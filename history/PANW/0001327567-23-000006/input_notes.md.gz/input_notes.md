# PANW notes — 0001327567-23-000006


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0001327567-23-000006:notes:1]
[same as prior period, unchanged from 0001327567-22-000038:notes:1]

[0001327567-23-000006:notes:2]
[same as prior period, unchanged from 0001327567-22-000038:notes:2]

[0001327567-23-000006:notes:3]
[same as prior period, unchanged from 0001327567-22-000038:notes:3]

[0001327567-23-000006:notes:4]
[same as prior period, unchanged from 0001327567-22-000038:notes:4]

[0001327567-23-000006:notes:5]
[same as prior period, unchanged from 0001327567-22-000038:notes:5]

[0001327567-23-000006:notes:6]
[same as prior period, unchanged from 0001327567-22-000038:notes:6]

[0001327567-23-000006:notes:7]
[same as prior period, unchanged from 0001327567-22-000038:notes:7]

[0001327567-23-000006:notes:8]
[same as prior period, unchanged from 0001327567-22-000038:notes:8]

[0001327567-23-000006:notes:9]
There have been no material changes to our significant accounting policies as of and for the six months ended January 31, 2023, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended July 31, 2022.

[0001327567-23-000006:notes:10]
[same as prior period, unchanged from 0001327567-22-000038:notes:10]

[0001327567-23-000006:notes:11]
[same as prior period, unchanged from 0001327567-22-000038:notes:11]


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001327567-23-000006:notes:12]
[same as prior period, unchanged from 0001327567-22-000038:notes:12]

[0001327567-23-000006:notes:13]
[same as prior period, unchanged from 0001327567-22-000038:notes:13]

[0001327567-23-000006:notes:14]
|  | Three Months Ended January 31, |  | Six Months Ended January 31, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Revenue: |  |  |  |  |  |  |  |
| Americas |  |  |  |  |  |  |  |
| United States | $ | 1,042.3 |  |  | $ | 858.6 |  |  | $ | 2,048.6 |  |  | $ | 1,670.3 |  |
| Other Americas | 74.7 |  |  | 57.3 |  |  | 139.1 |  |  | 112.3 |  |
| Total Americas | 1,117.0 |  |  | 915.9 |  |  | 2,187.7 |  |  | 1,782.6 |  |
| Europe, the Middle East, and Africa (“EMEA”) | 341.5 |  |  | 252.2 |  |  | 649.4 |  |  | 486.0 |  |
| Asia Pacific and Japan (“APAC”) | 196.6 |  |  | 148.8 |  |  | 381.4 |  |  | 295.7 |  |
| Total revenue | $ | 1,655.1 |  |  | $ | 1,316.9 |  |  | $ | 3,218.5 |  |  | $ | 2,564.3 |  |

[0001327567-23-000006:notes:15]
[same as prior period, unchanged from 0001327567-22-000038:notes:15]

[0001327567-23-000006:notes:16]
|  | Three Months Ended January 31, |  | Six Months Ended January 31, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Revenue: |  |  |  |  |  |  |  |
| Product | $ | 352.9 |  |  | $ | 308.0 |  |  | $ | 682.9 |  |  | $ | 603.5 |  |
| Subscription and support |  |  |  |  |  |  |  |
| Subscription | 815.4 |  |  | 618.0 |  |  | 1,579.4 |  |  | 1,196.8 |  |
| Support | 486.8 |  |  | 390.9 |  |  | 956.2 |  |  | 764.0 |  |
| Total subscription and support | 1,302.2 |  |  | 1,008.9 |  |  | 2,535.6 |  |  | 1,960.8 |  |
| Total revenue | $ | 1,655.1 |  |  | $ | 1,316.9 |  |  | $ | 3,218.5 |  |  | $ | 2,564.3 |  |

[0001327567-23-000006:notes:17]
[same as prior period, unchanged from 0001327567-22-000038:notes:17]

[0001327567-23-000006:notes:18]
During the six months ended January 31, 2023 and 2022, we recognized approximately $2.1 billion and $1.6 billion of revenue pertaining to amounts that were deferred as of July 31, 2022 and 2021, respectively.

[0001327567-23-000006:notes:19]
[same as prior period, unchanged from 0001327567-22-000038:notes:19]

[0001327567-23-000006:notes:20]
Remaining performance obligations were $8.8 billion as of January 31, 2023, of which we expect to recognize as revenue approximately $4.4 billion over the next 12 months and the remainder thereafter.


## us-gaap:FairValueDisclosuresTextBlock

[0001327567-23-000006:notes:21]
Fair Value Measurements The following table presents our financial assets and liabilities measured at fair value on a recurring basis as of January 31, 2023 and July 31, 2022 (in millions):

[0001327567-23-000006:notes:22]
|  |  | January 31, 2023 |  | July 31, 2022 |
|  |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Cash equivalents: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 655.9 |  |  | $ | — |  |  | $ | — |  |  | $ | 655.9 |  |  | $ | 1,205.2 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,205.2 |  |
| Certificates of deposit |  | — |  |  | 6.5 |  |  | — |  |  | 6.5 |  |  | — |  |  | 155.3 |  |  | — |  |  | 155.3 |  |
| Commercial paper |  | — |  |  | 175.2 |  |  | — |  |  | 175.2 |  |  | — |  |  | 69.1 |  |  | — |  |  | 69.1 |  |
| Corporate debt securities |  | — |  |  | 24.5 |  |  | — |  |  | 24.5 |  |  | — |  |  | 19.5 |  |  | — |  |  | 19.5 |  |
| U.S. government and agency securities |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 10.0 |  |  | — |  |  | 10.0 |  |
| Non-U.S. government and agency securities |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 5.1 |  |  | — |  |  | 5.1 |  |
| Total cash equivalents |  | 655.9 |  |  | 206.2 |  |  | — |  |  | 862.1 |  |  | 1,205.2 |  |  | 259.0 |  |  | — |  |  | 1,464.2 |  |
| Short-term investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Certificates of deposit |  | — |  |  | 210.8 |  |  | — |  |  | 210.8 |  |  | — |  |  | 116.4 |  |  | — |  |  | 116.4 |  |
| Commercial paper |  | — |  |  | 630.9 |  |  | — |  |  | 630.9 |  |  | — |  |  | 79.0 |  |  | — |  |  | 79.0 |  |
| Corporate debt securities |  | — |  |  | 701.0 |  |  | — |  |  | 701.0 |  |  | — |  |  | 505.0 |  |  | — |  |  | 505.0 |  |
| U.S. government and agency securities |  | — |  |  | 444.2 |  |  | — |  |  | 444.2 |  |  | — |  |  | 798.2 |  |  | — |  |  | 798.2 |  |
| Non-U.S. government and agency securities |  | — |  |  | 13.7 |  |  | — |  |  | 13.7 |  |  | — |  |  | 17.4 |  |  | — |  |  | 17.4 |  |
| Total short-term investments |  | — |  |  | 2,000.6 |  |  | — |  |  | 2,000.6 |  |  | — |  |  | 1,516.0 |  |  | — |  |  | 1,516.0 |  |
| Long-term investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate debt securities |  | — |  |  | 2,217.1 |  |  | — |  |  | 2,217.1 |  |  | — |  |  | 761.2 |  |  | — |  |  | 761.2 |  |
| U.S. government and agency securities |  | — |  |  | 68.9 |  |  | — |  |  | 68.9 |  |  | — |  |  | 118.2 |  |  | — |  |  | 118.2 |  |
| Non-U.S. government and agency securities |  | — |  |  | 54.4 |  |  | — |  |  | 54.4 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Asset-backed securities |  | — |  |  | 480.2 |  |  | — |  |  | 480.2 |  |  | — |  |  | 172.5 |  |  | — |  |  | 172.5 |  |
| Total long-term investments |  | — |  |  | 2,820.6 |  |  | — |  |  | 2,820.6 |  |  | — |  |  | 1,051.9 |  |  | — |  |  | 1,051.9 |  |

[0001327567-23-000006:notes:23]
|  |  | January 31, 2023 |  | July 31, 2022 |
|  |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Prepaid expenses and other current assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency forward contracts |  | — |  |  | 25.1 |  |  | — |  |  | 25.1 |  |  | — |  |  | 2.4 |  |  | — |  |  | 2.4 |  |
| Total prepaid expenses and other current assets |  | — |  |  | 25.1 |  |  | — |  |  | 25.1 |  |  | — |  |  | 2.4 |  |  | — |  |  | 2.4 |  |
| Other assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency forward contracts |  | — |  |  | 9.1 |  |  | — |  |  | 9.1 |  |  | — |  |  | 0.7 |  |  | — |  |  | 0.7 |  |
| Total other assets |  | — |  |  | 9.1 |  |  | — |  |  | 9.1 |  |  | — |  |  | 0.7 |  |  | — |  |  | 0.7 |  |
| Total assets measured at fair value |  | $ | 655.9 |  |  | $ | 5,061.6 |  |  | $ | — |  |  | $ | 5,717.5 |  |  | $ | 1,205.2 |  |  | $ | 2,830.0 |  |  | $ | — |  |  | $ | 4,035.2 |  |
| Accrued and other liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency forward contracts |  | $ | — |  |  | $ | 14.2 |  |  | $ | — |  |  | $ | 14.2 |  |  | $ | — |  |  | $ | 32.4 |  |  | $ | — |  |  | $ | 32.4 |  |
| Total accrued and other liabilities |  | — |  |  | 14.2 |  |  | — |  |  | 14.2 |  |  | — |  |  | 32.4 |  |  | — |  |  | 32.4 |  |
| Other long-term liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency forward contracts |  | — |  |  | 2.6 |  |  | — |  |  | 2.6 |  |  | — |  |  | 0.8 |  |  | — |  |  | 0.8 |  |
| Total other long-term liabilities |  | — |  |  | 2.6 |  |  | — |  |  | 2.6 |  |  | — |  |  | 0.8 |  |  | — |  |  | 0.8 |  |
| Total liabilities measured at fair value |  | $ | — |  |  | $ | 16.8 |  |  | $ | — |  |  | $ | 16.8 |  |  | $ | — |  |  | $ | 33.2 |  |  | $ | — |  |  | $ | 33.2 |  |

[0001327567-23-000006:notes:24]
Refer to Note 9. Debt for the carrying amount and estimated fair value of our convertible senior notes as of January 31, 2023 and July 31, 2022.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001327567-23-000006:notes:25]
Cash Equivalents and Investments
Available-for-sale Debt Securities

[0001327567-23-000006:notes:26]
The following tables summarize the amortized cost, unrealized gains and losses, and fair value of our available-for-sale debt securities as of January 31, 2023 and July 31, 2022 (in millions):

[0001327567-23-000006:notes:27]
|  | January 31, 2023 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 6.5 |  |  | $ | — |  |  | $ | — |  |  | $ | 6.5 |  |
| Commercial paper | 175.2 |  |  | — |  |  | — |  |  | 175.2 |  |
| Corporate debt securities | 24.5 |  |  | — |  |  | — |  |  | 24.5 |  |
| Total available-for-sale cash equivalents | $ | 206.2 |  |  | $ | — |  |  | $ | — |  |  | $ | 206.2 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 210.8 |  |  | $ | — |  |  | $ | — |  |  | $ | 210.8 |  |
| Commercial paper | 631.4 |  |  | 0.2 |  |  | (0.7) |  |  | 630.9 |  |
| Corporate debt securities | 2,927.9 |  |  | 9.0 |  |  | (18.8) |  |  | 2,918.1 |  |
| U.S. government and agency securities | 518.4 |  |  | — |  |  | (5.3) |  |  | 513.1 |  |
| Non-U.S. government and agency securities | 68.8 |  |  | — |  |  | (0.7) |  |  | 68.1 |  |
| Asset-backed securities | 481.7 |  |  | 1.0 |  |  | (2.5) |  |  | 480.2 |  |
| Total available-for-sale investments | $ | 4,839.0 |  |  | $ | 10.2 |  |  | $ | (28.0) |  |  | $ | 4,821.2 |  |

[0001327567-23-000006:notes:28]
|  | July 31, 2022 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 155.3 |  |  | $ | — |  |  | $ | — |  |  | $ | 155.3 |  |
| Commercial paper | 69.1 |  |  | — |  |  | — |  |  | 69.1 |  |
| Corporate debt securities | 19.5 |  |  | — |  |  | — |  |  | 19.5 |  |
| U.S. government and agency securities | 10.0 |  |  | — |  |  | — |  |  | 10.0 |  |
| Non-U.S. government and agency securities | 5.0 |  |  | 0.1 |  |  | — |  |  | 5.1 |  |
| Total available-for-sale cash equivalents | $ | 258.9 |  |  | $ | 0.1 |  |  | $ | — |  |  | $ | 259.0 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 116.5 |  |  | $ | — |  |  | $ | (0.1) |  |  | $ | 116.4 |  |
| Commercial paper | 79.1 |  |  | — |  |  | (0.1) |  |  | 79.0 |  |
| Corporate debt securities | 1,276.8 |  |  | 1.3 |  |  | (11.9) |  |  | 1,266.2 |  |
| U.S. government and agency securities | 928.1 |  |  | 0.1 |  |  | (11.8) |  |  | 916.4 |  |
| Non-U.S. government and agency securities | 17.6 |  |  | — |  |  | (0.2) |  |  | 17.4 |  |
| Asset-backed securities | $ | 173.4 |  |  | $ | 0.2 |  |  | $ | (1.1) |  |  | $ | 172.5 |  |
| Total available-for-sale investments | $ | 2,591.5 |  |  | $ | 1.6 |  |  | $ | (25.2) |  |  | $ | 2,567.9 |  |

[0001327567-23-000006:notes:29]
As of January 31, 2023, the gross unrealized losses that have been in a continuous unrealized loss position for less than 12 months were $17.2 million, which were related to $2.5 billion of available-for-sale debt securities, and the gross unrealized losses that have been in a continuous unrealized loss position for more than 12 months were $10.8 million, which were related to $571.6 million of available-for-sale debt securities. As of July 31, 2022 the gross unrealized losses that have been in a continuous unrealized loss position for less than 12 months were $24.8 million, which were related to $2.0 billion of available-for-sale debt securities, and the gross unrealized losses that have been in a continuous unrealized loss position for more than 12 months were not material.

[0001327567-23-000006:notes:30]
Unrealized losses related to our available-for-sale debt securities are due to interest rate fluctuations as opposed to credit quality. We do not intend to sell any of the securities in an unrealized loss position and it is not likely that we would be required to sell these securities before recovery of their amortized cost basis, which may be at maturity. We did not recognize any credit losses related to our available-for-sale debt securities during the three and six months ended January 31, 2023 and 2022.

[0001327567-23-000006:notes:31]
The following table summarizes the amortized cost and fair value of our available-for-sale debt securities as of January 31, 2023, by contractual years-to-maturity (in millions):

[0001327567-23-000006:notes:32]
|  | Amortized Cost |  | Fair Value |
| Due within one year | $ | 2,217.6 |  |  | $ | 2,206.8 |  |
| Due between one and three years | 2,658.4 |  |  | 2,651.4 |  |
| Due between three to five years | 123.8 |  |  | 123.5 |  |
| Due between five to ten years | 45.4 |  |  | 45.7 |  |
| Total | $ | 5,045.2 |  |  | $ | 5,027.4 |  |

[0001327567-23-000006:notes:33]
Marketable Equity Securities

[0001327567-23-000006:notes:34]
Marketable equity securities consist of money market funds and are included in cash and cash equivalents on our condensed consolidated balance sheets. As of January 31, 2023 and July 31, 2022, the carrying values of our marketable equity securities were $655.9 million and $1.2 billion, respectively. There were no unrealized gains or losses recognized for these securities during the three and six months ended January 31, 2023 and 2022.


## us-gaap:FinancingReceivablesTextBlock

[0001327567-23-000006:notes:35]
Financing ReceivablesThe following table summarizes our short-term and long-term financing receivables as of January 31, 2023 and July 31, 2022 (in millions):

[0001327567-23-000006:notes:36]
|  |  | January 31, 2023 |  | July 31, 2022 |
| Short-term financing receivables, gross |  | $ | 174.3 |  |  | $ | 112.6 |  |
| Allowance for credit losses |  | (2.5) |  |  | (1.3) |  |
| Short-term financing receivables, net |  | $ | 171.8 |  |  | $ | 111.3 |  |
| Long-term financing receivables, gross |  | $ | 222.0 |  |  | $ | 194.6 |  |
| Allowance for credit losses |  | (3.9) |  |  | (2.5) |  |
| Long-term financing receivables, net |  | $ | 218.1 |  |  | $ | 192.1 |  |

[0001327567-23-000006:notes:37]
There was no significant activity in allowance for credit losses during the three and six months ended January 31, 2023 and 2022. Past due amounts on financing receivables were not material as of January 31, 2023 and July 31, 2022.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001327567-23-000006:notes:38]
[same as prior period, unchanged from 0001327567-22-000038:notes:38]

[0001327567-23-000006:notes:39]
As of January 31, 2023 and July 31, 2022, the total notional amount of our outstanding foreign currency forward contracts was $1.1 billion and $856.9 million, respectively. Refer to Note 3. Fair Value Measurements for the fair value of our derivative instruments as reported on our condensed consolidated balance sheets as of January 31, 2023 and July 31, 2022.
As of January 31, 2023, unrealized gains in accumulated other comprehensive income (“AOCI”) related to our cash flow hedges were $14.2 million, of which $11.9 million of gains are expected to be recognized into earnings within the next 12 months. As of July 31, 2022, unrealized losses in AOCI related to our cash flow hedges were $24.8 million, of which $22.0 million of losses are expected to be recognized into earnings within the next 12 months.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001327567-23-000006:notes:40]
Acquisition
Cider Security Ltd.

[0001327567-23-000006:notes:41]
On December 20, 2022, we completed our acquisition of Cider Security Ltd. (“Cider”), a privately-held cloud security company. We expect the acquisition will support Prisma Cloud’s platform approach to securing the entire application security lifecycle from code-to-cloud. The total purchase consideration for the acquisition of Cider was $198.3 million, which consisted of the following (in millions):

[0001327567-23-000006:notes:42]
|  | Amount |
| Cash | $ | 198.0 |  |
| Fair value of replacement awards | 0.3 |  |
| Total | $ | 198.3 |  |

[0001327567-23-000006:notes:43]
As part of the acquisition, we issued replacement equity awards, which included 0.2 million shares of our restricted common stock. The total fair value of the replacement equity awards was $48.6 million, of which the portion attributable to services performed prior to the acquisition date was allocated to purchase consideration. The remaining fair value was allocated to future services and will be expensed over the remaining service periods as share-based compensation.

[0001327567-23-000006:notes:44]
We have accounted for this transaction as a business combination and allocated the purchase consideration to assets acquired and liabilities assumed based on preliminary estimated fair values, as presented in the following table (in millions):

[0001327567-23-000006:notes:45]
|  | Amount |
| Goodwill | $ | 164.6 |  |
| Identified intangible assets | 27.8 |  |
| Cash | 12.4 |  |
| Net liabilities assumed | (6.5) |  |
| Total | $ | 198.3 |  |

[0001327567-23-000006:notes:46]
Goodwill generated from this business combination is primarily attributable to the assembled workforce and expected post-acquisition synergies from integrating Cider technology into our platforms. The goodwill is expected to be deductible for U.S. income tax purposes.

[0001327567-23-000006:notes:47]
The following table presents details of the identified intangible asset acquired (in millions, except years):

[0001327567-23-000006:notes:48]
|  | Fair Value |  | Estimated Useful Life |
| Developed technology | $ | 27.8 |  |  | 5 years |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001327567-23-000006:notes:49]
Intangible Assets
Goodwill

[0001327567-23-000006:notes:50]
The following table presents details of our goodwill during the six months ended January 31, 2023 (in millions):

[0001327567-23-000006:notes:51]
|  | Amount |
| Balance as of July 31, 2022 | $ | 2,747.7 |  |
| Goodwill acquired | 164.6 |  |
| Balance as of January 31, 2023 | $ | 2,912.3 |  |

[0001327567-23-000006:notes:52]
Purchased Intangible Assets

[0001327567-23-000006:notes:53]
The following table presents details of our purchased intangible assets as of January 31, 2023 and July 31, 2022 (in millions):

[0001327567-23-000006:notes:54]
|  | January 31, 2023 |  | July 31, 2022 |
|  | Gross Carrying Amount |  | Accumulated Amortization |  | Net Carrying Amount |  | Gross Carrying Amount |  | Accumulated Amortization |  | Net Carrying Amount |
| Intangible assets subject to amortization: |  |  |  |  |  |  |  |  |  |  |  |
| Developed technology | $ | 628.5 |  |  | $ | (390.2) |  |  | $ | 238.3 |  |  | $ | 600.7 |  |  | $ | (347.9) |  |  | $ | 252.8 |  |
| Customer relationships | 172.7 |  |  | (63.1) |  |  | 109.6 |  |  | 172.7 |  |  | (52.2) |  |  | 120.5 |  |
| Acquired intellectual property | 14.6 |  |  | (5.4) |  |  | 9.2 |  |  | 11.3 |  |  | (4.8) |  |  | 6.5 |  |
| Trade name and trademarks | 9.4 |  |  | (9.4) |  |  | — |  |  | 9.4 |  |  | (9.4) |  |  | — |  |
| Other | 0.9 |  |  | (0.2) |  |  | 0.7 |  |  | 0.9 |  |  | (0.1) |  |  | 0.8 |  |
| Total intangible assets subject to amortization | 826.1 |  |  | (468.3) |  |  | 357.8 |  |  | 795.0 |  |  | (414.4) |  |  | 380.6 |  |
| Intangible assets not subject to amortization: |  |  |  |  |  |  |  |  |  |  |  |
| In-process research and development | 3.9 |  |  | — |  |  | 3.9 |  |  | 3.9 |  | — |  |  | 3.9 |  |
| Total purchased intangible assets | $ | 830.0 |  |  | $ | (468.3) |  |  | $ | 361.7 |  |  | $ | 798.9 |  |  | $ | (414.4) |  |  | $ | 384.5 |  |

[0001327567-23-000006:notes:55]
We recognized amortization expense of $24.8 million and $53.9 million for the three and six months ended January 31, 2023, respectively, and $31.7 million and $63.5 million for the three and six months ended January 31, 2022, respectively.

[0001327567-23-000006:notes:56]
The following table summarizes estimated future amortization expense of our intangible assets subject to amortization as of January 31, 2023 (in millions):

[0001327567-23-000006:notes:57]
|  |  |  | Fiscal years ending July 31, |
|  | Total |  | Remaining 2023 |  | 2024 |  | 2025 |  | 2026 |  | 2027 |  | 2028 and Thereafter |
| Future amortization expense | $ | 357.8 |  |  | $ | 50.7 |  |  | $ | 97.1 |  |  | $ | 83.4 |  |  | $ | 61.6 |  |  | $ | 34.6 |  |  | $ | 30.4 |  |


## us-gaap:DebtDisclosureTextBlock

[0001327567-23-000006:notes:58]
Debt
Convertible Senior Notes

[0001327567-23-000006:notes:59]
In July 2018, we issued $1.7 billion aggregate principal amount of 0.75% Convertible Senior Notes due 2023 (the “2023 Notes”) and in June 2020, we issued $2.0 billion aggregate principal amount of 0.375% Convertible Senior Notes due 2025 (the “2025 Notes,” and together with the 2023 Notes, the “Notes”). The 2023 Notes bear interest at a fixed rate of 0.75% per year, payable semi-annually in arrears on January 1 and July 1 of each year, beginning on January 1, 2019. The 2025 Notes bear interest at a fixed rate of 0.375% per year, payable semi-annually in arrears on June 1 and December 1 of each year, beginning on December 1, 2020. Each series of the convertible notes is governed by an indenture between us, as the issuer, and U.S. Bank National Association, as Trustee (individually, each an “Indenture,” and together, the “Indentures”). The Notes of each series are unsecured, unsubordinated obligations and the applicable Indenture governing each series of Notes does not contain any financial covenants or restrictions on the payments of dividends, the incurrence of indebtedness, or the issuance or repurchase of securities by us or any of our subsidiaries. The 2023 Notes and the 2025 Notes mature on July 1, 2023 and June 1, 2025, respectively. We cannot redeem the 2023 Notes prior to maturity. We may redeem for cash all or any portion of the 2025 Notes, at our option, on or after June 5, 2023, and prior to the 31st scheduled trading day immediately preceding the maturity date if the last reported sale price of our common stock has been at least 130% of the conversion price then in effect for at least 20 trading days during any 30 consecutive trading day period ending on and including the trading day preceding the date on which we provide notice of redemption. The redemption will be at a price equal to 100% of the principal amount of the 2025 Notes and adjusted for interest. If we call any or all of the 2025 Notes for redemption, holders may convert such 2025 Notes called for redemption at any time prior to the close of business on the second scheduled trading day immediately preceding the redemption date.

[0001327567-23-000006:notes:60]
The following table presents details of our Notes (number of shares in millions):

[0001327567-23-000006:notes:61]
|  | Conversion Rate per $1,000 Principal |  | Initial Conversion Price |  | Convertible Date |  | Initial Number of Shares |
| 2023 Notes | 11.2635 |  |  | $ | 88.78 |  |  | April 1, 2023 |  | 19.1 |  |
| 2025 Notes | 10.0806 |  |  | $ | 99.20 |  |  | March 1, 2025 |  | 20.1 |  |

[0001327567-23-000006:notes:62]
Holders of the Notes may surrender their Notes for conversion at their option at any time prior to the close of business on the business day immediately preceding their respective convertible dates only under the following circumstances:

[0001327567-23-000006:notes:63]
•during any fiscal quarter commencing after the fiscal quarters ending on October 31, 2018 and October 31, 2020 for the 2023 Notes and the 2025 Notes, respectively (and only during such fiscal quarter), if the last reported sale price of our common stock for at least 20 trading days (whether or not consecutive) during a period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the applicable conversion price for the respective Notes on each applicable trading day (the “sale price condition”);

[0001327567-23-000006:notes:64]
•during the five business day period after any five consecutive trading day period (the “measurement period”) in which the trading price per $1,000 principal amount of the applicable series of Notes for each trading day of the measurement period was less than 98% of the product of the last reported sale price of our common stock and the applicable conversion rate for the respective Notes on each such trading day; or

[0001327567-23-000006:notes:65]
•upon the occurrence of specified corporate events.

[0001327567-23-000006:notes:66]
On or after the respective convertible date, holders may surrender all or any portion of their Notes for conversion at any time prior to the close of business on the second scheduled trading day immediately preceding the applicable maturity date regardless of the foregoing conditions, and such conversions will be settled upon the applicable maturity date. Upon conversion, holders of the Notes of a series will receive cash equal to the aggregate principal amount of the Notes of such series to be converted, and, at our election, cash and/or shares of our common stock for any amounts in excess of the aggregate principal amount of the Notes of such series being converted.

[0001327567-23-000006:notes:67]
The conversion price will be subject to adjustment in some events. Holders of the Notes of a series who convert their Notes of such series in connection with certain corporate events that constitute a “make-whole fundamental change” under the applicable Indenture are, under certain circumstances, entitled to an increase in the conversion rate for such series of Notes. Additionally, upon the occurrence of a corporate event that constitutes a “fundamental change” under the applicable Indenture, holders of the Notes of such series may require us to repurchase for cash all or a portion of the Notes of such series at a repurchase price equal to 100% of the principal amount of the Notes of such series plus accrued and unpaid interest to, but excluding, the fundamental change repurchase date.

[0001327567-23-000006:notes:68]
The sale price condition for the Notes was met during the fiscal quarter ended January 31, 2023, and as a result, holders may convert their Notes at any time during the fiscal quarter ending April 30, 2023. The net carrying amount of the Notes was classified as a current liability on our condensed consolidated balance sheet as of January 31, 2023.

[0001327567-23-000006:notes:69]
The following table sets forth the components of the Notes (in millions):

[0001327567-23-000006:notes:70]
|  | January 31, 2023 | July 31, 2022 |
|  | 2023 Notes |  | 2025 Notes |  | Total |  | 2023 Notes |  | 2025 Notes |  | Total |
| Liability component: |  |  |  |  |  |  |  |  |  |  |  |
| Principal | $ | 1,691.9 |  |  | $ | 1,999.4 |  |  | $ | 3,691.3 |  |  | $ | 1,691.9 |  |  | $ | 1,999.4 |  |  | $ | 3,691.3 |  |
| Less: debt discount and debt issuance costs, net of amortization | (1.2) |  |  | (9.8) |  |  | (11.0) |  |  | (2.6) |  |  | (11.9) |  |  | (14.5) |  |
| Net carrying amount | $ | 1,690.7 |  |  | $ | 1,989.6 |  |  | $ | 3,680.3 |  |  | $ | 1,689.3 |  |  | $ | 1,987.5 |  |  | $ | 3,676.8 |  |

[0001327567-23-000006:notes:71]
The total estimated fair value of the 2023 Notes and 2025 Notes were $3.0 billion and $3.3 billion at January 31, 2023, respectively, and $3.2 billion and $3.5 billion at July 31, 2022, respectively. The fair value was determined based on the closing trading price per $100 of the applicable series of the Notes as of the last day of trading for the period. We consider the fair value of the Notes at January 31, 2023 and July 31, 2022 to be a Level 2 measurement. The fair value of the Notes is primarily affected by the trading price of our common stock and market interest rates.

[0001327567-23-000006:notes:72]
The following table sets forth interest expense recognized related to the Notes (dollars in millions):

[0001327567-23-000006:notes:73]
|  | Three Months Ended January 31, |  | Six Months Ended January 31, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
|  | 2023 Notes |  | 2025 Notes |  | Total |  | 2023 Notes |  | 2025 Notes |  | Total |  | 2023 Notes |  | 2025 Notes |  | Total |  | 2023 Notes |  | 2025 Notes |  | Total |
| Contractual interest expense | $ | 3.2 |  | $ | 2.0 |  | $ | 5.2 |  |  | $ | 3.1 |  | $ | 1.9 |  |  | $ | 5.0 |  | $ | 6.4 |  | $ | 3.8 |  | $ | 10.2 |  |  | $ | 6.3 |  | $ | 3.8 |  | $ | 10.1 |  |
| Amortization of debt issuance costs | 0.7 |  | 1.0 |  | 1.7 |  |  | 0.7 |  | 1.1 |  |  | 1.8 |  | 1.4 |  | 2.1 |  | 3.5 |  |  | 1.4 |  | 2.2 |  | 3.6 |  |
| Total interest expense | $ | 3.9 |  | $ | 3.0 |  | $ | 6.9 |  |  | $ | 3.8 |  | $ | 3.0 |  |  | $ | 6.8 |  | $ | 7.8 |  | $ | 5.9 |  | $ | 13.7 |  |  | $ | 7.7 |  | $ | 6.0 |  | $ | 13.7 |  |
| Effective interest rate | 0.9 | % |  | 0.6 | % |  |  |  | 0.9 | % |  | 0.6 | % |  |  |  | 0.9 | % |  | 0.6 | % |  |  |  | 0.9 | % |  | 0.6 | % |  |  |

[0001327567-23-000006:notes:74]
Note Hedges

[0001327567-23-000006:notes:75]
To minimize the impact of potential economic dilution upon conversion of our Notes, we entered into separate convertible note hedge transactions (the “2023 Note Hedges,” with respect to the 2023 Notes, the “2025 Note Hedges,” with respect to the 2025 Notes, and the 2023 Notes Hedges together with 2025 Note Hedges, the “Note Hedges”) with respect to our common stock concurrent with the issuance of each series of the Notes.

[0001327567-23-000006:notes:76]
The following table presents details of our Note Hedges (in millions):

[0001327567-23-000006:notes:77]
|  | Initial Number of Shares |  | Aggregate Purchase |
| 2023 Note Hedges | 19.1 |  |  | $ | 332.0 |  |
| 2025 Note Hedges | 20.1 |  |  | $ | 370.8 |  |

[0001327567-23-000006:notes:78]
The Note Hedges cover shares of our common stock at a strike price per share that corresponds to the initial applicable conversion price of the applicable series of the Notes, which are also subject to adjustment, and are exercisable upon conversion of the applicable series of the Notes. The Note Hedges will expire upon maturity of the applicable series of the Notes. The Note Hedges are separate transactions and are not part of the terms of the applicable series of the Notes. Holders of the Notes of either series will not have any rights with respect to the Note Hedges. Any shares of our common stock receivable by us under the Note Hedges are excluded from the calculation of diluted earnings per share as they are antidilutive. The aggregate amounts paid for the Note Hedges are included in additional paid-in capital on our condensed consolidated balance sheets.

[0001327567-23-000006:notes:79]
Warrants

[0001327567-23-000006:notes:80]
Separately, but concurrently with the issuance of each series of our Notes, we entered into transactions whereby we sold warrants (the “2023 Warrants,” with respect to the 2023 Notes, the “2025 Warrants,” with respect to the 2025 Notes, and the 2023 Warrants together with the 2025 Warrants, the “Warrants”) to acquire shares of our common stock, subject to anti-dilution adjustments. The 2023 Warrants and 2025 Warrants are exercisable beginning October 2023 and September 2025, respectively.

[0001327567-23-000006:notes:81]
The following table presents details of our Warrants (in millions, except per share data):

[0001327567-23-000006:notes:82]
|  | Initial Number of Shares |  | Strike Price per Share |  | Aggregate Proceeds |
| 2023 Warrants | 19.1 |  |  | $ | 139.27 |  |  | $ | 145.4 |  |
| 2025 Warrants | 20.1 |  |  | $ | 136.16 |  |  | $ | 202.8 |  |

[0001327567-23-000006:notes:83]
The shares issuable under the Warrants will be included in the calculation of diluted earnings per share when the average market value per share of our common stock for the reporting period exceeds the applicable strike price for such series of Warrants. The Warrants are separate transactions and are not part of either series of Notes or Note Hedges and are not remeasured through earnings each reporting period. Holders of the Notes of either series will not have any rights with respect to the Warrants. The aggregate proceeds received from the sale of the Warrants are included in additional paid-in capital on our condensed consolidated balance sheets.

[0001327567-23-000006:notes:84]
Revolving Credit Facility

[0001327567-23-000006:notes:85]
On September 4, 2018, we entered into a credit agreement (the “Credit Agreement”) with certain institutional lenders that provides for a $400.0 million unsecured revolving credit facility (the “Credit Facility”), with an option to increase the amount of the Credit Facility by up to an additional $350.0 million, subject to certain conditions. The Credit Facility matures on the earlier of (i) September 4, 2023 and (ii) the date that is 91 days prior to the stated maturity of our 2023 Notes if (a) any of the 2023 Notes are still outstanding and (b) our unrestricted cash and cash equivalents are less than the then outstanding principal amount of our 2023 Notes plus $400.0 million.

[0001327567-23-000006:notes:86]
The borrowings under the Credit Facility currently bear interest, at our option, at a base rate plus a spread of 0.00% to 0.75%, or an adjusted LIBO Rate plus a spread of 1.00% to 1.75%, in each case with such spread being determined based on our leverage ratio. We are obligated to pay an ongoing commitment fee on undrawn amounts at a rate of 0.125% to 0.250%, depending on our leverage ratio. In March 2021, the ICE Benchmark Administration, the administrator of LIBO Rate, announced that it will cease publication of the LIBO Rate by June 2023. Under the terms of our Credit Facility, in the event of the discontinuance of the LIBO Rate, a mutually agreed-upon alternative benchmark rate will be established to replace the LIBO Rate, which may include the Secured Overnight Financing Rate (“SOFR”). We do not anticipate that the discontinuance of the LIBO Rate will materially impact our liquidity or financial position.

[0001327567-23-000006:notes:87]
As of January 31, 2023, there were no amounts outstanding and we were in compliance with all covenants under the Credit Agreement.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001327567-23-000006:notes:88]
Commitments and Contingencies
Purchase Commitments

[0001327567-23-000006:notes:89]
Manufacturing Purchase Commitments

[0001327567-23-000006:notes:90]
In order to reduce manufacturing lead times and plan for adequate supply, we enter into agreements with manufacturing partners and component suppliers to procure inventory based on our demand forecasts. The following table presents details of the aggregate future minimum or fixed purchase commitments under these arrangements, excluding obligations under contracts that we can cancel as of January 31, 2023 (in millions):

[0001327567-23-000006:notes:91]
|  |  |  | Fiscal years ending July 31, |
|  | Total |  | Remaining 2023 |  | 2024 |  | 2025 |  | 2026 |  | 2027 |  | 2028 and Thereafter |
| Manufacturing purchase commitments | $ | 293.5 |  |  | $ | 120.5 |  |  | $ | 98.0 |  |  | $ | 35.0 |  |  | $ | 40.0 |  |  | $ | — |  |  | $ | — |  |

[0001327567-23-000006:notes:92]
Other Purchase Commitments

[0001327567-23-000006:notes:93]
We have entered into various non-cancelable agreements with certain service providers, under which we are committed to minimum or fixed purchases. The following table presents details of the aggregate future non-cancelable purchase commitments under these agreements as of January 31, 2023 (in millions):

[0001327567-23-000006:notes:94]
|  |  |  | Fiscal years ending July 31, |
|  | Total |  | Remaining 2023 |  | 2024 |  | 2025 |  | 2026 |  | 2027 |  | 2028 and Thereafter |
| Other purchase commitments | $ | 1,701.2 |  |  | $ | 54.2 |  |  | $ | 228.1 |  |  | $ | 416.7 |  |  | $ | 517.5 |  |  | $ | 483.9 |  |  | $ | 0.8 |  |

[0001327567-23-000006:notes:95]
Additionally, we have a $159.6 million minimum purchase commitment with a service provider through September 2027 with no specified annual commitments.

[0001327567-23-000006:notes:96]
Litigation

[0001327567-23-000006:notes:97]
We are subject to legal proceedings, claims, and litigation arising in the ordinary course of business, including intellectual property litigation. Such matters are subject to many uncertainties and outcomes are not predictable with assurance. We accrue for contingencies when we believe that a loss is probable and that we can reasonably estimate the amount of any such loss.

[0001327567-23-000006:notes:98]
To the extent there is a reasonable possibility that a loss exceeding amounts already recognized may be incurred and the amount of such additional loss would be material, we will either disclose the estimated additional loss or state that such an estimate cannot be made. As of January 31, 2023, we have not recorded any significant accruals for loss contingencies associated with such legal proceedings, determined that an unfavorable outcome is probable or reasonably possible, or determined that the amount or range of any possible loss is reasonably estimable.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001327567-23-000006:notes:99]
[same as prior period, unchanged from 0001327567-22-000038:notes:87]

[0001327567-23-000006:notes:100]
[same as prior period, unchanged from 0001327567-22-000038:notes:88]

[0001327567-23-000006:notes:101]
The following table summarizes the share repurchase activity under our share repurchase program (in millions, except per share amounts):

[0001327567-23-000006:notes:102]
|  |  |  | Three and Six Months Ended January 31, |
|  |  |  |  |  | 2023 |  | 2022 |
| Number of shares repurchased |  |  |  |  | 1.8 |  |  | 3.1 |  |
| Weighted average price per share (1) |  |  |  |  | $ | 138.65 |  |  | $ | 177.93 |  |
| Aggregate purchase price (1) |  |  |  |  | $ | 250.0 |  |  | $ | 550.0 |  |

[0001327567-23-000006:notes:103]
______________

[0001327567-23-000006:notes:104]
(1)     Includes transaction costs

[0001327567-23-000006:notes:105]
In addition to the share repurchase activity summarized in the table above, during the six months ended January 31, 2023, we paid $22.7 million related to share repurchases of our common stock that were not settled as of July 31, 2022.

[0001327567-23-000006:notes:106]
As of January 31, 2023, $750.0 million remained available for future share repurchases under our current repurchase authorization. The total price of the shares repurchased and related transaction costs are reflected as a reduction to common stock and additional paid-in capital on our condensed consolidated balance sheets.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001327567-23-000006:notes:107]
[same as prior period, unchanged from 0001327567-22-000038:notes:91]

[0001327567-23-000006:notes:108]
The following table summarizes the RSU and PSU activity under our stock plans during the six months ended January 31, 2023 (in millions, except per share amounts):

[0001327567-23-000006:notes:109]
|  | RSUs Outstanding |  | PSUs Outstanding |
|  | Number of Shares |  | Weighted-Average Grant-Date Fair Value Per Share |  |  |  | Aggregate Intrinsic Value |  | Number of Shares |  | Weighted-Average Grant-Date Fair Value Per Share |  |  |  | Aggregate Intrinsic Value |
| Balance—July 31, 2022 | 14.8 |  |  | $ | 115.51 |  |  |  |  | $ | 2,456.9 |  |  | 3.1 |  |  | $ | 106.38 |  |  |  |  | $ | 513.7 |  |
| Granted(1) | 4.8 |  |  | $ | 163.23 |  |  |  |  |  |  | 2.8 |  |  | $ | 141.40 |  |  |  |  |  |
| Vested | (3.4) |  |  | $ | 102.07 |  |  |  |  |  |  | (1.2) |  |  | $ | 115.67 |  |  |  |  |  |
| Forfeited | (0.8) |  |  | $ | 119.48 |  |  |  |  |  |  | (0.2) |  |  | $ | 135.26 |  |  |  |  |  |
| Balance—January 31, 2023 | 15.4 |  |  | $ | 133.47 |  |  |  |  | $ | 2,442.8 |  |  | 4.5 |  |  | $ | 124.21 |  |  |  |  | $ | 711.5 |  |

[0001327567-23-000006:notes:110]
[same as prior period, unchanged from 0001327567-22-000038:notes:95]

[0001327567-23-000006:notes:111]
[same as prior period, unchanged from 0001327567-22-000038:notes:96]

[0001327567-23-000006:notes:112]
[same as prior period, unchanged from 0001327567-22-000038:notes:97]

[0001327567-23-000006:notes:113]
During the six months ended January 31, 2023, we granted 0.8 million shares of PSUs with both service and market conditions to certain employees. The market conditions are satisfied when the price of our common stock is equal to or exceeds stock price targets of $233.33, $266.67, $300.00, and $333.33 based on the average closing price for 30 consecutive trading days during the three- or four-year period following the date of grant. To the extent that the market conditions have been met, one-fourth of the awards will vest on each anniversary date of the grant date, subject to continued service. As of January 31, 2023, the stock price targets for these PSU awards have not been met.

[0001327567-23-000006:notes:114]
During the six months ended January 31, 2023 and 2022, we granted 1.6 million and 0.6 million shares of PSUs, respectively, which contain service, performance and market conditions, to certain employees. The service conditions are satisfied over a period of one to three years. The performance conditions are based on revenue growth or billing growth. The market condition is measured based on our total shareholder return (“TSR”) relative to the TSR of the companies listed in the Standard & Poor’s 500 index. As of January 31, 2023, we have approved 2.3 million shares of PSUs, which will be granted upon the performance condition being established during the next two years.

[0001327567-23-000006:notes:115]
[same as prior period, unchanged from 0001327567-22-000038:notes:100]

[0001327567-23-000006:notes:116]
|  |  |  | Six Months Ended |
|  |  |  | January 31, |
|  |  |  |  |  | 2023 |  | 2022 |
| Volatility |  |  |  |  | 39.6% - 44.8% |  | 36.0% - 38.0% |
| Expected term (in years) |  |  |  |  | 1.0 - 4.0 |  | 1.9 - 3.0 |
| Dividend yield |  |  |  |  | 0.0 | % |  | 0.0 | % |
| Risk-free interest rate |  |  |  |  | 3.2% - 3.6% |  | 0.2% - 0.4% |
| Grant-date fair value per share |  |  |  |  | $105.60 - $280.41 |  | $137.16 - $140.22 |

[0001327567-23-000006:notes:117]
[same as prior period, unchanged from 0001327567-22-000038:notes:102]

[0001327567-23-000006:notes:118]
We have granted PSOs with both service and market conditions to certain executives. The market conditions were achieved when certain stock price targets were met. As of January 31, 2023, all stock price targets for our outstanding PSOs have been satisfied. One-fourth of the PSOs will vest on each anniversary date of the grant date, subject to continued service. The contractual term for the PSOs outstanding ranges from seven to seven and a half years following the date of grant in fiscal year 2018 and 2019.

[0001327567-23-000006:notes:119]
The following table summarizes the PSO activity under our stock plans during the six months ended January 31, 2023 (in millions, except per share amounts):

[0001327567-23-000006:notes:120]
|  |  |  | PSOs Outstanding |
|  |  |  |  |  |  |  |  |  | Number of Shares |  | Weighted-Average Exercise Price Per Share |  | Weighted-Average Remaining Contractual Term(Years) |  | Aggregate Intrinsic Value |
| Balance—July 31, 2022 |  |  |  |  |  |  |  |  | 8.0 |  |  | $ | 64.85 |  |  | 3.2 |  | $ | 809.3 |  |
| Balance—January 31, 2023 |  |  |  |  |  |  |  |  | 8.0 |  |  | $ | 64.85 |  |  | 2.7 |  | $ | 747.7 |  |
| Exercisable—January 31, 2023 |  |  |  |  |  |  |  |  | 8.0 |  |  | $ | 64.85 |  |  | 2.7 |  | $ | 747.7 |  |

[0001327567-23-000006:notes:121]
[same as prior period, unchanged from 0001327567-22-000038:notes:106]

[0001327567-23-000006:notes:122]
[same as prior period, unchanged from 0001327567-22-000038:notes:107]

[0001327567-23-000006:notes:123]
|  | Three Months Ended |  | Six Months Ended |
|  | January 31, |  | January 31, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Cost of product revenue | $ | 2.6 |  |  | $ | 2.3 |  |  | $ | 5.0 |  |  | $ | 4.6 |  |
| Cost of subscription and support revenue | 30.7 |  |  | 27.7 |  |  | 59.5 |  |  | 54.4 |  |
| Research and development | 129.7 |  |  | 123.6 |  |  | 247.7 |  |  | 249.2 |  |
| Sales and marketing | 88.4 |  |  | 79.8 |  |  | 175.8 |  |  | 153.1 |  |
| General and administrative | 38.5 |  |  | 31.7 |  |  | 67.9 |  |  | 64.1 |  |
| Total share-based compensation | $ | 289.9 |  |  | $ | 265.1 |  |  | $ | 555.9 |  |  | $ | 525.4 |  |

[0001327567-23-000006:notes:124]
As of January 31, 2023, total compensation cost related to unvested share-based awards not yet recognized was $2.3 billion. This cost is expected to be amortized over a weighted-average period of approximately 2.7 years.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001327567-23-000006:notes:125]
Income Taxes
For the three and six months ended January 31, 2023, our provision for income taxes reflected an effective tax rate of 0.2% and 12.3%, respectively. For the three and six months ended January 31, 2022, our provision for income taxes reflected an effective tax rate of negative 15.7% and negative 14.6%, respectively.

[0001327567-23-000006:notes:126]
Our income taxes for the three and six months ended January 31, 2023 were primarily due to U.S. federal and state income taxes, withholding taxes, and foreign income taxes. Our effective tax rate varied for the three and six months ended January 31, 2023 compared to the same periods in 2022 primarily due to an increase in current taxes driven by capitalization of research and development expenditures with no offsetting deferred benefit as a result of our valuation allowance. This increase was offset by a tax benefit from a release of tax reserves related to uncertain tax positions resulting from an agreement with a non-U.S. tax authority to pay $28.9 million to settle a tax audit during the three months ended January 31, 2023.

[0001327567-23-000006:notes:127]
Our income taxes for the three and six months ended January 31, 2022 were primarily due to foreign income taxes and withholding taxes. Our effective tax rates differed from the U.S. statutory tax rate primarily due to changes in our valuation allowance.

[0001327567-23-000006:notes:128]
As of January 31, 2023, our gross uncertain tax positions were $396.0 million and our interest and penalties were $6.7 million. We recognize both interest and penalties associated with uncertain tax positions as a component of income tax.


## us-gaap:EarningsPerShareTextBlock

[0001327567-23-000006:notes:129]
Net Income (Loss) Per ShareBasic net income (loss) per share is computed by dividing net income (loss) by basic weighted-average shares outstanding during the period. Diluted net income (loss) per share is computed by dividing net income (loss) by diluted weighted-average shares outstanding during the period giving effect to all potentially dilutive securities to the extent they are dilutive. Potentially dilutive securities include shares issuable upon conversion of our convertible senior notes using the if-converted method. Potentially dilutive securities also include warrants related to the issuance of convertible senior notes and equity awards under our employee equity incentive plans using the treasury stock method.
The following table presents the computation of basic and diluted net income (loss) per share of common stock (in millions, except per share data):

[0001327567-23-000006:notes:130]
|  | Three Months Ended |  | Six Months Ended |
|  | January 31, |  | January 31, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Net income (loss) | $ | 84.2 |  |  | $ | (93.5) |  |  | $ | 104.2 |  |  | $ | (197.1) |  |
| Weighted-average shares used to compute net income (loss) per share, basic | 302.3 |  |  | 294.5 |  |  | 301.0 |  |  | 293.7 |  |
| Weighted-average effect of potentially dilutive securities: |  |  |  |  |  |  |  |
| Convertible senior notes | 15.2 |  |  | — |  |  | 16.5 |  |  | — |  |
| Warrants related to the issuance of convertible senior notes | 4.1 |  |  | — |  |  | 6.0 |  |  | — |  |
| Employee equity incentive plans | 10.0 |  |  | — |  |  | 11.5 |  |  | — |  |
| Weighted-average shares used to compute net income (loss) per share, diluted | 331.6 |  |  | 294.5 |  |  | 335.0 |  |  | 293.7 |  |
| Net income (loss) per share, basic | $ | 0.28 |  |  | $ | (0.32) |  |  | $ | 0.35 |  |  | $ | (0.67) |  |
| Net income (loss) per share, diluted | $ | 0.25 |  |  | $ | (0.32) |  |  | $ | 0.31 |  |  | $ | (0.67) |  |

[0001327567-23-000006:notes:131]
[same as prior period, unchanged from 0001327567-22-000038:notes:116]

[0001327567-23-000006:notes:132]
|  | Three Months Ended |  | Six Months Ended |
|  | January 31, |  | January 31, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Convertible senior notes | — |  |  | 39.2 |  |  | — |  |  | 39.2 |  |
| Warrants related to the issuance of convertible senior notes | — |  |  | 39.2 |  |  | — |  |  | 39.2 |  |
| Employee equity incentive plans | 8.9 |  |  | 32.0 |  |  | 5.8 |  |  | 32.0 |  |
| Total | 8.9 |  |  | 110.4 |  |  | 5.8 |  |  | 110.4 |  |


## us-gaap:OtherNonoperatingIncomeAndExpenseTextBlock

[0001327567-23-000006:notes:133]
[same as prior period, unchanged from 0001327567-22-000038:notes:118]

[0001327567-23-000006:notes:134]
|  | Three Months Ended |  | Six Months Ended |
|  | January 31, |  | January 31, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Interest income | $ | 56.6 |  |  | $ | 1.9 |  |  | $ | 86.0 |  |  | $ | 3.3 |  |
| Foreign currency exchange gains (losses), net | (7.3) |  |  | (1.7) |  |  | (2.9) |  |  | (5.6) |  |
| Other | 2.1 |  |  | (0.3) |  |  | (5.7) |  |  | 0.6 |  |
| Total other income (expense), net | $ | 51.4 |  |  | $ | (0.1) |  |  | $ | 77.4 |  |  | $ | (1.7) |  |
