# PANW MD&A — 0001327567-25-000017


## mdna

[0001327567-25-000017:mdna:1]
[same as prior period, unchanged from 0001327567-25-000010:mdna:1]

[0001327567-25-000017:mdna:2]
[same as prior period, unchanged from 0001327567-25-000010:mdna:2]

[0001327567-25-000017:mdna:3]
[same as prior period, unchanged from 0001327567-25-000010:mdna:3]

[0001327567-25-000017:mdna:4]
[same as prior period, unchanged from 0001327567-25-000010:mdna:4]

[0001327567-25-000017:mdna:5]
•Results of Operations. A discussion of the nature and trends in our financial results and an analysis of our financial results comparing the three and nine months ended April 30, 2025 to the three and nine months ended April 30, 2024.

[0001327567-25-000017:mdna:6]
[same as prior period, unchanged from 0001327567-25-000010:mdna:6]

[0001327567-25-000017:mdna:7]
[same as prior period, unchanged from 0001327567-25-000010:mdna:7]

[0001327567-25-000017:mdna:8]
[same as prior period, unchanged from 0001327567-25-000010:mdna:8]

[0001327567-25-000017:mdna:9]
[same as prior period, unchanged from 0001327567-25-000010:mdna:21]

[0001327567-25-000017:mdna:10]
[same as prior period, unchanged from 0001327567-25-000010:mdna:10]

[0001327567-25-000017:mdna:11]
[same as prior period, unchanged from 0001327567-25-000010:mdna:11]

[0001327567-25-000017:mdna:12]
[same as prior period, unchanged from 0001327567-25-000010:mdna:12]

[0001327567-25-000017:mdna:13]
•Our network security platform, designed to deliver complete zero trust solutions to our customers, includes our hardware and software ML-Powered Next-Generation Firewalls, Prisma AIRSTM, as well as a cloud-delivered Secure Access Service Edge (“SASE”). Prisma® Access, our Security Services Edge (“SSE”) solution, when combined with Prisma SD-WAN, provides a comprehensive single-vendor SASE offering that is used to secure remote workforces and securely enable the cloud-delivered branch. Prisma Access Browser extends SASE security and data protection to the end user device, giving workers complete device freedom to access business applications securely using a secure browser. Our network security platform also includes our cloud-delivered security services, such as Advanced Threat Prevention, Advanced WildFire®, Advanced URL Filtering, Advanced DNS Security, IoT/OT Security, GlobalProtect®, Enterprise Data Loss Prevention (“Enterprise DLP”), AI for IT Operations (“AIOps”), software as a service (“SaaS”) Security, and AI Access Security. Through these add-on security services, our customers are able to secure their content, applications, users, and devices across their entire organization. Prisma AIRS is a comprehensive AI security platform that protects customers’ AI ecosystem—AI apps, agents, models, and data—and aims to make it secure at every step. Strata Cloud Manager, our network security management solution, centrally manages our network security platform irrespective of form factor, location, or scale. Strata Cloud Manager includes Strata Copilot, which offers a natural language interface to simplify and strengthen network security, and Autonomous Digital Experience Monitoring.

[0001327567-25-000017:mdna:14]
Security Operations and Cloud Security:

[0001327567-25-000017:mdna:15]
Our AI-driven Cortex platform transforms end-to-end security operations with unified data, AI, and automation for more secure, faster, and cost effective outcomes. We have merged our industry-leading Security Operations and Cloud Security capabilities on a single comprehensive platform to provide centralized visibility, proactive protection, real-time prevention, AI-driven insights, and automated remediation across enterprise and cloud.

[0001327567-25-000017:mdna:16]
•Security Operations. We deliver the next generation of security operations capabilities that unifies standalone Security Information and Event Management (“SIEM”) tools, endpoint security, security automation, cloud detection and response (“CDR”), as well as attack surface management (“ASM”) capabilities on our Cortex platform. These include Cortex XSIAM®, for AI-driven security operations replacing traditional SIEM tools, Cortex XDR® for the prevention, detection, and response to complex cybersecurity attacks, Cortex XSOAR® for security orchestration, automation, and response (“SOAR”), and Cortex Xpanse® for ASM. These products are delivered as SaaS or software subscriptions.

[0001327567-25-000017:mdna:17]
•Cloud Security. We deliver comprehensive security across the cloud application development lifecycle through Cortex Cloud, the next generation of Prisma Cloud, delivered as a scalable SaaS offering. As a comprehensive Cloud Native Application Protection Platform (“CNAPP”) merged with CDR, Cortex Cloud secures multi- and hybrid-cloud environments for applications, data, generative AI (“GenAI”) ecosystem, and the cloud native technology stack across the full development lifecycle, from code to cloud to security operations. As part of the Cortex platform, customers can expand from Cortex Cloud to our security operations offerings available on a single user experience and unified agent. We also offer our VM-Series and CN-Series virtual firewalls for inline network security on multi- and hybrid-cloud environments.

[0001327567-25-000017:mdna:18]
[same as prior period, unchanged from 0001327567-25-000010:mdna:18]

[0001327567-25-000017:mdna:19]
•Unit 42® brings together world-renowned expertise across threat research, incident response, and security consulting to deliver intelligence-driven, response-ready outcomes that help customers reduce cyber risk. Our elite consultants serve as trusted advisors to our customers by assessing and testing their security controls against sophisticated threats, transforming their security strategy with a threat-informed approach, and responding to security incidents on behalf of our clients. Additionally, Unit 42 offers managed detection and response (“MDR”) and managed threat hunting services.

[0001327567-25-000017:mdna:20]
[same as prior period, unchanged from 0001327567-25-000010:mdna:30]

[0001327567-25-000017:mdna:21]
For the third quarter of fiscal 2025 and 2024, total revenue was $2.3 billion and $2.0 billion, respectively, representing year-over-year growth of 15.3%. Our growth reflects the increased adoption of our portfolio, which consists of product, subscriptions, and support. We believe our portfolio will enable us to benefit from recurring revenues and new revenues as we continue to grow our end-customer base. As of April 30, 2025, we had end-customers in over 180 countries. Our end-customers represent a broad range of industries, including education, energy, financial services, government entities, healthcare, Internet and media, manufacturing, public sector, and telecommunications, and include almost all of the Fortune 100 companies and a majority of the Global 2000 companies. We maintain a field sales force that works closely with our channel partners in developing sales opportunities. We primarily use a two-tiered, indirect fulfillment model whereby we sell our products, subscriptions, and support to our distributors, which, in turn, sell to our resellers, which then sell to our end-customers.

[0001327567-25-000017:mdna:22]
Our product revenue grew to $452.7 million, or 19.8% of total revenue, for the third quarter of fiscal 2025, representing year-over-year growth of 15.8%. Product revenue is derived from sales of our appliances, primarily our ML-Powered Next-Generation Firewall. Product revenue also includes revenue derived from software licenses of Panorama®, SD-WAN, and the VM-Series. Our ML-Powered Next-Generation Firewall incorporates our PAN-OS operating system, which provides a consistent set of capabilities across our entire network security product line. Our appliances and software licenses include a broad set of built-in networking and security features and functionalities. Our products are designed for different performance requirements throughout an organization, ranging from our PA-400 Series, which is designed for small organizations and remote or branch offices, to our top-of-the-line PA-7500, which is designed for large-scale data centers and service provider use. The same firewall functionality that is delivered in our physical appliances is also available in our VM-Series virtual firewalls, which secure virtualized and cloud-based computing environments, and in our CN-Series container firewalls, which secure container environments and traffic.

[0001327567-25-000017:mdna:23]
Our subscription and support revenue grew to $1.8 billion, or 80.2% of total revenue, for the third quarter of fiscal 2025, representing year-over-year growth of 15.2%. Our subscriptions provide our end-customers with near real-time access to the latest intrusion prevention, web security, modern malware prevention, data loss prevention, cloud access security broker and AI security capabilities across the network, endpoints, and the cloud. Our subscriptions also include security operations, which enable customers to leverage the AI-driven Cortex platform for advanced capabilities such as security information and event management, next-generation antivirus, endpoint detection and response, extended detection and response, identity threat detection and response, cloud detection and response, SOAR, ASM, and CNAPP for comprehensive cloud security. Additionally, we offer MDR for Cortex subscriptions, powered by Unit 42’s elite expertise. When customers purchase our physical, virtual, or container firewall appliances, or certain cloud offerings, they typically purchase support in order to receive ongoing security updates, upgrades, bug fixes, and repairs. In addition to the subscriptions purchased with these appliances, customers may also purchase other subscriptions on a per-user, per-endpoint, or capacity-based basis. We also offer professional services, including incident response, risk management, and digital forensic services.

[0001327567-25-000017:mdna:24]
We continue to invest in innovation as we evolve and further extend the capabilities of our portfolio, as we believe that innovation and timely development of new features and products are essential to meeting the needs of our end-customers and improving our competitive position. For example, in April 2025, we introduced several new offerings, including: Prisma AIRS, new SASE innovations such as Prisma Access Browser 2.0, and Cortex XSIAM 3.0. Additionally, we continue to make strategic investments that fit within our long-term strategy. For example, in April 2025, we entered into a definitive agreement to acquire Protect AI, Inc., a privately-held cyber security company (“Protect AI”), and we expect the acquisition will enhance the capabilities of our AI security platform. The acquisition of Protect AI is expected to close by the first quarter of fiscal 2026, subject to the satisfaction of closing conditions, including regulatory clearance.

[0001327567-25-000017:mdna:25]
[same as prior period, unchanged from 0001327567-25-000010:mdna:25]

[0001327567-25-000017:mdna:26]
[same as prior period, unchanged from 0001327567-25-000010:mdna:26]

[0001327567-25-000017:mdna:27]
Our overall performance depends in part on worldwide economic and geopolitical conditions and their impact on customer behavior. Changes in legislation or regulations and actions by regulators, including changes in enforcement and administration policies, may have an impact on our results of operations and financial condition. Significant changes in U.S. or global trade policy, including further expansion of U.S. export/imports controls and tariffs, as well as retaliatory actions by other countries, may materially and adversely affect our business. Further, worsening economic conditions, including inflation, high interest rates, slow growth, fluctuations in foreign exchange rates, supply chain disruptions, impacts of trade regulations or international trade disputes, and other conditions, may adversely affect our results of operations and financial performance.

[0001327567-25-000017:mdna:28]
[same as prior period, unchanged from 0001327567-25-000010:mdna:37]

[0001327567-25-000017:mdna:29]
[same as prior period, unchanged from 0001327567-25-000010:mdna:28]

[0001327567-25-000017:mdna:30]
[same as prior period, unchanged from 0001327567-25-000010:mdna:29]

[0001327567-25-000017:mdna:31]
[same as prior period, unchanged from 0001327567-25-000010:mdna:31]

[0001327567-25-000017:mdna:32]
[same as prior period, unchanged from 0001327567-25-000010:mdna:32]

[0001327567-25-000017:mdna:33]
|  | April 30, 2025 |  | July 31, 2024 |
|  | (in billions) |
| Next-Generation Security Annualized Recurring Revenue | $ | 5.1 |  |  | $ | 4.2 |  |
| Remaining performance obligations | $ | 13.5 |  |  | $ | 12.7 |  |

[0001327567-25-000017:mdna:34]
|  | Three Months Ended April 30, |  | Nine Months Ended April 30, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
|  | (dollars in millions) |
| Total revenue | $ | 2,289.0 |  |  | $ | 1,984.8 |  |  | $ | 6,685.2 |  |  | $ | 5,838.0 |  |
| Total revenue year-over-year percentage increase | 15.3 | % |  | 15.3 | % |  | 14.5 | % |  | 18.2 | % |
| Gross margin | 72.9 | % |  | 74.1 | % |  | 73.5 | % |  | 74.6 | % |
| Operating income | $ | 218.8 |  |  | $ | 176.7 |  |  | $ | 745.7 |  |  | $ | 445.5 |  |
| Operating margin | 9.6 | % |  | 8.9 | % |  | 11.2 | % |  | 7.6 | % |
| Cash flow provided by operating activities |  |  |  |  | $ | 2,695.2 |  |  | $ | 2,744.9 |  |
| Free cash flow (non-GAAP) |  |  |  |  | $ | 2,535.3 |  |  | $ | 2,635.5 |  |

[0001327567-25-000017:mdna:35]
•Next-Generation Security Annualized Recurring Revenue (“NGS ARR”). Our NGS ARR represents the annualized allocated revenue of all active contracts as of the final day of the reporting period for Prisma and Cortex offerings inclusive of the VM-Series and related services, and certain cloud-delivered security services. Beginning in the first quarter of fiscal 2025, NGS ARR includes revenue attributable to QRadar SaaS contracts. NGS ARR is an operating metric that we use to assess the strength and trajectory of our business. NGS ARR should be viewed independently of revenue, deferred revenue and remaining performance obligations and does not represent our revenue under U.S. GAAP on an annualized basis, as it is an operating metric that can be impacted by contract start and end dates and renewal rates. NGS ARR is not intended to be a replacement for forecasts of revenue.

[0001327567-25-000017:mdna:36]
[same as prior period, unchanged from 0001327567-25-000010:mdna:36]

[0001327567-25-000017:mdna:37]
[same as prior period, unchanged from 0001327567-25-000010:mdna:40]

[0001327567-25-000017:mdna:38]
[same as prior period, unchanged from 0001327567-25-000010:mdna:38]

[0001327567-25-000017:mdna:39]
|  | Nine Months Ended April 30, |
|  | 2025 |  | 2024 |
|  | (in millions) |
| Free cash flow (non-GAAP): |  |  |  |
| Net cash provided by operating activities | $ | 2,695.2 |  |  | $ | 2,744.9 |  |
| Less: purchases of property, equipment, and other assets | 159.9 |  |  | 109.4 |  |
| Free cash flow (non-GAAP) | $ | 2,535.3 |  |  | $ | 2,635.5 |  |
| Net cash used in investing activities | $ | (1,442.2) |  |  | $ | (1,341.4) |  |
| Net cash used in financing activities | $ | (404.8) |  |  | $ | (1,163.8) |  |

[0001327567-25-000017:mdna:40]
[same as prior period, unchanged from 0001327567-25-000010:mdna:46]

[0001327567-25-000017:mdna:41]
[same as prior period, unchanged from 0001327567-25-000010:mdna:41]

[0001327567-25-000017:mdna:42]
[same as prior period, unchanged from 0001327567-25-000010:mdna:42]

[0001327567-25-000017:mdna:43]
|  | Three Months Ended April 30, |  | Nine Months Ended April 30, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
|  | Amount |  | % of Revenue |  | Amount |  | % of Revenue |  | Amount |  | % of Revenue |  | Amount |  | % of Revenue |
|  | (dollars in millions) |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 452.7 |  |  | 19.8 | % |  | $ | 391.0 |  |  | 19.7 | % |  | $ | 1,228.0 |  |  | 18.4 | % |  | $ | 1,122.8 |  |  | 19.2 | % |
| Subscription and support | 1,836.3 |  |  | 80.2 | % |  | 1,593.8 |  |  | 80.3 | % |  | 5,457.2 |  |  | 81.6 | % |  | 4,715.2 |  |  | 80.8 | % |
| Total revenue | 2,289.0 |  |  | 100.0 | % |  | 1,984.8 |  |  | 100.0 | % |  | 6,685.2 |  |  | 100.0 | % |  | 5,838.0 |  |  | 100.0 | % |
| Cost of revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product | 100.7 |  |  | 4.4 | % |  | 77.9 |  |  | 3.9 | % |  | 277.0 |  |  | 4.1 | % |  | 243.5 |  |  | 4.2 | % |
| Subscription and support | 518.6 |  |  | 22.7 | % |  | 435.7 |  |  | 22.0 | % |  | 1,495.6 |  |  | 22.4 | % |  | 1,242.0 |  |  | 21.2 | % |
| Total cost of revenue(1) | 619.3 |  |  | 27.1 | % |  | 513.6 |  |  | 25.9 | % |  | 1,772.6 |  |  | 26.5 | % |  | 1,485.5 |  |  | 25.4 | % |
| Total gross profit | 1,669.7 |  |  | 72.9 | % |  | 1,471.2 |  |  | 74.1 | % |  | 4,912.6 |  |  | 73.5 | % |  | 4,352.5 |  |  | 74.6 | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | 494.5 |  |  | 21.6 | % |  | 457.2 |  |  | 23.0 | % |  | 1,480.6 |  |  | 22.1 | % |  | 1,314.6 |  |  | 22.5 | % |
| Sales and marketing | 792.5 |  |  | 34.5 | % |  | 718.7 |  |  | 36.2 | % |  | 2,270.9 |  |  | 34.0 | % |  | 2,052.2 |  |  | 35.2 | % |
| General and administrative | 163.9 |  |  | 7.2 | % |  | 118.6 |  |  | 6.0 | % |  | 415.4 |  |  | 6.2 | % |  | 540.2 |  |  | 9.3 | % |
| Total operating expenses(1) | 1,450.9 |  |  | 63.3 | % |  | 1,294.5 |  |  | 65.2 | % |  | 4,166.9 |  |  | 62.3 | % |  | 3,907.0 |  |  | 67.0 | % |
| Operating income | 218.8 |  |  | 9.6 | % |  | 176.7 |  |  | 8.9 | % |  | 745.7 |  |  | 11.2 | % |  | 445.5 |  |  | 7.6 | % |
| Interest expense | (0.7) |  |  | — | % |  | (2.3) |  |  | (0.1) | % |  | (2.8) |  |  | — | % |  | (8.0) |  |  | (0.1) | % |
| Other income, net | 92.4 |  |  | 4.0 | % |  | 76.8 |  |  | 3.9 | % |  | 261.0 |  |  | 3.8 | % |  | 231.8 |  |  | 4.0 | % |
| Income before income taxes | 310.5 |  |  | 13.6 | % |  | 251.2 |  |  | 12.7 | % |  | 1,003.9 |  |  | 15.0 | % |  | 669.3 |  |  | 11.5 | % |
| Provision for (benefit from) income taxes | 48.4 |  |  | 2.1 | % |  | (27.6) |  |  | (1.3) | % |  | 123.8 |  |  | 1.8 | % |  | (1,550.6) |  |  | (26.5) | % |
| Net income | $ | 262.1 |  |  | 11.5 | % |  | $ | 278.8 |  |  | 14.0 | % |  | $ | 880.1 |  |  | 13.2 | % |  | $ | 2,219.9 |  |  | 38.0 | % |

[0001327567-25-000017:mdna:44]
[same as prior period, unchanged from 0001327567-25-000010:mdna:44]

[0001327567-25-000017:mdna:45]
|  | Three Months Ended April 30, |  | Nine Months Ended April 30, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
|  | (in millions) |
| Cost of product revenue | $ | 1.2 |  |  | $ | 1.6 |  |  | $ | 3.8 |  |  | $ | 6.3 |  |
| Cost of subscription and support revenue | 32.2 |  |  | 30.0 |  |  | 94.9 |  |  | 91.3 |  |
| Research and development | 133.4 |  |  | 128.2 |  |  | 410.8 |  |  | 386.9 |  |
| Sales and marketing | 91.6 |  |  | 74.3 |  |  | 258.2 |  |  | 229.1 |  |
| General and administrative | 67.5 |  |  | 29.4 |  |  | 173.0 |  |  | 96.2 |  |
| Total share-based compensation | $ | 325.9 |  |  | $ | 263.5 |  |  | $ | 940.7 |  |  | $ | 809.8 |  |

[0001327567-25-000017:mdna:46]
[same as prior period, unchanged from 0001327567-25-000010:mdna:57]

[0001327567-25-000017:mdna:47]
[same as prior period, unchanged from 0001327567-25-000010:mdna:47]

[0001327567-25-000017:mdna:48]
[same as prior period, unchanged from 0001327567-25-000010:mdna:48]

[0001327567-25-000017:mdna:49]
[same as prior period, unchanged from 0001327567-25-000010:mdna:49]

[0001327567-25-000017:mdna:50]
[same as prior period, unchanged from 0001327567-25-000010:mdna:50]

[0001327567-25-000017:mdna:51]
|  | Three Months Ended April 30, |  |  |  |  |  | Nine Months Ended April 30, |  |  |  |  |
|  | 2025 |  | 2024 |  | Change |  | 2025 |  | 2024 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Product | $ | 452.7 |  |  | $ | 391.0 |  |  | $ | 61.7 |  |  | 15.8 | % |  | $ | 1,228.0 |  |  | $ | 1,122.8 |  |  | $ | 105.2 |  |  | 9.4 | % |

[0001327567-25-000017:mdna:52]
Product revenue increased for the three and nine months ended April 30, 2025 compared to the same periods in 2024 driven by increased demand for our new generation of hardware products and accessories, and an increase in price of and allocation to on-premise software licenses due to enhanced features and capabilities beginning in the second quarter of fiscal 2025, partially offset by decreased demand for our prior generation of hardware products.

[0001327567-25-000017:mdna:53]
[same as prior period, unchanged from 0001327567-25-000010:mdna:53]

[0001327567-25-000017:mdna:54]
[same as prior period, unchanged from 0001327567-25-000010:mdna:54]

[0001327567-25-000017:mdna:55]
|  | Three Months Ended April 30, |  |  |  |  |  | Nine Months Ended April 30, |  |  |  |  |
|  | 2025 |  | 2024 |  | Change |  | 2025 |  | 2024 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Subscription | $ | 1,234.4 |  |  | $ | 1,045.6 |  |  | $ | 188.8 |  |  | 18.1 | % |  | $ | 3,659.4 |  |  | $ | 3,061.0 |  |  | $ | 598.4 |  |  | 19.5 | % |
| Support | 601.9 |  |  | 548.2 |  |  | 53.7 |  |  | 9.8 | % |  | 1,797.8 |  |  | 1,654.2 |  |  | 143.6 |  |  | 8.7 | % |
| Total subscription and support | $ | 1,836.3 |  |  | $ | 1,593.8 |  |  | $ | 242.5 |  |  | 15.2 | % |  | $ | 5,457.2 |  |  | $ | 4,715.2 |  |  | $ | 742.0 |  |  | 15.7 | % |

[0001327567-25-000017:mdna:56]
Subscription and support revenue increased for the three and nine months ended April 30, 2025 compared to the same periods in 2024 primarily due to increased demand for our subscription and support offerings from our end-customers. The mix between subscription revenue and support revenue will fluctuate over time, depending on the introduction of new subscription offerings, renewals of support services, and our ability to increase sales to new and existing end-customers.

[0001327567-25-000017:mdna:57]
[same as prior period, unchanged from 0001327567-25-000010:mdna:67]

[0001327567-25-000017:mdna:58]
[same as prior period, unchanged from 0001327567-25-000010:mdna:58]

[0001327567-25-000017:mdna:59]
|  | Three Months Ended April 30, |  |  |  |  |  | Nine Months Ended April 30, |  |  |  |  |
|  | 2025 |  | 2024 |  | Change |  | 2025 |  | 2024 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Americas | $ | 1,529.2 |  |  | $ | 1,359.6 |  |  | $ | 169.6 |  |  | 12.5 | % |  | $ | 4,473.7 |  |  | $ | 3,980.4 |  |  | $ | 493.3 |  |  | 12.4 | % |
| Europe, the Middle East, and Africa (“EMEA”) | 480.9 |  |  | 399.2 |  |  | 81.7 |  |  | 20.5 | % |  | 1,402.3 |  |  | 1,170.9 |  |  | 231.4 |  |  | 19.8 | % |
| Asia Pacific and Japan (“APAC”) | 278.9 |  |  | 226.0 |  |  | 52.9 |  |  | 23.4 | % |  | 809.2 |  |  | 686.7 |  |  | 122.5 |  |  | 17.8 | % |
| Total revenue | $ | 2,289.0 |  |  | $ | 1,984.8 |  |  | $ | 304.2 |  |  | 15.3 | % |  | $ | 6,685.2 |  |  | $ | 5,838.0 |  |  | $ | 847.2 |  |  | 14.5 | % |

[0001327567-25-000017:mdna:60]
Revenue from the Americas, EMEA, and APAC increased for the three and nine months ended April 30, 2025 compared to the same periods in 2024 as we continued to increase investment in our global sales force in order to support our growth and innovation, with the Americas contributing the highest increase in revenue due to its larger scale.

[0001327567-25-000017:mdna:61]
[same as prior period, unchanged from 0001327567-25-000010:mdna:61]

[0001327567-25-000017:mdna:62]
[same as prior period, unchanged from 0001327567-25-000010:mdna:62]

[0001327567-25-000017:mdna:63]
[same as prior period, unchanged from 0001327567-25-000010:mdna:63]

[0001327567-25-000017:mdna:64]
[same as prior period, unchanged from 0001327567-25-000010:mdna:64]

[0001327567-25-000017:mdna:65]
|  | Three Months Ended April 30, |  |  |  |  |  | Nine Months Ended April 30, |  |  |  |  |
|  | 2025 |  | 2024 |  | Change |  | 2025 |  | 2024 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Cost of product revenue | $ | 100.7 |  |  | $ | 77.9 |  |  | $ | 22.8 |  |  | 29.3 | % |  | $ | 277.0 |  |  | $ | 243.5 |  |  | $ | 33.5 |  |  | 13.8 | % |

[0001327567-25-000017:mdna:66]
Cost of product revenue increased for the three and nine months ended April 30, 2025 compared to the same periods in 2024 primarily due to increased demand for our new generation hardware products and an increase in inventory reserves. The increase in cost of product revenue for the nine months ended April 30, 2025 was partially offset by increasing benefits from manufacturing in a foreign trade zone established in July 2024.

[0001327567-25-000017:mdna:67]
[same as prior period, unchanged from 0001327567-25-000010:mdna:77]

[0001327567-25-000017:mdna:68]
[same as prior period, unchanged from 0001327567-25-000010:mdna:68]

[0001327567-25-000017:mdna:69]
[same as prior period, unchanged from 0001327567-25-000010:mdna:69]

[0001327567-25-000017:mdna:70]
|  | Three Months Ended April 30, |  |  |  |  |  | Nine Months Ended April 30, |  |  |  |  |
|  | 2025 |  | 2024 |  | Change |  | 2025 |  | 2024 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Cost of subscription and support revenue | $ | 518.6 |  |  | $ | 435.7 |  |  | $ | 82.9 |  |  | 19.0 | % |  | $ | 1,495.6 |  |  | $ | 1,242.0 |  |  | $ | 253.6 |  |  | 20.4 | % |

[0001327567-25-000017:mdna:71]
Cost of subscription and support revenue increased for the three and nine months ended April 30, 2025 compared to the same periods in 2024 primarily due to increased costs to support the growth of our subscription and support offerings. Cloud hosting service costs, which support our cloud-based subscription offerings, increased $55.7 million and $141.4 million for the three and nine months ended April 30, 2025, respectively, compared to the same periods in 2024. Personnel costs grew $14.0 million and $39.8 million for the three and nine months ended April 30, 2025, respectively, compared to the same periods in 2024, primarily due to headcount growth. The increase in cost of subscription and support revenue in both periods was further driven by increased professional services expense.

[0001327567-25-000017:mdna:72]
[same as prior period, unchanged from 0001327567-25-000010:mdna:72]

[0001327567-25-000017:mdna:73]
[same as prior period, unchanged from 0001327567-25-000010:mdna:73]

[0001327567-25-000017:mdna:74]
|  | Three Months Ended April 30, |  | Nine Months Ended April 30, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
|  | Amount |  | Gross Margin |  | Amount |  | Gross Margin |  | Amount |  | Gross Margin |  | Amount |  | Gross Margin |
|  | (dollars in millions) |
| Product | $ | 352.0 |  |  | 77.8 | % |  | $ | 313.1 |  |  | 80.1 | % |  | $ | 951.0 |  |  | 77.4 | % |  | $ | 879.3 |  |  | 78.3 | % |
| Subscription and support | 1,317.7 |  |  | 71.8 | % |  | 1,158.1 |  |  | 72.7 | % |  | 3,961.6 |  |  | 72.6 | % |  | 3,473.2 |  |  | 73.7 | % |
| Total gross profit | $ | 1,669.7 |  |  | 72.9 | % |  | $ | 1,471.2 |  |  | 74.1 | % |  | $ | 4,912.6 |  |  | 73.5 | % |  | $ | 4,352.5 |  |  | 74.6 | % |

[0001327567-25-000017:mdna:75]
Product gross margin decreased for the three and nine months ended April 30, 2025 compared to the same periods in 2024 primarily due to an increase in inventory reserves. The decrease in product gross margin for the nine months ended April 30, 2025 was partially offset by increasing benefits from manufacturing in a foreign trade zone established in July 2024.

[0001327567-25-000017:mdna:76]
Subscription and support gross margin decreased for the three and nine months ended April 30, 2025 compared to the same periods in 2024 primarily due to an increase in costs related to our cloud-based offerings, partially offset by increased leverage of our global customer service organization.

[0001327567-25-000017:mdna:77]
[same as prior period, unchanged from 0001327567-25-000010:mdna:88]

[0001327567-25-000017:mdna:78]
[same as prior period, unchanged from 0001327567-25-000010:mdna:78]

[0001327567-25-000017:mdna:79]
Our operating expenses consist of research and development, sales and marketing, and general and administrative expenses. Personnel costs are the most significant component of operating expenses and consist of salaries, benefits, bonuses, share-based compensation, travel and entertainment, and with regard to sales and marketing expense, sales commissions. Our operating expenses also include shared costs, which consist of certain facilities, depreciation, benefits, recruiting, and information technology costs that we allocate based on headcount to each department. We expect operating expenses generally to increase in absolute dollars and to decrease over the long term as a percentage of revenue as we continue to scale our business. As of April 30, 2025, we expect to recognize approximately $2.4 billion of share-based compensation expense over a weighted-average period of approximately 2.5 years, excluding additional share-based compensation expense related to any future grants of share-based awards. Share-based compensation expense is generally recognized on a straight-line basis over the requisite service periods of the awards.

[0001327567-25-000017:mdna:80]
[same as prior period, unchanged from 0001327567-25-000010:mdna:80]

[0001327567-25-000017:mdna:81]
[same as prior period, unchanged from 0001327567-25-000010:mdna:81]

[0001327567-25-000017:mdna:82]
|  | Three Months Ended April 30, |  |  |  |  |  | Nine Months Ended April 30, |  |  |  |  |
|  | 2025 |  | 2024 |  | Change |  | 2025 |  | 2024 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Research and development | $ | 494.5 |  |  | $ | 457.2 |  |  | $ | 37.3 |  |  | 8.2 | % |  | $ | 1,480.6 |  |  | $ | 1,314.6 |  |  | $ | 166.0 |  |  | 12.6 | % |

[0001327567-25-000017:mdna:83]
Research and development expense increased for the three and nine months ended April 30, 2025 compared to the same periods in 2024 primarily due to increased personnel costs, which grew $22.1 million and $109.2 million for the three and nine months ended April 30, 2025, respectively, compared to the same periods in 2024, largely due to headcount growth. The increase in research and development expense in both periods was further driven by increased shared costs.

[0001327567-25-000017:mdna:84]
[same as prior period, unchanged from 0001327567-25-000010:mdna:84]

[0001327567-25-000017:mdna:85]
[same as prior period, unchanged from 0001327567-25-000010:mdna:85]

[0001327567-25-000017:mdna:86]
|  | Three Months Ended April 30, |  |  |  |  |  | Nine Months Ended April 30, |  |  |  |  |
|  | 2025 |  | 2024 |  | Change |  | 2025 |  | 2024 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Sales and marketing | $ | 792.5 |  |  | $ | 718.7 |  |  | $ | 73.8 |  |  | 10.3 | % |  | $ | 2,270.9 |  |  | $ | 2,052.2 |  |  | $ | 218.7 |  |  | 10.7 | % |

[0001327567-25-000017:mdna:87]
Sales and marketing expense increased for the three and nine months ended April 30, 2025 compared to the same periods in 2024 primarily due to increased personnel costs, which grew $60.6 million and $183.3 million for the three and nine months ended April 30, 2025, respectively, compared to the same periods in 2024, largely due to headcount growth.

[0001327567-25-000017:mdna:88]
[same as prior period, unchanged from 0001327567-25-000010:mdna:101]

[0001327567-25-000017:mdna:89]
[same as prior period, unchanged from 0001327567-25-000010:mdna:89]

[0001327567-25-000017:mdna:90]
[same as prior period, unchanged from 0001327567-25-000010:mdna:90]

[0001327567-25-000017:mdna:91]
|  | Three Months Ended April 30, |  |  |  |  |  | Nine Months Ended April 30, |  |  |  |  |
|  | 2025 |  | 2024 |  | Change |  | 2025 |  | 2024 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| General and administrative | $ | 163.9 |  |  | $ | 118.6 |  |  | $ | 45.3 |  |  | 38.2 | % |  | $ | 415.4 |  |  | $ | 540.2 |  |  | $ | (124.8) |  |  | (23.1) | % |

[0001327567-25-000017:mdna:92]
General and administrative expense increased for the three months ended April 30, 2025 compared to the same period in 2024 primarily due to increased personnel costs, which grew $44.8 million, largely due to increased share-based compensation. General and administrative expense decreased for the nine months ended April 30, 2025 compared to the same period in 2024 primarily due to a litigation-related accrual of $176.8 million during the three months ended January 31, 2024 and a partial release of $43.0 million during the three months ended October 31, 2024. The decrease in general and administrative expense for the nine months ended April 30, 2025 was partially offset by increased personnel costs, which grew $92.6 million, largely due to increased share-based compensation.

[0001327567-25-000017:mdna:93]
[same as prior period, unchanged from 0001327567-25-000010:mdna:93]

[0001327567-25-000017:mdna:94]
Interest expense primarily consists of interest expense related to our 0.375% Convertible Senior Notes due 2025 (the “2025 Notes”).

[0001327567-25-000017:mdna:95]
|  | Three Months Ended April 30, |  |  |  | Nine Months Ended April 30, |  |  |
|  | 2025 |  | 2024 |  | Change |  | 2025 |  | 2024 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Interest expense | $ | 0.7 |  |  | $ | 2.3 |  |  | $ | (1.6) |  |  | (69.6) | % |  | $ | 2.8 |  |  | $ | 8.0 |  |  | $ | (5.2) |  |  | (65.0) | % |

[0001327567-25-000017:mdna:96]
Interest expense decreased for the three and nine months ended April 30, 2025 compared to the same periods in 2024 primarily due to early conversions of our 2025 Notes. Refer to Note 9. Debt in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information on the Notes.

[0001327567-25-000017:mdna:97]
[same as prior period, unchanged from 0001327567-25-000010:mdna:97]

[0001327567-25-000017:mdna:98]
[same as prior period, unchanged from 0001327567-25-000010:mdna:98]

[0001327567-25-000017:mdna:99]
|  | Three Months Ended April 30, |  |  |  | Nine Months Ended April 30, |  |  |
|  | 2025 |  | 2024 |  | Change |  | 2025 |  | 2024 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Other income, net | $ | 92.4 |  |  | $ | 76.8 |  |  | $ | 15.6 |  |  | 20.3 | % |  | $ | 261.0 |  |  | $ | 231.8 |  |  | $ | 29.2 |  |  | 12.6 | % |

[0001327567-25-000017:mdna:100]
Other income, net increased for the three and nine months ended April 30, 2025 compared to the same periods in 2024 primarily due to higher interest income as a result of higher average cash, cash equivalent, and investment balances for the three and nine months ended April 30, 2025 compared to the same periods in 2024. The increase was further driven by increased gains from our non-designated derivative instruments and investments, partially offset by increased foreign currency exchange losses for the three and nine months ended April 30, 2025 compared to the same periods in 2024.

[0001327567-25-000017:mdna:101]
[same as prior period, unchanged from 0001327567-25-000010:mdna:110]

[0001327567-25-000017:mdna:102]
[same as prior period, unchanged from 0001327567-25-000010:mdna:102]

[0001327567-25-000017:mdna:103]
Provision for (benefit from) income taxes consists primarily of U.S. and foreign income taxes. Our effective tax rates during the three and nine months ended April 30, 2025 were lower than our statutory tax rate primarily due to excess tax benefits from share-based compensation. We regularly assess the need for a valuation allowance on our deferred tax assets. In making this assessment, we consider both positive and negative evidence related to the likelihood of realization of the deferred tax assets to determine, based on the weight of available evidence, whether it is more likely than not that some or all the deferred tax assets will not be realized. The assessment requires significant judgment and is performed for each of the applicable jurisdictions. Based on our analysis of all positive and negative evidence during the fiscal quarter ended April 30, 2025, we continue to maintain a valuation allowance for our California deferred tax assets due to the uncertainty regarding realizability of these deferred tax assets as they have not met the “more likely than not” realization criterion. We expect future research and development tax credit generation in California to exceed our ability to use the existing tax credits.

[0001327567-25-000017:mdna:104]
|  | Three Months Ended April 30, |  |  |  |  |  | Nine Months Ended April 30, |  |  |  |  |
|  | 2025 |  | 2024 |  | Change |  | 2025 |  | 2024 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Provision for (benefit from) income taxes | $ | 48.4 |  |  | $ | (27.6) |  |  | $ | 76.0 |  |  | (275.4) | % |  | $ | 123.8 |  |  | $ | (1,550.6) |  |  | $ | 1,674.4 |  |  | (108.0) | % |
| Effective tax rate | 15.6 | % |  | (11.0) | % |  |  |  |  |  | 12.3 | % |  | (231.7) | % |  |  |  |  |

[0001327567-25-000017:mdna:105]
Our provision for income taxes for the three and nine months ended April 30, 2025 was primarily due to U.S. and foreign income taxes. Our effective tax rate increased for the three and nine months ended April 30, 2025 compared to the same periods in 2024 primarily due to the release of our valuation allowance on U.S. federal, U.S. states other than California, and United Kingdom deferred tax assets in the second quarter of fiscal 2024. Refer to Note 13. Income Taxes in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information.

[0001327567-25-000017:mdna:106]
[same as prior period, unchanged from 0001327567-25-000010:mdna:106]

[0001327567-25-000017:mdna:107]
|  | April 30, 2025 |  | July 31, 2024 |
|  | (in millions) |
| Working capital (deficit) | $ | (806.6) |  |  | $ | (833.0) |  |
| Cash, cash equivalents, and investments: |  |  |  |
| Cash and cash equivalents | $ | 2,383.4 |  |  | $ | 1,535.2 |  |
| Investments | 6,069.1 |  |  | 5,216.8 |  |
| Total cash, cash equivalents, and investments | $ | 8,452.5 |  |  | $ | 6,752.0 |  |

[0001327567-25-000017:mdna:108]
As of April 30, 2025, our total cash, cash equivalents, and investments of $8.5 billion were held for general corporate purposes. As of April 30, 2025, we had no unremitted earnings when evaluating our outside basis difference relating to our U.S. investment in foreign subsidiaries. However, there could be local withholding taxes due to various foreign countries if certain lower tier earnings are distributed. Withholding taxes that would be payable upon remittance of these lower tier earnings are not material.

[0001327567-25-000017:mdna:109]
[same as prior period, unchanged from 0001327567-25-000010:mdna:109]

[0001327567-25-000017:mdna:110]
[same as prior period, unchanged from 0001327567-25-000010:mdna:111]

[0001327567-25-000017:mdna:111]
In June 2020, we issued the 2025 Notes with an aggregate principal amount of $2.0 billion. The 2025 Notes mature on June 1, 2025; however, under certain circumstances, holders may surrender their 2025 Notes for conversion prior to the maturity date. Upon conversion of the 2025 Notes, we will pay cash equal to the aggregate principal amount of the 2025 Notes to be converted, and, at our election, we will pay or deliver cash and/or shares of our common stock for the amount of our conversion obligation in excess of the aggregate principal amount of the 2025 Notes being converted. During the three and nine months ended April 30, 2025, we repaid in cash $150.9 million and $582.3 million, respectively, in aggregate principal amount of the 2025 Notes and issued 2.2 million and 8.4 million shares of common stock to the holders, respectively, for the conversion value in excess of the principal amount of the 2025 Notes converted, which were fully offset by shares we received from our exercise of the associated note hedges.

[0001327567-25-000017:mdna:112]
[same as prior period, unchanged from 0001327567-25-000010:mdna:121]

[0001327567-25-000017:mdna:113]
All of the outstanding 2025 Notes will mature on June 1, 2025 and, at that time, we will become obligated to pay the remaining principal amount of the 2025 Notes of $383.3 million in cash, and deliver shares of our common stock for the amount of our conversion obligation in excess of the aggregate principal amount of the 2025 Notes being converted. We believe that our cash provided by operating activities, our existing cash, cash equivalents, and investments, and existing sources of and access to financing will be sufficient to meet our anticipated cash needs in connection with maturity of the 2025 Notes. As of April 30, 2025, $383.3 million of our 2025 Notes remained outstanding. Refer to Note 9. Debt in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information on the 2025 Notes.

[0001327567-25-000017:mdna:114]
In April 2023, we entered into a credit agreement (the “Credit Agreement”) that provides for a $400.0 million unsecured revolving credit facility (the “Credit Facility”), with an option to increase the amount of the Credit Facility by up to an additional $350.0 million, subject to certain conditions. The interest rates and commitment fees are also subject to upward and downward adjustments based on our progress towards the achievement of certain sustainability goals related to greenhouse gas emissions. As of April 30, 2025, there were no amounts outstanding, and we were in compliance with all covenants under the Credit Agreement. Refer to Note 9. Debt in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information on the Credit Agreement.

[0001327567-25-000017:mdna:115]
[same as prior period, unchanged from 0001327567-25-000010:mdna:115]

[0001327567-25-000017:mdna:116]
In February 2019, our board of directors authorized a $1.0 billion share repurchase program. In December 2020, August 2021, August 2022, November 2023, and August 2024, our board of directors authorized additional $700.0 million, $676.1 million, $915.0 million, $316.7 million and $500.0 million increases to this share repurchase program, respectively, bringing the total authorization under this share repurchase program to $4.1 billion. Repurchases will be funded from available working capital and may be made at management’s discretion from time to time. As of April 30, 2025, $1.0 billion remained available for future share repurchases under this repurchase program. The repurchase authorization will expire on December 31, 2025, and may be suspended or discontinued at any time without prior notice. Refer to Note 11. Stockholders’ Equity in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information on this repurchase program.

[0001327567-25-000017:mdna:117]
[same as prior period, unchanged from 0001327567-25-000010:mdna:117]

[0001327567-25-000017:mdna:118]
We have entered into various non-cancelable operating leases, primarily for our offices and data centers, with lease terms expiring through fiscal 2036. As of April 30, 2025, we have total operating lease obligations of $422.8 million recorded on our condensed consolidated balance sheet.

[0001327567-25-000017:mdna:119]
As of April 30, 2025, our commitments to purchase products, components, cloud and other services totaled $4.3 billion. Refer to Note 10. Commitments and Contingencies in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information on these commitments.

[0001327567-25-000017:mdna:120]
Our acquisition of certain QRadar assets from International Business Machines Corporation (“IBM”) on August 31, 2024 included contingent consideration that requires potential future payments through the fiscal quarter ending October 2028. As of April 30, 2025, we have total contingent consideration obligations of $669.2 million recorded on our condensed consolidated balance sheet. Refer to Note 3. Fair Value Measurements and Note 7. Acquisition in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information on these contingent consideration obligations.

[0001327567-25-000017:mdna:121]
[same as prior period, unchanged from 0001327567-25-000010:mdna:122]

[0001327567-25-000017:mdna:122]
The following table summarizes our cash flows for the nine months ended April 30, 2025 and 2024:

[0001327567-25-000017:mdna:123]
|  | Nine Months Ended April 30, |
|  | 2025 |  | 2024 |
|  | (in millions) |
| Net cash provided by operating activities | $ | 2,695.2 |  |  | $ | 2,744.9 |  |
| Net cash used in investing activities | (1,442.2) |  |  | (1,341.4) |  |
| Net cash used in financing activities | (404.8) |  |  | (1,163.8) |  |
| Net increase in cash, cash equivalents, and restricted cash | $ | 848.2 |  |  | $ | 239.7 |  |

[0001327567-25-000017:mdna:124]
[same as prior period, unchanged from 0001327567-25-000010:mdna:136]

[0001327567-25-000017:mdna:125]
[same as prior period, unchanged from 0001327567-25-000010:mdna:125]

[0001327567-25-000017:mdna:126]
[same as prior period, unchanged from 0001327567-25-000010:mdna:126]

[0001327567-25-000017:mdna:127]
[same as prior period, unchanged from 0001327567-25-000010:mdna:127]

[0001327567-25-000017:mdna:128]
Our operating activities have consisted of net income adjusted for certain non-cash items and changes in assets and liabilities. Our largest source of cash provided by our operations is receipts from our customers. Net cash provided by operating activities can be impacted by factors such as timing of payments and collections, vendor payment terms, and timing and amount of tax payments.

[0001327567-25-000017:mdna:129]
Cash provided by operating activities during the nine months ended April 30, 2025 was $2.7 billion, a slight decrease of $49.7 million compared to the same period in 2024. The decrease was primarily due to higher payments of cash expenditure to support our business growth, partially offset by an increase in receipts from our customers during the nine months ended April 30, 2025. Cash provided by operating activities during the nine months ended April 30, 2025 also includes proceeds from the sale of $30.4 million of our financing receivables based upon our financing credit risk management policy.

[0001327567-25-000017:mdna:130]
[same as prior period, unchanged from 0001327567-25-000010:mdna:130]

[0001327567-25-000017:mdna:131]
[same as prior period, unchanged from 0001327567-25-000010:mdna:131]

[0001327567-25-000017:mdna:132]
Cash used in investing activities during the nine months ended April 30, 2025 was $1.4 billion, an increase of $100.8 million compared to the same period in 2024. The increase was primarily due to higher purchases of investments, partially offset by higher proceeds from sales and maturities of investments and a decrease in net cash payments for business acquisitions during the nine months ended April 30, 2025.

[0001327567-25-000017:mdna:133]
[same as prior period, unchanged from 0001327567-25-000010:mdna:133]

[0001327567-25-000017:mdna:134]
[same as prior period, unchanged from 0001327567-25-000010:mdna:134]

[0001327567-25-000017:mdna:135]
Cash used in financing activities during the nine months ended April 30, 2025 was $404.8 million, a decrease of $759.0 million compared to the same period in 2024. The decrease was primarily due to a decrease in cash used to repurchase our common stock which did not recur during the nine months ended April 30, 2025 and a decrease in cash used for repayments of the early conversion of our 2025 Notes during the period.

[0001327567-25-000017:mdna:136]
[same as prior period, unchanged from 0001327567-25-000010:mdna:137]

[0001327567-25-000017:mdna:137]
[same as prior period, unchanged from 0001327567-25-000010:mdna:138]

[0001327567-25-000017:mdna:138]
- 37 -

[0001327567-25-000017:mdna:139]
[same as prior period, unchanged from 0001327567-25-000010:mdna:139]

[0001327567-25-000017:mdna:140]
[same as prior period, unchanged from 0001327567-25-000010:mdna:140]

[0001327567-25-000017:mdna:141]
[same as prior period, unchanged from 0001327567-25-000010:mdna:141]

[0001327567-25-000017:mdna:142]
[same as prior period, unchanged from 0001327567-25-000010:mdna:142]

[0001327567-25-000017:mdna:143]
[same as prior period, unchanged from 0001327567-25-000010:mdna:143]

[0001327567-25-000017:mdna:144]
Refer to “Recently Issued Accounting Pronouncements” in Note 1. Description of Business and Summary of Significant Accounting Policies in Part I, Item 1 of this Quarterly Report on Form 10-Q for a description of recent accounting pronouncements and our expectation of their impact, if any, on our results of operations and financial condition.
