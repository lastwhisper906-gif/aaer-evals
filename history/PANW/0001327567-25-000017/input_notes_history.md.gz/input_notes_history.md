# PANW note change history — 0001327567-25-000010 → 0001327567-25-000017


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2025-05-21):
[0001327567-25-000017:note_history:1]
We have entered into various non-cancelable agreements with cloud service providers, under which we are committed to minimum or fixed purchases of certain cloud services. In addition, in order to reduce manufacturing lead times and plan for adequate supply, we have entered into agreements with manufacturing partners and component suppliers to procure inventory based on our demand forecasts. Other purchase obligations include non-cancellable subscription agreements and other commitments in the normal course of business. The following table presents details of the aggregate future non-cancelable purchase commitments under these agreements as of April 30, 2025 (in millions):
  (was, 2025-02-14, similarity 0.7076):
[0001327567-25-000010:note_history:1]
We have entered into various non-cancelable agreements with cloud service providers, under which we are committed to minimum or fixed purchases of certain cloud services. In addition, in order to reduce manufacturing lead times and plan for adequate supply, we have entered into agreements with manufacturing partners and component suppliers to procure inventory based on our demand forecasts. The following table presents details of the aggregate future non-cancelable purchase commitments under these agreements as of January 31, 2025 (in millions):

- changed (2025-05-21):
[0001327567-25-000017:note_history:2]
As of July 31, 2024, we accrued $184.4 million for the verdict amount and estimated interest. As of April 30, 2025, we accrued $144.1 million based on the judgment and estimated interest, which is recorded in other long-term liabilities on our condensed consolidated balance sheets. The corresponding amount was a charge of $1.3 million for the three months ended April 30, 2025, and a release of $40.3 million for the nine months ended April 30, 2025, which is included in general and administrative expense on our condensed consolidated statements of operations.
  (was, 2025-02-14, similarity 0.933):
[0001327567-25-000010:note_history:2]
As of July 31, 2024, we accrued $184.4 million for the verdict amount and estimated interest. As of January 31, 2025, we accrued $142.8 million based on the judgment and estimated interest, which is recorded in other long-term liabilities on our condensed consolidated balance sheets. The corresponding amount was a charge of $1.4 million for the three months ended January 31, 2025, and a release of $41.6 million for the six months ended January 31, 2025, which is included in general and administrative expense on our condensed consolidated statements of operations.

- changed (2025-05-21):
[0001327567-25-000017:note_history:3]
Finjan, Inc. v. Palo Alto Networks
On November 4, 2014, Finjan, Inc., filed a lawsuit against us in the United States District Court for the Northern District of California. The lawsuit alleges that our products infringe multiple Finjan patents. The complaint requests injunctive relief, monetary damages, and attorneys’ fees. On March 21, 2025, the judge issued an order granting summary judgment of non-infringement on all remaining patents at issue. Plaintiff filed a Notice of Appeal on April 21, 2025. We are unable, at this time, to reasonably estimate a possible loss or potential range of loss, if any.
  (was, 2025-02-14, similarity 0.6152):
[0001327567-25-000010:note_history:3]
Finjan, Inc. v. Palo Alto Networks
On November 4, 2014, Finjan, Inc., filed a lawsuit against us in the United States District Court for the Northern District of California. The lawsuit alleges that our products infringe multiple Finjan patents. The complaint requests injunctive relief, monetary damages, and attorneys fees. A trial date is set for June 9, 2025. We are unable, at this time, to reasonably estimate a possible loss or potential range of loss, if any.


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2025-05-21):
[0001327567-25-000017:note_history:4]
There have been no material changes to our significant accounting policies as of and for the nine months ended April 30, 2025, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended July 31, 2024, except for the update to the disclosure of our accounting policies as described below resulting from our acquisition of certain QRadar assets from International Business Machines Corporation (“IBM”). Refer to Note 7. Acquisition for additional information.
  (was, 2025-02-14, similarity 0.9535):
[0001327567-25-000010:note_history:4]
There have been no material changes to our significant accounting policies as of and for the six months ended January 31, 2025, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended July 31, 2024, except for the update to the disclosure of our accounting policies as described below resulting from our acquisition of certain QRadar assets from International Business Machines Corporation (“IBM”). Refer to Note 7. Acquisition for additional information.

- changed (2025-05-21):
[0001327567-25-000017:note_history:5]
In November 2023, the Financial Accounting Standards Board (“FASB”) issued authoritative guidance that expands annual and interim disclosure requirements for reportable segments, primarily through enhanced disclosures about significant segment expenses. The standard is effective for our annual period in fiscal 2025 and interim periods beginning in the first quarter of fiscal 2026, and requires retrospective application for all prior periods presented in the financial statements. Early adoption is permitted. We expect the adoption of this standard will not have a material impact on our consolidated financial statements.
  (was, 2025-02-14, similarity 0.8775):
[0001327567-25-000010:note_history:5]
In November 2023, the Financial Accounting Standards Board (“FASB”) issued authoritative guidance that expands annual and interim disclosure requirements for reportable segments, primarily through enhanced disclosures about significant segment expenses. The standard is effective for our annual period in fiscal 2025 and interim periods beginning in the first quarter of fiscal 2026, and requires retrospective application for all prior periods presented in the financial statements. Early adoption is permitted. We are currently evaluating the impact of this standard on our disclosures in the consolidated financial statements.


## us-gaap:ConvertibleDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-05-21):
[0001327567-25-000017:note_history:6]
|  | April 30, 2025 |  | July 31, 2024 |
| Principal | $ | 383.3 |  |  | $ | 965.6 |  |
| Less: debt issuance costs, net of amortization | (0.1) |  |  | (1.7) |  |
| Net carrying amount | $ | 383.2 |  |  | $ | 963.9 |  |
  (was, 2025-02-14, similarity 0.9778):
[0001327567-25-000010:note_history:6]
|  | January 31, 2025 |  | July 31, 2024 |
| Principal | $ | 534.2 |  |  | $ | 965.6 |  |
| Less: debt issuance costs, net of amortization | (0.4) |  |  | (1.7) |  |
| Net carrying amount | $ | 533.8 |  |  | $ | 963.9 |  |


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-05-21):
[0001327567-25-000017:note_history:7]
Holders of the 2025 Notes were able to early convert their 2025 Notes at any time prior to the close of business on the business day immediately preceding March 1, 2025 for settlement prior to the maturity date as the sales price condition had been met during the fiscal quarter ended January 31, 2025. During the three and nine months ended April 30, 2025, holders of the 2025 Notes converted $150.9 million and $582.3 million, respectively, in aggregate principal amount of the 2025 Notes, which we repaid in cash. We also issued 2.2 million and 8.4 million shares of our common stock to the holders of the 2025 Notes during the three and nine months ended April 30, 2025, respectively, for the conversion value in excess of the principal amount. During the three and nine months ended April 30, 2024, holders of the 2025 Notes converted $661.8 million and $834.1 million, respectively, in aggregate principal amount of the 2025 Notes, which we repaid in cash. We also issued 9.1 million and 11.3 million shares of our common stock to the holders of the 2025 Notes during the three and nine months ended April 30, 2024, respectively, for the conversion value in excess of the principal amount. These shares were fully offset by shares we received from the corresponding exercise of the note hedges.
  (was, 2025-02-14, similarity 0.7034):
[0001327567-25-000010:note_history:7]
Holders of the 2025 Notes were able to early convert their 2025 Notes during the fiscal quarter ended January 31, 2025 as the sales price condition had been met during the fiscal quarter ended October 31, 2024. During the three and six months ended January 31, 2025, holders of the 2025 Notes converted $112.4 million and $431.4 million, respectively, in aggregate principal amount of the 2025 Notes, which we repaid in cash. We also issued 1.7 million and 6.2 million shares of our common stock to the holders of the 2025 Notes during the three and six months ended January 31, 2025, respectively, for the conversion value in excess of the principal amount. During the three and six months ended January 31, 2024, holders of the 2025 Notes converted $126.3 million and $172.3 million, respectively, in aggregate principal amount of the 2025 Notes, which we repaid in cash. We also issued 1.7 million and 2.2 million shares of our common stock to the holders of the 2025 Notes during the three and six months ended January 31, 2024, respectively, for the conversion value in excess of the principal amount. These shares were fully offset by shares we received from the corresponding exercise of the note hedges. Refer to Note 16. Subsequent Events for additional information regarding conversion of the 2025 Notes after January 31, 2025 through the filing date of this Quarterly Report on Form 10-Q.

- added (2025-05-21):
[0001327567-25-000017:note_history:8]
On or after March 1, 2025, holders may surrender their 2025 Notes for conversion at any time prior to maturity, in accordance with the terms described above. Such conversion requests will settle upon maturity of the 2025 Notes. The net carrying amount of the 2025 Notes was classified as a current liability on our condensed consolidated balance sheet as of April 30, 2025.

- changed (2025-05-21):
[0001327567-25-000017:note_history:9]
|  | April 30, 2025 |  | July 31, 2024 |
| Principal | $ | 383.3 |  |  | $ | 965.6 |  |
| Less: debt issuance costs, net of amortization | (0.1) |  |  | (1.7) |  |
| Net carrying amount | $ | 383.2 |  |  | $ | 963.9 |  |
  (was, 2025-02-14, similarity 0.9778):
[0001327567-25-000010:note_history:9]
|  | January 31, 2025 |  | July 31, 2024 |
| Principal | $ | 534.2 |  |  | $ | 965.6 |  |
| Less: debt issuance costs, net of amortization | (0.4) |  |  | (1.7) |  |
| Net carrying amount | $ | 533.8 |  |  | $ | 963.9 |  |

- added (2025-05-21):
[0001327567-25-000017:note_history:10]
The total estimated fair value of the 2025 Notes was $1.4 billion as of April 30, 2025 and $3.2 billion as of July 31, 2024. The fair value was determined based on the closing trading price per $100 of the 2025 Notes as of the last day of trading for the period. We consider the fair value of the 2025 Notes as of April 30, 2025 and July 31, 2024 to be a Level 2 measurement. The fair value of the 2025 Notes is primarily affected by the trading price of our common stock and market interest rates.

- changed (2025-05-21):
[0001327567-25-000017:note_history:11]
|  | Three Months Ended April 30, |  | Nine Months Ended April 30, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Contractual interest expense | $ | 0.5 |  |  | $ | 1.5 |  |  | $ | 1.8 |  |  | $ | 5.1 |  |
| Amortization of debt issuance costs | 0.2 |  |  | 0.8 |  |  | 1.0 |  |  | 2.9 |  |
| Total interest expense | $ | 0.7 |  |  | $ | 2.3 |  |  | $ | 2.8 |  |  | $ | 8.0 |  |
| Effective interest rate | 0.6 | % |  | 0.6 | % |  | 0.6 | % |  | 0.6 | % |
  (was, 2025-02-14, similarity 0.9404):
[0001327567-25-000010:note_history:11]
|  | Three Months Ended January 31, |  | Six Months Ended January 31, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Contractual interest expense | $ | 0.6 |  |  | $ | 1.7 |  |  | $ | 1.3 |  |  | $ | 3.6 |  |
| Amortization of debt issuance costs | 0.3 |  |  | 1.1 |  |  | 0.8 |  |  | 2.1 |  |
| Total interest expense | $ | 0.9 |  |  | $ | 2.8 |  |  | $ | 2.1 |  |  | $ | 5.7 |  |
| Effective interest rate | 0.6 | % |  | 0.6 | % |  | 0.6 | % |  | 0.6 | % |

- changed (2025-05-21):
[0001327567-25-000017:note_history:12]
As a result of the conversions of the 2025 Notes settled during the three and nine months ended April 30, 2025, we exercised the corresponding portion of our 2025 Note Hedges and received 2.2 million and 8.4 million shares of our common stock during the respective periods. As a result of the conversions of the 2025 Notes settled during the three and nine months ended April 30, 2024, we exercised the corresponding portion of our 2025 Note Hedges and received 9.1 million and 11.3 million shares of our common stock during the respective periods.
  (was, 2025-02-14, similarity 0.9089):
[0001327567-25-000010:note_history:12]
As a result of the conversions of the 2025 Notes settled during the three and six months ended January 31, 2025, we exercised the corresponding portion of our 2025 Note Hedges and received 1.7 million and 6.2 million shares of our common stock during the respective periods. As a result of the conversions of the 2025 Notes settled during the three and six months ended January 31, 2024, we exercised the corresponding portion of our 2025 Note Hedges and received 1.7 million and 2.2 million shares of our common stock during the respective periods.

- changed (2025-05-21):
[0001327567-25-000017:note_history:13]
Separately, but concurrently with the issuance of each series of our convertible senior notes, we entered into transactions whereby we sold warrants (the “2023 Warrants,” with respect to the 0.75% convertible senior notes due 2023 issued in July 2018, the “2025 Warrants,” with respect to the 2025 Notes, and the 2023 Warrants together with the 2025 Warrants, the “Warrants”) to acquire shares of our common stock, subject to anti-dilution adjustments. The 2023 Warrants were, and the 2025 Warrants are, exercisable over 60 scheduled trading days beginning October 2023 and September 2025, respectively.
  (was, 2025-02-14, similarity 0.9579):
[0001327567-25-000010:note_history:13]
Separately, but concurrently with the issuance of each series of our convertible senior notes, we entered into transactions whereby we sold warrants (the “2023 Warrants,” with respect to the 0.75% convertible senior notes due 2023 issued in July 2018, the “2025 Warrants,” with respect to the 2025 Notes, and the 2023 Warrants together with the 2025 Warrants, the “Warrants”) to acquire shares of our common stock, subject to anti-dilution adjustments. The 2023 Warrants and 2025 Warrants are exercisable over 60 scheduled trading days beginning October 2023 and September 2025, respectively.

- added (2025-05-21):
[0001327567-25-000017:note_history:14]
During the nine months ended April 30, 2024, we net settled all of the 2023 Warrants with 18.0 million shares of our common stock with a fair value of $2.4 billion. The number of net shares issued was determined based on the number of 2023 Warrants exercised multiplied by the difference between the strike price of the 2023 Warrants and their daily volume-weighted-average stock price.

- changed (2025-05-21):
[0001327567-25-000017:note_history:15]
As of April 30, 2025, there were no amounts outstanding and we were in compliance with all covenants under the Credit Agreement.
  (was, 2025-02-14, similarity 0.9675):
[0001327567-25-000010:note_history:15]
As of January 31, 2025, there were no amounts outstanding and we were in compliance with all covenants under the Credit Agreement.

- removed (2025-05-21):
[0001327567-25-000010:note_history:16]
The sale price condition for the 2025 Notes was met during the fiscal quarter ended January 31, 2025 and, as a result, holders may convert their 2025 Notes during the fiscal quarter ending April 30, 2025 at any time prior to the close of business on the business day immediately preceding March 1, 2025 for settlement prior to the maturity date. The net carrying amount of the 2025 Notes was classified as a current liability on our condensed consolidated balance sheet as of January 31, 2025.

- removed (2025-05-21):
[0001327567-25-000010:note_history:17]
The total estimated fair value of the 2025 Notes was $2.0 billion as of January 31, 2025 and $3.2 billion as of July 31, 2024. The fair value was determined based on the closing trading price per $100 of the 2025 Notes as of the last day of trading for the period. We consider the fair value of the 2025 Notes as of January 31, 2025 and July 31, 2024 to be a Level 2 measurement. The fair value of the 2025 Notes is primarily affected by the trading price of our common stock and market interest rates.

- removed (2025-05-21):
[0001327567-25-000010:note_history:18]
During the six months ended January 31, 2024, we net settled all of the 2023 Warrants with 18.0 million shares of our common stock with a fair value of $2.4 billion, of which 11.9 million shares of our common stock with a fair value of $1.7 billion were net settled during the three months ended January 31, 2024. The number of net shares issued was determined based on the number of 2023 Warrants exercised multiplied by the difference between the strike price of the 2023 Warrants and their daily volume-weighted-average stock price.


## us-gaap:DebtSecuritiesAvailableForSaleTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-05-21):
[0001327567-25-000017:note_history:19]
The following tables summarize the amortized cost, unrealized gains and losses, and fair value of our available-for-sale debt securities as of April 30, 2025 and July 31, 2024 (in millions):
  (was, 2025-02-14, similarity 0.9779):
[0001327567-25-000010:note_history:19]
The following tables summarize the amortized cost, unrealized gains and losses, and fair value of our available-for-sale debt securities as of January 31, 2025 and July 31, 2024 (in millions):

- changed (2025-05-21):
[0001327567-25-000017:note_history:20]
|  | April 30, 2025 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | $ | 575.0 |  |  | $ | — |  |  | $ | — |  |  | $ | 575.0 |  |
| Corporate debt securities | 0.7 |  |  | — |  |  | — |  |  | 0.7 |  |
| Total available-for-sale cash equivalents | $ | 575.7 |  |  | $ | — |  |  | $ | — |  |  | $ | 575.7 |  |
| Investments: |  |  |  |  |  |  |  |
| Commercial paper | 53.6 |  |  | — |  |  | — |  |  | 53.6 |  |
| Corporate debt securities | 4,607.4 |  |  | 51.2 |  |  | (1.2) |  |  | 4,657.4 |  |
| U.S. government and agency securities | 85.4 |  |  | 0.1 |  |  | — |  |  | 85.5 |  |
| Non-U.S. government and agency securities | 28.8 |  |  | 0.6 |  |  | — |  |  | 29.4 |  |
| Asset-backed securities | 1,231.7 |  |  | 11.9 |  |  | (0.4) |  |  | 1,243.2 |  |
| Total available-for-sale investments | $ | 6,006.9 |  |  | $ | 63.8 |  |  | $ | (1.6) |  |  | $ | 6,069.1 |  |
  (was, 2025-02-14, similarity 0.8948):
[0001327567-25-000010:note_history:20]
|  | January 31, 2025 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | $ | 277.7 |  |  | $ | 0.1 |  |  | $ | — |  |  | $ | 277.8 |  |
| Corporate debt securities | 4.3 |  |  | — |  |  | — |  |  | 4.3 |  |
| U.S. government and agency securities | 18.0 |  |  | — |  |  | — |  |  | 18.0 |  |
| Total available-for-sale cash equivalents | $ | 300.0 |  |  | $ | 0.1 |  |  | $ | — |  |  | $ | 300.1 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 1.0 |  |  | $ | — |  |  | $ | — |  |  | $ | 1.0 |  |
| Commercial paper | 34.6 |  |  | — |  |  | — |  |  | 34.6 |  |
| Corporate debt securities | 4,401.7 |  |  | 20.3 |  |  | (8.7) |  |  | 4,413.3 |  |
| U.S. government and agency securities | 99.1 |  |  | — |  |  | (0.1) |  |  | 99.0 |  |
| Non-U.S. government and agency securities | 28.8 |  |  | 0.3 |  |  | — |  |  | 29.1 |  |
| Asset-backed securities | 983.1 |  |  | 6.8 |  |  | (0.5) |  |  | 989.4 |  |
| Total available-for-sale investments | $ | 5,548.3 |  |  | $ | 27.4 |  |  | $ | (9.3) |  |  | $ | 5,566.4 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-05-21):
[0001327567-25-000017:note_history:21]
The following tables summarize the amortized cost, unrealized gains and losses, and fair value of our available-for-sale debt securities as of April 30, 2025 and July 31, 2024 (in millions):
  (was, 2025-02-14, similarity 0.9779):
[0001327567-25-000010:note_history:21]
The following tables summarize the amortized cost, unrealized gains and losses, and fair value of our available-for-sale debt securities as of January 31, 2025 and July 31, 2024 (in millions):

- changed (2025-05-21):
[0001327567-25-000017:note_history:22]
|  | April 30, 2025 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | $ | 575.0 |  |  | $ | — |  |  | $ | — |  |  | $ | 575.0 |  |
| Corporate debt securities | 0.7 |  |  | — |  |  | — |  |  | 0.7 |  |
| Total available-for-sale cash equivalents | $ | 575.7 |  |  | $ | — |  |  | $ | — |  |  | $ | 575.7 |  |
| Investments: |  |  |  |  |  |  |  |
| Commercial paper | 53.6 |  |  | — |  |  | — |  |  | 53.6 |  |
| Corporate debt securities | 4,607.4 |  |  | 51.2 |  |  | (1.2) |  |  | 4,657.4 |  |
| U.S. government and agency securities | 85.4 |  |  | 0.1 |  |  | — |  |  | 85.5 |  |
| Non-U.S. government and agency securities | 28.8 |  |  | 0.6 |  |  | — |  |  | 29.4 |  |
| Asset-backed securities | 1,231.7 |  |  | 11.9 |  |  | (0.4) |  |  | 1,243.2 |  |
| Total available-for-sale investments | $ | 6,006.9 |  |  | $ | 63.8 |  |  | $ | (1.6) |  |  | $ | 6,069.1 |  |
  (was, 2025-02-14, similarity 0.8948):
[0001327567-25-000010:note_history:22]
|  | January 31, 2025 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | $ | 277.7 |  |  | $ | 0.1 |  |  | $ | — |  |  | $ | 277.8 |  |
| Corporate debt securities | 4.3 |  |  | — |  |  | — |  |  | 4.3 |  |
| U.S. government and agency securities | 18.0 |  |  | — |  |  | — |  |  | 18.0 |  |
| Total available-for-sale cash equivalents | $ | 300.0 |  |  | $ | 0.1 |  |  | $ | — |  |  | $ | 300.1 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 1.0 |  |  | $ | — |  |  | $ | — |  |  | $ | 1.0 |  |
| Commercial paper | 34.6 |  |  | — |  |  | — |  |  | 34.6 |  |
| Corporate debt securities | 4,401.7 |  |  | 20.3 |  |  | (8.7) |  |  | 4,413.3 |  |
| U.S. government and agency securities | 99.1 |  |  | — |  |  | (0.1) |  |  | 99.0 |  |
| Non-U.S. government and agency securities | 28.8 |  |  | 0.3 |  |  | — |  |  | 29.1 |  |
| Asset-backed securities | 983.1 |  |  | 6.8 |  |  | (0.5) |  |  | 989.4 |  |
| Total available-for-sale investments | $ | 5,548.3 |  |  | $ | 27.4 |  |  | $ | (9.3) |  |  | $ | 5,566.4 |  |

- added (2025-05-21):
[0001327567-25-000017:note_history:23]
As of April 30, 2025, the gross unrealized losses that have been in a continuous unrealized loss position for less than 12 months were $1.4 million, which were related to $691.9 million of available-for-sale debt securities, and the gross unrealized losses that have been in a continuous unrealized loss position for more than 12 months were $0.2 million, which were related to $145.5 million of available-for-sale debt securities. As of July 31, 2024 the gross unrealized losses that have been in a continuous unrealized loss position for less than 12 months were $1.5 million, which were related to $949.4 million of available-for-sale debt securities, and the gross unrealized losses that have been in a continuous unrealized loss position for more than 12 months were $6.0 million, which were related to $915.3 million of available-for-sale debt securities.

- changed (2025-05-21):
[0001327567-25-000017:note_history:24]
Unrealized losses related to our available-for-sale debt securities are primarily due to interest rate fluctuations as opposed to credit quality. We do not intend to sell any of the securities in an unrealized loss position and it is not likely that we would be required to sell these securities before recovery of their amortized cost basis, which may be at maturity. We did not recognize any credit losses related to our available-for-sale debt securities during the three and nine months ended April 30, 2025 and 2024.
  (was, 2025-02-14, similarity 0.9815):
[0001327567-25-000010:note_history:24]
Unrealized losses related to our available-for-sale debt securities are primarily due to interest rate fluctuations as opposed to credit quality. We do not intend to sell any of the securities in an unrealized loss position and it is not likely that we would be required to sell these securities before recovery of their amortized cost basis, which may be at maturity. We did not recognize any credit losses related to our available-for-sale debt securities during the three and six months ended January 31, 2025 and 2024.

- changed (2025-05-21):
[0001327567-25-000017:note_history:25]
The following table summarizes the amortized cost and fair value of our available-for-sale debt securities as of April 30, 2025, by contractual years-to-maturity (in millions):
  (was, 2025-02-14, similarity 0.9766):
[0001327567-25-000010:note_history:25]
The following table summarizes the amortized cost and fair value of our available-for-sale debt securities as of January 31, 2025, by contractual years-to-maturity (in millions):

- added (2025-05-21):
[0001327567-25-000017:note_history:26]
Marketable equity securities consist of money market funds and are included in cash and cash equivalents on our condensed consolidated balance sheets. As of April 30, 2025 and July 31, 2024, the carrying values of our marketable equity securities were $1.1 billion and $494.0 million, respectively. There were no unrealized gains or losses recognized for these securities during the three and nine months ended April 30, 2025 and 2024.

- removed (2025-05-21):
[0001327567-25-000010:note_history:27]
As of January 31, 2025, the gross unrealized losses that have been in a continuous unrealized loss position for less than 12 months were $8.9 million, which were related to $1.5 billion of available-for-sale debt securities, and the gross unrealized losses that have been in a continuous unrealized loss position for more than 12 months were $0.4 million, which were related to $215.4 million of available-for-sale debt securities. As of July 31, 2024 the gross unrealized losses that have been in a continuous unrealized loss position for less than 12 months were $1.5 million, which were related to $949.4 million of available-for-sale debt securities, and the gross unrealized losses that have been in a continuous unrealized loss position for more than 12 months were $6.0 million, which were related to $915.3 million of available-for-sale debt securities.

- removed (2025-05-21):
[0001327567-25-000010:note_history:28]
Marketable equity securities consist of money market funds and are included in cash and cash equivalents on our condensed consolidated balance sheets. As of January 31, 2025 and July 31, 2024, the carrying values of our marketable equity securities were $1.3 billion and $494.0 million, respectively. There were no unrealized gains or losses recognized for these securities during the three and six months ended January 31, 2025 and 2024.


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2025-05-21):
[0001327567-25-000017:note_history:29]
|  | Three Months Ended April 30, |  | Nine Months Ended April 30, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Revenue: |  |  |  |  |  |  |  |
| Americas |  |  |  |  |  |  |  |
| United States | $ | 1,424.4 |  |  | $ | 1,271.1 |  |  | $ | 4,169.0 |  |  | $ | 3,723.6 |  |
| Other Americas | 104.8 |  |  | 88.5 |  |  | 304.7 |  |  | 256.8 |  |
| Total Americas | 1,529.2 |  |  | 1,359.6 |  |  | 4,473.7 |  |  | 3,980.4 |  |
| Europe, the Middle East, and Africa (“EMEA”) | 480.9 |  |  | 399.2 |  |  | 1,402.3 |  |  | 1,170.9 |  |
| Asia Pacific and Japan (“APAC”) | 278.9 |  |  | 226.0 |  |  | 809.2 |  |  | 686.7 |  |
| Total revenue | $ | 2,289.0 |  |  | $ | 1,984.8 |  |  | $ | 6,685.2 |  |  | $ | 5,838.0 |  |
  (was, 2025-02-14, similarity 0.9563):
[0001327567-25-000010:note_history:29]
|  | Three Months Ended January 31, |  | Six Months Ended January 31, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Revenue: |  |  |  |  |  |  |  |
| Americas |  |  |  |  |  |  |  |
| United States | $ | 1,400.5 |  |  | $ | 1,248.2 |  |  | $ | 2,744.6 |  |  | $ | 2,452.5 |  |
| Other Americas | 101.9 |  |  | 86.0 |  |  | 199.9 |  |  | 168.3 |  |
| Total Americas | 1,502.4 |  |  | 1,334.2 |  |  | 2,944.5 |  |  | 2,620.8 |  |
| Europe, the Middle East, and Africa (“EMEA”) | 480.0 |  |  | 406.8 |  |  | 921.4 |  |  | 771.7 |  |
| Asia Pacific and Japan (“APAC”) | 275.0 |  |  | 234.1 |  |  | 530.3 |  |  | 460.7 |  |
| Total revenue | $ | 2,257.4 |  |  | $ | 1,975.1 |  |  | $ | 4,396.2 |  |  | $ | 3,853.2 |  |

- added (2025-05-21):
[0001327567-25-000017:note_history:30]
|  | Three Months Ended April 30, |  | Nine Months Ended April 30, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Revenue: |  |  |  |  |  |  |  |
| Product | $ | 452.7 |  |  | $ | 391.0 |  |  | $ | 1,228.0 |  |  | $ | 1,122.8 |  |
| Subscription and support |  |  |  |  |  |  |  |
| Subscription | 1,234.4 |  |  | 1,045.6 |  |  | 3,659.4 |  |  | 3,061.0 |  |
| Support | 601.9 |  |  | 548.2 |  |  | 1,797.8 |  |  | 1,654.2 |  |
| Total subscription and support | 1,836.3 |  |  | 1,593.8 |  |  | 5,457.2 |  |  | 4,715.2 |  |
| Total revenue | $ | 2,289.0 |  |  | $ | 1,984.8 |  |  | $ | 6,685.2 |  |  | $ | 5,838.0 |  |

- changed (2025-05-21):
[0001327567-25-000017:note_history:31]
During the nine months ended April 30, 2025 and 2024, we recognized approximately $4.4 billion and $3.7 billion of revenue pertaining to amounts that were deferred as of July 31, 2024 and 2023, respectively.
  (was, 2025-02-14, similarity 0.965):
[0001327567-25-000010:note_history:31]
During the six months ended January 31, 2025 and 2024, we recognized approximately $3.1 billion and $2.7 billion of revenue pertaining to amounts that were deferred as of July 31, 2024 and 2023, respectively.

- changed (2025-05-21):
[0001327567-25-000017:note_history:32]
Remaining performance obligations were $13.5 billion as of April 30, 2025, of which we expect to recognize as revenue approximately $6.2 billion over the next 12 months and the remainder thereafter.
  (was, 2025-02-14, similarity 0.9786):
[0001327567-25-000010:note_history:32]
Remaining performance obligations were $13.0 billion as of January 31, 2025, of which we expect to recognize as revenue approximately $6.1 billion over the next 12 months and the remainder thereafter.

- removed (2025-05-21):
[0001327567-25-000010:note_history:33]
|  | Three Months Ended January 31, |  | Six Months Ended January 31, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Revenue: |  |  |  |  |  |  |  |
| Product | $ | 421.5 |  |  | $ | 390.7 |  |  | $ | 775.3 |  |  | $ | 731.8 |  |
| Subscription and support |  |  |  |  |  |  |  |
| Subscription | 1,233.2 |  |  | 1,027.1 |  |  | 2,425.0 |  |  | 2,015.4 |  |
| Support | 602.7 |  |  | 557.3 |  |  | 1,195.9 |  |  | 1,106.0 |  |
| Total subscription and support | 1,835.9 |  |  | 1,584.4 |  |  | 3,620.9 |  |  | 3,121.4 |  |
| Total revenue | $ | 2,257.4 |  |  | $ | 1,975.1 |  |  | $ | 4,396.2 |  |  | $ | 3,853.2 |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_current_note, score: 0.0

- removed (2025-05-21):
[0001327567-25-000010:note_history:34]
Subsequent Events
2025 Notes Conversion

- removed (2025-05-21):
[0001327567-25-000010:note_history:35]
Subsequent to January 31, 2025, $100.4 million in aggregate principal amount of the 2025 Notes was converted or had been submitted by the holders for conversion and will settle during the fiscal quarter ending April 30, 2025.
