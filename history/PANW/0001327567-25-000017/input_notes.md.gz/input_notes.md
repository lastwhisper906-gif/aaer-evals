# PANW notes — 0001327567-25-000017


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock

[0001327567-25-000017:notes:1]
[same as prior period, unchanged from 0001327567-25-000010:notes:1]

[0001327567-25-000017:notes:2]
[same as prior period, unchanged from 0001327567-25-000010:notes:2]

[0001327567-25-000017:notes:3]
[same as prior period, unchanged from 0001327567-25-000010:notes:3]

[0001327567-25-000017:notes:4]
[same as prior period, unchanged from 0001327567-25-000010:notes:4]

[0001327567-25-000017:notes:5]
[same as prior period, unchanged from 0001327567-25-000010:notes:5]

[0001327567-25-000017:notes:6]
[same as prior period, unchanged from 0001327567-25-000010:notes:6]

[0001327567-25-000017:notes:7]
The preparation of condensed consolidated financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the amounts reported and disclosed in the condensed consolidated financial statements and the accompanying notes. We evaluate our estimates on an ongoing basis. Management estimates include, but are not limited to, the standalone selling price for our products and services, share-based compensation, fair value of assets acquired and liabilities assumed in business combinations, fair value of contingent consideration liability, the assessment of recoverability of our intangibles and goodwill, valuation allowance against deferred tax assets, manufacturing partner and supplier liabilities, deferred contract cost benefit period, and loss contingencies. We base our estimates on assumptions, both historical and forward looking, that we believe are reasonable. Actual results could differ materially from those estimates due to risks and uncertainties, including uncertainty in the current economic environment.

[0001327567-25-000017:notes:8]
[same as prior period, unchanged from 0001327567-25-000010:notes:8]

[0001327567-25-000017:notes:9]
[same as prior period, unchanged from 0001327567-25-000010:notes:9]

[0001327567-25-000017:notes:10]
[same as prior period, unchanged from 0001327567-25-000010:notes:10]

[0001327567-25-000017:notes:11]
There have been no material changes to our significant accounting policies as of and for the nine months ended April 30, 2025, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended July 31, 2024, except for the update to the disclosure of our accounting policies as described below resulting from our acquisition of certain QRadar assets from International Business Machines Corporation (“IBM”). Refer to Note 7. Acquisition for additional information.

[0001327567-25-000017:notes:12]
[same as prior period, unchanged from 0001327567-25-000010:notes:12]

[0001327567-25-000017:notes:13]
[same as prior period, unchanged from 0001327567-25-000010:notes:13]

[0001327567-25-000017:notes:14]
Contingent consideration obligations incurred in connection with a business combination are recorded at fair value on the acquisition date and remeasured at each subsequent reporting period until the related contingencies have been resolved, with the change in fair value recognized in general and administrative expense on our condensed consolidated statements of operations. Payments not made soon after the acquisition date to settle a contingent consideration liability are classified as cash flows from financing activities up to the amount of the contingent consideration liability recognized at the acquisition date.

[0001327567-25-000017:notes:15]
Recently Issued Accounting Pronouncements

[0001327567-25-000017:notes:16]
[same as prior period, unchanged from 0001327567-25-000010:notes:16]

[0001327567-25-000017:notes:17]
In November 2023, the Financial Accounting Standards Board (“FASB”) issued authoritative guidance that expands annual and interim disclosure requirements for reportable segments, primarily through enhanced disclosures about significant segment expenses. The standard is effective for our annual period in fiscal 2025 and interim periods beginning in the first quarter of fiscal 2026, and requires retrospective application for all prior periods presented in the financial statements. Early adoption is permitted. We expect the adoption of this standard will not have a material impact on our consolidated financial statements.

[0001327567-25-000017:notes:18]
[same as prior period, unchanged from 0001327567-25-000010:notes:18]

[0001327567-25-000017:notes:19]
[same as prior period, unchanged from 0001327567-25-000010:notes:19]

[0001327567-25-000017:notes:20]
[same as prior period, unchanged from 0001327567-25-000010:notes:20]

[0001327567-25-000017:notes:21]
[same as prior period, unchanged from 0001327567-25-000010:notes:21]


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001327567-25-000017:notes:22]
[same as prior period, unchanged from 0001327567-25-000010:notes:22]

[0001327567-25-000017:notes:23]
[same as prior period, unchanged from 0001327567-25-000010:notes:23]

[0001327567-25-000017:notes:24]
|  | Three Months Ended April 30, |  | Nine Months Ended April 30, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Revenue: |  |  |  |  |  |  |  |
| Americas |  |  |  |  |  |  |  |
| United States | $ | 1,424.4 |  |  | $ | 1,271.1 |  |  | $ | 4,169.0 |  |  | $ | 3,723.6 |  |
| Other Americas | 104.8 |  |  | 88.5 |  |  | 304.7 |  |  | 256.8 |  |
| Total Americas | 1,529.2 |  |  | 1,359.6 |  |  | 4,473.7 |  |  | 3,980.4 |  |
| Europe, the Middle East, and Africa (“EMEA”) | 480.9 |  |  | 399.2 |  |  | 1,402.3 |  |  | 1,170.9 |  |
| Asia Pacific and Japan (“APAC”) | 278.9 |  |  | 226.0 |  |  | 809.2 |  |  | 686.7 |  |
| Total revenue | $ | 2,289.0 |  |  | $ | 1,984.8 |  |  | $ | 6,685.2 |  |  | $ | 5,838.0 |  |

[0001327567-25-000017:notes:25]
[same as prior period, unchanged from 0001327567-25-000010:notes:25]

[0001327567-25-000017:notes:26]
|  | Three Months Ended April 30, |  | Nine Months Ended April 30, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Revenue: |  |  |  |  |  |  |  |
| Product | $ | 452.7 |  |  | $ | 391.0 |  |  | $ | 1,228.0 |  |  | $ | 1,122.8 |  |
| Subscription and support |  |  |  |  |  |  |  |
| Subscription | 1,234.4 |  |  | 1,045.6 |  |  | 3,659.4 |  |  | 3,061.0 |  |
| Support | 601.9 |  |  | 548.2 |  |  | 1,797.8 |  |  | 1,654.2 |  |
| Total subscription and support | 1,836.3 |  |  | 1,593.8 |  |  | 5,457.2 |  |  | 4,715.2 |  |
| Total revenue | $ | 2,289.0 |  |  | $ | 1,984.8 |  |  | $ | 6,685.2 |  |  | $ | 5,838.0 |  |

[0001327567-25-000017:notes:27]
[same as prior period, unchanged from 0001327567-25-000010:notes:27]

[0001327567-25-000017:notes:28]
During the nine months ended April 30, 2025 and 2024, we recognized approximately $4.4 billion and $3.7 billion of revenue pertaining to amounts that were deferred as of July 31, 2024 and 2023, respectively.

[0001327567-25-000017:notes:29]
[same as prior period, unchanged from 0001327567-25-000010:notes:29]

[0001327567-25-000017:notes:30]
Remaining performance obligations were $13.5 billion as of April 30, 2025, of which we expect to recognize as revenue approximately $6.2 billion over the next 12 months and the remainder thereafter.


## us-gaap:FairValueDisclosuresTextBlock

[0001327567-25-000017:notes:31]
Fair Value Measurements
The following table presents our financial assets and liabilities measured at fair value on a recurring basis as of April 30, 2025 and July 31, 2024 (in millions):

[0001327567-25-000017:notes:32]
|  | April 30, 2025 |  | July 31, 2024 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Cash equivalents: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | $ | 1,060.7 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,060.7 |  |  | $ | 494.0 |  |  | $ | — |  |  | $ | — |  |  | $ | 494.0 |  |
| Commercial paper | — |  |  | 575.0 |  |  | — |  |  | 575.0 |  |  | — |  |  | 299.6 |  |  | — |  |  | 299.6 |  |
| Corporate debt securities | — |  |  | 0.7 |  |  | — |  |  | 0.7 |  |  | — |  |  | 18.2 |  |  | — |  |  | 18.2 |  |
| U.S. government and agency securities | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 149.6 |  |  | — |  |  | 149.6 |  |
| Total cash equivalents | 1,060.7 |  |  | 575.7 |  |  | — |  |  | 1,636.4 |  |  | 494.0 |  |  | 467.4 |  |  | — |  |  | 961.4 |  |
| Short-term investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Certificates of deposit | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 20.6 |  |  | — |  |  | 20.6 |  |
| Commercial paper | — |  |  | 53.6 |  |  | — |  |  | 53.6 |  |  | — |  |  | 79.9 |  |  | — |  |  | 79.9 |  |
| Corporate debt securities | — |  |  | 834.8 |  |  | — |  |  | 834.8 |  |  | — |  |  | 935.9 |  |  | — |  |  | 935.9 |  |
| U.S. government and agency securities | — |  |  | 7.1 |  |  | — |  |  | 7.1 |  |  | — |  |  | 2.7 |  |  | — |  |  | 2.7 |  |
| Non-U.S. government and agency securities | — |  |  | 3.1 |  |  | — |  |  | 3.1 |  |  | — |  |  | 4.2 |  |  | — |  |  | 4.2 |  |
| Asset-backed securities | — |  |  | 18.2 |  |  | — |  |  | 18.2 |  |  | — |  |  | 0.3 |  |  | — |  |  | 0.3 |  |
| Total short-term investments | — |  |  | 916.8 |  |  | — |  |  | 916.8 |  |  | — |  |  | 1,043.6 |  |  | — |  |  | 1,043.6 |  |

[0001327567-25-000017:notes:33]
|  | April 30, 2025 |  | July 31, 2024 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Long-term investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | — |  |  | 3,822.6 |  |  | — |  |  | 3,822.6 |  |  | — |  |  | 3,151.3 |  |  | — |  |  | 3,151.3 |  |
| U.S. government and agency securities | — |  |  | 78.4 |  |  | — |  |  | 78.4 |  |  | — |  |  | 19.0 |  |  | — |  |  | 19.0 |  |
| Non-U.S. government and agency securities | — |  |  | 26.3 |  |  | — |  |  | 26.3 |  |  | — |  |  | 54.4 |  |  | — |  |  | 54.4 |  |
| Asset-backed securities | — |  |  | 1,225.0 |  |  | — |  |  | 1,225.0 |  |  | — |  |  | 948.5 |  |  | — |  |  | 948.5 |  |
| Total long-term investments | — |  |  | 5,152.3 |  |  | — |  |  | 5,152.3 |  |  | — |  |  | 4,173.2 |  |  | — |  |  | 4,173.2 |  |
| Prepaid expenses and other current assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency forward contracts | — |  |  | 36.9 |  |  | — |  |  | 36.9 |  |  | — |  |  | 4.1 |  |  | — |  |  | 4.1 |  |
| Total prepaid expenses and other current assets | — |  |  | 36.9 |  |  | — |  |  | 36.9 |  |  | — |  |  | 4.1 |  |  | — |  |  | 4.1 |  |
| Other assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency forward contracts | — |  |  | 10.9 |  |  | — |  |  | 10.9 |  |  | — |  |  | 0.1 |  |  | — |  |  | 0.1 |  |
| Total other assets | — |  |  | 10.9 |  |  | — |  |  | 10.9 |  |  | — |  |  | 0.1 |  |  | — |  |  | 0.1 |  |
| Total assets measured at fair value | $ | 1,060.7 |  |  | $ | 6,692.6 |  |  | $ | — |  |  | $ | 7,753.3 |  |  | $ | 494.0 |  |  | $ | 5,688.4 |  |  | $ | — |  |  | $ | 6,182.4 |  |
| Accrued and other liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency forward contracts | $ | — |  |  | $ | 5.7 |  |  | $ | — |  |  | $ | 5.7 |  |  | $ | — |  |  | $ | 15.3 |  |  | $ | — |  |  | $ | 15.3 |  |
| Contingent consideration | — |  |  | — |  |  | 347.6 |  |  | 347.6 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Total accrued and other liabilities | — |  |  | 5.7 |  |  | 347.6 |  |  | 353.3 |  |  | — |  |  | 15.3 |  |  | — |  |  | 15.3 |  |
| Other long-term liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency forward contracts | — |  |  | 0.2 |  |  | — |  |  | 0.2 |  |  | — |  |  | 0.9 |  |  | — |  |  | 0.9 |  |
| Contingent consideration | — |  |  | — |  |  | 321.6 |  |  | 321.6 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Total other long-term liabilities | — |  |  | 0.2 |  |  | 321.6 |  |  | 321.8 |  |  | — |  |  | 0.9 |  |  | — |  |  | 0.9 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 5.9 |  |  | $ | 669.2 |  |  | $ | 675.1 |  |  | $ | — |  |  | $ | 16.2 |  |  | $ | — |  |  | $ | 16.2 |  |

[0001327567-25-000017:notes:34]
[same as prior period, unchanged from 0001327567-25-000010:notes:34]

[0001327567-25-000017:notes:35]
[same as prior period, unchanged from 0001327567-25-000010:notes:35]

[0001327567-25-000017:notes:36]
|  | Three Months Ended April 30, 2025 |  | Nine Months Ended April 30, 2025 |  |  |
| Contingent consideration liability at the beginning of the period | $ | 664.9 |  |  | $ | — |  |  |  |
| Initial valuation on the acquisition date | — |  |  | 648.9 |  |  |  |
| Change in fair value | 4.3 |  |  | 20.3 |  |  |  |
| Contingent consideration liability at the end of the period | $ | 669.2 |  |  | $ | 669.2 |  |  |  |

[0001327567-25-000017:notes:37]
The total estimated fair value of our financing receivables approximates their carrying amounts as of April 30, 2025 and July 31, 2024. We consider the fair value of our financing receivables to be a Level 3 measurement as we use unobservable inputs in determining discounted cash flows to estimate the fair value.

[0001327567-25-000017:notes:38]
Refer to Note 9. Debt for the carrying amount and estimated fair value of our convertible senior notes as of April 30, 2025 and July 31, 2024.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001327567-25-000017:notes:39]
Cash Equivalents and Investments
Available-for-sale Debt Securities

[0001327567-25-000017:notes:40]
The following tables summarize the amortized cost, unrealized gains and losses, and fair value of our available-for-sale debt securities as of April 30, 2025 and July 31, 2024 (in millions):

[0001327567-25-000017:notes:41]
|  | April 30, 2025 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | $ | 575.0 |  |  | $ | — |  |  | $ | — |  |  | $ | 575.0 |  |
| Corporate debt securities | 0.7 |  |  | — |  |  | — |  |  | 0.7 |  |
| Total available-for-sale cash equivalents | $ | 575.7 |  |  | $ | — |  |  | $ | — |  |  | $ | 575.7 |  |
| Investments: |  |  |  |  |  |  |  |
| Commercial paper | 53.6 |  |  | — |  |  | — |  |  | 53.6 |  |
| Corporate debt securities | 4,607.4 |  |  | 51.2 |  |  | (1.2) |  |  | 4,657.4 |  |
| U.S. government and agency securities | 85.4 |  |  | 0.1 |  |  | — |  |  | 85.5 |  |
| Non-U.S. government and agency securities | 28.8 |  |  | 0.6 |  |  | — |  |  | 29.4 |  |
| Asset-backed securities | 1,231.7 |  |  | 11.9 |  |  | (0.4) |  |  | 1,243.2 |  |
| Total available-for-sale investments | $ | 6,006.9 |  |  | $ | 63.8 |  |  | $ | (1.6) |  |  | $ | 6,069.1 |  |

[0001327567-25-000017:notes:42]
|  | July 31, 2024 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | $ | 299.6 |  |  | $ | — |  |  | $ | — |  |  | $ | 299.6 |  |
| Corporate debt securities | 18.2 |  |  | — |  |  | — |  |  | 18.2 |  |
| U.S. government and agency securities | 149.6 |  |  | — |  |  | — |  |  | 149.6 |  |
| Total available-for-sale cash equivalents | $ | 467.4 |  |  | $ | — |  |  | $ | — |  |  | $ | 467.4 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 20.6 |  |  | $ | — |  |  | $ | — |  |  | $ | 20.6 |  |
| Commercial paper | 79.9 |  |  | 0.1 |  |  | (0.1) |  |  | 79.9 |  |
| Corporate debt securities | 4,065.5 |  |  | 28.3 |  |  | (6.6) |  |  | 4,087.2 |  |
| U.S. government and agency securities | 21.9 |  |  | — |  |  | (0.2) |  |  | 21.7 |  |
| Non-U.S. government and agency securities | 57.9 |  |  | 0.7 |  |  | — |  |  | 58.6 |  |
| Asset-backed securities | 943.1 |  |  | 6.3 |  |  | (0.6) |  |  | 948.8 |  |
| Total available-for-sale investments | $ | 5,188.9 |  |  | $ | 35.4 |  |  | $ | (7.5) |  |  | $ | 5,216.8 |  |

[0001327567-25-000017:notes:43]
As of April 30, 2025, the gross unrealized losses that have been in a continuous unrealized loss position for less than 12 months were $1.4 million, which were related to $691.9 million of available-for-sale debt securities, and the gross unrealized losses that have been in a continuous unrealized loss position for more than 12 months were $0.2 million, which were related to $145.5 million of available-for-sale debt securities. As of July 31, 2024 the gross unrealized losses that have been in a continuous unrealized loss position for less than 12 months were $1.5 million, which were related to $949.4 million of available-for-sale debt securities, and the gross unrealized losses that have been in a continuous unrealized loss position for more than 12 months were $6.0 million, which were related to $915.3 million of available-for-sale debt securities.

[0001327567-25-000017:notes:44]
Unrealized losses related to our available-for-sale debt securities are primarily due to interest rate fluctuations as opposed to credit quality. We do not intend to sell any of the securities in an unrealized loss position and it is not likely that we would be required to sell these securities before recovery of their amortized cost basis, which may be at maturity. We did not recognize any credit losses related to our available-for-sale debt securities during the three and nine months ended April 30, 2025 and 2024.

[0001327567-25-000017:notes:45]
The following table summarizes the amortized cost and fair value of our available-for-sale debt securities as of April 30, 2025, by contractual years-to-maturity (in millions):

[0001327567-25-000017:notes:46]
|  | Amortized Cost |  | Fair Value |
| Due within one year | $ | 1,491.6 |  |  | $ | 1,492.5 |  |
| Due between one and three years | 1,803.7 |  |  | 1,820.0 |  |
| Due between three and five years | 2,868.6 |  |  | 2,908.2 |  |
| Due between five and ten years | 262.6 |  |  | 265.3 |  |
| Due after ten years | 156.1 |  |  | 158.8 |  |
| Total | $ | 6,582.6 |  |  | $ | 6,644.8 |  |

[0001327567-25-000017:notes:47]
Marketable Equity Securities

[0001327567-25-000017:notes:48]
Marketable equity securities consist of money market funds and are included in cash and cash equivalents on our condensed consolidated balance sheets. As of April 30, 2025 and July 31, 2024, the carrying values of our marketable equity securities were $1.1 billion and $494.0 million, respectively. There were no unrealized gains or losses recognized for these securities during the three and nine months ended April 30, 2025 and 2024.


## us-gaap:FinancingReceivablesTextBlock

[0001327567-25-000017:notes:49]
Financing Receivables
The following table summarizes our short-term and long-term financing receivables as of April 30, 2025 and July 31, 2024 (in millions):

[0001327567-25-000017:notes:50]
|  | April 30, 2025 |  | July 31, 2024 |
| Short-term financing receivables, gross | $ | 833.7 |  |  | $ | 830.2 |  |
| Unearned income | (91.4) |  |  | (95.7) |  |
| Allowance for credit losses | (5.0) |  |  | (8.6) |  |
| Short-term financing receivables, net | $ | 737.3 |  |  | $ | 725.9 |  |
| Long-term financing receivables, gross | $ | 1,154.3 |  |  | $ | 1,286.4 |  |
| Unearned income | (76.9) |  |  | (94.6) |  |
| Allowance for credit losses | (8.5) |  |  | (9.7) |  |
| Long-term financing receivables, net | $ | 1,068.9 |  |  | $ | 1,182.1 |  |

[0001327567-25-000017:notes:51]
[same as prior period, unchanged from 0001327567-25-000010:notes:51]

[0001327567-25-000017:notes:52]
| Internal Risk Rating(1) |  | April 30, 2025 |  | July 31, 2024 |
|  | Fiscal Year of Origination |  |  |  | Fiscal Year of Origination |  |  |
|  | 2025 |  | 2024 |  | 2023 |  | 2022 |  | 2021 |  | Total |  | 2024 |  | 2023 |  | 2022 |  | 2021 |  | Total |
| 1 to 4 |  | $ | 118.1 |  |  | $ | 794.3 |  |  | $ | 323.1 |  |  | $ | 9.2 |  |  | $ | 21.5 |  |  | $ | 1,266.2 |  |  | $ | 885.9 |  |  | $ | 477.3 |  |  | $ | 14.7 |  |  | $ | 44.4 |  |  | $ | 1,422.3 |  |
| 5 to 6 |  | 170.7 |  |  | 262.6 |  |  | 99.3 |  |  | — |  |  | 0.7 |  |  | 533.3 |  |  | 272.2 |  |  | 172.0 |  |  | 21.1 |  |  | 1.1 |  |  | 466.4 |  |
| 7 to 10 |  | 0.1 |  |  | 4.1 |  |  | 15.7 |  |  | 0.3 |  |  | — |  |  | 20.2 |  |  | 3.2 |  |  | 25.0 |  |  | 0.3 |  |  | 9.1 |  |  | 37.6 |  |
| Amortized cost basis of financing receivables |  | $ | 288.9 |  |  | $ | 1,061.0 |  |  | $ | 438.1 |  |  | $ | 9.5 |  |  | $ | 22.2 |  |  | $ | 1,819.7 |  |  | $ | 1,161.3 |  |  | $ | 674.3 |  |  | $ | 36.1 |  |  | $ | 54.6 |  |  | $ | 1,926.3 |  |

[0001327567-25-000017:notes:53]
[same as prior period, unchanged from 0001327567-25-000010:notes:53]

[0001327567-25-000017:notes:54]
As part of our financing credit risk management policy, we may sell financing receivables with an internal risk rating of 5 or greater on a non-recourse basis to third-party financial institutions when the outstanding balance of our financing receivables exceeds preestablished thresholds. We sold $28.1 million and $30.4 million of our financing receivables during the three and nine months ended April 30, 2025, respectively. The associated gains and losses were not material. The related proceeds were classified as cash flows from operating activities on our condensed consolidated statements of cash flows.

[0001327567-25-000017:notes:55]
There was no significant activity in allowance for credit losses during the three and nine months ended April 30, 2025 and 2024. Past due amounts on financing receivables were not material as of April 30, 2025 and July 31, 2024.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001327567-25-000017:notes:56]
Derivative Instruments
We are exposed to foreign currency exchange risk. Our sales contracts are primarily denominated in U.S. dollars. A portion of our operating expenditures are denominated in foreign currencies, making them subject to fluctuations in foreign currency exchange rates. We enter into foreign currency derivative contracts with maturities of 24 months or less, which we designate as cash flow hedges, to manage the foreign currency exchange risk associated with our revenue and operating expenditures.

[0001327567-25-000017:notes:57]
As of April 30, 2025 and July 31, 2024, the total notional amount of our outstanding foreign currency forward contracts designated as cash flow hedges was $1.1 billion and $804.8 million, respectively. Refer to Note 3. Fair Value Measurements for the fair value of our derivative instruments as reported on our condensed consolidated balance sheets as of April 30, 2025 and July 31, 2024.

[0001327567-25-000017:notes:58]
As of April 30, 2025, unrealized gains and losses in accumulated other comprehensive income (“AOCI”) related to our cash flow hedges were a $31.4 million net gain, of which $23.0 million in gains are expected to be recognized into earnings within the next 12 months. As of July 31, 2024, unrealized gains and losses in AOCI related to our cash flow hedges were a $10.6 million net loss.

[0001327567-25-000017:notes:59]
As of April 30, 2025 and July 31, 2024, the notional amount of our outstanding foreign currency forward contracts not designated as hedging instruments was $563.8 million and $375.6 million, respectively.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001327567-25-000017:notes:60]
Acquisition
Protect AI, Inc.

[0001327567-25-000017:notes:61]
On April 27, 2025, we entered into a definitive agreement to acquire Protect AI, Inc., a privately-held cyber security company (“Protect AI”), for a total consideration of $700.0 million in cash and replacement awards, subject to adjustment. We expect the acquisition will enhance the capabilities of our AI security platform.

[0001327567-25-000017:notes:62]
The acquisition of Protect AI is expected to close by the first quarter of fiscal 2026, subject to the satisfaction of closing conditions, including regulatory clearance.

[0001327567-25-000017:notes:63]
IBM QRadar Assets

[0001327567-25-000017:notes:64]
On August 31, 2024, we completed the acquisition of certain IBM QRadar assets, including certain intellectual property rights, customer relationships, and software as a service customer contracts. We expect the acquisition will help accelerate the growth of our Cortex Security Operations business. The total purchase consideration for the acquisition was $1.1 billion, which consisted of the following (in millions):

[0001327567-25-000017:notes:65]
[same as prior period, unchanged from 0001327567-25-000010:notes:61]

[0001327567-25-000017:notes:66]
As part of the acquisition, we agreed to make post-closing payments to IBM contingent upon customers entering into qualified new transactions through June 30, 2028. We also expect to receive a return of purchase consideration of $6.3 million due to timing of transition of certain underlying customer contracts, of which $1.4 million and $1.9 million were received during the three and nine months ended April 30, 2025, respectively. In addition, we have entered into a transition services arrangement with IBM, under which IBM will perform certain services supporting the acquired assets and customers for a period of time that ends in the fiscal quarter ending October 2026.

[0001327567-25-000017:notes:67]
Payments related to the contingent consideration liability are expected to begin in the fiscal quarter ending July 2025 and continue through the fiscal quarter ending October 2028. The estimated range of undiscounted contingent consideration is between $0.5 billion and $0.9 billion. Refer to Note 3. Fair Value Measurements, for more information on the fair value of our contingent consideration liability.

[0001327567-25-000017:notes:68]
[same as prior period, unchanged from 0001327567-25-000010:notes:64]

[0001327567-25-000017:notes:69]
[same as prior period, unchanged from 0001327567-25-000010:notes:65]

[0001327567-25-000017:notes:70]
Goodwill generated from this business combination is primarily attributable to the expected post-acquisition synergies from increased market penetration to support the growth of our Cortex Security Operations business. The goodwill is deductible for U.S. income tax purposes.

[0001327567-25-000017:notes:71]
[same as prior period, unchanged from 0001327567-25-000010:notes:67]

[0001327567-25-000017:notes:72]
[same as prior period, unchanged from 0001327567-25-000010:notes:68]

[0001327567-25-000017:notes:73]
[same as prior period, unchanged from 0001327567-25-000010:notes:69]

[0001327567-25-000017:notes:74]
[same as prior period, unchanged from 0001327567-25-000010:notes:70]


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001327567-25-000017:notes:75]
[same as prior period, unchanged from 0001327567-25-000010:notes:71]

[0001327567-25-000017:notes:76]
The following table presents details of our goodwill during the nine months ended April 30, 2025 (in millions):

[0001327567-25-000017:notes:77]
|  | Amount |
| Balance as of July 31, 2024 | $ | 3,350.1 |  |
| Goodwill acquired | 700.7 |  |
| Balance as of April 30, 2025 | $ | 4,050.8 |  |

[0001327567-25-000017:notes:78]
[same as prior period, unchanged from 0001327567-25-000010:notes:74]

[0001327567-25-000017:notes:79]
The following table presents details of our purchased intangible assets as of April 30, 2025 and July 31, 2024 (in millions):

[0001327567-25-000017:notes:80]
|  | April 30, 2025 |  | July 31, 2024 |
|  | Gross Carrying Amount |  | Accumulated Amortization |  | Net Carrying Amount |  | Gross Carrying Amount |  | Accumulated Amortization |  | Net Carrying Amount |
| Intangible assets subject to amortization: |  |  |  |  |  |  |  |  |  |  |  |
| Developed technology | $ | 825.9 |  |  | $ | (612.1) |  |  | $ | 213.8 |  |  | $ | 813.9 |  |  | $ | (526.2) |  |  | $ | 287.7 |  |
| Customer relationships | 636.7 |  |  | (137.0) |  |  | 499.7 |  |  | 172.7 |  |  | (96.1) |  |  | 76.6 |  |
| Acquired intellectual property | 26.3 |  |  | (9.7) |  |  | 16.6 |  |  | 18.2 |  |  | (7.9) |  |  | 10.3 |  |
| Trade name and trademarks | 9.4 |  |  | (9.4) |  |  | — |  |  | 9.4 |  |  | (9.4) |  |  | — |  |
| Other | 0.9 |  |  | (0.8) |  |  | 0.1 |  |  | 0.9 |  |  | (0.6) |  |  | 0.3 |  |
| Total purchased intangible assets | $ | 1,499.2 |  |  | $ | (769.0) |  |  | $ | 730.2 |  |  | $ | 1,015.1 |  |  | $ | (640.2) |  |  | $ | 374.9 |  |

[0001327567-25-000017:notes:81]
We recognized amortization expense of $43.2 million and $128.8 million for the three and nine months ended April 30, 2025, respectively, and $33.4 million and $86.7 million for the three and nine months ended April 30, 2024, respectively.

[0001327567-25-000017:notes:82]
The following table summarizes estimated future amortization expense of our intangible assets subject to amortization as of April 30, 2025 (in millions):

[0001327567-25-000017:notes:83]
|  |  |  | Fiscal years ending July 31, |
|  | Total |  | Remaining 2025 |  | 2026 |  | 2027 |  | 2028 |  | 2029 |  | 2030 and Thereafter |
| Future amortization expense | $ | 730.2 |  |  | $ | 37.5 |  |  | $ | 141.9 |  |  | $ | 111.0 |  |  | $ | 90.1 |  |  | $ | 64.2 |  |  | $ | 285.5 |  |


## us-gaap:DebtDisclosureTextBlock

[0001327567-25-000017:notes:84]
Debt
Convertible Senior Notes

[0001327567-25-000017:notes:85]
In June 2020, we issued $2.0 billion aggregate principal amount of 0.375% Convertible Senior Notes due 2025 (the “2025 Notes”). The 2025 Notes bear interest at a fixed rate of 0.375% per year, payable semi-annually in arrears on June 1 and December 1 of each year, beginning on December 1, 2020. The 2025 Notes are governed by an indenture between us, as the issuer, and U.S. Bank National Association, as Trustee (the “Indenture”). The 2025 Notes are unsecured, unsubordinated obligations and the Indenture governing the 2025 Notes does not contain any financial covenants or restrictions on the payments of dividends, the incurrence of indebtedness, or the issuance or repurchase of securities by us or any of our subsidiaries. The 2025 Notes mature on June 1, 2025. We may redeem for cash all or any portion of the 2025 Notes, at our option, on or after June 5, 2023 and prior to the 31st scheduled trading day immediately preceding the maturity date if the last reported sale price of our common stock has been at least 130% of the conversion price then in effect for at least 20 trading days during any 30 consecutive trading day period ending on and including the trading day preceding the date on which we provide notice of redemption. The redemption will be at a price equal to 100% of the principal amount of the 2025 Notes and adjusted for interest. If we call any or all of the 2025 Notes for redemption, holders may convert such 2025 Notes called for redemption at any time prior to the close of business on the second scheduled trading day immediately preceding the redemption date.

[0001327567-25-000017:notes:86]
The 2025 Notes are convertible for an initial 40.3 million shares of our common stock at a conversion rate of approximately 20.1612 shares of common stock per $1,000 principal amount, which is equal to an initial conversion price of approximately $49.60 per share of common stock, subject to adjustments. Holders of the 2025 Notes may surrender their 2025 Notes for conversion at their option at any time prior to the close of business on the business day immediately preceding March 1, 2025 only under the following circumstances:

[0001327567-25-000017:notes:87]
•during any fiscal quarter commencing after the fiscal quarters ending on October 31, 2020 (and only during such fiscal quarter), if the last reported sale price of our common stock for at least 20 trading days (whether or not consecutive) during a period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the conversion price for the 2025 Notes on each applicable trading day (the “sale price condition”);

[0001327567-25-000017:notes:88]
•during the five business day period after any five consecutive trading day period (the “measurement period”) in which the trading price per $1,000 principal amount of the 2025 Notes for each trading day of the measurement period was less than 98% of the product of the last reported sale price of our common stock and the conversion rate for the 2025 Notes on each such trading day; or

[0001327567-25-000017:notes:89]
•upon the occurrence of specified corporate events.

[0001327567-25-000017:notes:90]
On or after March 1, 2025, holders may surrender all or any portion of their 2025 Notes for conversion at any time prior to the close of business on the second scheduled trading day immediately preceding the maturity date regardless of the foregoing conditions, and such conversions will be settled upon the maturity date. Upon conversion, holders of the 2025 Notes will receive cash equal to the aggregate principal amount of the 2025 Notes to be converted, and, at our election, cash and/or shares of our common stock for any amounts in excess of the aggregate principal amount of the 2025 Notes being converted.

[0001327567-25-000017:notes:91]
The conversion price will be subject to adjustment in some events. Holders of the 2025 Notes who convert their 2025 Notes in connection with certain corporate events that constitute a “make-whole fundamental change” under the Indenture are, under certain circumstances, entitled to an increase in the conversion rate. Additionally, upon the occurrence of a corporate event that constitutes a “fundamental change” under the Indenture, holders of the 2025 Notes may require us to repurchase for cash all or a portion of the 2025 Notes at a repurchase price equal to 100% of the principal amount of the 2025 Notes plus accrued and unpaid interest to, but excluding, the fundamental change repurchase date.

[0001327567-25-000017:notes:92]
Holders of the 2025 Notes were able to early convert their 2025 Notes at any time prior to the close of business on the business day immediately preceding March 1, 2025 for settlement prior to the maturity date as the sales price condition had been met during the fiscal quarter ended January 31, 2025. During the three and nine months ended April 30, 2025, holders of the 2025 Notes converted $150.9 million and $582.3 million, respectively, in aggregate principal amount of the 2025 Notes, which we repaid in cash. We also issued 2.2 million and 8.4 million shares of our common stock to the holders of the 2025 Notes during the three and nine months ended April 30, 2025, respectively, for the conversion value in excess of the principal amount. During the three and nine months ended April 30, 2024, holders of the 2025 Notes converted $661.8 million and $834.1 million, respectively, in aggregate principal amount of the 2025 Notes, which we repaid in cash. We also issued 9.1 million and 11.3 million shares of our common stock to the holders of the 2025 Notes during the three and nine months ended April 30, 2024, respectively, for the conversion value in excess of the principal amount. These shares were fully offset by shares we received from the corresponding exercise of the note hedges.

[0001327567-25-000017:notes:93]
On or after March 1, 2025, holders may surrender their 2025 Notes for conversion at any time prior to maturity, in accordance with the terms described above. Such conversion requests will settle upon maturity of the 2025 Notes. The net carrying amount of the 2025 Notes was classified as a current liability on our condensed consolidated balance sheet as of April 30, 2025.

[0001327567-25-000017:notes:94]
The following table sets forth the net carrying amount of our 2025 Notes (in millions):

[0001327567-25-000017:notes:95]
|  | April 30, 2025 |  | July 31, 2024 |
| Principal | $ | 383.3 |  |  | $ | 965.6 |  |
| Less: debt issuance costs, net of amortization | (0.1) |  |  | (1.7) |  |
| Net carrying amount | $ | 383.2 |  |  | $ | 963.9 |  |

[0001327567-25-000017:notes:96]
The total estimated fair value of the 2025 Notes was $1.4 billion as of April 30, 2025 and $3.2 billion as of July 31, 2024. The fair value was determined based on the closing trading price per $100 of the 2025 Notes as of the last day of trading for the period. We consider the fair value of the 2025 Notes as of April 30, 2025 and July 31, 2024 to be a Level 2 measurement. The fair value of the 2025 Notes is primarily affected by the trading price of our common stock and market interest rates.

[0001327567-25-000017:notes:97]
The following table sets forth interest expense recognized related to the 2025 Notes (dollars in millions):

[0001327567-25-000017:notes:98]
|  | Three Months Ended April 30, |  | Nine Months Ended April 30, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Contractual interest expense | $ | 0.5 |  |  | $ | 1.5 |  |  | $ | 1.8 |  |  | $ | 5.1 |  |
| Amortization of debt issuance costs | 0.2 |  |  | 0.8 |  |  | 1.0 |  |  | 2.9 |  |
| Total interest expense | $ | 0.7 |  |  | $ | 2.3 |  |  | $ | 2.8 |  |  | $ | 8.0 |  |
| Effective interest rate | 0.6 | % |  | 0.6 | % |  | 0.6 | % |  | 0.6 | % |

[0001327567-25-000017:notes:99]
Note Hedges

[0001327567-25-000017:notes:100]
To minimize the impact of potential economic dilution upon conversion of our convertible senior notes, we entered into separate convertible note hedge transactions (the “2025 Note Hedges”) with respect to our common stock concurrent with the issuance of the 2025 Notes.

[0001327567-25-000017:notes:101]
The 2025 Note Hedges cover up to 40.3 million shares of our common stock at a strike price per share that corresponds to the initial conversion price of the 2025 Notes, which are also subject to adjustment, and are exercisable upon conversion of the 2025 Notes. The 2025 Note Hedges will expire upon maturity of the 2025 Notes. The 2025 Note Hedges are separate transactions and are not part of the terms of the 2025 Notes. Holders of the 2025 Notes will not have any rights with respect to the 2025 Note Hedges. Any shares of our common stock receivable by us under the 2025 Note Hedges are excluded from the calculation of diluted earnings per share as they are antidilutive. We paid an aggregate amount of $370.8 million for the 2025 Note Hedges, which is included in additional paid-in capital on our condensed consolidated balance sheets.

[0001327567-25-000017:notes:102]
As a result of the conversions of the 2025 Notes settled during the three and nine months ended April 30, 2025, we exercised the corresponding portion of our 2025 Note Hedges and received 2.2 million and 8.4 million shares of our common stock during the respective periods. As a result of the conversions of the 2025 Notes settled during the three and nine months ended April 30, 2024, we exercised the corresponding portion of our 2025 Note Hedges and received 9.1 million and 11.3 million shares of our common stock during the respective periods.

[0001327567-25-000017:notes:103]
Warrants

[0001327567-25-000017:notes:104]
Separately, but concurrently with the issuance of each series of our convertible senior notes, we entered into transactions whereby we sold warrants (the “2023 Warrants,” with respect to the 0.75% convertible senior notes due 2023 issued in July 2018, the “2025 Warrants,” with respect to the 2025 Notes, and the 2023 Warrants together with the 2025 Warrants, the “Warrants”) to acquire shares of our common stock, subject to anti-dilution adjustments. The 2023 Warrants were, and the 2025 Warrants are, exercisable over 60 scheduled trading days beginning October 2023 and September 2025, respectively.

[0001327567-25-000017:notes:105]
The following table presents details of our Warrants (in millions, except per share data):

[0001327567-25-000017:notes:106]
|  | Initial Number of Shares |  | Strike Price per Share |  | Aggregate Proceeds |
| 2023 Warrants (1) | 38.1 |  |  | $ | 69.63 |  |  | $ | 145.4 |  |
| 2025 Warrants | 40.3 |  |  | $ | 68.08 |  |  | $ | 202.8 |  |

[0001327567-25-000017:notes:107]
(1)The 2023 Warrants were net settled during the 60 scheduled trading days from October to December 2023.

[0001327567-25-000017:notes:108]
The shares issuable under the Warrants are included in the calculation of diluted earnings per share when the average market value per share of our common stock for the reporting period exceeds the applicable strike price for such series of Warrants. The Warrants are separate transactions and are not part of either series of Notes or Note Hedges and are not remeasured through earnings each reporting period. Holders of the Notes of either series will not have any rights with respect to the Warrants. The aggregate proceeds received from the sale of the Warrants are included in additional paid-in capital on our condensed consolidated balance sheets.

[0001327567-25-000017:notes:109]
During the nine months ended April 30, 2024, we net settled all of the 2023 Warrants with 18.0 million shares of our common stock with a fair value of $2.4 billion. The number of net shares issued was determined based on the number of 2023 Warrants exercised multiplied by the difference between the strike price of the 2023 Warrants and their daily volume-weighted-average stock price.

[0001327567-25-000017:notes:110]
Revolving Credit Facility

[0001327567-25-000017:notes:111]
On April 13, 2023, we entered into a credit agreement (the “Credit Agreement”) with certain institutional lenders that provides for a $400.0 million unsecured revolving credit facility (the “Credit Facility”), with an option to increase the amount of the Credit Facility by up to an additional $350.0 million, subject to certain conditions. The Credit Facility matures on April 13, 2028.

[0001327567-25-000017:notes:112]
The borrowings under the Credit Facility bear interest, at our option, at a base rate plus a spread of 0.000% to 0.375%, or an adjusted term Secured Overnight Financing Rate (“SOFR”) plus a spread of 1.000% to 1.375%, in each case with such spread being determined based on our leverage ratio. We are obligated to pay an ongoing commitment fee on undrawn amounts at a rate of 0.090% to 0.150%, depending on our leverage ratio. The interest rates and commitment fees are also subject to upward and downward adjustments based on our progress towards the achievement of certain sustainability goals related to greenhouse gas emissions.

[0001327567-25-000017:notes:113]
As of April 30, 2025, there were no amounts outstanding and we were in compliance with all covenants under the Credit Agreement.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001327567-25-000017:notes:114]
Commitments and Contingencies
Purchase Commitments

[0001327567-25-000017:notes:115]
We have entered into various non-cancelable agreements with cloud service providers, under which we are committed to minimum or fixed purchases of certain cloud services. In addition, in order to reduce manufacturing lead times and plan for adequate supply, we have entered into agreements with manufacturing partners and component suppliers to procure inventory based on our demand forecasts. Other purchase obligations include non-cancellable subscription agreements and other commitments in the normal course of business. The following table presents details of the aggregate future non-cancelable purchase commitments under these agreements as of April 30, 2025 (in millions):

[0001327567-25-000017:notes:116]
|  |  |  | Fiscal years ending July 31, |
|  | Total |  | Remaining 2025 |  | 2026 |  | 2027 |  | 2028 |  | 2029 |  | 2030 and Thereafter |
| Cloud | $ | 3,797.2 |  |  | $ | 64.1 |  |  | $ | 137.2 |  |  | $ | 518.1 |  |  | $ | 599.8 |  |  | $ | 685.3 |  |  | $ | 1,792.7 |  |
| Manufacturing | 196.7 |  |  | 61.5 |  |  | 135.2 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Other | 213.0 |  |  | 37.1 |  |  | 104.3 |  |  | 57.9 |  |  | 6.8 |  |  | 3.4 |  |  | 3.5 |  |
| Total purchase commitments | $ | 4,206.9 |  |  | $ | 162.7 |  |  | $ | 376.7 |  |  | $ | 576.0 |  |  | $ | 606.6 |  |  | $ | 688.7 |  |  | $ | 1,796.2 |  |

[0001327567-25-000017:notes:117]
Additionally, we have a $127.3 million minimum purchase commitment with a cloud service provider through September 2027 with no specified annual commitments.

[0001327567-25-000017:notes:118]
Litigation

[0001327567-25-000017:notes:119]
We are subject to legal proceedings, claims, tax matters, and litigation arising in the ordinary course of business, including, for instance, intellectual property and patent litigation. We accrue for contingencies when we believe that a loss is probable and that we can reasonably estimate the amount of any such loss.

[0001327567-25-000017:notes:120]
Legal matters could include speculative, substantial, or indeterminate monetary amounts. Significant judgment is required to determine both the likelihood of there being a loss and the estimated amount of a loss related to such matters, and we may be unable to estimate the reasonably possible loss or range of loss. The outcomes of outstanding legal matters are inherently unpredictable, and could, either individually or in aggregate, have a material adverse effect on us and our results of operations. To the extent there is a reasonable possibility that a loss exceeding any amounts already recognized may be incurred, we will either disclose the estimated additional loss or state that such an estimate cannot be made.

[0001327567-25-000017:notes:121]
The following matters arose in the ordinary course of business.

[0001327567-25-000017:notes:122]
Centripetal Networks, Inc. v. Palo Alto Networks

[0001327567-25-000017:notes:123]
On March 12, 2021, Centripetal Networks, Inc., filed a lawsuit against us in the United States District Court for the Eastern District of Virginia. The lawsuit alleges that our products infringe multiple Centripetal patents. We successfully challenged certain of these patents, which were found unpatentable by the U.S. Patent and Trademark Office (“PTO”). The case went to jury trial on January 22, 2024, on four patents. On January 31, 2024, the jury returned a verdict of non-willful infringement with a lump sum amount of $151.5 million, plus statutory interest. After post-trial motions, a judgment was issued on October 3, 2024 affirming infringement on three patents, reversing infringement on the fourth patent, and subsequently, reducing the damages amount to $113.6 million. We posted a surety bond that was agreed upon by the parties and approved by the court. This bond prevents execution of the judgment while appeals are pending. In addition, Centripetal filed infringement contentions on certain of their patents in the European Patent Office in Germany, to which we filed invalidity challenges. Those matters are still pending.

[0001327567-25-000017:notes:124]
As of July 31, 2024, we accrued $184.4 million for the verdict amount and estimated interest. As of April 30, 2025, we accrued $144.1 million based on the judgment and estimated interest, which is recorded in other long-term liabilities on our condensed consolidated balance sheets. The corresponding amount was a charge of $1.3 million for the three months ended April 30, 2025, and a release of $40.3 million for the nine months ended April 30, 2025, which is included in general and administrative expense on our condensed consolidated statements of operations.

[0001327567-25-000017:notes:125]
Finjan, Inc. v. Palo Alto Networks
On November 4, 2014, Finjan, Inc., filed a lawsuit against us in the United States District Court for the Northern District of California. The lawsuit alleges that our products infringe multiple Finjan patents. The complaint requests injunctive relief, monetary damages, and attorneys’ fees. On March 21, 2025, the judge issued an order granting summary judgment of non-infringement on all remaining patents at issue. Plaintiff filed a Notice of Appeal on April 21, 2025. We are unable, at this time, to reasonably estimate a possible loss or potential range of loss, if any.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001327567-25-000017:notes:126]
[same as prior period, unchanged from 0001327567-25-000010:notes:122]

[0001327567-25-000017:notes:127]
[same as prior period, unchanged from 0001327567-25-000010:notes:123]

[0001327567-25-000017:notes:128]
We did not repurchase shares of our common stock during the three and nine months ended April 30, 2025. During the three and nine months ended April 30, 2024, we repurchased and retired 3.4 million and 4.0 million shares of our common stock under our current repurchase authorization for an aggregate purchase price of $500.0 million and $566.7 million, including transaction costs, at an average price of $146.96 and $142.00 per share, respectively.

[0001327567-25-000017:notes:129]
As of April 30, 2025, $1.0 billion remained available for future share repurchases under our current repurchase authorization. The total price of the shares repurchased and related transaction costs are reflected as a reduction to common stock and additional paid-in capital on our condensed consolidated balance sheets.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001327567-25-000017:notes:130]
[same as prior period, unchanged from 0001327567-25-000010:notes:126]

[0001327567-25-000017:notes:131]
The following table summarizes the RSU and PSU activity under our stock plans during the nine months ended April 30, 2025 (in millions, except per share amounts):

[0001327567-25-000017:notes:132]
|  | Unvested RSUs |  | Unvested PSUs |
|  | Number of Shares |  | Weighted-Average Grant-Date Fair Value Per Share |  |  |  | Aggregate Intrinsic Value |  | Number of Shares |  | Weighted-Average Grant-Date Fair Value Per Share |  |  |  | Aggregate Intrinsic Value |
| Balance—July 31, 2024 | 18.0 |  |  | $ | 102.59 |  |  |  |  | $ | 2,924.4 |  |  | 10.0 |  |  | $ | 77.95 |  |  |  |  | $ | 1,624.2 |  |
| Granted(1) | 5.0 |  |  | $ | 188.95 |  |  |  |  |  |  | 3.8 |  |  | $ | 201.59 |  |  |  |  |  |
| Vested(2) | (6.8) |  |  | $ | 92.64 |  |  |  |  |  |  | (1.2) |  |  | $ | 64.51 |  |  |  |  |  |
| Forfeited | (1.6) |  |  | $ | 111.29 |  |  |  |  |  |  | (3.2) |  |  | $ | 91.73 |  |  |  |  |  |
| Balance—April 30, 2025 | 14.6 |  |  | $ | 135.64 |  |  |  |  | $ | 2,721.3 |  |  | 9.4 |  |  | $ | 140.92 |  |  |  |  | $ | 1,765.5 |  |

[0001327567-25-000017:notes:133]
[same as prior period, unchanged from 0001327567-25-000010:notes:129]

[0001327567-25-000017:notes:134]
[same as prior period, unchanged from 0001327567-25-000010:notes:130]

[0001327567-25-000017:notes:135]
[same as prior period, unchanged from 0001327567-25-000010:notes:131]

[0001327567-25-000017:notes:136]
[same as prior period, unchanged from 0001327567-25-000010:notes:132]

[0001327567-25-000017:notes:137]
During the nine months ended April 30, 2025, we granted 3.4 million shares of PSUs that contain service, performance, and market conditions. The service conditions are satisfied after a period of one to three years. The performance conditions are based on an average of next-generation security annualized recurring revenue and non-GAAP net income per diluted share. The market condition is measured based on our total shareholder return (“TSR”) relative to the TSR of the companies listed in the Standard & Poor’s 500 index. As of April 30, 2025, we have approved 2.7 million shares of PSUs, which will be granted upon the performance condition being established during the next two fiscal years.

[0001327567-25-000017:notes:138]
The fair value of the PSUs subject to market conditions is estimated on the grant date using a Monte Carlo simulation model. The following table summarizes the assumptions used and the resulting grant-date fair value of our PSUs subject to market conditions granted during the nine months ended April 30, 2025 and 2024:

[0001327567-25-000017:notes:139]
|  |  |  | Nine Months Ended April 30, |
|  |  |  |  |  | 2025 |  | 2024 |
| Volatility |  |  |  |  | 43.5% - 47.6% |  | 40.8% - 43.4% |
| Expected term (in years) |  |  |  |  | 1.0 - 2.9 |  | 0.9 - 2.9 |
| Dividend yield |  |  |  |  | 0.0 | % |  | 0.0 | % |
| Risk-free interest rate |  |  |  |  | 3.7% - 4.5% |  | 4.4% - 5.3% |
| Grant-date fair value per share |  |  |  |  | $264.51 - $305.83 |  | $173.46 - $310.61 |

[0001327567-25-000017:notes:140]
[same as prior period, unchanged from 0001327567-25-000010:notes:136]

[0001327567-25-000017:notes:141]
We have granted PSOs with both service and market conditions. The market conditions were achieved when certain stock price targets were met. As of April 30, 2025, all of our outstanding PSOs have been fully vested. The maximum contractual term of our outstanding PSOs is seven and a half years from the date of grant in fiscal year 2018 and 2019.

[0001327567-25-000017:notes:142]
The following table summarizes the PSO activity under our stock plans during the nine months ended April 30, 2025 (in millions, except per share amounts):

[0001327567-25-000017:notes:143]
|  |  |  |  |  |  |  |  |  | Number of Shares |  | Weighted-Average Exercise Price Per Share |  | Weighted-Average Remaining Contractual Term (Years) |  | Aggregate Intrinsic Value |
| Balance—July 31, 2024 |  |  |  |  |  |  |  |  | 9.6 |  |  | $ | 32.66 |  |  | 1.2 |  | $ | 1,244.9 |  |
| Exercised |  |  |  |  |  |  |  |  | (7.9) |  |  | $ | 32.66 |  |  |  |  |  |
| Balance—April 30, 2025 |  |  |  |  |  |  |  |  | 1.7 |  |  | $ | 32.67 |  |  | 0.8 |  | $ | 258.3 |  |
| Exercisable—April 30, 2025 |  |  |  |  |  |  |  |  | 1.7 |  |  | $ | 32.67 |  |  | 0.8 |  | $ | 258.3 |  |

[0001327567-25-000017:notes:144]
[same as prior period, unchanged from 0001327567-25-000010:notes:140]

[0001327567-25-000017:notes:145]
[same as prior period, unchanged from 0001327567-25-000010:notes:141]

[0001327567-25-000017:notes:146]
|  | Three Months Ended April 30, |  | Nine Months Ended April 30, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Cost of product revenue | $ | 1.2 |  |  | $ | 1.6 |  |  | $ | 3.8 |  |  | $ | 6.3 |  |
| Cost of subscription and support revenue | 32.2 |  |  | 30.0 |  |  | 94.9 |  |  | 91.3 |  |
| Research and development | 133.4 |  |  | 128.2 |  |  | 410.8 |  |  | 386.9 |  |
| Sales and marketing | 91.6 |  |  | 74.3 |  |  | 258.2 |  |  | 229.1 |  |
| General and administrative | 67.5 |  |  | 29.4 |  |  | 173.0 |  |  | 96.2 |  |
| Total share-based compensation | $ | 325.9 |  |  | $ | 263.5 |  |  | $ | 940.7 |  |  | $ | 809.8 |  |

[0001327567-25-000017:notes:147]
As of April 30, 2025, total compensation cost related to unvested share-based awards not yet recognized was $2.4 billion. This cost is expected to be amortized over a weighted-average period of approximately 2.5 years.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001327567-25-000017:notes:148]
Income Taxes
For the three and nine months ended April 30, 2025, our provision for income taxes reflected effective tax rates of 15.6% and 12.3%, respectively. Our income taxes for the three and nine months ended April 30, 2025 were primarily due to U.S. and foreign income taxes. Our effective tax rates for the three and nine months ended April 30, 2025 differed from the U.S. statutory tax rate primarily due to excess tax benefits from share-based compensation.

[0001327567-25-000017:notes:149]
For the three and nine months ended April 30, 2024, our benefit from income taxes reflected effective tax rates of negative 11.0% and negative 231.7%, respectively. Our effective tax rate for the three months ended April 30, 2024 differed from the U.S. statutory tax rate primarily due to excess tax benefits from share-based compensation and the release of our valuation allowance on U.S. federal, U.S. states other than California, and United Kingdom (“U.K.”) deferred tax assets. Our effective tax rate for the nine months ended April 30, 2024 differed from the U.S. statutory tax rate primarily due to the release of our valuation allowance on U.S. federal, U.S. states other than California, and U.K. deferred tax assets.
As a result of the valuation allowance release, during the three and nine months ended April 30, 2024, we recognized a deferred tax benefit of $40.0 million and $3.3 billion, respectively, for the U.S. federal, U.S. states other than California, and U.K. deferred tax assets. In addition, during the three and nine months ended April 30, 2024, we recognized a deferred tax expense of $7.4 million and $1.7 billion, respectively, for the U.S. federal indirect tax effect of foreign deferred taxes consistent with our policy to record deferred taxes for basis differences relating to our global intangible low-taxed income. Accordingly, during the three and nine months ended April 30, 2024, we recognized a net tax benefit of $32.6 million and $1.6 billion, respectively, relating to our valuation allowance release.


## us-gaap:EarningsPerShareTextBlock

[0001327567-25-000017:notes:150]
[same as prior period, unchanged from 0001327567-25-000010:notes:146]

[0001327567-25-000017:notes:151]
[same as prior period, unchanged from 0001327567-25-000010:notes:147]

[0001327567-25-000017:notes:152]
|  | Three Months Ended April 30, |  | Nine Months Ended April 30, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Net income | $ | 262.1 |  |  | $ | 278.8 |  |  | $ | 880.1 |  |  | $ | 2,219.9 |  |
| Weighted-average shares used to compute net income per share, basic | 665.1 |  |  | 645.8 |  |  | 659.3 |  |  | 635.0 |  |
| Weighted-average effect of potentially dilutive securities: |  |  |  |  |  |  |  |
| Convertible senior notes | 6.6 |  |  | 19.1 |  |  | 9.1 |  |  | 22.8 |  |
| Warrants related to the issuance of convertible senior notes | 25.1 |  |  | 22.1 |  |  | 25.2 |  |  | 26.5 |  |
| Employee equity incentive plans | 10.6 |  |  | 22.3 |  |  | 15.0 |  |  | 23.7 |  |
| Weighted-average shares used to compute net income per share, diluted | 707.4 |  |  | 709.3 |  |  | 708.6 |  |  | 708.0 |  |
| Net income per share, basic | $ | 0.39 |  |  | $ | 0.43 |  |  | $ | 1.33 |  |  | $ | 3.50 |  |
| Net income per share, diluted | $ | 0.37 |  |  | $ | 0.39 |  |  | $ | 1.24 |  |  | $ | 3.14 |  |

[0001327567-25-000017:notes:153]
[same as prior period, unchanged from 0001327567-25-000010:notes:149]

[0001327567-25-000017:notes:154]
|  | Three Months Ended April 30, |  | Nine Months Ended April 30, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Employee equity incentive plans | 4.0 |  |  | 4.8 |  |  | 4.5 |  |  | 4.9 |  |


## us-gaap:OtherNonoperatingIncomeAndExpenseTextBlock

[0001327567-25-000017:notes:155]
[same as prior period, unchanged from 0001327567-25-000010:notes:151]

[0001327567-25-000017:notes:156]
|  | Three Months Ended April 30, |  | Nine Months Ended April 30, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Interest income | $ | 92.8 |  |  | $ | 78.3 |  |  | $ | 265.4 |  |  | $ | 234.8 |  |
| Foreign currency exchange gains (losses), net | (8.2) |  |  | 4.3 |  |  | (13.3) |  |  | 2.9 |  |
| Other, net | 7.8 |  |  | (5.8) |  |  | 8.9 |  |  | (5.9) |  |
| Total other income, net | $ | 92.4 |  |  | $ | 76.8 |  |  | $ | 261.0 |  |  | $ | 231.8 |  |


## ecd:MtrlTermsOfTrdArrTextBlock

[0001327567-25-000017:notes:157]
Set forth below is certain information regarding Rule 10b5-1 trading plans adopted or terminated by our directors and officers (as defined in Rule 16a-1(f)) during the third quarter of fiscal 2025. The Rule 10b5-1 trading plans listed below are each intended to satisfy the affirmative defense of Rule 10b5-1(c).

[0001327567-25-000017:notes:158]
| Name |  | Title |  | Date Plan Was Adopted |  | Date Plan Was Terminated |  | Original Expiration Date |  | Total Amount of Common Stock to Be Sold Under the Plan |
| Nikesh Arora |  | Chief Executive Officer |  | March 27, 2024 |  | April 6, 2025 |  | December 31, 2025 |  | 4,889,520 |
