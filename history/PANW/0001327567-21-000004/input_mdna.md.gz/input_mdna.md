# PANW MD&A — 0001327567-21-000004


## mdna

[0001327567-21-000004:mdna:1]
[same as prior period, unchanged from 0001327567-20-000041:mdna:1]

[0001327567-21-000004:mdna:2]
[same as prior period, unchanged from 0001327567-20-000041:mdna:2]

[0001327567-21-000004:mdna:3]
[same as prior period, unchanged from 0001327567-20-000041:mdna:3]

[0001327567-21-000004:mdna:4]
[same as prior period, unchanged from 0001327567-20-000041:mdna:4]

[0001327567-21-000004:mdna:5]
•Results of Operations. A discussion of the nature and trends in our financial results and an analysis of our financial results comparing the three and six months ended January 31, 2021 to the three and six months ended January 31, 2020.

[0001327567-21-000004:mdna:6]
[same as prior period, unchanged from 0001327567-20-000041:mdna:6]

[0001327567-21-000004:mdna:7]
[same as prior period, unchanged from 0001327567-20-000041:mdna:7]

[0001327567-21-000004:mdna:8]
[same as prior period, unchanged from 0001327567-20-000041:mdna:8]

[0001327567-21-000004:mdna:9]
[same as prior period, unchanged from 0001327567-20-000041:mdna:9]

[0001327567-21-000004:mdna:10]
[same as prior period, unchanged from 0001327567-20-000041:mdna:10]

[0001327567-21-000004:mdna:11]
Intelligent Network Security:

[0001327567-21-000004:mdna:12]
[same as prior period, unchanged from 0001327567-20-000041:mdna:12]

[0001327567-21-000004:mdna:13]
[same as prior period, unchanged from 0001327567-20-000041:mdna:34]

[0001327567-21-000004:mdna:14]
Table of Content

[0001327567-21-000004:mdna:15]
[same as prior period, unchanged from 0001327567-20-000041:mdna:14]

[0001327567-21-000004:mdna:16]
Cloud Security:

[0001327567-21-000004:mdna:17]
•Secure the cloud through our Prisma security offerings. Prisma Cloud, the industry’s most comprehensive Cloud Native Security Platform (“CNSP”), secures multi- and hybrid-cloud environments and cloud native applications integrating security across the full deployment lifecycle. Prisma SaaS protects SaaS applications. Prisma Access, a comprehensive Secure Access Service Edge (“SASE”) offering, together with CloudGenix SD-WAN, is used to secure remote workforces and enable the cloud-delivered branch. CloudGenix SD-WAN autonomous networking and integrated security is available as a combination of physical, virtual, and cloud-delivered appliances and services. VM-Series and CN-Series enforce in-line network security in multi- and hybrid- cloud environments.

[0001327567-21-000004:mdna:18]
Security Analytics and Operations:

[0001327567-21-000004:mdna:19]
•Secure the future through our Cortex security offerings. These include Cortex XDR for prevention, detection, and response platforms to stop modern security attacks, Cortex XSOAR for security orchestration, automation, and response (“SOAR”), Expanse for attack surface management (“ASM”), Autofocus for threat intelligence, and Cortex Data Lake to collect and integrate security data for analytics. These products are delivered as software or SaaS subscriptions. In addition, Crypsis provides incident response, risk management, and digital forensics services to help and protect our customers.

[0001327567-21-000004:mdna:20]
For the second quarter of fiscal 2021 and 2020, total revenue was $1.0 billion and $816.7 million, respectively, representing year-over-year growth of 24.5%. Our growth reflects the increased adoption of our portfolio, which consists of product, subscriptions, and support. We believe our portfolio will enable us to benefit from recurring revenues as we continue to grow our installed end-customer base. As of January 31, 2021, we had end-customers in more than 170 countries. Our end-customers represent a broad range of industries including education, energy, financial services, government entities, healthcare, Internet and media, manufacturing, public sector, and telecommunications, and include some of the largest Fortune 100 and Global 2000 companies in the world. We maintain a field sales force that works closely with our channel partners in developing sales opportunities. We use a two-tiered, indirect fulfillment model whereby we sell our products, subscriptions, and support to our distributors, which, in turn, sell to our resellers, which then sell to our end-customers.

[0001327567-21-000004:mdna:21]
Our product revenue was $254.7 million, or 25.0% of total revenue, for the second quarter of fiscal 2021, representing year-over-year growth of 3.3%. Product revenue is generated from sales of our appliances, primarily our ML-powered Next-Generation Firewall, which is available in a number of form factors, including as physical, virtual, and containerized appliances. Our ML-powered Next-Generation Firewall incorporates our PAN-OS operating system, which provides a consistent set of capabilities across our entire product line. Our products are designed for different performance requirements throughout an organization, ranging from our PA-220, which is designed for small organizations and remote or branch offices, to our top-of-the-line PA-7080, which is designed for large-scale data centers and service provider use. The same firewall functionality that is delivered in our physical appliances is also available in our VM-Series virtual firewalls, which secure virtualized and cloud-based computing environments, and in our CN-Series container firewalls, which secure container environments and traffic.

[0001327567-21-000004:mdna:22]
Our subscription and support revenue grew to $762.2 million, or 75.0% of total revenue, for the second quarter of fiscal 2021, representing year-over-year growth of 33.7%. Our subscriptions provide our end-customers with near real-time access to the latest antivirus, intrusion prevention, web filtering, and modern malware prevention capabilities across the network, endpoints, and the cloud. When end-customers purchase our physical, virtual, or container firewall appliances, they typically purchase support in order to receive ongoing security updates, upgrades, bug fixes, and repairs. In addition to the subscriptions purchased with these appliances, end-customers may also purchase other subscriptions on a per-user, per-endpoint, or capacity-based basis. We also offer professional services, including incident response, risk management, and digital forensic services.

[0001327567-21-000004:mdna:23]
We continue to invest in innovation as we evolve and further extend the capabilities of our platforms, as we believe that innovation and timely development of new features and products are essential to meeting the needs of our end-customers and improving our competitive position. For example, in December 2020, we acquired Expanse Inc. (“Expanse”), which we expect will enrich our Cortex offerings and provide organizations an integrated view of the enterprise to combine external, internal, and threat data, and in November 2020 we acquired Sinefa Group, Inc. and its wholly owned subsidiaries (“Sinefa”), which we expect to extend our Prisma Access offering.

[0001327567-21-000004:mdna:24]
We believe that the growth of our business and our short-term and long-term success are dependent upon many factors, including our ability to extend our technology leadership, grow our base of end-customers, expand deployment of our portfolio and support offerings within existing end-customers, and focus on end-customer satisfaction. To manage any future growth effectively, we must continue to improve and expand our information technology and financial infrastructure, our operating and administrative systems and controls, and our ability to manage headcount, capital, and processes in an efficient manner. While these areas present significant opportunities for us, they also pose challenges and risks that we must successfully address in order to sustain the growth of

[0001327567-21-000004:mdna:25]
[same as prior period, unchanged from 0001327567-20-000041:mdna:40]

[0001327567-21-000004:mdna:26]
Table of Content

[0001327567-21-000004:mdna:27]
our business and improve our operating results. For additional information regarding the challenges and risks we face, see the “Risk Factors” section in Part II, Item 1A of this Quarterly Report on Form 10-Q.

[0001327567-21-000004:mdna:28]
[same as prior period, unchanged from 0001327567-20-000041:mdna:25]

[0001327567-21-000004:mdna:29]
We are actively monitoring, evaluating, and responding to developments relating to COVID-19, which has and is expected to result in continued significant global, social, and business disruption. While we instituted a global work-from-home policy beginning in March 2020, we did not incur significant disruptions in our work operations during the second quarter of fiscal 2021. We are conducting business as usual with restrictions to employee travel and have transitioned in-person marketing events to virtual formats, among other modifications. These changes will substantially remain in effect in the third quarter of fiscal 2021, and are likely to extend to future quarters. We will continue to actively monitor the situation, including progress made through vaccinations, and will make further changes to our business operations as may be required by federal, state, or local authorities or that we determine are in the best interests of our employees, end-customers, partners, suppliers, and stockholders. Our focus remains on the safety of our employees, striving to protect the health and well-being of the communities in which we operate, and providing technology to our employees, end-customers, and partners to help them do their best work while remote.

[0001327567-21-000004:mdna:30]
[same as prior period, unchanged from 0001327567-20-000041:mdna:27]

[0001327567-21-000004:mdna:31]
[same as prior period, unchanged from 0001327567-20-000041:mdna:28]

[0001327567-21-000004:mdna:32]
[same as prior period, unchanged from 0001327567-20-000041:mdna:29]

[0001327567-21-000004:mdna:33]
|  | January 31, 2021 |  | July 31, 2020 |
|  | (in millions) |
| Total deferred revenue | $ | 4,162.4 |  |  | $ | 3,810.2 |  |
| Cash, cash equivalents, and investments | $ | 4,028.3 |  |  | $ | 4,302.2 |  |

[0001327567-21-000004:mdna:34]
|  | Three Months Ended January 31, |  | Six Months Ended January 31, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
|  | (dollars in millions) |
| Total revenue | $ | 1,016.9 |  |  | $ | 816.7 |  |  | $ | 1,962.9 |  |  | $ | 1,588.6 |  |
| Total revenue year-over-year percentage increase | 24.5 | % |  | 14.8 | % |  | 23.6 | % |  | 16.2 | % |
| Gross margin | 69.8 | % |  | 71.5 | % |  | 70.2 | % |  | 71.6 | % |
| Operating loss | $ | (88.8) |  |  | $ | (52.9) |  |  | $ | (133.3) |  |  | $ | (104.7) |  |
| Operating margin | (8.7) | % |  | (6.5) | % |  | (6.8) | % |  | (6.6) | % |
| Billings | 1,214.7 |  |  | $ | 998.9 |  |  | 2,297.5 |  |  | $ | 1,896.3 |  |
| Billings year-over-year percentage increase | 21.6 | % |  | 17.2 | % |  | 21.2 | % |  | 17.7 | % |
| Cash flow provided by operating activities |  |  |  |  | $ | 899.4 |  |  | $ | 532.1 |  |
| Free cash flow (non-GAAP) |  |  |  |  | $ | 837.7 |  |  | $ | 435.8 |  |

[0001327567-21-000004:mdna:35]
[same as prior period, unchanged from 0001327567-20-000041:mdna:32]

[0001327567-21-000004:mdna:36]
•Billings. We define billings as total revenue plus the change in total deferred revenue, net of acquired deferred revenue, during the period. We consider billings to be a key metric used by management to manage our business, and believe billings provides investors with an important indicator of the health and visibility of our business because it includes subscription and support revenue, which is recognized ratably over the contractual service period, and product revenue,

[0001327567-21-000004:mdna:37]
[same as prior period, unchanged from 0001327567-20-000041:mdna:49]

[0001327567-21-000004:mdna:38]
Table of Content

[0001327567-21-000004:mdna:39]
which is recognized at the time of shipment, provided that all other conditions for revenue recognition have been met. We consider billings to be a useful metric for management and investors, particularly if we continue to experience increased sales of subscriptions and strong renewal rates for subscription and support offerings, and as we monitor our near-term cash flows. While we believe that billings provides useful information to investors and others in understanding and evaluating our operating results in the same manner as our management, it is important to note that other companies, including companies in our industry, may not use billings, may calculate billings differently, may have different billing frequencies, or may use other financial measures to evaluate their performance, all of which could reduce the usefulness of billings as a comparative measure. We calculate billings in the following manner:

[0001327567-21-000004:mdna:40]
|  | Three Months Ended January 31, |  | Six Months Ended January 31, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
|  | (in millions) |  | (in millions) |
| Billings: |  |  |  |  |  |  |  |
| Total revenue | $ | 1,016.9 |  |  | $ | 816.7 |  |  | $ | 1,962.9 |  |  | $ | 1,588.6 |  |
| Add: change in total deferred revenue, net of acquired deferred revenue | 197.8 |  |  | 182.2 |  |  | 334.6 |  |  | 307.7 |  |
| Billings | $ | 1,214.7 |  |  | $ | 998.9 |  |  | $ | 2,297.5 |  |  | $ | 1,896.3 |  |

[0001327567-21-000004:mdna:41]
[same as prior period, unchanged from 0001327567-20-000041:mdna:37]

[0001327567-21-000004:mdna:42]
[same as prior period, unchanged from 0001327567-20-000041:mdna:38]

[0001327567-21-000004:mdna:43]
|  | Six Months Ended January 31, |
|  | 2021 |  | 2020 |
|  | (in millions) |
| Free cash flow (non-GAAP): |  |  |  |
| Net cash provided by operating activities | $ | 899.4 |  |  | $ | 532.1 |  |
| Less: purchases of property, equipment, and other assets | 61.7 |  |  | 96.3 |  |
| Free cash flow (non-GAAP) | $ | 837.7 |  |  | $ | 435.8 |  |
| Net cash provided by (used in) investing activities | $ | (1,270.6) |  |  | $ | 680.9 |  |
| Net cash used in financing activities | $ | (469.9) |  |  | $ | (173.2) |  |

[0001327567-21-000004:mdna:44]
[same as prior period, unchanged from 0001327567-20-000041:mdna:63]

[0001327567-21-000004:mdna:45]
Table of Content

[0001327567-21-000004:mdna:46]
[same as prior period, unchanged from 0001327567-20-000041:mdna:41]

[0001327567-21-000004:mdna:47]
[same as prior period, unchanged from 0001327567-20-000041:mdna:42]

[0001327567-21-000004:mdna:48]
|  | Three Months Ended January 31, |  | Six Months Ended January 31, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
|  | Amount |  | % of Revenue |  | Amount |  | % of Revenue |  | Amount |  | % of Revenue |  | Amount |  | % of Revenue |
|  | (dollars in millions) |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 254.7 |  | 25.0 | % |  | $ | 246.5 |  |  | 30.2 | % |  | $ | 492.0 |  | 25.1 | % |  | $ | 477.7 |  |  | 30.1 | % |
| Subscription and support | 762.2 |  | 75.0 | % |  | 570.2 |  |  | 69.8 | % |  | 1,470.9 |  | 74.9 | % |  | 1,110.9 |  |  | 69.9 | % |
| Total revenue | 1,016.9 |  | 100.0 | % |  | 816.7 |  |  | 100.0 | % |  | 1,962.9 |  | 100.0 | % |  | 1,588.6 |  |  | 100.0 | % |
| Cost of revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product | 75.6 |  | 7.4 | % |  | 68.7 |  |  | 8.4 | % |  | 137.8 |  | 7.0 | % |  | 133.8 |  |  | 8.4 | % |
| Subscription and support | 232.0 |  | 22.8 | % |  | 164.4 |  |  | 20.1 | % |  | 447.6 |  | 22.8 | % |  | 317.0 |  |  | 20.0 | % |
| Total cost of revenue(1) | 307.6 |  | 30.2 | % |  | 233.1 |  |  | 28.5 | % |  | 585.4 |  | 29.8 | % |  | 450.8 |  |  | 28.4 | % |
| Total gross profit | 709.3 |  | 69.8 | % |  | 583.6 |  |  | 71.5 | % |  | 1,377.5 |  | 70.2 | % |  | 1,137.8 |  |  | 71.6 | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | 266.7 |  | 26.2 | % |  | 185.4 |  |  | 22.7 | % |  | 504.1 |  | 25.7 | % |  | 355.9 |  |  | 22.4 | % |
| Sales and marketing | 427.4 |  | 42.1 | % |  | 374.9 |  |  | 46.0 | % |  | 816.0 |  | 41.6 | % |  | 740.6 |  |  | 46.6 | % |
| General and administrative | 104.0 |  | 10.2 | % |  | 76.2 |  |  | 9.3 | % |  | 190.7 |  | 9.7 | % |  | 146.0 |  |  | 9.2 | % |
| Total operating expenses(1) | 798.1 |  | 78.5 | % |  | 636.5 |  |  | 78.0 | % |  | 1,510.8 |  | 77.0 | % |  | 1,242.5 |  |  | 78.2 | % |
| Operating loss | (88.8) |  | (8.7) | % |  | (52.9) |  |  | (6.5) | % |  | (133.3) |  |  | (6.8) | % |  | (104.7) |  |  | (6.6) | % |
| Interest expense | (40.7) |  | (4.0) | % |  | (19.0) |  |  | (2.3) | % |  | (80.9) |  |  | (4.1) | % |  | (37.9) |  |  | (2.4) | % |
| Other income (expense), net | (0.5) |  | (0.1) | % |  | 10.8 |  |  | 1.3 | % |  | 1.9 |  |  | 0.1 | % |  | 27.0 |  |  | 1.7 | % |
| Loss before income taxes | (130.0) |  |  | (12.8) | % |  | (61.1) |  |  | (7.5) | % |  | (212.3) |  |  | (10.8) | % |  | (115.6) |  |  | (7.3) | % |
| Provision for income taxes | 12.3 |  |  | 1.2 | % |  | 12.6 |  |  | 1.5 | % |  | 22.2 |  |  | 1.1 | % |  | 17.7 |  |  | 1.1 | % |
| Net loss | $ | (142.3) |  |  | (14.0) | % |  | $ | (73.7) |  |  | (9.0) | % |  | $ | (234.5) |  |  | (11.9) | % |  | $ | (133.3) |  |  | (8.4) | % |

[0001327567-21-000004:mdna:49]
[same as prior period, unchanged from 0001327567-20-000041:mdna:44]

[0001327567-21-000004:mdna:50]
[same as prior period, unchanged from 0001327567-20-000041:mdna:45]

[0001327567-21-000004:mdna:51]
|  | Three Months Ended January 31, |  | Six Months Ended January 31, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
|  | (in millions) |
| Cost of product revenue | $ | 1.6 |  |  | $ | 1.6 |  |  | $ | 3.1 |  |  | $ | 2.9 |  |
| Cost of subscription and support revenue | 23.8 |  |  | 20.0 |  |  | 46.0 |  |  | 38.9 |  |
| Research and development | 103.6 |  |  | 67.0 |  |  | 199.0 |  |  | 129.4 |  |
| Sales and marketing | 69.7 |  |  | 54.9 |  |  | 134.6 |  |  | 98.7 |  |
| General and administrative | 42.4 |  |  | 29.4 |  |  | 71.3 |  |  | 54.2 |  |
| Total share-based compensation | $ | 241.1 |  |  | $ | 172.9 |  |  | $ | 454.0 |  |  | $ | 324.1 |  |

[0001327567-21-000004:mdna:52]
[same as prior period, unchanged from 0001327567-20-000041:mdna:47]

[0001327567-21-000004:mdna:53]
[same as prior period, unchanged from 0001327567-20-000041:mdna:48]

[0001327567-21-000004:mdna:54]
[same as prior period, unchanged from 0001327567-20-000041:mdna:76]

[0001327567-21-000004:mdna:55]
Table of Content

[0001327567-21-000004:mdna:56]
[same as prior period, unchanged from 0001327567-20-000041:mdna:50]

[0001327567-21-000004:mdna:57]
[same as prior period, unchanged from 0001327567-20-000041:mdna:51]

[0001327567-21-000004:mdna:58]
|  | Three Months Ended January 31, |  |  |  |  |  | Six Months Ended January 31, |  |  |  |  |
|  | 2021 |  | 2020 |  | Change |  | 2021 |  | 2020 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Product | $ | 254.7 |  |  | $ | 246.5 |  |  | $ | 8.2 |  |  | 3.3 | % |  | $ | 492.0 |  |  | $ | 477.7 |  |  | $ | 14.3 |  |  | 3.0 | % |

[0001327567-21-000004:mdna:59]
The change in product revenue for the three and six months ended January 31, 2021 compared to the same periods in 2020 represented a modest increase in product sales in both periods.

[0001327567-21-000004:mdna:60]
[same as prior period, unchanged from 0001327567-20-000041:mdna:54]

[0001327567-21-000004:mdna:61]
[same as prior period, unchanged from 0001327567-20-000041:mdna:55]

[0001327567-21-000004:mdna:62]
|  | Three Months Ended January 31, |  |  |  |  |  | Six Months Ended January 31, |  |  |  |  |
|  | 2021 |  | 2020 |  | Change |  | 2021 |  | 2020 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Subscription | $ | 461.7 |  |  | $ | 342.6 |  |  | $ | 119.1 |  |  | 34.8 | % |  | $ | 889.7 |  |  | $ | 661.2 |  |  | $ | 228.5 |  |  | 34.6 | % |
| Support | 300.5 |  |  | 227.6 |  |  | 72.9 |  |  | 32.0 | % |  | 581.2 |  |  | 449.7 |  |  | 131.5 |  |  | 29.2 | % |
| Total subscription and support | $ | 762.2 |  |  | $ | 570.2 |  |  | $ | 192.0 |  |  | 33.7 | % |  | $ | 1,470.9 |  |  | $ | 1,110.9 |  |  | $ | 360.0 |  |  | 32.4 | % |

[0001327567-21-000004:mdna:63]
Subscription and support revenue increased for the three and six months ended January 31, 2021 compared to the same periods in 2020. The increase in both periods was due to increased demand for our subscription and support offerings from both new and existing end-customers. The mix between subscription revenue and support revenue will fluctuate over time, depending on the introduction of new subscription offerings, renewals of support services, and our ability to increase sales to new and existing end-customers. The change in subscription and support revenue due to changes in pricing was not significant for either period.

[0001327567-21-000004:mdna:64]
[same as prior period, unchanged from 0001327567-20-000041:mdna:58]

[0001327567-21-000004:mdna:65]
|  | Three Months Ended January 31, |  |  |  |  |  | Six Months Ended January 31, |  |  |  |  |
|  | 2021 |  | 2020 |  | Change |  | 2021 |  | 2020 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Americas | $ | 690.9 |  |  | $ | 544.7 |  |  | $ | 146.2 |  |  | 26.8 | % |  | $ | 1,361.2 |  |  | $ | 1,074.3 |  |  | $ | 286.9 |  |  | 26.7 | % |
| EMEA | 205.8 |  |  | 166.2 |  |  | 39.6 |  |  | 23.8 | % |  | 376.7 |  |  | 313.8 |  |  | 62.9 |  |  | 20.0 | % |
| APAC | 120.2 |  |  | 105.8 |  |  | 14.4 |  |  | 13.6 | % |  | 225.0 |  |  | 200.5 |  |  | 24.5 |  |  | 12.2 | % |
| Total revenue | $ | 1,016.9 |  |  | $ | 816.7 |  |  | $ | 200.2 |  |  | 24.5 | % |  | $ | 1,962.9 |  |  | $ | 1,588.6 |  |  | $ | 374.3 |  |  | 23.6 | % |

[0001327567-21-000004:mdna:66]
With respect to geographic theaters, the increase in revenue for the three and six months ended January 31, 2021 compared to the same periods in 2020 was driven primarily by the Americas, due to its larger and more established sales force. Revenue from our other geographic theaters, both Europe, the Middle East, and Africa (“EMEA”) and Asia Pacific and Japan (“APAC”), increased for the three and six months ended January 31, 2021 compared to the same periods in 2020 due to continued investment in our global sales force in order to support our growth and innovation.

[0001327567-21-000004:mdna:67]
[same as prior period, unchanged from 0001327567-20-000041:mdna:61]

[0001327567-21-000004:mdna:68]
[same as prior period, unchanged from 0001327567-20-000041:mdna:62]

[0001327567-21-000004:mdna:69]
[same as prior period, unchanged from 0001327567-20-000041:mdna:90]

[0001327567-21-000004:mdna:70]
Table of Content

[0001327567-21-000004:mdna:71]
[same as prior period, unchanged from 0001327567-20-000041:mdna:64]

[0001327567-21-000004:mdna:72]
[same as prior period, unchanged from 0001327567-20-000041:mdna:65]

[0001327567-21-000004:mdna:73]
|  | Three Months Ended January 31, |  |  |  |  |  | Six Months Ended January 31, |  |  |  |  |
|  | 2021 |  | 2020 |  | Change |  | 2021 |  | 2020 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Cost of product revenue | $ | 75.6 |  |  | $ | 68.7 |  |  | $ | 6.9 |  |  | 10.0 | % |  | $ | 137.8 |  |  | $ | 133.8 |  |  | $ | 4.0 |  |  | 3.0 | % |
| Number of employees at period end | 118 |  |  | 111 |  |  | 7 |  |  | 6.3 | % |  | 118 |  |  | 111 |  |  | 7 |  |  | 6.3 | % |

[0001327567-21-000004:mdna:74]
Cost of product revenue increased for the three months ended January 31, 2021 compared to the same period in 2020 primarily due to an increase in inventory reserve and higher amortization of intellectual property licenses. Cost of product revenue for the six months ended January 31, 2021 was relatively flat compared to the same period in 2020.

[0001327567-21-000004:mdna:75]
[same as prior period, unchanged from 0001327567-20-000041:mdna:68]

[0001327567-21-000004:mdna:76]
[same as prior period, unchanged from 0001327567-20-000041:mdna:69]

[0001327567-21-000004:mdna:77]
|  | Three Months Ended January 31, |  |  |  |  |  | Six Months Ended January 31, |  |  |  |  |
|  | 2021 |  | 2020 |  | Change |  | 2021 |  | 2020 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Cost of subscription and support revenue | $ | 232.0 |  |  | $ | 164.4 |  |  | $ | 67.6 |  |  | 41.1 | % |  | $ | 447.6 |  |  | $ | 317.0 |  |  | $ | 130.6 |  |  | 41.2 | % |
| Number of employees at period end | 1,697 |  |  | 1,331 |  |  | 366 |  |  | 27.5 | % |  | 1,697 |  |  | 1,331 |  |  | 366 |  |  | 27.5 | % |

[0001327567-21-000004:mdna:78]
Cost of subscription and support revenue increased for the three and six months ended January 31, 2021 compared to the same periods in 2020, primarily due to increased costs to support the growth of our subscription and support offerings. Cloud hosting service costs, which support the adoption of our cloud-based subscription offerings, increased $16.7 million for the three months ended January 31, 2021 compared to the same period in 2020, and increased $42.9 million for the six months ended January 31, 2021 compared to the same period in 2020. Personnel costs grew $20.6 million to $100.2 million for the three months ended January 31, 2021 compared to the same period in 2020, and grew $34.3 million to $187.8 million for the six months ended January 31, 2021 compared to the same period in 2020, primarily due to headcount growth. The remaining increase for both the three and six month periods was primarily due to increased outside service costs for global customer support from the expansion of our customer base, and the amortization of intangible assets from our recent acquisitions.

[0001327567-21-000004:mdna:79]
[same as prior period, unchanged from 0001327567-20-000041:mdna:72]

[0001327567-21-000004:mdna:80]
[same as prior period, unchanged from 0001327567-20-000041:mdna:73]

[0001327567-21-000004:mdna:81]
|  | Three Months Ended January 31, |  | Six Months Ended January 31, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
|  | Amount |  | Gross Margin |  | Amount |  | Gross Margin |  | Amount |  | Gross Margin |  | Amount |  | Gross Margin |
|  | (dollars in millions) |
| Product | $ | 179.1 |  |  | 70.3 | % |  | $ | 177.8 |  |  | 72.1 | % |  | $ | 354.2 |  |  | 72.0 | % |  | $ | 343.9 |  |  | 72.0 | % |
| Subscription and support | 530.2 |  |  | 69.6 | % |  | 405.8 |  |  | 71.2 | % |  | 1,023.3 |  |  | 69.6 | % |  | 793.9 |  |  | 71.5 | % |
| Total gross profit | $ | 709.3 |  |  | 69.8 | % |  | $ | 583.6 |  |  | 71.5 | % |  | $ | 1,377.5 |  |  | 70.2 | % |  | $ | 1,137.8 |  |  | 71.6 | % |

[0001327567-21-000004:mdna:82]
[same as prior period, unchanged from 0001327567-20-000041:mdna:102]

[0001327567-21-000004:mdna:83]
Table of Content

[0001327567-21-000004:mdna:84]
Product gross margin decreased for the three months ended January 31, 2021 compared to the same period in 2020, primarily due to an increase in inventory reserve and higher amortization of intellectual property licenses. Product gross margin was flat for the six months ended January 31, 2021 compared to the same period in 2020.

[0001327567-21-000004:mdna:85]
Subscription and support gross margin decreased for the three and six months ended January 31, 2021 compared to the same periods in 2020, primarily due to an increase in costs to support our cloud-based offerings in both periods.

[0001327567-21-000004:mdna:86]
[same as prior period, unchanged from 0001327567-20-000041:mdna:78]

[0001327567-21-000004:mdna:87]
Our operating expenses consist of research and development, sales and marketing, and general and administrative expense. Personnel costs are the most significant component of operating expenses and consist of salaries, benefits, bonuses, share-based compensation, travel and entertainment, and with regard to sales and marketing expense, sales commissions. Our operating expenses also include allocated costs, which consist of certain facilities, depreciation, benefits, recruiting, and information technology costs that we allocate based on headcount. We expect operating expenses generally to increase in absolute dollars and decrease over the long term as a percentage of revenue as we continue to scale our business. In response to COVID-19, we instituted a global work-from-home policy and limited employee travel beginning in March 2020. Further, we have canceled in-person events and either replaced them with virtual events or postponed them to future periods. As of January 31, 2021, we expect to recognize approximately $2.1 billion of share-based compensation expense over a weighted-average period of approximately 2.8 years, excluding additional share-based compensation expense related to any future grants of share-based awards. Share-based compensation expense is generally recognized on a straight-line basis over the requisite service periods of the awards.

[0001327567-21-000004:mdna:88]
[same as prior period, unchanged from 0001327567-20-000041:mdna:80]

[0001327567-21-000004:mdna:89]
[same as prior period, unchanged from 0001327567-20-000041:mdna:81]

[0001327567-21-000004:mdna:90]
|  | Three Months Ended January 31, |  |  |  |  |  | Six Months Ended January 31, |  |  |  |  |
|  | 2021 |  | 2020 |  | Change |  | 2021 |  | 2020 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Research and development | $ | 266.7 |  |  | $ | 185.4 |  |  | $ | 81.3 |  |  | 43.9 | % |  | $ | 504.1 |  |  | $ | 355.9 |  |  | $ | 148.2 |  |  | 41.6 | % |
| Number of employees at period end | 2,195 |  |  | 1,646 |  |  | 549 |  |  | 33.4 | % |  | 2,195 |  |  | 1,646 |  |  | 549 |  |  | 33.4 | % |

[0001327567-21-000004:mdna:91]
Research and development expense increased for the three and six months ended January 31, 2021 compared to the same periods in 2020. The increase was primarily due to personnel costs, which grew $72.3 million to $216.0 million for the three months ended January 31, 2021 compared to the same period in 2020, and grew $127.1 million to $404.0 million for the six months ended January 31, 2021 compared to the same period in 2020. The increase in personnel costs in both periods was primarily due to headcount growth. The increase in personnel costs in the six months ended January 31, 2021 was also due to accelerated vesting of certain equity awards.

[0001327567-21-000004:mdna:92]
[same as prior period, unchanged from 0001327567-20-000041:mdna:84]

[0001327567-21-000004:mdna:93]
[same as prior period, unchanged from 0001327567-20-000041:mdna:85]

[0001327567-21-000004:mdna:94]
|  | Three Months Ended January 31, |  |  |  |  |  | Six Months Ended January 31, |  |  |  |  |
|  | 2021 |  | 2020 |  | Change |  | 2021 |  | 2020 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Sales and marketing | $ | 427.4 |  |  | $ | 374.9 |  |  | $ | 52.5 |  |  | 14.0 | % |  | $ | 816.0 |  |  | $ | 740.6 |  |  | $ | 75.4 |  |  | 10.2 | % |
| Number of employees at period end | 4,065 |  |  | 3,699 |  | 366 |  |  | 9.9 | % |  | 4,065 |  |  | 3,699 |  |  | 366 |  |  | 9.9 | % |

[0001327567-21-000004:mdna:95]
Sales and marketing expense increased for the three and six months ended January 31, 2021 compared to the same periods in 2020, primarily due to personnel costs, which grew $34.9 million to $323.4 million, for the three months ended January 31, 2021 compared to the same period in 2020, and grew $65.2 million to $616.7 million for the six months ended January 31, 2021 compared to the same period in 2020. The increase in personnel costs in both periods was largely due to headcount growth, partially offset by

[0001327567-21-000004:mdna:96]
[same as prior period, unchanged from 0001327567-20-000041:mdna:113]

[0001327567-21-000004:mdna:97]
Table of Content

[0001327567-21-000004:mdna:98]
decreased travel expenses due to COVID-19. In addition, expenses increased in both periods as a result of go-to-market initiatives, including advertising, which were partially offset by a decrease in trade shows and convention expenses as in-person events were replaced with virtual events due to COVID-19.

[0001327567-21-000004:mdna:99]
[same as prior period, unchanged from 0001327567-20-000041:mdna:88]

[0001327567-21-000004:mdna:100]
General and administrative expense consists primarily of personnel costs for our executive, finance, human resources, legal, and information technology organizations, and professional services costs, which consist primarily of legal, auditing, accounting, and other consulting costs. General and administrative expense also includes certain non-recurring general expenses and impairment losses. Certain facilities, depreciation, benefits, recruiting, and information technology costs are allocated to other organizations based on headcount. We expect general and administrative expense to increase in absolute dollars due to additional costs associated with accounting, compliance, and insurance, although our general and administrative expense may fluctuate as a percentage of total revenue.

[0001327567-21-000004:mdna:101]
|  | Three Months Ended January 31, |  |  |  |  |  | Six Months Ended January 31, |  |  |  |  |
|  | 2021 |  | 2020 |  | Change |  | 2021 |  | 2020 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| General and administrative | $ | 104.0 |  |  | $ | 76.2 |  |  | $ | 27.8 |  |  | 36.5 | % |  | $ | 190.7 |  |  | $ | 146.0 |  |  | $ | 44.7 |  |  | 30.6 | % |
| Number of employees at period end | 963 |  |  | 856 |  |  | 107 |  |  | 12.5 | % |  | 963 |  |  | 856 |  |  | 107 |  |  | 12.5 | % |

[0001327567-21-000004:mdna:102]
General and administrative expense increased for the three and six months ended January 31, 2021 compared to the same periods in 2020. Personnel costs increased $16.6 million to $72.2 million for the three months ended January 31, 2021 compared to the same period in 2020, and grew $23.8 million to $125.7 million for the six months ended January 31, 2021 compared to the same period in 2020. The increase in personnel costs in both periods was primarily due to the accelerated vesting of certain equity awards in connection with our acquisitions. The remaining increase in both periods was due to acquisition-related costs, and in the six months ended January 31, 2021, increases in credit losses.

[0001327567-21-000004:mdna:103]
[same as prior period, unchanged from 0001327567-20-000041:mdna:94]

[0001327567-21-000004:mdna:104]
Interest expense primarily consists of non-cash interest expense from the amortization of the debt discount and debt issuance costs related to our 0.75% Convertible Senior Notes due 2023 (the “2023 Notes”) and the 0.375% Convertible Senior Notes due 2025 (the “2025 Notes,” and together with “2023 Notes,” the “Notes”), and also includes the contractual interest expense related to our Notes.

[0001327567-21-000004:mdna:105]
|  | Three Months Ended January 31, |  |  |  | Six Months Ended January 31, |  |  |
|  | 2021 |  | 2020 |  | Change |  | 2021 |  | 2020 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Interest expense | $ | 40.7 |  |  | $ | 19.0 |  |  | $ | 21.7 |  |  | 114.2 | % |  | $ | 80.9 |  |  | $ | 37.9 |  |  | $ | 43.0 |  |  | 113.5 | % |

[0001327567-21-000004:mdna:106]
Interest expense increased for the three and six months ended January 31, 2021 compared to the same periods in 2020 primarily due to our 2025 Notes issued in the fourth quarter of fiscal 2020. Refer to Note 10. Debt in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information on our Notes.

[0001327567-21-000004:mdna:107]
Other Income (expense), Net

[0001327567-21-000004:mdna:108]
Other income (expense), net includes interest income earned on our cash, cash equivalents, and investments, foreign currency remeasurement gains and losses, and foreign currency transaction gains and losses.

[0001327567-21-000004:mdna:109]
|  | Three Months Ended January 31, |  |  |  | Six Months Ended January 31, |  |  |
|  | 2021 |  | 2020 |  | Change |  | 2021 |  | 2020 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Other income (expense), net | $ | (0.5) |  |  | $ | 10.8 |  |  | $ | (11.3) |  |  | (104.6) | % |  | $ | 1.9 |  |  | $ | 27.0 |  |  | $ | (25.1) |  |  | (93.0) | % |

[0001327567-21-000004:mdna:110]
The change in other income (expense), net for the three and six months ended January 31, 2021 compared to the same periods in 2020 was primarily due to lower interest income earned on our cash, cash equivalents, and investments balances as a result of lower interest rates for the three and six months ended January 31, 2021 compared to the same periods in 2020.

[0001327567-21-000004:mdna:111]
[same as prior period, unchanged from 0001327567-20-000041:mdna:131]

[0001327567-21-000004:mdna:112]
Table of Content

[0001327567-21-000004:mdna:113]
[same as prior period, unchanged from 0001327567-20-000041:mdna:103]

[0001327567-21-000004:mdna:114]
[same as prior period, unchanged from 0001327567-20-000041:mdna:104]

[0001327567-21-000004:mdna:115]
|  | Three Months Ended January 31, |  | Change |  | Six Months Ended January 31, |  | Change |
|  | 2021 |  | 2020 |  | Amount |  | % |  | 2021 |  | 2020 |  | Amount |  | % |
|  | (dollars in millions) |
| Provision for income taxes | $ | 12.3 |  |  | $ | 12.6 |  |  | $ | (0.3) |  |  | (2.4) | % |  | $ | 22.2 |  |  | $ | 17.7 |  |  | $ | 4.5 |  |  | 25.4 | % |
| Effective tax rate | (9.5) | % |  | (20.6) | % |  |  |  |  |  | (10.5) | % |  | (15.3) | % |  |  |  |  |

[0001327567-21-000004:mdna:116]
We recorded an income tax provision for the three and six months ended January 31, 2021, primarily due to income taxes in profitable foreign jurisdictions and withholding taxes. Our negative effective tax rate decreased for the three and six months ended January 31, 2021 compared to the same periods in 2020 primarily due to our valuation allowance. Refer to Note 14. Income Taxes in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information.

[0001327567-21-000004:mdna:117]
[same as prior period, unchanged from 0001327567-20-000041:mdna:107]

[0001327567-21-000004:mdna:118]
|  | January 31, 2021 |  | July 31, 2020 |
|  | (in millions) |
| Working capital(1) | $ | (100.5) |  |  | $ | 2,437.5 |  |
| Cash, cash equivalents, and investments: |  |  |  |
| Cash and cash equivalents | $ | 2,113.2 |  |  | $ | 2,958.0 |  |
| Investments | 1,915.1 |  |  | 1,344.2 |  |
| Total cash, cash equivalents, and investments | $ | 4,028.3 |  |  | $ | 4,302.2 |  |

[0001327567-21-000004:mdna:119]
______________

[0001327567-21-000004:mdna:120]
(1)The net carrying amount of the 2023 Notes was classified in current liabilities in our condensed consolidated balance sheets as of January 31, 2021. Refer to 10. Debt in Part I, Item 1 of this Quarterly Report on Form 10-Q for information on the Notes.

[0001327567-21-000004:mdna:121]
As of January 31, 2021, our total cash, cash equivalents, and investments of $4.0 billion were held for general corporate purposes, of which approximately $792.2 million was held outside of the United States. As of January 31, 2021, we had no unremitted earnings when evaluating our outside basis difference relating to our U.S. investment in foreign subsidiaries. However, there could be local withholding taxes payable due to various foreign countries if certain lower tier earnings are distributed. Withholding taxes that would be payable upon remittance of these lower tier earnings are not expected to be material.

[0001327567-21-000004:mdna:122]
In July 2018, we issued the 2023 Notes with an aggregate principal amount of $1.7 billion. In June 2020, we issued the 2025 Notes with an aggregate principal amount of $2.0 billion. The 2023 Notes mature on July 1, 2023 and the 2025 Notes mature on June 1, 2025; however, under certain circumstances, holders may surrender their Notes of a series for conversion prior to the applicable maturity date. Upon conversion of the Notes of a series, we will pay cash equal to the aggregate principal amount of the Notes of such series to be converted, and, at our election, will pay or deliver cash and/or shares of our common stock for the amount of our conversion obligation in excess of the aggregate principal amount of the Notes of such series being converted. The sale price condition was met for the 2023 Notes during the fiscal quarter ended January 31, 2021, and as a result, holders may convert their 2023 Notes at any time during the fiscal quarter ending April 30, 2021. We believe that our cash provided by operating activities, together with our existing cash, cash equivalents and investments will be sufficient to meet our anticipated cash needs should the holders choose to convert their 2023 Notes during the fiscal quarter ending April 30, 2021. As of January 31, 2021, all of our Notes remained outstanding. Refer to Note 10. Debt in Part I, Item 1 of this Quarterly Report on Form 10-Q for information on the Notes.

[0001327567-21-000004:mdna:123]
In September 2018, we entered into a credit agreement (the “Credit Agreement”) that provides for a $400.0 million unsecured revolving credit facility (the “Credit Facility”), with an option to increase the amount of the credit facility up to an additional $350.0 million, subject to certain conditions. As of January 31, 2021, there were no amounts outstanding and we were in compliance with all covenants under the Credit Agreement. Refer to Note 10. Debt in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information on the Credit Agreement.

[0001327567-21-000004:mdna:124]
In February 2019, our board of directors authorized a $1.0 billion share repurchase program, and, in December 2020, our board of directors authorized a $700.0 million increase to our share repurchase program, bringing the total authorization to $1.7 billion.

[0001327567-21-000004:mdna:125]
- 35 -

[0001327567-21-000004:mdna:126]
Table of Content

[0001327567-21-000004:mdna:127]
Repurchases are funded from available working capital and may be made at management’s discretion from time to time. The expiration date of this repurchase program was extended to December 31, 2021, and our repurchase program may be suspended or discontinued at any time. As of January 31, 2021, $1.0 billion remained available for future share repurchases under this repurchase program. Refer to Note 12. Stockholders’ Equity in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information on this repurchase program.

[0001327567-21-000004:mdna:128]
The following table summarizes our cash flows for the six months ended January 31, 2021 and 2020:

[0001327567-21-000004:mdna:129]
|  | Six Months Ended January 31, |
| 2021 |  | 2020 |
|  | (in millions) |
| Net cash provided by operating activities | $ | 899.4 |  |  | $ | 532.1 |  |
| Net cash provided by (used in) investing activities | (1,270.6) |  |  | 680.9 |  |
| Net cash used in financing activities | (469.9) |  |  | (173.2) |  |
| Net increase (decrease) in cash, cash equivalents, and restricted cash | $ | (841.1) |  |  | $ | 1,039.8 |  |

[0001327567-21-000004:mdna:130]
[same as prior period, unchanged from 0001327567-20-000041:mdna:116]

[0001327567-21-000004:mdna:131]
[same as prior period, unchanged from 0001327567-20-000041:mdna:117]

[0001327567-21-000004:mdna:132]
[same as prior period, unchanged from 0001327567-20-000041:mdna:118]

[0001327567-21-000004:mdna:133]
[same as prior period, unchanged from 0001327567-20-000041:mdna:119]

[0001327567-21-000004:mdna:134]
Cash provided by operating activities during the six months ended January 31, 2021 was $899.4 million, an increase of $367.3 million compared to the same period in 2020. The increase was primarily due to growth of our business as reflected by an increase in billings, and an increase in collections during the six months ended January 31, 2021, partially offset by a decrease in cash due to timing of payments.

[0001327567-21-000004:mdna:135]
[same as prior period, unchanged from 0001327567-20-000041:mdna:121]

[0001327567-21-000004:mdna:136]
[same as prior period, unchanged from 0001327567-20-000041:mdna:122]

[0001327567-21-000004:mdna:137]
Cash used in investing activities during the six months ended January 31, 2021 was $1,270.6 million, a net change of $2.0 billion compared to cash provided by investing activities of $680.9 million during the same period in 2020. The change was primarily due to higher purchases of investments, a decrease in proceeds from maturities of investments, and an increase in net cash payments for business acquisitions during the six months ended January 31, 2021.

[0001327567-21-000004:mdna:138]
[same as prior period, unchanged from 0001327567-20-000041:mdna:124]

[0001327567-21-000004:mdna:139]
[same as prior period, unchanged from 0001327567-20-000041:mdna:125]

[0001327567-21-000004:mdna:140]
Cash used in financing activities during the six months ended January 31, 2021 was $469.9 million, an increase of $296.7 million compared to the same period in 2020. The increase was primarily due to higher repurchases of our common stock during the six months ended January 31, 2021.

[0001327567-21-000004:mdna:141]
[same as prior period, unchanged from 0001327567-20-000041:mdna:127]

[0001327567-21-000004:mdna:142]
Except for those disclosed in Note 11. Commitments and Contingencies in Part I, Item 1 of this Quarterly Report on Form 10-Q, there have been no material changes outside of the ordinary course of business to our contractual obligations and commitments disclosed in our Annual Report on Form 10-K for the fiscal year ended July 31, 2020.

[0001327567-21-000004:mdna:143]
- 36 -

[0001327567-21-000004:mdna:144]
Table of Content

[0001327567-21-000004:mdna:145]
[same as prior period, unchanged from 0001327567-20-000041:mdna:129]

[0001327567-21-000004:mdna:146]
As of January 31, 2021, we did not have any relationships with unconsolidated organizations or financial partnerships, such as structured finance or special purpose entities that would have been established for the purpose of facilitating off-balance sheet arrangements or other contractually narrow or limited purposes.

[0001327567-21-000004:mdna:147]
[same as prior period, unchanged from 0001327567-20-000041:mdna:132]

[0001327567-21-000004:mdna:148]
[same as prior period, unchanged from 0001327567-20-000041:mdna:133]

[0001327567-21-000004:mdna:149]
[same as prior period, unchanged from 0001327567-20-000041:mdna:134]

[0001327567-21-000004:mdna:150]
[same as prior period, unchanged from 0001327567-20-000041:mdna:135]

[0001327567-21-000004:mdna:151]
For a discussion of the recent accounting pronouncements, refer to “Recently Adopted Accounting Pronouncements” and “Recently Issued Accounting Pronouncements” in Note 1. Description of Business and Summary of Significant Accounting Policies in Part I, Item 1 of this Quarterly Report on Form 10-Q.
