# PANW note change history — 0001327567-20-000041 → 0001327567-21-000004


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2021-02-23):
[0001327567-21-000004:note_history:1]
Our electronics manufacturing service provider (“EMS provider”) procures components and assembles our products based on our forecasts. These forecasts are based on estimates of demand for our products primarily for the next 12 months, which are in turn based on historical trends and an analysis from our sales and product management organizations, adjusted for overall market conditions. In order to reduce manufacturing lead times and plan for adequate supply, we may issue non-cancelable orders for products and components to our manufacturing partners or component suppliers. As of January 31, 2021, our purchase commitments under such orders were $157.7 million excluding obligations under contracts that we can cancel without a significant penalty.
  (was, 2020-11-19, similarity 0.9906):
[0001327567-20-000041:note_history:1]
Our electronics manufacturing service provider (“EMS provider”) procures components and assembles our products based on our forecasts. These forecasts are based on estimates of demand for our products primarily for the next 12 months, which are in turn based on historical trends and an analysis from our sales and product management organizations, adjusted for overall market conditions. In order to reduce manufacturing lead times and plan for adequate supply, we may issue non-cancelable orders for products and components to our manufacturing partners or component suppliers. As of October 31, 2020, our purchase commitments under such orders were $140.8 million excluding obligations under contracts that we can cancel without a significant penalty.

- changed (2021-02-23):
[0001327567-21-000004:note_history:2]
We have entered into various non-cancelable agreements with certain service providers, under which we are committed to minimum or fixed purchases through the year ending July 31, 2026. The following table presents details of the aggregate future non-cancelable purchase commitments under these agreements as of January 31, 2021 (in millions):
  (was, 2020-11-19, similarity 0.9789):
[0001327567-20-000041:note_history:2]
We have entered into various non-cancelable agreements with certain service providers, under which we are committed to minimum or fixed purchases through the year ending July 31, 2026. The following table presents details of the aggregate future non-cancelable purchase commitments under these agreements as of October 31, 2020 (in millions):

- changed (2021-02-23):
[0001327567-21-000004:note_history:3]
To the extent there is a reasonable possibility that a loss exceeding amounts already recognized may be incurred and the amount of such additional loss would be material, we will either disclose the estimated additional loss or state that such an estimate cannot be made. As of January 31, 2021, we have not recorded any significant accruals for loss contingencies associated with such legal proceedings, determined that an unfavorable outcome is probable or reasonably possible, or determined that the amount or range of any possible loss is reasonably estimable.
  (was, 2020-11-19, similarity 0.9875):
[0001327567-20-000041:note_history:3]
To the extent there is a reasonable possibility that a loss exceeding amounts already recognized may be incurred and the amount of such additional loss would be material, we will either disclose the estimated additional loss or state that such an estimate cannot be made. As of October 31, 2020, we have not recorded any significant accruals for loss contingencies associated with such legal proceedings, determined that an unfavorable outcome is probable or reasonably possible, or determined that the amount or range of any possible loss is reasonably estimable.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2021-02-23):
[0001327567-21-000004:note_history:4]
Our condensed consolidated financial statements are unaudited but include all adjustments of a normal recurring nature necessary for a fair presentation of our quarterly results. Our condensed consolidated financial statements should be read in conjunction with the audited consolidated financial statements and related notes in our Annual Report on Form 10-K for the fiscal year ended July 31, 2020.
  (was, 2020-11-19, similarity 0.9987):
[0001327567-20-000041:note_history:4]
Our condensed consolidated financial statements are unaudited, but include all adjustments of a normal recurring nature necessary for a fair presentation of our quarterly results. Our condensed consolidated financial statements should be read in conjunction with the audited consolidated financial statements and related notes in our Annual Report on Form 10-K for the fiscal year ended July 31, 2020.

- changed (2021-02-23):
[0001327567-21-000004:note_history:5]
There have been no material changes to our significant accounting policies as of and for the six months ended January 31, 2021, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended July 31, 2020, except for the change in our accounting policies for credit losses due to our adoption of the new credit losses guidance. Refer to “Recently Adopted Accounting Pronouncements” below.
  (was, 2020-11-19, similarity 0.9747):
[0001327567-20-000041:note_history:5]
There have been no material changes to our significant accounting policies as of and for the three months ended October 31, 2020, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended July 31, 2020, except for the change in our accounting policies for credit losses due to our adoption of the new credit losses guidance. Refer to “Recently Adopted Accounting Pronouncements” below.

- changed (2021-02-23):
[0001327567-21-000004:note_history:6]
recorded in other income (expense), net in our condensed consolidated statements of operations. Impairment losses that are not credit-related are included in accumulated other comprehensive income (loss) (“AOCI”) in stockholders’ equity.
  (was, 2020-11-19, similarity 0.9784):
[0001327567-20-000041:note_history:6]
recorded in other income, net in our condensed consolidated statements of operations. Impairment losses that are not credit-related are included in accumulated other comprehensive income (loss) (“AOCI”) in stockholders’ equity.

- changed (2021-02-23):
[0001327567-21-000004:note_history:7]
Trade accounts receivable are recorded at the invoiced amount, net of allowances for credit losses for any potential uncollectible amounts. The allowance for credit losses is based on our assessment of the collectability of accounts. Management regularly reviews the adequacy of the allowance for credit losses on a collective basis by considering the age of each outstanding invoice, each customer’s expected ability to pay and collection history, current market conditions, and reasonable and supportable forecasts of future economic conditions to determine whether the allowance is appropriate. Accounts receivable deemed uncollectible are charged against the allowance for credit losses when identified. For the three and six months ended January 31, 2021 and 2020, the allowance for credit losses activity was not significant.
  (was, 2020-11-19, similarity 0.9095):
[0001327567-20-000041:note_history:7]
Trade accounts receivable are recorded at the invoiced amount, net of allowances for credit losses for any potential uncollectible amounts. The allowance for credit losses is based on our assessment of the collectability of accounts. Management regularly reviews the adequacy of the allowance for credit losses on a collective basis by considering the age of each outstanding invoice, each customer’s expected ability to pay and collection history, current market conditions, and reasonable and supportable forecasts of future economic conditions to determine whether the allowance is appropriate. Accounts receivable deemed uncollectible are charged against the allowance for credit losses when identified. For the three months ended October 31, 2020 and 2019, the allowance for credit losses activity was not significant.

- changed (2021-02-23):
[0001327567-21-000004:note_history:8]
In August 2020, the FASB issued new authoritative guidance to simplify the accounting for certain financial instruments with characteristics of liabilities and equity, including convertible instruments and contracts on an entity’s own equity. The standard reduces the number of models used to account for convertible instruments and simplifies both the classification of debt on the balance sheet and the earnings per share calculation. The standard is effective for us in our first quarter of fiscal 2023 and will be applied on a modified retrospective basis. Early adoption is permitted from our first quarter of fiscal 2022. We are currently evaluating the impact of this standard on our condensed consolidated financial statements.
  (was, 2020-11-19, similarity 0.9993):
[0001327567-20-000041:note_history:8]
In August 2020, the FASB issued new authoritative guidance to simplify the accounting for certain financial instruments with characteristics of liabilities and equity, including convertible instruments and contracts on an entity’s own equity. The standard reduces the number of models used to account for convertible instruments, and simplifies both the classification of debt on the balance sheet and the earnings per share calculation. The standard is effective for us in our first quarter of fiscal 2023 and will be applied on a modified retrospective basis. Early adoption is permitted from our first quarter of fiscal 2022. We are currently evaluating the impact of this standard on our condensed consolidated financial statements.


## us-gaap:ConvertibleDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-02-23):
[0001327567-21-000004:note_history:9]
The following table sets forth the components of the Notes as of January 31, 2021 and July 31, 2020 (in millions):
  (was, 2020-11-19, similarity 0.9423):
[0001327567-20-000041:note_history:9]
The following table sets forth the components of the Notes as of October 31, 2020 and July 31, 2020 (in millions):

- changed (2021-02-23):
[0001327567-21-000004:note_history:10]
|  | January 31, 2021 | July 31, 2020 |
|  | 2023 Notes |  | 2025 Notes |  | Total |  | 2023 Notes |  | 2025 Notes |  | Total |
| Liability component: |  |  |  |  |  |  |  |  |  |  |  |
| Principal | $ | 1,693.0 |  |  | $ | 2,000.0 |  |  | $ | 3,693.0 |  |  | $ | 1,693.0 |  |  | $ | 2,000.0 |  |  | $ | 3,693.0 |  |
| Less: debt discount and debt issuance costs, net of amortization | 167.4 |  |  | 370.9 |  |  | 538.3 |  |  | 200.0 |  |  | 408.9 |  |  | 608.9 |  |
| Net carrying amount | $ | 1,525.6 |  |  | $ | 1,629.1 |  |  | $ | 3,154.7 |  |  | $ | 1,493.0 |  |  | $ | 1,591.1 |  |  | $ | 3,084.1 |  |
| Equity component (including amounts classified as temporary equity) | $ | 315.0 |  |  | $ | 403.0 |  |  | $ | 718.0 |  |  | $ | 315.0 |  |  | $ | 403.0 |  |  | $ | 718.0 |  |
  (was, 2020-11-19, similarity 0.8151):
[0001327567-20-000041:note_history:10]
|  | October 31, 2020 | July 31, 2020 |
|  | 2023 Notes |  | 2025 Notes |  | Total |  | 2023 Notes |  | 2025 Notes |  | Total |
| Liability component: |  |  |  |  |  |  |  |  |  |  |  |
| Principal | $ | 1,693.0 |  |  | $ | 2,000.0 |  |  | $ | 3,693.0 |  |  | $ | 1,693.0 |  |  | $ | 2,000.0 |  |  | $ | 3,693.0 |  |
| Less: debt discount and debt issuance costs, net of amortization | 183.8 |  |  | 390.1 |  |  | 573.9 |  |  | 200.0 |  |  | 408.9 |  |  | 608.9 |  |
| Net carrying amount | $ | 1,509.2 |  |  | $ | 1,609.9 |  |  | $ | 3,119.1 |  |  | $ | 1,493.0 |  |  | $ | 1,591.1 |  |  | $ | 3,084.1 |  |
| Equity component | $ | 315.0 |  |  | $ | 403.0 |  |  | $ | 718.0 |  |  | $ | 315.0 |  |  | $ | 403.0 |  |  | $ | 718.0 |  |


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-02-23):
[0001327567-21-000004:note_history:11]
In July 2018, we issued $1.7 billion aggregate principal amount of 0.75% Convertible Senior Notes due 2023 (the “2023 Notes”) and, in June 2020, we issued $2.0 billion aggregate principal amount of 0.375% Convertible Senior Notes due 2025 (the “2025 Notes,” and together with the 2023 Notes, the “Notes”). The 2023 Notes bear interest at a fixed rate of 0.75% per year, payable semi-annually in arrears on January 1 and July 1 of each year, beginning on January 1, 2019. The 2025 Notes bear interest at a fixed rate of 0.375% per year, payable semi-annually in arrears on June 1 and December 1 of each year, beginning on December 1, 2020. Each series of the convertible notes is governed by an indenture between us, as the issuer, and U.S. Bank National Association, as Trustee (individually, each an “Indenture,” and together, the “Indentures”). The Notes of each series are unsecured, unsubordinated obligations and the applicable Indenture governing each series of Notes does not contain any financial covenants or restrictions on the payments of dividends, the incurrence of indebtedness, or the issuance or repurchase of securities by us or any of our subsidiaries. The
  (was, 2020-11-19, similarity 0.7079):
[0001327567-20-000041:note_history:11]
In July 2018, we issued $1.7 billion aggregate principal amount of 0.75% Convertible Senior Notes due 2023 (the “2023 Notes”) and, in June 2020, we issued $2.0 billion aggregate principal amount of 0.375% Convertible Senior Notes due 2025 (the “2025 Notes,” and together with the 2023 Notes, the “Notes”). The 2023 Notes bear interest at a fixed rate of 0.75% per year, payable semi-annually in arrears on January 1 and July 1 of each year, beginning on January 1, 2019. The 2025 Notes bear interest at a fixed rate of 0.375% per year, payable semi-annually in arrears on June 1 and December 1 of each year, beginning on December 1, 2020. Each series of the convertible notes is governed by an indenture between us, as the issuer, and U.S. Bank National Association, as Trustee (individually, each an “Indenture,” and together, the “Indentures”). The Notes of each series are unsecured, unsubordinated obligations and the applicable Indenture governing each series of Notes does not contain any financial covenants or restrictions on the payments of dividends, the incurrence of indebtedness, or the issuance or repurchase of securities by us or any of our subsidiaries. The 2023 Notes and the 2025 Notes mature on July 1, 2023 and June 1, 2025, respectively. We cannot redeem the 2023 Notes prior to maturity. We may redeem for cash all or any portion of the 2025 Notes, at our option, on or after June 5, 2023, and prior to the 31st scheduled trading day immediately preceding the maturity date if the last reported sale price of our common stock has been at least 130% of the conversion price then in effect for at least 20 trading days during any 30 consecutive trading day period ending on and including the trading day preceding the date on which we provide notice of redemption. The redemption will be at a price equal to 100% of the principal amount of the 2025 Notes and adjusted for interest. If we call any or all of the 2025 Notes for redemption, holders may convert such 2025 Notes called for redemption at any time prior to the close of business on the second scheduled trading day immediately preceding the redemption date.

- added (2021-02-23):
[0001327567-21-000004:note_history:12]
2023 Notes and the 2025 Notes mature on July 1, 2023 and June 1, 2025, respectively. We cannot redeem the 2023 Notes prior to maturity. We may redeem for cash all or any portion of the 2025 Notes, at our option, on or after June 5, 2023, and prior to the 31st scheduled trading day immediately preceding the maturity date if the last reported sale price of our common stock has been at least 130% of the conversion price then in effect for at least 20 trading days during any 30 consecutive trading day period ending on and including the trading day preceding the date on which we provide notice of redemption. The redemption will be at a price equal to 100% of the principal amount of the 2025 Notes and adjusted for interest. If we call any or all of the 2025 Notes for redemption, holders may convert such 2025 Notes called for redemption at any time prior to the close of business on the second scheduled trading day immediately preceding the redemption date.

- added (2021-02-23):
[0001327567-21-000004:note_history:13]
The sale price condition was met for the 2023 Notes during the fiscal quarter ended January 31, 2021, and as a result, holders may convert their 2023 Notes at any time during the fiscal quarter ending April 30, 2021. Accordingly, the net carrying amount of the 2023 Notes was reclassified into current liabilities and the portion of the equity component representing the conversion option was reclassified into temporary equity in our condensed consolidated balance sheet as of January 31, 2021. The portion of the equity component classified as temporary equity is measured as the difference between the principal and net carrying amount of the 2023 Notes, excluding debt issuance costs.

- added (2021-02-23):
[0001327567-21-000004:note_history:14]
The sale price condition was not met for the 2025 Notes during the fiscal quarters ended January 31, 2021 and July 31, 2020 and was not met for the 2023 Notes during the fiscal quarter ended July 31, 2020. Since the 2025 Notes for both periods and the 2023 Notes as of July 31, 2020 were not convertible, the associated net carrying amount was classified as a long-term liability and the equity component was included in additional paid-in capital in our condensed consolidated balance sheets.

- added (2021-02-23):
[0001327567-21-000004:note_history:15]
As of January 31, 2021, all of the Notes remained outstanding.

- changed (2021-02-23):
[0001327567-21-000004:note_history:16]
The following table sets forth the components of the Notes as of January 31, 2021 and July 31, 2020 (in millions):
  (was, 2020-11-19, similarity 0.9423):
[0001327567-20-000041:note_history:16]
The following table sets forth the components of the Notes as of October 31, 2020 and July 31, 2020 (in millions):

- changed (2021-02-23):
[0001327567-21-000004:note_history:17]
|  | January 31, 2021 | July 31, 2020 |
|  | 2023 Notes |  | 2025 Notes |  | Total |  | 2023 Notes |  | 2025 Notes |  | Total |
| Liability component: |  |  |  |  |  |  |  |  |  |  |  |
| Principal | $ | 1,693.0 |  |  | $ | 2,000.0 |  |  | $ | 3,693.0 |  |  | $ | 1,693.0 |  |  | $ | 2,000.0 |  |  | $ | 3,693.0 |  |
| Less: debt discount and debt issuance costs, net of amortization | 167.4 |  |  | 370.9 |  |  | 538.3 |  |  | 200.0 |  |  | 408.9 |  |  | 608.9 |  |
| Net carrying amount | $ | 1,525.6 |  |  | $ | 1,629.1 |  |  | $ | 3,154.7 |  |  | $ | 1,493.0 |  |  | $ | 1,591.1 |  |  | $ | 3,084.1 |  |
| Equity component (including amounts classified as temporary equity) | $ | 315.0 |  |  | $ | 403.0 |  |  | $ | 718.0 |  |  | $ | 315.0 |  |  | $ | 403.0 |  |  | $ | 718.0 |  |
  (was, 2020-11-19, similarity 0.8151):
[0001327567-20-000041:note_history:17]
|  | October 31, 2020 | July 31, 2020 |
|  | 2023 Notes |  | 2025 Notes |  | Total |  | 2023 Notes |  | 2025 Notes |  | Total |
| Liability component: |  |  |  |  |  |  |  |  |  |  |  |
| Principal | $ | 1,693.0 |  |  | $ | 2,000.0 |  |  | $ | 3,693.0 |  |  | $ | 1,693.0 |  |  | $ | 2,000.0 |  |  | $ | 3,693.0 |  |
| Less: debt discount and debt issuance costs, net of amortization | 183.8 |  |  | 390.1 |  |  | 573.9 |  |  | 200.0 |  |  | 408.9 |  |  | 608.9 |  |
| Net carrying amount | $ | 1,509.2 |  |  | $ | 1,609.9 |  |  | $ | 3,119.1 |  |  | $ | 1,493.0 |  |  | $ | 1,591.1 |  |  | $ | 3,084.1 |  |
| Equity component | $ | 315.0 |  |  | $ | 403.0 |  |  | $ | 718.0 |  |  | $ | 315.0 |  |  | $ | 403.0 |  |  | $ | 718.0 |  |

- added (2021-02-23):
[0001327567-21-000004:note_history:18]
The total estimated fair value of the Notes was $5.0 billion and $4.1 billion at January 31, 2021 and July 31, 2020, respectively. The fair value was determined based on the closing trading price per $100 of the Notes as of the last day of trading for the period. We consider the fair value of the Notes at January 31, 2021 and July 31, 2020 to be a Level 2 measurement. The fair value of the Notes is primarily affected by the trading price of our common stock and market interest rates. Based on the closing price of our common stock on January 31, 2021, the if-converted values of the 2023 Notes and 2025 Notes exceeded their principal amounts by $575.4 million and $398.1 million, respectively.

- added (2021-02-23):
[0001327567-21-000004:note_history:19]
|  | Three Months Ended January 31, |  | Six Months Ended January 31, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
|  | 2023 Notes |  | 2025 Notes |  | Total |  | 2023 Notes |  |  |  | Total |  | 2023 Notes |  | 2025 Notes |  | Total |  | 2023 Notes |  |  |  | Total |
| Contractual interest expense | $ | 3.1 |  | $ | 1.9 |  | $ | 5.0 |  |  | $3.1 |  |  |  | $ | 3.1 |  |  | $ | 6.3 |  | $ | 3.8 |  | $ | 10.1 |  |  | $ | 6.3 |  |  |  | $ | 6.3 |  |
| Amortization of debt discount | 15.7 |  | 18.5 |  | 34.2 |  |  | 15.2 |  |  |  | 15.2 |  |  | 31.4 |  | 36.7 |  | 68.1 |  |  | 30.2 |  |  |  | 30.2 |  |
| Amortization of debt issuance costs | 0.6 |  | 0.7 |  | 1.3 |  |  | 0.5 |  |  |  | 0.5 |  |  | 1.1 |  | 1.4 |  | 2.5 |  |  | 1.0 |  |  |  | 1.0 |  |
| Total interest expense recognized | $ | 19.4 |  | $ | 21.1 |  | $ | 40.5 |  |  | $ | 18.8 |  |  |  | $ | 18.8 |  |  | $ | 38.8 |  | $ | 41.9 |  | $ | 80.7 |  |  | $ | 37.5 |  |  |  | $ | 37.5 |  |
| Effective interest rate of the liability component | 5.2 | % |  | 5.4 | % |  |  |  | 5.2 | % |  |  |  |  |  | 5.2 | % |  | 5.4 | % |  |  |  | 5.2 | % |  |  |  |  |

- changed (2021-02-23):
[0001327567-21-000004:note_history:20]
On September 4, 2018, we entered into a credit agreement (the “Credit Agreement”) with certain institutional lenders that provides for a $400.0 million unsecured revolving credit facility (the “Credit Facility”), with an option to increase the amount of the Credit Facility by up to an additional $350.0 million, subject to certain conditions. The Credit Facility matures on the earlier of (i) September 4, 2023 and (ii) the date that is 91 days prior to the stated maturity of our 2023 Notes if (a) any of the 2023 Notes are still outstanding and (b) our unrestricted cash and cash equivalents are less than the then outstanding principal amount of our 2023 Notes plus $400.0 million.
  (was, 2020-11-19, similarity 0.8675):
[0001327567-20-000041:note_history:20]
On September 4, 2018, we entered into a credit agreement (the “Credit Agreement”) with certain institutional lenders that provides for a $400.0 million unsecured revolving credit facility (the “Credit Facility”), with an option to increase the amount of the Credit Facility by up to an additional $350.0 million, subject to certain conditions. The Credit Facility matures on the earlier of (i) September 4, 2023 and (ii) the date that is 91 days prior to the stated maturity of our 2023 Notes if (a) any of the 2023 Notes are

- changed (2021-02-23):
[0001327567-21-000004:note_history:21]
As of January 31, 2021, there were no amounts outstanding and we were in compliance with all covenants under the Credit Agreement.
  (was, 2020-11-19, similarity 0.9516):
[0001327567-20-000041:note_history:21]
As of October 31, 2020, there were no amounts outstanding and we were in compliance with all covenants under the Credit Agreement.

- removed (2021-02-23):
[0001327567-20-000041:note_history:22]
The sale price condition was not met for the Notes during the fiscal quarters ended October 31, 2020 or July 31, 2020. Since the Notes were not convertible, the net carrying amount of the Notes was classified as a long-term liability and the equity component was included in additional paid-in capital in our condensed consolidated balance sheets in the periods presented. As of October 31, 2020, all of the Notes remained outstanding.

- removed (2021-02-23):
[0001327567-20-000041:note_history:23]
The total estimated fair value of the Notes was $3.9 billion and $4.1 billion at October 31, 2020 and July 31, 2020, respectively. The fair value was determined based on the closing trading price per $100 of the Notes as of the last day of trading for the period. We consider the fair value of the Notes at October 31, 2020 and July 31, 2020 to be a Level 2 measurement. The fair value of the Notes is primarily affected by the trading price of our common stock and market interest rates. Based on the closing price of our common stock on October 31, 2020, the if-converted value of the Notes was less than its respective principal amount.

- removed (2021-02-23):
[0001327567-20-000041:note_history:24]
|  |  |  | Three Months Ended October 31, |
|  |  |  |  |  | 2020 |  | 2019 |
|  |  |  |  |  |  |  |  |  |  |  |  |  | 2023 Notes |  | 2025 Notes |  | Total |  | 2023 Notes |  |  |  | Total |
| Contractual interest expense |  |  |  |  |  |  |  |  |  |  |  |  | $ | 3.2 |  |  | $ | 1.9 |  |  | $ | 5.1 |  |  | $ | 3.2 |  |  |  | $ | 3.2 |  |
| Amortization of debt discount |  |  |  |  |  |  |  |  |  |  |  |  | 15.7 |  |  | 18.2 |  |  | 33.9 |  |  | 15.0 |  |  |  | 15.0 |  |
| Amortization of debt issuance costs |  |  |  |  |  |  |  |  |  |  |  |  | 0.5 |  |  | 0.7 |  |  | 1.2 |  |  | 0.5 |  |  |  | 0.5 |  |
| Total interest expense recognized |  |  |  |  |  |  |  |  |  |  |  |  | $ | 19.4 |  |  | $ | 20.8 |  |  | $ | 40.2 |  |  | $ | 18.7 |  |  |  | $ | 18.7 |  |
| Effective interest rate of the liability component |  |  |  |  |  |  |  |  |  |  |  |  | 5.2 | % |  | 5.4 | % |  |  |  | 5.2 | % |  |  |  |  |

- removed (2021-02-23):
[0001327567-20-000041:note_history:25]
still outstanding and (b) our unrestricted cash and cash equivalents are less than the then outstanding principal amount of our 2023 Notes plus $400.0 million.


## us-gaap:DebtSecuritiesAvailableForSaleTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-02-23):
[0001327567-21-000004:note_history:26]
The following tables summarize the amortized cost, unrealized gains and losses, and fair value of our available-for-sale debt securities as of January 31, 2021 and July 31, 2020 (in millions):
  (was, 2020-11-19, similarity 0.967):
[0001327567-20-000041:note_history:26]
The following tables summarize the amortized cost, unrealized gains and losses, and fair value of our available-for-sale debt securities as of October 31, 2020 and July 31, 2020 (in millions):

- changed (2021-02-23):
[0001327567-21-000004:note_history:27]
|  | January 31, 2021 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 150.1 |  |  | $ | — |  |  | $ | — |  |  | $ | 150.1 |  |
| Corporate debt securities | 1.9 |  |  | — |  |  | — |  |  | 1.9 |  |
| U.S. government and agency securities | 335.6 |  |  | — |  |  | — |  |  | 335.6 |  |
| Total available-for-sale cash equivalents | $ | 487.6 |  |  | $ | — |  |  | $ | — |  |  | $ | 487.6 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 27.2 |  |  | $ | — |  |  | $ | — |  |  | $ | 27.2 |  |
| Corporate debt securities | 322.0 |  |  | 1.0 |  |  | — |  |  | 323.0 |  |
| U.S. government and agency securities | 1,491.9 |  |  | 2.0 |  |  | — |  |  | 1,493.9 |  |
| Non-U.S. government securities | 71.0 |  |  | — |  |  | — |  |  | 71.0 |  |
| Total available-for-sale investments | $ | 1,912.1 |  |  | $ | 3.0 |  |  | $ | — |  |  | $ | 1,915.1 |  |
  (was, 2020-11-19, similarity 0.8977):
[0001327567-20-000041:note_history:27]
|  | October 31, 2020 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 150.0 |  |  | $ | — |  |  | $ | — |  |  | $ | 150.0 |  |
| U.S. government and agency securities | 407.6 |  |  | — |  |  | — |  |  | 407.6 |  |
| Total available-for-sale cash equivalents | $ | 557.6 |  |  | $ | — |  |  | $ | — |  |  | $ | 557.6 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 31.1 |  |  | $ | — |  |  | $ | — |  |  | $ | 31.1 |  |
| Commercial paper | 10.0 |  |  | — |  |  | — |  |  | 10.0 |  |
| Corporate debt securities | 330.7 |  |  | 1.3 |  |  | — |  |  | 332.0 |  |
| U.S. government and agency securities | 1,492.6 |  |  | 2.0 |  |  | (0.1) |  |  | 1,494.5 |  |
| Non-U.S. government securities | 81.2 |  |  | — |  |  | — |  |  | 81.2 |  |
| Total available-for-sale investments | $ | 1,945.6 |  |  | $ | 3.3 |  |  | $ | (0.1) |  |  | $ | 1,948.8 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-02-23):
[0001327567-21-000004:note_history:28]
The following tables summarize the amortized cost, unrealized gains and losses, and fair value of our available-for-sale debt securities as of January 31, 2021 and July 31, 2020 (in millions):
  (was, 2020-11-19, similarity 0.967):
[0001327567-20-000041:note_history:28]
The following tables summarize the amortized cost, unrealized gains and losses, and fair value of our available-for-sale debt securities as of October 31, 2020 and July 31, 2020 (in millions):

- changed (2021-02-23):
[0001327567-21-000004:note_history:29]
|  | January 31, 2021 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 150.1 |  |  | $ | — |  |  | $ | — |  |  | $ | 150.1 |  |
| Corporate debt securities | 1.9 |  |  | — |  |  | — |  |  | 1.9 |  |
| U.S. government and agency securities | 335.6 |  |  | — |  |  | — |  |  | 335.6 |  |
| Total available-for-sale cash equivalents | $ | 487.6 |  |  | $ | — |  |  | $ | — |  |  | $ | 487.6 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 27.2 |  |  | $ | — |  |  | $ | — |  |  | $ | 27.2 |  |
| Corporate debt securities | 322.0 |  |  | 1.0 |  |  | — |  |  | 323.0 |  |
| U.S. government and agency securities | 1,491.9 |  |  | 2.0 |  |  | — |  |  | 1,493.9 |  |
| Non-U.S. government securities | 71.0 |  |  | — |  |  | — |  |  | 71.0 |  |
| Total available-for-sale investments | $ | 1,912.1 |  |  | $ | 3.0 |  |  | $ | — |  |  | $ | 1,915.1 |  |
  (was, 2020-11-19, similarity 0.8977):
[0001327567-20-000041:note_history:29]
|  | October 31, 2020 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 150.0 |  |  | $ | — |  |  | $ | — |  |  | $ | 150.0 |  |
| U.S. government and agency securities | 407.6 |  |  | — |  |  | — |  |  | 407.6 |  |
| Total available-for-sale cash equivalents | $ | 557.6 |  |  | $ | — |  |  | $ | — |  |  | $ | 557.6 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 31.1 |  |  | $ | — |  |  | $ | — |  |  | $ | 31.1 |  |
| Commercial paper | 10.0 |  |  | — |  |  | — |  |  | 10.0 |  |
| Corporate debt securities | 330.7 |  |  | 1.3 |  |  | — |  |  | 332.0 |  |
| U.S. government and agency securities | 1,492.6 |  |  | 2.0 |  |  | (0.1) |  |  | 1,494.5 |  |
| Non-U.S. government securities | 81.2 |  |  | — |  |  | — |  |  | 81.2 |  |
| Total available-for-sale investments | $ | 1,945.6 |  |  | $ | 3.3 |  |  | $ | (0.1) |  |  | $ | 1,948.8 |  |

- changed (2021-02-23):
[0001327567-21-000004:note_history:30]
We do not intend to sell any of the securities in an unrealized loss position and it is not likely that we would be required to sell these securities before recovery of their amortized cost basis, which may be at maturity. We did not recognize any credit losses related to our available-for-sale debt securities during the three and six months ended January 31, 2021.
  (was, 2020-11-19, similarity 0.9692):
[0001327567-20-000041:note_history:30]
We do not intend to sell any of the securities in an unrealized loss position and it is not likely that we would be required to sell these securities before recovery of their amortized cost basis, which may be at maturity. We did not recognize any credit losses related to our available-for-sale debt securities during the three months ended October 31, 2020.

- changed (2021-02-23):
[0001327567-21-000004:note_history:31]
The following table summarizes the amortized cost and fair value of our available-for-sale debt securities as of January 31, 2021, by contractual years-to-maturity (in millions):
  (was, 2020-11-19, similarity 0.9651):
[0001327567-20-000041:note_history:31]
The following table summarizes the amortized cost and fair value of our available-for-sale debt securities as of October 31, 2020, by contractual years-to-maturity (in millions):

- changed (2021-02-23):
[0001327567-21-000004:note_history:32]
Marketable equity securities consist of money market funds and are included in cash and cash equivalents on our condensed consolidated balance sheets. As of January 31, 2021 and July 31, 2020, the carrying value of our marketable equity securities were $310.2 million and $1.6 billion, respectively. There were no unrealized gains or losses recognized for these securities during the three and six months ended January 31, 2021 and 2020.
  (was, 2020-11-19, similarity 0.8771):
[0001327567-20-000041:note_history:32]
Marketable equity securities consist of money market funds and are included in cash and cash equivalents on our condensed consolidated balance sheets. As of October 31, 2020 and July 31, 2020, the carrying value of our marketable equity securities were $392.3 million and $1.6 billion, respectively. There were no unrealized gains or losses recognized for these securities during the three months ended October 31, 2020 and 2019.


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2021-02-23):
[0001327567-21-000004:note_history:33]
|  | Three Months Ended January 31, |  | Six Months Ended January 31, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Revenue: |  |  |  |  |  |  |  |
| Americas |  |  |  |  |  |  |  |
| United States | $ | 644.0 |  |  | $ | 505.6 |  |  | $ | 1,272.4 |  |  | $ | 1,000.5 |  |
| Other Americas | 46.9 |  |  | 39.1 |  |  | 88.8 |  |  | 73.8 |  |
| Total Americas | 690.9 |  |  | 544.7 |  |  | 1,361.2 |  |  | 1,074.3 |  |
| Europe, the Middle East, and Africa (“EMEA”) | 205.8 |  |  | 166.2 |  |  | 376.7 |  |  | 313.8 |  |
| Asia Pacific and Japan (“APAC”) | 120.2 |  |  | 105.8 |  |  | 225.0 |  |  | 200.5 |  |
| Total revenue | $ | 1,016.9 |  |  | $ | 816.7 |  |  | $ | 1,962.9 |  |  | $ | 1,588.6 |  |

- added (2021-02-23):
[0001327567-21-000004:note_history:34]
|  | Three Months Ended January 31, |  | Six Months Ended January 31, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Revenue: |  |  |  |  |  |  |  |
| Product | $ | 254.7 |  |  | $ | 246.5 |  |  | $ | 492.0 |  |  | $ | 477.7 |  |
| Subscription and support |  |  |  |  |  |  |  |
| Subscription | 461.7 |  |  | 342.6 |  |  | 889.7 |  |  | 661.2 |  |
| Support | 300.5 |  |  | 227.6 |  |  | 581.2 |  |  | 449.7 |  |
| Total subscription and support | 762.2 |  |  | 570.2 |  |  | 1,470.9 |  |  | 1,110.9 |  |
| Total revenue | $ | 1,016.9 |  |  | $ | 816.7 |  |  | $ | 1,962.9 |  |  | $ | 1,588.6 |  |

- changed (2021-02-23):
[0001327567-21-000004:note_history:35]
During the six months ended January 31, 2021 and 2020, we recognized approximately $1.2 billion and $915.0 million of revenue pertaining to amounts that were deferred as of July 31, 2020 and 2019, respectively.
  (was, 2020-11-19, similarity 0.8168):
[0001327567-20-000041:note_history:35]
During the three months ended October 31, 2020, we recognized approximately $630.0 million of revenue pertaining to amounts that were deferred as of July 31, 2020.

- added (2021-02-23):
[0001327567-21-000004:note_history:36]
Revenue expected to be recognized from remaining performance obligations was $4.6 billion as of January 31, 2021, of which we expect to recognize approximately $2.5 billion over the next 12 months and the remainder thereafter.
Deferred Contract Costs
The following table presents details of our short-term and long-term deferred contract costs as of January 31, 2021 and July 31, 2020 (in millions):

- changed (2021-02-23):
[0001327567-21-000004:note_history:37]
|  | January 31, 2021 |  | July 31, 2020 |
| Short-term deferred contract costs | $ | 224.4 |  |  | $ | 206.0 |  |
| Long-term deferred contract costs | 410.5 |  |  | 422.3 |  |
| Total deferred contract costs | $ | 634.9 |  |  | $ | 628.3 |  |
  (was, 2020-11-19, similarity 0.9698):
[0001327567-20-000041:note_history:37]
|  | October 31, 2020 |  | July 31, 2020 |
| Short-term deferred contract costs | $ | 213.0 |  |  | $ | 206.0 |  |
| Long-term deferred contract costs | 408.8 |  |  | 422.3 |  |
| Total deferred contract costs | $ | 621.8 |  |  | $ | 628.3 |  |

- changed (2021-02-23):
[0001327567-21-000004:note_history:38]
We recognized amortization expense for our deferred contract costs of $68.6 million and $134.4 million during the three and six months ended January 31, 2021, respectively, and $55.3 million and $110.9 million during the three and six months ended January 31, 2020, respectively. We did not recognize any impairment losses on our deferred contract costs during the three and six months ended January 31, 2021 or 2020.
  (was, 2020-11-19, similarity 0.6697):
[0001327567-20-000041:note_history:38]
We recognized amortization expense for our deferred contract costs of $65.8 million and $55.6 million during the three months ended October 31, 2020 and 2019, respectively. We did not recognize any impairment losses on our deferred contract costs during the three months ended October 31, 2020 or 2019.

- removed (2021-02-23):
[0001327567-20-000041:note_history:39]
|  |  |  | Three Months Ended October 31, |
|  |  |  |  |  | 2020 |  | 2019 |
| Revenue: |  |  |  |  |  |  |  |
| Americas |  |  |  |  |  |  |  |
| United States |  |  |  |  | $ | 628.4 |  |  | $ | 494.9 |  |
| Other Americas |  |  |  |  | 41.9 |  |  | 34.7 |  |
| Total Americas |  |  |  |  | 670.3 |  |  | 529.6 |  |
| Europe, the Middle East, and Africa (“EMEA”) |  |  |  |  | 170.9 |  |  | 147.6 |  |
| Asia Pacific and Japan (“APAC”) |  |  |  |  | 104.8 |  |  | 94.7 |  |
| Total revenue |  |  |  |  | $ | 946.0 |  |  | $ | 771.9 |  |

- removed (2021-02-23):
[0001327567-20-000041:note_history:40]
|  |  |  | Three Months Ended October 31, |
|  |  |  |  |  | 2020 |  | 2019 |
| Revenue: |  |  |  |  |  |  |  |
| Product |  |  |  |  | $ | 237.3 |  |  | $ | 231.2 |  |
| Subscription and support |  |  |  |  |  |  |  |
| Subscription |  |  |  |  | 428.0 |  |  | 318.6 |  |
| Support |  |  |  |  | 280.7 |  |  | 222.1 |  |
| Total subscription and support |  |  |  |  | 708.7 |  |  | 540.7 |  |
| Total revenue |  |  |  |  | $ | 946.0 |  |  | $ | 771.9 |  |

- removed (2021-02-23):
[0001327567-20-000041:note_history:41]
Revenue expected to be recognized from remaining performance obligations was $4.4 billion as of October 31, 2020, of which we expect to recognize approximately $2.3 billion over the next 12 months and the remainder thereafter.
Deferred Contract Costs
The following table presents details of our short-term and long-term deferred contract costs as of October 31, 2020 and July 31, 2020 (in millions):


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- changed (2021-02-23):
[0001327567-21-000004:note_history:42]
Subsequent Events
Business Combination
  (was, 2020-11-19, similarity 0.987):
[0001327567-20-000041:note_history:42]
Subsequent Events
Business Combinations

- changed (2021-02-23):
[0001327567-21-000004:note_history:43]
In February 2021, we entered into a definitive agreement to acquire Bridgecrew Inc. (“Bridgecrew”), a privately-held cloud security company, for total consideration of approximately $200 million, including approximately $156 million in cash, and approximately $44 million in replacement equity awards, subject to adjustment. We expect the acquisition will expand our Prisma Cloud offering to deliver security across the full application lifecycle. The acquisition is expected to close during our third quarter of fiscal 2021.
  (was, 2020-11-19, similarity 0.6745):
[0001327567-20-000041:note_history:43]
In November 2020, we entered into a definitive agreement to acquire Expanse Inc. (“Expanse”), a privately-held company specializing in attack surface management, for total consideration of approximately $800 million, including approximately $670 million in cash and common stock, and approximately $130 million in replacement equity awards, subject to adjustment. We expect the acquisition will enrich our Cortex offerings and enable organizations an integrated view of the enterprise to combine external, internal, and threat data. The acquisition is expected to close during our second quarter of fiscal 2021.

- removed (2021-02-23):
[0001327567-20-000041:note_history:44]
In November 2020, we entered into a definitive agreement to acquire Sinefa Group, Inc. and its wholly owned subsidiaries (“Sinefa”), a privately-held digital experience monitoring company, for total consideration of approximately $44 million in cash, subject to adjustment. We expect the acquisition will extend our Prisma Access offering. The acquisition is expected to close during our second quarter of fiscal 2021.
