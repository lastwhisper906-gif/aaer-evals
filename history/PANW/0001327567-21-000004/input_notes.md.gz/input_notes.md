# PANW notes — 0001327567-21-000004


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0001327567-21-000004:notes:1]
[same as prior period, unchanged from 0001327567-20-000041:notes:1]

[0001327567-21-000004:notes:2]
[same as prior period, unchanged from 0001327567-20-000041:notes:2]

[0001327567-21-000004:notes:3]
[same as prior period, unchanged from 0001327567-20-000041:notes:3]

[0001327567-21-000004:notes:4]
[same as prior period, unchanged from 0001327567-20-000041:notes:4]

[0001327567-21-000004:notes:5]
Our condensed consolidated financial statements are unaudited but include all adjustments of a normal recurring nature necessary for a fair presentation of our quarterly results. Our condensed consolidated financial statements should be read in conjunction with the audited consolidated financial statements and related notes in our Annual Report on Form 10-K for the fiscal year ended July 31, 2020.

[0001327567-21-000004:notes:6]
[same as prior period, unchanged from 0001327567-20-000041:notes:6]

[0001327567-21-000004:notes:7]
[same as prior period, unchanged from 0001327567-20-000041:notes:7]

[0001327567-21-000004:notes:8]
[same as prior period, unchanged from 0001327567-20-000041:notes:8]

[0001327567-21-000004:notes:9]
There have been no material changes to our significant accounting policies as of and for the six months ended January 31, 2021, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended July 31, 2020, except for the change in our accounting policies for credit losses due to our adoption of the new credit losses guidance. Refer to “Recently Adopted Accounting Pronouncements” below.

[0001327567-21-000004:notes:10]
Recently Adopted Accounting Pronouncements

[0001327567-21-000004:notes:11]
[same as prior period, unchanged from 0001327567-20-000041:notes:11]

[0001327567-21-000004:notes:12]
[same as prior period, unchanged from 0001327567-20-000041:notes:12]

[0001327567-21-000004:notes:13]
[same as prior period, unchanged from 0001327567-20-000041:notes:13]

[0001327567-21-000004:notes:14]
[same as prior period, unchanged from 0001327567-20-000041:notes:14]

[0001327567-21-000004:notes:15]
[same as prior period, unchanged from 0001327567-20-000041:notes:15]

[0001327567-21-000004:notes:16]
[same as prior period, unchanged from 0001327567-20-000041:notes:16]

[0001327567-21-000004:notes:17]
recorded in other income (expense), net in our condensed consolidated statements of operations. Impairment losses that are not credit-related are included in accumulated other comprehensive income (loss) (“AOCI”) in stockholders’ equity.

[0001327567-21-000004:notes:18]
[same as prior period, unchanged from 0001327567-20-000041:notes:18]

[0001327567-21-000004:notes:19]
Trade accounts receivable are recorded at the invoiced amount, net of allowances for credit losses for any potential uncollectible amounts. The allowance for credit losses is based on our assessment of the collectability of accounts. Management regularly reviews the adequacy of the allowance for credit losses on a collective basis by considering the age of each outstanding invoice, each customer’s expected ability to pay and collection history, current market conditions, and reasonable and supportable forecasts of future economic conditions to determine whether the allowance is appropriate. Accounts receivable deemed uncollectible are charged against the allowance for credit losses when identified. For the three and six months ended January 31, 2021 and 2020, the allowance for credit losses activity was not significant.

[0001327567-21-000004:notes:20]
[same as prior period, unchanged from 0001327567-20-000041:notes:20]

[0001327567-21-000004:notes:21]
[same as prior period, unchanged from 0001327567-20-000041:notes:21]

[0001327567-21-000004:notes:22]
Recently Issued Accounting Pronouncements

[0001327567-21-000004:notes:23]
[same as prior period, unchanged from 0001327567-20-000041:notes:23]

[0001327567-21-000004:notes:24]
In August 2020, the FASB issued new authoritative guidance to simplify the accounting for certain financial instruments with characteristics of liabilities and equity, including convertible instruments and contracts on an entity’s own equity. The standard reduces the number of models used to account for convertible instruments and simplifies both the classification of debt on the balance sheet and the earnings per share calculation. The standard is effective for us in our first quarter of fiscal 2023 and will be applied on a modified retrospective basis. Early adoption is permitted from our first quarter of fiscal 2022. We are currently evaluating the impact of this standard on our condensed consolidated financial statements.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001327567-21-000004:notes:25]
[same as prior period, unchanged from 0001327567-20-000041:notes:25]

[0001327567-21-000004:notes:26]
[same as prior period, unchanged from 0001327567-20-000041:notes:26]

[0001327567-21-000004:notes:27]
|  | Three Months Ended January 31, |  | Six Months Ended January 31, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Revenue: |  |  |  |  |  |  |  |
| Americas |  |  |  |  |  |  |  |
| United States | $ | 644.0 |  |  | $ | 505.6 |  |  | $ | 1,272.4 |  |  | $ | 1,000.5 |  |
| Other Americas | 46.9 |  |  | 39.1 |  |  | 88.8 |  |  | 73.8 |  |
| Total Americas | 690.9 |  |  | 544.7 |  |  | 1,361.2 |  |  | 1,074.3 |  |
| Europe, the Middle East, and Africa (“EMEA”) | 205.8 |  |  | 166.2 |  |  | 376.7 |  |  | 313.8 |  |
| Asia Pacific and Japan (“APAC”) | 120.2 |  |  | 105.8 |  |  | 225.0 |  |  | 200.5 |  |
| Total revenue | $ | 1,016.9 |  |  | $ | 816.7 |  |  | $ | 1,962.9 |  |  | $ | 1,588.6 |  |

[0001327567-21-000004:notes:28]
[same as prior period, unchanged from 0001327567-20-000041:notes:28]

[0001327567-21-000004:notes:29]
|  | Three Months Ended January 31, |  | Six Months Ended January 31, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Revenue: |  |  |  |  |  |  |  |
| Product | $ | 254.7 |  |  | $ | 246.5 |  |  | $ | 492.0 |  |  | $ | 477.7 |  |
| Subscription and support |  |  |  |  |  |  |  |
| Subscription | 461.7 |  |  | 342.6 |  |  | 889.7 |  |  | 661.2 |  |
| Support | 300.5 |  |  | 227.6 |  |  | 581.2 |  |  | 449.7 |  |
| Total subscription and support | 762.2 |  |  | 570.2 |  |  | 1,470.9 |  |  | 1,110.9 |  |
| Total revenue | $ | 1,016.9 |  |  | $ | 816.7 |  |  | $ | 1,962.9 |  |  | $ | 1,588.6 |  |

[0001327567-21-000004:notes:30]
[same as prior period, unchanged from 0001327567-20-000041:notes:30]

[0001327567-21-000004:notes:31]
During the six months ended January 31, 2021 and 2020, we recognized approximately $1.2 billion and $915.0 million of revenue pertaining to amounts that were deferred as of July 31, 2020 and 2019, respectively.

[0001327567-21-000004:notes:32]
[same as prior period, unchanged from 0001327567-20-000041:notes:32]

[0001327567-21-000004:notes:33]
Revenue expected to be recognized from remaining performance obligations was $4.6 billion as of January 31, 2021, of which we expect to recognize approximately $2.5 billion over the next 12 months and the remainder thereafter.
Deferred Contract Costs
The following table presents details of our short-term and long-term deferred contract costs as of January 31, 2021 and July 31, 2020 (in millions):

[0001327567-21-000004:notes:34]
|  | January 31, 2021 |  | July 31, 2020 |
| Short-term deferred contract costs | $ | 224.4 |  |  | $ | 206.0 |  |
| Long-term deferred contract costs | 410.5 |  |  | 422.3 |  |
| Total deferred contract costs | $ | 634.9 |  |  | $ | 628.3 |  |

[0001327567-21-000004:notes:35]
We recognized amortization expense for our deferred contract costs of $68.6 million and $134.4 million during the three and six months ended January 31, 2021, respectively, and $55.3 million and $110.9 million during the three and six months ended January 31, 2020, respectively. We did not recognize any impairment losses on our deferred contract costs during the three and six months ended January 31, 2021 or 2020.


## us-gaap:FairValueDisclosuresTextBlock

[0001327567-21-000004:notes:36]
Fair Value Measurements 
We categorize assets and liabilities recorded or disclosed at fair value on our condensed consolidated balance sheets based upon the level of judgment associated with inputs used to measure their fair value. The categories are as follows:

[0001327567-21-000004:notes:37]
•Level 1—Inputs are unadjusted quoted prices in active markets for identical assets or liabilities.

[0001327567-21-000004:notes:38]
•Level 2—Inputs are quoted prices for similar assets and liabilities in active markets or inputs that are observable for the assets or liabilities, either directly or indirectly through market corroboration, for substantially the full term of the financial instruments.

[0001327567-21-000004:notes:39]
•Level 3—Inputs are unobservable inputs based on our own assumptions used to measure assets and liabilities at fair value. The inputs require significant management judgment or estimation.

[0001327567-21-000004:notes:40]
The following table presents the fair value of our financial assets and liabilities measured at fair value on a recurring basis using the above input categories as of January 31, 2021 and July 31, 2020 (in millions):

[0001327567-21-000004:notes:41]
|  |  | January 31, 2021 |  | July 31, 2020 |
|  |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Cash equivalents: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 310.2 |  |  | $ | — |  |  | $ | — |  |  | $ | 310.2 |  |  | $ | 1,589.5 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,589.5 |  |
| Certificates of deposit |  | — |  |  | 150.1 |  |  | — |  |  | 150.1 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Corporate debt securities |  | — |  |  | 1.9 |  |  | — |  |  | 1.9 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| U.S. government and agency securities |  | — |  |  | 335.6 |  |  | — |  |  | 335.6 |  |  | — |  |  | 342.0 |  |  | — |  |  | 342.0 |  |
| Total cash equivalents |  | 310.2 |  |  | 487.6 |  |  | — |  |  | 797.8 |  |  | 1,589.5 |  |  | 342.0 |  |  | — |  |  | 1,931.5 |  |
| Short-term investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Certificates of deposit |  | — |  |  | 22.2 |  |  | — |  |  | 22.2 |  |  | — |  |  | 26.9 |  |  | — |  |  | 26.9 |  |
| Corporate debt securities |  | — |  |  | 206.1 |  |  | — |  |  | 206.1 |  |  | — |  |  | 100.2 |  |  | — |  |  | 100.2 |  |
| U.S. government and agency securities |  | — |  |  | 791.5 |  |  | — |  |  | 791.5 |  |  | — |  |  | 645.6 |  |  | — |  |  | 645.6 |  |
| Non-U.S. government and agency securities |  |  |  | 38.2 |  |  |  |  | 38.2 |  |  |  |  | 17.1 |  |  |  |  | 17.1 |  |
| Total short-term investments |  | — |  |  | 1,058.0 |  |  | — |  |  | 1,058.0 |  |  | — |  |  | 789.8 |  |  | — |  |  | 789.8 |  |
| Long-term investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Certificates of deposit |  | — |  |  | 5.0 |  |  | — |  |  | 5.0 |  |  | — |  |  | 5.0 |  |  | — |  |  | 5.0 |  |
| Corporate debt securities |  | — |  |  | 116.9 |  |  | — |  |  | 116.9 |  |  | — |  |  | 91.7 |  |  | — |  |  | 91.7 |  |
| U.S. government and agency securities |  | — |  |  | 702.4 |  |  | — |  |  | 702.4 |  |  | — |  |  | 447.4 |  |  | — |  |  | 447.4 |  |
| Non-U.S. government and agency securities |  | — |  |  | 32.8 |  |  | — |  |  | 32.8 |  |  | — |  |  | 10.3 |  |  | — |  |  | 10.3 |  |
| Total long-term investments |  | — |  |  | 857.1 |  |  | — |  |  | 857.1 |  |  | — |  |  | 554.4 |  |  | — |  |  | 554.4 |  |
| Prepaid expenses and other current assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency forward contracts |  | — |  |  | 17.6 |  |  | — |  |  | 17.6 |  |  | — |  |  | 13.6 |  |  | — |  |  | 13.6 |  |
| Total prepaid expenses and other current assets |  | — |  |  | 17.6 |  |  | — |  |  | 17.6 |  |  | — |  |  | 13.6 |  |  | — |  |  | 13.6 |  |
| Other assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency forward contracts |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 1.4 |  |  | — |  |  | 1.4 |  |
| Total other assets: |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 1.4 |  |  | — |  |  | 1.4 |  |
| Total assets measured at fair value |  | $ | 310.2 |  |  | $ | 2,420.3 |  |  | $ | — |  |  | $ | 2,730.5 |  |  | $ | 1,589.5 |  |  | $ | 1,701.2 |  |  | $ | — |  |  | $ | 3,290.7 |  |
| Accrued and other liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency forward contracts |  | $ | — |  |  | $ | 0.1 |  |  | $ | — |  |  | $ | 0.1 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Total accrued and other liabilities |  | — |  |  | 0.1 |  |  | — |  |  | 0.1 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Total liabilities measured at fair value |  | $ | — |  |  | $ | 0.1 |  |  | $ | — |  |  | $ | 0.1 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |

[0001327567-21-000004:notes:42]
Refer to Note 10. Debt for the carrying amount and estimated fair value of our convertible senior notes as of January 31, 2021 and July 31, 2020.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001327567-21-000004:notes:43]
Cash Equivalents and Investments
Available-for-sale Debt Securities

[0001327567-21-000004:notes:44]
The following tables summarize the amortized cost, unrealized gains and losses, and fair value of our available-for-sale debt securities as of January 31, 2021 and July 31, 2020 (in millions):

[0001327567-21-000004:notes:45]
|  | January 31, 2021 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 150.1 |  |  | $ | — |  |  | $ | — |  |  | $ | 150.1 |  |
| Corporate debt securities | 1.9 |  |  | — |  |  | — |  |  | 1.9 |  |
| U.S. government and agency securities | 335.6 |  |  | — |  |  | — |  |  | 335.6 |  |
| Total available-for-sale cash equivalents | $ | 487.6 |  |  | $ | — |  |  | $ | — |  |  | $ | 487.6 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 27.2 |  |  | $ | — |  |  | $ | — |  |  | $ | 27.2 |  |
| Corporate debt securities | 322.0 |  |  | 1.0 |  |  | — |  |  | 323.0 |  |
| U.S. government and agency securities | 1,491.9 |  |  | 2.0 |  |  | — |  |  | 1,493.9 |  |
| Non-U.S. government securities | 71.0 |  |  | — |  |  | — |  |  | 71.0 |  |
| Total available-for-sale investments | $ | 1,912.1 |  |  | $ | 3.0 |  |  | $ | — |  |  | $ | 1,915.1 |  |

[0001327567-21-000004:notes:46]
|  | July 31, 2020 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| U.S. government and agency securities | $ | 342.0 |  |  | $ | — |  |  | $ | — |  |  | $ | 342.0 |  |
| Total available-for-sale cash equivalents | $ | 342.0 |  |  | $ | — |  |  | $ | — |  |  | $ | 342.0 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 31.9 |  |  | $ | — |  |  | $ | — |  |  | $ | 31.9 |  |
| Corporate debt securities | 190.1 |  |  | 1.8 |  |  | — |  |  | 191.9 |  |
| U.S. government and agency securities | 1,090.3 |  |  | 2.8 |  |  | (0.1) |  |  | 1,093.0 |  |
| Non-U.S. government and agency securities | 27.4 |  |  | — |  |  | — |  |  | 27.4 |  |
| Total available-for-sale investments | $ | 1,339.7 |  |  | $ | 4.6 |  |  | $ | (0.1) |  |  | $ | 1,344.2 |  |

[0001327567-21-000004:notes:47]
We do not intend to sell any of the securities in an unrealized loss position and it is not likely that we would be required to sell these securities before recovery of their amortized cost basis, which may be at maturity. We did not recognize any credit losses related to our available-for-sale debt securities during the three and six months ended January 31, 2021.

[0001327567-21-000004:notes:48]
The following table summarizes the amortized cost and fair value of our available-for-sale debt securities as of January 31, 2021, by contractual years-to-maturity (in millions):

[0001327567-21-000004:notes:49]
|  | Amortized Cost |  | Fair Value |
| Due within one year | $ | 1,544.2 |  |  | $ | 1,545.6 |  |
| Due between one and three years | 855.5 |  |  | 857.1 |  |
| Total | $ | 2,399.7 |  |  | $ | 2,402.7 |  |

[0001327567-21-000004:notes:50]
Marketable Equity Securities

[0001327567-21-000004:notes:51]
Marketable equity securities consist of money market funds and are included in cash and cash equivalents on our condensed consolidated balance sheets. As of January 31, 2021 and July 31, 2020, the carrying value of our marketable equity securities were $310.2 million and $1.6 billion, respectively. There were no unrealized gains or losses recognized for these securities during the three and six months ended January 31, 2021 and 2020.


## us-gaap:FinancingReceivablesTextBlock

[0001327567-21-000004:notes:52]
Financing Receivables
We provide financing arrangements, primarily loans, for certain qualified end-user customers to purchase our products. The following table summarizes our short-term and long-term financing receivables as of January 31, 2021 (in millions):

[0001327567-21-000004:notes:53]
|  |  | Amount |
| Short-term financing receivables, gross |  | $ | 26.8 |  |
| Allowance for credit losses |  | (0.3) |  |
| Short-term financing receivables, net |  | $ | 26.5 |  |
| Long-term financing receivables, gross |  | $ | 38.9 |  |
| Allowance for credit losses |  | (0.4) |  |
| Long-term financing receivables, net |  | $ | 38.5 |  |

[0001327567-21-000004:notes:54]
Through July 31, 2020, financing receivables were not significant to our condensed consolidated balance sheet. There was no significant activity in allowance for credit losses during the three and six months ended January 31, 2021. Past due amounts on financing receivables were immaterial as of January 31, 2021 and July 31, 2020.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001327567-21-000004:notes:55]
[same as prior period, unchanged from 0001327567-20-000041:notes:55]

[0001327567-21-000004:notes:56]
As of January 31, 2021 and July 31, 2020, the total notional amount of our outstanding foreign currency forward contracts was $286.5 million and $443.6 million, respectively. Refer to Note 3. Fair Value Measurements for the fair value of our derivative instruments as reported on our condensed consolidated balance sheets as of January 31, 2021.

[0001327567-21-000004:notes:57]
During the three and six months ended January 31, 2021 and 2020, both unrealized gains and losses recognized in AOCI related to our cash flow hedges and amounts reclassified into earnings were not material. Unrealized gains and losses in AOCI related to our cash flow hedges as of January 31, 2021 and 2020 were not material.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001327567-21-000004:notes:58]
Acquisitions
Expanse Inc.

[0001327567-21-000004:notes:59]
On December 15, 2020, we completed our acquisition of Expanse Inc. (“Expanse”), a privately-held company specializing in attack surface management. We expect the acquisition will enrich our Cortex offerings and provide organizations an integrated view of the enterprise to combine external, internal, and threat data. The total purchase consideration for the acquisition of Expanse was $797.2 million, which consisted of the following (in millions):

[0001327567-21-000004:notes:60]
|  | Amount |
| Cash | $ | 434.9 |  |
| Common stock (1.1 million shares) | 340.7 |  |
| Fair value of replacement awards | 21.6 |  |
| Total | $ | 797.2 |  |

[0001327567-21-000004:notes:61]
As part of the acquisition, we issued replacement equity awards, which included 0.2 million shares of our restricted common stock. The total fair value of the replacement equity awards was $160.0 million, of which the portion attributable to services performed prior to the acquisition date was allocated to purchase consideration. The remaining fair value was allocated to future services and will be expensed over the remaining service periods as share-based compensation.

[0001327567-21-000004:notes:62]
[same as prior period, unchanged from 0001327567-20-000041:notes:62]

[0001327567-21-000004:notes:63]
|  | Amount |
| Goodwill | $ | 601.2 |  |
| Identified intangible assets | 160.3 |  |
| Cash | 51.1 |  |
| Net liabilities assumed | (15.4) |  |
| Total | $ | 797.2 |  |

[0001327567-21-000004:notes:64]
Goodwill generated from this business combination is primarily attributable to the assembled workforce and expected post-acquisition synergies from integrating Expanse technology into our platforms. The goodwill is not deductible for income tax purposes.

[0001327567-21-000004:notes:65]
[same as prior period, unchanged from 0001327567-20-000041:notes:65]

[0001327567-21-000004:notes:66]
|  | Fair Value |  | Estimated Useful Life |
| Developed technology | $ | 123.4 |  |  | 6 years |
| Customer relationships | 36.9 |  |  | 10 years |
| Total | $ | 160.3 |  |  |  |

[0001327567-21-000004:notes:67]
Sinefa Group, Inc.

[0001327567-21-000004:notes:68]
On November 24, 2020, we completed our acquisition of Sinefa Group, Inc. and its wholly owned subsidiaries (“Sinefa”), a privately-held digital experience monitoring company. We believe the acquisition will extend our Prisma Access offering. The total purchase consideration for the acquisition of Sinefa was $27.0 million, which consisted of the following (in millions):

[0001327567-21-000004:notes:69]
|  | Amount |
| Cash | $ | 26.9 |  |
| Fair value of replacement awards | 0.1 |  |
| Total | $ | 27.0 |  |

[0001327567-21-000004:notes:70]
As part of the acquisition, we issued $11.5 million of replacement equity awards, of which the portion attributable to services performed prior to the acquisition date was allocated to purchase consideration. The remaining fair value was allocated to future services and will be expensed over the remaining service periods as share-based compensation.

[0001327567-21-000004:notes:71]
|  | Amount |
| Goodwill | $ | 13.7 |  |
| Identified intangible assets | 20.4 |  |
| Net liabilities assumed | (7.1) |  |
| Total | $ | 27.0 |  |

[0001327567-21-000004:notes:72]
Goodwill generated from this business combination is primarily attributable to the assembled workforce and expected post-acquisition synergies from integrating Sinefa technology into our platforms. The goodwill is deductible for income tax purposes.

[0001327567-21-000004:notes:73]
|  | Fair Value |  | Estimated Useful Life |
| Developed technology | $ | 18.6 |  |  | 6 years |
| Customer relationships | 1.8 |  |  | 8 years |
| Total | $ | 20.4 |  |  |  |

[0001327567-21-000004:notes:74]
The Crypsis Group

[0001327567-21-000004:notes:75]
[same as prior period, unchanged from 0001327567-20-000041:notes:59]

[0001327567-21-000004:notes:76]
[same as prior period, unchanged from 0001327567-20-000041:notes:60]

[0001327567-21-000004:notes:77]
[same as prior period, unchanged from 0001327567-20-000041:notes:61]

[0001327567-21-000004:notes:78]
[same as prior period, unchanged from 0001327567-20-000041:notes:63]

[0001327567-21-000004:notes:79]
[same as prior period, unchanged from 0001327567-20-000041:notes:64]

[0001327567-21-000004:notes:80]
[same as prior period, unchanged from 0001327567-20-000041:notes:66]

[0001327567-21-000004:notes:81]
[same as prior period, unchanged from 0001327567-20-000041:notes:67]

[0001327567-21-000004:notes:82]
The operating results of the acquired companies are included in our condensed consolidated statements of operations from the respective dates of acquisition. Pro forma results of operations have not been presented because the effects of the acquisitions were not material to our condensed consolidated statements of operations.

[0001327567-21-000004:notes:83]
Additional information related to the acquired companies, such as that related to income tax and other contingencies, existing as of the respective acquisition dates but unknown to us, may become known during the remainders of the respective measurement periods, not to exceed 12 months from each such acquisition date, which may result in changes to the amounts and allocations recorded.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001327567-21-000004:notes:84]
[same as prior period, unchanged from 0001327567-20-000041:notes:70]

[0001327567-21-000004:notes:85]
The following table presents details of our goodwill during the six months ended January 31, 2021 (in millions):

[0001327567-21-000004:notes:86]
|  | Amount |
| Balance as of July 31, 2020 | $ | 1,812.9 |  |
| Goodwill acquired | 772.5 |  |
| Measurement period adjustment | (1.9) |  |
| Balance as of January 31, 2021 | $ | 2,583.5 |  |

[0001327567-21-000004:notes:87]
[same as prior period, unchanged from 0001327567-20-000041:notes:73]

[0001327567-21-000004:notes:88]
The following table presents details of our purchased intangible assets as of January 31, 2021 and July 31, 2020 (in millions):

[0001327567-21-000004:notes:89]
|  | January 31, 2021 |  | July 31, 2020 |
|  | Gross Carrying Amount |  | Accumulated Amortization |  | Net Carrying Amount |  | Gross Carrying Amount |  | Accumulated Amortization |  | Net Carrying Amount |
| Intangible assets subject to amortization: |  |  |  |  |  |  |  |  |  |  |  |
| Developed technology | $ | 574.6 |  |  | $ | (191.0) |  |  | $ | 383.6 |  |  | $ | 425.9 |  |  | $ | (146.6) |  |  | $ | 279.3 |  |
| Customer relationships | 172.7 |  |  | (19.7) |  |  | 153.0 |  |  | 87.6 |  |  | (12.4) |  |  | 75.2 |  |
| Acquired intellectual property | 7.8 |  |  | (3.5) |  |  | 4.3 |  |  | 6.3 |  |  | (3.2) |  |  | 3.1 |  |
| Trade name and trademarks | 9.4 |  |  | (9.4) |  |  | — |  |  | 9.4 |  |  | (9.4) |  |  | — |  |
| Other | 2.8 |  |  | (2.6) |  |  | 0.2 |  |  | 3.1 |  |  | (2.5) |  |  | 0.6 |  |
| Total purchased intangible assets | $ | 767.3 |  |  | $ | (226.2) |  |  | $ | 541.1 |  |  | $ | 532.3 |  |  | $ | (174.1) |  |  | $ | 358.2 |  |

[0001327567-21-000004:notes:90]
We recognized amortization expense of $29.7 million and $53.3 million for the three and six months ended January 31, 2021, respectively, and $17.9 million and $34.8 million for the three and six months ended January 31, 2020, respectively.

[0001327567-21-000004:notes:91]
The following table summarizes estimated future amortization expense of our intangible assets as of January 31, 2021 (in millions):

[0001327567-21-000004:notes:92]
|  | Amount |
| Fiscal years ending July 31: |  |
| Remaining 2021 | $ | 62.7 |  |
| 2022 | 122.1 |  |
| 2023 | 96.0 |  |
| 2024 | 86.0 |  |
| 2025 | 72.3 |  |
| 2026 and thereafter | 102.0 |  |
| Total future amortization expense | $ | 541.1 |  |


## us-gaap:DebtDisclosureTextBlock

[0001327567-21-000004:notes:93]
Debt
Convertible Senior Notes

[0001327567-21-000004:notes:94]
In July 2018, we issued $1.7 billion aggregate principal amount of 0.75% Convertible Senior Notes due 2023 (the “2023 Notes”) and, in June 2020, we issued $2.0 billion aggregate principal amount of 0.375% Convertible Senior Notes due 2025 (the “2025 Notes,” and together with the 2023 Notes, the “Notes”). The 2023 Notes bear interest at a fixed rate of 0.75% per year, payable semi-annually in arrears on January 1 and July 1 of each year, beginning on January 1, 2019. The 2025 Notes bear interest at a fixed rate of 0.375% per year, payable semi-annually in arrears on June 1 and December 1 of each year, beginning on December 1, 2020. Each series of the convertible notes is governed by an indenture between us, as the issuer, and U.S. Bank National Association, as Trustee (individually, each an “Indenture,” and together, the “Indentures”). The Notes of each series are unsecured, unsubordinated obligations and the applicable Indenture governing each series of Notes does not contain any financial covenants or restrictions on the payments of dividends, the incurrence of indebtedness, or the issuance or repurchase of securities by us or any of our subsidiaries. The

[0001327567-21-000004:notes:95]
2023 Notes and the 2025 Notes mature on July 1, 2023 and June 1, 2025, respectively. We cannot redeem the 2023 Notes prior to maturity. We may redeem for cash all or any portion of the 2025 Notes, at our option, on or after June 5, 2023, and prior to the 31st scheduled trading day immediately preceding the maturity date if the last reported sale price of our common stock has been at least 130% of the conversion price then in effect for at least 20 trading days during any 30 consecutive trading day period ending on and including the trading day preceding the date on which we provide notice of redemption. The redemption will be at a price equal to 100% of the principal amount of the 2025 Notes and adjusted for interest. If we call any or all of the 2025 Notes for redemption, holders may convert such 2025 Notes called for redemption at any time prior to the close of business on the second scheduled trading day immediately preceding the redemption date.

[0001327567-21-000004:notes:96]
The following table presents details of our Notes (number of shares in millions):

[0001327567-21-000004:notes:97]
|  | Conversion Rate per $1,000 Principal |  | Initial Conversion Price |  | Convertible Date |  | Initial Number of Shares |
| 2023 Notes | 3.7545 |  |  | $ | 266.35 |  |  | April 1, 2023 |  | 6.4 |  |
| 2025 Notes | 3.3602 |  |  | $ | 297.60 |  |  | March 1, 2025 |  | 6.7 |  |

[0001327567-21-000004:notes:98]
Holders of the Notes may surrender their Notes for conversion at their option at any time prior to the close of business on the business day immediately preceding their respective convertible dates only under the following circumstances:

[0001327567-21-000004:notes:99]
•during any fiscal quarter commencing after the fiscal quarters ending on October 31, 2018 and October 31, 2020 for the 2023 Notes and the 2025 Notes, respectively (and only during such fiscal quarter), if the last reported sale price of our common stock for at least 20 trading days (whether or not consecutive) during a period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the applicable conversion price for the respective Notes on each applicable trading day (the “sale price condition”);

[0001327567-21-000004:notes:100]
•during the five business day period after any five consecutive trading day period (the “measurement period”) in which the trading price per $1,000 principal amount of the applicable series of Notes for each trading day of the measurement period was less than 98% of the product of the last reported sale price of our common stock and the applicable conversion rate for the respective Notes on each such trading day; or

[0001327567-21-000004:notes:101]
•upon the occurrence of specified corporate events.

[0001327567-21-000004:notes:102]
On or after the respective convertible date, holders may surrender all or any portion of their Notes for conversion at any time prior to the close of business on the second scheduled trading day immediately preceding the applicable maturity date regardless of the foregoing conditions, and such conversions will be settled upon the applicable maturity date. Upon conversion, holders of the Notes of a series will receive cash equal to the aggregate principal amount of the Notes of such series to be converted, and, at our election, cash and/or shares of our common stock for any amounts in excess of the aggregate principal amount of the Notes of such series being converted.

[0001327567-21-000004:notes:103]
The conversion price will be subject to adjustment in some events. Holders of the Notes of a series who convert their Notes of such series in connection with certain corporate events that constitute a “make-whole fundamental change” under the applicable Indenture are, under certain circumstances, entitled to an increase in the conversion rate for such series of Notes. Additionally, upon the occurrence of a corporate event that constitutes a “fundamental change” under the applicable Indenture, holders of the Notes of such series may require us to repurchase for cash all or a portion of the Notes of such series at a repurchase price equal to 100% of the principal amount of the Notes of such series plus accrued and unpaid interest to, but excluding, the fundamental change repurchase date.

[0001327567-21-000004:notes:104]
The sale price condition was met for the 2023 Notes during the fiscal quarter ended January 31, 2021, and as a result, holders may convert their 2023 Notes at any time during the fiscal quarter ending April 30, 2021. Accordingly, the net carrying amount of the 2023 Notes was reclassified into current liabilities and the portion of the equity component representing the conversion option was reclassified into temporary equity in our condensed consolidated balance sheet as of January 31, 2021. The portion of the equity component classified as temporary equity is measured as the difference between the principal and net carrying amount of the 2023 Notes, excluding debt issuance costs.

[0001327567-21-000004:notes:105]
The sale price condition was not met for the 2025 Notes during the fiscal quarters ended January 31, 2021 and July 31, 2020 and was not met for the 2023 Notes during the fiscal quarter ended July 31, 2020. Since the 2025 Notes for both periods and the 2023 Notes as of July 31, 2020 were not convertible, the associated net carrying amount was classified as a long-term liability and the equity component was included in additional paid-in capital in our condensed consolidated balance sheets.

[0001327567-21-000004:notes:106]
As of January 31, 2021, all of the Notes remained outstanding.

[0001327567-21-000004:notes:107]
The following table sets forth the components of the Notes as of January 31, 2021 and July 31, 2020 (in millions):

[0001327567-21-000004:notes:108]
|  | January 31, 2021 | July 31, 2020 |
|  | 2023 Notes |  | 2025 Notes |  | Total |  | 2023 Notes |  | 2025 Notes |  | Total |
| Liability component: |  |  |  |  |  |  |  |  |  |  |  |
| Principal | $ | 1,693.0 |  |  | $ | 2,000.0 |  |  | $ | 3,693.0 |  |  | $ | 1,693.0 |  |  | $ | 2,000.0 |  |  | $ | 3,693.0 |  |
| Less: debt discount and debt issuance costs, net of amortization | 167.4 |  |  | 370.9 |  |  | 538.3 |  |  | 200.0 |  |  | 408.9 |  |  | 608.9 |  |
| Net carrying amount | $ | 1,525.6 |  |  | $ | 1,629.1 |  |  | $ | 3,154.7 |  |  | $ | 1,493.0 |  |  | $ | 1,591.1 |  |  | $ | 3,084.1 |  |
| Equity component (including amounts classified as temporary equity) | $ | 315.0 |  |  | $ | 403.0 |  |  | $ | 718.0 |  |  | $ | 315.0 |  |  | $ | 403.0 |  |  | $ | 718.0 |  |

[0001327567-21-000004:notes:109]
The total estimated fair value of the Notes was $5.0 billion and $4.1 billion at January 31, 2021 and July 31, 2020, respectively. The fair value was determined based on the closing trading price per $100 of the Notes as of the last day of trading for the period. We consider the fair value of the Notes at January 31, 2021 and July 31, 2020 to be a Level 2 measurement. The fair value of the Notes is primarily affected by the trading price of our common stock and market interest rates. Based on the closing price of our common stock on January 31, 2021, the if-converted values of the 2023 Notes and 2025 Notes exceeded their principal amounts by $575.4 million and $398.1 million, respectively.

[0001327567-21-000004:notes:110]
The following table sets forth interest expense recognized related to the Notes (dollars in millions):

[0001327567-21-000004:notes:111]
|  | Three Months Ended January 31, |  | Six Months Ended January 31, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
|  | 2023 Notes |  | 2025 Notes |  | Total |  | 2023 Notes |  |  |  | Total |  | 2023 Notes |  | 2025 Notes |  | Total |  | 2023 Notes |  |  |  | Total |
| Contractual interest expense | $ | 3.1 |  | $ | 1.9 |  | $ | 5.0 |  |  | $3.1 |  |  |  | $ | 3.1 |  |  | $ | 6.3 |  | $ | 3.8 |  | $ | 10.1 |  |  | $ | 6.3 |  |  |  | $ | 6.3 |  |
| Amortization of debt discount | 15.7 |  | 18.5 |  | 34.2 |  |  | 15.2 |  |  |  | 15.2 |  |  | 31.4 |  | 36.7 |  | 68.1 |  |  | 30.2 |  |  |  | 30.2 |  |
| Amortization of debt issuance costs | 0.6 |  | 0.7 |  | 1.3 |  |  | 0.5 |  |  |  | 0.5 |  |  | 1.1 |  | 1.4 |  | 2.5 |  |  | 1.0 |  |  |  | 1.0 |  |
| Total interest expense recognized | $ | 19.4 |  | $ | 21.1 |  | $ | 40.5 |  |  | $ | 18.8 |  |  |  | $ | 18.8 |  |  | $ | 38.8 |  | $ | 41.9 |  | $ | 80.7 |  |  | $ | 37.5 |  |  |  | $ | 37.5 |  |
| Effective interest rate of the liability component | 5.2 | % |  | 5.4 | % |  |  |  | 5.2 | % |  |  |  |  |  | 5.2 | % |  | 5.4 | % |  |  |  | 5.2 | % |  |  |  |  |

[0001327567-21-000004:notes:112]
Note Hedges

[0001327567-21-000004:notes:113]
To minimize the impact of potential economic dilution upon conversion of our Notes, we entered into separate convertible note hedge transactions (the “2023 Note Hedges,” with respect to the 2023 Notes, the “2025 Note Hedges,” with respect to the 2025 Notes, and the 2023 Notes Hedges together with 2025 Note Hedges, the “Note Hedges”) with respect to our common stock concurrent with the issuance of each series of the Notes.

[0001327567-21-000004:notes:114]
The following table presents details of our Note Hedges (in millions):

[0001327567-21-000004:notes:115]
|  | Initial Number of Shares |  | Aggregate Purchase |
| 2023 Note Hedges | 6.4 |  |  | $ | 332.0 |  |
| 2025 Note Hedges | 6.7 |  |  | $ | 370.8 |  |

[0001327567-21-000004:notes:116]
The Note Hedges cover shares of our common stock at a strike price per share that corresponds to the initial applicable conversion price of the applicable series of the Notes, which are also subject to adjustment, and are exercisable upon conversion of the applicable series of the Notes. The Note Hedges will expire upon maturity of the applicable series of the Notes. The Note Hedges are separate transactions and are not part of the terms of the applicable series of the Notes. Holders of the Notes of either series will not have any rights with respect to the Note Hedges. Any shares of our common stock receivable by us under the Note Hedges are excluded from the calculation of diluted earnings per share as they are antidilutive. The aggregate amounts paid for the Note Hedges are included in additional paid-in capital in our condensed consolidated balance sheets.

[0001327567-21-000004:notes:117]
Warrants

[0001327567-21-000004:notes:118]
Separately, but concurrently with the issuance of each series of our Notes, we entered into transactions whereby we sold warrants (the “2023 Warrants,” with respect to the 2023 Notes, the “2025 Warrants,” with respect to the 2025 Notes, and the 2023 Warrants together with the 2025 Warrants, the “Warrants”) to acquire shares of our common stock, subject to anti-dilution adjustments. The 2023 Warrants and 2025 Warrants are exercisable beginning October 2023 and September 2025, respectively.

[0001327567-21-000004:notes:119]
The following table presents details of the Warrants (in millions, except per share data):

[0001327567-21-000004:notes:120]
|  | Initial Number of Shares |  | Strike Price per Share |  | Aggregate Proceeds |
| 2023 Warrants | 6.4 |  |  | $ | 417.80 |  |  | $ | 145.4 |  |
| 2025 Warrants | 6.7 |  |  | $ | 408.47 |  |  | $ | 202.8 |  |

[0001327567-21-000004:notes:121]
The shares issuable under the Warrants will be included in the calculation of diluted earnings per share when the average market value per share of our common stock for the reporting period exceeds the applicable strike price for such series of Warrants. The Warrants are separate transactions and are not part of either series of Notes or Note Hedges and are not remeasured through earnings each reporting period. Holders of the Notes of either series will not have any rights with respect to the Warrants. The aggregate proceeds received from the sale of the Warrants are included in additional paid-in capital in our condensed consolidated balance sheets.

[0001327567-21-000004:notes:122]
Revolving Credit Facility

[0001327567-21-000004:notes:123]
On September 4, 2018, we entered into a credit agreement (the “Credit Agreement”) with certain institutional lenders that provides for a $400.0 million unsecured revolving credit facility (the “Credit Facility”), with an option to increase the amount of the Credit Facility by up to an additional $350.0 million, subject to certain conditions. The Credit Facility matures on the earlier of (i) September 4, 2023 and (ii) the date that is 91 days prior to the stated maturity of our 2023 Notes if (a) any of the 2023 Notes are still outstanding and (b) our unrestricted cash and cash equivalents are less than the then outstanding principal amount of our 2023 Notes plus $400.0 million.

[0001327567-21-000004:notes:124]
The borrowings under the Credit Facility currently bear interest, at our option, at a base rate plus a spread of 0.00% to 0.75%, or an adjusted LIBO Rate plus a spread of 1.00% to 1.75%, in each case with such spread being determined based on our leverage ratio. We are obligated to pay an ongoing commitment fee on undrawn amounts at a rate of 0.125% to 0.250%, depending on our leverage ratio. Regulatory authorities that oversee financial markets have announced that after the end of 2021, they would no longer compel banks currently reporting information used to set the LIBO Rate to continue to make rate submissions. As a result, it is possible that beginning in 2022, the LIBO Rate will no longer be available as a reference rate. Under the terms of our Credit Facility, in the event of the discontinuance of the LIBO Rate, a mutually agreed-upon alternative benchmark rate will be established to replace the LIBO Rate, which may include the Secured Overnight Financing Rate (“SOFR”). We do not anticipate that the discontinuance of the LIBO Rate will materially impact our liquidity or financial position.

[0001327567-21-000004:notes:125]
As of January 31, 2021, there were no amounts outstanding and we were in compliance with all covenants under the Credit Agreement.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001327567-21-000004:notes:126]
Commitments and Contingencies
Purchase Commitments

[0001327567-21-000004:notes:127]
Manufacturing Purchase Commitments

[0001327567-21-000004:notes:128]
Our electronics manufacturing service provider (“EMS provider”) procures components and assembles our products based on our forecasts. These forecasts are based on estimates of demand for our products primarily for the next 12 months, which are in turn based on historical trends and an analysis from our sales and product management organizations, adjusted for overall market conditions. In order to reduce manufacturing lead times and plan for adequate supply, we may issue non-cancelable orders for products and components to our manufacturing partners or component suppliers. As of January 31, 2021, our purchase commitments under such orders were $157.7 million excluding obligations under contracts that we can cancel without a significant penalty.

[0001327567-21-000004:notes:129]
Other Purchase Commitments

[0001327567-21-000004:notes:130]
We have entered into various non-cancelable agreements with certain service providers, under which we are committed to minimum or fixed purchases through the year ending July 31, 2026. The following table presents details of the aggregate future non-cancelable purchase commitments under these agreements as of January 31, 2021 (in millions):

[0001327567-21-000004:notes:131]
|  | Amount |
| Fiscal years ending July 31: |  |
| Remaining 2021 | $ | — |  |
| 2022 | 134.3 |  |
| 2023 | 227.2 |  |
| 2024 | 285.7 |  |
| 2025 | 345.3 |  |
| 2026 and thereafter | 551.1 |  |
| Total other purchase commitments | $ | 1,543.6 |  |

[0001327567-21-000004:notes:132]
Litigation

[0001327567-21-000004:notes:133]
We are subject to legal proceedings, claims, and litigation arising in the ordinary course of business, including intellectual property litigation. Such matters are subject to many uncertainties and outcomes are not predictable with assurance. We accrue for contingencies when we believe that a loss is probable and that we can reasonably estimate the amount of any such loss.

[0001327567-21-000004:notes:134]
To the extent there is a reasonable possibility that a loss exceeding amounts already recognized may be incurred and the amount of such additional loss would be material, we will either disclose the estimated additional loss or state that such an estimate cannot be made. As of January 31, 2021, we have not recorded any significant accruals for loss contingencies associated with such legal proceedings, determined that an unfavorable outcome is probable or reasonably possible, or determined that the amount or range of any possible loss is reasonably estimable.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001327567-21-000004:notes:135]
[same as prior period, unchanged from 0001327567-20-000041:notes:119]

[0001327567-21-000004:notes:136]
In February 2019, our board of directors authorized a $1.0 billion share repurchase program, which is funded from available working capital. In December 2020, our board of directors authorized a $700.0 million increase to our share repurchase program, bringing the total authorization to $1.7 billion. The expiration date of this repurchase authorization was extended to December 31, 2021, and our repurchase program may be suspended or discontinued at any time. Repurchases under our program are to be made at management’s discretion from time to time on the open market, through privately negotiated transactions, transactions structured through investment banking institutions, block purchase techniques, 10b5-1 trading plans, or a combination of the foregoing.

[0001327567-21-000004:notes:137]
During the six months ended January 31, 2021, we repurchased and retired 2.1 million shares of our common stock under the authorization for an aggregate purchase price of $500.0 million, including transaction costs, at an average price of $242.44 per share. The total price of the shares repurchased and related transaction costs were reflected as a reduction to common stock and additional paid-in capital on our condensed consolidated balance sheets. As of January 31, 2021, $1.0 billion remained available for future share repurchases under our current repurchase authorization.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001327567-21-000004:notes:138]
[same as prior period, unchanged from 0001327567-20-000041:notes:123]

[0001327567-21-000004:notes:139]
Expanse Holding Company, Inc. Amended and Restated 2012 Stock Incentive Plan

[0001327567-21-000004:notes:140]
In connection with our acquisition of Expanse in December 2020, we assumed the Expanse Holding Company, Inc. Amended and Restated 2012 Stock Incentive Plan (the “Expanse Plan”), under which the assumed Expanse equity awards were granted. The assumed equity awards will be settled in shares of our common stock and will retain the terms and conditions under which they were originally granted; forfeited awards will not be returned to the Expanse Plan. No additional equity awards will be granted under the Expanse Plan. Refer to Note 7. Acquisitions for more information on our Expanse acquisition and the related equity awards assumed.

[0001327567-21-000004:notes:141]
Sinefa Group, Inc.2020 Stock Plan

[0001327567-21-000004:notes:142]
In connection with our acquisition of Sinefa in November 2020, we assumed the Sinefa Group, Inc. 2020 Stock Plan (the “Sinefa Plan”), under which the assumed Sinefa equity awards were granted. The assumed equity awards will be settled in shares of our common stock and will retain the terms and conditions under which they were originally granted; forfeited awards will not be returned to the Sinefa Plan. No additional equity awards will be granted under the Sinefa Plan. Refer to Note 7. Acquisitions for more information on our Sinefa acquisition and the related equity awards assumed.

[0001327567-21-000004:notes:143]
[same as prior period, unchanged from 0001327567-20-000041:notes:124]

[0001327567-21-000004:notes:144]
In connection with our acquisition of Crypsis in September 2020, we assumed the Crypsis Group Holdings, LLC 2017 Equity Incentive Plan (the “Crypsis Group Plan”), under which the assumed Crypsis equity awards were granted. The assumed equity awards will be settled in shares of our common stock and will retain the terms and conditions under which they were originally granted; forfeited awards will not be returned to the Crypsis Group Plan. No additional equity awards will be granted under the Crypsis Group Plan. Refer to Note 7. Acquisitions for more information on our Crypsis acquisition and the related equity awards assumed.

[0001327567-21-000004:notes:145]
[same as prior period, unchanged from 0001327567-20-000041:notes:126]

[0001327567-21-000004:notes:146]
We have granted PSOs with both a market condition and a service condition to certain executives. The market condition for PSOs granted in the fiscal years 2018 and 2019 requires the price of our common stock to equal or exceed $297.75, $397.00, $496.25, and $595.50 during the four-, five-, six-, and seven-and-a-half-year periods following the date of grant in fiscal year 2018 and 2019, respectively. The market condition for PSOs granted in the quarter ended January 31, 2021 requires the price of our common stock to equal or exceed $397.00, $496.25, $595.50 and $700.00 during the three-, four-, five-, and six-and-a-half-year periods following the date of grant. To the extent that the market condition has been met, one-fourth of the PSOs will vest on the anniversary date of the grant date for such PSOs, subject to continued service. Certain outstanding PSOs may be exercised prior to vesting (“early exercise”). Shares of common stock issued upon early exercise of the PSOs will be restricted and, at our option, subject to repurchase if the option holder ceases to be a service provider. The maximum contractual term of our PSOs ranged from six and a half years to seven and a half years from the date of grant, depending on vesting period. During the six months ended January 31, 2021, 0.3 million shares of our PSOs vested as the first stock price target for our PSOs granted in fiscal years 2018 and 2019 was satisfied and the service condition was met.

[0001327567-21-000004:notes:147]
The following table summarizes the PSO activity under our stock plans during the reporting period (in millions, except per share amounts):

[0001327567-21-000004:notes:148]
|  |  |  | PSOs Outstanding |
|  |  |  |  |  |  |  |  |  | Number of Shares |  | Weighted-Average Exercise Price Per Share |  | Weighted-Average Remaining Contractual Term(Years) |  | Aggregate Intrinsic Value |
| Balance—July 31, 2020 |  |  |  |  |  |  |  |  | 2.8 |  | $ | 194.14 |  |  | 5.2 |  | $ | 170.9 |  |
| Granted |  |  |  |  |  |  |  |  | 0.2 |  | $ | 304.29 |  |  |  |  |  |
| Balance—January 31, 2021 |  |  |  |  |  |  |  |  | 3.0 |  | $ | 200.97 |  |  | 4.8 |  | $ | 441.7 |  |
| Exercisable—January 31, 2021 |  |  |  |  |  |  |  |  | 2.8 |  | $ | 194.14 |  |  | 4.7 |  | $ | 433.2 |  |

[0001327567-21-000004:notes:149]
[same as prior period, unchanged from 0001327567-20-000041:notes:128]

[0001327567-21-000004:notes:150]
[same as prior period, unchanged from 0001327567-20-000041:notes:129]

[0001327567-21-000004:notes:151]
|  | RSUs Outstanding |  | PSUs Outstanding |
|  | Number of Shares |  | Weighted-Average Grant-Date Fair Value Per Share |  |  |  | Aggregate Intrinsic Value |  | Number of Shares |  | Weighted-Average Grant-Date Fair Value Per Share |  |  |  | Aggregate Intrinsic Value |
| Balance—July 31, 2020 | 6.6 |  |  | $ | 203.30 |  |  |  |  | $ | 1,688.1 |  |  | 0.6 |  |  | $ | 231.42 |  |  |  |  | $ | 147.2 |  |
| Granted | 3.2 |  |  | $ | 278.45 |  |  |  |  |  |  | 0.4 |  |  | $ | 244.15 |  |  |  |  |  |
| Vested | (1.4) |  |  | $ | 195.08 |  |  |  |  |  |  | (0.1) |  |  | $ | 204.03 |  |  |  |  |  |
| Forfeited | (0.4) |  |  | $ | 209.19 |  |  |  |  |  |  | 0.0 |  |  | $ | 232.00 |  |  |  |  |  |
| Balance—January 31, 2021 | 8.0 |  |  | $ | 234.13 |  |  |  |  | $ | 2,805.3 |  |  | 0.9 |  |  | $ | 238.98 |  |  |  |  | $ | 305.8 |  |

[0001327567-21-000004:notes:152]
Our PSUs generally vest over a period of one to four years from the date of grant. The actual number of PSUs earned and eligible to vest is determined based on the level of achievement against revenue growth, pre-established billings and operating margin goals, or pre-defined individual performance targets for the fiscal year.

[0001327567-21-000004:notes:153]
[same as prior period, unchanged from 0001327567-20-000041:notes:132]

[0001327567-21-000004:notes:154]
[same as prior period, unchanged from 0001327567-20-000041:notes:133]

[0001327567-21-000004:notes:155]
|  | Three Months Ended |  | Six Months Ended |
|  | January 31, |  | January 31, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Cost of product revenue | $ | 1.6 |  |  | $ | 1.6 |  |  | $ | 3.1 |  |  | $ | 2.9 |  |
| Cost of subscription and support revenue | 23.8 |  |  | 20.0 |  |  | 46.0 |  |  | 38.9 |  |
| Research and development | 103.6 |  |  | 67.0 |  |  | 199.0 |  |  | 129.4 |  |
| Sales and marketing | 69.7 |  |  | 54.9 |  |  | 134.6 |  |  | 98.7 |  |
| General and administrative | 42.4 |  |  | 29.4 |  |  | 71.3 |  |  | 54.2 |  |
| Total share-based compensation | $ | 241.1 |  |  | $ | 172.9 |  |  | $ | 454.0 |  |  | $ | 324.1 |  |

[0001327567-21-000004:notes:156]
During the three and six months ended January 31, 2021, we accelerated the vesting of certain equity awards in connection with our acquisitions; as a result, we recorded $15.5 million and $22.6 million, respectively, of share-based compensation within general and administrative expense in our condensed consolidated statements of operations.
As of January 31, 2021, total compensation cost related to unvested share-based awards not yet recognized was $2.1 billion. This cost is expected to be amortized over a weighted-average period of approximately 2.8 years.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001327567-21-000004:notes:157]
Income Taxes
For the three and six months ended January 31, 2021, our provision for income taxes reflects an effective tax rate of negative 9.5% and negative 10.5%, respectively. Our effective tax rate for the six months ended January 31, 2021 was negative as we recorded a provision for income taxes on year-to-date losses primarily due to income taxes in profitable foreign jurisdictions and withholding taxes. For the three months ended January 31, 2021, our foreign income tax and withholding tax were largely offset by the effects of one-time tax benefits of $5.1 million and $8.2 million as a result of our acquisitions of Expanse and Sinefa. Our effective tax rates differ from the U.S. statutory tax rate primarily due to changes in our valuation allowance.

[0001327567-21-000004:notes:158]
Our provision for income taxes for the three and six months ended January 31, 2020 reflects an effective tax rate of negative 20.6% and negative 15.3%, respectively. Our effective tax rate for the six months ended January 31, 2020 was negative as we recorded a provision for income taxes on year-to-date losses. The provision for income taxes for the six months ended January 31, 2020, is primarily due to income taxes in profitable foreign jurisdictions, U.S. state taxes, and withholding taxes. Our effective tax rates differ from the U.S. statutory tax rate primarily due to deductibility of our share-based compensation, foreign income at other than U.S. tax rates, and changes in our valuation allowance.


## us-gaap:EarningsPerShareTextBlock

[0001327567-21-000004:notes:159]
[same as prior period, unchanged from 0001327567-20-000041:notes:139]

[0001327567-21-000004:notes:160]
[same as prior period, unchanged from 0001327567-20-000041:notes:140]

[0001327567-21-000004:notes:161]
|  | Three Months Ended |  | Six Months Ended |
|  | January 31, |  | January 31, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Net loss | $ | (142.3) |  |  | $ | (73.7) |  |  | $ | (234.5) |  |  | $ | (133.3) |  |
| Weighted-average shares used to compute net loss per share, basic and diluted | 95.9 |  |  | 98.3 |  |  | 95.7 |  |  | 97.5 |  |
| Net loss per share, basic and diluted | $ | (1.48) |  |  | $ | (0.75) |  |  | $ | (2.45) |  |  | $ | (1.37) |  |

[0001327567-21-000004:notes:162]
[same as prior period, unchanged from 0001327567-20-000041:notes:142]

[0001327567-21-000004:notes:163]
|  | Three and Six Months Ended |
|  | January 31, |
|  | 2021 |  | 2020 |
| Convertible senior notes | 13.1 |  |  | 6.4 |  |
| Warrants related to the issuance of convertible senior notes | 13.1 |  |  | 6.4 |  |
| RSUs and PSUs | 8.9 |  |  | 7.2 |  |
| Options to purchase common stock, including PSOs | 3.0 |  |  | 3.1 |  |
| Restricted stock awards and performance-based stock awards | 0.5 |  |  | 0.1 |  |
| ESPP shares | 0.3 |  |  | 0.2 |  |
| Total | 38.9 |  |  | 23.4 |  |


## us-gaap:OtherNonoperatingIncomeAndExpenseTextBlock

[0001327567-21-000004:notes:164]
Other Income (expense), Net
The following table sets forth the components of other income (expense), net (in millions):

[0001327567-21-000004:notes:165]
|  | Three Months Ended |  | Six Months Ended |
|  | January 31, |  | January 31, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Interest income | $ | 2.3 |  |  | $ | 13.9 |  |  | $ | 5.2 |  |  | $ | 29.7 |  |
| Foreign currency exchange losses, net | (3.7) |  |  | (2.4) |  |  | (1.6) |  |  | (2.0) |  |
| Other | 0.9 |  |  | (0.7) |  |  | (1.7) |  |  | (0.7) |  |
| Total other income (expense), net | $ | (0.5) |  |  | $ | 10.8 |  |  | $ | 1.9 |  |  | $ | 27.0 |  |


## us-gaap:SubsequentEventsTextBlock

[0001327567-21-000004:notes:166]
Subsequent Events
Business Combination

[0001327567-21-000004:notes:167]
In February 2021, we entered into a definitive agreement to acquire Bridgecrew Inc. (“Bridgecrew”), a privately-held cloud security company, for total consideration of approximately $200 million, including approximately $156 million in cash, and approximately $44 million in replacement equity awards, subject to adjustment. We expect the acquisition will expand our Prisma Cloud offering to deliver security across the full application lifecycle. The acquisition is expected to close during our third quarter of fiscal 2021.
