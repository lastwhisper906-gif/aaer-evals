# PANW note change history — 0001327567-15-000018 → 0001327567-15-000036


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- added (2015-11-24):
[0001327567-15-000036:note_history:1]
In May 2015, we entered into three lease agreements for approximately 752,000 square feet of corporate office space in Santa Clara, California to serve as our future corporate headquarters. In October 2015, we entered into a fourth lease agreement for approximately 310,000 square feet of additional office space at the same location, which will commence in December 2017 and expire in April 2028. The site is currently under construction and as a result, the lease commencement date may change based on progress of the construction project. The lease contains a rent holiday period, scheduled rent increases, lease incentives, and renewal options which allow the lease term to be extended through April 2046. Rental payments under the fourth lease agreement are approximately $101.2 million over the initial lease term.

- changed (2015-11-24):
[0001327567-15-000036:note_history:2]
The following table presents details of the aggregate future non-cancelable minimum rental payments under our operating leases as of October 31, 2015 (in millions):
  (was, 2015-05-28, similarity 0.9338):
[0001327567-15-000018:note_history:2]
The following table presents details of the aggregate future non-cancelable minimum rental payments under our operating leases as of April 30, 2015 (in thousands):

- changed (2015-11-24):
[0001327567-15-000036:note_history:3]
Our independent contract manufacturer procures components and assembles our products based on our forecasts. These forecasts are based on estimates of demand for our products primarily for the next 12 months, which are in turn based on historical trends and an analysis from our sales and product marketing organizations, adjusted for overall market conditions. In order to reduce manufacturing lead times and plan for adequate supply, we may issue forecasts and orders for components and products that are non-cancelable. As of October 31, 2015, our purchase commitments under such orders were $46.3 million, excluding obligations under contracts that we can cancel without a significant penalty.
  (was, 2015-05-28, similarity 0.7926):
[0001327567-15-000018:note_history:3]
Our independent contract manufacturer procures components and assembles our products based on our forecasts. These forecasts are based on estimates of demand for our products primarily for the next twelve months, which are in turn based on historical trends and an analysis from our sales and product marketing organizations, adjusted for overall market conditions. In order to reduce manufacturing lead times and plan for adequate supply, we may issue forecasts and orders for components and products that are non-cancelable. Obligations under contracts that we can cancel without a significant penalty are not included. As of April 30, 2015, we had $41,772,000 of open orders.

- changed (2015-11-24):
[0001327567-15-000036:note_history:4]
We are subject to legal proceedings, claims, and litigation arising in the ordinary course of business, including intellectual property litigation. Such matters are subject to many uncertainties and outcomes are not predictable with assurance. We accrue for contingencies when we believe that a loss is probable and that we can reasonably estimate the amount of any such loss.
  (was, 2015-05-28, similarity 0.958):
[0001327567-15-000018:note_history:4]
In addition to the above matter, we are subject to legal proceedings, claims, and litigation arising in the ordinary course of business, including intellectual property litigation. Such matters are subject to many uncertainties and outcomes are not predictable with assurance. We accrue for contingencies when we believe that a loss is probable and that we can reasonably estimate the amount of any such loss.

- changed (2015-11-24):
[0001327567-15-000036:note_history:5]
To the extent there is a reasonable possibility that a loss exceeding amounts already recognized may be incurred and the amount of such additional loss would be material, we will either disclose the estimated additional loss or state that such an estimate cannot be made. As of October 31, 2015, we have not recorded any significant accruals for loss contingencies associated with such legal proceedings, determined that an unfavorable outcome is probable or reasonably possible, or determined that the amount or range of any possible loss is reasonably estimable.
  (was, 2015-05-28, similarity 0.9892):
[0001327567-15-000018:note_history:5]
To the extent there is a reasonable possibility that a loss exceeding amounts already recognized may be incurred and the amount of such additional loss would be material, we will either disclose the estimated additional loss or state that such an estimate cannot be made. As of April 30, 2015, we have not recorded any significant accruals for loss contingencies associated with such legal proceedings, determined that an unfavorable outcome is probable or reasonably possible, or determined that the amount or range of any possible loss is reasonably estimable.

- removed (2015-11-24):
[0001327567-15-000018:note_history:6]
In December 2011, Juniper Networks, Inc. (“Juniper”) filed a complaint against us in the United States District Court for the District of Delaware alleging patent infringement, which sought preliminary and permanent injunctions against infringement, treble damages, and attorneys' fees. On September 30, 2013, we filed a lawsuit against Juniper in the United States District Court for the Northern District of California alleging that Juniper’s products infringe three of our U.S. patents, and sought monetary damages and a permanent injunction. On May 27, 2014, we entered into a Settlement, Release and Cross-License Agreement (the “settlement agreement”) with Juniper to resolve all pending litigation between the parties, including those discussed above. Refer to Note 8. Legal Settlement for more information on the settlement agreement.


## us-gaap:LegalMattersAndContingenciesTextBlock (contingencies) — matched_by: no_current_note, score: 0.0

- removed (2015-11-24):
[0001327567-15-000018:note_history:7]
Legal Settlement

- removed (2015-11-24):
[0001327567-15-000018:note_history:8]
Mutual Covenant Not to Sue and Release Agreement

- removed (2015-11-24):
[0001327567-15-000018:note_history:9]
On January 27, 2014, we executed a Mutual Covenant Not to Sue and Release Agreement with Fortinet, Inc., thereby extending an existing covenant for six more years. We evaluated the transaction as a multiple-element arrangement and allocated the one-time payment that we made in the amount of $20,000,000 to each identifiable element using its relative fair value. Based on our estimates of fair value, we determined that the primary benefit of the arrangement is avoided litigation cost and the release of any potential past claims, with no material value attributable to future use or benefit. Accordingly, we recorded a $20,000,000 settlement charge within legal settlement expense in our condensed consolidated statement of operations during the three months ended January 31, 2014.

- removed (2015-11-24):
[0001327567-15-000018:note_history:10]
Settlement, Release and Cross-License Agreement with Juniper

- removed (2015-11-24):
[0001327567-15-000018:note_history:11]
On May 27, 2014, we entered into the settlement agreement with Juniper, whereby we resolved all pending litigation matters. Under the terms of the settlement agreement, we agreed to pay Juniper a one-time settlement amount comprised of $75,000,000 in cash, 1,081,000 shares of our common stock, and a warrant to purchase 463,000 shares of our common stock, in exchange for the following:

- removed (2015-11-24):
[0001327567-15-000018:note_history:12]
| • | Mutual dismissal with prejudice of all pending litigation between the parties and general release of all liability for Palo Alto Networks and Juniper, |

- removed (2015-11-24):
[0001327567-15-000018:note_history:13]
| • | Cross-license between both parties for the patents-in-suit and associated family members and counterparts worldwide for the life of the patents, and |

- removed (2015-11-24):
[0001327567-15-000018:note_history:14]
| • | Mutual covenant not to sue for infringement of any other patents for a period of eight years. |

- removed (2015-11-24):
[0001327567-15-000018:note_history:15]
The fair value of the total consideration as of the settlement date was $182,473,000, which was comprised of $75,000,000 in cash, $75,231,000 in common stock, and $32,242,000 in warrant. The fair values of the common stock and warrant were measured using the closing price of our common stock on the settlement date.

- removed (2015-11-24):
[0001327567-15-000018:note_history:16]
The warrant was issued on June 3, 2014 and entitled Juniper to purchase up to 463,000 shares of common stock at an exercise price of $0.0001 per share and was classified as a liability during the period it was outstanding. On July 1, 2014, Juniper exercised the warrant in full. Accordingly, we recorded the change in the fair value of the warrant liability through the exercise date of $5,859,000 within other income (expense), net in our consolidated statement of operations during the three months ended July 31, 2014.

- removed (2015-11-24):
[0001327567-15-000018:note_history:17]
We accounted for the settlement agreement as a multiple-element arrangement and allocated the fair value of the consideration as of the settlement date to the identifiable elements based on their estimated fair values. Of the total settlement amount, $61,300,000 was allocated to the licensing of intellectual property, $54,300,000 was allocated to the mutual dismissal of claims, and the remaining amount was allocated to the mutual covenant not to sue. The mutual dismissal of claims and the mutual covenant not to sue have no identifiable future benefit, and as a result we recorded a settlement charge within legal settlement expense in our condensed consolidated statement of operations during the three months ended April 30, 2014. The licensing of intellectual property is being amortized to cost of product revenue in our condensed consolidated statements of operations over the estimated period of benefit of five years.


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2015-11-24):
[0001327567-15-000036:note_history:18]
Palo Alto Networks, Inc. (the “Company,” “we,” “us,” or “our”), located in Santa Clara, California, was incorporated in March 2005 under the laws of the State of Delaware and commenced operations in April 2005. We offer a next-generation security platform that empowers enterprises, service providers, and government entities to secure their organizations by safely enabling the increasingly complex and rapidly growing number of applications running on their networks and by preventing breaches in real-time that stem from targeted cyber attacks.
  (was, 2015-05-28, similarity 0.8857):
[0001327567-15-000018:note_history:18]
Palo Alto Networks, Inc. (the “Company,” “we,” “us,” or “our”), located in Santa Clara, California, was incorporated in March 2005 under the laws of the State of Delaware and commenced operations in April 2005. We offer a next-generation enterprise security platform that allows enterprises, service providers, and government entities to simultaneously empower and secure their organizations by safely enabling the increasingly complex and rapidly growing number of applications running on their networks and by preventing breaches stemming from targeted cyber attacks.

- added (2015-11-24):
[0001327567-15-000036:note_history:19]
The accompanying condensed consolidated financial statements have been prepared in conformity with U.S. generally accepted accounting principles, consistent in all material respects with those applied in our Annual Report on Form 10-K for the fiscal year ended July 31, 2015, filed with the Securities and Exchange Commission on September 17, 2015. The condensed consolidated financial statements are unaudited, but include all adjustments of a normal recurring nature necessary for a fair presentation of our quarterly results. We have made estimates and judgments affecting the amounts reported in our condensed consolidated financial statements and the accompanying notes. The actual results that we experience may differ materially from our estimates. Certain prior period amounts have been reclassified to conform to current period presentation.

- added (2015-11-24):
[0001327567-15-000036:note_history:20]
The condensed consolidated financial statements should be read in conjunction with the consolidated financial statements and related notes in our Annual Report on Form 10-K for the fiscal year ended July 31, 2015.

- changed (2015-11-24):
[0001327567-15-000036:note_history:21]
There have been no material changes to our significant accounting policies as of and for the three months ended October 31, 2015, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended July 31, 2015.
  (was, 2015-05-28, similarity 0.9022):
[0001327567-15-000018:note_history:21]
There have been no material changes to our significant accounting policies as of and for the nine months ended April 30, 2015, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended July 31, 2014.

- changed (2015-11-24):
[0001327567-15-000036:note_history:22]
In April 2015, the Financial Accounting Standards Board (FASB) issued new authoritative guidance on fees paid in a cloud computing arrangement. The standard requires customers in a cloud computing arrangement to evaluate whether the arrangement includes a software license. If the arrangement includes a software license, the customer should account for the software license element of the arrangement consistent with the acquisition of other software licenses. If the arrangement does not include a software license, the customer should account for the arrangement as a service contract. The standard is effective for us for our first quarter of fiscal 2017 and will be applied on either a prospective or retrospective basis. We are currently evaluating adoption methods and whether this standard will have a material impact on our condensed consolidated financial statements.
  (was, 2015-05-28, similarity 0.9786):
[0001327567-15-000018:note_history:22]
In April 2015, the Financial Accounting Standards Board (FASB) issued new authoritative guidance on fees paid in a cloud computing arrangement. The standard requires customers in a cloud computing arrangement to evaluate whether the arrangement includes a software license. If the arrangement includes a software license, the customer should account for the software license element of the arrangement consistent with the acquisition of other software licenses. If the arrangement does not include a software license, the customer should account for the arrangement as a service contract. The standard is effective for us for our first quarter of fiscal 2017, although early adoption is permitted, and will be applied on either a prospective or retrospective basis. We are currently evaluating adoption methods and whether this standard will have a material impact on our condensed consolidated financial statements.

- changed (2015-11-24):
[0001327567-15-000036:note_history:23]
In April 2015, the FASB issued updated authoritative guidance to simplify the presentation of debt issuance costs. The amended standard requires that debt issuance costs related to a recognized debt liability be presented in the balance sheet as a direct deduction from the carrying amount of the related debt liability, consistent with the presentation of debt discounts, instead of being presented as an asset. The amended standard is effective for us for our first quarter of fiscal 2017 and will be applied on a retrospective basis. We do not expect the adoption of the standard will have a material impact on our condensed consolidated financial statements.
  (was, 2015-05-28, similarity 0.7787):
[0001327567-15-000018:note_history:23]
In April 2015, the FASB issued updated authoritative guidance to simplify the presentation of debt issuance costs. The amended standard requires that debt issuance costs related to a recognized debt liability be presented in the balance sheet as a direct deduction from the carrying amount of the related debt liability, consistent with the presentation of debt discounts, instead of being presented as an asset. The amended standard is effective for us for our first quarter of fiscal 2017, although early adoption is permitted, and will be applied on a retrospective basis. Upon adoption, the amended standard will change the classification of our unamortized debt issuance costs in our condensed consolidated balance sheets.

- added (2015-11-24):
[0001327567-15-000036:note_history:24]
In May 2014, the FASB issued new authoritative guidance on revenue from contracts with customers. The new standard provides principles for recognizing revenue for the transfer of promised goods or services to customers with the consideration to which the entity expects to be entitled in exchange for those goods or services. The standard also requires significantly expanded disclosures about revenue recognition. The FASB subsequently delayed the effective date of the standard by one year and as a result, the standard is now effective for us for our first quarter of fiscal 2019 using either of two methods: (i) retrospective to each prior reporting period presented with the option to elect certain practical expedients as defined within the guidance; or (ii) retrospective with the cumulative effect of initially applying the guidance recognized at the date of initial application and providing certain additional disclosures as defined per the guidance. Early adoption as of the original effective date is permitted. We are currently evaluating adoption methods and whether this standard will have a material impact on our condensed consolidated financial statements.

- removed (2015-11-24):
[0001327567-15-000018:note_history:25]
The accompanying condensed consolidated financial statements have been prepared in conformity with U.S. generally accepted accounting principles, consistent in all material respects with those applied in our Annual Report on Form 10-K for the fiscal year ended July 31, 2014. The condensed consolidated financial statements include all adjustments necessary for a fair presentation of our quarterly results. All adjustments are of a normal recurring nature. We have made estimates and judgments affecting the amounts reported in our condensed consolidated financial statements and the accompanying notes. The actual results that we experience may differ materially from our estimates. Certain prior period amounts have been reclassified to conform with current period presentation.

- removed (2015-11-24):
[0001327567-15-000018:note_history:26]
In August 2014, the FASB issued new authoritative guidance about management's responsibility to evaluate whether there is substantial doubt about an entity's ability to continue as a going concern and to provide related footnote disclosures. The standard is effective for us for our fourth quarter of fiscal 2017, although early adoption is permitted. The adoption of this standard is not expected to have a material impact on our condensed consolidated financial statements.

- removed (2015-11-24):
[0001327567-15-000018:note_history:27]
In May 2014, the FASB issued new authoritative guidance on revenue from contracts with customers. The new standard provides principles for recognizing revenue for the transfer of promised goods or services to customers with the consideration to which the entity expects to be entitled in exchange for those goods or services. The standard also requires significantly expanded disclosures about revenue recognition. The guidance is effective for us for our first quarter of fiscal 2018 using either of two methods: (i) retrospective to each prior reporting period presented with the option to elect certain practical expedients as defined within the guidance; or (ii) retrospective with the cumulative effect of initially applying the guidance recognized at the date of initial application and providing certain additional disclosures as defined per the guidance. Early adoption is not permitted. We are currently evaluating adoption methods and whether this standard will have a material impact on our condensed consolidated financial statements.

- removed (2015-11-24):
[0001327567-15-000018:note_history:28]
In July 2013, the FASB issued new authoritative guidance on the financial statement presentation of an unrecognized tax benefit when a net operating loss carryforward, a similar tax loss, or a tax credit carryforward exists. The standard requires us to present an unrecognized tax benefit as a reduction of a deferred tax asset for a net operating loss (NOL) carryforward or other tax credit carryforward when settlement in this manner is available under applicable tax law. The guidance was effective for us in the first quarter of fiscal 2015. Our adoption of this guidance did not have an impact on our condensed consolidated financial statements.


## us-gaap:ConvertibleDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2015-11-24):
[0001327567-15-000036:note_history:29]
The following table sets forth the components of the Notes as of October 31, 2015 and July 31, 2015 (in millions):
  (was, 2015-05-28, similarity 0.8986):
[0001327567-15-000018:note_history:29]
The following table sets forth the components of the Notes as of April 30, 2015 and July 31, 2014 (in thousands):

- changed (2015-11-24):
[0001327567-15-000036:note_history:30]
|  | October 31, 2015 |  | July 31, 2015 |
| Liability: |  |  |  |
| Principal | $ | 575.0 |  |  | $ | 575.0 |  |
| Less: debt discount, net of amortization | 82.7 |  |  | 87.9 |  |
| Net carrying amount | $ | 492.3 |  |  | $ | 487.1 |  |
| Equity (including temporary equity) | $ | (109.8 | ) |  | $ | (109.8 | ) |
  (was, 2015-05-28, similarity 0.8267):
[0001327567-15-000018:note_history:30]
|  | April 30, 2015 |  | July 31, 2014 |
| Liability: |  |  |  |
| Principal | $ | 575,000 |  |  | $ | 575,000 |  |
| Less: debt discount, net of amortization | 93,040 |  |  | 108,125 |  |
| Net carrying amount | $ | 481,960 |  |  | $ | 466,875 |  |


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2015-11-24):
[0001327567-15-000036:note_history:31]
On June 30, 2014, we issued $575.0 million aggregate principal amount of 0.0% Convertible Senior Notes due 2019 (the “Notes”). The Notes mature on July 1, 2019 unless converted or repurchased in accordance with their terms prior to such date. The Notes do not contain any financial covenants and we cannot redeem the Notes prior to maturity.

- changed (2015-11-24):
[0001327567-15-000036:note_history:32]
The Notes are convertible for up to 5.2 million shares of our common stock at an initial conversion price of approximately $110.28 per share of common stock, subject to adjustment. Holders of the Notes may surrender their Notes for conversion at their option at any time prior to the close of business on the business day immediately preceding January 1, 2019, only under the following circumstances:
  (was, 2015-05-28, similarity 0.8636):
[0001327567-15-000018:note_history:32]
The Notes are convertible for up to 5,214,000 shares of our common stock at an initial conversion rate of approximately 9.068 shares of common stock per $1,000 principal amount, which is equal to an initial conversion price of approximately $110.28 per share of common stock, subject to adjustment. Holders of the Notes may surrender their Notes for conversion at their option at any time prior to the close of business on the business day immediately preceding January 1, 2019, only under the following circumstances:

- changed (2015-11-24):
[0001327567-15-000036:note_history:33]
| • | if the last reported sale price of our common stock for at least 20 trading days (whether or not consecutive) during a period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the conversion price for the Notes on each applicable trading day (the “sale price condition”); |
  (was, 2015-05-28, similarity 0.8164):
[0001327567-15-000018:note_history:33]
| • | during any fiscal quarter commencing after the fiscal quarter ending on October 31, 2014 (and only during such fiscal quarter), if the last reported sale price of our common stock for at least 20 trading days (whether or not consecutive) during a period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the conversion price for the Notes on each applicable trading day; |

- changed (2015-11-24):
[0001327567-15-000036:note_history:34]
| • | during the five business day period after any five consecutive trading day period, in which the trading price per $1,000 principal amount of Notes for each trading day of the measurement period was less than 98% of the product of the last reported sale price of our common stock and the conversion rate for the Notes on each such trading day (the “trading price condition”); or |
  (was, 2015-05-28, similarity 0.9219):
[0001327567-15-000018:note_history:34]
| • | during the five business day period after any five consecutive trading day period (the “measurement period”), in which the trading price per $1,000 principal amount of Notes for each trading day of the measurement period was less than 98% of the product of the last reported sale price of our common stock and the conversion rate for the Notes on each such trading day; or |

- added (2015-11-24):
[0001327567-15-000036:note_history:35]
The sale price condition was initially met during the fiscal quarter ended April 30, 2015. The sale price condition continued to be met through the fiscal quarter ended October 31, 2015 and as a result, holders may convert their Notes at any time during the fiscal quarter ending January 31, 2016. Accordingly, the net carrying amount of the Notes was classified in current liabilities and a portion of the equity component representing the conversion option was classified as temporary equity in our condensed consolidated balance sheets as of October 31, 2015. The portion of the equity component classified as temporary equity is measured as the difference between the principal and net carrying amount of the Notes.

- changed (2015-11-24):
[0001327567-15-000036:note_history:36]
The following table sets forth the components of the Notes as of October 31, 2015 and July 31, 2015 (in millions):
  (was, 2015-05-28, similarity 0.8986):
[0001327567-15-000018:note_history:36]
The following table sets forth the components of the Notes as of April 30, 2015 and July 31, 2014 (in thousands):

- changed (2015-11-24):
[0001327567-15-000036:note_history:37]
|  | October 31, 2015 |  | July 31, 2015 |
| Liability: |  |  |  |
| Principal | $ | 575.0 |  |  | $ | 575.0 |  |
| Less: debt discount, net of amortization | 82.7 |  |  | 87.9 |  |
| Net carrying amount | $ | 492.3 |  |  | $ | 487.1 |  |
| Equity (including temporary equity) | $ | (109.8 | ) |  | $ | (109.8 | ) |
  (was, 2015-05-28, similarity 0.8267):
[0001327567-15-000018:note_history:37]
|  | April 30, 2015 |  | July 31, 2014 |
| Liability: |  |  |  |
| Principal | $ | 575,000 |  |  | $ | 575,000 |  |
| Less: debt discount, net of amortization | 93,040 |  |  | 108,125 |  |
| Net carrying amount | $ | 481,960 |  |  | $ | 466,875 |  |

- added (2015-11-24):
[0001327567-15-000036:note_history:38]
The total estimated fair value of the Notes was $896.3 million and $994.8 million at October 31, 2015 and July 31, 2015, respectively. The fair value was determined based on the closing trading price per $100 of the Notes as of the last day of trading for the period. We consider the fair value of the Notes at October 31, 2015 and July 31, 2015 to be a Level 2 measurement. The fair value of the Notes is primarily affected by the trading price of our common stock and market interest rates. As of October 31, 2015, the if-converted value of the Notes exceeded its principal amount by $308.0 million.

- changed (2015-11-24):
[0001327567-15-000036:note_history:39]
The following table sets forth interest expense recognized related to the Notes (dollars in millions):
  (was, 2015-05-28, similarity 0.7729):
[0001327567-15-000018:note_history:39]
The following table sets forth interest expense recognized related to the Notes for the three and nine months ended April 30, 2015 (dollars in thousands):

- changed (2015-11-24):
[0001327567-15-000036:note_history:40]
|  | Three Months Ended October 31, |
|  | 2015 |  | 2014 |
| Amortization of debt discount | $ | 5.2 |  |  | $ | 5.0 |  |
| Amortization of debt issuance costs | 0.5 |  |  | 0.5 |  |
| Total interest expense recognized | $ | 5.7 |  |  | $ | 5.5 |  |
| Effective interest rate of the liability component | 4.8 | % |  | 4.8 | % |
  (was, 2015-05-28, similarity 0.6946):
[0001327567-15-000018:note_history:40]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 30, 2015 |
| Amortization of debt issuance costs | $ | 522 |  |  | $ | 1,524 |  |
| Amortization of debt discount | 5,088 |  |  | 15,085 |  |
| Total interest expense recognized | $ | 5,610 |  |  | $ | 16,609 |  |
| Effective interest rate of the liability component | 4.8 | % |  | 4.8 | % |

- changed (2015-11-24):
[0001327567-15-000036:note_history:41]
To minimize the impact of potential economic dilution upon conversion of the Notes, we entered into convertible note hedge transactions (the “Note Hedges”) with respect to our common stock concurrent with the issuance of the Notes. The Note Hedges cover up to 5.2 million shares of our common stock and are exercisable upon conversion of the Notes. The Note Hedges will expire upon maturity of the Notes. The Note Hedges are separate transactions and are not part of the terms of the Notes. Holders of the Notes will not have any rights with respect to the Note Hedges. The shares receivable related to the Note Hedges are excluded from the calculation of diluted earnings per share as they are antidilutive.
  (was, 2015-05-28, similarity 0.9106):
[0001327567-15-000018:note_history:41]
To minimize the impact of potential economic dilution upon conversion of the Notes, we entered into convertible note hedge transactions (the “Note Hedges”) with respect to our common stock concurrent with the issuance of the Notes. The Note Hedges cover up to 5,214,000 shares of our common stock at a strike price per share that corresponds to the initial conversion price of the Notes, which are also subject to adjustment, and are exercisable upon conversion of the Notes. The Note Hedges will expire upon maturity of the Notes. The Note Hedges are separate transactions and are not part of the terms of the Notes. Holders of the Notes will not have any rights with respect to the Note Hedges. The shares receivable related to the Note Hedges are excluded from the calculation of diluted earnings per share as they are antidilutive.

- changed (2015-11-24):
[0001327567-15-000036:note_history:42]
Separately, but concurrently with our issuance of the Notes, we entered into warrant transactions (the “Warrants”) whereby we sold warrants to acquire up to 5.2 million shares of our common stock at a strike price of approximately $137.85 per share, subject to adjustments. The shares issuable under the Warrants will be included in the calculation of diluted earnings per share when the average market value per share of our common stock for the reporting period exceeds the strike price of the Warrants. The Warrants are separate transactions and are not part of the Notes or Notes Hedges, and are not remeasured through earnings each reporting period. Holders of the Notes and Note Hedges will not have any rights with respect to the Warrants.
  (was, 2015-05-28, similarity 0.9946):
[0001327567-15-000018:note_history:42]
Separately, but concurrently with our issuance of the Notes, we entered into warrant transactions (the “Warrants”) whereby we sold warrants to acquire up to 5,214,000 shares of our common stock at a strike price of approximately $137.85 per share, subject to adjustments. The shares issuable under the Warrants will be included in the calculation of diluted earnings per share when the average market value per share of our common stock for the reporting period exceeds the strike price of the Warrants. The Warrants are separate transactions and are not part of the Notes or Notes Hedges, and are not remeasured through earnings each reporting period. Holders of the Notes and Note Hedges will not have any rights with respect to the Warrants.

- added (2015-11-24):
[0001327567-15-000036:note_history:43]
For more information on the Notes, the Note Hedges, and the Warrants, refer to Note 7. Convertible Senior Notes of Notes to Consolidated Financial Statements included in Part II, Item 8 of our Annual Report on Form 10-K for the fiscal year ended July 31, 2015.

- removed (2015-11-24):
[0001327567-15-000018:note_history:44]
On June 30, 2014, we issued $575,000,000 aggregate principal amount of 0.0% Convertible Senior Notes due 2019 (the “Notes”). The Notes are governed by an indenture between us, as the issuer, and U.S. Bank National Association, as Trustee (the “Indenture”). The Notes are unsecured, unsubordinated obligations that do not contain any financial covenants or restrictions on the payments of dividends, the incurrence of indebtedness, or the issuance or repurchase of securities by us or any of our subsidiaries. The Notes mature on July 1, 2019 unless converted or repurchased in accordance with their terms prior to such date. We cannot redeem the Notes prior to maturity.

- removed (2015-11-24):
[0001327567-15-000018:note_history:45]
The conversion price will be subject to adjustment in some events. Holders of the Notes who convert their Notes in connection with certain corporate events that constitute a “make-whole fundamental change” per the Indenture are, under certain circumstances, entitled to an increase in the conversion rate. Additionally, upon the occurrence of a corporate event that constitutes a “fundamental change” per the Indenture, holders of the Notes may require us to repurchase for cash all or a portion of the Notes at a purchase price equal to 100% of the principal amount of the Notes plus accrued and unpaid contingent interest.

- removed (2015-11-24):
[0001327567-15-000018:note_history:46]
In accounting for the issuance of the Notes, we separated the Notes into liability and equity components. The carrying amount of the liability component was calculated by measuring the fair value of a similar liability that does not have an associated convertible feature. The carrying amount of the equity component representing the conversion option was determined by deducting the fair value of the liability component from the par value of the Notes as a whole. The difference between the principal amount of the Notes and the liability component (the “debt discount”), is amortized to interest expense using the effective interest method over the term of the Notes. The equity component of the Notes was recorded in additional paid-in capital in our condensed consolidated balance sheets and is not remeasured as long as it continues to meet the conditions for equity classification.

- removed (2015-11-24):
[0001327567-15-000018:note_history:47]
In accounting for the transaction costs related to the issuance of the Notes, we allocated the total amount incurred to the liability and equity components using the same proportions as the proceeds from the Notes. Transaction costs attributable to the liability component were recorded in other assets in our condensed consolidated balance sheets and are being amortized to interest expense in our condensed consolidated statements of operations using the effective interest method over the term of the Notes. Transaction costs attributable to the equity component were netted with the equity component of the Notes in additional paid-in capital in our condensed consolidated balance sheets. We recorded liability issuance costs, or debt issuance costs, of $12,497,000 and equity issuance costs of $2,949,000.

- removed (2015-11-24):
[0001327567-15-000018:note_history:48]
During the fiscal quarter ended April 30, 2015, the last reported sale price of our common stock was greater than or equal to 130% of the conversion price of the Notes for at least 20 of the last 30 consecutive trading days of such quarter. As a result, holders may convert their Notes at any time during the fiscal quarter ending July 31, 2015. Accordingly, as of April 30, 2015, we reclassified the net carrying amount of the Notes and related debt issuance costs to current liabilities and current assets, respectively, in our condensed consolidated balance sheets. We also reclassified a portion of the equity component representing the conversion option to temporary equity in our condensed consolidated balance sheets. The amount reclassified to temporary equity was measured as the difference between the principal and net carrying amount of the Notes as of April 30, 2015.

- removed (2015-11-24):
[0001327567-15-000018:note_history:49]
The total estimated fair value of the Notes was $836,987,000 and $587,087,000 at April 30, 2015 and July 31, 2014, respectively. The fair value was determined based on the closing trading price per $100 of the Notes as of the last day of trading for the period. We consider the fair value of the Notes at April 30, 2015 and July 31, 2014 to be a Level 2 measurement. The fair value of the Notes is primarily affected by the trading price of our common stock and market interest rates. As of April 30, 2015, the if-converted value of the Notes exceeded its principal amount by $188,879,000.

- removed (2015-11-24):
[0001327567-15-000018:note_history:50]
We paid an aggregate amount of $110,975,000 for the Note Hedges, which is included in additional paid-in capital in our condensed consolidated balance sheets.

- removed (2015-11-24):
[0001327567-15-000018:note_history:51]
We received aggregate proceeds of $78,258,000 from the sale of the Warrants, which is included in additional paid-in capital in our condensed consolidated balance sheets.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2015-11-24):
[0001327567-15-000036:note_history:52]
The following tables summarize the unrealized gains and losses and fair value of our available-for-sale investments as of October 31, 2015 and July 31, 2015 (in millions):
  (was, 2015-05-28, similarity 0.8675):
[0001327567-15-000018:note_history:52]
The following tables summarize the unrealized gains and losses and fair value of our investments as of April 30, 2015 and July 31, 2014 (in thousands):

- added (2015-11-24):
[0001327567-15-000036:note_history:53]
|  | October 31, 2015 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Estimated Fair Value |
| Certificates of deposit | $ | 1.0 |  |  | $ | — |  |  | $ | — |  |  | $ | 1.0 |  |
| Corporate debt securities | 292.1 |  |  | 0.1 |  |  | (0.3 | ) |  | 291.9 |  |
| U.S. government and agency securities | 902.1 |  |  | 0.2 |  |  | (0.4 | ) |  | 901.9 |  |
| Total | $ | 1,195.2 |  |  | $ | 0.3 |  |  | $ | (0.7 | ) |  | $ | 1,194.8 |  |

- changed (2015-11-24):
[0001327567-15-000036:note_history:54]
|  | July 31, 2015 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Estimated Fair Value |
| Certificates of deposit | $ | 1.0 |  |  | $ | — |  |  | $ | — |  |  | $ | 1.0 |  |
| Corporate debt securities | 190.9 |  |  | — |  |  | (0.2 | ) |  | 190.7 |  |
| U.S. government and agency securities | 760.2 |  |  | 0.3 |  |  | (0.2 | ) |  | 760.3 |  |
| Total | $ | 952.1 |  |  | $ | 0.3 |  |  | $ | (0.4 | ) |  | $ | 952.0 |  |
  (was, 2015-05-28, similarity 0.9973):
[0001327567-15-000018:note_history:54]
|  | July 31, 2014 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Estimated Fair Value |
| Certificates of deposit | $ | 1,000 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,000 |  |
| Corporate debt securities | 61,299 |  |  | 16 |  |  | (58 | ) |  | 61,257 |  |
| U.S. government and agency securities | 258,376 |  |  | 45 |  |  | (108 | ) |  | 258,313 |  |
| Total | $ | 320,675 |  |  | $ | 61 |  |  | $ | (166 | ) |  | $ | 320,570 |  |

- changed (2015-11-24):
[0001327567-15-000036:note_history:55]
Unrealized losses related to these investments are due to interest rate fluctuations as opposed to credit quality. In addition, we do not intend to sell and it is not likely that we would be required to sell these investments before recovery of their amortized cost basis, which may be at maturity. As a result, there were no other-than-temporary impairments for these investments at October 31, 2015 and July 31, 2015.
  (was, 2015-05-28, similarity 0.9599):
[0001327567-15-000018:note_history:55]
Unrealized losses related to these investments are due to interest rate fluctuations as opposed to credit quality. In addition, we do not intend to sell and it is not likely that we would be required to sell these investments before recovery of their amortized cost basis, which may be at maturity. As a result, there is no other-than-temporary impairment for these investments at April 30, 2015.

- changed (2015-11-24):
[0001327567-15-000036:note_history:56]
The following table summarizes the amortized cost and fair value of our available-for-sale investments as of October 31, 2015, by contractual years-to-maturity (in millions):
  (was, 2015-05-28, similarity 0.8734):
[0001327567-15-000018:note_history:56]
The following table summarizes the amortized cost and fair value of our investments as of April 30, 2015, by contractual years-to-maturity (in thousands):

- removed (2015-11-24):
[0001327567-15-000018:note_history:57]
|  | April 30, 2015 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Estimated Fair Value |
| Certificates of deposit | $ | 1,000 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,000 |  |
| Corporate debt securities | 161,005 |  |  | 53 |  |  | (48 | ) |  | 161,010 |  |
| U.S. government and agency securities | 615,087 |  |  | 322 |  |  | (104 | ) |  | 615,305 |  |
| Total | $ | 777,092 |  |  | $ | 375 |  |  | $ | (152 | ) |  | $ | 777,315 |  |

- removed (2015-11-24):
[0001327567-15-000018:note_history:58]
The following tables present our investments that were in an unrealized loss position as of April 30, 2015 and July 31, 2014 (in thousands):

- removed (2015-11-24):
[0001327567-15-000018:note_history:59]
|  | April 30, 2015 |
|  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
|  | Fair Value |  | Unrealized Loss |  | Fair Value |  | Unrealized Loss |  | Fair Value |  | Unrealized Loss |
| Corporate debt securities | $ | 77,534 |  |  | $ | (48 | ) |  | $ | — |  |  | $ | — |  |  | $ | 77,534 |  |  | $ | (48 | ) |
| U.S. government and agency securities | 181,639 |  |  | (104 | ) |  | — |  |  | — |  |  | 181,639 |  |  | (104 | ) |
| Total | $ | 259,173 |  |  | $ | (152 | ) |  | $ | — |  |  | $ | — |  |  | $ | 259,173 |  |  | $ | (152 | ) |

- removed (2015-11-24):
[0001327567-15-000018:note_history:60]
|  | July 31, 2014 |
|  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
|  | Fair Value |  | Unrealized Loss |  | Fair Value |  | Unrealized Loss |  | Fair Value |  | Unrealized Loss |
| Corporate debt securities | $ | 43,868 |  |  | $ | (58 | ) |  | $ | — |  |  | $ | — |  |  | $ | 43,868 |  |  | $ | (58 | ) |
| U.S. government and agency securities | 142,490 |  |  | (108 | ) |  | — |  |  | — |  |  | 142,490 |  |  | (108 | ) |
| Total | $ | 186,358 |  |  | $ | (166 | ) |  | $ | — |  |  | $ | — |  |  | $ | 186,358 |  |  | $ | (166 | ) |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_current_note, score: 0.0

- removed (2015-11-24):
[0001327567-15-000018:note_history:61]
Subsequent Event

- removed (2015-11-24):
[0001327567-15-000018:note_history:62]
In May 2015, we completed our acquisition of CirroSecure, Inc., a privately-held cybersecurity company, in exchange for total consideration of approximately $18,000,000. The acquisition expands the functionality of our enterprise security platform by providing additional security for SaaS applications. We are currently in the process of finalizing the accounting for this transaction and expect to complete our preliminary allocation of the purchase consideration to the assets acquired and liabilities assumed by the end of fiscal 2015.
