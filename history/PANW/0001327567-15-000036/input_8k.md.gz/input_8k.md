# PANW 8-K — 0001327567-15-000033 filed 2015-11-23

## item codes, every 8-K on or before 2015-11-24

- 2015-11-23 0001327567-15-000033 — 2.02, 9.01
- 2015-10-19 0001193125-15-347005 — 1.01, 9.01 — amendment, the index does not say of what
- 2015-09-09 0001327567-15-000022 — 2.02, 9.01
- 2015-08-19 0001193125-15-296115 — 1.01, 2.03
- 2015-06-01 0001193125-15-207786 — 1.01, 2.03
- 2015-05-27 0001327567-15-000015 — 2.02, 9.01
- 2015-03-02 0001327567-15-000006 — 2.02, 9.01
- 2014-12-15 0001327567-14-000046 — 5.07
- 2014-11-24 0001327567-14-000040 — 2.02, 9.01
- 2014-09-22 0001193125-14-348581 — 5.02, 9.01
- 2014-09-09 0001327567-14-000025 — 2.02, 9.01
- 2014-07-01 0001193125-14-257824 — 1.01, 2.03, 3.02, 9.01
- 2014-06-26 0001193125-14-249529 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2014-06-20 0001327567-14-000020 — 9.01 — amendment of 0001193125-14-140511
- 2014-06-04 0001327567-14-000016 — 3.02
- 2014-05-30 0001193125-14-218158 — 2.02 — amendment, the index does not say of what
- 2014-05-28 0001193125-14-215060 — 1.01, 2.02, 3.02, 9.01
- 2014-04-11 0001193125-14-140511 — 2.01, 3.02, 7.01, 9.01
- 2014-03-24 0001193125-14-111318 — 1.01, 3.02, 7.01, 9.01
- 2014-03-13 0001327567-14-000009 — 5.02
- 2014-02-24 0001193125-14-063754 — 2.02, 9.01
- 2013-12-12 0001327567-13-000040 — 5.07
- 2013-11-25 0001327567-13-000033 — 2.02, 9.01
- 2013-09-30 0001193125-13-384966 — 8.01
- 2013-09-09 0001193125-13-361421 — 2.02, 9.01
- 2013-05-30 0001193125-13-241542 — 2.02, 5.02, 9.01
- 2013-03-11 0001193125-13-101082 — 5.02, 9.01
- 2013-02-28 0001193125-13-084193 — 2.02, 9.01
- 2012-12-14 0001193125-12-503335 — 5.07
- 2012-12-06 0001193125-12-493700 — 2.02, 9.01
- 2012-09-24 0001193125-12-401534 — 1.01, 2.03
- 2012-09-20 0001193125-12-398433 — 5.02, 9.01
- 2012-09-10 0001193125-12-386605 — 2.02, 9.01

## late-filing notifications on or before 2015-11-24

- none on or before 2015-11-24

## item 2.02 — earnings release, exhibit 99.1

[0001327567-15-000033:8k_2_02:1]
EX-99.1
2
ex991q116earningsrelease.htm
EXHIBIT 99.1

[0001327567-15-000033:8k_2_02:2]
Exhibit

[0001327567-15-000033:8k_2_02:3]
Exhibit 99.1

[0001327567-15-000033:8k_2_02:4]
Palo Alto Networks Reports Fiscal First Quarter 2016 Financial Results

[0001327567-15-000033:8k_2_02:5]
| • | Fiscal first quarter total revenue grows 55 percent year-over-year to $297.2 million |

[0001327567-15-000033:8k_2_02:6]
| • | Fiscal first quarter billings grow 61 percent year-over-year to $388.0 million |

[0001327567-15-000033:8k_2_02:7]
| • | Fiscal first quarter cash flow from operations grows to $146.7 million and free cash flow grows to $127.2 million |

[0001327567-15-000033:8k_2_02:8]
SANTA CLARA, Calif., November 23, 2015 - Palo Alto Networks (NYSE: PANW), the next-generation security company, today announced financial results for its fiscal first quarter 2016 ended October 31, 2015.

[0001327567-15-000033:8k_2_02:9]
Total revenue for the fiscal first quarter 2016 grew 55 percent year-over-year to a record $297.2 million, compared with total revenue of $192.3 million for the fiscal first quarter 2015. GAAP net loss for the fiscal first quarter 2016 was $38.7 million, or $0.45 per diluted share, compared with GAAP net loss of $30.1 million, or $0.38 per diluted share, for the fiscal first quarter 2015.

[0001327567-15-000033:8k_2_02:10]
Non-GAAP net income for the fiscal first quarter 2016 was $31.6 million, or $0.35 per diluted share, compared with non-GAAP net income of $12.8 million, or $0.15 per diluted share, for the fiscal first quarter 2015. A reconciliation between GAAP and non-GAAP information is contained in the tables below.

[0001327567-15-000033:8k_2_02:11]
“We had a very strong start to fiscal year 2016 that included achieving our highest fiscal first quarter revenue and billings year-over-year growth rates since going public,” said Mark McLaughlin, president and chief executive officer of Palo Alto Networks. “We believe that our success is due to our unwavering commitment to solving our customers’ most complex security challenges with the industry’s most innovative technology. Security remains a strategic consideration for companies globally, and it is clear from our results that our natively integrated and automated next-generation platform is resonating very well as the long-term strategic answer for customers’ security needs.”

[0001327567-15-000033:8k_2_02:12]
Commenting on the company’s financial results, Steffan Tomlinson, chief financial officer of Palo Alto Networks, added, “We reported record revenue in the fiscal first quarter as robust new customer acquisition and expansion within our existing customer base drove strong demand for our appliances and subscription services. As the business scales, the power of our hybrid-SaaS model is becoming

[0001327567-15-000033:8k_2_02:13]
increasingly evident. Deferred revenue grew 71 percent-year-over-year to $804.5 million, and we improved non-GAAP operating leverage both sequentially and year-over-year. This resulted in cash flow from operations of $146.7 million and free cash flow of $127.2 million.”

[0001327567-15-000033:8k_2_02:14]
Recent Highlights

[0001327567-15-000033:8k_2_02:15]
| • | Published cybersecurity book for C-suite and boards of directors – The book, “Navigating the Digital Age: The Definitive Cybersecurity Guide for Directors and Officers,” was jointly published with the New York Stock Exchange (NYSE) and underscores Palo Alto Networks continued thought leadership by offering actionable, expert advice from lawyers, forensic professionals, consultants, academia, and government officials on a range of cybersecurity issues. All NYSE member company executives and boards of directors will receive a copy of the book. |

[0001327567-15-000033:8k_2_02:16]
| • | Introduced Aperture – This new security-as-a-service offering helps organizations safely enable and strengthen security for sanctioned SaaS applications, such as Box, Dropbox, Google Drive, and Salesforce. |

[0001327567-15-000033:8k_2_02:17]
| • | Announced commercial availability of our AutoFocus threat intelligence offering – This new cloud service, initially made available in April 2015 as a community access offering, is designed to provide users with the shared intelligence, analytics, and context required to understand which attacks require immediate response, as well as the ability to make threat indicators actionable and prevent future attacks. |

[0001327567-15-000033:8k_2_02:18]
| • | Signed significant global managed security services agreements – These strategic alliances with Telefonica and Trustwave®, the managed security services business unit of Singapore Telecommunications Limited, extend our presence in the large and growing managed security services market and are designed to bring next-generation managed security services to global, multi-national businesses and government agencies. |

[0001327567-15-000033:8k_2_02:19]
| • | Helped prove the power of information sharing – The collaborative Cyber Threat Alliance effort that included cyberthreat information sharing and combined intelligence has resulted in the revelation of a pervasive ransomware threat and specific measures to prevent it. As a founding member of the Cyber Threat Alliance, we believe this kind of collaboration across public and private industries is essential in the battle against cybercrime. |

[0001327567-15-000033:8k_2_02:20]
2

[0001327567-15-000033:8k_2_02:21]
Financial Outlook

[0001327567-15-000033:8k_2_02:22]
Palo Alto Networks provides guidance based on current market conditions and expectations.

[0001327567-15-000033:8k_2_02:23]
For the fiscal second quarter 2016, we expect:

[0001327567-15-000033:8k_2_02:24]
| • | Total revenue in the range of $314 to $318 million, representing year-over-year growth between 44 percent and 46 percent. |

[0001327567-15-000033:8k_2_02:25]
| • | Diluted non-GAAP earnings per share in the range of $0.38 to $0.39 using 91 to 92 million shares. |

[0001327567-15-000033:8k_2_02:26]
Guidance for non-GAAP financial measures excludes share-based compensation and related payroll taxes, acquisition related costs, amortization expense of acquired intangible assets, litigation related charges including legal settlements, non-cash interest expense related to our convertible senior notes, the foreign currency gains (losses) and tax effects associated with these items, and certain non-recurring expenses. We have not reconciled diluted non-GAAP earnings per share guidance to GAAP net income (loss) per diluted share because we do not provide guidance on GAAP net income (loss) or the various reconciling cash and non-cash items between GAAP net income (loss) and non-GAAP net income (loss). Items that impact these measures are out of our control and/or cannot be reasonably predicted. Accordingly, a reconciliation of the non-GAAP financial measure guidance to the corresponding GAAP measures is not available without unreasonable effort.

[0001327567-15-000033:8k_2_02:27]
Conference Call Information

[0001327567-15-000033:8k_2_02:28]
Palo Alto Networks will host a conference call for analysts and investors to discuss its fiscal first quarter 2016 results and outlook for its fiscal second quarter 2016 today at 4:30 PM Eastern time/1:30 PM Pacific time. Open to the public, investors may access the call by dialing 1-888-337-8168 or 1-719-325-2262 and using conference ID 7799714. A live audio webcast of the conference call along with supplemental financial information will also be accessible from the “Investors” section of our website at investors.paloaltonetworks.com. Following the webcast, an archived version will be available on our website for one year. A telephonic replay of the call will be available three hours after the call and will run for ten days and may be accessed by dialing 1-888-203-1112 or 1-719-457-0820 and entering the passcode 7799714.

[0001327567-15-000033:8k_2_02:29]
Forward-Looking Statements

[0001327567-15-000033:8k_2_02:30]
This press release contains forward-looking statements that involve risks and uncertainties, including statements regarding our financial outlook for the fiscal second quarter of 2016. There are a significant number of factors that could cause actual results to differ materially from statements made in this press

[0001327567-15-000033:8k_2_02:31]
release, including: our limited operating history; risks associated with managing our rapid growth, particularly outside of the United States; our limited experience with new product introductions and the risks associated with new products, including software bugs; the failure to timely develop and achieve market acceptance of new products as well as existing products and services; rapidly evolving technological developments in the market for network security products; and general market, political, economic and business conditions.

[0001327567-15-000033:8k_2_02:32]
Additional risks and uncertainties that could affect our financial results are included under the captions “Risk Factors” and “Management’s Discussion and Analysis of Financial Condition and Results of Operations” in our Annual Report on Form 10-K filed with the SEC on September 17, 2015, which is available on our website at investors.paloaltonetworks.com and on the SEC’s website at www.sec.gov. Additional information will also be set forth in other filings that we make with the SEC from time to time. All forward-looking statements in this press release are based on information available to us as of the date hereof, and we do not assume any obligation to update the forward-looking statements provided to reflect events that occur or circumstances that exist after the date on which they were made.

[0001327567-15-000033:8k_2_02:33]
Non-GAAP Financial Measures

[0001327567-15-000033:8k_2_02:34]
Palo Alto Networks has provided in this press release financial information that has not been prepared in accordance with generally accepted accounting principles in the United States (GAAP). The company uses these non-GAAP financial measures internally in analyzing its financial results and believes that the use of these non-GAAP financial measures is useful to investors as an additional tool to evaluate ongoing operating results and trends and in comparing the company’s financial results with other companies in its industry, many of which present similar non-GAAP financial measures.

[0001327567-15-000033:8k_2_02:35]
Non-GAAP financial measures are not meant to be considered in isolation or as a substitute for comparable GAAP financial measures, and should be read only in conjunction with the company’s consolidated financial statements prepared in accordance with GAAP. A reconciliation of the company’s historical non-GAAP financial measures to their most directly comparable GAAP measures has been provided in the financial statement tables included in this press release, and investors are encouraged to review the reconciliation.

[0001327567-15-000033:8k_2_02:36]
Non-GAAP net income and net income per share, diluted. Palo Alto Networks defines non-GAAP net income as net income (loss) plus share-based compensation related charges including share-based payroll tax expense, amortization expense of acquired intangible assets, litigation related charges including legal

[0001327567-15-000033:8k_2_02:37]
4

[0001327567-15-000033:8k_2_02:38]
settlements, non-cash interest expense related to the company’s convertible senior notes, and intellectual property restructuring related charges. The company also excludes from non-GAAP net income the foreign currency gains (losses) and tax effects associated with these items in order to provide a complete picture of the company’s recurring core business operating results. The company defines non-GAAP net income per share, diluted, as non-GAAP net income divided by the weighted average diluted shares outstanding after giving effect to the anti-dilutive impact of the company’s note hedge agreements, which reduces the potential economic dilution that otherwise would occur upon conversion of the company’s convertible senior notes. Under GAAP, the anti-dilutive impact of the note hedge is not reflected in diluted shares outstanding. Palo Alto Networks believes that excluding these items from non-GAAP net income and non-GAAP net income per share, diluted, provides management and investors with greater visibility into the underlying performance of the company’s core business operating results, meaning its operating performance excluding these items and, from time to time, other discrete charges that are infrequent in nature, over multiple periods.

[0001327567-15-000033:8k_2_02:39]
Billings. Palo Alto Networks defines billings as total revenue plus the change in deferred revenue during the period. The company’s management monitors billings because billings drive deferred revenue, which is an important indicator of the health and visibility of the company’s business. The company considers billings to be a useful metric for management and investors, particularly if sales of subscriptions continue to increase and the company experiences strong renewal rates for subscriptions and support and maintenance.

[0001327567-15-000033:8k_2_02:40]
Free cash flow. Palo Alto Networks defines free cash flow as cash provided by operating activities less purchases of property, equipment, and other assets. The company considers free cash flow to be a liquidity measure that provides useful information to management and investors about the amount of cash generated by the business that, after the purchases of property, equipment, and other assets, can be used for strategic opportunities, including investing in our business, making strategic acquisitions, and strengthening the balance sheet.

[0001327567-15-000033:8k_2_02:41]
Investors are cautioned that there are a number of limitations associated with the use of non-GAAP financial measures as an analytical tool. In particular, the billings metric reported by the company includes amounts that have not yet been recognized as revenue and the free cash flow measure does not represent the total increase or decrease in our cash balance for the period. In addition, many of the adjustments to the company’s GAAP financial measures reflect the exclusion of items that are recurring and will be reflected in the company’s financial results for the foreseeable future, such as share-based compensation,

[0001327567-15-000033:8k_2_02:42]
which is an important part of Palo Alto Networks employees’ compensation and impacts their performance. Furthermore, the components that Palo Alto Networks excludes in its calculation of non-GAAP financial measures may differ from the components that its peer companies exclude when they report their non-GAAP results of operations. Palo Alto Networks compensates for these limitations by providing specific information regarding the GAAP amounts excluded from these non-GAAP financial measures. In the future, the company may also exclude non-recurring expenses and other expenses that do not reflect the company’s core business operating results.

[0001327567-15-000033:8k_2_02:43]
About Palo Alto Networks

[0001327567-15-000033:8k_2_02:44]
Palo Alto Networks is the next-generation security company, leading a new era in cybersecurity by safely enabling applications and preventing cyber breaches for tens of thousands of organizations worldwide. Built with an innovative approach and highly differentiated cyberthreat prevention capabilities, our game-changing security platform delivers security far superior to legacy or point products, safely enables daily business operations, and protects an organization’s most valuable assets. Find out more at www.paloaltonetworks.com.

[0001327567-15-000033:8k_2_02:45]
Palo Alto Networks and the Palo Alto Networks Logo are trademarks of Palo Alto Networks, Inc. in the United States and in jurisdictions throughout the world. All other trademarks, trade names or service marks used or mentioned herein belong to their respective owners.

[0001327567-15-000033:8k_2_02:46]
Media Contact:

[0001327567-15-000033:8k_2_02:47]
Jennifer Jasper Smith

[0001327567-15-000033:8k_2_02:48]
Head of Corporate Communications

[0001327567-15-000033:8k_2_02:49]
Palo Alto Networks

[0001327567-15-000033:8k_2_02:50]
408-638-3280

[0001327567-15-000033:8k_2_02:51]
jjsmith@paloaltonetworks.com

[0001327567-15-000033:8k_2_02:52]
Investor Relations Contact:

[0001327567-15-000033:8k_2_02:53]
Kelsey Turcotte

[0001327567-15-000033:8k_2_02:54]
Vice President of Investor Relations

[0001327567-15-000033:8k_2_02:55]
408-753-3872

[0001327567-15-000033:8k_2_02:56]
kturcotte@paloaltonetworks.com

[0001327567-15-000033:8k_2_02:57]
Chris Danne/Maria Riley

[0001327567-15-000033:8k_2_02:58]
The Blueshirt Group

[0001327567-15-000033:8k_2_02:59]
415-217-7722

[0001327567-15-000033:8k_2_02:60]
ir@paloaltonetworks.com

[0001327567-15-000033:8k_2_02:61]
| Palo Alto Networks, Inc. |
| Preliminary Condensed Consolidated Statements of Operations |
| (In millions, except per share data) |
| (Unaudited) |
|  | Three Months Ended October 31, |
|  | 2015 |  | 2014 |
| Revenue: |  |  |  |
| Product | $ | 147.7 |  |  | $ | 101.5 |  |
| Services | 149.5 |  |  | 90.8 |  |
| Total revenue | 297.2 |  |  | 192.3 |  |
| Cost of revenue: |  |  |  |
| Product | 38.8 |  |  | 29.1 |  |
| Services | 40.4 |  |  | 24.3 |  |
| Total cost of revenue | 79.2 |  |  | 53.4 |  |
| Total gross profit | 218.0 |  |  | 138.9 |  |
| Operating expenses: |  |  |  |
| Research and development | 59.7 |  |  | 37.3 |  |
| Sales and marketing | 158.3 |  |  | 106.4 |  |
| General and administrative | 30.8 |  |  | 19.0 |  |
| Total operating expenses | 248.8 |  |  | 162.7 |  |
| Operating loss | (30.8 | ) |  | (23.8 | ) |
| Interest expense | (5.8 | ) |  | (5.5 | ) |
| Other income, net | 2.2 |  |  | 0.4 |  |
| Loss before income taxes | (34.4 | ) |  | (28.9 | ) |
| Provision for income taxes | 4.3 |  |  | 1.2 |  |
| Net loss | $ | (38.7 | ) |  | $ | (30.1 | ) |
| Net loss per share, basic and diluted | $ | (0.45 | ) |  | $ | (0.38 | ) |
| Weighted-average shares used to compute net loss per share, basic and diluted | 85.1 |  |  | 79.4 |  |

[0001327567-15-000033:8k_2_02:62]
8

[0001327567-15-000033:8k_2_02:63]
| Palo Alto Networks, Inc. |
| Reconciliation of GAAP to Non-GAAP Financial Measures |
| (In millions, except per share amounts) |
| (Unaudited) |
|  | Three Months Ended October 31, |
|  | 2015 |  | 2014 |
| GAAP net loss | $ | (38.7 | ) |  | $ | (30.1 | ) |
| Share-based compensation related charges | 75.2 |  |  | 39.5 |  |
| Amortization expense of acquired intangible assets | 2.1 |  |  | 1.5 |  |
| Litigation related charges | 3.1 |  |  | 3.1 |  |
| Non-cash interest expense related to convertible notes | 5.8 |  |  | 5.5 |  |
| Foreign currency gain associated with non-GAAP adjustments | (0.8 | ) |  | — |  |
| Income tax and other tax adjustments related to the above | (15.1 | ) |  | (6.7 | ) |
| Non-GAAP net income | $ | 31.6 |  |  | $ | 12.8 |  |
| GAAP net loss per share, diluted | $ | (0.45 | ) |  | $ | (0.38 | ) |
| Share-based compensation related charges | 0.86 |  |  | 0.48 |  |
| Amortization expense of acquired intangible assets | 0.02 |  |  | 0.02 |  |
| Litigation related charges | 0.04 |  |  | 0.04 |  |
| Non-cash interest expense related to convertible notes | 0.07 |  |  | 0.07 |  |
| Foreign currency gain associated with non-GAAP adjustments | (0.01 | ) |  | 0.00 |  |
| Income tax and other tax adjustments related to the above | (0.18 | ) |  | (0.08 | ) |
| Non-GAAP net income per share, diluted | $ | 0.35 |  |  | $ | 0.15 |  |
| GAAP weighted-average shares used to compute net loss per share, diluted | 85.1 |  |  | 79.4 |  |
| Weighted-average effect of potentially dilutive securities [a] | 5.6 |  |  | 5.3 |  |
| Non-GAAP weighted-average shares used to compute net income per share, diluted | 90.7 |  |  | 84.7 |  |
| Revenue | $ | 297.2 |  |  | $ | 192.3 |  |
| Change in deferred revenue | 90.8 |  |  | 48.2 |  |
| Billings | $ | 388.0 |  |  | $ | 240.5 |  |
| Net cash provided by operating activities | $ | 146.7 |  |  | $ | 74.9 |  |
| Less: purchases of property, equipment, and other assets | 19.5 |  |  | 5.9 |  |
| Free cash flow | $ | 127.2 |  |  | $ | 69.0 |  |
| Net cash used in investing activities | $ | (263.5 | ) |  | $ | (201.1 | ) |
| Net cash provided by financing activities | $ | 16.8 |  |  | $ | 16.1 |  |

[0001327567-15-000033:8k_2_02:64]
___________

[0001327567-15-000033:8k_2_02:65]
[a]    Non-GAAP net income per share, diluted, includes the potentially dilutive effect of employee equity incentive plan awards and convertible senior notes outstanding. In addition, non-GAAP net income per share, diluted, includes the anti-dilutive impact of the company’s note hedge agreements, which reduced the potentially dilutive effect of the convertible notes for the fiscal first quarter ended October 31, 2015 by 1.8 million shares. The potentially dilutive effect of the convertible notes for the fiscal first quarter ended October 31, 2014 was nil.

[0001327567-15-000033:8k_2_02:66]
9

[0001327567-15-000033:8k_2_02:67]
| Palo Alto Networks, Inc. |
| Preliminary Condensed Consolidated Balance Sheets |
| (In millions) |
| (Unaudited) |
|  | October 31, 2015 |  | July 31, 2015 |
| Assets |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 275.8 |  |  | $ | 375.8 |  |
| Short-term investments | 485.5 |  |  | 413.2 |  |
| Accounts receivable, net | 196.4 |  |  | 212.4 |  |
| Prepaid expenses and other current assets | 82.2 |  |  | 72.6 |  |
| Total current assets | 1,039.9 |  |  | 1,074.0 |  |
| Property and equipment, net | 76.7 |  |  | 62.9 |  |
| Long-term investments | 694.5 |  |  | 538.8 |  |
| Goodwill | 163.5 |  |  | 163.5 |  |
| Intangible assets, net | 51.0 |  |  | 52.7 |  |
| Other assets | 68.8 |  |  | 73.3 |  |
| Total assets | $ | 2,094.4 |  |  | $ | 1,965.2 |  |
| Liabilities, temporary equity, and stockholders’ equity |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 17.5 |  |  | $ | 13.2 |  |
| Accrued compensation | 52.8 |  |  | 79.8 |  |
| Accrued and other liabilities | 38.3 |  |  | 28.2 |  |
| Deferred revenue | 477.3 |  |  | 423.9 |  |
| Convertible senior notes, net | 492.3 |  |  | 487.1 |  |
| Total current liabilities | 1,078.2 |  |  | 1,032.2 |  |
| Long-term deferred revenue | 327.2 |  |  | 289.8 |  |
| Other long-term liabilities | 62.5 |  |  | 67.4 |  |
| Temporary equity | 82.7 |  |  | 87.9 |  |
| Stockholders’ equity: |  |  |  |
| Preferred stock | — |  |  | — |  |
| Common stock and additional paid-in capital | 1,083.6 |  |  | 988.7 |  |
| Accumulated other comprehensive loss | (0.4 | ) |  | (0.1 | ) |
| Accumulated deficit | (539.4 | ) |  | (500.7 | ) |
| Total stockholders’ equity | 543.8 |  |  | 487.9 |  |
| Total liabilities, temporary equity, and stockholders’ equity | $ | 2,094.4 |  |  | $ | 1,965.2 |  |

[0001327567-15-000033:8k_2_02:68]
10

[0001327567-15-000033:8k_2_02:69]
| Palo Alto Networks, Inc. |
| Preliminary Condensed Consolidated Statements of Cash Flows |
| (In millions) |
| (Unaudited) |
|  | Three Months Ended October 31, |
|  | 2015 |  | 2014 |
| Cash flows from operating activities |  |  |  |
| Net loss | $ | (38.7 | ) |  | $ | (30.1 | ) |
| Adjustments to reconcile net loss to net cash provided by operating activities: |  |  |  |
| Share-based compensation for equity based awards | 72.9 |  |  | 38.4 |  |
| Depreciation and amortization | 9.2 |  |  | 6.1 |  |
| Amortization of investment premiums, net of accretion of purchase discounts | 0.8 |  |  | 0.7 |  |
| Amortization of debt discount and debt issuance costs | 5.7 |  |  | 5.5 |  |
| Excess tax benefit from share-based compensation arrangements | (0.2 | ) |  | (0.3 | ) |
| Changes in operating assets and liabilities: |  |  |  |
| Accounts receivable, net | 16.0 |  |  | 19.3 |  |
| Prepaid expenses and other assets | 5.0 |  |  | 3.4 |  |
| Accounts payable | 5.2 |  |  | (4.5 | ) |
| Accrued compensation | (27.0 | ) |  | (12.8 | ) |
| Accrued and other liabilities | 7.0 |  |  | 1.0 |  |
| Deferred revenue | 90.8 |  |  | 48.2 |  |
| Net cash provided by operating activities | 146.7 |  |  | 74.9 |  |
| Cash flows from investing activities |  |  |  |
| Purchases of investments | (512.5 | ) |  | (247.9 | ) |
| Proceeds from sales of investments | 124.4 |  |  | 2.0 |  |
| Proceeds from maturities of investments | 144.1 |  |  | 50.7 |  |
| Purchases of property, equipment, and other assets | (19.5 | ) |  | (5.9 | ) |
| Net cash used in investing activities | (263.5 | ) |  | (201.1 | ) |
| Cash flows from financing activities |  |  |  |
| Proceeds from sales of shares through employee equity incentive plans | 16.6 |  |  | 15.8 |  |
| Excess tax benefit from share-based compensation arrangements | 0.2 |  |  | 0.3 |  |
| Net cash provided by financing activities | 16.8 |  |  | 16.1 |  |
| Net decrease in cash and cash equivalents | (100.0 | ) |  | (110.1 | ) |
| Cash and cash equivalents - beginning of period | 375.8 |  |  | 653.8 |  |
| Cash and cash equivalents - end of period | $ | 275.8 |  |  | $ | 543.7 |  |

[0001327567-15-000033:8k_2_02:70]
11
