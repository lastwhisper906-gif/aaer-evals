# PANW notes — 0001327567-15-000036


## us-gaap:AvailableForSaleSecuritiesTextBlock

[0001327567-15-000036:notes:1]
The following tables summarize the unrealized gains and losses and fair value of our available-for-sale investments as of October 31, 2015 and July 31, 2015 (in millions):

[0001327567-15-000036:notes:2]
|  | October 31, 2015 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Estimated Fair Value |
| Certificates of deposit | $ | 1.0 |  |  | $ | — |  |  | $ | — |  |  | $ | 1.0 |  |
| Corporate debt securities | 292.1 |  |  | 0.1 |  |  | (0.3 | ) |  | 291.9 |  |
| U.S. government and agency securities | 902.1 |  |  | 0.2 |  |  | (0.4 | ) |  | 901.9 |  |
| Total | $ | 1,195.2 |  |  | $ | 0.3 |  |  | $ | (0.7 | ) |  | $ | 1,194.8 |  |

[0001327567-15-000036:notes:3]
|  | July 31, 2015 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Estimated Fair Value |
| Certificates of deposit | $ | 1.0 |  |  | $ | — |  |  | $ | — |  |  | $ | 1.0 |  |
| Corporate debt securities | 190.9 |  |  | — |  |  | (0.2 | ) |  | 190.7 |  |
| U.S. government and agency securities | 760.2 |  |  | 0.3 |  |  | (0.2 | ) |  | 760.3 |  |
| Total | $ | 952.1 |  |  | $ | 0.3 |  |  | $ | (0.4 | ) |  | $ | 952.0 |  |


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001327567-15-000036:notes:4]
[same as prior period, unchanged from 0001327567-15-000018:notes:9]

[0001327567-15-000036:notes:5]
The accompanying condensed consolidated financial statements have been prepared in conformity with U.S. generally accepted accounting principles, consistent in all material respects with those applied in our Annual Report on Form 10-K for the fiscal year ended July 31, 2015, filed with the Securities and Exchange Commission on September 17, 2015. The condensed consolidated financial statements are unaudited, but include all adjustments of a normal recurring nature necessary for a fair presentation of our quarterly results. We have made estimates and judgments affecting the amounts reported in our condensed consolidated financial statements and the accompanying notes. The actual results that we experience may differ materially from our estimates. Certain prior period amounts have been reclassified to conform to current period presentation.

[0001327567-15-000036:notes:6]
The condensed consolidated financial statements should be read in conjunction with the consolidated financial statements and related notes in our Annual Report on Form 10-K for the fiscal year ended July 31, 2015.


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock

[0001327567-15-000036:notes:7]
[same as prior period, unchanged from 0001327567-15-000018:notes:11]

[0001327567-15-000036:notes:8]
[same as prior period, unchanged from 0001327567-15-000018:notes:12]

[0001327567-15-000036:notes:9]
Palo Alto Networks, Inc. (the “Company,” “we,” “us,” or “our”), located in Santa Clara, California, was incorporated in March 2005 under the laws of the State of Delaware and commenced operations in April 2005. We offer a next-generation security platform that empowers enterprises, service providers, and government entities to secure their organizations by safely enabling the increasingly complex and rapidly growing number of applications running on their networks and by preventing breaches in real-time that stem from targeted cyber attacks.

[0001327567-15-000036:notes:10]
[same as prior period, unchanged from 0001327567-15-000018:notes:14]

[0001327567-15-000036:notes:11]
[same as prior period, unchanged from 0001327567-15-000018:notes:15]

[0001327567-15-000036:notes:12]
[same as prior period, unchanged from 0001327567-15-000018:notes:16]

[0001327567-15-000036:notes:13]
There have been no material changes to our significant accounting policies as of and for the three months ended October 31, 2015, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended July 31, 2015.

[0001327567-15-000036:notes:14]
[same as prior period, unchanged from 0001327567-15-000018:notes:18]

[0001327567-15-000036:notes:15]
In April 2015, the Financial Accounting Standards Board (FASB) issued new authoritative guidance on fees paid in a cloud computing arrangement. The standard requires customers in a cloud computing arrangement to evaluate whether the arrangement includes a software license. If the arrangement includes a software license, the customer should account for the software license element of the arrangement consistent with the acquisition of other software licenses. If the arrangement does not include a software license, the customer should account for the arrangement as a service contract. The standard is effective for us for our first quarter of fiscal 2017 and will be applied on either a prospective or retrospective basis. We are currently evaluating adoption methods and whether this standard will have a material impact on our condensed consolidated financial statements.

[0001327567-15-000036:notes:16]
In April 2015, the FASB issued updated authoritative guidance to simplify the presentation of debt issuance costs. The amended standard requires that debt issuance costs related to a recognized debt liability be presented in the balance sheet as a direct deduction from the carrying amount of the related debt liability, consistent with the presentation of debt discounts, instead of being presented as an asset. The amended standard is effective for us for our first quarter of fiscal 2017 and will be applied on a retrospective basis. We do not expect the adoption of the standard will have a material impact on our condensed consolidated financial statements.

[0001327567-15-000036:notes:17]
In May 2014, the FASB issued new authoritative guidance on revenue from contracts with customers. The new standard provides principles for recognizing revenue for the transfer of promised goods or services to customers with the consideration to which the entity expects to be entitled in exchange for those goods or services. The standard also requires significantly expanded disclosures about revenue recognition. The FASB subsequently delayed the effective date of the standard by one year and as a result, the standard is now effective for us for our first quarter of fiscal 2019 using either of two methods: (i) retrospective to each prior reporting period presented with the option to elect certain practical expedients as defined within the guidance; or (ii) retrospective with the cumulative effect of initially applying the guidance recognized at the date of initial application and providing certain additional disclosures as defined per the guidance. Early adoption as of the original effective date is permitted. We are currently evaluating adoption methods and whether this standard will have a material impact on our condensed consolidated financial statements.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001327567-15-000036:notes:18]
Commitments and Contingencies

[0001327567-15-000036:notes:19]
Leases

[0001327567-15-000036:notes:20]
We lease our facilities under various non-cancelable operating leases, which expire through the year ending July 31, 2028.

[0001327567-15-000036:notes:21]
In May 2015, we entered into three lease agreements for approximately 752,000 square feet of corporate office space in Santa Clara, California to serve as our future corporate headquarters. In October 2015, we entered into a fourth lease agreement for approximately 310,000 square feet of additional office space at the same location, which will commence in December 2017 and expire in April 2028. The site is currently under construction and as a result, the lease commencement date may change based on progress of the construction project. The lease contains a rent holiday period, scheduled rent increases, lease incentives, and renewal options which allow the lease term to be extended through April 2046. Rental payments under the fourth lease agreement are approximately $101.2 million over the initial lease term.

[0001327567-15-000036:notes:22]
The following table presents details of the aggregate future non-cancelable minimum rental payments under our operating leases as of October 31, 2015 (in millions):

[0001327567-15-000036:notes:23]
|  | Amount |
| Fiscal years ending July 31: |  |
| Remaining 2016 | $ | 16.9 |  |
| 2017 | 25.1 |  |
| 2018 | 28.2 |  |
| 2019 | 41.9 |  |
| 2020 | 45.9 |  |
| 2021 and thereafter | 350.5 |  |
| Committed gross lease payments | 508.5 |  |
| Less: proceeds from sublease rental | 7.4 |  |
| Net operating lease obligation | $ | 501.1 |  |

[0001327567-15-000036:notes:24]
Contract Manufacturer Commitments

[0001327567-15-000036:notes:25]
Our independent contract manufacturer procures components and assembles our products based on our forecasts. These forecasts are based on estimates of demand for our products primarily for the next 12 months, which are in turn based on historical trends and an analysis from our sales and product marketing organizations, adjusted for overall market conditions. In order to reduce manufacturing lead times and plan for adequate supply, we may issue forecasts and orders for components and products that are non-cancelable. As of October 31, 2015, our purchase commitments under such orders were $46.3 million, excluding obligations under contracts that we can cancel without a significant penalty.

[0001327567-15-000036:notes:26]
Litigation

[0001327567-15-000036:notes:27]
We are subject to legal proceedings, claims, and litigation arising in the ordinary course of business, including intellectual property litigation. Such matters are subject to many uncertainties and outcomes are not predictable with assurance. We accrue for contingencies when we believe that a loss is probable and that we can reasonably estimate the amount of any such loss.

[0001327567-15-000036:notes:28]
To the extent there is a reasonable possibility that a loss exceeding amounts already recognized may be incurred and the amount of such additional loss would be material, we will either disclose the estimated additional loss or state that such an estimate cannot be made. As of October 31, 2015, we have not recorded any significant accruals for loss contingencies associated with such legal proceedings, determined that an unfavorable outcome is probable or reasonably possible, or determined that the amount or range of any possible loss is reasonably estimable.


## us-gaap:ConvertibleDebtTableTextBlock

[0001327567-15-000036:notes:29]
The following table sets forth the components of the Notes as of October 31, 2015 and July 31, 2015 (in millions):

[0001327567-15-000036:notes:30]
|  | October 31, 2015 |  | July 31, 2015 |
| Liability: |  |  |  |
| Principal | $ | 575.0 |  |  | $ | 575.0 |  |
| Less: debt discount, net of amortization | 82.7 |  |  | 87.9 |  |
| Net carrying amount | $ | 492.3 |  |  | $ | 487.1 |  |
| Equity (including temporary equity) | $ | (109.8 | ) |  | $ | (109.8 | ) |


## us-gaap:DebtDisclosureTextBlock

[0001327567-15-000036:notes:31]
Convertible Senior Notes

[0001327567-15-000036:notes:32]
On June 30, 2014, we issued $575.0 million aggregate principal amount of 0.0% Convertible Senior Notes due 2019 (the “Notes”). The Notes mature on July 1, 2019 unless converted or repurchased in accordance with their terms prior to such date. The Notes do not contain any financial covenants and we cannot redeem the Notes prior to maturity.

[0001327567-15-000036:notes:33]
The Notes are convertible for up to 5.2 million shares of our common stock at an initial conversion price of approximately $110.28 per share of common stock, subject to adjustment. Holders of the Notes may surrender their Notes for conversion at their option at any time prior to the close of business on the business day immediately preceding January 1, 2019, only under the following circumstances:

[0001327567-15-000036:notes:34]
| • | if the last reported sale price of our common stock for at least 20 trading days (whether or not consecutive) during a period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the conversion price for the Notes on each applicable trading day (the “sale price condition”); |

[0001327567-15-000036:notes:35]
| • | during the five business day period after any five consecutive trading day period, in which the trading price per $1,000 principal amount of Notes for each trading day of the measurement period was less than 98% of the product of the last reported sale price of our common stock and the conversion rate for the Notes on each such trading day (the “trading price condition”); or |

[0001327567-15-000036:notes:36]
| • | upon the occurrence of specified corporate events. |

[0001327567-15-000036:notes:37]
On or after January 1, 2019, holders may convert all or any portion of their Notes at any time prior to the close of business on the second scheduled trading day immediately preceding the maturity date regardless of the foregoing conditions. Upon conversion, holders will receive cash equal to the aggregate principal amount of the Notes to be converted, and, at our election, cash and/or shares of our common stock for any amounts in excess of the aggregate principal amount of the Notes being converted.

[0001327567-15-000036:notes:38]
The sale price condition was initially met during the fiscal quarter ended April 30, 2015. The sale price condition continued to be met through the fiscal quarter ended October 31, 2015 and as a result, holders may convert their Notes at any time during the fiscal quarter ending January 31, 2016. Accordingly, the net carrying amount of the Notes was classified in current liabilities and a portion of the equity component representing the conversion option was classified as temporary equity in our condensed consolidated balance sheets as of October 31, 2015. The portion of the equity component classified as temporary equity is measured as the difference between the principal and net carrying amount of the Notes.

[0001327567-15-000036:notes:39]
The total estimated fair value of the Notes was $896.3 million and $994.8 million at October 31, 2015 and July 31, 2015, respectively. The fair value was determined based on the closing trading price per $100 of the Notes as of the last day of trading for the period. We consider the fair value of the Notes at October 31, 2015 and July 31, 2015 to be a Level 2 measurement. The fair value of the Notes is primarily affected by the trading price of our common stock and market interest rates. As of October 31, 2015, the if-converted value of the Notes exceeded its principal amount by $308.0 million.

[0001327567-15-000036:notes:40]
The following table sets forth interest expense recognized related to the Notes (dollars in millions):

[0001327567-15-000036:notes:41]
|  | Three Months Ended October 31, |
|  | 2015 |  | 2014 |
| Amortization of debt discount | $ | 5.2 |  |  | $ | 5.0 |  |
| Amortization of debt issuance costs | 0.5 |  |  | 0.5 |  |
| Total interest expense recognized | $ | 5.7 |  |  | $ | 5.5 |  |
| Effective interest rate of the liability component | 4.8 | % |  | 4.8 | % |

[0001327567-15-000036:notes:42]
Note Hedges

[0001327567-15-000036:notes:43]
To minimize the impact of potential economic dilution upon conversion of the Notes, we entered into convertible note hedge transactions (the “Note Hedges”) with respect to our common stock concurrent with the issuance of the Notes. The Note Hedges cover up to 5.2 million shares of our common stock and are exercisable upon conversion of the Notes. The Note Hedges will expire upon maturity of the Notes. The Note Hedges are separate transactions and are not part of the terms of the Notes. Holders of the Notes will not have any rights with respect to the Note Hedges. The shares receivable related to the Note Hedges are excluded from the calculation of diluted earnings per share as they are antidilutive.

[0001327567-15-000036:notes:44]
Warrants

[0001327567-15-000036:notes:45]
Separately, but concurrently with our issuance of the Notes, we entered into warrant transactions (the “Warrants”) whereby we sold warrants to acquire up to 5.2 million shares of our common stock at a strike price of approximately $137.85 per share, subject to adjustments. The shares issuable under the Warrants will be included in the calculation of diluted earnings per share when the average market value per share of our common stock for the reporting period exceeds the strike price of the Warrants. The Warrants are separate transactions and are not part of the Notes or Notes Hedges, and are not remeasured through earnings each reporting period. Holders of the Notes and Note Hedges will not have any rights with respect to the Warrants.

[0001327567-15-000036:notes:46]
For more information on the Notes, the Note Hedges, and the Warrants, refer to Note 7. Convertible Senior Notes of Notes to Consolidated Financial Statements included in Part II, Item 8 of our Annual Report on Form 10-K for the fiscal year ended July 31, 2015.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001327567-15-000036:notes:47]
[same as prior period, unchanged from 0001327567-15-000018:notes:57]

[0001327567-15-000036:notes:48]
[same as prior period, unchanged from 0001327567-15-000018:notes:58]

[0001327567-15-000036:notes:49]
A summary of the activity under our stock plans during the reporting period and a summary of information related to options exercisable, vested, and expected to vest are presented below (in millions, except per share amounts):

[0001327567-15-000036:notes:50]
|  | Options Outstanding |
|  | Number of Shares |  | Weighted- Average Exercise Price Per Share |  | Weighted- Average Remaining Contractual Term (Years) |  | Aggregate Intrinsic Value |
| Balance—July 31, 2015 | 3.3 |  |  | $ | 13.74 |  |  | 6.2 |  | $ | 562.9 |  |
| Options granted | — |  |  | — |  |  |  |  |  |
| Options forfeited | — |  |  | — |  |  |  |  |  |
| Options exercised | (0.4 | ) |  | 11.46 |  |  |  |  |  |
| Balance—October 31, 2015 | 2.9 |  |  | $ | 14.06 |  |  | 5.9 |  | $ | 420.2 |  |
| Options vested and expected to vest—October 31 2015 | 2.9 |  |  | $ | 14.04 |  |  | 5.9 |  | $ | 419.6 |  |
| Options exercisable—October 31, 2015 | 2.5 |  |  | $ | 12.89 |  |  | 5.9 |  | $ | 364.2 |  |

[0001327567-15-000036:notes:51]
[same as prior period, unchanged from 0001327567-15-000018:notes:61]

[0001327567-15-000036:notes:52]
A summary of the activity under our stock plans during the reporting period and a summary of information related to RSUs vested and expected to vest are presented below (in millions, except per share amounts):

[0001327567-15-000036:notes:53]
|  | RSUs Outstanding |
|  | Number of Shares |  | Weighted- Average Grant-Date Fair Value Per Share |  | Weighted- Average Remaining Contractual Term (Years) |  | Aggregate Intrinsic Value |
| Balance—July 31, 2015 | 7.2 |  |  | $ | 95.66 |  |  | 1.2 |  | $ | 1,334.8 |  |
| RSUs granted | 0.4 |  |  | 171.01 |  |  |  |  |  |
| RSUs vested | (0.6 | ) |  | 66.60 |  |  |  |  |  |
| RSUs forfeited | (0.2 | ) |  | 82.45 |  |  |  |  |  |
| Balance—October 31, 2015 | 6.8 |  |  | $ | 103.05 |  |  | 1.1 |  | $ | 1,101.0 |  |
| RSUs vested and expected to vest—October 31, 2015 | 6.5 |  |  | $ | 102.49 |  |  | 1.1 |  | $ | 1,046.0 |  |

[0001327567-15-000036:notes:54]
[same as prior period, unchanged from 0001327567-15-000018:notes:64]

[0001327567-15-000036:notes:55]
The following table summarizes share-based compensation included in costs and expenses (in millions):

[0001327567-15-000036:notes:56]
|  | Three Months Ended October 31, |
|  | 2015 |  | 2014 |
| Cost of product revenue | $ | 1.3 |  |  | $ | 0.7 |  |
| Cost of services revenue | 7.0 |  |  | 3.5 |  |
| Research and development | 25.0 |  |  | 14.0 |  |
| Sales and marketing | 27.2 |  |  | 15.8 |  |
| General and administrative | 12.4 |  |  | 4.5 |  |
| Total | $ | 72.9 |  |  | $ | 38.5 |  |

[0001327567-15-000036:notes:57]
At October 31, 2015, total compensation cost related to unvested share-based awards not yet recognized was $570.9 million, net of estimated forfeitures. This cost is expected to be amortized on a straight-line basis over a weighted-average period of approximately three years.


## us-gaap:EarningsPerShareTextBlock

[0001327567-15-000036:notes:58]
[same as prior period, unchanged from 0001327567-15-000018:notes:68]

[0001327567-15-000036:notes:59]
[same as prior period, unchanged from 0001327567-15-000018:notes:69]

[0001327567-15-000036:notes:60]
The following table presents the computation of basic and diluted net loss per share of common stock (in millions, except per share data):

[0001327567-15-000036:notes:61]
|  | Three Months Ended |
|  | October 31, |
|  | 2015 |  | 2014 |
| Net loss | $ | (38.7 | ) |  | $ | (30.1 | ) |
| Weighted-average shares used to compute net loss per share, basic and diluted | 85.1 |  |  | 79.4 |  |
| Net loss per share, basic and diluted | $ | (0.45 | ) |  | $ | (0.38 | ) |

[0001327567-15-000036:notes:62]
The following securities were excluded from the computation of diluted net loss per share of common stock for the periods presented as their effect would have been antidilutive (in millions):

[0001327567-15-000036:notes:63]
|  | October 31, |
|  | 2015 |  | 2014 |
| Options to purchase common stock | 2.9 |  |  | 5.2 |  |
| RSUs | 6.8 |  |  | 6.2 |  |
| Convertible senior notes | 5.2 |  |  | 5.2 |  |
| Warrants related to the issuance of convertible senior notes | 5.2 |  |  | 5.2 |  |
| Total | 20.1 |  |  | 21.8 |  |


## us-gaap:FairValueAssetsAndLiabilitiesMeasuredOnRecurringAndNonrecurringBasisTableTextBlock

[0001327567-15-000036:notes:64]
The following table presents the fair value of our financial assets and liabilities using the above input categories as of October 31, 2015 and July 31, 2015 (in millions):

[0001327567-15-000036:notes:65]
|  |  | October 31, 2015 |  | July 31, 2015 |
|  |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Cash equivalents: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. government and agency securities |  | $ | — |  |  | $ | 14.8 |  |  | $ | — |  |  | $ | 14.8 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Total cash equivalents |  | — |  |  | 14.8 |  |  | — |  |  | 14.8 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Short-term investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Certificates of deposit |  | — |  |  | 1.0 |  |  | — |  |  | 1.0 |  |  | — |  |  | 1.0 |  |  | — |  |  | 1.0 |  |
| Corporate debt securities |  | — |  |  | 111.6 |  |  | — |  |  | 111.6 |  |  | — |  |  | 97.8 |  |  | — |  |  | 97.8 |  |
| U.S. government and agency securities |  | — |  |  | 372.9 |  |  | — |  |  | 372.9 |  |  | — |  |  | 314.4 |  |  | — |  |  | 314.4 |  |
| Total short-term investments |  | — |  |  | 485.5 |  |  | — |  |  | 485.5 |  |  | — |  |  | 413.2 |  |  | — |  |  | 413.2 |  |
| Long-term investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate debt securities |  | — |  |  | 180.3 |  |  | — |  |  | 180.3 |  |  | — |  |  | 92.9 |  |  | — |  |  | 92.9 |  |
| U.S. government and agency securities |  | — |  |  | 514.2 |  |  | — |  |  | 514.2 |  |  | — |  |  | 445.9 |  |  | — |  |  | 445.9 |  |
| Total long-term investments |  | — |  |  | 694.5 |  |  | — |  |  | 694.5 |  |  | — |  |  | 538.8 |  |  | — |  |  | 538.8 |  |
| Total assets measured at fair value |  | $ | — |  |  | $ | 1,194.8 |  |  | $ | — |  |  | $ | 1,194.8 |  |  | $ | — |  |  | $ | 952.0 |  |  | $ | — |  |  | $ | 952.0 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001327567-15-000036:notes:66]
[same as prior period, unchanged from 0001327567-15-000018:notes:76]

[0001327567-15-000036:notes:67]
[same as prior period, unchanged from 0001327567-15-000018:notes:77]

[0001327567-15-000036:notes:68]
[same as prior period, unchanged from 0001327567-15-000018:notes:78]

[0001327567-15-000036:notes:69]
[same as prior period, unchanged from 0001327567-15-000018:notes:79]

[0001327567-15-000036:notes:70]
[same as prior period, unchanged from 0001327567-15-000018:notes:80]

[0001327567-15-000036:notes:71]
Refer to Note 4. Convertible Senior Notes for the carrying amount and estimated fair value of our convertible senior notes as of October 31, 2015.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001327567-15-000036:notes:72]
[same as prior period, unchanged from 0001327567-15-000018:notes:82]

[0001327567-15-000036:notes:73]
Our provision for income taxes for the three months ended October 31, 2015 reflects an effective tax rate of negative 12.2%. Our effective tax rate for this period was negative as we recorded a provision for income taxes on year to date losses. The key components of our income tax provision primarily consist of foreign income taxes, withholding taxes, U.S. federal and state income taxes, and amortization of our deferred tax charges. Key components of our effective tax rate consist of foreign tax losses which derive no benefit, non-deductible share-based compensation, and changes in our valuation allowance. As compared to the same period last year, our effective tax rate changed primarily due to an increase in non-deductible share-based compensation, changes in our valuation allowance against deferred tax assets, and amortization of our deferred tax charges.

[0001327567-15-000036:notes:74]
Our provision for income taxes for the three months ended October 31, 2014 reflects an effective tax rate of negative 4.0%. Our effective tax rate for this period was negative as we recorded a provision for income taxes on year to date losses. The key components of our income tax provision consist of foreign income taxes, withholding taxes, and limited U.S. federal and state income tax due primarily to our net operating loss carryforward. Key components of our effective tax rate consist of foreign tax losses which derive no benefit, non-deductible share-based compensation, and changes in our valuation allowance.


## us-gaap:InvestmentsClassifiedByContractualMaturityDateTableTextBlock

[0001327567-15-000036:notes:75]
The following table summarizes the amortized cost and fair value of our available-for-sale investments as of October 31, 2015, by contractual years-to-maturity (in millions):

[0001327567-15-000036:notes:76]
|  | Amortized Cost |  | Fair Value |
| Due within one year | $ | 500.2 |  |  | $ | 500.3 |  |
| Due between one and three years | 695.0 |  |  | 694.5 |  |
| Total | $ | 1,195.2 |  |  | $ | 1,194.8 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001327567-15-000036:notes:77]
Investments

[0001327567-15-000036:notes:78]
Unrealized losses related to these investments are due to interest rate fluctuations as opposed to credit quality. In addition, we do not intend to sell and it is not likely that we would be required to sell these investments before recovery of their amortized cost basis, which may be at maturity. As a result, there were no other-than-temporary impairments for these investments at October 31, 2015 and July 31, 2015.
