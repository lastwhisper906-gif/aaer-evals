# PANW MD&A — 0001327567-15-000036


## mdna

[0001327567-15-000036:mdna:1]
[same as prior period, unchanged from 0001327567-15-000018:mdna:1]

[0001327567-15-000036:mdna:2]
- 13 -

[0001327567-15-000036:mdna:3]
[same as prior period, unchanged from 0001327567-15-000018:mdna:2]

[0001327567-15-000036:mdna:4]
[same as prior period, unchanged from 0001327567-15-000018:mdna:3]

[0001327567-15-000036:mdna:5]
[same as prior period, unchanged from 0001327567-15-000018:mdna:4]

[0001327567-15-000036:mdna:6]
| • | Results of Operations. A discussion of the nature and trends of the components of our financial results and an analysis of our financial results comparing the three months ended October 31, 2015 to the three months ended October 31, 2014. |

[0001327567-15-000036:mdna:7]
| • | Liquidity and Capital Resources. An analysis of changes in our balance sheets and cash flows, and a discussion of our financial condition and our ability to meet cash needs. |

[0001327567-15-000036:mdna:8]
| • | Contractual Obligations and Commitments. An overview of our contractual obligations, contingent liabilities, commitments, and off-balance sheet arrangements outstanding as of October 31, 2015, including expected payment schedule. |

[0001327567-15-000036:mdna:9]
[same as prior period, unchanged from 0001327567-15-000018:mdna:9]

[0001327567-15-000036:mdna:10]
[same as prior period, unchanged from 0001327567-15-000018:mdna:10]

[0001327567-15-000036:mdna:11]
[same as prior period, unchanged from 0001327567-15-000018:mdna:12]

[0001327567-15-000036:mdna:12]
We have pioneered the next-generation of security with our innovative platform that empowers enterprises, service providers, and government entities to secure their organizations by safely enabling the increasingly complex and rapidly growing number of applications running on their networks and by preventing breaches in real-time that stem from targeted cyber attacks. Our platform uses an innovative traffic classification engine that identifies network traffic by application, user, and content. As a result, it provides in-depth visibility into all traffic and all applications, at the user level, at all times, and at the full speed of the network in order to control usage, content, risks, and cyber threats. Our security platform consists of three major elements: our Next-Generation Firewall, our Advanced Endpoint Protection, and our Threat Intelligence Cloud. Our Next-Generation Firewall delivers application, user, and content visibility and control as well as protection against network-based cyber threats integrated within the firewall through our proprietary hardware and software architecture. Our Advanced Endpoint Protection prevents cyber attacks that aim to exploit software vulnerabilities on a broad variety of fixed and virtual endpoints and servers. Our Threat Intelligence Cloud provides central intelligence capabilities, security for software as a service (SaaS) applications, and automated delivery of preventative measures against cyber attacks.

[0001327567-15-000036:mdna:13]
The network-based element of our platform is delivered in the form of a physical or virtual appliance and includes a suite of subscription services. The cyber attack prevention capabilities of our platform are delivered in the form of subscription services that can be used either in the public cloud or in a private cloud using a dedicated appliance. Our subscription services can be easily activated on any of our appliances without requiring additional hardware or processing resources, thereby providing a seamless implementation path for our end-customers.

[0001327567-15-000036:mdna:14]
For the first quarter of fiscal 2016 and 2015, revenues were $297.2 million and $192.3 million, respectively, representing year over year growth of 54.5%. All three components of our hybrid SaaS revenue model experienced year over year growth, led by revenue from subscription services, which grew 68.5% to $73.6 million, followed by support and maintenance services, which grew 60.9% to $75.9 million, and product, which grew 45.5% to $147.7 million.

[0001327567-15-000036:mdna:15]
Our growth reflects the increased adoption of our hybrid SaaS revenue model, which consists of product, subscriptions, and support and maintenance. We believe this model will enable us to benefit from recurring revenues as we continue to grow our installed end-customer base. Our growth was also driven by increased security spending by customers, as security continues to be a critical business imperative for every business in the world. As of October 31, 2015, we had sold our products and services to more than 28,000 end-customers in over 140 countries. Our end-customers represent a broad range of industries including education,

[0001327567-15-000036:mdna:16]
- 14 -

[0001327567-15-000036:mdna:17]
energy, financial services, government entities, healthcare, Internet and media, manufacturing, public sector, and telecommunications, and include some of the largest Fortune 100 and Global 2000 companies in the world.

[0001327567-15-000036:mdna:18]
Product revenue is generated from sales of our appliances, primarily our Next-Generation Firewall, which is available in physical and virtualized form. Our Next-Generation Firewall incorporates our proprietary PAN-OS operating system, which provides a consistent set of capabilities across our entire product line. Our products are designed for different performance requirements throughout an organization, ranging from our PA-200, which is designed for enterprise remote offices, to our top-of-the-line PA-7080, which was released in August 2015 and is especially suited for service provider customers. The same firewall functionality that is delivered in our physical appliances is also available in our VM-Series virtual firewalls, which secure virtualized and cloud-based computing environments.

[0001327567-15-000036:mdna:19]
Services revenue is generated from sales of subscriptions and support and maintenance, which together provide us with a source of recurring services revenue. Our subscriptions include two new services released during the first quarter of fiscal 2016: our Aperture subscription service, which provides content control for IT-sanctioned SaaS applications that are used to store and share end-customer’s data, and our AutoFocus cyber threat intelligence service, which provides prioritized actionable intelligence on targeted cyber attacks. Our subscriptions provide our end-customers with real-time access to the latest antivirus, intrusion prevention, web filtering, and modern malware prevention capabilities across fixed and mobile devices.

[0001327567-15-000036:mdna:20]
We maintain a field sales force that works closely with our channel partners in developing sales opportunities. We use a two-tier, indirect fulfillment model whereby we sell our products and services to our global distributor channel partners, which, in turn, sell our products and services to our reseller network, which then sell to our end-customers. We leverage our appliances to sell SaaS subscription services to meet our customers’ evolving security requirements. When end-customers purchase an appliance, they typically purchase one or more of our subscriptions for additional functionality, as well as support and maintenance in order to receive ongoing security updates, upgrades, bug fixes, and repairs.

[0001327567-15-000036:mdna:21]
[same as prior period, unchanged from 0001327567-15-000018:mdna:22]

[0001327567-15-000036:mdna:22]
[same as prior period, unchanged from 0001327567-15-000018:mdna:23]

[0001327567-15-000036:mdna:23]
[same as prior period, unchanged from 0001327567-15-000018:mdna:25]

[0001327567-15-000036:mdna:24]
We monitor the key financial metrics set forth in the tables below to help us evaluate growth trends, establish budgets, measure the effectiveness of our sales and marketing efforts, and assess operational efficiencies. We discuss revenue, gross margin, and the components of operating loss and margin below under “—Results of Operations.”

[0001327567-15-000036:mdna:25]
|  | October 31, 2015 |  | July 31, 2015 |
|  | (in millions) |
| Total deferred revenue | $ | 804.5 |  |  | $ | 713.7 |  |
| Cash, cash equivalents, and investments | $ | 1,455.8 |  |  | $ | 1,327.8 |  |

[0001327567-15-000036:mdna:26]
- 15 -

[0001327567-15-000036:mdna:27]
|  | Three Months Ended October 31, |
|  | 2015 |  | 2014 |
|  | (dollars in millions) |
| Total revenue | $ | 297.2 |  |  | $ | 192.3 |  |
| Year over year percentage increase | 54.5 | % |  | 50.1 | % |
| Gross margin percentage | 73.3 | % |  | 72.2 | % |
| Operating loss | $ | (30.8 | ) |  | $ | (23.8 | ) |
| Operating margin percentage | (10.4 | )% |  | (12.4 | )% |
| Billings (non-GAAP) | $ | 388.0 |  |  | $ | 240.5 |  |
| Cash flow provided by operating activities | $ | 146.7 |  |  | $ | 74.9 |  |
| Free cash flow (non-GAAP) | $ | 127.2 |  |  | $ | 69.0 |  |

[0001327567-15-000036:mdna:28]
| • | Deferred Revenue. Our deferred revenue consists of amounts that have been invoiced, but have not been recognized as revenue as of the period end. The majority of our deferred revenue balance consists of subscription and support and maintenance revenue that is recognized ratably over the contractual service period. We monitor our deferred revenue balance because it represents a significant portion of revenue to be recognized in future periods. |

[0001327567-15-000036:mdna:29]
[same as prior period, unchanged from 0001327567-15-000018:mdna:30]

[0001327567-15-000036:mdna:30]
| • | Free Cash Flow (non-GAAP). We define free cash flow, a non-GAAP financial measure, as cash provided by operating activities less purchases of property, equipment, and other assets. We consider free cash flow to be a liquidity measure that provides useful information to management and investors about the amount of cash generated by the business that, after the purchases of property, equipment, and other productive assets, can be used for strategic opportunities, including investing in our business, making strategic acquisitions, and strengthening the balance sheet. A limitation of the utility of free cash flow as a measure of our financial performance and liquidity is that it does not represent the total increase or decrease in our cash balance for the period. In addition, it is important to note that other companies, including companies in our industry, may not use free cash flow, may calculate free cash flow in a different manner than we do, or may use other financial measures to evaluate their performance, all of which could reduce the usefulness of free cash flow as a comparative measure. A reconciliation of free cash flow to cash flow provided by operating activities, the most directly comparable financial measure calculated and presented in accordance with GAAP, is provided below: |

[0001327567-15-000036:mdna:31]
|  | Three Months Ended October 31, |
|  | 2015 |  | 2014 |
|  | (in millions) |
| Free cash flow (non-GAAP): |  |  |  |
| Cash flow provided by operating activities | $ | 146.7 |  |  | $ | 74.9 |  |
| Less: purchases of property, equipment, and other assets | 19.5 |  |  | 5.9 |  |
| Free cash flow (non-GAAP) | $ | 127.2 |  |  | $ | 69.0 |  |
| Net cash used in investing activities | $ | (263.5 | ) |  | $ | (201.1 | ) |
| Net cash provided by financing activities | $ | 16.8 |  |  | $ | 16.1 |  |

[0001327567-15-000036:mdna:32]
| • | Billings (non-GAAP). We define billings, a non-GAAP financial measure, as total revenue plus the change in deferred revenue during the period. Billings is a key measure used by our management to manage our business because billings drive deferred revenue, which is an important indicator of the health and visibility of our business. We consider billings to be a useful metric for management and investors, particularly if we continue to experience increased sales of subscriptions and strong renewal rates for subscriptions and support and maintenance services, and as we monitor our near term cash flows. We believe that billings provides useful information to investors and others in understanding and evaluating our operating results in the same manner as our management. However, it is important to note that other |

[0001327567-15-000036:mdna:33]
- 16 -

[0001327567-15-000036:mdna:34]
companies, including companies in our industry, may not use billings, may calculate billings differently, may have different billing frequencies, or may use other financial measures to evaluate their performance, all of which could reduce the usefulness of billings as a comparative measure. A reconciliation of billings to revenue, the most directly comparable financial measure calculated and presented in accordance with GAAP, is provided below:

[0001327567-15-000036:mdna:35]
|  | Three Months Ended October 31, |
|  | 2015 |  | 2014 |
|  | (in millions) |
| Billings (non-GAAP): |  |  |  |
| Total revenue | $ | 297.2 |  |  | $ | 192.3 |  |
| Add: change in total deferred revenue | 90.8 |  |  | 48.2 |  |
| Billings (non-GAAP) | $ | 388.0 |  |  | $ | 240.5 |  |

[0001327567-15-000036:mdna:36]
[same as prior period, unchanged from 0001327567-15-000018:mdna:63]

[0001327567-15-000036:mdna:37]
The following table summarizes our results of operations for the periods presented and as a percentage of our total revenue for those periods based on our condensed consolidated statements of operations data. The period to period comparison of results is not necessarily indicative of results for future periods.

[0001327567-15-000036:mdna:38]
|  | Three Months Ended October 31, |
|  | 2015 |  | 2014 |
|  | Amount |  | % of Revenue |  | Amount |  | % of Revenue |
|  | (dollars in millions) |
| Revenue: |  |  |  |  |  |  |  |
| Product | $ | 147.7 |  |  | 49.7 | % |  | $ | 101.5 |  |  | 52.8 | % |
| Services | 149.5 |  |  | 50.3 | % |  | 90.8 |  |  | 47.2 | % |
| Total revenue | 297.2 |  |  | 100.0 | % |  | 192.3 |  |  | 100.0 | % |
| Cost of revenue: |  |  |  |  |  |  |  |
| Product | 38.8 |  |  | 13.0 | % |  | 29.1 |  |  | 15.2 | % |
| Services | 40.4 |  |  | 13.7 | % |  | 24.3 |  |  | 12.6 | % |
| Total cost of revenue | 79.2 |  |  | 26.7 | % |  | 53.4 |  |  | 27.8 | % |
| Total gross profit | 218.0 |  |  | 73.3 | % |  | 138.9 |  |  | 72.2 | % |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 59.7 |  |  | 20.1 | % |  | 37.3 |  |  | 19.4 | % |
| Sales and marketing | 158.3 |  |  | 53.3 | % |  | 106.4 |  |  | 55.3 | % |
| General and administrative | 30.8 |  |  | 10.3 | % |  | 19.0 |  |  | 9.9 | % |
| Total operating expenses | 248.8 |  |  | 83.7 | % |  | 162.7 |  |  | 84.6 | % |
| Operating loss | (30.8 | ) |  | (10.4 | )% |  | (23.8 | ) |  | (12.4 | )% |
| Interest expense | (5.8 | ) |  | (1.9 | )% |  | (5.5 | ) |  | (2.9 | )% |
| Other income, net | 2.2 |  |  | 0.7 | % |  | 0.4 |  |  | 0.2 | % |
| Loss before income taxes | (34.4 | ) |  | (11.6 | )% |  | (28.9 | ) |  | (15.1 | )% |
| Provision for income taxes | 4.3 |  |  | 1.4 | % |  | 1.2 |  |  | 0.5 | % |
| Net loss | $ | (38.7 | ) |  | (13.0 | )% |  | $ | (30.1 | ) |  | (15.6 | )% |
| Number of employees at period end | 2,998 |  |  |  |  | 1,900 |  |  |  |

[0001327567-15-000036:mdna:39]
[same as prior period, unchanged from 0001327567-15-000018:mdna:14]

[0001327567-15-000036:mdna:40]
[same as prior period, unchanged from 0001327567-15-000018:mdna:37]

[0001327567-15-000036:mdna:41]
[same as prior period, unchanged from 0001327567-15-000018:mdna:38]

[0001327567-15-000036:mdna:42]
[same as prior period, unchanged from 0001327567-15-000018:mdna:39]

[0001327567-15-000036:mdna:43]
| • | Product Revenue. Product revenue is derived primarily from sales of our appliances. Product revenue also includes revenue derived from software licenses of Panorama, GlobalProtect, and the VM-Series. We recognize product revenue at the time of shipment, provided that all other revenue recognition criteria have been met. As a percentage of total revenue, we expect our product revenue to vary from quarter to quarter based on seasonal and cyclical factors. |

[0001327567-15-000036:mdna:44]
| • | Services Revenue. Services revenue is derived primarily from sales of our subscriptions and support and maintenance. Our contractual subscription and support and maintenance terms are typically one year, although we also offer three to five year terms. We recognize revenue from subscriptions and support and maintenance over the contractual service period. As a percentage of total revenue, we expect our services revenue to vary from quarter to quarter and increase over the long term as we introduce new subscriptions, renew existing services contracts, and expand our installed end-customer base. |

[0001327567-15-000036:mdna:45]
|  | Three Months Ended October 31, |  |  |  |  |
|  | 2015 |  | 2014 |  | Change |
|  | Amount |  | % of Revenue |  | Amount |  | % of Revenue |  | Amount |  | % |
|  | (dollars in millions) |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 147.7 |  |  | 49.7 | % |  | $ | 101.5 |  |  | 52.8 | % |  | $ | 46.2 |  |  | 45.5 | % |
| Services |  |  |  |  |  |  |  |  |  |  |  |
| Subscription | 73.6 |  |  | 24.8 | % |  | 43.7 |  |  | 22.7 | % |  | 29.9 |  |  | 68.5 | % |
| Support and maintenance | 75.9 |  |  | 25.5 | % |  | 47.1 |  |  | 24.5 | % |  | 28.8 |  |  | 60.9 | % |
| Total services | 149.5 |  |  | 50.3 | % |  | 90.8 |  |  | 47.2 | % |  | 58.7 |  |  | 64.6 | % |
| Total revenue | $ | 297.2 |  |  | 100.0 | % |  | $ | 192.3 |  |  | 100.0 | % |  | $ | 104.9 |  |  | 54.5 | % |
| Revenue by geographic theater: |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 211.3 |  |  | 71.1 | % |  | $ | 131.8 |  |  | 68.6 | % |  | $ | 79.5 |  |  | 60.3 | % |
| EMEA | 53.7 |  |  | 18.1 | % |  | 38.5 |  |  | 20.0 | % |  | 15.2 |  |  | 39.6 | % |
| APAC | 32.2 |  |  | 10.8 | % |  | 22.0 |  |  | 11.4 | % |  | 10.2 |  |  | 46.3 | % |
| Total revenue | $ | 297.2 |  |  | 100.0 | % |  | $ | 192.3 |  |  | 100.0 | % |  | $ | 104.9 |  |  | 54.5 | % |

[0001327567-15-000036:mdna:46]
Product revenue increased $46.2 million, or 45.5%, for the three months ended October 31, 2015 compared to the three months ended October 31, 2014, driven by increased demand for our higher end appliances. The impact of changes in pricing on our product revenue was insignificant.

[0001327567-15-000036:mdna:47]
Services revenue increased $58.7 million, or 64.6%, for the three months ended October 31, 2015 compared to the three months ended October 31, 2014, due to increased sales to new and existing end-customers. The mix between subscription revenue and support and maintenance revenue will fluctuate over time, depending on the introduction of new subscription offerings, renewals of support and maintenance services, and our ability to increase sales to new and existing customers. The impact of changes in pricing on our services revenue was insignificant.

[0001327567-15-000036:mdna:48]
With respect to geographic theaters, the Americas contributed the largest portion of the increase in revenue for the three months ended October 31, 2015 compared to the three months ended October 31, 2014, due to its larger and more established sales force compared to our other theaters. Revenue from both Europe, the Middle East, and Africa (EMEA) and Asia Pacific and Japan (APAC) increased for the three months ended October 31, 2015 compared to the three months ended October 31, 2014, due to our investment in increasing the size of our sales force and number of channel partners in these theaters.

[0001327567-15-000036:mdna:49]
[same as prior period, unchanged from 0001327567-15-000018:mdna:43]

[0001327567-15-000036:mdna:50]
Our cost of revenue consists of cost of product revenue and cost of services revenue.

[0001327567-15-000036:mdna:51]
| • | Cost of Product Revenue. Cost of product revenue primarily includes costs paid to our third-party contract manufacturer. Our cost of product revenue also includes amortization of intellectual property licenses, product testing |

[0001327567-15-000036:mdna:52]
[same as prior period, unchanged from 0001327567-15-000018:mdna:24]

[0001327567-15-000036:mdna:53]
costs, warranty costs, shipping costs, and personnel costs, which consist of salaries, benefits, bonuses, and share-based compensation associated with our operations organization. In addition, our cost of product revenue also includes allocated costs, which consist of certain facilities, depreciation, benefits, recruiting, and information technology costs that we allocate based on headcount. We expect our cost of product revenue to increase as our product revenue increases.

[0001327567-15-000036:mdna:54]
| • | Cost of Services Revenue. Cost of services revenue includes personnel costs for our global customer support and technical operations organizations, amortization of acquired intangible assets, allocated costs, and uniform resource locator (URL) filtering database service fees. We expect our cost of services revenue to increase as our installed end-customer base grows. |

[0001327567-15-000036:mdna:55]
|  | Three Months Ended October 31, |  |  |
|  | 2015 |  | 2014 |  | Change |
|  | Amount |  | % of Revenue |  | Amount |  | % of Revenue |  | Amount |  | % |
|  | (dollars in millions) |
| Cost of revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 38.8 |  |  | 13.0 | % |  | $ | 29.1 |  |  | 15.2 | % |  | $ | 9.7 |  |  | 33.0 | % |
| Services | 40.4 |  |  | 13.7 | % |  | 24.3 |  |  | 12.6 | % |  | 16.1 |  |  | 66.6 | % |
| Total cost of revenue | $ | 79.2 |  |  | 26.7 | % |  | $ | 53.4 |  |  | 27.8 | % |  | $ | 25.8 |  |  | 48.3 | % |
| Includes share-based compensation of: |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 1.3 |  |  |  |  | $ | 0.7 |  |  |  |  | $ | 0.6 |  |  | 71.8 | % |
| Services | 7.0 |  |  |  |  | 3.5 |  |  |  |  | 3.5 |  |  | 99.2 | % |
| Total share-based compensation included in cost of revenue | $ | 8.3 |  |  |  |  | $ | 4.2 |  |  |  |  | $ | 4.1 |  |  | 94.4 | % |

[0001327567-15-000036:mdna:56]
Cost of product revenue increased $9.7 million, or 33.0%, for the three months ended October 31, 2015 compared to the three months ended October 31, 2014, due to an increase in product unit volume.

[0001327567-15-000036:mdna:57]
Cost of services revenue increased $16.1 million, or 66.6%, for the three months ended October 31, 2015 compared to the three months ended October 31, 2014, due to increases in personnel costs of $8.6 million related to increasing our headcount, allocated costs of $2.6 million, and third party professional services costs of $1.4 million to expand our customer service capabilities to support our growing installed end-customer base.

[0001327567-15-000036:mdna:58]
[same as prior period, unchanged from 0001327567-15-000018:mdna:47]

[0001327567-15-000036:mdna:59]
Gross margin, or gross profit as a percentage of revenue, has been and will continue to be affected by a variety of factors, including the average sales price of our products, manufacturing costs, the mix of products sold, and the mix of revenue between products and services. For sales of our products, our higher end firewall products generally have higher gross margins than our lower end firewall products within each product series. For sales of our services, our subscriptions typically have higher gross margins than our support and maintenance. We expect our gross margins to fluctuate over time depending on the factors described above.

[0001327567-15-000036:mdna:60]
|  | Three Months Ended October 31, |  |  |
|  | 2015 |  | 2014 |  | Change |
|  | Amount |  | Gross Margin |  | Amount |  | Gross Margin |  | Amount |  | Percentage |
|  | (dollars in millions) |
| Gross profit: |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 108.9 |  |  | 73.8 | % |  | $ | 72.4 |  |  | 71.3 | % |  | $ | 36.5 |  |  | 2.5 | % |
| Services | 109.1 |  |  | 72.9 | % |  | 66.5 |  |  | 73.2 | % |  | 42.6 |  |  | (0.3 | )% |
| Total gross profit | $ | 218.0 |  |  | 73.3 | % |  | $ | 138.9 |  |  | 72.2 | % |  | $ | 79.1 |  |  | 1.1 | % |

[0001327567-15-000036:mdna:61]
Gross margin increased 110 basis points for the three months ended October 31, 2015 compared to the three months ended October 31, 2014, driven by the increase of 250 basis points in product margin, which was due to our continued focus on material cost reductions and increased demand for our higher end appliances.

[0001327567-15-000036:mdna:62]
[same as prior period, unchanged from 0001327567-15-000018:mdna:32]

[0001327567-15-000036:mdna:63]
[same as prior period, unchanged from 0001327567-15-000018:mdna:49]

[0001327567-15-000036:mdna:64]
Our operating expenses consist of research and development, sales and marketing, and general and administrative expense. Personnel costs are the most significant component of operating expenses and consist of salaries, benefits, bonuses, share-based compensation, and with regard to sales and marketing expense, sales commissions. Our operating expenses also include allocated costs, which consist of certain facilities, depreciation, benefits, recruiting, and information technology costs that we allocate based on headcount. We expect operating expenses to increase in absolute dollars and decrease over the long term as a percentage of revenue as we continue to scale our business. As of October 31, 2015, we expect to recognize approximately $570.9 million of share-based compensation expense over a weighted-average period of approximately three years, excluding additional share-based compensation expense related to any future grants of share-based awards. Share-based compensation expense, net of forfeitures, is recognized on a straight-line basis over the requisite service periods of the awards.

[0001327567-15-000036:mdna:65]
[same as prior period, unchanged from 0001327567-15-000018:mdna:51]

[0001327567-15-000036:mdna:66]
[same as prior period, unchanged from 0001327567-15-000018:mdna:52]

[0001327567-15-000036:mdna:67]
| • | General and Administrative. General and administrative expense consists of personnel costs for our executive, finance, human resources, legal, and information technology organizations, professional services, and certain non-recurring general expenses. Professional services consist primarily of legal, auditing, accounting, and other consulting costs. We expect general and administrative expense to increase in absolute dollars due to additional costs associated with accounting, compliance, insurance, and investor relations, although our general and administrative expense may fluctuate as a percentage of total revenue. |

[0001327567-15-000036:mdna:68]
|  | Three Months Ended October 31, |  |  |  |  |
|  | 2015 |  | 2014 |  | Change |
|  | Amount |  | % of Revenue |  | Amount |  | % of Revenue |  | Amount |  | % |
|  | (dollars in millions) |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | $ | 59.7 |  |  | 20.1 | % |  | $ | 37.3 |  |  | 19.4 | % |  | $ | 22.4 |  |  | 60.1 | % |
| Sales and marketing | 158.3 |  |  | 53.3 | % |  | 106.4 |  |  | 55.3 | % |  | 51.9 |  |  | 48.8 | % |
| General and administrative | 30.8 |  |  | 10.3 | % |  | 19.0 |  |  | 9.9 | % |  | 11.8 |  |  | 61.9 | % |
| Total operating expenses | $ | 248.8 |  |  | 83.7 | % |  | $ | 162.7 |  |  | 84.6 | % |  | $ | 86.1 |  |  | 52.9 | % |
| Includes share-based compensation of: |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | $ | 25.0 |  |  |  |  | $ | 14.0 |  |  |  |  | $ | 11.0 |  |  | 78.3 | % |
| Sales and marketing | 27.2 |  |  |  |  | 15.8 |  |  |  |  | 11.4 |  |  | 72.2 | % |
| General and administrative | 12.4 |  |  |  |  | 4.5 |  |  |  |  | 7.9 |  |  | 180.9 | % |
| Total share-based compensation included in operating expenses | $ | 64.6 |  |  |  |  | $ | 34.3 |  |  |  |  | $ | 30.3 |  |  | 88.8 | % |

[0001327567-15-000036:mdna:69]
Research and development expense increased $22.4 million, or 60.1%, for the three months ended October 31, 2015 compared to the three months ended October 31, 2014, due to an increase in personnel costs of $19.6 million, largely due to an increase in headcount, and an increase in allocated costs of $2.2 million.

[0001327567-15-000036:mdna:70]
Sales and marketing expense increased $51.9 million, or 48.8%, for the three months ended October 31, 2015 compared to the three months ended October 31, 2014, due to an increase in personnel costs of $34.0 million, largely due to an increase in headcount, an increase in allocated costs of $6.5 million, an increase in travel and entertainment costs of $4.2 million, and an increase in demand generation activities, trade shows, and other marketing activities of $1.6 million.

[0001327567-15-000036:mdna:71]
[same as prior period, unchanged from 0001327567-15-000018:mdna:42]

[0001327567-15-000036:mdna:72]
General and administrative expense increased $11.8 million, or 61.9%, for the three months ended October 31, 2015 compared to the three months ended October 31, 2014, due to an increase in personnel costs of $10.6 million, largely due to an increase in headcount.

[0001327567-15-000036:mdna:73]
Other Income, Net

[0001327567-15-000036:mdna:74]
Other income, net includes interest income earned on our cash, cash equivalents, and investments, foreign currency remeasurement gains and losses, and foreign currency transaction gains and losses.

[0001327567-15-000036:mdna:75]
|  | Three Months Ended October 31, |  |  |  |  |
|  | 2015 |  | 2014 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Other income, net | $ | 2.2 |  |  | $ | 0.4 |  |  | $ | 1.8 |  |  | 510.2 | % |

[0001327567-15-000036:mdna:76]
Other income, net increased $1.8 million for the three months ended October 31, 2015 compared to the three months ended October 31, 2014, due to an increase in interest income and higher foreign currency remeasurement gains.

[0001327567-15-000036:mdna:77]
[same as prior period, unchanged from 0001327567-15-000018:mdna:60]

[0001327567-15-000036:mdna:78]
Provision for income taxes consists primarily of income taxes in foreign jurisdictions in which we conduct business, withholding taxes, federal and state income taxes in the United States, and amortization of our deferred tax charges. We maintain a full valuation allowance for domestic deferred tax assets, including net operating loss carryforwards and tax credits.

[0001327567-15-000036:mdna:79]
|  | Three Months Ended October 31, |  |  |  |  |
|  | 2015 |  | 2014 |  | Change |
|  | (dollars in millions) |
| Provision for income taxes | $ | 4.3 |  |  | $ | 1.2 |  |  | $ | 3.1 |  |  | 264.0 | % |
| Effective tax rate | (12.2 | )% |  | (4.0 | )% |  |  |  |  |

[0001327567-15-000036:mdna:80]
We recorded an income tax provision for the three months ended October 31, 2015, due to federal, state, and foreign income taxes, withholding taxes, and amortization of our deferred tax charges. The provision for income taxes increased for the three months ended October 31, 2015 compared to the three months ended October 31, 2014, primarily due to an increase in non-deductible share-based compensation, changes in our valuation allowance against deferred tax assets, and amortization of our deferred tax charges.

[0001327567-15-000036:mdna:81]
[same as prior period, unchanged from 0001327567-15-000018:mdna:102]

[0001327567-15-000036:mdna:82]
|  | October 31, 2015 |  | July 31, 2015 |
|  | (in millions) |
| Working capital (1) | $ | (38.3 | ) |  | $ | 41.8 |  |
| Cash, cash equivalents, and investments: |  |  |  |
| Cash and cash equivalents | $ | 275.8 |  |  | $ | 375.8 |  |
| Investments | 1,180.0 |  |  | 952.0 |  |
| Total cash, cash equivalents, and investments | $ | 1,455.8 |  |  | $ | 1,327.8 |  |

[0001327567-15-000036:mdna:83]
[same as prior period, unchanged from 0001327567-15-000018:mdna:126]

[0001327567-15-000036:mdna:84]
| (1) | The net carrying amount of the Notes was classified in current liabilities in our condensed consolidated balance sheets as of October 31, 2015 and July 31, 2015. Refer to Note 4. Convertible Senior Notes of Notes to Condensed Consolidated Financial Statements included in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information. |

[0001327567-15-000036:mdna:85]
At October 31, 2015, our total cash, cash equivalents, and investments of $1.5 billion were held for general corporate purposes, of which approximately $93.8 million was held outside of the United States. We do not provide for federal income taxes on the undistributed earnings of our foreign subsidiaries, all of which we expect to reinvest outside of the United States

[0001327567-15-000036:mdna:86]
[same as prior period, unchanged from 0001327567-15-000018:mdna:55]

[0001327567-15-000036:mdna:87]
indefinitely. However, if these funds were needed for our domestic operations, we would be required to accrue and pay U.S. taxes on undistributed earnings of foreign subsidiaries. There are no other restrictions on the use of these funds. If we were to repatriate these earnings to the United States, any associated income tax liability would be insignificant.

[0001327567-15-000036:mdna:88]
In June 2014, we issued the Notes, which mature on July 1, 2019, with an aggregate principal amount of $575.0 million. Prior to January 1, 2019, holders may surrender their Notes for early conversion under certain circumstances. Upon conversion, we will pay cash equal to the aggregate principal amount of the Notes to be converted, and, at our election, will pay or deliver cash and/or shares of our common stock for the amount of our conversion obligation in excess of the aggregate principal amount of the Notes being converted. Refer to Note 4. Convertible Senior Notes of Notes to Condensed Consolidated Financial Statements included in Part I, Item 1 of this Quarterly Report on Form 10-Q for information on the Notes.

[0001327567-15-000036:mdna:89]
The following table summarizes our cash flows for the three months ended October 31, 2015 and 2014:

[0001327567-15-000036:mdna:90]
|  | Three Months Ended October 31, |
| 2015 |  | 2014 |
|  | (in millions) |
| Cash provided by operating activities | $ | 146.7 |  |  | $ | 74.9 |  |
| Cash used in investing activities | (263.5 | ) |  | (201.1 | ) |
| Cash provided by financing activities | 16.8 |  |  | 16.1 |  |
| Net decrease in cash and cash equivalents | $ | (100.0 | ) |  | $ | (110.1 | ) |

[0001327567-15-000036:mdna:91]
[same as prior period, unchanged from 0001327567-15-000018:mdna:110]

[0001327567-15-000036:mdna:92]
[same as prior period, unchanged from 0001327567-15-000018:mdna:111]

[0001327567-15-000036:mdna:93]
[same as prior period, unchanged from 0001327567-15-000018:mdna:112]

[0001327567-15-000036:mdna:94]
[same as prior period, unchanged from 0001327567-15-000018:mdna:113]

[0001327567-15-000036:mdna:95]
Cash provided by operating activities during the three months ended October 31, 2015 was $146.7 million, an increase of $71.8 million compared to the three months ended October 31, 2014. The increase was due to growth of our business and changes in our assets and liabilities during the three months ended October 31, 2015, which included an increase in sales of subscription and support and maintenance contracts to new and existing customers as reflected by an increase in deferred revenue.

[0001327567-15-000036:mdna:96]
[same as prior period, unchanged from 0001327567-15-000018:mdna:116]

[0001327567-15-000036:mdna:97]
[same as prior period, unchanged from 0001327567-15-000018:mdna:117]

[0001327567-15-000036:mdna:98]
Cash used in investing activities during the three months ended October 31, 2015 was $263.5 million, an increase of $62.4 million compared to the three months ended October 31, 2014, due to higher net purchases of available-for-sale investments and an increase in investment in infrastructure and facilities to support the growth of our business.

[0001327567-15-000036:mdna:99]
[same as prior period, unchanged from 0001327567-15-000018:mdna:119]

[0001327567-15-000036:mdna:100]
[same as prior period, unchanged from 0001327567-15-000018:mdna:120]

[0001327567-15-000036:mdna:101]
Cash provided by financing activities was flat for the three months ended October 31, 2015 compared to the three months ended October 31, 2014.

[0001327567-15-000036:mdna:102]
[same as prior period, unchanged from 0001327567-15-000018:mdna:66]

[0001327567-15-000036:mdna:103]
[same as prior period, unchanged from 0001327567-15-000018:mdna:123]

[0001327567-15-000036:mdna:104]
The following table summarizes our contractual obligations and commitments as of October 31, 2015:

[0001327567-15-000036:mdna:105]
|  | Payments Due by Period |
|  | Total |  | Less Than 1 Year |  | 1 - 3 Years |  | 3- 5 Years |  | More Than 5 Years |
|  |  |  | (in millions) |  |  |
| 0.0% Convertible Senior Notes due 2019 (1) | $ | 575.0 |  |  | $ | — |  |  | $ | — |  |  | $ | 575.0 |  |  | $ | — |  |
| Operating lease obligations (2) (3) | 508.5 |  |  | 23.3 |  |  | 57.5 |  |  | 90.6 |  |  | 337.1 |  |
| Purchase obligations (4) | 46.3 |  |  | 46.3 |  |  | — |  |  | — |  |  | — |  |
| Total (5) | $ | 1,129.8 |  |  | $ | 69.6 |  |  | $ | 57.5 |  |  | $ | 665.6 |  |  | $ | 337.1 |  |

[0001327567-15-000036:mdna:106]
______________

[0001327567-15-000036:mdna:107]
| (1) | As of October 31, 2015, holders may convert their Notes at any time during the fiscal quarter ending January 31, 2016. Refer to Note 4. Convertible Senior Notes of Notes to Condensed Consolidated Financial Statements included in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information. |

[0001327567-15-000036:mdna:108]
| (2) | Consists of contractual obligations from our non-cancelable operating leases, including the lease agreement executed in October 2015 for additional corporate office space in Santa Clara, California. Refer to Note 5. Commitments and Contingencies of Notes to Condensed Consolidated Financial Statements included in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information. |

[0001327567-15-000036:mdna:109]
| (3) | Excludes contractual sublease proceeds of $7.4 million, of which $3.0 million will be received in less than one year and $4.4 million will be received in one to three years. |

[0001327567-15-000036:mdna:110]
[same as prior period, unchanged from 0001327567-15-000018:mdna:130]

[0001327567-15-000036:mdna:111]
| (5) | No amounts related to income taxes are included. As of October 31, 2015, we had approximately $41.8 million of tax liabilities recorded related to uncertainty in income tax positions. |

[0001327567-15-000036:mdna:112]
[same as prior period, unchanged from 0001327567-15-000018:mdna:132]

[0001327567-15-000036:mdna:113]
As of October 31, 2015, we did not have any relationships with unconsolidated organizations or financial partnerships, such as structured finance or special purpose entities that would have been established for the purpose of facilitating off-balance sheet arrangements or other contractually narrow or limited purposes.

[0001327567-15-000036:mdna:114]
[same as prior period, unchanged from 0001327567-15-000018:mdna:134]

[0001327567-15-000036:mdna:115]
Our condensed consolidated financial statements have been prepared in accordance with U.S. GAAP. The preparation of these condensed consolidated financial statements requires us to make estimates and assumptions that affect the reported amounts of assets, liabilities, revenue, expenses, and related disclosures. We base our estimates on historical experience and on various other assumptions that we believe are reasonable under the circumstances. We evaluate our estimates and assumptions on an ongoing basis. Actual results may differ from these estimates. To the extent that there are material differences between these estimates and our actual results, our future financial statements will be affected.

[0001327567-15-000036:mdna:116]
We believe the critical accounting policies and estimates discussed under Item 7, “Management’s Discussion and Analysis of Financial Condition and Results of Operations” in our Annual Report on Form 10-K filed with the SEC on September 17, 2015, reflect our more significant judgments and estimates used in the preparation of the condensed consolidated financial statements. There have been no significant changes to our critical accounting policies and estimates as filed in such report.

[0001327567-15-000036:mdna:117]
[same as prior period, unchanged from 0001327567-15-000018:mdna:137]

[0001327567-15-000036:mdna:118]
[same as prior period, unchanged from 0001327567-15-000018:mdna:138]

[0001327567-15-000036:mdna:119]
[same as prior period, unchanged from 0001327567-15-000018:mdna:68]
