# PANW note change history — 0001327567-23-000032 → 0001327567-24-000005


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2024-02-21):
[0001327567-24-000005:note_history:1]
We have entered into various non-cancelable agreements with cloud service providers, under which we are committed to minimum or fixed purchases of certain cloud services. In addition, in order to reduce manufacturing lead times and plan for adequate supply, we have entered into agreements with manufacturing partners and component suppliers to procure inventory based on our demand forecasts. The following table presents details of the aggregate future non-cancelable purchase commitments under these agreements as of January 31, 2024 (in millions):
  (was, 2023-11-17, similarity 0.6769):
[0001327567-23-000032:note_history:1]
We have entered into various non-cancelable agreements with certain service providers, under which we are committed to minimum or fixed purchases. The following table presents details of the aggregate future non-cancelable purchase commitments under these agreements as of October 31, 2023 (in millions):

- changed (2024-02-21):
[0001327567-24-000005:note_history:2]
|  |  |  | Fiscal years ending July 31, |
|  | Total |  | Remaining 2024 |  | 2025 |  | 2026 |  | 2027 |  | 2028 |  | 2029 and Thereafter |
| Cloud | $ | 4,793.3 |  |  | $ | 0.6 |  |  | $ | 419.8 |  |  | $ | 868.4 |  |  | $ | 518.1 |  |  | $ | 585.6 |  |  | $ | 2,400.8 |  |
| Manufacturing | 218.9 |  |  | 109.3 |  |  | 69.6 |  |  | 40.0 |  |  | — |  |  | — |  |  | — |  |
| Other | 34.7 |  |  | 4.8 |  |  | 9.8 |  |  | 7.2 |  |  | 3.0 |  |  | 3.2 |  |  | 6.7 |  |
| Total purchase commitments | $ | 5,046.9 |  |  | $ | 114.7 |  |  | $ | 499.2 |  |  | $ | 915.6 |  |  | $ | 521.1 |  |  | $ | 588.8 |  |  | $ | 2,407.5 |  |
  (was, 2023-11-17, similarity 0.6607):
[0001327567-23-000032:note_history:2]
|  |  |  | Fiscal years ending July 31, |
|  | Total |  | Remaining 2024 |  | 2025 |  | 2026 |  | 2027 |  | 2028 |  | 2029 and Thereafter |
| Other purchase commitments | $ | 1,383.3 |  |  | $ | 11.3 |  |  | $ | 387.4 |  |  | $ | 499.4 |  |  | $ | 483.8 |  |  | $ | 0.6 |  |  | $ | 0.8 |  |

- changed (2024-02-21):
[0001327567-24-000005:note_history:3]
Additionally, we have a $149.9 million minimum purchase commitment with a cloud service provider through September 2027 with no specified annual commitments.
  (was, 2023-11-17, similarity 0.9796):
[0001327567-23-000032:note_history:3]
Additionally, we have a $153.3 million minimum purchase commitment with a service provider through September 2027 with no specified annual commitments.

- changed (2024-02-21):
[0001327567-24-000005:note_history:4]
We are subject to legal proceedings, claims, tax matters, and litigation arising in the ordinary course of business, including, for instance, intellectual property and patent litigation. We accrue for contingencies when we believe that a loss is probable and that we can reasonably estimate the amount of any such loss.
  (was, 2023-11-17, similarity 0.845):
[0001327567-23-000032:note_history:4]
We are subject to legal proceedings, claims, tax matters, and litigation arising in the ordinary course of business, including, for instance, intellectual property and patent litigation. We accrue for contingencies when we believe that a loss is probable and that we can reasonably estimate the amount of any such loss. As of October 31, 2023, we have not recorded any significant accruals for loss contingencies associated with such matters.

- changed (2024-02-21):
[0001327567-24-000005:note_history:5]
Legal matters could include speculative, substantial, or indeterminate monetary amounts. Significant judgment is required to determine both the likelihood of there being a loss and the estimated amount of a loss related to such matters, and we may be unable to estimate the reasonably possible loss or range of loss. The outcomes of outstanding legal matters are inherently unpredictable, and could, either individually or in aggregate, have a material adverse effect on us and our results of operations. To the extent there is a reasonable possibility that a loss exceeding any amounts already recognized may be incurred, we will either disclose the estimated additional loss or state that such an estimate cannot be made.
  (was, 2023-11-17, similarity 0.9993):
[0001327567-23-000032:note_history:5]
Legal matters could include speculative, substantial or indeterminate monetary amounts. Significant judgment is required to determine both the likelihood of there being a loss and the estimated amount of a loss related to such matters, and we may be unable to estimate the reasonably possible loss or range of loss. The outcomes of outstanding legal matters are inherently unpredictable, and could, either individually or in aggregate, have a material adverse effect on us and our results of operations. To the extent there is a reasonable possibility that a loss exceeding any amounts already recognized may be incurred, we will either disclose the estimated additional loss or state that such an estimate cannot be made.

- added (2024-02-21):
[0001327567-24-000005:note_history:6]
On March 12, 2021, Centripetal Networks, Inc., filed a lawsuit against us in the United States District Court for the Eastern District of Virginia. The lawsuit alleges that our products infringe multiple Centripetal patents. We successfully challenged certain of these patents, which were found unpatentable by the U.S. Patent and Trademark Office (“PTO”). The case went to jury trial on January 22, 2024, on four patents, with three stayed pending review in the PTO. On January 31, 2024, the jury returned a verdict of non-willful infringement with a lump sum amount of $151.5 million, plus statutory interest. We are advancing post-trial motions that aim to eliminate patents and patent claims from the scope of the final judgment and corresponding damages. The trial judge will decide these motions before entering final judgment, after which there will likely be an appeal by one or both parties to the action. We respectfully disagree with the verdict and believe that it is contrary to both the law and the extensive evidence presented at trial, which is why we are seeking relief from the court. In addition, Centripetal filed infringement contentions on certain of their patents in the European Patent Office in Germany, to which we filed invalidity challenges. Those matters are still pending.

- added (2024-02-21):
[0001327567-24-000005:note_history:7]
As of January 31, 2024, we accrued $176.8 million for the verdict amount and estimated interest. The accrual was recorded in other long-term liabilities on our condensed consolidated balance sheets with the corresponding charge included in general and administrative expense on our condensed consolidated statements of operations for the three and six months ended January 31, 2024.

- changed (2024-02-21):
[0001327567-24-000005:note_history:8]
On November 4, 2014, Finjan, Inc., filed a lawsuit against us in the United States District Court for the Northern District of California. The lawsuit alleges that our products infringe multiple Finjan patents. The complaint requests injunctive relief, monetary damages, and attorneys fees. The trial is set for October 21, 2024. We are unable, at this time, to reasonably estimate a possible loss or potential range of loss, if any.
  (was, 2023-11-17, similarity 0.9269):
[0001327567-23-000032:note_history:8]
On November 4, 2014, Finjan, Inc., filed a lawsuit against us in the United States District Court for the Northern District of California. The lawsuit alleges that our products infringe multiple Finjan patents. The complaint requests injunctive relief, monetary damages, and attorneys fees. The court has moved the trial date from April 8, 2024 to October 21, 2024. We are unable, at this time, to reasonably estimate a possible loss or potential range of loss, if any.

- added (2024-02-21):
[0001327567-24-000005:note_history:9]
On March 22, 2022, we filed a declaratory judgment action in the United States District Court for the Southern District of New York seeking a ruling that we are not infringing various Taasera patents. The parties have now resolved all pending matters between them as of December 2023. The amounts paid by us to resolve these matters were not material.

- added (2024-02-21):
[0001327567-24-000005:note_history:10]
Lionra Technologies v. Palo Alto Networks

- added (2024-02-21):
[0001327567-24-000005:note_history:11]
On August 29, 2022, Lionra Technologies filed a lawsuit against us in the United States District Court for the Eastern District of Texas. The lawsuit alleges that our products infringe multiple Lionra patents. The complaint requests injunctive relief, monetary damages and attorneys fees. The patents at issue are currently under review before the U.S. Patent and Trademark Office. Trial is set for May 20, 2024. We are unable, at this time, to reasonably estimate a possible loss or potential range of loss, if any.

- removed (2024-02-21):
[0001327567-23-000032:note_history:12]
Manufacturing Purchase Commitments

- removed (2024-02-21):
[0001327567-23-000032:note_history:13]
In order to reduce manufacturing lead times and plan for adequate supply, we enter into agreements with manufacturing partners and component suppliers to procure inventory based on our demand forecasts. The following table presents details of the aggregate future minimum or fixed purchase commitments under these arrangements, excluding obligations under contracts that we can cancel as of October 31, 2023 (in millions):

- removed (2024-02-21):
[0001327567-23-000032:note_history:14]
|  |  |  | Fiscal years ending July 31, |
|  | Total |  | Remaining 2024 |  | 2025 |  | 2026 |  | 2027 |  | 2028 |  | 2029 and Thereafter |
| Manufacturing purchase commitments | $ | 188.2 |  |  | $ | 113.2 |  |  | $ | 35.0 |  |  | $ | 40.0 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |

- removed (2024-02-21):
[0001327567-23-000032:note_history:15]
Other Purchase Commitments

- removed (2024-02-21):
[0001327567-23-000032:note_history:16]
On March 12, 2021, Centripetal Networks, Inc., filed a lawsuit against us in the United States District Court for the Eastern District of Virginia (“E.D.VA”). The lawsuit alleges that our products infringe multiple Centripetal patents. We successfully challenged certain of these patents, which were found unpatentable by the U.S. Patent and Trademark Office. The complaint requests injunctive relief, monetary damages, and attorneys fees. The US District Court E.D.VA has set a trial date of January 22, 2024 on the remaining patents. In addition, Centripetal filed infringement contentions on certain of their patents in the European Patent Office in Germany, to which we filed invalidity challenges. Those matters are still pending. We are unable, at this time, to reasonably estimate a possible loss or potential range of loss, if any.

- removed (2024-02-21):
[0001327567-23-000032:note_history:17]
On March 22, 2022, we filed a declaratory judgment action in the United States District Court for the Southern District of New York (“S.D.N.Y”) seeking a ruling that we are not infringing various Taasera patents. Taasera challenged jurisdiction in S.D.N.Y, which issue is currently on appeal with the Federal Circuit. Pursuant to an order of the Judicial Panel on Multidistrict Litigation, this matter has been consolidated in the United States District Court for the Eastern District of Texas with several other patent infringement matters brought by Taasera. The court moved the start date to April 15, 2024, as the start of consecutive trials of these consolidated matters. The complaint requests injunctive relief, monetary damages, and attorneys fees. We are unable, at this time, to reasonably estimate a possible loss or potential range of loss, if any.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2024-02-21):
[0001327567-24-000005:note_history:18]
Reclassification

- added (2024-02-21):
[0001327567-24-000005:note_history:19]
Certain prior period amounts in the condensed consolidated financial statements have been reclassified to conform to the current period presentation.

- changed (2024-02-21):
[0001327567-24-000005:note_history:20]
There have been no material changes to our significant accounting policies as of and for the six months ended January 31, 2024, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended July 31, 2023.
  (was, 2023-11-17, similarity 0.9004):
[0001327567-23-000032:note_history:20]
There have been no material changes to our significant accounting policies as of and for the three months ended October 31, 2023, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended July 31, 2023.

- added (2024-02-21):
[0001327567-24-000005:note_history:21]
Recently Issued Accounting Pronouncements

- added (2024-02-21):
[0001327567-24-000005:note_history:22]
Segment Reporting

- added (2024-02-21):
[0001327567-24-000005:note_history:23]
In November 2023, the Financial Accounting Standards Board (“FASB”) issued authoritative guidance that expands annual and interim disclosure requirements for reportable segments, primarily through enhanced disclosures about significant segment expenses. The standard is effective for our annual periods beginning in fiscal 2025 and interim periods beginning in the first quarter of fiscal 2026, and requires retrospective application for all prior periods presented in the financial statements. Early adoption is permitted. We are currently evaluating the impact of this standard on our disclosures in the consolidated financial statements.

- added (2024-02-21):
[0001327567-24-000005:note_history:24]
Income Tax Disclosures

- added (2024-02-21):
[0001327567-24-000005:note_history:25]
In December 2023, the FASB issued authoritative guidance that requires consistent categories and greater disaggregation of information in the effective tax rate reconciliation and additional disclosures of income taxes paid by jurisdiction. The standard is effective for our annual periods beginning in fiscal 2026 and could be applied either prospectively or retrospectively. Early adoption is permitted. We are currently evaluating the impact of this standard on our disclosures in the consolidated financial statements.


## us-gaap:ConvertibleDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-02-21):
[0001327567-24-000005:note_history:26]
|  |  |  | January 31, 2024 | July 31, 2023 |
| Principal |  |  | $ | 1,827.0 |  |  |  |  |  |  | $ | 1,999.3 |  |  |  |
| Less: debt issuance costs, net of amortization |  |  | (5.2) |  |  |  |  |  |  | (7.8) |  |  |  |
| Net carrying amount |  |  | $ | 1,821.8 |  |  |  |  |  |  | $ | 1,991.5 |  |  |  |
  (was, 2023-11-17, similarity 0.9697):
[0001327567-23-000032:note_history:26]
|  |  |  | October 31, 2023 | July 31, 2023 |
| Principal |  |  | $ | 1,953.3 |  |  |  |  |  |  | $ | 1,999.3 |  |  |  |
| Less: debt issuance costs, net of amortization |  |  | (6.6) |  |  |  |  |  |  | (7.8) |  |  |  |
| Net carrying amount |  |  | $ | 1,946.7 |  |  |  |  |  |  | $ | 1,991.5 |  |  |  |


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2024-02-21):
[0001327567-24-000005:note_history:27]
Holders of the 2025 Notes were able to early convert their 2025 Notes during the fiscal quarter ended January 31, 2024 as the sales price condition had been met during the fiscal quarter ended October 31, 2023. During the three and six months ended January 31, 2024, holders of the 2025 Notes converted $126.3 million and $172.3 million, respectively, in aggregate principal amount of the 2025 Notes, which we repaid in cash. We also issued 0.8 million and 1.1 million shares of our common stock to the holders of the 2025 Notes during the three and six months ended January 31, 2024, respectively, for the conversion value in excess of the principal amount. These shares were fully offset by shares we received from the corresponding exercise of the associated note hedges. Refer to Note 16. Subsequent Event for additional information regarding conversion of the 2025 Notes after January 31, 2024 through the filing date of this Quarterly Report on Form 10-Q.

- added (2024-02-21):
[0001327567-24-000005:note_history:28]
The sale price condition for the 2025 Notes was met during the fiscal quarter ended January 31, 2024 and as a result, holders may convert their 2025 Notes during the fiscal quarter ending April 30, 2024. The net carrying amount of the 2025 Notes was classified as a current liability on our condensed consolidated balance sheet as of January 31, 2024.

- changed (2024-02-21):
[0001327567-24-000005:note_history:29]
|  |  |  | January 31, 2024 | July 31, 2023 |
| Principal |  |  | $ | 1,827.0 |  |  |  |  |  |  | $ | 1,999.3 |  |  |  |
| Less: debt issuance costs, net of amortization |  |  | (5.2) |  |  |  |  |  |  | (7.8) |  |  |  |
| Net carrying amount |  |  | $ | 1,821.8 |  |  |  |  |  |  | $ | 1,991.5 |  |  |  |
  (was, 2023-11-17, similarity 0.9697):
[0001327567-23-000032:note_history:29]
|  |  |  | October 31, 2023 | July 31, 2023 |
| Principal |  |  | $ | 1,953.3 |  |  |  |  |  |  | $ | 1,999.3 |  |  |  |
| Less: debt issuance costs, net of amortization |  |  | (6.6) |  |  |  |  |  |  | (7.8) |  |  |  |
| Net carrying amount |  |  | $ | 1,946.7 |  |  |  |  |  |  | $ | 1,991.5 |  |  |  |

- added (2024-02-21):
[0001327567-24-000005:note_history:30]
The total estimated fair value of the 2025 Notes was $6.2 billion as of January 31, 2024 and $5.0 billion as of July 31, 2023. The fair value was determined based on the closing trading price per $100 of the 2025 Notes as of the last day of trading for the period. We consider the fair value of the 2025 Notes as of January 31, 2024 and July 31, 2023 to be a Level 2 measurement. The fair value of the 2025 Notes is primarily affected by the trading price of our common stock and market interest rates.

- changed (2024-02-21):
[0001327567-24-000005:note_history:31]
|  | Three Months Ended January 31, |  | Six Months Ended January 31, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
|  | 2023 Notes |  | 2025 Notes |  | Total |  | 2023 Notes |  | 2025 Notes |  | Total |  | 2023 Notes |  | 2025 Notes |  | Total |  | 2023 Notes |  | 2025 Notes |  | Total |
| Contractual interest expense | $ | — |  |  | $ | 1.7 |  |  | $ | 1.7 |  |  | $ | 3.2 |  |  | $ | 2.0 |  |  | $ | 5.2 |  |  | $ | — |  |  | $ | 3.6 |  |  | $ | 3.6 |  |  | $ | 6.4 |  |  | $ | 3.8 |  |  | $ | 10.2 |  |
| Amortization of debt issuance costs | — |  |  | 1.1 |  |  | 1.1 |  |  | 0.7 |  |  | 1.0 |  |  | 1.7 |  |  | — |  |  | 2.1 |  |  | 2.1 |  |  | 1.4 |  |  | 2.1 |  |  | 3.5 |  |
| Total interest expense | $ | — |  |  | $ | 2.8 |  |  | $ | 2.8 |  |  | $ | 3.9 |  |  | $ | 3.0 |  |  | $ | 6.9 |  |  | $ | — |  |  | $ | 5.7 |  |  | $ | 5.7 |  |  | $ | 7.8 |  |  | $ | 5.9 |  |  | $ | 13.7 |  |
| Effective interest rate | — | % |  | 0.6 | % |  |  |  | 0.9 | % |  | 0.6 | % |  |  |  | — | % |  | 0.6 | % |  |  |  | 0.9 | % |  | 0.6 | % |  |  |
  (was, 2023-11-17, similarity 0.6588):
[0001327567-23-000032:note_history:31]
|  |  |  | Three Months Ended October 31, |
|  |  |  |  |  | 2023 |  | 2022 |
|  |  |  |  |  |  |  |  |  |  |  |  |  | 2023 Notes |  | 2025 Notes |  | Total |  | 2023 Notes |  | 2025 Notes |  | Total |
| Contractual interest expense |  |  |  |  |  |  |  |  |  |  |  |  | $ | — |  |  | $ | 1.9 |  |  | $ | 1.9 |  |  | $ | 3.2 |  |  | $ | 1.8 |  |  | $ | 5.0 |  |
| Amortization of debt issuance costs |  |  |  |  |  |  |  |  |  |  |  |  | — |  |  | 1.0 |  |  | 1.0 |  |  | 0.7 |  |  | 1.1 |  |  | 1.8 |  |
| Total interest expense |  |  |  |  |  |  |  |  |  |  |  |  | $ | — |  |  | $ | 2.9 |  |  | $ | 2.9 |  |  | $ | 3.9 |  |  | $ | 2.9 |  |  | $ | 6.8 |  |
| Effective interest rate |  |  |  |  |  |  |  |  |  |  |  |  | — | % |  | 0.6 | % |  |  |  | 0.9 | % |  | 0.6 | % |  |  |

- changed (2024-02-21):
[0001327567-24-000005:note_history:32]
As a result of the conversions of the 2025 Notes settled during the three and six months ended January 31, 2024, we exercised the corresponding portion of our 2025 Note Hedges and received 0.8 million and 1.1 million shares of our common stock during the respective period.
  (was, 2023-11-17, similarity 0.8108):
[0001327567-23-000032:note_history:32]
As a result of the conversions of the 2025 Notes settled during the three months ended October 31, 2023, we exercised the corresponding portion of our 2025 Note Hedges and received 0.3 million shares of our common stock during the period.

- added (2024-02-21):
[0001327567-24-000005:note_history:33]
During the six months ended January 31, 2024, we net settled all of the 2023 Warrants with 9.0 million shares of our common stock with a fair value of $2.4 billion, of which 5.9 million shares of our common stock with a fair value of $1.7 billion were net settled during the three months ended January 31, 2024. The number of net shares issued was determined based on the number of 2023 Warrants exercised multiplied by the difference between the strike price of the 2023 Warrants and their daily volume-weighted-average stock price.

- changed (2024-02-21):
[0001327567-24-000005:note_history:34]
As of January 31, 2024, there were no amounts outstanding and we were in compliance with all covenants under the Credit Agreement.
  (was, 2023-11-17, similarity 0.9516):
[0001327567-23-000032:note_history:34]
As of October 31, 2023, there were no amounts outstanding and we were in compliance with all covenants under the Credit Agreement.

- removed (2024-02-21):
[0001327567-23-000032:note_history:35]
Holders of the 2025 Notes were able to early convert their 2025 Notes during the fiscal quarter ended October 31, 2023 as the sales price condition had been met during the fiscal quarter ended July 31, 2023. During the three months ended October 31, 2023, holders of the 2025 Notes converted $46.0 million in aggregate principal amount of the 2025 Notes, which we repaid in cash. We also issued 0.3 million shares of our common stock to the holders of the 2025 Notes for the conversion value in excess of the principal amount. These shares were fully offset by shares we received from the corresponding exercise of the associated note hedges.

- removed (2024-02-21):
[0001327567-23-000032:note_history:36]
The sale price condition for the 2025 Notes was met during the fiscal quarter ended October 31, 2023 and as a result, holders may convert their 2025 Notes during the fiscal quarter ending January 31, 2024. The net carrying amount of the 2025 Notes was classified as a current liability on our condensed consolidated balance sheet as of October 31, 2023.

- removed (2024-02-21):
[0001327567-23-000032:note_history:37]
The total estimated fair value of the 2025 Notes was $4.8 billion as of October 31, 2023 and $5.0 billion as of July 31, 2023, respectively. The fair value was determined based on the closing trading price per $100 of the 2025 Notes as of the last day of trading for the period. We consider the fair value of the 2025 Notes as of October 31, 2023 and July 31, 2023 to be a Level 2 measurement. The fair value of the 2025 Notes is primarily affected by the trading price of our common stock and market interest rates.

- removed (2024-02-21):
[0001327567-23-000032:note_history:38]
During the three months ended October 31, 2023, we net settled a portion of the 2023 Warrants with 3.1 million shares of our common stock with a fair value of $763.5 million. The number of net shares issued was determined based on the number of 2023 Warrants exercised multiplied by the difference between the strike price of the 2023 Warrants and their daily volume-weighted-average stock price. As of October 31, 2023, up to 12.1 million shares of our common stock were issuable for gross settlement under the remaining outstanding 2023 Warrants, which will be net settled when exercised through the end of December 2023.


## us-gaap:DebtSecuritiesAvailableForSaleTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-02-21):
[0001327567-24-000005:note_history:39]
The following tables summarize the amortized cost, unrealized gains and losses, and fair value of our available-for-sale debt securities as of January 31, 2024 and July 31, 2023 (in millions):
  (was, 2023-11-17, similarity 0.967):
[0001327567-23-000032:note_history:39]
The following tables summarize the amortized cost, unrealized gains and losses, and fair value of our available-for-sale debt securities as of October 31, 2023 and July 31, 2023 (in millions):

- changed (2024-02-21):
[0001327567-24-000005:note_history:40]
|  | January 31, 2024 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 11.0 |  |  | $ | — |  |  | $ | — |  |  | $ | 11.0 |  |
| Commercial paper | 252.1 |  |  | — |  |  | — |  |  | 252.1 |  |
| Corporate debt securities | 8.1 |  |  | — |  |  | — |  |  | 8.1 |  |
| U.S. government and agency securities | 10.0 |  |  | — |  |  | — |  |  | 10.0 |  |
| Total available-for-sale cash equivalents | $ | 281.2 |  |  | $ | — |  |  | $ | — |  |  | $ | 281.2 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 61.7 |  |  | $ | — |  |  | $ | — |  |  | $ | 61.7 |  |
| Commercial paper | 163.3 |  |  | 0.2 |  |  | — |  |  | 163.5 |  |
| Corporate debt securities | 3,937.2 |  |  | 22.5 |  |  | (10.2) |  |  | 3,949.5 |  |
| U.S. government and agency securities | 160.5 |  |  | 1.1 |  |  | (0.1) |  |  | 161.5 |  |
| Non-U.S. government and agency securities | 87.8 |  |  | 0.8 |  |  | (0.3) |  |  | 88.3 |  |
| Asset-backed securities | 778.5 |  |  | 5.8 |  |  | (0.7) |  |  | 783.6 |  |
| Total available-for-sale investments | $ | 5,189.0 |  |  | $ | 30.4 |  |  | $ | (11.3) |  |  | $ | 5,208.1 |  |
  (was, 2023-11-17, similarity 0.9136):
[0001327567-23-000032:note_history:40]
|  | October 31, 2023 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | $ | 297.0 |  |  | $ | — |  |  | $ | — |  |  | $ | 297.0 |  |
| Corporate debt securities | 8.6 |  |  | — |  |  | — |  |  | 8.6 |  |
| U.S. government and agency securities | 24.9 |  |  | — |  |  | — |  |  | 24.9 |  |
| Total available-for-sale cash equivalents | $ | 330.5 |  |  | $ | — |  |  | $ | — |  |  | $ | 330.5 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 34.0 |  |  | $ | — |  |  | $ | — |  |  | $ | 34.0 |  |
| Commercial paper | 136.9 |  |  | — |  |  | (0.1) |  |  | 136.8 |  |
| Corporate debt securities | 3,453.7 |  |  | 0.1 |  |  | (48.6) |  |  | 3,405.2 |  |
| U.S. government and agency securities | 219.9 |  |  | 0.1 |  |  | (0.8) |  |  | 219.2 |  |
| Non-U.S. government and agency securities | 62.4 |  |  | — |  |  | (0.8) |  |  | 61.6 |  |
| Asset-backed securities | 539.1 |  |  | 0.1 |  |  | (4.7) |  |  | 534.5 |  |
| Total available-for-sale investments | $ | 4,446.0 |  |  | $ | 0.3 |  |  | $ | (55.0) |  |  | $ | 4,391.3 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-02-21):
[0001327567-24-000005:note_history:41]
The following tables summarize the amortized cost, unrealized gains and losses, and fair value of our available-for-sale debt securities as of January 31, 2024 and July 31, 2023 (in millions):
  (was, 2023-11-17, similarity 0.967):
[0001327567-23-000032:note_history:41]
The following tables summarize the amortized cost, unrealized gains and losses, and fair value of our available-for-sale debt securities as of October 31, 2023 and July 31, 2023 (in millions):

- changed (2024-02-21):
[0001327567-24-000005:note_history:42]
|  | January 31, 2024 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 11.0 |  |  | $ | — |  |  | $ | — |  |  | $ | 11.0 |  |
| Commercial paper | 252.1 |  |  | — |  |  | — |  |  | 252.1 |  |
| Corporate debt securities | 8.1 |  |  | — |  |  | — |  |  | 8.1 |  |
| U.S. government and agency securities | 10.0 |  |  | — |  |  | — |  |  | 10.0 |  |
| Total available-for-sale cash equivalents | $ | 281.2 |  |  | $ | — |  |  | $ | — |  |  | $ | 281.2 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 61.7 |  |  | $ | — |  |  | $ | — |  |  | $ | 61.7 |  |
| Commercial paper | 163.3 |  |  | 0.2 |  |  | — |  |  | 163.5 |  |
| Corporate debt securities | 3,937.2 |  |  | 22.5 |  |  | (10.2) |  |  | 3,949.5 |  |
| U.S. government and agency securities | 160.5 |  |  | 1.1 |  |  | (0.1) |  |  | 161.5 |  |
| Non-U.S. government and agency securities | 87.8 |  |  | 0.8 |  |  | (0.3) |  |  | 88.3 |  |
| Asset-backed securities | 778.5 |  |  | 5.8 |  |  | (0.7) |  |  | 783.6 |  |
| Total available-for-sale investments | $ | 5,189.0 |  |  | $ | 30.4 |  |  | $ | (11.3) |  |  | $ | 5,208.1 |  |
  (was, 2023-11-17, similarity 0.9136):
[0001327567-23-000032:note_history:42]
|  | October 31, 2023 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | $ | 297.0 |  |  | $ | — |  |  | $ | — |  |  | $ | 297.0 |  |
| Corporate debt securities | 8.6 |  |  | — |  |  | — |  |  | 8.6 |  |
| U.S. government and agency securities | 24.9 |  |  | — |  |  | — |  |  | 24.9 |  |
| Total available-for-sale cash equivalents | $ | 330.5 |  |  | $ | — |  |  | $ | — |  |  | $ | 330.5 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 34.0 |  |  | $ | — |  |  | $ | — |  |  | $ | 34.0 |  |
| Commercial paper | 136.9 |  |  | — |  |  | (0.1) |  |  | 136.8 |  |
| Corporate debt securities | 3,453.7 |  |  | 0.1 |  |  | (48.6) |  |  | 3,405.2 |  |
| U.S. government and agency securities | 219.9 |  |  | 0.1 |  |  | (0.8) |  |  | 219.2 |  |
| Non-U.S. government and agency securities | 62.4 |  |  | — |  |  | (0.8) |  |  | 61.6 |  |
| Asset-backed securities | 539.1 |  |  | 0.1 |  |  | (4.7) |  |  | 534.5 |  |
| Total available-for-sale investments | $ | 4,446.0 |  |  | $ | 0.3 |  |  | $ | (55.0) |  |  | $ | 4,391.3 |  |

- added (2024-02-21):
[0001327567-24-000005:note_history:43]
As of January 31, 2024, the gross unrealized losses that have been in a continuous unrealized loss position for less than 12 months were $5.1 million, which were related to $1.5 billion of available-for-sale debt securities, and the gross unrealized losses that have been in a continuous unrealized loss position for more than 12 months were $6.2 million, which were related to $752.8 million of available-for-sale debt securities. As of July 31, 2023 the gross unrealized losses that have been in a continuous unrealized loss position for less than 12 months were $30.7 million, which were related to $3.4 billion of available-for-sale debt securities, and the gross unrealized losses that have been in a continuous unrealized loss position for more than 12 months were $7.3 million, which were related to $481.8 million of available-for-sale debt securities.

- changed (2024-02-21):
[0001327567-24-000005:note_history:44]
Unrealized losses related to our available-for-sale debt securities are primarily due to interest rate fluctuations as opposed to credit quality. We do not intend to sell any of the securities in an unrealized loss position and it is not likely that we would be required to sell these securities before recovery of their amortized cost basis, which may be at maturity. We did not recognize any credit losses related to our available-for-sale debt securities during the three and six months ended January 31, 2024 and 2023.
  (was, 2023-11-17, similarity 0.9784):
[0001327567-23-000032:note_history:44]
Unrealized losses related to our available-for-sale debt securities are primarily due to interest rate fluctuations as opposed to credit quality. We do not intend to sell any of the securities in an unrealized loss position and it is not likely that we would be required to sell these securities before recovery of their amortized cost basis, which may be at maturity. We did not recognize any credit losses related to our available-for-sale debt securities during the three months ended October 31, 2023 and 2022.

- changed (2024-02-21):
[0001327567-24-000005:note_history:45]
The following table summarizes the amortized cost and fair value of our available-for-sale debt securities as of January 31, 2024, by contractual years-to-maturity (in millions):
  (was, 2023-11-17, similarity 0.9651):
[0001327567-23-000032:note_history:45]
The following table summarizes the amortized cost and fair value of our available-for-sale debt securities as of October 31, 2023, by contractual years-to-maturity (in millions):

- changed (2024-02-21):
[0001327567-24-000005:note_history:46]
Marketable equity securities consist of money market funds and are included in cash and cash equivalents on our condensed consolidated balance sheets. As of January 31, 2024 and July 31, 2023, the carrying values of our marketable equity securities were $859.3 million and $476.1 million, respectively. There were no unrealized gains or losses recognized for these securities during the three and six months ended January 31, 2024 and 2023.
  (was, 2023-11-17, similarity 0.875):
[0001327567-23-000032:note_history:46]
Marketable equity securities consist of money market funds and are included in cash and cash equivalents on our condensed consolidated balance sheets. As of October 31, 2023 and July 31, 2023, the carrying values of our marketable equity securities were $1.6 billion and $476.1 million, respectively. There were no unrealized gains or losses recognized for these securities during the three months ended October 31, 2023 and 2022.

- removed (2024-02-21):
[0001327567-23-000032:note_history:47]
As of October 31, 2023, the gross unrealized losses that have been in a continuous unrealized loss position for less than 12 months were $40.4 million, which were related to $3.3 billion of available-for-sale debt securities, and the gross unrealized losses that have been in a continuous unrealized loss position for more than 12 months were $14.6 million, which were related to $922.5 million of available-for-sale debt securities. As of July 31, 2023 the gross unrealized losses that have been in a continuous unrealized loss position for less than 12 months were $30.7 million, which were related to $3.4 billion of available-for-sale debt securities, and the gross unrealized losses that have been in a continuous unrealized loss position for more than 12 months were $7.3 million, which were related to $481.8 million of available-for-sale debt securities.


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2024-02-21):
[0001327567-24-000005:note_history:48]
|  | Three Months Ended January 31, |  | Six Months Ended January 31, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Revenue: |  |  |  |  |  |  |  |
| Americas |  |  |  |  |  |  |  |
| United States | $ | 1,248.2 |  |  | $ | 1,042.3 |  |  | $ | 2,452.5 |  |  | $ | 2,048.6 |  |
| Other Americas | 86.0 |  |  | 74.7 |  |  | 168.3 |  |  | 139.1 |  |
| Total Americas | 1,334.2 |  |  | 1,117.0 |  |  | 2,620.8 |  |  | 2,187.7 |  |
| Europe, the Middle East, and Africa (“EMEA”) | 406.8 |  |  | 341.5 |  |  | 771.7 |  |  | 649.4 |  |
| Asia Pacific and Japan (“APAC”) | 234.1 |  |  | 196.6 |  |  | 460.7 |  |  | 381.4 |  |
| Total revenue | $ | 1,975.1 |  |  | $ | 1,655.1 |  |  | $ | 3,853.2 |  |  | $ | 3,218.5 |  |

- added (2024-02-21):
[0001327567-24-000005:note_history:49]
|  | Three Months Ended January 31, |  | Six Months Ended January 31, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Revenue: |  |  |  |  |  |  |  |
| Product | $ | 390.7 |  |  | $ | 352.9 |  |  | $ | 731.8 |  |  | $ | 682.9 |  |
| Subscription and support |  |  |  |  |  |  |  |
| Subscription | 1,027.1 |  |  | 815.4 |  |  | 2,015.4 |  |  | 1,579.4 |  |
| Support | 557.3 |  |  | 486.8 |  |  | 1,106.0 |  |  | 956.2 |  |
| Total subscription and support | 1,584.4 |  |  | 1,302.2 |  |  | 3,121.4 |  |  | 2,535.6 |  |
| Total revenue | $ | 1,975.1 |  |  | $ | 1,655.1 |  |  | $ | 3,853.2 |  |  | $ | 3,218.5 |  |

- changed (2024-02-21):
[0001327567-24-000005:note_history:50]
During the six months ended January 31, 2024 and 2023, we recognized approximately $2.7 billion and $2.1 billion of revenue pertaining to amounts that were deferred as of July 31, 2023 and 2022, respectively.
  (was, 2023-11-17, similarity 0.9465):
[0001327567-23-000032:note_history:50]
During the three months ended October 31, 2023 and 2022, we recognized approximately $1.4 billion and $1.1 billion of revenue pertaining to amounts that were deferred as of July 31, 2023 and 2022, respectively.

- changed (2024-02-21):
[0001327567-24-000005:note_history:51]
Remaining performance obligations were $10.8 billion as of January 31, 2024, of which we expect to recognize as revenue approximately $5.2 billion over the next 12 months and the remainder thereafter.
  (was, 2023-11-17, similarity 0.9681):
[0001327567-23-000032:note_history:51]
Remaining performance obligations were $10.4 billion as of October 31, 2023, of which we expect to recognize as revenue approximately $5.0 billion over the next 12 months and the remainder thereafter.

- removed (2024-02-21):
[0001327567-23-000032:note_history:52]
|  |  |  | Three Months Ended October 31, |
|  |  |  |  |  | 2023 |  | 2022 |
| Revenue: |  |  |  |  |  |  |  |
| Americas |  |  |  |  |  |  |  |
| United States |  |  |  |  | $ | 1,204.3 |  |  | $ | 1,006.3 |  |
| Other Americas |  |  |  |  | 82.3 |  |  | 64.4 |  |
| Total Americas |  |  |  |  | 1,286.6 |  |  | 1,070.7 |  |
| Europe, the Middle East, and Africa (“EMEA”) |  |  |  |  | 364.9 |  |  | 307.9 |  |
| Asia Pacific and Japan (“APAC”) |  |  |  |  | 226.6 |  |  | 184.8 |  |
| Total revenue |  |  |  |  | $ | 1,878.1 |  |  | $ | 1,563.4 |  |

- removed (2024-02-21):
[0001327567-23-000032:note_history:53]
|  |  |  | Three Months Ended October 31, |
|  |  |  |  |  | 2023 |  | 2022 |
| Revenue: |  |  |  |  |  |  |  |
| Product |  |  |  |  | $ | 341.1 |  |  | $ | 330.0 |  |
| Subscription and support |  |  |  |  |  |  |  |
| Subscription |  |  |  |  | 988.3 |  |  | 764.0 |  |
| Support |  |  |  |  | 548.7 |  |  | 469.4 |  |
| Total subscription and support |  |  |  |  | 1,537.0 |  |  | 1,233.4 |  |
| Total revenue |  |  |  |  | $ | 1,878.1 |  |  | $ | 1,563.4 |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- changed (2024-02-21):
[0001327567-24-000005:note_history:54]
Subsequent Event
2025 Notes Conversion
  (was, 2023-11-17, similarity 0.7077):
[0001327567-23-000032:note_history:54]
Subsequent Events
Acquisitions

- added (2024-02-21):
[0001327567-24-000005:note_history:55]
Subsequent to January 31, 2024, $581.0 million in aggregate principal amount of the 2025 Notes was converted or had been submitted by the holders for conversion and will settle during the fiscal quarter ending April 30, 2024.

- removed (2024-02-21):
[0001327567-23-000032:note_history:56]
On October 29, 2023, we entered into a definitive agreement to acquire Dig Security Solutions Ltd., a privately-held cyber security company (“Dig”), for total consideration of approximately $295.0 million, including approximately $232.0 million in cash and approximately $63.0 million in replacement awards, subject to adjustment. We expect the acquisition will enhance our Prisma Cloud capabilities with a data security posture management solution that is intended to provide customers with visibility into, and secure data stored across, their multi-cloud environments.

- removed (2024-02-21):
[0001327567-23-000032:note_history:57]
On November 6, 2023, we entered into a definitive agreement to acquire Talon Cyber Security Ltd., a privately-held cyber security company (“Talon”), for total consideration of approximately $550.0 million, including approximately $434.9 million in cash and approximately $115.1 million in replacement awards, subject to adjustment. We expect the acquisition will support Prisma SASE’s approach to provide secure access to business applications for unmanaged and personal devices with an enterprise browser.

- removed (2024-02-21):
[0001327567-23-000032:note_history:58]
The proposed acquisitions of Dig and Talon are expected to close during our second quarter of fiscal 2024, subject to the satisfaction of customary closing conditions.

- removed (2024-02-21):
[0001327567-23-000032:note_history:59]
Share Repurchase

- removed (2024-02-21):
[0001327567-23-000032:note_history:60]
On November 16, 2023, our board of directors authorized a $316.7 million increase to our share repurchase program, bringing the total remaining authorization for future share repurchases to $1.0 billion. The expiration date of the repurchase authorization was extended to December 31, 2024, and our repurchase program may be suspended or discontinued at any time without prior notice. Repurchases may be made at management’s discretion from time to time on the open market, through privately negotiated transactions, transactions structured through investment banking institutions, block purchase techniques, 10b5-1 trading plans, or a combination of the foregoing.
