# PANW notes — 0001327567-24-000005


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0001327567-24-000005:notes:1]
[same as prior period, unchanged from 0001327567-23-000032:notes:1]

[0001327567-24-000005:notes:2]
[same as prior period, unchanged from 0001327567-23-000032:notes:2]

[0001327567-24-000005:notes:3]
[same as prior period, unchanged from 0001327567-23-000032:notes:3]

[0001327567-24-000005:notes:4]
[same as prior period, unchanged from 0001327567-23-000032:notes:4]

[0001327567-24-000005:notes:5]
[same as prior period, unchanged from 0001327567-23-000032:notes:5]

[0001327567-24-000005:notes:6]
Reclassification

[0001327567-24-000005:notes:7]
Certain prior period amounts in the condensed consolidated financial statements have been reclassified to conform to the current period presentation.

[0001327567-24-000005:notes:8]
[same as prior period, unchanged from 0001327567-23-000032:notes:6]

[0001327567-24-000005:notes:9]
[same as prior period, unchanged from 0001327567-23-000032:notes:7]

[0001327567-24-000005:notes:10]
[same as prior period, unchanged from 0001327567-23-000032:notes:8]

[0001327567-24-000005:notes:11]
There have been no material changes to our significant accounting policies as of and for the six months ended January 31, 2024, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended July 31, 2023.

[0001327567-24-000005:notes:12]
Recently Issued Accounting Pronouncements

[0001327567-24-000005:notes:13]
Segment Reporting

[0001327567-24-000005:notes:14]
In November 2023, the Financial Accounting Standards Board (“FASB”) issued authoritative guidance that expands annual and interim disclosure requirements for reportable segments, primarily through enhanced disclosures about significant segment expenses. The standard is effective for our annual periods beginning in fiscal 2025 and interim periods beginning in the first quarter of fiscal 2026, and requires retrospective application for all prior periods presented in the financial statements. Early adoption is permitted. We are currently evaluating the impact of this standard on our disclosures in the consolidated financial statements.

[0001327567-24-000005:notes:15]
Income Tax Disclosures

[0001327567-24-000005:notes:16]
In December 2023, the FASB issued authoritative guidance that requires consistent categories and greater disaggregation of information in the effective tax rate reconciliation and additional disclosures of income taxes paid by jurisdiction. The standard is effective for our annual periods beginning in fiscal 2026 and could be applied either prospectively or retrospectively. Early adoption is permitted. We are currently evaluating the impact of this standard on our disclosures in the consolidated financial statements.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001327567-24-000005:notes:17]
[same as prior period, unchanged from 0001327567-23-000032:notes:10]

[0001327567-24-000005:notes:18]
[same as prior period, unchanged from 0001327567-23-000032:notes:11]

[0001327567-24-000005:notes:19]
|  | Three Months Ended January 31, |  | Six Months Ended January 31, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Revenue: |  |  |  |  |  |  |  |
| Americas |  |  |  |  |  |  |  |
| United States | $ | 1,248.2 |  |  | $ | 1,042.3 |  |  | $ | 2,452.5 |  |  | $ | 2,048.6 |  |
| Other Americas | 86.0 |  |  | 74.7 |  |  | 168.3 |  |  | 139.1 |  |
| Total Americas | 1,334.2 |  |  | 1,117.0 |  |  | 2,620.8 |  |  | 2,187.7 |  |
| Europe, the Middle East, and Africa (“EMEA”) | 406.8 |  |  | 341.5 |  |  | 771.7 |  |  | 649.4 |  |
| Asia Pacific and Japan (“APAC”) | 234.1 |  |  | 196.6 |  |  | 460.7 |  |  | 381.4 |  |
| Total revenue | $ | 1,975.1 |  |  | $ | 1,655.1 |  |  | $ | 3,853.2 |  |  | $ | 3,218.5 |  |

[0001327567-24-000005:notes:20]
[same as prior period, unchanged from 0001327567-23-000032:notes:13]

[0001327567-24-000005:notes:21]
|  | Three Months Ended January 31, |  | Six Months Ended January 31, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Revenue: |  |  |  |  |  |  |  |
| Product | $ | 390.7 |  |  | $ | 352.9 |  |  | $ | 731.8 |  |  | $ | 682.9 |  |
| Subscription and support |  |  |  |  |  |  |  |
| Subscription | 1,027.1 |  |  | 815.4 |  |  | 2,015.4 |  |  | 1,579.4 |  |
| Support | 557.3 |  |  | 486.8 |  |  | 1,106.0 |  |  | 956.2 |  |
| Total subscription and support | 1,584.4 |  |  | 1,302.2 |  |  | 3,121.4 |  |  | 2,535.6 |  |
| Total revenue | $ | 1,975.1 |  |  | $ | 1,655.1 |  |  | $ | 3,853.2 |  |  | $ | 3,218.5 |  |

[0001327567-24-000005:notes:22]
[same as prior period, unchanged from 0001327567-23-000032:notes:15]

[0001327567-24-000005:notes:23]
During the six months ended January 31, 2024 and 2023, we recognized approximately $2.7 billion and $2.1 billion of revenue pertaining to amounts that were deferred as of July 31, 2023 and 2022, respectively.

[0001327567-24-000005:notes:24]
[same as prior period, unchanged from 0001327567-23-000032:notes:17]

[0001327567-24-000005:notes:25]
Remaining performance obligations were $10.8 billion as of January 31, 2024, of which we expect to recognize as revenue approximately $5.2 billion over the next 12 months and the remainder thereafter.


## us-gaap:FairValueDisclosuresTextBlock

[0001327567-24-000005:notes:26]
Fair Value Measurements
The following table presents our financial assets and liabilities measured at fair value on a recurring basis as of January 31, 2024 and July 31, 2023 (in millions):

[0001327567-24-000005:notes:27]
|  | January 31, 2024 |  | July 31, 2023 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Cash equivalents: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | $ | 859.3 |  |  | $ | — |  |  | $ | — |  |  | $ | 859.3 |  |  | $ | 476.1 |  |  | $ | — |  |  | $ | — |  |  | $ | 476.1 |  |
| Certificates of deposit | — |  |  | 11.0 |  |  | — |  |  | 11.0 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Commercial paper | — |  |  | 252.1 |  |  | — |  |  | 252.1 |  |  | — |  |  | 151.4 |  |  | — |  |  | 151.4 |  |
| Corporate debt securities | — |  |  | 8.1 |  |  | — |  |  | 8.1 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| U.S. government and agency securities | — |  |  | 10.0 |  |  | — |  |  | 10.0 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Total cash equivalents | 859.3 |  |  | 281.2 |  |  | — |  |  | 1,140.5 |  |  | 476.1 |  |  | 151.4 |  |  | — |  |  | 627.5 |  |

[0001327567-24-000005:notes:28]
|  | January 31, 2024 |  | July 31, 2023 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Short-term investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Certificates of deposit | — |  |  | 61.7 |  |  | — |  |  | 61.7 |  |  | — |  |  | 48.1 |  |  | — |  |  | 48.1 |  |
| Commercial paper | — |  |  | 163.5 |  |  | — |  |  | 163.5 |  |  | — |  |  | 213.8 |  |  | — |  |  | 213.8 |  |
| Corporate debt securities | — |  |  | 1,241.7 |  |  | — |  |  | 1,241.7 |  |  | — |  |  | 798.0 |  |  | — |  |  | 798.0 |  |
| U.S. government and agency securities | — |  |  | 85.2 |  |  | — |  |  | 85.2 |  |  | — |  |  | 190.6 |  |  | — |  |  | 190.6 |  |
| Non-U.S. government and agency securities | — |  |  | 33.9 |  |  | — |  |  | 33.9 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Asset-backed securities | — |  |  | 2.5 |  |  | — |  |  | 2.5 |  |  | — |  |  | 4.2 |  |  | — |  |  | 4.2 |  |
| Total short-term investments | — |  |  | 1,588.5 |  |  | — |  |  | 1,588.5 |  |  | — |  |  | 1,254.7 |  |  | — |  |  | 1,254.7 |  |
| Long-term investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | — |  |  | 2,707.8 |  |  | — |  |  | 2,707.8 |  |  | — |  |  | 2,484.3 |  |  | — |  |  | 2,484.3 |  |
| U.S. government and agency securities | — |  |  | 76.3 |  |  | — |  |  | 76.3 |  |  | — |  |  | 22.0 |  |  | — |  |  | 22.0 |  |
| Non-U.S. government and agency securities | — |  |  | 54.4 |  |  | — |  |  | 54.4 |  |  | — |  |  | 36.6 |  |  | — |  |  | 36.6 |  |
| Asset-backed securities | — |  |  | 781.1 |  |  | — |  |  | 781.1 |  |  | — |  |  | 505.0 |  |  | — |  |  | 505.0 |  |
| Total long-term investments | — |  |  | 3,619.6 |  |  | — |  |  | 3,619.6 |  |  | — |  |  | 3,047.9 |  |  | — |  |  | 3,047.9 |  |
| Prepaid expenses and other current assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency forward contracts | — |  |  | 10.0 |  |  | — |  |  | 10.0 |  |  | — |  |  | 19.1 |  |  | — |  |  | 19.1 |  |
| Total prepaid expenses and other current assets | — |  |  | 10.0 |  |  | — |  |  | 10.0 |  |  | — |  |  | 19.1 |  |  | — |  |  | 19.1 |  |
| Other assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency forward contracts | — |  |  | 1.9 |  |  | — |  |  | 1.9 |  |  | — |  |  | 1.7 |  |  | — |  |  | 1.7 |  |
| Total other assets | — |  |  | 1.9 |  |  | — |  |  | 1.9 |  |  | — |  |  | 1.7 |  |  | — |  |  | 1.7 |  |
| Total assets measured at fair value | $ | 859.3 |  |  | $ | 5,501.2 |  |  | $ | — |  |  | $ | 6,360.5 |  |  | $ | 476.1 |  |  | $ | 4,474.8 |  |  | $ | — |  |  | $ | 4,950.9 |  |
| Accrued and other liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency forward contracts | $ | — |  |  | $ | 16.3 |  |  | $ | — |  |  | $ | 16.3 |  |  | $ | — |  |  | $ | 18.7 |  |  | $ | — |  |  | $ | 18.7 |  |
| Total accrued and other liabilities | — |  |  | 16.3 |  |  | — |  |  | 16.3 |  |  | — |  |  | 18.7 |  |  | — |  |  | 18.7 |  |
| Other long-term liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency forward contracts | — |  |  | 0.7 |  |  | — |  |  | 0.7 |  |  | — |  |  | 1.6 |  |  | — |  |  | 1.6 |  |
| Total other long-term liabilities | — |  |  | 0.7 |  |  | — |  |  | 0.7 |  |  | — |  |  | 1.6 |  |  | — |  |  | 1.6 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 17.0 |  |  | $ | — |  |  | $ | 17.0 |  |  | $ | — |  |  | $ | 20.3 |  |  | $ | — |  |  | $ | 20.3 |  |

[0001327567-24-000005:notes:29]
Refer to Note 9. Debt for the carrying amount and estimated fair value of our convertible senior notes as of January 31, 2024 and July 31, 2023.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001327567-24-000005:notes:30]
Cash Equivalents and Investments
Available-for-sale Debt Securities

[0001327567-24-000005:notes:31]
The following tables summarize the amortized cost, unrealized gains and losses, and fair value of our available-for-sale debt securities as of January 31, 2024 and July 31, 2023 (in millions):

[0001327567-24-000005:notes:32]
|  | January 31, 2024 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 11.0 |  |  | $ | — |  |  | $ | — |  |  | $ | 11.0 |  |
| Commercial paper | 252.1 |  |  | — |  |  | — |  |  | 252.1 |  |
| Corporate debt securities | 8.1 |  |  | — |  |  | — |  |  | 8.1 |  |
| U.S. government and agency securities | 10.0 |  |  | — |  |  | — |  |  | 10.0 |  |
| Total available-for-sale cash equivalents | $ | 281.2 |  |  | $ | — |  |  | $ | — |  |  | $ | 281.2 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 61.7 |  |  | $ | — |  |  | $ | — |  |  | $ | 61.7 |  |
| Commercial paper | 163.3 |  |  | 0.2 |  |  | — |  |  | 163.5 |  |
| Corporate debt securities | 3,937.2 |  |  | 22.5 |  |  | (10.2) |  |  | 3,949.5 |  |
| U.S. government and agency securities | 160.5 |  |  | 1.1 |  |  | (0.1) |  |  | 161.5 |  |
| Non-U.S. government and agency securities | 87.8 |  |  | 0.8 |  |  | (0.3) |  |  | 88.3 |  |
| Asset-backed securities | 778.5 |  |  | 5.8 |  |  | (0.7) |  |  | 783.6 |  |
| Total available-for-sale investments | $ | 5,189.0 |  |  | $ | 30.4 |  |  | $ | (11.3) |  |  | $ | 5,208.1 |  |

[0001327567-24-000005:notes:33]
|  | July 31, 2023 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | $ | 151.4 |  |  | $ | — |  |  | $ | — |  |  | $ | 151.4 |  |
| Total available-for-sale cash equivalents | $ | 151.4 |  |  | $ | — |  |  | $ | — |  |  | $ | 151.4 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 48.1 |  |  | $ | — |  |  | $ | — |  |  | $ | 48.1 |  |
| Commercial paper | 214.1 |  |  | — |  |  | (0.3) |  |  | 213.8 |  |
| Corporate debt securities | 3,313.5 |  |  | 1.3 |  |  | (32.5) |  |  | 3,282.3 |  |
| U.S. government and agency securities | 214.2 |  |  | — |  |  | (1.6) |  |  | 212.6 |  |
| Non-U.S. government and agency securities | 37.2 |  |  | — |  |  | (0.6) |  |  | 36.6 |  |
| Asset-backed securities | 512.0 |  |  | 0.2 |  |  | (3.0) |  |  | 509.2 |  |
| Total available-for-sale investments | $ | 4,339.1 |  |  | $ | 1.5 |  |  | $ | (38.0) |  |  | $ | 4,302.6 |  |

[0001327567-24-000005:notes:34]
As of January 31, 2024, the gross unrealized losses that have been in a continuous unrealized loss position for less than 12 months were $5.1 million, which were related to $1.5 billion of available-for-sale debt securities, and the gross unrealized losses that have been in a continuous unrealized loss position for more than 12 months were $6.2 million, which were related to $752.8 million of available-for-sale debt securities. As of July 31, 2023 the gross unrealized losses that have been in a continuous unrealized loss position for less than 12 months were $30.7 million, which were related to $3.4 billion of available-for-sale debt securities, and the gross unrealized losses that have been in a continuous unrealized loss position for more than 12 months were $7.3 million, which were related to $481.8 million of available-for-sale debt securities.

[0001327567-24-000005:notes:35]
Unrealized losses related to our available-for-sale debt securities are primarily due to interest rate fluctuations as opposed to credit quality. We do not intend to sell any of the securities in an unrealized loss position and it is not likely that we would be required to sell these securities before recovery of their amortized cost basis, which may be at maturity. We did not recognize any credit losses related to our available-for-sale debt securities during the three and six months ended January 31, 2024 and 2023.

[0001327567-24-000005:notes:36]
The following table summarizes the amortized cost and fair value of our available-for-sale debt securities as of January 31, 2024, by contractual years-to-maturity (in millions):

[0001327567-24-000005:notes:37]
|  | Amortized Cost |  | Fair Value |
| Due within one year | $ | 1,873.7 |  |  | $ | 1,869.7 |  |
| Due between one and three years | 2,244.2 |  |  | 2,250.3 |  |
| Due between three and five years | 1,120.4 |  |  | 1,134.3 |  |
| Due between five and ten years | 138.8 |  |  | 140.1 |  |
| Due after ten years | 93.1 |  |  | 94.9 |  |
| Total | $ | 5,470.2 |  |  | $ | 5,489.3 |  |

[0001327567-24-000005:notes:38]
Marketable Equity Securities

[0001327567-24-000005:notes:39]
Marketable equity securities consist of money market funds and are included in cash and cash equivalents on our condensed consolidated balance sheets. As of January 31, 2024 and July 31, 2023, the carrying values of our marketable equity securities were $859.3 million and $476.1 million, respectively. There were no unrealized gains or losses recognized for these securities during the three and six months ended January 31, 2024 and 2023.


## us-gaap:FinancingReceivablesTextBlock

[0001327567-24-000005:notes:40]
Financing Receivables
The following table summarizes our short-term and long-term financing receivables as of January 31, 2024 and July 31, 2023 (in millions):

[0001327567-24-000005:notes:41]
|  | January 31, 2024 |  | July 31, 2023 |
| Short-term financing receivables, gross | $ | 503.0 |  |  | $ | 435.1 |  |
| Unearned income | (49.1) |  |  | (42.9) |  |
| Allowance for credit losses | (8.4) |  |  | (3.4) |  |
| Short-term financing receivables, net | $ | 445.5 |  |  | $ | 388.8 |  |
| Long-term financing receivables, gross | $ | 685.4 |  |  | $ | 698.6 |  |
| Unearned income | (39.0) |  |  | (39.2) |  |
| Allowance for credit losses | (6.5) |  |  | (6.1) |  |
| Long-term financing receivables, net | $ | 639.9 |  |  | $ | 653.3 |  |

[0001327567-24-000005:notes:42]
Our financing receivables portfolio primarily consisted of high-quality investment-grade receivables as of January 31, 2024 and July 31, 2023. There was no significant activity in allowance for credit losses during the three and six months ended January 31, 2024 and 2023. Past due amounts on financing receivables were not material as of January 31, 2024 and July 31, 2023.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001327567-24-000005:notes:43]
[same as prior period, unchanged from 0001327567-23-000032:notes:36]

[0001327567-24-000005:notes:44]
As of January 31, 2024 and July 31, 2023, the total notional amount of our outstanding foreign currency forward contracts was $1.2 billion and $957.5 million, respectively. Refer to Note 3. Fair Value Measurements for the fair value of our derivative instruments as reported on our condensed consolidated balance sheets as of January 31, 2024 and July 31, 2023.

[0001327567-24-000005:notes:45]
As of January 31, 2024, unrealized gains and losses in accumulated other comprehensive income (“AOCI”) related to our cash flow hedges were a $6.2 million net loss, of which $5.4 million in losses are expected to be recognized into earnings within the next 12 months. As of July 31, 2023, unrealized gains and losses in AOCI related to our cash flow hedges were a $0.7 million net gain.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001327567-24-000005:notes:46]
Acquisitions
Dig Security Solutions Ltd.

[0001327567-24-000005:notes:47]
On December 5, 2023, we completed our acquisition of Dig Security Solutions Ltd. (“Dig”), a privately-held cyber security company. We expect the acquisition will enhance our Prisma Cloud capabilities with a data security posture management solution that is intended to provide customers with visibility into, and secure data stored across, their multi-cloud environments. The total purchase consideration for the acquisition of Dig was $255.4 million, which consisted of the following (in millions):

[0001327567-24-000005:notes:48]
|  | Amount |
| Cash | $ | 247.6 |  |
| Fair value of replacement awards | 7.8 |  |
| Total | $ | 255.4 |  |

[0001327567-24-000005:notes:49]
As part of the acquisition, we issued replacement equity awards, which included 0.2 million shares of our restricted common stock. The total fair value of the replacement equity awards was $72.0 million, of which the portion attributable to services performed prior to the acquisition date was allocated to purchase consideration. The remaining fair value was allocated to future services and will be expensed over the remaining service periods as share-based compensation.

[0001327567-24-000005:notes:50]
We have accounted for this transaction as a business combination and allocated the purchase consideration to assets acquired and liabilities assumed based on preliminary estimated fair values, as presented in the following table (in millions):

[0001327567-24-000005:notes:51]
|  | Amount |
| Goodwill | $ | 192.2 |  |
| Identified intangible assets | 45.4 |  |
| Cash and restricted cash | 22.1 |  |
| Net liabilities assumed | (4.3) |  |
| Total | $ | 255.4 |  |

[0001327567-24-000005:notes:52]
Goodwill generated from this business combination is primarily attributable to the assembled workforce and expected post-acquisition synergies from integrating Dig technology into our platforms. The goodwill is not expected to be deducible for income tax purposes.

[0001327567-24-000005:notes:53]
The following table presents details of the identified intangible asset acquired (in millions, except years):

[0001327567-24-000005:notes:54]
|  | Fair Value |  | Estimated Useful Life |
| Developed technology | $ | 45.4 |  |  | 5 years |

[0001327567-24-000005:notes:55]
Talon Cyber Security Ltd.

[0001327567-24-000005:notes:56]
On December 28, 2023, we completed our acquisition of Talon Cyber Security Ltd. (“Talon”), a privately-held cyber security company. We expect the acquisition will support Prisma SASE’s approach to provide secure access to business applications for unmanaged and personal devices with an enterprise browser. The total purchase consideration for the acquisition of Talon was $458.6 million, which consisted of the following (in millions):

[0001327567-24-000005:notes:57]
|  | Amount |
| Cash | $ | 439.0 |  |
| Fair value of replacement awards | 19.6 |  |
| Total | $ | 458.6 |  |

[0001327567-24-000005:notes:58]
As part of the acquisition, we issued replacement equity awards, which included 0.3 million shares of our restricted common stock. The total fair value of the replacement equity awards was $109.6 million, of which the portion attributable to services performed prior to the acquisition date was allocated to purchase consideration. The remaining fair value was allocated to future services and will be expensed over the remaining service periods as share-based compensation.

[0001327567-24-000005:notes:59]
|  | Amount |
| Goodwill | $ | 253.7 |  |
| Identified intangible assets | 131.4 |  |
| Cash and restricted cash | 53.9 |  |
| Net assets acquired | 19.6 |  |
| Total | $ | 458.6 |  |

[0001327567-24-000005:notes:60]
Goodwill generated from this business combination is primarily attributable to the assembled workforce and expected post-acquisition synergies from integrating Talon technology into our platforms. The goodwill is not expected to be deductible for income tax purposes.

[0001327567-24-000005:notes:61]
|  | Fair Value |  | Estimated Useful Life |
| Developed technology | $ | 131.4 |  |  | 5 years |


## us-gaap:ScheduleOfBusinessAcquisitionsByAcquisitionTextBlock

[0001327567-24-000005:notes:62]
The total purchase consideration for the acquisition of Dig was $255.4 million, which consisted of the following (in millions):

[0001327567-24-000005:notes:63]
The total purchase consideration for the acquisition of Talon was $458.6 million, which consisted of the following (in millions):


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001327567-24-000005:notes:64]
Intangible Assets
Goodwill

[0001327567-24-000005:notes:65]
The following table presents details of our goodwill during the six months ended January 31, 2024 (in millions):

[0001327567-24-000005:notes:66]
|  | Amount |
| Balance as of July 31, 2023 | $ | 2,926.8 |  |
| Goodwill acquired | 445.9 |  |
| Balance as of January 31, 2024 | $ | 3,372.7 |  |

[0001327567-24-000005:notes:67]
Purchased Intangible Assets

[0001327567-24-000005:notes:68]
The following table presents details of our purchased intangible assets as of January 31, 2024 and July 31, 2023 (in millions):

[0001327567-24-000005:notes:69]
|  | January 31, 2024 |  | July 31, 2023 |
|  | Gross Carrying Amount |  | Accumulated Amortization |  | Net Carrying Amount |  | Gross Carrying Amount |  | Accumulated Amortization |  | Net Carrying Amount |
| Intangible assets subject to amortization: |  |  |  |  |  |  |  |  |  |  |  |
| Developed technology | $ | 813.9 |  |  | $ | (471.0) |  |  | $ | 342.9 |  |  | $ | 633.2 |  |  | $ | (429.4) |  |  | $ | 203.8 |  |
| Customer relationships | 172.7 |  |  | (84.7) |  |  | 88.0 |  |  | 172.7 |  |  | (73.9) |  |  | 98.8 |  |
| Acquired intellectual property | 15.8 |  |  | (7.0) |  |  | 8.8 |  |  | 14.6 |  |  | (6.2) |  |  | 8.4 |  |
| Trade name and trademarks | 9.4 |  |  | (9.4) |  |  | — |  |  | 9.4 |  |  | (9.4) |  |  | — |  |
| Other | 0.9 |  |  | (0.5) |  |  | 0.4 |  |  | 0.9 |  |  | (0.4) |  |  | 0.5 |  |
| Total intangible assets subject to amortization | 1,012.7 |  |  | (572.6) |  |  | 440.1 |  |  | 830.8 |  |  | (519.3) |  |  | 311.5 |  |
| Intangible assets not subject to amortization: |  |  |  |  |  |  |  |  |  |  |  |
| In-process research and development | — |  |  | — |  |  | — |  |  | 3.9 |  | — |  |  | 3.9 |  |
| Total purchased intangible assets | $ | 1,012.7 |  |  | $ | (572.6) |  |  | $ | 440.1 |  |  | $ | 834.7 |  |  | $ | (519.3) |  |  | $ | 315.4 |  |

[0001327567-24-000005:notes:70]
We recognized amortization expense of $28.4 million and $53.3 million for the three and six months ended January 31, 2024, respectively, and $24.8 million and $53.9 million for the three and six months ended January 31, 2023, respectively.

[0001327567-24-000005:notes:71]
The following table summarizes estimated future amortization expense of our intangible assets subject to amortization as of January 31, 2024 (in millions):

[0001327567-24-000005:notes:72]
|  |  |  | Fiscal years ending July 31, |
|  | Total |  | Remaining 2024 |  | 2025 |  | 2026 |  | 2027 |  | 2028 |  | 2029 and Thereafter |
| Future amortization expense | $ | 440.1 |  |  | $ | 66.6 |  |  | $ | 120.5 |  |  | $ | 98.7 |  |  | $ | 71.6 |  |  | $ | 50.0 |  |  | $ | 32.7 |  |


## us-gaap:DebtDisclosureTextBlock

[0001327567-24-000005:notes:73]
Debt
Convertible Senior Notes

[0001327567-24-000005:notes:74]
In July 2018, we issued $1.7 billion aggregate principal amount of 0.75% Convertible Senior Notes due 2023 (the “2023 Notes”) and in June 2020, we issued $2.0 billion aggregate principal amount of 0.375% Convertible Senior Notes due 2025 (the “2025 Notes,” and together with the 2023 Notes, the “Notes”). The 2023 Notes were converted prior to or settled on the maturity date of July 1, 2023 in accordance with their terms. The 2025 Notes bear interest at a fixed rate of 0.375% per year, payable semi-annually in arrears on June 1 and December 1 of each year, beginning on December 1, 2020. The 2025 Notes are governed by an indenture between us, as the issuer, and U.S. Bank National Association, as Trustee (the “Indenture”). The 2025 Notes are unsecured, unsubordinated obligations and the Indenture governing the 2025 Notes does not contain any financial covenants or restrictions on the payments of dividends, the incurrence of indebtedness, or the issuance or repurchase of securities by us or any of our subsidiaries. The 2025 Notes mature on June 1, 2025. We may redeem for cash all or any portion of the 2025 Notes, at our option, on or after June 5, 2023 and prior to the 31st scheduled trading day immediately preceding the maturity date if the last reported sale price of our common stock has been at least 130% of the conversion price then in effect for at least 20 trading days during any 30 consecutive trading day period ending on and including the trading day preceding the date on which we provide notice of redemption. The redemption will be at a price equal to 100% of the principal amount of the 2025 Notes and adjusted for interest. If we call any or all of the 2025 Notes for redemption, holders may convert such 2025 Notes called for redemption at any time prior to the close of business on the second scheduled trading day immediately preceding the redemption date.

[0001327567-24-000005:notes:75]
The 2025 Notes are convertible for an initial 20.1 million shares of our common stock at a conversion rate of approximately 10.0806 shares of common stock per $1,000 principal amount, which is equal to an initial conversion price of approximately $99.20 per share of common stock, subject to adjustments. Holders of the 2025 Notes may surrender their 2025 Notes for conversion at their option at any time prior to the close of business on the business day immediately preceding March 1, 2025 only under the following circumstances:

[0001327567-24-000005:notes:76]
•during any fiscal quarter commencing after the fiscal quarters ending on October 31, 2020 (and only during such fiscal quarter), if the last reported sale price of our common stock for at least 20 trading days (whether or not consecutive) during a period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the conversion price for the 2025 Notes on each applicable trading day (the “sale price condition”);

[0001327567-24-000005:notes:77]
•during the five business day period after any five consecutive trading day period (the “measurement period”) in which the trading price per $1,000 principal amount of the 2025 Notes for each trading day of the measurement period was less than 98% of the product of the last reported sale price of our common stock and the conversion rate for the 2025 Notes on each such trading day; or

[0001327567-24-000005:notes:78]
•upon the occurrence of specified corporate events.

[0001327567-24-000005:notes:79]
On or after March 1, 2025, holders may surrender all or any portion of their 2025 Notes for conversion at any time prior to the close of business on the second scheduled trading day immediately preceding the maturity date regardless of the foregoing conditions, and such conversions will be settled upon the maturity date. Upon conversion, holders of the 2025 Notes will receive cash equal to the aggregate principal amount of the 2025 Notes to be converted, and, at our election, cash and/or shares of our common stock for any amounts in excess of the aggregate principal amount of the 2025 Notes being converted.

[0001327567-24-000005:notes:80]
The conversion price will be subject to adjustment in some events. Holders of the 2025 Notes who convert their 2025 Notes in connection with certain corporate events that constitute a “make-whole fundamental change” under the Indenture are, under certain circumstances, entitled to an increase in the conversion rate. Additionally, upon the occurrence of a corporate event that constitutes a “fundamental change” under the Indenture, holders of the 2025 Notes may require us to repurchase for cash all or a portion of the 2025 Notes at a repurchase price equal to 100% of the principal amount of the 2025 Notes plus accrued and unpaid interest to, but excluding, the fundamental change repurchase date.

[0001327567-24-000005:notes:81]
Holders of the 2025 Notes were able to early convert their 2025 Notes during the fiscal quarter ended January 31, 2024 as the sales price condition had been met during the fiscal quarter ended October 31, 2023. During the three and six months ended January 31, 2024, holders of the 2025 Notes converted $126.3 million and $172.3 million, respectively, in aggregate principal amount of the 2025 Notes, which we repaid in cash. We also issued 0.8 million and 1.1 million shares of our common stock to the holders of the 2025 Notes during the three and six months ended January 31, 2024, respectively, for the conversion value in excess of the principal amount. These shares were fully offset by shares we received from the corresponding exercise of the associated note hedges. Refer to Note 16. Subsequent Event for additional information regarding conversion of the 2025 Notes after January 31, 2024 through the filing date of this Quarterly Report on Form 10-Q.

[0001327567-24-000005:notes:82]
The sale price condition for the 2025 Notes was met during the fiscal quarter ended January 31, 2024 and as a result, holders may convert their 2025 Notes during the fiscal quarter ending April 30, 2024. The net carrying amount of the 2025 Notes was classified as a current liability on our condensed consolidated balance sheet as of January 31, 2024.

[0001327567-24-000005:notes:83]
The following table sets forth the net carrying amount of our 2025 Notes (in millions):

[0001327567-24-000005:notes:84]
|  |  |  | January 31, 2024 | July 31, 2023 |
| Principal |  |  | $ | 1,827.0 |  |  |  |  |  |  | $ | 1,999.3 |  |  |  |
| Less: debt issuance costs, net of amortization |  |  | (5.2) |  |  |  |  |  |  | (7.8) |  |  |  |
| Net carrying amount |  |  | $ | 1,821.8 |  |  |  |  |  |  | $ | 1,991.5 |  |  |  |

[0001327567-24-000005:notes:85]
The total estimated fair value of the 2025 Notes was $6.2 billion as of January 31, 2024 and $5.0 billion as of July 31, 2023. The fair value was determined based on the closing trading price per $100 of the 2025 Notes as of the last day of trading for the period. We consider the fair value of the 2025 Notes as of January 31, 2024 and July 31, 2023 to be a Level 2 measurement. The fair value of the 2025 Notes is primarily affected by the trading price of our common stock and market interest rates.

[0001327567-24-000005:notes:86]
The following table sets forth interest expense recognized related to the Notes (dollars in millions):

[0001327567-24-000005:notes:87]
|  | Three Months Ended January 31, |  | Six Months Ended January 31, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
|  | 2023 Notes |  | 2025 Notes |  | Total |  | 2023 Notes |  | 2025 Notes |  | Total |  | 2023 Notes |  | 2025 Notes |  | Total |  | 2023 Notes |  | 2025 Notes |  | Total |
| Contractual interest expense | $ | — |  |  | $ | 1.7 |  |  | $ | 1.7 |  |  | $ | 3.2 |  |  | $ | 2.0 |  |  | $ | 5.2 |  |  | $ | — |  |  | $ | 3.6 |  |  | $ | 3.6 |  |  | $ | 6.4 |  |  | $ | 3.8 |  |  | $ | 10.2 |  |
| Amortization of debt issuance costs | — |  |  | 1.1 |  |  | 1.1 |  |  | 0.7 |  |  | 1.0 |  |  | 1.7 |  |  | — |  |  | 2.1 |  |  | 2.1 |  |  | 1.4 |  |  | 2.1 |  |  | 3.5 |  |
| Total interest expense | $ | — |  |  | $ | 2.8 |  |  | $ | 2.8 |  |  | $ | 3.9 |  |  | $ | 3.0 |  |  | $ | 6.9 |  |  | $ | — |  |  | $ | 5.7 |  |  | $ | 5.7 |  |  | $ | 7.8 |  |  | $ | 5.9 |  |  | $ | 13.7 |  |
| Effective interest rate | — | % |  | 0.6 | % |  |  |  | 0.9 | % |  | 0.6 | % |  |  |  | — | % |  | 0.6 | % |  |  |  | 0.9 | % |  | 0.6 | % |  |  |

[0001327567-24-000005:notes:88]
Note Hedges

[0001327567-24-000005:notes:89]
To minimize the impact of potential economic dilution upon conversion of our convertible senior notes, we entered into separate convertible note hedge transactions (the “2023 Note Hedges,” with respect to the 2023 Notes, the “2025 Note Hedges,” with respect to the 2025 Notes, and the 2023 Note Hedges together with 2025 Note Hedges, the “Note Hedges”) with respect to our common stock concurrent with the issuance of each series of the Notes.

[0001327567-24-000005:notes:90]
Upon the settlement of the 2023 Notes, we exercised the corresponding portion of our 2023 Note Hedges during the year ended July 31, 2023 and received shares of our common stock that fully offset the shares issued in excess of the principal amount of the converted 2023 Notes. The 2023 Note Hedges expired upon maturity of the 2023 Notes.

[0001327567-24-000005:notes:91]
The 2025 Note Hedges cover up to 20.1 million shares of our common stock at a strike price per share that corresponds to the initial conversion price of the 2025 Notes, which are also subject to adjustment, and are exercisable upon conversion of the 2025 Notes. The 2025 Note Hedges will expire upon maturity of the 2025 Notes. The 2025 Note Hedges are separate transactions and are not part of the terms of the 2025 Notes. Holders of the 2025 Notes will not have any rights with respect to the 2025 Note Hedges. Any shares of our common stock receivable by us under the 2025 Note Hedges are excluded from the calculation of diluted earnings per share as they are antidilutive. We paid an aggregate amount of $370.8 million for the 2025 Note Hedges, which is included in additional paid-in capital on our condensed consolidated balance sheets.

[0001327567-24-000005:notes:92]
As a result of the conversions of the 2025 Notes settled during the three and six months ended January 31, 2024, we exercised the corresponding portion of our 2025 Note Hedges and received 0.8 million and 1.1 million shares of our common stock during the respective period.

[0001327567-24-000005:notes:93]
Warrants

[0001327567-24-000005:notes:94]
Separately, but concurrently with the issuance of each series of our convertible senior notes, we entered into transactions whereby we sold warrants (the “2023 Warrants,” with respect to the 2023 Notes, the “2025 Warrants,” with respect to the 2025 Notes, and the 2023 Warrants together with the 2025 Warrants, the “Warrants”) to acquire shares of our common stock, subject to anti-dilution adjustments. The 2023 Warrants and 2025 Warrants are exercisable over 60 scheduled trading days beginning October 2023 and September 2025, respectively.

[0001327567-24-000005:notes:95]
The following table presents details of our Warrants (in millions, except per share data):

[0001327567-24-000005:notes:96]
|  | Initial Number of Shares |  | Strike Price per Share |  | Aggregate Proceeds |
| 2023 Warrants | 19.1 |  |  | $ | 139.27 |  |  | $ | 145.4 |  |
| 2025 Warrants | 20.1 |  |  | $ | 136.16 |  |  | $ | 202.8 |  |

[0001327567-24-000005:notes:97]
The shares issuable under the Warrants are included in the calculation of diluted earnings per share when the average market value per share of our common stock for the reporting period exceeds the applicable strike price for such series of Warrants. The Warrants are separate transactions and are not part of either series of Notes or Note Hedges and are not remeasured through earnings each reporting period. Holders of the Notes of either series will not have any rights with respect to the Warrants. The aggregate proceeds received from the sale of the Warrants are included in additional paid-in capital on our condensed consolidated balance sheets.

[0001327567-24-000005:notes:98]
During the six months ended January 31, 2024, we net settled all of the 2023 Warrants with 9.0 million shares of our common stock with a fair value of $2.4 billion, of which 5.9 million shares of our common stock with a fair value of $1.7 billion were net settled during the three months ended January 31, 2024. The number of net shares issued was determined based on the number of 2023 Warrants exercised multiplied by the difference between the strike price of the 2023 Warrants and their daily volume-weighted-average stock price.

[0001327567-24-000005:notes:99]
Revolving Credit Facility

[0001327567-24-000005:notes:100]
On April 13, 2023, we entered into a credit agreement (the “Credit Agreement”) with certain institutional lenders that provides for a $400.0 million unsecured revolving credit facility (the “Credit Facility”), with an option to increase the amount of the Credit Facility by up to an additional $350.0 million, subject to certain conditions. The Credit Facility matures on April 13, 2028.

[0001327567-24-000005:notes:101]
The borrowings under the Credit Facility bear interest, at our option, at a base rate plus a spread of 0.000% to 0.375%, or an adjusted term Secured Overnight Financing Rate (“SOFR”) plus a spread of 1.000% to 1.375%, in each case with such spread being determined based on our leverage ratio. We are obligated to pay an ongoing commitment fee on undrawn amounts at a rate of 0.090% to 0.150%, depending on our leverage ratio. The interest rates and commitment fees are also subject to upward and downward adjustments based on our progress towards the achievement of certain sustainability goals related to greenhouse gas emissions.

[0001327567-24-000005:notes:102]
As of January 31, 2024, there were no amounts outstanding and we were in compliance with all covenants under the Credit Agreement.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001327567-24-000005:notes:103]
Commitments and Contingencies
Purchase Commitments

[0001327567-24-000005:notes:104]
We have entered into various non-cancelable agreements with cloud service providers, under which we are committed to minimum or fixed purchases of certain cloud services. In addition, in order to reduce manufacturing lead times and plan for adequate supply, we have entered into agreements with manufacturing partners and component suppliers to procure inventory based on our demand forecasts. The following table presents details of the aggregate future non-cancelable purchase commitments under these agreements as of January 31, 2024 (in millions):

[0001327567-24-000005:notes:105]
|  |  |  | Fiscal years ending July 31, |
|  | Total |  | Remaining 2024 |  | 2025 |  | 2026 |  | 2027 |  | 2028 |  | 2029 and Thereafter |
| Cloud | $ | 4,793.3 |  |  | $ | 0.6 |  |  | $ | 419.8 |  |  | $ | 868.4 |  |  | $ | 518.1 |  |  | $ | 585.6 |  |  | $ | 2,400.8 |  |
| Manufacturing | 218.9 |  |  | 109.3 |  |  | 69.6 |  |  | 40.0 |  |  | — |  |  | — |  |  | — |  |
| Other | 34.7 |  |  | 4.8 |  |  | 9.8 |  |  | 7.2 |  |  | 3.0 |  |  | 3.2 |  |  | 6.7 |  |
| Total purchase commitments | $ | 5,046.9 |  |  | $ | 114.7 |  |  | $ | 499.2 |  |  | $ | 915.6 |  |  | $ | 521.1 |  |  | $ | 588.8 |  |  | $ | 2,407.5 |  |

[0001327567-24-000005:notes:106]
Additionally, we have a $149.9 million minimum purchase commitment with a cloud service provider through September 2027 with no specified annual commitments.

[0001327567-24-000005:notes:107]
Guarantee

[0001327567-24-000005:notes:108]
In October 2023, we established a multi-currency notional cash pool for a certain number of our entities with a third-party bank. As part of the notional cash pool agreement, the bank extends overdraft credit to our participating entities as needed, provided that the overall notionally pooled balance of all accounts in the pool at the end of each day is positive. In the unlikely event of a default, any overdraft balances incurred would be guaranteed by our collective entities participating in the pool.

[0001327567-24-000005:notes:109]
Litigation

[0001327567-24-000005:notes:110]
We are subject to legal proceedings, claims, tax matters, and litigation arising in the ordinary course of business, including, for instance, intellectual property and patent litigation. We accrue for contingencies when we believe that a loss is probable and that we can reasonably estimate the amount of any such loss.

[0001327567-24-000005:notes:111]
Legal matters could include speculative, substantial, or indeterminate monetary amounts. Significant judgment is required to determine both the likelihood of there being a loss and the estimated amount of a loss related to such matters, and we may be unable to estimate the reasonably possible loss or range of loss. The outcomes of outstanding legal matters are inherently unpredictable, and could, either individually or in aggregate, have a material adverse effect on us and our results of operations. To the extent there is a reasonable possibility that a loss exceeding any amounts already recognized may be incurred, we will either disclose the estimated additional loss or state that such an estimate cannot be made.

[0001327567-24-000005:notes:112]
The following matters arose in the ordinary course of business.

[0001327567-24-000005:notes:113]
Centripetal Networks, Inc. v. Palo Alto Networks

[0001327567-24-000005:notes:114]
On March 12, 2021, Centripetal Networks, Inc., filed a lawsuit against us in the United States District Court for the Eastern District of Virginia. The lawsuit alleges that our products infringe multiple Centripetal patents. We successfully challenged certain of these patents, which were found unpatentable by the U.S. Patent and Trademark Office (“PTO”). The case went to jury trial on January 22, 2024, on four patents, with three stayed pending review in the PTO. On January 31, 2024, the jury returned a verdict of non-willful infringement with a lump sum amount of $151.5 million, plus statutory interest. We are advancing post-trial motions that aim to eliminate patents and patent claims from the scope of the final judgment and corresponding damages. The trial judge will decide these motions before entering final judgment, after which there will likely be an appeal by one or both parties to the action. We respectfully disagree with the verdict and believe that it is contrary to both the law and the extensive evidence presented at trial, which is why we are seeking relief from the court. In addition, Centripetal filed infringement contentions on certain of their patents in the European Patent Office in Germany, to which we filed invalidity challenges. Those matters are still pending.

[0001327567-24-000005:notes:115]
As of January 31, 2024, we accrued $176.8 million for the verdict amount and estimated interest. The accrual was recorded in other long-term liabilities on our condensed consolidated balance sheets with the corresponding charge included in general and administrative expense on our condensed consolidated statements of operations for the three and six months ended January 31, 2024.

[0001327567-24-000005:notes:116]
Finjan, Inc. v. Palo Alto Networks

[0001327567-24-000005:notes:117]
On November 4, 2014, Finjan, Inc., filed a lawsuit against us in the United States District Court for the Northern District of California. The lawsuit alleges that our products infringe multiple Finjan patents. The complaint requests injunctive relief, monetary damages, and attorneys fees. The trial is set for October 21, 2024. We are unable, at this time, to reasonably estimate a possible loss or potential range of loss, if any.

[0001327567-24-000005:notes:118]
Taasera v. Palo Alto Networks

[0001327567-24-000005:notes:119]
On March 22, 2022, we filed a declaratory judgment action in the United States District Court for the Southern District of New York seeking a ruling that we are not infringing various Taasera patents. The parties have now resolved all pending matters between them as of December 2023. The amounts paid by us to resolve these matters were not material.

[0001327567-24-000005:notes:120]
Lionra Technologies v. Palo Alto Networks

[0001327567-24-000005:notes:121]
On August 29, 2022, Lionra Technologies filed a lawsuit against us in the United States District Court for the Eastern District of Texas. The lawsuit alleges that our products infringe multiple Lionra patents. The complaint requests injunctive relief, monetary damages and attorneys fees. The patents at issue are currently under review before the U.S. Patent and Trademark Office. Trial is set for May 20, 2024. We are unable, at this time, to reasonably estimate a possible loss or potential range of loss, if any.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001327567-24-000005:notes:122]
[same as prior period, unchanged from 0001327567-23-000032:notes:95]

[0001327567-24-000005:notes:123]
In February 2019, our board of directors authorized a $1.0 billion share repurchase program, which is funded from available working capital. In December 2020, August 2021, August 2022, and November 2023, our board of directors authorized additional $700.0 million, $676.1 million, $915.0 million, and $316.7 million increases to this share repurchase program, respectively, bringing the total authorization under this share repurchase program to $3.6 billion (our “current authorization”). The expiration date of our current authorization was extended to December 31, 2024, and our repurchase program may be suspended or discontinued at any time. Repurchases may be made at management’s discretion from time to time on the open market, through privately negotiated transactions, transactions structured through investment banking institutions, block purchase techniques, 10b5-1 trading plans, or a combination of the foregoing.

[0001327567-24-000005:notes:124]
The following table summarizes the share repurchase activity under our share repurchase program (in millions, except per share amounts):

[0001327567-24-000005:notes:125]
|  | Three Months Ended January 31, |  | Six Months Ended January 31, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Number of shares repurchased | — |  |  | 1.8 |  |  | 0.3 |  |  | 1.8 |  |
| Weighted average price per share(1) | $ | — |  |  | $ | 138.65 |  |  | $ | 226.67 |  |  | $ | 138.65 |  |
| Aggregate purchase price(1) | $ | — |  |  | $ | 250.0 |  |  | $ | 66.7 |  |  | $ | 250.0 |  |

[0001327567-24-000005:notes:126]
(1)     Includes transaction costs

[0001327567-24-000005:notes:127]
In addition to the share repurchase activity summarized in the table above, during the six months ended January 31, 2023, we paid $22.7 million related to share repurchases of our common stock that were not settled as of July 31, 2022.

[0001327567-24-000005:notes:128]
As of January 31, 2024, $1.0 billion remained available for future share repurchases under our current repurchase authorization. The total price of the shares repurchased and related transaction costs are reflected as a reduction to common stock and additional paid-in capital on our condensed consolidated balance sheets.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001327567-24-000005:notes:129]
[same as prior period, unchanged from 0001327567-23-000032:notes:99]

[0001327567-24-000005:notes:130]
The following table summarizes the RSU and PSU activity under our stock plans during the six months ended January 31, 2024 (in millions, except per share amounts):

[0001327567-24-000005:notes:131]
|  | RSUs Outstanding |  | PSUs Outstanding |
|  | Number of Shares |  | Weighted-Average Grant-Date Fair Value Per Share |  |  |  | Aggregate Intrinsic Value |  | Number of Shares |  | Weighted-Average Grant-Date Fair Value Per Share |  |  |  | Aggregate Intrinsic Value |
| Balance—July 31, 2023 | 12.1 |  |  | $ | 142.61 |  |  |  |  | $ | 3,013.0 |  |  | 5.0 |  |  | $ | 128.64 |  |  |  |  | $ | 1,242.3 |  |
| Granted(1) | 3.2 |  |  | $ | 264.04 |  |  |  |  |  |  | 2.1 |  |  | $ | 184.74 |  |  |  |  |  |
| Vested | (2.9) |  |  | $ | 127.17 |  |  |  |  |  |  | (0.8) |  |  | $ | 147.02 |  |  |  |  |  |
| Forfeited | (0.7) |  |  | $ | 153.46 |  |  |  |  |  |  | (0.4) |  |  | $ | 136.05 |  |  |  |  |  |
| Balance—January 31, 2024 | 11.7 |  |  | $ | 179.68 |  |  |  |  | $ | 3,973.8 |  |  | 5.9 |  |  | $ | 146.39 |  |  |  |  | $ | 1,982.8 |  |

[0001327567-24-000005:notes:132]
[same as prior period, unchanged from 0001327567-23-000032:notes:102]

[0001327567-24-000005:notes:133]
[same as prior period, unchanged from 0001327567-23-000032:notes:103]

[0001327567-24-000005:notes:134]
[same as prior period, unchanged from 0001327567-23-000032:notes:104]

[0001327567-24-000005:notes:135]
During the six months ended January 31, 2024, we granted 2.1 million shares of PSUs that contain service, performance, and market conditions, of which 0.1 million shares were granted during the three months ended January 31, 2024. The service conditions are satisfied after a period of one to three years. The performance conditions are based on revenue growth or billing growth. The market condition is measured based on our total shareholder return (“TSR”) relative to the TSR of the companies listed in the Standard & Poor’s 500 index. As of January 31, 2024, we have approved 2.7 million shares of PSUs, which will be granted upon the performance condition being established during the next two fiscal years.

[0001327567-24-000005:notes:136]
The fair value of the PSUs subject to market conditions is estimated on the grant date using a Monte Carlo simulation model. The following table summarizes the assumptions used and the resulting grant-date fair value of our PSUs subject to market conditions granted during the three and six months ended January 31, 2024:

[0001327567-24-000005:notes:137]
|  | Three Months Ended January 31, 2024 |  |  |  | Six Months Ended January 31, 2024 |  |  |
| Volatility | 40.9% |  |  |  | 40.8% - 43.4% |  |  |
| Expected term (in years) | 2.7 |  |  |  | 0.9 - 2.9 |  |  |
| Dividend yield | 0.0 | % |  |  |  | 0.0 | % |  |  |
| Risk-free interest rate | 4.5% |  |  |  | 4.5% - 5.3% |  |  |
| Grant-date fair value per share | $348.03 |  |  |  | $346.92 - $394.63 |  |  |

[0001327567-24-000005:notes:138]
[same as prior period, unchanged from 0001327567-23-000032:notes:108]

[0001327567-24-000005:notes:139]
We have granted PSOs with both service and market conditions. The market conditions were achieved when certain stock price targets were met. As of January 31, 2024, all of our outstanding PSOs have been fully vested. The maximum contractual term of our outstanding PSOs is seven and a half years from the date of grant in fiscal year 2018 and 2019.

[0001327567-24-000005:notes:140]
The following table summarizes the PSO activity under our stock plans during the six months ended January 31, 2024 (in millions, except per share amounts):

[0001327567-24-000005:notes:141]
|  |  |  |  |  |  |  |  |  | Number of Shares |  | Weighted-Average Exercise Price Per Share |  | Weighted-Average Remaining Contractual Term (Years) |  | Aggregate Intrinsic Value |
| Balance—July 31, 2023 |  |  |  |  |  |  |  |  | 6.4 |  |  | $ | 65.20 |  |  | 2.2 |  | $ | 1,184.6 |  |
| Exercised |  |  |  |  |  |  |  |  | (1.0) |  |  | $ | 64.94 |  |  |  |  |  |
| Balance—January 31, 2024 |  |  |  |  |  |  |  |  | 5.4 |  |  | $ | 65.25 |  |  | 1.7 |  | $ | 1,482.7 |  |
| Exercisable—January 31, 2024 |  |  |  |  |  |  |  |  | 5.4 |  |  | $ | 65.25 |  |  | 1.7 |  | $ | 1,482.7 |  |

[0001327567-24-000005:notes:142]
[same as prior period, unchanged from 0001327567-23-000032:notes:112]

[0001327567-24-000005:notes:143]
[same as prior period, unchanged from 0001327567-23-000032:notes:113]

[0001327567-24-000005:notes:144]
|  | Three Months Ended January 31, |  | Six Months Ended January 31, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Cost of product revenue | $ | 2.3 |  |  | $ | 2.6 |  |  | $ | 4.7 |  |  | $ | 5.0 |  |
| Cost of subscription and support revenue | 30.7 |  |  | 30.7 |  |  | 61.3 |  |  | 59.5 |  |
| Research and development | 138.6 |  |  | 129.7 |  |  | 258.7 |  |  | 247.7 |  |
| Sales and marketing | 75.6 |  |  | 88.4 |  |  | 154.8 |  |  | 175.8 |  |
| General and administrative | 28.1 |  |  | 38.5 |  |  | 66.8 |  |  | 67.9 |  |
| Total share-based compensation | $ | 275.3 |  |  | $ | 289.9 |  |  | $ | 546.3 |  |  | $ | 555.9 |  |

[0001327567-24-000005:notes:145]
As of January 31, 2024, total compensation cost related to unvested share-based awards not yet recognized was $2.3 billion. This cost is expected to be amortized over a weighted-average period of approximately 2.8 years.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001327567-24-000005:notes:146]
Income Taxes
For the three and six months ended January 31, 2024, our benefit from income taxes reflected an effective tax rate of negative 1,189.2% and negative 364.3%, respectively. Our effective tax rates for the three and six months ended January 31, 2024 differed from the U.S. statutory tax rate primarily due to the release of our valuation allowance.

[0001327567-24-000005:notes:147]
We regularly assess the need for a valuation allowance on our deferred tax assets. In making this assessment, we consider both positive and negative evidence related to the likelihood of realization of the deferred tax assets to determine, based on the weight of available evidence, whether it is more likely than not that some or all the deferred tax assets will not be realized. As of January 31, 2024, based on our analysis of all positive and negative evidence, we concluded it is more likely than not that our U.S. federal, U.S. states other than California, and United Kingdom deferred tax assets will be realizable based on our recent profitability and continued forecasted income. We continue to maintain a valuation allowance for our California deferred tax assets due to the uncertainty regarding realizability of these deferred tax assets as they have not met the “more likely than not” realization criterion. As a result of the valuation allowance release, we recognized a deferred tax benefit of $3.2 billion for the U.S. federal, U.S. states other than California, and United Kingdom deferred tax assets. In addition, we recognized a deferred tax expense of $1.7 billion for the U.S. federal indirect tax effect of foreign deferred taxes. Accordingly, during the three and six months ended January 31, 2024, we recognized a net tax benefit of $1.5 billion relating to our valuation allowance release. We will continue to monitor the need for a valuation allowance on our deferred tax assets.

[0001327567-24-000005:notes:148]
For the three and six months ended January 31, 2023, our provision for income taxes reflected an effective tax rate of 0.2% and 12.3%, respectively. Our income taxes for the three and six months ended January 31, 2023 were primarily due to U.S. federal and state income taxes, withholding taxes, and foreign income taxes. Our effective tax rates differed from the U.S. statutory tax rate primarily due to an increase in current taxes driven by capitalization of research and development expenditures with no offsetting deferred benefit as a result of our valuation allowance. This increase was offset by a tax benefit from a release of tax reserves related to uncertain tax positions resulting from an agreement with a non-U.S. tax authority to pay $28.9 million to settle a tax audit during the three months ended January 31, 2023.


## us-gaap:EarningsPerShareTextBlock

[0001327567-24-000005:notes:149]
Net Income Per Share
Basic net income per share is computed by dividing net income by basic weighted-average shares outstanding during the period. Diluted net income per share is computed by dividing net income by diluted weighted-average shares outstanding during the period giving effect to all potentially dilutive securities to the extent they are dilutive. Potentially dilutive securities include shares issuable upon conversion of our convertible senior notes using the if-converted method, warrants related to the issuance of convertible senior notes, and equity awards under our employee equity incentive plans using the treasury stock method.

[0001327567-24-000005:notes:150]
The following table presents the computation of basic and diluted net income per share of common stock (in millions, except per share data):

[0001327567-24-000005:notes:151]
|  | Three Months Ended January 31, |  | Six Months Ended January 31, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Net income | $ | 1,746.9 |  |  | $ | 84.2 |  |  | $ | 1,941.1 |  |  | $ | 104.2 |  |
| Weighted-average shares used to compute net income per share, basic | 319.6 |  |  | 302.3 |  |  | 314.9 |  |  | 301.0 |  |
| Weighted-average effect of potentially dilutive securities: |  |  |  |  |  |  |  |
| Convertible senior notes | 13.0 |  |  | 15.2 |  |  | 12.3 |  |  | 16.5 |  |
| Warrants related to the issuance of convertible senior notes | 12.6 |  |  | 4.1 |  |  | 14.3 |  |  | 6.0 |  |
| Employee equity incentive plans | 12.3 |  |  | 10.0 |  |  | 12.2 |  |  | 11.5 |  |
| Weighted-average shares used to compute net income per share, diluted | 357.5 |  |  | 331.6 |  |  | 353.7 |  |  | 335.0 |  |
| Net income per share, basic | $ | 5.47 |  |  | $ | 0.28 |  |  | $ | 6.16 |  |  | $ | 0.35 |  |
| Net income per share, diluted | $ | 4.89 |  |  | $ | 0.25 |  |  | $ | 5.49 |  |  | $ | 0.31 |  |

[0001327567-24-000005:notes:152]
[same as prior period, unchanged from 0001327567-23-000032:notes:121]

[0001327567-24-000005:notes:153]
|  | Three Months Ended January 31, |  | Six Months Ended January 31, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Employee equity incentive plans | 2.4 |  |  | 8.9 |  |  | 2.5 |  |  | 5.8 |  |


## us-gaap:OtherNonoperatingIncomeAndExpenseTextBlock

[0001327567-24-000005:notes:154]
[same as prior period, unchanged from 0001327567-23-000032:notes:123]

[0001327567-24-000005:notes:155]
|  | Three Months Ended January 31, |  | Six Months Ended January 31, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Interest income | $ | 85.3 |  |  | $ | 56.6 |  |  | $ | 156.5 |  |  | $ | 86.0 |  |
| Foreign currency exchange gains (losses), net | (6.5) |  |  | (7.3) |  |  | (1.4) |  |  | (2.9) |  |
| Other, net | 5.9 |  |  | 2.1 |  |  | (0.1) |  |  | (5.7) |  |
| Total other income, net | $ | 84.7 |  |  | $ | 51.4 |  |  | $ | 155.0 |  |  | $ | 77.4 |  |


## us-gaap:SubsequentEventsTextBlock

[0001327567-24-000005:notes:156]
Subsequent Event
2025 Notes Conversion

[0001327567-24-000005:notes:157]
Subsequent to January 31, 2024, $581.0 million in aggregate principal amount of the 2025 Notes was converted or had been submitted by the holders for conversion and will settle during the fiscal quarter ending April 30, 2024.


## ecd:MtrlTermsOfTrdArrTextBlock

[0001327567-24-000005:notes:158]
Set forth below is certain information regarding Rule 10b5-1 trading plans adopted or terminated by our directors and officers (as defined in Rule 16a-1(f)) during the second quarter of fiscal 2024. The Rule 10b5-1 trading plans listed below are each intended to satisfy the affirmative defense of Rule 10b5-1(c).

[0001327567-24-000005:notes:159]
| Name |  | Title |  | Date Plan Was Adopted |  | Date Plan was Terminated |  | Expiration Date |  | Total Amount of Common Stock to be Sold Under the Plan |
| Nikesh Arora |  | Chief Executive Officer |  | June 8, 2023 |  | December 13, 2023 |  | Not applicable |  | 2,000,000 |
| John Donovan |  | Director |  | October 8, 2023 |  | Not applicable |  | December 31, 2025 or when all shares have been sold |  | 126,312 |
| Lee Klarich |  | Executive Vice President, Chief Product Officer |  | November 22, 2023 |  | Not applicable |  | January 18, 2025 or when all shares have been sold |  | 920,000 |
| Joshua Paul |  | Senior Vice President, Chief Accounting Officer |  | December 7, 2023 |  | Not applicable |  | December 3, 2024 or when all shares have been sold |  | 2,600 |
