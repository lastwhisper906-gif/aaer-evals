# PANW MD&A — 0001327567-24-000005


## mdna

[0001327567-24-000005:mdna:1]
[same as prior period, unchanged from 0001327567-23-000032:mdna:1]

[0001327567-24-000005:mdna:2]
[same as prior period, unchanged from 0001327567-23-000032:mdna:2]

[0001327567-24-000005:mdna:3]
[same as prior period, unchanged from 0001327567-23-000032:mdna:3]

[0001327567-24-000005:mdna:4]
[same as prior period, unchanged from 0001327567-23-000032:mdna:4]

[0001327567-24-000005:mdna:5]
•Results of Operations. A discussion of the nature and trends in our financial results and an analysis of our financial results comparing the three and six months ended January 31, 2024 to the three and six months ended January 31, 2023.

[0001327567-24-000005:mdna:6]
[same as prior period, unchanged from 0001327567-23-000032:mdna:6]

[0001327567-24-000005:mdna:7]
[same as prior period, unchanged from 0001327567-23-000032:mdna:7]

[0001327567-24-000005:mdna:8]
•Recent Accounting Pronouncements. A discussion of expected impacts of impending accounting changes on financial information to be reported in the future.

[0001327567-24-000005:mdna:9]
[same as prior period, unchanged from 0001327567-23-000032:mdna:29]

[0001327567-24-000005:mdna:10]
[same as prior period, unchanged from 0001327567-23-000032:mdna:9]

[0001327567-24-000005:mdna:11]
[same as prior period, unchanged from 0001327567-23-000032:mdna:10]

[0001327567-24-000005:mdna:12]
[same as prior period, unchanged from 0001327567-23-000032:mdna:11]

[0001327567-24-000005:mdna:13]
•Our network security platform, designed to deliver complete zero trust solutions to our customers, includes our hardware and software ML-Powered Next-Generation Firewalls, as well as a cloud-delivered Secure Access Service Edge (“SASE”). Prisma® Access, our Security Services Edge (“SSE”) solution, when combined with Prisma SD-WAN, provides a comprehensive single-vendor SASE offering that is used to secure remote workforces and enable the cloud-delivered branch. We have been recognized as a leader in network firewalls, SASE, SSE, and SD-WAN. Our network security platform also includes our cloud-delivered security services, such as Advanced Threat Prevention, Advanced WildFire®, Advanced URL Filtering, DNS Security, IoT/OT Security, GlobalProtect®, Enterprise Data Loss Prevention (“Enterprise DLP”), Artificial Intelligence for IT Operations (“AIOps”), SaaS Security API, and SaaS Security Inline. Through these add-on security services, our customers are able to secure their content, applications, users, and devices across their entire organization. Strata Cloud Manager, our network security management solution, can centrally manage our network security platform irrespective of form factor, location, or scale.

[0001327567-24-000005:mdna:14]
[same as prior period, unchanged from 0001327567-23-000032:mdna:13]

[0001327567-24-000005:mdna:15]
•We enable cloud-native security through our Prisma Cloud Code to CloudTM platform. As a comprehensive Cloud Native Application Protection Platform (“CNAPP”), Prisma Cloud secures multi- and hybrid-cloud environments for applications, data, and the entire cloud native technology stack across the full development lifecycle, from code to runtime. We also offer our VM-Series and CN-Series virtual firewalls for inline network security on multi- and hybrid-cloud environments.

[0001327567-24-000005:mdna:16]
[same as prior period, unchanged from 0001327567-23-000032:mdna:15]

[0001327567-24-000005:mdna:17]
•We deliver the next generation of security automation, security analytics, endpoint security, and attack surface management solutions through our Cortex portfolio. These include Cortex XSIAM, our AI-driven security operations platform, Cortex XDR® for the prevention, detection, and response to complex cybersecurity attacks on the endpoint, Cortex XSOAR® for security orchestration, automation, and response (“SOAR”), and Cortex XpanseTM for attack surface management (“ASM”). These products are delivered as SaaS or software subscriptions.

[0001327567-24-000005:mdna:18]
Threat Intelligence and Advisory Services (Unit 42):

[0001327567-24-000005:mdna:19]
•Unit 42 brings together world-renowned threat researchers with an elite team of incident responders and security consultants to create an intelligence-driven, response-ready organization to help customers manage cyber risk. Our consultants serve as trusted advisors to our customers by assessing and testing their security controls against the right threats, transforming their security strategy with a threat-informed approach, and responding to security incidents on behalf of our clients. Additionally, Unit 42 offers managed detection and response services and managed threat hunting services.

[0001327567-24-000005:mdna:20]
For the second quarter of fiscal 2024 and 2023, total revenue was $2.0 billion and $1.7 billion, respectively, representing year-over-year growth of 19.3%. Our growth reflects the increased adoption of our portfolio, which consists of product, subscriptions, and support. We believe our portfolio will enable us to benefit from recurring revenues and new revenues as we continue to grow our end-customer base. As of January 31, 2024, we had end-customers in over 180 countries. Our end-customers represent a broad range of industries, including education, energy, financial services, government entities, healthcare, Internet and media, manufacturing, public sector, and telecommunications, and include almost all of the Fortune 100 companies and a majority of the Global 2000 companies. We maintain a field sales force that works closely with our channel partners in developing sales opportunities. We primarily use a two-tiered, indirect fulfillment model whereby we sell our products, subscriptions, and support to our distributors, which, in turn, sell to our resellers, which then sell to our end-customers.

[0001327567-24-000005:mdna:21]
[same as prior period, unchanged from 0001327567-23-000032:mdna:37]

[0001327567-24-000005:mdna:22]
Our product revenue grew to $390.7 million, or 19.8% of total revenue, for the second quarter of fiscal 2024, representing year-over-year growth of 10.7%. Product revenue is derived from sales of our appliances, primarily our ML-Powered Next-Generation Firewall. Product revenue also includes revenue derived from software licenses of Panorama®, SD-WAN, and the VM-Series. Our ML-Powered Next-Generation Firewall incorporates our PAN-OS operating system, which provides a consistent set of capabilities across our entire network security product line. Our appliances and software licenses include a broad set of built-in networking and security features and functionalities. Our products are designed for different performance requirements throughout an organization, ranging from our PA-410, which is designed for small organizations and remote or branch offices, to our top-of-the-line PA-7080, which is designed for large-scale data centers and service provider use. The same firewall functionality that is delivered in our physical appliances is also available in our VM-Series virtual firewalls, which secure virtualized and cloud-based computing environments, and in our CN-Series container firewalls, which secure container environments and traffic.

[0001327567-24-000005:mdna:23]
Our subscription and support revenue grew to $1.6 billion, or 80.2% of total revenue, for the second quarter of fiscal 2024, representing year-over-year growth of 21.7%. Our subscriptions provide our end-customers with near real-time access to the latest antivirus, intrusion prevention, web filtering, modern malware prevention, data loss prevention, and cloud access security broker capabilities across the network, endpoints, and the cloud. When end-customers purchase our physical, virtual, or container firewall appliances, or certain cloud offerings, they typically purchase support in order to receive ongoing security updates, upgrades, bug fixes, and repairs. In addition to the subscriptions purchased with these appliances, end-customers may also purchase other subscriptions on a per-user, per-endpoint, or capacity-based basis. We also offer professional services, including incident response, risk management, and digital forensic services.

[0001327567-24-000005:mdna:24]
We continue to invest in innovation as we evolve and further extend the capabilities of our portfolio, as we believe that innovation and timely development of new features and products are essential to meeting the needs of our end-customers and improving our competitive position. For example, in November 2023, we announced PAN-OS 11.1 Cosmos which will help our customers stay ahead of attackers and centrally manage and operate their network security estate. We also introduced Cortex XSIAM 2.0 which includes a new bring-your-own machine learning framework to enable customers to add their own custom Artificial Intelligence (“AI”) models on the XSIAM data lake.

[0001327567-24-000005:mdna:25]
[same as prior period, unchanged from 0001327567-23-000032:mdna:24]

[0001327567-24-000005:mdna:26]
[same as prior period, unchanged from 0001327567-23-000032:mdna:25]

[0001327567-24-000005:mdna:27]
[same as prior period, unchanged from 0001327567-23-000032:mdna:26]

[0001327567-24-000005:mdna:28]
The hostilities in Israel and the surrounding region have increased the levels of economic and political uncertainty. While we have business operations in Israel, and intend to continue growing our presence in Israel, we currently do not expect significant business disruption. We are actively monitoring, evaluating, and responding to the developing situation.

[0001327567-24-000005:mdna:29]
[same as prior period, unchanged from 0001327567-23-000032:mdna:28]

[0001327567-24-000005:mdna:30]
[same as prior period, unchanged from 0001327567-23-000032:mdna:41]

[0001327567-24-000005:mdna:31]
[same as prior period, unchanged from 0001327567-23-000032:mdna:30]

[0001327567-24-000005:mdna:32]
[same as prior period, unchanged from 0001327567-23-000032:mdna:31]

[0001327567-24-000005:mdna:33]
|  | January 31, 2024 |  | July 31, 2023 |
|  | (in millions) |
| Total deferred revenue | $ | 9,818.4 |  |  | $ | 9,296.4 |  |
| Cash, cash equivalents, and investments | $ | 6,990.6 |  |  | $ | 5,437.9 |  |

[0001327567-24-000005:mdna:34]
|  | Three Months Ended January 31, |  | Six Months Ended January 31, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
|  | (dollars in millions) |
| Total revenue | $ | 1,975.1 |  |  | $ | 1,655.1 |  |  | $ | 3,853.2 |  |  | $ | 3,218.5 |  |
| Total revenue year-over-year percentage increase | 19.3 | % |  | 25.7 | % |  | 19.7 | % |  | 25.5 | % |
| Gross margin | 74.7 | % |  | 71.8 | % |  | 74.8 | % |  | 71.2 | % |
| Operating income | $ | 53.6 |  |  | $ | 39.9 |  |  | $ | 268.8 |  |  | $ | 55.1 |  |
| Operating margin | 2.7 | % |  | 2.4 | % |  | 7.0 | % |  | 1.7 | % |
| Billings | $ | 2,347.2 |  |  | $ | 2,029.1 |  |  | $ | 4,371.7 |  |  | $ | 3,778.1 |  |
| Billings year-over-year percentage increase | 15.7 | % |  | 26.2 | % |  | 15.7 | % |  | 26.4 | % |
| Cash flow provided by operating activities |  |  |  |  | $ | 2,216.0 |  |  | $ | 1,931.3 |  |
| Free cash flow (non-GAAP) |  |  |  |  | $ | 2,144.0 |  |  | $ | 1,853.4 |  |

[0001327567-24-000005:mdna:35]
[same as prior period, unchanged from 0001327567-23-000032:mdna:34]

[0001327567-24-000005:mdna:36]
[same as prior period, unchanged from 0001327567-23-000032:mdna:35]

[0001327567-24-000005:mdna:37]
|  | Three Months Ended January 31, |  | Six Months Ended January 31, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
|  | (in millions) |
| Billings: |  |  |  |  |  |  |  |
| Total revenue | $ | 1,975.1 |  |  | $ | 1,655.1 |  |  | $ | 3,853.2 |  |  | $ | 3,218.5 |  |
| Add: change in total deferred revenue, net of acquired deferred revenue | 372.1 |  |  | 374.0 |  |  | 518.5 |  |  | 559.6 |  |
| Billings | $ | 2,347.2 |  |  | $ | 2,029.1 |  |  | $ | 4,371.7 |  |  | $ | 3,778.1 |  |

[0001327567-24-000005:mdna:38]
[same as prior period, unchanged from 0001327567-23-000032:mdna:47]

[0001327567-24-000005:mdna:39]
•Cash Flow Provided by Operating Activities. We monitor cash flow provided by operating activities as a measure of our overall business performance. Our cash flow provided by operating activities is driven in large part by sales of our products and from up-front payments for subscription and support offerings. Monitoring cash flow provided by operating activities enables us to analyze our financial performance without the non-cash effects of certain items such as share-based compensation costs, depreciation, and amortization, thereby allowing us to better understand and manage the cash needs of our business.

[0001327567-24-000005:mdna:40]
[same as prior period, unchanged from 0001327567-23-000032:mdna:39]

[0001327567-24-000005:mdna:41]
|  | Six Months Ended January 31, |
|  | 2024 |  | 2023 |
|  | (in millions) |
| Free cash flow (non-GAAP): |  |  |  |
| Net cash provided by operating activities | $ | 2,216.0 |  |  | $ | 1,931.3 |  |
| Less: purchases of property, equipment, and other assets | 72.0 |  |  | 77.9 |  |
| Free cash flow (non-GAAP) | $ | 2,144.0 |  |  | $ | 1,853.4 |  |
| Net cash used in investing activities | $ | (1,454.5) |  |  | $ | (2,484.3) |  |
| Net cash used in financing activities | $ | (114.4) |  |  | $ | (219.7) |  |

[0001327567-24-000005:mdna:42]
[same as prior period, unchanged from 0001327567-23-000032:mdna:58]

[0001327567-24-000005:mdna:43]
[same as prior period, unchanged from 0001327567-23-000032:mdna:42]

[0001327567-24-000005:mdna:44]
[same as prior period, unchanged from 0001327567-23-000032:mdna:43]

[0001327567-24-000005:mdna:45]
|  | Three Months Ended January 31, |  | Six Months Ended January 31, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
|  | Amount |  | % of Revenue |  | Amount |  | % of Revenue |  | Amount |  | % of Revenue |  | Amount |  | % of Revenue |
|  | (dollars in millions) |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 390.7 |  |  | 19.8 | % |  | $ | 352.9 |  |  | 21.3 | % |  | $ | 731.8 |  |  | 19.0 | % |  | $ | 682.9 |  |  | 21.2 | % |
| Subscription and support | 1,584.4 |  |  | 80.2 | % |  | 1,302.2 |  |  | 78.7 | % |  | 3,121.4 |  |  | 81.0 | % |  | 2,535.6 |  |  | 78.8 | % |
| Total revenue | 1,975.1 |  |  | 100.0 | % |  | 1,655.1 |  |  | 100.0 | % |  | 3,853.2 |  |  | 100.0 | % |  | 3,218.5 |  |  | 100.0 | % |
| Cost of revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product | 88.2 |  |  | 4.5 | % |  | 100.5 |  |  | 6.1 | % |  | 165.6 |  |  | 4.3 | % |  | 220.6 |  |  | 6.9 | % |
| Subscription and support | 410.9 |  |  | 20.8 | % |  | 365.7 |  |  | 22.1 | % |  | 806.3 |  |  | 20.9 | % |  | 707.5 |  |  | 21.9 | % |
| Total cost of revenue(1) | 499.1 |  |  | 25.3 | % |  | 466.2 |  |  | 28.2 | % |  | 971.9 |  |  | 25.2 | % |  | 928.1 |  |  | 28.8 | % |
| Total gross profit | 1,476.0 |  |  | 74.7 | % |  | 1,188.9 |  |  | 71.8 | % |  | 2,881.3 |  |  | 74.8 | % |  | 2,290.4 |  |  | 71.2 | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | 447.9 |  |  | 22.7 | % |  | 404.1 |  |  | 24.4 | % |  | 857.4 |  |  | 22.3 | % |  | 775.9 |  |  | 24.1 | % |
| Sales and marketing | 673.0 |  |  | 34.0 | % |  | 625.5 |  |  | 37.8 | % |  | 1,333.5 |  |  | 34.6 | % |  | 1,240.5 |  |  | 38.6 | % |
| General and administrative | 301.5 |  |  | 15.3 | % |  | 119.4 |  |  | 7.2 | % |  | 421.6 |  |  | 10.9 | % |  | 218.9 |  |  | 6.8 | % |
| Total operating expenses(1) | 1,422.4 |  |  | 72.0 | % |  | 1,149.0 |  |  | 69.4 | % |  | 2,612.5 |  |  | 67.8 | % |  | 2,235.3 |  |  | 69.5 | % |
| Operating income | 53.6 |  |  | 2.7 | % |  | 39.9 |  |  | 2.4 | % |  | 268.8 |  |  | 7.0 | % |  | 55.1 |  |  | 1.7 | % |
| Interest expense | (2.8) |  |  | (0.1 | %) |  | (6.9) |  |  | (0.4) | % |  | (5.7) |  |  | (0.1 | %) |  | (13.7) |  |  | (0.4) | % |
| Other income, net | 84.7 |  |  | 4.3 | % |  | 51.4 |  |  | 3.1 | % |  | 155.0 |  |  | 4.0 | % |  | 77.4 |  |  | 2.4 | % |
| Income before income taxes | 135.5 |  |  | 6.9 | % |  | 84.4 |  |  | 5.1 | % |  | 418.1 |  |  | 10.9 | % |  | 118.8 |  |  | 3.7 | % |
| Provision for (benefit from) income taxes | (1,611.4) |  |  | (81.5 | %) |  | 0.2 |  |  | — | % |  | (1,523.0) |  |  | (39.5 | %) |  | 14.6 |  |  | 0.5 | % |
| Net income | $ | 1,746.9 |  |  | 88.4 | % |  | $ | 84.2 |  |  | 5.1 | % |  | $ | 1,941.1 |  |  | 50.4 | % |  | $ | 104.2 |  |  | 3.2 | % |

[0001327567-24-000005:mdna:46]
Includes share-based compensation as follows:

[0001327567-24-000005:mdna:47]
|  | Three Months Ended January 31, |  | Six Months Ended January 31, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
|  | (in millions) |
| Cost of product revenue | $ | 2.3 |  |  | $ | 2.6 |  |  | $ | 4.7 |  |  | $ | 5.0 |  |
| Cost of subscription and support revenue | 30.7 |  |  | 30.7 |  |  | 61.3 |  |  | 59.5 |  |
| Research and development | 138.6 |  |  | 129.7 |  |  | 258.7 |  |  | 247.7 |  |
| Sales and marketing | 75.6 |  |  | 88.4 |  |  | 154.8 |  |  | 175.8 |  |
| General and administrative | 28.1 |  |  | 38.5 |  |  | 66.8 |  |  | 67.9 |  |
| Total share-based compensation | $ | 275.3 |  |  | $ | 289.9 |  |  | $ | 546.3 |  |  | $ | 555.9 |  |

[0001327567-24-000005:mdna:48]
[same as prior period, unchanged from 0001327567-23-000032:mdna:68]

[0001327567-24-000005:mdna:49]
[same as prior period, unchanged from 0001327567-23-000032:mdna:48]

[0001327567-24-000005:mdna:50]
[same as prior period, unchanged from 0001327567-23-000032:mdna:49]

[0001327567-24-000005:mdna:51]
[same as prior period, unchanged from 0001327567-23-000032:mdna:50]

[0001327567-24-000005:mdna:52]
[same as prior period, unchanged from 0001327567-23-000032:mdna:51]

[0001327567-24-000005:mdna:53]
|  | Three Months Ended January 31, |  |  |  |  |  | Six Months Ended January 31, |  |  |  |  |
|  | 2024 |  | 2023 |  | Change |  | 2024 |  | 2023 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Product | $ | 390.7 |  |  | $ | 352.9 |  |  | $ | 37.8 |  |  | 10.7 | % |  | $ | 731.8 |  |  | $ | 682.9 |  |  | $ | 48.9 |  |  | 7.2 | % |

[0001327567-24-000005:mdna:54]
Product revenue for the three and six months ended January 31, 2024 increased compared to the same periods in 2023 driven by increased software revenue primarily due to a go-to-market strategy for certain Network Security offerings, and increased demand for our new generation of hardware products, partially offset by decreased revenue from our prior generation of hardware products.

[0001327567-24-000005:mdna:55]
[same as prior period, unchanged from 0001327567-23-000032:mdna:54]

[0001327567-24-000005:mdna:56]
[same as prior period, unchanged from 0001327567-23-000032:mdna:55]

[0001327567-24-000005:mdna:57]
|  | Three Months Ended January 31, |  |  |  |  |  | Six Months Ended January 31, |  |  |  |  |
|  | 2024 |  | 2023 |  | Change |  | 2024 |  | 2023 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Subscription | $ | 1,027.1 |  |  | $ | 815.4 |  |  | $ | 211.7 |  |  | 26.0 | % |  | $ | 2,015.4 |  |  | $ | 1,579.4 |  |  | $ | 436.0 |  |  | 27.6 | % |
| Support | 557.3 |  |  | 486.8 |  |  | 70.5 |  |  | 14.5 | % |  | 1,106.0 |  |  | 956.2 |  |  | 149.8 |  |  | 15.7 | % |
| Total subscription and support | $ | 1,584.4 |  |  | $ | 1,302.2 |  |  | $ | 282.2 |  |  | 21.7 | % |  | $ | 3,121.4 |  |  | $ | 2,535.6 |  |  | $ | 585.8 |  |  | 23.1 | % |

[0001327567-24-000005:mdna:58]
Subscription and support revenue increased for the three and six months ended January 31, 2024 compared to the same periods in 2023 primarily due to increased demand for our subscription and support offerings from our end-customers. The mix between subscription revenue and support revenue will fluctuate over time, depending on the introduction of new subscription offerings, renewals of support services, and our ability to increase sales to new and existing end-customers.

[0001327567-24-000005:mdna:59]
[same as prior period, unchanged from 0001327567-23-000032:mdna:80]

[0001327567-24-000005:mdna:60]
[same as prior period, unchanged from 0001327567-23-000032:mdna:59]

[0001327567-24-000005:mdna:61]
|  | Three Months Ended January 31, |  |  |  |  |  | Six Months Ended January 31, |  |  |  |  |
|  | 2024 |  | 2023 |  | Change |  | 2024 |  | 2023 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Americas | $ | 1,334.2 |  |  | $ | 1,117.0 |  |  | $ | 217.2 |  |  | 19.4 | % |  | $ | 2,620.8 |  |  | $ | 2,187.7 |  |  | $ | 433.1 |  |  | 19.8 | % |
| EMEA | 406.8 |  |  | 341.5 |  |  | 65.3 |  |  | 19.1 | % |  | 771.7 |  |  | 649.4 |  |  | 122.3 |  |  | 18.8 | % |
| APAC | 234.1 |  |  | 196.6 |  |  | 37.5 |  |  | 19.1 | % |  | 460.7 |  |  | 381.4 |  |  | 79.3 |  |  | 20.8 | % |
| Total revenue | $ | 1,975.1 |  |  | $ | 1,655.1 |  |  | $ | 320.0 |  |  | 19.3 | % |  | $ | 3,853.2 |  |  | $ | 3,218.5 |  |  | $ | 634.7 |  |  | 19.7 | % |

[0001327567-24-000005:mdna:62]
Revenue from the Americas, Europe, the Middle East, and Africa (“EMEA”), and Asia Pacific and Japan (“APAC”), increased for the three and six months ended January 31, 2024 compared to the same periods in 2023 as we continued to increase investment in our global sales force in order to support our growth and innovation. Our three geographic theaters had similar year-over-year revenue growth rates for the three and six months ended January 31, 2024 compared to the same periods in 2023, with the Americas contributing the highest increase in revenue due to its larger scale.

[0001327567-24-000005:mdna:63]
[same as prior period, unchanged from 0001327567-23-000032:mdna:62]

[0001327567-24-000005:mdna:64]
[same as prior period, unchanged from 0001327567-23-000032:mdna:63]

[0001327567-24-000005:mdna:65]
[same as prior period, unchanged from 0001327567-23-000032:mdna:64]

[0001327567-24-000005:mdna:66]
[same as prior period, unchanged from 0001327567-23-000032:mdna:65]

[0001327567-24-000005:mdna:67]
|  | Three Months Ended January 31, |  |  |  |  |  | Six Months Ended January 31, |  |  |  |  |
|  | 2024 |  | 2023 |  | Change |  | 2024 |  | 2023 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Cost of product revenue | $ | 88.2 |  |  | $ | 100.5 |  |  | $ | (12.3) |  |  | (12.2) | % |  | $ | 165.6 |  |  | $ | 220.6 |  |  | $ | (55.0) |  |  | (24.9) | % |

[0001327567-24-000005:mdna:68]
Cost of product revenue decreased for the three and six months ended January 31, 2024 compared to the same periods in 2023 primarily due to decreased demand for our prior generation of hardware products and lower costs largely driven by an easing of supply chain challenges, partially offset by increased demand for our new generation hardware products.

[0001327567-24-000005:mdna:69]
[same as prior period, unchanged from 0001327567-23-000032:mdna:93]

[0001327567-24-000005:mdna:70]
[same as prior period, unchanged from 0001327567-23-000032:mdna:69]

[0001327567-24-000005:mdna:71]
[same as prior period, unchanged from 0001327567-23-000032:mdna:70]

[0001327567-24-000005:mdna:72]
|  | Three Months Ended January 31, |  |  |  |  |  | Six Months Ended January 31, |  |  |  |  |
|  | 2024 |  | 2023 |  | Change |  | 2024 |  | 2023 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Cost of subscription and support revenue | $ | 410.9 |  |  | $ | 365.7 |  |  | $ | 45.2 |  |  | 12.4 | % |  | $ | 806.3 |  |  | $ | 707.5 |  |  | $ | 98.8 |  |  | 14.0 | % |

[0001327567-24-000005:mdna:73]
Cost of subscription and support revenue increased for the three and six months ended January 31, 2024 compared to the same periods in 2023 primarily due to increased costs to support the growth of our subscription and support offerings. Cloud hosting service costs, which support our cloud-based subscription offerings, increased $22.2 million for the three months ended January 31, 2024 compared to the same period in 2023, and increased $48.4 million for the six months ended January 31, 2024 compared to the same period in 2023. Personnel costs grew $9.9 million for the three months ended January 31, 2024 compared to the same period in 2023, and grew $32.9 million for the six months ended January 31, 2024 compared to the same period in 2023, primarily due to headcount growth.

[0001327567-24-000005:mdna:74]
[same as prior period, unchanged from 0001327567-23-000032:mdna:73]

[0001327567-24-000005:mdna:75]
[same as prior period, unchanged from 0001327567-23-000032:mdna:74]

[0001327567-24-000005:mdna:76]
|  | Three Months Ended January 31, |  | Six Months Ended January 31, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
|  | Amount |  | Gross Margin |  | Amount |  | Gross Margin |  | Amount |  | Gross Margin |  | Amount |  | Gross Margin |
|  | (dollars in millions) |
| Product | $ | 302.5 |  |  | 77.4 | % |  | $ | 252.4 |  |  | 71.5 | % |  | $ | 566.2 |  |  | 77.4 | % |  | $ | 462.3 |  |  | 67.7 | % |
| Subscription and support | 1,173.5 |  |  | 74.1 | % |  | 936.5 |  |  | 71.9 | % |  | 2,315.1 |  |  | 74.2 | % |  | 1,828.1 |  |  | 72.1 | % |
| Total gross profit | $ | 1,476.0 |  |  | 74.7 | % |  | $ | 1,188.9 |  |  | 71.8 | % |  | $ | 2,881.3 |  |  | 74.8 | % |  | $ | 2,290.4 |  |  | 71.2 | % |

[0001327567-24-000005:mdna:77]
Product gross margin increased for the three and six months ended January 31, 2024 compared to the same periods in 2023 primarily due to lower costs largely driven by an easing of supply chain challenges and increased software revenue.

[0001327567-24-000005:mdna:78]
Subscription and support gross margin increased for the three and six months ended January 31, 2024 compared to the same periods in 2023 primarily due to our growth in subscription and support revenue, which outpaced the subscription and support costs.

[0001327567-24-000005:mdna:79]
[same as prior period, unchanged from 0001327567-23-000032:mdna:106]

[0001327567-24-000005:mdna:80]
[same as prior period, unchanged from 0001327567-23-000032:mdna:78]

[0001327567-24-000005:mdna:81]
Our operating expenses consist of research and development, sales and marketing, and general and administrative expenses. Personnel costs are the most significant component of operating expenses and consist of salaries, benefits, bonuses, share-based compensation, travel and entertainment, and with regard to sales and marketing expense, sales commissions. Our operating expenses also include shared costs, which consist of certain facilities, depreciation, benefits, recruiting, and information technology costs that we allocate based on headcount to each department. We expect operating expenses generally to increase in absolute dollars and to decrease over the long term as a percentage of revenue as we continue to scale our business. As of January 31, 2024, we expect to recognize approximately $2.3 billion of share-based compensation expense over a weighted-average period of approximately 2.8 years, excluding additional share-based compensation expense related to any future grants of share-based awards. Share-based compensation expense is generally recognized on a straight-line basis over the requisite service periods of the awards.

[0001327567-24-000005:mdna:82]
[same as prior period, unchanged from 0001327567-23-000032:mdna:81]

[0001327567-24-000005:mdna:83]
[same as prior period, unchanged from 0001327567-23-000032:mdna:82]

[0001327567-24-000005:mdna:84]
|  | Three Months Ended January 31, |  |  |  |  |  | Six Months Ended January 31, |  |  |  |  |
|  | 2024 |  | 2023 |  | Change |  | 2024 |  | 2023 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Research and development | $ | 447.9 |  |  | $ | 404.1 |  |  | $ | 43.8 |  |  | 10.8 | % |  | $ | 857.4 |  |  | $ | 775.9 |  |  | $ | 81.5 |  |  | 10.5 | % |

[0001327567-24-000005:mdna:85]
Research and development expense increased for the three and six months ended January 31, 2024 compared to the same periods in 2023 primarily due to increased personnel costs, which grew $34.3 million for the three months ended January 31, 2024 compared to the same period in 2023, and grew $61.7 million for the six months ended January 31, 2024 compared to the same period in 2023, largely due to headcount growth.

[0001327567-24-000005:mdna:86]
[same as prior period, unchanged from 0001327567-23-000032:mdna:85]

[0001327567-24-000005:mdna:87]
[same as prior period, unchanged from 0001327567-23-000032:mdna:86]

[0001327567-24-000005:mdna:88]
|  | Three Months Ended January 31, |  |  |  |  |  | Six Months Ended January 31, |  |  |  |  |
|  | 2024 |  | 2023 |  | Change |  | 2024 |  | 2023 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Sales and marketing | $ | 673.0 |  |  | $ | 625.5 |  |  | $ | 47.5 |  |  | 7.6 | % |  | $ | 1,333.5 |  |  | $ | 1,240.5 |  |  | $ | 93.0 |  |  | 7.5 | % |

[0001327567-24-000005:mdna:89]
Sales and marketing expense increased for the three and six months ended January 31, 2024 compared to the same periods in 2023 primarily due to increased costs associated with sales and marketing events and go-to-market initiatives, which grew $33.8 million for the three months ended January 31, 2024 compared to the same period in 2023, and grew $61.4 million for the six months ended January 31, 2024 compared to the same period in 2023. The remaining increases in both periods were primarily driven by increased personnel costs, largely due to headcount growth.

[0001327567-24-000005:mdna:90]
[same as prior period, unchanged from 0001327567-23-000032:mdna:116]

[0001327567-24-000005:mdna:91]
[same as prior period, unchanged from 0001327567-23-000032:mdna:89]

[0001327567-24-000005:mdna:92]
[same as prior period, unchanged from 0001327567-23-000032:mdna:90]

[0001327567-24-000005:mdna:93]
|  | Three Months Ended January 31, |  |  |  |  |  | Six Months Ended January 31, |  |  |  |  |
|  | 2024 |  | 2023 |  | Change |  | 2024 |  | 2023 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| General and administrative | $ | 301.5 |  |  | $ | 119.4 |  |  | $ | 182.1 |  |  | 152.5 | % |  | $ | 421.6 |  |  | $ | 218.9 |  |  | $ | 202.7 |  |  | 92.6 | % |

[0001327567-24-000005:mdna:94]
General and administrative expense increased for the three and six months ended January 31, 2024 compared to the same periods in 2023 primarily due to a litigation accrual of $176.8 million during the three months ended January 31, 2024 relating to an ongoing patent infringement lawsuit.

[0001327567-24-000005:mdna:95]
[same as prior period, unchanged from 0001327567-23-000032:mdna:94]

[0001327567-24-000005:mdna:96]
Interest expense primarily consists of interest expense related to our 0.75% Convertible Senior Notes due 2023 (the “2023 Notes”) and our 0.375% Convertible Senior Notes due 2025 (the “2025 Notes,” and together with “2023 Notes,” the “Notes”).

[0001327567-24-000005:mdna:97]
|  | Three Months Ended January 31, |  |  |  | Six Months Ended January 31, |  |  |
|  | 2024 |  | 2023 |  | Change |  | 2024 |  | 2023 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Interest expense | $ | 2.8 |  |  | $ | 6.9 |  |  | $ | (4.1) |  |  | (59.4) | % |  | $ | 5.7 |  |  | $ | 13.7 |  |  | $ | (8.0) |  |  | (58.4) | % |

[0001327567-24-000005:mdna:98]
Interest expense decreased for the three and six months ended January 31, 2024 compared to the same periods in 2023 primarily due to conversions of the 2023 Notes prior to or upon maturity in July 2023. Refer to Note 9. Debt in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information on the Notes.

[0001327567-24-000005:mdna:99]
[same as prior period, unchanged from 0001327567-23-000032:mdna:98]

[0001327567-24-000005:mdna:100]
[same as prior period, unchanged from 0001327567-23-000032:mdna:99]

[0001327567-24-000005:mdna:101]
|  | Three Months Ended January 31, |  |  |  | Six Months Ended January 31, |  |  |
|  | 2024 |  | 2023 |  | Change |  | 2024 |  | 2023 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Other income, net | $ | 84.7 |  |  | $ | 51.4 |  |  | $ | 33.3 |  |  | 64.8 | % |  | $ | 155.0 |  |  | $ | 77.4 |  |  | $ | 77.6 |  |  | 100.3 | % |

[0001327567-24-000005:mdna:102]
Other income, net increased for the three and six months ended January 31, 2024 compared to the same periods in 2023 primarily due to higher interest income as a result of higher interest rates and higher average cash, cash equivalent, and investment balances for the three and six months ended January 31, 2024 compared to the same periods in 2023.

[0001327567-24-000005:mdna:103]
[same as prior period, unchanged from 0001327567-23-000032:mdna:130]

[0001327567-24-000005:mdna:104]
PROVISION FOR (BENEFIT FROM) INCOME TAXES

[0001327567-24-000005:mdna:105]
Provision for (benefit from) income taxes consists primarily of U.S. taxes, foreign income taxes, and withholding taxes. Our provision for income taxes was offset by tax benefits from the release of our valuation allowance on U.S. federal, U.S. states other than California, and United Kingdom deferred tax assets. A portion of our valuation allowance release is included in our estimated annual effective tax rate. Accordingly, we will continue to realize related tax benefits for the remainder of fiscal 2024, in amounts much less than that recorded during the three and six months ended January 31, 2024. We continue to maintain a valuation allowance for California and certain foreign deferred tax assets, including net operating loss carryforwards and certain domestic tax credits.

[0001327567-24-000005:mdna:106]
|  | Three Months Ended January 31, |  |  |  |  |  | Six Months Ended January 31, |  |  |  |  |
|  | 2024 |  | 2023 |  | Change |  | 2024 |  | 2023 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Provision for (benefit from) income taxes | $ | (1,611.4) |  |  | $ | 0.2 |  |  | $ | (1,611.6) |  |  | * |  | $ | (1,523.0) |  |  | $ | 14.6 |  |  | $ | (1,537.6) |  |  | * |
| Effective tax rate | (1,189.2 | %) |  | 0.2 | % |  |  |  |  |  | (364.3 | %) |  | 12.3 | % |  |  |  |  |

[0001327567-24-000005:mdna:107]
*    Not meaningful

[0001327567-24-000005:mdna:108]
Our benefit from income taxes for the three and six months ended January 31, 2024 was primarily driven by the release of our valuation allowance on U.S. federal, U.S. states other than California, and United Kingdom deferred tax assets. Refer to Note 13. Income Taxes in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information.

[0001327567-24-000005:mdna:109]
[same as prior period, unchanged from 0001327567-23-000032:mdna:107]

[0001327567-24-000005:mdna:110]
|  | January 31, 2024 |  | July 31, 2023 |
|  | (in millions) |
| Working capital(1) | $ | (1,318.8) |  |  | $ | (1,689.5) |  |
| Cash, cash equivalents, and investments: |  |  |  |
| Cash and cash equivalents | $ | 1,782.5 |  |  | $ | 1,135.3 |  |
| Investments | 5,208.1 |  |  | 4,302.6 |  |
| Total cash, cash equivalents, and investments | $ | 6,990.6 |  |  | $ | 5,437.9 |  |

[0001327567-24-000005:mdna:111]
(1)Current liabilities included net carrying amounts of convertible senior notes of $1.8 billion and $2.0 billion as of January 31, 2024 and July 31, 2023, respectively. Refer to Note 9. Debt in Part I, Item 1 of this Quarterly Report on Form 10-Q for information on the Notes.

[0001327567-24-000005:mdna:112]
As of January 31, 2024, our total cash, cash equivalents, and investments of $7.0 billion were held for general corporate purposes. As of January 31, 2024, we had no unremitted earnings when evaluating our outside basis difference relating to our U.S. investment in foreign subsidiaries. However, there could be local withholding taxes due to various foreign countries if certain lower tier earnings are distributed. Withholding taxes that would be payable upon remittance of these lower tier earnings are not expected to be material.

[0001327567-24-000005:mdna:113]
Beginning in fiscal 2023, we were required to capitalize and amortize research and development expenses as required by the Tax Cuts and Jobs Act. As a result of this change, we have paid significantly more U.S. cash taxes during the six months ended January 31, 2024.

[0001327567-24-000005:mdna:114]
- 34 -

[0001327567-24-000005:mdna:115]
[same as prior period, unchanged from 0001327567-23-000032:mdna:112]

[0001327567-24-000005:mdna:116]
In June 2020, we issued the 2025 Notes with an aggregate principal amount of $2.0 billion. The 2025 Notes mature on June 1, 2025; however, under certain circumstances, holders may surrender their 2025 Notes for conversion prior to the maturity date. Upon conversion of the 2025 Notes, we will pay cash equal to the aggregate principal amount of the 2025 Notes to be converted, and, at our election, we will pay or deliver cash and/or shares of our common stock for the amount of our conversion obligation in excess of the aggregate principal amount of the 2025 Notes being converted. During the three and six months ended January 31, 2024, holders of the 2025 Notes converted $126.3 million and $172.3 million, respectively, in aggregate principal amount of the 2025 Notes, which we repaid in cash. We also issued 0.8 million and 1.1 million shares of our common stock to the holders of the 2025 Notes during the three and six months ended January 31, 2024, respectively, for the conversion value in excess of the principal amount of the 2025 Notes converted, which were fully offset by shares we received from the corresponding exercise of the associated note hedges. Subsequent to January 31, 2024, through the filing date of this Quarterly Report on Form 10-Q, $581.0 million in aggregate principal amount of the 2025 Notes was converted or had been submitted by the holders for conversion and will settle during the fiscal quarter ending April 30, 2024.

[0001327567-24-000005:mdna:117]
The sale price condition for the 2025 Notes was met during the fiscal quarter ended January 31, 2024, and as a result, holders may convert their 2025 Notes during the fiscal quarter ending April 30, 2024. If all of the holders convert their 2025 Notes during this period, we would be obligated to settle the $1.8 billion principal amount of the 2025 Notes in cash. We believe that our cash provided by operating activities, our existing cash, cash equivalents, and investments, and existing sources of and access to financing will be sufficient to meet our anticipated cash needs should the holders choose to convert their 2025 Notes during the fiscal quarter ending April 30, 2024 or hold the 2025 Notes until maturity on June 1, 2025. As of January 31, 2024, $1.8 billion of our 2025 Notes remained outstanding. Refer to Note 9. Debt in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information on the Notes.

[0001327567-24-000005:mdna:118]
In April 2023, we entered into a credit agreement (the “Credit Agreement”) that provides for a $400.0 million unsecured revolving credit facility (the “Credit Facility”), with an option to increase the amount of the Credit Facility by up to an additional $350.0 million, subject to certain conditions. The interest rates and commitment fees are also subject to upward and downward adjustments based on our progress towards the achievement of certain sustainability goals related to greenhouse gas emissions. As of January 31, 2024, there were no amounts outstanding, and we were in compliance with all covenants under the Credit Agreement. Refer to Note 9. Debt in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information on the Credit Agreement.

[0001327567-24-000005:mdna:119]
[same as prior period, unchanged from 0001327567-23-000032:mdna:117]

[0001327567-24-000005:mdna:120]
In February 2019, our board of directors authorized a $1.0 billion share repurchase program. In December 2020, August 2021, August 2022, and November 2023, our board of directors authorized additional $700.0 million, $676.1 million, $915.0 million, and $316.7 million increases to this share repurchase program, respectively, bringing the total authorization under this share repurchase program to $3.6 billion. Repurchases will be funded from available working capital and may be made at management’s discretion from time to time. As of January 31, 2024, $1.0 billion remained available for future share repurchases under this repurchase program. The repurchase authorization will expire on December 31, 2024, and may be suspended or discontinued at any time without prior notice. Refer to Note 11. Stockholders’ Equity in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information on this repurchase program.

[0001327567-24-000005:mdna:121]
[same as prior period, unchanged from 0001327567-23-000032:mdna:119]

[0001327567-24-000005:mdna:122]
We have entered into various non-cancelable operating leases, primarily for our facilities, with original lease periods expiring through the fiscal year ending July 31, 2036, with the most significant leases relating to our corporate headquarters in Santa Clara, California. As of January 31, 2024, we have total operating lease obligations of $427.8 million recorded on our condensed consolidated balance sheet.

[0001327567-24-000005:mdna:123]
As of January 31, 2024, our commitments to purchase products, components, cloud and other services totaled $5.2 billion. Refer to Note 10. Commitments and Contingencies in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information on these commitments.

[0001327567-24-000005:mdna:124]
- 35 -

[0001327567-24-000005:mdna:125]
[same as prior period, unchanged from 0001327567-23-000032:mdna:122]

[0001327567-24-000005:mdna:126]
The following table summarizes our cash flows for the six months ended January 31, 2024 and 2023:

[0001327567-24-000005:mdna:127]
|  | Six Months Ended January 31, |
|  | 2024 |  | 2023 |
|  | (in millions) |
| Net cash provided by operating activities | $ | 2,216.0 |  |  | $ | 1,931.3 |  |
| Net cash used in investing activities | (1,454.5) |  |  | (2,484.3) |  |
| Net cash used in financing activities | (114.4) |  |  | (219.7) |  |
| Net increase (decrease) in cash, cash equivalents, and restricted cash | $ | 647.1 |  |  | $ | (772.7) |  |

[0001327567-24-000005:mdna:128]
Cash from operations could be affected by various risks and uncertainties detailed in Part II, Item 1A “Risk Factors” in this Quarterly Report on Form 10-Q. We believe that our cash flow from operations with existing cash and cash equivalents will be sufficient to meet our anticipated cash needs for at least the next 12 months and thereafter for the foreseeable future. Our future capital requirements will depend on many factors, including our growth rate, the timing and extent of spending to support development efforts, the expansion of sales and marketing activities, the introduction of new and enhanced products and subscription and support offerings, the costs to acquire or invest in complementary businesses and technologies, the costs to ensure access to adequate manufacturing capacity, the investments in our infrastructure to support the adoption of our cloud-based subscription offerings, the repayment obligations associated with our 2025 Notes, the continuing market acceptance of our products and subscription and support offerings and macroeconomic events. In addition, from time to time, we may incur additional tax liability in connection with certain corporate structuring decisions.

[0001327567-24-000005:mdna:129]
[same as prior period, unchanged from 0001327567-23-000032:mdna:126]

[0001327567-24-000005:mdna:130]
[same as prior period, unchanged from 0001327567-23-000032:mdna:127]

[0001327567-24-000005:mdna:131]
[same as prior period, unchanged from 0001327567-23-000032:mdna:128]

[0001327567-24-000005:mdna:132]
Cash provided by operating activities during the six months ended January 31, 2024 was $2.2 billion, an increase of $284.7 million compared to the same period in 2023. The increase was primarily due to growth of our business as reflected by increases in collections during the six months ended January 31, 2024, partially offset by higher cash expenditure to support our business growth.

[0001327567-24-000005:mdna:133]
[same as prior period, unchanged from 0001327567-23-000032:mdna:131]

[0001327567-24-000005:mdna:134]
[same as prior period, unchanged from 0001327567-23-000032:mdna:132]

[0001327567-24-000005:mdna:135]
Cash used in investing activities during the six months ended January 31, 2024 was $1.5 billion, a decrease of $1.0 billion compared to the same period in 2023. The decrease was primarily due to a decrease in purchases of investments, partially offset by an increase in net cash payments for business acquisitions during the six months ended January 31, 2024.

[0001327567-24-000005:mdna:136]
[same as prior period, unchanged from 0001327567-23-000032:mdna:134]

[0001327567-24-000005:mdna:137]
[same as prior period, unchanged from 0001327567-23-000032:mdna:135]

[0001327567-24-000005:mdna:138]
Cash used in financing activities during the six months ended January 31, 2024 was $114.4 million, a decrease of $105.3 million compared to the same period in 2023. The decrease was primarily due to a decrease in cash used to repurchase our common stock, partially offset by early repayments of our 2025 Notes during the six months ended January 31, 2024.

[0001327567-24-000005:mdna:139]
- 36 -

[0001327567-24-000005:mdna:140]
[same as prior period, unchanged from 0001327567-23-000032:mdna:137]

[0001327567-24-000005:mdna:141]
[same as prior period, unchanged from 0001327567-23-000032:mdna:138]

[0001327567-24-000005:mdna:142]
[same as prior period, unchanged from 0001327567-23-000032:mdna:139]

[0001327567-24-000005:mdna:143]
Recent Accounting Pronouncements

[0001327567-24-000005:mdna:144]
Refer to “Recently Issued Accounting Pronouncements” in Note 1. Description of Business and Summary of Significant Accounting Policies in Part I, Item 1 of this Quarterly Report on Form 10-Q for a description of recent accounting pronouncements and our expectation of their impact, if any, on our results of operations and financial condition.
