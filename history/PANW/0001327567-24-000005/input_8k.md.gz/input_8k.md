# PANW 8-K — 0001327567-24-000003 filed 2024-02-20

## item codes, every 8-K on or before 2024-02-21

- 2024-02-20 0001327567-24-000003 — 2.02, 9.01
- 2023-12-14 0001193125-23-295527 — 5.02, 5.07, 9.01
- 2023-11-29 0001193125-23-285277 — 8.01, 9.01
- 2023-11-17 0001327567-23-000035 — 8.01, 9.01
- 2023-11-15 0001327567-23-000030 — 2.02, 9.01
- 2023-11-15 0001193125-23-277318 — 8.01
- 2023-08-18 0001327567-23-000020 — 2.02, 9.01
- 2023-06-08 0001193125-23-163506 — 7.01, 9.01
- 2023-06-05 0001193125-23-160228 — 7.01
- 2023-05-23 0001327567-23-000012 — 2.02, 9.01
- 2023-04-19 0001327567-23-000009 — 1.01, 2.03, 9.01
- 2023-02-21 0001327567-23-000005 — 2.02, 9.01
- 2022-12-16 0001193125-22-307346 — 5.02, 5.07
- 2022-11-17 0001327567-22-000035 — 2.02, 9.01
- 2022-11-15 0001193125-22-285017 — 8.01
- 2022-08-22 0001327567-22-000020 — 2.02, 8.01, 9.01
- 2022-05-23 0001193125-22-157474 — 5.02, 5.03, 9.01
- 2022-05-19 0001327567-22-000014 — 2.02, 9.01
- 2022-02-23 0001193125-22-049906 — 5.02
- 2022-02-22 0001327567-22-000006 — 2.02, 9.01
- 2021-12-15 0001193125-21-358074 — 5.02, 5.07
- 2021-11-18 0001327567-21-000037 — 2.02, 9.01
- 2021-10-12 0001193125-21-296438 — 3.01, 7.01, 9.01
- 2021-09-13 0001193125-21-270979 — 7.01, 9.01
- 2021-09-08 0001193125-21-267862 — 5.02, 9.01
- 2021-08-23 0001327567-21-000020 — 2.02, 9.01
- 2021-08-12 0001193125-21-244832 — 5.02, 9.01
- 2021-05-20 0001327567-21-000012 — 2.02, 9.01
- 2021-05-18 0001193125-21-164169 — 5.02 — amendment of 0001193125-21-162161
- 2021-05-14 0001193125-21-162161 — 5.02, 9.01
- 2021-03-19 0001193125-21-087516 — 5.02, 9.01
- 2021-02-22 0001628280-21-002659 — 2.02, 9.01
- 2021-02-22 0001193125-21-049293 — 5.02, 9.01
- 2020-12-18 0001193125-20-321568 — 8.01, 9.01
- 2020-12-16 0001193125-20-319091 — 3.02 — amendment of 0001193125-20-291707
- 2020-12-10 0001193125-20-314920 — 5.07
- 2020-12-08 0001193125-20-312056 — 5.02, 8.01, 9.01
- 2020-11-16 0001327567-20-000037 — 2.02, 9.01
- 2020-11-12 0001193125-20-291707 — 3.02
- 2020-10-19 0001193125-20-272060 — 5.02
- 2020-08-24 0001327567-20-000025 — 2.02, 9.01
- 2020-06-23 0001193125-20-176553 — 5.02, 9.01
- 2020-06-22 0001193125-20-175603 — 5.02, 9.01
- 2020-06-08 0001193125-20-163579 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2020-05-21 0001327567-20-000015 — 2.02, 9.01
- 2020-02-27 0001193125-20-050335 — 1.01, 2.03
- 2020-02-24 0001327567-20-000002 — 2.02, 9.01
- 2019-12-19 0001193125-19-319166 — 1.02, 9.01
- 2019-12-10 0001193125-19-310251 — 5.07
- 2019-11-25 0001327567-19-000036 — 2.02, 9.01
- 2019-11-25 0001193125-19-299886 — 5.02, 8.01 — amendment of 0001327567-19-000011
- 2019-10-22 0001193125-19-271660 — 5.02
- 2019-09-06 0001327567-19-000026 — 9.01 — amendment of 0001327567-19-000023
- 2019-09-04 0001327567-19-000023 — 2.02, 7.01, 9.01
- 2019-07-11 0001193125-19-192415 — 5.02, 9.01
- 2019-05-29 0001327567-19-000014 — 2.02, 9.01
- 2019-04-15 0001327567-19-000011 — 5.02, 9.01
- 2019-04-01 0001193125-19-094613 — 8.01, 9.01
- 2019-03-28 0001193125-19-090572 — 3.02 — amendment of 0001327567-19-000003
- 2019-02-26 0001327567-19-000006 — 2.02, 8.01, 9.01
- 2019-02-19 0001327567-19-000003 — 3.02
- 2018-12-11 0001327567-18-000033 — 5.07
- 2018-11-29 0001327567-18-000029 — 2.02, 9.01
- 2018-10-15 0001193125-18-299312 — 5.02, 9.01
- 2018-09-25 0001193125-18-282542 — 5.02
- 2018-09-14 0001193125-18-274239 — 5.03, 9.01
- 2018-09-06 0001327567-18-000018 — 1.01, 2.02, 2.03, 9.01
- 2018-07-13 0001193125-18-217281 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2018-06-04 0001327567-18-000011 — 2.02, 5.02, 9.01
- 2018-02-26 0001327567-18-000004 — 2.02, 5.02, 7.01, 9.01
- 2017-12-12 0001193125-17-367477 — 5.07
- 2017-11-20 0001327567-17-000032 — 2.02, 5.02, 9.01
- 2017-08-31 0001327567-17-000021 — 2.02, 5.02, 9.01
- 2017-05-31 0001327567-17-000016 — 2.02, 9.01
- 2017-02-28 0001327567-17-000005 — 2.02, 8.01, 9.01
- 2016-12-12 0001193125-16-790757 — 5.07
- 2016-11-21 0001327567-16-000071 — 2.02, 9.01
- 2016-10-24 0001193125-16-745121 — 5.02, 9.01
- 2016-08-30 0001327567-16-000057 — 2.02, 5.03, 8.01, 9.01
- 2016-08-22 0001193125-16-687588 — 5.02, 9.01
- 2016-05-26 0001327567-16-000051 — 2.02, 9.01
- 2016-02-25 0001327567-16-000044 — 2.02, 5.02, 9.01
- 2015-12-14 0001327567-15-000038 — 5.07
- 2015-12-14 0001193125-15-402588 — 1.01, 9.01
- 2015-11-23 0001327567-15-000033 — 2.02, 9.01
- 2015-10-19 0001193125-15-347005 — 1.01, 9.01 — amendment, the index does not say of what
- 2015-09-09 0001327567-15-000022 — 2.02, 9.01
- 2015-08-19 0001193125-15-296115 — 1.01, 2.03
- 2015-06-01 0001193125-15-207786 — 1.01, 2.03
- 2015-05-27 0001327567-15-000015 — 2.02, 9.01
- 2015-03-02 0001327567-15-000006 — 2.02, 9.01
- 2014-12-15 0001327567-14-000046 — 5.07
- 2014-11-24 0001327567-14-000040 — 2.02, 9.01
- 2014-09-22 0001193125-14-348581 — 5.02, 9.01
- 2014-09-09 0001327567-14-000025 — 2.02, 9.01
- 2014-07-01 0001193125-14-257824 — 1.01, 2.03, 3.02, 9.01
- 2014-06-26 0001193125-14-249529 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2014-06-20 0001327567-14-000020 — 9.01 — amendment of 0001193125-14-140511
- 2014-06-04 0001327567-14-000016 — 3.02
- 2014-05-30 0001193125-14-218158 — 2.02 — amendment, the index does not say of what
- 2014-05-28 0001193125-14-215060 — 1.01, 2.02, 3.02, 9.01
- 2014-04-11 0001193125-14-140511 — 2.01, 3.02, 7.01, 9.01
- 2014-03-24 0001193125-14-111318 — 1.01, 3.02, 7.01, 9.01
- 2014-03-13 0001327567-14-000009 — 5.02
- 2014-02-24 0001193125-14-063754 — 2.02, 9.01
- 2013-12-12 0001327567-13-000040 — 5.07
- 2013-11-25 0001327567-13-000033 — 2.02, 9.01
- 2013-09-30 0001193125-13-384966 — 8.01
- 2013-09-09 0001193125-13-361421 — 2.02, 9.01
- 2013-05-30 0001193125-13-241542 — 2.02, 5.02, 9.01
- 2013-03-11 0001193125-13-101082 — 5.02, 9.01
- 2013-02-28 0001193125-13-084193 — 2.02, 9.01
- 2012-12-14 0001193125-12-503335 — 5.07
- 2012-12-06 0001193125-12-493700 — 2.02, 9.01
- 2012-09-24 0001193125-12-401534 — 1.01, 2.03
- 2012-09-20 0001193125-12-398433 — 5.02, 9.01
- 2012-09-10 0001193125-12-386605 — 2.02, 9.01

## late-filing notifications on or before 2024-02-21

- none on or before 2024-02-21

## item 2.02 — earnings release, exhibit 99.1

[0001327567-24-000003:8k_2_02:1]
EX-99.1
2
ex991q224earningsrelease.htm
EX-99.1

[0001327567-24-000003:8k_2_02:2]
Document

[0001327567-24-000003:8k_2_02:3]
Exhibit 99.1

[0001327567-24-000003:8k_2_02:4]
Palo Alto Networks Reports Fiscal Second Quarter 2024 Financial Results

[0001327567-24-000003:8k_2_02:5]
•Fiscal second quarter revenue grew 19% year over year to $2.0 billion

[0001327567-24-000003:8k_2_02:6]
•Remaining performance obligation grew 22% year over year to $10.8 billion

[0001327567-24-000003:8k_2_02:7]
•Non-GAAP operating margin grew 580 bps year over year to 29%

[0001327567-24-000003:8k_2_02:8]
SANTA CLARA, Calif., Feb. 20, 2024 — Palo Alto Networks (NASDAQ: PANW), the global cybersecurity leader, announced today financial results for its fiscal second quarter 2024, ended January 31, 2024.

[0001327567-24-000003:8k_2_02:9]
Total revenue for the fiscal second quarter 2024 grew 19% year over year to $2.0 billion, compared with total revenue of $1.7 billion for the fiscal second quarter 2023. GAAP net income for the fiscal second quarter 2024 was $1.7 billion, or $4.89 per diluted share, compared with GAAP net income of $0.1 billion, or $0.25 per diluted share, for the fiscal second quarter 2023. GAAP net income for the fiscal second quarter 2024 included a $1.5 billion net tax benefit from a release of the company’s valuation allowance.

[0001327567-24-000003:8k_2_02:10]
Non-GAAP net income for the fiscal second quarter 2024 was $0.5 billion, or $1.46 per diluted share, compared with non-GAAP net income of $0.3 billion, or $1.05 per diluted share, for the fiscal second quarter 2023. A reconciliation between GAAP and non-GAAP information is contained in the tables below.

[0001327567-24-000003:8k_2_02:11]
“Our leadership across all of our three platforms and growing cross-platform adoption puts us in a strong and unique position,”  said Nikesh Arora, chairman and CEO of Palo Alto Networks. "With this backdrop, we are activating our accelerated platformization and consolidation strategy, as well as our AI leadership strategy."

[0001327567-24-000003:8k_2_02:12]
“Our disciplined execution on profitable growth gives us the confidence to maintain FY’24 non-GAAP EPS and free cash flow guidance, while making significant additional investments in our platformization and consolidation strategies to accelerate our long-term growth trajectory,” said Dipak Golechha, chief financial officer of Palo Alto Networks.

[0001327567-24-000003:8k_2_02:13]
Financial Outlook

[0001327567-24-000003:8k_2_02:14]
Palo Alto Networks provides guidance based on current market conditions and expectations.

[0001327567-24-000003:8k_2_02:15]
For the fiscal third quarter 2024, we expect:

[0001327567-24-000003:8k_2_02:16]
•Total billings in the range of $2.30 billion to $2.35 billion, representing year-over-year growth of between 2% and 4%.

[0001327567-24-000003:8k_2_02:17]
•Total revenue in the range of $1.95 billion to $1.98 billion, representing year-over-year growth of between 13% and 15%.

[0001327567-24-000003:8k_2_02:18]
•Diluted non-GAAP net income per share in the range of $1.24 to $1.26, using 347 million to 351 million shares outstanding.

[0001327567-24-000003:8k_2_02:19]
For the fiscal year 2024, we are updating guidance and expect:

[0001327567-24-000003:8k_2_02:20]
•Total billings in the range of $10.10 billion to $10.20 billion, representing year-over-year growth of between 10% and 11%.

[0001327567-24-000003:8k_2_02:21]
•Total revenue in the range of $7.95 billion to $8.00 billion, representing year-over-year growth of between 15% and 16%.

[0001327567-24-000003:8k_2_02:22]
•Non-GAAP operating margin in the range of 26.5% to 27.0%.

[0001327567-24-000003:8k_2_02:23]
•Diluted non-GAAP net income per share in the range of $5.45 to $5.55, using 345 million to 347 million shares outstanding.

[0001327567-24-000003:8k_2_02:24]
•Adjusted free cash flow margin in the range of 38.0% to 39.0%.

[0001327567-24-000003:8k_2_02:25]
Guidance for non-GAAP financial measures excludes share-based compensation-related charges, including share-based payroll tax expense, acquisition-related costs, amortization expense of acquired intangible assets, litigation-related charges, including legal settlements, restructuring and other costs, non-cash charges related to convertible notes, foreign currency gains (losses), and income tax and other tax adjustments related to our long-term non-GAAP effective tax rate, along with certain non-recurring expenses and certain non-recurring cash flows. We have not reconciled diluted non-GAAP net income per share guidance to GAAP net income per diluted share or adjusted free cash flow margin guidance to GAAP net cash from operating activities because we do not provide guidance on GAAP net income or net cash from operating activities and would not be able to present the various reconciling cash and non-cash items between GAAP and non-GAAP financial measures because certain items that impact these measures are uncertain or out of our control, or cannot be reasonably predicted, including share-based compensation expense, without unreasonable effort. The actual amounts of such reconciling items will have a significant impact on the company's GAAP net income per diluted share and GAAP net cash from operating activities.

[0001327567-24-000003:8k_2_02:26]
Earnings Call Information

[0001327567-24-000003:8k_2_02:27]
Palo Alto Networks will host a video webcast for analysts and investors to discuss the company’s fiscal second quarter 2024 results as well as the outlook for its fiscal third quarter and fiscal year 2024 today at 4:30 p.m. Eastern time/1:30 p.m. Pacific time. Open to the public, investors may access the webcast, supplemental financial information and earnings slides from the “Investors” section of the company’s website at investors.paloaltonetworks.com. A replay will be available three hours after the conclusion of the webcast and archived for one year.

[0001327567-24-000003:8k_2_02:28]
Forward-Looking Statements

[0001327567-24-000003:8k_2_02:29]
This press release contains forward-looking statements that involve risks, uncertainties, and assumptions including statements regarding our financial outlook for the fiscal third quarter 2024 and fiscal year 2024. There are a significant number of factors that could cause actual results to differ materially from statements made in this press release, including: developments and changes in general market, political, economic, and business conditions; risks associated with managing our growth; risks associated with new products and subscription and support offerings; shifts in priorities or delays in the development or release of new offerings, or the failure to timely develop and achieve market acceptance of new products and subscriptions as well as existing products and subscription and support offerings; failure of our business strategies; rapidly evolving technological developments in the market for security products and subscription and support offerings; our customers’ purchasing decisions and the length of sales cycles; our competition; our ability to attract and retain new customers; our ability to acquire and integrate other companies, products, or technologies in a successful manner; our debt repayment obligations; and our share repurchase program, which may not be fully consummated or enhance shareholder value, and any share repurchases which could affect the price of our common stock.

[0001327567-24-000003:8k_2_02:30]
Additional risks and uncertainties that could affect our financial results are included under the captions "Risk Factors" and "Management's Discussion and Analysis of Financial Condition and Results of Operations" in our Quarterly Report on Form 10-Q filed with the SEC on November 17, 2023, which is available on our website at investors.paloaltonetworks.com and on the SEC's website at www.sec.gov. Additional information will also be set forth in other filings that we make with the SEC from time to time. All forward-looking statements in this press release are based on information available to us as of the date hereof, and we do not assume any obligation to update the forward-looking statements provided to reflect events that occur or circumstances that exist after the date on which they were made.

[0001327567-24-000003:8k_2_02:31]
Non-GAAP Financial Measures and Other Key Metrics

[0001327567-24-000003:8k_2_02:32]
Palo Alto Networks has provided in this press release financial information that has not been prepared in accordance with generally accepted accounting principles in the United States (GAAP). The company uses these non-GAAP financial measures and other key metrics internally in analyzing its financial results and believes that the use of these non-GAAP financial measures and key metrics are helpful to investors as an additional tool to evaluate ongoing operating results and trends, and in comparing the company’s financial results with other companies in its industry, many of which present similar non-GAAP financial measures or key metrics.

[0001327567-24-000003:8k_2_02:33]
The presentation of these non-GAAP financial measures and key metrics are not meant to be considered in isolation or as a substitute for comparable GAAP financial measures and should be read only in conjunction with the company’s consolidated financial statements prepared in accordance with GAAP. A reconciliation of the company’s historical non-GAAP financial measures to their most directly comparable GAAP measures has been provided in the financial statement tables included in this press release, and investors are encouraged to review these reconciliations.

[0001327567-24-000003:8k_2_02:34]
Non-GAAP operating margin. Palo Alto Networks defines non-GAAP operating margin as non-GAAP operating income divided by total revenue. The company defines non-GAAP operating income as operating income plus share-based compensation-related charges, including share-based payroll tax expense, acquisition-related costs, amortization expense of acquired intangible assets, litigation-related charges, including legal settlements, and restructuring and other costs. The company believes that non-GAAP operating margin provides management and investors with greater visibility into the underlying performance of the company’s core business operating results.

[0001327567-24-000003:8k_2_02:35]
Non-GAAP net income and net income per share, diluted. Palo Alto Networks defines non-GAAP net income as net income plus share-based compensation-related charges, including share-based payroll tax expense, acquisition-related costs, amortization expense of acquired intangible assets, litigation-related charges, including legal settlements, restructuring and other costs, and non-cash charges related to convertible notes. The company also excludes from non-GAAP net income foreign currency gains (losses) and tax adjustments related to our long-term non-GAAP effective tax rate in order to provide a complete picture of the company’s recurring core business operating results. The company defines non-GAAP net income per share, diluted, as non-GAAP net income divided by the weighted-average diluted shares outstanding, which includes the potentially dilutive effect of the company’s employee equity incentive plan awards and the company’s convertible senior notes outstanding and related warrants, after giving effect to the anti-dilutive impact of the company’s note hedge agreements, which reduces the potential economic dilution that otherwise would occur upon conversion of the company’s convertible senior notes. Under GAAP, the anti-dilutive impact of the note hedge is not reflected in diluted shares outstanding. The company considers these non-GAAP financial measures to be useful metrics for management and investors for the same reasons that it uses non-GAAP operating margin.

[0001327567-24-000003:8k_2_02:36]
Billings. Palo Alto Networks defines billings as total revenue plus the change in total deferred revenue, net of acquired deferred revenue, during the period. The company considers billings to be a key metric used by management to manage the company’s business and believes billings provides investors with an important indicator of the health and visibility of the company’s business because it includes subscription and support revenue, which is recognized ratably over the contractual service period, and product revenue, which is recognized at the time of hardware shipment or delivery of software license, provided that all other conditions for revenue recognition have been met. The company considers billings to be a useful metric for management and investors, particularly if sales of subscriptions continue to increase and the company experiences strong renewal rates for subscriptions and support.

[0001327567-24-000003:8k_2_02:37]
Investors are cautioned that there are a number of limitations associated with the use of non-GAAP financial measures and key metrics as analytical tools. In particular, the billings metric reported by the company includes amounts that have not yet been recognized as revenue. Additionally, many of the adjustments to the company’s GAAP financial measures reflect the exclusion of items that are recurring and will be reflected in the company’s financial results for the foreseeable future, such as share-based compensation, which is an important part of Palo Alto Networks employees’ compensation and impacts their performance. Furthermore, these non-GAAP financial measures are not based on any standardized methodology prescribed by GAAP, and the components that Palo Alto Networks excludes in its calculation of non-GAAP financial measures may differ from the components that its peer companies exclude when they report their non-GAAP results of operations. Palo Alto Networks compensates for these limitations by providing specific information regarding the GAAP amounts excluded from these non-GAAP financial measures. In the future, the company may also exclude non-recurring expenses and other expenses that do not reflect the company’s core business operating results.

[0001327567-24-000003:8k_2_02:38]
About Palo Alto Networks

[0001327567-24-000003:8k_2_02:39]
Palo Alto Networks is the world’s cybersecurity leader. We innovate to outpace cyberthreats, so organizations can embrace technology with confidence. We provide next-gen cybersecurity to thousands of customers globally, across all sectors. Our best-in-class cybersecurity platforms and services are backed by industry-leading threat intelligence and strengthened by state-of-the-art automation. Whether deploying our products to enable the Zero Trust Enterprise, responding to a security incident, or partnering to deliver better security outcomes through a world-class partner ecosystem, we’re committed to helping ensure each day is safer than the one before. It’s what makes us the cybersecurity partner of choice.

[0001327567-24-000003:8k_2_02:40]
At Palo Alto Networks, we're committed to bringing together the very best people in service of our mission, so we're also proud to be the cybersecurity workplace of choice, recognized among Newsweek's Most Loved Workplaces (2023, 2022, 2021), with a score of 100 on the Disability Equality Index (2023, 2022), and HRC Best Places for LGBTQ Equality (2022). For more information, visit www.paloaltonetworks.com.

[0001327567-24-000003:8k_2_02:41]
Palo Alto Networks and the Palo Alto Networks logo are registered trademarks of Palo Alto Networks, Inc. in the United States and in jurisdictions throughout the world. All other trademarks, trade names, or service marks used or mentioned herein belong to their respective owners. Any unreleased services or features (and any services or features not generally available to customers) referenced in this or other press releases or public statements are not currently available (or are not yet generally available to customers) and may not be delivered when expected or at all. Customers who purchase Palo Alto Networks applications should make their purchase decisions based on services and features currently generally available.

[0001327567-24-000003:8k_2_02:42]
Media Contact:

[0001327567-24-000003:8k_2_02:43]
Sandra Wheatley

[0001327567-24-000003:8k_2_02:44]
SVP, Corporate Communications, Palo Alto Networks

[0001327567-24-000003:8k_2_02:45]
press@paloaltonetworks.com

[0001327567-24-000003:8k_2_02:46]
Investor Relations Contact:

[0001327567-24-000003:8k_2_02:47]
Ryan Fenwick

[0001327567-24-000003:8k_2_02:48]
Sr. Manager, Investor Relations, Palo Alto Networks

[0001327567-24-000003:8k_2_02:49]
ir@paloaltonetworks.com

[0001327567-24-000003:8k_2_02:50]
1

[0001327567-24-000003:8k_2_02:51]
| Palo Alto Networks, Inc. |
| Preliminary Condensed Consolidated Statements of Operations |
| (In millions, except per share data) |
| (Unaudited) |
|  | Three Months Ended |  | Six Months Ended |
|  | January 31, |  | January 31, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Revenue: |  |  |  |  |  |  |  |
| Product | $ | 390.7 |  |  | $ | 352.9 |  |  | $ | 731.8 |  |  | $ | 682.9 |  |
| Subscription and support | 1,584.4 |  |  | 1,302.2 |  |  | 3,121.4 |  |  | 2,535.6 |  |
| Total revenue | 1,975.1 |  |  | 1,655.1 |  |  | 3,853.2 |  |  | 3,218.5 |  |
| Cost of revenue: |  |  |  |  |  |  |  |
| Product | 88.2 |  |  | 100.5 |  |  | 165.6 |  |  | 220.6 |  |
| Subscription and support | 410.9 |  |  | 365.7 |  |  | 806.3 |  |  | 707.5 |  |
| Total cost of revenue | 499.1 |  |  | 466.2 |  |  | 971.9 |  |  | 928.1 |  |
| Total gross profit | 1,476.0 |  |  | 1,188.9 |  |  | 2,881.3 |  |  | 2,290.4 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 447.9 |  |  | 404.1 |  |  | 857.4 |  |  | 775.9 |  |
| Sales and marketing | 673.0 |  |  | 625.5 |  |  | 1,333.5 |  |  | 1,240.5 |  |
| General and administrative | 301.5 |  |  | 119.4 |  |  | 421.6 |  |  | 218.9 |  |
| Total operating expenses | 1,422.4 |  |  | 1,149.0 |  |  | 2,612.5 |  |  | 2,235.3 |  |
| Operating income | 53.6 |  |  | 39.9 |  |  | 268.8 |  |  | 55.1 |  |
| Interest expense | (2.8) |  |  | (6.9) |  |  | (5.7) |  |  | (13.7) |  |
| Other income, net | 84.7 |  |  | 51.4 |  |  | 155.0 |  |  | 77.4 |  |
| Income before income taxes | 135.5 |  |  | 84.4 |  |  | 418.1 |  |  | 118.8 |  |
| Provision for (benefit from) income taxes | (1,611.4) |  |  | 0.2 |  |  | (1,523.0) |  |  | 14.6 |  |
| Net income | $ | 1,746.9 |  |  | $ | 84.2 |  |  | $ | 1,941.1 |  |  | $ | 104.2 |  |
| Net income per share, basic | $ | 5.47 |  |  | $ | 0.28 |  |  | $ | 6.16 |  |  | $ | 0.35 |  |
| Net income per share, diluted | $ | 4.89 |  |  | $ | 0.25 |  |  | $ | 5.49 |  |  | $ | 0.31 |  |
| Weighted-average shares used to compute net income per share, basic | 319.6 |  |  | 302.3 |  |  | 314.9 |  |  | 301.0 |  |
| Weighted-average shares used to compute net income per share, diluted | 357.5 |  |  | 331.6 |  |  | 353.7 |  |  | 335.0 |  |

[0001327567-24-000003:8k_2_02:52]
2

[0001327567-24-000003:8k_2_02:53]
| Palo Alto Networks, Inc. |
| Reconciliation of GAAP to Non-GAAP Financial Measures |
| (In millions, except per share amounts) |
| (Unaudited) |
|  | Three Months Ended |  | Six Months Ended |
|  | January 31, |  | January 31, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| GAAP operating income | $ | 53.6 |  |  | $ | 39.9 |  |  | $ | 268.8 |  |  | $ | 55.1 |  |
| Share-based compensation-related charges | 296.8 |  |  | 298.6 |  |  | 584.6 |  |  | 577.5 |  |
| Acquisition-related costs(1) | 7.3 |  |  | 12.1 |  |  | 7.3 |  |  | 12.1 |  |
| Amortization expense of acquired intangible assets | 27.9 |  |  | 24.4 |  |  | 52.4 |  |  | 53.1 |  |
| Litigation-related charges(2) | 178.6 |  |  | 1.8 |  |  | 180.4 |  |  | 3.6 |  |
| Restructuring and other costs(3) | — |  |  | — |  |  | — |  |  | (2.2) |  |
| Non-GAAP operating income | $ | 564.2 |  |  | $ | 376.8 |  |  | $ | 1,093.5 |  |  | $ | 699.2 |  |
| Non-GAAP operating margin | 28.6 | % |  | 22.8 | % |  | 28.4 | % |  | 21.7 | % |
| GAAP net income | $ | 1,746.9 |  |  | $ | 84.2 |  |  | $ | 1,941.1 |  |  | $ | 104.2 |  |
| Share-based compensation-related charges | 296.8 |  |  | 298.6 |  |  | 584.6 |  |  | 577.5 |  |
| Acquisition-related costs(1) | 7.3 |  |  | 12.1 |  |  | 7.3 |  |  | 12.1 |  |
| Amortization expense of acquired intangible assets | 27.9 |  |  | 24.4 |  |  | 52.4 |  |  | 53.1 |  |
| Litigation-related charges(2) | 178.6 |  |  | 1.8 |  |  | 180.4 |  |  | 3.6 |  |
| Restructuring and other costs(3) | — |  |  | — |  |  | — |  |  | (2.2) |  |
| Non-cash charges related to convertible notes(4) | 1.1 |  |  | 1.7 |  |  | 2.1 |  |  | 3.5 |  |
| Foreign currency loss associated with non-GAAP adjustments | — |  |  | 2.3 |  |  | — |  |  | 0.5 |  |
| Income tax and other tax adjustments(5) | (1,753.9) |  |  | (93.4) |  |  | (1,796.9) |  |  | (154.2) |  |
| Non-GAAP net income | $ | 504.7 |  |  | $ | 331.7 |  |  | $ | 971.0 |  |  | $ | 598.1 |  |
| GAAP net income per share, diluted | $ | 4.89 |  |  | $ | 0.25 |  |  | $ | 5.49 |  |  | $ | 0.31 |  |
| Share-based compensation-related charges | 0.88 |  |  | 0.94 |  |  | 1.74 |  |  | 1.82 |  |
| Acquisition-related costs(1) | 0.02 |  |  | 0.04 |  |  | 0.02 |  |  | 0.04 |  |
| Amortization expense of acquired intangible assets | 0.08 |  |  | 0.07 |  |  | 0.15 |  |  | 0.16 |  |
| Litigation-related charges(2) | 0.50 |  |  | 0.01 |  |  | 0.51 |  |  | 0.01 |  |
| Restructuring and other costs(3) | 0.00 |  |  | 0.00 |  |  | 0.00 |  |  | (0.01) |  |
| Non-cash charges related to convertible notes(4) | 0.00 |  |  | 0.01 |  |  | 0.01 |  |  | 0.01 |  |
| Foreign currency loss associated with non-GAAP adjustments | 0.00 |  |  | 0.01 |  |  | 0.00 |  |  | 0.00 |  |
| Income tax and other tax adjustments(5) | (4.91) |  |  | (0.28) |  |  | (5.08) |  |  | (0.46) |  |
| Non-GAAP net income per share, diluted | $ | 1.46 |  |  | $ | 1.05 |  |  | $ | 2.84 |  |  | $ | 1.88 |  |
| GAAP weighted-average shares used to compute net income per share, diluted | 357.5 |  |  | 331.6 |  |  | 353.7 |  |  | 335.0 |  |
| Weighted-average anti-dilutive impact of note hedge agreements | (13.0) |  |  | (15.2) |  |  | (12.3) |  |  | (16.5) |  |
| Non-GAAP weighted-average shares used to compute net income per share, diluted | 344.5 |  |  | 316.4 |  |  | 341.4 |  |  | 318.5 |  |

[0001327567-24-000003:8k_2_02:54]
(1)    Consists of acquisition transaction costs, share-based compensation related to the cash settlement of certain equity awards, and costs to terminate certain employment, operating lease, and other contracts of the acquired companies.

[0001327567-24-000003:8k_2_02:55]
(2)    Consists of the amortization of intellectual property licenses and covenant not to sue, and a legal contingency charge in Q2'24.

[0001327567-24-000003:8k_2_02:56]
(3)    Consists of adjustments to restructuring and other costs.

[0001327567-24-000003:8k_2_02:57]
(4)     Consists of non-cash interest expense for amortization of debt issuance costs related to the company's convertible senior notes.

[0001327567-24-000003:8k_2_02:58]
(5)    Consists of income tax adjustments related to our long-term non-GAAP effective tax rate. In Q2'23, it included a tax benefit from a release of tax reserves related to uncertain tax positions resulting from a tax settlement. In Q2'24, it included a tax benefit from a release of our valuation allowance on U.S. federal, U.S. states other than California, and United Kingdom deferred tax assets.

[0001327567-24-000003:8k_2_02:59]
3

[0001327567-24-000003:8k_2_02:60]
| Palo Alto Networks, Inc. |
| Preliminary Condensed Consolidated Balance Sheets |
| (In millions) |
|  | January 31, 2024 |  | July 31, 2023 |
|  | (unaudited) |  |  |
| Assets |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 1,782.5 |  |  | $ | 1,135.3 |  |
| Short-term investments | 1,588.5 |  |  | 1,254.7 |  |
| Accounts receivable, net | 1,896.3 |  |  | 2,463.2 |  |
| Short-term financing receivables, net | 445.5 |  |  | 388.8 |  |
| Short-term deferred contract costs | 328.0 |  |  | 339.2 |  |
| Prepaid expenses and other current assets | 405.9 |  |  | 466.8 |  |
| Total current assets | 6,446.7 |  |  | 6,048.0 |  |
| Property and equipment, net | 352.3 |  |  | 354.5 |  |
| Operating lease right-of-use assets | 355.8 |  |  | 263.3 |  |
| Long-term investments | 3,619.6 |  |  | 3,047.9 |  |
| Long-term financing receivables, net | 639.9 |  |  | 653.3 |  |
| Long-term deferred contract costs | 504.6 |  |  | 547.1 |  |
| Goodwill | 3,372.7 |  |  | 2,926.8 |  |
| Intangible assets, net | 440.1 |  |  | 315.4 |  |
| Deferred tax assets | 2,234.3 |  |  | 23.1 |  |
| Other assets | 326.0 |  |  | 321.7 |  |
| Total assets | $ | 18,292.0 |  |  | $ | 14,501.1 |  |
| Liabilities and stockholders’ equity |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 178.8 |  |  | $ | 132.3 |  |
| Accrued compensation | 452.6 |  |  | 548.3 |  |
| Accrued and other liabilities | 394.2 |  |  | 390.8 |  |
| Deferred revenue | 4,918.1 |  |  | 4,674.6 |  |
| Convertible senior notes, net | 1,821.8 |  |  | 1,991.5 |  |
| Total current liabilities | 7,765.5 |  |  | 7,737.5 |  |
| Long-term deferred revenue | 4,900.3 |  |  | 4,621.8 |  |
| Deferred tax liabilities | 588.5 |  |  | 28.1 |  |
| Long-term operating lease liabilities | 362.7 |  |  | 279.2 |  |
| Other long-term liabilities | 317.8 |  |  | 86.1 |  |
| Total liabilities | 13,934.8 |  |  | 12,752.7 |  |
| Stockholders’ equity: |  |  |  |
| Preferred stock | — |  |  | — |  |
| Common stock and additional paid-in capital | 3,650.0 |  |  | 3,019.0 |  |
| Accumulated other comprehensive loss | (6.5) |  |  | (43.2) |  |
| Retained earnings (accumulated deficit) | 713.7 |  |  | (1,227.4) |  |
| Total stockholders’ equity | 4,357.2 |  |  | 1,748.4 |  |
| Total liabilities and stockholders’ equity | $ | 18,292.0 |  |  | $ | 14,501.1 |  |

[0001327567-24-000003:8k_2_02:61]
4
