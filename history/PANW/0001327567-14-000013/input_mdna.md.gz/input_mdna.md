# PANW MD&A — 0001327567-14-000013


## mdna

[0001327567-14-000013:mdna:1]
[same as prior period, unchanged from 0001327567-14-000005:mdna:1]

[0001327567-14-000013:mdna:2]
[same as prior period, unchanged from 0001327567-14-000005:mdna:2]

[0001327567-14-000013:mdna:3]
[same as prior period, unchanged from 0001327567-14-000005:mdna:3]

[0001327567-14-000013:mdna:4]
[same as prior period, unchanged from 0001327567-14-000005:mdna:4]

[0001327567-14-000013:mdna:5]
[same as prior period, unchanged from 0001327567-14-000005:mdna:5]

[0001327567-14-000013:mdna:6]
| • | Results of Operations. An analysis of our financial results comparing the three and nine months ended April 30, 2014 to the three and nine months ended April 30, 2013. |

[0001327567-14-000013:mdna:7]
[same as prior period, unchanged from 0001327567-14-000005:mdna:7]

[0001327567-14-000013:mdna:8]
[same as prior period, unchanged from 0001327567-14-000005:mdna:8]

[0001327567-14-000013:mdna:9]
[same as prior period, unchanged from 0001327567-14-000005:mdna:9]

[0001327567-14-000013:mdna:10]
[same as prior period, unchanged from 0001327567-14-000005:mdna:10]

[0001327567-14-000013:mdna:11]
[same as prior period, unchanged from 0001327567-14-000005:mdna:11]

[0001327567-14-000013:mdna:12]
We have pioneered the next-generation of enterprise security with our innovative platform that allows enterprises, service providers, and government entities to simultaneously empower and secure their organizations by safely enabling the increasingly complex and rapidly growing number of applications running on their networks and by preventing breaches stemming from targeted cyber attacks. Our enterprise security platform consists of three major elements: our Next-Generation Firewall, our Next-Generation Endpoint Protection, and our Next-Generation Threat Intelligence Cloud. Our Next-Generation Firewall delivers application, user, and content visibility and control as well as protection against network based cyber threats integrated within the firewall through our proprietary hardware and software architecture. Our Next-Generation Endpoint Protection protects against cyber attacks that aim to exploit software vulnerabilities on a broad variety of fixed and virtual endpoints. Our Next-Generation Threat Intelligence Cloud provides central intelligence capabilities as well as automated delivery of preventative measures against cyber attacks. The cloud-based element of our platform is delivered in the form of a service that can be used either in the public cloud or in a private cloud using our dedicated WildFire appliance, WF-500.

[0001327567-14-000013:mdna:13]
We derive revenue from sales of our products and services, which together comprise our platform. Product revenue is generated from sales of our Next-Generation Firewall, which is available in hardware and virtualized form factors. Our Next-Generation Firewall incorporates our proprietary PAN-OS operating system, which provides a consistent set of capabilities across our entire product line. These capabilities include: application visibility and control (App-ID), user identification (User-ID), site-to-site virtual private network (VPN), remote access Secure Sockets Layer (SSL) VPN, and Quality-of-Service (QoS). Our

[0001327567-14-000013:mdna:14]
[same as prior period, unchanged from 0001327567-14-000005:mdna:24]

[0001327567-14-000013:mdna:15]
products are designed for different performance requirements throughout an organization, ranging from the PA-200, which is designed for enterprise remote offices, to the PA-7050, which is designed for data centers and high-speed networks. The same firewall functionality that is delivered in the hardware appliances is also available in the VM-Series virtual firewalls, which secure virtualized and cloud-based computing environments. Multiple firewalls can leverage our WildFire appliance, WF-500, which identifies, analyzes, and blocks known and unknown malware in a private cloud-based environment. Our platform can be centrally managed in both virtualized and hardware appliances across an organization with our Panorama product. In addition, our GlobalProtect appliance, GP-100, provides mobile device management, malware detection, and shares device state information to safely enable mobile devices for business use.

[0001327567-14-000013:mdna:16]
Services revenue is generated from sales of subscriptions, including our Next-Generation Endpoint Protection, and support and maintenance. Our Threat Prevention, URL Filtering, GlobalProtect, and WildFire subscriptions provide our end-customers with real-time access to the latest antivirus, intrusion prevention, web filtering, and modern malware prevention capabilities across fixed and mobile devices. Our Next-Generation Endpoint Protection protects against cyber attacks that exploit software vulnerabilities in Windows-based fixed and virtual endpoints through the use of its unique capability of stopping the underlying exploit techniques, and can prevent cyber attacks without relying on prior knowledge of the attack. When end-customers purchase an appliance, they typically purchase one or more of our subscriptions for additional functionality, as well as support and maintenance in order to receive ongoing security updates, upgrades, bug fixes, and repairs. We leverage our appliances to sell SaaS (software as a service) subscription services to meet our customers’ evolving enterprise security requirements. Our hybrid SaaS revenue model consists of product, subscriptions, and support and maintenance, which will enable us to benefit from recurring revenues as we continue to grow our installed base. Sales of these services increase our deferred revenue balance and contribute significantly to our positive cash flow provided by operating activities.

[0001327567-14-000013:mdna:17]
[same as prior period, unchanged from 0001327567-14-000005:mdna:17]

[0001327567-14-000013:mdna:18]
We continue to invest in innovation and strengthening our product portfolio, which resulted in several new product offerings during fiscal 2014. These new product offerings include: the PA-7050 firewall, the fastest Next-Generation Firewall in the industry with a throughput of 120Mbps; the GP-100 mobile security management appliance, which offers an easy to deploy, high-performance, dedicated management appliance for our GlobalProtect customers; and the VM-1000-HV virtual Next-Generation Firewall, which is fully integrated with VMware, Inc.’s NSX virtualization platform.

[0001327567-14-000013:mdna:19]
In addition, we extended our next-generation enterprise security platform and our technology leadership with the acquisitions of Cyvera Ltd. ("Cyvera") and Morta Security, Inc. ("Morta"). Cyvera's offering protects enterprises from cyber threats by using an innovative approach to block unknown, zero-day attacks on the endpoint. Through fiscal 2015, we intend to invest approximately $3.5 million in the forth quarter of fiscal 2014 and $25.0 million in fiscal 2015 in research and development, customer support, and growing our Next-Generation Endpoint Protection sales force. We anticipate billings (non-GAAP) and revenue of our Next-Generation Endpoint will begin ramping in the second half of fiscal 2015 with a more meaningful revenue contribution in fiscal 2016. Morta provides a team of cybersecurity experts that will enhance our WildFire threat detection and prevention offering. These enhancements enable quick discovery and elimination of previously unknown malware, zero-day exploits, and advanced persistent threats.

[0001327567-14-000013:mdna:20]
During the third quarter of fiscal 2014, we added more than 1,300 end-customers including some of the largest Fortune 100 and Global 2000 companies in the world. As of April 30, 2014, we had more than 17,000 end-customers in over 130 countries. Our end-customers represent a broad range of industries including education, energy, financial services, government entities, healthcare, Internet and media, manufacturing, public sector, and telecommunications. As of April 30, 2014, we had 1,556 employees.

[0001327567-14-000013:mdna:21]
We have experienced rapid growth and increased demand for our products in recent periods. For the third quarter of fiscal 2014 and 2013, revenues were $150.7 million and $101.3 million, respectively, representing year-over-year growth of 48.8%, despite continued uncertainty in the macroeconomic environment. These macroeconomic factors may continue to impact overall spending in information technology (IT) by our customers, which could adversely affect our revenues and operating results.

[0001327567-14-000013:mdna:22]
All three components of our hybrid SaaS revenue model experienced year-over-year growth, led by revenue from subscription services, which grew 71.4% to $32.0 million, followed by support and maintenance services, which grew 58.4% to $34.6 million, and product, which grew 38.4% to $84.1 million. The growth reflected increasing recurring revenue in our business model and rapid adoption of high margin subscription services in our base of end-customers.

[0001327567-14-000013:mdna:23]
In May 2014, we entered into a Settlement, Release and Cross-License Agreement ("settlement agreement") with Juniper Networks, Inc. ("Juniper"). Under the terms of the settlement agreement, we agreed to pay to Juniper $75.0 million in cash and transfer 1.1 million shares of our common stock with an approximate value of $70.0 million and a warrant to purchase 0.5 million

[0001327567-14-000013:mdna:24]
[same as prior period, unchanged from 0001327567-14-000005:mdna:36]

[0001327567-14-000013:mdna:25]
shares of our common stock with an approximate value of $30.0 million. The terms of the settlement agreement provide for mutual dismissal with prejudice of all pending litigation between the parties, cross-license of the patents in suit for the life of the patents, and an eight-year mutual covenant not to sue for infringement of any other patents. The settlement with Juniper resolves all pending litigation matters between us and will allow us to further focus on innovating and strengthening our product portfolio, servicing our customers, and growing our business.

[0001327567-14-000013:mdna:26]
We believe that the growth of our business and our short-term and long-term success are dependent upon many factors, including our ability to extend our technology leadership, grow our base of end-customers, expand deployment of our platform and services within existing end-customers, extend the length of service terms within existing end-customers, and focus on end-customer satisfaction. While these areas present significant opportunities for us, they also pose challenges and risks that we must successfully address in order to sustain the growth of our business and improve our operating results.

[0001327567-14-000013:mdna:27]
[same as prior period, unchanged from 0001327567-14-000005:mdna:23]

[0001327567-14-000013:mdna:28]
[same as prior period, unchanged from 0001327567-14-000005:mdna:25]

[0001327567-14-000013:mdna:29]
We monitor the key financial metrics set forth below to help us evaluate growth trends, establish budgets, measure the effectiveness of our sales and marketing efforts, and assess operational efficiencies. We discuss revenue, gross margin, and the components of operating loss and margin below under “—Financial Overview” and “—Results of Operations.” The following tables summarize deferred revenue, cash flow provided by operating activities, free cash flow (non-GAAP), and billings (non-GAAP).

[0001327567-14-000013:mdna:30]
|  | April 30, 2014 |  | July 31, 2013 |
|  | (in thousands) |
| Total deferred revenue | $ | 367,933 |  |  | $ | 249,230 |  |
| Cash, cash equivalents, and investments | $ | 471,872 |  |  | $ | 436,935 |  |

[0001327567-14-000013:mdna:31]
|  | Three Months Ended April 30, |  | Nine Months Ended April 30, |
|  | 2014 |  | 2013 |  | 2014 |  | 2013 |
|  | (dollars in thousands) |
| Total revenue | $ | 150,700 |  |  | $ | 101,289 |  |  | $ | 419,948 |  |  | $ | 283,722 |  |
| Year-over-year percentage increase | 48.8 | % |  | 54.2 | % |  | 48.0 | % |  | 58.1 | % |
| Gross margin percentage | 73.6 | % |  | 72.7 | % |  | 73.6 | % |  | 72.0 | % |
| Operating loss (1)(2)(3)(4) | $ | (145,732 | ) |  | $ | (6,450 | ) |  | $ | (189,899 | ) |  | $ | (11,738 | ) |
| Operating margin percentage | (96.7 | )% |  | (6.4 | )% |  | (45.2 | )% |  | (4.1 | )% |
| Billings (non-GAAP) | $ | 193,890 |  |  | $ | 132,410 |  |  | $ | 538,499 |  |  | $ | 367,218 |  |
| Cash flow provided by operating activities |  |  |  |  | $ | 114,556 |  |  | $ | 72,789 |  |
| Free cash flow (non-GAAP) |  |  |  |  | $ | 83,177 |  |  | $ | 56,194 |  |

[0001327567-14-000013:mdna:32]
[same as prior period, unchanged from 0001327567-14-000005:mdna:29]

[0001327567-14-000013:mdna:33]
| (1) | Includes share-based compensation expense of $28.0 million and $66.8 million for the three and nine months ended April 30, 2014, respectively, and $12.6 million and $29.7 million for the three and nine months ended April 30, 2013, respectively. |

[0001327567-14-000013:mdna:34]
| (2) | Includes intellectual property litigation expense of $4.7 million and $9.3 million for the three and nine months ended April 30, 2014, respectively, and $1.3 million and $2.3 million for the three and nine months ended April 30, 2013, respectively. |

[0001327567-14-000013:mdna:35]
| (3) | Includes legal settlement expense of $121.2 million and $141.2 million for the three and nine months ended April 30, 2014, respectively, and nil for the three and nine months ended April 30, 2013. |

[0001327567-14-000013:mdna:36]
| (4) | Includes acquisition transaction costs of $3.6 million and $4.0 million for the three and nine months ended April 30, 2014, respectively, and nil for the three and nine months ended April 30, 2013. |

[0001327567-14-000013:mdna:37]
[same as prior period, unchanged from 0001327567-14-000005:mdna:48]

[0001327567-14-000013:mdna:38]
[same as prior period, unchanged from 0001327567-14-000005:mdna:33]

[0001327567-14-000013:mdna:39]
[same as prior period, unchanged from 0001327567-14-000005:mdna:34]

[0001327567-14-000013:mdna:40]
| • | Free Cash Flow (non-GAAP). We define free cash flow, a non-GAAP financial measure, as cash provided by operating activities less purchases of property, equipment, and other assets. We consider free cash flow to be a liquidity measure that provides useful information to management and investors about the amount of cash generated by the business that, after the purchases of property, equipment, and other assets, can be used for strategic opportunities, including investing in our business, making strategic acquisitions, and strengthening the balance sheet. However, it is important to note that other companies, including companies in our industry, may not use free cash flow, may calculate free cash flow differently, or may use other financial measures to evaluate their performance, all of which could reduce the usefulness of free cash flow as a comparative measure. A reconciliation of free cash flow to cash flow provided by operating activities, the most directly comparable financial measure calculated and presented in accordance with GAAP, is provided below: |

[0001327567-14-000013:mdna:41]
|  | Nine Months Ended April 30, |
|  | 2014 |  | 2013 |
|  | (in thousands) |
| Cash Flow: |  |  |  |
| Cash flow provided by operating activities | $ | 114,556 |  |  | $ | 72,789 |  |
| Less: purchase of property, equipment, and other assets | 31,379 |  |  | 16,595 |  |
| Free cash flow (non-GAAP) | $ | 83,177 |  |  | $ | 56,194 |  |
| Net cash used in investing activities | $ | (229,306 | ) |  | $ | (196,637 | ) |
| Net cash provided by financing activities | $ | 38,926 |  |  | $ | 14,870 |  |

[0001327567-14-000013:mdna:42]
| • | Billings (non-GAAP). We define billings, a non-GAAP financial measure, as total revenue plus the change in deferred revenue, net of acquired deferred revenue, during the period. Billings is a key measure used by our management to manage our business because billings drive deferred revenue, which is an important indicator of the health and visibility of our business. We consider billings to be a useful metric for management and investors, particularly as we experience increased sales of subscriptions and strong renewal rates for subscriptions and support and maintenance services, and monitor our near term cash flows. We believe that billings provides useful information to investors and others in understanding and evaluating our operating results in the same manner as our management. However, it is important to note that other companies, including companies in our industry, may not use billings, may calculate billings differently, may have different billing frequencies, or may use other financial measures to evaluate their performance, all of which could reduce the usefulness of billings as a comparative measure. A reconciliation of billings to revenue, the most directly comparable financial measure calculated and presented in accordance with GAAP, is provided below: |

[0001327567-14-000013:mdna:43]
|  | Three Months Ended April 30, |  | Nine Months Ended April 30, |
|  | 2014 |  | 2013 |  | 2014 |  | 2013 |
|  | (in thousands) |
| Billings (non-GAAP): |  |  |  |  |  |  |  |
| Total revenue | $ | 150,700 |  |  | $ | 101,289 |  |  | $ | 419,948 |  |  | $ | 283,722 |  |
| Add: change in total deferred revenue, net of acquired deferred revenue | 43,190 |  |  | 31,121 |  |  | 118,551 |  |  | 83,496 |  |
| Billings (non-GAAP) | $ | 193,890 |  |  | $ | 132,410 |  |  | $ | 538,499 |  |  | $ | 367,218 |  |

[0001327567-14-000013:mdna:44]
[same as prior period, unchanged from 0001327567-14-000005:mdna:61]

[0001327567-14-000013:mdna:45]
[same as prior period, unchanged from 0001327567-14-000005:mdna:40]

[0001327567-14-000013:mdna:46]
[same as prior period, unchanged from 0001327567-14-000005:mdna:41]

[0001327567-14-000013:mdna:47]
[same as prior period, unchanged from 0001327567-14-000005:mdna:42]

[0001327567-14-000013:mdna:48]
[same as prior period, unchanged from 0001327567-14-000005:mdna:43]

[0001327567-14-000013:mdna:49]
[same as prior period, unchanged from 0001327567-14-000005:mdna:44]

[0001327567-14-000013:mdna:50]
| • | Services Revenue. Services revenue is derived primarily from Threat Prevention, URL Filtering, GlobalProtect, and WildFire subscriptions and support and maintenance. Revenue from our Next-Generation Endpoint Protection is immaterial for the three and nine months ended April 30, 2014. We expect that revenue from our Next-Generation Endpoint Protection will increase in the future. Threat Prevention, URL Filtering, GlobalProtect, and WildFire subscriptions are priced as a percentage of the appliance’s list price. Our contractual subscription and support and maintenance terms are typically one to five years. We recognize revenue from subscriptions and support and maintenance over the contractual service period. As a percentage of total revenue, we expect our services revenue to vary from quarter to quarter and increase over the long term as we introduce new subscriptions, renew existing services contracts, and expand our end-customer base. |

[0001327567-14-000013:mdna:51]
[same as prior period, unchanged from 0001327567-14-000005:mdna:46]

[0001327567-14-000013:mdna:52]
Our total cost of revenue consists of cost of product revenue and cost of services revenue. Our cost of revenue includes costs paid to our third-party contract manufacturer and personnel costs, which consist of salaries, bonuses, and share-based compensation associated with our operations and global customer support organizations. Our cost of revenue also includes allocated costs, which consist of certain facilities, depreciation, benefits, recruiting, and information technology costs that we allocate based on headcount, and amortization expense of intangible assets.

[0001327567-14-000013:mdna:53]
[same as prior period, unchanged from 0001327567-14-000005:mdna:50]

[0001327567-14-000013:mdna:54]
| • | Cost of Services Revenue. Cost of services revenue includes personnel costs for our global customer support organization, amortization expense of intangible assets acquired, allocated costs, and URL filtering database service fees. We expect our cost of services revenue to increase as our end-customer base grows. |

[0001327567-14-000013:mdna:55]
[same as prior period, unchanged from 0001327567-14-000005:mdna:52]

[0001327567-14-000013:mdna:56]
[same as prior period, unchanged from 0001327567-14-000005:mdna:53]

[0001327567-14-000013:mdna:57]
[same as prior period, unchanged from 0001327567-14-000005:mdna:54]

[0001327567-14-000013:mdna:58]
Our operating expenses consist of research and development, sales and marketing, general and administrative expense, and legal settlement expense. Personnel costs are the most significant component of operating expenses and consist of salaries, benefits, bonuses, share-based compensation, and with regard to sales and marketing expense, sales commissions. We expect operating expenses to increase in absolute dollars, although they may fluctuate as a percentage of revenue from quarter to quarter, as we continue to grow in response to demand for our products and services. As of April 30, 2014, we expect to recognize approximately $282.9 million of share-based compensation over a weighted-average period of three years, excluding additional share-based compensation related to any future grants of share-based awards. Share-based compensation, net of forfeitures, is recognized on a straight-line basis over the requisite service periods of the awards.

[0001327567-14-000013:mdna:59]
| • | Research and Development. Research and development expense consists primarily of personnel costs. Research and development expense also includes prototype related expenses and allocated costs. We expect research and |

[0001327567-14-000013:mdna:60]
[same as prior period, unchanged from 0001327567-14-000005:mdna:69]

[0001327567-14-000013:mdna:61]
development expense to increase in absolute dollars as we continue to invest in our future products and services, although our research and development expense may fluctuate as a percentage of total revenue.

[0001327567-14-000013:mdna:62]
[same as prior period, unchanged from 0001327567-14-000005:mdna:57]

[0001327567-14-000013:mdna:63]
| • | General and Administrative. General and administrative expense consists of personnel costs as well as professional services and certain non-recurring general expenses. General and administrative personnel include our executive, finance, human resources, and legal organizations. Professional services consist primarily of legal, auditing, accounting, and other consulting costs. We expect general and administrative expense to increase in absolute dollars due to additional costs associated with accounting, compliance, insurance, and investor relations, although our general and administrative expense may fluctuate as a percentage of total revenue. |

[0001327567-14-000013:mdna:64]
| • | Legal Settlement. Legal settlement expense consists of charges related to the settlement agreement with Juniper and the Mutual Covenant Not to Sue and Release Agreement with Fortinet, Inc. ("Fortinet"). Refer to the discussion under Note 12 Subsequent Events and Note 7 Mutual Covenant Not to Sue and Release Agreement of Notes to Condensed Consolidated Financial Statements in Part I, Item 1 of this Quarterly Report on Form 10-Q for information related to these matters. |

[0001327567-14-000013:mdna:65]
[same as prior period, unchanged from 0001327567-14-000005:mdna:59]

[0001327567-14-000013:mdna:66]
[same as prior period, unchanged from 0001327567-14-000005:mdna:60]

[0001327567-14-000013:mdna:67]
[same as prior period, unchanged from 0001327567-14-000005:mdna:62]

[0001327567-14-000013:mdna:68]
[same as prior period, unchanged from 0001327567-14-000005:mdna:63]

[0001327567-14-000013:mdna:69]
[same as prior period, unchanged from 0001327567-14-000005:mdna:64]

[0001327567-14-000013:mdna:70]
Provision for income taxes consists primarily of income taxes in foreign jurisdictions in which we conduct business, withholding taxes, and federal and state income taxes in the United States. We maintain a full valuation allowance for domestic deferred tax assets, including net operating loss carryforwards and tax credits. We expect the provision for income taxes to increase in future years. We implemented our corporate structure and intercompany relationships to more closely align with the international nature of our business in the fourth quarter of fiscal 2013. Income in certain countries may be taxed at statutory tax rates that are lower than the U.S. statutory tax rate. As a result, our overall effective tax rate over the long term may be lower than the U.S. federal statutory tax rate on positive income through changes in international procurement and sales operations.

[0001327567-14-000013:mdna:71]
[same as prior period, unchanged from 0001327567-14-000005:mdna:66]

[0001327567-14-000013:mdna:72]
[same as prior period, unchanged from 0001327567-14-000005:mdna:67]

[0001327567-14-000013:mdna:73]
[same as prior period, unchanged from 0001327567-14-000005:mdna:75]

[0001327567-14-000013:mdna:74]
|  | Three Months Ended April 30, |  | Nine Months Ended April 30, |
|  | 2014 |  | 2013 |  | 2014 |  | 2013 |
|  | (in thousands) |
| Condensed Consolidated Statements of Operations Data: |  |  |  |  |  |  |  |
| Revenue: |  |  |  |  |  |  |  |
| Product | $ | 84,128 |  |  | $ | 60,793 |  |  | $ | 240,436 |  |  | $ | 178,251 |  |
| Services | 66,572 |  |  | 40,496 |  |  | 179,512 |  |  | 105,471 |  |
| Total revenue | 150,700 |  |  | 101,289 |  |  | 419,948 |  |  | 283,722 |  |
| Cost of revenue: |  |  |  |  |  |  |  |
| Product | 20,425 |  |  | 15,855 |  |  | 58,600 |  |  | 46,907 |  |
| Services | 19,285 |  |  | 11,835 |  |  | 52,421 |  |  | 32,591 |  |
| Total cost of revenue | 39,710 |  |  | 27,690 |  |  | 111,021 |  |  | 79,498 |  |
| Total gross profit | 110,990 |  |  | 73,599 |  |  | 308,927 |  |  | 204,224 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 27,837 |  |  | 16,048 |  |  | 71,983 |  |  | 44,855 |  |
| Sales and marketing | 83,995 |  |  | 51,733 |  |  | 228,095 |  |  | 140,136 |  |
| General and administrative | 23,717 |  |  | 12,268 |  |  | 57,575 |  |  | 30,971 |  |
| Legal settlement | 121,173 |  |  | — |  |  | 141,173 |  |  | — |  |
| Total operating expenses | 256,722 |  |  | 80,049 |  |  | 498,826 |  |  | 215,962 |  |
| Operating loss | (145,732 | ) |  | (6,450 | ) |  | (189,899 | ) |  | (11,738 | ) |
| Interest income | 272 |  |  | 133 |  |  | 619 |  |  | 347 |  |
| Other income (expense), net | 145 |  |  | (157 | ) |  | 11 |  |  | (387 | ) |
| Loss before income taxes | (145,315 | ) |  | (6,474 | ) |  | (189,269 | ) |  | (11,778 | ) |
| Provision for income taxes | 1,272 |  |  | 808 |  |  | 5,125 |  |  | 1,632 |  |
| Net loss | $ | (146,587 | ) |  | $ | (7,282 | ) |  | $ | (194,394 | ) |  | $ | (13,410 | ) |

[0001327567-14-000013:mdna:75]
[same as prior period, unchanged from 0001327567-14-000005:mdna:87]

[0001327567-14-000013:mdna:76]
|  | Three Months Ended April 30, |  | Nine Months Ended April 30, |
|  | 2014 |  | 2013 |  | 2014 |  | 2013 |
|  | (as a percentage of revenue) |
| Condensed Consolidated Statements of Operations Data: |  |  |  |  |  |  |  |
| Revenue: |  |  |  |  |  |  |  |
| Product | 55.8 | % |  | 60.0 | % |  | 57.3 | % |  | 62.8 | % |
| Services | 44.2 | % |  | 40.0 | % |  | 42.7 | % |  | 37.2 | % |
| Total revenue | 100.0 | % |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |
| Cost of revenue: |  |  |  |  |  |  |  |
| Product | 13.6 | % |  | 15.7 | % |  | 14.0 | % |  | 16.5 | % |
| Services | 12.8 | % |  | 11.6 | % |  | 12.4 | % |  | 11.5 | % |
| Total cost of revenue | 26.4 | % |  | 27.3 | % |  | 26.4 | % |  | 28.0 | % |
| Total gross profit | 73.6 | % |  | 72.7 | % |  | 73.6 | % |  | 72.0 | % |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 18.5 | % |  | 15.8 | % |  | 17.1 | % |  | 15.8 | % |
| Sales and marketing | 55.7 | % |  | 51.1 | % |  | 54.3 | % |  | 49.4 | % |
| General and administrative | 15.7 | % |  | 12.2 | % |  | 13.8 | % |  | 10.9 | % |
| Legal settlement | 80.4 | % |  | — | % |  | 33.6 | % |  | — | % |
| Total operating expenses | 170.3 | % |  | 79.1 | % |  | 118.8 | % |  | 76.1 | % |
| Operating loss | (96.7 | )% |  | (6.4 | )% |  | (45.2 | )% |  | (4.1 | )% |
| Interest income | 0.2 | % |  | 0.1 | % |  | 0.1 | % |  | 0.1 | % |
| Other income (expense), net | 0.1 | % |  | (0.2 | )% |  | — | % |  | (0.1 | )% |
| Loss before income taxes | (96.4 | )% |  | (6.5 | )% |  | (45.1 | )% |  | (4.1 | )% |
| Provision for income taxes | 0.9 | % |  | 0.8 | % |  | 1.2 | % |  | 0.6 | % |
| Net loss | (97.3 | )% |  | (7.3 | )% |  | (46.3 | )% |  | (4.7 | )% |

[0001327567-14-000013:mdna:77]
[same as prior period, unchanged from 0001327567-14-000005:mdna:97]

[0001327567-14-000013:mdna:78]
Comparison of the Three and Nine Month Periods Ended April 30, 2014 and 2013

[0001327567-14-000013:mdna:79]
[same as prior period, unchanged from 0001327567-14-000005:mdna:72]

[0001327567-14-000013:mdna:80]
|  | Three Months Ended April 30, |  |  |  |  |  | Nine Months Ended April 30, |  |  |  |  |
|  | 2014 |  | 2013 |  | Change |  | 2014 |  | 2013 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in thousands) |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 84,128 |  |  | $ | 60,793 |  |  | $ | 23,335 |  |  | 38.4 | % |  | $ | 240,436 |  |  | $ | 178,251 |  |  | $ | 62,185 |  |  | 34.9 | % |
| Service |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Subscription | 32,005 |  |  | 18,677 |  |  | 13,328 |  |  | 71.4 | % |  | 85,619 |  |  | 49,553 |  |  | 36,066 |  |  | 72.8 | % |
| Support and maintenance | 34,567 |  |  | 21,819 |  |  | 12,748 |  |  | 58.4 | % |  | 93,893 |  |  | 55,918 |  |  | 37,975 |  |  | 67.9 | % |
| Total service | 66,572 |  |  | 40,496 |  |  | 26,076 |  |  | 64.4 | % |  | 179,512 |  |  | 105,471 |  |  | 74,041 |  |  | 70.2 | % |
| Total revenue | $ | 150,700 |  |  | $ | 101,289 |  |  | $ | 49,411 |  |  | 48.8 | % |  | $ | 419,948 |  |  | $ | 283,722 |  |  | $ | 136,226 |  |  | 48.0 | % |
| Revenue by geographic theater: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 98,689 |  |  | $ | 63,233 |  |  | $ | 35,456 |  |  | 56.1 | % |  | $ | 275,724 |  |  | $ | 178,169 |  |  | $ | 97,555 |  |  | 54.8 | % |
| EMEA | 32,326 |  |  | 23,154 |  |  | 9,172 |  |  | 39.6 | % |  | 89,299 |  |  | 67,048 |  |  | 22,251 |  |  | 33.2 | % |
| APAC | 19,685 |  |  | 14,902 |  |  | 4,783 |  |  | 32.1 | % |  | 54,925 |  |  | 38,505 |  |  | 16,420 |  |  | 42.6 | % |
| Total revenue | $ | 150,700 |  |  | $ | 101,289 |  |  | $ | 49,411 |  |  | 48.8 | % |  | $ | 419,948 |  |  | $ | 283,722 |  |  | $ | 136,226 |  |  | 48.0 | % |

[0001327567-14-000013:mdna:81]
Product revenue increased $23.3 million, or 38.4%, for the three months ended April 30, 2014 compared to the three months ended April 30, 2013. The increase was driven by increased demand for our higher end appliances.

[0001327567-14-000013:mdna:82]
Product revenue increased $62.2 million, or 34.9%, for the nine months ended April 30, 2014 compared to the nine months ended April 30, 2013. The increase was driven by increased demand for our higher end appliances.

[0001327567-14-000013:mdna:83]
Service revenue increased $26.1 million, or 64.4%, for the three months ended April 30, 2014 compared to the three months ended April 30, 2013. The increase was driven by a 71.4% increase in our subscription revenue and a 58.4% increase in our support and maintenance revenue due to increased sales to new and existing end-customers. The relative increases in subscriptions and support and maintenance will fluctuate over time, depending on the mix of services revenue and the introduction of new services offerings.

[0001327567-14-000013:mdna:84]
Service revenue increased $74.0 million, or 70.2%, for the nine months ended April 30, 2014 compared to the nine months ended April 30, 2013. The increase was driven by a 72.8% increase in our subscription revenue and a 67.9% increase in our support and maintenance revenue due to increased sales to new and existing end-customers. The relative increases in subscriptions and support and maintenance will fluctuate over time, depending on the mix of services revenue and the introduction of new services offerings.

[0001327567-14-000013:mdna:85]
With respect to geographic theaters, the Americas contributed the largest portion of the increase in revenue for the three and nine months ended April 30, 2014 compared to the three and nine months ended April 30, 2013 due to its larger and more established sales force compared to our other theaters. Revenue from both EMEA and APAC increased for the three and nine months ended April 30, 2014 compared to the three and nine months ended April 30, 2013 due to our investment in our sales force and number of partners in these theaters.

[0001327567-14-000013:mdna:86]
[same as prior period, unchanged from 0001327567-14-000005:mdna:108]

[0001327567-14-000013:mdna:87]
[same as prior period, unchanged from 0001327567-14-000005:mdna:80]

[0001327567-14-000013:mdna:88]
|  | Three Months Ended April 30, |  | Nine Months Ended April 30, |
|  | 2014 |  | 2013 |  | 2014 |  | 2013 |
|  | Amount |  | Gross Margin |  | Amount |  | Gross Margin |  | Amount |  | Gross Margin |  | Amount |  | Gross Margin |
|  | (dollars in thousands) |
| Cost of revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 20,425 |  |  |  |  | $ | 15,855 |  |  |  |  | $ | 58,600 |  |  |  |  | $ | 46,907 |  |  |  |
| Services | 19,285 |  |  |  |  | 11,835 |  |  |  |  | 52,421 |  |  |  |  | 32,591 |  |  |  |
| Total cost of revenue | $ | 39,710 |  |  |  |  | $ | 27,690 |  |  |  |  | $ | 111,021 |  |  |  |  | $ | 79,498 |  |  |  |
| Gross profit: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 63,703 |  |  | 75.7 | % |  | $ | 44,938 |  |  | 73.9 | % |  | $ | 181,836 |  |  | 75.6 | % |  | $ | 131,344 |  |  | 73.7 | % |
| Services | 47,287 |  |  | 71.0 | % |  | 28,661 |  |  | 70.8 | % |  | 127,091 |  |  | 70.8 | % |  | 72,880 |  |  | 69.1 | % |
| Total gross profit | $ | 110,990 |  |  | 73.6 | % |  | $ | 73,599 |  |  | 72.7 | % |  | $ | 308,927 |  |  | 73.6 | % |  | $ | 204,224 |  |  | 72.0 | % |

[0001327567-14-000013:mdna:89]
Product cost increased $4.6 million, or 28.8%, for the three months ended April 30, 2014 compared to the three months ended April 30, 2013 due to an increase in product unit volume.

[0001327567-14-000013:mdna:90]
Product cost increased $11.7 million, or 24.9%, for the nine months ended April 30, 2014 compared to the nine months ended April 30, 2013 due to an increase in product unit volume.

[0001327567-14-000013:mdna:91]
Service cost increased $7.5 million, or 62.9%, for the three months ended April 30, 2014 compared to the three months ended April 30, 2013 due to an increase in personnel costs of $4.3 million related to increasing our headcount, allocated costs of $1.4 million, and other costs incurred to expand our customer service capabilities to support our growing end-customer base.

[0001327567-14-000013:mdna:92]
Service cost increased $19.8 million, or 60.8%, for the nine months ended April 30, 2014 compared to the nine months ended April 30, 2013 due to an increase in personnel costs of $10.5 million related to increasing our headcount, allocated costs of $4.3 million, professional services costs of $1.4 million, and other costs incurred to expand our customer service capabilities to support our growing end-customer base.

[0001327567-14-000013:mdna:93]
Gross margin increased 90 basis points for the three months ended April 30, 2014 compared to the three months ended April 30, 2013. The increase of 180 basis points in product margin was equally due to increased demand for our higher end appliances and continued focus on material cost reductions. The increase of 20 basis points in services margin was driven by an increase of 80 basis points due to contributions from our higher margin subscription services, partially offset by a 60 basis points decrease due to amortization of purchased intangible assets.

[0001327567-14-000013:mdna:94]
Gross margin increased 160 basis points for the nine months ended April 30, 2014 compared to the nine months ended April 30, 2013. The increase of 190 basis points in product margin was due to increased demand for our higher end appliances. The increase of 170 basis points in services margin was due to contributions from our higher margin subscription services.

[0001327567-14-000013:mdna:95]
[same as prior period, unchanged from 0001327567-14-000005:mdna:123]

[0001327567-14-000013:mdna:96]
[same as prior period, unchanged from 0001327567-14-000005:mdna:89]

[0001327567-14-000013:mdna:97]
|  | Three Months Ended April 30, |  |  |  |  |  | Nine Months Ended April 30, |  |  |  |  |
|  | 2014 |  | 2013 |  | Change |  | 2014 |  | 2013 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in thousands) |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | $ | 27,837 |  |  | $ | 16,048 |  |  | $ | 11,789 |  |  | 73.5 | % |  | $ | 71,983 |  |  | $ | 44,855 |  |  | $ | 27,128 |  |  | 60.5 | % |
| Sales and marketing | 83,995 |  |  | 51,733 |  |  | 32,262 |  |  | 62.4 | % |  | 228,095 |  |  | 140,136 |  |  | 87,959 |  |  | 62.8 | % |
| General and administrative | 23,717 |  |  | 12,268 |  |  | 11,449 |  |  | 93.3 | % |  | 57,575 |  |  | 30,971 |  |  | 26,604 |  |  | 85.9 | % |
| Legal settlement | 121,173 |  |  | — |  |  | 121,173 |  |  | N/A |  |  | 141,173 |  |  | — |  |  | 141,173 |  |  | N/A |  |
| Total operating expenses | $ | 256,722 |  |  | $ | 80,049 |  |  | $ | 176,673 |  |  | 220.7 | % |  | $ | 498,826 |  |  | $ | 215,962 |  |  | $ | 282,864 |  |  | 131.0 | % |
| Includes share-based compensation of: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | $ | 8,666 |  |  | $ | 3,024 |  |  | $ | 5,642 |  |  | 186.6 | % |  | $ | 17,825 |  |  | $ | 6,687 |  |  | $ | 11,138 |  |  | 166.6 | % |
| Sales and marketing | 12,372 |  |  | 5,686 |  |  | 6,686 |  |  | 117.6 | % |  | 29,050 |  |  | 13,919 |  |  | 15,131 |  |  | 108.7 | % |
| General and administrative | 3,798 |  |  | 2,560 |  |  | 1,238 |  |  | 48.4 | % |  | 12,601 |  |  | 6,325 |  |  | 6,276 |  |  | 99.2 | % |
| Total | $ | 24,836 |  |  | $ | 11,270 |  |  | $ | 13,566 |  |  | 120.4 | % |  | $ | 59,476 |  |  | $ | 26,931 |  |  | $ | 32,545 |  |  | 120.8 | % |

[0001327567-14-000013:mdna:98]
Research and development expense increased $11.8 million, or 73.5%, for the three months ended April 30, 2014 compared to the three months ended April 30, 2013, due to an increase in personnel costs of $9.7 million largely due to an increase in headcount and an increase in allocated costs of $1.6 million.

[0001327567-14-000013:mdna:99]
Research and development expense increased $27.1 million, or 60.5%, for the nine months ended April 30, 2014 compared to the nine months ended April 30, 2013, due to an increase in personnel costs of $19.0 million largely due to an increase in headcount, an increase in allocated costs of $5.2 million, and an increase in development costs of $1.5 million to support continued investment in our future product and service offerings.

[0001327567-14-000013:mdna:100]
Sales and marketing expense increased $32.3 million, or 62.4%, for the three months ended April 30, 2014 compared to the three months ended April 30, 2013, due to an increase in personnel costs of $21.4 million largely due to an increase in headcount, an increase in allocated costs of $3.5 million, an increase in demand generation activities, trade shows, and other marketing activities of $2.6 million, an increase in travel and entertainment costs of $1.5 million, and an increase in professional services costs of $1.3 million.

[0001327567-14-000013:mdna:101]
Sales and marketing expense increased $88.0 million, or 62.8%, for the nine months ended April 30, 2014 compared to the nine months ended April 30, 2013, due to an increase in personnel costs of $59.8 million largely due to an increase in headcount, an increase in allocated costs of $11.1 million, an increase in travel and entertainment costs of $6.7 million, an increase in professional services costs of $5.3 million, and an increase in demand generation activities, trade shows, and other marketing activities of $3.1 million.

[0001327567-14-000013:mdna:102]
General and administrative expense increased $11.4 million, or 93.3%, for the three months ended April 30, 2014 compared to the three months ended April 30, 2013, due to an increase in professional services costs of $7.3 million, including increased expenses related to the IP litigation with Juniper of $3.5 million and expenses related to our acquisition of Cyvera of $3.6 million. The remaining increase was due to an increase in personnel costs of $2.6 million, largely due to an increase in headcount.

[0001327567-14-000013:mdna:103]
General and administrative expense increased $26.6 million, or 85.9%, for the nine months ended April 30, 2014 compared to the nine months ended April 30, 2013, due to an increase in professional services costs of $12.5 million, including expenses related to the IP litigation with Juniper of $7.0 million and expenses related to our acquisition of Cyvera and Morta of $4.0 million, and an increase in personnel costs of $9.2 million, largely due to an increase in headcount.

[0001327567-14-000013:mdna:104]
Legal settlement expense increased $121.2 million for the three months ended April 30, 2014 compared to the three months ended April 30, 2013 due to the recognition of an expense of $121.2 million for the settlement agreement with Juniper.

[0001327567-14-000013:mdna:105]
Legal settlement expense increased $141.2 million for the nine months ended April 30, 2014 compared to the nine months ended April 30, 2013 due to the recognition of an expense of $121.2 million for the settlement agreement with Juniper and $20.0 million for the Mutual Covenant Not to Sue and Release Agreement with Fortinet.

[0001327567-14-000013:mdna:106]
[same as prior period, unchanged from 0001327567-14-000005:mdna:131]

[0001327567-14-000013:mdna:107]
[same as prior period, unchanged from 0001327567-14-000005:mdna:98]

[0001327567-14-000013:mdna:108]
|  | Three Months Ended April 30, |  | Nine Months Ended April 30, |
|  | 2014 |  | 2013 |  | 2014 |  | 2013 |
|  | (dollars in thousands) |
| Provision for income taxes | $ | 1,272 |  |  | $ | 808 |  |  | $ | 5,125 |  |  | $ | 1,632 |  |
| Effective tax rate | (0.9 | )% |  | (12.5 | )% |  | (2.7 | )% |  | (13.9 | )% |

[0001327567-14-000013:mdna:109]
We recorded an income tax provision for the three and nine months ended April 30, 2014 due to federal, state, and foreign income taxes and foreign withholding taxes. The provision for income taxes increased for the three and nine months ended April 30, 2014 compared to the three and nine months ended April 30, 2013 due to increased U.S. taxable income and a shift in geographical mix of income due to global expansion.

[0001327567-14-000013:mdna:110]
[same as prior period, unchanged from 0001327567-14-000005:mdna:101]

[0001327567-14-000013:mdna:111]
|  | April 30, 2014 |  | July 31, 2013 |
|  | (in thousands) |
| Working capital | $ | 81,094 |  |  | $ | 323,597 |  |
| Cash, cash equivalents, and investments: |  |  |  |
| Cash and cash equivalents | $ | 234,790 |  |  | $ | 310,614 |  |
| Investments | 237,082 |  |  | 126,321 |  |
| Total cash, cash equivalents, and investments | $ | 471,872 |  |  | $ | 436,935 |  |
|  | Nine Months Ended April 30, |
| 2014 |  | 2013 |
|  | (in thousands) |
| Cash provided by operating activities | $ | 114,556 |  |  | $ | 72,789 |  |
| Cash used in investing activities | (229,306 | ) |  | (196,637 | ) |
| Cash provided by financing activities | 38,926 |  |  | 14,870 |  |
| Net decrease in cash and cash equivalents | $ | (75,824 | ) |  | $ | (108,978 | ) |

[0001327567-14-000013:mdna:112]
At April 30, 2014, our cash, cash equivalents, and investments of $471.9 million were held for working capital purposes, of which approximately $103.1 million was held outside of the United States. Our current plans do not include repatriating these funds. However, if these funds were needed for our domestic operations, we would be required to accrue and pay U.S. taxes to do so. There are no other restrictions on the use of these funds. We do not provide for federal income taxes on the undistributed earnings of our foreign subsidiaries, all of which we expect to reinvest outside of the United States indefinitely. If we were to repatriate these earnings to the United States, any associated income tax liability would be insignificant.

[0001327567-14-000013:mdna:113]
We believe that our cash flow from operations with existing cash and cash equivalents will be sufficient to meet our anticipated cash needs for the foreseeable future. Our future capital requirements will depend on many factors including our growth rate, the timing and extent of spending to support development efforts, the expansion of sales and marketing activities, the introduction of new and enhanced products and services offerings, the costs to acquire or invest in complementary businesses and technologies, the costs to ensure access to adequate manufacturing capacity, and the continuing market acceptance of our products. In addition, we may be required to pay additional taxes related to the acquisition of Cyvera if we transfer the acquired intellectual property out of Israel. We may choose to seek additional equity or debt financing. In the event that additional financing is required from outside sources, we may not be able to raise it on terms acceptable to us or at all. If we are unable to raise additional capital when desired, our business, operating results, and financial condition may be adversely affected.

[0001327567-14-000013:mdna:114]
[same as prior period, unchanged from 0001327567-14-000005:mdna:105]

[0001327567-14-000013:mdna:115]
[same as prior period, unchanged from 0001327567-14-000005:mdna:106]

[0001327567-14-000013:mdna:116]
Cash provided by operating activities during the nine months ended April 30, 2014 was $114.6 million, an increase of $41.8 million compared to the nine months ended April 30, 2013 due to changes in our assets and liabilities, partially offset by an increase in our net loss during the nine months ended April 30, 2014. Our net loss for the nine months ended April 30, 2014

[0001327567-14-000013:mdna:117]
- 29 -

[0001327567-14-000013:mdna:118]
included a $20.0 million payment for a mutual release of claims and an extension of the Mutual Covenant Note to Sue and Release Agreement with Fortinet for six more years. Changes in assets and liabilities during the nine months ended April 30, 2014 compared to the nine months ended April 30, 2013 include an increase in collections on accounts receivable and an increase in sales of subscriptions and support and maintenance contracts to new and existing customers as reflected by an increase in deferred revenue.

[0001327567-14-000013:mdna:119]
The change in accrued and other liabilities includes the accrual of $121.2 million related to the settlement agreement with Juniper. Pursuant to the settlement agreement, we are obligated to pay $75.0 million in cash during the three months ended July 31, 2014.

[0001327567-14-000013:mdna:120]
[same as prior period, unchanged from 0001327567-14-000005:mdna:109]

[0001327567-14-000013:mdna:121]
[same as prior period, unchanged from 0001327567-14-000005:mdna:110]

[0001327567-14-000013:mdna:122]
Cash used by investing activities during the nine months ended April 30, 2014 was $229.3 million, an increase of $32.7 million as compared to the nine months ended April 30, 2013. The increase was primarily due to business acquisitions and increased purchases of property, equipment, and other assets, partially offset by lower net purchases of available-for-sale investments during the nine months ended April 30, 2014.

[0001327567-14-000013:mdna:123]
[same as prior period, unchanged from 0001327567-14-000005:mdna:112]

[0001327567-14-000013:mdna:124]
[same as prior period, unchanged from 0001327567-14-000005:mdna:113]

[0001327567-14-000013:mdna:125]
Cash provided by financing activities during the nine months ended April 30, 2014 was $38.9 million, an increase of $24.1 million as compared to the nine months ended April 30, 2013. The increase was due to higher proceeds from the sale of shares through employee equity incentive plans during the nine months ended April 30, 2014. In addition, during the nine months ended April 30, 2013, we completed payments of our initial public offering costs.

[0001327567-14-000013:mdna:126]
[same as prior period, unchanged from 0001327567-14-000005:mdna:115]

[0001327567-14-000013:mdna:127]
Through April 30, 2014, we did not have any relationships with unconsolidated organizations or financial partnerships, such as structured finance or special purpose entities, that would have been established for the purpose of facilitating off-balance sheet arrangements or other contractually narrow or limited purposes.

[0001327567-14-000013:mdna:128]
[same as prior period, unchanged from 0001327567-14-000005:mdna:117]

[0001327567-14-000013:mdna:129]
[same as prior period, unchanged from 0001327567-14-000005:mdna:118]

[0001327567-14-000013:mdna:130]
[same as prior period, unchanged from 0001327567-14-000005:mdna:119]

[0001327567-14-000013:mdna:131]
Goodwill, Intangibles, and Other Long-Lived Assets

[0001327567-14-000013:mdna:132]
We make significant estimates, assumptions, and judgments when valuing goodwill and other purchased intangible assets in connection with the initial purchase price allocation of an acquired entity, as well as when evaluating impairment of goodwill and other purchased intangible assets on an ongoing basis. These estimates are based upon a number of factors, including historical experience, market conditions, and information obtained from the management of the acquired company. Critical estimates in valuing certain intangible assets include, but are not limited to, cash flows that an asset is expected to generate in the future, discount rates, the time and expenses that would be necessary to recreate the assets, and the profit margin a market participant would receive. The amounts and useful lives assigned to identified intangible assets impacts the amount and timing of future amortization expense.

[0001327567-14-000013:mdna:133]
- 30 -

[0001327567-14-000013:mdna:134]
We evaluate goodwill for impairment on an annual basis in our fourth fiscal quarter or more frequently if we believe impairment indicators exist. Goodwill is tested for impairment at the reporting unit level by comparing the reporting unit's carrying amount, including goodwill, to the fair value of the reporting unit. The fair value of the reporting unit is estimated using significant judgment based on a combination of the income and the market approaches. If the fair value of the reporting unit does not exceed the carrying amount of the net assets assigned to the reporting unit, then we perform the second step of the impairment test in order to determine the implied fair value of the reporting unit's goodwill. When the carrying amount of a reporting unit's goodwill exceeds its implied fair value, we record an impairment loss equal to the difference. Determining the fair value of a reporting unit is highly judgmental in nature and involves the use of significant estimates and assumptions. These estimates and assumptions include revenue growth rates and operating margins used to calculate projected future cash flows, operating trends, risk-adjusted discount rates, future economic and market conditions, and determination of appropriate market comparables. We base our fair value estimates on assumptions we believe to be reasonable but that are unpredictable and inherently uncertain. Actual future results may differ from those estimates.

[0001327567-14-000013:mdna:135]
[same as prior period, unchanged from 0001327567-14-000005:mdna:125]

[0001327567-14-000013:mdna:136]
[same as prior period, unchanged from 0001327567-14-000005:mdna:126]

[0001327567-14-000013:mdna:137]
[same as prior period, unchanged from 0001327567-14-000005:mdna:127]

[0001327567-14-000013:mdna:138]
[same as prior period, unchanged from 0001327567-14-000005:mdna:128]

[0001327567-14-000013:mdna:139]
[same as prior period, unchanged from 0001327567-14-000005:mdna:129]

[0001327567-14-000013:mdna:140]
[same as prior period, unchanged from 0001327567-14-000005:mdna:130]
