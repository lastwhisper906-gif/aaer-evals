# PANW notes — 0001327567-14-000013


## us-gaap:AvailableForSaleSecuritiesContinuousUnrealizedLossPositionFairValueTableTextBlock

[0001327567-14-000013:notes:1]
The following tables present our investments that were in an unrealized loss position as of April 30, 2014 and July 31, 2013 (in thousands):

[0001327567-14-000013:notes:2]
|  | April 30, 2014 |
|  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
|  | Fair Value |  | Unrealized Loss |  | Fair Value |  | Unrealized Loss |  | Fair Value |  | Unrealized Loss |
| Corporate debt securities | 16,766 |  |  | (6 | ) |  | — |  |  | — |  |  | 16,766 |  |  | (6 | ) |
| U.S. government and agency securities | 33,601 |  |  | (24 | ) |  | — |  |  | — |  |  | 33,601 |  |  | (24 | ) |
| Total | $ | 50,367 |  |  | $ | (30 | ) |  | $ | — |  |  | $ | — |  |  | $ | 50,367 |  |  | $ | (30 | ) |

[0001327567-14-000013:notes:3]
[same as prior period, unchanged from 0001327567-14-000005:notes:3]


## us-gaap:AvailableForSaleSecuritiesTextBlock

[0001327567-14-000013:notes:4]
The following tables summarize our unrealized gains and losses and fair value of investments as of April 30, 2014 and July 31, 2013 (in thousands):

[0001327567-14-000013:notes:5]
|  | April 30, 2014 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Estimated Fair Value |
| Certificates of deposit | $ | 3,000 |  |  | $ | 1 |  |  | $ | — |  |  | $ | 3,001 |  |
| Corporate debt securities | 45,957 |  |  | 22 |  |  | (6 | ) |  | 45,973 |  |
| U.S. government and agency securities | 192,064 |  |  | 68 |  |  | (24 | ) |  | 192,108 |  |
| Total | $ | 241,021 |  |  | $ | 91 |  |  | $ | (30 | ) |  | $ | 241,082 |  |

[0001327567-14-000013:notes:6]
[same as prior period, unchanged from 0001327567-14-000005:notes:6]


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001327567-14-000013:notes:7]
[same as prior period, unchanged from 0001327567-14-000005:notes:7]

[0001327567-14-000013:notes:8]
The accompanying condensed consolidated financial statements have been prepared in conformity with U.S. generally accepted accounting principles, consistent in all material respects with those applied in our Annual Report on Form 10-K for the fiscal year ended July 31, 2013. The condensed consolidated financial statements include all adjustments necessary for a fair presentation of our quarterly results. All adjustments are of a normal recurring nature. We have made estimates and judgments affecting the amounts reported in our condensed consolidated financial statements and the accompanying notes. The actual results that we experience may differ materially from our estimates. Certain prior period amounts have been reclassified to conform with current period presentation.


## us-gaap:BusinessAcquisitionProFormaInformationTextBlock

[0001327567-14-000013:notes:9]
The following table presents the unaudited pro forma financial information for the three and nine months ended April 30, 2014 and 2013, as though the companies were combined as of August 1, 2012 (in thousands):

[0001327567-14-000013:notes:10]
|  | Three Months Ended April 30, |  | Nine Months Ended April 30, |
|  | 2014 |  | 2013 |  | 2014 |  | 2013 |
| Total revenue | $ | 150,732 |  |  | $ | 101,295 |  |  | $ | 420,023 |  |  | $ | 283,739 |  |
| Net loss | $ | (149,776 | ) |  | $ | (10,744 | ) |  | $ | (210,276 | ) |  | $ | (23,502 | ) |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001327567-14-000013:notes:11]
[same as prior period, unchanged from 0001327567-14-000005:notes:9]

[0001327567-14-000013:notes:12]
Business Combinations

[0001327567-14-000013:notes:13]
Cyvera Ltd.

[0001327567-14-000013:notes:14]
On April 9, 2014, we completed our acquisition of Cyvera Ltd. (“Cyvera”), a privately-held cybersecurity company located in Tel Aviv, Israel. The acquisition extends our next-generation security platform with an innovative approach to preventing attacks on the endpoint. We have accounted for this transaction as a business combination in exchange for total consideration of approximately $177,647,000, which consisted of the following (in thousands):

[0001327567-14-000013:notes:15]
|  | Amount |
| Cash | $ | 90,170 |  |
| Common stock (1,281,000 shares) | 87,477 |  |
| Total | $ | 177,647 |  |

[0001327567-14-000013:notes:16]
As part of the acquisition, we agreed to replace Cyvera's unvested options with our restricted stock units with an estimated fair value of $6,353,000. Of the total estimated fair value, a portion was allocated to the purchase consideration and the remainder was allocated to future services and will be expensed over the remaining service periods on a straight-line basis as share-based compensation.

[0001327567-14-000013:notes:17]
In addition, we issued 276,000 shares of restricted common stock with a total fair value of $17,612,000 to certain Cyvera employees. The restriction on these shares will be released over a period of three years from the acquisition date, subject to continued employment. These shares were excluded from the purchase consideration and are being expensed over the remaining service periods on a straight-line basis as share-based compensation.

[0001327567-14-000013:notes:18]
We expensed the related acquisition costs in the amount of $3,583,000 in general and administrative expenses in the three and nine months ended April 30, 2014.

[0001327567-14-000013:notes:19]
The following table summarizes our preliminary allocation of the purchase consideration based on the fair value of assets acquired and liabilities assumed (in thousands):

[0001327567-14-000013:notes:20]
|  | Amount |
| Cash | $ | 6,930 |  |
| Goodwill | 144,992 |  |
| Identified intangible assets | 42,300 |  |
| Accrued and other liabilities, net | (6,950 | ) |
| Long-term deferred tax liability, net | (9,625 | ) |
| Total | $ | 177,647 |  |

[0001327567-14-000013:notes:21]
We expect to finalize the valuation as soon as practicable, but not later than 12 months from the acquisition date.

[0001327567-14-000013:notes:22]
[same as prior period, unchanged from 0001327567-14-000005:notes:14]

[0001327567-14-000013:notes:23]
|  | Fair Value |  | Estimated Useful Life |
| Developed technology | $ | 34,500 |  |  | 7 years |
| In-process research and development | 7,600 |  |  | N/A |
| Other | 200 |  |  | 2 years |
| Total | $ | 42,300 |  |  |  |

[0001327567-14-000013:notes:24]
Goodwill generated from this business combination is primarily attributable to the assembled workforce and synergies from combined selling opportunities of both network security products and endpoint security products. The goodwill is not tax deductible for Israeli income tax purposes.

[0001327567-14-000013:notes:25]
Cyvera’s operating results are included in our Condensed Consolidated Statements of Operations from the date of the acquisition and are considered immaterial for purposes of financial disclosures.

[0001327567-14-000013:notes:26]
The pro forma financial information for the three and nine months ended April 30, 2014 and 2013 has been calculated after adjusting the results of Cyvera to reflect the business combination accounting effects resulting from this acquisition as though the acquisition occurred as of August 1, 2012, including the amortization expense from acquired intangible assets and post-acquisition share-based compensation expense related to restricted common stock and the replacement of unvested Cyvera options. The pro forma financial information is for informational purposes only and is not indicative of the results of operations that would have been achieved if the acquisition had taken place at the beginning of our fiscal 2013.

[0001327567-14-000013:notes:27]
The pro forma financial information for the three and nine months ended April 30, 2014 and 2013 combines the historical results of the Company for the three and nine months ended April 30, 2014 and 2013 and the adjusted historical results of Cyvera for the three and nine months ended March 31, 2014 and 2013, due to differences in reporting periods and considering the date the Company acquired Cyvera.

[0001327567-14-000013:notes:28]
Morta Security, Inc.

[0001327567-14-000013:notes:29]
[same as prior period, unchanged from 0001327567-14-000005:notes:11]

[0001327567-14-000013:notes:30]
[same as prior period, unchanged from 0001327567-14-000005:notes:13]

[0001327567-14-000013:notes:31]
[same as prior period, unchanged from 0001327567-14-000005:notes:15]

[0001327567-14-000013:notes:32]
Morta’s operating results are included in our Condensed Consolidated Statements of Operations from the date of the acquisition and are considered immaterial for purposes of pro forma financial disclosures. Goodwill generated from this business combination is primarily attributable to human capital with threat intelligence experience and capabilities, and is not tax deductible for U.S. federal income tax purposes.

[0001327567-14-000013:notes:33]
[same as prior period, unchanged from 0001327567-14-000005:notes:17]

[0001327567-14-000013:notes:34]
On September 4, 2013 we entered into an agreement to purchase intellectual property for $5,000,000, which is being amortized over a weighted-average period of 13 years.


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock

[0001327567-14-000013:notes:35]
[same as prior period, unchanged from 0001327567-14-000005:notes:19]

[0001327567-14-000013:notes:36]
[same as prior period, unchanged from 0001327567-14-000005:notes:20]

[0001327567-14-000013:notes:37]
Palo Alto Networks, Inc. (the “Company,” “we,” “us,” or “our”), located in Santa Clara, California, was incorporated in March 2005 under the laws of the State of Delaware and commenced operations in April 2005. We offer a next-generation enterprise security platform that allows enterprises, service providers, and government entities to simultaneously empower and secure their organization by safely enabling the increasingly complex and rapidly growing number of applications running on their networks and preventing breaches stemming from targeted cyber attacks. Our enterprise security platform consists of three major elements: our Next-Generation Firewall, our Next-Generation Endpoint Protection, and our Next-Generation Threat Intelligence Cloud. Our Next-Generation Firewall delivers application, user, and content visibility and control as well as protection against network based cyber threats integrated within the firewall through our proprietary hardware and software architecture. Our Next-Generation Endpoint Protection protects against cyber attacks that aim to exploit software vulnerabilities on a broad variety of fixed and virtual endpoints. Our Next-Generation Threat Intelligence Cloud provides central intelligence capabilities as well as automation of delivery of preventative measures against cyber attacks. We primarily sell our products and services to end-customers through our channel partners and infrequently directly to end-customers. Our partners are supported by our sales and marketing organization in the Americas, in Europe, the Middle East, and Africa (EMEA), and in Asia Pacific and Japan (APAC).

[0001327567-14-000013:notes:38]
[same as prior period, unchanged from 0001327567-14-000005:notes:22]

[0001327567-14-000013:notes:39]
The condensed consolidated financial statements include our accounts and our wholly owned subsidiaries. All significant intercompany balances and transactions have been eliminated in consolidation.

[0001327567-14-000013:notes:40]
[same as prior period, unchanged from 0001327567-14-000005:notes:24]

[0001327567-14-000013:notes:41]
There have been no material changes to our significant accounting policies as of and for the three and nine months ended April 30, 2014, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended July 31, 2013, except for the inclusion of a policy related to business combinations, amortization of intangible assets, and broadening our policy on the Impairment of Long-Lived Assets to include policies related to goodwill and intangible assets.

[0001327567-14-000013:notes:42]
[same as prior period, unchanged from 0001327567-14-000005:notes:27]

[0001327567-14-000013:notes:43]
Amortization of Intangible Assets

[0001327567-14-000013:notes:44]
Purchased intangible assets with finite lives are carried at cost, less accumulated amortization. Amortization is computed over the estimated useful lives of the respective assets. Acquisition-related in-process research and development represents the fair value of incomplete research and development projects that have not reached technological feasibility as of the date of acquisition. Initially, these assets are not subject to amortization. Assets related to projects that have been completed are transferred to developed technology, which are subject to amortization, while assets related to projects that have been abandoned are impaired and expensed to research and development.

[0001327567-14-000013:notes:45]
Impairment of Goodwill, Intangible Assets, and Long-Lived Assets

[0001327567-14-000013:notes:46]
Goodwill is evaluated for impairment on an annual basis in the fourth quarter of our fiscal year, and whenever events or changes in circumstances indicate the carrying amount of goodwill may not be recoverable. We have elected to first assess qualitative factors to determine whether it is more likely than not that the fair value of our single reporting unit is less than its carrying amount. If we determine that it is more likely than not that the fair value of our single reporting unit is less than its carrying amount, then the two-step goodwill impairment test will be performed. The first step, identifying a potential impairment, compares the fair value of our single reporting unit with its carrying amount. If the carrying amount exceeds its fair value, the second step will be performed; otherwise, no further step is required. The second step, measuring the impairment loss, compares the implied fair value of the goodwill with the carrying amount of the goodwill. Any excess of the goodwill carrying amount over the implied fair value is recognized as an impairment loss.

[0001327567-14-000013:notes:47]
We evaluate events and changes in circumstances that could indicate carrying amounts of purchased intangible assets and long-lived assets may not be recoverable. When such events or changes in circumstances occur, we assess the recoverability of these assets by determining whether or not the carrying amount will be recovered through undiscounted expected future cash flows. If the total of the future undiscounted cash flows is less than the carrying amount of an asset, we record an impairment loss for the amount by which the carrying amount of the asset exceeds the fair value of the asset.

[0001327567-14-000013:notes:48]
[same as prior period, unchanged from 0001327567-14-000005:notes:31]

[0001327567-14-000013:notes:49]
In July 2013, the FASB issued ASU No. 2013-11, Income Taxes (Topic 740)-Presentation of an Unrecognized Tax Benefit When a Net Operating Loss Carryforward, a Similar Tax Loss, or a Tax Credit Carryforward Exists. The standard requires us to present an unrecognized tax benefit as a reduction of a deferred tax asset for a net operating loss (NOL) carryforward or other tax credit carryforward when settlement in this manner is available under applicable tax law. The guidance is effective for us in the first quarter of fiscal 2015 and will be applied prospectively. Early adoption is permitted. We do not believe the adoption of this guidance will have a material impact on our condensed consolidated financial statements.

[0001327567-14-000013:notes:50]
In February 2013, the FASB issued Accounting Standards Update No. 2013-02, Comprehensive Income (Topic 220)-Reporting of Amounts Reclassified Out of Accumulated Other Comprehensive Income. The standard requires entities to present (either on the face of the income statement or in the notes) the effects on the line items of the income statement for amounts reclassified out of accumulated other comprehensive income. The guidance was effective for us in the first quarter of fiscal 2014. Our adoption of this guidance did not impact our financial statements as the guidance is related to disclosure only and we did not have significant reclassifications out of accumulated other comprehensive income.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001327567-14-000013:notes:51]
Commitments and Contingencies

[0001327567-14-000013:notes:52]
Leases

[0001327567-14-000013:notes:53]
We lease our facilities under various non-cancelable operating leases, which expire through the year ending July 31, 2023.

[0001327567-14-000013:notes:54]
The following table presents details of the aggregate future non-cancelable minimum rental payments on our operating leases as of April 30, 2014 (in thousands):

[0001327567-14-000013:notes:55]
|  | Amount |
| Fiscal years ending July 31: |  |
| Remaining 2014 | $ | 2,930 |  |
| 2015 | 13,778 |  |
| 2016 | 14,018 |  |
| 2017 | 13,052 |  |
| 2018 | 11,774 |  |
| 2019 and thereafter | 52,300 |  |
| Committed gross lease payments | 107,852 |  |
| Less: proceeds from sublease rental | 10,700 |  |
| Net operating lease obligation | $ | 97,152 |  |

[0001327567-14-000013:notes:56]
Contract Manufacturer Commitments

[0001327567-14-000013:notes:57]
Our independent contract manufacturer procures components and assembles our products based on our forecasts. These forecasts are based on estimates of future demand for our products, which are in turn based on historical trends and an analysis from our sales and product marketing organizations, adjusted for overall market conditions. In order to reduce manufacturing lead times and plan for adequate supply, we may issue forecasts and orders for components and products that are non-cancelable. Obligations under contracts that we can cancel without a significant penalty are not included. As of April 30, 2014, we had $29,407,000 of open orders.

[0001327567-14-000013:notes:58]
Litigation

[0001327567-14-000013:notes:59]
In December 2011, Juniper Networks, Inc. ("Juniper") filed a complaint against us in the United States District Court for the District of Delaware alleging patent infringement. The complaint sought preliminary and permanent injunctions against infringement, treble damages, and attorneys' fees. On September 4, 2012, Juniper filed a motion to amend its complaint to allege that our appliances infringe two additional U.S. patents but also to withdraw its allegations as to a previously-asserted patent. This amended complaint was officially filed on September 25, 2012, pursuant to a stipulation between the parties. On October 12, 2012, we filed an answer to Juniper’s amended complaint, which denied that we infringed Juniper’s patents and asserted that Juniper’s patents were invalid. The Court issued an order on February 6, 2014, in which the Court construed several disputed claim limitations, granted Juniper’s motion for summary judgment of assignor estoppel, precluding us from raising in the litigation challenges to the validity of Juniper’s patents, denied Juniper’s motion for summary judgment of infringement, and granted in part and denied in part our motion for summary judgment of non-infringement. A trial took place in February 2014. Following the trial, the jury was unable to reach a verdict and the Court declared a mistrial.

[0001327567-14-000013:notes:60]
On September 13, 2012, we filed with the U.S. Patent and Trademark Office requests for inter partes reexamination of five of the six patents asserted by Juniper in its original complaint. On October 19 and December 3, 2012, the U.S. Patent and Trademark Office granted our requests for reexamination for three patents, rejecting a number of the claims asserted in the litigation, and on November 15 and 26, 2012, the U.S. Patent and Trademark Office denied our requests for reexamination as to two other patents. On June 20, 2013 and July 23, 2013, we filed with the U.S. Patent and Trademark Office petitions for inter partes review for two other patents asserted by Juniper in the litigation. A hearing to resolve claim construction issues, as well as motions for summary judgment, was heard on November 15, 2013.

[0001327567-14-000013:notes:61]
On September 30, 2013, we filed a lawsuit against Juniper in the United States District Court for the Northern District of California. The lawsuit alleged that Juniper’s products infringe three of our U.S. patents, and sought monetary damages and a permanent injunction. On November 21, 2013, Juniper filed an answer and counterclaims in a separate action in the United States District Court for the Northern District of California. In its counterclaims Juniper sought a declaration that the asserted patents owned by us are not infringed and are invalid. Juniper’s counterclaims also asserted that our products infringe three additional Juniper patents.

[0001327567-14-000013:notes:62]
On May 27, 2014, we entered into a Settlement, Release and Cross-License Agreement (the “settlement agreement”) with Juniper to resolve all pending litigation between the parties, including those discussed above. Refer to Note 12 Subsequent Events for more information on the settlement agreement.

[0001327567-14-000013:notes:63]
In addition to the above matter, we are subject to legal proceedings, claims, and litigation arising in the ordinary course of business, including intellectual property litigation. Such matters are subject to many uncertainties and outcomes are not predictable with assurance. We accrue for contingencies when we believe that a loss is probable and that we can reasonably estimate the amount of any such loss. We have made an assessment of the probability of incurring any such losses and whether or not those losses are estimable.

[0001327567-14-000013:notes:64]
To the extent there is a reasonable possibility that a loss exceeding amounts already recognized may be incurred and the amount of such additional loss would be material, we will either disclose the estimated additional loss or state that such an estimate cannot be made.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001327567-14-000013:notes:65]
[same as prior period, unchanged from 0001327567-14-000005:notes:47]

[0001327567-14-000013:notes:66]
[same as prior period, unchanged from 0001327567-14-000005:notes:48]

[0001327567-14-000013:notes:67]
[same as prior period, unchanged from 0001327567-14-000005:notes:49]

[0001327567-14-000013:notes:68]
|  | Options Outstanding |
|  | Number of Shares |  | Weighted- Average Exercise Price |  | Weighted- Average Remaining Contractual Term (Years) |  | Aggregate Intrinsic Value |
| Balance—July 31, 2013 | 10,033 |  |  | $ | 11.74 |  |  | 7.8 |  | $ | 373,228 |  |
| Options granted | — |  |  | — |  |  |  |  |  |
| Options forfeited | (488 | ) |  | 15.17 |  |  |  |  |  |
| Options exercised | (2,949 | ) |  | 8.62 |  |  |  |  |  |
| Balance—April 30, 2014 | 6,596 |  |  | 12.88 |  |  | 7.3 |  | $ | 334,417 |  |
| Options vested and expected to vest—April 30, 2014 | 6,410 |  |  | $ | 12.77 |  |  | 7.3 |  | $ | 325,692 |  |
| Options exercisable—April 30, 2014 | 3,668 |  |  | $ | 10.25 |  |  | 7.0 |  | $ | 195,614 |  |

[0001327567-14-000013:notes:69]
[same as prior period, unchanged from 0001327567-14-000005:notes:51]

[0001327567-14-000013:notes:70]
[same as prior period, unchanged from 0001327567-14-000005:notes:52]

[0001327567-14-000013:notes:71]
|  | RSUs Outstanding |
|  | Number of Shares |  | Weighted- Average Grant-Date Fair Value Per Share |  | Weighted- Average Remaining Contractual Term (Years) |  | Aggregate Intrinsic Value |
| Balance—July 31, 2013 | 2,241 |  |  | $ | 54.36 |  |  | 1.5 |  | $ | 109,675 |  |
| RSUs granted | 4,073 |  |  | 56.77 |  |  |  |  |  |
| RSUs vested | (646 | ) |  | 55.95 |  |  |  |  |  |
| RSUs forfeited | (358 | ) |  | 55.29 |  |  |  |  |  |
| Balance—April 30, 2014 | 5,310 |  |  | $ | 55.95 |  |  | 1.5 |  | $ | 337,610 |  |
| RSUs vested and expected to vest—April 30, 2014 | 4,782 |  |  | $ | 55.89 |  |  | 1.4 |  | $ | 304,040 |  |

[0001327567-14-000013:notes:72]
[same as prior period, unchanged from 0001327567-14-000005:notes:54]

[0001327567-14-000013:notes:73]
The following table presents the stock activity and the total number of shares available for grant as of April 30, 2014 (in thousands):

[0001327567-14-000013:notes:74]
|  | Number of Shares |
| Balance—July 31, 2013 | 8,932 |  |
| Authorized | 3,223 |  |
| RSUs granted | (4,073 | ) |
| Repurchased | 27 |  |
| Options forfeited | 488 |  |
| RSUs forfeited | 358 |  |
| Balance—April 30, 2014 | 8,955 |  |

[0001327567-14-000013:notes:75]
[same as prior period, unchanged from 0001327567-14-000005:notes:57]

[0001327567-14-000013:notes:76]
Compensation expense recognized in connection with the 2012 Employee Stock Purchase Plan was $1,142,000 and $3,217,000 for the three and nine months ended April 30, 2014, respectively, and $1,132,000 and $3,943,000 for the three and nine months ended April 30, 2013, respectively.

[0001327567-14-000013:notes:77]
[same as prior period, unchanged from 0001327567-14-000005:notes:59]

[0001327567-14-000013:notes:78]
[same as prior period, unchanged from 0001327567-14-000005:notes:60]

[0001327567-14-000013:notes:79]
|  | Three Months Ended April 30, |  | Nine Months Ended April 30, |
|  | 2014 |  | 2013 |  | 2014 |  | 2013 |
| Risk-free interest rate | 0.1% |  | 0.1% |  | 0.1% |  | 0.1% |
| Expected term (years) | <1 year |  | <1 year |  | <1 year |  | <1 year |
| Volatility | 41% |  | 41% |  | 40% |  | 41% |
| Dividend yield | —% |  | —% |  | —% |  | —% |

[0001327567-14-000013:notes:80]
[same as prior period, unchanged from 0001327567-14-000005:notes:62]

[0001327567-14-000013:notes:81]
|  | Three Months Ended April 30, |  | Nine Months Ended April 30, |
|  | 2014 |  | 2013 |  | 2014 |  | 2013 |
| Cost of revenue | $ | 3,156 |  |  | $ | 1,364 |  |  | $ | 7,311 |  |  | $ | 2,799 |  |
| Research and development | 8,666 |  |  | 3,024 |  |  | 17,825 |  |  | 6,687 |  |
| Sales and marketing | 12,372 |  |  | 5,686 |  |  | 29,050 |  |  | 13,919 |  |
| General and administrative | 3,798 |  |  | 2,560 |  |  | 12,601 |  |  | 6,325 |  |
| Total | $ | 27,992 |  |  | $ | 12,634 |  |  | $ | 66,787 |  |  | $ | 29,730 |  |

[0001327567-14-000013:notes:82]
At April 30, 2014, total compensation cost related to unvested share-based awards granted to employees under our stock plans but not yet recognized was $282,866,000, net of estimated forfeitures. This cost is expected to be amortized on a straight-line basis over a weighted-average period of three years. Future grants will increase the amount of compensation expense to be recorded in these periods.

[0001327567-14-000013:notes:83]
During the nine months ended April 30, 2014, we accelerated the vesting of certain share-based awards and as a result, in the three and nine months ended April 30, 2014, we recorded compensation expense within general and administrative expense of $62,000 and $3,446,000, respectively.

[0001327567-14-000013:notes:84]
During the three months ended October 31, 2012, we modified the terms of certain share-based awards and as a result, in the three and nine months ended April 30, 2013, we recorded compensation expense within sales and marketing expense of nil and $1,861,000, respectively.


## us-gaap:EarningsPerShareTextBlock

[0001327567-14-000013:notes:85]
[same as prior period, unchanged from 0001327567-14-000005:notes:67]

[0001327567-14-000013:notes:86]
Basic net income (loss) per common share is computed by dividing net income (loss) by basic weighted-average shares outstanding during the period. Diluted net income (loss) per share is computed by dividing net income (loss) by diluted weighted-average shares outstanding, including potentially dilutive securities.

[0001327567-14-000013:notes:87]
[same as prior period, unchanged from 0001327567-14-000005:notes:70]

[0001327567-14-000013:notes:88]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 30, |  | April 30, |
|  | 2014 |  | 2013 |  | 2014 |  | 2013 |
| Net loss | $ | (146,587 | ) |  | $ | (7,282 | ) |  | $ | (194,394 | ) |  | $ | (13,410 | ) |
| Weighted-average shares used to compute net loss per share, basic and diluted | 74,967 |  |  | 69,575 |  |  | 73,127 |  |  | 67,980 |  |
| Net loss per share, basic and diluted | $ | (1.96 | ) |  | $ | (0.10 | ) |  | $ | (2.66 | ) |  | $ | (0.20 | ) |

[0001327567-14-000013:notes:89]
The following outstanding options, RSUs, and ESPP shares were excluded from the computation of diluted net loss per common share for the periods presented as their effects would have been antidilutive (in thousands):

[0001327567-14-000013:notes:90]
|  | April 30, 2014 |  | April 30, 2013 |
| Options to purchase common stock | 6,596 |  |  | 10,637 |  |
| RSUs | 5,310 |  |  | 1,798 |  |
| ESPP shares | 41 |  |  | — |  |


## us-gaap:FairValueAssetsAndLiabilitiesMeasuredOnRecurringAndNonrecurringBasisTableTextBlock

[0001327567-14-000013:notes:91]
[same as prior period, unchanged from 0001327567-14-000005:notes:74]

[0001327567-14-000013:notes:92]
|  |  | April 30, 2014 |  | July 31, 2013 |
|  |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Cash equivalents: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Certificates of deposit |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,822 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,822 |  |
| U.S. government and agency securities |  | — |  |  | 4,000 |  |  | — |  |  | 4,000 |  |  | — |  |  | 46,700 |  |  | — |  |  | 46,700 |  |
| Money market funds |  | — |  |  | — |  |  | — |  |  | — |  |  | 131,845 |  |  | — |  |  | — |  |  | 131,845 |  |
| Total cash equivalents |  | — |  |  | 4,000 |  |  | — |  |  | 4,000 |  |  | 133,667 |  |  | 46,700 |  |  | — |  |  | 180,367 |  |
| Short-term investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate debt securities |  | — |  |  | 27,583 |  |  | — |  |  | 27,583 |  |  | — |  |  | 32,834 |  |  | — |  |  | 32,834 |  |
| U.S. government and agency securities |  | — |  |  | 105,597 |  |  | — |  |  | 105,597 |  |  | — |  |  | 76,173 |  |  | — |  |  | 76,173 |  |
| Total short-term investments |  | — |  |  | 133,180 |  |  | — |  |  | 133,180 |  |  | — |  |  | 109,007 |  |  | — |  |  | 109,007 |  |
| Long-term investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Certificates of deposit |  | — |  |  | 3,001 |  |  | — |  |  | 3,001 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Corporate debt securities |  | — |  |  | 18,390 |  |  | — |  |  | 18,390 |  |  | — |  |  | 12,317 |  |  | — |  |  | 12,317 |  |
| U.S. government and agency securities |  | — |  |  | 82,511 |  |  | — |  |  | 82,511 |  |  | — |  |  | 4,997 |  |  | — |  |  | 4,997 |  |
| Total long-term investments |  | — |  |  | 103,902 |  |  | — |  |  | 103,902 |  |  | — |  |  | 17,314 |  |  | — |  |  | 17,314 |  |
| Other assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Restricted cash |  | 1,220 |  |  | — |  |  | — |  |  | 1,220 |  |  | 1,221 |  |  | — |  |  | — |  |  | 1,221 |  |
| Total other assets |  | 1,220 |  |  | — |  |  | — |  |  | 1,220 |  |  | 1,221 |  |  | — |  |  | — |  |  | 1,221 |  |
| Total assets measured at fair value |  | $ | 1,220 |  |  | $ | 241,082 |  |  | $ | — |  |  | $ | 242,302 |  |  | $ | 134,888 |  |  | $ | 173,021 |  |  | $ | — |  |  | $ | 307,909 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001327567-14-000013:notes:93]
[same as prior period, unchanged from 0001327567-14-000005:notes:76]

[0001327567-14-000013:notes:94]
[same as prior period, unchanged from 0001327567-14-000005:notes:77]

[0001327567-14-000013:notes:95]
[same as prior period, unchanged from 0001327567-14-000005:notes:78]

[0001327567-14-000013:notes:96]
[same as prior period, unchanged from 0001327567-14-000005:notes:79]

[0001327567-14-000013:notes:97]
[same as prior period, unchanged from 0001327567-14-000005:notes:80]


## us-gaap:IncomeTaxDisclosureTextBlock

[0001327567-14-000013:notes:98]
[same as prior period, unchanged from 0001327567-14-000005:notes:81]

[0001327567-14-000013:notes:99]
Our provision for income taxes for the three and nine months ended April 30, 2014 reflects an effective tax rate of negative 1% and negative 3%, respectively. Our effective tax rates for these periods were negative due to the fact that we recorded a provision for income taxes on year-to-date losses. The key components of our income tax provision, and the related effective tax rate, consist of foreign tax losses which derive no benefit, non-deductible share-based compensation and foreign withholding taxes. As compared to the same periods last year, our negative effective tax rate changed due to fluctuations in our overall loss before income taxes and the geographic mix of income due to global expansion.

[0001327567-14-000013:notes:100]
Our provision for income taxes for the three and nine months ended April 30, 2013 reflects an effective tax rate of negative 12% and negative 14%, respectively, and consists of foreign income and withholding taxes.


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001327567-14-000013:notes:101]
[same as prior period, unchanged from 0001327567-14-000005:notes:84]

[0001327567-14-000013:notes:102]
[same as prior period, unchanged from 0001327567-14-000005:notes:85]

[0001327567-14-000013:notes:103]
The following table presents details of our goodwill during the nine months ended April 30, 2014 (in thousands):

[0001327567-14-000013:notes:104]
|  | Gross Carrying Amount |  | Accumulated Impairment Loss |  | Net Carrying Amount |
| Balance as of July 31, 2013 | $ | — |  |  | $ | — |  |  | $ | — |  |
| Goodwill acquired | 155,086 |  |  | — |  |  | 155,086 |  |
| Balance as of April 30, 2014 | $ | 155,086 |  |  | $ | — |  |  | $ | 155,086 |  |

[0001327567-14-000013:notes:105]
[same as prior period, unchanged from 0001327567-14-000005:notes:88]

[0001327567-14-000013:notes:106]
The following tables present details of our purchased intangible assets as of April 30, 2014 and July 31, 2013 (in thousands):

[0001327567-14-000013:notes:107]
|  | April 30, 2014 |
|  | Gross Carrying Amount |  | Accumulated Amortization |  | Net Carrying Amount |
| Intangible assets with finite lives: |  |  |  |  |  |
| Developed technology | $ | 34,500 |  |  | $ | (411 | ) |  | $ | 34,089 |  |
| Acquired intellectual property | 6,546 |  |  | (753 | ) |  | 5,793 |  |
| In-process research and development held for defensive purposes | 1,900 |  |  | (212 | ) |  | 1,688 |  |
| Other | 500 |  |  | (57 | ) |  | 443 |  |
| Total intangible assets with finite lives | 43,446 |  |  | (1,433 | ) |  | 42,013 |  |
| In-process research and development with indefinite lives | 7,600 |  |  | — |  |  | 7,600 |  |
| Total purchased intangible assets | $ | 51,046 |  |  | $ | (1,433 | ) |  | $ | 49,613 |  |

[0001327567-14-000013:notes:108]
[same as prior period, unchanged from 0001327567-14-000005:notes:91]

[0001327567-14-000013:notes:109]
Amortization expense was $820,000 and $1,245,000 for the three and nine months ended April 30, 2014, respectively, and $42,000 and $68,000 for the three and nine months ended April 30, 2013, respectively.

[0001327567-14-000013:notes:110]
The following table summarizes our estimated future amortization expense of intangible assets with finite lives by type as of April 30, 2014 (in thousands):

[0001327567-14-000013:notes:111]
|  | Fiscal Years Ending July 31, |
|  | Remaining 2014 |  | 2015 |  | 2016 |  | 2017 |  | 2018 |  | 2019 and Thereafter |
| Developed technology | $ | 1,232 |  |  | $ | 4,928 |  |  | $ | 4,928 |  |  | $ | 4,928 |  |  | $ | 4,928 |  |  | $ | 13,145 |  |
| Acquired intellectual property | 205 |  |  | 761 |  |  | 704 |  |  | 611 |  |  | 484 |  |  | 3,028 |  |
| In-process research and development held for defensive purposes | 158 |  |  | 633 |  |  | 633 |  |  | 264 |  |  | — |  |  | — |  |
| Other | 63 |  |  | 250 |  |  | 130 |  |  | — |  |  | — |  |  | — |  |
| Total future amortization expense | $ | 1,658 |  |  | $ | 6,572 |  |  | $ | 6,395 |  |  | $ | 5,803 |  |  | $ | 5,412 |  |  | $ | 16,173 |  |


## us-gaap:InvestmentsClassifiedByContractualMaturityDateTableTextBlock

[0001327567-14-000013:notes:112]
The following table summarizes the amortized cost and fair value of our investments as of April 30, 2014, by contractual years-to-maturity (in thousands):

[0001327567-14-000013:notes:113]
|  | Amortized Cost |  | Fair Value |
| Due within one year | $ | 137,154 |  |  | $ | 137,180 |  |
| Due within one to two years | 103,867 |  |  | 103,902 |  |
| Total | $ | 241,021 |  |  | $ | 241,082 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001327567-14-000013:notes:114]
Investments

[0001327567-14-000013:notes:115]
Unrealized losses related to these investments are due to interest rate fluctuations as opposed to credit quality. In addition, we do not intend to sell and it is not more likely than not that we would be required to sell these investments before recovery of their amortized cost basis, which may be at maturity. As a result, there is no other-than-temporary impairment for these investments at April 30, 2014.


## us-gaap:LegalMattersAndContingenciesTextBlock

[0001327567-14-000013:notes:116]
On January 27, 2014, we executed a Mutual Covenant Not to Sue and Release Agreement with Fortinet, Inc., thereby extending an existing covenant for six more years. We evaluated the transaction as a multiple-element arrangement and allocated the one-time payment that we made in the amount of $20,000,000 to each identifiable element using its relative fair value. Based on our estimates of fair value, we determined that the primary benefit of the arrangement is avoided litigation cost and the release of any potential past claims, with no material value attributable to future use or benefit. Accordingly, we recorded a $20,000,000 settlement charge within operating expenses during the three months ended January 31, 2014.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001327567-14-000013:notes:117]
Related Party Transactions

[0001327567-14-000013:notes:118]
Certain members of our board of directors serve as board members or executive officers of certain of our customers and in some cases are also investors of these customers. We believe these transactions with related party customers are carried out on terms that are consistent with similar transactions with our comparable customers. We had sales transactions with significant related party customers of $1,619,000 and $3,776,000 for the three and nine months ended April 30, 2014, respectively, and $903,000 and $2,381,000 for the three and nine months ended April 30, 2013, respectively. Amounts payable to and due from related party customers were not material at April 30, 2014.


## us-gaap:SubsequentEventsTextBlock

[0001327567-14-000013:notes:119]
Subsequent Events

[0001327567-14-000013:notes:120]
On May 27, 2014, we entered into a Settlement, Release and Cross-License Agreement with Juniper, whereby we resolved all pending litigation matters. Under the terms of the settlement agreement, we agreed to pay Juniper a one-time settlement amount of approximately $175,000,000, which was comprised of $75,000,000 in cash, 1,081,000 shares of our common stock with an approximate value of $70,000,000, and a warrant to purchase 463,000 shares of our common stock with an approximate value of $30,000,000, in exchange for the following:

[0001327567-14-000013:notes:121]
| • | Mutual dismissal with prejudice of all pending litigation between the parties and general release of all liability for Palo Alto Networks and Juniper, |

[0001327567-14-000013:notes:122]
| • | Cross-license between both parties for the patents-in-suit and associated family members and counterparts worldwide for the life of the patents, and |

[0001327567-14-000013:notes:123]
| • | Mutual covenant not to sue for infringement of any other patents for a period of eight years. |

[0001327567-14-000013:notes:124]
For accounting purposes, the fair value of the total consideration as of the settlement date was $182,473,000 . The fair values of the common stock and warrant were measured using the closing price of our common stock on the settlement date.

[0001327567-14-000013:notes:125]
We accounted for the settlement agreement as a multiple element arrangement and allocated the fair value of the consideration as of the settlement date to the identifiable elements based on their estimated fair values. Of the total settlement amount, $61,300,000 was allocated to the licensing of intellectual property, $54,300,000 was allocated to the mutual dismissal of claims, and the remaining amount was allocated to the mutual covenant not to sue. The mutual dismissal of claims and the covenant not to sue have no identifiable future benefit, and as a result we accrued a settlement charge within operating expenses as of and for the three and nine months ended April 30, 2014. The licensing of intellectual property will be recorded in our fiscal fourth quarter and will be amortized over the estimated period of benefit of five years.

[0001327567-14-000013:notes:126]
The warrant entitles Juniper to purchase up to 463,000 shares of common stock at an exercise price of $0.0001 per share and will expire seven months from the date of its issuance. Once issued, the liability-classified warrant will be remeasured through earnings at the end of each reporting period until exercised. The amount of future remeasurement is undeterminable and will be driven predominantly by increases or decreases in our stock price.
