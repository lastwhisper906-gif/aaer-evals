# PANW 8-K — 0001193125-14-215060 filed 2014-05-28

## item codes, every 8-K on or before 2014-06-03

- 2014-05-30 0001193125-14-218158 — 2.02 — amendment, the index does not say of what
- 2014-05-28 0001193125-14-215060 — 1.01, 2.02, 3.02, 9.01
- 2014-04-11 0001193125-14-140511 — 2.01, 3.02, 7.01, 9.01
- 2014-03-24 0001193125-14-111318 — 1.01, 3.02, 7.01, 9.01
- 2014-03-13 0001327567-14-000009 — 5.02
- 2014-02-24 0001193125-14-063754 — 2.02, 9.01
- 2013-12-12 0001327567-13-000040 — 5.07
- 2013-11-25 0001327567-13-000033 — 2.02, 9.01
- 2013-09-30 0001193125-13-384966 — 8.01
- 2013-09-09 0001193125-13-361421 — 2.02, 9.01
- 2013-05-30 0001193125-13-241542 — 2.02, 5.02, 9.01
- 2013-03-11 0001193125-13-101082 — 5.02, 9.01
- 2013-02-28 0001193125-13-084193 — 2.02, 9.01
- 2012-12-14 0001193125-12-503335 — 5.07
- 2012-12-06 0001193125-12-493700 — 2.02, 9.01
- 2012-09-24 0001193125-12-401534 — 1.01, 2.03
- 2012-09-20 0001193125-12-398433 — 5.02, 9.01
- 2012-09-10 0001193125-12-386605 — 2.02, 9.01

## late-filing notifications on or before 2014-06-03

- none on or before 2014-06-03

## item 2.02 — earnings release, exhibit 99.1

[0001193125-14-215060:8k_2_02:1]
EX-99.1
3
d734043dex991.htm
EX-99.1

[0001193125-14-215060:8k_2_02:2]
EX-99.1

[0001193125-14-215060:8k_2_02:3]
Exhibit 99.1

[0001193125-14-215060:8k_2_02:4]
Palo Alto Networks Reports Fiscal Third Quarter 2014 Financial Results and Announces Settlement of Litigation with Juniper Networks

[0001193125-14-215060:8k_2_02:5]
|  | • |  | Fiscal third quarter total revenue grows 49 percent year-over-year to a record $150.7 million |

[0001193125-14-215060:8k_2_02:6]
|  | • |  | Billings grow 46 percent year-over-year to a record $193.9 million |

[0001193125-14-215060:8k_2_02:7]
|  | • |  | Product revenue grows 38 percent year-over-year to a record $84.1 million; recurring subscription revenue grows 71 percent year-over-year to a record $32.0 million |

[0001193125-14-215060:8k_2_02:8]
|  | • |  | Deferred revenue grows 68 percent year-over-year to a record $367.9 million |

[0001193125-14-215060:8k_2_02:9]
SANTA CLARA,
Calif., May 28, 2014 – Palo Alto Networks, Inc. (NYSE: PANW) today announced financial results for its fiscal third quarter of 2014 ended April 30, 2014.

[0001193125-14-215060:8k_2_02:10]
Total revenue for the fiscal third quarter grew 49 percent year-over-year to a record $150.7 million, compared with $101.3 million in the fiscal third quarter
of 2013. GAAP net loss for the fiscal third quarter was $139.1 million, or $1.86 per diluted share, compared with a net loss of $7.3 million, or $0.10 per diluted share, in the fiscal third quarter of 2013.

[0001193125-14-215060:8k_2_02:11]
Palo Alto Networks recorded fiscal third quarter non-GAAP net income of $8.7 million, or $0.11 per diluted share, compared with non-GAAP net income of $5.3
million, or $0.07 per diluted share, in the fiscal third quarter of 2013. A reconciliation between GAAP and non-GAAP information is contained in the tables below.

[0001193125-14-215060:8k_2_02:12]
“We reported record revenue in our third quarter driven by strong customer demand for our next-generation enterprise security platform. We achieved the
highest rate of new customer acquisition in our history and now serve more than 17,000 customers globally to address their security needs and prevent increasingly sophisticated and complex cyber attacks from compromising an organization’s
critical assets,” said Mark McLaughlin, president and chief executive officer of Palo Alto Networks. “We also announced this afternoon that we have reached a settlement with Juniper Networks of all litigation matters between us; this
allows us to further focus our resources and time on our customers and growing our business.”

[0001193125-14-215060:8k_2_02:13]
“Year-over-year revenue growth of 49 percent was driven by our land, expand and retain model, as product,
recurring subscription and support revenue all delivered substantial growth,” said Steffan Tomlinson, chief financial officer of Palo Alto Networks. “Additionally, we continue to demonstrate the power of our hybrid SaaS model as gross
margin and operating margin improved sequentially, and we generated $28.4 million of free cash flow in the quarter, bringing our fiscal year to date total to $83.2 million.”

[0001193125-14-215060:8k_2_02:14]
Recent Highlights

[0001193125-14-215060:8k_2_02:15]
|  | • |  | Reached a settlement with Juniper Networks, the terms of which provide that both parties will dismiss all litigation; both parties will license the patents at issue in all outstanding suits to each other for the life of the patents; both parties will also enter into a covenant not to sue each other for patent infringement for eight years; and Palo Alto Networks will pay Juniper Networks a one-time settlement amount of approximately $175 million, consisting of $75 million in cash, approximately $70 million in shares of common stock and a warrant to purchase approximately $30 million of common stock. |

[0001193125-14-215060:8k_2_02:16]
|  | • |  | Positioned in the “Leaders” quadrant of Gartner, Inc.’s April 2014 Magic Quadrant for Enterprise Network Firewalls; this is the third consecutive year in which Palo Alto Networks has been recognized as a leader in the Magic Quadrant for Enterprise Firewall report.1 |

[0001193125-14-215060:8k_2_02:17]
|  | • |  | Completed the acquisition of Cyvera Ltd., a privately held cybersecurity company located in Tel Aviv, Israel; with the addition of Cyvera’s unique endpoint protection capabilities to the company’s security platform, Palo Alto Networks can provide protection across the enterprise, extending prevention technology from the network to the endpoint. |

[0001193125-14-215060:8k_2_02:18]
|  | • |  | Strengthened our strategic partnership with VMware by announcing a new reseller agreement and general availability of an integrated offering for automating and accelerating security deployments in the software-defined data center. |

[0001193125-14-215060:8k_2_02:19]
|  | • |  | Announced a global managed security services agreement with NTT Com Security (formerly Integralis) under which NTT Com Security will provide its extensive implementation, integration, and managed security services around the Palo Alto Networks security platform. |

[0001193125-14-215060:8k_2_02:20]
| 1 | Gartner, “Magic Quadrant for Enterprise Network Firewalls”, Greg Young, Adam Hils, Jeremy D’Hoinne; April 15, 2014. |

[0001193125-14-215060:8k_2_02:21]
Conference Call Information

[0001193125-14-215060:8k_2_02:22]
Palo Alto Networks will host a conference call for analysts and investors to discuss its fiscal third quarter of 2014 results and outlook for its fiscal fourth
quarter of 2014 today at 4:30 PM Eastern time / 1:30 PM Pacific time. Open to the public, investors may access the call by dialing 1-877-280-4959 or 857-244-7316 and entering the passcode 37864312. A live audio webcast of the conference call along
with supplemental financial information will also be accessible from the “Investors” section of the company’s website at investors.paloaltonetworks.com. Following the webcast, an archived version will be available on the website
for one year. A telephonic replay of the call will be available two hours after the call and will run for five business days and may be accessed by dialing 1-888-286-8010 or 617-801-6888 and entering the passcode 58471222.

[0001193125-14-215060:8k_2_02:23]
Forward-Looking Statements

[0001193125-14-215060:8k_2_02:24]
This press release contains
forward-looking statements that involve risks and uncertainties, including statements regarding the settlement of the company’s litigation with Juniper Networks and continued momentum in the company’s business. There are a significant
number of factors that could cause actual results to differ materially from statements made in this press release, including: the need to receive formal dismissal of the litigation by the relevant courts in Delaware and California; Palo Alto
Networks’ limited operating history; risks associated with Palo Alto Networks’ rapid growth, particularly outside of the U.S.; rapidly evolving technological developments in the market for network security products; and general market,
political, economic and business conditions.

[0001193125-14-215060:8k_2_02:25]
Additional risks and uncertainties that could affect Palo Alto Networks’ financial results are included
under the captions “Risk Factors” and “Management’s Discussion and Analysis of Financial Condition and Results of Operations,” in the company’s quarterly report on Form 10-Q filed with the SEC on February 24, 2014,
which is available on the company’s website at investors.paloaltonetworks.com and on the SEC’s website at www.sec.gov. Additional information will also be set forth in other filings that the company makes with the SEC from time to time.
All forward-looking statements in this press release are based on information available to the company as of the date hereof, and Palo Alto Networks does not assume any obligation to update the forward-looking statements provided to reflect events
that occur or circumstances that exist after the date on which they were made.

[0001193125-14-215060:8k_2_02:26]
Non-GAAP Financial Measures

[0001193125-14-215060:8k_2_02:27]
Palo Alto Networks has provided in this release financial information that has not been prepared in accordance with generally accepted accounting principles in
the United States (GAAP). The company uses these non-GAAP financial measures internally in analyzing its financial results and believes that the use of these non-GAAP financial measures is useful to investors as an additional tool to evaluate
ongoing operating results and trends and in comparing the company’s financial results with other companies in its industry, many of which present similar non-GAAP financial measures.

[0001193125-14-215060:8k_2_02:28]
Non-GAAP financial measures are not meant to be considered in isolation or as a substitute for comparable GAAP financial measures, and should be read only in
conjunction with the company’s consolidated financial statements prepared in accordance with GAAP. A reconciliation of the company’s non-GAAP financial measures to their most directly comparable GAAP measures has been provided in the
financial statement tables included in this press release, and investors are encouraged to review the reconciliation.

[0001193125-14-215060:8k_2_02:29]
Non-GAAP net income and diluted
net income per share. Palo Alto Networks defines non-GAAP net income as net income (loss) plus share-based compensation expense, tax adjustments related to the valuation allowance on deferred tax assets, expenses related to IP litigation,
legal settlement expenses, and acquisition related costs. Palo Alto Networks believes that excluding these items provides management and investors with greater visibility into the underlying performance of the company’s core business operating
results, meaning its operating performance excluding these items and, from time to time, other discrete charges that are infrequent in nature, over multiple periods. The company also excludes from non-GAAP net income and non-GAAP diluted net income
per share the tax effects, including income tax and payroll tax, associated with these items in order to provide a complete picture of the company’s recurring core business operating results. Without excluding these tax effects, investors would
only see the gross effect that excluding these expenses had on the company’s operating results.

[0001193125-14-215060:8k_2_02:30]
Billings. Palo Alto Networks defines billings
as total revenue plus the change in deferred revenue, net of acquired deferred revenue, during the period. The company’s management monitors billings because billings drive deferred revenue, which is an important indicator of the health and
visibility of the company’s business. The company considers billings to be a useful metric for management and investors, particularly as sales of subscriptions increase and the company experiences strong renewal rates for subscriptions and
support and maintenance.

[0001193125-14-215060:8k_2_02:31]
Free Cash Flow. Palo Alto Networks defines free cash flow as cash provided by operating activities less
purchases of property, equipment, and other assets. The company considers free cash flow to be a liquidity measure that provides useful information to management and investors about the amount of cash generated by the business that, after the
purchases of property, equipment, and other assets, can be used for strategic opportunities, including investing in our business, making strategic acquisitions, and strengthening the balance sheet.

[0001193125-14-215060:8k_2_02:32]
Investors are cautioned that there are a number of limitations associated with the use of non-GAAP financial measures as an analytical tool. In particular,
many of the adjustments to the company’s GAAP financial measures reflect the exclusion of items that are recurring and will be reflected in the company’s financial results for the foreseeable future, such as share-based compensation.
Share-based compensation is an important part of Palo Alto Networks employees’ compensation and impacts their performance. In addition, the billings metric reported by the company includes amounts that have not yet been recognized as revenue.
The components that Palo Alto Networks excludes in its calculation of non-GAAP financial measures may differ from the components that its peer companies exclude when they report their non-GAAP results of operations. Palo Alto Networks compensates
for these limitations by providing specific information regarding the GAAP amounts excluded from these non-GAAP financial measures. In the future, the company may also exclude non-recurring expenses and other expenses that do not reflect the
company’s core business operating results.

[0001193125-14-215060:8k_2_02:33]
ABOUT PALO ALTO NETWORKS

[0001193125-14-215060:8k_2_02:34]
Palo Alto Networks is leading a new era in cybersecurity by protecting thousands of enterprise, government, and service provider networks from cyber threats.
Unlike fragmented legacy products, our security platform safely enables business operations and delivers protection based on what matters most in today’s dynamic computing environments: applications, users, and content. Find out more at
www.paloaltonetworks.com.

[0001193125-14-215060:8k_2_02:35]
Palo Alto Networks and the Palo Alto Networks Logo are trademarks of Palo Alto Networks, Inc. in the United
States and in jurisdictions throughout the world. All other trademarks, trade names or service marks used or mentioned herein belong to their respective owners.

[0001193125-14-215060:8k_2_02:36]
Media Contact:

[0001193125-14-215060:8k_2_02:37]
Jennifer Jasper Smith

[0001193125-14-215060:8k_2_02:38]
Head of Corporate Communications

[0001193125-14-215060:8k_2_02:39]
Palo Alto Networks

[0001193125-14-215060:8k_2_02:40]
408-638-3280

[0001193125-14-215060:8k_2_02:41]
jjsmith@paloaltonetworks.com

[0001193125-14-215060:8k_2_02:42]
Investor Relations Contact:

[0001193125-14-215060:8k_2_02:43]
Kelsey Turcotte

[0001193125-14-215060:8k_2_02:44]
Vice President of Investor Relations

[0001193125-14-215060:8k_2_02:45]
408-753-3872

[0001193125-14-215060:8k_2_02:46]
kturcotte@paloaltonetworks.com

[0001193125-14-215060:8k_2_02:47]
Chris Danne/Maria Riley

[0001193125-14-215060:8k_2_02:48]
The Blueshirt Group

[0001193125-14-215060:8k_2_02:49]
415-217-7722

[0001193125-14-215060:8k_2_02:50]
ir@paloaltonetworks.com

[0001193125-14-215060:8k_2_02:51]
Palo Alto Networks, Inc.

[0001193125-14-215060:8k_2_02:52]
Preliminary Condensed Consolidated Statements of Operations

[0001193125-14-215060:8k_2_02:53]
(In thousands, except per share data)

[0001193125-14-215060:8k_2_02:54]
(Unaudited)

[0001193125-14-215060:8k_2_02:55]
|  |  | Three Months EndedApril 30, |  |  | Nine Months EndedApril 30, |  |
|  |  | 2014 |  |  | 2013 |  |  | 2014 |  |  | 2013 |  |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 84,128 |  |  | $ | 60,793 |  |  | $ | 240,436 |  |  | $ | 178,251 |  |
| Services |  |  | 66,572 |  |  |  | 40,496 |  |  |  | 179,512 |  |  |  | 105,471 |  |
| Total revenue |  |  | 150,700 |  |  |  | 101,289 |  |  |  | 419,948 |  |  |  | 283,722 |  |
| Cost of revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  |  | 20,425 |  |  |  | 15,855 |  |  |  | 58,600 |  |  |  | 46,907 |  |
| Services |  |  | 19,285 |  |  |  | 11,835 |  |  |  | 52,421 |  |  |  | 32,591 |  |
| Total cost of revenue |  |  | 39,710 |  |  |  | 27,690 |  |  |  | 111,021 |  |  |  | 79,498 |  |
| Total gross profit |  |  | 110,990 |  |  |  | 73,599 |  |  |  | 308,927 |  |  |  | 204,224 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development |  |  | 27,837 |  |  |  | 16,048 |  |  |  | 71,983 |  |  |  | 44,855 |  |
| Sales and marketing |  |  | 83,995 |  |  |  | 51,733 |  |  |  | 228,095 |  |  |  | 140,136 |  |
| General and administrative |  |  | 23,718 |  |  |  | 12,268 |  |  |  | 57,576 |  |  |  | 30,971 |  |
| Legal settlement [a] |  |  | 113,700 |  |  |  | — |  |  |  | 133,700 |  |  |  | — |  |
| Total operating expenses |  |  | 249,250 |  |  |  | 80,049 |  |  |  | 491,354 |  |  |  | 215,962 |  |
| Operating loss |  |  | (138,260 | ) |  |  | (6,450 | ) |  |  | (182,427 | ) |  |  | (11,738 | ) |
| Interest income |  |  | 272 |  |  |  | 133 |  |  |  | 619 |  |  |  | 347 |  |
| Other income (expense), net |  |  | 145 |  |  |  | (157 | ) |  |  | 11 |  |  |  | (387 | ) |
| Loss before income taxes |  |  | (137,843 | ) |  |  | (6,474 | ) |  |  | (181,797 | ) |  |  | (11,778 | ) |
| Provision for income taxes |  |  | 1,272 |  |  |  | 808 |  |  |  | 5,125 |  |  |  | 1,632 |  |
| Net loss |  | $ | (139,115 | ) |  | $ | (7,282 | ) |  | $ | (186,922 | ) |  | $ | (13,410 | ) |
| Net loss per share, basic and diluted |  | $ | (1.86 | ) |  | $ | (0.10 | ) |  | $ | (2.56 | ) |  | $ | (0.20 | ) |
| Weighted-average shares used to compute net loss per share, basic and diluted |  |  | 74,967 |  |  |  | 69,575 |  |  |  | 73,127 |  |  |  | 67,980 |  |

[0001193125-14-215060:8k_2_02:56]
| [a] | Represents legal settlement expenses, including expenses related to the Q3’14 legal settlement with Juniper. |

[0001193125-14-215060:8k_2_02:57]
Palo Alto Networks, Inc.

[0001193125-14-215060:8k_2_02:58]
Reconciliation of GAAP to Non-GAAP Financial Measures

[0001193125-14-215060:8k_2_02:59]
(In thousands, except per share amounts)

[0001193125-14-215060:8k_2_02:60]
(Unaudited)

[0001193125-14-215060:8k_2_02:61]
|  |  | Three Months EndedApril 30, |  |  | Nine Months EndedApril 30, |  |
|  |  | 2014 |  |  | 2013 |  |  | 2014 |  |  | 2013 |  |
| GAAP net loss |  | $ | (139,115 | ) |  | $ | (7,282 | ) |  | $ | (186,922 | ) |  | $ | (13,410 | ) |
| Share-based compensation expense |  |  | 27,930 |  |  |  | 12,634 |  |  |  | 63,341 |  |  |  | 29,730 |  |
| Share-based payroll tax expense |  |  | 1,267 |  |  |  | 1,135 |  |  |  | 3,887 |  |  |  | 1,135 |  |
| Acquisition related costs |  |  | 3,681 |  |  |  | — |  |  |  | 7,480 |  |  |  | — |  |
| Amortization expense of acquired intangible assets |  |  | 614 |  |  |  | — |  |  |  | 679 |  |  |  | — |  |
| Legal settlement expense [a] |  |  | 113,700 |  |  |  | — |  |  |  | 133,700 |  |  |  | — |  |
| Litigation expense [b] |  |  | 4,732 |  |  |  | 1,256 |  |  |  | 9,274 |  |  |  | 2,295 |  |
| Income tax related to the above |  |  | (4,079 | ) |  |  | (2,486 | ) |  |  | (8,769 | ) |  |  | (7,054 | ) |
| Non-GAAP net income |  | $ | 8,730 |  |  | $ | 5,257 |  |  | $ | 22,670 |  |  | $ | 12,696 |  |
| GAAP net loss per share, diluted |  | $ | (1.86 | ) |  | $ | (0.10 | ) |  | $ | (2.56 | ) |  | $ | (0.20 | ) |
| Share-based compensation expense |  |  | 0.36 |  |  |  | 0.17 |  |  |  | 0.85 |  |  |  | 0.42 |  |
| Share-based payroll tax expense |  |  | 0.02 |  |  |  | 0.02 |  |  |  | 0.05 |  |  |  | 0.02 |  |
| Acquisition related costs |  |  | 0.05 |  |  |  | — |  |  |  | 0.10 |  |  |  | — |  |
| Amortization expense of acquired intangible assets |  |  | 0.01 |  |  |  | — |  |  |  | 0.01 |  |  |  | — |  |
| Legal settlement expense [a] |  |  | 1.52 |  |  |  | — |  |  |  | 1.83 |  |  |  | — |  |
| Litigation expense [b] |  |  | 0.06 |  |  |  | 0.02 |  |  |  | 0.13 |  |  |  | 0.02 |  |
| Income tax related to the above |  |  | (0.05 | ) |  |  | (0.04 | ) |  |  | (0.12 | ) |  |  | (0.10 | ) |
| Non-GAAP net income per share, diluted |  | $ | 0.11 |  |  | $ | 0.07 |  |  | $ | 0.29 |  |  | $ | 0.16 |  |
| GAAP weighted-average shares used to compute net loss per share, diluted |  |  | 74,967 |  |  |  | 69,575 |  |  |  | 73,127 |  |  |  | 67,980 |  |
| Weighted-average effect of potentially dilutive securities |  |  | 5,248 |  |  |  | 8,466 |  |  |  | 5,350 |  |  |  | 9,752 |  |
| Non-GAAP weighted-average shares used to compute net income per share, diluted |  |  | 80,215 |  |  |  | 78,041 |  |  |  | 78,477 |  |  |  | 77,732 |  |
| Revenue |  | $ | 150,700 |  |  | $ | 101,289 |  |  | $ | 419,948 |  |  | $ | 283,722 |  |
| Change in deferred revenue, net of acquired deferred revenue |  |  | 43,191 |  |  |  | 31,121 |  |  |  | 118,552 |  |  |  | 83,496 |  |
| Billings |  | $ | 193,891 |  |  | $ | 132,410 |  |  | $ | 538,500 |  |  | $ | 367,218 |  |
| Cash flow provided by operating activities |  | $ | 34,279 |  |  | $ | 15,206 |  |  | $ | 114,556 |  |  | $ | 72,789 |  |
| Less: purchase of property, equipment, and other assets |  |  | 5,896 |  |  |  | 6,359 |  |  |  | 31,379 |  |  |  | 16,595 |  |
| Free cash flow |  | $ | 28,383 |  |  | $ | 8,847 |  |  | $ | 83,177 |  |  | $ | 56,194 |  |

[0001193125-14-215060:8k_2_02:62]
| [a] | Represents legal settlement expenses, including expenses related to the Q3’14 legal settlement with Juniper. |

[0001193125-14-215060:8k_2_02:63]
| [b] | Litigation expense represents legal expenses attributable to IP litigation, including our litigation with Juniper. |

[0001193125-14-215060:8k_2_02:64]
Palo Alto Networks, Inc.

[0001193125-14-215060:8k_2_02:65]
Preliminary Condensed Consolidated Balance Sheets

[0001193125-14-215060:8k_2_02:66]
(In thousands)

[0001193125-14-215060:8k_2_02:67]
(Unaudited)

[0001193125-14-215060:8k_2_02:68]
|  |  | April 30, 2014 |  |  | July 31, 2013 |  |
| Assets |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 234,790 |  |  | $ | 310,614 |  |
| Short-term investments |  |  | 133,180 |  |  |  | 109,007 |  |
| Accounts receivable, net |  |  | 114,789 |  |  |  | 87,461 |  |
| Prepaid expenses and other current assets |  |  | 33,686 |  |  |  | 22,617 |  |
| Total current assets |  |  | 516,445 |  |  |  | 529,699 |  |
| Property and equipment, net |  |  | 48,488 |  |  |  | 32,086 |  |
| Long-term investments |  |  | 103,902 |  |  |  | 17,314 |  |
| Goodwill |  |  | 155,086 |  |  |  | — |  |
| Intangible assets, net |  |  | 49,613 |  |  |  | 1,358 |  |
| Other assets |  |  | 6,853 |  |  |  | 5,149 |  |
| Total assets |  | $ | 880,387 |  |  | $ | 585,606 |  |
| Liabilities and stockholders’ equity |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Accounts payable |  | $ | 24,641 |  |  | $ | 15,544 |  |
| Accrued liabilities [a] |  |  | 142,823 |  |  |  | 14,609 |  |
| Accrued compensation |  |  | 29,188 |  |  |  | 22,004 |  |
| Deferred revenue |  |  | 231,227 |  |  |  | 153,945 |  |
| Total current liabilities |  |  | 427,879 |  |  |  | 206,102 |  |
| Deferred revenue – non-current |  |  | 136,707 |  |  |  | 95,285 |  |
| Other long-term liabilities |  |  | 36,636 |  |  |  | 11,799 |  |
| Stockholders’ equity: |  |  |  |  |  |  |  |  |
| Preferred stock |  |  | — |  |  |  | — |  |
| Common stock |  |  | 7 |  |  |  | 7 |  |
| Additional paid-in capital |  |  | 575,293 |  |  |  | 381,703 |  |
| Accumulated other comprehensive gain (loss) |  |  | 61 |  |  |  | (16 | ) |
| Accumulated deficit |  |  | (296,196 | ) |  |  | (109,274 | ) |
| Total stockholders’ equity |  |  | 279,165 |  |  |  | 272,420 |  |
| Total liabilities and stockholders’ equity |  | $ | 880,387 |  |  | $ | 585,606 |  |

[0001193125-14-215060:8k_2_02:69]
| [a] | Includes an accrual for the Q3’14 legal settlement with Juniper. |

[0001193125-14-215060:8k_2_02:70]
Palo Alto Networks, Inc.

[0001193125-14-215060:8k_2_02:71]
Preliminary Condensed Consolidated Statements of Cash Flows

[0001193125-14-215060:8k_2_02:72]
(In thousands)

[0001193125-14-215060:8k_2_02:73]
(Unaudited)

[0001193125-14-215060:8k_2_02:74]
|  |  | Nine Months Ended April 30, |  |
|  |  | 2014 |  |  | 2013 |  |
| Cash flows from operating activities |  |  |  |  |  |  |  |  |
| Net loss |  | $ | (186,922 | ) |  | $ | (13,410 | ) |
| Adjustments to reconcile net loss to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 11,638 |  |  |  | 7,221 |  |
| Amortization of investment premiums, net of accretion of purchase discounts |  |  | 1,180 |  |  |  | 1,445 |  |
| Share-based compensation for equity based awards |  |  | 66,685 |  |  |  | 29,608 |  |
| Excess tax benefit from share-based compensation |  |  | (758 | ) |  |  | (177 | ) |
| Changes in operating assets and liabilities: |  |  |  |  |  |  |  |  |
| Accounts receivable, net |  |  | (27,220 | ) |  |  | (45,847 | ) |
| Prepaid expenses and other assets |  |  | (7,926 | ) |  |  | (5,991 | ) |
| Accounts payable |  |  | 8,965 |  |  |  | 3,347 |  |
| Accrued and other liabilities [a] |  |  | 130,362 |  |  |  | 13,097 |  |
| Deferred revenue |  |  | 118,552 |  |  |  | 83,496 |  |
| Net cash provided by operating activities |  |  | 114,556 |  |  |  | 72,789 |  |
| Cash flows from investing activities |  |  |  |  |  |  |  |  |
| Purchase of property, equipment, and other assets |  |  | (31,379 | ) |  |  | (16,595 | ) |
| Purchase of investments |  |  | (316,911 | ) |  |  | (310,683 | ) |
| Proceeds from sales of investments |  |  | 6,630 |  |  |  | 13,491 |  |
| Proceeds from maturities of investments |  |  | 198,080 |  |  |  | 117,150 |  |
| Acquisition of business, net of cash acquired |  |  | (85,726 | ) |  |  | — |  |
| Net cash used in investing activities |  |  | (229,306 | ) |  |  | (196,637 | ) |
| Cash flows from financing activities |  |  |  |  |  |  |  |  |
| Excess tax benefit from share-based compensation |  |  | 758 |  |  |  | 177 |  |
| Proceeds from exercise of stock options |  |  | 25,431 |  |  |  | 11,195 |  |
| Proceeds from employee stock purchase plan |  |  | 12,869 |  |  |  | 6,267 |  |
| Repurchase of restricted common stock from employees |  |  | (132 | ) |  |  | (71 | ) |
| Payments of initial public offering costs |  |  | — |  |  |  | (2,698 | ) |
| Net cash provided by financing activities |  |  | 38,926 |  |  |  | 14,870 |  |
| Net decrease in cash and cash equivalents |  |  | (75,824 | ) |  |  | (108,978 | ) |
| Cash and cash equivalents - beginning of period |  |  | 310,614 |  |  |  | 322,642 |  |
| Cash and cash equivalents - end of period |  | $ | 234,790 |  |  | $ | 213,664 |  |

[0001193125-14-215060:8k_2_02:75]
| [a] | Includes an accrual for the Q3’14 legal settlement with Juniper. |

## item 1.01 — body, verbatim

[0001193125-14-215060:8k_body:1]
Item 1.01 Entry into a Material Definitive Agreement

[0001193125-14-215060:8k_body:2]
On May 27, 2014 (the “Settlement Effective Date”), Palo Alto Networks, Inc. (the “Company”) entered into a Settlement,
Release and Cross-License Agreement (the “Settlement Agreement”) with Juniper Networks, Inc. (“Juniper”) to resolve all pending disputes between Juniper and the Company, including (a) various patent-related disputes that
were being litigated in the U.S. District Courts for the District of Delaware and the Northern District of California and the Superior Court in Santa Clara County, a California state court (collectively, the “Court Proceedings”); and
(b) various inter partes proceedings in the U.S. Patent and Trademark Office (the “Settlement”). Under the Settlement Agreement, each party granted to the other party (i) a life-of-patents license of the patents in suit (together
with other patents in the same patent families); and (ii) an 8-year covenant not to sue for infringement of any other patents of the party. The licenses and covenants include immunity for each party’s customers for the party’s
products and services. The Settlement Agreement also contains releases for any past infringement and general releases for past claims between the parties.

[0001193125-14-215060:8k_body:3]
As part of the Settlement, the Company will issue to Juniper on the Settlement Effective Date 1,080,747 shares of the Company’s common
stock (the “Shares”) with an approximate value of $70,000,000 and, as soon as reasonably practicable after the date upon which a judgment or stipulation for entry of judgment has been issued by the courts in each Court Proceeding (the
“Stipulation Date”) (and in any event not later than three (3) business days following such date), the Company will (a) pay to Juniper $75,000,000 in cash and (b) issue to Juniper a warrant (the “Warrant”) to
purchase 463,177 shares of the Company’s common stock, which have an approximate value of $30,000,000, at an exercise price of $0.0001 per share. The Warrant will expire seven (7) months after the issuance date of the Warrant.

[0001193125-14-215060:8k_body:4]
The foregoing description of the Settlement Agreement and the Warrant does not purport to be complete and is qualified in its entirety by
reference to the full text of the Settlement Agreement filed as exhibit 10.1 hereto, which is incorporated by reference herein, and the full text of the Warrant, a form of which is filed as an exhibit to the Settlement Agreement. The Warrant, when
issued by the Company to Juniper, will be filed with a subsequent Form 8-K.
