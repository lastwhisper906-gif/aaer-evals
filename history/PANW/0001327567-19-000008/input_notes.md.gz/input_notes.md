# PANW notes — 0001327567-19-000008


## panw:ConvertibleDebtOtherDetailsTableTextBlock

[0001327567-19-000008:notes:1]
The following table presents details of the Notes (number of shares in millions):

[0001327567-19-000008:notes:2]
|  | Conversion Rate per $1,000 Principal |  | Initial Conversion Price |  | Convertible Date |  | Initial Number of Shares |
| 2019 Notes | 9.0680 |  |  | $ | 110.28 |  |  | January 1, 2019 |  | 5.2 |  |
| 2023 Notes | 3.7545 |  |  | $ | 266.35 |  |  | April 1, 2023 |  | 6.4 |  |


## panw:DebtSecuritiesAvailableforsaleTableTextBlock

[0001327567-19-000008:notes:3]
The following tables summarize the amortized cost, unrealized gains and losses, and fair value of our available-for-sale securities as of January 31, 2019 and July 31, 2018 (in millions):

[0001327567-19-000008:notes:4]
|  | January 31, 2019 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | $ | 39.4 |  |  | $ | — |  |  | $ | — |  |  | $ | 39.4 |  |
| U.S. government and agency securities | 279.4 |  |  | — |  |  | — |  |  | 279.4 |  |
| Total available-for-sale cash equivalents | $ | 318.8 |  |  | $ | — |  |  | $ | — |  |  | $ | 318.8 |  |
| Investments: |  |  |  |  |  |  |  |
| Commercial paper | $ | 50.2 |  |  | $ | — |  |  | $ | — |  |  | $ | 50.2 |  |
| Corporate debt securities | 495.9 |  |  | 0.9 |  |  | (1.4 | ) |  | 495.4 |  |
| U.S. government and agency securities | 1,968.0 |  |  | 1.1 |  |  | (3.9 | ) |  | 1,965.2 |  |
| Total available-for-sale investments | $ | 2,514.1 |  |  | $ | 2.0 |  |  | $ | (5.3 | ) |  | $ | 2,510.8 |  |

[0001327567-19-000008:notes:5]
[same as prior period, unchanged from 0001327567-18-000031:notes:5]


## panw:Scheduleof2019NotesConversionsTableTextBlock

[0001327567-19-000008:notes:6]
The following table presents details of conversions of the 2019 Notes during the reporting period (in millions):

[0001327567-19-000008:notes:7]
|  | Three Months Ended |  | Six Months Ended |
|  | January 31, 2019 |  | January 31, 2019 |
| 2019 Notes principal converted and repaid in cash: |  |  |  |
| Allocated to liability component(1) | $ | 86.3 |  |  | $ | 403.4 |  |
| Allocated to equity component(2) | 2.0 |  |  | 12.2 |  |
| Total principal converted and repaid in cash | $ | 88.3 |  |  | $ | 415.6 |  |
| Loss on conversions of convertible senior notes(3) | $ | 0.4 |  |  | $ | 2.6 |  |
| Shares of common stock issued in connection with conversion of convertible senior notes(4) | 0.3 |  |  | 1.7 |  |

[0001327567-19-000008:notes:8]
______________

[0001327567-19-000008:notes:9]
| (1) | Recorded as a reduction to convertible senior notes, net in our condensed consolidated balance sheets and calculated by measuring the fair value of a similar liability that did not have an associated convertible feature. |

[0001327567-19-000008:notes:10]
| (2) | Recorded as a reduction to additional paid-in capital in our condensed consolidated balance sheets. |

[0001327567-19-000008:notes:11]
| (3) | Represents the difference between the cash consideration allocated to the liability component and the net carrying amount of the liability component on the respective settlement dates. The amount is included in other income, net in our condensed consolidated statement of operations. |

[0001327567-19-000008:notes:12]
| (4) | Shares of common stock issued to the holders for the conversion value in excess of the principal amount. These shares were fully offset by shares received from the corresponding exercise of the associated note hedges. |


## panw:ScheduleofNoteHedgeTransactionsTableTextBlock

[0001327567-19-000008:notes:13]
[same as prior period, unchanged from 0001327567-18-000031:notes:6]

[0001327567-19-000008:notes:14]
[same as prior period, unchanged from 0001327567-18-000031:notes:7]


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001327567-19-000008:notes:15]
[same as prior period, unchanged from 0001327567-18-000031:notes:8]

[0001327567-19-000008:notes:16]
[same as prior period, unchanged from 0001327567-18-000031:notes:9]

[0001327567-19-000008:notes:17]
[same as prior period, unchanged from 0001327567-18-000031:notes:10]

[0001327567-19-000008:notes:18]
[same as prior period, unchanged from 0001327567-18-000031:notes:11]

[0001327567-19-000008:notes:19]
[same as prior period, unchanged from 0001327567-18-000031:notes:12]

[0001327567-19-000008:notes:20]
[same as prior period, unchanged from 0001327567-18-000031:notes:13]

[0001327567-19-000008:notes:21]
[same as prior period, unchanged from 0001327567-18-000031:notes:14]

[0001327567-19-000008:notes:22]
[same as prior period, unchanged from 0001327567-18-000031:notes:15]

[0001327567-19-000008:notes:23]
[same as prior period, unchanged from 0001327567-18-000031:notes:16]

[0001327567-19-000008:notes:24]
[same as prior period, unchanged from 0001327567-18-000031:notes:17]

[0001327567-19-000008:notes:25]
Additional information, such as that related to income tax and other contingencies, existing as of the acquisition date but unknown to us may become known during the remainder of the measurement period, not to exceed 12 months from the acquisition date, which may result in changes to the amounts and allocations recorded.


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock

[0001327567-19-000008:notes:26]
[same as prior period, unchanged from 0001327567-18-000031:notes:19]

[0001327567-19-000008:notes:27]
[same as prior period, unchanged from 0001327567-18-000031:notes:20]

[0001327567-19-000008:notes:28]
[same as prior period, unchanged from 0001327567-18-000031:notes:21]

[0001327567-19-000008:notes:29]
[same as prior period, unchanged from 0001327567-18-000031:notes:22]

[0001327567-19-000008:notes:30]
[same as prior period, unchanged from 0001327567-18-000031:notes:23]

[0001327567-19-000008:notes:31]
[same as prior period, unchanged from 0001327567-18-000031:notes:24]

[0001327567-19-000008:notes:32]
Certain prior period amounts have been adjusted due to our retrospective adoption of new accounting guidance related to revenue from contracts with customers and new accounting guidance related to the presentation of restricted cash and cash equivalents in the statement of cash flows. Refer to “Recently Adopted Accounting Pronouncements” below for more information.

[0001327567-19-000008:notes:33]
[same as prior period, unchanged from 0001327567-18-000031:notes:26]

[0001327567-19-000008:notes:34]
[same as prior period, unchanged from 0001327567-18-000031:notes:27]

[0001327567-19-000008:notes:35]
There have been no material changes to our significant accounting policies as of and for the six months ended January 31, 2019, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended July 31, 2018, except for the change in our accounting policies for revenue recognition and deferred contract costs due to our adoption of new accounting guidance related to revenue from contracts with customers. Refer to “Recently Adopted Accounting Pronouncements” below, Note 2. Revenue, and Note 8. Deferred Contract Costs for more information.

[0001327567-19-000008:notes:36]
Recently Adopted Accounting Pronouncements

[0001327567-19-000008:notes:37]
[same as prior period, unchanged from 0001327567-18-000031:notes:49]

[0001327567-19-000008:notes:38]
In August 2018, the Financial Accounting Standards Board (“FASB”) issued authoritative guidance on customers’ accounting for implementation costs incurred in a cloud computing arrangement that is a service contract, which requires customers to apply internal-use software guidance to determine the implementation costs that are able to be capitalized. Under the new standard, capitalized implementation costs are generally amortized over the term of the arrangement, beginning when the module or component of the hosting arrangement is ready for its intended use. We early adopted this standard in our second quarter of fiscal 2019 on a prospective basis. The adoption of the standard did not have a material impact on our condensed consolidated financial statements.

[0001327567-19-000008:notes:39]
[same as prior period, unchanged from 0001327567-18-000031:notes:30]

[0001327567-19-000008:notes:40]
In January 2017, the FASB issued authoritative guidance clarifying the definition of a business to assist companies with evaluating whether transactions should be accounted for as acquisitions (or disposals) of assets or businesses. We adopted this standard in our first quarter of fiscal 2019 on a prospective basis. The adoption of the standard did not have an impact on our condensed consolidated financial statements.

[0001327567-19-000008:notes:41]
[same as prior period, unchanged from 0001327567-18-000031:notes:32]

[0001327567-19-000008:notes:42]
[same as prior period, unchanged from 0001327567-18-000031:notes:33]

[0001327567-19-000008:notes:43]
[same as prior period, unchanged from 0001327567-18-000031:notes:34]

[0001327567-19-000008:notes:44]
In October 2016, the FASB issued authoritative guidance requiring the recognition of income tax consequences of an intra-entity transfer of an asset, other than inventory, when the transfer occurs. We adopted the standard in our first quarter of fiscal 2019 on a modified retrospective basis. As a result, we recorded the cumulative effect of the change as an increase to accumulated deficit of $28.3 million, with a corresponding decrease to prepaid expenses and other current assets and other assets in our condensed consolidated balance sheets as of August 1, 2018, the date of adoption. The cumulative effect adjustment represents the reclassification of unrecognized income tax effects from intra-entity transfers of assets other than inventory that occurred prior to the date of adoption.

[0001327567-19-000008:notes:45]
[same as prior period, unchanged from 0001327567-18-000031:notes:36]

[0001327567-19-000008:notes:46]
[same as prior period, unchanged from 0001327567-18-000031:notes:37]

[0001327567-19-000008:notes:47]
[same as prior period, unchanged from 0001327567-18-000031:notes:38]

[0001327567-19-000008:notes:48]
[same as prior period, unchanged from 0001327567-18-000031:notes:39]

[0001327567-19-000008:notes:49]
[same as prior period, unchanged from 0001327567-18-000031:notes:40]

[0001327567-19-000008:notes:50]
[same as prior period, unchanged from 0001327567-18-000031:notes:41]

[0001327567-19-000008:notes:51]
[same as prior period, unchanged from 0001327567-18-000031:notes:42]

[0001327567-19-000008:notes:52]
The adoption of the standard using the full retrospective method required us to restate the prior periods presented in this Quarterly Report on Form 10-Q, with the cumulative effect of the change of $168.2 million reflected in accumulated deficit as of July 31, 2017. In adopting the new standard, we have also applied a transition practical expedient and have not disclosed revenue expected to be recognized from remaining performance obligations for periods prior to August 1, 2018.

[0001327567-19-000008:notes:53]
[same as prior period, unchanged from 0001327567-18-000031:notes:44]

[0001327567-19-000008:notes:54]
|  | Three Months Ended January 31, 2018 |  | Six Months Ended January 31, 2018 |
|  | As Previously Reported |  | Impact of Adoption |  | As Adjusted |  | As Previously Reported |  | Impact of Adoption |  | As Adjusted |
| Condensed Consolidated Statements of Operations |  |  |  |  |  |  |  |  |  |  |  |
| Product revenue | $ | 202.2 |  |  | $ | 2.6 |  |  | $ | 204.8 |  |  | $ | 388.7 |  |  | $ | 0.9 |  |  | $ | 389.6 |  |
| Subscription and support revenue | 340.2 |  |  | 0.6 |  |  | 340.8 |  |  | 659.2 |  |  | (1.4 | ) |  | 657.8 |  |
| Total revenue | 542.4 |  |  | 3.2 |  |  | 545.6 |  |  | 1,047.9 |  |  | (0.5 | ) |  | 1,047.4 |  |
| Total cost of revenue | 159.3 |  |  | 0.1 |  |  | 159.4 |  |  | 300.7 |  |  | — |  |  | 300.7 |  |
| Total operating expenses | 414.9 |  |  | (6.2 | ) |  | 408.7 |  |  | 833.3 |  |  | (10.6 | ) |  | 822.7 |  |
| Operating loss | (31.8 | ) |  | 9.3 |  |  | (22.5 | ) |  | (86.1 | ) |  | 10.1 |  |  | (76.0 | ) |
| Net loss | (34.9 | ) |  | 9.3 |  |  | (25.6 | ) |  | (98.9 | ) |  | 10.1 |  |  | (88.8 | ) |
| Net loss per share, basic and diluted | $ | (0.38 | ) |  | $ | 0.10 |  |  | $ | (0.28 | ) |  | $ | (1.09 | ) |  | $ | 0.11 |  |  | $ | (0.98 | ) |

[0001327567-19-000008:notes:55]
[same as prior period, unchanged from 0001327567-18-000031:notes:46]

[0001327567-19-000008:notes:56]
[same as prior period, unchanged from 0001327567-18-000031:notes:47]

[0001327567-19-000008:notes:57]
Recently Issued Accounting Pronouncements

[0001327567-19-000008:notes:58]
[same as prior period, unchanged from 0001327567-18-000031:notes:51]

[0001327567-19-000008:notes:59]
[same as prior period, unchanged from 0001327567-18-000031:notes:52]

[0001327567-19-000008:notes:60]
[same as prior period, unchanged from 0001327567-18-000031:notes:53]

[0001327567-19-000008:notes:61]
In February 2016, the FASB issued new authoritative guidance on lease accounting. Among its provisions, the standard requires lessees to recognize right-of-use assets and lease liabilities on the balance sheet for operating leases and also requires additional qualitative and quantitative disclosures about lease arrangements. The standard is effective for us in our first quarter of fiscal 2020 and will be applied on a modified retrospective basis, with the option to elect certain practical expedients. Early adoption is permitted; however, we plan to adopt the new standard in our first quarter of fiscal 2020. Upon adoption, we will recognize right-of-use assets and operating lease liabilities on our condensed consolidated balance sheets, which will increase our total assets and total liabilities. We expect our operating leases, as disclosed in Note 10. Commitments and Contingencies, will be subject to the new standard. We continue to evaluate the accounting, transition, and disclosure requirements of this standard, including its impact on our systems, accounting policies, and processes.


## us-gaap:CapitalizedContractCostTableTextBlock

[0001327567-19-000008:notes:62]
The following table presents details of our short-term and long-term deferred contract costs as of January 31, 2019 and July 31, 2018 (in millions):

[0001327567-19-000008:notes:63]
|  | January 31, 2019 |  | July 31, 2018 |
| Short-term deferred contract costs | $ | 117.6 |  |  | $ | 113.2 |  |
| Long-term deferred contract costs | 230.7 |  |  | 224.8 |  |
| Total deferred contract costs | $ | 348.3 |  |  | $ | 338.0 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001327567-19-000008:notes:64]
Commitments and Contingencies

[0001327567-19-000008:notes:65]
We lease our facilities under various non-cancelable operating leases, which expire through the year ending July 31, 2028.

[0001327567-19-000008:notes:66]
In May 2015 and October 2015, we entered into a total of three lease agreements for approximately 941,000 square feet of corporate office space in Santa Clara, California, which serves as our new corporate headquarters. The leases contain rent holiday periods, scheduled rent increases, lease incentives, and renewal options which allow the lease terms to be extended beyond their expiration dates of July 2028 through July 2046. In September 2017, per the terms of the lease agreements, the landlords exercised their option to amend our lease payment schedules and eliminate our rent holiday periods, which increased our rental payments by $24.4 million, $11.8 million, and $2.0 million for fiscal 2018, 2019, and 2020, respectively. In exchange, we received an upfront cash reimbursement of $38.2 million during the three months ended October 31, 2017, which we have applied and will apply against the future additional rental payments when due. As amended, rental payments under the three lease agreements are approximately $412.0 million over the lease term.

[0001327567-19-000008:notes:67]
In May 2015, we also entered into a lease agreement for approximately 122,000 square feet of space in Santa Clara, California, to serve as an extension of our previous corporate headquarters. The lease contains scheduled rent increases, lease incentives, and renewal options which allow the lease term to be extended beyond the expiration date of April 2021 through July 2046. Rental payments under the lease agreement are approximately $23.1 million over the lease term. In December 2017, we entered into an agreement to sublease this office space for the remaining lease term. Proceeds from this sublease will be approximately $16.3 million over the sublease term.

[0001327567-19-000008:notes:68]
In September 2012, we entered into two lease agreements for a total of approximately 300,000 square feet of space in Santa Clara, California, which served as our previous corporate headquarters through August 2017, when we relocated to our new corporate campus. The leases contain rent holiday periods and two separate five-year options to extend the lease term beyond their expiration dates of July 2023. Rental payments under these lease agreements are approximately $94.3 million over the lease term. In August 2017, we exited our previous headquarter facilities and relocated to our new corporate campus, which resulted in the recognition of a cease-use loss of $39.2 million as general and administrative expense in our consolidated statements of operations during the year ended July 31, 2018, and a corresponding liability in our consolidated balance sheets. During the three and six months ended January 31, 2019, we released $2.5 million and $5.0 million, respectively, of the cease-use liability through rental payments. As of January 31, 2019, the remaining balance of the cease-use liability was $24.1 million, which is expected to be paid through the end of the lease term in July 2023.

[0001327567-19-000008:notes:69]
The following table presents details of the aggregate future non-cancelable minimum rental payments under our operating leases as of January 31, 2019 (in millions):

[0001327567-19-000008:notes:70]
|  | Amount |
| Fiscal years ending July 31: |  |
| Remaining 2019 | $ | 33.6 |  |
| 2020 | 69.0 |  |
| 2021 | 64.1 |  |
| 2022 | 59.9 |  |

[0001327567-19-000008:notes:71]
| 2023 | 58.6 |  |
| 2024 and thereafter | 223.8 |  |
| Committed gross lease payments | 509.0 |  |
| Less: proceeds from sublease rentals | 12.3 |  |
| Net operating lease obligation | $ | 496.7 |  |

[0001327567-19-000008:notes:72]
Purchase Commitments

[0001327567-19-000008:notes:73]
Manufacturing Purchase Commitments

[0001327567-19-000008:notes:74]
Our electronics manufacturing service provider (“EMS provider”) procures components and assembles our products based on our forecasts. These forecasts are based on estimates of demand for our products primarily for the next 12 months, which are in turn based on historical trends and an analysis from our sales and product management organizations, adjusted for overall market conditions. In order to reduce manufacturing lead times and plan for adequate supply, we may issue non-cancelable orders for products and components to our manufacturing partners or component suppliers. As of January 31, 2019, our purchase commitments under such orders were $136.8 million, excluding obligations under contracts that we can cancel without a significant penalty.

[0001327567-19-000008:notes:75]
Other Purchase Commitments

[0001327567-19-000008:notes:76]
We have entered into various non-cancelable agreements with third-party providers for our use of certain cloud services, under which we are committed to minimum purchases through the year ending July 31, 2026. The following table presents details of the aggregate future non-cancelable purchase commitments under these agreements as of January 31, 2019 (in millions):

[0001327567-19-000008:notes:77]
|  | Amount |
| Fiscal years ending July 31: |  |
| Remaining 2019 | $ | — |  |
| 2020 | 8.0 |  |
| 2021 | 30.0 |  |
| 2022 | 47.5 |  |
| 2023 | 57.5 |  |
| 2024 and thereafter | 165.0 |  |
| Total other purchase commitments | $ | 308.0 |  |

[0001327567-19-000008:notes:78]
Litigation

[0001327567-19-000008:notes:79]
We are subject to legal proceedings, claims, and litigation arising in the ordinary course of business, including intellectual property litigation. Such matters are subject to many uncertainties and outcomes are not predictable with assurance. We accrue for contingencies when we believe that a loss is probable and that we can reasonably estimate the amount of any such loss.

[0001327567-19-000008:notes:80]
To the extent there is a reasonable possibility that a loss exceeding amounts already recognized may be incurred and the amount of such additional loss would be material, we will either disclose the estimated additional loss or state that such an estimate cannot be made. As of January 31, 2019, we have not recorded any significant accruals for loss contingencies associated with such legal proceedings, determined that an unfavorable outcome is probable or reasonably possible, or determined that the amount or range of any possible loss is reasonably estimable.


## us-gaap:ConvertibleDebtTableTextBlock

[0001327567-19-000008:notes:81]
The following table sets forth the components of the Notes as of January 31, 2019 and July 31, 2018 (in millions):

[0001327567-19-000008:notes:82]
|  | January 31, 2019 |  | July 31, 2018 |
|  | 2019 Notes |  | 2023 Notes |  | Total |  | 2019 Notes |  | 2023 Notes |  | Total |
| Liability component: |  |  |  |  |  |  |  |  |  |  |  |
| Principal | $ | 159.4 |  |  | $ | 1,693.0 |  |  | $ | 1,852.4 |  |  | $ | 575.0 |  |  | $ | 1,693.0 |  |  | $ | 2,268.0 |  |
| Less: debt discount and debt issuance costs, net of amortization | 3.1 |  |  | 293.5 |  |  | 296.6 |  |  | 24.6 |  |  | 323.3 |  |  | 347.9 |  |
| Net carrying amount | $ | 156.3 |  |  | $ | 1,399.5 |  |  | $ | 1,555.8 |  |  | $ | 550.4 |  |  | $ | 1,369.7 |  |  | $ | 1,920.1 |  |
| Equity component (including amounts classified as temporary equity) | $ | 30.4 |  |  | $ | 315.0 |  |  | $ | 345.4 |  |  | $ | 109.8 |  |  | $ | 315.0 |  |  | $ | 424.8 |  |


## us-gaap:DebtDisclosureTextBlock

[0001327567-19-000008:notes:83]
Debt

[0001327567-19-000008:notes:84]
Convertible Senior Notes

[0001327567-19-000008:notes:85]
In June 2014, we issued $575.0 million aggregate principal amount of 0.0% Convertible Senior Notes due 2019 (the “2019 Notes”) and in July 2018, we issued $1.7 billion aggregate principal amount of 0.75% Convertible Senior Notes due 2023 (the “2023 Notes” and, together with the 2019 Notes, the “Notes”). The 2023 Notes bear interest at a fixed rate of 0.75% per year, payable semi-annually in arrears on January 1 and July 1 of each year, beginning on January 1, 2019. Each series of Notes is governed by an indenture between us, as the issuer, and U.S. Bank National Association, as Trustee (individually, each an “Indenture,” and together, the “Indentures”). The Notes of each series are unsecured, unsubordinated obligations and the applicable Indenture governing each series of Notes does not contain any financial covenants or restrictions on the payments of dividends, the incurrence of indebtedness, or the issuance or repurchase of securities by us or any of our subsidiaries. The 2019 Notes and 2023 Notes mature on July 1, 2019 and July 1, 2023, respectively. We cannot redeem either series of Notes prior to the applicable maturity date.

[0001327567-19-000008:notes:86]
Holders of the Notes may surrender their Notes for conversion at their option at any time prior to the close of business on the business day immediately preceding their respective convertible dates only under the following circumstances:

[0001327567-19-000008:notes:87]
| • | during any fiscal quarter commencing after the fiscal quarters ending on October 31, 2014 and October 31, 2018, for the 2019 Notes and 2023 Notes, respectively (and only during such fiscal quarter), if the last reported sale price of our common stock for at least 20 trading days (whether or not consecutive) during a period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the applicable conversion price for the respective Notes on each applicable trading day (the “sale price condition”); |

[0001327567-19-000008:notes:88]
| • | during the five business day period after any five consecutive trading day period (the “measurement period”) in which the trading price per $1,000 principal amount of the applicable series of Notes for each trading day of the measurement period was less than 98% of the product of the last reported sale price of our common stock and the applicable conversion rate for the respective Notes on each such trading day; or |

[0001327567-19-000008:notes:89]
| • | upon the occurrence of specified corporate events. |

[0001327567-19-000008:notes:90]
On or after the respective convertible date, holders may surrender all or any portion of their Notes for conversion at any time prior to the close of business on the second scheduled trading day immediately preceding the applicable maturity date regardless of the foregoing conditions, and such conversions will be settled upon the applicable maturity date. Upon conversion, holders of the Notes of a series will receive cash equal to the aggregate principal amount of the Notes of such series to be converted, and, at our election, cash and/or shares of our common stock for any amounts in excess of the aggregate principal amount of the Notes of such series being converted.

[0001327567-19-000008:notes:91]
The conversion price will be subject to adjustment in some events. Holders of the Notes of a series who convert their Notes of such series in connection with certain corporate events that constitute a “make-whole fundamental change” under the applicable Indenture are, under certain circumstances, entitled to an increase in the conversion rate for such series of Notes. Additionally, upon the occurrence of a corporate event that constitutes a “fundamental change” under the applicable Indenture, holders of the Notes of such series may require us to repurchase for cash all or a portion of the Notes of such series at a repurchase price equal to 100% of the principal amount of the Notes of such series plus accrued and unpaid interest to, but excluding, the fundamental change repurchase date.

[0001327567-19-000008:notes:92]
The sale price condition was met for the 2019 Notes during the fiscal quarters ended July 31, 2018 and October 31, 2018. As a result, holders were able to convert their 2019 Notes at any time during the fiscal quarter ended October 31, 2018 and up to January 1, 2019. On or after January 1, 2019, holders may surrender their 2019 Notes for conversion at any time prior to maturity, in accordance with the terms described above. Such conversion requests will settle upon maturity of the 2019 Notes. Accordingly, the net carrying amount of the 2019 Notes was classified as a current liability and the portion of the equity component representing the conversion option was classified as temporary equity in our condensed consolidated balance sheets as of January 31, 2019. As of January 31, 2019, $159.4 million in aggregate principal amount of the 2019 Notes remained outstanding.

[0001327567-19-000008:notes:93]
The sale price condition was not met for the 2023 Notes during the fiscal quarters ended January 31, 2019 or July 31, 2018. Since the 2023 Notes were not convertible, the net carrying amount of the 2023 Notes was classified as a long-term liability and the equity component was included in additional paid-in capital in our condensed consolidated balance sheets as of January 31, 2019 and July 31, 2018. As of January 31, 2019, all of the 2023 Notes remained outstanding.

[0001327567-19-000008:notes:94]
The total estimated fair value of the Notes was $2.1 billion and $2.7 billion at January 31, 2019 and July 31, 2018, respectively. The fair value was determined based on the closing trading price per $100 of the Notes as of the last day of trading for the period. We consider the fair value of the Notes at January 31, 2019 and July 31, 2018 to be a Level 2 measurement. The fair value of the Notes is primarily affected by the trading price of our common stock and market interest rates. As of January 31, 2019, the if-converted value of the 2019 Notes exceeded its principal amount by $119.1 million. Based on the closing price of our common stock on January 31, 2019, the if-converted value of the 2023 Notes was less than its principal amount.

[0001327567-19-000008:notes:95]
The following table sets forth interest expense recognized related to the Notes (dollars in millions):

[0001327567-19-000008:notes:96]
|  | Three Months Ended January 31, |  | Six Months Ended January 31, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
|  | 2019 Notes |  | 2023 Notes |  | Total |  | 2019 Notes |  | 2023 Notes |  | Total |  | 2019 Notes |  | 2023 Notes |  | Total |  | 2019 Notes |  | 2023 Notes |  | Total |
| Contractual interest expense | $ | — |  |  | $ | 3.1 |  |  | $ | 3.1 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 6.3 |  |  | $ | 6.3 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Amortization of debt discount | 2.0 |  |  | 14.5 |  |  | 16.5 |  |  | 5.8 |  |  | — |  |  | 5.8 |  |  | 6.0 |  |  | 28.9 |  |  | 34.9 |  |  | 11.4 |  |  | — |  |  | 11.4 |  |
| Amortization of debt issuance costs | 0.2 |  |  | 0.4 |  |  | 0.6 |  |  | 0.6 |  |  | — |  |  | 0.6 |  |  | 0.7 |  |  | 0.9 |  |  | 1.6 |  |  | 1.3 |  |  | — |  |  | 1.3 |  |
| Total interest expense recognized | $ | 2.2 |  |  | $ | 18.0 |  |  | $ | 20.2 |  |  | $ | 6.4 |  |  | $ | — |  |  | $ | 6.4 |  |  | $ | 6.7 |  |  | $ | 36.1 |  |  | $ | 42.8 |  |  | $ | 12.7 |  |  | $ | — |  |  | $ | 12.7 |  |
| Effective interest rate of the liability component | 4.8 | % |  | 5.2 | % |  |  |  | 4.8 | % |  | — | % |  |  |  | 4.8 | % |  | 5.2 | % |  |  |  | 4.8 | % |  | — | % |  |  |

[0001327567-19-000008:notes:97]
Note Hedges

[0001327567-19-000008:notes:98]
To minimize the impact of potential economic dilution upon conversion of the Notes, we entered into separate convertible note hedge transactions (the “2019 Note Hedges,” with respect to the 2019 Notes, and the “2023 Note Hedges,” with respect to the 2023 Notes, and collectively, the “Note Hedges”) with respect to our common stock concurrent with the issuance of each series of Notes.

[0001327567-19-000008:notes:99]
The Note Hedges cover shares of our common stock at a strike price per share that corresponds to the initial applicable conversion price of the applicable series of Notes, which are also subject to adjustment, and are exercisable upon conversion of the applicable series of Notes. The Note Hedges will expire upon maturity of the applicable series of Notes. The Note Hedges are separate transactions and are not part of the terms of the applicable series of the Notes. Holders of the Notes of either series will not have any rights with respect to the Note Hedges. Any shares of our common stock receivable by us under the Note Hedges are excluded from the calculation of diluted earnings per share as they are antidilutive. The aggregate amounts paid for the Note Hedges are included in additional paid-in capital in our consolidated balance sheets.

[0001327567-19-000008:notes:100]
As a result of the conversions of the 2019 Notes settled during the three and six months ended January 31, 2019, we exercised the corresponding portion of our 2019 Note Hedges and received 0.3 million and 1.7 million shares of common stock during the respective periods.

[0001327567-19-000008:notes:101]
Warrants

[0001327567-19-000008:notes:102]
Separately, but concurrently with the issuance of each series of Notes, we entered into transactions whereby we sold warrants (the “2019 Warrants,” with respect to the 2019 Notes, and the “2023 Warrants,” with respect to the 2023 Notes, and collectively, the “Warrants”) to acquire shares of our common stock, subject to anti-dilution adjustments. The 2019 Warrants and 2023 Warrants are exercisable beginning October 2019 and October 2023, respectively.

[0001327567-19-000008:notes:103]
The following table presents details of the Warrants (in millions, except per share data):

[0001327567-19-000008:notes:104]
|  | Initial Number of Shares |  | Strike Price per Share |  | Aggregate Proceeds |
| 2019 Warrants | 5.2 |  |  | $ | 137.85 |  |  | $ | 78.3 |  |
| 2023 Warrants | 6.4 |  |  | $ | 417.80 |  |  | $ | 145.4 |  |

[0001327567-19-000008:notes:105]
The shares issuable under the Warrants will be included in the calculation of diluted earnings per share when the average market value per share of our common stock for the reporting period exceeds the applicable strike price for such series of Warrants. The Warrants are separate transactions and are not part of either series of Notes or Note Hedges and are not remeasured through earnings each reporting period. Holders of the Notes of either series will not have any rights with respect to the Warrants. The aggregate proceeds received from the sale of the Warrants are included in additional paid-in capital in our consolidated balance sheets.

[0001327567-19-000008:notes:106]
Revolving Credit Facility

[0001327567-19-000008:notes:107]
On September 4, 2018, we entered into a credit agreement (the “Credit Agreement”) with certain institutional lenders that provides for a $400.0 million unsecured revolving credit facility (the “Credit Facility”), with an option to increase the amount of the Credit Facility by up to an additional $350.0 million, subject to certain conditions. The Credit Facility matures on the earlier of (i) September 4, 2023 and (ii) the date that is 91 days prior to the stated maturity of our 2023 Notes if (a) any of the 2023 Notes are still outstanding and (b) our unrestricted cash and cash equivalents are less than the then outstanding principal amount of our 2023 Notes plus $400.0 million.

[0001327567-19-000008:notes:108]
The borrowings under the Credit Facility bear interest, at our option, at a base rate plus a spread of 0.00% to 0.75%, or an adjusted LIBO rate plus a spread of 1.00% to 1.75%, in each case with such spread being determined based on our leverage ratio. We are obligated to pay an ongoing commitment fee on undrawn amounts at a rate of 0.125% to 0.250%, depending on our leverage ratio. As of January 31, 2019, there were no amounts outstanding and we were in compliance with all covenants under the Credit Agreement.


## us-gaap:DeferredChargesPolicyTextBlock

[0001327567-19-000008:notes:109]
[same as prior period, unchanged from 0001327567-18-000031:notes:102]

[0001327567-19-000008:notes:110]
[same as prior period, unchanged from 0001327567-18-000031:notes:103]

[0001327567-19-000008:notes:111]
[same as prior period, unchanged from 0001327567-18-000031:notes:104]


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001327567-19-000008:notes:112]
[same as prior period, unchanged from 0001327567-18-000031:notes:105]

[0001327567-19-000008:notes:113]
[same as prior period, unchanged from 0001327567-18-000031:notes:106]

[0001327567-19-000008:notes:114]
[same as prior period, unchanged from 0001327567-18-000031:notes:107]

[0001327567-19-000008:notes:115]
[same as prior period, unchanged from 0001327567-18-000031:notes:108]

[0001327567-19-000008:notes:116]
As of January 31, 2019 and July 31, 2018, the total notional amount of our outstanding foreign currency forward contracts was $205.1 million and $288.5 million, respectively. Refer to Note 3. Fair Value Measurements for the fair value of our derivative instruments as reported in our condensed consolidated balance sheets as of January 31, 2019.

[0001327567-19-000008:notes:117]
During the three and six months ended January 31, 2019 and 2018, both unrealized gains and losses recognized in AOCI related to our cash flow hedges and amounts reclassified into earnings were not material. Unrealized losses in AOCI related to our cash flow hedges as of January 31, 2019 and 2018 were not material.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001327567-19-000008:notes:118]
[same as prior period, unchanged from 0001327567-18-000031:notes:111]

[0001327567-19-000008:notes:119]
[same as prior period, unchanged from 0001327567-18-000031:notes:112]

[0001327567-19-000008:notes:120]
[same as prior period, unchanged from 0001327567-18-000031:notes:113]

[0001327567-19-000008:notes:121]
[same as prior period, unchanged from 0001327567-18-000031:notes:114]

[0001327567-19-000008:notes:122]
[same as prior period, unchanged from 0001327567-18-000031:notes:115]

[0001327567-19-000008:notes:123]
[same as prior period, unchanged from 0001327567-18-000031:notes:116]

[0001327567-19-000008:notes:124]
|  | Stock Options Outstanding |  | PSOs Outstanding |
|  | Number of Shares |  | Weighted-Average Exercise Price Per Share |  | Weighted-Average Remaining Contractual Term(Years) |  | Aggregate Intrinsic Value |  | Number of Shares |  | Weighted-Average Exercise Price Per Share |  | Weighted-Average Remaining Contractual Term(Years) |  | Aggregate Intrinsic Value |
| Balance—July 31, 2018 | 1.0 |  |  | $ | 13.29 |  |  | 3.1 |  | $ | 199.8 |  |  | 1.2 |  |  | $ | 198.50 |  |  | 7.0 |  | $ | — |  |
| Granted | — |  |  | $ | — |  |  |  |  |  |  | 2.6 |  |  | $ | 191.97 |  |  |  |  |  |
| Exercised | (0.4 | ) |  | $ | 13.88 |  |  |  |  |  |  | — |  |  | $ | — |  |  |  |  |  |
| Forfeited | — |  |  | $ | — |  |  |  |  |  |  | — |  |  | $ | — |  |  |  |  |  |
| Balance—January 31, 2019 | 0.6 |  |  | $ | 12.92 |  |  | 2.7 |  | $ | 136.2 |  |  | 3.8 |  |  | $ | 193.98 |  |  | 6.7 |  | $ | 78.6 |  |
| Exercisable—January 31, 2019 | 0.6 |  |  | $ | 12.92 |  |  | 2.7 |  | $ | 136.2 |  |  | 3.8 |  |  | $ | 193.98 |  |  | 6.7 |  | $ | 78.6 |  |

[0001327567-19-000008:notes:125]
During the six months ended January 31, 2019, we granted 2.6 million PSOs with both a market condition and a service condition to certain executives. The market condition requires the price of our common stock to equal or exceed $297.75, $397.00, $496.25, and $595.50 (the “stock price targets”) during the four-, five-, six-, and seven-year periods following the date of grant, respectively. To the extent that the stock price targets have been met, one-fourth of the PSOs will vest on the anniversary date of the grant date for such PSOs, subject to continued service. All outstanding PSOs may be exercised prior to vesting (“early exercised”). Shares of common stock issued upon early exercise of the PSOs will be restricted and, at our option, subject to repurchase if the option holder ceases to be a service provider.

[0001327567-19-000008:notes:126]
The aggregate fair value of the PSOs granted during the six months ended January 31, 2019 was $154.5 million, which was estimated on the grant date using a Monte Carlo simulation model. The following table summarizes the assumptions used and the resulting grant-date fair values of our PSOs:

[0001327567-19-000008:notes:127]
|  | Six Months Ended |
|  | January 31, 2019 |
| Volatility | 35.6% - 36.5% |  |
| Dividend yield | — | % |
| Risk-free interest rate | 3.1% - 3.2% |  |
| Weighted-average grant-date fair value per share | $56.44 - $59.64 |  |

[0001327567-19-000008:notes:128]
The expected volatility is based on a combination of implied volatility from traded options on our common stock and the historical volatility of our common stock. The dividend yield assumption is based on our current expectations about our anticipated dividend policy. The risk-free interest rate is based on the implied yield available on U.S. Treasury zero-coupon issues with terms equal to the contractual terms of each tranche. The expected term assumption takes into consideration the vesting term and the contractual term of the PSOs. We recognize share-based compensation expense for our PSOs on a straight-line basis over the requisite service period for each separately vesting portion of the award.

[0001327567-19-000008:notes:129]
[same as prior period, unchanged from 0001327567-18-000031:notes:121]

[0001327567-19-000008:notes:130]
[same as prior period, unchanged from 0001327567-18-000031:notes:122]

[0001327567-19-000008:notes:131]
|  | RSAs and PSAs Outstanding |  | RSUs and PSUs Outstanding |
|  | Number of Shares |  | Weighted-Average Grant-Date Fair Value Per Share |  | Number of Shares |  | Weighted-Average Grant-Date Fair Value Per Share |  | Weighted-Average Remaining Contractual Term(Years) |  | Aggregate Intrinsic Value |
| Balance—July 31, 2018 | 0.3 |  |  | $ | 160.85 |  |  | 6.7 |  |  | $ | 160.20 |  |  | 1.6 |  | $ | 1,335.2 |  |
| Granted(1)(2) | — |  |  | $ | — |  |  | 2.2 |  |  | $ | 195.59 |  |  |  |  |  |
| Vested | (0.2 | ) |  | $ | 167.32 |  |  | (1.4 | ) |  | $ | 154.31 |  |  |  |  |  |
| Forfeited | — |  |  | $ | — |  |  | (0.4 | ) |  | $ | 160.81 |  |  |  |  |  |
| Balance—January 31, 2019 | 0.1 |  |  | $ | 148.54 |  |  | 7.1 |  |  | $ | 172.30 |  |  | 1.5 |  | $ | 1,515.1 |  |

[0001327567-19-000008:notes:132]
[same as prior period, unchanged from 0001327567-18-000031:notes:125]

[0001327567-19-000008:notes:133]
[same as prior period, unchanged from 0001327567-18-000031:notes:126]

[0001327567-19-000008:notes:134]
[same as prior period, unchanged from 0001327567-18-000031:notes:127]

[0001327567-19-000008:notes:135]
[same as prior period, unchanged from 0001327567-18-000031:notes:128]

[0001327567-19-000008:notes:136]
[same as prior period, unchanged from 0001327567-18-000031:notes:129]

[0001327567-19-000008:notes:137]
|  | Three Months Ended |  | Six Months Ended |
|  | January 31, |  | January 31, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Cost of product revenue | $ | 1.4 |  |  | $ | 1.9 |  |  | $ | 3.0 |  |  | $ | 3.8 |  |
| Cost of subscription and support revenue | 18.2 |  |  | 19.9 |  |  | 35.7 |  |  | 35.8 |  |
| Research and development | 44.0 |  |  | 35.5 |  |  | 84.5 |  |  | 73.0 |  |
| Sales and marketing | 58.7 |  |  | 53.3 |  |  | 114.7 |  |  | 104.5 |  |
| General and administrative | 20.1 |  |  | 20.2 |  |  | 55.6 |  |  | 39.4 |  |
| Total share-based compensation | $ | 142.4 |  |  | $ | 130.8 |  |  | $ | 293.5 |  |  | $ | 256.5 |  |

[0001327567-19-000008:notes:138]
[same as prior period, unchanged from 0001327567-18-000031:notes:131]

[0001327567-19-000008:notes:139]
As of January 31, 2019, total compensation cost related to unvested share-based awards not yet recognized was $1.4 billion. This cost is expected to be amortized over a weighted-average period of approximately 2.8 years. Future grants will increase the amount of compensation expense to be recorded in these periods.


## us-gaap:EarningsPerShareTextBlock

[0001327567-19-000008:notes:140]
[same as prior period, unchanged from 0001327567-18-000031:notes:133]

[0001327567-19-000008:notes:141]
[same as prior period, unchanged from 0001327567-18-000031:notes:134]

[0001327567-19-000008:notes:142]
[same as prior period, unchanged from 0001327567-18-000031:notes:135]

[0001327567-19-000008:notes:143]
|  | Three Months Ended |  | Six Months Ended |
|  | January 31, |  | January 31, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
|  |  |  | (As Adjusted) |  |  |  | (As Adjusted) |
| Net loss | $ | (2.6 | ) |  | $ | (25.6 | ) |  | $ | (40.9 | ) |  | $ | (88.8 | ) |
| Weighted-average shares used to compute net loss per share, basic and diluted | 94.0 |  |  | 91.1 |  |  | 93.9 |  |  | 91.0 |  |
| Net loss per share, basic and diluted | $ | (0.03 | ) |  | $ | (0.28 | ) |  | $ | (0.44 | ) |  | $ | (0.98 | ) |

[0001327567-19-000008:notes:144]
[same as prior period, unchanged from 0001327567-18-000031:notes:137]

[0001327567-19-000008:notes:145]
|  | Three and Six Months Ended |
|  | January 31, |
|  | 2019 |  | 2018 |
| Convertible senior notes | 7.8 |  |  | 5.2 |  |
| Warrants related to the issuance of convertible senior notes | 11.6 |  |  | 5.2 |  |
| RSUs and PSUs | 7.1 |  |  | 6.6 |  |
| Options to purchase common stock, including PSOs | 4.4 |  |  | 1.4 |  |
| RSAs and PSAs | 0.1 |  |  | 0.6 |  |
| ESPP shares | 0.2 |  |  | 0.2 |  |
| Total | 31.2 |  |  | 19.2 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001327567-19-000008:notes:146]
[same as prior period, unchanged from 0001327567-18-000031:notes:139]

[0001327567-19-000008:notes:147]
[same as prior period, unchanged from 0001327567-18-000031:notes:140]

[0001327567-19-000008:notes:148]
[same as prior period, unchanged from 0001327567-18-000031:notes:141]

[0001327567-19-000008:notes:149]
[same as prior period, unchanged from 0001327567-18-000031:notes:142]

[0001327567-19-000008:notes:150]
[same as prior period, unchanged from 0001327567-18-000031:notes:143]

[0001327567-19-000008:notes:151]
The following table presents the fair value of our financial assets and liabilities measured at fair value on a recurring basis using the above input categories as of January 31, 2019 and July 31, 2018 (in millions):

[0001327567-19-000008:notes:152]
|  |  | January 31, 2019 |  | July 31, 2018 |
|  |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Cash equivalents: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 430.6 |  |  | $ | — |  |  | $ | — |  |  | $ | 430.6 |  |  | $ | 1,512.3 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,512.3 |  |
| Commercial paper |  | — |  |  | 39.4 |  |  | — |  |  | 39.4 |  |  | — |  |  | 52.0 |  |  | — |  |  | 52.0 |  |
| U.S. government and agency securities |  | — |  |  | 279.4 |  |  | — |  |  | 279.4 |  |  | — |  |  | 397.3 |  |  | — |  |  | 397.3 |  |
| Total cash equivalents |  | 430.6 |  |  | 318.8 |  |  | — |  |  | 749.4 |  |  | 1,512.3 |  |  | 449.3 |  |  | — |  |  | 1,961.6 |  |
| Short-term investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Certificates of deposit |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 5.4 |  |  | — |  |  | 5.4 |  |
| Non-U.S. government securities |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 20.0 |  |  | — |  |  | 20.0 |  |
| Commercial paper |  | — |  |  | 50.2 |  |  | — |  |  | 50.2 |  |  | — |  |  | 22.3 |  |  | — |  |  | 22.3 |  |
| Corporate debt securities |  | — |  |  | 216.3 |  |  | — |  |  | 216.3 |  |  | — |  |  | 139.8 |  |  | — |  |  | 139.8 |  |
| U.S. government and agency securities |  | — |  |  | 1,435.7 |  |  | — |  |  | 1,435.7 |  |  | — |  |  | 709.0 |  |  | — |  |  | 709.0 |  |
| Total short-term investments |  | — |  |  | 1,702.2 |  |  | — |  |  | 1,702.2 |  |  | — |  |  | 896.5 |  |  | — |  |  | 896.5 |  |
| Long-term investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate debt securities |  | — |  |  | 279.1 |  |  | — |  |  | 279.1 |  |  | — |  |  | 153.6 |  |  | — |  |  | 153.6 |  |
| U.S. government and agency securities |  | — |  |  | 529.5 |  |  | — |  |  | 529.5 |  |  | — |  |  | 393.9 |  |  | — |  |  | 393.9 |  |
| Total long-term investments |  | — |  |  | 808.6 |  |  | — |  |  | 808.6 |  |  | — |  |  | 547.5 |  |  | — |  |  | 547.5 |  |
| Prepaid expenses and other current assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency forward contracts |  | — |  |  | 0.3 |  |  | — |  |  | 0.3 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Total prepaid expenses and other current assets |  | — |  |  | 0.3 |  |  | — |  |  | 0.3 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Total assets measured at fair value |  | $ | 430.6 |  |  | $ | 2,829.9 |  |  | $ | — |  |  | $ | 3,260.5 |  |  | $ | 1,512.3 |  |  | $ | 1,893.3 |  |  | $ | — |  |  | $ | 3,405.6 |  |
| Accrued and other liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency forward contracts |  | $ | — |  |  | $ | 5.6 |  |  | $ | — |  |  | $ | 5.6 |  |  | $ | — |  |  | $ | 6.9 |  |  | $ | — |  |  | $ | 6.9 |  |
| Total accrued and other liabilities |  | — |  |  | 5.6 |  |  | — |  |  | 5.6 |  |  | — |  |  | 6.9 |  |  | — |  |  | 6.9 |  |
| Total liabilities measured at fair value |  | $ | — |  |  | $ | 5.6 |  |  | $ | — |  |  | $ | 5.6 |  |  | $ | — |  |  | $ | 6.9 |  |  | $ | — |  |  | $ | 6.9 |  |

[0001327567-19-000008:notes:153]
Refer to Note 9. Debt for the carrying amount and estimated fair value of our convertible senior notes as of January 31, 2019 and July 31, 2018.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001327567-19-000008:notes:154]
[same as prior period, unchanged from 0001327567-18-000031:notes:147]

[0001327567-19-000008:notes:155]
[same as prior period, unchanged from 0001327567-18-000031:notes:148]

[0001327567-19-000008:notes:156]
The following table presents details of our goodwill during the six months ended January 31, 2019 (in millions):

[0001327567-19-000008:notes:157]
|  | Amount |
| Balance as of July 31, 2018 | $ | 522.8 |  |
| Goodwill acquired | 113.6 |  |
| Balance as of January 31, 2019 | $ | 636.4 |  |

[0001327567-19-000008:notes:158]
[same as prior period, unchanged from 0001327567-18-000031:notes:151]

[0001327567-19-000008:notes:159]
The following table presents details of our purchased intangible assets as of January 31, 2019 and July 31, 2018 (in millions):

[0001327567-19-000008:notes:160]
|  | January 31, 2019 |  | July 31, 2018 |
|  | Gross Carrying Amount |  | Accumulated Amortization |  | Net Carrying Amount |  | Gross Carrying Amount |  | Accumulated Amortization |  | Net Carrying Amount |
| Intangible assets subject to amortization: |  |  |  |  |  |  |  |  |  |  |  |
| Developed technology | $ | 203.3 |  |  | $ | (54.5 | ) |  | $ | 148.8 |  |  | $ | 154.7 |  |  | $ | (38.2 | ) |  | $ | 116.5 |  |
| Customer relationships | 17.5 |  |  | (2.3 | ) |  | 15.2 |  |  | 12.2 |  |  | (1.2 | ) |  | 11.0 |  |
| Acquired intellectual property | 8.9 |  |  | (4.9 | ) |  | 4.0 |  |  | 8.9 |  |  | (4.5 | ) |  | 4.4 |  |
| Trade name and trademarks | 9.4 |  |  | (6.4 | ) |  | 3.0 |  |  | 8.5 |  |  | (0.4 | ) |  | 8.1 |  |
| Other | 2.2 |  |  | (2.2 | ) |  | — |  |  | 2.2 |  |  | (2.2 | ) |  | — |  |
| Total intangible assets subject to amortization | 241.3 |  |  | (70.3 | ) |  | 171.0 |  |  | 186.5 |  |  | (46.5 | ) |  | 140.0 |  |
| Intangible assets not subject to amortization: |  |  |  |  |  |  |  |  |  |  |  |
| In-process research and development | 0.8 |  |  | — |  |  | 0.8 |  |  | 0.8 |  |  | — |  |  | 0.8 |  |
| Total purchased intangible assets | $ | 242.1 |  |  | $ | (70.3 | ) |  | $ | 171.8 |  |  | $ | 187.3 |  |  | $ | (46.5 | ) |  | $ | 140.8 |  |

[0001327567-19-000008:notes:161]
We recognized amortization expense of $14.4 million and $23.8 million for the three and six months ended January 31, 2019, respectively, and $2.7 million and $5.4 million for the three and six months ended January 31, 2018, respectively.

[0001327567-19-000008:notes:162]
The following table summarizes estimated future amortization expense of our intangible assets as of January 31, 2019 (in millions):

[0001327567-19-000008:notes:163]
|  | Amount |
| Fiscal years ending July 31: |  |
| Remaining 2019 | $ | 22.7 |  |
| 2020 | 39.4 |  |
| 2021 | 37.4 |  |
| 2022 | 32.9 |  |
| 2023 | 20.4 |  |
| 2024 and thereafter | 18.2 |  |
| Total future amortization expense | $ | 171.0 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001327567-19-000008:notes:164]
[same as prior period, unchanged from 0001327567-18-000031:notes:157]

[0001327567-19-000008:notes:165]
Our provision for income taxes for the three and six months ended January 31, 2019 reflects an effective tax rate of 230.0% and (2.8)%, respectively. Our effective tax rate for the six months ended January 31, 2019 was negative as we recorded a provision for income taxes on year to date losses. The key components of our income tax provision, excluding one-time items, primarily consist of foreign income taxes and withholding taxes. During the six months ended January 31, 2019, the effect of these key components was primarily offset by a one-time tax benefit of $9.4 million from a partial release of our valuation allowance related to the acquisition of RedLock Inc. recorded during the three months ended October 31, 2018. Our effective tax rates differ from the U.S. statutory tax rate primarily due to deductibility of our share-based compensation, foreign income at other than U.S. tax rates, and changes in our valuation allowance.

[0001327567-19-000008:notes:166]
Our provision for income taxes for the three and six months ended January 31, 2018 reflects an effective tax rate of (6.7)% and (12.4)%. Our effective tax rates for these periods were negative as we recorded a provision for income taxes on year to date losses. The key components of our income tax provision primarily consisted of foreign income taxes, withholding taxes, amortization of our deferred tax charges, and a one-time tax benefit during the three months ended January 31, 2018, resulting from new tax legislation enacted during the period. Our effective tax rates differed from the U.S. statutory tax rate primarily due to changes in non-deductible share-based compensation, foreign income at other than U.S. tax rates, and charges in our valuation allowance.

[0001327567-19-000008:notes:167]
In December 2017, the Tax Cuts and Jobs Act (“TCJA”) was enacted into law. The SEC staff and FASB previously issued guidance that allowed companies to record provisional amounts for the effects of the TCJA during a measurement period not to extend beyond one year from the enactment date. The measurement period ended in December 2018 and we completed our accounting for the income tax effects of the TCJA during the three months ended January 31, 2019. During the three and six months ended January 31, 2019, we did not have any significant adjustments to provisional estimates recorded in previous periods. The recorded impact for the effects of the TCJA is based on our current knowledge, assumptions, and interpretations of available guidance. We will continue to monitor the issuance of further guidance and record the necessary adjustments in the period additional guidance is issued.


## us-gaap:InvestmentsClassifiedByContractualMaturityDateTableTextBlock

[0001327567-19-000008:notes:168]
The following table summarizes the amortized cost and fair value of our available-for-sale securities as of January 31, 2019, by contractual years-to-maturity (in millions):

[0001327567-19-000008:notes:169]
|  | Amortized Cost |  | Fair Value |
| Due within one year | $ | 2,023.2 |  |  | $ | 2,021.0 |  |
| Due between one and three years | 809.7 |  |  | 808.6 |  |
| Total | $ | 2,832.9 |  |  | $ | 2,829.6 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001327567-19-000008:notes:170]
Cash Equivalents and Investments

[0001327567-19-000008:notes:171]
Available-for-sale Securities

[0001327567-19-000008:notes:172]
Unrealized losses related to these securities are due to interest rate fluctuations as opposed to credit quality. In addition, we do not intend to sell and it is not likely that we would be required to sell these securities before recovery of their amortized cost basis, which may be at maturity. As a result, there were no other-than-temporary impairments for these securities at January 31, 2019 and July 31, 2018.

[0001327567-19-000008:notes:173]
Marketable Equity Securities

[0001327567-19-000008:notes:174]
Marketable equity securities consist of money market funds and are included in cash and cash equivalents in our condensed consolidated balance sheets. As of January 31, 2019 and July 31, 2018, the carrying value of our marketable equity securities were $430.6 million and $1.5 billion, respectively. During the three and six months ended January 31, 2019 and 2018, there were no unrealized gains or losses recognized for these securities.


## us-gaap:OtherNonoperatingIncomeAndExpenseTextBlock

[0001327567-19-000008:notes:175]
[same as prior period, unchanged from 0001327567-18-000031:notes:168]

[0001327567-19-000008:notes:176]
[same as prior period, unchanged from 0001327567-18-000031:notes:169]

[0001327567-19-000008:notes:177]
|  | Three Months Ended |  | Six Months Ended |
|  | January 31, |  | January 31, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Interest income | $ | 18.0 |  |  | $ | 5.9 |  |  | $ | 33.4 |  |  | $ | 11.0 |  |
| Foreign currency exchange gains (losses), net | (1.2 | ) |  | (1.2 | ) |  | (1.2 | ) |  | (1.8 | ) |
| Other | (0.8 | ) |  | 0.2 |  |  | (3.2 | ) |  | 0.5 |  |
| Total other income, net | $ | 16.0 |  |  | $ | 4.9 |  |  | $ | 29.0 |  |  | $ | 9.7 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001327567-19-000008:notes:178]
[same as prior period, unchanged from 0001327567-18-000031:notes:171]

[0001327567-19-000008:notes:179]
[same as prior period, unchanged from 0001327567-18-000031:notes:172]

[0001327567-19-000008:notes:180]
[same as prior period, unchanged from 0001327567-18-000031:notes:173]

[0001327567-19-000008:notes:181]
[same as prior period, unchanged from 0001327567-18-000031:notes:174]

[0001327567-19-000008:notes:182]
[same as prior period, unchanged from 0001327567-18-000031:notes:175]

[0001327567-19-000008:notes:183]
[same as prior period, unchanged from 0001327567-18-000031:notes:176]

[0001327567-19-000008:notes:184]
[same as prior period, unchanged from 0001327567-18-000031:notes:177]

[0001327567-19-000008:notes:185]
[same as prior period, unchanged from 0001327567-18-000031:notes:178]

[0001327567-19-000008:notes:186]
[same as prior period, unchanged from 0001327567-18-000031:notes:179]

[0001327567-19-000008:notes:187]
[same as prior period, unchanged from 0001327567-18-000031:notes:180]

[0001327567-19-000008:notes:188]
[same as prior period, unchanged from 0001327567-18-000031:notes:181]

[0001327567-19-000008:notes:189]
[same as prior period, unchanged from 0001327567-18-000031:notes:182]

[0001327567-19-000008:notes:190]
[same as prior period, unchanged from 0001327567-18-000031:notes:183]

[0001327567-19-000008:notes:191]
[same as prior period, unchanged from 0001327567-18-000031:notes:184]

[0001327567-19-000008:notes:192]
[same as prior period, unchanged from 0001327567-18-000031:notes:185]

[0001327567-19-000008:notes:193]
[same as prior period, unchanged from 0001327567-18-000031:notes:186]

[0001327567-19-000008:notes:194]
[same as prior period, unchanged from 0001327567-18-000031:notes:187]

[0001327567-19-000008:notes:195]
We record deferred revenue when cash payments are received or due in advance of our performance. Our payment terms typically require payment within 30 to 45 days of the date we issue an invoice. The current portion of deferred revenue represents the amounts that are expected to be recognized as revenue within one year of the condensed consolidated balance sheet date. During the six months ended January 31, 2019, we recognized approximately $695.0 million of revenue pertaining to amounts that were deferred as of July 31, 2018.

[0001327567-19-000008:notes:196]
[same as prior period, unchanged from 0001327567-18-000031:notes:189]

[0001327567-19-000008:notes:197]
Revenue expected to be recognized from remaining performance obligations was $2.6 billion as of January 31, 2019, of which we expect to recognize approximately $1.4 billion over the next 12 months and the remainder thereafter.

[0001327567-19-000008:notes:198]
[same as prior period, unchanged from 0001327567-18-000031:notes:191]

[0001327567-19-000008:notes:199]
[same as prior period, unchanged from 0001327567-18-000031:notes:192]

[0001327567-19-000008:notes:200]
|  | Three Months Ended January 31, |  | Six Months Ended January 31, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
|  |  |  | (As Adjusted) |  |  |  | (As Adjusted) |
| Revenue: |  |  |  |  |  |  |  |
| Americas |  |  |  |  |  |  |  |
| United States | $ | 434.6 |  |  | $ | 346.0 |  |  | $ | 850.5 |  |  | $ | 672.0 |  |
| Other Americas | 40.4 |  |  | 27.3 |  |  | 74.7 |  |  | 50.6 |  |
| Total Americas | 475.0 |  |  | 373.3 |  |  | 925.2 |  |  | 722.6 |  |
| Europe, the Middle East, and Africa (“EMEA”) | 148.3 |  |  | 107.2 |  |  | 276.0 |  |  | 201.9 |  |
| Asia Pacific and Japan (“APAC”) | 87.9 |  |  | 65.1 |  |  | 166.0 |  |  | 122.9 |  |
| Total revenue | $ | 711.2 |  |  | $ | 545.6 |  |  | $ | 1,367.2 |  |  | $ | 1,047.4 |  |

[0001327567-19-000008:notes:201]
[same as prior period, unchanged from 0001327567-18-000031:notes:194]

[0001327567-19-000008:notes:202]
|  | Three Months Ended January 31, |  | Six Months Ended January 31, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
|  |  |  | (As Adjusted) |  |  |  | (As Adjusted) |
| Revenue: |  |  |  |  |  |  |  |
| Product | $ | 271.6 |  |  | $ | 204.8 |  |  | $ | 512.1 |  |  | $ | 389.6 |  |
| Subscription and support |  |  |  |  |  |  |  |
| Subscription | 249.7 |  |  | 183.3 |  |  | 481.0 |  |  | 352.3 |  |
| Support | 189.9 |  |  | 157.5 |  |  | 374.1 |  |  | 305.5 |  |
| Total subscription and support | 439.6 |  |  | 340.8 |  |  | 855.1 |  |  | 657.8 |  |
| Total revenue | $ | 711.2 |  |  | $ | 545.6 |  |  | $ | 1,367.2 |  |  | $ | 1,047.4 |  |

[0001327567-19-000008:notes:203]
We recognized amortization expense for our deferred contract costs of $41.9 million and $83.0 million during the three and six months ended January 31, 2019, respectively, and $29.2 million and $57.3 million during the three and six months ended January 31, 2018, respectively. We did not recognize any impairment losses on our deferred contract costs during the three and six months ended January 31, 2019 or 2018.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001327567-19-000008:notes:204]
[same as prior period, unchanged from 0001327567-18-000031:notes:197]

[0001327567-19-000008:notes:205]
[same as prior period, unchanged from 0001327567-18-000031:notes:198]

[0001327567-19-000008:notes:206]
In August 2016, our board of directors authorized a $500.0 million share repurchase program to be funded from available working capital. In February 2017, our board of directors authorized a $500.0 million increase to our repurchase program, bringing the total authorization to $1.0 billion. Repurchases could be made at management’s discretion from time to time on the open market, through privately negotiated transactions, transactions structured through investment banking institutions, block purchase techniques, 10b5-1 trading plans, or a combination of the foregoing. During the three and six months ended January 31, 2019, we repurchased and retired 1.9 million shares of our common stock under the authorization for an aggregate purchase price of $330.0 million, including transaction costs. The total price of the shares repurchased and related transaction costs are reflected as a reduction to common stock and additional paid-in capital on our condensed consolidated balance sheets. The repurchase program expired on December 31, 2018.


## us-gaap:SubsequentEventsTextBlock

[0001327567-19-000008:notes:207]
Subsequent Events

[0001327567-19-000008:notes:208]
Business Combination

[0001327567-19-000008:notes:209]
In February 2019, we entered into a definitive agreement to acquire Demisto, Inc. (“Demisto”), a privately-held security company, in exchange for total consideration of approximately $560.0 million in cash and common stock, subject to adjustments. The number of shares of common stock to be issued in connection with the transaction will be finalized upon closing. The acquisition expands the functionality of our platform with the addition of Demisto’s security, orchestration, automation, and response product. The acquisition is expected to close during our third quarter of fiscal 2019.
