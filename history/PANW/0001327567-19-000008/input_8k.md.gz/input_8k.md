# PANW 8-K — 0001327567-19-000006 filed 2019-02-26

## item codes, every 8-K on or before 2019-02-27

- 2019-02-26 0001327567-19-000006 — 2.02, 8.01, 9.01
- 2019-02-19 0001327567-19-000003 — 3.02
- 2018-12-11 0001327567-18-000033 — 5.07
- 2018-11-29 0001327567-18-000029 — 2.02, 9.01
- 2018-10-15 0001193125-18-299312 — 5.02, 9.01
- 2018-09-25 0001193125-18-282542 — 5.02
- 2018-09-14 0001193125-18-274239 — 5.03, 9.01
- 2018-09-06 0001327567-18-000018 — 1.01, 2.02, 2.03, 9.01
- 2018-07-13 0001193125-18-217281 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2018-06-04 0001327567-18-000011 — 2.02, 5.02, 9.01
- 2018-02-26 0001327567-18-000004 — 2.02, 5.02, 7.01, 9.01
- 2017-12-12 0001193125-17-367477 — 5.07
- 2017-11-20 0001327567-17-000032 — 2.02, 5.02, 9.01
- 2017-08-31 0001327567-17-000021 — 2.02, 5.02, 9.01
- 2017-05-31 0001327567-17-000016 — 2.02, 9.01
- 2017-02-28 0001327567-17-000005 — 2.02, 8.01, 9.01
- 2016-12-12 0001193125-16-790757 — 5.07
- 2016-11-21 0001327567-16-000071 — 2.02, 9.01
- 2016-10-24 0001193125-16-745121 — 5.02, 9.01
- 2016-08-30 0001327567-16-000057 — 2.02, 5.03, 8.01, 9.01
- 2016-08-22 0001193125-16-687588 — 5.02, 9.01
- 2016-05-26 0001327567-16-000051 — 2.02, 9.01
- 2016-02-25 0001327567-16-000044 — 2.02, 5.02, 9.01
- 2015-12-14 0001327567-15-000038 — 5.07
- 2015-12-14 0001193125-15-402588 — 1.01, 9.01
- 2015-11-23 0001327567-15-000033 — 2.02, 9.01
- 2015-10-19 0001193125-15-347005 — 1.01, 9.01 — amendment, the index does not say of what
- 2015-09-09 0001327567-15-000022 — 2.02, 9.01
- 2015-08-19 0001193125-15-296115 — 1.01, 2.03
- 2015-06-01 0001193125-15-207786 — 1.01, 2.03
- 2015-05-27 0001327567-15-000015 — 2.02, 9.01
- 2015-03-02 0001327567-15-000006 — 2.02, 9.01
- 2014-12-15 0001327567-14-000046 — 5.07
- 2014-11-24 0001327567-14-000040 — 2.02, 9.01
- 2014-09-22 0001193125-14-348581 — 5.02, 9.01
- 2014-09-09 0001327567-14-000025 — 2.02, 9.01
- 2014-07-01 0001193125-14-257824 — 1.01, 2.03, 3.02, 9.01
- 2014-06-26 0001193125-14-249529 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2014-06-20 0001327567-14-000020 — 9.01 — amendment of 0001193125-14-140511
- 2014-06-04 0001327567-14-000016 — 3.02
- 2014-05-30 0001193125-14-218158 — 2.02 — amendment, the index does not say of what
- 2014-05-28 0001193125-14-215060 — 1.01, 2.02, 3.02, 9.01
- 2014-04-11 0001193125-14-140511 — 2.01, 3.02, 7.01, 9.01
- 2014-03-24 0001193125-14-111318 — 1.01, 3.02, 7.01, 9.01
- 2014-03-13 0001327567-14-000009 — 5.02
- 2014-02-24 0001193125-14-063754 — 2.02, 9.01
- 2013-12-12 0001327567-13-000040 — 5.07
- 2013-11-25 0001327567-13-000033 — 2.02, 9.01
- 2013-09-30 0001193125-13-384966 — 8.01
- 2013-09-09 0001193125-13-361421 — 2.02, 9.01
- 2013-05-30 0001193125-13-241542 — 2.02, 5.02, 9.01
- 2013-03-11 0001193125-13-101082 — 5.02, 9.01
- 2013-02-28 0001193125-13-084193 — 2.02, 9.01
- 2012-12-14 0001193125-12-503335 — 5.07
- 2012-12-06 0001193125-12-493700 — 2.02, 9.01
- 2012-09-24 0001193125-12-401534 — 1.01, 2.03
- 2012-09-20 0001193125-12-398433 — 5.02, 9.01
- 2012-09-10 0001193125-12-386605 — 2.02, 9.01

## late-filing notifications on or before 2019-02-27

- none on or before 2019-02-27

## item 2.02 — earnings release, exhibit 99.1

[0001327567-19-000006:8k_2_02:1]
EX-99.1
2
ex991q219earningsrelease.htm
EXHIBIT 99.1

[0001327567-19-000006:8k_2_02:2]
Exhibit

[0001327567-19-000006:8k_2_02:3]
Exhibit 99.1

[0001327567-19-000006:8k_2_02:4]
Palo Alto Networks Reports Fiscal Second Quarter 2019 Financial Results

[0001327567-19-000006:8k_2_02:5]
| • | Fiscal second quarter revenue grows 30 percent year over year to $711.2 million |

[0001327567-19-000006:8k_2_02:6]
| • | Fiscal second quarter billings grow 27 percent year over year to $852.5 million |

[0001327567-19-000006:8k_2_02:7]
| • | Deferred revenue grows 32 percent year over year to $2.5 billion |

[0001327567-19-000006:8k_2_02:8]
| • | Announces $1 billion share repurchase authorization |

[0001327567-19-000006:8k_2_02:9]
SANTA CLARA, Calif. — February 26, 2019 — Palo Alto Networks (NYSE: PANW), the global cybersecurity leader, announced today financial results for its fiscal second quarter 2019, ended January 31, 2019.

[0001327567-19-000006:8k_2_02:10]
Total revenue for the fiscal second quarter 2019 grew 30 percent year over year to $711.2 million, compared with total revenue of $545.6 million for the fiscal second quarter 2018. GAAP net loss for the fiscal second quarter 2019 was $2.6 million, or $0.03 per diluted share, compared with GAAP net loss of $25.6 million, or $0.28 per diluted share, for the fiscal second quarter 2018.

[0001327567-19-000006:8k_2_02:11]
Non-GAAP net income for the fiscal second quarter 2019 was $147.0 million, or $1.51 per diluted share, compared with non-GAAP net income of $98.7 million, or $1.05 per diluted share, for the fiscal second quarter 2018. A reconciliation between GAAP and non-GAAP information is contained in the tables below.

[0001327567-19-000006:8k_2_02:12]
“We remain focused on delivering to our customers the best security in the market,” said Nikesh Arora, chief executive officer of Palo Alto Networks.  “Our recently introduced products and

[0001327567-19-000006:8k_2_02:13]
services, including Cortex XDR, Traps 6.0, PAN-OS 9.0, the DNS Security Service subscription, and our fastest ever Next-Generation Firewall, coupled with the proposed acquisition of Demisto, further enhance and expand our capabilities, making security simpler and more effective through the use of artificial intelligence, analytics, automation and orchestration.”

[0001327567-19-000006:8k_2_02:14]
In a separate news release issued today, the company announced Cortex, the industry’s only open and integrated AI-based continuous security platform, as well as Cortex XDR and Traps 6.0 Endpoint Protection.

[0001327567-19-000006:8k_2_02:15]
$1.0 Billion Share Repurchase Authorization

[0001327567-19-000006:8k_2_02:16]
On February 22, 2019, our board of directors authorized a $1.0 billion share repurchase. This authorization allows the company to repurchase its shares opportunistically and will be funded from available working capital. Repurchases may be made at management’s discretion from time to time on the open market, through privately negotiated transactions, transactions structured through investment banking institutions, block purchase techniques, 10b5-1 trading plans, or a combination of the foregoing. The repurchase authorization will expire on December 31, 2020, and may be suspended or discontinued by the company at any time without prior notice. The company had approximately 93.7 million shares of common stock outstanding as of January 31, 2019.

[0001327567-19-000006:8k_2_02:17]
Financial Outlook

[0001327567-19-000006:8k_2_02:18]
Palo Alto Networks provides guidance based on current market conditions and expectations.

[0001327567-19-000006:8k_2_02:19]
2

[0001327567-19-000006:8k_2_02:20]
For the fiscal third quarter 2019, we expect:

[0001327567-19-000006:8k_2_02:21]
| • | Total revenue in the range of $697 to $707 million, representing year-over-year growth between 23 percent and 25 percent on an ASC 606 basis. |

[0001327567-19-000006:8k_2_02:22]
| • | Diluted non-GAAP net income per share in the range of $1.23 to $1.25, which includes expenses related to the proposed Demisto acquisition, using 99 to 101 million shares on an ASC 606 basis. |

[0001327567-19-000006:8k_2_02:23]
Guidance for non-GAAP financial measures excludes share-based compensation-related charges, including share-based payroll tax expense, acquisition-related costs, amortization expense of acquired intangible assets, litigation-related charges, including legal settlements, facility exit costs, non-cash charges related to convertible notes, foreign currency gains (losses), and income and other tax effects associated with these items, along with certain non-recurring expenses. We have not reconciled diluted non-GAAP net income per share guidance to GAAP net income (loss) per diluted share because we do not provide guidance on GAAP net income (loss) and would not be able to present the various reconciling cash and non-cash items between GAAP net income (loss) and non-GAAP net income, including share-based compensation expense, without unreasonable effort. Share-based compensation expense is impacted by the company’s future hiring and retention needs and, to a lesser extent, the future fair market value of the company’s common stock, all of which is difficult to predict and subject to constant change. The actual amounts of such reconciling items will have a significant impact on the company’s GAAP net income (loss) per diluted share.

[0001327567-19-000006:8k_2_02:24]
Conference Call Information

[0001327567-19-000006:8k_2_02:25]
Palo Alto Networks will host a conference call for analysts and investors to discuss its fiscal second quarter 2019 results and outlook for its fiscal third quarter 2019 today at 4:30 p.m.

[0001327567-19-000006:8k_2_02:26]
Eastern time/1:30 p.m. Pacific time. Open to the public, investors may access the call by dialing 1-855-719-5012 or 1-334-323-0522 and using conference ID 3411135. A live audio webcast of the conference call, along with supplemental financial information, will also be accessible from the “Investors” section of our website at investors.paloaltonetworks.com. Following the webcast, an archived version will be available on our website for one year. A telephonic replay of the call will be available three hours after the call, will run for ten days, and may be accessed by dialing 1-888-203-1112 or 1-719-457-0820 and entering the passcode 3411135.

[0001327567-19-000006:8k_2_02:27]
Forward-Looking Statements

[0001327567-19-000006:8k_2_02:28]
This press release contains forward-looking statements that involve risks and uncertainties, including statements regarding the benefits and effectiveness of the integration of Demisto’s technologies and other recently launched technologies into our existing platform, our financial outlook for the fiscal third quarter 2019, and our plans with respect to our share repurchase authorizations. There are a significant number of factors that could cause actual results to differ materially from statements made in this press release, including: the possibility that share repurchases may be suspended or discontinued; fluctuations in the trading volume and market price of shares of our common stock; competing future investment opportunities and alternate uses of cash; our limited operating history; our ability as an organization to acquire and integrate other companies, products or technologies in a successful manner; risks associated with managing our rapid growth; the risks associated with new products and subscription and support offerings, including the discovery of software bugs; our ability to attract and retain new customers; delays in the development or release of new subscription offerings, or the failure to timely develop and achieve market acceptance of new products and subscriptions as well as existing products and subscription and support offerings; rapidly evolving technological

[0001327567-19-000006:8k_2_02:29]
4

[0001327567-19-000006:8k_2_02:30]
developments in the market for security products and subscription and support offerings; length of sales cycles; and general market, political, economic and business conditions.

[0001327567-19-000006:8k_2_02:31]
Additional risks and uncertainties that could affect our financial results are included under the captions “Risk Factors” and “Management’s Discussion and Analysis of Financial Condition and Results of Operations” in our Quarterly Report on Form 10-Q filed with the SEC on November 30, 2018, which is available on our website at investors.paloaltonetworks.com and on the SEC’s website at www.sec.gov. Additional information will also be set forth in other filings that we make with the SEC from time to time. All forward-looking statements in this press release are based on information available to us as of the date hereof, and we do not assume any obligation to update the forward-looking statements provided to reflect events that occur or circumstances that exist after the date on which they were made.

[0001327567-19-000006:8k_2_02:32]
Non-GAAP Financial Measures and Other Key Metrics

[0001327567-19-000006:8k_2_02:33]
Palo Alto Networks has provided in this press release financial information that has not been prepared in accordance with generally accepted accounting principles in the United States (GAAP). The company uses these non-GAAP financial measures and key metrics internally in analyzing its financial results and believes that the use of these non-GAAP financial measures and key metrics is useful to investors as an additional tool to evaluate ongoing operating results and trends, and in comparing the company’s financial results with other companies in its industry, many of which present similar non-GAAP financial measures or key metrics.

[0001327567-19-000006:8k_2_02:34]
The presentation of these non-GAAP financial measures and key metrics are not meant to be considered in isolation or as a substitute for comparable GAAP financial measures and should be read only in conjunction with the company’s consolidated financial statements prepared in

[0001327567-19-000006:8k_2_02:35]
accordance with GAAP. A reconciliation of the company’s historical non-GAAP financial measures and key metrics to their most directly comparable GAAP measures has been provided in the financial statement tables included in this press release, and investors are encouraged to review these reconciliations.

[0001327567-19-000006:8k_2_02:36]
Non-GAAP net income and net income per share, diluted. Palo Alto Networks defines non-GAAP net income as net income (loss) plus share-based compensation-related charges, including share-based payroll tax expense, acquisition-related costs, amortization expense of acquired intangible assets, litigation-related charges, including legal settlements, facility exit costs, non-cash charges related to convertible notes, and intellectual property restructuring-related charges. The company also excludes from non-GAAP net income the foreign currency gains (losses) and tax effects associated with these items in order to provide a complete picture of the company’s recurring core business operating results. The company defines non-GAAP net income per share, diluted, as non-GAAP net income divided by the weighted-average diluted shares outstanding, which includes the potentially dilutive effect of the company’s employee equity incentive plan awards and the company’s convertible senior notes outstanding and related warrants, after giving effect to the anti-dilutive impact of the company’s note hedge agreements, which reduces the potential economic dilution that otherwise would occur upon conversion of the company’s convertible senior notes. Under GAAP, the anti-dilutive impact of the note hedge is not reflected in diluted shares outstanding. The company believes that excluding these items from non-GAAP net income and net income per share, diluted, provides management and investors with greater visibility into the underlying performance of the company’s core business operating results, meaning its operating performance excluding these items and, from time to time, other discrete charges that are infrequent in nature, over multiple periods.

[0001327567-19-000006:8k_2_02:37]
6

[0001327567-19-000006:8k_2_02:38]
Billings. Palo Alto Networks defines billings as total revenue plus the change in total deferred revenue, net of acquired deferred revenue, during the period. The company considers billings to be a key metric used by management to manage the company’s business given the company’s hybrid-SaaS revenue model, and believes billings provides investors with an important indicator of the health and visibility of the company’s business because it includes subscription and support revenue, which is recognized ratably over the contractual service period, and product revenue, which is recognized at the time of shipment, provided that all other conditions for revenue recognition have been met. The company considers billings to be a useful metric for management and investors, particularly if sales of subscriptions continue to increase and the company experiences strong renewal rates for subscriptions and support.

[0001327567-19-000006:8k_2_02:39]
Investors are cautioned that there are a number of limitations associated with the use of non-GAAP financial measures and key metrics as analytical tools. In particular, the billings metric reported by the company includes amounts that have not yet been recognized as revenue. In addition, many of the adjustments to the company’s GAAP financial measures reflect the exclusion of items that are recurring and will be reflected in the company’s financial results for the foreseeable future, such as share-based compensation, which is an important part of Palo Alto Networks employees’ compensation and impacts their performance. Furthermore, these non-GAAP financial measures are not based on any standardized methodology prescribed by GAAP, and the components that Palo Alto Networks excludes in its calculation of non-GAAP financial measures may differ from the components that its peer companies exclude when they report their non-GAAP results of operations. Palo Alto Networks compensates for these limitations by providing specific information regarding the GAAP amounts excluded from these

[0001327567-19-000006:8k_2_02:40]
7

[0001327567-19-000006:8k_2_02:41]
non-GAAP financial measures. In the future, the company may also exclude non-recurring expenses and other expenses that do not reflect the company’s core business operating results.

[0001327567-19-000006:8k_2_02:42]
About Palo Alto Networks

[0001327567-19-000006:8k_2_02:43]
We are the global cybersecurity leader, known for always challenging the security status quo. Our mission is to protect our way of life in the digital age by preventing successful cyberattacks. This has given us the privilege of safely enabling tens of thousands of organizations and their customers. Our pioneering Security Operating Platform emboldens their digital transformation with continuous innovation that seizes the latest breakthroughs in security, automation, and analytics. By delivering a true platform and empowering a growing ecosystem of change-makers like us, we provide highly effective and innovative cybersecurity across clouds, networks, and mobile devices.

[0001327567-19-000006:8k_2_02:44]
Palo Alto Networks and the Palo Alto Networks logo are trademarks of Palo Alto Networks, Inc. in the United States and in jurisdictions throughout the world. All other trademarks, trade names or service marks used or mentioned herein belong to their respective owners.

[0001327567-19-000006:8k_2_02:45]
Media Contact:

[0001327567-19-000006:8k_2_02:46]
Kristen Batch

[0001327567-19-000006:8k_2_02:47]
Senior Vice President of Corporate Communications, Palo Alto Networks

[0001327567-19-000006:8k_2_02:48]
Mobile: 503-516-6297

[0001327567-19-000006:8k_2_02:49]
kbatch@paloaltonetworks.com

[0001327567-19-000006:8k_2_02:50]
| Palo Alto Networks, Inc. |
| Preliminary Condensed Consolidated Statements of Operations |
| (In millions, except per share data) |
| (Unaudited) |
|  | Three Months Ended January 31, |  | Six Months Ended January 31, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
|  |  |  | (As Adjusted)(1) |  |  |  | (As Adjusted)(1) |
| Revenue: |  |  |  |  |  |  |  |
| Product | $ | 271.6 |  |  | $ | 204.8 |  |  | $ | 512.1 |  |  | $ | 389.6 |  |
| Subscription and support | 439.6 |  |  | 340.8 |  |  | 855.1 |  |  | 657.8 |  |
| Total revenue | 711.2 |  |  | 545.6 |  |  | 1,367.2 |  |  | 1,047.4 |  |
| Cost of revenue: |  |  |  |  |  |  |  |
| Product | 82.5 |  |  | 63.9 |  |  | 155.7 |  |  | 121.5 |  |
| Subscription and support | 120.1 |  |  | 95.5 |  |  | 230.4 |  |  | 179.2 |  |
| Total cost of revenue | 202.6 |  |  | 159.4 |  |  | 386.1 |  |  | 300.7 |  |
| Total gross profit | 508.6 |  |  | 386.2 |  |  | 981.1 |  |  | 746.7 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 128.3 |  |  | 96.6 |  |  | 241.7 |  |  | 190.8 |  |
| Sales and marketing | 320.0 |  |  | 258.8 |  |  | 634.6 |  |  | 512.9 |  |
| General and administrative | 53.7 |  |  | 53.3 |  |  | 130.3 |  |  | 119.0 |  |
| Total operating expenses | 502.0 |  |  | 408.7 |  |  | 1,006.6 |  |  | 822.7 |  |
| Operating income (loss) | 6.6 |  |  | (22.5 | ) |  | (25.5 | ) |  | (76.0 | ) |
| Interest expense | (20.6 | ) |  | (6.4 | ) |  | (43.3 | ) |  | (12.7 | ) |
| Other income, net | 16.0 |  |  | 4.9 |  |  | 29.0 |  |  | 9.7 |  |
| Income (loss) before income taxes | 2.0 |  |  | (24.0 | ) |  | (39.8 | ) |  | (79.0 | ) |
| Provision for income taxes | 4.6 |  |  | 1.6 |  |  | 1.1 |  |  | 9.8 |  |
| Net loss | $ | (2.6 | ) |  | $ | (25.6 | ) |  | $ | (40.9 | ) |  | $ | (88.8 | ) |
| Net loss per share, basic and diluted | $ | (0.03 | ) |  | $ | (0.28 | ) |  | $ | (0.44 | ) |  | $ | (0.98 | ) |
| Weighted-average shares used to compute net loss per share, basic and diluted | 94.0 |  |  | 91.1 |  |  | 93.9 |  |  | 91.0 |  |

[0001327567-19-000006:8k_2_02:51]
______________

[0001327567-19-000006:8k_2_02:52]
| (1) | Certain amounts have been adjusted due to the company’s adoption of the new revenue recognition standard (ASC 606) as of August 1, 2018 using the full retrospective method. |

[0001327567-19-000006:8k_2_02:53]
9

[0001327567-19-000006:8k_2_02:54]
| Palo Alto Networks, Inc. |
| Reconciliation of GAAP to Non-GAAP Financial Measures |
| (In millions, except per share amounts) |
| (Unaudited) |
|  | Three Months Ended |  | Six Months Ended |
|  | January 31, |  | January 31, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
|  |  |  | (As Adjusted)(1) |  |  |  | (As Adjusted)(1) |
| GAAP net loss | $ | (2.6 | ) |  | $ | (25.6 | ) |  | $ | (40.9 | ) |  | $ | (88.8 | ) |
| Share-based compensation-related charges | 149.5 |  |  | 136.3 |  |  | 290.2 |  |  | 265.2 |  |
| Acquisition-related costs(2) | 1.6 |  |  | — |  |  | 17.1 |  |  | — |  |
| Amortization expense of acquired intangible assets | 14.1 |  |  | 2.5 |  |  | 23.4 |  |  | 5.0 |  |
| Litigation-related charges(3) | 3.0 |  |  | 3.0 |  |  | 6.1 |  |  | 6.1 |  |
| Facility exit costs(4) | — |  |  | 1.4 |  |  | — |  |  | 17.0 |  |
| Non-cash charges related to convertible notes(5) | 17.5 |  |  | 6.4 |  |  | 39.1 |  |  | 12.7 |  |
| Foreign currency loss associated with non-GAAP adjustments | 0.6 |  |  | 1.0 |  |  | 0.1 |  |  | 1.5 |  |
| Income tax and other tax adjustments related to the above(6) | (36.7 | ) |  | (26.3 | ) |  | (72.7 | ) |  | (49.7 | ) |
| Non-GAAP net income | $ | 147.0 |  |  | $ | 98.7 |  |  | $ | 262.4 |  |  | $ | 169.0 |  |
| GAAP net loss per share, diluted | $ | (0.03 | ) |  | $ | (0.28 | ) |  | $ | (0.44 | ) |  | $ | (0.98 | ) |
| Share-based compensation-related charges | 1.53 |  |  | 1.46 |  |  | 2.97 |  |  | 2.86 |  |
| Acquisition-related costs(2) | 0.02 |  |  | 0.00 |  |  | 0.18 |  |  | 0.00 |  |
| Amortization expense of acquired intangible assets | 0.15 |  |  | 0.03 |  |  | 0.25 |  |  | 0.05 |  |
| Litigation-related charges(3) | 0.03 |  |  | 0.03 |  |  | 0.06 |  |  | 0.07 |  |
| Facility exit costs(4) | 0.00 |  |  | 0.02 |  |  | 0.00 |  |  | 0.19 |  |
| Non-cash charges related to convertible notes(5) | 0.19 |  |  | 0.07 |  |  | 0.42 |  |  | 0.14 |  |
| Foreign currency loss associated with non-GAAP adjustments | 0.01 |  |  | 0.01 |  |  | 0.00 |  |  | 0.02 |  |
| Income tax and other tax adjustments related to the above(6) | (0.39 | ) |  | (0.29 | ) |  | (0.77 | ) |  | (0.55 | ) |
| Non-GAAP net income per share, diluted | $ | 1.51 |  |  | $ | 1.05 |  |  | $ | 2.67 |  |  | $ | 1.80 |  |
| GAAP weighted-average shares used to compute net loss per share, diluted | 94.0 |  |  | 91.1 |  |  | 93.9 |  |  | 91.0 |  |
| Weighted-average effect of potentially dilutive securities(7) | 3.6 |  |  | 2.8 |  |  | 4.4 |  |  | 2.8 |  |
| Non-GAAP weighted-average shares used to compute net income per share, diluted | 97.6 |  |  | 93.9 |  |  | 98.3 |  |  | 93.8 |  |

[0001327567-19-000006:8k_2_02:55]
___________

[0001327567-19-000006:8k_2_02:56]
| (1) | Certain amounts have been adjusted due to the company’s adoption of the new revenue recognition standard (ASC 606) as of August 1, 2018 using the full retrospective method. |

[0001327567-19-000006:8k_2_02:57]
| (2) | Consists of acquisition transaction costs, share-based compensation related to the cash settlement of certain equity awards, and costs to terminate certain employment and operating lease contracts of the acquired company. |

[0001327567-19-000006:8k_2_02:58]
| (3) | Consists of the amortization of intellectual property licenses. |

[0001327567-19-000006:8k_2_02:59]
| (4) | Consists of charges related to the relocation of the company’s corporate headquarters during the three months ended October 31, 2017, including a cease-use loss of $15.4 million and accelerated depreciation, and charges related to the relocation of the company’s research and development center in Israel during the three months ended January 31, 2018, including a cease-use loss of $1.3 million and accelerated depreciation. |

[0001327567-19-000006:8k_2_02:60]
| (5) | Consists primarily of non-cash interest expense related to the company’s convertible senior notes. Also includes non-cash losses of $0.4 million and $2.6 million during the three and six months ended January 31, 2019, respectively, related to early conversions of the convertible notes during those periods. |

[0001327567-19-000006:8k_2_02:61]
| (6) | The company changed its non-GAAP effective tax rate from 31% to 22% in its second quarter of fiscal 2018 due to the reduction of the U.S. federal corporate income tax rate under the U.S. Tax Cuts and Jobs Act, which was enacted into law on December 22, 2017. |

[0001327567-19-000006:8k_2_02:62]
| (7) | Non-GAAP net income per share, diluted, includes the potentially dilutive effect of employee equity incentive plan awards and convertible senior notes outstanding and related warrants. In addition, non-GAAP net income per share, diluted, includes the anti-dilutive impact of the company’s note hedge agreements, which reduced the potentially dilutive effect of the convertible notes by 0.6 million shares and 0.8 million shares for the three and six months ended January 31, 2019, respectively, and 1.4 million shares and 1.4 million shares for the three and six months ended January 31, 2018, respectively. |

[0001327567-19-000006:8k_2_02:63]
10

[0001327567-19-000006:8k_2_02:64]
| Palo Alto Networks, Inc. |
| Calculation of Billings |
| (In millions) |
| (Unaudited) |
|  | Three Months Ended |  | Six Months Ended |
|  | January 31, |  | January 31, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
|  |  |  | (As Adjusted)(1) |  |  |  | (As Adjusted)(1) |
| Total revenue | $ | 711.2 |  |  | $ | 545.6 |  |  | $ | 1,367.2 |  |  | $ | 1,047.4 |  |
| Add: change in total deferred revenue, net of acquired deferred revenue | 141.3 |  |  | 127.6 |  |  | 243.8 |  |  | 221.2 |  |
| Billings | $ | 852.5 |  |  | $ | 673.2 |  |  | $ | 1,611.0 |  |  | $ | 1,268.6 |  |

[0001327567-19-000006:8k_2_02:65]
___________

[0001327567-19-000006:8k_2_02:66]
| (1) | These amounts have been adjusted due to the company’s adoption of the new revenue recognition standard (ASC 606) as of August 1, 2018 using the full retrospective method. |

[0001327567-19-000006:8k_2_02:67]
11

[0001327567-19-000006:8k_2_02:68]
| Palo Alto Networks, Inc. |
| Preliminary Condensed Consolidated Balance Sheets |
| (In millions) |
| (Unaudited) |
|  | January 31, 2019 |  | July 31, 2018 |
|  |  |  | (As Adjusted)(1) |
| Assets |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 1,127.8 |  |  | $ | 2,506.9 |  |
| Short-term investments | 1,702.2 |  |  | 896.5 |  |
| Accounts receivable, net | 415.0 |  |  | 467.0 |  |
| Prepaid expenses and other current assets | 242.5 |  |  | 268.1 |  |
| Total current assets | 3,487.5 |  |  | 4,138.5 |  |
| Property and equipment, net | 273.2 |  |  | 273.1 |  |
| Long-term investments | 808.6 |  |  | 547.5 |  |
| Goodwill | 636.4 |  |  | 522.8 |  |
| Intangible assets, net | 171.8 |  |  | 140.8 |  |
| Other assets | 330.0 |  |  | 326.2 |  |
| Total assets | $ | 5,707.5 |  |  | $ | 5,948.9 |  |
| Liabilities, temporary equity, and stockholders’ equity |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 27.9 |  |  | $ | 49.4 |  |
| Accrued compensation | 143.4 |  |  | 163.7 |  |
| Accrued and other liabilities | 171.4 |  |  | 124.6 |  |
| Deferred revenue | 1,369.2 |  |  | 1,213.6 |  |
| Convertible senior notes, net | 156.3 |  |  | 550.4 |  |
| Total current liabilities | 1,868.2 |  |  | 2,101.7 |  |
| Convertible senior notes, net | 1,399.5 |  |  | 1,369.7 |  |
| Long-term deferred revenue | 1,156.5 |  |  | 1,065.7 |  |
| Other long-term liabilities | 208.7 |  |  | 229.6 |  |
| Temporary equity | 2.8 |  |  | 21.9 |  |
| Stockholders’ equity: |  |  |  |
| Preferred stock | — |  |  | — |  |
| Common stock and additional paid-in capital | 1,941.5 |  |  | 1,967.4 |  |
| Accumulated other comprehensive loss | (9.8 | ) |  | (16.4 | ) |
| Accumulated deficit | (859.9 | ) |  | (790.7 | ) |
| Total stockholders’ equity | 1,071.8 |  |  | 1,160.3 |  |
| Total liabilities, temporary equity, and stockholders’ equity | $ | 5,707.5 |  |  | $ | 5,948.9 |  |

[0001327567-19-000006:8k_2_02:69]
______________

[0001327567-19-000006:8k_2_02:70]
| (1) | Certain amounts have been adjusted due to the company’s adoption of the new revenue recognition standard (ASC 606) as of August 1, 2018 using the full retrospective method. |

[0001327567-19-000006:8k_2_02:71]
12
