# PANW MD&A — 0001327567-19-000008


## mdna

[0001327567-19-000008:mdna:1]
[same as prior period, unchanged from 0001327567-18-000031:mdna:1]

[0001327567-19-000008:mdna:2]
[same as prior period, unchanged from 0001327567-18-000031:mdna:2]

[0001327567-19-000008:mdna:3]
[same as prior period, unchanged from 0001327567-18-000031:mdna:3]

[0001327567-19-000008:mdna:4]
[same as prior period, unchanged from 0001327567-18-000031:mdna:4]

[0001327567-19-000008:mdna:5]
| • | Results of Operations. A discussion of the nature and trends in our financial results and an analysis of our financial results comparing the three and six months ended January 31, 2019 to the three and six months ended January 31, 2018. |

[0001327567-19-000008:mdna:6]
[same as prior period, unchanged from 0001327567-18-000031:mdna:6]

[0001327567-19-000008:mdna:7]
| • | Contractual Obligations and Commitments. An overview of our contractual obligations, contingent liabilities, commitments, and off-balance sheet arrangements outstanding as of January 31, 2019, including expected payment schedules. |

[0001327567-19-000008:mdna:8]
[same as prior period, unchanged from 0001327567-18-000031:mdna:8]

[0001327567-19-000008:mdna:9]
[same as prior period, unchanged from 0001327567-18-000031:mdna:10]

[0001327567-19-000008:mdna:10]
[same as prior period, unchanged from 0001327567-18-000031:mdna:11]

[0001327567-19-000008:mdna:11]
We have pioneered the next generation of security through our innovative Security Operating Platform that empowers enterprises, service providers, and government entities to secure their organizations by safely enabling applications and data running in their networks, on their endpoints, and in the cloud, and by preventing breaches that stem from targeted cyberattacks. Our platform uses an innovative traffic classification engine that identifies network traffic by application, user, and content and provides consistent security across the network, endpoint, and cloud. Accordingly, our platform enables our end-customers to pursue transformative digital initiatives, like public cloud and mobility, that grow their business, while maintaining the visibility and control needed to protect their

[0001327567-19-000008:mdna:12]
[same as prior period, unchanged from 0001327567-18-000031:mdna:52]

[0001327567-19-000008:mdna:13]
valued data and critical control systems. We believe the architecture of our platform offers superior performance compared to legacy approaches and reduces the total cost of ownership for organizations by simplifying their security operations and infrastructure and eliminating the need for multiple, stand-alone hardware and software security products, and consists of four primary security capabilities.

[0001327567-19-000008:mdna:14]
[same as prior period, unchanged from 0001327567-18-000031:mdna:13]

[0001327567-19-000008:mdna:15]
[same as prior period, unchanged from 0001327567-18-000031:mdna:14]

[0001327567-19-000008:mdna:16]
[same as prior period, unchanged from 0001327567-18-000031:mdna:15]

[0001327567-19-000008:mdna:17]
[same as prior period, unchanged from 0001327567-18-000031:mdna:16]

[0001327567-19-000008:mdna:18]
For the second quarter of fiscal 2019 and 2018, total revenue was $711.2 million and $545.6 million, respectively, representing year-over-year growth of 30.4%. Our growth reflects the increased adoption of our hybrid SaaS revenue model, which consists of product, subscriptions, and support. We believe this model will enable us to benefit from recurring revenues as we continue to grow our installed end-customer base. As of January 31, 2019, we had end-customers in over 150 countries. Our end-customers represent a broad range of industries, including education, energy, financial services, government entities, healthcare, Internet and media, manufacturing, public sector, and telecommunications, and include some of the largest Fortune 100 and Global 2000 companies in the world. We maintain a field sales force that works closely with our channel partners in developing sales opportunities. We use a two-tiered, indirect fulfillment model whereby we sell our products, subscriptions, and support to our distributors, which, in turn, sell to our resellers, which then sell to our end-customers.

[0001327567-19-000008:mdna:19]
Our product revenue was $271.6 million, or 38.2% of total revenue, for the second quarter of fiscal 2019, representing year-over-year growth of 32.6%. Product revenue is generated from sales of our appliances, primarily our Next-Generation Firewall, which is available in physical and virtualized form. Our Next-Generation Firewall incorporates our proprietary PAN-OS operating system, which provides a consistent set of capabilities across our entire product line. Our products are designed for different performance requirements throughout an organization, ranging from our PA-220, which is designed for small organizations and remote or branch offices, to our top-of-the-line PA-7080, which is especially suited for very large enterprise deployments and service provider customers. The same firewall functionality that is delivered in our physical appliances is also available in our VM-Series virtual firewalls, which secure virtualized and cloud-based computing environments.

[0001327567-19-000008:mdna:20]
Our subscription and support revenue was $439.6 million, or 61.8% of total revenue, for the second quarter of fiscal 2019, representing year-over-year growth of 29.0%. Our subscriptions provide our end-customers with real-time access to the latest antivirus, intrusion prevention, web filtering, and modern malware prevention capabilities across the network, endpoints, and the cloud. When end-customers purchase our physical or virtual firewall appliances, they typically purchase support in order to receive ongoing security updates, upgrades, bug fixes, and repairs. In addition to the subscriptions purchased with these appliances, end-customers may also purchase other subscriptions on a per-user, per-endpoint, or capacity-based basis.

[0001327567-19-000008:mdna:21]
We continue to invest in innovation as we evolve and further extend the capabilities of our platform, as we believe that innovation and timely development of new features and products is essential to meeting the needs of our end-customers and improving our competitive position. For example, in October 2018, we acquired RedLock Inc. (“RedLock”), which expanded our security capabilities for the public cloud with the addition of RedLock’s cloud security analytics technology. In addition, in February 2019, we introduced PAN-OS 9.0, with over 60 new features, and our new DNS Security Service subscription, which uses machine learning to proactively block malicious domains and stop attacks in progress.

[0001327567-19-000008:mdna:22]
We believe that the growth of our business and our short-term and long-term success are dependent upon many factors, including our ability to extend our technology leadership, grow our base of end-customers, expand deployment of our platform and support offerings within existing end-customers, and focus on end-customer satisfaction. To manage any future growth effectively, we must continue to improve and expand our information technology and financial infrastructure, our operating and administrative systems and controls, and our ability to manage headcount, capital, and processes in an efficient manner. While these areas present significant opportunities for us, they also pose challenges and risks that we must successfully address in order to sustain the growth of our business and improve our operating results. For additional information regarding the challenges and risks we face, see the “Risk Factors” section in Part II, Item 1A of this Quarterly Report on Form 10-Q.

[0001327567-19-000008:mdna:23]
[same as prior period, unchanged from 0001327567-18-000031:mdna:67]

[0001327567-19-000008:mdna:24]
[same as prior period, unchanged from 0001327567-18-000031:mdna:24]

[0001327567-19-000008:mdna:25]
[same as prior period, unchanged from 0001327567-18-000031:mdna:25]

[0001327567-19-000008:mdna:26]
|  | January 31, 2019 |  | July 31, 2018 |
|  | (in millions) |
| Total deferred revenue(1) | $ | 2,525.7 |  |  | $ | 2,279.3 |  |
| Cash, cash equivalents, and investments | $ | 3,638.6 |  |  | $ | 3,950.9 |  |

[0001327567-19-000008:mdna:27]
[same as prior period, unchanged from 0001327567-18-000031:mdna:27]

[0001327567-19-000008:mdna:28]
[same as prior period, unchanged from 0001327567-18-000031:mdna:28]

[0001327567-19-000008:mdna:29]
|  | Three Months Ended January 31, |  | Six Months Ended January 31, |
|  | 2019 |  | 2018(1) |  | 2019 |  | 2018(1) |
|  | (dollars in millions) |
| Total revenue | $ | 711.2 |  |  | $ | 545.6 |  |  | $ | 1,367.2 |  |  | $ | 1,047.4 |  |
| Total revenue year-over-year percentage increase | 30.4 | % |  | 29.8 | % |  | 30.5 | % |  | 28.0 | % |
| Gross margin | 71.5 | % |  | 70.8 | % |  | 71.8 | % |  | 71.3 | % |
| Operating income (loss) | $ | 6.6 |  |  | $ | (22.5 | ) |  | $ | (25.5 | ) |  | $ | (76.0 | ) |
| Operating margin | 0.9 | % |  | (4.1 | )% |  | (1.9 | )% |  | (7.3 | )% |
| Billings | $ | 852.5 |  |  | $ | 673.2 |  |  | $ | 1,611.0 |  |  | $ | 1,268.6 |  |
| Billings year-over-year percentage increase | 26.6 | % |  | 20.8 | % |  | 27.0 | % |  | 22.6 | % |
| Cash flow provided by operating activities |  |  |  |  | $ | 527.7 |  |  | $ | 518.6 |  |
| Free cash flow (non-GAAP) |  |  |  |  | $ | 469.9 |  |  | $ | 460.8 |  |

[0001327567-19-000008:mdna:30]
[same as prior period, unchanged from 0001327567-18-000031:mdna:30]

[0001327567-19-000008:mdna:31]
[same as prior period, unchanged from 0001327567-18-000031:mdna:31]

[0001327567-19-000008:mdna:32]
[same as prior period, unchanged from 0001327567-18-000031:mdna:32]

[0001327567-19-000008:mdna:33]
| • | Billings. We define billings as total revenue plus the change in total deferred revenue, net of acquired deferred revenue, during the period. We consider billings to be a key metric used by management to manage our business given our hybrid SaaS revenue model, and believe billings provides investors with an important indicator of the health and visibility of our business because it includes subscription and support revenue, which is recognized ratably over the contractual service period, and product revenue, which is recognized at the time of shipment, provided that all other conditions for revenue recognition have been met. We consider billings to be a useful metric for management and investors, particularly if we continue to experience increased sales of subscriptions and strong renewal rates for subscription and support offerings, and as we monitor our near-term cash flows. While we believe that billings provides useful information to investors and others in understanding and evaluating our operating results in the same manner as our management, it is important to note that other companies, including companies in our industry, may not use billings, may calculate billings differently, may have different billing frequencies, or may use other financial measures to evaluate their performance, all of which could reduce the usefulness of billings as a comparative measure. We calculate billings in the following manner: |

[0001327567-19-000008:mdna:34]
[same as prior period, unchanged from 0001327567-18-000031:mdna:79]

[0001327567-19-000008:mdna:35]
|  | Three Months Ended January 31, |  | Six Months Ended January 31, |
|  | 2019 |  | 2018(1) |  | 2019 |  | 2018(1) |
|  | (in millions) |
| Billings: |  |  |  |  |  |  |  |
| Total revenue | $ | 711.2 |  |  | $ | 545.6 |  |  | $ | 1,367.2 |  |  | $ | 1,047.4 |  |
| Add: change in total deferred revenue, net of acquired deferred revenue | 141.3 |  |  | 127.6 |  |  | 243.8 |  |  | 221.2 |  |
| Billings | $ | 852.5 |  |  | $ | 673.2 |  |  | $ | 1,611.0 |  |  | $ | 1,268.6 |  |

[0001327567-19-000008:mdna:36]
[same as prior period, unchanged from 0001327567-18-000031:mdna:37]

[0001327567-19-000008:mdna:37]
[same as prior period, unchanged from 0001327567-18-000031:mdna:38]

[0001327567-19-000008:mdna:38]
[same as prior period, unchanged from 0001327567-18-000031:mdna:39]

[0001327567-19-000008:mdna:39]
[same as prior period, unchanged from 0001327567-18-000031:mdna:40]

[0001327567-19-000008:mdna:40]
|  | Six Months Ended January 31, |
|  | 2019 |  | 2018 |
|  | (in millions) |
| Free cash flow (non-GAAP): |  |  |  |
| Net cash provided by operating activities(1) | $ | 527.7 |  |  | $ | 518.6 |  |
| Less: purchases of property, equipment, and other assets | 57.8 |  |  | 57.8 |  |
| Free cash flow (non-GAAP)(1) | $ | 469.9 |  |  | $ | 460.8 |  |
| Net cash used in investing activities | $ | (1,236.9 | ) |  | $ | (88.5 | ) |
| Net cash used in financing activities | $ | (669.6 | ) |  | $ | (258.6 | ) |

[0001327567-19-000008:mdna:41]
[same as prior period, unchanged from 0001327567-18-000031:mdna:42]

[0001327567-19-000008:mdna:42]
[same as prior period, unchanged from 0001327567-18-000031:mdna:43]

[0001327567-19-000008:mdna:43]
[same as prior period, unchanged from 0001327567-18-000031:mdna:93]

[0001327567-19-000008:mdna:44]
[same as prior period, unchanged from 0001327567-18-000031:mdna:45]

[0001327567-19-000008:mdna:45]
[same as prior period, unchanged from 0001327567-18-000031:mdna:46]

[0001327567-19-000008:mdna:46]
|  | Three Months Ended January 31, |  | Six Months Ended January 31, |
|  | 2019 |  | 2018(1) |  | 2019 |  | 2018(1) |
|  | Amount |  | % of Revenue |  | Amount |  | % of Revenue |  | Amount |  | % of Revenue |  | Amount |  | % of Revenue |
|  | (dollars in millions) |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 271.6 |  |  | 38.2 | % |  | $ | 204.8 |  |  | 37.5 | % |  | $ | 512.1 |  |  | 37.5 | % |  | $ | 389.6 |  |  | 37.2 | % |
| Subscription and support | 439.6 |  |  | 61.8 | % |  | 340.8 |  |  | 62.5 | % |  | 855.1 |  |  | 62.5 | % |  | 657.8 |  |  | 62.8 | % |
| Total revenue | 711.2 |  |  | 100.0 | % |  | 545.6 |  |  | 100.0 | % |  | 1,367.2 |  |  | 100.0 | % |  | 1,047.4 |  |  | 100.0 | % |
| Cost of revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product | 82.5 |  |  | 11.6 | % |  | 63.9 |  |  | 11.7 | % |  | 155.7 |  |  | 11.4 | % |  | 121.5 |  |  | 11.6 | % |
| Subscription and support | 120.1 |  |  | 16.9 | % |  | 95.5 |  |  | 17.5 | % |  | 230.4 |  |  | 16.8 | % |  | 179.2 |  |  | 17.1 | % |
| Total cost of revenue(2) | 202.6 |  |  | 28.5 | % |  | 159.4 |  |  | 29.2 | % |  | 386.1 |  |  | 28.2 | % |  | 300.7 |  |  | 28.7 | % |
| Total gross profit | 508.6 |  |  | 71.5 | % |  | 386.2 |  |  | 70.8 | % |  | 981.1 |  |  | 71.8 | % |  | 746.7 |  |  | 71.3 | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | 128.3 |  |  | 18.0 | % |  | 96.6 |  |  | 17.7 | % |  | 241.7 |  |  | 17.7 | % |  | 190.8 |  |  | 18.2 | % |
| Sales and marketing | 320.0 |  |  | 45.0 | % |  | 258.8 |  |  | 47.4 | % |  | 634.6 |  |  | 46.5 | % |  | 512.9 |  |  | 49.0 | % |
| General and administrative | 53.7 |  |  | 7.6 | % |  | 53.3 |  |  | 9.8 | % |  | 130.3 |  |  | 9.5 | % |  | 119.0 |  |  | 11.4 | % |
| Total operating expenses(2) | 502.0 |  |  | 70.6 | % |  | 408.7 |  |  | 74.9 | % |  | 1,006.6 |  |  | 73.7 | % |  | 822.7 |  |  | 78.6 | % |
| Operating income (loss) | 6.6 |  |  | 0.9 | % |  | (22.5 | ) |  | (4.1 | )% |  | (25.5 | ) |  | (1.9 | )% |  | (76.0 | ) |  | (7.3 | )% |
| Interest expense | (20.6 | ) |  | (2.9 | )% |  | (6.4 | ) |  | (1.2 | )% |  | (43.3 | ) |  | (3.2 | )% |  | (12.7 | ) |  | (1.2 | )% |
| Other income, net | 16.0 |  |  | 2.3 | % |  | 4.9 |  |  | 0.9 | % |  | 29.0 |  |  | 2.2 | % |  | 9.7 |  |  | 1.0 | % |
| Income (loss) before income taxes | 2.0 |  |  | 0.3 | % |  | (24.0 | ) |  | (4.4 | )% |  | (39.8 | ) |  | (2.9 | )% |  | (79.0 | ) |  | (7.5 | )% |
| Provision for income taxes | 4.6 |  |  | 0.7 | % |  | 1.6 |  |  | 0.3 | % |  | 1.1 |  |  | 0.1 | % |  | 9.8 |  |  | 1.0 | % |
| Net loss | $ | (2.6 | ) |  | (0.4 | )% |  | $ | (25.6 | ) |  | (4.7 | )% |  | $ | (40.9 | ) |  | (3.0 | )% |  | $ | (88.8 | ) |  | (8.5 | )% |

[0001327567-19-000008:mdna:47]
[same as prior period, unchanged from 0001327567-18-000031:mdna:48]

[0001327567-19-000008:mdna:48]
[same as prior period, unchanged from 0001327567-18-000031:mdna:49]

[0001327567-19-000008:mdna:49]
[same as prior period, unchanged from 0001327567-18-000031:mdna:50]

[0001327567-19-000008:mdna:50]
|  | Three Months Ended January 31, |  | Six Months Ended January 31, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
|  | (in millions) |
| Cost of product revenue | $ | 1.4 |  |  | $ | 1.9 |  |  | $ | 3.0 |  |  | $ | 3.8 |  |
| Cost of subscription and support revenue | 18.2 |  |  | 19.9 |  |  | 35.7 |  |  | 35.8 |  |
| Research and development | 44.0 |  |  | 35.5 |  |  | 84.5 |  |  | 73.0 |  |
| Sales and marketing | 58.7 |  |  | 53.3 |  |  | 114.7 |  |  | 104.5 |  |
| General and administrative | 20.1 |  |  | 20.2 |  |  | 55.6 |  |  | 39.4 |  |
| Total share-based compensation | $ | 142.4 |  |  | $ | 130.8 |  |  | $ | 293.5 |  |  | $ | 256.5 |  |

[0001327567-19-000008:mdna:51]
[same as prior period, unchanged from 0001327567-18-000031:mdna:106]

[0001327567-19-000008:mdna:52]
[same as prior period, unchanged from 0001327567-18-000031:mdna:53]

[0001327567-19-000008:mdna:53]
[same as prior period, unchanged from 0001327567-18-000031:mdna:54]

[0001327567-19-000008:mdna:54]
[same as prior period, unchanged from 0001327567-18-000031:mdna:55]

[0001327567-19-000008:mdna:55]
[same as prior period, unchanged from 0001327567-18-000031:mdna:56]

[0001327567-19-000008:mdna:56]
|  | Three Months Ended January 31, |  |  |  |  |  | Six Months Ended January 31, |  |  |  |  |
|  | 2019 |  | 2018(1) |  | Change |  | 2019 |  | 2018(1) |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Product | $ | 271.6 |  |  | $ | 204.8 |  |  | $ | 66.8 |  |  | 32.6 | % |  | $ | 512.1 |  |  | $ | 389.6 |  |  | $ | 122.5 |  |  | 31.4 | % |

[0001327567-19-000008:mdna:57]
[same as prior period, unchanged from 0001327567-18-000031:mdna:58]

[0001327567-19-000008:mdna:58]
[same as prior period, unchanged from 0001327567-18-000031:mdna:59]

[0001327567-19-000008:mdna:59]
Product revenue increased for the three and six months ended January 31, 2019 compared to the three and six months ended January 31, 2018. The increase in both periods was primarily due to increased demand for our appliances. The change in product revenue due to pricing was not significant for either period.

[0001327567-19-000008:mdna:60]
[same as prior period, unchanged from 0001327567-18-000031:mdna:61]

[0001327567-19-000008:mdna:61]
[same as prior period, unchanged from 0001327567-18-000031:mdna:62]

[0001327567-19-000008:mdna:62]
|  | Three Months Ended January 31, |  |  |  |  |  | Six Months Ended January 31, |  |  |  |  |
|  | 2019 |  | 2018(1) |  | Change |  | 2019 |  | 2018(1) |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Subscription | $ | 249.7 |  |  | $ | 183.3 |  |  | $ | 66.4 |  |  | 36.2 | % |  | $ | 481.0 |  |  | $ | 352.3 |  |  | $ | 128.7 |  |  | 36.5 | % |
| Support | 189.9 |  |  | 157.5 |  |  | 32.4 |  |  | 20.6 | % |  | 374.1 |  |  | 305.5 |  |  | 68.6 |  |  | 22.5 | % |
| Total subscription and support | $ | 439.6 |  |  | $ | 340.8 |  |  | $ | 98.8 |  |  | 29.0 | % |  | $ | 855.1 |  |  | $ | 657.8 |  |  | $ | 197.3 |  |  | 30.0 | % |

[0001327567-19-000008:mdna:63]
[same as prior period, unchanged from 0001327567-18-000031:mdna:64]

[0001327567-19-000008:mdna:64]
[same as prior period, unchanged from 0001327567-18-000031:mdna:65]

[0001327567-19-000008:mdna:65]
Subscription and support revenue increased for the three and six months ended January 31, 2019 compared to the three and six months ended January 31, 2018. The increase in both periods was due to increased demand for our subscription and support offerings from both new and existing end-customers. The mix between subscription revenue and support revenue will fluctuate over time, depending on the introduction of new subscription offerings, renewals of support services, and our ability to increase sales to new and existing customers. The change in subscription and support revenue due to changes in pricing was not significant for either period.

[0001327567-19-000008:mdna:66]
[same as prior period, unchanged from 0001327567-18-000031:mdna:119]

[0001327567-19-000008:mdna:67]
[same as prior period, unchanged from 0001327567-18-000031:mdna:68]

[0001327567-19-000008:mdna:68]
|  | Three Months Ended January 31, |  |  |  |  |  | Six Months Ended January 31, |  |  |  |  |
|  | 2019 |  | 2018(1) |  | Change |  | 2019 |  | 2018(1) |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Americas | $ | 475.0 |  |  | $ | 373.3 |  |  | $ | 101.7 |  |  | 27.2 | % |  | $ | 925.2 |  |  | $ | 722.6 |  |  | $ | 202.6 |  |  | 28.0 | % |
| EMEA | 148.3 |  |  | 107.2 |  |  | 41.1 |  |  | 38.3 | % |  | 276.0 |  |  | 201.9 |  |  | 74.1 |  |  | 36.7 | % |
| APAC | 87.9 |  |  | 65.1 |  |  | 22.8 |  |  | 35.0 | % |  | 166.0 |  |  | 122.9 |  |  | 43.1 |  |  | 35.1 | % |
| Total revenue | $ | 711.2 |  |  | $ | 545.6 |  |  | $ | 165.6 |  |  | 30.4 | % |  | $ | 1,367.2 |  |  | $ | 1,047.4 |  |  | $ | 319.8 |  |  | 30.5 | % |

[0001327567-19-000008:mdna:69]
[same as prior period, unchanged from 0001327567-18-000031:mdna:70]

[0001327567-19-000008:mdna:70]
[same as prior period, unchanged from 0001327567-18-000031:mdna:71]

[0001327567-19-000008:mdna:71]
With respect to geographic theaters, the Americas contributed the largest portion of the increase in revenue for the three and six months ended January 31, 2019 compared to the three and six months ended January 31, 2018, due to its larger and more established sales force compared to our other theaters. Revenue from both Europe, the Middle East, and Africa (“EMEA”) and Asia Pacific and Japan (“APAC”) increased for the three and six months ended January 31, 2019 compared to the three and six months ended January 31, 2018, due to our investment in increasing the size of our sales force and number of channel partners in these theaters.

[0001327567-19-000008:mdna:72]
[same as prior period, unchanged from 0001327567-18-000031:mdna:73]

[0001327567-19-000008:mdna:73]
[same as prior period, unchanged from 0001327567-18-000031:mdna:74]

[0001327567-19-000008:mdna:74]
[same as prior period, unchanged from 0001327567-18-000031:mdna:75]

[0001327567-19-000008:mdna:75]
[same as prior period, unchanged from 0001327567-18-000031:mdna:76]

[0001327567-19-000008:mdna:76]
|  | Three Months Ended January 31, |  |  |  | Six Months Ended January 31, |  |  |  |  |
|  | 2019 |  | 2018 |  | Change |  | 2019 |  | 2018 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Cost of product revenue | $ | 82.5 |  |  | $ | 63.9 |  |  | $ | 18.6 |  |  | 29.1 | % |  | $ | 155.7 |  |  | $ | 121.5 |  |  | $ | 34.2 |  |  | 28.1 | % |
| Number of employees at period end | 98 |  |  | 91 |  |  | 7 |  |  | 7.7 | % |  | 98 |  |  | 91 |  |  | 7 |  |  | 7.7 | % |

[0001327567-19-000008:mdna:77]
Cost of product revenue increased for the three and six months ended January 31, 2019 compared to the three and six months ended January 31, 2018. The increase in both periods was primarily due to an increase in product unit volume.

[0001327567-19-000008:mdna:78]
[same as prior period, unchanged from 0001327567-18-000031:mdna:133]

[0001327567-19-000008:mdna:79]
[same as prior period, unchanged from 0001327567-18-000031:mdna:80]

[0001327567-19-000008:mdna:80]
[same as prior period, unchanged from 0001327567-18-000031:mdna:81]

[0001327567-19-000008:mdna:81]
|  | Three Months Ended January 31, |  |  |  | Six Months Ended January 31, |  |  |  |  |
|  | 2019 |  | 2018 |  | Change |  | 2019 |  | 2018 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Cost of subscription and support revenue(1) | $ | 120.1 |  |  | $ | 95.5 |  |  | $ | 24.6 |  |  | 25.8 | % |  | $ | 230.4 |  |  | $ | 179.2 |  |  | $ | 51.2 |  |  | 28.6 | % |
| Number of employees at period end | 1,030 |  |  | 813 |  |  | 217 |  |  | 26.7 | % |  | 1,030 |  |  | 813 |  |  | 217 |  |  | 26.7 | % |

[0001327567-19-000008:mdna:82]
[same as prior period, unchanged from 0001327567-18-000031:mdna:83]

[0001327567-19-000008:mdna:83]
| (1) | The amounts for fiscal 2018 have been adjusted due to our adoption of the new revenue recognition standard. Refer to Note 1. Description of Business and Summary of Significant Accounting Policies in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information. |

[0001327567-19-000008:mdna:84]
Cost of subscription and support revenue increased for the three and six months ended January 31, 2019 compared to the three and six months ended January 31, 2018. The increase in both periods was primarily due to increased costs to support the growth of our subscription and support business. Personnel costs grew $8.7 million to $63.0 million for the three months ended January 31, 2019 compared to the three months ended January 31, 2018, and grew $20.2 million to $121.6 million for the six months ended January 31, 2019 compared to the six months ended January 31, 2018, primarily due to headcount growth. Amortization of purchased intangible assets increased $6.7 million for the three months ended January 31, 2019 compared to the three months ended January 31, 2018, and increased $11.4 million for the six months ended January 31, 2019 compared to the six months ended January 31, 2018, as a result of our recent acquisitions. The remaining increase in both periods was primarily due to an increase in data center and cloud hosting costs to support the adoption of our cloud-based subscription offerings and costs to expand our customer service capabilities.

[0001327567-19-000008:mdna:85]
[same as prior period, unchanged from 0001327567-18-000031:mdna:86]

[0001327567-19-000008:mdna:86]
[same as prior period, unchanged from 0001327567-18-000031:mdna:87]

[0001327567-19-000008:mdna:87]
|  | Three Months Ended January 31, |  | Six Months Ended January 31, |
|  | 2019 |  | 2018(1) |  | 2019 |  | 2018(1) |
|  | Amount |  | Gross Margin |  | Amount |  | Gross Margin |  | Amount |  | Gross Margin |  | Amount |  | Gross Margin |
|  | (dollars in millions) |
| Product | $ | 189.1 |  |  | 69.6 | % |  | $ | 140.9 |  |  | 68.8 | % |  | $ | 356.4 |  |  | 69.6 | % |  | $ | 268.1 |  |  | 68.8 | % |
| Subscription and support | 319.5 |  |  | 72.7 | % |  | 245.3 |  |  | 72.0 | % |  | 624.7 |  |  | 73.1 | % |  | 478.6 |  |  | 72.8 | % |
| Total gross profit | $ | 508.6 |  |  | 71.5 | % |  | $ | 386.2 |  |  | 70.8 | % |  | $ | 981.1 |  |  | 71.8 | % |  | $ | 746.7 |  |  | 71.3 | % |

[0001327567-19-000008:mdna:88]
[same as prior period, unchanged from 0001327567-18-000031:mdna:89]

[0001327567-19-000008:mdna:89]
[same as prior period, unchanged from 0001327567-18-000031:mdna:90]

[0001327567-19-000008:mdna:90]
Product gross margin increased for the three and six months ended January 31, 2019 compared to the three and six months ended January 31, 2018, primarily due to increased leverage of our operations organization and improved operations in our supply chain management, partially offset by higher product costs related to our newly introduced appliances, which have lower product margins.

[0001327567-19-000008:mdna:91]
[same as prior period, unchanged from 0001327567-18-000031:mdna:146]

[0001327567-19-000008:mdna:92]
Subscription and support gross margin increased for the three and six months ended January 31, 2019 compared to the three and six months ended January 31, 2018 primarily due to increased leverage of our global customer support organization and a decrease in product support and repair costs, partially offset by higher costs to support the adoption of our cloud-based subscription offerings.

[0001327567-19-000008:mdna:93]
[same as prior period, unchanged from 0001327567-18-000031:mdna:94]

[0001327567-19-000008:mdna:94]
Our operating expenses consist of research and development, sales and marketing, and general and administrative expense. Personnel costs are the most significant component of operating expenses and consist of salaries, benefits, bonuses, share-based compensation, travel and entertainment, and with regard to sales and marketing expense, sales commissions. Our operating expenses also include allocated costs, which consist of certain facilities, depreciation, benefits, recruiting, and information technology costs that we allocate based on headcount. We expect operating expenses to increase in absolute dollars and decrease over the long term as a percentage of revenue as we continue to scale our business. As of January 31, 2019, we expect to recognize approximately $1.4 billion of share-based compensation expense over a weighted-average period of approximately 2.8 years, excluding additional share-based compensation expense related to any future grants of share-based awards. Share-based compensation expense is generally recognized on a straight-line basis over the requisite service periods of the awards.

[0001327567-19-000008:mdna:95]
[same as prior period, unchanged from 0001327567-18-000031:mdna:96]

[0001327567-19-000008:mdna:96]
[same as prior period, unchanged from 0001327567-18-000031:mdna:97]

[0001327567-19-000008:mdna:97]
|  | Three Months Ended January 31, |  |  |  |  |  | Six Months Ended January 31, |  |  |  |  |
|  | 2019 |  | 2018 |  | Change |  | 2019 |  | 2018 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Research and development | $ | 128.3 |  |  | $ | 96.6 |  |  | $ | 31.7 |  |  | 32.8 | % |  | $ | 241.7 |  |  | $ | 190.8 |  |  | $ | 50.9 |  |  | 26.7 | % |
| Number of employees at period end | 1,098 |  |  | 814 |  |  | 284 |  |  | 34.9 | % |  | 1,098 |  |  | 814 |  |  | 284 |  |  | 34.9 | % |

[0001327567-19-000008:mdna:98]
Research and development expense increased for the three and six months ended January 31, 2019 compared to the three and six months ended January 31, 2018. The increase in both periods was primarily due to an increase in personnel costs, which grew $22.7 million to $103.5 million for the three months ended January 31, 2019 compared to the three months ended January 31, 2018, and grew $38.4 million to $196.8 million for the six months ended January 31, 2019 compared to the six months ended January 31, 2018. The increase in personnel costs in both periods was largely due to headcount growth. The remaining increase in both periods was primarily driven by an increase in allocated costs.

[0001327567-19-000008:mdna:99]
[same as prior period, unchanged from 0001327567-18-000031:mdna:100]

[0001327567-19-000008:mdna:100]
[same as prior period, unchanged from 0001327567-18-000031:mdna:101]

[0001327567-19-000008:mdna:101]
[same as prior period, unchanged from 0001327567-18-000031:mdna:166]

[0001327567-19-000008:mdna:102]
|  | Three Months Ended January 31, |  |  |  |  |  | Six Months Ended January 31, |  |  |  |  |
|  | 2019 |  | 2018 |  | Change |  | 2019 |  | 2018 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Sales and marketing(1) | $ | 320.0 |  |  | $ | 258.8 |  |  | $ | 61.2 |  |  | 23.6 | % |  | $ | 634.6 |  |  | $ | 512.9 |  |  | $ | 121.7 |  |  | 23.7 | % |
| Number of employees at period end | 2,919 |  |  | 2,511 |  |  | 408 |  |  | 16.2 | % |  | 2,919 |  |  | 2,511 |  |  | 408 |  |  | 16.2 | % |

[0001327567-19-000008:mdna:103]
[same as prior period, unchanged from 0001327567-18-000031:mdna:103]

[0001327567-19-000008:mdna:104]
| (1) | The amounts for fiscal 2018 have been adjusted due to our adoption of the new revenue recognition standard. Refer to Note 1. Description of Business and Summary of Significant Accounting Policies in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information. |

[0001327567-19-000008:mdna:105]
Sales and marketing expense increased for the three and six months ended January 31, 2019 compared to the three and six months ended January 31, 2018. The increase in both periods was primarily due to an increase in personnel costs, which grew $39.4 million to $244.0 million for the three months ended January 31, 2019 compared to the three months ended January 31, 2018, and grew $74.2 million to $471.3 million for the six months ended January 31, 2019 compared to the six months ended January 31, 2018. The increase in personnel costs in both periods was largely due to headcount growth. The remaining increase in both periods was primarily driven by an increase in allocated costs and an increase in costs associated with marketing-related activities.

[0001327567-19-000008:mdna:106]
[same as prior period, unchanged from 0001327567-18-000031:mdna:107]

[0001327567-19-000008:mdna:107]
[same as prior period, unchanged from 0001327567-18-000031:mdna:108]

[0001327567-19-000008:mdna:108]
|  | Three Months Ended January 31, |  |  |  |  |  | Six Months Ended January 31, |  |  |  |  |
|  | 2019 |  | 2018 |  | Change |  | 2019 |  | 2018 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| General and administrative | $ | 53.7 |  |  | $ | 53.3 |  |  | $ | 0.4 |  |  | 0.8 | % |  | $ | 130.3 |  |  | $ | 119.0 |  |  | $ | 11.3 |  |  | 9.5 | % |
| Number of employees at period end | 711 |  |  | 604 |  |  | 107 |  |  | 17.7 | % |  | 711 |  |  | 604 |  |  | 107 |  |  | 17.7 | % |

[0001327567-19-000008:mdna:109]
General and administrative expense was relatively flat for the three months ended January 31, 2019 compared to the three months ended January 31, 2018. General and administrative expense increased for the six months ended January 31, 2019 compared to the six months ended January 31, 2018. The increase was driven by an increase in personnel costs, which grew $16.2 million to $89.8 million for the six months ended January 31, 2019 compared to the six months ended January 31, 2018, primarily due to expense related to the accelerated vesting of certain equity awards in connection with the RedLock acquisition of $14.2 million recognized during the three months ended October 31, 2018. This increase was partially offset by a decrease due to the cease-use loss of $15.4 million recognized on the lease of our previous headquarter facilities during the three months ended October 31, 2017. The remaining increase was primarily due to an increase in legal expenses during the three months ended October 31, 2018.

[0001327567-19-000008:mdna:110]
- 37 -

[0001327567-19-000008:mdna:111]
[same as prior period, unchanged from 0001327567-18-000031:mdna:111]

[0001327567-19-000008:mdna:112]
Interest expense primarily consists of non-cash interest expense from the amortization of the debt discount and debt issuance costs related to our 0.0% Convertible Senior Notes due 2019 (the “2019 Notes”) and 0.75% Convertible Senior Notes due 2023 (the “2023 Notes” and, together with the 2019 Notes, the “Notes”), and also includes the contractual interest expense related to our 2023 Notes.

[0001327567-19-000008:mdna:113]
|  | Three Months Ended January 31, |  |  |  | Six Months Ended January 31, |  |  |
|  | 2019 |  | 2018 |  | Change |  | 2019 |  | 2018 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Interest expense | $ | 20.6 |  |  | $ | 6.4 |  |  | $ | 14.2 |  |  | 221.9 | % |  | $ | 43.3 |  |  | $ | 12.7 |  |  | $ | 30.6 |  |  | 240.9 | % |

[0001327567-19-000008:mdna:114]
Interest expense increased for the three and six months ended January 31, 2019 compared to the three and six months ended January 31, 2018. The increase in both periods was primarily due to interest expense recognized on the 2023 Notes issued in July 2018, partially offset by a reduction in interest expense recognized on the 2019 Notes due early conversions. We expect interest expense to increase in fiscal 2019 due to interest expense to be incurred on the 2023 Notes. Refer to Note 9. Debt in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information on the Notes.

[0001327567-19-000008:mdna:115]
[same as prior period, unchanged from 0001327567-18-000031:mdna:115]

[0001327567-19-000008:mdna:116]
[same as prior period, unchanged from 0001327567-18-000031:mdna:116]

[0001327567-19-000008:mdna:117]
|  | Three Months Ended January 31, |  |  |  | Six Months Ended January 31, |  |  |
|  | 2019 |  | 2018 |  | Change |  | 2019 |  | 2018 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Other income, net | $ | 16.0 |  |  | $ | 4.9 |  |  | $ | 11.1 |  |  | 226.5 | % |  | $ | 29.0 |  |  | $ | 9.7 |  |  | $ | 19.3 |  |  | 199.0 | % |

[0001327567-19-000008:mdna:118]
Other income, net increased for the three and six months ended January 31, 2019 compared to the three and six months ended January 31, 2018. The increase in both periods was primarily driven by an increase in interest income, which grew $12.1 million for the three months ended January 31, 2019 compared to the three months ended January 31, 2018, and grew $22.4 million for the six months ended January 31, 2019 compared to the six months ended January 31, 2018. The increase in interest income was largely due to higher cash, cash equivalents, and investments balances and higher yields on these balances during the three and six months ended January 31, 2019 compared to the three and six months ended January 31, 2018. The increase in interest income for the three and six months ended January 31, 2019 was partially offset by losses of $0.4 million and $2.6 million, respectively, recognized related to the settlement of the 2019 Notes. Refer to Note 9. Debt in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information on the Notes.

[0001327567-19-000008:mdna:119]
- 38 -

[0001327567-19-000008:mdna:120]
Provision for Income Taxes

[0001327567-19-000008:mdna:121]
Provision for income taxes consists primarily of income taxes in foreign jurisdictions in which we conduct business, withholding taxes, and U.S. state income taxes. We maintain a full valuation allowance for domestic and certain foreign deferred tax assets, including net operating loss carryforwards and certain domestic tax credits. In recent years, we reorganized our corporate structure and intercompany relationships to more closely align with the international nature of our business activities. Our corporate structure has caused, and may continue to cause, disproportionate relationships between our overall effective tax rate and other jurisdictional measures. To the extent we revisit our corporate structure, it may have an impact on our tax provision.

[0001327567-19-000008:mdna:122]
|  | Three Months Ended January 31, |  | Change |  | Six Months Ended January 31, |  | Change |
|  | 2019 |  | 2018 |  | Amount |  | % |  | 2019 |  | 2018 |  | Amount |  | % |
|  | (dollars in millions) |
| Provision for income taxes | $ | 4.6 |  |  | $ | 1.6 |  |  | $ | 3.0 |  |  | 187.5 | % |  | $ | 1.1 |  |  | $ | 9.8 |  |  | $ | (8.7 | ) |  | (88.8 | )% |
| Effective tax rate | 230.0 | % |  | (6.7 | )% |  |  |  |  |  |  | (2.8 | )% |  | (12.4 | )% |  |  |  |  |  |

[0001327567-19-000008:mdna:123]
We recorded an income tax provision for the three and six months ended January 31, 2019. Key components of our provision for income taxes, excluding one-time items, include foreign income taxes and withholding taxes. Our provision for income taxes increased for the three months ended January 31, 2019 compared to the three months ended January 31, 2018, primarily due to a one-time tax benefit of $6.2 million recognized during the three months ended January 31, 2018 related to the Tax Cuts and Jobs Act (“TCJA”), which was enacted into law in December 2017. Our provision for income taxes decreased for the six months ended January 31, 2019 compared to the six months ended January 31, 2018, primarily due to a one-time tax benefit of $9.4 million recognized during the three months ended October 31, 2018 related to a partial release of our valuation allowance related to the acquisition of RedLock. Excluding the aforementioned one-time items, our provision for income taxes decreased for the three and six months ended January 31, 2019 compared to the three and six months ended January 31, 2018, due to guidance for intra-entity asset transfers, other than inventory, adopted in the first quarter of fiscal 2019. Refer to Note 13. Income Taxes in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information.

[0001327567-19-000008:mdna:124]
[same as prior period, unchanged from 0001327567-18-000031:mdna:126]

[0001327567-19-000008:mdna:125]
|  | January 31, 2019 |  | July 31, 2018 |
|  | (in millions) |
| Working capital(1)(2) | $ | 1,619.3 |  |  | $ | 2,036.8 |  |
| Cash, cash equivalents, and investments: |  |  |  |
| Cash and cash equivalents | $ | 1,127.8 |  |  | $ | 2,506.9 |  |
| Investments | 2,510.8 |  |  | 1,444.0 |  |
| Total cash, cash equivalents, and investments | $ | 3,638.6 |  |  | $ | 3,950.9 |  |

[0001327567-19-000008:mdna:126]
[same as prior period, unchanged from 0001327567-18-000031:mdna:128]

[0001327567-19-000008:mdna:127]
[same as prior period, unchanged from 0001327567-18-000031:mdna:84]

[0001327567-19-000008:mdna:128]
| (2) | The net carrying amount of the 0.0% Convertible Senior Notes due 2019 (the “2019 Notes”) was classified in current liabilities in our condensed consolidated balance sheets as of January 31, 2019 and July 31, 2018, respectively. Refer to Note 9. Debt in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information. |

[0001327567-19-000008:mdna:129]
As of January 31, 2019, our total cash, cash equivalents, and investments of $3.6 billion were held for general corporate purposes, of which approximately $253.8 million was held outside of the United States. As of January 31, 2019, we had no unremitted earnings when evaluating our outside basis difference relating to our U.S. investment in foreign subsidiaries. However, there could be local withholding taxes payable due to various foreign countries if certain lower tier earnings are distributed. Withholding taxes that would be payable upon remittance of these lower tier earnings were not material as of January 31, 2019.

[0001327567-19-000008:mdna:130]
In June 2014, we issued the 2019 Notes with an aggregate principal amount of $575.0 million and in July 2018, we issued the 2023 Notes with an aggregate principal amount of $1.7 billion. As of January 31, 2019, $159.4 million of the 2019 Notes remained outstanding and all of the 2023 Notes remained outstanding. The 2019 Notes and the 2023 Notes mature on July 1, 2019 and July 1, 2023, respectively; however, under certain circumstances, holders may surrender their Notes of a series for conversion prior to the applicable maturity dates. Upon conversion of the Notes of a series, we will pay cash equal to the aggregate principal amount of the

[0001327567-19-000008:mdna:131]
- 39 -

[0001327567-19-000008:mdna:132]
Notes of such series to be converted, and, at our election, will pay or deliver cash and/or shares of our common stock for the amount of our conversion obligation in excess of the aggregate principal amount of the Notes of such series being converted. During the three and six months ended January 31, 2019, holders converted $88.3 million and $415.6 million, respectively, in aggregate principal amount of the 2019 Notes, which we repaid in cash. We also issued 0.3 million and 1.7 million shares of common stock to the holders during the three and six months ended January 31, 2019, respectively, for the conversion value in excess of the principal amount of the 2019 Notes converted, which were fully offset by shares received from our exercise of the associated note hedges. Refer to Note 9. Debt in Part I, Item 1 of this Quarterly Report on Form 10-Q for information on the Notes.

[0001327567-19-000008:mdna:133]
In September 2018, we entered into a credit agreement (the “Credit Agreement”) that provides for a $400.0 million unsecured revolving credit facility (the “Credit Facility”), with an option to increase the amount of the credit facility up to an additional $350.0 million, subject to certain conditions. As of January 31, 2019, there were no amounts outstanding, and we were in compliance with all covenants under the Credit Agreement. Refer to Note 9. Debt in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information on the Credit Agreement.

[0001327567-19-000008:mdna:134]
In August 2016, our board of directors authorized a $500.0 million share repurchase program and, in February 2017, authorized a $500.0 million increase to the repurchase program, bringing the total authorization to $1.0 billion. Repurchases were to be funded from available working capital and could be made at management’s discretion from time to time. The repurchase program expired on December 31, 2018. On February 22, 2019, our board of directors authorized a new $1.0 billion share repurchase program which will be funded from available working capital and will expire on December 31, 2020. Refer to Note 11. Stockholders’ Equity and Note 16. Subsequent Events in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information on the repurchase program and the new repurchase authorization, respectively.

[0001327567-19-000008:mdna:135]
The following table summarizes our cash flows for the six months ended January 31, 2019 and 2018:

[0001327567-19-000008:mdna:136]
|  | Six Months Ended January 31, |
| 2019 |  | 2018 |
|  | (in millions) |
| Net cash provided by operating activities(1) | $ | 527.7 |  |  | $ | 518.6 |  |
| Net cash used in investing activities | (1,236.9 | ) |  | (88.5 | ) |
| Net cash used in financing activities | (669.6 | ) |  | (258.6 | ) |
| Net increase (decrease) in cash, cash equivalents, and restricted cash(1) | $ | (1,378.8 | ) |  | $ | 171.5 |  |

[0001327567-19-000008:mdna:137]
[same as prior period, unchanged from 0001327567-18-000031:mdna:139]

[0001327567-19-000008:mdna:138]
[same as prior period, unchanged from 0001327567-18-000031:mdna:140]

[0001327567-19-000008:mdna:139]
[same as prior period, unchanged from 0001327567-18-000031:mdna:141]

[0001327567-19-000008:mdna:140]
[same as prior period, unchanged from 0001327567-18-000031:mdna:142]

[0001327567-19-000008:mdna:141]
[same as prior period, unchanged from 0001327567-18-000031:mdna:143]

[0001327567-19-000008:mdna:142]
[same as prior period, unchanged from 0001327567-18-000031:mdna:144]

[0001327567-19-000008:mdna:143]
Cash provided by operating activities during the six months ended January 31, 2019 was $527.7 million, an increase of $9.1 million compared to the six months ended January 31, 2018. The increase was due to growth of our business, as reflected by an increase in billings, and an increase in collections during the six months ended January 31, 2019. This was partially offset by a decrease due to repayments of the 2019 Notes attributable to the debt discount of $67.1 million during the six months ended January 31, 2019, and the receipt of an upfront cash reimbursement of $38.2 million related to certain of our lease agreements during the six months ended January 31, 2018.

[0001327567-19-000008:mdna:144]
- 40 -

[0001327567-19-000008:mdna:145]
[same as prior period, unchanged from 0001327567-18-000031:mdna:148]

[0001327567-19-000008:mdna:146]
[same as prior period, unchanged from 0001327567-18-000031:mdna:149]

[0001327567-19-000008:mdna:147]
Cash used in investing activities during the six months ended January 31, 2019 was $1.2 billion, an increase of $1.1 billion compared to the six months ended January 31, 2018, due to higher net purchases of investments and cash paid for our acquisition of RedLock during the six months ended January 31, 2019.

[0001327567-19-000008:mdna:148]
[same as prior period, unchanged from 0001327567-18-000031:mdna:151]

[0001327567-19-000008:mdna:149]
Our financing activities have consisted of net proceeds from the issuance of the Notes and related transactions, repayments of the 2019 Notes, proceeds from sales of shares through employee equity incentive plans, cash used to repurchase shares of our common stock, and payments for tax withholding obligations of certain employees related to the net share settlement of equity awards.

[0001327567-19-000008:mdna:150]
Cash used in financing activities during the six months ended January 31, 2019 was $669.6 million, an increase of $411.0 million compared to the six months ended January 31, 2018, primarily due to repayments of our 2019 Notes and an increase in repurchases of our common stock during the six months ended January 31, 2019.

[0001327567-19-000008:mdna:151]
[same as prior period, unchanged from 0001327567-18-000031:mdna:154]

[0001327567-19-000008:mdna:152]
The following summarizes our contractual obligations and commitments as of January 31, 2019:

[0001327567-19-000008:mdna:153]
|  | Payments Due by Period |
|  | Total |  | Less Than 1 Year |  | 1-3 Years |  | 3-5 Years |  | More Than 5 Years |
|  |  |  | (in millions) |  |  |
| 0.0% Convertible Senior Notes due 2019(1) | $ | 159.4 |  |  | $ | 159.4 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| 0.75% Convertible Senior Notes due 2023 | 1,693.0 |  |  | — |  |  | — |  |  | 1,693.0 |  |  | — |  |
| Operating lease obligations(2) | 509.0 |  |  | 68.4 |  |  | 128.2 |  |  | 110.8 |  |  | 201.6 |  |
| Purchase obligations(3) | 444.8 |  |  | 136.8 |  |  | 38.0 |  |  | 105.0 |  |  | 165.0 |  |
| Total(4) | $ | 2,806.2 |  |  | $ | 364.6 |  |  | $ | 166.2 |  |  | $ | 1,908.8 |  |  | $ | 366.6 |  |

[0001327567-19-000008:mdna:154]
[same as prior period, unchanged from 0001327567-18-000031:mdna:157]

[0001327567-19-000008:mdna:155]
| (1) | The 2019 Notes mature on July 1, 2019. Refer to Note 9. Debt in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information. |

[0001327567-19-000008:mdna:156]
| (2) | Consists of contractual obligations from our non-cancelable operating leases. Excludes contractual sublease proceeds of $12.3 million, which consists of $5.4 million to be received in less than one year and $6.9 million to be received in one to three years. Refer to Note 10. Commitments and Contingencies in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information on our operating leases. |

[0001327567-19-000008:mdna:157]
| (3) | Consists of minimum purchase commitments of products and components with our manufacturing partners and component suppliers, as well as minimum purchase commitments for our use of certain cloud services with third-party providers. Obligations under contracts that we can cancel without a significant penalty are not included in the table above. |

[0001327567-19-000008:mdna:158]
| (4) | No amounts related to income taxes are included. As of January 31, 2019, we had approximately $69.9 million of tax liabilities recorded related to uncertainty in income tax positions. |

[0001327567-19-000008:mdna:159]
[same as prior period, unchanged from 0001327567-18-000031:mdna:162]

[0001327567-19-000008:mdna:160]
As of January 31, 2019, we did not have any relationships with unconsolidated organizations or financial partnerships, such as structured finance or special purpose entities that would have been established for the purpose of facilitating off-balance sheet arrangements or other contractually narrow or limited purposes.

[0001327567-19-000008:mdna:161]
[same as prior period, unchanged from 0001327567-18-000031:mdna:164]

[0001327567-19-000008:mdna:162]
Our condensed consolidated financial statements have been prepared in accordance with U.S. GAAP. The preparation of these condensed consolidated financial statements requires us to make estimates and assumptions that affect the reported amounts of assets, liabilities, revenue, expenses, and related disclosures. We base our estimates on historical experience and on various other assumptions that we believe are reasonable under the circumstances. We evaluate our estimates and assumptions on an ongoing basis. Actual results

[0001327567-19-000008:mdna:163]
- 41 -

[0001327567-19-000008:mdna:164]
may differ from these estimates. To the extent that there are material differences between these estimates and our actual results, our future financial statements will be affected.

[0001327567-19-000008:mdna:165]
We believe the critical accounting estimates discussed under Item 7, “Management’s Discussion and Analysis of Financial Condition and Results of Operations” in our Annual Report on Form 10-K for the fiscal year ended July 31, 2018, reflect our more significant judgments and estimates used in the preparation of our condensed consolidated financial statements. There have been no significant changes to our critical accounting estimates as filed in such report, except for revenue recognition and deferred contract costs, due to our adoption of new accounting guidance, as described below. Refer to “Recently Adopted Accounting Pronouncements” in Note 1. Description of Business and Summary of Significant Accounting Policies in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information on our adoption of the new accounting guidance.

[0001327567-19-000008:mdna:166]
[same as prior period, unchanged from 0001327567-18-000031:mdna:169]

[0001327567-19-000008:mdna:167]
[same as prior period, unchanged from 0001327567-18-000031:mdna:170]

[0001327567-19-000008:mdna:168]
[same as prior period, unchanged from 0001327567-18-000031:mdna:171]

[0001327567-19-000008:mdna:169]
[same as prior period, unchanged from 0001327567-18-000031:mdna:172]

[0001327567-19-000008:mdna:170]
[same as prior period, unchanged from 0001327567-18-000031:mdna:173]

[0001327567-19-000008:mdna:171]
[same as prior period, unchanged from 0001327567-18-000031:mdna:174]

[0001327567-19-000008:mdna:172]
Refer to “Recently Issued Accounting Pronouncements” in Note 1. Description of Business and Summary of Significant Accounting Policies in Part I, Item 1 of this Quarterly Report on Form 10-Q.
