# PANW note change history — 0001327567-18-000031 → 0001327567-19-000008


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2019-02-27):
[0001327567-19-000008:note_history:1]
In September 2012, we entered into two lease agreements for a total of approximately 300,000 square feet of space in Santa Clara, California, which served as our previous corporate headquarters through August 2017, when we relocated to our new corporate campus. The leases contain rent holiday periods and two separate five-year options to extend the lease term beyond their expiration dates of July 2023. Rental payments under these lease agreements are approximately $94.3 million over the lease term. In August 2017, we exited our previous headquarter facilities and relocated to our new corporate campus, which resulted in the recognition of a cease-use loss of $39.2 million as general and administrative expense in our consolidated statements of operations during the year ended July 31, 2018, and a corresponding liability in our consolidated balance sheets. During the three and six months ended January 31, 2019, we released $2.5 million and $5.0 million, respectively, of the cease-use liability through rental payments. As of January 31, 2019, the remaining balance of the cease-use liability was $24.1 million, which is expected to be paid through the end of the lease term in July 2023.
  (was, 2018-11-30, similarity 0.7587):
[0001327567-18-000031:note_history:1]
In September 2012, we entered into two lease agreements for a total of approximately 300,000 square feet of space in Santa Clara, California, which served as our previous corporate headquarters through August 2017, when we relocated to our new corporate campus. The leases contain rent holiday periods and two separate five-year options to extend the lease term beyond their expiration dates of July 2023. Rental payments under these lease agreements are approximately $94.3 million over the lease term. In August 2017, we exited our previous headquarter facilities and relocated to our new corporate campus, which resulted in the recognition of a cease-use loss of $39.2 million as general and administrative expense in our consolidated statements of operations during the year ended July 31, 2018, and a corresponding liability in our consolidated balance sheets. During the three months ended October 31, 2018, we released $2.5 million of the cease-use liability through rental payments. As of October 31, 2018, the remaining balance of the cease-use liability was $26.6 million, which is expected to be paid through the end of the lease term in July 2023.

- changed (2019-02-27):
[0001327567-19-000008:note_history:2]
The following table presents details of the aggregate future non-cancelable minimum rental payments under our operating leases as of January 31, 2019 (in millions):
  (was, 2018-11-30, similarity 0.9623):
[0001327567-18-000031:note_history:2]
The following table presents details of the aggregate future non-cancelable minimum rental payments under our operating leases as of October 31, 2018 (in millions):

- added (2019-02-27):
[0001327567-19-000008:note_history:3]
|  | Amount |
| Fiscal years ending July 31: |  |
| Remaining 2019 | $ | 33.6 |  |
| 2020 | 69.0 |  |
| 2021 | 64.1 |  |
| 2022 | 59.9 |  |

- changed (2019-02-27):
[0001327567-19-000008:note_history:4]
| 2023 | 58.6 |  |
| 2024 and thereafter | 223.8 |  |
| Committed gross lease payments | 509.0 |  |
| Less: proceeds from sublease rentals | 12.3 |  |
| Net operating lease obligation | $ | 496.7 |  |
  (was, 2018-11-30, similarity 0.7583):
[0001327567-18-000031:note_history:4]
|  | Amount |
| Fiscal years ending July 31: |  |
| Remaining 2019 | $ | 50.4 |  |
| 2020 | 68.9 |  |
| 2021 | 64.1 |  |
| 2022 | 59.8 |  |
| 2023 | 58.5 |  |
| 2024 and thereafter | 224.1 |  |
| Committed gross lease payments | 525.8 |  |
| Less: proceeds from sublease rentals | 12.8 |  |
| Net operating lease obligation | $ | 513.0 |  |

- changed (2019-02-27):
[0001327567-19-000008:note_history:5]
Our electronics manufacturing service provider (“EMS provider”) procures components and assembles our products based on our forecasts. These forecasts are based on estimates of demand for our products primarily for the next 12 months, which are in turn based on historical trends and an analysis from our sales and product management organizations, adjusted for overall market conditions. In order to reduce manufacturing lead times and plan for adequate supply, we may issue non-cancelable orders for products and components to our manufacturing partners or component suppliers. As of January 31, 2019, our purchase commitments under such orders were $136.8 million, excluding obligations under contracts that we can cancel without a significant penalty.
  (was, 2018-11-30, similarity 0.9906):
[0001327567-18-000031:note_history:5]
Our electronics manufacturing service provider (“EMS provider”) procures components and assembles our products based on our forecasts. These forecasts are based on estimates of demand for our products primarily for the next 12 months, which are in turn based on historical trends and an analysis from our sales and product management organizations, adjusted for overall market conditions. In order to reduce manufacturing lead times and plan for adequate supply, we may issue non-cancelable orders for products and components to our manufacturing partners or component suppliers. As of October 31, 2018, our purchase commitments under such orders were $155.6 million, excluding obligations under contracts that we can cancel without a significant penalty.

- added (2019-02-27):
[0001327567-19-000008:note_history:6]
We have entered into various non-cancelable agreements with third-party providers for our use of certain cloud services, under which we are committed to minimum purchases through the year ending July 31, 2026. The following table presents details of the aggregate future non-cancelable purchase commitments under these agreements as of January 31, 2019 (in millions):

- added (2019-02-27):
[0001327567-19-000008:note_history:7]
|  | Amount |
| Fiscal years ending July 31: |  |
| Remaining 2019 | $ | — |  |
| 2020 | 8.0 |  |
| 2021 | 30.0 |  |
| 2022 | 47.5 |  |
| 2023 | 57.5 |  |
| 2024 and thereafter | 165.0 |  |
| Total other purchase commitments | $ | 308.0 |  |

- changed (2019-02-27):
[0001327567-19-000008:note_history:8]
To the extent there is a reasonable possibility that a loss exceeding amounts already recognized may be incurred and the amount of such additional loss would be material, we will either disclose the estimated additional loss or state that such an estimate cannot be made. As of January 31, 2019, we have not recorded any significant accruals for loss contingencies associated with such legal proceedings, determined that an unfavorable outcome is probable or reasonably possible, or determined that the amount or range of any possible loss is reasonably estimable.
  (was, 2018-11-30, similarity 0.9875):
[0001327567-18-000031:note_history:8]
To the extent there is a reasonable possibility that a loss exceeding amounts already recognized may be incurred and the amount of such additional loss would be material, we will either disclose the estimated additional loss or state that such an estimate cannot be made. As of October 31, 2018, we have not recorded any significant accruals for loss contingencies associated with such legal proceedings, determined that an unfavorable outcome is probable or reasonably possible, or determined that the amount or range of any possible loss is reasonably estimable.

- removed (2019-02-27):
[0001327567-18-000031:note_history:9]
In March 2018, we amended an agreement with a third-party provider for our use of certain cloud services through June 2020. Under the non-cancelable addendum, we are committed to a minimum purchase of $14.0 million between April 2018 and March 2019 and $8.0 million between April 2019 and March 2020. As of October 31, 2018, our purchase commitment under the addendum was $8.0 million.


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2019-02-27):
[0001327567-19-000008:note_history:10]
There have been no material changes to our significant accounting policies as of and for the six months ended January 31, 2019, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended July 31, 2018, except for the change in our accounting policies for revenue recognition and deferred contract costs due to our adoption of new accounting guidance related to revenue from contracts with customers. Refer to “Recently Adopted Accounting Pronouncements” below, Note 2. Revenue, and Note 8. Deferred Contract Costs for more information.
  (was, 2018-11-30, similarity 0.9571):
[0001327567-18-000031:note_history:10]
There have been no material changes to our significant accounting policies as of and for the three months ended October 31, 2018, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended July 31, 2018, except for the change in our accounting policies for revenue recognition and deferred contract costs due to our adoption of new accounting guidance related to revenue from contracts with customers. Refer to “Recently Adopted Accounting Pronouncements” below, Note 2. Revenue, and Note 8. Deferred Contract Costs for more information.

- added (2019-02-27):
[0001327567-19-000008:note_history:11]
In August 2018, the Financial Accounting Standards Board (“FASB”) issued authoritative guidance on customers’ accounting for implementation costs incurred in a cloud computing arrangement that is a service contract, which requires customers to apply internal-use software guidance to determine the implementation costs that are able to be capitalized. Under the new standard, capitalized implementation costs are generally amortized over the term of the arrangement, beginning when the module or component of the hosting arrangement is ready for its intended use. We early adopted this standard in our second quarter of fiscal 2019 on a prospective basis. The adoption of the standard did not have a material impact on our condensed consolidated financial statements.

- changed (2019-02-27):
[0001327567-19-000008:note_history:12]
In January 2017, the FASB issued authoritative guidance clarifying the definition of a business to assist companies with evaluating whether transactions should be accounted for as acquisitions (or disposals) of assets or businesses. We adopted this standard in our first quarter of fiscal 2019 on a prospective basis. The adoption of the standard did not have an impact on our condensed consolidated financial statements.
  (was, 2018-11-30, similarity 0.9459):
[0001327567-18-000031:note_history:12]
In January 2017, the Financial Accounting Standards Board (“FASB”) issued authoritative guidance clarifying the definition of a business to assist companies with evaluating whether transactions should be accounted for as acquisitions (or disposals) of assets or businesses. We adopted this standard in our first quarter of fiscal 2019 on a prospective basis. The adoption of the standard did not have an impact on our condensed consolidated financial statements.

- changed (2019-02-27):
[0001327567-19-000008:note_history:13]
The adoption of the standard using the full retrospective method required us to restate the prior periods presented in this Quarterly Report on Form 10-Q, with the cumulative effect of the change of $168.2 million reflected in accumulated deficit as of July 31, 2017. In adopting the new standard, we have also applied a transition practical expedient and have not disclosed revenue expected to be recognized from remaining performance obligations for periods prior to August 1, 2018.
  (was, 2018-11-30, similarity 0.9893):
[0001327567-18-000031:note_history:13]
The adoption of the standard using the full retrospective method required us to restate the prior periods presented in this Quarterly Report on Form 10-Q, with the cumulative effect of the change of $168.2 million reflected in accumulated deficit as of August 1, 2017. In adopting the new standard, we have also applied a transition practical expedient and have not disclosed revenue expected to be recognized from remaining performance obligations for periods prior to August 1, 2018.

- added (2019-02-27):
[0001327567-19-000008:note_history:14]
|  | Three Months Ended January 31, 2018 |  | Six Months Ended January 31, 2018 |
|  | As Previously Reported |  | Impact of Adoption |  | As Adjusted |  | As Previously Reported |  | Impact of Adoption |  | As Adjusted |
| Condensed Consolidated Statements of Operations |  |  |  |  |  |  |  |  |  |  |  |
| Product revenue | $ | 202.2 |  |  | $ | 2.6 |  |  | $ | 204.8 |  |  | $ | 388.7 |  |  | $ | 0.9 |  |  | $ | 389.6 |  |
| Subscription and support revenue | 340.2 |  |  | 0.6 |  |  | 340.8 |  |  | 659.2 |  |  | (1.4 | ) |  | 657.8 |  |
| Total revenue | 542.4 |  |  | 3.2 |  |  | 545.6 |  |  | 1,047.9 |  |  | (0.5 | ) |  | 1,047.4 |  |
| Total cost of revenue | 159.3 |  |  | 0.1 |  |  | 159.4 |  |  | 300.7 |  |  | — |  |  | 300.7 |  |
| Total operating expenses | 414.9 |  |  | (6.2 | ) |  | 408.7 |  |  | 833.3 |  |  | (10.6 | ) |  | 822.7 |  |
| Operating loss | (31.8 | ) |  | 9.3 |  |  | (22.5 | ) |  | (86.1 | ) |  | 10.1 |  |  | (76.0 | ) |
| Net loss | (34.9 | ) |  | 9.3 |  |  | (25.6 | ) |  | (98.9 | ) |  | 10.1 |  |  | (88.8 | ) |
| Net loss per share, basic and diluted | $ | (0.38 | ) |  | $ | 0.10 |  |  | $ | (0.28 | ) |  | $ | (1.09 | ) |  | $ | 0.11 |  |  | $ | (0.98 | ) |

- changed (2019-02-27):
[0001327567-19-000008:note_history:15]
In February 2016, the FASB issued new authoritative guidance on lease accounting. Among its provisions, the standard requires lessees to recognize right-of-use assets and lease liabilities on the balance sheet for operating leases and also requires additional qualitative and quantitative disclosures about lease arrangements. The standard is effective for us in our first quarter of fiscal 2020 and will be applied on a modified retrospective basis, with the option to elect certain practical expedients. Early adoption is permitted; however, we plan to adopt the new standard in our first quarter of fiscal 2020. Upon adoption, we will recognize right-of-use assets and operating lease liabilities on our condensed consolidated balance sheets, which will increase our total assets and total liabilities. We expect our operating leases, as disclosed in Note 10. Commitments and Contingencies, will be subject to the new standard. We continue to evaluate the accounting, transition, and disclosure requirements of this standard, including its impact on our systems, accounting policies, and processes.
  (was, 2018-11-30, similarity 0.7846):
[0001327567-18-000031:note_history:15]
In February 2016, the FASB issued new authoritative guidance on lease accounting. Among its provisions, the standard requires lessees to recognize right-of-use assets and lease liabilities on the balance sheet for operating leases and also requires additional qualitative and quantitative disclosures about lease arrangements. The standard is effective for us in our first quarter of fiscal 2020 and will be applied on a modified retrospective basis, with the option to elect certain practical expedients. Early adoption is permitted; however, we plan to adopt the new standard in our first quarter of fiscal 2020. Upon adoption, we will recognize right-of-use assets and operating lease liabilities on our condensed consolidated balance sheets, which will increase our total assets and total liabilities. We are currently evaluating the accounting, transition, and disclosure requirements of this standard, including its impact on our accounting policies and processes.

- removed (2019-02-27):
[0001327567-18-000031:note_history:16]
|  | Three Months Ended October 31, 2017 |
|  | As Previously Reported |  | Impact of Adoption |  | As Adjusted |
| Condensed Consolidated Statements of Operations |  |  |  |  |  |
| Product revenue | $ | 186.5 |  |  | $ | (1.7 | ) |  | $ | 184.8 |  |
| Subscription and support revenue | 319.0 |  |  | (2.0 | ) |  | 317.0 |  |
| Total revenue | 505.5 |  |  | (3.7 | ) |  | 501.8 |  |
| Total cost of revenue | 141.4 |  |  | (0.1 | ) |  | 141.3 |  |
| Total operating expenses | 418.4 |  |  | (4.4 | ) |  | 414.0 |  |
| Operating loss | (54.3 | ) |  | 0.8 |  |  | (53.5 | ) |
| Net loss | (64.0 | ) |  | 0.8 |  |  | (63.2 | ) |
| Net loss per share, basic and diluted | $ | (0.70 | ) |  | $ | — |  |  | $ | (0.70 | ) |

- removed (2019-02-27):
[0001327567-18-000031:note_history:17]
In August 2018, the FASB issued new authoritative guidance on customer’s accounting for implementation costs incurred in a cloud computing arrangement that is a service contract, which will require customers to apply internal-use software guidance to determine the implementation costs that are able to be capitalized. Capitalized implementation costs will be required to be amortized over the term of the arrangement, beginning when the module or component of the hosting arrangement is ready for its intended use. The standard is effective for us in our first quarter of fiscal 2021 and will be applied on either a prospective or retrospective basis. Early adoption is permitted. We are currently evaluating adoption timing and whether this standard will have a material impact on our condensed consolidated financial statements.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2019-02-27):
[0001327567-19-000008:note_history:18]
There have been no material changes to our significant accounting policies as of and for the six months ended January 31, 2019, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended July 31, 2018, except for the change in our accounting policies for revenue recognition and deferred contract costs due to our adoption of new accounting guidance related to revenue from contracts with customers. Refer to “Recently Adopted Accounting Pronouncements” below, Note 2. Revenue, and Note 8. Deferred Contract Costs for more information.
  (was, 2018-11-30, similarity 0.9571):
[0001327567-18-000031:note_history:18]
There have been no material changes to our significant accounting policies as of and for the three months ended October 31, 2018, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended July 31, 2018, except for the change in our accounting policies for revenue recognition and deferred contract costs due to our adoption of new accounting guidance related to revenue from contracts with customers. Refer to “Recently Adopted Accounting Pronouncements” below, Note 2. Revenue, and Note 8. Deferred Contract Costs for more information.


## panw:DebtSecuritiesAvailableforsaleTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-02-27):
[0001327567-19-000008:note_history:19]
The following tables summarize the amortized cost, unrealized gains and losses, and fair value of our available-for-sale securities as of January 31, 2019 and July 31, 2018 (in millions):
  (was, 2018-11-30, similarity 0.9661):
[0001327567-18-000031:note_history:19]
The following tables summarize the amortized cost, unrealized gains and losses, and fair value of our available-for-sale securities as of October 31, 2018 and July 31, 2018 (in millions):

- changed (2019-02-27):
[0001327567-19-000008:note_history:20]
|  | January 31, 2019 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | $ | 39.4 |  |  | $ | — |  |  | $ | — |  |  | $ | 39.4 |  |
| U.S. government and agency securities | 279.4 |  |  | — |  |  | — |  |  | 279.4 |  |
| Total available-for-sale cash equivalents | $ | 318.8 |  |  | $ | — |  |  | $ | — |  |  | $ | 318.8 |  |
| Investments: |  |  |  |  |  |  |  |
| Commercial paper | $ | 50.2 |  |  | $ | — |  |  | $ | — |  |  | $ | 50.2 |  |
| Corporate debt securities | 495.9 |  |  | 0.9 |  |  | (1.4 | ) |  | 495.4 |  |
| U.S. government and agency securities | 1,968.0 |  |  | 1.1 |  |  | (3.9 | ) |  | 1,965.2 |  |
| Total available-for-sale investments | $ | 2,514.1 |  |  | $ | 2.0 |  |  | $ | (5.3 | ) |  | $ | 2,510.8 |  |
  (was, 2018-11-30, similarity 0.7841):
[0001327567-18-000031:note_history:20]
|  | October 31, 2018 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | $ | 5.0 |  |  | $ | — |  |  | $ | — |  |  | $ | 5.0 |  |
| Corporate debt securities | 2.5 |  |  | — |  |  | — |  |  | 2.5 |  |
| U.S. government and agency securities | 210.3 |  |  | — |  |  | — |  |  | 210.3 |  |
| Total available-for-sale cash equivalents | $ | 217.8 |  |  | $ | — |  |  | $ | — |  |  | $ | 217.8 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 5.4 |  |  | $ | — |  |  | $ | — |  |  | $ | 5.4 |  |
| Non-U.S. government securities | 20.0 |  |  | — |  |  | — |  |  | 20.0 |  |
| Commercial paper | 97.3 |  |  | — |  |  | — |  |  | 97.3 |  |
| Corporate debt securities | 382.5 |  |  | — |  |  | (2.4 | ) |  | 380.1 |  |
| U.S. government and agency securities | 1,489.0 |  |  | — |  |  | (6.9 | ) |  | 1,482.1 |  |
| Total available-for-sale investments | $ | 1,994.2 |  |  | $ | — |  |  | $ | (9.3 | ) |  | $ | 1,984.9 |  |


## us-gaap:ConvertibleDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-02-27):
[0001327567-19-000008:note_history:21]
The following table sets forth the components of the Notes as of January 31, 2019 and July 31, 2018 (in millions):
  (was, 2018-11-30, similarity 0.9423):
[0001327567-18-000031:note_history:21]
The following table sets forth the components of the Notes as of October 31, 2018 and July 31, 2018 (in millions):

- changed (2019-02-27):
[0001327567-19-000008:note_history:22]
|  | January 31, 2019 |  | July 31, 2018 |
|  | 2019 Notes |  | 2023 Notes |  | Total |  | 2019 Notes |  | 2023 Notes |  | Total |
| Liability component: |  |  |  |  |  |  |  |  |  |  |  |
| Principal | $ | 159.4 |  |  | $ | 1,693.0 |  |  | $ | 1,852.4 |  |  | $ | 575.0 |  |  | $ | 1,693.0 |  |  | $ | 2,268.0 |  |
| Less: debt discount and debt issuance costs, net of amortization | 3.1 |  |  | 293.5 |  |  | 296.6 |  |  | 24.6 |  |  | 323.3 |  |  | 347.9 |  |
| Net carrying amount | $ | 156.3 |  |  | $ | 1,399.5 |  |  | $ | 1,555.8 |  |  | $ | 550.4 |  |  | $ | 1,369.7 |  |  | $ | 1,920.1 |  |
| Equity component (including amounts classified as temporary equity) | $ | 30.4 |  |  | $ | 315.0 |  |  | $ | 345.4 |  |  | $ | 109.8 |  |  | $ | 315.0 |  |  | $ | 424.8 |  |
  (was, 2018-11-30, similarity 0.988):
[0001327567-18-000031:note_history:22]
|  | October 31, 2018 |  | July 31, 2018 |
|  | 2019 Notes |  | 2023 Notes |  | Total |  | 2019 Notes |  | 2023 Notes |  | Total |
| Liability component: |  |  |  |  |  |  |  |  |  |  |  |
| Principal | $ | 247.7 |  |  | $ | 1,693.0 |  |  | $ | 1,940.7 |  |  | $ | 575.0 |  |  | $ | 1,693.0 |  |  | $ | 2,268.0 |  |
| Less: debt discount and debt issuance costs, net of amortization | 7.8 |  |  | 308.5 |  |  | 316.3 |  |  | 24.6 |  |  | 323.3 |  |  | 347.9 |  |
| Net carrying amount | $ | 239.9 |  |  | $ | 1,384.5 |  |  | $ | 1,624.4 |  |  | $ | 550.4 |  |  | $ | 1,369.7 |  |  | $ | 1,920.1 |  |
| Equity component (including amounts classified as temporary equity) | $ | 47.3 |  |  | $ | 315.0 |  |  | $ | 362.3 |  |  | $ | 109.8 |  |  | $ | 315.0 |  |  | $ | 424.8 |  |


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2019-02-27):
[0001327567-19-000008:note_history:23]
On or after the respective convertible date, holders may surrender all or any portion of their Notes for conversion at any time prior to the close of business on the second scheduled trading day immediately preceding the applicable maturity date regardless of the foregoing conditions, and such conversions will be settled upon the applicable maturity date. Upon conversion, holders of the Notes of a series will receive cash equal to the aggregate principal amount of the Notes of such series to be converted, and, at our election, cash and/or shares of our common stock for any amounts in excess of the aggregate principal amount of the Notes of such series being converted.

- added (2019-02-27):
[0001327567-19-000008:note_history:24]
The sale price condition was met for the 2019 Notes during the fiscal quarters ended July 31, 2018 and October 31, 2018. As a result, holders were able to convert their 2019 Notes at any time during the fiscal quarter ended October 31, 2018 and up to January 1, 2019. On or after January 1, 2019, holders may surrender their 2019 Notes for conversion at any time prior to maturity, in accordance with the terms described above. Such conversion requests will settle upon maturity of the 2019 Notes. Accordingly, the net carrying amount of the 2019 Notes was classified as a current liability and the portion of the equity component representing the conversion option was classified as temporary equity in our condensed consolidated balance sheets as of January 31, 2019. As of January 31, 2019, $159.4 million in aggregate principal amount of the 2019 Notes remained outstanding.

- added (2019-02-27):
[0001327567-19-000008:note_history:25]
The following table presents details of conversions of the 2019 Notes during the reporting period (in millions):

- added (2019-02-27):
[0001327567-19-000008:note_history:26]
|  | Three Months Ended |  | Six Months Ended |
|  | January 31, 2019 |  | January 31, 2019 |
| 2019 Notes principal converted and repaid in cash: |  |  |  |
| Allocated to liability component(1) | $ | 86.3 |  |  | $ | 403.4 |  |
| Allocated to equity component(2) | 2.0 |  |  | 12.2 |  |
| Total principal converted and repaid in cash | $ | 88.3 |  |  | $ | 415.6 |  |
| Loss on conversions of convertible senior notes(3) | $ | 0.4 |  |  | $ | 2.6 |  |
| Shares of common stock issued in connection with conversion of convertible senior notes(4) | 0.3 |  |  | 1.7 |  |

- added (2019-02-27):
[0001327567-19-000008:note_history:27]
______________

- added (2019-02-27):
[0001327567-19-000008:note_history:28]
| (1) | Recorded as a reduction to convertible senior notes, net in our condensed consolidated balance sheets and calculated by measuring the fair value of a similar liability that did not have an associated convertible feature. |

- added (2019-02-27):
[0001327567-19-000008:note_history:29]
| (2) | Recorded as a reduction to additional paid-in capital in our condensed consolidated balance sheets. |

- added (2019-02-27):
[0001327567-19-000008:note_history:30]
| (3) | Represents the difference between the cash consideration allocated to the liability component and the net carrying amount of the liability component on the respective settlement dates. The amount is included in other income, net in our condensed consolidated statement of operations. |

- added (2019-02-27):
[0001327567-19-000008:note_history:31]
| (4) | Shares of common stock issued to the holders for the conversion value in excess of the principal amount. These shares were fully offset by shares received from the corresponding exercise of the associated note hedges. |

- changed (2019-02-27):
[0001327567-19-000008:note_history:32]
The sale price condition was not met for the 2023 Notes during the fiscal quarters ended January 31, 2019 or July 31, 2018. Since the 2023 Notes were not convertible, the net carrying amount of the 2023 Notes was classified as a long-term liability and the equity component was included in additional paid-in capital in our condensed consolidated balance sheets as of January 31, 2019 and July 31, 2018. As of January 31, 2019, all of the 2023 Notes remained outstanding.
  (was, 2018-11-30, similarity 0.8445):
[0001327567-18-000031:note_history:32]
The sale price condition was not met for the 2023 Notes during the fiscal quarters ended October 31, 2018 and July 31, 2018. Since the 2023 Notes were not convertible, the net carrying amount of the 2023 Notes was classified as a long-term liability and the equity component was included in additional paid-in capital in our condensed consolidated balance sheets as of October 31, 2018.

- changed (2019-02-27):
[0001327567-19-000008:note_history:33]
The following table sets forth the components of the Notes as of January 31, 2019 and July 31, 2018 (in millions):
  (was, 2018-11-30, similarity 0.9423):
[0001327567-18-000031:note_history:33]
The following table sets forth the components of the Notes as of October 31, 2018 and July 31, 2018 (in millions):

- changed (2019-02-27):
[0001327567-19-000008:note_history:34]
|  | January 31, 2019 |  | July 31, 2018 |
|  | 2019 Notes |  | 2023 Notes |  | Total |  | 2019 Notes |  | 2023 Notes |  | Total |
| Liability component: |  |  |  |  |  |  |  |  |  |  |  |
| Principal | $ | 159.4 |  |  | $ | 1,693.0 |  |  | $ | 1,852.4 |  |  | $ | 575.0 |  |  | $ | 1,693.0 |  |  | $ | 2,268.0 |  |
| Less: debt discount and debt issuance costs, net of amortization | 3.1 |  |  | 293.5 |  |  | 296.6 |  |  | 24.6 |  |  | 323.3 |  |  | 347.9 |  |
| Net carrying amount | $ | 156.3 |  |  | $ | 1,399.5 |  |  | $ | 1,555.8 |  |  | $ | 550.4 |  |  | $ | 1,369.7 |  |  | $ | 1,920.1 |  |
| Equity component (including amounts classified as temporary equity) | $ | 30.4 |  |  | $ | 315.0 |  |  | $ | 345.4 |  |  | $ | 109.8 |  |  | $ | 315.0 |  |  | $ | 424.8 |  |
  (was, 2018-11-30, similarity 0.988):
[0001327567-18-000031:note_history:34]
|  | October 31, 2018 |  | July 31, 2018 |
|  | 2019 Notes |  | 2023 Notes |  | Total |  | 2019 Notes |  | 2023 Notes |  | Total |
| Liability component: |  |  |  |  |  |  |  |  |  |  |  |
| Principal | $ | 247.7 |  |  | $ | 1,693.0 |  |  | $ | 1,940.7 |  |  | $ | 575.0 |  |  | $ | 1,693.0 |  |  | $ | 2,268.0 |  |
| Less: debt discount and debt issuance costs, net of amortization | 7.8 |  |  | 308.5 |  |  | 316.3 |  |  | 24.6 |  |  | 323.3 |  |  | 347.9 |  |
| Net carrying amount | $ | 239.9 |  |  | $ | 1,384.5 |  |  | $ | 1,624.4 |  |  | $ | 550.4 |  |  | $ | 1,369.7 |  |  | $ | 1,920.1 |  |
| Equity component (including amounts classified as temporary equity) | $ | 47.3 |  |  | $ | 315.0 |  |  | $ | 362.3 |  |  | $ | 109.8 |  |  | $ | 315.0 |  |  | $ | 424.8 |  |

- added (2019-02-27):
[0001327567-19-000008:note_history:35]
The total estimated fair value of the Notes was $2.1 billion and $2.7 billion at January 31, 2019 and July 31, 2018, respectively. The fair value was determined based on the closing trading price per $100 of the Notes as of the last day of trading for the period. We consider the fair value of the Notes at January 31, 2019 and July 31, 2018 to be a Level 2 measurement. The fair value of the Notes is primarily affected by the trading price of our common stock and market interest rates. As of January 31, 2019, the if-converted value of the 2019 Notes exceeded its principal amount by $119.1 million. Based on the closing price of our common stock on January 31, 2019, the if-converted value of the 2023 Notes was less than its principal amount.

- changed (2019-02-27):
[0001327567-19-000008:note_history:36]
|  | Three Months Ended January 31, |  | Six Months Ended January 31, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
|  | 2019 Notes |  | 2023 Notes |  | Total |  | 2019 Notes |  | 2023 Notes |  | Total |  | 2019 Notes |  | 2023 Notes |  | Total |  | 2019 Notes |  | 2023 Notes |  | Total |
| Contractual interest expense | $ | — |  |  | $ | 3.1 |  |  | $ | 3.1 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 6.3 |  |  | $ | 6.3 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Amortization of debt discount | 2.0 |  |  | 14.5 |  |  | 16.5 |  |  | 5.8 |  |  | — |  |  | 5.8 |  |  | 6.0 |  |  | 28.9 |  |  | 34.9 |  |  | 11.4 |  |  | — |  |  | 11.4 |  |
| Amortization of debt issuance costs | 0.2 |  |  | 0.4 |  |  | 0.6 |  |  | 0.6 |  |  | — |  |  | 0.6 |  |  | 0.7 |  |  | 0.9 |  |  | 1.6 |  |  | 1.3 |  |  | — |  |  | 1.3 |  |
| Total interest expense recognized | $ | 2.2 |  |  | $ | 18.0 |  |  | $ | 20.2 |  |  | $ | 6.4 |  |  | $ | — |  |  | $ | 6.4 |  |  | $ | 6.7 |  |  | $ | 36.1 |  |  | $ | 42.8 |  |  | $ | 12.7 |  |  | $ | — |  |  | $ | 12.7 |  |
| Effective interest rate of the liability component | 4.8 | % |  | 5.2 | % |  |  |  | 4.8 | % |  | — | % |  |  |  | 4.8 | % |  | 5.2 | % |  |  |  | 4.8 | % |  | — | % |  |  |
  (was, 2018-11-30, similarity 0.7204):
[0001327567-18-000031:note_history:36]
|  | Three Months Ended |  | Three Months Ended |
|  | October 31, 2018 |  | October 31, 2017 |
|  | 2019 Notes |  | 2023 Notes |  | Total |  | 2019 Notes |  | 2023 Notes |  | Total |
| Contractual interest expense | $ | — |  |  | $ | 3.2 |  |  | $ | 3.2 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Amortization of debt discount | 4.0 |  |  | 14.4 |  |  | 18.4 |  |  | 5.6 |  |  | — |  |  | 5.6 |  |
| Amortization of debt issuance costs | 0.5 |  |  | 0.5 |  |  | 1.0 |  |  | 0.7 |  |  | — |  |  | 0.7 |  |
| Total interest expense recognized | $ | 4.5 |  |  | $ | 18.1 |  |  | $ | 22.6 |  |  | $ | 6.3 |  |  | $ | — |  |  | $ | 6.3 |  |
| Effective interest rate of the liability component | 4.8 | % |  | 5.2 | % |  |  |  | 4.8 | % |  | — | % |  |  |

- changed (2019-02-27):
[0001327567-19-000008:note_history:37]
As a result of the conversions of the 2019 Notes settled during the three and six months ended January 31, 2019, we exercised the corresponding portion of our 2019 Note Hedges and received 0.3 million and 1.7 million shares of common stock during the respective periods.
  (was, 2018-11-30, similarity 0.7605):
[0001327567-18-000031:note_history:37]
As a result of the conversions of the 2019 Notes settled during the fiscal quarter ended October 31, 2018, we exercised the corresponding portion of our 2019 Note Hedges and received 1.4 million shares of common stock during the period.

- changed (2019-02-27):
[0001327567-19-000008:note_history:38]
The borrowings under the Credit Facility bear interest, at our option, at a base rate plus a spread of 0.00% to 0.75%, or an adjusted LIBO rate plus a spread of 1.00% to 1.75%, in each case with such spread being determined based on our leverage ratio. We are obligated to pay an ongoing commitment fee on undrawn amounts at a rate of 0.125% to 0.250%, depending on our leverage ratio. As of January 31, 2019, there were no amounts outstanding and we were in compliance with all covenants under the Credit Agreement.
  (was, 2018-11-30, similarity 0.9857):
[0001327567-18-000031:note_history:38]
The borrowings under the Credit Facility bear interest, at our option, at a base rate plus a spread of 0.00% to 0.75%, or an adjusted LIBO rate plus a spread of 1.00% to 1.75%, in each case with such spread being determined based on our leverage ratio. We are obligated to pay an ongoing commitment fee on undrawn amounts at a rate of 0.125% to 0.250%, depending on our leverage ratio. As of October 31, 2018, there were no amounts outstanding and we were in compliance with all covenants under the Credit Agreement.

- removed (2019-02-27):
[0001327567-18-000031:note_history:39]
On or after the respective convertible date, holders may convert all or any portion of their Notes at any time prior to the close of business on the second scheduled trading day immediately preceding the applicable maturity date regardless of the foregoing conditions. Upon conversion, holders of the Notes of a series will receive cash equal to the aggregate principal amount of the Notes of such series to be converted, and, at our election, cash and/or shares of our common stock for any amounts in excess of the aggregate principal amount of the Notes of such series being converted.

- removed (2019-02-27):
[0001327567-18-000031:note_history:40]
The sale price condition was met for the 2019 Notes during the fiscal quarter ended July 31, 2018, and, as a result, holders were able to convert their 2019 Notes at any time during the fiscal quarter ended October 31, 2018. During the three months ended October 31, 2018, holders converted $327.3 million in aggregate principal amount of the 2019 Notes, which we repaid in cash. We also issued 1.4 million shares of our common stock to the holders for the conversion value in excess of the principal amount. These shares were fully offset by shares received from the corresponding exercise of the associated note hedges. We allocated $317.1 million of the cash consideration to the liability component of the converted 2019 Notes, which was calculated by measuring the fair value of a similar liability that did not have an associated convertible feature. We recorded a loss of $2.2 million related to the settlement of the 2019 Notes converted, which represented the difference between the cash consideration allocated to the liability component and the net carrying amount of the liability component on the respective settlement dates. The loss was included in other income, net in our condensed consolidated statement of operations for the three months ended October 31, 2018. During the three months ended October 31, 2018, we also recorded a $10.2 million net reduction to additional paid-in capital in our condensed consolidated balance sheets, reflecting the portion of the cash consideration allocated to the equity component.

- removed (2019-02-27):
[0001327567-18-000031:note_history:41]
The sale price condition continued to be met through the fiscal quarter ended October 31, 2018, and, as a result, holders may convert their 2019 Notes at any time prior to January 1, 2019 (the “2019 Notes Convertible Date”). On or after the 2019 Notes Convertible Date, holders may convert their 2019 Notes at any time prior to maturity, in accordance with the terms described above, regardless of the sale price condition. Accordingly, the net carrying amount of the 2019 Notes was classified as a current liability and the portion of the equity component representing the conversion option was classified as temporary equity in our condensed consolidated balance sheets as of October 31, 2018.

- removed (2019-02-27):
[0001327567-18-000031:note_history:42]
As of October 31, 2018, $247.7 million in aggregate principal amount of the 2019 Notes remained outstanding and all of the 2023 Notes remained outstanding. Subsequent to October 31, 2018, through the filing date of this Quarterly Report on Form 10-Q, $88.3 million in principal amount of the 2019 Notes was converted or had been submitted by the holders for conversion and will settle during the fiscal quarter ending January 31, 2019.

- removed (2019-02-27):
[0001327567-18-000031:note_history:43]
The total estimated fair value of the Notes was $2.1 billion and $2.7 billion at October 31, 2018 and July 31, 2018, respectively. The fair value was determined based on the closing trading price per $100 of the Notes as of the last day of trading for the period. We consider the fair value of the Notes at October 31, 2018 and July 31, 2018 to be a Level 2 measurement. The fair value of the Notes is primarily affected by the trading price of our common stock and market interest rates. As of October 31, 2018, the if-converted value of the 2019 Notes exceeded its principal amount by $220.2 million. Based on the closing price of our common stock on October 31, 2018, the if-converted value of the 2023 Notes was less than its principal amount.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-02-27):
[0001327567-19-000008:note_history:44]
The following tables summarize the amortized cost, unrealized gains and losses, and fair value of our available-for-sale securities as of January 31, 2019 and July 31, 2018 (in millions):
  (was, 2018-11-30, similarity 0.9661):
[0001327567-18-000031:note_history:44]
The following tables summarize the amortized cost, unrealized gains and losses, and fair value of our available-for-sale securities as of October 31, 2018 and July 31, 2018 (in millions):

- changed (2019-02-27):
[0001327567-19-000008:note_history:45]
|  | January 31, 2019 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | $ | 39.4 |  |  | $ | — |  |  | $ | — |  |  | $ | 39.4 |  |
| U.S. government and agency securities | 279.4 |  |  | — |  |  | — |  |  | 279.4 |  |
| Total available-for-sale cash equivalents | $ | 318.8 |  |  | $ | — |  |  | $ | — |  |  | $ | 318.8 |  |
| Investments: |  |  |  |  |  |  |  |
| Commercial paper | $ | 50.2 |  |  | $ | — |  |  | $ | — |  |  | $ | 50.2 |  |
| Corporate debt securities | 495.9 |  |  | 0.9 |  |  | (1.4 | ) |  | 495.4 |  |
| U.S. government and agency securities | 1,968.0 |  |  | 1.1 |  |  | (3.9 | ) |  | 1,965.2 |  |
| Total available-for-sale investments | $ | 2,514.1 |  |  | $ | 2.0 |  |  | $ | (5.3 | ) |  | $ | 2,510.8 |  |
  (was, 2018-11-30, similarity 0.7841):
[0001327567-18-000031:note_history:45]
|  | October 31, 2018 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | $ | 5.0 |  |  | $ | — |  |  | $ | — |  |  | $ | 5.0 |  |
| Corporate debt securities | 2.5 |  |  | — |  |  | — |  |  | 2.5 |  |
| U.S. government and agency securities | 210.3 |  |  | — |  |  | — |  |  | 210.3 |  |
| Total available-for-sale cash equivalents | $ | 217.8 |  |  | $ | — |  |  | $ | — |  |  | $ | 217.8 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 5.4 |  |  | $ | — |  |  | $ | — |  |  | $ | 5.4 |  |
| Non-U.S. government securities | 20.0 |  |  | — |  |  | — |  |  | 20.0 |  |
| Commercial paper | 97.3 |  |  | — |  |  | — |  |  | 97.3 |  |
| Corporate debt securities | 382.5 |  |  | — |  |  | (2.4 | ) |  | 380.1 |  |
| U.S. government and agency securities | 1,489.0 |  |  | — |  |  | (6.9 | ) |  | 1,482.1 |  |
| Total available-for-sale investments | $ | 1,994.2 |  |  | $ | — |  |  | $ | (9.3 | ) |  | $ | 1,984.9 |  |

- changed (2019-02-27):
[0001327567-19-000008:note_history:46]
Unrealized losses related to these securities are due to interest rate fluctuations as opposed to credit quality. In addition, we do not intend to sell and it is not likely that we would be required to sell these securities before recovery of their amortized cost basis, which may be at maturity. As a result, there were no other-than-temporary impairments for these securities at January 31, 2019 and July 31, 2018.
  (was, 2018-11-30, similarity 0.9556):
[0001327567-18-000031:note_history:46]
Unrealized losses related to these securities are due to interest rate fluctuations as opposed to credit quality. In addition, we do not intend to sell and it is not likely that we would be required to sell these securities before recovery of their amortized cost basis, which may be at maturity. As a result, there were no other-than-temporary impairments for these securities at October 31, 2018 and July 31, 2018.

- changed (2019-02-27):
[0001327567-19-000008:note_history:47]
The following table summarizes the amortized cost and fair value of our available-for-sale securities as of January 31, 2019, by contractual years-to-maturity (in millions):
  (was, 2018-11-30, similarity 0.9641):
[0001327567-18-000031:note_history:47]
The following table summarizes the amortized cost and fair value of our available-for-sale securities as of October 31, 2018, by contractual years-to-maturity (in millions):

- changed (2019-02-27):
[0001327567-19-000008:note_history:48]
Marketable equity securities consist of money market funds and are included in cash and cash equivalents in our condensed consolidated balance sheets. As of January 31, 2019 and July 31, 2018, the carrying value of our marketable equity securities were $430.6 million and $1.5 billion, respectively. During the three and six months ended January 31, 2019 and 2018, there were no unrealized gains or losses recognized for these securities.
  (was, 2018-11-30, similarity 0.902):
[0001327567-18-000031:note_history:48]
Marketable equity securities consist of money market funds and are included in cash and cash equivalents in our condensed consolidated balance sheets. As of October 31, 2018 and July 31, 2018, the carrying value of our marketable equity securities were $904.4 million and $1.5 billion, respectively. During the three months ended October 31, 2018 and 2017, there were no unrealized gains or losses recognized for these securities.


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2019-02-27):
[0001327567-19-000008:note_history:49]
We record deferred revenue when cash payments are received or due in advance of our performance. Our payment terms typically require payment within 30 to 45 days of the date we issue an invoice. The current portion of deferred revenue represents the amounts that are expected to be recognized as revenue within one year of the condensed consolidated balance sheet date. During the six months ended January 31, 2019, we recognized approximately $695.0 million of revenue pertaining to amounts that were deferred as of July 31, 2018.
  (was, 2018-11-30, similarity 0.7432):
[0001327567-18-000031:note_history:49]
We record deferred revenue when cash payments are received or due in advance of our performance. Our payment terms typically require payment within 30 to 45 days of the date we issue an invoice. The current portion of deferred revenue represents the amounts that are expected to be recognized as revenue within one year of the condensed consolidated balance sheet date. During the three months ended October 31, 2018, we recognized approximately $370.0 million of revenue pertaining to amounts that were deferred as of July 31, 2018.

- changed (2019-02-27):
[0001327567-19-000008:note_history:50]
Revenue expected to be recognized from remaining performance obligations was $2.6 billion as of January 31, 2019, of which we expect to recognize approximately $1.4 billion over the next 12 months and the remainder thereafter.
  (was, 2018-11-30, similarity 0.7395):
[0001327567-18-000031:note_history:50]
Revenue expected to be recognized from remaining performance obligations was $2.5 billion as of October 31, 2018, of which we expect to recognize approximately $1.3 billion over the next 12 months and the remainder thereafter.

- added (2019-02-27):
[0001327567-19-000008:note_history:51]
|  | Three Months Ended January 31, |  | Six Months Ended January 31, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
|  |  |  | (As Adjusted) |  |  |  | (As Adjusted) |
| Revenue: |  |  |  |  |  |  |  |
| Americas |  |  |  |  |  |  |  |
| United States | $ | 434.6 |  |  | $ | 346.0 |  |  | $ | 850.5 |  |  | $ | 672.0 |  |
| Other Americas | 40.4 |  |  | 27.3 |  |  | 74.7 |  |  | 50.6 |  |
| Total Americas | 475.0 |  |  | 373.3 |  |  | 925.2 |  |  | 722.6 |  |
| Europe, the Middle East, and Africa (“EMEA”) | 148.3 |  |  | 107.2 |  |  | 276.0 |  |  | 201.9 |  |
| Asia Pacific and Japan (“APAC”) | 87.9 |  |  | 65.1 |  |  | 166.0 |  |  | 122.9 |  |
| Total revenue | $ | 711.2 |  |  | $ | 545.6 |  |  | $ | 1,367.2 |  |  | $ | 1,047.4 |  |

- added (2019-02-27):
[0001327567-19-000008:note_history:52]
|  | Three Months Ended January 31, |  | Six Months Ended January 31, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
|  |  |  | (As Adjusted) |  |  |  | (As Adjusted) |
| Revenue: |  |  |  |  |  |  |  |
| Product | $ | 271.6 |  |  | $ | 204.8 |  |  | $ | 512.1 |  |  | $ | 389.6 |  |
| Subscription and support |  |  |  |  |  |  |  |
| Subscription | 249.7 |  |  | 183.3 |  |  | 481.0 |  |  | 352.3 |  |
| Support | 189.9 |  |  | 157.5 |  |  | 374.1 |  |  | 305.5 |  |
| Total subscription and support | 439.6 |  |  | 340.8 |  |  | 855.1 |  |  | 657.8 |  |
| Total revenue | $ | 711.2 |  |  | $ | 545.6 |  |  | $ | 1,367.2 |  |  | $ | 1,047.4 |  |

- changed (2019-02-27):
[0001327567-19-000008:note_history:53]
The following table presents details of our short-term and long-term deferred contract costs as of January 31, 2019 and July 31, 2018 (in millions):
  (was, 2018-11-30, similarity 0.9565):
[0001327567-18-000031:note_history:53]
The following table presents details of our short-term and long-term deferred contract costs as of October 31, 2018 and July 31, 2018 (in millions):

- changed (2019-02-27):
[0001327567-19-000008:note_history:54]
|  | January 31, 2019 |  | July 31, 2018 |
| Short-term deferred contract costs | $ | 117.6 |  |  | $ | 113.2 |  |
| Long-term deferred contract costs | 230.7 |  |  | 224.8 |  |
| Total deferred contract costs | $ | 348.3 |  |  | $ | 338.0 |  |
  (was, 2018-11-30, similarity 0.9698):
[0001327567-18-000031:note_history:54]
|  | October 31, 2018 |  | July 31, 2018 |
| Short-term deferred contract costs | $ | 112.1 |  |  | $ | 113.2 |  |
| Long-term deferred contract costs | 223.1 |  |  | 224.8 |  |
| Total deferred contract costs | $ | 335.2 |  |  | $ | 338.0 |  |

- changed (2019-02-27):
[0001327567-19-000008:note_history:55]
We recognized amortization expense for our deferred contract costs of $41.9 million and $83.0 million during the three and six months ended January 31, 2019, respectively, and $29.2 million and $57.3 million during the three and six months ended January 31, 2018, respectively. We did not recognize any impairment losses on our deferred contract costs during the three and six months ended January 31, 2019 or 2018.
  (was, 2018-11-30, similarity 0.6697):
[0001327567-18-000031:note_history:55]
We recognized amortization expense for our deferred contract costs of $41.1 million and $28.1 million during the three months ended October 31, 2018 and 2017, respectively. We did not recognize any impairment losses on our deferred contract costs during the three months ended October 31, 2018 or 2017.

- removed (2019-02-27):
[0001327567-18-000031:note_history:56]
|  | Three Months Ended October 31, |
|  | 2018 |  | 2017 |
|  |  |  | (As Adjusted) |
| Revenue: |  |  |  |
| Americas |  |  |  |
| United States | $ | 415.9 |  |  | $ | 326.0 |  |
| Other Americas | 34.3 |  |  | 23.3 |  |
| Total Americas | 450.2 |  |  | 349.3 |  |
| Europe, the Middle East, and Africa (“EMEA”) | 127.7 |  |  | 94.7 |  |
| Asia Pacific and Japan (“APAC”) | 78.1 |  |  | 57.8 |  |
| Total revenue | $ | 656.0 |  |  | $ | 501.8 |  |

- removed (2019-02-27):
[0001327567-18-000031:note_history:57]
|  | Three Months Ended October 31, |
|  | 2018 |  | 2017 |
|  |  |  | (As Adjusted) |
| Revenue: |  |  |  |
| Product | $ | 240.5 |  |  | $ | 184.8 |  |
| Subscription and support |  |  |  |
| Subscription | 231.3 |  |  | 169.0 |  |
| Support | 184.2 |  |  | 148.0 |  |
| Total subscription and support | 415.5 |  |  | 317.0 |  |
| Total revenue | $ | 656.0 |  |  | $ | 501.8 |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_prior_note, score: 0.0

- added (2019-02-27):
[0001327567-19-000008:note_history:58]
Subsequent Events

- added (2019-02-27):
[0001327567-19-000008:note_history:59]
Business Combination

- added (2019-02-27):
[0001327567-19-000008:note_history:60]
In February 2019, we entered into a definitive agreement to acquire Demisto, Inc. (“Demisto”), a privately-held security company, in exchange for total consideration of approximately $560.0 million in cash and common stock, subject to adjustments. The number of shares of common stock to be issued in connection with the transaction will be finalized upon closing. The acquisition expands the functionality of our platform with the addition of Demisto’s security, orchestration, automation, and response product. The acquisition is expected to close during our third quarter of fiscal 2019.
