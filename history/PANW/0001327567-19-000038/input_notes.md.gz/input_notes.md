# PANW notes — 0001327567-19-000038


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock

[0001327567-19-000038:notes:1]
Description of Business and Summary of Significant Accounting Policies 
Description of Business

[0001327567-19-000038:notes:2]
Palo Alto Networks, Inc. (the “Company,” “we,” “us,” or “our”), located in Santa Clara, California, was incorporated in March 2005 under the laws of the State of Delaware and commenced operations in April 2005. We offer platforms that empower enterprises, service providers, and government entities to secure their organizations by safely enabling applications and data running in their networks, on their endpoints, and in the cloud, and by preventing breaches that stem from targeted cyberattacks.

[0001327567-19-000038:notes:3]
[same as prior period, unchanged from 0001327567-19-000016:notes:34]

[0001327567-19-000038:notes:4]
The accompanying condensed consolidated financial statements have been prepared in conformity with U.S. generally accepted accounting principles (“GAAP”), consistent in all material respects with those applied in our Annual Report on Form 10-K for the fiscal year ended July 31, 2019, filed with the Securities and Exchange Commission (“SEC”) on September 9, 2019. Our condensed consolidated financial statements include our accounts and our wholly owned subsidiaries. All significant intercompany balances and transactions have been eliminated in consolidation.

[0001327567-19-000038:notes:5]
[same as prior period, unchanged from 0001327567-19-000016:notes:36]

[0001327567-19-000038:notes:6]
Certain prior period amounts have been reclassified to conform to our current period presentation.

[0001327567-19-000038:notes:7]
Our condensed consolidated financial statements should be read in conjunction with the audited consolidated financial statements and related notes in our Annual Report on Form 10-K for the fiscal year ended July 31, 2019.

[0001327567-19-000038:notes:8]
[same as prior period, unchanged from 0001327567-19-000016:notes:39]

[0001327567-19-000038:notes:9]
There have been no material changes to our significant accounting policies as of and for the three months ended October 31, 2019, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended July 31, 2019, except for the change in our accounting policies for leases due to our adoption of new lease accounting guidance. Refer to “Recently Adopted Accounting Pronouncements” below and Note 10. Leases.

[0001327567-19-000038:notes:10]
Recently Adopted Accounting Pronouncements

[0001327567-19-000038:notes:11]
[same as prior period, unchanged from 0001327567-19-000016:notes:65]

[0001327567-19-000038:notes:12]
In February 2016, the Financial Accounting Standards Board (“FASB”) issued new authoritative guidance on lease accounting. Among its provisions, the standard requires lessees to recognize right-of-use assets and lease liabilities on the balance sheet for operating leases and also requires additional qualitative and quantitative disclosures about lease arrangements.

[0001327567-19-000038:notes:13]
We adopted this standard effective August 1, 2019 on a modified retrospective basis, under which financial results reported in periods prior to fiscal 2020 were not adjusted. We elected the package of practical expedients, which allowed us to carry forward our historical assessments of whether contracts are or contain leases, lease classification, and initial direct costs. Additionally, we elected to account for lease and non-lease components as a single lease component and to not recognize right-of-use assets and lease liabilities for leases with a term of 12 months or less.

[0001327567-19-000038:notes:14]
The most significant impact of adopting this guidance was the recognition of $286.4 million of operating lease right-of-use assets and $437.6 million of operating lease liabilities on our condensed consolidated balance sheet as of August 1, 2019, which included reclassifying previously recognized $124.2 million in lease incentives, deferred or prepaid rent, as well as $27.0 million in cease-use liabilities to operating lease right-of-use assets.

[0001327567-19-000038:notes:15]
The adoption of this standard had no impact on our condensed consolidated statements of operations and condensed consolidated statements of cash flows. Refer to Note 10. Leases for further discussion.

[0001327567-19-000038:notes:16]
Recently Issued Accounting Pronouncements

[0001327567-19-000038:notes:17]
[same as prior period, unchanged from 0001327567-19-000016:notes:63]

[0001327567-19-000038:notes:18]
In June 2016, the FASB issued new authoritative guidance on the accounting for credit losses on most financial assets and certain financial instruments. The standard replaces the existing incurred loss model with an expected credit loss model for financial

[0001327567-19-000038:notes:19]
assets measured at amortized cost, including trade receivables, and requires that credit losses on available-for-sale debt securities be presented as an allowance rather than as a write-down. The standard is effective for us in our first quarter of fiscal 2021 and will be applied on a modified retrospective basis. We are currently evaluating whether this standard will have a material impact on our condensed consolidated financial statements.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001327567-19-000038:notes:20]
Revenue
Disaggregation of Revenue

[0001327567-19-000038:notes:21]
[same as prior period, unchanged from 0001327567-19-000016:notes:213]

[0001327567-19-000038:notes:22]
|  | Three Months Ended October 31, |
|  | 2019 |  | 2018 |
| Revenue: |  |  |  |
| Americas |  |  |  |
| United States | $ | 494.9 |  |  | $ | 415.9 |  |
| Other Americas | 34.7 |  |  | 34.3 |  |
| Total Americas | 529.6 |  |  | 450.2 |  |
| Europe, the Middle East, and Africa (“EMEA”) | 147.6 |  |  | 127.7 |  |
| Asia Pacific and Japan (“APAC”) | 94.7 |  |  | 78.1 |  |
| Total revenue | $ | 771.9 |  |  | $ | 656.0 |  |

[0001327567-19-000038:notes:23]
[same as prior period, unchanged from 0001327567-19-000016:notes:215]

[0001327567-19-000038:notes:24]
|  | Three Months Ended October 31, |
|  | 2019 |  | 2018 |
| Revenue: |  |  |  |
| Product | $ | 231.2 |  |  | $ | 240.5 |  |
| Subscription and support |  |  |  |  |  |
| Subscription | 318.6 |  |  | 231.3 |  |
| Support | 222.1 |  |  | 184.2 |  |
| Total subscription and support | 540.7 |  |  | 415.5 |  |
| Total revenue | $ | 771.9 |  |  | $ | 656.0 |  |

[0001327567-19-000038:notes:25]
Deferred Revenue

[0001327567-19-000038:notes:26]
During the three months ended October 31, 2019, we recognized approximately $485.0 million of revenue pertaining to amounts that were deferred as of July 31, 2019.

[0001327567-19-000038:notes:27]
[same as prior period, unchanged from 0001327567-19-000016:notes:210]

[0001327567-19-000038:notes:28]
Revenue expected to be recognized from remaining performance obligations was $3.1 billion as of October 31, 2019, of which we expect to recognize approximately $1.7 billion over the next 12 months and the remainder thereafter.
Deferred Contract Costs
The following table presents details of our short-term and long-term deferred contract costs as of October 31, 2019 and July 31, 2019 (in millions):

[0001327567-19-000038:notes:29]
|  | October 31, 2019 |  | July 31, 2019 |
| Short-term deferred contract costs | $ | 155.4 |  |  | $ | 151.1 |  |
| Long-term deferred contract costs | 317.6 |  |  | 324.2 |  |
| Total deferred contract costs | $ | 473.0 |  |  | $ | 475.3 |  |

[0001327567-19-000038:notes:30]
We recognized amortization expense for our deferred contract costs of $55.6 million and $43.6 million during the three months ended October 31, 2019 and 2018, respectively. We did not recognize any impairment losses on our deferred contract costs during the three months ended October 31, 2019 or 2018.


## us-gaap:FairValueDisclosuresTextBlock

[0001327567-19-000038:notes:31]
Fair Value Measurements 
We categorize assets and liabilities recorded or disclosed at fair value on our condensed consolidated balance sheets based upon the level of judgment associated with inputs used to measure their fair value. The categories are as follows:

[0001327567-19-000038:notes:32]
[same as prior period, unchanged from 0001327567-19-000016:notes:159]

[0001327567-19-000038:notes:33]
[same as prior period, unchanged from 0001327567-19-000016:notes:160]

[0001327567-19-000038:notes:34]
[same as prior period, unchanged from 0001327567-19-000016:notes:161]

[0001327567-19-000038:notes:35]
The following table presents the fair value of our financial assets and liabilities measured at fair value on a recurring basis using the above input categories as of October 31, 2019 and July 31, 2019 (in millions):

[0001327567-19-000038:notes:36]
|  |  | October 31, 2019 |  | July 31, 2019 |
|  |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Cash equivalents: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 617.3 |  |  | $ | — |  |  | $ | — |  |  | $ | 617.3 |  |  | $ | 369.1 |  |  | $ | — |  |  | $ | — |  |  | $ | 369.1 |  |
| Certificates of deposit |  | — |  |  | 4.0 |  |  | — |  |  | 4.0 |  |  | — |  |  | 12.0 |  |  |  |  | 12.0 |  |
| Commercial paper |  | — |  |  | 4.5 |  |  | — |  |  | 4.5 |  |  | — |  |  | 19.3 |  |  | — |  |  | 19.3 |  |
| U.S. government and agency securities |  | — |  |  | 15.0 |  |  | — |  |  | 15.0 |  |  | — |  |  | 54.4 |  |  | — |  |  | 54.4 |  |
| Total cash equivalents |  | 617.3 |  |  | 23.5 |  |  | — |  |  | 640.8 |  |  | 369.1 |  |  | 85.7 |  |  | — |  |  | 454.8 |  |
| Short-term investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Certificates of deposit |  | — |  |  | 23.7 |  |  | — |  |  | 23.7 |  |  | — |  |  | 17.5 |  |  | — |  |  | 17.5 |  |
| Commercial paper |  | — |  |  | 15.9 |  |  | — |  |  | 15.9 |  |  | — |  |  | 8.9 |  |  | — |  |  | 8.9 |  |
| Corporate debt securities |  | — |  |  | 369.9 |  |  | — |  |  | 369.9 |  |  | — |  |  | 375.5 |  |  | — |  |  | 375.5 |  |
| U.S. government and agency securities |  | — |  |  | 1,188.0 |  |  | — |  |  | 1,188.0 |  |  | — |  |  | 1,439.8 |  |  | — |  |  | 1,439.8 |  |
| Total short-term investments |  | — |  |  | 1,597.5 |  |  | — |  |  | 1,597.5 |  |  | — |  |  | 1,841.7 |  |  | — |  |  | 1,841.7 |  |
| Long-term investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate debt securities |  | — |  |  | 198.3 |  |  | — |  |  | 198.3 |  |  | — |  |  | 214.3 |  |  | — |  |  | 214.3 |  |
| U.S. government and agency securities |  | — |  |  | 269.3 |  |  | — |  |  | 269.3 |  |  | — |  |  | 361.1 |  |  | — |  |  | 361.1 |  |
| Total long-term investments |  | — |  |  | 467.6 |  |  | — |  |  | 467.6 |  |  | — |  |  | 575.4 |  |  | — |  |  | 575.4 |  |
| Prepaid expenses and other current assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency forward contracts |  | — |  |  | 0.4 |  |  | — |  |  | 0.4 |  |  | — |  |  | 1.3 |  |  | — |  |  | 1.3 |  |
| Total prepaid expenses and other current assets |  | — |  |  | 0.4 |  |  | — |  |  | 0.4 |  |  | — |  |  | 1.3 |  |  | — |  |  | 1.3 |  |
| Total assets measured at fair value |  | $ | 617.3 |  |  | $ | 2,089.0 |  |  | $ | — |  |  | $ | 2,706.3 |  |  | $ | 369.1 |  |  | $ | 2,504.1 |  |  | $ | — |  |  | $ | 2,873.2 |  |
| Accrued and other liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency forward contracts |  | $ | — |  |  | $ | 2.2 |  |  | $ | — |  |  | $ | 2.2 |  |  | $ | — |  |  | $ | 3.8 |  |  | $ | — |  |  | $ | 3.8 |  |
| Total accrued and other liabilities |  | — |  |  | 2.2 |  |  | — |  |  | 2.2 |  |  | — |  |  | 3.8 |  |  | — |  |  | 3.8 |  |
| Total liabilities measured at fair value |  | $ | — |  |  | $ | 2.2 |  |  | $ | — |  |  | $ | 2.2 |  |  | $ | — |  |  | $ | 3.8 |  |  | $ | — |  |  | $ | 3.8 |  |

[0001327567-19-000038:notes:37]
Refer to Note 9. Debt for the carrying amount and estimated fair value of our convertible senior notes as of October 31, 2019 and July 31, 2019.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001327567-19-000038:notes:38]
Cash Equivalents and Investments
Available-for-sale Debt Securities

[0001327567-19-000038:notes:39]
The following tables summarize the amortized cost, unrealized gains and losses, and fair value of our available-for-sale debt securities as of October 31, 2019 and July 31, 2019 (in millions):

[0001327567-19-000038:notes:40]
|  | October 31, 2019 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 4.0 |  |  | $ | — |  |  | $ | — |  |  | $ | 4.0 |  |
| Commercial paper | 4.5 |  |  | — |  |  | — |  |  | 4.5 |  |
| U.S. government and agency securities | 15.0 |  |  | — |  |  | — |  |  | 15.0 |  |
| Total available-for-sale cash equivalents | $ | 23.5 |  |  | $ | — |  |  | $ | — |  |  | $ | 23.5 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 23.7 |  |  | $ | — |  |  | $ | — |  |  | $ | 23.7 |  |
| Commercial paper | 15.9 |  |  | — |  |  | — |  |  | 15.9 |  |
| Corporate debt securities | 565.2 |  |  | 3.0 |  |  | — |  |  | 568.2 |  |
| U.S. government and agency securities | 1,454.0 |  |  | 3.6 |  |  | (0.3 | ) |  | 1,457.3 |  |
| Total available-for-sale investments | $ | 2,058.8 |  |  | $ | 6.6 |  |  | $ | (0.3 | ) |  | $ | 2,065.1 |  |

[0001327567-19-000038:notes:41]
|  | July 31, 2019 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 12.0 |  |  | $ | — |  |  | $ | — |  |  | $ | 12.0 |  |
| Commercial paper | 19.3 |  |  | — |  |  | — |  |  | 19.3 |  |
| U.S. government and agency securities | 54.4 |  |  | — |  |  | — |  |  | 54.4 |  |
| Total available-for-sale cash equivalents | $ | 85.7 |  |  | $ | — |  |  | $ | — |  |  | $ | 85.7 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 17.5 |  |  | $ | — |  |  | $ | — |  |  | $ | 17.5 |  |
| Commercial paper | 8.9 |  |  | — |  |  | — |  |  | 8.9 |  |
| Corporate debt securities | 587.8 |  |  | 2.3 |  |  | (0.3 | ) |  | 589.8 |  |
| U.S. government and agency securities | 1,799.5 |  |  | 2.6 |  |  | (1.2 | ) |  | 1,800.9 |  |
| Total available-for-sale investments | $ | 2,413.7 |  |  | $ | 4.9 |  |  | $ | (1.5 | ) |  | $ | 2,417.1 |  |

[0001327567-19-000038:notes:42]
Unrealized losses related to these securities are due to interest rate fluctuations as opposed to credit quality. In addition, we do not intend to sell and it is not likely that we would be required to sell these securities before recovery of their amortized cost basis, which may be at maturity. As a result, there were no other-than-temporary impairments for these securities at October 31, 2019 and July 31, 2019.

[0001327567-19-000038:notes:43]
The following table summarizes the amortized cost and fair value of our available-for-sale debt securities as of October 31, 2019, by contractual years-to-maturity (in millions):

[0001327567-19-000038:notes:44]
|  | Amortized Cost |  | Fair Value |
| Due within one year | $ | 1,618.4 |  |  | $ | 1,621.0 |  |
| Due between one and three years | 463.9 |  |  | 467.6 |  |
| Total | $ | 2,082.3 |  |  | $ | 2,088.6 |  |

[0001327567-19-000038:notes:45]
Marketable Equity Securities

[0001327567-19-000038:notes:46]
Marketable equity securities consist of money market funds and are included in cash and cash equivalents in our condensed consolidated balance sheets. As of October 31, 2019 and July 31, 2019, the carrying value of our marketable equity securities were

[0001327567-19-000038:notes:47]
$617.3 million and $369.1 million, respectively. There were no unrealized gains or losses recognized for these securities during the three months ended October 31, 2019 and 2018.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001327567-19-000038:notes:48]
Derivative Instruments
As a global business, we are exposed to currency exchange rate risk. Substantially all of our revenue is transacted in U.S. dollars, however, a portion of our operating expenditures are incurred outside of the United States and are denominated in foreign currencies, making them subject to fluctuations in foreign currency exchange rates. We enter into foreign currency derivative contracts with maturities of 15 months or less, which we designate as cash flow hedges, to manage the foreign currency exchange rate risk associated with these expenditures.

[0001327567-19-000038:notes:49]
[same as prior period, unchanged from 0001327567-19-000016:notes:123]

[0001327567-19-000038:notes:50]
Our derivative financial instruments are recorded at fair value, on a gross basis, as either assets or liabilities in our condensed consolidated balance sheets. Gains or losses related to our cash flow hedges are recorded as a component of accumulated other comprehensive income (loss) (“AOCI”) in our condensed consolidated balance sheets and are reclassified into the financial statement line item associated with the underlying hedged transaction in our condensed consolidated statements of operations when the underlying hedged transaction is recognized in earnings. If it becomes probable that the hedged transaction will not occur, the cumulative unrealized gain or loss is reclassified immediately from AOCI into the financial statement line item associated with the underlying hedged transaction in our condensed consolidated statements of operations. Gains or losses related to non-designated derivative instruments are recognized in other income (expense), net in our condensed consolidated statements of operations for each period until the instrument matures, is terminated, is re-designated as a qualified cash flow hedge, or is sold. Derivatives designated as cash flow hedges are classified in our condensed consolidated statements of cash flows in the same manner as the underlying hedged transaction, primarily within cash flows from operating activities.

[0001327567-19-000038:notes:51]
As of October 31, 2019 and July 31, 2019, the total notional amount of our outstanding foreign currency forward contracts was $233.9 million and $307.2 million, respectively. Refer to Note 3. Fair Value Measurements for the fair value of our derivative instruments as reported on our condensed consolidated balance sheets as of October 31, 2019.

[0001327567-19-000038:notes:52]
During the three months ended October 31, 2019 and 2018, both unrealized gains and losses recognized in AOCI related to our cash flow hedges and amounts reclassified into earnings were not material. Unrealized losses in AOCI related to our cash flow hedges as of October 31, 2019 and 2018 were not material.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001327567-19-000038:notes:53]
Acquisitions
Zingbox, Inc.

[0001327567-19-000038:notes:54]
On September 20, 2019, we completed our acquisition of 100% of the voting equity interest of Zingbox, Inc. (“Zingbox”), a privately-held Internet of Things (“IoT”) security company. We believe the acquisition will accelerate our delivery of IoT security through our Next-Generation Firewall and Cortex platforms. The total purchase consideration for the acquisition of Zingbox was $66.4 million in cash.

[0001327567-19-000038:notes:55]
As part of the acquisition, we issued replacement equity awards with a total fair value of $5.7 million, which will be expensed over the remaining service periods as share-based compensation.

[0001327567-19-000038:notes:56]
[same as prior period, unchanged from 0001327567-19-000016:notes:17]

[0001327567-19-000038:notes:57]
|  | Amount |
| Goodwill | $ | 48.1 |  |
| Identified intangible assets | 20.4 |  |
| Net liabilities assumed | (2.1 | ) |
| Total | $ | 66.4 |  |

[0001327567-19-000038:notes:58]
Goodwill generated from this business combination is primarily attributable to the assembled workforce and expected post-acquisition synergies from integrating Zingbox’s technology into our platforms. The goodwill is not deductible for income tax purposes.

[0001327567-19-000038:notes:59]
[same as prior period, unchanged from 0001327567-19-000016:notes:20]

[0001327567-19-000038:notes:60]
|  | Fair Value |  | Estimated Useful Life |
| Developed technology | $ | 18.6 |  |  | 5 years |
| Customer relationships | 1.8 |  |  | 8 years |
| Total | $ | 20.4 |  |  |  |

[0001327567-19-000038:notes:61]
Zingbox’s operating results are included in our condensed consolidated statements of operations from the date of acquisition. Pro forma results of operations have not been presented because the effect of the acquisition was not material to our condensed consolidated statements of operations.

[0001327567-19-000038:notes:62]
Additional information, such as that related to income tax and other contingencies, existing as of the acquisition date but unknown to us may become known during the remainder of the measurement period, not to exceed 12 months from the acquisition date, which may result in changes to the amounts and allocations recorded.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001327567-19-000038:notes:63]
Goodwill and Intangible Assets
Goodwill

[0001327567-19-000038:notes:64]
The following table presents details of our goodwill during the three months ended October 31, 2019 (in millions):

[0001327567-19-000038:notes:65]
|  | Amount |
| Balance as of July 31, 2019 | $ | 1,352.3 |  |
| Goodwill acquired | 48.1 |  |
| Balance as of October 31, 2019 | $ | 1,400.4 |  |

[0001327567-19-000038:notes:66]
[same as prior period, unchanged from 0001327567-19-000016:notes:169]

[0001327567-19-000038:notes:67]
The following table presents details of our purchased intangible assets as of October 31, 2019 and July 31, 2019 (in millions):

[0001327567-19-000038:notes:68]
|  | October 31, 2019 |  | July 31, 2019 |
|  | Gross Carrying Amount |  | Accumulated Amortization |  | Net Carrying Amount |  | Gross Carrying Amount |  | Accumulated Amortization |  | Net Carrying Amount |
| Intangible assets subject to amortization: |  |  |  |  |  |  |  |  |  |  |  |
| Developed technology | $ | 337.4 |  |  | $ | (93.9 | ) |  | $ | 243.5 |  |  | $ | 318.8 |  |  | $ | (78.7 | ) |  | $ | 240.1 |  |
| Customer relationships | 41.6 |  |  | (6.2 | ) |  | 35.4 |  |  | 39.8 |  |  | (4.7 | ) |  | 35.1 |  |
| Acquired intellectual property | 8.9 |  |  | (5.3 | ) |  | 3.6 |  |  | 8.9 |  |  | (5.1 | ) |  | 3.8 |  |
| Trade name and trademarks | 9.4 |  |  | (9.4 | ) |  | — |  |  | 9.4 |  |  | (9.4 | ) |  | — |  |
| Other | 2.2 |  |  | (2.2 | ) |  | — |  |  | 2.2 |  |  | (2.2 | ) |  | — |  |
| Total intangible assets subject to amortization | 399.5 |  |  | (117.0 | ) |  | 282.5 |  |  | 379.1 |  |  | (100.1 | ) |  | 279.0 |  |
| Intangible assets not subject to amortization: |  |  |  |  |  |  |  |  |  |  |  |
| In-process research and development | 1.6 |  |  | — |  |  | 1.6 |  |  | 1.6 |  |  | — |  |  | 1.6 |  |
| Total purchased intangible assets | $ | 401.1 |  |  | $ | (117.0 | ) |  | $ | 284.1 |  |  | $ | 380.7 |  |  | $ | (100.1 | ) |  | $ | 280.6 |  |

[0001327567-19-000038:notes:69]
We recognized amortization expense of $16.9 million and $9.4 million for the three months ended October 31, 2019 and 2018, respectively.

[0001327567-19-000038:notes:70]
The following table summarizes estimated future amortization expense of our intangible assets as of October 31, 2019 (in millions):

[0001327567-19-000038:notes:71]
|  | Amount |
| Fiscal years ending July 31: |  |
| Remaining 2020 | $ | 52.5 |  |
| 2021 | 68.0 |  |
| 2022 | 63.5 |  |
| 2023 | 37.6 |  |
| 2024 | 30.1 |  |
| 2025 and thereafter | 30.8 |  |
| Total future amortization expense | $ | 282.5 |  |


## us-gaap:DebtDisclosureTextBlock

[0001327567-19-000038:notes:72]
Debt
Convertible Senior Notes

[0001327567-19-000038:notes:73]
In June 2014, we issued $575.0 million aggregate principal amount of 0.0% Convertible Senior Notes due 2019 (the “2019 Notes”), and in July 2018, we issued $1.7 billion aggregate principal amount of 0.75% Convertible Senior Notes due 2023 (the “2023 Notes” and, together with the 2019 Notes, the “Notes”). The 2023 Notes bear interest at a fixed rate of 0.75% per year, payable semi-annually in arrears on January 1 and July 1 of each year, beginning on January 1, 2019. The 2023 Notes are governed by an indenture between us, as the issuer, and U.S. Bank National Association, as Trustee (the “Indenture”). The 2023 Notes are unsecured, unsubordinated obligations and the Indenture governing the 2023 Notes does not contain any financial covenants or restrictions on the payments of dividends, the incurrence of indebtedness, or the issuance or repurchase of securities by us or any of our subsidiaries. The 2019 Notes were converted prior to or settled on the maturity date of July 1, 2019, in accordance with their terms. The 2023 Notes mature on July 1, 2023. We cannot redeem the 2023 Notes prior to maturity.

[0001327567-19-000038:notes:74]
The 2023 Notes are convertible for up to 6.4 million shares of our common stock at an initial conversion rate of approximately 3.7545 shares of common stock per $1,000 principal amount, which is equal to an initial conversion price of approximately $266.35 per share of common stock, subject to adjustments. Holders of the 2023 Notes may surrender their 2023 Notes for conversion at their option at any time prior to the close of business on the business day immediately preceding April 1, 2023, only under the following circumstances:

[0001327567-19-000038:notes:75]
| • | during any fiscal quarter commencing after the fiscal quarter ending on October 31, 2018 (and only during such fiscal quarter), if the last reported sale price of our common stock for at least 20 trading days (whether or not consecutive) during a period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the applicable conversion price for the 2023 Notes on each applicable trading day (the “sale price condition”); |

[0001327567-19-000038:notes:76]
| • | during the five business day period after any five consecutive trading day period (the “measurement period”), in which the trading price per $1,000 principal amount of the 2023 Notes for each trading day of the measurement period was less than 98% of the product of the last reported sale price of our common stock and the applicable conversion rate for the 2023 Notes on each such trading day; or |

[0001327567-19-000038:notes:77]
| • | upon the occurrence of specified corporate events. |

[0001327567-19-000038:notes:78]
On or after April 1, 2023, holders may surrender all or any portion of their 2023 Notes for conversion at any time prior to the close of business on the second scheduled trading day immediately preceding the maturity date regardless of the foregoing conditions, and such conversions will be settled upon the maturity date. Upon conversion, holders of the 2023 Notes will receive cash equal to the aggregate principal amount of the 2023 Notes to be converted, and, at our election, cash and/or shares of our common stock for any amounts in excess of the aggregate principal amount of the 2023 Notes being converted.

[0001327567-19-000038:notes:79]
The conversion price will be subject to adjustment in some events. Holders who convert their 2023 Notes in connection with certain corporate events that constitute a “make-whole fundamental change” under the Indenture are, under certain circumstances, entitled to an increase in the conversion rate. Additionally, upon the occurrence of a corporate event that constitutes a “fundamental change” under the Indenture, holders of the 2023 Notes may require us to repurchase for cash all or a portion of the 2023 Notes at a repurchase price equal to 100% of the principal amount of the 2023 Notes plus accrued and unpaid interest to, but excluding, the fundamental change repurchase date.

[0001327567-19-000038:notes:80]
The sale price condition was not met for the 2023 Notes during the fiscal quarters ended October 31, 2019 or July 31, 2019. Since the 2023 Notes were not convertible, the net carrying amount of the 2023 Notes was classified as a long-term liability and the equity component was included in additional paid-in capital in our condensed consolidated balance sheets as of October 31, 2019 and July 31, 2019. As of October 31, 2019, all of the 2023 Notes remained outstanding.

[0001327567-19-000038:notes:81]
The following table sets forth the components of the 2023 Notes as of October 31, 2019 and July 31, 2019 (in millions):

[0001327567-19-000038:notes:82]
|  | October 31, 2019 |  | July 31, 2019 |
| Liability component: |  |  |  |
| Principal | $ | 1,693.0 |  |  | $ | 1,693.0 |  |
| Less: debt discount and debt issuance costs, net of amortization | 247.5 |  |  | 263.0 |  |
| Net carrying amount | $ | 1,445.5 |  |  | $ | 1,430.0 |  |
| Equity component | $ | 315.0 |  |  | $ | 315.0 |  |

[0001327567-19-000038:notes:83]
The total estimated fair value of the 2023 Notes was $1.9 billion at both October 31, 2019 and July 31, 2019. The fair value was determined based on the closing trading price per $100 of the 2023 Notes as of the last day of trading for the period. We consider the fair value of the 2023 Notes at October 31, 2019 and July 31, 2019 to be a Level 2 measurement. The fair value of the 2023 Notes is primarily affected by the trading price of our common stock and market interest rates. Based on the closing price of our common stock on October 31, 2019, the if-converted value of the 2023 Notes was less than its principal amount.

[0001327567-19-000038:notes:84]
The following table sets forth interest expense recognized related to the Notes (dollars in millions):

[0001327567-19-000038:notes:85]
|  | Three Months Ended October 31, |
|  | 2019 |  | 2018 |
|  | 2019 Notes |  | 2023 Notes |  | Total |  | 2019 Notes |  | 2023 Notes |  | Total |
| Contractual interest expense | $ | — |  |  | $ | 3.2 |  |  | $ | 3.2 |  |  | $ | — |  |  | $ | 3.2 |  |  | $ | 3.2 |  |
| Amortization of debt discount | — |  |  | 15.0 |  |  | 15.0 |  |  | 4.0 |  |  | 14.4 |  |  | 18.4 |  |
| Amortization of debt issuance costs | — |  |  | 0.5 |  |  | 0.5 |  |  | 0.5 |  |  | 0.5 |  |  | 1.0 |  |
| Total interest expense recognized | $ | — |  |  | $ | 18.7 |  |  | $ | 18.7 |  |  | $ | 4.5 |  |  | $ | 18.1 |  |  | $ | 22.6 |  |
| Effective interest rate of the liability component | — | % |  | 5.2 | % |  |  |  | 4.8 | % |  | 5.2 | % |  |  |

[0001327567-19-000038:notes:86]
Note Hedges

[0001327567-19-000038:notes:87]
To minimize the impact of potential economic dilution upon conversion of the Notes, we entered into separate convertible note hedge transactions (the “2019 Note Hedges,” with respect to the 2019 Notes, and the “2023 Note Hedges,” with respect to the 2023 Notes, and collectively, the “Note Hedges”) with respect to our common stock concurrent with the issuance of each series of Notes.

[0001327567-19-000038:notes:88]
Upon the settlement of the 2019 Notes, we exercised the corresponding portion of our 2019 Note Hedges during the year ended July 31, 2019 and received shares of our common stock that fully offset the shares issued in excess of the principal amount of the converted 2019 Notes. The 2019 Note Hedges expired upon maturity of the 2019 Notes.

[0001327567-19-000038:notes:89]
The 2023 Note Hedges cover up to 6.4 million shares of our common stock at a strike price per share that corresponds to the initial applicable conversion price of the 2023 Notes, which are also subject to adjustment, and are exercisable upon conversion of the 2023 Notes. The 2023 Note Hedges will expire upon maturity of the 2023 Notes. The 2023 Note Hedges are separate transactions and

[0001327567-19-000038:notes:90]
are not part of the terms of 2023 Notes. Holders of the 2023 Notes will not have any rights with respect to the 2023 Note Hedges. Any shares of our common stock receivable by us under the 2023 Note Hedges are excluded from the calculation of diluted earnings per share as they are antidilutive. We paid an aggregate amount of $332.0 million for the 2023 Note Hedges, which is included in additional paid-in capital in our consolidated balance sheets.

[0001327567-19-000038:notes:91]
Warrants

[0001327567-19-000038:notes:92]
Separately, but concurrently with the issuance of each series of Notes, we entered into transactions whereby we sold warrants (the “2019 Warrants,” with respect to the 2019 Notes, and the “2023 Warrants,” with respect to the 2023 Notes, and collectively, the “Warrants”) to acquire shares of our common stock, subject to anti-dilution adjustments. The 2019 Warrants became exercisable beginning October 2019 and the 2023 Warrants are exercisable beginning October 2023.

[0001327567-19-000038:notes:93]
The following table presents details of the Warrants (in millions, except per share data):

[0001327567-19-000038:notes:94]
|  | Initial Number of Shares |  | Strike Price per Share |  | Aggregate Proceeds |
| 2019 Warrants | 5.2 |  |  | $ | 137.85 |  |  | $ | 78.3 |  |
| 2023 Warrants | 6.4 |  |  | $ | 417.80 |  |  | $ | 145.4 |  |

[0001327567-19-000038:notes:95]
The shares issuable under the Warrants will be included in the calculation of diluted earnings per share when the average market value per share of our common stock for the reporting period exceeds the applicable strike price for such series of Warrants. The Warrants are separate transactions and are not part of either series of Notes or Note Hedges and are not remeasured through earnings each reporting period. Holders of the Notes of either series will not have any rights with respect to the Warrants. The aggregate proceeds received from the sale of the Warrants are included in additional paid-in capital in our consolidated balance sheets.

[0001327567-19-000038:notes:96]
During the three months ended October 31, 2019, we net settled the 2019 Warrants exercised with 0.7 million shares or $153.6 million in fair value of our common stock. The number of net shares issued was determined based on the number of 2019 Warrants exercised multiplied by the difference between the strike price of the 2019 Warrants and their daily volume weighted-average stock price. As of October 31, 2019, up to 3.2 million shares of our common stock were issuable for gross settlement under the remaining outstanding 2019 Warrants, which will be net settled when exercised through the end of December 2019.

[0001327567-19-000038:notes:97]
Revolving Credit Facility

[0001327567-19-000038:notes:98]
On September 4, 2018, we entered into a credit agreement (the “Credit Agreement”) with certain institutional lenders that provides for a $400.0 million unsecured revolving credit facility (the “Credit Facility”), with an option to increase the amount of the Credit Facility by up to an additional $350.0 million, subject to certain conditions. The Credit Facility matures on the earlier of (i) September 4, 2023 and (ii) the date that is 91 days prior to the stated maturity of our 2023 Notes if (a) any of the 2023 Notes are still outstanding and (b) our unrestricted cash and cash equivalents are less than the then outstanding principal amount of our 2023 Notes plus $400.0 million.

[0001327567-19-000038:notes:99]
The borrowings under the Credit Facility bear interest, at our option, at a base rate plus a spread of 0.00% to 0.75%, or an adjusted LIBO rate plus a spread of 1.00% to 1.75%, in each case with such spread being determined based on our leverage ratio. We are obligated to pay an ongoing commitment fee on undrawn amounts at a rate of 0.125% to 0.250%, depending on our leverage ratio. As of October 31, 2019, there were no amounts outstanding and we were in compliance with all covenants under the Credit Agreement.


## us-gaap:LesseeOperatingLeasesTextBlock

[0001327567-19-000038:notes:100]
Leases
We determine if an arrangement is a lease at inception. We evaluate classification of leases at commencement and, as necessary, at modification. Operating leases are included in operating lease right-of-use assets, accrued and other liabilities, and long-term operating lease liabilities on our condensed consolidated balance sheets beginning August 1, 2019. We did not have any material finance leases in any of the periods presented.

[0001327567-19-000038:notes:101]
Operating lease right-of-use assets represent our right to use an underlying asset for the lease term. Operating lease liabilities represent our obligation to make payments arising from the lease. Operating lease right-of-use assets and liabilities are recognized at the present value of the future lease payments at the lease commencement date. The interest rate used to determine the present value of the future lease payments is our incremental borrowing rate, because the interest rates implicit in most of our leases are not readily determinable. Our incremental borrowing rate is estimated to approximate the interest rate on a collateralized basis with similar terms and payments, and in economic environments where the leased asset is located. Operating lease right-of-use assets also include adjustments related to lease incentives, prepaid or accrued rent and initial direct lease costs. Operating lease right-of-use assets are subject to evaluation for impairment or disposal on a basis consistent with other long-lived assets.

[0001327567-19-000038:notes:102]
Our lease terms may include periods under options to extend or terminate the lease when it is reasonably certain that we will exercise that option. We generally use the base, non-cancelable lease term when determining the lease assets and liabilities. Operating lease cost is generally recognized on a straight-line basis over the lease term.

[0001327567-19-000038:notes:103]
We account for lease and non-lease components as a single lease component and do not recognize right-of-use assets and lease liabilities for leases with a term of 12 months or less. Payments under our lease arrangements are primarily fixed, however, certain lease agreements contain variable payments, which are expensed as incurred and not included in the operating lease right-of-use assets and liabilities. Variable lease payments are primarily comprised of payments affected by the Consumer Price Index, common area maintenance, and utility charges.

[0001327567-19-000038:notes:104]
We have entered into various non-cancelable operating leases primarily for our facilities with original lease periods expiring through the year ending July 31, 2028.

[0001327567-19-000038:notes:105]
During the three months ended October 31, 2019, our net cost for operating leases was $16.8 million and primarily consisted of operating lease costs of $14.7 million. During the three months ended October 31, 2019, variable lease costs, short-term lease costs, and sublease income were not material.

[0001327567-19-000038:notes:106]
The following tables present additional information for our operating leases (in millions, except for years and percentages):

[0001327567-19-000038:notes:107]
|  | Three Months Ended |
|  | October 31, 2019 |
| Operating cash flows used in payments of operating lease liabilities | $ | 10.5 |  |
| Right-of-use assets obtained in exchange for new operating lease liabilities | $ | 6.5 |  |
|  | October 31, 2019 |
| Weighted-average remaining lease term | 7.5 |  |
| Weighted-average discount rate | 3.9 | % |

[0001327567-19-000038:notes:108]
The following table presents maturities of operating lease liabilities as of October 31, 2019 (in millions):

[0001327567-19-000038:notes:109]
|  | Amount |
| Fiscal years ending July 31: |  |
| Remaining 2020 | $ | 58.7 |  |
| 2021 | 73.8 |  |
| 2022 | 68.4 |  |
| 2023 | 63.0 |  |
| 2024 | 48.0 |  |
| 2025 and thereafter | 190.7 |  |
| Total operating lease payments | 502.6 |  |
| Less: imputed interest | 69.2 |  |
| Present value of operating lease liabilities | $ | 433.4 |  |
| Current portion of operating lease liabilities(1) | $ | 61.8 |  |
| Long-term operating lease liabilities | $ | 371.6 |  |

[0001327567-19-000038:notes:110]
______________

[0001327567-19-000038:notes:111]
| (1) | Current portion of operating lease liabilities is included in accrued and other liabilities on our condensed consolidated balance sheet. |

[0001327567-19-000038:notes:112]
Operating lease liabilities above do not include sublease income. As of October 31, 2019, we expect to receive sublease income of approximately $7.7 million, which consists of $4.0 million to be received for the remainder of fiscal 2020 and $3.7 million to be received in fiscal 2021.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001327567-19-000038:notes:113]
Commitments and Contingencies
Purchase Commitments

[0001327567-19-000038:notes:114]
Manufacturing Purchase Commitments

[0001327567-19-000038:notes:115]
Our electronics manufacturing service provider (“EMS provider”) procures components and assembles our products based on our forecasts. These forecasts are based on estimates of demand for our products primarily for the next 12 months, which are in turn based on historical trends and an analysis from our sales and product management organizations, adjusted for overall market conditions. In order to reduce manufacturing lead times and plan for adequate supply, we may issue non-cancelable orders for products and components to our manufacturing partners or component suppliers. As of October 31, 2019, our purchase commitments under such orders were $106.7 million, excluding obligations under contracts that we can cancel without a significant penalty.

[0001327567-19-000038:notes:116]
Other Purchase Commitments

[0001327567-19-000038:notes:117]
We have entered into various non-cancelable agreements with third-party providers for our use of certain cloud and other services, under which we are committed to minimum or fixed purchases through the year ending July 31, 2026. The following table presents details of the aggregate future non-cancelable purchase commitments under these agreements as of October 31, 2019 (in millions):

[0001327567-19-000038:notes:118]
|  | Amount |
| Fiscal years ending July 31: |  |
| Remaining 2020 | $ | — |  |
| 2021 | 19.0 |  |
| 2022 | 55.9 |  |
| 2023 | 57.5 |  |
| 2024 | 67.5 |  |
| 2025 and thereafter | 97.5 |  |
| Total other purchase commitments | $ | 297.4 |  |

[0001327567-19-000038:notes:119]
Litigation

[0001327567-19-000038:notes:120]
We are subject to legal proceedings, claims, and litigation arising in the ordinary course of business, including intellectual property litigation. Such matters are subject to many uncertainties and outcomes are not predictable with assurance. We accrue for contingencies when we believe that a loss is probable and that we can reasonably estimate the amount of any such loss.

[0001327567-19-000038:notes:121]
To the extent there is a reasonable possibility that a loss exceeding amounts already recognized may be incurred and the amount of such additional loss would be material, we will either disclose the estimated additional loss or state that such an estimate cannot be made. As of October 31, 2019, we have not recorded any significant accruals for loss contingencies associated with such legal proceedings, determined that an unfavorable outcome is probable or reasonably possible, or determined that the amount or range of any possible loss is reasonably estimable.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001327567-19-000038:notes:122]
Stockholders’ Equity
Share Repurchase Program

[0001327567-19-000038:notes:123]
In February 2019, our board of directors authorized a $1.0 billion share repurchase program which is funded from available working capital. Repurchases may be made at management’s discretion from time to time on the open market, through privately negotiated transactions, transactions structured through investment banking institutions, block purchase techniques, 10b5-1 trading plans, or a combination of the foregoing. This repurchase authorization will expire on December 31, 2020, and may be suspended or discontinued at any time.

[0001327567-19-000038:notes:124]
During the three months ended October 31, 2019, we repurchased and retired 0.9 million shares of our common stock under the authorization for an aggregate purchase price of $198.1 million, including transaction costs. The total price of the shares repurchased and related transaction costs are reflected as a reduction to common stock and additional paid-in capital on our condensed consolidated balance sheets. As of October 31, 2019, $801.9 million remained available for future share repurchases under our current repurchase authorization.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001327567-19-000038:notes:125]
Equity Award Plans
Assumed Share-based Compensation Plans

[0001327567-19-000038:notes:126]
Zingbox, Inc. Stock Incentive Plan

[0001327567-19-000038:notes:127]
In connection with our acquisition of Zingbox on September 20, 2019, we assumed Zingbox’s Stock Incentive Plan, as amended and restated (the “Zingbox Plan”), under which the assumed Zingbox equity awards were granted. The assumed equity awards will be settled in shares of our common stock and will retain the terms and conditions under which they were originally granted; forfeited awards will not be returned to the Zingbox Plan. No additional equity awards will be granted under the Zingbox Plan. Refer to Note 6. Acquisitions for more information on the Zingbox acquisition and the related equity awards assumed.

[0001327567-19-000038:notes:128]
[same as prior period, unchanged from 0001327567-19-000016:notes:133]

[0001327567-19-000038:notes:129]
[same as prior period, unchanged from 0001327567-19-000016:notes:134]

[0001327567-19-000038:notes:130]
|  | Stock Options Outstanding |  | PSOs Outstanding |
|  | Number of Shares |  | Weighted-Average Exercise Price Per Share |  | Weighted-Average Remaining Contractual Term(Years) |  | Aggregate Intrinsic Value |  | Number of Shares |  | Weighted-Average Exercise Price Per Share |  | Weighted-Average Remaining Contractual Term(Years) |  | Aggregate Intrinsic Value |
| Balance—July 31, 2019 | 0.3 |  |  | $ | 14.53 |  |  | 2.2 |  | $ | 81.4 |  |  | 3.7 |  |  | $ | 193.99 |  |  | 6.2 |  | $ | 120.1 |  |
| Exercised | (0.1 | ) |  | $ | 11.02 |  |  |  |  |  |  | — |  |  | $ | — |  |  |  |  |  |
| Forfeited | — |  |  | $ | — |  |  |  |  |  |  | (0.7 | ) |  | $ | 193.51 |  |  |  |  |  |
| Balance—October 31, 2019 | 0.2 |  |  | $ | 15.79 |  |  | 2.1 |  | $ | 59.7 |  |  | 3.0 |  |  | $ | 194.09 |  |  | 6.0 |  | $ | 100.5 |  |
| Exercisable—October 31, 2019 | 0.2 |  |  | $ | 15.79 |  |  | 2.1 |  | $ | 59.7 |  |  | 3.0 |  |  | $ | 194.09 |  |  | 6.0 |  | $ | 100.5 |  |

[0001327567-19-000038:notes:131]
[same as prior period, unchanged from 0001327567-19-000016:notes:140]

[0001327567-19-000038:notes:132]
The following table summarizes the RSA and PSA activity under our stock plans during the reporting period (in millions, except per share amounts):

[0001327567-19-000038:notes:133]
|  | RSAs Outstanding |  | PSAs Outstanding |
|  | Number of Shares |  | Weighted-Average Grant-Date Fair Value Per Share |  | Number of Shares |  | Weighted-Average Grant-Date Fair Value Per Share |
| Balance—July 31, 2019 | — |  |  | $ | 148.54 |  |  | 0.1 |  |  | $ | 148.54 |  |
| Vested | — |  |  | $ | 148.54 |  |  | — |  |  | $ | 148.54 |  |
| Balance—October 31, 2019 | — |  |  | $ | 148.54 |  |  | 0.1 |  |  | $ | 148.54 |  |

[0001327567-19-000038:notes:134]
The following table summarizes the RSU and PSU activity under our stock plans during the reporting period (in millions, except per share amounts):

[0001327567-19-000038:notes:135]
|  | RSUs Outstanding |  | PSUs Outstanding |
|  | Number of Shares |  | Weighted-Average Grant-Date Fair Value Per Share |  | Weighted-Average Remaining Contractual Term(Years) |  | Aggregate Intrinsic Value |  | Number of Shares |  | Weighted-Average Grant-Date Fair Value Per Share |  | Weighted-Average Remaining Contractual Term(Years) |  | Aggregate Intrinsic Value |
| Balance—July 31, 2019 | 6.9 |  |  | $ | 188.16 |  |  | 1.5 |  | $ | 1,554.0 |  |  | 0.3 |  |  | $ | 197.86 |  |  | 1.8 |  | $ | 67.0 |  |
| Granted | 1.5 |  |  | $ | 211.17 |  |  |  |  |  |  | — |  |  | $ | — |  |  |  |  |  |
| Vested | (0.6 | ) |  | $ | 173.42 |  |  |  |  |  |  | — |  |  | $ | 174.62 |  |  |  |  |  |
| Forfeited | (0.3 | ) |  | $ | 173.93 |  |  |  |  |  |  | (0.1 | ) |  | $ | 181.48 |  |  |  |  |  |
| Balance—October 31, 2019 | 7.5 |  |  | $ | 194.47 |  |  | 1.5 |  | $ | 1,712.1 |  |  | 0.2 |  |  | $ | 199.23 |  |  | 1.7 |  | $ | 53.6 |  |

[0001327567-19-000038:notes:136]
Our PSAs and PSUs generally vest over a period of three to four years from the date of grant. The actual number of PSAs and PSUs earned and eligible to vest is determined based on level of achievement against pre-established billings or revenue growth

[0001327567-19-000038:notes:137]
targets for the fiscal year. We recognize share-based compensation expense for our PSAs and PSUs on a straight-line basis over the requisite service period for each separately vesting portion of the award when it is probable that the performance condition will be achieved.

[0001327567-19-000038:notes:138]
[same as prior period, unchanged from 0001327567-19-000016:notes:146]

[0001327567-19-000038:notes:139]
[same as prior period, unchanged from 0001327567-19-000016:notes:147]

[0001327567-19-000038:notes:140]
|  | Three Months Ended |
|  | October 31, |
|  | 2019 |  | 2018 |
| Cost of product revenue | $ | 1.3 |  |  | $ | 1.6 |  |
| Cost of subscription and support revenue | 18.9 |  |  | 17.5 |  |
| Research and development | 62.4 |  |  | 40.5 |  |
| Sales and marketing | 43.8 |  |  | 56.0 |  |
| General and administrative | 24.8 |  |  | 35.5 |  |
| Total share-based compensation | $ | 151.2 |  |  | $ | 151.1 |  |

[0001327567-19-000038:notes:141]
As of October 31, 2019, total compensation cost related to unvested share-based awards not yet recognized was $1.6 billion. This cost is expected to be amortized over a weighted-average period of approximately 2.8 years. Future grants will increase the amount of compensation expense to be recorded in these periods.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001327567-19-000038:notes:142]
Income Taxes
Our provision for income taxes for the three months ended October 31, 2019 reflects an effective tax rate of negative 9.4%. Our effective tax rate for the three months ended October 31, 2019 was negative as we recorded a provision for income taxes on year to date losses. The provision for income taxes for the three months ended October 31, 2019 is primarily due to income taxes in profitable foreign jurisdictions, U.S. state taxes, and withholding taxes. Our effective tax rate differs from the U.S. statutory tax rate primarily due to deductibility of our share-based compensation, foreign income at other than U.S. tax rates, and changes in our valuation allowance.

[0001327567-19-000038:notes:143]
Our provision for income taxes for the three months ended October 31, 2018 reflects an effective tax rate of 8.4%. Our effective tax rate for the three months ended October 31, 2018 was positive as we recorded a benefit from income taxes on year to date losses. The key components of our income tax provision, excluding one-time items, primarily consisted of foreign income taxes and withholding taxes. During the three months ended October 31, 2018, the effect of these key components was fully offset by a one-time tax benefit of $9.4 million from a partial release of our valuation allowance related to the acquisition of RedLock Inc. Our effective tax rate differed from the U.S. statutory tax rate primarily due to deductibility of our share-based compensation, foreign income at other than U.S. tax rates, and changes in our valuation allowance.


## us-gaap:EarningsPerShareTextBlock

[0001327567-19-000038:notes:144]
Net Loss Per Share
Basic net loss per share is computed by dividing net loss by basic weighted-average shares outstanding during the period. Diluted net loss per share is computed by dividing net loss by diluted weighted-average shares outstanding, including potentially dilutive securities.

[0001327567-19-000038:notes:145]
[same as prior period, unchanged from 0001327567-19-000016:notes:153]

[0001327567-19-000038:notes:146]
|  | Three Months Ended |
|  | October 31, |
|  | 2019 |  | 2018 |
| Net loss | $ | (59.6 | ) |  | $ | (38.3 | ) |
| Weighted-average shares used to compute net loss per share, basic and diluted | 96.6 |  |  | 93.8 |  |
| Net loss per share, basic and diluted | $ | (0.62 | ) |  | $ | (0.41 | ) |

[0001327567-19-000038:notes:147]
[same as prior period, unchanged from 0001327567-19-000016:notes:155]

[0001327567-19-000038:notes:148]
|  | Three Months Ended |
|  | October 31, |
|  | 2019 |  | 2018 |
| Convertible senior notes | 6.4 |  |  | 8.6 |  |
| Warrants related to the issuance of convertible senior notes | 9.6 |  |  | 11.6 |  |
| RSUs and PSUs | 7.7 |  |  | 7.5 |  |
| Options to purchase common stock, including PSOs | 3.2 |  |  | 4.2 |  |
| RSAs and PSAs | 0.1 |  |  | 0.2 |  |
| ESPP shares | 0.1 |  |  | 0.1 |  |
| Total | 27.1 |  |  | 32.2 |  |


## us-gaap:OtherNonoperatingIncomeAndExpenseTextBlock

[0001327567-19-000038:notes:149]
Other Income, Net
The following table sets forth the components of other income, net (in millions):

[0001327567-19-000038:notes:150]
|  | Three Months Ended |
|  | October 31, |
|  | 2019 |  | 2018 |
| Interest income | $ | 15.8 |  |  | $ | 15.4 |  |
| Foreign currency exchange gains (losses), net | 0.4 |  |  | — |  |
| Other | — |  |  | (2.4 | ) |
| Total other income, net | $ | 16.2 |  |  | $ | 13.0 |  |


## us-gaap:SubsequentEventsTextBlock

[0001327567-19-000038:notes:151]
Subsequent Event
Business Combination

[0001327567-19-000038:notes:152]
In November 2019, we entered into a definitive agreement to acquire Aporeto, Inc., a privately-held company, for total consideration of approximately $150.0 million in cash, subject to adjustment. We expect the acquisition will strengthen our Cloud-Native Security Platform capabilities delivered by Prisma Cloud. The acquisition is expected to close during our second quarter of fiscal 2020.
