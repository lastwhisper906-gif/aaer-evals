# PANW note change history — 0001327567-19-000016 → 0001327567-19-000038


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2019-11-26):
[0001327567-19-000038:note_history:1]
Commitments and Contingencies
Purchase Commitments
  (was, 2019-05-30, similarity 0.7342):
[0001327567-19-000016:note_history:1]
Commitments and Contingencies

- changed (2019-11-26):
[0001327567-19-000038:note_history:2]
Our electronics manufacturing service provider (“EMS provider”) procures components and assembles our products based on our forecasts. These forecasts are based on estimates of demand for our products primarily for the next 12 months, which are in turn based on historical trends and an analysis from our sales and product management organizations, adjusted for overall market conditions. In order to reduce manufacturing lead times and plan for adequate supply, we may issue non-cancelable orders for products and components to our manufacturing partners or component suppliers. As of October 31, 2019, our purchase commitments under such orders were $106.7 million, excluding obligations under contracts that we can cancel without a significant penalty.
  (was, 2019-05-30, similarity 0.9919):
[0001327567-19-000016:note_history:2]
Our electronics manufacturing service provider (“EMS provider”) procures components and assembles our products based on our forecasts. These forecasts are based on estimates of demand for our products primarily for the next 12 months, which are in turn based on historical trends and an analysis from our sales and product management organizations, adjusted for overall market conditions. In order to reduce manufacturing lead times and plan for adequate supply, we may issue non-cancelable orders for products and components to our manufacturing partners or component suppliers. As of April 30, 2019, our purchase commitments under such orders were $129.3 million, excluding obligations under contracts that we can cancel without a significant penalty.

- changed (2019-11-26):
[0001327567-19-000038:note_history:3]
We have entered into various non-cancelable agreements with third-party providers for our use of certain cloud and other services, under which we are committed to minimum or fixed purchases through the year ending July 31, 2026. The following table presents details of the aggregate future non-cancelable purchase commitments under these agreements as of October 31, 2019 (in millions):
  (was, 2019-05-30, similarity 0.9575):
[0001327567-19-000016:note_history:3]
We have entered into various non-cancelable agreements with third-party providers for our use of certain cloud services, under which we are committed to minimum purchases through the year ending July 31, 2026. The following table presents details of the aggregate future non-cancelable purchase commitments under these agreements as of April 30, 2019 (in millions):

- changed (2019-11-26):
[0001327567-19-000038:note_history:4]
To the extent there is a reasonable possibility that a loss exceeding amounts already recognized may be incurred and the amount of such additional loss would be material, we will either disclose the estimated additional loss or state that such an estimate cannot be made. As of October 31, 2019, we have not recorded any significant accruals for loss contingencies associated with such legal proceedings, determined that an unfavorable outcome is probable or reasonably possible, or determined that the amount or range of any possible loss is reasonably estimable.
  (was, 2019-05-30, similarity 0.9892):
[0001327567-19-000016:note_history:4]
To the extent there is a reasonable possibility that a loss exceeding amounts already recognized may be incurred and the amount of such additional loss would be material, we will either disclose the estimated additional loss or state that such an estimate cannot be made. As of April 30, 2019, we have not recorded any significant accruals for loss contingencies associated with such legal proceedings, determined that an unfavorable outcome is probable or reasonably possible, or determined that the amount or range of any possible loss is reasonably estimable.

- removed (2019-11-26):
[0001327567-19-000016:note_history:5]
Leases

- removed (2019-11-26):
[0001327567-19-000016:note_history:6]
We lease our facilities under various non-cancelable operating leases, which expire through the year ending July 31, 2028.

- removed (2019-11-26):
[0001327567-19-000016:note_history:7]
In May 2015 and October 2015, we entered into a total of three lease agreements for approximately 941,000 square feet of corporate office space in Santa Clara, California, which serves as our new corporate headquarters. The leases contain rent holiday periods, scheduled rent increases, lease incentives, and renewal options which allow the lease terms to be extended beyond their expiration dates of July 2028 through July 2046. In September 2017, per the terms of the lease agreements, the landlords exercised their option to amend our lease payment schedules and eliminate our rent holiday periods, which increased our rental payments by $24.4 million, $11.8 million, and $2.0 million for fiscal 2018, 2019, and 2020, respectively. In exchange, we received an upfront cash reimbursement of $38.2 million during the three months ended October 31, 2017, which we have applied and will apply against the future additional rental payments when due. As amended, rental payments under the three lease agreements are approximately $412.0 million over the lease term.

- removed (2019-11-26):
[0001327567-19-000016:note_history:8]
In May 2015, we also entered into a lease agreement for approximately 122,000 square feet of space in Santa Clara, California, to serve as an extension of our previous corporate headquarters. The lease contains scheduled rent increases, lease incentives, and renewal options which allow the lease term to be extended beyond the expiration date of April 2021 through July 2046. Rental payments under the lease agreement are approximately $23.1 million over the lease term. In December 2017, we entered into an agreement to sublease this office space for the remaining lease term. Proceeds from this sublease will be approximately $16.3 million over the sublease term.

- removed (2019-11-26):
[0001327567-19-000016:note_history:9]
In September 2012, we entered into two lease agreements for a total of approximately 300,000 square feet of space in Santa Clara, California, which served as our previous corporate headquarters through August 2017, when we relocated to our new corporate campus. The leases contain rent holiday periods and two separate five-year options to extend the lease term beyond their expiration dates of July 2023. Rental payments under these lease agreements are approximately $94.3 million over the lease term. In August 2017, we exited our previous corporate headquarter facilities and relocated to our new corporate campus, which resulted in the recognition of a cease-use loss of $39.2 million during the year ended July 31, 2018. Due to changes in market conditions in recent months, and the resulting changes to the amount and timing of estimated cash flows from sublease rentals that could be reasonably obtained, we recognized an additional cease-use loss of $4.1 million as general and administrative expense in our condensed consolidated statements of operations during the three and nine months ended April 30, 2019, and a corresponding liability in our condensed consolidated balance sheets. During the three and nine months ended April 30, 2019, we released $2.6 million and $7.6 million, respectively, of the cease-use liability through rental payments. As of April 30, 2019 and July 31, 2018, the remaining balance of the cease-use liability was $25.6 million and $29.1 million, respectively, which is expected to be paid through the end of the lease term in July 2023.

- removed (2019-11-26):
[0001327567-19-000016:note_history:10]
The following table presents details of the aggregate future non-cancelable minimum rental payments under our operating leases as of April 30, 2019 (in millions):

- removed (2019-11-26):
[0001327567-19-000016:note_history:11]
|  | Amount |
| Fiscal years ending July 31: |  |
| Remaining 2019 | $ | 17.8 |  |
| 2020 | 73.2 |  |

- removed (2019-11-26):
[0001327567-19-000016:note_history:12]
| 2021 | 67.2 |  |
| 2022 | 63.0 |  |
| 2023 | 60.1 |  |
| 2024 and thereafter | 227.7 |  |
| Committed gross lease payments | 509.0 |  |
| Less: proceeds from sublease rentals | 11.2 |  |
| Net operating lease obligation | $ | 497.8 |  |

- removed (2019-11-26):
[0001327567-19-000016:note_history:13]
Purchase Commitments


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2019-11-26):
[0001327567-19-000038:note_history:14]
Description of Business and Summary of Significant Accounting Policies 
Description of Business
  (was, 2019-05-30, similarity 0.8537):
[0001327567-19-000016:note_history:14]
Description of Business and Summary of Significant Accounting Policies

- changed (2019-11-26):
[0001327567-19-000038:note_history:15]
Palo Alto Networks, Inc. (the “Company,” “we,” “us,” or “our”), located in Santa Clara, California, was incorporated in March 2005 under the laws of the State of Delaware and commenced operations in April 2005. We offer platforms that empower enterprises, service providers, and government entities to secure their organizations by safely enabling applications and data running in their networks, on their endpoints, and in the cloud, and by preventing breaches that stem from targeted cyberattacks.
  (was, 2019-05-30, similarity 0.9353):
[0001327567-19-000016:note_history:15]
Palo Alto Networks, Inc. (the “Company,” “we,” “us,” or “our”), located in Santa Clara, California, was incorporated in March 2005 under the laws of the State of Delaware and commenced operations in April 2005. We offer a security operating platform that empowers enterprises, service providers, and government entities to secure their organizations by safely enabling applications and data running in their networks, on their endpoints, and in the cloud, and by preventing breaches that stem from targeted cyberattacks.

- added (2019-11-26):
[0001327567-19-000038:note_history:16]
Certain prior period amounts have been reclassified to conform to our current period presentation.

- changed (2019-11-26):
[0001327567-19-000038:note_history:17]
There have been no material changes to our significant accounting policies as of and for the three months ended October 31, 2019, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended July 31, 2019, except for the change in our accounting policies for leases due to our adoption of new lease accounting guidance. Refer to “Recently Adopted Accounting Pronouncements” below and Note 10. Leases.
  (was, 2019-05-30, similarity 0.7232):
[0001327567-19-000016:note_history:17]
There have been no material changes to our significant accounting policies as of and for the nine months ended April 30, 2019, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended July 31, 2018, except for the change in our accounting policies for revenue recognition and deferred contract costs due to our adoption of new accounting guidance related to revenue from contracts with customers. Refer to “Recently Adopted Accounting Pronouncements” below, Note 2. Revenue, and Note 8. Deferred Contract Costs for more information.

- added (2019-11-26):
[0001327567-19-000038:note_history:18]
In February 2016, the Financial Accounting Standards Board (“FASB”) issued new authoritative guidance on lease accounting. Among its provisions, the standard requires lessees to recognize right-of-use assets and lease liabilities on the balance sheet for operating leases and also requires additional qualitative and quantitative disclosures about lease arrangements.

- added (2019-11-26):
[0001327567-19-000038:note_history:19]
We adopted this standard effective August 1, 2019 on a modified retrospective basis, under which financial results reported in periods prior to fiscal 2020 were not adjusted. We elected the package of practical expedients, which allowed us to carry forward our historical assessments of whether contracts are or contain leases, lease classification, and initial direct costs. Additionally, we elected to account for lease and non-lease components as a single lease component and to not recognize right-of-use assets and lease liabilities for leases with a term of 12 months or less.

- added (2019-11-26):
[0001327567-19-000038:note_history:20]
The most significant impact of adopting this guidance was the recognition of $286.4 million of operating lease right-of-use assets and $437.6 million of operating lease liabilities on our condensed consolidated balance sheet as of August 1, 2019, which included reclassifying previously recognized $124.2 million in lease incentives, deferred or prepaid rent, as well as $27.0 million in cease-use liabilities to operating lease right-of-use assets.

- changed (2019-11-26):
[0001327567-19-000038:note_history:21]
The adoption of this standard had no impact on our condensed consolidated statements of operations and condensed consolidated statements of cash flows. Refer to Note 10. Leases for further discussion.
  (was, 2019-05-30, similarity 0.6006):
[0001327567-19-000016:note_history:21]
The adoption of the standard did not impact net cash flows from operating, investing, or financing activities in our condensed consolidated statements of cash flows.

- added (2019-11-26):
[0001327567-19-000038:note_history:22]
In June 2016, the FASB issued new authoritative guidance on the accounting for credit losses on most financial assets and certain financial instruments. The standard replaces the existing incurred loss model with an expected credit loss model for financial

- changed (2019-11-26):
[0001327567-19-000038:note_history:23]
assets measured at amortized cost, including trade receivables, and requires that credit losses on available-for-sale debt securities be presented as an allowance rather than as a write-down. The standard is effective for us in our first quarter of fiscal 2021 and will be applied on a modified retrospective basis. We are currently evaluating whether this standard will have a material impact on our condensed consolidated financial statements.
  (was, 2019-05-30, similarity 0.6988):
[0001327567-19-000016:note_history:23]
In June 2016, the FASB issued new authoritative guidance on the accounting for credit losses on most financial assets and certain financial instruments. The standard replaces the existing incurred loss model with an expected credit loss model for financial assets measured at amortized cost, including trade receivables, and requires that credit losses on available-for-sale debt securities be presented as an allowance rather than as a write-down. The standard is effective for us in our first quarter of fiscal 2021 and will be applied on a modified retrospective basis. Early adoption is permitted beginning our first quarter of fiscal 2020. We are currently evaluating adoption timing and whether this standard will have a material impact on our condensed consolidated financial statements.

- removed (2019-11-26):
[0001327567-19-000016:note_history:24]
Description of Business

- removed (2019-11-26):
[0001327567-19-000016:note_history:25]
Certain prior period amounts have been reclassified to conform to our current period presentation. In addition, certain prior period amounts have been adjusted due to our retrospective adoption of new accounting guidance related to revenue from contracts with customers and new accounting guidance related to the presentation of restricted cash and cash equivalents in the statement of cash flows. Refer to “Recently Adopted Accounting Pronouncements” below for more information.

- removed (2019-11-26):
[0001327567-19-000016:note_history:26]
Implementation Costs Incurred in a Cloud Computing Arrangement

- removed (2019-11-26):
[0001327567-19-000016:note_history:27]
In August 2018, the Financial Accounting Standards Board (“FASB”) issued authoritative guidance on customers’ accounting for implementation costs incurred in a cloud computing arrangement that is a service contract, which requires customers to apply internal-use software guidance to determine the implementation costs that are able to be capitalized. Under the new standard, capitalized implementation costs are generally amortized over the term of the arrangement, beginning when the module or component of the hosting arrangement is ready for its intended use. We early adopted this standard in our second quarter of fiscal 2019 on a prospective basis. The adoption of the standard did not have a material impact on our condensed consolidated financial statements.

- removed (2019-11-26):
[0001327567-19-000016:note_history:28]
Business Combinations - Definition of a Business

- removed (2019-11-26):
[0001327567-19-000016:note_history:29]
In January 2017, the FASB issued authoritative guidance clarifying the definition of a business to assist companies with evaluating whether transactions should be accounted for as acquisitions (or disposals) of assets or businesses. We adopted this standard in our first quarter of fiscal 2019 on a prospective basis. The adoption of the standard did not have an impact on our condensed consolidated financial statements.

- removed (2019-11-26):
[0001327567-19-000016:note_history:30]
Statement of Cash Flows - Restricted Cash

- removed (2019-11-26):
[0001327567-19-000016:note_history:31]
In November 2016, the FASB issued authoritative guidance on the presentation of restricted cash or restricted cash equivalents in the statement of cash flows. Under the new standard, restricted cash or restricted cash equivalents should be included with cash and cash equivalents when reconciling the beginning-of-period and end-of-period total amounts shown on the statement of cash flows. We adopted this standard in our first quarter of fiscal 2019 on a retrospective basis. The adoption of the standard did not have a material impact on our condensed consolidated financial statements because our restricted cash balance has not been material.

- removed (2019-11-26):
[0001327567-19-000016:note_history:32]
Income Taxes - Intra-Entity Asset Transfers

- removed (2019-11-26):
[0001327567-19-000016:note_history:33]
In October 2016, the FASB issued authoritative guidance requiring the recognition of income tax consequences of an intra-entity transfer of an asset, other than inventory, when the transfer occurs. We adopted the standard in our first quarter of fiscal 2019 on a modified retrospective basis. As a result, we recorded the cumulative effect of the change as an increase to accumulated deficit of $28.3 million, with a corresponding decrease to prepaid expenses and other current assets and other assets in our condensed consolidated balance sheets as of August 1, 2018, the date of adoption. The cumulative effect adjustment represents the reclassification of unrecognized income tax effects from intra-entity transfers of assets other than inventory that occurred prior to the date of adoption.

- removed (2019-11-26):
[0001327567-19-000016:note_history:34]
Statement of Cash Flows - Classification of Certain Cash Receipts and Cash Payments

- removed (2019-11-26):
[0001327567-19-000016:note_history:35]
In August 2016, the FASB issued new authoritative guidance addressing eight specific cash flow issues with the objective of reducing the existing diversity in practice in how certain transactions are presented and classified in the statement of cash flows. We adopted this standard in our first quarter of fiscal 2019 on a retrospective basis. The adoption of the standard did not have an impact on our condensed consolidated financial statements.

- removed (2019-11-26):
[0001327567-19-000016:note_history:36]
Financial Instruments - Recognition and Measurement

- removed (2019-11-26):
[0001327567-19-000016:note_history:37]
In January 2016, the FASB issued authoritative guidance requiring equity instruments to be measured at fair value with changes in fair value recognized through net income. We adopted this standard in our first quarter of fiscal 2019 on a prospective basis for non-marketable equity securities and a modified retrospective basis for marketable equity investments. The adoption of the standard did not have an impact on our condensed consolidated financial statements.

- removed (2019-11-26):
[0001327567-19-000016:note_history:38]
Revenue Recognition

- removed (2019-11-26):
[0001327567-19-000016:note_history:39]
In May 2014, the FASB issued new authoritative guidance on revenue from contracts with customers. The new standard provides principles for recognizing revenue when control of promised goods or services is transferred to customers with the expected consideration in exchange for those goods or services, as well as guidance on the recognition of costs related to obtaining and fulfilling customer contracts. The standard also requires expanded disclosures about the nature, amount, timing, and uncertainty of revenues and cash flows arising from customer contracts, including significant judgments and changes in judgments, and assets recognized from costs incurred to obtain or fulfill a contract. We adopted the standard in our first quarter of fiscal 2019 using the full retrospective method.

- removed (2019-11-26):
[0001327567-19-000016:note_history:40]
The adoption of the new standard did not have a material impact on our condensed consolidated financial statements for the fiscal years ended July 31, 2018 and 2017, with the exception of the accounting for incremental costs to obtain customer contracts, which primarily consist of sales commissions, due to the longer period of amortization. Under the previous accounting guidance, we deferred and amortized these costs over the term of the related contract. Under the new standard, we defer and amortize these costs for initial contracts that are not commensurate with renewal commissions over a benefit period of five years, which is typically longer than the initial contract term.

- removed (2019-11-26):
[0001327567-19-000016:note_history:41]
The adoption of the standard using the full retrospective method required us to restate the prior periods presented in this Quarterly Report on Form 10-Q, with the cumulative effect of the change of $168.2 million reflected in accumulated deficit as of July 31, 2017. In adopting the new standard, we have also applied a transition practical expedient and have not disclosed revenue expected to be recognized from remaining performance obligations for periods prior to August 1, 2018.

- removed (2019-11-26):
[0001327567-19-000016:note_history:42]
The following tables present the impact of the adoption of the standard on our previously reported results (in millions, except per share data):

- removed (2019-11-26):
[0001327567-19-000016:note_history:43]
|  | Three Months Ended April 30, 2018 |  | Nine Months Ended April 30, 2018 |
|  | As Previously Reported |  | Impact of Adoption |  | As Adjusted |  | As Previously Reported |  | Impact of Adoption |  | As Adjusted |
| Condensed Consolidated Statements of Operations |  |  |  |  |  |  |  |  |  |  |  |
| Product revenue | $ | 215.2 |  |  | $ | 2.9 |  |  | $ | 218.1 |  |  | $ | 603.9 |  |  | $ | 3.8 |  |  | $ | 607.7 |  |
| Subscription and support revenue | 351.9 |  |  | (2.3 | ) |  | 349.6 |  |  | 1,011.1 |  |  | (3.7 | ) |  | 1,007.4 |  |
| Total revenue | 567.1 |  |  | 0.6 |  |  | 567.7 |  |  | 1,615.0 |  |  | 0.1 |  |  | 1,615.1 |  |
| Total cost of revenue | 159.9 |  |  | — |  |  | 159.9 |  |  | 460.6 |  |  | — |  |  | 460.6 |  |
| Total operating expenses | 458.8 |  |  | (5.7 | ) |  | 453.1 |  |  | 1,292.1 |  |  | (16.3 | ) |  | 1,275.8 |  |
| Operating loss | (51.6 | ) |  | 6.3 |  |  | (45.3 | ) |  | (137.7 | ) |  | 16.4 |  |  | (121.3 | ) |
| Net loss | (46.7 | ) |  | 6.3 |  |  | (40.4 | ) |  | (145.6 | ) |  | 16.4 |  |  | (129.2 | ) |
| Net loss per share, basic and diluted | $ | (0.51 | ) |  | $ | 0.07 |  |  | $ | (0.44 | ) |  | $ | (1.59 | ) |  | $ | 0.17 |  |  | $ | (1.42 | ) |

- removed (2019-11-26):
[0001327567-19-000016:note_history:44]
|  | July 31, 2018 |
|  | As Previously Reported |  | Impact of Adoption |  | As Adjusted |
| Condensed Consolidated Balance Sheet |  |  |  |  |  |
| Accounts receivable, net | $ | 467.3 |  |  | $ | (0.3 | ) |  | $ | 467.0 |  |
| Prepaid expenses and other current assets | 261.3 |  |  | 6.8 |  |  | 268.1 |  |
| Other assets | 206.8 |  |  | 119.4 |  |  | 326.2 |  |
| Accrued and other liabilities | 107.0 |  |  | 17.6 |  |  | 124.6 |  |
| Deferred revenue | 1,268.9 |  |  | (55.3 | ) |  | 1,213.6 |  |
| Long-term deferred revenue | 1,096.0 |  |  | (30.3 | ) |  | 1,065.7 |  |
| Accumulated deficit | $ | (984.6 | ) |  | $ | 193.9 |  |  | $ | (790.7 | ) |

- removed (2019-11-26):
[0001327567-19-000016:note_history:45]
In February 2016, the FASB issued new authoritative guidance on lease accounting. Among its provisions, the standard requires lessees to recognize right-of-use assets and lease liabilities on the balance sheet for operating leases and also requires additional qualitative and quantitative disclosures about lease arrangements. The standard is effective for us in our first quarter of fiscal 2020 and will be applied on a modified retrospective basis, with the option to elect certain practical expedients. Early adoption is permitted; however, we plan to adopt the new standard in our first quarter of fiscal 2020. We expect to recognize right-of-use assets and operating lease liabilities on our consolidated balance sheets upon adoption for our operating leases disclosed in Note 10. Commitments and Contingencies, which will materially increase our total assets and liabilities. We do not expect the adoption of this standard to have a material impact to our consolidated statements of operations and consolidated statements of cash flows. We continue to evaluate the accounting, transition, and disclosure requirements of this standard, including its impact on our systems, accounting policies, and processes.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2019-11-26):
[0001327567-19-000038:note_history:46]
Palo Alto Networks, Inc. (the “Company,” “we,” “us,” or “our”), located in Santa Clara, California, was incorporated in March 2005 under the laws of the State of Delaware and commenced operations in April 2005. We offer platforms that empower enterprises, service providers, and government entities to secure their organizations by safely enabling applications and data running in their networks, on their endpoints, and in the cloud, and by preventing breaches that stem from targeted cyberattacks.
  (was, 2019-05-30, similarity 0.9353):
[0001327567-19-000016:note_history:46]
Palo Alto Networks, Inc. (the “Company,” “we,” “us,” or “our”), located in Santa Clara, California, was incorporated in March 2005 under the laws of the State of Delaware and commenced operations in April 2005. We offer a security operating platform that empowers enterprises, service providers, and government entities to secure their organizations by safely enabling applications and data running in their networks, on their endpoints, and in the cloud, and by preventing breaches that stem from targeted cyberattacks.

- added (2019-11-26):
[0001327567-19-000038:note_history:47]
Certain prior period amounts have been reclassified to conform to our current period presentation.

- changed (2019-11-26):
[0001327567-19-000038:note_history:48]
There have been no material changes to our significant accounting policies as of and for the three months ended October 31, 2019, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended July 31, 2019, except for the change in our accounting policies for leases due to our adoption of new lease accounting guidance. Refer to “Recently Adopted Accounting Pronouncements” below and Note 10. Leases.
  (was, 2019-05-30, similarity 0.7232):
[0001327567-19-000016:note_history:48]
There have been no material changes to our significant accounting policies as of and for the nine months ended April 30, 2019, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended July 31, 2018, except for the change in our accounting policies for revenue recognition and deferred contract costs due to our adoption of new accounting guidance related to revenue from contracts with customers. Refer to “Recently Adopted Accounting Pronouncements” below, Note 2. Revenue, and Note 8. Deferred Contract Costs for more information.

- removed (2019-11-26):
[0001327567-19-000016:note_history:49]
Certain prior period amounts have been reclassified to conform to our current period presentation. In addition, certain prior period amounts have been adjusted due to our retrospective adoption of new accounting guidance related to revenue from contracts with customers and new accounting guidance related to the presentation of restricted cash and cash equivalents in the statement of cash flows. Refer to “Recently Adopted Accounting Pronouncements” below for more information.


## panw:ConvertibleDebtOtherDetailsTableTextBlock (debt) — matched_by: no_current_note, score: 0.0

- removed (2019-11-26):
[0001327567-19-000016:note_history:50]
The following table presents details of the Notes (number of shares in millions):

- removed (2019-11-26):
[0001327567-19-000016:note_history:51]
|  | Conversion Rate per $1,000 Principal |  | Initial Conversion Price |  | Convertible Date |  | Initial Number of Shares |
| 2019 Notes | 9.0680 |  |  | $ | 110.28 |  |  | January 1, 2019 |  | 5.2 |  |
| 2023 Notes | 3.7545 |  |  | $ | 266.35 |  |  | April 1, 2023 |  | 6.4 |  |


## us-gaap:ConvertibleDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-11-26):
[0001327567-19-000038:note_history:52]
The following table sets forth the components of the 2023 Notes as of October 31, 2019 and July 31, 2019 (in millions):
  (was, 2019-05-30, similarity 0.9423):
[0001327567-19-000016:note_history:52]
The following table sets forth the components of the Notes as of April 30, 2019 and July 31, 2018 (in millions):

- added (2019-11-26):
[0001327567-19-000038:note_history:53]
|  | October 31, 2019 |  | July 31, 2019 |
| Liability component: |  |  |  |
| Principal | $ | 1,693.0 |  |  | $ | 1,693.0 |  |
| Less: debt discount and debt issuance costs, net of amortization | 247.5 |  |  | 263.0 |  |
| Net carrying amount | $ | 1,445.5 |  |  | $ | 1,430.0 |  |
| Equity component | $ | 315.0 |  |  | $ | 315.0 |  |

- removed (2019-11-26):
[0001327567-19-000016:note_history:54]
|  | April 30, 2019 |  | July 31, 2018 |
|  | 2019 Notes |  | 2023 Notes |  | Total |  | 2019 Notes |  | 2023 Notes |  | Total |
| Liability component: |  |  |  |  |  |  |  |  |  |  |  |
| Principal | $ | 159.4 |  |  | $ | 1,693.0 |  |  | $ | 1,852.4 |  |  | $ | 575.0 |  |  | $ | 1,693.0 |  |  | $ | 2,268.0 |  |
| Less: debt discount and debt issuance costs, net of amortization | 1.3 |  |  | 278.3 |  |  | 279.6 |  |  | 24.6 |  |  | 323.3 |  |  | 347.9 |  |
| Net carrying amount | $ | 158.1 |  |  | $ | 1,414.7 |  |  | $ | 1,572.8 |  |  | $ | 550.4 |  |  | $ | 1,369.7 |  |  | $ | 1,920.1 |  |
| Equity component (including amounts classified as temporary equity) | $ | 30.4 |  |  | $ | 315.0 |  |  | $ | 345.4 |  |  | $ | 109.8 |  |  | $ | 315.0 |  |  | $ | 424.8 |  |


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-11-26):
[0001327567-19-000038:note_history:55]
Debt
Convertible Senior Notes
  (was, 2019-05-30, similarity 0.9057):
[0001327567-19-000016:note_history:55]
Convertible Senior Notes

- changed (2019-11-26):
[0001327567-19-000038:note_history:56]
In June 2014, we issued $575.0 million aggregate principal amount of 0.0% Convertible Senior Notes due 2019 (the “2019 Notes”), and in July 2018, we issued $1.7 billion aggregate principal amount of 0.75% Convertible Senior Notes due 2023 (the “2023 Notes” and, together with the 2019 Notes, the “Notes”). The 2023 Notes bear interest at a fixed rate of 0.75% per year, payable semi-annually in arrears on January 1 and July 1 of each year, beginning on January 1, 2019. The 2023 Notes are governed by an indenture between us, as the issuer, and U.S. Bank National Association, as Trustee (the “Indenture”). The 2023 Notes are unsecured, unsubordinated obligations and the Indenture governing the 2023 Notes does not contain any financial covenants or restrictions on the payments of dividends, the incurrence of indebtedness, or the issuance or repurchase of securities by us or any of our subsidiaries. The 2019 Notes were converted prior to or settled on the maturity date of July 1, 2019, in accordance with their terms. The 2023 Notes mature on July 1, 2023. We cannot redeem the 2023 Notes prior to maturity.
  (was, 2019-05-30, similarity 0.7399):
[0001327567-19-000016:note_history:56]
In June 2014, we issued $575.0 million aggregate principal amount of 0.0% Convertible Senior Notes due 2019 (the “2019 Notes”) and in July 2018, we issued $1.7 billion aggregate principal amount of 0.75% Convertible Senior Notes due 2023 (the “2023 Notes” and, together with the 2019 Notes, the “Notes”). The 2023 Notes bear interest at a fixed rate of 0.75% per year, payable semi-annually in arrears on January 1 and July 1 of each year, beginning on January 1, 2019. Each series of Notes is governed by an indenture between us, as the issuer, and U.S. Bank National Association, as Trustee (individually, each an “Indenture,” and together, the “Indentures”). The Notes of each series are unsecured, unsubordinated obligations and the applicable Indenture governing each series of Notes does not contain any financial covenants or restrictions on the payments of dividends, the incurrence of indebtedness, or the issuance or repurchase of securities by us or any of our subsidiaries. The 2019 Notes and 2023 Notes mature on July 1, 2019 and July 1, 2023, respectively. We cannot redeem either series of Notes prior to the applicable maturity date.

- added (2019-11-26):
[0001327567-19-000038:note_history:57]
The 2023 Notes are convertible for up to 6.4 million shares of our common stock at an initial conversion rate of approximately 3.7545 shares of common stock per $1,000 principal amount, which is equal to an initial conversion price of approximately $266.35 per share of common stock, subject to adjustments. Holders of the 2023 Notes may surrender their 2023 Notes for conversion at their option at any time prior to the close of business on the business day immediately preceding April 1, 2023, only under the following circumstances:

- changed (2019-11-26):
[0001327567-19-000038:note_history:58]
| • | during any fiscal quarter commencing after the fiscal quarter ending on October 31, 2018 (and only during such fiscal quarter), if the last reported sale price of our common stock for at least 20 trading days (whether or not consecutive) during a period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the applicable conversion price for the 2023 Notes on each applicable trading day (the “sale price condition”); |
  (was, 2019-05-30, similarity 0.9348):
[0001327567-19-000016:note_history:58]
| • | during any fiscal quarter commencing after the fiscal quarters ending on October 31, 2014 and October 31, 2018, for the 2019 Notes and 2023 Notes, respectively (and only during such fiscal quarter), if the last reported sale price of our common stock for at least 20 trading days (whether or not consecutive) during a period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the applicable conversion price for the respective Notes on each applicable trading day (the “sale price condition”); |

- changed (2019-11-26):
[0001327567-19-000038:note_history:59]
| • | during the five business day period after any five consecutive trading day period (the “measurement period”), in which the trading price per $1,000 principal amount of the 2023 Notes for each trading day of the measurement period was less than 98% of the product of the last reported sale price of our common stock and the applicable conversion rate for the 2023 Notes on each such trading day; or |
  (was, 2019-05-30, similarity 0.9595):
[0001327567-19-000016:note_history:59]
| • | during the five business day period after any five consecutive trading day period (the “measurement period”) in which the trading price per $1,000 principal amount of the applicable series of Notes for each trading day of the measurement period was less than 98% of the product of the last reported sale price of our common stock and the applicable conversion rate for the respective Notes on each such trading day; or |

- added (2019-11-26):
[0001327567-19-000038:note_history:60]
On or after April 1, 2023, holders may surrender all or any portion of their 2023 Notes for conversion at any time prior to the close of business on the second scheduled trading day immediately preceding the maturity date regardless of the foregoing conditions, and such conversions will be settled upon the maturity date. Upon conversion, holders of the 2023 Notes will receive cash equal to the aggregate principal amount of the 2023 Notes to be converted, and, at our election, cash and/or shares of our common stock for any amounts in excess of the aggregate principal amount of the 2023 Notes being converted.

- changed (2019-11-26):
[0001327567-19-000038:note_history:61]
The conversion price will be subject to adjustment in some events. Holders who convert their 2023 Notes in connection with certain corporate events that constitute a “make-whole fundamental change” under the Indenture are, under certain circumstances, entitled to an increase in the conversion rate. Additionally, upon the occurrence of a corporate event that constitutes a “fundamental change” under the Indenture, holders of the 2023 Notes may require us to repurchase for cash all or a portion of the 2023 Notes at a repurchase price equal to 100% of the principal amount of the 2023 Notes plus accrued and unpaid interest to, but excluding, the fundamental change repurchase date.
  (was, 2019-05-30, similarity 0.888):
[0001327567-19-000016:note_history:61]
The conversion price will be subject to adjustment in some events. Holders of the Notes of a series who convert their Notes of such series in connection with certain corporate events that constitute a “make-whole fundamental change” under the applicable Indenture are, under certain circumstances, entitled to an increase in the conversion rate for such series of Notes. Additionally, upon the occurrence of a corporate event that constitutes a “fundamental change” under the applicable Indenture, holders of the Notes of such series may require us to repurchase for cash all or a portion of the Notes of such series at a repurchase price equal to 100% of the principal amount of the Notes of such series plus accrued and unpaid interest to, but excluding, the fundamental change repurchase date.

- changed (2019-11-26):
[0001327567-19-000038:note_history:62]
The sale price condition was not met for the 2023 Notes during the fiscal quarters ended October 31, 2019 or July 31, 2019. Since the 2023 Notes were not convertible, the net carrying amount of the 2023 Notes was classified as a long-term liability and the equity component was included in additional paid-in capital in our condensed consolidated balance sheets as of October 31, 2019 and July 31, 2019. As of October 31, 2019, all of the 2023 Notes remained outstanding.
  (was, 2019-05-30, similarity 0.9579):
[0001327567-19-000016:note_history:62]
The sale price condition was not met for the 2023 Notes during the fiscal quarters ended April 30, 2019 or July 31, 2018. Since the 2023 Notes were not convertible, the net carrying amount of the 2023 Notes was classified as a long-term liability and the equity component was included in additional paid-in capital in our condensed consolidated balance sheets as of April 30, 2019 and July 31, 2018. As of April 30, 2019, all of the 2023 Notes remained outstanding.

- changed (2019-11-26):
[0001327567-19-000038:note_history:63]
The following table sets forth the components of the 2023 Notes as of October 31, 2019 and July 31, 2019 (in millions):
  (was, 2019-05-30, similarity 0.9423):
[0001327567-19-000016:note_history:63]
The following table sets forth the components of the Notes as of April 30, 2019 and July 31, 2018 (in millions):

- added (2019-11-26):
[0001327567-19-000038:note_history:64]
|  | October 31, 2019 |  | July 31, 2019 |
| Liability component: |  |  |  |
| Principal | $ | 1,693.0 |  |  | $ | 1,693.0 |  |
| Less: debt discount and debt issuance costs, net of amortization | 247.5 |  |  | 263.0 |  |
| Net carrying amount | $ | 1,445.5 |  |  | $ | 1,430.0 |  |
| Equity component | $ | 315.0 |  |  | $ | 315.0 |  |

- added (2019-11-26):
[0001327567-19-000038:note_history:65]
The total estimated fair value of the 2023 Notes was $1.9 billion at both October 31, 2019 and July 31, 2019. The fair value was determined based on the closing trading price per $100 of the 2023 Notes as of the last day of trading for the period. We consider the fair value of the 2023 Notes at October 31, 2019 and July 31, 2019 to be a Level 2 measurement. The fair value of the 2023 Notes is primarily affected by the trading price of our common stock and market interest rates. Based on the closing price of our common stock on October 31, 2019, the if-converted value of the 2023 Notes was less than its principal amount.

- added (2019-11-26):
[0001327567-19-000038:note_history:66]
|  | Three Months Ended October 31, |
|  | 2019 |  | 2018 |
|  | 2019 Notes |  | 2023 Notes |  | Total |  | 2019 Notes |  | 2023 Notes |  | Total |
| Contractual interest expense | $ | — |  |  | $ | 3.2 |  |  | $ | 3.2 |  |  | $ | — |  |  | $ | 3.2 |  |  | $ | 3.2 |  |
| Amortization of debt discount | — |  |  | 15.0 |  |  | 15.0 |  |  | 4.0 |  |  | 14.4 |  |  | 18.4 |  |
| Amortization of debt issuance costs | — |  |  | 0.5 |  |  | 0.5 |  |  | 0.5 |  |  | 0.5 |  |  | 1.0 |  |
| Total interest expense recognized | $ | — |  |  | $ | 18.7 |  |  | $ | 18.7 |  |  | $ | 4.5 |  |  | $ | 18.1 |  |  | $ | 22.6 |  |
| Effective interest rate of the liability component | — | % |  | 5.2 | % |  |  |  | 4.8 | % |  | 5.2 | % |  |  |

- added (2019-11-26):
[0001327567-19-000038:note_history:67]
Upon the settlement of the 2019 Notes, we exercised the corresponding portion of our 2019 Note Hedges during the year ended July 31, 2019 and received shares of our common stock that fully offset the shares issued in excess of the principal amount of the converted 2019 Notes. The 2019 Note Hedges expired upon maturity of the 2019 Notes.

- added (2019-11-26):
[0001327567-19-000038:note_history:68]
The 2023 Note Hedges cover up to 6.4 million shares of our common stock at a strike price per share that corresponds to the initial applicable conversion price of the 2023 Notes, which are also subject to adjustment, and are exercisable upon conversion of the 2023 Notes. The 2023 Note Hedges will expire upon maturity of the 2023 Notes. The 2023 Note Hedges are separate transactions and

- added (2019-11-26):
[0001327567-19-000038:note_history:69]
are not part of the terms of 2023 Notes. Holders of the 2023 Notes will not have any rights with respect to the 2023 Note Hedges. Any shares of our common stock receivable by us under the 2023 Note Hedges are excluded from the calculation of diluted earnings per share as they are antidilutive. We paid an aggregate amount of $332.0 million for the 2023 Note Hedges, which is included in additional paid-in capital in our consolidated balance sheets.

- changed (2019-11-26):
[0001327567-19-000038:note_history:70]
Separately, but concurrently with the issuance of each series of Notes, we entered into transactions whereby we sold warrants (the “2019 Warrants,” with respect to the 2019 Notes, and the “2023 Warrants,” with respect to the 2023 Notes, and collectively, the “Warrants”) to acquire shares of our common stock, subject to anti-dilution adjustments. The 2019 Warrants became exercisable beginning October 2019 and the 2023 Warrants are exercisable beginning October 2023.
  (was, 2019-05-30, similarity 0.8912):
[0001327567-19-000016:note_history:70]
Separately, but concurrently with the issuance of each series of Notes, we entered into transactions whereby we sold warrants (the “2019 Warrants,” with respect to the 2019 Notes, and the “2023 Warrants,” with respect to the 2023 Notes, and collectively, the “Warrants”) to acquire shares of our common stock, subject to anti-dilution adjustments. The 2019 Warrants and 2023 Warrants are exercisable beginning October 2019 and October 2023, respectively.

- added (2019-11-26):
[0001327567-19-000038:note_history:71]
During the three months ended October 31, 2019, we net settled the 2019 Warrants exercised with 0.7 million shares or $153.6 million in fair value of our common stock. The number of net shares issued was determined based on the number of 2019 Warrants exercised multiplied by the difference between the strike price of the 2019 Warrants and their daily volume weighted-average stock price. As of October 31, 2019, up to 3.2 million shares of our common stock were issuable for gross settlement under the remaining outstanding 2019 Warrants, which will be net settled when exercised through the end of December 2019.

- changed (2019-11-26):
[0001327567-19-000038:note_history:72]
The borrowings under the Credit Facility bear interest, at our option, at a base rate plus a spread of 0.00% to 0.75%, or an adjusted LIBO rate plus a spread of 1.00% to 1.75%, in each case with such spread being determined based on our leverage ratio. We are obligated to pay an ongoing commitment fee on undrawn amounts at a rate of 0.125% to 0.250%, depending on our leverage ratio. As of October 31, 2019, there were no amounts outstanding and we were in compliance with all covenants under the Credit Agreement.
  (was, 2019-05-30, similarity 0.9877):
[0001327567-19-000016:note_history:72]
The borrowings under the Credit Facility bear interest, at our option, at a base rate plus a spread of 0.00% to 0.75%, or an adjusted LIBO rate plus a spread of 1.00% to 1.75%, in each case with such spread being determined based on our leverage ratio. We are obligated to pay an ongoing commitment fee on undrawn amounts at a rate of 0.125% to 0.250%, depending on our leverage ratio. As of April 30, 2019, there were no amounts outstanding and we were in compliance with all covenants under the Credit Agreement.

- removed (2019-11-26):
[0001327567-19-000016:note_history:73]
Debt

- removed (2019-11-26):
[0001327567-19-000016:note_history:74]
The following table presents details of the Notes (number of shares in millions):

- removed (2019-11-26):
[0001327567-19-000016:note_history:75]
|  | Conversion Rate per $1,000 Principal |  | Initial Conversion Price |  | Convertible Date |  | Initial Number of Shares |
| 2019 Notes | 9.0680 |  |  | $ | 110.28 |  |  | January 1, 2019 |  | 5.2 |  |
| 2023 Notes | 3.7545 |  |  | $ | 266.35 |  |  | April 1, 2023 |  | 6.4 |  |

- removed (2019-11-26):
[0001327567-19-000016:note_history:76]
Holders of the Notes may surrender their Notes for conversion at their option at any time prior to the close of business on the business day immediately preceding their respective convertible dates only under the following circumstances:

- removed (2019-11-26):
[0001327567-19-000016:note_history:77]
On or after the respective convertible date, holders may surrender all or any portion of their Notes for conversion at any time prior to the close of business on the second scheduled trading day immediately preceding the applicable maturity date regardless of the foregoing conditions, and such conversions will be settled upon the applicable maturity date. Upon conversion, holders of the Notes of a series will receive cash equal to the aggregate principal amount of the Notes of such series to be converted, and, at our election, cash and/or shares of our common stock for any amounts in excess of the aggregate principal amount of the Notes of such series being converted.

- removed (2019-11-26):
[0001327567-19-000016:note_history:78]
The sale price condition was met for the 2019 Notes during the fiscal quarters ended July 31, 2018 and October 31, 2018. As a result, holders were able to convert their 2019 Notes at any time during the fiscal quarter ended October 31, 2018 and up to January 1, 2019. On or after January 1, 2019, holders may surrender their 2019 Notes for conversion at any time prior to maturity, in accordance with the terms described above. Such conversion requests will settle upon maturity of the 2019 Notes in the fourth quarter of fiscal 2019. Accordingly, the net carrying amount of the 2019 Notes was classified as a current liability and the portion of the equity component representing the conversion option was classified as temporary equity in our condensed consolidated balance sheets as of April 30, 2019. As of April 30, 2019, $159.4 million in aggregate principal amount of the 2019 Notes remained outstanding.

- removed (2019-11-26):
[0001327567-19-000016:note_history:79]
There were no conversions of the 2019 Notes during the three months ended April 30, 2019. The following table presents details of conversions of the 2019 Notes during the nine months ended April 30, 2019 (in millions):

- removed (2019-11-26):
[0001327567-19-000016:note_history:80]
|  | Nine Months Ended |
|  | April 30, 2019 |
| 2019 Notes principal converted and repaid in cash: |  |
| Allocated to liability component(1) | $ | 403.4 |  |
| Allocated to equity component(2) | 12.2 |  |
| Total principal converted and repaid in cash | $ | 415.6 |  |
| Loss on conversions of convertible senior notes(3) | $ | 2.6 |  |
| Shares of common stock issued in connection with conversion of convertible senior notes(4) | 1.7 |  |

- removed (2019-11-26):
[0001327567-19-000016:note_history:81]
______________

- removed (2019-11-26):
[0001327567-19-000016:note_history:82]
| (1) | Recorded as a reduction to convertible senior notes, net in our condensed consolidated balance sheets and calculated by measuring the fair value of a similar liability that did not have an associated convertible feature. |

- removed (2019-11-26):
[0001327567-19-000016:note_history:83]
| (2) | Recorded as a reduction to additional paid-in capital in our condensed consolidated balance sheets. |

- removed (2019-11-26):
[0001327567-19-000016:note_history:84]
| (3) | Represents the difference between the cash consideration allocated to the liability component and the net carrying amount of the liability component on the respective settlement dates. The amount is included in other income, net in our condensed consolidated statement of operations. |

- removed (2019-11-26):
[0001327567-19-000016:note_history:85]
| (4) | Shares of common stock issued to the holders for the conversion value in excess of the principal amount. These shares were fully offset by shares received from the corresponding exercise of the associated note hedges. |

- removed (2019-11-26):
[0001327567-19-000016:note_history:86]
|  | April 30, 2019 |  | July 31, 2018 |
|  | 2019 Notes |  | 2023 Notes |  | Total |  | 2019 Notes |  | 2023 Notes |  | Total |
| Liability component: |  |  |  |  |  |  |  |  |  |  |  |
| Principal | $ | 159.4 |  |  | $ | 1,693.0 |  |  | $ | 1,852.4 |  |  | $ | 575.0 |  |  | $ | 1,693.0 |  |  | $ | 2,268.0 |  |
| Less: debt discount and debt issuance costs, net of amortization | 1.3 |  |  | 278.3 |  |  | 279.6 |  |  | 24.6 |  |  | 323.3 |  |  | 347.9 |  |
| Net carrying amount | $ | 158.1 |  |  | $ | 1,414.7 |  |  | $ | 1,572.8 |  |  | $ | 550.4 |  |  | $ | 1,369.7 |  |  | $ | 1,920.1 |  |
| Equity component (including amounts classified as temporary equity) | $ | 30.4 |  |  | $ | 315.0 |  |  | $ | 345.4 |  |  | $ | 109.8 |  |  | $ | 315.0 |  |  | $ | 424.8 |  |

- removed (2019-11-26):
[0001327567-19-000016:note_history:87]
The total estimated fair value of the Notes was $2.3 billion and $2.7 billion at April 30, 2019 and July 31, 2018, respectively. The fair value was determined based on the closing trading price per $100 of the Notes as of the last day of trading for the period. We consider the fair value of the Notes at April 30, 2019 and July 31, 2018 to be a Level 2 measurement. The fair value of the Notes is primarily affected by the trading price of our common stock and market interest rates. As of April 30, 2019, the if-converted value of the 2019 Notes exceeded its principal amount by $191.1 million. Based on the closing price of our common stock on April 30, 2019, the if-converted value of the 2023 Notes was less than its principal amount.

- removed (2019-11-26):
[0001327567-19-000016:note_history:88]
|  | Three Months Ended April 30, |  | Nine Months Ended April 30, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
|  | 2019 Notes |  | 2023 Notes |  | Total |  | 2019 Notes |  | 2023 Notes |  | Total |  | 2019 Notes |  | 2023 Notes |  | Total |  | 2019 Notes |  | 2023 Notes |  | Total |
| Contractual interest expense | $ | — |  |  | $ | 3.3 |  |  | $ | 3.3 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 9.6 |  |  | $ | 9.6 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Amortization of debt discount | 1.6 |  |  | 14.7 |  |  | 16.3 |  |  | 5.7 |  |  | — |  |  | 5.7 |  |  | 7.6 |  |  | 43.6 |  |  | 51.2 |  |  | 17.1 |  |  | — |  |  | 17.1 |  |
| Amortization of debt issuance costs | 0.3 |  |  | 0.5 |  |  | 0.8 |  |  | 0.8 |  |  | — |  |  | 0.8 |  |  | 1.0 |  |  | 1.4 |  |  | 2.4 |  |  | 2.1 |  |  | — |  |  | 2.1 |  |
| Total interest expense recognized | $ | 1.9 |  |  | $ | 18.5 |  |  | $ | 20.4 |  |  | $ | 6.5 |  |  | $ | — |  |  | $ | 6.5 |  |  | $ | 8.6 |  |  | $ | 54.6 |  |  | $ | 63.2 |  |  | $ | 19.2 |  |  | $ | — |  |  | $ | 19.2 |  |
| Effective interest rate of the liability component | 4.8 | % |  | 5.2 | % |  |  |  | 4.8 | % |  | — | % |  |  |  | 4.8 | % |  | 5.2 | % |  |  |  | 4.8 | % |  | — | % |  |  |

- removed (2019-11-26):
[0001327567-19-000016:note_history:89]
The following table presents details of the Note Hedges (in millions):

- removed (2019-11-26):
[0001327567-19-000016:note_history:90]
|  | Initial Number of Shares |  | Aggregate Purchase |
| 2019 Note Hedges | 5.2 |  |  | $ | 111.0 |  |
| 2023 Note Hedges | 6.4 |  |  | $ | 332.0 |  |

- removed (2019-11-26):
[0001327567-19-000016:note_history:91]
The Note Hedges cover shares of our common stock at a strike price per share that corresponds to the initial applicable conversion price of the applicable series of Notes, which are also subject to adjustment, and are exercisable upon conversion of the applicable series of Notes. The Note Hedges will expire upon maturity of the applicable series of Notes. The Note Hedges are separate transactions and are not part of the terms of the applicable series of the Notes. Holders of the Notes of either series will not have any rights with respect to the Note Hedges. Any shares of our common stock receivable by us under the Note Hedges are excluded from the calculation of diluted earnings per share as they are antidilutive. The aggregate amounts paid for the Note Hedges are included in additional paid-in capital in our consolidated balance sheets.

- removed (2019-11-26):
[0001327567-19-000016:note_history:92]
As a result of the conversions of the 2019 Notes settled during the nine months ended April 30, 2019, we exercised the corresponding portion of our 2019 Note Hedges and received 1.7 million shares of common stock during the period.


## us-gaap:DebtSecuritiesAvailableForSaleTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-11-26):
[0001327567-19-000038:note_history:93]
The following tables summarize the amortized cost, unrealized gains and losses, and fair value of our available-for-sale debt securities as of October 31, 2019 and July 31, 2019 (in millions):
  (was, 2019-05-30, similarity 0.958):
[0001327567-19-000016:note_history:93]
The following tables summarize the amortized cost, unrealized gains and losses, and fair value of our available-for-sale securities as of April 30, 2019 and July 31, 2018 (in millions):

- changed (2019-11-26):
[0001327567-19-000038:note_history:94]
|  | October 31, 2019 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 4.0 |  |  | $ | — |  |  | $ | — |  |  | $ | 4.0 |  |
| Commercial paper | 4.5 |  |  | — |  |  | — |  |  | 4.5 |  |
| U.S. government and agency securities | 15.0 |  |  | — |  |  | — |  |  | 15.0 |  |
| Total available-for-sale cash equivalents | $ | 23.5 |  |  | $ | — |  |  | $ | — |  |  | $ | 23.5 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 23.7 |  |  | $ | — |  |  | $ | — |  |  | $ | 23.7 |  |
| Commercial paper | 15.9 |  |  | — |  |  | — |  |  | 15.9 |  |
| Corporate debt securities | 565.2 |  |  | 3.0 |  |  | — |  |  | 568.2 |  |
| U.S. government and agency securities | 1,454.0 |  |  | 3.6 |  |  | (0.3 | ) |  | 1,457.3 |  |
| Total available-for-sale investments | $ | 2,058.8 |  |  | $ | 6.6 |  |  | $ | (0.3 | ) |  | $ | 2,065.1 |  |
  (was, 2019-05-30, similarity 0.833):
[0001327567-19-000016:note_history:94]
|  | July 31, 2018 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | $ | 52.0 |  |  | $ | — |  |  | $ | — |  |  | $ | 52.0 |  |
| U.S. government and agency securities | 397.3 |  |  | — |  |  | — |  |  | 397.3 |  |
| Total available-for-sale cash equivalents | $ | 449.3 |  |  | $ | — |  |  | $ | — |  |  | $ | 449.3 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 5.4 |  |  | $ | — |  |  | $ | — |  |  | $ | 5.4 |  |
| Non-U.S. government securities | 20.0 |  |  | — |  |  | — |  |  | 20.0 |  |
| Commercial paper | 22.3 |  |  | — |  |  | — |  |  | 22.3 |  |
| Corporate debt securities | 295.9 |  |  | — |  |  | (2.5 | ) |  | 293.4 |  |
| U.S. government and agency securities | 1,110.6 |  |  | — |  |  | (7.7 | ) |  | 1,102.9 |  |
| Total available-for-sale investments | $ | 1,454.2 |  |  | $ | — |  |  | $ | (10.2 | ) |  | $ | 1,444.0 |  |

- changed (2019-11-26):
[0001327567-19-000038:note_history:95]
|  | July 31, 2019 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 12.0 |  |  | $ | — |  |  | $ | — |  |  | $ | 12.0 |  |
| Commercial paper | 19.3 |  |  | — |  |  | — |  |  | 19.3 |  |
| U.S. government and agency securities | 54.4 |  |  | — |  |  | — |  |  | 54.4 |  |
| Total available-for-sale cash equivalents | $ | 85.7 |  |  | $ | — |  |  | $ | — |  |  | $ | 85.7 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 17.5 |  |  | $ | — |  |  | $ | — |  |  | $ | 17.5 |  |
| Commercial paper | 8.9 |  |  | — |  |  | — |  |  | 8.9 |  |
| Corporate debt securities | 587.8 |  |  | 2.3 |  |  | (0.3 | ) |  | 589.8 |  |
| U.S. government and agency securities | 1,799.5 |  |  | 2.6 |  |  | (1.2 | ) |  | 1,800.9 |  |
| Total available-for-sale investments | $ | 2,413.7 |  |  | $ | 4.9 |  |  | $ | (1.5 | ) |  | $ | 2,417.1 |  |
  (was, 2019-05-30, similarity 0.776):
[0001327567-19-000016:note_history:95]
|  | April 30, 2019 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | $ | 27.0 |  |  | $ | — |  |  | $ | — |  |  | $ | 27.0 |  |
| Corporate debt securities | 15.0 |  |  | — |  |  | — |  |  | 15.0 |  |
| U.S. government and agency securities | 340.0 |  |  | — |  |  | — |  |  | 340.0 |  |
| Total available-for-sale cash equivalents | $ | 382.0 |  |  | $ | — |  |  | $ | — |  |  | $ | 382.0 |  |
| Investments: |  |  |  |  |  |  |  |
| Commercial paper | $ | 19.5 |  |  | $ | — |  |  | $ | — |  |  | $ | 19.5 |  |
| Corporate debt securities | 540.5 |  |  | 1.3 |  |  | (0.7 | ) |  | 541.1 |  |
| U.S. government and agency securities | 1,843.2 |  |  | 1.6 |  |  | (2.3 | ) |  | 1,842.5 |  |
| Total available-for-sale investments | $ | 2,403.2 |  |  | $ | 2.9 |  |  | $ | (3.0 | ) |  | $ | 2,403.1 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-11-26):
[0001327567-19-000038:note_history:96]
Cash Equivalents and Investments
Available-for-sale Debt Securities
  (was, 2019-05-30, similarity 0.6465):
[0001327567-19-000016:note_history:96]
Cash Equivalents and Investments

- changed (2019-11-26):
[0001327567-19-000038:note_history:97]
The following tables summarize the amortized cost, unrealized gains and losses, and fair value of our available-for-sale debt securities as of October 31, 2019 and July 31, 2019 (in millions):
  (was, 2019-05-30, similarity 0.958):
[0001327567-19-000016:note_history:97]
The following tables summarize the amortized cost, unrealized gains and losses, and fair value of our available-for-sale securities as of April 30, 2019 and July 31, 2018 (in millions):

- changed (2019-11-26):
[0001327567-19-000038:note_history:98]
|  | October 31, 2019 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 4.0 |  |  | $ | — |  |  | $ | — |  |  | $ | 4.0 |  |
| Commercial paper | 4.5 |  |  | — |  |  | — |  |  | 4.5 |  |
| U.S. government and agency securities | 15.0 |  |  | — |  |  | — |  |  | 15.0 |  |
| Total available-for-sale cash equivalents | $ | 23.5 |  |  | $ | — |  |  | $ | — |  |  | $ | 23.5 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 23.7 |  |  | $ | — |  |  | $ | — |  |  | $ | 23.7 |  |
| Commercial paper | 15.9 |  |  | — |  |  | — |  |  | 15.9 |  |
| Corporate debt securities | 565.2 |  |  | 3.0 |  |  | — |  |  | 568.2 |  |
| U.S. government and agency securities | 1,454.0 |  |  | 3.6 |  |  | (0.3 | ) |  | 1,457.3 |  |
| Total available-for-sale investments | $ | 2,058.8 |  |  | $ | 6.6 |  |  | $ | (0.3 | ) |  | $ | 2,065.1 |  |
  (was, 2019-05-30, similarity 0.833):
[0001327567-19-000016:note_history:98]
|  | July 31, 2018 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | $ | 52.0 |  |  | $ | — |  |  | $ | — |  |  | $ | 52.0 |  |
| U.S. government and agency securities | 397.3 |  |  | — |  |  | — |  |  | 397.3 |  |
| Total available-for-sale cash equivalents | $ | 449.3 |  |  | $ | — |  |  | $ | — |  |  | $ | 449.3 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 5.4 |  |  | $ | — |  |  | $ | — |  |  | $ | 5.4 |  |
| Non-U.S. government securities | 20.0 |  |  | — |  |  | — |  |  | 20.0 |  |
| Commercial paper | 22.3 |  |  | — |  |  | — |  |  | 22.3 |  |
| Corporate debt securities | 295.9 |  |  | — |  |  | (2.5 | ) |  | 293.4 |  |
| U.S. government and agency securities | 1,110.6 |  |  | — |  |  | (7.7 | ) |  | 1,102.9 |  |
| Total available-for-sale investments | $ | 1,454.2 |  |  | $ | — |  |  | $ | (10.2 | ) |  | $ | 1,444.0 |  |

- changed (2019-11-26):
[0001327567-19-000038:note_history:99]
|  | July 31, 2019 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 12.0 |  |  | $ | — |  |  | $ | — |  |  | $ | 12.0 |  |
| Commercial paper | 19.3 |  |  | — |  |  | — |  |  | 19.3 |  |
| U.S. government and agency securities | 54.4 |  |  | — |  |  | — |  |  | 54.4 |  |
| Total available-for-sale cash equivalents | $ | 85.7 |  |  | $ | — |  |  | $ | — |  |  | $ | 85.7 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 17.5 |  |  | $ | — |  |  | $ | — |  |  | $ | 17.5 |  |
| Commercial paper | 8.9 |  |  | — |  |  | — |  |  | 8.9 |  |
| Corporate debt securities | 587.8 |  |  | 2.3 |  |  | (0.3 | ) |  | 589.8 |  |
| U.S. government and agency securities | 1,799.5 |  |  | 2.6 |  |  | (1.2 | ) |  | 1,800.9 |  |
| Total available-for-sale investments | $ | 2,413.7 |  |  | $ | 4.9 |  |  | $ | (1.5 | ) |  | $ | 2,417.1 |  |
  (was, 2019-05-30, similarity 0.776):
[0001327567-19-000016:note_history:99]
|  | April 30, 2019 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | $ | 27.0 |  |  | $ | — |  |  | $ | — |  |  | $ | 27.0 |  |
| Corporate debt securities | 15.0 |  |  | — |  |  | — |  |  | 15.0 |  |
| U.S. government and agency securities | 340.0 |  |  | — |  |  | — |  |  | 340.0 |  |
| Total available-for-sale cash equivalents | $ | 382.0 |  |  | $ | — |  |  | $ | — |  |  | $ | 382.0 |  |
| Investments: |  |  |  |  |  |  |  |
| Commercial paper | $ | 19.5 |  |  | $ | — |  |  | $ | — |  |  | $ | 19.5 |  |
| Corporate debt securities | 540.5 |  |  | 1.3 |  |  | (0.7 | ) |  | 541.1 |  |
| U.S. government and agency securities | 1,843.2 |  |  | 1.6 |  |  | (2.3 | ) |  | 1,842.5 |  |
| Total available-for-sale investments | $ | 2,403.2 |  |  | $ | 2.9 |  |  | $ | (3.0 | ) |  | $ | 2,403.1 |  |

- changed (2019-11-26):
[0001327567-19-000038:note_history:100]
Unrealized losses related to these securities are due to interest rate fluctuations as opposed to credit quality. In addition, we do not intend to sell and it is not likely that we would be required to sell these securities before recovery of their amortized cost basis, which may be at maturity. As a result, there were no other-than-temporary impairments for these securities at October 31, 2019 and July 31, 2019.
  (was, 2019-05-30, similarity 0.9851):
[0001327567-19-000016:note_history:100]
Unrealized losses related to these securities are due to interest rate fluctuations as opposed to credit quality. In addition, we do not intend to sell and it is not likely that we would be required to sell these securities before recovery of their amortized cost basis, which may be at maturity. As a result, there were no other-than-temporary impairments for these securities at April 30, 2019 and July 31, 2018.

- changed (2019-11-26):
[0001327567-19-000038:note_history:101]
The following table summarizes the amortized cost and fair value of our available-for-sale debt securities as of October 31, 2019, by contractual years-to-maturity (in millions):
  (was, 2019-05-30, similarity 0.9555):
[0001327567-19-000016:note_history:101]
The following table summarizes the amortized cost and fair value of our available-for-sale securities as of April 30, 2019, by contractual years-to-maturity (in millions):

- added (2019-11-26):
[0001327567-19-000038:note_history:102]
Marketable equity securities consist of money market funds and are included in cash and cash equivalents in our condensed consolidated balance sheets. As of October 31, 2019 and July 31, 2019, the carrying value of our marketable equity securities were

- added (2019-11-26):
[0001327567-19-000038:note_history:103]
$617.3 million and $369.1 million, respectively. There were no unrealized gains or losses recognized for these securities during the three months ended October 31, 2019 and 2018.

- removed (2019-11-26):
[0001327567-19-000016:note_history:104]
Available-for-sale Securities

- removed (2019-11-26):
[0001327567-19-000016:note_history:105]
Marketable equity securities consist of money market funds and are included in cash and cash equivalents in our condensed consolidated balance sheets. As of April 30, 2019 and July 31, 2018, the carrying value of our marketable equity securities were $155.0 million and $1.5 billion, respectively. There were no unrealized gains or losses recognized for these securities during the three and nine months ended April 30, 2019 and 2018.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: no_current_note, score: 0.0

- removed (2019-11-26):
[0001327567-19-000016:note_history:106]
Related Party Transactions

- removed (2019-11-26):
[0001327567-19-000016:note_history:107]
Certain members of our board of directors are affiliated with Greylock Partners, a venture capital firm. Entities affiliated with Greylock Partners owned a portion of the outstanding shares of Demisto immediately prior to completion of our acquisition of Demisto on March 28, 2019 and, as a result, received purchase consideration valued at $85.6 million during the three months ended April 30, 2019. Refer to Note 6. Acquisitions for more information on our acquisition of Demisto.


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock (revenue_recognition_policy) — matched_by: no_current_note, score: 0.0

- removed (2019-11-26):
[0001327567-19-000016:note_history:108]
Revenue Recognition

- removed (2019-11-26):
[0001327567-19-000016:note_history:109]
Our revenue consists of product revenue and subscription and support revenue. Revenue is recognized when control of promised products, subscriptions and support services are transferred to customers with the expected consideration in exchange for those products and services. Depending on who the contract is with, our customers are either our channel partners or our end-customers.

- removed (2019-11-26):
[0001327567-19-000016:note_history:110]
We determine revenue recognition through the following steps:

- removed (2019-11-26):
[0001327567-19-000016:note_history:111]
| • | Identification of the contract, or contracts, with a customer. |

- removed (2019-11-26):
[0001327567-19-000016:note_history:112]
| • | Identification of the performance obligations in the contract. |

- removed (2019-11-26):
[0001327567-19-000016:note_history:113]
| • | Determination of the transaction price. |

- removed (2019-11-26):
[0001327567-19-000016:note_history:114]
| • | Allocation of the transaction price to the performance obligations in the contract. |

- removed (2019-11-26):
[0001327567-19-000016:note_history:115]
| • | Recognition of revenue when, or as, we satisfy a performance obligation. |

- removed (2019-11-26):
[0001327567-19-000016:note_history:116]
Revenues are reported net of sales taxes. Shipping charges billed to channel partners are included in revenues and related costs are included in cost of revenue.

- removed (2019-11-26):
[0001327567-19-000016:note_history:117]
Product Revenue

- removed (2019-11-26):
[0001327567-19-000016:note_history:118]
Product revenue is derived primarily from sales of our appliances. Product revenue also includes revenue derived from software licenses of Panorama and the VM-Series. We recognize product revenue at the time of hardware shipment or delivery of software license.

- removed (2019-11-26):
[0001327567-19-000016:note_history:119]
Subscription and Support Revenue

- removed (2019-11-26):
[0001327567-19-000016:note_history:120]
Subscription and support revenue is derived primarily from sales of our subscription and support offerings. We recognize subscription and support revenue over time as the services are performed. Our contractual subscription and support contracts are typically one to five years.

- removed (2019-11-26):
[0001327567-19-000016:note_history:121]
Contracts with Multiple Performance Obligations

- removed (2019-11-26):
[0001327567-19-000016:note_history:122]
The majority of our contracts with our customers include various combinations of our products and subscriptions and support which are distinct and accounted for as separate performance obligations. We account for multiple agreements with a single customer as a single contract if the contractual terms and/or substance of those agreements indicate that they may be so closely related that they are, in effect, parts of a single contract. The amount of consideration we expect to receive in exchange for delivering on the contract is allocated to each performance obligation based on its relative standalone selling price. If a contract contains a single performance obligation, no allocation is required.

- removed (2019-11-26):
[0001327567-19-000016:note_history:123]
We establish standalone selling price using the prices charged for a deliverable when sold separately. If the standalone selling price is not observable through past transactions, we estimate the standalone selling price based on our pricing model and our go-to-market strategy, which include factors such as type of sales channel (reseller, distributor, or end-customer), the geographies in which our offerings were sold (domestic or international), and offering type (products, subscriptions, or support).

- removed (2019-11-26):
[0001327567-19-000016:note_history:124]
Deferred Revenue

- removed (2019-11-26):
[0001327567-19-000016:note_history:125]
We record deferred revenue when cash payments are received or due in advance of our performance. Our payment terms typically require payment within 30 to 45 days of the date we issue an invoice. The current portion of deferred revenue represents the amounts that are expected to be recognized as revenue within one year of the condensed consolidated balance sheet date.


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2019-11-26):
[0001327567-19-000038:note_history:126]
Revenue
Disaggregation of Revenue
  (was, 2019-05-30, similarity 0.8621):
[0001327567-19-000016:note_history:126]
Disaggregation of Revenue

- added (2019-11-26):
[0001327567-19-000038:note_history:127]
|  | Three Months Ended October 31, |
|  | 2019 |  | 2018 |
| Revenue: |  |  |  |
| Americas |  |  |  |
| United States | $ | 494.9 |  |  | $ | 415.9 |  |
| Other Americas | 34.7 |  |  | 34.3 |  |
| Total Americas | 529.6 |  |  | 450.2 |  |
| Europe, the Middle East, and Africa (“EMEA”) | 147.6 |  |  | 127.7 |  |
| Asia Pacific and Japan (“APAC”) | 94.7 |  |  | 78.1 |  |
| Total revenue | $ | 771.9 |  |  | $ | 656.0 |  |

- added (2019-11-26):
[0001327567-19-000038:note_history:128]
|  | Three Months Ended October 31, |
|  | 2019 |  | 2018 |
| Revenue: |  |  |  |
| Product | $ | 231.2 |  |  | $ | 240.5 |  |
| Subscription and support |  |  |  |  |  |
| Subscription | 318.6 |  |  | 231.3 |  |
| Support | 222.1 |  |  | 184.2 |  |
| Total subscription and support | 540.7 |  |  | 415.5 |  |
| Total revenue | $ | 771.9 |  |  | $ | 656.0 |  |

- added (2019-11-26):
[0001327567-19-000038:note_history:129]
During the three months ended October 31, 2019, we recognized approximately $485.0 million of revenue pertaining to amounts that were deferred as of July 31, 2019.

- changed (2019-11-26):
[0001327567-19-000038:note_history:130]
Revenue expected to be recognized from remaining performance obligations was $3.1 billion as of October 31, 2019, of which we expect to recognize approximately $1.7 billion over the next 12 months and the remainder thereafter.
Deferred Contract Costs
The following table presents details of our short-term and long-term deferred contract costs as of October 31, 2019 and July 31, 2019 (in millions):
  (was, 2019-05-30, similarity 0.7039):
[0001327567-19-000016:note_history:130]
Revenue expected to be recognized from remaining performance obligations was $2.7 billion as of April 30, 2019, of which we expect to recognize approximately $1.5 billion over the next 12 months and the remainder thereafter.

- changed (2019-11-26):
[0001327567-19-000038:note_history:131]
|  | October 31, 2019 |  | July 31, 2019 |
| Short-term deferred contract costs | $ | 155.4 |  |  | $ | 151.1 |  |
| Long-term deferred contract costs | 317.6 |  |  | 324.2 |  |
| Total deferred contract costs | $ | 473.0 |  |  | $ | 475.3 |  |
  (was, 2019-05-30, similarity 0.9747):
[0001327567-19-000016:note_history:131]
|  | April 30, 2019 |  | July 31, 2018 |
| Short-term deferred contract costs | $ | 125.8 |  |  | $ | 113.2 |  |
| Long-term deferred contract costs | 251.8 |  |  | 224.8 |  |
| Total deferred contract costs | $ | 377.6 |  |  | $ | 338.0 |  |

- changed (2019-11-26):
[0001327567-19-000038:note_history:132]
We recognized amortization expense for our deferred contract costs of $55.6 million and $43.6 million during the three months ended October 31, 2019 and 2018, respectively. We did not recognize any impairment losses on our deferred contract costs during the three months ended October 31, 2019 or 2018.
  (was, 2019-05-30, similarity 0.6728):
[0001327567-19-000016:note_history:132]
We recognized amortization expense for our deferred contract costs of $57.2 million and $147.6 million during the three and nine months ended April 30, 2019, respectively, and $37.7 million and $101.9 million during the three and nine months ended April 30, 2018, respectively. We did not recognize any impairment losses on our deferred contract costs during the three and nine months ended April 30, 2019 or 2018.

- removed (2019-11-26):
[0001327567-19-000016:note_history:133]
Revenue

- removed (2019-11-26):
[0001327567-19-000016:note_history:134]
Revenue Recognition

- removed (2019-11-26):
[0001327567-19-000016:note_history:135]
Our revenue consists of product revenue and subscription and support revenue. Revenue is recognized when control of promised products, subscriptions and support services are transferred to customers with the expected consideration in exchange for those products and services. Depending on who the contract is with, our customers are either our channel partners or our end-customers.

- removed (2019-11-26):
[0001327567-19-000016:note_history:136]
We determine revenue recognition through the following steps:

- removed (2019-11-26):
[0001327567-19-000016:note_history:137]
| • | Identification of the contract, or contracts, with a customer. |

- removed (2019-11-26):
[0001327567-19-000016:note_history:138]
| • | Identification of the performance obligations in the contract. |

- removed (2019-11-26):
[0001327567-19-000016:note_history:139]
| • | Determination of the transaction price. |

- removed (2019-11-26):
[0001327567-19-000016:note_history:140]
| • | Allocation of the transaction price to the performance obligations in the contract. |

- removed (2019-11-26):
[0001327567-19-000016:note_history:141]
| • | Recognition of revenue when, or as, we satisfy a performance obligation. |

- removed (2019-11-26):
[0001327567-19-000016:note_history:142]
Revenues are reported net of sales taxes. Shipping charges billed to channel partners are included in revenues and related costs are included in cost of revenue.

- removed (2019-11-26):
[0001327567-19-000016:note_history:143]
Product Revenue

- removed (2019-11-26):
[0001327567-19-000016:note_history:144]
Product revenue is derived primarily from sales of our appliances. Product revenue also includes revenue derived from software licenses of Panorama and the VM-Series. We recognize product revenue at the time of hardware shipment or delivery of software license.

- removed (2019-11-26):
[0001327567-19-000016:note_history:145]
Subscription and Support Revenue

- removed (2019-11-26):
[0001327567-19-000016:note_history:146]
Subscription and support revenue is derived primarily from sales of our subscription and support offerings. We recognize subscription and support revenue over time as the services are performed. Our contractual subscription and support contracts are typically one to five years.

- removed (2019-11-26):
[0001327567-19-000016:note_history:147]
Contracts with Multiple Performance Obligations

- removed (2019-11-26):
[0001327567-19-000016:note_history:148]
The majority of our contracts with our customers include various combinations of our products and subscriptions and support which are distinct and accounted for as separate performance obligations. We account for multiple agreements with a single customer as a single contract if the contractual terms and/or substance of those agreements indicate that they may be so closely related that they are, in effect, parts of a single contract. The amount of consideration we expect to receive in exchange for delivering on the contract is allocated to each performance obligation based on its relative standalone selling price. If a contract contains a single performance obligation, no allocation is required.

- removed (2019-11-26):
[0001327567-19-000016:note_history:149]
We establish standalone selling price using the prices charged for a deliverable when sold separately. If the standalone selling price is not observable through past transactions, we estimate the standalone selling price based on our pricing model and our go-to-market strategy, which include factors such as type of sales channel (reseller, distributor, or end-customer), the geographies in which our offerings were sold (domestic or international), and offering type (products, subscriptions, or support).

- removed (2019-11-26):
[0001327567-19-000016:note_history:150]
We record deferred revenue when cash payments are received or due in advance of our performance. Our payment terms typically require payment within 30 to 45 days of the date we issue an invoice. The current portion of deferred revenue represents the amounts that are expected to be recognized as revenue within one year of the condensed consolidated balance sheet date. During the nine months ended April 30, 2019, we recognized approximately $955.0 million of revenue pertaining to amounts that were deferred as of July 31, 2018.

- removed (2019-11-26):
[0001327567-19-000016:note_history:151]
|  | Three Months Ended April 30, |  | Nine Months Ended April 30, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
|  |  |  | (As Adjusted) |  |  |  | (As Adjusted) |
| Revenue: |  |  |  |  |  |  |  |
| Americas |  |  |  |  |  |  |  |
| United States | $ | 464.3 |  |  | $ | 358.0 |  |  | $ | 1,314.8 |  |  | $ | 1,030.0 |  |
| Other Americas | 33.5 |  |  | 29.7 |  |  | 108.2 |  |  | 80.3 |  |
| Total Americas | 497.8 |  |  | 387.7 |  |  | 1,423.0 |  |  | 1,110.3 |  |
| Europe, the Middle East, and Africa (“EMEA”) | 138.7 |  |  | 110.1 |  |  | 414.7 |  |  | 312.0 |  |
| Asia Pacific and Japan (“APAC”) | 90.1 |  |  | 69.9 |  |  | 256.1 |  |  | 192.8 |  |
| Total revenue | $ | 726.6 |  |  | $ | 567.7 |  |  | $ | 2,093.8 |  |  | $ | 1,615.1 |  |

- removed (2019-11-26):
[0001327567-19-000016:note_history:152]
|  | Three Months Ended April 30, |  | Nine Months Ended April 30, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
|  |  |  | (As Adjusted) |  |  |  | (As Adjusted) |
| Revenue: |  |  |  |  |  |  |  |
| Product | $ | 278.4 |  |  | $ | 218.1 |  |  | $ | 790.5 |  |  | $ | 607.7 |  |
| Subscription and support |  |  |  |  |  |  |  |
| Subscription | 258.8 |  |  | 192.0 |  |  | 739.8 |  |  | 544.3 |  |
| Support | 189.4 |  |  | 157.6 |  |  | 563.5 |  |  | 463.1 |  |
| Total subscription and support | 448.2 |  |  | 349.6 |  |  | 1,303.3 |  |  | 1,007.4 |  |
| Total revenue | $ | 726.6 |  |  | $ | 567.7 |  |  | $ | 2,093.8 |  |  | $ | 1,615.1 |  |

- removed (2019-11-26):
[0001327567-19-000016:note_history:153]
Deferred Contract Costs

- removed (2019-11-26):
[0001327567-19-000016:note_history:154]
We defer contract costs that are recoverable and incremental to obtaining customer sales contracts. Contract costs, which primarily consist of sales commissions, are amortized on a systematic basis that is consistent with the transfer to the customer of the goods or services to which the asset relates. Sales commissions paid for initial contracts are generally not commensurate with the commissions paid for renewal contracts, given the substantive difference in commission rates in proportion to their respective contract values. Sales commissions for initial contracts that are not commensurate are amortized over a benefit period of five years, consistent with the revenue recognition pattern of the performance obligations in the related contracts including expected renewals. The benefit period is determined by taking into consideration contract length, technology life, and other quantitative and qualitative factors. The expected renewals are estimated based on historical renewal trends. Sales commissions for initial contracts that are commensurate and sales commissions for renewal contracts are amortized over the related contractual period in proportion to the revenue recognized.

- removed (2019-11-26):
[0001327567-19-000016:note_history:155]
We classify deferred contract costs as short-term or long-term based on when we expect to recognize the expense. Short-term deferred contract costs are included in prepaid expenses and other current assets and long-term deferred contract costs are included in other assets in our condensed consolidated balance sheets. Deferred contract costs are periodically reviewed for impairment. The amortization of deferred contract costs is included in sales and marketing expense in our condensed consolidated statements of operations.

- removed (2019-11-26):
[0001327567-19-000016:note_history:156]
The following table presents details of our short-term and long-term deferred contract costs as of April 30, 2019 and July 31, 2018 (in millions):


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- changed (2019-11-26):
[0001327567-19-000038:note_history:157]
Subsequent Event
Business Combination
  (was, 2019-05-30, similarity 0.7018):
[0001327567-19-000016:note_history:157]
Business Combination

- added (2019-11-26):
[0001327567-19-000038:note_history:158]
In November 2019, we entered into a definitive agreement to acquire Aporeto, Inc., a privately-held company, for total consideration of approximately $150.0 million in cash, subject to adjustment. We expect the acquisition will strengthen our Cloud-Native Security Platform capabilities delivered by Prisma Cloud. The acquisition is expected to close during our second quarter of fiscal 2020.

- removed (2019-11-26):
[0001327567-19-000016:note_history:159]
Subsequent Events

- removed (2019-11-26):
[0001327567-19-000016:note_history:160]
In May 2019, we entered into a definitive agreement to acquire Twistlock Ltd. (“Twistlock”), a privately-held container security company, for total consideration of approximately $410.0 million in cash, subject to adjustment. In May 2019, we also entered into a definitive agreement to acquire PureSec Ltd. (“PureSec”), a privately-held serverless security company, for total consideration of approximately $47.0 million in cash, subject to adjustment. We expect the acquisitions will extend our cloud security strategy with the additions of Twistlock and PureSec to our Prisma cloud security offerings. The acquisitions are expected to close during our fourth quarter of fiscal 2019.
