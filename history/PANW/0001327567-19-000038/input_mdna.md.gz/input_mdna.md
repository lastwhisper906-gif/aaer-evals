# PANW MD&A — 0001327567-19-000038


## mdna

[0001327567-19-000038:mdna:1]
[same as prior period, unchanged from 0001327567-19-000016:mdna:1]

[0001327567-19-000038:mdna:2]
[same as prior period, unchanged from 0001327567-19-000016:mdna:4]

[0001327567-19-000038:mdna:3]
[same as prior period, unchanged from 0001327567-19-000016:mdna:5]

[0001327567-19-000038:mdna:4]
[same as prior period, unchanged from 0001327567-19-000016:mdna:6]

[0001327567-19-000038:mdna:5]
| • | Results of Operations. A discussion of the nature and trends in our financial results and an analysis of our financial results comparing the three months ended October 31, 2019 to the three months ended October 31, 2018. |

[0001327567-19-000038:mdna:6]
[same as prior period, unchanged from 0001327567-19-000016:mdna:8]

[0001327567-19-000038:mdna:7]
- 22 -

[0001327567-19-000038:mdna:8]
[same as prior period, unchanged from 0001327567-19-000016:mdna:10]

[0001327567-19-000038:mdna:9]
[same as prior period, unchanged from 0001327567-19-000016:mdna:11]

[0001327567-19-000038:mdna:10]
[same as prior period, unchanged from 0001327567-19-000016:mdna:12]

[0001327567-19-000038:mdna:11]
We have pioneered the next generation of security through our innovative platforms that empower enterprises, service providers, and government entities to secure their organizations by safely enabling applications and data running in their networks, on their endpoints, and in the cloud, and by preventing breaches that stem from targeted cyberattacks. Our platforms use an innovative traffic classification engine that identifies network traffic by application, user, and content and provides consistent security across the network, endpoint, and cloud. Accordingly, our platforms enable our end-customers to pursue transformative digital initiatives, like public cloud and mobility, that grow their business, while maintaining the visibility and control needed to protect their valued data and critical control systems. We believe the architecture of our platforms offers superior performance compared to legacy approaches and reduces the total cost of ownership for organizations by simplifying their security operations and infrastructure and eliminating the need for multiple, stand-alone hardware and software security products, and consists of three primary areas of security capabilities.

[0001327567-19-000038:mdna:12]
[same as prior period, unchanged from 0001327567-19-000016:mdna:14]

[0001327567-19-000038:mdna:13]
[same as prior period, unchanged from 0001327567-19-000016:mdna:15]

[0001327567-19-000038:mdna:14]
[same as prior period, unchanged from 0001327567-19-000016:mdna:16]

[0001327567-19-000038:mdna:15]
[same as prior period, unchanged from 0001327567-19-000016:mdna:17]

[0001327567-19-000038:mdna:16]
| • | Secure the cloud through our Prisma cloud security offerings, such as Prisma Cloud (formerly RedLock) for security and compliance in public and private clouds, Prisma Access (formerly GlobalProtect cloud service) for securing user access, Prisma SaaS (formerly Aperture) for protecting SaaS applications, VM-Series for in-line network security in public and private clouds, and Twistlock for protecting containers in public and private clouds, as well as PureSec for protecting serverless functions in public clouds. |

[0001327567-19-000038:mdna:17]
[same as prior period, unchanged from 0001327567-19-000016:mdna:19]

[0001327567-19-000038:mdna:18]
| • | Secure the future of security operations through Cortex, which includes Cortex XDR (formerly Magnifier) for detection and response, Traps for endpoint protection, Zingbox for Internet of Things (“IoT”) security, Cortex Data Lake (formerly Logging Service) to collect and integrate security data for analytics, Demisto for security orchestration, automation and response (“SOAR”), and AutoFocus for threat intelligence. These products are delivered as software or SaaS subscriptions. |

[0001327567-19-000038:mdna:19]
For the first quarter of fiscal 2020 and 2019, total revenue was $771.9 million and $656.0 million, respectively, representing year-over-year growth of 17.7%. Our growth reflected the increased adoption of our hybrid SaaS revenue model, which consists of product, subscriptions, and support. We believe this model will enable us to benefit from recurring revenues as we continue to grow our installed end-customer base. As of October 31, 2019, we had end-customers in over 150 countries. Our end-customers represent a broad range of industries, including education, energy, financial services, government entities, healthcare, Internet and media, manufacturing, public sector, and telecommunications, and include some of the largest Fortune 100 and Global 2000 companies in the world. We maintain a field sales force that works closely with our channel partners in developing sales opportunities. We use a two-tiered, indirect fulfillment model whereby we sell our products, subscriptions, and support to our distributors, which, in turn, sell to our resellers, which then sell to our end-customers.

[0001327567-19-000038:mdna:20]
Our product revenue was $231.2 million, or 30.0% of total revenue, for the first quarter of fiscal 2020, representing a year-over-year decrease of 3.9%. Product revenue is generated from sales of our appliances, primarily our Next-Generation Firewall, which is available in physical and virtualized form. Our Next-Generation Firewall incorporates our proprietary PAN-OS operating system, which provides a consistent set of capabilities across our entire product line. Our products are designed for different performance requirements throughout an organization, ranging from our PA-220, which is designed for small organizations and remote or branch offices, to our top-of-the-line PA-7080, which is especially suited for very large enterprise deployments and service provider customers. The same firewall functionality that is delivered in our physical appliances is also available in our VM-Series virtual firewalls, which secure virtualized and cloud-based computing environments.

[0001327567-19-000038:mdna:21]
Our subscription and support revenue grew to $540.7 million, or 70.0% of total revenue, for the first quarter of fiscal 2020, representing year-over-year growth of 30.1%. Our subscriptions provide our end-customers with real-time access to the latest

[0001327567-19-000038:mdna:22]
- 23 -

[0001327567-19-000038:mdna:23]
antivirus, intrusion prevention, web filtering, and modern malware prevention capabilities across the network, endpoints, and the cloud. When end-customers purchase our physical or virtual firewall appliances, they typically purchase support in order to receive ongoing security updates, upgrades, bug fixes, and repairs. In addition to the subscriptions purchased with these appliances, end-customers may also purchase other subscriptions on a per-user, per-endpoint, or capacity-based basis.

[0001327567-19-000038:mdna:24]
We continue to invest in innovation as we evolve and further extend the capabilities of our platforms, as we believe that innovation and timely development of new features and products is essential to meeting the needs of our end-customers and improving our competitive position. For example: in September 2019, we acquired Zingbox, Inc. (“Zingbox”), which we believe will accelerate our delivery of IoT security through our Next-Generation Firewall and Cortex platforms.

[0001327567-19-000038:mdna:25]
We believe that the growth of our business and our short-term and long-term success are dependent upon many factors, including our ability to extend our technology leadership, grow our base of end-customers, expand deployment of our platforms and support offerings within existing end-customers, and focus on end-customer satisfaction. To manage any future growth effectively, we must continue to improve and expand our information technology and financial infrastructure, our operating and administrative systems and controls, and our ability to manage headcount, capital, and processes in an efficient manner. While these areas present significant opportunities for us, they also pose challenges and risks that we must successfully address in order to sustain the growth of our business and improve our operating results. For additional information regarding the challenges and risks we face, see the “Risk Factors” section in Part II, Item 1A of this Quarterly Report on Form 10-Q.

[0001327567-19-000038:mdna:26]
[same as prior period, unchanged from 0001327567-19-000016:mdna:27]

[0001327567-19-000038:mdna:27]
[same as prior period, unchanged from 0001327567-19-000016:mdna:28]

[0001327567-19-000038:mdna:28]
|  | October 31, 2019 |  | July 31, 2019 |
|  | (in millions) |
| Total deferred revenue | $ | 3,016.0 |  |  | $ | 2,888.7 |  |
| Cash, cash equivalents, and investments | $ | 3,328.8 |  |  | $ | 3,378.5 |  |

[0001327567-19-000038:mdna:29]
|  | Three Months Ended October 31, |
|  | 2019 |  | 2018 |
|  | (dollars in millions) |
| Total revenue | $ | 771.9 |  |  | $ | 656.0 |  |
| Total revenue year-over-year percentage increase | 17.7 | % |  | 30.7 | % |
| Gross margin | 71.8 | % |  | 72.0 | % |
| Operating loss | $ | (51.8 | ) |  | $ | (32.1 | ) |
| Operating margin | (6.7 | )% |  | (4.9 | )% |
| Billings | $ | 897.4 |  |  | $ | 758.5 |  |
| Billings year-over-year percentage increase | 18.3 | % |  | 27.4 | % |
| Cash flow provided by operating activities | $ | 225.2 |  |  | $ | 252.3 |  |
| Free cash flow (non-GAAP) | $ | 178.0 |  |  | $ | 218.0 |  |

[0001327567-19-000038:mdna:30]
[same as prior period, unchanged from 0001327567-19-000016:mdna:36]

[0001327567-19-000038:mdna:31]
| • | Billings. We define billings as total revenue plus the change in total deferred revenue, net of acquired deferred revenue, during the period. We consider billings to be a key metric used by management to manage our business given our hybrid SaaS revenue model, and believe billings provides investors with an important indicator of the health and visibility of our business because it includes subscription and support revenue, which is recognized ratably over the contractual service period, and product revenue, which is recognized at the time of shipment, provided that all other conditions for revenue recognition have been met. We consider billings to be a useful metric for management and investors, particularly if we continue to experience increased sales of subscriptions and strong renewal rates for subscription and support offerings, and as we monitor our near-term cash flows. While we believe that billings provides useful information to investors and others in understanding and evaluating our operating results in the same manner as our management, it is important to note that other companies, including companies in our industry, may not use billings, may calculate billings differently, |

[0001327567-19-000038:mdna:32]
- 24 -

[0001327567-19-000038:mdna:33]
may have different billing frequencies, or may use other financial measures to evaluate their performance, all of which could reduce the usefulness of billings as a comparative measure. We calculate billings in the following manner:

[0001327567-19-000038:mdna:34]
|  | Three Months Ended October 31, |
|  | 2019 |  | 2018 |
|  | (in millions) |
| Billings: |  |  |  |
| Total revenue | $ | 771.9 |  |  | $ | 656.0 |  |
| Add: change in total deferred revenue, net of acquired deferred revenue | 125.5 |  |  | 102.5 |  |
| Billings | $ | 897.4 |  |  | $ | 758.5 |  |

[0001327567-19-000038:mdna:35]
[same as prior period, unchanged from 0001327567-19-000016:mdna:41]

[0001327567-19-000038:mdna:36]
[same as prior period, unchanged from 0001327567-19-000016:mdna:43]

[0001327567-19-000038:mdna:37]
|  | Three Months Ended October 31, |
|  | 2019 |  | 2018 |
|  | (in millions) |
| Free cash flow (non-GAAP): |  |  |  |
| Net cash provided by operating activities | $ | 225.2 |  |  | $ | 252.3 |  |
| Less: purchases of property, equipment, and other assets | 47.2 |  |  | 34.3 |  |
| Free cash flow (non-GAAP) | $ | 178.0 |  |  | $ | 218.0 |  |
| Net cash provided by (used in) investing activities | $ | 244.5 |  |  | $ | (713.1 | ) |
| Net cash used in financing activities | $ | (167.1 | ) |  | $ | (261.8 | ) |

[0001327567-19-000038:mdna:38]
- 25 -

[0001327567-19-000038:mdna:39]
[same as prior period, unchanged from 0001327567-19-000016:mdna:48]

[0001327567-19-000038:mdna:40]
[same as prior period, unchanged from 0001327567-19-000016:mdna:49]

[0001327567-19-000038:mdna:41]
|  | Three Months Ended October 31, |
|  | 2019 |  | 2018 |
|  | Amount |  | % of Revenue |  | Amount |  | % of Revenue |
|  | (dollars in millions) |
| Revenue: |  |  |  |  |  |  |  |
| Product | $ | 231.2 |  |  | 30.0 | % |  | $ | 240.5 |  |  | 36.7 | % |
| Subscription and support | 540.7 |  |  | 70.0 | % |  | 415.5 |  |  | 63.3 | % |
| Total revenue | 771.9 |  |  | 100.0 | % |  | 656.0 |  |  | 100.0 | % |
| Cost of revenue: |  |  |  |  |  |  |  |
| Product | 65.1 |  |  | 8.4 | % |  | 73.2 |  |  | 11.2 | % |
| Subscription and support | 152.6 |  |  | 19.8 | % |  | 110.3 |  |  | 16.8 | % |
| Total cost of revenue(1) | 217.7 |  |  | 28.2 | % |  | 183.5 |  |  | 28.0 | % |
| Total gross profit | 554.2 |  |  | 71.8 | % |  | 472.5 |  |  | 72.0 | % |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 170.5 |  |  | 22.1 | % |  | 113.4 |  |  | 17.3 | % |
| Sales and marketing | 365.7 |  |  | 47.4 | % |  | 314.6 |  |  | 47.9 | % |
| General and administrative | 69.8 |  |  | 9.0 | % |  | 76.6 |  |  | 11.7 | % |
| Total operating expenses(1) | 606.0 |  |  | 78.5 | % |  | 504.6 |  |  | 76.9 | % |
| Operating loss | (51.8 | ) |  | (6.7 | )% |  | (32.1 | ) |  | (4.9 | )% |
| Interest expense | (18.9 | ) |  | (2.4 | )% |  | (22.7 | ) |  | (3.5 | )% |
| Other income, net | 16.2 |  |  | 2.0 | % |  | 13.0 |  |  | 2.0 | % |
| Loss before income taxes | (54.5 | ) |  | (7.1 | )% |  | (41.8 | ) |  | (6.4 | )% |
| Provision for (benefit from) income taxes | 5.1 |  |  | 0.6 | % |  | (3.5 | ) |  | (0.6 | )% |
| Net loss | $ | (59.6 | ) |  | (7.7 | )% |  | $ | (38.3 | ) |  | (5.8 | )% |

[0001327567-19-000038:mdna:42]
[same as prior period, unchanged from 0001327567-19-000016:mdna:30]

[0001327567-19-000038:mdna:43]
| (1) | Includes share-based compensation as follows: |

[0001327567-19-000038:mdna:44]
|  | Three Months Ended October 31, |
|  | 2019 |  | 2018 |
|  | (in millions) |
| Cost of product revenue | $ | 1.3 |  |  | $ | 1.6 |  |
| Cost of subscription and support revenue | 18.9 |  |  | 17.5 |  |
| Research and development | 62.4 |  |  | 40.5 |  |
| Sales and marketing | 43.8 |  |  | 56.0 |  |
| General and administrative | 24.8 |  |  | 35.5 |  |
| Total share-based compensation | $ | 151.2 |  |  | $ | 151.1 |  |

[0001327567-19-000038:mdna:45]
[same as prior period, unchanged from 0001327567-19-000016:mdna:56]

[0001327567-19-000038:mdna:46]
[same as prior period, unchanged from 0001327567-19-000016:mdna:57]

[0001327567-19-000038:mdna:47]
- 26 -

[0001327567-19-000038:mdna:48]
[same as prior period, unchanged from 0001327567-19-000016:mdna:58]

[0001327567-19-000038:mdna:49]
Product revenue is derived primarily from sales of our appliances. Product revenue also includes revenue derived from software licenses of Panorama and the VM-Series. Our appliances and software licenses include a broad set of built-in networking and security features and functionalities. We generally recognize product revenue at the time of hardware shipment or delivery of software license.

[0001327567-19-000038:mdna:50]
|  | Three Months Ended October 31, |  |  |  |  |
|  | 2019 |  | 2018 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Product | $ | 231.2 |  |  | $ | 240.5 |  |  | $ | (9.3 | ) |  | (3.9 | )% |

[0001327567-19-000038:mdna:51]
Product revenue decreased for the three months ended October 31, 2019 compared to the three months ended October 31, 2018. The decrease was primarily due to a decrease in product unit volume. The change in product revenue due to pricing was not significant.

[0001327567-19-000038:mdna:52]
[same as prior period, unchanged from 0001327567-19-000016:mdna:64]

[0001327567-19-000038:mdna:53]
[same as prior period, unchanged from 0001327567-19-000016:mdna:65]

[0001327567-19-000038:mdna:54]
|  | Three Months Ended October 31, |  |  |  |  |
|  | 2019 |  | 2018 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Subscription | $ | 318.6 |  |  | $ | 231.3 |  |  | $ | 87.3 |  |  | 37.7 | % |
| Support | 222.1 |  |  | 184.2 |  |  | 37.9 |  |  | 20.6 | % |
| Total subscription and support | $ | 540.7 |  |  | $ | 415.5 |  |  | $ | 125.2 |  |  | 30.1 | % |

[0001327567-19-000038:mdna:55]
Subscription and support revenue increased for the three months ended October 31, 2019 compared to the three months ended October 31, 2018. The increase was due to increased demand for our subscription and support offerings from both new and existing end-customers. The mix between subscription revenue and support revenue will fluctuate over time, depending on the introduction of new subscription offerings, renewals of support services, and our ability to increase sales to new and existing end customers. The change in subscription and support revenue due to changes in pricing was not significant.

[0001327567-19-000038:mdna:56]
[same as prior period, unchanged from 0001327567-19-000016:mdna:71]

[0001327567-19-000038:mdna:57]
|  | Three Months Ended October 31, |  |  |  |  |
|  | 2019 |  | 2018 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Americas | $ | 529.6 |  |  | $ | 450.2 |  |  | $ | 79.4 |  |  | 17.6 | % |
| EMEA | 147.6 |  |  | 127.7 |  |  | 19.9 |  |  | 15.6 | % |
| APAC | 94.7 |  |  | 78.1 |  |  | 16.6 |  |  | 21.3 | % |
| Total revenue | $ | 771.9 |  |  | $ | 656.0 |  |  | $ | 115.9 |  |  | 17.7 | % |

[0001327567-19-000038:mdna:58]
With respect to geographic theaters, the Americas contributed the largest portion of the increase in revenue for the three months ended October 31, 2019 compared to the three months ended October 31, 2018, due to its larger and more established sales force compared to our other theaters. Revenue from both Europe, the Middle East, and Africa (“EMEA”) and Asia Pacific and Japan (“APAC”) increased for the three months ended October 31, 2019 compared to the three months ended October 31, 2018, due to our investment in increasing the size of our sales force and number of channel partners in these theaters.

[0001327567-19-000038:mdna:59]
- 27 -

[0001327567-19-000038:mdna:60]
[same as prior period, unchanged from 0001327567-19-000016:mdna:76]

[0001327567-19-000038:mdna:61]
[same as prior period, unchanged from 0001327567-19-000016:mdna:77]

[0001327567-19-000038:mdna:62]
[same as prior period, unchanged from 0001327567-19-000016:mdna:78]

[0001327567-19-000038:mdna:63]
Cost of product revenue primarily includes costs paid to our manufacturing partners. Our cost of product revenue also includes personnel costs, which consist of salaries, benefits, bonuses, share-based compensation, and travel and entertainment associated with our operations organization, amortization of intellectual property licenses, product testing costs, shipping and tariff costs, and allocated costs. Allocated costs consist of certain facilities, depreciation, benefits, recruiting, and information technology costs that we allocate based on headcount. We expect our cost of product revenue to increase as our product revenue increases.

[0001327567-19-000038:mdna:64]
|  | Three Months Ended October 31, |  |  |  |  |
|  | 2019 |  | 2018 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Cost of product revenue | $ | 65.1 |  |  | $ | 73.2 |  |  | $ | (8.1 | ) |  | (11.1 | )% |
| Number of employees at period end | 108 |  |  | 97 |  |  | 11 |  |  | 11.3 | % |

[0001327567-19-000038:mdna:65]
Cost of product revenue decreased for the three months ended October 31, 2019 compared to the three months ended October 31, 2018. The decrease was primarily due to reductions in costs of materials and lower amortization of intellectual property licenses.

[0001327567-19-000038:mdna:66]
[same as prior period, unchanged from 0001327567-19-000016:mdna:83]

[0001327567-19-000038:mdna:67]
Cost of subscription and support revenue includes personnel costs for our global customer support and technical operations organizations, customer support and repair costs, third-party professional services costs, data center and cloud hosting costs, amortization of acquired intangible assets and capitalized software development costs, and allocated costs. We expect our cost of subscription and support revenue to increase as our installed end-customer base grows and adoption of our cloud-based subscription offerings increases.

[0001327567-19-000038:mdna:68]
|  | Three Months Ended October 31, |  |  |  |  |
|  | 2019 |  | 2018 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Cost of subscription and support revenue | $ | 152.6 |  |  | $ | 110.3 |  |  | $ | 42.3 |  |  | 38.3 | % |
| Number of employees at period end | 1,288 |  |  | 985 |  |  | 303 |  |  | 30.8 | % |

[0001327567-19-000038:mdna:69]
Cost of subscription and support revenue increased for the three months ended October 31, 2019 compared to the three months ended October 31, 2018. The increase was primarily due to increased costs to support the growth of our subscription and support business. Personnel costs grew $15.3 million to $73.9 million for the three months ended October 31, 2019 compared to the three months ended October 31, 2018 primarily due to headcount growth. Data center and cloud hosting costs to support the adoption of our cloud-based subscription offerings and costs to expand our customer service capacities increased $12.2 million for the three months ended October 31, 2019 compared to the three months ended October 31, 2018. The remaining increase was primarily due to amortization of purchased intangible assets, which increased $8.1 million for the three months ended October 31, 2019 compared to the three months ended October 31, 2018 as a result of our recent acquisitions.

[0001327567-19-000038:mdna:70]
[same as prior period, unchanged from 0001327567-19-000016:mdna:89]

[0001327567-19-000038:mdna:71]
[same as prior period, unchanged from 0001327567-19-000016:mdna:90]

[0001327567-19-000038:mdna:72]
- 28 -

[0001327567-19-000038:mdna:73]
|  | Three Months Ended October 31, |
|  | 2019 |  | 2018 |
|  | Amount |  | Gross Margin |  | Amount |  | Gross Margin |
|  | (dollars in millions) |
| Product | $ | 166.1 |  |  | 71.8 | % |  | $ | 167.3 |  |  | 69.6 | % |
| Subscription and support | 388.1 |  |  | 71.8 | % |  | 305.2 |  |  | 73.5 | % |
| Total gross profit | $ | 554.2 |  |  | 71.8 | % |  | $ | 472.5 |  |  | 72.0 | % |

[0001327567-19-000038:mdna:74]
Product gross margin increased for the three months ended October 31, 2019 compared to the three months ended October 31, 2018, primarily due to reductions in costs of materials and lower amortization of intellectual property licenses.

[0001327567-19-000038:mdna:75]
Subscription and support gross margin decreased for the three months ended October 31, 2019 compared to the three months ended October 31, 2018, primarily due to an increase in costs to support the adoption of our cloud-based subscription offerings and higher amortization of purchased intangibles as a result of our recent acquisitions, partially offset by increased leverage of our global customer support organization.

[0001327567-19-000038:mdna:76]
[same as prior period, unchanged from 0001327567-19-000016:mdna:97]

[0001327567-19-000038:mdna:77]
Our operating expenses consist of research and development, sales and marketing, and general and administrative expense. Personnel costs are the most significant component of operating expenses and consist of salaries, benefits, bonuses, share-based compensation, travel and entertainment, and with regard to sales and marketing expense, sales commissions. Our operating expenses also include allocated costs, which consist of certain facilities, depreciation, benefits, recruiting, and information technology costs that we allocate based on headcount. We expect operating expenses to increase in absolute dollars and decrease over the long term as a percentage of revenue as we continue to scale our business. As of October 31, 2019, we expect to recognize approximately $1.6 billion of share-based compensation expense over a weighted-average period of approximately 2.8 years, excluding additional share-based compensation expense related to any future grants of share-based awards. Share-based compensation expense is generally recognized on a straight-line basis over the requisite service periods of the awards.

[0001327567-19-000038:mdna:78]
[same as prior period, unchanged from 0001327567-19-000016:mdna:99]

[0001327567-19-000038:mdna:79]
[same as prior period, unchanged from 0001327567-19-000016:mdna:100]

[0001327567-19-000038:mdna:80]
|  | Three Months Ended October 31, |  |  |  |  |
|  | 2019 |  | 2018 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Research and development | $ | 170.5 |  |  | $ | 113.4 |  |  | $ | 57.1 |  |  | 50.4 | % |
| Number of employees at period end | 1,598 |  |  | 1,047 |  |  | 551 |  |  | 52.6 | % |

[0001327567-19-000038:mdna:81]
Research and development expense increased for the three months ended October 31, 2019 compared to the three months ended October 31, 2018. The increase was primarily due to personnel costs, which grew $45.3 million to $133.2 million for the three months ended October 31, 2019 compared to the three months ended October 31, 2018. The increase in personnel costs was primarily due to headcount growth. The remaining increase was primarily driven by an increase in allocated costs.

[0001327567-19-000038:mdna:82]
[same as prior period, unchanged from 0001327567-19-000016:mdna:103]

[0001327567-19-000038:mdna:83]
[same as prior period, unchanged from 0001327567-19-000016:mdna:104]

[0001327567-19-000038:mdna:84]
[same as prior period, unchanged from 0001327567-19-000016:mdna:2]

[0001327567-19-000038:mdna:85]
|  | Three Months Ended October 31, |  |  |  |  |
|  | 2019 |  | 2018 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Sales and marketing | $ | 365.7 |  |  | $ | 314.6 |  |  | $ | 51.1 |  |  | 16.2 | % |
| Number of employees at period end | 3,557 |  |  | 2,826 |  |  | 731 |  |  | 25.9 | % |

[0001327567-19-000038:mdna:86]
Sales and marketing expense increased for the three months ended October 31, 2019 compared to the three months ended October 31, 2018. The increase was primarily due to personnel costs, which grew $35.8 million to $263.1 million for the three months ended October 31, 2019 compared to the three months ended October 31, 2018. The increase in personnel costs was largely due to headcount growth. The remaining increase was primarily driven by an increase in costs associated with marketing-related activities for the three months ended October 31, 2019 compared to the three months ended October 31, 2018.

[0001327567-19-000038:mdna:87]
[same as prior period, unchanged from 0001327567-19-000016:mdna:110]

[0001327567-19-000038:mdna:88]
[same as prior period, unchanged from 0001327567-19-000016:mdna:111]

[0001327567-19-000038:mdna:89]
|  | Three Months Ended October 31, |  |  |  |  |
|  | 2019 |  | 2018 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| General and administrative | $ | 69.8 |  |  | $ | 76.6 |  |  | $ | (6.8 | ) |  | (8.9 | )% |
| Number of employees at period end | 831 |  |  | 690 |  |  | 141 |  |  | 20.4 | % |

[0001327567-19-000038:mdna:90]
General and administrative expense decreased for the three months ended October 31, 2019 compared to the three months ended October 31, 2018, primarily due to personnel costs, which decreased $6.5 million to $46.3 million for the three months ended October 31, 2019 compared to the three months ended October 31, 2018. The decrease was largely due to expense related to the accelerated vesting of certain equity awards in connection with the RedLock acquisition of $14.2 million recognized during the three months ended October 31, 2018, partially offset by an increase of $6.4 million due to headcount growth for the three months ended October 31, 2019 compared to the three months ended October 31, 2018.

[0001327567-19-000038:mdna:91]
[same as prior period, unchanged from 0001327567-19-000016:mdna:116]

[0001327567-19-000038:mdna:92]
Interest expense primarily consists of non-cash interest expense from the amortization of the debt discount and debt issuance costs related to our 0.0% Convertible Senior Notes due 2019 (the “2019 Notes”) and 0.75% Convertible Senior Notes due 2023 (the “2023 Notes” and, together with the 2019 Notes, the “Notes”), and also includes the contractual interest expense related to our 2023 Notes.

[0001327567-19-000038:mdna:93]
|  | Three Months Ended October 31, |  |  |
|  | 2019 |  | 2018 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Interest expense | $ | 18.9 |  |  | $ | 22.7 |  |  | $ | (3.8 | ) |  | (16.7 | )% |

[0001327567-19-000038:mdna:94]
Interest expense decreased for the three months ended October 31, 2019 compared to the three months ended October 31, 2018. The decrease was primarily due to conversions of the 2019 Notes before and upon maturity in July 2019. Refer to Note 9. Debt in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information on the Notes.

[0001327567-19-000038:mdna:95]
[same as prior period, unchanged from 0001327567-19-000016:mdna:21]

[0001327567-19-000038:mdna:96]
[same as prior period, unchanged from 0001327567-19-000016:mdna:120]

[0001327567-19-000038:mdna:97]
[same as prior period, unchanged from 0001327567-19-000016:mdna:121]

[0001327567-19-000038:mdna:98]
|  | Three Months Ended October 31, |  |  |
|  | 2019 |  | 2018 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Other income, net | $ | 16.2 |  |  | $ | 13.0 |  |  | $ | 3.2 |  |  | 24.6 | % |

[0001327567-19-000038:mdna:99]
Other income, net increased for the three months ended October 31, 2019 compared to the three months ended October 31, 2018. The increase was primarily due to a $2.2 million loss recognized related to the settlement of the 2019 Notes converted during the three months ended October 31, 2018. Refer to Note 9. Debt in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information on the Notes.

[0001327567-19-000038:mdna:100]
[same as prior period, unchanged from 0001327567-19-000016:mdna:125]

[0001327567-19-000038:mdna:101]
[same as prior period, unchanged from 0001327567-19-000016:mdna:126]

[0001327567-19-000038:mdna:102]
|  | Three Months Ended October 31, |  | Change |
|  | 2019 |  | 2018 |  | Amount |  | % |
|  | (dollars in millions) |
| Provision for (benefit from) income taxes | $ | 5.1 |  |  | $ | (3.5 | ) |  | $ | 8.6 |  |  | (245.7 | )% |
| Effective tax rate | (9.4 | )% |  | 8.4 | % |  |  |  |  |

[0001327567-19-000038:mdna:103]
We recorded an income tax provision for the three months ended October 31, 2019. The provision for income taxes for the three months ended October 31, 2019 was primarily due to income taxes in profitable foreign jurisdictions, U.S. state taxes, and withholding taxes. Our provision for income taxes increased for the three months ended October 31, 2019 compared to the three months ended October 31, 2018, primarily due to a reduction of one-time tax benefit relating to partial releases of our U.S. valuation allowance resulting from acquisitions. Refer to Note 14. Income Taxes in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information.

[0001327567-19-000038:mdna:104]
[same as prior period, unchanged from 0001327567-19-000016:mdna:129]

[0001327567-19-000038:mdna:105]
|  | October 31, 2019 |  | July 31, 2019 |
|  | (in millions) |
| Working capital | $ | 1,598.2 |  |  | $ | 1,611.5 |  |
| Cash, cash equivalents, and investments: |  |  |  |
| Cash and cash equivalents | $ | 1,263.7 |  |  | $ | 961.4 |  |
| Investments | 2,065.1 |  |  | 2,417.1 |  |
| Total cash, cash equivalents, and investments | $ | 3,328.8 |  |  | $ | 3,378.5 |  |

[0001327567-19-000038:mdna:106]
As of October 31, 2019, our total cash, cash equivalents, and investments of $3.3 billion were held for general corporate purposes, of which approximately $360.7 million was held outside of the United States. As of October 31, 2019, we had no unremitted earnings when evaluating our outside basis difference relating to our U.S. investment in foreign subsidiaries. However, there could be local withholding taxes payable due to various foreign countries if certain lower tier earnings are distributed. Withholding taxes that would be payable upon remittance of these lower tier earnings are not expected to be material.

[0001327567-19-000038:mdna:107]
In July 2018, we issued the 2023 Notes with an aggregate principal amount of $1.7 billion. The 2023 Notes mature on July 1, 2023; however, under certain circumstances, holders may surrender their 2023 Notes for conversion prior to the maturity date. Upon conversion of the 2023 Notes, we will pay cash equal to the aggregate principal amount of the 2023 Notes to be converted, and, at our

[0001327567-19-000038:mdna:108]
[same as prior period, unchanged from 0001327567-19-000016:mdna:32]

[0001327567-19-000038:mdna:109]
election, will pay or deliver cash and/or shares of our common stock for the amount of our conversion obligation in excess of the aggregate principal amount of the 2023 Notes being converted. As of October 31, 2019, all of the 2023 Notes remained outstanding. Refer to Note 9. Debt in Part I, Item 1 of this Quarterly Report on Form 10-Q for information on the Notes.

[0001327567-19-000038:mdna:110]
In September 2018, we entered into a credit agreement (the “Credit Agreement”) that provides for a $400.0 million unsecured revolving credit facility (the “Credit Facility”), with an option to increase the amount of the credit facility up to an additional $350.0 million, subject to certain conditions. As of October 31, 2019, there were no amounts outstanding, and we were in compliance with all covenants under the Credit Agreement. Refer to Note 9. Debt in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information on the Credit Agreement.

[0001327567-19-000038:mdna:111]
In February 2019, our board of directors authorized a $1.0 billion share repurchase program which is funded from available working capital and will expire on December 31, 2020. As of October 31, 2019, $801.9 million remained available for future share repurchases under our current repurchase authorization. Refer to Note 12. Stockholders’ Equity in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information on the repurchase programs.

[0001327567-19-000038:mdna:112]
The following table summarizes our cash flows for the three months ended October 31, 2019 and 2018:

[0001327567-19-000038:mdna:113]
|  | Three Months Ended October 31, |
| 2019 |  | 2018 |
|  | (in millions) |
| Net cash provided by operating activities | $ | 225.2 |  |  | $ | 252.3 |  |
| Net cash provided by (used in) investing activities | 244.5 |  |  | (713.1 | ) |
| Net cash used in financing activities | (167.1 | ) |  | (261.8 | ) |
| Net increase (decrease) in cash, cash equivalents, and restricted cash | $ | 302.6 |  |  | $ | (722.6 | ) |

[0001327567-19-000038:mdna:114]
[same as prior period, unchanged from 0001327567-19-000016:mdna:144]

[0001327567-19-000038:mdna:115]
[same as prior period, unchanged from 0001327567-19-000016:mdna:145]

[0001327567-19-000038:mdna:116]
[same as prior period, unchanged from 0001327567-19-000016:mdna:146]

[0001327567-19-000038:mdna:117]
[same as prior period, unchanged from 0001327567-19-000016:mdna:147]

[0001327567-19-000038:mdna:118]
Cash provided by operating activities during the three months ended October 31, 2019 was $225.2 million, a decrease of $27.1 million compared to the three months ended October 31, 2018. The decrease was primarily due to timing of payments and collections during the three months ended October 31, 2019, partially offset by repayments of the 2019 Notes attributable to the debt discount during the three months ended October 31, 2018.

[0001327567-19-000038:mdna:119]
[same as prior period, unchanged from 0001327567-19-000016:mdna:149]

[0001327567-19-000038:mdna:120]
[same as prior period, unchanged from 0001327567-19-000016:mdna:150]

[0001327567-19-000038:mdna:121]
Cash provided by investing activities during the three months ended October 31, 2019 was $244.5 million, a net change of $957.6 million compared to cash used in investing activities of $713.1 million during the three months ended October 31, 2018. The change was primarily due to lower net purchases of investments and a decrease in net cash payments for business acquisitions during the three months ended October 31, 2019.

[0001327567-19-000038:mdna:122]
[same as prior period, unchanged from 0001327567-19-000016:mdna:153]

[0001327567-19-000038:mdna:123]
[same as prior period, unchanged from 0001327567-19-000016:mdna:154]

[0001327567-19-000038:mdna:124]
[same as prior period, unchanged from 0001327567-19-000016:mdna:42]

[0001327567-19-000038:mdna:125]
Cash used in financing activities during the three months ended October 31, 2019 was $167.1 million, a decrease of $94.7 million compared to the three months ended October 31, 2018. The decrease was primarily due to repayments of our 2019 Notes during the three months ended October 31, 2018, partially offset by repurchases of our common stock during the three months ended October 31, 2019.

[0001327567-19-000038:mdna:126]
[same as prior period, unchanged from 0001327567-19-000016:mdna:164]

[0001327567-19-000038:mdna:127]
As of October 31, 2019, we did not have any relationships with unconsolidated organizations or financial partnerships, such as structured finance or special purpose entities that would have been established for the purpose of facilitating off-balance sheet arrangements or other contractually narrow or limited purposes.

[0001327567-19-000038:mdna:128]
[same as prior period, unchanged from 0001327567-19-000016:mdna:166]

[0001327567-19-000038:mdna:129]
[same as prior period, unchanged from 0001327567-19-000016:mdna:167]

[0001327567-19-000038:mdna:130]
We believe the critical accounting estimates discussed under Item 7, “Management’s Discussion and Analysis of Financial Condition and Results of Operations” in our Annual Report on Form 10-K for the fiscal year ended July 31, 2019 reflect our more significant judgments and estimates used in the preparation of our condensed consolidated financial statements. There have been no significant changes to our critical accounting estimates as filed in such report.

[0001327567-19-000038:mdna:131]
[same as prior period, unchanged from 0001327567-19-000016:mdna:176]

[0001327567-19-000038:mdna:132]
Refer to “Recently Adopted Accounting Pronouncements” and “Recently Issued Accounting Pronouncements” in Note 1. Description of Business and Summary of Significant Accounting Policies in Part I, Item 1 of this Quarterly Report on Form 10-Q.
