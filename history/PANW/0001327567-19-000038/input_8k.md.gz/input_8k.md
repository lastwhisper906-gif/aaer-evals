# PANW 8-K — 0001327567-19-000036 filed 2019-11-25

## item codes, every 8-K on or before 2019-11-26

- 2019-11-25 0001327567-19-000036 — 2.02, 9.01
- 2019-11-25 0001193125-19-299886 — 5.02, 8.01 — amendment of 0001327567-19-000011
- 2019-10-22 0001193125-19-271660 — 5.02
- 2019-09-06 0001327567-19-000026 — 9.01 — amendment of 0001327567-19-000023
- 2019-09-04 0001327567-19-000023 — 2.02, 7.01, 9.01
- 2019-07-11 0001193125-19-192415 — 5.02, 9.01
- 2019-05-29 0001327567-19-000014 — 2.02, 9.01
- 2019-04-15 0001327567-19-000011 — 5.02, 9.01
- 2019-04-01 0001193125-19-094613 — 8.01, 9.01
- 2019-03-28 0001193125-19-090572 — 3.02 — amendment of 0001327567-19-000003
- 2019-02-26 0001327567-19-000006 — 2.02, 8.01, 9.01
- 2019-02-19 0001327567-19-000003 — 3.02
- 2018-12-11 0001327567-18-000033 — 5.07
- 2018-11-29 0001327567-18-000029 — 2.02, 9.01
- 2018-10-15 0001193125-18-299312 — 5.02, 9.01
- 2018-09-25 0001193125-18-282542 — 5.02
- 2018-09-14 0001193125-18-274239 — 5.03, 9.01
- 2018-09-06 0001327567-18-000018 — 1.01, 2.02, 2.03, 9.01
- 2018-07-13 0001193125-18-217281 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2018-06-04 0001327567-18-000011 — 2.02, 5.02, 9.01
- 2018-02-26 0001327567-18-000004 — 2.02, 5.02, 7.01, 9.01
- 2017-12-12 0001193125-17-367477 — 5.07
- 2017-11-20 0001327567-17-000032 — 2.02, 5.02, 9.01
- 2017-08-31 0001327567-17-000021 — 2.02, 5.02, 9.01
- 2017-05-31 0001327567-17-000016 — 2.02, 9.01
- 2017-02-28 0001327567-17-000005 — 2.02, 8.01, 9.01
- 2016-12-12 0001193125-16-790757 — 5.07
- 2016-11-21 0001327567-16-000071 — 2.02, 9.01
- 2016-10-24 0001193125-16-745121 — 5.02, 9.01
- 2016-08-30 0001327567-16-000057 — 2.02, 5.03, 8.01, 9.01
- 2016-08-22 0001193125-16-687588 — 5.02, 9.01
- 2016-05-26 0001327567-16-000051 — 2.02, 9.01
- 2016-02-25 0001327567-16-000044 — 2.02, 5.02, 9.01
- 2015-12-14 0001327567-15-000038 — 5.07
- 2015-12-14 0001193125-15-402588 — 1.01, 9.01
- 2015-11-23 0001327567-15-000033 — 2.02, 9.01
- 2015-10-19 0001193125-15-347005 — 1.01, 9.01 — amendment, the index does not say of what
- 2015-09-09 0001327567-15-000022 — 2.02, 9.01
- 2015-08-19 0001193125-15-296115 — 1.01, 2.03
- 2015-06-01 0001193125-15-207786 — 1.01, 2.03
- 2015-05-27 0001327567-15-000015 — 2.02, 9.01
- 2015-03-02 0001327567-15-000006 — 2.02, 9.01
- 2014-12-15 0001327567-14-000046 — 5.07
- 2014-11-24 0001327567-14-000040 — 2.02, 9.01
- 2014-09-22 0001193125-14-348581 — 5.02, 9.01
- 2014-09-09 0001327567-14-000025 — 2.02, 9.01
- 2014-07-01 0001193125-14-257824 — 1.01, 2.03, 3.02, 9.01
- 2014-06-26 0001193125-14-249529 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2014-06-20 0001327567-14-000020 — 9.01 — amendment of 0001193125-14-140511
- 2014-06-04 0001327567-14-000016 — 3.02
- 2014-05-30 0001193125-14-218158 — 2.02 — amendment, the index does not say of what
- 2014-05-28 0001193125-14-215060 — 1.01, 2.02, 3.02, 9.01
- 2014-04-11 0001193125-14-140511 — 2.01, 3.02, 7.01, 9.01
- 2014-03-24 0001193125-14-111318 — 1.01, 3.02, 7.01, 9.01
- 2014-03-13 0001327567-14-000009 — 5.02
- 2014-02-24 0001193125-14-063754 — 2.02, 9.01
- 2013-12-12 0001327567-13-000040 — 5.07
- 2013-11-25 0001327567-13-000033 — 2.02, 9.01
- 2013-09-30 0001193125-13-384966 — 8.01
- 2013-09-09 0001193125-13-361421 — 2.02, 9.01
- 2013-05-30 0001193125-13-241542 — 2.02, 5.02, 9.01
- 2013-03-11 0001193125-13-101082 — 5.02, 9.01
- 2013-02-28 0001193125-13-084193 — 2.02, 9.01
- 2012-12-14 0001193125-12-503335 — 5.07
- 2012-12-06 0001193125-12-493700 — 2.02, 9.01
- 2012-09-24 0001193125-12-401534 — 1.01, 2.03
- 2012-09-20 0001193125-12-398433 — 5.02, 9.01
- 2012-09-10 0001193125-12-386605 — 2.02, 9.01

## late-filing notifications on or before 2019-11-26

- none on or before 2019-11-26

## item 2.02 — earnings release, exhibit 99.1

[0001327567-19-000036:8k_2_02:1]
EX-99.1
2
ex991q120earningsrelea.htm
EXHIBIT 99.1

[0001327567-19-000036:8k_2_02:2]
Exhibit

[0001327567-19-000036:8k_2_02:3]
Exhibit 99.1

[0001327567-19-000036:8k_2_02:4]
Palo Alto Networks Reports Fiscal First Quarter 2020 Financial Results

[0001327567-19-000036:8k_2_02:5]
| • | Fiscal first quarter revenue grows 18 percent year over year to $771.9 million |

[0001327567-19-000036:8k_2_02:6]
| • | Billings increase 18 percent year over year to $897.4 million |

[0001327567-19-000036:8k_2_02:7]
| • | Deferred revenue grows 26 percent year over year to $3.0 billion |

[0001327567-19-000036:8k_2_02:8]
SANTA CLARA, Calif. — Nov. 25, 2019 — Palo Alto Networks (NYSE: PANW), the global cybersecurity leader, announced today financial results for its fiscal first quarter 2020, ended October 31, 2019.

[0001327567-19-000036:8k_2_02:9]
Total revenue for the fiscal first quarter 2020 grew 18 percent year over year to $771.9 million, compared with total revenue of $656.0 million for the fiscal first quarter 2019. GAAP net loss for the fiscal first quarter 2020 was $59.6 million, or $0.62 per diluted share, compared with GAAP net loss of $38.3 million, or $0.41 per diluted share, for the fiscal first quarter 2019.

[0001327567-19-000036:8k_2_02:10]
Non-GAAP net income for the fiscal first quarter 2020 was $104.8 million, or $1.05 per diluted share, compared with non-GAAP net income of $115.4 million, or $1.17 per diluted share, for the fiscal first quarter 2019. A reconciliation between GAAP and non-GAAP information is contained in the tables below.

[0001327567-19-000036:8k_2_02:11]
“Palo Alto Networks’ multi-platform approach to security is clearly resonating with our customers. Our Next-Gen Security offerings performed extremely well in our first fiscal quarter, bolstering our confidence in our long-term prospects for Prisma and Cortex,” said Nikesh Arora, chairman and CEO of Palo Alto Networks. “At our recent Ignite conference, we introduced significant

[0001327567-19-000036:8k_2_02:12]
product enhancements, including Cortex XDR 2.0, SD-WAN and DLP capabilities for Prisma Access and the integration of Twistlock and PureSec into Prisma Cloud, that should sustain this momentum. Additionally, we expect our proposed acquisition of Aporeto, announced today, will further extend our leadership in cloud security.”

[0001327567-19-000036:8k_2_02:13]
Financial Outlook

[0001327567-19-000036:8k_2_02:14]
Palo Alto Networks provides guidance based on current market conditions and expectations.

[0001327567-19-000036:8k_2_02:15]
For the fiscal second quarter 2020, we expect:

[0001327567-19-000036:8k_2_02:16]
| • | Total revenue in the range of $838 to $848 million, representing year-over-year growth between 18 percent and 19 percent. |

[0001327567-19-000036:8k_2_02:17]
| • | Total billings in the range of $985 million to $1.0 billion, representing year-over-year growth between 16 percent and 17 percent. |

[0001327567-19-000036:8k_2_02:18]
| • | Diluted non-GAAP net income per share in the range of $1.11 to $1.13, which incorporates net expenses related to the proposed acquisition of Aporeto, using 100 to 102 million shares. |

[0001327567-19-000036:8k_2_02:19]
For the fiscal year 2020, we expect:

[0001327567-19-000036:8k_2_02:20]
| • | Total revenue in the range of $3.44 to $3.48 billion, representing year-over-year growth between 19 percent and 20 percent. |

[0001327567-19-000036:8k_2_02:21]
| • | Total billings in the range of $4.105 to $4.165 billion, representing year-over-year growth between 18 percent and 19 percent. |

[0001327567-19-000036:8k_2_02:22]
| • | Diluted non-GAAP net income per share in the range of $4.90 to $5.00, which incorporates net expenses related to the proposed acquisition of Aporeto, using 102 to 104 million shares. |

[0001327567-19-000036:8k_2_02:23]
2

[0001327567-19-000036:8k_2_02:24]
| • | Adjusted free cash flow margin of approximately 29 percent, which includes net expenses and acquisition transaction costs attributable to the proposed acquisition of Aporeto and one-time items, such as cash flow associated with the additional investment in our headquarters in Santa Clara. |

[0001327567-19-000036:8k_2_02:25]
Guidance for non-GAAP financial measures excludes share-based compensation-related charges, including share-based payroll tax expense, acquisition-related costs, amortization expense of acquired intangible assets, litigation-related charges, including legal settlements, facility exit costs, non-cash charges related to convertible notes, foreign currency gains (losses), and income and other tax effects associated with these items, along with certain non-recurring expenses. We have not reconciled diluted non-GAAP net income per share guidance to GAAP net income (loss) per diluted share because we do not provide guidance on GAAP net income (loss) and would not be able to present the various reconciling cash and non-cash items between GAAP net income (loss) and non-GAAP net income, including share-based compensation expense, without unreasonable effort. Share-based compensation expense is impacted by the company's future hiring and retention needs and, to a lesser extent, the future fair market value of the company's common stock, all of which is difficult to predict and subject to constant change. The actual amounts of such reconciling items will have a significant impact on the company's GAAP net income (loss) per diluted share.

[0001327567-19-000036:8k_2_02:26]
Conference Call Information

[0001327567-19-000036:8k_2_02:27]
Palo Alto Networks will host a conference call for analysts and investors to discuss its fiscal first quarter 2020 results and outlook for its fiscal second quarter and full fiscal year 2020 today at 4:30 p.m. Eastern time/1:30 p.m. Pacific time. Open to the public, investors may access the call by dialing 1-888-394-8218 or 1-720-452-9217 and using conference ID 3863128. A live audio

[0001327567-19-000036:8k_2_02:28]
webcast of the conference call, along with supplemental financial information, will also be accessible from the “Investors” section of our website at investors.paloaltonetworks.com. Following the webcast, an archived version will be available on our website for one year. A telephonic replay of the call will be available three hours after the call, will run for ten days, and may be accessed by dialing 1-888-203-1112 or 1-719-457-0820 and entering the passcode 3863128.

[0001327567-19-000036:8k_2_02:29]
Forward-Looking Statements

[0001327567-19-000036:8k_2_02:30]
This press release contains forward-looking statements that involve risks and uncertainties, including statements regarding our proposed acquisition of Aporeto and expectations that it will extend our leadership in cloud security, the benefits and effectiveness of our enhanced product offerings, and our financial outlook for the fiscal second quarter and full fiscal year 2020. There are a significant number of factors that could cause actual results to differ materially from statements made in this press release, including: our limited operating history; our ability as an organization to acquire and integrate other companies, products or technologies in a successful manner; risks associated with managing our rapid growth; the risks associated with new products and subscription and support offerings, including the discovery of software bugs; our competitive position; our ability to attract and retain new customers; delays in the development or release of new subscription offerings, or the failure to timely develop and achieve market acceptance of new products and subscriptions as well as existing products and subscription and support offerings; rapidly evolving technological developments in the market for security products and subscription and support offerings; length of sales cycles; and general market, political, economic and business conditions.

[0001327567-19-000036:8k_2_02:31]
4

[0001327567-19-000036:8k_2_02:32]
Additional risks and uncertainties that could affect our financial results are included under the captions “Risk Factors” and “Management’s Discussion and Analysis of Financial Condition and Results of Operations” in our Annual Report on Form 10-K filed with the SEC on September 9, 2019, which is available on our website at investors.paloaltonetworks.com and on the SEC’s website at www.sec.gov. Additional information will also be set forth in other filings that we make with the SEC from time to time. All forward-looking statements in this press release are based on information available to us as of the date hereof, and we do not assume any obligation to update the forward-looking statements provided to reflect events that occur or circumstances that exist after the date on which they were made.

[0001327567-19-000036:8k_2_02:33]
Non-GAAP Financial Measures and Other Key Metrics

[0001327567-19-000036:8k_2_02:34]
Palo Alto Networks has provided in this press release financial information that has not been prepared in accordance with generally accepted accounting principles in the United States (GAAP). The company uses these non-GAAP financial measures and other key metrics internally in analyzing its financial results and believes that the use of these non-GAAP financial measures and key metrics are useful to investors as an additional tool to evaluate ongoing operating results and trends, and in comparing the company’s financial results with other companies in its industry, many of which present similar non-GAAP financial measures or key metrics.

[0001327567-19-000036:8k_2_02:35]
The presentation of these non-GAAP financial measures and key metrics are not meant to be considered in isolation or as a substitute for comparable GAAP financial measures and should be read only in conjunction with the company’s consolidated financial statements prepared in accordance with GAAP. A reconciliation of the company’s historical non-GAAP financial measures to their most directly comparable GAAP measures has been provided in the financial

[0001327567-19-000036:8k_2_02:36]
statement tables included in this press release, and investors are encouraged to review these reconciliations.

[0001327567-19-000036:8k_2_02:37]
Non-GAAP net income and net income per share, diluted. Palo Alto Networks defines non-GAAP net income as net income (loss) plus share-based compensation-related charges, including share-based payroll tax expense, acquisition-related costs, amortization expense of acquired intangible assets, litigation-related charges, including legal settlements, facility exit costs, non-cash charges related to convertible notes, and intellectual property restructuring-related charges. The company also excludes from non-GAAP net income the foreign currency gains (losses) and tax effects associated with these items in order to provide a complete picture of the company’s recurring core business operating results. The company defines non-GAAP net income per share, diluted, as non-GAAP net income divided by the weighted-average diluted shares outstanding, which includes the potentially dilutive effect of the company’s employee equity incentive plan awards and the company’s convertible senior notes outstanding and related warrants, after giving effect to the anti-dilutive impact of the company’s note hedge agreements, which reduces the potential economic dilution that otherwise would occur upon conversion of the company’s convertible senior notes. Under GAAP, the anti-dilutive impact of the note hedge is not reflected in diluted shares outstanding. The company believes that excluding these items from non-GAAP net income and net income per share, diluted, provides management and investors with greater visibility into the underlying performance of the company’s core business operating results, meaning its operating performance excluding these items and, from time to time, other discrete charges that are infrequent in nature, over multiple periods.

[0001327567-19-000036:8k_2_02:38]
6

[0001327567-19-000036:8k_2_02:39]
Billings. Palo Alto Networks defines billings as total revenue plus the change in total deferred revenue, net of acquired deferred revenue, during the period. The company considers billings to be a key metric used by management to manage the company's business given the company's hybrid-SaaS revenue model, and believes billings provides investors with an important indicator of the health and visibility of the company's business because it includes subscription and support revenue, which is recognized ratably over the contractual service period, and product revenue, which is recognized at the time of shipment, provided that all other conditions for revenue recognition have been met. The company considers billings to be a useful metric for management and investors, particularly if sales of subscriptions continue to increase and the company experiences strong renewal rates for subscriptions and support.

[0001327567-19-000036:8k_2_02:40]
Investors are cautioned that there are a number of limitations associated with the use of non-GAAP financial measures and key metrics as analytical tools. In particular, the billings metric reported by the company includes amounts that have not yet been recognized as revenue. Additionally, many of the adjustments to the company’s GAAP financial measures reflect the exclusion of items that are recurring and will be reflected in the company’s financial results for the foreseeable future, such as share-based compensation, which is an important part of Palo Alto Networks employees’ compensation and impacts their performance. Furthermore, these non-GAAP financial measures are not based on any standardized methodology prescribed by GAAP, and the components that Palo Alto Networks excludes in its calculation of non-GAAP financial measures may differ from the components that its peer companies exclude when they report their non-GAAP results of operations. Palo Alto Networks compensates for these limitations by providing specific information regarding the GAAP amounts excluded from these non-GAAP financial measures. In the future, the company may also exclude non-recurring expenses and other expenses that do not reflect the company’s core business operating results.

[0001327567-19-000036:8k_2_02:41]
7

[0001327567-19-000036:8k_2_02:42]
About Palo Alto Networks

[0001327567-19-000036:8k_2_02:43]
Palo Alto Networks, the global cybersecurity leader, is shaping the cloud-centric future with technology that is transforming the way people and organizations operate. Our mission is to be the cybersecurity partner of choice, protecting our digital way of life. We help address the world's greatest security challenges with continuous innovation that seizes the latest breakthroughs in artificial intelligence, analytics, automation, and orchestration. By delivering an integrated platform and empowering a growing ecosystem of partners, we are at the forefront of protecting tens of thousands of organizations across clouds, networks, and mobile devices. Our vision is a world where each day is safer and more secure than the one before. For more information, visit www.paloaltonetworks.com.

[0001327567-19-000036:8k_2_02:44]
Palo Alto Networks, Prisma, Cortex and the Palo Alto Networks logo are trademarks of Palo Alto Networks, Inc. in the United States and in jurisdictions throughout the world. All other trademarks, trade names or service marks used or mentioned herein belong to their respective owners.

[0001327567-19-000036:8k_2_02:45]
Media Contact:

[0001327567-19-000036:8k_2_02:46]
Mara Mort

[0001327567-19-000036:8k_2_02:47]
Senior Director of Corporate Communications, Palo Alto Networks

[0001327567-19-000036:8k_2_02:48]
Mobile: 1-415-850-8645

[0001327567-19-000036:8k_2_02:49]
mmort@paloaltonetworks.com

[0001327567-19-000036:8k_2_02:50]
Investor Relations Contact:

[0001327567-19-000036:8k_2_02:51]
David Niederman

[0001327567-19-000036:8k_2_02:52]
Vice President of Investor Relations, Palo Alto Networks

[0001327567-19-000036:8k_2_02:53]
Office: 1-669-400-7323

[0001327567-19-000036:8k_2_02:54]
dniederman@paloaltonetworks.com

[0001327567-19-000036:8k_2_02:55]
9

[0001327567-19-000036:8k_2_02:56]
| Palo Alto Networks, Inc. |
| Preliminary Condensed Consolidated Statements of Operations |
| (In millions, except per share data) |
| (Unaudited) |
|  | Three Months Ended October 31, |
|  | 2019 |  | 2018 |
| Revenue: |  |  |  |
| Product | $ | 231.2 |  |  | $ | 240.5 |  |
| Subscription and support | 540.7 |  |  | 415.5 |  |
| Total revenue | 771.9 |  |  | 656.0 |  |
| Cost of revenue: |  |  |  |
| Product | 65.1 |  |  | 73.2 |  |
| Subscription and support | 152.6 |  |  | 110.3 |  |
| Total cost of revenue | 217.7 |  |  | 183.5 |  |
| Total gross profit | 554.2 |  |  | 472.5 |  |
| Operating expenses: |  |  |  |
| Research and development | 170.5 |  |  | 113.4 |  |
| Sales and marketing | 365.7 |  |  | 314.6 |  |
| General and administrative | 69.8 |  |  | 76.6 |  |
| Total operating expenses | 606.0 |  |  | 504.6 |  |
| Operating loss | (51.8 | ) |  | (32.1 | ) |
| Interest expense | (18.9 | ) |  | (22.7 | ) |
| Other income, net | 16.2 |  |  | 13.0 |  |
| Loss before income taxes | (54.5 | ) |  | (41.8 | ) |
| Provision for (benefit from) income taxes | 5.1 |  |  | (3.5 | ) |
| Net loss | $ | (59.6 | ) |  | $ | (38.3 | ) |
| Net loss per share, basic and diluted | $ | (0.62 | ) |  | $ | (0.41 | ) |
| Weighted-average shares used to compute net loss per share, basic and diluted | 96.6 |  |  | 93.8 |  |

[0001327567-19-000036:8k_2_02:57]
10

[0001327567-19-000036:8k_2_02:58]
| Palo Alto Networks, Inc. |
| Reconciliation of GAAP to Non-GAAP Financial Measures |
| (In millions, except per share amounts) |
| (Unaudited) |
|  | Three Months Ended |
|  | October 31, |
|  | 2019 |  | 2018 |
| GAAP net loss | $ | (59.6 | ) |  | $ | (38.3 | ) |
| Share-based compensation-related charges | 153.7 |  |  | 140.7 |  |
| Acquisition-related costs(1) | 3.4 |  |  | 15.5 |  |
| Amortization expense of acquired intangible assets | 16.7 |  |  | 9.3 |  |
| Litigation-related charges(2) | — |  |  | 3.1 |  |
| Non-cash charges related to convertible notes(3) | 15.5 |  |  | 21.6 |  |
| Foreign currency gain associated with non-GAAP adjustments | (0.5 | ) |  | (0.5 | ) |
| Income tax and other tax adjustments related to the above | (24.4 | ) |  | (36.0 | ) |
| Non-GAAP net income | $ | 104.8 |  |  | $ | 115.4 |  |
| GAAP net loss per share, diluted | $ | (0.62 | ) |  | $ | (0.41 | ) |
| Share-based compensation-related charges | 1.56 |  |  | 1.44 |  |
| Acquisition-related costs(1) | 0.04 |  |  | 0.17 |  |
| Amortization expense of acquired intangible assets | 0.17 |  |  | 0.10 |  |
| Litigation-related charges(2) | 0.00 |  |  | 0.03 |  |
| Non-cash charges related to convertible notes(3) | 0.16 |  |  | 0.23 |  |
| Foreign currency gain associated with non-GAAP adjustments | (0.01 | ) |  | (0.01 | ) |
| Income tax and other tax adjustments related to the above | (0.25 | ) |  | (0.38 | ) |
| Non-GAAP net income per share, diluted | $ | 1.05 |  |  | $ | 1.17 |  |
| GAAP weighted-average shares used to compute net loss per share, diluted | 96.6 |  |  | 93.8 |  |
| Weighted-average effect of potentially dilutive securities(4) | 3.5 |  |  | 5.2 |  |
| Non-GAAP weighted-average shares used to compute net income per share, diluted | 100.1 |  |  | 99.0 |  |

[0001327567-19-000036:8k_2_02:59]
| (1) | Consists of acquisition transaction costs, share-based compensation related to the cash settlement of certain equity awards, and costs to terminate certain employment and operating lease contracts of the acquired company. |

[0001327567-19-000036:8k_2_02:60]
| (2) | Consists of the amortization of intellectual property licenses. |

[0001327567-19-000036:8k_2_02:61]
| (3) | Consists primarily of non-cash interest expense related to the company’s convertible senior notes. Also includes a non-cash loss of $2.2 million during the three months ended October 31, 2018, related to early conversions of the convertible notes during the period. |

[0001327567-19-000036:8k_2_02:62]
| (4) | Non-GAAP net income per share, diluted, includes the potentially dilutive effect of employee equity incentive plan awards and convertible senior notes outstanding and related warrants. In addition, non-GAAP net income per share, diluted, includes the anti-dilutive impact of the company’s note hedge agreements, which reduced the potentially dilutive effect of the convertible notes by 1.1 million shares for the three months ended October 31, 2018. |

[0001327567-19-000036:8k_2_02:63]
11

[0001327567-19-000036:8k_2_02:64]
| Palo Alto Networks, Inc. |
| Calculation of Billings |
| (In millions) |
| (Unaudited) |
|  | Three Months Ended |
|  | October 31, |
|  | 2019 |  | 2018 |
| Total revenue | $ | 771.9 |  |  | $ | 656.0 |  |
| Add: change in total deferred revenue, net of acquired deferred revenue | 125.5 |  |  | 102.5 |  |
| Billings | $ | 897.4 |  |  | $ | 758.5 |  |

[0001327567-19-000036:8k_2_02:65]
12

[0001327567-19-000036:8k_2_02:66]
| Palo Alto Networks, Inc. |
| Preliminary Condensed Consolidated Balance Sheets |
| (In millions) |
| (Unaudited) |
|  | October 31, 2019 |  | July 31, 2019 |
| Assets |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 1,263.7 |  |  | $ | 961.4 |  |
| Short-term investments | 1,597.5 |  |  | 1,841.7 |  |
| Accounts receivable, net | 499.2 |  |  | 582.4 |  |
| Prepaid expenses and other current assets | 289.4 |  |  | 279.3 |  |
| Total current assets | 3,649.8 |  |  | 3,664.8 |  |
| Property and equipment, net | 316.4 |  |  | 296.0 |  |
| Operating lease right-of-use assets | 282.6 |  |  | — |  |
| Long-term investments | 467.6 |  |  | 575.4 |  |
| Goodwill | 1,400.4 |  |  | 1,352.3 |  |
| Intangible assets, net | 284.1 |  |  | 280.6 |  |
| Other assets | 423.9 |  |  | 423.1 |  |
| Total assets | $ | 6,824.8 |  |  | $ | 6,592.2 |  |
| Liabilities and stockholders’ equity |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 74.7 |  |  | $ | 73.3 |  |
| Accrued compensation | 125.7 |  |  | 235.5 |  |
| Accrued and other liabilities | 192.3 |  |  | 162.4 |  |
| Deferred revenue | 1,658.9 |  |  | 1,582.1 |  |
| Total current liabilities | 2,051.6 |  |  | 2,053.3 |  |
| Convertible senior notes, net | 1,445.5 |  |  | 1,430.0 |  |
| Long-term deferred revenue | 1,357.1 |  |  | 1,306.6 |  |
| Long-term operating lease liabilities | 371.6 |  |  | — |  |
| Other long-term liabilities | 82.6 |  |  | 216.0 |  |
| Stockholders’ equity: |  |  |  |
| Preferred stock | — |  |  | — |  |
| Common stock and additional paid-in capital | 2,477.5 |  |  | 2,490.9 |  |
| Accumulated other comprehensive loss | (0.6 | ) |  | (3.7 | ) |
| Accumulated deficit | (960.5 | ) |  | (900.9 | ) |
| Total stockholders’ equity | 1,516.4 |  |  | 1,586.3 |  |
| Total liabilities and stockholders’ equity | $ | 6,824.8 |  |  | $ | 6,592.2 |  |

[0001327567-19-000036:8k_2_02:67]
13
