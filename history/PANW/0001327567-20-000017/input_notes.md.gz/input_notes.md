# PANW notes — 0001327567-20-000017


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock

[0001327567-20-000017:notes:1]
[same as prior period, unchanged from 0001327567-20-000007:notes:1]

[0001327567-20-000017:notes:2]
[same as prior period, unchanged from 0001327567-20-000007:notes:2]

[0001327567-20-000017:notes:3]
[same as prior period, unchanged from 0001327567-20-000007:notes:3]

[0001327567-20-000017:notes:4]
[same as prior period, unchanged from 0001327567-20-000007:notes:4]

[0001327567-20-000017:notes:5]
[same as prior period, unchanged from 0001327567-20-000007:notes:5]

[0001327567-20-000017:notes:6]
[same as prior period, unchanged from 0001327567-20-000007:notes:6]

[0001327567-20-000017:notes:7]
[same as prior period, unchanged from 0001327567-20-000007:notes:7]

[0001327567-20-000017:notes:8]
Use of Estimates

[0001327567-20-000017:notes:9]
The preparation of condensed consolidated financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the consolidated financial statements and the reported amounts of revenues and expenses during the reporting period. We base our estimates on historical experience and also on assumptions that we believe are reasonable. Actual results could differ materially from those estimates due to risks and uncertainties, including uncertainty in the current economic environment due to the recent outbreak of COVID-19.

[0001327567-20-000017:notes:10]
[same as prior period, unchanged from 0001327567-20-000007:notes:8]

[0001327567-20-000017:notes:11]
There have been no material changes to our significant accounting policies as of and for the nine months ended April 30, 2020, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended July 31, 2019, except for the change in our accounting policies for leases due to our adoption of new lease accounting guidance. Refer to “Recently Adopted Accounting Pronouncements” below and Note 10. Leases and Other Office Facilities.

[0001327567-20-000017:notes:12]
Recently Adopted Accounting Pronouncements

[0001327567-20-000017:notes:13]
[same as prior period, unchanged from 0001327567-20-000007:notes:11]

[0001327567-20-000017:notes:14]
[same as prior period, unchanged from 0001327567-20-000007:notes:12]

[0001327567-20-000017:notes:15]
[same as prior period, unchanged from 0001327567-20-000007:notes:13]

[0001327567-20-000017:notes:16]
[same as prior period, unchanged from 0001327567-20-000007:notes:14]

[0001327567-20-000017:notes:17]
The adoption of this standard had no impact on our condensed consolidated statements of operations and condensed consolidated statements of cash flows. Refer to Note 10. Leases and Other Office Facilities for further discussion.

[0001327567-20-000017:notes:18]
Recently Issued Accounting Pronouncements

[0001327567-20-000017:notes:19]
[same as prior period, unchanged from 0001327567-20-000007:notes:17]

[0001327567-20-000017:notes:20]
In June 2016, the FASB issued new authoritative guidance on the accounting for credit losses on most financial assets and certain financial instruments. The standard replaces the existing incurred loss model with an expected credit loss model for financial assets measured at amortized cost, including trade receivables, and requires that credit losses on available-for-sale debt securities be presented as an allowance rather than as a write-down. The standard is effective for us in our first quarter of fiscal 2021 and will be applied on a modified retrospective basis. We are currently evaluating whether this standard will have a material impact on our condensed consolidated financial statements.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001327567-20-000017:notes:21]
[same as prior period, unchanged from 0001327567-20-000007:notes:20]

[0001327567-20-000017:notes:22]
[same as prior period, unchanged from 0001327567-20-000007:notes:21]

[0001327567-20-000017:notes:23]
|  | Three Months Ended April 30, |  |  |  | Nine Months Ended April 30, |  |  |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Revenue: |  |  |  |  |  |  |  |
| Americas |  |  |  |  |  |  |  |
| United States | $ | 553.5 |  |  | $ | 464.3 |  |  | $ | 1,554.0 |  |  | $ | 1,314.8 |  |
| Other Americas | 40.7 |  |  | 33.5 |  |  | 114.5 |  |  | 108.2 |  |
| Total Americas | 594.2 |  |  | 497.8 |  |  | 1,668.5 |  |  | 1,423.0 |  |
| Europe, the Middle East, and Africa (“EMEA”) | 171.5 |  |  | 138.7 |  |  | 485.3 |  |  | 414.7 |  |
| Asia Pacific and Japan (“APAC”) | 103.7 |  |  | 90.1 |  |  | 304.2 |  |  | 256.1 |  |
| Total revenue | $ | 869.4 |  |  | $ | 726.6 |  |  | $ | 2,458.0 |  |  | $ | 2,093.8 |  |

[0001327567-20-000017:notes:24]
[same as prior period, unchanged from 0001327567-20-000007:notes:23]

[0001327567-20-000017:notes:25]
|  | Three Months Ended April 30, |  |  |  | Nine Months Ended April 30, |  |  |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Revenue: |  |  |  |  |  |  |  |
| Product | $ | 280.9 |  |  | $ | 278.4 |  |  | $ | 758.6 |  |  | $ | 790.5 |  |
| Subscription and support |  |  |  |  |  |  |  |
| Subscription | 354.3 |  |  | 258.8 |  |  | 1,015.5 |  |  | 739.8 |  |
| Support | 234.2 |  |  | 189.4 |  |  | 683.9 |  |  | 563.5 |  |
| Total subscription and support | 588.5 |  |  | 448.2 |  |  | 1,699.4 |  |  | 1,303.3 |  |
| Total revenue | $ | 869.4 |  |  | $ | 726.6 |  |  | $ | 2,458.0 |  |  | $ | 2,093.8 |  |

[0001327567-20-000017:notes:26]
[same as prior period, unchanged from 0001327567-20-000007:notes:25]

[0001327567-20-000017:notes:27]
During the nine months ended April 30, 2020, we recognized approximately $1,265.0 million of revenue pertaining to amounts that were deferred as of July 31, 2019.

[0001327567-20-000017:notes:28]
[same as prior period, unchanged from 0001327567-20-000007:notes:27]

[0001327567-20-000017:notes:29]
Revenue expected to be recognized from remaining performance obligations was $3.5 billion as of April 30, 2020, of which we expect to recognize approximately $1.9 billion over the next 12 months and the remainder thereafter.
Deferred Contract Costs
The following table presents details of our short-term and long-term deferred contract costs as of April 30, 2020 and July 31, 2019 (in millions):

[0001327567-20-000017:notes:30]
|  | April 30, 2020 |  | July 31, 2019 |
| Short-term deferred contract costs | $ | 173.7 |  |  | $ | 151.1 |  |
| Long-term deferred contract costs | 343.6 |  |  | 324.2 |  |
| Total deferred contract costs | $ | 517.3 |  |  | $ | 475.3 |  |

[0001327567-20-000017:notes:31]
We recognized amortization expense for our deferred contract costs of $60.5 million and $171.4 million during the three and nine months ended April 30, 2020, respectively, and $57.2 million and $147.6 million during the three and nine months ended April 30, 2019, respectively. We did not recognize any impairment losses on our deferred contract costs during the three and nine months ended April 30, 2020 or 2019.


## us-gaap:FairValueMeasurementPolicyPolicyTextBlock

[0001327567-20-000017:notes:32]
Fair Value Measurements 
We categorize assets and liabilities recorded or disclosed at fair value on our condensed consolidated balance sheets based upon the level of judgment associated with inputs used to measure their fair value. The categories are as follows:

[0001327567-20-000017:notes:33]
•Level 1—Inputs are unadjusted quoted prices in active markets for identical assets or liabilities.

[0001327567-20-000017:notes:34]
•Level 2—Inputs are quoted prices for similar assets and liabilities in active markets or inputs that are observable for the assets or liabilities, either directly or indirectly through market corroboration, for substantially the full term of the financial instruments.
•Level 3—Inputs are unobservable inputs based on our own assumptions used to measure assets and liabilities at fair value. The inputs require significant management judgment or estimation.


## us-gaap:FairValueDisclosuresTextBlock

[0001327567-20-000017:notes:35]
•Level 2—Inputs are quoted prices for similar assets and liabilities in active markets or inputs that are observable for the assets or liabilities, either directly or indirectly through market corroboration, for substantially the full term of the financial instruments.

[0001327567-20-000017:notes:36]
•Level 3—Inputs are unobservable inputs based on our own assumptions used to measure assets and liabilities at fair value. The inputs require significant management judgment or estimation.

[0001327567-20-000017:notes:37]
The following table presents the fair value of our financial assets and liabilities measured at fair value on a recurring basis using the above input categories as of April 30, 2020 and July 31, 2019 (in millions):

[0001327567-20-000017:notes:38]
|  |  | April 30, 2020 |  |  |  |  |  |  |  | July 31, 2019 |  |  |  |  |  |  |
|  |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Cash equivalents: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 762.6 |  |  | $ | — |  |  | $ | — |  |  | $ | 762.6 |  |  | $ | 369.1 |  |  | $ | — |  |  | $ | — |  |  | $ | 369.1 |  |
| Certificates of deposit |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 12.0 |  |  |  |  | 12.0 |  |
| Commercial paper |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 19.3 |  |  | — |  |  | 19.3 |  |
| U.S. government and agency securities |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 54.4 |  |  | — |  |  | 54.4 |  |
| Total cash equivalents |  | 762.6 |  |  | — |  |  | — |  |  | 762.6 |  |  | 369.1 |  |  | 85.7 |  |  | — |  |  | 454.8 |  |
| Short-term investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Certificates of deposit |  | — |  |  | 22.3 |  |  | — |  |  | 22.3 |  |  | — |  |  | 17.5 |  |  | — |  |  | 17.5 |  |
| Commercial paper |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 8.9 |  |  | — |  |  | 8.9 |  |
| Corporate debt securities |  | — |  |  | 95.1 |  |  | — |  |  | 95.1 |  |  | — |  |  | 375.5 |  |  | — |  |  | 375.5 |  |
| U.S. government and agency securities |  | — |  |  | 436.7 |  |  | — |  |  | 436.7 |  |  | — |  |  | 1,439.8 |  |  | — |  |  | 1,439.8 |  |
| Total short-term investments |  | — |  |  | 554.1 |  |  | — |  |  | 554.1 |  |  | — |  |  | 1,841.7 |  |  | — |  |  | 1,841.7 |  |
| Long-term investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate debt securities |  | — |  |  | 46.0 |  |  | — |  |  | 46.0 |  |  | — |  |  | 214.3 |  |  | — |  |  | 214.3 |  |
| U.S. government and agency securities |  | — |  |  | 105.2 |  |  | — |  |  | 105.2 |  |  | — |  |  | 361.1 |  |  | — |  |  | 361.1 |  |
| Total long-term investments |  | — |  |  | 151.2 |  |  | — |  |  | 151.2 |  |  | — |  |  | 575.4 |  |  | — |  |  | 575.4 |  |
| Prepaid expenses and other current assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency forward contracts |  | — |  |  | 0.3 |  |  | — |  |  | 0.3 |  |  | — |  |  | 1.3 |  |  | — |  |  | 1.3 |  |
| Total prepaid expenses and other current assets |  | — |  |  | 0.3 |  |  | — |  |  | 0.3 |  |  | — |  |  | 1.3 |  |  | — |  |  | 1.3 |  |
| Total assets measured at fair value |  | $ | 762.6 |  |  | $ | 705.6 |  |  | $ | — |  |  | $ | 1,468.2 |  |  | $ | 369.1 |  |  | $ | 2,504.1 |  |  | $ | — |  |  | $ | 2,873.2 |  |
| Accrued and other liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency forward contracts |  | $ | — |  |  | $ | 3.3 |  |  | $ | — |  |  | $ | 3.3 |  |  | $ | — |  |  | $ | 3.8 |  |  | $ | — |  |  | $ | 3.8 |  |
| Total accrued and other liabilities |  | — |  |  | 3.3 |  |  | — |  |  | 3.3 |  |  | — |  |  | 3.8 |  |  | — |  |  | 3.8 |  |
| Total liabilities measured at fair value |  | $ | — |  |  | $ | 3.3 |  |  | $ | — |  |  | $ | 3.3 |  |  | $ | — |  |  | $ | 3.8 |  |  | $ | — |  |  | $ | 3.8 |  |

[0001327567-20-000017:notes:39]
Refer to Note 9. Debt for the carrying amount and estimated fair value of our convertible senior notes as of April 30, 2020 and July 31, 2019.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001327567-20-000017:notes:40]
Cash Equivalents and Investments
Available-for-sale Debt Securities

[0001327567-20-000017:notes:41]
The following tables summarize the amortized cost, unrealized gains and losses, and fair value of our available-for-sale debt securities as of April 30, 2020 and July 31, 2019 (in millions):

[0001327567-20-000017:notes:42]
|  | April 30, 2020 |  |  |  |  |  |  |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 22.3 |  |  | $ | — |  |  | $ | — |  |  | $ | 22.3 |  |
| Corporate debt securities | 139.4 |  |  | 1.7 |  |  | — |  |  | 141.1 |  |
| U.S. government and agency securities | 537.6 |  |  | 4.3 |  |  | — |  |  | 541.9 |  |
| Total available-for-sale investments | $ | 699.3 |  |  | $ | 6.0 |  |  | $ | — |  |  | $ | 705.3 |  |

[0001327567-20-000017:notes:43]
|  | July 31, 2019 |  |  |  |  |  |  |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 12.0 |  |  | $ | — |  |  | $ | — |  |  | $ | 12.0 |  |
| Commercial paper | 19.3 |  |  | — |  |  | — |  |  | 19.3 |  |
| U.S. government and agency securities | 54.4 |  |  | — |  |  | — |  |  | 54.4 |  |
| Total available-for-sale cash equivalents | $ | 85.7 |  |  | $ | — |  |  | $ | — |  |  | $ | 85.7 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 17.5 |  |  | $ | — |  |  | $ | — |  |  | $ | 17.5 |  |
| Commercial paper | 8.9 |  |  | — |  |  | — |  |  | 8.9 |  |
| Corporate debt securities | 587.8 |  |  | 2.3 |  |  | (0.3) |  |  | 589.8 |  |
| U.S. government and agency securities | 1,799.5 |  |  | 2.6 |  |  | (1.2) |  |  | 1,800.9 |  |
| Total available-for-sale investments | $ | 2,413.7 |  |  | $ | 4.9 |  |  | $ | (1.5) |  |  | $ | 2,417.1 |  |

[0001327567-20-000017:notes:44]
Unrealized losses related to these securities are due to interest rate fluctuations as opposed to credit quality. In addition, we do not intend to sell and it is not likely that we would be required to sell these securities before recovery of their amortized cost basis, which may be at maturity. As a result, there were no other-than-temporary impairments for these securities at April 30, 2020 and July 31, 2019.

[0001327567-20-000017:notes:45]
The following table summarizes the amortized cost and fair value of our available-for-sale debt securities as of April 30, 2020, by contractual years-to-maturity (in millions):

[0001327567-20-000017:notes:46]
|  | Amortized Cost |  | Fair Value |
| Due within one year | $ | 551.0 |  |  | $ | 554.1 |  |
| Due between one and three years | 148.3 |  |  | 151.2 |  |
| Total | $ | 699.3 |  |  | $ | 705.3 |  |

[0001327567-20-000017:notes:47]
Marketable Equity Securities

[0001327567-20-000017:notes:48]
Marketable equity securities consist of money market funds and are included in cash and cash equivalents in our condensed consolidated balance sheets. As of April 30, 2020 and July 31, 2019, the carrying value of our marketable equity securities were $762.6 million and $369.1 million, respectively. There were no unrealized gains or losses recognized for these securities during the three and nine months ended April 30, 2020 and 2019.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001327567-20-000017:notes:49]
Derivative InstrumentsAs a global business, we are exposed to currency exchange rate risk. Substantially all of our revenue is transacted in U.S. dollars, however, a portion of our operating expenditures are incurred outside of the United States and are denominated in foreign currencies, making them subject to fluctuations in foreign currency exchange rates. We enter into foreign currency derivative contracts with maturities of 15 months or less, which we designate as cash flow hedges, to manage the foreign currency exchange rate risk associated with these expenditures.
These derivative contracts expose us to credit risk to the extent that the counterparties may be unable to meet the terms of the arrangement. We mitigate this credit risk by transacting with major financial institutions with high credit ratings and also enter into master netting arrangements, which permit net settlement of transactions with the same counterparty. We are not required to pledge, and are not entitled to receive, cash collateral related to these derivative instruments. We do not enter into derivative contracts for trading or speculative purposes.

[0001327567-20-000017:notes:50]
[same as prior period, unchanged from 0001327567-20-000007:notes:49]

[0001327567-20-000017:notes:51]
As of April 30, 2020 and July 31, 2019, the total notional amount of our outstanding foreign currency forward contracts was $106.0 million and $307.2 million, respectively. Refer to Note 3. Fair Value Measurements for the fair value of our derivative instruments as reported on our condensed consolidated balance sheets as of April 30, 2020.

[0001327567-20-000017:notes:52]
During the three and nine months ended April 30, 2020 and 2019, both unrealized gains and losses recognized in AOCI related to our cash flow hedges and amounts reclassified into earnings were not material. Unrealized losses in AOCI related to our cash flow hedges as of April 30, 2020 and 2019 were not material.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001327567-20-000017:notes:53]
Acquisitions
CloudGenix Inc.

[0001327567-20-000017:notes:54]
On April 21, 2020, we completed our acquisition of 100% of the voting interest of CloudGenix Inc. (“CloudGenix”), a privately-held company. We believe the acquisition will strengthen our secure access service edge (“SASE”) platform. The total purchase consideration for the acquisition of CloudGenix was $402.7 million, which consisted of the following (in millions):

[0001327567-20-000017:notes:55]
|  | Amount |
| Cash | $ | 396.1 |  |
| Fair value of replacement awards | 6.6 |  |
| Total | $ | 402.7 |  |

[0001327567-20-000017:notes:56]
As part of the acquisition, we issued $30.3 million of replacement awards, of which the portion attributable to services performed prior to the acquisition date was allocated to purchase consideration. The remaining fair value was allocated to future services and will be expensed over the remaining service periods as share-based compensation.

[0001327567-20-000017:notes:57]
[same as prior period, unchanged from 0001327567-20-000007:notes:56]

[0001327567-20-000017:notes:58]
|  | Amount |
| Goodwill | $ | 301.2 |  |
| Identified intangible assets | 109.9 |  |
| Cash | 8.3 |  |
| Net liabilities assumed | (16.7) |  |
| Total | $ | 402.7 |  |

[0001327567-20-000017:notes:59]
Goodwill generated from this business combination is primarily attributable to the assembled workforce and expected post-acquisition synergies from integrating CloudGenix technology into our platforms. The goodwill is not deductible for income tax purposes.

[0001327567-20-000017:notes:60]
[same as prior period, unchanged from 0001327567-20-000007:notes:59]

[0001327567-20-000017:notes:61]
|  | Fair Value |  | Estimated Useful Life |
| Developed technology | $ | 67.2 |  |  | 5 years |
| Customer relationships | 42.7 |  |  | 10 years |
| Total | $ | 109.9 |  |  |  |

[0001327567-20-000017:notes:62]
Aporeto, Inc.

[0001327567-20-000017:notes:63]
On December 23, 2019, we completed our acquisition of 100% of the voting interest of Aporeto, Inc. (“Aporeto”), a privately-held machine identity-based microsegmentation company. We believe the acquisition will strengthen our cloud-native security platform capabilities delivered by Prisma Cloud. The total purchase consideration for the acquisition of Aporeto was $144.1 million, which consisted of the following (in millions):

[0001327567-20-000017:notes:64]
[same as prior period, unchanged from 0001327567-20-000007:notes:54]

[0001327567-20-000017:notes:65]
[same as prior period, unchanged from 0001327567-20-000007:notes:55]

[0001327567-20-000017:notes:66]
|  | Amount |
| Goodwill | $ | 111.3 |  |
| Identified intangible assets | 23.8 |  |
| Cash | 10.5 |  |
| Net liabilities assumed | (1.5) |  |
| Total | $ | 144.1 |  |

[0001327567-20-000017:notes:67]
[same as prior period, unchanged from 0001327567-20-000007:notes:58]

[0001327567-20-000017:notes:68]
[same as prior period, unchanged from 0001327567-20-000007:notes:60]

[0001327567-20-000017:notes:69]
[same as prior period, unchanged from 0001327567-20-000007:notes:61]

[0001327567-20-000017:notes:70]
[same as prior period, unchanged from 0001327567-20-000007:notes:62]

[0001327567-20-000017:notes:71]
[same as prior period, unchanged from 0001327567-20-000007:notes:63]

[0001327567-20-000017:notes:72]
|  | Amount |
| Goodwill | $ | 48.1 |  |
| Identified intangible assets | 20.4 |  |
| Net liabilities assumed | (2.1) |  |
| Total | $ | 66.4 |  |

[0001327567-20-000017:notes:73]
[same as prior period, unchanged from 0001327567-20-000007:notes:65]

[0001327567-20-000017:notes:74]
[same as prior period, unchanged from 0001327567-20-000007:notes:66]

[0001327567-20-000017:notes:75]
[same as prior period, unchanged from 0001327567-20-000007:notes:67]

[0001327567-20-000017:notes:76]
[same as prior period, unchanged from 0001327567-20-000007:notes:68]

[0001327567-20-000017:notes:77]
Additional information related to the acquired companies, such as that related to income tax and other contingencies, existing as of the respective acquisition dates but unknown to us may become known during the remainder of the measurement period, not to exceed 12 months from the acquisition date, which may result in changes to the amounts and allocations recorded.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001327567-20-000017:notes:78]
[same as prior period, unchanged from 0001327567-20-000007:notes:70]

[0001327567-20-000017:notes:79]
The following table presents details of our goodwill during the nine months ended April 30, 2020 (in millions):

[0001327567-20-000017:notes:80]
|  | Amount |
| Balance as of July 31, 2019 | $ | 1,352.3 |  |
| Goodwill acquired | 460.6 |  |
| Balance as of April 30, 2020 | $ | 1,812.9 |  |

[0001327567-20-000017:notes:81]
[same as prior period, unchanged from 0001327567-20-000007:notes:73]

[0001327567-20-000017:notes:82]
The following table presents details of our purchased intangible assets as of April 30, 2020 and July 31, 2019 (in millions):

[0001327567-20-000017:notes:83]
|  | April 30, 2020 |  |  |  |  |  | July 31, 2019 |  |  |  |  |
|  | Gross Carrying Amount |  | Accumulated Amortization |  | Net Carrying Amount |  | Gross Carrying Amount |  | Accumulated Amortization |  | Net Carrying Amount |
| Intangible assets subject to amortization: |  |  |  |  |  |  |  |  |  |  |  |
| Developed technology | $ | 425.9 |  |  | $ | (126.5) |  |  | $ | 299.4 |  |  | $ | 318.8 |  |  | $ | (78.7) |  |  | $ | 240.1 |  |
| Customer relationships | 87.6 |  |  | (9.7) |  |  | 77.9 |  |  | 39.8 |  |  | (4.7) |  |  | 35.1 |  |
| Acquired intellectual property | 8.9 |  |  | (5.6) |  |  | 3.3 |  |  | 8.9 |  |  | (5.1) |  |  | 3.8 |  |
| Trade name and trademarks | 9.4 |  |  | (9.4) |  |  | — |  |  | 9.4 |  |  | (9.4) |  |  | — |  |
| Other | 2.2 |  |  | (2.2) |  |  | — |  |  | 2.2 |  |  | (2.2) |  |  | — |  |
| Total intangible assets subject to amortization | 534.0 |  |  | (153.4) |  |  | 380.6 |  |  | 379.1 |  |  | (100.1) |  |  | 279.0 |  |
| Intangible assets not subject to amortization: |  |  |  |  |  |  |  |  |  |  |  |
| In-process research and development | — |  |  | — |  |  | — |  |  | 1.6 |  |  | — |  |  | 1.6 |  |
| Total purchased intangible assets | $ | 534.0 |  |  | $ | (153.4) |  |  | $ | 380.6 |  |  | $ | 380.7 |  |  | $ | (100.1) |  |  | $ | 280.6 |  |

[0001327567-20-000017:notes:84]
We recognized amortization expense of $19.3 million and $54.1 million for the three and nine months ended April 30, 2020, respectively, and $14.7 million and $38.5 million for the three and nine months ended April 30, 2019, respectively.

[0001327567-20-000017:notes:85]
The following table summarizes estimated future amortization expense of our intangible assets as of April 30, 2020 (in millions):

[0001327567-20-000017:notes:86]
|  | Amount |
| Fiscal years ending July 31: |  |
| Remaining 2020 | $ | 22.9 |  |
| 2021 | 89.7 |  |
| 2022 | 85.3 |  |
| 2023 | 59.1 |  |
| 2024 | 51.1 |  |
| 2025 and thereafter | 72.5 |  |
| Total future amortization expense | $ | 380.6 |  |


## us-gaap:DebtDisclosureTextBlock

[0001327567-20-000017:notes:87]
Debt
Convertible Senior Notes

[0001327567-20-000017:notes:88]
In June 2014, we issued $575.0 million aggregate principal amount of 0.0% Convertible Senior Notes due 2019 (the “2019 Notes”), and in July 2018, we issued $1.7 billion aggregate principal amount of 0.75% Convertible Senior Notes due 2023 (the “2023 Notes” and, together with the 2019 Notes, the “Notes”). The 2023 Notes bear interest at a fixed rate of 0.75% per year, payable semi-annually in arrears on January 1 and July 1 of each year, beginning on January 1, 2019. The 2023 Notes are governed by an indenture

[0001327567-20-000017:notes:89]
between us, as the issuer, and U.S. Bank National Association, as Trustee (the “Indenture”). The 2023 Notes are unsecured, unsubordinated obligations and the Indenture governing the 2023 Notes does not contain any financial covenants or restrictions on the payments of dividends, the incurrence of indebtedness, or the issuance or repurchase of securities by us or any of our subsidiaries. The 2019 Notes were converted prior to or settled on the maturity date of July 1, 2019, in accordance with their terms. The 2023 Notes mature on July 1, 2023. We cannot redeem the 2023 Notes prior to maturity.

[0001327567-20-000017:notes:90]
The 2023 Notes are convertible for up to 6.4 million shares of our common stock at an initial conversion rate of approximately 3.7545 shares of common stock per $1,000 principal amount, which is equal to an initial conversion price of approximately $266.35 per share of common stock, subject to adjustments. Holders of the 2023 Notes may surrender their 2023 Notes for conversion at their option at any time prior to the close of business on the business day immediately preceding April 1, 2023, only under the following circumstances:

[0001327567-20-000017:notes:91]
•during any fiscal quarter commencing after the fiscal quarter ending on October 31, 2018 (and only during such fiscal quarter), if the last reported sale price of our common stock for at least 20 trading days (whether or not consecutive) during a period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the applicable conversion price for the 2023 Notes on each applicable trading day (the “sale price condition”);

[0001327567-20-000017:notes:92]
•during the five business day period after any five consecutive trading day period (the “measurement period”), in which the trading price per $1,000 principal amount of the 2023 Notes for each trading day of the measurement period was less than 98% of the product of the last reported sale price of our common stock and the applicable conversion rate for the 2023 Notes on each such trading day; or

[0001327567-20-000017:notes:93]
•upon the occurrence of specified corporate events.

[0001327567-20-000017:notes:94]
On or after April 1, 2023, holders may surrender all or any portion of their 2023 Notes for conversion at any time prior to the close of business on the second scheduled trading day immediately preceding the maturity date regardless of the foregoing conditions, and such conversions will be settled upon the maturity date. Upon conversion, holders of the 2023 Notes will receive cash equal to the aggregate principal amount of the 2023 Notes to be converted, and, at our election, cash and/or shares of our common stock for any amounts in excess of the aggregate principal amount of the 2023 Notes being converted.

[0001327567-20-000017:notes:95]
The conversion price will be subject to adjustment in some events. Holders who convert their 2023 Notes in connection with certain corporate events that constitute a “make-whole fundamental change” under the Indenture are, under certain circumstances, entitled to an increase in the conversion rate. Additionally, upon the occurrence of a corporate event that constitutes a “fundamental change” under the Indenture, holders of the 2023 Notes may require us to repurchase for cash all or a portion of the 2023 Notes at a repurchase price equal to 100% of the principal amount of the 2023 Notes plus accrued and unpaid interest to, but excluding, the fundamental change repurchase date.

[0001327567-20-000017:notes:96]
The sale price condition was not met for the 2023 Notes during the fiscal quarters ended April 30, 2020 or July 31, 2019. Since the 2023 Notes were not convertible, the net carrying amount of the 2023 Notes was classified as a long-term liability and the equity component was included in additional paid-in capital in our condensed consolidated balance sheets as of April 30, 2020 and July 31, 2019. As of April 30, 2020, all of the 2023 Notes remained outstanding.

[0001327567-20-000017:notes:97]
The following table sets forth the components of the 2023 Notes as of April 30, 2020 and July 31, 2019 (in millions):

[0001327567-20-000017:notes:98]
|  | April 30, 2020 |  | July 31, 2019 |
| Liability component: |  |  |  |
| Principal | $ | 1,693.0 |  |  | $ | 1,693.0 |  |
| Less: debt discount and debt issuance costs, net of amortization | 216.0 |  |  | 263.0 |  |
| Net carrying amount | $ | 1,477.0 |  |  | $ | 1,430.0 |  |
| Equity component | $ | 315.0 |  |  | $ | 315.0 |  |

[0001327567-20-000017:notes:99]
The total estimated fair value of the 2023 Notes was $1.7 billion and $1.9 billion at April 30, 2020 and July 31, 2019, respectively. The fair value was determined based on the closing trading price per $100 of the 2023 Notes as of the last day of trading for the period. We consider the fair value of the 2023 Notes at April 30, 2020 and July 31, 2019 to be a Level 2 measurement. The fair value of the 2023 Notes is primarily affected by the trading price of our common stock and market interest rates. Based on the closing price of our common stock on April 30, 2020, the if-converted value of the 2023 Notes was less than its principal amount.

[0001327567-20-000017:notes:100]
The following table sets forth interest expense recognized related to the Notes (dollars in millions):

[0001327567-20-000017:notes:101]
|  | Three Months Ended April 30, |  |  |  |  |  |  |  |  |  |  |  | Nine Months Ended April 30, |  |  |  |  |  |  |  |  |  |  |
|  | 2020 |  |  |  |  |  | 2019 |  |  |  |  |  | 2020 |  |  |  |  |  | 2019 |  |  |  |  |
|  | 2019 Notes |  | 2023 Notes |  | Total |  | 2019 Notes |  | 2023 Notes |  | Total |  | 2019 Notes |  | 2023 Notes |  | Total |  | 2019 Notes |  | 2023 Notes |  | Total |
| Contractual interest expense | $ | — |  |  | $ | 3.2 |  |  | $ | 3.2 |  |  | $ | — |  |  | $ | 3.3 |  |  | $ | 3.3 |  |  | $ | — |  |  | $ | 9.5 |  |  | $ | 9.5 |  |  | $ | — |  |  | $ | 9.6 |  |  | $ | 9.6 |  |
| Amortization of debt discount | — |  |  | 15.3 |  |  | 15.3 |  |  | 1.6 |  |  | 14.7 |  |  | 16.3 |  |  | — |  |  | 45.5 |  |  | 45.5 |  |  | 7.6 |  |  | 43.6 |  |  | 51.2 |  |
| Amortization of debt issuance costs | — |  |  | 0.5 |  |  | 0.5 |  |  | 0.3 |  |  | 0.5 |  |  | 0.8 |  |  | — |  |  | 1.5 |  |  | 1.5 |  |  | 1.0 |  |  | 1.4 |  |  | 2.4 |  |
| Total interest expense recognized | $ | — |  |  | $ | 19.0 |  |  | $ | 19.0 |  |  | $ | 1.9 |  |  | $ | 18.5 |  |  | $ | 20.4 |  |  | $ | — |  |  | $ | 56.5 |  |  | $ | 56.5 |  |  | $ | 8.6 |  |  | $ | 54.6 |  |  | $ | 63.2 |  |
| Effective interest rate of the liability component | — | % |  | 5.2 | % |  |  |  | 4.8 | % |  | 5.2 | % |  |  |  | — | % |  | 5.2 | % |  |  |  | 4.8 | % |  | 5.2 | % |  |  |

[0001327567-20-000017:notes:102]
Note Hedges

[0001327567-20-000017:notes:103]
To minimize the impact of potential economic dilution upon conversion of the Notes, we entered into separate convertible note hedge transactions (the “2019 Note Hedges,” with respect to the 2019 Notes, and the “2023 Note Hedges,” with respect to the 2023 Notes, and collectively, the “Note Hedges”) with respect to our common stock concurrent with the issuance of each series of Notes.

[0001327567-20-000017:notes:104]
Upon the settlement of the 2019 Notes, we exercised the corresponding portion of our 2019 Note Hedges during the year ended July 31, 2019 and received shares of our common stock that fully offset the shares issued in excess of the principal amount of the converted 2019 Notes. The 2019 Note Hedges expired upon maturity of the 2019 Notes.

[0001327567-20-000017:notes:105]
The 2023 Note Hedges cover up to 6.4 million shares of our common stock at a strike price per share that corresponds to the initial applicable conversion price of the 2023 Notes, which are also subject to adjustment, and are exercisable upon conversion of the 2023 Notes. The 2023 Note Hedges will expire upon maturity of the 2023 Notes. The 2023 Note Hedges are separate transactions and are not part of the terms of 2023 Notes. Holders of the 2023 Notes will not have any rights with respect to the 2023 Note Hedges. Any shares of our common stock receivable by us under the 2023 Note Hedges are excluded from the calculation of diluted earnings per share as they are antidilutive. We paid an aggregate amount of $332.0 million for the 2023 Note Hedges, which is included in additional paid-in capital in our consolidated balance sheets.

[0001327567-20-000017:notes:106]
Warrants

[0001327567-20-000017:notes:107]
Separately, but concurrently with the issuance of each series of Notes, we entered into transactions whereby we sold warrants (the “2019 Warrants,” with respect to the 2019 Notes, and the “2023 Warrants,” with respect to the 2023 Notes, and collectively, the “Warrants”) to acquire shares of our common stock, subject to anti-dilution adjustments. The 2019 Warrants became exercisable beginning October 2019 and the 2023 Warrants are exercisable beginning October 2023.

[0001327567-20-000017:notes:108]
The following table presents details of the Warrants (in millions, except per share data):

[0001327567-20-000017:notes:109]
|  | Initial Number of Shares |  | Strike Price per Share |  | Aggregate Proceeds |
| 2019 Warrants | 5.2 |  |  | $ | 137.85 |  |  | $ | 78.3 |  |
| 2023 Warrants | 6.4 |  |  | $ | 417.80 |  |  | $ | 145.4 |  |

[0001327567-20-000017:notes:110]
The shares issuable under the Warrants will be included in the calculation of diluted earnings per share when the average market value per share of our common stock for the reporting period exceeds the applicable strike price for such series of Warrants. The Warrants are separate transactions and are not part of either series of Notes or Note Hedges and are not remeasured through earnings each reporting period. Holders of the Notes of either series will not have any rights with respect to the Warrants. The aggregate proceeds received from the sale of the Warrants are included in additional paid-in capital in our consolidated balance sheets.

[0001327567-20-000017:notes:111]
During the nine months ended April 30, 2020, we net settled all 2019 Warrants with 2.0 million shares or $462.0 million in fair value of our common stock. The number of net shares issued was determined based on the number of 2019 Warrants exercised multiplied by the difference between the strike price of the 2019 Warrants and their daily volume weighted-average stock price.

[0001327567-20-000017:notes:112]
Revolving Credit Facility

[0001327567-20-000017:notes:113]
On September 4, 2018, we entered into a credit agreement (the “Credit Agreement”) with certain institutional lenders that provides for a $400.0 million unsecured revolving credit facility (the “Credit Facility”), with an option to increase the amount of the

[0001327567-20-000017:notes:114]
Credit Facility by up to an additional $350.0 million, subject to certain conditions. The Credit Facility matures on the earlier of (i) September 4, 2023 and (ii) the date that is 91 days prior to the stated maturity of our 2023 Notes if (a) any of the 2023 Notes are still outstanding and (b) our unrestricted cash and cash equivalents are less than the then outstanding principal amount of our 2023 Notes plus $400.0 million.

[0001327567-20-000017:notes:115]
The borrowings under the Credit Facility bear interest, at our option, at a base rate plus a spread of 0.00% to 0.75%, or an adjusted LIBO rate plus a spread of 1.00% to 1.75%, in each case with such spread being determined based on our leverage ratio. We are obligated to pay an ongoing commitment fee on undrawn amounts at a rate of 0.125% to 0.250%, depending on our leverage ratio. As of April 30, 2020, there were no amounts outstanding and we were in compliance with all covenants under the Credit Agreement.


## us-gaap:LesseeOperatingLeasesTextBlock

[0001327567-20-000017:notes:116]
Leases and Other Office Facilities
We determine if an arrangement is a lease at inception. We evaluate classification of leases at commencement and, as necessary, at modification. Operating leases are included in operating lease right-of-use assets, accrued and other liabilities, and long-term operating lease liabilities on our condensed consolidated balance sheets beginning August 1, 2019. We did not have any material finance leases in any of the periods presented.

[0001327567-20-000017:notes:117]
[same as prior period, unchanged from 0001327567-20-000007:notes:109]

[0001327567-20-000017:notes:118]
[same as prior period, unchanged from 0001327567-20-000007:notes:110]

[0001327567-20-000017:notes:119]
[same as prior period, unchanged from 0001327567-20-000007:notes:111]

[0001327567-20-000017:notes:120]
We have entered into various non-cancelable operating leases primarily for our facilities with original lease periods expiring through the year ending July 31, 2028.

[0001327567-20-000017:notes:121]
In December 2019, we entered into lease termination agreements for our previous corporate headquarters in Santa Clara, California, which we ceased use of in August 2017. Under the arrangements, we terminated these leases effective in December 2019, prior to their expiration date of July 2023. The early termination fee is $25.0 million, payable in equal quarterly installments from April 2020 through July 2023. Upon termination, we recorded a decrease of $13.6 million in operating lease liabilities based on the payment schedule of the early termination fee discounted by the incremental borrowing rate for the remaining payment term. We also decreased right-of-use asset by $8.7 million upon surrendering possession of the properties. As a result, during the nine months ended April 30, 2020, we recorded a gain of $3.1 million net of other related fees of $1.8 million in general and administrative expense in our condensed consolidated statements of operations.

[0001327567-20-000017:notes:122]
During the three months ended April 30, 2020, our net cost for operating leases was $19.6 million and primarily consisted of operating lease costs of $17.1 million, in addition to variable lease costs, short-term lease costs, and sublease income. During the nine months ended April 30, 2020, our net cost for operating leases was $53.1 million and primarily consisted of operating lease costs of $46.3 million, in addition to variable lease costs, short-term lease costs and sublease income.

[0001327567-20-000017:notes:123]
[same as prior period, unchanged from 0001327567-20-000007:notes:115]

[0001327567-20-000017:notes:124]
|  | Nine Months Ended |
|  | April 30, 2020 |
| Operating cash flows used in payments of operating lease liabilities | $ | 50.3 |  |
| Right-of-use assets obtained in exchange for new operating lease liabilities | $ | 21.0 |  |
|  | April 30, 2020 |
| Weighted-average remaining lease term | 7.2 years |
| Weighted-average discount rate | 3.9 | % |

[0001327567-20-000017:notes:125]
The following table presents maturities of operating lease liabilities as of April 30, 2020 (in millions):

[0001327567-20-000017:notes:126]
|  | Amount |
| Fiscal years ending July 31: |  |
| Remaining 2020 | $ | 15.0 |  |
| 2021 | 73.9 |  |
| 2022 | 67.0 |  |
| 2023 | 61.2 |  |
| 2024 | 50.5 |  |
| 2025 and thereafter | 195.9 |  |
| Total operating lease payments | 463.5 |  |
| Less: imputed interest | 61.6 |  |
| Present value of operating lease liabilities | $ | 401.9 |  |
| Current portion of operating lease liabilities(1) | $ | 57.3 |  |
| Long-term operating lease liabilities | $ | 344.6 |  |

[0001327567-20-000017:notes:127]
[same as prior period, unchanged from 0001327567-20-000007:notes:119]

[0001327567-20-000017:notes:128]
(1) Current portion of operating lease liabilities is included in accrued and other liabilities on our condensed consolidated balance sheet.

[0001327567-20-000017:notes:129]
Operating lease liabilities above do not include sublease income. As of April 30, 2020, we expect to receive sublease income of approximately $5.1 million, which consists of $1.3 million to be received for the remainder of fiscal 2020 and $3.8 million to be received in fiscal 2021.

[0001327567-20-000017:notes:130]
During the three months ended April 30, 2020, we purchased 5.8 acres of land in Santa Clara, California for $51.7 million to accommodate future expansion of our headquarters. This amount was recorded in property and equipment, net on our condensed consolidated balance sheets as of April 30, 2020.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001327567-20-000017:notes:131]
Commitments and Contingencies
Purchase Commitments

[0001327567-20-000017:notes:132]
Manufacturing Purchase Commitments

[0001327567-20-000017:notes:133]
Our electronics manufacturing service provider (“EMS provider”) procures components and assembles our products based on our forecasts. These forecasts are based on estimates of demand for our products primarily for the next 12 months, which are in turn based on historical trends and an analysis from our sales and product management organizations, adjusted for overall market conditions. In order to reduce manufacturing lead times and plan for adequate supply, we may issue non-cancelable orders for products and components to our manufacturing partners or component suppliers. As of April 30, 2020, our purchase commitments under such orders were $124.3 million excluding obligations under contracts that we can cancel without a significant penalty.

[0001327567-20-000017:notes:134]
Other Purchase Commitments

[0001327567-20-000017:notes:135]
We have entered into various non-cancelable agreements with third-party providers for our use of certain cloud and other services, under which we are committed to minimum or fixed purchases through the year ending July 31, 2026. The following table presents details of the aggregate future non-cancelable purchase commitments under these agreements as of April 30, 2020 (in millions):

[0001327567-20-000017:notes:136]
|  | Amount |
| Fiscal years ending July 31: |  |
| Remaining 2020 | $ | 1.7 |  |
| 2021 | 11.7 |  |
| 2022 | 49.8 |  |
| 2023 | 58.5 |  |
| 2024 | 67.5 |  |
| 2025 and thereafter | 97.5 |  |
| Total other purchase commitments | $ | 286.7 |  |

[0001327567-20-000017:notes:137]
Mutual Covenant Not to Sue and Release Agreement

[0001327567-20-000017:notes:138]
In January 2020, we executed a Mutual Covenant Not to Sue and Release Agreement for $50.0 million, to extend an existing covenant not to sue for seven years. As the primary benefit of the arrangement was attributable to future use, the amount was recorded in other assets on our condensed consolidated balance sheets and is amortized to cost of product revenue in our condensed consolidated statements of operations over the estimated period of benefit of seven years. This amount was paid in the three months ended April 30, 2020.

[0001327567-20-000017:notes:139]
Litigation

[0001327567-20-000017:notes:140]
We are subject to legal proceedings, claims, and litigation arising in the ordinary course of business, including intellectual property litigation. Such matters are subject to many uncertainties and outcomes are not predictable with assurance. We accrue for contingencies when we believe that a loss is probable and that we can reasonably estimate the amount of any such loss.

[0001327567-20-000017:notes:141]
To the extent there is a reasonable possibility that a loss exceeding amounts already recognized may be incurred and the amount of such additional loss would be material, we will either disclose the estimated additional loss or state that such an estimate cannot be made. As of April 30, 2020, we have not recorded any significant accruals for loss contingencies associated with such legal proceedings, determined that an unfavorable outcome is probable or reasonably possible, or determined that the amount or range of any possible loss is reasonably estimable.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001327567-20-000017:notes:142]
[same as prior period, unchanged from 0001327567-20-000007:notes:133]

[0001327567-20-000017:notes:143]
[same as prior period, unchanged from 0001327567-20-000007:notes:134]

[0001327567-20-000017:notes:144]
During the nine months ended April 30, 2020, we repurchased and retired 0.9 million shares of our common stock under the authorization for an aggregate purchase price of $198.1 million, including transaction costs. The total price of the shares repurchased and related transaction costs are reflected as a reduction to common stock and additional paid-in capital on our condensed consolidated balance sheets. As of April 30, 2020, $801.9 million remained available for future share repurchases under our current repurchase authorization.

[0001327567-20-000017:notes:145]
Accelerated Stock Repurchase

[0001327567-20-000017:notes:146]
In February 2020, our board of directors approved the repurchase of $1.0 billion of our common stock through an accelerated share repurchase (“ASR”) transaction with a financial institution. This ASR transaction is in addition to our share repurchase program.

[0001327567-20-000017:notes:147]
During the three months ended April 30, 2020, we made an up-front payment of $1.0 billion pursuant to the ASR to receive an initial delivery of approximately 80% of the common stock, or 4.2 million shares valued at $800.0 million. The final number of shares to be repurchased under the ASR will be based generally upon the volume weighted average price of our common stock during the repurchase period, which is expected to be completed in our fourth quarter of fiscal 2020. The shares received by us were retired and the upfront payment was accounted for as a reduction to stockholders' equity of $1.0 billion in our condensed consolidated statements of stockholders’ equity for the three and nine months ended April 30, 2020.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001327567-20-000017:notes:148]
[same as prior period, unchanged from 0001327567-20-000007:notes:136]

[0001327567-20-000017:notes:149]
CloudGenix Inc. Stock Incentive Plan

[0001327567-20-000017:notes:150]
In connection with our acquisition of CloudGenix in April 2020, we assumed CloudGenix’s 2013 Equity Incentive Plan (the “CloudGenix Plan”), under which the assumed CloudGenix equity awards were granted. The assumed equity awards will be settled in shares of our common stock and will retain the terms and conditions under which they were originally granted; forfeited awards will not be returned to the CloudGenix Plan. No additional equity awards will be granted under the CloudGenix Plan. Refer to Note 6. Acquisitions for more information on the CloudGenix acquisition and the related equity awards assumed.

[0001327567-20-000017:notes:151]
[same as prior period, unchanged from 0001327567-20-000007:notes:137]

[0001327567-20-000017:notes:152]
In connection with our acquisition of Aporeto in December 2019, we assumed Aporeto’s 2015 Stock Option and Grant Plan, as amended and restated (the “Aporeto Plan”), under which the assumed Aporeto equity awards were granted. The assumed equity awards will be settled in shares of our common stock and will retain the terms and conditions under which they were originally

[0001327567-20-000017:notes:153]
granted; forfeited awards will not be returned to the Aporeto Plan. No additional equity awards will be granted under the Aporeto Plan. Refer to Note 6. Acquisitions for more information on the Aporeto acquisition and the related equity awards assumed.

[0001327567-20-000017:notes:154]
[same as prior period, unchanged from 0001327567-20-000007:notes:139]

[0001327567-20-000017:notes:155]
In connection with our acquisition of Zingbox in September 2019, we assumed Zingbox’s Stock Incentive Plan, as amended and restated (the “Zingbox Plan”), under which the assumed Zingbox equity awards were granted. The assumed equity awards will be settled in shares of our common stock and will retain the terms and conditions under which they were originally granted; forfeited awards will not be returned to the Zingbox Plan. No additional equity awards will be granted under the Zingbox Plan. Refer to Note 6. Acquisitions for more information on the Zingbox acquisition and the related equity awards assumed.

[0001327567-20-000017:notes:156]
[same as prior period, unchanged from 0001327567-20-000007:notes:141]

[0001327567-20-000017:notes:157]
[same as prior period, unchanged from 0001327567-20-000007:notes:142]

[0001327567-20-000017:notes:158]
|  | Stock Options Outstanding |  |  |  |  |  |  |  | PSOs Outstanding |  |  |  |  |  |  |
|  | Number of Shares |  | Weighted-Average Exercise Price Per Share |  | Weighted-Average Remaining Contractual Term(Years) |  | Aggregate Intrinsic Value |  | Number of Shares |  | Weighted-Average Exercise Price Per Share |  | Weighted-Average Remaining Contractual Term(Years) |  | Aggregate Intrinsic Value |
| Balance—July 31, 2019 | 0.3 |  | $ | 14.53 |  |  | 2.2 |  | $ | 81.4 |  |  | 3.7 |  | $ | 193.99 |  |  | 6.2 |  | $ | 120.1 |  |
| Exercised | (0.1) |  |  | $ | 11.66 |  |  |  |  |  |  | — |  |  | $ | — |  |  |  |  |  |
| Forfeited | — |  |  | $ | — |  |  |  |  |  |  | (0.8) |  | $ | 193.51 |  |  |  |  |  |
| Balance—April 30, 2020 | 0.2 |  | $ | 17.57 |  |  | 1.7 |  | $ | 33.3 |  |  | 2.9 |  | $ | 194.11 |  |  | 5.5 |  | $ | 9.4 |  |
| Exercisable—April 30, 2020 | 0.2 |  | $ | 17.57 |  |  | 1.7 |  | $ | 33.3 |  |  | 2.9 |  | $ | 194.11 |  |  | 5.5 |  | $ | 9.4 |  |

[0001327567-20-000017:notes:159]
[same as prior period, unchanged from 0001327567-20-000007:notes:144]

[0001327567-20-000017:notes:160]
[same as prior period, unchanged from 0001327567-20-000007:notes:145]

[0001327567-20-000017:notes:161]
|  | RSAs Outstanding |  |  |  | PSAs Outstanding |  |  |
|  | Number of Shares |  | Weighted-Average Grant-Date Fair Value Per Share |  | Number of Shares |  | Weighted-Average Grant-Date Fair Value Per Share |
| Balance—July 31, 2019 | 0.0 |  |  | $ | 148.54 |  |  | 0.1 |  |  | $ | 148.54 |  |
| Vested | 0.0 |  |  | $ | 148.54 |  |  | 0.0 |  |  | $ | 148.54 |  |
| Balance—April 30, 2020 | 0.0 |  |  | $ | 148.54 |  |  | 0.1 |  |  | $ | 148.54 |  |

[0001327567-20-000017:notes:162]
[same as prior period, unchanged from 0001327567-20-000007:notes:147]

[0001327567-20-000017:notes:163]
|  | RSUs Outstanding |  |  |  |  |  |  |  | PSUs Outstanding |  |  |  |  |  |  |
|  | Number of Shares |  | Weighted-Average Grant-Date Fair Value Per Share |  | Weighted-Average Remaining Contractual Term(Years) |  | Aggregate Intrinsic Value |  | Number of Shares |  | Weighted-Average Grant-Date Fair Value Per Share |  | Weighted-Average Remaining Contractual Term(Years) |  | Aggregate Intrinsic Value |
| Balance—July 31, 2019 | 6.9 |  | $ | 188.16 |  |  | 1.5 |  | $ | 1,554.0 |  |  | 0.3 |  | $ | 197.86 |  |  | 1.8 |  | $ | 67.0 |  |
| Granted | 3.1 |  | $ | 208.19 |  |  |  |  |  |  | — |  |  | $ | — |  |  |  |  |  |
| Vested | (2.0) |  | $ | 178.93 |  |  |  |  |  |  | 0.0 |  |  | $ | 168.17 |  |  |  |  |  |
| Forfeited | (0.9) |  | $ | 185.56 |  |  |  |  |  |  | (0.1) |  | $ | 181.48 |  |  |  |  |  |
| Balance—April 30, 2020 | 7.1 |  | $ | 199.76 |  |  | 1.5 |  | $ | 1,400.7 |  |  | 0.2 |  | $ | 202.99 |  |  | 1.3 |  | $ | 42.1 |  |

[0001327567-20-000017:notes:164]
[same as prior period, unchanged from 0001327567-20-000007:notes:149]

[0001327567-20-000017:notes:165]
[same as prior period, unchanged from 0001327567-20-000007:notes:150]

[0001327567-20-000017:notes:166]
[same as prior period, unchanged from 0001327567-20-000007:notes:151]

[0001327567-20-000017:notes:167]
|  | Three Months Ended |  |  |  | Nine Months Ended |  |  |
|  | April 30, |  |  |  | April 30, |  |  |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Cost of product revenue | $ | 1.4 |  |  | $ | 1.3 |  |  | $ | 4.2 |  |  | $ | 4.3 |  |
| Cost of subscription and support revenue | 18.8 |  |  | 17.2 |  |  | 57.6 |  |  | 52.9 |  |
| Research and development | 67.7 |  |  | 45.1 |  |  | 197.4 |  |  | 129.6 |  |
| Sales and marketing | 55.5 |  |  | 54.5 |  |  | 155.0 |  |  | 169.2 |  |
| General and administrative | 22.7 |  |  | 20.1 |  |  | 76.0 |  |  | 75.7 |  |
| Total share-based compensation | $ | 166.1 |  |  | $ | 138.2 |  |  | $ | 490.2 |  |  | $ | 431.7 |  |

[0001327567-20-000017:notes:168]
During the three and nine months ended April 30, 2020, we accelerated the vesting of certain equity awards in connection with our acquisitions, as a result, we recorded $0.3 million and $6.0 million, respectively, of share-based compensation within general and administrative expense.

[0001327567-20-000017:notes:169]
As of April 30, 2020, total compensation cost related to unvested share-based awards not yet recognized was $1.6 billion. This cost is expected to be amortized over a weighted-average period of approximately 2.6 years. Future grants will increase the amount of compensation expense to be recorded in these periods.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001327567-20-000017:notes:170]
For the three and nine months ended April 30, 2020 our provision for income taxes reflects an effective tax rate of negative 10.3% and negative 13.5% respectively. Our effective tax rate for the nine months ended April 30, 2020 was negative as we recorded a provision for income taxes on year to date losses. The provision for income taxes for the nine months ended April 30, 2020 is primarily due to income taxes in profitable foreign jurisdictions, U.S. state taxes, and withholding taxes. Our effective tax rates differ from the U.S. statutory tax rate primarily due to deductibility of our share-based compensation, foreign income at other than U.S. tax rates, and changes in our valuation allowance.

[0001327567-20-000017:notes:171]
In December 2019, we transferred certain intellectual property rights to a wholly owned United Kingdom subsidiary, primarily to align our legal structure to our evolving operations. This resulted in an increase in the tax basis of these intellectual property rights and a corresponding increase in foreign deferred tax assets. As of April 30, 2019, it is not more likely than not that these additional deferred tax assets will be realizable, and therefore, are offset by a full valuation allowance. This resulted in no net impact to our condensed consolidated financial statements.

[0001327567-20-000017:notes:172]
Our provision for income taxes for the three and nine months ended April 30, 2019 reflects an effective tax rate of 4.3% and negative 0.3%, respectively. Our effective tax rate for the nine months ended April 30, 2019 was negative as we recorded a provision for income taxes on year to date losses. The key components of our income tax provision, excluding one-time items, primarily consisted of foreign and U.S. state income taxes and withholding taxes. During the nine months ended April 30, 2019, the effect of these key components was partially offset by a one-time tax benefit of $9.4 million and $4.9 million from partial releases of our valuation allowance related to the acquisitions of RedLock, Inc. and Demisto, Inc., recorded during the three months ended October 31, 2018 and April 30, 2019, respectively. Our effective tax rate differed from the U.S. statutory tax rate primarily due to deductibility of our share-based compensation, foreign income at other than U.S. tax rates, and changes in our valuation allowance.


## us-gaap:EarningsPerShareTextBlock

[0001327567-20-000017:notes:173]
[same as prior period, unchanged from 0001327567-20-000007:notes:159]

[0001327567-20-000017:notes:174]
[same as prior period, unchanged from 0001327567-20-000007:notes:160]

[0001327567-20-000017:notes:175]
|  | Three Months Ended |  |  |  | Nine Months Ended |  |  |
|  | April 30, |  |  |  | April 30, |  |  |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Net loss | $ | (74.8) |  |  | $ | (20.2) |  |  | $ | (208.1) |  |  | $ | (61.1) |  |
| Weighted-average shares used to compute net loss per share, basic and diluted | 96.7 |  |  | 94.4 |  |  | 97.2 |  |  | 94.1 |  |
| Net loss per share, basic and diluted | $ | (0.77) |  |  | $ | (0.21) |  |  | $ | (2.14) |  |  | $ | (0.65) |  |

[0001327567-20-000017:notes:176]
[same as prior period, unchanged from 0001327567-20-000007:notes:162]

[0001327567-20-000017:notes:177]
|  | Three and Nine Months Ended |  |  |
|  | April 30, |  |  |
|  | 2020 |  | 2019 |
| Convertible senior notes | 6.4 |  |  | 7.8 |  |
| Warrants related to the issuance of convertible senior notes | 6.4 |  |  | 11.6 |  |
| RSUs and PSUs | 7.3 |  |  | 7.0 |  |
| Options to purchase common stock, including PSOs | 3.1 |  |  | 4.2 |  |
| RSAs and PSAs | 0.1 |  |  | 0.1 |  |
| ESPP shares | 0.1 |  |  | 0.1 |  |
| Total | 23.4 |  |  | 30.8 |  |


## us-gaap:OtherNonoperatingIncomeAndExpenseTextBlock

[0001327567-20-000017:notes:178]
[same as prior period, unchanged from 0001327567-20-000007:notes:164]

[0001327567-20-000017:notes:179]
|  | Three Months Ended |  |  |  | Nine Months Ended |  |  |
|  | April 30, |  |  |  | April 30, |  |  |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Interest income | $ | 8.3 |  |  | $ | 18.3 |  |  | $ | 38.0 |  |  | $ | 51.7 |  |
| Foreign currency exchange gains (losses), net | 0.2 |  |  | (0.1) |  |  | (1.8) |  |  | (1.3) |  |
| Other | (0.4) |  |  | — |  |  | (1.1) |  |  | (3.2) |  |
| Total other income, net | $ | 8.1 |  |  | $ | 18.2 |  |  | $ | 35.1 |  |  | $ | 47.2 |  |
