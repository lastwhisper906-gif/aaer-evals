# PANW MD&A — 0001327567-20-000017


## mdna

[0001327567-20-000017:mdna:1]
ITEM 2.  MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS

[0001327567-20-000017:mdna:2]
[same as prior period, unchanged from 0001327567-20-000007:mdna:2]

[0001327567-20-000017:mdna:3]
•Overview. A discussion of our business and overall analysis of financial and other highlights in order to provide context for the remainder of MD&A.

[0001327567-20-000017:mdna:4]
•Key Financial Metrics. A summary of our generally accepted accounting principles (“GAAP”) and non-GAAP key financial metrics, which management monitors to evaluate our performance.

[0001327567-20-000017:mdna:5]
•Results of Operations. A discussion of the nature and trends in our financial results and an analysis of our financial results comparing the three and nine months ended April 30, 2020 to the three and nine months ended April 30, 2019.

[0001327567-20-000017:mdna:6]
•Liquidity and Capital Resources. An analysis of changes in our balance sheets and cash flows, and a discussion of our financial condition and our ability to meet cash needs.

[0001327567-20-000017:mdna:7]
•Critical Accounting Estimates. A discussion of our accounting policies that require critical estimates, assumptions, and judgments.

[0001327567-20-000017:mdna:8]
•Recent Accounting Pronouncements. A discussion of expected impacts of impending accounting changes on financial information to be reported in the future.

[0001327567-20-000017:mdna:9]
[same as prior period, unchanged from 0001327567-20-000007:mdna:9]

[0001327567-20-000017:mdna:10]
[same as prior period, unchanged from 0001327567-20-000007:mdna:10]

[0001327567-20-000017:mdna:11]
[same as prior period, unchanged from 0001327567-20-000007:mdna:34]

[0001327567-20-000017:mdna:12]
[same as prior period, unchanged from 0001327567-20-000007:mdna:11]

[0001327567-20-000017:mdna:13]
•Secure the network through our Next-Generation Firewalls, available as physical appliances, virtual appliances called VM-Series, or a cloud-delivered service called Prisma Access (formerly GlobalProtect cloud service), Panorama management delivered as an appliance or as a virtual machine for the public or private cloud, and Zingbox IoT Guardian for Internet of Things (“IoT”) security. This also includes security services such as WildFire, Threat Prevention, URL Filtering, GlobalProtect, DNS Security and SD-WAN that are delivered as SaaS subscriptions to our Next-Generation Firewalls. In addition, CloudGenix SD-WAN remains available as a combination of physical, virtual and cloud-delivered appliances and services.

[0001327567-20-000017:mdna:14]
[same as prior period, unchanged from 0001327567-20-000007:mdna:15]

[0001327567-20-000017:mdna:15]
•Secure the cloud through our Prisma security offerings, such as Prisma Cloud (formerly RedLock, Twistlock and PureSec) with comprehensive security and compliance coverage for cloud native applications, data and the full cloud native technology stack, throughout the full development lifecycle and across multi- and hybrid- cloud environments, Prisma SaaS (formerly Aperture) for protecting SaaS applications and VM-Series for in-line network security in multi- and hybrid- cloud environments.

[0001327567-20-000017:mdna:16]
[same as prior period, unchanged from 0001327567-20-000007:mdna:17]

[0001327567-20-000017:mdna:17]
•Secure the future of security operations through Cortex, which includes Cortex XDR for prevention, detection and response (one unified product that was formerly Cortex XDR and Traps), Cortex SOAR (formerly Demisto) for security orchestration, automation and response (“SOAR”), AutoFocus for threat intelligence, and Cortex Data Lake to collect and integrate security data for analytics. These products are delivered as software or SaaS subscriptions.

[0001327567-20-000017:mdna:18]
For the third quarter of fiscal 2020 and 2019, total revenue was $869.4 million and $726.6 million, respectively, representing year-over-year growth of 19.7%. Our growth reflected the increased adoption of our hybrid SaaS revenue model, which consists of product, subscriptions, and support. We believe this model will enable us to benefit from recurring revenues as we continue to grow our installed end-customer base. As of April 30, 2020, we had end-customers in more than 150 countries. Our end-customers represent a broad range of industries, including education, energy, financial services, government entities, healthcare, Internet and media, manufacturing, public sector, and telecommunications, and include some of the largest Fortune 100 and Global 2000 companies in the world. We maintain a field sales force that works closely with our channel partners in developing sales opportunities. We use a two-tiered, indirect fulfillment model whereby we sell our products, subscriptions, and support to our distributors, which, in turn, sell to our resellers, which then sell to our end-customers.

[0001327567-20-000017:mdna:19]
Our product revenue was $280.9 million, or 32.3% of total revenue, for the third quarter of fiscal 2020, representing a year-over-year growth of 0.9%. Product revenue is generated from sales of our appliances, primarily our Next-Generation Firewall, which is available in physical and virtualized form. Our Next-Generation Firewall incorporates our proprietary PAN-OS operating system, which provides a consistent set of capabilities across our entire product line. Our products are designed for different performance requirements throughout an organization, ranging from our PA-220, which is designed for small organizations and remote or branch offices, to our top-of-the-line PA-7080, which is especially suited for very large enterprise deployments and service provider customers. The same firewall functionality that is delivered in our physical appliances is also available in our VM-Series virtual firewalls, which secure virtualized and cloud-based computing environments.

[0001327567-20-000017:mdna:20]
Our subscription and support revenue grew to $588.5 million, or 67.7% of total revenue, for the third quarter of fiscal 2020, representing a year-over-year growth of 31.3%. Our subscriptions provide our end-customers with real-time access to the latest antivirus, intrusion prevention, web filtering, and modern malware prevention capabilities across the network, endpoints, and the cloud. When end-customers purchase our physical or virtual firewall appliances, they typically purchase support in order to receive ongoing security updates, upgrades, bug fixes, and repairs. In addition to the subscriptions purchased with these appliances, end-customers may also purchase other subscriptions on a per-user, per-endpoint, or capacity-based basis.

[0001327567-20-000017:mdna:21]
We continue to invest in innovation as we evolve and further extend the capabilities of our platforms, as we believe that innovation and timely development of new features and products is essential to meeting the needs of our end-customers and improving our competitive position. For example, in April 2020, we acquired CloudGenix Inc. (“CloudGenix”), which we believe will strengthen our secure access service edge (“SASE”) platform.

[0001327567-20-000017:mdna:22]
In general, we believe that the growth of our business and our short-term and long-term success are dependent upon many factors, including our ability to extend our technology leadership, grow our base of end-customers, expand deployment of our platforms and support offerings within existing end-customers, and focus on end-customer satisfaction. To manage any future growth effectively, we must continue to improve and expand our information technology and financial infrastructure, our operating and administrative systems and controls, and our ability to manage headcount, capital, and processes in an efficient manner. While these areas present significant opportunities for us, they also pose challenges and risks that we must successfully address in order to sustain the growth of our business and improve our operating results. For additional information regarding the challenges and risks we face, see the “Risk Factors” section in Part II, Item 1A of this Quarterly Report on Form 10-Q.

[0001327567-20-000017:mdna:23]
[same as prior period, unchanged from 0001327567-20-000007:mdna:40]

[0001327567-20-000017:mdna:24]
COVID-19 Update

[0001327567-20-000017:mdna:25]
We are actively monitoring, evaluating and responding to developments relating to COVID-19, which is expected to result in significant global social and business disruption. While we instituted a global work-from-home policy beginning in March 2020, we did not incur significant disruptions in our work operations during the third quarter of fiscal 2020. We are trying to conduct business as usual with restrictions to employee travel, cancellation of in-person marketing events, and a hiring slowdown, among other modifications. These changes will substantially remain in effect in the fourth quarter of fiscal 2020 and could extend into future quarters. We will continue to actively monitor the situation and will make further changes that alter our business operations as may be required by federal, state or local authorities or that we determine are in the best interests of our employees, customers, partners, suppliers and stockholders.

[0001327567-20-000017:mdna:26]
COVID-19 may curtail our customers' spending and could lead them to delay or defer purchasing decisions, and lengthen sales cycles and payment terms, which could materially adversely impact our business, results of operations and overall financial performance. Also, certain of our customers or partners may be or may become credit or cash constrained making it difficult for them to fulfill their payment obligations to us. The extent of the impact of COVID-19 on our operational and financial performance will depend on developments, including the duration and spread of the virus, impact on our customers cash constraints, volume of sales and length of our sales cycles, impact on our partners, suppliers and employees, actions that may be taken by governmental authorities and other factors identified in Part II, Item 1A "Risk Factors" in this Form 10-Q. Given the dynamic nature of these circumstances, the full impact of COVID-19 on our ongoing business, results of operations and overall financial performance cannot be reasonably estimated at this time.

[0001327567-20-000017:mdna:27]
[same as prior period, unchanged from 0001327567-20-000007:mdna:24]

[0001327567-20-000017:mdna:28]
[same as prior period, unchanged from 0001327567-20-000007:mdna:25]

[0001327567-20-000017:mdna:29]
|  | April 30, 2020 |  | July 31, 2019 |
|  | (in millions) |  |  |
| Total deferred revenue | $ | 3,370.6 |  |  | $ | 2,888.7 |  |
| Cash, cash equivalents, and investments | $ | 2,190.0 |  |  | $ | 3,378.5 |  |

[0001327567-20-000017:mdna:30]
|  | Three Months Ended April 30, |  |  |  | Nine Months Ended April 30, |  |  |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
|  | (dollars in millions) |  |  |  |  |  |  |
| Total revenue | $ | 869.4 |  |  | $ | 726.6 |  |  | $ | 2,458.0 |  |  | $ | 2,093.8 |  |
| Total revenue year-over-year percentage increase | 19.7 | % |  | 28.0 | % |  | 17.4 | % |  | 29.6 | % |
| Gross margin | 70.3 | % |  | 71.8 | % |  | 71.2 | % |  | 71.8 | % |
| Operating loss | $ | (56.5) |  |  | $ | (18.7) |  |  | $ | (161.2) |  |  | $ | (44.2) |  |
| Operating margin | (6.5) | % |  | (2.6) | % |  | (6.6) | % |  | (2.1) | % |
| Billings | $ | 1,015.4 |  |  | $ | 821.9 |  |  | $ | 2,911.7 |  |  | $ | 2,432.9 |  |
| Billings year-over-year percentage increase | 23.5 | % |  | 13.4 | % |  | 19.7 | % |  | 22.1 | % |
| Cash flow provided by operating activities |  |  |  |  | $ | 702.0 |  |  | $ | 824.1 |  |
| Free cash flow (non-GAAP) |  |  |  |  | $ | 519.4 |  |  | $ | 746.0 |  |

[0001327567-20-000017:mdna:31]
•Deferred Revenue. Our deferred revenue primarily consists of amounts that have been invoiced but have not been recognized as revenue as of the period end. The majority of our deferred revenue balance consists of subscription and support revenue that is recognized ratably over the contractual service period. We monitor our deferred revenue balance because it represents a significant portion of revenue to be recognized in future periods.

[0001327567-20-000017:mdna:32]
•Billings. We define billings as total revenue plus the change in total deferred revenue, net of acquired deferred revenue, during the period. We consider billings to be a key metric used by management to manage our business given our hybrid SaaS revenue model, and believe billings provides investors with an important indicator of the health and visibility of our business because it includes subscription and support revenue, which is recognized ratably over the contractual service period, and product revenue, which is recognized at the time of shipment, provided that all other conditions for revenue recognition have been met. We consider billings to be a useful metric for management and investors, particularly if we continue to experience increased sales of subscriptions and strong renewal rates for subscription and support offerings,

[0001327567-20-000017:mdna:33]
[same as prior period, unchanged from 0001327567-20-000007:mdna:54]

[0001327567-20-000017:mdna:34]
and as we monitor our near-term cash flows. While we believe that billings provides useful information to investors and others in understanding and evaluating our operating results in the same manner as our management, it is important to note that other companies, including companies in our industry, may not use billings, may calculate billings differently, may have different billing frequencies, or may use other financial measures to evaluate their performance, all of which could reduce the usefulness of billings as a comparative measure. We calculate billings in the following manner:

[0001327567-20-000017:mdna:35]
|  | Three Months Ended April 30, |  |  |  | Nine Months Ended April 30, |  |  |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
|  | (in millions) |  |  |  | (in millions) |  |  |
| Billings: |  |  |  |  |  |  |  |
| Total revenue | $ | 869.4 |  |  | $ | 726.6 |  |  | $ | 2,458.0 |  |  | $ | 2,093.8 |  |
| Add: change in total deferred revenue, net of acquired deferred revenue | 146.0 |  |  | 95.3 |  |  | 453.7 |  |  | 339.1 |  |
| Billings | $ | 1,015.4 |  |  | $ | 821.9 |  |  | $ | 2,911.7 |  |  | $ | 2,432.9 |  |

[0001327567-20-000017:mdna:36]
• Cash Flow Provided by Operating Activities. We monitor cash flow provided by operating activities as a measure of our overall business performance. Our cash flow provided by operating activities is driven in large part by sales of our products and from up-front payments for subscription and support offerings. Monitoring cash flow provided by operating activities enables us to analyze our financial performance without the non-cash effects of certain items such as depreciation, amortization, and share-based compensation costs, thereby allowing us to better understand and manage the cash needs of our business.

[0001327567-20-000017:mdna:37]
• Free Cash Flow (non-GAAP). We define free cash flow, a non-GAAP financial measure, as cash provided by operating activities less purchases of property, equipment, and other assets. We consider free cash flow to be a profitability and liquidity measure that provides useful information to management and investors about the amount of cash generated by the business after necessary capital expenditures. A limitation of the utility of free cash flow as a measure of our financial performance and liquidity is that it does not represent the total increase or decrease in our cash balance for the period. In addition, it is important to note that other companies, including companies in our industry, may not use free cash flow, may calculate free cash flow in a different manner than we do, or may use other financial measures to evaluate their performance, all of which could reduce the usefulness of free cash flow as a comparative measure. A reconciliation of free cash flow to cash flow provided by operating activities, the most directly comparable financial measure calculated and presented in accordance with GAAP, is provided below:

[0001327567-20-000017:mdna:38]
|  | Nine Months Ended April 30, |  |  |
|  | 2020 |  | 2019 |
|  | (in millions) |  |  |
| Free cash flow (non-GAAP): |  |  |  |
| Net cash provided by operating activities | $ | 702.0 |  |  | $ | 824.1 |  |
| Less: purchases of property, equipment, and other assets | 182.6 |  |  | 78.1 |  |
| Free cash flow (non-GAAP) | $ | 519.4 |  |  | $ | 746.0 |  |
| Net cash provided by (used in) investing activities | $ | 955.6 |  |  | $ | (1,377.2) |  |
| Net cash used in financing activities | $ | (1,132.5) |  |  | $ | (637.8) |  |

[0001327567-20-000017:mdna:39]
[same as prior period, unchanged from 0001327567-20-000007:mdna:67]

[0001327567-20-000017:mdna:40]
[same as prior period, unchanged from 0001327567-20-000007:mdna:37]

[0001327567-20-000017:mdna:41]
[same as prior period, unchanged from 0001327567-20-000007:mdna:38]

[0001327567-20-000017:mdna:42]
|  | Three Months Ended April 30, |  |  |  |  |  |  |  | Nine Months Ended April 30, |  |  |  |  |  |  |
|  | 2020 |  |  |  | 2019 |  |  |  | 2020 |  |  |  | 2019 |  |  |
|  | Amount |  | % of Revenue |  | Amount |  | % of Revenue |  | Amount |  | % of Revenue |  | Amount |  | % of Revenue |
|  | (dollars in millions) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 280.9 |  |  | 32.3 | % |  | $ | 278.4 |  |  | 38.3 | % |  | $ | 758.6 |  |  | 30.9 | % |  | $ | 790.5 |  |  | 37.8 | % |
| Subscription and support | 588.5 |  |  | 67.7 | % |  | 448.2 |  |  | 61.7 | % |  | 1,699.4 |  |  | 69.1 | % |  | 1,303.3 |  |  | 62.2 | % |
| Total revenue | 869.4 |  |  | 100.0 | % |  | 726.6 |  |  | 100.0 | % |  | 2,458.0 |  |  | 100.0 | % |  | 2,093.8 |  |  | 100.0 | % |
| Cost of revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product | 73.3 |  |  | 8.4 | % |  | 78.0 |  |  | 10.7 | % |  | 207.1 |  |  | 8.4 | % |  | 233.7 |  |  | 11.2 | % |
| Subscription and support | 185.0 |  |  | 21.3 | % |  | 126.9 |  |  | 17.5 | % |  | 502.0 |  |  | 20.4 | % |  | 357.3 |  |  | 17.0 | % |
| Total cost of revenue(1) | 258.3 |  |  | 29.7 | % |  | 204.9 |  |  | 28.2 | % |  | 709.1 |  |  | 28.8 | % |  | 591.0 |  |  | 28.2 | % |
| Total gross profit | 611.1 |  |  | 70.3 | % |  | 521.7 |  |  | 71.8 | % |  | 1,748.9 |  |  | 71.2 | % |  | 1,502.8 |  |  | 71.8 | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | 196.3 |  |  | 22.6 | % |  | 139.1 |  |  | 19.1 | % |  | 552.2 |  |  | 22.5 | % |  | 380.8 |  |  | 18.2 | % |
| Sales and marketing | 388.4 |  |  | 44.7 | % |  | 339.0 |  |  | 46.7 | % |  | 1,129.0 |  |  | 46.0 | % |  | 973.6 |  |  | 46.5 | % |
| General and administrative | 82.9 |  |  | 9.5 | % |  | 62.3 |  |  | 8.6 | % |  | 228.9 |  |  | 9.3 | % |  | 192.6 |  |  | 9.2 | % |
| Total operating expenses(1) | 667.6 |  |  | 76.8 | % |  | 540.4 |  |  | 74.4 | % |  | 1,910.1 |  |  | 77.8 | % |  | 1,547.0 |  |  | 73.9 | % |
| Operating loss | (56.5) |  |  | (6.5) | % |  | (18.7) |  |  | (2.6) | % |  | (161.2) |  |  | (6.6) | % |  | (44.2) |  |  | (2.1) | % |
| Interest expense | (19.4) |  |  | (2.2) | % |  | (20.6) |  |  | (2.8) | % |  | (57.3) |  |  | (2.3) | % |  | (63.9) |  |  | (3.1) | % |
| Other income, net | 8.1 |  |  | 0.9 | % |  | 18.2 |  |  | 2.5 | % |  | 35.1 |  |  | 1.4 | % |  | 47.2 |  |  | 2.3 | % |
| Loss before income taxes | (67.8) |  |  | (7.8) | % |  | (21.1) |  |  | (2.9) | % |  | (183.4) |  |  | (7.5) | % |  | (60.9) |  |  | (2.9) | % |
| Provision for (benefit from) income taxes | 7.0 |  |  | 0.8 | % |  | (0.9) |  |  | (0.1) | % |  | 24.7 |  |  | 1.0 | % |  | 0.2 |  |  | — | % |
| Net loss | $ | (74.8) |  |  | (8.6) | % |  | $ | (20.2) |  |  | (2.8) | % |  | $ | (208.1) |  |  | (8.5) | % |  | $ | (61.1) |  |  | (2.9) | % |

[0001327567-20-000017:mdna:43]
[same as prior period, unchanged from 0001327567-20-000007:mdna:41]

[0001327567-20-000017:mdna:44]
(1)Includes share-based compensation as follows:

[0001327567-20-000017:mdna:45]
|  | Three Months Ended April 30, |  |  |  | Nine Months Ended April 30, |  |  |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
|  | (in millions) |  |  |  |  |  |  |
| Cost of product revenue | $ | 1.4 |  |  | $ | 1.3 |  |  | $ | 4.2 |  |  | $ | 4.3 |  |
| Cost of subscription and support revenue | 18.8 |  |  | 17.2 |  |  | 57.6 |  |  | 52.9 |  |
| Research and development | 67.7 |  |  | 45.1 |  |  | 197.4 |  |  | 129.6 |  |
| Sales and marketing | 55.5 |  |  | 54.5 |  |  | 155.0 |  |  | 169.2 |  |
| General and administrative | 22.7 |  |  | 20.1 |  |  | 76.0 |  |  | 75.7 |  |
| Total share-based compensation | $ | 166.1 |  |  | $ | 138.2 |  |  | $ | 490.2 |  |  | $ | 431.7 |  |

[0001327567-20-000017:mdna:46]
[same as prior period, unchanged from 0001327567-20-000007:mdna:44]

[0001327567-20-000017:mdna:47]
[same as prior period, unchanged from 0001327567-20-000007:mdna:45]

[0001327567-20-000017:mdna:48]
[same as prior period, unchanged from 0001327567-20-000007:mdna:77]

[0001327567-20-000017:mdna:49]
[same as prior period, unchanged from 0001327567-20-000007:mdna:46]

[0001327567-20-000017:mdna:50]
[same as prior period, unchanged from 0001327567-20-000007:mdna:47]

[0001327567-20-000017:mdna:51]
|  | Three Months Ended April 30, |  |  |  |  |  |  |  | Nine Months Ended April 30, |  |  |  |  |  |  |
|  | 2020 |  | 2019 |  | Change |  |  |  | 2020 |  | 2019 |  | Change |  |  |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 280.9 |  |  | $ | 278.4 |  |  | $ | 2.5 |  |  | 0.9 | % |  | $ | 758.6 |  |  | $ | 790.5 |  |  | $ | (31.9) |  |  | (4.0) | % |

[0001327567-20-000017:mdna:52]
Product revenue was relatively flat for the three months ended April 30, 2020 compared to the three months ended April 30, 2019. Product revenue decreased in the nine months ended April 30, 2020 compared to the nine months ended April 30, 2019 primarily due to product mix, partially offset by an increase in product unit volume. The change in product revenue due to pricing was not significant for either period.

[0001327567-20-000017:mdna:53]
[same as prior period, unchanged from 0001327567-20-000007:mdna:50]

[0001327567-20-000017:mdna:54]
[same as prior period, unchanged from 0001327567-20-000007:mdna:51]

[0001327567-20-000017:mdna:55]
|  | Three Months Ended April 30, |  |  |  |  |  |  |  | Nine Months Ended April 30, |  |  |  |  |  |  |
|  | 2020 |  | 2019 |  | Change |  |  |  | 2020 |  | 2019 |  | Change |  |  |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Subscription | $ | 354.3 |  |  | $ | 258.8 |  |  | $ | 95.5 |  |  | 36.9 | % |  | $ | 1,015.5 |  |  | $ | 739.8 |  |  | $ | 275.7 |  |  | 37.3 | % |
| Support | 234.2 |  |  | 189.4 |  |  | 44.8 |  |  | 23.7 | % |  | 683.9 |  |  | 563.5 |  |  | 120.4 |  |  | 21.4 | % |
| Total subscription and support | $ | 588.5 |  |  | $ | 448.2 |  |  | $ | 140.3 |  |  | 31.3 | % |  | $ | 1,699.4 |  |  | $ | 1,303.3 |  |  | $ | 396.1 |  |  | 30.4 | % |

[0001327567-20-000017:mdna:56]
Subscription and support revenue increased for the three and nine months ended April 30, 2020 compared to the three and nine months ended April 30, 2019. The increase in both periods was due to increased demand for our subscription and support offerings from both new and existing end-customers. The mix between subscription revenue and support revenue will fluctuate over time, depending on the introduction of new subscription offerings, renewals of support services, and our ability to increase sales to new and existing end customers. The change in subscription and support revenue due to changes in pricing was not significant for either period.

[0001327567-20-000017:mdna:57]
[same as prior period, unchanged from 0001327567-20-000007:mdna:56]

[0001327567-20-000017:mdna:58]
|  | Three Months Ended April 30, |  |  |  |  |  |  |  | Nine Months Ended April 30, |  |  |  |  |  |  |
|  | 2020 |  | 2019 |  | Change |  |  |  | 2020 |  | 2019 |  | Change |  |  |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 594.2 |  |  | $ | 497.8 |  |  | $ | 96.4 |  |  | 19.4 | % |  | $ | 1,668.5 |  |  | $ | 1,423.0 |  |  | $ | 245.5 |  |  | 17.3 | % |
| EMEA | 171.5 |  |  | 138.7 |  |  | 32.8 |  |  | 23.6 | % |  | 485.3 |  |  | 414.7 |  |  | 70.6 |  |  | 17.0 | % |
| APAC | 103.7 |  |  | 90.1 |  |  | 13.6 |  |  | 15.1 | % |  | 304.2 |  |  | 256.1 |  |  | 48.1 |  |  | 18.8 | % |
| Total revenue | $ | 869.4 |  |  | $ | 726.6 |  |  | $ | 142.8 |  |  | 19.7 | % |  | $ | 2,458.0 |  |  | $ | 2,093.8 |  |  | $ | 364.2 |  |  | 17.4 | % |

[0001327567-20-000017:mdna:59]
With respect to geographic theaters, the Americas contributed the largest portion of the increase in revenue for the three and nine months ended April 30, 2020 compared to the three and nine months ended April 30, 2019, due to its larger and more established sales force compared to our other theaters. Revenue from both Europe, the Middle East, and Africa (“EMEA”) and Asia Pacific and Japan (“APAC”) increased for the three and nine months ended April 30, 2020 compared to the three and nine months ended April 30, 2019, due to our investment in increasing the size of our sales force in these theaters.

[0001327567-20-000017:mdna:60]
[same as prior period, unchanged from 0001327567-20-000007:mdna:59]

[0001327567-20-000017:mdna:61]
[same as prior period, unchanged from 0001327567-20-000007:mdna:60]

[0001327567-20-000017:mdna:62]
[same as prior period, unchanged from 0001327567-20-000007:mdna:88]

[0001327567-20-000017:mdna:63]
[same as prior period, unchanged from 0001327567-20-000007:mdna:61]

[0001327567-20-000017:mdna:64]
Cost of product revenue primarily includes costs paid to our manufacturing partners. Our cost of product revenue also includes personnel costs, which consist of salaries, benefits, bonuses, share-based compensation, and travel and entertainment associated with our operations organization, amortization of intellectual property licenses, product testing costs, shipping and tariff costs, and allocated costs. Allocated costs consist of certain facilities, depreciation, benefits, recruiting, and information technology costs that we allocate based on headcount. We expect our cost of product revenue to fluctuate with our product revenue.

[0001327567-20-000017:mdna:65]
|  | Three Months Ended April 30, |  |  |  |  |  |  |  | Nine Months Ended April 30, |  |  |  |  |  |  |
|  | 2020 |  | 2019 |  | Change |  |  |  | 2020 |  | 2019 |  | Change |  |  |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of product revenue | $ | 73.3 |  |  | $ | 78.0 |  |  | $ | (4.7) |  |  | (6.0) | % |  | $ | 207.1 |  |  | $ | 233.7 |  |  | $ | (26.6) |  |  | (11.4) | % |
| Number of employees at period end | 118 |  |  | 99 |  |  | 19 |  |  | 19.2 | % |  | 118 |  |  | 99 |  |  | 19 |  |  | 19.2 | % |

[0001327567-20-000017:mdna:66]
Cost of product revenue decreased for the three and nine months ended April 30, 2020 compared to the three and nine months ended April 30, 2019. The decrease for the three and nine months ended April 30, 2020 was primarily due to reductions in costs of materials and lower amortization of intellectual property licenses.

[0001327567-20-000017:mdna:67]
[same as prior period, unchanged from 0001327567-20-000007:mdna:65]

[0001327567-20-000017:mdna:68]
[same as prior period, unchanged from 0001327567-20-000007:mdna:66]

[0001327567-20-000017:mdna:69]
|  | Three Months Ended April 30, |  |  |  |  |  |  |  | Nine Months Ended April 30, |  |  |  |  |  |  |
|  | 2020 |  | 2019 |  | Change |  |  |  | 2020 |  | 2019 |  | Change |  |  |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of subscription and support revenue | $ | 185.0 |  |  | $ | 126.9 |  |  | $ | 58.1 |  |  | 45.8 | % |  | $ | 502.0 |  |  | $ | 357.3 |  |  | $ | 144.7 |  |  | 40.5 | % |
| Number of employees at period end | 1,403 |  |  | 1,114 |  |  | 289 |  |  | 25.9 | % |  | 1,403 |  |  | 1,114 |  |  | 289 |  |  | 25.9 | % |

[0001327567-20-000017:mdna:70]
Cost of subscription and support revenue increased for the three and nine months ended April 30, 2020 compared to the three and nine months ended April 30, 2019. The increase in both periods was primarily due to increased costs to support the growth of our subscription and support offerings. Cloud hosting costs to support the adoption of our cloud-based subscription offerings increased $25.6 million for the three months ended April 30, 2020 compared to the three months ended April 30, 2019, and increased $53.4 million for the nine months ended April 30, 2020 compared to the nine months ended April 30, 2019. Personnel costs grew $15.5 million to $81.5 million for the three months ended April 30, 2020 compared to the three months ended April 30, 2019, and grew $47.3 million to $234.9 million for the nine months ended April 30, 2020 compared to the nine months ended April 30, 2019 primarily due to headcount growth. The remaining increase was primarily due to amortization of purchased intangible assets, which increased $6.7 million for the three months ended April 30, 2020 compared to the three months ended April 30, 2019 and increased $21.8 million for the nine months ended April 30, 2020 compared to the nine months ended April 30, 2019, as a result of our recent acquisitions.

[0001327567-20-000017:mdna:71]
[same as prior period, unchanged from 0001327567-20-000007:mdna:70]

[0001327567-20-000017:mdna:72]
Gross margin, or gross profit as a percentage of revenue, has been and will continue to be affected by a variety of factors, including the introduction of new products, manufacturing costs, tariff costs, the average sales price of our products, the mix of products sold, and the mix of revenue between product and subscription and support offerings. For sales of our products, our higher-end firewall products generally have higher gross margins than our lower-end firewall products within each product series. We expect our gross margins to fluctuate over time depending on the factors described above.

[0001327567-20-000017:mdna:73]
[same as prior period, unchanged from 0001327567-20-000007:mdna:99]

[0001327567-20-000017:mdna:74]
|  | Three Months Ended April 30, |  |  |  |  |  |  |  | Nine Months Ended April 30, |  |  |  |  |  |  |
|  | 2020 |  |  |  | 2019 |  |  |  | 2020 |  |  |  | 2019 |  |  |
|  | Amount |  | Gross Margin |  | Amount |  | Gross Margin |  | Amount |  | Gross Margin |  | Amount |  | Gross Margin |
|  | (dollars in millions) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 207.6 |  |  | 73.9 | % |  | $ | 200.4 |  |  | 72.0 | % |  | $ | 551.5 |  |  | 72.7 | % |  | $ | 556.8 |  |  | 70.4 | % |
| Subscription and support | 403.5 |  |  | 68.6 | % |  | 321.3 |  |  | 71.7 | % |  | 1,197.4 |  |  | 70.5 | % |  | 946.0 |  |  | 72.6 | % |
| Total gross profit | $ | 611.1 |  |  | 70.3 | % |  | $ | 521.7 |  |  | 71.8 | % |  | $ | 1,748.9 |  |  | 71.2 | % |  | $ | 1,502.8 |  |  | 71.8 | % |

[0001327567-20-000017:mdna:75]
Product gross margin increased for the three and nine months ended April 30, 2020 compared to the three and nine months ended April 30, 2019, primarily due to reductions in costs of materials.

[0001327567-20-000017:mdna:76]
Subscription and support gross margin decreased for the three and nine months ended April 30, 2020 compared to the three and nine months ended April 30, 2019, primarily due to an increase in costs to support the adoption of our cloud-based subscription offerings and higher amortization of purchased intangibles as a result of our recent acquisitions, partially offset by increased leverage of our global customer support organization.

[0001327567-20-000017:mdna:77]
[same as prior period, unchanged from 0001327567-20-000007:mdna:75]

[0001327567-20-000017:mdna:78]
Our operating expenses consist of research and development, sales and marketing, and general and administrative expense. Personnel costs are the most significant component of operating expenses and consist of salaries, benefits, bonuses, share-based compensation, travel and entertainment, and with regard to sales and marketing expense, sales commissions. Our operating expenses also include allocated costs, which consist of certain facilities, depreciation, benefits, recruiting, and information technology costs that we allocate based on headcount. We expect operating expenses generally to increase in absolute dollars and decrease over the long term as a percentage of revenue as we continue to scale our business. In response to COVID-19, we instituted a global work-from-home policy and limited employee travel beginning in March 2020. Further, we have canceled in-person events and either replaced them with virtual events or postponed them to future periods. Although we did not conduct any employee layoffs related to COVID-19, we slowed hiring in our third quarter of fiscal 2020. As of April 30, 2020, we expect to recognize approximately $1.6 billion of share-based compensation expense over a weighted-average period of approximately 2.6 years, excluding additional share-based compensation expense related to any future grants of share-based awards. Share-based compensation expense is generally recognized on a straight-line basis over the requisite service periods of the awards.

[0001327567-20-000017:mdna:79]
[same as prior period, unchanged from 0001327567-20-000007:mdna:78]

[0001327567-20-000017:mdna:80]
[same as prior period, unchanged from 0001327567-20-000007:mdna:79]

[0001327567-20-000017:mdna:81]
|  | Three Months Ended April 30, |  |  |  |  |  |  |  | Nine Months Ended April 30, |  |  |  |  |  |  |
|  | 2020 |  | 2019 |  | Change |  |  |  | 2020 |  | 2019 |  | Change |  |  |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | $ | 196.3 |  |  | $ | 139.1 |  |  | $ | 57.2 |  |  | 41.1 | % |  | $ | 552.2 |  |  | $ | 380.8 |  |  | $ | 171.4 |  |  | 45.0 | % |
| Number of employees at period end | 1,789 |  |  | 1,336 |  |  | 453 |  |  | 33.9 | % |  | 1,789 |  |  | 1,336 |  |  | 453 |  |  | 33.9 | % |

[0001327567-20-000017:mdna:82]
Research and development expense increased for the three and nine months ended April 30, 2020 compared to the three and nine months ended April 30, 2019. The increase was primarily due to personnel costs, which grew $48.7 million to $152.3 million for the three months ended April 30, 2020 compared to the three months ended April 30, 2019, and grew $140.3 million to $429.2 million for the nine months ended April 30, 2020 compared to the nine months ended April 30, 2019. The increase in personnel costs in both periods was primarily due to headcount growth. The remaining increase in both periods was primarily driven by an increase in allocated costs.

[0001327567-20-000017:mdna:83]
[same as prior period, unchanged from 0001327567-20-000007:mdna:82]

[0001327567-20-000017:mdna:84]
[same as prior period, unchanged from 0001327567-20-000007:mdna:83]

[0001327567-20-000017:mdna:85]
[same as prior period, unchanged from 0001327567-20-000007:mdna:110]

[0001327567-20-000017:mdna:86]
|  | Three Months Ended April 30, |  |  |  |  |  |  |  | Nine Months Ended April 30, |  |  |  |  |  |  |
|  | 2020 |  | 2019 |  | Change |  |  |  | 2020 |  | 2019 |  | Change |  |  |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Sales and marketing | $ | 388.4 |  |  | $ | 339.0 |  |  | $ | 49.4 |  |  | 14.6 | % |  | $ | 1,129.0 |  |  | $ | 973.6 |  |  | $ | 155.4 |  |  | 16.0 | % |
| Number of employees at period end | 3,853 |  |  | 3,194 |  | 659 |  |  | 20.6 | % |  | 3,853 |  |  | 3,194 |  |  | 659 |  |  | 20.6 | % |

[0001327567-20-000017:mdna:87]
Sales and marketing expense increased for the three and nine months ended April 30, 2020 compared to the three and nine months ended April 30, 2019. The increase was primarily due to personnel costs, which grew $34.7 million to $290.6 million for the three months ended April 30, 2020 compared to the three months ended April 30, 2019, and grew $115.1 million to $842.2 million for the nine months ended April 30, 2020 compared to the nine months ended April 30, 2019. The increase in personnel costs in both periods was largely due to headcount growth. The increase in personnel costs in the three months ended April 30, 2020 was partially offset by savings related to decreased travel as a response to COVID-19. The remaining increase in both periods was primarily driven by an increase in costs associated with marketing-related activities. The increase in the three months ended April 30, 2020 also included costs to cancel in-person events, replace them with virtual events or postpone them to future periods due to COVID-19.

[0001327567-20-000017:mdna:88]
[same as prior period, unchanged from 0001327567-20-000007:mdna:86]

[0001327567-20-000017:mdna:89]
[same as prior period, unchanged from 0001327567-20-000007:mdna:87]

[0001327567-20-000017:mdna:90]
|  | Three Months Ended April 30, |  |  |  |  |  |  |  | Nine Months Ended April 30, |  |  |  |  |  |  |
|  | 2020 |  | 2019 |  | Change |  |  |  | 2020 |  | 2019 |  | Change |  |  |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| General and administrative | $ | 82.9 |  |  | $ | 62.3 |  |  | $ | 20.6 |  |  | 33.1 | % |  | $ | 228.9 |  |  | $ | 192.6 |  |  | $ | 36.3 |  |  | 18.8 | % |
| Number of employees at period end | 886 |  |  | 760 |  |  | 126 |  |  | 16.6 | % |  | 886 |  |  | 760 |  |  | 126 |  |  | 16.6 | % |

[0001327567-20-000017:mdna:91]
General and administrative expense increased for the three and nine months ended April 30, 2020 compared to the three and nine months ended April 30, 2019, primarily due to personnel costs, which increased $13.1 million to $52.1 million for the three months ended April 30, 2020 compared to the three months ended April 30, 2019, and increased $25.2 million to $154.1 million for the nine months ended April 30, 2020 compared to the nine months ended April 30, 2019. The increase in both periods was largely due to headcount growth. The increase in personnel costs in the nine months ended April 30, 2020 was partially offset by accelerated vesting of certain equity awards in connection with business acquisitions during the nine months ended April 30, 2019. The remaining increase in general and administrative expense in both periods was primarily due to increases in acquisition-related costs and other costs to support our business growth, partially offset by a net decrease in facility exit related charges.

[0001327567-20-000017:mdna:92]
[same as prior period, unchanged from 0001327567-20-000007:mdna:91]

[0001327567-20-000017:mdna:93]
Interest expense primarily consists of non-cash interest expense from the amortization of the debt discount and debt issuance costs related to our 0.0% Convertible Senior Notes due 2019 (the “2019 Notes”) and 0.75% Convertible Senior Notes due 2023 (the “2023 Notes” and, together with the 2019 Notes, the “Notes”), and also includes the contractual interest expense related to our 2023 Notes.

[0001327567-20-000017:mdna:94]
|  | Three Months Ended April 30, |  |  |  |  |  |  |  | Nine Months Ended April 30, |  |  |  |  |  |  |
|  | 2020 |  | 2019 |  | Change |  |  |  | 2020 |  | 2019 |  | Change |  |  |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense | $ | 19.4 |  |  | $ | 20.6 |  |  | $ | (1.2) |  |  | (5.8) | % |  | $ | 57.3 |  |  | $ | 63.9 |  |  | $ | (6.6) |  |  | (10.3) | % |

[0001327567-20-000017:mdna:95]
Interest expense decreased for the three and nine months ended April 30, 2020 compared to the three and nine months ended April 30, 2019. The decrease in the three and nine months ended April 30, 2020 was primarily due to conversions of our 2019 Notes before and upon maturity in July 2019. Refer to Note 9. Debt in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information on our Notes.

[0001327567-20-000017:mdna:96]
[same as prior period, unchanged from 0001327567-20-000007:mdna:127]

[0001327567-20-000017:mdna:97]
[same as prior period, unchanged from 0001327567-20-000007:mdna:95]

[0001327567-20-000017:mdna:98]
[same as prior period, unchanged from 0001327567-20-000007:mdna:96]

[0001327567-20-000017:mdna:99]
|  | Three Months Ended April 30, |  |  |  |  |  |  |  | Nine Months Ended April 30, |  |  |  |  |  |  |
|  | 2020 |  | 2019 |  | Change |  |  |  | 2020 |  | 2019 |  | Change |  |  |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Other income, net | $ | 8.1 |  |  | $ | 18.2 |  |  | $ | (10.1) |  |  | (55.5) | % |  | $ | 35.1 |  |  | $ | 47.2 |  |  | $ | (12.1) |  |  | (25.6) | % |

[0001327567-20-000017:mdna:100]
Other income, net decreased for the three and nine months ended April 30, 2020 compared to the three and nine months ended April 30, 2019. The decrease was primarily due to lower interest income on our investments.

[0001327567-20-000017:mdna:101]
[same as prior period, unchanged from 0001327567-20-000007:mdna:100]

[0001327567-20-000017:mdna:102]
[same as prior period, unchanged from 0001327567-20-000007:mdna:101]

[0001327567-20-000017:mdna:103]
|  | Three Months Ended April 30, |  |  |  | Change |  |  |  | Nine Months Ended April 30, |  |  |  | Change |  |  |
|  | 2020 |  | 2019 |  | Amount |  | % |  | 2020 |  | 2019 |  | Amount |  | % |
|  | (dollars in millions) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Provision for (benefit from) income taxes | $ | 7.0 |  |  | $ | (0.9) |  |  | $ | 7.9 |  |  | (877.8) | % |  | $ | 24.7 |  |  | $ | 0.2 |  |  | $ | 24.5 |  |  | 12,250.0 | % |
| Effective tax rate | (10.3) | % |  | 4.3 | % |  |  |  |  |  | (13.5) | % |  | (0.3) | % |  |  |  |  |

[0001327567-20-000017:mdna:104]
We recorded an income tax provision for the three and nine months ended April 30, 2020. The provision for income taxes for the three and nine months ended April 30, 2020 was primarily due to income taxes in profitable foreign jurisdictions, U.S. state taxes, and withholding taxes. Our provision for income taxes increased for the three months ended April 30, 2020 compared to the three months ended April 30, 2019, primarily due to an increase in foreign withholding taxes. Our provision for income taxes increased for the nine months ended April 30, 2020 compared to the nine months ended April 30, 2019, due to an increase in withholding taxes and a decrease in one-time tax benefits relating to partial releases of our U.S. valuation allowance resulting from acquisitions. Refer to Note 14. Income Taxes in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information.

[0001327567-20-000017:mdna:105]
[same as prior period, unchanged from 0001327567-20-000007:mdna:104]

[0001327567-20-000017:mdna:106]
|  | April 30, 2020 |  | July 31, 2019 |
|  | (in millions) |  |  |
| Working capital | $ | 678.3 |  |  | $ | 1,611.5 |  |
| Cash, cash equivalents, and investments: |  |  |  |
| Cash and cash equivalents | $ | 1,484.7 |  |  | $ | 961.4 |  |
| Investments | 705.3 |  |  | 2,417.1 |  |
| Total cash, cash equivalents, and investments | $ | 2,190.0 |  |  | $ | 3,378.5 |  |

[0001327567-20-000017:mdna:107]
As of April 30, 2020, our total cash, cash equivalents, and investments of $2.2 billion were held for general corporate purposes, of which approximately $360.1 million was held outside of the United States. As of April 30, 2020, we had no unremitted earnings when evaluating our outside basis difference relating to our U.S. investment in foreign subsidiaries. However, there could be local withholding taxes payable due to various foreign countries if certain lower tier earnings are distributed. Withholding taxes that would be payable upon remittance of these lower tier earnings are not expected to be material.

[0001327567-20-000017:mdna:108]
In July 2018, we issued the 2023 Notes with an aggregate principal amount of $1.7 billion. The 2023 Notes mature on July 1, 2023; however, under certain circumstances, holders may surrender their 2023 Notes for conversion prior to the maturity date. Upon conversion of the 2023 Notes, we will pay cash equal to the aggregate principal amount of the 2023 Notes to be converted, and, at our election, will pay or deliver cash and/or shares of our common stock for the amount of our conversion obligation in excess of the

[0001327567-20-000017:mdna:109]
- 35 -

[0001327567-20-000017:mdna:110]
aggregate principal amount of the 2023 Notes being converted. As of April 30, 2020, all of the 2023 Notes remained outstanding. Refer to Note 9. Debt in Part I, Item 1 of this Quarterly Report on Form 10-Q for information on the Notes.

[0001327567-20-000017:mdna:111]
In September 2018, we entered into a credit agreement (the “Credit Agreement”) that provides for a $400.0 million unsecured revolving credit facility (the “Credit Facility”), with an option to increase the amount of the credit facility up to an additional $350.0 million, subject to certain conditions. As of April 30, 2020, there were no amounts outstanding, and we were in compliance with all covenants under the Credit Agreement. Refer to Note 9. Debt in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information on the Credit Agreement.

[0001327567-20-000017:mdna:112]
In February 2019, our board of directors authorized a $1.0 billion share repurchase program which is funded from available working capital and will expire on December 31, 2020. As of April 30, 2020, $801.9 million remained available for future share repurchases under this repurchase authorization. In February 2020, our board of directors approved the repurchase of $1.0 billion of our common stock through an accelerated share repurchase (“ASR”) transaction, which is in addition to our $1.0 billion share repurchase program that our board of directors authorized in February 2019. During the three months ended April 30, 2020 we made an up-front payment of $1.0 billion pursuant to the ASR to receive an initial delivery of approximately 80% of the common stock, or 4.2 million shares valued at $800.0 million. The final number of shares to be repurchased under the ASR will be based generally upon the volume weighted average price of our common stock during the repurchase period, which is expected to be completed in our fourth quarter of fiscal 2020. Refer to Note 12. Stockholders’ Equity in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information on our repurchase programs.

[0001327567-20-000017:mdna:113]
The following table summarizes our cash flows for the nine months ended April 30, 2020 and 2019:

[0001327567-20-000017:mdna:114]
|  | Nine Months Ended April 30, |  |  |
|  | 2020 |  | 2019 |
|  | (in millions) |  |  |
| Net cash provided by operating activities | $ | 702.0 |  |  | $ | 824.1 |  |
| Net cash provided by (used in) investing activities | 955.6 |  |  | (1,377.2) |  |
| Net cash used in financing activities | (1,132.5) |  |  | (637.8) |  |
| Net increase (decrease) in cash, cash equivalents, and restricted cash | $ | 525.1 |  |  | $ | (1,190.9) |  |

[0001327567-20-000017:mdna:115]
Cash from operations could be affected by various risks and uncertainties, including, but not limited to, the effects of COVID-19 and other risks detailed in Part II, Item 1A "Risk Factors" in this Form 10-Q. We believe that our cash flow from operations with existing cash and cash equivalents will be sufficient to meet our anticipated cash needs for at least the next 12 months and thereafter for the foreseeable future. Our future capital requirements will depend on many factors including our growth rate, the timing and extent of spending to support development efforts, the expansion of sales and marketing activities, the introduction of new and enhanced products and subscription and support offerings, the costs to acquire or invest in complementary businesses and technologies, the costs to ensure access to adequate manufacturing capacity, the investments in our infrastructure to support the adoption of our cloud-based subscription offerings, the investments in our new corporate headquarters, the continuing market acceptance of our products and subscription and support offerings and macroeconomic events such as COVID-19. In addition, from time to time we may incur additional tax liability in connection with certain corporate structuring decisions.

[0001327567-20-000017:mdna:116]
[same as prior period, unchanged from 0001327567-20-000007:mdna:115]

[0001327567-20-000017:mdna:117]
[same as prior period, unchanged from 0001327567-20-000007:mdna:116]

[0001327567-20-000017:mdna:118]
[same as prior period, unchanged from 0001327567-20-000007:mdna:117]

[0001327567-20-000017:mdna:119]
Cash provided by operating activities during the nine months ended April 30, 2020 was $702.0 million, a decrease of $122.1 million compared to the nine months ended April 30, 2019. The decrease was primarily due to higher cash expenditure during the nine months ended April 30, 2020. The decrease was partially offset by an increase due to growth of our business, as reflected by an increase in billings during the nine months ended April 30, 2020, and repayments of the 2019 Notes attributable to the debt discount during the nine months ended April 30, 2019.

[0001327567-20-000017:mdna:120]
[same as prior period, unchanged from 0001327567-20-000007:mdna:119]

[0001327567-20-000017:mdna:121]
[same as prior period, unchanged from 0001327567-20-000007:mdna:120]

[0001327567-20-000017:mdna:122]
Cash provided by investing activities during the nine months ended April 30, 2020 was $955.6 million, a net change of $2.3 billion compared to cash used in investing activities of $1.4 billion during the nine months ended April 30, 2019. The change was primarily due to lower purchases of investments and higher proceeds from maturities and sales of investments, partially offset by an

[0001327567-20-000017:mdna:123]
- 36 -

[0001327567-20-000017:mdna:124]
increase in net cash payments for business acquisitions and an increase in purchases of property, equipment and other assets, including a land purchase in Santa Clara, California during the nine months ended April 30, 2020.

[0001327567-20-000017:mdna:125]
[same as prior period, unchanged from 0001327567-20-000007:mdna:122]

[0001327567-20-000017:mdna:126]
[same as prior period, unchanged from 0001327567-20-000007:mdna:123]

[0001327567-20-000017:mdna:127]
Cash used in financing activities during the nine months ended April 30, 2020 was $1,132.5 million, an increase of $494.7 million compared to the nine months ended April 30, 2019. The increase was primarily due to higher repurchases of our common stock during the nine months ended April 30, 2020, partially offset by repayments of our 2019 Notes during the nine months ended April 30, 2019.

[0001327567-20-000017:mdna:128]
[same as prior period, unchanged from 0001327567-20-000007:mdna:125]

[0001327567-20-000017:mdna:129]
As of April 30, 2020, we did not have any relationships with unconsolidated organizations or financial partnerships, such as structured finance or special purpose entities that would have been established for the purpose of facilitating off-balance sheet arrangements or other contractually narrow or limited purposes.

[0001327567-20-000017:mdna:130]
[same as prior period, unchanged from 0001327567-20-000007:mdna:128]

[0001327567-20-000017:mdna:131]
Our condensed consolidated financial statements have been prepared in accordance with U.S. GAAP. The preparation of these condensed consolidated financial statements requires us to make estimates and assumptions that affect the reported amounts of assets, liabilities, revenue, expenses, and related disclosures. We base our estimates on historical experience and on various other assumptions that we believe are reasonable under the circumstances. These estimates and assumptions are affected by management’s application of accounting policies, as well as uncertainty in the current economic environment due to the recent outbreak of COVID-19. We evaluate our estimates and assumptions on an ongoing basis. Actual results may differ from these estimates. To the extent that there are material differences between these estimates and our actual results, our future financial statements will be affected.

[0001327567-20-000017:mdna:132]
[same as prior period, unchanged from 0001327567-20-000007:mdna:130]

[0001327567-20-000017:mdna:133]
[same as prior period, unchanged from 0001327567-20-000007:mdna:131]

[0001327567-20-000017:mdna:134]
Refer to “Recently Adopted Accounting Pronouncements” and “Recently Issued Accounting Pronouncements” in Note 1. Description of Business and Summary of Significant Accounting Policies in Part I, Item 1 of this Quarterly Report on Form 10-Q.
