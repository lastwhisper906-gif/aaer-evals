# PANW 8-K — 0001327567-20-000015 filed 2020-05-21

## item codes, every 8-K on or before 2020-05-22

- 2020-05-21 0001327567-20-000015 — 2.02, 9.01
- 2020-02-27 0001193125-20-050335 — 1.01, 2.03
- 2020-02-24 0001327567-20-000002 — 2.02, 9.01
- 2019-12-19 0001193125-19-319166 — 1.02, 9.01
- 2019-12-10 0001193125-19-310251 — 5.07
- 2019-11-25 0001327567-19-000036 — 2.02, 9.01
- 2019-11-25 0001193125-19-299886 — 5.02, 8.01 — amendment of 0001327567-19-000011
- 2019-10-22 0001193125-19-271660 — 5.02
- 2019-09-06 0001327567-19-000026 — 9.01 — amendment of 0001327567-19-000023
- 2019-09-04 0001327567-19-000023 — 2.02, 7.01, 9.01
- 2019-07-11 0001193125-19-192415 — 5.02, 9.01
- 2019-05-29 0001327567-19-000014 — 2.02, 9.01
- 2019-04-15 0001327567-19-000011 — 5.02, 9.01
- 2019-04-01 0001193125-19-094613 — 8.01, 9.01
- 2019-03-28 0001193125-19-090572 — 3.02 — amendment of 0001327567-19-000003
- 2019-02-26 0001327567-19-000006 — 2.02, 8.01, 9.01
- 2019-02-19 0001327567-19-000003 — 3.02
- 2018-12-11 0001327567-18-000033 — 5.07
- 2018-11-29 0001327567-18-000029 — 2.02, 9.01
- 2018-10-15 0001193125-18-299312 — 5.02, 9.01
- 2018-09-25 0001193125-18-282542 — 5.02
- 2018-09-14 0001193125-18-274239 — 5.03, 9.01
- 2018-09-06 0001327567-18-000018 — 1.01, 2.02, 2.03, 9.01
- 2018-07-13 0001193125-18-217281 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2018-06-04 0001327567-18-000011 — 2.02, 5.02, 9.01
- 2018-02-26 0001327567-18-000004 — 2.02, 5.02, 7.01, 9.01
- 2017-12-12 0001193125-17-367477 — 5.07
- 2017-11-20 0001327567-17-000032 — 2.02, 5.02, 9.01
- 2017-08-31 0001327567-17-000021 — 2.02, 5.02, 9.01
- 2017-05-31 0001327567-17-000016 — 2.02, 9.01
- 2017-02-28 0001327567-17-000005 — 2.02, 8.01, 9.01
- 2016-12-12 0001193125-16-790757 — 5.07
- 2016-11-21 0001327567-16-000071 — 2.02, 9.01
- 2016-10-24 0001193125-16-745121 — 5.02, 9.01
- 2016-08-30 0001327567-16-000057 — 2.02, 5.03, 8.01, 9.01
- 2016-08-22 0001193125-16-687588 — 5.02, 9.01
- 2016-05-26 0001327567-16-000051 — 2.02, 9.01
- 2016-02-25 0001327567-16-000044 — 2.02, 5.02, 9.01
- 2015-12-14 0001327567-15-000038 — 5.07
- 2015-12-14 0001193125-15-402588 — 1.01, 9.01
- 2015-11-23 0001327567-15-000033 — 2.02, 9.01
- 2015-10-19 0001193125-15-347005 — 1.01, 9.01 — amendment, the index does not say of what
- 2015-09-09 0001327567-15-000022 — 2.02, 9.01
- 2015-08-19 0001193125-15-296115 — 1.01, 2.03
- 2015-06-01 0001193125-15-207786 — 1.01, 2.03
- 2015-05-27 0001327567-15-000015 — 2.02, 9.01
- 2015-03-02 0001327567-15-000006 — 2.02, 9.01
- 2014-12-15 0001327567-14-000046 — 5.07
- 2014-11-24 0001327567-14-000040 — 2.02, 9.01
- 2014-09-22 0001193125-14-348581 — 5.02, 9.01
- 2014-09-09 0001327567-14-000025 — 2.02, 9.01
- 2014-07-01 0001193125-14-257824 — 1.01, 2.03, 3.02, 9.01
- 2014-06-26 0001193125-14-249529 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2014-06-20 0001327567-14-000020 — 9.01 — amendment of 0001193125-14-140511
- 2014-06-04 0001327567-14-000016 — 3.02
- 2014-05-30 0001193125-14-218158 — 2.02 — amendment, the index does not say of what
- 2014-05-28 0001193125-14-215060 — 1.01, 2.02, 3.02, 9.01
- 2014-04-11 0001193125-14-140511 — 2.01, 3.02, 7.01, 9.01
- 2014-03-24 0001193125-14-111318 — 1.01, 3.02, 7.01, 9.01
- 2014-03-13 0001327567-14-000009 — 5.02
- 2014-02-24 0001193125-14-063754 — 2.02, 9.01
- 2013-12-12 0001327567-13-000040 — 5.07
- 2013-11-25 0001327567-13-000033 — 2.02, 9.01
- 2013-09-30 0001193125-13-384966 — 8.01
- 2013-09-09 0001193125-13-361421 — 2.02, 9.01
- 2013-05-30 0001193125-13-241542 — 2.02, 5.02, 9.01
- 2013-03-11 0001193125-13-101082 — 5.02, 9.01
- 2013-02-28 0001193125-13-084193 — 2.02, 9.01
- 2012-12-14 0001193125-12-503335 — 5.07
- 2012-12-06 0001193125-12-493700 — 2.02, 9.01
- 2012-09-24 0001193125-12-401534 — 1.01, 2.03
- 2012-09-20 0001193125-12-398433 — 5.02, 9.01
- 2012-09-10 0001193125-12-386605 — 2.02, 9.01

## late-filing notifications on or before 2020-05-22

- none on or before 2020-05-22

## item 2.02 — earnings release, exhibit 99.1

[0001327567-20-000015:8k_2_02:1]
EX-99.1
2
ex991q320earningsrelea.htm
EX-99.1

[0001327567-20-000015:8k_2_02:2]
Document

[0001327567-20-000015:8k_2_02:3]
Exhibit 99.1

[0001327567-20-000015:8k_2_02:4]
Palo Alto Networks Reports Fiscal Third Quarter 2020 Financial Results

[0001327567-20-000015:8k_2_02:5]
•Fiscal third quarter revenue grows 20% year over year to $869.4 million

[0001327567-20-000015:8k_2_02:6]
•Billings increase 24% year over year to $1.0 billion

[0001327567-20-000015:8k_2_02:7]
•Deferred revenue grows 28% year over year to $3.4 billion

[0001327567-20-000015:8k_2_02:8]
SANTA CLARA, Calif. - May. 21, 2020 - Palo Alto Networks (NYSE: PANW), the global cybersecurity leader, announced today financial results for its fiscal third quarter 2020, ended April 30, 2020.

[0001327567-20-000015:8k_2_02:9]
Total revenue for the fiscal third quarter 2020 grew 20% year over year to $869.4 million, compared with total revenue of $726.6 million for the fiscal third quarter 2019. GAAP net loss for the fiscal third quarter 2020 was $74.8 million, or $0.77 per diluted share, compared with GAAP net loss of $20.2 million, or $0.21 per diluted share, for the fiscal third quarter 2019.

[0001327567-20-000015:8k_2_02:10]
Non-GAAP net income for the fiscal third quarter 2020 was $114.6 million, or $1.17 per diluted share, compared with non-GAAP net income of $130.1 million, or $1.31 per diluted share, for the fiscal third quarter 2019. A reconciliation between GAAP and non-GAAP information is contained in the tables below.

[0001327567-20-000015:8k_2_02:11]
“The world will likely be in a state of transition over the next 12 to 18 months due to the COVID-19 pandemic. We believe this will prompt key trends to accelerate, including remote working models, shift to the cloud, and focus on AI/ML and automation to drive effective cybersecurity outcomes,” said Nikesh Arora, chairman and CEO of Palo Alto Networks. “Palo Alto Networks is well positioned to leverage the acceleration of these trends, with our significant and ongoing investments to transform our company into a multi-product, integrated platform provider of cybersecurity solutions. As our performance this quarter demonstrates, we are entering this transition in a position of strength, and while the path might be bumpy, we believe we will emerge stronger as we continue providing the best security solutions for our customers.”

[0001327567-20-000015:8k_2_02:12]
Financial Outlook

[0001327567-20-000015:8k_2_02:13]
Palo Alto Networks provides guidance based on current market conditions and expectations.

[0001327567-20-000015:8k_2_02:14]
For the fiscal fourth quarter 2020, we expect:

[0001327567-20-000015:8k_2_02:15]
•Total billings in the range of $1.190 billion to $1.210 billion, representing year-over-year growth of between 13% and 14%.

[0001327567-20-000015:8k_2_02:16]
•Total revenue in the range of $915 million to $925 million, representing year-over-year growth between 14% and 15%.

[0001327567-20-000015:8k_2_02:17]
•Diluted non-GAAP net income per share in the range of $1.37 to $1.40, which incorporates approximately $8 million of net expense, or $0.06 per share, related to the acquisition of CloudGenix, using 96.0 million to 98.0 million shares.

[0001327567-20-000015:8k_2_02:18]
For the full year fiscal 2020, we expect:

[0001327567-20-000015:8k_2_02:19]
•Total billings in the range of $4.102 billion to $4.122 billion, representing year-over-year growth of 18%.

[0001327567-20-000015:8k_2_02:20]
•Total revenue in the range of $3.373 billion to $3.383 billion, representing year-over-year growth between 16% and 17%.

[0001327567-20-000015:8k_2_02:21]
•Diluted non-GAAP net income per share in the range of $4.78 to $4.81, using 98.0 million to 100.0 million shares.

[0001327567-20-000015:8k_2_02:22]
•Adjusted free cash flow margin of approximately 27% - 28%, which excludes cash flow associated with the additional investment in our headquarters in Santa Clara and a cash payment associated with a litigation-related settlement.

[0001327567-20-000015:8k_2_02:23]
Guidance for non-GAAP financial measures excludes share-based compensation-related charges, including share-based payroll tax expense, acquisition-related costs, amortization expense of acquired intangible assets, litigation-related charges, including legal settlements, gains (losses) related to facility exit, non-cash charges related to convertible notes, foreign currency gains (losses), and income and other tax effects associated with these items, along with certain non-recurring expenses. We have not reconciled diluted non-GAAP net income per share guidance to GAAP net income (loss) per diluted share because we do not provide guidance on GAAP net income (loss) and would not be able to present the various reconciling cash and non-cash items between GAAP net income (loss) and non-GAAP net income, including share-based compensation expense, without unreasonable effort. Share-based compensation expense is impacted by the company's future hiring and retention needs and, to a lesser extent, the future fair

[0001327567-20-000015:8k_2_02:24]
market value of the company's common stock, all of which is difficult to predict and subject to constant change. The actual amounts of such reconciling items will have a significant impact on the company's GAAP net income (loss) per diluted share.

[0001327567-20-000015:8k_2_02:25]
Stockholder Letter

[0001327567-20-000015:8k_2_02:26]
Palo Alto Networks issued a stockholder letter today, which can be found on the “Investors” section of the company’s website at investors.paloaltonetworks.com.

[0001327567-20-000015:8k_2_02:27]
Earnings Call Information

[0001327567-20-000015:8k_2_02:28]
Palo Alto Networks will host a video webcast for analysts and investors to discuss its fiscal third quarter 2020 results and outlook for its fiscal fourth quarter and full year 2020 today at 4:30 p.m. Eastern time/1:30 p.m. Pacific time. Open to the public, investors may access the webcast, supplemental financial information and earnings slides from the “Investors” section of the company’s website at investors.paloaltonetworks.com. A replay will be available three hours after the conclusion of the webcast and archived for one year.

[0001327567-20-000015:8k_2_02:29]
Forward-Looking Statements

[0001327567-20-000015:8k_2_02:30]
This press release contains forward-looking statements that involve risks, uncertainties, and assumptions including statements regarding (1) our financial outlook for the fiscal fourth quarter and full year fiscal 2020 and (2) the length of the transition and changes caused by COVID-19, including the acceleration of certain trends, and our ability to leverage this acceleration and emerge from this transition in a position of strength. Many of these assumptions relate to matters that are beyond our control and changing rapidly, including, but not limited to, the timeframes for and severity of social distancing and other mitigation requirements, the impact of COVID-19 on our customers’ purchasing decisions and the length of our sales cycles, particularly for customers in certain industries highly affected by COVID-19. There are a significant number of factors that could cause actual results to differ materially from statements made in this press release, including: developments and changes in general market, political, economic, and business conditions; the duration and global impact of COVID-19; our ability as an organization to acquire and integrate other companies, products or technologies in a successful manner; risks associated with managing our growth; the risks associated with new products and subscription and support offerings, including the discovery of software bugs; our competitive position; our ability to attract and retain new customers; shift in priorities or delays in the development or release of new subscription offerings, or the failure to timely develop and achieve market acceptance of new

[0001327567-20-000015:8k_2_02:31]
products and subscriptions as well as existing products and subscription and support offerings; rapidly evolving technological developments in the market for security products and subscription and support offerings; and length of sales cycles.

[0001327567-20-000015:8k_2_02:32]
Additional risks and uncertainties that could affect our financial results are included under the captions “Risk Factors” and “Management’s Discussion and Analysis of Financial Condition and Results of Operations” in our Quarterly Report on Form 10-Q filed with the SEC on February 25, 2020, which is available on our website at investors.paloaltonetworks.com and on the SEC’s website at www.sec.gov. Additional information will also be set forth in other filings that we make with the SEC from time to time. All forward-looking statements in this press release are based on information available to us as of the date hereof, and we do not assume any obligation to update the forward-looking statements provided to reflect events that occur or circumstances that exist after the date on which they were made.

[0001327567-20-000015:8k_2_02:33]
Non-GAAP Financial Measures and Other Key Metrics

[0001327567-20-000015:8k_2_02:34]
Palo Alto Networks has provided in this press release financial information that has not been prepared in accordance with generally accepted accounting principles in the United States (GAAP). The company uses these non-GAAP financial measures and other key metrics internally in analyzing its financial results and believes that the use of these non-GAAP financial measures and key metrics are useful to investors as an additional tool to evaluate ongoing operating results and trends, and in comparing the company’s financial results with other companies in its industry, many of which present similar non-GAAP financial measures or key metrics.

[0001327567-20-000015:8k_2_02:35]
The presentation of these non-GAAP financial measures and key metrics are not meant to be considered in isolation or as a substitute for comparable GAAP financial measures and should be read only in conjunction with the company’s consolidated financial statements prepared in accordance with GAAP. A reconciliation of the company’s historical non-GAAP financial measures to their most directly comparable GAAP measures has been provided in the financial statement tables included in this press release, and investors are encouraged to review these reconciliations.

[0001327567-20-000015:8k_2_02:36]
Non-GAAP net income and net income per share, diluted. Palo Alto Networks defines non-GAAP net income as net income (loss) plus share-based compensation-related charges, including share-based payroll tax expense, acquisition-related costs, amortization expense of acquired intangible assets, litigation-related charges, including legal settlements, gains (losses) related to facility exit, non-cash charges related to convertible notes, and intellectual property restructuring-related

[0001327567-20-000015:8k_2_02:37]
4

[0001327567-20-000015:8k_2_02:38]
charges. The company also excludes from non-GAAP net income the foreign currency gains (losses) and tax effects associated with these items in order to provide a complete picture of the company’s recurring core business operating results. The company defines non-GAAP net income per share, diluted, as non-GAAP net income divided by the weighted-average diluted shares outstanding, which includes the potentially dilutive effect of the company’s employee equity incentive plan awards and the company’s convertible senior notes outstanding and related warrants, after giving effect to the anti-dilutive impact of the company’s note hedge agreements, which reduces the potential economic dilution that otherwise would occur upon conversion of the company’s convertible senior notes. Under GAAP, the anti-dilutive impact of the note hedge is not reflected in diluted shares outstanding. The company believes that excluding these items from non-GAAP net income and net income per share, diluted, provides management and investors with greater visibility into the underlying performance of the company’s core business operating results, meaning its operating performance excluding these items and, from time to time, other discrete charges that are infrequent in nature, over multiple periods.

[0001327567-20-000015:8k_2_02:39]
Billings. Palo Alto Networks defines billings as total revenue plus the change in total deferred revenue, net of acquired deferred revenue, during the period. The company considers billings to be a key metric used by management to manage the company's business given the company's hybrid-SaaS revenue model, and believes billings provides investors with an important indicator of the health and visibility of the company's business because it includes subscription and support revenue, which is recognized ratably over the contractual service period, and product revenue, which is recognized at the time of shipment, provided that all other conditions for revenue recognition have been met. The company considers billings to be a useful metric for management and investors, particularly if sales of subscriptions continue to increase and the company experiences strong renewal rates for subscriptions and support.

[0001327567-20-000015:8k_2_02:40]
Investors are cautioned that there are a number of limitations associated with the use of non-GAAP financial measures and key metrics as analytical tools. In particular, the billings metric reported by the company includes amounts that have not yet been recognized as revenue. Additionally, many of the adjustments to the company’s GAAP financial measures reflect the exclusion of items that are recurring and will be reflected in the company’s financial results for the foreseeable future, such as share-based compensation, which is an important part of Palo Alto Networks employees’ compensation and impacts their performance. Furthermore, these non-GAAP financial measures are not based on any standardized methodology prescribed by GAAP,

[0001327567-20-000015:8k_2_02:41]
and the components that Palo Alto Networks excludes in its calculation of non-GAAP financial measures may differ from the components that its peer companies exclude when they report their non-GAAP results of operations. Palo Alto Networks compensates for these limitations by providing specific information regarding the GAAP amounts excluded from these non-GAAP financial measures. In the future, the company may also exclude non-recurring expenses and other expenses that do not reflect the company’s core business operating results.

[0001327567-20-000015:8k_2_02:42]
About Palo Alto Networks

[0001327567-20-000015:8k_2_02:43]
Palo Alto Networks, the global cybersecurity leader, is shaping the cloud-centric future with technology that is transforming the way people and organizations operate. Our mission is to be the cybersecurity partner of choice, protecting our digital way of life. We help address the world's greatest security challenges with continuous innovation that seizes the latest breakthroughs in artificial intelligence, analytics, automation, and orchestration. By delivering an integrated platform and empowering a growing ecosystem of partners, we are at the forefront of protecting tens of thousands of organizations across clouds, networks, and mobile devices. Our vision is a world where each day is safer and more secure than the one before. For more information, visit www.paloaltonetworks.com.

[0001327567-20-000015:8k_2_02:44]
Palo Alto Networks and the Palo Alto Networks logo are trademarks of Palo Alto Networks, Inc. in the United States and in jurisdictions throughout the world. All other trademarks, trade names, or service marks used or mentioned herein belong to their respective owners.

[0001327567-20-000015:8k_2_02:45]
Media Contact:

[0001327567-20-000015:8k_2_02:46]
Mara Mort

[0001327567-20-000015:8k_2_02:47]
Senior Director of Corporate Communications, Palo Alto Networks

[0001327567-20-000015:8k_2_02:48]
Mobile: 1-415-850-8645

[0001327567-20-000015:8k_2_02:49]
mmort@paloaltonetworks.com

[0001327567-20-000015:8k_2_02:50]
Investor Relations Contact:

[0001327567-20-000015:8k_2_02:51]
David Niederman

[0001327567-20-000015:8k_2_02:52]
Vice President of Investor Relations, Palo Alto Networks

[0001327567-20-000015:8k_2_02:53]
Office: 1-669-400-7323

[0001327567-20-000015:8k_2_02:54]
dniederman@paloaltonetworks.com

[0001327567-20-000015:8k_2_02:55]
6

[0001327567-20-000015:8k_2_02:56]
| Palo Alto Networks, Inc. |  |  |  |  |  |  |  |
| Preliminary Condensed Consolidated Statements of Operations |  |  |  |  |  |  |  |
| (In millions, except per share data) |  |  |  |  |  |  |  |
| (Unaudited) |  |  |  |  |  |  |  |
|  | Three Months Ended April 30, |  |  |  | Nine Months Ended April 30, |  |  |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Revenue: |  |  |  |  |  |  |  |
| Product | $ | 280.9 |  |  | $ | 278.4 |  |  | $ | 758.6 |  |  | $ | 790.5 |  |
| Subscription and support | 588.5 |  |  | 448.2 |  |  | 1,699.4 |  |  | 1,303.3 |  |
| Total revenue | 869.4 |  |  | 726.6 |  |  | 2,458.0 |  |  | 2,093.8 |  |
| Cost of revenue: |  |  |  |  |  |  |  |
| Product | 73.3 |  |  | 78.0 |  |  | 207.1 |  |  | 233.7 |  |
| Subscription and support | 185.0 |  |  | 126.9 |  |  | 502.0 |  |  | 357.3 |  |
| Total cost of revenue | 258.3 |  |  | 204.9 |  |  | 709.1 |  |  | 591.0 |  |
| Total gross profit | 611.1 |  |  | 521.7 |  |  | 1,748.9 |  |  | 1,502.8 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 196.3 |  |  | 139.1 |  |  | 552.2 |  |  | 380.8 |  |
| Sales and marketing | 388.4 |  |  | 339.0 |  |  | 1,129.0 |  |  | 973.6 |  |
| General and administrative | 82.9 |  |  | 62.3 |  |  | 228.9 |  |  | 192.6 |  |
| Total operating expenses | 667.6 |  |  | 540.4 |  |  | 1,910.1 |  |  | 1,547.0 |  |
| Operating income (loss) | (56.5) |  |  | (18.7) |  |  | (161.2) |  |  | (44.2) |  |
| Interest expense | (19.4) |  |  | (20.6) |  |  | (57.3) |  |  | (63.9) |  |
| Other income, net | 8.1 |  |  | 18.2 |  |  | 35.1 |  |  | 47.2 |  |
| Income (loss) before income taxes | (67.8) |  |  | (21.1) |  |  | (183.4) |  |  | (60.9) |  |
| Provision for (benefit from) income taxes | 7.0 |  |  | (0.9) |  |  | 24.7 |  |  | 0.2 |  |
| Net loss | $ | (74.8) |  |  | $ | (20.2) |  |  | $ | (208.1) |  |  | $ | (61.1) |  |
| Net loss per share, basic and diluted | $ | (0.77) |  |  | $ | (0.21) |  |  | $ | (2.14) |  |  | $ | (0.65) |  |
| Weighted-average shares used to compute net loss per share, basic and diluted | 96.7 |  |  | 94.4 |  |  | 97.2 |  |  | 94.1 |  |

[0001327567-20-000015:8k_2_02:57]
| Palo Alto Networks, Inc. |  |  |  |  |  |  |  |
| Reconciliation of GAAP to Non-GAAP Financial Measures |  |  |  |  |  |  |  |
| (In millions, except per share amounts) |  |  |  |  |  |  |  |
| (Unaudited) |  |  |  |  |  |  |  |
|  | Three Months Ended |  |  |  | Nine Months Ended |  |  |
|  | April 30, |  |  |  | April 30, |  |  |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| GAAP net loss | $ | (74.8) |  |  | $ | (20.2) |  |  | $ | (208.1) |  |  | $ | (61.1) |  |
| Share-based compensation-related charges | 173.5 |  |  | 145.8 |  |  | 504.2 |  |  | 436.0 |  |
| Acquisition-related costs(1) | 4.9 |  |  | 2.9 |  |  | 15.3 |  |  | 20.0 |  |
| Amortization expense of acquired intangible assets | 19.2 |  |  | 14.6 |  |  | 53.7 |  |  | 38.0 |  |
| Litigation-related charges(2) | 1.8 |  |  | 3.1 |  |  | 1.8 |  |  | 9.2 |  |
| (Gain) loss related to facility exit (3) | — |  |  | 4.1 |  |  | (3.1) |  |  | 4.1 |  |
| Non-cash charges related to convertible notes(4) | 15.8 |  |  | 17.2 |  |  | 47.0 |  |  | 56.3 |  |
| Foreign currency (gain) loss associated with non-GAAP adjustments | (0.6) |  |  | 0.5 |  |  | (0.1) |  |  | 0.6 |  |
| Income tax and other tax adjustments related to the above | (25.2) |  |  | (37.9) |  |  | (71.0) |  |  | (110.6) |  |
| Non-GAAP net income | $ | 114.6 |  |  | $ | 130.1 |  |  | $ | 339.7 |  |  | $ | 392.5 |  |
| GAAP net loss per share, diluted | $ | (0.77) |  |  | $ | (0.21) |  |  | $ | (2.14) |  |  | $ | (0.65) |  |
| Share-based compensation-related charges | 1.78 |  |  | 1.48 |  |  | 5.10 |  |  | 4.45 |  |
| Acquisition-related costs(1) | 0.05 |  |  | 0.03 |  |  | 0.16 |  |  | 0.21 |  |
| Amortization expense of acquired intangible assets | 0.20 |  |  | 0.15 |  |  | 0.55 |  |  | 0.40 |  |
| Litigation-related charges(2) | 0.02 |  |  | 0.03 |  |  | 0.02 |  |  | 0.10 |  |
| (Gain) loss related to facility exit (3) | 0.00 |  |  | 0.04 |  |  | (0.03) |  |  | 0.04 |  |
| Non-cash charges related to convertible notes(4) | 0.16 |  |  | 0.18 |  |  | 0.48 |  |  | 0.60 |  |
| Foreign currency (gain) loss associated with non-GAAP adjustments | (0.01) |  |  | 0.01 |  |  | 0.00 |  |  | 0.01 |  |
| Income tax and other tax adjustments related to the above | (0.26) |  |  | (0.40) |  |  | (0.73) |  |  | (1.18) |  |
| Non-GAAP net income per share, diluted | $ | 1.17 |  |  | $ | 1.31 |  |  | $ | 3.41 |  |  | $ | 3.98 |  |
| GAAP weighted-average shares used to compute net loss per share, diluted | 96.7 |  |  | 94.4 |  |  | 97.2 |  |  | 94.1 |  |
| Weighted-average effect of potentially dilutive securities(5) | 1.1 |  |  | 5.2 |  |  | 2.5 |  |  | 4.6 |  |
| Non-GAAP weighted-average shares used to compute net income per share, diluted | 97.8 |  |  | 99.6 |  |  | 99.7 |  |  | 98.7 |  |

[0001327567-20-000015:8k_2_02:58]
(1) Consists of acquisition transaction costs, share-based compensation related to the cash settlement of certain equity awards, and costs to terminate certain employment, operating lease, and other contracts of the acquired companies.

[0001327567-20-000015:8k_2_02:59]
(2) Consists of the amortization of intellectual property licenses and covenant not to sue.

[0001327567-20-000015:8k_2_02:60]
(3) Consists of a cease-use loss of $4.1 million related to the relocation of the company’s headquarters during the three and nine months ended April 30, 2019 and a gain of $3.1 million related to the early termination of the company’s previous headquarters leases during the nine months ended April 30, 2020.

[0001327567-20-000015:8k_2_02:61]
(4) Consists primarily of non-cash interest expense related to the company’s convertible senior notes. Also includes a non-cash loss of $2.6 million during the nine months ended April 30, 2019 related to early conversions of the convertible notes during the period.

[0001327567-20-000015:8k_2_02:62]
(5) Non-GAAP net income per share, diluted, includes the potentially dilutive effect of employee equity incentive plan awards and convertible senior notes outstanding and related warrants. In addition, non-GAAP net income per share, diluted, includes the anti-dilutive impact of the company’s note hedge agreements, which reduced the potentially dilutive effect of the convertible notes by 0.8 million shares for the three and nine months ended April 30, 2019.

[0001327567-20-000015:8k_2_02:63]
8

[0001327567-20-000015:8k_2_02:64]
| Palo Alto Networks, Inc. |  |  |  |  |  |  |  |
| Calculation of Billings |  |  |  |  |  |  |  |
| (In millions) |  |  |  |  |  |  |  |
| (Unaudited) |  |  |  |  |  |  |  |
|  | Three Months Ended |  |  |  | Nine Months Ended |  |  |
|  | April 30, |  |  |  | April 30, |  |  |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Total revenue | $ | 869.4 |  |  | $ | 726.6 |  |  | $ | 2,458.0 |  |  | $ | 2,093.8 |  |
| Add: change in total deferred revenue, net of acquired deferred revenue | 146.0 |  |  | 95.3 |  |  | 453.7 |  |  | 339.1 |  |
| Billings | $ | 1,015.4 |  |  | $ | 821.9 |  |  | $ | 2,911.7 |  |  | $ | 2,432.9 |  |

[0001327567-20-000015:8k_2_02:65]
9

[0001327567-20-000015:8k_2_02:66]
| Palo Alto Networks, Inc. |  |  |  |
| Preliminary Condensed Consolidated Balance Sheets |  |  |  |
| (In millions) |  |  |  |
| (Unaudited) |  |  |  |
|  | April 30, 2020 |  | July 31, 2019 |
| Assets |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 1,484.7 |  |  | $ | 961.4 |  |
| Short-term investments | 554.1 |  |  | 1,841.7 |  |
| Accounts receivable, net | 668.8 |  |  | 582.4 |  |
| Prepaid expenses and other current assets | 306.4 |  |  | 279.3 |  |
| Total current assets | 3,014.0 |  |  | 3,664.8 |  |
| Property and equipment, net | 357.2 |  |  | 296.0 |  |
| Operating lease right-of-use assets | 263.8 |  |  | — |  |
| Long-term investments | 151.2 |  |  | 575.4 |  |
| Goodwill | 1,812.9 |  |  | 1,352.3 |  |
| Intangible assets, net | 380.6 |  |  | 280.6 |  |
| Other assets | 522.1 |  |  | 423.1 |  |
| Total assets | $ | 6,501.8 |  |  | $ | 6,592.2 |  |
| Liabilities and stockholders’ equity |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 52.3 |  |  | $ | 73.3 |  |
| Accrued compensation | 174.9 |  |  | 235.5 |  |
| Accrued and other liabilities | 253.9 |  |  | 162.4 |  |
| Deferred revenue | 1,854.6 |  |  | 1,582.1 |  |
| Total current liabilities | 2,335.7 |  |  | 2,053.3 |  |
| Convertible senior notes, net | 1,477.0 |  |  | 1,430.0 |  |
| Long-term deferred revenue | 1,516.0 |  |  | 1,306.6 |  |
| Long-term operating lease liabilities | 344.6 |  |  | — |  |
| Other long-term liabilities | 83.8 |  |  | 216.0 |  |
| Stockholders’ equity: |  |  |  |
| Preferred stock | — |  |  | — |  |
| Common stock and additional paid-in capital | 1,855.7 |  |  | 2,490.9 |  |
| Accumulated other comprehensive loss | (2.0) |  |  | (3.7) |  |
| Accumulated deficit | (1,109.0) |  |  | (900.9) |  |
| Total stockholders’ equity | 744.7 |  |  | 1,586.3 |  |
| Total liabilities and stockholders’ equity | $ | 6,501.8 |  |  | $ | 6,592.2 |  |
