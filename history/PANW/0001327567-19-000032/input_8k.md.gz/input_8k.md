# PANW 8-K — 0001327567-19-000023 filed 2019-09-04

## item codes, every 8-K on or before 2019-09-09

- 2019-09-06 0001327567-19-000026 — 9.01 — amendment of 0001327567-19-000023
- 2019-09-04 0001327567-19-000023 — 2.02, 7.01, 9.01
- 2019-07-11 0001193125-19-192415 — 5.02, 9.01
- 2019-05-29 0001327567-19-000014 — 2.02, 9.01
- 2019-04-15 0001327567-19-000011 — 5.02, 9.01
- 2019-04-01 0001193125-19-094613 — 8.01, 9.01
- 2019-03-28 0001193125-19-090572 — 3.02 — amendment of 0001327567-19-000003
- 2019-02-26 0001327567-19-000006 — 2.02, 8.01, 9.01
- 2019-02-19 0001327567-19-000003 — 3.02
- 2018-12-11 0001327567-18-000033 — 5.07
- 2018-11-29 0001327567-18-000029 — 2.02, 9.01
- 2018-10-15 0001193125-18-299312 — 5.02, 9.01
- 2018-09-25 0001193125-18-282542 — 5.02
- 2018-09-14 0001193125-18-274239 — 5.03, 9.01
- 2018-09-06 0001327567-18-000018 — 1.01, 2.02, 2.03, 9.01
- 2018-07-13 0001193125-18-217281 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2018-06-04 0001327567-18-000011 — 2.02, 5.02, 9.01
- 2018-02-26 0001327567-18-000004 — 2.02, 5.02, 7.01, 9.01
- 2017-12-12 0001193125-17-367477 — 5.07
- 2017-11-20 0001327567-17-000032 — 2.02, 5.02, 9.01
- 2017-08-31 0001327567-17-000021 — 2.02, 5.02, 9.01
- 2017-05-31 0001327567-17-000016 — 2.02, 9.01
- 2017-02-28 0001327567-17-000005 — 2.02, 8.01, 9.01
- 2016-12-12 0001193125-16-790757 — 5.07
- 2016-11-21 0001327567-16-000071 — 2.02, 9.01
- 2016-10-24 0001193125-16-745121 — 5.02, 9.01
- 2016-08-30 0001327567-16-000057 — 2.02, 5.03, 8.01, 9.01
- 2016-08-22 0001193125-16-687588 — 5.02, 9.01
- 2016-05-26 0001327567-16-000051 — 2.02, 9.01
- 2016-02-25 0001327567-16-000044 — 2.02, 5.02, 9.01
- 2015-12-14 0001327567-15-000038 — 5.07
- 2015-12-14 0001193125-15-402588 — 1.01, 9.01
- 2015-11-23 0001327567-15-000033 — 2.02, 9.01
- 2015-10-19 0001193125-15-347005 — 1.01, 9.01 — amendment, the index does not say of what
- 2015-09-09 0001327567-15-000022 — 2.02, 9.01
- 2015-08-19 0001193125-15-296115 — 1.01, 2.03
- 2015-06-01 0001193125-15-207786 — 1.01, 2.03
- 2015-05-27 0001327567-15-000015 — 2.02, 9.01
- 2015-03-02 0001327567-15-000006 — 2.02, 9.01
- 2014-12-15 0001327567-14-000046 — 5.07
- 2014-11-24 0001327567-14-000040 — 2.02, 9.01
- 2014-09-22 0001193125-14-348581 — 5.02, 9.01
- 2014-09-09 0001327567-14-000025 — 2.02, 9.01
- 2014-07-01 0001193125-14-257824 — 1.01, 2.03, 3.02, 9.01
- 2014-06-26 0001193125-14-249529 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2014-06-20 0001327567-14-000020 — 9.01 — amendment of 0001193125-14-140511
- 2014-06-04 0001327567-14-000016 — 3.02
- 2014-05-30 0001193125-14-218158 — 2.02 — amendment, the index does not say of what
- 2014-05-28 0001193125-14-215060 — 1.01, 2.02, 3.02, 9.01
- 2014-04-11 0001193125-14-140511 — 2.01, 3.02, 7.01, 9.01
- 2014-03-24 0001193125-14-111318 — 1.01, 3.02, 7.01, 9.01
- 2014-03-13 0001327567-14-000009 — 5.02
- 2014-02-24 0001193125-14-063754 — 2.02, 9.01
- 2013-12-12 0001327567-13-000040 — 5.07
- 2013-11-25 0001327567-13-000033 — 2.02, 9.01
- 2013-09-30 0001193125-13-384966 — 8.01
- 2013-09-09 0001193125-13-361421 — 2.02, 9.01
- 2013-05-30 0001193125-13-241542 — 2.02, 5.02, 9.01
- 2013-03-11 0001193125-13-101082 — 5.02, 9.01
- 2013-02-28 0001193125-13-084193 — 2.02, 9.01
- 2012-12-14 0001193125-12-503335 — 5.07
- 2012-12-06 0001193125-12-493700 — 2.02, 9.01
- 2012-09-24 0001193125-12-401534 — 1.01, 2.03
- 2012-09-20 0001193125-12-398433 — 5.02, 9.01
- 2012-09-10 0001193125-12-386605 — 2.02, 9.01

## late-filing notifications on or before 2019-09-09

- none on or before 2019-09-09

## item 2.02 — earnings release, exhibit 99.1

[0001327567-19-000023:8k_2_02:1]
EX-99.1
2
ex991q419earningsrelease.htm
EXHIBIT 99.1

[0001327567-19-000023:8k_2_02:2]
Exhibit

[0001327567-19-000023:8k_2_02:3]
Exhibit 99.1

[0001327567-19-000023:8k_2_02:4]
Palo Alto Networks Reports Fiscal Fourth Quarter and Fiscal Year 2019 Financial Results

[0001327567-19-000023:8k_2_02:5]
| • | Fiscal fourth quarter revenue grows 22 percent year over year to $805.8 million; fiscal year 2019 revenue grows 28 percent year over year to $2.9 billion |

[0001327567-19-000023:8k_2_02:6]
| • | Fiscal fourth quarter billings grow 22 percent year over year to $1.1 billion; fiscal year 2019 billings grow 22 percent year over year to $3.5 billion |

[0001327567-19-000023:8k_2_02:7]
| • | Deferred revenue grows 27 percent year over year to $2.9 billion |

[0001327567-19-000023:8k_2_02:8]
SANTA CLARA, Calif. — September 4, 2019 — Palo Alto Networks (NYSE: PANW), the global cybersecurity leader, today announced financial results for its fiscal fourth quarter and fiscal year 2019, ended July 31, 2019.

[0001327567-19-000023:8k_2_02:9]
Total revenue for the fiscal fourth quarter 2019 grew 22 percent year over year to $805.8 million, compared with total revenue of $658.5 million for the fiscal fourth quarter 2018. GAAP net loss for the fiscal fourth quarter 2019 was $20.8 million, or $0.22 per diluted share, compared with GAAP net income of $7.0 million, or $0.07 per diluted share, for the fiscal fourth quarter 2018.

[0001327567-19-000023:8k_2_02:10]
Non-GAAP net income for the fiscal fourth quarter 2019 was $146.9 million, or $1.47 per diluted share, compared with non-GAAP net income of $131.7 million, or $1.34 per diluted share, for the fiscal fourth quarter 2018. A reconciliation between GAAP and non-GAAP information is contained in the tables below.

[0001327567-19-000023:8k_2_02:11]
“We had a strong fourth quarter, surpassing a billion dollars in billings within the quarter for the first time, and achieving approximately 180% year-over-year growth in our newer Prisma and Cortex offerings. This year we acquired and released important new technologies and built a

[0001327567-19-000023:8k_2_02:12]
robust go-to-market framework for driving their success in the market. It’s gratifying to see all the team’s hard work translate into strong market results,” said Nikesh Arora, chairman and CEO of Palo Alto Networks. “The addition of our proposed acquisition announced today, Zingbox, Inc., a differentiated player in IoT security, continues our strategy of extending our platforms. Zingbox will add to the capabilities of our Next-Generation Firewall by offering a first-of-its kind subscription that will make it easier for organizations to protect IoT devices from attackers. It will also be available as a service on our Cortex platform.”

[0001327567-19-000023:8k_2_02:13]
Analyst Meeting Information

[0001327567-19-000023:8k_2_02:14]
Palo Alto Networks will host an Investor Event at TheTimesCenter in New York City on Wednesday, September 4 from 4:30 p.m. to approximately 8:00 p.m. Eastern Daylight Time. The in-person event is by invitation only; however, it will be simultaneously accessible via phone and webcast. Interested parties may access the conference call by dialing 1-800-458-4148 or 1-323-794-2093 and using conference ID 8941272. The live audio webcast of the formal investor presentation, along with supplemental financial information, will be accessible beginning at 4:30 p.m. Eastern Daylight Time from the “Investors” section of the Palo Alto Networks website at investors.paloaltonetworks.com. The webcast will be archived for a period of one year. A telephonic replay of the conference call will be available three hours after the call, will run for ten days, and may be accessed by dialing 1-888-203-1112 or 1-719-457-0820 and entering the passcode 8941272.

[0001327567-19-000023:8k_2_02:15]
Forward-Looking Statements

[0001327567-19-000023:8k_2_02:16]
This press release contains forward-looking statements that involve risks and uncertainties, including our proposed acquisition of Zingbox, Inc. and the anticipated benefits of its technology to us and our customers. There are a significant number of factors that could cause actual results to differ materially from statements made in this press release, including: our limited

[0001327567-19-000023:8k_2_02:17]
2

[0001327567-19-000023:8k_2_02:18]
operating history; our ability as an organization to acquire and integrate other companies, products or technologies in a successful manner; risks associated with managing our rapid growth; the risks associated with new products and subscription and support offerings, including the discovery of software bugs; our ability to attract and retain new customers; delays in the development or release of new subscription offerings, or the failure to timely develop and achieve market acceptance of new products and subscriptions as well as existing products and subscription and support offerings; rapidly evolving technological developments in the market for security products and subscription and support offerings; length of sales cycles; and general market, political, economic and business conditions.

[0001327567-19-000023:8k_2_02:19]
Additional risks and uncertainties that could affect our financial results are included under the captions “Risk Factors” and “Management’s Discussion and Analysis of Financial Condition and Results of Operations” in our Quarterly Report on Form 10-Q filed with the SEC on May 30, 2019, which is available on our website at investors.paloaltonetworks.com and on the SEC’s website at www.sec.gov. Additional information will also be set forth in other filings that we make with the SEC from time to time. All forward-looking statements in this press release are based on information available to us as of the date hereof, and we do not assume any obligation to update the forward-looking statements provided to reflect events that occur or circumstances that exist after the date on which they were made.

[0001327567-19-000023:8k_2_02:20]
Non-GAAP Financial Measures and Other Key Metrics

[0001327567-19-000023:8k_2_02:21]
Palo Alto Networks has provided in this press release financial information that has not been prepared in accordance with generally accepted accounting principles in the United States (GAAP). The company uses these non-GAAP financial measures and other key metrics internally in analyzing its financial results and believes that the use of these non-GAAP financial measures and key metrics are useful to investors as an additional tool to evaluate ongoing

[0001327567-19-000023:8k_2_02:22]
operating results and trends, and in comparing the company’s financial results with other companies in its industry, many of which present similar non-GAAP financial measures or key metrics.

[0001327567-19-000023:8k_2_02:23]
The presentation of these non-GAAP financial measures and key metrics are not meant to be considered in isolation or as a substitute for comparable GAAP financial measures and should be read only in conjunction with the company’s consolidated financial statements prepared in accordance with GAAP. A reconciliation of the company’s historical non-GAAP financial measures to their most directly comparable GAAP measures has been provided in the financial statement tables included in this press release, and investors are encouraged to review these reconciliations.

[0001327567-19-000023:8k_2_02:24]
Non-GAAP net income and net income per share, diluted. Palo Alto Networks defines non-GAAP net income as net income (loss) plus share-based compensation-related charges, including share-based payroll tax expense, acquisition-related costs, amortization expense of acquired intangible assets, litigation-related charges, including legal settlements, facility exit costs, non-cash charges related to convertible notes, and intellectual property restructuring-related charges. The company also excludes from non-GAAP net income the foreign currency gains (losses) and tax effects associated with these items in order to provide a complete picture of the company’s recurring core business operating results. The company defines non-GAAP net income per share, diluted, as non-GAAP net income divided by the weighted-average diluted shares outstanding, which includes the potentially dilutive effect of the company’s employee equity incentive plan awards and the company’s convertible senior notes outstanding and related warrants, after giving effect to the anti-dilutive impact of the company’s note hedge agreements, which reduces the potential economic dilution that otherwise would occur upon conversion of the company’s convertible senior notes. Under GAAP, the anti-dilutive impact of

[0001327567-19-000023:8k_2_02:25]
4

[0001327567-19-000023:8k_2_02:26]
the note hedge is not reflected in diluted shares outstanding. The company believes that excluding these items from non-GAAP net income and net income per share, diluted, provides management and investors with greater visibility into the underlying performance of the company’s core business operating results, meaning its operating performance excluding these items and, from time to time, other discrete charges that are infrequent in nature, over multiple periods.

[0001327567-19-000023:8k_2_02:27]
Billings. Palo Alto Networks defines billings as total revenue plus the change in total deferred revenue, net of acquired deferred revenue, during the period. The company considers billings to be a key metric used by management to manage the company’s business given the company’s hybrid-SaaS revenue model, and believes billings provides investors with an important indicator of the health and visibility of the company’s business because it includes subscription and support revenue, which is recognized ratably over the contractual service period, and product revenue, which is recognized at the time of shipment, provided that all other conditions for revenue recognition have been met. The company considers billings to be a useful metric for management and investors, particularly if sales of subscriptions continue to increase and the company experiences strong renewal rates for subscriptions and support.

[0001327567-19-000023:8k_2_02:28]
Investors are cautioned that there are a number of limitations associated with the use of non-GAAP financial measures and key metrics as analytical tools. In particular, the billings metric reported by the company includes amounts that have not yet been recognized as revenue. Additionally, many of the adjustments to the company’s GAAP financial measures reflect the exclusion of items that are recurring and will be reflected in the company’s financial results for the foreseeable future, such as share-based compensation, which is an important part of Palo Alto Networks employees’ compensation and impacts their performance. Furthermore, these non-GAAP financial measures are not based on any standardized methodology prescribed by

[0001327567-19-000023:8k_2_02:29]
GAAP, and the components that Palo Alto Networks excludes in its calculation of non-GAAP financial measures may differ from the components that its peer companies exclude when they report their non-GAAP results of operations. Palo Alto Networks compensates for these limitations by providing specific information regarding the GAAP amounts excluded from these non-GAAP financial measures. In the future, the company may also exclude non-recurring expenses and other expenses that do not reflect the company’s core business operating results.

[0001327567-19-000023:8k_2_02:30]
About Palo Alto Networks

[0001327567-19-000023:8k_2_02:31]
Palo Alto Networks, the global cybersecurity leader, is shaping the cloud-centric future with technology that is transforming the way people and organizations operate. Our mission is to be the cybersecurity partner of choice, protecting our digital way of life. We help address the world’s greatest security challenges with continuous innovation that seizes the latest breakthroughs in artificial intelligence, analytics, automation, and orchestration. By delivering an integrated platform and empowering a growing ecosystem of partners, we are at the forefront of protecting tens of thousands of organizations across clouds, networks, and mobile devices. Our vision is a world where each day is safer and more secure than the one before. For more information, visit www.paloaltonetworks.com.

[0001327567-19-000023:8k_2_02:32]
Palo Alto Networks, Prisma, Cortex, and the Palo Alto Networks logo are trademarks of Palo Alto Networks, Inc. in the United States and in jurisdictions throughout the world. All other trademarks, trade names, or service marks used or mentioned herein belong to their respective owners.

[0001327567-19-000023:8k_2_02:33]
Media Contact:

[0001327567-19-000023:8k_2_02:34]
Kristen Batch

[0001327567-19-000023:8k_2_02:35]
Senior Vice President of Corporate Communications, Palo Alto Networks

[0001327567-19-000023:8k_2_02:36]
Mobile: 503-516-6297

[0001327567-19-000023:8k_2_02:37]
kbatch@paloaltonetworks.com

[0001327567-19-000023:8k_2_02:38]
Investor Relations Contact:

[0001327567-19-000023:8k_2_02:39]
David Niederman

[0001327567-19-000023:8k_2_02:40]
Vice President of Investor Relations, Palo Alto Networks

[0001327567-19-000023:8k_2_02:41]
Office: 669-400-7323

[0001327567-19-000023:8k_2_02:42]
dniederman@paloaltonetworks.com

[0001327567-19-000023:8k_2_02:43]
| Palo Alto Networks, Inc. |
| Preliminary Consolidated Statements of Operations |
| (In millions, except per share data) |
| (Unaudited) |
|  | Three Months Ended July 31, |  | Year Ended July 31, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
|  |  |  | (As Adjusted)(1) |  |  |  | (As Adjusted)(1) |
| Revenue: |  |  |  |  |  |  |  |
| Product | $ | 305.7 |  |  | $ | 272.1 |  |  | $ | 1,096.2 |  |  | $ | 879.8 |  |
| Subscription and support | 500.1 |  |  | 386.4 |  |  | 1,803.4 |  |  | 1,393.8 |  |
| Total revenue | 805.8 |  |  | 658.5 |  |  | 2,899.6 |  |  | 2,273.6 |  |
| Cost of revenue: |  |  |  |  |  |  |  |
| Product | 82.2 |  |  | 82.0 |  |  | 315.9 |  |  | 272.4 |  |
| Subscription and support | 135.2 |  |  | 102.5 |  |  | 492.5 |  |  | 372.7 |  |
| Total cost of revenue | 217.4 |  |  | 184.5 |  |  | 808.4 |  |  | 645.1 |  |
| Total gross profit | 588.4 |  |  | 474.0 |  |  | 2,091.2 |  |  | 1,628.5 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 158.7 |  |  | 110.3 |  |  | 539.5 |  |  | 400.7 |  |
| Sales and marketing | 370.4 |  |  | 289.9 |  |  | 1,344.0 |  |  | 1,074.2 |  |
| General and administrative | 69.2 |  |  | 56.7 |  |  | 261.8 |  |  | 257.8 |  |
| Total operating expenses | 598.3 |  |  | 456.9 |  |  | 2,145.3 |  |  | 1,732.7 |  |
| Operating income (loss) | (9.9 | ) |  | 17.1 |  |  | (54.1 | ) |  | (104.2 | ) |
| Interest expense | (20.0 | ) |  | (10.4 | ) |  | (83.9 | ) |  | (29.6 | ) |
| Other income, net | 16.2 |  |  | 10.2 |  |  | 63.4 |  |  | 28.5 |  |
| Income (loss) before income taxes | (13.7 | ) |  | 16.9 |  |  | (74.6 | ) |  | (105.3 | ) |
| Provision for income taxes | 7.1 |  |  | 9.9 |  |  | 7.3 |  |  | 16.9 |  |
| Net income (loss) | $ | (20.8 | ) |  | $ | 7.0 |  |  | $ | (81.9 | ) |  | $ | (122.2 | ) |
| Net income (loss) per share, basic | $ | (0.22 | ) |  | $ | 0.08 |  |  | $ | (0.87 | ) |  | $ | (1.33 | ) |
| Net income (loss) per share, diluted | $ | (0.22 | ) |  | $ | 0.07 |  |  | $ | (0.87 | ) |  | $ | (1.33 | ) |
| Weighted-average shares used to compute net income (loss) per share, basic | 95.8 |  |  | 92.8 |  |  | 94.5 |  |  | 91.7 |  |
| Weighted-average shares used to compute net income (loss) per share, diluted | 95.8 |  |  | 100.5 |  |  | 94.5 |  |  | 91.7 |  |

[0001327567-19-000023:8k_2_02:44]
______________

[0001327567-19-000023:8k_2_02:45]
| (1) | Certain amounts have been adjusted due to the company’s adoption of the new revenue recognition standard (ASC 606) as of August 1, 2018 using the full retrospective method. |

[0001327567-19-000023:8k_2_02:46]
8

[0001327567-19-000023:8k_2_02:47]
| Palo Alto Networks, Inc. |
| Reconciliation of GAAP to Non-GAAP Financial Measures |
| (In millions, except per share amounts) |
| (Unaudited) |
|  | Three Months Ended |  | Year Ended |
|  | July 31, |  | July 31, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
|  |  |  | (As Adjusted)(1) |  |  |  | (As Adjusted)(1) |
| GAAP net income (loss) | $ | (20.8 | ) |  | $ | 7.0 |  |  | $ | (81.9 | ) |  | $ | (122.2 | ) |
| Share-based compensation-related charges | 155.3 |  |  | 128.1 |  |  | 591.3 |  |  | 516.4 |  |
| Acquisition-related costs(2) | 9.8 |  |  | 4.6 |  |  | 29.8 |  |  | 17.9 |  |
| Amortization expense of acquired intangible assets | 15.0 |  |  | 7.0 |  |  | 53.0 |  |  | 15.6 |  |
| Litigation-related charges(3) | 1.0 |  |  | 3.1 |  |  | 10.2 |  |  | 12.3 |  |
| Facility exit costs(4) | 2.9 |  |  | — |  |  | 7.0 |  |  | 40.8 |  |
| Non-cash charges related to convertible notes(5) | 16.5 |  |  | 9.6 |  |  | 72.8 |  |  | 28.8 |  |
| Foreign currency (gain) loss associated with non-GAAP adjustments | 1.5 |  |  | (0.5 | ) |  | 2.1 |  |  | (1.0 | ) |
| Income tax and other tax adjustments related to the above(6) | (34.3 | ) |  | (27.2 | ) |  | (144.9 | ) |  | (107.9 | ) |
| Non-GAAP net income | $ | 146.9 |  |  | $ | 131.7 |  |  | $ | 539.4 |  |  | $ | 400.7 |  |
| GAAP net income (loss) per share, diluted | $ | (0.22 | ) |  | $ | 0.07 |  |  | $ | (0.87 | ) |  | $ | (1.33 | ) |
| Share-based compensation-related charges | 1.56 |  |  | 1.29 |  |  | 6.00 |  |  | 5.47 |  |
| Acquisition-related costs(2) | 0.10 |  |  | 0.05 |  |  | 0.32 |  |  | 0.20 |  |
| Amortization expense of acquired intangible assets | 0.16 |  |  | 0.07 |  |  | 0.56 |  |  | 0.17 |  |
| Litigation-related charges(3) | 0.01 |  |  | 0.03 |  |  | 0.11 |  |  | 0.13 |  |
| Facility exit costs(4) | 0.03 |  |  | 0.00 |  |  | 0.07 |  |  | 0.44 |  |
| Non-cash charges related to convertible notes(5) | 0.17 |  |  | 0.10 |  |  | 0.77 |  |  | 0.31 |  |
| Foreign currency (gain) loss associated with non-GAAP adjustments | 0.02 |  |  | 0.00 |  |  | 0.02 |  |  | (0.01 | ) |
| Income tax and other tax adjustments related to the above(6) | (0.36 | ) |  | (0.27 | ) |  | (1.53 | ) |  | (1.18 | ) |
| Non-GAAP net income per share, diluted | $ | 1.47 |  |  | $ | 1.34 |  |  | $ | 5.45 |  |  | $ | 4.20 |  |
| GAAP weighted-average shares used to compute net income (loss) per share, diluted | 95.8 |  |  | 100.5 |  |  | 94.5 |  |  | 91.7 |  |
| Weighted-average effect of potentially dilutive securities(7) | 4.2 |  |  | (2.5 | ) |  | 4.5 |  |  | 3.8 |  |
| Non-GAAP weighted-average shares used to compute net income per share, diluted | 100.0 |  |  | 98.0 |  |  | 99.0 |  |  | 95.5 |  |

[0001327567-19-000023:8k_2_02:48]
___________

[0001327567-19-000023:8k_2_02:49]
| (1) | Certain amounts have been adjusted due to the company’s adoption of the new revenue recognition standard (ASC 606) as of August 1, 2018 using the full retrospective method. |

[0001327567-19-000023:8k_2_02:50]
| (2) | Consists of acquisition transaction costs, share-based compensation related to the cash settlement of certain equity awards, and costs to terminate certain employment, operating lease, and other contracts of the acquired companies. |

[0001327567-19-000023:8k_2_02:51]
| (3) | Consists of the amortization of intellectual property licenses. |

[0001327567-19-000023:8k_2_02:52]
| (4) | Consists of charges related to the relocation of the company’s corporate headquarters (cease-use loss of $39.2 million and accelerated depreciation during the fiscal year ended July 31, 2018 and additional cease-use loss of $7.0 million during the fiscal year ended July 31, 2019) and charges related to the relocation of the company’s research and development center in Israel (cease-use loss of $1.3 million and accelerated depreciation during the fiscal year ended July 31, 2018). |

[0001327567-19-000023:8k_2_02:53]
| (5) | Consists primarily of non-cash interest expense related to the company’s convertible senior notes. Also includes a non-cash loss of $2.6 million during the fiscal year ended July 31, 2019, related to early conversions of the convertible notes during the period. |

[0001327567-19-000023:8k_2_02:54]
| (6) | The company changed its non-GAAP effective tax rate from 31% to 22% in its second quarter of fiscal 2018 due to the reduction of the U.S. federal corporate income tax rate under the U.S. Tax Cuts and Jobs Act, which was enacted into law on December 22, 2017. |

[0001327567-19-000023:8k_2_02:55]
| (7) | Non-GAAP net income per share, diluted, includes the potentially dilutive effect of employee equity incentive plan awards and convertible senior notes outstanding and related warrants. In addition, non-GAAP net income per share, diluted, includes the anti-dilutive impact of the company’s note hedge agreements, which reduced the potentially dilutive effect of the convertible notes by 0.6 million shares for the fiscal year ended July 31, 2019, and 2.5 million shares and 1.8 million shares for the fiscal fourth quarter and fiscal year ended July 31, 2018, respectively. |

[0001327567-19-000023:8k_2_02:56]
9

[0001327567-19-000023:8k_2_02:57]
| Palo Alto Networks, Inc. |
| Calculation of Billings |
| (In millions) |
| (Unaudited) |
|  | Three Months Ended |  | Year Ended |
|  | July 31, |  | July 31, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
|  |  |  | (As Adjusted)(1) |  |  |  | (As Adjusted)(1) |
| Total revenue | $ | 805.8 |  |  | $ | 658.5 |  |  | $ | 2,899.6 |  |  | $ | 2,273.6 |  |
| Add: change in total deferred revenue, net of acquired deferred revenue | 251.1 |  |  | 204.4 |  |  | 590.2 |  |  | 582.6 |  |
| Billings | $ | 1,056.9 |  |  | $ | 862.9 |  |  | $ | 3,489.8 |  |  | $ | 2,856.2 |  |

[0001327567-19-000023:8k_2_02:58]
___________

[0001327567-19-000023:8k_2_02:59]
| (1) | These amounts have been adjusted due to the company’s adoption of the new revenue recognition standard (ASC 606) as of August 1, 2018 using the full retrospective method. |

[0001327567-19-000023:8k_2_02:60]
10

[0001327567-19-000023:8k_2_02:61]
| Palo Alto Networks, Inc. |
| Preliminary Consolidated Balance Sheets |
| (In millions) |
| (Unaudited) |
|  | July 31, 2019 |  | July 31, 2018 |
|  |  |  | (As Adjusted)(1) |
| Assets |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 961.4 |  |  | $ | 2,506.9 |  |
| Short-term investments | 1,841.7 |  |  | 896.5 |  |
| Accounts receivable, net | 582.4 |  |  | 467.0 |  |
| Prepaid expenses and other current assets | 279.3 |  |  | 268.1 |  |
| Total current assets | 3,664.8 |  |  | 4,138.5 |  |
| Property and equipment, net | 296.0 |  |  | 273.1 |  |
| Long-term investments | 575.4 |  |  | 547.5 |  |
| Goodwill | 1,352.3 |  |  | 522.8 |  |
| Intangible assets, net | 280.6 |  |  | 140.8 |  |
| Other assets | 423.1 |  |  | 326.2 |  |
| Total assets | $ | 6,592.2 |  |  | $ | 5,948.9 |  |
| Liabilities, temporary equity, and stockholders’ equity |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 73.3 |  |  | $ | 49.4 |  |
| Accrued compensation | 235.5 |  |  | 163.7 |  |
| Accrued and other liabilities | 162.4 |  |  | 124.6 |  |
| Deferred revenue | 1,582.1 |  |  | 1,213.6 |  |
| Convertible senior notes, net | — |  |  | 550.4 |  |
| Total current liabilities | 2,053.3 |  |  | 2,101.7 |  |
| Convertible senior notes, net | 1,430.0 |  |  | 1,369.7 |  |
| Long-term deferred revenue | 1,306.6 |  |  | 1,065.7 |  |
| Other long-term liabilities | 216.0 |  |  | 229.6 |  |
| Temporary equity | — |  |  | 21.9 |  |
| Stockholders’ equity: |  |  |  |
| Preferred stock | — |  |  | — |  |
| Common stock and additional paid-in capital | 2,490.9 |  |  | 1,967.4 |  |
| Accumulated other comprehensive loss | (3.7 | ) |  | (16.4 | ) |
| Accumulated deficit | (900.9 | ) |  | (790.7 | ) |
| Total stockholders’ equity | 1,586.3 |  |  | 1,160.3 |  |
| Total liabilities, temporary equity, and stockholders’ equity | $ | 6,592.2 |  |  | $ | 5,948.9 |  |

[0001327567-19-000023:8k_2_02:62]
______________

[0001327567-19-000023:8k_2_02:63]
| (1) | Certain amounts have been adjusted due to the company’s adoption of the new revenue recognition standard (ASC 606) as of August 1, 2018 using the full retrospective method. |

[0001327567-19-000023:8k_2_02:64]
11
