# PANW notes — 0001327567-19-000032


## panw:ConvertibleDebtOtherDetailsTableTextBlock

[0001327567-19-000032:notes:1]
The following table presents details of the Notes (number of shares in millions):

[0001327567-19-000032:notes:2]
|  | Conversion Rate per $1,000 Principal |  | Initial Conversion Price |  | Convertible Date |  | Initial Number of Shares |
| 2019 Notes | 9.0680 |  |  | $ | 110.28 |  |  | January 1, 2019 |  | 5.2 |  |
| 2023 Notes | 3.7545 |  |  | $ | 266.35 |  |  | April 1, 2023 |  | 6.4 |  |


## panw:ManufacturingPartnerandSupplierLiabilitiesPolicyPolicyTextBlock

[0001327567-19-000032:notes:3]
Manufacturing Partner and Supplier Liabilities

[0001327567-19-000032:notes:4]
We outsource most of our manufacturing, repair, and supply chain management operations to our EMS provider and payments to it are a significant portion of our cost of product revenue. Although we could be contractually obligated to purchase manufactured products and components, we generally do not own the manufactured products and components. Product title transfers from our EMS provider to us and immediately to our channel partners upon shipment. Our EMS provider assembles our products using design specifications, quality assurance programs, and standards that we establish and it procures components and assembles our products based on our demand forecasts. These forecasts represent our estimates of future demand for our products based upon historical trends and analysis from our sales and product management functions as adjusted for overall market conditions. If the actual component usage and product demand are significantly lower than forecast, we record a liability for manufacturing purchase commitments in excess of our forecasted demand including costs for excess components or for carrying costs incurred by our manufacturing partners and component suppliers.


## panw:Scheduleof2019NotesConversionsTableTextBlock

[0001327567-19-000032:notes:5]
The following table presents details of early conversions of the 2019 Notes during the year ended July 31, 2019 (in millions):

[0001327567-19-000032:notes:6]
|  | Year Ended |
|  | July 31, 2019 |
| 2019 Notes principal early converted and repaid in cash: |  |
| Allocated to liability component(1) | $ | 403.4 |  |
| Allocated to equity component(2) | 12.2 |  |
| Total principal early converted and repaid in cash | $ | 415.6 |  |
| Loss on early conversions of convertible senior notes(3) | $ | 2.6 |  |

[0001327567-19-000032:notes:7]
______________

[0001327567-19-000032:notes:8]
| (1) | Recorded as a reduction to convertible senior notes, net in our consolidated balance sheets and calculated by measuring the fair value of a similar liability that did not have an associated convertible feature. |

[0001327567-19-000032:notes:9]
| (2) | Recorded as a reduction to additional paid-in capital in our consolidated balance sheets. |

[0001327567-19-000032:notes:10]
| (3) | Represents the difference between the cash consideration allocated to the liability component and the net carrying amount of the liability component on the respective settlement dates. The amount is included in other income, net in our consolidated statement of operations. |


## panw:ScheduleofNoteHedgeTransactionsTableTextBlock

[0001327567-19-000032:notes:11]
The following table presents details of the Note Hedges (in millions):

[0001327567-19-000032:notes:12]
|  | Initial Number of Shares |  | Aggregate Purchase |
| 2019 Note Hedges | 5.2 |  |  | $ | 111.0 |  |
| 2023 Note Hedges | 6.4 |  |  | $ | 332.0 |  |


## panw:ScheduleofSharebasedCompensationSharesAvailableforGrantTableTextBlock

[0001327567-19-000032:notes:13]
The following table presents the stock activity and the total number of shares available for grant under our stock plans as of July 31, 2019 (in millions):

[0001327567-19-000032:notes:14]
|  | Number of shares |
| Balance—July 31, 2018 | 8.8 |  |
| Authorized | 4.6 |  |
| PSOs, RSUs, and PSUs granted | (6.7 | ) |
| Options, PSOs, RSAs, PSAs, RSUs, and PSUs forfeited | 1.0 |  |
| Shares withheld for taxes | 0.1 |  |
| Balance—July 31, 2019 | 7.8 |  |


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001327567-19-000032:notes:15]
Basis of Presentation

[0001327567-19-000032:notes:16]
The accompanying consolidated financial statements have been prepared in conformity with U.S. generally accepted accounting principles (“GAAP”). The consolidated financial statements include all adjustments necessary for a fair presentation of our annual results. All adjustments are of a normal recurring nature. Certain prior period amounts have been reclassified to conform to our current period presentation. In addition, certain prior period amounts have been adjusted due to our retrospective adoption of new accounting guidance related to revenue from contracts with customers and new accounting guidance related to the presentation of restricted cash and cash equivalents in the statement of cash flows.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001327567-19-000032:notes:17]
Acquisitions

[0001327567-19-000032:notes:18]
Fiscal 2019

[0001327567-19-000032:notes:19]
Twistlock Ltd.

[0001327567-19-000032:notes:20]
On July 9, 2019, we completed our acquisition of 100% of the voting equity interest of Twistlock Ltd. (“Twistlock”), a privately-held company specializing in container security. The acquisition extends our cloud security strategy with the addition of Twistlock to our Prisma cloud security offerings. The total purchase consideration for the acquisition of Twistlock was $378.1 million, which consisted of the following (in millions):

[0001327567-19-000032:notes:21]
|  | Amount |
| Cash | $ | 375.4 |  |
| Fair value of replacement equity awards | 2.7 |  |
| Total purchase consideration | $ | 378.1 |  |

[0001327567-19-000032:notes:22]
As part of the acquisition, we issued replacement equity awards, which included 0.1 million shares of our restricted common stock. The total fair value of the replacement equity awards was $51.8 million, of which the portion attributable to services performed prior to the acquisition date was allocated to the purchase consideration. The remaining fair value was allocated to future services and will be expensed over the remaining service periods as share-based compensation.

[0001327567-19-000032:notes:23]
We have accounted for this transaction as a business combination and allocated the purchase consideration to assets acquired and liabilities assumed based on preliminary estimated fair values, as presented in the following table (in millions):

[0001327567-19-000032:notes:24]
|  | Amount |
| Goodwill | $ | 300.6 |  |
| Identified intangible assets | 54.1 |  |
| Cash and cash equivalents | 14.0 |  |
| Net assets acquired | 9.4 |  |
| Total | $ | 378.1 |  |

[0001327567-19-000032:notes:25]
Goodwill generated from this business combination is primarily attributable to the assembled workforce and expected post-acquisition synergies from integrating Twistlock’s product into our platform. The goodwill is expected to be deductible for U.S. income tax purposes.

[0001327567-19-000032:notes:26]
The following table presents details of the identified intangible assets acquired (in millions, except years):

[0001327567-19-000032:notes:27]
|  | Fair Value |  | Estimated Useful Life |
| Developed technology | $ | 51.5 |  |  | 7 years |
| Customer relationships | 2.6 |  |  | 8 years |
| Total | $ | 54.1 |  |  |  |

[0001327567-19-000032:notes:28]
PureSec Ltd.

[0001327567-19-000032:notes:29]
On June 12, 2019, we completed our acquisition of 100% of the voting equity interest of PureSec Ltd. (“PureSec”), a privately-held company specializing in cybersecurity solutions for serverless architectures. The acquisition extends our cloud security strategy with the addition of PureSec to our Prisma cloud security offerings. The total purchase consideration for the acquisition of PureSec was $36.8 million, which consisted of the following (in millions):

[0001327567-19-000032:notes:30]
|  | Amount |
| Cash | $ | 35.9 |  |
| Fair value of replacement equity awards | 0.9 |  |
| Total purchase consideration | $ | 36.8 |  |

[0001327567-19-000032:notes:31]
As part of the acquisition, we issued replacement equity awards. The total fair value of the replacement equity awards was $9.1 million, of which the portion attributable to services performed prior to the acquisition date was allocated to the purchase consideration. The remaining fair value was allocated to future services and will be expensed over the remaining service periods as share-based compensation.

[0001327567-19-000032:notes:32]
|  | Amount |
| Goodwill | $ | 24.4 |  |
| Identified intangible assets | 7.4 |  |
| Cash | 4.0 |  |
| Net assets acquired | 1.0 |  |
| Total | $ | 36.8 |  |

[0001327567-19-000032:notes:33]
Goodwill generated from this business combination is primarily attributable to the assembled workforce and expected post-acquisition synergies from integrating PureSec’s product into our platform. The goodwill is expected to be deductible for U.S. income tax purposes.

[0001327567-19-000032:notes:34]
|  | Fair Value |  | Estimated Useful Life |
| Developed technology | $ | 7.4 |  |  | 5 years |
| Total | $ | 7.4 |  |  |  |

[0001327567-19-000032:notes:35]
Demisto, Inc.

[0001327567-19-000032:notes:36]
On March 28, 2019, we completed our acquisition of 100% of the voting equity interest of Demisto, Inc. (“Demisto”), a privately-held security company specializing in security orchestration, automation and response (“SOAR”). The acquisition expands the functionality of our platform with the addition of Demisto’s SOAR product. The total purchase consideration for the acquisition of Demisto was $474.2 million, which consisted of the following (in millions):

[0001327567-19-000032:notes:37]
|  | Amount |
| Cash | $ | 250.0 |  |
| Common stock (0.9 million shares) | 214.7 |  |
| Fair value of replacement equity awards | 9.5 |  |
| Total purchase consideration | $ | 474.2 |  |

[0001327567-19-000032:notes:38]
As part of the acquisition, we issued replacement equity awards, which included 0.3 million shares of our restricted common stock. The total fair value of the replacement equity awards was $105.2 million, of which the portion attributable to services performed prior to the acquisition date was allocated to the purchase consideration. The remaining fair value was allocated to future services and will be expensed over the remaining service periods as share-based compensation.

[0001327567-19-000032:notes:39]
|  | Amount |
| Goodwill | $ | 387.8 |  |
| Identified intangible assets | 76.3 |  |
| Cash | 25.9 |  |
| Net liabilities assumed | (15.8 | ) |
| Total | $ | 474.2 |  |

[0001327567-19-000032:notes:40]
Goodwill generated from this business combination is primarily attributable to the assembled workforce and expected post-acquisition synergies from integrating Demisto’s product into our platform. The goodwill is not deductible for income tax purposes.

[0001327567-19-000032:notes:41]
|  | Fair Value |  | Estimated Useful Life |
| Developed technology | $ | 56.6 |  |  | 6 years |
| Customer relationships | 19.7 |  |  | 6 years |
| Total | $ | 76.3 |  |  |  |

[0001327567-19-000032:notes:42]
RedLock Inc.

[0001327567-19-000032:notes:43]
On October 12, 2018, we completed our acquisition of 100% of the voting equity interest of RedLock Inc. (“RedLock”), a privately-held cloud security company. The acquisition expands our security capabilities for the public cloud with the addition of RedLock’s cloud security analytics technology. The total purchase consideration for the acquisition of RedLock was $158.2 million, which consisted of $155.0 million in cash paid upon closing and $3.2 million in fair value of unvested equity awards attributable to services performed prior to the acquisition date.

[0001327567-19-000032:notes:44]
As part of the acquisition, we assumed RedLock equity awards with a total fair value of $57.4 million. Of the total fair value, a portion was allocated to the purchase consideration and the remainder was allocated to future services and will be expensed over the remaining service periods as share-based compensation.

[0001327567-19-000032:notes:45]
|  | Amount |
| Goodwill | $ | 113.6 |  |
| Identified intangible assets | 54.8 |  |
| Net liabilities assumed | (10.2 | ) |
| Total | $ | 158.2 |  |

[0001327567-19-000032:notes:46]
Goodwill generated from this business combination is primarily attributable to the assembled workforce and expected post-acquisition synergies from integrating RedLock’s technology into our platform. The goodwill is not deductible for income tax purposes.

[0001327567-19-000032:notes:47]
|  | Fair Value |  | Estimated Useful Life |
| Developed technology | $ | 48.6 |  |  | 4 years |
| Customer relationships | 5.3 |  |  | 8 years |
| Trade name and trademarks | 0.9 |  |  | 6 months |
| Total | $ | 54.8 |  |  |  |

[0001327567-19-000032:notes:48]
Fiscal 2018

[0001327567-19-000032:notes:49]
Evident.io, Inc.

[0001327567-19-000032:notes:50]
On March 26, 2018, we completed our acquisition of all outstanding shares of Evident.io, Inc. (“Evident.io”), a privately-held cloud security company. The acquisition expanded our API-based security capabilities for the public cloud with the addition of Evident.io’s cloud services infrastructure protection technology. The total purchase consideration for the acquisition of Evident.io was $292.9 million in cash, of which $4.0 million was accrued and was paid over a period of five months from the acquisition date.

[0001327567-19-000032:notes:51]
We have accounted for this transaction as a business combination and allocated the purchase consideration to assets acquired and liabilities assumed based on their estimated fair values, as presented in the following table (in millions):

[0001327567-19-000032:notes:52]
|  | Amount |
| Goodwill | $ | 209.8 |  |
| Identified intangible assets | 85.1 |  |
| Net liabilities assumed | (2.0 | ) |
| Total | $ | 292.9 |  |

[0001327567-19-000032:notes:53]
Goodwill generated from this business combination is primarily attributable to the assembled workforce and expected post-acquisition synergies from integrating Evident.io’s technology into our platform and sales opportunities of Evident.io’s software as a service (“SaaS”) offerings. The goodwill is not deductible for income tax purposes.

[0001327567-19-000032:notes:54]
|  | Fair Value |  | Estimated Useful Life |
| Developed technology | $ | 68.4 |  |  | 4.5 years |
| Trade name and trademarks | 8.5 |  |  | 1 year |
| Customer relationships | 8.2 |  |  | 8 years |
| Total | $ | 85.1 |  |  |  |

[0001327567-19-000032:notes:55]
Cyber Secdo Ltd.

[0001327567-19-000032:notes:56]
On April 24, 2018, we completed our acquisition of all outstanding shares of Cyber Secdo Ltd. (“Secdo”), a privately-held company specializing in endpoint detection and response (“EDR”). The acquisition expands the functionality of our platform by adding EDR capabilities. The total purchase consideration for the acquisition of Secdo was $82.7 million in cash.

[0001327567-19-000032:notes:57]
|  | Amount |
| Goodwill | $ | 68.6 |  |
| Identified intangible assets | 17.3 |  |
| Net liabilities assumed | (3.2 | ) |
| Total | $ | 82.7 |  |

[0001327567-19-000032:notes:58]
Goodwill generated from this business combination is primarily attributable to the assembled workforce and expected post-acquisition synergies from integrating Secdo’s technology into our advanced endpoint protection offering and our platform. The goodwill is not deductible for income tax purposes.

[0001327567-19-000032:notes:59]
|  | Fair Value |  | Estimated Useful Life |
| Developed technology | $ | 16.4 |  |  | 5 years |
| Customer relationships | 0.9 |  |  | 2 years |
| Total | $ | 17.3 |  |  |  |

[0001327567-19-000032:notes:60]
Fiscal 2017

[0001327567-19-000032:notes:61]
LightCyber Ltd.

[0001327567-19-000032:notes:62]
On February 27, 2017, we completed our acquisition of all outstanding shares of LightCyber Ltd. (“LightCyber”), a privately-held cybersecurity company. The acquisition expands the functionality of our platform with the addition of LightCyber’s behavioral analytics technology. The total purchase consideration for the acquisition of LightCyber was $103.1 million in cash.

[0001327567-19-000032:notes:63]
|  | Amount |
| Cash | $ | 12.4 |  |
| Goodwill | 75.3 |  |
| Identified intangible assets | 19.5 |  |
| Net liabilities assumed | (4.1 | ) |
| Total | $ | 103.1 |  |

[0001327567-19-000032:notes:64]
|  | Fair Value |  | Estimated Useful Life |
| Developed technology | $ | 16.6 |  |  | 8 years |
| Customer relationships | 2.9 |  |  | 8 years |
| Total | $ | 19.5 |  |  |  |

[0001327567-19-000032:notes:65]
Goodwill generated from this business combination is primarily attributable to the assembled workforce and expected synergies from integrating the LightCyber technology into our platform. The goodwill is not deductible for income tax purposes.

[0001327567-19-000032:notes:66]
Additional Acquisition-Related Information

[0001327567-19-000032:notes:67]
The operating results of the acquired companies are included in our consolidated statements of operations from the respective dates of acquisition. Pro forma results of operations have not been presented because the effects of the acquisitions were not material to our consolidated statements of operations.

[0001327567-19-000032:notes:68]
Additional information related to our acquisitions completed in fiscal 2019, such as that related to income tax and other contingencies, existing as of the acquisition date but unknown to us may become known during the remainder of the measurement period, not to exceed 12 months from the respective acquisition date, which may result in changes to the amounts and allocations recorded.

[0001327567-19-000032:notes:69]
As a result of the Tax Cuts and Jobs Act (“TCJA”), a portion of the goodwill from prior year acquisitions may be deductible in future periods.


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock

[0001327567-19-000032:notes:70]
Description of Business and Summary of Significant Accounting Policies

[0001327567-19-000032:notes:71]
Description of Business

[0001327567-19-000032:notes:72]
Palo Alto Networks, Inc. (the “Company,” “we,” “us,” or “our”), located in Santa Clara, California, was incorporated in March 2005 under the laws of the State of Delaware and commenced operations in April 2005. We offer a platform that empowers enterprises, service providers, and government entities to secure their organizations by safely enabling applications and data running in their networks, on their endpoints, and in the cloud, and by preventing breaches that stem from targeted cyberattacks.

[0001327567-19-000032:notes:73]
The accompanying consolidated financial statements have been prepared in conformity with U.S. generally accepted accounting principles (“GAAP”). The consolidated financial statements include all adjustments necessary for a fair presentation of our annual results. All adjustments are of a normal recurring nature. Certain prior period amounts have been reclassified to conform to our current period presentation. In addition, certain prior period amounts have been adjusted due to our retrospective adoption of new accounting guidance related to revenue from contracts with customers and new accounting guidance related to the presentation of restricted cash and cash equivalents in the statement of cash flows. Refer to “Recently Adopted Accounting Pronouncements” below for more information.

[0001327567-19-000032:notes:74]
Principles of Consolidation

[0001327567-19-000032:notes:75]
The consolidated financial statements include our accounts and our wholly owned subsidiaries. All significant intercompany balances and transactions have been eliminated in consolidation.

[0001327567-19-000032:notes:76]
Use of Estimates

[0001327567-19-000032:notes:77]
The preparation of consolidated financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the consolidated financial statements and the reported amounts of revenues and expenses during the reporting period. Such management estimates include, but are not limited to the standalone selling price for our products and services, share-based compensation, fair value of assets acquired and liabilities assumed in business combinations, the assessment of recoverability of our property and equipment, identified intangibles and goodwill, future taxable income, manufacturing partner and supplier liabilities, fair value of debt component of convertible notes, cease-use loss related to facility exit, deferred contract cost benefit period, and loss contingencies. We base our estimates on historical experience and also on assumptions that we believe are reasonable. Actual results could differ materially from those estimates.

[0001327567-19-000032:notes:78]
Concentrations

[0001327567-19-000032:notes:79]
Financial instruments that subject us to concentrations of credit risk consist primarily of cash and cash equivalents, investments, accounts receivable, and derivative contracts.

[0001327567-19-000032:notes:80]
We invest only in high-quality credit instruments and maintain our cash and cash equivalents and available-for-sale investments in fixed income securities. Management believes that the financial institutions that hold our investments are financially sound and, accordingly, are subject to minimal credit risk. Deposits held with banks may exceed the amount of insurance provided on such deposits.

[0001327567-19-000032:notes:81]
Our derivative contracts expose us to credit risk to the extent that the counterparties may be unable to meet the terms of the arrangement. We mitigate this credit risk by transacting with major financial institutions with high credit ratings and also enter into master netting arrangements, which permit net settlement of transactions with the same counterparty. We are not required to pledge, and are not entitled to receive, cash collateral related to these derivative instruments. We do not enter into derivative contracts for trading or speculative purposes.

[0001327567-19-000032:notes:82]
Our accounts receivables are primarily derived from our distributors representing various geographical locations. We perform ongoing credit evaluations and generally do not require collateral on accounts receivable. We maintain an allowance for doubtful accounts for estimated potential credit losses. As of July 31, 2019, three distributors represented 29.9%, 18.9%, and 14.2% of our gross accounts receivable. For fiscal 2019, four distributors represented 31.8%, 22.1%, 10.7%, and 10.0% of our total revenue.

[0001327567-19-000032:notes:83]
We rely on an electronics manufacturing services provider (“EMS provider”) to assemble most of our products and sole source component suppliers for a certain number of our components.

[0001327567-19-000032:notes:84]
Comprehensive Loss

[0001327567-19-000032:notes:85]
Comprehensive loss is comprised of net loss and other comprehensive income (loss). Our other comprehensive income (loss) includes unrealized gains and losses on available-for-sale investments and unrealized gains and losses on cash flow hedges.

[0001327567-19-000032:notes:86]
Foreign Currency Transactions

[0001327567-19-000032:notes:87]
The functional currency of our foreign subsidiaries is the U.S. dollar. Monetary assets and liabilities denominated in foreign currencies have been remeasured into U.S. dollars using the exchange rates in effect at the balance sheet dates. Foreign currency denominated income and expenses have been remeasured using the average exchange rates in effect during each period. Foreign currency remeasurement gains and losses and foreign currency transaction gains and losses are not significant to the financial statements.

[0001327567-19-000032:notes:88]
Fair Value

[0001327567-19-000032:notes:89]
We define fair value as the price that would be received from selling an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date. When determining the fair value measurements for assets and liabilities which are required to be recorded at fair value, we consider the principal or most advantageous market in which to transact and the market-based risk. We apply fair value accounting for all financial assets and liabilities that are recognized or disclosed at fair value in the financial statements on a recurring basis. Goodwill, intangible assets, and other long-lived assets are measured at fair value on a nonrecurring basis, only if impairment is indicated. The carrying amounts reported in the consolidated financial statements approximate the fair value for cash and cash equivalents, accounts receivable, accounts payable, and accrued liabilities, due to their short-term nature.

[0001327567-19-000032:notes:90]
Cash, Cash Equivalents, and Investments

[0001327567-19-000032:notes:91]
We consider all highly liquid investments with original maturities of three months or less at date of purchase to be cash equivalents. Investments not considered cash equivalents and with maturities one year or less from the consolidated balance sheet date are classified as short-term investments. Investments with maturities greater than one year from the consolidated balance sheet date are classified as long-term investments.

[0001327567-19-000032:notes:92]
We classify our investments in marketable debt securities as available-for-sale at the time of purchase since it is our intent that these investments are available for current operations, and include these investments on our consolidated balance sheets as cash equivalents, short-term investments, or long-term investments depending on their maturity. These investments are considered impaired when a decline in fair value is judged to be other-than-temporary. We consult with our investment managers and consider available quantitative and qualitative evidence in evaluating potential impairment of our investments on a quarterly basis. If the cost of an individual investment exceeds its fair value, we evaluate, among other factors, general market conditions, the duration and extent to which the fair value is less than cost, and our intent and ability to hold the investment. Once a decline in fair value is determined to be other-than-temporary, an impairment charge is recorded and a new cost basis in the investment is established.

[0001327567-19-000032:notes:93]
Accounts Receivable

[0001327567-19-000032:notes:94]
Trade accounts receivable are recorded at the invoiced amount, net of allowances for doubtful accounts. The allowance for doubtful accounts is based on our assessment of the collectability of accounts. Management regularly reviews the adequacy of the allowance for doubtful accounts by considering the age of each outstanding invoice, each channel partner’s expected ability to pay, and the collection history with each channel partner, when applicable, to determine whether a specific allowance is appropriate. Accounts receivable deemed uncollectible are charged against the allowance for doubtful accounts when identified. As of July 31, 2019 and 2018, the allowance for doubtful accounts activity was not significant.

[0001327567-19-000032:notes:95]
Derivatives

[0001327567-19-000032:notes:96]
Our derivative financial instruments are recorded at fair value, on a gross basis, as either assets or liabilities in our consolidated balance sheets. Gains or losses related to our cash flow hedges are recorded as a component of accumulated other comprehensive income (loss) (“AOCI”) in our consolidated balance sheets and are reclassified into the financial statement line item associated with the underlying hedged transaction in our consolidated statements of operations when the underlying hedged transaction is recognized in earnings. If it becomes probable that the hedged transaction will not occur, the cumulative unrealized gain or loss is reclassified immediately from AOCI into the financial statement line item associated with the underlying hedged transaction in our consolidated statements of operations. Gains or losses related to non-designated derivative instruments are recognized in other income (expense), net in our consolidated statements of operations for each period until the instrument matures, is terminated, is re-designated as a qualified cash flow hedge, or is sold. Derivatives designated as cash flow hedges are classified in our consolidated statements of cash flows in the same manner as the underlying hedged transaction, primarily within cash flows from operating activities.

[0001327567-19-000032:notes:97]
Property and Equipment

[0001327567-19-000032:notes:98]
Property and equipment are stated at cost, less accumulated depreciation. Depreciation is computed using the straight-line method over the estimated useful lives of the assets, generally three to ten years. Leasehold improvements are depreciated over the shorter of the estimated useful lives of the improvements or the remaining lease term.

[0001327567-19-000032:notes:99]
Business Combinations

[0001327567-19-000032:notes:100]
We include the results of operations of the businesses that we acquire as of the respective dates of acquisition. We allocate the fair value of the purchase price of our acquisitions to the tangible assets acquired, liabilities assumed, and intangible assets acquired, based on their estimated fair values. The excess of the purchase price over the fair values of these identifiable assets and liabilities is recorded as goodwill. Additional information existing as of the acquisition date but unknown to us may become known during the remainder of the measurement period, not to exceed 12 months from the acquisition date, which may result in changes to the amounts and allocations recorded.

[0001327567-19-000032:notes:101]
Intangible Assets

[0001327567-19-000032:notes:102]
Purchased intangible assets with finite lives are carried at cost, less accumulated amortization. Amortization is computed over the estimated useful lives of the respective assets. Acquisition-related in-process research and development represents the fair value of incomplete research and development projects that have not reached technological feasibility as of the date of acquisition. Initially, these assets are not subject to amortization. Assets related to projects that have been completed are transferred to developed technology, which are subject to amortization.

[0001327567-19-000032:notes:103]
Impairment of Goodwill, Intangible Assets, and Other Long-Lived Assets

[0001327567-19-000032:notes:104]
Goodwill is evaluated for impairment on an annual basis in the fourth quarter of our fiscal year, and whenever events or changes in circumstances indicate the carrying amount of goodwill may not be recoverable. We have elected to first assess qualitative factors to determine whether it is more likely than not that the fair value of our single reporting unit is less than its carrying amount, including goodwill. If we determine that it is more likely than not that the fair value of our single reporting unit is less than its carrying amount, then the quantitative impairment test will be performed. Under the quantitative impairment test, if the carrying amount of our single reporting unit exceeds its fair value, we will recognize an impairment loss in an amount equal to that excess, but limited to the total amount of goodwill.

[0001327567-19-000032:notes:105]
We evaluate events and changes in circumstances that could indicate carrying amounts of purchased intangible assets and other long-lived assets may not be recoverable. When such events or changes in circumstances occur, we assess the recoverability of these assets by determining whether or not the carrying amount will be recovered through undiscounted expected future cash flows. If the total of the future undiscounted cash flows is less than the carrying amount of an asset, we record an impairment loss for the amount by which the carrying amount of the asset exceeds the fair value of the asset.

[0001327567-19-000032:notes:106]
Through July 31, 2019, we have not recognized any impairment losses on our goodwill and intangible assets. During the year ended July 31, 2017, we recognized an impairment loss of $20.9 million on property and equipment related to the relocation of our corporate headquarters. We did not recognize any impairment losses on our other long-lived assets during the years ended July 31, 2019 and 2018, or prior to fiscal 2017.

[0001327567-19-000032:notes:107]
We outsource most of our manufacturing, repair, and supply chain management operations to our EMS provider and payments to it are a significant portion of our cost of product revenue. Although we could be contractually obligated to purchase manufactured products and components, we generally do not own the manufactured products and components. Product title transfers from our EMS provider to us and immediately to our channel partners upon shipment. Our EMS provider assembles our products using design specifications, quality assurance programs, and standards that we establish and it procures components and assembles our products based on our demand forecasts. These forecasts represent our estimates of future demand for our products based upon historical trends and analysis from our sales and product management functions as adjusted for overall market conditions. If the actual component usage and product demand are significantly lower than forecast, we record a liability for manufacturing purchase commitments in excess of our forecasted demand including costs for excess components or for carrying costs incurred by our manufacturing partners and component suppliers. Through July 31, 2019, we have not accrued any significant costs associated with this exposure.

[0001327567-19-000032:notes:108]
Convertible Senior Notes

[0001327567-19-000032:notes:109]
In accounting for the issuance of our convertible senior notes, we separate the notes into liability and equity components. The carrying amount of the liability component is calculated by measuring the fair value of a similar liability that does not have an associated convertible feature. The carrying amount of the equity component representing the conversion option is determined by deducting the fair value of the liability component from the par value of the notes as a whole. This difference represents a debt discount that is amortized to interest expense using the effective interest method over the term of the notes. The equity component is not remeasured as long as it continues to meet the conditions for equity classification. In accounting for the transaction costs related to the issuance of the notes, we allocate the total amount incurred to the liability and equity components using the same proportions as the proceeds from the notes. Transaction costs attributable to the liability component are netted with the liability component and amortized to interest expense using the effective interest method over the term of the notes. Transaction costs attributable to the equity component are netted with the equity component of the notes in additional paid-in capital in the consolidated balance sheets. When the notes are convertible, the net carrying amount of the notes is classified as a current liability and a portion of the equity component representing the conversion option is reclassified to temporary equity in our consolidated balance sheets. The portion of the equity component classified as temporary equity is measured as the difference between the principal and net carrying amount of the notes, excluding debt issuance costs.

[0001327567-19-000032:notes:110]
Revenue Recognition

[0001327567-19-000032:notes:111]
Our revenue consists of product revenue and subscription and support revenue. Revenue is recognized when control of promised products, subscriptions and support services are transferred to customers with the expected consideration in exchange for those products and services. Depending on who the contract is with, our customers are either our channel partners or our end-customers.

[0001327567-19-000032:notes:112]
We determine revenue recognition through the following steps:

[0001327567-19-000032:notes:113]
| • | Identification of the contract, or contracts, with a customer. |

[0001327567-19-000032:notes:114]
| • | Identification of the performance obligations in the contract. |

[0001327567-19-000032:notes:115]
| • | Determination of the transaction price. |

[0001327567-19-000032:notes:116]
| • | Allocation of the transaction price to the performance obligations in the contract. |

[0001327567-19-000032:notes:117]
| • | Recognition of revenue when, or as, we satisfy a performance obligation. |

[0001327567-19-000032:notes:118]
Revenues are reported net of sales taxes. Shipping charges billed to channel partners are included in revenues and related costs are included in cost of revenue.

[0001327567-19-000032:notes:119]
Product Revenue

[0001327567-19-000032:notes:120]
Product revenue is derived primarily from sales of our appliances. Product revenue also includes revenue derived from software licenses of Panorama and the VM-Series. Our appliances and software licenses include a broad set of built-in networking and security features and functionalities. We recognize product revenue at the time of hardware shipment or delivery of software license.

[0001327567-19-000032:notes:121]
Subscription and Support Revenue

[0001327567-19-000032:notes:122]
Subscription and support revenue is derived primarily from sales of our subscription and support offerings. We recognize subscription and support revenue over time as the services are performed. Our contractual subscription and support contracts are typically one to five years.

[0001327567-19-000032:notes:123]
Contracts with Multiple Performance Obligations

[0001327567-19-000032:notes:124]
The majority of our contracts with our customers include various combinations of our products and subscriptions and support. Our appliances and software licenses have significant standalone functionalities and capabilities. Accordingly, these appliances and software licenses are distinct from our subscriptions and support services as the customer can benefit from the product without these services and such services are separately identifiable within the contract. We account for multiple agreements with a single customer as a single contract if the contractual terms and/or substance of those agreements indicate that they may be so closely related that they are, in effect, parts of a single contract. The amount of consideration we expect to receive in exchange for delivering on the contract is allocated to each performance obligation based on its relative standalone selling price. If a contract contains a single performance obligation, no allocation is required.

[0001327567-19-000032:notes:125]
We establish standalone selling price using the prices charged for a deliverable when sold separately. If the standalone selling price is not observable through past transactions, we estimate the standalone selling price based on our pricing model and our go-to-market strategy, which include factors such as type of sales channel (reseller, distributor, or end-customer), the geographies in which our offerings were sold (domestic or international), and offering type (products, subscriptions, or support).

[0001327567-19-000032:notes:126]
Deferred Revenue

[0001327567-19-000032:notes:127]
We record deferred revenue when cash payments are received or due in advance of our performance. Our payment terms typically require payment within 30 to 45 days of the date we issue an invoice. The current portion of deferred revenue represents the amounts that are expected to be recognized as revenue within one year of the consolidated balance sheet date.

[0001327567-19-000032:notes:128]
Deferred Contract Costs

[0001327567-19-000032:notes:129]
We defer contract costs that are recoverable and incremental to obtaining customer sales contracts. Contract costs, which primarily consist of sales commissions, are amortized on a systematic basis that is consistent with the transfer to the customer of the goods or services to which the asset relates. Sales commissions paid for initial contracts are generally not commensurate with the commissions paid for renewal contracts, given the substantive difference in commission rates in proportion to their respective contract values. Sales commissions for initial contracts that are not commensurate are amortized over a benefit period of five years, consistent with the revenue recognition pattern of the performance obligations in the related contracts including expected renewals. The benefit period is determined by taking into consideration contract length, technology life, and other quantitative and qualitative factors. The expected renewals are estimated based on historical renewal trends. Sales commissions for initial contracts that are commensurate and sales commissions for renewal contracts are amortized over the related contractual period in proportion to the revenue recognized.

[0001327567-19-000032:notes:130]
We classify deferred contract costs as short-term or long-term based on when we expect to recognize the expense. Short-term deferred contract costs are included in prepaid expenses and other current assets and long-term deferred contract costs are included in other assets in our consolidated balance sheets. Deferred contract costs are periodically reviewed for impairment. The amortization of deferred contract costs is included in sales and marketing expense in our consolidated statements of operations.

[0001327567-19-000032:notes:131]
Software Development Costs

[0001327567-19-000032:notes:132]
Internally developed software includes security software developed to meet our internal needs to provide cloud-based subscription offerings to our end-customers and business software that we customize to meet our specific operational needs. These capitalized costs consist of internal compensation related costs and external direct costs incurred during the application development stage and will be amortized over a useful life of three to five years. As of July 31, 2019 and 2018, we capitalized as other assets on our consolidated balance sheets $44.9 million and $23.0 million in costs, respectively, net of accumulated amortization, for security software developed to meet our internal needs to provide our cloud-based subscription offerings. We recognized amortization expense of $12.9 million, $4.3 million, and $1.2 million related to these capitalized costs as cost of subscription and support revenue in our consolidated statements of operations during the years ended July 31, 2019, 2018, and 2017, respectively.

[0001327567-19-000032:notes:133]
The costs to develop software that is marketed externally have not been capitalized as we believe our current software development process is essentially completed concurrent with the establishment of technological feasibility. As such, all related software development costs are expensed as incurred and included in research and development expense in our consolidated statements of operations.

[0001327567-19-000032:notes:134]
Share-Based Compensation

[0001327567-19-000032:notes:135]
Compensation expense related to share-based transactions, including employee and non-employee director awards, is measured and recognized in the financial statements based on fair value on the grant date. We recognize share-based compensation expense for awards with only service conditions on a straight-line basis over the requisite service period of the related award. We recognize share-based compensation expense for awards with market conditions and awards with performance conditions on a straight-line basis over the requisite service period for each separately vesting portion of the award and, for awards with performance conditions, when it is probable that the performance condition will be achieved. We account for forfeitures of all share-based payment awards when they occur.

[0001327567-19-000032:notes:136]
Leases

[0001327567-19-000032:notes:137]
We rent our facilities under operating lease agreements and recognize related rent expense on a straight-line basis over the term of the lease. Some of our lease agreements contain rent holidays, scheduled rent increases, lease incentives, and renewal options. Rent holidays and scheduled rent increases are included in the determination of rent expense to be recorded over the lease term. Lease incentives are recognized as a reduction of rent expense on a straight-line basis over the term of the lease. Renewals are not assumed in the determination of the lease term unless they are deemed to be reasonably assured at the inception of the lease. We begin recognizing rent expense on the date that we obtain the legal right to use and control the leased space.

[0001327567-19-000032:notes:138]
Upon exiting a leased property before the lease term expires, we assess the fair value of our remaining obligation under the lease and record a cease-use loss, if needed. The cease-use loss is calculated as the present value of the amount by which the remaining lease obligation, adjusted for the effects of any deferred items recognized under the lease and related costs, exceeds the estimated sublease rentals that could be reasonably obtained. The cease-use loss will be adjusted as a result of the remeasurement of the cease-use liability if the timing or amount of estimated cash flows change.

[0001327567-19-000032:notes:139]
Income Taxes

[0001327567-19-000032:notes:140]
We account for income taxes using the asset and liability method, which requires the recognition of deferred tax assets and liabilities for the expected future tax consequences of events that have been recognized in our financial statements or tax returns. In addition, deferred tax assets are recorded for the future benefit of utilizing net operating losses and research and development credit carryforwards. Valuation allowances are provided when necessary to reduce deferred tax assets to the amount expected to be realized.

[0001327567-19-000032:notes:141]
Significant judgment is required in determining any valuation allowance recorded against deferred tax assets. In assessing the need for a valuation allowance, we consider all available evidence, including past operating results, estimates of future taxable income, and the feasibility of tax planning strategies. In the event that we change our determination as to the amount of deferred tax assets that can be realized, we will adjust our valuation allowance with a corresponding impact to the provision for income taxes in the period in which such determination is made.

[0001327567-19-000032:notes:142]
We apply the authoritative accounting guidance prescribing a threshold and measurement attribute for the financial recognition and measurement of a tax position taken or expected to be taken in a tax return. We recognize liabilities for uncertain tax positions based on a two-step process. The first step is to evaluate the tax position for recognition by determining if the weight of available evidence indicates that it is more likely than not that the position will be sustained on audit, including resolution of related appeals or litigation processes, if any. The second step requires us to estimate and measure the tax benefit as the largest amount that is more likely than not to be realized upon ultimate settlement.

[0001327567-19-000032:notes:143]
Loss Contingencies

[0001327567-19-000032:notes:144]
We are subject to the possibility of various loss contingencies arising in the ordinary course of business. In determining loss contingencies, we consider the likelihood of loss or impairment of an asset, or the incurrence of a liability, as well as our ability to reasonably estimate the amount of loss. An estimated loss contingency is accrued when it is probable that an asset has been impaired or a liability has been incurred and the amount of loss can be reasonably estimated. If we determine that a loss is possible and the range of the loss can be reasonably determined, then we disclose the range of the possible loss. We regularly evaluate current information available to us to determine whether an accrual is required, an accrual should be adjusted or a range of possible loss should be disclosed.

[0001327567-19-000032:notes:145]
Recently Adopted Accounting Pronouncements

[0001327567-19-000032:notes:146]
Implementation Costs Incurred in a Cloud Computing Arrangement

[0001327567-19-000032:notes:147]
In August 2018, the Financial Accounting Standards Board (“FASB”) issued authoritative guidance on customers’ accounting for implementation costs incurred in a cloud computing arrangement that is a service contract, which requires customers to apply internal-use software guidance to determine the implementation costs that are able to be capitalized. Under the new standard, capitalized implementation costs are generally amortized over the term of the arrangement, beginning when the module or component of the hosting arrangement is ready for its intended use. We early adopted this standard in our second quarter of fiscal 2019 on a prospective basis. The adoption of the standard did not have a material impact on our consolidated financial statements.

[0001327567-19-000032:notes:148]
Business Combinations - Definition of a Business

[0001327567-19-000032:notes:149]
In January 2017, the FASB issued authoritative guidance clarifying the definition of a business to assist companies with evaluating whether transactions should be accounted for as acquisitions (or disposals) of assets or businesses. We adopted this standard in our first quarter of fiscal 2019 on a prospective basis. The adoption of the standard did not have an impact on our consolidated financial statements.

[0001327567-19-000032:notes:150]
Statement of Cash Flows - Restricted Cash

[0001327567-19-000032:notes:151]
In November 2016, the FASB issued authoritative guidance on the presentation of restricted cash or restricted cash equivalents in the statement of cash flows. Under the new standard, restricted cash or restricted cash equivalents should be included with cash and cash equivalents when reconciling the beginning-of-period and end-of-period total amounts shown on the statement of cash flows. We adopted this standard in our first quarter of fiscal 2019 on a retrospective basis. The adoption of the standard did not have a material impact on our consolidated financial statements because our restricted cash balance has not been material.

[0001327567-19-000032:notes:152]
Income Taxes - Intra-Entity Asset Transfers

[0001327567-19-000032:notes:153]
In October 2016, the FASB issued authoritative guidance requiring the recognition of income tax consequences of an intra-entity transfer of an asset, other than inventory, when the transfer occurs. We adopted the standard in our first quarter of fiscal 2019 on a modified retrospective basis. As a result, we recorded the cumulative effect of the change as an increase to accumulated deficit of $28.3 million, with a corresponding decrease to prepaid expenses and other current assets and other assets in our consolidated balance sheets as of August 1, 2018, the date of adoption. The cumulative effect adjustment represents the reclassification of unrecognized income tax effects from intra-entity transfers of assets other than inventory that occurred prior to the date of adoption.

[0001327567-19-000032:notes:154]
Statement of Cash Flows - Classification of Certain Cash Receipts and Cash Payments

[0001327567-19-000032:notes:155]
In August 2016, the FASB issued new authoritative guidance addressing eight specific cash flow issues with the objective of reducing the existing diversity in practice in how certain transactions are presented and classified in the statement of cash flows. We adopted this standard in our first quarter of fiscal 2019 on a retrospective basis. The adoption of the standard did not have an impact on our consolidated financial statements.

[0001327567-19-000032:notes:156]
Financial Instruments - Recognition and Measurement

[0001327567-19-000032:notes:157]
In January 2016, the FASB issued authoritative guidance requiring equity instruments to be measured at fair value with changes in fair value recognized through net income. We adopted this standard in our first quarter of fiscal 2019 on a prospective basis for non-marketable equity securities and a modified retrospective basis for marketable equity investments. The adoption of the standard did not have an impact on our consolidated financial statements.

[0001327567-19-000032:notes:158]
In May 2014, the FASB issued new authoritative guidance on revenue from contracts with customers. The new standard provides principles for recognizing revenue when control of promised goods or services is transferred to customers with the expected consideration in exchange for those goods or services, as well as guidance on the recognition of costs related to obtaining and fulfilling customer contracts. The standard also requires expanded disclosures about the nature, amount, timing, and uncertainty of revenues and cash flows arising from customer contracts, including significant judgments and changes in judgments, and assets recognized from costs incurred to obtain or fulfill a contract. We adopted the standard in our first quarter of fiscal 2019 using the full retrospective method.

[0001327567-19-000032:notes:159]
The adoption of the new standard did not have a material impact on our consolidated financial statements for the fiscal years ended July 31, 2018 and 2017, with the exception of the accounting for incremental costs to obtain customer contracts, which primarily consist of sales commissions, due to the longer period of amortization. Under the previous accounting guidance, we deferred and amortized these costs over the term of the related contract. Under the new standard, we defer and amortize these costs for initial contracts that are not commensurate with renewal commissions over a benefit period of five years, which is typically longer than the initial contract term.

[0001327567-19-000032:notes:160]
The adoption of the standard using the full retrospective method required us to restate the prior periods presented in this Annual Report on Form 10-K, with the cumulative effect of the change of $154.6 million reflected in accumulated deficit as of July 31, 2016. In adopting the new standard, we have also applied a transition practical expedient and have not disclosed revenue expected to be recognized from remaining performance obligations for periods prior to August 1, 2018.

[0001327567-19-000032:notes:161]
The following tables present the impact of the adoption of the standard on our previously reported results (in millions, except per share data):

[0001327567-19-000032:notes:162]
|  | Year Ended July 31, 2018 |  | Year Ended July 31, 2017 |
|  | As Previously Reported |  | Impact of Adoption |  | As Adjusted |  | As Previously Reported |  | Impact of Adoption |  | As Adjusted |
| Consolidated Statements of Operations |  |  |  |  |  |  |  |  |  |  |  |
| Product revenue | $ | 871.5 |  |  | $ | 8.3 |  |  | $ | 879.8 |  |  | $ | 709.1 |  |  | $ | (0.6 | ) |  | $ | 708.5 |  |
| Subscription and support revenue | 1,401.6 |  |  | (7.8 | ) |  | 1,393.8 |  |  | 1,052.5 |  |  | (5.9 | ) |  | 1,046.6 |  |
| Total revenue | 2,273.1 |  |  | 0.5 |  |  | 2,273.6 |  |  | 1,761.6 |  |  | (6.5 | ) |  | 1,755.1 |  |
| Total cost of revenue | 645.3 |  |  | (0.2 | ) |  | 645.1 |  |  | 476.6 |  |  | (0.2 | ) |  | 476.4 |  |
| Total operating expenses | 1,756.9 |  |  | (24.2 | ) |  | 1,732.7 |  |  | 1,464.8 |  |  | (20.3 | ) |  | 1,444.5 |  |
| Operating loss | (129.1 | ) |  | 24.9 |  |  | (104.2 | ) |  | (179.8 | ) |  | 14.0 |  |  | (165.8 | ) |
| Provision for income taxes | 17.7 |  |  | (0.8 | ) |  | 16.9 |  |  | 22.5 |  |  | 0.4 |  |  | 22.9 |  |
| Net loss | $ | (147.9 | ) |  | $ | 25.7 |  |  | $ | (122.2 | ) |  | $ | (216.6 | ) |  | $ | 13.6 |  |  | $ | (203.0 | ) |
| Net loss per share, basic and diluted | $ | (1.61 | ) |  | $ | 0.28 |  |  | $ | (1.33 | ) |  | $ | (2.39 | ) |  | $ | 0.15 |  |  | $ | (2.24 | ) |

[0001327567-19-000032:notes:163]
|  | July 31, 2018 |
|  | As Previously Reported |  | Impact of Adoption |  | As Adjusted |
| Consolidated Balance Sheet |  |  |  |  |  |
| Accounts receivable, net | $ | 467.3 |  |  | $ | (0.3 | ) |  | $ | 467.0 |  |
| Prepaid expenses and other current assets | 261.3 |  |  | 6.8 |  |  | 268.1 |  |
| Other assets | 206.8 |  |  | 119.4 |  |  | 326.2 |  |
| Accrued and other liabilities | 107.0 |  |  | 17.6 |  |  | 124.6 |  |
| Deferred revenue | 1,268.9 |  |  | (55.3 | ) |  | 1,213.6 |  |
| Long-term deferred revenue | 1,096.0 |  |  | (30.3 | ) |  | 1,065.7 |  |
| Accumulated deficit | $ | (984.6 | ) |  | $ | 193.9 |  |  | $ | (790.7 | ) |

[0001327567-19-000032:notes:164]
The adoption of the standard did not impact net cash flows from operating, investing, or financing activities in our consolidated statements of cash flows.

[0001327567-19-000032:notes:165]
Recently Issued Accounting Pronouncements

[0001327567-19-000032:notes:166]
Financial Instruments - Credit Losses

[0001327567-19-000032:notes:167]
In June 2016, the FASB issued new authoritative guidance on the accounting for credit losses on most financial assets and certain financial instruments. The standard replaces the existing incurred loss model with an expected credit loss model for financial assets measured at amortized cost, including trade receivables, and requires that credit losses on available-for-sale debt securities be presented as an allowance rather than as a write-down. The standard is effective for us in our first quarter of fiscal 2021 and will be applied on a modified retrospective basis. Early adoption is permitted beginning our first quarter of fiscal 2020. We are currently evaluating adoption timing and whether this standard will have a material impact on our consolidated financial statements.

[0001327567-19-000032:notes:168]
In February 2016, the FASB issued new authoritative guidance on lease accounting. Among its provisions, the standard requires lessees to recognize right-of-use assets and lease liabilities on the balance sheet for operating leases and also requires additional qualitative and quantitative disclosures about lease arrangements. We will adopt the standard effective August 1, 2019, on a modified retrospective basis and will not restate comparative periods.

[0001327567-19-000032:notes:169]
We are in the process of finalizing our implementation of the standard and have updated our systems, accounting policies, and processes. We plan to elect the practical expedients permitted under the transition guidance, which allows us to carry forward our historical assessments of whether contracts are or contain leases, lease classification, and initial direct costs. Additionally, we plan to elect to account for lease and non-lease components as a single lease component and to not recognize right-of-use assets and lease liabilities for leases with a term of 12 months or less. We expect to recognize right-of-use assets and lease liabilities on our consolidated balance sheet upon adoption, primarily relating to our facilities leases disclosed in Note 11. Commitments and Contingencies, which will materially increase our total assets and liabilities. We do not expect the adoption of this standard to have a material impact to our consolidated statements of operations and consolidated statements of cash flows.


## us-gaap:CapitalizedContractCostTableTextBlock

[0001327567-19-000032:notes:170]
The following table presents details of our short-term and long-term deferred contract costs as of July 31, 2019 and July 31, 2018 (in millions):

[0001327567-19-000032:notes:171]
|  | July 31, 2019 |  | July 31, 2018 |
| Short-term deferred contract costs | $ | 151.1 |  |  | $ | 113.2 |  |
| Long-term deferred contract costs | 324.2 |  |  | 224.8 |  |
| Total deferred contract costs | $ | 475.3 |  |  | $ | 338.0 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001327567-19-000032:notes:172]
Commitments and Contingencies

[0001327567-19-000032:notes:173]
We lease our facilities under various non-cancelable operating leases, which expire through the year ending July 31, 2028.

[0001327567-19-000032:notes:174]
In May 2015 and October 2015, we entered into a total of three lease agreements for approximately 941,000 square feet of corporate office space in Santa Clara, California, which serves as our new corporate headquarters. The leases contain rent holiday periods, scheduled rent increases, lease incentives, and renewal options which allow the lease terms to be extended beyond their expiration dates of July 2028 through July 2046. In September 2017, per the terms of the lease agreements, the landlords exercised their option to amend our lease payment schedules and eliminate our rent holiday periods, which increased our rental payments by $24.4 million, $11.8 million, and $2.0 million for fiscal 2018, 2019, and 2020, respectively. In exchange, we received an upfront cash reimbursement of $38.2 million during the three months ended October 31, 2017, which we have applied and will apply against the future additional rental payments when due. As amended, rental payments under the three lease agreements are approximately $412.0 million over the lease term.

[0001327567-19-000032:notes:175]
In May 2015, we also entered into a lease agreement for approximately 122,000 square feet of space in Santa Clara, California to serve as an extension of our previous corporate headquarters. The lease contains scheduled rent increases, lease incentives, and renewal options which allow the lease term to be extended beyond the expiration date of April 2021 through July 2046. Rental payments under the lease agreement are approximately $23.1 million over the lease term. In December 2017, we entered into an agreement to sublease this office space for the remaining lease term. Proceeds from this sublease are approximately $16.3 million over the sublease term.

[0001327567-19-000032:notes:176]
In September 2012, we entered into two lease agreements for a total of approximately 300,000 square feet of space in Santa Clara, California, which served as our previous corporate headquarters through August 2017, when we relocated to our new corporate campus. The leases contain rent holiday periods and two separate five-year options to extend the lease term beyond their expiration dates of July 2023. Rental payments under these lease agreements are approximately $94.3 million over the lease term. In August 2017, we exited our previous corporate headquarter facilities and relocated to our new corporate campus, which resulted in the recognition of a cease-use loss of $39.2 million during the year ended July 31, 2018. Due to changes in market conditions, and the resulting changes to the amount and timing of estimated cash flows from sublease rentals that could be reasonably obtained, we recognized an additional cease-use loss of $7.0 million as general and administrative expense in our consolidated statements of operations during the year ended July 31, 2019, and a corresponding liability in our consolidated balance sheets. During the years ended July 31, 2019 and 2018, we released $10.0 million and $10.1 million, respectively, of the cease-use liability through rental payments. As of July 31, 2019 and 2018, the remaining balance of the cease-use liability was $26.1 million and $29.1 million, respectively. The remaining balance as of July 31, 2019 is expected to be paid through the end of the lease term in July 2023.

[0001327567-19-000032:notes:177]
We recognized rent expense of $43.0 million, $35.2 million, and $35.9 million for the years ended July 31, 2019, 2018, and 2017, respectively. Rent expense is recognized on a straight-line basis over the term of the lease.

[0001327567-19-000032:notes:178]
The following table presents details of the aggregate future non-cancelable minimum rental payments under our operating leases as of July 31, 2019 (in millions):

[0001327567-19-000032:notes:179]
|  | Amount |
| Years ending July 31: |  |
| 2020 | $ | 74.1 |  |
| 2021 | 67.2 |  |
| 2022 | 62.9 |  |
| 2023 | 60.2 |  |
| 2024 | 45.5 |  |
| 2025 and thereafter | 181.9 |  |
| Committed gross lease payments | 491.8 |  |
| Less: proceeds from sublease rentals | 9.8 |  |
| Net operating lease obligation | $ | 482.0 |  |

[0001327567-19-000032:notes:180]
Purchase Commitments

[0001327567-19-000032:notes:181]
Manufacturing Purchase Commitments

[0001327567-19-000032:notes:182]
Our EMS provider procures components and assembles our products based on our forecasts. These forecasts are based on estimates of demand for our products primarily for the next 12 months, which are in turn based on historical trends and an analysis from our sales and product management organizations, adjusted for overall market conditions. In order to reduce manufacturing lead times and plan for adequate supply, we may issue non-cancelable orders for products and components to our manufacturing partners or component suppliers. As of July 31, 2019, our purchase commitments under such orders were $109.2 million, excluding obligations under contracts that we can cancel without a significant penalty.

[0001327567-19-000032:notes:183]
Other Purchase Commitments

[0001327567-19-000032:notes:184]
We have entered into various non-cancelable agreements with third-party providers for our use of certain cloud and other services, under which we are committed to minimum or fixed purchases through the year ending July 31, 2026. The following table presents details of the aggregate future non-cancelable purchase commitments under these agreements as of July 31, 2019 (in millions):

[0001327567-19-000032:notes:185]
|  | Amount |
| Fiscal years ending July 31: |  |
| 2020 | $ | 10.0 |  |
| 2021 | 30.1 |  |
| 2022 | 55.8 |  |
| 2023 | 57.5 |  |
| 2024 | 67.5 |  |
| 2025 and thereafter | 97.5 |  |
| Total other purchase commitments | $ | 318.4 |  |

[0001327567-19-000032:notes:186]
Litigation

[0001327567-19-000032:notes:187]
We are subject to legal proceedings, claims, and litigation arising in the ordinary course of business, including intellectual property litigation. Such matters are subject to many uncertainties and outcomes are not predictable with assurance. We accrue for contingencies when we believe that a loss is probable and that we can reasonably estimate the amount of any such loss.

[0001327567-19-000032:notes:188]
To the extent there is a reasonable possibility that a loss exceeding amounts already recognized may be incurred and the amount of such additional loss would be material, we will either disclose the estimated additional loss or state that such an estimate cannot be made. As of July 31, 2019, we have not recorded any significant accruals for loss contingencies associated with such legal proceedings, determined that an unfavorable outcome is probable or reasonably possible, or determined that the amount or range of any possible loss is reasonably estimable.

[0001327567-19-000032:notes:189]
Indemnification

[0001327567-19-000032:notes:190]
Under the indemnification provisions of our standard sales related contracts, we agree to defend our end-customers against third-party claims asserting infringement of certain intellectual property rights, which may include patents, copyrights, trademarks, or trade secrets, and to pay judgments entered on such claims. Our exposure under these indemnification provisions is generally limited to payments made to us for the alleged infringing products over the preceding twelve months under the agreement. However, certain agreements include indemnification provisions that could potentially expose us to losses in excess of these payments. In addition, we indemnify our officers, directors, and certain key employees while they are serving in good faith in their company capacities. To date, we have not recorded any accruals for loss contingencies associated with indemnification claims or determined that an unfavorable outcome is probable or reasonably possible.


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0001327567-19-000032:notes:191]
Employee Benefit Plan

[0001327567-19-000032:notes:192]
We have established a 401(k) tax-deferred savings plan which permits participants to make contributions by salary deduction pursuant to Section 401(k) of the Internal Revenue Code. We make matching contributions based upon the amount of employees’ contributions, subject to certain limitations. Our matching contributions to the plan were immaterial for the years ended July 31, 2019, 2018, and 2017.


## us-gaap:ConvertibleDebtTableTextBlock

[0001327567-19-000032:notes:193]
The following table sets forth the components of the Notes as of July 31, 2019 and July 31, 2018 (in millions):

[0001327567-19-000032:notes:194]
|  | July 31, 2019 |  | July 31, 2018 |
|  | 2019 Notes |  | 2023 Notes |  | Total |  | 2019 Notes |  | 2023 Notes |  | Total |
| Liability component: |  |  |  |  |  |  |  |  |  |  |  |
| Principal | $ | — |  |  | $ | 1,693.0 |  |  | $ | 1,693.0 |  |  | $ | 575.0 |  |  | $ | 1,693.0 |  |  | $ | 2,268.0 |  |
| Less: debt discount and debt issuance costs, net of amortization | — |  |  | 263.0 |  |  | 263.0 |  |  | 24.6 |  |  | 323.3 |  |  | 347.9 |  |
| Net carrying amount | $ | — |  |  | $ | 1,430.0 |  |  | $ | 1,430.0 |  |  | $ | 550.4 |  |  | $ | 1,369.7 |  |  | $ | 1,920.1 |  |
| Equity component (including amounts classified as temporary equity) | $ | — |  |  | $ | 315.0 |  |  | $ | 315.0 |  |  | $ | 109.8 |  |  | $ | 315.0 |  |  | $ | 424.8 |  |


## us-gaap:DebtDisclosureTextBlock

[0001327567-19-000032:notes:195]
Debt

[0001327567-19-000032:notes:196]
In June 2014, we issued $575.0 million aggregate principal amount of 0.0% Convertible Senior Notes due 2019 (the “2019 Notes”) and in July 2018, we issued $1.7 billion aggregate principal amount of 0.75% Convertible Senior Notes due 2023 (the “2023 Notes” and, together with the 2019 Notes, the “Notes”). The 2023 Notes bear interest at a fixed rate of 0.75% per year, payable semi-annually in arrears on January 1 and July 1 of each year, beginning on January 1, 2019. Each series of Notes is governed by an indenture between us, as the issuer, and U.S. Bank National Association, as Trustee (individually, each an “Indenture,” and together, the “Indentures”). The Notes of each series are unsecured, unsubordinated obligations and the applicable Indenture governing each series of Notes does not contain any financial covenants or restrictions on the payments of dividends, the incurrence of indebtedness, or the issuance or repurchase of securities by us or any of our subsidiaries. The 2019 Notes were converted prior to or settled on the maturity date of July 1, 2019, in accordance with their terms. The 2023 Notes mature on July 1, 2023. We cannot redeem the 2023 Notes prior to maturity.

[0001327567-19-000032:notes:197]
Holders of the Notes may surrender their Notes for conversion at their option at any time prior to the close of business on the business day immediately preceding their respective convertible dates only under the following circumstances:

[0001327567-19-000032:notes:198]
| • | during any fiscal quarter commencing after the fiscal quarters ending on October 31, 2014 and October 31, 2018, for the 2019 Notes and 2023 Notes, respectively (and only during such fiscal quarter), if the last reported sale price of our common stock for at least 20 trading days (whether or not consecutive) during a period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the applicable conversion price for the respective Notes on each applicable trading day (the “sale price condition”); |

[0001327567-19-000032:notes:199]
| • | during the five business day period after any five consecutive trading day period (the “measurement period”) in which the trading price per $1,000 principal amount of the applicable series of Notes for each trading day of the measurement period was less than 98% of the product of the last reported sale price of our common stock and the applicable conversion rate for the respective Notes on each such trading day; or |

[0001327567-19-000032:notes:200]
| • | upon the occurrence of specified corporate events. |

[0001327567-19-000032:notes:201]
On or after the respective convertible date, holders may surrender all or any portion of their Notes for conversion at any time prior to the close of business on the second scheduled trading day immediately preceding the applicable maturity date regardless of the foregoing conditions, and such conversions will be settled upon the applicable maturity date. Upon conversion, holders of the Notes of a series will receive cash equal to the aggregate principal amount of the Notes of such series to be converted, and, at our election, cash and/or shares of our common stock for any amounts in excess of the aggregate principal amount of the Notes of such series being converted.

[0001327567-19-000032:notes:202]
The conversion price will be subject to adjustment in some events. Holders of the Notes of a series who convert their Notes of such series in connection with certain corporate events that constitute a “make-whole fundamental change” under the applicable Indenture are, under certain circumstances, entitled to an increase in the conversion rate for such series of Notes. Additionally, upon the occurrence of a corporate event that constitutes a “fundamental change” under the applicable Indenture, holders of the Notes of such series may require us to repurchase for cash all or a portion of the Notes of such series at a repurchase price equal to 100% of the principal amount of the Notes of such series plus accrued and unpaid interest to, but excluding, the fundamental change repurchase date.

[0001327567-19-000032:notes:203]
The sale price condition was met for the 2019 Notes during the fiscal quarters ended July 31, 2018 and October 31, 2018. As a result, holders were able to early convert their 2019 Notes at any time during the fiscal quarter ended October 31, 2018 and up to January 1, 2019. Conversion requests for the 2019 Notes received on or after January 1, 2019 were settled on the maturity date. During the year ended July 31, 2019, we repaid $575.0 million in aggregate principal amount of the 2019 Notes, of which $415.6 million in aggregate principal amount pertained to early conversions submitted by the holders prior to January 1, 2019. The remaining $159.4 million in aggregate principal amount was repaid on the July 1, 2019 maturity date. We issued 2.5 million shares of common stock to the holders of the 2019 Notes for the conversion value in excess of the principal amount during the year ended July 31, 2019. These shares were fully offset by shares received from the corresponding exercise of the associated note hedges.

[0001327567-19-000032:notes:204]
The sale price condition was not met for the 2023 Notes during the fiscal quarters ended July 31, 2019 or July 31, 2018. Since the 2023 Notes were not convertible, the net carrying amount of the 2023 Notes was classified as a long-term liability and the equity component was included in additional paid-in capital in our consolidated balance sheets as of July 31, 2019 and July 31, 2018. As of July 31, 2019, all of the 2023 Notes remained outstanding.

[0001327567-19-000032:notes:205]
The total estimated fair value of the 2023 Notes was $1.9 billion at July 31, 2019. The total estimated fair value of the Notes was $2.7 billion at July 31, 2018. The fair value was determined based on the closing trading price per $100 of the Notes as of the last day of trading for the period. We consider the fair value of the Notes at July 31, 2019 and July 31, 2018 to be a Level 2 measurement. The fair value of the Notes is primarily affected by the trading price of our common stock and market interest rates. Based on the closing price of our common stock on July 31, 2019, the if-converted value of the 2023 Notes was less than its principal amount.

[0001327567-19-000032:notes:206]
The following table sets forth interest expense recognized related to the Notes (dollars in millions):

[0001327567-19-000032:notes:207]
|  | Year Ended July 31, 2019 |  | Year Ended July 31, 2018 |  | Year Ended July 31, 2017 |
|  | 2019 Notes |  | 2023 Notes |  | Total |  | 2019 Notes |  | 2023 Notes |  | Total |  | 2019 Notes |  | 2023 Notes |  | Total |
| Contractual interest expense | $ | — |  |  | $ | 12.7 |  |  | $ | 12.7 |  |  | $ | — |  |  | $ | 0.7 |  |  | $ | 0.7 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Amortization of debt discount | 8.7 |  |  | 58.5 |  |  | 67.2 |  |  | 22.9 |  |  | 3.0 |  |  | 25.9 |  |  | 22.0 |  |  | — |  |  | 22.0 |  |
| Amortization of debt issuance costs | 1.1 |  |  | 1.9 |  |  | 3.0 |  |  | 2.8 |  |  | 0.1 |  |  | 2.9 |  |  | 2.5 |  |  | — |  |  | 2.5 |  |
| Total interest expense recognized | $ | 9.8 |  |  | $ | 73.1 |  |  | $ | 82.9 |  |  | $ | 25.7 |  |  | $ | 3.8 |  |  | $ | 29.5 |  |  | $ | 24.5 |  |  | $ | — |  |  | $ | 24.5 |  |
| Effective interest rate of the liability component | 4.8 | % |  | 5.2 | % |  |  |  | 4.8 | % |  | 5.2 | % |  |  |  | 4.8 | % |  | — | % |  |  |

[0001327567-19-000032:notes:208]
Note Hedges

[0001327567-19-000032:notes:209]
To minimize the impact of potential economic dilution upon conversion of the Notes, we entered into separate convertible note hedge transactions (the “2019 Note Hedges,” with respect to the 2019 Notes, and the “2023 Note Hedges,” with respect to the 2023 Notes, and collectively, the “Note Hedges”) with respect to our common stock concurrent with the issuance of each series of Notes.

[0001327567-19-000032:notes:210]
The Note Hedges cover shares of our common stock at a strike price per share that corresponds to the initial applicable conversion price of the applicable series of Notes, which are also subject to adjustment, and are exercisable upon conversion of the applicable series of Notes. The Note Hedges will expire upon maturity of the applicable series of Notes. The Note Hedges are separate transactions and are not part of the terms of the applicable series of the Notes. Holders of the Notes of either series will not have any rights with respect to the Note Hedges. Any shares of our common stock receivable by us under the Note Hedges are excluded from the calculation of diluted earnings per share as they are antidilutive. The aggregate amounts paid for the Note Hedges are included in additional paid-in capital in our consolidated balance sheets.

[0001327567-19-000032:notes:211]
As a result of the conversions of the 2019 Notes settled during the year ended July 31, 2019, we exercised the corresponding portion of our 2019 Note Hedges and received 2.5 million shares of our common stock during the period. As of July 31, 2019, none of our 2019 Note Hedges were outstanding.

[0001327567-19-000032:notes:212]
Warrants

[0001327567-19-000032:notes:213]
Separately, but concurrently with the issuance of each series of Notes, we entered into transactions whereby we sold warrants (the “2019 Warrants,” with respect to the 2019 Notes, and the “2023 Warrants,” with respect to the 2023 Notes, and collectively, the “Warrants”) to acquire shares of our common stock, subject to anti-dilution adjustments. The 2019 Warrants and 2023 Warrants are exercisable beginning October 2019 and October 2023, respectively.

[0001327567-19-000032:notes:214]
The following table presents details of the Warrants (in millions, except per share data):

[0001327567-19-000032:notes:215]
|  | Initial Number of Shares |  | Strike Price per Share |  | Aggregate Proceeds |
| 2019 Warrants | 5.2 |  |  | $ | 137.85 |  |  | $ | 78.3 |  |
| 2023 Warrants | 6.4 |  |  | $ | 417.80 |  |  | $ | 145.4 |  |

[0001327567-19-000032:notes:216]
The shares issuable under the Warrants will be included in the calculation of diluted earnings per share when the average market value per share of our common stock for the reporting period exceeds the applicable strike price for such series of Warrants. The Warrants are separate transactions and are not part of either series of Notes or Note Hedges and are not remeasured through earnings each reporting period. Holders of the Notes of either series will not have any rights with respect to the Warrants. The aggregate proceeds received from the sale of the Warrants are included in additional paid-in capital in our consolidated balance sheets.

[0001327567-19-000032:notes:217]
Revolving Credit Facility

[0001327567-19-000032:notes:218]
On September 4, 2018, we entered into a credit agreement (the “Credit Agreement”) with certain institutional lenders that provides for a $400.0 million unsecured revolving credit facility (the “Credit Facility”), with an option to increase the amount of the Credit Facility by up to an additional $350.0 million, subject to certain conditions. The Credit Facility matures on the earlier of (i) September 4, 2023 and (ii) the date that is 91 days prior to the stated maturity of our 2023 Notes if (a) any of the 2023 Notes are still outstanding and (b) our unrestricted cash and cash equivalents are less than the then outstanding principal amount of our 2023 Notes plus $400.0 million.

[0001327567-19-000032:notes:219]
The borrowings under the Credit Facility bear interest, at our option, at a base rate plus a spread of 0.00% to 0.75%, or an adjusted LIBO rate plus a spread of 1.00% to 1.75%, in each case with such spread being determined based on our leverage ratio. We are obligated to pay an ongoing commitment fee on undrawn amounts at a rate of 0.125% to 0.250%, depending on our leverage ratio. As of July 31, 2019, there were no amounts outstanding and we were in compliance with all covenants under the Credit Agreement.


## us-gaap:DebtSecuritiesAvailableForSaleTableTextBlock

[0001327567-19-000032:notes:220]
The following tables summarize the amortized cost, unrealized gains and losses, and fair value of our available-for-sale debt securities as of July 31, 2019 and July 31, 2018 (in millions):

[0001327567-19-000032:notes:221]
|  | July 31, 2019 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 12.0 |  |  | $ | — |  |  | $ | — |  |  | $ | 12.0 |  |
| Commercial paper | 19.3 |  |  | — |  |  | — |  |  | 19.3 |  |
| U.S. government and agency securities | 54.4 |  |  | — |  |  | — |  |  | 54.4 |  |
| Total available-for-sale cash equivalents | $ | 85.7 |  |  | $ | — |  |  | $ | — |  |  | $ | 85.7 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 17.5 |  |  | $ | — |  |  | $ | — |  |  | $ | 17.5 |  |
| Commercial paper | 8.9 |  |  | — |  |  | — |  |  | 8.9 |  |
| Corporate debt securities | 587.8 |  |  | 2.3 |  |  | (0.3 | ) |  | 589.8 |  |
| U.S. government and agency securities | 1,799.5 |  |  | 2.6 |  |  | (1.2 | ) |  | 1,800.9 |  |
| Total available-for-sale investments | $ | 2,413.7 |  |  | $ | 4.9 |  |  | $ | (1.5 | ) |  | $ | 2,417.1 |  |

[0001327567-19-000032:notes:222]
|  | July 31, 2018 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | $ | 52.0 |  |  | $ | — |  |  | $ | — |  |  | $ | 52.0 |  |
| U.S. government and agency securities | 397.3 |  |  | — |  |  | — |  |  | 397.3 |  |
| Total available-for-sale cash equivalents | $ | 449.3 |  |  | $ | — |  |  | $ | — |  |  | $ | 449.3 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 5.4 |  |  | $ | — |  |  | $ | — |  |  | $ | 5.4 |  |
| Non-U.S. government securities | 20.0 |  |  | — |  |  | — |  |  | 20.0 |  |
| Commercial paper | 22.3 |  |  | — |  |  | — |  |  | 22.3 |  |
| Corporate debt securities | 295.9 |  |  | — |  |  | (2.5 | ) |  | 293.4 |  |
| U.S. government and agency securities | 1,110.6 |  |  | — |  |  | (7.7 | ) |  | 1,102.9 |  |
| Total available-for-sale investments | $ | 1,454.2 |  |  | $ | — |  |  | $ | (10.2 | ) |  | $ | 1,444.0 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001327567-19-000032:notes:223]
Derivative Instruments

[0001327567-19-000032:notes:224]
As a global business, we are exposed to currency exchange rate risk. Substantially all of our revenue is transacted in U.S. dollars, however, a portion of our operating expenditures are incurred outside of the United States and are denominated in foreign currencies, making them subject to fluctuations in foreign currency exchange rates. We enter into foreign currency derivative contracts with maturities of 15 months or less, which we designate as cash flow hedges, to manage the foreign currency exchange rate risk associated with these expenditures.

[0001327567-19-000032:notes:225]
As of July 31, 2019 and 2018, the total notional amount of our outstanding foreign currency forward contracts was $307.2 million and $288.5 million, respectively. Refer to Note 3. Fair Value Measurements for the fair value of our derivative instruments as reported on our consolidated balance sheets as of July 31, 2019.

[0001327567-19-000032:notes:226]
During the years ended July 31, 2019, 2018, and 2017, both unrealized gains and losses recognized in AOCI related to our cash flow hedges and amounts reclassified into earnings were not material. Unrealized losses in AOCI related to our cash flow hedges as of July 31, 2019 and 2018 were not material.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001327567-19-000032:notes:227]
Equity Award Plans

[0001327567-19-000032:notes:228]
Share-Based Compensation Plans

[0001327567-19-000032:notes:229]
2012 Equity Incentive Plan

[0001327567-19-000032:notes:230]
Our 2012 Equity Incentive Plan (our “2012 Plan”) was adopted by our board of directors and approved by the stockholders on June 5, 2012 and was effective one business day prior to the effectiveness of our registration statement for our initial public offering (“IPO”). Our 2012 Plan replaced our 2005 Equity Incentive Plan (our “2005 Plan”), which terminated upon the completion of our IPO, however, awards that were outstanding upon termination remained outstanding pursuant to their original terms. Our 2012 Plan provides for the granting of stock options, restricted stock awards (“RSAs”), restricted stock units (“RSUs”), stock appreciation rights, performance-based stock units (“PSUs”), performance shares (“PSAs”), and performance stock options (“PSOs”) to our employees, directors, and consultants.

[0001327567-19-000032:notes:231]
Awards granted under our 2012 Plan vest over the periods determined by the board of directors, generally three to four years from the date of grant, and our options expire no more than ten years after the date of grant. Since our IPO in 2012, awards granted under our 2012 Plan consist primarily of RSUs. Until vested, RSUs do not have the voting and dividend participation rights of common stock and the shares underlying the awards are not considered issued and outstanding.

[0001327567-19-000032:notes:232]
We grant awards with performance conditions (PSAs and PSUs) to certain employees, which vest over a period of three to four years from the date of grant. The actual number of PSAs and PSUs earned and eligible to vest is determined based on level of achievement against pre-established billings or revenue growth targets for the fiscal year.

[0001327567-19-000032:notes:233]
We have also granted PSOs with both a market condition and a service condition to certain executives. The market condition requires the price of our common stock to equal or exceed $297.75, $397.00, $496.25, and $595.50 (the “stock price targets”) during the four-, five-, six-, and seven-year periods following the date of grant, respectively. To the extent that the stock price targets have been met, one-fourth of the PSOs will vest on the anniversary date of the grant date for such PSOs, subject to continued service. All outstanding PSOs may be exercised prior to vesting (“early exercised”). Shares of common stock issued upon early exercise of the PSOs will be restricted and, at our option, subject to repurchase if the option holder ceases to be a service provider. The contractual term of our PSOs is seven to seven and a half years from the date of grant, depending on vesting period.

[0001327567-19-000032:notes:234]
We net-share settle equity awards held by certain employees by withholding shares upon vesting to satisfy tax withholding obligations. The shares withheld to satisfy employee tax withholding obligations are returned to our 2012 Plan and will be available for future issuance. Payments for employees’ tax obligations to the tax authorities are recognized as a reduction to additional paid-in capital and reflected as financing activities in our consolidated statements of cash flows.

[0001327567-19-000032:notes:235]
A total of 18.8 million shares of our common stock are reserved for issuance pursuant to our 2012 Plan as of July 31, 2019. This includes shares that are (i) reserved but unissued under our 2005 Plan on the effective date of our 2012 Plan or (ii) returned to our 2005 Plan as a result of expiration or termination of options. On the first day of each fiscal year, the number of shares in the reserve may be increased by the lesser of (i) 8,000,000 shares, (ii) 4.5% of the outstanding shares of common stock on the last day of our immediately preceding fiscal year, or (iii) such other amount as determined by our board of directors.

[0001327567-19-000032:notes:236]
2012 Employee Stock Purchase Plan

[0001327567-19-000032:notes:237]
Our 2012 Employee Stock Purchase Plan was adopted by our board of directors and approved by the stockholders on June 5, 2012, and was effective upon completion of our IPO. On August 29, 2017, we amended and restated our 2012 Employee Stock Purchase Plan (our “2012 ESPP”) to extend the length of our offering periods from 6 to 24 months.

[0001327567-19-000032:notes:238]
Our 2012 ESPP permits eligible employees to acquire shares of our common stock at 85% of the lower of the fair market value of our common stock on the first trading day of each offering period or on the purchase date. If the fair market value of our common stock on the purchase date is lower than the first trading day of the offering period, the current offering period will be cancelled after purchase and a new 24-month offering period will begin. Under our 2012 ESPP, each 24-month offering period consists of four consecutive 6-month purchase periods, with purchase dates on the first trading day on or after February 28 and August 31 of each year. Participants may purchase shares of common stock through payroll deductions of up to 15% of their eligible compensation, subject to purchase limits of 625 shares per six-month purchase period and $25,000 worth of stock for each calendar year. During the year ended July 31, 2019, employees purchased 0.5 million shares of common stock under our 2012 ESPP at an average exercise price of $128.81 per share.

[0001327567-19-000032:notes:239]
A total of 3.9 million shares of our common stock are available for sale under our 2012 ESPP as of July 31, 2019. On the first day of each fiscal year, the number of shares in the reserve may be increased by the lesser of (i) 2,000,000 shares, (ii) 1% of the outstanding shares of our common stock on the first day of the fiscal year, or (iii) such other amount as determined by our board of directors.

[0001327567-19-000032:notes:240]
Acquisition-related Activities

[0001327567-19-000032:notes:241]
Assumed Share-based Compensation Plans

[0001327567-19-000032:notes:242]
In connection with our acquisitions of RedLock, Demisto, and Twistlock, we assumed RedLock’s 2015 Stock Plan, as amended, Demisto’s 2015 Stock Option Plan, as amended, and Twistlock’s 2015 Share Option Plan, as amended and restated (together, the “assumed Plans”). The equity awards assumed in connection with each acquisition were granted from their respective assumed Plans. The assumed equity awards will be settled in shares of our common stock and will retain the terms and conditions under which they were originally granted. No additional equity awards will be granted under and forfeited awards will not be returned to the assumed Plans. Refer to Note 6. Acquisitions for more information on our acquisitions and the related equity awards assumed.

[0001327567-19-000032:notes:243]
Restricted Stock Issuances

[0001327567-19-000032:notes:244]
In connection with our acquisitions of RedLock, Demisto, PureSec, and Twistlock during the year ended July 31, 2019, we issued a total of 0.5 million shares of restricted common stock as replacement equity awards which are subject to additional time-based vesting requirements and continued service by the award holder.

[0001327567-19-000032:notes:245]
Stock Option Activities

[0001327567-19-000032:notes:246]
The following table summarizes the stock option and PSO activity under our stock plans during the years ended July 31, 2019, 2018, and 2017 (in millions, except per share amounts):

[0001327567-19-000032:notes:247]
|  | Stock Options Outstanding |  | PSOs Outstanding |
|  | Number of Shares |  | Weighted-Average Exercise Price Per Share |  | Weighted-Average Remaining Contractual Term(Years) |  | Aggregate Intrinsic Value |  | Number of Shares |  | Weighted-Average Exercise Price Per Share |  | Weighted-Average Remaining Contractual Term(Years) |  | Aggregate Intrinsic Value |
| Balance—July 31, 2016 | 2.1 |  |  | $ | 13.42 |  |  | 5.2 |  | $ | 244.9 |  |  | — |  |  | $ | — |  |  | 0.0 |  | $ | — |  |
| Granted | — |  |  | $ | — |  |  |  |  |  |  | — |  |  | $ | — |  |  |  |  |  |
| Exercised | (0.5 | ) |  | $ | 14.44 |  |  |  |  |  |  | — |  |  | $ | — |  |  |  |  |  |
| Forfeited | — |  |  | $ | — |  |  |  |  |  |  | — |  |  | $ | — |  |  |  |  |  |
| Balance—July 31, 2017 | 1.6 |  |  | $ | 13.11 |  |  | 4.2 |  | $ | 190.6 |  |  | — |  |  | $ | — |  |  | 0.0 |  | $ | — |  |
| Granted | — |  |  | $ | — |  |  |  |  |  |  | 1.2 |  |  | $ | 198.50 |  |  |  |  |  |
| Exercised | (0.6 | ) |  | $ | 12.76 |  |  |  |  |  |  | — |  |  | $ | — |  |  |  |  |  |
| Forfeited | — |  |  | $ | — |  |  |  |  |  |  | — |  |  | $ | — |  |  |  |  |  |
| Balance—July 31, 2018 | 1.0 |  |  | $ | 13.28 |  |  | 3.1 |  | $ | 199.8 |  |  | 1.2 |  |  | $ | 198.50 |  |  | 7.0 |  | $ | — |  |
| Granted | — |  |  | $ | — |  |  |  |  |  |  | 2.6 |  |  | $ | 191.97 |  |  |  |  |  |
| Exercised | (0.7 | ) |  | $ | 12.61 |  |  |  |  |  |  | — |  |  | $ | — |  |  |  |  |  |
| Forfeited | — |  |  | $ | 1.24 |  |  |  |  |  |  | (0.1 | ) |  | $ | 193.51 |  |  |  |  |  |
| Balance—July 31, 2019 | 0.3 |  |  | $ | 14.53 |  |  | 2.2 |  | $ | 81.4 |  |  | 3.7 |  |  | $ | 193.99 |  |  | 6.2 |  | $ | 120.1 |  |
| Exercisable—July 31, 2019 | 0.3 |  |  | $ | 14.53 |  |  | 2.2 |  | $ | 81.4 |  |  | 3.7 |  |  | $ | 193.99 |  |  | 6.2 |  | $ | 120.1 |  |

[0001327567-19-000032:notes:248]
The weighted-average grant-date fair value of PSOs granted during the years ended July 31, 2019 and July 31, 2018 was $59.11 and $56.14 per share, respectively. No stock options or PSOs were granted during the year ended July 31, 2017. No options vested during the years ended July 31, 2019, 2018 or 2017. The intrinsic value of options exercised during the years ended July 31, 2019, 2018, and 2017 was $139.5 million, $85.0 million, and $61.2 million, respectively.

[0001327567-19-000032:notes:249]
RSA and PSA Activities

[0001327567-19-000032:notes:250]
The following table summarizes the RSA and PSA activity under our stock plans during the years ended July 31, 2019, 2018, and 2017 (in millions, except per share amounts):

[0001327567-19-000032:notes:251]
|  | RSAs Outstanding |  | PSAs Outstanding |
|  | Number of Shares |  | Weighted- Average Grant-Date Fair Value Per Share |  | Number of Shares |  | Weighted- Average Grant-Date Fair Value Per Share |
| Balance—July 31, 2016 | 1.1 |  |  | $ | 170.97 |  |  | — |  |  | $ | — |  |
| Granted(1) | 0.1 |  |  | $ | 148.54 |  |  | 0.2 |  |  | $ | 148.54 |  |
| Vested | (0.4 | ) |  | $ | 170.97 |  |  | — |  |  | $ | — |  |
| Forfeited | — |  |  | $ | — |  |  | — |  |  | $ | — |  |
| Balance—July 31, 2017 | 0.8 |  |  | $ | 166.86 |  |  | 0.2 |  |  | $ | 148.54 |  |
| Granted(1) | — |  |  | $ | — |  |  | — |  |  | $ | — |  |
| Vested | (0.5 | ) |  | $ | 169.38 |  |  | — |  |  | $ | 148.54 |  |
| Forfeited | (0.1 | ) |  | $ | 166.05 |  |  | (0.1 | ) |  | $ | 148.54 |  |
| Balance—July 31, 2018 | 0.2 |  |  | $ | 163.14 |  |  | 0.1 |  |  | $ | 148.54 |  |
| Granted(1) | — |  |  | $ | — |  |  | — |  |  | $ | — |  |
| Vested | (0.2 | ) |  | $ | 166.83 |  |  | — |  |  | $ | 148.54 |  |
| Forfeited | — |  |  | $ | 152.09 |  |  | — |  |  | $ | 148.54 |  |
| Balance—July 31, 2019 | — |  |  | $ | 148.54 |  |  | 0.1 |  |  | $ | 148.54 |  |

[0001327567-19-000032:notes:252]
| (1) | For PSAs, shares granted represents the aggregate maximum number of shares that may be earned and issued with respect to these awards over their full terms. |

[0001327567-19-000032:notes:253]
No RSAs or PSAs were granted during the years ended July 31, 2019 and 2018. The aggregate fair value, as of the respective vesting dates, of RSAs vested during the years ended July 31, 2019, 2018, and 2017 was $41.1 million, $65.0 million, $62.6 million, respectively. The aggregate fair value, as of the respective vesting dates, of PSAs vested during the years ended July 31, 2019 and 2018 was $4.5 million and $2.5 million, respectively. No PSAs vested during the year ended July 31, 2017.

[0001327567-19-000032:notes:254]
RSU and PSU Activities

[0001327567-19-000032:notes:255]
The following table summarizes the RSU and PSU activity under our stock plans during the years ended July 31, 2019, 2018, and 2017 (in millions, except per share amounts):

[0001327567-19-000032:notes:256]
|  | RSUs Outstanding |  | PSUs Outstanding |
|  | Number of Shares |  | Weighted- Average Grant-Date Fair Value Per Share |  | Weighted- Average Remaining Contractual Term (Years) |  | Aggregate Intrinsic Value |  | Number of Shares |  | Weighted- Average Grant-Date Fair Value Per Share |  | Weighted- Average Remaining Contractual Term (Years) |  | Aggregate Intrinsic Value |
| Balance—July 31, 2016 | 6.5 |  |  | $ | 130.14 |  |  | 1.1 |  | $ | 852.7 |  |  | — |  |  | $ | — |  |  | 0.0 |  | $ | — |  |
| Granted | 3.9 |  |  | $ | 141.35 |  |  |  |  |  |  | — |  |  | $ | — |  |  |  |  |  |
| Vested | (3.3 | ) |  | $ | 119.88 |  |  |  |  |  |  | — |  |  | $ | — |  |  |  |  |  |
| Forfeited | (0.6 | ) |  | $ | 139.56 |  |  |  |  |  |  | — |  |  | $ | — |  |  |  |  |  |
| Balance—July 31, 2017 | 6.5 |  |  | $ | 141.16 |  |  | 1.3 |  | $ | 854.1 |  |  | — |  |  | $ | — |  |  | 0.0 |  | $ | — |  |
| Granted(1) | 3.9 |  |  | $ | 171.74 |  |  |  |  |  |  | 0.2 |  |  | $ | 149.73 |  |  |  |  |  |
| Vested | (3.3 | ) |  | $ | 138.93 |  |  |  |  |  |  | — |  |  | $ | — |  |  |  |  |  |
| Forfeited | (0.6 | ) |  | $ | 144.33 |  |  |  |  |  |  | — |  |  | $ | — |  |  |  |  |  |
| Balance—July 31, 2018 | 6.5 |  |  | $ | 160.70 |  |  | 1.6 |  | $ | 1,291.4 |  |  | 0.2 |  |  | $ | 149.73 |  |  | 1.4 |  | $ | 43.7 |  |
| Granted(1)(2) | 3.9 |  |  | $ | 210.14 |  |  |  |  |  |  | 0.2 |  |  | $ | 215.64 |  |  |  |  |  |
| Vested(3) | (2.7 | ) |  | $ | 160.87 |  |  |  |  |  |  | (0.1 | ) |  | $ | 149.73 |  |  |  |  |  |
| Forfeited | (0.8 | ) |  | $ | 162.73 |  |  |  |  |  |  | — |  |  | $ | 155.38 |  |  |  |  |  |
| Balance—July 31, 2019 | 6.9 |  |  | $ | 188.16 |  |  | 1.5 |  | $ | 1,554.0 |  |  | 0.3 |  |  | $ | 197.86 |  |  | 1.8 |  | $ | 67.0 |  |

[0001327567-19-000032:notes:257]
| (1) | For PSUs, shares granted represent the aggregate maximum number of shares that may be earned and issued with respect to these awards over their full terms. |

[0001327567-19-000032:notes:258]
| (2) | Includes 0.4 million RSUs assumed and 0.1 million replacement RSUs granted in connection with the acquisitions of RedLock, Demisto, PureSec, and Twistlock, with weighted-average grant-date fair values of $218.69 and $224.31 per share, respectively. |

[0001327567-19-000032:notes:259]
| (3) | Includes time-based vesting for PSUs granted during the year ended July 31, 2018. |

[0001327567-19-000032:notes:260]
The aggregate fair value, as of the respective vesting dates, of RSUs vested during the years ended July 31, 2019, 2018, and 2017 was $566.4 million, $546.3 million, and $462.6 million, respectively. The aggregate fair value, as of the respective vesting dates, of PSUs vested during the year ended July 31, 2019 was $17.2 million. No PSUs vested during the years ended July 31, 2018 and 2017.

[0001327567-19-000032:notes:261]
Shares Available for Grant

[0001327567-19-000032:notes:262]
We record share-based compensation awards based on estimated fair value as of the grant date. The fair value of RSUs, PSUs, RSAs, and PSAs is based on the closing market price of our common stock on the date of grant.

[0001327567-19-000032:notes:263]
The fair value of PSOs is estimated on the grant date using a Monte Carlo simulation model, which predicts settlement of the options midway between the vesting term and the contractual term. The following table summarizes the assumptions used and the resulting grant-date fair values of our PSOs:

[0001327567-19-000032:notes:264]
|  | Year Ended July 31, |
|  | 2019 |  | 2018 |
| Volatility | 35.6% - 36.5% |  |  | 33.3 | % |
| Dividend yield | — | % |  | — | % |
| Risk-free interest rate | 3.1% - 3.2% |  |  | 2.9 | % |
| Weighted-average grant-date fair value per share | $ | 59.11 |  |  | $ | 56.14 |  |

[0001327567-19-000032:notes:265]
The expected volatility is based on a combination of implied volatility from traded options on our common stock and the historical volatility of our common stock. The dividend yield assumption is based on our current expectations about our anticipated dividend policy. The risk-free interest rate is based on the implied yield available on U.S. Treasury zero-coupon issues with terms equal to the contractual terms of each tranche.

[0001327567-19-000032:notes:266]
The fair value of shares issued under our 2012 ESPP are estimated on the grant date using the Black-Scholes option pricing model. The following table summarizes the assumptions used and the resulting grant-date fair values of our ESPP:

[0001327567-19-000032:notes:267]
|  | Year Ended July 31, |
|  | 2019 |  | 2018 |  | 2017 |
| Volatility | 30.0% - 34.5% |  |  | 26.8% - 43.6% |  |  | 41.0% - 50.1% |  |
| Expected term (in years) | 0.5 - 2.0 |  |  | 0.5 - 2.0 |  |  | 0.5 |  |
| Dividend yield | — | % |  | — | % |  | — | % |
| Risk-free interest rate | 2.3% - 2.6% |  |  | 1.2% - 2.3% |  |  | 0.5% - 0.9% |  |
| Grant-date fair value per share | $55.03 - $87.04 |  |  | $34.94 - $65.04 |  |  | $34.15 - $39.65 |  |

[0001327567-19-000032:notes:268]
The expected volatility is based on a combination of implied volatility from traded options on our common stock and the historical volatility of our common stock. The expected term represents the term from the first day of the offering period to the purchase dates within each offering period. The dividend yield assumption is based on our expectations about our anticipated dividend policy. The risk-free interest rate is based on the implied yield available on U.S. Treasury zero-coupon issues with maturities that approximate the expected term.

[0001327567-19-000032:notes:269]
The following table summarizes share-based compensation included in costs and expenses (in millions):

[0001327567-19-000032:notes:270]
|  | Year Ended July 31, |
|  | 2019 |  | 2018 |  | 2017 |
| Cost of product revenue | $ | 5.6 |  |  | $ | 7.0 |  |  | $ | 7.3 |  |
| Cost of subscription and support revenue | 71.3 |  |  | 66.7 |  |  | 56.2 |  |
| Research and development | 186.8 |  |  | 145.2 |  |  | 152.6 |  |
| Sales and marketing | 221.9 |  |  | 208.0 |  |  | 186.5 |  |
| General and administrative | 102.1 |  |  | 77.0 |  |  | 73.1 |  |
| Total share-based compensation | $ | 587.7 |  |  | $ | 503.9 |  |  | $ | 475.7 |  |

[0001327567-19-000032:notes:271]
During the year ended July 31, 2019, we accelerated the vesting of certain equity awards in connection with our acquisitions of RedLock and Twistlock and recorded $14.2 million and $5.8 million, respectively, of share-based compensation within general and administrative expense. During the year ended July 31, 2018, we paid $6.6 million in cash to settle certain Evident.io stock options, for which vesting was accelerated in connection with the acquisition and the subsequent termination of the option holders’ services. This amount was recorded as post-acquisition share-based compensation included in general and administrative expense.

[0001327567-19-000032:notes:272]
As of July 31, 2019, total compensation cost related to unvested share-based awards not yet recognized was $1.5 billion. This cost is expected to be amortized over a weighted-average period of approximately 2.7 years. Future grants will increase the amount of compensation expense to be recorded in these periods.


## us-gaap:EarningsPerShareTextBlock

[0001327567-19-000032:notes:273]
Net Loss Per Share

[0001327567-19-000032:notes:274]
Basic net loss per share is computed by dividing net loss by basic weighted-average shares outstanding during the period. Diluted net loss per share is computed by dividing net loss by diluted weighted-average shares outstanding, including potentially dilutive securities.

[0001327567-19-000032:notes:275]
The following table presents the computation of basic and diluted net loss per share of common stock (in millions, except per share data):

[0001327567-19-000032:notes:276]
|  | Year Ended July 31, |
|  | 2019 |  | 2018 |  | 2017 |
|  |  |  | (As Adjusted) |  | (As Adjusted) |
| Net loss | $ | (81.9 | ) |  | $ | (122.2 | ) |  | $ | (203.0 | ) |
| Weighted-average shares used to compute net loss per share, basic and diluted | 94.5 |  |  | 91.7 |  |  | 90.6 |  |
| Net loss per share, basic and diluted | $ | (0.87 | ) |  | $ | (1.33 | ) |  | $ | (2.24 | ) |

[0001327567-19-000032:notes:277]
The following securities were excluded from the computation of diluted net loss per share of common stock for the periods presented as their effect would have been antidilutive (in millions):

[0001327567-19-000032:notes:278]
|  | Year Ended July 31, |
|  | 2019 |  | 2018 |  | 2017 |
| Convertible senior notes | 6.4 |  |  | 11.6 |  |  | 5.2 |  |
| Warrants related to the issuance of convertible senior notes | 11.6 |  |  | 11.6 |  |  | 5.2 |  |
| RSUs and PSUs | 7.2 |  |  | 6.7 |  |  | 6.5 |  |
| Options to purchase common stock, including PSOs | 4.0 |  |  | 2.2 |  |  | 1.6 |  |
| RSAs and PSAs | 0.1 |  |  | 0.3 |  |  | 1.0 |  |
| ESPP shares | 0.2 |  |  | 0.2 |  |  | 0.2 |  |
| Total | 29.5 |  |  | 32.6 |  |  | 19.7 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001327567-19-000032:notes:279]
Fair Value Measurements

[0001327567-19-000032:notes:280]
We categorize assets and liabilities recorded or disclosed at fair value on our consolidated balance sheets based upon the level of judgment associated with inputs used to measure their fair value. The categories are as follows:

[0001327567-19-000032:notes:281]
| • | Level 1—Inputs are unadjusted quoted prices in active markets for identical assets or liabilities. |

[0001327567-19-000032:notes:282]
| • | Level 2—Inputs are quoted prices for similar assets and liabilities in active markets or inputs that are observable for the assets or liabilities, either directly or indirectly through market corroboration, for substantially the full term of the financial instruments. |

[0001327567-19-000032:notes:283]
| • | Level 3—Inputs are unobservable inputs based on our own assumptions used to measure assets and liabilities at fair value. The inputs require significant management judgment or estimation. |

[0001327567-19-000032:notes:284]
The following table presents the fair value of our financial assets and liabilities measured at fair value on a recurring basis using the above input categories as of July 31, 2019 and July 31, 2018 (in millions):

[0001327567-19-000032:notes:285]
|  |  | July 31, 2019 |  | July 31, 2018 |
|  |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Cash equivalents: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 369.1 |  |  | $ | — |  |  | $ | — |  |  | $ | 369.1 |  |  | $ | 1,512.3 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,512.3 |  |
| Certificates of deposit |  | — |  |  | 12.0 |  |  | — |  |  | 12.0 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Commercial paper |  | — |  |  | 19.3 |  |  | — |  |  | 19.3 |  |  | — |  |  | 52.0 |  |  | — |  |  | 52.0 |  |
| U.S. government and agency securities |  | — |  |  | 54.4 |  |  | — |  |  | 54.4 |  |  | — |  |  | 397.3 |  |  | — |  |  | 397.3 |  |
| Total cash equivalents |  | 369.1 |  |  | 85.7 |  |  | — |  |  | 454.8 |  |  | 1,512.3 |  |  | 449.3 |  |  | — |  |  | 1,961.6 |  |
| Short-term investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Certificates of deposit |  | — |  |  | 17.5 |  |  | — |  |  | 17.5 |  |  | — |  |  | 5.4 |  |  | — |  |  | 5.4 |  |
| Non-U.S. government securities |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 20.0 |  |  | — |  |  | 20.0 |  |
| Commercial paper |  | — |  |  | 8.9 |  |  | — |  |  | 8.9 |  |  | — |  |  | 22.3 |  |  | — |  |  | 22.3 |  |
| Corporate debt securities |  | — |  |  | 375.5 |  |  | — |  |  | 375.5 |  |  | — |  |  | 139.8 |  |  | — |  |  | 139.8 |  |
| U.S. government and agency securities |  | — |  |  | 1,439.8 |  |  | — |  |  | 1,439.8 |  |  | — |  |  | 709.0 |  |  | — |  |  | 709.0 |  |
| Total short-term investments |  | — |  |  | 1,841.7 |  |  | — |  |  | 1,841.7 |  |  | — |  |  | 896.5 |  |  | — |  |  | 896.5 |  |
| Long-term investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate debt securities |  | — |  |  | 214.3 |  |  | — |  |  | 214.3 |  |  | — |  |  | 153.6 |  |  | — |  |  | 153.6 |  |
| U.S. government and agency securities |  | — |  |  | 361.1 |  |  | — |  |  | 361.1 |  |  | — |  |  | 393.9 |  |  | — |  |  | 393.9 |  |
| Total long-term investments |  | — |  |  | 575.4 |  |  | — |  |  | 575.4 |  |  | — |  |  | 547.5 |  |  | — |  |  | 547.5 |  |
| Prepaid expenses and other current assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency forward contracts |  | — |  |  | 1.3 |  |  | — |  |  | 1.3 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Total prepaid expenses and other current assets |  | — |  |  | 1.3 |  |  | — |  |  | 1.3 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Total assets measured at fair value |  | $ | 369.1 |  |  | $ | 2,504.1 |  |  | $ | — |  |  | $ | 2,873.2 |  |  | $ | 1,512.3 |  |  | $ | 1,893.3 |  |  | $ | — |  |  | $ | 3,405.6 |  |
| Accrued and other liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency forward contracts |  | $ | — |  |  | $ | 3.8 |  |  | $ | — |  |  | $ | 3.8 |  |  | $ | — |  |  | $ | 6.9 |  |  | $ | — |  |  | $ | 6.9 |  |
| Total accrued and other liabilities |  | — |  |  | 3.8 |  |  | — |  |  | 3.8 |  |  | — |  |  | 6.9 |  |  | — |  |  | 6.9 |  |
| Total liabilities measured at fair value |  | $ | — |  |  | $ | 3.8 |  |  | $ | — |  |  | $ | 3.8 |  |  | $ | — |  |  | $ | 6.9 |  |  | $ | — |  |  | $ | 6.9 |  |

[0001327567-19-000032:notes:286]
Refer to Note 10. Convertible Senior Notes for the carrying amount and estimated fair value of our convertible senior notes as of July 31, 2019 and July 31, 2018.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001327567-19-000032:notes:287]
Goodwill and Intangible Assets

[0001327567-19-000032:notes:288]
Goodwill

[0001327567-19-000032:notes:289]
The following table presents details of our goodwill during the year ended July 31, 2019 (in millions):

[0001327567-19-000032:notes:290]
|  | Amount |
| Balance as of July 31, 2018 | $ | 522.8 |  |
| Goodwill acquired | 829.5 |  |
| Balance as of July 31, 2019 | $ | 1,352.3 |  |

[0001327567-19-000032:notes:291]
Through July 31, 2019, we have not recognized any impairment losses on our goodwill.

[0001327567-19-000032:notes:292]
Purchased Intangible Assets

[0001327567-19-000032:notes:293]
The following table presents details of our purchased intangible assets as of July 31, 2019 and July 31, 2018 (in millions):

[0001327567-19-000032:notes:294]
|  | July 31, |
|  | 2019 |  | 2018 |
|  | Gross Carrying Amount |  | Accumulated Amortization |  | Net Carrying Amount |  | Gross Carrying Amount |  | Accumulated Amortization |  | Net Carrying Amount |
| Intangible assets subject to amortization: |  |  |  |  |  |  |  |  |  |  |  |
| Developed technology | $ | 318.8 |  |  | $ | (78.7 | ) |  | $ | 240.1 |  |  | $ | 154.7 |  |  | $ | (38.2 | ) |  | $ | 116.5 |  |
| Customer relationships | 39.8 |  |  | (4.7 | ) |  | 35.1 |  |  | 12.2 |  |  | (1.2 | ) |  | 11.0 |  |
| Acquired intellectual property | 8.9 |  |  | (5.1 | ) |  | 3.8 |  |  | 8.9 |  |  | (4.5 | ) |  | 4.4 |  |
| Trade name and trademarks | 9.4 |  |  | (9.4 | ) |  | — |  |  | 8.5 |  |  | (0.4 | ) |  | 8.1 |  |
| Other | 2.2 |  |  | (2.2 | ) |  | — |  |  | 2.2 |  |  | (2.2 | ) |  | — |  |
| Total intangible assets subject to amortization | 379.1 |  |  | (100.1 | ) |  | 279.0 |  |  | 186.5 |  |  | (46.5 | ) |  | 140.0 |  |
| Intangible assets not subject to amortization: |  |  |  |  |  |  |  |  |  |  |  |
| In-process research and development | 1.6 |  |  | — |  |  | 1.6 |  |  | 0.8 |  |  | — |  |  | 0.8 |  |
| Total purchased intangible assets | $ | 380.7 |  |  | $ | (100.1 | ) |  | $ | 280.6 |  |  | $ | 187.3 |  |  | $ | (46.5 | ) |  | $ | 140.8 |  |

[0001327567-19-000032:notes:295]
We recognized amortization expense of $53.6 million, $16.3 million, and $9.8 million for the years ended July 31, 2019, 2018, and 2017, respectively.

[0001327567-19-000032:notes:296]
The following table summarizes estimated future amortization expense of our intangible assets as of July 31, 2019 (in millions):

[0001327567-19-000032:notes:297]
|  | Amount |
| Years ending July 31: |  |
| 2020 | $ | 66.1 |  |
| 2021 | 64.1 |  |
| 2022 | 59.6 |  |
| 2023 | 33.6 |  |
| 2024 | 26.1 |  |
| 2025 and thereafter | 29.5 |  |
| Total future amortization expense | $ | 279.0 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001327567-19-000032:notes:298]
The following table presents the components of income (loss) before income taxes (in millions):

[0001327567-19-000032:notes:299]
|  | Year Ended July 31, |
|  | 2019 |  | 2018 |  | 2017 |
|  |  |  | (As Adjusted) |  | (As Adjusted) |
| United States | $ | (198.1 | ) |  | $ | (181.1 | ) |  | $ | (205.8 | ) |
| Foreign | 123.5 |  |  | 75.8 |  |  | 25.7 |  |
| Total | $ | (74.6 | ) |  | $ | (105.3 | ) |  | $ | (180.1 | ) |

[0001327567-19-000032:notes:300]
The following table summarizes our provision for income taxes (in millions):

[0001327567-19-000032:notes:301]
|  | Year Ended July 31, |
|  | 2019 |  | 2018 |  | 2017 |
|  |  |  | (As Adjusted) |  | (As Adjusted) |
| Federal: |  |  |  |  |  |
| Current | $ | (1.3 | ) |  | $ | (0.6 | ) |  | $ | 3.4 |  |
| Deferred | (11.3 | ) |  | (3.3 | ) |  | — |  |
| State: |  |  |  |  |  |
| Current | (0.9 | ) |  | 1.6 |  |  | 0.9 |  |
| Deferred | (3.0 | ) |  | (1.3 | ) |  | — |  |
| Foreign: |  |  |  |  |  |
| Current | 27.5 |  |  | 23.3 |  |  | 19.7 |  |
| Deferred | (3.7 | ) |  | (2.8 | ) |  | (1.1 | ) |
| Total | $ | 7.3 |  |  | $ | 16.9 |  |  | $ | 22.9 |  |

[0001327567-19-000032:notes:302]
For the year ended July 31, 2019, our provision for income taxes decreased compared to the year ended July 31, 2018, primarily due to changes in our valuation allowance related to acquisitions completed during fiscal 2019 and our adoption of accounting guidance requiring the recognition of income tax consequences of an intra-entity transfer of an asset, other than inventory, when the transfer occurs. These decreases were partially offset by an increase in our foreign taxes due to growth in non-U.S. operations.

[0001327567-19-000032:notes:303]
For the year ended July 31, 2018, our provision for income taxes decreased compared to the year ended July 31, 2017, primarily due to changes in our valuation allowance related to our acquisition of Evident.io and future benefits from alternative minimum credits under the TCJA.

[0001327567-19-000032:notes:304]
In December 2017, the TCJA was enacted into law. The TCJA provided for significant tax law changes and modifications including, but not limited to, the reduction of the U.S. federal corporate statutory tax rate from 35% to 21% as of January 1, 2018, and the creation of new taxes on certain foreign-sourced earnings. The SEC staff and FASB previously issued guidance that allowed companies to record provisional amounts for the effects of the TCJA during a measurement period not to extend beyond one year from the enactment date. The measurement period ended in December 2018 and we completed our accounting for the income tax effects of the TCJA during the three months ended January 31, 2019. During the year ended July 31, 2019, we did not have any significant adjustments to provisional estimates recorded in previous periods.

[0001327567-19-000032:notes:305]
The following table presents the items accounting for the difference between income taxes computed at the federal statutory income tax rate and our provision for income taxes:

[0001327567-19-000032:notes:306]
|  | Year Ended July 31, |
|  | 2019 |  | 2018 |  | 2017 |
|  |  |  | (As Adjusted) |  | (As Adjusted) |
| Federal statutory rate | 21.0 | % |  | 26.8 | % |  | 35.0 | % |
| Effect of: |  |  |  |  |  |
| State taxes, net of federal tax benefit | 7.9 |  |  | 5.7 |  |  | 3.2 |  |
| Effects of non-U.S. operations | 89.3 |  |  | 19.9 |  |  | (15.3 | ) |
| Change in valuation allowance | (196.9 | ) |  | 39.2 |  |  | (40.3 | ) |
| Effect of U.S. tax law change | 0.6 |  |  | (129.3 | ) |  | — |  |
| Share-based compensation | 44.9 |  |  | 10.6 |  |  | 1.7 |  |
| Amortization of deferred tax charges | — |  |  | (8.0 | ) |  | (3.9 | ) |
| Research credits | 35.0 |  |  | 31.4 |  |  | 10.9 |  |
| Non-deductible expenses | (11.5 | ) |  | (6.1 | ) |  | (3.2 | ) |
| Other, net | (0.1 | ) |  | (6.2 | ) |  | (0.8 | ) |
| Total | (9.8 | )% |  | (16.0 | )% |  | (12.7 | )% |

[0001327567-19-000032:notes:307]
As a result of the TCJA, our federal statutory tax rate for the fiscal year ended July 31, 2018 was 26.8% based on a blend of the statutory rates for 2017 and 2018. Further, we have reflected an adjustment to deferred taxes as a result of the TCJA, which is fully offset by changes in our valuation allowance.

[0001327567-19-000032:notes:308]
The following table presents the components of our deferred tax assets and liabilities as of July 31, 2019 and July 31, 2018 (in millions):

[0001327567-19-000032:notes:309]
|  | July 31, |
|  | 2019 |  | 2018 |
|  |  |  | (As Adjusted) |
| Deferred tax assets: |  |  |  |
| Accruals and reserves | $ | 53.3 |  |  | $ | 59.6 |  |
| Deferred revenue | 212.8 |  |  | 128.0 |  |
| Net operating loss carryforwards | 269.9 |  |  | 189.5 |  |
| Research and development and foreign tax credits | 143.3 |  |  | 113.4 |  |
| Share-based compensation | 25.9 |  |  | 21.4 |  |
| Gross deferred tax assets | 705.2 |  |  | 511.9 |  |
| Valuation allowance | (561.9 | ) |  | (388.0 | ) |
| Total deferred tax assets | 143.3 |  |  | 123.9 |  |
| Deferred tax liabilities: |  |  |  |
| Fixed assets and intangible assets | (26.0 | ) |  | (43.3 | ) |
| Deferred commissions | (94.6 | ) |  | (54.4 | ) |
| Other deferred tax liabilities | (15.7 | ) |  | (17.7 | ) |
| Total deferred tax liabilities | (136.3 | ) |  | (115.4 | ) |
| Total | $ | 7.0 |  |  | $ | 8.5 |  |

[0001327567-19-000032:notes:310]
On January 22, 2018, the FASB released guidance on the accounting for tax on the global intangible low-taxed income (“GILTI”) provisions of the TCJA. The GILTI provisions impose a tax on foreign income in excess of a deemed return on tangible assets of foreign corporations. We have elected to provide for deferred taxes for potential GILTI obligations. Deferred tax assets relating to our GILTI obligations have been properly reflected above with an offsetting valuation allowance as appropriate.

[0001327567-19-000032:notes:311]
As a result of the TCJA, we have reflected an adjustment to deferred tax assets during the year ended July 31, 2018, which was fully offset by changes in our valuation allowance.

[0001327567-19-000032:notes:312]
A valuation allowance is provided when it is more likely than not that the deferred tax asset will not be realized. Realization of deferred tax assets is dependent upon future taxable income, if any, the amount and timing of which are uncertain. At such time, if it is determined that it is more likely than not that the deferred tax assets are realizable, the valuation allowance will be adjusted. As of July 31, 2019, we have provided a valuation allowance for our federal, state, and certain foreign deferred tax assets that we believe will, more likely than not, be unrealizable. The net valuation allowance increased by $173.9 million from the year ended July 31, 2018 to the year ended July 31, 2019, primarily due to increases in our U.S. net operating losses and deferred revenue.

[0001327567-19-000032:notes:313]
As of July 31, 2019, we had federal, state, and foreign NOL carryforwards of approximately $1.6 billion, $775.6 million, and $111.6 million, respectively, as reported on our tax returns, available to reduce future taxable income, if any. If not utilized, our federal and state NOL carryforwards will expire in various amounts at various dates beginning in the years ending July 31, 2027 and July 31, 2019, respectively. Our foreign NOL will carry forward indefinitely.

[0001327567-19-000032:notes:314]
As of July 31, 2019, we had federal and state research and development tax credit carryforwards of approximately $92.1 million and $81.2 million, respectively, as reported on our tax returns. If not utilized, the federal credit carryforwards will expire in various amounts at various dates beginning in the year ending July 31, 2026. The state credit will carry forward indefinitely.

[0001327567-19-000032:notes:315]
As of July 31, 2019, we had foreign tax credit carryforwards of $5.4 million as reported on our tax returns. If not utilized, the foreign tax credit carryforwards will expire in various amounts at various dates beginning in the year ending July 31, 2021.

[0001327567-19-000032:notes:316]
Utilization of the NOL carryforwards and credits may be subject to a substantial annual limitation due to the ownership change limitations provided by the Internal Revenue Code of 1986, as amended, and similar state provisions. The annual limitation may result in the expiration of NOLs and credits before utilization.

[0001327567-19-000032:notes:317]
During the year ended July 31, 2017, we were awarded a tax incentive by a foreign jurisdiction. The incentive is effective through September 30, 2031, and is conditional upon meeting certain investment and employment thresholds. The impact of this incentive on our provision for income taxes was not material for the years ended July 31, 2019, 2018, and 2017.

[0001327567-19-000032:notes:318]
As of July 31, 2019, we had $314.5 million of unrecognized tax benefits, $68.0 million of which would affect income tax expense if recognized, after consideration of our valuation allowance in the United States and other assets. As of July 31, 2018, we had $337.7 million of unrecognized tax benefits, $48.0 million of which would affect income tax expense if recognized, after consideration of our valuation allowance in the United States and other assets. As of July 31, 2019, our federal, state, and foreign returns for the tax years 2008 through the current period remain subject to adjustment due to examination. Fiscal years outside the normal statute of limitation remain open to audit by tax authorities due to tax attributes generated in earlier years, which have been carried forward and may be audited in subsequent years when utilized. We do not expect the amount of unrecognized tax benefits as of July 31, 2019 to change significantly over the next 12 months. We recognize both interest and penalties associated with uncertain tax positions as a component of income tax expense. During the years ended July 31, 2019, 2018, and 2017, we recognized income tax expense related to interest and penalties of $2.3 million, $2.9 million, and $2.1 million, respectively. We had accrued interest and penalties on our consolidated balance sheets related to unrecognized tax benefits of $10.6 million and $8.3 million as of July 31, 2019 and 2018, respectively. The ultimate amount and timing of any future cash settlements cannot be predicted with reasonable certainty.

[0001327567-19-000032:notes:319]
The following table presents a reconciliation of the beginning and ending amount of our gross unrecognized tax benefits (in millions):

[0001327567-19-000032:notes:320]
|  | Year Ended July 31, |
|  | 2019 |  | 2018 |  | 2017 |
| Unrecognized tax benefits at the beginning of the period | $ | 337.7 |  |  | $ | 301.3 |  |  | $ | 127.7 |  |
| Additions for tax positions taken in prior years | 0.3 |  |  | 3.1 |  |  | 3.1 |  |
| Reductions for tax positions taken in prior years | (33.4 | ) |  | (6.3 | ) |  | — |  |
| Additions for tax positions taken in the current year | 9.9 |  |  | 39.6 |  |  | 170.5 |  |
| Unrecognized tax benefits at the end of the period | $ | 314.5 |  |  | $ | 337.7 |  |  | $ | 301.3 |  |

[0001327567-19-000032:notes:321]
During the year ended July 31, 2019, our additions for tax positions taken in the current year were primarily attributable to intercompany transactions.

[0001327567-19-000032:notes:322]
During the year ended July 31, 2018, our additions for tax positions taken in the current year were primarily attributable to uncertain tax positions related to federal and state research and development credits, withholding taxes, and intercompany transactions.

[0001327567-19-000032:notes:323]
During the year ended July 31, 2017, our additions for tax positions taken in the current year were primarily attributable to uncertainties related to intercompany transactions.

[0001327567-19-000032:notes:324]
As of July 31, 2019, we had no unremitted earnings when evaluating our outside basis difference relating to our U.S. investment in foreign subsidiaries. However, there could be local withholding taxes payable due to various foreign countries if certain lower tier earnings are distributed. Withholding taxes that would be payable upon remittance of these lower tier earnings are not expected to be material.


## us-gaap:InvestmentsClassifiedByContractualMaturityDateTableTextBlock

[0001327567-19-000032:notes:325]
The following table summarizes the amortized cost and fair value of our available-for-sale debt securities as of July 31, 2019, by contractual years-to-maturity (in millions):

[0001327567-19-000032:notes:326]
|  | Amortized Cost |  | Fair Value |
| Due within one year | $ | 1,926.7 |  |  | $ | 1,927.4 |  |
| Due between one and three years | 572.7 |  |  | 575.4 |  |
| Total | $ | 2,499.4 |  |  | $ | 2,502.8 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001327567-19-000032:notes:327]
Cash Equivalents and Investments

[0001327567-19-000032:notes:328]
Available-for-sale Debt Securities

[0001327567-19-000032:notes:329]
Unrealized losses related to these securities are due to interest rate fluctuations as opposed to credit quality. In addition, we do not intend to sell and it is not likely that we would be required to sell these securities before recovery of their amortized cost basis, which may be at maturity. As a result, there were no other-than-temporary impairments for these securities at July 31, 2019 and 2018.

[0001327567-19-000032:notes:330]
Marketable Equity Securities

[0001327567-19-000032:notes:331]
Marketable equity securities consist of money market funds and are included in cash and cash equivalents in our consolidated balance sheets. As of July 31, 2019 and 2018, the carrying value of our marketable equity securities were $369.1 million and $1.5 billion, respectively. There were no unrealized gains or losses recognized for these securities during the years ended July 31, 2019, 2018, and 2017.


## us-gaap:LongLivedAssetsByGeographicAreasTableTextBlock

[0001327567-19-000032:notes:332]
The following table presents our property and equipment, net by geographic region (in millions):

[0001327567-19-000032:notes:333]
|  | Year Ended July 31, |
|  | 2019 |  | 2018 |
| Property and equipment, net: |  |  |  |
| United States | $ | 240.5 |  |  | $ | 228.4 |  |
| International | 55.5 |  |  | 44.7 |  |
| Total property and equipment, net | $ | 296.0 |  |  | $ | 273.1 |  |


## us-gaap:OtherNonoperatingIncomeAndExpenseTextBlock

[0001327567-19-000032:notes:334]
Other Income, Net

[0001327567-19-000032:notes:335]
The following table sets forth the components of other income, net (in millions):

[0001327567-19-000032:notes:336]
|  | Year Ended July 31, |
|  | 2019 |  | 2018 |  | 2017 |
| Interest income | $ | 69.8 |  |  | $ | 27.1 |  |  | $ | 14.7 |  |
| Foreign currency exchange gains (losses), net | (3.5 | ) |  | 1.7 |  |  | (3.4 | ) |
| Other | (2.9 | ) |  | (0.3 | ) |  | (1.1 | ) |
| Total other income, net | $ | 63.4 |  |  | $ | 28.5 |  |  | $ | 10.2 |  |


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001327567-19-000032:notes:337]
The following table presents details of our property and equipment, net as of July 31, 2019 and July 31, 2018 (in millions):

[0001327567-19-000032:notes:338]
|  | July 31, |
|  | 2019 |  | 2018 |
| Computers, equipment, and software | $ | 264.1 |  |  | $ | 217.9 |  |
| Leasehold improvements | 204.8 |  |  | 159.5 |  |
| Demonstration units | 40.7 |  |  | 33.0 |  |
| Furniture and fixtures | 30.6 |  |  | 24.6 |  |
| Total property and equipment | 540.2 |  |  | 435.0 |  |
| Less: accumulated depreciation | (244.2 | ) |  | (161.9 | ) |
| Total property and equipment, net | $ | 296.0 |  |  | $ | 273.1 |  |

[0001327567-19-000032:notes:339]
We recognized depreciation expense of $86.2 million, $74.7 million, and $48.6 million related to property and equipment during the years ended July 31, 2019, 2018, and 2017, respectively.


## us-gaap:QuarterlyFinancialInformationTextBlock

[0001327567-19-000032:notes:340]
Selected Quarterly Financial Data (Unaudited)

[0001327567-19-000032:notes:341]
The following tables set forth selected unaudited quarterly financial data for the years ended July 31, 2019 and 2018 (in millions, except per share amounts):

[0001327567-19-000032:notes:342]
|  | Three Months Ended |
|  | October 31,2018 |  | January 31,2019 |  | April 30,2019 |  | July 31,2019 |
| Revenue: |  |  |  |  |  |  |  |
| Product | $ | 240.5 |  |  | $ | 271.6 |  |  | $ | 278.4 |  |  | $ | 305.7 |  |
| Subscription and support | 415.5 |  |  | 439.6 |  |  | 448.2 |  |  | 500.1 |  |
| Total revenue | 656.0 |  |  | 711.2 |  |  | 726.6 |  |  | 805.8 |  |
| Cost of revenue: |  |  |  |  |  |  |  |
| Product | 73.2 |  |  | 82.5 |  |  | 78.0 |  |  | 82.2 |  |
| Subscription and support | 110.3 |  |  | 120.1 |  |  | 126.9 |  |  | 135.2 |  |
| Total cost of revenue | 183.5 |  |  | 202.6 |  |  | 204.9 |  |  | 217.4 |  |
| Total gross profit | 472.5 |  |  | 508.6 |  |  | 521.7 |  |  | 588.4 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 113.4 |  |  | 128.3 |  |  | 139.1 |  |  | 158.7 |  |
| Sales and marketing | 314.6 |  |  | 320.0 |  |  | 339.0 |  |  | 370.4 |  |
| General and administrative | 76.6 |  |  | 53.7 |  |  | 62.3 |  |  | 69.2 |  |
| Total operating expenses | 504.6 |  |  | 502.0 |  |  | 540.4 |  |  | 598.3 |  |
| Operating income (loss) | (32.1 | ) |  | 6.6 |  |  | (18.7 | ) |  | (9.9 | ) |
| Interest expense | (22.7 | ) |  | (20.6 | ) |  | (20.6 | ) |  | (20.0 | ) |
| Other income, net | 13.0 |  |  | 16.0 |  |  | 18.2 |  |  | 16.2 |  |
| Income (loss) before income taxes | (41.8 | ) |  | 2.0 |  |  | (21.1 | ) |  | (13.7 | ) |
| Provision for (benefit from) income taxes | (3.5 | ) |  | 4.6 |  |  | (0.9 | ) |  | 7.1 |  |
| Net loss | $ | (38.3 | ) |  | $ | (2.6 | ) |  | $ | (20.2 | ) |  | $ | (20.8 | ) |
| Net loss per share, basic and diluted | $ | (0.41 | ) |  | $ | (0.03 | ) |  | $ | (0.21 | ) |  | $ | (0.22 | ) |

[0001327567-19-000032:notes:343]
|  | Three Months Ended |
|  | October 31,2017 |  | January 31,2018 |  | April 30,2018 |  | July 31,2018 |
|  | (As Adjusted) |  | (As Adjusted) |  | (As Adjusted) |  | (As Adjusted) |
| Revenue: |  |  |  |  |  |  |  |
| Product | $ | 184.8 |  |  | $ | 204.8 |  |  | $ | 218.1 |  |  | $ | 272.1 |  |
| Subscription and support | 317.0 |  |  | 340.8 |  |  | 349.6 |  |  | 386.4 |  |
| Total revenue | 501.8 |  |  | 545.6 |  |  | 567.7 |  |  | 658.5 |  |
| Cost of revenue: |  |  |  |  |  |  |  |
| Product | 57.6 |  |  | 63.9 |  |  | 68.9 |  |  | 82.0 |  |
| Subscription and support | 83.7 |  |  | 95.5 |  |  | 91.0 |  |  | 102.5 |  |
| Total cost of revenue | 141.3 |  |  | 159.4 |  |  | 159.9 |  |  | 184.5 |  |
| Total gross profit | 360.5 |  |  | 386.2 |  |  | 407.8 |  |  | 474.0 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 94.2 |  |  | 96.6 |  |  | 99.6 |  |  | 110.3 |  |
| Sales and marketing | 254.1 |  |  | 258.8 |  |  | 271.4 |  |  | 289.9 |  |
| General and administrative | 65.7 |  |  | 53.3 |  |  | 82.1 |  |  | 56.7 |  |
| Total operating expenses | 414.0 |  |  | 408.7 |  |  | 453.1 |  |  | 456.9 |  |
| Operating income (loss) | (53.5 | ) |  | (22.5 | ) |  | (45.3 | ) |  | 17.1 |  |
| Interest expense | (6.3 | ) |  | (6.4 | ) |  | (6.5 | ) |  | (10.4 | ) |
| Other income, net | 4.8 |  |  | 4.9 |  |  | 8.6 |  |  | 10.2 |  |
| Income (loss) before income taxes | (55.0 | ) |  | (24.0 | ) |  | (43.2 | ) |  | 16.9 |  |
| Provision for (benefit from) income taxes | 8.2 |  |  | 1.6 |  |  | (2.8 | ) |  | 9.9 |  |
| Net income (loss) | $ | (63.2 | ) |  | $ | (25.6 | ) |  | $ | (40.4 | ) |  | $ | 7.0 |  |
| Net income (loss) per share, basic | $ | (0.70 | ) |  | $ | (0.28 | ) |  | $ | (0.44 | ) |  | $ | 0.08 |  |
| Net income (loss) per share, diluted | $ | (0.70 | ) |  | $ | (0.28 | ) |  | $ | (0.44 | ) |  | $ | 0.07 |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001327567-19-000032:notes:344]
Related Party Transactions

[0001327567-19-000032:notes:345]
Certain members of our board of directors are affiliated with Greylock Partners (“Greylock”), a venture capital firm. Entities affiliated with Greylock owned a portion of the outstanding shares of Demisto immediately prior to completion of our acquisition of Demisto on March 28, 2019 and, as a result, received purchase consideration valued at $85.6 million during the year ended July 31, 2019. Refer to Note 6. Acquisitions for more information on our acquisition of Demisto.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001327567-19-000032:notes:346]
Revenue

[0001327567-19-000032:notes:347]
Disaggregation of Revenue

[0001327567-19-000032:notes:348]
The following table presents revenue by geographic theater (in millions):

[0001327567-19-000032:notes:349]
|  | Years Ended July 31, |
|  | 2019 |  | 2018 |  | 2017 |
|  |  |  | (As Adjusted) |  | (As Adjusted) |
| Revenue: |  |  |  |  |  |
| Americas |  |  |  |  |  |
| United States | $ | 1,830.3 |  |  | $ | 1,446.7 |  |  | $ | 1,149.7 |  |
| Other Americas | 152.0 |  |  | 112.0 |  |  | 80.9 |  |
| Total Americas | 1,982.3 |  |  | 1,558.7 |  |  | 1,230.6 |  |
| Europe, the Middle East, and Africa (“EMEA”) | 564.8 |  |  | 439.6 |  |  | 320.3 |  |
| Asia Pacific and Japan (“APAC”) | 352.5 |  |  | 275.3 |  |  | 204.2 |  |
| Total revenue | $ | 2,899.6 |  |  | $ | 2,273.6 |  |  | $ | 1,755.1 |  |

[0001327567-19-000032:notes:350]
The following table presents revenue for groups of similar products and services (in millions):

[0001327567-19-000032:notes:351]
|  | Years Ended July 31, |
|  | 2019 |  | 2018 |  | 2017 |
|  |  |  | (As Adjusted) |  | (As Adjusted) |
| Revenue: |  |  |  |  |  |
| Product | $ | 1,096.2 |  |  | $ | 879.8 |  |  | $ | 708.5 |  |
| Subscription and support |  |  |  |  |  |
| Subscription | 1,032.7 |  |  | 758.1 |  |  | 548.8 |  |
| Support | 770.7 |  |  | 635.7 |  |  | 497.8 |  |
| Total subscription and support | 1,803.4 |  |  | 1,393.8 |  |  | 1,046.6 |  |
| Total revenue | $ | 2,899.6 |  |  | $ | 2,273.6 |  |  | $ | 1,755.1 |  |

[0001327567-19-000032:notes:352]
During the year ended July 31, 2019, we recognized approximately $1.2 billion of revenue pertaining to amounts that were deferred as of July 31, 2018.

[0001327567-19-000032:notes:353]
Remaining Performance Obligations

[0001327567-19-000032:notes:354]
Revenue expected to be recognized from remaining performance obligations was $3.1 billion as of July 31, 2019, of which we expect to recognize approximately $1.7 billion over the next 12 months and the remainder thereafter.

[0001327567-19-000032:notes:355]
We recognized amortization expense for our deferred contract costs of $223.8 million, $149.8 million, and $107.4 million during the years ended July 31, 2019, 2018, and 2017, respectively. We did not recognize any impairment losses on our deferred contract costs during the years ended July 31, 2019, 2018, or 2017.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001327567-19-000032:notes:356]
Segment Information

[0001327567-19-000032:notes:357]
We conduct business globally and are primarily managed on a geographic theater basis. Our chief operating decision maker reviews financial information presented on a consolidated basis accompanied by information about revenue by geographic region for purposes of allocating resources and evaluating financial performance. We have one business activity and there are no segment managers who are held accountable for operations, operating results, and plans for levels, components, or types of products or services below the consolidated unit level. Accordingly, we are considered to be in a single reportable segment and operating unit structure.

[0001327567-19-000032:notes:358]
Refer to Note 2. Revenue for revenue by geographic theater and revenue for groups of similar products and services for the years ended July 31, 2019, 2018, and 2017.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001327567-19-000032:notes:359]
Stockholders’ Equity

[0001327567-19-000032:notes:360]
Share Repurchase Program

[0001327567-19-000032:notes:361]
In August 2016, our board of directors authorized a $500.0 million share repurchase program to be funded from available working capital. In February 2017, our board of directors authorized a $500.0 million increase to our repurchase program, bringing the total authorization to $1.0 billion (our “original authorization”). Repurchases could be made at management’s discretion from time to time on the open market, through privately negotiated transactions, transactions structured through investment banking institutions, block purchase techniques, 10b5-1 trading plans, or a combination of the foregoing. During the years ended July 31, 2019, 2018, and 2017, we repurchased and retired 1.9 million shares, 1.7 million shares, and 3.3 million shares, respectively, of our common stock under our original authorization for an aggregate purchase price of $330.0 million, $250.0 million, and $420.1 million, respectively, including transaction costs. The total price of the shares repurchased and related transaction costs are reflected as a reduction to common stock and additional paid-in capital on our consolidated balance sheets. This repurchase program expired on December 31, 2018.

[0001327567-19-000032:notes:362]
In February 2019, our board of directors authorized a new $1.0 billion share repurchase program which will be funded from available working capital (our “current authorization”). Repurchases may be made at management’s discretion from time to time on the open market, through privately negotiated transactions, transactions structured through investment banking institutions, block purchase techniques, 10b5-1 trading plans, or a combination of the foregoing. This repurchase program will expire on December 31, 2020, and may be suspended or discontinued at any time. As of July 31, 2019, $1.0 billion remained available for future share repurchases under our current authorization.


## us-gaap:SubsequentEventsTextBlock

[0001327567-19-000032:notes:363]
Subsequent Event

[0001327567-19-000032:notes:364]
Business Combination

[0001327567-19-000032:notes:365]
In September 2019, we entered into a definitive agreement to acquire Zingbox, Inc. (“Zingbox”), a privately-held Internet of Things (“IoT”) security company, in exchange for total consideration of approximately $75.0 million in cash, subject to adjustment. We expect the acquisition will expand the functionality of our platform with the addition of Zingbox’s cloud-based service and advanced AI and machine learning technology for device and threat identification capabilities. The acquisition is expected to close during our first quarter of fiscal 2020.
