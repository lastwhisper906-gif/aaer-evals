# PANW MD&A — 0001327567-19-000032


## mdna

[0001327567-19-000032:mdna:1]
| ITEM 7. | MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS |

[0001327567-19-000032:mdna:2]
The following discussion and analysis of our financial condition and results of operations should be read in conjunction with our consolidated financial statements and related notes appearing elsewhere in this Annual Report on Form 10-K. The following discussion and analysis contains forward-looking statements based on current expectations and assumptions that are subject to risks and uncertainties, which could cause our actual results to differ materially from those anticipated or implied by any forward-looking statements. Factors that could cause or contribute to such differences include, but are not limited to, those discussed in this Annual Report on Form 10-K, and in particular, the risks discussed under the caption “Risk Factors” in Part I, Item 1A of this report.

[0001327567-19-000032:mdna:3]
Our Management’s Discussion and Analysis of Financial Condition and Results of Operations (“MD&A”) is organized as follows:

[0001327567-19-000032:mdna:4]
| • | Overview. A discussion of our business and overall analysis of financial and other highlights in order to provide context for the remainder of MD&A. |

[0001327567-19-000032:mdna:5]
| • | Key Financial Metrics. A summary of our GAAP and non-GAAP key financial metrics, which management monitors to evaluate our performance. |

[0001327567-19-000032:mdna:6]
| • | Results of Operations. A discussion of the nature and trends in our financial results and an analysis of our financial results comparing fiscal 2019 to 2018 and fiscal 2018 to 2017. |

[0001327567-19-000032:mdna:7]
| • | Liquidity and Capital Resources. An analysis of changes in our balance sheets and cash flows, and a discussion of our financial condition and our ability to meet cash needs. |

[0001327567-19-000032:mdna:8]
| • | Contractual Obligations and Commitments. An overview of our contractual obligations, contingent liabilities, commitments, and off-balance sheet arrangements outstanding as of July 31, 2019, including expected payment schedules. |

[0001327567-19-000032:mdna:9]
| • | Critical Accounting Estimates. A discussion of our accounting policies that require critical estimates, assumptions, and judgments. |

[0001327567-19-000032:mdna:10]
| • | Recent Accounting Pronouncements. A discussion of expected impacts of impending accounting changes on financial information to be reported in the future. |

[0001327567-19-000032:mdna:11]
Overview

[0001327567-19-000032:mdna:12]
We have pioneered the next generation of security through our innovative platform that empowers enterprises, service providers, and government entities to secure their organizations by safely enabling applications and data running in their networks, on their endpoints, and in the cloud, and by preventing breaches that stem from targeted cyberattacks. Our platform uses an innovative traffic classification engine that identifies network traffic by application, user, and content and provides consistent security across the network, endpoint, and cloud. Accordingly, our platform enables our end-customers to pursue transformative digital initiatives, like public cloud and mobility, that grow their business, while maintaining the visibility and control needed to protect their valued data and critical control systems. We believe the architecture of our platform offers superior performance compared to legacy approaches and reduces the total cost of ownership for organizations by simplifying their security operations and infrastructure and eliminating the need for multiple, stand-alone hardware and software security products, and consists of three primary areas of security capabilities.

[0001327567-19-000032:mdna:13]
Secure the Enterprise:

[0001327567-19-000032:mdna:14]
| • | Secure the network through our Next-Generation Firewalls, available as physical appliances, virtual appliances called VM-Series, or a cloud-delivered service called Prisma Access (formerly GlobalProtect cloud service), and Panorama management delivered as an appliance or as a virtual machine for the public or private cloud. This also includes security services such as WildFire, Threat Prevention, URL Filtering, GlobalProtect, and DNS Security that are delivered as SaaS subscriptions to our Next-Generation Firewalls. |

[0001327567-19-000032:mdna:15]
| • | Secure the endpoints through our Traps advanced endpoint protection software, delivered as a light-weight software agent with cloud or on-premise management capabilities. |

[0001327567-19-000032:mdna:16]
Secure the Cloud:

[0001327567-19-000032:mdna:17]
| • | Secure the cloud through our Prisma cloud security offerings, such as Prisma Public Cloud (formerly RedLock) for security and compliance in public clouds, Prisma Access (formerly GlobalProtect cloud service) for securing user access, Prisma SaaS (formerly Aperture) for protecting SaaS applications, VM-Series for in-line network security in public and private clouds, Traps for host-based public cloud infrastructure protection, and Twistlock for protecting containers in public and private clouds, as well as PureSec for protecting serverless functions in public clouds. |

[0001327567-19-000032:mdna:18]
- 38 -

[0001327567-19-000032:mdna:19]
Secure the Future:

[0001327567-19-000032:mdna:20]
| • | Secure the future of security operations through our Cortex platform, which includes Cortex XDR (formerly Magnifier) for detection and response, Cortex Data Lake (formerly Logging Service) to collect and integrate security data for analytics, Demisto for security orchestration, automation, and response (“SOAR”), and AutoFocus for threat intelligence. These products are delivered as software or SaaS subscriptions. |

[0001327567-19-000032:mdna:21]
For fiscal 2019, 2018, and 2017, total revenue was $2.9 billion, $2.3 billion, and $1.8 billion, respectively, representing year-over-year growth of 27.5% for fiscal 2019 and 29.5% for fiscal 2018. Our growth reflects the increased adoption of our hybrid SaaS revenue model, which consists of product, subscriptions, and support. We believe this model will enable us to benefit from recurring revenues as we continue to grow our installed end-customer base. As of July 31, 2019, we had end-customers in over 150 countries. Our end-customers represent a broad range of industries including education, energy, financial services, government entities, healthcare, Internet and media, manufacturing, public sector, and telecommunications, and include some of the largest Fortune 100 and Global 2000 companies in the world. We maintain a field sales force that works closely with our channel partners in developing sales opportunities. We use a two-tiered, indirect fulfillment model whereby we sell our products, subscriptions, and support to our distributors, which, in turn, sell to our resellers, which then sell to our end-customers.

[0001327567-19-000032:mdna:22]
Our product revenue grew to $1.1 billion or 37.8% of total revenue for fiscal 2019, representing year-over-year growth of 24.6%. Product revenue is generated from sales of our appliances, primarily our Next-Generation Firewall, which is available in physical and virtualized form. Our Next-Generation Firewall incorporates our proprietary PAN-OS operating system, which provides a consistent set of capabilities across our entire product line. Our products are designed for different performance requirements throughout an organization, ranging from our PA-220, which is designed for small organizations and remote or branch offices, to our top-of-the-line PA-7080, which is especially suited for very large enterprise deployments and service provider customers. The same firewall functionality that is delivered in our physical appliances is also available in our VM-Series virtual firewalls, which secure virtualized and cloud-based computing environments.

[0001327567-19-000032:mdna:23]
Our subscription and support revenue grew to $1.8 billion or 62.2% of total revenue for fiscal 2019, representing year-over-year growth of 29.4%. Our subscriptions provide our end-customers with real-time access to the latest antivirus, intrusion prevention, web filtering, and modern malware prevention capabilities across the network, endpoints, and the cloud. When end-customers purchase our physical or virtual firewall appliances, they typically purchase support in order to receive ongoing security updates, upgrades, bug fixes, and repairs. In addition to the subscriptions purchased with these appliances, end-customers may also purchase other subscriptions on a per-user, per-endpoint, or capacity-based basis.

[0001327567-19-000032:mdna:24]
We continue to invest in innovation as we evolve and further extend the capabilities of our platform, as we believe that innovation and timely development of new features and products is essential to meeting the needs of our end-customers and improving our competitive position. For example: in October 2018, we acquired RedLock, which expanded our security capabilities for the public cloud with the addition of RedLock’s cloud security analytics technology; in February 2019, we introduced PAN-OS 9.0, with over 60 new features, our new DNS Security Service subscription, which uses machine learning to proactively block malicious domains and stop attacks in progress, and Cortex XDR, our cloud-based detection, investigation, and response application that natively integrates network, endpoint, and cloud data; in March 2019, we acquired Demisto, which expanded the functionality of our platform with the addition of Demisto’s SOAR product; and in June and July 2019, we acquired PureSec and Twistlock, respectively, which extend our Prisma cloud security strategy with the addition of PureSec’s security for serverless applications and Twistlock’s container security capabilities.

[0001327567-19-000032:mdna:25]
We believe that the growth of our business and our short-term and long-term success are dependent upon many factors, including our ability to extend our technology leadership, grow our base of end-customers, expand deployment of our platform and support offerings within existing end-customers, and focus on end-customer satisfaction. To manage any future growth effectively, we must continue to improve and expand our information technology and financial infrastructure, our operating and administrative systems and controls, and our ability to manage headcount, capital, and processes in an efficient manner. While these areas present significant opportunities for us, they also pose challenges and risks that we must successfully address in order to sustain the growth of our business and improve our operating results. For additional information regarding the challenges and risks we face, see the “Risk Factors” section in Part I, Item 1A of this Annual Report on Form 10-K.

[0001327567-19-000032:mdna:26]
- 39 -

[0001327567-19-000032:mdna:27]
Key Financial Metrics

[0001327567-19-000032:mdna:28]
We monitor the key financial metrics set forth in the tables below to help us evaluate growth trends, establish budgets, measure the effectiveness of our sales and marketing efforts, and assess operational efficiencies. We discuss revenue, gross margin, and the components of operating loss and margin below under “—Results of Operations.”

[0001327567-19-000032:mdna:29]
|  | July 31, |
|  | 2019 |  | 2018 |
|  | (in millions) |
| Total deferred revenue(1) | $ | 2,888.7 |  |  | $ | 2,279.3 |  |
| Cash, cash equivalents, and investments | $ | 3,378.5 |  |  | $ | 3,950.9 |  |

[0001327567-19-000032:mdna:30]
______________

[0001327567-19-000032:mdna:31]
| (1) | The amount for fiscal 2018 has been adjusted due to our adoption of the new revenue recognition standard. Refer to Note 1. Description of Business and Summary of Significant Accounting Policies in Part II, Item 8 of this Annual Report on Form 10-K for more information. |

[0001327567-19-000032:mdna:32]
|  | Year Ended July 31, |
|  | 2019 |  | 2018(1) |  | 2017(1) |
|  | (dollars in millions) |
| Total revenue | $ | 2,899.6 |  |  | $ | 2,273.6 |  |  | $ | 1,755.1 |  |
| Total revenue year-over-year percentage increase | 27.5 | % |  | 29.5 | % |  | 27.3 | % |
| Gross margin | 72.1 | % |  | 71.6 | % |  | 72.9 | % |
| Operating loss | $ | (54.1 | ) |  | $ | (104.2 | ) |  | $ | (165.8 | ) |
| Operating margin | (1.9 | )% |  | (4.6 | )% |  | (9.4 | )% |
| Billings | $ | 3,489.8 |  |  | $ | 2,856.2 |  |  | $ | 2,251.7 |  |
| Billings year-over-year percentage increase | 22.2 | % |  | 26.8 | % |  | 18.2 | % |
| Cash flow provided by operating activities | $ | 1,055.6 |  |  | $ | 1,038.1 |  |  | $ | 868.8 |  |
| Free cash flow (non-GAAP) | $ | 924.4 |  |  | $ | 926.1 |  |  | $ | 705.4 |  |

[0001327567-19-000032:mdna:33]
______________

[0001327567-19-000032:mdna:34]
| (1) | These amounts have been adjusted due to our adoption of the new revenue recognition standard and new guidance related to the presentation of restricted cash and cash equivalents in the statement of cash flows. Refer to Note 1. Description of Business and Summary of Significant Accounting Policies in Part II, Item 8 of this Annual Report on Form 10-K for more information. |

[0001327567-19-000032:mdna:35]
| • | Deferred Revenue. Our deferred revenue primarily consists of amounts that have been invoiced but have not been recognized as revenue as of the period end. The majority of our deferred revenue balance consists of subscription and support revenue that is recognized ratably over the contractual service period. We monitor our deferred revenue balance because it represents a significant portion of revenue to be recognized in future periods. |

[0001327567-19-000032:mdna:36]
| • | Billings. We define billings as total revenue plus the change in total deferred revenue, net of acquired deferred revenue, during the period. We consider billings to be a key metric used by management to manage our business given our hybrid SaaS revenue model, and believe billings provides investors with an important indicator of the health and visibility of our business because it includes subscription and support revenue, which is recognized ratably over the contractual service period, and product revenue, which is recognized at the time of shipment, provided that all other conditions for revenue recognition have been met. We consider billings to be a useful metric for management and investors, particularly if we continue to experience increased sales of subscriptions and strong renewal rates for subscription and support offerings, and as we monitor our near-term cash flows. While we believe that billings provides useful information to investors and others in understanding and evaluating our operating results in the same manner as our management, it is important to note that other companies, including companies in our industry, may not use billings, may calculate billings differently, may have different billing frequencies, or may use other financial measures to evaluate their performance, all of which could reduce the usefulness of billings as a comparative measure. We calculate billings in the following manner: |

[0001327567-19-000032:mdna:37]
- 40 -

[0001327567-19-000032:mdna:38]
|  | Year Ended July 31, |
|  | 2019 |  | 2018(1) |  | 2017(1) |
|  | (in millions) |
| Billings: |  |  |  |  |  |
| Total revenue | $ | 2,899.6 |  |  | $ | 2,273.6 |  |  | $ | 1,755.1 |  |
| Add: change in total deferred revenue, net of acquired deferred revenue | 590.2 |  |  | 582.6 |  |  | 496.6 |  |
| Billings | $ | 3,489.8 |  |  | $ | 2,856.2 |  |  | $ | 2,251.7 |  |

[0001327567-19-000032:mdna:39]
______________

[0001327567-19-000032:mdna:40]
| (1) | These amounts have been adjusted due to our adoption of the new revenue recognition standard. Refer to Note 1. Description of Business and Summary of Significant Accounting Policies in Part II, Item 8 of this Annual Report on Form 10-K for more information. |

[0001327567-19-000032:mdna:41]
| • | Cash Flow Provided by Operating Activities. We monitor cash flow provided by operating activities as a measure of our overall business performance. Our cash flow provided by operating activities is driven in large part by sales of our products and from up-front payments for subscription and support offerings. Monitoring cash flow provided by operating activities enables us to analyze our financial performance without the non-cash effects of certain items such as depreciation, amortization, and share-based compensation costs, thereby allowing us to better understand and manage the cash needs of our business. |

[0001327567-19-000032:mdna:42]
| • | Free Cash Flow (non-GAAP). We define free cash flow, a non-GAAP financial measure, as cash provided by operating activities less purchases of property, equipment, and other assets. We consider free cash flow to be a profitability and liquidity measure that provides useful information to management and investors about the amount of cash generated by the business after necessary capital expenditures. A limitation of the utility of free cash flow as a measure of our financial performance and liquidity is that it does not represent the total increase or decrease in our cash balance for the period. In addition, it is important to note that other companies, including companies in our industry, may not use free cash flow, may calculate free cash flow in a different manner than we do, or may use other financial measures to evaluate their performance, all of which could reduce the usefulness of free cash flow as a comparative measure. A reconciliation of free cash flow to cash flow provided by operating activities, the most directly comparable financial measure calculated and presented in accordance with GAAP, is provided below: |

[0001327567-19-000032:mdna:43]
|  | Year Ended July 31, |
|  | 2019 |  | 2018 |  | 2017 |
|  | (in millions) |
| Free cash flow (non-GAAP): |  |  |  |  |  |
| Net cash provided by operating activities(1) | $ | 1,055.6 |  |  | $ | 1,038.1 |  |  | $ | 868.8 |  |
| Less: purchases of property, equipment, and other assets | 131.2 |  |  | 112.0 |  |  | 163.4 |  |
| Free cash flow (non-GAAP)(1) | $ | 924.4 |  |  | $ | 926.1 |  |  | $ | 705.4 |  |
| Net cash used in investing activities | $ | (1,825.9 | ) |  | $ | (520.0 | ) |  | $ | (472.6 | ) |
| Net cash provided by (used in) financing activities | $ | (773.9 | ) |  | $ | 1,245.6 |  |  | $ | (386.0 | ) |

[0001327567-19-000032:mdna:44]
______________

[0001327567-19-000032:mdna:45]
| (1) | The amounts for fiscal 2018 and fiscal 2017 have been adjusted due to our adoption of new guidance related to the presentation of restricted cash and cash equivalents in the statement of cash flows. Refer to Note 1. Description of Business and Summary of Significant Accounting Policies in Part II, Item 8 of this Annual Report on Form 10-K for more information. |

[0001327567-19-000032:mdna:46]
- 41 -

[0001327567-19-000032:mdna:47]
Results of Operations

[0001327567-19-000032:mdna:48]
The following table summarizes our results of operations for the periods presented and as a percentage of our total revenue for those periods based on our consolidated statements of operations data. The period to period comparison of results is not necessarily indicative of results for future periods.

[0001327567-19-000032:mdna:49]
|  | Year Ended July 31, |
|  | 2019 |  | 2018(1) |  | 2017(1) |
|  | Amount |  | % of Revenue |  | Amount |  | % of Revenue |  | Amount |  | % of Revenue |
|  | (dollars in millions) |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 1,096.2 |  |  | 37.8 | % |  | $ | 879.8 |  |  | 38.7 | % |  | $ | 708.5 |  |  | 40.4 | % |
| Subscription and support | 1,803.4 |  |  | 62.2 | % |  | 1,393.8 |  |  | 61.3 | % |  | 1,046.6 |  |  | 59.6 | % |
| Total revenue | 2,899.6 |  |  | 100.0 | % |  | 2,273.6 |  |  | 100.0 | % |  | 1,755.1 |  |  | 100.0 | % |
| Cost of revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Product | 315.9 |  |  | 10.9 | % |  | 272.4 |  |  | 12.0 | % |  | 201.4 |  |  | 11.5 | % |
| Subscription and support | 492.5 |  |  | 17.0 | % |  | 372.7 |  |  | 16.4 | % |  | 275.0 |  |  | 15.6 | % |
| Total cost of revenue(2) | 808.4 |  |  | 27.9 | % |  | 645.1 |  |  | 28.4 | % |  | 476.4 |  |  | 27.1 | % |
| Total gross profit | 2,091.2 |  |  | 72.1 | % |  | 1,628.5 |  |  | 71.6 | % |  | 1,278.7 |  |  | 72.9 | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | 539.5 |  |  | 18.6 | % |  | 400.7 |  |  | 17.6 | % |  | 347.4 |  |  | 19.8 | % |
| Sales and marketing | 1,344.0 |  |  | 46.4 | % |  | 1,074.2 |  |  | 47.3 | % |  | 898.8 |  |  | 51.2 | % |
| General and administrative | 261.8 |  |  | 9.0 | % |  | 257.8 |  |  | 11.3 | % |  | 198.3 |  |  | 11.3 | % |
| Total operating expenses(2) | 2,145.3 |  |  | 74.0 | % |  | 1,732.7 |  |  | 76.2 | % |  | 1,444.5 |  |  | 82.3 | % |
| Operating loss | (54.1 | ) |  | (1.9 | )% |  | (104.2 | ) |  | (4.6 | )% |  | (165.8 | ) |  | (9.4 | )% |
| Interest expense | (83.9 | ) |  | (2.9 | )% |  | (29.6 | ) |  | (1.3 | )% |  | (24.5 | ) |  | (1.4 | )% |
| Other income, net | 63.4 |  |  | 2.2 | % |  | 28.5 |  |  | 1.3 | % |  | 10.2 |  |  | 0.5 | % |
| Loss before income taxes | (74.6 | ) |  | (2.6 | )% |  | (105.3 | ) |  | (4.6 | )% |  | (180.1 | ) |  | (10.3 | )% |
| Provision for income taxes | 7.3 |  |  | 0.2 | % |  | 16.9 |  |  | 0.8 | % |  | 22.9 |  |  | 1.3 | % |
| Net loss | $ | (81.9 | ) |  | (2.8 | )% |  | $ | (122.2 | ) |  | (5.4 | )% |  | $ | (203.0 | ) |  | (11.6 | )% |

[0001327567-19-000032:mdna:50]
______________

[0001327567-19-000032:mdna:51]
| (1) | Certain amounts have been adjusted due to our adoption of the new revenue recognition standard. Refer to Note 1. Description of Business and Summary of Significant Accounting Policies in Part II, Item 8 of this Annual Report on Form 10-K for more information. |

[0001327567-19-000032:mdna:52]
| (2) | Includes share-based compensation as follows: |

[0001327567-19-000032:mdna:53]
|  | Year Ended July 31, |
|  | 2019 |  | 2018 |  | 2017 |
|  | (in millions) |
| Cost of product revenue | $ | 5.6 |  |  | $ | 7.0 |  |  | $ | 7.3 |  |
| Cost of subscription and support revenue | 71.3 |  |  | 66.7 |  |  | 56.2 |  |
| Research and development | 186.8 |  |  | 145.2 |  |  | 152.6 |  |
| Sales and marketing | 221.9 |  |  | 208.0 |  |  | 186.5 |  |
| General and administrative | 102.1 |  |  | 77.0 |  |  | 73.1 |  |
| Total share-based compensation | $ | 587.7 |  |  | $ | 503.9 |  |  | $ | 475.7 |  |

[0001327567-19-000032:mdna:54]
- 42 -

[0001327567-19-000032:mdna:55]
Revenue

[0001327567-19-000032:mdna:56]
Our revenue consists of product revenue and subscription and support revenue. Revenue is recognized upon transfer of control of the corresponding promised products and subscriptions and support to our customers in an amount that reflects the consideration we expect to be entitled in exchange for those products and subscriptions and support. We expect our revenue to vary from quarter to quarter based on seasonal and cyclical factors.

[0001327567-19-000032:mdna:57]
Product Revenue

[0001327567-19-000032:mdna:58]
Product revenue is derived primarily from sales of our appliances. Product revenue also includes revenue derived from software licenses of Panorama and the VM-Series. Our appliances and software licenses include a broad set of built-in networking and security features and functionalities. We recognize product revenue at the time of hardware shipment or delivery of software license.

[0001327567-19-000032:mdna:59]
|  | Year Ended July 31, |  |  |  | Year Ended July 31, |  |  |
|  | 2019 |  | 2018(1) |  | Change |  | 2018(1) |  | 2017(1) |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Product | $ | 1,096.2 |  |  | $ | 879.8 |  |  | $ | 216.4 |  |  | 24.6 | % |  | $ | 879.8 |  |  | $ | 708.5 |  |  | $ | 171.3 |  |  | 24.2 | % |

[0001327567-19-000032:mdna:60]
______________

[0001327567-19-000032:mdna:61]
| (1) | These amounts have been adjusted due to our adoption of the new revenue recognition standard. Refer to Note 1. Description of Business and Summary of Significant Accounting Policies in Part II, Item 8 of this Annual Report on Form 10-K for more information. |

[0001327567-19-000032:mdna:62]
Product revenue increased for fiscal 2019 compared to fiscal 2018 primarily due to increased demand for our appliances. Product revenue increased for fiscal 2018 compared to fiscal 2017 due to increased demand for our newly introduced appliances. The change in product revenue due to pricing was not significant for either period.

[0001327567-19-000032:mdna:63]
Subscription and Support Revenue

[0001327567-19-000032:mdna:64]
Subscription and support revenue is derived primarily from sales of our subscription and support offerings. Our contractual subscription and support contracts are typically one to five years. We recognize revenue from subscriptions and support over time as the services are performed. As a percentage of total revenue, we expect our subscription and support revenue to vary from quarter to quarter and increase over the long term as we introduce new subscriptions, renew existing subscription and support contracts, and expand our installed end-customer base.

[0001327567-19-000032:mdna:65]
|  | Year Ended July 31, |  |  |  | Year Ended July 31, |  |  |
|  | 2019 |  | 2018(1) |  | Change |  | 2018(1) |  | 2017(1) |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Subscription | $ | 1,032.7 |  |  | $ | 758.1 |  |  | $ | 274.6 |  |  | 36.2 | % |  | $ | 758.1 |  |  | $ | 548.8 |  |  | $ | 209.3 |  |  | 38.1 | % |
| Support | 770.7 |  |  | 635.7 |  |  | 135.0 |  |  | 21.2 | % |  | 635.7 |  |  | 497.8 |  |  | 137.9 |  |  | 27.7 | % |
| Total subscription and support | $ | 1,803.4 |  |  | $ | 1,393.8 |  |  | $ | 409.6 |  |  | 29.4 | % |  | $ | 1,393.8 |  |  | $ | 1,046.6 |  |  | $ | 347.2 |  |  | 33.2 | % |

[0001327567-19-000032:mdna:66]
______________

[0001327567-19-000032:mdna:67]
| (1) | These amounts have been adjusted due to our adoption of the new revenue recognition standard. Refer to Note 1. Description of Business and Summary of Significant Accounting Policies in Part II, Item 8 of this Annual Report on Form 10-K for more information. |

[0001327567-19-000032:mdna:68]
Subscription and support revenue increased year-over-year for both fiscal 2019 and fiscal 2018. The increase in both periods was due to increased demand for our subscription and support offerings from both new and existing end-customers. The mix between subscription revenue and support revenue will fluctuate over time, depending on the introduction of new subscription offerings, renewals of support services, and our ability to increase sales to new and existing end-customers. The change in subscription and support revenue due to changes in pricing was not significant for either period.

[0001327567-19-000032:mdna:69]
- 43 -

[0001327567-19-000032:mdna:70]
Revenue by Geographic Theater

[0001327567-19-000032:mdna:71]
|  | Year Ended July 31, |  |  |  | Year Ended July 31, |  |  |
|  | 2019 |  | 2018(1) |  | Change |  | 2018(1) |  | 2017(1) |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Americas | $ | 1,982.3 |  |  | $ | 1,558.7 |  |  | $ | 423.6 |  |  | 27.2 | % |  | $ | 1,558.7 |  |  | $ | 1,230.6 |  |  | $ | 328.1 |  |  | 26.7 | % |
| EMEA | 564.8 |  |  | 439.6 |  |  | 125.2 |  |  | 28.5 | % |  | 439.6 |  |  | 320.3 |  |  | 119.3 |  |  | 37.2 | % |
| APAC | 352.5 |  |  | 275.3 |  |  | 77.2 |  |  | 28.0 | % |  | 275.3 |  |  | 204.2 |  |  | 71.1 |  |  | 34.8 | % |
| Total revenue | $ | 2,899.6 |  |  | $ | 2,273.6 |  |  | $ | 626.0 |  |  | 27.5 | % |  | $ | 2,273.6 |  |  | $ | 1,755.1 |  |  | $ | 518.5 |  |  | 29.5 | % |

[0001327567-19-000032:mdna:72]
______________

[0001327567-19-000032:mdna:73]
| (1) | These amounts have been adjusted due to our adoption of the new revenue recognition standard. Refer to Note 1. Description of Business and Summary of Significant Accounting Policies in Part II, Item 8 of this Annual Report on Form 10-K for more information. |

[0001327567-19-000032:mdna:74]
With respect to geographic theaters, the Americas contributed the largest portion of the year-over-year increases in revenue for both fiscal 2019 and fiscal 2018 due to its larger and more established sales force compared to our other theaters. Revenue from both Europe, the Middle East, and Africa (“EMEA”) and Asia Pacific and Japan (“APAC”) increased year-over-year for both fiscal 2019 and fiscal 2018 due to our investment in increasing the size of our sales force and number of channel partners in these theaters.

[0001327567-19-000032:mdna:75]
Cost of Revenue

[0001327567-19-000032:mdna:76]
Our cost of revenue consists of cost of product revenue and cost of subscription and support revenue.

[0001327567-19-000032:mdna:77]
Cost of Product Revenue

[0001327567-19-000032:mdna:78]
Cost of product revenue primarily includes costs paid to our manufacturing partners. Our cost of product revenue also includes personnel costs, which consist of salaries, benefits, bonuses, share-based compensation, and travel and entertainment associated with our operations organization, amortization of intellectual property licenses, product testing costs, shipping costs, and allocated costs. Allocated costs consist of certain facilities, depreciation, benefits, recruiting, and information technology costs that we allocate based on headcount. We expect our cost of product revenue to increase as our product revenue increases.

[0001327567-19-000032:mdna:79]
|  | Year Ended July 31, |  |  |  | Year Ended July 31, |  |  |
|  | 2019 |  | 2018 |  | Change |  | 2018 |  | 2017 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Cost of product revenue | $ | 315.9 |  |  | $ | 272.4 |  |  | $ | 43.5 |  |  | 16.0 | % |  | $ | 272.4 |  |  | $ | 201.4 |  |  | $ | 71.0 |  |  | 35.3 | % |
| Number of employees at period end | 102 |  |  | 97 |  |  | 5 |  |  | 5.2 | % |  | 97 |  |  | 96 |  |  | 1 |  |  | 1.0 | % |

[0001327567-19-000032:mdna:80]
Cost of product revenue increased for fiscal 2019 compared to fiscal 2018 primarily due to an increase in product unit volume. Cost of product revenue increased for fiscal 2018 compared to fiscal 2017 primarily due to higher product costs related to our newly introduced appliances.

[0001327567-19-000032:mdna:81]
Cost of Subscription and Support Revenue

[0001327567-19-000032:mdna:82]
Cost of subscription and support revenue includes personnel costs for our global customer support and technical operations organizations, customer support and repair costs, third-party professional services costs, data center and cloud hosting costs, amortization of acquired intangible assets and capitalized software development costs, and allocated costs. We expect our cost of subscription and support revenue to increase as our installed end-customer base grows and adoption of our cloud-based subscription offerings increases.

[0001327567-19-000032:mdna:83]
- 44 -

[0001327567-19-000032:mdna:84]
|  | Year Ended July 31, |  |  |  | Year Ended July 31, |  |  |
|  | 2019 |  | 2018 |  | Change |  | 2018 |  | 2017 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Cost of subscription and support revenue(1) | $ | 492.5 |  |  | $ | 372.7 |  |  | $ | 119.8 |  |  | 32.1 | % |  | $ | 372.7 |  |  | $ | 275.0 |  |  | $ | 97.7 |  |  | 35.5 | % |
| Number of employees at period end | 1,219 |  |  | 932 |  |  | 287 |  |  | 30.8 | % |  | 932 |  |  | 725 |  |  | 207 |  |  | 28.6 | % |

[0001327567-19-000032:mdna:85]
______________

[0001327567-19-000032:mdna:86]
| (1) | The amounts for fiscal 2018 and 2017 have been adjusted due to our adoption of the new revenue recognition standard. Refer to Note 1. Description of Business and Summary of Significant Accounting Policies in Part II, Item 8 of this Annual Report on Form 10-K for more information. |

[0001327567-19-000032:mdna:87]
Cost of subscription and support revenue increased for fiscal 2019 compared to fiscal 2018 primarily due to an increase in costs to support the growth of our subscription and support business. Personnel costs grew $45.7 million to $254.5 million primarily due to headcount growth. Amortization of purchased intangible assets increased $26.2 million for fiscal 2019 compared to fiscal 2018 as a result of our recent acquisitions. The remaining increase was primarily due to an increase in data center and cloud hosting costs to support the adoption of our cloud-based subscription offerings and costs to expand our customer service capabilities.

[0001327567-19-000032:mdna:88]
Cost of subscription and support revenue increased for fiscal 2018 compared to fiscal 2017 primarily due to an increase in personnel costs for our global customer support and technical operations organizations, which grew $53.5 million to $208.9 million, primarily due to headcount growth. The remaining increase was primarily due to data center and cloud hosting costs to support the adoption of our cloud-based subscription offerings, costs to expand our customer service capabilities, and allocated costs. The increase in allocated costs was primarily due to our expansion of facilities to support the growth of our business.

[0001327567-19-000032:mdna:89]
Gross Margin

[0001327567-19-000032:mdna:90]
Gross margin, or gross profit as a percentage of revenue, has been and will continue to be affected by a variety of factors, including the introduction of new products, manufacturing costs, the average sales price of our products, the mix of products sold, and the mix of revenue between product and subscription and support offerings. For sales of our products, our higher-end firewall products generally have higher gross margins than our lower-end firewall products within each product series. For sales of our subscription and support offerings, our subscription offerings typically have higher gross margins than our support offerings. We expect our gross margins to fluctuate over time depending on the factors described above.

[0001327567-19-000032:mdna:91]
|  | Year Ended July 31, |
|  | 2019 |  | 2018(1) |  | 2017(1) |
|  | Amount |  | GrossMargin |  | Amount |  | GrossMargin |  | Amount |  | GrossMargin |
|  | (dollars in millions) |
| Product | $ | 780.3 |  |  | 71.2 | % |  | $ | 607.4 |  |  | 69.0 | % |  | $ | 507.1 |  |  | 71.6 | % |
| Subscription and support | 1,310.9 |  |  | 72.7 | % |  | 1,021.1 |  |  | 73.3 | % |  | 771.6 |  |  | 73.7 | % |
| Total gross profit | $ | 2,091.2 |  |  | 72.1 | % |  | $ | 1,628.5 |  |  | 71.6 | % |  | $ | 1,278.7 |  |  | 72.9 | % |

[0001327567-19-000032:mdna:92]
______________

[0001327567-19-000032:mdna:93]
| (1) | These amounts have been adjusted due to our adoption of the new revenue recognition standard. Refer to Note 1. Description of Business and Summary of Significant Accounting Policies in Part II, Item 8 of this Annual Report on Form 10-K for more information. |

[0001327567-19-000032:mdna:94]
Product gross margin increased for fiscal 2019 compared to fiscal 2018 primarily due to improved operations in our supply chain management and increased leverage of our operations organization. Product gross margin decreased for fiscal 2018 compared to fiscal 2017, driven by higher product costs related to our newly introduced appliances, which had lower product margins.

[0001327567-19-000032:mdna:95]
Subscription and support gross margin decreased for fiscal 2019 compared to fiscal 2018, primarily due to higher amortization of purchased intangibles as a result of our recent acquisitions and costs to support the adoption of our cloud-based subscription offerings, partially offset by increased leverage of our global customer support organization. Subscription and support gross margin decreased slightly for fiscal 2018 compared to fiscal 2017, primarily due to higher data center and cloud hosting costs to support the adoption of our cloud-based subscription offerings and costs to expand our customer service capabilities, partially offset by a decrease in customer support and repair costs.

[0001327567-19-000032:mdna:96]
- 45 -

[0001327567-19-000032:mdna:97]
Operating Expenses

[0001327567-19-000032:mdna:98]
Our operating expenses consist of research and development, sales and marketing, and general and administrative expense. Personnel costs are the most significant component of operating expenses and consist of salaries, benefits, bonuses, share-based compensation, travel and entertainment, and with regard to sales and marketing expense, sales commissions. Our operating expenses also include allocated costs, which consist of certain facilities, depreciation, benefits, recruiting, and information technology costs that we allocate based on headcount. We expect operating expenses to increase in absolute dollars and decrease over the long term as a percentage of revenue as we continue to scale our business. As of July 31, 2019, we expect to recognize approximately $1.5 billion of share-based compensation expense over a weighted-average period of approximately 2.7 years, excluding additional share-based compensation expense related to any future grants of share-based awards. Share-based compensation expense is generally recognized on a straight-line basis over the requisite service periods of the awards.

[0001327567-19-000032:mdna:99]
Research and Development

[0001327567-19-000032:mdna:100]
Research and development expense consists primarily of personnel costs. Research and development expense also includes prototype related expenses and allocated costs. We expect research and development expense to increase in absolute dollars as we continue to invest in our future products and services, although our research and development expense may fluctuate as a percentage of total revenue.

[0001327567-19-000032:mdna:101]
|  | Year Ended July 31, |  |  |  | Year Ended July 31, |  |  |
|  | 2019 |  | 2018 |  | Change |  | 2018 |  | 2017 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Research and development | $ | 539.5 |  |  | $ | 400.7 |  |  | $ | 138.8 |  |  | 34.6 | % |  | $ | 400.7 |  |  | $ | 347.4 |  |  | $ | 53.3 |  |  | 15.3 | % |
| Number of employees at period end | 1,507 |  |  | 947 |  |  | 560 |  |  | 59.1 | % |  | 947 |  |  | 766 |  |  | 181 |  |  | 23.6 | % |

[0001327567-19-000032:mdna:102]
Research and development expense increased year-over-year for both fiscal 2019 and fiscal 2018. The increase in both periods was primarily due to an increase in personnel costs, which grew $105.8 million to $436.7 million for fiscal 2019 compared to fiscal 2018 and grew $36.8 million to $330.9 million for fiscal 2018 compared to fiscal 2017. The increase in personnel costs in both periods was primarily due to headcount growth. The remaining increase for both fiscal 2019 and 2018 was primarily driven by an increase in allocated costs.

[0001327567-19-000032:mdna:103]
Sales and Marketing

[0001327567-19-000032:mdna:104]
Sales and marketing expense consists primarily of personnel costs, including commission expense. Sales and marketing expense also includes costs for market development programs, promotional and other marketing costs, professional services, and allocated costs. We continue to thoughtfully invest in headcount and have substantially grown our sales presence internationally. We expect sales and marketing expense to continue to increase in absolute dollars as we increase the size of our sales and marketing organizations to increase touch points with end-customers and to expand our international presence, although our sales and marketing expense may fluctuate as a percentage of total revenue.

[0001327567-19-000032:mdna:105]
|  | Year Ended July 31, |  |  |  | Year Ended July 31, |  |  |
|  | 2019 |  | 2018 |  | Change |  | 2018 |  | 2017 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Sales and marketing(1) | $ | 1,344.0 |  |  | $ | 1,074.2 |  |  | $ | 269.8 |  |  | 25.1 | % |  | $ | 1,074.2 |  |  | $ | 898.8 |  |  | $ | 175.4 |  |  | 19.5 | % |
| Number of employees at period end | 3,382 |  |  | 2,704 |  |  | 678 |  |  | 25.1 | % |  | 2,704 |  |  | 2,418 |  |  | 286 |  |  | 11.8 | % |

[0001327567-19-000032:mdna:106]
______________

[0001327567-19-000032:mdna:107]
| (1) | The amounts for fiscal 2018 and 2017 have been adjusted due to our adoption of the new revenue recognition standard. Refer to Note 1. Description of Business and Summary of Significant Accounting Policies in Part II, Item 8 of this Annual Report on Form 10-K for more information. |

[0001327567-19-000032:mdna:108]
Sales and marketing expense increased year-over-year for both fiscal 2019 and fiscal 2018. The increase in both periods was primarily due to an increase in personnel costs, which grew $181.7 million to $1.0 billion for fiscal 2019 compared to fiscal 2018 and grew $133.8 million to $829.6 million for fiscal 2018 compared to fiscal 2017. The increase in personnel costs in both periods was largely due to headcount growth. The remaining increase for fiscal 2019 was primarily driven by an increase in allocated costs, an increase in costs associated with marketing-related activities, and higher amortization of purchased intangible assets, which increased

[0001327567-19-000032:mdna:109]
- 46 -

[0001327567-19-000032:mdna:110]
for fiscal 2019 compared to fiscal 2018 as a result of our recent acquisitions. The remaining increase for fiscal 2018 was primarily driven by an increase in allocated costs due to our expansion of facilities to support the growth of our business.

[0001327567-19-000032:mdna:111]
General and Administrative

[0001327567-19-000032:mdna:112]
General and administrative expense consists primarily of personnel costs for our executive, finance, human resources, legal, and information technology organizations, and professional services costs, which consist primarily of legal, auditing, accounting, and other consulting costs. General and administrative expense also includes certain non-recurring general expenses and impairment losses. Certain facilities, depreciation, benefits, recruiting, and information technology costs are allocated to other organizations based on headcount. We expect general and administrative expense to increase in absolute dollars due to additional costs associated with accounting, compliance, and insurance, although our general and administrative expense may fluctuate as a percentage of total revenue.

[0001327567-19-000032:mdna:113]
|  | Year Ended July 31, |  |  |  | Year Ended July 31, |  |  |
|  | 2019 |  | 2018 |  | Change |  | 2018 |  | 2017 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| General and administrative | $ | 261.8 |  |  | $ | 257.8 |  |  | $ | 4.0 |  |  | 1.6 | % |  | $ | 257.8 |  |  | $ | 198.3 |  |  | $ | 59.5 |  |  | 30.0 | % |
| Number of employees at period end | 804 |  |  | 668 |  |  | 136 |  |  | 20.4 | % |  | 668 |  |  | 557 |  |  | 111 |  |  | 19.9 | % |

[0001327567-19-000032:mdna:114]
General and administrative expense increased for fiscal 2019 compared to fiscal 2018 primarily due to an increase in personnel costs, which grew $28.0 million to $173.8 million for fiscal 2019 compared to fiscal 2018, and an increase in legal expenses. The increase in personnel costs was primarily due to headcount growth and expense related to the accelerated vesting of certain equity awards in connection with our business acquisitions in fiscal 2019. These increases were substantially offset by a net decrease of $32.2 million in cease-use losses recognized on the lease of our previous corporate headquarter facilities. Refer to Note 11. Commitments and Contingencies in Part II, Item 8 of this Annual Report on Form 10-K for more information.

[0001327567-19-000032:mdna:115]
General and administrative expense increased for fiscal 2018 compared to fiscal 2017 primarily due to a cease-use loss of $39.2 million recognized on the lease of our previous corporate headquarter facilities during fiscal 2018. Refer to Note 11. Commitments and Contingencies in Part II, Item 8 of this Annual Report on Form 10-K for more information. The remaining increase was primarily driven by costs related to business acquisitions completed during fiscal 2018, an increase in personnel costs, and an increase in allocated costs due to our expansion of facilities to support the growth of our business. Personnel costs grew $10.2 million to $138.7 million for fiscal 2018 compared to fiscal 2017, largely due to headcount growth. These increases were partially offset by a decrease in impairment losses due to the $20.9 million loss recognized in fiscal 2017 on property and equipment related to the relocation of our corporate headquarters.

[0001327567-19-000032:mdna:116]
Interest Expense

[0001327567-19-000032:mdna:117]
Interest expense primarily consists of non-cash interest expense from the amortization of the debt discount and debt issuance costs related to our 0.0% Convertible Senior Notes due 2019 (the “2019 Notes”) and 0.75% Convertible Senior Notes due 2023 (the “2023 Notes” and, together with the 2019 Notes, the “Notes”), and also includes the contractual interest expense related to our 2023 Notes.

[0001327567-19-000032:mdna:118]
|  | Year Ended July 31, |  |  |  | Year Ended July 31, |  |  |
|  | 2019 |  | 2018 |  | Change |  | 2018 |  | 2017 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Interest expense | $ | 83.9 |  |  | $ | 29.6 |  |  | $ | 54.3 |  |  | 183.4 | % |  | $ | 29.6 |  |  | $ | 24.5 |  |  | $ | 5.1 |  |  | 20.8 | % |

[0001327567-19-000032:mdna:119]
Interest expense increased year-over-year for both fiscal 2019 and fiscal 2018. The increase in both periods was primarily due to interest expense recognized on the 2023 Notes issued in July 2018. The increase in interest expense for fiscal 2019 was partially offset by a reduction in interest expense recognized on the 2019 Notes due to conversions of the 2019 Notes before and upon maturity in July 2019. Refer to Note 10. Debt in Part II, Item 8 of this Annual Report on Form 10-K for more information on the Notes.

[0001327567-19-000032:mdna:120]
Other Income, Net

[0001327567-19-000032:mdna:121]
Other income, net includes interest income earned on our cash, cash equivalents, and investments, foreign currency remeasurement gains and losses, and foreign currency transaction gains and losses.

[0001327567-19-000032:mdna:122]
- 47 -

[0001327567-19-000032:mdna:123]
|  | Year Ended July 31, |  |  |  | Year Ended July 31, |  |  |
|  | 2019 |  | 2018 |  | Change |  | 2018 |  | 2017 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Other income, net | $ | 63.4 |  |  | $ | 28.5 |  |  | $ | 34.9 |  |  | 122.5 | % |  | $ | 28.5 |  |  | $ | 10.2 |  |  | $ | 18.3 |  |  | 179.4 | % |

[0001327567-19-000032:mdna:124]
Other income, net increased for fiscal 2019 compared to fiscal 2018 primarily driven by a $42.6 million increase in interest income, partially offset by an increase in foreign currency remeasurement and transaction losses. Other income, net increased for fiscal 2018 compared to fiscal 2017 primarily driven by a $12.4 million increase in interest income and an increase in foreign currency remeasurement gains. The increase in interest income in both periods was largely due to higher cash, cash equivalents and investments balances and higher yields on these balances during the respective periods.

[0001327567-19-000032:mdna:125]
Provision for Income Taxes

[0001327567-19-000032:mdna:126]
Provision for income taxes consists primarily of income taxes in foreign jurisdictions in which we conduct business, withholding taxes, and U.S. state income taxes. We maintain a full valuation allowance for domestic and certain foreign deferred tax assets, including net operating loss carryforwards and certain domestic tax credits. In recent years, we reorganized our corporate structure and intercompany relationships to more closely align with the international nature of our business activities. Our corporate structure has caused, and may continue to cause, disproportionate relationships between our overall effective tax rate and other jurisdictional measures. To the extent we revisit our corporate structure, it may have an impact on our tax provision.

[0001327567-19-000032:mdna:127]
|  | Year Ended July 31, |  |  |  |  |  | Year Ended July 31, |  |  |  |  |
|  | 2019 |  | 2018(1) |  | Change |  | 2018(1) |  | 2017(1) |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Provision for income taxes | $ | 7.3 |  |  | $ | 16.9 |  |  | $ | (9.6 | ) |  | (56.8 | )% |  | $ | 16.9 |  |  | $ | 22.9 |  |  | $ | (6.0 | ) |  | (26.2 | )% |
| Effective tax rate | (9.8 | )% |  | (16.0 | )% |  |  |  |  |  | (16.0 | )% |  | (12.7 | )% |  |  |  |  |

[0001327567-19-000032:mdna:128]
______________

[0001327567-19-000032:mdna:129]
| (1) | These amounts have been adjusted due to our adoption of the new revenue recognition standard. Refer to Note 1. Description of Business and Summary of Significant Accounting Policies in Part II, Item 8 of this Annual Report on Form 10-K for more information. |

[0001327567-19-000032:mdna:130]
We recorded an income tax provision for fiscal 2019 primarily due to foreign and state income taxes and withholding taxes. Our provision for income taxes decreased for fiscal 2019 compared to fiscal 2018 primarily due to changes in our valuation allowance related to acquisitions completed during fiscal 2019 and our adoption of accounting guidance requiring the recognition of income tax consequences of an intra-entity transfer of an asset, other than inventory, when the transfer occurs. These decreases were partially offset by an increase in foreign taxes due to growth in non-U.S. operations.

[0001327567-19-000032:mdna:131]
We recorded an income tax provision for fiscal 2018 due to foreign income taxes, withholding taxes, and amortization of our deferred tax charges. Our provision for income taxes decreased for fiscal 2018 compared to fiscal 2017 primarily due to changes in our valuation allowance related to the acquisition of Evident.io and future benefits from alternative minimum tax credits under the TCJA, which was enacted into law in December 2017. Refer to Note 14. Income Taxes in Part II, Item 8 of this Annual Report on Form 10-K for more information on the TCJA and its impact.

[0001327567-19-000032:mdna:132]
- 48 -

[0001327567-19-000032:mdna:133]
Liquidity and Capital Resources

[0001327567-19-000032:mdna:134]
|  | July 31, |
|  | 2019 |  | 2018 |
|  | (in millions) |
| Working capital(1)(2) | $ | 1,611.5 |  |  | $ | 2,036.8 |  |
| Cash, cash equivalents, and investments: |  |  |  |
| Cash and cash equivalents | $ | 961.4 |  |  | $ | 2,506.9 |  |
| Investments | 2,417.1 |  |  | 1,444.0 |  |
| Total cash, cash equivalents, and investments | $ | 3,378.5 |  |  | $ | 3,950.9 |  |

[0001327567-19-000032:mdna:135]
______________

[0001327567-19-000032:mdna:136]
| (1) | The amount for fiscal 2018 has been adjusted due to our adoption of the new revenue recognition standard. Refer to Note 1. Description of Business and Summary of Significant Accounting Policies in Part II, Item 8 of this Annual Report on Form 10-K for more information. |

[0001327567-19-000032:mdna:137]
| (2) | The net carrying amount of the 2019 Notes was classified in current liabilities on our consolidated balance sheets as of July 31, 2018. Refer to Note 10. Debt in Part II, Item 8 of this Annual Report on Form 10-K for information on the Notes. |

[0001327567-19-000032:mdna:138]
As of July 31, 2019, our total cash, cash equivalents, and investments of $3.4 billion were held for general corporate purposes, of which approximately $243.5 million was held outside of the United States. As of July 31, 2019, we had no unremitted earnings when evaluating our outside basis difference relating to our U.S. investment in foreign subsidiaries. However, there could be local withholding taxes payable due to various foreign countries if certain lower tier earnings are distributed. Withholding taxes that would be payable upon remittance of these lower tier earnings are not expected to be material.

[0001327567-19-000032:mdna:139]
In June 2014, we issued the 2019 Notes with an aggregate principal amount of $575.0 million. The 2019 Notes were converted prior to or settled on the maturity date of July 1, 2019. During fiscal 2019, we repaid in cash $575.0 million in aggregate principal amount of the 2019 Notes and issued 2.5 million shares of common stock to the holders for the conversion value in excess of the principal amount of the 2019 Notes converted, which were fully offset by shares received from our exercise of the associated note hedges. In July 2018, we issued the 2023 Notes with an aggregate principal amount of $1.7 billion. The 2023 Notes mature on July 1, 2023; however, under certain circumstances, holders may surrender their 2023 Notes for conversion prior to the maturity date. Upon conversion of the 2023 Notes, we will pay cash equal to the aggregate principal amount of the 2023 Notes to be converted, and, at our election, will pay or deliver cash and/or shares of our common stock for the amount of our conversion obligation in excess of the aggregate principal amount of the 2023 Notes being converted. As of July 31, 2019, all of the 2023 Notes remained outstanding. Refer to Note 10. Debt in Part II, Item 8 of this Annual Report on Form 10-K for more information on the Notes.

[0001327567-19-000032:mdna:140]
In September 2018, we entered into a credit agreement (the “Credit Agreement”) that provides for a $400.0 million unsecured revolving credit facility (the “Credit Facility”), with an option to increase the amount of the credit facility by up to an additional $350.0 million, subject to certain conditions. As of July 31, 2019, there were no amounts outstanding, and we were in compliance with all covenants under the Credit Agreement. Refer to Note 10. Debt in Part II, Item 8 of this Annual Report on Form 10-K for more information on the Credit Agreement.

[0001327567-19-000032:mdna:141]
In August 2016, our board of directors authorized a $500.0 million share repurchase program and, in February 2017, authorized a $500.0 million increase to the repurchase program, bringing the total authorization to $1.0 billion. The repurchase program expired on December 31, 2018. In February 2019, our board of directors authorized a new $1.0 billion share repurchase program. Repurchases will be funded from available working capital and may be made at management’s discretion from time to time. This repurchase program will expire on December 31, 2020, and may be suspended or discontinued at any time. As of July 31, 2019, $1.0 billion remained available for future share repurchases under the new repurchase authorization. Refer to Note 12. Stockholders’ Equity in Part II, Item 8 of this Annual Report on Form 10-K for information on the repurchase programs.

[0001327567-19-000032:mdna:142]
- 49 -

[0001327567-19-000032:mdna:143]
The following table summarizes our cash flows for the years ended July 31, 2019, 2018, and 2017:

[0001327567-19-000032:mdna:144]
|  | Year Ended July 31, |
| 2019 |  | 2018 |  | 2017 |
|  | (in millions) |
| Net cash provided by operating activities(1) | $ | 1,055.6 |  |  | $ | 1,038.1 |  |  | $ | 868.8 |  |
| Net cash used in investing activities | (1,825.9 | ) |  | (520.0 | ) |  | (472.6 | ) |
| Net cash provided by (used in) financing activities | (773.9 | ) |  | 1,245.6 |  |  | (386.0 | ) |
| Net increase (decrease) in cash, cash equivalents, and restricted cash(1) | $ | (1,544.2 | ) |  | $ | 1,763.7 |  |  | $ | 10.2 |  |

[0001327567-19-000032:mdna:145]
______________

[0001327567-19-000032:mdna:146]
| (1) | The amounts for fiscal 2018 and 2017 have been adjusted due to our adoption of new guidance related to the presentation of restricted cash and cash equivalents in the statement of cash flows. Refer to Note 1. Description of Business and Summary of Significant Accounting Policies in Part II, Item 8 of this Annual Report on Form 10-K for more information. |

[0001327567-19-000032:mdna:147]
We believe that our cash flow from operations with existing cash and cash equivalents will be sufficient to meet our anticipated cash needs for the foreseeable future. Our future capital requirements will depend on many factors including our growth rate, the timing and extent of spending to support development efforts, the expansion of sales and marketing activities, the introduction of new and enhanced products and subscription and support offerings, the costs to acquire or invest in complementary businesses and technologies, the costs to ensure access to adequate manufacturing capacity, the investments in our infrastructure to support the adoption of our cloud-based subscription offerings, the investments in our new corporate headquarters, and the continuing market acceptance of our products and subscription and support offerings. In addition, from time to time we may incur additional tax liability in connection with certain corporate structuring decisions.

[0001327567-19-000032:mdna:148]
We may also choose to seek additional equity or debt financing. In the event that additional financing is required from outside sources, we may not be able to raise it on terms acceptable to us or at all. If we are unable to raise additional capital when desired, our business, operating results, and financial condition may be adversely affected.

[0001327567-19-000032:mdna:149]
Operating Activities

[0001327567-19-000032:mdna:150]
Our operating activities have consisted of net losses adjusted for certain non-cash items and changes in assets and liabilities.

[0001327567-19-000032:mdna:151]
Cash provided by operating activities during fiscal 2019 was $1.1 billion, an increase of $17.5 million compared to fiscal 2018. The increase was due to growth of our business, as reflected by an increase in billings during fiscal 2019. This was partially offset by repayments of the 2019 Notes attributable to the debt discount of $97.6 million during fiscal 2019.

[0001327567-19-000032:mdna:152]
Cash provided by operating activities in fiscal 2018 was $1.0 billion, an increase of $169.3 million compared to fiscal 2017. The increase was due to growth of our business, as reflected by an increase in billings during fiscal 2018.

[0001327567-19-000032:mdna:153]
Investing Activities

[0001327567-19-000032:mdna:154]
Our investing activities have consisted of capital expenditures, net investment purchases, sales, and maturities, and business acquisitions. We expect to continue such activities as our business grows.

[0001327567-19-000032:mdna:155]
Cash used in investing activities during fiscal 2019 was $1.8 billion, an increase of $1.3 billion compared to fiscal 2018. The increase was primarily due to higher net purchases of investments and an increase in net cash payments for business acquisitions during fiscal 2019.

[0001327567-19-000032:mdna:156]
Cash used in investing activities during fiscal 2018 was $520.0 million, an increase of $47.4 million compared to fiscal 2017. The increase was due to higher net cash payments for business acquisitions, partially offset by lower net purchases of available-for-sale investments and capital expenditures during fiscal 2018.

[0001327567-19-000032:mdna:157]
Financing Activities

[0001327567-19-000032:mdna:158]
Our financing activities have consisted of net proceeds from the issuance of the Notes and related transactions, repayments of the 2019 Notes, proceeds from sales of shares through employee equity incentive plans, cash used to repurchase shares of our common stock, and payments for tax withholding obligations of certain employees related to the net share settlement of equity awards.

[0001327567-19-000032:mdna:159]
Cash used in financing activities during fiscal 2019 was $773.9 million, a change of $2.0 billion compared to fiscal 2018. The change was primarily due to net proceeds of $1.5 billion from the issuance of the 2023 Notes, issuance of warrants, and purchase of note hedges received during fiscal 2018 and repayments of the 2019 Notes during fiscal 2019.

[0001327567-19-000032:mdna:160]
- 50 -

[0001327567-19-000032:mdna:161]
Cash provided by financing activities during fiscal 2018 was $1.2 billion, a change of $1.6 billion compared to fiscal 2017. The change was primarily due to net proceeds of $1.5 billion from the issuance of the 2023 Notes, issuance of warrants, and purchase of note hedges, partially offset by an increase in payments for tax withholding obligations of certain employees related to the net share settlement of equity awards during fiscal 2018.

[0001327567-19-000032:mdna:162]
Contractual Obligations and Commitments

[0001327567-19-000032:mdna:163]
The following summarizes our contractual obligations and commitments as of July 31, 2019:

[0001327567-19-000032:mdna:164]
|  | Payments Due by Period |
|  | Total |  | Less Than 1 Year |  | 1-3 Years |  | 3-5 Years |  | More Than 5 Years |
|  |  |  | (in millions) |  |  |
| 0.75% Convertible Senior Notes due 2023 | $ | 1,693.0 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,693.0 |  |  | $ | — |  |
| Operating lease obligations(1) | 491.8 |  |  | 74.1 |  |  | 130.1 |  |  | 105.7 |  |  | 181.9 |  |
| Purchase obligations(2) | 427.6 |  |  | 119.2 |  |  | 85.9 |  |  | 125.0 |  |  | 97.5 |  |
| Total(3) | $ | 2,612.4 |  |  | $ | 193.3 |  |  | $ | 216.0 |  |  | $ | 1,923.7 |  |  | $ | 279.4 |  |

[0001327567-19-000032:mdna:165]
______________

[0001327567-19-000032:mdna:166]
| (1) | Consists of contractual obligations from our non-cancelable operating leases. Excludes contractual sublease proceeds of $9.8 million, which consists of $5.6 million to be received in less than one year and $4.2 million to be received in one to three years. Refer to Note 11. Commitments and Contingencies in Part II, Item 8 of this Annual Report on Form 10-K for more information on our operating leases. |

[0001327567-19-000032:mdna:167]
| (2) | Consists of minimum purchase commitments of products and components with our manufacturing partners and component suppliers, as well as minimum or fixed purchase commitments for our use of certain cloud and other services with third-party providers. Obligations under contracts that we can cancel without a significant penalty are not included in the table above. |

[0001327567-19-000032:mdna:168]
| (3) | No amounts related to income taxes are included. As of July 31, 2019, we had approximately $72.9 million of tax liabilities recorded related to uncertainty in income tax positions. |

[0001327567-19-000032:mdna:169]
Off-Balance Sheet Arrangements

[0001327567-19-000032:mdna:170]
As of July 31, 2019, we did not have any relationships with unconsolidated organizations or financial partnerships, such as structured finance or special purpose entities that would have been established for the purpose of facilitating off-balance sheet arrangements or other contractually narrow or limited purposes.

[0001327567-19-000032:mdna:171]
Critical Accounting Estimates

[0001327567-19-000032:mdna:172]
Our consolidated financial statements have been prepared in accordance with GAAP. The preparation of these consolidated financial statements requires us to make estimates and assumptions that affect the reported amounts of assets, liabilities, revenue, expenses, and related disclosures. We base our estimates on historical experience and on various other assumptions that we believe are reasonable under the circumstances. We evaluate our estimates and assumptions on an ongoing basis. Actual results may differ from these estimates. To the extent that there are material differences between these estimates and our actual results, our future financial statements will be affected.

[0001327567-19-000032:mdna:173]
We believe that of our significant accounting policies described in Note 1. Description of Business and Summary of Significant Accounting Policies in Part II, Item 8 of this Annual Report on Form 10-K, the critical accounting policies requiring estimates, assumptions, and judgments that have the most significant impact on our consolidated financial statements are described below.

[0001327567-19-000032:mdna:174]
Revenue Recognition

[0001327567-19-000032:mdna:175]
The majority of our contracts with our customers include various combinations of our products and subscriptions and support. Our appliances and software licenses have significant standalone functionalities and capabilities and, accordingly, are distinct from our subscriptions and support services, as the customer can benefit from the product without these services and such services are separately identifiable within the contract. We account for multiple agreements with a single customer as a single contract if the contractual terms and/or substance of those agreements indicate that they may be so closely related that they are, in effect, parts of a single contract. The amount we are due in exchange for delivering on the contract is allocated to each performance obligation based on its relative standalone selling price.

[0001327567-19-000032:mdna:176]
We establish standalone selling price using the prices charged for a deliverable when sold separately. If not observable through past transactions, we estimate the standalone selling price based on our pricing model and our go-to-market strategy, which include

[0001327567-19-000032:mdna:177]
- 51 -

[0001327567-19-000032:mdna:178]
factors such as type of sales channel (reseller, distributor, or end-customer), the geographies in which our offerings were sold (domestic or international) and offering type (products, subscriptions, or support). As our business offerings evolve over time, we may be required to modify our estimated standalone selling prices, and as a result the timing and classification of our revenue could be affected.

[0001327567-19-000032:mdna:179]
Deferred Contract Costs

[0001327567-19-000032:mdna:180]
We defer contract costs that are recoverable and incremental to obtaining customer sales contracts. Contract costs, which primarily consist of sales commissions, are amortized on a systematic basis that is consistent with the transfer to the customer of the goods or services to which the asset relates. Sales commissions for initial contracts that are not commensurate with renewal commissions are amortized over a benefit period of five years, consistent with the revenue recognition pattern of the performance obligations in the related contracts including expected renewals. The benefit period is determined by taking into consideration of contract length, technology life, and other quantitative and qualitative factors. The expected renewals are estimated based on historical renewal trends. Sales commissions for initial contracts that are commensurate and sales commissions for renewal contracts are amortized over the related contractual period in proportion to the revenue recognized.

[0001327567-19-000032:mdna:181]
Income Taxes

[0001327567-19-000032:mdna:182]
We account for income taxes using the asset and liability method, which requires the recognition of deferred tax assets and liabilities for the expected future tax consequences of events that have been recognized in our financial statements or tax returns. In addition, deferred tax assets are recorded for the future benefit of utilizing net operating losses and research and development credit carryforwards. Valuation allowances are provided when necessary to reduce deferred tax assets to the amount expected to be realized.

[0001327567-19-000032:mdna:183]
Significant judgment is required in determining any valuation allowance recorded against deferred tax assets. In assessing the need for a valuation allowance, we consider all available evidence, including past operating results, estimates of future taxable income, and the feasibility of tax planning strategies. In the event that we change our determination as to the amount of deferred tax assets that can be realized, we will adjust our valuation allowance with a corresponding impact to the provision for income taxes in the period in which such determination is made.

[0001327567-19-000032:mdna:184]
We apply the authoritative accounting guidance prescribing a threshold and measurement attribute for the financial recognition and measurement of a tax position taken or expected to be taken in a tax return. We recognize liabilities for uncertain tax positions based on a two-step process. The first step is to evaluate the tax position for recognition by determining if the weight of available evidence indicates that it is more likely than not that the position will be sustained on audit, including resolution of related appeals or litigation processes, if any. The second step requires us to estimate and measure the tax benefit as the largest amount that is more likely than not to be realized upon ultimate settlement.

[0001327567-19-000032:mdna:185]
Significant judgment is also required in evaluating our uncertain tax positions and determining our provision for income taxes. Although we believe our reserves are reasonable, no assurance can be given that the final tax outcome of these matters will not be different from that which is reflected in our historical income tax provisions and accruals. We adjust these reserves in light of changing facts and circumstances, such as the closing of a tax audit or the refinement of an estimate. To the extent that the final tax outcome of these matters is different than the amounts recorded, such differences may impact the provision for income taxes in the period in which such determination is made.

[0001327567-19-000032:mdna:186]
Manufacturing Partner and Supplier Liabilities

[0001327567-19-000032:mdna:187]
We outsource most of our manufacturing, repair, and supply chain management operations to our EMS provider, which procures components and assembles our products based on our demand forecasts. These forecasts of future demand are based upon historical trends and analysis from our sales and product management functions as adjusted for overall market conditions. We accrue for costs for manufacturing purchase commitments in excess of our forecasted demand, including costs for excess components or for carrying costs incurred by our manufacturing partners and component suppliers. Actual component usage and product demand may be materially different from our forecast, and could be caused by factors outside of our control, which could have an adverse impact on our results of operations. To date, we have not accrued significant costs associated with this exposure.

[0001327567-19-000032:mdna:188]
Loss Contingencies

[0001327567-19-000032:mdna:189]
We are subject to the possibility of various loss contingencies arising in the ordinary course of business. We accrue for loss contingencies when it is probable that an asset has been impaired or a liability has been incurred and the amount of loss can be reasonably estimated. If we determine that a loss is possible and the range of the loss can be reasonably determined, then we disclose the range of the possible loss. We regularly evaluate current information available to us to determine whether an accrual is required, an accrual should be adjusted or a range of possible loss should be disclosed.

[0001327567-19-000032:mdna:190]
From time to time, we are involved in disputes, litigation, and other legal actions. However, there are many uncertainties associated with any litigation, and these actions or other third-party claims against us may cause us to incur substantial settlement charges, which are inherently difficult to estimate and could adversely affect our results of operations. The actual liability in any such

[0001327567-19-000032:mdna:191]
- 52 -

[0001327567-19-000032:mdna:192]
matters may be materially different from our estimates, which could result in the need to adjust our liability and record additional expenses.

[0001327567-19-000032:mdna:193]
Goodwill, Intangibles, and Other Long-Lived Assets

[0001327567-19-000032:mdna:194]
We make significant estimates, assumptions, and judgments when valuing goodwill and other purchased intangible assets in connection with the initial purchase price allocation of an acquired entity, as well as when evaluating impairment of goodwill and other purchased intangible assets on an ongoing basis. These estimates are based upon a number of factors, including historical experience, market conditions, and information obtained from the management of the acquired company. Critical estimates in valuing certain intangible assets include, but are not limited to, cash flows that an asset is expected to generate in the future, discount rates, the time and expense that would be necessary to recreate the assets, and the profit margin a market participant would receive. The amounts and useful lives assigned to identified intangible assets impacts the amount and timing of future amortization expense.

[0001327567-19-000032:mdna:195]
We evaluate goodwill for impairment on an annual basis in our fourth fiscal quarter or more frequently if we believe impairment indicators exist. We have elected to first assess qualitative factors to determine whether it is more likely than not that the fair value of our reporting unit is less than its carrying amount, including goodwill. The qualitative assessment includes our evaluation of relevant events and circumstances affecting our single reporting unit, including macroeconomic, industry, and market conditions, our overall financial performance, and trends in the market price of our common stock. If qualitative factors indicate that it is more likely than not that our reporting unit’s fair value is less than its carrying amount, then we will perform the quantitative impairment test by comparing our reporting unit’s carrying amount, including goodwill, to its fair value. If the carrying amount of our reporting unit exceeds its fair value, an impairment loss will be recognized in an amount equal to that excess. To date, the results of our qualitative assessment have indicated that the quantitative goodwill impairment test is not necessary.

[0001327567-19-000032:mdna:196]
We evaluate long-lived assets, such as property, equipment, and purchased intangible assets for impairment whenever events or changes in circumstances indicate that the carrying amount of the assets may not be recoverable. Such events or changes in circumstances include, but are not limited to, a significant decrease in the fair value of the underlying asset or asset group, a significant decrease in the benefits realized from the acquired assets, difficulty and delays in integrating the business, or a significant change in the operations of the acquired assets or use of an asset or asset group. A long-lived asset is considered impaired if its carrying amount exceeds the estimated future undiscounted cash flows the asset or asset group is expected to generate. Critical estimates in determining whether a long-lived asset is considered impaired include the amount and timing of future cash flows that the asset or asset group is expected to generate. If a long-lived asset is considered to be impaired, the impairment to be recognized is the amount by which the carrying amount of the asset exceeds the fair value of the asset or asset group, which is estimated using a present value technique. Critical estimates in determining the fair value of an asset or asset group and the amount of impairment to recognize include, but are not limited to, the amount and timing of future cash flows that the asset or asset group is expected to generate and the discount rate. Determining the fair value of an asset or asset group is highly judgmental in nature and involves the use of significant estimates and assumptions for market participants. We base our fair value estimates on assumptions we believe to be reasonable but that are unpredictable and inherently uncertain. Actual future results may differ from those estimates.

[0001327567-19-000032:mdna:197]
Cease-use Loss

[0001327567-19-000032:mdna:198]
Upon exiting a leased property before the lease term expires, we assess the fair value of our remaining obligation under the lease and record a cease-use loss, if needed. The cease-use loss is calculated as the present value of the amount by which the remaining lease obligation, adjusted for the effects of any deferred items recognized under the lease and related costs, exceeds the estimated sublease rentals that could be reasonably obtained. The key assumptions used in our discounted cash flow model include the amount and timing of estimated sublease rental receipts and the discount rate. The cease-use loss recorded or to be recorded may change significantly as a result of the remeasurement of the cease-use liability, if the timing or amount of estimated cash flows change.

[0001327567-19-000032:mdna:199]
Recent Accounting Pronouncements

[0001327567-19-000032:mdna:200]
Refer to “Recently Issued Accounting Pronouncements” in Note 1. Description of Business and Summary of Significant Accounting Policies in Part II, Item 8 of this Annual Report on Form 10-K for a description of recent accounting pronouncements and our expectation of their impact, if any, on our results of operations and financial condition.
