# PANW note change history — 0001327567-23-000014 → 0001327567-23-000032


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2023-11-17):
[0001327567-23-000032:note_history:1]
In order to reduce manufacturing lead times and plan for adequate supply, we enter into agreements with manufacturing partners and component suppliers to procure inventory based on our demand forecasts. The following table presents details of the aggregate future minimum or fixed purchase commitments under these arrangements, excluding obligations under contracts that we can cancel as of October 31, 2023 (in millions):
  (was, 2023-05-24, similarity 0.9856):
[0001327567-23-000014:note_history:1]
In order to reduce manufacturing lead times and plan for adequate supply, we enter into agreements with manufacturing partners and component suppliers to procure inventory based on our demand forecasts. The following table presents details of the aggregate future minimum or fixed purchase commitments under these arrangements, excluding obligations under contracts that we can cancel as of April 30, 2023 (in millions):

- changed (2023-11-17):
[0001327567-23-000032:note_history:2]
|  |  |  | Fiscal years ending July 31, |
|  | Total |  | Remaining 2024 |  | 2025 |  | 2026 |  | 2027 |  | 2028 |  | 2029 and Thereafter |
| Manufacturing purchase commitments | $ | 188.2 |  |  | $ | 113.2 |  |  | $ | 35.0 |  |  | $ | 40.0 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
  (was, 2023-05-24, similarity 0.9478):
[0001327567-23-000014:note_history:2]
|  |  |  | Fiscal years ending July 31, |
|  | Total |  | Remaining 2023 |  | 2024 |  | 2025 |  | 2026 |  | 2027 |  | 2028 and Thereafter |
| Manufacturing purchase commitments | $ | 182.6 |  |  | $ | 67.0 |  |  | $ | 40.6 |  |  | $ | 35.0 |  |  | $ | 40.0 |  |  | $ | — |  |  | $ | — |  |

- changed (2023-11-17):
[0001327567-23-000032:note_history:3]
We have entered into various non-cancelable agreements with certain service providers, under which we are committed to minimum or fixed purchases. The following table presents details of the aggregate future non-cancelable purchase commitments under these agreements as of October 31, 2023 (in millions):
  (was, 2023-05-24, similarity 0.9799):
[0001327567-23-000014:note_history:3]
We have entered into various non-cancelable agreements with certain service providers, under which we are committed to minimum or fixed purchases. The following table presents details of the aggregate future non-cancelable purchase commitments under these agreements as of April 30, 2023 (in millions):

- added (2023-11-17):
[0001327567-23-000032:note_history:4]
Guarantee

- added (2023-11-17):
[0001327567-23-000032:note_history:5]
In October 2023, we established a multi-currency notional cash pool for a certain number of our entities with a third-party bank. As part of the notional cash pool agreement, the bank extends overdraft credit to our participating entities as needed, provided that the overall notionally pooled balance of all accounts in the pool at the end of each day is positive. In the unlikely event of a default, any overdraft balances incurred would be guaranteed by our collective entities participating in the pool.

- added (2023-11-17):
[0001327567-23-000032:note_history:6]
We are subject to legal proceedings, claims, tax matters, and litigation arising in the ordinary course of business, including, for instance, intellectual property and patent litigation. We accrue for contingencies when we believe that a loss is probable and that we can reasonably estimate the amount of any such loss. As of October 31, 2023, we have not recorded any significant accruals for loss contingencies associated with such matters.

- added (2023-11-17):
[0001327567-23-000032:note_history:7]
Legal matters could include speculative, substantial or indeterminate monetary amounts. Significant judgment is required to determine both the likelihood of there being a loss and the estimated amount of a loss related to such matters, and we may be unable to estimate the reasonably possible loss or range of loss. The outcomes of outstanding legal matters are inherently unpredictable, and could, either individually or in aggregate, have a material adverse effect on us and our results of operations. To the extent there is a reasonable possibility that a loss exceeding any amounts already recognized may be incurred, we will either disclose the estimated additional loss or state that such an estimate cannot be made.

- added (2023-11-17):
[0001327567-23-000032:note_history:8]
The following matters arose in the ordinary course of business.

- added (2023-11-17):
[0001327567-23-000032:note_history:9]
Centripetal Networks, Inc. v. Palo Alto Networks

- added (2023-11-17):
[0001327567-23-000032:note_history:10]
On March 12, 2021, Centripetal Networks, Inc., filed a lawsuit against us in the United States District Court for the Eastern District of Virginia (“E.D.VA”). The lawsuit alleges that our products infringe multiple Centripetal patents. We successfully challenged certain of these patents, which were found unpatentable by the U.S. Patent and Trademark Office. The complaint requests injunctive relief, monetary damages, and attorneys fees. The US District Court E.D.VA has set a trial date of January 22, 2024 on the remaining patents. In addition, Centripetal filed infringement contentions on certain of their patents in the European Patent Office in Germany, to which we filed invalidity challenges. Those matters are still pending. We are unable, at this time, to reasonably estimate a possible loss or potential range of loss, if any.

- added (2023-11-17):
[0001327567-23-000032:note_history:11]
Finjan, Inc. v. Palo Alto Networks

- added (2023-11-17):
[0001327567-23-000032:note_history:12]
On November 4, 2014, Finjan, Inc., filed a lawsuit against us in the United States District Court for the Northern District of California. The lawsuit alleges that our products infringe multiple Finjan patents. The complaint requests injunctive relief, monetary damages, and attorneys fees. The court has moved the trial date from April 8, 2024 to October 21, 2024. We are unable, at this time, to reasonably estimate a possible loss or potential range of loss, if any.

- added (2023-11-17):
[0001327567-23-000032:note_history:13]
Taasera v. Palo Alto Networks

- added (2023-11-17):
[0001327567-23-000032:note_history:14]
On March 22, 2022, we filed a declaratory judgment action in the United States District Court for the Southern District of New York (“S.D.N.Y”) seeking a ruling that we are not infringing various Taasera patents. Taasera challenged jurisdiction in S.D.N.Y, which issue is currently on appeal with the Federal Circuit. Pursuant to an order of the Judicial Panel on Multidistrict Litigation, this matter has been consolidated in the United States District Court for the Eastern District of Texas with several other patent infringement matters brought by Taasera. The court moved the start date to April 15, 2024, as the start of consecutive trials of these consolidated matters. The complaint requests injunctive relief, monetary damages, and attorneys fees. We are unable, at this time, to reasonably estimate a possible loss or potential range of loss, if any.

- removed (2023-11-17):
[0001327567-23-000014:note_history:15]
We are subject to legal proceedings, claims, and litigation arising in the ordinary course of business, including intellectual property litigation. Such matters are subject to many uncertainties and outcomes are not predictable with assurance. We accrue for contingencies when we believe that a loss is probable and that we can reasonably estimate the amount of any such loss.

- removed (2023-11-17):
[0001327567-23-000014:note_history:16]
To the extent there is a reasonable possibility that a loss exceeding amounts already recognized may be incurred and the amount of such additional loss would be material, we will either disclose the estimated additional loss or state that such an estimate cannot be made. As of April 30, 2023, we have not recorded any significant accruals for loss contingencies associated with such legal proceedings, determined that an unfavorable outcome is probable or reasonably possible, or determined that the amount or range of any possible loss is reasonably estimable.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2023-11-17):
[0001327567-23-000032:note_history:17]
Palo Alto Networks, Inc. (the “Company,” “we,” “us,” or “our”), headquartered in Santa Clara, California, was incorporated in March 2005 under the laws of the State of Delaware and commenced operations in April 2005. We empower enterprises, organizations, service providers, and government entities to secure their users, networks, clouds, and endpoints by delivering comprehensive cybersecurity enabled by artificial intelligence and automation.
  (was, 2023-05-24, similarity 0.992):
[0001327567-23-000014:note_history:17]
Palo Alto Networks, Inc. (the “Company,” “we,” “us,” or “our”), headquartered in Santa Clara, California, was incorporated in March 2005 under the laws of the State of Delaware and commenced operations in April 2005. We empower enterprises, organizations, service providers, and government entities to secure their users, networks, clouds, and endpoints by delivering comprehensive cybersecurity backed by artificial intelligence and automation.

- changed (2023-11-17):
[0001327567-23-000032:note_history:18]
The accompanying condensed consolidated financial statements have been prepared in conformity with U.S. generally accepted accounting principles (“U.S. GAAP”), consistent in all material respects with those applied in our Annual Report on Form 10-K for the fiscal year ended July 31, 2023, filed with the Securities and Exchange Commission (“SEC”) on September 1, 2023. The condensed consolidated financial statements include our accounts and our wholly owned subsidiaries. All significant intercompany balances and transactions have been eliminated in consolidation.
  (was, 2023-05-24, similarity 0.99):
[0001327567-23-000014:note_history:18]
The accompanying condensed consolidated financial statements have been prepared in conformity with U.S. generally accepted accounting principles (“GAAP”), consistent in all material respects with those applied in our Annual Report on Form 10-K for the fiscal year ended July 31, 2022, filed with the Securities and Exchange Commission (“SEC”) on September 6, 2022. Our condensed consolidated financial statements include our accounts and our wholly owned subsidiaries. All significant intercompany balances and transactions have been eliminated in consolidation.

- changed (2023-11-17):
[0001327567-23-000032:note_history:19]
The preparation of condensed consolidated financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the amounts reported and disclosed in the condensed consolidated financial statements and the accompanying notes. We base our estimates on assumptions, both historical and forward looking, that we believe are reasonable. Actual results could differ materially from those estimates due to risks and uncertainties, including uncertainty in the current economic environment.
  (was, 2023-05-24, similarity 0.9953):
[0001327567-23-000014:note_history:19]
The preparation of condensed consolidated financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the amounts reported and disclosed in the condensed consolidated financial statements and the accompanying notes. We base our estimates on assumptions, both historical and forward looking, that we believe are reasonable. Actual results could differ materially from those estimates due to risks and uncertainties, including uncertainty in the current economic environment.

- changed (2023-11-17):
[0001327567-23-000032:note_history:20]
There have been no material changes to our significant accounting policies as of and for the three months ended October 31, 2023, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended July 31, 2023.
  (was, 2023-05-24, similarity 0.9022):
[0001327567-23-000014:note_history:20]
There have been no material changes to our significant accounting policies as of and for the nine months ended April 30, 2023, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended July 31, 2022.

- removed (2023-11-17):
[0001327567-23-000014:note_history:21]
Stock Split Effected in the Form of a Stock Dividend (“Stock Split”)

- removed (2023-11-17):
[0001327567-23-000014:note_history:22]
On September 13, 2022, we executed a three-for-one stock split of our common stock, effected in the form of a stock dividend. The par value per share of our common stock remains unchanged at $0.001 per share after the Stock Split. All references made to share or per share amounts on the accompanying condensed consolidated financial statements and applicable disclosures have been retroactively adjusted to reflect the effects of the Stock Split.


## panw:ConvertibleDebtOtherDetailsTableTextBlock (debt) — matched_by: no_current_note, score: 0.0

- removed (2023-11-17):
[0001327567-23-000014:note_history:23]
The following table presents details of our Notes (number of shares in millions):

- removed (2023-11-17):
[0001327567-23-000014:note_history:24]
|  | Conversion Rate per $1,000 Principal |  | Initial Conversion Price |  | Convertible Date |  | Initial Number of Shares |
| 2023 Notes | 11.2635 |  |  | $ | 88.78 |  |  | April 1, 2023 |  | 19.1 |  |
| 2025 Notes | 10.0806 |  |  | $ | 99.20 |  |  | March 1, 2025 |  | 20.1 |  |


## us-gaap:ConvertibleDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-11-17):
[0001327567-23-000032:note_history:25]
The following table sets forth the net carrying amount of our 2025 Notes (in millions):
  (was, 2023-05-24, similarity 0.988):
[0001327567-23-000014:note_history:25]
The following table sets forth the net carrying amount of our Notes (in millions):

- added (2023-11-17):
[0001327567-23-000032:note_history:26]
|  |  |  | October 31, 2023 | July 31, 2023 |
| Principal |  |  | $ | 1,953.3 |  |  |  |  |  |  | $ | 1,999.3 |  |  |  |
| Less: debt issuance costs, net of amortization |  |  | (6.6) |  |  |  |  |  |  | (7.8) |  |  |  |
| Net carrying amount |  |  | $ | 1,946.7 |  |  |  |  |  |  | $ | 1,991.5 |  |  |  |

- removed (2023-11-17):
[0001327567-23-000014:note_history:27]
|  | April 30, 2023 | July 31, 2022 |
|  | 2023 Notes |  | 2025 Notes |  | Total |  | 2023 Notes |  | 2025 Notes |  | Total |
| Principal | $ | 1,691.9 |  |  | $ | 1,999.4 |  |  | $ | 3,691.3 |  |  | $ | 1,691.9 |  |  | $ | 1,999.4 |  |  | $ | 3,691.3 |  |
| Less: debt discount and debt issuance costs, net of amortization | (0.5) |  |  | (8.7) |  |  | (9.2) |  |  | (2.6) |  |  | (11.9) |  |  | (14.5) |  |
| Net carrying amount | $ | 1,691.4 |  |  | $ | 1,990.7 |  |  | $ | 3,682.1 |  |  | $ | 1,689.3 |  |  | $ | 1,987.5 |  |  | $ | 3,676.8 |  |


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-11-17):
[0001327567-23-000032:note_history:28]
In July 2018, we issued $1.7 billion aggregate principal amount of 0.75% Convertible Senior Notes due 2023 (the “2023 Notes”) and in June 2020, we issued $2.0 billion aggregate principal amount of 0.375% Convertible Senior Notes due 2025 (the “2025 Notes,” and together with the 2023 Notes, the “Notes”). The 2023 Notes were converted prior to or settled on the maturity date of July 1, 2023 in accordance with their terms. The 2025 Notes bear interest at a fixed rate of 0.375% per year, payable semi-annually in arrears on June 1 and December 1 of each year, beginning on December 1, 2020. The 2025 Notes are governed by an indenture between us, as the issuer, and U.S. Bank National Association, as Trustee (the “Indenture”). The 2025 Notes are unsecured, unsubordinated obligations and the Indenture governing the 2025 Notes does not contain any financial covenants or restrictions on the payments of dividends, the incurrence of indebtedness, or the issuance or repurchase of securities by us or any of our subsidiaries. The 2025 Notes mature on June 1, 2025. We may redeem for cash all or any portion of the 2025 Notes, at our option, on or after June 5, 2023 and prior to the 31st scheduled trading day immediately preceding the maturity date if the last reported sale price of our common stock has been at least 130% of the conversion price then in effect for at least 20 trading days during any 30 consecutive trading day period ending on and including the trading day preceding the date on which we provide notice of redemption. The redemption will be at a price equal to 100% of the principal amount of the 2025 Notes and adjusted for interest. If we call any or all of the 2025 Notes for redemption, holders may convert such 2025 Notes called for redemption at any time prior to the close of business on the second scheduled trading day immediately preceding the redemption date.
  (was, 2023-05-24, similarity 0.7393):
[0001327567-23-000014:note_history:28]
In July 2018, we issued $1.7 billion aggregate principal amount of 0.75% Convertible Senior Notes due 2023 (the “2023 Notes”) and in June 2020, we issued $2.0 billion aggregate principal amount of 0.375% Convertible Senior Notes due 2025 (the “2025 Notes,” and together with the 2023 Notes, the “Notes”). The 2023 Notes bear interest at a fixed rate of 0.75% per year, payable semi-annually in arrears on January 1 and July 1 of each year, beginning on January 1, 2019. The 2025 Notes bear interest at a fixed rate of 0.375% per year, payable semi-annually in arrears on June 1 and December 1 of each year, beginning on December 1, 2020. Each series of the convertible notes is governed by an indenture between us, as the issuer, and U.S. Bank National Association, as Trustee (individually, each an “Indenture,” and together, the “Indentures”). The Notes of each series are unsecured, unsubordinated obligations and the applicable Indenture governing each series of Notes does not contain any financial covenants or restrictions on the payments of dividends, the incurrence of indebtedness, or the issuance or repurchase of securities by us or any of our subsidiaries. The 2023 Notes and the 2025 Notes mature on July 1, 2023 and June 1, 2025, respectively. We cannot redeem the 2023 Notes prior to maturity. We may redeem for cash all or any portion of the 2025 Notes, at our option, on or after June 5, 2023, and prior to the 31st scheduled trading day immediately preceding the maturity date if the last reported sale price of our common stock has been at least 130% of the conversion price then in effect for at least 20 trading days during any 30 consecutive trading day period ending on and including the trading day preceding the date on which we provide notice of redemption. The redemption will be at a price equal to 100% of the principal amount of the 2025 Notes and adjusted for interest. If we call any or all of the 2025 Notes for redemption, holders may convert such 2025 Notes called for redemption at any time prior to the close of business on the second scheduled trading day immediately preceding the redemption date.

- added (2023-11-17):
[0001327567-23-000032:note_history:29]
The 2025 Notes are convertible for an initial 20.1 million shares of our common stock at a conversion rate of approximately 10.0806 shares of common stock per $1,000 principal amount, which is equal to an initial conversion price of approximately $99.20 per share of common stock, subject to adjustments. Holders of the 2025 Notes may surrender their 2025 Notes for conversion at their option at any time prior to the close of business on the business day immediately preceding March 1, 2025 only under the following circumstances:

- changed (2023-11-17):
[0001327567-23-000032:note_history:30]
•during any fiscal quarter commencing after the fiscal quarters ending on October 31, 2020 (and only during such fiscal quarter), if the last reported sale price of our common stock for at least 20 trading days (whether or not consecutive) during a period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the conversion price for the 2025 Notes on each applicable trading day (the “sale price condition”);
  (was, 2023-05-24, similarity 0.9203):
[0001327567-23-000014:note_history:30]
•during any fiscal quarter commencing after the fiscal quarters ending on October 31, 2018 and October 31, 2020 for the 2023 Notes and the 2025 Notes, respectively (and only during such fiscal quarter), if the last reported sale price of our common stock for at least 20 trading days (whether or not consecutive) during a period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the applicable conversion price for the respective Notes on each applicable trading day (the “sale price condition”);

- changed (2023-11-17):
[0001327567-23-000032:note_history:31]
•during the five business day period after any five consecutive trading day period (the “measurement period”) in which the trading price per $1,000 principal amount of the 2025 Notes for each trading day of the measurement period was less than 98% of the product of the last reported sale price of our common stock and the conversion rate for the 2025 Notes on each such trading day; or
  (was, 2023-05-24, similarity 0.9455):
[0001327567-23-000014:note_history:31]
•during the five business day period after any five consecutive trading day period (the “measurement period”) in which the trading price per $1,000 principal amount of the applicable series of Notes for each trading day of the measurement period was less than 98% of the product of the last reported sale price of our common stock and the applicable conversion rate for the respective Notes on each such trading day; or

- added (2023-11-17):
[0001327567-23-000032:note_history:32]
On or after March 1, 2025, holders may surrender all or any portion of their 2025 Notes for conversion at any time prior to the close of business on the second scheduled trading day immediately preceding the maturity date regardless of the foregoing conditions, and such conversions will be settled upon the maturity date. Upon conversion, holders of the 2025 Notes will receive cash equal to the aggregate principal amount of the 2025 Notes to be converted, and, at our election, cash and/or shares of our common stock for any amounts in excess of the aggregate principal amount of the 2025 Notes being converted.

- changed (2023-11-17):
[0001327567-23-000032:note_history:33]
The conversion price will be subject to adjustment in some events. Holders of the 2025 Notes who convert their 2025 Notes in connection with certain corporate events that constitute a “make-whole fundamental change” under the Indenture are, under certain circumstances, entitled to an increase in the conversion rate. Additionally, upon the occurrence of a corporate event that constitutes a “fundamental change” under the Indenture, holders of the 2025 Notes may require us to repurchase for cash all or a portion of the 2025 Notes at a repurchase price equal to 100% of the principal amount of the 2025 Notes plus accrued and unpaid interest to, but excluding, the fundamental change repurchase date.
  (was, 2023-05-24, similarity 0.8925):
[0001327567-23-000014:note_history:33]
The conversion price will be subject to adjustment in some events. Holders of the Notes of a series who convert their Notes of such series in connection with certain corporate events that constitute a “make-whole fundamental change” under the applicable Indenture are, under certain circumstances, entitled to an increase in the conversion rate for such series of Notes. Additionally, upon the occurrence of a corporate event that constitutes a “fundamental change” under the applicable Indenture, holders of the Notes of such series may require us to repurchase for cash all or a portion of the Notes of such series at a repurchase price equal to 100% of the principal amount of the Notes of such series plus accrued and unpaid interest to, but excluding, the fundamental change repurchase date.

- added (2023-11-17):
[0001327567-23-000032:note_history:34]
Holders of the 2025 Notes were able to early convert their 2025 Notes during the fiscal quarter ended October 31, 2023 as the sales price condition had been met during the fiscal quarter ended July 31, 2023. During the three months ended October 31, 2023, holders of the 2025 Notes converted $46.0 million in aggregate principal amount of the 2025 Notes, which we repaid in cash. We also issued 0.3 million shares of our common stock to the holders of the 2025 Notes for the conversion value in excess of the principal amount. These shares were fully offset by shares we received from the corresponding exercise of the associated note hedges.

- added (2023-11-17):
[0001327567-23-000032:note_history:35]
The sale price condition for the 2025 Notes was met during the fiscal quarter ended October 31, 2023 and as a result, holders may convert their 2025 Notes during the fiscal quarter ending January 31, 2024. The net carrying amount of the 2025 Notes was classified as a current liability on our condensed consolidated balance sheet as of October 31, 2023.

- changed (2023-11-17):
[0001327567-23-000032:note_history:36]
The following table sets forth the net carrying amount of our 2025 Notes (in millions):
  (was, 2023-05-24, similarity 0.988):
[0001327567-23-000014:note_history:36]
The following table sets forth the net carrying amount of our Notes (in millions):

- added (2023-11-17):
[0001327567-23-000032:note_history:37]
|  |  |  | October 31, 2023 | July 31, 2023 |
| Principal |  |  | $ | 1,953.3 |  |  |  |  |  |  | $ | 1,999.3 |  |  |  |
| Less: debt issuance costs, net of amortization |  |  | (6.6) |  |  |  |  |  |  | (7.8) |  |  |  |
| Net carrying amount |  |  | $ | 1,946.7 |  |  |  |  |  |  | $ | 1,991.5 |  |  |  |

- changed (2023-11-17):
[0001327567-23-000032:note_history:38]
The total estimated fair value of the 2025 Notes was $4.8 billion as of October 31, 2023 and $5.0 billion as of July 31, 2023, respectively. The fair value was determined based on the closing trading price per $100 of the 2025 Notes as of the last day of trading for the period. We consider the fair value of the 2025 Notes as of October 31, 2023 and July 31, 2023 to be a Level 2 measurement. The fair value of the 2025 Notes is primarily affected by the trading price of our common stock and market interest rates.
  (was, 2023-05-24, similarity 0.8437):
[0001327567-23-000014:note_history:38]
The total estimated fair value of the 2023 Notes and 2025 Notes were $3.5 billion and $3.7 billion at April 30, 2023, respectively, and $3.2 billion and $3.5 billion at July 31, 2022, respectively. The fair value was determined based on the closing trading price per $100 of the applicable series of the Notes as of the last day of trading for the period. We consider the fair value of the Notes at April 30, 2023 and July 31, 2022 to be a Level 2 measurement. The fair value of the Notes is primarily affected by the trading price of our common stock and market interest rates.

- added (2023-11-17):
[0001327567-23-000032:note_history:39]
|  |  |  | Three Months Ended October 31, |
|  |  |  |  |  | 2023 |  | 2022 |
|  |  |  |  |  |  |  |  |  |  |  |  |  | 2023 Notes |  | 2025 Notes |  | Total |  | 2023 Notes |  | 2025 Notes |  | Total |
| Contractual interest expense |  |  |  |  |  |  |  |  |  |  |  |  | $ | — |  |  | $ | 1.9 |  |  | $ | 1.9 |  |  | $ | 3.2 |  |  | $ | 1.8 |  |  | $ | 5.0 |  |
| Amortization of debt issuance costs |  |  |  |  |  |  |  |  |  |  |  |  | — |  |  | 1.0 |  |  | 1.0 |  |  | 0.7 |  |  | 1.1 |  |  | 1.8 |  |
| Total interest expense |  |  |  |  |  |  |  |  |  |  |  |  | $ | — |  |  | $ | 2.9 |  |  | $ | 2.9 |  |  | $ | 3.9 |  |  | $ | 2.9 |  |  | $ | 6.8 |  |
| Effective interest rate |  |  |  |  |  |  |  |  |  |  |  |  | — | % |  | 0.6 | % |  |  |  | 0.9 | % |  | 0.6 | % |  |  |

- changed (2023-11-17):
[0001327567-23-000032:note_history:40]
To minimize the impact of potential economic dilution upon conversion of our convertible senior notes, we entered into separate convertible note hedge transactions (the “2023 Note Hedges,” with respect to the 2023 Notes, the “2025 Note Hedges,” with respect to the 2025 Notes, and the 2023 Note Hedges together with 2025 Note Hedges, the “Note Hedges”) with respect to our common stock concurrent with the issuance of each series of the Notes.
  (was, 2023-05-24, similarity 0.899):
[0001327567-23-000014:note_history:40]
To minimize the impact of potential economic dilution upon conversion of our Notes, we entered into separate convertible note hedge transactions (the “2023 Note Hedges,” with respect to the 2023 Notes, the “2025 Note Hedges,” with respect to the 2025 Notes, and the 2023 Notes Hedges together with 2025 Note Hedges, the “Note Hedges”) with respect to our common stock concurrent with the issuance of each series of the Notes.

- added (2023-11-17):
[0001327567-23-000032:note_history:41]
Upon the settlement of the 2023 Notes, we exercised the corresponding portion of our 2023 Note Hedges during the year ended July 31, 2023 and received shares of our common stock that fully offset the shares issued in excess of the principal amount of the converted 2023 Notes. The 2023 Note Hedges expired upon maturity of the 2023 Notes.

- changed (2023-11-17):
[0001327567-23-000032:note_history:42]
The 2025 Note Hedges cover up to 20.1 million shares of our common stock at a strike price per share that corresponds to the initial conversion price of the 2025 Notes, which are also subject to adjustment, and are exercisable upon conversion of the 2025 Notes. The 2025 Note Hedges will expire upon maturity of the 2025 Notes. The 2025 Note Hedges are separate transactions and are not part of the terms of the 2025 Notes. Holders of the 2025 Notes will not have any rights with respect to the 2025 Note Hedges. Any shares of our common stock receivable by us under the 2025 Note Hedges are excluded from the calculation of diluted earnings per share as they are antidilutive. We paid an aggregate amount of $370.8 million for the 2025 Note Hedges, which is included in additional paid-in capital on our condensed consolidated balance sheets.
  (was, 2023-05-24, similarity 0.8501):
[0001327567-23-000014:note_history:42]
The Note Hedges cover shares of our common stock at a strike price per share that corresponds to the initial applicable conversion price of the applicable series of the Notes, which are also subject to adjustment, and are exercisable upon conversion of the applicable series of the Notes. The Note Hedges will expire upon maturity of the applicable series of the Notes. The Note Hedges are separate transactions and are not part of the terms of the applicable series of the Notes. Holders of the Notes of either series will not have any rights with respect to the Note Hedges. Any shares of our common stock receivable by us under the Note Hedges are excluded from the calculation of diluted earnings per share as they are antidilutive. The aggregate amounts paid for the Note Hedges are included in additional paid-in capital on our condensed consolidated balance sheets.

- added (2023-11-17):
[0001327567-23-000032:note_history:43]
As a result of the conversions of the 2025 Notes settled during the three months ended October 31, 2023, we exercised the corresponding portion of our 2025 Note Hedges and received 0.3 million shares of our common stock during the period.

- changed (2023-11-17):
[0001327567-23-000032:note_history:44]
Separately, but concurrently with the issuance of each series of our convertible senior notes, we entered into transactions whereby we sold warrants (the “2023 Warrants,” with respect to the 2023 Notes, the “2025 Warrants,” with respect to the 2025 Notes, and the 2023 Warrants together with the 2025 Warrants, the “Warrants”) to acquire shares of our common stock, subject to anti-dilution adjustments. The 2023 Warrants and 2025 Warrants are exercisable over 60 scheduled trading days beginning October 2023 and September 2025, respectively.
  (was, 2023-05-24, similarity 0.9496):
[0001327567-23-000014:note_history:44]
Separately, but concurrently with the issuance of each series of our Notes, we entered into transactions whereby we sold warrants (the “2023 Warrants,” with respect to the 2023 Notes, the “2025 Warrants,” with respect to the 2025 Notes, and the 2023 Warrants together with the 2025 Warrants, the “Warrants”) to acquire shares of our common stock, subject to anti-dilution adjustments. The 2023 Warrants and 2025 Warrants are exercisable beginning October 2023 and September 2025, respectively.

- changed (2023-11-17):
[0001327567-23-000032:note_history:45]
The shares issuable under the Warrants are included in the calculation of diluted earnings per share when the average market value per share of our common stock for the reporting period exceeds the applicable strike price for such series of Warrants. The Warrants are separate transactions and are not part of either series of Notes or Note Hedges and are not remeasured through earnings each reporting period. Holders of the Notes of either series will not have any rights with respect to the Warrants. The aggregate proceeds received from the sale of the Warrants are included in additional paid-in capital on our condensed consolidated balance sheets.
  (was, 2023-05-24, similarity 0.9939):
[0001327567-23-000014:note_history:45]
The shares issuable under the Warrants will be included in the calculation of diluted earnings per share when the average market value per share of our common stock for the reporting period exceeds the applicable strike price for such series of Warrants. The Warrants are separate transactions and are not part of either series of Notes or Note Hedges and are not remeasured through earnings each reporting period. Holders of the Notes of either series will not have any rights with respect to the Warrants. The aggregate proceeds received from the sale of the Warrants are included in additional paid-in capital on our condensed consolidated balance sheets.

- added (2023-11-17):
[0001327567-23-000032:note_history:46]
During the three months ended October 31, 2023, we net settled a portion of the 2023 Warrants with 3.1 million shares of our common stock with a fair value of $763.5 million. The number of net shares issued was determined based on the number of 2023 Warrants exercised multiplied by the difference between the strike price of the 2023 Warrants and their daily volume-weighted-average stock price. As of October 31, 2023, up to 12.1 million shares of our common stock were issuable for gross settlement under the remaining outstanding 2023 Warrants, which will be net settled when exercised through the end of December 2023.

- changed (2023-11-17):
[0001327567-23-000032:note_history:47]
On April 13, 2023, we entered into a credit agreement (the “Credit Agreement”) with certain institutional lenders that provides for a $400.0 million unsecured revolving credit facility (the “Credit Facility”), with an option to increase the amount of the Credit Facility by up to an additional $350.0 million, subject to certain conditions. The Credit Facility matures on April 13, 2028.
  (was, 2023-05-24, similarity 0.8874):
[0001327567-23-000014:note_history:47]
On April 13, 2023, we entered into a new credit agreement (the “2023 Credit Agreement”) with certain institutional lenders that provides for a $400.0 million unsecured revolving credit facility (the “2023 Credit Facility”), with an option to increase the amount of the 2023 Credit Facility by up to an additional $350.0 million, subject to certain conditions. The 2023 Credit Facility matures on April 13, 2028.

- changed (2023-11-17):
[0001327567-23-000032:note_history:48]
The borrowings under the Credit Facility bear interest, at our option, at a base rate plus a spread of 0.000% to 0.375%, or an adjusted term Secured Overnight Financing Rate (“SOFR”) plus a spread of 1.000% to 1.375%, in each case with such spread being determined based on our leverage ratio. We are obligated to pay an ongoing commitment fee on undrawn amounts at a rate of 0.090% to 0.150%, depending on our leverage ratio. The interest rates and commitment fees are also subject to upward and downward adjustments based on our progress towards the achievement of certain sustainability goals related to greenhouse gas emissions.
  (was, 2023-05-24, similarity 0.9984):
[0001327567-23-000014:note_history:48]
The borrowings under the 2023 Credit Facility bear interest, at our option, at a base rate plus a spread of 0.00% to 0.375%, or an adjusted term Secured Overnight Financing Rate (“SOFR”) plus a spread of 1.00% to 1.375%, in each case with such spread being determined based on our leverage ratio. We are obligated to pay an ongoing commitment fee on undrawn amounts at a rate of 0.090% to 0.150%, depending on our leverage ratio. The interest rates and commitment fees are also subject to upward and downward adjustments based on our progress towards the achievement of certain sustainability goals related to greenhouse gas emissions.

- changed (2023-11-17):
[0001327567-23-000032:note_history:49]
As of October 31, 2023, there were no amounts outstanding and we were in compliance with all covenants under the Credit Agreement.
  (was, 2023-05-24, similarity 0.9516):
[0001327567-23-000014:note_history:49]
As of April 30, 2023, there were no amounts outstanding and we were in compliance with all covenants under the 2023 Credit Agreement.

- removed (2023-11-17):
[0001327567-23-000014:note_history:50]
The following table presents details of our Notes (number of shares in millions):

- removed (2023-11-17):
[0001327567-23-000014:note_history:51]
|  | Conversion Rate per $1,000 Principal |  | Initial Conversion Price |  | Convertible Date |  | Initial Number of Shares |
| 2023 Notes | 11.2635 |  |  | $ | 88.78 |  |  | April 1, 2023 |  | 19.1 |  |
| 2025 Notes | 10.0806 |  |  | $ | 99.20 |  |  | March 1, 2025 |  | 20.1 |  |

- removed (2023-11-17):
[0001327567-23-000014:note_history:52]
Holders of the Notes may surrender their Notes for conversion at their option at any time prior to the close of business on the business day immediately preceding their respective convertible dates only under the following circumstances:

- removed (2023-11-17):
[0001327567-23-000014:note_history:53]
On or after the respective convertible date, holders may surrender all or any portion of their Notes for conversion at any time prior to the close of business on the second scheduled trading day immediately preceding the applicable maturity date regardless of the foregoing conditions, and such conversions will be settled upon the applicable maturity date. Upon conversion, holders of the Notes of a series will receive cash equal to the aggregate principal amount of the Notes of such series to be converted, and, at our election, cash and/or shares of our common stock for any amounts in excess of the aggregate principal amount of the Notes of such series being converted.

- removed (2023-11-17):
[0001327567-23-000014:note_history:54]
On or after April 1, 2023, holders may surrender their 2023 Notes for conversion at any time prior to maturity, in accordance with the terms described above. Such conversion requests will settle upon maturity of the 2023 Notes. The sale price condition for the 2025 Notes was met during the fiscal quarter ended April 30, 2023, and as a result, holders may convert their 2025 Notes at any time during the fiscal quarter ending July 31, 2023. The net carrying amount of the Notes was classified as a current liability on our condensed consolidated balance sheet as of April 30, 2023.

- removed (2023-11-17):
[0001327567-23-000014:note_history:55]
|  | April 30, 2023 | July 31, 2022 |
|  | 2023 Notes |  | 2025 Notes |  | Total |  | 2023 Notes |  | 2025 Notes |  | Total |
| Principal | $ | 1,691.9 |  |  | $ | 1,999.4 |  |  | $ | 3,691.3 |  |  | $ | 1,691.9 |  |  | $ | 1,999.4 |  |  | $ | 3,691.3 |  |
| Less: debt discount and debt issuance costs, net of amortization | (0.5) |  |  | (8.7) |  |  | (9.2) |  |  | (2.6) |  |  | (11.9) |  |  | (14.5) |  |
| Net carrying amount | $ | 1,691.4 |  |  | $ | 1,990.7 |  |  | $ | 3,682.1 |  |  | $ | 1,689.3 |  |  | $ | 1,987.5 |  |  | $ | 3,676.8 |  |

- removed (2023-11-17):
[0001327567-23-000014:note_history:56]
|  | Three Months Ended April 30, |  | Nine Months Ended April 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
|  | 2023 Notes |  | 2025 Notes |  | Total |  | 2023 Notes |  | 2025 Notes |  | Total |  | 2023 Notes |  | 2025 Notes |  | Total |  | 2023 Notes |  | 2025 Notes |  | Total |
| Contractual interest expense | $ | 3.2 |  | $ | 1.8 |  | $ | 5.0 |  |  | $ | 3.2 |  | $ | 1.8 |  |  | $ | 5.0 |  | $ | 9.6 |  | $ | 5.6 |  | $ | 15.2 |  |  | $ | 9.5 |  | $ | 5.6 |  | $ | 15.1 |  |
| Amortization of debt issuance costs | 0.7 |  | 1.1 |  | 1.8 |  |  | 0.7 |  | 1.1 |  |  | 1.8 |  | 2.1 |  | 3.2 |  | 5.3 |  |  | 2.1 |  | 3.3 |  | 5.4 |  |
| Total interest expense | $ | 3.9 |  | $ | 2.9 |  | $ | 6.8 |  |  | $ | 3.9 |  | $ | 2.9 |  |  | $ | 6.8 |  | $ | 11.7 |  | $ | 8.8 |  | $ | 20.5 |  |  | $ | 11.6 |  | $ | 8.9 |  | $ | 20.5 |  |
| Effective interest rate | 0.9 | % |  | 0.6 | % |  |  |  | 0.9 | % |  | 0.6 | % |  |  |  | 0.9 | % |  | 0.6 | % |  |  |  | 0.9 | % |  | 0.6 | % |  |  |

- removed (2023-11-17):
[0001327567-23-000014:note_history:57]
The following table presents details of our Note Hedges (in millions):

- removed (2023-11-17):
[0001327567-23-000014:note_history:58]
|  | Initial Number of Shares |  | Aggregate Purchase |
| 2023 Note Hedges | 19.1 |  |  | $ | 332.0 |  |
| 2025 Note Hedges | 20.1 |  |  | $ | 370.8 |  |

- removed (2023-11-17):
[0001327567-23-000014:note_history:59]
On September 4, 2018, we entered into a credit agreement (the “2018 Credit Agreement”) with certain institutional lenders that provides for a $400.0 million unsecured revolving credit facility (the “2018 Credit Facility”), with an option to increase the amount of the 2018 Credit Facility by up to an additional $350.0 million, subject to certain conditions. The 2018 Credit Facility expired in April 2023.


## us-gaap:DebtSecuritiesAvailableForSaleTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-11-17):
[0001327567-23-000032:note_history:60]
The following tables summarize the amortized cost, unrealized gains and losses, and fair value of our available-for-sale debt securities as of October 31, 2023 and July 31, 2023 (in millions):
  (was, 2023-05-24, similarity 0.9724):
[0001327567-23-000014:note_history:60]
The following tables summarize the amortized cost, unrealized gains and losses, and fair value of our available-for-sale debt securities as of April 30, 2023 and July 31, 2022 (in millions):

- changed (2023-11-17):
[0001327567-23-000032:note_history:61]
|  | October 31, 2023 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | $ | 297.0 |  |  | $ | — |  |  | $ | — |  |  | $ | 297.0 |  |
| Corporate debt securities | 8.6 |  |  | — |  |  | — |  |  | 8.6 |  |
| U.S. government and agency securities | 24.9 |  |  | — |  |  | — |  |  | 24.9 |  |
| Total available-for-sale cash equivalents | $ | 330.5 |  |  | $ | — |  |  | $ | — |  |  | $ | 330.5 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 34.0 |  |  | $ | — |  |  | $ | — |  |  | $ | 34.0 |  |
| Commercial paper | 136.9 |  |  | — |  |  | (0.1) |  |  | 136.8 |  |
| Corporate debt securities | 3,453.7 |  |  | 0.1 |  |  | (48.6) |  |  | 3,405.2 |  |
| U.S. government and agency securities | 219.9 |  |  | 0.1 |  |  | (0.8) |  |  | 219.2 |  |
| Non-U.S. government and agency securities | 62.4 |  |  | — |  |  | (0.8) |  |  | 61.6 |  |
| Asset-backed securities | 539.1 |  |  | 0.1 |  |  | (4.7) |  |  | 534.5 |  |
| Total available-for-sale investments | $ | 4,446.0 |  |  | $ | 0.3 |  |  | $ | (55.0) |  |  | $ | 4,391.3 |  |
  (was, 2023-05-24, similarity 0.9615):
[0001327567-23-000014:note_history:61]
|  | April 30, 2023 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | 369.0 |  |  | — |  |  | — |  |  | 369.0 |  |
| Corporate debt securities | 21.0 |  |  | — |  |  | — |  |  | 21.0 |  |
| U.S. government and agency securities | 49.9 |  |  | — |  |  | — |  |  | 49.9 |  |
| Total available-for-sale cash equivalents | $ | 439.9 |  |  | $ | — |  |  | $ | — |  |  | $ | 439.9 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 194.1 |  |  | $ | — |  |  | $ | — |  |  | $ | 194.1 |  |
| Commercial paper | 618.3 |  |  | 0.1 |  |  | (0.5) |  |  | 617.9 |  |
| Corporate debt securities | 2,975.3 |  |  | 6.7 |  |  | (17.5) |  |  | 2,964.5 |  |
| U.S. government and agency securities | 360.9 |  |  | 0.1 |  |  | (3.0) |  |  | 358.0 |  |
| Non-U.S. government and agency securities | 56.3 |  |  | — |  |  | (0.5) |  |  | 55.8 |  |
| Asset-backed securities | 486.2 |  |  | 0.8 |  |  | (2.2) |  |  | 484.8 |  |
| Total available-for-sale investments | $ | 4,691.1 |  |  | $ | 7.7 |  |  | $ | (23.7) |  |  | $ | 4,675.1 |  |

- changed (2023-11-17):
[0001327567-23-000032:note_history:62]
|  | July 31, 2023 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | $ | 151.4 |  |  | $ | — |  |  | $ | — |  |  | $ | 151.4 |  |
| Total available-for-sale cash equivalents | $ | 151.4 |  |  | $ | — |  |  | $ | — |  |  | $ | 151.4 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 48.1 |  |  | $ | — |  |  | $ | — |  |  | $ | 48.1 |  |
| Commercial paper | 214.1 |  |  | — |  |  | (0.3) |  |  | 213.8 |  |
| Corporate debt securities | 3,313.5 |  |  | 1.3 |  |  | (32.5) |  |  | 3,282.3 |  |
| U.S. government and agency securities | 214.2 |  |  | — |  |  | (1.6) |  |  | 212.6 |  |
| Non-U.S. government and agency securities | 37.2 |  |  | — |  |  | (0.6) |  |  | 36.6 |  |
| Asset-backed securities | 512.0 |  |  | 0.2 |  |  | (3.0) |  |  | 509.2 |  |
| Total available-for-sale investments | $ | 4,339.1 |  |  | $ | 1.5 |  |  | $ | (38.0) |  |  | $ | 4,302.6 |  |
  (was, 2023-05-24, similarity 0.795):
[0001327567-23-000014:note_history:62]
|  | July 31, 2022 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 155.3 |  |  | $ | — |  |  | $ | — |  |  | $ | 155.3 |  |
| Commercial paper | 69.1 |  |  | — |  |  | — |  |  | 69.1 |  |
| Corporate debt securities | 19.5 |  |  | — |  |  | — |  |  | 19.5 |  |
| U.S. government and agency securities | 10.0 |  |  | — |  |  | — |  |  | 10.0 |  |
| Non-U.S. government and agency securities | 5.0 |  |  | 0.1 |  |  | — |  |  | 5.1 |  |
| Total available-for-sale cash equivalents | $ | 258.9 |  |  | $ | 0.1 |  |  | $ | — |  |  | $ | 259.0 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 116.5 |  |  | $ | — |  |  | $ | (0.1) |  |  | $ | 116.4 |  |
| Commercial paper | 79.1 |  |  | — |  |  | (0.1) |  |  | 79.0 |  |
| Corporate debt securities | 1,276.8 |  |  | 1.3 |  |  | (11.9) |  |  | 1,266.2 |  |
| U.S. government and agency securities | 928.1 |  |  | 0.1 |  |  | (11.8) |  |  | 916.4 |  |
| Non-U.S. government and agency securities | 17.6 |  |  | — |  |  | (0.2) |  |  | 17.4 |  |
| Asset-backed securities | $ | 173.4 |  |  | $ | 0.2 |  |  | $ | (1.1) |  |  | $ | 172.5 |  |
| Total available-for-sale investments | $ | 2,591.5 |  |  | $ | 1.6 |  |  | $ | (25.2) |  |  | $ | 2,567.9 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-11-17):
[0001327567-23-000032:note_history:63]
The following tables summarize the amortized cost, unrealized gains and losses, and fair value of our available-for-sale debt securities as of October 31, 2023 and July 31, 2023 (in millions):
  (was, 2023-05-24, similarity 0.9724):
[0001327567-23-000014:note_history:63]
The following tables summarize the amortized cost, unrealized gains and losses, and fair value of our available-for-sale debt securities as of April 30, 2023 and July 31, 2022 (in millions):

- changed (2023-11-17):
[0001327567-23-000032:note_history:64]
|  | October 31, 2023 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | $ | 297.0 |  |  | $ | — |  |  | $ | — |  |  | $ | 297.0 |  |
| Corporate debt securities | 8.6 |  |  | — |  |  | — |  |  | 8.6 |  |
| U.S. government and agency securities | 24.9 |  |  | — |  |  | — |  |  | 24.9 |  |
| Total available-for-sale cash equivalents | $ | 330.5 |  |  | $ | — |  |  | $ | — |  |  | $ | 330.5 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 34.0 |  |  | $ | — |  |  | $ | — |  |  | $ | 34.0 |  |
| Commercial paper | 136.9 |  |  | — |  |  | (0.1) |  |  | 136.8 |  |
| Corporate debt securities | 3,453.7 |  |  | 0.1 |  |  | (48.6) |  |  | 3,405.2 |  |
| U.S. government and agency securities | 219.9 |  |  | 0.1 |  |  | (0.8) |  |  | 219.2 |  |
| Non-U.S. government and agency securities | 62.4 |  |  | — |  |  | (0.8) |  |  | 61.6 |  |
| Asset-backed securities | 539.1 |  |  | 0.1 |  |  | (4.7) |  |  | 534.5 |  |
| Total available-for-sale investments | $ | 4,446.0 |  |  | $ | 0.3 |  |  | $ | (55.0) |  |  | $ | 4,391.3 |  |
  (was, 2023-05-24, similarity 0.9615):
[0001327567-23-000014:note_history:64]
|  | April 30, 2023 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | 369.0 |  |  | — |  |  | — |  |  | 369.0 |  |
| Corporate debt securities | 21.0 |  |  | — |  |  | — |  |  | 21.0 |  |
| U.S. government and agency securities | 49.9 |  |  | — |  |  | — |  |  | 49.9 |  |
| Total available-for-sale cash equivalents | $ | 439.9 |  |  | $ | — |  |  | $ | — |  |  | $ | 439.9 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 194.1 |  |  | $ | — |  |  | $ | — |  |  | $ | 194.1 |  |
| Commercial paper | 618.3 |  |  | 0.1 |  |  | (0.5) |  |  | 617.9 |  |
| Corporate debt securities | 2,975.3 |  |  | 6.7 |  |  | (17.5) |  |  | 2,964.5 |  |
| U.S. government and agency securities | 360.9 |  |  | 0.1 |  |  | (3.0) |  |  | 358.0 |  |
| Non-U.S. government and agency securities | 56.3 |  |  | — |  |  | (0.5) |  |  | 55.8 |  |
| Asset-backed securities | 486.2 |  |  | 0.8 |  |  | (2.2) |  |  | 484.8 |  |
| Total available-for-sale investments | $ | 4,691.1 |  |  | $ | 7.7 |  |  | $ | (23.7) |  |  | $ | 4,675.1 |  |

- changed (2023-11-17):
[0001327567-23-000032:note_history:65]
|  | July 31, 2023 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | $ | 151.4 |  |  | $ | — |  |  | $ | — |  |  | $ | 151.4 |  |
| Total available-for-sale cash equivalents | $ | 151.4 |  |  | $ | — |  |  | $ | — |  |  | $ | 151.4 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 48.1 |  |  | $ | — |  |  | $ | — |  |  | $ | 48.1 |  |
| Commercial paper | 214.1 |  |  | — |  |  | (0.3) |  |  | 213.8 |  |
| Corporate debt securities | 3,313.5 |  |  | 1.3 |  |  | (32.5) |  |  | 3,282.3 |  |
| U.S. government and agency securities | 214.2 |  |  | — |  |  | (1.6) |  |  | 212.6 |  |
| Non-U.S. government and agency securities | 37.2 |  |  | — |  |  | (0.6) |  |  | 36.6 |  |
| Asset-backed securities | 512.0 |  |  | 0.2 |  |  | (3.0) |  |  | 509.2 |  |
| Total available-for-sale investments | $ | 4,339.1 |  |  | $ | 1.5 |  |  | $ | (38.0) |  |  | $ | 4,302.6 |  |
  (was, 2023-05-24, similarity 0.795):
[0001327567-23-000014:note_history:65]
|  | July 31, 2022 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 155.3 |  |  | $ | — |  |  | $ | — |  |  | $ | 155.3 |  |
| Commercial paper | 69.1 |  |  | — |  |  | — |  |  | 69.1 |  |
| Corporate debt securities | 19.5 |  |  | — |  |  | — |  |  | 19.5 |  |
| U.S. government and agency securities | 10.0 |  |  | — |  |  | — |  |  | 10.0 |  |
| Non-U.S. government and agency securities | 5.0 |  |  | 0.1 |  |  | — |  |  | 5.1 |  |
| Total available-for-sale cash equivalents | $ | 258.9 |  |  | $ | 0.1 |  |  | $ | — |  |  | $ | 259.0 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 116.5 |  |  | $ | — |  |  | $ | (0.1) |  |  | $ | 116.4 |  |
| Commercial paper | 79.1 |  |  | — |  |  | (0.1) |  |  | 79.0 |  |
| Corporate debt securities | 1,276.8 |  |  | 1.3 |  |  | (11.9) |  |  | 1,266.2 |  |
| U.S. government and agency securities | 928.1 |  |  | 0.1 |  |  | (11.8) |  |  | 916.4 |  |
| Non-U.S. government and agency securities | 17.6 |  |  | — |  |  | (0.2) |  |  | 17.4 |  |
| Asset-backed securities | $ | 173.4 |  |  | $ | 0.2 |  |  | $ | (1.1) |  |  | $ | 172.5 |  |
| Total available-for-sale investments | $ | 2,591.5 |  |  | $ | 1.6 |  |  | $ | (25.2) |  |  | $ | 2,567.9 |  |

- changed (2023-11-17):
[0001327567-23-000032:note_history:66]
As of October 31, 2023, the gross unrealized losses that have been in a continuous unrealized loss position for less than 12 months were $40.4 million, which were related to $3.3 billion of available-for-sale debt securities, and the gross unrealized losses that have been in a continuous unrealized loss position for more than 12 months were $14.6 million, which were related to $922.5 million of available-for-sale debt securities. As of July 31, 2023 the gross unrealized losses that have been in a continuous unrealized loss position for less than 12 months were $30.7 million, which were related to $3.4 billion of available-for-sale debt securities, and the gross unrealized losses that have been in a continuous unrealized loss position for more than 12 months were $7.3 million, which were related to $481.8 million of available-for-sale debt securities.
  (was, 2023-05-24, similarity 0.9327):
[0001327567-23-000014:note_history:66]
As of April 30, 2023, the gross unrealized losses that have been in a continuous unrealized loss position for less than 12 months were $16.6 million, which were related to $2.7 billion of available-for-sale debt securities, and the gross unrealized losses that have been in a continuous unrealized loss position for more than 12 months were $7.1 million, which were related to $474.2 million of available-for-sale debt securities. As of July 31, 2022 the gross unrealized losses that have been in a continuous unrealized loss position for less than 12 months were $24.8 million, which were related to $2.0 billion of available-for-sale debt securities, and the gross unrealized losses that have been in a continuous unrealized loss position for more than 12 months were not material.

- changed (2023-11-17):
[0001327567-23-000032:note_history:67]
Unrealized losses related to our available-for-sale debt securities are primarily due to interest rate fluctuations as opposed to credit quality. We do not intend to sell any of the securities in an unrealized loss position and it is not likely that we would be required to sell these securities before recovery of their amortized cost basis, which may be at maturity. We did not recognize any credit losses related to our available-for-sale debt securities during the three months ended October 31, 2023 and 2022.
  (was, 2023-05-24, similarity 0.9692):
[0001327567-23-000014:note_history:67]
Unrealized losses related to our available-for-sale debt securities are due to interest rate fluctuations as opposed to credit quality. We do not intend to sell any of the securities in an unrealized loss position and it is not likely that we would be required to sell these securities before recovery of their amortized cost basis, which may be at maturity. We did not recognize any credit losses related to our available-for-sale debt securities during the three and nine months ended April 30, 2023 and 2022.

- changed (2023-11-17):
[0001327567-23-000032:note_history:68]
The following table summarizes the amortized cost and fair value of our available-for-sale debt securities as of October 31, 2023, by contractual years-to-maturity (in millions):
  (was, 2023-05-24, similarity 0.9708):
[0001327567-23-000014:note_history:68]
The following table summarizes the amortized cost and fair value of our available-for-sale debt securities as of April 30, 2023, by contractual years-to-maturity (in millions):

- added (2023-11-17):
[0001327567-23-000032:note_history:69]
Marketable equity securities consist of money market funds and are included in cash and cash equivalents on our condensed consolidated balance sheets. As of October 31, 2023 and July 31, 2023, the carrying values of our marketable equity securities were $1.6 billion and $476.1 million, respectively. There were no unrealized gains or losses recognized for these securities during the three months ended October 31, 2023 and 2022.

- removed (2023-11-17):
[0001327567-23-000014:note_history:70]
Marketable equity securities consist of money market funds and are included in cash and cash equivalents on our condensed consolidated balance sheets. As of April 30, 2023 and July 31, 2022, the carrying values of our marketable equity securities were $879.5 million and $1.2 billion, respectively. There were no unrealized gains or losses recognized for these securities during the three and nine months ended April 30, 2023 and 2022.


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2023-11-17):
[0001327567-23-000032:note_history:71]
|  |  |  | Three Months Ended October 31, |
|  |  |  |  |  | 2023 |  | 2022 |
| Revenue: |  |  |  |  |  |  |  |
| Americas |  |  |  |  |  |  |  |
| United States |  |  |  |  | $ | 1,204.3 |  |  | $ | 1,006.3 |  |
| Other Americas |  |  |  |  | 82.3 |  |  | 64.4 |  |
| Total Americas |  |  |  |  | 1,286.6 |  |  | 1,070.7 |  |
| Europe, the Middle East, and Africa (“EMEA”) |  |  |  |  | 364.9 |  |  | 307.9 |  |
| Asia Pacific and Japan (“APAC”) |  |  |  |  | 226.6 |  |  | 184.8 |  |
| Total revenue |  |  |  |  | $ | 1,878.1 |  |  | $ | 1,563.4 |  |

- added (2023-11-17):
[0001327567-23-000032:note_history:72]
|  |  |  | Three Months Ended October 31, |
|  |  |  |  |  | 2023 |  | 2022 |
| Revenue: |  |  |  |  |  |  |  |
| Product |  |  |  |  | $ | 341.1 |  |  | $ | 330.0 |  |
| Subscription and support |  |  |  |  |  |  |  |
| Subscription |  |  |  |  | 988.3 |  |  | 764.0 |  |
| Support |  |  |  |  | 548.7 |  |  | 469.4 |  |
| Total subscription and support |  |  |  |  | 1,537.0 |  |  | 1,233.4 |  |
| Total revenue |  |  |  |  | $ | 1,878.1 |  |  | $ | 1,563.4 |  |

- changed (2023-11-17):
[0001327567-23-000032:note_history:73]
During the three months ended October 31, 2023 and 2022, we recognized approximately $1.4 billion and $1.1 billion of revenue pertaining to amounts that were deferred as of July 31, 2023 and 2022, respectively.
  (was, 2023-05-24, similarity 0.9544):
[0001327567-23-000014:note_history:73]
During the nine months ended April 30, 2023 and 2022, we recognized approximately $2.9 billion and $2.2 billion of revenue pertaining to amounts that were deferred as of July 31, 2022 and 2021, respectively.

- changed (2023-11-17):
[0001327567-23-000032:note_history:74]
Remaining performance obligations were $10.4 billion as of October 31, 2023, of which we expect to recognize as revenue approximately $5.0 billion over the next 12 months and the remainder thereafter.
  (was, 2023-05-24, similarity 0.9733):
[0001327567-23-000014:note_history:74]
Remaining performance obligations were $9.2 billion as of April 30, 2023, of which we expect to recognize as revenue approximately $4.5 billion over the next 12 months and the remainder thereafter.

- removed (2023-11-17):
[0001327567-23-000014:note_history:75]
|  | Three Months Ended April 30, |  | Nine Months Ended April 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Revenue: |  |  |  |  |  |  |  |
| Americas |  |  |  |  |  |  |  |
| United States | $ | 1,105.2 |  |  | $ | 887.2 |  |  | $ | 3,153.8 |  |  | $ | 2,557.5 |  |
| Other Americas | 74.0 |  |  | 61.5 |  |  | 213.1 |  |  | 173.8 |  |
| Total Americas | 1,179.2 |  |  | 948.7 |  |  | 3,366.9 |  |  | 2,731.3 |  |
| Europe, the Middle East, and Africa (“EMEA”) | 332.1 |  |  | 269.5 |  |  | 981.5 |  |  | 755.5 |  |
| Asia Pacific and Japan (“APAC”) | 209.6 |  |  | 168.5 |  |  | 591.0 |  |  | 464.2 |  |
| Total revenue | $ | 1,720.9 |  |  | $ | 1,386.7 |  |  | $ | 4,939.4 |  |  | $ | 3,951.0 |  |

- removed (2023-11-17):
[0001327567-23-000014:note_history:76]
|  | Three Months Ended April 30, |  | Nine Months Ended April 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Revenue: |  |  |  |  |  |  |  |
| Product | $ | 388.1 |  |  | $ | 351.5 |  |  | $ | 1,071.0 |  |  | $ | 955.0 |  |
| Subscription and support |  |  |  |  |  |  |  |
| Subscription | 838.1 |  |  | 639.8 |  |  | 2,417.5 |  |  | 1,836.6 |  |
| Support | 494.7 |  |  | 395.4 |  |  | 1,450.9 |  |  | 1,159.4 |  |
| Total subscription and support | 1,332.8 |  |  | 1,035.2 |  |  | 3,868.4 |  |  | 2,996.0 |  |
| Total revenue | $ | 1,720.9 |  |  | $ | 1,386.7 |  |  | $ | 4,939.4 |  |  | $ | 3,951.0 |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_prior_note, score: 0.0

- added (2023-11-17):
[0001327567-23-000032:note_history:77]
Subsequent Events
Acquisitions

- added (2023-11-17):
[0001327567-23-000032:note_history:78]
On October 29, 2023, we entered into a definitive agreement to acquire Dig Security Solutions Ltd., a privately-held cyber security company (“Dig”), for total consideration of approximately $295.0 million, including approximately $232.0 million in cash and approximately $63.0 million in replacement awards, subject to adjustment. We expect the acquisition will enhance our Prisma Cloud capabilities with a data security posture management solution that is intended to provide customers with visibility into, and secure data stored across, their multi-cloud environments.

- added (2023-11-17):
[0001327567-23-000032:note_history:79]
On November 6, 2023, we entered into a definitive agreement to acquire Talon Cyber Security Ltd., a privately-held cyber security company (“Talon”), for total consideration of approximately $550.0 million, including approximately $434.9 million in cash and approximately $115.1 million in replacement awards, subject to adjustment. We expect the acquisition will support Prisma SASE’s approach to provide secure access to business applications for unmanaged and personal devices with an enterprise browser.

- added (2023-11-17):
[0001327567-23-000032:note_history:80]
The proposed acquisitions of Dig and Talon are expected to close during our second quarter of fiscal 2024, subject to the satisfaction of customary closing conditions.

- added (2023-11-17):
[0001327567-23-000032:note_history:81]
Share Repurchase

- added (2023-11-17):
[0001327567-23-000032:note_history:82]
On November 16, 2023, our board of directors authorized a $316.7 million increase to our share repurchase program, bringing the total remaining authorization for future share repurchases to $1.0 billion. The expiration date of the repurchase authorization was extended to December 31, 2024, and our repurchase program may be suspended or discontinued at any time without prior notice. Repurchases may be made at management’s discretion from time to time on the open market, through privately negotiated transactions, transactions structured through investment banking institutions, block purchase techniques, 10b5-1 trading plans, or a combination of the foregoing.
