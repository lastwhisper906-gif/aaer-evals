# PANW MD&A — 0001327567-23-000032


## mdna

[0001327567-23-000032:mdna:1]
Item 2. Management’s Discussion and Analysis of Financial Condition and Results of Operations

[0001327567-23-000032:mdna:2]
Our Management’s Discussion and Analysis of Financial Condition and Results of Operations (“MD&A”) is organized as follows:

[0001327567-23-000032:mdna:3]
[same as prior period, unchanged from 0001327567-23-000014:mdna:3]

[0001327567-23-000032:mdna:4]
•Key Financial Metrics. A summary of our U.S. GAAP and non-GAAP key financial metrics, which management monitors to evaluate our performance.

[0001327567-23-000032:mdna:5]
•Results of Operations. A discussion of the nature and trends in our financial results and an analysis of our financial results comparing the three months ended October 31, 2023 to the three months ended October 31, 2022.

[0001327567-23-000032:mdna:6]
•Liquidity and Capital Resources. An analysis of changes on our balance sheets and cash flows, and a discussion of our financial condition and our ability to meet cash needs.

[0001327567-23-000032:mdna:7]
[same as prior period, unchanged from 0001327567-23-000014:mdna:7]

[0001327567-23-000032:mdna:8]
- 21 -

[0001327567-23-000032:mdna:9]
[same as prior period, unchanged from 0001327567-23-000014:mdna:9]

[0001327567-23-000032:mdna:10]
We empower enterprises, organizations, service providers, and government entities to protect themselves against today’s most sophisticated cyber threats. Our cybersecurity platforms and services help secure enterprise users, networks, clouds, and endpoints by delivering comprehensive cybersecurity backed by industry-leading artificial intelligence and automation. We are a leading provider of zero trust solutions, starting with next-generation zero trust network access to secure today’s remote hybrid workforces and extending to securing all users, applications, and infrastructure with zero trust principles. Our security solutions are designed to reduce customers’ total cost of ownership by improving operational efficiency and eliminating the need for siloed point products. Our company focuses on delivering value in four fundamental areas:

[0001327567-23-000032:mdna:11]
[same as prior period, unchanged from 0001327567-23-000014:mdna:12]

[0001327567-23-000032:mdna:12]
•Our network security platform, designed to deliver complete zero trust solutions to our customers, includes our hardware and software ML-Powered Next-Generation Firewalls, as well as a cloud-delivered Secure Access Service Edge (“SASE”). Prisma® Access, our Security Services Edge (“SSE”) solution, when combined with Prisma SD-WAN, provides a comprehensive single-vendor SASE offering that is used to secure remote workforces and enable the cloud-delivered branch. We have been recognized as a leader in network firewalls, SASE, SSE, and SD-WAN. Our network security platform also includes our cloud-delivered security services, such as Advanced Threat Prevention, Advanced WildFire®, Advanced URL Filtering, DNS Security, IoT/OT Security, GlobalProtect®, Enterprise Data Loss Prevention (“Enterprise DLP”), Artificial Intelligence for Operations (“AIOps”), SaaS Security API, and SaaS Security Inline. Through these add-on security services, our customers are able to secure their content, applications, users, and devices across their entire organization. Panorama®, our network security management solution, can centrally manage our network security platform irrespective of form factor, location, or scale.

[0001327567-23-000032:mdna:13]
[same as prior period, unchanged from 0001327567-23-000014:mdna:16]

[0001327567-23-000032:mdna:14]
•We enable cloud-native security through our Prisma Cloud platform. As a comprehensive Cloud Native Application Protection Platform (“CNAPP”), Prisma Cloud secures multi- and hybrid-cloud environments for applications, data, and the entire cloud native technology stack across the full development lifecycle, from code to runtime. For inline network security on multi- and hybrid-cloud environments, we also offer our VM-Series and CN-Series Firewall offerings.

[0001327567-23-000032:mdna:15]
[same as prior period, unchanged from 0001327567-23-000014:mdna:18]

[0001327567-23-000032:mdna:16]
•We deliver the next generation of security automation, security analytics, endpoint security, and attack surface management solutions through our Cortex portfolio. These include Cortex XSIAM, our AI-driven security automation platform, Cortex XDR® for the prevention, detection, and response to complex cybersecurity attacks on the endpoint, Cortex XSOAR® for security orchestration, automation, and response (“SOAR”), and Cortex XpanseTM for attack surface management (“ASM”). These products are delivered as SaaS or software subscriptions.

[0001327567-23-000032:mdna:17]
[same as prior period, unchanged from 0001327567-23-000014:mdna:20]

[0001327567-23-000032:mdna:18]
•Unit 42 brings together world-renowned threat researchers with an elite team of incident responders and security consultants to create an intelligence-driven, response-ready organization to help customers proactively manage cyber risk. Our consultants serve as trusted advisors to our customers by assessing and testing their security controls against the right threats, transforming their security strategy with a threat-informed approach, and responding to security incidents on behalf of our clients.

[0001327567-23-000032:mdna:19]
For the first quarter of fiscal 2024 and 2023, total revenue was $1.9 billion and $1.6 billion, respectively, representing year-over-year growth of 20.1%. Our growth reflects the increased adoption of our portfolio, which consists of product, subscriptions, and support. We believe our portfolio will enable us to benefit from recurring revenues and new revenues as we continue to grow our end-customer base. As of October 31, 2023, we had end-customers in over 180 countries. Our end-customers represent a broad range of industries, including education, energy, financial services, government entities, healthcare, Internet and media, manufacturing, public sector, and telecommunications, and include almost all of the Fortune 100 companies and a majority of the Global 2000 companies. We maintain a field sales force that works closely with our channel partners in developing sales opportunities. We primarily use a two-tiered, indirect fulfillment model whereby we sell our products, subscriptions, and support to our distributors, which, in turn, sell to our resellers, which then sell to our end-customers.

[0001327567-23-000032:mdna:20]
- 22 -

[0001327567-23-000032:mdna:21]
Our product revenue grew to $341.1 million, or 18.2% of total revenue, for the first quarter of fiscal 2024, representing year-over-year growth of 3.4%. Product revenue is derived from sales of our appliances, primarily our ML-Powered Next-Generation Firewall. Product revenue also includes revenue derived from software licenses of Panorama, SD-WAN, and the VM-Series. Our ML-Powered Next-Generation Firewall incorporates our PAN-OS operating system, which provides a consistent set of capabilities across our entire network security product line. Our appliances and software licenses include a broad set of built-in networking and security features and functionalities. Our products are designed for different performance requirements throughout an organization, ranging from our PA-410, which is designed for small organizations and remote or branch offices, to our top-of-the-line PA-7080, which is designed for large-scale data centers and service provider use. The same firewall functionality that is delivered in our physical appliances is also available in our VM-Series virtual firewalls, which secure virtualized and cloud-based computing environments, and in our CN-Series container firewalls, which secure container environments and traffic.

[0001327567-23-000032:mdna:22]
Our subscription and support revenue grew to $1.5 billion, or 81.8% of total revenue, for the first quarter of fiscal 2024, representing year-over-year growth of 24.6%. Our subscriptions provide our end-customers with near real-time access to the latest antivirus, intrusion prevention, web filtering, modern malware prevention, data loss prevention, and cloud access security broker capabilities across the network, endpoints, and the cloud. When end-customers purchase our physical, virtual, or container firewall appliances, or certain cloud offerings, they typically purchase support in order to receive ongoing security updates, upgrades, bug fixes, and repairs. In addition to the subscriptions purchased with these appliances, end-customers may also purchase other subscriptions on a per-user, per-endpoint, or capacity-based basis. We also offer professional services, including incident response, risk management, and digital forensic services.

[0001327567-23-000032:mdna:23]
We continue to invest in innovation as we evolve and further extend the capabilities of our portfolio, as we believe that innovation and timely development of new features and products are essential to meeting the needs of our end-customers and improving our competitive position. For example, in October 2023, we enhanced our Prisma Cloud capabilities with new integrated Code to Cloud intelligence for developers, operations, and security teams to improve productivity and collaboration across code, infrastructure, and runtime.

[0001327567-23-000032:mdna:24]
[same as prior period, unchanged from 0001327567-23-000014:mdna:27]

[0001327567-23-000032:mdna:25]
[same as prior period, unchanged from 0001327567-23-000014:mdna:28]

[0001327567-23-000032:mdna:26]
Our overall performance depends in part on worldwide economic and geopolitical conditions and their impact on customer behavior. Worsening economic conditions, including inflation, higher interest rates, slower growth, fluctuations in foreign exchange rates, supply chain disruptions, and other conditions, may adversely affect our results of operations and financial performance.

[0001327567-23-000032:mdna:27]
The recent hostilities in Israel and the surrounding region have increased the levels of economic and political uncertainty. While we have business operations in Israel, and intend to continue growing our presence in Israel, we currently do not expect significant business disruption. We are actively monitoring, evaluating, and responding to the developing situation.

[0001327567-23-000032:mdna:28]
We are also monitoring the impact of inflationary pressures and the tensions between China and Taiwan, and between the U.S. and China, which could have an adverse impact on our business or results of operations in future periods.

[0001327567-23-000032:mdna:29]
[same as prior period, unchanged from 0001327567-23-000014:mdna:11]

[0001327567-23-000032:mdna:30]
[same as prior period, unchanged from 0001327567-23-000014:mdna:32]

[0001327567-23-000032:mdna:31]
We monitor the key financial metrics set forth in the tables below to help us evaluate growth trends, establish budgets, measure the effectiveness of our sales and marketing efforts, and assess operational efficiencies. We discuss revenue, gross margin, and the components of operating income and margin below under “Results of Operations.”

[0001327567-23-000032:mdna:32]
|  | October 31, 2023 |  | July 31, 2023 |
|  | (in millions) |
| Total deferred revenue | $ | 9,442.8 |  |  | $ | 9,296.4 |  |
| Cash, cash equivalents, and investments | $ | 6,882.7 |  |  | $ | 5,437.9 |  |

[0001327567-23-000032:mdna:33]
|  |  |  | Three Months Ended October 31, |
|  |  |  |  |  | 2023 |  | 2022 |
|  |  |  |  |  | (dollars in millions) |
| Total revenue |  |  |  |  | $ | 1,878.1 |  |  | $ | 1,563.4 |  |
| Total revenue year-over-year percentage increase |  |  |  |  | 20.1 | % |  | 25.3 | % |
| Gross margin |  |  |  |  | 74.8 | % |  | 70.5 | % |
| Operating income |  |  |  |  | $ | 215.2 |  |  | $ | 15.2 |  |
| Operating margin |  |  |  |  | 11.5 | % |  | 1.0 | % |
| Billings |  |  |  |  | $ | 2,024.5 |  |  | $ | 1,749.0 |  |
| Billings year-over-year percentage increase |  |  |  |  | 15.8 | % |  | 26.6 | % |
| Cash flow provided by operating activities |  |  |  |  | $ | 1,526.0 |  |  | $ | 1,236.7 |  |
| Free cash flow (non-GAAP) |  |  |  |  | $ | 1,489.2 |  |  | $ | 1,197.1 |  |

[0001327567-23-000032:mdna:34]
[same as prior period, unchanged from 0001327567-23-000014:mdna:36]

[0001327567-23-000032:mdna:35]
[same as prior period, unchanged from 0001327567-23-000014:mdna:37]

[0001327567-23-000032:mdna:36]
|  |  |  | Three Months Ended October 31, |
|  |  |  |  |  | 2023 |  | 2022 |
|  |  |  | (in millions) |
| Billings: |  |  |  |  |  |  |  |
| Total revenue |  |  |  |  | $ | 1,878.1 |  |  | $ | 1,563.4 |  |
| Add: change in total deferred revenue, net of acquired deferred revenue |  |  |  |  | 146.4 |  |  | 185.6 |  |
| Billings |  |  |  |  | $ | 2,024.5 |  |  | $ | 1,749.0 |  |

[0001327567-23-000032:mdna:37]
[same as prior period, unchanged from 0001327567-23-000014:mdna:23]

[0001327567-23-000032:mdna:38]
•Cash Flow Provided by Operating Activities. We monitor cash flow provided by operating activities as a measure of our overall business performance. Our cash flow provided by operating activities is driven in large part by sales of our products and from up-front payments for subscription and support offerings. Monitoring cash flow provided by operating activities enables us to analyze our financial performance without the non-cash effects of certain items such as share-based compensation costs, depreciation and amortization, thereby allowing us to better understand and manage the cash needs of our business.

[0001327567-23-000032:mdna:39]
•Free Cash Flow (non-GAAP). We define free cash flow, a non-GAAP financial measure, as cash provided by operating activities less purchases of property, equipment, and other assets. We consider free cash flow to be a profitability and liquidity measure that provides useful information to management and investors about the amount of cash generated by the business after necessary capital expenditures. A limitation of the utility of free cash flow as a measure of our financial performance and liquidity is that it does not represent the total increase or decrease in our cash balance for the period. In addition, it is important to note that other companies, including companies in our industry, may not use free cash flow, may calculate free cash flow in a different manner than we do, or may use other financial measures to evaluate their performance, all of which could reduce the usefulness of free cash flow as a comparative measure. A reconciliation of free cash flow to cash flow provided by operating activities, the most directly comparable financial measure calculated and presented in accordance with U.S. GAAP, is provided below:

[0001327567-23-000032:mdna:40]
|  | Three Months Ended October 31, |
|  | 2023 |  | 2022 |
|  | (in millions) |
| Free cash flow (non-GAAP): |  |  |  |
| Net cash provided by operating activities | $ | 1,526.0 |  |  | $ | 1,236.7 |  |
| Less: purchases of property, equipment, and other assets | 36.8 |  |  | 39.6 |  |
| Free cash flow (non-GAAP) | $ | 1,489.2 |  |  | $ | 1,197.1 |  |
| Net cash used in investing activities | $ | (129.0) |  |  | $ | (1,319.8) |  |
| Net cash provided by (used in) financing activities | $ | (41.8) |  |  | $ | 31.1 |  |

[0001327567-23-000032:mdna:41]
[same as prior period, unchanged from 0001327567-23-000014:mdna:31]

[0001327567-23-000032:mdna:42]
[same as prior period, unchanged from 0001327567-23-000014:mdna:44]

[0001327567-23-000032:mdna:43]
[same as prior period, unchanged from 0001327567-23-000014:mdna:45]

[0001327567-23-000032:mdna:44]
|  |  |  | Three Months Ended October 31, |
|  |  |  |  |  | 2023 |  | 2022 |
|  |  |  |  |  |  |  |  |  | Amount |  | % of Revenue |  | Amount |  | % of Revenue |
|  |  |  |  |  |  |  |  |  | (dollars in millions) |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  |  |  |  |  |  |  |  | $ | 341.1 |  |  | 18.2 | % |  | $ | 330.0 |  |  | 21.1 | % |
| Subscription and support |  |  |  |  |  |  |  |  | 1,537.0 |  |  | 81.8 | % |  | 1,233.4 |  |  | 78.9 | % |
| Total revenue |  |  |  |  |  |  |  |  | 1,878.1 |  |  | 100.0 | % |  | 1,563.4 |  |  | 100.0 | % |
| Cost of revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  |  |  |  |  |  |  |  | 77.4 |  |  | 4.1 | % |  | 120.1 |  |  | 7.7 | % |
| Subscription and support |  |  |  |  |  |  |  |  | 395.4 |  |  | 21.1 | % |  | 341.8 |  |  | 21.8 | % |
| Total cost of revenue(1) |  |  |  |  |  |  |  |  | 472.8 |  |  | 25.2 | % |  | 461.9 |  |  | 29.5 | % |
| Total gross profit |  |  |  |  |  |  |  |  | 1,405.3 |  |  | 74.8 | % |  | 1,101.5 |  |  | 70.5 | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development |  |  |  |  |  |  |  |  | 409.5 |  |  | 21.8 | % |  | 371.8 |  |  | 23.8 | % |
| Sales and marketing |  |  |  |  |  |  |  |  | 660.5 |  |  | 35.1 | % |  | 615.0 |  |  | 39.3 | % |
| General and administrative |  |  |  |  |  |  |  |  | 120.1 |  |  | 6.4 | % |  | 99.5 |  |  | 6.4 | % |
| Total operating expenses(1) |  |  |  |  |  |  |  |  | 1,190.1 |  |  | 63.3 | % |  | 1,086.3 |  |  | 69.5 | % |
| Operating income |  |  |  |  |  |  |  |  | 215.2 |  |  | 11.5 | % |  | 15.2 |  |  | 1.0 | % |
| Interest expense |  |  |  |  |  |  |  |  | (2.9) |  |  | (0.2 | %) |  | (6.8) |  |  | (0.4) | % |
| Other income, net |  |  |  |  |  |  |  |  | 70.3 |  |  | 3.7 | % |  | 26.0 |  |  | 1.6 | % |
| Income before income taxes |  |  |  |  |  |  |  |  | 282.6 |  |  | 15.0 | % |  | 34.4 |  |  | 2.2 | % |
| Provision for income taxes |  |  |  |  |  |  |  |  | 88.4 |  |  | 4.7 | % |  | 14.4 |  |  | 0.9 | % |
| Net income |  |  |  |  |  |  |  |  | $ | 194.2 |  |  | 10.3 | % |  | $ | 20.0 |  |  | 1.3 | % |

[0001327567-23-000032:mdna:45]
[same as prior period, unchanged from 0001327567-23-000014:mdna:48]

[0001327567-23-000032:mdna:46]
|  |  |  | Three Months Ended October 31, |
|  |  |  |  |  | 2023 |  | 2022 |
|  |  |  |  |  | (in millions) |
| Cost of product revenue |  |  |  |  | $ | 2.4 |  |  | $ | 2.4 |  |
| Cost of subscription and support revenue |  |  |  |  | 30.6 |  |  | 28.8 |  |
| Research and development |  |  |  |  | 120.1 |  |  | 118.0 |  |
| Sales and marketing |  |  |  |  | 79.2 |  |  | 87.4 |  |
| General and administrative |  |  |  |  | 38.7 |  |  | 29.4 |  |
| Total share-based compensation |  |  |  |  | $ | 271.0 |  |  | $ | 266.0 |  |

[0001327567-23-000032:mdna:47]
[same as prior period, unchanged from 0001327567-23-000014:mdna:39]

[0001327567-23-000032:mdna:48]
REVENUE

[0001327567-23-000032:mdna:49]
[same as prior period, unchanged from 0001327567-23-000014:mdna:51]

[0001327567-23-000032:mdna:50]
PRODUCT REVENUE

[0001327567-23-000032:mdna:51]
Product revenue is derived from sales of our appliances, primarily our ML-Powered Next-Generation Firewall. Product revenue also includes revenue derived from software licenses of Panorama, SD-WAN, and the VM-Series. Our appliances and software licenses include a broad set of built-in networking and security features and functionalities. We recognize product revenue at the time of hardware shipment or delivery of software license.

[0001327567-23-000032:mdna:52]
|  |  |  |  |  |  |  | Three Months Ended October 31, |  |  |  |  |
|  |  |  |  |  |  |  | 2023 |  | 2022 |  | Change |
|  |  |  |  |  |  |  |  |  | Amount |  | Amount |  | Amount |  | % |
|  |  |  |  |  |  |  |  |  | (dollars in millions) |
| Product |  |  |  |  |  |  |  |  | $ | 341.1 |  |  | $ | 330.0 |  |  | $ | 11.1 |  |  | 3.4 | % |

[0001327567-23-000032:mdna:53]
Product revenue for the three months ended October 31, 2023 increased compared to the same period in 2022 driven by increased software revenue primarily due to a new go-to-market strategy for certain Network Security offerings, and increased demand for our new generation of hardware products, partially offset by decreased revenue from our prior generation of hardware products.

[0001327567-23-000032:mdna:54]
SUBSCRIPTION AND SUPPORT REVENUE

[0001327567-23-000032:mdna:55]
Subscription and support revenue is derived primarily from sales of our subscription and support offerings. Our subscription and support contracts are typically one to five years. We recognize revenue from subscriptions and support over time as the services are performed. As a percentage of total revenue, we expect our subscription and support revenue to vary from quarter to quarter and increase over the long term as we introduce new subscriptions, renew existing subscription and support contracts, and expand our installed end-customer base.

[0001327567-23-000032:mdna:56]
|  |  |  |  |  |  |  | Three Months Ended October 31, |  |  |  |  |
|  |  |  |  |  |  |  | 2023 |  | 2022 |  | Change |
|  |  |  |  |  |  |  |  |  | Amount |  | Amount |  | Amount |  | % |
|  |  |  |  |  |  |  |  |  | (dollars in millions) |
| Subscription |  |  |  |  |  |  |  |  | $ | 988.3 |  |  | $ | 764.0 |  |  | $ | 224.3 |  |  | 29.4 | % |
| Support |  |  |  |  |  |  |  |  | 548.7 |  |  | 469.4 |  |  | 79.3 |  |  | 16.9 | % |
| Total subscription and support |  |  |  |  |  |  |  |  | $ | 1,537.0 |  |  | $ | 1,233.4 |  |  | $ | 303.6 |  |  | 24.6 | % |

[0001327567-23-000032:mdna:57]
Subscription and support revenue increased for the three months ended October 31, 2023 compared to the same period in 2022 due to increased demand for our subscription and support offerings from our end-customers. The mix between subscription revenue and support revenue will fluctuate over time, depending on the introduction of new subscription offerings, renewals of support services, and our ability to increase sales to new and existing end-customers.

[0001327567-23-000032:mdna:58]
[same as prior period, unchanged from 0001327567-23-000014:mdna:43]

[0001327567-23-000032:mdna:59]
REVENUE BY GEOGRAPHIC THEATER

[0001327567-23-000032:mdna:60]
|  |  |  |  |  |  |  | Three Months Ended October 31, |  |  |  |  |
|  |  |  |  |  |  |  | 2023 |  | 2022 |  | Change |
|  |  |  |  |  |  |  |  |  | Amount |  | Amount |  | Amount |  | % |
|  |  |  |  |  |  |  |  |  | (dollars in millions) |
| Americas |  |  |  |  |  |  |  |  | $ | 1,286.6 |  |  | $ | 1,070.7 |  |  | $ | 215.9 |  |  | 20.2 | % |
| EMEA |  |  |  |  |  |  |  |  | 364.9 |  |  | 307.9 |  |  | 57.0 |  |  | 18.5 | % |
| APAC |  |  |  |  |  |  |  |  | 226.6 |  |  | 184.8 |  |  | 41.8 |  |  | 22.6 | % |
| Total revenue |  |  |  |  |  |  |  |  | $ | 1,878.1 |  |  | $ | 1,563.4 |  |  | $ | 314.7 |  |  | 20.1 | % |

[0001327567-23-000032:mdna:61]
Revenue from the Americas, Europe, the Middle East, and Africa (“EMEA”), and Asia Pacific and Japan (“APAC”), increased for the three months ended October 31, 2023 compared to the same period in 2022 as we continued to increase investment in our global sales force in order to support our growth and innovation. Our three geographic theaters had similar year-over-year revenue growth rates for the three months ended October 31, 2023 compared to the same period in 2022, with the Americas contributing the highest increase in revenue due to its larger scale.

[0001327567-23-000032:mdna:62]
COST OF REVENUE

[0001327567-23-000032:mdna:63]
[same as prior period, unchanged from 0001327567-23-000014:mdna:66]

[0001327567-23-000032:mdna:64]
COST OF PRODUCT REVENUE

[0001327567-23-000032:mdna:65]
Cost of product revenue primarily includes costs paid to our manufacturing partners for procuring components and manufacturing our products. Our cost of product revenue also includes personnel costs, which consist of salaries, benefits, bonuses, share-based compensation, and travel associated with our operations organization, amortization of intellectual property licenses, product testing costs, shipping and tariff costs, and shared costs. Shared costs consist of certain facilities, depreciation, benefits, recruiting, and information technology costs that we allocate based on headcount. We expect our cost of product revenue to fluctuate with our revenue from hardware products.

[0001327567-23-000032:mdna:66]
|  |  |  |  |  |  |  | Three Months Ended October 31, |  |  |  |  |
|  |  |  |  |  |  |  | 2023 |  | 2022 |  | Change |
|  |  |  |  |  |  |  |  |  | Amount |  | Amount |  | Amount |  | % |
|  |  |  |  |  |  |  |  |  | (dollars in millions) |
| Cost of product revenue |  |  |  |  |  |  |  |  | $ | 77.4 |  |  | $ | 120.1 |  |  | $ | (42.7) |  |  | (35.6) | % |

[0001327567-23-000032:mdna:67]
Cost of product revenue decreased for the three months ended October 31, 2023 compared to the same period in 2022 primarily due to lower costs largely driven by an easing of supply chain challenges and decreased demand for our prior generation of hardware products.

[0001327567-23-000032:mdna:68]
[same as prior period, unchanged from 0001327567-23-000014:mdna:52]

[0001327567-23-000032:mdna:69]
COST OF SUBSCRIPTION AND SUPPORT REVENUE

[0001327567-23-000032:mdna:70]
[same as prior period, unchanged from 0001327567-23-000014:mdna:72]

[0001327567-23-000032:mdna:71]
|  |  |  |  |  |  |  | Three Months Ended October 31, |  |  |  |  |
|  |  |  |  |  |  |  | 2023 |  | 2022 |  | Change |
|  |  |  |  |  |  |  |  |  | Amount |  | Amount |  | Amount |  | % |
|  |  |  |  |  |  |  |  |  | (dollars in millions) |
| Cost of subscription and support revenue |  |  |  |  |  |  |  |  | $ | 395.4 |  |  | $ | 341.8 |  |  | $ | 53.6 |  |  | 15.7 | % |

[0001327567-23-000032:mdna:72]
Cost of subscription and support revenue increased for the three months ended October 31, 2023 compared to the same period in 2022 primarily due to increased costs to support the growth of our subscription and support offerings. Cloud hosting service costs, which support our cloud-based subscription offerings, increased $26.2 million for the three months ended October 31, 2023 compared to the same period in 2022. Personnel costs grew $23.0 million for the three months ended October 31, 2023 compared to the same period in 2022 primarily due to headcount growth.

[0001327567-23-000032:mdna:73]
GROSS MARGIN

[0001327567-23-000032:mdna:74]
[same as prior period, unchanged from 0001327567-23-000014:mdna:77]

[0001327567-23-000032:mdna:75]
|  |  |  | Three Months Ended October 31, |
|  |  |  |  |  | 2023 |  | 2022 |
|  |  |  |  |  |  |  |  |  | Amount |  | Gross Margin |  | Amount |  | Gross Margin |
|  |  |  |  |  |  |  |  |  | (dollars in millions) |
| Product |  |  |  |  |  |  |  |  | $ | 263.7 |  |  | 77.3 | % |  | $ | 209.9 |  |  | 63.6 | % |
| Subscription and support |  |  |  |  |  |  |  |  | 1,141.6 |  |  | 74.3 | % |  | 891.6 |  |  | 72.3 | % |
| Total gross profit |  |  |  |  |  |  |  |  | $ | 1,405.3 |  |  | 74.8 | % |  | $ | 1,101.5 |  |  | 70.5 | % |

[0001327567-23-000032:mdna:76]
Product gross margin increased for the three months ended October 31, 2023 compared to the same period in 2022 primarily due to lower costs largely driven by an easing of supply chain challenges and increased software revenue.

[0001327567-23-000032:mdna:77]
Subscription and support gross margin increased for the three months ended October 31, 2023 compared to the same period in 2022 primarily due to our growth in subscription and support revenue, which outpaced the subscription and support costs.

[0001327567-23-000032:mdna:78]
OPERATING EXPENSES

[0001327567-23-000032:mdna:79]
Our operating expenses consist of research and development, sales and marketing, and general and administrative expenses. Personnel costs are the most significant component of operating expenses and consist of salaries, benefits, bonuses, share-based compensation, travel and entertainment, and with regard to sales and marketing expense, sales commissions. Our operating expenses also include shared costs, which consist of certain facilities, depreciation, benefits, recruiting, and information technology costs that we allocate based on headcount to each department. We expect operating expenses generally to increase in absolute dollars and decrease over the long term as a percentage of revenue as we continue to scale our business. As of October 31, 2023, we expect to recognize approximately $1.9 billion of share-based compensation expense over a weighted-average period of approximately 2.7 years, excluding additional share-based compensation expense related to any future grants of share-based awards. Share-based compensation expense is generally recognized on a straight-line basis over the requisite service periods of the awards.

[0001327567-23-000032:mdna:80]
[same as prior period, unchanged from 0001327567-23-000014:mdna:64]

[0001327567-23-000032:mdna:81]
RESEARCH AND DEVELOPMENT

[0001327567-23-000032:mdna:82]
[same as prior period, unchanged from 0001327567-23-000014:mdna:84]

[0001327567-23-000032:mdna:83]
|  |  |  |  |  |  |  | Three Months Ended October 31, |  |  |  |  |
|  |  |  |  |  |  |  | 2023 |  | 2022 |  | Change |
|  |  |  |  |  |  |  |  |  | Amount |  | Amount |  | Amount |  | % |
|  |  |  |  |  |  |  |  |  | (dollars in millions) |
| Research and development |  |  |  |  |  |  |  |  | $ | 409.5 |  |  | $ | 371.8 |  |  | $ | 37.7 |  |  | 10.1 | % |

[0001327567-23-000032:mdna:84]
Research and development expense increased for the three months ended October 31, 2023 compared to the same period in 2022 primarily due to increased personnel costs, which grew $27.4 million, largely due to headcount growth.

[0001327567-23-000032:mdna:85]
SALES AND MARKETING

[0001327567-23-000032:mdna:86]
Sales and marketing expense consists primarily of personnel costs, including commission expense. Sales and marketing expense also includes costs for market development programs, promotional and other marketing costs, professional services, and shared costs. We continue to strategically invest in headcount and have grown our sales presence. We expect sales and marketing expense to continue to increase in absolute dollars as we increase the size of our sales and marketing organizations to grow our customer base, increase touch points with end-customers, and expand our global presence, although our sales and marketing expense may fluctuate as a percentage of total revenue.

[0001327567-23-000032:mdna:87]
|  |  |  |  |  |  |  | Three Months Ended October 31, |  |  |  |  |
|  |  |  |  |  |  |  | 2023 |  | 2022 |  | Change |
|  |  |  |  |  |  |  |  |  | Amount |  | Amount |  | Amount |  | % |
|  |  |  |  |  |  |  |  |  | (dollars in millions) |
| Sales and marketing |  |  |  |  |  |  |  |  | $ | 660.5 |  |  | $ | 615.0 |  |  | $ | 45.5 |  |  | 7.4 | % |

[0001327567-23-000032:mdna:88]
Sales and marketing expense increased for the three months ended October 31, 2023 compared to the same period in 2022 primarily due to increased personnel costs, which grew $21.8 million, largely due to headcount growth. The increase in sales and marketing expense was further driven by increased costs associated with sales and marketing events and go-to-market initiatives.

[0001327567-23-000032:mdna:89]
GENERAL AND ADMINISTRATIVE

[0001327567-23-000032:mdna:90]
[same as prior period, unchanged from 0001327567-23-000014:mdna:93]

[0001327567-23-000032:mdna:91]
|  |  |  |  |  |  |  | Three Months Ended October 31, |  |  |  |  |
|  |  |  |  |  |  |  | 2023 |  | 2022 |  | Change |
|  |  |  |  |  |  |  |  |  | Amount |  | Amount |  | Amount |  | % |
|  |  |  |  |  |  |  |  |  | (dollars in millions) |
| General and administrative |  |  |  |  |  |  |  |  | $ | 120.1 |  |  | $ | 99.5 |  |  | $ | 20.6 |  |  | 20.7 | % |

[0001327567-23-000032:mdna:92]
General and administrative expense increased for the three months ended October 31, 2023 compared to the same period in 2022 primarily due to increased personnel costs, which grew $12.8 million, largely due to increased share-based compensation and headcount growth. The increase in general and administrative expense was further driven by increased professional services expense during the three months ended October 31, 2023.

[0001327567-23-000032:mdna:93]
[same as prior period, unchanged from 0001327567-23-000014:mdna:75]

[0001327567-23-000032:mdna:94]
INTEREST EXPENSE

[0001327567-23-000032:mdna:95]
Interest expense primarily consists of interest expense related to our 0.75% Convertible Senior Notes due 2023 (the “2023 Notes”) and our 0.375% Convertible Senior Notes due 2025 (the “2025 Notes,” and together with “2023 Notes,” the “Notes”).

[0001327567-23-000032:mdna:96]
|  |  |  |  |  | Three Months Ended October 31, |  |  |
|  |  |  |  |  |  |  | 2023 |  | 2022 |  | Change |
|  |  |  |  |  |  |  |  |  | Amount |  | Amount |  | Amount |  | % |
|  |  |  |  |  |  |  |  |  | (dollars in millions) |
| Interest expense |  |  |  |  |  |  |  |  | $ | 2.9 |  |  | $ | 6.8 |  |  | $ | (3.9) |  |  | (57.4) | % |

[0001327567-23-000032:mdna:97]
Interest expense decreased for the three months ended October 31, 2023 compared to the same period in 2022 primarily due to conversions of the 2023 Notes prior to or upon maturity in July 2023. Refer to Note 8. Debt in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information on the Notes.

[0001327567-23-000032:mdna:98]
OTHER INCOME, NET

[0001327567-23-000032:mdna:99]
[same as prior period, unchanged from 0001327567-23-000014:mdna:102]

[0001327567-23-000032:mdna:100]
|  |  |  |  |  | Three Months Ended October 31, |  |  |
|  |  |  |  |  |  |  | 2023 |  | 2022 |  | Change |
|  |  |  |  |  |  |  |  |  | Amount |  | Amount |  | Amount |  | % |
|  |  |  |  |  |  |  |  |  | (dollars in millions) |
| Other income, net |  |  |  |  |  |  |  |  | $ | 70.3 |  |  | $ | 26.0 |  |  | $ | 44.3 |  |  | 170.4 | % |

[0001327567-23-000032:mdna:101]
Other income, net increased for the three months ended October 31, 2023 compared to the same period in 2022 primarily due to higher interest income as a result of higher interest rates and higher average cash, cash equivalent, and investment balances for the three months ended October 31, 2023 compared to 2022.

[0001327567-23-000032:mdna:102]
PROVISION FOR INCOME TAXES

[0001327567-23-000032:mdna:103]
Provision for income taxes consists primarily of U.S. taxes driven by capitalization of research and development expenditures, foreign income taxes, and withholding taxes. We maintain a full valuation allowance for domestic and certain foreign deferred tax assets, including net operating loss carryforwards and certain domestic tax credits. Our valuation allowance has caused, and may continue to cause, disproportionate relationships between our overall effective tax rate and other jurisdictional measures. We regularly evaluate the need for a valuation allowance. Due to recent profitability, a reversal of our valuation allowance in certain jurisdictions in the near future is reasonably possible.

[0001327567-23-000032:mdna:104]
|  |  |  |  |  |  |  | Three Months Ended October 31, |  |  |  |  |
|  |  |  |  |  |  |  | 2023 |  | 2022 |  | Change |
|  |  |  |  |  |  |  |  |  | Amount |  | Amount |  | Amount |  | % |
|  |  |  |  |  |  |  |  |  | (dollars in millions) |
| Provision for income taxes |  |  |  |  |  |  |  |  | $ | 88.4 |  |  | $ | 14.4 |  |  | $ | 74.0 |  |  | 513.9 | % |
| Effective tax rate |  |  |  |  |  |  |  |  | 31.3 | % |  | 41.9 | % |  |  |  |  |

[0001327567-23-000032:mdna:105]
Our provision for income taxes for the three months ended October 31, 2023 was primarily due to U.S. federal and state income taxes, withholding taxes, and foreign income taxes. Our effective tax rate decreased for the three months ended October 31, 2023 compared to the same period in 2022 primarily due to higher tax benefits from our share-based compensation. Refer to Note 12. Income Taxes in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information.

[0001327567-23-000032:mdna:106]
[same as prior period, unchanged from 0001327567-23-000014:mdna:87]

[0001327567-23-000032:mdna:107]
[same as prior period, unchanged from 0001327567-23-000014:mdna:112]

[0001327567-23-000032:mdna:108]
|  | October 31, 2023 |  | July 31, 2023 |
|  | (in millions) |
| Working capital(1) | $ | (1,035.8) |  |  | $ | (1,689.5) |  |
| Cash, cash equivalents, and investments: |  |  |  |
| Cash and cash equivalents | $ | 2,491.4 |  |  | $ | 1,135.3 |  |
| Investments | 4,391.3 |  |  | 4,302.6 |  |
| Total cash, cash equivalents, and investments | $ | 6,882.7 |  |  | $ | 5,437.9 |  |

[0001327567-23-000032:mdna:109]
(1)Current liabilities included net carrying amounts of convertible senior notes of $1.9 billion and $2.0 billion as of October 31, 2023 and July 31, 2023, respectively. Refer to Note 8 Debt in Part I, Item 1 of this Quarterly Report on Form 10-Q for information on the Notes.

[0001327567-23-000032:mdna:110]
As of October 31, 2023, our total cash, cash equivalents, and investments of $6.9 billion were held for general corporate purposes. As of October 31, 2023, we had no unremitted earnings when evaluating our outside basis difference relating to our U.S. investment in foreign subsidiaries. However, there could be local withholding taxes due to various foreign countries if certain lower tier earnings are distributed. Withholding taxes that would be payable upon remittance of these lower tier earnings are not expected to be material.

[0001327567-23-000032:mdna:111]
Beginning in fiscal 2023, we were required to capitalize and amortize R&D expenses as required by the Tax Cuts and Jobs Act. As a result of this change, we expect to pay significantly more cash taxes in the future, beginning in fiscal 2024.

[0001327567-23-000032:mdna:112]
DEBT

[0001327567-23-000032:mdna:113]
In June 2020, we issued the 2025 Notes with an aggregate principal amount of $2.0 billion. The 2025 Notes mature on June 1, 2025; however, under certain circumstances, holders may surrender their 2025 Notes for conversion prior to the maturity date. Upon conversion of the 2025 Notes, we will pay cash equal to the aggregate principal amount of the 2025 Notes to be converted, and, at our election, we will pay or deliver cash and/or shares of our common stock for the amount of our conversion obligation in excess of the aggregate principal amount of the 2025 Notes being converted. During the three months ended October 31, 2023, holders of the 2025 Notes converted $46.0 million in aggregate principal amount of the 2025 Notes, which we repaid in cash. We also issued 0.3 million shares of our common stock to the holders of the 2025 Notes for the conversion value in excess of the principal amount of the 2025 Notes converted, which were fully offset by shares we received from the corresponding exercise of the associated note hedges.

[0001327567-23-000032:mdna:114]
The sale price condition for the 2025 Notes was met during the fiscal quarter ended October 31, 2023, and as a result, holders may convert their 2025 Notes during the fiscal quarter ending January 31, 2024. If all of the holders convert their 2025 Notes during this period, we would be obligated to settle the $2.0 billion principal amount of the 2025 Notes in cash. We believe that our cash provided by operating activities, our existing cash, cash equivalents, and investments, and existing sources of and access to financing will be sufficient to meet our anticipated cash needs should the holders choose to convert their 2025 Notes during the fiscal quarter ending January 31, 2024 or hold the 2025 Notes until maturity on June 1, 2025. As of October 31, 2023, substantially all of our 2025 Notes remained outstanding. Refer to Note 8. Debt in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information on the Notes.

[0001327567-23-000032:mdna:115]
In April 2023, we entered into a credit agreement (the “Credit Agreement”) that provides for a $400.0 million unsecured revolving credit facility (the “Credit Facility”), with an option to increase the amount of the Credit Facility by up to an additional $350.0 million, subject to certain conditions. The interest rates and commitment fees are also subject to upward and downward adjustments based on our progress towards the achievement of certain sustainability goals related to greenhouse gas emissions. As of October 31, 2023, there were no amounts outstanding, and we were in compliance with all covenants under the Credit Agreement. Refer to Note 8. Debt in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information on the Credit Agreement.

[0001327567-23-000032:mdna:116]
[same as prior period, unchanged from 0001327567-23-000014:mdna:100]

[0001327567-23-000032:mdna:117]
CAPITAL RETURN

[0001327567-23-000032:mdna:118]
In February 2019, our board of directors authorized a $1.0 billion share repurchase program. In December 2020, August 2021, and August 2022, our board of directors authorized additional $700.0 million, $676.1 million, and $915.0 million increases to this share repurchase program, respectively, bringing the total authorization under this share repurchase program to $3.3 billion. Repurchases will be funded from available working capital and may be made at management’s discretion from time to time. As of October 31, 2023, $683.3 million remained available for future share repurchases under this repurchase program. On November 16, 2023, our board of directors authorized a $316.7 million increase to our share repurchase program, bringing the total remaining authorization for future share repurchases to $1.0 billion. The repurchase authorization will expire on December 31, 2024, and may be suspended or discontinued at any time without prior notice. Refer to Note 10. Stockholders’ Equity and Note 15. Subsequent Events in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information on this repurchase program.

[0001327567-23-000032:mdna:119]
LEASES AND OTHER MATERIAL CASH REQUIREMENTS

[0001327567-23-000032:mdna:120]
We have entered into various non-cancelable operating leases primarily for our facilities with original lease periods expiring through the fiscal year ending July 31, 2033, with the most significant leases relating to our corporate headquarters in Santa Clara, California. As of October 31, 2023, we have total operating lease obligations of $336.8 million recorded on our condensed consolidated balance sheet.

[0001327567-23-000032:mdna:121]
As of October 31, 2023, our commitments to purchase products, components, cloud and other services totaled $1.7 billion. Refer to Note 9. Commitments and Contingencies in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information on these commitments.

[0001327567-23-000032:mdna:122]
CASH FLOWS

[0001327567-23-000032:mdna:123]
The following table summarizes our cash flows for the three months ended October 31, 2023 and 2022:

[0001327567-23-000032:mdna:124]
|  | Three Months Ended October 31, |
|  | 2023 |  | 2022 |
|  | (in millions) |
| Net cash provided by operating activities | $ | 1,526.0 |  |  | $ | 1,236.7 |  |
| Net cash used in investing activities | (129.0) |  |  | (1,319.8) |  |
| Net cash provided by (used in) financing activities | (41.8) |  |  | 31.1 |  |
| Net increase (decrease) in cash, cash equivalents, and restricted cash | $ | 1,355.2 |  |  | $ | (52.0) |  |

[0001327567-23-000032:mdna:125]
Cash from operations could be affected by various risks and uncertainties detailed in Part II, Item 1A “Risk Factors” in this Quarterly Report on Form 10-Q. We believe that our cash flow from operations with existing cash and cash equivalents will be sufficient to meet our anticipated cash needs for at least the next 12 months and thereafter for the foreseeable future. Our future capital requirements will depend on many factors, including our growth rate, the timing and extent of spending to support development efforts, the expansion of sales and marketing activities, the introduction of new and enhanced products and subscription and support offerings, the costs to acquire or invest in complementary businesses and technologies, the costs to ensure access to adequate manufacturing capacity, the investments in our infrastructure to support the adoption of our cloud-based subscription offerings, the repayment obligations associated with our Notes, the continuing market acceptance of our products and subscription and support offerings and macroeconomic events. In addition, from time to time, we may incur additional tax liability in connection with certain corporate structuring decisions.

[0001327567-23-000032:mdna:126]
[same as prior period, unchanged from 0001327567-23-000014:mdna:130]

[0001327567-23-000032:mdna:127]
OPERATING ACTIVITIES

[0001327567-23-000032:mdna:128]
Our operating activities have consisted of net income adjusted for certain non-cash items and changes in assets and liabilities. Our largest source of cash provided by our operations is receipts from our billings.

[0001327567-23-000032:mdna:129]
Cash provided by operating activities during the three months ended October 31, 2023 was $1.5 billion, an increase of $289.3 million compared to the same period in 2022. The increase was primarily due to growth of our business as reflected by increases in collections during the three months ended October 31, 2023, partially offset by higher cash expenditure to support our business growth.

[0001327567-23-000032:mdna:130]
[same as prior period, unchanged from 0001327567-23-000014:mdna:111]

[0001327567-23-000032:mdna:131]
INVESTING ACTIVITIES

[0001327567-23-000032:mdna:132]
[same as prior period, unchanged from 0001327567-23-000014:mdna:135]

[0001327567-23-000032:mdna:133]
Cash used in investing activities during the three months ended October 31, 2023 was $129.0 million, a decrease of $1.2 billion compared to the same period in 2022. The decrease was primarily due to a decrease in purchases of investments during the three months ended October 31, 2023.

[0001327567-23-000032:mdna:134]
FINANCING ACTIVITIES

[0001327567-23-000032:mdna:135]
[same as prior period, unchanged from 0001327567-23-000014:mdna:138]

[0001327567-23-000032:mdna:136]
Cash used in financing activities during the three months ended October 31, 2023 was $41.8 million, a change of $72.9 million compared to cash provided by financing activities of $31.1 million during the same period in 2022. The change was primarily due to early repayments of our 2025 Notes and repurchases of our common stock during the three months ended October 31, 2023.

[0001327567-23-000032:mdna:137]
[same as prior period, unchanged from 0001327567-23-000014:mdna:141]

[0001327567-23-000032:mdna:138]
Our condensed consolidated financial statements have been prepared in accordance with U.S. GAAP. The preparation of these condensed consolidated financial statements requires us to make estimates and assumptions that affect the reported amounts of assets, liabilities, revenue, expenses, and related disclosures. We base our estimates on historical experience and on various other assumptions that we believe are reasonable under the circumstances. We evaluate our estimates and assumptions on an ongoing basis. Actual results could differ materially from those estimates due to risks and uncertainties, including uncertainty in the current economic environment. To the extent that there are material differences between these estimates and our actual results, our future consolidated financial statements will be affected.

[0001327567-23-000032:mdna:139]
We believe the critical accounting estimates discussed under Item 7, “Management’s Discussion and Analysis of Financial Condition and Results of Operations” in our Annual Report on Form 10-K for the fiscal year ended July 31, 2023 reflect our more significant estimates, assumptions, and judgments that have the most significant impact on our condensed consolidated financial statements. There have been no significant changes to our critical accounting estimates as filed in such report.
