# PANW notes — 0001327567-23-000032


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0001327567-23-000032:notes:1]
Description of Business and Summary of Significant Accounting Policies
Description of Business

[0001327567-23-000032:notes:2]
Palo Alto Networks, Inc. (the “Company,” “we,” “us,” or “our”), headquartered in Santa Clara, California, was incorporated in March 2005 under the laws of the State of Delaware and commenced operations in April 2005. We empower enterprises, organizations, service providers, and government entities to secure their users, networks, clouds, and endpoints by delivering comprehensive cybersecurity enabled by artificial intelligence and automation.

[0001327567-23-000032:notes:3]
[same as prior period, unchanged from 0001327567-23-000014:notes:3]

[0001327567-23-000032:notes:4]
The accompanying condensed consolidated financial statements have been prepared in conformity with U.S. generally accepted accounting principles (“U.S. GAAP”), consistent in all material respects with those applied in our Annual Report on Form 10-K for the fiscal year ended July 31, 2023, filed with the Securities and Exchange Commission (“SEC”) on September 1, 2023. The condensed consolidated financial statements include our accounts and our wholly owned subsidiaries. All significant intercompany balances and transactions have been eliminated in consolidation.

[0001327567-23-000032:notes:5]
The condensed consolidated financial statements are unaudited but include all adjustments of a normal recurring nature necessary for a fair presentation of our quarterly results. Our condensed consolidated financial statements should be read in conjunction with the audited consolidated financial statements and related notes in our Annual Report on Form 10-K for the fiscal year ended July 31, 2023.

[0001327567-23-000032:notes:6]
[same as prior period, unchanged from 0001327567-23-000014:notes:6]

[0001327567-23-000032:notes:7]
The preparation of condensed consolidated financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the amounts reported and disclosed in the condensed consolidated financial statements and the accompanying notes. We base our estimates on assumptions, both historical and forward looking, that we believe are reasonable. Actual results could differ materially from those estimates due to risks and uncertainties, including uncertainty in the current economic environment.

[0001327567-23-000032:notes:8]
[same as prior period, unchanged from 0001327567-23-000014:notes:8]

[0001327567-23-000032:notes:9]
There have been no material changes to our significant accounting policies as of and for the three months ended October 31, 2023, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended July 31, 2023.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001327567-23-000032:notes:10]
[same as prior period, unchanged from 0001327567-23-000014:notes:12]

[0001327567-23-000032:notes:11]
[same as prior period, unchanged from 0001327567-23-000014:notes:13]

[0001327567-23-000032:notes:12]
|  |  |  | Three Months Ended October 31, |
|  |  |  |  |  | 2023 |  | 2022 |
| Revenue: |  |  |  |  |  |  |  |
| Americas |  |  |  |  |  |  |  |
| United States |  |  |  |  | $ | 1,204.3 |  |  | $ | 1,006.3 |  |
| Other Americas |  |  |  |  | 82.3 |  |  | 64.4 |  |
| Total Americas |  |  |  |  | 1,286.6 |  |  | 1,070.7 |  |
| Europe, the Middle East, and Africa (“EMEA”) |  |  |  |  | 364.9 |  |  | 307.9 |  |
| Asia Pacific and Japan (“APAC”) |  |  |  |  | 226.6 |  |  | 184.8 |  |
| Total revenue |  |  |  |  | $ | 1,878.1 |  |  | $ | 1,563.4 |  |

[0001327567-23-000032:notes:13]
[same as prior period, unchanged from 0001327567-23-000014:notes:15]

[0001327567-23-000032:notes:14]
|  |  |  | Three Months Ended October 31, |
|  |  |  |  |  | 2023 |  | 2022 |
| Revenue: |  |  |  |  |  |  |  |
| Product |  |  |  |  | $ | 341.1 |  |  | $ | 330.0 |  |
| Subscription and support |  |  |  |  |  |  |  |
| Subscription |  |  |  |  | 988.3 |  |  | 764.0 |  |
| Support |  |  |  |  | 548.7 |  |  | 469.4 |  |
| Total subscription and support |  |  |  |  | 1,537.0 |  |  | 1,233.4 |  |
| Total revenue |  |  |  |  | $ | 1,878.1 |  |  | $ | 1,563.4 |  |

[0001327567-23-000032:notes:15]
[same as prior period, unchanged from 0001327567-23-000014:notes:17]

[0001327567-23-000032:notes:16]
During the three months ended October 31, 2023 and 2022, we recognized approximately $1.4 billion and $1.1 billion of revenue pertaining to amounts that were deferred as of July 31, 2023 and 2022, respectively.

[0001327567-23-000032:notes:17]
[same as prior period, unchanged from 0001327567-23-000014:notes:19]

[0001327567-23-000032:notes:18]
Remaining performance obligations were $10.4 billion as of October 31, 2023, of which we expect to recognize as revenue approximately $5.0 billion over the next 12 months and the remainder thereafter.


## us-gaap:FairValueDisclosuresTextBlock

[0001327567-23-000032:notes:19]
Fair Value Measurements
The following table presents our financial assets and liabilities measured at fair value on a recurring basis as of October 31, 2023 and July 31, 2023 (in millions):

[0001327567-23-000032:notes:20]
|  |  | October 31, 2023 |  | July 31, 2023 |
|  |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Cash equivalents: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 1,595.3 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,595.3 |  |  | $ | 476.1 |  |  | $ | — |  |  | $ | — |  |  | $ | 476.1 |  |
| Commercial paper |  | — |  |  | 297.0 |  |  | — |  |  | 297.0 |  |  | — |  |  | 151.4 |  |  | — |  |  | 151.4 |  |
| Corporate debt securities |  | — |  |  | 8.6 |  |  | — |  |  | 8.6 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| U.S. government and agency securities |  | — |  |  | 24.9 |  |  | — |  |  | 24.9 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Total cash equivalents |  | 1,595.3 |  |  | 330.5 |  |  | — |  |  | 1,925.8 |  |  | 476.1 |  |  | 151.4 |  |  | — |  |  | 627.5 |  |
| Short-term investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Certificates of deposit |  | — |  |  | 34.0 |  |  | — |  |  | 34.0 |  |  | — |  |  | 48.1 |  |  | — |  |  | 48.1 |  |
| Commercial paper |  | — |  |  | 136.8 |  |  | — |  |  | 136.8 |  |  | — |  |  | 213.8 |  |  | — |  |  | 213.8 |  |
| Corporate debt securities |  | — |  |  | 1,038.2 |  |  | — |  |  | 1,038.2 |  |  | — |  |  | 798.0 |  |  | — |  |  | 798.0 |  |
| U.S. government and agency securities |  | — |  |  | 148.0 |  |  | — |  |  | 148.0 |  |  | — |  |  | 190.6 |  |  | — |  |  | 190.6 |  |
| Non-U.S. government and agency securities |  | — |  |  | 33.7 |  |  | — |  |  | 33.7 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Asset-backed securities |  | — |  |  | 11.7 |  |  | — |  |  | 11.7 |  |  | — |  |  | 4.2 |  |  | — |  |  | 4.2 |  |
| Total short-term investments |  | — |  |  | 1,402.4 |  |  | — |  |  | 1,402.4 |  |  | — |  |  | 1,254.7 |  |  | — |  |  | 1,254.7 |  |

[0001327567-23-000032:notes:21]
|  |  | October 31, 2023 |  | July 31, 2023 |
|  |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Long-term investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate debt securities |  | — |  |  | 2,367.0 |  |  | — |  |  | 2,367.0 |  |  | — |  |  | 2,484.3 |  |  | — |  |  | 2,484.3 |  |
| U.S. government and agency securities |  | — |  |  | 71.2 |  |  | — |  |  | 71.2 |  |  | — |  |  | 22.0 |  |  | — |  |  | 22.0 |  |
| Non-U.S. government and agency securities |  | — |  |  | 27.9 |  |  | — |  |  | 27.9 |  |  | — |  |  | 36.6 |  |  | — |  |  | 36.6 |  |
| Asset-backed securities |  | — |  |  | 522.8 |  |  | — |  |  | 522.8 |  |  | — |  |  | 505.0 |  |  | — |  |  | 505.0 |  |
| Total long-term investments |  | — |  |  | 2,988.9 |  |  | — |  |  | 2,988.9 |  |  | — |  |  | 3,047.9 |  |  | — |  |  | 3,047.9 |  |
| Prepaid expenses and other current assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency forward contracts |  | — |  |  | 5.6 |  |  | — |  |  | 5.6 |  |  | — |  |  | 19.1 |  |  | — |  |  | 19.1 |  |
| Total prepaid expenses and other current assets |  | — |  |  | 5.6 |  |  | — |  |  | 5.6 |  |  | — |  |  | 19.1 |  |  | — |  |  | 19.1 |  |
| Other assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency forward contracts |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 1.7 |  |  | — |  |  | 1.7 |  |
| Total other assets |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 1.7 |  |  | — |  |  | 1.7 |  |
| Total assets measured at fair value |  | $ | 1,595.3 |  |  | $ | 4,727.4 |  |  | $ | — |  |  | $ | 6,322.7 |  |  | $ | 476.1 |  |  | $ | 4,474.8 |  |  | $ | — |  |  | $ | 4,950.9 |  |
| Accrued and other liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency forward contracts |  | $ | — |  |  | $ | 44.6 |  |  | $ | — |  |  | $ | 44.6 |  |  | $ | — |  |  | $ | 18.7 |  |  | $ | — |  |  | $ | 18.7 |  |
| Total accrued and other liabilities |  | — |  |  | 44.6 |  |  | — |  |  | 44.6 |  |  | — |  |  | 18.7 |  |  | — |  |  | 18.7 |  |
| Other long-term liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency forward contracts |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 1.6 |  |  | — |  |  | 1.6 |  |
| Total other long-term liabilities |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 1.6 |  |  | — |  |  | 1.6 |  |
| Total liabilities measured at fair value |  | $ | — |  |  | $ | 44.6 |  |  | $ | — |  |  | $ | 44.6 |  |  | $ | — |  |  | $ | 20.3 |  |  | $ | — |  |  | $ | 20.3 |  |

[0001327567-23-000032:notes:22]
Refer to Note 8. Debt for the carrying amount and estimated fair value of our convertible senior notes as of October 31, 2023 and July 31, 2023.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001327567-23-000032:notes:23]
Cash Equivalents and Investments
Available-for-sale Debt Securities

[0001327567-23-000032:notes:24]
The following tables summarize the amortized cost, unrealized gains and losses, and fair value of our available-for-sale debt securities as of October 31, 2023 and July 31, 2023 (in millions):

[0001327567-23-000032:notes:25]
|  | October 31, 2023 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | $ | 297.0 |  |  | $ | — |  |  | $ | — |  |  | $ | 297.0 |  |
| Corporate debt securities | 8.6 |  |  | — |  |  | — |  |  | 8.6 |  |
| U.S. government and agency securities | 24.9 |  |  | — |  |  | — |  |  | 24.9 |  |
| Total available-for-sale cash equivalents | $ | 330.5 |  |  | $ | — |  |  | $ | — |  |  | $ | 330.5 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 34.0 |  |  | $ | — |  |  | $ | — |  |  | $ | 34.0 |  |
| Commercial paper | 136.9 |  |  | — |  |  | (0.1) |  |  | 136.8 |  |
| Corporate debt securities | 3,453.7 |  |  | 0.1 |  |  | (48.6) |  |  | 3,405.2 |  |
| U.S. government and agency securities | 219.9 |  |  | 0.1 |  |  | (0.8) |  |  | 219.2 |  |
| Non-U.S. government and agency securities | 62.4 |  |  | — |  |  | (0.8) |  |  | 61.6 |  |
| Asset-backed securities | 539.1 |  |  | 0.1 |  |  | (4.7) |  |  | 534.5 |  |
| Total available-for-sale investments | $ | 4,446.0 |  |  | $ | 0.3 |  |  | $ | (55.0) |  |  | $ | 4,391.3 |  |

[0001327567-23-000032:notes:26]
|  | July 31, 2023 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | $ | 151.4 |  |  | $ | — |  |  | $ | — |  |  | $ | 151.4 |  |
| Total available-for-sale cash equivalents | $ | 151.4 |  |  | $ | — |  |  | $ | — |  |  | $ | 151.4 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 48.1 |  |  | $ | — |  |  | $ | — |  |  | $ | 48.1 |  |
| Commercial paper | 214.1 |  |  | — |  |  | (0.3) |  |  | 213.8 |  |
| Corporate debt securities | 3,313.5 |  |  | 1.3 |  |  | (32.5) |  |  | 3,282.3 |  |
| U.S. government and agency securities | 214.2 |  |  | — |  |  | (1.6) |  |  | 212.6 |  |
| Non-U.S. government and agency securities | 37.2 |  |  | — |  |  | (0.6) |  |  | 36.6 |  |
| Asset-backed securities | 512.0 |  |  | 0.2 |  |  | (3.0) |  |  | 509.2 |  |
| Total available-for-sale investments | $ | 4,339.1 |  |  | $ | 1.5 |  |  | $ | (38.0) |  |  | $ | 4,302.6 |  |

[0001327567-23-000032:notes:27]
As of October 31, 2023, the gross unrealized losses that have been in a continuous unrealized loss position for less than 12 months were $40.4 million, which were related to $3.3 billion of available-for-sale debt securities, and the gross unrealized losses that have been in a continuous unrealized loss position for more than 12 months were $14.6 million, which were related to $922.5 million of available-for-sale debt securities. As of July 31, 2023 the gross unrealized losses that have been in a continuous unrealized loss position for less than 12 months were $30.7 million, which were related to $3.4 billion of available-for-sale debt securities, and the gross unrealized losses that have been in a continuous unrealized loss position for more than 12 months were $7.3 million, which were related to $481.8 million of available-for-sale debt securities.

[0001327567-23-000032:notes:28]
Unrealized losses related to our available-for-sale debt securities are primarily due to interest rate fluctuations as opposed to credit quality. We do not intend to sell any of the securities in an unrealized loss position and it is not likely that we would be required to sell these securities before recovery of their amortized cost basis, which may be at maturity. We did not recognize any credit losses related to our available-for-sale debt securities during the three months ended October 31, 2023 and 2022.

[0001327567-23-000032:notes:29]
The following table summarizes the amortized cost and fair value of our available-for-sale debt securities as of October 31, 2023, by contractual years-to-maturity (in millions):

[0001327567-23-000032:notes:30]
|  | Amortized Cost |  | Fair Value |
| Due within one year | $ | 1,742.4 |  |  | $ | 1,732.9 |  |
| Due between one and three years | 2,173.8 |  |  | 2,145.2 |  |
| Due between three and five years | 743.4 |  |  | 728.1 |  |
| Due between five and ten years | 61.3 |  |  | 60.8 |  |
| Due after ten years | 55.6 |  |  | 54.8 |  |
| Total | $ | 4,776.5 |  |  | $ | 4,721.8 |  |

[0001327567-23-000032:notes:31]
Marketable Equity Securities

[0001327567-23-000032:notes:32]
Marketable equity securities consist of money market funds and are included in cash and cash equivalents on our condensed consolidated balance sheets. As of October 31, 2023 and July 31, 2023, the carrying values of our marketable equity securities were $1.6 billion and $476.1 million, respectively. There were no unrealized gains or losses recognized for these securities during the three months ended October 31, 2023 and 2022.


## us-gaap:FinancingReceivablesTextBlock

[0001327567-23-000032:notes:33]
Financing Receivables
The following table summarizes our short-term and long-term financing receivables as of October 31, 2023 and July 31, 2023 (in millions):

[0001327567-23-000032:notes:34]
|  |  | October 31, 2023 |  | July 31, 2023 |
| Short-term financing receivables, gross |  | $ | 499.8 |  |  | $ | 435.1 |  |
| Unearned income |  | (49.3) |  |  | (42.9) |  |
| Allowance for credit losses |  | (4.6) |  |  | (3.4) |  |
| Short-term financing receivables, net |  | $ | 445.9 |  |  | $ | 388.8 |  |
| Long-term financing receivables, gross |  | $ | 689.8 |  |  | $ | 698.6 |  |
| Unearned income |  | (42.0) |  |  | (39.2) |  |
| Allowance for credit losses |  | (8.0) |  |  | (6.1) |  |
| Long-term financing receivables, net |  | $ | 639.8 |  |  | $ | 653.3 |  |

[0001327567-23-000032:notes:35]
Our financing receivables portfolio primarily consisted of high-quality investment-grade receivables as of October 31, 2023 and July 31, 2023. There was no significant activity in allowance for credit losses during the three months ended October 31, 2023 and 2022. Past due amounts on financing receivables were not material as of October 31, 2023 and July 31, 2023.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001327567-23-000032:notes:36]
Derivative Instruments
We are exposed to foreign currency exchange risk. Our revenue is transacted in U.S. dollars, however, a portion of our operating expenditures are incurred outside of the United States and are denominated in foreign currencies, making them subject to fluctuations in foreign currency exchange rates. We enter into foreign currency derivative contracts with maturities of 24 months or less, which we designate as cash flow hedges, to manage the foreign currency exchange risk associated with our operating expenditures.

[0001327567-23-000032:notes:37]
As of October 31, 2023 and July 31, 2023, the total notional amount of our outstanding foreign currency forward contracts was $777.9 million and $957.5 million, respectively. Refer to Note 3. Fair Value Measurements for the fair value of our derivative instruments as reported on our condensed consolidated balance sheets as of October 31, 2023 and July 31, 2023.

[0001327567-23-000032:notes:38]
As of October 31, 2023, unrealized gains and losses in accumulated other comprehensive income (“AOCI”) related to our cash flow hedges were a $31.0 million net loss, of which $29.0 million in losses are expected to be recognized into earnings within the next 12 months. As of July 31, 2023, unrealized gains and losses in AOCI related to our cash flow hedges were a $0.7 million net gain.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001327567-23-000032:notes:39]
Intangible Assets
Purchased Intangible Assets

[0001327567-23-000032:notes:40]
The following table presents details of our purchased intangible assets as of October 31, 2023 and July 31, 2023 (in millions):

[0001327567-23-000032:notes:41]
|  | October 31, 2023 |  | July 31, 2023 |
|  | Gross Carrying Amount |  | Accumulated Amortization |  | Net Carrying Amount |  | Gross Carrying Amount |  | Accumulated Amortization |  | Net Carrying Amount |
| Intangible assets subject to amortization: |  |  |  |  |  |  |  |  |  |  |  |
| Developed technology | $ | 633.2 |  |  | $ | (448.5) |  |  | $ | 184.7 |  |  | $ | 633.2 |  |  | $ | (429.4) |  |  | $ | 203.8 |  |
| Customer relationships | 172.7 |  |  | (79.3) |  |  | 93.4 |  |  | 172.7 |  |  | (73.9) |  |  | 98.8 |  |
| Acquired intellectual property | 14.6 |  |  | (6.5) |  |  | 8.1 |  |  | 14.6 |  |  | (6.2) |  |  | 8.4 |  |
| Trade name and trademarks | 9.4 |  |  | (9.4) |  |  | — |  |  | 9.4 |  |  | (9.4) |  |  | — |  |
| Other | 0.9 |  |  | (0.5) |  |  | 0.4 |  |  | 0.9 |  |  | (0.4) |  |  | 0.5 |  |
| Total intangible assets subject to amortization | 830.8 |  |  | (544.2) |  |  | 286.6 |  |  | 830.8 |  |  | (519.3) |  |  | 311.5 |  |
| Intangible assets not subject to amortization: |  |  |  |  |  |  |  |  |  |  |  |
| In-process research and development | 3.9 |  |  | — |  |  | 3.9 |  |  | 3.9 |  | — |  |  | 3.9 |  |
| Total purchased intangible assets | $ | 834.7 |  |  | $ | (544.2) |  |  | $ | 290.5 |  |  | $ | 834.7 |  |  | $ | (519.3) |  |  | $ | 315.4 |  |

[0001327567-23-000032:notes:42]
We recognized amortization expense of $24.9 million and $29.1 million for the three months ended October 31, 2023 and 2022, respectively.

[0001327567-23-000032:notes:43]
The following table summarizes estimated future amortization expense of our intangible assets subject to amortization as of October 31, 2023 (in millions):

[0001327567-23-000032:notes:44]
|  |  |  | Fiscal years ending July 31, |
|  | Total |  | Remaining 2024 |  | 2025 |  | 2026 |  | 2027 |  | 2028 |  | 2029 and Thereafter |
| Future amortization expense | $ | 286.6 |  |  | $ | 73.0 |  |  | $ | 84.2 |  |  | $ | 62.4 |  |  | $ | 35.3 |  |  | $ | 13.7 |  |  | $ | 18.0 |  |


## us-gaap:DebtDisclosureTextBlock

[0001327567-23-000032:notes:45]
Debt
Convertible Senior Notes

[0001327567-23-000032:notes:46]
In July 2018, we issued $1.7 billion aggregate principal amount of 0.75% Convertible Senior Notes due 2023 (the “2023 Notes”) and in June 2020, we issued $2.0 billion aggregate principal amount of 0.375% Convertible Senior Notes due 2025 (the “2025 Notes,” and together with the 2023 Notes, the “Notes”). The 2023 Notes were converted prior to or settled on the maturity date of July 1, 2023 in accordance with their terms. The 2025 Notes bear interest at a fixed rate of 0.375% per year, payable semi-annually in arrears on June 1 and December 1 of each year, beginning on December 1, 2020. The 2025 Notes are governed by an indenture between us, as the issuer, and U.S. Bank National Association, as Trustee (the “Indenture”). The 2025 Notes are unsecured, unsubordinated obligations and the Indenture governing the 2025 Notes does not contain any financial covenants or restrictions on the payments of dividends, the incurrence of indebtedness, or the issuance or repurchase of securities by us or any of our subsidiaries. The 2025 Notes mature on June 1, 2025. We may redeem for cash all or any portion of the 2025 Notes, at our option, on or after June 5, 2023 and prior to the 31st scheduled trading day immediately preceding the maturity date if the last reported sale price of our common stock has been at least 130% of the conversion price then in effect for at least 20 trading days during any 30 consecutive trading day period ending on and including the trading day preceding the date on which we provide notice of redemption. The redemption will be at a price equal to 100% of the principal amount of the 2025 Notes and adjusted for interest. If we call any or all of the 2025 Notes for redemption, holders may convert such 2025 Notes called for redemption at any time prior to the close of business on the second scheduled trading day immediately preceding the redemption date.

[0001327567-23-000032:notes:47]
The 2025 Notes are convertible for an initial 20.1 million shares of our common stock at a conversion rate of approximately 10.0806 shares of common stock per $1,000 principal amount, which is equal to an initial conversion price of approximately $99.20 per share of common stock, subject to adjustments. Holders of the 2025 Notes may surrender their 2025 Notes for conversion at their option at any time prior to the close of business on the business day immediately preceding March 1, 2025 only under the following circumstances:

[0001327567-23-000032:notes:48]
•during any fiscal quarter commencing after the fiscal quarters ending on October 31, 2020 (and only during such fiscal quarter), if the last reported sale price of our common stock for at least 20 trading days (whether or not consecutive) during a period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the conversion price for the 2025 Notes on each applicable trading day (the “sale price condition”);

[0001327567-23-000032:notes:49]
•during the five business day period after any five consecutive trading day period (the “measurement period”) in which the trading price per $1,000 principal amount of the 2025 Notes for each trading day of the measurement period was less than 98% of the product of the last reported sale price of our common stock and the conversion rate for the 2025 Notes on each such trading day; or

[0001327567-23-000032:notes:50]
•upon the occurrence of specified corporate events.

[0001327567-23-000032:notes:51]
On or after March 1, 2025, holders may surrender all or any portion of their 2025 Notes for conversion at any time prior to the close of business on the second scheduled trading day immediately preceding the maturity date regardless of the foregoing conditions, and such conversions will be settled upon the maturity date. Upon conversion, holders of the 2025 Notes will receive cash equal to the aggregate principal amount of the 2025 Notes to be converted, and, at our election, cash and/or shares of our common stock for any amounts in excess of the aggregate principal amount of the 2025 Notes being converted.

[0001327567-23-000032:notes:52]
The conversion price will be subject to adjustment in some events. Holders of the 2025 Notes who convert their 2025 Notes in connection with certain corporate events that constitute a “make-whole fundamental change” under the Indenture are, under certain circumstances, entitled to an increase in the conversion rate. Additionally, upon the occurrence of a corporate event that constitutes a “fundamental change” under the Indenture, holders of the 2025 Notes may require us to repurchase for cash all or a portion of the 2025 Notes at a repurchase price equal to 100% of the principal amount of the 2025 Notes plus accrued and unpaid interest to, but excluding, the fundamental change repurchase date.

[0001327567-23-000032:notes:53]
Holders of the 2025 Notes were able to early convert their 2025 Notes during the fiscal quarter ended October 31, 2023 as the sales price condition had been met during the fiscal quarter ended July 31, 2023. During the three months ended October 31, 2023, holders of the 2025 Notes converted $46.0 million in aggregate principal amount of the 2025 Notes, which we repaid in cash. We also issued 0.3 million shares of our common stock to the holders of the 2025 Notes for the conversion value in excess of the principal amount. These shares were fully offset by shares we received from the corresponding exercise of the associated note hedges.

[0001327567-23-000032:notes:54]
The sale price condition for the 2025 Notes was met during the fiscal quarter ended October 31, 2023 and as a result, holders may convert their 2025 Notes during the fiscal quarter ending January 31, 2024. The net carrying amount of the 2025 Notes was classified as a current liability on our condensed consolidated balance sheet as of October 31, 2023.

[0001327567-23-000032:notes:55]
The following table sets forth the net carrying amount of our 2025 Notes (in millions):

[0001327567-23-000032:notes:56]
|  |  |  | October 31, 2023 | July 31, 2023 |
| Principal |  |  | $ | 1,953.3 |  |  |  |  |  |  | $ | 1,999.3 |  |  |  |
| Less: debt issuance costs, net of amortization |  |  | (6.6) |  |  |  |  |  |  | (7.8) |  |  |  |
| Net carrying amount |  |  | $ | 1,946.7 |  |  |  |  |  |  | $ | 1,991.5 |  |  |  |

[0001327567-23-000032:notes:57]
The total estimated fair value of the 2025 Notes was $4.8 billion as of October 31, 2023 and $5.0 billion as of July 31, 2023, respectively. The fair value was determined based on the closing trading price per $100 of the 2025 Notes as of the last day of trading for the period. We consider the fair value of the 2025 Notes as of October 31, 2023 and July 31, 2023 to be a Level 2 measurement. The fair value of the 2025 Notes is primarily affected by the trading price of our common stock and market interest rates.

[0001327567-23-000032:notes:58]
The following table sets forth interest expense recognized related to the Notes (dollars in millions):

[0001327567-23-000032:notes:59]
|  |  |  | Three Months Ended October 31, |
|  |  |  |  |  | 2023 |  | 2022 |
|  |  |  |  |  |  |  |  |  |  |  |  |  | 2023 Notes |  | 2025 Notes |  | Total |  | 2023 Notes |  | 2025 Notes |  | Total |
| Contractual interest expense |  |  |  |  |  |  |  |  |  |  |  |  | $ | — |  |  | $ | 1.9 |  |  | $ | 1.9 |  |  | $ | 3.2 |  |  | $ | 1.8 |  |  | $ | 5.0 |  |
| Amortization of debt issuance costs |  |  |  |  |  |  |  |  |  |  |  |  | — |  |  | 1.0 |  |  | 1.0 |  |  | 0.7 |  |  | 1.1 |  |  | 1.8 |  |
| Total interest expense |  |  |  |  |  |  |  |  |  |  |  |  | $ | — |  |  | $ | 2.9 |  |  | $ | 2.9 |  |  | $ | 3.9 |  |  | $ | 2.9 |  |  | $ | 6.8 |  |
| Effective interest rate |  |  |  |  |  |  |  |  |  |  |  |  | — | % |  | 0.6 | % |  |  |  | 0.9 | % |  | 0.6 | % |  |  |

[0001327567-23-000032:notes:60]
Note Hedges

[0001327567-23-000032:notes:61]
To minimize the impact of potential economic dilution upon conversion of our convertible senior notes, we entered into separate convertible note hedge transactions (the “2023 Note Hedges,” with respect to the 2023 Notes, the “2025 Note Hedges,” with respect to the 2025 Notes, and the 2023 Note Hedges together with 2025 Note Hedges, the “Note Hedges”) with respect to our common stock concurrent with the issuance of each series of the Notes.

[0001327567-23-000032:notes:62]
Upon the settlement of the 2023 Notes, we exercised the corresponding portion of our 2023 Note Hedges during the year ended July 31, 2023 and received shares of our common stock that fully offset the shares issued in excess of the principal amount of the converted 2023 Notes. The 2023 Note Hedges expired upon maturity of the 2023 Notes.

[0001327567-23-000032:notes:63]
The 2025 Note Hedges cover up to 20.1 million shares of our common stock at a strike price per share that corresponds to the initial conversion price of the 2025 Notes, which are also subject to adjustment, and are exercisable upon conversion of the 2025 Notes. The 2025 Note Hedges will expire upon maturity of the 2025 Notes. The 2025 Note Hedges are separate transactions and are not part of the terms of the 2025 Notes. Holders of the 2025 Notes will not have any rights with respect to the 2025 Note Hedges. Any shares of our common stock receivable by us under the 2025 Note Hedges are excluded from the calculation of diluted earnings per share as they are antidilutive. We paid an aggregate amount of $370.8 million for the 2025 Note Hedges, which is included in additional paid-in capital on our condensed consolidated balance sheets.

[0001327567-23-000032:notes:64]
As a result of the conversions of the 2025 Notes settled during the three months ended October 31, 2023, we exercised the corresponding portion of our 2025 Note Hedges and received 0.3 million shares of our common stock during the period.

[0001327567-23-000032:notes:65]
Warrants

[0001327567-23-000032:notes:66]
Separately, but concurrently with the issuance of each series of our convertible senior notes, we entered into transactions whereby we sold warrants (the “2023 Warrants,” with respect to the 2023 Notes, the “2025 Warrants,” with respect to the 2025 Notes, and the 2023 Warrants together with the 2025 Warrants, the “Warrants”) to acquire shares of our common stock, subject to anti-dilution adjustments. The 2023 Warrants and 2025 Warrants are exercisable over 60 scheduled trading days beginning October 2023 and September 2025, respectively.

[0001327567-23-000032:notes:67]
The following table presents details of our Warrants (in millions, except per share data):

[0001327567-23-000032:notes:68]
|  | Initial Number of Shares |  | Strike Price per Share |  | Aggregate Proceeds |
| 2023 Warrants | 19.1 |  |  | $ | 139.27 |  |  | $ | 145.4 |  |
| 2025 Warrants | 20.1 |  |  | $ | 136.16 |  |  | $ | 202.8 |  |

[0001327567-23-000032:notes:69]
The shares issuable under the Warrants are included in the calculation of diluted earnings per share when the average market value per share of our common stock for the reporting period exceeds the applicable strike price for such series of Warrants. The Warrants are separate transactions and are not part of either series of Notes or Note Hedges and are not remeasured through earnings each reporting period. Holders of the Notes of either series will not have any rights with respect to the Warrants. The aggregate proceeds received from the sale of the Warrants are included in additional paid-in capital on our condensed consolidated balance sheets.

[0001327567-23-000032:notes:70]
During the three months ended October 31, 2023, we net settled a portion of the 2023 Warrants with 3.1 million shares of our common stock with a fair value of $763.5 million. The number of net shares issued was determined based on the number of 2023 Warrants exercised multiplied by the difference between the strike price of the 2023 Warrants and their daily volume-weighted-average stock price. As of October 31, 2023, up to 12.1 million shares of our common stock were issuable for gross settlement under the remaining outstanding 2023 Warrants, which will be net settled when exercised through the end of December 2023.

[0001327567-23-000032:notes:71]
Revolving Credit Facility

[0001327567-23-000032:notes:72]
On April 13, 2023, we entered into a credit agreement (the “Credit Agreement”) with certain institutional lenders that provides for a $400.0 million unsecured revolving credit facility (the “Credit Facility”), with an option to increase the amount of the Credit Facility by up to an additional $350.0 million, subject to certain conditions. The Credit Facility matures on April 13, 2028.

[0001327567-23-000032:notes:73]
The borrowings under the Credit Facility bear interest, at our option, at a base rate plus a spread of 0.000% to 0.375%, or an adjusted term Secured Overnight Financing Rate (“SOFR”) plus a spread of 1.000% to 1.375%, in each case with such spread being determined based on our leverage ratio. We are obligated to pay an ongoing commitment fee on undrawn amounts at a rate of 0.090% to 0.150%, depending on our leverage ratio. The interest rates and commitment fees are also subject to upward and downward adjustments based on our progress towards the achievement of certain sustainability goals related to greenhouse gas emissions.

[0001327567-23-000032:notes:74]
As of October 31, 2023, there were no amounts outstanding and we were in compliance with all covenants under the Credit Agreement.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001327567-23-000032:notes:75]
Commitments and Contingencies
Purchase Commitments

[0001327567-23-000032:notes:76]
Manufacturing Purchase Commitments

[0001327567-23-000032:notes:77]
In order to reduce manufacturing lead times and plan for adequate supply, we enter into agreements with manufacturing partners and component suppliers to procure inventory based on our demand forecasts. The following table presents details of the aggregate future minimum or fixed purchase commitments under these arrangements, excluding obligations under contracts that we can cancel as of October 31, 2023 (in millions):

[0001327567-23-000032:notes:78]
|  |  |  | Fiscal years ending July 31, |
|  | Total |  | Remaining 2024 |  | 2025 |  | 2026 |  | 2027 |  | 2028 |  | 2029 and Thereafter |
| Manufacturing purchase commitments | $ | 188.2 |  |  | $ | 113.2 |  |  | $ | 35.0 |  |  | $ | 40.0 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |

[0001327567-23-000032:notes:79]
Other Purchase Commitments

[0001327567-23-000032:notes:80]
We have entered into various non-cancelable agreements with certain service providers, under which we are committed to minimum or fixed purchases. The following table presents details of the aggregate future non-cancelable purchase commitments under these agreements as of October 31, 2023 (in millions):

[0001327567-23-000032:notes:81]
|  |  |  | Fiscal years ending July 31, |
|  | Total |  | Remaining 2024 |  | 2025 |  | 2026 |  | 2027 |  | 2028 |  | 2029 and Thereafter |
| Other purchase commitments | $ | 1,383.3 |  |  | $ | 11.3 |  |  | $ | 387.4 |  |  | $ | 499.4 |  |  | $ | 483.8 |  |  | $ | 0.6 |  |  | $ | 0.8 |  |

[0001327567-23-000032:notes:82]
Additionally, we have a $153.3 million minimum purchase commitment with a service provider through September 2027 with no specified annual commitments.

[0001327567-23-000032:notes:83]
Guarantee

[0001327567-23-000032:notes:84]
In October 2023, we established a multi-currency notional cash pool for a certain number of our entities with a third-party bank. As part of the notional cash pool agreement, the bank extends overdraft credit to our participating entities as needed, provided that the overall notionally pooled balance of all accounts in the pool at the end of each day is positive. In the unlikely event of a default, any overdraft balances incurred would be guaranteed by our collective entities participating in the pool.

[0001327567-23-000032:notes:85]
Litigation

[0001327567-23-000032:notes:86]
We are subject to legal proceedings, claims, tax matters, and litigation arising in the ordinary course of business, including, for instance, intellectual property and patent litigation. We accrue for contingencies when we believe that a loss is probable and that we can reasonably estimate the amount of any such loss. As of October 31, 2023, we have not recorded any significant accruals for loss contingencies associated with such matters.

[0001327567-23-000032:notes:87]
Legal matters could include speculative, substantial or indeterminate monetary amounts. Significant judgment is required to determine both the likelihood of there being a loss and the estimated amount of a loss related to such matters, and we may be unable to estimate the reasonably possible loss or range of loss. The outcomes of outstanding legal matters are inherently unpredictable, and could, either individually or in aggregate, have a material adverse effect on us and our results of operations. To the extent there is a reasonable possibility that a loss exceeding any amounts already recognized may be incurred, we will either disclose the estimated additional loss or state that such an estimate cannot be made.

[0001327567-23-000032:notes:88]
The following matters arose in the ordinary course of business.

[0001327567-23-000032:notes:89]
Centripetal Networks, Inc. v. Palo Alto Networks

[0001327567-23-000032:notes:90]
On March 12, 2021, Centripetal Networks, Inc., filed a lawsuit against us in the United States District Court for the Eastern District of Virginia (“E.D.VA”). The lawsuit alleges that our products infringe multiple Centripetal patents. We successfully challenged certain of these patents, which were found unpatentable by the U.S. Patent and Trademark Office. The complaint requests injunctive relief, monetary damages, and attorneys fees. The US District Court E.D.VA has set a trial date of January 22, 2024 on the remaining patents. In addition, Centripetal filed infringement contentions on certain of their patents in the European Patent Office in Germany, to which we filed invalidity challenges. Those matters are still pending. We are unable, at this time, to reasonably estimate a possible loss or potential range of loss, if any.

[0001327567-23-000032:notes:91]
Finjan, Inc. v. Palo Alto Networks

[0001327567-23-000032:notes:92]
On November 4, 2014, Finjan, Inc., filed a lawsuit against us in the United States District Court for the Northern District of California. The lawsuit alleges that our products infringe multiple Finjan patents. The complaint requests injunctive relief, monetary damages, and attorneys fees. The court has moved the trial date from April 8, 2024 to October 21, 2024. We are unable, at this time, to reasonably estimate a possible loss or potential range of loss, if any.

[0001327567-23-000032:notes:93]
Taasera v. Palo Alto Networks

[0001327567-23-000032:notes:94]
On March 22, 2022, we filed a declaratory judgment action in the United States District Court for the Southern District of New York (“S.D.N.Y”) seeking a ruling that we are not infringing various Taasera patents. Taasera challenged jurisdiction in S.D.N.Y, which issue is currently on appeal with the Federal Circuit. Pursuant to an order of the Judicial Panel on Multidistrict Litigation, this matter has been consolidated in the United States District Court for the Eastern District of Texas with several other patent infringement matters brought by Taasera. The court moved the start date to April 15, 2024, as the start of consecutive trials of these consolidated matters. The complaint requests injunctive relief, monetary damages, and attorneys fees. We are unable, at this time, to reasonably estimate a possible loss or potential range of loss, if any.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001327567-23-000032:notes:95]
[same as prior period, unchanged from 0001327567-23-000014:notes:100]

[0001327567-23-000032:notes:96]
[same as prior period, unchanged from 0001327567-23-000014:notes:101]

[0001327567-23-000032:notes:97]
During the three months ended October 31, 2023, we repurchased and retired 0.3 million shares of our common stock under our current repurchase authorization for an aggregate purchase price of $66.7 million, including transaction costs, at an average price of $226.67. During the three months ended October 31, 2022, we did not repurchase shares of our common stock, and paid $22.7 million related to share repurchases of our common stock that were not settled as of July 31, 2022.

[0001327567-23-000032:notes:98]
As of October 31, 2023, $683.3 million remained available for future share repurchases under our current repurchase authorization. The total price of the shares repurchased and related transaction costs are reflected as a reduction to common stock and additional paid-in capital on our condensed consolidated balance sheets.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001327567-23-000032:notes:99]
[same as prior period, unchanged from 0001327567-23-000014:notes:108]

[0001327567-23-000032:notes:100]
The following table summarizes the RSU and PSU activity under our stock plans during the three months ended October 31, 2023 (in millions, except per share amounts):

[0001327567-23-000032:notes:101]
|  | RSUs Outstanding |  | PSUs Outstanding |
|  | Number of Shares |  | Weighted-Average Grant-Date Fair Value Per Share |  |  |  | Aggregate Intrinsic Value |  | Number of Shares |  | Weighted-Average Grant-Date Fair Value Per Share |  |  |  | Aggregate Intrinsic Value |
| Balance—July 31, 2023 | 12.1 |  |  | $ | 142.61 |  |  |  |  | $ | 3,013.0 |  |  | 5.0 |  |  | $ | 128.64 |  |  |  |  | $ | 1,242.3 |  |
| Granted(1) | 0.5 |  |  | $ | 245.46 |  |  |  |  |  |  | 2.1 |  |  | $ | 183.03 |  |  |  |  |  |
| Vested | (1.6) |  |  | $ | 123.43 |  |  |  |  |  |  | (0.5) |  |  | $ | 145.93 |  |  |  |  |  |
| Forfeited | (0.4) |  |  | $ | 143.47 |  |  |  |  |  |  | (0.4) |  |  | $ | 133.97 |  |  |  |  |  |
| Balance—October 31, 2023 | 10.6 |  |  | $ | 150.58 |  |  |  |  | $ | 2,574.9 |  |  | 6.2 |  |  | $ | 145.51 |  |  |  |  | $ | 1,516.4 |  |

[0001327567-23-000032:notes:102]
(1)For PSUs, shares granted represent the aggregate maximum number of shares that may be earned and issued with respect to these awards over their full terms.

[0001327567-23-000032:notes:103]
[same as prior period, unchanged from 0001327567-23-000014:notes:112]

[0001327567-23-000032:notes:104]
Our PSUs generally vest over a period of one to four years from the date of grant. The number of PSUs eligible to vest is determined based on the level of achievement against certain performance conditions, market conditions, and a combination thereof.

[0001327567-23-000032:notes:105]
During the three months ended October 31, 2023 and 2022, we granted 2.0 million and 1.6 million shares of PSUs, respectively, which contain service, performance and market conditions. The service conditions are satisfied after a period of one to three years. The performance conditions are based on revenue growth or billing growth. The market condition is measured based on our total shareholder return (“TSR”) relative to the TSR of the companies listed in the Standard & Poor’s 500 index. As of October 31, 2023, we have approved 2.7 million shares of PSUs, which will be granted upon the performance condition being established during the next two fiscal years.

[0001327567-23-000032:notes:106]
The fair value of the PSUs subject to market conditions is estimated on the grant date using a Monte Carlo simulation model. The following table summarizes the assumptions used and the resulting grant-date fair value of our PSUs subject to market conditions granted during the three months ended October 31, 2023 and 2022:

[0001327567-23-000032:notes:107]
|  |  |  | Three Months Ended October 31, |
|  |  |  |  |  | 2023 |  | 2022 |
| Volatility |  |  |  |  | 40.8% - 43.4% |  | 39.6% - 44.8% |
| Expected term (in years) |  |  |  |  | 0.9 - 2.9 |  | 1.0 - 4.0 |
| Dividend yield |  |  |  |  | 0.0 | % |  | 0.0 | % |
| Risk-free interest rate |  |  |  |  | 4.9% - 5.3% |  | 3.2% - 3.6% |
| Grant-date fair value per share |  |  |  |  | $346.92 - $394.63 |  | $105.60 - $280.41 |

[0001327567-23-000032:notes:108]
[same as prior period, unchanged from 0001327567-23-000014:notes:118]

[0001327567-23-000032:notes:109]
We have granted PSOs with both service and market conditions. The market conditions were achieved when certain stock price targets were met. As of October 31, 2023, all of our outstanding PSOs have been fully vested. The maximum contractual term of our outstanding PSOs is seven and a half years from the date of grant in fiscal year 2018 and 2019.

[0001327567-23-000032:notes:110]
The following table summarizes the PSO activity under our stock plans during the three months ended October 31, 2023 (in millions, except per share amounts):

[0001327567-23-000032:notes:111]
|  |  |  |  |  |  |  |  |  | Number of Shares |  | Weighted-Average Exercise Price Per Share |  | Weighted-Average Remaining Contractual Term (Years) |  | Aggregate Intrinsic Value |
| Balance—July 31, 2023 |  |  |  |  |  |  |  |  | 6.4 |  |  | $ | 65.20 |  |  | 2.2 |  | $ | 1,184.6 |  |
| Exercised |  |  |  |  |  |  |  |  | (0.1) |  |  | $ | 64.50 |  |  |  |  |  |
| Balance—October 31, 2023 |  |  |  |  |  |  |  |  | 6.3 |  |  | $ | 65.22 |  |  | 1.9 |  | $ | 1,116.0 |  |
| Exercisable—October 31, 2023 |  |  |  |  |  |  |  |  | 6.3 |  |  | $ | 65.22 |  |  | 1.9 |  | $ | 1,116.0 |  |

[0001327567-23-000032:notes:112]
[same as prior period, unchanged from 0001327567-23-000014:notes:122]

[0001327567-23-000032:notes:113]
[same as prior period, unchanged from 0001327567-23-000014:notes:123]

[0001327567-23-000032:notes:114]
|  |  |  | Three Months Ended October 31, |
|  |  |  |  |  | 2023 |  | 2022 |
| Cost of product revenue |  |  |  |  | $ | 2.4 |  |  | $ | 2.4 |  |
| Cost of subscription and support revenue |  |  |  |  | 30.6 |  |  | 28.8 |  |
| Research and development |  |  |  |  | 120.1 |  |  | 118.0 |  |
| Sales and marketing |  |  |  |  | 79.2 |  |  | 87.4 |  |
| General and administrative |  |  |  |  | 38.7 |  |  | 29.4 |  |
| Total share-based compensation |  |  |  |  | $ | 271.0 |  |  | $ | 266.0 |  |

[0001327567-23-000032:notes:115]
As of October 31, 2023, total compensation cost related to unvested share-based awards not yet recognized was $1.9 billion. This cost is expected to be amortized over a weighted-average period of approximately 2.7 years.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001327567-23-000032:notes:116]
Income Taxes
For the three months ended October 31, 2023 and 2022, our provision for income taxes reflected effective tax rates of 31.3% and 41.9%, respectively.

[0001327567-23-000032:notes:117]
Our income taxes for the three months ended October 31, 2023 and 2022 were primarily due to U.S. federal and state income taxes, withholding taxes, and foreign income taxes. Our effective tax rate decreased for the three months ended October 31, 2023 compared to the same period in 2022 primarily due to higher tax benefits from our share-based compensation. Our effective tax rates differed from the U.S. statutory tax rate primarily due to changes in our valuation allowance.

[0001327567-23-000032:notes:118]
We maintain a full valuation allowance for domestic and certain foreign deferred tax assets, including net operating loss carryforwards and certain domestic tax credits. We regularly evaluate the need for a valuation allowance. Due to recent profitability, a reversal of our valuation allowance in certain jurisdictions in the near future is reasonably possible.


## us-gaap:EarningsPerShareTextBlock

[0001327567-23-000032:notes:119]
Net Income Per ShareBasic net income per share is computed by dividing net income by basic weighted-average shares outstanding during the period. Diluted net income per share is computed by dividing net income by diluted weighted-average shares outstanding during the period giving effect to all potentially dilutive securities to the extent they are dilutive. Potentially dilutive securities include shares issuable upon conversion of our convertible senior notes using the if-converted method, warrants related to the issuance of convertible senior notes, and equity awards under our employee equity incentive plans using the treasury stock method.
The following table presents the computation of basic and diluted net income per share of common stock (in millions, except per share data):

[0001327567-23-000032:notes:120]
|  |  |  | Three Months Ended October 31, |
|  |  |  |  |  | 2023 |  | 2022 |
| Net income |  |  |  |  | $ | 194.2 |  |  | $ | 20.0 |  |
| Weighted-average shares used to compute net income per share, basic |  |  |  |  | 310.1 |  |  | 299.8 |  |
| Weighted-average effect of potentially dilutive securities: |  |  |  |  |  |  |  |
| Convertible senior notes |  |  |  |  | 11.6 |  |  | 17.8 |  |
| Warrants related to the issuance of convertible senior notes |  |  |  |  | 16.0 |  |  | 7.8 |  |
| Employee equity incentive plans |  |  |  |  | 12.1 |  |  | 13.0 |  |
| Weighted-average shares used to compute net income per share, diluted |  |  |  |  | 349.8 |  |  | 338.4 |  |
| Net income per share, basic |  |  |  |  | $ | 0.63 |  |  | $ | 0.07 |  |
| Net income per share, diluted |  |  |  |  | $ | 0.56 |  |  | $ | 0.06 |  |

[0001327567-23-000032:notes:121]
The following securities were excluded from the computation of diluted net income per share of common stock as their effect would have been antidilutive or issuance of such shares is contingent upon the satisfaction of certain conditions which were not satisfied by the end of the applicable period (in millions):

[0001327567-23-000032:notes:122]
|  |  |  | Three Months Ended October 31, |
|  |  |  |  |  | 2023 |  | 2022 |
| Employee equity incentive plans |  |  |  |  | 2.6 |  |  | 2.7 |  |


## us-gaap:OtherNonoperatingIncomeAndExpenseTextBlock

[0001327567-23-000032:notes:123]
Other Income, Net
The following table sets forth the components of other income, net (in millions):

[0001327567-23-000032:notes:124]
|  |  |  | Three Months Ended October 31, |
|  |  |  |  |  | 2023 |  | 2022 |
| Interest income |  |  |  |  | $ | 71.2 |  |  | $ | 29.4 |  |
| Foreign currency exchange gains (losses), net |  |  |  |  | 5.1 |  |  | 4.4 |  |
| Other, net |  |  |  |  | (6.0) |  |  | (7.8) |  |
| Total other income, net |  |  |  |  | $ | 70.3 |  |  | $ | 26.0 |  |


## us-gaap:SubsequentEventsTextBlock

[0001327567-23-000032:notes:125]
Subsequent Events
Acquisitions

[0001327567-23-000032:notes:126]
On October 29, 2023, we entered into a definitive agreement to acquire Dig Security Solutions Ltd., a privately-held cyber security company (“Dig”), for total consideration of approximately $295.0 million, including approximately $232.0 million in cash and approximately $63.0 million in replacement awards, subject to adjustment. We expect the acquisition will enhance our Prisma Cloud capabilities with a data security posture management solution that is intended to provide customers with visibility into, and secure data stored across, their multi-cloud environments.

[0001327567-23-000032:notes:127]
On November 6, 2023, we entered into a definitive agreement to acquire Talon Cyber Security Ltd., a privately-held cyber security company (“Talon”), for total consideration of approximately $550.0 million, including approximately $434.9 million in cash and approximately $115.1 million in replacement awards, subject to adjustment. We expect the acquisition will support Prisma SASE’s approach to provide secure access to business applications for unmanaged and personal devices with an enterprise browser.

[0001327567-23-000032:notes:128]
The proposed acquisitions of Dig and Talon are expected to close during our second quarter of fiscal 2024, subject to the satisfaction of customary closing conditions.

[0001327567-23-000032:notes:129]
Share Repurchase

[0001327567-23-000032:notes:130]
On November 16, 2023, our board of directors authorized a $316.7 million increase to our share repurchase program, bringing the total remaining authorization for future share repurchases to $1.0 billion. The expiration date of the repurchase authorization was extended to December 31, 2024, and our repurchase program may be suspended or discontinued at any time without prior notice. Repurchases may be made at management’s discretion from time to time on the open market, through privately negotiated transactions, transactions structured through investment banking institutions, block purchase techniques, 10b5-1 trading plans, or a combination of the foregoing.


## ecd:MtrlTermsOfTrdArrTextBlock

[0001327567-23-000032:notes:131]
Set forth below is certain information regarding Rule 10b5-1 trading plans adopted by our directors and officers (as defined in Rule 16a-1(f)) during the first quarter of fiscal 2024. The Rule 10b5-1 trading plans listed below are each intended to satisfy the affirmative defense of Rule 10b5-1(c).

[0001327567-23-000032:notes:132]
| Name |  | Title |  | Date Plan Was Adopted |  | Expiration Date |  | Total Amount of Common Stock to be Sold Under the Plan |
| Dipak Golechha |  | Executive Vice President, Chief Financial Officer |  | September 13, 2023 |  | December 31, 2024 or when all shares have been sold |  | 12,500 |  |
| Mary Pat McCarthy |  | Director |  | August 22, 2023 |  | August 23, 2024 or when all shares have been sold |  | 4,000 |  |
