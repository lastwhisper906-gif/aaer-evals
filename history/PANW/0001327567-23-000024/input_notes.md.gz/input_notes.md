# PANW notes — 0001327567-23-000024


## dei:DocumentsIncorporatedByReferenceTextBlock

[0001327567-23-000024:notes:1]
Portions of the information called for by Part III of this Annual Report on Form 10-K is hereby incorporated by reference from the definitive proxy statement for the registrant’s 2023 annual meeting of stockholders, which will be filed with the Securities and Exchange Commission not later than 120 days after the registrant’s fiscal year ended July 31, 2023.


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock

[0001327567-23-000024:notes:2]
Description of Business and Summary of Significant Accounting Policies 
Description of Business

[0001327567-23-000024:notes:3]
Palo Alto Networks, Inc. (the “Company,” “we,” “us,” or “our”), headquartered in Santa Clara, California, was incorporated in March 2005 under the laws of the State of Delaware and commenced operations in April 2005. We empower enterprises, organizations, service providers, and government entities to secure their users, networks, clouds and endpoints by delivering comprehensive cybersecurity enabled by artificial intelligence and automation.

[0001327567-23-000024:notes:4]
Basis of Presentation

[0001327567-23-000024:notes:5]
The accompanying consolidated financial statements have been prepared in conformity with U.S. generally accepted accounting principles (“U.S. GAAP”). The consolidated financial statements include all adjustments necessary for a fair presentation of our annual results. All adjustments are of a normal recurring nature.

[0001327567-23-000024:notes:6]
Principles of Consolidation

[0001327567-23-000024:notes:7]
The consolidated financial statements include our accounts and our wholly owned subsidiaries. All significant intercompany balances and transactions have been eliminated in consolidation.

[0001327567-23-000024:notes:8]
Reclassification

[0001327567-23-000024:notes:9]
Certain prior period amounts in the consolidated financial statements and accompanying notes have been reclassified to conform to the current period presentation.

[0001327567-23-000024:notes:10]
Use of Estimates

[0001327567-23-000024:notes:11]
The preparation of consolidated financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the amounts reported and disclosed in the consolidated financial statements and the accompanying notes. We evaluate our estimates on an ongoing basis. Management estimates include, but are not limited to, the standalone selling price for our products and services, share-based compensation, fair value of assets acquired and liabilities assumed in business combinations, the assessment of recoverability of our intangibles and goodwill, valuation allowance against deferred tax assets, manufacturing partner and supplier liabilities, deferred contract cost benefit period, and loss contingencies. We base our estimates on assumptions, both historical and forward looking, that we believe are reasonable. Actual results could differ materially from those estimates due to risks and uncertainties, including uncertainty in the current economic environment.

[0001327567-23-000024:notes:12]
Stock Split Effected in the Form of a Stock Dividend (“Stock Split”)

[0001327567-23-000024:notes:13]
On September 13, 2022, we executed a three-for-one stock split of our common stock, effected in the form of a stock dividend. The par value per share of our common stock remains unchanged at $0.0001 per share after the Stock Split. All references made to share or per share amounts on the accompanying consolidated financial statements and applicable disclosures have been retroactively adjusted to reflect the effects of the Stock Split.

[0001327567-23-000024:notes:14]
Concentrations

[0001327567-23-000024:notes:15]
Financial instruments that subject us to concentrations of credit risk consist primarily of cash and cash equivalents, investments, derivative contracts, accounts receivable and financing receivables.

[0001327567-23-000024:notes:16]
We invest only in high-quality credit instruments and our cash and cash equivalents and available-for-sale investments consist primarily of fixed income securities. Management believes that the financial institutions that hold our investments are financially sound and, accordingly, are subject to minimal credit risk. Deposits held with banks may exceed the amount of insurance provided on such deposits.

[0001327567-23-000024:notes:17]
Our derivative contracts expose us to credit risk to the extent that the counterparties may be unable to meet the terms of the arrangement. We mitigate this credit risk by transacting with major financial institutions with high credit ratings and also enter into master netting arrangements, which permit net settlement of transactions with the same counterparty. We are not required to pledge, and are not entitled to receive, cash collateral related to these derivative instruments. We do not enter into derivative contracts for trading or speculative purposes.

[0001327567-23-000024:notes:18]
Our accounts receivable are primarily derived from our distributors in various geographical locations. Our financing receivables are with qualified end-customers and channel partners. We perform ongoing credit evaluations and generally do not require collateral on accounts receivable or financing receivables.

[0001327567-23-000024:notes:19]
As of July 31, 2023, two distributors individually represented 10% or more of our gross accounts receivable, and in the aggregate represented 37.6% of our gross accounts receivable. As of July 31, 2023, no end-customers or channel partners represented 10% or more of our gross financing receivables.

[0001327567-23-000024:notes:20]
For fiscal 2023, three distributors represented 10% or more of our total revenue, representing 25.0%, 12.8%, and 11.9%, respectively. No single end-customer accounted for more than 10% of our total revenue in fiscal 2023, 2022, or 2021.

[0001327567-23-000024:notes:21]
We rely on an electronics manufacturing services provider (“EMS provider”) to assemble most of our products and sole source component suppliers for certain components.

[0001327567-23-000024:notes:22]
Comprehensive Income (Loss)

[0001327567-23-000024:notes:23]
Comprehensive income (loss) is comprised of net income (loss) and other comprehensive income (loss). Our other comprehensive income (loss) includes unrealized gains and losses on available-for-sale investments and unrealized gains and losses on cash flow hedges.

[0001327567-23-000024:notes:24]
Foreign Currency Transactions

[0001327567-23-000024:notes:25]
The functional currency of our foreign subsidiaries is the U.S. dollar. Monetary assets and liabilities denominated in foreign currencies have been remeasured into U.S. dollars using the exchange rates in effect at the balance sheet dates. Foreign currency remeasurement gains and losses and foreign currency transaction gains and losses are not significant to the consolidated financial statements.

[0001327567-23-000024:notes:26]
Fair Value

[0001327567-23-000024:notes:27]
We define fair value as the price that would be received from selling an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date. When determining the fair value measurements for assets and liabilities which are required to be recorded at fair value, we consider the principal or most advantageous market in which to transact and the market-based risk.

[0001327567-23-000024:notes:28]
We categorize assets and liabilities recorded or disclosed at fair value on our consolidated balance sheets based upon the level of judgment associated with inputs used to measure their fair value. The categories are as follows:

[0001327567-23-000024:notes:29]
•Level 1—Inputs are unadjusted quoted prices in active markets for identical assets or liabilities.

[0001327567-23-000024:notes:30]
•Level 2—Inputs are quoted prices for similar assets and liabilities in active markets or inputs that are observable for the assets or liabilities, either directly or indirectly through market corroboration, for substantially the full term of the financial instruments.

[0001327567-23-000024:notes:31]
•Level 3—Inputs are unobservable inputs based on our own assumptions used to measure assets and liabilities at fair value. The inputs require significant management judgment or estimation.

[0001327567-23-000024:notes:32]
Our financial assets and liabilities that are measured at fair value on a recurring basis include marketable securities and derivative financial instruments. Goodwill, intangible assets, and other long-lived assets are measured at fair value on a nonrecurring basis, only if impairment is indicated. The carrying amounts reported in the consolidated financial statements approximate the fair value for cash and cash equivalents, accounts receivable, accounts payable, and accrued liabilities due to their short-term nature.

[0001327567-23-000024:notes:33]
Cash, Cash Equivalents, and Investments

[0001327567-23-000024:notes:34]
We consider all highly liquid investments with original maturities of three months or less at the date of purchase to be cash equivalents. Investments not considered cash equivalents and with maturities of one year or less from the consolidated balance sheet date are classified as short-term investments. Investments with maturities greater than one year from the consolidated balance sheet date are classified as long-term investments.

[0001327567-23-000024:notes:35]
We determine the classification of our investments in marketable debt securities at the time of purchase and reevaluate such determination at each balance sheet date. Our marketable debt securities are classified as available-for-sale. Debt securities in an unrealized loss position are written down to its fair value with the corresponding charge recorded in other income, net on our consolidated statements of operations, if it is more likely than not that we will be required to sell the impaired security before recovery of its amortized cost basis, or we have the intention to sell the security. If neither of these conditions are met, we determine whether a credit loss exists by comparing the present value of the expected cash flows of the security with its amortized cost basis. An allowance for credit losses is recorded in other income, net on our consolidated statements of operations for an amount not to exceed the unrealized loss. Unrealized losses that are not credit-related are included in accumulated other comprehensive income (loss) (“AOCI”) in stockholders’ equity.

[0001327567-23-000024:notes:36]
Accounts Receivable

[0001327567-23-000024:notes:37]
Trade accounts receivable are recorded at the invoiced amount, net of allowances for credit losses. The allowance for credit losses is based on our assessment of collectability. Management regularly reviews the adequacy of the allowance for credit losses on a collective basis by considering the age of each outstanding invoice, each customer’s expected ability to pay and collection history, current market conditions, and, where appropriate, reasonable and supportable forecasts of future economic conditions. Accounts receivable deemed uncollectible are charged against the allowance for credit losses. For the years ended July 31, 2023 and 2022, the allowance for credit losses activity was not significant.

[0001327567-23-000024:notes:38]
Financing Receivables

[0001327567-23-000024:notes:39]
We provide financing arrangements for certain qualified end-customers and channel partners to purchase our products and services. Payment terms on these financing arrangements are up to five years. Financing receivables are recorded at amortized cost, which approximates fair value. We may sell, in certain instances, these financing arrangements on a non-recourse basis to third-party financial institutions. The financing receivables are derecognized upon transfer as these sales qualify as true sales.

[0001327567-23-000024:notes:40]
We evaluate the allowance for credit losses by assessing the risks and losses inherent in our financing receivables on either an individual or a collective basis. Our assessment considers various factors, including lifetime expected losses determined using customer risk profile, current economic conditions that may affect a customer’s ability to pay, and forward-looking economic considerations. Financing receivables deemed uncollectible are charged against the allowance for credit losses.

[0001327567-23-000024:notes:41]
Derivatives

[0001327567-23-000024:notes:42]
We are exposed to foreign currency exchange risk. Our revenue is transacted in U.S. dollars, however, a portion of our operating expenditures are incurred outside of the United States and are denominated in foreign currencies, making them subject to fluctuations in foreign currency exchange rates. We enter into foreign currency derivative contracts with maturities of 24 months or less, which we designate as cash flow hedges, to manage the foreign currency exchange risk associated with our operating expenditures.

[0001327567-23-000024:notes:43]
Our derivative financial instruments are recorded at fair value, on a gross basis, as either assets or liabilities on our consolidated balance sheets. Gains or losses related to our cash flow hedges are recorded as a component of AOCI on our consolidated balance sheets and are reclassified into the financial statement line item associated with the underlying hedged transaction on our consolidated statements of operations when the underlying hedged transaction is recognized in earnings. Gains or losses related to non-designated derivative instruments are recognized in other income, net on our consolidated statements of operations for each period until the instrument matures, is terminated, is re-designated as a qualified cash flow hedge, or is sold. Derivatives designated as cash flow hedges are classified on our consolidated statements of cash flows in the same manner as the underlying hedged transaction, primarily within cash flows from operating activities.

[0001327567-23-000024:notes:44]
Property and Equipment

[0001327567-23-000024:notes:45]
Property and equipment are stated at cost, less accumulated depreciation. Depreciation is computed using the straight-line method over the estimated useful lives of the assets. Land is not depreciated. The estimated useful lives of our depreciable assets are as follows:

[0001327567-23-000024:notes:46]
| Asset category |  | Useful life |
| Computers, equipment, and software |  | 3 - 5 years |
| Demonstration units |  | 3 - 4 years |
| Furniture and fixtures |  | 5 years |
| Leasehold improvements |  | Lesser of 10 years or remaining lease term |

[0001327567-23-000024:notes:47]
Business Combinations

[0001327567-23-000024:notes:48]
We include the results of operations of the businesses that we acquire as of the respective dates of acquisition. We allocate the fair value of the purchase price of our acquisitions to the assets acquired and liabilities assumed, generally based on their estimated fair values. The excess of the purchase price over the fair values of these identifiable assets and liabilities is recorded as goodwill. Additional information existing as of the acquisition date but unknown to us may become known during the remainder of the measurement period, not to exceed 12 months from the acquisition date, which may result in changes to the amounts and allocations recorded.

[0001327567-23-000024:notes:49]
Intangible Assets

[0001327567-23-000024:notes:50]
Purchased intangible assets with finite lives are carried at cost, less accumulated amortization. Amortization is computed using the straight-line method over the estimated useful lives of the respective assets. Acquisition-related in-process research and development represents the fair value of incomplete research and development projects that have not reached technological feasibility as of the date of acquisition. Initially, these assets are not subject to amortization. Assets related to projects that have been completed are transferred to developed technology, which are subject to amortization.

[0001327567-23-000024:notes:51]
Impairment of Goodwill, Intangible Assets, and Other Long-Lived Assets

[0001327567-23-000024:notes:52]
Goodwill is evaluated for impairment on an annual basis in the fourth quarter of our fiscal year, and whenever events or changes in circumstances indicate the carrying amount of goodwill may not be recoverable. We have elected to first assess qualitative factors to determine whether it is more likely than not that the fair value of our single reporting unit is less than its carrying amount, including goodwill. If we determine that it is more likely than not that the fair value is less than its carrying amount, then the quantitative impairment test will be performed. Under the quantitative impairment test, if the carrying amount exceeds its fair value, we will recognize an impairment loss in an amount equal to that excess but limited to the total amount of goodwill.

[0001327567-23-000024:notes:53]
We evaluate events and changes in circumstances that could indicate carrying amounts of purchased intangible assets and other long-lived assets may not be recoverable. When such events or changes in circumstances occur, we assess the recoverability of these assets or asset groups by determining whether or not the carrying amount will be recovered through undiscounted expected future cash flows. If the total of the future undiscounted cash flows is less than the carrying amount of an asset or asset group, we record an impairment loss for the amount by which the carrying amount exceeds the fair value of the asset or asset group.

[0001327567-23-000024:notes:54]
We did not recognize any impairment losses on our goodwill, intangible assets, or other long-lived assets during the years ended July 31, 2023, 2022, and 2021.

[0001327567-23-000024:notes:55]
Manufacturing Partner and Supplier Liabilities

[0001327567-23-000024:notes:56]
We outsource most of our manufacturing, repair, and supply chain management operations to our EMS provider and payments to it are a significant portion of our cost of product revenue. Although we are contractually obligated to purchase manufactured products and components, we generally do not own the components and manufactured products. Product title transfers from our EMS provider to us and immediately to our customers upon shipment. Our EMS provider assembles our products using design specifications, quality assurance programs, and standards that we establish, and it procures components and assembles products based on our demand forecasts. These forecasts represent our estimates of future demand for our products based upon historical trends and analysis from our sales and product management functions as adjusted for overall market conditions. If the actual component usage and product demand are significantly lower than forecast, we record a liability for manufacturing purchase commitments in excess of our forecasted demand, including costs for excess components or for carrying costs incurred by our manufacturing partners and component suppliers. Through July 31, 2023, we have not accrued any significant costs associated with this exposure.

[0001327567-23-000024:notes:57]
Convertible Senior Notes

[0001327567-23-000024:notes:58]
Prior to August 1, 2021, our convertible senior notes were separated into a liability and an equity component. The carrying amount of the liability component was calculated by measuring the fair value of a similar liability that did not have an associated convertible feature, using a discounted cash flow model with a risk-adjusted yield. The carrying amount of the equity component representing the conversion option was determined by deducting the fair value of the liability component from the par value of the notes as a whole. This difference represented a debt discount that was amortized to interest expense using the effective interest method over the term of the notes. The equity component was not remeasured as it continued to meet the conditions for equity classification. Transaction costs related to the issuance of the notes were allocated to the liability and equity components using the same proportions as the proceeds from the notes. Transaction costs attributable to the liability component were netted with the liability component and amortized to interest expense using the effective interest method over the term of the notes. Transaction costs attributable to the equity component were netted with the equity component of the notes in additional paid-in capital. Upon the notes becoming convertible, the net carrying amount of the liability component was classified as a current liability and a portion of the equity component representing the conversion option was reclassified to temporary equity. The portion of the equity component classified as temporary equity was measured as the difference between the principal and net carrying amount of the notes, excluding debt issuance costs.

[0001327567-23-000024:notes:59]
Upon adoption of the new debt guidance on August 1, 2021, our convertible senior notes are accounted for entirely as a liability and measured at their amortized cost. Transaction costs related to the issuance of the notes are netted with the liability and are amortized on a straight-line basis, which approximates the effective interest rate method, to interest expense over the term of the notes.

[0001327567-23-000024:notes:60]
Revenue Recognition

[0001327567-23-000024:notes:61]
Our revenue consists of product revenue and subscription and support revenue. Revenue is recognized when control of promised products, subscriptions and support services are transferred to customers, in an amount that reflects the expected consideration in exchange for those products and services.

[0001327567-23-000024:notes:62]
We determine revenue recognition through the following steps:

[0001327567-23-000024:notes:63]
•Identification of the contract, or contracts, with a customer.

[0001327567-23-000024:notes:64]
•Identification of the performance obligations in the contract.

[0001327567-23-000024:notes:65]
•Determination of the transaction price.

[0001327567-23-000024:notes:66]
•Allocation of the transaction price to the performance obligations in the contract.

[0001327567-23-000024:notes:67]
•Recognition of revenue when, or as, we satisfy a performance obligation.

[0001327567-23-000024:notes:68]
Revenues are reported net of sales taxes. Shipping charges billed to our customers are included in revenue and related costs are included in cost of revenue.

[0001327567-23-000024:notes:69]
Product Revenue

[0001327567-23-000024:notes:70]
Product revenue is derived primarily from sales of our appliances. Product revenue also includes revenue derived from software licenses of Panorama, SD-WAN, and the VM-Series. Our appliances and software licenses include a broad set of built-in networking and security features and functionalities. We recognize product revenue at the time of hardware shipment or delivery of software license.

[0001327567-23-000024:notes:71]
Subscription and Support Revenue

[0001327567-23-000024:notes:72]
Subscription and support revenue is derived primarily from sales of our subscription and support offerings. We recognize subscription and support revenue over time as the services are performed. Our contractual subscription and support contracts are typically one to five years.

[0001327567-23-000024:notes:73]
Contracts with Multiple Performance Obligations

[0001327567-23-000024:notes:74]
The majority of our contracts with our customers include various combinations of our products and subscriptions and support. Our appliances and software licenses have significant standalone functionalities and capabilities. Accordingly, these appliances and software licenses are distinct from our subscriptions and support services as the customer can benefit from the product without these services and such services are separately identifiable within the contract. We account for multiple agreements with a single customer as a single contract if the contractual terms and/or substance of those agreements indicate that they may be so closely related that they are, in effect, parts of a single contract. The amount of consideration we expect to receive in exchange for delivering on the contract is allocated to each performance obligation based on its relative standalone selling price.

[0001327567-23-000024:notes:75]
We establish standalone selling price using the prices charged for a deliverable when sold separately. If the standalone selling price is not observable through past transactions, we estimate the standalone selling price based on our pricing model and our go-to-market strategy, which include factors such as type of sales channel (channel partner or end-customer), the geographies in which our offerings were sold (domestic or international), and offering type (products, subscriptions, or support).

[0001327567-23-000024:notes:76]
Deferred Revenue

[0001327567-23-000024:notes:77]
We record deferred revenue when cash payments are received or due in advance of our performance. Our payment terms typically require payment within 30 to 45 days of the date we issue an invoice. The current portion of deferred revenue represents the amounts that are expected to be recognized as revenue within one year of the consolidated balance sheet date.

[0001327567-23-000024:notes:78]
Deferred Contract Costs

[0001327567-23-000024:notes:79]
We defer contract costs that are recoverable and incremental to obtaining customer sales contracts. Contract costs, which primarily consist of sales commissions, are amortized on a systematic basis that is consistent with the transfer to the customer of the goods or services to which the asset relates. Sales commissions paid for initial contracts are generally not commensurate with the commissions paid for renewal contracts, given the substantive difference in commission rates in proportion to their respective contract values. Sales commissions for initial contracts that are not commensurate are amortized over a benefit period of five years. The benefit period is determined by taking into consideration contract length, expected renewals, technology life, and other quantitative and qualitative factors. Sales commissions for initial contracts that are commensurate and sales commissions for renewal contracts are amortized over the related contractual period.

[0001327567-23-000024:notes:80]
We classify deferred contract costs as short-term or long-term based on when we expect to recognize the expense. The amortization of deferred contract costs is included in sales and marketing expense on our consolidated statements of operations. Deferred contract costs are periodically reviewed for impairment. We did not recognize any impairment losses on our deferred contract costs during the years ended July 31, 2023, 2022, or 2021.

[0001327567-23-000024:notes:81]
Software Development Costs

[0001327567-23-000024:notes:82]
Internally developed software includes security software developed to deliver our cloud-based subscription offerings to our end-customers. These capitalized costs consist of internal compensation-related costs and external direct costs incurred during the application development stage and will be amortized over a useful life of three years. As of July 31, 2023 and 2022, we capitalized as other assets on our consolidated balance sheets $132.1 million and $130.9 million in costs, respectively, net of accumulated amortization, for security software developed to deliver our cloud-based subscription offerings. We recognized amortization expense of $79.5 million, $62.4 million, and $47.8 million related to these capitalized costs as cost of subscription and support revenue on our consolidated statements of operations during the years ended July 31, 2023, 2022, and 2021, respectively.

[0001327567-23-000024:notes:83]
The costs to develop software that is marketed externally have not been capitalized as we believe our current software development process is essentially completed concurrent with the establishment of technological feasibility. As such, all related software development costs are expensed as incurred and included in research and development expense on our consolidated statements of operations.

[0001327567-23-000024:notes:84]
Share-Based Compensation

[0001327567-23-000024:notes:85]
Compensation expense related to share-based transactions is measured at fair value on the grant date. We recognize share-based compensation expense for awards with only service conditions on a straight-line basis over the requisite service period. We recognize share-based compensation expense for awards with market conditions and awards with performance conditions on a straight-line basis over the requisite service period for each separately vesting portion of the award. We recognize share-based compensation expense for awards with performance conditions when it is probable that the performance condition will be achieved. We account for forfeitures of all share-based payment awards when they occur.

[0001327567-23-000024:notes:86]
Leases

[0001327567-23-000024:notes:87]
We determine if an arrangement is a lease at inception. We evaluate the classification of leases at commencement and, as necessary, at modification. Operating lease related balances are included in operating lease right-of-use assets, accrued and other liabilities, and long-term operating lease liabilities on our consolidated balance sheets. We did not have any material finance leases in any of the periods presented.

[0001327567-23-000024:notes:88]
Operating lease right-of-use assets represent our right to use an underlying asset for the lease term. Operating lease liabilities represent our obligation to make payments arising from the lease. Operating lease right-of-use assets and liabilities are recognized at the present value of the future lease payments at the lease commencement date. The interest rate used to determine the present value of the future lease payments is our incremental borrowing rate, because the interest rates implicit in most of our leases are not readily determinable. Our incremental borrowing rate is estimated to approximate the interest rate on a collateralized basis with similar terms and payments, and in economic environments where the leased asset is located. Operating lease right-of-use assets also include adjustments related to lease incentives, prepaid or accrued rent and initial direct lease costs. Operating lease right-of-use assets are subject to evaluation for impairment or disposal on a basis consistent with other long-lived assets.

[0001327567-23-000024:notes:89]
Our lease terms may include periods under options to extend or terminate the lease when it is reasonably certain that we will exercise that option. We generally use the base, non-cancelable lease term when determining the lease right-of-use assets and lease liabilities. Operating lease cost is recognized on a straight-line basis over the lease term.

[0001327567-23-000024:notes:90]
We account for lease and non-lease components as a single lease component and do not recognize right-of-use assets and lease liabilities for leases with a term of 12 months or less. Payments under our lease arrangements are primarily fixed, however, certain lease agreements contain variable payments, which are expensed as incurred and not included in the operating lease right-of-use assets and liabilities. Variable lease payments are primarily comprised of real estate taxes, common area maintenance charges, and insurance costs.

[0001327567-23-000024:notes:91]
Income Taxes

[0001327567-23-000024:notes:92]
We account for income taxes using the asset and liability method, which requires the recognition of deferred tax assets and liabilities for the expected future tax consequences of events that have been recognized in our consolidated financial statements or tax returns. In addition, deferred tax assets are recorded for all future benefits including, but not limited to, net operating losses, research and development credit carryforwards, and basis differences relating to our global intangible low-taxed income. Valuation allowances are provided when necessary to reduce deferred tax assets to the amount more likely than not to be realized.

[0001327567-23-000024:notes:93]
Significant judgment is required in determining any valuation allowance recorded against deferred tax assets. In assessing the need for a valuation allowance, we consider all available evidence, including past operating results, estimates of future taxable income, and the feasibility of tax planning strategies. In the event that we change our determination as to the amount of deferred tax assets that can be realized, we will adjust our valuation allowance with a corresponding impact to the provision for income taxes in the period in which such determination is made.

[0001327567-23-000024:notes:94]
We recognize liabilities for uncertain tax positions based on a two-step process. The first step is to evaluate the tax position for recognition by determining if the weight of available evidence indicates that it is more likely than not that the position will be sustained on audit, including resolution of related appeals or litigation processes, if any. The second step requires us to estimate and measure the tax benefit as the largest amount that is more likely than not to be realized upon ultimate settlement.

[0001327567-23-000024:notes:95]
Loss Contingencies

[0001327567-23-000024:notes:96]
We are subject to the possibility of various loss contingencies arising in the ordinary course of business. In determining loss contingencies, we consider the likelihood of loss or impairment of an asset, or the incurrence of a liability, as well as our ability to reasonably estimate the amount of loss. An estimated loss contingency is accrued when it is probable that an asset has been impaired or a liability has been incurred and the amount of loss can be reasonably estimated. If we determine that a loss is reasonably possible, then we disclose the possible loss or range of the possible loss or state that such an estimate cannot be made. We regularly evaluate current information available to us to determine whether an accrual is required, an accrual should be adjusted, or a range of possible loss should be disclosed.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001327567-23-000024:notes:97]
Revenue 
Disaggregation of Revenue

[0001327567-23-000024:notes:98]
The following table presents revenue by geographic theater (in millions):

[0001327567-23-000024:notes:99]
|  | Year Ended July 31, |
|  | 2023 |  | 2022 |  | 2021 |
| Revenue: |  |  |  |  |  |
| Americas |  |  |  |  |  |
| United States | $ | 4,424.2 |  |  | $ | 3,560.3 |  |  | $ | 2,747.8 |  |
| Other Americas | 295.7 |  |  | 242.3 |  |  | 189.7 |  |
| Total Americas | 4,719.9 |  |  | 3,802.6 |  |  | 2,937.5 |  |
| Europe, the Middle East, and Africa (“EMEA”) | 1,359.6 |  |  | 1,055.8 |  |  | 817.3 |  |
| Asia Pacific and Japan (“APAC”) | 813.2 |  |  | 643.1 |  |  | 501.3 |  |
| Total revenue | $ | 6,892.7 |  |  | $ | 5,501.5 |  |  | $ | 4,256.1 |  |

[0001327567-23-000024:notes:100]
The following table presents revenue for groups of similar products and services (in millions):

[0001327567-23-000024:notes:101]
|  | Year Ended July 31, |
|  | 2023 |  | 2022 |  | 2021 |
| Revenue: |  |  |  |  |  |
| Product | $ | 1,578.4 |  |  | $ | 1,363.1 |  |  | $ | 1,120.3 |  |
| Subscription and support |  |  |  |  |  |
| Subscription | 3,335.4 |  |  | 2,539.0 |  |  | 1898.8 |
| Support | 1,978.9 |  |  | 1,599.4 |  |  | 1,237.0 |  |
| Total subscription and support | 5,314.3 |  |  | 4,138.4 |  |  | 3,135.8 |  |
| Total revenue | $ | 6,892.7 |  |  | $ | 5,501.5 |  |  | $ | 4,256.1 |  |

[0001327567-23-000024:notes:102]
During the years ended July 31, 2023 and 2022, we recognized approximately $3.6 billion and $2.7 billion of revenue pertaining to amounts that were deferred as of July 31, 2022 and 2021, respectively.

[0001327567-23-000024:notes:103]
Remaining Performance Obligations

[0001327567-23-000024:notes:104]
Remaining performance obligations were $10.6 billion as of July 31, 2023, of which we expect to recognize as revenue approximately $5.1 billion over the next 12 months and the remainder thereafter.


## us-gaap:FairValueDisclosuresTextBlock

[0001327567-23-000024:notes:105]
Fair Value Measurements 
The following table presents our financial assets and liabilities measured at fair value on a recurring basis as of July 31, 2023 and 2022 (in millions):

[0001327567-23-000024:notes:106]
|  |  | July 31, 2023 |  | July 31, 2022 |
|  |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Cash equivalents: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 476.1 |  |  | $ | — |  |  | $ | — |  |  | $ | 476.1 |  |  | $ | 1,205.2 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,205.2 |  |
| Certificates of deposit |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 155.3 |  |  | — |  |  | 155.3 |  |
| Commercial paper |  | — |  |  | 151.4 |  |  | — |  |  | 151.4 |  |  | — |  |  | 69.1 |  |  | — |  |  | 69.1 |  |
| Corporate debt securities |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 19.5 |  |  | — |  |  | 19.5 |  |
| U.S. government and agency securities |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 10.0 |  |  | — |  |  | 10.0 |  |
| Non-U.S. government and agency securities |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 5.1 |  |  | — |  |  | 5.1 |  |
| Total cash equivalents |  | 476.1 |  |  | 151.4 |  |  | — |  |  | 627.5 |  |  | 1,205.2 |  |  | 259.0 |  |  | — |  |  | 1,464.2 |  |
| Short-term investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Certificates of deposit |  | — |  |  | 48.1 |  |  | — |  |  | 48.1 |  |  | — |  |  | 116.4 |  |  | — |  |  | 116.4 |  |
| Commercial paper |  | — |  |  | 213.8 |  |  | — |  |  | 213.8 |  |  | — |  |  | 79.0 |  |  | — |  |  | 79.0 |  |
| Corporate debt securities |  | — |  |  | 798.0 |  |  | — |  |  | 798.0 |  |  | — |  |  | 505.0 |  |  | — |  |  | 505.0 |  |
| U.S. government and agency securities |  | — |  |  | 190.6 |  |  | — |  |  | 190.6 |  |  | — |  |  | 798.2 |  |  | — |  |  | 798.2 |  |
| Non-U.S. government and agency securities |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 17.4 |  |  | — |  |  | 17.4 |  |
| Asset-backed securities |  | — |  |  | 4.2 |  |  | — |  |  | 4.2 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Total short-term investments |  | — |  |  | 1,254.7 |  |  | — |  |  | 1,254.7 |  |  | — |  |  | 1,516.0 |  |  | — |  |  | 1,516.0 |  |
| Long-term investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate debt securities |  | — |  |  | 2,484.3 |  |  | — |  |  | 2,484.3 |  |  | — |  |  | 761.2 |  |  | — |  |  | 761.2 |  |
| U.S. government and agency securities |  | — |  |  | 22.0 |  |  | — |  |  | 22.0 |  |  | — |  |  | 118.2 |  |  | — |  |  | 118.2 |  |
| Non-U.S. government and agency securities |  | — |  |  | 36.6 |  |  | — |  |  | 36.6 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Asset-backed securities |  | — |  |  | 505.0 |  |  | — |  |  | 505.0 |  |  | — |  |  | 172.5 |  |  | — |  |  | 172.5 |  |
| Total long-term investments |  | — |  |  | 3,047.9 |  |  | — |  |  | 3,047.9 |  |  | — |  |  | 1,051.9 |  |  | — |  |  | 1,051.9 |  |
| Prepaid expenses and other current assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency forward contracts |  | — |  |  | 19.1 |  |  | — |  |  | 19.1 |  |  | — |  |  | 2.4 |  |  | — |  |  | 2.4 |  |
| Total prepaid expenses and other current assets |  | — |  |  | 19.1 |  |  | — |  |  | 19.1 |  |  | — |  |  | 2.4 |  |  | — |  |  | 2.4 |  |
| Other assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency forward contracts |  | — |  |  | 1.7 |  |  | — |  |  | 1.7 |  |  | — |  |  | 0.7 |  |  | — |  |  | 0.7 |  |
| Total other assets |  | — |  |  | 1.7 |  |  | — |  |  | 1.7 |  |  | — |  |  | 0.7 |  |  | — |  |  | 0.7 |  |
| Total assets measured at fair value |  | $ | 476.1 |  |  | $ | 4,474.8 |  |  | $ | — |  |  | $ | 4,950.9 |  |  | $ | 1,205.2 |  |  | $ | 2,830.0 |  |  | $ | — |  |  | $ | 4,035.2 |  |

[0001327567-23-000024:notes:107]
|  |  | July 31, 2023 |  | July 31, 2022 |
|  |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Accrued and other liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency forward contracts |  | $ | — |  |  | $ | 18.7 |  |  | $ | — |  |  | $ | 18.7 |  |  | $ | — |  |  | $ | 32.4 |  |  | $ | — |  |  | $ | 32.4 |  |
| Total accrued and other liabilities |  | — |  |  | 18.7 |  |  | — |  |  | 18.7 |  |  | — |  |  | 32.4 |  |  | — |  |  | 32.4 |  |
| Other long-term liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency forward contracts |  | — |  |  | 1.6 |  |  | — |  |  | 1.6 |  |  | — |  |  | 0.8 |  |  | — |  |  | 0.8 |  |
| Total other long-term liabilities |  | — |  |  | 1.6 |  |  | — |  |  | 1.6 |  |  | — |  |  | 0.8 |  |  | — |  |  | 0.8 |  |
| Total liabilities measured at fair value |  | $ | — |  |  | $ | 20.3 |  |  | $ | — |  |  | $ | 20.3 |  |  | $ | — |  |  | $ | 33.2 |  |  | $ | — |  |  | $ | 33.2 |  |

[0001327567-23-000024:notes:108]
Refer to Note 10. Debt, for the carrying amount and estimated fair value of our convertible senior notes as of July 31, 2023 and 2022.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001327567-23-000024:notes:109]
Cash Equivalents and Investments
Available-for-sale Debt Securities

[0001327567-23-000024:notes:110]
The following tables summarize the amortized cost, unrealized gains and losses, and fair value of our available-for-sale debt securities (in millions):

[0001327567-23-000024:notes:111]
|  | July 31, 2023 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | $ | 151.4 |  |  | $ | — |  |  | $ | — |  |  | $ | 151.4 |  |
| Total available-for-sale cash equivalents | $ | 151.4 |  |  | $ | — |  |  | $ | — |  |  | $ | 151.4 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 48.1 |  |  | $ | — |  |  | $ | — |  |  | $ | 48.1 |  |
| Commercial paper | 214.1 |  |  | — |  |  | (0.3) |  |  | 213.8 |  |
| Corporate debt securities | 3,313.5 |  |  | 1.3 |  |  | (32.5) |  |  | 3,282.3 |  |
| U.S. government and agency securities | 214.2 |  |  | — |  |  | (1.6) |  |  | 212.6 |  |
| Non-U.S. government and agency securities | 37.2 |  |  | — |  |  | (0.6) |  |  | 36.6 |  |
| Asset-backed securities | 512.0 |  |  | 0.2 |  |  | (3.0) |  |  | 509.2 |  |
| Total available-for-sale investments | $ | 4,339.1 |  |  | $ | 1.5 |  |  | $ | (38.0) |  |  | $ | 4,302.6 |  |

[0001327567-23-000024:notes:112]
|  | July 31, 2022 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 155.3 |  |  | $ | — |  |  | $ | — |  |  | $ | 155.3 |  |
| Commercial paper | 69.1 |  |  | — |  |  | — |  |  | 69.1 |  |
| Corporate debt securities | 19.5 |  |  | — |  |  | — |  |  | 19.5 |  |
| U.S. government and agency securities | 10.0 |  |  | — |  |  | — |  |  | 10.0 |  |
| Non-U.S. government and agency securities | 5.0 |  |  | 0.1 |  |  | — |  |  | 5.1 |  |
| Total available-for-sale cash equivalents | $ | 258.9 |  |  | $ | 0.1 |  |  | $ | — |  |  | $ | 259.0 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 116.5 |  |  | $ | — |  |  | $ | (0.1) |  |  | $ | 116.4 |  |
| Commercial paper | 79.1 |  |  | — |  |  | (0.1) |  |  | 79.0 |  |
| Corporate debt securities | 1,276.8 |  |  | 1.3 |  |  | (11.9) |  |  | 1,266.2 |  |
| U.S. government and agency securities | 928.1 |  |  | 0.1 |  |  | (11.8) |  |  | 916.4 |  |
| Non-U.S. government and agency securities | 17.6 |  |  | — |  |  | (0.2) |  |  | 17.4 |  |
| Asset-backed securities | 173.4 |  |  | 0.2 |  |  | (1.1) |  |  | 172.5 |  |
| Total available-for-sale investments | $ | 2,591.5 |  |  | $ | 1.6 |  |  | $ | (25.2) |  |  | $ | 2,567.9 |  |

[0001327567-23-000024:notes:113]
As of July 31, 2023, the gross unrealized losses that have been in a continuous unrealized loss position for less than 12 months were $30.7 million, which were related to $3.4 billion of available-for-sale debt securities, and the gross unrealized losses that have been in a continuous unrealized loss position for more than 12 months were $7.3 million, which were related to $481.8 million of available-for-sale debt securities. As of July 31, 2022 the gross unrealized losses that have been in a continuous unrealized loss position for less than 12 months were $24.8 million, which were related to $2.0 billion of available-for-sale debt securities, and the gross unrealized losses that have been in a continuous unrealized loss position for more than 12 months were not material.

[0001327567-23-000024:notes:114]
Unrealized losses related to our available-for-sale debt securities are primarily due to interest rate fluctuations as opposed to credit quality. We do not intend to sell any of the securities in an unrealized loss position and it is not likely that we would be required to sell these securities before recovery of their amortized cost basis, which may be at maturity. We did not recognize any credit losses related to our available-for-sale debt securities during the years ended July 31, 2023 and 2022.

[0001327567-23-000024:notes:115]
The following table summarizes the amortized cost and fair value of our available-for-sale debt securities as of July 31, 2023, by contractual years-to-maturity (in millions):

[0001327567-23-000024:notes:116]
|  | Amortized Cost |  | Fair Value |
| Due within one year | $ | 1,414.8 |  |  | $ | 1,406.1 |  |
| Due between one and three years | 2,478.8 |  |  | 2,456.0 |  |
| Due between three and five years | 523.4 |  |  | 518.8 |  |
| Due between five and ten years | 52.5 |  |  | 52.3 |  |
| Due after ten years | 21.0 |  |  | 20.8 |  |
| Total | $ | 4,490.5 |  |  | $ | 4,454.0 |  |

[0001327567-23-000024:notes:117]
Marketable Equity Securities

[0001327567-23-000024:notes:118]
Marketable equity securities consist of money market funds and are included in cash and cash equivalents on our consolidated balance sheets. As of July 31, 2023 and 2022, the carrying value of our marketable equity securities were $476.1 million and $1.2 billion, respectively. There were no unrealized gains or losses recognized for these securities during the years ended July 31, 2023, 2022, and 2021.


## us-gaap:FinancingReceivablesTextBlock

[0001327567-23-000024:notes:119]
Financing Receivables
The following table summarizes our short-term and long-term financing receivables (in millions):

[0001327567-23-000024:notes:120]
|  | July 31, |
|  | 2023 |  | 2022 |
| Short-term financing receivables, gross | $ | 435.1 |  |  | $ | 115.0 |  |
| Unearned income | (42.9) |  |  | (2.4) |  |
| Allowance for credit losses | (3.4) |  |  | (1.3) |  |
| Short-term financing receivables, net | $ | 388.8 |  |  | $ | 111.3 |  |
| Long-term financing receivables, gross | $ | 698.6 |  |  | $ | 196.1 |  |
| Unearned income | (39.2) |  |  | (1.5) |  |
| Allowance for credit losses | (6.1) |  |  | (2.5) |  |
| Long-term financing receivables, net | $ | 653.3 |  |  | $ | 192.1 |  |

[0001327567-23-000024:notes:121]
Our financing receivables portfolio primarily consists of high-quality investment-grade receivables as of July 31, 2023 and 2022. There was no significant activity in allowance for credit losses during the years ended July 31, 2023 and 2022. Past due amounts on financing receivables were not material as of July 31, 2023 and 2022.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001327567-23-000024:notes:122]
Derivative Instruments
As of July 31, 2023 and 2022, the total notional amount of our outstanding foreign currency forward contracts was $957.5 million and $856.9 million, respectively. Refer to Note 3. Fair Value Measurements for the fair value of our derivative instruments as reported on our consolidated balance sheets as of July 31, 2023.

[0001327567-23-000024:notes:123]
As of July 31, 2023, unrealized gains and losses in AOCI related to our cash flow hedges were a $0.7 million net gain, of which $2.7 million in gains are expected to be recognized into earnings within the next 12 months. As of July 31, 2022, unrealized gains and losses in AOCI related to our cash flow hedges were a $24.8 million net loss.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001327567-23-000024:notes:124]
Acquisitions
Fiscal 2023

[0001327567-23-000024:notes:125]
Cider Security Ltd.

[0001327567-23-000024:notes:126]
On December 20, 2022, we completed our acquisition of Cider Security Ltd. (“Cider”), a privately-held cloud security company. We expect the acquisition will support Prisma Cloud’s platform approach to securing the entire application security lifecycle from code to cloud. The total purchase consideration for the acquisition of Cider was $198.3 million, which consisted of the following (in millions):

[0001327567-23-000024:notes:127]
|  | Amount |
| Cash | $ | 198.0 |  |
| Fair value of replacement awards | 0.3 |  |
| Total | $ | 198.3 |  |

[0001327567-23-000024:notes:128]
As part of the acquisition, we issued replacement equity awards, which included 0.2 million shares of our restricted common stock. The total fair value of the replacement equity awards was $48.6 million, of which the portion attributable to services performed prior to the acquisition date was allocated to purchase consideration. The remaining fair value was allocated to future services and will be expensed over the remaining service periods as share-based compensation.

[0001327567-23-000024:notes:129]
We have accounted for this transaction as a business combination and allocated the purchase consideration to assets acquired and liabilities assumed based on preliminary estimated fair values, as presented in the following table (in millions):

[0001327567-23-000024:notes:130]
|  | Amount |
| Goodwill | $ | 164.6 |  |
| Identified intangible assets | 27.8 |  |
| Cash | 12.4 |  |
| Net liabilities assumed | (6.5) |  |
| Total | $ | 198.3 |  |

[0001327567-23-000024:notes:131]
Goodwill generated from this business combination is primarily attributable to the assembled workforce and expected post-acquisition synergies from integrating Cider technology into our platforms. The goodwill is expected to be deductible for U.S. income tax purposes.

[0001327567-23-000024:notes:132]
The following table presents the identified intangible asset acquired (in millions, except years):

[0001327567-23-000024:notes:133]
|  | Fair Value |  | Estimated Useful Life |
| Developed technology | $ | 27.8 |  |  | 5 years |

[0001327567-23-000024:notes:134]
Other acquisition

[0001327567-23-000024:notes:135]
In April 2023, we completed an acquisition for total purchase consideration of $18.9 million in cash. We have accounted for this transaction as a business combination and recorded goodwill of $14.5 million. The goodwill is not deductible for income tax purposes.

[0001327567-23-000024:notes:136]
Fiscal 2022

[0001327567-23-000024:notes:137]
During the year ended July 31, 2022, we completed acquisitions for a combined total purchase consideration of $40.1 million, which was primarily cash. We have accounted for these transactions as business combinations, and recorded goodwill of $37.6 million. The goodwill is not deductible for income tax purposes.

[0001327567-23-000024:notes:138]
Fiscal 2021

[0001327567-23-000024:notes:139]
Bridgecrew Inc.

[0001327567-23-000024:notes:140]
On March 2, 2021, we completed our acquisition of Bridgecrew Inc. (“Bridgecrew”), a privately-held cloud security company. We expect the acquisition will expand our Prisma Cloud offering to deliver security across the full application lifecycle. The total purchase consideration for the acquisition of Bridgecrew was $156.9 million, which consisted of the following (in millions):

[0001327567-23-000024:notes:141]
|  | Amount |
| Cash | $ | 155.9 |  |
| Fair value of replacement awards | 1.0 |  |
| Total | $ | 156.9 |  |

[0001327567-23-000024:notes:142]
As part of the acquisition, we issued $42.5 million of replacement awards, of which the portion attributable to services performed prior to the acquisition date was allocated to purchase consideration. The remaining fair value was allocated to future services and will be expensed over the remaining service periods as share-based compensation.

[0001327567-23-000024:notes:143]
We have accounted for this transaction as a business combination and allocated the purchase consideration to assets acquired and liabilities assumed based on estimated fair values, as presented in the following table (in millions):

[0001327567-23-000024:notes:144]
|  | Amount |
| Goodwill | $ | 129.6 |  |
| Identified intangible assets | 21.6 |  |
| Cash | 9.0 |  |
| Net liabilities assumed | (3.3) |  |
| Total | $ | 156.9 |  |

[0001327567-23-000024:notes:145]
Goodwill generated from this business combination is primarily attributable to the assembled workforce and expected post-acquisition synergies from integrating Bridgecrew technology into our platforms. The goodwill is not deductible for income tax purposes.

[0001327567-23-000024:notes:146]
|  | Fair Value |  | Estimated Useful Life |
| Developed technology | $ | 21.6 |  |  | 6 years |

[0001327567-23-000024:notes:147]
Expanse Inc.

[0001327567-23-000024:notes:148]
On December 15, 2020, we completed our acquisition of Expanse Inc. (“Expanse”), a privately-held company specializing in attack surface management. We expect the acquisition will enrich our Cortex offerings and provide organizations an integrated view of the enterprise to combine external, internal, and threat data. The total purchase consideration for the acquisition of Expanse was $797.2 million, which consisted of the following (in millions):

[0001327567-23-000024:notes:149]
|  | Amount |
| Cash | $ | 434.9 |  |
| Common stock (1.1 million shares) | 340.7 |  |
| Fair value of replacement awards | 21.6 |  |
| Total | $ | 797.2 |  |

[0001327567-23-000024:notes:150]
As part of the acquisition, we issued replacement equity awards, which included 0.2 million shares of our restricted common stock. The total fair value of the replacement equity awards was $160.0 million, of which the portion attributable to services performed prior to the acquisition date was allocated to purchase consideration. The remaining fair value was allocated to future services and will be expensed over the remaining service periods as share-based compensation.

[0001327567-23-000024:notes:151]
We have accounted for this transaction as a business combination and allocated the purchase consideration to assets acquired and liabilities assumed based on estimated fair values, as presented in the following table (in millions):

[0001327567-23-000024:notes:152]
|  | Amount |
| Goodwill | $ | 598.2 |  |
| Identified intangible assets | 160.3 |  |
| Cash | 51.1 |  |
| Net liabilities assumed | (12.4) |  |
| Total | $ | 797.2 |  |

[0001327567-23-000024:notes:153]
Goodwill generated from this business combination is primarily attributable to the assembled workforce and expected post-acquisition synergies from integrating Expanse technology into our platforms. The goodwill is not deductible for income tax purposes.

[0001327567-23-000024:notes:154]
The following table presents details of the identified intangible assets acquired (in millions, except years):

[0001327567-23-000024:notes:155]
|  | Fair Value |  | Estimated Useful Life |
| Developed technology | $ | 123.4 |  |  | 6 years |
| Customer relationships | 36.9 |  |  | 10 years |
| Total | $ | 160.3 |  |  |  |

[0001327567-23-000024:notes:156]
Sinefa Group, Inc.

[0001327567-23-000024:notes:157]
On November 24, 2020, we completed our acquisition of Sinefa Group, Inc. and its wholly owned subsidiaries (“Sinefa”), a privately-held digital experience monitoring company. We expect the acquisition will extend our Prisma Access offering. The total purchase consideration for the acquisition of Sinefa was $27.0 million, which consisted of the following (in millions):

[0001327567-23-000024:notes:158]
|  | Amount |
| Cash | $ | 26.9 |  |
| Fair value of replacement awards | 0.1 |  |
| Total | $ | 27.0 |  |

[0001327567-23-000024:notes:159]
As part of the acquisition, we issued $11.5 million of replacement equity awards, of which the portion attributable to services performed prior to the acquisition date was allocated to purchase consideration. The remaining fair value was allocated to future services and will be expensed over the remaining service periods as share-based compensation.

[0001327567-23-000024:notes:160]
|  | Amount |
| Goodwill | $ | 13.7 |  |
| Identified intangible assets | 20.4 |  |
| Net liabilities assumed | (7.1) |  |
| Total | $ | 27.0 |  |

[0001327567-23-000024:notes:161]
Goodwill generated from this business combination is primarily attributable to the assembled workforce and expected post-acquisition synergies from integrating Sinefa technology into our platforms. The goodwill is deductible for income tax purposes.

[0001327567-23-000024:notes:162]
|  | Fair Value |  | Estimated Useful Life |
| Developed technology | $ | 18.6 |  |  | 6 years |
| Customer relationships | 1.8 |  |  | 8 years |
| Total | $ | 20.4 |  |  |  |

[0001327567-23-000024:notes:163]
The Crypsis Group

[0001327567-23-000024:notes:164]
On September 17, 2020, we completed our acquisition of The Crypsis Group (“Crypsis”), an incident response, risk management, and digital forensics consulting firm. We expect the acquisition will expand our capabilities and strengthen our Cortex strategy. The total purchase consideration for the acquisition of Crypsis was $227.7 million, which consisted of the following (in millions):

[0001327567-23-000024:notes:165]
|  | Amount |
| Cash | $ | 225.7 |  |
| Fair value of replacement awards | 2.0 |  |
| Total | $ | 227.7 |  |

[0001327567-23-000024:notes:166]
As part of the acquisition, we issued $27.1 million of replacement awards, of which the portion attributable to services performed prior to the acquisition date was allocated to purchase consideration. The remaining fair value was allocated to future services and will be expensed over the remaining service periods as share-based compensation.

[0001327567-23-000024:notes:167]
|  | Amount |
| Goodwill | $ | 157.6 |  |
| Identified intangible assets | 54.4 |  |
| Net assets acquired | 15.7 |  |
| Total | $ | 227.7 |  |

[0001327567-23-000024:notes:168]
Goodwill generated from this business combination is primarily attributable to the assembled workforce and expected post-acquisition synergies from integrating Crypsis technology into our platforms. The goodwill is deductible for income tax purposes.

[0001327567-23-000024:notes:169]
|  | Fair Value |  | Estimated Useful Life |
| Developed technology | $ | 6.9 |  |  | 3 years |
| Customer relationships | 47.5 |  |  | 7 years |
| Total | $ | 54.4 |  |  |  |

[0001327567-23-000024:notes:170]
Additional Acquisition-Related Information

[0001327567-23-000024:notes:171]
Pro forma results of operations have not been presented because the effects of the acquisitions were not material to our consolidated statements of operations.

[0001327567-23-000024:notes:172]
Additional information related to our acquisitions completed in fiscal 2023, such as that related to income tax and other contingencies, existing as of the acquisition date may become known during the remainder of the measurement period, not to exceed 12 months from the respective acquisition date, which may result in changes to the amounts and allocations recorded.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001327567-23-000024:notes:173]
Goodwill and Intangible Assets
Goodwill

[0001327567-23-000024:notes:174]
The following table presents details of our goodwill during the year ended July 31, 2023 (in millions):

[0001327567-23-000024:notes:175]
|  | Amount |
| Balance as of July 31, 2022 | $ | 2,747.7 |  |
| Goodwill acquired | 179.1 |  |
| Balance as of July 31, 2023 | $ | 2,926.8 |  |

[0001327567-23-000024:notes:176]
Purchased Intangible Assets

[0001327567-23-000024:notes:177]
The following table presents details of our purchased intangible assets (in millions):

[0001327567-23-000024:notes:178]
|  | July 31, |
|  | 2023 |  | 2022 |
|  | Gross Carrying Amount |  | Accumulated Amortization |  | Net Carrying Amount |  | Gross Carrying Amount |  | Accumulated Amortization |  | Net Carrying Amount |
| Intangible assets subject to amortization: |  |  |  |  |  |  |  |  |  |  |  |
| Developed technology | $ | 633.2 |  |  | $ | (429.4) |  |  | $ | 203.8 |  |  | $ | 600.7 |  |  | $ | (347.9) |  |  | $ | 252.8 |  |
| Customer relationships | 172.7 |  |  | (73.9) |  |  | 98.8 |  |  | 172.7 |  |  | (52.2) |  |  | 120.5 |  |
| Acquired intellectual property | 14.6 |  |  | (6.2) |  |  | 8.4 |  |  | 11.3 |  |  | (4.8) |  |  | 6.5 |  |
| Trade name and trademarks | 9.4 |  |  | (9.4) |  |  | — |  |  | 9.4 |  |  | (9.4) |  |  | — |  |
| Other | 0.9 |  |  | (0.4) |  |  | 0.5 |  |  | 0.9 |  |  | (0.1) |  |  | 0.8 |  |
| Total intangible assets subject to amortization | 830.8 |  |  | (519.3) |  |  | 311.5 |  |  | 795.0 |  |  | (414.4) |  |  | 380.6 |  |
| Intangible assets not subject to amortization: |  |  |  |  |  |  |  |  |  |  |  |
| In-process research and development | 3.9 |  | — |  |  | 3.9 |  |  | 3.9 |  | — |  |  | 3.9 |  |
| Total purchased intangible assets | $ | 834.7 |  |  | $ | (519.3) |  |  | $ | 315.4 |  |  | $ | 798.9 |  |  | $ | (414.4) |  |  | $ | 384.5 |  |

[0001327567-23-000024:notes:179]
We recognized amortization expense of $104.9 million, $126.9 million, and $117.8 million for the years ended July 31, 2023, 2022, and 2021, respectively.

[0001327567-23-000024:notes:180]
The following table summarizes estimated future amortization expense of our intangible assets subject to amortization as of July 31, 2023 (in millions):

[0001327567-23-000024:notes:181]
|  |  |  | Fiscal years ending July 31, |
|  | Total |  | 2024 |  | 2025 |  | 2026 |  | 2027 |  | 2028 |  | 2029 and Thereafter |
| Future amortization expense | $ | 311.5 |  |  | $ | 97.9 |  |  | $ | 84.2 |  |  | $ | 62.4 |  |  | $ | 35.3 |  |  | $ | 13.7 |  |  | $ | 18.0 |  |


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001327567-23-000024:notes:182]
Property and Equipment
The following table presents details of our property and equipment, net (in millions):

[0001327567-23-000024:notes:183]
|  | July 31, |
|  | 2023 |  | 2022 |
| Computers, equipment, and software | $ | 432.9 |  |  | $ | 404.3 |  |
| Leasehold improvements | 268.9 |  |  | 249.3 |  |
| Land | 87.2 |  |  | 87.2 |  |
| Demonstration units | 46.9 |  |  | 41.6 |  |
| Furniture and fixtures | 46.9 |  |  | 45.1 |  |
| Total property and equipment, gross | 882.8 |  |  | 827.5 |  |
| Less: accumulated depreciation | (528.3) |  |  | (469.7) |  |
| Total property and equipment, net | $ | 354.5 |  |  | $ | 357.8 |  |

[0001327567-23-000024:notes:184]
During the year ended July 31, 2022, we purchased 4.6 acres of land adjacent to our headquarters in Santa Clara, California, along with the associated buildings, for $39.5 million to accommodate future expansion of our headquarters.

[0001327567-23-000024:notes:185]
We recognized depreciation expense of $95.9 million, $92.8 million, and $94.2 million related to property and equipment during the years ended July 31, 2023, 2022, and 2021, respectively.


## us-gaap:DebtDisclosureTextBlock

[0001327567-23-000024:notes:186]
Debt
Convertible Senior Notes

[0001327567-23-000024:notes:187]
In July 2018, we issued $1.7 billion aggregate principal amount of 0.75% Convertible Senior Notes due 2023 (the “2023 Notes”) and in June 2020, we issued $2.0 billion aggregate principal amount of 0.375% Convertible Senior Notes due 2025 (the “2025 Notes,” and together with the 2023 Notes, the “Notes”). The 2023 Notes bear interest at a fixed rate of 0.75% per year, payable semi-annually in arrears on January 1 and July 1 of each year, beginning on January 1, 2019. The 2025 Notes bear interest at a fixed rate of 0.375% per year, payable semi-annually in arrears on June 1 and December 1 of each year, beginning on December 1, 2020. Each series of the convertible notes is governed by an indenture between us, as the issuer, and U.S. Bank National Association, as Trustee (individually, each an “Indenture,” and together, the “Indentures”). The Notes of each series are unsecured, unsubordinated obligations and the applicable Indenture governing each series of Notes does not contain any financial covenants or restrictions on the payments of dividends, the incurrence of indebtedness, or the issuance or repurchase of securities by us or any of our subsidiaries. The 2023 Notes were converted prior to or settled on the maturity date of July 1, 2023 in accordance with their terms. The 2025 Notes mature on June 1, 2025. We may redeem for cash all or any portion of the 2025 Notes, at our option, on or after June 5, 2023 and prior to the 31st scheduled trading day immediately preceding the maturity date if the last reported sale price of our common stock has been at least 130% of the conversion price then in effect for at least 20 trading days during any 30 consecutive trading day period ending on and including the trading day preceding the date on which we provide notice of redemption. The redemption will be at a price equal to 100% of the principal amount of the 2025 Notes and adjusted for interest. If we call any or all of the 2025 Notes for redemption, holders may convert such 2025 Notes called for redemption at any time prior to the close of business on the second scheduled trading day immediately preceding the redemption date.

[0001327567-23-000024:notes:188]
The following table presents details of our Notes (number of shares in millions):

[0001327567-23-000024:notes:189]
|  | Conversion Rate per $1,000 Principal |  | Initial Conversion Price |  | Convertible Date |  | Initial Number of Shares |
| 2023 Notes(1) | 11.2635 |  |  | $ | 88.78 |  |  | April 1, 2023 |  | 19.1 |  |
| 2025 Notes | 10.0806 |  |  | $ | 99.20 |  |  | March 1, 2025 |  | 20.1 |  |

[0001327567-23-000024:notes:190]
(1)The 2023 Notes were converted prior to or settled on the maturity date of July 1, 2023.

[0001327567-23-000024:notes:191]
Holders of the Notes may surrender their Notes for conversion at their option at any time prior to the close of business on the business day immediately preceding their respective convertible dates only under the following circumstances:

[0001327567-23-000024:notes:192]
•during any fiscal quarter commencing after the fiscal quarters ending on October 31, 2018 and October 31, 2020 for the 2023 Notes and the 2025 Notes, respectively (and only during such fiscal quarter), if the last reported sale price of our common stock for at least 20 trading days (whether or not consecutive) during a period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the applicable conversion price for the respective Notes on each applicable trading day (the “sale price condition”);

[0001327567-23-000024:notes:193]
•during the five business day period after any five consecutive trading day period (the “measurement period”) in which the trading price per $1,000 principal amount of the applicable series of Notes for each trading day of the measurement period was less than 98% of the product of the last reported sale price of our common stock and the applicable conversion rate for the respective Notes on each such trading day; or

[0001327567-23-000024:notes:194]
•upon the occurrence of specified corporate events.

[0001327567-23-000024:notes:195]
On or after the respective convertible date, holders may surrender all or any portion of their Notes for conversion at any time prior to the close of business on the second scheduled trading day immediately preceding the applicable maturity date regardless of the foregoing conditions, and such conversions will be settled upon the applicable maturity date. Upon conversion, holders of the Notes of a series will receive cash equal to the aggregate principal amount of the Notes of such series to be converted, and, at our election, cash and/or shares of our common stock for any amounts in excess of the aggregate principal amount of the Notes of such series being converted.

[0001327567-23-000024:notes:196]
The conversion price will be subject to adjustment in some events. Holders of the Notes of a series who convert their Notes of such series in connection with certain corporate events that constitute a “make-whole fundamental change” under the applicable Indenture are, under certain circumstances, entitled to an increase in the conversion rate for such series of Notes. Additionally, upon the occurrence of a corporate event that constitutes a “fundamental change” under the applicable Indenture, holders of the Notes of such series may require us to repurchase for cash all or a portion of the Notes of such series at a repurchase price equal to 100% of the principal amount of the Notes of such series plus accrued and unpaid interest to, but excluding, the fundamental change repurchase date.

[0001327567-23-000024:notes:197]
Holders of the 2023 Notes were able to early convert their 2023 Notes in fiscal 2023 up to April 1, 2023 as the sales price condition had been met. Conversion requests for the 2023 Notes received on or after April 1, 2023 were settled upon maturity of the 2023 Notes. Holders of the 2025 Notes were able to early convert their 2025 Notes in fiscal 2023 as the sales price condition was met. During the year ended July 31, 2023, we repaid in cash $1.7 billion in aggregate principal amount of the Notes and issued 11.4 million shares of common stock to the holders of the Notes for the conversion value in excess of the principal amount. These shares were fully offset by shares we received from the corresponding exercise of the associated note hedges.

[0001327567-23-000024:notes:198]
The sale price condition for the 2025 Notes was met during the fiscal quarter ended July 31, 2023, and as a result, holders may convert their 2025 Notes during the fiscal quarter ending October 31, 2023. The net carrying amount of the 2025 Notes was classified as a current liability on our consolidated balance sheet as of July 31, 2023.

[0001327567-23-000024:notes:199]
The sale price condition for the Notes was met during the fiscal quarter ended July 31, 2022, and as a result, holders could convert their Notes during the fiscal quarter ended October 31, 2022. The net carrying amount of the Notes was classified as a current liability on our consolidated balance sheet as of July 31, 2022.

[0001327567-23-000024:notes:200]
The following table sets forth the net carrying amount of our Notes (in millions):

[0001327567-23-000024:notes:201]
|  | July 31, 2023 |  | July 31, 2022 |
|  | 2023 Notes |  | 2025 Notes |  | Total |  | 2023 Notes |  | 2025 Notes |  | Total |
| Principal | $ | — |  |  | $ | 1,999.3 |  |  | $ | 1,999.3 |  |  | $ | 1,691.9 |  |  | $ | 1,999.4 |  |  | $ | 3,691.3 |  |
| Less: debt issuance costs, net of amortization | — |  |  | (7.8) |  |  | (7.8) |  |  | (2.6) |  |  | (11.9) |  |  | (14.5) |  |
| Net carrying amount | $ | — |  |  | $ | 1,991.5 |  |  | $ | 1,991.5 |  |  | $ | 1,689.3 |  |  | $ | 1,987.5 |  |  | $ | 3,676.8 |  |

[0001327567-23-000024:notes:202]
The total estimated fair value of the 2025 Notes was $5.0 billion at July 31, 2023. The total estimated fair value of the 2023 Notes and 2025 Notes were $3.2 billion and $3.5 billion at July 31, 2022, respectively. The fair value was determined based on the closing trading price per $100 of the applicable series of the Notes as of the last day of trading for the period. We consider the fair value of the Notes at July 31, 2023 and 2022 to be a Level 2 measurement. The fair value of the Notes is primarily affected by the trading price of our common stock and market interest rates.

[0001327567-23-000024:notes:203]
The following table sets forth interest expense recognized related to the Notes (dollars in millions):

[0001327567-23-000024:notes:204]
|  | Year Ended July 31, 2023 |  | Year Ended July 31, 2022 |  | Year Ended July 31, 2021 |
|  | 2023 Notes |  | 2025 Notes |  | Total |  | 2023 Notes |  | 2025 Notes |  | Total |  | 2023 Notes |  | 2025 Notes |  | Total |
| Contractual interest expense | $ | 11.6 |  |  | $ | 7.5 |  |  | $ | 19.1 |  |  | $ | 12.7 |  |  | $ | 7.5 |  |  | $ | 20.2 |  |  | $ | 12.7 |  |  | $ | 7.5 |  |  | $ | 20.2 |  |
| Amortization of debt discount(1) | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 63.5 |  |  | 74.3 |  |  | 137.8 |  |
| Amortization of debt issuance costs | 2.6 |  |  | 4.1 |  |  | 6.7 |  |  | 2.8 |  |  | 4.4 |  |  | 7.2 |  |  | 2.3 |  |  | 2.8 |  |  | 5.1 |  |
| Total interest expense recognized | $ | 14.2 |  |  | $ | 11.6 |  |  | $ | 25.8 |  |  | $ | 15.5 |  |  | $ | 11.9 |  |  | $ | 27.4 |  |  | $ | 78.5 |  |  | $ | 84.6 |  |  | $ | 163.1 |  |
| Effective interest rate of the liability component | 0.9 | % |  | 0.6 | % |  |  |  | 0.9 | % |  | 0.6 | % |  |  |  | 5.2 | % |  | 5.4 | % |  |  |

[0001327567-23-000024:notes:205]
(1)Upon adoption of the new debt guidance on August 1, 2021, the conversion option is no longer separately accounted for as debt discount. Our convertible senior notes are accounted for entirely as a liability.

[0001327567-23-000024:notes:206]
Note Hedges

[0001327567-23-000024:notes:207]
To minimize the impact of potential economic dilution upon conversion of our convertible senior notes, we entered into separate convertible note hedge transactions (the “2023 Note Hedges,” with respect to the 2023 Notes, the “2025 Note Hedges,” with respect to the 2025 Notes, and the 2023 Notes Hedges together with 2025 Note Hedges, the “Note Hedges”) with respect to our common stock concurrent with the issuance of each series of the Notes.

[0001327567-23-000024:notes:208]
The following table presents details of our Note Hedges (in millions):

[0001327567-23-000024:notes:209]
|  | Initial Number of Shares |  | Aggregate Purchase |
| 2023 Note Hedges(1) | 19.1 |  |  | $ | 332.0 |  |
| 2025 Note Hedges | 20.1 |  |  | $ | 370.8 |  |

[0001327567-23-000024:notes:210]
(1)The 2023 Note Hedges were settled as a result of the conversions of the 2023 Notes prior to or on July 1, 2023.

[0001327567-23-000024:notes:211]
The Note Hedges cover shares of our common stock at a strike price per share that corresponds to the initial applicable conversion price of the applicable series of the Notes, which are also subject to adjustment, and are exercisable upon conversion of the applicable series of the Notes. The Note Hedges will expire upon maturity of the applicable series of the Notes. The Note Hedges are separate transactions and are not part of the terms of the applicable series of the Notes. Holders of the Notes of either series will not have any rights with respect to the Note Hedges. Any shares of our common stock receivable by us under the Note Hedges are excluded from the calculation of diluted earnings per share as they are antidilutive. The aggregate amounts paid for the Note Hedges are included in additional paid-in capital on our consolidated balance sheets.

[0001327567-23-000024:notes:212]
As a result of the conversions of the 2023 Notes settled during the year ended July 31, 2023, we exercised the corresponding portion of our 2023 Note Hedges and received 11.4 million shares of our common stock during the period. As of July 31, 2023, none of our 2023 Note Hedges were outstanding.

[0001327567-23-000024:notes:213]
Warrants

[0001327567-23-000024:notes:214]
Separately, but concurrently with the issuance of each series of our convertible senior notes, we entered into transactions whereby we sold warrants (the “2023 Warrants,” with respect to the 2023 Notes, the “2025 Warrants,” with respect to the 2025 Notes, and the 2023 Warrants together with the 2025 Warrants, the “Warrants”) to acquire shares of our common stock, subject to anti-dilution adjustments. The 2023 Warrants and 2025 Warrants are exercisable over 60 scheduled trading days beginning October 2023 and September 2025, respectively.

[0001327567-23-000024:notes:215]
The following table presents details of our Warrants (in millions, except per share data):

[0001327567-23-000024:notes:216]
|  | Initial Number of Shares |  | Strike Price per Share |  | Aggregate Proceeds |
| 2023 Warrants | 19.1 |  |  | $ | 139.27 |  |  | $ | 145.4 |  |
| 2025 Warrants | 20.1 |  |  | $ | 136.16 |  |  | $ | 202.8 |  |

[0001327567-23-000024:notes:217]
The shares issuable under the Warrants are included in the calculation of diluted earnings per share when the average market value per share of our common stock for the reporting period exceeds the applicable strike price for such series of Warrants. The Warrants are separate transactions and are not part of either series of Notes or Note Hedges and are not remeasured through earnings each reporting period. Holders of the Notes of either series will not have any rights with respect to the Warrants. The aggregate proceeds received from the sale of the Warrants are included in additional paid-in capital on our consolidated balance sheets.

[0001327567-23-000024:notes:218]
Revolving Credit Facility

[0001327567-23-000024:notes:219]
On September 4, 2018, we entered into a credit agreement (the “2018 Credit Agreement”) with certain institutional lenders that provides for a $400.0 million unsecured revolving credit facility (the “2018 Credit Facility”), with an option to increase the amount of the 2018 Credit Facility by up to an additional $350.0 million, subject to certain conditions. The 2018 Credit Facility expired in April 2023.

[0001327567-23-000024:notes:220]
On April 13, 2023, we entered into a new credit agreement (the “2023 Credit Agreement”) with certain institutional lenders that provides for a $400.0 million unsecured revolving credit facility (the “2023 Credit Facility”), with an option to increase the amount by up to an additional $350.0 million, subject to certain conditions. The 2023 Credit Facility matures on April 13, 2028.

[0001327567-23-000024:notes:221]
The borrowings under the 2023 Credit Facility bear interest, at our option, at a base rate plus a spread of 0.000% to 0.375%, or an adjusted term Secured Overnight Financing Rate (“SOFR”) plus a spread of 1.000% to 1.375%, in each case with such spread being determined based on our leverage ratio. We are obligated to pay an ongoing commitment fee on undrawn amounts at a rate of 0.090% to 0.150%, depending on our leverage ratio. The interest rates and commitment fees are also subject to upward and downward adjustments based on our progress towards the achievement of certain sustainability goals related to greenhouse gas emissions.

[0001327567-23-000024:notes:222]
As of July 31, 2023, there were no amounts outstanding and we were in compliance with all covenants under the 2023 Credit Agreement.


## us-gaap:LesseeOperatingLeasesTextBlock

[0001327567-23-000024:notes:223]
Leases
We have entered into various non-cancelable operating leases primarily for our facilities with original lease periods expiring through the year ending July 31, 2033, with the most significant leases relating to our corporate headquarters in Santa Clara.

[0001327567-23-000024:notes:224]
In May 2015 and October 2015, we entered into a total of three lease agreements for approximately 941,000 square feet of corporate office space in Santa Clara, California, which serves as our current corporate headquarters. The leases contain rent holiday periods, scheduled rent increases, lease incentives, and renewal options which allow the lease terms to be extended beyond their expiration dates of July 2028 through July 2046. Rental payments under the three lease agreements are approximately $412.0 million over the lease term.

[0001327567-23-000024:notes:225]
During the years ended July 31, 2023, 2022, and 2021, our net cost for operating leases was $91.3 million, $89.7 million, and $75.2 million, respectively, primarily consisting of operating lease costs of $64.2 million, $67.6 million, and $59.3 million, respectively. Our net cost for operating leases also included variable lease costs, short-term lease costs, and sublease income in the periods presented.

[0001327567-23-000024:notes:226]
The following tables present additional information for our operating leases (in millions, except for years and percentages):

[0001327567-23-000024:notes:227]
|  | Year Ended July 31, |  |  |  |  |  |  |
|  | 2023 |  | 2022 |  | 2021 |  |  |  |  |  |  |
| Operating cash flows used in payments of operating lease liabilities | $ | 82.7 |  |  | $ | 81.5 |  |  | $ | 81.7 |  |  |  |  |  |  |  |
| Right-of-use assets obtained in exchange for new operating lease liabilities | $ | 71.1 |  |  | $ | 33.0 |  |  | $ | 48.6 |  |  |  |  |  |  |  |

[0001327567-23-000024:notes:228]
|  | July 31, 2023 |  | July 31, 2022 |  |  |  |  |  |  |
| Weighted-average remaining lease term | 5.7 years |  | 5.5 years |  |  |  |  |  |  |
| Weighted-average discount rate | 4.7 | % |  | 4.0 | % |  |  |  |  |  |  |

[0001327567-23-000024:notes:229]
The following table presents maturities of operating lease liabilities as of July 31, 2023 (in millions):

[0001327567-23-000024:notes:230]
|  | Amount |
| Fiscal years ending July 31: |  |
| 2024 | $ | 74.3 |  |
| 2025 | 73.4 |  |
| 2026 | 67.8 |  |
| 2027 | 60.5 |  |
| 2028 | 59.6 |  |
| 2029 and thereafter | 57.2 |  |
| Total operating lease payments | 392.8 |  |
| Less: imputed interest | (53.4) |  |
| Present value of operating lease liabilities | $ | 339.4 |  |
| Current portion of operating lease liabilities(1) | $ | 60.2 |  |
| Long-term operating lease liabilities | $ | 279.2 |  |

[0001327567-23-000024:notes:231]
(1)Current portion of operating lease liabilities is included in accrued and other liabilities on our consolidated balance sheet.

[0001327567-23-000024:notes:232]
As of July 31, 2023, we had additional non-cancelable operating leases for office space that had been signed but had not yet commenced with total future minimum lease payments of $72.1 million. These leases are expected to commence on or after fiscal 2024, with lease terms ranging from two to twelve years.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001327567-23-000024:notes:233]
Commitments and Contingencies 
Purchase Commitments

[0001327567-23-000024:notes:234]
Manufacturing Purchase Commitments

[0001327567-23-000024:notes:235]
In order to reduce manufacturing lead times and plan for adequate supply, we enter into agreements with manufacturing partners and component suppliers to procure inventory based on our demand forecasts. The following table presents details of the aggregate future minimum or fixed purchase commitments under these arrangements excluding obligations under contracts that we can cancel as of July 31, 2023 (in millions):

[0001327567-23-000024:notes:236]
|  |  |  | Fiscal years ending July 31, |
|  | Total |  | 2024 |  | 2025 |  | 2026 |  | 2027 |  | 2028 |  | 2029 and Thereafter |  |  |
| Manufacturing purchase commitments | $ | 157.4 |  |  | $ | 82.4 |  |  | $ | 35.0 |  |  | $ | 40.0 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  |  |

[0001327567-23-000024:notes:237]
Other Purchase Commitments

[0001327567-23-000024:notes:238]
We have entered into various non-cancelable agreements with certain service providers, under which we are committed to minimum or fixed purchases. The following table presents details of the aggregate future non-cancelable purchase commitments under these agreements as of July 31, 2023 (in millions):

[0001327567-23-000024:notes:239]
|  |  |  | Fiscal years ending July 31, |
|  | Total |  | 2024 |  | 2025 |  | 2026 |  | 2027 |  | 2028 |  | 2029 and Thereafter |  |  |
| Other purchase commitments | $ | 1,519.2 |  |  | $ | 94.0 |  |  | $ | 420.6 |  |  | $ | 519.4 |  |  | $ | 483.8 |  |  | $ | 0.6 |  |  | $ | 0.8 |  |  |  |

[0001327567-23-000024:notes:240]
Additionally, we have a $155.6 million minimum purchase commitment with a service provider through September 2027 with no specified annual commitments.

[0001327567-23-000024:notes:241]
Mutual Covenant Not to Sue and Release Agreement

[0001327567-23-000024:notes:242]
In January 2020, we executed a Mutual Covenant Not to Sue and Release Agreement for $50.0 million to extend an existing covenant not to sue for seven years. As the primary benefit of the arrangement was attributable to future use, the amount was recorded in other assets on our consolidated balance sheets and is amortized to cost of product revenue on our consolidated statements of operations over the estimated period of benefit of seven years.

[0001327567-23-000024:notes:243]
Litigation

[0001327567-23-000024:notes:244]
We are subject to legal proceedings, claims, tax matters, and litigation arising in the ordinary course of business, including, for instance, intellectual property and patent litigation. We accrue for contingencies when we believe that a loss is probable and that we can reasonably estimate the amount of any such loss. As of July 31, 2023, we have not recorded any significant accruals for loss contingencies associated with such matters.

[0001327567-23-000024:notes:245]
Legal matters could include speculative, substantial or indeterminate monetary amounts. Significant judgment is required to determine both the likelihood of there being a loss and the estimated amount of a loss related to such matters, and we may be unable to estimate the reasonably possible loss or range of loss. The outcomes of outstanding legal matters are inherently unpredictable, and could, either individually or in aggregate, have a material adverse effect on us and our results of operations. To the extent there is a reasonable possibility that a loss exceeding amounts already recognized may be incurred, we will either disclose the estimated additional loss or state that such an estimate cannot be made.

[0001327567-23-000024:notes:246]
The following matters arose in the ordinary course of business.

[0001327567-23-000024:notes:247]
Centripetal Networks, Inc. v. Palo Alto Networks

[0001327567-23-000024:notes:248]
On March 12, 2021, Centripetal Networks, Inc., filed a lawsuit against us in the United States District Court for the Eastern District of Virginia. The lawsuit alleges that our products infringe multiple Centripetal patents. We successfully challenged certain of these patents, which were found unpatentable by the U.S. Patent and Trademark Office. The complaint requests injunctive relief, monetary damages, and attorneys fees. In addition, Centripetal filed infringement contentions on certain of their patents in the European Patent Office in Germany, to which we filed invalidity challenges. Those matters are still pending. The court has set a trial date of January 22, 2024 on the remaining patents. We are unable, at this time, to reasonably estimate a possible loss or potential range of loss, if any.

[0001327567-23-000024:notes:249]
Finjan, Inc. v. Palo Alto Networks

[0001327567-23-000024:notes:250]
On November 4, 2014, Finjan, Inc., filed a lawsuit against us in the United States District Court for the Northern District of California. The lawsuit alleges that our products infringe multiple Finjan patents. The complaint requests injunctive relief, monetary damages, and attorneys fees. The court has set a trial date of April 8, 2024. We are unable, at this time, to reasonably estimate a possible loss or potential range of loss, if any.

[0001327567-23-000024:notes:251]
Taasera v. Palo Alto Networks

[0001327567-23-000024:notes:252]
On March 22, 2022, we filed a declaratory judgment action in the United States District Court for the Southern District of New York (“S.D.N.Y”) seeking a ruling that we are not infringing various Taasera patents. Taasera challenged jurisdiction in S.D.N.Y, which issue is currently on appeal with the Federal Circuit. Pursuant to an order of the Judicial Panel on Multidistrict Litigation, this matter has been consolidated in the United States District Court for the Eastern District of Texas with several other patent infringement matters brought by Taasera. The court has set April 1, 2024 as the date for the start of consecutive trials of these consolidated matters. The complaint requests injunctive relief, monetary damages, and attorneys fees. We are unable, at this time, to reasonably estimate a possible loss or potential range of loss, if any.

[0001327567-23-000024:notes:253]
Indemnification

[0001327567-23-000024:notes:254]
Under the indemnification provisions of our standard sales related contracts, we agree to defend our end-customers against third-party claims asserting infringement of certain intellectual property rights, which may include patents, copyrights, trademarks, or trade secrets, and to pay judgments entered on such claims. Our exposure under these indemnification provisions is generally limited to payments made to us for the alleged infringing products over the preceding twelve months under the agreement. However, certain agreements include indemnification provisions that could potentially expose us to losses in excess of these payments. In addition, we indemnify our officers, directors, and certain key employees while they are serving in good faith in their company capacities. To date, we have not recorded any accruals for loss contingencies associated with indemnification claims or determined that an unfavorable outcome is probable or reasonably possible.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001327567-23-000024:notes:255]
Stockholders’ Equity
Share Repurchase Program

[0001327567-23-000024:notes:256]
In February 2019, our board of directors authorized a $1.0 billion share repurchase program, which is funded from available working capital. In December 2020, August 2021, and August 2022, our board of directors authorized additional $700.0 million, $676.1 million, and $915.0 million increases to this share repurchase program, respectively, bringing the total authorization under this share repurchase program to $3.3 billion (our “current authorization”). The expiration date of our current authorization was extended to December 31, 2023, and our repurchase program may be suspended or discontinued at any time. Repurchases may be made at management’s discretion from time to time on the open market, through privately negotiated transactions, transactions structured through investment banking institutions, block purchase techniques, 10b5-1 trading plans, or a combination of the foregoing.

[0001327567-23-000024:notes:257]
The following table summarizes the share repurchase activity under our share repurchase program (in millions, except per share amounts):

[0001327567-23-000024:notes:258]
|  | Year Ended July 31, |
|  | 2023 |  | 2022 |  | 2021 |
| Number of shares repurchased | 1.8 |  |  | 5.4 |  |  | 12.0 |  |
| Weighted-average price per share (1) | $ | 138.65 |  |  | $ | 170.83 |  |  | $ | 98.29 |  |
| Aggregate purchase price (1) | $ | 250.0 |  |  | $ | 915.0 |  |  | $ | 1,178.1 |  |

[0001327567-23-000024:notes:259]
(1)Includes transaction costs

[0001327567-23-000024:notes:260]
As of July 31, 2023, $750.0 million remained available for future share repurchases under our current repurchase authorization. The total price of the shares repurchased and related transaction costs are reflected as a reduction to common stock and additional paid-in capital on our consolidated balance sheets.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001327567-23-000024:notes:261]
Equity Award Plans
Share-Based Compensation Plans

[0001327567-23-000024:notes:262]
Equity Incentive Plans

[0001327567-23-000024:notes:263]
Our 2021 Equity Incentive Plan (our “2021 Plan”) became effective in December 2021 and replaced our 2012 Equity Incentive Plan (our “2012 Plan”). Our 2021 Plan provides for the granting of stock options, stock appreciation rights, restricted stock awards (“RSAs”), restricted stock units (“RSUs”), performance shares (“PSAs”), performance-based stock units (“PSUs”) and performance stock options (“PSOs”) to our employees, directors, and consultants. Upon effectiveness of the 2021 Plan, the 2012 Plan was terminated and no further awards will be granted under the 2012 Plan. Awards that were outstanding upon such termination remained outstanding pursuant to their original terms, and any subsequent expiration, cancellation or forfeiture of awards under our 2012 Plan are returned to our 2021 Plan.

[0001327567-23-000024:notes:264]
The majority of our equity awards are RSUs, which generally vest over a period of three to four years from the date of grant. Until vested, RSUs do not have the voting and dividend participation rights of common stock and the shares underlying the awards are not considered issued and outstanding.

[0001327567-23-000024:notes:265]
Our PSUs generally vest over a period of one to four years from the date of grant. The number of PSUs eligible to vest is determined based on the level of achievement against certain performance conditions, market conditions, and a combination thereof.

[0001327567-23-000024:notes:266]
During the year ended July 31, 2023, we granted 0.9 million shares of PSUs with both service and market conditions. The market conditions are satisfied when the price of our common stock is equal to or exceeds stock price targets of $233.33, $266.67, $300.00, and $333.33 based on the average closing price for 30 consecutive trading days during the three- or four-year period following the date of grant. To the extent the market conditions have been met, one-fourth of the awards will vest on each anniversary date of the grant date, subject to continued service. During the year ended July 31, 2023, the first stock price target for these PSU awards was met, and the related shares will vest when the underlying service conditions are satisfied.

[0001327567-23-000024:notes:267]
During the year ended July 31, 2023, we granted 0.8 million shares of PSUs, which contain service and market conditions. The service conditions are satisfied after a period of five years. The market condition is measured based on our TSR relative to the TSR of the companies listed in the Standard & Poor’s 500 index.

[0001327567-23-000024:notes:268]
During the years ended July 31, 2023 and 2022, we granted 1.6 million and 0.6 million shares of PSUs, respectively, which contain service, performance and market conditions. The service conditions are satisfied after a period of one to three years. The performance conditions are based on revenue growth or billing growth. The market condition is measured based on our total shareholder return (“TSR”) relative to the TSR of the companies listed in the Standard & Poor’s 500 index. As of July 31, 2023, we have approved 2.3 million shares of PSUs, which will be granted upon the performance condition being established during the next two years.

[0001327567-23-000024:notes:269]
We have also granted PSOs with both service and market conditions. The market condition for PSOs granted in the fiscal years 2018 and 2019 requires the price of our common stock to equal or exceed $99.25, $132.33, $165.42, and $198.50 based on the average closing price for 30 consecutive trading days during the four-, five-, six-, and seven-and-a-half-year periods following the date of grant in fiscal year 2018 and 2019, respectively. The market condition for PSOs granted in the fiscal year 2021 requires the price of our common stock to equal or exceed $132.33, $165.42, $198.50 and $233.33 based on the average closing price for 30 consecutive trading days during the three-, four-, five-, and six-and-a-half-year periods following the date of grant. All of the PSOs granted in the fiscal year 2021 were forfeited in the same fiscal year and are no longer outstanding. To the extent that the market conditions are met, one-fourth of the PSOs vest on each anniversary date of the grant date for such PSOs, subject to continued service. The maximum contractual term of our outstanding PSOs is seven and a half years from the date of grant, depending on vesting period. As of July 31, 2023, all of our outstanding PSOs have been fully vested.

[0001327567-23-000024:notes:270]
We net-share settle equity awards held by certain employees by withholding shares upon vesting to satisfy tax withholding obligations. The shares withheld to satisfy employee tax withholding obligations are returned to our 2021 Plan and will be available for future issuance. Payments for employees’ tax obligations to the tax authorities are recognized as a reduction to additional paid-in capital and reflected as financing activities on our consolidated statements of cash flows.

[0001327567-23-000024:notes:271]
A total of 35.6 million shares of our common stock are reserved for issuance pursuant to our equity incentive plans as of July 31, 2023.

[0001327567-23-000024:notes:272]
2012 Employee Stock Purchase Plan

[0001327567-23-000024:notes:273]
Our 2012 Employee Stock Purchase Plan was adopted by our board of directors and approved by the stockholders on June 5, 2012, and was effective upon completion of our initial public offering (“IPO”). On August 29, 2017, we amended and restated our 2012 Employee Stock Purchase Plan (our “2012 ESPP”) to extend the length of our offering periods from 6 to 24 months.

[0001327567-23-000024:notes:274]
Our 2012 ESPP permits eligible employees to acquire shares of our common stock at 85% of the lower of the fair market value of our common stock on the first trading day of each offering period or on the purchase date. If the fair market value of our common stock on the purchase date is lower than the first trading day of the offering period, the current offering period will be cancelled after purchase and a new 24-month offering period will begin. Under our 2012 ESPP, each 24-month offering period consists of four consecutive 6-month purchase periods, with purchase dates on the first trading day on or after February 28 and August 31 of each year. Participants may purchase shares of common stock through payroll deductions of up to 15% of their eligible compensation, subject to purchase limits of 1,875 shares per six-month purchase period and $25,000 worth of stock for each calendar year. Shares purchased under our 2012 ESPP during the fiscal years ended July 31, 2023, 2022 and 2021 were 1.2 million, 2.1 million and 1.9 million, at an average exercise price of $138.30 per share, $64.27 per share, and $53.69 per share, respectively.

[0001327567-23-000024:notes:275]
A total of 16.4 million shares of our common stock are available for sale under our 2012 ESPP as of July 31, 2023. On the first day of each fiscal year, the number of shares in the reserve may be increased by the lesser of (i) 6,000,000 shares, (ii) 1% of the outstanding shares of our common stock on the first day of the fiscal year, or (iii) such other amount as determined by our board of directors.

[0001327567-23-000024:notes:276]
Assumed Share-Based Compensation Plans

[0001327567-23-000024:notes:277]
In connection with our acquisitions, we have assumed equity incentive plans of certain acquired companies (collectively “the Assumed Plans”). The equity awards assumed in connection with each acquisition were granted from their respective assumed plans. The assumed equity awards will be settled in shares of our common stock and will retain the terms and conditions under which they were originally granted. No additional equity awards will be granted under and forfeited awards will not be returned to the Assumed Plans. Refer to Note 7. Acquisitions for more information on our acquisitions and the related equity awards assumed.

[0001327567-23-000024:notes:278]
Stock Option Activities

[0001327567-23-000024:notes:279]
The following table summarizes the stock option and PSO activity under our stock plans during the years ended July 31, 2023, 2022, and 2021 (in millions, except per share amounts):

[0001327567-23-000024:notes:280]
|  | Stock Options Outstanding |  | PSOs Outstanding |
|  | Number of Shares |  | Weighted-Average Exercise Price Per Share |  | Weighted-Average Remaining Contractual Term(Years) |  | Aggregate Intrinsic Value |  | Number of Shares |  | Weighted-Average Exercise Price Per Share |  | Weighted-Average Remaining Contractual Term(Years) |  | Aggregate Intrinsic Value |
| Balance—July 31, 2020 | 0.4 |  |  | $ | 6.53 |  |  | 1.5 |  | $ | 34.2 |  |  | 8.3 |  |  | $ | 64.71 |  |  | 5.2 |  | $ | 170.9 |  |
| Granted | — |  |  | $ | — |  |  |  |  |  |  | 0.5 |  |  | $ | 101.43 |  |  |  |  |  |
| Exercised | (0.2) |  |  | $ | 4.27 |  |  |  |  |  |  | — |  |  | $ | — |  |  |  |  |  |
| Forfeited | 0.0 |  |  | $ | 2.61 |  |  |  |  |  |  | (0.5) |  |  | $ | 101.43 |  |  |  |  |  |
| Balance—July 31, 2021 | 0.2 |  |  | $ | 8.74 |  |  | 0.8 |  | $ | 27.4 |  |  | 8.3 |  |  | $ | 64.71 |  |  | 4.2 |  | $ | 566.8 |  |
| Exercised | (0.2) |  |  | $ | 6.24 |  |  |  |  |  |  | — |  |  | $ | — |  |  |  |  |  |
| Forfeited | — |  |  | $ | — |  |  |  |  |  |  | (0.3) |  |  | $ | 61.41 |  |  |  |  |  |
| Balance—July 31, 2022 | 0.0 |  |  | $ | 18.45 |  |  | 0.5 |  | $ | 6.7 |  |  | 8.0 |  |  | $ | 64.85 |  |  | 3.2 |  | $ | 809.3 |  |
| Exercised | 0.0 |  |  | $ | 18.45 |  |  |  |  |  |  | (1.6) |  |  | $ | 63.39 |  |  |  |  |  |
| Balance—July 31, 2023 | — |  |  | $ | — |  |  | 0.0 |  | $ | — |  |  | 6.4 |  |  | $ | 65.20 |  |  | 2.2 |  | $ | 1,184.6 |  |
| Exercisable—July 31, 2023 | — |  |  | $ | — |  |  | 0.0 |  | $ | — |  |  | 6.4 |  |  | $ | 65.20 |  |  | 2.2 |  | $ | 1,184.6 |  |

[0001327567-23-000024:notes:281]
The intrinsic value of options exercised during the years ended July 31, 2023, 2022, and 2021 was $237.7 million, $29.2 million, and $22.2 million, respectively.

[0001327567-23-000024:notes:282]
RSU and PSU Activities

[0001327567-23-000024:notes:283]
The following table summarizes the RSU and PSU activity under our stock plans during the years ended July 31, 2023, 2022, and 2021 (in millions, except per share amounts):

[0001327567-23-000024:notes:284]
|  | RSUs Outstanding |  | PSUs Outstanding |
|  | Number of Shares |  | Weighted-Average Grant-Date Fair Value Per Share |  |  |  | Aggregate Intrinsic Value |  | Number of Shares |  | Weighted-Average Grant-Date Fair Value Per Share |  |  |  | Aggregate Intrinsic Value |
| Balance—July 31, 2020 | 19.8 |  |  | $ | 67.75 |  |  |  |  | $ | 1,688.1 |  |  | 1.7 |  |  | $ | 77.14 |  |  |  |  | $ | 147.2 |  |
| Granted(1)(2) | 12.3 |  |  | $ | 99.30 |  |  |  |  |  |  | 2.5 |  |  | $ | 107.15 |  |  |  |  |  |
| Vested(3) | (8.8) |  |  | $ | 66.97 |  |  |  |  |  |  | (0.2) |  |  | $ | 65.20 |  |  |  |  |  |
| Forfeited | (2.6) |  |  | $ | 75.60 |  |  |  |  |  |  | (0.2) |  |  | $ | 78.65 |  |  |  |  |  |
| Balance—July 31, 2021 | 20.7 |  |  | $ | 85.85 |  |  |  |  | $ | 2,760.2 |  |  | 3.8 |  |  | $ | 97.64 |  |  |  |  | $ | 498.4 |  |
| Granted(1) | 5.9 |  |  | $ | 164.85 |  |  |  |  |  |  | 0.8 |  |  | $ | 117.05 |  |  |  |  |  |
| Vested(3) | (9.0) |  |  | $ | 85.69 |  |  |  |  |  |  | (1.1) |  |  | $ | 83.47 |  |  |  |  |  |
| Forfeited | (2.8) |  |  | $ | 95.50 |  |  |  |  |  |  | (0.4) |  |  | $ | 107.31 |  |  |  |  |  |
| Balance—July 31, 2022 | 14.8 |  |  | $ | 115.51 |  |  |  |  | $ | 2,456.9 |  |  | 3.1 |  |  | $ | 106.38 |  |  |  |  | $ | 513.7 |  |
| Granted(1) | 5.8 |  |  | $ | 169.04 |  |  |  |  |  |  | 3.6 |  |  | $ | 142.88 |  |  |  |  |  |
| Vested(3) | (7.0) |  |  | $ | 110.93 |  |  |  |  |  |  | (1.3) |  |  | $ | 112.72 |  |  |  |  |  |
| Forfeited | (1.5) |  |  | $ | 128.05 |  |  |  |  |  |  | (0.4) |  |  | $ | 136.95 |  |  |  |  |  |
| Balance—July 31, 2023 | 12.1 |  |  | $ | 142.61 |  |  |  |  | $ | 3,013.0 |  |  | 5.0 |  |  | $ | 128.64 |  |  |  |  | $ | 1,242.3 |  |

[0001327567-23-000024:notes:285]
(1)For PSUs, shares granted represent the aggregate maximum number of shares that may be earned and issued with respect to these awards over their full terms.

[0001327567-23-000024:notes:286]
(2)Includes 1.2 million RSUs assumed in connection with the acquisitions of Crypsis, Sinefa, Expanse and Bridgecrew, with weighted-average grant-date fair values of $80.48, $99.06, $105.82 and $118.22, respectively, for the year ended July 31, 2021.

[0001327567-23-000024:notes:287]
(3)Includes time-based vesting for PSUs.

[0001327567-23-000024:notes:288]
The aggregate fair value, as of the respective vesting dates, of RSUs vested during the years ended July 31, 2023, 2022, and 2021 was $1.3 billion, $1.6 billion, and $986.4 million, respectively. The aggregate fair value, as of the respective vesting dates, of PSUs vested during the years ended July 31, 2023, 2022, and 2021 was $218.9 million, $184.0 million, and $20.8 million, respectively.

[0001327567-23-000024:notes:289]
Shares Available for Grant

[0001327567-23-000024:notes:290]
The following table presents the stock activity and the total number of shares available for grant under our equity incentive plans as of July 31, 2023 (in millions):

[0001327567-23-000024:notes:291]
|  | Number of shares |
| Balance—July 31, 2022 | 13.9 |  |
| Authorized | 6.0 |  |
| RSUs and PSUs granted | (9.4) |  |
| RSUs and PSUs forfeited | 1.8 |  |
| Shares withheld for taxes | 0.1 |  |
| Balance—July 31, 2023 | 12.4 |  |

[0001327567-23-000024:notes:292]
We record share-based compensation awards based on estimated fair value as of the grant date. The fair value of RSUs and PSUs not subject to market conditions is based on the closing market price of our common stock on the date of grant.

[0001327567-23-000024:notes:293]
The fair value of the PSUs subject to market conditions is estimated on the grant date using a Monte Carlo simulation model. No such PSUs were granted during the year ended July 31, 2021. The following table summarizes the assumptions used and the resulting grant-date fair value of our PSUs subject to market conditions granted during the years ended July 31, 2023 and 2022:

[0001327567-23-000024:notes:294]
|  | Year Ended July 31, |
|  | 2023 |  | 2022 |
| Volatility | 38.3% - 44.8% |  | 36.0% - 41.1% |
| Expected term (in years) | 1.0 - 5.0 |  | 1.4 - 3.0 |
| Dividend yield | — | % |  | — | % |
| Risk-free interest rate | 3.2% - 4.1% |  | 0.2% - 2.0% |
| Grant-date fair value per share | $91.77 - $280.41 |  | $137.16 - $260.71 |

[0001327567-23-000024:notes:295]
The expected volatility is based on the historical volatility of our common stock. The expected term is based on the length of each tranche’s performance period from the grant date. The dividend yield assumption is based on our current expectations about our anticipated dividend policy. The risk-free interest rate is based on the implied yield available on U.S. Treasury zero-coupon issues with maturities that approximate the expected term.

[0001327567-23-000024:notes:296]
The fair value of PSOs is estimated on the grant date using a Monte Carlo simulation model, which predicts settlement of the PSOs midway between the vesting term and the contractual term. No PSOs were granted during the years ended July 31, 2023 and 2022. The following table summarizes the assumptions used and the resulting grant-date fair values of our PSOs granted during the year ended July 31, 2021:

[0001327567-23-000024:notes:297]
|  | Year Ended July 31, 2021 |  |  |
| Volatility | 35.9 | % |  |  |
| Dividend yield | — | % |  |  |
| Risk-free interest rate | 0.6 | % |  |  |
| Weighted-average grant-date fair value per share | $27.37 |  |  |  |

[0001327567-23-000024:notes:298]
The expected volatility is based on a combination of implied volatility from traded options on our common stock and the historical volatility of our common stock. The dividend yield assumption is based on our current expectations about our anticipated dividend policy. The risk-free interest rate is based on the implied yield available on U.S. Treasury zero-coupon issues with terms equal to the contractual terms of each tranche.

[0001327567-23-000024:notes:299]
The fair value of shares issued under our 2012 ESPP are estimated on the grant date using the Black-Scholes option pricing model. The following table summarizes the assumptions used and the resulting grant-date fair values of our ESPP:

[0001327567-23-000024:notes:300]
|  | Year Ended July 31, |
|  | 2023 |  | 2022 |  | 2021 |
| Volatility | 38.6% - 44.7% |  | 33.6% - 39.4% |  | 34.9% - 42.6% |
| Expected term (in years) | 0.5 - 2.0 |  | 0.5 - 2.0 |  | 0.5 - 2.0 |
| Dividend yield | — | % |  | — | % |  | — | % |
| Risk-free interest rate | 3.3% - 5.2% |  | 0.1% - 1.4% |  | 0.1% |
| Grant-date fair value per share | $48.78 - $74.06 |  | $37.59 - $74.10 |  | $23.16 - $43.02 |

[0001327567-23-000024:notes:301]
The expected volatility is based on a combination of implied volatility from traded options on our common stock and the historical volatility of our common stock. The expected term represents the term from the first day of the offering period to the purchase dates within each offering period. The dividend yield assumption is based on our current expectations about our anticipated dividend policy. The risk-free interest rate is based on the implied yield available on U.S. Treasury zero-coupon issues with maturities that approximate the expected term.

[0001327567-23-000024:notes:302]
The following table summarizes share-based compensation included in costs and expenses (in millions):

[0001327567-23-000024:notes:303]
|  | Year Ended July 31, |
|  | 2023 |  | 2022 |  | 2021 |
| Cost of product revenue | $ | 9.8 |  |  | $ | 9.3 |  |  | $ | 6.2 |  |
| Cost of subscription and support revenue | 123.4 |  |  | 110.2 |  |  | 93.0 |  |
| Research and development | 488.4 |  |  | 471.1 |  |  | 428.9 |  |
| Sales and marketing | 335.3 |  |  | 304.7 |  |  | 269.9 |  |
| General and administrative | 130.4 |  |  | 118.1 |  |  | 128.9 |  |
| Total share-based compensation | $ | 1,087.3 |  |  | $ | 1,013.4 |  |  | $ | 926.9 |  |

[0001327567-23-000024:notes:304]
As of July 31, 2023, total compensation cost related to unvested share-based awards not yet recognized was $2.0 billion. This cost is expected to be amortized over a weighted-average period of approximately 2.6 years. Future grants will increase the amount of compensation expense to be recorded in these periods.


## us-gaap:ScheduleOfShareBasedPaymentAwardStockOptionsValuationAssumptionsTableTextBlock

[0001327567-23-000024:notes:305]
The following table summarizes the assumptions used and the resulting grant-date fair value of our PSUs subject to market conditions granted during the years ended July 31, 2023 and 2022:

[0001327567-23-000024:notes:306]
The following table summarizes the assumptions used and the resulting grant-date fair values of our PSOs granted during the year ended July 31, 2021:


## us-gaap:IncomeTaxDisclosureTextBlock

[0001327567-23-000024:notes:307]
Income Taxes 
The following table presents the components of income (loss) before income taxes (in millions):

[0001327567-23-000024:notes:308]
|  | Year Ended July 31, |
|  | 2023 |  | 2022 |  | 2021 |
| United States | $ | 374.3 |  |  | $ | (152.3) |  |  | $ | (482.2) |  |
| Foreign | 192.0 |  |  | (54.9) |  |  | 17.2 |  |
| Total | $ | 566.3 |  |  | $ | (207.2) |  |  | $ | (465.0) |  |

[0001327567-23-000024:notes:309]
The following table summarizes our provision for income taxes (in millions):

[0001327567-23-000024:notes:310]
|  | Year Ended July 31, |
|  | 2023 |  | 2022 |  | 2021 |
| Federal: |  |  |  |  |  |
| Current | $ | 26.1 |  |  | $ | 2.6 |  |  | $ | 3.3 |  |
| Deferred | 19.3 |  |  | (0.3) |  |  | (5.9) |  |
| State: |  |  |  |  |  |
| Current | 44.0 |  |  | 1.5 |  |  | 1.7 |  |
| Deferred | 0.4 |  |  | 0.1 |  |  | 0.1 |  |
| Foreign: |  |  |  |  |  |
| Current | 44.0 |  |  | 58.8 |  |  | 41.3 |  |
| Deferred | (7.2) |  |  | (2.9) |  |  | (6.6) |  |
| Total | $ | 126.6 |  |  | $ | 59.8 |  |  | $ | 33.9 |  |

[0001327567-23-000024:notes:311]
For the year ended July 31, 2023, our provision for income taxes increased compared to the year ended July 31, 2022, primarily due to our profitability in fiscal 2023 and an increase in U.S. taxes driven by capitalization of research and development expenditure with no offsetting deferred benefit due to our valuation allowance.

[0001327567-23-000024:notes:312]
For the year ended July 31, 2022, our provision for income taxes increased compared to the year ended July 31, 2021, primarily due to foreign income and withholding taxes.

[0001327567-23-000024:notes:313]
The following table presents the items accounting for the difference between income taxes computed at the federal statutory income tax rate and our provision for income taxes:

[0001327567-23-000024:notes:314]
|  | Year Ended July 31, |
|  | 2023 |  | 2022 |  | 2021 |
| Federal statutory rate | 21.0 | % |  | 21.0 | % |  | 21.0 | % |
| Effect of: |  |  |  |  |  |
| State taxes, net of federal tax benefit | 2.8 |  |  | 2.7 |  |  | 1.3 |  |
| Effects of non-U.S. operations | 9.7 |  |  | (16.5) |  |  | (3.1) |  |
| Change in valuation allowance | 15.5 |  |  | (158.7) |  |  | (40.7) |  |
| Share-based compensation | (12.6) |  |  | 83.6 |  |  | 5.0 |  |
| Tax credits | (15.6) |  |  | 41.5 |  |  | 9.9 |  |
| Non-deductible expenses | 2.3 |  |  | (2.5) |  |  | (1.3) |  |
| Other, net | (0.7) |  |  | — |  |  | 0.6 |  |
| Total | 22.4 | % |  | (28.9) | % |  | (7.3) | % |

[0001327567-23-000024:notes:315]
The following table presents the components of our deferred tax assets and liabilities as of July 31, 2023 and 2022 (in millions):

[0001327567-23-000024:notes:316]
|  | July 31, |
|  | 2023 |  | 2022 |
| Deferred tax assets: |  |  |  |
| Accruals and reserves | $ | 88.5 |  |  | $ | 141.1 |  |
| Operating lease liabilities | 94.1 |  |  | 86.0 |  |
| Deferred revenue | 708.1 |  |  | 475.5 |  |
| Net operating loss carryforwards | 551.0 |  |  | 759.1 |  |
| Tax credits | 338.9 |  |  | 317.4 |  |
| Capitalized research expenditures | 354.8 |  |  | — |  |
| Share-based compensation | 66.0 |  |  | 59.2 |  |
| Fixed assets and intangible assets | 1,698.3 |  |  | 1,803.6 |  |
| Interest carryforward | — |  |  | 55.8 |  |
| Gross deferred tax assets | 3,899.7 |  |  | 3,697.7 |  |
| Valuation allowance | (3,586.7) |  |  | (3,414.1) |  |
| Total deferred tax assets | 313.0 |  |  | 283.6 |  |
| Deferred tax liabilities: |  |  |  |
| Operating lease right-of-use assets | (73.5) |  |  | (61.0) |  |
| Deferred contract costs | (186.7) |  |  | (183.6) |  |
| Other deferred tax liabilities | (58.2) |  |  | (27.8) |  |
| Total deferred tax liabilities | (318.4) |  |  | (272.4) |  |
| Net deferred tax assets (liabilities) | $ | (5.4) |  |  | $ | 11.2 |  |

[0001327567-23-000024:notes:317]
A valuation allowance is provided when it is more likely than not that the deferred tax asset will not be realized. We regularly evaluate the need for a valuation allowance. We evaluate and weigh all available positive and negative evidence such as historic results, future reversals of existing deferred tax liabilities, projected future taxable income, as well as prudent and feasible tax-planning strategies. The assessment requires significant judgment and is performed in each of the applicable jurisdictions. Due to recent profitability, a reversal of our valuation allowance in certain jurisdictions in the foreseeable future is reasonably possible. As of July 31, 2023, we have provided a valuation allowance for our federal, state, United Kingdom, and certain other foreign deferred tax assets that we believe will, more likely than not, be unrealizable. The net valuation allowance increased by $172.6 million from the year ended July 31, 2022 to the year ended July 31, 2023, primarily due to capitalization of research and development expenditures and deferred revenue, partially offset by net operating losses and intangible assets.

[0001327567-23-000024:notes:318]
As of July 31, 2023, we had federal, state, and foreign net operating loss carryforwards of approximately $66.2 million, $447.8 million, and $2.0 billion, respectively, as reported on our tax returns, available to reduce future taxable income, if any. If not utilized, our federal and state net operating loss carryforwards will expire in various amounts at various dates beginning in the years ending July 31, 2034 and July 31, 2026, respectively. Our foreign net operating loss will carry forward indefinitely.

[0001327567-23-000024:notes:319]
As of July 31, 2023, we had federal and state research and development tax credit carryforwards of approximately $323.9 million and $249.3 million, respectively, as reported on our tax returns. If not utilized, the federal credit carryforwards will expire in various amounts at various dates beginning in the year ending July 31, 2028. The state credit carryforwards have no expiration.

[0001327567-23-000024:notes:320]
As of July 31, 2023, we had foreign tax credit carryforwards of $10.6 million as reported on our tax returns. If not utilized, the foreign tax credit carryforwards will expire in various amounts at various dates beginning in the year ending July 31, 2024.

[0001327567-23-000024:notes:321]
Utilization of the net operating loss carryforwards and credits may be subject to a substantial annual limitation due to the ownership change limitations provided by the Internal Revenue Code of 1986, as amended, and similar state provisions. The annual limitation may result in the expiration of net operating losses and credits before utilization.

[0001327567-23-000024:notes:322]
As of July 31, 2023, we had $360.0 million of unrecognized tax benefits, $70.4 million of which would affect income tax expense if recognized, after consideration of our valuation allowance in the United States and other assets. As of July 31, 2022, we had $414.0 million of unrecognized tax benefits, $76.1 million of which would affect income tax expense if recognized, after consideration of our valuation allowance in the United States and other assets. We do not expect the amount of unrecognized tax benefits as of July 31, 2023 to materially change over the next 12 months.

[0001327567-23-000024:notes:323]
We file federal, state, and foreign income tax returns in jurisdictions with varying statutes of limitations. Generally, all years remain subject to adjustment due to our net operating loss and credit carryforwards. We currently have ongoing tax audits in various jurisdictions and at various times. The primary focus of these audits is, generally, profit allocation. The ultimate amount and timing of any future settlements cannot be predicted with reasonable certainty.

[0001327567-23-000024:notes:324]
We recognize both interest and penalties associated with uncertain tax positions as a component of income tax expense. During the year ended July 31, 2023, we recognized a net income tax benefit related to interest and penalties of $4.8 million. During the years ended July 31, 2022 and 2021, we recognized income tax expense related to interest and penalties of $5.2 million and $3.5 million, respectively. We had accrued interest and penalties on our consolidated balance sheets related to unrecognized tax benefits of $5.1 million and $20.9 million as of July 31, 2023 and 2022, respectively.

[0001327567-23-000024:notes:325]
The following table presents a reconciliation of the beginning and ending amount of our gross unrecognized tax benefits (in millions):

[0001327567-23-000024:notes:326]
|  | Year Ended July 31, |
|  | 2023 |  | 2022 |  | 2021 |
| Unrecognized tax benefits at the beginning of the period | $ | 414.0 |  |  | $ | 372.9 |  |  | $ | 326.4 |  |
| Additions for tax positions taken in prior years | 7.8 |  |  | 3.5 |  |  | 26.5 |  |
| Reductions for tax positions taken in prior years | (99.8) |  |  | (7.4) |  |  | (2.5) |  |
| Additions for tax positions taken in the current year | 66.9 |  |  | 45.0 |  |  | 22.5 |  |
| Reduction relating to audit settlement | (28.9) |  |  | — |  |  | — |  |
| Unrecognized tax benefits at the end of the period | $ | 360.0 |  |  | $ | 414.0 |  |  | $ | 372.9 |  |

[0001327567-23-000024:notes:327]
During the year ended July 31, 2023, our reductions in uncertain tax positions primarily related to settlements with non-U.S. tax authorities and remeasurement of certain unrecognized tax benefits. As a result of our settlement agreements with non-U.S. tax authorities, we paid a total of $39.8 million, including interest and penalties.

[0001327567-23-000024:notes:328]
Our additions for tax positions taken in the years ended July 31, 2023, 2022 and 2021 were primarily attributable to uncertain tax positions related to tax credits.
As of July 31, 2023, we had no unremitted earnings when evaluating our outside basis difference relating to our U.S. investment in foreign subsidiaries. However, there could be local withholding taxes due to various foreign countries if certain lower tier earnings are distributed. Withholding taxes that would be payable upon remittance of these lower tier earnings are not material.


## us-gaap:EarningsPerShareTextBlock

[0001327567-23-000024:notes:329]
Net Income (Loss) Per Share 
Basic net income (loss) per share is computed by dividing net income (loss) by basic weighted-average shares outstanding during the period. Diluted net income (loss) per share is computed by dividing net income (loss) by diluted weighted-average shares outstanding during the period giving effect to all potentially dilutive securities to the extent they are dilutive. Potentially dilutive securities include shares issuable upon conversion of our convertible senior notes using the if-converted method, warrants related to the issuance of convertible senior notes, and equity awards under our employee equity incentive plans using the treasury stock method.

[0001327567-23-000024:notes:330]
The following table presents the computation of basic and diluted net income (loss) per share of common stock (in millions, except per share data):

[0001327567-23-000024:notes:331]
|  | Year Ended July 31, |
|  | 2023 |  | 2022 |  | 2021 |
| Net income (loss) | $ | 439.7 |  |  | $ | (267.0) |  |  | $ | (498.9) |  |
| Weighted-average shares used to compute net income (loss) per share, basic | 303.2 |  |  | 295.6 |  |  | 289.1 |
| Weighted-average effect of potentially dilutive securities: |  |  |  |  |  |
| Convertible senior notes | 17.9 |  |  | — |  |  | — |  |
| Warrants related to the issuance of convertible senior notes | 9.3 |  |  | — |  |  | — |  |
| Employee equity incentive plans | 11.9 |  |  | — |  |  | — |  |
| Weighted-average shares used to compute net income (loss) per share, diluted | 342.3 |  |  | 295.6 |  |  | 289.1 |
| Net income (loss) per share, basic | $ | 1.45 |  |  | $ | (0.90) |  |  | $ | (1.73) |  |
| Net income (loss) per share, diluted | $ | 1.28 |  |  | $ | (0.90) |  |  | $ | (1.73) |  |

[0001327567-23-000024:notes:332]
The following securities were excluded from the computation of diluted net income (loss) per share of common stock for the periods presented as their effect would have been antidilutive (in millions):

[0001327567-23-000024:notes:333]
|  | Year Ended July 31, |
|  | 2023 |  | 2022 |  | 2021 |
| Convertible senior notes | — |  |  | 39.2 |  |  | 39.2 |  |
| Warrants related to the issuance of convertible senior notes | — |  |  | 39.2 |  |  | 39.2 |  |
| Employee equity incentive plans | 3.9 |  |  | 26.8 |  |  | 34.9 |  |
| Total | 3.9 |  |  | 105.2 |  |  | 113.3 |  |


## us-gaap:OtherNonoperatingIncomeAndExpenseTextBlock

[0001327567-23-000024:notes:334]
Other Income, Net
The following table sets forth the components of other income, net (in millions):

[0001327567-23-000024:notes:335]
|  | Year Ended July 31, |
|  | 2023 |  | 2022 |  | 2021 |
| Interest income | $ | 224.4 |  |  | $ | 15.6 |  |  | $ | 8.5 |  |
| Foreign currency exchange gains (losses), net | (7.9) |  |  | 1.8 |  |  | (5.4) |  |
| Other, net | (10.3) |  |  | (8.4) |  |  | (0.7) |  |
| Total other income, net | $ | 206.2 |  |  | $ | 9.0 |  |  | $ | 2.4 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001327567-23-000024:notes:336]
Segment Information
We conduct business globally and sales are primarily managed on a geographic theater basis. Our chief operating decision maker reviews financial information presented on a consolidated basis accompanied by information about revenue by geographic region for purposes of allocating resources and evaluating financial performance. We have one business activity and there are no segment managers who are held accountable for operations, operating results, and plans for levels, components, or types of products or services below the consolidated unit level. Accordingly, we are considered to be in a single reportable segment and operating unit structure.

[0001327567-23-000024:notes:337]
The following table presents our long-lived assets, which consist of property and equipment, net and operating lease right-of-use assets, by geographic region (in millions):

[0001327567-23-000024:notes:338]
|  | Year Ended July 31, |
|  | 2023 |  | 2022 |
| Long-lived assets: |  |  |  |
| United States | $ | 400.4 |  |  | $ | 446.1 |  |
| Israel | 76.8 |  |  | 55.4 |  |
| Other countries | 140.6 |  |  | 98.3 |  |
| Total long-lived assets | $ | 617.8 |  |  | $ | 599.8 |  |

[0001327567-23-000024:notes:339]
Refer to Note 2. Revenue for revenue by geographic theater and revenue for groups of similar products and services for the years ended July 31, 2023, 2022, and 2021.


## ecd:MtrlTermsOfTrdArrTextBlock

[0001327567-23-000024:notes:340]
Set forth below is certain information regarding Rule 10b5-1 trading plans adopted by our directors and officers (as defined in Rule 16a-1(f)) during the fourth quarter of fiscal 2023. The Rule 10b5-1 trading plans listed below are each intended to satisfy the affirmative defense of Rule 10b5-1(c).

[0001327567-23-000024:notes:341]
| Name |  | Title |  | Date Plan Was Adopted |  | Expiration Date |  | Total Amount of Common Stock to be Sold Under the Plan |
| Nikesh Arora |  | Chairman and Chief Executive Officer |  | June 8, 2023 |  | August 30, 2024 or when all shares have been sold |  | 2,000,000 |  |
| William “BJ” Jenkins, Jr. |  | President |  | May 26, 2023 |  | June 29, 2024 or when all shares have been sold |  | 13,000 |  |
