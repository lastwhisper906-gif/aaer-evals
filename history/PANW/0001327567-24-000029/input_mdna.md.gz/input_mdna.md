# PANW MD&A — 0001327567-24-000029


## mdna

[0001327567-24-000029:mdna:1]
Item 7. Management’s Discussion and Analysis of Financial Condition and Results of Operations

[0001327567-24-000029:mdna:2]
The following discussion and analysis of our financial condition and results of operations should be read in conjunction with our consolidated financial statements and related notes appearing elsewhere in this Annual Report on Form 10-K. The following discussion and analysis contains forward-looking statements based on current expectations and assumptions that are subject to risks and uncertainties, which could cause our actual results to differ materially from those anticipated or implied by any forward-looking statements. Factors that could cause or contribute to such differences include, but are not limited to, those discussed in this Annual Report on Form 10-K, and in particular, the risks discussed under the caption “Risk Factors” in Part I, Item 1A of this report.

[0001327567-24-000029:mdna:3]
Our Management’s Discussion and Analysis of Financial Condition and Results of Operations (“MD&A”) is organized as follows:

[0001327567-24-000029:mdna:4]
•Overview. A discussion of our business and overall analysis of financial and other highlights in order to provide context for the remainder of MD&A.

[0001327567-24-000029:mdna:5]
•Key Financial Metrics. A summary of our U.S. GAAP and non-GAAP key financial metrics, which management monitors to evaluate our performance.

[0001327567-24-000029:mdna:6]
•Results of Operations. A discussion of the nature and trends in our financial results and an analysis of our financial results comparing fiscal 2024 to fiscal 2023. For discussion and analysis related to our financial results comparing fiscal 2023 to 2022, refer to Part II, Item 7. Management’s Discussion and Analysis of Financial Condition and Results of Operations in our Annual Report on Form 10-K for fiscal 2023, which was filed with the Securities and Exchange Commission on September 1, 2023.

[0001327567-24-000029:mdna:7]
•Liquidity and Capital Resources. An analysis of changes on our balance sheets and cash flows, and a discussion of our financial condition and our ability to meet cash needs.

[0001327567-24-000029:mdna:8]
•Critical Accounting Estimates. A discussion of our accounting policies that require critical estimates, assumptions, and judgments.

[0001327567-24-000029:mdna:9]
•Recent Accounting Pronouncements. A discussion of expected impacts of impending accounting changes on financial information to be reported in the future.

[0001327567-24-000029:mdna:10]
Overview

[0001327567-24-000029:mdna:11]
We empower enterprises, organizations, service providers, and government entities to protect themselves against today’s most sophisticated cyber threats. Our cybersecurity platforms and services help secure enterprise users, networks, clouds, and endpoints by delivering comprehensive cybersecurity backed by AI and automation. A key element of our strategy is to help our customers simplify their security architectures through consolidating disparate point products. We execute on this strategy by developing our capabilities and packaging our offerings into platforms which are able to cover many of our customers’ needs in the markets in which we operate. Our platformization strategy combines various products and services into a tightly integrated architecture and makes security faster, less complex, and more cost-effective. We focus on delivering value in four sectors of the cybersecurity industry:

[0001327567-24-000029:mdna:12]
Network Security:

[0001327567-24-000029:mdna:13]
•Our network security platform, designed to deliver complete zero trust solutions to our customers, includes our hardware and software ML-Powered Next-Generation Firewalls, AI Runtime Security, as well as a cloud-delivered SASE. Prisma® Access, our SSE solution, when combined with Prisma SD-WAN, provides a comprehensive single-vendor SASE offering that is used to secure remote workforces and securely enable the cloud-delivered branch. Our network security platform also includes our cloud-delivered security services, such as Advanced Threat Prevention, Advanced WildFire®, Advanced URL Filtering, Advanced DNS Security, IoT/OT Security, GlobalProtect®, Enterprise DLP, AIOps, SaaS Security, and AI Access Security. Through these add-on security services, our customers are able to secure their content, applications, users, and devices across their entire organization. Strata Cloud Manager, our network security management solution, can centrally manage our network security platform irrespective of form factor, location, or scale. Strata Cloud Manager includes the Strata Copilot which provides a natural language interface to simplify and accelerate platform management.

[0001327567-24-000029:mdna:14]
Cloud Security:

[0001327567-24-000029:mdna:15]
•We deliver scalable and comprehensive security across the cloud application development lifecycle through our Code to CloudTM platform, Prisma Cloud. As a comprehensive CNAPP, Prisma Cloud secures multi- and hybrid-cloud environments for applications, data, GenAI ecosystem, and the entire cloud native technology stack across the full development lifecycle, from code to cloud. We also offer our VM-Series and CN-Series virtual firewalls for inline network security on multi- and hybrid-cloud environments.

[0001327567-24-000029:mdna:16]
- 43 -

[0001327567-24-000029:mdna:17]
Security Operations:

[0001327567-24-000029:mdna:18]
•We deliver the next generation of security operations capabilities that combine security analytics, endpoint security, automation, and ASM solutions through our Cortex platform. These include Cortex XSIAM, our AI-driven security operations platform, Cortex XDR® for the prevention, detection, and response to complex cybersecurity attacks, Cortex XSOAR® for SOAR, and Cortex XpanseTM for ASM. These products are delivered as SaaS or software subscriptions.

[0001327567-24-000029:mdna:19]
Threat Intelligence and Advisory Services (Unit 42):

[0001327567-24-000029:mdna:20]
•Unit 42 brings together world-renowned threat researchers with an elite team of incident responders and security consultants to create an intelligence-driven, response-ready organization to help customers manage cyber risk. Our consultants serve as trusted advisors to our customers by assessing and testing their security controls against the right threats, transforming their security strategy with a threat-informed approach, and responding to security incidents on behalf of our clients. Additionally, Unit 42 offers managed detection and response and managed threat hunting services.

[0001327567-24-000029:mdna:21]
For fiscal 2024 and 2023, total revenue was $8.0 billion and $6.9 billion, respectively, representing year-over-year growth of 16.5%. Our growth reflects the increased adoption of our portfolio, which consists of product, subscriptions, and support. We believe our portfolio will enable us to benefit from recurring revenues and new revenues as we continue to grow our end-customer base. As of July 31, 2024, we had end-customers in over 180 countries. Our end-customers represent a broad range of industries, including education, energy, financial services, government entities, healthcare, Internet and media, manufacturing, public sector, and telecommunications, and include almost all of the Fortune 100 companies and a majority of the Global 2000 companies. We maintain a field sales force that works closely with our channel partners in developing sales opportunities. We primarily use a two-tiered, indirect fulfillment model whereby we sell our products, subscriptions, and support to our distributors, which, in turn, sell to our resellers, which then sell to our end-customers.

[0001327567-24-000029:mdna:22]
Our product revenue grew to $1.6 billion or 20.0% of total revenue for fiscal 2024, representing year-over-year growth of 1.6%. Product revenue is derived from sales of our appliances, primarily our ML-Powered Next-Generation Firewall. Product revenue also includes revenue derived from software licenses of Panorama®, SD-WAN, and the VM-Series. Our ML-Powered Next-Generation Firewall incorporates our PAN-OS operating system, which provides a consistent set of capabilities across our entire network security product line. Our appliances and software licenses include a broad set of built-in networking and security features and functionalities. Our products are designed for different performance requirements throughout an organization, ranging from our PA-410, which is designed for small organizations and remote or branch offices, to our top-of-the-line PA-7500, which is designed for large-scale data centers and service provider use. The same firewall functionality that is delivered in our physical appliances is also available in our VM-Series virtual firewalls, which secure virtualized and cloud-based computing environments, and in our CN-Series container firewalls, which secure container environments and traffic.

[0001327567-24-000029:mdna:23]
Our subscription and support revenue grew to $6.4 billion or 80.0% of total revenue for fiscal 2024, representing year-over-year growth of 20.9%. Our subscriptions provide our end-customers with near real-time access to the latest antivirus, intrusion prevention, web filtering, modern malware prevention, data loss prevention, CASB and AI security capabilities across the network, endpoints, and the cloud. When customers purchase our physical, virtual, or container firewall appliances, or certain cloud offerings, they typically purchase support in order to receive ongoing security updates, upgrades, bug fixes, and repairs. In addition to the subscriptions purchased with these appliances, customers may also purchase other subscriptions on a per-user, per-endpoint, or capacity-based basis. We also offer professional services, including incident response, risk management, and digital forensic services.

[0001327567-24-000029:mdna:24]
We continue to invest in innovation as we evolve and further extend the capabilities of our portfolio, as we believe that innovation and timely development of new features and products are essential to meeting the needs of our end-customers and improving our competitive position. During fiscal 2024, we introduced several new offerings, including: Prisma Cloud Darwin release with newly integrated Code to Cloud intelligence capabilities, PAN-OS 11.2 Quasar, Cortex XSIAM 2.0, new Cortex XSIAM features, Prisma SASE 3.0, and Precision AITM. Additionally, we acquired productive investments that fit well within our long-term strategy. For example, in December 2023, we acquired Dig, which we expect will enhance our Prisma Cloud capabilities with a DSPM solution that is intended to provide customers with visibility into, and secure data stored across, their multi-cloud environments; and we acquired Talon, which will support Prisma SASE’s approach to provide secure access to business applications for unmanaged and personal devices with an enterprise browser. In May 2024, we announced an expanded partnership with International Business Machines Corporation (“IBM”) to deliver AI-powered security outcomes for customers, as part of which we agreed to acquire IBM's QRadar SaaS assets, including QRadar intellectual property rights, customer relationships and customer contracts. On August 31, 2024, we completed the acquisition of IBM’s QRadar SaaS assets and we expect the acquisition will help accelerate the growth of our Cortex XSIAM business.

[0001327567-24-000029:mdna:25]
- 44 -

[0001327567-24-000029:mdna:26]
We believe that the growth of our business and our short-term and long-term success are dependent upon many factors, including our ability to extend our technology leadership, grow our base of end-customers, expand deployment of our portfolio and support offerings within existing end-customers, focus on end-customer satisfaction, and address any product vulnerabilities. To manage any future growth effectively, we must continue to improve and expand our information technology and financial infrastructure, our operating and administrative systems and controls, and our ability to manage headcount, capital, and processes in an efficient manner. While these areas present significant opportunities for us, they also pose challenges and risks that we must successfully address in order to sustain the growth of our business and improve our operating results. For additional information regarding the challenges and risks we face, see the “Risk Factors” section in Part I, Item 1A of this Annual Report on Form 10-K.

[0001327567-24-000029:mdna:27]
Impact of Macroeconomic Developments and Other Factors on Our Business

[0001327567-24-000029:mdna:28]
Our overall performance depends in part on worldwide economic and geopolitical conditions and their impact on customer behavior. Worsening economic conditions, including inflation, higher interest rates, slower growth, fluctuations in foreign exchange rates, supply chain disruptions, and other conditions, may adversely affect our results of operations and financial performance.

[0001327567-24-000029:mdna:29]
The hostilities in Israel and the surrounding region have increased the levels of economic and political uncertainty. While we have business operations in Israel, and intend to continue growing our presence in Israel, we currently do not expect significant business disruption. We are actively monitoring, evaluating, and responding to the developing situation.

[0001327567-24-000029:mdna:30]
We are also monitoring the impact of inflationary pressures and the tensions between China and Taiwan, and between the U.S. and China, which could have an adverse impact on our business or results of operations in future periods.

[0001327567-24-000029:mdna:31]
Key Financial Metrics

[0001327567-24-000029:mdna:32]
We monitor the key financial metrics set forth in the tables below to help us evaluate growth trends, establish budgets, measure the effectiveness of our sales and marketing efforts, and assess operational efficiencies. We discuss revenue, gross margin, and the components of operating income (loss) and margin below under “Results of Operations.”

[0001327567-24-000029:mdna:33]
|  | July 31, |
|  | 2024 |  | 2023 |
|  | (in millions) |
| Total deferred revenue | $ | 11,480.5 |  |  | $ | 9,296.4 |  |
| Cash, cash equivalents, and investments | $ | 6,752.0 |  |  | $ | 5,437.9 |  |

[0001327567-24-000029:mdna:34]
|  | Year Ended July 31, |
|  | 2024 |  | 2023 |  | 2022 |
|  | (dollars in millions) |
| Total revenue | $ | 8,027.5 |  |  | $ | 6,892.7 |  |  | $ | 5,501.5 |  |
| Total revenue year-over-year percentage increase | 16.5 | % |  | 25.3 | % |  | 29.3 | % |
| Gross margin | 74.3 | % |  | 72.3 | % |  | 68.8 | % |
| Operating income (loss) | $ | 683.9 |  |  | $ | 387.3 |  |  | $ | (188.8) |  |
| Operating margin | 8.5 | % |  | 5.6 | % |  | (3.4) | % |
| Billings | $ | 10,208.1 |  |  | $ | 9,194.4 |  |  | $ | 7,471.5 |  |
| Billings year-over-year percentage increase | 11.0 | % |  | 23.1 | % |  | 37.0 | % |
| Cash flow provided by operating activities | $ | 3,257.6 |  |  | $ | 2,777.5 |  |  | $ | 1,984.7 |  |
| Free cash flow (non-GAAP) | $ | 3,100.8 |  |  | $ | 2,631.2 |  |  | $ | 1,791.9 |  |

[0001327567-24-000029:mdna:35]
•Deferred Revenue. Our deferred revenue primarily consists of amounts that have been invoiced but have not been recognized as revenue as of the period end. The majority of our deferred revenue balance consists of subscription and support revenue that is recognized ratably over the contractual service period. We monitor our deferred revenue balance because it represents a significant portion of revenue to be recognized in future periods.

[0001327567-24-000029:mdna:36]
- 45 -

[0001327567-24-000029:mdna:37]
•Billings. We define billings as total revenue plus the change in total deferred revenue, net of acquired deferred revenue, during the period. We have considered billings to be a key metric used by management to manage our business. There are inherent limitations in using billings to evaluate our operating results as the variability in payment terms may cause fluctuation in billings. Beginning in the first fiscal quarter of 2025, billings will no longer be a key financial metric and will no longer be reported. We calculate billings in the following manner:

[0001327567-24-000029:mdna:38]
|  | Year Ended July 31, |
|  | 2024 |  | 2023 |  | 2022 |
|  | (in millions) |
| Billings: |  |  |  |  |  |
| Total revenue | $ | 8,027.5 |  |  | $ | 6,892.7 |  |  | $ | 5,501.5 |  |
| Add: change in total deferred revenue, net of acquired deferred revenue | 2,180.6 |  |  | 2,301.7 |  |  | 1,970.0 |  |
| Billings | $ | 10,208.1 |  |  | $ | 9,194.4 |  |  | $ | 7,471.5 |  |

[0001327567-24-000029:mdna:39]
•Cash Flow Provided by Operating Activities. We monitor cash flow provided by operating activities as a measure of our overall business performance. Our cash flow provided by operating activities is driven in large part by sales of our products and from up-front payments for subscription and support offerings. Monitoring cash flow provided by operating activities enables us to analyze our financial performance without the non-cash effects of certain items such as share-based compensation costs, depreciation and amortization, thereby allowing us to better understand and manage the cash needs of our business.

[0001327567-24-000029:mdna:40]
•Free Cash Flow (non-GAAP). We define free cash flow, a non-GAAP financial measure, as cash provided by operating activities less purchases of property, equipment, and other assets. We consider free cash flow to be a profitability and liquidity measure that provides useful information to management and investors about the amount of cash generated by the business after necessary capital expenditures. A limitation of the utility of free cash flow as a measure of our financial performance and liquidity is that it does not represent the total increase or decrease in our cash balance for the period. In addition, it is important to note that other companies, including companies in our industry, may not use free cash flow, may calculate free cash flow in a different manner than we do, or may use other financial measures to evaluate their performance, all of which could reduce the usefulness of free cash flow as a comparative measure. A reconciliation of free cash flow to cash flow provided by operating activities, the most directly comparable financial measure calculated and presented in accordance with U.S. GAAP, is provided below:

[0001327567-24-000029:mdna:41]
|  | Year Ended July 31, |
|  | 2024 |  | 2023 |  | 2022 |
|  | (in millions) |
| Free cash flow (non-GAAP): |  |  |  |  |  |
| Net cash provided by operating activities | $ | 3,257.6 |  |  | $ | 2,777.5 |  |  | $ | 1,984.7 |  |
| Less: purchases of property, equipment, and other assets | 156.8 |  |  | 146.3 |  |  | 192.8 |  |
| Free cash flow (non-GAAP) | $ | 3,100.8 |  |  | $ | 2,631.2 |  |  | $ | 1,791.9 |  |
| Net cash used in investing activities | $ | (1,509.9) |  |  | $ | (2,033.8) |  |  | $ | (933.4) |  |
| Net cash used in financing activities | $ | (1,343.1) |  |  | $ | (1,726.3) |  |  | $ | (806.6) |  |

[0001327567-24-000029:mdna:42]
- 46 -

[0001327567-24-000029:mdna:43]
Results of Operations

[0001327567-24-000029:mdna:44]
The following table summarizes our results of operations for the periods presented and as a percentage of our total revenue for those periods based on our consolidated statements of operations data. The period-to-period comparison of results is not necessarily indicative of results for future periods.

[0001327567-24-000029:mdna:45]
|  | Year Ended July 31, |
|  | 2024 |  | 2023 |  | 2022 |
|  | Amount |  | % of Revenue |  | Amount |  | % of Revenue |  | Amount |  | % of Revenue |
|  | (dollars in millions) |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 1,603.3 |  |  | 20.0 | % |  | $ | 1,578.4 |  |  | 22.9 | % |  | $ | 1,363.1 |  |  | 24.8 | % |
| Subscription and support | 6,424.2 |  |  | 80.0 | % |  | 5,314.3 |  |  | 77.1 | % |  | 4,138.4 |  |  | 75.2 | % |
| Total revenue | 8,027.5 |  |  | 100.0 | % |  | 6,892.7 |  |  | 100.0 | % |  | 5,501.5 |  |  | 100.0 | % |
| Cost of revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Product | 348.2 |  |  | 4.3 | % |  | 418.3 |  |  | 6.1 | % |  | 455.5 |  |  | 8.3 | % |
| Subscription and support | 1,711.0 |  |  | 21.4 | % |  | 1,491.4 |  |  | 21.6 | % |  | 1,263.2 |  |  | 22.9 | % |
| Total cost of revenue(1) | 2,059.2 |  |  | 25.7 | % |  | 1,909.7 |  |  | 27.7 | % |  | 1,718.7 |  |  | 31.2 | % |
| Total gross profit | 5,968.3 |  |  | 74.3 | % |  | 4,983.0 |  |  | 72.3 | % |  | 3,782.8 |  |  | 68.8 | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | 1,809.4 |  |  | 22.5 | % |  | 1,604.0 |  |  | 23.3 | % |  | 1,417.7 |  |  | 25.8 | % |
| Sales and marketing | 2,794.5 |  |  | 34.8 | % |  | 2,544.0 |  |  | 36.9 | % |  | 2,148.9 |  |  | 39.0 | % |
| General and administrative | 680.5 |  |  | 8.5 | % |  | 447.7 |  |  | 6.5 | % |  | 405.0 |  |  | 7.4 | % |
| Total operating expenses(1) | 5,284.4 |  |  | 65.8 | % |  | 4,595.7 |  |  | 66.7 | % |  | 3,971.6 |  |  | 72.2 | % |
| Operating income (loss) | 683.9 |  |  | 8.5 | % |  | 387.3 |  |  | 5.6 | % |  | (188.8) |  |  | (3.4) | % |
| Interest expense | (8.3) |  |  | (0.1) | % |  | (27.2) |  |  | (0.4) | % |  | (27.4) |  |  | (0.5) | % |
| Other income, net | 312.7 |  |  | 3.9 | % |  | 206.2 |  |  | 3.0 | % |  | 9.0 |  |  | 0.1 | % |
| Income (loss) before income taxes | 988.3 |  |  | 12.3 | % |  | 566.3 |  |  | 8.2 | % |  | (207.2) |  |  | (3.8) | % |
| Provision for (benefit from) income taxes | (1,589.3) |  |  | (19.8) | % |  | 126.6 |  |  | 1.8 | % |  | 59.8 |  |  | 1.1 | % |
| Net income (loss) | $ | 2,577.6 |  |  | 32.1 | % |  | $ | 439.7 |  |  | 6.4 | % |  | $ | (267.0) |  |  | (4.9) | % |

[0001327567-24-000029:mdna:46]
(1)Includes share-based compensation as follows:

[0001327567-24-000029:mdna:47]
|  | Year Ended July 31, |
|  | 2024 |  | 2023 |  | 2022 |
|  | (in millions) |
| Cost of product revenue | $ | 7.3 |  |  | $ | 9.8 |  |  | $ | 9.3 |  |
| Cost of subscription and support revenue | 121.0 |  |  | 123.4 |  |  | 110.2 |  |
| Research and development | 525.5 |  |  | 488.4 |  |  | 471.1 |  |
| Sales and marketing | 300.8 |  |  | 335.3 |  |  | 304.7 |  |
| General and administrative | 124.1 |  |  | 130.4 |  |  | 118.1 |  |
| Total share-based compensation | $ | 1,078.7 |  |  | $ | 1,087.3 |  |  | $ | 1,013.4 |  |

[0001327567-24-000029:mdna:48]
- 47 -

[0001327567-24-000029:mdna:49]
REVENUE

[0001327567-24-000029:mdna:50]
Our revenue consists of product revenue and subscription and support revenue. Revenue is recognized upon transfer of control of the corresponding promised products and subscriptions and support to our customers in an amount that reflects the consideration we expect to be entitled to in exchange for those products and subscriptions and support. We expect our revenue to vary from quarter to quarter based on seasonal and cyclical factors.

[0001327567-24-000029:mdna:51]
PRODUCT REVENUE

[0001327567-24-000029:mdna:52]
Product revenue is derived from sales of our appliances, primarily our ML-Powered Next-Generation Firewall. Product revenue also includes revenue derived from software licenses of Panorama, SD-WAN, and the VM-Series. Our appliances and software licenses include a broad set of built-in networking and security features and functionalities. We recognize product revenue at the time of hardware shipment or delivery of software license.

[0001327567-24-000029:mdna:53]
|  | Year Ended July 31, |  |  |  | Year Ended July 31, |  |  |
|  | 2024 |  | 2023 |  | Change |  | 2023 |  | 2022 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Product | $ | 1,603.3 |  |  | $ | 1,578.4 |  |  | $ | 24.9 |  |  | 1.6 | % |  | $ | 1,578.4 |  |  | $ | 1,363.1 |  |  | $ | 215.3 |  |  | 15.8 | % |

[0001327567-24-000029:mdna:54]
Product revenue increased for fiscal 2024 compared to fiscal 2023 driven by increased software revenue primarily due to our go-to-market strategy for certain Network Security offerings, and a change in mix shift within our new generation of hardware products, partially offset by decreased demand for our prior generation of hardware products.

[0001327567-24-000029:mdna:55]
SUBSCRIPTION AND SUPPORT REVENUE

[0001327567-24-000029:mdna:56]
Subscription and support revenue is derived primarily from sales of our subscription and support offerings. Our subscription and support contracts are typically one to five years. We recognize revenue from subscriptions and support over time as the services are performed. As a percentage of total revenue, we expect our subscription and support revenue to vary from quarter to quarter and increase over the long term as we introduce new subscriptions, renew existing subscription and support contracts, and expand our installed end-customer base.

[0001327567-24-000029:mdna:57]
|  | Year Ended July 31, |  |  |  | Year Ended July 31, |  |  |
|  | 2024 |  | 2023 |  | Change |  | 2023 |  | 2022 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Subscription | $ | 4,188.5 |  |  | $ | 3,335.4 |  |  | $ | 853.1 |  |  | 25.6 | % |  | $ | 3,335.4 |  |  | $ | 2,539.0 |  |  | $ | 796.4 |  |  | 31.4 | % |
| Support | 2,235.7 |  |  | 1,978.9 |  |  | 256.8 |  |  | 13.0 | % |  | 1,978.9 |  |  | 1,599.4 |  |  | 379.5 |  |  | 23.7 | % |
| Total subscription and support | $ | 6,424.2 |  |  | $ | 5,314.3 |  |  | $ | 1,109.9 |  |  | 20.9 | % |  | $ | 5,314.3 |  |  | $ | 4,138.4 |  |  | $ | 1,175.9 |  |  | 28.4 | % |

[0001327567-24-000029:mdna:58]
Subscription and support revenue increased for fiscal 2024 compared to fiscal 2023 due to increased demand for our subscription and support offerings from our end-customers. The mix between subscription revenue and support revenue will fluctuate over time, depending on the introduction of new subscription offerings, renewals of support services, and our ability to increase sales to new and existing end-customers.

[0001327567-24-000029:mdna:59]
- 48 -

[0001327567-24-000029:mdna:60]
REVENUE BY GEOGRAPHIC THEATER

[0001327567-24-000029:mdna:61]
|  | Year Ended July 31, |  |  |  | Year Ended July 31, |  |  |
|  | 2024 |  | 2023 |  | Change |  | 2023 |  | 2022 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Americas | $ | 5,482.9 |  |  | $ | 4,719.9 |  |  | $ | 763.0 |  |  | 16.2 | % |  | $ | 4,719.9 |  |  | $ | 3,802.6 |  |  | $ | 917.3 |  |  | 24.1 | % |
| Europe, the Middle East, and Africa (“EMEA”) | 1,602.0 |  |  | 1,359.6 |  |  | 242.4 |  |  | 17.8 | % |  | 1,359.6 |  |  | 1,055.8 |  |  | 303.8 |  |  | 28.8 | % |
| Asia Pacific and Japan (“APAC”) | 942.6 |  |  | 813.2 |  |  | 129.4 |  |  | 15.9 | % |  | 813.2 |  |  | 643.1 |  |  | 170.1 |  |  | 26.5 | % |
| Total revenue | $ | 8,027.5 |  |  | $ | 6,892.7 |  |  | $ | 1,134.8 |  |  | 16.5 | % |  | $ | 6,892.7 |  |  | $ | 5,501.5 |  |  | $ | 1,391.2 |  |  | 25.3 | % |

[0001327567-24-000029:mdna:62]
Revenue from the Americas, EMEA and APAC increased year-over-year for fiscal 2024 as we continued to increase investment in our global sales force in order to support our growth and innovation. Our three geographic theaters had similar year-over-year revenue growth rates for fiscal 2024, with the Americas contributing the highest increase in revenue due to its larger scale.

[0001327567-24-000029:mdna:63]
COST OF REVENUE

[0001327567-24-000029:mdna:64]
Our cost of revenue consists of cost of product revenue and cost of subscription and support revenue.

[0001327567-24-000029:mdna:65]
COST OF PRODUCT REVENUE

[0001327567-24-000029:mdna:66]
Cost of product revenue primarily includes costs paid to our manufacturing partners for procuring components and manufacturing our products. Our cost of product revenue also includes personnel costs, which consist of salaries, benefits, bonuses, share-based compensation, and travel associated with our operations organization, amortization of intellectual property licenses, product testing costs, shipping and tariff costs, and shared costs. Shared costs consist of certain facilities, depreciation, benefits, recruiting, and information technology costs that we allocate based on headcount. We expect our cost of product revenue to fluctuate with our revenue from hardware products.

[0001327567-24-000029:mdna:67]
|  | Year Ended July 31, |  |  |  | Year Ended July 31, |  |  |
|  | 2024 |  | 2023 |  | Change |  | 2023 |  | 2022 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Cost of product revenue | $ | 348.2 |  |  | $ | 418.3 |  |  | $ | (70.1) |  |  | (16.8) | % |  | $ | 418.3 |  |  | $ | 455.5 |  |  | $ | (37.2) |  |  | (8.2) | % |

[0001327567-24-000029:mdna:68]
Cost of product revenue decreased for fiscal 2024 compared to fiscal 2023 primarily due to decreased demand for our prior generation of hardware products and lower costs largely driven by an easing of supply chain challenges, partially offset by a change in mix shift within our new generation hardware products.

[0001327567-24-000029:mdna:69]
COST OF SUBSCRIPTION AND SUPPORT REVENUE

[0001327567-24-000029:mdna:70]
Cost of subscription and support revenue includes personnel costs for our global customer support and technical operations organizations, data center and cloud hosting service costs, third-party professional services costs, amortization of acquired intangible assets and capitalized software development costs, customer support and repair costs, and shared costs. We expect our cost of subscription and support revenue to increase as our installed end-customer base grows and adoption of our cloud-based subscription offerings increases.

[0001327567-24-000029:mdna:71]
|  | Year Ended July 31, |  |  |  | Year Ended July 31, |  |  |
|  | 2024 |  | 2023 |  | Change |  | 2023 |  | 2022 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Cost of subscription and support revenue | $ | 1,711.0 |  |  | $ | 1,491.4 |  |  | $ | 219.6 |  |  | 14.7 | % |  | $ | 1,491.4 |  |  | $ | 1,263.2 |  |  | $ | 228.2 |  |  | 18.1 | % |

[0001327567-24-000029:mdna:72]
Cost of subscription and support revenue increased for fiscal 2024 compared to fiscal 2023 primarily due to increased costs to support the growth of our subscription and support offerings. Cloud hosting service costs, which support our cloud-based subscription offerings, increased $116.0 million for fiscal 2024 compared to fiscal 2023. Personnel costs grew $48.2 million for fiscal 2024 compared to fiscal 2023, primarily due to headcount growth.

[0001327567-24-000029:mdna:73]
- 49 -

[0001327567-24-000029:mdna:74]
GROSS MARGIN

[0001327567-24-000029:mdna:75]
Gross margin has been and will continue to be affected by a variety of factors, including the introduction of new products, manufacturing costs, the average sales price of our products, cloud hosting service costs, personnel costs, the mix of products sold, and the mix of revenue between product and subscription and support offerings. Our virtual and higher-end firewall products generally have higher gross margins than our lower-end firewall products within each product series. We expect our gross margins to vary over time depending on the factors described above.

[0001327567-24-000029:mdna:76]
|  | Year Ended July 31, |
|  | 2024 |  | 2023 |  | 2022 |
|  | Amount |  | GrossMargin |  | Amount |  | GrossMargin |  | Amount |  | GrossMargin |
|  | (dollars in millions) |
| Product | $ | 1,255.1 |  |  | 78.3 | % |  | $ | 1,160.1 |  |  | 73.5 | % |  | $ | 907.6 |  |  | 66.6 | % |
| Subscription and support | 4,713.2 |  |  | 73.4 | % |  | 3,822.9 |  |  | 71.9 | % |  | 2,875.2 |  |  | 69.5 | % |
| Total gross profit | $ | 5,968.3 |  |  | 74.3 | % |  | $ | 4,983.0 |  |  | 72.3 | % |  | $ | 3,782.8 |  |  | 68.8 | % |

[0001327567-24-000029:mdna:77]
Product gross margin increased for fiscal 2024 compared to fiscal 2023 primarily due to increased software revenue and lower costs largely driven by an easing of supply chain challenges.

[0001327567-24-000029:mdna:78]
Subscription and support gross margin increased for fiscal 2024 compared to fiscal 2023 primarily due to our growth in subscription and support revenue, which outpaced the subscription and support costs.

[0001327567-24-000029:mdna:79]
OPERATING EXPENSES

[0001327567-24-000029:mdna:80]
Our operating expenses consist of research and development, sales and marketing, and general and administrative expenses. Personnel costs are the most significant component of operating expenses and consist of salaries, benefits, bonuses, share-based compensation, travel and entertainment, and with regard to sales and marketing expense, sales commissions. Our operating expenses also include shared costs, which consist of certain facilities, depreciation, benefits, recruiting, and information technology costs that we allocate based on headcount to each department. We expect operating expenses generally to increase in absolute dollars and to decrease over the long term as a percentage of revenue as we continue to scale our business. As of July 31, 2024, we expect to recognize approximately $2.0 billion of share-based compensation expense over a weighted-average period of approximately 2.6 years, excluding additional share-based compensation expense related to any future grants of share-based awards. Share-based compensation expense is generally recognized on a straight-line basis over the requisite service periods of the awards.

[0001327567-24-000029:mdna:81]
RESEARCH AND DEVELOPMENT

[0001327567-24-000029:mdna:82]
Research and development expense consists primarily of personnel costs. Research and development expense also includes prototype-related expenses and shared costs. We expect research and development expense to increase in absolute dollars as we continue to invest in our future products and services, although our research and development expense may fluctuate as a percentage of total revenue.

[0001327567-24-000029:mdna:83]
|  | Year Ended July 31, |  |  |  | Year Ended July 31, |  |  |
|  | 2024 |  | 2023 |  | Change |  | 2023 |  | 2022 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Research and development | $ | 1,809.4 |  |  | $ | 1,604.0 |  |  | $ | 205.4 |  |  | 12.8 | % |  | $ | 1,604.0 |  |  | $ | 1,417.7 |  |  | $ | 186.3 |  |  | 13.1 | % |

[0001327567-24-000029:mdna:84]
Research and development expense increased for fiscal 2024 compared to fiscal 2023 primarily due to increased personnel costs, which grew $143.4 million, largely due to headcount growth. The remaining increase in research and development expense was further driven by increased shared costs.

[0001327567-24-000029:mdna:85]
- 50 -

[0001327567-24-000029:mdna:86]
SALES AND MARKETING

[0001327567-24-000029:mdna:87]
Sales and marketing expense consists primarily of personnel costs, including commission expense. Sales and marketing expense also includes costs for market development programs, promotional and other marketing costs, professional services, and shared costs. We continue to strategically invest in headcount and have grown our sales presence. We expect sales and marketing expense to continue to increase in absolute dollars as we increase the size of our sales and marketing organizations to grow our customer base, increase touch points with end-customers, and expand our global presence, although our sales and marketing expense may fluctuate as a percentage of total revenue.

[0001327567-24-000029:mdna:88]
|  | Year Ended July 31, |  |  |  | Year Ended July 31, |  |  |
|  | 2024 |  | 2023 |  | Change |  | 2023 |  | 2022 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Sales and marketing | $ | 2,794.5 |  |  | $ | 2,544.0 |  |  | $ | 250.5 |  |  | 9.8 | % |  | $ | 2,544.0 |  |  | $ | 2,148.9 |  |  | $ | 395.1 |  |  | 18.4 | % |

[0001327567-24-000029:mdna:89]
Sales and marketing expense increased for fiscal 2024 compared to fiscal 2023 primarily due to increased personnel costs, which grew $117.3 million, largely due to headcount growth. The increase in sales and marketing expense was further driven by increased costs associated with sales and marketing events and go-to-market initiatives.

[0001327567-24-000029:mdna:90]
GENERAL AND ADMINISTRATIVE

[0001327567-24-000029:mdna:91]
General and administrative expense consists primarily of personnel costs and shared costs for our executive, finance, human resources, information technology, and legal organizations, and professional services costs, which consist primarily of legal, auditing, accounting, and other consulting costs. We expect general and administrative expense to increase in absolute dollars over time as we increase the size of our general and administrative organizations and incur additional costs to support our business growth, although our general and administrative expense may fluctuate as a percentage of total revenue.

[0001327567-24-000029:mdna:92]
|  | Year Ended July 31, |  |  |  | Year Ended July 31, |  |  |
|  | 2024 |  | 2023 |  | Change |  | 2023 |  | 2022 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| General and administrative | $ | 680.5 |  |  | $ | 447.7 |  |  | $ | 232.8 |  |  | 52.0 | % |  | $ | 447.7 |  |  | $ | 405.0 |  |  | $ | 42.7 |  |  | 10.5 | % |

[0001327567-24-000029:mdna:93]
General and administrative expenses increased for fiscal 2024 compared to fiscal 2023 primarily due to litigation-related charges of $204.4 million in fiscal 2024. Refer to Note 12. Commitments and Contingencies in Part II, Item 8 of this Annual Report on Form 10-K for more information.

[0001327567-24-000029:mdna:94]
INTEREST EXPENSE

[0001327567-24-000029:mdna:95]
Interest expense primarily consists of interest expense related to our 0.75% Convertible Senior Notes due 2023 (the “2023 Notes”) and our 0.375% Convertible Senior Notes due 2025 (the “2025 Notes,” and together with “2023 Notes,” the “Notes”).

[0001327567-24-000029:mdna:96]
|  | Year Ended July 31, |  |  |  | Year Ended July 31, |  |  |
|  | 2024 |  | 2023 |  | Change |  | 2023 |  | 2022 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Interest expense | $ | 8.3 |  |  | $ | 27.2 |  |  | $ | (18.9) |  |  | (69.5) | % |  | $ | 27.2 |  |  | $ | 27.4 |  |  | $ | (0.2) |  |  | (0.7) | % |

[0001327567-24-000029:mdna:97]
Interest expense decreased for fiscal 2024 compared to fiscal 2023 primarily due to maturity of our 2023 Notes in July 2023 and early conversion of our 2025 Notes in fiscal 2024. Refer to Note 10. Debt in Part II, Item 8 of this Annual Report on Form 10-K for more information on the Notes.

[0001327567-24-000029:mdna:98]
- 51 -

[0001327567-24-000029:mdna:99]
OTHER INCOME, NET

[0001327567-24-000029:mdna:100]
Other income, net includes interest income earned on our cash, cash equivalents, and investments, and gains and losses from foreign currency remeasurement and foreign currency transactions.

[0001327567-24-000029:mdna:101]
|  | Year Ended July 31, |  |  |  | Year Ended July 31, |  |  |
|  | 2024 |  | 2023 |  | Change |  | 2023 |  | 2022 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Other income, net | $ | 312.7 |  |  | $ | 206.2 |  |  | $ | 106.5 |  |  | 51.6 | % |  | $ | 206.2 |  |  | $ | 9.0 |  |  | $ | 197.2 |  |  | * |

[0001327567-24-000029:mdna:102]
*    Not meaningful

[0001327567-24-000029:mdna:103]
Other income, net increased for fiscal 2024 compared to fiscal 2023 primarily due to higher interest income as a result of higher interest rates and higher average cash, cash equivalents, and investments balance for fiscal 2024 compared to fiscal 2023.

[0001327567-24-000029:mdna:104]
PROVISION FOR (BENEFIT FROM) INCOME TAXES

[0001327567-24-000029:mdna:105]
Provision for (benefit from) income taxes consists primarily of U.S. taxes, foreign income taxes, and withholding taxes. We had a benefit from income taxes during fiscal 2024 primarily due to the release of our valuation allowance on U.S. federal, U.S. states other than California, and U.K. deferred tax assets. We continue to maintain a valuation allowance for California and certain deferred tax assets, including net operating loss carryforwards and certain domestic tax credits.

[0001327567-24-000029:mdna:106]
|  | Year Ended July 31, |  |  |  |  |  | Year Ended July 31, |  |  |  |  |
|  | 2024 |  | 2023 |  | Change |  | 2023 |  | 2022 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Provision for (benefit from) income taxes | $ | (1,589.3) |  |  | $ | 126.6 |  |  | $ | (1,715.9) |  |  | * |  | $ | 126.6 |  |  | $ | 59.8 |  |  | $ | 66.8 |  |  | 111.7 | % |
| Effective tax rate | (160.8) | % |  | 22.4 | % |  |  |  |  |  | 22.4 | % |  | (28.9) | % |  |  |  |  |

[0001327567-24-000029:mdna:107]
*    Not meaningful

[0001327567-24-000029:mdna:108]
Our benefit from income taxes in fiscal 2024 was $1.6 billion, a net change of $1.7 billion compared to a provision for income taxes of $126.6 million in fiscal 2023, primarily due to the release of our valuation allowance in fiscal 2024. This is also the primary driver of the change in our effective tax rate for fiscal 2024 compared to fiscal 2023. Refer to Note 15. Income Taxes in Part II, Item 8 of this Annual Report on Form 10-K for more information.

[0001327567-24-000029:mdna:109]
Liquidity and Capital Resources

[0001327567-24-000029:mdna:110]
|  | July 31, |
|  | 2024 |  | 2023 |
|  | (in millions) |
| Working capital(1) | $ | (833.0) |  |  | $ | (1,689.5) |  |
| Cash, cash equivalents, and investments: |  |  |  |
| Cash and cash equivalents | $ | 1,535.2 |  |  | $ | 1,135.3 |  |
| Investments | 5,216.8 |  |  | 4,302.6 |  |
| Total cash, cash equivalents, and investments | $ | 6,752.0 |  |  | $ | 5,437.9 |  |

[0001327567-24-000029:mdna:111]
(1)Current liabilities included net carrying amounts of convertible senior notes of $1.0 billion and $2.0 billion as of July 31, 2024 and 2023, respectively. Refer to Note 10. Debt in Part II, Item 8 of this Annual Report on Form 10-K for information on the Notes.

[0001327567-24-000029:mdna:112]
As of July 31, 2024, our total cash, cash equivalents, and investments of $6.8 billion were held for general corporate purposes. As of July 31, 2024, we had no unremitted earnings when evaluating our outside basis difference relating to our U.S. investment in foreign subsidiaries. However, there could be local withholding taxes due to various foreign countries if certain lower tier earnings are distributed. Withholding taxes that would be payable upon remittance of these lower tier earnings are not material.

[0001327567-24-000029:mdna:113]
- 52 -

[0001327567-24-000029:mdna:114]
Beginning in fiscal 2023, we were required to capitalize and amortize research and development expenses as required by the Tax Cuts and Jobs Act. As a result of this change and our increased profitability, we have paid significantly more U.S. cash taxes during fiscal 2024 and we expect our cash tax payments to increase in future periods.

[0001327567-24-000029:mdna:115]
DEBT

[0001327567-24-000029:mdna:116]
In June 2020, we issued the 2025 Notes with an aggregate principal amount of $2.0 billion. The 2025 Notes mature on June 1, 2025; however, under certain circumstances, holders may surrender their 2025 Notes for conversion prior to the maturity date. Upon conversion of the 2025 Notes, we will pay cash equal to the aggregate principal amount of the 2025 Notes to be converted, and, at our election, we will pay or deliver cash and/or shares of our common stock for the amount of our conversion obligation in excess of the aggregate principal amount of the 2025 Notes being converted. During fiscal 2024, we repaid in cash $1.0 billion in aggregate principal amount of the 2025 Notes and issued 7.0 million shares of common stock to the holders for the conversion value in excess of the principal amount of the 2025 Notes converted, which were fully offset by shares we received from our exercise of the associated note hedges. Subsequent to July 31, 2024, through the filing date of this Annual Report on Form 10-K, $285.8 million in aggregate principal amount of the 2025 Notes was converted or had been submitted by the holders for conversion and will settle during the fiscal quarter ending October 31, 2024.

[0001327567-24-000029:mdna:117]
The sale price condition for the 2025 Notes was met during the fiscal quarter ended July 31, 2024, and as a result, holders may convert their 2025 Notes during the fiscal quarter ending October 31, 2024. If all of the holders convert their 2025 Notes during this period, we would be obligated to settle the $1.0 billion principal amount of the 2025 Notes in cash. We believe that our cash provided by operating activities, our existing cash, cash equivalents and investments, and existing sources of and access to financing will be sufficient to meet our anticipated cash needs should the holders choose to convert their 2025 Notes during the fiscal quarter ending October 31, 2024 or hold the 2025 Notes until maturity on June 1, 2025. As of July 31, 2024, $1.0 billion of our 2025 Notes remained outstanding. Refer to Note 10. Debt in Part II, Item 8 of this Annual Report on Form 10-K for more information on the Notes.

[0001327567-24-000029:mdna:118]
In April 2023, we entered into a credit agreement (the “Credit Agreement”) that provides for a $400.0 million unsecured revolving credit facility (the “Credit Facility”), with an option to increase the amount of the Credit Facility by up to an additional $350.0 million, subject to certain conditions. The interest rates and commitment fees are also subject to upward and downward adjustments based on our progress towards the achievement of certain sustainability goals related to greenhouse gas emissions. As of July 31, 2024, there were no amounts outstanding, and we were in compliance with all covenants under the Credit Agreement. Refer to Note 10. Debt in Part II, Item 8 of this Annual Report on Form 10-K for more information on the Credit Agreement.

[0001327567-24-000029:mdna:119]
CAPITAL RETURN

[0001327567-24-000029:mdna:120]
In February 2019, our board of directors authorized a $1.0 billion share repurchase program. In December 2020, August 2021, August 2022, and November 2023, our board of directors authorized additional $700.0 million, $676.1 million, $915.0 million, and $316.7 million increases to this share repurchase program, respectively, bringing the total authorization under this share repurchase program to $3.6 billion. Repurchases will be funded from available working capital and may be made at management’s discretion from time to time. As of July 31, 2024, $500.0 million remained available for future share repurchases under this repurchase program. On August 15, 2024, our board of directors authorized a $500.0 million increase to our share repurchase program, bringing the total remaining authorization for future share repurchases to $1.0 billion. The repurchase authorization will expire on December 31, 2025, and may be suspended or discontinued at any time without prior notice. Refer to Note 13. Stockholders’ Equity in Part II, Item 8 of this Annual Report on Form 10-K for more information on this repurchase program.

[0001327567-24-000029:mdna:121]
LEASES AND OTHER MATERIAL CASH REQUIREMENTS

[0001327567-24-000029:mdna:122]
We have entered into various non-cancelable operating leases, primarily for our offices and data centers, with lease terms expiring through fiscal 2036. As of July 31, 2024, we have total operating lease obligations of $446.4 million recorded on our consolidated balance sheet.

[0001327567-24-000029:mdna:123]
As of July 31, 2024, our commitments to purchase products, components, cloud and other services totaled $4.8 billion. Refer to Note 12. Commitments and Contingencies in Part II, Item 8 of this Annual Report on Form 10-K for more information on these commitments.

[0001327567-24-000029:mdna:124]
- 53 -

[0001327567-24-000029:mdna:125]
CASH FLOWS

[0001327567-24-000029:mdna:126]
The following table summarizes our cash flows for the years ended July 31, 2024, 2023, and 2022:

[0001327567-24-000029:mdna:127]
|  | Year Ended July 31, |
| 2024 |  | 2023 |  | 2022 |
|  | (in millions) |
| Net cash provided by operating activities | $ | 3,257.6 |  |  | $ | 2,777.5 |  |  | $ | 1,984.7 |  |
| Net cash used in investing activities | (1,509.9) |  |  | (2,033.8) |  |  | (933.4) |  |
| Net cash used in financing activities | (1,343.1) |  |  | (1,726.3) |  |  | (806.6) |  |
| Net increase (decrease) in cash, cash equivalents, and restricted cash | $ | 404.6 |  |  | $ | (982.6) |  |  | $ | 244.7 |  |

[0001327567-24-000029:mdna:128]
Cash from operations could be affected by various risks and uncertainties detailed in Part I, Item 1A “Risk Factors” in this Form 10-K. We believe that our cash flow from operations with existing cash and cash equivalents will be sufficient to meet our anticipated cash needs for at least the next 12 months and thereafter for the foreseeable future. Our future capital requirements will depend on many factors including our growth rate, the timing and extent of spending to support development efforts, the expansion of sales and marketing activities, the introduction of new and enhanced products and subscription and support offerings, the costs to acquire or invest in complementary businesses and technologies, the costs to ensure access to adequate manufacturing capacity, the investments in our infrastructure to support the adoption of our cloud-based subscription offerings, the repayment obligations associated with our 2025 Notes, the continuing market acceptance of our products and subscription and support offerings and macroeconomic events. In addition, from time to time, we may incur additional tax liability in connection with certain corporate structuring decisions.

[0001327567-24-000029:mdna:129]
We may also choose to seek additional equity or debt financing. In the event that additional financing is required from outside sources, we may not be able to raise it on terms acceptable to us or at all. If we are unable to raise additional capital when desired, our business, operating results, and financial condition may be adversely affected.

[0001327567-24-000029:mdna:130]
OPERATING ACTIVITIES

[0001327567-24-000029:mdna:131]
Our operating activities have consisted of net income (losses) adjusted for certain non-cash items and changes in assets and liabilities. Our largest source of cash provided by our operations is receipts from our billings.

[0001327567-24-000029:mdna:132]
Cash provided by operating activities during fiscal 2024 was $3.3 billion, an increase of $480.1 million compared to fiscal 2023. The increase was primarily due to growth of our business as reflected by increases in collections during fiscal 2024, partially offset by higher cash expenditure to support our business growth.

[0001327567-24-000029:mdna:133]
INVESTING ACTIVITIES

[0001327567-24-000029:mdna:134]
Our investing activities have consisted of capital expenditures, net investment purchases, sales, and maturities, and business acquisitions. We expect to continue such activities as our business grows.

[0001327567-24-000029:mdna:135]
Cash used in investing activities during fiscal 2024 was $1.5 billion, a decrease of $523.9 million compared to fiscal 2023. The decrease was primarily due to a decrease in purchases of investments, partially offset by a decrease in proceeds from sales and maturities of investments and an increase in net cash payments for business acquisitions during fiscal 2024.

[0001327567-24-000029:mdna:136]
FINANCING ACTIVITIES

[0001327567-24-000029:mdna:137]
Our financing activities have consisted of repayments of our convertible senior notes, cash used to repurchase shares of our common stock, proceeds from sales of shares through employee equity incentive plans, and payments for tax withholding obligations of certain employees related to the net share settlement of equity awards.

[0001327567-24-000029:mdna:138]
Cash used in financing activities during fiscal 2024 was $1.3 billion, a decrease of $383.2 million compared to fiscal 2023. The decrease was primarily due to a decrease in repayments of our Notes, partially offset by an increase in cash used to repurchases of our common stock during fiscal 2024.

[0001327567-24-000029:mdna:139]
- 54 -

[0001327567-24-000029:mdna:140]
Critical Accounting Estimates

[0001327567-24-000029:mdna:141]
Our consolidated financial statements have been prepared in accordance with U.S. GAAP. The preparation of these consolidated financial statements requires us to make estimates and assumptions that affect the reported amounts of assets, liabilities, revenue, expenses, and related disclosures. We base our estimates on historical experience and on various other assumptions that we believe are reasonable under the circumstances. We evaluate our estimates and assumptions on an ongoing basis. Actual results could differ materially from those estimates due to risks and uncertainties, including uncertainty in the current economic environment. To the extent that there are material differences between these estimates and our actual results, our future consolidated financial statements will be affected.

[0001327567-24-000029:mdna:142]
We believe that of our significant accounting policies described in Note 1. Description of Business and Summary of Significant Accounting Policies in Part II, Item 8 of this Annual Report on Form 10-K, the critical accounting estimates, assumptions, and judgments that have the most significant impact on our consolidated financial statements are described below.

[0001327567-24-000029:mdna:143]
REVENUE RECOGNITION

[0001327567-24-000029:mdna:144]
The majority of our contracts with our customers include various combinations of our products and subscriptions and support. Our appliances and software licenses have significant standalone functionalities and capabilities. Accordingly, these appliances and software licenses are distinct from our subscriptions and support services as the customer can benefit from the product without these services and such services are separately identifiable within the contract. We account for multiple agreements with a single customer as a single contract if the contractual terms and/or substance of those agreements indicate that they may be so closely related that they are, in effect, parts of a single contract. The amount of consideration we expect to receive in exchange for delivering on the contract is allocated to each performance obligation based on its relative standalone selling price.

[0001327567-24-000029:mdna:145]
We establish standalone selling price using the prices charged for a deliverable when sold separately. If the standalone selling price is not observable through past transactions, we estimate the standalone selling price based on our pricing model and our go-to-market strategy, which include factors such as type of sales channel (channel partner or end-customer), the geographies in which our offerings were sold (domestic or international), and offering type (products, subscriptions, or support). As our business offerings evolve over time, we may be required to modify our estimated standalone selling prices, and as a result the timing and classification of our revenue could be affected.

[0001327567-24-000029:mdna:146]
INCOME TAXES

[0001327567-24-000029:mdna:147]
We account for income taxes using the asset and liability method, which requires the recognition of deferred tax assets and liabilities for the expected future tax consequences of events that have been recognized in our consolidated financial statements or tax returns. In addition, deferred tax assets are recorded for all future benefits including, but not limited to, net operating losses, research and development credit carryforwards, and basis differences relating to our global intangible low-taxed income. Valuation allowances are provided when necessary to reduce deferred tax assets to the amount more likely than not to be realized.

[0001327567-24-000029:mdna:148]
Significant judgment is required in determining any valuation allowance recorded against deferred tax assets. In assessing the need for a valuation allowance, we consider all available evidence, including past operating results, estimates of future taxable income, and the feasibility of tax planning strategies. In the event that we change our determination as to the amount of deferred tax assets that can be realized, we will adjust our valuation allowance with a corresponding impact to the provision for income taxes in the period in which such determination is made.

[0001327567-24-000029:mdna:149]
We recognize liabilities for uncertain tax positions based on a two-step process. The first step is to evaluate the tax position for recognition by determining if the weight of available evidence indicates that it is more likely than not that the position will be sustained on audit, including resolution of related appeals or litigation processes, if any. The second step requires us to estimate and measure the tax benefit as the largest amount that is more likely than not to be realized upon ultimate settlement.

[0001327567-24-000029:mdna:150]
Significant judgment is required in evaluating our uncertain tax positions and determining our provision for income taxes. Although we believe our reserves are reasonable, no assurance can be given that the final tax outcome of these matters will not be different from that which is reflected in our historical income tax provisions and accruals. We adjust these reserves in light of changing facts and circumstances, such as the closing of a tax audit or the refinement of an estimate. To the extent that the final tax outcome of these matters is different than the amounts recorded, such differences may impact the provision for income taxes in the period in which such determination is made.

[0001327567-24-000029:mdna:151]
- 55 -

[0001327567-24-000029:mdna:152]
MANUFACTURING PARTNER AND SUPPLIER LIABILITIES

[0001327567-24-000029:mdna:153]
We outsource most of our manufacturing, repair, and supply chain management operations to our EMS provider, which procures components and assembles our products based on our demand forecasts. These forecasts of future demand are based upon historical trends and analysis from our sales and product management functions as adjusted for overall market conditions. We accrue costs for manufacturing purchase commitments in excess of our forecasted demand, including costs for excess components or for carrying costs incurred by our manufacturing partners and component suppliers. Actual component usage and product demand may be materially different from our forecast and could be caused by factors outside of our control, which could have an adverse impact on our results of operations. Through July 31, 2024, we have not accrued significant costs associated with this exposure.

[0001327567-24-000029:mdna:154]
LOSS CONTINGENCIES

[0001327567-24-000029:mdna:155]
We are subject to the possibility of various loss contingencies arising in the ordinary course of business. We accrue for loss contingencies when it is probable that an asset has been impaired or a liability has been incurred and the amount of loss can be reasonably estimated. If we determine that a loss is reasonably possible, then we disclose the possible loss or range of the possible loss or state that such an estimate cannot be made. We regularly evaluate current information available to us to determine whether an accrual is required, an accrual should be adjusted, or a range of possible loss should be disclosed.

[0001327567-24-000029:mdna:156]
From time to time, we are involved in disputes, litigation, and other legal actions. However, there are many uncertainties associated with any litigation, and these actions or other third-party claims against us may cause us to incur substantial settlement charges, which are inherently difficult to estimate and could adversely affect our results of operations. The actual liability in any such matters may be materially different from our estimates, which could result in the need to adjust our liability and record additional expenses. Refer to the “Litigation” subheading in Note 12. Commitments and Contingencies in Part II, Item 8 of this Annual Report on Form 10-K for more information regarding our litigation.

[0001327567-24-000029:mdna:157]
Recent Accounting Pronouncements

[0001327567-24-000029:mdna:158]
Refer to “Recently Issued Accounting Pronouncements” in Note 1. Description of Business and Summary of Significant Accounting Policies in Part II, Item 8 of this Annual Report on Form 10-K for a description of recent accounting pronouncements and our expectation of their impact, if any, on our results of operations and financial condition.

[0001327567-24-000029:mdna:159]
- 56 -
