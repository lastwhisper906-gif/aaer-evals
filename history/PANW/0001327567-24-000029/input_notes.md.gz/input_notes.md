# PANW notes — 0001327567-24-000029


## dei:DocumentsIncorporatedByReferenceTextBlock

[0001327567-24-000029:notes:1]
Portions of the information called for by Part III of this Annual Report on Form 10-K is hereby incorporated by reference from the definitive proxy statement for the registrant’s 2024 annual meeting of stockholders, which will be filed with the Securities and Exchange Commission not later than 120 days after the registrant’s fiscal year ended July 31, 2024.


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock

[0001327567-24-000029:notes:2]
Description of Business and Summary of Significant Accounting Policies 
Description of Business

[0001327567-24-000029:notes:3]
Palo Alto Networks, Inc. (the “Company,” “we,” “us,” or “our”), headquartered in Santa Clara, California, was incorporated in March 2005 under the laws of the State of Delaware and commenced operations in April 2005. We empower enterprises, organizations, service providers, and government entities to secure their users, networks, clouds and endpoints by delivering comprehensive cybersecurity enabled by artificial intelligence and automation.

[0001327567-24-000029:notes:4]
Basis of Presentation

[0001327567-24-000029:notes:5]
The accompanying consolidated financial statements have been prepared in conformity with U.S. generally accepted accounting principles (“U.S. GAAP”). The consolidated financial statements include all adjustments necessary for a fair presentation of our annual results. All adjustments are of a normal recurring nature.

[0001327567-24-000029:notes:6]
Principles of Consolidation

[0001327567-24-000029:notes:7]
The consolidated financial statements include our accounts and our wholly owned subsidiaries. All significant intercompany balances and transactions have been eliminated in consolidation.

[0001327567-24-000029:notes:8]
Reclassification

[0001327567-24-000029:notes:9]
Certain prior period amounts in the consolidated financial statements and accompanying notes have been reclassified to conform to the current period presentation.

[0001327567-24-000029:notes:10]
Use of Estimates

[0001327567-24-000029:notes:11]
The preparation of consolidated financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the amounts reported and disclosed in the consolidated financial statements and the accompanying notes. We evaluate our estimates on an ongoing basis. Management estimates include, but are not limited to, the standalone selling price for our products and services, share-based compensation, fair value of assets acquired and liabilities assumed in business combinations, the assessment of recoverability of our intangibles and goodwill, valuation allowance against deferred tax assets, manufacturing partner and supplier liabilities, deferred contract cost benefit period, and loss contingencies. We base our estimates on assumptions, both historical and forward looking, that we believe are reasonable. Actual results could differ materially from those estimates due to risks and uncertainties, including uncertainty in the current economic environment.

[0001327567-24-000029:notes:12]
Stock Split Effected in the Form of a Stock Dividend (“Stock Split”)

[0001327567-24-000029:notes:13]
On September 13, 2022, we executed a three-for-one stock split of our common stock, effected in the form of a stock dividend. The par value per share of our common stock remains unchanged at $0.0001 per share after the Stock Split. All references made to share or per share amounts on the accompanying consolidated financial statements and applicable disclosures have been retroactively adjusted to reflect the effects of the Stock Split.

[0001327567-24-000029:notes:14]
Concentrations

[0001327567-24-000029:notes:15]
Financial instruments that subject us to concentrations of credit risk consist primarily of cash and cash equivalents, investments, derivative contracts, accounts receivable and financing receivables.

[0001327567-24-000029:notes:16]
We invest only in high-quality credit instruments and our cash and cash equivalents and available-for-sale investments consist primarily of fixed income securities. Management believes that the financial institutions that hold our investments are financially sound and, accordingly, are subject to minimal credit risk. Deposits held with banks may exceed the amount of insurance provided on such deposits.

[0001327567-24-000029:notes:17]
Our derivative contracts expose us to credit risk to the extent that the counterparties may be unable to meet the terms of the arrangement. We mitigate this credit risk by transacting with major financial institutions with high credit ratings and also enter into master netting arrangements, which permit net settlement of transactions with the same counterparty. We are not required to pledge, and are not entitled to receive, cash collateral related to these derivative instruments. We do not enter into derivative contracts for trading or speculative purposes.

[0001327567-24-000029:notes:18]
Our accounts receivable are primarily derived from our distributors in various geographical locations. Our financing receivables are with qualified end-customers and channel partners. We perform ongoing credit evaluations and generally do not require collateral on accounts receivable or financing receivables.

[0001327567-24-000029:notes:19]
As of July 31, 2024, two distributors individually represented 10% or more of our gross accounts receivable, and in the aggregate represented 31.5% of our gross accounts receivable. As of July 31, 2024, no end-customers or channel partners represented 10% or more of our gross financing receivables.

[0001327567-24-000029:notes:20]
For fiscal 2024, four distributors represented 10% or more of our total revenue, representing 21.2%, 13.2%, 13.2%, and 11.4%, respectively. No single end-customer accounted for more than 10% of our total revenue in fiscal 2024, 2023, or 2022.

[0001327567-24-000029:notes:21]
We rely on an electronics manufacturing services provider (“EMS provider”) to assemble most of our products and sole source component suppliers for certain components.

[0001327567-24-000029:notes:22]
Comprehensive Income (Loss)

[0001327567-24-000029:notes:23]
Comprehensive income (loss) is comprised of net income (loss) and other comprehensive income (loss). Our other comprehensive income (loss) includes unrealized gains and losses on available-for-sale investments and unrealized gains and losses on cash flow hedges, net of tax effects.

[0001327567-24-000029:notes:24]
Foreign Currency Transactions

[0001327567-24-000029:notes:25]
The functional currency of our foreign subsidiaries is the U.S. dollar. Monetary assets and liabilities denominated in foreign currencies have been remeasured into U.S. dollars using the exchange rates in effect at the balance sheet dates. Foreign currency remeasurement gains and losses and foreign currency transaction gains and losses are not significant to the consolidated financial statements.

[0001327567-24-000029:notes:26]
Fair Value

[0001327567-24-000029:notes:27]
We define fair value as the price that would be received from selling an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date. When determining the fair value measurements for assets and liabilities which are required to be recorded at fair value, we consider the principal or most advantageous market in which to transact and the market-based risk.

[0001327567-24-000029:notes:28]
We categorize assets and liabilities recorded or disclosed at fair value on our consolidated balance sheets based upon the level of judgment associated with inputs used to measure their fair value. The categories are as follows:

[0001327567-24-000029:notes:29]
•Level 1—Inputs are unadjusted quoted prices in active markets for identical assets or liabilities.

[0001327567-24-000029:notes:30]
•Level 2—Inputs are quoted prices for similar assets and liabilities in active markets or inputs that are observable for the assets or liabilities, either directly or indirectly through market corroboration, for substantially the full term of the financial instruments.

[0001327567-24-000029:notes:31]
•Level 3—Inputs are unobservable inputs based on our own assumptions used to measure assets and liabilities at fair value. The inputs require significant management judgment or estimation.

[0001327567-24-000029:notes:32]
Our financial assets and liabilities that are measured at fair value on a recurring basis include marketable securities and derivative financial instruments. Goodwill, intangible assets, and other long-lived assets are measured at fair value on a nonrecurring basis, only if impairment is indicated. Certain certificates of deposit, time deposits, and overnight sweep accounts recorded in cash and cash equivalents and short-term investments are stated at their carrying amounts, which approximate fair value due to their short maturities. The carrying amounts of accounts receivable, accounts payable, and accrued liabilities approximate fair value due to their short-term nature.

[0001327567-24-000029:notes:33]
Cash, Cash Equivalents, and Investments

[0001327567-24-000029:notes:34]
We consider all highly liquid investments with original maturities of three months or less at the date of purchase to be cash equivalents. Investments not considered cash equivalents and with maturities of one year or less from the consolidated balance sheet date are classified as short-term investments. Investments with maturities greater than one year from the consolidated balance sheet date are classified as long-term investments.

[0001327567-24-000029:notes:35]
We determine the classification of our investments in marketable debt securities at the time of purchase and reevaluate such determination at each balance sheet date. Our marketable debt securities are classified as available-for-sale. Debt securities in an unrealized loss position are written down to its fair value with the corresponding charge recorded in other income, net on our consolidated statements of operations, if it is more likely than not that we will be required to sell the impaired security before recovery of its amortized cost basis, or we have the intention to sell the security. If neither of these conditions are met, we determine whether a credit loss exists by comparing the present value of the expected cash flows of the security with its amortized cost basis. An allowance for credit losses is recorded in other income, net on our consolidated statements of operations for an amount not to exceed the unrealized loss. Unrealized losses that are not credit-related are included in accumulated other comprehensive income (loss) (“AOCI”) in stockholders’ equity.

[0001327567-24-000029:notes:36]
Accounts Receivable

[0001327567-24-000029:notes:37]
Trade accounts receivable are recorded at the invoiced amount, net of allowances for credit losses. The allowance for credit losses is based on our assessment of collectability. Management regularly reviews the adequacy of the allowance for credit losses on a collective basis by considering the age of each outstanding invoice, each customer’s expected ability to pay and collection history, current market conditions, and, where appropriate, reasonable and supportable forecasts of future economic conditions. Accounts receivable deemed uncollectible are charged against the allowance for credit losses. For the years ended July 31, 2024 and 2023, the allowance for credit losses activity was not significant.

[0001327567-24-000029:notes:38]
Financing Receivables

[0001327567-24-000029:notes:39]
We provide financing arrangements for certain qualified end-customers and channel partners to purchase our products and services. Payment terms on these financing arrangements are up to five years. Financing receivables are recorded at amortized cost, which approximates fair value. We may sell, in certain instances, these financing arrangements on a non-recourse basis to third-party financial institutions. The financing receivables are derecognized upon transfer as these sales qualify as true sales.

[0001327567-24-000029:notes:40]
We evaluate the allowance for credit losses by assessing the risks and losses inherent in our financing receivables on either an individual or a collective basis. Our assessment considers various factors, including lifetime expected losses determined using customer risk profile, current economic conditions that may affect a customer’s ability to pay, and forward-looking economic considerations. Financing receivables deemed uncollectible are charged against the allowance for credit losses.

[0001327567-24-000029:notes:41]
Derivatives

[0001327567-24-000029:notes:42]
We are exposed to foreign currency exchange risk, and we use derivative financial instruments to manage our foreign currency exchange risk. Our derivative financial instruments are recorded at fair value, on a gross basis, as either assets or liabilities on our consolidated balance sheets.

[0001327567-24-000029:notes:43]
Our revenue is transacted in U.S. dollars, however, a portion of our operating expenditures are incurred outside of the United States and are denominated in foreign currencies, making them subject to fluctuations in foreign currency exchange rates. We enter into foreign currency derivative contracts with maturities of 24 months or less, which we designate as cash flow hedges, to manage the foreign currency exchange risk associated with our operating expenditures. Gains or losses related to the effective portion of our cash flow hedges are recorded as a component of AOCI on our consolidated balance sheets and are reclassified into the financial statement line item associated with the underlying hedged transaction on our consolidated statements of operations when the underlying hedged transaction is recognized in earnings. In the event the underlying hedged transactions do not occur, or it becomes probable that they will not occur within the defined hedge period, the gains or losses on these related cash flow hedges are recognized in other income, net on our consolidated statements of operations. Cash flows from foreign currency derivative contracts designated as cash flow hedges are classified on our consolidated statements of cash flows in the same manner as the underlying hedged transaction, primarily within cash flows from operating activities.

[0001327567-24-000029:notes:44]
We also enter into foreign currency derivative contracts to hedge a portion of our outstanding monetary assets and liabilities denominated in foreign currencies. These derivatives are not designated as hedging instruments for accounting purposes, and the related gains and losses are recorded in other income, net on our consolidated statements of operations.

[0001327567-24-000029:notes:45]
Property and Equipment

[0001327567-24-000029:notes:46]
Property and equipment are stated at cost, less accumulated depreciation. Depreciation is computed using the straight-line method over the estimated useful lives of the assets. Land is not depreciated. The estimated useful lives of our depreciable assets are as follows:

[0001327567-24-000029:notes:47]
| Asset category |  | Useful life |
| Computers, equipment, and software |  | 3 - 5 years |
| Demonstration units |  | 3 - 4 years |
| Furniture and fixtures |  | 5 years |
| Leasehold improvements |  | Lesser of 10 years or remaining lease term |

[0001327567-24-000029:notes:48]
Business Combinations

[0001327567-24-000029:notes:49]
We include the results of operations of the businesses that we acquire as of the respective dates of acquisition. We allocate the fair value of the purchase price of our acquisitions to the assets acquired and liabilities assumed, generally based on their estimated fair values. The excess of the purchase price over the fair values of these identifiable assets and liabilities is recorded as goodwill. Additional information existing as of the acquisition date but unknown to us may become known during the remainder of the measurement period, not to exceed 12 months from the acquisition date, which may result in changes to the amounts and allocations recorded.

[0001327567-24-000029:notes:50]
Intangible Assets

[0001327567-24-000029:notes:51]
Purchased intangible assets with finite lives are carried at cost, less accumulated amortization. Amortization is computed using the straight-line method over the estimated useful lives of the respective assets. Acquisition-related in-process research and development represents the fair value of incomplete research and development projects that have not reached technological feasibility as of the date of acquisition. Initially, these assets are not subject to amortization. Assets related to projects that have been completed are transferred to developed technology, which are subject to amortization.

[0001327567-24-000029:notes:52]
Impairment of Goodwill, Intangible Assets, and Other Long-Lived Assets

[0001327567-24-000029:notes:53]
Goodwill is evaluated for impairment on an annual basis in the fourth quarter of our fiscal year, and whenever events or changes in circumstances indicate the carrying amount of goodwill may not be recoverable. We have elected to first assess qualitative factors to determine whether it is more likely than not that the fair value of our single reporting unit is less than its carrying amount, including goodwill. If we determine that it is more likely than not that the fair value is less than its carrying amount, then the quantitative impairment test will be performed. Under the quantitative impairment test, if the carrying amount exceeds its fair value, we will recognize an impairment loss in an amount equal to that excess but limited to the total amount of goodwill.

[0001327567-24-000029:notes:54]
We evaluate events and changes in circumstances that could indicate carrying amounts of purchased intangible assets and other long-lived assets may not be recoverable. When such events or changes in circumstances occur, we assess the recoverability of these assets or asset groups by determining whether or not the carrying amount will be recovered through undiscounted expected future cash flows. If the total of the future undiscounted cash flows is less than the carrying amount of an asset or asset group, we record an impairment loss for the amount by which the carrying amount exceeds the fair value of the asset or asset group.

[0001327567-24-000029:notes:55]
We did not recognize any impairment losses on our goodwill, intangible assets, or other long-lived assets during the years ended July 31, 2024, 2023, and 2022.

[0001327567-24-000029:notes:56]
Manufacturing Partner and Supplier Liabilities

[0001327567-24-000029:notes:57]
We outsource most of our manufacturing, repair, and supply chain management operations to our EMS provider and payments to it are a significant portion of our cost of product revenue. Although we are contractually obligated to purchase manufactured products and components, we generally do not own the components and manufactured products. Product title transfers from our EMS provider to us and immediately to our customers upon shipment. Our EMS provider assembles our products using design specifications, quality assurance programs, and standards that we establish, and it procures components and assembles products based on our demand forecasts. These forecasts represent our estimates of future demand for our products based upon historical trends and analysis from our sales and product management functions as adjusted for overall market conditions. If the actual component usage and product demand are significantly lower than forecast, we record a liability for manufacturing purchase commitments in excess of our forecasted demand, including costs for excess components or for carrying costs incurred by our manufacturing partners and component suppliers. Through July 31, 2024, we have not accrued any significant costs associated with this exposure.

[0001327567-24-000029:notes:58]
Convertible Senior Notes

[0001327567-24-000029:notes:59]
Prior to August 1, 2021, our convertible senior notes were separated into a liability and an equity component. The carrying amount of the liability component was calculated by measuring the fair value of a similar liability that did not have an associated convertible feature, using a discounted cash flow model with a risk-adjusted yield. The carrying amount of the equity component representing the conversion option was determined by deducting the fair value of the liability component from the par value of the notes as a whole. This difference represented a debt discount that was amortized to interest expense using the effective interest method over the term of the notes. The equity component was not remeasured as it continued to meet the conditions for equity classification. Transaction costs related to the issuance of the notes were allocated to the liability and equity components using the same proportions as the proceeds from the notes. Transaction costs attributable to the liability component were netted with the liability component and amortized to interest expense using the effective interest method over the term of the notes. Transaction costs attributable to the equity component were netted with the equity component of the notes in additional paid-in capital. Upon the notes becoming convertible, the net carrying amount of the liability component was classified as a current liability and a portion of the equity component representing the conversion option was reclassified to temporary equity. The portion of the equity component classified as temporary equity was measured as the difference between the principal and net carrying amount of the notes, excluding debt issuance costs.

[0001327567-24-000029:notes:60]
Upon adoption of the new debt guidance on August 1, 2021, our convertible senior notes are accounted for entirely as a liability and measured at their amortized cost. Transaction costs related to the issuance of the notes are netted with the liability and are amortized on a straight-line basis, which approximates the effective interest rate method, to interest expense over the term of the notes.

[0001327567-24-000029:notes:61]
We adopted the new debt guidance using the modified-retrospective approach. The adoption of this standard resulted in an increase to convertible senior notes, net of $444.3 million, a decrease to accumulated deficit of $266.7 million, a decrease to additional paid-in capital of $581.9 million, and a decrease to temporary equity of $129.1 million on August 1, 2021.

[0001327567-24-000029:notes:62]
Revenue Recognition

[0001327567-24-000029:notes:63]
Our revenue consists of product revenue and subscription and support revenue. Revenue is recognized when control of promised products, subscriptions and support services are transferred to customers, in an amount that reflects the expected consideration in exchange for those products and services.

[0001327567-24-000029:notes:64]
We determine revenue recognition through the following steps:

[0001327567-24-000029:notes:65]
•Identification of the contract, or contracts, with a customer.

[0001327567-24-000029:notes:66]
•Identification of the performance obligations in the contract.

[0001327567-24-000029:notes:67]
•Determination of the transaction price.

[0001327567-24-000029:notes:68]
•Allocation of the transaction price to the performance obligations in the contract.

[0001327567-24-000029:notes:69]
•Recognition of revenue when, or as, we satisfy a performance obligation.

[0001327567-24-000029:notes:70]
Revenues are reported net of sales taxes. Shipping charges billed to our customers are included in revenue and related costs are included in cost of revenue.

[0001327567-24-000029:notes:71]
Product Revenue

[0001327567-24-000029:notes:72]
Product revenue is derived primarily from sales of our appliances. Product revenue also includes revenue derived from software licenses of Panorama, SD-WAN, and the VM-Series. Our appliances and software licenses include a broad set of built-in networking and security features and functionalities. We recognize product revenue at the time of hardware shipment or delivery of software license.

[0001327567-24-000029:notes:73]
Subscription and Support Revenue

[0001327567-24-000029:notes:74]
Subscription and support revenue is derived primarily from sales of our subscription and support offerings. We recognize subscription and support revenue over time as the services are performed. Our contractual subscription and support contracts are typically one to five years.

[0001327567-24-000029:notes:75]
Contracts with Multiple Performance Obligations

[0001327567-24-000029:notes:76]
The majority of our contracts with our customers include various combinations of our products and subscriptions and support. Our appliances and software licenses have significant standalone functionalities and capabilities. Accordingly, these appliances and software licenses are distinct from our subscriptions and support services as the customer can benefit from the product without these services and such services are separately identifiable within the contract. We account for multiple agreements with a single customer as a single contract if the contractual terms and/or substance of those agreements indicate that they may be so closely related that they are, in effect, parts of a single contract. The amount of consideration we expect to receive in exchange for delivering on the contract is allocated to each performance obligation based on its relative standalone selling price.

[0001327567-24-000029:notes:77]
We establish standalone selling price using the prices charged for a deliverable when sold separately. If the standalone selling price is not observable through past transactions, we estimate the standalone selling price based on our pricing model and our go-to-market strategy, which include factors such as type of sales channel (channel partner or end-customer), the geographies in which our offerings were sold (domestic or international), and offering type (products, subscriptions, or support).

[0001327567-24-000029:notes:78]
Deferred Revenue

[0001327567-24-000029:notes:79]
We record deferred revenue when cash payments are received or due in advance of our performance. Our payment terms typically require payment within 30 to 45 days of the date we issue an invoice. The current portion of deferred revenue represents the amounts that are expected to be recognized as revenue within one year of the consolidated balance sheet date.

[0001327567-24-000029:notes:80]
Deferred Contract Costs

[0001327567-24-000029:notes:81]
We defer contract costs that are recoverable and incremental to obtaining customer sales contracts. Contract costs, which primarily consist of sales commissions, are amortized on a systematic basis that is consistent with the transfer to the customer of the goods or services to which the asset relates. Sales commissions paid for initial contracts are generally not commensurate with the commissions paid for renewal contracts, given the substantive difference in commission rates in proportion to their respective contract values. Sales commissions for initial contracts that are not commensurate are amortized over a benefit period of five years. The benefit period is determined by taking into consideration contract length, expected renewals, technology life, and other quantitative and qualitative factors. Sales commissions for initial contracts that are commensurate and sales commissions for renewal contracts are amortized over the related contractual period.

[0001327567-24-000029:notes:82]
We classify deferred contract costs as short-term or long-term based on when we expect to recognize the expense. The amortization of deferred contract costs is included in sales and marketing expense on our consolidated statements of operations. Deferred contract costs are periodically reviewed for impairment. We did not recognize any impairment losses on our deferred contract costs during the years ended July 31, 2024, 2023, or 2022.

[0001327567-24-000029:notes:83]
Software Development Costs

[0001327567-24-000029:notes:84]
Internally developed software includes security software developed to deliver our cloud-based subscription offerings to our end-customers. These capitalized costs consist of internal compensation-related costs and external direct costs incurred during the application development stage and will be amortized over a useful life of three years. As of July 31, 2024 and 2023, we capitalized as other assets on our consolidated balance sheets $129.2 million and $132.1 million in costs, respectively, net of accumulated amortization, for security software developed to deliver our cloud-based subscription offerings. We recognized amortization expense of $77.2 million, $79.5 million, and $62.4 million related to these capitalized costs as cost of subscription and support revenue on our consolidated statements of operations during the years ended July 31, 2024, 2023, and 2022, respectively.

[0001327567-24-000029:notes:85]
The costs to develop software that is marketed externally have not been capitalized as we believe our current software development process is essentially completed concurrent with the establishment of technological feasibility. As such, all related software development costs are expensed as incurred and included in research and development expense on our consolidated statements of operations.

[0001327567-24-000029:notes:86]
Share-Based Compensation

[0001327567-24-000029:notes:87]
Compensation expense related to share-based transactions is measured at fair value on the grant date. We recognize share-based compensation expense for awards with only service conditions on a straight-line basis over the requisite service period. We recognize share-based compensation expense for awards with market conditions and awards with performance conditions on a straight-line basis over the requisite service period for each separately vesting portion of the award. We recognize share-based compensation expense for awards with performance conditions when it is probable that the performance condition will be achieved. We account for forfeitures of all share-based payment awards when they occur.

[0001327567-24-000029:notes:88]
Leases

[0001327567-24-000029:notes:89]
We determine if an arrangement is a lease at inception. We evaluate the classification of leases at commencement and, as necessary, at modification. Operating lease related balances are included in operating lease right-of-use assets, accrued and other liabilities, and long-term operating lease liabilities on our consolidated balance sheets. We did not have any material finance leases in any of the periods presented.

[0001327567-24-000029:notes:90]
Operating lease right-of-use assets represent our right to use an underlying asset for the lease term. Operating lease liabilities represent our obligation to make payments arising from the lease. Operating lease right-of-use assets and liabilities are recognized at the present value of the future lease payments at the lease commencement date. The interest rate used to determine the present value of the future lease payments is our incremental borrowing rate, because the interest rates implicit in our leases are not readily determinable. Our incremental borrowing rate is estimated to approximate the interest rate on a collateralized basis with similar terms and payments, and in economic environments where the leased asset is located. Operating lease right-of-use assets also include adjustments related to lease incentives, prepaid or accrued rent and initial direct lease costs. Operating lease right-of-use assets are subject to evaluation for impairment or disposal on a basis consistent with other long-lived assets.

[0001327567-24-000029:notes:91]
Our lease terms may include periods under options to extend or terminate the lease when it is reasonably certain that we will exercise that option. We generally use the base, non-cancelable lease term when determining the lease right-of-use assets and lease liabilities. Operating lease cost is recognized on a straight-line basis over the lease term.

[0001327567-24-000029:notes:92]
We account for lease and non-lease components as a single lease component and do not recognize right-of-use assets and lease liabilities for leases with a term of 12 months or less. Payments under our lease arrangements are primarily fixed, however, certain lease agreements contain variable payments, which are expensed as incurred and not included in the operating lease right-of-use assets and liabilities. Variable lease payments primarily consist of real estate taxes, common area maintenance charges, and insurance costs.

[0001327567-24-000029:notes:93]
Income Taxes

[0001327567-24-000029:notes:94]
We account for income taxes using the asset and liability method, which requires the recognition of deferred tax assets and liabilities for the expected future tax consequences of events that have been recognized in our consolidated financial statements or tax returns. In addition, deferred tax assets are recorded for all future benefits including, but not limited to, net operating losses, research and development credit carryforwards, and basis differences relating to our global intangible low-taxed income. Valuation allowances are provided when necessary to reduce deferred tax assets to the amount more likely than not to be realized.

[0001327567-24-000029:notes:95]
Significant judgment is required in determining any valuation allowance recorded against deferred tax assets. In assessing the need for a valuation allowance, we consider all available evidence, including past operating results, estimates of future taxable income, and the feasibility of tax planning strategies. In the event that we change our determination as to the amount of deferred tax assets that can be realized, we will adjust our valuation allowance with a corresponding impact to the provision for income taxes in the period in which such determination is made.

[0001327567-24-000029:notes:96]
We recognize liabilities for uncertain tax positions based on a two-step process. The first step is to evaluate the tax position for recognition by determining if the weight of available evidence indicates that it is more likely than not that the position will be sustained on audit, including resolution of related appeals or litigation processes, if any. The second step requires us to estimate and measure the tax benefit as the largest amount that is more likely than not to be realized upon ultimate settlement.

[0001327567-24-000029:notes:97]
Loss Contingencies

[0001327567-24-000029:notes:98]
We are subject to the possibility of various loss contingencies arising in the ordinary course of business. In determining loss contingencies, we consider the likelihood of loss or impairment of an asset, or the incurrence of a liability, as well as our ability to reasonably estimate the amount of loss. An estimated loss contingency is accrued when it is probable that an asset has been impaired or a liability has been incurred and the amount of loss can be reasonably estimated. If we determine that a loss is reasonably possible, then we disclose the possible loss or range of the possible loss or state that such an estimate cannot be made. We regularly evaluate current information available to us to determine whether an accrual is required, an accrual should be adjusted, or a range of possible loss should be disclosed.

[0001327567-24-000029:notes:99]
Recently Issued Accounting Pronouncements

[0001327567-24-000029:notes:100]
Segment Reporting

[0001327567-24-000029:notes:101]
In November 2023, the Financial Accounting Standards Board (“FASB”) issued authoritative guidance that expands annual and interim disclosure requirements for reportable segments, primarily through enhanced disclosures about significant segment expenses. The standard is effective for our annual periods beginning in fiscal 2025 and interim periods beginning in the first quarter of fiscal 2026, and requires retrospective application for all prior periods presented in the financial statements. Early adoption is permitted. We are currently evaluating the impact of this standard on our disclosures in the consolidated financial statements.

[0001327567-24-000029:notes:102]
Income Tax Disclosures

[0001327567-24-000029:notes:103]
In December 2023, the FASB issued authoritative guidance that requires consistent categories and greater disaggregation of information in the effective tax rate reconciliation and additional disclosures of income taxes paid by jurisdiction. The standard is effective for our annual periods beginning in fiscal 2026 and could be applied either prospectively or retrospectively. Early adoption is permitted. We are currently evaluating the impact of this standard on our disclosures in the consolidated financial statements.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001327567-24-000029:notes:104]
Revenue 
Disaggregation of Revenue

[0001327567-24-000029:notes:105]
The following table presents revenue by geographic theater (in millions):

[0001327567-24-000029:notes:106]
|  | Year Ended July 31, |
|  | 2024 |  | 2023 |  | 2022 |
| Revenue: |  |  |  |  |  |
| Americas |  |  |  |  |  |
| United States | $ | 5,134.0 |  |  | $ | 4,424.2 |  |  | $ | 3,560.3 |  |
| Other Americas | 348.9 |  |  | 295.7 |  |  | 242.3 |  |
| Total Americas | 5,482.9 |  |  | 4,719.9 |  |  | 3,802.6 |  |
| Europe, the Middle East, and Africa (“EMEA”) | 1,602.0 |  |  | 1,359.6 |  |  | 1,055.8 |  |
| Asia Pacific and Japan (“APAC”) | 942.6 |  |  | 813.2 |  |  | 643.1 |  |
| Total revenue | $ | 8,027.5 |  |  | $ | 6,892.7 |  |  | $ | 5,501.5 |  |

[0001327567-24-000029:notes:107]
The following table presents revenue for groups of similar products and services (in millions):

[0001327567-24-000029:notes:108]
|  | Year Ended July 31, |
|  | 2024 |  | 2023 |  | 2022 |
| Revenue: |  |  |  |  |  |
| Product | $ | 1,603.3 |  |  | $ | 1,578.4 |  |  | $ | 1,363.1 |  |
| Subscription and support |  |  |  |  |  |
| Subscription | 4,188.5 |  |  | 3,335.4 |  |  | 2,539.0 |  |
| Support | 2,235.7 |  |  | 1,978.9 |  |  | 1,599.4 |  |
| Total subscription and support | 6,424.2 |  |  | 5,314.3 |  |  | 4,138.4 |  |
| Total revenue | $ | 8,027.5 |  |  | $ | 6,892.7 |  |  | $ | 5,501.5 |  |

[0001327567-24-000029:notes:109]
During the years ended July 31, 2024 and 2023, we recognized approximately $4.6 billion and $3.6 billion of revenue pertaining to amounts that were deferred as of July 31, 2023 and 2022, respectively.

[0001327567-24-000029:notes:110]
Remaining Performance Obligations

[0001327567-24-000029:notes:111]
Remaining performance obligations were $12.7 billion as of July 31, 2024, of which we expect to recognize as revenue approximately $5.9 billion over the next 12 months and the remainder thereafter.


## us-gaap:FairValueDisclosuresTextBlock

[0001327567-24-000029:notes:112]
Fair Value Measurements 
The following table presents our financial assets and liabilities measured at fair value on a recurring basis as of July 31, 2024 and 2023 (in millions):

[0001327567-24-000029:notes:113]
|  |  | July 31, 2024 |  | July 31, 2023 |
|  |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Cash equivalents: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 494.0 |  |  | $ | — |  |  | $ | — |  |  | $ | 494.0 |  |  | $ | 476.1 |  |  | $ | — |  |  | $ | — |  |  | $ | 476.1 |  |
| Commercial paper |  | — |  |  | 299.6 |  |  | — |  |  | 299.6 |  |  | — |  |  | 151.4 |  |  | — |  |  | 151.4 |  |
| Corporate debt securities |  | — |  |  | 18.2 |  |  | — |  |  | 18.2 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| U.S. government and agency securities |  | — |  |  | 149.6 |  |  | — |  |  | 149.6 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Total cash equivalents |  | 494.0 |  |  | 467.4 |  |  | — |  |  | 961.4 |  |  | 476.1 |  |  | 151.4 |  |  | — |  |  | 627.5 |  |
| Short-term investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Certificates of deposit |  | — |  |  | 20.6 |  |  | — |  |  | 20.6 |  |  | — |  |  | 48.1 |  |  | — |  |  | 48.1 |  |
| Commercial paper |  | — |  |  | 79.9 |  |  | — |  |  | 79.9 |  |  | — |  |  | 213.8 |  |  | — |  |  | 213.8 |  |
| Corporate debt securities |  | — |  |  | 935.9 |  |  | — |  |  | 935.9 |  |  | — |  |  | 798.0 |  |  | — |  |  | 798.0 |  |
| U.S. government and agency securities |  | — |  |  | 2.7 |  |  | — |  |  | 2.7 |  |  | — |  |  | 190.6 |  |  | — |  |  | 190.6 |  |
| Non-U.S. government and agency securities |  | — |  |  | 4.2 |  |  | — |  |  | 4.2 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Asset-backed securities |  | — |  |  | 0.3 |  |  | — |  |  | 0.3 |  |  | — |  |  | 4.2 |  |  | — |  |  | 4.2 |  |
| Total short-term investments |  | — |  |  | 1,043.6 |  |  | — |  |  | 1,043.6 |  |  | — |  |  | 1,254.7 |  |  | — |  |  | 1,254.7 |  |
| Long-term investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate debt securities |  | — |  |  | 3,151.3 |  |  | — |  |  | 3,151.3 |  |  | — |  |  | 2,484.3 |  |  | — |  |  | 2,484.3 |  |
| U.S. government and agency securities |  | — |  |  | 19.0 |  |  | — |  |  | 19.0 |  |  | — |  |  | 22.0 |  |  | — |  |  | 22.0 |  |
| Non-U.S. government and agency securities |  | — |  |  | 54.4 |  |  | — |  |  | 54.4 |  |  | — |  |  | 36.6 |  |  | — |  |  | 36.6 |  |
| Asset-backed securities |  | — |  |  | 948.5 |  |  | — |  |  | 948.5 |  |  | — |  |  | 505.0 |  |  | — |  |  | 505.0 |  |
| Total long-term investments |  | — |  |  | 4,173.2 |  |  | — |  |  | 4,173.2 |  |  | — |  |  | 3,047.9 |  |  | — |  |  | 3,047.9 |  |
| Prepaid expenses and other current assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency forward contracts |  | — |  |  | 4.1 |  |  | — |  |  | 4.1 |  |  | — |  |  | 19.1 |  |  | — |  |  | 19.1 |  |
| Total prepaid expenses and other current assets |  | — |  |  | 4.1 |  |  | — |  |  | 4.1 |  |  | — |  |  | 19.1 |  |  | — |  |  | 19.1 |  |

[0001327567-24-000029:notes:114]
|  |  | July 31, 2024 |  | July 31, 2023 |
|  |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Other assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency forward contracts |  | — |  |  | 0.1 |  |  | — |  |  | 0.1 |  |  | — |  |  | 1.7 |  |  | — |  |  | 1.7 |  |
| Total other assets |  | — |  |  | 0.1 |  |  | — |  |  | 0.1 |  |  | — |  |  | 1.7 |  |  | — |  |  | 1.7 |  |
| Total assets measured at fair value |  | $ | 494.0 |  |  | $ | 5,688.4 |  |  | $ | — |  |  | $ | 6,182.4 |  |  | $ | 476.1 |  |  | $ | 4,474.8 |  |  | $ | — |  |  | $ | 4,950.9 |  |
| Accrued and other liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency forward contracts |  | $ | — |  |  | $ | 15.3 |  |  | $ | — |  |  | $ | 15.3 |  |  | $ | — |  |  | $ | 18.7 |  |  | $ | — |  |  | $ | 18.7 |  |
| Total accrued and other liabilities |  | — |  |  | 15.3 |  |  | — |  |  | 15.3 |  |  | — |  |  | 18.7 |  |  | — |  |  | 18.7 |  |
| Other long-term liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency forward contracts |  | — |  |  | 0.9 |  |  | — |  |  | 0.9 |  |  | — |  |  | 1.6 |  |  | — |  |  | 1.6 |  |
| Total other long-term liabilities |  | — |  |  | 0.9 |  |  | — |  |  | 0.9 |  |  | — |  |  | 1.6 |  |  | — |  |  | 1.6 |  |
| Total liabilities measured at fair value |  | $ | — |  |  | $ | 16.2 |  |  | $ | — |  |  | $ | 16.2 |  |  | $ | — |  |  | $ | 20.3 |  |  | $ | — |  |  | $ | 20.3 |  |

[0001327567-24-000029:notes:115]
The total estimated fair value of our financing receivables approximates their carrying amounts as of July 31, 2024 and 2023. We consider the fair value of our financing receivables to be a Level 3 measurement as we use unobservable inputs in determining discounted cash flows to estimate the fair value.

[0001327567-24-000029:notes:116]
Refer to Note 10. Debt, for the carrying amount and estimated fair value of our convertible senior notes as of July 31, 2024 and 2023.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001327567-24-000029:notes:117]
Cash Equivalents and Investments
Available-for-sale Debt Securities

[0001327567-24-000029:notes:118]
The following tables summarize the amortized cost, unrealized gains and losses, and fair value of our available-for-sale debt securities (in millions):

[0001327567-24-000029:notes:119]
|  | July 31, 2024 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | $ | 299.6 |  |  | $ | — |  |  | $ | — |  |  | $ | 299.6 |  |
| Corporate debt securities | 18.2 |  |  | — |  |  | — |  |  | 18.2 |  |
| U.S. government and agency securities | 149.6 |  |  | — |  |  | — |  |  | 149.6 |  |
| Total available-for-sale cash equivalents | $ | 467.4 |  |  | $ | — |  |  | $ | — |  |  | $ | 467.4 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 20.6 |  |  | $ | — |  |  | $ | — |  |  | $ | 20.6 |  |
| Commercial paper | 79.9 |  |  | 0.1 |  |  | (0.1) |  |  | 79.9 |  |
| Corporate debt securities | 4,065.5 |  |  | 28.3 |  |  | (6.6) |  |  | 4,087.2 |  |
| U.S. government and agency securities | 21.9 |  |  | — |  |  | (0.2) |  |  | 21.7 |  |
| Non-U.S. government and agency securities | 57.9 |  |  | 0.7 |  |  | — |  |  | 58.6 |  |
| Asset-backed securities | 943.1 |  |  | 6.3 |  |  | (0.6) |  |  | 948.8 |  |
| Total available-for-sale investments | $ | 5,188.9 |  |  | $ | 35.4 |  |  | $ | (7.5) |  |  | $ | 5,216.8 |  |

[0001327567-24-000029:notes:120]
|  | July 31, 2023 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | $ | 151.4 |  |  | $ | — |  |  | $ | — |  |  | $ | 151.4 |  |
| Total available-for-sale cash equivalents | $ | 151.4 |  |  | $ | — |  |  | $ | — |  |  | $ | 151.4 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 48.1 |  |  | $ | — |  |  | $ | — |  |  | $ | 48.1 |  |
| Commercial paper | 214.1 |  |  | — |  |  | (0.3) |  |  | 213.8 |  |
| Corporate debt securities | 3,313.5 |  |  | 1.3 |  |  | (32.5) |  |  | 3,282.3 |  |
| U.S. government and agency securities | 214.2 |  |  | — |  |  | (1.6) |  |  | 212.6 |  |
| Non-U.S. government and agency securities | 37.2 |  |  | — |  |  | (0.6) |  |  | 36.6 |  |
| Asset-backed securities | 512.0 |  |  | 0.2 |  |  | (3.0) |  |  | 509.2 |  |
| Total available-for-sale investments | $ | 4,339.1 |  |  | $ | 1.5 |  |  | $ | (38.0) |  |  | $ | 4,302.6 |  |

[0001327567-24-000029:notes:121]
As of July 31, 2024, the gross unrealized losses that have been in a continuous unrealized loss position for less than 12 months were $1.5 million, which were related to $949.4 million of available-for-sale debt securities, and the gross unrealized losses that have been in a continuous unrealized loss position for more than 12 months were $6.0 million, which were related to $915.3 million of available-for-sale debt securities. As of July 31, 2023, the gross unrealized losses that have been in a continuous unrealized loss position for less than 12 months were $30.7 million, which were related to $3.4 billion of available-for-sale debt securities, and the gross unrealized losses that have been in a continuous unrealized loss position for more than 12 months were $7.3 million, which were related to $481.8 million of available-for-sale debt securities.

[0001327567-24-000029:notes:122]
Unrealized losses related to our available-for-sale debt securities are primarily due to interest rate fluctuations as opposed to credit quality. We do not intend to sell any of the securities in an unrealized loss position and it is not likely that we would be required to sell these securities before recovery of their amortized cost basis, which may be at maturity. We did not recognize any credit losses related to our available-for-sale debt securities during the years ended July 31, 2024 and 2023.

[0001327567-24-000029:notes:123]
The following table summarizes the amortized cost and fair value of our available-for-sale debt securities as of July 31, 2024, by contractual years-to-maturity (in millions):

[0001327567-24-000029:notes:124]
|  | Amortized Cost |  | Fair Value |
| Due within one year | $ | 1,513.3 |  |  | $ | 1,511.0 |  |
| Due between one and three years | 2,054.2 |  |  | 2,059.9 |  |
| Due between three and five years | 1,782.9 |  |  | 1,804.1 |  |
| Due between five and ten years | 203.5 |  |  | 205.1 |  |
| Due after ten years | 102.4 |  |  | 104.1 |  |
| Total | $ | 5,656.3 |  |  | $ | 5,684.2 |  |

[0001327567-24-000029:notes:125]
Marketable Equity Securities

[0001327567-24-000029:notes:126]
Marketable equity securities consist of money market funds and are included in cash and cash equivalents on our consolidated balance sheets. As of July 31, 2024 and 2023, the carrying amounts of our marketable equity securities were $494.0 million and $476.1 million, respectively. There were no unrealized gains or losses recognized for these securities during the years ended July 31, 2024, 2023, and 2022.


## us-gaap:FinancingReceivablesTextBlock

[0001327567-24-000029:notes:127]
Financing Receivables
The following table summarizes our short-term and long-term financing receivables (in millions):

[0001327567-24-000029:notes:128]
|  | July 31, |
|  | 2024 |  | 2023 |
| Short-term financing receivables, gross | $ | 830.2 |  |  | $ | 435.1 |  |
| Unearned income | (95.7) |  |  | (42.9) |  |
| Allowance for credit losses | (8.6) |  |  | (3.4) |  |
| Short-term financing receivables, net | $ | 725.9 |  |  | $ | 388.8 |  |
| Long-term financing receivables, gross | $ | 1,286.4 |  |  | $ | 698.6 |  |
| Unearned income | (94.6) |  |  | (39.2) |  |
| Allowance for credit losses | (9.7) |  |  | (6.1) |  |
| Long-term financing receivables, net | $ | 1,182.1 |  |  | $ | 653.3 |  |

[0001327567-24-000029:notes:129]
The following table presents amortized cost basis of our financing receivables categorized by internal risk rating and year of origination (in millions):

[0001327567-24-000029:notes:130]
| Internal Risk Rating(1) |  | July 31, 2024 |  | July 31, 2023 |
|  | Fiscal Years Ended July 31, |  |  |  | Fiscal Years Ended July 31, |  |  |
|  | 2024 |  | 2023 |  | 2022 |  | 2021 |  | Total |  | 2023 |  | 2022 |  | 2021 |  | 2020 |  | Total |
| 1 to 4 |  | $ | 885.9 |  |  | $ | 477.3 |  |  | $ | 14.7 |  |  | $ | 44.4 |  |  | $ | 1,422.3 |  |  | $ | 595.8 |  |  | $ | 50.6 |  |  | $ | 114.5 |  |  | $ | 1.2 |  |  | $ | 762.1 |  |
| 5 to 6 |  | 272.2 |  |  | 172.0 |  |  | 21.1 |  |  | 1.1 |  |  | 466.4 |  |  | 219.4 |  |  | 40.1 |  |  | 4.4 |  |  | 1.5 |  |  | 265.4 |  |
| 7 to 10 |  | 3.2 |  |  | 25.0 |  |  | 0.3 |  |  | 9.1 |  |  | 37.6 |  |  | 5.6 |  |  | 0.6 |  |  | 17.9 |  |  | — |  |  | 24.1 |  |
| Amortized cost basis of financing receivables |  | $ | 1,161.3 |  |  | $ | 674.3 |  |  | $ | 36.1 |  |  | $ | 54.6 |  |  | $ | 1,926.3 |  |  | $ | 820.8 |  |  | $ | 91.3 |  |  | $ | 136.8 |  |  | $ | 2.7 |  |  | $ | 1,051.6 |  |

[0001327567-24-000029:notes:131]
(1)Internal risk ratings are categorized as 1 through 10, with the lowest rating representing the highest quality.
There was no significant activity in allowance for credit losses during the years ended July 31, 2024 and 2023. Past due amounts on financing receivables were not material as of July 31, 2024 and 2023.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001327567-24-000029:notes:132]
Derivative Instruments
As of July 31, 2024 and 2023, the notional amount of our outstanding foreign currency forward contracts designated as cash flow hedges was $804.8 million and $824.1 million, respectively. Refer to Note 3. Fair Value Measurements for the fair value of our derivative instruments as reported on our consolidated balance sheets as of July 31, 2024 and 2023.

[0001327567-24-000029:notes:133]
As of July 31, 2024, unrealized gains and losses in AOCI related to our cash flow hedges were a $10.6 million net loss, of which $7.9 million in losses are expected to be recognized into earnings within the next 12 months. As of July 31, 2023, unrealized gains and losses in AOCI related to our cash flow hedges were a $0.7 million net gain.

[0001327567-24-000029:notes:134]
As of July 31, 2024 and 2023, the notional amount of our outstanding foreign currency forward contracts not designated as hedging instruments was $375.6 million and $133.4 million, respectively.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001327567-24-000029:notes:135]
Acquisitions
Fiscal 2024

[0001327567-24-000029:notes:136]
Dig Security Solutions Ltd.

[0001327567-24-000029:notes:137]
On December 5, 2023, we completed our acquisition of Dig Security Solutions Ltd. (“Dig”), a privately-held cyber security company. We expect the acquisition will enhance our Prisma Cloud capabilities with a data security posture management solution that is intended to provide customers with visibility into, and secure data stored across, their multi-cloud environments. The total purchase consideration for the acquisition of Dig was $255.4 million, which consisted of the following (in millions):

[0001327567-24-000029:notes:138]
|  | Amount |
| Cash | $ | 247.6 |  |
| Fair value of replacement awards | 7.8 |  |
| Total | $ | 255.4 |  |

[0001327567-24-000029:notes:139]
As part of the acquisition, we issued replacement equity awards, which included 0.2 million shares of our restricted common stock. The total fair value of the replacement equity awards was $72.0 million, of which the portion attributable to services performed prior to the acquisition date was allocated to purchase consideration. The remaining fair value was allocated to future services and will be expensed over the remaining service periods as share-based compensation.

[0001327567-24-000029:notes:140]
We have accounted for this transaction as a business combination and allocated the purchase consideration to assets acquired and liabilities assumed based on preliminary estimated fair values, as presented in the following table (in millions):

[0001327567-24-000029:notes:141]
|  | Amount |
| Goodwill | $ | 186.4 |  |
| Identified intangible assets | 45.4 |  |
| Cash and restricted cash | 22.1 |  |
| Net assets acquired | 1.5 |  |
| Total | $ | 255.4 |  |

[0001327567-24-000029:notes:142]
Goodwill generated from this business combination is primarily attributable to the assembled workforce and expected post-acquisition synergies from integrating Dig technology into our platforms. The goodwill is deductible for U.S. income tax purposes.

[0001327567-24-000029:notes:143]
The following table presents details of the identified intangible asset acquired (in millions, except years):

[0001327567-24-000029:notes:144]
|  | Fair Value |  | Estimated Useful Life |
| Developed technology | $ | 45.4 |  |  | 5 years |

[0001327567-24-000029:notes:145]
Talon Cyber Security Ltd.

[0001327567-24-000029:notes:146]
On December 28, 2023, we completed our acquisition of Talon Cyber Security Ltd. (“Talon”), a privately-held cyber security company. We expect the acquisition will support Prisma SASE’s approach to provide secure access to business applications for unmanaged and personal devices with an enterprise browser. The total purchase consideration for the acquisition of Talon was $458.6 million, which consisted of the following (in millions):

[0001327567-24-000029:notes:147]
|  | Amount |
| Cash | $ | 439.0 |  |
| Fair value of replacement awards | 19.6 |  |
| Total | $ | 458.6 |  |

[0001327567-24-000029:notes:148]
As part of the acquisition, we issued replacement equity awards, which included 0.3 million shares of our restricted common stock. The total fair value of the replacement equity awards was $109.6 million, of which the portion attributable to services performed prior to the acquisition date was allocated to purchase consideration. The remaining fair value was allocated to future services and will be expensed over the remaining service periods as share-based compensation.

[0001327567-24-000029:notes:149]
|  | Amount |
| Goodwill | $ | 236.9 |  |
| Identified intangible assets | 131.4 |  |
| Cash and restricted cash | 53.9 |  |
| Net assets acquired | 36.4 |  |
| Total | $ | 458.6 |  |

[0001327567-24-000029:notes:150]
Goodwill generated from this business combination is primarily attributable to the assembled workforce and expected post-acquisition synergies from integrating Talon technology into our platforms. The goodwill is deductible for U.S. income tax purposes.

[0001327567-24-000029:notes:151]
|  | Fair Value |  | Estimated Useful Life |
| Developed technology | $ | 131.4 |  |  | 5 years |

[0001327567-24-000029:notes:152]
Fiscal 2023

[0001327567-24-000029:notes:153]
Cider Security Ltd.

[0001327567-24-000029:notes:154]
On December 20, 2022, we completed our acquisition of Cider Security Ltd. (“Cider”), a privately-held cloud security company. We expect the acquisition will support Prisma Cloud’s platform approach to securing the entire application security lifecycle from code to cloud. The total purchase consideration for the acquisition of Cider was $198.3 million, which consisted of the following (in millions):

[0001327567-24-000029:notes:155]
|  | Amount |
| Cash | $ | 198.0 |  |
| Fair value of replacement awards | 0.3 |  |
| Total | $ | 198.3 |  |

[0001327567-24-000029:notes:156]
As part of the acquisition, we issued replacement equity awards, which included 0.2 million shares of our restricted common stock. The total fair value of the replacement equity awards was $48.6 million, of which the portion attributable to services performed prior to the acquisition date was allocated to purchase consideration. The remaining fair value was allocated to future services and will be expensed over the remaining service periods as share-based compensation.

[0001327567-24-000029:notes:157]
We have accounted for this transaction as a business combination and allocated the purchase consideration to assets acquired and liabilities assumed based on estimated fair values, as presented in the following table (in millions):

[0001327567-24-000029:notes:158]
|  | Amount |
| Goodwill | $ | 164.6 |  |
| Identified intangible assets | 27.8 |  |
| Cash | 12.4 |  |
| Net liabilities assumed | (6.5) |  |
| Total | $ | 198.3 |  |

[0001327567-24-000029:notes:159]
Goodwill generated from this business combination is primarily attributable to the assembled workforce and expected post-acquisition synergies from integrating Cider technology into our platforms. The goodwill is deductible for U.S. income tax purposes.

[0001327567-24-000029:notes:160]
The following table presents the identified intangible asset acquired (in millions, except years):

[0001327567-24-000029:notes:161]
|  | Fair Value |  | Estimated Useful Life |
| Developed technology | $ | 27.8 |  |  | 5 years |

[0001327567-24-000029:notes:162]
Other acquisition

[0001327567-24-000029:notes:163]
In April 2023, we completed an acquisition for total purchase consideration of $18.9 million in cash. We have accounted for this transaction as a business combination and recorded goodwill of $14.5 million. The goodwill is not deductible for income tax purposes.

[0001327567-24-000029:notes:164]
Fiscal 2022

[0001327567-24-000029:notes:165]
During the year ended July 31, 2022, we completed acquisitions for a combined total purchase consideration of $40.1 million, which was primarily cash. We have accounted for these transactions as business combinations, and recorded goodwill of $37.6 million. The goodwill is not deductible for income tax purposes.

[0001327567-24-000029:notes:166]
Additional Acquisition-Related Information

[0001327567-24-000029:notes:167]
Pro forma results of operations have not been presented because the effects of the acquisitions were not material to our consolidated statements of operations.

[0001327567-24-000029:notes:168]
Additional information related to our acquisitions completed in fiscal 2024, such as that related to income tax and other contingencies, existing as of the acquisition date may become known during the remainder of the measurement period, not to exceed 12 months from the respective acquisition date, which may result in changes to the amounts and allocations recorded.


## us-gaap:ScheduleOfBusinessAcquisitionsByAcquisitionTextBlock

[0001327567-24-000029:notes:169]
The total purchase consideration for the acquisition of Dig was $255.4 million, which consisted of the following (in millions):

[0001327567-24-000029:notes:170]
The total purchase consideration for the acquisition of Talon was $458.6 million, which consisted of the following (in millions):

[0001327567-24-000029:notes:171]
The total purchase consideration for the acquisition of Cider was $198.3 million, which consisted of the following (in millions):


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001327567-24-000029:notes:172]
Goodwill and Intangible Assets
Goodwill

[0001327567-24-000029:notes:173]
The following table presents details of our goodwill during the year ended July 31, 2024 (in millions):

[0001327567-24-000029:notes:174]
|  | Amount |
| Balance as of July 31, 2023 | $ | 2,926.8 |  |
| Goodwill acquired | 423.3 |  |
| Balance as of July 31, 2024 | $ | 3,350.1 |  |

[0001327567-24-000029:notes:175]
Purchased Intangible Assets

[0001327567-24-000029:notes:176]
The following table presents details of our purchased intangible assets (in millions):

[0001327567-24-000029:notes:177]
|  | July 31, |
|  | 2024 |  | 2023 |
|  | Gross Carrying Amount |  | Accumulated Amortization |  | Net Carrying Amount |  | Gross Carrying Amount |  | Accumulated Amortization |  | Net Carrying Amount |
| Intangible assets subject to amortization: |  |  |  |  |  |  |  |  |  |  |  |
| Developed technology | $ | 813.9 |  |  | $ | (526.2) |  |  | $ | 287.7 |  |  | $ | 633.2 |  |  | $ | (429.4) |  |  | $ | 203.8 |  |
| Customer relationships | 172.7 |  |  | (96.1) |  |  | 76.6 |  |  | 172.7 |  |  | (73.9) |  |  | 98.8 |  |
| Acquired intellectual property | 18.2 |  |  | (7.9) |  |  | 10.3 |  |  | 14.6 |  |  | (6.2) |  |  | 8.4 |  |
| Trade name and trademarks | 9.4 |  |  | (9.4) |  |  | — |  |  | 9.4 |  |  | (9.4) |  |  | — |  |
| Other | 0.9 |  |  | (0.6) |  |  | 0.3 |  |  | 0.9 |  |  | (0.4) |  |  | 0.5 |  |
| Total intangible assets subject to amortization | 1,015.1 |  |  | (640.2) |  |  | 374.9 |  |  | 830.8 |  |  | (519.3) |  |  | 311.5 |  |
| Intangible assets not subject to amortization: |  |  |  |  |  |  |  |  |  |  |  |
| In-process research and development | — |  | — |  |  | — |  |  | 3.9 |  | — |  |  | 3.9 |  |
| Total purchased intangible assets | $ | 1,015.1 |  |  | $ | (640.2) |  |  | $ | 374.9 |  |  | $ | 834.7 |  |  | $ | (519.3) |  |  | $ | 315.4 |  |

[0001327567-24-000029:notes:178]
We recognized amortization expense of $120.9 million, $104.9 million, and $126.9 million for the years ended July 31, 2024, 2023, and 2022, respectively.

[0001327567-24-000029:notes:179]
The following table summarizes estimated future amortization expense of our intangible assets subject to amortization as of July 31, 2024 (in millions):

[0001327567-24-000029:notes:180]
|  |  |  | Fiscal years ending July 31, |
|  | Total |  | 2025 |  | 2026 |  | 2027 |  | 2028 |  | 2029 |  | 2030 and Thereafter |
| Future amortization expense | $ | 374.9 |  |  | $ | 120.6 |  |  | $ | 98.8 |  |  | $ | 71.8 |  |  | $ | 50.2 |  |  | $ | 24.2 |  |  | $ | 9.3 |  |


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001327567-24-000029:notes:181]
Property and Equipment
The following table presents details of our property and equipment, net (in millions):

[0001327567-24-000029:notes:182]
|  | July 31, |
|  | 2024 |  | 2023 |
| Computers, equipment, and software | $ | 466.0 |  |  | $ | 432.9 |  |
| Leasehold improvements | 274.0 |  |  | 268.9 |  |
| Land | 87.2 |  |  | 87.2 |  |
| Demonstration units | 44.4 |  |  | 46.9 |  |
| Furniture and fixtures | 48.7 |  |  | 46.9 |  |
| Total property and equipment, gross | 920.3 |  |  | 882.8 |  |
| Less: accumulated depreciation | (559.2) |  |  | (528.3) |  |
| Total property and equipment, net | $ | 361.1 |  |  | $ | 354.5 |  |

[0001327567-24-000029:notes:183]
We recognized depreciation expense of $85.1 million, $95.9 million, and $92.8 million related to property and equipment during the years ended July 31, 2024, 2023, and 2022, respectively.


## us-gaap:DebtDisclosureTextBlock

[0001327567-24-000029:notes:184]
Debt
Convertible Senior Notes

[0001327567-24-000029:notes:185]
In July 2018, we issued $1.7 billion aggregate principal amount of 0.75% Convertible Senior Notes due 2023 (the “2023 Notes”) and in June 2020, we issued $2.0 billion aggregate principal amount of 0.375% Convertible Senior Notes due 2025 (the “2025 Notes,” and together with the 2023 Notes, the “Notes”). The 2023 Notes bear interest at a fixed rate of 0.75% per year, payable semi-annually in arrears on January 1 and July 1 of each year, beginning on January 1, 2019. The 2023 Notes were converted prior to or settled on the maturity date of July 1, 2023 in accordance with their terms. The 2025 Notes bear interest at a fixed rate of 0.375% per year, payable semi-annually in arrears on June 1 and December 1 of each year, beginning on December 1, 2020. The 2025 Notes are governed by an indenture between us, as the issuer, and U.S. Bank National Association, as Trustee (the “Indenture”). The 2025 Notes are unsecured, unsubordinated obligations and the Indenture governing the 2025 Notes does not contain any financial covenants or restrictions on the payments of dividends, the incurrence of indebtedness, or the issuance or repurchase of securities by us or any of our subsidiaries. The 2025 Notes mature on June 1, 2025. We may redeem for cash all or any portion of the 2025 Notes, at our option, on or after June 5, 2023 and prior to the 31st scheduled trading day immediately preceding the maturity date if the last reported sale price of our common stock has been at least 130% of the conversion price then in effect for at least 20 trading days during any 30 consecutive trading day period ending on and including the trading day preceding the date on which we provide notice of redemption. The redemption will be at a price equal to 100% of the principal amount of the 2025 Notes and adjusted for interest. If we call any or all of the 2025 Notes for redemption, holders may convert such 2025 Notes called for redemption at any time prior to the close of business on the second scheduled trading day immediately preceding the redemption date.

[0001327567-24-000029:notes:186]
The following table presents details of our Notes (number of shares in millions):

[0001327567-24-000029:notes:187]
|  | Conversion Rate per $1,000 Principal |  | Initial Conversion Price |  | Convertible Date |  | Initial Number of Shares |
| 2023 Notes(1) | 11.2635 |  |  | $ | 88.78 |  |  | April 1, 2023 |  | 19.1 |  |
| 2025 Notes | 10.0806 |  |  | $ | 99.20 |  |  | March 1, 2025 |  | 20.1 |  |

[0001327567-24-000029:notes:188]
(1)The 2023 Notes were converted prior to or settled on the maturity date of July 1, 2023.

[0001327567-24-000029:notes:189]
Holders of the 2025 Notes may surrender their 2025 Notes for conversion at their option at any time prior to the close of business on the business day immediately preceding March 1, 2025 only under the following circumstances:

[0001327567-24-000029:notes:190]
•during any fiscal quarter commencing after the fiscal quarter ending on October 31, 2020 (and only during such fiscal quarter), if the last reported sale price of our common stock for at least 20 trading days (whether or not consecutive) during a period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the conversion price for the 2025 Notes on each applicable trading day (the “sale price condition”);

[0001327567-24-000029:notes:191]
•during the five business day period after any five consecutive trading day period (the “measurement period”) in which the trading price per $1,000 principal amount of the 2025 Notes for each trading day of the measurement period was less than 98% of the product of the last reported sale price of our common stock and the conversion rate for the 2025 Notes on each such trading day; or

[0001327567-24-000029:notes:192]
•upon the occurrence of specified corporate events.

[0001327567-24-000029:notes:193]
On or after March 1, 2025, holders may surrender all or any portion of their 2025 Notes for conversion at any time prior to the close of business on the second scheduled trading day immediately preceding the maturity date regardless of the foregoing conditions, and such conversions will be settled upon the maturity date. Upon conversion, holders of the 2025 Notes will receive cash equal to the aggregate principal amount of the 2025 Notes to be converted, and, at our election, cash and/or shares of our common stock for any amounts in excess of the aggregate principal amount of the 2025 Notes being converted.

[0001327567-24-000029:notes:194]
The conversion price will be subject to adjustment in some events. Holders of the 2025 Notes who convert their 2025 Notes in connection with certain corporate events that constitute a “make-whole fundamental change” under the Indenture are, under certain circumstances, entitled to an increase in the conversion rate. Additionally, upon the occurrence of a corporate event that constitutes a “fundamental change” under the Indenture, holders of the 2025 Notes may require us to repurchase for cash all or a portion of the 2025 Notes at a repurchase price equal to 100% of the principal amount of the 2025 Notes plus accrued and unpaid interest to, but excluding, the fundamental change repurchase date.

[0001327567-24-000029:notes:195]
Holders of the 2023 Notes were able to early convert their 2023 Notes in fiscal 2023 up to April 1, 2023 as the sales price condition had been met. Conversion requests for the 2023 Notes received on or after April 1, 2023 were settled upon maturity of the 2023 Notes. Holders of the 2025 Notes were able to early convert their 2025 Notes in fiscal 2024 and 2023 as the sales price condition was met. During the years ended July 31, 2024 and 2023, holders of the Notes converted $1.0 billion and $1.7 billion, respectively, in aggregate principal amount of the Notes, which we repaid in cash. We also issued 7.0 million and 11.4 million shares of our common stock to the holders of the Notes during the years ended July 31, 2024 and 2023, respectively, for the conversion value in excess of the principal amount. These shares were fully offset by shares we received from the corresponding exercise of the associated note hedges. Refer to Note 19. Subsequent Events for additional information regarding conversion of the 2025 Notes after July 31, 2024 through the filing date of this Annual Report on Form 10-K.

[0001327567-24-000029:notes:196]
The sale price condition for the 2025 Notes was met during the fiscal quarters ended July 31, 2024 and 2023, and as a result, holders have the option to convert their 2025 Notes in the fiscal quarter commencing after July 31, 2024 and 2023, respectively. The net carrying amount of the 2025 Notes was classified as a current liability on our consolidated balance sheet as of July 31, 2024 and 2023.

[0001327567-24-000029:notes:197]
The following table sets forth the net carrying amount of our 2025 Notes (in millions):

[0001327567-24-000029:notes:198]
|  | July 31, 2024 |  | July 31, 2023 |
| Principal | $ | 965.6 |  |  | $ | 1,999.3 |  |
| Less: debt issuance costs, net of amortization | (1.7) |  |  | (7.8) |  |
| Net carrying amount | $ | 963.9 |  |  | $ | 1,991.5 |  |

[0001327567-24-000029:notes:199]
The total estimated fair value of the 2025 Notes was $3.2 billion and $5.0 billion as of July 31, 2024 and 2023, respectively. The fair value was determined based on the closing trading price per $100 of the 2025 Notes as of the last day of trading for the period. We consider the fair value of the 2025 Notes at July 31, 2024 and 2023 to be a Level 2 measurement. The fair value of the 2025 Notes is primarily affected by the trading price of our common stock and market interest rates.

[0001327567-24-000029:notes:200]
The following table sets forth interest expense recognized related to the Notes (dollars in millions):

[0001327567-24-000029:notes:201]
|  | Year Ended July 31, 2024 |  | Year Ended July 31, 2023 |  | Year Ended July 31, 2022 |
|  | 2023 Notes |  | 2025 Notes |  | Total |  | 2023 Notes |  | 2025 Notes |  | Total |  | 2023 Notes |  | 2025 Notes |  | Total |
| Contractual interest expense | $ | — |  |  | $ | 4.8 |  |  | $ | 4.8 |  |  | $ | 11.6 |  |  | $ | 7.5 |  |  | $ | 19.1 |  |  | $ | 12.7 |  |  | $ | 7.5 |  |  | $ | 20.2 |  |
| Amortization of debt issuance costs | — |  |  | 3.5 |  |  | 3.5 |  |  | 2.6 |  |  | 4.1 |  |  | 6.7 |  |  | 2.8 |  |  | 4.4 |  |  | 7.2 |  |
| Total interest expense recognized | $ | — |  |  | $ | 8.3 |  |  | $ | 8.3 |  |  | $ | 14.2 |  |  | $ | 11.6 |  |  | $ | 25.8 |  |  | $ | 15.5 |  |  | $ | 11.9 |  |  | $ | 27.4 |  |
| Effective interest rate of the liability component | — | % |  | 0.6 | % |  |  |  | 0.9 | % |  | 0.6 | % |  |  |  | 0.9 | % |  | 0.6 | % |  |  |

[0001327567-24-000029:notes:202]
Note Hedges

[0001327567-24-000029:notes:203]
To minimize the impact of potential economic dilution upon conversion of our convertible senior notes, we entered into separate convertible note hedge transactions (the “2023 Note Hedges,” with respect to the 2023 Notes, the “2025 Note Hedges,” with respect to the 2025 Notes, and the 2023 Note Hedges together with 2025 Note Hedges, the “Note Hedges”) with respect to our common stock concurrent with the issuance of each series of the Notes.

[0001327567-24-000029:notes:204]
The following table presents details of our Note Hedges (in millions):

[0001327567-24-000029:notes:205]
|  | Initial Number of Shares |  | Aggregate Purchase |
| 2023 Note Hedges(1) | 19.1 |  |  | $ | 332.0 |  |
| 2025 Note Hedges | 20.1 |  |  | $ | 370.8 |  |

[0001327567-24-000029:notes:206]
(1)The 2023 Note Hedges were settled as a result of the conversions of the 2023 Notes prior to or on July 1, 2023.

[0001327567-24-000029:notes:207]
The Note Hedges cover shares of our common stock at a strike price per share that corresponds to the initial applicable conversion price of the applicable series of the Notes, which are also subject to adjustment, and are exercisable upon conversion of the applicable series of the Notes. The Note Hedges will expire upon maturity of the applicable series of the Notes. The Note Hedges are separate transactions and are not part of the terms of the applicable series of the Notes. Holders of the Notes of either series will not have any rights with respect to the Note Hedges. Any shares of our common stock receivable by us under the Note Hedges are excluded from the calculation of diluted earnings per share as they are antidilutive. The aggregate amounts paid for the Note Hedges are included in additional paid-in capital on our consolidated balance sheets.

[0001327567-24-000029:notes:208]
As a result of the conversions of the Notes settled during the years ended July 31, 2024 and 2023, we exercised the corresponding portion of our Note Hedges and received 7.0 million and 11.4 million shares of our common stock during the respective periods.

[0001327567-24-000029:notes:209]
Warrants

[0001327567-24-000029:notes:210]
Separately, but concurrently with the issuance of each series of our convertible senior notes, we entered into transactions whereby we sold warrants (the “2023 Warrants,” with respect to the 2023 Notes, the “2025 Warrants,” with respect to the 2025 Notes, and the 2023 Warrants together with the 2025 Warrants, the “Warrants”) to acquire shares of our common stock, subject to anti-dilution adjustments. The 2023 Warrants and 2025 Warrants are exercisable over 60 scheduled trading days beginning October 2023 and September 2025, respectively.

[0001327567-24-000029:notes:211]
The following table presents details of our Warrants (in millions, except per share data):

[0001327567-24-000029:notes:212]
|  | Initial Number of Shares |  | Strike Price per Share |  | Aggregate Proceeds |
| 2023 Warrants | 19.1 |  |  | $ | 139.27 |  |  | $ | 145.4 |  |
| 2025 Warrants | 20.1 |  |  | $ | 136.16 |  |  | $ | 202.8 |  |

[0001327567-24-000029:notes:213]
The shares issuable under the Warrants are included in the calculation of diluted earnings per share when the average market value per share of our common stock for the reporting period exceeds the applicable strike price for such series of Warrants. The Warrants are separate transactions and are not part of either series of Notes or Note Hedges and are not remeasured through earnings each reporting period. Holders of the Notes of either series will not have any rights with respect to the Warrants. The aggregate proceeds received from the sale of the Warrants are included in additional paid-in capital on our consolidated balance sheets.

[0001327567-24-000029:notes:214]
During the year ended July 31, 2024, we net settled all of the 2023 Warrants with 9.0 million shares of our common stock with a fair value of $2.4 billion. The number of net shares issued was determined based on the number of 2023 Warrants exercised multiplied by the difference between the strike price of the 2023 Warrants and their daily volume-weighted-average stock price.

[0001327567-24-000029:notes:215]
Revolving Credit Facility

[0001327567-24-000029:notes:216]
On September 4, 2018, we entered into a credit agreement (the “2018 Credit Agreement”) with certain institutional lenders that provides for a $400.0 million unsecured revolving credit facility (the “2018 Credit Facility”), with an option to increase the amount of the 2018 Credit Facility by up to an additional $350.0 million, subject to certain conditions. The 2018 Credit Facility expired in April 2023.

[0001327567-24-000029:notes:217]
On April 13, 2023, we entered into a new credit agreement (the “2023 Credit Agreement”) with certain institutional lenders that provides for a $400.0 million unsecured revolving credit facility (the “2023 Credit Facility”), with an option to increase the amount by up to an additional $350.0 million, subject to certain conditions. The 2023 Credit Facility matures on April 13, 2028.

[0001327567-24-000029:notes:218]
The borrowings under the 2023 Credit Facility bear interest, at our option, at a base rate plus a spread of 0.000% to 0.375%, or an adjusted term Secured Overnight Financing Rate plus a spread of 1.000% to 1.375%, in each case with such spread being determined based on our leverage ratio. We are obligated to pay an ongoing commitment fee on undrawn amounts at a rate of 0.090% to 0.150%, depending on our leverage ratio. The interest rates and commitment fees are also subject to upward and downward adjustments based on our progress towards the achievement of certain sustainability goals related to greenhouse gas emissions.

[0001327567-24-000029:notes:219]
As of July 31, 2024, there were no amounts outstanding and we were in compliance with all covenants under the 2023 Credit Agreement.


## us-gaap:LesseeOperatingLeasesTextBlock

[0001327567-24-000029:notes:220]
Leases
We have entered into various non-cancelable operating leases, primarily for our offices and data centers, with lease terms expiring through the year ending July 31, 2036. Some of our leases contain rent holiday periods, scheduled rent increases, lease incentives, early termination rights, and/or renewal options.

[0001327567-24-000029:notes:221]
During the years ended July 31, 2024, 2023, and 2022, our net cost for operating leases was $104.7 million, $91.3 million, and $89.7 million, respectively, primarily consisting of operating lease costs of $75.6 million, $64.2 million, and $67.6 million, respectively. Our net cost for operating leases also included variable lease costs, short-term lease costs, and sublease income in the periods presented.

[0001327567-24-000029:notes:222]
The following tables present additional information for our operating leases (in millions, except for years and percentages):

[0001327567-24-000029:notes:223]
|  | Year Ended July 31, |  |  |  |  |  |  |
|  | 2024 |  | 2023 |  | 2022 |  |  |  |  |  |  |
| Operating cash flows used in payments of operating lease liabilities | $ | 87.4 |  |  | $ | 82.7 |  |  | $ | 81.5 |  |  |  |  |  |  |  |
| Right-of-use assets obtained in exchange for new operating lease liabilities | $ | 177.9 |  |  | $ | 71.1 |  |  | $ | 33.0 |  |  |  |  |  |  |  |

[0001327567-24-000029:notes:224]
|  | July 31, 2024 |  | July 31, 2023 |  |  |  |  |  |  |
| Weighted-average remaining lease term | 6.6 years |  | 5.7 years |  |  |  |  |  |  |
| Weighted-average discount rate | 5.3 | % |  | 4.7 | % |  |  |  |  |  |  |

[0001327567-24-000029:notes:225]
The following table presents maturities of operating lease liabilities as of July 31, 2024 (in millions):

[0001327567-24-000029:notes:226]
|  | Amount |
| Fiscal years ending July 31: |  |
| 2025 | $ | 84.8 |  |
| 2026 | 91.9 |  |
| 2027 | 88.0 |  |
| 2028 | 87.5 |  |
| 2029 | 42.4 |  |
| 2030 and thereafter | 144.2 |  |
| Total operating lease payments | 538.8 |  |
| Less: imputed interest | (92.4) |  |
| Present value of operating lease liabilities | $ | 446.4 |  |
| Current portion of operating lease liabilities(1) | $ | 65.9 |  |
| Long-term operating lease liabilities | $ | 380.5 |  |

[0001327567-24-000029:notes:227]
(1)Current portion of operating lease liabilities is included in accrued and other liabilities on our consolidated balance sheet.

[0001327567-24-000029:notes:228]
As of July 31, 2024, we had additional non-cancelable operating leases for office space that had been signed but had not yet commenced with total future minimum lease payments of $32.7 million. These leases are expected to commence on or after fiscal 2025, with lease terms ranging from four to eight years.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001327567-24-000029:notes:229]
Commitments and Contingencies 
Purchase Commitments

[0001327567-24-000029:notes:230]
We have entered into various non-cancelable agreements with cloud service providers, under which we are committed to minimum or fixed purchases of certain cloud services. In addition, in order to reduce manufacturing lead times and plan for adequate supply, we have entered into agreements with manufacturing partners and component suppliers to procure inventory based on our demand forecasts. The following table presents details of the aggregate future non-cancelable purchase commitments under these agreements as of July 31, 2024 (in millions):

[0001327567-24-000029:notes:231]
|  |  |  | Fiscal years ending July 31, |
|  | Total |  | 2025 |  | 2026 |  | 2027 |  | 2028 |  | 2029 |  | 2030 and Thereafter |  |  |
| Cloud | $ | 4,275.7 |  |  | $ | 98.9 |  |  | $ | 580.2 |  |  | $ | 518.1 |  |  | $ | 599.6 |  |  | $ | 686.1 |  |  | $ | 1,792.8 |  |  |  |
| Manufacturing | 266.0 |  |  | 226.0 |  |  | 40.0 |  |  | — |  |  | — |  |  | — |  |  | — |  |  |  |
| Other | 135.2 |  |  | 46.7 |  |  | 42.5 |  |  | 32.3 |  |  | 6.8 |  |  | 3.4 |  |  | 3.5 |  |  |  |
| Total purchase commitments | $ | 4,676.9 |  |  | $ | 371.6 |  |  | $ | 662.7 |  |  | $ | 550.4 |  |  | $ | 606.4 |  |  | $ | 689.5 |  |  | $ | 1,796.3 |  |  |  |

[0001327567-24-000029:notes:232]
Additionally, we have a $141.2 million minimum purchase commitment with a cloud service provider through September 2027 with no specified annual commitments.

[0001327567-24-000029:notes:233]
Mutual Covenant Not to Sue and Release Agreement

[0001327567-24-000029:notes:234]
In January 2020, we executed a Mutual Covenant Not to Sue and Release Agreement for $50.0 million to extend an existing covenant not to sue for seven years. As the primary benefit of the arrangement was attributable to future use, the amount was recorded in other assets on our consolidated balance sheets and is amortized to cost of product revenue on our consolidated statements of operations over the estimated period of benefit of seven years.

[0001327567-24-000029:notes:235]
Guarantee

[0001327567-24-000029:notes:236]
In October 2023, we established a multi-currency notional cash pool for a certain number of our entities with a third-party bank. As part of the notional cash pool agreement, the bank extends overdraft credit to our participating entities as needed, provided that the overall notionally pooled balance of all accounts in the pool at the end of each day is positive. In the unlikely event of a default, any overdraft balances incurred would be guaranteed by our collective entities participating in the pool.

[0001327567-24-000029:notes:237]
Litigation

[0001327567-24-000029:notes:238]
We are subject to legal proceedings, claims, tax matters, and litigation arising in the ordinary course of business, including, for instance, intellectual property and patent litigation. We accrue for contingencies when we believe that a loss is probable and that we can reasonably estimate the amount of any such loss.

[0001327567-24-000029:notes:239]
Legal matters could include speculative, substantial or indeterminate monetary amounts. Significant judgment is required to determine both the likelihood of there being a loss and the estimated amount of a loss related to such matters, and we may be unable to estimate the reasonably possible loss or range of loss. The outcomes of outstanding legal matters are inherently unpredictable, and could, either individually or in aggregate, have a material adverse effect on us and our results of operations. To the extent there is a reasonable possibility that a loss exceeding any amounts already recognized may be incurred, we will either disclose the estimated additional loss or state that such an estimate cannot be made.

[0001327567-24-000029:notes:240]
The following matters arose in the ordinary course of business.

[0001327567-24-000029:notes:241]
Centripetal Networks, Inc. v. Palo Alto Networks

[0001327567-24-000029:notes:242]
On March 12, 2021, Centripetal Networks, Inc., filed a lawsuit against us in the United States District Court for the Eastern District of Virginia. The lawsuit alleges that our products infringe multiple Centripetal patents. We successfully challenged certain of these patents, which were found unpatentable by the U.S. Patent and Trademark Office (“PTO”). The case went to jury trial on January 22, 2024, on four patents. On January 31, 2024, the jury returned a verdict of non-willful infringement with a lump sum amount of $151.5 million, plus statutory interest. We have filed motions to overturn the verdict and seek a new trial, which are pending before the court. Three patents are still pending review in the PTO and are currently subject to a stay at the trial court. In addition, Centripetal filed infringement contentions on certain of their patents in the European Patent Office in Germany, to which we filed invalidity challenges. Those matters are still pending.

[0001327567-24-000029:notes:243]
As of July 31, 2024, we accrued $184.4 million for the verdict amount and estimated interest. The accrual is recorded in other long-term liabilities on our consolidated balance sheets with the corresponding charge included in general and administrative expense on our consolidated statements of operations for the year ended July 31, 2024.

[0001327567-24-000029:notes:244]
Finjan, Inc. v. Palo Alto Networks

[0001327567-24-000029:notes:245]
On November 4, 2014, Finjan, Inc., filed a lawsuit against us in the United States District Court for the Northern District of California. The lawsuit alleges that our products infringe multiple Finjan patents. The complaint requests injunctive relief, monetary damages, and attorneys fees. A trial date is set for June 9, 2025. We are unable, at this time, to reasonably estimate a possible loss or potential range of loss, if any.

[0001327567-24-000029:notes:246]
Taasera v. Palo Alto Networks

[0001327567-24-000029:notes:247]
On March 22, 2022, we filed a declaratory judgment action in the United States District Court for the Southern District of New York seeking a ruling that we are not infringing various Taasera patents. The parties have resolved all pending matters between them as of December 2023. The amounts paid by us to resolve these matters were not material.

[0001327567-24-000029:notes:248]
Lionra Technologies v. Palo Alto Networks

[0001327567-24-000029:notes:249]
On August 29, 2022, Lionra Technologies filed a patent infringement lawsuit against us in the United States District Court for the Eastern District of Texas. The parties have resolved all pending matters between them as of July 2024. The amounts paid by us to resolve these matters were not material.

[0001327567-24-000029:notes:250]
Indemnification

[0001327567-24-000029:notes:251]
Under the indemnification provisions of our standard sales related contracts, we agree to defend our end-customers against third-party claims asserting infringement of certain intellectual property rights, which may include patents, copyrights, trademarks, or trade secrets, and to pay judgments or approved settlements attributable to such claims. Our exposure under these indemnification provisions is generally limited to payments made to us for the alleged infringing products over the preceding twelve months under the agreement. However, certain agreements include indemnification provisions that could potentially expose us to losses in excess of these payments. In addition, we indemnify our officers, directors, and certain key employees while they are serving in good faith in their company capacities. To date, we have not recorded any accruals for loss contingencies associated with indemnification claims or determined that an unfavorable outcome is probable or reasonably possible.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001327567-24-000029:notes:252]
Stockholders’ Equity
Share Repurchase Program

[0001327567-24-000029:notes:253]
In February 2019, our board of directors authorized a $1.0 billion share repurchase program, which is funded from available working capital. In December 2020, August 2021, August 2022, and November 2023, our board of directors authorized additional $700.0 million, $676.1 million, $915.0 million and $316.7 million increases to this share repurchase program, respectively, bringing the total authorization under this share repurchase program to $3.6 billion (our “current authorization”). The expiration date of our current authorization was extended to December 31, 2024, and our repurchase program may be suspended or discontinued at any time. Repurchases may be made at management’s discretion from time to time on the open market, through privately negotiated transactions, transactions structured through investment banking institutions, block purchase techniques, 10b5-1 trading plans, or a combination of the foregoing. Refer to Note 19. Subsequent Events for additional information regarding the increase to our share repurchase program in August 2024.

[0001327567-24-000029:notes:254]
The following table summarizes the share repurchase activity under our share repurchase program (in millions, except per share amounts):

[0001327567-24-000029:notes:255]
|  | Year Ended July 31, |
|  | 2024 |  | 2023 |  | 2022 |
| Number of shares repurchased | 2.0 |  |  | 1.8 |  |  | 5.4 |  |
| Weighted-average price per share (1) | $ | 284.00 |  |  | $ | 138.65 |  |  | $ | 170.83 |  |
| Aggregate purchase price (1) | $ | 566.7 |  |  | $ | 250.0 |  |  | $ | 915.0 |  |

[0001327567-24-000029:notes:256]
(1)Includes transaction costs

[0001327567-24-000029:notes:257]
During the year ended July 31, 2023, we paid $22.7 million related to share repurchases of our common stock that were not settled as of July 31, 2022.

[0001327567-24-000029:notes:258]
As of July 31, 2024, $500.0 million remained available for future share repurchases under our current repurchase authorization. The total price of the shares repurchased and related transaction costs are reflected as a reduction to common stock and additional paid-in capital on our consolidated balance sheets.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001327567-24-000029:notes:259]
Equity Award Plans
Share-Based Compensation Plans

[0001327567-24-000029:notes:260]
Equity Incentive Plans

[0001327567-24-000029:notes:261]
Our 2021 Equity Incentive Plan (our “2021 Plan”) became effective in December 2021 and replaced our 2012 Equity Incentive Plan (our “2012 Plan”). Our 2021 Plan provides for the granting of stock options, stock appreciation rights, restricted stock awards (“RSAs”), restricted stock units (“RSUs”), performance shares (“PSAs”), performance-based stock units (“PSUs”) and performance stock options (“PSOs”) to our employees, directors, and consultants. Upon effectiveness of the 2021 Plan, the 2012 Plan was terminated and no further awards will be granted under the 2012 Plan. Awards that were outstanding upon such termination remained outstanding pursuant to their original terms, and any subsequent expiration, cancellation or forfeiture of awards under our 2012 Plan are returned to our 2021 Plan.

[0001327567-24-000029:notes:262]
The majority of our equity awards are RSUs, which generally vest over a period of three to four years from the date of grant. Until vested, RSUs do not have the voting and dividend participation rights of common stock and the shares underlying the awards are not considered issued and outstanding.

[0001327567-24-000029:notes:263]
Our PSUs generally vest over a period of one to four years from the date of grant. The number of PSUs eligible to vest is determined based on the level of achievement against certain performance conditions, market conditions, and a combination thereof.

[0001327567-24-000029:notes:264]
During the year ended July 31, 2023, we granted 0.9 million shares of PSUs with both service and market conditions. The market conditions are satisfied when the price of our common stock is equal to or exceeds stock price targets of $233.33, $266.67, $300.00, and $333.33 based on the average closing price for 30 consecutive trading days during the three- or four-year period following the date of grant. Once a market condition is met, its corresponding one-fourth of the awards vest on each anniversary date of the grant date, subject to continued service. As of July 31, 2024, all stock price targets for these PSU awards have been met, and the related shares will vest when the underlying service conditions are satisfied.

[0001327567-24-000029:notes:265]
During the year ended July 31, 2023, we granted 0.8 million shares of PSUs, which contain service and market conditions. The service conditions are satisfied after a period of five years. The market condition is measured based on our total shareholder return (“TSR”) relative to the TSR of the companies listed in the Standard & Poor’s 500 index.

[0001327567-24-000029:notes:266]
During the years ended July 31, 2024 and 2023, we granted 2.1 million and 1.6 million shares of PSUs, respectively, which contain service, performance and market conditions. The service conditions are satisfied after a period of one to three years. The performance conditions are based on revenue growth or billing growth. The market condition is measured based on our TSR relative to the TSR of the companies listed in the Standard & Poor’s 500 index. As of July 31, 2024, we have approved an additional 2.7 million shares of PSUs, which will be granted upon the performance condition being established during the next two years.

[0001327567-24-000029:notes:267]
We have also granted PSOs with both service and market conditions. The market condition for PSOs granted in the fiscal years 2018 and 2019 requires the price of our common stock to equal or exceed $99.25, $132.33, $165.42, and $198.50 based on the average closing price for 30 consecutive trading days during the four-, five-, six-, and seven-and-a-half-year periods following the date of grant in fiscal year 2018 and 2019, respectively. Once a market condition is met, its corresponding one-fourth of the PSOs vest on each anniversary date of the grant date, subject to continued service. The maximum contractual term of our outstanding PSOs is seven and a half years from the date of grant, depending on vesting period. As of July 31, 2024, all of our outstanding PSOs have been fully vested.

[0001327567-24-000029:notes:268]
We net-share settle equity awards held by certain employees by withholding shares upon vesting to satisfy tax withholding obligations. The shares withheld to satisfy employee tax withholding obligations are returned to our 2021 Plan and will be available for future issuance. Payments for employees’ tax obligations to the tax authorities are recognized as a reduction to additional paid-in capital and reflected as financing activities on our consolidated statements of cash flows.

[0001327567-24-000029:notes:269]
A total of 32.8 million shares of our common stock are reserved for issuance pursuant to our equity incentive plans as of July 31, 2024.

[0001327567-24-000029:notes:270]
2012 Employee Stock Purchase Plan

[0001327567-24-000029:notes:271]
Our 2012 Employee Stock Purchase Plan was adopted by our board of directors and approved by the stockholders on June 5, 2012, and was effective upon completion of our initial public offering. On August 29, 2017, we amended and restated our 2012 Employee Stock Purchase Plan (our “2012 ESPP”) to extend the length of our offering periods from 6 to 24 months.

[0001327567-24-000029:notes:272]
Our 2012 ESPP permits eligible employees to acquire shares of our common stock at 85% of the lower of the fair market value of our common stock on the first trading day of each offering period or on the purchase date. If the fair market value of our common stock on the purchase date is lower than the first trading day of the offering period, the current offering period will be cancelled after purchase and a new 24-month offering period will begin. Under our 2012 ESPP, each 24-month offering period consists of four consecutive 6-month purchase periods, with purchase dates on the first trading day on or after February 28 and August 31 of each year. Participants may purchase shares of common stock through payroll deductions of up to 15% of their eligible compensation, subject to purchase limits of 1,875 shares per six-month purchase period and $25,000 worth of stock for each calendar year. Shares purchased under our 2012 ESPP during the fiscal years ended July 31, 2024, 2023 and 2022 were 1.1 million, 1.2 million and 2.1 million, at an average exercise price of $160.63 per share, $138.30 per share, and $64.27 per share, respectively.

[0001327567-24-000029:notes:273]
A total of 18.4 million shares of our common stock are available for sale under our 2012 ESPP as of July 31, 2024. On the first day of each fiscal year, the number of shares in the reserve may be increased by the lesser of (i) 6,000,000 shares, (ii) 1% of the outstanding shares of our common stock on the first day of the fiscal year, or (iii) such other amount as determined by our board of directors.

[0001327567-24-000029:notes:274]
Assumed Share-Based Compensation Plans

[0001327567-24-000029:notes:275]
In connection with our acquisitions, we have assumed equity incentive plans of certain acquired companies (collectively “the Assumed Plans”). The equity awards assumed in connection with each acquisition were granted from their respective assumed plans. The assumed equity awards will be settled in shares of our common stock and will retain the terms and conditions under which they were originally granted. No additional equity awards will be granted under and forfeited awards will not be returned to the Assumed Plans. Refer to Note 7. Acquisitions for more information on our acquisitions and the related equity awards assumed.

[0001327567-24-000029:notes:276]
Stock Option Activities

[0001327567-24-000029:notes:277]
The following table summarizes the stock option and PSO activity under our stock plans during the years ended July 31, 2024, 2023, and 2022 (in millions, except per share amounts):

[0001327567-24-000029:notes:278]
|  | Stock Options Outstanding |  | PSOs Outstanding |
|  | Number of Shares |  | Weighted-Average Exercise Price Per Share |  | Weighted-Average Remaining Contractual Term(Years) |  | Aggregate Intrinsic Value |  | Number of Shares |  | Weighted-Average Exercise Price Per Share |  | Weighted-Average Remaining Contractual Term(Years) |  | Aggregate Intrinsic Value |
| Balance—July 31, 2021 | 0.2 |  |  | $ | 8.74 |  |  | 0.8 |  | $ | 27.4 |  |  | 8.3 |  |  | $ | 64.71 |  |  | 4.2 |  | $ | 566.8 |  |
| Exercised | (0.2) |  |  | 6.24 |  |  |  |  |  |  | — |  |  | — |  |  |  |  |  |
| Forfeited | — |  |  | — |  |  |  |  |  |  | (0.3) |  |  | 61.41 |  |  |  |  |  |
| Balance—July 31, 2022 | 0.0 |  |  | $ | 18.45 |  |  | 0.5 |  | $ | 6.7 |  |  | 8.0 |  |  | $ | 64.85 |  |  | 3.2 |  | $ | 809.3 |  |
| Exercised | 0.0 |  |  | 18.45 |  |  |  |  |  |  | (1.6) |  |  | 63.39 |  |  |  |  |  |
| Balance—July 31, 2023 | — |  |  | $ | — |  |  | 0.0 |  | $ | — |  |  | 6.4 |  |  | $ | 65.20 |  |  | 2.2 |  | $ | 1,184.6 |  |
| Exercised | — |  |  | — |  |  |  |  |  |  | (1.6) |  |  | 64.84 |  |  |  |  |  |
| Balance—July 31, 2024 | — |  |  | $ | — |  |  | 0.0 |  | $ | — |  |  | 4.8 |  |  | $ | 65.33 |  |  | 1.2 |  | $ | 1,244.9 |  |
| Exercisable—July 31, 2024 | — |  |  | $ | — |  |  | 0.0 |  | $ | — |  |  | 4.8 |  |  | $ | 65.33 |  |  | 1.2 |  | $ | 1,244.9 |  |

[0001327567-24-000029:notes:279]
The intrinsic value of options exercised during the years ended July 31, 2024, 2023, and 2022 was $358.5 million, $237.7 million, and $29.2 million, respectively.

[0001327567-24-000029:notes:280]
RSU and PSU Activities

[0001327567-24-000029:notes:281]
The following table summarizes the RSU and PSU activity under our stock plans during the years ended July 31, 2024, 2023, and 2022 (in millions, except per share amounts):

[0001327567-24-000029:notes:282]
|  | Unvested RSUs |  | Unvested PSUs |
|  | Number of Shares |  | Weighted-Average Grant-Date Fair Value Per Share |  |  |  | Aggregate Intrinsic Value |  | Number of Shares |  | Weighted-Average Grant-Date Fair Value Per Share |  |  |  | Aggregate Intrinsic Value |
| Balance—July 31, 2021 | 20.7 |  |  | $ | 85.85 |  |  |  |  | $ | 2,760.2 |  |  | 3.8 |  |  | $ | 97.64 |  |  |  |  | $ | 498.4 |  |
| Granted(1) | 5.9 |  |  | 164.85 |  |  |  |  |  |  | 0.8 |  |  | 117.05 |  |  |  |  |  |
| Vested(2) | (9.0) |  |  | 85.69 |  |  |  |  |  |  | (1.1) |  |  | 83.47 |  |  |  |  |  |
| Forfeited | (2.8) |  |  | 95.50 |  |  |  |  |  |  | (0.4) |  |  | 107.31 |  |  |  |  |  |
| Balance—July 31, 2022 | 14.8 |  |  | $ | 115.51 |  |  |  |  | $ | 2,456.9 |  |  | 3.1 |  |  | $ | 106.38 |  |  |  |  | $ | 513.7 |  |
| Granted(1) | 5.8 |  |  | 169.04 |  |  |  |  |  |  | 3.6 |  |  | 142.88 |  |  |  |  |  |
| Vested(2) | (7.0) |  |  | 110.93 |  |  |  |  |  |  | (1.3) |  |  | 112.72 |  |  |  |  |  |
| Forfeited | (1.5) |  |  | 128.05 |  |  |  |  |  |  | (0.4) |  |  | 136.95 |  |  |  |  |  |
| Balance—July 31, 2023 | 12.1 |  |  | $ | 142.61 |  |  |  |  | $ | 3,013.0 |  |  | 5.0 |  |  | $ | 128.64 |  |  |  |  | $ | 1,242.3 |  |
| Granted(1) | 4.2 |  |  | 275.51 |  |  |  |  |  |  | 2.2 |  |  | 182.79 |  |  |  |  |  |
| Vested(2) | (5.9) |  |  | 137.25 |  |  |  |  |  |  | (1.6) |  |  | 114.56 |  |  |  |  |  |
| Forfeited | (1.4) |  |  | 168.24 |  |  |  |  |  |  | (0.6) |  |  | 137.07 |  |  |  |  |  |
| Balance—July 31, 2024 | 9.0 |  |  | $ | 205.18 |  |  |  |  | $ | 2,924.4 |  |  | 5.0 |  |  | $ | 155.89 |  |  |  |  | $ | 1,624.2 |  |

[0001327567-24-000029:notes:283]
(1)For PSUs, shares granted represent the aggregate maximum number of shares that may be earned and issued with respect to these awards over their full terms.

[0001327567-24-000029:notes:284]
(2)Includes time-based vesting for PSUs.

[0001327567-24-000029:notes:285]
The aggregate fair value, as of the respective vesting dates, of RSUs vested during the years ended July 31, 2024, 2023, and 2022 was $1.6 billion, $1.3 billion, and $1.6 billion, respectively. The aggregate fair value, as of the respective vesting dates, of PSUs vested during the years ended July 31, 2024, 2023, and 2022 was $377.7 million, $218.9 million, and $184.0 million, respectively.

[0001327567-24-000029:notes:286]
Shares Available for Grant

[0001327567-24-000029:notes:287]
The following table presents the stock activity and the total number of shares available for grant under our equity incentive plans as of July 31, 2024 (in millions):

[0001327567-24-000029:notes:288]
|  | Number of shares |
| Balance—July 31, 2023 | 12.4 |  |
| Authorized | 5.0 |  |
| RSUs and PSUs granted | (6.4) |  |
| RSUs and PSUs forfeited | 2.0 |  |
| Shares withheld for taxes | 0.1 |  |
| Balance—July 31, 2024 | 13.1 |  |

[0001327567-24-000029:notes:289]
We record share-based compensation awards based on estimated fair value as of the grant date. The fair value of RSUs and PSUs not subject to market conditions is based on the closing market price of our common stock on the date of grant.

[0001327567-24-000029:notes:290]
The fair value of the PSUs subject to market conditions is estimated on the grant date using a Monte Carlo simulation model. The following table summarizes the assumptions used and the resulting grant-date fair value of our PSUs subject to market conditions granted during the years ended July 31, 2024, 2023, and 2022:

[0001327567-24-000029:notes:291]
|  | Year Ended July 31, |
|  | 2024 |  | 2023 |  | 2022 |
| Volatility | 40.8% - 43.4% |  | 38.3% - 44.8% |  | 36.0% - 41.1% |
| Expected term (in years) | 0.9 - 2.9 |  | 1.0 - 5.0 |  | 1.4 - 3.0 |
| Dividend yield | — | % |  | — | % |  | — | % |
| Risk-free interest rate | 4.4% - 5.3% |  | 3.2% - 4.1% |  | 0.2% - 2.0% |
| Grant-date fair value per share | $346.92 - $621.21 |  | $91.77 - $280.41 |  | $137.16 - $260.71 |

[0001327567-24-000029:notes:292]
The expected volatility is based on the historical volatility of our common stock. The expected term is based on the length of each tranche’s performance period from the grant date. The dividend yield assumption is based on our current expectations about our anticipated dividend policy. The risk-free interest rate is based on the implied yield available on U.S. Treasury zero-coupon issues with maturities that approximate the expected term.

[0001327567-24-000029:notes:293]
The fair value of PSOs was estimated on the grant date using a Monte Carlo simulation model, which predicts settlement of the PSOs midway between the vesting term and the contractual term. No PSOs were granted during the years ended July 31, 2024, 2023, and 2022.

[0001327567-24-000029:notes:294]
The fair value of shares issued under our 2012 ESPP are estimated on the grant date using the Black-Scholes option pricing model. The following table summarizes the assumptions used and the resulting grant-date fair values of our ESPP:

[0001327567-24-000029:notes:295]
|  | Year Ended July 31, |
|  | 2024 |  | 2023 |  | 2022 |
| Volatility | 39.6% - 50.0% |  | 38.6% - 44.7% |  | 33.6% - 39.4% |
| Expected term (in years) | 0.5 - 2.0 |  | 0.5 - 2.0 |  | 0.5 - 2.0 |
| Dividend yield | — | % |  | — | % |  | — | % |
| Risk-free interest rate | 4.6% - 5.5% |  | 3.3% - 5.2% |  | 0.1% - 1.4% |
| Grant-date fair value per share | $65.61 - $133.32 |  | $48.78 - $74.06 |  | $37.59 - $74.10 |

[0001327567-24-000029:notes:296]
The expected volatility is based on a combination of implied volatility from traded options on our common stock and the historical volatility of our common stock. The expected term represents the term from the first day of the offering period to the purchase dates within each offering period. The dividend yield assumption is based on our current expectations about our anticipated dividend policy. The risk-free interest rate is based on the implied yield available on U.S. Treasury zero-coupon issues with maturities that approximate the expected term.

[0001327567-24-000029:notes:297]
The following table summarizes share-based compensation included in costs and expenses (in millions):

[0001327567-24-000029:notes:298]
|  | Year Ended July 31, |
|  | 2024 |  | 2023 |  | 2022 |
| Cost of product revenue | $ | 7.3 |  |  | $ | 9.8 |  |  | $ | 9.3 |  |
| Cost of subscription and support revenue | 121.0 |  |  | 123.4 |  |  | 110.2 |  |
| Research and development | 525.5 |  |  | 488.4 |  |  | 471.1 |  |
| Sales and marketing | 300.8 |  |  | 335.3 |  |  | 304.7 |  |
| General and administrative | 124.1 |  |  | 130.4 |  |  | 118.1 |  |
| Total share-based compensation | $ | 1,078.7 |  |  | $ | 1,087.3 |  |  | $ | 1,013.4 |  |

[0001327567-24-000029:notes:299]
As of July 31, 2024, total compensation cost related to unvested share-based awards not yet recognized was $2.0 billion. This cost is expected to be amortized over a weighted-average period of approximately 2.6 years. Future grants will increase the amount of compensation expense to be recorded in these periods.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001327567-24-000029:notes:300]
Income Taxes 
The following table presents the components of income (loss) before income taxes (in millions):

[0001327567-24-000029:notes:301]
|  | Year Ended July 31, |
|  | 2024 |  | 2023 |  | 2022 |
| United States | $ | 669.2 |  |  | $ | 374.3 |  |  | $ | (152.3) |  |
| Foreign | 319.1 |  |  | 192.0 |  |  | (54.9) |  |
| Total | $ | 988.3 |  |  | $ | 566.3 |  |  | $ | (207.2) |  |

[0001327567-24-000029:notes:302]
The following table summarizes our provision for (benefit from) income taxes (in millions):

[0001327567-24-000029:notes:303]
|  | Year Ended July 31, |
|  | 2024 |  | 2023 |  | 2022 |
| Federal: |  |  |  |  |  |
| Current | $ | 213.4 |  |  | $ | 26.1 |  |  | $ | 2.6 |  |
| Deferred | 311.7 |  |  | 19.3 |  |  | (0.3) |  |
| State: |  |  |  |  |  |
| Current | 101.5 |  |  | 44.0 |  |  | 1.5 |  |
| Deferred | (172.8) |  |  | 0.4 |  |  | 0.1 |  |
| Foreign: |  |  |  |  |  |
| Current | 129.6 |  |  | 44.0 |  |  | 58.8 |  |
| Deferred | (2,172.7) |  |  | (7.2) |  |  | (2.9) |  |
| Total | $ | (1,589.3) |  |  | $ | 126.6 |  |  | $ | 59.8 |  |

[0001327567-24-000029:notes:304]
For the year ended July 31, 2024, our benefit from income taxes was $1.6 billion, a net change of $1.7 billion compared to a provision for income taxes of $126.6 million for the year ended July 31, 2023, primarily due to the release of our valuation allowance on U.S. federal, U.S. states other than California, and United Kingdom (“U.K.”) deferred tax assets in fiscal 2024, partially offset by the deferred tax provision in our U.S. federal tax provision to recognize the indirect effect on basis differences relating to our global intangible low-taxed income in connection with the release of our valuation allowance in the U.K.

[0001327567-24-000029:notes:305]
For the year ended July 31, 2023, our provision for income taxes increased compared to the year ended July 31, 2022, primarily due to our profitability in fiscal 2023 and an increase in U.S. taxes driven by capitalization of research and development expenditure with no offsetting deferred benefit due to our valuation allowance.

[0001327567-24-000029:notes:306]
The following table presents the items accounting for the difference between income taxes computed at the federal statutory income tax rate and our provision for (benefit from) income taxes:

[0001327567-24-000029:notes:307]
|  | Year Ended July 31, |
|  | 2024 |  | 2023 |  | 2022 |
| Federal statutory rate | 21.0 | % |  | 21.0 | % |  | 21.0 | % |
| Effect of: |  |  |  |  |  |
| State taxes, net of federal tax benefit | 3.1 |  |  | 2.8 |  |  | 2.7 |  |
| Non-U.S. operations | 9.5 |  |  | 9.7 |  |  | (16.5) |  |
| Change in valuation allowance | (341.9) |  |  | 15.5 |  |  | (158.7) |  |
| U.S. effect of foreign deferred tax assets | 175.8 |  |  | — |  |  | — |  |
| Share-based compensation | (16.9) |  |  | (12.6) |  |  | 83.6 |  |
| Tax credits | (13.4) |  |  | (15.6) |  |  | 41.5 |  |
| Non-deductible expenses | 1.5 |  |  | 2.3 |  |  | (2.5) |  |
| Other, net | 0.5 |  |  | (0.7) |  |  | — |  |
| Total | (160.8) | % |  | 22.4 | % |  | (28.9) | % |

[0001327567-24-000029:notes:308]
The following table presents the components of our deferred tax assets and liabilities as of July 31, 2024 and 2023 (in millions):

[0001327567-24-000029:notes:309]
|  | July 31, |
|  | 2024 |  | 2023 |
| Deferred tax assets: |  |  |  |
| Accruals and reserves | $ | 109.7 |  |  | $ | 88.5 |  |
| Operating lease liabilities | 132.6 |  |  | 94.1 |  |
| Deferred revenue | 1,004.9 |  |  | 708.1 |  |
| Net operating loss carryforwards | 585.2 |  |  | 551.0 |  |
| Tax credits | 175.3 |  |  | 338.9 |  |
| Capitalized research expenditures | 626.6 |  |  | 354.8 |  |
| Share-based compensation | 75.6 |  |  | 66.0 |  |
| Fixed assets and intangible assets | 1,631.7 |  |  | 1,698.3 |  |
| Gross deferred tax assets | 4,341.6 |  |  | 3,899.7 |  |
| Valuation allowance | (243.4) |  |  | (3,586.7) |  |
| Total deferred tax assets | 4,098.2 |  |  | 313.0 |  |
| Deferred tax liabilities: |  |  |  |
| U.S. effect of foreign deferred tax assets | (1,728.5) |  |  | — |  |
| Operating lease right-of-use assets | (115.8) |  |  | (73.5) |  |
| Deferred contract costs | (199.1) |  |  | (186.7) |  |
| Other deferred tax liabilities | (43.5) |  |  | (58.2) |  |
| Total deferred tax liabilities | (2,086.9) |  |  | (318.4) |  |
| Net deferred tax assets (liabilities) | $ | 2,011.3 |  |  | $ | (5.4) |  |

[0001327567-24-000029:notes:310]
We regularly assess the need for a valuation allowance on our deferred tax assets. In making this assessment, we consider both positive and negative evidence related to the likelihood of realization of the deferred tax assets to determine, based on the weight of available evidence, whether it is more likely than not that some or all the deferred tax assets will not be realized. The assessment requires significant judgment and is performed for each of the applicable jurisdictions. Based on our analysis of all positive and negative evidence during the year ended July 31, 2024, we concluded it is more likely than not that our U.S. federal, U.S. states other than California, and U.K. deferred tax assets will be realizable based on our recent profitability and continued forecasted income. In making these judgments, we considered our recent and expected ongoing profitability, which supports our conclusion of the realization of the deferred tax assets. We continue to maintain a valuation allowance for our California deferred tax assets due to the uncertainty regarding realizability of these deferred tax assets as they have not met the “more likely than not” realization criterion. We expect future research and development tax credit generation in California to exceed our ability to use the existing tax credits.

[0001327567-24-000029:notes:311]
As a result of the valuation allowance release, during the year ended July 31, 2024, we recognized a deferred tax benefit of $3.4 billion for the U.S. federal, U.S. states other than California, and U.K. deferred tax assets. Our U.S. federal and state deferred tax assets largely consist of capitalized research expenditures and accelerated recognition of deferred revenue for tax purposes. U.S. tax carryforwards (including net operating losses and tax credits) are expected to be fully utilized to the extent allowable by law. Our U.K. deferred tax assets largely consist of basis differences in intangible assets and related net operating losses expected to be utilized in the future.

[0001327567-24-000029:notes:312]
In addition, during the year ended July 31, 2024, we recognized a deferred tax expense of $1.7 billion for the U.S. federal indirect tax effect of foreign deferred taxes consistent with our policy to record deferred taxes for basis differences relating to our global intangible low-taxed income. Accordingly, during the year ended July 31, 2024, we recognized a net tax benefit of $1.7 billion relating to our valuation allowance release. We will continue to monitor the need for a valuation allowance on our deferred tax assets.

[0001327567-24-000029:notes:313]
As of July 31, 2024, we had federal, state, and foreign net operating loss carryforwards of approximately $46.8 million, $112.8 million, and $2.3 billion, respectively, as reported on our tax returns, available to reduce future taxable income, if any. If not utilized, our federal and state net operating loss carryforwards will expire in various amounts at various dates beginning in the years ending July 31, 2034 and July 31, 2031, respectively. Our foreign net operating loss will carry forward indefinitely.

[0001327567-24-000029:notes:314]
As of July 31, 2024, we had federal and state research and development tax credit carryforwards of approximately $70.7 million and $291.2 million, respectively, as reported on our tax returns. If not utilized, the federal credit carryforwards will expire in various amounts at various dates beginning in the year ending July 31, 2034. The state credit carryforwards have no expiration.

[0001327567-24-000029:notes:315]
As of July 31, 2024, we had foreign tax credit carryforwards of $1.6 million as reported on our tax returns. If not utilized, the foreign tax credit carryforwards will expire in various amounts at various dates beginning in the year ending July 31, 2029.

[0001327567-24-000029:notes:316]
Utilization of the net operating loss carryforwards and credits may be subject to a substantial annual limitation due to the ownership change limitations provided by the Internal Revenue Code of 1986, as amended, and similar state provisions. The annual limitation may result in the expiration of net operating losses and credits before utilization.

[0001327567-24-000029:notes:317]
As of July 31, 2024, we had $454.4 million of unrecognized tax benefits, $200.1 million of which would affect income tax expense if recognized, after consideration of our valuation allowance in the United States and other assets. As of July 31, 2023, we had $360.0 million of unrecognized tax benefits, $70.4 million of which would affect income tax expense if recognized, after consideration of our valuation allowance in the United States and other assets. We do not expect the amount of unrecognized tax benefits as of July 31, 2024 to materially change over the next 12 months.

[0001327567-24-000029:notes:318]
We file federal, state, and foreign income tax returns in jurisdictions with varying statutes of limitations. Generally, all years remain subject to adjustment due to our net operating loss and credit carryforwards. We currently have ongoing tax audits in various jurisdictions and at various times. The primary focus of these audits is, generally, profit allocation. The ultimate amount and timing of any future settlements cannot be predicted with reasonable certainty.

[0001327567-24-000029:notes:319]
We recognize both interest and penalties associated with uncertain tax positions as a component of income tax expense. During the years ended July 31, 2024, 2023, and 2022, we recognized an income tax expense of $5.8 million, a net income tax benefit of $4.8 million, and an income tax expense of $5.2 million related to interest and penalties, respectively. We had accrued interest and penalties on our consolidated balance sheets related to unrecognized tax benefits of $10.9 million and $5.1 million as of July 31, 2024 and 2023, respectively.

[0001327567-24-000029:notes:320]
The following table presents a reconciliation of the beginning and ending amount of our gross unrecognized tax benefits (in millions):

[0001327567-24-000029:notes:321]
|  | Year Ended July 31, |
|  | 2024 |  | 2023 |  | 2022 |
| Unrecognized tax benefits at the beginning of the period | $ | 360.0 |  |  | $ | 414.0 |  |  | $ | 372.9 |  |
| Additions for tax positions taken in prior years | 1.9 |  |  | 7.8 |  |  | 3.5 |  |
| Reductions for tax positions taken in prior years | (19.8) |  |  | (99.8) |  |  | (7.4) |  |
| Additions for tax positions taken in the current year | 112.3 |  |  | 66.9 |  |  | 45.0 |  |
| Reduction relating to audit settlement | — |  |  | (28.9) |  |  | — |  |
| Unrecognized tax benefits at the end of the period | $ | 454.4 |  |  | $ | 360.0 |  |  | $ | 414.0 |  |

[0001327567-24-000029:notes:322]
During the year ended July 31, 2024, increases in uncertain tax positions were primarily due to positions relating to our credits and incentives and intercompany transactions. During the year ended July 31, 2023, our reductions in uncertain tax positions primarily related to settlements with non-U.S. tax authorities and remeasurement of certain unrecognized tax benefits. As a result of our settlement agreements with non-U.S. tax authorities, we paid a total of $39.8 million, including interest and penalties.

[0001327567-24-000029:notes:323]
Our additions for tax positions taken in the years ended July 31, 2024, 2023 and 2022 were primarily attributable to uncertain tax positions related to tax credits. Our additions for tax positions taken in the year ended July 31, 2024 were further driven by intercompany transactions.
As of July 31, 2024, we had no unremitted earnings when evaluating our outside basis difference relating to our U.S. investment in foreign subsidiaries. However, there could be local withholding taxes due to various foreign countries if certain lower tier earnings are distributed. Withholding taxes that would be payable upon remittance of these lower tier earnings are not material.


## us-gaap:EarningsPerShareTextBlock

[0001327567-24-000029:notes:324]
Net Income (Loss) Per Share 
Basic net income (loss) per share is computed by dividing net income (loss) by basic weighted-average shares outstanding during the period. Diluted net income (loss) per share is computed by dividing net income (loss) by diluted weighted-average shares outstanding during the period giving effect to all potentially dilutive securities to the extent they are dilutive. We compute the dilutive effect of shares issuable upon conversion of our convertible senior notes using the if-converted method, and the dilutive effect of warrants related to the issuance of convertible senior notes and equity awards under our employee equity incentive plans using the treasury stock method.

[0001327567-24-000029:notes:325]
The following table presents the computation of basic and diluted net income (loss) per share of common stock (in millions, except per share data):

[0001327567-24-000029:notes:326]
|  | Year Ended July 31, |
|  | 2024 |  | 2023 |  | 2022 |
| Net income (loss) | $ | 2,577.6 |  |  | $ | 439.7 |  |  | $ | (267.0) |  |
| Weighted-average shares used to compute net income (loss) per share, basic | 319.2 |  |  | 303.2 |  |  | 295.6 |
| Weighted-average effect of potentially dilutive securities: |  |  |  |  |  |
| Convertible senior notes | 10.4 |  |  | 17.9 |  |  | — |  |
| Warrants related to the issuance of convertible senior notes | 12.8 |  |  | 9.3 |  |  | — |  |
| Employee equity incentive plans | 11.6 |  |  | 11.9 |  |  | — |  |
| Weighted-average shares used to compute net income (loss) per share, diluted | 354.0 |  |  | 342.3 |  |  | 295.6 |
| Net income (loss) per share, basic | $ | 8.07 |  |  | $ | 1.45 |  |  | $ | (0.90) |  |
| Net income (loss) per share, diluted | $ | 7.28 |  |  | $ | 1.28 |  |  | $ | (0.90) |  |

[0001327567-24-000029:notes:327]
The following securities were excluded from the computation of diluted net income (loss) per share of common stock as their effect would have been antidilutive or issuance of such shares is contingent upon the satisfaction of certain conditions which were not satisfied by the end of the applicable period (in millions):

[0001327567-24-000029:notes:328]
|  | Year Ended July 31, |
|  | 2024 |  | 2023 |  | 2022 |
| Convertible senior notes | — |  |  | — |  |  | 39.2 |  |
| Warrants related to the issuance of convertible senior notes | — |  |  | — |  |  | 39.2 |  |
| Employee equity incentive plans | 2.4 |  |  | 3.9 |  |  | 26.8 |  |
| Total | 2.4 |  |  | 3.9 |  |  | 105.2 |  |


## us-gaap:OtherNonoperatingIncomeAndExpenseTextBlock

[0001327567-24-000029:notes:329]
Other Income, Net
The following table sets forth the components of other income, net (in millions):

[0001327567-24-000029:notes:330]
|  | Year Ended July 31, |
|  | 2024 |  | 2023 |  | 2022 |
| Interest income | $ | 317.9 |  |  | $ | 224.4 |  |  | $ | 15.6 |  |
| Foreign currency exchange gains (losses), net | 0.2 |  |  | (7.9) |  |  | 1.8 |  |
| Other, net | (5.4) |  |  | (10.3) |  |  | (8.4) |  |
| Total other income, net | $ | 312.7 |  |  | $ | 206.2 |  |  | $ | 9.0 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001327567-24-000029:notes:331]
Segment Information
We conduct business globally and sales are primarily managed on a geographic theater basis. Our chief operating decision maker reviews financial information presented on a consolidated basis accompanied by information about revenue by geographic region for purposes of allocating resources and evaluating financial performance. We have one business activity and there are no segment managers who are held accountable for operations, operating results, and plans for levels, components, or types of products or services below the consolidated unit level. Accordingly, we are considered to be in a single reportable segment and operating unit structure.

[0001327567-24-000029:notes:332]
The following table presents our long-lived assets, which consist of property and equipment, net and operating lease right-of-use assets, by geographic area (in millions):

[0001327567-24-000029:notes:333]
|  | Year Ended July 31, |
|  | 2024 |  | 2023 |
| Long-lived assets: |  |  |  |
| United States | $ | 438.9 |  |  | $ | 400.4 |  |
| Israel | 141.1 |  |  | 76.8 |  |
| Other countries | 167.0 |  |  | 140.6 |  |
| Total long-lived assets | $ | 747.0 |  |  | $ | 617.8 |  |

[0001327567-24-000029:notes:334]
Refer to Note 2. Revenue for revenue by geographic theater and revenue for groups of similar products and services for the years ended July 31, 2024, 2023, and 2022.


## us-gaap:SubsequentEventsTextBlock

[0001327567-24-000029:notes:335]
Subsequent Events
Acquisition

[0001327567-24-000029:notes:336]
On May 15, 2024, we entered into a definitive agreement with International Business Machines Corporation to acquire certain QRadar assets, including intellectual property, customer relationships, and customer contracts. We agreed to pay $500.0 million in cash upon closing, and to make additional post-closing payments contingent upon the migration of QRadar on-premise customers to Cortex XSIAM through December 31, 2027. We expect the acquisition will help accelerate the growth of our Cortex XSIAM business. On August 31, 2024, we completed this acquisition, which will be accounted for as a business combination in the first quarter of fiscal 2025. We are currently in the process of determining the initial purchase accounting for this transaction.

[0001327567-24-000029:notes:337]
2025 Notes Conversion

[0001327567-24-000029:notes:338]
Subsequent to July 31, 2024, $285.8 million in aggregate principal amount of the 2025 Notes was converted or had been submitted by the holders for conversion and will settle during the fiscal quarter ending October 31, 2024.

[0001327567-24-000029:notes:339]
Share Repurchase

[0001327567-24-000029:notes:340]
On August 15, 2024, our board of directors authorized a $500.0 million increase to our share repurchase program, bringing the total remaining authorization for future share repurchases to $1.0 billion. The expiration date of the repurchase authorization was extended to December 31, 2025, and our repurchase program may be suspended or discontinued at any time without prior notice. Repurchases may be made at management’s discretion from time to time on the open market, through privately negotiated transactions, transactions structured through investment banking institutions, block purchase techniques, 10b5-1 trading plans, or a combination of the foregoing.
