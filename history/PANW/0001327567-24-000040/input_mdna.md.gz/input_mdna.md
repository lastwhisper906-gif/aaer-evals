# PANW MD&A — 0001327567-24-000040


## mdna

[0001327567-24-000040:mdna:1]
[same as prior period, unchanged from 0001327567-24-000017:mdna:1]

[0001327567-24-000040:mdna:2]
[same as prior period, unchanged from 0001327567-24-000017:mdna:2]

[0001327567-24-000040:mdna:3]
[same as prior period, unchanged from 0001327567-24-000017:mdna:3]

[0001327567-24-000040:mdna:4]
[same as prior period, unchanged from 0001327567-24-000017:mdna:4]

[0001327567-24-000040:mdna:5]
•Results of Operations. A discussion of the nature and trends in our financial results and an analysis of our financial results comparing the three months ended October 31, 2024 to the three months ended October 31, 2023.

[0001327567-24-000040:mdna:6]
[same as prior period, unchanged from 0001327567-24-000017:mdna:6]

[0001327567-24-000040:mdna:7]
[same as prior period, unchanged from 0001327567-24-000017:mdna:7]

[0001327567-24-000040:mdna:8]
[same as prior period, unchanged from 0001327567-24-000017:mdna:8]

[0001327567-24-000040:mdna:9]
- 22 -

[0001327567-24-000040:mdna:10]
[same as prior period, unchanged from 0001327567-24-000017:mdna:10]

[0001327567-24-000040:mdna:11]
We empower enterprises, organizations, service providers, and government entities to protect themselves against today’s most sophisticated cyber threats. Our cybersecurity platforms and services help secure enterprise users, networks, clouds, and endpoints by delivering comprehensive cybersecurity backed by artificial intelligence (“AI”) and automation. A key element of our strategy is to help our customers simplify their security architectures through consolidating disparate point products. We execute on this strategy by developing our capabilities and packaging our offerings into platforms which are able to cover many of our customers’ needs in the markets in which we operate. Our platformization strategy combines various products and services into a tightly integrated architecture and makes security faster, less complex, and more cost-effective. We focus on delivering value in four sectors of the cybersecurity industry:

[0001327567-24-000040:mdna:12]
[same as prior period, unchanged from 0001327567-24-000017:mdna:12]

[0001327567-24-000040:mdna:13]
•Our network security platform, designed to deliver complete zero trust solutions to our customers, includes our hardware and software ML-Powered Next-Generation Firewalls, AI Runtime Security, as well as a cloud-delivered Secure Access Service Edge (“SASE”). Prisma® Access, our Security Services Edge (“SSE”) solution, when combined with Prisma SD-WAN, provides a comprehensive single-vendor SASE offering that is used to secure remote workforces and securely enable the cloud-delivered branch. Prisma Access Browser extends SASE security and data protection to the endpoint, giving workers complete device freedom to access business applications securely using their browser. Our network security platform also includes our cloud-delivered security services, such as Advanced Threat Prevention, Advanced WildFire®, Advanced URL Filtering, Advanced DNS Security, IoT/OT Security, GlobalProtect®, Enterprise Data Loss Prevention (“Enterprise DLP”), AI for IT Operations (“AIOps”), software as a service (“SaaS”) Security, and AI Access Security. Through these add-on security services, our customers are able to secure their content, applications, users, and devices across their entire organization. Strata Cloud Manager, our network security management solution, can centrally manage our network security platform irrespective of form factor, location, or scale. Strata Cloud Manager includes the Strata Copilot which provides a natural language interface to simplify and strengthen network security.

[0001327567-24-000040:mdna:14]
[same as prior period, unchanged from 0001327567-24-000017:mdna:14]

[0001327567-24-000040:mdna:15]
•We deliver scalable and comprehensive security across the cloud application development lifecycle through our Code to CloudTM platform, Prisma Cloud. As a comprehensive Cloud Native Application Protection Platform (“CNAPP”), Prisma Cloud secures multi- and hybrid-cloud environments for applications, data, generative AI (“GenAI”) ecosystem, and the entire cloud native technology stack across the full development lifecycle, from code to cloud. We also offer our VM-Series and CN-Series virtual firewalls for inline network security on multi- and hybrid-cloud environments.

[0001327567-24-000040:mdna:16]
[same as prior period, unchanged from 0001327567-24-000017:mdna:16]

[0001327567-24-000040:mdna:17]
•We deliver the next generation of security operations capabilities that unifies standalone Security Information and Event Management (“SIEM”) tools, endpoint security, security automation, and attack surface management (“ASM”) capabilities on our Cortex platform. These include Cortex XSIAM®, for AI-driven security operations that replaces traditional SIEM tools, Cortex XDR® for the prevention, detection, and response to complex cybersecurity attacks, Cortex XSOAR® for security orchestration, automation, and response (“SOAR”), and Cortex Xpanse® for ASM. These products are delivered as SaaS or software subscriptions.

[0001327567-24-000040:mdna:18]
[same as prior period, unchanged from 0001327567-24-000017:mdna:18]

[0001327567-24-000040:mdna:19]
•Unit 42® brings together world-renowned threat researchers with an elite team of incident responders and security consultants to create an intelligence-driven, response-ready organization to help customers manage cyber risk. Our consultants serve as trusted advisors to our customers by assessing and testing their security controls against the right threats, transforming their security strategy with a threat-informed approach, and responding to security incidents on behalf of our clients. Additionally, Unit 42 offers managed detection and response (“MDR”) and managed threat hunting services.

[0001327567-24-000040:mdna:20]
For the first quarter of fiscal 2025 and 2024, total revenue was $2.1 billion and $1.9 billion, respectively, representing year-over-year growth of 13.9%. Our growth reflects the increased adoption of our portfolio, which consists of product, subscriptions, and support. We believe our portfolio will enable us to benefit from recurring revenues and new revenues as we continue to grow our end-customer base. As of October 31, 2024, we had end-customers in over 180 countries. Our end-customers represent a broad range of industries, including education, energy, financial services, government entities, healthcare, Internet and media, manufacturing, public sector, and telecommunications, and include almost all of the Fortune 100 companies and a majority of the Global 2000 companies. We maintain a field sales force that works closely with our channel partners in developing sales opportunities. We primarily use a two-tiered, indirect fulfillment model whereby we sell our products, subscriptions, and support to our distributors, which, in turn, sell to our resellers, which then sell to our end-customers.

[0001327567-24-000040:mdna:21]
[same as prior period, unchanged from 0001327567-24-000017:mdna:9]

[0001327567-24-000040:mdna:22]
Our product revenue grew to $353.8 million, or 16.5% of total revenue, for the first quarter of fiscal 2025, representing year-over-year growth of 3.7%. Product revenue is derived from sales of our appliances, primarily our ML-Powered Next-Generation Firewall. Product revenue also includes revenue derived from software licenses of Panorama®, SD-WAN, and the VM-Series. Our ML-Powered Next-Generation Firewall incorporates our PAN-OS operating system, which provides a consistent set of capabilities across our entire network security product line. Our appliances and software licenses include a broad set of built-in networking and security features and functionalities. Our products are designed for different performance requirements throughout an organization, ranging from our PA-410, which is designed for small organizations and remote or branch offices, to our top-of-the-line PA-7500, which is designed for large-scale data centers and service provider use. The same firewall functionality that is delivered in our physical appliances is also available in our VM-Series virtual firewalls, which secure virtualized and cloud-based computing environments, and in our CN-Series container firewalls, which secure container environments and traffic.

[0001327567-24-000040:mdna:23]
Our subscription and support revenue grew to $1.8 billion, or 83.5% of total revenue, for the first quarter of fiscal 2025, representing year-over-year growth of 16.1%. Our subscriptions provide our end-customers with near real-time access to the latest antivirus, intrusion prevention, web filtering, modern malware prevention, data loss prevention, and cloud access security broker and AI security capabilities across the network, endpoints, and the cloud. Our subscriptions also include security operations, which enable customers to leverage the AI-driven Cortex platform for advanced capabilities such as security information and event management, next-generation antivirus, endpoint detection and response, extended detection and response, identity threat detection and response, cloud detection and response, SOAR, as well as ASM. Additionally, we offer MDR for Cortex subscriptions, powered by Unit 42’s elite expertise. When customers purchase our physical, virtual, or container firewall appliances, or certain cloud offerings, they typically purchase support in order to receive ongoing security updates, upgrades, bug fixes, and repairs. In addition to the subscriptions purchased with these appliances, customers may also purchase other subscriptions on a per-user, per-endpoint, or capacity-based basis. We also offer professional services, including incident response, risk management, and digital forensic services.

[0001327567-24-000040:mdna:24]
We continue to invest in innovation as we evolve and further extend the capabilities of our portfolio, as we believe that innovation and timely development of new features and products are essential to meeting the needs of our end-customers and improving our competitive position. For example, in August 2024, we launched Prisma Access Browser, our SASE-native enterprise browser that enables security teams to manage security policies across web applications and devices; and in October 2024, we introduced new capabilities in our operational technology (“OT”) Security solution to protect OT remote operations, mitigate risk for critical OT assets and extend security into industrial environments. Additionally, we continue to make strategic investments that fit well within our long-term strategy. For example, in August 2024, we completed the acquisition of certain QRadar assets from International Business Machines Corporation (“IBM”), which we expect will help accelerate the growth of our Cortex business.

[0001327567-24-000040:mdna:25]
[same as prior period, unchanged from 0001327567-24-000017:mdna:25]

[0001327567-24-000040:mdna:26]
IMPACT OF MACROECONOMIC DEVELOPMENTS AND OTHER FACTORS ON OUR BUSINESS

[0001327567-24-000040:mdna:27]
Our overall performance depends in part on worldwide economic and geopolitical conditions and their impact on customer behavior. Worsening economic conditions, including inflation, high interest rates, slow growth, fluctuations in foreign exchange rates, supply chain disruptions, impacts of trade regulations, and other conditions, may adversely affect our results of operations and financial performance.

[0001327567-24-000040:mdna:28]
The hostilities in Israel and the surrounding region have increased the levels of economic and political uncertainty. While we have business operations in Israel, and intend to continue growing our presence in Israel, we currently do not expect significant business disruption. We are actively monitoring, evaluating, and responding to the situation.

[0001327567-24-000040:mdna:29]
[same as prior period, unchanged from 0001327567-24-000017:mdna:29]

[0001327567-24-000040:mdna:30]
[same as prior period, unchanged from 0001327567-24-000017:mdna:21]

[0001327567-24-000040:mdna:31]
[same as prior period, unchanged from 0001327567-24-000017:mdna:31]

[0001327567-24-000040:mdna:32]
[same as prior period, unchanged from 0001327567-24-000017:mdna:32]

[0001327567-24-000040:mdna:33]
|  | October 31, 2024 |  | July 31, 2024 |
|  | (in billions) |
| Next-Generation Security Annualized Recurring Revenue | $ | 4.5 |  |  | $ | 4.2 |  |
| Remaining performance obligations | $ | 12.6 |  |  | $ | 12.7 |  |

[0001327567-24-000040:mdna:34]
|  |  |  | Three Months Ended October 31, |
|  |  |  |  |  | 2024 |  | 2023 |
|  |  |  |  |  | (dollars in millions) |
| Total revenue |  |  |  |  | $ | 2,138.8 |  |  | $ | 1,878.1 |  |
| Total revenue year-over-year percentage increase |  |  |  |  | 13.9 | % |  | 20.1 | % |
| Gross margin |  |  |  |  | 74.1 | % |  | 74.8 | % |
| Operating income |  |  |  |  | $ | 286.5 |  |  | $ | 215.2 |  |
| Operating margin |  |  |  |  | 13.4 | % |  | 11.5 | % |
| Cash flow provided by operating activities |  |  |  |  | $ | 1,509.6 |  |  | $ | 1,526.0 |  |
| Free cash flow (non-GAAP) |  |  |  |  | $ | 1,465.5 |  |  | $ | 1,489.2 |  |

[0001327567-24-000040:mdna:35]
•Next-Generation Security Annualized Recurring Revenue (“NGS ARR”). Our NGS ARR represents the annualized allocated revenue of all active contracts as of the final day of the reporting period for Prisma and Cortex offerings inclusive of the VM-Series and related services, and certain cloud-delivered security services. Beginning the first quarter of fiscal 2025, NGS ARR includes revenue attributable to QRadar SaaS contracts. NGS ARR is an operating metric that we use to assess the strength and trajectory of our business. NGS ARR should be viewed independently of revenue, deferred revenue and remaining performance obligations and does not represent our revenue under U.S. GAAP on an annualized basis, as it is an operating metric that can be impacted by contract start and end dates and renewal rates. NGS ARR is not intended to be a replacement for forecasts of revenue.

[0001327567-24-000040:mdna:36]
[same as prior period, unchanged from 0001327567-24-000017:mdna:39]

[0001327567-24-000040:mdna:37]
[same as prior period, unchanged from 0001327567-24-000017:mdna:30]

[0001327567-24-000040:mdna:38]
[same as prior period, unchanged from 0001327567-24-000017:mdna:40]

[0001327567-24-000040:mdna:39]
|  | Three Months Ended October 31, |
|  | 2024 |  | 2023 |
|  | (in millions) |
| Free cash flow (non-GAAP): |  |  |  |
| Net cash provided by operating activities | $ | 1,509.6 |  |  | $ | 1,526.0 |  |
| Less: purchases of property, equipment, and other assets | 44.1 |  |  | 36.8 |  |
| Free cash flow (non-GAAP) | $ | 1,465.5 |  |  | $ | 1,489.2 |  |
| Net cash used in investing activities | $ | (543.8) |  |  | $ | (129.0) |  |
| Net cash used in financing activities | $ | (219.7) |  |  | $ | (41.8) |  |

[0001327567-24-000040:mdna:40]
[same as prior period, unchanged from 0001327567-24-000017:mdna:38]

[0001327567-24-000040:mdna:41]
[same as prior period, unchanged from 0001327567-24-000017:mdna:43]

[0001327567-24-000040:mdna:42]
[same as prior period, unchanged from 0001327567-24-000017:mdna:44]

[0001327567-24-000040:mdna:43]
|  |  |  | Three Months Ended October 31, |
|  |  |  |  |  | 2024 |  | 2023 |
|  |  |  |  |  |  |  |  |  | Amount |  | % of Revenue |  | Amount |  | % of Revenue |
|  |  |  |  |  |  |  |  |  | (dollars in millions) |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  |  |  |  |  |  |  |  | $ | 353.8 |  |  | 16.5 | % |  | $ | 341.1 |  |  | 18.2 | % |
| Subscription and support |  |  |  |  |  |  |  |  | 1,785.0 |  |  | 83.5 | % |  | 1,537.0 |  |  | 81.8 | % |
| Total revenue |  |  |  |  |  |  |  |  | 2,138.8 |  |  | 100.0 | % |  | 1,878.1 |  |  | 100.0 | % |
| Cost of revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  |  |  |  |  |  |  |  | 75.0 |  |  | 3.5 | % |  | 77.4 |  |  | 4.1 | % |
| Subscription and support |  |  |  |  |  |  |  |  | 479.1 |  |  | 22.4 | % |  | 395.4 |  |  | 21.1 | % |
| Total cost of revenue(1) |  |  |  |  |  |  |  |  | 554.1 |  |  | 25.9 | % |  | 472.8 |  |  | 25.2 | % |
| Total gross profit |  |  |  |  |  |  |  |  | 1,584.7 |  |  | 74.1 | % |  | 1,405.3 |  |  | 74.8 | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development |  |  |  |  |  |  |  |  | 480.4 |  |  | 22.5 | % |  | 409.5 |  |  | 21.8 | % |
| Sales and marketing |  |  |  |  |  |  |  |  | 720.1 |  |  | 33.6 | % |  | 660.5 |  |  | 35.1 | % |
| General and administrative |  |  |  |  |  |  |  |  | 97.7 |  |  | 4.6 | % |  | 120.1 |  |  | 6.4 | % |
| Total operating expenses(1) |  |  |  |  |  |  |  |  | 1,298.2 |  |  | 60.7 | % |  | 1,190.1 |  |  | 63.3 | % |
| Operating income |  |  |  |  |  |  |  |  | 286.5 |  |  | 13.4 | % |  | 215.2 |  |  | 11.5 | % |
| Interest expense |  |  |  |  |  |  |  |  | (1.2) |  |  | (0.1) | % |  | (2.9) |  |  | (0.2) | % |
| Other income, net |  |  |  |  |  |  |  |  | 83.3 |  |  | 3.9 | % |  | 70.3 |  |  | 3.7 | % |
| Income before income taxes |  |  |  |  |  |  |  |  | 368.6 |  |  | 17.2 | % |  | 282.6 |  |  | 15.0 | % |
| Provision for income taxes |  |  |  |  |  |  |  |  | 17.9 |  |  | 0.8 | % |  | 88.4 |  |  | 4.7 | % |
| Net income |  |  |  |  |  |  |  |  | $ | 350.7 |  |  | 16.4 | % |  | $ | 194.2 |  |  | 10.3 | % |

[0001327567-24-000040:mdna:44]
[same as prior period, unchanged from 0001327567-24-000017:mdna:46]

[0001327567-24-000040:mdna:45]
|  |  |  | Three Months Ended October 31, |
|  |  |  |  |  | 2024 |  | 2023 |
|  |  |  |  |  | (in millions) |
| Cost of product revenue |  |  |  |  | $ | 1.3 |  |  | $ | 2.4 |  |
| Cost of subscription and support revenue |  |  |  |  | 30.4 |  |  | 30.6 |  |
| Research and development |  |  |  |  | 137.8 |  |  | 120.1 |  |
| Sales and marketing |  |  |  |  | 76.4 |  |  | 79.2 |  |
| General and administrative |  |  |  |  | 48.4 |  |  | 38.7 |  |
| Total share-based compensation |  |  |  |  | $ | 294.3 |  |  | $ | 271.0 |  |

[0001327567-24-000040:mdna:46]
[same as prior period, unchanged from 0001327567-24-000017:mdna:42]

[0001327567-24-000040:mdna:47]
[same as prior period, unchanged from 0001327567-24-000017:mdna:49]

[0001327567-24-000040:mdna:48]
[same as prior period, unchanged from 0001327567-24-000017:mdna:50]

[0001327567-24-000040:mdna:49]
[same as prior period, unchanged from 0001327567-24-000017:mdna:51]

[0001327567-24-000040:mdna:50]
[same as prior period, unchanged from 0001327567-24-000017:mdna:52]

[0001327567-24-000040:mdna:51]
|  |  |  |  |  |  |  | Three Months Ended October 31, |  |  |  |  |
|  |  |  |  |  |  |  | 2024 |  | 2023 |  | Change |
|  |  |  |  |  |  |  |  |  | Amount |  | Amount |  | Amount |  | % |
|  |  |  |  |  |  |  |  |  | (dollars in millions) |
| Product |  |  |  |  |  |  |  |  | $ | 353.8 |  |  | $ | 341.1 |  |  | $ | 12.7 |  |  | 3.7 | % |

[0001327567-24-000040:mdna:52]
The change in product revenue for the three months ended October 31, 2024 compared to the same period in 2023 represented a modest increase in product sales.

[0001327567-24-000040:mdna:53]
[same as prior period, unchanged from 0001327567-24-000017:mdna:55]

[0001327567-24-000040:mdna:54]
[same as prior period, unchanged from 0001327567-24-000017:mdna:56]

[0001327567-24-000040:mdna:55]
|  |  |  |  |  |  |  | Three Months Ended October 31, |  |  |  |  |
|  |  |  |  |  |  |  | 2024 |  | 2023 |  | Change |
|  |  |  |  |  |  |  |  |  | Amount |  | Amount |  | Amount |  | % |
|  |  |  |  |  |  |  |  |  | (dollars in millions) |
| Subscription |  |  |  |  |  |  |  |  | $ | 1,191.8 |  |  | $ | 988.3 |  |  | $ | 203.5 |  |  | 20.6 | % |
| Support |  |  |  |  |  |  |  |  | 593.2 |  |  | 548.7 |  |  | 44.5 |  |  | 8.1 | % |
| Total subscription and support |  |  |  |  |  |  |  |  | $ | 1,785.0 |  |  | $ | 1,537.0 |  |  | $ | 248.0 |  |  | 16.1 | % |

[0001327567-24-000040:mdna:56]
Subscription and support revenue increased for the three months ended October 31, 2024 compared to the same period in 2023 primarily due to increased demand for our subscription and support offerings from our end-customers. The mix between subscription revenue and support revenue will fluctuate over time, depending on the introduction of new subscription offerings, renewals of support services, and our ability to increase sales to new and existing end-customers.

[0001327567-24-000040:mdna:57]
[same as prior period, unchanged from 0001327567-24-000017:mdna:48]

[0001327567-24-000040:mdna:58]
[same as prior period, unchanged from 0001327567-24-000017:mdna:60]

[0001327567-24-000040:mdna:59]
|  |  |  |  |  |  |  | Three Months Ended October 31, |  |  |  |  |
|  |  |  |  |  |  |  | 2024 |  | 2023 |  | Change |
|  |  |  |  |  |  |  |  |  | Amount |  | Amount |  | Amount |  | % |
|  |  |  |  |  |  |  |  |  | (dollars in millions) |
| Americas |  |  |  |  |  |  |  |  | $ | 1,442.1 |  |  | $ | 1,286.6 |  |  | $ | 155.5 |  |  | 12.1 | % |
| EMEA |  |  |  |  |  |  |  |  | 441.4 |  |  | 364.9 |  |  | 76.5 |  |  | 21.0 | % |
| APAC |  |  |  |  |  |  |  |  | 255.3 |  |  | 226.6 |  |  | 28.7 |  |  | 12.7 | % |
| Total revenue |  |  |  |  |  |  |  |  | $ | 2,138.8 |  |  | $ | 1,878.1 |  |  | $ | 260.7 |  |  | 13.9 | % |

[0001327567-24-000040:mdna:60]
Revenue from the Americas, Europe, the Middle East, and Africa (“EMEA”), and Asia Pacific and Japan (“APAC”), increased for the three months ended October 31, 2024 compared to the same period in 2023 as we continued to increase investment in our global sales force in order to support our growth and innovation, with the Americas contributing the highest increase in revenue due to its larger scale.

[0001327567-24-000040:mdna:61]
[same as prior period, unchanged from 0001327567-24-000017:mdna:63]

[0001327567-24-000040:mdna:62]
[same as prior period, unchanged from 0001327567-24-000017:mdna:64]

[0001327567-24-000040:mdna:63]
[same as prior period, unchanged from 0001327567-24-000017:mdna:65]

[0001327567-24-000040:mdna:64]
[same as prior period, unchanged from 0001327567-24-000017:mdna:66]

[0001327567-24-000040:mdna:65]
|  |  |  |  |  |  |  | Three Months Ended October 31, |  |  |  |  |
|  |  |  |  |  |  |  | 2024 |  | 2023 |  | Change |
|  |  |  |  |  |  |  |  |  | Amount |  | Amount |  | Amount |  | % |
|  |  |  |  |  |  |  |  |  | (dollars in millions) |
| Cost of product revenue |  |  |  |  |  |  |  |  | $ | 75.0 |  |  | $ | 77.4 |  |  | $ | (2.4) |  |  | (3.1) | % |

[0001327567-24-000040:mdna:66]
Cost of product revenue was relatively flat for the three months ended October 31, 2024 compared to the same period in 2023.

[0001327567-24-000040:mdna:67]
[same as prior period, unchanged from 0001327567-24-000017:mdna:59]

[0001327567-24-000040:mdna:68]
[same as prior period, unchanged from 0001327567-24-000017:mdna:70]

[0001327567-24-000040:mdna:69]
Cost of subscription and support revenue includes personnel costs for our global customer support and technical operations organizations, data center and cloud hosting service costs, third-party professional services costs, amortization of acquired intangible assets and capitalized software development costs, customer support and repair costs, and shared costs. We expect our cost of subscription and support revenue to increase as our installed end-customer base grows and adoption of our cloud-based subscription offerings increases.

[0001327567-24-000040:mdna:70]
|  |  |  |  |  |  |  | Three Months Ended October 31, |  |  |  |  |
|  |  |  |  |  |  |  | 2024 |  | 2023 |  | Change |
|  |  |  |  |  |  |  |  |  | Amount |  | Amount |  | Amount |  | % |
|  |  |  |  |  |  |  |  |  | (dollars in millions) |
| Cost of subscription and support revenue |  |  |  |  |  |  |  |  | $ | 479.1 |  |  | $ | 395.4 |  |  | $ | 83.7 |  |  | 21.2 | % |

[0001327567-24-000040:mdna:71]
Cost of subscription and support revenue increased for the three months ended October 31, 2024 compared to the same period in 2023 primarily due to increased costs to support the growth of our subscription and support offerings. Cloud hosting service costs, which support our cloud-based subscription offerings, increased $39.8 million for the three months ended October 31, 2024 compared to the same period in 2023. Personnel costs grew $11.3 million for the three months ended October 31, 2024 compared to the same period in 2023, primarily due to headcount growth. The increase in cost of subscription and support revenue was further driven by increased professional services expense.

[0001327567-24-000040:mdna:72]
[same as prior period, unchanged from 0001327567-24-000017:mdna:74]

[0001327567-24-000040:mdna:73]
[same as prior period, unchanged from 0001327567-24-000017:mdna:75]

[0001327567-24-000040:mdna:74]
|  |  |  | Three Months Ended October 31, |
|  |  |  |  |  | 2024 |  | 2023 |
|  |  |  |  |  |  |  |  |  | Amount |  | Gross Margin |  | Amount |  | Gross Margin |
|  |  |  |  |  |  |  |  |  | (dollars in millions) |
| Product |  |  |  |  |  |  |  |  | $ | 278.8 |  |  | 78.8 | % |  | $ | 263.7 |  |  | 77.3 | % |
| Subscription and support |  |  |  |  |  |  |  |  | 1,305.9 |  |  | 73.2 | % |  | 1,141.6 |  |  | 74.3 | % |
| Total gross profit |  |  |  |  |  |  |  |  | $ | 1,584.7 |  |  | 74.1 | % |  | $ | 1,405.3 |  |  | 74.8 | % |

[0001327567-24-000040:mdna:75]
Product gross margin increased for the three months ended October 31, 2024 compared to the same period in 2023 primarily due to favorable hardware product mix and lower other product costs.

[0001327567-24-000040:mdna:76]
Subscription and support gross margin decreased for the three months ended October 31, 2024 compared to the same period in 2023 primarily due to an increase in costs related to our cloud-based offerings.

[0001327567-24-000040:mdna:77]
[same as prior period, unchanged from 0001327567-24-000017:mdna:69]

[0001327567-24-000040:mdna:78]
[same as prior period, unchanged from 0001327567-24-000017:mdna:80]

[0001327567-24-000040:mdna:79]
Our operating expenses consist of research and development, sales and marketing, and general and administrative expenses. Personnel costs are the most significant component of operating expenses and consist of salaries, benefits, bonuses, share-based compensation, travel and entertainment, and with regard to sales and marketing expense, sales commissions. Our operating expenses also include shared costs, which consist of certain facilities, depreciation, benefits, recruiting, and information technology costs that we allocate based on headcount to each department. We expect operating expenses generally to increase in absolute dollars and to decrease over the long term as a percentage of revenue as we continue to scale our business. As of October 31, 2024, we expect to recognize approximately $2.2 billion of share-based compensation expense over a weighted-average period of approximately 2.5 years, excluding additional share-based compensation expense related to any future grants of share-based awards. Share-based compensation expense is generally recognized on a straight-line basis over the requisite service periods of the awards.

[0001327567-24-000040:mdna:80]
[same as prior period, unchanged from 0001327567-24-000017:mdna:82]

[0001327567-24-000040:mdna:81]
[same as prior period, unchanged from 0001327567-24-000017:mdna:83]

[0001327567-24-000040:mdna:82]
|  |  |  |  |  |  |  | Three Months Ended October 31, |  |  |  |  |
|  |  |  |  |  |  |  | 2024 |  | 2023 |  | Change |
|  |  |  |  |  |  |  |  |  | Amount |  | Amount |  | Amount |  | % |
|  |  |  |  |  |  |  |  |  | (dollars in millions) |
| Research and development |  |  |  |  |  |  |  |  | $ | 480.4 |  |  | $ | 409.5 |  |  | $ | 70.9 |  |  | 17.3 | % |

[0001327567-24-000040:mdna:83]
Research and development expense increased for the three months ended October 31, 2024 compared to the same period in 2023 primarily due to increased personnel costs, which grew $49.0 million, largely due to headcount growth. The remaining increase in research and development expense was further driven by increased shared costs.

[0001327567-24-000040:mdna:84]
[same as prior period, unchanged from 0001327567-24-000017:mdna:86]

[0001327567-24-000040:mdna:85]
[same as prior period, unchanged from 0001327567-24-000017:mdna:87]

[0001327567-24-000040:mdna:86]
|  |  |  |  |  |  |  | Three Months Ended October 31, |  |  |  |  |
|  |  |  |  |  |  |  | 2024 |  | 2023 |  | Change |
|  |  |  |  |  |  |  |  |  | Amount |  | Amount |  | Amount |  | % |
|  |  |  |  |  |  |  |  |  | (dollars in millions) |
| Sales and marketing |  |  |  |  |  |  |  |  | $ | 720.1 |  |  | $ | 660.5 |  |  | $ | 59.6 |  |  | 9.0 | % |

[0001327567-24-000040:mdna:87]
Sales and marketing expense increased for the three months ended October 31, 2024 compared to the same period in 2023 primarily due to increased personnel costs, which grew $57.6 million, largely due to headcount growth.

[0001327567-24-000040:mdna:88]
[same as prior period, unchanged from 0001327567-24-000017:mdna:79]

[0001327567-24-000040:mdna:89]
[same as prior period, unchanged from 0001327567-24-000017:mdna:91]

[0001327567-24-000040:mdna:90]
General and administrative expense consists primarily of personnel costs and shared costs for our executive, finance, human resources, information technology, and legal organizations, and professional services costs, which consist primarily of legal, auditing, accounting, and other consulting costs. General and administrative expense also includes change in fair value of contingent consideration liability. We expect general and administrative expense to increase in absolute dollars over time as we increase the size of our general and administrative organizations and incur additional costs to support our business growth, although our general and administrative expense may fluctuate as a percentage of total revenue.

[0001327567-24-000040:mdna:91]
|  |  |  |  |  |  |  | Three Months Ended October 31, |  |  |  |  |
|  |  |  |  |  |  |  | 2024 |  | 2023 |  | Change |
|  |  |  |  |  |  |  |  |  | Amount |  | Amount |  | Amount |  | % |
|  |  |  |  |  |  |  |  |  | (dollars in millions) |
| General and administrative |  |  |  |  |  |  |  |  | $ | 97.7 |  |  | $ | 120.1 |  |  | $ | (22.4) |  |  | (18.7) | % |

[0001327567-24-000040:mdna:92]
General and administrative expense decreased for the three months ended October 31, 2024 compared to the same period in 2023 primarily due to a release of previously accrued litigation-related charge of $43.0 million and decreased professional services expense during the three months ended October 31, 2024, partially offset by increased personnel costs, which grew $15.1 million, largely due to increased share-based compensation, and increased acquisition-related costs, including change in fair value of contingent consideration liability.

[0001327567-24-000040:mdna:93]
[same as prior period, unchanged from 0001327567-24-000017:mdna:95]

[0001327567-24-000040:mdna:94]
Interest expense primarily consists of interest expense related to our 0.375% Convertible Senior Notes due 2025 (the “2025 Notes”).

[0001327567-24-000040:mdna:95]
|  |  |  |  |  | Three Months Ended October 31, |  |  |
|  |  |  |  |  |  |  | 2024 |  | 2023 |  | Change |
|  |  |  |  |  |  |  |  |  | Amount |  | Amount |  | Amount |  | % |
|  |  |  |  |  |  |  |  |  | (dollars in millions) |
| Interest expense |  |  |  |  |  |  |  |  | $ | 1.2 |  |  | $ | 2.9 |  |  | $ | (1.7) |  |  | (58.6) | % |

[0001327567-24-000040:mdna:96]
Interest expense decreased for the three months ended October 31, 2024 compared to the same period in 2023 primarily due to early conversions of our 2025 Notes. Refer to Note 9. Debt in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information on the Notes.

[0001327567-24-000040:mdna:97]
[same as prior period, unchanged from 0001327567-24-000017:mdna:99]

[0001327567-24-000040:mdna:98]
[same as prior period, unchanged from 0001327567-24-000017:mdna:100]

[0001327567-24-000040:mdna:99]
|  |  |  |  |  | Three Months Ended October 31, |  |  |
|  |  |  |  |  |  |  | 2024 |  | 2023 |  | Change |
|  |  |  |  |  |  |  |  |  | Amount |  | Amount |  | Amount |  | % |
|  |  |  |  |  |  |  |  |  | (dollars in millions) |
| Other income, net |  |  |  |  |  |  |  |  | $ | 83.3 |  |  | $ | 70.3 |  |  | $ | 13.0 |  |  | 18.5 | % |

[0001327567-24-000040:mdna:100]
Other income, net increased for the three months ended October 31, 2024 compared to the same period in 2023 primarily due to higher interest income as a result of higher average cash, cash equivalent, and investment balances for the three months ended October 31, 2024 compared to the same period in 2023. The increase was further driven by increased gains from our non-designated derivative instruments and investments, partially offset by increased foreign currency exchange losses for the three months ended October 31, 2024 compared to the same period in 2023.

[0001327567-24-000040:mdna:101]
[same as prior period, unchanged from 0001327567-24-000017:mdna:90]

[0001327567-24-000040:mdna:102]
PROVISION FOR INCOME TAXES

[0001327567-24-000040:mdna:103]
Provision for income taxes consists primarily of U.S. taxes, foreign income taxes, and withholding taxes. Our provision for income taxes during the fiscal quarter ended October 31, 2024 was offset primarily by excess tax benefits from share-based compensation. We regularly assess the need for a valuation allowance on our deferred tax assets. In making this assessment, we consider both positive and negative evidence related to the likelihood of realization of the deferred tax assets to determine, based on the weight of available evidence, whether it is more likely than not that some or all the deferred tax assets will not be realized. The assessment requires significant judgment and is performed for each of the applicable jurisdictions. Based on our analysis of all positive and negative evidence during the fiscal quarter ended October 31, 2024, we continue to maintain a valuation allowance for our California deferred tax assets due to the uncertainty regarding realizability of these deferred tax assets as they have not met the “more likely than not” realization criterion. We expect future research and development tax credit generation in California to exceed our ability to use the existing tax credits.

[0001327567-24-000040:mdna:104]
|  |  |  |  |  |  |  | Three Months Ended October 31, |  |  |  |  |
|  |  |  |  |  |  |  | 2024 |  | 2023 |  | Change |
|  |  |  |  |  |  |  |  |  | Amount |  | Amount |  | Amount |  | % |
|  |  |  |  |  |  |  |  |  | (dollars in millions) |
| Provision for income taxes |  |  |  |  |  |  |  |  | $ | 17.9 |  |  | $ | 88.4 |  |  | $ | (70.5) |  |  | (79.8) | % |
| Effective tax rate |  |  |  |  |  |  |  |  | 4.9 | % |  | 31.3 | % |  |  |  |  |

[0001327567-24-000040:mdna:105]
Our provision for income taxes for the three months ended October 31, 2024 and 2023 was primarily due to U.S. federal and state income taxes, withholding taxes, and foreign income taxes. Our effective tax rate decreased for the three months ended October 31, 2024 compared to the same period in 2023 primarily due to deferred tax benefits. During the three months ended October 31, 2023, our deferred tax benefits were significantly limited due to our valuation allowance on U.S. federal, U.S. states other than California, and United Kingdom deferred tax assets which was subsequently released in the second quarter of fiscal 2024. Refer to Note 13. Income Taxes in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information.

[0001327567-24-000040:mdna:106]
[same as prior period, unchanged from 0001327567-24-000017:mdna:109]

[0001327567-24-000040:mdna:107]
|  | October 31, 2024 |  | July 31, 2024 |
|  | (in millions) |
| Working capital (deficit) | $ | (1,160.0) |  |  | $ | (833.0) |  |
| Cash, cash equivalents, and investments: |  |  |  |
| Cash and cash equivalents | $ | 2,282.8 |  |  | $ | 1,535.2 |  |
| Investments | 5,227.9 |  |  | 5,216.8 |  |
| Total cash, cash equivalents, and investments | $ | 7,510.7 |  |  | $ | 6,752.0 |  |

[0001327567-24-000040:mdna:108]
As of October 31, 2024, our total cash, cash equivalents, and investments of $7.5 billion were held for general corporate purposes. As of October 31, 2024, we had no unremitted earnings when evaluating our outside basis difference relating to our U.S. investment in foreign subsidiaries. However, there could be local withholding taxes due to various foreign countries if certain lower tier earnings are distributed. Withholding taxes that would be payable upon remittance of these lower tier earnings are not material.

[0001327567-24-000040:mdna:109]
Our cash tax payments have increased and we expect this trend to continue as a result of our increased profitability and utilization of our net operating loss carryforwards and credits.

[0001327567-24-000040:mdna:110]
[same as prior period, unchanged from 0001327567-24-000017:mdna:103]

[0001327567-24-000040:mdna:111]
[same as prior period, unchanged from 0001327567-24-000017:mdna:115]

[0001327567-24-000040:mdna:112]
In June 2020, we issued the 2025 Notes with an aggregate principal amount of $2.0 billion. The 2025 Notes mature on June 1, 2025; however, under certain circumstances, holders may surrender their 2025 Notes for conversion prior to the maturity date. Upon conversion of the 2025 Notes, we will pay cash equal to the aggregate principal amount of the 2025 Notes to be converted, and, at our election, we will pay or deliver cash and/or shares of our common stock for the amount of our conversion obligation in excess of the aggregate principal amount of the 2025 Notes being converted. During the three months ended October 31, 2024, we repaid in cash $319.0 million in aggregate principal amount of the 2025 Notes and issued 2.3 million shares of common stock to the holders for the conversion value in excess of the principal amount of the 2025 Notes converted, which were fully offset by shares we received from our exercise of the associated note hedges. Subsequent to October 31, 2024, through the filing date of this Quarterly Report on Form 10-Q, $106.0 million in aggregate principal amount of the 2025 Notes was converted or had been submitted by the holders for conversion and will settle during the fiscal quarter ending January 31, 2025.

[0001327567-24-000040:mdna:113]
The sale price condition for the 2025 Notes was met during the fiscal quarter ended October 31, 2024, and as a result, holders may convert their 2025 Notes during the fiscal quarter ending January 31, 2025. If all of the holders convert their 2025 Notes during this period, we would be obligated to settle the $646.6 million principal amount of the 2025 Notes in cash. We believe that our cash provided by operating activities, our existing cash, cash equivalents, and investments, and existing sources of and access to financing will be sufficient to meet our anticipated cash needs should the holders choose to convert their 2025 Notes during the fiscal quarter ending January 31, 2025 or hold the 2025 Notes until maturity on June 1, 2025. As of October 31, 2024, $646.6 million of our 2025 Notes remained outstanding. Refer to Note 9. Debt in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information on the 2025 Notes.

[0001327567-24-000040:mdna:114]
In April 2023, we entered into a credit agreement (the “Credit Agreement”) that provides for a $400.0 million unsecured revolving credit facility (the “Credit Facility”), with an option to increase the amount of the Credit Facility by up to an additional $350.0 million, subject to certain conditions. The interest rates and commitment fees are also subject to upward and downward adjustments based on our progress towards the achievement of certain sustainability goals related to greenhouse gas emissions. As of October 31, 2024, there were no amounts outstanding, and we were in compliance with all covenants under the Credit Agreement. Refer to Note 9. Debt in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information on the Credit Agreement.

[0001327567-24-000040:mdna:115]
[same as prior period, unchanged from 0001327567-24-000017:mdna:119]

[0001327567-24-000040:mdna:116]
In February 2019, our board of directors authorized a $1.0 billion share repurchase program. In December 2020, August 2021, August 2022, November 2023, and August 2024, our board of directors authorized additional $700.0 million, $676.1 million, $915.0 million, $316.7 million and $500.0 million increases to this share repurchase program, respectively, bringing the total authorization under this share repurchase program to $4.1 billion. Repurchases will be funded from available working capital and may be made at management’s discretion from time to time. As of October 31, 2024, $1.0 billion remained available for future share repurchases under this repurchase program. The repurchase authorization will expire on December 31, 2025, and may be suspended or discontinued at any time without prior notice. Refer to Note 11. Stockholders’ Equity in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information on this repurchase program.

[0001327567-24-000040:mdna:117]
[same as prior period, unchanged from 0001327567-24-000017:mdna:121]

[0001327567-24-000040:mdna:118]
We have entered into various non-cancelable operating leases, primarily for our offices and data centers, with lease terms expiring through fiscal 2036. As of October 31, 2024, we have total operating lease obligations of $452.5 million recorded on our condensed consolidated balance sheet.

[0001327567-24-000040:mdna:119]
As of October 31, 2024, our commitments to purchase products, components, cloud and other services totaled $4.6 billion. Refer to Note 10. Commitments and Contingencies in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information on these commitments.

[0001327567-24-000040:mdna:120]
Our acquisition of certain IBM QRadar assets on August 31, 2024 included contingent consideration that requires potential future payments through the fiscal quarter ending October 2028. As of October 31, 2024, we have total contingent consideration obligations of $655.2 million recorded on our condensed consolidated balance sheet. Refer to Note 3. Fair Value Measurements and Note 7. Acquisition in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information on these contingent consideration obligations.

[0001327567-24-000040:mdna:121]
[same as prior period, unchanged from 0001327567-24-000017:mdna:114]

[0001327567-24-000040:mdna:122]
[same as prior period, unchanged from 0001327567-24-000017:mdna:125]

[0001327567-24-000040:mdna:123]
The following table summarizes our cash flows for the three months ended October 31, 2024 and 2023:

[0001327567-24-000040:mdna:124]
|  | Three Months Ended October 31, |
|  | 2024 |  | 2023 |
|  | (in millions) |
| Net cash provided by operating activities | $ | 1,509.6 |  |  | $ | 1,526.0 |  |
| Net cash used in investing activities | (543.8) |  |  | (129.0) |  |
| Net cash used in financing activities | (219.7) |  |  | (41.8) |  |
| Net increase in cash, cash equivalents, and restricted cash | $ | 746.1 |  |  | $ | 1,355.2 |  |

[0001327567-24-000040:mdna:125]
[same as prior period, unchanged from 0001327567-24-000017:mdna:128]

[0001327567-24-000040:mdna:126]
[same as prior period, unchanged from 0001327567-24-000017:mdna:129]

[0001327567-24-000040:mdna:127]
[same as prior period, unchanged from 0001327567-24-000017:mdna:130]

[0001327567-24-000040:mdna:128]
[same as prior period, unchanged from 0001327567-24-000017:mdna:131]

[0001327567-24-000040:mdna:129]
Cash provided by operating activities during the three months ended October 31, 2024 was $1.5 billion, a slight decrease of $16.4 million compared to the same period in 2023. The decrease was primarily due to timing of payments and collections during the three months ended October 31, 2024.

[0001327567-24-000040:mdna:130]
[same as prior period, unchanged from 0001327567-24-000017:mdna:133]

[0001327567-24-000040:mdna:131]
[same as prior period, unchanged from 0001327567-24-000017:mdna:134]

[0001327567-24-000040:mdna:132]
Cash used in investing activities during the three months ended October 31, 2024 was $543.8 million, an increase of $414.8 million compared to the same period in 2023. The increase was primarily due to an increase in cash payments for a business acquisition and a decrease in proceeds from sales and maturities of investments, partially offset by a decrease in purchases of investments during the three months ended October 31, 2024.

[0001327567-24-000040:mdna:133]
[same as prior period, unchanged from 0001327567-24-000017:mdna:136]

[0001327567-24-000040:mdna:134]
[same as prior period, unchanged from 0001327567-24-000017:mdna:137]

[0001327567-24-000040:mdna:135]
Cash used in financing activities during the three months ended October 31, 2024 was $219.7 million, an increase of $177.9 million compared to the same period in 2023. The increase was primarily due to an increase in cash used for early repayments of our 2025 Notes, partially offset by a decrease in cash used to repurchase our common stock which did not recur during the three months ended October 31, 2024.

[0001327567-24-000040:mdna:136]
[same as prior period, unchanged from 0001327567-24-000017:mdna:124]

[0001327567-24-000040:mdna:137]
[same as prior period, unchanged from 0001327567-24-000017:mdna:140]

[0001327567-24-000040:mdna:138]
[same as prior period, unchanged from 0001327567-24-000017:mdna:141]

[0001327567-24-000040:mdna:139]
We believe the critical accounting estimates discussed under Item 7, “Management’s Discussion and Analysis of Financial Condition and Results of Operations” in our Annual Report on Form 10-K for the fiscal year ended July 31, 2024 reflect our more significant estimates, assumptions, and judgments that have the most significant impact on our condensed consolidated financial statements. There have been no significant changes to our critical accounting estimates as filed in such report, except for the update as described below resulting from our recent acquisition of certain IBM QRadar assets.

[0001327567-24-000040:mdna:140]
BUSINESS COMBINATIONS

[0001327567-24-000040:mdna:141]
We make significant estimates, assumptions, and judgments when valuing goodwill and other purchased intangible assets in connection with the initial purchase price allocation of an acquired business. These estimates are based upon a number of factors, including historical experience, market conditions, and information obtained from the management of the acquired business. Critical estimates in valuing certain intangible assets include, but are not limited to, cash flows that an asset is expected to generate in the future, discount rates, the time and expense that would be necessary to recreate the assets, and the profit margin a market participant would receive. The amounts and useful lives assigned to identified intangible assets impact the amount and timing of future amortization expense.

[0001327567-24-000040:mdna:142]
Our business combination may also involve post-closing payments contingent upon the occurrence of future events and/or certain conditions being met. Critical estimates used in valuing contingent consideration obligations include, but are not limited to, estimated future cash payments related to customers entering into qualified new transactions and risk-adjusted discount rates used to present value the expected cash flows. These estimates and assumptions are required to be updated in order to revalue our contingent consideration liability at the end of each reporting period. Accordingly, subsequent changes in underlying facts and circumstances could result in changes in these estimates and assumptions, which could have a material impact on the estimated future fair values of these obligations.

[0001327567-24-000040:mdna:143]
[same as prior period, unchanged from 0001327567-24-000017:mdna:143]

[0001327567-24-000040:mdna:144]
Refer to “Recently Issued Accounting Pronouncements” in Note 1. Description of Business and Summary of Significant Accounting Policies in Part I, Item 1 of this Quarterly Report on Form 10-Q for a description of recent accounting pronouncements and our expectation of their impact, if any, on our results of operations and financial condition.
