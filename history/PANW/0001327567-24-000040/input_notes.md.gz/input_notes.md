# PANW notes — 0001327567-24-000040


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock

[0001327567-24-000040:notes:1]
Description of Business and Summary of Significant Accounting Policies
Description of Business

[0001327567-24-000040:notes:2]
Palo Alto Networks, Inc. (the “Company,” “we,” “us,” or “our”), headquartered in Santa Clara, California, was incorporated in March 2005 under the laws of the State of Delaware and commenced operations in April 2005. We empower enterprises, organizations, service providers, and government entities to secure their users, networks, clouds, and endpoints by delivering comprehensive cybersecurity backed by artificial intelligence and automation.

[0001327567-24-000040:notes:3]
Basis of Presentation and Principles of Consolidation

[0001327567-24-000040:notes:4]
The accompanying condensed consolidated financial statements have been prepared in conformity with U.S. generally accepted accounting principles (“U.S. GAAP”), consistent in all material respects with those applied in our Annual Report on Form 10-K for the fiscal year ended July 31, 2024, filed with the Securities and Exchange Commission (“SEC”) on September 6, 2024. The condensed consolidated financial statements include our accounts and our wholly owned subsidiaries. All significant intercompany balances and transactions have been eliminated in consolidation.

[0001327567-24-000040:notes:5]
The condensed consolidated financial statements are unaudited but include all adjustments of a normal recurring nature necessary for a fair presentation of our quarterly results. Our condensed consolidated financial statements should be read in conjunction with the audited consolidated financial statements and related notes in our Annual Report on Form 10-K for the fiscal year ended July 31, 2024.

[0001327567-24-000040:notes:6]
Use of Estimates

[0001327567-24-000040:notes:7]
The preparation of condensed consolidated financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the amounts reported and disclosed in the condensed consolidated financial statements and the accompanying notes. We evaluate our estimates on an ongoing basis. Management estimates include, but are not limited to, the standalone selling price for our products and services, share-based compensation, fair value of assets acquired and liabilities assumed in business combinations, fair value of contingent consideration liability, the assessment of recoverability of our intangibles and goodwill, valuation allowance against deferred tax assets, manufacturing partner and supplier liabilities, deferred contract cost benefit period, and loss contingencies. We base our estimates on assumptions, both historical and forward looking, that we believe are reasonable. Actual results could differ materially from those estimates due to risks and uncertainties, including uncertainty in the current economic environment.

[0001327567-24-000040:notes:8]
Summary of Significant Accounting Policies

[0001327567-24-000040:notes:9]
There have been no material changes to our significant accounting policies as of and for the three months ended October 31, 2024, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended July 31, 2024, except for the update to the disclosure of our accounting policies as described below resulting from our recent acquisition of certain QRadar assets from International Business Machines Corporation (“IBM”). Refer to Note 7. Acquisition for additional information.

[0001327567-24-000040:notes:10]
Business Combinations

[0001327567-24-000040:notes:11]
We include the results of operations of the businesses that we acquire as of the respective dates of acquisition. We allocate the fair value of the purchase price of our acquisitions to the assets acquired and liabilities assumed, including contingent consideration, generally based on their estimated fair values. The excess of the purchase price over the fair values of these identifiable assets and liabilities is recorded as goodwill. Additional information existing as of the acquisition date but unknown to us may become known during the remainder of the measurement period, not to exceed 12 months from the acquisition date, which may result in changes to the amounts and allocations recorded.

[0001327567-24-000040:notes:12]
Contingent consideration obligations incurred in connection with a business combination are recorded at fair value on the acquisition date and remeasured at each subsequent reporting period until the related contingencies have been resolved, with the change in fair value recognized in general and administrative expense on our condensed consolidated statements of operations. Payments not made soon after the acquisition date to settle a contingent consideration liability are classified as cash flows from financing activities up to the amount of the contingent consideration liability recognized at the acquisition date.

[0001327567-24-000040:notes:13]
Recently Issued Accounting Pronouncements

[0001327567-24-000040:notes:14]
Segment Reporting

[0001327567-24-000040:notes:15]
In November 2023, the Financial Accounting Standards Board (“FASB”) issued authoritative guidance that expands annual and interim disclosure requirements for reportable segments, primarily through enhanced disclosures about significant segment expenses. The standard is effective for our annual period in fiscal 2025 and interim periods beginning in the first quarter of fiscal 2026, and requires retrospective application for all prior periods presented in the financial statements. Early adoption is permitted. We are currently evaluating the impact of this standard on our disclosures in the consolidated financial statements.

[0001327567-24-000040:notes:16]
Income Tax Disclosures

[0001327567-24-000040:notes:17]
In December 2023, the FASB issued authoritative guidance that requires consistent categories and greater disaggregation of information in the effective tax rate reconciliation and additional disclosures of income taxes paid by jurisdiction. The standard is effective for our annual period in fiscal 2026 and could be applied either prospectively or retrospectively. Early adoption is permitted. We are currently evaluating the impact of this standard on our disclosures in the consolidated financial statements.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001327567-24-000040:notes:18]
[same as prior period, unchanged from 0001327567-24-000017:notes:17]

[0001327567-24-000040:notes:19]
[same as prior period, unchanged from 0001327567-24-000017:notes:18]

[0001327567-24-000040:notes:20]
|  |  |  | Three Months Ended October 31, |
|  |  |  |  |  | 2024 |  | 2023 |
| Revenue: |  |  |  |  |  |  |  |
| Americas |  |  |  |  |  |  |  |
| United States |  |  |  |  | $ | 1,344.1 |  |  | $ | 1,204.3 |  |
| Other Americas |  |  |  |  | 98.0 |  |  | 82.3 |  |
| Total Americas |  |  |  |  | 1,442.1 |  |  | 1,286.6 |  |
| Europe, the Middle East, and Africa (“EMEA”) |  |  |  |  | 441.4 |  |  | 364.9 |  |
| Asia Pacific and Japan (“APAC”) |  |  |  |  | 255.3 |  |  | 226.6 |  |
| Total revenue |  |  |  |  | $ | 2,138.8 |  |  | $ | 1,878.1 |  |

[0001327567-24-000040:notes:21]
[same as prior period, unchanged from 0001327567-24-000017:notes:20]

[0001327567-24-000040:notes:22]
|  |  |  | Three Months Ended October 31, |
|  |  |  |  |  | 2024 |  | 2023 |
| Revenue: |  |  |  |  |  |  |  |
| Product |  |  |  |  | $ | 353.8 |  |  | $ | 341.1 |  |
| Subscription and support |  |  |  |  |  |  |  |
| Subscription |  |  |  |  | 1,191.8 |  |  | 988.3 |  |
| Support |  |  |  |  | 593.2 |  |  | 548.7 |  |
| Total subscription and support |  |  |  |  | 1,785.0 |  |  | 1,537.0 |  |
| Total revenue |  |  |  |  | $ | 2,138.8 |  |  | $ | 1,878.1 |  |

[0001327567-24-000040:notes:23]
[same as prior period, unchanged from 0001327567-24-000017:notes:22]

[0001327567-24-000040:notes:24]
During the three months ended October 31, 2024 and 2023, we recognized approximately $1.6 billion and $1.4 billion of revenue pertaining to amounts that were deferred as of July 31, 2024 and 2023, respectively.

[0001327567-24-000040:notes:25]
[same as prior period, unchanged from 0001327567-24-000017:notes:24]

[0001327567-24-000040:notes:26]
Remaining performance obligations were $12.6 billion as of October 31, 2024, of which we expect to recognize as revenue approximately $5.9 billion over the next 12 months and the remainder thereafter.


## us-gaap:FairValueDisclosuresTextBlock

[0001327567-24-000040:notes:27]
Fair Value Measurements
The following table presents our financial assets and liabilities measured at fair value on a recurring basis as of October 31, 2024 and July 31, 2024 (in millions):

[0001327567-24-000040:notes:28]
|  | October 31, 2024 |  | July 31, 2024 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Cash equivalents: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | $ | 1,105.3 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,105.3 |  |  | $ | 494.0 |  |  | $ | — |  |  | $ | — |  |  | $ | 494.0 |  |
| Commercial paper | — |  |  | 228.7 |  |  | — |  |  | 228.7 |  |  | — |  |  | 299.6 |  |  | — |  |  | 299.6 |  |
| Corporate debt securities | — |  |  | 34.2 |  |  | — |  |  | 34.2 |  |  | — |  |  | 18.2 |  |  | — |  |  | 18.2 |  |
| U.S. government and agency securities | — |  |  | 74.8 |  |  | — |  |  | 74.8 |  |  | — |  |  | 149.6 |  |  | — |  |  | 149.6 |  |
| Total cash equivalents | 1,105.3 |  |  | 337.7 |  |  | — |  |  | 1,443.0 |  |  | 494.0 |  |  | 467.4 |  |  | — |  |  | 961.4 |  |
| Short-term investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Certificates of deposit | — |  |  | 15.7 |  |  | — |  |  | 15.7 |  |  | — |  |  | 20.6 |  |  | — |  |  | 20.6 |  |
| Commercial paper | — |  |  | 36.1 |  |  | — |  |  | 36.1 |  |  | — |  |  | 79.9 |  |  | — |  |  | 79.9 |  |
| Corporate debt securities | — |  |  | 1,037.5 |  |  | — |  |  | 1,037.5 |  |  | — |  |  | 935.9 |  |  | — |  |  | 935.9 |  |
| U.S. government and agency securities | — |  |  | 4.2 |  |  | — |  |  | 4.2 |  |  | — |  |  | 2.7 |  |  | — |  |  | 2.7 |  |
| Non-U.S. government and agency securities | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 4.2 |  |  | — |  |  | 4.2 |  |
| Asset-backed securities | — |  |  | 14.7 |  |  | — |  |  | 14.7 |  |  | — |  |  | 0.3 |  |  | — |  |  | 0.3 |  |
| Total short-term investments | — |  |  | 1,108.2 |  |  | — |  |  | 1,108.2 |  |  | — |  |  | 1,043.6 |  |  | — |  |  | 1,043.6 |  |
| Long-term investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | — |  |  | 3,095.2 |  |  | — |  |  | 3,095.2 |  |  | — |  |  | 3,151.3 |  |  | — |  |  | 3,151.3 |  |
| U.S. government and agency securities | — |  |  | 17.7 |  |  | — |  |  | 17.7 |  |  | — |  |  | 19.0 |  |  | — |  |  | 19.0 |  |
| Non-U.S. government and agency securities | — |  |  | 39.1 |  |  | — |  |  | 39.1 |  |  | — |  |  | 54.4 |  |  | — |  |  | 54.4 |  |
| Asset-backed securities | — |  |  | 967.7 |  |  | — |  |  | 967.7 |  |  | — |  |  | 948.5 |  |  | — |  |  | 948.5 |  |
| Total long-term investments | — |  |  | 4,119.7 |  |  | — |  |  | 4,119.7 |  |  | — |  |  | 4,173.2 |  |  | — |  |  | 4,173.2 |  |
| Prepaid expenses and other current assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency forward contracts | — |  |  | 5.3 |  |  | — |  |  | 5.3 |  |  | — |  |  | 4.1 |  |  | — |  |  | 4.1 |  |
| Total prepaid expenses and other current assets | — |  |  | 5.3 |  |  | — |  |  | 5.3 |  |  | — |  |  | 4.1 |  |  | — |  |  | 4.1 |  |
| Other assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency forward contracts | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 0.1 |  |  | — |  |  | 0.1 |  |
| Total other assets | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 0.1 |  |  | — |  |  | 0.1 |  |
| Total assets measured at fair value | $ | 1,105.3 |  |  | $ | 5,570.9 |  |  | $ | — |  |  | $ | 6,676.2 |  |  | $ | 494.0 |  |  | $ | 5,688.4 |  |  | $ | — |  |  | $ | 6,182.4 |  |

[0001327567-24-000040:notes:29]
|  | October 31, 2024 |  | July 31, 2024 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Accrued and other liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency forward contracts | $ | — |  |  | $ | 11.8 |  |  | $ | — |  |  | $ | 11.8 |  |  | $ | — |  |  | $ | 15.3 |  |  | $ | — |  |  | $ | 15.3 |  |
| Contingent consideration | — |  |  | — |  |  | 238.5 |  |  | 238.5 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Total accrued and other liabilities | — |  |  | 11.8 |  |  | 238.5 |  |  | 250.3 |  |  | — |  |  | 15.3 |  |  | — |  |  | 15.3 |  |
| Other long-term liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency forward contracts | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 0.9 |  |  | — |  |  | 0.9 |  |
| Contingent consideration | — |  |  | — |  |  | 416.7 |  |  | 416.7 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Total other long-term liabilities | — |  |  | — |  |  | 416.7 |  |  | 416.7 |  |  | — |  |  | 0.9 |  |  | — |  |  | 0.9 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 11.8 |  |  | $ | 655.2 |  |  | $ | 667.0 |  |  | $ | — |  |  | $ | 16.2 |  |  | $ | — |  |  | $ | 16.2 |  |

[0001327567-24-000040:notes:30]
The fair value of contingent consideration liability is estimated using a discounted cash flow valuation technique. We consider the fair value of our contingent consideration liability to be a Level 3 measurement as we use unobservable inputs in determining discounted cash flows to estimate the fair value. The significant unobservable inputs include an estimate of future cash payments related to customers entering into qualified new transactions as well as a risk-adjusted discount rate used to present value the expected cash flows. A significant change in any of these assumptions could have a material impact to the fair value of our contingent consideration liability.

[0001327567-24-000040:notes:31]
The following table presents a reconciliation of our contingent consideration liability (in millions):

[0001327567-24-000040:notes:32]
|  |  |  |  |  | Three Months Ended October 31, 2024 |  |  |
| Contingent consideration liability at the beginning of the period |  |  |  |  | $ | — |  |  |  |
| Initial valuation on the acquisition date |  |  |  |  | 648.9 |  |  |  |
| Change in fair value |  |  |  |  | 6.3 |  |  |  |
| Contingent consideration liability at the end of the period |  |  |  |  | $ | 655.2 |  |  |  |

[0001327567-24-000040:notes:33]
The total estimated fair value of our financing receivables approximates their carrying amounts as of October 31, 2024 and July 31, 2024. We consider the fair value of our financing receivables to be a Level 3 measurement as we use unobservable inputs in determining discounted cash flows to estimate the fair value.

[0001327567-24-000040:notes:34]
Refer to Note 9. Debt for the carrying amount and estimated fair value of our convertible senior notes as of October 31, 2024 and July 31, 2024.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001327567-24-000040:notes:35]
Cash Equivalents and Investments
Available-for-sale Debt Securities

[0001327567-24-000040:notes:36]
The following tables summarize the amortized cost, unrealized gains and losses, and fair value of our available-for-sale debt securities as of October 31, 2024 and July 31, 2024 (in millions):

[0001327567-24-000040:notes:37]
|  | October 31, 2024 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | $ | 228.7 |  |  | $ | — |  |  | $ | — |  |  | $ | 228.7 |  |
| Corporate debt securities | 34.2 |  |  | — |  |  | — |  |  | 34.2 |  |
| U.S. government and agency securities | 74.8 |  |  | — |  |  | — |  |  | 74.8 |  |
| Total available-for-sale cash equivalents | $ | 337.7 |  |  | $ | — |  |  | $ | — |  |  | $ | 337.7 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 15.7 |  |  | $ | — |  |  | $ | — |  |  | $ | 15.7 |  |
| Commercial paper | 36.1 |  |  | — |  |  | — |  |  | 36.1 |  |
| Corporate debt securities | 4,115.2 |  |  | 25.3 |  |  | (7.8) |  |  | 4,132.7 |  |
| U.S. government and agency securities | 21.9 |  |  | — |  |  | — |  |  | 21.9 |  |
| Non-U.S. government and agency securities | 38.6 |  |  | 0.5 |  |  | — |  |  | 39.1 |  |
| Asset-backed securities | 976.1 |  |  | 7.1 |  |  | (0.8) |  |  | 982.4 |  |
| Total available-for-sale investments | $ | 5,203.6 |  |  | $ | 32.9 |  |  | $ | (8.6) |  |  | $ | 5,227.9 |  |

[0001327567-24-000040:notes:38]
|  | July 31, 2024 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | $ | 299.6 |  |  | $ | — |  |  | $ | — |  |  | $ | 299.6 |  |
| Corporate debt securities | 18.2 |  |  | — |  |  | — |  |  | 18.2 |  |
| U.S. government and agency securities | 149.6 |  |  | — |  |  | — |  |  | 149.6 |  |
| Total available-for-sale cash equivalents | $ | 467.4 |  |  | $ | — |  |  | $ | — |  |  | $ | 467.4 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 20.6 |  |  | $ | — |  |  | $ | — |  |  | $ | 20.6 |  |
| Commercial paper | 79.9 |  |  | 0.1 |  |  | (0.1) |  |  | 79.9 |  |
| Corporate debt securities | 4,065.5 |  |  | 28.3 |  |  | (6.6) |  |  | 4,087.2 |  |
| U.S. government and agency securities | 21.9 |  |  | — |  |  | (0.2) |  |  | 21.7 |  |
| Non-U.S. government and agency securities | 57.9 |  |  | 0.7 |  |  | — |  |  | 58.6 |  |
| Asset-backed securities | 943.1 |  |  | 6.3 |  |  | (0.6) |  |  | 948.8 |  |
| Total available-for-sale investments | $ | 5,188.9 |  |  | $ | 35.4 |  |  | $ | (7.5) |  |  | $ | 5,216.8 |  |

[0001327567-24-000040:notes:39]
As of October 31, 2024, the gross unrealized losses that have been in a continuous unrealized loss position for less than 12 months were $7.3 million, which were related to $1.2 billion of available-for-sale debt securities, and the gross unrealized losses that have been in a continuous unrealized loss position for more than 12 months were $1.3 million, which were related to $372.5 million of available-for-sale debt securities. As of July 31, 2024 the gross unrealized losses that have been in a continuous unrealized loss position for less than 12 months were $1.5 million, which were related to $949.4 million of available-for-sale debt securities, and the gross unrealized losses that have been in a continuous unrealized loss position for more than 12 months were $6.0 million, which were related to $915.3 million of available-for-sale debt securities.

[0001327567-24-000040:notes:40]
Unrealized losses related to our available-for-sale debt securities are primarily due to interest rate fluctuations as opposed to credit quality. We do not intend to sell any of the securities in an unrealized loss position and it is not likely that we would be required to sell these securities before recovery of their amortized cost basis, which may be at maturity. We did not recognize any credit losses related to our available-for-sale debt securities during the three months ended October 31, 2024 and 2023.

[0001327567-24-000040:notes:41]
The following table summarizes the amortized cost and fair value of our available-for-sale debt securities as of October 31, 2024, by contractual years-to-maturity (in millions):

[0001327567-24-000040:notes:42]
|  | Amortized Cost |  | Fair Value |
| Due within one year | $ | 1,445.9 |  |  | $ | 1,445.9 |  |
| Due between one and three years | 1,843.2 |  |  | 1,853.4 |  |
| Due between three and five years | 1,925.5 |  |  | 1,937.9 |  |
| Due between five and ten years | 217.7 |  |  | 218.2 |  |
| Due after ten years | 109.0 |  |  | 110.2 |  |
| Total | $ | 5,541.3 |  |  | $ | 5,565.6 |  |

[0001327567-24-000040:notes:43]
Marketable Equity Securities

[0001327567-24-000040:notes:44]
Marketable equity securities consist of money market funds and are included in cash and cash equivalents on our condensed consolidated balance sheets. As of October 31, 2024 and July 31, 2024, the carrying values of our marketable equity securities were $1.1 billion and $494.0 million, respectively. There were no unrealized gains or losses recognized for these securities during the three months ended October 31, 2024 and 2023.


## us-gaap:FinancingReceivablesTextBlock

[0001327567-24-000040:notes:45]
Financing Receivables
The following table summarizes our short-term and long-term financing receivables as of October 31, 2024 and July 31, 2024 (in millions):

[0001327567-24-000040:notes:46]
|  | October 31, 2024 |  | July 31, 2024 |
| Short-term financing receivables, gross | $ | 911.6 |  |  | $ | 830.2 |  |
| Unearned income | (99.0) |  |  | (95.7) |  |
| Allowance for credit losses | (7.5) |  |  | (8.6) |  |
| Short-term financing receivables, net | $ | 805.1 |  |  | $ | 725.9 |  |
| Long-term financing receivables, gross | $ | 1,191.5 |  |  | $ | 1,286.4 |  |
| Unearned income | (91.4) |  |  | (94.6) |  |
| Allowance for credit losses | (7.9) |  |  | (9.7) |  |
| Long-term financing receivables, net | $ | 1,092.2 |  |  | $ | 1,182.1 |  |

[0001327567-24-000040:notes:47]
The following table presents amortized cost basis of our financing receivables categorized by internal risk rating and year of origination (in millions):

[0001327567-24-000040:notes:48]
| Internal Risk Rating(1) |  | October 31, 2024 |  | July 31, 2024 |
|  | Fiscal Year of Origination |  |  |  | Fiscal Year of Origination |  |  |
|  | 2025 |  | 2024 |  | 2023 |  | 2022 |  | 2021 |  | Total |  | 2024 |  | 2023 |  | 2022 |  | 2021 |  | Total |
| 1 to 4 |  | $ | 7.4 |  |  | $ | 916.1 |  |  | $ | 387.5 |  |  | $ | 9.9 |  |  | $ | 26.7 |  |  | $ | 1,347.6 |  |  | $ | 885.9 |  |  | $ | 477.3 |  |  | $ | 14.7 |  |  | $ | 44.4 |  |  | $ | 1,422.3 |  |
| 5 to 6 |  | 43.7 |  |  | 330.1 |  |  | 152.3 |  |  | 3.1 |  |  | 1.1 |  |  | 530.3 |  |  | 272.2 |  |  | 172.0 |  |  | 21.1 |  |  | 1.1 |  |  | 466.4 |  |
| 7 to 10 |  | 0.1 |  |  | 2.2 |  |  | 22.9 |  |  | 0.3 |  |  | 9.3 |  |  | 34.8 |  |  | 3.2 |  |  | 25.0 |  |  | 0.3 |  |  | 9.1 |  |  | 37.6 |  |
| Amortized cost basis of financing receivables |  | $ | 51.2 |  |  | $ | 1,248.4 |  |  | $ | 562.7 |  |  | $ | 13.3 |  |  | $ | 37.1 |  |  | $ | 1,912.7 |  |  | $ | 1,161.3 |  |  | $ | 674.3 |  |  | $ | 36.1 |  |  | $ | 54.6 |  |  | $ | 1,926.3 |  |

[0001327567-24-000040:notes:49]
(1)Internal risk ratings are categorized as 1 through 10, with the lowest rating representing the highest quality.

[0001327567-24-000040:notes:50]
There was no significant activity in allowance for credit losses during the three months ended October 31, 2024 and 2023. Past due amounts on financing receivables were not material as of October 31, 2024 and July 31, 2024.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001327567-24-000040:notes:51]
Derivative Instruments
We are exposed to foreign currency exchange risk. Our revenue is primarily transacted in U.S. dollars, however, a portion of our operating expenditures are incurred outside of the United States and are denominated in foreign currencies, making them subject to fluctuations in foreign currency exchange rates. We enter into foreign currency derivative contracts with maturities of 24 months or less, which we designate as cash flow hedges, to manage the foreign currency exchange risk associated with our operating expenditures.

[0001327567-24-000040:notes:52]
As of October 31, 2024 and July 31, 2024, the total notional amount of our outstanding foreign currency forward contracts designated as cash flow hedges was $656.6 million and $804.8 million, respectively. Refer to Note 3. Fair Value Measurements for the fair value of our derivative instruments as reported on our condensed consolidated balance sheets as of October 31, 2024 and July 31, 2024.

[0001327567-24-000040:notes:53]
As of October 31, 2024, unrealized gains and losses in accumulated other comprehensive income (“AOCI”) related to our cash flow hedges were a $7.5 million net loss, of which $5.8 million in losses are expected to be recognized into earnings within the next 12 months. As of July 31, 2024, unrealized gains and losses in AOCI related to our cash flow hedges were a $10.6 million net loss.

[0001327567-24-000040:notes:54]
As of October 31, 2024 and July 31, 2024, the notional amount of our outstanding foreign currency forward contracts not designated as hedging instruments was $483.8 million and $375.6 million, respectively.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001327567-24-000040:notes:55]
Acquisition
IBM QRadar Assets

[0001327567-24-000040:notes:56]
On August 31, 2024, we completed the acquisition of certain IBM QRadar assets, including certain intellectual property rights, customer relationships, and software as a service customer contracts. We expect the acquisition will help accelerate the growth of our Cortex business. The total purchase consideration for the acquisition was $1.1 billion, which consisted of the following (in millions):

[0001327567-24-000040:notes:57]
|  | Amount |
| Cash | $ | 500.0 |  |
| Fair value of contingent consideration liability | 648.9 |  |
| Return of purchase consideration | (6.3) |  |
| Total | $ | 1,142.6 |  |

[0001327567-24-000040:notes:58]
As part of the acquisition, we agreed to make post-closing payments to IBM contingent upon customers entering into qualified new transactions through June 30, 2028. We also expect to receive a return of purchase consideration of $6.3 million due to timing of transition of certain underlying customer contracts. In addition, we have entered into a transition services arrangement with IBM, under which IBM will perform certain services supporting the acquired assets and customers for a limited period of time.

[0001327567-24-000040:notes:59]
Payments related to the contingent consideration liability are expected to begin in the fiscal quarter ending April 2025 and continue through the fiscal quarter ending October 2028. The estimated range of undiscounted contingent consideration is between $0.5 billion and $0.9 billion. Refer to Note 3. Fair Value Measurements, for more information on the fair value of our contingent consideration liability.

[0001327567-24-000040:notes:60]
[same as prior period, unchanged from 0001327567-24-000017:notes:50]

[0001327567-24-000040:notes:61]
|  | Amount |
| Goodwill | $ | 700.7 |  |
| Identified intangible assets | 476.0 |  |
| Net liabilities assumed | (34.1) |  |
| Total | $ | 1,142.6 |  |

[0001327567-24-000040:notes:62]
Goodwill generated from this business combination is primarily attributable to the expected post-acquisition synergies from increased market penetration to support the growth of our Cortex business. The goodwill is deductible for U.S. income tax purposes.

[0001327567-24-000040:notes:63]
The following table presents details of the identified intangible assets acquired (in millions, except years):

[0001327567-24-000040:notes:64]
|  | Fair Value |  | Estimated Useful Life |
| Customer relationships | $ | 464.0 |  |  | 12 years |
| Developed technology | 12.0 |  |  | 2 years |
| Total | $ | 476.0 |  |  |  |

[0001327567-24-000040:notes:65]
Pro forma results of operations have not been presented because the effects of the acquisition were not material to our condensed consolidated statements of operations.

[0001327567-24-000040:notes:66]
Additional information related to the acquisition existing as of the acquisition date may become known during the remainder of the measurement period, not to exceed 12 months from the acquisition date, which may result in changes to the amounts and allocations recorded.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001327567-24-000040:notes:67]
[same as prior period, unchanged from 0001327567-24-000017:notes:64]

[0001327567-24-000040:notes:68]
The following table presents details of our goodwill during the three months ended October 31, 2024 (in millions):

[0001327567-24-000040:notes:69]
|  | Amount |
| Balance as of July 31, 2024 | $ | 3,350.1 |  |
| Goodwill acquired | 700.7 |  |
| Balance as of October 31, 2024 | $ | 4,050.8 |  |

[0001327567-24-000040:notes:70]
[same as prior period, unchanged from 0001327567-24-000017:notes:67]

[0001327567-24-000040:notes:71]
The following table presents details of our purchased intangible assets as of October 31, 2024 and July 31, 2024 (in millions):

[0001327567-24-000040:notes:72]
|  | October 31, 2024 |  | July 31, 2024 |
|  | Gross Carrying Amount |  | Accumulated Amortization |  | Net Carrying Amount |  | Gross Carrying Amount |  | Accumulated Amortization |  | Net Carrying Amount |
| Intangible assets subject to amortization: |  |  |  |  |  |  |  |  |  |  |  |
| Developed technology | $ | 825.9 |  |  | $ | (555.3) |  |  | $ | 270.6 |  |  | $ | 813.9 |  |  | $ | (526.2) |  |  | $ | 287.7 |  |
| Customer relationships | 636.7 |  |  | (107.7) |  |  | 529.0 |  |  | 172.7 |  |  | (96.1) |  |  | 76.6 |  |
| Acquired intellectual property | 18.2 |  |  | (8.4) |  |  | 9.8 |  |  | 18.2 |  |  | (7.9) |  |  | 10.3 |  |
| Trade name and trademarks | 9.4 |  |  | (9.4) |  |  | — |  |  | 9.4 |  |  | (9.4) |  |  | — |  |
| Other | 0.9 |  |  | (0.7) |  |  | 0.2 |  |  | 0.9 |  |  | (0.6) |  |  | 0.3 |  |
| Total purchased intangible assets | $ | 1,491.1 |  |  | $ | (681.5) |  |  | $ | 809.6 |  |  | $ | 1,015.1 |  |  | $ | (640.2) |  |  | $ | 374.9 |  |

[0001327567-24-000040:notes:73]
We recognized amortization expense of $41.3 million and $24.9 million for the three months ended October 31, 2024 and 2023, respectively.

[0001327567-24-000040:notes:74]
The following table summarizes estimated future amortization expense of our intangible assets subject to amortization as of October 31, 2024 (in millions):

[0001327567-24-000040:notes:75]
|  |  |  | Fiscal years ending July 31, |
|  | Total |  | Remaining 2025 |  | 2026 |  | 2027 |  | 2028 |  | 2029 |  | 2030 and Thereafter |
| Future amortization expense | $ | 809.6 |  |  | $ | 124.5 |  |  | $ | 140.6 |  |  | $ | 109.7 |  |  | $ | 88.8 |  |  | $ | 62.8 |  |  | $ | 283.2 |  |


## us-gaap:DebtDisclosureTextBlock

[0001327567-24-000040:notes:76]
Debt
Convertible Senior Notes

[0001327567-24-000040:notes:77]
In June 2020, we issued $2.0 billion aggregate principal amount of 0.375% Convertible Senior Notes due 2025 (the “2025 Notes”). The 2025 Notes bear interest at a fixed rate of 0.375% per year, payable semi-annually in arrears on June 1 and December 1 of each year, beginning on December 1, 2020. The 2025 Notes are governed by an indenture between us, as the issuer, and U.S. Bank National Association, as Trustee (the “Indenture”). The 2025 Notes are unsecured, unsubordinated obligations and the Indenture governing the 2025 Notes does not contain any financial covenants or restrictions on the payments of dividends, the incurrence of indebtedness, or the issuance or repurchase of securities by us or any of our subsidiaries. The 2025 Notes mature on June 1, 2025. We may redeem for cash all or any portion of the 2025 Notes, at our option, on or after June 5, 2023 and prior to the 31st scheduled trading day immediately preceding the maturity date if the last reported sale price of our common stock has been at least 130% of the conversion price then in effect for at least 20 trading days during any 30 consecutive trading day period ending on and including the trading day preceding the date on which we provide notice of redemption. The redemption will be at a price equal to 100% of the principal amount of the 2025 Notes and adjusted for interest. If we call any or all of the 2025 Notes for redemption, holders may convert such 2025 Notes called for redemption at any time prior to the close of business on the second scheduled trading day immediately preceding the redemption date.

[0001327567-24-000040:notes:78]
The 2025 Notes are convertible for an initial 20.1 million shares of our common stock at a conversion rate of approximately 10.0806 shares of common stock per $1,000 principal amount, which is equal to an initial conversion price of approximately $99.20 per share of common stock, subject to adjustments. Holders of the 2025 Notes may surrender their 2025 Notes for conversion at their option at any time prior to the close of business on the business day immediately preceding March 1, 2025 only under the following circumstances:

[0001327567-24-000040:notes:79]
•during any fiscal quarter commencing after the fiscal quarters ending on October 31, 2020 (and only during such fiscal quarter), if the last reported sale price of our common stock for at least 20 trading days (whether or not consecutive) during a period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the conversion price for the 2025 Notes on each applicable trading day (the “sale price condition”);

[0001327567-24-000040:notes:80]
•during the five business day period after any five consecutive trading day period (the “measurement period”) in which the trading price per $1,000 principal amount of the 2025 Notes for each trading day of the measurement period was less than 98% of the product of the last reported sale price of our common stock and the conversion rate for the 2025 Notes on each such trading day; or

[0001327567-24-000040:notes:81]
•upon the occurrence of specified corporate events.

[0001327567-24-000040:notes:82]
On or after March 1, 2025, holders may surrender all or any portion of their 2025 Notes for conversion at any time prior to the close of business on the second scheduled trading day immediately preceding the maturity date regardless of the foregoing conditions, and such conversions will be settled upon the maturity date. Upon conversion, holders of the 2025 Notes will receive cash equal to the aggregate principal amount of the 2025 Notes to be converted, and, at our election, cash and/or shares of our common stock for any amounts in excess of the aggregate principal amount of the 2025 Notes being converted.

[0001327567-24-000040:notes:83]
The conversion price will be subject to adjustment in some events. Holders of the 2025 Notes who convert their 2025 Notes in connection with certain corporate events that constitute a “make-whole fundamental change” under the Indenture are, under certain circumstances, entitled to an increase in the conversion rate. Additionally, upon the occurrence of a corporate event that constitutes a “fundamental change” under the Indenture, holders of the 2025 Notes may require us to repurchase for cash all or a portion of the 2025 Notes at a repurchase price equal to 100% of the principal amount of the 2025 Notes plus accrued and unpaid interest to, but excluding, the fundamental change repurchase date.

[0001327567-24-000040:notes:84]
Holders of the 2025 Notes were able to early convert their 2025 Notes during the fiscal quarter ended October 31, 2024 as the sales price condition had been met during the fiscal quarter ended July 31, 2024. During the three months ended October 31, 2024 and 2023, holders of the 2025 Notes converted $319.0 million and $46.0 million, respectively, in aggregate principal amount of the 2025 Notes, which we repaid in cash. We also issued 2.3 million and 0.3 million shares of our common stock to the holders of the 2025 Notes during the three months ended October 31, 2024 and 2023, respectively, for the conversion value in excess of the principal amount. These shares were fully offset by shares we received from the corresponding exercise of the note hedges. Refer to Note 16. Subsequent Events for additional information regarding conversion of the 2025 Notes after October 31, 2024 through the filing date of this Quarterly Report on Form 10-Q.

[0001327567-24-000040:notes:85]
The sale price condition for the 2025 Notes was met during the fiscal quarter ended October 31, 2024 and as a result, holders may convert their 2025 Notes during the fiscal quarter ending January 31, 2025. The net carrying amount of the 2025 Notes was classified as a current liability on our condensed consolidated balance sheet as of October 31, 2024.

[0001327567-24-000040:notes:86]
The following table sets forth the net carrying amount of our 2025 Notes (in millions):

[0001327567-24-000040:notes:87]
|  |  |  | October 31, 2024 | July 31, 2024 |
| Principal |  |  | $ | 646.6 |  |  |  |  |  |  | $ | 965.6 |  |  |  |
| Less: debt issuance costs, net of amortization |  |  | (0.8) |  |  |  |  |  |  | (1.7) |  |  |  |
| Net carrying amount |  |  | $ | 645.8 |  |  |  |  |  |  | $ | 963.9 |  |  |  |

[0001327567-24-000040:notes:88]
The total estimated fair value of the 2025 Notes was $2.3 billion as of October 31, 2024 and $3.2 billion as of July 31, 2024. The fair value was determined based on the closing trading price per $100 of the 2025 Notes as of the last day of trading for the period. We consider the fair value of the 2025 Notes as of October 31, 2024 and July 31, 2024 to be a Level 2 measurement. The fair value of the 2025 Notes is primarily affected by the trading price of our common stock and market interest rates.

[0001327567-24-000040:notes:89]
The following table sets forth interest expense recognized related to the 2025 Notes (dollars in millions):

[0001327567-24-000040:notes:90]
|  |  |  |  |  | Three Months Ended October 31, |
|  |  |  |  |  |  |  | 2024 |  |  |  | 2023 |
| Contractual interest expense |  |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 0.7 |  |  |  |  |  |  | $ | 1.9 |  |  |  |
| Amortization of debt issuance costs |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 0.5 |  |  |  |  |  |  | 1.0 |  |  |  |
| Total interest expense |  |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 1.2 |  |  |  |  |  |  | $ | 2.9 |  |  |  |
| Effective interest rate |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 0.6 | % |  |  |  |  |  | 0.6 | % |  |  |

[0001327567-24-000040:notes:91]
Note Hedges

[0001327567-24-000040:notes:92]
To minimize the impact of potential economic dilution upon conversion of our convertible senior notes, we entered into separate convertible note hedge transactions (the “2025 Note Hedges”) with respect to our common stock concurrent with the issuance of the 2025 Notes.

[0001327567-24-000040:notes:93]
The 2025 Note Hedges cover up to 20.1 million shares of our common stock at a strike price per share that corresponds to the initial conversion price of the 2025 Notes, which are also subject to adjustment, and are exercisable upon conversion of the 2025 Notes. The 2025 Note Hedges will expire upon maturity of the 2025 Notes. The 2025 Note Hedges are separate transactions and are not part of the terms of the 2025 Notes. Holders of the 2025 Notes will not have any rights with respect to the 2025 Note Hedges. Any shares of our common stock receivable by us under the 2025 Note Hedges are excluded from the calculation of diluted earnings per share as they are antidilutive. We paid an aggregate amount of $370.8 million for the 2025 Note Hedges, which is included in additional paid-in capital on our condensed consolidated balance sheets.

[0001327567-24-000040:notes:94]
As a result of the conversions of the 2025 Notes settled during the three months ended October 31, 2024 and 2023, we exercised the corresponding portion of our 2025 Note Hedges and received 2.3 million and 0.3 million shares of our common stock during the respective periods.

[0001327567-24-000040:notes:95]
Warrants

[0001327567-24-000040:notes:96]
Separately, but concurrently with the issuance of each series of our convertible senior notes, we entered into transactions whereby we sold warrants (the “2023 Warrants,” with respect to the 0.75% convertible senior notes due 2023 issued in July 2018, the “2025 Warrants,” with respect to the 2025 Notes, and the 2023 Warrants together with the 2025 Warrants, the “Warrants”) to acquire shares of our common stock, subject to anti-dilution adjustments. The 2023 Warrants and 2025 Warrants are exercisable over 60 scheduled trading days beginning October 2023 and September 2025, respectively.

[0001327567-24-000040:notes:97]
The following table presents details of our Warrants (in millions, except per share data):

[0001327567-24-000040:notes:98]
|  | Initial Number of Shares |  | Strike Price per Share |  | Aggregate Proceeds |
| 2023 Warrants (1) | 19.1 |  |  | $ | 139.27 |  |  | $ | 145.4 |  |
| 2025 Warrants | 20.1 |  |  | $ | 136.16 |  |  | $ | 202.8 |  |

[0001327567-24-000040:notes:99]
(1)The 2023 Warrants were net settled during the 60 scheduled trading days from October to December 2023.

[0001327567-24-000040:notes:100]
The shares issuable under the Warrants are included in the calculation of diluted earnings per share when the average market value per share of our common stock for the reporting period exceeds the applicable strike price for such series of Warrants. The Warrants are separate transactions and are not part of either series of Notes or Note Hedges and are not remeasured through earnings each reporting period. Holders of the Notes of either series will not have any rights with respect to the Warrants. The aggregate proceeds received from the sale of the Warrants are included in additional paid-in capital on our condensed consolidated balance sheets.

[0001327567-24-000040:notes:101]
During the three months ended October 31, 2023, we net settled a portion of the 2023 Warrants with 3.1 million shares of our common stock with a fair value of $763.5 million. The number of net shares issued was determined based on the number of 2023 Warrants exercised multiplied by the difference between the strike price of the 2023 Warrants and their daily volume-weighted-average stock price.

[0001327567-24-000040:notes:102]
Revolving Credit Facility

[0001327567-24-000040:notes:103]
On April 13, 2023, we entered into a credit agreement (the “Credit Agreement”) with certain institutional lenders that provides for a $400.0 million unsecured revolving credit facility (the “Credit Facility”), with an option to increase the amount of the Credit Facility by up to an additional $350.0 million, subject to certain conditions. The Credit Facility matures on April 13, 2028.

[0001327567-24-000040:notes:104]
The borrowings under the Credit Facility bear interest, at our option, at a base rate plus a spread of 0.000% to 0.375%, or an adjusted term Secured Overnight Financing Rate (“SOFR”) plus a spread of 1.000% to 1.375%, in each case with such spread being determined based on our leverage ratio. We are obligated to pay an ongoing commitment fee on undrawn amounts at a rate of 0.090% to 0.150%, depending on our leverage ratio. The interest rates and commitment fees are also subject to upward and downward adjustments based on our progress towards the achievement of certain sustainability goals related to greenhouse gas emissions.

[0001327567-24-000040:notes:105]
As of October 31, 2024, there were no amounts outstanding and we were in compliance with all covenants under the Credit Agreement.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001327567-24-000040:notes:106]
Commitments and Contingencies
Purchase Commitments

[0001327567-24-000040:notes:107]
We have entered into various non-cancelable agreements with cloud service providers, under which we are committed to minimum or fixed purchases of certain cloud services. In addition, in order to reduce manufacturing lead times and plan for adequate supply, we have entered into agreements with manufacturing partners and component suppliers to procure inventory based on our demand forecasts. The following table presents details of the aggregate future non-cancelable purchase commitments under these agreements as of October 31, 2024 (in millions):

[0001327567-24-000040:notes:108]
|  |  |  | Fiscal years ending July 31, |
|  | Total |  | Remaining 2025 |  | 2026 |  | 2027 |  | 2028 |  | 2029 |  | 2030 and Thereafter |
| Cloud | $ | 4,088.9 |  |  | $ | 56.7 |  |  | $ | 435.7 |  |  | $ | 518.1 |  |  | $ | 599.6 |  |  | $ | 686.1 |  |  | $ | 1,792.7 |  |
| Manufacturing | 205.7 |  |  | 165.7 |  |  | 40.0 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Other | 155.8 |  |  | 41.3 |  |  | 57.7 |  |  | 42.4 |  |  | 7.5 |  |  | 3.4 |  |  | 3.5 |  |
| Total purchase commitments | $ | 4,450.4 |  |  | $ | 263.7 |  |  | $ | 533.4 |  |  | $ | 560.5 |  |  | $ | 607.1 |  |  | $ | 689.5 |  |  | $ | 1,796.2 |  |

[0001327567-24-000040:notes:109]
Additionally, we have a $137.2 million minimum purchase commitment with a cloud service provider through September 2027 with no specified annual commitments.

[0001327567-24-000040:notes:110]
Litigation

[0001327567-24-000040:notes:111]
We are subject to legal proceedings, claims, tax matters, and litigation arising in the ordinary course of business, including, for instance, intellectual property and patent litigation. We accrue for contingencies when we believe that a loss is probable and that we can reasonably estimate the amount of any such loss.

[0001327567-24-000040:notes:112]
Legal matters could include speculative, substantial, or indeterminate monetary amounts. Significant judgment is required to determine both the likelihood of there being a loss and the estimated amount of a loss related to such matters, and we may be unable to estimate the reasonably possible loss or range of loss. The outcomes of outstanding legal matters are inherently unpredictable, and could, either individually or in aggregate, have a material adverse effect on us and our results of operations. To the extent there is a reasonable possibility that a loss exceeding any amounts already recognized may be incurred, we will either disclose the estimated additional loss or state that such an estimate cannot be made.

[0001327567-24-000040:notes:113]
The following matters arose in the ordinary course of business.

[0001327567-24-000040:notes:114]
Centripetal Networks, Inc. v. Palo Alto Networks

[0001327567-24-000040:notes:115]
On March 12, 2021, Centripetal Networks, Inc., filed a lawsuit against us in the United States District Court for the Eastern District of Virginia. The lawsuit alleges that our products infringe multiple Centripetal patents. We successfully challenged certain of these patents, which were found unpatentable by the U.S. Patent and Trademark Office (“PTO”). The case went to jury trial on January 22, 2024, on four patents. On January 31, 2024, the jury returned a verdict of non-willful infringement with a lump sum amount of $151.5 million, plus statutory interest. After post-trial motions, a judgment was issued on October 3, 2024 affirming infringement on three patents, reversing infringement on the fourth patent, and subsequently, reducing the damages amount to $113.6 million. We posted a surety bond that was agreed upon by the parties and approved by the court. This bond prevents execution of the judgment while appeals are pending. In addition, Centripetal filed infringement contentions on certain of their patents in the European Patent Office in Germany, to which we filed invalidity challenges. Those matters are still pending.

[0001327567-24-000040:notes:116]
As of July 31, 2024, we accrued $184.4 million for the verdict amount and estimated interest. As of October 31, 2024, we reassessed our loss accrual and reduced the amount to $141.4 million based on the judgment and estimated interest, which is recorded in other long-term liabilities on our condensed consolidated balance sheets. The corresponding amount released was $43.0 million for the three months ended October 31, 2024, which is included in general and administrative expense on our condensed consolidated statements of operations.

[0001327567-24-000040:notes:117]
Finjan, Inc. v. Palo Alto Networks

[0001327567-24-000040:notes:118]
On November 4, 2014, Finjan, Inc., filed a lawsuit against us in the United States District Court for the Northern District of California. The lawsuit alleges that our products infringe multiple Finjan patents. The complaint requests injunctive relief, monetary damages, and attorneys fees. A trial date is set for June 9, 2025. We are unable, at this time, to reasonably estimate a possible loss or potential range of loss, if any.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001327567-24-000040:notes:119]
[same as prior period, unchanged from 0001327567-24-000017:notes:122]

[0001327567-24-000040:notes:120]
In February 2019, our board of directors authorized a $1.0 billion share repurchase program, which is funded from available working capital. In December 2020, August 2021, August 2022, November 2023, and August 2024, our board of directors authorized additional $700.0 million, $676.1 million, $915.0 million, $316.7 million and $500.0 million increases to this share repurchase program, respectively, bringing the total authorization under this share repurchase program to $4.1 billion (our “current authorization”). The expiration date of our current authorization was extended to December 31, 2025, and our repurchase program may be suspended or discontinued at any time. Repurchases may be made at management’s discretion from time to time on the open market, through privately negotiated transactions, transactions structured through investment banking institutions, block purchase techniques, 10b5-1 trading plans, or a combination of the foregoing.

[0001327567-24-000040:notes:121]
We did not repurchase shares of our common stock during the three months ended October 31, 2024. During the three months ended October 31, 2023, we repurchased and retired 0.3 million shares of our common stock under our current repurchase authorization for an aggregate purchase price of $66.7 million, including transaction costs, at an average price of $226.67.

[0001327567-24-000040:notes:122]
As of October 31, 2024, $1.0 billion remained available for future share repurchases under our current repurchase authorization. The total price of the shares repurchased and related transaction costs are reflected as a reduction to common stock and additional paid-in capital on our condensed consolidated balance sheets.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001327567-24-000040:notes:123]
[same as prior period, unchanged from 0001327567-24-000017:notes:129]

[0001327567-24-000040:notes:124]
The following table summarizes the RSU and PSU activity under our stock plans during the three months ended October 31, 2024 (in millions, except per share amounts):

[0001327567-24-000040:notes:125]
|  | Unvested RSUs |  | Unvested PSUs |
|  | Number of Shares |  | Weighted-Average Grant-Date Fair Value Per Share |  |  |  | Aggregate Intrinsic Value |  | Number of Shares |  | Weighted-Average Grant-Date Fair Value Per Share |  |  |  | Aggregate Intrinsic Value |
| Balance—July 31, 2024 | 9.0 |  |  | $ | 205.18 |  |  |  |  | $ | 2,924.4 |  |  | 5.0 |  |  | $ | 155.89 |  |  |  |  | $ | 1,624.2 |  |
| Granted(1) | 0.4 |  |  | $ | 351.52 |  |  |  |  |  |  | 1.6 |  |  | $ | 404.69 |  |  |  |  |  |
| Vested(2) | (1.3) |  |  | $ | 163.72 |  |  |  |  |  |  | (0.6) |  |  | $ | 129.35 |  |  |  |  |  |
| Forfeited | (0.3) |  |  | $ | 197.36 |  |  |  |  |  |  | (1.5) |  |  | $ | 181.44 |  |  |  |  |  |
| Balance—October 31, 2024 | 7.8 |  |  | $ | 221.08 |  |  |  |  | $ | 2,813.8 |  |  | 4.5 |  |  | $ | 272.87 |  |  |  |  | $ | 1,633.6 |  |

[0001327567-24-000040:notes:126]
[same as prior period, unchanged from 0001327567-24-000017:notes:132]

[0001327567-24-000040:notes:127]
(2)Includes time-based vesting for PSUs.

[0001327567-24-000040:notes:128]
[same as prior period, unchanged from 0001327567-24-000017:notes:133]

[0001327567-24-000040:notes:129]
[same as prior period, unchanged from 0001327567-24-000017:notes:134]

[0001327567-24-000040:notes:130]
During the three months ended October 31, 2024, we granted 1.6 million shares of PSUs that contain service, performance, and market conditions. The service conditions are satisfied after a period of one to three years. The performance conditions are based on an average of next-generation security annualized recurring revenue and non-GAAP net income per diluted share. The market condition is measured based on our total shareholder return (“TSR”) relative to the TSR of the companies listed in the Standard & Poor’s 500 index. As of October 31, 2024, we have approved 1.3 million shares of PSUs, which will be granted upon the performance condition being established during the next two fiscal years.

[0001327567-24-000040:notes:131]
The fair value of the PSUs subject to market conditions is estimated on the grant date using a Monte Carlo simulation model. The following table summarizes the assumptions used and the resulting grant-date fair value of our PSUs subject to market conditions granted during the three months ended October 31, 2024:

[0001327567-24-000040:notes:132]
|  |  |  | Three Months Ended October 31, |
|  |  |  |  |  | 2024 |  | 2023 |
| Volatility |  |  |  |  | 44.1% - 47.6% |  | 40.8% - 43.4% |
| Expected term (in years) |  |  |  |  | 1.0 - 2.9 |  | 0.9 - 2.9 |
| Dividend yield |  |  |  |  | 0.0 | % |  | 0.0 | % |
| Risk-free interest rate |  |  |  |  | 3.7% - 4.5% |  | 4.9% - 5.3% |
| Grant-date fair value per share |  |  |  |  | $529.01 - $611.65 |  | $346.92 - $394.63 |

[0001327567-24-000040:notes:133]
[same as prior period, unchanged from 0001327567-24-000017:notes:138]

[0001327567-24-000040:notes:134]
We have granted PSOs with both service and market conditions. The market conditions were achieved when certain stock price targets were met. As of October 31, 2024, all of our outstanding PSOs have been fully vested. The maximum contractual term of our outstanding PSOs is seven and a half years from the date of grant in fiscal year 2018 and 2019.

[0001327567-24-000040:notes:135]
The following table summarizes the PSO activity under our stock plans during the three months ended October 31, 2024 (in millions, except per share amounts):

[0001327567-24-000040:notes:136]
|  |  |  |  |  |  |  |  |  | Number of Shares |  | Weighted-Average Exercise Price Per Share |  | Weighted-Average Remaining Contractual Term (Years) |  | Aggregate Intrinsic Value |
| Balance—July 31, 2024 |  |  |  |  |  |  |  |  | 4.8 |  |  | $ | 65.33 |  |  | 1.2 |  | $ | 1,244.9 |  |
| Exercised |  |  |  |  |  |  |  |  | (0.6) |  |  | $ | 65.63 |  |  |  |  |  |
| Balance—October 31, 2024 |  |  |  |  |  |  |  |  | 4.2 |  |  | $ | 65.29 |  |  | 1.0 |  | $ | 1,251.3 |  |
| Exercisable—October 31, 2024 |  |  |  |  |  |  |  |  | 4.2 |  |  | $ | 65.29 |  |  | 1.0 |  | $ | 1,251.3 |  |

[0001327567-24-000040:notes:137]
[same as prior period, unchanged from 0001327567-24-000017:notes:142]

[0001327567-24-000040:notes:138]
[same as prior period, unchanged from 0001327567-24-000017:notes:143]

[0001327567-24-000040:notes:139]
|  |  |  | Three Months Ended October 31, |
|  |  |  |  |  | 2024 |  | 2023 |
| Cost of product revenue |  |  |  |  | $ | 1.3 |  |  | $ | 2.4 |  |
| Cost of subscription and support revenue |  |  |  |  | 30.4 |  |  | 30.6 |  |
| Research and development |  |  |  |  | 137.8 |  |  | 120.1 |  |
| Sales and marketing |  |  |  |  | 76.4 |  |  | 79.2 |  |
| General and administrative |  |  |  |  | 48.4 |  |  | 38.7 |  |
| Total share-based compensation |  |  |  |  | $ | 294.3 |  |  | $ | 271.0 |  |

[0001327567-24-000040:notes:140]
As of October 31, 2024, total compensation cost related to unvested share-based awards not yet recognized was $2.2 billion. This cost is expected to be amortized over a weighted-average period of approximately 2.5 years.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001327567-24-000040:notes:141]
Income Taxes
For the three months ended October 31, 2024 and 2023, our provision for income taxes reflected effective tax rates of 4.9% and 31.3%, respectively. Our income taxes for the three months ended October 31, 2024 and 2023 were primarily due to U.S. federal and state income taxes, withholding taxes, and foreign income taxes.

[0001327567-24-000040:notes:142]
Our effective tax rate for the three months ended October 31, 2024 differed from the U.S. statutory tax rate primarily due to excess tax benefits from share-based compensation.

[0001327567-24-000040:notes:143]
Our effective tax rate for the three months ended October 31, 2023 differed from the U.S. statutory tax rate primarily due to changes in our valuation allowance and excess tax benefits from share-based compensation.


## us-gaap:EarningsPerShareTextBlock

[0001327567-24-000040:notes:144]
Net Income Per Share
Basic net income per share is computed by dividing net income by basic weighted-average shares outstanding during the period. Diluted net income per share is computed by dividing net income by diluted weighted-average shares outstanding during the period giving effect to all potentially dilutive securities to the extent they are dilutive. We compute the dilutive effect of shares issuable upon conversion of our convertible senior notes using the if-converted method, and the dilutive effect of warrants related to the issuance of convertible senior notes and equity awards under our employee equity incentive plans using the treasury stock method.

[0001327567-24-000040:notes:145]
[same as prior period, unchanged from 0001327567-24-000017:notes:152]

[0001327567-24-000040:notes:146]
|  |  |  | Three Months Ended October 31, |
|  |  |  |  |  | 2024 |  | 2023 |
| Net income |  |  |  |  | $ | 350.7 |  |  | $ | 194.2 |  |
| Weighted-average shares used to compute net income per share, basic |  |  |  |  | 326.8 |  |  | 310.1 |  |
| Weighted-average effect of potentially dilutive securities: |  |  |  |  |  |  |  |
| Convertible senior notes |  |  |  |  | 5.9 |  |  | 11.6 |  |
| Warrants related to the issuance of convertible senior notes |  |  |  |  | 12.2 |  |  | 16.0 |  |
| Employee equity incentive plans |  |  |  |  | 9.6 |  |  | 12.1 |  |
| Weighted-average shares used to compute net income per share, diluted |  |  |  |  | 354.5 |  |  | 349.8 |  |
| Net income per share, basic |  |  |  |  | $ | 1.07 |  |  | $ | 0.63 |  |
| Net income per share, diluted |  |  |  |  | $ | 0.99 |  |  | $ | 0.56 |  |

[0001327567-24-000040:notes:147]
[same as prior period, unchanged from 0001327567-24-000017:notes:154]

[0001327567-24-000040:notes:148]
|  |  |  | Three Months Ended October 31, |
|  |  |  |  |  | 2024 |  | 2023 |
| Employee equity incentive plans |  |  |  |  | 1.6 |  |  | 2.6 |  |


## us-gaap:OtherNonoperatingIncomeAndExpenseTextBlock

[0001327567-24-000040:notes:149]
[same as prior period, unchanged from 0001327567-24-000017:notes:156]

[0001327567-24-000040:notes:150]
|  |  |  | Three Months Ended October 31, |
|  |  |  |  |  | 2024 |  | 2023 |
| Interest income |  |  |  |  | $ | 85.7 |  |  | $ | 71.2 |  |
| Foreign currency exchange gains (losses), net |  |  |  |  | (7.5) |  |  | 5.1 |  |
| Other, net |  |  |  |  | 5.1 |  |  | (6.0) |  |
| Total other income, net |  |  |  |  | $ | 83.3 |  |  | $ | 70.3 |  |


## us-gaap:SubsequentEventsTextBlock

[0001327567-24-000040:notes:151]
Subsequent Events
2025 Notes Conversion

[0001327567-24-000040:notes:152]
Subsequent to October 31, 2024, $106.0 million in aggregate principal amount of the 2025 Notes was converted or had been submitted by the holders for conversion and will settle during the fiscal quarter ending January 31, 2025.

[0001327567-24-000040:notes:153]
Stock Split

[0001327567-24-000040:notes:154]
On November 19, 2024, our board of directors approved a two-for-one stock split (the “stock split”) of our outstanding shares of common stock. The stock split is to be effected through an amendment to our restated certificate of incorporation, which will also effect a proportionate increase in the number of authorized shares of our common stock from 1.0 billion to 2.0 billion.

[0001327567-24-000040:notes:155]
As a result of the stock split, each stockholder of record as of the close of trading on December 12, 2024 (the “record date”), will receive, after the close of trading on December 13, 2024, one additional share for every share held on the record date. Trading is expected to begin on a split-adjusted basis on December 16, 2024.


## ecd:MtrlTermsOfTrdArrTextBlock

[0001327567-24-000040:notes:156]
Set forth below is certain information regarding Rule 10b5-1 trading plans adopted or terminated by our directors and officers (as defined in Rule 16a-1(f)) during the first quarter of fiscal 2025. The Rule 10b5-1 trading plans listed below are each intended to satisfy the affirmative defense of Rule 10b5-1(c).

[0001327567-24-000040:notes:157]
| Name |  | Title |  | Date Plan Was Adopted |  | Date Plan was Terminated |  | Expiration Date |  | Total Amount of Common Stock to be Sold Under the Plan |
| Lee Klarich |  | Executive Vice President, Chief Product Officer |  | September 27, 2024 |  | Not applicable |  | January 8, 2026 or when all shares have been sold |  | 711,088 |
| Mary Pat McCarthy |  | Director |  | September 12, 2024 |  | Not applicable |  | November 30, 2025 or when all shares have been sold |  | 6,000 |
| Josh Paul |  | Senior Vice President, Chief Accounting Officer |  | October 1, 2024 |  | Not applicable |  | December 31, 2025 or when all shares have been sold |  | 4,500 |
| Nir Zuk |  | Executive Vice President, Chief Technology Officer |  | April 1, 2024 |  | October 2, 2024 |  | Not applicable |  | 432,000 |
