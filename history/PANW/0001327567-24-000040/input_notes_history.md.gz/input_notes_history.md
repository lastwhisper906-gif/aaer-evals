# PANW note change history — 0001327567-24-000017 → 0001327567-24-000040


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2024-11-21):
[0001327567-24-000040:note_history:1]
We have entered into various non-cancelable agreements with cloud service providers, under which we are committed to minimum or fixed purchases of certain cloud services. In addition, in order to reduce manufacturing lead times and plan for adequate supply, we have entered into agreements with manufacturing partners and component suppliers to procure inventory based on our demand forecasts. The following table presents details of the aggregate future non-cancelable purchase commitments under these agreements as of October 31, 2024 (in millions):
  (was, 2024-05-21, similarity 0.989):
[0001327567-24-000017:note_history:1]
We have entered into various non-cancelable agreements with cloud service providers, under which we are committed to minimum or fixed purchases of certain cloud services. In addition, in order to reduce manufacturing lead times and plan for adequate supply, we have entered into agreements with manufacturing partners and component suppliers to procure inventory based on our demand forecasts. The following table presents details of the aggregate future non-cancelable purchase commitments under these agreements as of April 30, 2024 (in millions):

- changed (2024-11-21):
[0001327567-24-000040:note_history:2]
|  |  |  | Fiscal years ending July 31, |
|  | Total |  | Remaining 2025 |  | 2026 |  | 2027 |  | 2028 |  | 2029 |  | 2030 and Thereafter |
| Cloud | $ | 4,088.9 |  |  | $ | 56.7 |  |  | $ | 435.7 |  |  | $ | 518.1 |  |  | $ | 599.6 |  |  | $ | 686.1 |  |  | $ | 1,792.7 |  |
| Manufacturing | 205.7 |  |  | 165.7 |  |  | 40.0 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Other | 155.8 |  |  | 41.3 |  |  | 57.7 |  |  | 42.4 |  |  | 7.5 |  |  | 3.4 |  |  | 3.5 |  |
| Total purchase commitments | $ | 4,450.4 |  |  | $ | 263.7 |  |  | $ | 533.4 |  |  | $ | 560.5 |  |  | $ | 607.1 |  |  | $ | 689.5 |  |  | $ | 1,796.2 |  |
  (was, 2024-05-21, similarity 0.9467):
[0001327567-24-000017:note_history:2]
|  |  |  | Fiscal years ending July 31, |
|  | Total |  | Remaining 2024 |  | 2025 |  | 2026 |  | 2027 |  | 2028 |  | 2029 and Thereafter |
| Cloud | $ | 4,338.4 |  |  | $ | 1.0 |  |  | $ | 251.8 |  |  | $ | 581.1 |  |  | $ | 518.1 |  |  | $ | 585.6 |  |  | $ | 2,400.8 |  |
| Manufacturing | 210.6 |  |  | 54.8 |  |  | 115.8 |  |  | 40.0 |  |  | — |  |  | — |  |  | — |  |
| Other | 48.5 |  |  | — |  |  | 15.6 |  |  | 13.2 |  |  | 6.3 |  |  | 6.7 |  |  | 6.7 |  |
| Total purchase commitments | $ | 4,597.5 |  |  | $ | 55.8 |  |  | $ | 383.2 |  |  | $ | 634.3 |  |  | $ | 524.4 |  |  | $ | 592.3 |  |  | $ | 2,407.5 |  |

- added (2024-11-21):
[0001327567-24-000040:note_history:3]
On March 12, 2021, Centripetal Networks, Inc., filed a lawsuit against us in the United States District Court for the Eastern District of Virginia. The lawsuit alleges that our products infringe multiple Centripetal patents. We successfully challenged certain of these patents, which were found unpatentable by the U.S. Patent and Trademark Office (“PTO”). The case went to jury trial on January 22, 2024, on four patents. On January 31, 2024, the jury returned a verdict of non-willful infringement with a lump sum amount of $151.5 million, plus statutory interest. After post-trial motions, a judgment was issued on October 3, 2024 affirming infringement on three patents, reversing infringement on the fourth patent, and subsequently, reducing the damages amount to $113.6 million. We posted a surety bond that was agreed upon by the parties and approved by the court. This bond prevents execution of the judgment while appeals are pending. In addition, Centripetal filed infringement contentions on certain of their patents in the European Patent Office in Germany, to which we filed invalidity challenges. Those matters are still pending.

- added (2024-11-21):
[0001327567-24-000040:note_history:4]
As of July 31, 2024, we accrued $184.4 million for the verdict amount and estimated interest. As of October 31, 2024, we reassessed our loss accrual and reduced the amount to $141.4 million based on the judgment and estimated interest, which is recorded in other long-term liabilities on our condensed consolidated balance sheets. The corresponding amount released was $43.0 million for the three months ended October 31, 2024, which is included in general and administrative expense on our condensed consolidated statements of operations.

- changed (2024-11-21):
[0001327567-24-000040:note_history:5]
On November 4, 2014, Finjan, Inc., filed a lawsuit against us in the United States District Court for the Northern District of California. The lawsuit alleges that our products infringe multiple Finjan patents. The complaint requests injunctive relief, monetary damages, and attorneys fees. A trial date is set for June 9, 2025. We are unable, at this time, to reasonably estimate a possible loss or potential range of loss, if any.
  (was, 2024-05-21, similarity 0.7632):
[0001327567-24-000017:note_history:5]
On November 4, 2014, Finjan, Inc., filed a lawsuit against us in the United States District Court for the Northern District of California. The lawsuit alleges that our products infringe multiple Finjan patents. The complaint requests injunctive relief, monetary damages, and attorneys fees. On March 11, 2024, the case was reassigned to a new judge and the October 21, 2024 trial date was vacated. A new trial date has not yet been set. We are unable, at this time, to reasonably estimate a possible loss or potential range of loss, if any.

- removed (2024-11-21):
[0001327567-24-000017:note_history:6]
Guarantee

- removed (2024-11-21):
[0001327567-24-000017:note_history:7]
In October 2023, we established a multi-currency notional cash pool for a certain number of our entities with a third-party bank. As part of the notional cash pool agreement, the bank extends overdraft credit to our participating entities as needed, provided that the overall notionally pooled balance of all accounts in the pool at the end of each day is positive. In the unlikely event of a default, any overdraft balances incurred would be guaranteed by our collective entities participating in the pool.

- removed (2024-11-21):
[0001327567-24-000017:note_history:8]
On March 12, 2021, Centripetal Networks, Inc., filed a lawsuit against us in the United States District Court for the Eastern District of Virginia. The lawsuit alleges that our products infringe multiple Centripetal patents. We successfully challenged certain of these patents, which were found unpatentable by the U.S. Patent and Trademark Office (“PTO”). The case went to jury trial on January 22, 2024, on four patents, with three stayed pending review in the PTO. On January 31, 2024, the jury returned a verdict of non-willful infringement with a lump sum amount of $151.5 million, plus statutory interest. We have filed motions to overturn the verdict and seek a new trial, which is pending before the court. In addition, Centripetal filed infringement contentions on certain of their patents in the European Patent Office in Germany, to which we filed invalidity challenges. Those matters are still pending.

- removed (2024-11-21):
[0001327567-24-000017:note_history:9]
As of April 30, 2024, we accrued $180.5 million for the verdict amount and estimated interest, which is recorded in other long-term liabilities on our condensed consolidated balance sheets. The corresponding charge was $3.7 million and $180.5 million for the three and nine months ended April 30, 2024, respectively, which is included in general and administrative expense on our condensed consolidated statements of operations.

- removed (2024-11-21):
[0001327567-24-000017:note_history:10]
Taasera v. Palo Alto Networks

- removed (2024-11-21):
[0001327567-24-000017:note_history:11]
On March 22, 2022, we filed a declaratory judgment action in the United States District Court for the Southern District of New York seeking a ruling that we are not infringing various Taasera patents. The parties have resolved all pending matters between them as of December 2023. The amounts paid by us to resolve these matters were not material.

- removed (2024-11-21):
[0001327567-24-000017:note_history:12]
Lionra Technologies v. Palo Alto Networks

- removed (2024-11-21):
[0001327567-24-000017:note_history:13]
On August 29, 2022, Lionra Technologies filed a lawsuit against us in the United States District Court for the Eastern District of Texas. The lawsuit alleges that our products infringe multiple Lionra patents. The complaint requests injunctive relief, monetary damages and attorneys fees. The patents at issue are currently under review by the U.S. Patent and Trademark Office. The May 20, 2024 trial date was vacated. A new trial date has not yet been set, but may be rescheduled to take place in the fourth quarter of fiscal 2024. We are unable, at this time, to reasonably estimate a possible loss or potential range of loss, if any.


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: title_similarity, score: 1.0

- changed (2024-11-21):
[0001327567-24-000040:note_history:14]
Palo Alto Networks, Inc. (the “Company,” “we,” “us,” or “our”), headquartered in Santa Clara, California, was incorporated in March 2005 under the laws of the State of Delaware and commenced operations in April 2005. We empower enterprises, organizations, service providers, and government entities to secure their users, networks, clouds, and endpoints by delivering comprehensive cybersecurity backed by artificial intelligence and automation.
  (was, 2024-05-21, similarity 0.992):
[0001327567-24-000017:note_history:14]
Palo Alto Networks, Inc. (the “Company,” “we,” “us,” or “our”), headquartered in Santa Clara, California, was incorporated in March 2005 under the laws of the State of Delaware and commenced operations in April 2005. We empower enterprises, organizations, service providers, and government entities to secure their users, networks, clouds, and endpoints by delivering comprehensive cybersecurity enabled by artificial intelligence and automation.

- changed (2024-11-21):
[0001327567-24-000040:note_history:15]
The preparation of condensed consolidated financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the amounts reported and disclosed in the condensed consolidated financial statements and the accompanying notes. We evaluate our estimates on an ongoing basis. Management estimates include, but are not limited to, the standalone selling price for our products and services, share-based compensation, fair value of assets acquired and liabilities assumed in business combinations, fair value of contingent consideration liability, the assessment of recoverability of our intangibles and goodwill, valuation allowance against deferred tax assets, manufacturing partner and supplier liabilities, deferred contract cost benefit period, and loss contingencies. We base our estimates on assumptions, both historical and forward looking, that we believe are reasonable. Actual results could differ materially from those estimates due to risks and uncertainties, including uncertainty in the current economic environment.
  (was, 2024-05-21, similarity 0.6608):
[0001327567-24-000017:note_history:15]
The preparation of condensed consolidated financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the amounts reported and disclosed in the condensed consolidated financial statements and the accompanying notes. We base our estimates on assumptions, both historical and forward looking, that we believe are reasonable. Actual results could differ materially from those estimates due to risks and uncertainties, including uncertainty in the current economic environment.

- added (2024-11-21):
[0001327567-24-000040:note_history:16]
There have been no material changes to our significant accounting policies as of and for the three months ended October 31, 2024, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended July 31, 2024, except for the update to the disclosure of our accounting policies as described below resulting from our recent acquisition of certain QRadar assets from International Business Machines Corporation (“IBM”). Refer to Note 7. Acquisition for additional information.

- added (2024-11-21):
[0001327567-24-000040:note_history:17]
Business Combinations

- added (2024-11-21):
[0001327567-24-000040:note_history:18]
We include the results of operations of the businesses that we acquire as of the respective dates of acquisition. We allocate the fair value of the purchase price of our acquisitions to the assets acquired and liabilities assumed, including contingent consideration, generally based on their estimated fair values. The excess of the purchase price over the fair values of these identifiable assets and liabilities is recorded as goodwill. Additional information existing as of the acquisition date but unknown to us may become known during the remainder of the measurement period, not to exceed 12 months from the acquisition date, which may result in changes to the amounts and allocations recorded.

- added (2024-11-21):
[0001327567-24-000040:note_history:19]
Contingent consideration obligations incurred in connection with a business combination are recorded at fair value on the acquisition date and remeasured at each subsequent reporting period until the related contingencies have been resolved, with the change in fair value recognized in general and administrative expense on our condensed consolidated statements of operations. Payments not made soon after the acquisition date to settle a contingent consideration liability are classified as cash flows from financing activities up to the amount of the contingent consideration liability recognized at the acquisition date.

- changed (2024-11-21):
[0001327567-24-000040:note_history:20]
In November 2023, the Financial Accounting Standards Board (“FASB”) issued authoritative guidance that expands annual and interim disclosure requirements for reportable segments, primarily through enhanced disclosures about significant segment expenses. The standard is effective for our annual period in fiscal 2025 and interim periods beginning in the first quarter of fiscal 2026, and requires retrospective application for all prior periods presented in the financial statements. Early adoption is permitted. We are currently evaluating the impact of this standard on our disclosures in the consolidated financial statements.
  (was, 2024-05-21, similarity 0.9912):
[0001327567-24-000017:note_history:20]
In November 2023, the Financial Accounting Standards Board (“FASB”) issued authoritative guidance that expands annual and interim disclosure requirements for reportable segments, primarily through enhanced disclosures about significant segment expenses. The standard is effective for our annual periods beginning in fiscal 2025 and interim periods beginning in the first quarter of fiscal 2026, and requires retrospective application for all prior periods presented in the financial statements. Early adoption is permitted. We are currently evaluating the impact of this standard on our disclosures in the consolidated financial statements.

- changed (2024-11-21):
[0001327567-24-000040:note_history:21]
In December 2023, the FASB issued authoritative guidance that requires consistent categories and greater disaggregation of information in the effective tax rate reconciliation and additional disclosures of income taxes paid by jurisdiction. The standard is effective for our annual period in fiscal 2026 and could be applied either prospectively or retrospectively. Early adoption is permitted. We are currently evaluating the impact of this standard on our disclosures in the consolidated financial statements.
  (was, 2024-05-21, similarity 0.9892):
[0001327567-24-000017:note_history:21]
In December 2023, the FASB issued authoritative guidance that requires consistent categories and greater disaggregation of information in the effective tax rate reconciliation and additional disclosures of income taxes paid by jurisdiction. The standard is effective for our annual periods beginning in fiscal 2026 and could be applied either prospectively or retrospectively. Early adoption is permitted. We are currently evaluating the impact of this standard on our disclosures in the consolidated financial statements.

- removed (2024-11-21):
[0001327567-24-000017:note_history:22]
Reclassification

- removed (2024-11-21):
[0001327567-24-000017:note_history:23]
Certain prior period amounts in the condensed consolidated financial statements have been reclassified to conform to the current period presentation.

- removed (2024-11-21):
[0001327567-24-000017:note_history:24]
There have been no material changes to our significant accounting policies as of and for the nine months ended April 30, 2024, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended July 31, 2023.


## us-gaap:ConvertibleDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-11-21):
[0001327567-24-000040:note_history:25]
|  |  |  | October 31, 2024 | July 31, 2024 |
| Principal |  |  | $ | 646.6 |  |  |  |  |  |  | $ | 965.6 |  |  |  |
| Less: debt issuance costs, net of amortization |  |  | (0.8) |  |  |  |  |  |  | (1.7) |  |  |  |
| Net carrying amount |  |  | $ | 645.8 |  |  |  |  |  |  | $ | 963.9 |  |  |  |
  (was, 2024-05-21, similarity 0.9739):
[0001327567-24-000017:note_history:25]
|  |  |  | April 30, 2024 | July 31, 2023 |
| Principal |  |  | $ | 1,165.2 |  |  |  |  |  |  | $ | 1,999.3 |  |  |  |
| Less: debt issuance costs, net of amortization |  |  | (2.7) |  |  |  |  |  |  | (7.8) |  |  |  |
| Net carrying amount |  |  | $ | 1,162.5 |  |  |  |  |  |  | $ | 1,991.5 |  |  |  |


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-11-21):
[0001327567-24-000040:note_history:26]
In June 2020, we issued $2.0 billion aggregate principal amount of 0.375% Convertible Senior Notes due 2025 (the “2025 Notes”). The 2025 Notes bear interest at a fixed rate of 0.375% per year, payable semi-annually in arrears on June 1 and December 1 of each year, beginning on December 1, 2020. The 2025 Notes are governed by an indenture between us, as the issuer, and U.S. Bank National Association, as Trustee (the “Indenture”). The 2025 Notes are unsecured, unsubordinated obligations and the Indenture governing the 2025 Notes does not contain any financial covenants or restrictions on the payments of dividends, the incurrence of indebtedness, or the issuance or repurchase of securities by us or any of our subsidiaries. The 2025 Notes mature on June 1, 2025. We may redeem for cash all or any portion of the 2025 Notes, at our option, on or after June 5, 2023 and prior to the 31st scheduled trading day immediately preceding the maturity date if the last reported sale price of our common stock has been at least 130% of the conversion price then in effect for at least 20 trading days during any 30 consecutive trading day period ending on and including the trading day preceding the date on which we provide notice of redemption. The redemption will be at a price equal to 100% of the principal amount of the 2025 Notes and adjusted for interest. If we call any or all of the 2025 Notes for redemption, holders may convert such 2025 Notes called for redemption at any time prior to the close of business on the second scheduled trading day immediately preceding the redemption date.
  (was, 2024-05-21, similarity 0.9173):
[0001327567-24-000017:note_history:26]
In July 2018, we issued $1.7 billion aggregate principal amount of 0.75% Convertible Senior Notes due 2023 (the “2023 Notes”) and in June 2020, we issued $2.0 billion aggregate principal amount of 0.375% Convertible Senior Notes due 2025 (the “2025 Notes,” and together with the 2023 Notes, the “Notes”). The 2023 Notes were converted prior to or settled on the maturity date of July 1, 2023 in accordance with their terms. The 2025 Notes bear interest at a fixed rate of 0.375% per year, payable semi-annually in arrears on June 1 and December 1 of each year, beginning on December 1, 2020. The 2025 Notes are governed by an indenture between us, as the issuer, and U.S. Bank National Association, as Trustee (the “Indenture”). The 2025 Notes are unsecured, unsubordinated obligations and the Indenture governing the 2025 Notes does not contain any financial covenants or restrictions on the payments of dividends, the incurrence of indebtedness, or the issuance or repurchase of securities by us or any of our subsidiaries. The 2025 Notes mature on June 1, 2025. We may redeem for cash all or any portion of the 2025 Notes, at our option, on or after June 5, 2023 and prior to the 31st scheduled trading day immediately preceding the maturity date if the last reported sale price of our common stock has been at least 130% of the conversion price then in effect for at least 20 trading days during any 30 consecutive trading day period ending on and including the trading day preceding the date on which we provide notice of redemption. The redemption will be at a price equal to 100% of the principal amount of the 2025 Notes and adjusted for interest. If we call any or all of the 2025 Notes for redemption, holders may convert such 2025 Notes called for redemption at any time prior to the close of business on the second scheduled trading day immediately preceding the redemption date.

- changed (2024-11-21):
[0001327567-24-000040:note_history:27]
Holders of the 2025 Notes were able to early convert their 2025 Notes during the fiscal quarter ended October 31, 2024 as the sales price condition had been met during the fiscal quarter ended July 31, 2024. During the three months ended October 31, 2024 and 2023, holders of the 2025 Notes converted $319.0 million and $46.0 million, respectively, in aggregate principal amount of the 2025 Notes, which we repaid in cash. We also issued 2.3 million and 0.3 million shares of our common stock to the holders of the 2025 Notes during the three months ended October 31, 2024 and 2023, respectively, for the conversion value in excess of the principal amount. These shares were fully offset by shares we received from the corresponding exercise of the note hedges. Refer to Note 16. Subsequent Events for additional information regarding conversion of the 2025 Notes after October 31, 2024 through the filing date of this Quarterly Report on Form 10-Q.
  (was, 2024-05-21, similarity 0.8743):
[0001327567-24-000017:note_history:27]
Holders of the 2025 Notes were able to early convert their 2025 Notes during the fiscal quarter ended April 30, 2024 as the sales price condition had been met during the fiscal quarter ended January 31, 2024. During the three and nine months ended April 30, 2024, holders of the 2025 Notes converted $661.8 million and $834.1 million, respectively, in aggregate principal amount of the 2025 Notes, which we repaid in cash. We also issued 4.6 million and 5.7 million shares of our common stock to the holders of the 2025 Notes during the three and nine months ended April 30, 2024, respectively, for the conversion value in excess of the principal amount. These shares were fully offset by shares we received from the corresponding exercise of the note hedges. Refer to Note 16. Subsequent Event for additional information regarding conversion of the 2025 Notes after April 30, 2024 through the filing date of this Quarterly Report on Form 10-Q.

- added (2024-11-21):
[0001327567-24-000040:note_history:28]
The sale price condition for the 2025 Notes was met during the fiscal quarter ended October 31, 2024 and as a result, holders may convert their 2025 Notes during the fiscal quarter ending January 31, 2025. The net carrying amount of the 2025 Notes was classified as a current liability on our condensed consolidated balance sheet as of October 31, 2024.

- changed (2024-11-21):
[0001327567-24-000040:note_history:29]
|  |  |  | October 31, 2024 | July 31, 2024 |
| Principal |  |  | $ | 646.6 |  |  |  |  |  |  | $ | 965.6 |  |  |  |
| Less: debt issuance costs, net of amortization |  |  | (0.8) |  |  |  |  |  |  | (1.7) |  |  |  |
| Net carrying amount |  |  | $ | 645.8 |  |  |  |  |  |  | $ | 963.9 |  |  |  |
  (was, 2024-05-21, similarity 0.9739):
[0001327567-24-000017:note_history:29]
|  |  |  | April 30, 2024 | July 31, 2023 |
| Principal |  |  | $ | 1,165.2 |  |  |  |  |  |  | $ | 1,999.3 |  |  |  |
| Less: debt issuance costs, net of amortization |  |  | (2.7) |  |  |  |  |  |  | (7.8) |  |  |  |
| Net carrying amount |  |  | $ | 1,162.5 |  |  |  |  |  |  | $ | 1,991.5 |  |  |  |

- added (2024-11-21):
[0001327567-24-000040:note_history:30]
The total estimated fair value of the 2025 Notes was $2.3 billion as of October 31, 2024 and $3.2 billion as of July 31, 2024. The fair value was determined based on the closing trading price per $100 of the 2025 Notes as of the last day of trading for the period. We consider the fair value of the 2025 Notes as of October 31, 2024 and July 31, 2024 to be a Level 2 measurement. The fair value of the 2025 Notes is primarily affected by the trading price of our common stock and market interest rates.

- changed (2024-11-21):
[0001327567-24-000040:note_history:31]
The following table sets forth interest expense recognized related to the 2025 Notes (dollars in millions):
  (was, 2024-05-21, similarity 0.9903):
[0001327567-24-000017:note_history:31]
The following table sets forth interest expense recognized related to the Notes (dollars in millions):

- added (2024-11-21):
[0001327567-24-000040:note_history:32]
|  |  |  |  |  | Three Months Ended October 31, |
|  |  |  |  |  |  |  | 2024 |  |  |  | 2023 |
| Contractual interest expense |  |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 0.7 |  |  |  |  |  |  | $ | 1.9 |  |  |  |
| Amortization of debt issuance costs |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 0.5 |  |  |  |  |  |  | 1.0 |  |  |  |
| Total interest expense |  |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 1.2 |  |  |  |  |  |  | $ | 2.9 |  |  |  |
| Effective interest rate |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 0.6 | % |  |  |  |  |  | 0.6 | % |  |  |

- changed (2024-11-21):
[0001327567-24-000040:note_history:33]
To minimize the impact of potential economic dilution upon conversion of our convertible senior notes, we entered into separate convertible note hedge transactions (the “2025 Note Hedges”) with respect to our common stock concurrent with the issuance of the 2025 Notes.
  (was, 2024-05-21, similarity 0.75):
[0001327567-24-000017:note_history:33]
To minimize the impact of potential economic dilution upon conversion of our convertible senior notes, we entered into separate convertible note hedge transactions (the “2023 Note Hedges,” with respect to the 2023 Notes, the “2025 Note Hedges,” with respect to the 2025 Notes, and the 2023 Note Hedges together with 2025 Note Hedges, the “Note Hedges”) with respect to our common stock concurrent with the issuance of each series of the Notes.

- changed (2024-11-21):
[0001327567-24-000040:note_history:34]
As a result of the conversions of the 2025 Notes settled during the three months ended October 31, 2024 and 2023, we exercised the corresponding portion of our 2025 Note Hedges and received 2.3 million and 0.3 million shares of our common stock during the respective periods.
  (was, 2024-05-21, similarity 0.8889):
[0001327567-24-000017:note_history:34]
As a result of the conversions of the 2025 Notes settled during the three and nine months ended April 30, 2024, we exercised the corresponding portion of our 2025 Note Hedges and received 4.6 million and 5.7 million shares of our common stock during the respective periods.

- changed (2024-11-21):
[0001327567-24-000040:note_history:35]
Separately, but concurrently with the issuance of each series of our convertible senior notes, we entered into transactions whereby we sold warrants (the “2023 Warrants,” with respect to the 0.75% convertible senior notes due 2023 issued in July 2018, the “2025 Warrants,” with respect to the 2025 Notes, and the 2023 Warrants together with the 2025 Warrants, the “Warrants”) to acquire shares of our common stock, subject to anti-dilution adjustments. The 2023 Warrants and 2025 Warrants are exercisable over 60 scheduled trading days beginning October 2023 and September 2025, respectively.
  (was, 2024-05-21, similarity 0.9474):
[0001327567-24-000017:note_history:35]
Separately, but concurrently with the issuance of each series of our convertible senior notes, we entered into transactions whereby we sold warrants (the “2023 Warrants,” with respect to the 2023 Notes, the “2025 Warrants,” with respect to the 2025 Notes, and the 2023 Warrants together with the 2025 Warrants, the “Warrants”) to acquire shares of our common stock, subject to anti-dilution adjustments. The 2023 Warrants and 2025 Warrants are exercisable over 60 scheduled trading days beginning October 2023 and September 2025, respectively.

- changed (2024-11-21):
[0001327567-24-000040:note_history:36]
|  | Initial Number of Shares |  | Strike Price per Share |  | Aggregate Proceeds |
| 2023 Warrants (1) | 19.1 |  |  | $ | 139.27 |  |  | $ | 145.4 |  |
| 2025 Warrants | 20.1 |  |  | $ | 136.16 |  |  | $ | 202.8 |  |
  (was, 2024-05-21, similarity 0.9884):
[0001327567-24-000017:note_history:36]
|  | Initial Number of Shares |  | Strike Price per Share |  | Aggregate Proceeds |
| 2023 Warrants | 19.1 |  |  | $ | 139.27 |  |  | $ | 145.4 |  |
| 2025 Warrants | 20.1 |  |  | $ | 136.16 |  |  | $ | 202.8 |  |

- added (2024-11-21):
[0001327567-24-000040:note_history:37]
(1)The 2023 Warrants were net settled during the 60 scheduled trading days from October to December 2023.

- changed (2024-11-21):
[0001327567-24-000040:note_history:38]
During the three months ended October 31, 2023, we net settled a portion of the 2023 Warrants with 3.1 million shares of our common stock with a fair value of $763.5 million. The number of net shares issued was determined based on the number of 2023 Warrants exercised multiplied by the difference between the strike price of the 2023 Warrants and their daily volume-weighted-average stock price.
  (was, 2024-05-21, similarity 0.8637):
[0001327567-24-000017:note_history:38]
During the nine months ended April 30, 2024, we net settled all of the 2023 Warrants with 9.0 million shares of our common stock with a fair value of $2.4 billion. The number of net shares issued was determined based on the number of 2023 Warrants exercised multiplied by the difference between the strike price of the 2023 Warrants and their daily volume-weighted-average stock price.

- changed (2024-11-21):
[0001327567-24-000040:note_history:39]
As of October 31, 2024, there were no amounts outstanding and we were in compliance with all covenants under the Credit Agreement.
  (was, 2024-05-21, similarity 0.9593):
[0001327567-24-000017:note_history:39]
As of April 30, 2024, there were no amounts outstanding and we were in compliance with all covenants under the Credit Agreement.

- removed (2024-11-21):
[0001327567-24-000017:note_history:40]
The sale price condition for the 2025 Notes was met during the fiscal quarter ended April 30, 2024 and as a result, holders may convert their 2025 Notes during the fiscal quarter ending July 31, 2024. The net carrying amount of the 2025 Notes was classified as a current liability on our condensed consolidated balance sheet as of April 30, 2024.

- removed (2024-11-21):
[0001327567-24-000017:note_history:41]
The total estimated fair value of the 2025 Notes was $3.4 billion as of April 30, 2024 and $5.0 billion as of July 31, 2023. The fair value was determined based on the closing trading price per $100 of the 2025 Notes as of the last day of trading for the period. We consider the fair value of the 2025 Notes as of April 30, 2024 and July 31, 2023 to be a Level 2 measurement. The fair value of the 2025 Notes is primarily affected by the trading price of our common stock and market interest rates.

- removed (2024-11-21):
[0001327567-24-000017:note_history:42]
|  | Three Months Ended April 30, |  | Nine Months Ended April 30, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
|  | 2023 Notes |  | 2025 Notes |  | Total |  | 2023 Notes |  | 2025 Notes |  | Total |  | 2023 Notes |  | 2025 Notes |  | Total |  | 2023 Notes |  | 2025 Notes |  | Total |
| Contractual interest expense | $ | — |  |  | $ | 1.5 |  |  | $ | 1.5 |  |  | $ | 3.2 |  |  | $ | 1.8 |  |  | $ | 5.0 |  |  | $ | — |  |  | $ | 5.1 |  |  | $ | 5.1 |  |  | $ | 9.6 |  |  | $ | 5.6 |  |  | $ | 15.2 |  |
| Amortization of debt issuance costs | — |  |  | 0.8 |  |  | 0.8 |  |  | 0.7 |  |  | 1.1 |  |  | 1.8 |  |  | — |  |  | 2.9 |  |  | 2.9 |  |  | 2.1 |  |  | 3.2 |  |  | 5.3 |  |
| Total interest expense | $ | — |  |  | $ | 2.3 |  |  | $ | 2.3 |  |  | $ | 3.9 |  |  | $ | 2.9 |  |  | $ | 6.8 |  |  | $ | — |  |  | $ | 8.0 |  |  | $ | 8.0 |  |  | $ | 11.7 |  |  | $ | 8.8 |  |  | $ | 20.5 |  |
| Effective interest rate | — | % |  | 0.6 | % |  |  |  | 0.9 | % |  | 0.6 | % |  |  |  | — | % |  | 0.6 | % |  |  |  | 0.9 | % |  | 0.6 | % |  |  |

- removed (2024-11-21):
[0001327567-24-000017:note_history:43]
Upon the settlement of the 2023 Notes, we exercised the corresponding portion of our 2023 Note Hedges during the year ended July 31, 2023 and received shares of our common stock that fully offset the shares issued in excess of the principal amount of the converted 2023 Notes. The 2023 Note Hedges expired upon maturity of the 2023 Notes.


## us-gaap:DebtSecuritiesAvailableForSaleTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-11-21):
[0001327567-24-000040:note_history:44]
The following tables summarize the amortized cost, unrealized gains and losses, and fair value of our available-for-sale debt securities as of October 31, 2024 and July 31, 2024 (in millions):
  (was, 2024-05-21, similarity 0.9724):
[0001327567-24-000017:note_history:44]
The following tables summarize the amortized cost, unrealized gains and losses, and fair value of our available-for-sale debt securities as of April 30, 2024 and July 31, 2023 (in millions):

- changed (2024-11-21):
[0001327567-24-000040:note_history:45]
|  | October 31, 2024 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | $ | 228.7 |  |  | $ | — |  |  | $ | — |  |  | $ | 228.7 |  |
| Corporate debt securities | 34.2 |  |  | — |  |  | — |  |  | 34.2 |  |
| U.S. government and agency securities | 74.8 |  |  | — |  |  | — |  |  | 74.8 |  |
| Total available-for-sale cash equivalents | $ | 337.7 |  |  | $ | — |  |  | $ | — |  |  | $ | 337.7 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 15.7 |  |  | $ | — |  |  | $ | — |  |  | $ | 15.7 |  |
| Commercial paper | 36.1 |  |  | — |  |  | — |  |  | 36.1 |  |
| Corporate debt securities | 4,115.2 |  |  | 25.3 |  |  | (7.8) |  |  | 4,132.7 |  |
| U.S. government and agency securities | 21.9 |  |  | — |  |  | — |  |  | 21.9 |  |
| Non-U.S. government and agency securities | 38.6 |  |  | 0.5 |  |  | — |  |  | 39.1 |  |
| Asset-backed securities | 976.1 |  |  | 7.1 |  |  | (0.8) |  |  | 982.4 |  |
| Total available-for-sale investments | $ | 5,203.6 |  |  | $ | 32.9 |  |  | $ | (8.6) |  |  | $ | 5,227.9 |  |
  (was, 2024-05-21, similarity 0.6949):
[0001327567-24-000017:note_history:45]
|  | July 31, 2023 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | $ | 151.4 |  |  | $ | — |  |  | $ | — |  |  | $ | 151.4 |  |
| Total available-for-sale cash equivalents | $ | 151.4 |  |  | $ | — |  |  | $ | — |  |  | $ | 151.4 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 48.1 |  |  | $ | — |  |  | $ | — |  |  | $ | 48.1 |  |
| Commercial paper | 214.1 |  |  | — |  |  | (0.3) |  |  | 213.8 |  |
| Corporate debt securities | 3,313.5 |  |  | 1.3 |  |  | (32.5) |  |  | 3,282.3 |  |
| U.S. government and agency securities | 214.2 |  |  | — |  |  | (1.6) |  |  | 212.6 |  |
| Non-U.S. government and agency securities | 37.2 |  |  | — |  |  | (0.6) |  |  | 36.6 |  |
| Asset-backed securities | 512.0 |  |  | 0.2 |  |  | (3.0) |  |  | 509.2 |  |
| Total available-for-sale investments | $ | 4,339.1 |  |  | $ | 1.5 |  |  | $ | (38.0) |  |  | $ | 4,302.6 |  |

- changed (2024-11-21):
[0001327567-24-000040:note_history:46]
|  | July 31, 2024 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | $ | 299.6 |  |  | $ | — |  |  | $ | — |  |  | $ | 299.6 |  |
| Corporate debt securities | 18.2 |  |  | — |  |  | — |  |  | 18.2 |  |
| U.S. government and agency securities | 149.6 |  |  | — |  |  | — |  |  | 149.6 |  |
| Total available-for-sale cash equivalents | $ | 467.4 |  |  | $ | — |  |  | $ | — |  |  | $ | 467.4 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 20.6 |  |  | $ | — |  |  | $ | — |  |  | $ | 20.6 |  |
| Commercial paper | 79.9 |  |  | 0.1 |  |  | (0.1) |  |  | 79.9 |  |
| Corporate debt securities | 4,065.5 |  |  | 28.3 |  |  | (6.6) |  |  | 4,087.2 |  |
| U.S. government and agency securities | 21.9 |  |  | — |  |  | (0.2) |  |  | 21.7 |  |
| Non-U.S. government and agency securities | 57.9 |  |  | 0.7 |  |  | — |  |  | 58.6 |  |
| Asset-backed securities | 943.1 |  |  | 6.3 |  |  | (0.6) |  |  | 948.8 |  |
| Total available-for-sale investments | $ | 5,188.9 |  |  | $ | 35.4 |  |  | $ | (7.5) |  |  | $ | 5,216.8 |  |
  (was, 2024-05-21, similarity 0.9079):
[0001327567-24-000017:note_history:46]
|  | April 30, 2024 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | $ | 2.5 |  |  | $ | — |  |  | $ | — |  |  | $ | 2.5 |  |
| Total available-for-sale cash equivalents | $ | 2.5 |  |  | $ | — |  |  | $ | — |  |  | $ | 2.5 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 25.5 |  |  | $ | — |  |  | $ | — |  |  | $ | 25.5 |  |
| Commercial paper | 171.0 |  |  | — |  |  | (0.1) |  |  | 170.9 |  |
| Corporate debt securities | 3,803.5 |  |  | 2.6 |  |  | (28.8) |  |  | 3,777.3 |  |
| U.S. government and agency securities | 85.0 |  |  | — |  |  | (0.4) |  |  | 84.6 |  |
| Non-U.S. government and agency securities | 87.9 |  |  | — |  |  | (0.9) |  |  | 87.0 |  |
| Asset-backed securities | 881.4 |  |  | 0.9 |  |  | (6.5) |  |  | 875.8 |  |
| Total available-for-sale investments | $ | 5,054.3 |  |  | $ | 3.5 |  |  | $ | (36.7) |  |  | $ | 5,021.1 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-11-21):
[0001327567-24-000040:note_history:47]
The following tables summarize the amortized cost, unrealized gains and losses, and fair value of our available-for-sale debt securities as of October 31, 2024 and July 31, 2024 (in millions):
  (was, 2024-05-21, similarity 0.9724):
[0001327567-24-000017:note_history:47]
The following tables summarize the amortized cost, unrealized gains and losses, and fair value of our available-for-sale debt securities as of April 30, 2024 and July 31, 2023 (in millions):

- changed (2024-11-21):
[0001327567-24-000040:note_history:48]
|  | October 31, 2024 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | $ | 228.7 |  |  | $ | — |  |  | $ | — |  |  | $ | 228.7 |  |
| Corporate debt securities | 34.2 |  |  | — |  |  | — |  |  | 34.2 |  |
| U.S. government and agency securities | 74.8 |  |  | — |  |  | — |  |  | 74.8 |  |
| Total available-for-sale cash equivalents | $ | 337.7 |  |  | $ | — |  |  | $ | — |  |  | $ | 337.7 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 15.7 |  |  | $ | — |  |  | $ | — |  |  | $ | 15.7 |  |
| Commercial paper | 36.1 |  |  | — |  |  | — |  |  | 36.1 |  |
| Corporate debt securities | 4,115.2 |  |  | 25.3 |  |  | (7.8) |  |  | 4,132.7 |  |
| U.S. government and agency securities | 21.9 |  |  | — |  |  | — |  |  | 21.9 |  |
| Non-U.S. government and agency securities | 38.6 |  |  | 0.5 |  |  | — |  |  | 39.1 |  |
| Asset-backed securities | 976.1 |  |  | 7.1 |  |  | (0.8) |  |  | 982.4 |  |
| Total available-for-sale investments | $ | 5,203.6 |  |  | $ | 32.9 |  |  | $ | (8.6) |  |  | $ | 5,227.9 |  |
  (was, 2024-05-21, similarity 0.6949):
[0001327567-24-000017:note_history:48]
|  | July 31, 2023 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | $ | 151.4 |  |  | $ | — |  |  | $ | — |  |  | $ | 151.4 |  |
| Total available-for-sale cash equivalents | $ | 151.4 |  |  | $ | — |  |  | $ | — |  |  | $ | 151.4 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 48.1 |  |  | $ | — |  |  | $ | — |  |  | $ | 48.1 |  |
| Commercial paper | 214.1 |  |  | — |  |  | (0.3) |  |  | 213.8 |  |
| Corporate debt securities | 3,313.5 |  |  | 1.3 |  |  | (32.5) |  |  | 3,282.3 |  |
| U.S. government and agency securities | 214.2 |  |  | — |  |  | (1.6) |  |  | 212.6 |  |
| Non-U.S. government and agency securities | 37.2 |  |  | — |  |  | (0.6) |  |  | 36.6 |  |
| Asset-backed securities | 512.0 |  |  | 0.2 |  |  | (3.0) |  |  | 509.2 |  |
| Total available-for-sale investments | $ | 4,339.1 |  |  | $ | 1.5 |  |  | $ | (38.0) |  |  | $ | 4,302.6 |  |

- changed (2024-11-21):
[0001327567-24-000040:note_history:49]
|  | July 31, 2024 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | $ | 299.6 |  |  | $ | — |  |  | $ | — |  |  | $ | 299.6 |  |
| Corporate debt securities | 18.2 |  |  | — |  |  | — |  |  | 18.2 |  |
| U.S. government and agency securities | 149.6 |  |  | — |  |  | — |  |  | 149.6 |  |
| Total available-for-sale cash equivalents | $ | 467.4 |  |  | $ | — |  |  | $ | — |  |  | $ | 467.4 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 20.6 |  |  | $ | — |  |  | $ | — |  |  | $ | 20.6 |  |
| Commercial paper | 79.9 |  |  | 0.1 |  |  | (0.1) |  |  | 79.9 |  |
| Corporate debt securities | 4,065.5 |  |  | 28.3 |  |  | (6.6) |  |  | 4,087.2 |  |
| U.S. government and agency securities | 21.9 |  |  | — |  |  | (0.2) |  |  | 21.7 |  |
| Non-U.S. government and agency securities | 57.9 |  |  | 0.7 |  |  | — |  |  | 58.6 |  |
| Asset-backed securities | 943.1 |  |  | 6.3 |  |  | (0.6) |  |  | 948.8 |  |
| Total available-for-sale investments | $ | 5,188.9 |  |  | $ | 35.4 |  |  | $ | (7.5) |  |  | $ | 5,216.8 |  |
  (was, 2024-05-21, similarity 0.9079):
[0001327567-24-000017:note_history:49]
|  | April 30, 2024 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | $ | 2.5 |  |  | $ | — |  |  | $ | — |  |  | $ | 2.5 |  |
| Total available-for-sale cash equivalents | $ | 2.5 |  |  | $ | — |  |  | $ | — |  |  | $ | 2.5 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 25.5 |  |  | $ | — |  |  | $ | — |  |  | $ | 25.5 |  |
| Commercial paper | 171.0 |  |  | — |  |  | (0.1) |  |  | 170.9 |  |
| Corporate debt securities | 3,803.5 |  |  | 2.6 |  |  | (28.8) |  |  | 3,777.3 |  |
| U.S. government and agency securities | 85.0 |  |  | — |  |  | (0.4) |  |  | 84.6 |  |
| Non-U.S. government and agency securities | 87.9 |  |  | — |  |  | (0.9) |  |  | 87.0 |  |
| Asset-backed securities | 881.4 |  |  | 0.9 |  |  | (6.5) |  |  | 875.8 |  |
| Total available-for-sale investments | $ | 5,054.3 |  |  | $ | 3.5 |  |  | $ | (36.7) |  |  | $ | 5,021.1 |  |

- changed (2024-11-21):
[0001327567-24-000040:note_history:50]
As of October 31, 2024, the gross unrealized losses that have been in a continuous unrealized loss position for less than 12 months were $7.3 million, which were related to $1.2 billion of available-for-sale debt securities, and the gross unrealized losses that have been in a continuous unrealized loss position for more than 12 months were $1.3 million, which were related to $372.5 million of available-for-sale debt securities. As of July 31, 2024 the gross unrealized losses that have been in a continuous unrealized loss position for less than 12 months were $1.5 million, which were related to $949.4 million of available-for-sale debt securities, and the gross unrealized losses that have been in a continuous unrealized loss position for more than 12 months were $6.0 million, which were related to $915.3 million of available-for-sale debt securities.
  (was, 2024-05-21, similarity 0.9915):
[0001327567-24-000017:note_history:50]
As of April 30, 2024, the gross unrealized losses that have been in a continuous unrealized loss position for less than 12 months were $30.3 million, which were related to $3.4 billion of available-for-sale debt securities, and the gross unrealized losses that have been in a continuous unrealized loss position for more than 12 months were $6.4 million, which were related to $722.1 million of available-for-sale debt securities. As of July 31, 2023 the gross unrealized losses that have been in a continuous unrealized loss position for less than 12 months were $30.7 million, which were related to $3.4 billion of available-for-sale debt securities, and the gross unrealized losses that have been in a continuous unrealized loss position for more than 12 months were $7.3 million, which were related to $481.8 million of available-for-sale debt securities.

- changed (2024-11-21):
[0001327567-24-000040:note_history:51]
Unrealized losses related to our available-for-sale debt securities are primarily due to interest rate fluctuations as opposed to credit quality. We do not intend to sell any of the securities in an unrealized loss position and it is not likely that we would be required to sell these securities before recovery of their amortized cost basis, which may be at maturity. We did not recognize any credit losses related to our available-for-sale debt securities during the three months ended October 31, 2024 and 2023.
  (was, 2024-05-21, similarity 0.9794):
[0001327567-24-000017:note_history:51]
Unrealized losses related to our available-for-sale debt securities are primarily due to interest rate fluctuations as opposed to credit quality. We do not intend to sell any of the securities in an unrealized loss position and it is not likely that we would be required to sell these securities before recovery of their amortized cost basis, which may be at maturity. We did not recognize any credit losses related to our available-for-sale debt securities during the three and nine months ended April 30, 2024 and 2023.

- changed (2024-11-21):
[0001327567-24-000040:note_history:52]
The following table summarizes the amortized cost and fair value of our available-for-sale debt securities as of October 31, 2024, by contractual years-to-maturity (in millions):
  (was, 2024-05-21, similarity 0.9708):
[0001327567-24-000017:note_history:52]
The following table summarizes the amortized cost and fair value of our available-for-sale debt securities as of April 30, 2024, by contractual years-to-maturity (in millions):

- added (2024-11-21):
[0001327567-24-000040:note_history:53]
Marketable equity securities consist of money market funds and are included in cash and cash equivalents on our condensed consolidated balance sheets. As of October 31, 2024 and July 31, 2024, the carrying values of our marketable equity securities were $1.1 billion and $494.0 million, respectively. There were no unrealized gains or losses recognized for these securities during the three months ended October 31, 2024 and 2023.

- removed (2024-11-21):
[0001327567-24-000017:note_history:54]
Marketable equity securities consist of money market funds and are included in cash and cash equivalents on our condensed consolidated balance sheets. As of April 30, 2024 and July 31, 2023, the carrying values of our marketable equity securities were $763.9 million and $476.1 million, respectively. There were no unrealized gains or losses recognized for these securities during the three and nine months ended April 30, 2024 and 2023.


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2024-11-21):
[0001327567-24-000040:note_history:55]
|  |  |  | Three Months Ended October 31, |
|  |  |  |  |  | 2024 |  | 2023 |
| Revenue: |  |  |  |  |  |  |  |
| Americas |  |  |  |  |  |  |  |
| United States |  |  |  |  | $ | 1,344.1 |  |  | $ | 1,204.3 |  |
| Other Americas |  |  |  |  | 98.0 |  |  | 82.3 |  |
| Total Americas |  |  |  |  | 1,442.1 |  |  | 1,286.6 |  |
| Europe, the Middle East, and Africa (“EMEA”) |  |  |  |  | 441.4 |  |  | 364.9 |  |
| Asia Pacific and Japan (“APAC”) |  |  |  |  | 255.3 |  |  | 226.6 |  |
| Total revenue |  |  |  |  | $ | 2,138.8 |  |  | $ | 1,878.1 |  |

- added (2024-11-21):
[0001327567-24-000040:note_history:56]
|  |  |  | Three Months Ended October 31, |
|  |  |  |  |  | 2024 |  | 2023 |
| Revenue: |  |  |  |  |  |  |  |
| Product |  |  |  |  | $ | 353.8 |  |  | $ | 341.1 |  |
| Subscription and support |  |  |  |  |  |  |  |
| Subscription |  |  |  |  | 1,191.8 |  |  | 988.3 |  |
| Support |  |  |  |  | 593.2 |  |  | 548.7 |  |
| Total subscription and support |  |  |  |  | 1,785.0 |  |  | 1,537.0 |  |
| Total revenue |  |  |  |  | $ | 2,138.8 |  |  | $ | 1,878.1 |  |

- changed (2024-11-21):
[0001327567-24-000040:note_history:57]
During the three months ended October 31, 2024 and 2023, we recognized approximately $1.6 billion and $1.4 billion of revenue pertaining to amounts that were deferred as of July 31, 2024 and 2023, respectively.
  (was, 2024-05-21, similarity 0.9544):
[0001327567-24-000017:note_history:57]
During the nine months ended April 30, 2024 and 2023, we recognized approximately $3.7 billion and $2.9 billion of revenue pertaining to amounts that were deferred as of July 31, 2023 and 2022, respectively.

- changed (2024-11-21):
[0001327567-24-000040:note_history:58]
Remaining performance obligations were $12.6 billion as of October 31, 2024, of which we expect to recognize as revenue approximately $5.9 billion over the next 12 months and the remainder thereafter.
  (was, 2024-05-21, similarity 0.9733):
[0001327567-24-000017:note_history:58]
Remaining performance obligations were $11.3 billion as of April 30, 2024, of which we expect to recognize as revenue approximately $5.4 billion over the next 12 months and the remainder thereafter.

- removed (2024-11-21):
[0001327567-24-000017:note_history:59]
|  | Three Months Ended April 30, |  | Nine Months Ended April 30, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Revenue: |  |  |  |  |  |  |  |
| Americas |  |  |  |  |  |  |  |
| United States | $ | 1,271.1 |  |  | $ | 1,105.2 |  |  | $ | 3,723.6 |  |  | $ | 3,153.8 |  |
| Other Americas | 88.5 |  |  | 74.0 |  |  | 256.8 |  |  | 213.1 |  |
| Total Americas | 1,359.6 |  |  | 1,179.2 |  |  | 3,980.4 |  |  | 3,366.9 |  |
| Europe, the Middle East, and Africa (“EMEA”) | 399.2 |  |  | 332.1 |  |  | 1,170.9 |  |  | 981.5 |  |
| Asia Pacific and Japan (“APAC”) | 226.0 |  |  | 209.6 |  |  | 686.7 |  |  | 591.0 |  |
| Total revenue | $ | 1,984.8 |  |  | $ | 1,720.9 |  |  | $ | 5,838.0 |  |  | $ | 4,939.4 |  |

- removed (2024-11-21):
[0001327567-24-000017:note_history:60]
|  | Three Months Ended April 30, |  | Nine Months Ended April 30, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Revenue: |  |  |  |  |  |  |  |
| Product | $ | 391.0 |  |  | $ | 388.1 |  |  | $ | 1,122.8 |  |  | $ | 1,071.0 |  |
| Subscription and support |  |  |  |  |  |  |  |
| Subscription | 1,045.6 |  |  | 838.1 |  |  | 3,061.0 |  |  | 2,417.5 |  |
| Support | 548.2 |  |  | 494.7 |  |  | 1,654.2 |  |  | 1,450.9 |  |
| Total subscription and support | 1,593.8 |  |  | 1,332.8 |  |  | 4,715.2 |  |  | 3,868.4 |  |
| Total revenue | $ | 1,984.8 |  |  | $ | 1,720.9 |  |  | $ | 5,838.0 |  |  | $ | 4,939.4 |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- changed (2024-11-21):
[0001327567-24-000040:note_history:61]
Subsequent Events
2025 Notes Conversion
  (was, 2024-05-21, similarity 0.9859):
[0001327567-24-000017:note_history:61]
Subsequent Event
2025 Notes Conversion

- changed (2024-11-21):
[0001327567-24-000040:note_history:62]
Subsequent to October 31, 2024, $106.0 million in aggregate principal amount of the 2025 Notes was converted or had been submitted by the holders for conversion and will settle during the fiscal quarter ending January 31, 2025.
  (was, 2024-05-21, similarity 0.9538):
[0001327567-24-000017:note_history:62]
Subsequent to April 30, 2024, $123.2 million in aggregate principal amount of the 2025 Notes was converted or had been submitted by the holders for conversion and will settle during the fiscal quarter ending July 31, 2024.

- added (2024-11-21):
[0001327567-24-000040:note_history:63]
Stock Split

- added (2024-11-21):
[0001327567-24-000040:note_history:64]
On November 19, 2024, our board of directors approved a two-for-one stock split (the “stock split”) of our outstanding shares of common stock. The stock split is to be effected through an amendment to our restated certificate of incorporation, which will also effect a proportionate increase in the number of authorized shares of our common stock from 1.0 billion to 2.0 billion.

- added (2024-11-21):
[0001327567-24-000040:note_history:65]
As a result of the stock split, each stockholder of record as of the close of trading on December 12, 2024 (the “record date”), will receive, after the close of trading on December 13, 2024, one additional share for every share held on the record date. Trading is expected to begin on a split-adjusted basis on December 16, 2024.

- removed (2024-11-21):
[0001327567-24-000017:note_history:66]
Acquisition

- removed (2024-11-21):
[0001327567-24-000017:note_history:67]
On May 15, 2024, we entered into a definitive agreement with International Business Machines Corporation to acquire certain QRadar assets including intellectual property, customer relationships, and customer contracts. We agreed to pay $500.0 million in cash upon closing, and may make additional post-closing payments contingent upon the migration of QRadar on-premise customers to Cortex XSIAM through December 31, 2027. We expect the acquisition will help accelerate the growth of our Cortex XSIAM platform.

- removed (2024-11-21):
[0001327567-24-000017:note_history:68]
The proposed acquisition is expected to close during our first quarter of fiscal 2025, subject to the satisfaction of regulatory approvals and other customary closing conditions.
