# PANW 8-K — 0001327567-24-000036 filed 2024-11-20

## item codes, every 8-K on or before 2024-11-21

- 2024-11-20 0001327567-24-000036 — 2.02, 8.01, 9.01
- 2024-11-15 0001193125-24-259308 — 8.01
- 2024-09-04 0001327567-24-000026 — 8.01, 9.01
- 2024-08-19 0001327567-24-000023 — 2.02, 8.01, 9.01
- 2024-05-20 0001327567-24-000015 — 2.02, 9.01
- 2024-05-16 0001327567-24-000010 — 8.01, 9.01
- 2024-02-20 0001327567-24-000003 — 2.02, 9.01
- 2023-12-14 0001193125-23-295527 — 5.02, 5.07, 9.01
- 2023-11-29 0001193125-23-285277 — 8.01, 9.01
- 2023-11-17 0001327567-23-000035 — 8.01, 9.01
- 2023-11-15 0001327567-23-000030 — 2.02, 9.01
- 2023-11-15 0001193125-23-277318 — 8.01
- 2023-08-18 0001327567-23-000020 — 2.02, 9.01
- 2023-06-08 0001193125-23-163506 — 7.01, 9.01
- 2023-06-05 0001193125-23-160228 — 7.01
- 2023-05-23 0001327567-23-000012 — 2.02, 9.01
- 2023-04-19 0001327567-23-000009 — 1.01, 2.03, 9.01
- 2023-02-21 0001327567-23-000005 — 2.02, 9.01
- 2022-12-16 0001193125-22-307346 — 5.02, 5.07
- 2022-11-17 0001327567-22-000035 — 2.02, 9.01
- 2022-11-15 0001193125-22-285017 — 8.01
- 2022-08-22 0001327567-22-000020 — 2.02, 8.01, 9.01
- 2022-05-23 0001193125-22-157474 — 5.02, 5.03, 9.01
- 2022-05-19 0001327567-22-000014 — 2.02, 9.01
- 2022-02-23 0001193125-22-049906 — 5.02
- 2022-02-22 0001327567-22-000006 — 2.02, 9.01
- 2021-12-15 0001193125-21-358074 — 5.02, 5.07
- 2021-11-18 0001327567-21-000037 — 2.02, 9.01
- 2021-10-12 0001193125-21-296438 — 3.01, 7.01, 9.01
- 2021-09-13 0001193125-21-270979 — 7.01, 9.01
- 2021-09-08 0001193125-21-267862 — 5.02, 9.01
- 2021-08-23 0001327567-21-000020 — 2.02, 9.01
- 2021-08-12 0001193125-21-244832 — 5.02, 9.01
- 2021-05-20 0001327567-21-000012 — 2.02, 9.01
- 2021-05-18 0001193125-21-164169 — 5.02 — amendment of 0001193125-21-162161
- 2021-05-14 0001193125-21-162161 — 5.02, 9.01
- 2021-03-19 0001193125-21-087516 — 5.02, 9.01
- 2021-02-22 0001628280-21-002659 — 2.02, 9.01
- 2021-02-22 0001193125-21-049293 — 5.02, 9.01
- 2020-12-18 0001193125-20-321568 — 8.01, 9.01
- 2020-12-16 0001193125-20-319091 — 3.02 — amendment of 0001193125-20-291707
- 2020-12-10 0001193125-20-314920 — 5.07
- 2020-12-08 0001193125-20-312056 — 5.02, 8.01, 9.01
- 2020-11-16 0001327567-20-000037 — 2.02, 9.01
- 2020-11-12 0001193125-20-291707 — 3.02
- 2020-10-19 0001193125-20-272060 — 5.02
- 2020-08-24 0001327567-20-000025 — 2.02, 9.01
- 2020-06-23 0001193125-20-176553 — 5.02, 9.01
- 2020-06-22 0001193125-20-175603 — 5.02, 9.01
- 2020-06-08 0001193125-20-163579 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2020-05-21 0001327567-20-000015 — 2.02, 9.01
- 2020-02-27 0001193125-20-050335 — 1.01, 2.03
- 2020-02-24 0001327567-20-000002 — 2.02, 9.01
- 2019-12-19 0001193125-19-319166 — 1.02, 9.01
- 2019-12-10 0001193125-19-310251 — 5.07
- 2019-11-25 0001327567-19-000036 — 2.02, 9.01
- 2019-11-25 0001193125-19-299886 — 5.02, 8.01 — amendment of 0001327567-19-000011
- 2019-10-22 0001193125-19-271660 — 5.02
- 2019-09-06 0001327567-19-000026 — 9.01 — amendment of 0001327567-19-000023
- 2019-09-04 0001327567-19-000023 — 2.02, 7.01, 9.01
- 2019-07-11 0001193125-19-192415 — 5.02, 9.01
- 2019-05-29 0001327567-19-000014 — 2.02, 9.01
- 2019-04-15 0001327567-19-000011 — 5.02, 9.01
- 2019-04-01 0001193125-19-094613 — 8.01, 9.01
- 2019-03-28 0001193125-19-090572 — 3.02 — amendment of 0001327567-19-000003
- 2019-02-26 0001327567-19-000006 — 2.02, 8.01, 9.01
- 2019-02-19 0001327567-19-000003 — 3.02
- 2018-12-11 0001327567-18-000033 — 5.07
- 2018-11-29 0001327567-18-000029 — 2.02, 9.01
- 2018-10-15 0001193125-18-299312 — 5.02, 9.01
- 2018-09-25 0001193125-18-282542 — 5.02
- 2018-09-14 0001193125-18-274239 — 5.03, 9.01
- 2018-09-06 0001327567-18-000018 — 1.01, 2.02, 2.03, 9.01
- 2018-07-13 0001193125-18-217281 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2018-06-04 0001327567-18-000011 — 2.02, 5.02, 9.01
- 2018-02-26 0001327567-18-000004 — 2.02, 5.02, 7.01, 9.01
- 2017-12-12 0001193125-17-367477 — 5.07
- 2017-11-20 0001327567-17-000032 — 2.02, 5.02, 9.01
- 2017-08-31 0001327567-17-000021 — 2.02, 5.02, 9.01
- 2017-05-31 0001327567-17-000016 — 2.02, 9.01
- 2017-02-28 0001327567-17-000005 — 2.02, 8.01, 9.01
- 2016-12-12 0001193125-16-790757 — 5.07
- 2016-11-21 0001327567-16-000071 — 2.02, 9.01
- 2016-10-24 0001193125-16-745121 — 5.02, 9.01
- 2016-08-30 0001327567-16-000057 — 2.02, 5.03, 8.01, 9.01
- 2016-08-22 0001193125-16-687588 — 5.02, 9.01
- 2016-05-26 0001327567-16-000051 — 2.02, 9.01
- 2016-02-25 0001327567-16-000044 — 2.02, 5.02, 9.01
- 2015-12-14 0001327567-15-000038 — 5.07
- 2015-12-14 0001193125-15-402588 — 1.01, 9.01
- 2015-11-23 0001327567-15-000033 — 2.02, 9.01
- 2015-10-19 0001193125-15-347005 — 1.01, 9.01 — amendment, the index does not say of what
- 2015-09-09 0001327567-15-000022 — 2.02, 9.01
- 2015-08-19 0001193125-15-296115 — 1.01, 2.03
- 2015-06-01 0001193125-15-207786 — 1.01, 2.03
- 2015-05-27 0001327567-15-000015 — 2.02, 9.01
- 2015-03-02 0001327567-15-000006 — 2.02, 9.01
- 2014-12-15 0001327567-14-000046 — 5.07
- 2014-11-24 0001327567-14-000040 — 2.02, 9.01
- 2014-09-22 0001193125-14-348581 — 5.02, 9.01
- 2014-09-09 0001327567-14-000025 — 2.02, 9.01
- 2014-07-01 0001193125-14-257824 — 1.01, 2.03, 3.02, 9.01
- 2014-06-26 0001193125-14-249529 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2014-06-20 0001327567-14-000020 — 9.01 — amendment of 0001193125-14-140511
- 2014-06-04 0001327567-14-000016 — 3.02
- 2014-05-30 0001193125-14-218158 — 2.02 — amendment, the index does not say of what
- 2014-05-28 0001193125-14-215060 — 1.01, 2.02, 3.02, 9.01
- 2014-04-11 0001193125-14-140511 — 2.01, 3.02, 7.01, 9.01
- 2014-03-24 0001193125-14-111318 — 1.01, 3.02, 7.01, 9.01
- 2014-03-13 0001327567-14-000009 — 5.02
- 2014-02-24 0001193125-14-063754 — 2.02, 9.01
- 2013-12-12 0001327567-13-000040 — 5.07
- 2013-11-25 0001327567-13-000033 — 2.02, 9.01
- 2013-09-30 0001193125-13-384966 — 8.01
- 2013-09-09 0001193125-13-361421 — 2.02, 9.01
- 2013-05-30 0001193125-13-241542 — 2.02, 5.02, 9.01
- 2013-03-11 0001193125-13-101082 — 5.02, 9.01
- 2013-02-28 0001193125-13-084193 — 2.02, 9.01
- 2012-12-14 0001193125-12-503335 — 5.07
- 2012-12-06 0001193125-12-493700 — 2.02, 9.01
- 2012-09-24 0001193125-12-401534 — 1.01, 2.03
- 2012-09-20 0001193125-12-398433 — 5.02, 9.01
- 2012-09-10 0001193125-12-386605 — 2.02, 9.01

## late-filing notifications on or before 2024-11-21

- none on or before 2024-11-21

## item 2.02 — earnings release, exhibit 99.1

[0001327567-24-000036:8k_2_02:1]
EX-99.1
2
ex991q125earningsrelease.htm
EX-99.1

[0001327567-24-000036:8k_2_02:2]
Document

[0001327567-24-000036:8k_2_02:3]
Exhibit 99.1

[0001327567-24-000036:8k_2_02:4]
Palo Alto Networks Reports Fiscal First Quarter 2025 Financial Results

[0001327567-24-000036:8k_2_02:5]
•Fiscal first quarter revenue grew 14% year over year to $2.1 billion.

[0001327567-24-000036:8k_2_02:6]
•Next-Generation Security ARR grew 40% year over year to $4.5 billion.

[0001327567-24-000036:8k_2_02:7]
•Remaining performance obligation grew 20% year over year to $12.6 billion.

[0001327567-24-000036:8k_2_02:8]
SANTA CLARA, Calif., Nov. 20, 2024 — Palo Alto Networks (NASDAQ: PANW), the global cybersecurity leader, announced today financial results for its fiscal first quarter 2025, ended October 31, 2024.

[0001327567-24-000036:8k_2_02:9]
Total revenue for the fiscal first quarter 2025 grew 14% year over year to $2.1 billion, compared with total revenue of $1.9 billion for the fiscal first quarter 2024. GAAP net income for the fiscal first quarter 2025 was $350.7 million, or $0.99 per diluted share, compared with GAAP net income of $194.2 million, or $0.56 per diluted share, for the fiscal first quarter 2024.

[0001327567-24-000036:8k_2_02:10]
Non-GAAP net income for the fiscal first quarter 2025 was $544.9 million, or $1.56 per diluted share, compared with non-GAAP net income of $466.3 million, or $1.38 per diluted share, for the fiscal first quarter 2024. A reconciliation between GAAP and non-GAAP information is contained in the tables below.

[0001327567-24-000036:8k_2_02:11]
"Our Q1 results reinforced our conviction in our differentiated platformization strategy," said Nikesh Arora, chairman and CEO of Palo Alto Networks. "We see a growing market realization that platformization is the game changer that will solve security and enable better AI outcomes. I expect this will be a multiyear trend for which we are best positioned to deliver to our customers."

[0001327567-24-000036:8k_2_02:12]
"Our platformization progress continued in Q1, driving strong financial results,” said Dipak Golechha, chief financial officer of Palo Alto Networks. "As a result, we are raising our NGS ARR, revenue and non-GAAP EPS guidance for the year."

[0001327567-24-000036:8k_2_02:13]
Stock Split

[0001327567-24-000036:8k_2_02:14]
Palo Alto Networks announced that its board of directors has approved a two-for-one forward stock split of the company’s outstanding shares of common stock. The stock split is to be effected through an amendment to the company’s restated certificate of incorporation, which will also effect

[0001327567-24-000036:8k_2_02:15]
a proportionate increase in the number of authorized shares of common stock from 1.0 billion to 2.0 billion. Each stockholder of record as of the close of trading on December 12, 2024 (the “record date”), will receive, after the close of trading on December 13, 2024, one additional share for every share held on the record date. Trading is expected to begin on a split-adjusted basis on December 16, 2024.

[0001327567-24-000036:8k_2_02:16]
Financial Outlook

[0001327567-24-000036:8k_2_02:17]
Palo Alto Networks provides guidance based on current market conditions and expectations.

[0001327567-24-000036:8k_2_02:18]
For the fiscal second quarter 2025, we expect:

[0001327567-24-000036:8k_2_02:19]
•Next-Generation Security ARR of $4.70 billion to $4.75 billion, representing year-over-year growth of between 35% and 36%.

[0001327567-24-000036:8k_2_02:20]
•Remaining performance obligation of $12.9 billion to $13.0 billion, representing year-over-year growth of between 20% and 21%.

[0001327567-24-000036:8k_2_02:21]
•Total revenue in the range of $2.22 billion to $2.25 billion, representing year-over-year growth of between 12% and 14%.

[0001327567-24-000036:8k_2_02:22]
•Diluted non-GAAP net income per share in the range of $1.54 to $1.56, using 350 million to 352 million shares outstanding.

[0001327567-24-000036:8k_2_02:23]
For the fiscal year 2025, we expect:

[0001327567-24-000036:8k_2_02:24]
•Next-Generation Security ARR of $5.52 billion to $5.57 billion, representing year-over-year growth of between 31% and 32%.

[0001327567-24-000036:8k_2_02:25]
•Remaining performance obligation of $15.2 billion to $15.3 billion, representing year-over-year growth of between 19% and 20%.

[0001327567-24-000036:8k_2_02:26]
•Total revenue in the range of $9.12 billion to $9.17 billion, representing year-over-year growth of 14%.

[0001327567-24-000036:8k_2_02:27]
•Non-GAAP operating margin in the range of 27.5% to 28.0%.

[0001327567-24-000036:8k_2_02:28]
•Diluted non-GAAP net income per share in the range of $6.26 to $6.39, using 350 million to 354 million shares outstanding.

[0001327567-24-000036:8k_2_02:29]
•Adjusted free cash flow margin in the range of 37% to 38%.

[0001327567-24-000036:8k_2_02:30]
Guidance for non-GAAP financial measures excludes share-based compensation-related charges, including share-based payroll tax expense, acquisition-related costs, including change in fair value of contingent consideration liability, amortization expense of acquired intangible assets, litigation-related charges, non-cash charges related to convertible notes, and income tax and other tax adjustments related to our long-term non-GAAP effective tax rate, along with certain non-recurring expenses and certain non-recurring cash flows. We have not reconciled non-GAAP operating margin guidance to GAAP operating margin, diluted non-GAAP net income per share guidance to GAAP net income per diluted share or adjusted free cash flow margin guidance to GAAP net cash from operating activities because we do not provide guidance on GAAP operating margin, GAAP net income or net cash from operating activities and would not be able to present the various reconciling cash and non-cash items between GAAP and non-GAAP financial measures because certain items that impact these measures are uncertain or out of our control, or cannot be reasonably predicted, including share-based compensation expense, without unreasonable effort. The actual amounts of such reconciling items will have a significant impact on the company's GAAP net income per diluted share and GAAP net cash from operating activities.

[0001327567-24-000036:8k_2_02:31]
Earnings Call Information

[0001327567-24-000036:8k_2_02:32]
Palo Alto Networks will host a video webcast for analysts and investors to discuss the company’s fiscal first quarter 2025 results as well as the outlook for its fiscal second quarter and fiscal year 2025 today at 4:30 p.m. Eastern time/1:30 p.m. Pacific time. Open to the public, investors may access the webcast, supplemental financial information and earnings slides from the “Investors” section of the company’s website at investors.paloaltonetworks.com. A replay will be available three hours after the conclusion of the webcast and archived for one year.

[0001327567-24-000036:8k_2_02:33]
Forward-Looking Statements

[0001327567-24-000036:8k_2_02:34]
This press release contains forward-looking statements that involve risks, uncertainties, and assumptions including statements regarding our platformization strategy and financial outlook for the fiscal second quarter 2025 and fiscal year 2025. There are a significant number of factors that could cause actual results to differ materially from forward-looking statements made or implied in this press release, including: developments and changes in general market, political, economic, and business conditions; failure of our platformization product offerings; failure to achieve the expected benefits of our strategic partnerships and acquisitions; changes in the fair value of our contingent consideration liability associated with acquisitions; risks associated with managing our growth; risks associated with new product, subscription and support offerings, including our product offerings that leverage AI; shifts in priorities or delays in the development or release of new product or subscription or other offerings, or the failure to timely develop and achieve market acceptance of new products and subscriptions as well as existing products, subscriptions and support offerings; failure of our business strategies; rapidly evolving technological developments in the market for security products, subscriptions and support offerings; defects, errors, or vulnerabilities in our products, subscriptions or support offerings; our customers’ purchasing decisions and the length of sales cycles; our competition; our ability to attract and retain new customers; our ability to acquire and integrate other companies, products, or technologies in a successful manner; our debt repayment obligations; and our share repurchase program, which may not be fully consummated or enhance shareholder value, and any share repurchases which could affect the price of our common stock.

[0001327567-24-000036:8k_2_02:35]
Additional risks and uncertainties on these and other factors that could affect our financial results and the forward-looking statements we make in this press release are included under the captions "Risk Factors" and "Management's Discussion and Analysis of Financial Condition and Results of Operations" and elsewhere in our Annual Report on Form 10-K filed with the U.S. Securities and Exchange Commission (“SEC”) on September 6, 2024, which is available on our website at investors.paloaltonetworks.com and on the SEC's website at www.sec.gov. Additional information will also be set forth in other documents that we file with or furnish to the SEC from time to time. All forward-looking statements in this press release are based on our beliefs and information available to management as of the date hereof, and we do not assume any obligation to update the forward-looking statements provided to reflect events that occur or circumstances that exist after the date on which they were made.

[0001327567-24-000036:8k_2_02:36]
Non-GAAP Financial Measures and Other Key Metrics

[0001327567-24-000036:8k_2_02:37]
Palo Alto Networks has provided in this press release financial information that has not been prepared in accordance with generally accepted accounting principles in the United States (GAAP). The company uses these non-GAAP financial measures and other key metrics internally in analyzing its financial results and believes that the use of these non-GAAP financial measures and key metrics are helpful to investors as an additional tool to evaluate ongoing operating results and trends, and in comparing the company’s financial results with other companies in its industry, many of which present similar non-GAAP financial measures or key metrics.

[0001327567-24-000036:8k_2_02:38]
The presentation of these non-GAAP financial measures and key metrics are not meant to be considered in isolation or as a substitute for comparable GAAP financial measures and should be read only in conjunction with the company’s consolidated financial statements prepared in accordance with GAAP. A reconciliation of the company’s historical non-GAAP financial measures to their most directly comparable GAAP measures has been provided in the financial statement tables included in this press release, and investors are encouraged to review these reconciliations.

[0001327567-24-000036:8k_2_02:39]
Non-GAAP operating margin. Palo Alto Networks defines non-GAAP operating margin as non-GAAP operating income divided by total revenue. The company defines non-GAAP operating income as operating income plus share-based compensation-related charges, including share-based payroll tax expense, acquisition-related costs, including change in fair value of contingent consideration liability, amortization expense of acquired intangible assets, and litigation-related charges. The company believes that non-GAAP operating margin provides management and investors with greater visibility into the underlying performance of the company’s core business operating results.

[0001327567-24-000036:8k_2_02:40]
Non-GAAP net income and net income per share, diluted. Palo Alto Networks defines non-GAAP net income as net income plus share-based compensation-related charges, including share-based payroll tax expense, acquisition-related costs, including change in fair value of contingent consideration liability, amortization expense of acquired intangible assets, litigation-related charges, including legal settlements, and non-cash charges related to convertible notes. The company also excludes from non-GAAP net income tax adjustments related to our long-term non-GAAP effective tax rate in order to provide a complete picture of the company’s recurring core business operating results. The company defines non-GAAP net income per share, diluted, as non-GAAP net income divided by the weighted-average diluted shares outstanding, which includes the potentially dilutive effect of the company’s employee equity incentive plan awards and the company’s convertible senior notes outstanding and related warrants, after giving effect to the anti-dilutive impact of the company’s note hedge agreements, which reduces the potential economic dilution that otherwise would occur upon conversion of the company’s convertible senior notes. Under GAAP, the anti-dilutive impact of the note hedge is not reflected in diluted shares outstanding. The company considers these non-GAAP financial measures to be useful metrics for management and investors for the same reasons that it uses non-GAAP operating margin.

[0001327567-24-000036:8k_2_02:41]
Next-Generation Security ARR. Palo Alto Networks defines Next-Generation Security ARR as the annualized allocated revenue of all active contracts as of the final day of the reporting period for Prisma and Cortex offerings inclusive of the VM-Series and related services, and certain cloud-delivered security services. Beginning the fiscal first quarter 2025, Next-Generation Security ARR includes revenue attributable to QRadar software as a service contracts that we recently acquired from International Business Machines Corporation. The company considers Next-Generation Security ARR to be a useful metric for management and investors to evaluate the performance of the company because Next-Generation Security is where the company has focused its innovation and the company expects its overall revenue to be disproportionately driven by this Next-Generation Security portfolio. Because Next-Generation Security ARR does not have the effect of providing a numerical measure that is different from any comparable GAAP measure, the company does not consider it a non-GAAP measure.

[0001327567-24-000036:8k_2_02:42]
Investors are cautioned that there are a number of limitations associated with the use of non-GAAP financial measures and key metrics as analytical tools. Many of the adjustments to the company’s GAAP financial measures reflect the exclusion of items that are recurring and will be reflected in the company’s financial results for the foreseeable future, such as share-based compensation, which is an important part of Palo Alto Networks employees’ compensation and impacts their performance. Furthermore, these non-GAAP financial measures are not based on any standardized methodology prescribed by GAAP, and the components that Palo Alto Networks excludes in its calculation of non-GAAP financial measures may differ from the components that its peer companies exclude when they report their non-GAAP results of operations. Palo Alto Networks compensates for these limitations by providing specific information regarding the GAAP amounts excluded from these non-GAAP financial measures. In the future, the company may also exclude non-recurring expenses and other expenses that do not reflect the company’s core business operating results.

[0001327567-24-000036:8k_2_02:43]
About Palo Alto Networks

[0001327567-24-000036:8k_2_02:44]
Palo Alto Networks is the global cybersecurity leader, committed to making each day safer than the one before with industry-leading, AI-powered solutions in network security, cloud security and security operations. Powered by Precision AI, our technologies deliver precise threat detection and swift response, minimizing false positives and enhancing security effectiveness. Our platformization approach integrates diverse security solutions into a unified, scalable platform, streamlining management and providing operational efficiencies with comprehensive protection. From defending network perimeters to safeguarding cloud environments and ensuring rapid incident response, Palo Alto Networks empowers businesses to achieve Zero Trust security and confidently embrace digital transformation in an ever-evolving threat landscape. This unwavering commitment to security and innovation makes us the cybersecurity partner of choice.

[0001327567-24-000036:8k_2_02:45]
At Palo Alto Networks, we're committed to bringing together the very best people in service of our mission, so we're also proud to be the cybersecurity workplace of choice, recognized among Newsweek's Most Loved Workplaces (2021-2024), with a score of 100 on the Disability Equality Index (2024, 2023, 2022), and HRC Best Places for LGBTQ+ Equality (2022). For more information, visit www.paloaltonetworks.com.

[0001327567-24-000036:8k_2_02:46]
Palo Alto Networks, the Palo Alto Networks logo, and Precision AI are trademarks of Palo Alto Networks, Inc. in the United States and in jurisdictions throughout the world. All other trademarks, trade names, or service marks used or mentioned herein belong to their respective owners. Any unreleased services or features (and any services or features not generally available to customers) referenced in this or other press releases or public statements are not currently available (or are not yet generally available to customers) and may not be delivered when expected or at all. Customers who purchase Palo Alto Networks applications should make their purchase decisions based on services and features currently generally available.

[0001327567-24-000036:8k_2_02:47]
Media Contact:

[0001327567-24-000036:8k_2_02:48]
Nicole Hockin

[0001327567-24-000036:8k_2_02:49]
VP, Global Communications, Palo Alto Networks

[0001327567-24-000036:8k_2_02:50]
press@paloaltonetworks.com

[0001327567-24-000036:8k_2_02:51]
Investor Relations Contact:

[0001327567-24-000036:8k_2_02:52]
Ryan Fenwick

[0001327567-24-000036:8k_2_02:53]
Sr. Manager - Investor Relations, Palo Alto Networks

[0001327567-24-000036:8k_2_02:54]
ir@paloaltonetworks.com

[0001327567-24-000036:8k_2_02:55]
1

[0001327567-24-000036:8k_2_02:56]
| Palo Alto Networks, Inc. |
| Preliminary Condensed Consolidated Statements of Operations |
| (In millions, except per share data) |
| (Unaudited) |
|  | Three Months Ended |  |  |
|  | October 31, |  |  |
|  | 2024 |  | 2023 |  |  |  |  |
| Revenue: |  |  |  |  |  |  |  |
| Product | $ | 353.8 |  |  | $ | 341.1 |  |  |  |  |  |
| Subscription and support | 1,785.0 |  |  | 1,537.0 |  |  |  |  |  |
| Total revenue | 2,138.8 |  |  | 1,878.1 |  |  |  |  |  |
| Cost of revenue: |  |  |  |  |  |  |  |
| Product | 75.0 |  |  | 77.4 |  |  |  |  |  |
| Subscription and support | 479.1 |  |  | 395.4 |  |  |  |  |  |
| Total cost of revenue | 554.1 |  |  | 472.8 |  |  |  |  |  |
| Total gross profit | 1,584.7 |  |  | 1,405.3 |  |  |  |  |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 480.4 |  |  | 409.5 |  |  |  |  |  |
| Sales and marketing | 720.1 |  |  | 660.5 |  |  |  |  |  |
| General and administrative | 97.7 |  |  | 120.1 |  |  |  |  |  |
| Total operating expenses | 1,298.2 |  |  | 1,190.1 |  |  |  |  |  |
| Operating income | 286.5 |  |  | 215.2 |  |  |  |  |  |
| Interest expense | (1.2) |  |  | (2.9) |  |  |  |  |  |
| Other income, net | 83.3 |  |  | 70.3 |  |  |  |  |  |
| Income before income taxes | 368.6 |  |  | 282.6 |  |  |  |  |  |
| Provision for income taxes | 17.9 |  |  | 88.4 |  |  |  |  |  |
| Net income | $ | 350.7 |  |  | $ | 194.2 |  |  |  |  |  |
| Net income per share, basic | $ | 1.07 |  |  | $ | 0.63 |  |  |  |  |  |
| Net income per share, diluted | $ | 0.99 |  |  | $ | 0.56 |  |  |  |  |  |
| Weighted-average shares used to compute net income per share, basic | 326.8 |  |  | 310.1 |  |  |  |  |  |
| Weighted-average shares used to compute net income per share, diluted | 354.5 |  |  | 349.8 |  |  |  |  |  |

[0001327567-24-000036:8k_2_02:57]
2

[0001327567-24-000036:8k_2_02:58]
| Palo Alto Networks, Inc. |
| Reconciliation of GAAP to Non-GAAP Financial Measures |
| (In millions, except per share amounts) |
| (Unaudited) |
|  | Three Months Ended |  |  |
|  | October 31, |  |  |
|  | 2024 |  | 2023 |  |  |  |  |
| GAAP operating income | $ | 286.5 |  |  | $ | 215.2 |  |  |  |  |  |
| Share-based compensation-related charges | 315.1 |  |  | 287.8 |  |  |  |  |  |
| Acquisition-related costs(1) | 15.1 |  |  | — |  |  |  |  |  |
| Amortization expense of acquired intangible assets | 40.7 |  |  | 24.5 |  |  |  |  |  |
| Litigation-related charges(2) | (41.2) |  |  | 1.8 |  |  |  |  |  |
| Non-GAAP operating income | $ | 616.2 |  |  | $ | 529.3 |  |  |  |  |  |
| Non-GAAP operating margin | 28.8 | % |  | 28.2 | % |  |  |  |  |
| GAAP net income | $ | 350.7 |  |  | $ | 194.2 |  |  |  |  |  |
| Share-based compensation-related charges | 315.1 |  |  | 287.8 |  |  |  |  |  |
| Acquisition-related costs(1) | 15.1 |  |  | — |  |  |  |  |  |
| Amortization expense of acquired intangible assets | 40.7 |  |  | 24.5 |  |  |  |  |  |
| Litigation-related charges(2) | (41.2) |  |  | 1.8 |  |  |  |  |  |
| Non-cash charges related to convertible notes(3) | 0.5 |  |  | 1.0 |  |  |  |  |  |
| Income tax and other tax adjustments(4) | (136.0) |  |  | (43.0) |  |  |  |  |  |
| Non-GAAP net income | $ | 544.9 |  |  | $ | 466.3 |  |  |  |  |  |
| GAAP net income per share, diluted | $ | 0.99 |  |  | $ | 0.56 |  |  |  |  |  |
| Share-based compensation-related charges | 0.92 |  |  | 0.86 |  |  |  |  |  |
| Acquisition-related costs(1) | 0.04 |  |  | 0.00 |  |  |  |  |  |
| Amortization expense of acquired intangible assets | 0.11 |  |  | 0.07 |  |  |  |  |  |
| Litigation-related charges(2) | (0.12) |  |  | 0.01 |  |  |  |  |  |
| Non-cash charges related to convertible notes(3) | 0.00 |  |  | 0.00 |  |  |  |  |  |
| Income tax and other tax adjustments(4) | (0.38) |  |  | (0.12) |  |  |  |  |  |
| Non-GAAP net income per share, diluted | $ | 1.56 |  |  | $ | 1.38 |  |  |  |  |  |
| GAAP weighted-average shares used to compute net income per share, diluted | 354.5 |  |  | 349.8 |  |  |  |  |  |
| Weighted-average anti-dilutive impact of note hedge agreements | (5.9) |  |  | (11.6) |  |  |  |  |  |
| Non-GAAP weighted-average shares used to compute net income per share, diluted | 348.6 |  |  | 338.2 |  |  |  |  |  |

[0001327567-24-000036:8k_2_02:59]
(1)    Consists of acquisition transaction costs, share-based compensation related to the cash settlement of certain equity awards, change in fair value of contingent consideration liability, and costs to terminate certain employment, operating lease, and other contracts of the acquired companies.

[0001327567-24-000036:8k_2_02:60]
(2)    Consists of the amortization of intellectual property licenses and covenant not to sue. During the three months ended October 31, 2024, it also includes a release of previously accrued legal contingency charge.

[0001327567-24-000036:8k_2_02:61]
(3)     Consists of non-cash interest expense for amortization of debt issuance costs related to the company's convertible senior notes.

[0001327567-24-000036:8k_2_02:62]
(4)    Consists of income tax adjustments related to our long-term non-GAAP effective tax rate.

[0001327567-24-000036:8k_2_02:63]
3

[0001327567-24-000036:8k_2_02:64]
| Palo Alto Networks, Inc. |
| Preliminary Condensed Consolidated Balance Sheets |
| (In millions) |
|  | October 31, 2024 |  | July 31, 2024 |
|  | (unaudited) |  |  |
| Assets |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 2,282.8 |  |  | $ | 1,535.2 |  |
| Short-term investments | 1,108.2 |  |  | 1,043.6 |  |
| Accounts receivable, net | 1,132.9 |  |  | 2,618.6 |  |
| Short-term financing receivables, net | 805.1 |  |  | 725.9 |  |
| Short-term deferred contract costs | 367.6 |  |  | 369.0 |  |
| Prepaid expenses and other current assets | 546.1 |  |  | 557.4 |  |
| Total current assets | 6,242.7 |  |  | 6,849.7 |  |
| Property and equipment, net | 361.0 |  |  | 361.1 |  |
| Operating lease right-of-use assets | 389.0 |  |  | 385.9 |  |
| Long-term investments | 4,119.7 |  |  | 4,173.2 |  |
| Long-term financing receivables, net | 1,092.2 |  |  | 1,182.1 |  |
| Long-term deferred contract costs | 531.9 |  |  | 562.0 |  |
| Goodwill | 4,050.8 |  |  | 3,350.1 |  |
| Intangible assets, net | 809.6 |  |  | 374.9 |  |
| Deferred tax assets | 2,397.5 |  |  | 2,399.0 |  |
| Other assets | 380.2 |  |  | 352.9 |  |
| Total assets | $ | 20,374.6 |  |  | $ | 19,990.9 |  |
| Liabilities and stockholders’ equity |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 211.6 |  |  | $ | 116.3 |  |
| Accrued compensation | 354.5 |  |  | 554.7 |  |
| Accrued and other liabilities | 683.1 |  |  | 506.7 |  |
| Deferred revenue | 5,507.7 |  |  | 5,541.1 |  |
| Convertible senior notes, net | 645.8 |  |  | 963.9 |  |
| Total current liabilities | 7,402.7 |  |  | 7,682.7 |  |
| Long-term deferred revenue | 5,585.9 |  |  | 5,939.4 |  |
| Deferred tax liabilities | 250.8 |  |  | 387.7 |  |
| Long-term operating lease liabilities | 379.6 |  |  | 380.5 |  |
| Other long-term liabilities | 843.8 |  |  | 430.9 |  |
| Total liabilities | 14,462.8 |  |  | 14,821.2 |  |
| Stockholders’ equity: |  |  |  |
| Preferred stock | — |  |  | — |  |
| Common stock and additional paid-in capital | 4,214.9 |  |  | 3,821.1 |  |
| Accumulated other comprehensive loss | (4.0) |  |  | (1.6) |  |
| Retained earnings | 1,700.9 |  |  | 1,350.2 |  |
| Total stockholders’ equity | 5,911.8 |  |  | 5,169.7 |  |
| Total liabilities and stockholders’ equity | $ | 20,374.6 |  |  | $ | 19,990.9 |  |

[0001327567-24-000036:8k_2_02:65]
4
