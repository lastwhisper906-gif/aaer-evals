# PANW 8-K — 0001327567-14-000040 filed 2014-11-24

## item codes, every 8-K on or before 2014-11-25

- 2014-11-24 0001327567-14-000040 — 2.02, 9.01
- 2014-09-22 0001193125-14-348581 — 5.02, 9.01
- 2014-09-09 0001327567-14-000025 — 2.02, 9.01
- 2014-07-01 0001193125-14-257824 — 1.01, 2.03, 3.02, 9.01
- 2014-06-26 0001193125-14-249529 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2014-06-20 0001327567-14-000020 — 9.01 — amendment of 0001193125-14-140511
- 2014-06-04 0001327567-14-000016 — 3.02
- 2014-05-30 0001193125-14-218158 — 2.02 — amendment, the index does not say of what
- 2014-05-28 0001193125-14-215060 — 1.01, 2.02, 3.02, 9.01
- 2014-04-11 0001193125-14-140511 — 2.01, 3.02, 7.01, 9.01
- 2014-03-24 0001193125-14-111318 — 1.01, 3.02, 7.01, 9.01
- 2014-03-13 0001327567-14-000009 — 5.02
- 2014-02-24 0001193125-14-063754 — 2.02, 9.01
- 2013-12-12 0001327567-13-000040 — 5.07
- 2013-11-25 0001327567-13-000033 — 2.02, 9.01
- 2013-09-30 0001193125-13-384966 — 8.01
- 2013-09-09 0001193125-13-361421 — 2.02, 9.01
- 2013-05-30 0001193125-13-241542 — 2.02, 5.02, 9.01
- 2013-03-11 0001193125-13-101082 — 5.02, 9.01
- 2013-02-28 0001193125-13-084193 — 2.02, 9.01
- 2012-12-14 0001193125-12-503335 — 5.07
- 2012-12-06 0001193125-12-493700 — 2.02, 9.01
- 2012-09-24 0001193125-12-401534 — 1.01, 2.03
- 2012-09-20 0001193125-12-398433 — 5.02, 9.01
- 2012-09-10 0001193125-12-386605 — 2.02, 9.01

## late-filing notifications on or before 2014-11-25

- none on or before 2014-11-25

## item 2.02 — earnings release, exhibit 99.1

[0001327567-14-000040:8k_2_02:1]
EX-99.1
2
ex991q115earningsrelease.htm
EXHIBIT 99.1

[0001327567-14-000040:8k_2_02:2]
Ex 99.1 (Q1'15 Earnings Release)

[0001327567-14-000040:8k_2_02:3]
Exhibit 99.1

[0001327567-14-000040:8k_2_02:4]
Palo Alto Networks Reports Fiscal First Quarter 2015 Financial Results

[0001327567-14-000040:8k_2_02:5]
| • | Fiscal first quarter total revenue grows 50 percent year-over-year to a record $192.3 million |

[0001327567-14-000040:8k_2_02:6]
| • | Billings grow 52 percent year-over-year to a record $240.5 million |

[0001327567-14-000040:8k_2_02:7]
| • | Product revenue grows 34 percent year-over-year to $101.5 million; recurring subscription revenue grows 76 percent year-over-year to $43.7 million |

[0001327567-14-000040:8k_2_02:8]
| • | Deferred revenue grows 69 percent year-over-year to a record $470.7 million |

[0001327567-14-000040:8k_2_02:9]
SANTA CLARA, Calif., November 24, 2014 - Palo Alto Networks, Inc. (NYSE: PANW) today announced financial results for its fiscal first quarter 2015 ended October 31, 2014.

[0001327567-14-000040:8k_2_02:10]
Total revenue for the fiscal first quarter grew 50 percent year-over-year to a record $192.3 million, compared with $128.2 million in the fiscal first quarter of 2014. GAAP net loss for the fiscal first quarter was $30.1 million, or $0.38 per diluted share, compared with a net loss of $7.9 million, or $0.11 per diluted share, in the fiscal first quarter of 2014.

[0001327567-14-000040:8k_2_02:11]
Palo Alto Networks recorded fiscal first quarter non-GAAP net income of $12.8 million, or $0.15 per diluted share, compared with non-GAAP net income of $6.2 million, or $0.08 per diluted share, in the fiscal first quarter of 2014. A reconciliation between GAAP and non-GAAP information is contained in the tables below.

[0001327567-14-000040:8k_2_02:12]
“We had a strong start to fiscal year 2015, outperforming expectations across all of our reported metrics. As the leading provider of the next-generation enterprise security platform, we delivered 52 percent billings growth and 50 percent revenue growth on a year-over-year basis,” said Mark McLaughlin, president and chief executive officer of Palo Alto Networks. “In today’s increasingly complex threat environment, enterprise customers recognize that a true, integrated and automated platform delivering prevention capabilities offers superior security with a superior total cost of ownership advantage. Our results demonstrate the differentiation and sustainability of that unique platform, the scalability of our go-to-market model and our ongoing growth potential.”

[0001327567-14-000040:8k_2_02:13]
“We are very pleased with our first quarter performance. Once again robust new customer acquisition and expansion within our existing customer base drove record billings, revenue and deferred revenue,” said Steffan Tomlinson, chief financial officer of Palo Alto Networks. “We delivered this top-line performance

[0001327567-14-000040:8k_2_02:14]
while continuing to grow our non-GAAP operating margin, both sequentially and year-over-year, and generating $74.9 million in cash flow from operations and $69.0 million in free cash flow.”

[0001327567-14-000040:8k_2_02:15]
Recent Highlights

[0001327567-14-000040:8k_2_02:16]
| • | Discovered WireLurker malware - Underscoring our thought leadership in cybersecurity, this finding by our Unit 42 threat intelligence team marks a new era in both Mac OS and iOS malware. |

[0001327567-14-000040:8k_2_02:17]
| • | Extended VMware partnership - Building on our strategic partnership with VMware, we announced our VM-Series support for VMware vCloud® Air™, enabling customers to apply the same rich next-generation security policies across their private and public virtualized infrastructure, whether an application is virtual, physical, on- or off-premise. |

[0001327567-14-000040:8k_2_02:18]
| • | Launched Advanced Endpoint Protection offering - Further extending our technology leadership, we announced availability of Traps, our revolutionary preventative approach to stop cyber threats on the endpoint, sparing IT security teams from cumbersome remediation, patching, and often futile recovery measures. |

[0001327567-14-000040:8k_2_02:19]
| • | Honored as a customer support leader - Recognizing our effective use of process and technology to achieve excellent customer satisfaction, we were given by the Technology Services Industry Association the STAR Award for innovation in the delivery of support services. |

[0001327567-14-000040:8k_2_02:20]
| • | Announced Stanley J. Meresman to the Board of Directors - He joined our audit committee and serves as an audit committee financial expert. Mr. Meresman brings a wealth of valuable experience cultivated during current and previous positions on a number of public and private companies' boards, such as LinkedIn and Zynga. |

[0001327567-14-000040:8k_2_02:21]
Financial Outlook

[0001327567-14-000040:8k_2_02:22]
Palo Alto Networks provides guidance based on current market conditions and expectations.

[0001327567-14-000040:8k_2_02:23]
For the fiscal second quarter of 2015, Palo Alto Networks expects:

[0001327567-14-000040:8k_2_02:24]
| • | Total revenue in the range of $200 to $204 million, representing year-over-year growth between 42 percent and 45 percent. |

[0001327567-14-000040:8k_2_02:25]
| • | Diluted non-GAAP earnings per share in the range of $0.16 to $0.17 using 85 to 87 million shares. |

[0001327567-14-000040:8k_2_02:26]
2

[0001327567-14-000040:8k_2_02:27]
Guidance for non-GAAP financial measures excludes share-based compensation, amortization of acquisition-related intangible assets, acquisition expenses, discrete tax benefits, non-cash interest expense related to the company’s convertible senior notes, and other non-recurring expenses.  The company has not reconciled diluted non-GAAP earnings per share guidance to net income (loss) per diluted share because the company does not provide guidance on net income (loss) or the various reconciling cash and non-cash items between GAAP net income (loss) and non-GAAP net income (loss).  As items that impact these measures are out of the company’s control and/or cannot be reasonably predicted, the company is unable to provide such guidance.  Accordingly, a reconciliation of the non-GAAP financial measure guidance to the corresponding GAAP measures is not available without unreasonable effort.

[0001327567-14-000040:8k_2_02:28]
Conference Call Information

[0001327567-14-000040:8k_2_02:29]
Palo Alto Networks will host a conference call for analysts and investors to discuss its fiscal first quarter 2015 results and outlook for its fiscal second quarter of 2015 today at 4:30 PM Eastern time / 1:30 PM Pacific time. Open to the public, investors may access the call by dialing 1-877-545-1409 or 1-719-325-4940 and entering the passcode 7873236. A live audio webcast of the conference call along with supplemental financial information will also be accessible from the “Investors” section of the company’s website at investors.paloaltonetworks.com. Following the webcast, an archived version will be available on the website for one year. A telephonic replay of the call will be available two hours after the call and will run for five business days and may be accessed by dialing 1-888-203-1112 or 719-457-0820 and entering the passcode 7873236.

[0001327567-14-000040:8k_2_02:30]
Forward-Looking Statements

[0001327567-14-000040:8k_2_02:31]
This press release contains forward-looking statements that involve risks and uncertainties, including statements regarding the company’s financial outlook for the fiscal second quarter of 2015, the company’s expectations regarding gross margins, seasonality, revenue growth, future investment in Traps, capital expenditures and non-GAAP operating margin, the company’s ability to accelerate growth in its market share, growth trends, demand for and adoption of the company’s products and services, expected availability and efficacy of new products, the company’s competitive position, and continued momentum in the company’s business. There are a significant number of factors that could cause actual results to differ materially from statements made in this press release, including: Palo Alto Networks’ limited operating history; risks associated with Palo Alto Networks’ rapid growth, particularly outside of the United States; Palo Alto Networks’ limited experience with new product introductions, including the introduction of the Advanced Endpoint Protection offering; risks associated with new product releases, including software bugs; the failure to timely develop and achieve market acceptance of new products as w

[0001327567-14-000040:8k_2_02:32]
ell as existing products and services; rapidly evolving technological developments in the market for network security products; and general market, political, economic and business conditions.

[0001327567-14-000040:8k_2_02:33]
Additional risks and uncertainties that could affect Palo Alto Networks’ financial results are included under the captions “Risk Factors” and “Management’s Discussion and Analysis of Financial Condition and Results of Operations,” in the company’s annual report on Form 10-K filed with the SEC on September 18, 2014, which is available on the company’s website at investors.paloaltonetworks.com and on the SEC’s website at www.sec.gov. Additional information will also be set forth in other filings that the company makes with the SEC from time to time. All forward-looking statements in this press release are based on information available to the company as of the date hereof, and Palo Alto Networks does not assume any obligation to update the forward-looking statements provided to reflect events that occur or circumstances that exist after the date on which they were made.

[0001327567-14-000040:8k_2_02:34]
Non-GAAP Financial Measures

[0001327567-14-000040:8k_2_02:35]
Palo Alto Networks has provided in this release financial information that has not been prepared in accordance with generally accepted accounting principles in the United States (GAAP). The company uses these non-GAAP financial measures internally in analyzing its financial results and believes that the use of these non-GAAP financial measures is useful to investors as an additional tool to evaluate ongoing operating results and trends and in comparing the company’s financial results with other companies in its industry, many of which present similar non-GAAP financial measures.

[0001327567-14-000040:8k_2_02:36]
Non-GAAP financial measures are not meant to be considered in isolation or as a substitute for comparable GAAP financial measures, and should be read only in conjunction with the company’s consolidated financial statements prepared in accordance with GAAP. A reconciliation of the company’s non-GAAP financial measures to their most directly comparable GAAP measures has been provided in the financial statement tables included in this press release, and investors are encouraged to review the reconciliation.

[0001327567-14-000040:8k_2_02:37]
Non-GAAP net income and diluted net income per share. Palo Alto Networks defines non-GAAP net income as net income (loss) plus share-based compensation expense and related payroll taxes, acquisition related costs, amortization expense of acquired intangible assets, litigation related charges including legal settlements, and non-cash interest expense related to the company’s convertible senior notes. Palo Alto Networks believes that excluding these items from non-GAAP net income and non-GAAP diluted net income per share provides management and investors with greater visibility into the underlying

[0001327567-14-000040:8k_2_02:38]
4

[0001327567-14-000040:8k_2_02:39]
performance of the company’s core business operating results, meaning its operating performance excluding these items and, from time to time, other discrete charges that are infrequent in nature, over multiple periods. The company also excludes from non-GAAP net income and non-GAAP diluted net income per share the tax effects, including income tax associated with these items in order to provide a complete picture of the company’s recurring core business operating results. Without excluding these tax effects, investors would only see the gross effect that excluding these expenses had on the company’s operating results.

[0001327567-14-000040:8k_2_02:40]
Billings. Palo Alto Networks defines billings as total revenue plus the change in deferred revenue during the period. The company’s management monitors billings because billings drive deferred revenue, which is an important indicator of the health and visibility of the company’s business. The company considers billings to be a useful metric for management and investors, particularly as sales of subscriptions increase and the company experiences strong renewal rates for subscriptions and support and maintenance.

[0001327567-14-000040:8k_2_02:41]
Free Cash Flow. Palo Alto Networks defines free cash flow as cash provided by operating activities less purchases of property, equipment, and other assets.  The company considers free cash flow to be a liquidity measure that provides useful information to management and investors about the amount of cash generated by the business that, after the purchases of property, equipment, and other assets, can be used for strategic opportunities, including investing in our business, making strategic acquisitions, and strengthening the balance sheet.

[0001327567-14-000040:8k_2_02:42]
Investors are cautioned that there are a number of limitations associated with the use of non-GAAP financial measures as an analytical tool. In particular, many of the adjustments to the company’s GAAP financial measures reflect the exclusion of items that are recurring and will be reflected in the company’s financial results for the foreseeable future, such as share-based compensation.  Share-based compensation is an important part of Palo Alto Networks employees’ compensation and impacts their performance.  In addition, the billings metric reported by the company includes amounts that have not yet been recognized as revenue.  The components that Palo Alto Networks excludes in its calculation of non-GAAP financial measures may differ from the components that its peer companies exclude when they report their non-GAAP results of operations. Palo Alto Networks compensates for these limitations by providing specific information regarding the GAAP amounts excluded from these non-GAAP financial measures. In the future, the company may also exclude non-recurring expenses and other expenses that do not reflect the company’s core business operating results.

[0001327567-14-000040:8k_2_02:43]
About Palo Alto Networks

[0001327567-14-000040:8k_2_02:44]
Palo Alto Networks is leading a new era in cybersecurity by protecting thousands of enterprise, government, and service provider networks from cyber threats.  Unlike fragmented legacy products, our security platform safely enables business operations and delivers protection based on what matters most in today's dynamic computing environments: applications, users, and content.  Find out more at www.paloaltonetworks.com.

[0001327567-14-000040:8k_2_02:45]
Palo Alto Networks and the Palo Alto Networks Logo are trademarks of Palo Alto Networks, Inc. in the United States and in jurisdictions throughout the world. All other trademarks, trade names or service marks used or mentioned herein belong to their respective owners.

[0001327567-14-000040:8k_2_02:46]
Media Contact:

[0001327567-14-000040:8k_2_02:47]
Jennifer Jasper Smith

[0001327567-14-000040:8k_2_02:48]
Head of Corporate Communications

[0001327567-14-000040:8k_2_02:49]
Palo Alto Networks

[0001327567-14-000040:8k_2_02:50]
408-638-3280

[0001327567-14-000040:8k_2_02:51]
jjsmith@paloaltonetworks.com

[0001327567-14-000040:8k_2_02:52]
Investor Relations Contact:

[0001327567-14-000040:8k_2_02:53]
Kelsey Turcotte

[0001327567-14-000040:8k_2_02:54]
Vice President of Investor Relations

[0001327567-14-000040:8k_2_02:55]
408-753-3872

[0001327567-14-000040:8k_2_02:56]
kturcotte@paloaltonetworks.com

[0001327567-14-000040:8k_2_02:57]
Chris Danne/Maria Riley

[0001327567-14-000040:8k_2_02:58]
The Blueshirt Group

[0001327567-14-000040:8k_2_02:59]
415-217-7722

[0001327567-14-000040:8k_2_02:60]
ir@paloaltonetworks.com

[0001327567-14-000040:8k_2_02:61]
| Palo Alto Networks, Inc. |
| Preliminary Condensed Consolidated Statements of Operations |
| (In thousands, except per share data) |
| (Unaudited) |
|  | Three Months Ended October 31, |
|  | 2014 |  | 2013 |
| Revenue: |  |  |  |
| Product | $ | 101,476 |  |  | $ | 75,485 |  |
| Services | 90,870 |  |  | 52,695 |  |
| Total revenue | 192,346 |  |  | 128,180 |  |
| Cost of revenue: |  |  |  |
| Product | 29,141 |  |  | 17,954 |  |
| Services | 24,320 |  |  | 15,853 |  |
| Total cost of revenue | 53,461 |  |  | 33,807 |  |
| Total gross profit | 138,885 |  |  | 94,373 |  |
| Operating expenses: |  |  |  |
| Research and development | 37,305 |  |  | 19,893 |  |
| Sales and marketing | 106,366 |  |  | 67,366 |  |
| General and administrative | 18,977 |  |  | 14,125 |  |
| Total operating expenses | 162,648 |  |  | 101,384 |  |
| Operating loss | (23,763 | ) |  | (7,011 | ) |
| Interest expense | (5,489 | ) |  | (8 | ) |
| Other income, net | 341 |  |  | 405 |  |
| Loss before income taxes | (28,911 | ) |  | (6,614 | ) |
| Provision for income taxes | 1,157 |  |  | 1,247 |  |
| Net loss | $ | (30,068 | ) |  | $ | (7,861 | ) |
| Net loss per share, basic and diluted | $ | (0.38 | ) |  | $ | (0.11 | ) |
| Weighted-average shares used to compute net loss per share, basic and diluted | 79,388 |  |  | 71,681 |  |

[0001327567-14-000040:8k_2_02:62]
7

[0001327567-14-000040:8k_2_02:63]
| Palo Alto Networks, Inc. |
| Reconciliation of GAAP to Non-GAAP Financial Measures |
| (In thousands, except per share amounts) |
| (Unaudited) |
|  | Three Months Ended October 31, |
|  | 2014 |  | 2013 |
| GAAP net loss | $ | (30,068 | ) |  | $ | (7,861 | ) |
| Share-based compensation expense | 38,475 |  |  | 14,411 |  |
| Share-based payroll tax expense | 1,054 |  |  | 265 |  |
| Amortization expense of acquired intangible assets | 1,544 |  |  | — |  |
| Litigation related charges [a] | 3,065 |  |  | 1,889 |  |
| Non-cash interest expense related to convertible notes | 5,478 |  |  | — |  |
| Income tax and other tax adjustments related to the above | (6,711 | ) |  | (2,534 | ) |
| Non-GAAP net income | $ | 12,837 |  |  | $ | 6,170 |  |
| GAAP net loss per share, diluted | $ | (0.38 | ) |  | $ | (0.11 | ) |
| Share-based compensation expense | 0.47 |  |  | 0.20 |  |
| Share-based payroll tax expense | 0.01 |  |  | 0.00 |  |
| Amortization expense of acquired intangible assets | 0.02 |  |  | 0.00 |  |
| Litigation related charges [a] | 0.04 |  |  | 0.03 |  |
| Non-cash interest expense related to convertible notes | 0.07 |  |  | 0.00 |  |
| Income tax and other tax adjustments related to the above | (0.08 | ) |  | (0.04 | ) |
| Non-GAAP net income per share, diluted | $ | 0.15 |  |  | $ | 0.08 |  |
| GAAP weighted-average shares used to compute net loss per share, diluted | 79,388 |  |  | 71,681 |  |
| Weighted-average effect of potentially dilutive securities [b] | 5,341 |  |  | 5,518 |  |
| Non-GAAP weighted-average shares used to compute net income per share, diluted | 84,729 |  |  | 77,199 |  |
| Revenue | $ | 192,346 |  |  | $ | 128,180 |  |
| Change in deferred revenue | 48,142 |  |  | 29,726 |  |
| Billings | $ | 240,488 |  |  | $ | 157,906 |  |
| Net cash provided by operating activities | $ | 74,928 |  |  | $ | 38,881 |  |
| Less: purchases of property, equipment, and other assets | 5,935 |  |  | 15,680 |  |
| Free cash flow | $ | 68,993 |  |  | $ | 23,201 |  |
| Net cash used in investing activities | $ | (201,093 | ) |  | $ | (93,959 | ) |
| Net cash provided by financing activities | $ | 16,100 |  |  | $ | 10,646 |  |

[0001327567-14-000040:8k_2_02:64]
___________

[0001327567-14-000040:8k_2_02:65]
[a]    Litigation related charges during the three months ended October 31, 2014 and 2013 includes the amortization of intellectual property licenses entered into as part of the settlement with Juniper and expenses for legal services, respectively.

[0001327567-14-000040:8k_2_02:66]
[b]    Non-GAAP net income per share, diluted, includes the potentially dilutive effect of our options and restricted stock units outstanding. The potentially dilutive effect of the convertible notes for the three months ended October 31, 2014 and 2013 was nil.

[0001327567-14-000040:8k_2_02:67]
8

[0001327567-14-000040:8k_2_02:68]
| Palo Alto Networks, Inc. |
| Preliminary Condensed Consolidated Balance Sheets |
| (In thousands) |
| (Unaudited) |
|  | October 31, 2014 |  | July 31, 2014 |
| Assets |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 543,747 |  |  | $ | 653,812 |  |
| Short-term investments | 227,752 |  |  | 118,690 |  |
| Accounts receivable, net | 116,224 |  |  | 135,518 |  |
| Prepaid expenses and other current assets | 45,844 |  |  | 50,306 |  |
| Total current assets | 933,567 |  |  | 958,326 |  |
| Property and equipment, net | 49,823 |  |  | 48,744 |  |
| Long-term investments | 289,011 |  |  | 201,880 |  |
| Goodwill | 155,033 |  |  | 155,033 |  |
| Intangible assets, net | 47,451 |  |  | 47,955 |  |
| Other assets | 65,471 |  |  | 66,528 |  |
| Total assets | $ | 1,540,356 |  |  | $ | 1,478,466 |  |
| Liabilities and stockholders’ equity |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 10,497 |  |  | $ | 14,526 |  |
| Accrued compensation | 35,935 |  |  | 48,727 |  |
| Accrued and other liabilities | 27,852 |  |  | 25,000 |  |
| Deferred revenue | 286,682 |  |  | 259,918 |  |
| Total current liabilities | 360,966 |  |  | 348,171 |  |
| Convertible senior notes, net | 471,856 |  |  | 466,875 |  |
| Long-term deferred revenue | 184,038 |  |  | 162,660 |  |
| Other long-term liabilities | 30,285 |  |  | 32,177 |  |
| Stockholders’ equity: |  |  |  |
| Preferred stock | — |  |  | — |  |
| Common stock | 8 |  |  | 8 |  |
| Additional paid-in capital | 859,010 |  |  | 804,406 |  |
| Accumulated other comprehensive loss | (13 | ) |  | (105 | ) |
| Accumulated deficit | (365,794 | ) |  | (335,726 | ) |
| Total stockholders’ equity | 493,211 |  |  | 468,583 |  |
| Total liabilities and stockholders’ equity | $ | 1,540,356 |  |  | $ | 1,478,466 |  |

[0001327567-14-000040:8k_2_02:69]
9

[0001327567-14-000040:8k_2_02:70]
| Palo Alto Networks, Inc. |
| Preliminary Condensed Consolidated Statements of Cash Flows |
| (In thousands) |
| (Unaudited) |
|  | Three Months Ended October 31, |
|  | 2014 |  | 2013 |
| Cash flows from operating activities |  |  |  |
| Net loss | $ | (30,068 | ) |  | $ | (7,861 | ) |
| Adjustments to reconcile net loss to net cash provided by operating activities: |  |  |  |
| Share-based compensation for equity based awards | 38,443 |  |  | 14,383 |  |
| Depreciation and amortization | 6,115 |  |  | 3,146 |  |
| Amortization of investment premiums, net of accretion of purchase discounts | 667 |  |  | 386 |  |
| Amortization of debt discount and debt issuance costs | 5,478 |  |  | — |  |
| Excess tax benefit from share-based compensation | (346 | ) |  | (56 | ) |
| Changes in operating assets and liabilities: |  |  |  |
| Accounts receivable, net | 19,294 |  |  | (3,978 | ) |
| Prepaid expenses and other assets | 3,409 |  |  | (1,707 | ) |
| Accounts payable | (4,460 | ) |  | (205 | ) |
| Accrued compensation | (12,792 | ) |  | 1,614 |  |
| Accrued and other liabilities | 1,046 |  |  | 3,433 |  |
| Deferred revenue | 48,142 |  |  | 29,726 |  |
| Net cash provided by operating activities | 74,928 |  |  | 38,881 |  |
| Cash flows from investing activities |  |  |  |
| Purchase of investments | (247,849 | ) |  | (122,238 | ) |
| Proceeds from sales of investments | 1,999 |  |  | — |  |
| Proceeds from maturities of investments | 50,692 |  |  | 43,959 |  |
| Purchase of property, equipment, and other assets | (5,935 | ) |  | (15,680 | ) |
| Net cash used in investing activities | (201,093 | ) |  | (93,959 | ) |
| Cash flows from financing activities |  |  |  |
| Proceeds from exercise of stock options | 7,963 |  |  | 4,610 |  |
| Proceeds from employee stock purchase plan | 7,791 |  |  | 5,988 |  |
| Excess tax benefit from share-based compensation | 346 |  |  | 56 |  |
| Repurchase of restricted common stock from terminated employees | — |  |  | (8 | ) |
| Net cash provided by financing activities | 16,100 |  |  | 10,646 |  |
| Net decrease in cash and cash equivalents | (110,065 | ) |  | (44,432 | ) |
| Cash and cash equivalents - beginning of period | 653,812 |  |  | 310,614 |  |
| Cash and cash equivalents - end of period | $ | 543,747 |  |  | $ | 266,182 |  |

[0001327567-14-000040:8k_2_02:71]
10
