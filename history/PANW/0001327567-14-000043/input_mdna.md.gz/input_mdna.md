# PANW MD&A — 0001327567-14-000043


## mdna

[0001327567-14-000043:mdna:1]
| ITEM 2. | MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS |

[0001327567-14-000043:mdna:2]
[same as prior period, unchanged from 0001327567-14-000013:mdna:2]

[0001327567-14-000043:mdna:3]
| • | Overview. A discussion of our business and overall analysis of financial and other highlights in order to provide context for the remainder of MD&A. |

[0001327567-14-000043:mdna:4]
| • | Key Financial Metrics. An analysis of our generally accepted accounting principles (GAAP) and non-GAAP key financial metrics, which management monitors to evaluate our performance. |

[0001327567-14-000043:mdna:5]
| • | Financial Overview. A discussion of the nature and trends of components of our financial results. |

[0001327567-14-000043:mdna:6]
| • | Results of Operations. An analysis of our financial results comparing the three months ended October 31, 2014 to the three months ended October 31, 2013. |

[0001327567-14-000043:mdna:7]
[same as prior period, unchanged from 0001327567-14-000013:mdna:7]

[0001327567-14-000043:mdna:8]
[same as prior period, unchanged from 0001327567-14-000013:mdna:8]

[0001327567-14-000043:mdna:9]
[same as prior period, unchanged from 0001327567-14-000013:mdna:9]

[0001327567-14-000043:mdna:10]
[same as prior period, unchanged from 0001327567-14-000013:mdna:10]

[0001327567-14-000043:mdna:11]
[same as prior period, unchanged from 0001327567-14-000013:mdna:11]

[0001327567-14-000043:mdna:12]
We have pioneered the next-generation of enterprise security with our innovative platform that allows enterprises, service providers, and government entities to simultaneously empower and secure their organizations by safely enabling the increasingly complex and rapidly growing number of applications running on their networks and by preventing breaches stemming from targeted cyber attacks. Our enterprise security platform consists of three major elements: our Next-Generation Firewall, our Advanced Endpoint Protection, and our Threat Intelligence Cloud. Our Next-Generation Firewall delivers application, user, and content visibility and control as well as protection against network-based cyber threats integrated within the firewall through our proprietary hardware and software architecture. Our Advanced Endpoint Protection prevents cyber attacks that aim to exploit software vulnerabilities on a broad variety of fixed and virtual endpoints. Our Threat Intelligence Cloud provides central intelligence capabilities as well as automated delivery of preventative measures against cyber attacks. The cloud-based element of our platform is delivered in the form of a service that can be used either in the public cloud or in a private cloud using a dedicated appliance.

[0001327567-14-000043:mdna:13]
We derive revenue from sales of our products and services, which together comprise our platform. Product revenue is generated from sales of our Next-Generation Firewall, which is available in hardware and virtualized form factors. Our Next-Generation Firewall incorporates our proprietary PAN-OS operating system, which provides a consistent set of capabilities across our entire product line. These capabilities include: application visibility and control (App-ID), user identification (User-ID), site-

[0001327567-14-000043:mdna:14]
- 16 -

[0001327567-14-000043:mdna:15]
to-site virtual private network (VPN), remote access Secure Sockets Layer (SSL) VPN, and Quality-of-Service (QoS). Our products are designed for different performance requirements throughout an organization, ranging from the PA-200, which is designed for enterprise remote offices, to the PA-7050, which is designed for data centers and high-speed networks. The same firewall functionality that is delivered in the hardware appliances is also available in the VM-Series virtual firewalls, which secure virtualized and cloud-based computing environments. Multiple firewalls can jointly use our WildFire appliance, WF-500, which identifies, analyzes, and blocks known and unknown malware in a private cloud-based environment. Our platform can be centrally managed in both virtualized and hardware appliances across an organization with our Panorama product. In addition, our GlobalProtect appliance, GP-100, provides mobile device management, malware detection, and shares device state information to safely enable mobile devices for business use.

[0001327567-14-000043:mdna:16]
Services revenue is generated from sales of subscriptions and support and maintenance. Our Threat Prevention, URL Filtering, GlobalProtect, and WildFire subscriptions provide our end-customers with real-time access to the latest antivirus, intrusion prevention, web filtering, and modern malware prevention capabilities across fixed and mobile devices. Our Advanced Endpoint Protection subscription protects against cyber attacks that exploit software vulnerabilities in Windows-based fixed and virtual endpoints through the use of its unique capability of stopping the underlying exploit techniques, and can prevent cyber attacks without relying on prior knowledge of the attack.

[0001327567-14-000043:mdna:17]
When end-customers purchase an appliance, they typically purchase one or more of our subscriptions for additional functionality, as well as support and maintenance in order to receive ongoing security updates, upgrades, bug fixes, and repairs. We leverage our appliances to sell software as a service (SaaS) subscription services to meet our customers’ evolving enterprise security requirements. Our hybrid SaaS revenue model consists of product, subscriptions, and support and maintenance, which we believe will enable us to benefit from recurring revenues as we continue to grow our installed end-customer base.

[0001327567-14-000043:mdna:18]
[same as prior period, unchanged from 0001327567-14-000013:mdna:17]

[0001327567-14-000043:mdna:19]
We continue to invest in innovation and strengthening our product portfolio. For example, in September 2014, we announced the availability of Traps, our Advanced Endpoint Protection offering, designed to prevent sophisticated cyber attacks on endpoints. In addition, in October 2014, we expanded our partnership with VMware, Inc. (“VMware”) by extending our advanced security to VMware’s public cloud platform, vCloud Air.

[0001327567-14-000043:mdna:20]
As of October 31, 2014, we had sold to approximately 21,000 end-customers in over 130 countries. Our end-customers represent a broad range of industries including education, energy, financial services, government entities, healthcare, Internet and media, manufacturing, public sector, and telecommunications, and include some of the largest Fortune 100 and Global 2000 companies in the world. Also, during the first quarter of fiscal 2015, our headcount increased by 178 to 1,900 employees.

[0001327567-14-000043:mdna:21]
For the first quarter of fiscal 2015 and 2014, revenues were $192.3 million and $128.2 million, respectively, representing year-over-year growth of 50.1%. All three components of our hybrid SaaS revenue model experienced year-over-year growth, led by revenue from subscription services, which grew 76.2% to $43.7 million, followed by support and maintenance services, which grew 69.1% to $47.2 million, and product, which grew 34.4% to $101.5 million. Revenue growth reflected rapid adoption of our Next-Generation Firewall and related support and maintenance, as well as increasing momentum in our subscription services business. We believe the growth was also driven by increased security spending by customers, as security continues to be a critical business imperative for every business in the world.

[0001327567-14-000043:mdna:22]
[same as prior period, unchanged from 0001327567-14-000013:mdna:26]

[0001327567-14-000043:mdna:23]
[same as prior period, unchanged from 0001327567-14-000013:mdna:27]

[0001327567-14-000043:mdna:24]
- 17 -

[0001327567-14-000043:mdna:25]
[same as prior period, unchanged from 0001327567-14-000013:mdna:28]

[0001327567-14-000043:mdna:26]
[same as prior period, unchanged from 0001327567-14-000013:mdna:29]

[0001327567-14-000043:mdna:27]
|  | October 31, 2014 |  | July 31, 2014 |
|  | (in thousands) |
| Total deferred revenue | $ | 470,720 |  |  | $ | 422,578 |  |
| Cash, cash equivalents, and investments | $ | 1,060,510 |  |  | $ | 974,382 |  |

[0001327567-14-000043:mdna:28]
|  | Three Months Ended October 31, |
|  | 2014 |  | 2013 |
|  | (dollars in thousands) |
| Total revenue | $ | 192,346 |  |  | $ | 128,180 |  |
| Year over year percentage increase | 50.1 | % |  | 49.2 | % |
| Gross margin percentage | 72.2 | % |  | 73.6 | % |
| Operating loss | $ | (23,763 | ) |  | $ | (7,011 | ) |
| Operating margin percentage | (12.4 | )% |  | (5.5 | )% |
| Billings (non-GAAP) | $ | 240,488 |  |  | $ | 157,906 |  |
| Cash flow provided by operating activities | $ | 74,928 |  |  | $ | 38,881 |  |
| Free cash flow (non-GAAP) | $ | 68,993 |  |  | $ | 23,201 |  |

[0001327567-14-000043:mdna:29]
| • | Deferred Revenue. Our deferred revenue consists of amounts that have been invoiced, but that have not yet been recognized as revenue as of the period end. The majority of our deferred revenue balance consists of subscription and support and maintenance revenue that is recognized ratably over the contractual service period. We monitor our deferred revenue balance because it represents a significant portion of revenue to be recognized in future periods. |

[0001327567-14-000043:mdna:30]
[same as prior period, unchanged from 0001327567-14-000013:mdna:39]

[0001327567-14-000043:mdna:31]
| • | Free Cash Flow (non-GAAP). We define free cash flow, a non-GAAP financial measure, as cash provided by operating activities less purchases of property, equipment, and other assets. We consider free cash flow to be a liquidity measure that provides useful information to management and investors about the amount of cash generated by the business that, after the purchases of property, equipment, and other assets, can be used for strategic opportunities, including investing in our business, making strategic acquisitions, and strengthening the balance sheet. A limitation of the utility of free cash flow as a measure of our financial performance and liquidity is that it does not represent the total increase or decrease in our cash balance for the period. In addition, it is important to note that other companies, including companies in our industry, may not use free cash flow, may calculate free cash flow in a different manner than we do, or may use other financial measures to evaluate their performance, all of which could reduce the usefulness of free cash flow as a comparative measure. A reconciliation of free cash flow to cash flow provided by operating activities, the most directly comparable financial measure calculated and presented in accordance with GAAP, is provided below: |

[0001327567-14-000043:mdna:32]
[same as prior period, unchanged from 0001327567-14-000013:mdna:14]

[0001327567-14-000043:mdna:33]
|  | Three Months Ended October 31, |
|  | 2014 |  | 2013 |
|  | (in thousands) |
| Free cash flow (non-GAAP): |  |  |  |
| Cash flow provided by operating activities | $ | 74,928 |  |  | $ | 38,881 |  |
| Less: purchase of property, equipment, and other assets | 5,935 |  |  | 15,680 |  |
| Free cash flow (non-GAAP) | $ | 68,993 |  |  | $ | 23,201 |  |
| Net cash used in investing activities | $ | (201,093 | ) |  | $ | (93,959 | ) |
| Net cash provided by financing activities | $ | 16,100 |  |  | $ | 10,646 |  |

[0001327567-14-000043:mdna:34]
| • | Billings (non-GAAP). We define billings, a non-GAAP financial measure, as total revenue plus the change in deferred revenue during the period. Billings is a key measure used by our management to manage our business because billings drive deferred revenue, which is an important indicator of the health and visibility of our business. We consider billings to be a useful metric for management and investors, particularly as we experience increased sales of subscriptions and strong renewal rates for subscriptions and support and maintenance services, and monitor our near term cash flows. We believe that billings provides useful information to investors and others in understanding and evaluating our operating results in the same manner as our management. However, it is important to note that other companies, including companies in our industry, may not use billings, may calculate billings differently, may have different billing frequencies, or may use other financial measures to evaluate their performance, all of which could reduce the usefulness of billings as a comparative measure. A reconciliation of billings to revenue, the most directly comparable financial measure calculated and presented in accordance with GAAP, is provided below: |

[0001327567-14-000043:mdna:35]
|  | Three Months Ended October 31, |
|  | 2014 |  | 2013 |
|  | (in thousands) |
| Billings (non-GAAP): |  |  |  |
| Total revenue | $ | 192,346 |  |  | $ | 128,180 |  |
| Add: change in total deferred revenue | 48,142 |  |  | 29,726 |  |
| Billings (non-GAAP) | $ | 240,488 |  |  | $ | 157,906 |  |

[0001327567-14-000043:mdna:36]
[same as prior period, unchanged from 0001327567-14-000013:mdna:45]

[0001327567-14-000043:mdna:37]
[same as prior period, unchanged from 0001327567-14-000013:mdna:46]

[0001327567-14-000043:mdna:38]
[same as prior period, unchanged from 0001327567-14-000013:mdna:47]

[0001327567-14-000043:mdna:39]
[same as prior period, unchanged from 0001327567-14-000013:mdna:48]

[0001327567-14-000043:mdna:40]
| • | Product Revenue. The substantial majority of our product revenue is derived from sales of our appliances. Product revenue also includes revenue derived from software licenses of Panorama, GlobalProtect, and the VM-Series. We recognize product revenue at the time of shipment, provided that all other revenue recognition criteria have been met. As a percentage of total revenue, we expect our product revenue to vary from quarter to quarter based on seasonal and cyclical factors. |

[0001327567-14-000043:mdna:41]
| • | Services Revenue. Services revenue is derived primarily from Threat Prevention, URL Filtering, GlobalProtect, and WildFire subscriptions and support and maintenance. In addition, in September 2014, we released Traps, our Advanced Endpoint Protection subscription. We anticipate billings (non-GAAP) from Traps will begin ramping in the second half of fiscal 2015 with a more meaningful revenue contribution in fiscal 2016. Our contractual subscription and support and maintenance terms are typically one year, with three to five year terms available. We recognize revenue from subscriptions and support and maintenance over the contractual service period. As a percentage of total revenue, we expect our services revenue to vary from quarter to quarter and increase over the long term as we introduce new subscriptions, renew existing services contracts, and expand our installed end-customer base. |

[0001327567-14-000043:mdna:42]
[same as prior period, unchanged from 0001327567-14-000013:mdna:24]

[0001327567-14-000043:mdna:43]
[same as prior period, unchanged from 0001327567-14-000013:mdna:51]

[0001327567-14-000043:mdna:44]
Our total cost of revenue consists of cost of product revenue and cost of services revenue. Our cost of revenue includes costs paid to our third-party contract manufacturer and personnel costs, which consist of salaries, bonuses, and share-based compensation associated with our operations and global customer support organizations. Our cost of revenue also includes allocated costs, which consist of certain facilities, depreciation, benefits, recruiting, and information technology costs that we allocate based on headcount, and amortization of intangible assets.

[0001327567-14-000043:mdna:45]
| • | Cost of Product Revenue. Cost of product revenue primarily includes costs paid to our third-party contract manufacturer. Our cost of product revenue also includes amortization of intellectual property licenses, product testing costs, allocated costs, warranty costs, shipping costs, and personnel costs associated with logistics and quality control. We expect our cost of product revenue to increase as our product revenue increases. |

[0001327567-14-000043:mdna:46]
| • | Cost of Services Revenue. Cost of services revenue includes personnel costs for our global customer support organization, amortization of intangible assets acquired, allocated costs, and URL filtering database service fees. We expect our cost of services revenue to increase as our installed end-customer base grows. |

[0001327567-14-000043:mdna:47]
[same as prior period, unchanged from 0001327567-14-000013:mdna:55]

[0001327567-14-000043:mdna:48]
[same as prior period, unchanged from 0001327567-14-000013:mdna:56]

[0001327567-14-000043:mdna:49]
[same as prior period, unchanged from 0001327567-14-000013:mdna:57]

[0001327567-14-000043:mdna:50]
Our operating expenses consist of research and development, sales and marketing, and general and administrative expense. Personnel costs are the most significant component of operating expenses and consist of salaries, benefits, bonuses, share-based compensation, and with regard to sales and marketing expense, sales commissions. We expect operating expenses to increase in absolute dollars, and decrease over the long term as a percentage of revenue as we continue to scale our business. As of October 31, 2014, we expect to recognize approximately $327.2 million of share-based compensation expense over a weighted-average period of three years, excluding additional share-based compensation expense related to any future grants of share-based awards. Share-based compensation expense, net of forfeitures, is recognized on a straight-line basis over the requisite service periods of the awards.

[0001327567-14-000043:mdna:51]
| • | Research and Development. Research and development expense consists primarily of personnel costs. Research and development expense also includes prototype related expenses and allocated costs. We expect research and development expense to increase in absolute dollars as we continue to invest in our future products and services, although our research and development expense may fluctuate as a percentage of total revenue. |

[0001327567-14-000043:mdna:52]
| • | Sales and Marketing. Sales and marketing expense consists primarily of personnel costs, including commission costs. We expense commission costs as incurred. Sales and marketing expense also includes costs for market development programs, promotional and other marketing costs, travel costs, professional services, and allocated costs. We continue to increase the size of our sales force and have also substantially grown our sales presence internationally. We expect sales and marketing expense to continue to increase in absolute dollars as we increase the size of our sales and marketing organizations to increase touch points with end-customers and to expand our international presence, although our sales and marketing expense may fluctuate as a percentage of total revenue. |

[0001327567-14-000043:mdna:53]
| • | General and Administrative. General and administrative expense consists of personnel costs, professional services, and certain non-recurring general expenses. General and administrative personnel include our executive, finance, human resources, legal, and IT organizations. Professional services consist primarily of legal, auditing, accounting, and other consulting costs. We expect general and administrative expense to increase in absolute dollars due to additional costs associated with accounting, compliance, insurance, and investor relations, although our general and administrative expense may fluctuate as a percentage of total revenue. |

[0001327567-14-000043:mdna:54]
[same as prior period, unchanged from 0001327567-14-000013:mdna:37]

[0001327567-14-000043:mdna:55]
Interest Expense

[0001327567-14-000043:mdna:56]
Interest expense consists of the amortization of the debt discount and debt issuance costs related to our 0.0% convertible senior notes due 2019 (the “Notes”). This interest expense is non-cash and will range from $22.3 million to $25.7 million per year through fiscal 2019.

[0001327567-14-000043:mdna:57]
[same as prior period, unchanged from 0001327567-14-000013:mdna:67]

[0001327567-14-000043:mdna:58]
Other income (expense), net includes interest income earned on our cash, cash equivalents, and investments, foreign currency re-measurement gains and losses, and foreign currency transaction gains and losses.

[0001327567-14-000043:mdna:59]
[same as prior period, unchanged from 0001327567-14-000013:mdna:69]

[0001327567-14-000043:mdna:60]
Provision for income taxes consists primarily of income taxes in foreign jurisdictions in which we conduct business, withholding taxes, and federal and state income taxes in the United States. We maintain a full valuation allowance for domestic deferred tax assets, including net operating loss carryforwards and tax credits. We implemented our corporate structure and intercompany relationships to more closely align with the international nature of our business in the fourth quarter of fiscal 2013. Income in certain countries may be taxed at statutory tax rates that are lower than the U.S. statutory tax rate. As a result, our overall effective tax rate over the long term may be lower than the U.S. federal statutory tax rate on positive income through changes in international procurement and sales operations.

[0001327567-14-000043:mdna:61]
[same as prior period, unchanged from 0001327567-14-000013:mdna:71]

[0001327567-14-000043:mdna:62]
[same as prior period, unchanged from 0001327567-14-000013:mdna:72]

[0001327567-14-000043:mdna:63]
|  | Three Months Ended October 31, |
|  | 2014 |  | 2013 |
|  | (dollars in thousands) |
| Condensed Consolidated Statements of Operations Data: |  |  |  |
| Revenue: |  |  |  |
| Product | $ | 101,476 |  |  | $ | 75,485 |  |
| Services | 90,870 |  |  | 52,695 |  |
| Total revenue | 192,346 |  |  | 128,180 |  |
| Cost of revenue: |  |  |  |
| Product | 29,141 |  |  | 17,954 |  |
| Services | 24,320 |  |  | 15,853 |  |
| Total cost of revenue | 53,461 |  |  | 33,807 |  |
| Total gross profit | 138,885 |  |  | 94,373 |  |
| Operating expenses: |  |  |  |
| Research and development | 37,305 |  |  | 19,893 |  |
| Sales and marketing | 106,366 |  |  | 67,366 |  |
| General and administrative | 18,977 |  |  | 14,125 |  |
| Total operating expenses | 162,648 |  |  | 101,384 |  |
| Operating loss | (23,763 | ) |  | (7,011 | ) |
| Interest expense | (5,489 | ) |  | (8 | ) |
| Other income, net | 341 |  |  | 405 |  |
| Loss before income taxes | (28,911 | ) |  | (6,614 | ) |
| Provision for income taxes | 1,157 |  |  | 1,247 |  |
| Net loss | $ | (30,068 | ) |  | $ | (7,861 | ) |
| Number of employees at period end | 1,900 |  |  | 1,264 |  |

[0001327567-14-000043:mdna:64]
[same as prior period, unchanged from 0001327567-14-000013:mdna:44]

[0001327567-14-000043:mdna:65]
|  | Three Months Ended October 31, |
|  | 2014 |  | 2013 |
|  | (as a percentage of revenue) |
| Condensed Consolidated Statements of Operations Data: |  |  |  |
| Revenue: |  |  |  |
| Product | 52.8 | % |  | 58.9 | % |
| Services | 47.2 | % |  | 41.1 | % |
| Total revenue | 100.0 | % |  | 100.0 | % |
| Cost of revenue: |  |  |  |
| Product | 15.2 | % |  | 14.0 | % |
| Services | 12.6 | % |  | 12.4 | % |
| Total cost of revenue | 27.8 | % |  | 26.4 | % |
| Total gross profit | 72.2 | % |  | 73.6 | % |
| Operating expenses: |  |  |  |
| Research and development | 19.4 | % |  | 15.5 | % |
| Sales and marketing | 55.3 | % |  | 52.6 | % |
| General and administrative | 9.9 | % |  | 11.0 | % |
| Total operating expenses | 84.6 | % |  | 79.1 | % |
| Operating loss | (12.4 | )% |  | (5.5 | )% |
| Interest expense | (2.9 | )% |  | — | % |
| Other income, net | 0.2 | % |  | 0.3 | % |
| Loss before income taxes | (15.1 | )% |  | (5.2 | )% |
| Provision for income taxes | 0.5 | % |  | 1.0 | % |
| Net loss | (15.6 | )% |  | (6.2 | )% |

[0001327567-14-000043:mdna:66]
Comparison of the Three Month Periods Ended October 31, 2014 and 2013

[0001327567-14-000043:mdna:67]
[same as prior period, unchanged from 0001327567-14-000013:mdna:79]

[0001327567-14-000043:mdna:68]
|  | Three Months Ended October 31, |  |  |  |  |
|  | 2014 |  | 2013 |  | Change |
|  | Amount |  | % of Revenue |  | Amount |  | % of Revenue |  | Amount |  | % |
|  | (dollars in thousands) |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 101,476 |  |  | 52.8 | % |  | $ | 75,485 |  |  | 58.9 | % |  | $ | 25,991 |  |  | 34.4 | % |
| Services |  |  |  |  |  |  |  |  |  |  |  |
| Subscription | 43,698 |  |  | 22.7 | % |  | 24,796 |  |  | 19.3 | % |  | 18,902 |  |  | 76.2 | % |
| Support and maintenance | 47,172 |  |  | 24.5 | % |  | 27,899 |  |  | 21.8 | % |  | 19,273 |  |  | 69.1 | % |
| Total services | 90,870 |  |  | 47.2 | % |  | 52,695 |  |  | 41.1 | % |  | 38,175 |  |  | 72.4 | % |
| Total revenue | $ | 192,346 |  |  | 100.0 | % |  | $ | 128,180 |  |  | 100.0 | % |  | $ | 64,166 |  |  | 50.1 | % |
| Revenue by geographic theater: |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 131,855 |  |  | 68.6 | % |  | $ | 86,166 |  |  | 67.2 | % |  | $ | 45,689 |  |  | 53.0 | % |
| EMEA | 38,484 |  |  | 20.0 | % |  | 23,875 |  |  | 18.6 | % |  | 14,609 |  |  | 61.2 | % |
| APAC | 22,007 |  |  | 11.4 | % |  | 18,139 |  |  | 14.2 | % |  | 3,868 |  |  | 21.3 | % |
| Total revenue | $ | 192,346 |  |  | 100.0 | % |  | $ | 128,180 |  |  | 100.0 | % |  | $ | 64,166 |  |  | 50.1 | % |

[0001327567-14-000043:mdna:69]
[same as prior period, unchanged from 0001327567-14-000013:mdna:60]

[0001327567-14-000043:mdna:70]
Product revenue increased $26.0 million, or 34.4%, for the three months ended October 31, 2014 compared to the three months ended October 31, 2013. The increase was driven by increased demand, including broader adoption of our newly introduced PA-7050 firewall. The impact of changes in pricing on our product revenue was insignificant.

[0001327567-14-000043:mdna:71]
Services revenue increased $38.2 million, or 72.4%, for the three months ended October 31, 2014 compared to the three months ended October 31, 2013. The increase was driven by a 76.2% increase in our subscription revenue and a 69.1% increase in our support and maintenance revenue due to increased sales to new and existing end-customers. The relative increases in subscription and support and maintenance revenue will fluctuate over time, depending on the mix of services revenue and the introduction of new subscription offerings. The impact of changes in pricing on our services revenue was insignificant.

[0001327567-14-000043:mdna:72]
With respect to geographic theaters, the Americas contributed the largest portion of the increase in revenue for the three months ended October 31, 2014 compared to the three months ended October 31, 2013 due to its larger and more established sales force compared to our other theaters. Revenue from both EMEA and APAC increased for the three months ended October 31, 2014 compared to the three months ended October 31, 2013 due to our investment in increasing the size of our sales force and number of channel partners in these theaters.

[0001327567-14-000043:mdna:73]
[same as prior period, unchanged from 0001327567-14-000013:mdna:87]

[0001327567-14-000043:mdna:74]
|  | Three Months Ended October 31, |  |  |
|  | 2014 |  | 2013 |  | Change |
|  | Amount |  | Gross Margin |  | Amount |  | Gross Margin |  | Amount |  | Percentage |
|  | (dollars in thousands) |
| Cost of revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 29,141 |  |  |  |  | $ | 17,954 |  |  |  |  | $ | 11,187 |  |  | 62.3 | % |
| Services | 24,320 |  |  |  |  | 15,853 |  |  |  |  | 8,467 |  |  | 53.4 | % |
| Total cost of revenue | $ | 53,461 |  |  |  |  | $ | 33,807 |  |  |  |  | $ | 19,654 |  |  | 58.1 | % |
| Includes share-based compensation of: |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 749 |  |  |  |  | $ | 250 |  |  |  |  | $ | 499 |  |  | 199.6 | % |
| Services | 3,495 |  |  |  |  | 1,413 |  |  |  |  | 2,082 |  |  | 147.3 | % |
| Total | $ | 4,244 |  |  |  |  | $ | 1,663 |  |  |  |  | $ | 2,581 |  |  | 155.2 | % |
| Gross profit: |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 72,335 |  |  | 71.3 | % |  | $ | 57,531 |  |  | 76.2 | % |  | $ | 14,804 |  |  | (4.9 | )% |
| Services | 66,550 |  |  | 73.2 | % |  | 36,842 |  |  | 69.9 | % |  | 29,708 |  |  | 3.3 | % |
| Total gross profit | $ | 138,885 |  |  | 72.2 | % |  | $ | 94,373 |  |  | 73.6 | % |  | $ | 44,512 |  |  | (1.4 | )% |

[0001327567-14-000043:mdna:75]
Product cost increased $11.2 million, or 62.3%, for the three months ended October 31, 2014 compared to the three months ended October 31, 2013 due to an increase in product unit volume.

[0001327567-14-000043:mdna:76]
Service cost increased $8.5 million, or 53.4%, for the three months ended October 31, 2014 compared to the three months ended October 31, 2013 due to an increase in personnel costs of $4.2 million related to increasing our headcount, amortization of acquired intangible assets of $1.3 million, allocated costs of $1.1 million, and other costs incurred to expand our customer service capabilities to support our growing installed end-customer base.

[0001327567-14-000043:mdna:77]
Gross margin decreased 140 basis points for the three months ended October 31, 2014 compared to the three months ended October 31, 2013. The decrease of 490 basis points in product margin was driven by a decrease of 300 basis points due to amortization of intellectual property licenses of $3.1 million. The remaining decrease was due to higher product cost as a result of new product introductions, including the PA-7050 firewalls, which will have lower product margins until increased volume drives better economies of scale. The increase of 330 basis points in services margin was driven by an increase of 480 basis points due to contributions from our higher margin subscription services, partially offset by a 150 basis points decrease due to amortization of purchased intangible assets.

[0001327567-14-000043:mdna:78]
[same as prior period, unchanged from 0001327567-14-000013:mdna:73]

[0001327567-14-000043:mdna:79]
[same as prior period, unchanged from 0001327567-14-000013:mdna:96]

[0001327567-14-000043:mdna:80]
|  | Three Months Ended October 31, |  |  |  |  |
|  | 2014 |  | 2013 |  | Change |
|  | Amount |  | % of Revenue |  | Amount |  | % of Revenue |  | Amount |  | % |
|  | (dollars in thousands) |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | $ | 37,305 |  |  | 19.4 | % |  | $ | 19,893 |  |  | 15.5 | % |  | $ | 17,412 |  |  | 87.5 | % |
| Sales and marketing | 106,366 |  |  | 55.3 | % |  | 67,366 |  |  | 52.6 | % |  | 39,000 |  |  | 57.9 | % |
| General and administrative | 18,977 |  |  | 9.9 | % |  | 14,125 |  |  | 11.0 | % |  | 4,852 |  |  | 34.4 | % |
| Total operating expenses | $ | 162,648 |  |  | 84.6 | % |  | $ | 101,384 |  |  | 79.1 | % |  | $ | 61,264 |  |  | 60.4 | % |
| Includes share-based compensation of: |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | $ | 13,999 |  |  |  |  | $ | 3,262 |  |  |  |  | $ | 10,737 |  |  | 329.2 | % |
| Sales and marketing | 15,799 |  |  |  |  | 6,628 |  |  |  |  | 9,171 |  |  | 138.4 | % |
| General and administrative | 4,433 |  |  |  |  | 2,858 |  |  |  |  | 1,575 |  |  | 55.1 | % |
| Total | $ | 34,231 |  |  |  |  | $ | 12,748 |  |  |  |  | $ | 21,483 |  |  | 168.5 | % |

[0001327567-14-000043:mdna:81]
Research and development expense increased $17.4 million, or 87.5%, for the three months ended October 31, 2014 compared to the three months ended October 31, 2013, due to an increase in personnel costs of $15.6 million largely due to an increase in headcount and an increase in allocated costs of $1.2 million.

[0001327567-14-000043:mdna:82]
Sales and marketing expense increased $39.0 million, or 57.9%, for the three months ended October 31, 2014 compared to the three months ended October 31, 2013, due to an increase in personnel costs of $23.5 million largely due to an increase in headcount, an increase in demand generation activities, trade shows, and other marketing activities of $4.9 million, an increase in allocated costs of $3.4 million, and an increase in travel and entertainment costs of $3.3 million.

[0001327567-14-000043:mdna:83]
General and administrative expense increased $4.9 million, or 34.4%, for the three months ended October 31, 2014 compared to the three months ended October 31, 2013, due to an increase in personnel costs of $3.8 million, largely due to an increase in headcount.

[0001327567-14-000043:mdna:84]
Interest Expense

[0001327567-14-000043:mdna:85]
|  | Three Months Ended October 31, |  |  |  |  |
|  | 2014 |  | 2013 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in thousands) |
| Interest expense | $ | 5,489 |  |  | $ | 8 |  |  | $ | 5,481 |  |  | NM |

[0001327567-14-000043:mdna:86]
Interest expense increased $5.5 million for the three months ended October 31, 2014 compared to the three months ended October 31, 2013 due to the amortization of the debt discount and debt issuance costs related to the Notes. This interest expense is non-cash and will range from $22.3 million to $25.7 million per year through fiscal 2019.

[0001327567-14-000043:mdna:87]
[same as prior period, unchanged from 0001327567-14-000013:mdna:107]

[0001327567-14-000043:mdna:88]
|  | Three Months Ended October 31, |  |  |  |  |
|  | 2014 |  | 2013 |  | Change |
|  | (dollars in thousands) |
| Provision for income taxes | $ | 1,157 |  |  | $ | 1,247 |  |  | $ | (90 | ) |  | (7.2 | )% |
| Effective tax rate | (4.0 | )% |  | (18.9 | )% |  |  |  |  |

[0001327567-14-000043:mdna:89]
We recorded an income tax provision for the three months ended October 31, 2014 due to federal, state, and foreign income taxes and foreign withholding taxes. The provision for income taxes decreased for the three months ended October 31, 2014 compared

[0001327567-14-000043:mdna:90]
[same as prior period, unchanged from 0001327567-14-000013:mdna:75]

[0001327567-14-000043:mdna:91]
to the three months ended October 31, 2013 due to increased U.S. taxable income and a shift in geographical mix of income due to global expansion.

[0001327567-14-000043:mdna:92]
[same as prior period, unchanged from 0001327567-14-000013:mdna:110]

[0001327567-14-000043:mdna:93]
|  | October 31, 2014 |  | July 31, 2014 |
|  | (in thousands) |
| Working capital | $ | 572,601 |  |  | $ | 610,155 |  |
| Cash, cash equivalents, and investments: |  |  |  |
| Cash and cash equivalents | $ | 543,747 |  |  | $ | 653,812 |  |
| Investments | 516,763 |  |  | 320,570 |  |
| Total cash, cash equivalents, and investments | $ | 1,060,510 |  |  | $ | 974,382 |  |

[0001327567-14-000043:mdna:94]
At October 31, 2014, our cash, cash equivalents, and investments of $1.1 billion were held for general corporate purposes, of which approximately $140.5 million was held outside the United States. Our current plans do not include repatriating these funds. However, if these funds were needed for our domestic operations, we would be required to accrue and pay U.S. taxes on undistributed earnings of foreign subsidiaries. There are no other restrictions on the use of these funds. We do not provide for federal income taxes on the undistributed earnings of our foreign subsidiaries, all of which we expect to reinvest outside of the United States indefinitely. If we were to repatriate these earnings to the United States, any associated income tax liability would be insignificant.

[0001327567-14-000043:mdna:95]
In June 2014, we issued the Notes with an aggregate principal amount of $575.0 million. The Notes will mature on July 1, 2019. Prior to January 1, 2019, holders may surrender their Notes for early conversion under certain circumstances. Upon conversion of the Notes, we will pay cash up to the aggregate principal amount of the Notes to be converted and we may choose to pay or deliver, as the case may be, cash, shares of our common stock or a combination of cash and shares of our common stock with respect to the remainder of our conversion obligation in excess of the aggregate principal amount of the Notes being converted. As of October 31, 2014, the Notes were not convertible. Refer to Note 5. Convertible Senior Notes of Notes to Condensed Consolidated Financial Statements included in Part I, Item 1 of this Quarterly Report on Form 10-Q for information on the Notes.

[0001327567-14-000043:mdna:96]
The following table summarizes our cash flows for the three months ended October 31, 2014 and 2013.

[0001327567-14-000043:mdna:97]
|  | Three Months Ended October 31, |
| 2014 |  | 2013 |
|  | (in thousands) |
| Cash provided by operating activities | $ | 74,928 |  |  | $ | 38,881 |  |
| Cash used in investing activities | (201,093 | ) |  | (93,959 | ) |
| Cash provided by financing activities | 16,100 |  |  | 10,646 |  |
| Net decrease in cash and cash equivalents | $ | (110,065 | ) |  | $ | (44,432 | ) |

[0001327567-14-000043:mdna:98]
We believe that our cash flow from operations with existing cash and cash equivalents will be sufficient to meet our anticipated cash needs for the foreseeable future. Our future capital requirements will depend on many factors including our growth rate, the timing and extent of spending to support development efforts, the expansion of sales and marketing activities, the introduction of new and enhanced products and services offerings, the costs to acquire or invest in complementary businesses and technologies, the costs to ensure access to adequate manufacturing capacity, and the continuing market acceptance of our products. In addition, from time to time we may incur additional tax liability in connection with certain tax structuring decisions, for example, we may be required to pay additional taxes related to the acquisition of Cyvera Ltd. if we transfer the acquired intellectual property out of Israel.

[0001327567-14-000043:mdna:99]
We may also choose to seek additional equity or debt financing. In the event that additional financing is required from outside sources, we may not be able to raise it on terms acceptable to us or at all. If we are unable to raise additional capital when desired, our business, operating results, and financial condition may be adversely affected.

[0001327567-14-000043:mdna:100]
[same as prior period, unchanged from 0001327567-14-000013:mdna:114]

[0001327567-14-000043:mdna:101]
[same as prior period, unchanged from 0001327567-14-000013:mdna:115]

[0001327567-14-000043:mdna:102]
[same as prior period, unchanged from 0001327567-14-000013:mdna:77]

[0001327567-14-000043:mdna:103]
Cash provided by operating activities during the three months ended October 31, 2014 was $74.9 million, an increase of $36.0 million compared to the three months ended October 31, 2013 due to changes in our assets and liabilities and growth of our business during the three months ended October 31, 2014. Changes in assets and liabilities during the three months ended October 31, 2014 compared to the three months ended October 31, 2013 include an increase in collections on accounts receivable and an increase in sales of subscriptions and support and maintenance contracts to new and existing customers as reflected by an increase in deferred revenue, partially offset by an increase in commissions paid during the three months ended October 31, 2014.

[0001327567-14-000043:mdna:104]
[same as prior period, unchanged from 0001327567-14-000013:mdna:120]

[0001327567-14-000043:mdna:105]
[same as prior period, unchanged from 0001327567-14-000013:mdna:121]

[0001327567-14-000043:mdna:106]
Cash used in investing activities during the three months ended October 31, 2014 was $201.1 million, an increase of $107.1 million as compared to the three months ended October 31, 2013. The increase was primarily due to higher net purchases of available-for-sale investments, partially offset by decreased purchases of property, equipment, and other assets during the three months ended October 31, 2014.

[0001327567-14-000043:mdna:107]
[same as prior period, unchanged from 0001327567-14-000013:mdna:123]

[0001327567-14-000043:mdna:108]
[same as prior period, unchanged from 0001327567-14-000013:mdna:124]

[0001327567-14-000043:mdna:109]
Cash provided by financing activities during the three months ended October 31, 2014 was $16.1 million, an increase of $5.5 million as compared to the three months ended October 31, 2013. The increase was due to higher proceeds from the sale of shares through employee equity incentive plans during the three months ended October 31, 2014.

[0001327567-14-000043:mdna:110]
[same as prior period, unchanged from 0001327567-14-000013:mdna:126]

[0001327567-14-000043:mdna:111]
Through October 31, 2014, we did not have any relationships with unconsolidated organizations or financial partnerships, such as structured finance or special purpose entities, that would have been established for the purpose of facilitating off-balance sheet arrangements or other contractually narrow or limited purposes.

[0001327567-14-000043:mdna:112]
[same as prior period, unchanged from 0001327567-14-000013:mdna:128]

[0001327567-14-000043:mdna:113]
[same as prior period, unchanged from 0001327567-14-000013:mdna:129]

[0001327567-14-000043:mdna:114]
We believe the critical accounting policies and estimates discussed under Item 7, “Management’s Discussion and Analysis of Financial Condition and Results of Operations” in our Annual Report on Form 10-K filed with the Securities and Exchange Commission (SEC) on September 18, 2014, reflect our more significant judgments and estimates used in the preparation of the condensed consolidated financial statements. See “Available Information” below for instructions on how to access our Annual Report on Form 10-K. There have been no significant changes to our critical accounting policies and estimates as filed in such report.

[0001327567-14-000043:mdna:115]
[same as prior period, unchanged from 0001327567-14-000013:mdna:136]

[0001327567-14-000043:mdna:116]
Refer to “Recent Accounting Pronouncements” in Note 1. Description of Business and Summary of Significant Accounting Policies of Notes to Condensed Consolidated Financial Statements included in Part I, Item 1 of this Quarterly Report on Form 10-Q.

[0001327567-14-000043:mdna:117]
[same as prior period, unchanged from 0001327567-14-000013:mdna:138]

[0001327567-14-000043:mdna:118]
Our website is located at www.paloaltonetworks.com, and our investor relations website is located at http://investors.paloaltonetworks.com. Copies of Annual Reports on Form 10-K, Quarterly Reports on Form 10-Q, Current Reports on Form 8-K, and amendments to these reports filed or furnished pursuant to Section 13(a) or 15(d) of the Securities Exchange Act of 1934, as amended (the “Exchange Act”), are available, free of charge, on our investor relations website as soon as reasonably practicable after we file such material electronically with or furnish it to the SEC. The SEC also maintains a website that contains our SEC filings. The address of the site is www.sec.gov. Further, a copy of this Quarterly Report on Form 10-Q is located at the SEC's Public Reference Room at 100 F Street, NE, Washington, D.C. 20549. Information on the operation of the Public Reference Room can be obtained by calling the SEC at 1-800-SEC-0330.

[0001327567-14-000043:mdna:119]
[same as prior period, unchanged from 0001327567-14-000013:mdna:86]

[0001327567-14-000043:mdna:120]
[same as prior period, unchanged from 0001327567-14-000013:mdna:140]
