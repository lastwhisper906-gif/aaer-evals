# PANW notes — 0001327567-14-000043


## us-gaap:AvailableForSaleSecuritiesContinuousUnrealizedLossPositionFairValueTableTextBlock

[0001327567-14-000043:notes:1]
The following tables present our investments that were in an unrealized loss position as of October 31, 2014 and July 31, 2014 (in thousands):

[0001327567-14-000043:notes:2]
|  | October 31, 2014 |
|  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
|  | Fair Value |  | Unrealized Loss |  | Fair Value |  | Unrealized Loss |  | Fair Value |  | Unrealized Loss |
| Corporate debt securities | $ | 72,352 |  |  | $ | (85 | ) |  | $ | — |  |  | $ | — |  |  | $ | 72,352 |  |  | $ | (85 | ) |
| U.S. government and agency securities | 185,151 |  |  | (119 | ) |  | — |  |  | — |  |  | 185,151 |  |  | (119 | ) |
| Total | $ | 257,503 |  |  | $ | (204 | ) |  | $ | — |  |  | $ | — |  |  | $ | 257,503 |  |  | $ | (204 | ) |

[0001327567-14-000043:notes:3]
|  | July 31, 2014 |
|  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
|  | Fair Value |  | Unrealized Loss |  | Fair Value |  | Unrealized Loss |  | Fair Value |  | Unrealized Loss |
| Corporate debt securities | $ | 43,868 |  |  | $ | (58 | ) |  | $ | — |  |  | $ | — |  |  | $ | 43,868 |  |  | $ | (58 | ) |
| U.S. government and agency securities | 142,490 |  |  | (108 | ) |  | — |  |  | — |  |  | 142,490 |  |  | (108 | ) |
| Total | $ | 186,358 |  |  | $ | (166 | ) |  | $ | — |  |  | $ | — |  |  | $ | 186,358 |  |  | $ | (166 | ) |


## us-gaap:AvailableForSaleSecuritiesTextBlock

[0001327567-14-000043:notes:4]
The following tables summarize the unrealized gains and losses and fair value of our investments as of October 31, 2014 and July 31, 2014 (in thousands):

[0001327567-14-000043:notes:5]
|  | October 31, 2014 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Estimated Fair Value |
| Certificates of deposit | $ | 1,000 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,000 |  |
| Corporate debt securities | 102,797 |  |  | 18 |  |  | (85 | ) |  | 102,730 |  |
| U.S. government and agency securities | 412,980 |  |  | 172 |  |  | (119 | ) |  | 413,033 |  |
| Total | $ | 516,777 |  |  | $ | 190 |  |  | $ | (204 | ) |  | $ | 516,763 |  |

[0001327567-14-000043:notes:6]
|  | July 31, 2014 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Estimated Fair Value |
| Certificates of deposit | $ | 1,000 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,000 |  |
| Corporate debt securities | 61,299 |  |  | 16 |  |  | (58 | ) |  | 61,257 |  |
| U.S. government and agency securities | 258,376 |  |  | 45 |  |  | (108 | ) |  | 258,313 |  |
| Total | $ | 320,675 |  |  | $ | 61 |  |  | $ | (166 | ) |  | $ | 320,570 |  |


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001327567-14-000043:notes:7]
[same as prior period, unchanged from 0001327567-14-000013:notes:7]

[0001327567-14-000043:notes:8]
The accompanying condensed consolidated financial statements have been prepared in conformity with U.S. generally accepted accounting principles, consistent in all material respects with those applied in our Annual Report on Form 10-K for the fiscal year ended July 31, 2014. The condensed consolidated financial statements include all adjustments necessary for a fair presentation of our quarterly results. All adjustments are of a normal recurring nature. We have made estimates and judgments affecting the amounts reported in our condensed consolidated financial statements and the accompanying notes. The actual results that we experience may differ materially from our estimates. Certain prior period amounts have been reclassified to conform with current period presentation.


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock

[0001327567-14-000043:notes:9]
[same as prior period, unchanged from 0001327567-14-000013:notes:35]

[0001327567-14-000043:notes:10]
[same as prior period, unchanged from 0001327567-14-000013:notes:36]

[0001327567-14-000043:notes:11]
Palo Alto Networks, Inc. (the “Company,” “we,” “us,” or “our”), located in Santa Clara, California, was incorporated in March 2005 under the laws of the State of Delaware and commenced operations in April 2005. We offer a next-generation enterprise security platform that allows enterprises, service providers, and government entities to simultaneously empower and secure their organizations by safely enabling the increasingly complex and rapidly growing number of applications running on their networks and by preventing breaches stemming from targeted cyber attacks.

[0001327567-14-000043:notes:12]
Our enterprise security platform consists of three major elements: our Next-Generation Firewall, our Advanced Endpoint Protection, and our Threat Intelligence Cloud. Our Next-Generation Firewall delivers application, user, and content visibility and control as well as protection against network-based cyber threats integrated within the firewall through our proprietary hardware and software architecture. Our Advanced Endpoint Protection prevents cyber attacks that aim to exploit software vulnerabilities on a broad variety of fixed and virtual endpoints. Our Threat Intelligence Cloud provides central intelligence capabilities as well as automated delivery of preventative measures against cyber attacks. The cloud-based element of our platform is delivered in the form of a service that can be used either in the public cloud or in a private cloud using a dedicated appliance.

[0001327567-14-000043:notes:13]
We primarily sell our products and services to end-customers through our channel partners and infrequently directly to end-customers. Our partners are supported by our sales and marketing organization in the Americas, in Europe, the Middle East, and Africa (EMEA), and in Asia Pacific and Japan (APAC).

[0001327567-14-000043:notes:14]
[same as prior period, unchanged from 0001327567-14-000013:notes:38]

[0001327567-14-000043:notes:15]
[same as prior period, unchanged from 0001327567-14-000013:notes:39]

[0001327567-14-000043:notes:16]
[same as prior period, unchanged from 0001327567-14-000013:notes:40]

[0001327567-14-000043:notes:17]
There have been no material changes to our significant accounting policies as of and for the three months ended October 31, 2014, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended July 31, 2014.

[0001327567-14-000043:notes:18]
[same as prior period, unchanged from 0001327567-14-000013:notes:48]

[0001327567-14-000043:notes:19]
In August 2014, the Financial Accounting Standards Board (FASB) issued Accounting Standards Update (ASU) No. 2014-15, Presentation of Financial Statements-Going Concern (Subtopic 205-40)-Disclosure of Uncertainties about an Entity’s Ability to Continue as a Going Concern. The standard provides guidance about management's responsibility to evaluate whether there is substantial doubt about an entity's ability to continue as a going concern and to provide related footnote disclosures. The standard is effective for fiscal years ending after December 15, 2016, and for interim periods thereafter. Early adoption is permitted. We will adopt the new standard in our fiscal year ending 2017. The adoption of this standard is not expected to have a material impact on our condensed consolidated financial statements.

[0001327567-14-000043:notes:20]
In May 2014, the FASB issued ASU No. 2014-09 regarding Accounting Standards Codification (ASC) Topic 606-Revenue from Contracts with Customers. The standard provides principles for recognizing revenue for the transfer of promised goods or services to customers with the consideration to which the entity expects to be entitled in exchange for those goods or services. The guidance is effective for us in the first quarter of fiscal 2018 using either of two methods: (i) retrospective to each prior reporting period presented with the option to elect certain practical expedients as defined within the guidance; or (ii) retrospective with the cumulative effect of initially applying the guidance recognized at the date of initial application and providing certain additional disclosures as defined per the guidance. Early adoption is not permitted. We are currently evaluating adoption methods and whether this standard will have a material impact on our condensed consolidated financial statements.

[0001327567-14-000043:notes:21]
In July 2013, the FASB issued ASU No. 2013-11, Income Taxes (Topic 740)-Presentation of an Unrecognized Tax Benefit When a Net Operating Loss Carryforward, a Similar Tax Loss, or a Tax Credit Carryforward Exists. The standard requires us to present an unrecognized tax benefit as a reduction of a deferred tax asset for a net operating loss (NOL) carryforward or other tax credit carryforward when settlement in this manner is available under applicable tax law. The guidance was effective for us in the first quarter of fiscal 2015. Our adoption of this guidance did not have any impact on our condensed consolidated financial statements.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001327567-14-000043:notes:22]
Commitments and Contingencies

[0001327567-14-000043:notes:23]
Leases

[0001327567-14-000043:notes:24]
We lease our facilities under various non-cancelable operating leases, which expire through the year ending July 31, 2023.

[0001327567-14-000043:notes:25]
The following table presents details of the aggregate future non-cancelable minimum rental payments on our operating leases as of October 31, 2014 (in thousands):

[0001327567-14-000043:notes:26]
|  | Amount |
| Fiscal years ending July 31: |  |
| Remaining 2015 | $ | 11,686 |  |
| 2016 | 15,629 |  |
| 2017 | 14,549 |  |
| 2018 | 12,016 |  |
| 2019 | 9,697 |  |
| 2020 and thereafter | 42,603 |  |
| Committed gross lease payments | 106,180 |  |
| Less: proceeds from sublease rental | 10,282 |  |
| Net operating lease obligation | $ | 95,898 |  |

[0001327567-14-000043:notes:27]
Contract Manufacturer Commitments

[0001327567-14-000043:notes:28]
Our independent contract manufacturer procures components and assembles our products based on our forecasts. These forecasts are based on estimates of demand for our products primarily for the next twelve months, which are in turn based on historical trends and an analysis from our sales and product marketing organizations, adjusted for overall market conditions. In order to reduce manufacturing lead times and plan for adequate supply, we may issue forecasts and orders for components and products that are non-cancelable. Obligations under contracts that we can cancel without a significant penalty are not included. As of October 31, 2014, we had $39,018,000 of open orders.

[0001327567-14-000043:notes:29]
Litigation

[0001327567-14-000043:notes:30]
In December 2011, Juniper Networks, Inc. (“Juniper”) filed a complaint against us in the United States District Court for the District of Delaware alleging patent infringement, which sought preliminary and permanent injunctions against infringement, treble damages, and attorneys' fees. On September 30, 2013, we filed a lawsuit against Juniper in the United States District Court for the Northern District of California alleging that Juniper’s products infringe three of our U.S. patents, and sought monetary damages and a permanent injunction.

[0001327567-14-000043:notes:31]
On May 27, 2014, we entered into a Settlement, Release and Cross-License Agreement (the “settlement agreement”) with Juniper to resolve all pending litigation between the parties, including those discussed above. Under the terms of the settlement agreement, we agreed to pay Juniper a one-time settlement amount of approximately $175,000,000, which was comprised of $75,000,000 in cash, 1,081,000 shares of our common stock with an approximate value of $70,000,000, and a warrant to purchase 463,000 shares of our common stock with an approximate value of $30,000,000, in exchange for the following:

[0001327567-14-000043:notes:32]
| • | Mutual dismissal with prejudice of all pending litigation between the parties and general release of all liability for Palo Alto Networks and Juniper, |

[0001327567-14-000043:notes:33]
| • | Cross-license between both parties for the patents-in-suit and associated family members and counterparts worldwide for the life of the patents, and |

[0001327567-14-000043:notes:34]
| • | Mutual covenant not to sue for infringement of any other patents for a period of eight years. |

[0001327567-14-000043:notes:35]
For accounting purposes, the fair value of the total consideration as of the settlement date was $182,473,000, which was comprised of $75,000,000 in cash, $75,231,000 in common stock, and $32,242,000 in warrant. The fair values of the common stock and warrant were measured using the closing price of our common stock on the settlement date.

[0001327567-14-000043:notes:36]
The warrant was issued on June 3, 2014 and entitled Juniper to purchase up to 463,000 shares of common stock at an exercise price of $0.0001 per share and was classified as a liability during the period it was outstanding. On July 1, 2014, Juniper exercised the warrant in full. Accordingly, we recorded the change in the fair value of the warrant liability through the exercise date of $5,859,000 within other income (expense), net in the consolidated statement of operations for the year ended July 31, 2014.

[0001327567-14-000043:notes:37]
We accounted for the settlement agreement as a multiple-element arrangement and allocated the fair value of the consideration as of the settlement date to the identifiable elements based on their estimated fair values. Of the total settlement amount, $61,300,000 was allocated to the licensing of intellectual property, $54,300,000 was allocated to the mutual dismissal of claims, and the remaining amount was allocated to the mutual covenant not to sue. The mutual dismissal of claims and the mutual covenant not to sue have no identifiable future benefit, and as a result we recorded a settlement charge within operating expenses in the consolidated statements of operations for the year ended July 31, 2014. The licensing of intellectual property is being amortized over the estimated period of benefit of five years.

[0001327567-14-000043:notes:38]
In addition to the above matter, we are subject to legal proceedings, claims, and litigation arising in the ordinary course of business, including intellectual property litigation. Such matters are subject to many uncertainties and outcomes are not predictable with assurance. We accrue for contingencies when we believe that a loss is probable and that we can reasonably estimate the amount of any such loss. We have made an assessment of the probability of incurring any such losses and whether or not those losses are estimable.

[0001327567-14-000043:notes:39]
To the extent there is a reasonable possibility that a loss exceeding amounts already recognized may be incurred and the amount of such additional loss would be material, we will either disclose the estimated additional loss or state that such an estimate cannot be made. As of October 31, 2014, we have not recorded any accrual for loss contingencies associated with such legal proceedings, determined that an unfavorable outcome is probable or reasonably possible, or determined that the amount or range of any possible loss is reasonably estimable.


## us-gaap:ConvertibleDebtTableTextBlock

[0001327567-14-000043:notes:40]
The following table sets forth the components of the Notes as of October 31, 2014 and July 31, 2014 (in thousands):

[0001327567-14-000043:notes:41]
|  | October 31, 2014 |  | July 31, 2014 |
| Liability: |  |  |  |
| Principal | $ | 575,000 |  |  | $ | 575,000 |  |
| Less: debt discount, net of amortization | 103,144 |  |  | 108,125 |  |
| Net carrying amount | $ | 471,856 |  |  | $ | 466,875 |  |
| Equity | $ | (109,785 | ) |  | $ | (109,785 | ) |


## us-gaap:DebtDisclosureTextBlock

[0001327567-14-000043:notes:42]
Convertible Senior Notes

[0001327567-14-000043:notes:43]
On June 30, 2014, we issued $575,000,000 aggregate principal amount of 0.0% convertible senior notes due 2019 (the “Notes”). The Notes are governed by an indenture between us, as the issuer, and U.S. Bank National Association, as Trustee. The Notes are unsecured, unsubordinated obligations that do not contain any financial covenants or restrictions on the payments of dividends, the incurrence of indebtedness, or the issuance or repurchase of securities by us or any of our subsidiaries. The Notes mature on July 1, 2019 unless converted or repurchased in accordance with their terms prior to such date. We cannot redeem the Notes prior to maturity.

[0001327567-14-000043:notes:44]
The Notes are convertible for up to 5,214,000 shares of our common stock at an initial conversion rate of approximately 9.068 shares of common stock per $1,000 principal amount, which is equal to an initial conversion price of approximately $110.28 per share of common stock, subject to adjustment. Holders of the Notes may surrender their Notes for conversion at their option at any time prior to the close of business on the business day immediately preceding January 1, 2019, only under the following circumstances, none of which have occurred to date:

[0001327567-14-000043:notes:45]
| • | during any fiscal quarter commencing after the fiscal quarter ending on October 31, 2014 (and only during such fiscal quarter), if the last reported sale price of our common stock for at least 20 trading days (whether or not consecutive) during a period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the conversion price for the Notes on each applicable trading day; |

[0001327567-14-000043:notes:46]
| • | during the five business day period after any five consecutive trading day period (the “measurement period”), in which the trading price per $1,000 principal amount of Notes for each trading day of the measurement period was less than 98% of the product of the last reported sale price of our common stock and the conversion rate for the Notes on each such trading day; or |

[0001327567-14-000043:notes:47]
| • | upon the occurrence of specified corporate events. |

[0001327567-14-000043:notes:48]
On or after January 1, 2019, holders may convert all or any portion of their Notes at any time prior to the close of business on the second scheduled trading day immediately preceding the maturity date regardless of the foregoing conditions. Upon conversion, holders will receive cash equal to the aggregate principal amount of the Notes to be converted, and, at our election, cash and/or shares of our common stock for any amounts in excess of the aggregate principal amount of the Notes being converted.

[0001327567-14-000043:notes:49]
The conversion price will be subject to adjustment in some events. Holders of the Notes who convert their Notes in connection with certain corporate events that constitute a “make-whole fundamental change” per the Indenture governing the Notes are, under certain circumstances, entitled to an increase in the conversion rate. Additionally, upon the occurrence of a corporate event that constitutes a “fundamental change” per the Indenture governing the Notes, holders of the Notes may require us to repurchase for cash all or a portion of the Notes at a purchase price equal to 100% of the principal amount of the Notes plus accrued and unpaid contingent interest.

[0001327567-14-000043:notes:50]
In accounting for the issuance of the Notes, we separated the Notes into liability and equity components. The carrying amount of the liability component was calculated by measuring the fair value of a similar liability that does not have an associated convertible feature. The carrying amount of the equity component representing the conversion option was determined by deducting the fair value of the liability component from the par value of the Notes as a whole. The difference between the principal amount of the Notes and the liability component (the “debt discount”), is amortized to interest expense using the effective interest method over the term of the Notes. The equity component of the Notes is included in additional paid-in capital in the condensed consolidated balance sheets and is not remeasured as long as it continues to meet the conditions for equity classification.

[0001327567-14-000043:notes:51]
In accounting for the transaction costs related to the issuance of the Notes, we allocated the total amount incurred to the liability and equity components using the same proportions as the proceeds from the Notes. Transaction costs attributable to the liability component were recorded in other assets in the condensed consolidated balance sheets and are being amortized to interest expense in the condensed consolidated statements of operations using the effective interest method over the term of the Notes. Transaction costs attributable to the equity component were netted with the equity component of the Notes in additional paid-in capital in the condensed consolidated balance sheets. We recorded liability issuance costs, or debt issuance costs, of $12,497,000 and equity issuance costs of $2,949,000.

[0001327567-14-000043:notes:52]
The total estimated fair value of the Notes was $677,856,000 and $587,087,000 at October 31, 2014 and July 31, 2014, respectively. The fair value was determined based on the closing trading price per $100 of the Notes as of the last day of trading for the period. We consider the fair value of the Notes at October 31, 2014 and July 31, 2014 to be a Level 2 measurement. The fair value of the Notes is primarily affected by the trading price of our common stock and market interest rates. Based on the closing price of our common stock of $105.70 on October 31, 2014, the if-converted value of the Notes was less than its principal amount.

[0001327567-14-000043:notes:53]
The following table sets forth interest expense recognized related to the Notes for the three months ended October 31, 2014 (dollars in thousands):

[0001327567-14-000043:notes:54]
|  | Amount |
| Amortization of debt issuance costs | $ | 497 |  |
| Amortization of debt discount | 4,981 |  |
| Total interest expense recognized | $ | 5,478 |  |
| Effective interest rate of the liability component | 4.8 | % |

[0001327567-14-000043:notes:55]
Note Hedges

[0001327567-14-000043:notes:56]
To minimize the impact of potential economic dilution upon conversion of the Notes, we entered into convertible note hedge transactions (the “Note Hedges”) with respect to our common stock concurrent with the issuance of the Notes. The Note Hedges cover up to 5,214,000 shares of our common stock at a strike price per share that corresponds to the initial conversion price of the Notes, which are also subject to adjustment, and are exercisable upon conversion of the Notes. The Note Hedges will expire upon maturity of the Notes. The Note Hedges are separate transactions and are not part of the terms of the Notes. Holders of the Notes will not have any rights with respect to the Note Hedges. The shares receivable related to the Note Hedges are excluded from the calculation of diluted earnings per share as they are antidilutive.

[0001327567-14-000043:notes:57]
We paid an aggregate amount of $110,975,000 for the Note Hedges, which is included in additional paid-in capital in the condensed consolidated balance sheets.

[0001327567-14-000043:notes:58]
Warrants

[0001327567-14-000043:notes:59]
Separately, but concurrently with our issuance of the Notes, we entered into warrant transactions (the “Warrants”) whereby we sold warrants to acquire up to 5,214,000 shares of our common stock at a strike price of approximately $137.85 per share, subject to adjustments. The shares issuable under the Warrants will be included in the calculation of diluted earnings per share when the average market value per share of our common stock for the reporting period exceeds the strike price of the Warrants. The Warrants are separate transactions and are not part of the Notes or Notes Hedges, and are not remeasured through earnings each reporting period. Holders of the Notes and Note Hedges will not have any rights with respect to the Warrants.

[0001327567-14-000043:notes:60]
We received aggregate proceeds of $78,258,000 from the sale of the Warrants, which is included in additional paid-in capital in the condensed consolidated balance sheets.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001327567-14-000043:notes:61]
[same as prior period, unchanged from 0001327567-14-000013:notes:65]

[0001327567-14-000043:notes:62]
[same as prior period, unchanged from 0001327567-14-000013:notes:66]

[0001327567-14-000043:notes:63]
A summary of the activity under our stock plans during the reporting period and a summary of information related to options exercisable, vested, and expected to vest are presented below (in thousands, except per share amounts):

[0001327567-14-000043:notes:64]
|  | Options Outstanding |
|  | Number of Shares |  | Weighted- Average Exercise Price |  | Weighted- Average Remaining Contractual Term (Years) |  | Aggregate Intrinsic Value |
| Balance—July 31, 2014 | 5,830 |  |  | $ | 13.02 |  |  | 7.0 |  | $ | 395,507 |  |
| Options granted | — |  |  | — |  |  |  |  |  |
| Options forfeited | (17 | ) |  | 13.17 |  |  |  |  |  |
| Options exercised | (618 | ) |  | 12.86 |  |  |  |  |  |
| Balance—October 31, 2014 | 5,195 |  |  | $ | 13.04 |  |  | 6.8 |  | $ | 481,369 |  |
| Options vested and expected to vest—October 31, 2014 | 5,105 |  |  | $ | 12.95 |  |  | 6.8 |  | $ | 473,489 |  |
| Options exercisable—October 31, 2014 | 3,247 |  |  | $ | 10.63 |  |  | 6.6 |  | $ | 308,692 |  |

[0001327567-14-000043:notes:65]
Restricted Stock Unit (RSU) Activities

[0001327567-14-000043:notes:66]
A summary of the activity under our stock plans during the reporting period and a summary of information related to RSUs vested and expected to vest are presented below (in thousands, except per share amounts):

[0001327567-14-000043:notes:67]
|  | RSUs Outstanding |
|  | Number of Shares |  | Weighted- Average Grant-Date Fair Value Per Share |  | Weighted- Average Remaining Contractual Term (Years) |  | Aggregate Intrinsic Value |
| Balance—July 31, 2014 | 6,046 |  |  | $ | 59.84 |  |  | 1.4 |  | $ | 488,880 |  |
| RSUs granted | 511 |  |  | 92.61 |  |  |  |  |  |
| RSUs vested | (265 | ) |  | 50.88 |  |  |  |  |  |
| RSUs forfeited | (99 | ) |  | 59.39 |  |  |  |  |  |
| Balance—October 31, 2014 | 6,193 |  |  | $ | 62.93 |  |  | 1.3 |  | $ | 654,600 |  |
| RSUs vested and expected to vest—October 31, 2014 | 5,658 |  |  | $ | 62.64 |  |  | 1.2 |  | $ | 598,051 |  |

[0001327567-14-000043:notes:68]
[same as prior period, unchanged from 0001327567-14-000013:notes:77]

[0001327567-14-000043:notes:69]
[same as prior period, unchanged from 0001327567-14-000013:notes:80]

[0001327567-14-000043:notes:70]
|  | Three Months Ended October 31, |
|  | 2014 |  | 2013 |
| Cost of product revenue | $ | 749 |  |  | $ | 250 |  |
| Cost of services revenue | 3,495 |  |  | 1,413 |  |
| Research and development | 13,999 |  |  | 3,262 |  |
| Sales and marketing | 15,799 |  |  | 6,628 |  |
| General and administrative | 4,433 |  |  | 2,858 |  |
| Total | $ | 38,475 |  |  | $ | 14,411 |  |

[0001327567-14-000043:notes:71]
At October 31, 2014, total compensation cost related to unvested share-based awards not yet recognized was $327,189,000, net of estimated forfeitures. This cost is expected to be amortized on a straight-line basis over a weighted-average period of approximately three years. Future grants will increase the amount of compensation expense to be recorded in these periods.


## us-gaap:EarningsPerShareTextBlock

[0001327567-14-000043:notes:72]
[same as prior period, unchanged from 0001327567-14-000013:notes:85]

[0001327567-14-000043:notes:73]
[same as prior period, unchanged from 0001327567-14-000013:notes:86]

[0001327567-14-000043:notes:74]
[same as prior period, unchanged from 0001327567-14-000013:notes:87]

[0001327567-14-000043:notes:75]
|  | Three Months Ended |
|  | October 31, |
|  | 2014 |  | 2013 |
| Net loss | $ | (30,068 | ) |  | $ | (7,861 | ) |
| Weighted-average shares used to compute net loss per share, basic and diluted | 79,388 |  |  | 71,681 |  |
| Net loss per share, basic and diluted | $ | (0.38 | ) |  | $ | (0.11 | ) |

[0001327567-14-000043:notes:76]
The following securities were excluded from the computation of diluted net income (loss) per share of common stock for the periods presented as their effect would have been antidilutive (in thousands):

[0001327567-14-000043:notes:77]
|  | October 31, |
|  | 2014 |  | 2013 |
| Options to purchase common stock | 5,195 |  |  | 9,203 |  |
| RSUs | 6,193 |  |  | 2,565 |  |
| ESPP shares | 35 |  |  | 53 |  |
| Convertible senior notes | 5,214 |  |  | — |  |
| Warrants related to the issuance of the convertible senior notes | 5,214 |  |  | — |  |


## us-gaap:FairValueAssetsAndLiabilitiesMeasuredOnRecurringAndNonrecurringBasisTableTextBlock

[0001327567-14-000043:notes:78]
The following table presents the fair value of our financial assets and liabilities using the above input categories as of October 31, 2014 and July 31, 2014 (in thousands):

[0001327567-14-000043:notes:79]
|  |  | October 31, 2014 |  | July 31, 2014 |
|  |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Short-term investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate debt securities |  | $ | — |  |  | $ | 39,297 |  |  | $ | — |  |  | $ | 39,297 |  |  | $ | — |  |  | $ | 22,239 |  |  | $ | — |  |  | $ | 22,239 |  |
| U.S. government and agency securities |  | — |  |  | 188,455 |  |  | — |  |  | 188,455 |  |  | — |  |  | 96,451 |  |  | — |  |  | 96,451 |  |
| Total short-term investments |  | — |  |  | 227,752 |  |  | — |  |  | 227,752 |  |  | — |  |  | 118,690 |  |  | — |  |  | 118,690 |  |
| Long-term investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Certificates of deposit |  | — |  |  | 1,000 |  |  | — |  |  | 1,000 |  |  | — |  |  | 1,000 |  |  | — |  |  | 1,000 |  |
| Corporate debt securities |  | — |  |  | 63,433 |  |  | — |  |  | 63,433 |  |  | — |  |  | 39,018 |  |  | — |  |  | 39,018 |  |
| U.S. government and agency securities |  | — |  |  | 224,578 |  |  | — |  |  | 224,578 |  |  | — |  |  | 161,862 |  |  | — |  |  | 161,862 |  |
| Total long-term investments |  | — |  |  | 289,011 |  |  | — |  |  | 289,011 |  |  | — |  |  | 201,880 |  |  | — |  |  | 201,880 |  |
| Other assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Restricted cash |  | 1,220 |  |  | — |  |  | — |  |  | 1,220 |  |  | 1,220 |  |  | — |  |  | — |  |  | 1,220 |  |
| Total other assets |  | 1,220 |  |  | — |  |  | — |  |  | 1,220 |  |  | 1,220 |  |  | — |  |  | — |  |  | 1,220 |  |
| Total assets measured at fair value |  | $ | 1,220 |  |  | $ | 516,763 |  |  | $ | — |  |  | $ | 517,983 |  |  | $ | 1,220 |  |  | $ | 320,570 |  |  | $ | — |  |  | $ | 321,790 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001327567-14-000043:notes:80]
[same as prior period, unchanged from 0001327567-14-000013:notes:93]

[0001327567-14-000043:notes:81]
[same as prior period, unchanged from 0001327567-14-000013:notes:94]

[0001327567-14-000043:notes:82]
[same as prior period, unchanged from 0001327567-14-000013:notes:95]

[0001327567-14-000043:notes:83]
[same as prior period, unchanged from 0001327567-14-000013:notes:96]

[0001327567-14-000043:notes:84]
[same as prior period, unchanged from 0001327567-14-000013:notes:97]

[0001327567-14-000043:notes:85]
Refer to Note 5. Convertible Senior Notes for the carrying amount and estimated fair value of our convertible senior notes, which were not recorded at fair value as of October 31, 2014.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001327567-14-000043:notes:86]
[same as prior period, unchanged from 0001327567-14-000013:notes:98]

[0001327567-14-000043:notes:87]
Our provision for income taxes for the three months ended October 31, 2014 reflects an effective tax rate of negative 4.0%. Our effective tax rate for this period was negative as we recorded a provision for income taxes on year to date losses. The key components of our income tax provision consist of foreign income, foreign withholding taxes, and limited US federal and state income tax due primarily to our net operating loss carryforward. Key components of our effective tax rate consist of foreign tax losses which derive no benefit, non-deductible share-based compensation, and changes in our valuation allowance. As compared to the three months ended October 31, 2013, our negative effective tax rate changed due to fluctuations in our overall loss before income taxes and the geographic mix of income due to global expansion.

[0001327567-14-000043:notes:88]
Our provision for income taxes for the three months ended October 31, 2013 reflects an effective tax rate of negative 18.9%, and consists of foreign income, withholding taxes, and limited state income tax due to our net operating loss carryforwards and other tax attributes.


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001327567-14-000043:notes:89]
Intangible Assets

[0001327567-14-000043:notes:90]
The following table presents details of our purchased intangible assets as of October 31, 2014 and July 31, 2014 (in thousands):

[0001327567-14-000043:notes:91]
|  |  | October 31, 2014 |  | July 31, 2014 |
|  |  | Gross Carrying Amount |  | Accumulated Amortization |  | Net Carrying Amount |  | Gross Carrying Amount |  | Accumulated Amortization |  | Net Carrying Amount |
| Intangible assets with finite lives: |  |  |  |  |  |  |  |  |  |  |  |  |
| Developed technology |  | $ | 42,100 |  |  | $ | (2,965 | ) |  | $ | 39,135 |  |  | $ | 34,500 |  |  | $ | (1,643 | ) |  | $ | 32,857 |  |
| Acquired intellectual property |  | 7,796 |  |  | (1,169 | ) |  | 6,627 |  |  | 6,546 |  |  | (958 | ) |  | 5,588 |  |
| In-process research and development held for defensive purposes |  | 1,900 |  |  | (528 | ) |  | 1,372 |  |  | 1,900 |  |  | (370 | ) |  | 1,530 |  |
| Other |  | 500 |  |  | (183 | ) |  | 317 |  |  | 500 |  |  | (120 | ) |  | 380 |  |
| Total intangible assets with finite lives |  | 52,296 |  |  | (4,845 | ) |  | 47,451 |  |  | 43,446 |  |  | (3,091 | ) |  | 40,355 |  |
| In-process research and development with indefinite lives |  | — |  |  | — |  |  | — |  |  | 7,600 |  |  | — |  |  | 7,600 |  |
| Total purchased intangible assets |  | $ | 52,296 |  |  | $ | (4,845 | ) |  | $ | 47,451 |  |  | $ | 51,046 |  |  | $ | (3,091 | ) |  | $ | 47,955 |  |

[0001327567-14-000043:notes:92]
We recognized amortization expense of $1,754,000 and $155,000 for the three months ended October 31, 2014 and 2013, respectively. Our in-process research and development acquired from Cyvera Ltd. in April 2014 was transferred to developed technology during the three months ended October 31, 2014 and is being amortized over its estimated useful life of seven years.

[0001327567-14-000043:notes:93]
The following table summarizes our estimated future amortization expense of intangible assets with finite lives by type as of October 31, 2014 (in thousands):

[0001327567-14-000043:notes:94]
|  | Fiscal Years Ending July 31, |
|  | Remaining 2015 |  | 2016 |  | 2017 |  | 2018 |  | 2019 |  | 2020 and Thereafter |
| Developed technology | $ | 4,511 |  |  | $ | 6,014 |  |  | $ | 6,014 |  |  | $ | 6,014 |  |  | $ | 6,014 |  |  | $ | 10,568 |  |
| Acquired intellectual property | 644 |  |  | 816 |  |  | 722 |  |  | 596 |  |  | 511 |  |  | 3,338 |  |
| In-process research and development held for defensive purposes | 475 |  |  | 633 |  |  | 264 |  |  | — |  |  | — |  |  | — |  |
| Other | 187 |  |  | 130 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Total future amortization expense | $ | 5,817 |  |  | $ | 7,593 |  |  | $ | 7,000 |  |  | $ | 6,610 |  |  | $ | 6,525 |  |  | $ | 13,906 |  |


## us-gaap:InvestmentsClassifiedByContractualMaturityDateTableTextBlock

[0001327567-14-000043:notes:95]
The following table summarizes the amortized cost and fair value of our investments as of October 31, 2014, by contractual years-to-maturity (in thousands):

[0001327567-14-000043:notes:96]
|  | Amortized Cost |  | Fair Value |
| Due within one year | $ | 227,738 |  |  | $ | 227,752 |  |
| Due within one to two years | 287,530 |  |  | 287,506 |  |
| Due within two to three years | 1,509 |  |  | 1,505 |  |
| Total | $ | 516,777 |  |  | $ | 516,763 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001327567-14-000043:notes:97]
Investments

[0001327567-14-000043:notes:98]
Unrealized losses related to these investments are due to interest rate fluctuations as opposed to credit quality. In addition, we do not intend to sell and it is not more likely than not that we would be required to sell these investments before recovery of their amortized cost basis, which may be at maturity. As a result, there is no other-than-temporary impairment for these investments at October 31, 2014.
