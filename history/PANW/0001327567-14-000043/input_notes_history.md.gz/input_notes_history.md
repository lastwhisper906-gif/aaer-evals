# PANW note change history — 0001327567-14-000013 → 0001327567-14-000043


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2014-11-25):
[0001327567-14-000043:note_history:1]
The following table presents details of the aggregate future non-cancelable minimum rental payments on our operating leases as of October 31, 2014 (in thousands):
  (was, 2014-06-03, similarity 0.9679):
[0001327567-14-000013:note_history:1]
The following table presents details of the aggregate future non-cancelable minimum rental payments on our operating leases as of April 30, 2014 (in thousands):

- changed (2014-11-25):
[0001327567-14-000043:note_history:2]
Our independent contract manufacturer procures components and assembles our products based on our forecasts. These forecasts are based on estimates of demand for our products primarily for the next twelve months, which are in turn based on historical trends and an analysis from our sales and product marketing organizations, adjusted for overall market conditions. In order to reduce manufacturing lead times and plan for adequate supply, we may issue forecasts and orders for components and products that are non-cancelable. Obligations under contracts that we can cancel without a significant penalty are not included. As of October 31, 2014, we had $39,018,000 of open orders.
  (was, 2014-06-03, similarity 0.923):
[0001327567-14-000013:note_history:2]
Our independent contract manufacturer procures components and assembles our products based on our forecasts. These forecasts are based on estimates of future demand for our products, which are in turn based on historical trends and an analysis from our sales and product marketing organizations, adjusted for overall market conditions. In order to reduce manufacturing lead times and plan for adequate supply, we may issue forecasts and orders for components and products that are non-cancelable. Obligations under contracts that we can cancel without a significant penalty are not included. As of April 30, 2014, we had $29,407,000 of open orders.

- added (2014-11-25):
[0001327567-14-000043:note_history:3]
In December 2011, Juniper Networks, Inc. (“Juniper”) filed a complaint against us in the United States District Court for the District of Delaware alleging patent infringement, which sought preliminary and permanent injunctions against infringement, treble damages, and attorneys' fees. On September 30, 2013, we filed a lawsuit against Juniper in the United States District Court for the Northern District of California alleging that Juniper’s products infringe three of our U.S. patents, and sought monetary damages and a permanent injunction.

- added (2014-11-25):
[0001327567-14-000043:note_history:4]
On May 27, 2014, we entered into a Settlement, Release and Cross-License Agreement (the “settlement agreement”) with Juniper to resolve all pending litigation between the parties, including those discussed above. Under the terms of the settlement agreement, we agreed to pay Juniper a one-time settlement amount of approximately $175,000,000, which was comprised of $75,000,000 in cash, 1,081,000 shares of our common stock with an approximate value of $70,000,000, and a warrant to purchase 463,000 shares of our common stock with an approximate value of $30,000,000, in exchange for the following:

- added (2014-11-25):
[0001327567-14-000043:note_history:5]
| • | Mutual dismissal with prejudice of all pending litigation between the parties and general release of all liability for Palo Alto Networks and Juniper, |

- added (2014-11-25):
[0001327567-14-000043:note_history:6]
| • | Cross-license between both parties for the patents-in-suit and associated family members and counterparts worldwide for the life of the patents, and |

- added (2014-11-25):
[0001327567-14-000043:note_history:7]
| • | Mutual covenant not to sue for infringement of any other patents for a period of eight years. |

- added (2014-11-25):
[0001327567-14-000043:note_history:8]
For accounting purposes, the fair value of the total consideration as of the settlement date was $182,473,000, which was comprised of $75,000,000 in cash, $75,231,000 in common stock, and $32,242,000 in warrant. The fair values of the common stock and warrant were measured using the closing price of our common stock on the settlement date.

- added (2014-11-25):
[0001327567-14-000043:note_history:9]
The warrant was issued on June 3, 2014 and entitled Juniper to purchase up to 463,000 shares of common stock at an exercise price of $0.0001 per share and was classified as a liability during the period it was outstanding. On July 1, 2014, Juniper exercised the warrant in full. Accordingly, we recorded the change in the fair value of the warrant liability through the exercise date of $5,859,000 within other income (expense), net in the consolidated statement of operations for the year ended July 31, 2014.

- added (2014-11-25):
[0001327567-14-000043:note_history:10]
We accounted for the settlement agreement as a multiple-element arrangement and allocated the fair value of the consideration as of the settlement date to the identifiable elements based on their estimated fair values. Of the total settlement amount, $61,300,000 was allocated to the licensing of intellectual property, $54,300,000 was allocated to the mutual dismissal of claims, and the remaining amount was allocated to the mutual covenant not to sue. The mutual dismissal of claims and the mutual covenant not to sue have no identifiable future benefit, and as a result we recorded a settlement charge within operating expenses in the consolidated statements of operations for the year ended July 31, 2014. The licensing of intellectual property is being amortized over the estimated period of benefit of five years.

- changed (2014-11-25):
[0001327567-14-000043:note_history:11]
To the extent there is a reasonable possibility that a loss exceeding amounts already recognized may be incurred and the amount of such additional loss would be material, we will either disclose the estimated additional loss or state that such an estimate cannot be made. As of October 31, 2014, we have not recorded any accrual for loss contingencies associated with such legal proceedings, determined that an unfavorable outcome is probable or reasonably possible, or determined that the amount or range of any possible loss is reasonably estimable.
  (was, 2014-06-03, similarity 0.6642):
[0001327567-14-000013:note_history:11]
To the extent there is a reasonable possibility that a loss exceeding amounts already recognized may be incurred and the amount of such additional loss would be material, we will either disclose the estimated additional loss or state that such an estimate cannot be made.

- removed (2014-11-25):
[0001327567-14-000013:note_history:12]
In December 2011, Juniper Networks, Inc. ("Juniper") filed a complaint against us in the United States District Court for the District of Delaware alleging patent infringement. The complaint sought preliminary and permanent injunctions against infringement, treble damages, and attorneys' fees. On September 4, 2012, Juniper filed a motion to amend its complaint to allege that our appliances infringe two additional U.S. patents but also to withdraw its allegations as to a previously-asserted patent. This amended complaint was officially filed on September 25, 2012, pursuant to a stipulation between the parties. On October 12, 2012, we filed an answer to Juniper’s amended complaint, which denied that we infringed Juniper’s patents and asserted that Juniper’s patents were invalid. The Court issued an order on February 6, 2014, in which the Court construed several disputed claim limitations, granted Juniper’s motion for summary judgment of assignor estoppel, precluding us from raising in the litigation challenges to the validity of Juniper’s patents, denied Juniper’s motion for summary judgment of infringement, and granted in part and denied in part our motion for summary judgment of non-infringement. A trial took place in February 2014. Following the trial, the jury was unable to reach a verdict and the Court declared a mistrial.

- removed (2014-11-25):
[0001327567-14-000013:note_history:13]
On September 13, 2012, we filed with the U.S. Patent and Trademark Office requests for inter partes reexamination of five of the six patents asserted by Juniper in its original complaint. On October 19 and December 3, 2012, the U.S. Patent and Trademark Office granted our requests for reexamination for three patents, rejecting a number of the claims asserted in the litigation, and on November 15 and 26, 2012, the U.S. Patent and Trademark Office denied our requests for reexamination as to two other patents. On June 20, 2013 and July 23, 2013, we filed with the U.S. Patent and Trademark Office petitions for inter partes review for two other patents asserted by Juniper in the litigation. A hearing to resolve claim construction issues, as well as motions for summary judgment, was heard on November 15, 2013.

- removed (2014-11-25):
[0001327567-14-000013:note_history:14]
On September 30, 2013, we filed a lawsuit against Juniper in the United States District Court for the Northern District of California. The lawsuit alleged that Juniper’s products infringe three of our U.S. patents, and sought monetary damages and a permanent injunction. On November 21, 2013, Juniper filed an answer and counterclaims in a separate action in the United States District Court for the Northern District of California. In its counterclaims Juniper sought a declaration that the asserted patents owned by us are not infringed and are invalid. Juniper’s counterclaims also asserted that our products infringe three additional Juniper patents.

- removed (2014-11-25):
[0001327567-14-000013:note_history:15]
On May 27, 2014, we entered into a Settlement, Release and Cross-License Agreement (the “settlement agreement”) with Juniper to resolve all pending litigation between the parties, including those discussed above. Refer to Note 12 Subsequent Events for more information on the settlement agreement.


## us-gaap:LegalMattersAndContingenciesTextBlock (contingencies) — matched_by: no_current_note, score: 0.0

- removed (2014-11-25):
[0001327567-14-000013:note_history:16]
On January 27, 2014, we executed a Mutual Covenant Not to Sue and Release Agreement with Fortinet, Inc., thereby extending an existing covenant for six more years. We evaluated the transaction as a multiple-element arrangement and allocated the one-time payment that we made in the amount of $20,000,000 to each identifiable element using its relative fair value. Based on our estimates of fair value, we determined that the primary benefit of the arrangement is avoided litigation cost and the release of any potential past claims, with no material value attributable to future use or benefit. Accordingly, we recorded a $20,000,000 settlement charge within operating expenses during the three months ended January 31, 2014.


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2014-11-25):
[0001327567-14-000043:note_history:17]
Palo Alto Networks, Inc. (the “Company,” “we,” “us,” or “our”), located in Santa Clara, California, was incorporated in March 2005 under the laws of the State of Delaware and commenced operations in April 2005. We offer a next-generation enterprise security platform that allows enterprises, service providers, and government entities to simultaneously empower and secure their organizations by safely enabling the increasingly complex and rapidly growing number of applications running on their networks and by preventing breaches stemming from targeted cyber attacks.

- added (2014-11-25):
[0001327567-14-000043:note_history:18]
Our enterprise security platform consists of three major elements: our Next-Generation Firewall, our Advanced Endpoint Protection, and our Threat Intelligence Cloud. Our Next-Generation Firewall delivers application, user, and content visibility and control as well as protection against network-based cyber threats integrated within the firewall through our proprietary hardware and software architecture. Our Advanced Endpoint Protection prevents cyber attacks that aim to exploit software vulnerabilities on a broad variety of fixed and virtual endpoints. Our Threat Intelligence Cloud provides central intelligence capabilities as well as automated delivery of preventative measures against cyber attacks. The cloud-based element of our platform is delivered in the form of a service that can be used either in the public cloud or in a private cloud using a dedicated appliance.

- added (2014-11-25):
[0001327567-14-000043:note_history:19]
We primarily sell our products and services to end-customers through our channel partners and infrequently directly to end-customers. Our partners are supported by our sales and marketing organization in the Americas, in Europe, the Middle East, and Africa (EMEA), and in Asia Pacific and Japan (APAC).

- changed (2014-11-25):
[0001327567-14-000043:note_history:20]
There have been no material changes to our significant accounting policies as of and for the three months ended October 31, 2014, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended July 31, 2014.
  (was, 2014-06-03, similarity 0.6228):
[0001327567-14-000013:note_history:20]
There have been no material changes to our significant accounting policies as of and for the three and nine months ended April 30, 2014, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended July 31, 2013, except for the inclusion of a policy related to business combinations, amortization of intangible assets, and broadening our policy on the Impairment of Long-Lived Assets to include policies related to goodwill and intangible assets.

- added (2014-11-25):
[0001327567-14-000043:note_history:21]
In August 2014, the Financial Accounting Standards Board (FASB) issued Accounting Standards Update (ASU) No. 2014-15, Presentation of Financial Statements-Going Concern (Subtopic 205-40)-Disclosure of Uncertainties about an Entity’s Ability to Continue as a Going Concern. The standard provides guidance about management's responsibility to evaluate whether there is substantial doubt about an entity's ability to continue as a going concern and to provide related footnote disclosures. The standard is effective for fiscal years ending after December 15, 2016, and for interim periods thereafter. Early adoption is permitted. We will adopt the new standard in our fiscal year ending 2017. The adoption of this standard is not expected to have a material impact on our condensed consolidated financial statements.

- added (2014-11-25):
[0001327567-14-000043:note_history:22]
In May 2014, the FASB issued ASU No. 2014-09 regarding Accounting Standards Codification (ASC) Topic 606-Revenue from Contracts with Customers. The standard provides principles for recognizing revenue for the transfer of promised goods or services to customers with the consideration to which the entity expects to be entitled in exchange for those goods or services. The guidance is effective for us in the first quarter of fiscal 2018 using either of two methods: (i) retrospective to each prior reporting period presented with the option to elect certain practical expedients as defined within the guidance; or (ii) retrospective with the cumulative effect of initially applying the guidance recognized at the date of initial application and providing certain additional disclosures as defined per the guidance. Early adoption is not permitted. We are currently evaluating adoption methods and whether this standard will have a material impact on our condensed consolidated financial statements.

- changed (2014-11-25):
[0001327567-14-000043:note_history:23]
In July 2013, the FASB issued ASU No. 2013-11, Income Taxes (Topic 740)-Presentation of an Unrecognized Tax Benefit When a Net Operating Loss Carryforward, a Similar Tax Loss, or a Tax Credit Carryforward Exists. The standard requires us to present an unrecognized tax benefit as a reduction of a deferred tax asset for a net operating loss (NOL) carryforward or other tax credit carryforward when settlement in this manner is available under applicable tax law. The guidance was effective for us in the first quarter of fiscal 2015. Our adoption of this guidance did not have any impact on our condensed consolidated financial statements.
  (was, 2014-06-03, similarity 0.8372):
[0001327567-14-000013:note_history:23]
In July 2013, the FASB issued ASU No. 2013-11, Income Taxes (Topic 740)-Presentation of an Unrecognized Tax Benefit When a Net Operating Loss Carryforward, a Similar Tax Loss, or a Tax Credit Carryforward Exists. The standard requires us to present an unrecognized tax benefit as a reduction of a deferred tax asset for a net operating loss (NOL) carryforward or other tax credit carryforward when settlement in this manner is available under applicable tax law. The guidance is effective for us in the first quarter of fiscal 2015 and will be applied prospectively. Early adoption is permitted. We do not believe the adoption of this guidance will have a material impact on our condensed consolidated financial statements.

- removed (2014-11-25):
[0001327567-14-000013:note_history:24]
Palo Alto Networks, Inc. (the “Company,” “we,” “us,” or “our”), located in Santa Clara, California, was incorporated in March 2005 under the laws of the State of Delaware and commenced operations in April 2005. We offer a next-generation enterprise security platform that allows enterprises, service providers, and government entities to simultaneously empower and secure their organization by safely enabling the increasingly complex and rapidly growing number of applications running on their networks and preventing breaches stemming from targeted cyber attacks. Our enterprise security platform consists of three major elements: our Next-Generation Firewall, our Next-Generation Endpoint Protection, and our Next-Generation Threat Intelligence Cloud. Our Next-Generation Firewall delivers application, user, and content visibility and control as well as protection against network based cyber threats integrated within the firewall through our proprietary hardware and software architecture. Our Next-Generation Endpoint Protection protects against cyber attacks that aim to exploit software vulnerabilities on a broad variety of fixed and virtual endpoints. Our Next-Generation Threat Intelligence Cloud provides central intelligence capabilities as well as automation of delivery of preventative measures against cyber attacks. We primarily sell our products and services to end-customers through our channel partners and infrequently directly to end-customers. Our partners are supported by our sales and marketing organization in the Americas, in Europe, the Middle East, and Africa (EMEA), and in Asia Pacific and Japan (APAC).

- removed (2014-11-25):
[0001327567-14-000013:note_history:25]
Business Combinations

- removed (2014-11-25):
[0001327567-14-000013:note_history:26]
We include the results of operations of the businesses that we acquire as of the respective dates of acquisition. We allocate the fair value of the purchase price of our acquisitions to the tangible assets acquired, liabilities assumed, and intangible assets acquired, based on their estimated fair values. The excess of the purchase price over the fair values of these identifiable assets and liabilities is recorded as goodwill. Additional information existing as of the acquisition date but unknown to us may become known during the remainder of the measurement period, not to exceed 12 months from the acquisition date, which may result in changes to the amounts and allocations recorded.

- removed (2014-11-25):
[0001327567-14-000013:note_history:27]
Amortization of Intangible Assets

- removed (2014-11-25):
[0001327567-14-000013:note_history:28]
Purchased intangible assets with finite lives are carried at cost, less accumulated amortization. Amortization is computed over the estimated useful lives of the respective assets. Acquisition-related in-process research and development represents the fair value of incomplete research and development projects that have not reached technological feasibility as of the date of acquisition. Initially, these assets are not subject to amortization. Assets related to projects that have been completed are transferred to developed technology, which are subject to amortization, while assets related to projects that have been abandoned are impaired and expensed to research and development.

- removed (2014-11-25):
[0001327567-14-000013:note_history:29]
Impairment of Goodwill, Intangible Assets, and Long-Lived Assets

- removed (2014-11-25):
[0001327567-14-000013:note_history:30]
Goodwill is evaluated for impairment on an annual basis in the fourth quarter of our fiscal year, and whenever events or changes in circumstances indicate the carrying amount of goodwill may not be recoverable. We have elected to first assess qualitative factors to determine whether it is more likely than not that the fair value of our single reporting unit is less than its carrying amount. If we determine that it is more likely than not that the fair value of our single reporting unit is less than its carrying amount, then the two-step goodwill impairment test will be performed. The first step, identifying a potential impairment, compares the fair value of our single reporting unit with its carrying amount. If the carrying amount exceeds its fair value, the second step will be performed; otherwise, no further step is required. The second step, measuring the impairment loss, compares the implied fair value of the goodwill with the carrying amount of the goodwill. Any excess of the goodwill carrying amount over the implied fair value is recognized as an impairment loss.

- removed (2014-11-25):
[0001327567-14-000013:note_history:31]
We evaluate events and changes in circumstances that could indicate carrying amounts of purchased intangible assets and long-lived assets may not be recoverable. When such events or changes in circumstances occur, we assess the recoverability of these assets by determining whether or not the carrying amount will be recovered through undiscounted expected future cash flows. If the total of the future undiscounted cash flows is less than the carrying amount of an asset, we record an impairment loss for the amount by which the carrying amount of the asset exceeds the fair value of the asset.

- removed (2014-11-25):
[0001327567-14-000013:note_history:32]
In February 2013, the FASB issued Accounting Standards Update No. 2013-02, Comprehensive Income (Topic 220)-Reporting of Amounts Reclassified Out of Accumulated Other Comprehensive Income. The standard requires entities to present (either on the face of the income statement or in the notes) the effects on the line items of the income statement for amounts reclassified out of accumulated other comprehensive income. The guidance was effective for us in the first quarter of fiscal 2014. Our adoption of this guidance did not impact our financial statements as the guidance is related to disclosure only and we did not have significant reclassifications out of accumulated other comprehensive income.


## us-gaap:ConvertibleDebtTableTextBlock (debt) — matched_by: no_prior_note, score: 0.0

- added (2014-11-25):
[0001327567-14-000043:note_history:33]
The following table sets forth the components of the Notes as of October 31, 2014 and July 31, 2014 (in thousands):

- added (2014-11-25):
[0001327567-14-000043:note_history:34]
|  | October 31, 2014 |  | July 31, 2014 |
| Liability: |  |  |  |
| Principal | $ | 575,000 |  |  | $ | 575,000 |  |
| Less: debt discount, net of amortization | 103,144 |  |  | 108,125 |  |
| Net carrying amount | $ | 471,856 |  |  | $ | 466,875 |  |
| Equity | $ | (109,785 | ) |  | $ | (109,785 | ) |


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: no_prior_note, score: 0.0

- added (2014-11-25):
[0001327567-14-000043:note_history:35]
Convertible Senior Notes

- added (2014-11-25):
[0001327567-14-000043:note_history:36]
Convertible Senior Notes

- added (2014-11-25):
[0001327567-14-000043:note_history:37]
On June 30, 2014, we issued $575,000,000 aggregate principal amount of 0.0% convertible senior notes due 2019 (the “Notes”). The Notes are governed by an indenture between us, as the issuer, and U.S. Bank National Association, as Trustee. The Notes are unsecured, unsubordinated obligations that do not contain any financial covenants or restrictions on the payments of dividends, the incurrence of indebtedness, or the issuance or repurchase of securities by us or any of our subsidiaries. The Notes mature on July 1, 2019 unless converted or repurchased in accordance with their terms prior to such date. We cannot redeem the Notes prior to maturity.

- added (2014-11-25):
[0001327567-14-000043:note_history:38]
The Notes are convertible for up to 5,214,000 shares of our common stock at an initial conversion rate of approximately 9.068 shares of common stock per $1,000 principal amount, which is equal to an initial conversion price of approximately $110.28 per share of common stock, subject to adjustment. Holders of the Notes may surrender their Notes for conversion at their option at any time prior to the close of business on the business day immediately preceding January 1, 2019, only under the following circumstances, none of which have occurred to date:

- added (2014-11-25):
[0001327567-14-000043:note_history:39]
| • | during any fiscal quarter commencing after the fiscal quarter ending on October 31, 2014 (and only during such fiscal quarter), if the last reported sale price of our common stock for at least 20 trading days (whether or not consecutive) during a period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the conversion price for the Notes on each applicable trading day; |

- added (2014-11-25):
[0001327567-14-000043:note_history:40]
| • | during the five business day period after any five consecutive trading day period (the “measurement period”), in which the trading price per $1,000 principal amount of Notes for each trading day of the measurement period was less than 98% of the product of the last reported sale price of our common stock and the conversion rate for the Notes on each such trading day; or |

- added (2014-11-25):
[0001327567-14-000043:note_history:41]
| • | upon the occurrence of specified corporate events. |

- added (2014-11-25):
[0001327567-14-000043:note_history:42]
On or after January 1, 2019, holders may convert all or any portion of their Notes at any time prior to the close of business on the second scheduled trading day immediately preceding the maturity date regardless of the foregoing conditions. Upon conversion, holders will receive cash equal to the aggregate principal amount of the Notes to be converted, and, at our election, cash and/or shares of our common stock for any amounts in excess of the aggregate principal amount of the Notes being converted.

- added (2014-11-25):
[0001327567-14-000043:note_history:43]
The conversion price will be subject to adjustment in some events. Holders of the Notes who convert their Notes in connection with certain corporate events that constitute a “make-whole fundamental change” per the Indenture governing the Notes are, under certain circumstances, entitled to an increase in the conversion rate. Additionally, upon the occurrence of a corporate event that constitutes a “fundamental change” per the Indenture governing the Notes, holders of the Notes may require us to repurchase for cash all or a portion of the Notes at a purchase price equal to 100% of the principal amount of the Notes plus accrued and unpaid contingent interest.

- added (2014-11-25):
[0001327567-14-000043:note_history:44]
In accounting for the issuance of the Notes, we separated the Notes into liability and equity components. The carrying amount of the liability component was calculated by measuring the fair value of a similar liability that does not have an associated convertible feature. The carrying amount of the equity component representing the conversion option was determined by deducting the fair value of the liability component from the par value of the Notes as a whole. The difference between the principal amount of the Notes and the liability component (the “debt discount”), is amortized to interest expense using the effective interest method over the term of the Notes. The equity component of the Notes is included in additional paid-in capital in the condensed consolidated balance sheets and is not remeasured as long as it continues to meet the conditions for equity classification.

- added (2014-11-25):
[0001327567-14-000043:note_history:45]
In accounting for the transaction costs related to the issuance of the Notes, we allocated the total amount incurred to the liability and equity components using the same proportions as the proceeds from the Notes. Transaction costs attributable to the liability component were recorded in other assets in the condensed consolidated balance sheets and are being amortized to interest expense in the condensed consolidated statements of operations using the effective interest method over the term of the Notes. Transaction costs attributable to the equity component were netted with the equity component of the Notes in additional paid-in capital in the condensed consolidated balance sheets. We recorded liability issuance costs, or debt issuance costs, of $12,497,000 and equity issuance costs of $2,949,000.

- added (2014-11-25):
[0001327567-14-000043:note_history:46]
The following table sets forth the components of the Notes as of October 31, 2014 and July 31, 2014 (in thousands):

- added (2014-11-25):
[0001327567-14-000043:note_history:47]
|  | October 31, 2014 |  | July 31, 2014 |
| Liability: |  |  |  |
| Principal | $ | 575,000 |  |  | $ | 575,000 |  |
| Less: debt discount, net of amortization | 103,144 |  |  | 108,125 |  |
| Net carrying amount | $ | 471,856 |  |  | $ | 466,875 |  |
| Equity | $ | (109,785 | ) |  | $ | (109,785 | ) |

- added (2014-11-25):
[0001327567-14-000043:note_history:48]
The total estimated fair value of the Notes was $677,856,000 and $587,087,000 at October 31, 2014 and July 31, 2014, respectively. The fair value was determined based on the closing trading price per $100 of the Notes as of the last day of trading for the period. We consider the fair value of the Notes at October 31, 2014 and July 31, 2014 to be a Level 2 measurement. The fair value of the Notes is primarily affected by the trading price of our common stock and market interest rates. Based on the closing price of our common stock of $105.70 on October 31, 2014, the if-converted value of the Notes was less than its principal amount.

- added (2014-11-25):
[0001327567-14-000043:note_history:49]
The following table sets forth interest expense recognized related to the Notes for the three months ended October 31, 2014 (dollars in thousands):

- added (2014-11-25):
[0001327567-14-000043:note_history:50]
|  | Amount |
| Amortization of debt issuance costs | $ | 497 |  |
| Amortization of debt discount | 4,981 |  |
| Total interest expense recognized | $ | 5,478 |  |
| Effective interest rate of the liability component | 4.8 | % |

- added (2014-11-25):
[0001327567-14-000043:note_history:51]
Note Hedges

- added (2014-11-25):
[0001327567-14-000043:note_history:52]
To minimize the impact of potential economic dilution upon conversion of the Notes, we entered into convertible note hedge transactions (the “Note Hedges”) with respect to our common stock concurrent with the issuance of the Notes. The Note Hedges cover up to 5,214,000 shares of our common stock at a strike price per share that corresponds to the initial conversion price of the Notes, which are also subject to adjustment, and are exercisable upon conversion of the Notes. The Note Hedges will expire upon maturity of the Notes. The Note Hedges are separate transactions and are not part of the terms of the Notes. Holders of the Notes will not have any rights with respect to the Note Hedges. The shares receivable related to the Note Hedges are excluded from the calculation of diluted earnings per share as they are antidilutive.

- added (2014-11-25):
[0001327567-14-000043:note_history:53]
We paid an aggregate amount of $110,975,000 for the Note Hedges, which is included in additional paid-in capital in the condensed consolidated balance sheets.

- added (2014-11-25):
[0001327567-14-000043:note_history:54]
Warrants

- added (2014-11-25):
[0001327567-14-000043:note_history:55]
Separately, but concurrently with our issuance of the Notes, we entered into warrant transactions (the “Warrants”) whereby we sold warrants to acquire up to 5,214,000 shares of our common stock at a strike price of approximately $137.85 per share, subject to adjustments. The shares issuable under the Warrants will be included in the calculation of diluted earnings per share when the average market value per share of our common stock for the reporting period exceeds the strike price of the Warrants. The Warrants are separate transactions and are not part of the Notes or Notes Hedges, and are not remeasured through earnings each reporting period. Holders of the Notes and Note Hedges will not have any rights with respect to the Warrants.

- added (2014-11-25):
[0001327567-14-000043:note_history:56]
We received aggregate proceeds of $78,258,000 from the sale of the Warrants, which is included in additional paid-in capital in the condensed consolidated balance sheets.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2014-11-25):
[0001327567-14-000043:note_history:57]
The following tables summarize the unrealized gains and losses and fair value of our investments as of October 31, 2014 and July 31, 2014 (in thousands):
  (was, 2014-06-03, similarity 0.9286):
[0001327567-14-000013:note_history:57]
The following tables summarize our unrealized gains and losses and fair value of investments as of April 30, 2014 and July 31, 2013 (in thousands):

- added (2014-11-25):
[0001327567-14-000043:note_history:58]
|  | October 31, 2014 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Estimated Fair Value |
| Certificates of deposit | $ | 1,000 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,000 |  |
| Corporate debt securities | 102,797 |  |  | 18 |  |  | (85 | ) |  | 102,730 |  |
| U.S. government and agency securities | 412,980 |  |  | 172 |  |  | (119 | ) |  | 413,033 |  |
| Total | $ | 516,777 |  |  | $ | 190 |  |  | $ | (204 | ) |  | $ | 516,763 |  |

- changed (2014-11-25):
[0001327567-14-000043:note_history:59]
|  | July 31, 2014 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Estimated Fair Value |
| Certificates of deposit | $ | 1,000 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,000 |  |
| Corporate debt securities | 61,299 |  |  | 16 |  |  | (58 | ) |  | 61,257 |  |
| U.S. government and agency securities | 258,376 |  |  | 45 |  |  | (108 | ) |  | 258,313 |  |
| Total | $ | 320,675 |  |  | $ | 61 |  |  | $ | (166 | ) |  | $ | 320,570 |  |
  (was, 2014-06-03, similarity 0.9338):
[0001327567-14-000013:note_history:59]
|  | July 31, 2013 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Estimated Fair Value |
| Certificates of deposit | $ | 1,822 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,822 |  |
| Corporate debt securities | 45,173 |  |  | 12 |  |  | (34 | ) |  | 45,151 |  |
| U.S. government and agency securities | 127,864 |  |  | 8 |  |  | (2 | ) |  | 127,870 |  |
| Money market funds | 131,845 |  |  | — |  |  | — |  |  | 131,845 |  |
| Total | $ | 306,704 |  |  | $ | 20 |  |  | $ | (36 | ) |  | $ | 306,688 |  |

- changed (2014-11-25):
[0001327567-14-000043:note_history:60]
The following tables present our investments that were in an unrealized loss position as of October 31, 2014 and July 31, 2014 (in thousands):
  (was, 2014-06-03, similarity 0.9618):
[0001327567-14-000013:note_history:60]
The following tables present our investments that were in an unrealized loss position as of April 30, 2014 and July 31, 2013 (in thousands):

- added (2014-11-25):
[0001327567-14-000043:note_history:61]
|  | October 31, 2014 |
|  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
|  | Fair Value |  | Unrealized Loss |  | Fair Value |  | Unrealized Loss |  | Fair Value |  | Unrealized Loss |
| Corporate debt securities | $ | 72,352 |  |  | $ | (85 | ) |  | $ | — |  |  | $ | — |  |  | $ | 72,352 |  |  | $ | (85 | ) |
| U.S. government and agency securities | 185,151 |  |  | (119 | ) |  | — |  |  | — |  |  | 185,151 |  |  | (119 | ) |
| Total | $ | 257,503 |  |  | $ | (204 | ) |  | $ | — |  |  | $ | — |  |  | $ | 257,503 |  |  | $ | (204 | ) |

- changed (2014-11-25):
[0001327567-14-000043:note_history:62]
Unrealized losses related to these investments are due to interest rate fluctuations as opposed to credit quality. In addition, we do not intend to sell and it is not more likely than not that we would be required to sell these investments before recovery of their amortized cost basis, which may be at maturity. As a result, there is no other-than-temporary impairment for these investments at October 31, 2014.
  (was, 2014-06-03, similarity 0.9852):
[0001327567-14-000013:note_history:62]
Unrealized losses related to these investments are due to interest rate fluctuations as opposed to credit quality. In addition, we do not intend to sell and it is not more likely than not that we would be required to sell these investments before recovery of their amortized cost basis, which may be at maturity. As a result, there is no other-than-temporary impairment for these investments at April 30, 2014.

- changed (2014-11-25):
[0001327567-14-000043:note_history:63]
The following table summarizes the amortized cost and fair value of our investments as of October 31, 2014, by contractual years-to-maturity (in thousands):
  (was, 2014-06-03, similarity 0.9664):
[0001327567-14-000013:note_history:63]
The following table summarizes the amortized cost and fair value of our investments as of April 30, 2014, by contractual years-to-maturity (in thousands):

- changed (2014-11-25):
[0001327567-14-000043:note_history:64]
|  | Amortized Cost |  | Fair Value |
| Due within one year | $ | 227,738 |  |  | $ | 227,752 |  |
| Due within one to two years | 287,530 |  |  | 287,506 |  |
| Due within two to three years | 1,509 |  |  | 1,505 |  |
| Total | $ | 516,777 |  |  | $ | 516,763 |  |
  (was, 2014-06-03, similarity 0.8689):
[0001327567-14-000013:note_history:64]
|  | Amortized Cost |  | Fair Value |
| Due within one year | $ | 137,154 |  |  | $ | 137,180 |  |
| Due within one to two years | 103,867 |  |  | 103,902 |  |
| Total | $ | 241,021 |  |  | $ | 241,082 |  |

- removed (2014-11-25):
[0001327567-14-000013:note_history:65]
|  | April 30, 2014 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Estimated Fair Value |
| Certificates of deposit | $ | 3,000 |  |  | $ | 1 |  |  | $ | — |  |  | $ | 3,001 |  |
| Corporate debt securities | 45,957 |  |  | 22 |  |  | (6 | ) |  | 45,973 |  |
| U.S. government and agency securities | 192,064 |  |  | 68 |  |  | (24 | ) |  | 192,108 |  |
| Total | $ | 241,021 |  |  | $ | 91 |  |  | $ | (30 | ) |  | $ | 241,082 |  |

- removed (2014-11-25):
[0001327567-14-000013:note_history:66]
|  | April 30, 2014 |
|  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
|  | Fair Value |  | Unrealized Loss |  | Fair Value |  | Unrealized Loss |  | Fair Value |  | Unrealized Loss |
| Corporate debt securities | 16,766 |  |  | (6 | ) |  | — |  |  | — |  |  | 16,766 |  |  | (6 | ) |
| U.S. government and agency securities | 33,601 |  |  | (24 | ) |  | — |  |  | — |  |  | 33,601 |  |  | (24 | ) |
| Total | $ | 50,367 |  |  | $ | (30 | ) |  | $ | — |  |  | $ | — |  |  | $ | 50,367 |  |  | $ | (30 | ) |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: no_current_note, score: 0.0

- removed (2014-11-25):
[0001327567-14-000013:note_history:67]
Related Party Transactions

- removed (2014-11-25):
[0001327567-14-000013:note_history:68]
Certain members of our board of directors serve as board members or executive officers of certain of our customers and in some cases are also investors of these customers. We believe these transactions with related party customers are carried out on terms that are consistent with similar transactions with our comparable customers. We had sales transactions with significant related party customers of $1,619,000 and $3,776,000 for the three and nine months ended April 30, 2014, respectively, and $903,000 and $2,381,000 for the three and nine months ended April 30, 2013, respectively. Amounts payable to and due from related party customers were not material at April 30, 2014.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_current_note, score: 0.0

- removed (2014-11-25):
[0001327567-14-000013:note_history:69]
Subsequent Events

- removed (2014-11-25):
[0001327567-14-000013:note_history:70]
On May 27, 2014, we entered into a Settlement, Release and Cross-License Agreement with Juniper, whereby we resolved all pending litigation matters. Under the terms of the settlement agreement, we agreed to pay Juniper a one-time settlement amount of approximately $175,000,000, which was comprised of $75,000,000 in cash, 1,081,000 shares of our common stock with an approximate value of $70,000,000, and a warrant to purchase 463,000 shares of our common stock with an approximate value of $30,000,000, in exchange for the following:

- removed (2014-11-25):
[0001327567-14-000013:note_history:71]
| • | Mutual dismissal with prejudice of all pending litigation between the parties and general release of all liability for Palo Alto Networks and Juniper, |

- removed (2014-11-25):
[0001327567-14-000013:note_history:72]
| • | Cross-license between both parties for the patents-in-suit and associated family members and counterparts worldwide for the life of the patents, and |

- removed (2014-11-25):
[0001327567-14-000013:note_history:73]
| • | Mutual covenant not to sue for infringement of any other patents for a period of eight years. |

- removed (2014-11-25):
[0001327567-14-000013:note_history:74]
For accounting purposes, the fair value of the total consideration as of the settlement date was $182,473,000 . The fair values of the common stock and warrant were measured using the closing price of our common stock on the settlement date.

- removed (2014-11-25):
[0001327567-14-000013:note_history:75]
We accounted for the settlement agreement as a multiple element arrangement and allocated the fair value of the consideration as of the settlement date to the identifiable elements based on their estimated fair values. Of the total settlement amount, $61,300,000 was allocated to the licensing of intellectual property, $54,300,000 was allocated to the mutual dismissal of claims, and the remaining amount was allocated to the mutual covenant not to sue. The mutual dismissal of claims and the covenant not to sue have no identifiable future benefit, and as a result we accrued a settlement charge within operating expenses as of and for the three and nine months ended April 30, 2014. The licensing of intellectual property will be recorded in our fiscal fourth quarter and will be amortized over the estimated period of benefit of five years.

- removed (2014-11-25):
[0001327567-14-000013:note_history:76]
The warrant entitles Juniper to purchase up to 463,000 shares of common stock at an exercise price of $0.0001 per share and will expire seven months from the date of its issuance. Once issued, the liability-classified warrant will be remeasured through earnings at the end of each reporting period until exercised. The amount of future remeasurement is undeterminable and will be driven predominantly by increases or decreases in our stock price.
