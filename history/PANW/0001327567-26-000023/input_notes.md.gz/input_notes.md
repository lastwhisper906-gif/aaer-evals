# PANW notes — 0001327567-26-000023


## dei:DocumentsIncorporatedByReferenceTextBlock

[0001327567-26-000023:notes:1]
Portions of the information called for by Part III of this Annual Report on Form 10-K is hereby incorporated by reference from the definitive proxy statement for the registrant’s 2026 annual meeting of stockholders, which will be filed with the Securities and Exchange Commission not later than 120 days after the registrant’s fiscal year ended July 31, 2026.


## cyd:CybersecurityRiskManagementProcessesForAssessingIdentifyingAndManagingThreatsTextBlock

[0001327567-26-000023:notes:2]
Our cybersecurity risk management program includes written policies, standards, and procedures for maintaining data privacy, product security and information security to mitigate cybersecurity risks, and to identify, evaluate and respond to cybersecurity threats, vulnerabilities and incidents. Our cybersecurity risk management program and strategy is implemented across several areas, which include, but are not limited to, the following:

[0001327567-26-000023:notes:3]
•Information Security. We maintain a written information security program, which provides for policies, standards, guidelines, and administrative, technical and physical safeguards that we believe are reasonably designed, in light of the nature, size and complexity of our operations, to protect the resiliency of our operations and the confidentiality, integrity, and availability of our information systems and information. The organizational, administrative and technical measures we implement are guided by recognized security frameworks established by the National Institute of Standards and Technology, the ISO/IEC 27000 series of standards, and other generally recognized industry standards. The program is assessed regularly and in light of new and emerging cybersecurity risks.

[0001327567-26-000023:notes:4]
•Technical Safeguards and Product Security. We deploy and maintain a variety of technologies to detect and manage cybersecurity threats across the network, endpoint and cloud, as well as leverage Unit 42 to assess our internal security posture. We also apply security-by-design principles in our software development lifecycle, track vulnerabilities of open-source software, and run regular internal and external network scans. We conduct regular application security assessments, including our assessments for internet-facing applications that collect, transmit, or display end user data. We also employ tooling in certain areas to help prevent deviations from policy.

[0001327567-26-000023:notes:5]
•Incident Response and Reporting. We maintain incident response and recovery protocols to enable prompt, effective and orderly identification, evaluation, management, and disposition of actual and potential security threats and incidents, including for purposes of escalation and internal and external-notification steps. We maintain a cross-functional incident response team, including senior representatives from information security, information technology, product, legal, privacy, communications, and finance, that is involved in assessing cybersecurity threats and incidents, assigning severity levels, and evaluating the potential impact, including the potential impact on our business strategy, results of operations and financial condition. Additionally, we utilize Unit 42 to support our response to threats. This allows for prompt direction of appropriate personnel and resources for incident management and response, and internal notification to appropriate members of management, which may include our chief executive officer, chief product and technology officer, chief information security officer, general counsel, chief financial officer, and/or chief accounting officer, and the security committee of our board of directors (the “Security Committee”).

[0001327567-26-000023:notes:6]
•Third-Party Risk Management. We maintain a risk-based approach to identifying and overseeing cybersecurity risks presented by certain third parties, including vendors, service providers, suppliers, operations parties, and other external users of our systems, as well as the systems of third parties that are important to our operations and/or process sensitive information on our behalf. This includes a security process to conduct due diligence prior to engaging contractors and vendors and assess the security capabilities of subcontractors and vendors on a periodic basis based on our assessment of each third party’s operational criticality and risk profile. In addition, we maintain a security program designed to protect the security and integrity of our hardware products and data throughout the product design, development, manufacturing, delivery, and service and repair processes, which includes consideration of applicable supply chain risk management standards.

[0001327567-26-000023:notes:7]
•Risk and Readiness Assessments. We engage in at least quarterly assessments and testing of the effectiveness of our cybersecurity risk management program and incident response protocols that are designed to identify and evaluate vulnerabilities and weaknesses, address cybersecurity threats and test our readiness to respond to cybersecurity incidents. These efforts include, but are not limited to, threat modeling, vulnerability scans, penetration testing, audits, and/or tabletop exercises. We regularly engage third parties to perform assessments on our cybersecurity measures, such as audits and independent reviews of our compliance with various security compliance standards, including those established by the American Institute of Certified Public Accountants, operating effectiveness and penetration tests. The results of such assessments are reported to management and we adjust our cybersecurity policies, standards, processes and practices as necessary based on the information provided by these assessments, audits and reviews.

[0001327567-26-000023:notes:8]
•Awareness and Training. We provide regular training for educating employees about corporate policies and procedures and information security designed to provide our employees with knowledge of best practices and effective tools for safeguarding our data and assets and reducing security risks based on the human threat vector. Employees are also trained on the responsible use of AI and on the secure use of AI through regular trainings. We also deliver experiential training, including by periodically conducting simulated phishing exercises to test employee awareness and compliance with our security policies.

[0001327567-26-000023:notes:9]
•Governance. As discussed in more detail below under the heading, “Cybersecurity Governance,” our board of directors has delegated oversight of enterprise security risk management, including, but not limited to, cybersecurity risk management to the Security Committee. As part of our cybersecurity risk management procedures, senior members of management and the Security Committee are informed regarding security events based on established reporting thresholds, and are provided ongoing updates regarding any such meaningful threat or incident.
As a global cybersecurity provider, we recognize that we may be a particularly attractive target for sophisticated threat actors. We have not identified any risks from cybersecurity threats, including as a result of any previous cybersecurity incidents, that have materially impacted or are reasonably likely to materially impact us, including our business strategy, results of operations, or financial condition, to date. However, we face ongoing and increasing cybersecurity risks, including from threat actors that are becoming more sophisticated and effective over time, and we can provide no assurance that there will not be incidents in the future or that past or future threats or incidents will not materially affect us, including our business strategy, results of operations, or financial conditions. Despite our efforts, we cannot eliminate all risks from cybersecurity threats or provide assurances that we have not experienced an undetected cybersecurity incident. For additional information regarding these risks, please refer to Part I, Item 1A, “Risk Factors,” in this Form 10-K, including, but not limited to, the risk factor entitled “A significant network or data security incident may materially impact our reputation, financial condition, and operating results.”


## cyd:CybersecurityRiskBoardOfDirectorsOversightTextBlock

[0001327567-26-000023:notes:10]
The Security Committee, which is composed of our independent directors and chaired by our chief product and technology officer, facilitates our board of directors’ responsibility for oversight of security matters, including product security, data security, cybersecurity, security risk management, risk exposure and related controls and enterprise risk management related to these risks. The Security Committee, including our chief information security officer, reports regularly to the Board following meetings of the Security Committee with respect to its review and assessment of security matters and other matters that are relevant to the Security Committee’s discharge of its responsibilities. The Security Committee meets quarterly to review with our chief information security officer and other members of management, which may include our chief executive officer, chief product and technology officer, chief financial officer, and general counsel, our cybersecurity programs, cybersecurity risks, mitigation or remediation strategies, and other matters impacting the committee’s responsibilities.

[0001327567-26-000023:notes:11]
Management is responsible for day-to-day risk management activities, with our chief information security officer being primarily responsible for identifying, assessing and managing our exposure to cybersecurity risks, establishing processes and procedures so that potential cybersecurity risk exposures are monitored, implementing appropriate mitigation or remediation measures as needed, and maintaining cybersecurity risk management programs. Our chief information security officer is also responsible for defining, overseeing, managing, implementing, and reviewing compliance with the information security programs described above under the heading “Cybersecurity Risk Management and Strategy.” Our chief information security officer receives regular reports from our information security team and monitors the prevention, detection, and mitigation or remediation of cybersecurity risks, and works closely to keep the management team apprised of key risks, treats, and incidents. In addition, as described in further detail above under the heading “Cybersecurity Risk Management and Strategy,” a cross functional team is involved in assessing and managing the risks from cybersecurity threats and incidents, and reporting information about risks to the Security Committee.

[0001327567-26-000023:notes:12]
Our information security team consists of dedicated personnel who are experienced information systems security professionals and information security managers with many years of experience across a variety of technology sub-specialties. In particular, our chief information security officer has extensive experience in the management of cybersecurity risk management programs, having served in various roles in information technology and security for over 25 years. In addition, seven of the ten members of our board of directors have expertise in overseeing cybersecurity and information security management.


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock

[0001327567-26-000023:notes:13]
Description of Business and Summary of Significant Accounting Policies
Description of Business

[0001327567-26-000023:notes:14]
Palo Alto Networks, Inc. (the “Company,” “we,” “us,” or “our”), headquartered in Santa Clara, California, was incorporated in March 2005 under the laws of the State of Delaware and commenced operations in April 2005. Our cybersecurity platforms and services help secure enterprise users, networks, clouds, endpoints, artificial intelligence (“AI”) apps and agents, and identities by delivering comprehensive cybersecurity backed by AI and automation.

[0001327567-26-000023:notes:15]
On January 29, 2026, we acquired Chronosphere, Inc. (“Chronosphere”), a privately-held observability technology company, forming our next-generation observability platform. On February 11, 2026, we acquired CyberArk Software Ltd. (“CyberArk”), an identity security company, forming our next-generation identity security platform. The consolidated financial statements include the financial results of Chronosphere and CyberArk prospectively from the respective dates of acquisitions. Refer to Note 8. Acquisitions for more information regarding our acquisitions of Chronosphere and CyberArk.

[0001327567-26-000023:notes:16]
Basis of Presentation

[0001327567-26-000023:notes:17]
The accompanying consolidated financial statements have been prepared in conformity with U.S. generally accepted accounting principles (“U.S. GAAP”). The consolidated financial statements include all adjustments necessary for a fair presentation of our annual results. All adjustments are of a normal recurring nature.

[0001327567-26-000023:notes:18]
Principles of Consolidation

[0001327567-26-000023:notes:19]
The consolidated financial statements include our accounts and our wholly owned subsidiaries. All significant intercompany balances and transactions have been eliminated in consolidation.

[0001327567-26-000023:notes:20]
Reclassification

[0001327567-26-000023:notes:21]
Certain prior period amounts in the consolidated financial statements and accompanying notes have been reclassified to conform to the current presentation.

[0001327567-26-000023:notes:22]
Use of Estimates

[0001327567-26-000023:notes:23]
The preparation of consolidated financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the amounts reported and disclosed in the consolidated financial statements and the accompanying notes. We evaluate our estimates on an ongoing basis. Management estimates include, but are not limited to, the standalone selling price for our products and services, share-based compensation, fair value of assets acquired and liabilities assumed in business combinations, fair value of our contingent consideration liability, fair value of our capped call transactions (“Capped Calls”), the assessment of recoverability of our intangibles and goodwill, valuation allowance against deferred tax assets, and loss contingencies. We base our estimates on assumptions, both historical and forward looking, that we believe are reasonable. Actual results could differ materially from those estimates due to risks and uncertainties.

[0001327567-26-000023:notes:24]
Stock Split

[0001327567-26-000023:notes:25]
On December 12, 2024, we effected a two-for-one stock split of our outstanding shares of common stock through an amendment to our restated certificate of incorporation (“Stock Split”), which also effected a proportionate increase in the number of authorized shares of our common stock from 1.0 billion to 2.0 billion. The par value per share of our common stock remains unchanged at $0.0001 per share after the Stock Split. All references made to share or per share amounts related to our common stock have been retroactively adjusted on the accompanying consolidated financial statements and applicable disclosures to reflect the effects of the Stock Split.

[0001327567-26-000023:notes:26]
Concentrations of Risks

[0001327567-26-000023:notes:27]
Financial instruments that subject us to concentrations of credit risk consist primarily of cash and cash equivalents, investments, derivative contracts, accounts receivable, and financing receivables.

[0001327567-26-000023:notes:28]
We invest only in high-quality credit instruments and our cash and cash equivalents and available-for-sale investments consist primarily of fixed income securities held at large, diverse financial institutions to reduce the credit risk exposure to any single financial institution. Deposits held with banks may exceed the amount of insurance provided on such deposits.

[0001327567-26-000023:notes:29]
Our derivative contracts expose us to credit risk to the extent that the counterparties are unable to meet the terms of the arrangement. We mitigate credit risk by transacting with multiple major financial institutions with high credit ratings and also enter into master netting arrangements, which permit net settlement of transactions with the same counterparty. We are not required to pledge, and are not entitled to receive, cash collateral related to these derivative instruments. We do not enter into derivative contracts for trading or speculative purposes.

[0001327567-26-000023:notes:30]
Our accounts receivable are primarily derived from our distributors in various geographical locations. Our financing receivables are with qualified end-customers and channel partners. We perform ongoing credit evaluations and generally do not require collateral on accounts receivable or financing receivables.

[0001327567-26-000023:notes:31]
As of July 31, 2026, one distributor individually represented 19% of our gross accounts receivable. As of July 31, 2026, no end-customers or channel partners represented 10% or more of our gross financing receivables.

[0001327567-26-000023:notes:32]
For fiscal 2026, two distributors represented 10% or more of our total revenue, representing 15% and 15%, respectively. No single end-customer accounted for more than 10% of our total revenue in fiscal 2026, 2025, or 2024.

[0001327567-26-000023:notes:33]
We rely on an electronics manufacturing services provider (“EMS provider”) to assemble most of our products and sole source component suppliers for certain components.

[0001327567-26-000023:notes:34]
Comprehensive Income

[0001327567-26-000023:notes:35]
Comprehensive income is comprised of net income and other comprehensive income. Our other comprehensive income includes unrealized gains and losses on available-for-sale investments, unrealized gains and losses on cash flow hedges, and change in fair value of convertible senior notes attributable to instrument-specific credit risk, net of tax effects.

[0001327567-26-000023:notes:36]
Foreign Currency Transactions

[0001327567-26-000023:notes:37]
The functional currency of our foreign subsidiaries is the U.S. dollar. Monetary assets and liabilities denominated in foreign currencies have been remeasured into U.S. dollars using the exchange rates in effect at the balance sheet dates. Foreign currency remeasurement gains and losses and foreign currency transaction gains and losses are not significant to the consolidated financial statements.

[0001327567-26-000023:notes:38]
Fair Value

[0001327567-26-000023:notes:39]
We define fair value as the price that would be received from selling an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date. When determining the fair value measurements for assets and liabilities which are required to be recorded at fair value, we consider the principal or most advantageous market in which to transact and the market-based risk.

[0001327567-26-000023:notes:40]
We categorize assets and liabilities recorded or disclosed at fair value on our consolidated balance sheets based upon the level of judgment associated with inputs used to measure their fair value. The categories are as follows:

[0001327567-26-000023:notes:41]
•Level 1—Inputs are unadjusted quoted prices in active markets for identical assets or liabilities.

[0001327567-26-000023:notes:42]
•Level 2—Inputs are quoted prices for similar assets and liabilities in active markets or inputs that are observable for the assets or liabilities, either directly or indirectly through market corroboration, for substantially the full term of the financial instruments.

[0001327567-26-000023:notes:43]
•Level 3—Inputs are unobservable inputs based on our own assumptions used to measure assets and liabilities at fair value. The inputs require significant management judgment or estimation.

[0001327567-26-000023:notes:44]
Our financial assets and liabilities that are measured at fair value on a recurring basis include marketable securities, derivative financial instruments, Capped Calls related to convertible senior notes, deferred compensation liability, contingent consideration liability, and convertible senior notes. Goodwill, intangible assets, and other long-lived assets are measured at fair value on a nonrecurring basis, only if impairment is indicated. Certain certificates of deposit, time deposits, and overnight sweep accounts recorded in cash and cash equivalents and short-term investments are stated at their carrying amounts, which approximate fair value due to their short maturities. The carrying amounts of accounts receivable, accounts payable, and accrued liabilities approximate fair value due to their short-term nature.

[0001327567-26-000023:notes:45]
Cash, Cash Equivalents, and Investments

[0001327567-26-000023:notes:46]
We consider all highly liquid investments with original maturities of three months or less at the date of purchase to be cash equivalents. Investments not considered cash equivalents and with maturities of one year or less from the consolidated balance sheet date are classified as short-term investments. Investments with maturities greater than one year from the consolidated balance sheet date are classified as long-term investments.

[0001327567-26-000023:notes:47]
We determine the classification of our investments in marketable debt securities at the time of purchase and reevaluate such determination at each balance sheet date. Our marketable debt securities are classified as available-for-sale. Debt securities in an unrealized loss position are written down to its fair value with the corresponding charge recorded in other income (expense), net on our consolidated statements of operations, if it is more likely than not that we will be required to sell the impaired security before recovery of its amortized cost basis, or we have the intention to sell the security. If neither of these conditions are met, we determine whether a credit loss exists by comparing the present value of the expected cash flows of the security with its amortized cost basis. An allowance for credit losses is recorded in other income (expense), net on our consolidated statements of operations for an amount not to exceed the unrealized loss. Unrealized losses that are not credit-related are included in AOCI in stockholders’ equity.

[0001327567-26-000023:notes:48]
Accounts Receivable

[0001327567-26-000023:notes:49]
Trade accounts receivable are recorded at the invoiced amount, net of allowances for credit losses. The allowance for credit losses is based on our assessment of collectability. Management regularly reviews the adequacy of the allowance for credit losses on a collective basis by considering the age of each outstanding invoice, each customer’s expected ability to pay and collection history, current market conditions, and, where appropriate, reasonable and supportable forecasts of future economic conditions. Accounts receivable deemed uncollectible are charged against the allowance for credit losses. For the years ended July 31, 2026, 2025 and 2024, the allowance for credit losses activity was not significant.

[0001327567-26-000023:notes:50]
Financing Receivables

[0001327567-26-000023:notes:51]
We provide financing arrangements for certain qualified end-customers and channel partners to purchase our products and services. Payment terms on these financing arrangements are generally two to five years. Financing receivables are recorded at amortized cost, which approximates fair value. As part of our financing credit risk management policy, we may sell financing receivables with an internal risk rating of 5 or greater on a non-recourse basis to third-party financial institutions when the outstanding balance of our financing receivables exceeds pre-established thresholds. The financing receivables are derecognized upon sale as these transactions qualify as true sales. We classify the proceeds from these sales as cash flows from operating activities on our consolidated statements of cash flows.

[0001327567-26-000023:notes:52]
We evaluate the allowance for credit losses by assessing the risks and losses inherent in our financing receivables on either an individual or a collective basis. Our assessment considers various factors, including lifetime expected losses determined using customer risk profile, current economic conditions that may affect a customer’s ability to pay, and forward-looking economic considerations. Financing receivables deemed uncollectible are charged against the allowance for credit losses.

[0001327567-26-000023:notes:53]
Derivatives

[0001327567-26-000023:notes:54]
We are exposed to foreign currency exchange risk, which we manage through the use of derivative financial instruments. Our derivative financial instruments are recorded at fair value, on a gross basis, as either assets or liabilities on our consolidated balance sheets.

[0001327567-26-000023:notes:55]
Our sales contracts are primarily denominated in U.S. dollars. A portion of our operating expenditures are denominated in foreign currencies, making them subject to fluctuations in foreign currency exchange rates. We enter into foreign currency derivative contracts with maturities of 24 months or less, which we designate as cash flow hedges, to manage the foreign currency exchange risk associated with our revenue and operating expenditures. Gains and losses related to the effective portion of our cash flow hedges are recorded as a component of AOCI on our consolidated balance sheets and are reclassified into the financial statement line item associated with the underlying hedged transaction on our consolidated statements of operations when the underlying hedged transaction is recognized in earnings. In the event the underlying hedged transaction does not occur, or it becomes probable that it will not occur within the defined hedge period, the gains or losses on the related cash flow hedges are recognized in other income (expense), net on our consolidated statements of operations. Cash flows from foreign currency derivative contracts designated as cash flow hedges are classified on our consolidated statements of cash flows in the same manner as the underlying hedged transaction, primarily within cash flows from operating activities.

[0001327567-26-000023:notes:56]
We also enter into foreign currency derivative contracts to hedge a portion of our outstanding monetary assets and liabilities denominated in foreign currencies. These derivatives are not designated as hedging instruments for accounting purposes, and the related gains and losses are recorded in other income (expense), net on our consolidated statements of operations.

[0001327567-26-000023:notes:57]
Inventory and Manufacturing Partner and Supplier Liabilities

[0001327567-26-000023:notes:58]
Inventory consists primarily of raw materials and service-related spares, and is stated at the lower of average cost and net realizable value. Inventory is included in prepaid expenses and other current assets on our consolidated balance sheets. Inventory that is obsolete or in excess of forecasted demand is written down to its estimated realizable value. Once inventory has been written down, a new, lower-cost basis for that inventory is established.

[0001327567-26-000023:notes:59]
We outsource most of our manufacturing, repair, and supply chain management operations to our EMS provider and payments to it are a significant portion of our cost of product revenue. Although we are contractually obligated to purchase manufactured products and components, we generally do not own the components and manufactured products. Product title transfers from our EMS provider to us and immediately to our customers upon shipment. We record a liability for manufacturing purchase commitments in excess of our forecasted demand.

[0001327567-26-000023:notes:60]
We use consistent demand forecasts for our valuation of excess and obsolete inventory and manufacturing partner and supplier liabilities. These forecasts are based upon historical trends and analysis, adjusted for overall market conditions. Inventory write-downs and excess manufacturing purchase commitment charges are included in cost of product revenue on our consolidated statements of operations.

[0001327567-26-000023:notes:61]
Property and Equipment

[0001327567-26-000023:notes:62]
Property and equipment are stated at cost, less accumulated depreciation. Depreciation is computed using the straight-line method over the estimated useful lives of the assets. Land is not depreciated. The estimated useful lives of our depreciable assets are as follows:

[0001327567-26-000023:notes:63]
| Asset category |  | Useful life |
| Computers, equipment, and software |  | 3 years - 5 years |
| Demonstration units |  | 4 years |
| Furniture and fixtures |  | 5 years |
| Leasehold improvements |  | Lesser of 10 years or remaining lease term |

[0001327567-26-000023:notes:64]
Business Combinations

[0001327567-26-000023:notes:65]
We include the results of operations of the businesses that we acquire as of the respective dates of acquisition. We allocate the fair value of the purchase price of our acquisitions to the assets acquired and liabilities assumed, including contingent consideration, generally based on their estimated fair values. The excess of the purchase price over the fair values of these identifiable assets and liabilities is recorded as goodwill. Additional information existing as of the acquisition date but unknown to us may become known during the remainder of the measurement period, not to exceed 12 months from the acquisition date, which may result in changes to the amounts and allocations recorded.

[0001327567-26-000023:notes:66]
A contingent consideration obligation incurred in connection with a business combination is recorded at fair value on the acquisition date and remeasured at each subsequent reporting period until the related contingencies have been resolved, with the change in fair value recognized in general and administrative expense on our consolidated statements of operations. Payments not made soon after the acquisition date to settle a contingent consideration liability are classified as cash flows from financing activities up to the amount of the contingent consideration liability recognized at the acquisition date.

[0001327567-26-000023:notes:67]
Intangible Assets

[0001327567-26-000023:notes:68]
Purchased intangible assets with finite lives are carried at cost, less accumulated amortization. Amortization is computed using the straight-line method over the estimated useful lives of the assets.

[0001327567-26-000023:notes:69]
Impairment of Goodwill, Intangible Assets, and Other Long-Lived Assets

[0001327567-26-000023:notes:70]
Goodwill is evaluated for impairment on an annual basis in the fourth quarter of our fiscal year, and whenever events or changes in circumstances indicate the carrying amount of goodwill may not be recoverable. We have elected to first assess qualitative factors to determine whether it is more likely than not that the fair value of our single reporting unit is less than its carrying amount, including goodwill. If we determine that it is more likely than not that the fair value is less than its carrying amount, then the quantitative impairment test will be performed. Under the quantitative impairment test, if the carrying amount exceeds its fair value, we will recognize an impairment loss in an amount equal to that excess but limited to the total amount of goodwill.

[0001327567-26-000023:notes:71]
We evaluate events and changes in circumstances that could indicate carrying amounts of purchased intangible assets and other long-lived assets may not be recoverable. When such events or changes in circumstances occur, we assess the recoverability of an asset or asset group by determining whether or not the carrying amount will be recovered through undiscounted expected future cash flows. If the total of the future undiscounted cash flows is less than the carrying amount of an asset or asset group, we record an impairment loss for the amount by which the carrying amount exceeds the fair value of the asset or asset group.

[0001327567-26-000023:notes:72]
We did not recognize any impairment losses on our goodwill, intangible assets, or other long-lived assets during the years ended July 31, 2026, 2025, and 2024.

[0001327567-26-000023:notes:73]
Convertible Senior Notes and Capped Calls

[0001327567-26-000023:notes:74]
Our convertible senior notes issued in June 2020 were fully settled upon maturity as of July 31, 2025. Prior to settlement, these convertible senior notes were accounted for as a liability and measured at their amortized cost. Transaction costs related to the issuance of the notes were netted with the liability and were amortized on a straight-line basis, which approximates the effective interest rate method, to other income (expense), net over the term of the notes.

[0001327567-26-000023:notes:75]
In connection with the CyberArk acquisition, we acquired CyberArk’s convertible senior notes and assumed certain Capped Calls that CyberArk had previously entered into relating to the issuance of these convertible senior notes. The Capped Calls are expected to reduce the potential dilution to our common stock upon conversion of the convertible senior notes and/or offset our cash payments in excess of the principal amount of converted notes, as the case may be, with such reduction and/or offset subject to a cap.

[0001327567-26-000023:notes:76]
For the convertible senior notes acquired from CyberArk, we have elected the fair value option to simplify the accounting for embedded features that would otherwise require bifurcation from the debt-host and recognition as a separate derivative liability. These convertible senior notes are measured at fair value on a recurring basis through maturity or settlement. Changes in fair value included in earnings are recorded in other income (expense), net on our consolidated statements of operations, and changes in fair value attributable to instrument-specific credit risk are included in AOCI in our consolidated statements of stockholders’ equity.

[0001327567-26-000023:notes:77]
We account for Capped Calls as derivative assets, measured at fair value on a recurring basis through maturity or settlement. Capped Calls are recorded in other assets on our consolidated balance sheets. Changes in fair value are recorded in other income (expense), net on our consolidated statements of operations.

[0001327567-26-000023:notes:78]
Revenue Recognition

[0001327567-26-000023:notes:79]
Our revenue consists of product revenue and subscription and support revenue. Revenue is recognized when control of promised products, subscriptions and support services are transferred to customers, in an amount that reflects the expected consideration in exchange for those products and services.

[0001327567-26-000023:notes:80]
We determine revenue recognition through the following steps:

[0001327567-26-000023:notes:81]
•Identification of the contract, or contracts, with a customer.

[0001327567-26-000023:notes:82]
•Identification of the performance obligations in the contract.

[0001327567-26-000023:notes:83]
•Determination of the transaction price.

[0001327567-26-000023:notes:84]
•Allocation of the transaction price to the performance obligations in the contract.

[0001327567-26-000023:notes:85]
•Recognition of revenue when, or as, we satisfy a performance obligation.

[0001327567-26-000023:notes:86]
Revenues are reported net of sales taxes. Shipping charges billed to our customers are included in revenue and related costs are included in cost of revenue.

[0001327567-26-000023:notes:87]
Product Revenue

[0001327567-26-000023:notes:88]
Product revenue is derived from sales of our hardware products and software licenses. Our hardware products and software licenses include a broad set of built-in networking and security features and functionalities. We recognize product revenue at the time of hardware shipment or delivery of software license.

[0001327567-26-000023:notes:89]
Subscription and Support Revenue

[0001327567-26-000023:notes:90]
Subscription and support revenue is derived primarily from sales of our subscription and support offerings. We recognize subscription and support revenue over time as the services are performed. Our contractual subscription and support contracts are typically one to five years.

[0001327567-26-000023:notes:91]
Contracts with Multiple Performance Obligations

[0001327567-26-000023:notes:92]
The majority of our contracts with our customers include various combinations of our products and subscriptions and support. Our hardware products and software licenses are distinct from our subscriptions and support services as the customer can benefit from the product without these services and such services are separately identifiable within the contract. We account for multiple agreements with a single customer as a single contract if the contractual terms and/or substance of those agreements indicate that they may be so closely related that they are, in effect, parts of a single contract. The amount of consideration we expect to receive in exchange for delivering on the contract is allocated to each performance obligation based on its relative standalone selling price.

[0001327567-26-000023:notes:93]
When estimating standalone selling price, we first consider the prices charged for a deliverable when sold separately. If the standalone selling price is not observable through past transactions, we estimate it based on our pricing model and our go-to-market strategy, which include factors such as type of sales channel (channel partner or end-customer), the geographies in which our offerings were sold (domestic or international), and offering type (products, subscriptions, or support).

[0001327567-26-000023:notes:94]
Deferred Revenue

[0001327567-26-000023:notes:95]
We record deferred revenue when customers are invoiced or cash payments are received in advance of our performance. Our payment terms typically require payment within 30 to 75 days of the date we issue an invoice. The current portion of deferred revenue represents the amounts that are expected to be recognized as revenue within one year of the consolidated balance sheet date.

[0001327567-26-000023:notes:96]
Deferred Contract Costs

[0001327567-26-000023:notes:97]
We defer contract costs that are recoverable and incremental to obtaining customer sales contracts. Contract costs, which primarily consist of sales commissions, are amortized on a systematic basis that is consistent with the transfer to the customer of the goods or services to which the asset relates. We determine whether sales commissions for initial contracts are commensurate with the commissions for renewal contracts based on whether there is a substantive difference in commission rates in proportion to their respective contract values. Sales commissions for initial contracts that are commensurate and sales commissions for renewal contracts are amortized over the related contractual period. Sales commissions for initial contracts that are not commensurate are amortized over a benefit period of five years. The benefit period is determined by taking into consideration contract length, expected renewals, technology life, and other quantitative and qualitative factors.

[0001327567-26-000023:notes:98]
We classify deferred contract costs as short-term or long-term based on when we expect to recognize the expense. The amortization of deferred contract costs is included in sales and marketing expense on our consolidated statements of operations. Deferred contract costs are periodically reviewed for impairment. We did not recognize any impairment losses on our deferred contract costs during the years ended July 31, 2026, 2025, or 2024.

[0001327567-26-000023:notes:99]
Software Development Costs

[0001327567-26-000023:notes:100]
Internally developed software includes security software developed to deliver our cloud-based subscription offerings to our end-customers. We capitalize internal compensation-related costs and external direct costs incurred during the application development stage and amortize these costs over a useful life of three years. As of July 31, 2026 and 2025, we capitalized as other assets on our consolidated balance sheets $266 million and $167 million in costs, respectively, net of accumulated amortization, for security software developed to deliver our cloud-based subscription offerings. We recognized amortization expense of $104 million, $83 million, and $78 million related to these capitalized costs as cost of subscription and support revenue on our consolidated statements of operations during the years ended July 31, 2026, 2025, and 2024, respectively.

[0001327567-26-000023:notes:101]
The costs to develop software that is marketed externally have not been capitalized as we believe our current software development process is essentially completed concurrent with the establishment of technological feasibility. As such, all related software development costs are expensed as incurred and included in research and development expense on our consolidated statements of operations.

[0001327567-26-000023:notes:102]
Share-Based Compensation

[0001327567-26-000023:notes:103]
Compensation expense related to share-based transactions is measured at fair value on the grant date. We recognize share-based compensation expense for awards with only service conditions on a straight-line basis over the requisite service period. We recognize share-based compensation expense for awards with market conditions and awards with performance conditions on a straight-line basis over the requisite service period for each separately vesting tranche of the award. We recognize share-based compensation expense for awards with performance conditions when it is probable that the performance condition will be achieved. We account for forfeitures of all share-based payment awards when they occur.

[0001327567-26-000023:notes:104]
Deferred Compensation Plan

[0001327567-26-000023:notes:105]
We maintain an unfunded nonqualified deferred compensation plan that allows eligible employees to defer a portion of their base salary, bonus, commissions, and vested equity awards which are settled in shares of our common stock. Participants may elect to diversify a portion of their deferred compensation into certain investment funds. Amounts diversified are accounted for as liability-classified awards and are recorded in accrued compensation and other long-term liabilities on our consolidated balance sheets based on the timing of expected distributions. Liability-classified awards are measured at fair value on a recurring basis through distribution with changes in fair value recorded as share-based compensation.

[0001327567-26-000023:notes:106]
Leases

[0001327567-26-000023:notes:107]
We determine if an arrangement is a lease at inception. We evaluate the classification of leases at commencement and, as necessary, at modification. Operating lease related balances are included in operating lease right-of-use assets, accrued and other liabilities, and long-term operating lease liabilities on our consolidated balance sheets. We did not have any material finance leases in any of the periods presented.

[0001327567-26-000023:notes:108]
Operating lease right-of-use assets represent our right to use an underlying asset for the lease term. Operating lease liabilities represent our obligation to make payments arising from the lease. Operating lease right-of-use assets and liabilities are recognized at the present value of the future lease payments at the lease commencement date. The interest rate used to determine the present value of the future lease payments is our incremental borrowing rate, because the interest rates implicit in our leases are not readily determinable. Our incremental borrowing rate is estimated to approximate the interest rate on a collateralized basis with similar terms and payments, and in similar economic environments. Operating lease right-of-use assets also include adjustments related to lease incentives, prepaid or accrued rent and initial direct lease costs. Operating lease right-of-use assets are subject to evaluation for impairment or disposal on a basis consistent with other long-lived assets.

[0001327567-26-000023:notes:109]
Our lease terms may include periods under options to extend or terminate the lease when it is reasonably certain that we will exercise that option. We generally use the base, non-cancelable lease term when determining our operating lease right-of-use assets and lease liabilities. Operating lease costs are recognized on a straight-line basis over the lease term.

[0001327567-26-000023:notes:110]
We account for lease and non-lease components as a single lease component and do not recognize right-of-use assets and lease liabilities for leases with a term of 12 months or less. Payments under our lease arrangements are primarily fixed, however, certain lease agreements contain variable payments, which are expensed as incurred and not included in operating lease right-of-use assets and liabilities. Our variable lease payments primarily consist of real estate taxes, common area maintenance charges, and insurance costs.

[0001327567-26-000023:notes:111]
Income Taxes

[0001327567-26-000023:notes:112]
We account for income taxes using the asset and liability method, which requires the recognition of deferred tax assets and liabilities for the expected future tax consequences of events that have been recognized in our consolidated financial statements or tax returns. In addition, deferred tax assets are recorded for all future benefits including, but not limited to, net operating losses, research and development credit carryforwards, and basis differences relating to our global intangible low-taxed income. Valuation allowances are provided when necessary to reduce deferred tax assets to the amount more likely than not to be realized.

[0001327567-26-000023:notes:113]
Significant judgment is required in determining any valuation allowance recorded against deferred tax assets. In assessing the need for a valuation allowance, we consider all available evidence, including past operating results, estimates of future taxable income, and the feasibility of tax planning strategies. In the event that we change our determination as to the amount of deferred tax assets that can be realized, we will adjust our valuation allowance with a corresponding impact to the provision for income taxes in the period in which such determination is made.

[0001327567-26-000023:notes:114]
We recognize liabilities for uncertain tax positions based on a two-step process which includes evaluating if a tax position is more likely than not to be sustained on audit and then measuring the tax benefit as the largest amount that is more likely than not to be realized upon ultimate settlement.

[0001327567-26-000023:notes:115]
Loss Contingencies

[0001327567-26-000023:notes:116]
We are subject to the possibility of various loss contingencies arising in the ordinary course of business. In determining loss contingencies, we consider the likelihood of loss or impairment of an asset, or the incurrence of a liability, as well as our ability to reasonably estimate the amount of loss. An estimated loss contingency is accrued when it is probable that an asset has been impaired or a liability has been incurred and the amount of loss can be reasonably estimated. If we determine that a loss is reasonably possible, then we disclose the possible loss or range of the possible loss or state that such an estimate cannot be made. We regularly evaluate current information available to us to determine whether an accrual is required, an accrual should be adjusted, or a range of possible loss should be disclosed.

[0001327567-26-000023:notes:117]
Recently Adopted Accounting Pronouncements

[0001327567-26-000023:notes:118]
Income Tax Disclosures

[0001327567-26-000023:notes:119]
In December 2023, the Financial Accounting Standards Board (“FASB”) issued authoritative guidance that requires consistent categories and greater disaggregation of information in the effective tax rate reconciliation and additional disclosures of income taxes paid by jurisdiction. We adopted this standard for the year ended July 31, 2026 on a prospective basis. The adoption of this standard results in disclosure of additional jurisdictional level tax information in our consolidated financial statements. Refer to Note 16. Income Taxes for more details.

[0001327567-26-000023:notes:120]
Government Grants Received by Business Entities

[0001327567-26-000023:notes:121]
In December 2025, the FASB issued authoritative guidance that establishes the accounting for government grants received by business entities. We early adopted this standard in our fiscal 2026 on a modified prospective basis. The adoption of this standard did not have a material impact on our consolidated financial statements for the year ended July 31, 2026.

[0001327567-26-000023:notes:122]
Recently Issued Accounting Pronouncements

[0001327567-26-000023:notes:123]
Expense Disaggregation Disclosures

[0001327567-26-000023:notes:124]
In November 2024, the FASB issued authoritative guidance that expands annual and interim disclosure of specified information about certain costs and expenses in the notes to financial statements. The standard is effective for our annual periods beginning in fiscal 2028 and interim periods beginning in our first quarter of fiscal 2029, and can be applied either prospectively or retrospectively. Early adoption is permitted. We are currently evaluating the impact of this standard on our disclosures in the consolidated financial statements.

[0001327567-26-000023:notes:125]
Measurement of Credit Losses for Accounts Receivable and Contract Assets

[0001327567-26-000023:notes:126]
In July 2025, the FASB issued authoritative guidance that provides a practical expedient for estimating expected credit losses on accounts receivable and contract assets. We plan to adopt this standard beginning in our first quarter of fiscal 2027 and do not expect the adoption of this standard to have a material impact on our consolidated financial statements.

[0001327567-26-000023:notes:127]
Accounting for Internal-Use Software

[0001327567-26-000023:notes:128]
In September 2025, the FASB issued authoritative guidance that modernizes the accounting for internal-use software by eliminating project stage-based capitalization and clarifying the requirements, including probable-to-complete threshold, to commence the capitalization of software development costs. The standard is effective for our annual and interim periods beginning in the first quarter of fiscal 2029 and can be applied either prospectively or retrospectively. Early adoption is permitted. We are currently evaluating the impact of this standard on our consolidated financial statements.

[0001327567-26-000023:notes:129]
Hedge Accounting Improvements

[0001327567-26-000023:notes:130]
In November 2025, the FASB issued authoritative guidance that clarifies and improves the existing hedge accounting guidance to better reflect the economics of an entity’s risk management activities. The standard is effective for our annual and interim periods beginning in the first quarter of fiscal 2028 and will be applied on a prospective basis. Early adoption is permitted. We are currently evaluating the impact of this standard on our consolidated financial statements.


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0001327567-26-000023:notes:131]
The estimated useful lives of our depreciable assets are as follows:

[0001327567-26-000023:notes:132]
The following table presents details of our property and equipment, net (in millions):

[0001327567-26-000023:notes:133]
|  | July 31, |
|  | 2026 |  | 2025 |
| Computers, equipment, and software | $ | 612 |  |  | $ | 513 |  |
| Leasehold improvements | 366 |  |  | 325 |  |
| Land | 178 |  |  | 87 |  |
| Demonstration units | 49 |  |  | 47 |  |
| Furniture and fixtures | 65 |  |  | 54 |  |
| Total property and equipment, gross | 1,270 |  |  | 1,026 |  |
| Less: accumulated depreciation | (747) |  |  | (639) |  |
| Total property and equipment, net | $ | 523 |  |  | $ | 387 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001327567-26-000023:notes:134]
Revenue
Disaggregation of Revenue

[0001327567-26-000023:notes:135]
The following table presents revenue by geographic theater (in millions):

[0001327567-26-000023:notes:136]
|  | Year Ended July 31, |
|  | 2026 |  | 2025 |  | 2024 |
| Revenue: |  |  |  |  |  |
| Americas |  |  |  |  |  |
| United States | $ | 7,108 |  |  | $ | 5,786 |  |  | $ | 5,134 |  |
| Other Americas | 571 |  |  | 419 |  |  | 349 |  |
| Total Americas | 7,679 |  |  | 6,205 |  |  | 5,483 |  |
| Europe, the Middle East, and Africa (“EMEA”) | 2,428 |  |  | 1,917 |  |  | 1,602 |  |
| Asia Pacific and Japan (“APAC”) | 1,373 |  |  | 1,099 |  |  | 942 |  |
| Total revenue | $ | 11,480 |  |  | $ | 9,221 |  |  | $ | 8,027 |  |

[0001327567-26-000023:notes:137]
The following table presents revenue for groups of similar products and services (in millions):

[0001327567-26-000023:notes:138]
|  | Year Ended July 31, |
|  | 2026 |  | 2025 |  | 2024 |
| Revenue: |  |  |  |  |  |
| Product | $ | 2,280 |  |  | $ | 1,802 |  |  | $ | 1,603 |  |
| Subscription and support |  |  |  |  |  |
| Subscription | 6,239 |  |  | 4,974 |  |  | 4,188 |  |
| Support | 2,961 |  |  | 2,445 |  |  | 2,236 |  |
| Total subscription and support | 9,200 |  |  | 7,419 |  |  | 6,424 |  |
| Total revenue | $ | 11,480 |  |  | $ | 9,221 |  |  | $ | 8,027 |  |

[0001327567-26-000023:notes:139]
During the years ended July 31, 2026 and 2025, we recognized approximately $6.2 billion and $5.5 billion of revenue pertaining to amounts that were deferred as of July 31, 2025 and 2024, respectively.

[0001327567-26-000023:notes:140]
Remaining Performance Obligations

[0001327567-26-000023:notes:141]
Remaining performance obligations were $21.2 billion as of July 31, 2026, of which we expect to recognize as revenue approximately $9.3 billion over the next 12 months and the remainder thereafter.


## us-gaap:FairValueDisclosuresTextBlock

[0001327567-26-000023:notes:142]
Fair Value Measurements
The following table presents our financial assets and liabilities measured at fair value on a recurring basis as of July 31, 2026 and 2025 (in millions):

[0001327567-26-000023:notes:143]
|  |  | July 31, 2026 |  | July 31, 2025 |
|  |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Cash equivalents: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 1,514 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,514 |  |  | $ | 1,206 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,206 |  |
| Commercial paper |  | — |  |  | 123 |  |  | — |  |  | 123 |  |  | — |  |  | 169 |  |  | — |  |  | 169 |  |
| Total cash equivalents |  | 1,514 |  |  | 123 |  |  | — |  |  | 1,637 |  |  | 1,206 |  |  | 169 |  |  | — |  |  | 1,375 |  |
| Short-term investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Commercial paper |  | — |  |  | 10 |  |  | — |  |  | 10 |  |  | — |  |  | 15 |  |  | — |  |  | 15 |  |
| Corporate debt securities |  | — |  |  | 374 |  |  | — |  |  | 374 |  |  | — |  |  | 584 |  |  | — |  |  | 584 |  |
| U.S. government and agency securities |  | — |  |  | 2 |  |  | — |  |  | 2 |  |  | — |  |  | 6 |  |  | — |  |  | 6 |  |
| Non-U.S. government and agency securities |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 3 |  |  | — |  |  | 3 |  |
| Asset-backed securities |  | — |  |  | 6 |  |  | — |  |  | 6 |  |  | — |  |  | 22 |  |  | — |  |  | 22 |  |
| Total short-term investments |  | — |  |  | 392 |  |  | — |  |  | 392 |  |  | — |  |  | 630 |  |  | — |  |  | 630 |  |
| Long-term investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate debt securities |  | — |  |  | 3,843 |  |  | — |  |  | 3,843 |  |  | — |  |  | 4,050 |  |  | — |  |  | 4,050 |  |
| U.S. government and agency securities |  | — |  |  | 68 |  |  | — |  |  | 68 |  |  | — |  |  | 164 |  |  | — |  |  | 164 |  |
| Non-U.S. government and agency securities |  | — |  |  | 21 |  |  | — |  |  | 21 |  |  | — |  |  | 26 |  |  | — |  |  | 26 |  |
| Asset-backed securities |  | — |  |  | 903 |  |  | — |  |  | 903 |  |  | — |  |  | 1,315 |  |  | — |  |  | 1,315 |  |
| Total long-term investments |  | — |  |  | 4,835 |  |  | — |  |  | 4,835 |  |  | — |  |  | 5,555 |  |  | — |  |  | 5,555 |  |
| Prepaid expenses and other current assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency forward contracts |  | — |  |  | 18 |  |  | — |  |  | 18 |  |  | — |  |  | 58 |  |  | — |  |  | 58 |  |
| Total prepaid expenses and other current assets |  | — |  |  | 18 |  |  | — |  |  | 18 |  |  | — |  |  | 58 |  |  | — |  |  | 58 |  |
| Other assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency forward contracts |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 3 |  |  | — |  |  | 3 |  |
| Capped calls related to convertible senior notes |  | — |  |  | 153 |  |  | — |  |  | 153 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Total other assets |  | — |  |  | 153 |  |  | — |  |  | 153 |  |  | — |  |  | 3 |  |  | — |  |  | 3 |  |
| Total assets measured at fair value |  | $ | 1,514 |  |  | $ | 5,521 |  |  | $ | — |  |  | $ | 7,035 |  |  | $ | 1,206 |  |  | $ | 6,415 |  |  | $ | — |  |  | $ | 7,621 |  |

[0001327567-26-000023:notes:144]
|  |  | July 31, 2026 |  | July 31, 2025 |
|  |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Accrued and other liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency forward contracts |  | $ | — |  |  | $ | 24 |  |  | $ | — |  |  | $ | 24 |  |  | $ | — |  |  | $ | 4 |  |  | $ | — |  |  | $ | 4 |  |
| Deferred compensation liability |  | 5 |  |  | — |  |  | — |  |  | 5 |  |  | 2 |  |  | — |  |  | — |  |  | 2 |  |
| Contingent consideration |  | — |  |  | — |  |  | 116 |  |  | 116 |  |  | — |  |  | — |  |  | 276 |  |  | 276 |  |
| Total accrued and other liabilities |  | 5 |  |  | 24 |  |  | 116 |  |  | 145 |  |  | 2 |  |  | 4 |  |  | 276 |  |  | 282 |  |
| Long-term convertible senior notes |  | — |  |  | 1,774 |  |  | — |  |  | 1,774 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Other long-term liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Deferred compensation liability |  | 400 |  |  | — |  |  | — |  |  | 400 |  |  | 57 |  |  | — |  |  | — |  |  | 57 |  |
| Contingent consideration |  | — |  |  | — |  |  | 90 |  |  | 90 |  |  | — |  |  | — |  |  | 238 |  |  | 238 |  |
| Total other long-term liabilities |  | 400 |  |  | — |  |  | 90 |  |  | 490 |  |  | 57 |  |  | — |  |  | 238 |  |  | 295 |  |
| Total liabilities measured at fair value |  | $ | 405 |  |  | $ | 1,798 |  |  | $ | 206 |  |  | $ | 2,409 |  |  | $ | 59 |  |  | $ | 4 |  |  | $ | 514 |  |  | $ | 577 |  |

[0001327567-26-000023:notes:145]
The fair value of our contingent consideration liability is estimated using a discounted cash flow valuation technique. We consider the fair value of our contingent consideration liability to be a Level 3 measurement as we use unobservable inputs in determining discounted cash flows to estimate the fair value. The significant unobservable inputs include an estimate of future cash payments related to customers entering into qualified new transactions as well as a risk-adjusted discount rate used to present value the expected cash flows. A significant change in any of these assumptions could have a material impact to the fair value of our contingent consideration liability.

[0001327567-26-000023:notes:146]
In June 2025, we amended the terms of our contingent consideration arrangement with International Business Machines Corporation (“IBM”). During the three months ended July 31, 2025, we reduced our estimate of future cash payments based on the amended terms and our quarterly assessment of assumptions. During the year ended July 31, 2026, we reduced our estimate of future cash payments based on our quarterly assessment of assumptions. Assumptions considered during our quarterly assessment include the magnitude and likelihood of customers entering into qualified new transactions, the competitive industry environment, and current market conditions.

[0001327567-26-000023:notes:147]
The following table presents a reconciliation of our contingent consideration liability (in millions):

[0001327567-26-000023:notes:148]
|  | Year Ended July 31, |
|  | 2026 |  | 2025 |  |  |  |  |
| Contingent consideration liability at the beginning of the period | $ | 514 |  |  | $ | — |  |  |  |  |  |
| Initial valuation on the acquisition date | — |  |  | 649 |  |  |  |  |  |
| Change in fair value | (117) |  |  | (135) |  |  |  |  |  |
| Payments | (191) |  |  | — |  |  |  |  |  |
| Contingent consideration liability at the end of the period | $ | 206 |  |  | $ | 514 |  |  |  |  |  |

[0001327567-26-000023:notes:149]
The total estimated fair value of our financing receivables approximates their carrying amounts as of July 31, 2026 and 2025. We consider the fair value of our financing receivables to be a Level 3 measurement as we use unobservable inputs in determining discounted cash flows to estimate the fair value.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001327567-26-000023:notes:150]
Cash Equivalents and Investments
Available-for-sale Debt Securities

[0001327567-26-000023:notes:151]
The following tables summarize the amortized cost, unrealized gains and losses, and fair value of our available-for-sale debt securities (in millions):

[0001327567-26-000023:notes:152]
|  | July 31, 2026 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | $ | 123 |  |  | $ | — |  |  | $ | — |  |  | $ | 123 |  |
| Total available-for-sale cash equivalents | $ | 123 |  |  | $ | — |  |  | $ | — |  |  | $ | 123 |  |
| Investments: |  |  |  |  |  |  |  |
| Commercial paper | $ | 10 |  |  | $ | — |  |  | $ | — |  |  | $ | 10 |  |
| Corporate debt securities | 4,241 |  |  | 8 |  |  | (32) |  |  | 4,217 |  |
| U.S. government and agency securities | 70 |  |  | — |  |  | — |  |  | 70 |  |
| Non-U.S. government and agency securities | 21 |  |  | — |  |  | — |  |  | 21 |  |
| Asset-backed securities | 910 |  |  | 2 |  |  | (3) |  |  | 909 |  |
| Total available-for-sale investments | $ | 5,252 |  |  | $ | 10 |  |  | $ | (35) |  |  | $ | 5,227 |  |

[0001327567-26-000023:notes:153]
|  | July 31, 2025 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | $ | 169 |  |  | $ | — |  |  | $ | — |  |  | $ | 169 |  |
| Total available-for-sale cash equivalents | $ | 169 |  |  | $ | — |  |  | $ | — |  |  | $ | 169 |  |
| Investments: |  |  |  |  |  |  |  |
| Commercial paper | $ | 15 |  |  | $ | — |  |  | $ | — |  |  | $ | 15 |  |
| Corporate debt securities | 4,588 |  |  | 47 |  |  | (1) |  |  | 4,634 |  |
| U.S. government and agency securities | 170 |  |  | — |  |  | — |  |  | 170 |  |
| Non-U.S. government and agency securities | 29 |  |  | — |  |  | — |  |  | 29 |  |
| Asset-backed securities | 1,328 |  |  | 9 |  |  | — |  |  | 1,337 |  |
| Total available-for-sale investments | $ | 6,130 |  |  | $ | 56 |  |  | $ | (1) |  |  | $ | 6,185 |  |

[0001327567-26-000023:notes:154]
Unrealized losses related to our available-for-sale debt securities are primarily due to interest rate fluctuations as opposed to credit quality. We do not intend to sell any of the securities in an unrealized loss position and it is not likely that we would be required to sell these securities before recovery of their amortized cost basis, which may be at maturity. We did not recognize any credit losses related to our available-for-sale debt securities during the years ended July 31, 2026 and 2025.

[0001327567-26-000023:notes:155]
The following table summarizes the amortized cost and fair value of our available-for-sale debt securities as of July 31, 2026, by contractual years-to-maturity (in millions):

[0001327567-26-000023:notes:156]
|  | Amortized Cost |  | Fair Value |
| Due within one year | $ | 514 |  |  | $ | 515 |  |
| Due between one and three years | 1,805 |  |  | 1,807 |  |
| Due between three and five years | 2,754 |  |  | 2,727 |  |
| Due between five and ten years | 143 |  |  | 143 |  |
| Due after ten years | 159 |  |  | 158 |  |
| Total | $ | 5,375 |  |  | $ | 5,350 |  |

[0001327567-26-000023:notes:157]
Marketable Equity Securities

[0001327567-26-000023:notes:158]
Marketable equity securities consist of money market funds and are included in cash and cash equivalents on our consolidated balance sheets. As of July 31, 2026 and 2025, the carrying values of our marketable equity securities were $1.5 billion and $1.2 billion, respectively. There were no unrealized gains or losses recognized for these securities during the years ended July 31, 2026, 2025, and 2024.


## us-gaap:FinancingReceivablesTextBlock

[0001327567-26-000023:notes:159]
Financing Receivables
The following table summarizes our short-term and long-term financing receivables (in millions):

[0001327567-26-000023:notes:160]
|  | July 31, |
|  | 2026 |  | 2025 |
| Short-term financing receivables, gross | $ | 671 |  |  | $ | 806 |  |
| Unearned income | (74) |  |  | (86) |  |
| Allowance for credit losses | (5) |  |  | (5) |  |
| Short-term financing receivables, net | $ | 592 |  |  | $ | 715 |  |
| Long-term financing receivables, gross | $ | 1,013 |  |  | $ | 1,079 |  |
| Unearned income | (61) |  |  | (69) |  |
| Allowance for credit losses | (8) |  |  | (8) |  |
| Long-term financing receivables, net | $ | 944 |  |  | $ | 1,002 |  |

[0001327567-26-000023:notes:161]
The following table presents amortized cost basis of our financing receivables categorized by internal risk rating and year of origination (in millions):

[0001327567-26-000023:notes:162]
| Internal Risk Rating(1) |  | July 31, 2026 |  | July 31, 2025 |
|  | Fiscal Years Ended July 31, |  |  |  | Fiscal Years Ended July 31, |  |
|  | 2026 |  | 2025 |  | 2024 |  | 2023 |  | 2022 |  | Total |  | 2025 |  | 2024 |  | 2023 |  | 2022 |  | 2021 |  | Total |
| 1 to 4 |  | $ | 411 |  |  | $ | 208 |  |  | $ | 438 |  |  | $ | 102 |  |  | $ | 5 |  |  | $ | 1,164 |  |  | $ | 261 |  |  | $ | 732 |  |  | $ | 242 |  |  | $ | 9 |  |  | $ | 18 |  |  | $ | 1,262 |  |
| 5 to 6 |  | 156 |  |  | 92 |  |  | 85 |  |  | 9 |  |  | — |  |  | 342 |  |  | 174 |  |  | 226 |  |  | 50 |  |  | — |  |  | — |  |  | 450 |  |
| 7 to 10 |  | — |  |  | 32 |  |  | 10 |  |  | 1 |  |  | — |  |  | 43 |  |  | — |  |  | 4 |  |  | 14 |  |  | — |  |  | — |  |  | 18 |  |
| Amortized cost basis of financing receivables |  | $ | 567 |  |  | $ | 332 |  |  | $ | 533 |  |  | $ | 112 |  |  | $ | 5 |  |  | $ | 1,549 |  |  | $ | 435 |  |  | $ | 962 |  |  | $ | 306 |  |  | $ | 9 |  |  | $ | 18 |  |  | $ | 1,730 |  |

[0001327567-26-000023:notes:163]
(1)Internal risk ratings are categorized as 1 through 10, with the lowest rating representing the highest quality.

[0001327567-26-000023:notes:164]
During the years ended July 31, 2026 and 2025, we sold $54 million and $38 million, respectively, of our financing receivables. The associated gains and losses were not material.
There was no significant activity in allowance for credit losses during the years ended July 31, 2026 and 2025. Past due amounts on financing receivables were not material as of July 31, 2026 and 2025.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001327567-26-000023:notes:165]
Derivative Instruments
As of July 31, 2026 and 2025, the notional amount of our outstanding foreign currency forward contracts designated as cash flow hedges was $1.7 billion and $964 million, respectively. Refer to Note 3. Fair Value Measurements for the fair value of our derivative instruments as reported on our consolidated balance sheets as of July 31, 2026 and 2025.

[0001327567-26-000023:notes:166]
As of July 31, 2026, unrealized gains and losses in AOCI related to our cash flow hedges were a net loss of $15 million, substantially all of which is expected to be recognized into earnings within the next 12 months. As of July 31, 2025, unrealized gains and losses in AOCI related to our cash flow hedges were a net gain of $40 million.

[0001327567-26-000023:notes:167]
As of July 31, 2026 and 2025, the notional amount of our outstanding foreign currency forward contracts not designated as hedging instruments was $522 million and $504 million, respectively.


## us-gaap:InventoryDisclosureTextBlock

[0001327567-26-000023:notes:168]
Inventory
As of July 31, 2026 and 2025, our inventory balance was $117 million and $113 million, respectively.
For the years ended July 31, 2026, 2025, and 2024, inventory write-downs and excess manufacturing purchase commitment charges were $4 million, $71 million, and $25 million, respectively.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001327567-26-000023:notes:169]
Acquisitions
Fiscal 2026

[0001327567-26-000023:notes:170]
Chronosphere, Inc.

[0001327567-26-000023:notes:171]
On January 29, 2026, we completed our acquisition of Chronosphere, a privately-held observability technology company. The acquisition resulted in forming our next-generation observability platform. The total purchase consideration for the acquisition of Chronosphere was $3.0 billion, which consisted of the following (in millions):

[0001327567-26-000023:notes:172]
|  | Amount |
| Cash | $ | 2,842 |  |
| Fair value of replacement awards | 109 |  |
| Total | $ | 2,951 |  |

[0001327567-26-000023:notes:173]
As part of the acquisition, we issued $525 million of replacement equity awards, of which the portion attributable to services performed prior to the acquisition date was allocated to purchase consideration. The remaining fair value was allocated to future services and will be expensed over the remaining service periods as share-based compensation. The replacement equity awards included 2 million shares of our restricted common stock. These shares of restricted common stock vest over a period of two to three years from the date of issuance.

[0001327567-26-000023:notes:174]
We have accounted for this transaction as a business combination and allocated the purchase consideration to assets acquired and liabilities assumed based on preliminary estimated fair values, as presented in the following table (in millions):

[0001327567-26-000023:notes:175]
|  | Amount |
| Goodwill | $ | 2,364 |  |
| Identified intangible assets | 565 |  |
| Cash | 57 |  |
| Net liabilities assumed | (35) |  |
| Total | $ | 2,951 |  |

[0001327567-26-000023:notes:176]
Goodwill generated from this business combination is primarily attributable to the assembled workforce and expected post-acquisition synergies from integrating the Chronosphere observability platform into our business. The goodwill is not deductible for U.S. income tax purposes.

[0001327567-26-000023:notes:177]
The following table presents details of the identified intangible assets acquired (in millions, except years):

[0001327567-26-000023:notes:178]
|  | Fair Value |  | Estimated Useful Life |
| Developed technology | $ | 300 |  |  | 5 years |
| Customer relationships | 255 |  |  | 6 years - 10 years |
| Trade name and trademarks | 10 |  |  | 1 year |
| Total | $ | 565 |  |  |  |

[0001327567-26-000023:notes:179]
CyberArk Software Ltd.

[0001327567-26-000023:notes:180]
On February 11, 2026, we completed our acquisition of CyberArk, an identity security company, forming our next-generation identity security platform. CyberArk shareholders received $45.00 in cash and 2.2005 shares of our common stock for each CyberArk share. The total purchase consideration for the acquisition of CyberArk was $21.1 billion, which consisted of the following (in millions):

[0001327567-26-000023:notes:181]
|  | Amount |
| Cash | $ | 2,308 |  |
| Common stock (112 million shares) | 18,488 |  |
| Fair value of replacement awards | 265 |  |
| Total | $ | 21,061 |  |

[0001327567-26-000023:notes:182]
As part of the acquisition, we issued $945 million of replacement equity awards, of which the portion attributable to services performed prior to the acquisition date was allocated to purchase consideration. The remaining fair value was allocated to future services and will be expensed over the remaining service periods as share-based compensation.

[0001327567-26-000023:notes:183]
|  | Amount |
| Goodwill | $ | 14,800 |  |
| Identified intangible assets | 6,279 |  |
| Cash and cash equivalents | 743 |  |
| Accounts receivable, net of allowance for credit losses | 312 |  |
| Short-term and long-term investments | 1,217 |  |
| Net assets acquired | 60 |  |
| Convertible senior notes | (1,303) |  |
| Deferred revenue | (776) |  |
| Deferred tax liabilities | (271) |  |
| Total | $ | 21,061 |  |

[0001327567-26-000023:notes:184]
Goodwill generated from this business combination is primarily attributable to the assembled workforce and expected post-acquisition synergies from incorporating the CyberArk next-generation identity security platform into our business. Substantially all of the goodwill is deductible for U.S. income tax purposes.

[0001327567-26-000023:notes:185]
|  | Fair Value |  | Estimated Useful Life |  |  |
| Developed technology | $ | 2,537 |  |  | 5 years - 7 years |  |  |
| Platform renewals | 3,500 |  |  | 12 years - 14 years |  |  |
| Customer contracts | 219 |  |  | 2 years |  |  |
| Trade name | 23 |  |  | 1 year |  |  |
| Total | $ | 6,279 |  |  |  |  |  |

[0001327567-26-000023:notes:186]
For the year ended July 31, 2026, transaction costs related to CyberArk acquisition were $56 million, which were primarily included in general and administrative expense on our consolidated statements of operations.

[0001327567-26-000023:notes:187]
In connection with our acquisition integration strategy, we initiated a plan to optimize the combined entity’s workforce for a total estimated cost of $60 million. The activities associated with this plan are expected to be substantially completed by the end of fiscal 2027. Employee severance costs are recognized upon notification. If service is required beyond the minimum retention period, expense is recognized ratably over the future service period. During the year ended July 31, 2026, we made cash payments of $18 million under the plan. As of July 31, 2026, a liability of $14 million related to employee severance was included in accrued compensation on our consolidated balance sheets.

[0001327567-26-000023:notes:188]
The following table summarizes employee severance charges related to the CyberArk acquisition (in millions):

[0001327567-26-000023:notes:189]
|  | Year Ended July 31, 2026 |
|  | Cash Compensation |  | Share-based Compensation |  | Total |
| Cost of subscription and support revenue | $ | 2 |  |  | $ | — |  |  | $ | 2 |  |
| Research and development | 1 |  |  | — |  |  | 1 |  |
| Sales and marketing | 16 |  |  | 16 |  |  | 32 |  |
| General and administrative | 13 |  |  | 1 |  |  | 14 |  |
| Total | $ | 32 |  |  | $ | 17 |  |  | $ | 49 |  |

[0001327567-26-000023:notes:190]
Koi Security Ltd.

[0001327567-26-000023:notes:191]
On April 14, 2026, we completed our acquisition of Koi Security Ltd. (“Koi”), a privately-held endpoint posture management company. The acquisition adds agentic endpoint security capabilities to our security operations platform and enhances Prisma AIRS™. The total purchase consideration for the acquisition of Koi was $231 million, substantially all of which is comprised of cash.

[0001327567-26-000023:notes:192]
As part of the acquisition, we issued $61 million of replacement equity awards, which were allocated to future services and will be expensed over the remaining service periods as share-based compensation. The replacement equity awards included 0.3 million shares of our restricted common stock. These shares of restricted common stock vest over a period of three years from the date of issuance.

[0001327567-26-000023:notes:193]
|  | Amount |
| Goodwill | $ | 169 |  |
| Identified intangible asset | 35 |  |
| Cash and restricted cash | 20 |  |
| Net assets acquired | 7 |  |
| Total | $ | 231 |  |

[0001327567-26-000023:notes:194]
Goodwill generated from this business combination is primarily attributable to the assembled workforce and expected post-acquisition synergies from integrating Koi’s technology into our platforms. The goodwill is deductible for U.S. income tax purposes.

[0001327567-26-000023:notes:195]
The following table presents details of the identified intangible asset acquired (in millions, except years):

[0001327567-26-000023:notes:196]
|  | Fair Value |  | Estimated Useful Life |
| Developed technology | $ | 35 |  |  | 5 years |

[0001327567-26-000023:notes:197]
Portkey, Inc.

[0001327567-26-000023:notes:198]
On May 29, 2026, we completed our acquisition of Portkey, Inc. (“Portkey”), a privately-held AI Gateway company. The acquisition enhances the capabilities of Prisma AIRS™. The total purchase consideration for the acquisition of Portkey was $117 million, substantially all of which is comprised of cash.

[0001327567-26-000023:notes:199]
As part of the acquisition, we issued $2 million of replacement equity awards, which were allocated to future services and will be expensed over the remaining service periods as share-based compensation.

[0001327567-26-000023:notes:200]
|  | Amount |
| Goodwill | $ | 110 |  |
| Identified intangible assets | 15 |  |
| Cash and cash equivalents | 17 |  |
| Net liabilities assumed | (25) |  |
| Total | $ | 117 |  |

[0001327567-26-000023:notes:201]
Goodwill generated from this business combination is primarily attributable to the assembled workforce and expected post-acquisition synergies from integrating Portkey ’s technology into our platforms. The goodwill is not deductible for U.S. income tax purposes.

[0001327567-26-000023:notes:202]
|  | Fair Value |  | Estimated Useful Life |
| Developed technology | $ | 15 |  |  | 5 years |

[0001327567-26-000023:notes:203]
Embrace Mobile, Inc.

[0001327567-26-000023:notes:204]
On July 20, 2026, we entered into a definitive agreement to acquire Embrace Mobile, Inc. (“Embrace”), a privately-held user-focused observability company, in exchange for total consideration of $325 million in cash, subject to adjustments. We expect the acquisition to add high-fidelity Real User Monitoring (“RUM”) capabilities to our next-generation observability platform. Refer to Note 20. Subsequent Events for additional information.

[0001327567-26-000023:notes:205]
Console Systems, Inc.

[0001327567-26-000023:notes:206]
On July 29, 2026, we entered into a definitive agreement to acquire Console Systems, Inc. (“Console”), a privately-held company providing an AI-native platform that enables agentic workflows across enterprise operations, in exchange for total consideration of $500 million in cash, subject to adjustments. We expect the acquisition to deepen our agentic capabilities in Cortex. Refer to Note 20. Subsequent Events for additional information.

[0001327567-26-000023:notes:207]
Additional Acquisition-Related Information

[0001327567-26-000023:notes:208]
Since the date of acquisitions, the combined net impact of the Chronosphere and CyberArk acquisitions on our consolidated statements of operations was revenue of $930 million and operating loss of $797 million for the year ended July 31, 2026.

[0001327567-26-000023:notes:209]
The following unaudited pro forma financial information summarizes the combined results of operations for Palo Alto Networks, Chronosphere, and CyberArk, as though the companies were combined as of the beginning of our fiscal 2025 (in millions):

[0001327567-26-000023:notes:210]
|  |  |  | Year Ended July 31, |
|  |  |  |  |  | 2026 |  | 2025 |
| Total revenue |  |  |  |  | $ | 12,312 |  |  | $ | 10,486 |  |
| Net loss |  |  |  |  | $ | (114) |  |  | $ | (37) |  |

[0001327567-26-000023:notes:211]
The unaudited pro forma financial information for the years ended July 31, 2026 and 2025 combines the historical results of Palo Alto Networks and Chronosphere for these periods with the historical results of CyberArk for the years ended June 30, 2026 and 2025, respectively. The unaudited pro forma financial information include adjustments attributable to our acquisition of Chronosphere and CyberArk, including amortization of acquired intangible assets, share-based compensation expense from assumed replacement equity awards, acquisition-related transaction costs, employee severance costs under the workforce optimization plan, and income tax impact. We elected the fair value option to account for the convertible senior notes acquired from CyberArk. During the post-acquisition period presented, we recognized approximately $562 million of net losses related to changes in fair value of the convertible senior notes and Capped Calls. Such amounts are reflected in our historical post-acquisition results but are not included as adjustments to the historical periods presented in the unaudited pro forma financial information. The unaudited pro forma financial information is for informational purposes only and is not necessarily indicative of the results of operations that would have been achieved if the acquisitions had taken place at the beginning of our fiscal 2025 or of the results of our future operations of the combined business.

[0001327567-26-000023:notes:212]
Additional information related to our fiscal 2026 acquisitions, such as that related to income tax and other contingencies existing as of the acquisition date, may become known during the remainder of the measurement period, not to exceed 12 months from the acquisition date, which may result in changes to the amounts and allocations recorded.

[0001327567-26-000023:notes:213]
Fiscal 2025

[0001327567-26-000023:notes:214]
IBM QRadar Assets

[0001327567-26-000023:notes:215]
On August 31, 2024, we completed the acquisition of certain IBM QRadar assets, including certain intellectual property rights, customer relationships, and software as a service customer contracts. The total purchase consideration for the acquisition was $1.1 billion, which consisted of the following (in millions):

[0001327567-26-000023:notes:216]
|  | Amount |
| Cash | $ | 500 |  |
| Fair value of contingent consideration liability on the acquisition date | 649 |  |
| Return of purchase consideration | (6) |  |
| Total | $ | 1,143 |  |

[0001327567-26-000023:notes:217]
As part of the acquisition, we agreed to make post-closing payments to IBM contingent upon customers entering into qualified new transactions through June 30, 2028. We also expect to receive a return of purchase consideration of $6 million due to timing of transition of certain underlying customer contracts, of which $2 million and $3 million were received during the years ended July 31, 2026 and 2025, respectively. In addition, we have entered into a transition services arrangement with IBM, under which IBM will perform certain services supporting the acquired assets and customers for a period of time that ends in the fiscal quarter ending October 31, 2026.

[0001327567-26-000023:notes:218]
Payments related to the contingent consideration liability commenced in the fiscal quarter ended October 31, 2025 and are expected to continue through the fiscal quarter ending October 31, 2028. The estimated range of undiscounted contingent consideration is between $0.3 billion and $0.5 billion. Refer to Note 3. Fair Value Measurements, for more information on the fair value of our contingent consideration liability.

[0001327567-26-000023:notes:219]
We have accounted for this transaction as a business combination and allocated the purchase consideration to assets acquired and liabilities assumed based on estimated fair values, as presented in the following table (in millions):

[0001327567-26-000023:notes:220]
|  | Amount |
| Goodwill | $ | 701 |  |
| Identified intangible assets | 476 |  |
| Net liabilities assumed | $ | (34) |  |
| Total | $ | 1,143 |  |

[0001327567-26-000023:notes:221]
Goodwill generated from this business combination is primarily attributable to the expected post-acquisition synergies from increased market penetration to support the growth of our Cortex Security Operations business. The goodwill is deductible for U.S. income tax purposes.

[0001327567-26-000023:notes:222]
|  | Fair Value |  | Estimated Useful Life |
| Customer relationships | $ | 464 |  |  | 12 years |
| Developed technology | 12 |  |  | 2 years |
| Total | $ | 476 |  |  |  |

[0001327567-26-000023:notes:223]
Protect AI, Inc.

[0001327567-26-000023:notes:224]
On July 22, 2025, we completed our acquisition of Protect AI, Inc. (“Protect AI”), a privately-held cyber security company focused on AI security. The total purchase consideration for the acquisition of Protect AI was $635 million, which consisted of the following (in millions):

[0001327567-26-000023:notes:225]
|  | Amount |
| Cash | $ | 608 |  |
| Fair value of replacement awards | 27 |  |
| Total | $ | 635 |  |

[0001327567-26-000023:notes:226]
As part of the acquisition, we issued $107 million of replacement equity awards, of which the portion attributable to services performed prior to the acquisition date was allocated to purchase consideration. The remaining fair value was allocated to future services and will be expensed over the remaining service periods as share-based compensation.

[0001327567-26-000023:notes:227]
|  | Amount |
| Goodwill | $ | 516 |  |
| Identified intangible assets | 70 |  |
| Cash | 51 |  |
| Net liabilities assumed | (2) |  |
| Total | $ | 635 |  |

[0001327567-26-000023:notes:228]
Goodwill generated from this business combination is primarily attributable to the assembled workforce and expected post-acquisition synergies from integrating Protect AI technology into our platforms. The goodwill is not deductible for U.S. income tax purposes.

[0001327567-26-000023:notes:229]
|  | Fair Value |  | Estimated Useful Life |
| Developed technology | $ | 70 |  |  | 5 years |

[0001327567-26-000023:notes:230]
Fiscal 2024

[0001327567-26-000023:notes:231]
Dig Security Solutions Ltd.

[0001327567-26-000023:notes:232]
On December 5, 2023, we completed our acquisition of Dig Security Solutions Ltd. (“Dig”), a privately-held cyber security company providing a data security posture management solution for multi-cloud environments. The total purchase consideration for the acquisition of Dig was $255 million, which consisted of the following (in millions):

[0001327567-26-000023:notes:233]
|  | Amount |
| Cash | $ | 248 |  |
| Fair value of replacement awards | 7 |  |
| Total | $ | 255 |  |

[0001327567-26-000023:notes:234]
As part of the acquisition, we issued replacement equity awards, which included 0.4 million shares of our restricted common stock. The total fair value of the replacement equity awards was $72 million, of which the portion attributable to services performed prior to the acquisition date was allocated to purchase consideration. The remaining fair value was allocated to future services and will be expensed over the remaining service periods as share-based compensation.

[0001327567-26-000023:notes:235]
|  | Amount |
| Goodwill | $ | 186 |  |
| Identified intangible assets | 45 |  |
| Cash and restricted cash | 22 |  |
| Net assets acquired | 2 |  |
| Total | $ | 255 |  |

[0001327567-26-000023:notes:236]
Goodwill generated from this business combination is primarily attributable to the assembled workforce and expected post-acquisition synergies from integrating Dig technology into our platforms. The goodwill is deductible for U.S. income tax purposes.

[0001327567-26-000023:notes:237]
|  | Fair Value |  | Estimated Useful Life |
| Developed technology | $ | 45 |  |  | 5 years |

[0001327567-26-000023:notes:238]
Talon Cyber Security Ltd.

[0001327567-26-000023:notes:239]
On December 28, 2023, we completed our acquisition of Talon Cyber Security Ltd. (“Talon”), a privately-held cyber security company providing a secure enterprise browser solution. The total purchase consideration for the acquisition of Talon was $459 million, which consisted of the following (in millions):

[0001327567-26-000023:notes:240]
|  | Amount |
| Cash | $ | 439 |  |
| Fair value of replacement awards | 20 |  |
| Total | $ | 459 |  |

[0001327567-26-000023:notes:241]
As part of the acquisition, we issued replacement equity awards, which included 0.6 million shares of our restricted common stock. The total fair value of the replacement equity awards was $110 million, of which the portion attributable to services performed prior to the acquisition date was allocated to purchase consideration. The remaining fair value was allocated to future services and will be expensed over the remaining service periods as share-based compensation.

[0001327567-26-000023:notes:242]
|  | Amount |
| Goodwill | $ | 237 |  |
| Identified intangible assets | 132 |  |
| Cash and restricted cash | 54 |  |
| Net assets acquired | 36 |  |
| Total | $ | 459 |  |

[0001327567-26-000023:notes:243]
Goodwill generated from this business combination is primarily attributable to the assembled workforce and expected post-acquisition synergies from integrating Talon technology into our platforms. The goodwill is deductible for U.S. income tax purposes.

[0001327567-26-000023:notes:244]
|  | Fair Value |  | Estimated Useful Life |
| Developed technology | $ | 132 |  |  | 5 years |


## us-gaap:ScheduleOfBusinessAcquisitionsByAcquisitionTextBlock

[0001327567-26-000023:notes:245]
The total purchase consideration for the acquisition of Chronosphere was $3.0 billion, which consisted of the following (in millions):

[0001327567-26-000023:notes:246]
The total purchase consideration for the acquisition of CyberArk was $21.1 billion, which consisted of the following (in millions):

[0001327567-26-000023:notes:247]
The total purchase consideration for the acquisition was $1.1 billion, which consisted of the following (in millions):

[0001327567-26-000023:notes:248]
The total purchase consideration for the acquisition of Protect AI was $635 million, which consisted of the following (in millions):

[0001327567-26-000023:notes:249]
The total purchase consideration for the acquisition of Dig was $255 million, which consisted of the following (in millions):

[0001327567-26-000023:notes:250]
The total purchase consideration for the acquisition of Talon was $459 million, which consisted of the following (in millions):


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001327567-26-000023:notes:251]
Goodwill and Intangible Assets
Goodwill

[0001327567-26-000023:notes:252]
The following table presents details of our goodwill during the year ended July 31, 2026 (in millions):

[0001327567-26-000023:notes:253]
|  | Amount |
| Balance as of July 31, 2025 | $ | 4,567 |  |
| Goodwill acquired | 17,443 |  |
| Balance as of July 31, 2026 | $ | 22,010 |  |

[0001327567-26-000023:notes:254]
Purchased Intangible Assets

[0001327567-26-000023:notes:255]
The following table presents details of our purchased intangible assets (in millions):

[0001327567-26-000023:notes:256]
|  | July 31, |
|  | 2026 |  | 2025 |
|  | Gross Carrying Amount |  | Accumulated Amortization |  | Net Carrying Amount |  | Gross Carrying Amount |  | Accumulated Amortization |  | Net Carrying Amount |
| Intangible assets subject to amortization: |  |  |  |  |  |  |  |  |  |  |  |
| Developed technology | $ | 3,402 |  |  | $ | (614) |  |  | $ | 2,788 |  |  | $ | 536 |  |  | $ | (274) |  |  | $ | 262 |  |
| Customer relationships and platform renewals | 4,356 |  |  | (320) |  |  | 4,036 |  |  | 609 |  |  | (123) |  |  | 486 |  |
| Customer contracts | 219 |  |  | (55) |  |  | 164 |  |  | — |  |  | — |  |  | — |  |
| Acquired intellectual property | 24 |  |  | (12) |  |  | 12 |  |  | 24 |  |  | (9) |  |  | 15 |  |
| Trade name and trademarks | 33 |  |  | (16) |  |  | 17 |  |  | — |  |  | — |  |  | — |  |
| Other | — |  |  | — |  |  | — |  |  | 1 |  |  | (1) |  |  | — |  |
| Total purchased intangible assets | $ | 8,034 |  |  | $ | (1,017) |  |  | $ | 7,017 |  |  | $ | 1,170 |  |  | $ | (407) |  |  | $ | 763 |  |

[0001327567-26-000023:notes:257]
The following table summarizes amortization expense of our intangible assets (in millions):

[0001327567-26-000023:notes:258]
|  |  |  | Year Ended July 31, |
|  |  |  |  |  | 2026 |  | 2025 |  | 2024 |
| Cost of product revenue |  |  |  |  | $ | 75 |  |  | $ | — |  |  | $ | — |  |
| Cost of subscription and support revenue |  |  |  |  | 343 |  |  | 111 |  |  | 98 |  |
| Sales and marketing |  |  |  |  | 222 |  |  | 55 |  |  | 22 |  |
| General and administrative |  |  |  |  | — |  |  | — |  |  | 1 |  |
| Total intangible assets amortization |  |  |  |  | $ | 640 |  |  | $ | 166 |  |  | $ | 121 |  |

[0001327567-26-000023:notes:259]
The following table summarizes estimated future amortization expense of our intangible assets subject to amortization as of July 31, 2026 (in millions):

[0001327567-26-000023:notes:260]
|  |  |  | Fiscal years ending July 31, |
|  | Total |  | 2027 |  | 2028 |  | 2029 |  | 2030 |  | 2031 |  | 2032 and Thereafter |
| Future amortization expense | $ | 7,017 |  |  | $ | 1,081 |  |  | $ | 989 |  |  | $ | 908 |  |  | $ | 892 |  |  | $ | 667 |  |  | $ | 2,480 |  |


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001327567-26-000023:notes:261]
Property and Equipment
The following table presents details of our property and equipment, net (in millions):

[0001327567-26-000023:notes:262]
We recognized depreciation expense of $111 million, $94 million, and $85 million related to property and equipment during the years ended July 31, 2026, 2025, and 2024, respectively.

[0001327567-26-000023:notes:263]
During the year ended July 31, 2026, we purchased 14.5 acres of land adjacent to our headquarters in Santa Clara, California for $91 million to accommodate future expansion of our headquarters.


## us-gaap:DebtDisclosureTextBlock

[0001327567-26-000023:notes:264]
Debt
Convertible Senior Notes, Note Hedges, and Warrants

[0001327567-26-000023:notes:265]
2025 Convertible Senior Notes

[0001327567-26-000023:notes:266]
In June 2020, we issued $2.0 billion aggregate principal amount of 0.375% Convertible Senior Notes due 2025 (the “2025 Notes”). The 2025 Notes bear interest at a fixed rate of 0.375% per year, payable semi-annually in arrears on June 1 and December 1 of each year, beginning on December 1, 2020. The 2025 Notes were converted prior to or settled on the maturity date of June 1, 2025 in accordance with their terms.

[0001327567-26-000023:notes:267]
The following table presents details of our 2025 Notes (number of shares in millions):

[0001327567-26-000023:notes:268]
|  | Conversion Rate per $1,000 Principal |  | Initial Conversion Price |  | Convertible Date |  | Initial Number of Shares |
| 2025 Notes | 20.1612 |  |  | $ | 49.60 |  |  | March 1, 2025 |  | 40 |  |

[0001327567-26-000023:notes:269]
Holders of the 2025 Notes were able to early convert their 2025 Notes in fiscal 2024 and fiscal 2025 up to March 1, 2025, and conversion requests received on or after March 1, 2025 were settled upon maturity of the 2025 Notes. During the years ended July 31, 2025 and 2024, we repaid in cash $966 million and $1.0 billion, respectively, in aggregate principal amount of the 2025 Notes. We also issued 14 million shares of our common stock to the holders of the 2025 Notes during each of the years ended July 31, 2025 and 2024, for the conversion value in excess of the principal amount. These shares were fully offset by shares we received from the corresponding exercise of the associated note hedges.

[0001327567-26-000023:notes:270]
The following table sets forth interest expense recognized related to our 2025 Notes (dollars in millions):

[0001327567-26-000023:notes:271]
|  |  |  |  |  |  |  |  |  | Year Ended July 31, |
|  |  |  |  |  |  |  |  |  | 2025 |  |  |  |  |  | 2024 |  |  |
| Contractual interest expense |  |  |  |  |  |  |  |  | $ | 2 |  |  |  |  |  |  | $ | 5 |  |  |  |
| Amortization of debt issuance costs |  |  |  |  |  |  |  |  | 1 |  |  |  |  |  |  | 3 |  |  |  |
| Total interest expense recognized |  |  |  |  |  |  |  |  | $ | 3 |  |  |  |  |  |  | $ | 8 |  |  |  |
| Effective interest rate of the liability component |  |  |  |  |  |  |  |  | 0.6 | % |  |  |  |  |  | 0.6 | % |  |  |

[0001327567-26-000023:notes:272]
2025 Note Hedges

[0001327567-26-000023:notes:273]
To minimize the impact of potential economic dilution upon conversion of our 2025 Notes, we entered into separate convertible note hedge transactions (the “2025 Note Hedges”) with respect to our common stock concurrent with the issuance of the 2025 Notes.

[0001327567-26-000023:notes:274]
The following table presents details of our Note Hedges (in millions):

[0001327567-26-000023:notes:275]
|  | Initial Number of Shares |  | Aggregate Purchase |
| 2025 Note Hedges | 40 |  |  | $ | 371 |  |

[0001327567-26-000023:notes:276]
The 2025 Note Hedges covered shares of our common stock at a strike price per share that corresponded to the initial conversion price of the 2025 Notes and were exercisable upon conversion of the 2025 Notes. The 2025 Note Hedges expired upon maturity of the 2025 Notes. The 2025 Note Hedges were separate transactions and were not part of the terms of the 2025 Notes. Holders of the 2025 Notes did not have any rights with respect to the 2025 Note Hedges. Any shares of our common stock that were receivable by us under the 2025 Note Hedges were excluded from the calculation of diluted earnings per share as they were antidilutive.

[0001327567-26-000023:notes:277]
As a result of the conversions of the 2025 Notes during the years ended July 31, 2025 and 2024, we exercised the corresponding portion of our 2025 Note Hedges and received 14 million shares of our common stock during each of the respective periods.

[0001327567-26-000023:notes:278]
2025 Warrants

[0001327567-26-000023:notes:279]
Separately, but concurrently with the issuance of our 2025 Notes, we entered into transactions whereby we sold warrants (the “2025 Warrants”) to acquire shares of our common stock, subject to anti-dilution adjustments. The 2025 Warrants were exercisable over 60 scheduled trading days beginning September 2025.

[0001327567-26-000023:notes:280]
The following table presents details of our 2025 Warrants (in millions, except per share data):

[0001327567-26-000023:notes:281]
|  | Initial Number of Shares |  | Strike Price per Share |  | Aggregate Proceeds |
| 2025 Warrants | 40 |  |  | $ | 68.08 |  |  | $ | 203 |  |

[0001327567-26-000023:notes:282]
The shares that were issuable under the 2025 Warrants were included in the calculation of diluted earnings per share when the average market value per share of our common stock for the reporting period exceeded the strike price of the 2025 Warrants.

[0001327567-26-000023:notes:283]
During the year ended July 31, 2026, we net settled all of the 2025 Warrants with the issuance of 27 million shares of our common stock with a fair value of $5.6 billion. The number of net shares issued was determined based on the number of 2025 Warrants exercised multiplied by the difference between the strike price of the 2025 Warrants and their daily volume-weighted-average stock price.

[0001327567-26-000023:notes:284]
2030 Convertible Senior Notes and Capped Calls

[0001327567-26-000023:notes:285]
2030 Convertible Senior Notes

[0001327567-26-000023:notes:286]
In February 2026, in connection with the acquisition of CyberArk, we entered into a supplemental indenture (the “Supplemental Indenture”) to the Indenture, dated as of June 10, 2025 (together with the Supplemental Indenture, the “Indenture”), between CyberArk, as issuer, and U.S. Bank Trust Company, National Association, as trustee, governing CyberArk’s $1.25 billion aggregate principal amount of 0.0% Convertible Senior Notes due 2030 (the “2030 Notes”). As a result of our acquisition of CyberArk and pursuant to the Supplemental Indenture, the 2030 Notes are no longer convertible into ordinary shares of CyberArk. The conversion feature has been modified such that each $1,000 principal amount of the 2030 Notes are exchangeable for a combination of (i) approximately 4.3161 shares of our common stock, which is the effective initial conversion rate, and (ii) cash of $88.2630, subject to adjustment under the Indenture. These modifications result in the 2030 Notes being exchangeable initially for 5.4 million shares of our common stock with an effective initial conversion price of approximately $211.24 per share of common stock, subject to adjustments, and an initial cash amount of $110 million. The 2030 Notes are unsecured, unsubordinated obligations, and the Indenture does not contain any financial covenants or restrictions on the payments of dividends, the incurrence of indebtedness, or the issuance or repurchase of securities by us or any of our subsidiaries. The 2030 Notes mature on June 15, 2030.

[0001327567-26-000023:notes:287]
We may redeem for cash all or, subject to certain limitations, any portion of the 2030 Notes, at our option, on or after June 20, 2028 and on or prior to the 31st scheduled trading day immediately preceding the maturity date if the last reported sale price of our common stock has been at least $280.75 per share for at least 20 trading days (whether or not consecutive) during any 30 consecutive trading day period ending on and including the trading day preceding the date on which we provide notice of redemption. Any redemption of the 2030 Notes will be at a price equal to 100% of the principal amount of the 2030 Notes, plus accrued and unpaid special interest, if any, up to, but excluding, the redemption date. If we call any or all of the 2030 Notes for redemption, holders may convert such 2030 Notes called for redemption at an increased conversion rate at any time prior to the close of business on the second scheduled trading day immediately preceding the redemption date.

[0001327567-26-000023:notes:288]
Holders of the 2030 Notes may surrender their 2030 Notes for conversion at their option at any time prior to the close of business on the business day immediately preceding February 15, 2030 under the following circumstances:

[0001327567-26-000023:notes:289]
•during any calendar quarter commencing after the calendar quarter ended on September 30, 2025 (and only during such calendar quarter), if the last reported sale price of our common stock is greater than or equal to $280.75 per share of our common stock on each applicable trading day for at least 20 trading days (whether or not consecutive) during the period of 30 consecutive trading days ending on the last trading day of the immediately preceding calendar quarter (the “sale price condition”);

[0001327567-26-000023:notes:290]
•during the five business day period immediately after any ten consecutive trading day period (the “measurement period”) in which the trading price per $1,000 principal amount of the 2030 Notes for each trading day of the measurement period was less than 98% of the aggregate of (i) the product of the last reported sale price of our common stock on each such trading day and the conversion rate for the 2030 Notes on each such trading day and (ii) $88.2630; or

[0001327567-26-000023:notes:291]
•upon the occurrence of specified corporate events as described in the Indenture.

[0001327567-26-000023:notes:292]
On or after February 15, 2030, holders may surrender all or, subject to certain limitations, any portion of their 2030 Notes for conversion at any time prior to the close of business on the second scheduled trading day immediately preceding the maturity date, and such conversions will be settled upon the maturity date.

[0001327567-26-000023:notes:293]
Upon any conversion of the 2030 Notes, holders of the 2030 Notes will receive cash equal to the aggregate principal amount of the 2030 Notes to be converted, and, at our election, cash or a combination of cash and shares of our common stock for any amounts in excess of the aggregate principal amount of the 2030 Notes converted. The conversion rate will be subject to adjustment in connection with certain events. Holders of the 2030 Notes who convert their 2030 Notes in connection with certain corporate events that constitute a “make-whole fundamental change” under the Indenture are, under certain circumstances, entitled to an increase in the conversion rate for a certain period of time. Additionally, following the occurrence of a corporate event that constitutes a “fundamental change” under the Indenture, holders of the 2030 Notes may require us to repurchase for cash all or a portion of the 2030 Notes at a repurchase price equal to 100% of the principal amount of the 2030 Notes plus accrued and unpaid special interest, if any, up to, but excluding, the fundamental change repurchase date.

[0001327567-26-000023:notes:294]
Our acquisition of CyberArk constituted both a “make-whole fundamental change” and a “fundamental change” under the Indenture. In connection with the make-whole fundamental change, holders had the option to convert all or a portion of their 2030 Notes at an increased conversion rate equal to a combination of approximately 5.5690 shares of our common stock and $113.8860 in cash per $1,000 principal amount (the “make-whole conversion right”). We elected cash settlement as the settlement method for any 2030 Notes surrendered during the make-whole fundamental change period. Certain holders of the 2030 Notes surrendered $153 million in aggregate principal amount of the 2030 Notes during the make-whole fundamental change period for conversion, which were settled for $160 million in cash on May 7, 2026. In connection with the fundamental change, holders had the right to tender all or a portion of their 2030 Notes for cash (the “repurchase right”) pursuant to our offer to purchase in accordance with the obligations under the 2030 Notes. No holders exercised the repurchase right to tender their 2030 Notes. The make-whole conversion right and repurchase right resulting from our acquisition of CyberArk expired on March 20, 2026.

[0001327567-26-000023:notes:295]
As of July 31, 2026, after giving effect to the 2030 Notes surrendered for conversion during the make-whole conversion period, the remaining outstanding principal balance of the 2030 Notes was $1.1 billion. As of July 31, 2026, the 2030 Notes were classified as a long-term liability on our consolidated balance sheets since the sale price condition was not met during the calendar quarter ended June 30, 2026. The related fair value of $1.8 billion was determined based on the closing trading price per $100 of the 2030 Notes as of the last day of trading for the period. The fair value of the 2030 Notes is primarily affected by the trading price of our common stock and market interest rates.

[0001327567-26-000023:notes:296]
For the year ended July 31, 2026, changes in fair value of 2030 Notes included in earnings were a loss of $620 million, and changes in fair value attributable to instrument-specific credit risk included in AOCI were a loss of $11 million.

[0001327567-26-000023:notes:297]
Capped Calls

[0001327567-26-000023:notes:298]
In connection with our acquisition of CyberArk, on February 11, 2026, we entered into amendments to the Capped Calls that CyberArk purchased from certain financial institutions in connection with the issuance of the 2030 Notes. Under the amendments, we assumed the rights and obligations of CyberArk with respect to the Capped Calls and modified the Capped Calls to require the delivery of shares of our common stock in lieu of ordinary shares of CyberArk. The Capped Calls have a strike price of approximately $211.24 per share, subject to certain adjustments, which corresponds to the effective initial conversion price of our 2030 Notes. The Capped Calls have cap prices ranging from approximately $287.21 to $291.44 per share, subject to certain adjustments. In connection with exercising the Capped Calls, we may elect that the Capped Calls be settled either entirely in cash or a combination of our common stock and cash. The Capped Calls are separate transactions from the 2030 Notes, and holders of the 2030 Notes do not have any rights with respect to the Capped Calls.

[0001327567-26-000023:notes:299]
The Capped Calls cover shares of our common stock underlying the 2030 Notes, subject to anti-dilution adjustments substantially similar to those applicable to the 2030 Notes. In April 2026, we elected to terminate portions of the Capped Calls in exchange for $10 million in cash in connection with the $153 million in aggregate principal amount of the 2030 Notes surrendered by certain holders during the make-whole conversion period.

[0001327567-26-000023:notes:300]
As of July 31, 2026, the fair value of the outstanding Capped Calls was $153 million, determined using the Black-Scholes option pricing model and observable inputs, including the price of our common stock, volatility, remaining contractual term, and risk-free interest rate. For the year ended July 31, 2026, the change in fair value of Capped Calls was a gain of $58 million.

[0001327567-26-000023:notes:301]
Revolving Credit Facility

[0001327567-26-000023:notes:302]
On April 13, 2023, we entered into a credit agreement (the “Credit Agreement”) with certain institutional lenders that provides for a $400 million unsecured revolving credit facility (the “Credit Facility”), with an option to increase the amount of the Credit Facility by up to an additional $350 million, subject to certain conditions. The Credit Facility matures on April 13, 2028.

[0001327567-26-000023:notes:303]
The borrowings under the Credit Facility bear interest, at our option, at a base rate plus a spread of 0.000% to 0.375%, or an adjusted term Secured Overnight Financing Rate plus a spread of 1.000% to 1.375%, in each case with such spread being determined based on our leverage ratio. We are obligated to pay an ongoing commitment fee on undrawn amounts at a rate of 0.090% to 0.150%, depending on our leverage ratio. The interest rates and commitment fees are also subject to upward and downward adjustments based on our progress towards the achievement of certain sustainability goals.

[0001327567-26-000023:notes:304]
As of July 31, 2026, there were no amounts outstanding and no default or event of default has occurred under the Credit Agreement.


## us-gaap:LesseeOperatingLeasesTextBlock

[0001327567-26-000023:notes:305]
Leases
We have entered into various non-cancelable operating leases, primarily for our offices, with lease terms expiring through the year ending July 31, 2040. The most significant leases relate to our corporate headquarters in Santa Clara.

[0001327567-26-000023:notes:306]
In April 2026, we entered into three lease amendments to extend the lease terms of our current corporate headquarters in Santa Clara, California for a period of twelve years through July 2040. The leases contain rent holiday periods, scheduled rent increases, lease incentives, and renewal options which allow the lease terms to be extended through July 2052. Lease payments under the three lease amendments, net of lease incentives such as rent holidays and tenant improvement allowances, are approximately $469 million over the extended lease term through July 2040.

[0001327567-26-000023:notes:307]
During the years ended July 31, 2026, 2025, and 2024, our net cost for operating leases was $146 million, $122 million, and $105 million, respectively, primarily consisting of operating lease costs of $104 million, $88 million, and $76 million, respectively. Our net cost for operating leases also included variable lease costs, short-term lease costs, and sublease income in the periods presented.

[0001327567-26-000023:notes:308]
The following tables present additional information for our operating leases (in millions, except for years and percentages):

[0001327567-26-000023:notes:309]
|  | Year Ended July 31, |  |  |  |  |  |  |
|  | 2026 |  | 2025 |  | 2024 |  |  |  |  |  |  |
| Operating cash flows used in payments of operating lease liabilities | $ | 114 |  |  | $ | 91 |  |  | $ | 87 |  |  |  |  |  |  |  |
| Right-of-use assets obtained in exchange for new operating lease liabilities(1) | $ | 442 |  |  | $ | 27 |  |  | $ | 178 |  |  |  |  |  |  |  |

[0001327567-26-000023:notes:310]
(1)Includes $262 million in fiscal 2026 relating to the lease amendments of our corporate headquarters in Santa Clara.

[0001327567-26-000023:notes:311]
|  | July 31, 2026 |  | July 31, 2025 |  |  |  |  |  |  |
| Weighted-average remaining lease term | 10 years |  | 6 years |  |  |  |  |  |  |
| Weighted-average discount rate | 5.4 | % |  | 5.4 | % |  |  |  |  |  |  |

[0001327567-26-000023:notes:312]
The following table presents maturities of operating lease liabilities as of July 31, 2026 (in millions):

[0001327567-26-000023:notes:313]
|  | Amount |
| Fiscal years ending July 31: |  |
| 2027 | $ | 105 |  |
| 2028 | 85 |  |
| 2029 | 84 |  |
| 2030 | 121 |  |
| 2031 | 117 |  |
| 2032 and thereafter | 557 |  |
| Total operating lease payments | 1069 |  |
| Less: imputed interest | (276) |  |
| Present value of operating lease liabilities | $ | 793 |  |
| Current portion of operating lease liabilities(1) | $ | 67 |  |
| Long-term operating lease liabilities | $ | 726 |  |

[0001327567-26-000023:notes:314]
(1)Current portion of operating lease liabilities is included in accrued and other liabilities on our consolidated balance sheet.

[0001327567-26-000023:notes:315]
As of July 31, 2026, we had additional non-cancelable operating leases for office space that had been signed but had not yet commenced with total future minimum lease payments of $15 million. These leases are expected to commence in or after fiscal 2028, with lease terms ranging from four to five years.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001327567-26-000023:notes:316]
Commitments and Contingencies
Purchase Commitments

[0001327567-26-000023:notes:317]
We have entered into various non-cancelable agreements with cloud hosting service providers, under which we are committed to minimum or fixed purchases of certain cloud hosting services. In addition, in order to reduce manufacturing lead times and plan for adequate supply, we have entered into agreements with manufacturing partners and component suppliers to procure inventory based on our demand forecasts. Other purchase obligations include non-cancellable subscription agreements and other commitments in the normal course of business. The following table presents details of the aggregate future non-cancelable purchase commitments under these agreements as of July 31, 2026 (in millions):

[0001327567-26-000023:notes:318]
|  |  |  | Fiscal years ending July 31, |
|  | Total |  | 2027 |  | 2028 |  | 2029 |  | 2030 |  | 2031 |  | 2032 and Thereafter |  |  |
| Cloud | $ | 7,686 |  |  | $ | 143 |  |  | $ | 1,218 |  |  | $ | 1,329 |  |  | $ | 1,398 |  |  | $ | 1,725 |  |  | $ | 1,873 |  |  |  |
| Manufacturing | 370 |  |  | 370 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  |  |
| Other | 186 |  |  | 129 |  |  | 34 |  |  | 13 |  |  | 10 |  |  | — |  |  | — |  |  |  |
| Total | $ | 8,242 |  |  | $ | 642 |  |  | $ | 1,252 |  |  | $ | 1,342 |  |  | $ | 1,408 |  |  | $ | 1,725 |  |  | $ | 1,873 |  |  |  |

[0001327567-26-000023:notes:319]
Additionally, we have a $81 million minimum purchase commitment with a cloud hosting service provider through September 2027 with no specified annual commitments.

[0001327567-26-000023:notes:320]
Mutual Covenant Not to Sue and Release Agreement

[0001327567-26-000023:notes:321]
In January 2020, we executed a Mutual Covenant Not to Sue and Release Agreement for $50 million to extend an existing covenant not to sue for seven years. As the primary benefit of the arrangement was attributable to future use, the amount was recorded in other assets on our consolidated balance sheets and is amortized to cost of product revenue on our consolidated statements of operations over the estimated period of benefit of seven years.

[0001327567-26-000023:notes:322]
Guarantee

[0001327567-26-000023:notes:323]
As of July 31, 2026, we have multi-currency notional cash pool for a certain number of our entities with third-party banks. As part of the notional cash pool agreement, the bank extends overdraft credit to our participating entities as needed, provided that the overall notionally pooled balance of all accounts in the pool at the end of each day is positive. In the unlikely event of a default, any overdraft balances incurred would be guaranteed by our collective entities participating in the pool.

[0001327567-26-000023:notes:324]
Litigation

[0001327567-26-000023:notes:325]
We are subject to legal proceedings, claims, tax matters, and litigation arising in the ordinary course of business, including, for instance, intellectual property and patent litigation. We accrue for contingencies when we believe that a loss is probable and that we can reasonably estimate the amount of any such loss.

[0001327567-26-000023:notes:326]
Legal matters could include speculative, substantial, or indeterminate monetary amounts. Significant judgment is required to determine both the likelihood of there being a loss and the estimated amount of a loss related to such matters, and we may be unable to estimate the reasonably possible loss or range of loss. The outcomes of outstanding legal matters are inherently unpredictable, and could, either individually or in aggregate, have a material adverse effect on us and our results of operations. To the extent there is a reasonable possibility that a loss exceeding any amounts already recognized may be incurred, we will either disclose the estimated additional loss or state that such an estimate cannot be made.

[0001327567-26-000023:notes:327]
The following matters arose in the ordinary course of business.

[0001327567-26-000023:notes:328]
Centripetal Networks, Inc. v. Palo Alto Networks

[0001327567-26-000023:notes:329]
On March 12, 2021, Centripetal Networks, Inc. (“Centripetal”) filed a lawsuit against us in the United States District Court for the Eastern District of Virginia. The lawsuit alleges that our products infringe multiple Centripetal patents. We successfully challenged certain of these patents, which were found unpatentable by the U.S. Patent and Trademark Office (“PTO”). The case went to jury trial on January 22, 2024, on four patents. On January 31, 2024, the jury returned a verdict of non-willful infringement with a lump sum amount of $152 million, plus statutory interest. After post-trial motions, a judgment was issued on October 3, 2024 affirming infringement on three patents, reversing infringement on the fourth patent, and subsequently, reducing the damages amount to $114 million. We posted a surety bond that was agreed upon by the parties and approved by the court. This bond prevents execution of the judgment while appeals are pending. In addition, Centripetal filed infringement contentions on certain of their patents in the European Patent Office and Unified Patent Court in Germany, to which we filed appropriate legal challenges. Those matters are still pending.

[0001327567-26-000023:notes:330]
As of July 31, 2026 and 2025, we accrued $151 million and $146 million, respectively, based on the judgment and estimated interest, which is recorded in other long-term liabilities on our consolidated balance sheets. The corresponding amount was a charge of $5 million for the year ended July 31, 2026 and a release of $39 million for the year ended July 31, 2025, which is included in general and administrative expense on our consolidated statements of operations.

[0001327567-26-000023:notes:331]
Finjan, Inc. v. Palo Alto Networks

[0001327567-26-000023:notes:332]
On November 4, 2014, Finjan, Inc. (“Finjan”) filed a lawsuit against us in the United States District Court for the Northern District of California. The lawsuit alleges that our products infringe multiple Finjan patents. The complaint requests injunctive relief, monetary damages, and attorneys’ fees. On March 21, 2025, the judge issued an order granting summary judgment of non-infringement on all remaining patents at issue. The matter is currently pending appeal. We are unable, at this time, to reasonably estimate a possible loss or potential range of loss, if any.

[0001327567-26-000023:notes:333]
Eire OG Innovations. v. Palo Alto Networks

[0001327567-26-000023:notes:334]
On April 3, 2024, Eire OG Innovations filed a lawsuit against us in the United States District Court for the Eastern District of Texas asserting infringement of multiple patents, certain of which were subsequently dismissed. The parties have resolved all pending matters between them as of December 2025. The amount paid by us to resolve these matters was not material.

[0001327567-26-000023:notes:335]
Indemnification

[0001327567-26-000023:notes:336]
Under the indemnification provisions of our standard sales related contracts, we agree to defend our end-customers against third-party claims asserting infringement of certain intellectual property rights, which may include patents, copyrights, trademarks, or trade secrets, and to pay judgments or approved settlements attributable to such claims. Our exposure under these indemnification provisions is generally limited to payments made to us for the alleged infringing products over the preceding twelve months under the agreement. However, certain agreements include indemnification provisions that could potentially expose us to losses in excess of these payments. In addition, we indemnify our officers, directors, and certain key employees while they are serving in good faith in their company capacities. To date, we have not recorded any accruals for loss contingencies associated with indemnification claims or determined that an unfavorable outcome is probable or reasonably possible.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001327567-26-000023:notes:337]
Stockholders’ Equity
Share Repurchase Program

[0001327567-26-000023:notes:338]
In February 2019, our board of directors authorized a $1.0 billion share repurchase program, which is funded from available working capital. Our board of directors subsequently authorized additional increases to this share repurchase program, bringing the total authorization under this share repurchase program to $5.1 billion (our “current authorization”). The expiration date of our current authorization was extended to December 31, 2026, and our repurchase program may be suspended or discontinued at any time. Repurchases are to be made at management’s discretion from time to time on the open market, through privately negotiated transactions, transactions structured through investment banking institutions, block purchase techniques, 10b5-1 trading plans, or a combination of the foregoing.

[0001327567-26-000023:notes:339]
The following table summarizes the share repurchase activity under our share repurchase program (in millions, except per share amounts):

[0001327567-26-000023:notes:340]
|  | Year Ended July 31, |
|  | 2026 |  | 2025 |  | 2024 |
| Number of shares repurchased | 7 |  |  | — |  |  | 4 |  |
| Weighted-average price per share (1) | $ | 147.70 |  |  | $ | — |  |  | $ | 142.00 |  |
| Aggregate purchase price (1) | $ | 1,000 |  |  | $ | — |  |  | $ | 567 |  |

[0001327567-26-000023:notes:341]
(1)Includes transaction costs

[0001327567-26-000023:notes:342]
As of July 31, 2026, $1.0 billion remained available for future share repurchases under our current repurchase authorization. The total price of the shares repurchased and related transaction costs are reflected as a reduction to common stock and additional paid-in capital on our consolidated balance sheets.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001327567-26-000023:notes:343]
Equity Award Plans
Share-Based Compensation Plans

[0001327567-26-000023:notes:344]
Equity Incentive Plans

[0001327567-26-000023:notes:345]
Our 2021 Equity Incentive Plan (our “2021 Plan”) became effective in December 2021 and replaced our 2012 Equity Incentive Plan (our “2012 Plan”). Our 2021 Plan provides for the granting of stock options, stock appreciation rights, restricted stock awards (“RSAs”), restricted stock units (“RSUs”), performance shares (“PSAs”), performance-based stock units (“PSUs”) and performance stock options (“PSOs”) to our employees, directors, and consultants. Upon effectiveness of the 2021 Plan, the 2012 Plan was terminated and no further awards will be granted under the 2012 Plan. Awards that were outstanding upon such termination remained outstanding pursuant to their original terms, and any subsequent expiration, cancellation, or forfeiture of awards under our 2012 Plan are returned to our 2021 Plan.

[0001327567-26-000023:notes:346]
The majority of our equity awards are RSUs, which generally vest over a period of four years from the date of grant. Until vested, RSUs do not have the voting and dividend participation rights of common stock and the shares underlying the awards are not considered issued and outstanding.

[0001327567-26-000023:notes:347]
Our PSUs generally vest over a period of one to four years from the date of grant. The number of PSUs eligible to vest is determined based on the level of achievement against certain performance conditions, market conditions, and a combination thereof.

[0001327567-26-000023:notes:348]
During the year ended July 31, 2023, we granted 2 million shares of PSUs with both service and market conditions. The market conditions are satisfied when the price of our common stock is equal to or exceeds stock price targets of $116.67, $133.34, $150.00, and $166.67 based on the average closing price for 30 consecutive trading days during the three- or four-year period following the date of grant. Once a market condition is met, its corresponding one-fourth of the awards vest on each anniversary date of the grant date, subject to continued service. As of July 31, 2026, all stock price targets for these PSU awards have been met, and the related shares will vest when the underlying service conditions are satisfied.

[0001327567-26-000023:notes:349]
During the year ended July 31, 2023, we granted 2 million shares of PSUs, which contain service and market conditions. The service conditions are satisfied after a period of five years. The market condition is measured based on our total shareholder return (“TSR”) relative to the TSR of the companies listed in the Standard & Poor’s 500 index.

[0001327567-26-000023:notes:350]
During the years ended July 31, 2026, 2025, and 2024, we granted 3 million, 3 million, and 4 million shares of PSUs, respectively, which contain service, performance and market conditions. The service conditions are satisfied over a period of one to three years. For PSUs granted during the years ended July 31, 2026 and 2025, the performance conditions are based on an average of next-generation security annualized recurring revenue and non-GAAP net income per diluted share. For PSUs granted during the year ended July 31, 2024, the performance conditions are based on revenue growth or billing growth. The market condition is measured based on our TSR relative to the TSR of the companies listed in the Standard & Poor’s 500 index. As of July 31, 2026, we have approved an additional 3 million shares of PSUs, which will be granted upon the performance condition being established during the next two years.

[0001327567-26-000023:notes:351]
We have also granted PSOs with both service and market conditions. The market condition for PSOs granted in fiscal 2018 and 2019 requires the price of our common stock to equal or exceed $49.63, $66.17, $82.71, and $99.25 based on the average closing price for 30 consecutive trading days during the four-, five-, six-, and seven-and-a-half-year periods following the date of grant in fiscal 2018 and 2019, respectively. Once a market condition is met, its corresponding one-fourth of the PSOs vest on each anniversary date of the grant date, subject to continued service. The maximum contractual term of our outstanding PSOs is seven and a half years from the date of grant, depending on vesting period. As of July 31, 2026, all of our outstanding PSOs have been fully vested.

[0001327567-26-000023:notes:352]
We net-share settle equity awards held by certain employees by withholding shares upon vesting to satisfy tax withholding obligations. Effective August 14, 2025, our 2021 Plan was amended to provide that the shares withheld by us to satisfy employee tax withholding obligations are retired and are not returned to our 2021 Plan. Prior to the amendment, the shares withheld by us to satisfy employee tax withholding obligations were returned to the 2021 Plan and were available for future issuance. Payments for employees’ tax obligations to the tax authorities are recognized as a reduction to additional paid-in capital and reflected as financing activities on our consolidated statements of cash flows.

[0001327567-26-000023:notes:353]
A total of 59 million shares of our common stock are reserved for issuance pursuant to our equity incentive plans as of July 31, 2026.

[0001327567-26-000023:notes:354]
2012 Employee Stock Purchase Plan

[0001327567-26-000023:notes:355]
Our 2012 Employee Stock Purchase Plan was adopted by our board of directors and approved by the stockholders on June 5, 2012, and was effective upon completion of our initial public offering. On August 29, 2017, we amended and restated our 2012 Employee Stock Purchase Plan (our “2012 ESPP”) to extend the length of our offering periods from 6 to 24 months.

[0001327567-26-000023:notes:356]
Our 2012 ESPP permits eligible employees to acquire shares of our common stock at 85% of the lower of the fair market value of our common stock on the first trading day of each offering period or on the purchase date. If the fair market value of our common stock on the purchase date is lower than the first trading day of the offering period, the current offering period will be cancelled after purchase and a new 24-month offering period will begin. Under our 2012 ESPP, each 24-month offering period consists of four consecutive 6-month purchase periods, with purchase dates on the first trading day on or after February 28 and August 31 of each year. Participants may purchase shares of common stock through payroll deductions of up to 15% of their eligible compensation, subject to purchase limits of 3,750 shares per six-month purchase period and $25,000 worth of stock for each calendar year. Shares purchased under our 2012 ESPP during the fiscal years ended July 31, 2026, 2025 and 2024 were 2 million, 2 million and 2 million, at an average exercise price of $133.39 per share, $106.99 per share, and $80.32 per share, respectively.

[0001327567-26-000023:notes:357]
A total of 47 million shares of our common stock are available for sale under our 2012 ESPP as of July 31, 2026. On the first day of each fiscal year, the number of shares in the reserve may be increased by the lesser of (i) 12 million shares, (ii) 1% of the outstanding shares of our common stock on the first day of the fiscal year, or (iii) such other amount as determined by our board of directors.

[0001327567-26-000023:notes:358]
Assumed Share-Based Compensation Plans

[0001327567-26-000023:notes:359]
In connection with our acquisitions, we have assumed equity incentive plans of certain acquired companies (collectively “the Assumed Plans”). The equity awards assumed in connection with each acquisition were granted from their respective assumed plans. The assumed equity awards will be settled in shares of our common stock and will retain the terms and conditions under which they were originally granted. No additional equity awards will be granted under and forfeited awards will not be returned to the Assumed Plans. Refer to Note 8. Acquisitions for more information on our acquisitions and the related equity awards assumed.

[0001327567-26-000023:notes:360]
PSO Activities

[0001327567-26-000023:notes:361]
The following table summarizes the PSO activity under our stock plans during the years ended July 31, 2026, 2025, and 2024 (in millions, except per share amounts):

[0001327567-26-000023:notes:362]
|  |  |  | PSOs Outstanding |
|  |  |  |  |  |  |  |  |  | Number of Shares |  | Weighted-Average Exercise Price Per Share |  | Weighted-Average Remaining Contractual Term(Years) |  | Aggregate Intrinsic Value |
| Balance—July 31, 2023 |  |  |  |  |  |  |  |  | 13 |  |  | $ | 32.60 |  |  | 2.2 |  | $ | 1,185 |  |
| Exercised |  |  |  |  |  |  |  |  | (3) |  |  | 32.42 |  |  |  |  |  |
| Balance—July 31, 2024 |  |  |  |  |  |  |  |  | 10 |  |  | $ | 32.66 |  |  | 1.2 |  | $ | 1,245 |  |
| Exercised(1) |  |  |  |  |  |  |  |  | (9) |  |  | 32.65 |  |  |  |  |  |
| Balance—July 31, 2025 |  |  |  |  |  |  |  |  | 1 |  |  | $ | 32.76 |  |  | 0.5 |  | $ | 197 |  |
| Exercised |  |  |  |  |  |  |  |  | (1) |  |  | 32.76 |  |  |  |  |  |
| Balance—July 31, 2026 |  |  |  |  |  |  |  |  | — |  |  | $ | — |  |  | 0.0 |  | $ | — |  |
| Exercisable—July 31, 2026 |  |  |  |  |  |  |  |  | — |  |  | $ | — |  |  | 0.0 |  | $ | — |  |

[0001327567-26-000023:notes:363]
(1)Includes 1 million shares withheld by us to satisfy exercise price and tax withholding requirements.

[0001327567-26-000023:notes:364]
The intrinsic value of options exercised during the years ended July 31, 2026, 2025, and 2024 was $235 million, $1.2 billion, and $359 million, respectively.

[0001327567-26-000023:notes:365]
RSU and PSU Activities

[0001327567-26-000023:notes:366]
The following table summarizes the RSU and PSU activity under our stock plans during the years ended July 31, 2026, 2025, and 2024 (in millions, except per share amounts):

[0001327567-26-000023:notes:367]
|  | Unvested RSUs |  | Unvested PSUs |
|  | Number of Shares |  | Weighted-Average Grant-Date Fair Value Per Share |  |  |  | Aggregate Intrinsic Value |  | Number of Shares |  | Weighted-Average Grant-Date Fair Value Per Share |  |  |  | Aggregate Intrinsic Value |
| Balance—July 31, 2023 | 24 |  |  | $ | 71.30 |  |  |  |  | $ | 3,013 |  |  | 10 |  |  | $ | 64.32 |  |  |  |  | $ | 1,242 |  |
| Granted(1) | 9 |  |  | 137.76 |  |  |  |  |  |  | 4 |  |  | 91.39 |  |  |  |  |  |
| Vested(2) | (12) |  |  | 68.63 |  |  |  |  |  |  | (3) |  |  | 57.28 |  |  |  |  |  |
| Forfeited | (3) |  |  | 84.12 |  |  |  |  |  |  | (1) |  |  | 68.54 |  |  |  |  |  |
| Balance—July 31, 2024 | 18 |  |  | $ | 102.59 |  |  |  |  | $ | 2,924 |  |  | 10 |  |  | $ | 77.95 |  |  |  |  | $ | 1,624 |  |
| Granted(1) | 6 |  |  | 189.45 |  |  |  |  |  |  | 4 |  |  | 201.59 |  |  |  |  |  |
| Vested(2) | (9) |  |  | 97.00 |  |  |  |  |  |  | (1) |  |  | 64.65 |  |  |  |  |  |
| Forfeited | (2) |  |  | 115.94 |  |  |  |  |  |  | (4) |  |  | 92.11 |  |  |  |  |  |
| Balance—July 31, 2025 | 13 |  |  | $ | 143.33 |  |  |  |  | $ | 2,285 |  |  | 9 |  |  | $ | 140.92 |  |  |  |  | $ | 1,635 |  |
| Granted(1)(3) | 15 |  |  | 184.48 |  |  |  |  |  |  | 4 |  |  | 186.49 |  |  |  |  |  |
| Vested(2) | (9) |  |  | 144.94 |  |  |  |  |  |  | (3) |  |  | 150.68 |  |  |  |  |  |
| Forfeited | (2) |  |  | 158.84 |  |  |  |  |  |  | (2) |  |  | 146.42 |  |  |  |  |  |
| Balance—July 31, 2026 | 17 |  |  | $ | 177.41 |  |  |  |  | $ | 5,594 |  |  | 8 |  |  | $ | 155.85 |  |  |  |  | $ | 2,643 |  |

[0001327567-26-000023:notes:368]
(1)For PSUs, shares granted represent the aggregate maximum number of shares that may be earned and issued with respect to these awards over their full terms.

[0001327567-26-000023:notes:369]
(2)Includes time-based vesting for PSUs.

[0001327567-26-000023:notes:370]
(3)Includes 7 million RSUs assumed in connection with the acquisitions of Chronosphere, CyberArk, Koi, and Portkey with weighted-average grant-date fair value of $176.20, $165.30, $161.59, and $281.69 per share, respectively, for the year ended July 31, 2026.

[0001327567-26-000023:notes:371]
The aggregate fair value, as of the respective vesting dates, of RSUs vested during the years ended July 31, 2026, 2025, and 2024 was $1.8 billion, $1.6 billion, and $1.6 billion, respectively. The aggregate fair value, as of the respective vesting dates, of PSUs vested during the years ended July 31, 2026, 2025, and 2024 was $663 million, $221 million, and $378 million, respectively.

[0001327567-26-000023:notes:372]
Shares Available for Grant

[0001327567-26-000023:notes:373]
The following table presents the stock activity and the total number of shares available for grant under our equity incentive plans as of July 31, 2026 (in millions):

[0001327567-26-000023:notes:374]
|  | Number of shares |
| Balance—July 31, 2025 | 29 |  |
| Authorized | 10 |  |
| RSUs and PSUs granted | (13) |  |
| RSUs and PSUs forfeited | 4 |  |
| Shares withheld for taxes | — |  |
| Balance—July 31, 2026 | 30 |  |

[0001327567-26-000023:notes:375]
We record share-based compensation awards based on estimated fair value as of the grant date. The fair value of RSUs and PSUs not subject to market conditions is based on the closing market price of our common stock on the date of grant.

[0001327567-26-000023:notes:376]
The fair value of the PSUs subject to market conditions is estimated on the grant date using a Monte Carlo simulation model. The following table summarizes the assumptions used and the resulting grant-date fair value of our PSUs subject to market conditions granted during the years ended July 31, 2026, 2025, and 2024:

[0001327567-26-000023:notes:377]
|  | Year Ended July 31, |
|  | 2026 |  | 2025 |  | 2024 |
| Volatility | 36.6% - 42.6% |  | 43.5% - 47.6% |  | 40.8% - 43.4% |
| Expected term (in years) | 1.0 - 3.0 |  | 1.0 - 2.9 |  | 0.9 - 2.9 |
| Dividend yield | — | % |  | — | % |  | — | % |
| Risk-free interest rate | 3.6% - 3.9% |  | 3.7% - 4.5% |  | 4.4% - 5.3% |
| Grant-date fair value per share | $226.06 - $261.62 |  | $264.51 - $305.83 |  | $173.46 - $310.61 |

[0001327567-26-000023:notes:378]
The expected volatility is based on the historical volatility of our common stock. The expected term is based on the length of each tranche’s performance period from the grant date. The dividend yield assumption is based on our current expectations about our anticipated dividend policy. The risk-free interest rate is based on the implied yield available on U.S. Treasury zero-coupon issues with maturities that approximate the expected term.

[0001327567-26-000023:notes:379]
The fair value of PSOs was estimated on the grant date using a Monte Carlo simulation model, which predicts settlement of the PSOs midway between the vesting term and the contractual term. No PSOs were granted during the years ended July 31, 2026, 2025, and 2024.

[0001327567-26-000023:notes:380]
The fair value of shares issued under our 2012 ESPP are estimated on the grant date using the Black-Scholes option pricing model. The following table summarizes the assumptions used and the resulting grant-date fair values of our ESPP:

[0001327567-26-000023:notes:381]
|  | Year Ended July 31, |
|  | 2026 |  | 2025 |  | 2024 |
| Volatility | 35.6% - 39.2% |  | 34.3% - 43.3% |  | 39.6% - 50.0% |
| Expected term (in years) | 0.5 - 2.0 |  | 0.5 - 2.0 |  | 0.5 - 2.0 |
| Dividend yield | — | % |  | — | % |  | — | % |
| Risk-free interest rate | 3.5% - 4.0% |  | 3.9% - 4.8% |  | 4.6% - 5.5% |
| Grant-date fair value per share | $32.77 - $73.67 |  | $45.43 - $74.81 |  | $32.81 - $66.66 |

[0001327567-26-000023:notes:382]
The expected volatility is based on a combination of implied volatility from traded options on our common stock and the historical volatility of our common stock. The expected term represents the term from the first day of the offering period to the purchase dates within each offering period. The dividend yield assumption is based on our current expectations about our anticipated dividend policy. The risk-free interest rate is based on the implied yield available on U.S. Treasury zero-coupon issues with maturities that approximate the expected term.

[0001327567-26-000023:notes:383]
The following table summarizes share-based compensation by award types (in millions):

[0001327567-26-000023:notes:384]
|  | Year Ended July 31, |
|  | 2026 |  | 2025 |  | 2024 |
| RSU and RSA | $ | 1,319 |  |  | $ | 878 |  |  | $ | 866 |  |
| PSU | 344 |  |  | 331 |  |  | 124 |  |
| Others | 152 |  |  | 91 |  |  | 89 |  |
| Total share-based compensation | $ | 1,815 |  |  | $ | 1,300 |  |  | $ | 1,079 |  |

[0001327567-26-000023:notes:385]
The following table summarizes share-based compensation included in costs and expenses (in millions):

[0001327567-26-000023:notes:386]
|  | Year Ended July 31, |
|  | 2026 |  | 2025 |  | 2024 |
| Cost of product revenue | $ | 5 |  |  | $ | 5 |  |  | $ | 7 |  |
| Cost of subscription and support revenue | 161 |  |  | 127 |  |  | 121 |  |
| Research and development | 688 |  |  | 551 |  |  | 526 |  |
| Sales and marketing | 513 |  |  | 359 |  |  | 301 |  |
| General and administrative | 448 |  |  | 258 |  |  | 124 |  |
| Total share-based compensation | $ | 1,815 |  |  | $ | 1,300 |  |  | $ | 1,079 |  |

[0001327567-26-000023:notes:387]
During the year ended July 31, 2026, the vesting of certain equity awards was accelerated in connection with our acquisitions of CyberArk and Koi; as a result, we recorded share-based compensation of $177 million, including $1 million in cost of subscription and support revenue, $36 million in sales and marketing expense, and $140 million in general and administrative expense on our consolidated statements of operations.

[0001327567-26-000023:notes:388]
As of July 31, 2026, total compensation cost related to unvested share-based awards not yet recognized was $3.3 billion. This cost is expected to be amortized over a weighted-average period of approximately 2.5 years. Future grants will increase the amount of compensation expense to be recorded in these periods.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001327567-26-000023:notes:389]
Income Taxes
The following table presents the components of income before income taxes (in millions):

[0001327567-26-000023:notes:390]
|  | Year Ended July 31, |
|  | 2026 |  | 2025 |  | 2024 |
| United States | $ | 466 |  |  | $ | 1,125 |  |  | $ | 669 |  |
| Foreign | 70 |  |  | 471 |  |  | 319 |  |
| Total | $ | 536 |  |  | $ | 1,596 |  |  | $ | 988 |  |

[0001327567-26-000023:notes:391]
The following table summarizes our provision for (benefit from) income taxes (in millions):

[0001327567-26-000023:notes:392]
|  | Year Ended July 31, |
|  | 2026 |  | 2025 |  | 2024 |
| Federal: |  |  |  |  |  |
| Current | $ | 95 |  |  | $ | 517 |  |  | $ | 213 |  |
| Deferred | (165) |  |  | (300) |  |  | 312 |  |
| State: |  |  |  |  |  |
| Current | 53 |  |  | 108 |  |  | 101 |  |
| Deferred | (6) |  |  | (44) |  |  | (173) |  |
| Foreign: |  |  |  |  |  |
| Current | 132 |  |  | 186 |  |  | 130 |  |
| Deferred | 120 |  |  | (5) |  |  | (2,173) |  |
| Total | $ | 229 |  |  | $ | 462 |  |  | $ | (1,590) |  |

[0001327567-26-000023:notes:393]
For the year ended July 31, 2026, our provision for income taxes was $229 million, which represented a $233 million decrease from prior year, primarily due to a one-time deferred tax provision of $219 million recorded during during the year ended July 31, 2025 arising from the remeasurement of our basis difference associated with the U.S. tax effects of foreign deferred tax assets.

[0001327567-26-000023:notes:394]
We adopted the new income tax disclosures guidance effective in our year ended July 31, 2026 on a prospective basis. The following table presents a reconciliation from the federal statutory tax amount and rate to our provision for incomes taxes and effective tax rate under the requirements of the newly adopted income tax disclosures guidance (dollars in millions):

[0001327567-26-000023:notes:395]
|  | Year Ended July 31, 2026 |
|  | Amount |  | Rate |
| Federal statutory tax | $ | 113 |  |  | 21.0 | % |
| State taxes(1)(2) | 41 |  |  | 7.7 |  |
| Foreign tax effects: |  |  |  |
| Israel: |  |  |  |
| Statutory rate differential | (10) |  |  | (1.9) |  |
| Reduced statutory rate on qualifying income | 93 |  |  | 17.3 |  |
| Nondeductible expenses | 22 |  |  | 4.1 |  |
| Intercompany legal entity restructuring(2) | 48 |  |  | 9.0 |  |
| United Kingdom: |  |  |  |
| Statutory rate differential | 20 |  |  | 3.7 |  |
| Other jurisdictions | 54 |  |  | 10.2 |  |
| Effect of cross-border tax laws: |  |  |  |
| Global intangible low-taxed income(2) | (195) |  |  | (36.4) |  |
| Subpart F income | 22 |  |  | 4.1 |  |
| U.S. branch income (loss)(2) | (117) |  |  | (21.9) |  |
| Other | (23) |  |  | (4.1) |  |
| Tax credits: |  |  |  |
| Research and development tax credits | (58) |  |  | (10.8) |  |
| Changes in valuation allowance | (2) |  |  | (0.4) |  |
| Nontaxable or nondeductible items: |  |  |  |
| Shared-based compensation | 49 |  |  | 9.1 |  |
| Change in fair value of convertible senior notes and Capped Calls | 118 |  |  | 22.0 |  |
| Other | 7 |  |  | 1.3 |  |
| Changes in unrecognized tax benefits | 86 |  |  | 16.0 |  |
| Other: |  |  |  |
| Intercompany legal entity restructuring(2) | (39) |  |  | (7.3) |  |
| Total | $ | 229 |  |  | 42.7 | % |

[0001327567-26-000023:notes:396]
(1)The state and local jurisdictions that contribute to the majority of the tax effect in this category include California, District of Columbia, Maryland, the state and city of New York, and Pennsylvania.

[0001327567-26-000023:notes:397]
(2)These categories include impacts of an intercompany legal entity restructuring completed Q4 fiscal 2026 with a total impact of $45 million income tax benefit.

[0001327567-26-000023:notes:398]
Prior to the adoption of the new income tax disclosure guidance, the following table presents a reconciliation from the federal statutory income tax rate to our effective tax rate:

[0001327567-26-000023:notes:399]
|  |  |  | Year Ended July 31, |
|  |  |  | 2025 |  | 2024 |
| Federal statutory rate |  |  | 21.0 | % |  | 21.0 | % |
| Effect of: |  |  |  |  |  |
| State taxes, net of federal tax benefit |  |  | 3.8 |  |  | 3.1 |  |
| Non-U.S. operations |  |  | 2.2 |  |  | 9.5 |  |
| Change in valuation allowance |  |  | 1.1 |  |  | (341.9) |  |
| U.S. effect of foreign deferred tax assets |  |  | 11.2 |  |  | 175.8 |  |
| Share-based compensation |  |  | (5.5) |  |  | (16.9) |  |
| Tax credits |  |  | (6.2) |  |  | (13.4) |  |
| Non-deductible expenses |  |  | 1.2 |  |  | 1.5 |  |
| Other, net |  |  | 0.1 |  |  | 0.5 |  |
| Total |  |  | 28.9 | % |  | (160.8) | % |

[0001327567-26-000023:notes:400]
The following table presents the components of our deferred tax assets and liabilities as of July 31, 2026 and 2025 (in millions):

[0001327567-26-000023:notes:401]
|  | July 31, |
|  | 2026 |  | 2025 |
| Deferred tax assets: |  |  |  |
| Accruals and reserves | $ | 176 |  |  | $ | 132 |  |
| Operating lease liabilities | 233 |  |  | 127 |  |
| Deferred revenue | 1,385 |  |  | 1,266 |  |
| Net operating loss carryforwards | 776 |  |  | 620 |  |
| Tax credits | 286 |  |  | 222 |  |
| Capitalized research expenditures | 879 |  |  | 895 |  |
| Share-based compensation | 148 |  |  | 106 |  |
| Fixed assets and intangible assets | 921 |  |  | 1,561 |  |
| Gross deferred tax assets | 4,804 |  |  | 4,929 |  |
| Valuation allowance | (321) |  |  | (278) |  |
| Total deferred tax assets | 4,483 |  |  | 4,651 |  |
| Deferred tax liabilities: |  |  |  |
| U.S. effect of foreign deferred tax assets | (1,789) |  |  | (1,922) |  |
| Operating lease right-of-use assets | (208) |  |  | (108) |  |
| Deferred contract costs | (258) |  |  | (212) |  |
| Other deferred tax liabilities | (36) |  |  | (74) |  |
| Total deferred tax liabilities | (2,291) |  |  | (2,316) |  |
| Net deferred tax assets | $ | 2,192 |  |  | $ | 2,335 |  |

[0001327567-26-000023:notes:402]
We regularly assess the need for a valuation allowance on our deferred tax assets. In making this assessment, we consider both positive and negative evidence related to the likelihood of realization of the deferred tax assets to determine, based on the weight of available evidence, whether it is more likely than not that some or all the deferred tax assets will not be realized. The assessment requires significant judgment and is performed for each of the applicable jurisdictions. Due to a law change during the year ended July 31, 2026, we released a portion of the valuation allowance for our California deferred tax assets due to these assets becoming “more likely than not” to be realized in the future; however, we still expect future research and development tax credit generation in California to exceed our ability to use the existing tax credits.

[0001327567-26-000023:notes:403]
As of July 31, 2026, we had federal, state, and foreign net operating loss carryforwards of approximately $474 million, $746 million, and $3.0 billion, respectively, as reported on our tax returns, available to reduce future taxable income, if any. If not utilized, our federal and state net operating loss carryforwards will expire in various amounts at various dates beginning in the years ending July 31, 2034 and July 31, 2030, respectively. Our foreign net operating loss will carry forward indefinitely.

[0001327567-26-000023:notes:404]
As of July 31, 2026, we had federal and state research and development tax credit carryforwards of approximately $7 million and $382 million, respectively, as reported on our tax returns. If not utilized, the federal credit carryforwards will expire in various amounts at various dates beginning in the year ending July 31, 2040. The state credit carryforwards have no expiration.

[0001327567-26-000023:notes:405]
As of July 31, 2026, we had foreign tax credit carryforwards of $46 million as reported on our tax returns. If not utilized, the foreign tax credit carryforwards will expire in various amounts at various dates beginning in the year ending July 31, 2029.

[0001327567-26-000023:notes:406]
As of July 31, 2026, we had $719 million of unrecognized tax benefits, $393 million of which would affect income tax expense if recognized. As of July 31, 2025, we had $572 million of unrecognized tax benefits, $275 million of which would affect income tax expense if recognized.

[0001327567-26-000023:notes:407]
We file federal, state, and foreign income tax returns in jurisdictions with varying statutes of limitations. Generally, all years remain subject to adjustment due to our net operating loss and credit carryforwards. We currently have ongoing tax audits in various jurisdictions and at various times. The primary focus of these audits is, generally, profit allocation. The ultimate amount and timing of any future settlements cannot be predicted with reasonable certainty.

[0001327567-26-000023:notes:408]
We recognize both interest and penalties associated with uncertain tax positions as a component of income tax expense. During the years ended July 31, 2026, 2025, and 2024, we recognized income tax expense of $59 million, $42 million, and $6 million related to interest and penalties, respectively. We had accrued interest and penalties on our consolidated balance sheets related to unrecognized tax benefits of $113 million and $53 million as of July 31, 2026 and 2025, respectively.

[0001327567-26-000023:notes:409]
The following table presents a reconciliation of the beginning and ending amount of our gross unrecognized tax benefits (in millions):

[0001327567-26-000023:notes:410]
|  | Year Ended July 31, |
|  | 2026 |  | 2025 |  | 2024 |
| Unrecognized tax benefits at the beginning of the period | $ | 572 |  |  | $ | 454 |  |  | $ | 360 |  |
| Additions for tax positions taken in prior years | 13 |  |  | 10 |  |  | 2 |  |
| Reductions for tax positions taken in prior years | (1) |  |  | (11) |  |  | (20) |  |
| Additions for tax positions taken in the current year | 140 |  |  | 119 |  |  | 112 |  |
| Reduction relating to audit settlement | (5) |  |  | — |  |  | — |  |
| Unrecognized tax benefits at the end of the period | $ | 719 |  |  | $ | 572 |  |  | $ | 454 |  |

[0001327567-26-000023:notes:411]
As part of the acquisition of CyberArk, we executed an intercompany transaction to repatriate $3.5 billion of foreign earnings, resulting in immaterial income tax expense related to state and other taxes. Our remaining unremitted earnings are indefinitely reinvested.

[0001327567-26-000023:notes:412]
Pursuant to adoption of the new income tax disclosures guidance, the following table presents the income taxes paid, net of refunds (in millions):

[0001327567-26-000023:notes:413]
|  | Year Ended July 31, 2026 |
| Federal | $ | 40 |  |
| State |  |
| California | 18 |  |
| All Others | 51 |  |
| Foreign |  |
| Israel | 24 |  |
| Netherlands | 13 |  |
| India | 16 |  |
| All Others | 37 |  |
| Total | $ | 199 |  |


## us-gaap:EarningsPerShareTextBlock

[0001327567-26-000023:notes:414]
Net Income Per Share
Basic net income per share is computed by dividing net income by basic weighted-average shares outstanding during the period. Diluted net income per share is computed by dividing net income by diluted weighted-average shares outstanding during the period giving effect to all potentially dilutive securities to the extent they are dilutive. We compute the dilutive effect of shares issuable upon conversion of our convertible senior notes using the if-converted method, and the dilutive effect of warrants related to the issuance of convertible senior notes and equity awards under our employee equity incentive plans using the treasury stock method.

[0001327567-26-000023:notes:415]
The following table presents the computation of basic and diluted net income per share of common stock (in millions, except per share data):

[0001327567-26-000023:notes:416]
|  | Year Ended July 31, |
|  | 2026 |  | 2025 |  | 2024 |
| Net income | $ | 307 |  |  | $ | 1,134 |  |  | $ | 2,578 |  |
| Weighted-average shares used to compute net income per share, basic | 749 |  |  | 663 |  |  | 638 |
| Weighted-average effect of potentially dilutive securities: |  |  |  |  |  |
| Convertible senior notes | — |  |  | 7 |  |  | 21 |  |
| Warrants related to the issuance of convertible senior notes | 5 |  |  | 25 |  |  | 26 |  |
| Employee equity incentive plans | 10 |  |  | 14 |  |  | 23 |  |
| Weighted-average shares used to compute net income per share, diluted | 764 |  |  | 709 |  |  | 708 |
| Net income per share, basic | $ | 0.41 |  |  | $ | 1.71 |  |  | $ | 4.04 |  |
| Net income per share, diluted | $ | 0.40 |  |  | $ | 1.60 |  |  | $ | 3.64 |  |

[0001327567-26-000023:notes:417]
The following securities were excluded from the computation of diluted net income per share of common stock as their effect would have been antidilutive or issuance of such shares is contingent upon the satisfaction of certain conditions which were not satisfied by the end of the applicable period (in millions):

[0001327567-26-000023:notes:418]
|  | Year Ended July 31, |
|  | 2026 |  | 2025 |  | 2024 |
| Employee equity incentive plans | 5 |  |  | 3 |  |  | 5 |  |


## us-gaap:OtherNonoperatingIncomeAndExpenseTextBlock

[0001327567-26-000023:notes:419]
Other Income (Expense), Net
The following table sets forth the components of other income (expense), net (in millions):

[0001327567-26-000023:notes:420]
|  | Year Ended July 31, |
|  | 2026 |  | 2025 |  | 2024 |
| Interest income | $ | 374 |  |  | $ | 364 |  |  | $ | 318 |  |
| Interest expense | — |  |  | (3) |  |  | (8) |  |
| Foreign currency exchange gains (losses), net | (35) |  |  | (33) |  |  | — |  |
| Change in fair value of convertible senior notes | (620) |  |  | — |  |  | — |  |
| Change in fair value of Capped Calls | 58 |  |  | — |  |  | — |  |
| Other, net | 64 |  |  | 25 |  |  | (6) |  |
| Total other income (expense), net | $ | (159) |  |  | $ | 353 |  |  | $ | 304 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001327567-26-000023:notes:421]
Segment Information
We have one operating and reportable segment. We conduct business globally and sales are primarily managed on a geographic theater basis. Our chief operating decision maker (“CODM”) is our Chairman and Chief Executive Officer who reviewed financial information presented on a consolidated basis accompanied by revenue information for purposes of allocating resources and evaluating financial performance. Our CODM used consolidated net income as our measure of segment profit or loss. The consolidated financial information by function as reflected on our consolidated statements of operations was used in our annual budget and forecasting process to establish goals and monitor budget versus actual results. The measure of segment assets is reported on the consolidated balance sheets as total consolidated assets.

[0001327567-26-000023:notes:422]
The following table presents our long-lived assets, which consist of property and equipment, net and operating lease right-of-use assets, by geographic area (in millions):

[0001327567-26-000023:notes:423]
|  | Year Ended July 31, |
|  | 2026 |  | 2025 |
| Long-lived assets: |  |  |  |
| United States | $ | 759 |  |  | $ | 418 |  |
| Israel | 222 |  |  | 162 |  |
| Other countries | 242 |  |  | 154 |  |
| Total long-lived assets | $ | 1,223 |  |  | $ | 734 |  |

[0001327567-26-000023:notes:424]
Refer to Note 2. Revenue for revenue by geographic theater and revenue for groups of similar products and services for the years ended July 31, 2026, 2025, and 2024.


## us-gaap:SubsequentEventsTextBlock

[0001327567-26-000023:notes:425]
Subsequent Events
Embrace Mobile, Inc.

[0001327567-26-000023:notes:426]
On August 27, 2026, we completed the acquisition of Embrace. This acquisition will be accounted for as a business combination in the first quarter of fiscal 2027.

[0001327567-26-000023:notes:427]
On September 1, 2026, we completed the acquisition of Console. This acquisition will be accounted for as a business combination in the first quarter of fiscal 2027.


## ecd:MtrlTermsOfTrdArrTextBlock

[0001327567-26-000023:notes:428]
The Rule 10b5-1 trading plans listed below are each intended to satisfy the affirmative defense of Rule 10b5-1(c).

[0001327567-26-000023:notes:429]
| Name |  | Title |  | Action |  | Date of Action |  | Expiration Date |  | Total Amount of Common Stock to Be Sold Under the Plan |
| Dipak Golechha |  | Chief Financial Officer |  | Modified |  | June 25, 2026 |  | September 30, 2027 |  | 50,000 or, if earlier, when all shares have been sold |
| William D. Jenkins Jr. |  | President |  | Adopted |  | June 28, 2026 |  | January 31, 2027 |  | 148,217 or, if earlier, when all shares have been sold |
