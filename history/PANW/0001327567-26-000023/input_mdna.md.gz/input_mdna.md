# PANW MD&A — 0001327567-26-000023


## mdna

[0001327567-26-000023:mdna:1]
Item 7. Management’s Discussion and Analysis of Financial Condition and Results of Operations

[0001327567-26-000023:mdna:2]
The following discussion and analysis of our financial condition and results of operations should be read in conjunction with our consolidated financial statements and related notes appearing elsewhere in this Annual Report on Form 10-K. The following discussion and analysis contains forward-looking statements based on current expectations and assumptions that are subject to risks and uncertainties, which could cause our actual results to differ materially from those anticipated or implied by any forward-looking statements. Factors that could cause or contribute to such differences include, but are not limited to, those discussed in this Annual Report on Form 10-K, and in particular, the risks discussed under the caption “Risk Factors” in Part I, Item 1A of this report.

[0001327567-26-000023:mdna:3]
Our Management’s Discussion and Analysis of Financial Condition and Results of Operations (“MD&A”) is organized as follows:

[0001327567-26-000023:mdna:4]
•Overview. A discussion of our business and overall analysis of financial and other highlights in order to provide context for the remainder of MD&A.

[0001327567-26-000023:mdna:5]
•Key Financial Metrics. A summary of our U.S. GAAP and non-GAAP key financial metrics, which management monitors to evaluate our performance.

[0001327567-26-000023:mdna:6]
•Results of Operations. A discussion of the nature and trends in our financial results and an analysis of our financial results comparing fiscal 2026 to fiscal 2025. For discussion and analysis related to our financial results comparing fiscal 2025 to 2024, refer to Part II, Item 7 Management’s Discussion and Analysis of Financial Condition and Results of Operations in our Annual Report on Form 10-K for fiscal 2025, which was filed with the Securities and Exchange Commission on August 29, 2025.

[0001327567-26-000023:mdna:7]
•Liquidity and Capital Resources. An analysis of changes on our balance sheets and cash flows, and a discussion of our financial condition and our ability to meet cash needs.

[0001327567-26-000023:mdna:8]
•Critical Accounting Estimates. A discussion of our accounting policies that require critical estimates, assumptions, and judgments.

[0001327567-26-000023:mdna:9]
•Recent Accounting Pronouncements. A discussion of expected impacts of impending accounting changes on financial information to be reported in the future.

[0001327567-26-000023:mdna:10]
Overview

[0001327567-26-000023:mdna:11]
Our mission is to be the cybersecurity partner of choice, protecting our digital way of life. Our platforms and services help secure enterprise users, networks, clouds, endpoints, AI apps and agents, and identities by delivering comprehensive cybersecurity backed by AI and automation, and provide real-time visibility and monitoring across cloud infrastructure, applications and AI workloads. A key element of our strategy is to help our customers simplify their security architectures through consolidating disparate point products. We execute on this strategy by developing our capabilities and packaging our offerings into platforms, which are able to cover many of our customers’ needs in the markets in which we operate. Our platformization strategy combines various products and services into a tightly integrated architecture for more secure, faster, and cost-effective outcomes.

[0001327567-26-000023:mdna:12]
Network & AI Security

[0001327567-26-000023:mdna:13]
Our Network & AI Security platform is designed to deliver complete zero trust solutions to our customers. The platform includes:

[0001327567-26-000023:mdna:14]
•Secure Access Service Edge. Prisma® Access, when combined with Prisma SD-WAN, provides a comprehensive AI-powered SASE solution that secures users, branches, data, AI apps and agents from the most evasive threats in the new AI landscape. Our Prisma Browser™ further extends zero-trust security and data protection to the browser, where the majority of work is done today, providing users with the freedom to work securely using our secure browser from any device.

[0001327567-26-000023:mdna:15]
•Next-Generation Firewalls. Our ML-Powered NGFWs secure on-premises environments including campus locations and data centers. Our software NGFWs secure virtual and cloud networks.

[0001327567-26-000023:mdna:16]
•Cloud-Delivered Security Services. Our network security platform integrates a suite of Precision AI powered security capabilities that complements our SASE and NGFW solutions. These include Advanced Threat Prevention, Advanced WildFire®, Advanced URL Filtering, Advanced DNS Security, Device Security, Quantum Security, NGTS, GlobalProtect®, Prisma Access Agent, Enterprise DLP, SaaS Security, and AI Access Security™. Through these add-on services, our customers are able to secure their content, applications, users, devices, and connection across their entire organization.

[0001327567-26-000023:mdna:17]
- 42 -

[0001327567-26-000023:mdna:18]
•Prisma AIRS. Prisma AIRS™ is our comprehensive AI security platform designed to help organizations discover, assess, and protect AI agents, applications, models and data across the AI lifecycle. It supports key enterprise use cases, including securing AI-assisted software development, protecting custom AI applications from development through runtime, and governing autonomous AI agents. Prisma AIRS™ brings together AI Gateway, Agent Security, AI Red Teaming, AI Runtime Security™, AI Model Security, and AI Posture Management in a unified platform. These capabilities provide visibility into AI assets and activity, assess risks before deployment, and enforce security controls during live AI interactions and agent actions.

[0001327567-26-000023:mdna:19]
•Strata Cloud Manager. SCM, is our AI-powered unified network security management and operations solution. It enables customers to manage and monitor their NGFW and SASE environments through a single, streamlined interface. SCM helps customers centrally manage configurations and security policies, assess security posture and network health, and streamline troubleshooting and remediation. It includes Strata Copilot, which offers a natural language interface for actionable insights and guided remediation, and integrates ADEM to help customers monitor and improve end-user performance across the enterprise.

[0001327567-26-000023:mdna:20]
Cortex

[0001327567-26-000023:mdna:21]
Our AI-powered Cortex® platform transforms end-to-end security operations and observability with unified data, AI, and automation for more secure, faster, and cost effective outcomes.

[0001327567-26-000023:mdna:22]
•Security Operations. We deliver the next generation of security operations capabilities that unifies standalone SIEM tools, endpoint security, security automation, CDR, as well as ASM capabilities on our Cortex platform. These include Cortex XSIAM®, for AI-powered security operations replacing traditional SIEM tools; Cortex XDR®, for the prevention, detection, and response to complex cybersecurity attacks; Cortex XSOAR®, for SOAR; Cortex Xpanse®, for ASM; and Koi Agentic Endpoint Security. Additionally, Cortex XSIAM integrates with the Chronosphere Telemetry Pipeline to ingest and optimize massive data volumes, promoting cost-effective scaling of autonomous operations.

[0001327567-26-000023:mdna:23]
•Cloud Security. We deliver comprehensive security across the cloud application development lifecycle through Cortex Cloud®, delivered as a scalable SaaS offering. As a comprehensive CNAPP combined with CDR, Cortex Cloud secures multi- and hybrid-cloud environments for applications, data, GenAI ecosystem, and the cloud native technology stack across the full development lifecycle, from code to cloud to security operations. As part of the Cortex Cloud platform, customers can expand from Cortex Cloud to our security operations offerings available on a single user experience and unified agent. We also offer our VM-Series and CN-Series virtual firewalls for inline network security on multi- and hybrid-cloud environments.

[0001327567-26-000023:mdna:24]
•Observability. Chronosphere, our next-generation observability platform, delivers real-time visibility and monitoring across cloud-native infrastructure, applications, and AI workloads. Purpose-built to handle the massive data volumes of the AI era, Chronosphere enables organizations to maintain system resilience and uptime with high cost-efficiency and reliability. Our observability platform provides comprehensive visibility into complex digital environments and automated troubleshooting of issues. It allows customers to transition from passive monitoring to proactive management of their entire digital estate. Our telemetry pipeline acts as an intelligent control layer that filters, transforms, and routes data. This helps reduce data volumes, enabling customers to cost-effectively scale their security and observability posture.

[0001327567-26-000023:mdna:25]
Idira

[0001327567-26-000023:mdna:26]
Idira™, our next-generation identity security platform, is designed to secure human, agentic, and machine identities across the enterprise with intelligent privilege controls and continuous threat prevention. By unifying identity access management, privilege access management, and identity governance and administration, organizations can continuously discover and protect against identity risk throughout the end-to-end identity lifecycle. The platform includes:

[0001327567-26-000023:mdna:27]
•Workforce Identity Security. Our solutions apply identity assurance and modern access controls for the entire workforce, including through adaptive MFA, SSO, secure browsing, web session protection, workforce password management, and automated identity lifecycle management. Our approach enforces least privilege by elevating access only when required.

[0001327567-26-000023:mdna:28]
•IT and Developer Identity Security (Modern Privilege Access Management). Our solutions secure high-risk access for IT administrators, third-party vendors, developers, and cloud operations teams across hybrid and multi-cloud environments, delivering just-in-time privileged access, session isolation, credential protection, and zero standing privileges, while providing native, secure access to cloud services, workloads, and development and operations pipelines. Organizations can eliminate excessive permissions, automate access to dynamic cloud resources, and maintain developer velocity while strengthening identity controls across infrastructure and application environments.

[0001327567-26-000023:mdna:29]
•Machine Identity Security. Our solutions secure the growing volume of non-human identities—such as workloads, applications, containers, service accounts, certificates, and keys, including through centralized discovery and management of secrets, certificate lifecycle automation, workload identity issuance, public key infrastructure-as-a-service, Kubernetes certificate management, and secure code signing.

[0001327567-26-000023:mdna:30]
- 43 -

[0001327567-26-000023:mdna:31]
•Identity Governance and Administration. IGA enables visibility into entitlements, automated joiner–mover–leaver processes, access certification, and ongoing identity compliance. AI-supported policy automation helps organizations govern access at scale and enforce a zero-trust model across all identities.

[0001327567-26-000023:mdna:32]
•AI Agents Security. Our solution discovers AI agents, assigns identity attributes, and restricts their access to task-specific resources. It helps monitor and record agent activity for audit purposes, allows organizations to suspend or revoke access if behavior deviates from expected norms, and governs the lifecycle of the agent and the actions taken to support compliance.

[0001327567-26-000023:mdna:33]
Threat Intelligence and Advisory Services

[0001327567-26-000023:mdna:34]
•Unit 42® brings together world-renowned expertise across threat research, incident response, and security consulting to deliver intelligence-driven, response-ready outcomes that help customers reduce cyber risk. Our elite consultants serve as trusted advisors to our customers by assessing and testing their security controls against sophisticated threats, including Frontier AI, transforming their security strategy with a threat-informed approach, and responding to security incidents on behalf of our clients. Additionally, Unit 42 offers MDR and managed threat hunting services. In April 2026, we launched a new suite of Unit 42 Frontier AI Defense services to help customers proactively discover and neutralize threats introduced by next-generation AI models.

[0001327567-26-000023:mdna:35]
For fiscal 2026 and 2025, total revenue was $11.5 billion and $9.2 billion, respectively, representing year-over-year growth of 24%. Our growth reflects the increased adoption of our portfolio, which consists of product, subscriptions, and support, and the contributions from our acquisitions in our current fiscal year. We believe our portfolio will enable us to benefit from recurring revenues and new revenues as we continue to grow our end-customer base. As of July 31, 2026, we had end-customers in over 180 countries. Our end-customers represent a broad range of industries, including education, energy, financial services, government entities, healthcare, Internet and media, manufacturing, public sector, and telecommunications, and include almost all of the Fortune 100 companies and a majority of the Global 2000 companies. We maintain a field sales force that works closely with our channel partners in developing sales opportunities. We primarily use a two-tiered, indirect fulfillment model whereby we sell our products, subscriptions, and support to our distributors, which, in turn, sell to our resellers, which then sell to our end-customers.

[0001327567-26-000023:mdna:36]
Our product revenue grew to $2.3 billion, or 19.9% of total revenue for fiscal 2026, representing year-over-year growth of 27%. Product revenue is derived from sales of hardware products, primarily our ML-Powered NGFW, and software licenses, including SD-WAN, VM-Series, and Panorama®. In connection with the acquisition of CyberArk in February 2026, our product revenue also includes on-premise software licenses of certain identity security offerings. Our ML-Powered NGFW incorporates our PAN-OS® operating system, which provides a consistent set of capabilities across our entire network security product line. Our hardware products and software licenses include a broad set of built-in networking and security features and functionalities. Our products are designed for different performance requirements throughout an organization, ranging from our PA-400, which is designed for small organizations and remote or branch offices, to our top-of-the-line PA-7500, which is designed for large-scale data centers and service provider use. The same firewall functionality that is delivered in our hardware products is also available in our VM-Series virtual firewalls, which secure virtualized and cloud-based computing environments, and in our CN-Series container firewalls, which secure container environments and traffic.

[0001327567-26-000023:mdna:37]
Our subscription and support revenue grew to $9.2 billion, or 80.1% of total revenue for fiscal 2026, representing year-over-year growth of 24%. Our subscriptions provide our end-customers with near real-time access to the latest intrusion prevention, web security, modern malware prevention, data loss prevention, cloud security access broker, and AI security capabilities across the network, endpoints, and the cloud. Our subscriptions also include security operations, which enable customers to leverage the AI-powered Cortex platform for advanced capabilities such as security information and event management, next-generation antivirus, endpoint detection and response, extended detection and response, identity threat detection and response, cloud detection and response, SOAR, ASM, and CNAPP for comprehensive cloud security. In connection with our acquisition of Chronosphere in January 2026, our subscriptions also include a next-generation observability platform for cloud-native infrastructure and applications as well as telemetry pipeline management that is designed to handle vast cloud data volumes with cost-efficiency and reliability. With the acquisition of CyberArk, our subscriptions include a next-generation identity security platform designed to secure human, AI, and machine identity across the enterprise with intelligent privilege controls and continuous threat prevention. Additionally, we offer MDR for Cortex subscriptions, powered by Unit 42’s elite expertise. When customers purchase our physical, virtual, or container firewalls, or certain cloud offerings, they typically purchase support in order to receive ongoing security updates, upgrades, bug fixes, and repairs. In addition to the subscriptions purchased with these firewalls, customers may also purchase other subscriptions on a per-user, per-endpoint, or capacity-based basis. We also offer professional services, including incident response, risk management, digital forensic services, and technical account management.

[0001327567-26-000023:mdna:38]
- 44 -

[0001327567-26-000023:mdna:39]
We continue to invest in innovation as we evolve and further extend the capabilities of our portfolio, as we believe that innovation and timely development of, and investment in, new features and products are essential to meeting the needs of our end-customers and improving our competitive position. During fiscal 2026, we introduced several upgrades and new offerings, including: PAN-OS 12.1 Orion, Prisma AIRS 2.0, NGTS, and Prisma AIRS 3.0. Additionally, we evaluate opportunities to acquire complementary businesses, technologies, services, and intellectual property to complement our organic innovation and research and development efforts, advance the development of our platforms, and enable further investment in our key priority areas. For example, on January 29, 2026, we completed the acquisition of Chronosphere, forming our observability platform; on February 11, 2026, we completed the acquisition of CyberArk, forming our next-generation identity security platform; on April 14, 2026, we completed the acquisition of Koi, adding agentic endpoint security capabilities to our security operations platform and enhancing Prisma AIRS; on May 29, 2026, we completed the acquisition of Portkey, enhancing our Prisma AIRS capabilities; on August 27, 2026, we completed the acquisition of Embrace, which we expect will add RUM capabilities to our observability platform; and on September 1, 2026, we completed the acquisition of Console, which we expect will deepen our agentic capabilities in Cortex. On July 16, 2026, we announced the general availability of Prisma AIRS Gateway, which incorporates AI gateway capabilities acquired through Portkey into Prisma AIRS.

[0001327567-26-000023:mdna:40]
We believe that the growth of our business and our short-term and long-term success are dependent upon many factors, including our ability to extend our technology leadership, grow our base of end-customers, expand deployment of our portfolio and support offerings within existing end-customers, focus on end-customer satisfaction, and address any product vulnerabilities. To manage any future growth effectively, we must continue to improve and expand our information technology and financial infrastructure, our operating and administrative systems and controls, and our ability to manage headcount, capital, and processes in an efficient manner. While these areas present significant opportunities for us, they also pose challenges and risks that we must successfully address in order to sustain the growth of our business and improve our operating results. For additional information regarding the challenges and risks we face, see the “Risk Factors” section in Part I, Item 1A of this Annual Report on Form 10-K.

[0001327567-26-000023:mdna:41]
IMPACT OF MACROECONOMIC DEVELOPMENTS AND OTHER FACTORS ON OUR BUSINESS

[0001327567-26-000023:mdna:42]
Our overall performance depends in part on worldwide economic and geopolitical conditions and their impact on customer behavior. Changes in legislation or regulations and actions by regulators, including changes in enforcement and administration policies, may have an impact on our financial condition and operating results. Significant changes in U.S. or global trade policy, including further expansion of U.S. export/imports controls and tariffs, as well as retaliatory actions by other countries, may materially and adversely affect our business. Further, economic conditions, including inflation, high interest rates, slow growth, fluctuations in foreign exchange rates, supply chain disruptions, including increased memory, storage, or other component shortages and costs, impacts of trade regulations or international trade disputes, and other conditions, may materially and adversely affect our financial condition and operating results.

[0001327567-26-000023:mdna:43]
The hostilities in Israel, Iran, and the surrounding region have continued to result in economic and political uncertainty. While we have business operations in Israel, and intend to continue growing our presence in Israel, we currently do not expect significant business disruption. We are actively monitoring, evaluating, and responding to the situation.

[0001327567-26-000023:mdna:44]
We are also monitoring the impact of inflationary pressures and the tensions between China and Taiwan, and between the U.S. and China, which have increased our costs and could have an adverse impact on our business or results of operations in future periods.

[0001327567-26-000023:mdna:45]
Key Financial Metrics

[0001327567-26-000023:mdna:46]
We monitor the key financial metrics set forth in the tables below to help us evaluate growth trends, establish budgets, measure the effectiveness of our sales and marketing efforts, and assess operational efficiencies. We discuss revenue, gross margin, and the components of operating income and margin below under “Results of Operations.”

[0001327567-26-000023:mdna:47]
|  | July 31, |
|  | 2026 |  | 2025 |
|  | (in billions) |
| Next-Generation Security Annualized Recurring Revenue | $ | 9.1 |  |  | $ | 5.6 |  |
| Remaining performance obligations | $ | 21.2 |  |  | $ | 15.8 |  |

[0001327567-26-000023:mdna:48]
- 45 -

[0001327567-26-000023:mdna:49]
|  | Year Ended July 31, |
|  | 2026 |  | 2025 |  | 2024 |
|  | (dollars in millions) |
| Total revenue | $ | 11,480 |  |  | $ | 9,221 |  |  | $ | 8,027 |  |
| Total revenue year-over-year percentage increase | 24 | % |  | 15 | % |  | 16 | % |
| Gross margin | 70.4 | % |  | 73.4 | % |  | 74.3 | % |
| Operating income | $ | 695 |  |  | $ | 1,243 |  |  | $ | 684 |  |
| Operating margin | 6.1 | % |  | 13.5 | % |  | 8.5 | % |
| Net cash provided by operating activities | $ | 4,553 |  |  | $ | 3,716 |  |  | $ | 3,258 |  |
| Free cash flow (non-GAAP) | $ | 4,113 |  |  | $ | 3,469 |  |  | $ | 3,101 |  |

[0001327567-26-000023:mdna:50]
•Next-Generation Security Annualized Recurring Revenue (“NGS ARR”). Our NGS ARR represents the annualized allocated revenue of all active contracts as of the final day of the reporting period related to all product, subscription, and support offerings, excluding revenue from hardware products, and legacy attached subscriptions, support offerings, and professional services. NGS ARR is an operating metric that we use to assess the strength and trajectory of our business. NGS ARR should be viewed independently of revenue, deferred revenue, and remaining performance obligations and does not represent our revenue under U.S. GAAP on an annualized basis, as it is an operating metric that can be impacted by contract start and end dates and renewal rates. NGS ARR is not intended to be a replacement for forecasts of revenue. The scope of products, subscriptions, and support offerings that contribute to NGS ARR will generally increase over time as we introduce or acquire new next-generation products, subscriptions, and support offerings.

[0001327567-26-000023:mdna:51]
•Net Cash Provided by Operating Activities. We monitor net cash provided by operating activities as a measure of our overall business performance. Our net cash provided by operating activities is driven in large part by sales of our products and from up-front payments for subscription and support offerings. Monitoring net cash provided by operating activities enables us to analyze our financial performance without the non-cash effects of certain items such as share-based compensation costs, depreciation, and amortization, thereby allowing us to better understand and manage the cash needs of our business.

[0001327567-26-000023:mdna:52]
•Free Cash Flow (non-GAAP). We define free cash flow, a non-GAAP financial measure, as net cash provided by operating activities less purchases of property, equipment, and other assets. We consider free cash flow to be an operating metric as well as a liquidity measure that provides useful information to management and investors about the amount of cash generated by the business after necessary capital expenditures. A limitation of the utility of free cash flow as a measure of our liquidity is that it does not represent the total increase or decrease in our cash balance for the period. In addition, it is important to note that other companies, including companies in our industry, may not use free cash flow, may calculate free cash flow in a different manner than we do, or may use other financial measures to evaluate their liquidity, all of which could reduce the usefulness of free cash flow as a comparative measure. A reconciliation of free cash flow to net cash provided by operating activities, the most directly comparable financial measure calculated and presented in accordance with U.S. GAAP, is provided below:

[0001327567-26-000023:mdna:53]
|  | Year Ended July 31, |
|  | 2026 |  | 2025 |  | 2024 |
|  | (in millions) |
| Free cash flow (non-GAAP): |  |  |  |  |  |
| Net cash provided by operating activities | $ | 4,553 |  |  | $ | 3,716 |  |  | $ | 3,258 |  |
| Less: purchases of property, equipment, and other assets | 440 |  |  | 247 |  |  | 157 |  |
| Free cash flow (non-GAAP) | $ | 4,113 |  |  | $ | 3,469 |  |  | $ | 3,101 |  |
| Net cash used in investing activities | $ | (3,104) |  |  | $ | (2,205) |  |  | $ | (1,510) |  |
| Net cash used in financing activities | $ | (1,202) |  |  | $ | (779) |  |  | $ | (1,343) |  |

[0001327567-26-000023:mdna:54]
- 46 -

[0001327567-26-000023:mdna:55]
Results of Operations

[0001327567-26-000023:mdna:56]
The following table summarizes our results of operations for the periods presented and as a percentage of our total revenue for those periods based on our consolidated statements of operations data. The period-to-period comparison of results is not necessarily indicative of results for future periods.

[0001327567-26-000023:mdna:57]
|  | Year Ended July 31, |
|  | 2026 |  | 2025 |  | 2024 |
|  | Amount |  | % of Revenue |  | Amount |  | % of Revenue |  | Amount |  | % of Revenue |
|  | (dollars in millions) |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 2,280 |  |  | 19.9 | % |  | $ | 1,802 |  |  | 19.5 | % |  | $ | 1,603 |  |  | 20.0 | % |
| Subscription and support | 9,200 |  |  | 80.1 | % |  | 7,419 |  |  | 80.5 | % |  | 6,424 |  |  | 80.0 | % |
| Total revenue | 11,480 |  |  | 100.0 | % |  | 9,221 |  |  | 100.0 | % |  | 8,027 |  |  | 100.0 | % |
| Cost of revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Product | 568 |  |  | 4.9 | % |  | 413 |  |  | 4.5 | % |  | 348 |  |  | 4.3 | % |
| Subscription and support | 2,835 |  |  | 24.7 | % |  | 2,038 |  |  | 22.1 | % |  | 1,711 |  |  | 21.4 | % |
| Total cost of revenue(1) | 3,403 |  |  | 29.6 | % |  | 2,451 |  |  | 26.6 | % |  | 2,059 |  |  | 25.7 | % |
| Total gross profit | 8,077 |  |  | 70.4 | % |  | 6,770 |  |  | 73.4 | % |  | 5,968 |  |  | 74.3 | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | 2,552 |  |  | 22.2 | % |  | 1,984 |  |  | 21.5 | % |  | 1,810 |  |  | 22.5 | % |
| Sales and marketing | 3,931 |  |  | 34.3 | % |  | 3,100 |  |  | 33.6 | % |  | 2,794 |  |  | 34.8 | % |
| General and administrative | 899 |  |  | 7.8 | % |  | 443 |  |  | 4.8 | % |  | 680 |  |  | 8.5 | % |
| Total operating expenses(1) | 7,382 |  |  | 64.3 | % |  | 5,527 |  |  | 59.9 | % |  | 5,284 |  |  | 65.8 | % |
| Operating income | 695 |  |  | 6.1 | % |  | 1,243 |  |  | 13.5 | % |  | 684 |  |  | 8.5 | % |
| Other income (expense), net | (159) |  |  | (1.4) | % |  | 353 |  |  | 3.8 | % |  | 304 |  |  | 3.8 | % |
| Income before income taxes | 536 |  |  | 4.7 | % |  | 1,596 |  |  | 17.3 | % |  | 988 |  |  | 12.3 | % |
| Provision for (benefit from) income taxes | 229 |  |  | 2.0 | % |  | 462 |  |  | 5.0 | % |  | (1,590) |  |  | (19.8) | % |
| Net income | $ | 307 |  |  | 2.7 | % |  | $ | 1,134 |  |  | 12.3 | % |  | $ | 2,578 |  |  | 32.1 | % |

[0001327567-26-000023:mdna:58]
(1)Includes share-based compensation as follows:

[0001327567-26-000023:mdna:59]
|  | Year Ended July 31, |
|  | 2026 |  | 2025 |  | 2024 |
|  | (in millions) |
| Cost of product revenue | $ | 5 |  |  | $ | 5 |  |  | $ | 7 |  |
| Cost of subscription and support revenue | 161 |  |  | 127 |  |  | 121 |  |
| Research and development | 688 |  |  | 551 |  |  | 526 |  |
| Sales and marketing | 513 |  |  | 359 |  |  | 301 |  |
| General and administrative | 448 |  |  | 258 |  |  | 124 |  |
| Total share-based compensation | $ | 1,815 |  |  | $ | 1,300 |  |  | $ | 1,079 |  |

[0001327567-26-000023:mdna:60]
- 47 -

[0001327567-26-000023:mdna:61]
IMPACT OF ACQUISITIONS

[0001327567-26-000023:mdna:62]
Our operating results were impacted by our acquisitions. In discussions of our results of operations, we may qualitatively or quantitatively disclose the impact of our acquisitions on revenue, costs, and expenses for the one year period subsequent to the acquisition date where such discussions would be meaningful.

[0001327567-26-000023:mdna:63]
REVENUE

[0001327567-26-000023:mdna:64]
Our revenue consists of product revenue and subscription and support revenue. Revenue is recognized upon transfer of control of the corresponding promised products and subscriptions and support to our customers in an amount that reflects the consideration we expect to be entitled to in exchange for those products and subscriptions and support. We expect our revenue to vary from quarter to quarter based on seasonal and cyclical factors and business acquisitions.

[0001327567-26-000023:mdna:65]
PRODUCT REVENUE

[0001327567-26-000023:mdna:66]
Product revenue is derived from sales of hardware products, primarily our ML-Powered NGFW, software licenses, including SD-WAN, VM-Series, Panorama, and certain identity security offerings. Our hardware products and software licenses include a broad set of built-in networking and security features and functionalities. We recognize product revenue at the time of hardware shipment or delivery of software license. As a percentage of product revenue, we expect our revenue from software licenses to vary from quarter to quarter and increase over the long term as we improve features and capabilities of our on-premise software, renew our software license contracts, and expand our installed end-customer base.

[0001327567-26-000023:mdna:67]
|  | Year Ended July 31, |  |  |  | Year Ended July 31, |  |  |
|  | 2026 |  | 2025 |  | Change |  | 2025 |  | 2024 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Product | $ | 2,280 |  |  | $ | 1,802 |  |  | $ | 478 |  |  | 27 | % |  | $ | 1,802 |  |  | $ | 1,603 |  |  | $ | 199 |  |  | 12 | % |

[0001327567-26-000023:mdna:68]
Product revenue increased for fiscal 2026 compared to fiscal 2025 driven by increased revenue from software licenses, including from our CyberArk acquisition, and increased demand for our new generation of hardware products.

[0001327567-26-000023:mdna:69]
SUBSCRIPTION AND SUPPORT REVENUE

[0001327567-26-000023:mdna:70]
Subscription and support revenue is derived primarily from sales of our subscription and support offerings. Our subscription and support contracts are typically one to five years. We recognize revenue from subscriptions and support over time as the services are performed. As a percentage of total revenue, we expect our subscription and support revenue to vary from quarter to quarter and increase over the long term as we introduce new subscriptions, renew existing subscription and support contracts, and expand our installed end-customer base.

[0001327567-26-000023:mdna:71]
|  | Year Ended July 31, |  |  |  | Year Ended July 31, |  |  |
|  | 2026 |  | 2025 |  | Change |  | 2025 |  | 2024 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Subscription | $ | 6,239 |  |  | $ | 4,974 |  |  | $ | 1,265 |  |  | 25 | % |  | $ | 4,974 |  |  | $ | 4,188 |  |  | $ | 786 |  |  | 19 | % |
| Support | 2,961 |  |  | 2,445 |  |  | 516 |  |  | 21 | % |  | 2,445 |  |  | 2,236 |  |  | 209 |  |  | 9 | % |
| Total subscription and support | $ | 9,200 |  |  | $ | 7,419 |  |  | $ | 1,781 |  |  | 24 | % |  | $ | 7,419 |  |  | $ | 6,424 |  |  | $ | 995 |  |  | 16 | % |

[0001327567-26-000023:mdna:72]
Subscription and support revenue increased for fiscal 2026 compared to fiscal 2025 due to increased demand for our subscription and support offerings from our end-customers, including from our CyberArk and Chronosphere acquisitions. The mix between subscription revenue and support revenue will fluctuate over time, depending on the introduction of new subscription offerings, renewals of support services, and our ability to increase sales to new and existing end-customers.

[0001327567-26-000023:mdna:73]
- 48 -

[0001327567-26-000023:mdna:74]
REVENUE BY GEOGRAPHIC THEATER

[0001327567-26-000023:mdna:75]
|  | Year Ended July 31, |  |  |  | Year Ended July 31, |  |  |
|  | 2026 |  | 2025 |  | Change |  | 2025 |  | 2024 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Americas | $ | 7,679 |  |  | $ | 6,205 |  |  | $ | 1,474 |  |  | 24 | % |  | $ | 6,205 |  |  | $ | 5,483 |  |  | $ | 722 |  |  | 13 | % |
| Europe, the Middle East, and Africa (“EMEA”) | 2,428 |  |  | 1,917 |  |  | 511 |  |  | 27 | % |  | 1,917 |  |  | 1,602 |  |  | 315 |  |  | 20 | % |
| Asia Pacific and Japan (“APAC”) | 1,373 |  |  | 1,099 |  |  | 274 |  |  | 25 | % |  | 1,099 |  |  | 942 |  |  | 157 |  |  | 17 | % |
| Total revenue | $ | 11,480 |  |  | $ | 9,221 |  |  | $ | 2,259 |  |  | 25 | % |  | $ | 9,221 |  |  | $ | 8,027 |  |  | $ | 1,194 |  |  | 15 | % |

[0001327567-26-000023:mdna:76]
Revenue from the Americas, EMEA and APAC increased year-over-year for fiscal 2026 as we continued to increase investment in our global sales force in order to support our growth and innovation, with the Americas contributing the highest increase in revenue due to its larger scale.

[0001327567-26-000023:mdna:77]
COST OF REVENUE

[0001327567-26-000023:mdna:78]
Our cost of revenue consists of cost of product revenue and cost of subscription and support revenue.

[0001327567-26-000023:mdna:79]
COST OF PRODUCT REVENUE

[0001327567-26-000023:mdna:80]
Cost of product revenue primarily includes costs paid to our manufacturing partners for procuring components and manufacturing our products. Our cost of product revenue also includes personnel costs, which consist of salaries, benefits, bonuses, share-based compensation, and travel associated with our operations organization, inventory excess and obsolete charges, shipping and tariff costs, amortization of intangible assets, product testing costs, and shared costs. Shared costs consist of certain facilities, depreciation, benefits, recruiting, and information technology costs that we allocate based on headcount. We expect our cost of product revenue to fluctuate with our revenue from hardware products.

[0001327567-26-000023:mdna:81]
|  | Year Ended July 31, |  |  |  | Year Ended July 31, |  |  |
|  | 2026 |  | 2025 |  | Change |  | 2025 |  | 2024 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Cost of product revenue | $ | 568 |  |  | $ | 413 |  |  | $ | 155 |  |  | 38 | % |  | $ | 413 |  |  | $ | 348 |  |  | $ | 65 |  |  | 19 | % |

[0001327567-26-000023:mdna:82]
Cost of product revenue increased for fiscal 2026 compared to fiscal 2025 primarily due to increased demand for our hardware products, higher amortization of intangible assets as a result of our CyberArk acquisition, and higher costs primarily driven by supply chain challenges, partially offset by a decrease in inventory excess and obsolete charges.

[0001327567-26-000023:mdna:83]
COST OF SUBSCRIPTION AND SUPPORT REVENUE

[0001327567-26-000023:mdna:84]
Cost of subscription and support revenue includes personnel costs for our global customer support and technical operations organizations, data center and cloud hosting costs, third-party professional services costs, amortization of acquired intangible assets and capitalized software development costs, customer support and repair costs, and shared costs. We expect our cost of subscription and support revenue to increase as our installed end-customer base grows and adoption of our cloud-based subscription offerings increases.

[0001327567-26-000023:mdna:85]
|  | Year Ended July 31, |  |  |  | Year Ended July 31, |  |  |
|  | 2026 |  | 2025 |  | Change |  | 2025 |  | 2024 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Cost of subscription and support revenue | $ | 2,835 |  |  | $ | 2,038 |  |  | $ | 797 |  |  | 39 | % |  | $ | 2,038 |  |  | $ | 1,711 |  |  | $ | 327 |  |  | 19 | % |

[0001327567-26-000023:mdna:86]
Cost of subscription and support revenue increased for fiscal 2026 compared to fiscal 2025, primarily due to higher cloud hosting costs to support the growth of our cloud-based offerings, amortization of intangible assets from acquisitions in fiscal 2026, and personnel costs driven by headcount growth, including from our acquisitions.

[0001327567-26-000023:mdna:87]
- 49 -

[0001327567-26-000023:mdna:88]
GROSS MARGIN

[0001327567-26-000023:mdna:89]
Gross margin has been and will continue to be affected by a variety of factors, including the introduction of new products, manufacturing costs, the average sales price of our products, cloud hosting costs, personnel costs, the mix of products sold, and the mix of revenue between product and subscription and support offerings. Our higher-end firewall products generally have higher gross margins than our lower-end firewall products within each product series. We expect our gross margins to vary over time depending on the factors described above.

[0001327567-26-000023:mdna:90]
|  | Year Ended July 31, |
|  | 2026 |  | 2025 |  | 2024 |
|  | Amount |  | Gross Margin |  | Amount |  | Gross Margin |  | Amount |  | Gross Margin |
|  | (dollars in millions) |
| Product | $ | 1,712 |  |  | 75.1 | % |  | $ | 1,389 |  |  | 77.1 | % |  | $ | 1,255 |  |  | 78.3 | % |
| Subscription and support | 6,365 |  |  | 69.2 | % |  | 5,381 |  |  | 72.5 | % |  | 4,713 |  |  | 73.4 | % |
| Total gross profit | $ | 8,077 |  |  | 70.4 | % |  | $ | 6,770 |  |  | 73.4 | % |  | $ | 5,968 |  |  | 74.3 | % |

[0001327567-26-000023:mdna:91]
Product gross margin decreased for fiscal 2026 compared to fiscal 2025 primarily due to a decrease in gross margin on our hardware products, including the impact from supply chain challenges, and higher amortization of intangible assets, partially offset by an increase in software license revenue from our CyberArk acquisition and decrease in inventory excess and obsolete charges.

[0001327567-26-000023:mdna:92]
Subscription and support gross margin decreased for fiscal 2026 compared to fiscal 2025 primarily due to higher amortization of intangible assets as a result of our acquisitions in our current fiscal year and an increase in costs related to our cloud-based offerings.

[0001327567-26-000023:mdna:93]
OPERATING EXPENSES

[0001327567-26-000023:mdna:94]
Our operating expenses consist of research and development, sales and marketing, and general and administrative expenses. Personnel costs are the most significant component of operating expenses and consist of salaries, benefits, bonuses, share-based compensation, travel and entertainment, and with regard to sales and marketing expense, sales commissions. Our operating expenses also include shared costs, which consist of certain facilities, depreciation, benefits, recruiting, and information technology costs that we allocate based on headcount to each department. We expect operating expenses generally to increase in absolute dollars and to decrease over the long term as a percentage of revenue as we continue to scale our business. As of July 31, 2026, we expect to recognize approximately $3.3 billion of share-based compensation expense over a weighted-average period of approximately 2.5 years, excluding additional share-based compensation expense related to any future grants of share-based awards. Share-based compensation expense is generally recognized on a straight-line basis over the requisite service periods of the awards.

[0001327567-26-000023:mdna:95]
In March 2026, the Knesset Finance Committee approved the Law for the Encouragement and Incentivization of Research and Development (the “R&D Law”), which provides incentives for qualifying research and development expenditures incurred on or after January 1, 2026. The R&D Law introduces a qualified refundable tax credit, at varying rates based on specified thresholds, for qualifying research and development expenditures incurred in Israel, subject to meeting defined eligibility criteria. The R&D Law further provides that all or a portion of any unutilized tax credit will be refunded in cash upon the lapse of a period stipulated by the R&D Law. The amount of credit ultimately realized, if any, may differ from our current estimates due to, among other things, changes in the interpretive guidance, eligibility determination, or additional regulations that the Israeli government has indicated it intends to issue regarding the implementation of the R&D Law. For the year ended July 31, 2026, the impact of the R&D Law was not material to our consolidated financial statements. The benefit associated with the R&D Law may vary in future periods depending on the level and nature of qualifying expenditures, the evolving regulatory framework, and other factors.

[0001327567-26-000023:mdna:96]
- 50 -

[0001327567-26-000023:mdna:97]
RESEARCH AND DEVELOPMENT

[0001327567-26-000023:mdna:98]
Research and development expense consists primarily of personnel costs. Research and development expense also includes cloud hosting and shared costs. We expect research and development expense to increase in absolute dollars as we continue to invest in our future products and services, although our research and development expense may fluctuate as a percentage of total revenue.

[0001327567-26-000023:mdna:99]
|  | Year Ended July 31, |  |  |  | Year Ended July 31, |  |  |
|  | 2026 |  | 2025 |  | Change |  | 2025 |  | 2024 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Research and development | $ | 2,552 |  |  | $ | 1,984 |  |  | $ | 568 |  |  | 29 | % |  | $ | 1,984 |  |  | $ | 1,810 |  |  | $ | 174 |  |  | 10 | % |

[0001327567-26-000023:mdna:100]
Research and development expense increased for fiscal 2026 compared to fiscal 2025 primarily due to increased personnel costs, which increased by $429 million for fiscal 2026 compared to fiscal 2025, largely due to headcount growth, including from our acquisitions.

[0001327567-26-000023:mdna:101]
SALES AND MARKETING

[0001327567-26-000023:mdna:102]
Sales and marketing expense consists primarily of personnel costs, including commission expense. Sales and marketing expense also includes costs for market development programs, promotional and other marketing costs, professional services, amortization of intangible assets, and shared costs. We continue to strategically invest in headcount and have grown our sales presence. We expect sales and marketing expense to continue to increase in absolute dollars as we increase the size of our sales and marketing organizations to grow our customer base, increase touch points with end-customers, and expand our global presence, although our sales and marketing expense may fluctuate as a percentage of total revenue.

[0001327567-26-000023:mdna:103]
|  | Year Ended July 31, |  |  |  | Year Ended July 31, |  |  |
|  | 2026 |  | 2025 |  | Change |  | 2025 |  | 2024 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Sales and marketing | $ | 3,931 |  |  | $ | 3,100 |  |  | $ | 831 |  |  | 27 | % |  | $ | 3,100 |  |  | $ | 2,794 |  |  | $ | 306 |  |  | 11 | % |

[0001327567-26-000023:mdna:104]
Sales and marketing expense increased for fiscal 2026 compared to fiscal 2025 primarily due to increased personnel costs, which increased by $584 million for fiscal 2026 compared to fiscal 2025, largely due to headcount growth, including from our acquisitions. The increase was further driven by higher amortization of purchased intangible assets as a result of our acquisitions in fiscal 2026.

[0001327567-26-000023:mdna:105]
GENERAL AND ADMINISTRATIVE

[0001327567-26-000023:mdna:106]
General and administrative expense consists primarily of personnel costs and shared costs for our executive, finance, human resources, information technology, and legal organizations, and professional services costs, which consist primarily of legal, auditing, accounting, and other consulting costs. General and administrative expense also includes change in fair value of contingent consideration liability. Excluding the near-term impact of our acquisitions in our current fiscal year, we expect general and administrative expense to increase in absolute dollars over time as we increase the size of our general and administrative organizations and incur additional costs to support our business growth, although our general and administrative expense may fluctuate as a percentage of total revenue.

[0001327567-26-000023:mdna:107]
|  | Year Ended July 31, |  |  |  | Year Ended July 31, |  |  |
|  | 2026 |  | 2025 |  | Change |  | 2025 |  | 2024 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| General and administrative | $ | 899 |  |  | $ | 443 |  |  | $ | 456 |  |  | 103 | % |  | $ | 443 |  |  | $ | 680 |  |  | $ | (237) |  |  | (35) | % |

[0001327567-26-000023:mdna:108]
General and administrative expense increased for fiscal 2026 compared to fiscal 2025 primarily due to increased personnel costs, which grew $253 million for fiscal 2026 compared to fiscal 2025, primarily due to accelerated vesting of certain equity awards in connection with our acquisitions in fiscal year 2026, employee severance charges in connection with our CyberArk acquisition, and headcount growth, including from our acquisitions. The increase in general and administrative expense was further driven by an increase in acquisition-related costs.

[0001327567-26-000023:mdna:109]
- 51 -

[0001327567-26-000023:mdna:110]
OTHER INCOME (EXPENSE), NET

[0001327567-26-000023:mdna:111]
Other income (expense), net includes interest income earned on our cash, cash equivalents, and investments, interest expense related to our 0.375% Convertible Senior Notes due 2025 (the “2025 Notes”), gains and losses from foreign currency remeasurement and foreign currency transactions, and changes in fair value of our 0.0% Convertible Senior Notes due 2030 (the “2030 Notes”) and capped call transactions we assumed in connection with our acquisition of CyberArk (“Capped Calls”).

[0001327567-26-000023:mdna:112]
|  | Year Ended July 31, |  |  |  | Year Ended July 31, |  |  |
|  | 2026 |  | 2025 |  | Change |  | 2025 |  | 2024 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Other income (expense), net | $ | (159) |  |  | $ | 353 |  |  | $ | (512) |  |  | (145) | % |  | $ | 353 |  |  | $ | 304 |  |  | $ | 49 |  |  | 16 | % |

[0001327567-26-000023:mdna:113]
Other income (expense), net decreased for fiscal 2026 compared to fiscal 2025 primarily due to a loss from the change in fair value of our 2030 Notes, partially offset by gains from the change in fair value of our Capped Calls and gains on sales of our investments to fund acquisitions.

[0001327567-26-000023:mdna:114]
PROVISION FOR (BENEFIT FROM) INCOME TAXES

[0001327567-26-000023:mdna:115]
Provision for income taxes consists primarily of U.S. and foreign income taxes. We had a benefit from income taxes during fiscal 2024 primarily due to the release of our valuation allowance on U.S. federal, U.S. states other than California, and U.K. deferred tax assets.

[0001327567-26-000023:mdna:116]
|  | Year Ended July 31, |  |  |  |  |  | Year Ended July 31, |  |  |  |  |
|  | 2026 |  | 2025 |  | Change |  | 2025 |  | 2024 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Provision for (benefit from) income taxes | $ | 229 |  |  | $ | 462 |  |  | $ | (233) |  |  | (50) | % |  | $ | 462 |  |  | $ | (1,590) |  |  | $ | 2,052 |  |  | (129) | % |
| Effective tax rate | 42.7 | % |  | 28.9 | % |  |  |  |  |  | 28.9 | % |  | (160.8) | % |  |  |  |  |

[0001327567-26-000023:mdna:117]
Our effective tax rate increased for fiscal 2026 compared to fiscal 2025 primarily due to non-deductible changes in fair value of our 2030 Notes and Capped Calls and share based compensation, partially offset by intercompany legal entity restructuring in fiscal 2026 and the impact of adoption of One Big Beautiful Bill Act in fiscal 2025.

[0001327567-26-000023:mdna:118]
- 52 -

[0001327567-26-000023:mdna:119]
Liquidity and Capital Resources

[0001327567-26-000023:mdna:120]
|  | July 31, |
|  | 2026 |  | 2025 |
|  | (in millions) |
| Working capital (deficit) | $ | (1,280) |  |  | $ | (465) |  |
| Cash, cash equivalents, and investments: |  |  |  |
| Cash and cash equivalents | $ | 2,514 |  |  | $ | 2,269 |  |
| Investments | 5,392 |  |  | 6,190 |  |
| Total cash, cash equivalents, and investments | $ | 7,906 |  |  | $ | 8,459 |  |

[0001327567-26-000023:mdna:121]
As of July 31, 2026, our total cash, cash equivalents, and investments of $7.9 billion were held for general corporate purposes. As part of the acquisition of CyberArk, we executed an intercompany transaction to repatriate $3.5 billion of foreign earnings, resulting in immaterial income tax expense related to state and other taxes. Our remaining unremitted earnings are indefinitely reinvested.

[0001327567-26-000023:mdna:122]
DEBT

[0001327567-26-000023:mdna:123]
In February 2026 in connection with the acquisition of CyberArk, we entered into a supplemental indenture (the “Supplemental Indenture”) to the Indenture, dated as of June 10, 2025 (together with the Supplemental Indenture, the “Indenture”), between CyberArk, as issuer, and U.S. Bank Trust Company, National Association, as trustee, governing CyberArk’s $1.25 billion aggregate principal amount of the 2030 Notes. As a result of our acquisition of CyberArk and pursuant to the Supplemental Indenture, the 2030 Notes are now exchangeable into shares of our common stock and cash. The 2030 Notes mature on June 15, 2030; however, under certain circumstances, holders may surrender their 2030 Notes for conversion prior to the maturity date. Upon conversion of the 2030 Notes, we will pay cash equal to the aggregate principal amount of the 2030 Notes to be converted, and, at our election, we will pay or deliver cash or a combination of cash and shares of our common stock for the amount of our conversion obligation in excess of the aggregate principal amount of the 2030 Notes converted. During the year ended July 31, 2026, holders surrendered $153 million in aggregate principal amount of the 2030 Notes for conversion, which were settled for $160 million in cash. After giving effect to these conversions, the remaining outstanding principal balance of the 2030 Notes was $1.1 billion.

[0001327567-26-000023:mdna:124]
The sale price condition for the 2030 Notes was not met during the calendar quarter ended June 30, 2026, and as a result, our 2030 Notes are not convertible pursuant to that condition during the calendar quarter ending September 30, 2026. If the sale price condition for the 2030 Notes is met during the calendar quarter ending September 30, 2026 and all of the holders elect to convert their 2030 Notes during the calendar quarter ending December 31, 2026, we would be obligated to settle the $1.1 billion principal amount of the 2030 Notes and a portion of our conversion obligation in excess of the aggregate principal amount of the 2030 Notes, if any, in cash. We believe that our net cash provided by operating activities, our existing cash, cash equivalents, and investments, and existing sources of and access to financing, including any proceeds that may be received from the settlement or termination of the outstanding Capped Calls, will be sufficient to meet our anticipated cash needs should the holders choose to convert their 2030 Notes during the fiscal quarter ending October 31, 2026 or hold the 2030 Notes until maturity on June 15, 2030. Refer to Note 11. Debt in Part II, Item 8 of this Annual Report on Form 10-K for more information on the 2030 Notes.

[0001327567-26-000023:mdna:125]
In April 2023, we entered into a credit agreement (the “Credit Agreement”) that provides for a $400 million unsecured revolving credit facility (the “Credit Facility”), with an option to increase the amount of the Credit Facility by up to an additional $350 million, subject to certain conditions. The interest rates and commitment fees are also subject to upward and downward adjustments based on our progress towards the achievement of certain sustainability goals. As of July 31, 2026, there were no amounts outstanding, and no default or event of default has occurred under the Credit Agreement. Refer to Note 11 Debt in Part II, Item 8 of this Annual Report on Form 10-K for more information on the Credit Agreement.

[0001327567-26-000023:mdna:126]
CAPITAL RETURN

[0001327567-26-000023:mdna:127]
In February 2019, our board of directors authorized a $1.0 billion share repurchase program. Our board of directors subsequently authorized additional increases to this share repurchase program, bringing the total authorization to $5.1 billion. Repurchases will be funded from available working capital and may be made at management’s discretion from time to time. As of July 31, 2026, $1.0 billion remained available for future share repurchases under this repurchase program. The repurchase authorization will expire on December 31, 2026 and may be suspended or discontinued at any time without prior notice. Refer to Note 14. Stockholders’ Equity in Part II, Item 8 of this Annual Report on Form 10-K for more information on this repurchase program.

[0001327567-26-000023:mdna:128]
- 53 -

[0001327567-26-000023:mdna:129]
CONTRACTUAL OBLIGATIONS AND OTHER MATERIAL CASH REQUIREMENTS

[0001327567-26-000023:mdna:130]
We have entered into various non-cancelable operating leases, primarily for our offices, with lease terms expiring through fiscal 2040, with the most significant leases relating to our corporate headquarters in Santa Clara, California. As of July 31, 2026, we have total operating lease obligations of $793 million recorded on our consolidated balance sheet.

[0001327567-26-000023:mdna:131]
As of July 31, 2026, our commitments to purchase products, components, cloud hosting, and other services totaled $8.3 billion. Refer to Note 13. Commitments and Contingencies in Part II, Item 8 of this Annual Report on Form 10-K for more information on these commitments.

[0001327567-26-000023:mdna:132]
Our acquisition of certain QRadar assets from International Business Machines Corporation (“IBM”) on August 31, 2024 included contingent consideration that requires potential future payments through the fiscal quarter ending October 31, 2028. As of July 31, 2026, we have a contingent consideration obligation of $206 million recorded on our consolidated balance sheet. Refer to Note 3. Fair Value Measurements and Note 8. Acquisitions in Part II, Item 8 of this Annual Report on Form 10-K for more information on our contingent consideration obligation.

[0001327567-26-000023:mdna:133]
CASH FLOWS

[0001327567-26-000023:mdna:134]
The following table summarizes our cash flows for the years ended July 31, 2026, 2025, and 2024:

[0001327567-26-000023:mdna:135]
|  | Year Ended July 31, |
| 2026 |  | 2025 |  | 2024 |
|  | (in millions) |
| Net cash provided by operating activities | $ | 4,553 |  |  | $ | 3,716 |  |  | $ | 3,258 |  |
| Net cash used in investing activities | (3,104) |  |  | (2,205) |  |  | (1,510) |  |
| Net cash used in financing activities | (1,202) |  |  | (779) |  |  | (1,343) |  |
| Effect of exchange rate changes on cash, cash equivalents, and restricted cash | (3) |  |  | — |  |  | — |  |
| Net increase in cash, cash equivalents, and restricted cash | $ | 244 |  |  | $ | 732 |  |  | $ | 405 |  |

[0001327567-26-000023:mdna:136]
Cash flows from operations could be affected by various risks and uncertainties detailed in Part I, Item 1A “Risk Factors” in this Annual Report on Form 10-K. We believe that our cash flow from operations with existing cash and cash equivalents will be sufficient to meet our anticipated cash needs for at least the next 12 months and thereafter for the foreseeable future. Our future capital requirements will depend on many factors including our growth rate, the timing and extent of spending to support development efforts, the expansion of sales and marketing activities, the introduction of new and enhanced products and subscription and support offerings, the costs to acquire or invest in complementary businesses and technologies, the costs to ensure access to adequate manufacturing capacity, the investments in our infrastructure to support the adoption of our cloud-based subscription offerings, the continuing market acceptance of our products and subscription and support offerings, and macroeconomic events. In addition, from time to time, we may incur additional tax liability in connection with certain corporate structuring decisions.

[0001327567-26-000023:mdna:137]
We may also choose to seek additional equity or debt financing. In the event that additional financing is required from outside sources, we may not be able to raise it on terms acceptable to us or at all. If we are unable to raise additional capital when desired, our business, financial condition, and operating results may be adversely affected.

[0001327567-26-000023:mdna:138]
OPERATING ACTIVITIES

[0001327567-26-000023:mdna:139]
Our operating activities have consisted of net income adjusted for certain non-cash items and changes in assets and liabilities. Our largest source of cash provided by our operations is receipts from our customers. Net cash provided by operating activities can be impacted by factors such as timing of payments and collections, vendor payment terms, and timing and amount of tax payments.

[0001327567-26-000023:mdna:140]
Net cash provided by operating activities during fiscal 2026 was $4.6 billion, an increase of $837 million compared to fiscal 2025. The increase was primarily due to growth of our business as reflected by increases in collections during fiscal 2026, partially offset by higher cash expenditure to support our business growth.

[0001327567-26-000023:mdna:141]
INVESTING ACTIVITIES

[0001327567-26-000023:mdna:142]
Our investing activities have consisted of capital expenditures, net investment purchases, sales, and maturities, and business acquisitions. We expect to continue such activities as our business grows.

[0001327567-26-000023:mdna:143]
- 54 -

[0001327567-26-000023:mdna:144]
Net cash used in investing activities during fiscal 2026 was $3.1 billion, an increase of $899 million compared to fiscal 2025. The increase was primarily due to an increase in net cash payments for business acquisitions during fiscal 2026, partially offset by higher proceeds from sales and maturities of investments.

[0001327567-26-000023:mdna:145]
FINANCING ACTIVITIES

[0001327567-26-000023:mdna:146]
Our financing activities have consisted of repayments and settlement of conversions of our convertible senior notes, proceeds from Capped Calls, cash used to repurchase shares of our common stock, proceeds from sales of shares through employee equity incentive plans, payments for tax withholding obligations of certain employees related to the net share settlement of equity awards, and payments of contingent consideration.

[0001327567-26-000023:mdna:147]
Net cash used in financing activities during fiscal 2026 was $1.2 billion, an increase of $423 million compared to fiscal 2025. The increase was primarily due to repurchases of our common stock and payments of our contingent consideration during fiscal 2026, partially offset by a decrease in cash used for repayments and settlement of conversions of our convertible notes.

[0001327567-26-000023:mdna:148]
Critical Accounting Estimates

[0001327567-26-000023:mdna:149]
Our consolidated financial statements have been prepared in accordance with U.S. GAAP. The preparation of these consolidated financial statements requires us to make estimates and assumptions that affect the reported amounts of assets, liabilities, revenue, expenses, and related disclosures. We base our estimates on historical experience and on various other assumptions that we believe are reasonable under the circumstances. We evaluate our estimates and assumptions on an ongoing basis. Actual results could differ materially from those estimates due to risks and uncertainties, including uncertainty in the current economic environment. To the extent that there are material differences between these estimates and our actual results, our future consolidated financial statements will be affected.

[0001327567-26-000023:mdna:150]
We believe that of our significant accounting policies described in Note 1. Description of Business and Summary of Significant Accounting Policies in Part II, Item 8 of this Annual Report on Form 10-K, the critical accounting estimates, assumptions, and judgments that have the most significant impact on our consolidated financial statements are described below.

[0001327567-26-000023:mdna:151]
REVENUE RECOGNITION

[0001327567-26-000023:mdna:152]
The majority of our contracts with our customers include various combinations of our products and subscriptions and support. Our hardware products and software licenses are distinct from our subscriptions and support services as the customer can benefit from the product without these services and such services are separately identifiable within the contract. We account for multiple agreements with a single customer as a single contract if the contractual terms and/or substance of those agreements indicate that they may be so closely related that they are, in effect, parts of a single contract. The amount of consideration we expect to receive in exchange for delivering on the contract is allocated to each performance obligation based on its relative standalone selling price.

[0001327567-26-000023:mdna:153]
When estimating standalone selling price, we first consider the prices charged for a deliverable when sold separately. If the standalone selling price is not observable through past transactions, we estimate it based on our pricing model and our go-to-market strategy, which include factors such as type of sales channel (channel partner or end-customer), the geographies in which our offerings were sold (domestic or international), and offering type (products, subscriptions, or support). As our business offerings evolve over time, we may be required to modify our estimated standalone selling prices, and as a result the timing and classification of our revenue could be affected.

[0001327567-26-000023:mdna:154]
INCOME TAXES

[0001327567-26-000023:mdna:155]
We account for income taxes using the asset and liability method, which requires the recognition of deferred tax assets and liabilities for the expected future tax consequences of events that have been recognized in our consolidated financial statements or tax returns. In addition, deferred tax assets are recorded for all future benefits including, but not limited to, net operating losses, research and development credit carryforwards, and basis differences relating to our global intangible low-taxed income. Valuation allowances are provided when necessary to reduce deferred tax assets to the amount more likely than not to be realized.

[0001327567-26-000023:mdna:156]
Significant judgment is required in determining any valuation allowance recorded against deferred tax assets. In assessing the need for a valuation allowance, we consider all available evidence, including past operating results, estimates of future taxable income, and the feasibility of tax planning strategies. In the event that we change our determination as to the amount of deferred tax assets that can be realized, we will adjust our valuation allowance with a corresponding impact to the provision for income taxes in the period in which such determination is made.

[0001327567-26-000023:mdna:157]
- 55 -

[0001327567-26-000023:mdna:158]
We recognize liabilities for uncertain tax positions based on a two-step process which includes evaluating if a tax position is more likely than not to be sustained on audit and then measuring the tax benefit as the largest amount that is more likely than not to be realized upon ultimate settlement. Assumptions, judgment, and the use of estimates are required in determining if the more-likely-than-not standard has been met and in determining the expected benefit when developing the provision for income taxes. Our evaluations are based upon a number of factors, including changes in facts or circumstances, changes in tax law or guidance, correspondence with tax authorities during the course of audits, and effective settlement of audit issues. Changes in these or other factors could result in material increases or decreases in our provision for (benefit from) income taxes in the period in which we make the change.

[0001327567-26-000023:mdna:159]
LOSS CONTINGENCIES

[0001327567-26-000023:mdna:160]
We are subject to the possibility of various loss contingencies arising in the ordinary course of business. We accrue for loss contingencies when it is probable that an asset has been impaired or a liability has been incurred and the amount of loss can be reasonably estimated. If we determine that a loss is reasonably possible, then we disclose the possible loss or range of the possible loss or state that such an estimate cannot be made. We regularly evaluate current information available to us to determine whether an accrual is required, an accrual should be adjusted, or a range of possible loss should be disclosed.

[0001327567-26-000023:mdna:161]
From time to time, we are involved in disputes, litigation, and other legal actions. However, there are many uncertainties associated with any litigation, and these actions or other third-party claims against us may cause us to incur substantial settlement charges, which are inherently difficult to estimate and could adversely affect our results of operations. The actual liability in any such matters may be materially different from our estimates, which could result in the need to adjust our liability and record additional expenses. Refer to the “Litigation” subheading in Note 13. Commitments and Contingencies in Part II, Item 8 of this Annual Report on Form 10-K for more information regarding our litigation.

[0001327567-26-000023:mdna:162]
BUSINESS COMBINATIONS

[0001327567-26-000023:mdna:163]
We make significant estimates, assumptions, and judgments when valuing assets acquired and liabilities assumed, especially with respect to purchased intangible assets, in connection with the initial purchase price allocation of an acquired business. Critical estimates in valuing certain purchased intangible assets include, but are not limited to, cash flows that an asset is expected to generate in the future, discount rates, the time and expense that would be necessary to recreate the assets, and the profit margin a market participant would receive on such recreated assets. The amounts and useful lives assigned to identified intangible assets impact the amount and timing of future amortization expense.

[0001327567-26-000023:mdna:164]
One of our business combinations has included post-closing payments contingent upon the occurrence of future events and/or certain conditions being met. Critical estimates used in valuing our contingent consideration obligation include, but are not limited to, estimated future cash payments related to customers entering into qualified new transactions and risk-adjusted discount rates used to present value the expected cash flows. These estimates and assumptions are updated to revalue our contingent consideration liability at the end of each reporting period. Accordingly, subsequent changes in underlying facts and circumstances could result in changes in these estimates and assumptions, which could have a material impact on the estimated future fair values of these obligations.

[0001327567-26-000023:mdna:165]
Recent Accounting Pronouncements

[0001327567-26-000023:mdna:166]
Refer to “Recently Adopted Accounting Pronouncements” and “Recently Issued Accounting Pronouncements” in Note 1. Description of Business and Summary of Significant Accounting Policies in Part II, Item 8 of this Annual Report on Form 10-K for a description of recent accounting pronouncements and our expectation of their impact, if any, on our results of operations and financial condition.

[0001327567-26-000023:mdna:167]
- 56 -
