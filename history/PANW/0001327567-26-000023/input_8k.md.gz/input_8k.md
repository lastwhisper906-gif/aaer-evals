# PANW 8-K — 0001327567-26-000019 filed 2026-09-01

## item codes, every 8-K on or before 2026-09-10

- 2026-09-01 0001327567-26-000019 — 2.02, 9.01
- 2026-08-21 0001193125-26-361122 — 5.02, 5.03, 9.01
- 2026-06-02 0001327567-26-000012 — 2.02, 9.01
- 2026-04-13 0001193125-26-151637 — 1.01, 2.03, 9.01
- 2026-03-23 0001193125-26-119729 — 8.01
- 2026-03-11 0001327567-26-000009 — 8.01, 9.01
- 2026-02-17 0001327567-26-000003 — 2.02, 9.01
- 2026-02-11 0001193125-26-045600 — 1.01, 2.03, 8.01, 9.01
- 2026-01-29 0001193125-26-029489 — 7.01, 9.01
- 2025-12-11 0001193125-25-315915 — 5.02, 5.07, 9.01
- 2025-11-21 0001193125-25-291350 — 8.01
- 2025-11-19 0001327567-25-000032 — 2.02, 7.01, 8.01, 9.01
- 2025-11-19 0001193125-25-288132 — 5.02, 9.01
- 2025-09-25 0001193125-25-217462 — 8.01
- 2025-08-18 0001327567-25-000024 — 2.02, 5.02, 5.03, 9.01
- 2025-07-31 0001193125-25-169870 — 1.01, 9.01
- 2025-07-30 0001193125-25-168821 — 7.01, 8.01, 9.01
- 2025-05-20 0001327567-25-000015 — 2.02, 9.01
- 2025-02-13 0001327567-25-000006 — 2.02, 9.01
- 2025-02-13 0001327567-25-000004 — 5.02, 9.01
- 2024-12-17 0001193125-24-280058 — 5.02, 9.01
- 2024-12-12 0001193125-24-277082 — 5.02, 5.03, 5.07, 9.01
- 2024-11-20 0001327567-24-000036 — 2.02, 8.01, 9.01
- 2024-11-15 0001193125-24-259308 — 8.01
- 2024-09-04 0001327567-24-000026 — 8.01, 9.01
- 2024-08-19 0001327567-24-000023 — 2.02, 8.01, 9.01
- 2024-05-20 0001327567-24-000015 — 2.02, 9.01
- 2024-05-16 0001327567-24-000010 — 8.01, 9.01
- 2024-02-20 0001327567-24-000003 — 2.02, 9.01
- 2023-12-14 0001193125-23-295527 — 5.02, 5.07, 9.01
- 2023-11-29 0001193125-23-285277 — 8.01, 9.01
- 2023-11-17 0001327567-23-000035 — 8.01, 9.01
- 2023-11-15 0001327567-23-000030 — 2.02, 9.01
- 2023-11-15 0001193125-23-277318 — 8.01
- 2023-08-18 0001327567-23-000020 — 2.02, 9.01
- 2023-06-08 0001193125-23-163506 — 7.01, 9.01
- 2023-06-05 0001193125-23-160228 — 7.01
- 2023-05-23 0001327567-23-000012 — 2.02, 9.01
- 2023-04-19 0001327567-23-000009 — 1.01, 2.03, 9.01
- 2023-02-21 0001327567-23-000005 — 2.02, 9.01
- 2022-12-16 0001193125-22-307346 — 5.02, 5.07
- 2022-11-17 0001327567-22-000035 — 2.02, 9.01
- 2022-11-15 0001193125-22-285017 — 8.01
- 2022-08-22 0001327567-22-000020 — 2.02, 8.01, 9.01
- 2022-05-23 0001193125-22-157474 — 5.02, 5.03, 9.01
- 2022-05-19 0001327567-22-000014 — 2.02, 9.01
- 2022-02-23 0001193125-22-049906 — 5.02
- 2022-02-22 0001327567-22-000006 — 2.02, 9.01
- 2021-12-15 0001193125-21-358074 — 5.02, 5.07
- 2021-11-18 0001327567-21-000037 — 2.02, 9.01
- 2021-10-12 0001193125-21-296438 — 3.01, 7.01, 9.01
- 2021-09-13 0001193125-21-270979 — 7.01, 9.01
- 2021-09-08 0001193125-21-267862 — 5.02, 9.01
- 2021-08-23 0001327567-21-000020 — 2.02, 9.01
- 2021-08-12 0001193125-21-244832 — 5.02, 9.01
- 2021-05-20 0001327567-21-000012 — 2.02, 9.01
- 2021-05-18 0001193125-21-164169 — 5.02 — amendment of 0001193125-21-162161
- 2021-05-14 0001193125-21-162161 — 5.02, 9.01
- 2021-03-19 0001193125-21-087516 — 5.02, 9.01
- 2021-02-22 0001628280-21-002659 — 2.02, 9.01
- 2021-02-22 0001193125-21-049293 — 5.02, 9.01
- 2020-12-18 0001193125-20-321568 — 8.01, 9.01
- 2020-12-16 0001193125-20-319091 — 3.02 — amendment of 0001193125-20-291707
- 2020-12-10 0001193125-20-314920 — 5.07
- 2020-12-08 0001193125-20-312056 — 5.02, 8.01, 9.01
- 2020-11-16 0001327567-20-000037 — 2.02, 9.01
- 2020-11-12 0001193125-20-291707 — 3.02
- 2020-10-19 0001193125-20-272060 — 5.02
- 2020-08-24 0001327567-20-000025 — 2.02, 9.01
- 2020-06-23 0001193125-20-176553 — 5.02, 9.01
- 2020-06-22 0001193125-20-175603 — 5.02, 9.01
- 2020-06-08 0001193125-20-163579 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2020-05-21 0001327567-20-000015 — 2.02, 9.01
- 2020-02-27 0001193125-20-050335 — 1.01, 2.03
- 2020-02-24 0001327567-20-000002 — 2.02, 9.01
- 2019-12-19 0001193125-19-319166 — 1.02, 9.01
- 2019-12-10 0001193125-19-310251 — 5.07
- 2019-11-25 0001327567-19-000036 — 2.02, 9.01
- 2019-11-25 0001193125-19-299886 — 5.02, 8.01 — amendment of 0001327567-19-000011
- 2019-10-22 0001193125-19-271660 — 5.02
- 2019-09-06 0001327567-19-000026 — 9.01 — amendment of 0001327567-19-000023
- 2019-09-04 0001327567-19-000023 — 2.02, 7.01, 9.01
- 2019-07-11 0001193125-19-192415 — 5.02, 9.01
- 2019-05-29 0001327567-19-000014 — 2.02, 9.01
- 2019-04-15 0001327567-19-000011 — 5.02, 9.01
- 2019-04-01 0001193125-19-094613 — 8.01, 9.01
- 2019-03-28 0001193125-19-090572 — 3.02 — amendment of 0001327567-19-000003
- 2019-02-26 0001327567-19-000006 — 2.02, 8.01, 9.01
- 2019-02-19 0001327567-19-000003 — 3.02
- 2018-12-11 0001327567-18-000033 — 5.07
- 2018-11-29 0001327567-18-000029 — 2.02, 9.01
- 2018-10-15 0001193125-18-299312 — 5.02, 9.01
- 2018-09-25 0001193125-18-282542 — 5.02
- 2018-09-14 0001193125-18-274239 — 5.03, 9.01
- 2018-09-06 0001327567-18-000018 — 1.01, 2.02, 2.03, 9.01
- 2018-07-13 0001193125-18-217281 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2018-06-04 0001327567-18-000011 — 2.02, 5.02, 9.01
- 2018-02-26 0001327567-18-000004 — 2.02, 5.02, 7.01, 9.01
- 2017-12-12 0001193125-17-367477 — 5.07
- 2017-11-20 0001327567-17-000032 — 2.02, 5.02, 9.01
- 2017-08-31 0001327567-17-000021 — 2.02, 5.02, 9.01
- 2017-05-31 0001327567-17-000016 — 2.02, 9.01
- 2017-02-28 0001327567-17-000005 — 2.02, 8.01, 9.01
- 2016-12-12 0001193125-16-790757 — 5.07
- 2016-11-21 0001327567-16-000071 — 2.02, 9.01
- 2016-10-24 0001193125-16-745121 — 5.02, 9.01
- 2016-08-30 0001327567-16-000057 — 2.02, 5.03, 8.01, 9.01
- 2016-08-22 0001193125-16-687588 — 5.02, 9.01
- 2016-05-26 0001327567-16-000051 — 2.02, 9.01
- 2016-02-25 0001327567-16-000044 — 2.02, 5.02, 9.01
- 2015-12-14 0001327567-15-000038 — 5.07
- 2015-12-14 0001193125-15-402588 — 1.01, 9.01
- 2015-11-23 0001327567-15-000033 — 2.02, 9.01
- 2015-10-19 0001193125-15-347005 — 1.01, 9.01 — amendment, the index does not say of what
- 2015-09-09 0001327567-15-000022 — 2.02, 9.01
- 2015-08-19 0001193125-15-296115 — 1.01, 2.03
- 2015-06-01 0001193125-15-207786 — 1.01, 2.03
- 2015-05-27 0001327567-15-000015 — 2.02, 9.01
- 2015-03-02 0001327567-15-000006 — 2.02, 9.01
- 2014-12-15 0001327567-14-000046 — 5.07
- 2014-11-24 0001327567-14-000040 — 2.02, 9.01
- 2014-09-22 0001193125-14-348581 — 5.02, 9.01
- 2014-09-09 0001327567-14-000025 — 2.02, 9.01
- 2014-07-01 0001193125-14-257824 — 1.01, 2.03, 3.02, 9.01
- 2014-06-26 0001193125-14-249529 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2014-06-20 0001327567-14-000020 — 9.01 — amendment of 0001193125-14-140511
- 2014-06-04 0001327567-14-000016 — 3.02
- 2014-05-30 0001193125-14-218158 — 2.02 — amendment, the index does not say of what
- 2014-05-28 0001193125-14-215060 — 1.01, 2.02, 3.02, 9.01
- 2014-04-11 0001193125-14-140511 — 2.01, 3.02, 7.01, 9.01
- 2014-03-24 0001193125-14-111318 — 1.01, 3.02, 7.01, 9.01
- 2014-03-13 0001327567-14-000009 — 5.02
- 2014-02-24 0001193125-14-063754 — 2.02, 9.01
- 2013-12-12 0001327567-13-000040 — 5.07
- 2013-11-25 0001327567-13-000033 — 2.02, 9.01
- 2013-09-30 0001193125-13-384966 — 8.01
- 2013-09-09 0001193125-13-361421 — 2.02, 9.01
- 2013-05-30 0001193125-13-241542 — 2.02, 5.02, 9.01
- 2013-03-11 0001193125-13-101082 — 5.02, 9.01
- 2013-02-28 0001193125-13-084193 — 2.02, 9.01
- 2012-12-14 0001193125-12-503335 — 5.07
- 2012-12-06 0001193125-12-493700 — 2.02, 9.01
- 2012-09-24 0001193125-12-401534 — 1.01, 2.03
- 2012-09-20 0001193125-12-398433 — 5.02, 9.01
- 2012-09-10 0001193125-12-386605 — 2.02, 9.01

## late-filing notifications on or before 2026-09-10

- none on or before 2026-09-10

## item 2.02 — earnings release, exhibit 99.1

[0001327567-26-000019:8k_2_02:1]
EX-99.1
2
ex991q426earningsrelease.htm
EX-99.1

[0001327567-26-000019:8k_2_02:2]
Document

[0001327567-26-000019:8k_2_02:3]
Exhibit 99.1

[0001327567-26-000019:8k_2_02:4]
Palo Alto Networks Reports Fiscal Fourth Quarter and Fiscal Year 2026 Financial Results

[0001327567-26-000019:8k_2_02:5]
SANTA CLARA, Calif., Sept. 1, 2026 — Palo Alto Networks® (NASDAQ: PANW), the global AI cybersecurity leader, announced today financial results for its fiscal fourth quarter and fiscal year, ended July 31, 2026.

[0001327567-26-000019:8k_2_02:6]
"We delivered a strong Q4 to close out the year, adding nearly $1 billion of Net New NGS ARR in a single quarter," said Nikesh Arora, chairman and chief executive officer of Palo Alto Networks. "The latest advancements in AI are elevating cybersecurity to the top of the CIO priority list, and will serve as durable tailwinds as we progress towards our $20 billion FY30 NGS ARR target."

[0001327567-26-000019:8k_2_02:7]
"We delivered a strong finish to a record year and exceeded our guidance across the board, fueled by strength across our Network & AI Security, Cortex, and Idira platforms," said Dipak Golechha, chief financial officer of Palo Alto Networks. "Our profitable growth framework continues to scale effectively, reinforcing our confidence in achieving 40% adjusted free cash flow margin in FY28."

[0001327567-26-000019:8k_2_02:8]
Fourth Quarter Fiscal 2026 Financial Highlights

[0001327567-26-000019:8k_2_02:9]
•Total revenue for the fiscal fourth quarter 2026 grew 34% year over year to $3.41 billion.

[0001327567-26-000019:8k_2_02:10]
•Next-Generation Security ARR for the fiscal fourth quarter 2026 grew 63% year over year to $9.10 billion.

[0001327567-26-000019:8k_2_02:11]
•Remaining performance obligations grew 34% year over year to $21.2 billion.

[0001327567-26-000019:8k_2_02:12]
•GAAP operating income for the fiscal fourth quarter 2026 was $172 million, compared with GAAP operating income of $497 million for the fiscal fourth quarter 2025. Non-GAAP operating income for the fiscal fourth quarter 2026 was $1.0 billion, compared with non-GAAP operating income of $768 million for the fiscal fourth quarter 2025. A reconciliation between GAAP and non-GAAP information is contained in the tables below.

[0001327567-26-000019:8k_2_02:13]
•GAAP net loss for the fiscal fourth quarter 2026 was $282 million, or ($0.35) per diluted share, compared with GAAP net income of $254 million, or $0.36 per diluted share, for the fiscal fourth quarter 2025. Non-GAAP net income for the fiscal fourth quarter 2026 was $853 million, or $1.02 per diluted share, compared with non-GAAP net income of $673 million, or $0.95 per diluted share, for the fiscal fourth quarter 2025. A reconciliation between GAAP and non-GAAP information is contained in the tables below.

[0001327567-26-000019:8k_2_02:14]
•Net cash provided by operating activities for the fiscal fourth quarter 2026 was $1.4 billion, compared with net cash provided by operating activities of $1.0 billion for the fiscal fourth quarter 2025. Adjusted free cash flow for fiscal fourth quarter 2026 was $1.3 billion, compared with adjusted free cash flow of $954 million for the fiscal fourth quarter 2025. Fiscal year 2026 adjusted free cash flow margin was 38.4%. A reconciliation between GAAP and non-GAAP information is contained in the tables below.

[0001327567-26-000019:8k_2_02:15]
Acquisition of Console

[0001327567-26-000019:8k_2_02:16]
Palo Alto Networks has acquired Console, an AI-native platform that enables agentic workflows across enterprise operations. Console will expand the role of our Cortex platform across the broader enterprise agentic transformation.

[0001327567-26-000019:8k_2_02:17]
Financial Outlook

[0001327567-26-000019:8k_2_02:18]
Palo Alto Networks provides guidance based on current market conditions and expectations.

[0001327567-26-000019:8k_2_02:19]
For the fiscal first quarter 2027, we expect:

[0001327567-26-000019:8k_2_02:20]
•Next-Generation Security ARR of $9.54 billion to $9.56 billion, representing year-over-year growth of 63%.

[0001327567-26-000019:8k_2_02:21]
•Remaining performance obligations of $20.8 billion to $20.9 billion, representing year-over-year growth of 34% to 35%.

[0001327567-26-000019:8k_2_02:22]
•Total revenue in the range of $3.300 billion to $3.310 billion, representing year-over-year growth of 33% to 34%.

[0001327567-26-000019:8k_2_02:23]
•Diluted non-GAAP net income per share in the range of $0.96 to $0.98, using 837 million to 844 million shares outstanding.

[0001327567-26-000019:8k_2_02:24]
For the fiscal year 2027, we expect:

[0001327567-26-000019:8k_2_02:25]
•Next-Generation Security ARR of $11.075 billion to $11.175 billion, representing year-over-year growth of 22% to 23%.

[0001327567-26-000019:8k_2_02:26]
•Remaining performance obligations of $25.2 billion to $25.4 billion, representing year-over-year growth of 19% to 20%.

[0001327567-26-000019:8k_2_02:27]
•Total revenue in the range of $14.10 billion to $14.20 billion, representing year-over-year growth of 23% to 24%.

[0001327567-26-000019:8k_2_02:28]
•Non-GAAP operating margin of 29.5%.

[0001327567-26-000019:8k_2_02:29]
•Diluted non-GAAP net income per share in the range of $4.16 to $4.19, using 844 million to 847 million shares outstanding.

[0001327567-26-000019:8k_2_02:30]
•Adjusted free cash flow margin to be 38.0%.

[0001327567-26-000019:8k_2_02:31]
Guidance for non-GAAP financial measures excludes share-based compensation-related charges, including share-based payroll tax expense, acquisition-related costs, including change in fair value of contingent consideration liability, amortization expense of acquired intangible assets, litigation-related charges, non-cash charges related to convertible notes, change in fair value of convertible senior notes and capped calls, and income tax and other tax adjustments related to our long-term non-GAAP effective tax rate, along with certain non-recurring expenses and certain non-recurring cash flows. We have not reconciled non-GAAP operating margin guidance to GAAP operating margin, diluted non-GAAP net income per share guidance to GAAP net income (loss) per diluted share, or adjusted free cash flow margin guidance to GAAP net cash provided by operating activities because we do not provide guidance on GAAP operating margin, GAAP net income (loss) or net cash provided by operating activities and would not be able to present the various reconciling cash and non-cash items between GAAP and non-GAAP financial measures because certain items that impact these measures are uncertain or out of our control, or cannot be reasonably predicted, including share-based compensation expense, without unreasonable effort. The actual amounts of such reconciling items will have a significant impact on the company’s GAAP net income (loss) per diluted share, GAAP operating margin and GAAP net cash provided by operating activities.

[0001327567-26-000019:8k_2_02:32]
Earnings Call Information

[0001327567-26-000019:8k_2_02:33]
Palo Alto Networks will host a video webcast for analysts and investors to discuss the company’s fiscal fourth quarter and fiscal year 2026 results as well as the outlook for its fiscal first quarter and fiscal year 2027 today at 4:30 p.m. Eastern time/1:30 p.m. Pacific time. Open to the public, investors may access the webcast, supplemental financial information and earnings slides from the "Investors" section of the company’s website at investors.paloaltonetworks.com. A replay will be available three hours after the conclusion of the webcast and archived for one year.

[0001327567-26-000019:8k_2_02:34]
Forward-Looking Statements

[0001327567-26-000019:8k_2_02:35]
This press release contains forward-looking statements that involve risks, uncertainties and assumptions including statements regarding our financial and operating results and financial outlook for the fiscal first quarter 2027 and fiscal year 2027. There are a significant number of factors that could cause actual results to differ materially from forward-looking statements made or implied in this press release, including: unfavorable economic and market conditions and the uncertain geopolitical environment; our ability to effectively manage future growth and improve our systems, processes, and controls; our ability to maintain our revenue growth rate or profitability; variability and seasonality in our operating results; our ability to sell new and additional products, subscriptions, and support offerings to existing and new customers; the delayed recognition of revenue from subscription and support offerings; revenue volatility from consumption- or usage-based offerings and customer usage optimization behavior; potential decreases in the sales prices of our products, subscriptions, and support offerings; our reliance on channel partners; credit and liquidity risk exposure; challenges associated with sales to government entities; intense competition in our markets; risks associated with the evolving definition of the identity security market; customer trends toward vendor consolidation in cybersecurity; competition from cloud infrastructure providers offering native security capabilities; risks related to past and future acquisitions; our ability to predict, prepare for, and respond to rapidly evolving technological and

[0001327567-26-000019:8k_2_02:36]
market developments; the need to maintain a broad ecosystem of third-party technology integrations; risks related to the development, deployment, or use of AI, including AI agents as a new class of identity; the impact of network or data security incidents; defects, errors, or vulnerabilities in our products and subscriptions; reliance on customers to configure and use our products securely; the quality of our technical support services; our ability to meet service-level commitments; our reliance on data center facilities operated by third-party cloud service providers; intellectual property claims and our ability to protect proprietary rights; risks associated with open source software; our reliance on third-party technology licenses; dependence on manufacturing partners and limited sources of supply; our ability to attract, retain, and motivate key personnel; risks associated with international sales and operations, including export and import controls; fluctuations in foreign currency exchange rates; risks associated with operations and employees located in Israel; costs and risks related to compliance with privacy and data protection laws; potential tax liabilities; risks related to estimates, judgments, and critical accounting policies; our ability to maintain proper and effective internal control over financial reporting; risks related to corporate responsibility matters; dilution from issuance of additional common stock; risks related to our convertible senior notes, including our ability to settle conversions, repurchase, or repay such notes and the potential effect of capped call transactions.

[0001327567-26-000019:8k_2_02:37]
Additional risks and uncertainties on these and other factors that could affect our financial results and cause actual results to differ materially from those described in the forward-looking statements we make in this press release are included under the captions "Risk Factors" and "Management's Discussion and Analysis of Financial Condition and Results of Operations" in our annual reports on Form 10-K and quarterly reports on Form 10-Q, which are available on our website at investors.paloaltonetworks.com and on the SEC's website at www.sec.gov. Additional information and risks and uncertainties will also be set forth in other documents that we file with or furnish to the SEC from time to time. All forward-looking statements in this press release are based on our current beliefs and information available to management as of the date hereof and are inherently uncertain, and we do not assume any obligation to update the forward-looking statements provided to reflect events that occur or circumstances that exist after the date on which they were made, except as required by law.

[0001327567-26-000019:8k_2_02:38]
Non-GAAP Financial Measures and Other Key Metrics

[0001327567-26-000019:8k_2_02:39]
Palo Alto Networks has provided in this press release financial information that has not been prepared in accordance with generally accepted accounting principles in the United States (GAAP). The company uses these non-GAAP financial measures and other key metrics internally in analyzing its financial results and believes that the use of these non-GAAP financial measures and key metrics are helpful to investors as an additional tool to evaluate ongoing operating results and trends, and in comparing the company’s financial results with other companies in its industry, many of which present similar non-GAAP financial measures or key metrics.

[0001327567-26-000019:8k_2_02:40]
The presentation of these non-GAAP financial measures and key metrics are not meant to be considered in isolation or as a substitute for comparable GAAP financial measures and should be read only in conjunction with the company’s consolidated financial statements prepared in accordance with GAAP. A reconciliation of the company’s historical non-GAAP financial measures to their most directly comparable GAAP measures has been provided in the financial statement tables included in this press release, and investors are encouraged to review these reconciliations.

[0001327567-26-000019:8k_2_02:41]
Non-GAAP operating income. Palo Alto Networks defines non-GAAP operating income as operating income plus share-based compensation-related charges, including share-based payroll tax expense, acquisition-related costs, including change in fair value of contingent consideration liability, amortization expense of acquired intangible assets, and litigation-related charges. The company believes that non-GAAP operating income provides management and investors with greater visibility into the underlying performance of the company’s core business operating results.

[0001327567-26-000019:8k_2_02:42]
Non-GAAP net income and net income per share, diluted. Palo Alto Networks defines non-GAAP net income as net income (loss) plus share-based compensation-related charges, including share-based payroll tax expense, acquisition-related costs, including change in fair value of contingent consideration liability, amortization expense of acquired intangible assets, litigation-related charges, non-cash charges related to convertible notes, and change in fair value of convertible senior notes and capped calls. The company also excludes from non-GAAP income tax and other tax adjustments related to our long-term non-GAAP effective tax rate in order to provide a complete picture of the company’s recurring core business operating results. The company defines non-GAAP net income per share, diluted, as non-GAAP net income divided by the weighted-average diluted shares outstanding, which includes the potentially dilutive effect of the company’s employee equity incentive plan awards and the company’s convertible senior notes and related warrants, after giving effect to the anti-dilutive impact of the company’s note hedge agreements and capped call transactions, which reduced the potential economic dilution that otherwise would have occurred in connection with the conversion and settlement of the company’s convertible senior notes. Under GAAP, the anti-dilutive impact of the note hedge or capped calls is not reflected in diluted shares outstanding. The company considers these non-GAAP financial measures to be useful metrics for management and investors for the same reasons that it uses non-GAAP operating income.

[0001327567-26-000019:8k_2_02:43]
Adjusted free cash flow margin, adjusted free cash flow, and free cash flow. Palo Alto Networks defines adjusted free cash flow margin, a non-GAAP measure, as adjusted free cash flow divided by total revenue. The company defines adjusted free cash flow, a non-GAAP measure, as free cash flow, plus certain capital expenditures for our headquarters and certain corporate assets, plus payments of acquisition-related costs, plus litigation-related payments. The company defines free cash flow, a non-GAAP measure, as net cash provided by operating activities less purchases of property, equipment, and other assets. We consider free cash flow, adjusted free cash flow, and adjusted free cash flow margin to be operating metrics as well as liquidity measures that provide useful information to management and investors about the amount of cash generated by the business after necessary capital expenditures and before the impact of certain qualifying non-recurring cash payments from operating activities, as applicable. A limitation of the utility of free cash flow or adjusted free cash flow as a measure of our liquidity is that it does not represent the total increase or decrease in our cash balance for the period. In addition, it is important to note that other companies, including companies in our industry, may not use free cash flow or adjusted free cash flow, may calculate free cash flow or adjusted free cash flow in a different manner than we do, or may use other financial measures to evaluate their liquidity, all of which could reduce the usefulness of free cash flow or adjusted free cash flow as a comparative measure.

[0001327567-26-000019:8k_2_02:44]
Next-Generation Security ARR. Palo Alto Networks defines Next-Generation Security ARR as the annualized allocated revenue of all active contracts as of the final day of the reporting period related to all product, subscription and support offerings, excluding revenue from hardware products, and legacy attached subscriptions, support offerings and professional services. The company considers Next-Generation Security ARR to be a useful operating metric for management and investors to assess the performance of the company because Next-Generation Security is where the company has focused its innovation and the company expects its overall revenue to be disproportionately driven by this Next-Generation Security portfolio. Because Next-Generation Security ARR does not have the effect of providing a numerical measure that is different from any comparable GAAP measure, the company does not consider it a non-GAAP measure.

[0001327567-26-000019:8k_2_02:45]
Investors are cautioned that there are a number of limitations associated with the use of non-GAAP financial measures and key metrics as analytical tools. Many of the adjustments to the company’s GAAP financial measures reflect the exclusion of items that are recurring and will be reflected in the company’s financial results for the foreseeable future, such as share-based compensation, which is an important part of Palo Alto Networks employees’ compensation and impacts their performance. Furthermore, these non-GAAP financial measures are not based on any standardized methodology prescribed by GAAP, and the components that Palo Alto Networks excludes in its calculation of non-GAAP financial measures may differ from the components that its peer companies exclude when they report their non-GAAP results of operations. As a result, these non-GAAP financial measures may not be directly comparable to similar non-GAAP financial measures used by other companies. Palo Alto Networks compensates for these limitations by providing specific information regarding the GAAP amounts excluded from these non-GAAP financial measures. In the future, the company may also exclude non-recurring expenses and other expenses that do not reflect the company’s core business operating results.

[0001327567-26-000019:8k_2_02:46]
About Palo Alto Networks

[0001327567-26-000019:8k_2_02:47]
Palo Alto Networks® (NASDAQ: PANW), the global AI cybersecurity leader, protects our digital way of life with a comprehensive portfolio of cybersecurity solutions and platforms across Network, Cloud, Security Operations, AI and Identity. Trusted by 70,000+ customers and powered by Unit 42® threat intelligence, our AI-driven platforms eliminate complexity, empowering enterprises to modernize with confidence and securing the speed of innovation. Explore the future of security at www.paloaltonetworks.com.

[0001327567-26-000019:8k_2_02:48]
Palo Alto Networks and the Palo Alto Networks logo are trademarks of Palo Alto Networks, Inc. in the United States or in certain jurisdictions throughout the world. All other trademarks, trade names, or service marks used or mentioned herein belong to their respective owners. Any unreleased services or features (and any services or features not generally available to customers) referenced in this or other press releases or public statements are not currently available (or are not yet generally available to customers) and may not be delivered when expected or at all. Customers who purchase Palo Alto Networks applications should make their purchase decisions based on services and features currently generally available.

[0001327567-26-000019:8k_2_02:49]
Media Contact:

[0001327567-26-000019:8k_2_02:50]
Allie Cefalo Morales

[0001327567-26-000019:8k_2_02:51]
VP, Global Communications, Palo Alto Networks

[0001327567-26-000019:8k_2_02:52]
press@paloaltonetworks.com

[0001327567-26-000019:8k_2_02:53]
Investor Relations Contact:

[0001327567-26-000019:8k_2_02:54]
Ryan Fenwick

[0001327567-26-000019:8k_2_02:55]
Director, Investor Relations & Strategic Finance, Palo Alto Networks

[0001327567-26-000019:8k_2_02:56]
ir@paloaltonetworks.com

[0001327567-26-000019:8k_2_02:57]
1

[0001327567-26-000019:8k_2_02:58]
| Palo Alto Networks, Inc. |
| Preliminary Condensed Consolidated Statements of Operations |
| (In millions, except per share data) |
| (Unaudited) |
|  | Three Months Ended |  | Year Ended |
|  | July 31, |  | July 31, |
|  | 2026 |  | 2025 |  | 2026 |  | 2025 |
| Revenue: |  |  |  |  |  |  |  |
| Product | $ | 738 |  |  | $ | 574 |  |  | $ | 2,280 |  |  | $ | 1,802 |  |
| Subscription and support | 2,672 |  |  | 1,962 |  |  | 9,200 |  |  | 7,419 |  |
| Total revenue | 3,410 |  |  | 2,536 |  |  | 11,480 |  |  | 9,221 |  |
| Cost of revenue: |  |  |  |  |  |  |  |
| Product | 197 |  |  | 136 |  |  | 568 |  |  | 413 |  |
| Subscription and support | 909 |  |  | 543 |  |  | 2,835 |  |  | 2,038 |  |
| Total cost of revenue | 1,106 |  |  | 679 |  |  | 3,403 |  |  | 2,451 |  |
| Total gross profit | 2,304 |  |  | 1,857 |  |  | 8,077 |  |  | 6,770 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 779 |  |  | 504 |  |  | 2,552 |  |  | 1,984 |  |
| Sales and marketing | 1,127 |  |  | 829 |  |  | 3,931 |  |  | 3,100 |  |
| General and administrative | 226 |  |  | 27 |  |  | 899 |  |  | 443 |  |
| Total operating expenses | 2,132 |  |  | 1,360 |  |  | 7,382 |  |  | 5,527 |  |
| Operating income | 172 |  |  | 497 |  |  | 695 |  |  | 1,243 |  |
| Other income (expense), net | (441) |  |  | 95 |  |  | (159) |  |  | 353 |  |
| Income (loss) before income taxes | (269) |  |  | 592 |  |  | 536 |  |  | 1,596 |  |
| Provision for income taxes | 13 |  |  | 338 |  |  | 229 |  |  | 462 |  |
| Net income (loss) | $ | (282) |  |  | $ | 254 |  |  | $ | 307 |  |  | $ | 1,134 |  |
| Net income (loss) per share, basic | $ | (0.35) |  |  | $ | 0.38 |  |  | $ | 0.41 |  |  | $ | 1.71 |  |
| Net income (loss) per share, diluted | $ | (0.35) |  |  | $ | 0.36 |  |  | $ | 0.40 |  |  | $ | 1.60 |  |
| Weighted-average shares used to compute net income (loss) per share, basic | 817 |  |  | 669 |  |  | 749 |  |  | 663 |  |
| Weighted-average shares used to compute net income (loss) per share, diluted | 817 |  |  | 709 |  |  | 764 |  |  | 709 |  |

[0001327567-26-000019:8k_2_02:59]
2

[0001327567-26-000019:8k_2_02:60]
| Palo Alto Networks, Inc. |
| Reconciliation of GAAP to Non-GAAP Financial Measures |
| (In millions, except per share amounts) |
| (Unaudited) |
|  | Three Months Ended |  | Year Ended |
|  | July 31, |  | July 31, |
|  | 2026 |  | 2025 |  | 2026 |  | 2025 |
| GAAP operating income | $ | 172 |  |  | $ | 497 |  |  | $ | 695 |  |  | $ | 1,243 |  |
| Share-based compensation-related charges | 487 |  |  | 372 |  |  | 1,712 |  |  | 1,386 |  |
| Acquisition-related costs(1) | 68 |  |  | (142) |  |  | 295 |  |  | (110) |  |
| Amortization expense of acquired intangible assets | 281 |  |  | 37 |  |  | 638 |  |  | 164 |  |
| Litigation-related charges(2) | 3 |  |  | 4 |  |  | 16 |  |  | (31) |  |
| Non-GAAP operating income | $ | 1,011 |  |  | $ | 768 |  |  | $ | 3,356 |  |  | $ | 2,652 |  |
| GAAP net income (loss) | $ | (282) |  |  | $ | 254 |  |  | $ | 307 |  |  | $ | 1,134 |  |
| Share-based compensation-related charges | 487 |  |  | 372 |  |  | 1,712 |  |  | 1,386 |  |
| Acquisition-related costs(1) | 68 |  |  | (142) |  |  | 295 |  |  | (110) |  |
| Amortization expense of acquired intangible assets | 281 |  |  | 37 |  |  | 638 |  |  | 164 |  |
| Litigation-related charges(2) | 3 |  |  | 4 |  |  | 16 |  |  | (31) |  |
| Change in fair value of convertible senior notes and capped calls(3) | 524 |  |  | — |  |  | 562 |  |  | 1 |  |
| Income tax and other tax adjustments(4) | (228) |  |  | 148 |  |  | (599) |  |  | (199) |  |
| Non-GAAP net income | $ | 853 |  |  | $ | 673 |  |  | $ | 2,931 |  |  | $ | 2,345 |  |
| GAAP net income (loss) per share, diluted | $ | (0.35) |  |  | $ | 0.36 |  |  | $ | 0.40 |  |  | $ | 1.60 |  |
| Share-based compensation-related charges | 0.59 |  |  | 0.53 |  |  | 2.23 |  |  | 1.98 |  |
| Acquisition-related costs(1) | 0.08 |  |  | (0.20) |  |  | 0.39 |  |  | (0.15) |  |
| Amortization expense of acquired intangible assets | 0.34 |  |  | 0.05 |  |  | 0.84 |  |  | 0.23 |  |
| Litigation-related charges(2) | 0.00 |  |  | 0.00 |  |  | 0.02 |  |  | (0.04) |  |
| Change in fair value of convertible senior notes and capped calls(3) | 0.64 |  |  | 0.00 |  |  | 0.74 |  |  | 0.00 |  |
| Income tax and other tax adjustments(4) | (0.28) |  |  | 0.21 |  |  | (0.78) |  |  | (0.28) |  |
| Non-GAAP net income per share, diluted | $ | 1.02 |  |  | $ | 0.95 |  |  | $ | 3.84 |  |  | $ | 3.34 |  |
| GAAP weighted-average shares used to compute net income (loss) per share, diluted | 817 |  |  | 709 |  |  | 764 |  |  | 709 |  |
| Weighted-average dilutive effect of potentially dilutive securities(5) | 16 |  |  | — |  |  | — |  |  | — |  |
| Weighted-average anti-dilutive impact of note hedge agreements and capped call transactions | (1) |  |  | (2) |  |  | — |  |  | (7) |  |
| Non-GAAP weighted-average shares used to compute net income per share, diluted | 832 |  |  | 707 |  |  | 764 |  |  | 702 |  |

[0001327567-26-000019:8k_2_02:61]
(1)    Consists of acquisition transaction costs, share-based compensation related to the cash settlement of certain equity awards, change in fair value of contingent consideration liability, and costs to terminate certain employment, operating lease, and other contracts of the acquired companies. During the three months and fiscal year ended July 31, 2026, it also includes integration costs related to our acquisition of CyberArk Software Ltd.

[0001327567-26-000019:8k_2_02:62]
(2)    Consists of the amortization of intellectual property licenses and covenant not to sue, and legal contingency charges (credit). During the fiscal year ended July 31, 2026, it also includes a litigation settlement charge.

[0001327567-26-000019:8k_2_02:63]
(3)    Consists of changes in fair value of convertible senior notes acquired from CyberArk Software Ltd. that are included in earnings and changes in fair value of the related capped calls. During the fiscal year ended July 31, 2025, it also includes non-cash interest expense for amortization of debt issuance costs related to our convertible senior notes.

[0001327567-26-000019:8k_2_02:64]
(4)    Consists of income tax adjustments related to our long-term non-GAAP effective tax rate. During the three months and fiscal year ended July 31, 2025, it included a one-time deferred tax provision adjustment relating to the enactment of One Big Beautiful Bill.

[0001327567-26-000019:8k_2_02:65]
(5)    Consists of potentially dilutive effect of employee equity incentive plan awards in periods with GAAP net loss position as they are excluded from GAAP weighted-average shares.

[0001327567-26-000019:8k_2_02:66]
3

[0001327567-26-000019:8k_2_02:67]
| Palo Alto Networks, Inc. |
| Reconciliation of GAAP to Non-GAAP Financial Measures (Continued) |
| (In millions) |
| (Unaudited) |
|  | Three Months Ended |  | Year Ended |
|  | July 31, |  | July 31, |
|  | 2026 |  | 2025 |  | 2026 |  | 2025 |
| Net cash provided by operating activities | $ | 1,357 |  |  | $ | 1,021 |  |  | $ | 4,553 |  |  | $ | 3,716 |  |
| Less: purchases of property, equipment, and other assets | 103 |  |  | 87 |  |  | 440 |  |  | 247 |  |
| Free cash flow (non-GAAP) | $ | 1,254 |  |  | $ | 934 |  |  | $ | 4,113 |  |  | $ | 3,469 |  |
| Add: capital expenditures for headquarters(1) | — |  |  | — |  |  | 91 |  |  | — |  |
| Add: capital expenditures for certain corporate assets(2) | 7 |  |  | 20 |  |  | 42 |  |  | 38 |  |
| Add: payments of acquisition-related costs(3) | 28 |  |  | — |  |  | 164 |  |  | — |  |
| Add: litigation-related payment(4) | — |  |  | — |  |  | 4 |  |  | — |  |
| Adjusted free cash flow (non-GAAP) | $ | 1,289 |  |  | $ | 954 |  |  | $ | 4,414 |  |  | $ | 3,507 |  |
| Adjusted free cash flow margin (non-GAAP) | 37.8 | % |  | 37.6 | % |  | 38.4 | % |  | 38.0 | % |

[0001327567-26-000019:8k_2_02:68]
(1)    Consists of a land purchase of $91 million.

[0001327567-26-000019:8k_2_02:69]
(2)    Consists of a one-time purchase of a corporate asset which was paid through July 2026.

[0001327567-26-000019:8k_2_02:70]
(3)    Consists of payments of acquisition-related costs in connection with our acquisitions of CyberArk Software Ltd. and Koi Security Ltd.

[0001327567-26-000019:8k_2_02:71]
(4)    Consists of a non-recurring litigation settlement payment during the three months ended January 31, 2026.

[0001327567-26-000019:8k_2_02:72]
4

[0001327567-26-000019:8k_2_02:73]
| Palo Alto Networks, Inc. |
| Preliminary Condensed Consolidated Balance Sheets |
| (In millions) |
|  | July 31, 2026 |  | July 31, 2025 |
|  | (unaudited) |  |  |
| Assets |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 2,514 |  |  | $ | 2,269 |  |
| Short-term investments | 557 |  |  | 635 |  |
| Accounts receivable, net | 3,629 |  |  | 2,965 |  |
| Short-term financing receivables, net | 592 |  |  | 715 |  |
| Short-term deferred contract costs | 544 |  |  | 419 |  |
| Prepaid expenses and other current assets | 807 |  |  | 520 |  |
| Total current assets | 8,643 |  |  | 7,523 |  |
| Property and equipment, net | 523 |  |  | 387 |  |
| Operating lease right-of-use assets | 700 |  |  | 347 |  |
| Long-term investments | 4,835 |  |  | 5,555 |  |
| Long-term financing receivables, net | 944 |  |  | 1,002 |  |
| Long-term deferred contract costs | 667 |  |  | 586 |  |
| Goodwill | 22,010 |  |  | 4,567 |  |
| Intangible assets, net | 7,017 |  |  | 763 |  |
| Deferred tax assets | 2,443 |  |  | 2,424 |  |
| Other assets | 678 |  |  | 422 |  |
| Total assets | $ | 48,460 |  |  | $ | 23,576 |  |
| Liabilities and stockholders’ equity |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 290 |  |  | $ | 232 |  |
| Accrued compensation | 1,048 |  |  | 608 |  |
| Accrued and other liabilities | 838 |  |  | 846 |  |
| Deferred revenue | 7,747 |  |  | 6,302 |  |
| Total current liabilities | 9,923 |  |  | 7,988 |  |
| Long-term convertible senior notes | 1,774 |  |  | — |  |
| Long-term deferred revenue | 7,009 |  |  | 6,450 |  |
| Deferred tax liabilities | 251 |  |  | 89 |  |
| Long-term operating lease liabilities | 726 |  |  | 338 |  |
| Other long-term liabilities | 1,285 |  |  | 887 |  |
| Total liabilities | 20,968 |  |  | 15,752 |  |
| Stockholders’ equity: |  |  |  |
| Preferred stock | — |  |  | — |  |
| Common stock and additional paid-in capital | 24,772 |  |  | 5,292 |  |
| Accumulated other comprehensive income (loss) | (71) |  |  | 48 |  |
| Retained earnings | 2,791 |  |  | 2,484 |  |
| Total stockholders’ equity | 27,492 |  |  | 7,824 |  |
| Total liabilities and stockholders’ equity | $ | 48,460 |  |  | $ | 23,576 |  |

[0001327567-26-000019:8k_2_02:74]
5
