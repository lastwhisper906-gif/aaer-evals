# PANW notes — 0001327567-21-000040


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0001327567-21-000040:notes:1]
[same as prior period, unchanged from 0001327567-21-000014:notes:1]

[0001327567-21-000040:notes:2]
Palo Alto Networks, Inc. (the “Company,” “we,” “us,” or “our”), headquartered in Santa Clara, California, was incorporated in March 2005 under the laws of the State of Delaware and commenced operations in April 2005. We empower enterprises, service providers, and government entities to secure all users, applications, data, networks, clouds and devices with comprehensive visibility and context continuously across all locations.

[0001327567-21-000040:notes:3]
[same as prior period, unchanged from 0001327567-21-000014:notes:3]

[0001327567-21-000040:notes:4]
The accompanying condensed consolidated financial statements have been prepared in conformity with U.S. generally accepted accounting principles (“GAAP”), consistent in all material respects with those applied in our Annual Report on Form 10-K for the fiscal year ended July 31, 2021, filed with the Securities and Exchange Commission (“SEC”) on September 3, 2021. Our condensed consolidated financial statements include our accounts and our wholly owned subsidiaries. All significant intercompany balances and transactions have been eliminated in consolidation.

[0001327567-21-000040:notes:5]
Our condensed consolidated financial statements are unaudited but include all adjustments of a normal recurring nature necessary for a fair presentation of our quarterly results. Certain prior period amounts have been reclassified to conform to our current period presentation. Our condensed consolidated financial statements should be read in conjunction with the audited consolidated financial statements and related notes in our Annual Report on Form 10-K for the fiscal year ended July 31, 2021.

[0001327567-21-000040:notes:6]
[same as prior period, unchanged from 0001327567-21-000014:notes:6]

[0001327567-21-000040:notes:7]
The preparation of condensed consolidated financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the condensed consolidated financial statements and the reported amounts of revenues and expenses during the reporting period. We base our estimates on historical experience and also on assumptions that we believe are reasonable. Actual results could differ materially from those estimates due to risks and uncertainties, including uncertainty in the economic environment due to the global impact of the coronavirus disease discovered in 2019 (“COVID-19”).

[0001327567-21-000040:notes:8]
[same as prior period, unchanged from 0001327567-21-000014:notes:8]

[0001327567-21-000040:notes:9]
There have been no material changes to our significant accounting policies as of and for the three months ended October 31, 2021, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended July 31, 2021, except for the change in our accounting policies due to our adoption of recently issued guidance. Refer to “Recently Adopted Accounting Pronouncements” below.

[0001327567-21-000040:notes:10]
Recently Adopted Accounting Pronouncements

[0001327567-21-000040:notes:11]
Acquired Contract Assets and Contract Liabilities

[0001327567-21-000040:notes:12]
In October 2021, the Financial Accounting Standards Board (“FASB”) issued authoritative guidance that requires companies to apply revenue guidance to recognize and measure contract assets and contract liabilities from contracts with customers acquired in a business combination on the acquisition date, instead of measuring them at fair value. We early adopted this guidance in our first quarter of fiscal 2022 on a prospective basis. The adoption of this standard did not have a material impact on our condensed consolidated financial statements.

[0001327567-21-000040:notes:13]
[same as prior period, unchanged from 0001327567-21-000014:notes:23]

[0001327567-21-000040:notes:14]
In August 2020, the FASB issued authoritative guidance that simplifies the accounting for certain financial instruments with characteristics of liabilities and equity, including convertible instrument. The standard reduces the number of models used to account for convertible instruments and simplifies the classification of debt on the balance sheet.

[0001327567-21-000040:notes:15]
We adopted this standard in our first quarter of fiscal 2022 using the modified-retrospective approach, under which, financial results reported in periods prior to fiscal 2022 were not adjusted. The adoption of this standard resulted in an increase to convertible senior notes, net of $444.3 million, a decrease to accumulated deficit of $266.7 million, and a decrease to additional paid-in capital and temporary equity of $711.0 million upon adoption.

[0001327567-21-000040:notes:16]
Below is the update to our Summary of Significant Accounting Policies in our Annual Report on Form 10-K for the fiscal year ended July 31, 2021 as a result of the adoption of the above guidance.

[0001327567-21-000040:notes:17]
Business Combinations

[0001327567-21-000040:notes:18]
We include the results of operations of the businesses that we acquire as of the respective dates of acquisition. We generally allocate the fair value of the purchase price of our acquisitions to the assets acquired and liabilities assumed based on their estimated

[0001327567-21-000040:notes:19]
fair values. The excess of the purchase price over the values of these identifiable assets and liabilities is recorded as goodwill. Additional information existing as of the acquisition date but unknown to us may become known during the remainder of the measurement period, not to exceed 12 months from the acquisition date, which may result in changes to the amounts and allocations recorded.

[0001327567-21-000040:notes:20]
Convertible Senior Notes

[0001327567-21-000040:notes:21]
Prior to August 1, 2021, our convertible senior notes were separated into a liability and an equity component. The carrying amount of the liability component was calculated by measuring the fair value of a similar liability that did not have an associated convertible feature, using a discounted cash flow model with a risk adjusted yield. The carrying amount of the equity component representing the conversion option was determined by deducting the fair value of the liability component from the par value of the notes as a whole. This difference represented a debt discount that was amortized to interest expense using the effective interest method over the term of the notes. The equity component was not remeasured as it continued to meet the conditions for equity classification. Transaction costs related to the issuance of the notes were allocated to the liability and equity components using the same proportions as the proceeds from the notes. Transaction costs attributable to the liability component were netted with the liability component and amortized to interest expense using the effective interest method over the term of the notes. Transaction costs attributable to the equity component were netted with the equity component of the notes in additional paid-in capital. Upon the notes becoming convertible, the net carrying amount of the liability component was classified as a current liability and a portion of the equity component representing the conversion option was reclassified to temporary equity. The portion of the equity component classified as temporary equity was measured as the difference between the principal and net carrying amount of the notes, excluding debt issuance costs.
Upon adoption of the new debt guidance on August 1, 2021, our convertible senior notes are accounted for entirely as a liability and measured at their amortized cost. Transaction costs related to the issuance of the notes are netted with the liability and are amortized on a straight-line basis, which approximates the effective interest rate method, to interest expense over the term of the notes. Refer to Note 9. Debt for additional information.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001327567-21-000040:notes:22]
[same as prior period, unchanged from 0001327567-21-000014:notes:25]

[0001327567-21-000040:notes:23]
[same as prior period, unchanged from 0001327567-21-000014:notes:26]

[0001327567-21-000040:notes:24]
|  | Three Months Ended October 31, |  |  |
|  | 2021 |  | 2020 |  |  |  |  |
| Revenue: |  |  |  |  |  |  |  |
| Americas |  |  |  |  |  |  |  |
| United States | $ | 811.7 |  |  | $ | 624.4 |  |  |  |  |  |
| Other Americas | 55.0 |  |  | 42.1 |  |  |  |  |  |
| Total Americas | 866.7 |  |  | 666.5 |  |  |  |  |  |
| Europe, the Middle East, and Africa (“EMEA”) | 233.8 |  |  | 173.4 |  |  |  |  |  |
| Asia Pacific and Japan (“APAC”) | 146.9 |  |  | 106.1 |  |  |  |  |  |
| Total revenue | $ | 1,247.4 |  |  | $ | 946.0 |  |  |  |  |  |

[0001327567-21-000040:notes:25]
[same as prior period, unchanged from 0001327567-21-000014:notes:28]

[0001327567-21-000040:notes:26]
|  | Three Months Ended October 31, |  |  |
|  | 2021 |  | 2020 |  |  |  |  |
| Revenue: |  |  |  |  |  |  |  |
| Product | $ | 295.5 |  |  | $ | 237.3 |  |  |  |  |  |
| Subscription and support |  |  |  |  |  |  |  |
| Subscription | 578.8 |  |  | 428.0 |  |  |  |  |  |
| Support | 373.1 |  |  | 280.7 |  |  |  |  |  |
| Total subscription and support | 951.9 |  |  | 708.7 |  |  |  |  |  |
| Total revenue | $ | 1,247.4 |  |  | $ | 946.0 |  |  |  |  |  |

[0001327567-21-000040:notes:27]
[same as prior period, unchanged from 0001327567-21-000014:notes:30]

[0001327567-21-000040:notes:28]
During the three months ended October 31, 2021 and 2020, we recognized approximately $840.0 million and $630.0 million of revenue pertaining to amounts that were deferred as of July 31, 2021 and 2020, respectively.

[0001327567-21-000040:notes:29]
[same as prior period, unchanged from 0001327567-21-000014:notes:32]

[0001327567-21-000040:notes:30]
Revenue expected to be recognized from remaining performance obligations was $6.0 billion as of October 31, 2021, of which we expect to recognize approximately $3.2 billion over the next 12 months and the remainder thereafter.


## us-gaap:FairValueDisclosuresTextBlock

[0001327567-21-000040:notes:31]
Fair Value Measurements 
We categorize assets and liabilities recorded or disclosed at fair value on our condensed consolidated balance sheets based upon the level of judgment associated with inputs used to measure their fair value. The categories are as follows:

[0001327567-21-000040:notes:32]
•Level 1—Inputs are unadjusted quoted prices in active markets for identical assets or liabilities.

[0001327567-21-000040:notes:33]
•Level 2—Inputs are quoted prices for similar assets and liabilities in active markets or inputs that are observable for the assets or liabilities, either directly or indirectly through market corroboration, for substantially the full term of the financial instruments.

[0001327567-21-000040:notes:34]
•Level 3—Inputs are unobservable inputs based on our own assumptions used to measure assets and liabilities at fair value. The inputs require significant management judgment or estimation.

[0001327567-21-000040:notes:35]
The following table presents the fair value of our financial assets and liabilities measured at fair value on a recurring basis as of October 31, 2021 and July 31, 2021 (in millions):

[0001327567-21-000040:notes:36]
|  |  | October 31, 2021 |  | July 31, 2021 |
|  |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Cash equivalents: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 161.8 |  |  | $ | — |  |  | $ | — |  |  | $ | 161.8 |  |  | $ | 124.2 |  |  | $ | — |  |  | $ | — |  |  | $ | 124.2 |  |
| Certificates of deposit |  | — |  |  | 150.5 |  |  | — |  |  | 150.5 |  |  | — |  |  | 150.4 |  |  | — |  |  | 150.4 |  |
| Corporate debt securities |  | — |  |  | 26.1 |  |  | — |  |  | 26.1 |  |  | — |  |  | 1.0 |  |  | — |  |  | 1.0 |  |
| U.S. government and agency securities |  | — |  |  | 70.0 |  |  | — |  |  | 70.0 |  |  | — |  |  | 116.3 |  |  | — |  |  | 116.3 |  |
| Total cash equivalents |  | 161.8 |  |  | 246.6 |  |  | — |  |  | 408.4 |  |  | 124.2 |  |  | 267.7 |  |  | — |  |  | 391.9 |  |
| Short-term investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Certificates of deposit |  | — |  |  | 151.5 |  |  | — |  |  | 151.5 |  |  | — |  |  | 12.4 |  |  | — |  |  | 12.4 |  |
| Corporate debt securities |  | — |  |  | 200.0 |  |  | — |  |  | 200.0 |  |  | — |  |  | 208.9 |  |  | — |  |  | 208.9 |  |
| U.S. government and agency securities |  | — |  |  | 804.7 |  |  | — |  |  | 804.7 |  |  | — |  |  | 762.1 |  |  | — |  |  | 762.1 |  |
| Non-U.S. government and agency securities |  |  |  | 32.3 |  |  |  |  | 32.3 |  |  |  |  | 43.5 |  |  |  |  | 43.5 |  |
| Total short-term investments |  | — |  |  | 1,188.5 |  |  | — |  |  | 1,188.5 |  |  | — |  |  | 1,026.9 |  |  | — |  |  | 1,026.9 |  |
| Long-term investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Certificates of deposit |  | — |  |  | 5.0 |  |  | — |  |  | 5.0 |  |  | — |  |  | 5.0 |  |  | — |  |  | 5.0 |  |
| Corporate debt securities |  | — |  |  | 227.8 |  |  | — |  |  | 227.8 |  |  | — |  |  | 180.7 |  |  | — |  |  | 180.7 |  |
| U.S. government and agency securities |  | — |  |  | 637.6 |  |  | — |  |  | 637.6 |  |  | — |  |  | 674.1 |  |  | — |  |  | 674.1 |  |
| Non-U.S. government and agency securities |  | — |  |  | 28.4 |  |  | — |  |  | 28.4 |  |  | — |  |  | 28.5 |  |  | — |  |  | 28.5 |  |
| Total long-term investments |  | — |  |  | 898.8 |  |  | — |  |  | 898.8 |  |  | — |  |  | 888.3 |  |  | — |  |  | 888.3 |  |
| Prepaid expenses and other current assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency forward contracts |  | — |  |  | 4.7 |  |  | — |  |  | 4.7 |  |  | — |  |  | 4.1 |  |  | — |  |  | 4.1 |  |
| Total prepaid expenses and other current assets |  | — |  |  | 4.7 |  |  | — |  |  | 4.7 |  |  | — |  |  | 4.1 |  |  | — |  |  | 4.1 |  |
| Other assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency forward contracts |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 0.1 |  |  | — |  |  | 0.1 |  |
| Total other assets: |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 0.1 |  |  | — |  |  | 0.1 |  |
| Total assets measured at fair value |  | $ | 161.8 |  |  | $ | 2,338.6 |  |  | $ | — |  |  | $ | 2,500.4 |  |  | $ | 124.2 |  |  | $ | 2,187.1 |  |  | $ | — |  |  | $ | 2,311.3 |  |
| Accrued and other liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency forward contracts |  | $ | — |  |  | $ | 8.8 |  |  | $ | — |  |  | $ | 8.8 |  |  | $ | — |  |  | $ | 6.4 |  |  | $ | — |  |  | $ | 6.4 |  |
| Total accrued and other liabilities |  | — |  |  | 8.8 |  |  | — |  |  | 8.8 |  |  | — |  |  | 6.4 |  |  | — |  |  | 6.4 |  |
| Other long-term liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency forward contracts |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 0.5 |  |  | — |  |  | 0.5 |  |
| Total other long-term liabilities |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 0.5 |  |  | — |  |  | 0.5 |  |
| Total liabilities measured at fair value |  | $ | — |  |  | $ | 8.8 |  |  | $ | — |  |  | $ | 8.8 |  |  | $ | — |  |  | $ | 6.9 |  |  | $ | — |  |  | $ | 6.9 |  |

[0001327567-21-000040:notes:37]
Refer to Note 9. Debt for the carrying amount and estimated fair value of our convertible senior notes as of October 31, 2021 and July 31, 2021.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001327567-21-000040:notes:38]
Cash Equivalents and Investments
Available-for-sale Debt Securities

[0001327567-21-000040:notes:39]
The following tables summarize the amortized cost, unrealized gains and losses, and fair value of our available-for-sale debt securities as of October 31, 2021 and July 31, 2021 (in millions):

[0001327567-21-000040:notes:40]
|  | October 31, 2021 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 150.5 |  |  | $ | — |  |  | $ | — |  |  | $ | 150.5 |  |
| Corporate debt securities | 26.1 |  |  | — |  |  | — |  |  | 26.1 |  |
| U.S. government and agency securities | 70.0 |  |  | — |  |  | — |  |  | 70.0 |  |
| Total available-for-sale cash equivalents | $ | 246.6 |  |  | $ | — |  |  | $ | — |  |  | $ | 246.6 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 156.5 |  |  | $ | — |  |  | $ | — |  |  | $ | 156.5 |  |
| Corporate debt securities | 428.2 |  |  | 0.1 |  |  | (0.5) |  |  | 427.8 |  |
| U.S. government and agency securities | 1,442.6 |  |  | 0.6 |  |  | (0.9) |  |  | 1,442.3 |  |
| Non-U.S. government and agency securities | 60.7 |  |  | — |  |  | — |  |  | 60.7 |  |
| Total available-for-sale investments | $ | 2,088.0 |  |  | $ | 0.7 |  |  | $ | (1.4) |  |  | $ | 2,087.3 |  |

[0001327567-21-000040:notes:41]
|  | July 31, 2021 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 150.4 |  |  | $ | — |  |  | $ | — |  |  | $ | 150.4 |  |
| Corporate debt securities | 1.0 |  |  | — |  |  | — |  |  | 1.0 |  |
| U.S. government and agency securities | 116.3 |  |  | — |  |  | — |  |  | 116.3 |  |
| Total available-for-sale cash equivalents | $ | 267.7 |  |  | $ | — |  |  | $ | — |  |  | $ | 267.7 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 17.4 |  |  | $ | — |  |  | $ | — |  |  | $ | 17.4 |  |
| Corporate debt securities | 389.2 |  |  | 0.5 |  |  | (0.1) |  |  | 389.6 |  |
| U.S. government and agency securities | 1,435.1 |  |  | 1.1 |  |  | — |  |  | 1,436.2 |  |
| Non-U.S. government and agency securities | 72.0 |  |  | — |  |  | — |  |  | 72.0 |  |
| Total available-for-sale investments | $ | 1,913.7 |  |  | $ | 1.6 |  |  | $ | (0.1) |  |  | $ | 1,915.2 |  |

[0001327567-21-000040:notes:42]
We do not intend to sell any of the securities in an unrealized loss position and it is not likely that we would be required to sell these securities before recovery of their amortized cost basis, which may be at maturity. We did not recognize any credit losses related to our available-for-sale debt securities during the three months ended October 31, 2021 and 2020.

[0001327567-21-000040:notes:43]
The following table summarizes the amortized cost and fair value of our available-for-sale debt securities as of October 31, 2021, by contractual years-to-maturity (in millions):

[0001327567-21-000040:notes:44]
|  | Amortized Cost |  | Fair Value |
| Due within one year | $ | 1,434.5 |  |  | $ | 1,435.1 |  |
| Due between one and three years | 900.1 |  |  | 898.8 |  |
| Total | $ | 2,334.6 |  |  | $ | 2,333.9 |  |

[0001327567-21-000040:notes:45]
Marketable Equity Securities

[0001327567-21-000040:notes:46]
Marketable equity securities consist of money market funds and are included in cash and cash equivalents on our condensed consolidated balance sheets. As of October 31, 2021 and July 31, 2021, the carrying values of our marketable equity securities were $161.8 million and $124.2 million, respectively. There were no unrealized gains or losses recognized for these securities during the three months ended October 31, 2021 and 2020.


## us-gaap:FinancingReceivablesTextBlock

[0001327567-21-000040:notes:47]
Financing ReceivablesWe provide financing arrangements, primarily loans, for qualified end-user customers to purchase our products and services. The following table summarizes our short-term and long-term financing receivables as of October 31, 2021 and July 31, 2021 (in millions):

[0001327567-21-000040:notes:48]
|  |  | October 31, 2021 |  | July 31, 2021 |
| Short-term financing receivables, gross |  | $ | 104.9 |  |  | $ | 80.0 |  |
| Allowance for credit losses |  | (1.0) |  |  | (1.0) |  |
| Short-term financing receivables, net |  | $ | 103.9 |  |  | $ | 79.0 |  |
| Long-term financing receivables, gross |  | $ | 201.0 |  |  | $ | 198.6 |  |
| Allowance for credit losses |  | (3.2) |  |  | (4.3) |  |
| Long-term financing receivables, net |  | $ | 197.8 |  |  | $ | 194.3 |  |

[0001327567-21-000040:notes:49]
There was no significant activity in allowance for credit losses during the three months ended October 31, 2021 and 2020. Past due amounts on financing receivables were immaterial as of October 31, 2021 and July 31, 2021.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001327567-21-000040:notes:50]
Derivative Instruments
As a global business, we are exposed to currency exchange rate risk. Substantially all of our revenue is transacted in U.S. dollars, however, a portion of our operating expenditures are incurred outside of the United States and are denominated in foreign currencies, making them subject to fluctuations in foreign currency exchange rates. We enter into foreign currency derivative contracts with maturities of 16 months or less, which we designate as cash flow hedges, to manage the foreign currency exchange rate risk associated with these expenditures.

[0001327567-21-000040:notes:51]
As of October 31, 2021 and July 31, 2021, the total notional amount of our outstanding foreign currency forward contracts including designated and non-designated derivative instruments was $564.0 million and $531.9 million, respectively. Refer to Note 3. Fair Value Measurements for the fair value of our foreign currency derivative instruments as reported on our condensed consolidated balance sheets as of October 31, 2021 and July 31, 2021.

[0001327567-21-000040:notes:52]
During the three months ended October 31, 2021 and 2020, both unrealized gains and losses recognized in AOCI related to our cash flow hedges and amounts reclassified into earnings were not material. Unrealized gains and losses in AOCI related to our cash flow hedges as of October 31, 2021 and July 31, 2021 were not material.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001327567-21-000040:notes:53]
AcquisitionOn August 11, 2021, we completed our acquisition of Gamma Networks, Inc. (“Gamma”), a privately-held AI powered company, for total consideration of $20.4 million, primarily in cash. We expect the acquisition will enhance and expand our data loss prevention offerings. We have accounted for this transaction as a business combination. We allocated the purchase consideration to the assets acquired and liabilities assumed, with the remainder of $22.2 million recorded as goodwill. The goodwill is primarily attributable to the assembled workforce and expected post-acquisition synergies from integrating Gamma technology into our platforms. The goodwill is not deductible for income tax purposes.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001327567-21-000040:notes:54]
[same as prior period, unchanged from 0001327567-21-000014:notes:92]

[0001327567-21-000040:notes:55]
The following table presents details of our goodwill during the three months ended October 31, 2021 (in millions):

[0001327567-21-000040:notes:56]
|  | Amount |
| Balance as of July 31, 2021 | $ | 2,710.1 |  |
| Goodwill acquired | 22.2 |  |
| Balance as of October 31, 2021 | $ | 2,732.3 |  |

[0001327567-21-000040:notes:57]
[same as prior period, unchanged from 0001327567-21-000014:notes:95]

[0001327567-21-000040:notes:58]
The following table presents details of our purchased intangible assets as of October 31, 2021 and July 31, 2021 (in millions):

[0001327567-21-000040:notes:59]
|  | October 31, 2021 |  | July 31, 2021 |
|  | Gross Carrying Amount |  | Accumulated Amortization |  | Net Carrying Amount |  | Gross Carrying Amount |  | Accumulated Amortization |  | Net Carrying Amount |
| Intangible assets subject to amortization: |  |  |  |  |  |  |  |  |  |  |  |
| Developed technology | $ | 600.7 |  |  | $ | (270.1) |  |  | $ | 330.6 |  |  | $ | 596.2 |  |  | $ | (243.8) |  |  | $ | 352.4 |  |
| Customer relationships | 172.7 |  |  | (36.0) |  |  | 136.7 |  |  | 172.7 |  |  | (30.6) |  |  | 142.1 |  |
| Acquired intellectual property | 7.9 |  |  | (3.9) |  |  | 4.0 |  |  | 7.9 |  |  | (3.8) |  |  | 4.1 |  |
| Trade name and trademarks | 9.4 |  |  | (9.4) |  |  | — |  |  | 9.4 |  |  | (9.4) |  |  | — |  |
| Other | — |  |  | — |  |  | — |  |  | 1.8 |  |  | (1.8) |  |  | — |  |
| Total purchased intangible assets | $ | 790.7 |  |  | $ | (319.4) |  |  | $ | 471.3 |  |  | $ | 788.0 |  |  | $ | (289.4) |  |  | $ | 498.6 |  |

[0001327567-21-000040:notes:60]
We recognized amortization expense of $31.8 million and $23.6 million for the three months ended October 31, 2021 and 2020, respectively.

[0001327567-21-000040:notes:61]
The following table summarizes estimated future amortization expense of our intangible assets as of October 31, 2021 (in millions):

[0001327567-21-000040:notes:62]
|  |  |  | Fiscal years ending July 31, |
|  | Total |  | Remaining 2022 |  | 2023 |  | 2024 |  | 2025 |  | 2026 |  | 2027 and thereafter |
| Future amortization expense | $ | 471.3 |  |  | $ | 94.6 |  |  | $ | 100.3 |  |  | $ | 90.4 |  |  | $ | 76.7 |  |  | $ | 55.1 |  |  | $ | 54.2 |  |


## us-gaap:DebtDisclosureTextBlock

[0001327567-21-000040:notes:63]
Debt
Convertible Senior Notes

[0001327567-21-000040:notes:64]
In July 2018, we issued $1.7 billion aggregate principal amount of 0.75% Convertible Senior Notes due 2023 (the “2023 Notes”) and in June 2020, we issued $2.0 billion aggregate principal amount of 0.375% Convertible Senior Notes due 2025 (the “2025 Notes,” and together with the 2023 Notes, the “Notes”). The 2023 Notes bear interest at a fixed rate of 0.75% per year, payable semi-annually in arrears on January 1 and July 1 of each year, beginning on January 1, 2019. The 2025 Notes bear interest at a fixed rate of 0.375% per year, payable semi-annually in arrears on June 1 and December 1 of each year, beginning on December 1, 2020. Each series of the convertible notes is governed by an indenture between us, as the issuer, and U.S. Bank National Association, as Trustee (individually, each an “Indenture,” and together, the “Indentures”). The Notes of each series are unsecured, unsubordinated obligations and the applicable Indenture governing each series of Notes does not contain any financial covenants or restrictions on the payments of dividends, the incurrence of indebtedness, or the issuance or repurchase of securities by us or any of our subsidiaries. The 2023 Notes and the 2025 Notes mature on July 1, 2023 and June 1, 2025, respectively. We cannot redeem the 2023 Notes prior to maturity. We may redeem for cash all or any portion of the 2025 Notes, at our option, on or after June 5, 2023, and prior to the 31st scheduled trading day immediately preceding the maturity date if the last reported sale price of our common stock has been at least 130% of the conversion price then in effect for at least 20 trading days during any 30 consecutive trading day period ending on and including the trading day preceding the date on which we provide notice of redemption. The redemption will be at a price equal to 100% of the principal amount of the 2025 Notes and adjusted for interest. If we call any or all of the 2025 Notes for redemption, holders may convert such 2025 Notes called for redemption at any time prior to the close of business on the second scheduled trading day immediately preceding the redemption date.

[0001327567-21-000040:notes:65]
The following table presents details of our Notes (number of shares in millions):

[0001327567-21-000040:notes:66]
|  | Conversion Rate per $1,000 Principal |  | Initial Conversion Price |  | Convertible Date |  | Initial Number of Shares |
| 2023 Notes | 3.7545 |  |  | $ | 266.35 |  |  | April 1, 2023 |  | 6.4 |  |
| 2025 Notes | 3.3602 |  |  | $ | 297.60 |  |  | March 1, 2025 |  | 6.7 |  |

[0001327567-21-000040:notes:67]
Holders of the Notes may surrender their Notes for conversion at their option at any time prior to the close of business on the business day immediately preceding their respective convertible dates only under the following circumstances:

[0001327567-21-000040:notes:68]
•during any fiscal quarter commencing after the fiscal quarters ending on October 31, 2018 and October 31, 2020 for the 2023 Notes and the 2025 Notes, respectively (and only during such fiscal quarter), if the last reported sale price of our common stock for at least 20 trading days (whether or not consecutive) during a period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the applicable conversion price for the respective Notes on each applicable trading day (the “sale price condition”);

[0001327567-21-000040:notes:69]
•during the five business day period after any five consecutive trading day period (the “measurement period”) in which the trading price per $1,000 principal amount of the applicable series of Notes for each trading day of the measurement period was less than 98% of the product of the last reported sale price of our common stock and the applicable conversion rate for the respective Notes on each such trading day; or

[0001327567-21-000040:notes:70]
•upon the occurrence of specified corporate events.

[0001327567-21-000040:notes:71]
On or after the respective convertible date, holders may surrender all or any portion of their Notes for conversion at any time prior to the close of business on the second scheduled trading day immediately preceding the applicable maturity date regardless of the foregoing conditions, and such conversions will be settled upon the applicable maturity date. Upon conversion, holders of the Notes of a series will receive cash equal to the aggregate principal amount of the Notes of such series to be converted, and, at our election, cash and/or shares of our common stock for any amounts in excess of the aggregate principal amount of the Notes of such series being converted.

[0001327567-21-000040:notes:72]
The conversion price will be subject to adjustment in some events. Holders of the Notes of a series who convert their Notes of such series in connection with certain corporate events that constitute a “make-whole fundamental change” under the applicable Indenture are, under certain circumstances, entitled to an increase in the conversion rate for such series of Notes. Additionally, upon the occurrence of a corporate event that constitutes a “fundamental change” under the applicable Indenture, holders of the Notes of such series may require us to repurchase for cash all or a portion of the Notes of such series at a repurchase price equal to 100% of the principal amount of the Notes of such series plus accrued and unpaid interest to, but excluding, the fundamental change repurchase date.

[0001327567-21-000040:notes:73]
The sale price condition for the Notes was met during the fiscal quarter ended October 31, 2021, and as a result, holders may convert their Notes at any time during the fiscal quarter ending January 31, 2022. Accordingly, the net carrying amount of the Notes was classified as a current liability on our condensed consolidated balance sheet as of October 31, 2021.

[0001327567-21-000040:notes:74]
The following table sets forth the components of the Notes as of October 31, 2021 and July 31, 2021 (in millions):

[0001327567-21-000040:notes:75]
|  | October 31, 2021 (1) | July 31, 2021 |
|  | 2023 Notes |  | 2025 Notes |  | Total |  | 2023 Notes |  | 2025 Notes |  | Total |
| Liability component: |  |  |  |  |  |  |  |  |  |  |  |
| Principal | $ | 1,692.0 |  |  | $ | 2,000.0 |  |  | $ | 3,692.0 |  |  | $ | 1,692.0 |  |  | $ | 2,000.0 |  |  | $ | 3,692.0 |  |
| Less: debt discount and debt issuance costs, net of amortization | (4.7) |  |  | (15.2) |  |  | (19.9) |  |  | (134.1) |  |  | (331.9) |  |  | (466.0) |  |
| Net carrying amount | $ | 1,687.3 |  |  | $ | 1,984.8 |  |  | $ | 3,672.1 |  |  | $ | 1,557.9 |  |  | $ | 1,668.1 |  |  | $ | 3,226.0 |  |
| Equity component (including amounts classified as temporary equity) | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 315.0 |  |  | $ | 403.0 |  |  | $ | 718.0 |  |

[0001327567-21-000040:notes:76]
______________

[0001327567-21-000040:notes:77]
(1)     As described in Note 1. Description of Business and Summary of Significant Accounting Policies, we adopted new debt guidance effective August 1, 2021, using a modified retrospective method, under which financial results reported in prior periods were not adjusted. Upon adoption, our convertible senior notes are accounted for entirely as a liability and measured at their amortized cost. Transaction costs related to the issuance of the notes are netted with the liability and are amortized on a straight-line basis, which approximates the effective interest rate method, to interest expense over the term of the notes.

[0001327567-21-000040:notes:78]
The total estimated fair value of the 2023 Notes and 2025 Notes were $3.2 billion and $3.4 billion at October 31, 2021, respectively and $2.6 billion and $2.9 billion at July 31, 2021, respectively. The fair value was determined based on the closing trading price per $100 of the applicable series of the Notes as of the last day of trading for the period. We consider the fair value of the Notes at October 31, 2021 and July 31, 2021 to be a Level 2 measurement. The fair value of the Notes is primarily affected by the trading price of our common stock and market interest rates.

[0001327567-21-000040:notes:79]
The following table sets forth interest expense recognized related to the Notes (dollars in millions):

[0001327567-21-000040:notes:80]
|  | Three Months Ended October 31, |  |  |
|  | 2021 |  | 2020 |  |  |  |  |
|  | 2023 Notes |  | 2025 Notes |  | Total |  | 2023 Notes |  |  |  | 2025 Notes |  | Total |  |  |  |  |  |  |  |  |  |  |  |  |
| Contractual interest expense | $ | 3.2 |  | $ | 1.9 |  | $ | 5.1 |  |  | $ | 3.2 |  |  |  |  | $ | 1.9 |  | $ | 5.1 |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of debt discount(1) | — |  | — |  | — |  |  | 15.7 |  |  |  |  | 18.2 |  | 33.9 |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of debt issuance costs | 0.7 |  | 1.1 |  | 1.8 |  |  | 0.5 |  |  |  |  | 0.7 |  | 1.2 |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Total interest expense | $ | 3.9 |  | $ | 3.0 |  | $ | 6.9 |  |  | $ | 19.4 |  |  |  |  | $ | 20.8 |  | $ | 40.2 |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Effective interest rate | 0.9 | % |  | 0.6 | % |  |  |  | 5.2% |  |  |  | 5.4 | % |  |  |  |  |  |  |  |  |  |  |  |  |  |  |

[0001327567-21-000040:notes:81]
(1)    Upon adoption of the new debt guidance, the conversion option is no longer separately accounted for as debt discount. Our convertible senior notes are accounted for entirely as a liability.

[0001327567-21-000040:notes:82]
Note Hedges

[0001327567-21-000040:notes:83]
To minimize the impact of potential economic dilution upon conversion of our Notes, we entered into separate convertible note hedge transactions (the “2023 Note Hedges,” with respect to the 2023 Notes, the “2025 Note Hedges,” with respect to the 2025 Notes, and the 2023 Notes Hedges together with 2025 Note Hedges, the “Note Hedges”) with respect to our common stock concurrent with the issuance of each series of the Notes.

[0001327567-21-000040:notes:84]
The following table presents details of our Note Hedges (in millions):

[0001327567-21-000040:notes:85]
|  | Initial Number of Shares |  | Aggregate Purchase |
| 2023 Note Hedges | 6.4 |  |  | $ | 332.0 |  |
| 2025 Note Hedges | 6.7 |  |  | $ | 370.8 |  |

[0001327567-21-000040:notes:86]
The Note Hedges cover shares of our common stock at a strike price per share that corresponds to the initial applicable conversion price of the applicable series of the Notes, which are also subject to adjustment, and are exercisable upon conversion of the applicable series of the Notes. The Note Hedges will expire upon maturity of the applicable series of the Notes. The Note Hedges are separate transactions and are not part of the terms of the applicable series of the Notes. Holders of the Notes of either series will not have any rights with respect to the Note Hedges. Any shares of our common stock receivable by us under the Note Hedges are excluded from the calculation of diluted earnings per share as they are antidilutive. The aggregate amounts paid for the Note Hedges are included in additional paid-in capital in our condensed consolidated balance sheets.

[0001327567-21-000040:notes:87]
Warrants

[0001327567-21-000040:notes:88]
Separately, but concurrently with the issuance of each series of our Notes, we entered into transactions whereby we sold warrants (the “2023 Warrants,” with respect to the 2023 Notes, the “2025 Warrants,” with respect to the 2025 Notes, and the 2023 Warrants together with the 2025 Warrants, the “Warrants”) to acquire shares of our common stock, subject to anti-dilution adjustments. The 2023 Warrants and 2025 Warrants are exercisable beginning October 2023 and September 2025, respectively.

[0001327567-21-000040:notes:89]
The following table presents details of the Warrants (in millions, except per share data):

[0001327567-21-000040:notes:90]
|  | Initial Number of Shares |  | Strike Price per Share |  | Aggregate Proceeds |
| 2023 Warrants | 6.4 |  |  | $ | 417.80 |  |  | $ | 145.4 |  |
| 2025 Warrants | 6.7 |  |  | $ | 408.47 |  |  | $ | 202.8 |  |

[0001327567-21-000040:notes:91]
The shares issuable under the Warrants will be included in the calculation of diluted earnings per share when the average market value per share of our common stock for the reporting period exceeds the applicable strike price for such series of Warrants. The Warrants are separate transactions and are not part of either series of Notes or Note Hedges and are not remeasured through earnings each reporting period. Holders of the Notes of either series will not have any rights with respect to the Warrants. The aggregate proceeds received from the sale of the Warrants are included in additional paid-in capital in our condensed consolidated balance sheets.

[0001327567-21-000040:notes:92]
Revolving Credit Facility

[0001327567-21-000040:notes:93]
On September 4, 2018, we entered into a credit agreement (the “Credit Agreement”) with certain institutional lenders that provides for a $400.0 million unsecured revolving credit facility (the “Credit Facility”), with an option to increase the amount of the Credit Facility by up to an additional $350.0 million, subject to certain conditions. The Credit Facility matures on the earlier of (i) September 4, 2023 and (ii) the date that is 91 days prior to the stated maturity of our 2023 Notes if (a) any of the 2023 Notes are

[0001327567-21-000040:notes:94]
still outstanding and (b) our unrestricted cash and cash equivalents are less than the then outstanding principal amount of our 2023 Notes plus $400.0 million.

[0001327567-21-000040:notes:95]
The borrowings under the Credit Facility currently bear interest, at our option, at a base rate plus a spread of 0.00% to 0.75%, or an adjusted LIBO Rate plus a spread of 1.00% to 1.75%, in each case with such spread being determined based on our leverage ratio. We are obligated to pay an ongoing commitment fee on undrawn amounts at a rate of 0.125% to 0.250%, depending on our leverage ratio. In March 2021, the ICE Benchmark Administration, the administrator of LIBO Rate, announced that it will cease publication of LIBO rate by June 2023. Under the terms of our Credit Facility, in the event of the discontinuance of the LIBO Rate, a mutually agreed-upon alternative benchmark rate will be established to replace the LIBO Rate, which may include the Secured Overnight Financing Rate (“SOFR”). We do not anticipate that the discontinuance of the LIBO Rate will materially impact our liquidity or financial position.

[0001327567-21-000040:notes:96]
As of October 31, 2021, there were no amounts outstanding and we were in compliance with all covenants under the Credit Agreement.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001327567-21-000040:notes:97]
Commitments and Contingencies
Purchase Commitments

[0001327567-21-000040:notes:98]
Manufacturing Purchase Commitments

[0001327567-21-000040:notes:99]
In order to reduce manufacturing lead times and plan for adequate supply, we enter into agreements with manufacturing partners and component suppliers to procure inventory based on our demand forecasts. The following table presents details of the aggregate future purchase commitments under these arrangements excluding obligations under contracts that we can cancel without a significant penalty as of October 31, 2021 (in millions):

[0001327567-21-000040:notes:100]
|  |  |  | Fiscal years ending July 31, |
|  | Total |  | Remaining 2022 |  | 2023 |  | 2024 |  | 2025 |  | 2026 |  | 2027 and thereafter |
| Manufacturing purchase commitments | $ | 358.9 |  |  | $ | 159.5 |  |  | $ | 94.4 |  |  | $ | 30.0 |  |  | $ | 35.0 |  |  | $ | 40.0 |  |  | $ | — |  |

[0001327567-21-000040:notes:101]
Other Purchase Commitments

[0001327567-21-000040:notes:102]
We have entered into various non-cancelable agreements with certain service providers, under which we are committed to minimum or fixed purchases. The following table presents details of the aggregate future non-cancelable purchase commitments under these agreements as of October 31, 2021 (in millions):

[0001327567-21-000040:notes:103]
|  |  |  | Fiscal years ending July 31, |
|  | Total |  | Remaining 2022 |  | 2023 |  | 2024 |  | 2025 |  | 2026 |  | 2027 and thereafter |
| Other purchase commitments | $ | 1,405.8 |  |  | $ | 28.8 |  |  | $ | 186.6 |  |  | $ | 302.7 |  |  | $ | 345.9 |  |  | $ | 541.0 |  |  | $ | 0.8 |  |

[0001327567-21-000040:notes:104]
Additionally, we have a $163.0 million minimum purchase commitment with a service provider through September 2027 with no specified annual commitments.

[0001327567-21-000040:notes:105]
Land Purchase Agreement

[0001327567-21-000040:notes:106]
During the three months ended October 31, 2021, we entered into an agreement to purchase 4.6 acres of land adjacent to our headquarters in Santa Clara, California for $38.9 million in cash. If consummated, the transaction would be expected to close during our fiscal quarter ending January 31, 2022.

[0001327567-21-000040:notes:107]
Litigation

[0001327567-21-000040:notes:108]
We are subject to legal proceedings, claims, and litigation arising in the ordinary course of business, including intellectual property litigation. Such matters are subject to many uncertainties and outcomes are not predictable with assurance. We accrue for contingencies when we believe that a loss is probable and that we can reasonably estimate the amount of any such loss.

[0001327567-21-000040:notes:109]
To the extent there is a reasonable possibility that a loss exceeding amounts already recognized may be incurred and the amount of such additional loss would be material, we will either disclose the estimated additional loss or state that such an estimate cannot be made. As of October 31, 2021, we have not recorded any significant accruals for loss contingencies associated with such legal proceedings, determined that an unfavorable outcome is probable or reasonably possible, or determined that the amount or range of any possible loss is reasonably estimable.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001327567-21-000040:notes:110]
[same as prior period, unchanged from 0001327567-21-000014:notes:142]

[0001327567-21-000040:notes:111]
In February 2019, our board of directors authorized a $1.0 billion share repurchase program, which is funded from available working capital. In December 2020 and August 2021, our board of directors authorized an additional $700.0 million and

[0001327567-21-000040:notes:112]
$676.1 million increase, respectively, bringing the total authorization under this share repurchase program to $2.4 billion. The expiration date of this repurchase authorization was extended to December 31, 2022, and our repurchase program may be suspended or discontinued at any time. Repurchases under our program are to be made at management’s discretion from time to time on the open market, through privately negotiated transactions, transactions structured through investment banking institutions, block purchase techniques, 10b5-1 trading plans, or a combination of the foregoing.

[0001327567-21-000040:notes:113]
We did not repurchase shares of our common stock during the three months ended October 31, 2021. During the three months ended October 31, 2020, we repurchased and retired 2.1 million shares of our common stock under our current repurchase authorization for an aggregate purchase price of $500.0 million, including transaction costs, at an average price of $242.44. As of October 31, 2021, $1.0 billion remained available for future share repurchases under our current repurchase authorization.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001327567-21-000040:notes:114]
Equity Award Plans
Performance Stock Option (“PSO”) Activities

[0001327567-21-000040:notes:115]
We have granted PSOs with both a market condition and a service condition to certain executives. The market condition for PSOs granted in fiscal 2018 and fiscal 2019 requires the price of our common stock to equal or exceed $297.75, $397.00, $496.25, and $595.50 based on the average closing price for 30 consecutive trading days during the four-, five-, six-, and seven-and-a-half-year periods following the date of grant in fiscal 2018 and 2019, respectively. To the extent that the market condition has been met, one-fourth of the PSOs will vest on each anniversary date of the grant date for such PSOs, subject to continued service. All outstanding PSOs may be exercised prior to vesting (“early exercise”). Shares of common stock issued upon early exercise of the PSOs will be restricted and, at our option, subject to repurchase if the option holder ceases to be a service provider. The maximum contractual term of our PSOs is seven and a half years from the date of grant, depending on vesting period.

[0001327567-21-000040:notes:116]
[same as prior period, unchanged from 0001327567-21-000014:notes:151]

[0001327567-21-000040:notes:117]
|  |  |  | PSOs Outstanding |
|  |  |  |  |  |  |  |  |  | Number of Shares |  | Weighted-Average Exercise Price Per Share |  | Weighted-Average Remaining Contractual Term(Years) |  | Aggregate Intrinsic Value |
| Balance—July 31, 2021 |  |  |  |  |  |  |  |  | 2.8 |  |  | $ | 194.14 |  |  | 4.2 |  | $ | 566.8 |  |
| Forfeited |  |  |  |  |  |  |  |  | (0.1) |  |  | $ | 184.24 |  |  |  |  |  |
| Balance—October 31, 2021 |  |  |  |  |  |  |  |  | 2.7 |  |  | $ | 194.55 |  |  | 3.9 |  | $ | 835.9 |  |
| Exercisable—October 31, 2021 |  |  |  |  |  |  |  |  | 2.7 |  |  | $ | 194.55 |  |  | 3.9 |  | $ | 835.9 |  |

[0001327567-21-000040:notes:118]
[same as prior period, unchanged from 0001327567-21-000014:notes:153]

[0001327567-21-000040:notes:119]
[same as prior period, unchanged from 0001327567-21-000014:notes:154]

[0001327567-21-000040:notes:120]
|  | RSUs Outstanding |  | PSUs Outstanding |
|  | Number of Shares |  | Weighted-Average Grant-Date Fair Value Per Share |  |  |  | Aggregate Intrinsic Value |  | Number of Shares |  | Weighted-Average Grant-Date Fair Value Per Share |  |  |  | Aggregate Intrinsic Value |
| Balance—July 31, 2021 | 6.9 |  |  | $ | 257.56 |  |  |  |  | $ | 2,760.2 |  |  | 1.3 |  |  | $ | 292.93 |  |  |  |  | $ | 498.4 |  |
| Granted(1) | 1.3 |  |  | $ | 478.45 |  |  |  |  |  |  | 0.3 |  |  | $ | 328.34 |  |  |  |  |  |
| Vested | (0.8) |  |  | $ | 221.63 |  |  |  |  |  |  | (0.3) |  |  | $ | 243.90 |  |  |  |  |  |
| Forfeited | (0.2) |  |  | $ | 246.56 |  |  |  |  |  |  | (0.1) |  |  | $ | 304.48 |  |  |  |  |  |
| Balance—October 31, 2021 | 7.2 |  |  | $ | 299.53 |  |  |  |  | $ | 3,644.7 |  |  | 1.2 |  |  | $ | 311.24 |  |  |  |  | $ | 628.6 |  |

[0001327567-21-000040:notes:121]
(1)    For PSUs, shares granted represent the aggregate maximum number of shares that may be earned and issued with respect to these awards over their full terms.

[0001327567-21-000040:notes:122]
Our PSUs generally vest over a period of one to four years from the date of grant. The actual number of PSUs earned and eligible to vest is determined based on the level of achievement against performance conditions such as revenue growth, pre-established billings and operating margin goals, or pre-defined individual performance targets for the fiscal year, and market conditions, if applicable.

[0001327567-21-000040:notes:123]
During the three months ended October 31, 2021, we granted 0.1 million shares of PSUs, which contain service, performance and market conditions. The performance condition is based on revenue growth whereas the market condition measures our total shareholder return (“TSR”) relative to the TSR of the companies listed in the Standard & Poor’s 500 index. In addition to this grant, we have also approved the future grant of 0.1 million shares of PSUs with similar terms, which will be considered granted at the time their related vesting conditions are established in the next two years. The fair value of the PSUs subject to the market condition is estimated on the grant date using a Monte Carlo simulation model. The following table summarizes the assumptions used and the grant-date fair value of our PSUs granted during the three months ended October 31, 2021:

[0001327567-21-000040:notes:124]
| Volatility | 31.6% - 38.0% |
| Expected term (in years) | 1.0 - 3.0 |
| Dividend yield | 0.0 | % |
| Risk-free interest rate | 0.1% - 0.4% |
| Grant-date fair value per share | $387.82 - $420.66 |

[0001327567-21-000040:notes:125]
[same as prior period, unchanged from 0001327567-21-000014:notes:157]

[0001327567-21-000040:notes:126]
[same as prior period, unchanged from 0001327567-21-000014:notes:158]

[0001327567-21-000040:notes:127]
|  | Three Months Ended |  |  |
|  | October 31, |  |  |
|  | 2021 |  | 2020 |  |  |  |  |
| Cost of product revenue | $ | 2.3 |  |  | $ | 1.5 |  |  |  |  |  |
| Cost of subscription and support revenue | 26.7 |  |  | 22.2 |  |  |  |  |  |
| Research and development | 125.6 |  |  | 95.4 |  |  |  |  |  |
| Sales and marketing | 73.3 |  |  | 64.9 |  |  |  |  |  |
| General and administrative | 32.4 |  |  | 28.9 |  |  |  |  |  |
| Total share-based compensation | $ | 260.3 |  |  | $ | 212.9 |  |  |  |  |  |

[0001327567-21-000040:notes:128]
As of October 31, 2021, total compensation cost related to unvested share-based awards not yet recognized was $2.3 billion. This cost is expected to be amortized over a weighted-average period of approximately 2.8 years.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001327567-21-000040:notes:129]
Income TaxesFor the three months ended October 31, 2021 and 2020, our provision for income taxes reflected an effective tax rate of negative 13.6% and negative 12.0%, respectively. Our effective tax rates for the three months ended October 31, 2021 and 2020 were negative as we recorded provision for income taxes on year-to-date losses. Our taxes are primarily due to foreign income tax and withholding tax. Our effective tax rates differed from the U.S. statutory tax rate primarily due to changes in our valuation allowance.


## us-gaap:EarningsPerShareTextBlock

[0001327567-21-000040:notes:130]
[same as prior period, unchanged from 0001327567-21-000014:notes:163]

[0001327567-21-000040:notes:131]
[same as prior period, unchanged from 0001327567-21-000014:notes:164]

[0001327567-21-000040:notes:132]
|  | Three Months Ended |  |  |
|  | October 31, |  |  |
|  | 2021 |  | 2020 |  |  |  |  |
| Net loss | $ | (103.6) |  |  | $ | (92.2) |  |  |  |  |  |
| Weighted-average shares used to compute net loss per share, basic and diluted | 97.6 |  |  | 95.5 |  |  |  |  |  |
| Net loss per share, basic and diluted | $ | (1.06) |  |  | $ | (0.97) |  |  |  |  |  |

[0001327567-21-000040:notes:133]
[same as prior period, unchanged from 0001327567-21-000014:notes:166]

[0001327567-21-000040:notes:134]
|  | Three Months Ended |
|  | October 31, |
|  | 2021 |  | 2020 |
| Convertible senior notes | 13.1 |  |  | 13.1 |  |
| Warrants related to the issuance of convertible senior notes | 13.1 |  |  | 13.1 |  |
| RSUs and PSUs | 8.4 |  |  | 8.3 |  |
| Options to purchase common stock, including PSOs | 2.7 |  |  | 2.8 |  |
| Restricted stock awards and performance-based stock awards | 0.3 |  |  | — |  |
| ESPP shares | 0.1 |  |  | 0.1 |  |
| Total | 37.7 |  |  | 37.4 |  |
