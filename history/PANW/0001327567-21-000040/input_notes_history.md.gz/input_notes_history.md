# PANW note change history — 0001327567-21-000014 → 0001327567-21-000040


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2021-11-19):
[0001327567-21-000040:note_history:1]
In order to reduce manufacturing lead times and plan for adequate supply, we enter into agreements with manufacturing partners and component suppliers to procure inventory based on our demand forecasts. The following table presents details of the aggregate future purchase commitments under these arrangements excluding obligations under contracts that we can cancel without a significant penalty as of October 31, 2021 (in millions):
  (was, 2021-05-21, similarity 0.8825):
[0001327567-21-000014:note_history:1]
In order to reduce manufacturing lead times and plan for adequate supply, we enter into agreements with manufacturing partners and component suppliers to procure inventory based on our demand forecasts. We are committed to minimum or fixed purchases through the year ending July 31, 2026. The following table presents details of the aggregate future purchase commitments under these arrangements excluding obligations under contracts that we can cancel without a significant penalty as of April 30, 2021 (in millions):

- changed (2021-11-19):
[0001327567-21-000040:note_history:2]
|  |  |  | Fiscal years ending July 31, |
|  | Total |  | Remaining 2022 |  | 2023 |  | 2024 |  | 2025 |  | 2026 |  | 2027 and thereafter |
| Manufacturing purchase commitments | $ | 358.9 |  |  | $ | 159.5 |  |  | $ | 94.4 |  |  | $ | 30.0 |  |  | $ | 35.0 |  |  | $ | 40.0 |  |  | $ | — |  |
  (was, 2021-05-21, similarity 0.9078):
[0001327567-21-000014:note_history:2]
|  | Total |  | Remaining 2021 |  | 2022 |  | 2023 |  | 2024 |  | 2025 |  | 2026 and Thereafter |
| Manufacturing purchase commitments | $ | 317.5 |  |  | $ | 47.0 |  |  | $ | 135.5 |  |  | $ | 30.0 |  |  | $ | 30.0 |  |  | $ | 35.0 |  |  | $ | 40.0 |  |

- changed (2021-11-19):
[0001327567-21-000040:note_history:3]
We have entered into various non-cancelable agreements with certain service providers, under which we are committed to minimum or fixed purchases. The following table presents details of the aggregate future non-cancelable purchase commitments under these agreements as of October 31, 2021 (in millions):
  (was, 2021-05-21, similarity 0.9268):
[0001327567-21-000014:note_history:3]
We have entered into various non-cancelable agreements with certain service providers, under which we are committed to minimum or fixed purchases through the year ending July 31, 2026. The following table presents details of the aggregate future non-cancelable purchase commitments under these agreements as of April 30, 2021 (in millions):

- changed (2021-11-19):
[0001327567-21-000040:note_history:4]
|  |  |  | Fiscal years ending July 31, |
|  | Total |  | Remaining 2022 |  | 2023 |  | 2024 |  | 2025 |  | 2026 |  | 2027 and thereafter |
| Other purchase commitments | $ | 1,405.8 |  |  | $ | 28.8 |  |  | $ | 186.6 |  |  | $ | 302.7 |  |  | $ | 345.9 |  |  | $ | 541.0 |  |  | $ | 0.8 |  |
  (was, 2021-05-21, similarity 0.9042):
[0001327567-21-000014:note_history:4]
|  | Total |  | Remaining 2021 |  | 2022 |  | 2023 |  | 2024 |  | 2025 |  | 2026 and Thereafter |
| Other purchase commitments | $ | 1,504.8 |  |  | $ | — |  |  | $ | 95.5 |  |  | $ | 227.2 |  |  | $ | 285.7 |  |  | $ | 345.3 |  |  | $ | 551.1 |  |

- added (2021-11-19):
[0001327567-21-000040:note_history:5]
Additionally, we have a $163.0 million minimum purchase commitment with a service provider through September 2027 with no specified annual commitments.

- added (2021-11-19):
[0001327567-21-000040:note_history:6]
Land Purchase Agreement

- added (2021-11-19):
[0001327567-21-000040:note_history:7]
During the three months ended October 31, 2021, we entered into an agreement to purchase 4.6 acres of land adjacent to our headquarters in Santa Clara, California for $38.9 million in cash. If consummated, the transaction would be expected to close during our fiscal quarter ending January 31, 2022.

- changed (2021-11-19):
[0001327567-21-000040:note_history:8]
To the extent there is a reasonable possibility that a loss exceeding amounts already recognized may be incurred and the amount of such additional loss would be material, we will either disclose the estimated additional loss or state that such an estimate cannot be made. As of October 31, 2021, we have not recorded any significant accruals for loss contingencies associated with such legal proceedings, determined that an unfavorable outcome is probable or reasonably possible, or determined that the amount or range of any possible loss is reasonably estimable.
  (was, 2021-05-21, similarity 0.9892):
[0001327567-21-000014:note_history:8]
To the extent there is a reasonable possibility that a loss exceeding amounts already recognized may be incurred and the amount of such additional loss would be material, we will either disclose the estimated additional loss or state that such an estimate cannot be made. As of April 30, 2021, we have not recorded any significant accruals for loss contingencies associated with such legal proceedings, determined that an unfavorable outcome is probable or reasonably possible, or determined that the amount or range of any possible loss is reasonably estimable.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2021-11-19):
[0001327567-21-000040:note_history:9]
Palo Alto Networks, Inc. (the “Company,” “we,” “us,” or “our”), headquartered in Santa Clara, California, was incorporated in March 2005 under the laws of the State of Delaware and commenced operations in April 2005. We empower enterprises, service providers, and government entities to secure all users, applications, data, networks, clouds and devices with comprehensive visibility and context continuously across all locations.
  (was, 2021-05-21, similarity 0.981):
[0001327567-21-000014:note_history:9]
Palo Alto Networks, Inc. (the “Company,” “we,” “us,” or “our”), located in Santa Clara, California, was incorporated in March 2005 under the laws of the State of Delaware and commenced operations in April 2005. We empower enterprises, service providers, and government entities to secure all users, applications, data, networks, clouds and devices with comprehensive visibility and context continuously across all locations.

- changed (2021-11-19):
[0001327567-21-000040:note_history:10]
Our condensed consolidated financial statements are unaudited but include all adjustments of a normal recurring nature necessary for a fair presentation of our quarterly results. Certain prior period amounts have been reclassified to conform to our current period presentation. Our condensed consolidated financial statements should be read in conjunction with the audited consolidated financial statements and related notes in our Annual Report on Form 10-K for the fiscal year ended July 31, 2021.
  (was, 2021-05-21, similarity 0.8881):
[0001327567-21-000014:note_history:10]
Our condensed consolidated financial statements are unaudited but include all adjustments of a normal recurring nature necessary for a fair presentation of our quarterly results. Our condensed consolidated financial statements should be read in conjunction with the audited consolidated financial statements and related notes in our Annual Report on Form 10-K for the fiscal year ended July 31, 2020.

- changed (2021-11-19):
[0001327567-21-000040:note_history:11]
The preparation of condensed consolidated financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the condensed consolidated financial statements and the reported amounts of revenues and expenses during the reporting period. We base our estimates on historical experience and also on assumptions that we believe are reasonable. Actual results could differ materially from those estimates due to risks and uncertainties, including uncertainty in the economic environment due to the global impact of the coronavirus disease discovered in 2019 (“COVID-19”).
  (was, 2021-05-21, similarity 0.9464):
[0001327567-21-000014:note_history:11]
The preparation of condensed consolidated financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the condensed consolidated financial statements and the reported amounts of revenues and expenses during the reporting period. We base our estimates on historical experience and also on assumptions that we believe are reasonable. Actual results could differ materially from those estimates due to risks and uncertainties, including uncertainty in the current economic environment due to COVID-19.

- changed (2021-11-19):
[0001327567-21-000040:note_history:12]
There have been no material changes to our significant accounting policies as of and for the three months ended October 31, 2021, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended July 31, 2021, except for the change in our accounting policies due to our adoption of recently issued guidance. Refer to “Recently Adopted Accounting Pronouncements” below.
  (was, 2021-05-21, similarity 0.8588):
[0001327567-21-000014:note_history:12]
There have been no material changes to our significant accounting policies as of and for the nine months ended April 30, 2021, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended July 31, 2020, except for the change in our accounting policies for credit losses due to our adoption of the new credit losses guidance. Refer to “Recently Adopted Accounting Pronouncements” below.

- added (2021-11-19):
[0001327567-21-000040:note_history:13]
Acquired Contract Assets and Contract Liabilities

- added (2021-11-19):
[0001327567-21-000040:note_history:14]
In October 2021, the Financial Accounting Standards Board (“FASB”) issued authoritative guidance that requires companies to apply revenue guidance to recognize and measure contract assets and contract liabilities from contracts with customers acquired in a business combination on the acquisition date, instead of measuring them at fair value. We early adopted this guidance in our first quarter of fiscal 2022 on a prospective basis. The adoption of this standard did not have a material impact on our condensed consolidated financial statements.

- added (2021-11-19):
[0001327567-21-000040:note_history:15]
In August 2020, the FASB issued authoritative guidance that simplifies the accounting for certain financial instruments with characteristics of liabilities and equity, including convertible instrument. The standard reduces the number of models used to account for convertible instruments and simplifies the classification of debt on the balance sheet.

- added (2021-11-19):
[0001327567-21-000040:note_history:16]
We adopted this standard in our first quarter of fiscal 2022 using the modified-retrospective approach, under which, financial results reported in periods prior to fiscal 2022 were not adjusted. The adoption of this standard resulted in an increase to convertible senior notes, net of $444.3 million, a decrease to accumulated deficit of $266.7 million, and a decrease to additional paid-in capital and temporary equity of $711.0 million upon adoption.

- added (2021-11-19):
[0001327567-21-000040:note_history:17]
Below is the update to our Summary of Significant Accounting Policies in our Annual Report on Form 10-K for the fiscal year ended July 31, 2021 as a result of the adoption of the above guidance.

- added (2021-11-19):
[0001327567-21-000040:note_history:18]
Business Combinations

- added (2021-11-19):
[0001327567-21-000040:note_history:19]
We include the results of operations of the businesses that we acquire as of the respective dates of acquisition. We generally allocate the fair value of the purchase price of our acquisitions to the assets acquired and liabilities assumed based on their estimated

- added (2021-11-19):
[0001327567-21-000040:note_history:20]
fair values. The excess of the purchase price over the values of these identifiable assets and liabilities is recorded as goodwill. Additional information existing as of the acquisition date but unknown to us may become known during the remainder of the measurement period, not to exceed 12 months from the acquisition date, which may result in changes to the amounts and allocations recorded.

- added (2021-11-19):
[0001327567-21-000040:note_history:21]
Convertible Senior Notes

- added (2021-11-19):
[0001327567-21-000040:note_history:22]
Prior to August 1, 2021, our convertible senior notes were separated into a liability and an equity component. The carrying amount of the liability component was calculated by measuring the fair value of a similar liability that did not have an associated convertible feature, using a discounted cash flow model with a risk adjusted yield. The carrying amount of the equity component representing the conversion option was determined by deducting the fair value of the liability component from the par value of the notes as a whole. This difference represented a debt discount that was amortized to interest expense using the effective interest method over the term of the notes. The equity component was not remeasured as it continued to meet the conditions for equity classification. Transaction costs related to the issuance of the notes were allocated to the liability and equity components using the same proportions as the proceeds from the notes. Transaction costs attributable to the liability component were netted with the liability component and amortized to interest expense using the effective interest method over the term of the notes. Transaction costs attributable to the equity component were netted with the equity component of the notes in additional paid-in capital. Upon the notes becoming convertible, the net carrying amount of the liability component was classified as a current liability and a portion of the equity component representing the conversion option was reclassified to temporary equity. The portion of the equity component classified as temporary equity was measured as the difference between the principal and net carrying amount of the notes, excluding debt issuance costs.
Upon adoption of the new debt guidance on August 1, 2021, our convertible senior notes are accounted for entirely as a liability and measured at their amortized cost. Transaction costs related to the issuance of the notes are netted with the liability and are amortized on a straight-line basis, which approximates the effective interest rate method, to interest expense over the term of the notes. Refer to Note 9. Debt for additional information.

- removed (2021-11-19):
[0001327567-21-000014:note_history:23]
Credit Losses

- removed (2021-11-19):
[0001327567-21-000014:note_history:24]
In June 2016, the Financial Accounting Standards Board (“FASB”) issued new authoritative guidance on the accounting for credit losses on most financial assets and certain financial instruments. The standard replaces the incurred loss model with an expected credit loss model for financial assets measured at amortized cost, including trade accounts receivables and financing receivables. Credit losses on available-for-sale debt securities are required to be recorded through an allowance rather than as a write-down.

- removed (2021-11-19):
[0001327567-21-000014:note_history:25]
We adopted this standard in our first quarter of fiscal 2021 using the modified-retrospective approach. The adoption of this standard did not have a material impact on our condensed consolidated financial statements. We updated the following accounting policies as a result of the adoption of this guidance.

- removed (2021-11-19):
[0001327567-21-000014:note_history:26]
Cash, Cash Equivalents, and Investments

- removed (2021-11-19):
[0001327567-21-000014:note_history:27]
We consider all highly liquid investments with original maturities of three months or less at the date of purchase to be cash equivalents. Investments not considered cash equivalents, and with maturities of one year or less from the condensed consolidated balance sheet date, are classified as short-term investments. Investments with maturities greater than one year from the condensed consolidated balance sheet date are classified as long-term investments.

- removed (2021-11-19):
[0001327567-21-000014:note_history:28]
We classify our investments in marketable debt securities as available-for-sale at the time of purchase. When the fair value of a security is below its amortized cost, the amortized cost will be reduced to its fair value if it is more likely than not that we are required to sell the impaired security before recovery of its amortized cost basis, or we have the intention to sell the security. If neither of these conditions are met, we determine whether the impairment is due to credit losses by comparing the present value of the expected cash flows of the security with its amortized cost basis. The amount of impairment recognized is limited to the excess of the amortized cost over the fair value of the security. An allowance for credit losses for the excess of amortized cost over the expected cash flows is

- removed (2021-11-19):
[0001327567-21-000014:note_history:29]
recorded in other income, net in our condensed consolidated statements of operations. Impairment losses that are not credit-related are included in accumulated other comprehensive income (loss) (“AOCI”) in stockholders’ equity.

- removed (2021-11-19):
[0001327567-21-000014:note_history:30]
Accounts Receivable

- removed (2021-11-19):
[0001327567-21-000014:note_history:31]
Trade accounts receivable are recorded at the invoiced amount, net of allowances for credit losses for any potential uncollectible amounts. The allowance for credit losses is based on our assessment of the collectability of accounts. Management regularly reviews the adequacy of the allowance for credit losses on a collective basis by considering the age of each outstanding invoice, each customer’s expected ability to pay and collection history, current market conditions, and reasonable and supportable forecasts of future economic conditions to determine whether the allowance is appropriate. Accounts receivable deemed uncollectible are charged against the allowance for credit losses when identified. For the three and nine months ended April 30, 2021 and 2020, the allowance for credit losses activity was not significant.

- removed (2021-11-19):
[0001327567-21-000014:note_history:32]
Financing Receivables

- removed (2021-11-19):
[0001327567-21-000014:note_history:33]
We provide financing arrangements, primarily loans, for certain qualified end-user customers to purchase our products and services. Payment terms on these financing arrangements are up to five years. We evaluate our allowance for credit losses by assessing the risks and losses inherent in our financing receivables on either an individual or a collective basis. Our assessment considers various factors, including lifetime expected losses determined using customer risk profile, current economic conditions that may affect a customer’s ability to pay, and forward-looking economic considerations. Financing receivables are written off when they are considered uncollectible, and related outstanding balances are reversed and charged against the allowance for credit losses. Short-term financing receivables are included in prepaid expenses and other current assets, and long-term financing receivables are included in other assets on our condensed consolidated balance sheets. Refer to Note 5. Financing Receivables for additional information.

- removed (2021-11-19):
[0001327567-21-000014:note_history:34]
Recently Issued Accounting Pronouncements

- removed (2021-11-19):
[0001327567-21-000014:note_history:35]
In August 2020, the FASB issued new authoritative guidance to simplify the accounting for certain financial instruments with characteristics of liabilities and equity, including convertible instruments and contracts on an entity’s own equity. The standard reduces the number of models used to account for convertible instruments and simplifies both the classification of debt on the balance sheet and the earnings per share calculation. The standard is effective for us in our first quarter of fiscal 2023 and will be applied on a modified retrospective basis. Early adoption is permitted from our first quarter of fiscal 2022. We are currently evaluating the impact of this standard on our condensed consolidated financial statements.


## panw:ConvertibleSeniorNotesPolicyPolicyTextBlock (debt) — matched_by: no_prior_note, score: 0.0

- added (2021-11-19):
[0001327567-21-000040:note_history:36]
Convertible Senior Notes

- added (2021-11-19):
[0001327567-21-000040:note_history:37]
Prior to August 1, 2021, our convertible senior notes were separated into a liability and an equity component. The carrying amount of the liability component was calculated by measuring the fair value of a similar liability that did not have an associated convertible feature, using a discounted cash flow model with a risk adjusted yield. The carrying amount of the equity component representing the conversion option was determined by deducting the fair value of the liability component from the par value of the notes as a whole. This difference represented a debt discount that was amortized to interest expense using the effective interest method over the term of the notes. The equity component was not remeasured as it continued to meet the conditions for equity classification. Transaction costs related to the issuance of the notes were allocated to the liability and equity components using the same proportions as the proceeds from the notes. Transaction costs attributable to the liability component were netted with the liability component and amortized to interest expense using the effective interest method over the term of the notes. Transaction costs attributable to the equity component were netted with the equity component of the notes in additional paid-in capital. Upon the notes becoming convertible, the net carrying amount of the liability component was classified as a current liability and a portion of the equity component representing the conversion option was reclassified to temporary equity. The portion of the equity component classified as temporary equity was measured as the difference between the principal and net carrying amount of the notes, excluding debt issuance costs.
Upon adoption of the new debt guidance on August 1, 2021, our convertible senior notes are accounted for entirely as a liability and measured at their amortized cost. Transaction costs related to the issuance of the notes are netted with the liability and are amortized on a straight-line basis, which approximates the effective interest rate method, to interest expense over the term of the notes.


## us-gaap:ConvertibleDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-11-19):
[0001327567-21-000040:note_history:38]
The following table sets forth the components of the Notes as of October 31, 2021 and July 31, 2021 (in millions):
  (was, 2021-05-21, similarity 0.9515):
[0001327567-21-000014:note_history:38]
The following table sets forth the components of the Notes as of April 30, 2021 and July 31, 2020 (in millions):

- changed (2021-11-19):
[0001327567-21-000040:note_history:39]
|  | October 31, 2021 (1) | July 31, 2021 |
|  | 2023 Notes |  | 2025 Notes |  | Total |  | 2023 Notes |  | 2025 Notes |  | Total |
| Liability component: |  |  |  |  |  |  |  |  |  |  |  |
| Principal | $ | 1,692.0 |  |  | $ | 2,000.0 |  |  | $ | 3,692.0 |  |  | $ | 1,692.0 |  |  | $ | 2,000.0 |  |  | $ | 3,692.0 |  |
| Less: debt discount and debt issuance costs, net of amortization | (4.7) |  |  | (15.2) |  |  | (19.9) |  |  | (134.1) |  |  | (331.9) |  |  | (466.0) |  |
| Net carrying amount | $ | 1,687.3 |  |  | $ | 1,984.8 |  |  | $ | 3,672.1 |  |  | $ | 1,557.9 |  |  | $ | 1,668.1 |  |  | $ | 3,226.0 |  |
| Equity component (including amounts classified as temporary equity) | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 315.0 |  |  | $ | 403.0 |  |  | $ | 718.0 |  |
  (was, 2021-05-21, similarity 0.7248):
[0001327567-21-000014:note_history:39]
|  | April 30, 2021 | July 31, 2020 |
|  | 2023 Notes |  | 2025 Notes |  | Total |  | 2023 Notes |  | 2025 Notes |  | Total |
| Liability component: |  |  |  |  |  |  |  |  |  |  |  |
| Principal | $ | 1,693.0 |  |  | $ | 2,000.0 |  |  | $ | 3,693.0 |  |  | $ | 1,693.0 |  |  | $ | 2,000.0 |  |  | $ | 3,693.0 |  |
| Less: debt discount and debt issuance costs, net of amortization | 150.9 |  |  | 351.5 |  |  | 502.4 |  |  | 200.0 |  |  | 408.9 |  |  | 608.9 |  |
| Net carrying amount | $ | 1,542.1 |  |  | $ | 1,648.5 |  |  | $ | 3,190.6 |  |  | $ | 1,493.0 |  |  | $ | 1,591.1 |  |  | $ | 3,084.1 |  |
| Equity component | $ | 315.0 |  |  | $ | 403.0 |  |  | $ | 718.0 |  |  | $ | 315.0 |  |  | $ | 403.0 |  |  | $ | 718.0 |  |

- added (2021-11-19):
[0001327567-21-000040:note_history:40]
______________

- added (2021-11-19):
[0001327567-21-000040:note_history:41]
(1)     As described in Note 1. Description of Business and Summary of Significant Accounting Policies, we adopted new debt guidance effective August 1, 2021, using a modified retrospective method, under which financial results reported in prior periods were not adjusted. Upon adoption, our convertible senior notes are accounted for entirely as a liability and measured at their amortized cost. Transaction costs related to the issuance of the notes are netted with the liability and are amortized on a straight-line basis, which approximates the effective interest rate method, to interest expense over the term of the notes.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2021-11-19):
[0001327567-21-000040:note_history:42]
The sale price condition for the Notes was met during the fiscal quarter ended October 31, 2021, and as a result, holders may convert their Notes at any time during the fiscal quarter ending January 31, 2022. Accordingly, the net carrying amount of the Notes was classified as a current liability on our condensed consolidated balance sheet as of October 31, 2021.

- changed (2021-11-19):
[0001327567-21-000040:note_history:43]
The following table sets forth the components of the Notes as of October 31, 2021 and July 31, 2021 (in millions):
  (was, 2021-05-21, similarity 0.9515):
[0001327567-21-000014:note_history:43]
The following table sets forth the components of the Notes as of April 30, 2021 and July 31, 2020 (in millions):

- changed (2021-11-19):
[0001327567-21-000040:note_history:44]
|  | October 31, 2021 (1) | July 31, 2021 |
|  | 2023 Notes |  | 2025 Notes |  | Total |  | 2023 Notes |  | 2025 Notes |  | Total |
| Liability component: |  |  |  |  |  |  |  |  |  |  |  |
| Principal | $ | 1,692.0 |  |  | $ | 2,000.0 |  |  | $ | 3,692.0 |  |  | $ | 1,692.0 |  |  | $ | 2,000.0 |  |  | $ | 3,692.0 |  |
| Less: debt discount and debt issuance costs, net of amortization | (4.7) |  |  | (15.2) |  |  | (19.9) |  |  | (134.1) |  |  | (331.9) |  |  | (466.0) |  |
| Net carrying amount | $ | 1,687.3 |  |  | $ | 1,984.8 |  |  | $ | 3,672.1 |  |  | $ | 1,557.9 |  |  | $ | 1,668.1 |  |  | $ | 3,226.0 |  |
| Equity component (including amounts classified as temporary equity) | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 315.0 |  |  | $ | 403.0 |  |  | $ | 718.0 |  |
  (was, 2021-05-21, similarity 0.7248):
[0001327567-21-000014:note_history:44]
|  | April 30, 2021 | July 31, 2020 |
|  | 2023 Notes |  | 2025 Notes |  | Total |  | 2023 Notes |  | 2025 Notes |  | Total |
| Liability component: |  |  |  |  |  |  |  |  |  |  |  |
| Principal | $ | 1,693.0 |  |  | $ | 2,000.0 |  |  | $ | 3,693.0 |  |  | $ | 1,693.0 |  |  | $ | 2,000.0 |  |  | $ | 3,693.0 |  |
| Less: debt discount and debt issuance costs, net of amortization | 150.9 |  |  | 351.5 |  |  | 502.4 |  |  | 200.0 |  |  | 408.9 |  |  | 608.9 |  |
| Net carrying amount | $ | 1,542.1 |  |  | $ | 1,648.5 |  |  | $ | 3,190.6 |  |  | $ | 1,493.0 |  |  | $ | 1,591.1 |  |  | $ | 3,084.1 |  |
| Equity component | $ | 315.0 |  |  | $ | 403.0 |  |  | $ | 718.0 |  |  | $ | 315.0 |  |  | $ | 403.0 |  |  | $ | 718.0 |  |

- added (2021-11-19):
[0001327567-21-000040:note_history:45]
______________

- added (2021-11-19):
[0001327567-21-000040:note_history:46]
(1)     As described in Note 1. Description of Business and Summary of Significant Accounting Policies, we adopted new debt guidance effective August 1, 2021, using a modified retrospective method, under which financial results reported in prior periods were not adjusted. Upon adoption, our convertible senior notes are accounted for entirely as a liability and measured at their amortized cost. Transaction costs related to the issuance of the notes are netted with the liability and are amortized on a straight-line basis, which approximates the effective interest rate method, to interest expense over the term of the notes.

- added (2021-11-19):
[0001327567-21-000040:note_history:47]
The total estimated fair value of the 2023 Notes and 2025 Notes were $3.2 billion and $3.4 billion at October 31, 2021, respectively and $2.6 billion and $2.9 billion at July 31, 2021, respectively. The fair value was determined based on the closing trading price per $100 of the applicable series of the Notes as of the last day of trading for the period. We consider the fair value of the Notes at October 31, 2021 and July 31, 2021 to be a Level 2 measurement. The fair value of the Notes is primarily affected by the trading price of our common stock and market interest rates.

- added (2021-11-19):
[0001327567-21-000040:note_history:48]
|  | Three Months Ended October 31, |  |  |
|  | 2021 |  | 2020 |  |  |  |  |
|  | 2023 Notes |  | 2025 Notes |  | Total |  | 2023 Notes |  |  |  | 2025 Notes |  | Total |  |  |  |  |  |  |  |  |  |  |  |  |
| Contractual interest expense | $ | 3.2 |  | $ | 1.9 |  | $ | 5.1 |  |  | $ | 3.2 |  |  |  |  | $ | 1.9 |  | $ | 5.1 |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of debt discount(1) | — |  | — |  | — |  |  | 15.7 |  |  |  |  | 18.2 |  | 33.9 |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of debt issuance costs | 0.7 |  | 1.1 |  | 1.8 |  |  | 0.5 |  |  |  |  | 0.7 |  | 1.2 |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Total interest expense | $ | 3.9 |  | $ | 3.0 |  | $ | 6.9 |  |  | $ | 19.4 |  |  |  |  | $ | 20.8 |  | $ | 40.2 |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Effective interest rate | 0.9 | % |  | 0.6 | % |  |  |  | 5.2% |  |  |  | 5.4 | % |  |  |  |  |  |  |  |  |  |  |  |  |  |  |

- added (2021-11-19):
[0001327567-21-000040:note_history:49]
______________

- added (2021-11-19):
[0001327567-21-000040:note_history:50]
(1)    Upon adoption of the new debt guidance, the conversion option is no longer separately accounted for as debt discount. Our convertible senior notes are accounted for entirely as a liability.

- changed (2021-11-19):
[0001327567-21-000040:note_history:51]
On September 4, 2018, we entered into a credit agreement (the “Credit Agreement”) with certain institutional lenders that provides for a $400.0 million unsecured revolving credit facility (the “Credit Facility”), with an option to increase the amount of the Credit Facility by up to an additional $350.0 million, subject to certain conditions. The Credit Facility matures on the earlier of (i) September 4, 2023 and (ii) the date that is 91 days prior to the stated maturity of our 2023 Notes if (a) any of the 2023 Notes are
  (was, 2021-05-21, similarity 0.8675):
[0001327567-21-000014:note_history:51]
On September 4, 2018, we entered into a credit agreement (the “Credit Agreement”) with certain institutional lenders that provides for a $400.0 million unsecured revolving credit facility (the “Credit Facility”), with an option to increase the amount of the Credit Facility by up to an additional $350.0 million, subject to certain conditions. The Credit Facility matures on the earlier of (i) September 4, 2023 and (ii) the date that is 91 days prior to the stated maturity of our 2023 Notes if (a) any of the 2023 Notes are still outstanding and (b) our unrestricted cash and cash equivalents are less than the then outstanding principal amount of our 2023 Notes plus $400.0 million.

- added (2021-11-19):
[0001327567-21-000040:note_history:52]
still outstanding and (b) our unrestricted cash and cash equivalents are less than the then outstanding principal amount of our 2023 Notes plus $400.0 million.

- changed (2021-11-19):
[0001327567-21-000040:note_history:53]
The borrowings under the Credit Facility currently bear interest, at our option, at a base rate plus a spread of 0.00% to 0.75%, or an adjusted LIBO Rate plus a spread of 1.00% to 1.75%, in each case with such spread being determined based on our leverage ratio. We are obligated to pay an ongoing commitment fee on undrawn amounts at a rate of 0.125% to 0.250%, depending on our leverage ratio. In March 2021, the ICE Benchmark Administration, the administrator of LIBO Rate, announced that it will cease publication of LIBO rate by June 2023. Under the terms of our Credit Facility, in the event of the discontinuance of the LIBO Rate, a mutually agreed-upon alternative benchmark rate will be established to replace the LIBO Rate, which may include the Secured Overnight Financing Rate (“SOFR”). We do not anticipate that the discontinuance of the LIBO Rate will materially impact our liquidity or financial position.
  (was, 2021-05-21, similarity 0.7759):
[0001327567-21-000014:note_history:53]
The borrowings under the Credit Facility currently bear interest, at our option, at a base rate plus a spread of 0.00% to 0.75%, or an adjusted LIBO Rate plus a spread of 1.00% to 1.75%, in each case with such spread being determined based on our leverage ratio. We are obligated to pay an ongoing commitment fee on undrawn amounts at a rate of 0.125% to 0.250%, depending on our leverage ratio. Regulatory authorities that oversee financial markets have announced that after the end of 2021, they would no longer compel banks currently reporting information used to set the LIBO Rate to continue to make rate submissions. As a result, it is possible that beginning in 2022, the LIBO Rate will no longer be available as a reference rate. Under the terms of our Credit Facility, in the event of the discontinuance of the LIBO Rate, a mutually agreed-upon alternative benchmark rate will be established to replace the LIBO Rate, which may include the Secured Overnight Financing Rate (“SOFR”). We do not anticipate that the discontinuance of the LIBO Rate will materially impact our liquidity or financial position.

- changed (2021-11-19):
[0001327567-21-000040:note_history:54]
As of October 31, 2021, there were no amounts outstanding and we were in compliance with all covenants under the Credit Agreement.
  (was, 2021-05-21, similarity 0.9593):
[0001327567-21-000014:note_history:54]
As of April 30, 2021, there were no amounts outstanding and we were in compliance with all covenants under the Credit Agreement.

- removed (2021-11-19):
[0001327567-21-000014:note_history:55]
The sale price condition was not met for the Notes during the fiscal quarters ended April 30, 2021 and July 31, 2020. Since the Notes were not convertible, the net carrying amount of the Notes was classified as a long-term liability and the equity component was

- removed (2021-11-19):
[0001327567-21-000014:note_history:56]
included in additional paid-in capital in our condensed consolidated balance sheets in the periods presented. As of April 30, 2021, all of the Notes remained outstanding.

- removed (2021-11-19):
[0001327567-21-000014:note_history:57]
The total estimated fair value of the Notes was $5.0 billion and $4.1 billion at April 30, 2021 and July 31, 2020, respectively. The fair value was determined based on the closing trading price per $100 of the Notes as of the last day of trading for the period. We consider the fair value of the Notes at April 30, 2021 and July 31, 2020 to be a Level 2 measurement. The fair value of the Notes is primarily affected by the trading price of our common stock and market interest rates. Based on the closing price of our common stock on April 30, 2021, the if-converted values of the 2023 Notes and 2025 Notes exceeded their principal amounts by $488.4 million and $305.7 million, respectively.

- removed (2021-11-19):
[0001327567-21-000014:note_history:58]
|  | Three Months Ended April 30, |  | Nine Months Ended April 30, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
|  | 2023 Notes |  | 2025 Notes |  | Total |  | 2023 Notes |  |  |  | Total |  | 2023 Notes |  | 2025 Notes |  | Total |  | 2023 Notes |  |  |  | Total |
| Contractual interest expense | $ | 3.2 |  | $ | 1.8 |  | $ | 5.0 |  |  | $ | 3.2 |  |  |  |  | $ | 3.2 |  |  | $ | 9.5 |  | $ | 5.6 |  | $ | 15.1 |  |  | $ | 9.5 |  |  |  | $ | 9.5 |  |
| Amortization of debt discount | 16.0 |  | 18.6 |  | 34.6 |  |  | 15.3 |  |  |  |  | 15.3 |  |  | 47.4 |  | 55.3 |  | 102.7 |  |  | 45.5 |  |  |  | 45.5 |  |
| Amortization of debt issuance costs | 0.6 |  | 0.7 |  | 1.3 |  |  | 0.5 |  |  |  |  | 0.5 |  |  | 1.7 |  | 2.1 |  | 3.8 |  |  | 1.5 |  |  |  | 1.5 |  |
| Total interest expense recognized | $ | 19.8 |  | $ | 21.1 |  | $ | 40.9 |  |  | $ | 19.0 |  |  |  |  | $ | 19.0 |  |  | $ | 58.6 |  | $ | 63.0 |  | $ | 121.6 |  |  | $ | 56.5 |  |  |  | $ | 56.5 |  |
| Effective interest rate of the liability component | 5.2 | % |  | 5.4 | % |  |  |  | 5.2% |  |  |  |  |  | 5.2 | % |  | 5.4 | % |  |  |  | 5.2 | % |  |  |  |  |


## us-gaap:DebtSecuritiesAvailableForSaleTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-11-19):
[0001327567-21-000040:note_history:59]
The following tables summarize the amortized cost, unrealized gains and losses, and fair value of our available-for-sale debt securities as of October 31, 2021 and July 31, 2021 (in millions):
  (was, 2021-05-21, similarity 0.9724):
[0001327567-21-000014:note_history:59]
The following tables summarize the amortized cost, unrealized gains and losses, and fair value of our available-for-sale debt securities as of April 30, 2021 and July 31, 2020 (in millions):

- changed (2021-11-19):
[0001327567-21-000040:note_history:60]
|  | October 31, 2021 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 150.5 |  |  | $ | — |  |  | $ | — |  |  | $ | 150.5 |  |
| Corporate debt securities | 26.1 |  |  | — |  |  | — |  |  | 26.1 |  |
| U.S. government and agency securities | 70.0 |  |  | — |  |  | — |  |  | 70.0 |  |
| Total available-for-sale cash equivalents | $ | 246.6 |  |  | $ | — |  |  | $ | — |  |  | $ | 246.6 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 156.5 |  |  | $ | — |  |  | $ | — |  |  | $ | 156.5 |  |
| Corporate debt securities | 428.2 |  |  | 0.1 |  |  | (0.5) |  |  | 427.8 |  |
| U.S. government and agency securities | 1,442.6 |  |  | 0.6 |  |  | (0.9) |  |  | 1,442.3 |  |
| Non-U.S. government and agency securities | 60.7 |  |  | — |  |  | — |  |  | 60.7 |  |
| Total available-for-sale investments | $ | 2,088.0 |  |  | $ | 0.7 |  |  | $ | (1.4) |  |  | $ | 2,087.3 |  |
  (was, 2021-05-21, similarity 0.9904):
[0001327567-21-000014:note_history:60]
|  | April 30, 2021 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 150.2 |  |  | $ | — |  |  | $ | — |  |  | $ | 150.2 |  |
| Corporate debt securities | 2.0 |  |  | — |  |  | — |  |  | 2.0 |  |
| U.S. government and agency securities | 130.0 |  |  | — |  |  | — |  |  | 130.0 |  |
| Total available-for-sale cash equivalents | $ | 282.2 |  |  | $ | — |  |  | $ | — |  |  | $ | 282.2 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 23.5 |  |  | $ | — |  |  | $ | — |  |  | $ | 23.5 |  |
| Corporate debt securities | 389.4 |  |  | 0.6 |  |  | (0.1) |  |  | 389.9 |  |
| U.S. government and agency securities | 1,465.3 |  |  | 1.5 |  |  | — |  |  | 1,466.8 |  |
| Non-U.S. government and agency securities | 64.5 |  |  | — |  |  | — |  |  | 64.5 |  |
| Total available-for-sale investments | $ | 1,942.7 |  |  | $ | 2.1 |  |  | $ | (0.1) |  |  | $ | 1,944.7 |  |

- changed (2021-11-19):
[0001327567-21-000040:note_history:61]
|  | July 31, 2021 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 150.4 |  |  | $ | — |  |  | $ | — |  |  | $ | 150.4 |  |
| Corporate debt securities | 1.0 |  |  | — |  |  | — |  |  | 1.0 |  |
| U.S. government and agency securities | 116.3 |  |  | — |  |  | — |  |  | 116.3 |  |
| Total available-for-sale cash equivalents | $ | 267.7 |  |  | $ | — |  |  | $ | — |  |  | $ | 267.7 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 17.4 |  |  | $ | — |  |  | $ | — |  |  | $ | 17.4 |  |
| Corporate debt securities | 389.2 |  |  | 0.5 |  |  | (0.1) |  |  | 389.6 |  |
| U.S. government and agency securities | 1,435.1 |  |  | 1.1 |  |  | — |  |  | 1,436.2 |  |
| Non-U.S. government and agency securities | 72.0 |  |  | — |  |  | — |  |  | 72.0 |  |
| Total available-for-sale investments | $ | 1,913.7 |  |  | $ | 1.6 |  |  | $ | (0.1) |  |  | $ | 1,915.2 |  |
  (was, 2021-05-21, similarity 0.7565):
[0001327567-21-000014:note_history:61]
|  | July 31, 2020 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| U.S. government and agency securities | $ | 342.0 |  |  | $ | — |  |  | $ | — |  |  | $ | 342.0 |  |
| Total available-for-sale cash equivalents | $ | 342.0 |  |  | $ | — |  |  | $ | — |  |  | $ | 342.0 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 31.9 |  |  | $ | — |  |  | $ | — |  |  | $ | 31.9 |  |
| Corporate debt securities | 190.1 |  |  | 1.8 |  |  | — |  |  | 191.9 |  |
| U.S. government and agency securities | 1,090.3 |  |  | 2.8 |  |  | (0.1) |  |  | 1,093.0 |  |
| Non-U.S. government and agency securities | 27.4 |  |  | — |  |  | — |  |  | 27.4 |  |
| Total available-for-sale investments | $ | 1,339.7 |  |  | $ | 4.6 |  |  | $ | (0.1) |  |  | $ | 1,344.2 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-11-19):
[0001327567-21-000040:note_history:62]
The following tables summarize the amortized cost, unrealized gains and losses, and fair value of our available-for-sale debt securities as of October 31, 2021 and July 31, 2021 (in millions):
  (was, 2021-05-21, similarity 0.9724):
[0001327567-21-000014:note_history:62]
The following tables summarize the amortized cost, unrealized gains and losses, and fair value of our available-for-sale debt securities as of April 30, 2021 and July 31, 2020 (in millions):

- changed (2021-11-19):
[0001327567-21-000040:note_history:63]
|  | October 31, 2021 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 150.5 |  |  | $ | — |  |  | $ | — |  |  | $ | 150.5 |  |
| Corporate debt securities | 26.1 |  |  | — |  |  | — |  |  | 26.1 |  |
| U.S. government and agency securities | 70.0 |  |  | — |  |  | — |  |  | 70.0 |  |
| Total available-for-sale cash equivalents | $ | 246.6 |  |  | $ | — |  |  | $ | — |  |  | $ | 246.6 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 156.5 |  |  | $ | — |  |  | $ | — |  |  | $ | 156.5 |  |
| Corporate debt securities | 428.2 |  |  | 0.1 |  |  | (0.5) |  |  | 427.8 |  |
| U.S. government and agency securities | 1,442.6 |  |  | 0.6 |  |  | (0.9) |  |  | 1,442.3 |  |
| Non-U.S. government and agency securities | 60.7 |  |  | — |  |  | — |  |  | 60.7 |  |
| Total available-for-sale investments | $ | 2,088.0 |  |  | $ | 0.7 |  |  | $ | (1.4) |  |  | $ | 2,087.3 |  |
  (was, 2021-05-21, similarity 0.9904):
[0001327567-21-000014:note_history:63]
|  | April 30, 2021 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 150.2 |  |  | $ | — |  |  | $ | — |  |  | $ | 150.2 |  |
| Corporate debt securities | 2.0 |  |  | — |  |  | — |  |  | 2.0 |  |
| U.S. government and agency securities | 130.0 |  |  | — |  |  | — |  |  | 130.0 |  |
| Total available-for-sale cash equivalents | $ | 282.2 |  |  | $ | — |  |  | $ | — |  |  | $ | 282.2 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 23.5 |  |  | $ | — |  |  | $ | — |  |  | $ | 23.5 |  |
| Corporate debt securities | 389.4 |  |  | 0.6 |  |  | (0.1) |  |  | 389.9 |  |
| U.S. government and agency securities | 1,465.3 |  |  | 1.5 |  |  | — |  |  | 1,466.8 |  |
| Non-U.S. government and agency securities | 64.5 |  |  | — |  |  | — |  |  | 64.5 |  |
| Total available-for-sale investments | $ | 1,942.7 |  |  | $ | 2.1 |  |  | $ | (0.1) |  |  | $ | 1,944.7 |  |

- changed (2021-11-19):
[0001327567-21-000040:note_history:64]
|  | July 31, 2021 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 150.4 |  |  | $ | — |  |  | $ | — |  |  | $ | 150.4 |  |
| Corporate debt securities | 1.0 |  |  | — |  |  | — |  |  | 1.0 |  |
| U.S. government and agency securities | 116.3 |  |  | — |  |  | — |  |  | 116.3 |  |
| Total available-for-sale cash equivalents | $ | 267.7 |  |  | $ | — |  |  | $ | — |  |  | $ | 267.7 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 17.4 |  |  | $ | — |  |  | $ | — |  |  | $ | 17.4 |  |
| Corporate debt securities | 389.2 |  |  | 0.5 |  |  | (0.1) |  |  | 389.6 |  |
| U.S. government and agency securities | 1,435.1 |  |  | 1.1 |  |  | — |  |  | 1,436.2 |  |
| Non-U.S. government and agency securities | 72.0 |  |  | — |  |  | — |  |  | 72.0 |  |
| Total available-for-sale investments | $ | 1,913.7 |  |  | $ | 1.6 |  |  | $ | (0.1) |  |  | $ | 1,915.2 |  |
  (was, 2021-05-21, similarity 0.7565):
[0001327567-21-000014:note_history:64]
|  | July 31, 2020 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| U.S. government and agency securities | $ | 342.0 |  |  | $ | — |  |  | $ | — |  |  | $ | 342.0 |  |
| Total available-for-sale cash equivalents | $ | 342.0 |  |  | $ | — |  |  | $ | — |  |  | $ | 342.0 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 31.9 |  |  | $ | — |  |  | $ | — |  |  | $ | 31.9 |  |
| Corporate debt securities | 190.1 |  |  | 1.8 |  |  | — |  |  | 191.9 |  |
| U.S. government and agency securities | 1,090.3 |  |  | 2.8 |  |  | (0.1) |  |  | 1,093.0 |  |
| Non-U.S. government and agency securities | 27.4 |  |  | — |  |  | — |  |  | 27.4 |  |
| Total available-for-sale investments | $ | 1,339.7 |  |  | $ | 4.6 |  |  | $ | (0.1) |  |  | $ | 1,344.2 |  |

- changed (2021-11-19):
[0001327567-21-000040:note_history:65]
We do not intend to sell any of the securities in an unrealized loss position and it is not likely that we would be required to sell these securities before recovery of their amortized cost basis, which may be at maturity. We did not recognize any credit losses related to our available-for-sale debt securities during the three months ended October 31, 2021 and 2020.
  (was, 2021-05-21, similarity 0.9624):
[0001327567-21-000014:note_history:65]
We do not intend to sell any of the securities in an unrealized loss position and it is not likely that we would be required to sell these securities before recovery of their amortized cost basis, which may be at maturity. We did not recognize any credit losses related to our available-for-sale debt securities during the three and nine months ended April 30, 2021.

- changed (2021-11-19):
[0001327567-21-000040:note_history:66]
The following table summarizes the amortized cost and fair value of our available-for-sale debt securities as of October 31, 2021, by contractual years-to-maturity (in millions):
  (was, 2021-05-21, similarity 0.9708):
[0001327567-21-000014:note_history:66]
The following table summarizes the amortized cost and fair value of our available-for-sale debt securities as of April 30, 2021, by contractual years-to-maturity (in millions):

- added (2021-11-19):
[0001327567-21-000040:note_history:67]
Marketable equity securities consist of money market funds and are included in cash and cash equivalents on our condensed consolidated balance sheets. As of October 31, 2021 and July 31, 2021, the carrying values of our marketable equity securities were $161.8 million and $124.2 million, respectively. There were no unrealized gains or losses recognized for these securities during the three months ended October 31, 2021 and 2020.

- removed (2021-11-19):
[0001327567-21-000014:note_history:68]
Marketable equity securities consist of money market funds and are included in cash and cash equivalents on our condensed consolidated balance sheets. As of April 30, 2021 and July 31, 2020, the carrying values of our marketable equity securities were $265.0 million and $1.6 billion, respectively. There were no unrealized gains or losses recognized for these securities during the three and nine months ended April 30, 2021 and 2020.


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2021-11-19):
[0001327567-21-000040:note_history:69]
|  | Three Months Ended October 31, |  |  |
|  | 2021 |  | 2020 |  |  |  |  |
| Revenue: |  |  |  |  |  |  |  |
| Americas |  |  |  |  |  |  |  |
| United States | $ | 811.7 |  |  | $ | 624.4 |  |  |  |  |  |
| Other Americas | 55.0 |  |  | 42.1 |  |  |  |  |  |
| Total Americas | 866.7 |  |  | 666.5 |  |  |  |  |  |
| Europe, the Middle East, and Africa (“EMEA”) | 233.8 |  |  | 173.4 |  |  |  |  |  |
| Asia Pacific and Japan (“APAC”) | 146.9 |  |  | 106.1 |  |  |  |  |  |
| Total revenue | $ | 1,247.4 |  |  | $ | 946.0 |  |  |  |  |  |

- added (2021-11-19):
[0001327567-21-000040:note_history:70]
|  | Three Months Ended October 31, |  |  |
|  | 2021 |  | 2020 |  |  |  |  |
| Revenue: |  |  |  |  |  |  |  |
| Product | $ | 295.5 |  |  | $ | 237.3 |  |  |  |  |  |
| Subscription and support |  |  |  |  |  |  |  |
| Subscription | 578.8 |  |  | 428.0 |  |  |  |  |  |
| Support | 373.1 |  |  | 280.7 |  |  |  |  |  |
| Total subscription and support | 951.9 |  |  | 708.7 |  |  |  |  |  |
| Total revenue | $ | 1,247.4 |  |  | $ | 946.0 |  |  |  |  |  |

- changed (2021-11-19):
[0001327567-21-000040:note_history:71]
During the three months ended October 31, 2021 and 2020, we recognized approximately $840.0 million and $630.0 million of revenue pertaining to amounts that were deferred as of July 31, 2021 and 2020, respectively.
  (was, 2021-05-21, similarity 0.9437):
[0001327567-21-000014:note_history:71]
During the nine months ended April 30, 2021 and 2020, we recognized approximately $1.6 billion and $1.3 billion of revenue pertaining to amounts that were deferred as of July 31, 2020 and 2019, respectively.

- changed (2021-11-19):
[0001327567-21-000040:note_history:72]
Revenue expected to be recognized from remaining performance obligations was $6.0 billion as of October 31, 2021, of which we expect to recognize approximately $3.2 billion over the next 12 months and the remainder thereafter.
  (was, 2021-05-21, similarity 0.7063):
[0001327567-21-000014:note_history:72]
Revenue expected to be recognized from remaining performance obligations was $4.9 billion as of April 30, 2021, of which we expect to recognize approximately $2.6 billion over the next 12 months and the remainder thereafter.
Deferred Contract Costs
The following table presents details of our short-term and long-term deferred contract costs as of April 30, 2021 and July 31, 2020 (in millions):

- removed (2021-11-19):
[0001327567-21-000014:note_history:73]
|  | Three Months Ended April 30, |  | Nine Months Ended April 30, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Revenue: |  |  |  |  |  |  |  |
| Americas |  |  |  |  |  |  |  |
| United States | $ | 685.4 |  |  | $ | 553.5 |  |  | $ | 1,957.8 |  |  | $ | 1,554.0 |  |
| Other Americas | 49.1 |  |  | 40.7 |  |  | 137.9 |  |  | 114.5 |  |
| Total Americas | 734.5 |  |  | 594.2 |  |  | 2,095.7 |  |  | 1,668.5 |  |
| Europe, the Middle East, and Africa (“EMEA”) | 210.2 |  |  | 171.5 |  |  | 586.9 |  |  | 485.3 |  |
| Asia Pacific and Japan (“APAC”) | 129.2 |  |  | 103.7 |  |  | 354.2 |  |  | 304.2 |  |
| Total revenue | $ | 1,073.9 |  |  | $ | 869.4 |  |  | $ | 3,036.8 |  |  | $ | 2,458.0 |  |

- removed (2021-11-19):
[0001327567-21-000014:note_history:74]
|  | Three Months Ended April 30, |  | Nine Months Ended April 30, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Revenue: |  |  |  |  |  |  |  |
| Product | $ | 288.9 |  |  | $ | 280.9 |  |  | $ | 780.9 |  |  | $ | 758.6 |  |
| Subscription and support |  |  |  |  |  |  |  |
| Subscription | 473.8 |  |  | 354.3 |  |  | 1,363.5 |  |  | 1,015.5 |  |
| Support | 311.2 |  |  | 234.2 |  |  | 892.4 |  |  | 683.9 |  |
| Total subscription and support | 785.0 |  |  | 588.5 |  |  | 2,255.9 |  |  | 1,699.4 |  |
| Total revenue | $ | 1,073.9 |  |  | $ | 869.4 |  |  | $ | 3,036.8 |  |  | $ | 2,458.0 |  |

- removed (2021-11-19):
[0001327567-21-000014:note_history:75]
|  | April 30, 2021 |  | July 31, 2020 |
| Short-term deferred contract costs | $ | 235.0 |  |  | $ | 206.0 |  |
| Long-term deferred contract costs | 420.1 |  |  | 422.3 |  |
| Total deferred contract costs | $ | 655.1 |  |  | $ | 628.3 |  |

- removed (2021-11-19):
[0001327567-21-000014:note_history:76]
We recognized amortization expense for our deferred contract costs of $73.9 million and $208.3 million during the three and nine months ended April 30, 2021, respectively, and $60.5 million and $171.4 million during the three and nine months ended 
April 30, 2020, respectively. We did not recognize any impairment losses on our deferred contract costs during the three and nine months ended April 30, 2021 or 2020.
