# PANW MD&A — 0001327567-21-000040


## mdna

[0001327567-21-000040:mdna:1]
[same as prior period, unchanged from 0001327567-21-000014:mdna:1]

[0001327567-21-000040:mdna:2]
[same as prior period, unchanged from 0001327567-21-000014:mdna:2]

[0001327567-21-000040:mdna:3]
[same as prior period, unchanged from 0001327567-21-000014:mdna:3]

[0001327567-21-000040:mdna:4]
•Key Financial Metrics. A summary of our GAAP and non-GAAP key financial metrics, which management monitors to evaluate our performance.

[0001327567-21-000040:mdna:5]
•Results of Operations. A discussion of the nature and trends in our financial results and an analysis of our financial results comparing the three months ended October 31, 2021 to the three months ended October 31, 2020.

[0001327567-21-000040:mdna:6]
[same as prior period, unchanged from 0001327567-21-000014:mdna:6]

[0001327567-21-000040:mdna:7]
[same as prior period, unchanged from 0001327567-21-000014:mdna:7]

[0001327567-21-000040:mdna:8]
[same as prior period, unchanged from 0001327567-21-000014:mdna:8]

[0001327567-21-000040:mdna:9]
[same as prior period, unchanged from 0001327567-21-000014:mdna:9]

[0001327567-21-000040:mdna:10]
We empower enterprises, service providers, and government entities to secure all users, applications, data, networks, clouds and devices with comprehensive visibility and context, continuously across all locations. We deliver cybersecurity products covering a broad range of zero trust use cases, enabling our end-customers to secure their networks, remote and hybrid workforces, branch locations, and public and private clouds, and to advance their Security Operations Centers (“SOC”). We believe our portfolio offers the ability to achieve a zero trust enterprise through advanced security capabilities, while reducing the total cost of ownership for organizations by improving operational efficiency and eliminating the need for siloed point products. We do this with solutions focused on delivering value in five fundamental areas:

[0001327567-21-000040:mdna:11]
Network Security:

[0001327567-21-000040:mdna:12]
•Enabling network security through our ML-Powered Next-Generation Firewalls, available in a number of form factors, including physical, virtual, and containerized appliances, as well as a cloud-delivered service. Network security also

[0001327567-21-000040:mdna:13]
- 21 -

[0001327567-21-000040:mdna:14]
[same as prior period, unchanged from 0001327567-21-000014:mdna:14]

[0001327567-21-000040:mdna:15]
includes our add-on Cloud-Delivered Security Services, such as Threat Prevention, WildFire, URL Filtering, Advanced URL Filtering, DNS Security, IoT Security, GlobalProtect, SD-WAN, Enterprise Data Loss Prevention (“Enterprise DLP”), SaaS Security API and SaaS Security Inline that secure content, applications, users, and devices across our ML-Powered Next-Generation Firewalls, Prisma, and Cortex product lines, to enable best-in-class security across a broad range of applications. Panorama, our network security management solution, available as hardware or virtual machine, can centrally manage all of our firewalls irrespective of their form factor, location, or scale.

[0001327567-21-000040:mdna:16]
Secure Access Service Edge:

[0001327567-21-000040:mdna:17]
•Prisma Access, the industry’s most complete cloud-delivered security platform, together with Prisma SD-WAN, SaaS Security API and SaaS Security Inline, provide a comprehensive Secure Access Service Edge (“SASE”) offering that is used to secure remote workforces and enable the cloud-delivered branch.

[0001327567-21-000040:mdna:18]
[same as prior period, unchanged from 0001327567-21-000014:mdna:16]

[0001327567-21-000040:mdna:19]
•Enabling cloud security through our Prisma security offerings. Prisma Cloud, the industry’s most comprehensive Cloud Native Security Platform (“CNSP”), secures multi- and hybrid-cloud environments and cloud native applications, integrating security across the full deployment lifecycle. VM-Series and CN-Series enforce in-line network security in multi- and hybrid-cloud environments.

[0001327567-21-000040:mdna:20]
[same as prior period, unchanged from 0001327567-21-000014:mdna:18]

[0001327567-21-000040:mdna:21]
•Delivering the next generation of endpoint security, security analytics and security automation solutions through our Cortex portfolio. These include our industry-leading extended detection and response platform Cortex XDR to prevent, detect, and respond to complex cybersecurity attacks, Cortex XSOAR for security orchestration, automation, and response (“SOAR”), Cortex Xpanse for attack surface management (“ASM”) and Cortex Data Lake allowing our customers to collect and analyze large amounts of context-rich data across endpoints, networks, and clouds. These products are delivered as software or SaaS subscriptions.

[0001327567-21-000040:mdna:22]
Threat Intelligence and Security Consulting (Unit 42):

[0001327567-21-000040:mdna:23]
•Enabling security teams with up-to-date threat intelligence and deep cybersecurity expertise before, during and after attacks through our Unit 42 threat research and security consulting team. Unit 42 offers incident response, risk management, board advisory and proactive cybersecurity assessment services.

[0001327567-21-000040:mdna:24]
For the first quarter of fiscal 2022 and 2021, total revenue was $1.2 billion and $946.0 million, respectively, representing year-over-year growth of 31.9%. Our growth reflects the increased adoption of our portfolio, which consists of product, subscriptions, and support. We believe our portfolio will enable us to benefit from recurring revenues as we continue to grow our installed end-customer base. As of October 31, 2021, we had end-customers in over 170 countries. Our end-customers represent a broad range of industries including education, energy, financial services, government entities, healthcare, Internet and media, manufacturing, public sector, and telecommunications, and include almost all of the Fortune 100 companies and a majority of the Global 2000 companies in the world. We maintain a field sales force that works closely with our channel partners in developing sales opportunities. We primarily use a two-tiered, indirect fulfillment model whereby we sell our products, subscriptions, and support to our distributors, which, in turn, sell to our resellers, which then sell to our end-customers.

[0001327567-21-000040:mdna:25]
Our product revenue was $295.5 million, or 23.7% of total revenue, for the first quarter of fiscal 2022, representing year-over-year growth of 24.5%. Product revenue is generated from sales of our appliances, primarily our ML-Powered Next-Generation Firewall, which is available in a number of form factors, including as physical, virtual, and containerized appliances. Our ML-Powered Next-Generation Firewall incorporates our PAN-OS operating system, which provides a consistent set of capabilities across our entire network security product line. Our products are designed for different performance requirements throughout an organization, ranging from our PA-410, which is designed for small organizations and remote or branch offices, to our top-of-the-line PA-7080, which is designed for large-scale data centers and service provider use. The same firewall functionality that is delivered in our physical appliances is also available in our VM-Series virtual firewalls, which secure virtualized and cloud-based computing environments, and in our CN-Series container firewalls, which secure container environments and traffic.

[0001327567-21-000040:mdna:26]
Our subscription and support revenue grew to $951.9 million, or 76.3% of total revenue, for the first quarter of fiscal 2022, representing year-over-year growth of 34.3%. Our subscriptions provide our end-customers with near real-time access to the latest antivirus, intrusion prevention, web filtering, modern malware prevention, data loss prevention, and cloud access security broker capabilities across the network, endpoints, and the cloud. When end-customers purchase our physical, virtual, or container firewall appliances, or certain cloud offerings they typically purchase support in order to receive ongoing security updates, upgrades, bug fixes, and repairs. In addition to the subscriptions purchased with these appliances, end-customers may also purchase other subscriptions on a per-user, per-endpoint, or capacity-based basis. We also offer professional services, including incident response, risk management, and digital forensic services.

[0001327567-21-000040:mdna:27]
We continue to invest in innovation and acquire businesses as we evolve and further extend the capabilities of our portfolio, as we believe that innovation and timely development of new features and products are essential to meeting the needs of our end-

[0001327567-21-000040:mdna:28]
- 22 -

[0001327567-21-000040:mdna:29]
[same as prior period, unchanged from 0001327567-21-000014:mdna:28]

[0001327567-21-000040:mdna:30]
customers and improving our competitive position. For example, in August 2021, we acquired Gamma Networks, Inc. (“Gamma”), which we expect will enhance and expand our data loss prevention offerings.

[0001327567-21-000040:mdna:31]
We believe that the growth of our business and our short-term and long-term success are dependent upon many factors, including our ability to extend our technology leadership, grow our base of end-customers, expand deployment of our portfolio and support offerings within existing end-customers, and focus on end-customer satisfaction. To manage any future growth effectively, we must continue to improve and expand our information technology and financial infrastructure, our operating and administrative systems and controls, and our ability to manage headcount, capital, and processes in an efficient manner. While these areas present significant opportunities for us, they also pose challenges and risks that we must successfully address in order to sustain the growth of our business and improve our operating results. For additional information regarding the challenges and risks we face, see the “Risk Factors” section in Part II, Item 1A of this Quarterly Report on Form 10-Q.

[0001327567-21-000040:mdna:32]
Impact of COVID-19 and Other Macroeconomic Factors on Our Business

[0001327567-21-000040:mdna:33]
We are actively monitoring, evaluating, and responding to developments relating to COVID-19, which has resulted in, and is expected to continue to result in significant global, social, and business disruption. While we instituted a global work-from-home policy beginning in March 2020, which has been modified to provide employees with the choice to work in certain of our offices when and as they feel comfortable, we have not experienced significant disruptions in our work operations. We are conducting business as usual with modifications to employee travel and continue to hold most of the marketing events virtually. We expect these changes will substantially remain in effect in the second quarter of fiscal 2022 and could extend to future quarters. We will continue to actively monitor the situation, including progress made through vaccinations, and we will make further changes to our business operations as may be required by federal, state, or local authorities or that we determine are in the best interests of our employees, end-customers, partners, suppliers, and stockholders. Our focus remains on the safety of our employees, and we strive to protect the health and well-being of the communities in which we operate, in part, by providing technology to our employees, end-customers, and partners to help them do their best work while working remotely.

[0001327567-21-000040:mdna:34]
Although some end-customers adopted Prisma Access as their secure work-from-home solution for the longer term, COVID-19 has affected our end-customers’ spending and could lead them to delay or defer purchasing decisions, and lengthen sales cycles and payment terms, which could materially adversely impact our business, results of operations, and overall financial performance. Also, certain of our end-customers or partners may be or may become credit or cash constrained, making it difficult for them to fulfill their payment obligations to us. The extent of the impact of COVID-19 on our operational and financial performance will depend on developments, including the duration and spread of the virus and its variants, impact on our end-customers’ spending, volume of sales and length of our sales cycles, impact on our partners, suppliers, and employees, actions that may be taken by governmental authorities, and other factors identified in Part II, Item 1A “Risk Factors” in this Form 10-Q. The global supply chain and the semiconductor industry are experiencing challenges. We have seen supply chain challenges increase, including chip and component shortages, which have, in certain cases, caused delays in acquiring chips, components and inventory and have resulted in increased costs as compared to historic levels. We continue to work to minimize the effects from supply chain constraints, however, we have experienced increases in lead time for product deliveries to our end-customers. Given the dynamic nature of these circumstances, the full impact of COVID-19 and other macroeconomic factors on our ongoing business, results of operations and overall financial performance cannot be reasonably estimated at this time.

[0001327567-21-000040:mdna:35]
- 23 -

[0001327567-21-000040:mdna:36]
[same as prior period, unchanged from 0001327567-21-000014:mdna:40]

[0001327567-21-000040:mdna:37]
[same as prior period, unchanged from 0001327567-21-000014:mdna:33]

[0001327567-21-000040:mdna:38]
[same as prior period, unchanged from 0001327567-21-000014:mdna:34]

[0001327567-21-000040:mdna:39]
|  | October 31, 2021 |  | July 31, 2021 |
|  | (in millions) |
| Total deferred revenue | $ | 5,158.2 |  |  | $ | 5,024.0 |  |
| Cash, cash equivalents, and investments | $ | 4,360.2 |  |  | $ | 3,789.4 |  |

[0001327567-21-000040:mdna:40]
|  | Three Months Ended October 31, |  |  |
|  | 2021 |  | 2020 |  |  |  |  |
|  | (dollars in millions) |
| Total revenue | $ | 1,247.4 |  |  | $ | 946.0 |  |  |  |  |  |
| Total revenue year-over-year percentage increase | 31.9 | % |  | 22.6 | % |  |  |  |  |
| Gross margin | 69.5 | % |  | 70.6 | % |  |  |  |  |
| Operating loss | $ | (82.7) |  |  | $ | (44.5) |  |  |  |  |  |
| Operating margin | (6.6) | % |  | (4.7) | % |  |  |  |  |
| Billings | $ | 1,381.6 |  |  | $ | 1,082.8 |  |  |  |  |  |
| Billings year-over-year percentage increase | 27.6 | % |  | 20.7 | % |  |  |  |  |
| Cash flow provided by operating activities | $ | 588.9 |  |  | $ | 534.9 |  |  |  |  |  |
| Free cash flow (non-GAAP) | $ | 554.3 |  |  | $ | 505.3 |  |  |  |  |  |

[0001327567-21-000040:mdna:41]
[same as prior period, unchanged from 0001327567-21-000014:mdna:37]

[0001327567-21-000040:mdna:42]
•Billings. We define billings as total revenue plus the change in total deferred revenue, net of acquired deferred revenue, during the period. We consider billings to be a key metric used by management to manage our business. We believe billings provides investors with an important indicator of the health and visibility of our business because it includes subscription and support revenue, which is recognized ratably over the contractual service period, and product revenue, which is recognized at the time of shipment, provided that all other conditions for revenue recognition have been met. We consider billings to be a useful metric for management and investors, particularly if we continue to experience increased sales of subscriptions and strong renewal rates for subscription and support offerings, and as we monitor our near-term cash flows. While we believe that billings provides useful information to investors and others in understanding and evaluating our operating results in the same manner as our management, it is important to note that other companies, including companies in our industry, may not use billings, may calculate billings differently, may have different billing frequencies, or may use other financial measures to evaluate their performance, all of which could reduce the usefulness of billings as a comparative measure. We calculate billings in the following manner:

[0001327567-21-000040:mdna:43]
|  | Three Months Ended October 31, |  |  |
|  | 2021 |  | 2020 |  |  |  |  |
|  | (in millions) |  |  |
| Billings: |  |  |  |  |  |  |  |
| Total revenue | $ | 1,247.4 |  |  | $ | 946.0 |  |  |  |  |  |
| Add: change in total deferred revenue, net of acquired deferred revenue | 134.2 |  |  | 136.8 |  |  |  |  |  |
| Billings | $ | 1,381.6 |  |  | $ | 1,082.8 |  |  |  |  |  |

[0001327567-21-000040:mdna:44]
[same as prior period, unchanged from 0001327567-21-000014:mdna:43]

[0001327567-21-000040:mdna:45]
- 24 -

[0001327567-21-000040:mdna:46]
[same as prior period, unchanged from 0001327567-21-000014:mdna:47]

[0001327567-21-000040:mdna:47]
•    Free Cash Flow (non-GAAP). We define free cash flow, a non-GAAP financial measure, as cash provided by operating activities less purchases of property, equipment, and other assets. We consider free cash flow to be a profitability and liquidity measure that provides useful information to management and stockholders about the amount of cash generated by the business after necessary capital expenditures. A limitation of the utility of free cash flow as a measure of our financial performance and liquidity is that it does not represent the total increase or decrease in our cash balance for the period. In addition, it is important to note that other companies, including companies in our industry, may not use free cash flow, may calculate free cash flow in a different manner than we do, or may use other financial measures to evaluate their performance, all of which could reduce the usefulness of free cash flow as a comparative measure. A reconciliation of free cash flow to cash flow provided by operating activities, the most directly comparable financial measure calculated and presented in accordance with GAAP, is provided below:

[0001327567-21-000040:mdna:48]
|  | Three Months Ended October 31, |
|  | 2021 |  | 2020 |
|  | (in millions) |
| Free cash flow (non-GAAP): |  |  |  |
| Net cash provided by operating activities | $ | 588.9 |  |  | $ | 534.9 |  |
| Less: purchases of property, equipment, and other assets | 34.6 |  |  | 29.6 |  |
| Free cash flow (non-GAAP) | $ | 554.3 |  |  | $ | 505.3 |  |
| Net cash used in investing activities | $ | (229.9) |  |  | $ | (886.2) |  |
| Net cash provided by (used in) financing activities | $ | 38.7 |  |  | $ | (464.5) |  |

[0001327567-21-000040:mdna:49]
[same as prior period, unchanged from 0001327567-21-000014:mdna:13]

[0001327567-21-000040:mdna:50]
[same as prior period, unchanged from 0001327567-21-000014:mdna:57]

[0001327567-21-000040:mdna:51]
[same as prior period, unchanged from 0001327567-21-000014:mdna:48]

[0001327567-21-000040:mdna:52]
[same as prior period, unchanged from 0001327567-21-000014:mdna:49]

[0001327567-21-000040:mdna:53]
|  | Three Months Ended October 31, |  |  |
|  | 2021 |  | 2020 |  |  |  |  |
|  | Amount |  | % of Revenue |  | Amount |  | % of Revenue |  |  |  |  |  |  |  |  |
|  | (dollars in millions) |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 295.5 |  |  | 23.7 | % |  | $ | 237.3 |  |  | 25.1 | % |  |  |  |  |  |  |  |  |
| Subscription and support | 951.9 |  |  | 76.3 | % |  | 708.7 |  |  | 74.9 | % |  |  |  |  |  |  |  |  |
| Total revenue | 1,247.4 |  |  | 100.0 | % |  | 946.0 |  |  | 100.0 | % |  |  |  |  |  |  |  |  |
| Cost of revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product | 88.9 |  |  | 7.1 | % |  | 62.2 |  |  | 6.6 | % |  |  |  |  |  |  |  |  |
| Subscription and support | 291.7 |  |  | 23.4 | % |  | 215.6 |  |  | 22.8 | % |  |  |  |  |  |  |  |  |
| Total cost of revenue(1) | 380.6 |  |  | 30.5 | % |  | 277.8 |  |  | 29.4 | % |  |  |  |  |  |  |  |  |
| Total gross profit | 866.8 |  |  | 69.5 | % |  | 668.2 |  |  | 70.6 | % |  |  |  |  |  |  |  |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | 339.5 |  |  | 27.2 | % |  | 237.4 |  |  | 25.1 | % |  |  |  |  |  |  |  |  |
| Sales and marketing | 505.9 |  |  | 40.6 | % |  | 388.6 |  |  | 41.0 | % |  |  |  |  |  |  |  |  |
| General and administrative | 104.1 |  |  | 8.3 | % |  | 86.7 |  |  | 9.2 | % |  |  |  |  |  |  |  |  |
| Total operating expenses(1) | 949.5 |  |  | 76.1 | % |  | 712.7 |  |  | 75.3 | % |  |  |  |  |  |  |  |  |
| Operating loss | (82.7) |  |  | (6.6) | % |  | (44.5) |  |  | (4.7) | % |  |  |  |  |  |  |  |  |
| Interest expense | (6.9) |  |  | (0.6) | % |  | (40.2) |  |  | (4.2) | % |  |  |  |  |  |  |  |  |
| Other income (expense), net | (1.6) |  |  | (0.1) | % |  | 2.4 |  |  | 0.2 | % |  |  |  |  |  |  |  |  |
| Loss before income taxes | (91.2) |  |  | (7.3) | % |  | (82.3) |  |  | (8.7) | % |  |  |  |  |  |  |  |  |
| Provision for income taxes | 12.4 |  |  | 1.0 | % |  | 9.9 |  |  | 1.0 | % |  |  |  |  |  |  |  |  |
| Net loss | $ | (103.6) |  |  | (8.3) | % |  | $ | (92.2) |  |  | (9.7) | % |  |  |  |  |  |  |  |  |

[0001327567-21-000040:mdna:54]
[same as prior period, unchanged from 0001327567-21-000014:mdna:51]

[0001327567-21-000040:mdna:55]
[same as prior period, unchanged from 0001327567-21-000014:mdna:52]

[0001327567-21-000040:mdna:56]
|  | Three Months Ended October 31, |  |  |
|  | 2021 |  | 2020 |  |  |  |  |
|  | (in millions) |
| Cost of product revenue | $ | 2.3 |  |  | $ | 1.5 |  |  |  |  |  |
| Cost of subscription and support revenue | 26.7 |  |  | 22.2 |  |  |  |  |  |
| Research and development | 125.6 |  |  | 95.4 |  |  |  |  |  |
| Sales and marketing | 73.3 |  |  | 64.9 |  |  |  |  |  |
| General and administrative | 32.4 |  |  | 28.9 |  |  |  |  |  |
| Total share-based compensation | $ | 260.3 |  |  | $ | 212.9 |  |  |  |  |  |

[0001327567-21-000040:mdna:57]
[same as prior period, unchanged from 0001327567-21-000014:mdna:54]

[0001327567-21-000040:mdna:58]
Our revenue consists of product revenue and subscription and support revenue. Revenue is recognized upon transfer of control of the corresponding promised products and subscriptions and support to our customers in an amount that reflects the consideration we expect to be entitled in exchange for those products and subscriptions and support. We expect our revenue to vary from quarter to quarter based on seasonal and cyclical factors.

[0001327567-21-000040:mdna:59]
[same as prior period, unchanged from 0001327567-21-000014:mdna:27]

[0001327567-21-000040:mdna:60]
[same as prior period, unchanged from 0001327567-21-000014:mdna:72]

[0001327567-21-000040:mdna:61]
[same as prior period, unchanged from 0001327567-21-000014:mdna:58]

[0001327567-21-000040:mdna:62]
Product revenue is derived from sales of our appliances, primarily our ML-Powered Next-Generation Firewall, which is available in a number of form factors, including as physical, virtual, and containerized appliances. Product revenue also includes revenue derived from software licenses of Panorama. Our appliances and software licenses include a broad set of built-in networking and security features and functionalities. We recognize product revenue at the time of hardware shipment or delivery of software license.

[0001327567-21-000040:mdna:63]
|  | Three Months Ended October 31, |  |  |  |  |  |  |  |  |  |  |
|  | 2021 |  | 2020 |  | Change |  |  |  |  |  |  |
|  | Amount |  | Amount |  | Amount |  | % |  |  |  |  |  |  |  |  |
|  | (dollars in millions) |
| Product | $ | 295.5 |  |  | $ | 237.3 |  |  | $ | 58.2 |  |  | 24.5 | % |  |  |  |  |  |  |  |  |

[0001327567-21-000040:mdna:64]
Product revenue for the three months ended October 31, 2021 increased compared to the same period in 2020 primarily due to increased demand for our existing and newly introduced product offerings.

[0001327567-21-000040:mdna:65]
[same as prior period, unchanged from 0001327567-21-000014:mdna:62]

[0001327567-21-000040:mdna:66]
Subscription and support revenue is derived primarily from sales of our subscription and support offerings. Our contractual subscription and support contracts are typically one to five years. We recognize revenue from subscriptions and support over time as the services are performed. As a percentage of total revenue, we expect our subscription and support revenue to vary from quarter to quarter and increase over the long term as we introduce new subscriptions, renew existing subscription and support contracts, and expand our installed end-customer base.

[0001327567-21-000040:mdna:67]
|  | Three Months Ended October 31, |  |  |  |  |  |  |  |  |  |  |
|  | 2021 |  | 2020 |  | Change |  |  |  |  |  |  |
|  | Amount |  | Amount |  | Amount |  | % |  |  |  |  |  |  |  |  |
|  | (dollars in millions) |
| Subscription | $ | 578.8 |  |  | $ | 428.0 |  |  | $ | 150.8 |  |  | 35.2 | % |  |  |  |  |  |  |  |  |
| Support | 373.1 |  |  | 280.7 |  |  | 92.4 |  |  | 32.9 | % |  |  |  |  |  |  |  |  |
| Total subscription and support | $ | 951.9 |  |  | $ | 708.7 |  |  | $ | 243.2 |  |  | 34.3 | % |  |  |  |  |  |  |  |  |

[0001327567-21-000040:mdna:68]
Subscription and support revenue increased for the three months ended October 31, 2021 compared to the same period in 2020. The increase was due to increased demand for our subscription and support offerings from both new and existing end-customers. The mix between subscription revenue and support revenue will fluctuate over time, depending on the introduction of new subscription offerings, renewals of support services, and our ability to increase sales to new and existing end-customers.

[0001327567-21-000040:mdna:69]
[same as prior period, unchanged from 0001327567-21-000014:mdna:66]

[0001327567-21-000040:mdna:70]
|  | Three Months Ended October 31, |  |  |  |  |  |  |  |  |  |  |
|  | 2021 |  | 2020 |  | Change |  |  |  |  |  |  |
|  | Amount |  | Amount |  | Amount |  | % |  |  |  |  |  |  |  |  |
|  | (dollars in millions) |
| Americas | $ | 866.7 |  |  | $ | 666.5 |  |  | $ | 200.2 |  |  | 30.0 | % |  |  |  |  |  |  |  |  |
| EMEA | 233.8 |  |  | 173.4 |  |  | 60.4 |  |  | 34.8 | % |  |  |  |  |  |  |  |  |
| APAC | 146.9 |  |  | 106.1 |  |  | 40.8 |  |  | 38.5 | % |  |  |  |  |  |  |  |  |
| Total revenue | $ | 1,247.4 |  |  | $ | 946.0 |  |  | $ | 301.4 |  |  | 31.9 | % |  |  |  |  |  |  |  |  |

[0001327567-21-000040:mdna:71]
With respect to geographic theaters, the increase in revenue for the three months ended October 31, 2021 compared to the same period in 2020 was driven primarily by the Americas, due to its larger sales force and a larger percentage of our customers being located in the Americas. Revenue from our other geographic theaters, both Europe, the Middle East, and Africa (“EMEA”) and Asia Pacific and Japan (“APAC”), increased for the three months ended October 31, 2021 compared to the same period in 2020 due to continued investment in our global sales force in order to support our growth and increase our customer base in the region.

[0001327567-21-000040:mdna:72]
[same as prior period, unchanged from 0001327567-21-000014:mdna:69]

[0001327567-21-000040:mdna:73]
[same as prior period, unchanged from 0001327567-21-000014:mdna:70]

[0001327567-21-000040:mdna:74]
[same as prior period, unchanged from 0001327567-21-000014:mdna:39]

[0001327567-21-000040:mdna:75]
[same as prior period, unchanged from 0001327567-21-000014:mdna:85]

[0001327567-21-000040:mdna:76]
[same as prior period, unchanged from 0001327567-21-000014:mdna:73]

[0001327567-21-000040:mdna:77]
Cost of product revenue primarily includes costs paid to our manufacturing partners for procuring components and manufacturing our products. Our cost of product revenue also includes personnel costs, which consist of salaries, benefits, bonuses, share-based compensation, and travel and entertainment associated with our operations organization, amortization of intellectual property licenses, product testing costs, shipping and tariff costs, and allocated shared costs. Shared costs consist of certain facilities, depreciation, benefits, recruiting, and information technology costs that we allocate based on headcount. We expect our cost of product revenue to fluctuate with our product revenue.

[0001327567-21-000040:mdna:78]
|  | Three Months Ended October 31, |  |  |  |  |  |  |  |  |  |  |
|  | 2021 |  | 2020 |  | Change |  |  |  |  |  |  |
|  | Amount |  | Amount |  | Amount |  | % |  |  |  |  |  |  |  |  |
|  | (dollars in millions) |
| Cost of product revenue | $ | 88.9 |  |  | $ | 62.2 |  |  | $ | 26.7 |  |  | 42.9 | % |  |  |  |  |  |  |  |  |
| Number of employees at period end | 130 |  |  | 114 |  |  | 16 |  |  | 14.0 | % |  |  |  |  |  |  |  |  |

[0001327567-21-000040:mdna:79]
Cost of product revenue increased for the three months ended October 31, 2021 compared to the same period in 2020, primarily due to an increase in product volume and higher costs related to our new product offerings.

[0001327567-21-000040:mdna:80]
[same as prior period, unchanged from 0001327567-21-000014:mdna:77]

[0001327567-21-000040:mdna:81]
Cost of subscription and support revenue includes personnel costs, which consist of salaries, benefits, bonuses, share-based compensation, and travel and entertainment for our global customer support and technical operations organizations, customer support and repair costs, third-party professional services costs, data center and cloud hosting service costs, amortization of acquired intangible assets and capitalized software development costs, and allocated shared costs. Shared costs consist of certain facilities, depreciation, benefits, recruiting, and information technology costs that we allocate based on headcount. We expect our cost of subscription and support revenue to increase as our installed end-customer base grows and adoption of our cloud-based subscription offerings increases.

[0001327567-21-000040:mdna:82]
|  | Three Months Ended October 31, |  |  |  |  |  |  |  |  |  |  |
|  | 2021 |  | 2020 |  | Change |  |  |  |  |  |  |
|  | Amount |  | Amount |  | Amount |  | % |  |  |  |  |  |  |  |  |
|  | (dollars in millions) |
| Cost of subscription and support revenue | $ | 291.7 |  |  | $ | 215.6 |  |  | $ | 76.1 |  |  | 35.3 | % |  |  |  |  |  |  |  |  |
| Number of employees at period end | 2,321 |  |  | 1,569 |  |  | 752 |  |  | 47.9 | % |  |  |  |  |  |  |  |  |

[0001327567-21-000040:mdna:83]
Cost of subscription and support revenue increased for the three months ended October 31, 2021 compared to the same period in 2020, primarily due to personnel costs, which grew $35.2 million to $122.8 million for the three months ended October 31, 2021 compared to the same period in 2020 primarily due to headcount growth. The remaining increase was primarily due to increased outside service costs for global customer support resulting from the expansions of our customer base and product portfolio, amortization of intangible assets from our acquisitions, and cloud hosting service costs to support our cloud-based subscription offerings.

[0001327567-21-000040:mdna:84]
[same as prior period, unchanged from 0001327567-21-000014:mdna:81]

[0001327567-21-000040:mdna:85]
Gross margin, or gross profit as a percentage of revenue, has been and will continue to be affected by a variety of factors, including the introduction of new products, manufacturing costs, tariff costs, the average sales price of our products, cloud hosting service costs, personnel costs, the mix of products sold, and the mix of revenue between product and subscription and support offerings. For sales of our products, our higher-end firewall products generally have higher gross margins than our lower-end firewall products within each product series. We expect our gross margins to vary over time depending on the factors described above.

[0001327567-21-000040:mdna:86]
|  | Three Months Ended October 31, |  |  |
|  | 2021 |  | 2020 |  |  |  |  |
|  | Amount |  | Gross Margin |  | Amount |  | Gross Margin |  |  |  |  |  |  |  |  |
|  | (dollars in millions) |
| Product | $ | 206.6 |  |  | 69.9 | % |  | $ | 175.1 |  |  | 73.8 | % |  |  |  |  |  |  |  |  |
| Subscription and support | 660.2 |  |  | 69.4 | % |  | 493.1 |  |  | 69.6 | % |  |  |  |  |  |  |  |  |
| Total gross profit | $ | 866.8 |  |  | 69.5 | % |  | $ | 668.2 |  |  | 70.6 | % |  |  |  |  |  |  |  |  |

[0001327567-21-000040:mdna:87]
[same as prior period, unchanged from 0001327567-21-000014:mdna:46]

[0001327567-21-000040:mdna:88]
[same as prior period, unchanged from 0001327567-21-000014:mdna:99]

[0001327567-21-000040:mdna:89]
Product gross margin decreased for the three months ended October 31, 2021 compared to the same period in 2020, primarily due to product mix and higher costs of materials as a result of supply chain constraints.

[0001327567-21-000040:mdna:90]
Subscription and support gross margin decreased for the three months ended October 31, 2021 compared to the same period in 2020 primarily due to higher costs to fulfill professional services arrangements, partially offset by increased efficiency in our cloud hosting usage, which supports our cloud-based subscription offerings.

[0001327567-21-000040:mdna:91]
[same as prior period, unchanged from 0001327567-21-000014:mdna:88]

[0001327567-21-000040:mdna:92]
Our operating expenses consist of research and development, sales and marketing, and general and administrative expenses. Personnel costs are the most significant component of operating expenses and consist of salaries, benefits, bonuses, share-based compensation, travel and entertainment, and with regard to sales and marketing expense, sales commissions. Our operating expenses also include shared costs, which consist of certain facilities, depreciation, benefits, recruiting, and information technology costs that we allocate based on headcount to each department. In response to COVID-19, we instituted a global work-from-home policy, which has been modified to provide employees with the choice to work in certain of our offices when and as they feel comfortable. We also made modifications to employee travel beginning in March 2020, and we continue to hold most of the marketing events virtually. We expect operating expenses generally to increase in absolute dollars and decrease over the long term as a percentage of revenue as we continue to scale our business. As of October 31, 2021, we expect to recognize approximately $2.3 billion of share-based compensation expense over a weighted-average period of approximately 2.8 years, excluding additional share-based compensation expense related to any future grants of share-based awards. Share-based compensation expense is generally recognized on a straight-line basis over the requisite service periods of the awards.

[0001327567-21-000040:mdna:93]
[same as prior period, unchanged from 0001327567-21-000014:mdna:90]

[0001327567-21-000040:mdna:94]
Research and development expense consists primarily of personnel costs. Research and development expense also includes prototype-related expenses and allocated shared costs. We expect research and development expense to increase in absolute dollars as we continue to invest in our future products and services, although our research and development expense may fluctuate as a percentage of total revenue.

[0001327567-21-000040:mdna:95]
|  | Three Months Ended October 31, |  |  |  |  |  |  |  |  |  |  |
|  | 2021 |  | 2020 |  | Change |  |  |  |  |  |  |
|  | Amount |  | Amount |  | Amount |  | % |  |  |  |  |  |  |  |  |
|  | (dollars in millions) |
| Research and development | $ | 339.5 |  |  | $ | 237.4 |  |  | $ | 102.1 |  |  | 43.0 | % |  |  |  |  |  |  |  |  |
| Number of employees at period end | 2,745 |  |  | 1,943 |  |  | 802 |  |  | 41.3 | % |  |  |  |  |  |  |  |  |

[0001327567-21-000040:mdna:96]
Research and development expense increased for the three months ended October 31, 2021 compared to the same period in 2020 primarily due to personnel costs, which grew $78.9 million to $266.9 million. The increase in personnel costs was primarily due to headcount growth. The remaining increase was primarily driven by an increase in allocated shared costs.

[0001327567-21-000040:mdna:97]
[same as prior period, unchanged from 0001327567-21-000014:mdna:94]

[0001327567-21-000040:mdna:98]
Sales and marketing expense consists primarily of personnel costs, including commission expense. Sales and marketing expense also includes costs for market development programs, promotional and other marketing costs, professional services, and allocated shared costs. We continue to strategically invest in headcount and have substantially grown our international sales presence. We expect sales and marketing expense to continue to increase in absolute dollars as we increase the size of our sales and marketing organizations to grow customer base, increase touch points with end-customers and expand our global presence, although our sales and marketing expense may fluctuate as a percentage of total revenue.

[0001327567-21-000040:mdna:99]
|  | Three Months Ended October 31, |  |  |  |  |  |  |  |  |  |  |
|  | 2021 |  | 2020 |  | Change |  |  |  |  |  |  |
|  | Amount |  | Amount |  | Amount |  | % |  |  |  |  |  |  |  |  |
|  | (dollars in millions) |
| Sales and marketing | $ | 505.9 |  |  | $ | 388.6 |  |  | $ | 117.3 |  |  | 30.2 | % |  |  |  |  |  |  |  |  |
| Number of employees at period end | 4,664 |  |  | 3,855 |  | 809 |  |  | 21.0 | % |  |  |  |  |  |  |  |  |

[0001327567-21-000040:mdna:100]
Sales and marketing expense increased for the three months ended October 31, 2021 compared to the same period in 2020, primarily due to personnel costs, which grew $87.7 million to $381.0 million for the three months ended October 31, 2021 compared to the same period in 2020. The increase in personnel costs was largely due to headcount growth. The remaining increase was primarily driven by an increase in costs associated with go-to-market initiatives, including advertising.

[0001327567-21-000040:mdna:101]
[same as prior period, unchanged from 0001327567-21-000014:mdna:56]

[0001327567-21-000040:mdna:102]
[same as prior period, unchanged from 0001327567-21-000014:mdna:114]

[0001327567-21-000040:mdna:103]
[same as prior period, unchanged from 0001327567-21-000014:mdna:101]

[0001327567-21-000040:mdna:104]
General and administrative expense consists primarily of personnel costs and allocated shared costs for our executive, finance, human resources, and legal organizations, and professional services costs, which consist primarily of legal, auditing, accounting, and other consulting costs. General and administrative expense also includes certain non-recurring general expenses. We expect general and administrative expense to increase in absolute dollars due to additional costs associated with accounting, compliance, and insurance, although our general and administrative expense may fluctuate as a percentage of total revenue.

[0001327567-21-000040:mdna:105]
|  | Three Months Ended October 31, |  |  |  |  |  |  |  |  |  |  |
|  | 2021 |  | 2020 |  | Change |  |  |  |  |  |  |
|  | Amount |  | Amount |  | Amount |  | % |  |  |  |  |  |  |  |  |
|  | (dollars in millions) |
| General and administrative | $ | 104.1 |  |  | $ | 86.7 |  |  | $ | 17.4 |  |  | 20.1 | % |  |  |  |  |  |  |  |  |
| Number of employees at period end | 1,238 |  |  | 895 |  |  | 343 |  |  | 38.3 | % |  |  |  |  |  |  |  |  |

[0001327567-21-000040:mdna:106]
General and administrative expense increased for the three months ended October 31, 2021 compared to the same period in 2020 primarily due to personnel costs, which increased $13.9 million to $67.4 million. The increase in personnel costs was primarily due to headcount growth, partially offset by lower share-based compensation related to accelerated vesting of equity awards in connection with acquisitions during the three months ended October 31, 2021.

[0001327567-21-000040:mdna:107]
[same as prior period, unchanged from 0001327567-21-000014:mdna:105]

[0001327567-21-000040:mdna:108]
Interest expense primarily consists of interest expense related to our 0.75% Convertible Senior Notes due 2023 (the “2023 Notes”) and the 0.375% Convertible Senior Notes due 2025 (the “2025 Notes,” and together with “2023 Notes,” the “Notes”).

[0001327567-21-000040:mdna:109]
|  | Three Months Ended October 31, |  |  |  |  |  |  |
|  | 2021 |  | 2020 |  | Change |  |  |  |  |  |  |
|  | Amount |  | Amount |  | Amount |  | % |  |  |  |  |  |  |  |  |
|  | (dollars in millions) |
| Interest expense | $ | 6.9 |  |  | $ | 40.2 |  |  | $ | (33.3) |  |  | (82.8) | % |  |  |  |  |  |  |  |  |

[0001327567-21-000040:mdna:110]
Interest expense decreased for the three months ended October 31, 2021 compared to the same period in 2020 primarily because we no longer recognize interest expense for amortization of the debt discount as a result of the adoption of new debt guidance. Refer to Note 1. Description of Business and Summary of Significant Accounting Policies and Note 9. Debt in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information.

[0001327567-21-000040:mdna:111]
Other Income (Expense), Net

[0001327567-21-000040:mdna:112]
Other income (expense), net includes interest income earned on our cash, cash equivalents, and investments, foreign currency remeasurement gains and losses, and foreign currency transaction gains and losses.

[0001327567-21-000040:mdna:113]
|  | Three Months Ended October 31, |  |  |  |  |  |  |
|  | 2021 |  | 2020 |  | Change |  |  |  |  |  |  |
|  | Amount |  | Amount |  | Amount |  | % |  |  |  |  |  |  |  |  |
|  | (dollars in millions) |
| Other income (expense), net | $ | (1.6) |  |  | $ | 2.4 |  |  | $ | (4.0) |  |  | (166.7) | % |  |  |  |  |  |  |  |  |

[0001327567-21-000040:mdna:114]
The change in other income (expense), net for the three months ended October 31, 2021 compared to the same period in 2020 was primarily due to foreign currency remeasurement and transaction losses for the three months ended October 31, 2021 compared to foreign currency remeasurement and transaction gains for the same period in 2020.

[0001327567-21-000040:mdna:115]
[same as prior period, unchanged from 0001327567-21-000014:mdna:71]

[0001327567-21-000040:mdna:116]
[same as prior period, unchanged from 0001327567-21-000014:mdna:126]

[0001327567-21-000040:mdna:117]
Provision for Income Taxes

[0001327567-21-000040:mdna:118]
Provision for income taxes consists primarily of income taxes in foreign jurisdictions in which we conduct business and withholding taxes. We maintain a full valuation allowance for domestic and certain foreign deferred tax assets, including net operating loss carryforwards and certain domestic tax credits. In prior years, we reorganized our corporate structure and intercompany relationships to more closely align with the international nature of our business activities. Our corporate structure has caused, and may continue to cause, disproportionate relationships between our overall effective tax rate and other jurisdictional measures.

[0001327567-21-000040:mdna:119]
|  | Three Months Ended October 31, |  | Change |  |  |  |  |
|  | 2021 |  | 2020 |  | Amount |  | % |  |  |  |  |  |  |  |  |
|  | (dollars in millions) |
| Provision for income taxes | $ | 12.4 |  |  | $ | 9.9 |  |  | $ | 2.5 |  |  | 25.3 | % |  |  |  |  |  |  |  |  |
| Effective tax rate | (13.6) | % |  | (12.0) | % |  |  |  |  |  |  |  |  |  |  |  |  |

[0001327567-21-000040:mdna:120]
Our income taxes for the three months ended October 31, 2021 and 2020 are primarily due to foreign income taxes in profitable jurisdictions and withholding taxes. Our effective tax rate varied for the three months ended October 31, 2021 compared to the same period in 2020 primarily due to our valuation allowance. Refer to Note 13. Income Taxes in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information.

[0001327567-21-000040:mdna:121]
[same as prior period, unchanged from 0001327567-21-000014:mdna:119]

[0001327567-21-000040:mdna:122]
|  | October 31, 2021 |  | July 31, 2021 |
|  | (in millions) |
| Working capital(1) | $ | (2,305.3) |  |  | $ | (469.4) |  |
| Cash, cash equivalents, and investments: |  |  |  |
| Cash and cash equivalents | $ | 2,272.9 |  |  | $ | 1,874.2 |  |
| Investments | 2,087.3 |  |  | 1,915.2 |  |
| Total cash, cash equivalents, and investments | $ | 4,360.2 |  |  | $ | 3,789.4 |  |

[0001327567-21-000040:mdna:123]
______________

[0001327567-21-000040:mdna:124]
(1)Current liabilities included net carrying amounts of convertible senior notes of $3.7 billion and $1.6 billion as of October 31, 2021 and July 31, 2021, respectively. Refer to Note 9. Debt in Part I, Item 1 of this Quarterly Report on Form 10-Q for information on the Notes.

[0001327567-21-000040:mdna:125]
As of October 31, 2021, our total cash, cash equivalents, and investments of $4.4 billion were held for general corporate purposes, of which approximately $938.4 million was held outside of the United States. As of October 31, 2021, we had no unremitted earnings when evaluating our outside basis difference relating to our U.S. investment in foreign subsidiaries. However, there could be local withholding taxes payable due to various foreign countries if certain lower tier earnings are distributed. Withholding taxes that would be payable upon remittance of these lower tier earnings are not expected to be material.

[0001327567-21-000040:mdna:126]
Debt

[0001327567-21-000040:mdna:127]
In July 2018, we issued the 2023 Notes with an aggregate principal amount of $1.7 billion. In June 2020, we issued the 2025 Notes with an aggregate principal amount of $2.0 billion. The 2023 Notes mature on July 1, 2023 and the 2025 Notes mature on June 1, 2025; however, under certain circumstances, holders may surrender their Notes of a series for conversion prior to the applicable maturity date. Upon conversion of the Notes of a series, we will pay cash equal to the aggregate principal amount of the Notes of such series to be converted, and, at our election, will pay or deliver cash and/or shares of our common stock for the amount of our conversion obligation in excess of the aggregate principal amount of the Notes of such series being converted. The sale price condition for the Notes was met during the fiscal quarter ended October 31, 2021, and as a result, holders may convert their Notes at any time during the fiscal quarter ending January 31, 2022. If all of the holders of the Notes converted their Notes during this period, we would be obligated to settle the $3.7 billion principal amount of the Notes in cash. We believe that our cash provided by operating activities, our existing cash, cash equivalents and investments, and existing sources of and access to financing will be sufficient to meet our anticipated cash needs should the holders choose to convert their Notes during the fiscal quarter ending January 31, 2022. As of October 31, 2021, substantially all of our Notes remained outstanding. Refer to Note 9. Debt in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information on the Notes.

[0001327567-21-000040:mdna:128]
In September 2018, we entered into a credit agreement (the “Credit Agreement”) that provides for a $400.0 million unsecured revolving credit facility (the “Credit Facility”), with an option to increase the amount of the credit facility up to an additional $350.0 million, subject to certain conditions. As of October 31, 2021, there were no amounts outstanding and we were in compliance with all covenants under the Credit Agreement. Refer to Note 9. Debt in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information on the Credit Agreement.

[0001327567-21-000040:mdna:129]
[same as prior period, unchanged from 0001327567-21-000014:mdna:84]

[0001327567-21-000040:mdna:130]
[same as prior period, unchanged from 0001327567-21-000014:mdna:145]

[0001327567-21-000040:mdna:131]
Capital Return

[0001327567-21-000040:mdna:132]
In February 2019, our board of directors authorized a $1.0 billion share repurchase program. In December 2020 and August 2021, our board of directors authorized an additional $700.0 million and $676.1 million increase, respectively, bringing the total authorization under this share repurchase program to $2.4 billion. Repurchases will be funded from available working capital and may be made at management’s discretion from time to time. The expiration date of this repurchase authorization was extended to December 31, 2022, and our repurchase program may be suspended or discontinued at any time. As of October 31, 2021, $1.0 billion remained available for future share repurchases under this repurchase program. Refer to Note 11. Stockholders’ Equity in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information on this repurchase program.

[0001327567-21-000040:mdna:133]
Leases and Other Material Cash Requirements

[0001327567-21-000040:mdna:134]
We have entered into various non-cancelable operating leases primarily for our facilities with original lease periods expiring through the year ending July 31, 2028, with the most significant leases relating to corporate headquarters in Santa Clara, California. As of October 31, 2021, we have total of $363.9 million operating lease obligations recorded on our condensed consolidated balance sheet. During the three months ended October 31, 2021, we entered into an agreement to purchase 4.6 acres of land adjacent to our headquarters for $38.9 million in cash. If consummated, the transaction would be expected to close during our fiscal quarter ending January 31, 2022.

[0001327567-21-000040:mdna:135]
As of October 31, 2021, our purchase obligations including commitments of products and components with our manufacturing partners and component suppliers, as well as minimum or fixed purchase commitments for our use of certain cloud and other services with third-party providers, totaled $1.9 billion. Refer to Note 10. Commitments and Contingencies in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information on these commitments,

[0001327567-21-000040:mdna:136]
Cash Flows

[0001327567-21-000040:mdna:137]
The following table summarizes our cash flows for the three months ended October 31, 2021 and 2020:

[0001327567-21-000040:mdna:138]
|  | Three Months Ended October 31, |
| 2021 |  | 2020 |
|  | (in millions) |
| Net cash provided by operating activities | $ | 588.9 |  |  | $ | 534.9 |  |
| Net cash used in investing activities | (229.9) |  |  | (886.2) |  |
| Net cash provided by (used in) financing activities | 38.7 |  |  | (464.5) |  |
| Net increase (decrease) in cash, cash equivalents, and restricted cash | $ | 397.7 |  |  | $ | (815.8) |  |

[0001327567-21-000040:mdna:139]
Cash from operations could be affected by various risks and uncertainties, including, but not limited to, the effects of COVID-19 and other risks detailed in Part II, Item 1A “Risk Factors” in this Quarterly Report on Form 10-Q. We believe that our cash flow from operations with existing cash and cash equivalents will be sufficient to meet our anticipated cash needs for at least the next 12 months and thereafter for the foreseeable future. Our future capital requirements will depend on many factors including our growth rate, the timing and extent of spending to support development efforts, the expansion of sales and marketing activities, the introduction of new and enhanced products and subscription and support offerings, the costs to acquire or invest in complementary businesses and technologies, the costs to ensure access to adequate manufacturing capacity, the investments in our infrastructure to support the adoption of our cloud-based subscription offerings, the repayment obligations associated with our Notes, the investments in our new corporate headquarters, the continuing market acceptance of our products and subscription and support offerings, and macroeconomic events such as COVID-19. In addition, from time to time we may incur additional tax liability in connection with certain corporate structuring decisions.

[0001327567-21-000040:mdna:140]
[same as prior period, unchanged from 0001327567-21-000014:mdna:130]

[0001327567-21-000040:mdna:141]
[same as prior period, unchanged from 0001327567-21-000014:mdna:131]

[0001327567-21-000040:mdna:142]
Our operating activities have consisted of net losses adjusted for certain non-cash items and changes in assets and liabilities. Our largest source of cash provided by our operations is receipts from our product revenue and subscription and support revenue.

[0001327567-21-000040:mdna:143]
Cash provided by operating activities during the three months ended October 31, 2021 was $588.9 million, an increase of $54.0 million compared to the same period in 2020. The increase was primarily due to growth of our business as reflected by an increase in billings, and an increase in collections during the three months ended October 31, 2021, partially offset by higher cash expenditure to support our business growth.

[0001327567-21-000040:mdna:144]
[same as prior period, unchanged from 0001327567-21-000014:mdna:98]

[0001327567-21-000040:mdna:145]
Table of Content

[0001327567-21-000040:mdna:146]
[same as prior period, unchanged from 0001327567-21-000014:mdna:134]

[0001327567-21-000040:mdna:147]
[same as prior period, unchanged from 0001327567-21-000014:mdna:135]

[0001327567-21-000040:mdna:148]
Cash used in investing activities during the three months ended October 31, 2021 was $229.9 million, a decrease of $656.3 million compared to the same period in 2020. The decrease was primarily due to lower purchases of investments and a decrease in net cash payments for business acquisitions during the three months ended October 31, 2021.

[0001327567-21-000040:mdna:149]
[same as prior period, unchanged from 0001327567-21-000014:mdna:137]

[0001327567-21-000040:mdna:150]
Our financing activities have consisted of cash used to repurchase shares of our common stock, payments for tax withholding obligations of certain employees related to the net share settlement of equity awards, and proceeds from sales of shares through employee equity incentive plans.

[0001327567-21-000040:mdna:151]
Cash provided by financing activities during the three months ended October 31, 2021 was $38.7 million, a change of $503.2 million compared to cash used in financing activities of $464.5 million during the same period in 2020. The change was primarily due to us not repurchasing our common stock during the three months ended October 31, 2021.

[0001327567-21-000040:mdna:152]
[same as prior period, unchanged from 0001327567-21-000014:mdna:146]

[0001327567-21-000040:mdna:153]
Our condensed consolidated financial statements have been prepared in accordance with GAAP. The preparation of these condensed consolidated financial statements requires us to make estimates and assumptions that affect the reported amounts of assets, liabilities, revenue, expenses, and related disclosures. We base our estimates on historical experience and on various other assumptions that we believe are reasonable under the circumstances. We evaluate our estimates and assumptions on an ongoing basis. Actual results could differ materially from those estimates due to risks and uncertainties, including uncertainty in the economic environment due to the global impact of COVID-19. To the extent that there are material differences between these estimates and our actual results, our future financial statements will be affected.

[0001327567-21-000040:mdna:154]
We believe the critical accounting estimates discussed under Item 7, “Management’s Discussion and Analysis of Financial Condition and Results of Operations” in our Annual Report on Form 10-K for the fiscal year ended July 31, 2021 reflect our more significant judgments and estimates used in the preparation of our condensed consolidated financial statements. There have been no significant changes to our critical accounting estimates as filed in such report, except for estimates related to convertible senior notes, which we no longer consider to be a critical accounting policy, due to our adoption of the new debt guidance. Refer to Note 1. Description of Business and Summary of Significant Accounting Policies in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information on our adoption of the new accounting guidance.

[0001327567-21-000040:mdna:155]
[same as prior period, unchanged from 0001327567-21-000014:mdna:149]

[0001327567-21-000040:mdna:156]
For a discussion of the recent accounting pronouncements, refer to Note 1. Description of Business and Summary of Significant Accounting Policies in Part I, Item 1 of this Quarterly Report on Form 10-Q.
