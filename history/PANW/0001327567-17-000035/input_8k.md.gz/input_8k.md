# PANW 8-K — 0001327567-17-000032 filed 2017-11-20

## item codes, every 8-K on or before 2017-11-21

- 2017-11-20 0001327567-17-000032 — 2.02, 5.02, 9.01
- 2017-08-31 0001327567-17-000021 — 2.02, 5.02, 9.01
- 2017-05-31 0001327567-17-000016 — 2.02, 9.01
- 2017-02-28 0001327567-17-000005 — 2.02, 8.01, 9.01
- 2016-12-12 0001193125-16-790757 — 5.07
- 2016-11-21 0001327567-16-000071 — 2.02, 9.01
- 2016-10-24 0001193125-16-745121 — 5.02, 9.01
- 2016-08-30 0001327567-16-000057 — 2.02, 5.03, 8.01, 9.01
- 2016-08-22 0001193125-16-687588 — 5.02, 9.01
- 2016-05-26 0001327567-16-000051 — 2.02, 9.01
- 2016-02-25 0001327567-16-000044 — 2.02, 5.02, 9.01
- 2015-12-14 0001327567-15-000038 — 5.07
- 2015-12-14 0001193125-15-402588 — 1.01, 9.01
- 2015-11-23 0001327567-15-000033 — 2.02, 9.01
- 2015-10-19 0001193125-15-347005 — 1.01, 9.01 — amendment, the index does not say of what
- 2015-09-09 0001327567-15-000022 — 2.02, 9.01
- 2015-08-19 0001193125-15-296115 — 1.01, 2.03
- 2015-06-01 0001193125-15-207786 — 1.01, 2.03
- 2015-05-27 0001327567-15-000015 — 2.02, 9.01
- 2015-03-02 0001327567-15-000006 — 2.02, 9.01
- 2014-12-15 0001327567-14-000046 — 5.07
- 2014-11-24 0001327567-14-000040 — 2.02, 9.01
- 2014-09-22 0001193125-14-348581 — 5.02, 9.01
- 2014-09-09 0001327567-14-000025 — 2.02, 9.01
- 2014-07-01 0001193125-14-257824 — 1.01, 2.03, 3.02, 9.01
- 2014-06-26 0001193125-14-249529 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2014-06-20 0001327567-14-000020 — 9.01 — amendment of 0001193125-14-140511
- 2014-06-04 0001327567-14-000016 — 3.02
- 2014-05-30 0001193125-14-218158 — 2.02 — amendment, the index does not say of what
- 2014-05-28 0001193125-14-215060 — 1.01, 2.02, 3.02, 9.01
- 2014-04-11 0001193125-14-140511 — 2.01, 3.02, 7.01, 9.01
- 2014-03-24 0001193125-14-111318 — 1.01, 3.02, 7.01, 9.01
- 2014-03-13 0001327567-14-000009 — 5.02
- 2014-02-24 0001193125-14-063754 — 2.02, 9.01
- 2013-12-12 0001327567-13-000040 — 5.07
- 2013-11-25 0001327567-13-000033 — 2.02, 9.01
- 2013-09-30 0001193125-13-384966 — 8.01
- 2013-09-09 0001193125-13-361421 — 2.02, 9.01
- 2013-05-30 0001193125-13-241542 — 2.02, 5.02, 9.01
- 2013-03-11 0001193125-13-101082 — 5.02, 9.01
- 2013-02-28 0001193125-13-084193 — 2.02, 9.01
- 2012-12-14 0001193125-12-503335 — 5.07
- 2012-12-06 0001193125-12-493700 — 2.02, 9.01
- 2012-09-24 0001193125-12-401534 — 1.01, 2.03
- 2012-09-20 0001193125-12-398433 — 5.02, 9.01
- 2012-09-10 0001193125-12-386605 — 2.02, 9.01

## late-filing notifications on or before 2017-11-21

- none on or before 2017-11-21

## item 2.02 — earnings release, exhibit 99.1

[0001327567-17-000032:8k_2_02:1]
EX-99.1
3
ex991q118earningsrelease.htm
EXHIBIT 99.1

[0001327567-17-000032:8k_2_02:2]
Exhibit

[0001327567-17-000032:8k_2_02:3]
Exhibit 99.1

[0001327567-17-000032:8k_2_02:4]
Palo Alto Networks Reports Fiscal First Quarter 2018 Financial Results

[0001327567-17-000032:8k_2_02:5]
| • | Fiscal first quarter revenue grows 27 percent year over year to $505.5 million; product revenue grows 14 percent year over year to $186.5 million; and subscription and support revenue grows 36 percent year over year to $319.0 million |

[0001327567-17-000032:8k_2_02:6]
| • | Fiscal first quarter billings grow 15 percent year over year to $596.5 million |

[0001327567-17-000032:8k_2_02:7]
| • | Deferred revenue grows 37 percent year over year to $1.9 billion |

[0001327567-17-000032:8k_2_02:8]
| • | Announces the appointment of Kathy Bonanno as Chief Financial Officer |

[0001327567-17-000032:8k_2_02:9]
SANTA CLARA, Calif. — November 20, 2017 — Palo Alto Networks® (NYSE: PANW), the next-generation security company, today announced financial results for its fiscal first quarter 2018 ended October 31, 2017.

[0001327567-17-000032:8k_2_02:10]
Total revenue for the fiscal first quarter 2018 grew 27 percent year over year to $505.5 million, compared with total revenue of $398.1 million for the fiscal first quarter 2017. GAAP net loss for the fiscal first quarter 2018 was $64.0 million, or $0.70 per diluted share, compared with GAAP net loss of $56.9 million, or $0.63 per diluted share, for the fiscal first quarter 2017.

[0001327567-17-000032:8k_2_02:11]
Non-GAAP net income for the fiscal first quarter 2018 was $69.8 million, or $0.74 per diluted share, compared with non-GAAP net income of $51.2 million, or $0.55 per diluted share, for the fiscal first quarter 2017. A reconciliation between GAAP and non-GAAP information is contained in the tables below.

[0001327567-17-000032:8k_2_02:12]
“I am pleased with our start to fiscal year 2018 as we delivered record first quarter revenue of $505.5 million, growing 27 percent year over year, and added more than 2,500 new customers, bringing the total number of customers we now serve to more than 45,000,” said Mark McLaughlin, chief executive officer of Palo Alto Networks. “We continue to drive disruptive evolutions in a large and growing market by delivering highly automated and orchestrated security capabilities that increase prevention rates and simplify consumption models.”

[0001327567-17-000032:8k_2_02:13]
“Execution of our ‘land and expand’ go-to-market model resulted in strong first quarter performance with very strong new customer acquisition and broad adoption of our Next-Generation Security Platform,” said Steffan Tomlinson, chief financial officer of Palo Alto Networks. “Once again, we grew significantly faster than the market and our competition while delivering record deferred revenue, increasing year-over-year GAAP and non-GAAP operating margins, and generating robust cash flow. We ended the quarter with approximately $2.3 billion in cash, cash equivalents and investments.”

[0001327567-17-000032:8k_2_02:14]
Chief Financial Officer Appointed

[0001327567-17-000032:8k_2_02:15]
This afternoon, the company announced the appointment of Kathy Bonanno as the company’s next chief financial officer. Kathy has held senior finance positions at Palo Alto Networks since 2014 and, most recently, had responsibility for financial planning, treasury, enterprise risk management and facilities. In her 30 years of business experience, she has held a variety of senior finance positions, including at Symantec Corporation and American Airlines. She holds a B.S. in finance from Arizona State University and an MBA from Texas Christian University.

[0001327567-17-000032:8k_2_02:16]
“I am very pleased to welcome Kathy as our next chief financial officer,” said McLaughlin. “With more than three years at Palo Alto Networks and a decade in cybersecurity, she has an intimate knowledge of our company, the industry, and broad expertise across finance disciplines, as well as a proven track record

[0001327567-17-000032:8k_2_02:17]
2

[0001327567-17-000032:8k_2_02:18]
of building world-class organizations. Her knowledge of the company and team helps ensure a seamless transition, and I look forward to continuing to work with Kathy as we drive the next evolution in cybersecurity.”

[0001327567-17-000032:8k_2_02:19]
“I’m excited about the growth potential in front of Palo Alto Networks,” said Bonanno. “As the market disruptor, we have a unique opportunity to continue to take share at scale, while increasing operating leverage. I look forward to continuing to work with our team to realize the company’s potential.”

[0001327567-17-000032:8k_2_02:20]
Recent Highlights

[0001327567-17-000032:8k_2_02:21]
| • | Released Traps version 4.1 – Traps™, our advanced endpoint protection offering, now offers additional features that enable customers to prevent malware and kernel exploit attacks by monitoring for new techniques and ransomware behavior, and upon detection, prevents the attack and resulting encryption of the data. |

[0001327567-17-000032:8k_2_02:22]
| • | Expanded Aperture SaaS security service – Aperture™, our Cloud Access Security Broker offering, now provides application protection for several Amazon® Web Services (AWS®) solutions, including Amazon Elastic Compute Cloud, AWS Identity and Access Management and Amazon Simple Storage Service. These new capabilities enable organizations to achieve even more protection for AWS, as well as address critical cloud security needs. In addition, Aperture support for Office 365® and Google® applications has been enhanced to include cloud-based email services and G Suite Marketplace applications. |

[0001327567-17-000032:8k_2_02:23]
| • | Earned the NSS Labs’ “Recommended” rating in its Next Generation Intrusion Prevention System test – In the NSS Labs 2017 Next Generation Intrusion Prevention System (NGIPS) test, our platform achieved a “Recommended” rating for its block rate, resistance to evasions, and performance. |

[0001327567-17-000032:8k_2_02:24]
| • | Joined forces with Telefónica Business Solutions – Telefónica Business Solutions, a leading provider of a wide range of integrated communication solutions for the B2B market, announced the launch of Clean Pipes 2.0, a software-based security service jointly designed by Telefónica Business Solutions; ElevenPaths, Telefónica’s cybersecurity unit; and Palo Alto Networks. The Palo Alto Networks security platform safely enables all applications and enables Clean Pipes 2.0 to deliver highly automated, preventive protection against cyberthreats at all stages in the attack lifecycle without compromising performance. |

[0001327567-17-000032:8k_2_02:25]
| • | Recognized by Fortune Magazine for innovation – We were recently honored to be named to Fortune® Magazine’s Top 50 Companies Changing the World and Future 50 lists, recognizing the work we are doing to “empower businesses to fend off cyberattacks” with our security platform and the extension thereof to build security applications on top of it. This acknowledgement by Fortune underscores our commitment to innovation and our dedication to improving security outcomes for our customers. |

[0001327567-17-000032:8k_2_02:26]
| • | Opened new Santa Clara, Calif. headquarters – On September 21, we announced the grand opening of our new state-of-the-art LEED Silver U.S. headquarters. The new campus was designed to foster a culture of innovation and teamwork among employees in pursuit of achieving the company’s mission to prevent successful cyberattacks and maintain trust in the digital age. |

[0001327567-17-000032:8k_2_02:27]
Financial Outlook

[0001327567-17-000032:8k_2_02:28]
Palo Alto Networks provides guidance based on current market conditions and expectations.

[0001327567-17-000032:8k_2_02:29]
For the fiscal second quarter 2018, we expect:

[0001327567-17-000032:8k_2_02:30]
| • | Total revenue in the range of $518 to $528 million, representing year-over-year growth between 23 percent and 25 percent. Product revenue in the range of $185 to $188 million, representing year-over-year growth between 10 percent and 11 percent. |

[0001327567-17-000032:8k_2_02:31]
4

[0001327567-17-000032:8k_2_02:32]
| • | Total billings in the range of $640 to $655 million, representing year-over-year growth between 14 percent and 17 percent. |

[0001327567-17-000032:8k_2_02:33]
| • | Diluted non-GAAP net income per share in the range of $0.78 to $0.80 using 94 to 96 million shares. |

[0001327567-17-000032:8k_2_02:34]
For the fiscal year 2018, we expect:

[0001327567-17-000032:8k_2_02:35]
| • | Total revenue in the range of $2.145 to $2.185 billion, representing year-over-year growth between 22 percent and 24 percent. Product revenue in the range of $755 to $770 million, representing year-over-year growth between 6 percent and 9 percent. |

[0001327567-17-000032:8k_2_02:36]
| • | Total billings in the range of $2.650 to $2.710 billion, representing year-over-year growth between 16 percent and 18 percent. |

[0001327567-17-000032:8k_2_02:37]
| • | Diluted non-GAAP net income per share in the range of $3.35 to $3.41 using 96 to 98 million shares. |

[0001327567-17-000032:8k_2_02:38]
Guidance for non-GAAP financial measures excludes share-based compensation related charges including share-based payroll tax expense, acquisition related costs, amortization expense of acquired intangible assets, litigation-related charges including legal settlements, facility exit costs, non-cash interest expense related to our convertible senior notes, foreign currency gains (losses) and income and other tax effects associated with these items, and certain non-recurring expenses. We have not reconciled diluted non-GAAP net income per share guidance to GAAP net income (loss) per diluted share because we do not provide guidance on GAAP net income (loss) and would not be able to present the various reconciling cash and non-cash items between GAAP net income (loss) and non-GAAP net income, including share-based compensation expense, without unreasonable effort. Share-based compensation expense is impacted by the company’s future hiring and retention needs and, to a lesser extent, the future fair market value of the company’s common stock, all of which is difficult to predict and subject to constant change. The

[0001327567-17-000032:8k_2_02:39]
5

[0001327567-17-000032:8k_2_02:40]
actual amounts of such reconciling items will have a significant impact on the company’s GAAP net income (loss) per diluted share.

[0001327567-17-000032:8k_2_02:41]
Conference Call Information

[0001327567-17-000032:8k_2_02:42]
Palo Alto Networks will host a conference call for analysts and investors to discuss its fiscal first quarter 2018 results and outlook for its fiscal second quarter and full fiscal year 2018 today at 4:30 p.m. Eastern time/1:30 p.m. Pacific time. Open to the public, investors may access the call by dialing 1-888-737-3628 or 1-719-325-4793 and using conference ID 2061951. A live audio webcast of the conference call, along with supplemental financial information, will also be accessible from the “Investors” section of our website at investors.paloaltonetworks.com. Following the webcast, an archived version will be available on our website for one year. A telephonic replay of the call will be available three hours after the call, will run for ten days, and may be accessed by dialing 1-888-203-1112 or 1-719-457-0820 and entering the passcode 2061951.

[0001327567-17-000032:8k_2_02:43]
Forward-Looking Statements

[0001327567-17-000032:8k_2_02:44]
This press release contains forward-looking statements that involve risks and uncertainties, including statements regarding our future financial and operating performance, including our financial outlook for the fiscal second quarter and full fiscal year 2018, our expectations regarding the benefits of new subscription offerings and the effectiveness of our offerings to perform as intended, our continued delivery of highly automated and orchestrated security capabilities that increase prevention rates and simplify consumption models, our opportunity to continue to take market share at scale, while increasing  operating leverage, and our plans to use the upfront cash reimbursement received from our landlords against future rental payments. There are a significant number of factors that could cause actual results to differ materially from statements made in this press release, including: our limited operating history; our ability to identify and effectively implement the necessary changes to address execution challenges; risks

[0001327567-17-000032:8k_2_02:45]
associated with managing our rapid growth; organizational changes; the risks associated with new products and subscription and support offerings, including the discovery of software bugs; our ability to attract and retain new customers; delays in the development or release of new subscription offerings, or the failure to timely develop and achieve market acceptance of new products and subscriptions as well as existing products and subscription and support offerings; rapidly evolving technological developments in the market for network security products and subscription and support offerings; length of sales cycles; and general market, political, economic and business conditions.

[0001327567-17-000032:8k_2_02:46]
Additional risks and uncertainties that could affect our financial results are included under the captions “Risk Factors” and “Management’s Discussion and Analysis of Financial Condition and Results of Operations” in our Annual Report on Form 10-K filed with the SEC on September 7, 2017, which is available on our website at investors.paloaltonetworks.com and on the SEC’s website at www.sec.gov. Additional information will also be set forth in other filings that we make with the SEC from time to time. All forward-looking statements in this press release are based on information available to us as of the date hereof, and we do not assume any obligation to update the forward-looking statements provided to reflect events that occur or circumstances that exist after the date on which they were made.

[0001327567-17-000032:8k_2_02:47]
Non-GAAP Financial Measures and Other Key Metrics

[0001327567-17-000032:8k_2_02:48]
Palo Alto Networks has provided in this press release financial information that has not been prepared in accordance with generally accepted accounting principles in the United States (GAAP). The company uses these non-GAAP financial measures and key metrics internally in analyzing its financial results and believes that the use of these non-GAAP financial measures and key metrics is useful to investors as an additional tool to evaluate ongoing operating results and trends, and in comparing the company’s financial results with other companies in its industry, many of which present similar non-GAAP financial measures or key metrics.

[0001327567-17-000032:8k_2_02:49]
7

[0001327567-17-000032:8k_2_02:50]
The presentation of these non-GAAP financial measures and key metrics are not meant to be considered in isolation or as a substitute for comparable GAAP financial measures, and should be read only in conjunction with the company’s consolidated financial statements prepared in accordance with GAAP. A reconciliation of the company’s historical non-GAAP financial measures and key metrics to their most directly comparable GAAP measures has been provided in the financial statement tables included in this press release, and investors are encouraged to review these reconciliations.

[0001327567-17-000032:8k_2_02:51]
Non-GAAP net income and net income per share, diluted. Palo Alto Networks defines non-GAAP net income as net income (loss) plus share-based compensation related charges including share-based payroll tax expense, acquisition related costs, amortization expense of acquired intangible assets, litigation related charges including legal settlements, facility exit costs, non-cash interest expense related to the company’s convertible senior notes, and intellectual property restructuring related charges. The company also excludes from non-GAAP net income the foreign currency gains (losses) and tax effects associated with these items in order to provide a complete picture of the company’s recurring core business operating results. The company defines non-GAAP net income per share, diluted, as non-GAAP net income divided by the weighted average diluted shares outstanding, which includes the potentially dilutive effect of the company’s employee equity incentive plan awards and the company’s convertible senior notes outstanding, after giving effect to the anti-dilutive impact of the company’s note hedge agreements, which reduces the potential economic dilution that otherwise would occur upon conversion of the company’s convertible senior notes. Under GAAP, the anti-dilutive impact of the note hedge is not reflected in diluted shares outstanding. The company believes that excluding these items from non-GAAP net income and non-GAAP net income per share, diluted, provides management and investors with greater visibility into the underlying performance of the company’s core business operating results, meaning its operating

[0001327567-17-000032:8k_2_02:52]
performance excluding these items and, from time to time, other discrete charges that are infrequent in nature, over multiple periods.

[0001327567-17-000032:8k_2_02:53]
Billings. Palo Alto Networks defines billings as total revenue plus the change in total deferred revenue, net of acquired deferred revenue, during the period. The company considers billings to be a key metric used by management to manage the company’s business given the company’s hybrid-SaaS revenue model, and believes billings provides investors with an important indicator of the health and visibility of the company’s business because it includes subscription and support revenue, which is recognized ratably over the contractual service period, and product revenue, which is recognized at the time of shipment, provided that all other revenue recognition criteria have been met. The company considers billings to be a useful metric for management and investors, particularly if sales of subscriptions continue to increase and the company experiences strong renewal rates for subscriptions and support.

[0001327567-17-000032:8k_2_02:54]
Free cash flow. Palo Alto Networks defines free cash flow as cash provided by operating activities less purchases of property, equipment, and other assets. The company considers free cash flow to be a profitability and liquidity measure that provides useful information to management and investors about the amount of cash generated by the business after necessary capital expenditures.

[0001327567-17-000032:8k_2_02:55]
Investors are cautioned that there are a number of limitations associated with the use of non-GAAP financial measures and key metrics as analytical tools. In particular, the billings metric reported by the company includes amounts that have not yet been recognized as revenue, and free cash flow does not represent the total increase or decrease in our cash balance for the period. In addition, many of the adjustments to the company’s GAAP financial measures reflect the exclusion of items that are recurring and will be reflected in the company’s financial results for the foreseeable future, such as share-based compensation, which is an important part of Palo Alto Networks employees’ compensation and impacts their performance. Furthermore, these non-GAAP financial measures are not based on any standardized

[0001327567-17-000032:8k_2_02:56]
9

[0001327567-17-000032:8k_2_02:57]
methodology prescribed by GAAP, and the components that Palo Alto Networks excludes in its calculation of non-GAAP financial measures may differ from the components that its peer companies exclude when they report their non-GAAP results of operations. Palo Alto Networks compensates for these limitations by providing specific information regarding the GAAP amounts excluded from these non-GAAP financial measures. In the future, the company may also exclude non-recurring expenses and other expenses that do not reflect the company’s core business operating results.

[0001327567-17-000032:8k_2_02:58]
About Palo Alto Networks

[0001327567-17-000032:8k_2_02:59]
Palo Alto Networks is the next-generation security company, leading a new era in cybersecurity by safely enabling applications and preventing cyber breaches for tens of thousands of organizations worldwide. Built with an innovative approach and highly differentiated cyberthreat prevention capabilities, our game-changing security platform delivers security far superior to legacy or point products, safely enables daily business operations, and protects an organization’s most valuable assets. Find out more at www.paloaltonetworks.com.

[0001327567-17-000032:8k_2_02:60]
Palo Alto Networks and the Palo Alto Networks logo are trademarks of Palo Alto Networks, Inc. in the United States and in jurisdictions throughout the world. All other trademarks, trade names or service marks used or mentioned herein belong to their respective owners.

[0001327567-17-000032:8k_2_02:61]
Media Contact:

[0001327567-17-000032:8k_2_02:62]
Jennifer Jasper Smith

[0001327567-17-000032:8k_2_02:63]
Head of Corporate Communications

[0001327567-17-000032:8k_2_02:64]
Palo Alto Networks

[0001327567-17-000032:8k_2_02:65]
408-638-3280

[0001327567-17-000032:8k_2_02:66]
jjsmith@paloaltonetworks.com

[0001327567-17-000032:8k_2_02:67]
Investor Relations Contact:

[0001327567-17-000032:8k_2_02:68]
Kelsey Turcotte

[0001327567-17-000032:8k_2_02:69]
Vice President of Investor Relations

[0001327567-17-000032:8k_2_02:70]
Palo Alto Networks

[0001327567-17-000032:8k_2_02:71]
408-753-3872

[0001327567-17-000032:8k_2_02:72]
kturcotte@paloaltonetworks.com

[0001327567-17-000032:8k_2_02:73]
| Palo Alto Networks, Inc. |
| Preliminary Condensed Consolidated Statements of Operations |
| (In millions, except per share data) |
| (Unaudited) |
|  | Three Months Ended October 31, |
|  | 2017 |  | 2016(1) |
| Revenue: |  |  |  |
| Product | $ | 186.5 |  |  | $ | 163.8 |  |
| Subscription and support | 319.0 |  |  | 234.3 |  |
| Total revenue | 505.5 |  |  | 398.1 |  |
| Cost of revenue: |  |  |  |
| Product | 57.6 |  |  | 42.2 |  |
| Subscription and support | 83.8 |  |  | 59.0 |  |
| Total cost of revenue | 141.4 |  |  | 101.2 |  |
| Total gross profit | 364.1 |  |  | 296.9 |  |
| Operating expenses: |  |  |  |
| Research and development | 94.2 |  |  | 84.2 |  |
| Sales and marketing | 258.5 |  |  | 220.1 |  |
| General and administrative | 65.7 |  |  | 41.6 |  |
| Total operating expenses | 418.4 |  |  | 345.9 |  |
| Operating loss | (54.3 | ) |  | (49.0 | ) |
| Interest expense | (6.3 | ) |  | (6.0 | ) |
| Other income, net | 4.8 |  |  | 2.5 |  |
| Loss before income taxes | (55.8 | ) |  | (52.5 | ) |
| Provision for income taxes | 8.2 |  |  | 4.4 |  |
| Net loss | $ | (64.0 | ) |  | $ | (56.9 | ) |
| Net loss per share, basic and diluted | $ | (0.70 | ) |  | $ | (0.63 | ) |
| Weighted-average shares used to compute net loss per share, basic and diluted | 90.9 |  |  | 89.8 |  |

[0001327567-17-000032:8k_2_02:74]
___________

[0001327567-17-000032:8k_2_02:75]
| (1) | Certain amounts have been adjusted due to the Company’s early adoption of new share-based payment accounting guidance in its second quarter of fiscal 2017. |

[0001327567-17-000032:8k_2_02:76]
12

[0001327567-17-000032:8k_2_02:77]
| Palo Alto Networks, Inc. |
| Reconciliation of GAAP to Non-GAAP Financial Measures |
| (In millions, except per share amounts) |
| (Unaudited) |
|  | Three Months Ended |
|  | October 31, |
|  | 2017 |  | 2016(1) |
| GAAP net loss | $ | (64.0 | ) |  | $ | (56.9 | ) |
| Share-based compensation related charges | 128.9 |  |  | 115.6 |  |
| Amortization expense of acquired intangible assets | 2.5 |  |  | 2.1 |  |
| Litigation related charges(2) | 3.1 |  |  | 3.1 |  |
| Facility exit costs(3) | 15.6 |  |  | — |  |
| Non-cash interest expense related to convertible notes | 6.3 |  |  | 6.0 |  |
| Foreign currency (gain) loss associated with non-GAAP adjustments | 0.5 |  |  | (0.2 | ) |
| Income tax and other tax adjustments related to the above | (23.1 | ) |  | (18.5 | ) |
| Non-GAAP net income | $ | 69.8 |  |  | $ | 51.2 |  |
| GAAP net loss per share, diluted | $ | (0.70 | ) |  | $ | (0.63 | ) |
| Share-based compensation related charges | 1.38 |  |  | 1.27 |  |
| Amortization expense of acquired intangible assets | 0.03 |  |  | 0.02 |  |
| Litigation related charges(2) | 0.03 |  |  | 0.03 |  |
| Facility exit costs(3) | 0.17 |  |  | 0.00 |  |
| Non-cash interest expense related to convertible notes | 0.07 |  |  | 0.07 |  |
| Foreign currency (gain) loss associated with non-GAAP adjustments | 0.01 |  |  | 0.00 |  |
| Income tax and other tax adjustments related to the above | (0.25 | ) |  | (0.21 | ) |
| Non-GAAP net income per share, diluted | $ | 0.74 |  |  | $ | 0.55 |  |
| GAAP weighted-average shares used to compute net loss per share, diluted | 90.9 |  |  | 89.8 |  |
| Weighted-average effect of potentially dilutive securities(4) | 2.8 |  |  | 3.9 |  |
| Non-GAAP weighted-average shares used to compute net income per share, diluted | 93.7 |  |  | 93.7 |  |
| Net cash provided by operating activities | $ | 274.1 |  |  | $ | 203.5 |  |
| Less: purchases of property, equipment, and other assets | 32.2 |  |  | 20.9 |  |
| Free cash flow (non-GAAP) | $ | 241.9 |  |  | $ | 182.6 |  |
| Net cash used in investing activities | $ | (52.4 | ) |  | $ | (71.2 | ) |
| Net cash used in financing activities | $ | (123.4 | ) |  | $ | (27.3 | ) |

[0001327567-17-000032:8k_2_02:78]
___________

[0001327567-17-000032:8k_2_02:79]
| (1) | Certain amounts have been adjusted due to the Company’s early adoption of new share-based payment accounting guidance in its second quarter of fiscal 2017. |

[0001327567-17-000032:8k_2_02:80]
| (2) | Consists of the amortization of intellectual property licenses. |

[0001327567-17-000032:8k_2_02:81]
| (3) | Consists of charges related to the relocation of the Company’s corporate headquarters, including a cease-use loss of $15.4 million and accelerated depreciation. |

[0001327567-17-000032:8k_2_02:82]
| (4) | Non-GAAP net income per share, diluted, includes the potentially dilutive effect of employee equity incentive plan awards and convertible senior notes outstanding. In addition, non-GAAP net income per share, diluted, includes the anti-dilutive impact of the Company’s note hedge agreements, which reduced the potentially dilutive effect of the convertible notes by 1.3 million shares and 1.5 million shares for the three months ended October 31, 2017 and October 31, 2016, respectively. |

[0001327567-17-000032:8k_2_02:83]
13

[0001327567-17-000032:8k_2_02:84]
| Palo Alto Networks, Inc. |
| Calculation of Billings |
| (In millions) |
| (Unaudited) |
|  | Three Months Ended October 31, |
|  | 2017 |  | 2016 |
| Total revenue | $ | 505.5 |  |  | $ | 398.1 |  |
| Add: change in total deferred revenue, net of acquired deferred revenue | 91.0 |  |  | 118.8 |  |
| Billings | $ | 596.5 |  |  | $ | 516.9 |  |

[0001327567-17-000032:8k_2_02:85]
14

[0001327567-17-000032:8k_2_02:86]
| Palo Alto Networks, Inc. |
| Preliminary Condensed Consolidated Balance Sheets |
| (In millions) |
| (Unaudited) |
|  | October 31, 2017 |  | July 31, 2017 |
| Assets |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 842.6 |  |  | $ | 744.3 |  |
| Short-term investments | 660.6 |  |  | 630.7 |  |
| Accounts receivable, net | 350.8 |  |  | 432.1 |  |
| Prepaid expenses and other current assets | 185.5 |  |  | 169.2 |  |
| Total current assets | 2,039.5 |  |  | 1,976.3 |  |
| Property and equipment, net | 256.9 |  |  | 211.1 |  |
| Long-term investments | 777.4 |  |  | 789.3 |  |
| Goodwill | 238.8 |  |  | 238.8 |  |
| Intangible assets, net | 51.0 |  |  | 53.7 |  |
| Other assets | 122.9 |  |  | 169.1 |  |
| Total assets | $ | 3,486.5 |  |  | $ | 3,438.3 |  |
| Liabilities, temporary equity, and stockholders’ equity |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 38.8 |  |  | $ | 35.5 |  |
| Accrued compensation | 74.5 |  |  | 117.5 |  |
| Accrued and other liabilities | 80.8 |  |  | 79.9 |  |
| Deferred revenue | 1,017.9 |  |  | 968.4 |  |
| Convertible senior notes, net | 531.0 |  |  | — |  |
| Total current liabilities | 1,743.0 |  |  | 1,201.3 |  |
| Convertible senior notes, net | — |  |  | 524.7 |  |
| Long-term deferred revenue | 846.6 |  |  | 805.1 |  |
| Other long-term liabilities | 192.2 |  |  | 147.6 |  |
| Temporary equity | 39.2 |  |  | — |  |
| Stockholders’ equity: |  |  |  |
| Preferred stock | — |  |  | — |  |
| Common stock and additional paid-in capital | 1,573.2 |  |  | 1,599.7 |  |
| Accumulated other comprehensive loss | (7.0 | ) |  | (3.4 | ) |
| Accumulated deficit | (900.7 | ) |  | (836.7 | ) |
| Total stockholders’ equity | 665.5 |  |  | 759.6 |  |
| Liabilities, temporary equity, and stockholders’ equity | $ | 3,486.5 |  |  | $ | 3,438.3 |  |

[0001327567-17-000032:8k_2_02:87]
15

[0001327567-17-000032:8k_2_02:88]
| Palo Alto Networks, Inc. |
| Preliminary Condensed Consolidated Statements of Cash Flows |
| (In millions) |
| (Unaudited) |
|  | Three Months Ended October 31, |
|  | 2017 |  | 2016(1) |
| Cash flows from operating activities |  |  |  |
| Net loss | $ | (64.0 | ) |  | $ | (56.9 | ) |
| Adjustments to reconcile net loss to net cash provided by operating activities: |  |  |  |
| Share-based compensation for equity based awards | 125.7 |  |  | 113.3 |  |
| Depreciation and amortization | 21.3 |  |  | 13.6 |  |
| Cease-use loss related to facility exit | 15.4 |  |  | — |  |
| Amortization of debt discount and debt issuance costs | 6.3 |  |  | 6.0 |  |
| Amortization of investment premiums, net of accretion of purchase discounts | 0.5 |  |  | 0.7 |  |
| Changes in operating assets and liabilities: |  |  |  |
| Accounts receivable, net | 81.3 |  |  | 2.2 |  |
| Prepaid expenses and other assets | (6.4 | ) |  | 10.1 |  |
| Accounts payable | 4.2 |  |  | 1.8 |  |
| Accrued compensation | (43.0 | ) |  | (14.5 | ) |
| Accrued and other liabilities | 41.8 |  |  | 8.4 |  |
| Deferred revenue | 91.0 |  |  | 118.8 |  |
| Net cash provided by operating activities(2) | 274.1 |  |  | 203.5 |  |
| Cash flows from investing activities |  |  |  |
| Purchases of investments | (226.8 | ) |  | (285.7 | ) |
| Proceeds from maturities of investments | 206.6 |  |  | 235.4 |  |
| Purchases of property, equipment, and other assets | (32.2 | ) |  | (20.9 | ) |
| Net cash used in investing activities | (52.4 | ) |  | (71.2 | ) |
| Cash flows from financing activities |  |  |  |
| Repurchases of common stock | (134.1 | ) |  | (50.0 | ) |
| Proceeds from sales of shares through employee equity incentive plans | 22.1 |  |  | 22.7 |  |
| Payments for taxes related to net share settlement of equity awards | (11.4 | ) |  | — |  |
| Net cash used in financing activities | (123.4 | ) |  | (27.3 | ) |
| Net increase in cash and cash equivalents | 98.3 |  |  | 105.0 |  |
| Cash and cash equivalents - beginning of period | 744.3 |  |  | 734.4 |  |
| Cash and cash equivalents - end of period | $ | 842.6 |  |  | $ | 839.4 |  |
| Non-cash investing and financing activities |  |  |  |
| Property and equipment acquired through lease incentives | $ | 37.8 |  |  | $ | — |  |

[0001327567-17-000032:8k_2_02:89]
___________

[0001327567-17-000032:8k_2_02:90]
| (1) | Certain amounts have been adjusted due to the Company’s early adoption of new share-based payment accounting guidance in its second quarter of fiscal 2017. |

[0001327567-17-000032:8k_2_02:91]
| (2) | Cash provided by operating activities for the three months ended October 31, 2017 includes the receipt of an upfront cash reimbursement of $38.2 million from the Company’s landlords in connection with the exercise of their option to amend the lease payment schedules and eliminate the rent holiday periods under certain of the Company’s lease agreements. The upfront cash reimbursement will be applied against rental payments due in fiscal years 2018 through 2020 under the amended lease agreements. |

[0001327567-17-000032:8k_2_02:92]
16

## item 5.02 — body, verbatim

[0001327567-17-000032:8k_body:1]
Item 5.02 Departure of Directors or Certain Officers; Election of Directors; Appointment of Certain Officers; Compensatory Arrangements of Certain Officers.

[0001327567-17-000032:8k_body:2]
As previously disclosed on the Company’s Current Report on Form 8-K filed on August 31, 2017, Steffan Tomlinson, the Company’s Executive Vice President, Chief Financial Officer, notified the Company of his intention to retire and resign from his position at the Company.

[0001327567-17-000032:8k_body:3]
On November 17, 2017, the Board of Directors (the “Board”) of the Company appointed Kathleen Bonanno, age 55, to Executive Vice President, Chief Financial Officer, effective as of November 22, 2017.

[0001327567-17-000032:8k_body:4]
Prior to the appointment, Ms. Bonanno served as the Company’s Senior Vice President Finance, from November 2016 to November 2017, and, most recently, had responsibility for financial planning, treasury, enterprise risk management and facilities. From April 2014 when she joined the Company to November 2016, Ms. Bonanno served as Vice President Finance. In her 30 years of business experience she has held a variety of senior finance positions, including at Symantec Corporation, a cybersecurity company, and American Airlines, a major U.S. airline.  Prior to joining the Company, from January 2007 to March 2014, Ms. Bonanno served as Vice President, FP&A, for Symantec Corporation. Ms. Bonanno holds an M.B.A. from Texas Christian University and a B.S. in Finance from Arizona State University.

[0001327567-17-000032:8k_body:5]
On November 17, 2017, in connection with Ms. Bonanno’s appointment, the Company’s Board increased Ms. Bonanno’s annual base salary to $425,000 and provided Ms. Bonanno with the opportunity to earn a target annual cash incentive compensation payment of 60% of her annual base salary, under the Company’s Employee Incentive Compensation Plan for fiscal 2018 and subsequent fiscal periods. On November 17, 2017, the Board also granted Ms. Bonanno (i) an award of restricted stock units (“RSUs”) covering 11,968 shares of the Company’s common stock pursuant to the Company’s 2012 Equity Incentive Plan (the “2012 Plan”) and (ii) an award of restricted stock units with performance-based vesting (“PSUs”) covering a target of 11,968 shares of the Company’s common stock pursuant to the Company’s 2012 Plan. One-sixteenth (1/16) of the RSUs will vest on January 20, 2018 and one-sixteenth (1/16) will vest quarterly thereafter, subject to Ms. Bonanno continuing to be a Service Provider (as defined in the 2012 Plan) through each vesting date. With regard to the PSUs, Ms. Bonanno may potentially earn from 50% to 120% of the PSU target based on the achievement, if any, of certain pre-established Company performance criteria for fiscal 2018. The actual PSUs earned shall be determined by the Compensation Committee of the Company’s Board following the fiscal 2018 performance period. If earned, vesting of the PSUs shall become time-based such that twenty-five percent (25%) of the eligible PSUs will vest on October 20, 2018, and one-sixteenth (1/16) of the PSUs will vest quarterly thereafter, subject to Ms. Bonanno continuing to be a Service Provider through each vesting date.

[0001327567-17-000032:8k_body:6]
In the event of an involuntary termination of employment (a termination of employment by the Company without “cause” or a termination of employment for “good reason”) within 12 months following a “change in control,” provided that Ms. Bonanno executes an appropriate release and waiver of claims, Ms. Bonanno would be eligible to receive:

[0001327567-17-000032:8k_body:7]
•

[0001327567-17-000032:8k_body:8]
a lump sum cash payment equal to 12 months of her base salary as in effect as of the date of termination;

[0001327567-17-000032:8k_body:9]
•

[0001327567-17-000032:8k_body:10]
a lump sum cash payment equal to 100% of her target incentive payment for that fiscal year;

[0001327567-17-000032:8k_body:11]
•

[0001327567-17-000032:8k_body:12]
a lump sum cash payment equal to the amount payable for premiums for continued COBRA benefits for a period of 12 months; and

[0001327567-17-000032:8k_body:13]
•

[0001327567-17-000032:8k_body:14]
24 months of accelerated vesting of her then outstanding time-based equity awards.

[0001327567-17-000032:8k_body:15]
Additionally, in the event of an involuntary termination of employment (a termination of employment by us without “cause”), at any time before a “change in control” or more than 24 months following a “change in control,” provided that Ms. Bonanno executes an appropriate release and waiver of claims, Ms. Bonanno would be eligible to receive:

[0001327567-17-000032:8k_body:16]
•

[0001327567-17-000032:8k_body:17]
continued payment of base salary as in effect as of the date of termination for a period of six months; and

[0001327567-17-000032:8k_body:18]
•

[0001327567-17-000032:8k_body:19]
a lump sum cash payment equal to the amount payable for premiums for continued COBRA benefits for a period of six months.

[0001327567-17-000032:8k_body:20]
The foregoing description of Ms. Bonanno’s compensation, terms and conditions of her employment and treatment of Ms. Bonanno upon certain terminations of employment are qualified in its entirety by the full text of Ms. Bonanno’s Offer Letter, which is filed as Exhibit 10.1 to this Current Report on Form 8-K and incorporated herein by reference.

[0001327567-17-000032:8k_body:21]
In addition, Ms. Bonanno has entered into the Company’s standard form of indemnification agreement, a copy of which has been filed as Exhibit 10.1 to the Company’s Registration Statement on Form S-1 (File No. 333-180620) filed with the Securities and Exchange Commission on July 9, 2012.

[0001327567-17-000032:8k_body:22]
There are no arrangements or understandings between Ms. Bonanno and any other persons pursuant to which she was selected as an executive officer. There are no family relationships between Ms. Bonanno and any director or other executive officer. Ms. Bonanno has not had an interest in any transaction since the beginning of the Company’s last fiscal year, or any currently proposed transaction, that requires disclosure pursuant to Item 404(a) of Regulation S-K.
