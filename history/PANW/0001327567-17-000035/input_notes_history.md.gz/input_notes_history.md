# PANW note change history — 0001327567-17-000018 → 0001327567-17-000035


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- added (2017-11-21):
[0001327567-17-000035:note_history:1]
In May 2015 and October 2015, we entered into a total of three lease agreements for approximately 941,000 square feet of corporate office space in Santa Clara, California, which serves as our new corporate headquarters. The leases contain rent holiday periods, scheduled rent increases, lease incentives, and renewal options which allow the lease terms to be extended beyond their expiration dates of July 2028 through July 2046. In September 2017, per the terms of the lease agreements, the landlords exercised their option to amend our lease payment schedules and eliminate our rent holiday periods, which increased our rental payments by $24.4 million, $11.8 million, and $2.0 million for fiscal 2018, 2019, and 2020, respectively. In exchange, we received an upfront cash reimbursement of $38.2 million, which we will apply against the future additional rental payments when due. As amended, rental payments under the three lease agreements are approximately $412.0 million over the lease term.

- added (2017-11-21):
[0001327567-17-000035:note_history:2]
In May 2015, we also entered into a lease agreement for approximately 122,000 square feet of space in Santa Clara, California, to serve as an extension of our previous corporate headquarters. The lease contains scheduled rent increases, lease incentives, and renewal options which allow the lease term to be extended beyond the expiration date of April 2021 through July 2046. Rental payments under the lease agreement are approximately $23.1 million over the lease term.

- added (2017-11-21):
[0001327567-17-000035:note_history:3]
In September 2012, we entered into two lease agreements for a total of approximately 300,000 square feet of space in Santa Clara, California, which served as our previous corporate headquarters through August 2017, when we relocated to our new corporate campus. The leases contain rent holiday periods and two separate five-year options to extend the lease terms beyond their expiration dates of July 2023. Rental payments under these lease agreements are approximately $94.3 million over the lease term. In August 2017, we exited our previous headquarter facilities and relocated to our new corporate campus. As a result, we recognized a cease-use loss of $15.4 million as general administrative expense in our condensed consolidated statements of operations during the three months ended October 31, 2017 and a corresponding liability in our condensed consolidated balance sheets. The cease-use loss of $15.4 million was calculated as the present value of the excess of the remaining lease obligation for the vacated facilities, adjusted for the effects of any deferred items recognized under the leases and related costs, over the estimated sublease rentals that could be reasonably obtained. The amount of the cease-use loss may vary if the timing or amount of estimated cash flows change. During the three months ended October 31, 2017, $1.9 million of the cease-use liability was released through rental payments. As of October 31, 2017, the remaining balance of the cease-use liability was $13.5 million, which is expected to be paid through the end of the lease term in July 2023.

- changed (2017-11-21):
[0001327567-17-000035:note_history:4]
The following table presents details of the aggregate future non-cancelable minimum rental payments under our operating leases as of October 31, 2017 (in millions):
  (was, 2017-06-01, similarity 0.9684):
[0001327567-17-000018:note_history:4]
The following table presents details of the aggregate future non-cancelable minimum rental payments under our operating leases as of April 30, 2017 (in millions):

- added (2017-11-21):
[0001327567-17-000035:note_history:5]
Our electronics manufacturing service provider (“EMS provider”) procures components and assembles our products based on our forecasts. These forecasts are based on estimates of demand for our products primarily for the next 12 months, which are in turn based on historical trends and an analysis from our sales and product management organizations, adjusted for overall market conditions. In order to reduce manufacturing lead times and plan for adequate supply, we may issue non-cancelable orders for products and components to our manufacturing partners or component suppliers. As of October 31, 2017, our purchase commitments under such orders were $95.3 million, of which $2.8 million represent commitments through the year ending July 31, 2019, excluding obligations under contracts that we can cancel without a significant penalty.

- changed (2017-11-21):
[0001327567-17-000035:note_history:6]
To the extent there is a reasonable possibility that a loss exceeding amounts already recognized may be incurred and the amount of such additional loss would be material, we will either disclose the estimated additional loss or state that such an estimate cannot be made. As of October 31, 2017, we have not recorded any significant accruals for loss contingencies associated with such legal proceedings, determined that an unfavorable outcome is probable or reasonably possible, or determined that the amount or range of any possible loss is reasonably estimable.
  (was, 2017-06-01, similarity 0.9892):
[0001327567-17-000018:note_history:6]
To the extent there is a reasonable possibility that a loss exceeding amounts already recognized may be incurred and the amount of such additional loss would be material, we will either disclose the estimated additional loss or state that such an estimate cannot be made. As of April 30, 2017, we have not recorded any significant accruals for loss contingencies associated with such legal proceedings, determined that an unfavorable outcome is probable or reasonably possible, or determined that the amount or range of any possible loss is reasonably estimable.

- removed (2017-11-21):
[0001327567-17-000018:note_history:7]
Our independent contract manufacturer procures components and assembles our products based on our forecasts. These forecasts are based on estimates of demand for our products primarily for the next 12 months, which are in turn based on historical trends and an analysis from our sales and product marketing organizations, adjusted for overall market conditions. In order to reduce manufacturing lead times and plan for adequate supply, we may issue non-cancelable orders for components and products to our independent contract manufacturer, original design manufacturers, or component suppliers. As of April 30, 2017, our purchase commitments under such orders were $104.3 million, excluding obligations under contracts that we can cancel without a significant penalty.


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2017-11-21):
[0001327567-17-000035:note_history:8]
Palo Alto Networks, Inc. (the “Company,” “we,” “us,” or “our”), located in Santa Clara, California, was incorporated in March 2005 under the laws of the State of Delaware and commenced operations in April 2005. We offer a next-generation security platform that empowers enterprises, service providers, and government entities to secure their organizations by safely enabling applications running on their networks and by preventing breaches that stem from targeted cyberattacks.
  (was, 2017-06-01, similarity 0.9989):
[0001327567-17-000018:note_history:8]
Palo Alto Networks, Inc. (the “Company,” “we,” “us,” or “our”), located in Santa Clara, California, was incorporated in March 2005 under the laws of the State of Delaware and commenced operations in April 2005. We offer a next-generation security platform that empowers enterprises, service providers, and government entities to secure their organizations by safely enabling applications running on their networks and by preventing breaches that stem from targeted cyber attacks.

- changed (2017-11-21):
[0001327567-17-000035:note_history:9]
The accompanying condensed consolidated financial statements have been prepared in conformity with U.S. generally accepted accounting principles (“GAAP”), consistent in all material respects with those applied in our Annual Report on Form 10-K for the fiscal year ended July 31, 2017, filed with the Securities and Exchange Commission (“SEC”) on September 7, 2017. Our condensed consolidated financial statements include our accounts and our wholly owned subsidiaries. All significant intercompany balances and transactions have been eliminated in consolidation.
  (was, 2017-06-01, similarity 0.9843):
[0001327567-17-000018:note_history:9]
The accompanying condensed consolidated financial statements have been prepared in conformity with U.S. generally accepted accounting principles, consistent in all material respects with those applied in our Annual Report on Form 10-K for the fiscal year ended July 31, 2016, filed with the Securities and Exchange Commission on September 8, 2016. Our condensed consolidated financial statements include our accounts and our wholly owned subsidiaries. All significant intercompany balances and transactions have been eliminated in consolidation.

- changed (2017-11-21):
[0001327567-17-000035:note_history:10]
Our condensed consolidated financial statements are unaudited, but include all adjustments of a normal recurring nature necessary for a fair presentation of our quarterly results. We have made estimates and judgments affecting the amounts reported in our condensed consolidated financial statements and the accompanying notes. The actual results that we experience may differ materially from our estimates. Certain prior period amounts have been adjusted due to our early adoption of new accounting guidance related to share-based payments in our second quarter of fiscal 2017. For more information, refer to “Recently Adopted Accounting Pronouncements” in Note 1. Description of Business and Summary of Significant Accounting Policies included in Part II, Item 8 of our Annual Report on Form 10-K for the fiscal year ended July 31, 2017.
  (was, 2017-06-01, similarity 0.6724):
[0001327567-17-000018:note_history:10]
Our condensed consolidated financial statements are unaudited, but include all adjustments of a normal recurring nature necessary for a fair presentation of our quarterly results. We have made estimates and judgments affecting the amounts reported in our condensed consolidated financial statements and the accompanying notes. The actual results that we experience may differ materially from our estimates. Certain prior period amounts have been adjusted as a result of our voluntary change in accounting policy for sales commissions, our early adoption of new accounting guidance related to share-based payments, and our adoption of new accounting guidance related to debt issuance costs. Refer to “Summary of Significant Accounting Policies” and “Recent Accounting Pronouncements” below for more information.

- changed (2017-11-21):
[0001327567-17-000035:note_history:11]
Our condensed consolidated financial statements should be read in conjunction with the audited consolidated financial statements and related notes in our Annual Report on Form 10-K for the fiscal year ended July 31, 2017.
  (was, 2017-06-01, similarity 0.981):
[0001327567-17-000018:note_history:11]
Our condensed consolidated financial statements should be read in conjunction with the consolidated financial statements and related notes in our Annual Report on Form 10-K for the fiscal year ended July 31, 2016.

- changed (2017-11-21):
[0001327567-17-000035:note_history:12]
There have been no material changes to our significant accounting policies as of and for the three months ended October 31, 2017, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended July 31, 2017.
  (was, 2017-06-01, similarity 0.6706):
[0001327567-17-000018:note_history:12]
There have been no material changes to our significant accounting policies as of and for the nine months ended April 30, 2017, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended July 31, 2016, except for our voluntary change in accounting policy related to sales commissions and our early adoption of the new share-based payment accounting guidance discussed below.

- added (2017-11-21):
[0001327567-17-000035:note_history:13]
Derivatives and Hedging

- added (2017-11-21):
[0001327567-17-000035:note_history:14]
In August 2017, the Financial Accounting Standards Board (“FASB”) issued new authoritative guidance on derivatives and hedging to better align an entity’s risk management activities and financial reporting for hedging relationships through changes to both the designation and measurement guidance for qualifying hedging relationships, and the presentation of hedge results. The standard is effective for us in our first quarter of fiscal 2020 and will be applied on a modified retrospective basis. Early adoption is permitted.   We plan to early adopt the standard in our second quarter of fiscal 2018. We do not expect the adoption of the standard will have a material impact on our condensed consolidated financial statements.

- added (2017-11-21):
[0001327567-17-000035:note_history:15]
Business Combinations - Definition of a Business

- changed (2017-11-21):
[0001327567-17-000035:note_history:16]
In January 2017, the FASB issued authoritative guidance clarifying the definition of a business to assist companies with evaluating whether transactions should be accounted for as acquisitions (or disposals) of assets or businesses. The standard is effective for us in our first quarter of fiscal 2019 and will be applied on a prospective basis. Early adoption is permitted. We do not expect the adoption of the standard will have a material impact on our condensed consolidated financial statements.
  (was, 2017-06-01, similarity 0.9243):
[0001327567-17-000018:note_history:16]
In January 2017, the FASB issued authoritative guidance clarifying the definition of a business to assist companies with evaluating whether transactions should be accounted for as acquisitions (or disposals) of assets or businesses. The standard is effective for us for our first quarter of fiscal 2019 and will be applied on a prospective basis. Early adoption is permitted. We are currently evaluating whether this standard will have a material impact on our condensed consolidated financial statements.

- added (2017-11-21):
[0001327567-17-000035:note_history:17]
Statement of Cash Flows - Restricted Cash

- added (2017-11-21):
[0001327567-17-000035:note_history:18]
In November 2016, the FASB issued authoritative guidance on the presentation of restricted cash or restricted cash equivalents in the statement of cash flows. Under the new standard, restricted cash or restricted cash equivalents should be included with cash and cash equivalents when reconciling the beginning-of-period and end-of-period total amounts shown on the statement of cash flows. The standard is effective for us in our first quarter of fiscal 2019 and will be applied on a retrospective basis. Early adoption is permitted. We do not expect the adoption of the standard will have a material impact on our condensed consolidated financial statements because our restricted cash balance has not been material.

- added (2017-11-21):
[0001327567-17-000035:note_history:19]
Income Taxes - Intra-Entity Asset Transfers

- changed (2017-11-21):
[0001327567-17-000035:note_history:20]
In October 2016, the FASB issued authoritative guidance requiring the recognition of income tax consequences of an intra-entity transfer of an asset, other than inventory, when the transfer occurs. The standard is effective for us in our first quarter of fiscal 2019 and will be applied on a modified retrospective basis. Early adoption is permitted. We plan to adopt the standard in our first quarter of fiscal 2019. The adoption of this standard may have a material impact on our condensed consolidated financial statements, subject to any potential intra-entity transfers of assets (excluding inventory).
  (was, 2017-06-01, similarity 0.6579):
[0001327567-17-000018:note_history:20]
In October 2016, the FASB issued authoritative guidance requiring the recognition of income tax consequences of an intra-entity transfer of an asset, other than inventory, when the transfer occurs. The standard is effective for us for our first quarter of fiscal 2019 and will be applied on a modified retrospective basis. Early adoption is permitted. We are currently evaluating whether this standard will have a material impact on our condensed consolidated financial statements.

- added (2017-11-21):
[0001327567-17-000035:note_history:21]
Statement of Cash Flows - Classification of Certain Cash Receipts and Cash Payments

- changed (2017-11-21):
[0001327567-17-000035:note_history:22]
In August 2016, the FASB issued new authoritative guidance addressing eight specific cash flow issues with the objective of reducing the existing diversity in practice in how certain transactions are presented and classified in the statement of cash flows. The standard is effective for us in our first quarter of fiscal 2019 and will be applied on a retrospective basis. Early adoption is permitted. We do not expect the adoption of the standard will have a material impact on our condensed consolidated financial statements.
  (was, 2017-06-01, similarity 0.9281):
[0001327567-17-000018:note_history:22]
In August 2016, the FASB issued new authoritative guidance addressing eight specific cash flow issues with the objective of reducing the existing diversity in practice in how certain transactions are presented and classified in the statement of cash flows. The standard is effective for us for our first quarter of fiscal 2019 and will be applied on a retrospective basis. Early adoption is permitted. We are currently evaluating whether this standard will have a material impact on our condensed consolidated financial statements.

- added (2017-11-21):
[0001327567-17-000035:note_history:23]
Financial Instruments - Credit Losses

- changed (2017-11-21):
[0001327567-17-000035:note_history:24]
In June 2016, the FASB issued new authoritative guidance on the accounting for credit losses on most financial assets and certain financial instruments. The standard replaces the existing incurred loss model with an expected credit loss model for financial assets measured at amortized cost, including trade receivables, and requires that credit losses on available-for-sale debt securities be presented as an allowance rather than as a write-down. The standard is effective for us in our first quarter of fiscal 2021 and will be applied on a modified retrospective basis. Early adoption is permitted beginning our first quarter of fiscal 2020. We are currently evaluating whether this standard will have a material impact on our condensed consolidated financial statements.
  (was, 2017-06-01, similarity 0.9967):
[0001327567-17-000018:note_history:24]
In June 2016, the FASB issued new authoritative guidance on the accounting for credit losses on most financial assets and certain financial instruments. The standard replaces the existing incurred loss model with an expected credit loss model for financial assets measured at amortized cost, including trade receivables, and requires that credit losses on available-for-sale debt securities be presented as an allowance rather than as a write-down. The standard is effective for us for our first quarter of fiscal 2021 and will be applied on a modified retrospective basis. Early adoption is permitted beginning our first quarter of fiscal 2020. We are currently evaluating whether this standard will have a material impact on our condensed consolidated financial statements.

- added (2017-11-21):
[0001327567-17-000035:note_history:25]
Leases

- changed (2017-11-21):
[0001327567-17-000035:note_history:26]
In February 2016, the FASB issued new authoritative guidance on lease accounting. Among its provisions, the standard requires lessees to recognize right-of-use assets and lease liabilities on the balance sheet for operating leases and also requires additional qualitative and quantitative disclosures about lease arrangements. The standard is effective for us in our first quarter of fiscal 2020 and will be applied on a modified retrospective basis, with the option to elect certain practical expedients. Early adoption is permitted. We are currently evaluating whether this standard will have a material impact on our condensed consolidated financial statements.
  (was, 2017-06-01, similarity 0.9962):
[0001327567-17-000018:note_history:26]
In February 2016, the FASB issued new authoritative guidance on lease accounting. Among its provisions, the standard requires lessees to recognize right-of-use assets and lease liabilities on the balance sheet for operating leases and also requires additional qualitative and quantitative disclosures about lease arrangements. The standard is effective for us for our first quarter of fiscal 2020 and will be applied on a modified retrospective basis, with the option to elect certain practical expedients. Early adoption is permitted. We are currently evaluating whether this standard will have a material impact on our condensed consolidated financial statements.

- added (2017-11-21):
[0001327567-17-000035:note_history:27]
Revenue Recognition

- added (2017-11-21):
[0001327567-17-000035:note_history:28]
In May 2014, the FASB issued new authoritative guidance on revenue from contracts with customers. The new standard provides principles for recognizing revenue for the transfer of promised goods or services to customers with the consideration to which the entity expects to be entitled in exchange for those goods or services, as well as guidance on the recognition of costs related to obtaining and fulfilling customer contracts. The standard also requires expanded disclosures about the nature, amount, timing, and uncertainty of revenues and cash flows arising from customer contracts, including significant judgments and changes in judgments, and assets recognized from costs incurred to obtain or fulfill a contract. The standard is effective for us in our first quarter of fiscal 2019 using either of two methods: (i) retrospective to each prior reporting period presented with the option to elect certain practical expedients as defined within the guidance (“full retrospective method”); or (ii) retrospective with the cumulative effect of initially applying the guidance recognized at the date of initial application and providing certain additional disclosures as defined per the guidance (“modified retrospective method”).

- added (2017-11-21):
[0001327567-17-000035:note_history:29]
We will adopt the standard in our first quarter of fiscal 2019 using the full retrospective method. However, our ability to apply the full retrospective method is dependent on system readiness and the completion of our analysis of information necessary to restate prior period financial statements.

- added (2017-11-21):
[0001327567-17-000035:note_history:30]
We are continuing to evaluate the impact of the new standard on our accounting policies, processes, internal controls over financial reporting, and system requirements, and have assigned cross-functional internal resources and engaged third-party service providers to assist in our evaluation and system implementation. Furthermore, we have made and will continue to make investments in systems to enable timely and accurate reporting under the new standard.

- added (2017-11-21):
[0001327567-17-000035:note_history:31]
We are also continuing to evaluate the impact the standard will have on our condensed consolidated financial statements, including reviewing the provisions of our customer contracts and identifying performance obligations under the requirements of the new standard, and comparing to our current accounting policies and practices. Although we have not yet determined whether the effect will be material, we believe the new standard will impact our accounting for revenue arrangements in the following areas:

- changed (2017-11-21):
[0001327567-17-000035:note_history:32]
We will continue to assess the new standard along with industry trends and additional interpretive guidance, and may adjust our implementation plan accordingly.
  (was, 2017-06-01, similarity 0.6202):
[0001327567-17-000018:note_history:32]
We will continue to assess the new standard along with industry trends and additional interpretive guidance, and may adjust our implementation plan accordingly. We expect to finalize our adoption method and assessment of the impact that the implementation of this standard will have on our condensed consolidated financial statements by the end of fiscal 2017.

- removed (2017-11-21):
[0001327567-17-000018:note_history:33]
Change in Accounting Policy for Sales Commissions

- removed (2017-11-21):
[0001327567-17-000018:note_history:34]
Effective August 1, 2016, we voluntarily changed our accounting policy for sales commissions that are incremental and directly related to non-cancelable customer sales contracts from recording an expense when incurred to deferral and amortization of the sales commissions over the term of the related contract in proportion to the recognized revenue. We believe this change in accounting policy is preferable as the direct and incremental commission costs are closely related to the associated revenue, and therefore should be deferred and recognized as an expense over the same period that the related revenue is recognized.

- removed (2017-11-21):
[0001327567-17-000018:note_history:35]
Short-term deferred commissions are included in prepaid expenses and other current assets, while long-term deferred commissions are included in other assets in our condensed consolidated balance sheets. The amortization of deferred commissions is included in sales and marketing expense in our condensed consolidated statements of operations.

- removed (2017-11-21):
[0001327567-17-000018:note_history:36]
The adoption of this accounting policy change has been applied retrospectively to all prior periods presented in this Quarterly Report on Form 10-Q, in which the cumulative effect of the change of $71.8 million has been reflected in accumulated deficit as of August 1, 2015, the beginning of the earliest period presented.

- removed (2017-11-21):
[0001327567-17-000018:note_history:37]
The following tables present the changes to financial statement line items as a result of the accounting policy change for the periods presented in our condensed consolidated financial statements (in millions, except per share data):

- removed (2017-11-21):
[0001327567-17-000018:note_history:38]
|  | April 30, 2017 |  | July 31, 2016 |
|  | Computed under Prior Method |  | Impact of Commission Adjustment |  | As Reported |  | As Previously Reported |  | Impact of Commission Adjustment |  | As Adjusted |
| Condensed Consolidated Balance Sheets |  |  |  |  |  |  |  |  |  |  |  |
| Prepaid expenses and other current assets | $ | 99.4 |  |  | $ | 59.7 |  |  | $ | 159.1 |  |  | $ | 84.8 |  |  | $ | 54.9 |  |  | $ | 139.7 |  |
| Other assets | 91.7 |  |  | 56.5 |  |  | 148.2 |  |  | 64.6 |  |  | 50.1 |  |  | 114.7 |  |
| Other long-term liabilities | 136.7 |  |  | 0.4 |  |  | 137.1 |  |  | 79.4 |  |  | — |  |  | 79.4 |  |
| Accumulated deficit | $ | (914.3 | ) |  | $ | 115.8 |  |  | $ | (798.5 | ) |  | $ | (726.6 | ) |  | $ | 105.0 |  |  | $ | (621.6 | ) |

- removed (2017-11-21):
[0001327567-17-000018:note_history:39]
|  | Three Months Ended April 30, 2017 |  | Three Months Ended April 30, 2016 |
|  | Computed under Prior Method |  | Impact of Commission Adjustment |  | As Reported |  | As Previously Reported |  | Impact of Commission Adjustment |  | As Adjusted |
| Condensed Consolidated Statements of Operations |  |  |  |  |  |  |  |  |  |  |  |
| Sales and marketing | $ | 234.6 |  |  | $ | (7.7 | ) |  | $ | 226.9 |  |  | $ | 202.0 |  |  | $ | (6.1 | ) |  | $ | 195.9 |  |
| Operating loss | (56.8 | ) |  | 7.7 |  |  | (49.1 | ) |  | (58.6 | ) |  | 6.1 |  |  | (52.5 | ) |
| Provision for income taxes | 7.3 |  |  | 0.4 |  |  | 7.7 |  |  | 6.8 |  |  | — |  |  | 6.8 |  |
| Net loss | $ | (68.2 | ) |  | $ | 7.3 |  |  | $ | (60.9 | ) |  | $ | (70.2 | ) |  | $ | 6.1 |  |  | $ | (64.1 | ) |
| Net loss per share, basic and diluted | $ | (0.75 | ) |  | $ | 0.08 |  |  | $ | (0.67 | ) |  | $ | (0.80 | ) |  | $ | 0.07 |  |  | $ | (0.73 | ) |
| Weighted-average shares used to compute net loss per share, basic and diluted | 91.0 |  |  | — |  |  | 91.0 |  |  | 87.8 |  |  | — |  |  | 87.8 |  |
| Condensed Consolidated Statements of Comprehensive Loss |  |  |  |  |  |  |  |  |  |  |  |
| Net loss | $ | (68.2 | ) |  | $ | 7.3 |  |  | $ | (60.9 | ) |  | $ | (70.2 | ) |  | $ | 6.1 |  |  | $ | (64.1 | ) |
| Comprehensive loss | $ | (67.3 | ) |  | $ | 7.3 |  |  | $ | (60.0 | ) |  | $ | (68.9 | ) |  | $ | 6.1 |  |  | $ | (62.8 | ) |

- removed (2017-11-21):
[0001327567-17-000018:note_history:40]
|  | Nine Months Ended April 30, 2017(1) |  | Nine Months Ended April 30, 2016 |
|  | Computed under Prior Method |  | Impact of Commission Adjustment |  | As Reported |  | As Previously Reported |  | Impact of Commission Adjustment |  | As Adjusted |
| Condensed Consolidated Statements of Operations |  |  |  |  |  |  |  |  |  |  |  |
| Sales and marketing | $ | 684.8 |  |  | $ | (11.1 | ) |  | $ | 673.7 |  |  | $ | 547.9 |  |  | $ | (10.1 | ) |  | $ | 537.8 |  |
| Operating loss | (163.6 | ) |  | 11.1 |  |  | (152.5 | ) |  | (144.7 | ) |  | 10.1 |  |  | (134.6 | ) |
| Provision for income taxes | 14.6 |  |  | 0.3 |  |  | 14.9 |  |  | 15.0 |  |  | — |  |  | 15.0 |  |
| Net loss | $ | (189.2 | ) |  | $ | 10.8 |  |  | $ | (178.4 | ) |  | $ | (171.4 | ) |  | $ | 10.1 |  |  | $ | (161.3 | ) |
| Net loss per share, basic and diluted | $ | (2.09 | ) |  | $ | 0.12 |  |  | $ | (1.97 | ) |  | $ | (1.98 | ) |  | $ | 0.12 |  |  | $ | (1.86 | ) |
| Weighted-average shares used to compute net loss per share, basic and diluted | 90.5 |  |  | — |  |  | 90.5 |  |  | 86.5 |  |  | — |  |  | 86.5 |  |
| Condensed Consolidated Statements of Comprehensive Loss |  |  |  |  |  |  |  |  |  |  |  |
| Net loss | $ | (189.2 | ) |  | $ | 10.8 |  |  | $ | (178.4 | ) |  | $ | (171.4 | ) |  | $ | 10.1 |  |  | $ | (161.3 | ) |
| Comprehensive loss | $ | (194.4 | ) |  | $ | 10.8 |  |  | $ | (183.6 | ) |  | $ | (170.7 | ) |  | $ | 10.1 |  |  | $ | (160.6 | ) |

- removed (2017-11-21):
[0001327567-17-000018:note_history:41]
______________

- removed (2017-11-21):
[0001327567-17-000018:note_history:42]
| (1) | Amounts reflect an adjustment for the three months ended October 31, 2016, due to our early adoption of new share-based payment accounting guidance in our second quarter of fiscal 2017. Refer to “Recent Accounting Pronouncements” below for more information. |

- removed (2017-11-21):
[0001327567-17-000018:note_history:43]
This change in accounting policy does not affect our balance of cash and cash equivalents and, as a result, did not change net cash flows from operating, investing, or financing activities, or materially impact any individual line items presented in our condensed consolidated statement of cash flows for the nine months ended April 30, 2016.

- removed (2017-11-21):
[0001327567-17-000018:note_history:44]
Recent Accounting Pronouncements

- removed (2017-11-21):
[0001327567-17-000018:note_history:45]
Recently Adopted Accounting Pronouncements

- removed (2017-11-21):
[0001327567-17-000018:note_history:46]
In March 2016, the Financial Accounting Standards Board (“FASB”) issued authoritative guidance simplifying several aspects of the accounting for employee share-based payment transactions. The new standard requires us to recognize excess tax benefits or deficiencies as income tax expense or benefit in the period in which they occur, rather than additional paid-in capital, and also requires us to recognize excess tax benefits regardless of whether the benefit reduces taxes payable in the current period. In addition, excess tax benefits should be classified as an operating activity, along with other income tax cash flows, instead of a financing activity in our condensed consolidated statements of cash flows. The standard also allows us to make an accounting policy election to account for forfeitures of share-based payment awards when they occur, rather than estimate expected forfeitures.

- removed (2017-11-21):
[0001327567-17-000018:note_history:47]
We elected to early adopt the standard in our second quarter of fiscal 2017, which required us to reflect any adjustments related to the adoption as of the beginning of the fiscal year. The impact of the adoption on our condensed consolidated financial statements was as follows:

- removed (2017-11-21):
[0001327567-17-000018:note_history:48]
| • | Income tax accounting - We adopted the guidance related to the timing of when excess tax benefits are recognized on a modified retrospective basis. As a result, we recorded the cumulative effect of the change as a $3.5 million reduction to accumulated deficit as of August 1, 2016, to reflect the recognition of excess tax benefits in prior years, with a corresponding adjustment to deferred tax assets and long-term tax liabilities. We adopted the guidance related to the recognition of excess tax benefits and deficiencies as income tax expense or benefit on a prospective basis. |

- removed (2017-11-21):
[0001327567-17-000018:note_history:49]
| • | Cash flow presentation of excess tax benefits - We elected to adopt the guidance related to the presentation of excess tax benefits in our condensed consolidated statements of cash flows on a retrospective basis, which increased net cash provided by operating activities by $0.7 million for the nine months ended April 30, 2016, with a corresponding decrease to net cash provided by financing activities. |

- removed (2017-11-21):
[0001327567-17-000018:note_history:50]
| • | Forfeitures - We elected to account for forfeitures when they occur and adopted this change on a modified retrospective basis. As a result, we recorded the cumulative effect of the change as a $2.0 million increase to accumulated deficit as of August 1, 2016. |

- removed (2017-11-21):
[0001327567-17-000018:note_history:51]
The adoption of the standard also impacted our previously reported results for the three months ended October 31, 2016, as presented in the following tables (in millions, except per share data):

- removed (2017-11-21):
[0001327567-17-000018:note_history:52]
|  | October 31, 2016 |
|  | As Previously Reported |  | Impact of Adoption |  | As Adjusted |
| Condensed Consolidated Balance Sheets |  |  |  |  |  |
| Other assets | $ | 102.0 |  |  | $ | 1.7 |  |  | $ | 103.7 |  |
| Other long-term liabilities | 85.8 |  |  | (5.6 | ) |  | 80.2 |  |
| Common stock and additional paid-in capital | 1,542.2 |  |  | 0.9 |  |  | 1,543.1 |  |
| Accumulated deficit | $ | (683.4 | ) |  | $ | 6.4 |  |  | $ | (677.0 | ) |

- removed (2017-11-21):
[0001327567-17-000018:note_history:53]
|  | Three Months Ended October 31, 2016 |
|  | As Previously Reported |  | Impact of Adoption |  | As Adjusted |
| Condensed Consolidated Statements of Operations |  |  |  |  |  |
| Total cost of revenue(1) | $ | 101.3 |  |  | $ | (0.1 | ) |  | $ | 101.2 |  |
| Total operating expenses(1) | 346.7 |  |  | (0.8 | ) |  | 345.9 |  |
| Provision for income taxes | 8.4 |  |  | (4.0 | ) |  | 4.4 |  |
| Net loss | $ | (61.8 | ) |  | $ | 4.9 |  |  | $ | (56.9 | ) |
| Net loss per share, basic and diluted | $ | (0.69 | ) |  | $ | 0.06 |  |  | $ | (0.63 | ) |
| Weighted-average shares used to compute net loss per share, basic and diluted | 89.8 |  |  | — |  |  | 89.8 |  |
| Condensed Consolidated Statements of Comprehensive Loss |  |  |  |  |  |
| Net loss | $ | (61.8 | ) |  | $ | 4.9 |  |  | $ | (56.9 | ) |
| Comprehensive loss | $ | (64.7 | ) |  | $ | 4.9 |  |  | $ | (59.8 | ) |
| Condensed Consolidated Statements of Cash Flows |  |  |  |  |  |
| Net cash provided by operating activities | $ | 203.3 |  |  | $ | 0.2 |  |  | $ | 203.5 |  |
| Net cash used in financing activities | $ | (27.1 | ) |  | $ | (0.2 | ) |  | $ | (27.3 | ) |

- removed (2017-11-21):
[0001327567-17-000018:note_history:54]
______________

- removed (2017-11-21):
[0001327567-17-000018:note_history:55]
| (1) | Adjustments consist of share-based compensation, which was impacted by our policy election to account for forfeitures when they occur. The impact of adoption on each cost and expense line item within these subtotals was not significant. |

- removed (2017-11-21):
[0001327567-17-000018:note_history:56]
In April 2015, the FASB issued new authoritative guidance on fees paid in a cloud computing arrangement. The standard requires customers in a cloud computing arrangement to evaluate whether the arrangement includes a software license. If the arrangement includes a software license, the customer should account for the software license element of the arrangement consistent with the acquisition of other software licenses. If the arrangement does not include a software license, the customer should account for the arrangement as a service contract. We adopted the standard in our first quarter of fiscal 2017 on a prospective basis. Our adoption of this standard did not have a material impact on our condensed consolidated financial statements.

- removed (2017-11-21):
[0001327567-17-000018:note_history:57]
In April 2015, the FASB issued updated authoritative guidance to simplify the presentation of debt issuance costs. The amended standard requires that debt issuance costs related to a recognized debt liability be presented in the balance sheet as a direct deduction from the carrying amount of the related debt liability, consistent with the presentation of debt discounts, instead of being presented as an asset. We adopted the standard in our first quarter of fiscal 2017 on a retrospective basis, and as a result, we reduced other assets and convertible senior notes, net by $8.0 million on our condensed consolidated balance sheets as of July 31, 2016.

- removed (2017-11-21):
[0001327567-17-000018:note_history:58]
In January 2017, the FASB issued authoritative guidance simplifying the subsequent measurement of goodwill. The standard eliminates Step 2 of the current goodwill impairment test, which requires companies to determine the implied fair value of goodwill when measuring the amount of impairment loss. Under the new standard, goodwill impairment will be measured as the amount by which a reporting unit’s carrying value exceeds its fair value, with the loss limited to the total amount of goodwill allocated to that reporting unit. The standard is effective for us for our first quarter of fiscal 2021 and will be applied on a prospective basis. Early adoption is permitted. We do not expect the adoption of the standard will have a material impact on our condensed consolidated financial statements.

- removed (2017-11-21):
[0001327567-17-000018:note_history:59]
In May 2014, the FASB issued new authoritative guidance on revenue from contracts with customers. The new standard provides principles for recognizing revenue for the transfer of promised goods or services to customers with the consideration to which the entity expects to be entitled in exchange for those goods or services. The standard also requires significantly expanded disclosures about revenue recognition. The FASB subsequently delayed the effective date of the standard by one year and as a result, the standard is now effective for us for our first quarter of fiscal 2019 using either of two methods: (i) retrospective to each prior reporting period presented with the option to elect certain practical expedients as defined within the guidance; or (ii) retrospective with the cumulative effect of initially applying the guidance recognized at the date of initial application and providing certain additional disclosures as defined per the guidance. Early adoption as of the original effective date is permitted. We do not plan to early adopt, and accordingly, we will adopt the new standard in our first quarter of fiscal 2019. We are continuing to evaluate the impact of the new standard on our accounting policies, processes, and system requirements, and have assigned cross-functional internal resources and engaged third-party service providers to assist in our evaluation and system implementation. Furthermore, we have made and will continue to make investments in systems to enable timely and accurate reporting under the new standard. We are also continuing to evaluate adoption methods and the potential impact that the implementation of this standard will have on our condensed consolidated financial statements, but have not yet determined whether the effect will be material. However, we believe this new standard will impact our accounting for revenue arrangements in the following areas:


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: no_prior_note, score: 0.0

- added (2017-11-21):
[0001327567-17-000035:note_history:60]
Description of Business

- added (2017-11-21):
[0001327567-17-000035:note_history:61]
Palo Alto Networks, Inc. (the “Company,” “we,” “us,” or “our”), located in Santa Clara, California, was incorporated in March 2005 under the laws of the State of Delaware and commenced operations in April 2005. We offer a next-generation security platform that empowers enterprises, service providers, and government entities to secure their organizations by safely enabling applications running on their networks and by preventing breaches that stem from targeted cyberattacks.

- added (2017-11-21):
[0001327567-17-000035:note_history:62]
Basis of Presentation and Principles of Consolidation

- added (2017-11-21):
[0001327567-17-000035:note_history:63]
The accompanying condensed consolidated financial statements have been prepared in conformity with U.S. generally accepted accounting principles (“GAAP”), consistent in all material respects with those applied in our Annual Report on Form 10-K for the fiscal year ended July 31, 2017, filed with the Securities and Exchange Commission (“SEC”) on September 7, 2017. Our condensed consolidated financial statements include our accounts and our wholly owned subsidiaries. All significant intercompany balances and transactions have been eliminated in consolidation.

- added (2017-11-21):
[0001327567-17-000035:note_history:64]
Our condensed consolidated financial statements are unaudited, but include all adjustments of a normal recurring nature necessary for a fair presentation of our quarterly results. We have made estimates and judgments affecting the amounts reported in our condensed consolidated financial statements and the accompanying notes. The actual results that we experience may differ materially from our estimates. Certain prior period amounts have been adjusted due to our early adoption of new accounting guidance related to share-based payments in our second quarter of fiscal 2017. For more information, refer to “Recently Adopted Accounting Pronouncements” in Note 1. Description of Business and Summary of Significant Accounting Policies included in Part II, Item 8 of our Annual Report on Form 10-K for the fiscal year ended July 31, 2017.

- added (2017-11-21):
[0001327567-17-000035:note_history:65]
Our condensed consolidated financial statements should be read in conjunction with the audited consolidated financial statements and related notes in our Annual Report on Form 10-K for the fiscal year ended July 31, 2017.

- added (2017-11-21):
[0001327567-17-000035:note_history:66]
Summary of Significant Accounting Policies

- added (2017-11-21):
[0001327567-17-000035:note_history:67]
There have been no material changes to our significant accounting policies as of and for the three months ended October 31, 2017, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended July 31, 2017.


## us-gaap:ConvertibleDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-11-21):
[0001327567-17-000035:note_history:68]
The following table sets forth the components of the Notes as of October 31, 2017 and July 31, 2017 (in millions):
  (was, 2017-06-01, similarity 0.9515):
[0001327567-17-000018:note_history:68]
The following table sets forth the components of the Notes as of April 30, 2017 and July 31, 2016 (in millions):

- added (2017-11-21):
[0001327567-17-000035:note_history:69]
|  | October 31, 2017 |  | July 31, 2017 |
| Liability: |  |  |  |
| Principal | $ | 575.0 |  |  | $ | 575.0 |  |
| Less: debt discount and debt issuance costs, net of amortization | 44.0 |  |  | 50.3 |  |
| Net carrying amount | $ | 531.0 |  |  | $ | 524.7 |  |
| Equity (including temporary equity) | $ | 109.8 |  |  | $ | 109.8 |  |

- removed (2017-11-21):
[0001327567-17-000018:note_history:70]
|  | April 30, 2017 |  | July 31, 2016 |
| Liability: |  |  |  |
| Principal | $ | 575.0 |  |  | $ | 575.0 |  |
| Less: debt discount and debt issuance costs, net of amortization | 56.6 |  |  | 74.8 |  |
| Net carrying amount | $ | 518.4 |  |  | $ | 500.2 |  |
| Equity | $ | 109.8 |  |  | $ | 109.8 |  |


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-11-21):
[0001327567-17-000035:note_history:71]
| • | during any fiscal quarter commencing after the fiscal quarter ending on October 31, 2014 (and only during such fiscal quarter), if the last reported sale price of our common stock for at least 20 trading days (whether or not consecutive) during a period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the conversion price for the Notes on each applicable trading day (the “sale price condition”); |
  (was, 2017-06-01, similarity 0.8565):
[0001327567-17-000018:note_history:71]
| • | if the last reported sale price of our common stock for at least 20 trading days (whether or not consecutive) during a period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the conversion price for the Notes on each applicable trading day (the “sale price condition”); |

- added (2017-11-21):
[0001327567-17-000035:note_history:72]
The sale price condition was met during the fiscal quarter ended October 31, 2017, and as a result, holders may convert their Notes at any time during the fiscal quarter ending January 31, 2018. Accordingly, the net carrying amount of the Notes was reclassified into current liabilities and the portion of the equity component representing the conversion option was reclassified into temporary equity in our condensed consolidated balance sheets as of October 31, 2017. The portion of the equity component classified as temporary equity is measured as the difference between the principal and net carrying amount of the Notes, excluding debt issuance costs. The sale price condition was not met during the fiscal quarter ended July 31, 2017. Since the Notes were not convertible, the net carrying amount of the Notes was classified as a long-term liability and the equity component was included in additional paid-in capital in our condensed consolidated balance sheets as of July 31, 2017.

- changed (2017-11-21):
[0001327567-17-000035:note_history:73]
The following table sets forth the components of the Notes as of October 31, 2017 and July 31, 2017 (in millions):
  (was, 2017-06-01, similarity 0.9515):
[0001327567-17-000018:note_history:73]
The following table sets forth the components of the Notes as of April 30, 2017 and July 31, 2016 (in millions):

- added (2017-11-21):
[0001327567-17-000035:note_history:74]
|  | October 31, 2017 |  | July 31, 2017 |
| Liability: |  |  |  |
| Principal | $ | 575.0 |  |  | $ | 575.0 |  |
| Less: debt discount and debt issuance costs, net of amortization | 44.0 |  |  | 50.3 |  |
| Net carrying amount | $ | 531.0 |  |  | $ | 524.7 |  |
| Equity (including temporary equity) | $ | 109.8 |  |  | $ | 109.8 |  |

- added (2017-11-21):
[0001327567-17-000035:note_history:75]
The total estimated fair value of the Notes was $806.2 million and $747.5 million at October 31, 2017 and July 31, 2017, respectively. The fair value was determined based on the closing trading price per $100 of the Notes as of the last day of trading for the period. We consider the fair value of the Notes at October 31, 2017 and July 31, 2017 to be a Level 2 measurement. The fair value of the Notes is primarily affected by the trading price of our common stock and market interest rates. As of October 31, 2017, the if-converted value of the Notes exceeded its principal amount by $185.7 million.

- added (2017-11-21):
[0001327567-17-000035:note_history:76]
|  | Three Months Ended |
|  | October 31, |
|  | 2017 |  | 2016 |
| Amortization of debt discount | $ | 5.6 |  |  | $ | 5.4 |  |
| Amortization of debt issuance costs | 0.7 |  |  | 0.6 |  |
| Total interest expense recognized | $ | 6.3 |  |  | $ | 6.0 |  |
| Effective interest rate of the liability component | 4.8 | % |  | 4.8 | % |

- added (2017-11-21):
[0001327567-17-000035:note_history:77]
To minimize the impact of potential economic dilution upon conversion of the Notes, we entered into convertible note hedge transactions (the “Note Hedges”) with respect to our common stock concurrent with the issuance of the Notes. The Note Hedges cover up to 5.2 million shares of our common stock at a strike price per share that corresponds to the initial conversion price of the Notes, which are also subject to adjustment, and are exercisable upon conversion of the Notes. The Note Hedges will expire upon maturity of the Notes. The Note Hedges are separate transactions and are not part of the terms of the Notes. Holders of the Notes will not have any rights with respect to the Note Hedges. The shares receivable related to the Note Hedges are excluded from the calculation of diluted earnings per share as they are antidilutive.

- removed (2017-11-21):
[0001327567-17-000018:note_history:78]
The sale price condition was not met during the fiscal quarter ended April 30, 2017. Since the Notes were not convertible, the net carrying amount of the Notes was classified as a long-term liability and the equity component was included in additional paid-in capital in our condensed consolidated balance sheets as of April 30, 2017.

- removed (2017-11-21):
[0001327567-17-000018:note_history:79]
|  | April 30, 2017 |  | July 31, 2016 |
| Liability: |  |  |  |
| Principal | $ | 575.0 |  |  | $ | 575.0 |  |
| Less: debt discount and debt issuance costs, net of amortization | 56.6 |  |  | 74.8 |  |
| Net carrying amount | $ | 518.4 |  |  | $ | 500.2 |  |
| Equity | $ | 109.8 |  |  | $ | 109.8 |  |

- removed (2017-11-21):
[0001327567-17-000018:note_history:80]
The total estimated fair value of the Notes was $671.3 million and $761.9 million at April 30, 2017 and July 31, 2016, respectively. The fair value was determined based on the closing trading price per $100 of the Notes as of the last day of trading for the period. We consider the fair value of the Notes at April 30, 2017 and July 31, 2016 to be a Level 2 measurement. The fair value of the Notes is primarily affected by the trading price of our common stock and market interest rates. As of April 30, 2017, the if-converted value of the Notes exceeded its principal amount by $7.7 million.

- removed (2017-11-21):
[0001327567-17-000018:note_history:81]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 30, |  | April 30, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Amortization of debt discount | $ | 5.5 |  |  | $ | 5.3 |  |  | $ | 16.4 |  |  | $ | 15.7 |  |
| Amortization of debt issuance costs | 0.7 |  |  | 0.6 |  |  | 1.9 |  |  | 1.7 |  |
| Total interest expense recognized | $ | 6.2 |  |  | $ | 5.9 |  |  | $ | 18.3 |  |  | $ | 17.4 |  |
| Effective interest rate of the liability component | 4.8 | % |  | 4.8 | % |  | 4.8 | % |  | 4.8 | % |

- removed (2017-11-21):
[0001327567-17-000018:note_history:82]
To minimize the impact of potential economic dilution upon conversion of the Notes, we entered into convertible note hedge transactions (the “Note Hedges”) with respect to our common stock concurrent with the issuance of the Notes. The Note Hedges cover up to 5.2 million shares of our common stock and are exercisable upon conversion of the Notes. The Note Hedges will expire upon maturity of the Notes. The Note Hedges are separate transactions and are not part of the terms of the Notes. Holders of the Notes will not have any rights with respect to the Note Hedges. The shares receivable related to the Note Hedges are excluded from the calculation of diluted earnings per share as they are antidilutive.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2017-11-21):
[0001327567-17-000035:note_history:83]
Cash Equivalents and Investments

- changed (2017-11-21):
[0001327567-17-000035:note_history:84]
The following tables summarize the amortized cost, unrealized gains and losses, and fair value of our available-for-sale securities as of October 31, 2017 and July 31, 2017 (in millions):
  (was, 2017-06-01, similarity 0.9348):
[0001327567-17-000018:note_history:84]
The following tables summarize the amortized cost, unrealized gains and losses, and fair value of our available-for-sale investments as of April 30, 2017 and July 31, 2016 (in millions):

- added (2017-11-21):
[0001327567-17-000035:note_history:85]
|  | October 31, 2017 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Estimated Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Money market funds | $ | 250.1 |  |  | $ | — |  |  | $ | — |  |  | $ | 250.1 |  |
| U.S. government and agency securities | 5.0 |  |  | — |  |  | — |  |  | 5.0 |  |
| Total cash equivalents | $ | 255.1 |  |  | $ | — |  |  | $ | — |  |  | $ | 255.1 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 5.4 |  |  | $ | — |  |  | $ | — |  |  | $ | 5.4 |  |
| Corporate debt securities | 355.0 |  |  | 0.2 |  |  | (0.8 | ) |  | 354.4 |  |
| U.S. government and agency securities | 1,082.2 |  |  | — |  |  | (4.0 | ) |  | 1,078.2 |  |
| Total investments | $ | 1,442.6 |  |  | $ | 0.2 |  |  | $ | (4.8 | ) |  | $ | 1,438.0 |  |

- added (2017-11-21):
[0001327567-17-000035:note_history:86]
|  | July 31, 2017 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Estimated Fair Value |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 5.4 |  |  | $ | — |  |  | $ | — |  |  | $ | 5.4 |  |
| Corporate debt securities | 346.1 |  |  | 0.3 |  |  | (0.5 | ) |  | 345.9 |  |
| U.S. government and agency securities | 1,071.2 |  |  | 0.1 |  |  | (2.6 | ) |  | 1,068.7 |  |
| Total investments | $ | 1,422.7 |  |  | $ | 0.4 |  |  | $ | (3.1 | ) |  | $ | 1,420.0 |  |

- added (2017-11-21):
[0001327567-17-000035:note_history:87]
Unrealized losses related to these securities are due to interest rate fluctuations as opposed to credit quality. In addition, we do not intend to sell and it is not likely that we would be required to sell these securities before recovery of their amortized cost basis, which may be at maturity. As a result, there were no other-than-temporary impairments for these securities at October 31, 2017 and July 31, 2017.

- changed (2017-11-21):
[0001327567-17-000035:note_history:88]
The following table summarizes the amortized cost and fair value of our available-for-sale securities as of October 31, 2017, by contractual years-to-maturity (in millions):
  (was, 2017-06-01, similarity 0.9309):
[0001327567-17-000018:note_history:88]
The following table summarizes the amortized cost and fair value of our available-for-sale investments as of April 30, 2017, by contractual years-to-maturity (in millions):

- removed (2017-11-21):
[0001327567-17-000018:note_history:89]
Investments

- removed (2017-11-21):
[0001327567-17-000018:note_history:90]
|  | April 30, 2017 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Estimated Fair Value |
| Certificates of deposit | $ | 5.4 |  |  | $ | — |  |  | $ | — |  |  | $ | 5.4 |  |
| Commercial paper | 15.0 |  |  | — |  |  | — |  |  | 15.0 |  |
| Corporate debt securities | 336.6 |  |  | 0.2 |  |  | (0.6 | ) |  | 336.2 |  |
| U.S. government and agency securities | 1,064.2 |  |  | 0.1 |  |  | (2.8 | ) |  | 1,061.5 |  |
| Total | $ | 1,421.2 |  |  | $ | 0.3 |  |  | $ | (3.4 | ) |  | $ | 1,418.1 |  |

- removed (2017-11-21):
[0001327567-17-000018:note_history:91]
|  | July 31, 2016 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Estimated Fair Value |
| Certificates of deposit | $ | 5.4 |  |  | $ | — |  |  | $ | — |  |  | $ | 5.4 |  |
| Commercial paper | 3.0 |  |  | — |  |  | — |  |  | 3.0 |  |
| Corporate debt securities | 286.7 |  |  | 0.8 |  |  | — |  |  | 287.5 |  |
| U.S. government and agency securities | 907.3 |  |  | 0.9 |  |  | (0.1 | ) |  | 908.1 |  |
| Total | $ | 1,202.4 |  |  | $ | 1.7 |  |  | $ | (0.1 | ) |  | $ | 1,204.0 |  |

- removed (2017-11-21):
[0001327567-17-000018:note_history:92]
Unrealized losses related to these investments are due to interest rate fluctuations as opposed to credit quality. In addition, we do not intend to sell and it is not likely that we would be required to sell these investments before recovery of their amortized cost basis, which may be at maturity. As a result, there were no other-than-temporary impairments for these investments at April 30, 2017 and July 31, 2016.
