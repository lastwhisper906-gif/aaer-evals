# PANW MD&A — 0001327567-17-000035


## mdna

[0001327567-17-000035:mdna:1]
[same as prior period, unchanged from 0001327567-17-000018:mdna:1]

[0001327567-17-000035:mdna:2]
[same as prior period, unchanged from 0001327567-17-000018:mdna:2]

[0001327567-17-000035:mdna:3]
[same as prior period, unchanged from 0001327567-17-000018:mdna:3]

[0001327567-17-000035:mdna:4]
[same as prior period, unchanged from 0001327567-17-000018:mdna:4]

[0001327567-17-000035:mdna:5]
- 16 -

[0001327567-17-000035:mdna:6]
| • | Results of Operations. A discussion of the nature and trends in our financial results and an analysis of our financial results comparing the three months ended October 31, 2017 to the three months ended October 31, 2016. |

[0001327567-17-000035:mdna:7]
[same as prior period, unchanged from 0001327567-17-000018:mdna:7]

[0001327567-17-000035:mdna:8]
| • | Contractual Obligations and Commitments. An overview of our contractual obligations, contingent liabilities, commitments, and off-balance sheet arrangements outstanding as of October 31, 2017, including expected payment schedules. |

[0001327567-17-000035:mdna:9]
[same as prior period, unchanged from 0001327567-17-000018:mdna:8]

[0001327567-17-000035:mdna:10]
[same as prior period, unchanged from 0001327567-17-000018:mdna:9]

[0001327567-17-000035:mdna:11]
[same as prior period, unchanged from 0001327567-17-000018:mdna:10]

[0001327567-17-000035:mdna:12]
We have pioneered the next generation of security through our innovative platform that empowers enterprises, service providers, and government entities to secure their organizations by safely enabling applications running on their networks and by preventing breaches that stem from targeted cyberattacks. Our platform uses an innovative traffic classification engine that identifies network traffic by application, user, and content and provides consistent security across the network, endpoint, and cloud. Accordingly, our platform enables our end-customers to maintain the visibility and control needed to protect their valued data and critical control systems while pursuing technology initiatives, like cloud and mobility, that grow their business. We believe our platform offers superior performance compared to legacy approaches and reduces the total cost of ownership for organizations by simplifying their security operations and infrastructure and eliminating the need for multiple, stand-alone security appliances and software products.

[0001327567-17-000035:mdna:13]
Our Next-Generation Security Platform consists of three major elements: our Next-Generation Firewall, our Advanced Endpoint Protection, and our Threat Intelligence Cloud. Our Next-Generation Firewall comes in several physical and cloud-based software form-factors and delivers application, user, and content visibility and control as well as protection against network-based cyberthreats integrated within the firewall through our proprietary hardware and software architecture. Our Advanced Endpoint Protection software prevents cyberattacks that aim to run malicious code or exploit software vulnerabilities on a broad variety of fixed, mobile, and virtual endpoints and servers. Our Threat Intelligence Cloud provides central intelligence capabilities, security for software as a service (“SaaS”) applications, and automated delivery of preventative measures against cyberattacks.

[0001327567-17-000035:mdna:14]
For the first quarter of fiscal 2018 and 2017, total revenue was $505.5 million and $398.1 million, respectively, representing year-over-year growth of 27.0%. Our growth reflects the increased adoption of our hybrid SaaS revenue model, which consists of product, subscriptions, and support. We believe this model will enable us to benefit from recurring revenues as we continue to grow our installed end-customer base. As of October 31, 2017, we had more than 45,000 end-customers in over 150 countries. Our end-customers represent a broad range of industries, including education, energy, financial services, government entities, healthcare, Internet and media, manufacturing, public sector, and telecommunications, and include some of the largest Fortune 100 and Global 2000 companies in the world. We maintain a field sales force that works closely with our channel partners in developing sales opportunities. We use a two-tiered, indirect fulfillment model whereby we sell our products, subscriptions, and support to our distributors, which, in turn, sell to our resellers, which then sell to our end-customers.

[0001327567-17-000035:mdna:15]
Our product revenue was $186.5 million, or 36.9% of total revenue, for the first quarter of fiscal 2018, representing year-over-year growth of 13.9%. Product revenue is generated from sales of our appliances, primarily our Next-Generation Firewall, which is available in physical and virtualized form. Our Next-Generation Firewall incorporates our proprietary PAN-OS operating system, which provides a consistent set of capabilities across our entire product line. Our products are designed for different performance requirements throughout an organization, ranging from our PA-200, which is designed for enterprise remote offices, to our top-of-the-line PA-7080, which is especially suited for very large enterprise deployments and service provider customers. The same firewall functionality that is delivered in our physical appliances is also available in our VM-Series virtual firewalls, which secure virtualized and cloud-based computing environments.

[0001327567-17-000035:mdna:16]
Our subscription and support revenue was $319.0 million, or 63.1% of total revenue, for the first quarter of fiscal 2018, representing year-over-year growth of 36.2%. Our subscriptions provide our end-customers with real-time access to the latest antivirus, intrusion prevention, web filtering, and modern malware prevention capabilities across fixed and mobile devices. When end-customers purchase an appliance, they typically purchase support in order to receive ongoing security updates, upgrades, bug fixes, and repairs. In addition to the subscriptions purchased with our firewall appliances, end-customers may also purchase other subscriptions on a per-user, per-endpoint, or capacity-based basis.

[0001327567-17-000035:mdna:17]
We continue to invest in and extend our platform, and in September 2017, we released two new cloud-based subscription offerings: our GlobalProtect cloud service subscription, which provides our Next Generation Security Platform as a cloud-based

[0001327567-17-000035:mdna:18]
- 17 -

[0001327567-17-000035:mdna:19]
service for remote offices and mobile users; and our Logging Service subscription, which functions as the central cloud-based repository for application data and logs generated by our security offerings, including those of our firewalls and GlobalProtect cloud service subscription, and allows end-customers to collect data without needing to plan for local processing power and storage.

[0001327567-17-000035:mdna:20]
We plan to continue our investment in innovation as we evolve and further extend the capabilities of our platform, as we believe that innovation and timely development of new features and products is essential to meeting the needs of our end-customers and improving our competitive position. For example, in June 2017, we announced the next phase in the evolution of our Next-Generation Security Platform: our Palo Alto Networks Application Framework. Our cloud-based Application Framework will introduce a new SaaS consumption model under which our end-customers will be able to rapidly implement cloud-based security applications developed by us, third-party developers, or other security vendors, without having to deploy or manage additional products. We expect our Application Framework to become generally available in the first half of calendar year 2018, with continuous and ongoing introduction of new security applications.

[0001327567-17-000035:mdna:21]
[same as prior period, unchanged from 0001327567-17-000018:mdna:19]

[0001327567-17-000035:mdna:22]
[same as prior period, unchanged from 0001327567-17-000018:mdna:20]

[0001327567-17-000035:mdna:23]
We monitor the key financial metrics set forth in the tables below to help us evaluate growth trends, establish budgets, measure the effectiveness of our sales and marketing efforts, and assess operational efficiencies. We discuss revenue, gross margin, and the components of operating loss and margin below under “—Results of Operations.” Certain prior period amounts in the tables and discussion that follow have been adjusted due to our early adoption of new share-based payment accounting guidance in our second quarter of fiscal 2017. For more information, refer to “Recently Adopted Accounting Pronouncements” in Note 1. Description of Business and Summary of Significant Accounting Policies included in Part II, Item 8 of our Annual Report on Form 10-K for the fiscal year ended July 31, 2017.

[0001327567-17-000035:mdna:24]
|  | October 31, 2017 |  | July 31, 2017 |
|  | (in millions) |
| Total deferred revenue | $ | 1,864.5 |  |  | $ | 1,773.5 |  |
| Cash, cash equivalents, and investments | $ | 2,280.6 |  |  | $ | 2,164.3 |  |

[0001327567-17-000035:mdna:25]
|  | Three Months Ended October 31, |
|  | 2017 |  | 2016 |
|  | (dollars in millions) |
| Total revenue | $ | 505.5 |  |  | $ | 398.1 |  |
| Total revenue year-over-year percentage increase | 27.0 | % |  | 34.0 | % |
| Gross margin | 72.0 | % |  | 74.6 | % |
| Operating loss | $ | (54.3 | ) |  | $ | (49.0 | ) |
| Operating margin | (10.7 | )% |  | (12.3 | )% |
| Billings | $ | 596.5 |  |  | $ | 516.9 |  |
| Billings year-over-year percentage increase | 15.4 | % |  | 33.2 | % |
| Cash flow provided by operating activities | $ | 274.1 |  |  | $ | 203.5 |  |
| Free cash flow (non-GAAP) | $ | 241.9 |  |  | $ | 182.6 |  |

[0001327567-17-000035:mdna:26]
[same as prior period, unchanged from 0001327567-17-000018:mdna:27]

[0001327567-17-000035:mdna:27]
| • | Billings. We define billings as total revenue plus the change in total deferred revenue, net of acquired deferred revenue, during the period. We consider billings to be a key measure used by management to manage our business given our hybrid |

[0001327567-17-000035:mdna:28]
- 18 -

[0001327567-17-000035:mdna:29]
SaaS revenue model, and believe billings provides investors with an important indicator of the health and visibility of our business because it includes subscription and support revenue, which is recognized ratably over the contractual service period, and product revenue, which is recognized at the time of shipment, provided that all other revenue recognition criteria have been met. We consider billings to be a useful metric for management and investors, particularly if we continue to experience increased sales of subscriptions and strong renewal rates for subscription and support offerings, and as we monitor our near term cash flows. While we believe that billings provides useful information to investors and others in understanding and evaluating our operating results in the same manner as our management, it is important to note that other companies, including companies in our industry, may not use billings, may calculate billings differently, may have different billing frequencies, or may use other financial measures to evaluate their performance, all of which could reduce the usefulness of billings as a comparative measure. We calculate billings in the following manner:

[0001327567-17-000035:mdna:30]
|  | Three Months Ended October 31, |
|  | 2017 |  | 2016 |
|  | (in millions) |
| Billings: |  |  |  |
| Total revenue | $ | 505.5 |  |  | $ | 398.1 |  |
| Add: change in total deferred revenue, net of acquired deferred revenue | 91.0 |  |  | 118.8 |  |
| Billings | $ | 596.5 |  |  | $ | 516.9 |  |

[0001327567-17-000035:mdna:31]
[same as prior period, unchanged from 0001327567-17-000018:mdna:32]

[0001327567-17-000035:mdna:32]
[same as prior period, unchanged from 0001327567-17-000018:mdna:33]

[0001327567-17-000035:mdna:33]
|  | Three Months Ended October 31, |
|  | 2017 |  | 2016 |
|  | (in millions) |
| Free cash flow (non-GAAP): |  |  |  |
| Net cash provided by operating activities | $ | 274.1 |  |  | $ | 203.5 |  |
| Less: purchases of property, equipment, and other assets | 32.2 |  |  | 20.9 |  |
| Free cash flow (non-GAAP) | $ | 241.9 |  |  | $ | 182.6 |  |
| Net cash used in investing activities | $ | (52.4 | ) |  | $ | (71.2 | ) |
| Net cash used in financing activities | $ | (123.4 | ) |  | $ | (27.3 | ) |

[0001327567-17-000035:mdna:34]
- 19 -

[0001327567-17-000035:mdna:35]
[same as prior period, unchanged from 0001327567-17-000018:mdna:38]

[0001327567-17-000035:mdna:36]
[same as prior period, unchanged from 0001327567-17-000018:mdna:39]

[0001327567-17-000035:mdna:37]
|  | Three Months Ended October 31, |
|  | 2017 |  | 2016 |
|  | Amount |  | % of Revenue |  | Amount |  | % of Revenue |
|  | (dollars in millions) |
| Revenue: |  |  |  |  |  |  |  |
| Product | $ | 186.5 |  |  | 36.9 | % |  | $ | 163.8 |  |  | 41.1 | % |
| Subscription and support | 319.0 |  |  | 63.1 | % |  | 234.3 |  |  | 58.9 | % |
| Total revenue | 505.5 |  |  | 100.0 | % |  | 398.1 |  |  | 100.0 | % |
| Cost of revenue: |  |  |  |  |  |  |  |
| Product | 57.6 |  |  | 11.4 | % |  | 42.2 |  |  | 10.6 | % |
| Subscription and support | 83.8 |  |  | 16.6 | % |  | 59.0 |  |  | 14.8 | % |
| Total cost of revenue(1) | 141.4 |  |  | 28.0 | % |  | 101.2 |  |  | 25.4 | % |
| Total gross profit | 364.1 |  |  | 72.0 | % |  | 296.9 |  |  | 74.6 | % |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 94.2 |  |  | 18.6 | % |  | 84.2 |  |  | 21.2 | % |
| Sales and marketing | 258.5 |  |  | 51.1 | % |  | 220.1 |  |  | 55.3 | % |
| General and administrative | 65.7 |  |  | 13.0 | % |  | 41.6 |  |  | 10.4 | % |
| Total operating expenses(1) | 418.4 |  |  | 82.7 | % |  | 345.9 |  |  | 86.9 | % |
| Operating loss | (54.3 | ) |  | (10.7 | )% |  | (49.0 | ) |  | (12.3 | )% |
| Interest expense | (6.3 | ) |  | (1.2 | )% |  | (6.0 | ) |  | (1.5 | )% |
| Other income, net | 4.8 |  |  | 0.9 | % |  | 2.5 |  |  | 0.6 | % |
| Loss before income taxes | (55.8 | ) |  | (11.0 | )% |  | (52.5 | ) |  | (13.2 | )% |
| Provision for income taxes | 8.2 |  |  | 1.7 | % |  | 4.4 |  |  | 1.1 | % |
| Net loss | $ | (64.0 | ) |  | (12.7 | )% |  | $ | (56.9 | ) |  | (14.3 | )% |

[0001327567-17-000035:mdna:38]
[same as prior period, unchanged from 0001327567-17-000018:mdna:24]

[0001327567-17-000035:mdna:39]
| (1) | Includes share-based compensation as follows: |

[0001327567-17-000035:mdna:40]
|  | Three Months Ended October 31, |
|  | 2017 |  | 2016 |
| Cost of product revenue | $ | 1.9 |  |  | $ | 1.7 |  |
| Cost of subscription and support revenue | 15.9 |  |  | 12.3 |  |
| Research and development | 37.5 |  |  | 38.0 |  |
| Sales and marketing | 51.2 |  |  | 43.8 |  |
| General and administrative | 19.2 |  |  | 17.5 |  |
| Total share-based compensation | $ | 125.7 |  |  | $ | 113.3 |  |

[0001327567-17-000035:mdna:41]
[same as prior period, unchanged from 0001327567-17-000018:mdna:6]

[0001327567-17-000035:mdna:42]
[same as prior period, unchanged from 0001327567-17-000018:mdna:47]

[0001327567-17-000035:mdna:43]
[same as prior period, unchanged from 0001327567-17-000018:mdna:48]

[0001327567-17-000035:mdna:44]
[same as prior period, unchanged from 0001327567-17-000018:mdna:49]

[0001327567-17-000035:mdna:45]
Product revenue is derived primarily from sales of our appliances. Product revenue also includes revenue derived from software licenses of Panorama and the VM-Series. We recognize product revenue at the time of shipment, provided that all other revenue recognition criteria have been met.

[0001327567-17-000035:mdna:46]
|  | Three Months Ended October 31, |  |  |  |  |
|  | 2017 |  | 2016 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Product | $ | 186.5 |  |  | $ | 163.8 |  |  | $ | 22.7 |  |  | 13.9 | % |

[0001327567-17-000035:mdna:47]
Product revenue increased for the three months ended October 31, 2017 compared to the three months ended October 31, 2016. The increase was primarily driven by demand for our newly introduced appliances. The change in product revenue due to pricing was not significant for either period.

[0001327567-17-000035:mdna:48]
[same as prior period, unchanged from 0001327567-17-000018:mdna:53]

[0001327567-17-000035:mdna:49]
Subscription and support revenue is derived primarily from sales of our subscription and support offerings. Our contractual subscription and support terms are typically one to five years. We recognize revenue from subscriptions and support over the contractual service period. As a percentage of total revenue, we expect our subscription and support revenue to vary from quarter to quarter and increase over the long term as we introduce new subscriptions, renew existing subscription and support contracts, and expand our installed end-customer base.

[0001327567-17-000035:mdna:50]
|  | Three Months Ended October 31, |  |  |  |  |
|  | 2017 |  | 2016 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Subscription | $ | 169.3 |  |  | $ | 121.2 |  |  | $ | 48.1 |  |  | 39.7 | % |
| Support | 149.7 |  |  | 113.1 |  |  | 36.6 |  |  | 32.4 | % |
| Total subscription and support | $ | 319.0 |  |  | $ | 234.3 |  |  | $ | 84.7 |  |  | 36.2 | % |

[0001327567-17-000035:mdna:51]
Subscription and support revenue increased for the three months ended October 31, 2017 compared to the three months ended October 31, 2016. The increase was due to increased demand for our subscription and support offerings from both new and existing end-customers. The mix between subscription revenue and support revenue will fluctuate over time, depending on the introduction of new subscription offerings, renewals of support services, and our ability to increase sales to new and existing customers. The change in subscription and support revenue due to changes in pricing was not significant for either period.

[0001327567-17-000035:mdna:52]
[same as prior period, unchanged from 0001327567-17-000018:mdna:58]

[0001327567-17-000035:mdna:53]
|  | Three Months Ended October 31, |  |  |  |  |
|  | 2017 |  | 2016 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Americas | $ | 351.3 |  |  | $ | 280.2 |  |  | $ | 71.1 |  |  | 25.4 | % |
| EMEA | 95.4 |  |  | 70.7 |  |  | 24.7 |  |  | 34.9 | % |
| APAC | 58.8 |  |  | 47.2 |  |  | 11.6 |  |  | 24.6 | % |
| Total revenue | $ | 505.5 |  |  | $ | 398.1 |  |  | $ | 107.4 |  |  | 27.0 | % |

[0001327567-17-000035:mdna:54]
[same as prior period, unchanged from 0001327567-17-000018:mdna:17]

[0001327567-17-000035:mdna:55]
With respect to geographic theaters, the Americas contributed the largest portion of the increase in revenue for the three months ended October 31, 2017 compared to the three months ended October 31, 2016, due to its larger and more established sales force compared to our other theaters. Revenue from both Europe, the Middle East, and Africa (“EMEA”) and Asia Pacific and Japan (“APAC”) increased for the three months ended October 31, 2017 compared to the three months ended October 31, 2016, due to our investment in increasing the size of our sales force and number of channel partners in these theaters.

[0001327567-17-000035:mdna:56]
[same as prior period, unchanged from 0001327567-17-000018:mdna:61]

[0001327567-17-000035:mdna:57]
[same as prior period, unchanged from 0001327567-17-000018:mdna:62]

[0001327567-17-000035:mdna:58]
[same as prior period, unchanged from 0001327567-17-000018:mdna:63]

[0001327567-17-000035:mdna:59]
Cost of product revenue primarily includes costs paid to our manufacturing partners. Our cost of product revenue also includes personnel costs, which consist of salaries, benefits, bonuses, share-based compensation, and travel and entertainment associated with our operations organization, amortization of intellectual property licenses, product testing costs, shipping costs, and allocated costs. Allocated costs consist of certain facilities, depreciation, benefits, recruiting, and information technology costs that we allocate based on headcount. We expect our cost of product revenue to increase as our product revenue increases.

[0001327567-17-000035:mdna:60]
|  | Three Months Ended October 31, |  |  |  |  |
|  | 2017 |  | 2016 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Cost of product revenue | $ | 57.6 |  |  | $ | 42.2 |  |  | $ | 15.4 |  |  | 36.5 | % |
| Number of employees at period end | 98 |  |  | 92 |  |  | 6 |  |  | 6.5 | % |

[0001327567-17-000035:mdna:61]
Cost of product revenue increased for the three months ended October 31, 2017 compared to the three months ended October 31, 2016. The increase was primarily due to higher product costs related to our newly introduced appliances.

[0001327567-17-000035:mdna:62]
[same as prior period, unchanged from 0001327567-17-000018:mdna:68]

[0001327567-17-000035:mdna:63]
Cost of subscription and support revenue includes personnel costs for our global customer support and technical operations organizations, customer support costs, third-party professional services costs, data center and hosting costs, amortization of acquired intangible assets, and allocated costs. We expect our cost of subscription and support revenue to increase as our installed end-customer base grows and adoption of our cloud-based subscription offerings increases.

[0001327567-17-000035:mdna:64]
|  | Three Months Ended October 31, |  |  |  |  |
|  | 2017 |  | 2016 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Cost of subscription and support revenue | $ | 83.8 |  |  | $ | 59.0 |  |  | $ | 24.8 |  |  | 42.0 | % |
| Number of employees at period end | 778 |  |  | 575 |  |  | 203 |  |  | 35.3 | % |

[0001327567-17-000035:mdna:65]
Cost of subscription and support revenue increased for the three months ended October 31, 2017 compared to the three months ended October 31, 2016, driven by an increase in personnel costs, which grew $12.5 million to $47.1 million for the three months ended October 31, 2017 compared to the three months ended October 31, 2016. The increase in personnel costs was primarily due to headcount growth. The remaining increase was primarily due to costs to expand our customer service capabilities and infrastructure, customer support costs, and allocated costs. The increase in allocated costs was primarily due to our expansion of facilities to support the growth of our business.

[0001327567-17-000035:mdna:66]
[same as prior period, unchanged from 0001327567-17-000018:mdna:72]

[0001327567-17-000035:mdna:67]
Gross margin, or gross profit as a percentage of revenue, has been and will continue to be affected by a variety of factors, including the introduction of new products, manufacturing costs, the average sales price of our products, the mix of products sold, and the mix of revenue between product and subscription and support offerings. For sales of our products, our higher-end firewall products generally have higher gross margins than our lower-end firewall products within each product series. For sales of our subscription and support offerings, our subscription offerings typically have higher gross margins than our support offerings. We expect our gross margins to fluctuate over time depending on the factors described above.

[0001327567-17-000035:mdna:68]
[same as prior period, unchanged from 0001327567-17-000018:mdna:29]

[0001327567-17-000035:mdna:69]
|  | Three Months Ended October 31, |
|  | 2017 |  | 2016 |
|  | Amount |  | Gross Margin |  | Amount |  | Gross Margin |
|  | (dollars in millions) |
| Product | $ | 128.9 |  |  | 69.1 | % |  | $ | 121.6 |  |  | 74.2 | % |
| Subscription and support | 235.2 |  |  | 73.7 | % |  | 175.3 |  |  | 74.8 | % |
| Total gross profit | $ | 364.1 |  |  | 72.0 | % |  | $ | 296.9 |  |  | 74.6 | % |

[0001327567-17-000035:mdna:70]
Product gross margin decreased for the three months ended October 31, 2017 compared to the three months ended October 31, 2016, driven by higher product costs related to our newly introduced appliances, which will have lower product margins.

[0001327567-17-000035:mdna:71]
Subscription and support gross margin decreased for the three months ended October 31, 2017 compared to the three months ended October 31, 2016, primarily due to higher costs related to the expansion of our infrastructure to support the adoption of our cloud-based subscription offerings.

[0001327567-17-000035:mdna:72]
[same as prior period, unchanged from 0001327567-17-000018:mdna:77]

[0001327567-17-000035:mdna:73]
Our operating expenses consist of research and development, sales and marketing, and general and administrative expense. Personnel costs are the most significant component of operating expenses and consist of salaries, benefits, bonuses, share-based compensation, travel and entertainment, and with regard to sales and marketing expense, sales commissions. Our operating expenses also include allocated costs, which consist of certain facilities, depreciation, benefits, recruiting, and information technology costs that we allocate based on headcount. We expect operating expenses to increase in absolute dollars and decrease over the long term as a percentage of revenue as we continue to scale our business. As of October 31, 2017, we expect to recognize approximately $1.1 billion of share-based compensation expense over a weighted-average period of approximately 2.6 years, excluding additional share-based compensation expense related to any future grants of share-based awards. Share-based compensation expense is generally recognized on a straight-line basis over the requisite service periods of the awards.

[0001327567-17-000035:mdna:74]
[same as prior period, unchanged from 0001327567-17-000018:mdna:81]

[0001327567-17-000035:mdna:75]
[same as prior period, unchanged from 0001327567-17-000018:mdna:82]

[0001327567-17-000035:mdna:76]
|  | Three Months Ended October 31, |  |  |  |  |
|  | 2017 |  | 2016 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Research and development | $ | 94.2 |  |  | $ | 84.2 |  |  | $ | 10.0 |  |  | 11.9 | % |
| Number of employees at period end | 787 |  |  | 648 |  |  | 139 |  |  | 21.5 | % |

[0001327567-17-000035:mdna:77]
Research and development expense increased for the three months ended October 31, 2017 compared to the three months ended October 31, 2016, primarily due to an increase in personnel costs, which grew $5.8 million to $77.7 million, largely due to headcount growth, and allocated costs due to our expansion of facilities to support the growth of our business.

[0001327567-17-000035:mdna:78]
[same as prior period, unchanged from 0001327567-17-000018:mdna:86]

[0001327567-17-000035:mdna:79]
[same as prior period, unchanged from 0001327567-17-000018:mdna:87]

[0001327567-17-000035:mdna:80]
[same as prior period, unchanged from 0001327567-17-000018:mdna:37]

[0001327567-17-000035:mdna:81]
|  | Three Months Ended October 31, |  |  |  |  |
|  | 2017 |  | 2016 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Sales and marketing | $ | 258.5 |  |  | $ | 220.1 |  |  | $ | 38.4 |  |  | 17.4 | % |
| Number of employees at period end | 2,466 |  |  | 2,181 |  |  | 285 |  |  | 13.1 | % |

[0001327567-17-000035:mdna:82]
Sales and marketing expense increased for the three months ended October 31, 2017 compared to the three months ended October 31, 2016, primarily due to an increase in personnel costs, which grew $31.8 million to $196.9 million, largely due to headcount growth. The remaining increase was primarily driven by an increase in allocated costs due to our expansion of facilities to support the growth of our business.

[0001327567-17-000035:mdna:83]
[same as prior period, unchanged from 0001327567-17-000018:mdna:94]

[0001327567-17-000035:mdna:84]
General and administrative expense consists primarily of personnel costs for our executive, finance, human resources, legal, and information technology organizations, professional services costs, which consist primarily of legal, auditing, accounting, and other consulting costs, and certain non-recurring general expenses. Certain facilities, depreciation, benefits, recruiting, and information technology costs are allocated to other organizations based on headcount. We expect general and administrative expense to increase in absolute dollars due to additional costs associated with accounting, compliance, and insurance, although our general and administrative expense may fluctuate as a percentage of total revenue.

[0001327567-17-000035:mdna:85]
|  | Three Months Ended October 31, |  |  |  |  |
|  | 2017 |  | 2016 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| General and administrative | $ | 65.7 |  |  | $ | 41.6 |  |  | $ | 24.1 |  |  | 57.9 | % |
| Number of employees at period end | 578 |  |  | 464 |  |  | 114 |  |  | 24.6 | % |

[0001327567-17-000035:mdna:86]
General and administrative expense increased for the three months ended October 31, 2017 compared to the three months ended October 31, 2016, primarily due to a loss of $15.4 million recognized on the lease of our previous headquarter facilities in August 2017, when we officially ceased use of such facilities. Refer to Note 6. Commitments and Contingencies in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information on our cease-use loss. The remaining increase was primarily driven by an increase in personnel costs, which grew $3.9 million to $34.9 million for the three months ended October 31, 2017 compared to the three months ended October 31, 2016, due to headcount growth, and an increase in allocated costs due to our expansion of facilities to support the growth of our business.

[0001327567-17-000035:mdna:87]
[same as prior period, unchanged from 0001327567-17-000018:mdna:98]

[0001327567-17-000035:mdna:88]
Provision for income taxes consists primarily of income taxes in foreign jurisdictions in which we conduct business, withholding taxes, U.S. state income taxes, and amortization of our deferred tax charges. We maintain a full valuation allowance for domestic and certain foreign deferred tax assets, including net operating loss carryforwards and tax credits.

[0001327567-17-000035:mdna:89]
|  | Three Months Ended October 31, |  | Change |
|  | 2017 |  | 2016 |  | Amount |  | % |
|  | (dollars in millions) |
| Provision for income taxes | $ | 8.2 |  |  | $ | 4.4 |  |  | $ | 3.8 |  |  | 86.4 | % |
| Effective tax rate | (14.7 | )% |  | (8.4 | )% |  |  |  |  |  |

[0001327567-17-000035:mdna:90]
We recorded an income tax provision for the three months ended October 31, 2017, due to foreign income taxes, withholding taxes, and amortization of our deferred tax charges. The provision for income taxes increased for the three months ended October 31, 2017 compared to the three months ended October 31, 2016, primarily due to an increase in amortization of our deferred tax charges from intercompany transactions and an increase in foreign taxes due to growth in non-U.S. operations.

[0001327567-17-000035:mdna:91]
[same as prior period, unchanged from 0001327567-17-000018:mdna:46]

[0001327567-17-000035:mdna:92]
[same as prior period, unchanged from 0001327567-17-000018:mdna:105]

[0001327567-17-000035:mdna:93]
|  | October 31, 2017 |  | July 31, 2017 |
|  | (in millions) |
| Working capital(1) | $ | 296.5 |  |  | $ | 775.0 |  |
| Cash, cash equivalents, and investments: |  |  |  |
| Cash and cash equivalents | $ | 842.6 |  |  | $ | 744.3 |  |
| Investments | 1,438.0 |  |  | 1,420.0 |  |
| Total cash, cash equivalents, and investments | $ | 2,280.6 |  |  | $ | 2,164.3 |  |

[0001327567-17-000035:mdna:94]
[same as prior period, unchanged from 0001327567-17-000018:mdna:35]

[0001327567-17-000035:mdna:95]
| (1) | The net carrying amount of the 0.0% Convertible Senior Notes due 2019 (the “Notes”) was classified in current liabilities in our condensed consolidated balance sheets as of October 31, 2017. Refer to Note 5. Convertible Senior Notes in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information. |

[0001327567-17-000035:mdna:96]
At October 31, 2017, our total cash, cash equivalents, and investments of $2.3 billion were held for general corporate purposes, of which approximately $296.4 million was held outside of the United States. As of October 31, 2017, we had no unremitted earnings when evaluating our outside basis differences relating to our investment in foreign subsidiaries; accordingly, there is no restriction on the use of these funds.

[0001327567-17-000035:mdna:97]
As of October 31, 2017, all of the Notes remained outstanding. The Notes mature on July 1, 2019, however, prior to January 1, 2019, holders may surrender their Notes for early conversion under certain circumstances. During the fiscal quarter ended October 31, 2017, one of the early conversion conditions was met, and as a result, holders may convert their Notes at any time during the fiscal quarter ending January 31, 2018. Upon conversion, we will pay cash equal to the aggregate principal amount of the Notes to be converted, and, at our election, will pay or deliver cash and/or shares of our common stock for the amount of our conversion obligation in excess of the aggregate principal amount of the Notes being converted. Refer to Note 5. Convertible Senior Notes in Part I, Item 1 of this Quarterly Report on Form 10-Q for information on the Notes.

[0001327567-17-000035:mdna:98]
In August 2016, our board of directors authorized a $500.0 million share repurchase and, in February 2017, authorized a $500.0 million increase to our repurchase program, bringing the total authorization to $1.0 billion. Repurchases are funded from available working capital and may be made at management’s discretion from time to time. The repurchase authorization will expire on December 31, 2018, and may be suspended or discontinued at any time. As of October 31, 2017, $455.0 million remained available for future share repurchases under the repurchase authorization. Refer to Note 7. Stockholders’ Equity in Part I, Item 1 of this Quarterly Report on Form 10-Q for information on the repurchase authorization.

[0001327567-17-000035:mdna:99]
The following table summarizes our cash flows for the three months ended October 31, 2017 and 2016:

[0001327567-17-000035:mdna:100]
|  | Three Months Ended October 31, |
| 2017 |  | 2016 |
|  | (in millions) |
| Net cash provided by operating activities | $ | 274.1 |  |  | $ | 203.5 |  |
| Net cash used in investing activities | (52.4 | ) |  | (71.2 | ) |
| Net cash used in financing activities | (123.4 | ) |  | (27.3 | ) |
| Net increase in cash and cash equivalents | $ | 98.3 |  |  | $ | 105.0 |  |

[0001327567-17-000035:mdna:101]
We believe that our cash flow from operations with existing cash and cash equivalents will be sufficient to meet our anticipated cash needs for the foreseeable future. Our future capital requirements will depend on many factors including our growth rate, the timing and extent of spending to support development efforts, the expansion of sales and marketing activities, the introduction of new and enhanced products and subscription and support offerings, the costs to acquire or invest in complementary businesses and technologies, the costs to ensure access to adequate manufacturing capacity, the investments in our new corporate headquarters, and the continuing market acceptance of our products and subscription and support offerings. In addition, from time to time we may incur additional tax liability in connection with certain corporate structuring decisions.

[0001327567-17-000035:mdna:102]
[same as prior period, unchanged from 0001327567-17-000018:mdna:119]

[0001327567-17-000035:mdna:103]
[same as prior period, unchanged from 0001327567-17-000018:mdna:57]

[0001327567-17-000035:mdna:104]
[same as prior period, unchanged from 0001327567-17-000018:mdna:120]

[0001327567-17-000035:mdna:105]
[same as prior period, unchanged from 0001327567-17-000018:mdna:121]

[0001327567-17-000035:mdna:106]
Cash provided by operating activities during the three months ended October 31, 2017 was $274.1 million, an increase of $70.6 million compared to the three months ended October 31, 2016. The increase was due to growth of our business, as reflected by increases in billings and collections on accounts receivable, and the receipt of an upfront cash reimbursement of $38.2 million related to certain of our lease agreements during the three months ended October 31, 2017. The upfront cash reimbursement was received from our landlords in connection with the amendment of our lease agreements and will be applied against rental payments due in fiscal years 2018 through 2020. Refer to Note 6. Commitments and Contingencies in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information.

[0001327567-17-000035:mdna:107]
[same as prior period, unchanged from 0001327567-17-000018:mdna:123]

[0001327567-17-000035:mdna:108]
[same as prior period, unchanged from 0001327567-17-000018:mdna:124]

[0001327567-17-000035:mdna:109]
Cash used in investing activities during the three months ended October 31, 2017 was $52.4 million, a decrease of $18.8 million compared to the three months ended October 31, 2016, due to lower net purchases of available-for-sale investments, partially offset by increased investment in facilities to support the growth of our business during the three months ended October 31, 2017.

[0001327567-17-000035:mdna:110]
[same as prior period, unchanged from 0001327567-17-000018:mdna:126]

[0001327567-17-000035:mdna:111]
[same as prior period, unchanged from 0001327567-17-000018:mdna:127]

[0001327567-17-000035:mdna:112]
Cash used in financing activities during the three months ended October 31, 2017 was $123.4 million, an increase of $96.1 million compared to the three months ended October 31, 2016, primarily due to an increase in repurchases of our common stock and payments for tax withholding obligations of certain employees related to the net share settlement of equity awards during the three months ended October 31, 2017.

[0001327567-17-000035:mdna:113]
Contractual Obligations and Commitments

[0001327567-17-000035:mdna:114]
The following table summarizes our contractual obligations and commitments as of October 31, 2017:

[0001327567-17-000035:mdna:115]
|  | Payments Due by Period |
|  | Total |  | Less Than 1 Year |  | 1-3 Years |  | 3-5 Years |  | More Than 5 Years |
|  |  |  | (in millions) |  |  |
| 0.0% Convertible Senior Notes due 2019(1) | $ | 575.0 |  |  | $ | — |  |  | $ | 575.0 |  |  | $ | — |  |  | $ | — |  |
| Operating lease obligations(2) | 562.2 |  |  | 63.1 |  |  | 129.7 |  |  | 115.7 |  |  | 253.7 |  |
| Purchase obligations(3) | 95.3 |  |  | 92.5 |  |  | 2.8 |  |  | — |  |  | — |  |
| Total(4) | $ | 1,232.5 |  |  | $ | 155.6 |  |  | $ | 707.5 |  |  | $ | 115.7 |  |  | $ | 253.7 |  |

[0001327567-17-000035:mdna:116]
[same as prior period, unchanged from 0001327567-17-000018:mdna:42]

[0001327567-17-000035:mdna:117]
| (1) | As of October 31, 2017, holders may convert their Notes at any time during the fiscal quarter ending January 31, 2018. Refer to Note 5. Convertible Senior Notes in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information. |

[0001327567-17-000035:mdna:118]
| (2) | Consists of contractual obligations from our non-cancelable operating leases. Excludes contractual sublease proceeds of $1.3 million, which will be received in less than one year. Refer to Note 6. Commitments and Contingencies in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information on our operating leases. |

[0001327567-17-000035:mdna:119]
| (3) | Consists of minimum purchase commitments of products and components with our manufacturing partners and component suppliers. Obligations under contracts that we can cancel without a significant penalty are not included in the table above. |

[0001327567-17-000035:mdna:120]
| (4) | No amounts related to income taxes are included. As of October 31, 2017, we had approximately $65.3 million of tax liabilities recorded related to uncertainty in income tax positions. |

[0001327567-17-000035:mdna:121]
[same as prior period, unchanged from 0001327567-17-000018:mdna:67]

[0001327567-17-000035:mdna:122]
[same as prior period, unchanged from 0001327567-17-000018:mdna:129]

[0001327567-17-000035:mdna:123]
As of October 31, 2017, we did not have any relationships with unconsolidated organizations or financial partnerships, such as structured finance or special purpose entities that would have been established for the purpose of facilitating off-balance sheet arrangements or other contractually narrow or limited purposes.

[0001327567-17-000035:mdna:124]
[same as prior period, unchanged from 0001327567-17-000018:mdna:131]

[0001327567-17-000035:mdna:125]
[same as prior period, unchanged from 0001327567-17-000018:mdna:132]

[0001327567-17-000035:mdna:126]
We believe the critical accounting estimates discussed under Item 7, “Management’s Discussion and Analysis of Financial Condition and Results of Operations” in our Annual Report on Form 10-K for the fiscal year ended July 31, 2017, reflect our more significant judgments and estimates used in the preparation of our condensed consolidated financial statements. There have been no significant changes to our critical accounting estimates as filed in such report.

[0001327567-17-000035:mdna:127]
[same as prior period, unchanged from 0001327567-17-000018:mdna:134]

[0001327567-17-000035:mdna:128]
Refer to “Recently Issued Accounting Pronouncements” in Note 1. Description of Business and Summary of Significant Accounting Policies in Part I, Item 1 of this Quarterly Report on Form 10-Q.
