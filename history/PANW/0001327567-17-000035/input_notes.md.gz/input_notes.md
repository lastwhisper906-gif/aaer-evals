# PANW notes — 0001327567-17-000035


## us-gaap:AvailableForSaleSecuritiesTextBlock

[0001327567-17-000035:notes:1]
The following tables summarize the amortized cost, unrealized gains and losses, and fair value of our available-for-sale securities as of October 31, 2017 and July 31, 2017 (in millions):

[0001327567-17-000035:notes:2]
|  | October 31, 2017 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Estimated Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Money market funds | $ | 250.1 |  |  | $ | — |  |  | $ | — |  |  | $ | 250.1 |  |
| U.S. government and agency securities | 5.0 |  |  | — |  |  | — |  |  | 5.0 |  |
| Total cash equivalents | $ | 255.1 |  |  | $ | — |  |  | $ | — |  |  | $ | 255.1 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 5.4 |  |  | $ | — |  |  | $ | — |  |  | $ | 5.4 |  |
| Corporate debt securities | 355.0 |  |  | 0.2 |  |  | (0.8 | ) |  | 354.4 |  |
| U.S. government and agency securities | 1,082.2 |  |  | — |  |  | (4.0 | ) |  | 1,078.2 |  |
| Total investments | $ | 1,442.6 |  |  | $ | 0.2 |  |  | $ | (4.8 | ) |  | $ | 1,438.0 |  |

[0001327567-17-000035:notes:3]
|  | July 31, 2017 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Estimated Fair Value |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 5.4 |  |  | $ | — |  |  | $ | — |  |  | $ | 5.4 |  |
| Corporate debt securities | 346.1 |  |  | 0.3 |  |  | (0.5 | ) |  | 345.9 |  |
| U.S. government and agency securities | 1,071.2 |  |  | 0.1 |  |  | (2.6 | ) |  | 1,068.7 |  |
| Total investments | $ | 1,422.7 |  |  | $ | 0.4 |  |  | $ | (3.1 | ) |  | $ | 1,420.0 |  |


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock

[0001327567-17-000035:notes:4]
[same as prior period, unchanged from 0001327567-17-000018:notes:18]

[0001327567-17-000035:notes:5]
[same as prior period, unchanged from 0001327567-17-000018:notes:19]

[0001327567-17-000035:notes:6]
Palo Alto Networks, Inc. (the “Company,” “we,” “us,” or “our”), located in Santa Clara, California, was incorporated in March 2005 under the laws of the State of Delaware and commenced operations in April 2005. We offer a next-generation security platform that empowers enterprises, service providers, and government entities to secure their organizations by safely enabling applications running on their networks and by preventing breaches that stem from targeted cyberattacks.

[0001327567-17-000035:notes:7]
Basis of Presentation and Principles of Consolidation

[0001327567-17-000035:notes:8]
The accompanying condensed consolidated financial statements have been prepared in conformity with U.S. generally accepted accounting principles (“GAAP”), consistent in all material respects with those applied in our Annual Report on Form 10-K for the fiscal year ended July 31, 2017, filed with the Securities and Exchange Commission (“SEC”) on September 7, 2017. Our condensed consolidated financial statements include our accounts and our wholly owned subsidiaries. All significant intercompany balances and transactions have been eliminated in consolidation.

[0001327567-17-000035:notes:9]
Our condensed consolidated financial statements are unaudited, but include all adjustments of a normal recurring nature necessary for a fair presentation of our quarterly results. We have made estimates and judgments affecting the amounts reported in our condensed consolidated financial statements and the accompanying notes. The actual results that we experience may differ materially from our estimates. Certain prior period amounts have been adjusted due to our early adoption of new accounting guidance related to share-based payments in our second quarter of fiscal 2017. For more information, refer to “Recently Adopted Accounting Pronouncements” in Note 1. Description of Business and Summary of Significant Accounting Policies included in Part II, Item 8 of our Annual Report on Form 10-K for the fiscal year ended July 31, 2017.

[0001327567-17-000035:notes:10]
Our condensed consolidated financial statements should be read in conjunction with the audited consolidated financial statements and related notes in our Annual Report on Form 10-K for the fiscal year ended July 31, 2017.

[0001327567-17-000035:notes:11]
[same as prior period, unchanged from 0001327567-17-000018:notes:21]

[0001327567-17-000035:notes:12]
There have been no material changes to our significant accounting policies as of and for the three months ended October 31, 2017, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended July 31, 2017.

[0001327567-17-000035:notes:13]
Recently Issued Accounting Pronouncements

[0001327567-17-000035:notes:14]
Derivatives and Hedging

[0001327567-17-000035:notes:15]
In August 2017, the Financial Accounting Standards Board (“FASB”) issued new authoritative guidance on derivatives and hedging to better align an entity’s risk management activities and financial reporting for hedging relationships through changes to both the designation and measurement guidance for qualifying hedging relationships, and the presentation of hedge results. The standard is effective for us in our first quarter of fiscal 2020 and will be applied on a modified retrospective basis. Early adoption is permitted.   We plan to early adopt the standard in our second quarter of fiscal 2018. We do not expect the adoption of the standard will have a material impact on our condensed consolidated financial statements.

[0001327567-17-000035:notes:16]
Business Combinations - Definition of a Business

[0001327567-17-000035:notes:17]
In January 2017, the FASB issued authoritative guidance clarifying the definition of a business to assist companies with evaluating whether transactions should be accounted for as acquisitions (or disposals) of assets or businesses. The standard is effective for us in our first quarter of fiscal 2019 and will be applied on a prospective basis. Early adoption is permitted. We do not expect the adoption of the standard will have a material impact on our condensed consolidated financial statements.

[0001327567-17-000035:notes:18]
Statement of Cash Flows - Restricted Cash

[0001327567-17-000035:notes:19]
In November 2016, the FASB issued authoritative guidance on the presentation of restricted cash or restricted cash equivalents in the statement of cash flows. Under the new standard, restricted cash or restricted cash equivalents should be included with cash and cash equivalents when reconciling the beginning-of-period and end-of-period total amounts shown on the statement of cash flows. The standard is effective for us in our first quarter of fiscal 2019 and will be applied on a retrospective basis. Early adoption is permitted. We do not expect the adoption of the standard will have a material impact on our condensed consolidated financial statements because our restricted cash balance has not been material.

[0001327567-17-000035:notes:20]
Income Taxes - Intra-Entity Asset Transfers

[0001327567-17-000035:notes:21]
In October 2016, the FASB issued authoritative guidance requiring the recognition of income tax consequences of an intra-entity transfer of an asset, other than inventory, when the transfer occurs. The standard is effective for us in our first quarter of fiscal 2019 and will be applied on a modified retrospective basis. Early adoption is permitted. We plan to adopt the standard in our first quarter of fiscal 2019. The adoption of this standard may have a material impact on our condensed consolidated financial statements, subject to any potential intra-entity transfers of assets (excluding inventory).

[0001327567-17-000035:notes:22]
Statement of Cash Flows - Classification of Certain Cash Receipts and Cash Payments

[0001327567-17-000035:notes:23]
In August 2016, the FASB issued new authoritative guidance addressing eight specific cash flow issues with the objective of reducing the existing diversity in practice in how certain transactions are presented and classified in the statement of cash flows. The standard is effective for us in our first quarter of fiscal 2019 and will be applied on a retrospective basis. Early adoption is permitted. We do not expect the adoption of the standard will have a material impact on our condensed consolidated financial statements.

[0001327567-17-000035:notes:24]
Financial Instruments - Credit Losses

[0001327567-17-000035:notes:25]
In June 2016, the FASB issued new authoritative guidance on the accounting for credit losses on most financial assets and certain financial instruments. The standard replaces the existing incurred loss model with an expected credit loss model for financial assets measured at amortized cost, including trade receivables, and requires that credit losses on available-for-sale debt securities be presented as an allowance rather than as a write-down. The standard is effective for us in our first quarter of fiscal 2021 and will be applied on a modified retrospective basis. Early adoption is permitted beginning our first quarter of fiscal 2020. We are currently evaluating whether this standard will have a material impact on our condensed consolidated financial statements.

[0001327567-17-000035:notes:26]
Leases

[0001327567-17-000035:notes:27]
In February 2016, the FASB issued new authoritative guidance on lease accounting. Among its provisions, the standard requires lessees to recognize right-of-use assets and lease liabilities on the balance sheet for operating leases and also requires additional qualitative and quantitative disclosures about lease arrangements. The standard is effective for us in our first quarter of fiscal 2020 and will be applied on a modified retrospective basis, with the option to elect certain practical expedients. Early adoption is permitted. We are currently evaluating whether this standard will have a material impact on our condensed consolidated financial statements.

[0001327567-17-000035:notes:28]
Revenue Recognition

[0001327567-17-000035:notes:29]
In May 2014, the FASB issued new authoritative guidance on revenue from contracts with customers. The new standard provides principles for recognizing revenue for the transfer of promised goods or services to customers with the consideration to which the entity expects to be entitled in exchange for those goods or services, as well as guidance on the recognition of costs related to obtaining and fulfilling customer contracts. The standard also requires expanded disclosures about the nature, amount, timing, and uncertainty of revenues and cash flows arising from customer contracts, including significant judgments and changes in judgments, and assets recognized from costs incurred to obtain or fulfill a contract. The standard is effective for us in our first quarter of fiscal 2019 using either of two methods: (i) retrospective to each prior reporting period presented with the option to elect certain practical expedients as defined within the guidance (“full retrospective method”); or (ii) retrospective with the cumulative effect of initially applying the guidance recognized at the date of initial application and providing certain additional disclosures as defined per the guidance (“modified retrospective method”).

[0001327567-17-000035:notes:30]
We will adopt the standard in our first quarter of fiscal 2019 using the full retrospective method. However, our ability to apply the full retrospective method is dependent on system readiness and the completion of our analysis of information necessary to restate prior period financial statements.

[0001327567-17-000035:notes:31]
We are continuing to evaluate the impact of the new standard on our accounting policies, processes, internal controls over financial reporting, and system requirements, and have assigned cross-functional internal resources and engaged third-party service providers to assist in our evaluation and system implementation. Furthermore, we have made and will continue to make investments in systems to enable timely and accurate reporting under the new standard.

[0001327567-17-000035:notes:32]
We are also continuing to evaluate the impact the standard will have on our condensed consolidated financial statements, including reviewing the provisions of our customer contracts and identifying performance obligations under the requirements of the new standard, and comparing to our current accounting policies and practices. Although we have not yet determined whether the effect will be material, we believe the new standard will impact our accounting for revenue arrangements in the following areas:

[0001327567-17-000035:notes:33]
[same as prior period, unchanged from 0001327567-17-000018:notes:55]

[0001327567-17-000035:notes:34]
[same as prior period, unchanged from 0001327567-17-000018:notes:56]

[0001327567-17-000035:notes:35]
[same as prior period, unchanged from 0001327567-17-000018:notes:57]

[0001327567-17-000035:notes:36]
[same as prior period, unchanged from 0001327567-17-000018:notes:58]

[0001327567-17-000035:notes:37]
We will continue to assess the new standard along with industry trends and additional interpretive guidance, and may adjust our implementation plan accordingly.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001327567-17-000035:notes:38]
Commitments and Contingencies

[0001327567-17-000035:notes:39]
We lease our facilities under various non-cancelable operating leases, which expire through the year ending July 31, 2028.

[0001327567-17-000035:notes:40]
In May 2015 and October 2015, we entered into a total of three lease agreements for approximately 941,000 square feet of corporate office space in Santa Clara, California, which serves as our new corporate headquarters. The leases contain rent holiday periods, scheduled rent increases, lease incentives, and renewal options which allow the lease terms to be extended beyond their expiration dates of July 2028 through July 2046. In September 2017, per the terms of the lease agreements, the landlords exercised their option to amend our lease payment schedules and eliminate our rent holiday periods, which increased our rental payments by $24.4 million, $11.8 million, and $2.0 million for fiscal 2018, 2019, and 2020, respectively. In exchange, we received an upfront cash reimbursement of $38.2 million, which we will apply against the future additional rental payments when due. As amended, rental payments under the three lease agreements are approximately $412.0 million over the lease term.

[0001327567-17-000035:notes:41]
In May 2015, we also entered into a lease agreement for approximately 122,000 square feet of space in Santa Clara, California, to serve as an extension of our previous corporate headquarters. The lease contains scheduled rent increases, lease incentives, and renewal options which allow the lease term to be extended beyond the expiration date of April 2021 through July 2046. Rental payments under the lease agreement are approximately $23.1 million over the lease term.

[0001327567-17-000035:notes:42]
In September 2012, we entered into two lease agreements for a total of approximately 300,000 square feet of space in Santa Clara, California, which served as our previous corporate headquarters through August 2017, when we relocated to our new corporate campus. The leases contain rent holiday periods and two separate five-year options to extend the lease terms beyond their expiration dates of July 2023. Rental payments under these lease agreements are approximately $94.3 million over the lease term. In August 2017, we exited our previous headquarter facilities and relocated to our new corporate campus. As a result, we recognized a cease-use loss of $15.4 million as general administrative expense in our condensed consolidated statements of operations during the three months ended October 31, 2017 and a corresponding liability in our condensed consolidated balance sheets. The cease-use loss of $15.4 million was calculated as the present value of the excess of the remaining lease obligation for the vacated facilities, adjusted for the effects of any deferred items recognized under the leases and related costs, over the estimated sublease rentals that could be reasonably obtained. The amount of the cease-use loss may vary if the timing or amount of estimated cash flows change. During the three months ended October 31, 2017, $1.9 million of the cease-use liability was released through rental payments. As of October 31, 2017, the remaining balance of the cease-use liability was $13.5 million, which is expected to be paid through the end of the lease term in July 2023.

[0001327567-17-000035:notes:43]
The following table presents details of the aggregate future non-cancelable minimum rental payments under our operating leases as of October 31, 2017 (in millions):

[0001327567-17-000035:notes:44]
|  | Amount |
| Fiscal years ending July 31: |  |
| Remaining 2018 | $ | 46.3 |  |
| 2019 | 65.5 |  |
| 2020 | 65.8 |  |
| 2021 | 60.1 |  |
| 2022 | 56.7 |  |
| 2023 and thereafter | 267.8 |  |
| Committed gross lease payments | 562.2 |  |
| Less: proceeds from sublease rental | 1.3 |  |
| Net operating lease obligation | $ | 560.9 |  |

[0001327567-17-000035:notes:45]
Manufacturing Purchase Commitments

[0001327567-17-000035:notes:46]
Our electronics manufacturing service provider (“EMS provider”) procures components and assembles our products based on our forecasts. These forecasts are based on estimates of demand for our products primarily for the next 12 months, which are in turn based on historical trends and an analysis from our sales and product management organizations, adjusted for overall market conditions. In order to reduce manufacturing lead times and plan for adequate supply, we may issue non-cancelable orders for products and components to our manufacturing partners or component suppliers. As of October 31, 2017, our purchase commitments under such orders were $95.3 million, of which $2.8 million represent commitments through the year ending July 31, 2019, excluding obligations under contracts that we can cancel without a significant penalty.

[0001327567-17-000035:notes:47]
Litigation

[0001327567-17-000035:notes:48]
We are subject to legal proceedings, claims, and litigation arising in the ordinary course of business, including intellectual property litigation. Such matters are subject to many uncertainties and outcomes are not predictable with assurance. We accrue for contingencies when we believe that a loss is probable and that we can reasonably estimate the amount of any such loss.

[0001327567-17-000035:notes:49]
To the extent there is a reasonable possibility that a loss exceeding amounts already recognized may be incurred and the amount of such additional loss would be material, we will either disclose the estimated additional loss or state that such an estimate cannot be made. As of October 31, 2017, we have not recorded any significant accruals for loss contingencies associated with such legal proceedings, determined that an unfavorable outcome is probable or reasonably possible, or determined that the amount or range of any possible loss is reasonably estimable.


## us-gaap:ConvertibleDebtTableTextBlock

[0001327567-17-000035:notes:50]
The following table sets forth the components of the Notes as of October 31, 2017 and July 31, 2017 (in millions):

[0001327567-17-000035:notes:51]
|  | October 31, 2017 |  | July 31, 2017 |
| Liability: |  |  |  |
| Principal | $ | 575.0 |  |  | $ | 575.0 |  |
| Less: debt discount and debt issuance costs, net of amortization | 44.0 |  |  | 50.3 |  |
| Net carrying amount | $ | 531.0 |  |  | $ | 524.7 |  |
| Equity (including temporary equity) | $ | 109.8 |  |  | $ | 109.8 |  |


## us-gaap:DebtDisclosureTextBlock

[0001327567-17-000035:notes:52]
Convertible Senior Notes

[0001327567-17-000035:notes:53]
On June 30, 2014, we issued $575.0 million aggregate principal amount of 0.0% Convertible Senior Notes due 2019 (the “Notes”). The Notes mature on July 1, 2019 unless converted or repurchased in accordance with their terms prior to such date. The Notes do not contain any financial covenants and we cannot redeem the Notes prior to maturity.

[0001327567-17-000035:notes:54]
The Notes are convertible for up to 5.2 million shares of our common stock at an initial conversion price of approximately $110.28 per share of common stock, subject to adjustment. Holders of the Notes may surrender their Notes for conversion at their option at any time prior to the close of business on the business day immediately preceding January 1, 2019, only under the following circumstances:

[0001327567-17-000035:notes:55]
| • | during any fiscal quarter commencing after the fiscal quarter ending on October 31, 2014 (and only during such fiscal quarter), if the last reported sale price of our common stock for at least 20 trading days (whether or not consecutive) during a period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the conversion price for the Notes on each applicable trading day (the “sale price condition”); |

[0001327567-17-000035:notes:56]
| • | during the five business day period after any five consecutive trading day period, in which the trading price per $1,000 principal amount of Notes for each trading day of the measurement period was less than 98% of the product of the last reported sale price of our common stock and the conversion rate for the Notes on each such trading day; or |

[0001327567-17-000035:notes:57]
| • | upon the occurrence of specified corporate events. |

[0001327567-17-000035:notes:58]
On or after January 1, 2019, holders may convert all or any portion of their Notes at any time prior to the close of business on the second scheduled trading day immediately preceding the maturity date regardless of the foregoing conditions. Upon conversion, holders will receive cash equal to the aggregate principal amount of the Notes to be converted, and, at our election, cash and/or shares of our common stock for any amounts in excess of the aggregate principal amount of the Notes being converted.

[0001327567-17-000035:notes:59]
The sale price condition was met during the fiscal quarter ended October 31, 2017, and as a result, holders may convert their Notes at any time during the fiscal quarter ending January 31, 2018. Accordingly, the net carrying amount of the Notes was reclassified into current liabilities and the portion of the equity component representing the conversion option was reclassified into temporary equity in our condensed consolidated balance sheets as of October 31, 2017. The portion of the equity component classified as temporary equity is measured as the difference between the principal and net carrying amount of the Notes, excluding debt issuance costs. The sale price condition was not met during the fiscal quarter ended July 31, 2017. Since the Notes were not convertible, the net carrying amount of the Notes was classified as a long-term liability and the equity component was included in additional paid-in capital in our condensed consolidated balance sheets as of July 31, 2017.

[0001327567-17-000035:notes:60]
The total estimated fair value of the Notes was $806.2 million and $747.5 million at October 31, 2017 and July 31, 2017, respectively. The fair value was determined based on the closing trading price per $100 of the Notes as of the last day of trading for the period. We consider the fair value of the Notes at October 31, 2017 and July 31, 2017 to be a Level 2 measurement. The fair value of the Notes is primarily affected by the trading price of our common stock and market interest rates. As of October 31, 2017, the if-converted value of the Notes exceeded its principal amount by $185.7 million.

[0001327567-17-000035:notes:61]
The following table sets forth interest expense recognized related to the Notes (dollars in millions):

[0001327567-17-000035:notes:62]
|  | Three Months Ended |
|  | October 31, |
|  | 2017 |  | 2016 |
| Amortization of debt discount | $ | 5.6 |  |  | $ | 5.4 |  |
| Amortization of debt issuance costs | 0.7 |  |  | 0.6 |  |
| Total interest expense recognized | $ | 6.3 |  |  | $ | 6.0 |  |
| Effective interest rate of the liability component | 4.8 | % |  | 4.8 | % |

[0001327567-17-000035:notes:63]
Note Hedges

[0001327567-17-000035:notes:64]
To minimize the impact of potential economic dilution upon conversion of the Notes, we entered into convertible note hedge transactions (the “Note Hedges”) with respect to our common stock concurrent with the issuance of the Notes. The Note Hedges cover up to 5.2 million shares of our common stock at a strike price per share that corresponds to the initial conversion price of the Notes, which are also subject to adjustment, and are exercisable upon conversion of the Notes. The Note Hedges will expire upon maturity of the Notes. The Note Hedges are separate transactions and are not part of the terms of the Notes. Holders of the Notes will not have any rights with respect to the Note Hedges. The shares receivable related to the Note Hedges are excluded from the calculation of diluted earnings per share as they are antidilutive.

[0001327567-17-000035:notes:65]
Warrants

[0001327567-17-000035:notes:66]
Separately, but concurrently with our issuance of the Notes, we entered into transactions whereby we sold warrants (the “Warrants”) to acquire up to 5.2 million shares of our common stock at a strike price of approximately $137.85 per share, subject to adjustments. The shares issuable under the Warrants will be included in the calculation of diluted earnings per share when the average market value per share of our common stock for the reporting period exceeds the strike price of the Warrants. The Warrants are separate transactions and are not part of the Notes or Note Hedges, and are not remeasured through earnings each reporting period. Holders of the Notes and Note Hedges will not have any rights with respect to the Warrants.

[0001327567-17-000035:notes:67]
For more information on the Notes, the Note Hedges, and the Warrants, refer to Note 8. Convertible Senior Notes included in Part II, Item 8 of our Annual Report on Form 10-K for the fiscal year ended July 31, 2017.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001327567-17-000035:notes:68]
[same as prior period, unchanged from 0001327567-17-000018:notes:88]

[0001327567-17-000035:notes:69]
[same as prior period, unchanged from 0001327567-17-000018:notes:89]

[0001327567-17-000035:notes:70]
[same as prior period, unchanged from 0001327567-17-000018:notes:90]

[0001327567-17-000035:notes:71]
Our derivative financial instruments are recorded at fair value, on a gross basis, as either assets or liabilities in our condensed consolidated balance sheets. Gains or losses related to the effective portion of our cash flow hedges are recorded as a component of accumulated other comprehensive income (loss) (“AOCI”) in our condensed consolidated balance sheets and are reclassified into the financial statement line item associated with the underlying hedged transaction in our condensed consolidated statements of operations when the underlying hedged transaction is recognized in earnings. Any gains or losses related to the ineffective portion of our cash flow hedges are recorded immediately in other income (expense), net in our condensed consolidated statements of operations. If it becomes probable that the hedged transaction will not occur, the cumulative unrealized gain or loss is reclassified immediately from AOCI into other income (expense), net. Gains or losses related to non-designated derivative instruments are recognized in other income (expense), net each period until the instrument matures, is terminated, is re-designated as a qualified cash flow hedge, or is sold. Derivatives designated as cash flow hedges are classified in our condensed consolidated statements of cash flows in the same manner as the underlying hedged transaction, primarily within cash flows from operating activities.

[0001327567-17-000035:notes:72]
As of October 31, 2017, the total notional amount of our outstanding foreign currency forward contracts was $164.4 million. Refer to Note 2. Fair Value Measurements for the fair value of our derivative instruments as reported in our condensed consolidated balance sheets as of October 31, 2017.

[0001327567-17-000035:notes:73]
During the three months ended October 31, 2017, both unrealized losses recognized in AOCI related to the effective portion of our cash flow hedges and amounts reclassified into earnings were not material. Total unrealized losses in AOCI related to the effective portion of our cash flow hedges as of October 31, 2017 were also not material.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001327567-17-000035:notes:74]
[same as prior period, unchanged from 0001327567-17-000018:notes:94]

[0001327567-17-000035:notes:75]
2012 Employee Stock Purchase Plan

[0001327567-17-000035:notes:76]
Our 2012 Employee Stock Purchase Plan was adopted by our board of directors and approved by the stockholders on June 5, 2012, and was effective upon completion of our initial public offering (“IPO”). On August 29, 2017, we amended and restated our 2012 Employee Stock Purchase Plan (our “2012 ESPP”) to extend the length of our offering periods from six to 24 months. Under our 2012 ESPP, each 24-month offering period consists of four consecutive six-month purchase periods, with purchase dates on the first trading day on or after February 28 and August 31 of each year. Our 2012 ESPP permits eligible employees to acquire shares of our common stock at 85% of the lower of the fair market value of our common stock on the first trading day of each offering period or on the purchase date. If the fair market value of our common stock on the purchase date is lower than the first trading day of the offering period, the current offering period will be cancelled after purchase and a new 24-month offering period will begin. Participants may purchase shares of common stock through payroll deductions of up to 15% of their eligible compensation, subject to purchase limits of 625 shares per six-month purchase period or $25,000 worth of stock for each calendar year.

[0001327567-17-000035:notes:77]
[same as prior period, unchanged from 0001327567-17-000018:notes:95]

[0001327567-17-000035:notes:78]
[same as prior period, unchanged from 0001327567-17-000018:notes:96]

[0001327567-17-000035:notes:79]
|  | Options Outstanding |
|  | Number of Shares |  | Weighted-Average Exercise Price Per Share |  | Weighted-Average Remaining Contractual Term(Years) |  | Aggregate Intrinsic Value |
| Balance—July 31, 2017 | 1.6 |  |  | $ | 13.11 |  |  | 4.2 |  | $ | 190.6 |  |
| Options granted | — |  |  | $ | — |  |  |  |  |  |
| Options forfeited | — |  |  | $ | — |  |  |  |  |  |
| Options exercised | (0.1 | ) |  | $ | 10.09 |  |  |  |  |  |
| Balance—October 31, 2017 | 1.5 |  |  | $ | 13.30 |  |  | 4.0 |  | $ | 202.3 |  |
| Options exercisable—October 31, 2017 | 1.5 |  |  | $ | 13.30 |  |  | 4.0 |  | $ | 202.3 |  |

[0001327567-17-000035:notes:80]
Restricted Stock Award (“RSA”), Performance-Based Stock Award (“PSA”), Restricted Stock Unit (“RSU”), and Performance-Based Stock Unit (“PSU”) Activities

[0001327567-17-000035:notes:81]
Our PSAs and PSUs vest over a period of four years from the date of grant. The actual number of PSAs and PSUs earned and eligible to vest are determined based on level of achievement against a pre-established billings target for the fiscal year in which the awards are granted. We recognize share-based compensation expense for our PSAs and PSUs on a straight-line basis over the requisite service period for each separately vesting portion of the award when it is probable that the performance condition will be achieved.

[0001327567-17-000035:notes:82]
The following table summarizes the RSA, PSA, RSU, and PSU activity under our stock plans during the reporting period (in millions, except per share amounts):

[0001327567-17-000035:notes:83]
|  | RSAs and PSAs Outstanding |  | RSUs and PSUs Outstanding |
|  | Number of Shares |  | Weighted-Average Grant-Date Fair Value Per Share |  | Number of Shares |  | Weighted-Average Grant-Date Fair Value Per Share |  | Weighted-Average Remaining Contractual Term(Years) |  | Aggregate Intrinsic Value |
| Balance—July 31, 2017 | 1.0 |  |  | $ | 163.55 |  |  | 6.5 |  |  | $ | 141.16 |  |  | 1.3 |  | $ | 854.1 |  |
| Granted(1) | — |  |  | $ | — |  |  | 2.1 |  |  | $ | 146.87 |  |  |  |  |  |
| Vested | (0.1 | ) |  | $ | 166.03 |  |  | (1.1 | ) |  | $ | 136.53 |  |  |  |  |  |
| Forfeited | (0.1 | ) |  | $ | 148.54 |  |  | (0.2 | ) |  | $ | 137.21 |  |  |  |  |  |
| Balance—October 31, 2017 | 0.8 |  |  | $ | 165.04 |  |  | 7.3 |  |  | $ | 143.54 |  |  | 1.5 |  | $ | 1,074.4 |  |

[0001327567-17-000035:notes:84]
______________

[0001327567-17-000035:notes:85]
| (1) | For PSAs and PSUs, shares granted represents the aggregate maximum number of shares that may be earned and issued with respect to these awards over their full terms. |

[0001327567-17-000035:notes:86]
[same as prior period, unchanged from 0001327567-17-000018:notes:104]

[0001327567-17-000035:notes:87]
[same as prior period, unchanged from 0001327567-17-000018:notes:105]

[0001327567-17-000035:notes:88]
|  | Three Months Ended |
|  | October 31, |
|  | 2017 |  | 2016 |
| Cost of product revenue | $ | 1.9 |  |  | $ | 1.7 |  |
| Cost of subscription and support revenue | 15.9 |  |  | 12.3 |  |
| Research and development | 37.5 |  |  | 38.0 |  |
| Sales and marketing | 51.2 |  |  | 43.8 |  |
| General and administrative | 19.2 |  |  | 17.5 |  |
| Total share-based compensation | $ | 125.7 |  |  | $ | 113.3 |  |

[0001327567-17-000035:notes:89]
As of October 31, 2017, total compensation cost related to unvested share-based awards not yet recognized was $1.1 billion. This cost is expected to be amortized on a straight-line basis over a weighted-average period of approximately 2.6 years.


## us-gaap:EarningsPerShareTextBlock

[0001327567-17-000035:notes:90]
Net Loss Per Share

[0001327567-17-000035:notes:91]
Basic net loss per share is computed by dividing net loss by basic weighted-average shares outstanding during the period. Diluted net loss per share is computed by dividing net loss by diluted weighted-average shares outstanding, including potentially dilutive securities.

[0001327567-17-000035:notes:92]
[same as prior period, unchanged from 0001327567-17-000018:notes:111]

[0001327567-17-000035:notes:93]
|  | Three Months Ended |
|  | October 31, |
|  | 2017 |  | 2016 |
| Net loss | $ | (64.0 | ) |  | $ | (56.9 | ) |
| Weighted-average shares used to compute net loss per share, basic and diluted | 90.9 |  |  | 89.8 |  |
| Net loss per share, basic and diluted | $ | (0.70 | ) |  | $ | (0.63 | ) |

[0001327567-17-000035:notes:94]
[same as prior period, unchanged from 0001327567-17-000018:notes:113]

[0001327567-17-000035:notes:95]
|  | Three Months Ended |
|  | October 31, |
|  | 2017 |  | 2016 |
| RSUs and PSUs | 7.3 |  |  | 7.7 |  |
| Convertible senior notes | 5.2 |  |  | 5.2 |  |
| Warrants related to the issuance of convertible senior notes | 5.2 |  |  | 5.2 |  |
| Options to purchase common stock | 1.5 |  |  | 1.8 |  |
| RSAs and PSAs | 0.8 |  |  | 1.4 |  |
| ESPP shares | 0.1 |  |  | — |  |
| Total | 20.1 |  |  | 21.3 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001327567-17-000035:notes:96]
[same as prior period, unchanged from 0001327567-17-000018:notes:117]

[0001327567-17-000035:notes:97]
We categorize assets and liabilities recorded or disclosed at fair value on our condensed consolidated balance sheets based upon the level of judgment associated with inputs used to measure their fair value. The categories are as follows:

[0001327567-17-000035:notes:98]
[same as prior period, unchanged from 0001327567-17-000018:notes:119]

[0001327567-17-000035:notes:99]
[same as prior period, unchanged from 0001327567-17-000018:notes:120]

[0001327567-17-000035:notes:100]
[same as prior period, unchanged from 0001327567-17-000018:notes:121]

[0001327567-17-000035:notes:101]
The following table presents the fair value of our financial assets and liabilities measured at fair value on a recurring basis using the above input categories as of October 31, 2017 and July 31, 2017 (in millions):

[0001327567-17-000035:notes:102]
|  |  | October 31, 2017 |  | July 31, 2017 |
|  |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Cash equivalents: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 250.1 |  |  | $ | — |  |  | $ | — |  |  | $ | 250.1 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| U.S. government and agency securities |  | — |  |  | 5.0 |  |  | — |  |  | 5.0 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Total cash equivalents |  | 250.1 |  |  | 5.0 |  |  | — |  |  | 255.1 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Short-term investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate debt securities |  | — |  |  | 170.3 |  |  | — |  |  | 170.3 |  |  | — |  |  | 159.4 |  |  | — |  |  | 159.4 |  |
| U.S. government and agency securities |  | — |  |  | 490.3 |  |  | — |  |  | 490.3 |  |  | — |  |  | 471.3 |  |  | — |  |  | 471.3 |  |
| Total short-term investments |  | — |  |  | 660.6 |  |  | — |  |  | 660.6 |  |  | — |  |  | 630.7 |  |  | — |  |  | 630.7 |  |
| Prepaid expenses and other current assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency forward contracts |  | — |  |  | 0.2 |  |  | — |  |  | 0.2 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Total prepaid expenses and other current assets |  | — |  |  | 0.2 |  |  | — |  |  | 0.2 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Long-term investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Certificates of deposit |  | — |  |  | 5.4 |  |  | — |  |  | 5.4 |  |  | — |  |  | 5.4 |  |  | — |  |  | 5.4 |  |
| Corporate debt securities |  | — |  |  | 184.1 |  |  | — |  |  | 184.1 |  |  | — |  |  | 186.5 |  |  | — |  |  | 186.5 |  |
| U.S. government and agency securities |  | — |  |  | 587.9 |  |  | — |  |  | 587.9 |  |  | — |  |  | 597.4 |  |  | — |  |  | 597.4 |  |
| Total long-term investments |  | — |  |  | 777.4 |  |  | — |  |  | 777.4 |  |  | — |  |  | 789.3 |  |  | — |  |  | 789.3 |  |
| Total assets measured at fair value |  | $ | 250.1 |  |  | $ | 1,443.2 |  |  | $ | — |  |  | $ | 1,693.3 |  |  | $ | — |  |  | $ | 1,420.0 |  |  | $ | — |  |  | $ | 1,420.0 |  |
| Accrued and other liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency forward contracts |  | $ | — |  |  | $ | 1.8 |  |  | $ | — |  |  | $ | 1.8 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Total accrued and other liabilities |  | — |  |  | 1.8 |  |  | — |  |  | 1.8 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Total liabilities measured at fair value |  | $ | — |  |  | $ | 1.8 |  |  | $ | — |  |  | $ | 1.8 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |

[0001327567-17-000035:notes:103]
As of October 31, 2017, we did not have any assets required to be measured at fair value on a nonrecurring basis. As of July 31, 2017, we determined that certain property and equipment related to our prior corporate headquarters were impaired. In connection with our planned relocation to our new corporate headquarters, we assessed the recoverability of certain leasehold improvements and other long-lived assets associated with our previous headquarter facilities and determined that the carrying amount of these assets exceeded their fair value of $4.2 million. The resulting impairment loss of $20.9 million was recorded as general and administrative expense in our consolidated statements of operations during the year ended July 31, 2017. We calculated the fair value of the leasehold improvements and other long-lived assets based on estimated future discounted cash flows and classified the fair value as a Level 3 measurement due to the significance of unobservable inputs, which included the amount and timing of estimated sublease rental receipts that we could reasonably obtain over the remaining lease term and the discount rate. As of October 31, 2017 and July 31, 2017, we did not have any liabilities required to be measured at fair value on a nonrecurring basis.

[0001327567-17-000035:notes:104]
Refer to Note 5. Convertible Senior Notes for the carrying amount and estimated fair value of our convertible senior notes as of October 31, 2017 and July 31, 2017.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001327567-17-000035:notes:105]
[same as prior period, unchanged from 0001327567-17-000018:notes:133]

[0001327567-17-000035:notes:106]
Our provision for income taxes for the three months ended October 31, 2017 reflects an effective tax rate of (14.7)%. Our effective tax rate for this period was negative as we recorded a provision for income taxes on year to date losses. The key components of our income tax provision primarily consist of foreign income taxes, withholding taxes, and amortization of our deferred tax charges. Our effective tax rate differs from the U.S. statutory tax rate primarily due to changes in non-deductible share-based compensation, foreign income at other than U.S. tax rates, and changes in our valuation allowance. As compared to the same period last year, our effective tax rate changed primarily due to changes in our foreign income taxed at other than U.S. rates and our valuation allowance.

[0001327567-17-000035:notes:107]
Our provision for income taxes for the three months ended October 31, 2016 reflects an effective tax rate of (8.4)%. Our effective tax rate for this period was negative as we recorded a provision for income taxes on year to date losses. The key components of our income tax provision primarily consist of foreign income taxes, withholding taxes, U.S. state income taxes, and amortization of our deferred tax charges.


## us-gaap:InvestmentsClassifiedByContractualMaturityDateTableTextBlock

[0001327567-17-000035:notes:108]
The following table summarizes the amortized cost and fair value of our available-for-sale securities as of October 31, 2017, by contractual years-to-maturity (in millions):

[0001327567-17-000035:notes:109]
|  | Amortized Cost |  | Fair Value |
| Due within one year | $ | 917.0 |  |  | $ | 915.7 |  |
| Due between one and three years | 780.7 |  |  | 777.4 |  |
| Total | $ | 1,697.7 |  |  | $ | 1,693.1 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001327567-17-000035:notes:110]
Cash Equivalents and Investments

[0001327567-17-000035:notes:111]
Unrealized losses related to these securities are due to interest rate fluctuations as opposed to credit quality. In addition, we do not intend to sell and it is not likely that we would be required to sell these securities before recovery of their amortized cost basis, which may be at maturity. As a result, there were no other-than-temporary impairments for these securities at October 31, 2017 and July 31, 2017.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001327567-17-000035:notes:112]
[same as prior period, unchanged from 0001327567-17-000018:notes:141]

[0001327567-17-000035:notes:113]
[same as prior period, unchanged from 0001327567-17-000018:notes:142]

[0001327567-17-000035:notes:114]
In August 2016, our board of directors authorized a $500.0 million share repurchase which is funded from available working capital. In February 2017, our board of directors authorized a $500.0 million increase to our repurchase program, bringing the total authorization to $1.0 billion. Repurchases may be made at management’s discretion from time to time on the open market, through privately negotiated transactions, transactions structured through investment banking institutions, block purchase techniques, 10b5-1 trading plans, or a combination of the foregoing. The repurchase authorization will expire on December 31, 2018, and may be suspended or discontinued at any time.

[0001327567-17-000035:notes:115]
During the three months ended October 31, 2017, we repurchased and retired 0.9 million shares of our common stock under the authorization for an aggregate purchase price of $125.0 million, including transaction costs. The total price of the shares repurchased and related transaction costs are reflected as a reduction to common stock and additional paid-in capital on our condensed consolidated balance sheets. As of October 31, 2017, $455.0 million remained available for future share repurchases under the repurchase authorization.
