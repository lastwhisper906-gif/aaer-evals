# PANW notes — 0001327567-17-000018


## us-gaap:AvailableForSaleSecuritiesTextBlock

[0001327567-17-000018:notes:1]
The following tables summarize the amortized cost, unrealized gains and losses, and fair value of our available-for-sale investments as of April 30, 2017 and July 31, 2016 (in millions):

[0001327567-17-000018:notes:2]
|  | April 30, 2017 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Estimated Fair Value |
| Certificates of deposit | $ | 5.4 |  |  | $ | — |  |  | $ | — |  |  | $ | 5.4 |  |
| Commercial paper | 15.0 |  |  | — |  |  | — |  |  | 15.0 |  |
| Corporate debt securities | 336.6 |  |  | 0.2 |  |  | (0.6 | ) |  | 336.2 |  |
| U.S. government and agency securities | 1,064.2 |  |  | 0.1 |  |  | (2.8 | ) |  | 1,061.5 |  |
| Total | $ | 1,421.2 |  |  | $ | 0.3 |  |  | $ | (3.4 | ) |  | $ | 1,418.1 |  |

[0001327567-17-000018:notes:3]
[same as prior period, unchanged from 0001327567-17-000007:notes:3]


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001327567-17-000018:notes:4]
[same as prior period, unchanged from 0001327567-17-000007:notes:4]

[0001327567-17-000018:notes:5]
[same as prior period, unchanged from 0001327567-17-000007:notes:5]

[0001327567-17-000018:notes:6]
[same as prior period, unchanged from 0001327567-17-000007:notes:6]

[0001327567-17-000018:notes:7]
[same as prior period, unchanged from 0001327567-17-000007:notes:7]


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001327567-17-000018:notes:8]
Acquisitions

[0001327567-17-000018:notes:9]
LightCyber Ltd.

[0001327567-17-000018:notes:10]
On February 27, 2017, we completed our acquisition of all outstanding shares of LightCyber Ltd. (“LightCyber”), a privately-held cybersecurity company, for total consideration of $103.1 million in cash. The acquisition expands the functionality of our next-generation security platform with the addition of LightCyber’s behavioral analytics technology.

[0001327567-17-000018:notes:11]
We have accounted for this transaction as a business combination and allocated the purchase consideration to assets acquired and liabilities assumed based on their preliminary estimated fair values, as presented in the following table (in millions):

[0001327567-17-000018:notes:12]
|  | Amount |
| Cash | $ | 12.4 |  |
| Goodwill | 75.3 |  |
| Identified intangible assets | 19.5 |  |
| Net liabilities assumed | (4.1 | ) |
| Total | $ | 103.1 |  |

[0001327567-17-000018:notes:13]
Additional information, such as that related to income tax and other contingencies, existing as of the acquisition date but unknown to us may become known during the remainder of the measurement period, not to exceed 12 months from the acquisition date, which may result in changes to the amounts and allocations recorded.

[0001327567-17-000018:notes:14]
The following table presents details of the identified intangible assets acquired (in millions, except years):

[0001327567-17-000018:notes:15]
|  | Fair Value |  | Estimated Useful Life |
| Developed technology | $ | 16.6 |  |  | 8 years |
| Customer relationships | 2.9 |  |  | 8 years |
| Total | $ | 19.5 |  |  |  |

[0001327567-17-000018:notes:16]
Goodwill generated from this business combination is primarily attributable to the assembled workforce and expected synergies from integrating the LightCyber technology into our platform. The goodwill is not deductible for income tax purposes.

[0001327567-17-000018:notes:17]
LightCyber’s operating results are included in our condensed consolidated statements of operations from the date of acquisition. Pro forma results of operations have not been presented as the impact to our condensed consolidated statements of operations is not material


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock

[0001327567-17-000018:notes:18]
[same as prior period, unchanged from 0001327567-17-000007:notes:8]

[0001327567-17-000018:notes:19]
[same as prior period, unchanged from 0001327567-17-000007:notes:9]

[0001327567-17-000018:notes:20]
[same as prior period, unchanged from 0001327567-17-000007:notes:10]

[0001327567-17-000018:notes:21]
[same as prior period, unchanged from 0001327567-17-000007:notes:11]

[0001327567-17-000018:notes:22]
There have been no material changes to our significant accounting policies as of and for the nine months ended April 30, 2017, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended July 31, 2016, except for our voluntary change in accounting policy related to sales commissions and our early adoption of the new share-based payment accounting guidance discussed below.

[0001327567-17-000018:notes:23]
[same as prior period, unchanged from 0001327567-17-000007:notes:13]

[0001327567-17-000018:notes:24]
[same as prior period, unchanged from 0001327567-17-000007:notes:14]

[0001327567-17-000018:notes:25]
[same as prior period, unchanged from 0001327567-17-000007:notes:15]

[0001327567-17-000018:notes:26]
[same as prior period, unchanged from 0001327567-17-000007:notes:16]

[0001327567-17-000018:notes:27]
[same as prior period, unchanged from 0001327567-17-000007:notes:17]

[0001327567-17-000018:notes:28]
|  | April 30, 2017 |  | July 31, 2016 |
|  | Computed under Prior Method |  | Impact of Commission Adjustment |  | As Reported |  | As Previously Reported |  | Impact of Commission Adjustment |  | As Adjusted |
| Condensed Consolidated Balance Sheets |  |  |  |  |  |  |  |  |  |  |  |
| Prepaid expenses and other current assets | $ | 99.4 |  |  | $ | 59.7 |  |  | $ | 159.1 |  |  | $ | 84.8 |  |  | $ | 54.9 |  |  | $ | 139.7 |  |
| Other assets | 91.7 |  |  | 56.5 |  |  | 148.2 |  |  | 64.6 |  |  | 50.1 |  |  | 114.7 |  |
| Other long-term liabilities | 136.7 |  |  | 0.4 |  |  | 137.1 |  |  | 79.4 |  |  | — |  |  | 79.4 |  |
| Accumulated deficit | $ | (914.3 | ) |  | $ | 115.8 |  |  | $ | (798.5 | ) |  | $ | (726.6 | ) |  | $ | 105.0 |  |  | $ | (621.6 | ) |

[0001327567-17-000018:notes:29]
|  | Three Months Ended April 30, 2017 |  | Three Months Ended April 30, 2016 |
|  | Computed under Prior Method |  | Impact of Commission Adjustment |  | As Reported |  | As Previously Reported |  | Impact of Commission Adjustment |  | As Adjusted |
| Condensed Consolidated Statements of Operations |  |  |  |  |  |  |  |  |  |  |  |
| Sales and marketing | $ | 234.6 |  |  | $ | (7.7 | ) |  | $ | 226.9 |  |  | $ | 202.0 |  |  | $ | (6.1 | ) |  | $ | 195.9 |  |
| Operating loss | (56.8 | ) |  | 7.7 |  |  | (49.1 | ) |  | (58.6 | ) |  | 6.1 |  |  | (52.5 | ) |
| Provision for income taxes | 7.3 |  |  | 0.4 |  |  | 7.7 |  |  | 6.8 |  |  | — |  |  | 6.8 |  |
| Net loss | $ | (68.2 | ) |  | $ | 7.3 |  |  | $ | (60.9 | ) |  | $ | (70.2 | ) |  | $ | 6.1 |  |  | $ | (64.1 | ) |
| Net loss per share, basic and diluted | $ | (0.75 | ) |  | $ | 0.08 |  |  | $ | (0.67 | ) |  | $ | (0.80 | ) |  | $ | 0.07 |  |  | $ | (0.73 | ) |
| Weighted-average shares used to compute net loss per share, basic and diluted | 91.0 |  |  | — |  |  | 91.0 |  |  | 87.8 |  |  | — |  |  | 87.8 |  |
| Condensed Consolidated Statements of Comprehensive Loss |  |  |  |  |  |  |  |  |  |  |  |
| Net loss | $ | (68.2 | ) |  | $ | 7.3 |  |  | $ | (60.9 | ) |  | $ | (70.2 | ) |  | $ | 6.1 |  |  | $ | (64.1 | ) |
| Comprehensive loss | $ | (67.3 | ) |  | $ | 7.3 |  |  | $ | (60.0 | ) |  | $ | (68.9 | ) |  | $ | 6.1 |  |  | $ | (62.8 | ) |

[0001327567-17-000018:notes:30]
|  | Nine Months Ended April 30, 2017(1) |  | Nine Months Ended April 30, 2016 |
|  | Computed under Prior Method |  | Impact of Commission Adjustment |  | As Reported |  | As Previously Reported |  | Impact of Commission Adjustment |  | As Adjusted |
| Condensed Consolidated Statements of Operations |  |  |  |  |  |  |  |  |  |  |  |
| Sales and marketing | $ | 684.8 |  |  | $ | (11.1 | ) |  | $ | 673.7 |  |  | $ | 547.9 |  |  | $ | (10.1 | ) |  | $ | 537.8 |  |
| Operating loss | (163.6 | ) |  | 11.1 |  |  | (152.5 | ) |  | (144.7 | ) |  | 10.1 |  |  | (134.6 | ) |
| Provision for income taxes | 14.6 |  |  | 0.3 |  |  | 14.9 |  |  | 15.0 |  |  | — |  |  | 15.0 |  |
| Net loss | $ | (189.2 | ) |  | $ | 10.8 |  |  | $ | (178.4 | ) |  | $ | (171.4 | ) |  | $ | 10.1 |  |  | $ | (161.3 | ) |
| Net loss per share, basic and diluted | $ | (2.09 | ) |  | $ | 0.12 |  |  | $ | (1.97 | ) |  | $ | (1.98 | ) |  | $ | 0.12 |  |  | $ | (1.86 | ) |
| Weighted-average shares used to compute net loss per share, basic and diluted | 90.5 |  |  | — |  |  | 90.5 |  |  | 86.5 |  |  | — |  |  | 86.5 |  |
| Condensed Consolidated Statements of Comprehensive Loss |  |  |  |  |  |  |  |  |  |  |  |
| Net loss | $ | (189.2 | ) |  | $ | 10.8 |  |  | $ | (178.4 | ) |  | $ | (171.4 | ) |  | $ | 10.1 |  |  | $ | (161.3 | ) |
| Comprehensive loss | $ | (194.4 | ) |  | $ | 10.8 |  |  | $ | (183.6 | ) |  | $ | (170.7 | ) |  | $ | 10.1 |  |  | $ | (160.6 | ) |

[0001327567-17-000018:notes:31]
[same as prior period, unchanged from 0001327567-17-000007:notes:21]

[0001327567-17-000018:notes:32]
[same as prior period, unchanged from 0001327567-17-000007:notes:22]

[0001327567-17-000018:notes:33]
This change in accounting policy does not affect our balance of cash and cash equivalents and, as a result, did not change net cash flows from operating, investing, or financing activities, or materially impact any individual line items presented in our condensed consolidated statement of cash flows for the nine months ended April 30, 2016.

[0001327567-17-000018:notes:34]
[same as prior period, unchanged from 0001327567-17-000007:notes:24]

[0001327567-17-000018:notes:35]
Recently Adopted Accounting Pronouncements

[0001327567-17-000018:notes:36]
In March 2016, the Financial Accounting Standards Board (“FASB”) issued authoritative guidance simplifying several aspects of the accounting for employee share-based payment transactions. The new standard requires us to recognize excess tax benefits or deficiencies as income tax expense or benefit in the period in which they occur, rather than additional paid-in capital, and also requires us to recognize excess tax benefits regardless of whether the benefit reduces taxes payable in the current period. In addition, excess tax benefits should be classified as an operating activity, along with other income tax cash flows, instead of a financing activity in our condensed consolidated statements of cash flows. The standard also allows us to make an accounting policy election to account for forfeitures of share-based payment awards when they occur, rather than estimate expected forfeitures.

[0001327567-17-000018:notes:37]
We elected to early adopt the standard in our second quarter of fiscal 2017, which required us to reflect any adjustments related to the adoption as of the beginning of the fiscal year. The impact of the adoption on our condensed consolidated financial statements was as follows:

[0001327567-17-000018:notes:38]
[same as prior period, unchanged from 0001327567-17-000007:notes:28]

[0001327567-17-000018:notes:39]
| • | Cash flow presentation of excess tax benefits - We elected to adopt the guidance related to the presentation of excess tax benefits in our condensed consolidated statements of cash flows on a retrospective basis, which increased net cash provided by operating activities by $0.7 million for the nine months ended April 30, 2016, with a corresponding decrease to net cash provided by financing activities. |

[0001327567-17-000018:notes:40]
[same as prior period, unchanged from 0001327567-17-000007:notes:30]

[0001327567-17-000018:notes:41]
The adoption of the standard also impacted our previously reported results for the three months ended October 31, 2016, as presented in the following tables (in millions, except per share data):

[0001327567-17-000018:notes:42]
[same as prior period, unchanged from 0001327567-17-000007:notes:32]

[0001327567-17-000018:notes:43]
[same as prior period, unchanged from 0001327567-17-000007:notes:33]

[0001327567-17-000018:notes:44]
[same as prior period, unchanged from 0001327567-17-000007:notes:34]

[0001327567-17-000018:notes:45]
In April 2015, the FASB issued new authoritative guidance on fees paid in a cloud computing arrangement. The standard requires customers in a cloud computing arrangement to evaluate whether the arrangement includes a software license. If the arrangement includes a software license, the customer should account for the software license element of the arrangement consistent with the acquisition of other software licenses. If the arrangement does not include a software license, the customer should account for the arrangement as a service contract. We adopted the standard in our first quarter of fiscal 2017 on a prospective basis. Our adoption of this standard did not have a material impact on our condensed consolidated financial statements.

[0001327567-17-000018:notes:46]
In April 2015, the FASB issued updated authoritative guidance to simplify the presentation of debt issuance costs. The amended standard requires that debt issuance costs related to a recognized debt liability be presented in the balance sheet as a direct deduction from the carrying amount of the related debt liability, consistent with the presentation of debt discounts, instead of being presented as an asset. We adopted the standard in our first quarter of fiscal 2017 on a retrospective basis, and as a result, we reduced other assets and convertible senior notes, net by $8.0 million on our condensed consolidated balance sheets as of July 31, 2016.

[0001327567-17-000018:notes:47]
Recently Issued Accounting Pronouncements

[0001327567-17-000018:notes:48]
In January 2017, the FASB issued authoritative guidance simplifying the subsequent measurement of goodwill. The standard eliminates Step 2 of the current goodwill impairment test, which requires companies to determine the implied fair value of goodwill when measuring the amount of impairment loss. Under the new standard, goodwill impairment will be measured as the amount by which a reporting unit’s carrying value exceeds its fair value, with the loss limited to the total amount of goodwill allocated to that reporting unit. The standard is effective for us for our first quarter of fiscal 2021 and will be applied on a prospective basis. Early adoption is permitted. We do not expect the adoption of the standard will have a material impact on our condensed consolidated financial statements.

[0001327567-17-000018:notes:49]
In January 2017, the FASB issued authoritative guidance clarifying the definition of a business to assist companies with evaluating whether transactions should be accounted for as acquisitions (or disposals) of assets or businesses. The standard is effective for us for our first quarter of fiscal 2019 and will be applied on a prospective basis. Early adoption is permitted. We are currently evaluating whether this standard will have a material impact on our condensed consolidated financial statements.

[0001327567-17-000018:notes:50]
[same as prior period, unchanged from 0001327567-17-000007:notes:38]

[0001327567-17-000018:notes:51]
[same as prior period, unchanged from 0001327567-17-000007:notes:39]

[0001327567-17-000018:notes:52]
[same as prior period, unchanged from 0001327567-17-000007:notes:40]

[0001327567-17-000018:notes:53]
[same as prior period, unchanged from 0001327567-17-000007:notes:41]

[0001327567-17-000018:notes:54]
In May 2014, the FASB issued new authoritative guidance on revenue from contracts with customers. The new standard provides principles for recognizing revenue for the transfer of promised goods or services to customers with the consideration to which the entity expects to be entitled in exchange for those goods or services. The standard also requires significantly expanded disclosures about revenue recognition. The FASB subsequently delayed the effective date of the standard by one year and as a result, the standard is now effective for us for our first quarter of fiscal 2019 using either of two methods: (i) retrospective to each prior reporting period presented with the option to elect certain practical expedients as defined within the guidance; or (ii) retrospective with the cumulative effect of initially applying the guidance recognized at the date of initial application and providing certain additional disclosures as defined per the guidance. Early adoption as of the original effective date is permitted. We do not plan to early adopt, and accordingly, we will adopt the new standard in our first quarter of fiscal 2019. We are continuing to evaluate the impact of the new standard on our accounting policies, processes, and system requirements, and have assigned cross-functional internal resources and engaged third-party service providers to assist in our evaluation and system implementation. Furthermore, we have made and will continue to make investments in systems to enable timely and accurate reporting under the new standard. We are also continuing to evaluate adoption methods and the potential impact that the implementation of this standard will have on our condensed consolidated financial statements, but have not yet determined whether the effect will be material. However, we believe this new standard will impact our accounting for revenue arrangements in the following areas:

[0001327567-17-000018:notes:55]
| • | removal of the current limitation on contingent revenue may result in revenue being recognized earlier for certain contracts; |

[0001327567-17-000018:notes:56]
| • | term license revenue associated with our virtual firewalls will be recognized upfront; |

[0001327567-17-000018:notes:57]
| • | allocation of revenue related to software due to the removal of the residual method of revenue recognition; and |

[0001327567-17-000018:notes:58]
| • | amortization period for deferred commissions. |

[0001327567-17-000018:notes:59]
We will continue to assess the new standard along with industry trends and additional interpretive guidance, and may adjust our implementation plan accordingly. We expect to finalize our adoption method and assessment of the impact that the implementation of this standard will have on our condensed consolidated financial statements by the end of fiscal 2017.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001327567-17-000018:notes:60]
Commitments and Contingencies

[0001327567-17-000018:notes:61]
Leases

[0001327567-17-000018:notes:62]
We lease our facilities under various non-cancelable operating leases, which expire through the year ending July 31, 2028.

[0001327567-17-000018:notes:63]
The following table presents details of the aggregate future non-cancelable minimum rental payments under our operating leases as of April 30, 2017 (in millions):

[0001327567-17-000018:notes:64]
|  | Amount |
| Fiscal years ending July 31: |  |
| Remaining 2017 | $ | 7.2 |  |
| 2018 | 29.7 |  |
| 2019 | 48.8 |  |
| 2020 | 52.2 |  |
| 2021 | 56.5 |  |
| 2022 and thereafter | 318.5 |  |
| Committed gross lease payments | 512.9 |  |
| Less: proceeds from sublease rental | 2.9 |  |
| Net operating lease obligation | $ | 510.0 |  |

[0001327567-17-000018:notes:65]
Manufacturing Purchase Commitments

[0001327567-17-000018:notes:66]
Our independent contract manufacturer procures components and assembles our products based on our forecasts. These forecasts are based on estimates of demand for our products primarily for the next 12 months, which are in turn based on historical trends and an analysis from our sales and product marketing organizations, adjusted for overall market conditions. In order to reduce manufacturing lead times and plan for adequate supply, we may issue non-cancelable orders for components and products to our independent contract manufacturer, original design manufacturers, or component suppliers. As of April 30, 2017, our purchase commitments under such orders were $104.3 million, excluding obligations under contracts that we can cancel without a significant penalty.

[0001327567-17-000018:notes:67]
Litigation

[0001327567-17-000018:notes:68]
We are subject to legal proceedings, claims, and litigation arising in the ordinary course of business, including intellectual property litigation. Such matters are subject to many uncertainties and outcomes are not predictable with assurance. We accrue for contingencies when we believe that a loss is probable and that we can reasonably estimate the amount of any such loss.

[0001327567-17-000018:notes:69]
To the extent there is a reasonable possibility that a loss exceeding amounts already recognized may be incurred and the amount of such additional loss would be material, we will either disclose the estimated additional loss or state that such an estimate cannot be made. As of April 30, 2017, we have not recorded any significant accruals for loss contingencies associated with such legal proceedings, determined that an unfavorable outcome is probable or reasonably possible, or determined that the amount or range of any possible loss is reasonably estimable.


## us-gaap:ConvertibleDebtTableTextBlock

[0001327567-17-000018:notes:70]
The following table sets forth the components of the Notes as of April 30, 2017 and July 31, 2016 (in millions):

[0001327567-17-000018:notes:71]
|  | April 30, 2017 |  | July 31, 2016 |
| Liability: |  |  |  |
| Principal | $ | 575.0 |  |  | $ | 575.0 |  |
| Less: debt discount and debt issuance costs, net of amortization | 56.6 |  |  | 74.8 |  |
| Net carrying amount | $ | 518.4 |  |  | $ | 500.2 |  |
| Equity | $ | 109.8 |  |  | $ | 109.8 |  |


## us-gaap:DebtDisclosureTextBlock

[0001327567-17-000018:notes:72]
Convertible Senior Notes

[0001327567-17-000018:notes:73]
On June 30, 2014, we issued $575.0 million aggregate principal amount of 0.0% Convertible Senior Notes due 2019 (the “Notes”). The Notes mature on July 1, 2019, unless converted or repurchased in accordance with their terms prior to such date. The Notes do not contain any financial covenants and we cannot redeem the Notes prior to maturity.

[0001327567-17-000018:notes:74]
The Notes are convertible for up to 5.2 million shares of our common stock at an initial conversion price of approximately $110.28 per share of common stock, subject to adjustment. Holders of the Notes may surrender their Notes for conversion at their option at any time prior to the close of business on the business day immediately preceding January 1, 2019, only under the following circumstances:

[0001327567-17-000018:notes:75]
| • | if the last reported sale price of our common stock for at least 20 trading days (whether or not consecutive) during a period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the conversion price for the Notes on each applicable trading day (the “sale price condition”); |

[0001327567-17-000018:notes:76]
| • | during the five business day period after any five consecutive trading day period, in which the trading price per $1,000 principal amount of Notes for each trading day of the measurement period was less than 98% of the product of the last reported sale price of our common stock and the conversion rate for the Notes on each such trading day; or |

[0001327567-17-000018:notes:77]
| • | upon the occurrence of specified corporate events. |

[0001327567-17-000018:notes:78]
On or after January 1, 2019, holders may convert all or any portion of their Notes at any time prior to the close of business on the second scheduled trading day immediately preceding the maturity date regardless of the foregoing conditions. Upon conversion, holders will receive cash equal to the aggregate principal amount of the Notes to be converted, and, at our election, cash and/or shares of our common stock for any amounts in excess of the aggregate principal amount of the Notes being converted.

[0001327567-17-000018:notes:79]
The sale price condition was not met during the fiscal quarter ended April 30, 2017. Since the Notes were not convertible, the net carrying amount of the Notes was classified as a long-term liability and the equity component was included in additional paid-in capital in our condensed consolidated balance sheets as of April 30, 2017.

[0001327567-17-000018:notes:80]
The total estimated fair value of the Notes was $671.3 million and $761.9 million at April 30, 2017 and July 31, 2016, respectively. The fair value was determined based on the closing trading price per $100 of the Notes as of the last day of trading for the period. We consider the fair value of the Notes at April 30, 2017 and July 31, 2016 to be a Level 2 measurement. The fair value of the Notes is primarily affected by the trading price of our common stock and market interest rates. As of April 30, 2017, the if-converted value of the Notes exceeded its principal amount by $7.7 million.

[0001327567-17-000018:notes:81]
The following table sets forth interest expense recognized related to the Notes (dollars in millions):

[0001327567-17-000018:notes:82]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 30, |  | April 30, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Amortization of debt discount | $ | 5.5 |  |  | $ | 5.3 |  |  | $ | 16.4 |  |  | $ | 15.7 |  |
| Amortization of debt issuance costs | 0.7 |  |  | 0.6 |  |  | 1.9 |  |  | 1.7 |  |
| Total interest expense recognized | $ | 6.2 |  |  | $ | 5.9 |  |  | $ | 18.3 |  |  | $ | 17.4 |  |
| Effective interest rate of the liability component | 4.8 | % |  | 4.8 | % |  | 4.8 | % |  | 4.8 | % |

[0001327567-17-000018:notes:83]
Note Hedges

[0001327567-17-000018:notes:84]
To minimize the impact of potential economic dilution upon conversion of the Notes, we entered into convertible note hedge transactions (the “Note Hedges”) with respect to our common stock concurrent with the issuance of the Notes. The Note Hedges cover up to 5.2 million shares of our common stock and are exercisable upon conversion of the Notes. The Note Hedges will expire upon maturity of the Notes. The Note Hedges are separate transactions and are not part of the terms of the Notes. Holders of the Notes will not have any rights with respect to the Note Hedges. The shares receivable related to the Note Hedges are excluded from the calculation of diluted earnings per share as they are antidilutive.

[0001327567-17-000018:notes:85]
Warrants

[0001327567-17-000018:notes:86]
Separately, but concurrently with our issuance of the Notes, we entered into transactions whereby we sold warrants (the “Warrants”) to acquire up to 5.2 million shares of our common stock at a strike price of approximately $137.85 per share, subject to adjustments. The shares issuable under the Warrants will be included in the calculation of diluted earnings per share when the average market value per share of our common stock for the reporting period exceeds the strike price of the Warrants. The Warrants are separate transactions and are not part of the Notes or Note Hedges, and are not remeasured through earnings each reporting period. Holders of the Notes and Note Hedges will not have any rights with respect to the Warrants.

[0001327567-17-000018:notes:87]
For more information on the Notes, the Note Hedges, and the Warrants, refer to Note 7. Convertible Senior Notes included in Part II, Item 8 of our Annual Report on Form 10-K for the fiscal year ended July 31, 2016.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001327567-17-000018:notes:88]
[same as prior period, unchanged from 0001327567-17-000007:notes:71]

[0001327567-17-000018:notes:89]
[same as prior period, unchanged from 0001327567-17-000007:notes:72]

[0001327567-17-000018:notes:90]
[same as prior period, unchanged from 0001327567-17-000007:notes:73]

[0001327567-17-000018:notes:91]
[same as prior period, unchanged from 0001327567-17-000007:notes:74]

[0001327567-17-000018:notes:92]
Beginning August 2016, we entered into forward contracts to hedge the foreign currency exchange rate risk arising from our euro-denominated expenditures to be incurred during the fiscal year ending July 31, 2017. As of April 30, 2017, the total notional amount of our outstanding foreign currency forward contracts was $37.5 million. Refer to Note 2. Fair Value Measurements for the fair value of our derivative instruments as reported in our condensed consolidated balance sheets as of April 30, 2017.

[0001327567-17-000018:notes:93]
During the three and nine months ended April 30, 2017, both unrealized losses recognized in AOCI related to the effective portion of our cash flow hedges and amounts reclassified into earnings were not material. Total unrealized losses in AOCI related to the effective portion of our cash flow hedges as of April 30, 2017 were also not material.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001327567-17-000018:notes:94]
[same as prior period, unchanged from 0001327567-17-000007:notes:77]

[0001327567-17-000018:notes:95]
[same as prior period, unchanged from 0001327567-17-000007:notes:78]

[0001327567-17-000018:notes:96]
[same as prior period, unchanged from 0001327567-17-000007:notes:79]

[0001327567-17-000018:notes:97]
|  | Options Outstanding |
|  | Number of Shares |  | Weighted-Average Exercise Price Per Share |  | Weighted-Average Remaining Contractual Term(Years) |  | Aggregate Intrinsic Value |
| Balance—July 31, 2016 | 2.1 |  |  | $ | 13.42 |  |  | 5.2 |  | $ | 244.9 |  |
| Options granted | — |  |  | — |  |  |  |  |  |
| Options forfeited | — |  |  | — |  |  |  |  |  |
| Options exercised | (0.5 | ) |  | 14.23 |  |  |  |  |  |
| Balance—April 30, 2017 | 1.6 |  |  | $ | 13.20 |  |  | 4.5 |  | $ | 156.7 |  |
| Options exercisable—April 30, 2017 | 1.6 |  |  | $ | 13.20 |  |  | 4.5 |  | $ | 156.7 |  |

[0001327567-17-000018:notes:98]
[same as prior period, unchanged from 0001327567-17-000007:notes:81]

[0001327567-17-000018:notes:99]
In October 2016, we granted PSAs to certain employees, which will vest over a period of four years from the date of grant. The actual number of PSAs earned and eligible to vest will be determined based on level of achievement against a pre-established billings target for the fiscal year ending July 31, 2017, with a maximum of 0.2 million shares issuable at the end of the performance period. Share-based compensation expense for our PSAs is recognized on a straight-line basis over the requisite service period for each separately vesting portion of the award when it is probable that the performance condition will be achieved.

[0001327567-17-000018:notes:100]
In February 2017, we began to net-share settle equity awards held by certain employees by withholding shares upon vesting to satisfy tax withholding obligations. The shares withheld to satisfy employee tax withholding obligations are returned to our 2012 Equity Incentive Plan (our “2012 Plan”) and will be available for future issuance under our 2012 Plan. Payments for employees’ tax obligations to the tax authorities are reflected as financing activities in our condensed consolidated statements of cash flows.

[0001327567-17-000018:notes:101]
[same as prior period, unchanged from 0001327567-17-000007:notes:83]

[0001327567-17-000018:notes:102]
|  | RSAs and PSAs Outstanding |  | RSUs Outstanding |
|  | Number of Shares |  | Weighted-Average Grant-Date Fair Value Per Share |  | Number of Shares |  | Weighted-Average Grant-Date Fair Value Per Share |  | Weighted-Average Remaining Contractual Term(Years) |  | Aggregate Intrinsic Value |
| Balance—July 31, 2016 | 1.1 |  |  | $ | 170.97 |  |  | 6.5 |  |  | $ | 130.14 |  |  | 1.1 |  | $ | 852.7 |  |
| Granted(1) | 0.3 |  |  | 148.54 |  |  | 2.8 |  |  | 143.28 |  |  |  |  |  |
| Vested | (0.3 | ) |  | 170.97 |  |  | (2.6 | ) |  | 118.53 |  |  |  |  |  |
| Forfeited | — |  |  | — |  |  | (0.4 | ) |  | 137.88 |  |  |  |  |  |
| Balance—April 30, 2017 | 1.1 |  |  | $ | 164.24 |  |  | 6.3 |  |  | $ | 140.29 |  |  | 1.3 |  | $ | 687.1 |  |

[0001327567-17-000018:notes:103]
[same as prior period, unchanged from 0001327567-17-000007:notes:85]

[0001327567-17-000018:notes:104]
[same as prior period, unchanged from 0001327567-17-000007:notes:86]

[0001327567-17-000018:notes:105]
[same as prior period, unchanged from 0001327567-17-000007:notes:87]

[0001327567-17-000018:notes:106]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 30, |  | April 30, |
|  | 2017 |  | 2016 |  | 2017(1) |  | 2016 |
| Cost of product revenue | $ | 1.8 |  |  | $ | 1.6 |  |  | $ | 5.5 |  |  | $ | 4.5 |  |
| Cost of subscription and support revenue | 14.0 |  |  | 11.5 |  |  | 41.3 |  |  | 29.0 |  |
| Research and development | 37.1 |  |  | 36.0 |  |  | 116.4 |  |  | 95.9 |  |
| Sales and marketing | 46.2 |  |  | 43.8 |  |  | 139.7 |  |  | 110.4 |  |
| General and administrative | 18.3 |  |  | 15.6 |  |  | 55.1 |  |  | 43.5 |  |
| Total share-based compensation | $ | 117.4 |  |  | $ | 108.5 |  |  | $ | 358.0 |  |  | $ | 283.3 |  |

[0001327567-17-000018:notes:107]
[same as prior period, unchanged from 0001327567-17-000007:notes:89]

[0001327567-17-000018:notes:108]
As of April 30, 2017, total compensation cost related to unvested share-based awards not yet recognized was $913.0 million. This cost is expected to be amortized on a straight-line basis over a weighted-average period of approximately 2.5 years.


## us-gaap:EarningsPerShareTextBlock

[0001327567-17-000018:notes:109]
[same as prior period, unchanged from 0001327567-17-000007:notes:91]

[0001327567-17-000018:notes:110]
[same as prior period, unchanged from 0001327567-17-000007:notes:92]

[0001327567-17-000018:notes:111]
[same as prior period, unchanged from 0001327567-17-000007:notes:93]

[0001327567-17-000018:notes:112]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 30, |  | April 30, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Net loss | $ | (60.9 | ) |  | $ | (64.1 | ) |  | $ | (178.4 | ) |  | $ | (161.3 | ) |
| Weighted-average shares used to compute net loss per share, basic and diluted | 91.0 |  |  | 87.8 |  |  | 90.5 |  |  | 86.5 |  |
| Net loss per share, basic and diluted | $ | (0.67 | ) |  | $ | (0.73 | ) |  | $ | (1.97 | ) |  | $ | (1.86 | ) |

[0001327567-17-000018:notes:113]
[same as prior period, unchanged from 0001327567-17-000007:notes:95]

[0001327567-17-000018:notes:114]
|  | Three and Nine Months Ended |
|  | April 30, |
|  | 2017 |  | 2016 |
| RSUs | 6.3 |  |  | 7.0 |  |
| Convertible senior notes | 5.2 |  |  | 5.2 |  |
| Warrants related to the issuance of convertible senior notes | 5.2 |  |  | 5.2 |  |
| Options to purchase common stock | 1.6 |  |  | 2.3 |  |
| RSAs and PSAs | 1.1 |  |  | 1.1 |  |
| Total | 19.4 |  |  | 20.8 |  |


## us-gaap:FairValueAssetsAndLiabilitiesMeasuredOnRecurringAndNonrecurringBasisTableTextBlock

[0001327567-17-000018:notes:115]
The following table presents the fair value of our financial assets and liabilities using the above input categories as of April 30, 2017 and July 31, 2016 (in millions):

[0001327567-17-000018:notes:116]
|  |  | April 30, 2017 |  | July 31, 2016 |
|  |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Cash equivalents: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. government and agency securities |  | $ | — |  |  | $ | 19.0 |  |  | $ | — |  |  | $ | 19.0 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Total cash equivalents |  | — |  |  | 19.0 |  |  | — |  |  | 19.0 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Short-term investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Commercial paper |  | — |  |  | 15.0 |  |  | — |  |  | 15.0 |  |  | — |  |  | 3.0 |  |  | — |  |  | 3.0 |  |
| Corporate debt securities |  | — |  |  | 160.1 |  |  | — |  |  | 160.1 |  |  | — |  |  | 121.4 |  |  | — |  |  | 121.4 |  |
| U.S. government and agency securities |  | — |  |  | 504.9 |  |  | — |  |  | 504.9 |  |  | — |  |  | 426.8 |  |  | — |  |  | 426.8 |  |
| Total short-term investments |  | — |  |  | 680.0 |  |  | — |  |  | 680.0 |  |  | — |  |  | 551.2 |  |  | — |  |  | 551.2 |  |
| Long-term investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Certificates of deposit |  | — |  |  | 5.4 |  |  | — |  |  | 5.4 |  |  | — |  |  | 5.4 |  |  | — |  |  | 5.4 |  |
| Corporate debt securities |  | — |  |  | 176.1 |  |  | — |  |  | 176.1 |  |  | — |  |  | 166.1 |  |  | — |  |  | 166.1 |  |
| U.S. government and agency securities |  | — |  |  | 537.6 |  |  | — |  |  | 537.6 |  |  | — |  |  | 481.3 |  |  | — |  |  | 481.3 |  |
| Total long-term investments |  | — |  |  | 719.1 |  |  | — |  |  | 719.1 |  |  | — |  |  | 652.8 |  |  | — |  |  | 652.8 |  |
| Total assets measured at fair value |  | $ | — |  |  | $ | 1,418.1 |  |  | $ | — |  |  | $ | 1,418.1 |  |  | $ | — |  |  | $ | 1,204.0 |  |  | $ | — |  |  | $ | 1,204.0 |  |
| Accrued and other liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency forward contracts |  | $ | — |  |  | $ | 1.2 |  |  | $ | — |  |  | $ | 1.2 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Total accrued and other liabilities |  | — |  |  | 1.2 |  |  | — |  |  | 1.2 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Total liabilities measured at fair value |  | $ | — |  |  | $ | 1.2 |  |  | $ | — |  |  | $ | 1.2 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001327567-17-000018:notes:117]
[same as prior period, unchanged from 0001327567-17-000007:notes:99]

[0001327567-17-000018:notes:118]
[same as prior period, unchanged from 0001327567-17-000007:notes:100]

[0001327567-17-000018:notes:119]
[same as prior period, unchanged from 0001327567-17-000007:notes:101]

[0001327567-17-000018:notes:120]
[same as prior period, unchanged from 0001327567-17-000007:notes:102]

[0001327567-17-000018:notes:121]
[same as prior period, unchanged from 0001327567-17-000007:notes:103]

[0001327567-17-000018:notes:122]
Refer to Note 7. Convertible Senior Notes for the carrying amount and estimated fair value of our convertible senior notes as of April 30, 2017 and July 31, 2016.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001327567-17-000018:notes:123]
Goodwill and Intangible Assets

[0001327567-17-000018:notes:124]
Goodwill

[0001327567-17-000018:notes:125]
The following table presents details of our goodwill during the nine months ended April 30, 2017 (in millions):

[0001327567-17-000018:notes:126]
|  | Amount |
| Balance as of July 31, 2016 | $ | 163.5 |  |
| Goodwill acquired | 75.3 |  |
| Balance as of April 30, 2017 | $ | 238.8 |  |

[0001327567-17-000018:notes:127]
Purchased Intangible Assets

[0001327567-17-000018:notes:128]
The following table presents details of our purchased intangible assets as of April 30, 2017 and July 31, 2016 (in millions):

[0001327567-17-000018:notes:129]
|  | April 30, 2017 |  | July 31, 2016 |
|  | Gross Carrying Amount |  | Accumulated Amortization |  | Net Carrying Amount |  | Gross Carrying Amount |  | Accumulated Amortization |  | Net Carrying Amount |
| Developed technology | $ | 69.7 |  |  | $ | (21.3 | ) |  | $ | 48.4 |  |  | $ | 53.1 |  |  | $ | (15.4 | ) |  | $ | 37.7 |  |
| Acquired intellectual property | 8.9 |  |  | (3.6 | ) |  | 5.3 |  |  | 8.9 |  |  | (2.9 | ) |  | 6.0 |  |
| Customer relationships | 2.9 |  |  | (0.1 | ) |  | 2.8 |  |  | — |  |  | — |  |  | — |  |
| In-process research and development held for defensive purposes | 1.9 |  |  | (1.9 | ) |  | — |  |  | 1.9 |  |  | (1.6 | ) |  | 0.3 |  |
| Other | 0.5 |  |  | (0.5 | ) |  | — |  |  | 0.5 |  |  | (0.5 | ) |  | — |  |
| Total purchased intangible assets | $ | 83.9 |  |  | $ | (27.4 | ) |  | $ | 56.5 |  |  | $ | 64.4 |  |  | $ | (20.4 | ) |  | $ | 44.0 |  |

[0001327567-17-000018:notes:130]
We recognized amortization expense of $2.5 million and $7.1 million for the three and nine months ended April 30, 2017, respectively, and $2.3 million and $7.1 million for the three and nine months ended April 30, 2016, respectively.

[0001327567-17-000018:notes:131]
The following table summarizes our estimated future amortization expense of intangible assets as of April 30, 2017 (in millions):

[0001327567-17-000018:notes:132]
|  | Amount |
| Fiscal years ending July 31: |  |
| Remaining 2017 | $ | 2.7 |  |
| 2018 | 10.7 |  |
| 2019 | 10.6 |  |
| 2020 | 10.6 |  |
| 2021 | 8.9 |  |
| 2022 and thereafter | 13.0 |  |
| Total future amortization expense | $ | 56.5 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001327567-17-000018:notes:133]
[same as prior period, unchanged from 0001327567-17-000007:notes:105]

[0001327567-17-000018:notes:134]
Our provision for income taxes for the three and nine months ended April 30, 2017 reflects an effective tax rate of (14.5)% and (9.1)%, respectively. Our effective tax rates for these periods were negative as we recorded a provision for income taxes on year to date losses. The key components of our income tax provision primarily consist of foreign income taxes, withholding taxes, and amortization of our deferred tax charges. Our effective tax rate differs from the U.S. statutory tax rate primarily due to changes in non-deductible share-based compensation, foreign income at other than U.S. tax rates, and changes in our valuation allowance. As compared to the same periods last year, our effective tax rate changed primarily due to changes in our foreign income taxed at other than U.S. rates and our valuation allowance.

[0001327567-17-000018:notes:135]
Our provision for income taxes for the three and nine months ended April 30, 2016 reflects an effective tax rate of (11.9)% and (10.3)%, respectively. Our effective tax rates for these periods were negative as we recorded a provision for income taxes on year to date losses. The key components of our income tax provision primarily consisted of foreign income taxes, withholding taxes, U.S. federal and state income taxes, and amortization of our deferred tax charges. Key components of our effective tax rate consisted of foreign tax losses which derive no benefit, non-deductible share-based compensation, and changes in our valuation allowance.

[0001327567-17-000018:notes:136]
As of April 30, 2017, we had $289.1 million of unrecognized tax benefits, $29.2 million of which would affect income tax expense if recognized, after consideration of our valuation allowance in the United States and other assets. As of July 31, 2016, we had $127.7 million of unrecognized tax benefits, $21.9 million of which would affect income tax expense if recognized, after consideration of our valuation allowance in the United States and other assets. The increase in unrecognized tax benefits since July 31, 2016 relates to positions taken relating to transfer pricing in the current year. As of April 30, 2017, our federal, state, and foreign returns for the tax years 2008 through the current period remain open to examination. Fiscal years outside the normal statute of limitation remain open to audit by tax authorities due to tax attributes generated in earlier years, which have been carried forward and may be audited in subsequent years when utilized. We do not expect our unrecognized tax benefits to change significantly over the next 12 months. We recognize both interest and penalties associated with uncertain tax positions as a component of income tax expense. The ultimate amount and timing of any future cash settlements cannot be predicted with reasonable certainty.


## us-gaap:InvestmentsClassifiedByContractualMaturityDateTableTextBlock

[0001327567-17-000018:notes:137]
The following table summarizes the amortized cost and fair value of our available-for-sale investments as of April 30, 2017, by contractual years-to-maturity (in millions):

[0001327567-17-000018:notes:138]
|  | Amortized Cost |  | Fair Value |
| Due within one year | $ | 699.7 |  |  | $ | 699.0 |  |
| Due between one and three years | 721.5 |  |  | 719.1 |  |
| Total | $ | 1,421.2 |  |  | $ | 1,418.1 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001327567-17-000018:notes:139]
Investments

[0001327567-17-000018:notes:140]
Unrealized losses related to these investments are due to interest rate fluctuations as opposed to credit quality. In addition, we do not intend to sell and it is not likely that we would be required to sell these investments before recovery of their amortized cost basis, which may be at maturity. As a result, there were no other-than-temporary impairments for these investments at April 30, 2017 and July 31, 2016.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001327567-17-000018:notes:141]
[same as prior period, unchanged from 0001327567-17-000007:notes:113]

[0001327567-17-000018:notes:142]
[same as prior period, unchanged from 0001327567-17-000007:notes:114]

[0001327567-17-000018:notes:143]
On August 26, 2016, our board of directors authorized a $500.0 million share repurchase which is funded from available working capital. On February 24, 2017, our board of directors authorized a $500.0 million increase to our repurchase program, bringing the total authorization to $1.0 billion. Repurchases may be made at management’s discretion from time to time on the open market, through privately negotiated transactions, transactions structured through investment banking institutions, block purchase techniques, 10b5-1 trading plans, or a combination of the foregoing. The repurchase authorization will expire on December 31, 2018, and may be suspended or discontinued at any time.

[0001327567-17-000018:notes:144]
During the three and nine months ended April 30, 2017, we repurchased and retired 1.1 million and 2.4 million shares, respectively, of our common stock under the authorization for an aggregate purchase price of $125.0 million and $295.1 million, respectively. The total price of the shares repurchased and related transaction costs are reflected as a reduction to common stock and additional paid-in capital on our condensed consolidated balance sheets. As of April 30, 2017, $704.9 million remained available for future share repurchases under the repurchase authorization.
