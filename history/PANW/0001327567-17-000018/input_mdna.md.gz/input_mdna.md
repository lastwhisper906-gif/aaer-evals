# PANW MD&A — 0001327567-17-000018


## mdna

[0001327567-17-000018:mdna:1]
[same as prior period, unchanged from 0001327567-17-000007:mdna:1]

[0001327567-17-000018:mdna:2]
[same as prior period, unchanged from 0001327567-17-000007:mdna:2]

[0001327567-17-000018:mdna:3]
[same as prior period, unchanged from 0001327567-17-000007:mdna:3]

[0001327567-17-000018:mdna:4]
[same as prior period, unchanged from 0001327567-17-000007:mdna:4]

[0001327567-17-000018:mdna:5]
| • | Results of Operations. A discussion of the nature and trends in our financial results and an analysis of our financial results comparing the three and nine months ended April 30, 2017 to the three and nine months ended April 30, 2016. |

[0001327567-17-000018:mdna:6]
[same as prior period, unchanged from 0001327567-17-000007:mdna:22]

[0001327567-17-000018:mdna:7]
[same as prior period, unchanged from 0001327567-17-000007:mdna:6]

[0001327567-17-000018:mdna:8]
[same as prior period, unchanged from 0001327567-17-000007:mdna:7]

[0001327567-17-000018:mdna:9]
[same as prior period, unchanged from 0001327567-17-000007:mdna:8]

[0001327567-17-000018:mdna:10]
[same as prior period, unchanged from 0001327567-17-000007:mdna:9]

[0001327567-17-000018:mdna:11]
[same as prior period, unchanged from 0001327567-17-000007:mdna:10]

[0001327567-17-000018:mdna:12]
Our Next-Generation Security Platform consists of three major elements: our Next-Generation Firewall, our Advanced Endpoint Protection, and our Threat Intelligence Cloud. Our Next-Generation Firewall delivers application, user, and content visibility and control as well as protection against network-based cyber threats integrated within the firewall through our proprietary hardware and software architecture. Our Advanced Endpoint Protection prevents cyber attacks that aim to run malicious code or exploit software vulnerabilities on a broad variety of fixed and virtual endpoints and servers. Our Threat Intelligence Cloud provides central intelligence capabilities, security for software as a service (“SaaS”) applications, and automated delivery of preventative measures against cyber attacks.

[0001327567-17-000018:mdna:13]
For the third quarter of fiscal 2017 and 2016, total revenue was $431.8 million and $345.8 million, respectively, representing year-over-year growth of 24.9%. Our growth reflects the increased adoption of our hybrid SaaS revenue model, which consists of product, subscription, and support. We believe this model will enable us to benefit from recurring revenues as we continue to grow our installed end-customer base. As of April 30, 2017, we had more than 39,500 end-customers in over 150 countries. Our end-customers represent a broad range of industries, including education, energy, financial services, government entities, healthcare, Internet and media, manufacturing, public sector, and telecommunications, and include some of the largest Fortune 100 and Global 2000 companies in the world. We maintain a field sales force that works closely with our channel partners in developing sales opportunities. We use a two-tiered, indirect fulfillment model whereby we sell our products and services to our distributors, which, in turn, sell to our resellers, which then sell to our end-customers.

[0001327567-17-000018:mdna:14]
Our product revenue was $164.2 million, or 38.0% of total revenue, for the third quarter of fiscal 2017, representing year-over-year growth of 1.3%. Product revenue is generated from sales of our appliances, primarily our Next-Generation Firewall, which is available in physical and virtualized form. Our Next-Generation Firewall incorporates our proprietary PAN-OS operating system, which provides a consistent set of capabilities across our entire product line. Our products are designed for different performance requirements throughout an organization, ranging from our PA-200, which is designed for enterprise remote offices, to our top-of-the-line PA-7080, which is especially suited for very large enterprise deployments and service provider customers. The same firewall functionality that is delivered in our physical appliances is also available in our VM-Series virtual firewalls, which secure virtualized and cloud-based computing environments.

[0001327567-17-000018:mdna:15]
Our subscription and support revenue was $267.6 million, or 62.0% of total revenue, for the third quarter of fiscal 2017, representing year-over-year growth of 45.7%. Our subscriptions provide our end-customers with real-time access to the latest antivirus, intrusion prevention, web filtering, and modern malware prevention capabilities across fixed and mobile devices. When end-customers purchase an appliance, they typically purchase one or more of our subscriptions for additional functionality, as well as support in order to receive ongoing security updates, upgrades, bug fixes, and repairs.

[0001327567-17-000018:mdna:16]
We continue to invest in innovation and extending our platform and, in February 2017, introduced several new products and features. First, we expanded our family of firewalls with the launch of several new appliances: our PA-220, which is designed for small branch offices and remote locations; our PA-800 series, which are ideal for medium-sized networks and branch and remote office environments; our PA-5200 series, which deliver security for high throughput environments in a compact form factor; and the addition of three new VM-Series virtual firewall models, which support cloud and virtualization initiatives ranging from virtualized branch offices to data center and service provider deployments. Additionally, we delivered PAN-OS 8.0, an important software release that expands security for public and private clouds, provides new SaaS application security functionality, and provides the capabilities to prevent the theft and abuse of stolen credentials. We also acquired LightCyber Ltd. (“LightCyber”) in

[0001327567-17-000018:mdna:17]
[same as prior period, unchanged from 0001327567-17-000007:mdna:31]

[0001327567-17-000018:mdna:18]
February 2017. LightCyber’s technology further expands the functionality of our platform through the addition of behavioral analytics, and will be the foundation for a future subscription offering.

[0001327567-17-000018:mdna:19]
[same as prior period, unchanged from 0001327567-17-000007:mdna:18]

[0001327567-17-000018:mdna:20]
[same as prior period, unchanged from 0001327567-17-000007:mdna:19]

[0001327567-17-000018:mdna:21]
[same as prior period, unchanged from 0001327567-17-000007:mdna:20]

[0001327567-17-000018:mdna:22]
|  | April 30, 2017 |  | July 31, 2016 |
|  | (in millions) |
| Total deferred revenue | $ | 1,611.8 |  |  | $ | 1,240.8 |  |
| Cash, cash equivalents, and investments | $ | 2,091.1 |  |  | $ | 1,938.4 |  |

[0001327567-17-000018:mdna:23]
|  | Three Months Ended April 30, |  | Nine Months Ended April 30, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
|  | (dollars in millions) |
| Total revenue | $ | 431.8 |  |  | $ | 345.8 |  |  | $ | 1,252.5 |  |  | $ | 977.7 |  |
| Total revenue year-over-year percentage increase | 24.9 | % |  | 47.7 | % |  | 28.1 | % |  | 51.8 | % |
| Gross margin(2) | 71.4 | % |  | 72.6 | % |  | 73.0 | % |  | 72.6 | % |
| Operating loss(1)(2) | $ | (49.1 | ) |  | $ | (52.5 | ) |  | $ | (152.5 | ) |  | $ | (134.6 | ) |
| Operating margin(1)(2) | (11.4 | )% |  | (15.2 | )% |  | (12.2 | )% |  | (13.8 | )% |
| Billings | $ | 544.1 |  |  | $ | 486.2 |  |  | $ | 1,622.6 |  |  | $ | 1,333.2 |  |
| Billings year-over-year percentage increase | 11.9 | % |  | 60.8 | % |  | 21.7 | % |  | 61.5 | % |
| Cash flow provided by operating activities(2) |  |  |  |  | $ | 629.0 |  |  | $ | 471.3 |  |
| Free cash flow (non-GAAP)(2) |  |  |  |  | $ | 514.8 |  |  | $ | 415.1 |  |

[0001327567-17-000018:mdna:24]
[same as prior period, unchanged from 0001327567-17-000007:mdna:24]

[0001327567-17-000018:mdna:25]
| (1) | Amounts have been adjusted for the three and nine months ended April 30, 2016, as a result of our voluntary change in accounting policy for sales commissions. Refer to Note 1. Description of Business and Summary of Significant Accounting Policies in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information. |

[0001327567-17-000018:mdna:26]
[same as prior period, unchanged from 0001327567-17-000007:mdna:26]

[0001327567-17-000018:mdna:27]
[same as prior period, unchanged from 0001327567-17-000007:mdna:27]

[0001327567-17-000018:mdna:28]
| • | Billings. We define billings as total revenue plus the change in total deferred revenue, net of acquired deferred revenue, during the period. We consider billings to be a key measure used by management to manage our business given our hybrid SaaS revenue model, and believe billings provides investors with an important indicator of the health and visibility of our business because it includes subscription and support revenue, which is recognized ratably over the contractual service period, and product revenue, which is recognized at the time of shipment, provided that all other revenue recognition criteria have been met. We consider billings to be a useful metric for management and |

[0001327567-17-000018:mdna:29]
[same as prior period, unchanged from 0001327567-17-000007:mdna:36]

[0001327567-17-000018:mdna:30]
investors, particularly if we continue to experience increased sales of subscriptions and strong renewal rates for subscription and support offerings, and as we monitor our near term cash flows. While we believe that billings provides useful information to investors and others in understanding and evaluating our operating results in the same manner as our management, it is important to note that other companies, including companies in our industry, may not use billings, may calculate billings differently, may have different billing frequencies, or may use other financial measures to evaluate their performance, all of which could reduce the usefulness of billings as a comparative measure. We calculate billings in the following manner:

[0001327567-17-000018:mdna:31]
|  | Three Months Ended April 30, |  | Nine Months Ended April 30, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
|  | (in millions) |
| Billings: |  |  |  |  |  |  |  |
| Total revenue | $ | 431.8 |  |  | $ | 345.8 |  |  | $ | 1,252.5 |  |  | $ | 977.7 |  |
| Add: change in total deferred revenue, net of acquired deferred revenue | 112.3 |  |  | 140.4 |  |  | 370.1 |  |  | 355.5 |  |
| Billings | $ | 544.1 |  |  | $ | 486.2 |  |  | $ | 1,622.6 |  |  | $ | 1,333.2 |  |

[0001327567-17-000018:mdna:32]
[same as prior period, unchanged from 0001327567-17-000007:mdna:30]

[0001327567-17-000018:mdna:33]
[same as prior period, unchanged from 0001327567-17-000007:mdna:32]

[0001327567-17-000018:mdna:34]
|  | Nine Months Ended April 30, |
|  | 2017 |  | 2016 |
|  | (in millions) |
| Free cash flow (non-GAAP): |  |  |  |
| Net cash provided by operating activities(1) | $ | 629.0 |  |  | $ | 471.3 |  |
| Less: purchases of property, equipment, and other assets | 114.2 |  |  | 56.2 |  |
| Free cash flow (non-GAAP)(1) | $ | 514.8 |  |  | $ | 415.1 |  |
| Net cash used in investing activities | $ | (411.1 | ) |  | $ | (339.3 | ) |
| Net cash provided by (used in) financing activities(1) | $ | (260.3 | ) |  | $ | 42.2 |  |

[0001327567-17-000018:mdna:35]
[same as prior period, unchanged from 0001327567-17-000007:mdna:34]

[0001327567-17-000018:mdna:36]
[same as prior period, unchanged from 0001327567-17-000007:mdna:35]

[0001327567-17-000018:mdna:37]
[same as prior period, unchanged from 0001327567-17-000007:mdna:45]

[0001327567-17-000018:mdna:38]
[same as prior period, unchanged from 0001327567-17-000007:mdna:37]

[0001327567-17-000018:mdna:39]
[same as prior period, unchanged from 0001327567-17-000007:mdna:38]

[0001327567-17-000018:mdna:40]
Due to our early adoption of new share-based payment accounting guidance in the second quarter of fiscal 2017, certain amounts for the nine months ended April 30, 2017 in the tables and discussion that follow reflect an adjustment for the three months ended October 31, 2016. Refer to Note 1. Description of Business and Summary of Significant Accounting Policies in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information.

[0001327567-17-000018:mdna:41]
|  | Three Months Ended April 30, |  | Nine Months Ended April 30, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
|  | Amount |  | % of Revenue |  | Amount(1) |  | % of Revenue(1) |  | Amount |  | % of Revenue |  | Amount(1) |  | % of Revenue(1) |
|  | (dollars in millions) |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 164.2 |  |  | 38.0 | % |  | $ | 162.1 |  |  | 46.9 | % |  | $ | 496.8 |  |  | 39.7 | % |  | $ | 479.7 |  |  | 49.1 | % |
| Subscription and support | 267.6 |  |  | 62.0 | % |  | 183.7 |  |  | 53.1 | % |  | 755.7 |  |  | 60.3 | % |  | 498.0 |  |  | 50.9 | % |
| Total revenue | 431.8 |  |  | 100.0 | % |  | 345.8 |  |  | 100.0 | % |  | 1,252.5 |  |  | 100.0 | % |  | 977.7 |  |  | 100.0 | % |
| Cost of revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product | 49.7 |  |  | 11.5 | % |  | 43.2 |  |  | 12.5 | % |  | 137.7 |  |  | 11.0 | % |  | 126.9 |  |  | 13.0 | % |
| Subscription and support | 74.0 |  |  | 17.1 | % |  | 51.7 |  |  | 14.9 | % |  | 200.4 |  |  | 16.0 | % |  | 141.4 |  |  | 14.4 | % |
| Total cost of revenue(2) | 123.7 |  |  | 28.6 | % |  | 94.9 |  |  | 27.4 | % |  | 338.1 |  |  | 27.0 | % |  | 268.3 |  |  | 27.4 | % |
| Total gross profit | 308.1 |  |  | 71.4 | % |  | 250.9 |  |  | 72.6 | % |  | 914.4 |  |  | 73.0 | % |  | 709.4 |  |  | 72.6 | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | 86.0 |  |  | 19.9 | % |  | 74.0 |  |  | 21.4 | % |  | 260.1 |  |  | 20.8 | % |  | 207.7 |  |  | 21.2 | % |
| Sales and marketing | 226.9 |  |  | 52.5 | % |  | 195.9 |  |  | 56.7 | % |  | 673.7 |  |  | 53.8 | % |  | 537.8 |  |  | 55.0 | % |
| General and administrative | 44.3 |  |  | 10.4 | % |  | 33.5 |  |  | 9.7 | % |  | 133.1 |  |  | 10.6 | % |  | 98.5 |  |  | 10.2 | % |
| Total operating expenses(2) | 357.2 |  |  | 82.8 | % |  | 303.4 |  |  | 87.8 | % |  | 1,066.9 |  |  | 85.2 | % |  | 844.0 |  |  | 86.4 | % |
| Operating loss | (49.1 | ) |  | (11.4 | )% |  | (52.5 | ) |  | (15.2 | )% |  | (152.5 | ) |  | (12.2 | )% |  | (134.6 | ) |  | (13.8 | )% |
| Interest expense | (6.2 | ) |  | (1.4 | )% |  | (5.8 | ) |  | (1.7 | )% |  | (18.3 | ) |  | (1.5 | )% |  | (17.4 | ) |  | (1.8 | )% |
| Other income, net | 2.1 |  |  | 0.5 | % |  | 1.0 |  |  | 0.3 | % |  | 7.3 |  |  | 0.6 | % |  | 5.7 |  |  | 0.6 | % |
| Loss before income taxes | (53.2 | ) |  | (12.3 | )% |  | (57.3 | ) |  | (16.6 | )% |  | (163.5 | ) |  | (13.1 | )% |  | (146.3 | ) |  | (15.0 | )% |
| Provision for income taxes | 7.7 |  |  | 1.8 | % |  | 6.8 |  |  | 2.0 | % |  | 14.9 |  |  | 1.1 | % |  | 15.0 |  |  | 1.5 | % |
| Net loss | $ | (60.9 | ) |  | (14.1 | )% |  | $ | (64.1 | ) |  | (18.6 | )% |  | $ | (178.4 | ) |  | (14.2 | )% |  | $ | (161.3 | ) |  | (16.5 | )% |

[0001327567-17-000018:mdna:42]
[same as prior period, unchanged from 0001327567-17-000007:mdna:41]

[0001327567-17-000018:mdna:43]
[same as prior period, unchanged from 0001327567-17-000007:mdna:42]

[0001327567-17-000018:mdna:44]
[same as prior period, unchanged from 0001327567-17-000007:mdna:43]

[0001327567-17-000018:mdna:45]
|  | Three Months Ended April 30, |  | Nine Months Ended April 30, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Cost of product revenue | $ | 1.8 |  |  | $ | 1.6 |  |  | $ | 5.5 |  |  | $ | 4.5 |  |
| Cost of subscription and support revenue | 14.0 |  |  | 11.5 |  |  | 41.3 |  |  | 29.0 |  |
| Research and development | 37.1 |  |  | 36.0 |  |  | 116.4 |  |  | 95.9 |  |
| Sales and marketing | 46.2 |  |  | 43.8 |  |  | 139.7 |  |  | 110.4 |  |
| General and administrative | 18.3 |  |  | 15.6 |  |  | 55.1 |  |  | 43.5 |  |
| Total share-based compensation | $ | 117.4 |  |  | $ | 108.5 |  |  | $ | 358.0 |  |  | $ | 283.3 |  |

[0001327567-17-000018:mdna:46]
[same as prior period, unchanged from 0001327567-17-000007:mdna:57]

[0001327567-17-000018:mdna:47]
[same as prior period, unchanged from 0001327567-17-000007:mdna:46]

[0001327567-17-000018:mdna:48]
[same as prior period, unchanged from 0001327567-17-000007:mdna:47]

[0001327567-17-000018:mdna:49]
[same as prior period, unchanged from 0001327567-17-000007:mdna:48]

[0001327567-17-000018:mdna:50]
[same as prior period, unchanged from 0001327567-17-000007:mdna:49]

[0001327567-17-000018:mdna:51]
|  | Three Months Ended April 30, |  |  |  |  |  | Nine Months Ended April 30, |  |  |  |  |
|  | 2017 |  | 2016 |  | Change |  | 2017 |  | 2016 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Product | $ | 164.2 |  |  | $ | 162.1 |  |  | $ | 2.1 |  |  | 1.3 | % |  | $ | 496.8 |  |  | $ | 479.7 |  |  | $ | 17.1 |  |  | 3.6 | % |

[0001327567-17-000018:mdna:52]
Product revenue increased slightly for the three and nine months ended April 30, 2017 compared to the three and nine months ended April 30, 2016. The increases in both periods were primarily driven by demand for our newly introduced appliances. The change in product revenue due to pricing was not significant for either period.

[0001327567-17-000018:mdna:53]
[same as prior period, unchanged from 0001327567-17-000007:mdna:53]

[0001327567-17-000018:mdna:54]
[same as prior period, unchanged from 0001327567-17-000007:mdna:54]

[0001327567-17-000018:mdna:55]
|  | Three Months Ended April 30, |  |  |  |  |  | Nine Months Ended April 30, |  |  |  |  |
|  | 2017 |  | 2016 |  | Change |  | 2017 |  | 2016 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Subscription | $ | 143.2 |  |  | $ | 92.6 |  |  | $ | 50.6 |  |  | 54.6 | % |  | $ | 398.7 |  |  | $ | 250.5 |  |  | $ | 148.2 |  |  | 59.2 | % |
| Support | 124.4 |  |  | 91.1 |  |  | 33.3 |  |  | 36.6 | % |  | 357.0 |  |  | 247.5 |  |  | 109.5 |  |  | 44.2 | % |
| Total subscription and support | $ | 267.6 |  |  | $ | 183.7 |  |  | $ | 83.9 |  |  | 45.7 | % |  | $ | 755.7 |  |  | $ | 498.0 |  |  | $ | 257.7 |  |  | 51.7 | % |

[0001327567-17-000018:mdna:56]
Subscription and support revenue increased for the three and nine months ended April 30, 2017 compared to the three and nine months ended April 30, 2016. The increases in both periods were due to increased demand for our subscription and support offerings from both new and existing end-customers. The mix between subscription revenue and support revenue will fluctuate over time, depending on the introduction of new subscription offerings, renewals of support services, and our ability to increase sales to new and existing customers. The change in subscription and support revenue due to changes in pricing was not significant for either period.

[0001327567-17-000018:mdna:57]
[same as prior period, unchanged from 0001327567-17-000007:mdna:68]

[0001327567-17-000018:mdna:58]
[same as prior period, unchanged from 0001327567-17-000007:mdna:58]

[0001327567-17-000018:mdna:59]
|  | Three Months Ended April 30, |  |  |  |  |  | Nine Months Ended April 30, |  |  |  |  |
|  | 2017 |  | 2016 |  | Change |  | 2017 |  | 2016 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Americas | $ | 299.9 |  |  | $ | 246.3 |  |  | $ | 53.6 |  |  | 21.8 | % |  | $ | 875.1 |  |  | $ | 687.3 |  |  | $ | 187.8 |  |  | 27.3 | % |
| EMEA | 81.1 |  |  | 61.4 |  |  | 19.7 |  |  | 32.1 | % |  | 230.6 |  |  | 177.2 |  |  | 53.4 |  |  | 30.1 | % |
| APAC | 50.8 |  |  | 38.1 |  |  | 12.7 |  |  | 33.3 | % |  | 146.8 |  |  | 113.2 |  |  | 33.6 |  |  | 29.7 | % |
| Total revenue | $ | 431.8 |  |  | $ | 345.8 |  |  | $ | 86.0 |  |  | 24.9 | % |  | $ | 1,252.5 |  |  | $ | 977.7 |  |  | $ | 274.8 |  |  | 28.1 | % |

[0001327567-17-000018:mdna:60]
With respect to geographic theaters, the Americas contributed the largest portion of the increase in revenue for the three and nine months ended April 30, 2017 compared to the three and nine months ended April 30, 2016, due to its larger and more established sales force compared to our other theaters. Revenue from both Europe, the Middle East, and Africa (“EMEA”) and Asia Pacific and Japan (“APAC”) increased for the three and nine months ended April 30, 2017 compared to the three and nine months ended April 30, 2016, due to our investment in increasing the size of our sales force and number of channel partners in these theaters.

[0001327567-17-000018:mdna:61]
[same as prior period, unchanged from 0001327567-17-000007:mdna:61]

[0001327567-17-000018:mdna:62]
[same as prior period, unchanged from 0001327567-17-000007:mdna:62]

[0001327567-17-000018:mdna:63]
[same as prior period, unchanged from 0001327567-17-000007:mdna:63]

[0001327567-17-000018:mdna:64]
[same as prior period, unchanged from 0001327567-17-000007:mdna:64]

[0001327567-17-000018:mdna:65]
|  | Three Months Ended April 30, |  |  |  | Nine Months Ended April 30, |  |  |  |  |
|  | 2017 |  | 2016 |  | Change |  | 2017 |  | 2016 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Cost of product revenue | $ | 49.7 |  |  | $ | 43.2 |  |  | $ | 6.5 |  |  | 15.0 | % |  | $ | 137.7 |  |  | $ | 126.9 |  |  | $ | 10.8 |  |  | 8.5 | % |
| Number of employees at period end | 94 |  |  | 86 |  |  | 8 |  |  | 9.3 | % |  | 94 |  |  | 86 |  |  | 8 |  |  | 9.3 | % |

[0001327567-17-000018:mdna:66]
Cost of product revenue increased for the three and nine months ended April 30, 2017 compared to the three and nine months ended April 30, 2016. The increases in both periods were primarily due to higher product costs related to our newly introduced appliances. The remaining increase for the nine months ended April 30, 2017 compared to the nine months ended April 30, 2016 was primarily driven by an increase in personnel costs due to headcount growth.

[0001327567-17-000018:mdna:67]
[same as prior period, unchanged from 0001327567-17-000007:mdna:80]

[0001327567-17-000018:mdna:68]
[same as prior period, unchanged from 0001327567-17-000007:mdna:69]

[0001327567-17-000018:mdna:69]
[same as prior period, unchanged from 0001327567-17-000007:mdna:70]

[0001327567-17-000018:mdna:70]
|  | Three Months Ended April 30, |  |  |  | Nine Months Ended April 30, |  |  |  |  |
|  | 2017 |  | 2016 |  | Change |  | 2017 |  | 2016 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Cost of subscription and support revenue | $ | 74.0 |  |  | $ | 51.7 |  |  | $ | 22.3 |  |  | 43.1 | % |  | $ | 200.4 |  |  | $ | 141.4 |  |  | $ | 59.0 |  |  | 41.7 | % |
| Number of employees at period end | 668 |  |  | 514 |  |  | 154 |  |  | 30.0 | % |  | 668 |  |  | 514 |  |  | 154 |  |  | 30.0 | % |

[0001327567-17-000018:mdna:71]
Cost of subscription and support revenue increased for the three and nine months ended April 30, 2017 compared to the three and nine months ended April 30, 2016. The increases in both periods were driven by increases in personnel costs, which grew $9.7 million to $39.5 million for the three months ended April 30, 2017 compared to the three months ended April 30, 2016 and grew $34.9 million to $113.9 million for the nine months ended April 30, 2017 compared to the nine months ended April 30, 2016. The increases in personnel costs in both periods were primarily due to headcount growth. The remaining increases in both periods were primarily due to costs to expand our customer service capabilities and infrastructure, customer support costs, and allocated costs. The increases in allocated costs in both periods were primarily due to our expansion of facilities to support the growth of our business.

[0001327567-17-000018:mdna:72]
[same as prior period, unchanged from 0001327567-17-000007:mdna:73]

[0001327567-17-000018:mdna:73]
[same as prior period, unchanged from 0001327567-17-000007:mdna:74]

[0001327567-17-000018:mdna:74]
|  | Three Months Ended April 30, |  | Nine Months Ended April 30, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
|  | Amount |  | Gross Margin |  | Amount |  | Gross Margin |  | Amount |  | Gross Margin |  | Amount |  | Gross Margin |
|  | (dollars in millions) |
| Product | $ | 114.5 |  |  | 69.7 | % |  | $ | 118.9 |  |  | 73.4 | % |  | $ | 359.1 |  |  | 72.3 | % |  | $ | 352.8 |  |  | 73.5 | % |
| Subscription and support | 193.6 |  |  | 72.3 | % |  | 132.0 |  |  | 71.9 | % |  | 555.3 |  |  | 73.5 | % |  | 356.6 |  |  | 71.6 | % |
| Total gross profit | $ | 308.1 |  |  | 71.4 | % |  | $ | 250.9 |  |  | 72.6 | % |  | $ | 914.4 |  |  | 73.0 | % |  | $ | 709.4 |  |  | 72.6 | % |

[0001327567-17-000018:mdna:75]
Product gross margin decreased for the three and nine months ended April 30, 2017 compared to the three and nine months ended April 30, 2016. The decreases in both periods were due to higher product costs related to our newly introduced appliances, which will have lower product margins.

[0001327567-17-000018:mdna:76]
Subscription and support gross margin increased for the three and nine months ended April 30, 2017 compared to the three and nine months ended April 30, 2016. The increases in both periods were due to contributions from our higher margin subscription offerings.

[0001327567-17-000018:mdna:77]
[same as prior period, unchanged from 0001327567-17-000007:mdna:78]

[0001327567-17-000018:mdna:78]
Our operating expenses consist of research and development, sales and marketing, and general and administrative expense. Personnel costs are the most significant component of operating expenses and consist of salaries, benefits, bonuses, share-based compensation, travel and entertainment, and with regard to sales and marketing expense, sales commissions. Our operating expenses also include allocated costs, which consist of certain facilities, depreciation, benefits, recruiting, and information

[0001327567-17-000018:mdna:79]
[same as prior period, unchanged from 0001327567-17-000007:mdna:92]

[0001327567-17-000018:mdna:80]
technology costs that we allocate based on headcount. We expect operating expenses to increase in absolute dollars and decrease over the long term as a percentage of revenue as we continue to scale our business. As of April 30, 2017, we expect to recognize approximately $913.0 million of share-based compensation expense over a weighted-average period of approximately 2.5 years, excluding additional share-based compensation expense related to any future grants of share-based awards. Share-based compensation expense is generally recognized on a straight-line basis over the requisite service periods of the awards.

[0001327567-17-000018:mdna:81]
[same as prior period, unchanged from 0001327567-17-000007:mdna:82]

[0001327567-17-000018:mdna:82]
[same as prior period, unchanged from 0001327567-17-000007:mdna:83]

[0001327567-17-000018:mdna:83]
|  | Three Months Ended April 30, |  |  |  |  |  | Nine Months Ended April 30, |  |  |  |  |
|  | 2017 |  | 2016 |  | Change |  | 2017 |  | 2016 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Research and development | $ | 86.0 |  |  | $ | 74.0 |  |  | $ | 12.0 |  |  | 16.2 | % |  | $ | 260.1 |  |  | $ | 207.7 |  |  | $ | 52.4 |  |  | 25.2 | % |
| Number of employees at period end | 728 |  |  | 601 |  |  | 127 |  |  | 21.1 | % |  | 728 |  |  | 601 |  |  | 127 |  |  | 21.1 | % |

[0001327567-17-000018:mdna:84]
Research and development expense increased for the three months ended April 30, 2017 compared to the three months ended April 30, 2016, primarily due to an increase in personnel costs, which grew $8.1 million to $70.8 million, largely due to headcount growth. The remaining increase was primarily driven by an increase in allocated costs, due to our expansion of facilities to support the growth of our business.

[0001327567-17-000018:mdna:85]
Research and development expense increased for the nine months ended April 30, 2017 compared to the nine months ended April 30, 2016, primarily due to an increase in personnel costs, which grew $41.3 million to $216.7 million, largely due to headcount growth. The remaining increase was primarily driven by an increase in allocated costs, due to our expansion of facilities to support the growth of our business, and development costs related to investments in our new and future offerings.

[0001327567-17-000018:mdna:86]
[same as prior period, unchanged from 0001327567-17-000007:mdna:86]

[0001327567-17-000018:mdna:87]
[same as prior period, unchanged from 0001327567-17-000007:mdna:87]

[0001327567-17-000018:mdna:88]
|  | Three Months Ended April 30, |  |  |  |  |  | Nine Months Ended April 30, |  |  |  |  |
|  | 2017 |  | 2016 |  | Change |  | 2017 |  | 2016 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Sales and marketing(1) | $ | 226.9 |  |  | $ | 195.9 |  |  | $ | 31.0 |  |  | 15.8 | % |  | $ | 673.7 |  |  | $ | 537.8 |  |  | $ | 135.9 |  |  | 25.3 | % |
| Number of employees at period end | 2,327 |  |  | 1,972 |  |  | 355 |  |  | 18.0 | % |  | 2,327 |  |  | 1,972 |  |  | 355 |  |  | 18.0 | % |

[0001327567-17-000018:mdna:89]
[same as prior period, unchanged from 0001327567-17-000007:mdna:89]

[0001327567-17-000018:mdna:90]
[same as prior period, unchanged from 0001327567-17-000007:mdna:90]

[0001327567-17-000018:mdna:91]
Sales and marketing expense increased for the three months ended April 30, 2017 compared to the three months ended April 30, 2016, primarily due to an increase in personnel costs, which grew $26.5 million to $177.3 million, largely due to headcount growth. The remaining increase was primarily driven by an increase in allocated costs, due to our expansion of facilities to support the growth of our business.

[0001327567-17-000018:mdna:92]
[same as prior period, unchanged from 0001327567-17-000007:mdna:103]

[0001327567-17-000018:mdna:93]
Sales and marketing expense increased for the nine months ended April 30, 2017 compared to the nine months ended April 30, 2016, primarily due to an increase in personnel costs, which grew $115.2 million to $522.3 million, largely due to headcount growth. The remaining increase was primarily driven by an increase in allocated costs, due to our expansion of facilities to support the growth of our business, and an increase in demand generation activities and sales related events to support our revenue growth.

[0001327567-17-000018:mdna:94]
[same as prior period, unchanged from 0001327567-17-000007:mdna:93]

[0001327567-17-000018:mdna:95]
[same as prior period, unchanged from 0001327567-17-000007:mdna:94]

[0001327567-17-000018:mdna:96]
|  | Three Months Ended April 30, |  |  |  |  |  | Nine Months Ended April 30, |  |  |  |  |
|  | 2017 |  | 2016 |  | Change |  | 2017 |  | 2016 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| General and administrative | $ | 44.3 |  |  | $ | 33.5 |  |  | $ | 10.8 |  |  | 32.2 | % |  | $ | 133.1 |  |  | $ | 98.5 |  |  | $ | 34.6 |  |  | 35.1 | % |
| Number of employees at period end | 523 |  |  | 418 |  |  | 105 |  |  | 25.1 | % |  | 523 |  |  | 418 |  |  | 105 |  |  | 25.1 | % |

[0001327567-17-000018:mdna:97]
General and administrative expense increased for the three and nine months ended April 30, 2017 compared to the three and nine months ended April 30, 2016. The increases in both periods were driven by increases in personnel costs, which grew $6.5 million to $31.1 million for the three months ended April 30, 2017 compared to the three months ended April 30, 2016 and grew $25.8 million to $96.5 million for the nine months ended April 30, 2017 compared to the nine months ended April 30, 2016. The increases in personnel costs in both periods were primarily due to headcount growth. The remaining increases in both periods were primarily driven by increases in allocated costs, due to our expansion of facilities to support the growth of our business, and professional services costs related to our acquisition of LightCyber.

[0001327567-17-000018:mdna:98]
[same as prior period, unchanged from 0001327567-17-000007:mdna:97]

[0001327567-17-000018:mdna:99]
[same as prior period, unchanged from 0001327567-17-000007:mdna:98]

[0001327567-17-000018:mdna:100]
|  | Three Months Ended April 30, |  | Change |  | Nine Months Ended April 30, |  | Change |
|  | 2017 |  | 2016 |  | Amount |  | % |  | 2017 |  | 2016 |  | Amount |  | % |
|  | (dollars in millions) |
| Provision for income taxes | $ | 7.7 |  |  | $ | 6.8 |  |  | $ | 0.9 |  |  | 13.2 | % |  | $ | 14.9 |  |  | $ | 15.0 |  |  | $ | (0.1 | ) |  | (0.7 | )% |
| Effective tax rate(1) | (14.5 | )% |  | (11.9 | )% |  |  |  |  |  |  | (9.1 | )% |  | (10.3 | )% |  |  |  |  |  |

[0001327567-17-000018:mdna:101]
[same as prior period, unchanged from 0001327567-17-000007:mdna:100]

[0001327567-17-000018:mdna:102]
[same as prior period, unchanged from 0001327567-17-000007:mdna:101]

[0001327567-17-000018:mdna:103]
We recorded an income tax provision for the three and nine months ended April 30, 2017, due to foreign income taxes, withholding taxes, and amortization of our deferred tax charges. The provision for income taxes increased for the three months ended April 30, 2017 compared to the three months ended April 30, 2016, primarily due to an increase in profits in our taxable jurisdictions and a decrease in tax deductions related to share-based compensation. The provision for income taxes was flat for the nine months ended April 30, 2017 compared to the nine months ended April 30, 2016, primarily due to tax benefits from our early adoption of new share-based payment accounting guidance in the second quarter of fiscal 2017 fully offsetting an increase in profits in our taxable jurisdictions.

[0001327567-17-000018:mdna:104]
[same as prior period, unchanged from 0001327567-17-000007:mdna:116]

[0001327567-17-000018:mdna:105]
[same as prior period, unchanged from 0001327567-17-000007:mdna:104]

[0001327567-17-000018:mdna:106]
|  | April 30, 2017 |  | July 31, 2016 |
|  | (in millions) |
| Working capital(1) | $ | 840.5 |  |  | $ | 927.2 |  |
| Cash, cash equivalents, and investments: |  |  |  |
| Cash and cash equivalents | $ | 692.0 |  |  | $ | 734.4 |  |
| Investments | 1,399.1 |  |  | 1,204.0 |  |
| Total cash, cash equivalents, and investments | $ | 2,091.1 |  |  | $ | 1,938.4 |  |

[0001327567-17-000018:mdna:107]
[same as prior period, unchanged from 0001327567-17-000007:mdna:106]

[0001327567-17-000018:mdna:108]
[same as prior period, unchanged from 0001327567-17-000007:mdna:107]

[0001327567-17-000018:mdna:109]
At April 30, 2017, our total cash, cash equivalents, and investments of $2.1 billion were held for general corporate purposes, of which approximately $180.0 million was held outside of the United States. We do not provide for federal income taxes on the undistributed earnings of our foreign subsidiaries, all of which we expect to reinvest outside of the United States indefinitely. However, if these funds were needed for our domestic operations, we would be required to accrue and pay U.S. taxes on undistributed earnings of foreign subsidiaries. There are no other restrictions on the use of these funds. If we were to repatriate these earnings to the United States, any associated income tax liability would be insignificant.

[0001327567-17-000018:mdna:110]
As of April 30, 2017, all of our 0.0% Convertible Senior Notes due 2019 (the “Notes”) remained outstanding. The Notes mature on July 1, 2019, however, prior to January 1, 2019, holders may surrender their Notes for early conversion under certain circumstances. Upon conversion, we will pay cash equal to the aggregate principal amount of the Notes to be converted, and, at our election, will pay or deliver cash and/or shares of our common stock for the amount of our conversion obligation in excess of the aggregate principal amount of the Notes being converted. Refer to Note 7. Convertible Senior Notes in Part I, Item 1 of this Quarterly Report on Form 10-Q for information on the Notes.

[0001327567-17-000018:mdna:111]
In August 2016, our board of directors authorized a $500.0 million share repurchase and, in February 2017, authorized a $500.0 million increase to our repurchase program, bringing the total authorization to $1.0 billion. Repurchases are funded from available working capital and may be made at management’s discretion from time to time. The repurchase authorization will expire on December 31, 2018, and may be suspended or discontinued at any time. As of April 30, 2017, $704.9 million was available for future share repurchases under the repurchase authorization. Refer to Note 9. Stockholders’ Equity in Part I, Item 1 of this Quarterly Report on Form 10-Q for information on the repurchase authorization.

[0001327567-17-000018:mdna:112]
The following table summarizes our cash flows for the nine months ended April 30, 2017 and 2016.

[0001327567-17-000018:mdna:113]
|  | Nine Months Ended April 30, |
| 2017 |  | 2016 |
|  | (in millions) |
| Net cash provided by operating activities(1) | $ | 629.0 |  |  | $ | 471.3 |  |
| Net cash used in investing activities | (411.1 | ) |  | (339.3 | ) |
| Net cash provided by (used in) financing activities(1) | (260.3 | ) |  | 42.2 |  |
| Net increase (decrease) in cash and cash equivalents | $ | (42.4 | ) |  | $ | 174.2 |  |

[0001327567-17-000018:mdna:114]
[same as prior period, unchanged from 0001327567-17-000007:mdna:114]

[0001327567-17-000018:mdna:115]
[same as prior period, unchanged from 0001327567-17-000007:mdna:115]

[0001327567-17-000018:mdna:116]
We believe that our cash flow from operations with existing cash and cash equivalents will be sufficient to meet our anticipated cash needs for the foreseeable future. Our future capital requirements will depend on many factors including our growth rate, the timing and extent of spending to support development efforts, the expansion of sales and marketing activities, the introduction of new and enhanced products and subscription and support offerings, the costs to acquire or invest in complementary businesses and technologies, the costs to ensure access to adequate manufacturing capacity, the investments in our new corporate

[0001327567-17-000018:mdna:117]
[same as prior period, unchanged from 0001327567-17-000007:mdna:133]

[0001327567-17-000018:mdna:118]
headquarters, and the continuing market acceptance of our products and subscription and support offerings. In addition, from time to time we may incur additional tax liability in connection with certain corporate structuring decisions.

[0001327567-17-000018:mdna:119]
[same as prior period, unchanged from 0001327567-17-000007:mdna:118]

[0001327567-17-000018:mdna:120]
[same as prior period, unchanged from 0001327567-17-000007:mdna:119]

[0001327567-17-000018:mdna:121]
[same as prior period, unchanged from 0001327567-17-000007:mdna:120]

[0001327567-17-000018:mdna:122]
Cash provided by operating activities during the nine months ended April 30, 2017 was $629.0 million, an increase of $157.7 million compared to the nine months ended April 30, 2016. The increase was due to growth of our business, as reflected by an increase in billings, and an increase in collections on accounts receivable during the nine months ended April 30, 2017.

[0001327567-17-000018:mdna:123]
[same as prior period, unchanged from 0001327567-17-000007:mdna:122]

[0001327567-17-000018:mdna:124]
Our investing activities have consisted of capital expenditures, net investment purchases, sales, and maturities, and business acquisitions. We expect to continue such activities as our business grows.

[0001327567-17-000018:mdna:125]
Cash used in investing activities during the nine months ended April 30, 2017 was $411.1 million, an increase of $71.8 million compared to the nine months ended April 30, 2016, due to a net cash payment of $90.7 million for our acquisition of LightCyber and increased investment in facilities to support the growth of our business, partially offset by lower net purchases of available-for-sale investments, during the nine months ended April 30, 2017.

[0001327567-17-000018:mdna:126]
[same as prior period, unchanged from 0001327567-17-000007:mdna:125]

[0001327567-17-000018:mdna:127]
Our financing activities have consisted of proceeds from sales of shares through employee equity incentive plans, cash used to repurchase shares of our common stock, and payments for tax withholding obligations of certain employees related to the net share settlement of equity awards.

[0001327567-17-000018:mdna:128]
Cash used in financing activities during the nine months ended April 30, 2017 was $260.3 million, a change of $302.5 million compared to the nine months ended April 30, 2016, due to the repurchase of $295.1 million of our common stock and payments for tax withholding obligations of certain employees related to the net share settlement of equity awards of $11.0 million during the nine months ended April 30, 2017.

[0001327567-17-000018:mdna:129]
[same as prior period, unchanged from 0001327567-17-000007:mdna:128]

[0001327567-17-000018:mdna:130]
As of April 30, 2017, we did not have any relationships with unconsolidated organizations or financial partnerships, such as structured finance or special purpose entities that would have been established for the purpose of facilitating off-balance sheet arrangements or other contractually narrow or limited purposes.

[0001327567-17-000018:mdna:131]
[same as prior period, unchanged from 0001327567-17-000007:mdna:130]

[0001327567-17-000018:mdna:132]
[same as prior period, unchanged from 0001327567-17-000007:mdna:131]

[0001327567-17-000018:mdna:133]
[same as prior period, unchanged from 0001327567-17-000007:mdna:132]

[0001327567-17-000018:mdna:134]
[same as prior period, unchanged from 0001327567-17-000007:mdna:134]

[0001327567-17-000018:mdna:135]
[same as prior period, unchanged from 0001327567-17-000007:mdna:135]

[0001327567-17-000018:mdna:136]
- 31 -
