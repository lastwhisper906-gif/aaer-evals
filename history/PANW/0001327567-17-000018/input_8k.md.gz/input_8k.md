# PANW 8-K — 0001327567-17-000016 filed 2017-05-31

## item codes, every 8-K on or before 2017-06-01

- 2017-05-31 0001327567-17-000016 — 2.02, 9.01
- 2017-02-28 0001327567-17-000005 — 2.02, 8.01, 9.01
- 2016-12-12 0001193125-16-790757 — 5.07
- 2016-11-21 0001327567-16-000071 — 2.02, 9.01
- 2016-10-24 0001193125-16-745121 — 5.02, 9.01
- 2016-08-30 0001327567-16-000057 — 2.02, 5.03, 8.01, 9.01
- 2016-08-22 0001193125-16-687588 — 5.02, 9.01
- 2016-05-26 0001327567-16-000051 — 2.02, 9.01
- 2016-02-25 0001327567-16-000044 — 2.02, 5.02, 9.01
- 2015-12-14 0001327567-15-000038 — 5.07
- 2015-12-14 0001193125-15-402588 — 1.01, 9.01
- 2015-11-23 0001327567-15-000033 — 2.02, 9.01
- 2015-10-19 0001193125-15-347005 — 1.01, 9.01 — amendment, the index does not say of what
- 2015-09-09 0001327567-15-000022 — 2.02, 9.01
- 2015-08-19 0001193125-15-296115 — 1.01, 2.03
- 2015-06-01 0001193125-15-207786 — 1.01, 2.03
- 2015-05-27 0001327567-15-000015 — 2.02, 9.01
- 2015-03-02 0001327567-15-000006 — 2.02, 9.01
- 2014-12-15 0001327567-14-000046 — 5.07
- 2014-11-24 0001327567-14-000040 — 2.02, 9.01
- 2014-09-22 0001193125-14-348581 — 5.02, 9.01
- 2014-09-09 0001327567-14-000025 — 2.02, 9.01
- 2014-07-01 0001193125-14-257824 — 1.01, 2.03, 3.02, 9.01
- 2014-06-26 0001193125-14-249529 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2014-06-20 0001327567-14-000020 — 9.01 — amendment of 0001193125-14-140511
- 2014-06-04 0001327567-14-000016 — 3.02
- 2014-05-30 0001193125-14-218158 — 2.02 — amendment, the index does not say of what
- 2014-05-28 0001193125-14-215060 — 1.01, 2.02, 3.02, 9.01
- 2014-04-11 0001193125-14-140511 — 2.01, 3.02, 7.01, 9.01
- 2014-03-24 0001193125-14-111318 — 1.01, 3.02, 7.01, 9.01
- 2014-03-13 0001327567-14-000009 — 5.02
- 2014-02-24 0001193125-14-063754 — 2.02, 9.01
- 2013-12-12 0001327567-13-000040 — 5.07
- 2013-11-25 0001327567-13-000033 — 2.02, 9.01
- 2013-09-30 0001193125-13-384966 — 8.01
- 2013-09-09 0001193125-13-361421 — 2.02, 9.01
- 2013-05-30 0001193125-13-241542 — 2.02, 5.02, 9.01
- 2013-03-11 0001193125-13-101082 — 5.02, 9.01
- 2013-02-28 0001193125-13-084193 — 2.02, 9.01
- 2012-12-14 0001193125-12-503335 — 5.07
- 2012-12-06 0001193125-12-493700 — 2.02, 9.01
- 2012-09-24 0001193125-12-401534 — 1.01, 2.03
- 2012-09-20 0001193125-12-398433 — 5.02, 9.01
- 2012-09-10 0001193125-12-386605 — 2.02, 9.01

## late-filing notifications on or before 2017-06-01

- none on or before 2017-06-01

## item 2.02 — earnings release, exhibit 99.1

[0001327567-17-000016:8k_2_02:1]
EX-99.1
2
ex991q317earningsrelease.htm
EXHIBIT 99.1

[0001327567-17-000016:8k_2_02:2]
Exhibit

[0001327567-17-000016:8k_2_02:3]
Exhibit 99.1

[0001327567-17-000016:8k_2_02:4]
Palo Alto Networks Reports Fiscal Third Quarter 2017 Financial Results

[0001327567-17-000016:8k_2_02:5]
| • | Revenue grows 25 percent year over year to $431.8 million |

[0001327567-17-000016:8k_2_02:6]
| • | Billings grow 12 percent year over year to $544.1 million |

[0001327567-17-000016:8k_2_02:7]
| • | Deferred revenue grows 51 percent year over year to $1.6 billion |

[0001327567-17-000016:8k_2_02:8]
| • | Cash flow from operations of $211.2 million, and free cash flow of $162.6 million |

[0001327567-17-000016:8k_2_02:9]
SANTA CLARA, Calif. — May 31, 2017 — Palo Alto Networks® (NYSE: PANW), the next-generation security company, today announced financial results for its fiscal third quarter 2017 ended April 30, 2017.

[0001327567-17-000016:8k_2_02:10]
Total revenue for the fiscal third quarter 2017 grew 25 percent year over year to $431.8 million, compared with total revenue of $345.8 million for the fiscal third quarter 2016. GAAP net loss for the fiscal third quarter 2017 was $60.9 million, or $0.67 per diluted share, compared with GAAP net loss of $64.1 million, or $0.73 per diluted share, for the fiscal third quarter 2016.

[0001327567-17-000016:8k_2_02:11]
Non-GAAP net income for the fiscal third quarter 2017 was $57.1 million, or $0.61 per diluted share, compared with non-GAAP net income of $42.3 million, or $0.46 per diluted share, for the fiscal third quarter 2016. A reconciliation between GAAP and non-GAAP information is contained in the tables below.

[0001327567-17-000016:8k_2_02:12]
“We reported record revenue of $432 million in our fiscal third quarter and added the second highest number of new customers in the company’s history,” said Mark McLaughlin, chief executive officer of Palo Alto Networks. “The integrated and highly automated prevention capabilities of our Next-Generation

[0001327567-17-000016:8k_2_02:13]
Security Platform continue to differentiate us in the market as we help our customers protect our digital way of life.”

[0001327567-17-000016:8k_2_02:14]
“Expansion within our existing customer base and new customer acquisitions in the quarter drove growth in revenue, billings and deferred revenue,” commented Steffan Tomlinson, chief financial officer of Palo Alto Networks. “In addition, we continue to balance growth and profitability, as cash flow from operations totaled $211.2 million in the quarter, free cash flow totaled $162.6 million, and we ended the quarter with cash, cash equivalents and investments of $2.1 billion.”

[0001327567-17-000016:8k_2_02:15]
Recent Highlights

[0001327567-17-000016:8k_2_02:16]
| • | Announced enhancements to our Traps advanced endpoint protection offering – With Traps™ version 4.0, we expanded our multi-method prevention approach to block both known and unknown malware as well as exploits before they compromise endpoints. The enhancements also include the addition of support for macOS® and Android® (beta), plus several new prevention modules designed to detect and stop ransomware and other advanced threats. |

[0001327567-17-000016:8k_2_02:17]
| • | Won the SANS Best of 2016 Award for Next Generation Firewall – Each year SANS surveys its community for nominations for its “Best of the Year” awards for products and services that have been successfully used to provide increases in both the effectiveness and efficiency of cybersecurity programs. The products were voted on by security operations professionals and security managers from around the world, all of whom are actual users of these products, with Palo Alto Networks taking top honors in the Next Generation Firewall category. |

[0001327567-17-000016:8k_2_02:18]
| • | Expanded availability of Aperture SaaS security service to both Europe and APAC – We have made the Aperture™ SaaS security service available in Europe and APAC with new data centers in |

[0001327567-17-000016:8k_2_02:19]
2

[0001327567-17-000016:8k_2_02:20]
Germany and Singapore to alleviate concerns organizations may have in relation to data privacy and data transfer. For any organization operating across international borders, embracing SaaS applications brings security challenges, coupled with data privacy concerns, that can limit the ability to store, share or transfer data outside of the region, even for security purposes.

[0001327567-17-000016:8k_2_02:21]
| • | Joined forces with AT&T, IBM and others to form IoT Cybersecurity Alliance – Recognizing that IoT presents daunting cybersecurity challenges that can jeopardize trust in our digital age, we are pleased to be joining forces with other notable industry leaders, including AT&T, IBM, Nokia, Symantec and Trustonic, to help customers demystify IoT security, share best practices, conduct research and raise awareness of ways to better secure the IoT ecosystem. |

[0001327567-17-000016:8k_2_02:22]
Financial Outlook

[0001327567-17-000016:8k_2_02:23]
Palo Alto Networks provides guidance based on current market conditions and expectations.

[0001327567-17-000016:8k_2_02:24]
For the fiscal fourth quarter 2017, we expect:

[0001327567-17-000016:8k_2_02:25]
| • | Total revenue in the range of $481 to $491 million, representing year-over-year growth between 20 percent and 23 percent. |

[0001327567-17-000016:8k_2_02:26]
| • | Diluted non-GAAP net income per share in the range of $0.78 to $0.80 using 93 to 95 million shares. |

[0001327567-17-000016:8k_2_02:27]
Guidance for non-GAAP financial measures excludes share-based compensation related charges including share-based payroll tax expense, acquisition related costs, amortization expense of acquired intangible assets, litigation-related charges including legal settlements, non-cash interest expense related to our convertible senior notes, foreign currency gains (losses) and income and other tax effects associated with these items, and certain non-recurring expenses. We have not reconciled diluted non-GAAP net income

[0001327567-17-000016:8k_2_02:28]
per share guidance to GAAP net income (loss) per diluted share because we do not provide guidance on GAAP net income (loss) and would not be able to present the various reconciling cash and non-cash items between GAAP net income (loss) and non-GAAP net income (loss), including share-based compensation expense, without unreasonable effort. Share-based compensation expense is impacted by the company’s future hiring and retention needs and, to a lesser extent, the future fair market value of the company’s common stock, all of which is difficult to predict and subject to constant change. The actual amounts of such reconciling items will have a significant impact on the company’s GAAP net income (loss) per diluted share.

[0001327567-17-000016:8k_2_02:29]
Conference Call Information

[0001327567-17-000016:8k_2_02:30]
Palo Alto Networks will host a conference call for analysts and investors to discuss its fiscal third quarter 2017 results and outlook for its fiscal fourth quarter 2017 today at 4:30 p.m. Eastern time/1:30 p.m. Pacific time. Open to the public, investors may access the call by dialing 1-888-438-5448 or 1-719-325-2432 and using conference ID 6536755. A live audio webcast of the conference call, along with supplemental financial information, will also be accessible from the “Investors” section of our website at investors.paloaltonetworks.com. Following the webcast, an archived version will be available on our website for one year. A telephonic replay of the call will be available three hours after the call, will run for ten days, and may be accessed by dialing 1-888-203-1112 or 1-719-457-0820 and entering the passcode 6536755.

[0001327567-17-000016:8k_2_02:31]
Forward-Looking Statements

[0001327567-17-000016:8k_2_02:32]
This press release contains forward-looking statements that involve risks and uncertainties, including statements regarding our future financial and operating performance, including our financial outlook for the fiscal fourth quarter 2017. There are a significant number of factors that could cause actual results to differ materially from statements made in this press release, including: our limited operating history; our

[0001327567-17-000016:8k_2_02:33]
4

[0001327567-17-000016:8k_2_02:34]
ability to identify and effectively implement the necessary changes to address execution challenges; risks associated with managing our rapid growth; our limited experience with new product and subscription and support introductions and the risks associated with new products and subscription and support offerings, including the discovery of software bugs; our ability to attract and retain new customers; the failure to timely develop and achieve market acceptance of new products and subscriptions as well as existing products and subscription and support; rapidly evolving technological developments in the market for network security products and subscription and support offerings; length of sales cycles; and general market, political, economic and business conditions.

[0001327567-17-000016:8k_2_02:35]
Additional risks and uncertainties that could affect our financial results are included under the captions “Risk Factors” and “Management’s Discussion and Analysis of Financial Condition and Results of Operations” in our Quarterly Report on Form 10-Q filed with the SEC on March 1, 2017, which is available on our website at investors.paloaltonetworks.com and on the SEC’s website at www.sec.gov. Additional information will also be set forth in other filings that we make with the SEC from time to time. All forward-looking statements in this press release are based on information available to us as of the date hereof, and we do not assume any obligation to update the forward-looking statements provided to reflect events that occur or circumstances that exist after the date on which they were made.

[0001327567-17-000016:8k_2_02:36]
Non-GAAP Financial Measures and Other Key Metrics

[0001327567-17-000016:8k_2_02:37]
Palo Alto Networks has provided in this press release financial information that has not been prepared in accordance with generally accepted accounting principles in the United States (GAAP). The company uses these non-GAAP financial measures and key metrics internally in analyzing its financial results and believes that the use of these non-GAAP financial measures and key metrics is useful to investors as an additional tool to evaluate ongoing operating results and trends and in comparing the company’s financial

[0001327567-17-000016:8k_2_02:38]
results with other companies in its industry, many of which present similar non-GAAP financial measures or key metrics.

[0001327567-17-000016:8k_2_02:39]
The presentation of these non-GAAP financial measures and key metrics are not meant to be considered in isolation or as a substitute for comparable GAAP financial measures, and should be read only in conjunction with the company’s consolidated financial statements prepared in accordance with GAAP. A reconciliation of the company’s historical non-GAAP financial measures and key metrics to their most directly comparable GAAP measures has been provided in the financial statement tables included in this press release, and investors are encouraged to review these reconciliations.

[0001327567-17-000016:8k_2_02:40]
Non-GAAP net income and net income per share, diluted. Palo Alto Networks defines non-GAAP net income as net income (loss) plus share-based compensation related charges including share-based payroll tax expense, acquisition related costs, amortization expense of acquired intangible assets, litigation related charges including legal settlements, non-cash interest expense related to the company’s convertible senior notes, and intellectual property restructuring related charges. The company also excludes from non-GAAP net income the foreign currency gains (losses) and tax effects associated with these items in order to provide a complete picture of the company’s recurring core business operating results. The company defines non-GAAP net income per share, diluted, as non-GAAP net income divided by the weighted average diluted shares outstanding, which includes the potentially dilutive effect of the company’s employee equity incentive plan awards and the company’s convertible senior notes outstanding, after giving effect to the anti-dilutive impact of the company’s note hedge agreements, which reduces the potential economic dilution that otherwise would occur upon conversion of the company’s convertible senior notes. Under GAAP, the anti-dilutive impact of the note hedge is not reflected in diluted shares outstanding. The company believes that excluding these items from non-GAAP net income and non-GAAP net income per share, diluted, provides management and investors with greater visibility into the

[0001327567-17-000016:8k_2_02:41]
6

[0001327567-17-000016:8k_2_02:42]
underlying performance of the company’s core business operating results, meaning its operating performance excluding these items and, from time to time, other discrete charges that are infrequent in nature, over multiple periods.

[0001327567-17-000016:8k_2_02:43]
Billings. Palo Alto Networks defines billings as total revenue plus the change in total deferred revenue, net of acquired deferred revenue, during the period. The company considers billings to be a key metric used by management to manage the company’s business given the company’s hybrid-SaaS revenue model, and believes billings provides investors with an important indicator of the health and visibility of the company’s business because it includes subscription and support revenue, which is recognized ratably over the contractual service period, and product revenue, which is recognized at the time of shipment, provided that all other revenue recognition criteria have been met. The company considers billings to be a useful metric for management and investors, particularly if sales of subscriptions continue to increase and the company experiences strong renewal rates for subscription and support.

[0001327567-17-000016:8k_2_02:44]
Free cash flow. Palo Alto Networks defines free cash flow as cash provided by operating activities less purchases of property, equipment, and other assets. The company considers free cash flow to be a profitability and liquidity measure that provides useful information to management and investors about the amount of cash generated by the business after necessary capital expenditures.

[0001327567-17-000016:8k_2_02:45]
Investors are cautioned that there are a number of limitations associated with the use of non-GAAP financial measures and key metrics as analytical tools. In particular, the billings metric reported by the company includes amounts that have not yet been recognized as revenue and free cash flow does not represent the total increase or decrease in our cash balance for the period. In addition, many of the adjustments to the company’s GAAP financial measures reflect the exclusion of items that are recurring and will be reflected in the company’s financial results for the foreseeable future, such as share-based

[0001327567-17-000016:8k_2_02:46]
compensation, which is an important part of Palo Alto Networks employees’ compensation and impacts their performance. Furthermore, these non-GAAP financial measures are not based on any standardized methodology prescribed by GAAP, and the components that Palo Alto Networks excludes in its calculation of non-GAAP financial measures may differ from the components that its peer companies exclude when they report their non-GAAP results of operations. Palo Alto Networks compensates for these limitations by providing specific information regarding the GAAP amounts excluded from these non-GAAP financial measures. In the future, the company may also exclude non-recurring expenses and other expenses that do not reflect the company’s core business operating results.

[0001327567-17-000016:8k_2_02:47]
About Palo Alto Networks

[0001327567-17-000016:8k_2_02:48]
Palo Alto Networks is the next-generation security company, leading a new era in cybersecurity by safely enabling applications and preventing cyber breaches for tens of thousands of organizations worldwide. Built with an innovative approach and highly differentiated cyberthreat prevention capabilities, our game-changing security platform delivers security far superior to legacy or point products, safely enables daily business operations, and protects an organization’s most valuable assets. Find out more at www.paloaltonetworks.com.

[0001327567-17-000016:8k_2_02:49]
Palo Alto Networks and the Palo Alto Networks logo are trademarks of Palo Alto Networks, Inc. in the United States and in jurisdictions throughout the world. All other trademarks, trade names or service marks used or mentioned herein belong to their respective owners.

[0001327567-17-000016:8k_2_02:50]
Media Contact:

[0001327567-17-000016:8k_2_02:51]
Jennifer Jasper Smith

[0001327567-17-000016:8k_2_02:52]
Head of Corporate Communications

[0001327567-17-000016:8k_2_02:53]
Palo Alto Networks

[0001327567-17-000016:8k_2_02:54]
408-638-3280

[0001327567-17-000016:8k_2_02:55]
jjsmith@paloaltonetworks.com

[0001327567-17-000016:8k_2_02:56]
Investor Relations Contact:

[0001327567-17-000016:8k_2_02:57]
Kelsey Turcotte

[0001327567-17-000016:8k_2_02:58]
Vice President of Investor Relations

[0001327567-17-000016:8k_2_02:59]
Palo Alto Networks

[0001327567-17-000016:8k_2_02:60]
408-753-3872

[0001327567-17-000016:8k_2_02:61]
kturcotte@paloaltonetworks.com

[0001327567-17-000016:8k_2_02:62]
| Palo Alto Networks, Inc. |
| Preliminary Condensed Consolidated Statements of Operations |
| (In millions, except per share data) |
| (Unaudited) |
|  | Three Months Ended April 30, |  | Nine Months Ended April 30, |
|  | 2017(2) |  | 2016 |  | 2017(2) |  | 2016 |
|  |  |  | (As Adjusted)(1) |  |  |  | (As Adjusted)(1) |
| Revenue: |  |  |  |  |  |  |  |
| Product | $ | 164.2 |  |  | $ | 162.1 |  |  | $ | 496.8 |  |  | $ | 479.7 |  |
| Subscription and support | 267.6 |  |  | 183.7 |  |  | 755.7 |  |  | 498.0 |  |
| Total revenue | 431.8 |  |  | 345.8 |  |  | 1,252.5 |  |  | 977.7 |  |
| Cost of revenue: |  |  |  |  |  |  |  |
| Product | 49.7 |  |  | 43.2 |  |  | 137.7 |  |  | 126.9 |  |
| Subscription and support | 74.0 |  |  | 51.7 |  |  | 200.4 |  |  | 141.4 |  |
| Total cost of revenue | 123.7 |  |  | 94.9 |  |  | 338.1 |  |  | 268.3 |  |
| Total gross profit | 308.1 |  |  | 250.9 |  |  | 914.4 |  |  | 709.4 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 86.0 |  |  | 74.0 |  |  | 260.1 |  |  | 207.7 |  |
| Sales and marketing | 226.9 |  |  | 195.9 |  |  | 673.7 |  |  | 537.8 |  |
| General and administrative | 44.3 |  |  | 33.5 |  |  | 133.1 |  |  | 98.5 |  |
| Total operating expenses | 357.2 |  |  | 303.4 |  |  | 1,066.9 |  |  | 844.0 |  |
| Operating loss | (49.1 | ) |  | (52.5 | ) |  | (152.5 | ) |  | (134.6 | ) |
| Interest expense | (6.2 | ) |  | (5.8 | ) |  | (18.3 | ) |  | (17.4 | ) |
| Other income, net | 2.1 |  |  | 1.0 |  |  | 7.3 |  |  | 5.7 |  |
| Loss before income taxes | (53.2 | ) |  | (57.3 | ) |  | (163.5 | ) |  | (146.3 | ) |
| Provision for income taxes | 7.7 |  |  | 6.8 |  |  | 14.9 |  |  | 15.0 |  |
| Net loss | $ | (60.9 | ) |  | $ | (64.1 | ) |  | $ | (178.4 | ) |  | $ | (161.3 | ) |
| Net loss per share, basic and diluted | $ | (0.67 | ) |  | $ | (0.73 | ) |  | $ | (1.97 | ) |  | $ | (1.86 | ) |
| Weighted-average shares used to compute net loss per share, basic and diluted | 91.0 |  |  | 87.8 |  |  | 90.5 |  |  | 86.5 |  |

[0001327567-17-000016:8k_2_02:63]
___________

[0001327567-17-000016:8k_2_02:64]
| (1) | Certain amounts have been adjusted as a result of the Company’s change in accounting policy for sales commissions. Refer to Appendix A for more information. |

[0001327567-17-000016:8k_2_02:65]
| (2) | The Company early adopted new share-based payment accounting guidance in its second quarter of fiscal 2017, which simplified, among other things, the accounting for income tax consequences and the method of accounting for forfeitures of share-based payment awards. As a result of the early adoption, the Company’s share-based compensation and provision for income taxes decreased by $0.9 million and $4.0 million, respectively, for the three months ended October 31, 2016. These adjustments are reflected in the results for the nine months ended April 30, 2017. |

[0001327567-17-000016:8k_2_02:66]
10

[0001327567-17-000016:8k_2_02:67]
| Palo Alto Networks, Inc. |
| Reconciliation of GAAP to Non-GAAP Financial Measures |
| (In millions, except per share amounts) |
| (Unaudited) |
|  | Three Months Ended |  | Nine Months Ended |
|  | April 30, |  | April 30, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
|  |  |  | (As Adjusted)(1) |  |  |  | (As Adjusted)(1) |
| GAAP net loss | $ | (60.9 | ) |  | $ | (64.1 | ) |  | $ | (178.4 | ) |  | $ | (161.3 | ) |
| Share-based compensation related charges | 120.6 |  |  | 112.7 |  |  | 368.0 |  |  | 294.8 |  |
| Acquisition related costs | 2.4 |  |  | — |  |  | 3.1 |  |  | — |  |
| Amortization expense of acquired intangible assets | 2.3 |  |  | 2.1 |  |  | 6.4 |  |  | 6.3 |  |
| Litigation related charges | 3.1 |  |  | 3.1 |  |  | 9.2 |  |  | 9.2 |  |
| Non-cash interest expense related to convertible notes | 6.2 |  |  | 5.9 |  |  | 18.3 |  |  | 17.4 |  |
| Foreign currency loss associated with non-GAAP adjustments | 1.4 |  |  | 1.8 |  |  | 1.8 |  |  | 0.3 |  |
| Income tax and other tax adjustments related to the above | (18.0 | ) |  | (19.2 | ) |  | (60.5 | ) |  | (54.1 | ) |
| Non-GAAP net income | $ | 57.1 |  |  | $ | 42.3 |  |  | $ | 167.9 |  |  | $ | 112.6 |  |
| GAAP net loss per share, diluted | $ | (0.67 | ) |  | $ | (0.73 | ) |  | $ | (1.97 | ) |  | $ | (1.86 | ) |
| Share-based compensation related charges | 1.30 |  |  | 1.27 |  |  | 4.01 |  |  | 3.35 |  |
| Acquisition related costs | 0.03 |  |  | 0.00 |  |  | 0.03 |  |  | 0.00 |  |
| Amortization expense of acquired intangible assets | 0.03 |  |  | 0.02 |  |  | 0.07 |  |  | 0.07 |  |
| Litigation related charges | 0.03 |  |  | 0.03 |  |  | 0.10 |  |  | 0.11 |  |
| Non-cash interest expense related to convertible notes | 0.07 |  |  | 0.07 |  |  | 0.20 |  |  | 0.20 |  |
| Foreign currency loss associated with non-GAAP adjustments | 0.02 |  |  | 0.02 |  |  | 0.02 |  |  | 0.00 |  |
| Income tax and other tax adjustments related to the above | (0.20 | ) |  | (0.22 | ) |  | (0.67 | ) |  | (0.64 | ) |
| Non-GAAP net income per share, diluted | $ | 0.61 |  |  | $ | 0.46 |  |  | $ | 1.79 |  |  | $ | 1.23 |  |
| GAAP weighted-average shares used to compute net loss per share, diluted | 91.0 |  |  | 87.8 |  |  | 90.5 |  |  | 86.5 |  |
| Weighted-average effect of potentially dilutive securities(2) | 2.3 |  |  | 3.5 |  |  | 3.2 |  |  | 4.7 |  |
| Non-GAAP weighted-average shares used to compute net income per share, diluted | 93.3 |  |  | 91.3 |  |  | 93.7 |  |  | 91.2 |  |
| Net cash provided by operating activities | $ | 211.2 |  |  | $ | 170.3 |  |  | $ | 629.0 |  |  | $ | 471.3 |  |
| Less: purchases of property, equipment, and other assets | 48.6 |  |  | 19.3 |  |  | 114.2 |  |  | 56.2 |  |
| Free cash flow (non-GAAP) | $ | 162.6 |  |  | $ | 151.0 |  |  | $ | 514.8 |  |  | $ | 415.1 |  |
| Net cash used in investing activities | $ | (166.8 | ) |  | $ | (54.6 | ) |  | $ | (411.1 | ) |  | $ | (339.3 | ) |
| Net cash provided by (used in) financing activities | $ | (113.8 | ) |  | $ | 21.1 |  |  | $ | (260.3 | ) |  | $ | 42.2 |  |

[0001327567-17-000016:8k_2_02:68]
___________

[0001327567-17-000016:8k_2_02:69]
| (1) | Certain amounts have been adjusted as a result of the Company’s change in accounting policy for sales commissions. Refer to Appendix A for more information. |

[0001327567-17-000016:8k_2_02:70]
| (2) | Non-GAAP net income per share, diluted, includes the potentially dilutive effect of employee equity incentive plan awards and convertible senior notes outstanding. In addition, non-GAAP net income per share, diluted, includes the anti-dilutive impact of the Company’s note hedge agreements, which reduced the potentially dilutive effect of the convertible notes by 0.1 million shares and 0.8 million shares for the three and nine months ended April 30, 2017, respectively, and 1.4 million shares and 1.6 million shares for the three and nine months ended April 30, 2016, respectively. |

[0001327567-17-000016:8k_2_02:71]
11

[0001327567-17-000016:8k_2_02:72]
| Palo Alto Networks, Inc. |
| Calculation of Billings |
| (In millions) |
| (Unaudited) |
|  | Three Months Ended April 30, |  | Nine Months Ended April 30, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Total revenue | $ | 431.8 |  |  | $ | 345.8 |  |  | $ | 1,252.5 |  |  | $ | 977.7 |  |
| Add: change in total deferred revenue, net of acquired deferred revenue | 112.3 |  |  | 140.4 |  |  | 370.1 |  |  | 355.5 |  |
| Billings | $ | 544.1 |  |  | $ | 486.2 |  |  | $ | 1,622.6 |  |  | $ | 1,333.2 |  |

[0001327567-17-000016:8k_2_02:73]
12

[0001327567-17-000016:8k_2_02:74]
| Palo Alto Networks, Inc. |
| Preliminary Condensed Consolidated Balance Sheets |
| (In millions) |
| (Unaudited) |
|  | April 30, 2017 |  | July 31, 2016 |
|  |  |  | (As Adjusted)(1) |
| Assets |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 692.0 |  |  | $ | 734.4 |  |
| Short-term investments | 680.0 |  |  | 551.2 |  |
| Accounts receivable, net | 364.1 |  |  | 348.7 |  |
| Prepaid expenses and other current assets | 159.1 |  |  | 139.7 |  |
| Total current assets | 1,895.2 |  |  | 1,774.0 |  |
| Property and equipment, net | 192.3 |  |  | 117.2 |  |
| Long-term investments | 719.1 |  |  | 652.8 |  |
| Goodwill | 238.8 |  |  | 163.5 |  |
| Intangible assets, net | 56.5 |  |  | 44.0 |  |
| Other assets | 148.2 |  |  | 106.7 |  |
| Total assets | $ | 3,250.1 |  |  | $ | 2,858.2 |  |
| Liabilities and stockholders’ equity |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 33.2 |  |  | $ | 30.2 |  |
| Accrued compensation | 76.4 |  |  | 73.5 |  |
| Accrued and other liabilities | 60.1 |  |  | 39.2 |  |
| Deferred revenue | 885.0 |  |  | 703.9 |  |
| Total current liabilities | 1,054.7 |  |  | 846.8 |  |
| Convertible senior notes, net | 518.4 |  |  | 500.2 |  |
| Long-term deferred revenue | 726.8 |  |  | 536.9 |  |
| Other long-term liabilities | 137.1 |  |  | 79.4 |  |
| Stockholders’ equity: |  |  |  |
| Preferred stock | — |  |  | — |  |
| Common stock and additional paid-in capital | 1,615.8 |  |  | 1,515.5 |  |
| Accumulated other comprehensive income (loss) | (4.2 | ) |  | 1.0 |  |
| Accumulated deficit | (798.5 | ) |  | (621.6 | ) |
| Total stockholders’ equity | 813.1 |  |  | 894.9 |  |
| Total liabilities and stockholders’ equity | $ | 3,250.1 |  |  | $ | 2,858.2 |  |

[0001327567-17-000016:8k_2_02:75]
___________

[0001327567-17-000016:8k_2_02:76]
| (1) | Certain amounts have been adjusted as a result of the Company’s change in accounting policy for sales commissions. Refer to Appendix A for more information. |

[0001327567-17-000016:8k_2_02:77]
13

[0001327567-17-000016:8k_2_02:78]
| Palo Alto Networks, Inc. |
| Preliminary Condensed Consolidated Statements of Cash Flows |
| (In millions) |
| (Unaudited) |
|  | Nine Months Ended April 30, |
|  | 2017 |  | 2016 |
|  |  |  | (As Adjusted)(1) |
| Cash flows from operating activities |  |  |  |
| Net loss | $ | (178.4 | ) |  | $ | (161.3 | ) |
| Adjustments to reconcile net loss to net cash provided by operating activities: |  |  |  |
| Share-based compensation for equity based awards | 356.8 |  |  | 283.2 |  |
| Depreciation and amortization | 43.1 |  |  | 30.7 |  |
| Amortization of investment premiums, net of accretion of purchase discounts | 2.1 |  |  | 2.4 |  |
| Amortization of debt discount and debt issuance costs | 18.3 |  |  | 17.4 |  |
| Changes in operating assets and liabilities, net of effects of acquisitions: |  |  |  |
| Accounts receivable, net | (14.9 | ) |  | (55.3 | ) |
| Prepaid expenses and other assets | (49.6 | ) |  | (17.8 | ) |
| Accounts payable | 2.8 |  |  | 11.7 |  |
| Accrued compensation | 1.7 |  |  | (23.4 | ) |
| Accrued and other liabilities | 77.0 |  |  | 28.2 |  |
| Deferred revenue | 370.1 |  |  | 355.5 |  |
| Net cash provided by operating activities(2) | 629.0 |  |  | 471.3 |  |
| Cash flows from investing activities |  |  |  |
| Purchases of investments | (726.9 | ) |  | (830.1 | ) |
| Proceeds from sales of investments | — |  |  | 137.4 |  |
| Proceeds from maturities of investments | 520.7 |  |  | 409.6 |  |
| Business acquisitions, net of cash acquired | (90.7 | ) |  | — |  |
| Purchases of property, equipment, and other assets | (114.2 | ) |  | (56.2 | ) |
| Net cash used in investing activities | (411.1 | ) |  | (339.3 | ) |
| Cash flows from financing activities |  |  |  |
| Repurchases of common stock | (295.1 | ) |  | — |  |
| Proceeds from sales of shares through employee equity incentive plans | 45.8 |  |  | 42.2 |  |
| Payments for taxes related to net share settlement of equity awards | (11.0 | ) |  | — |  |
| Net cash provided by (used in) financing activities(2) | (260.3 | ) |  | 42.2 |  |
| Net increase (decrease) in cash and cash equivalents | (42.4 | ) |  | 174.2 |  |
| Cash and cash equivalents - beginning of period | 734.4 |  |  | 375.8 |  |
| Cash and cash equivalents - end of period | $ | 692.0 |  |  | $ | 550.0 |  |

[0001327567-17-000016:8k_2_02:79]
___________

[0001327567-17-000016:8k_2_02:80]
| (1) | Certain amounts have been adjusted as a result of the Company’s change in accounting policy for sales commissions. Refer to Appendix A for more information. |

[0001327567-17-000016:8k_2_02:81]
| (2) | The Company early adopted new share-based payment accounting guidance in its second quarter of fiscal 2017, which simplified, among other things, the presentation of excess tax benefits in the statement of cash flows. The Company adopted this portion of the guidance on a retrospective basis, which increased net cash provided by operating activities by $0.7 million for the nine months ended April 30, 2016, with a corresponding decrease to net cash provided by financing activities. |

[0001327567-17-000016:8k_2_02:82]
14

[0001327567-17-000016:8k_2_02:83]
Palo Alto Networks, Inc.

[0001327567-17-000016:8k_2_02:84]
Appendix A

[0001327567-17-000016:8k_2_02:85]
Change in Accounting Policy

[0001327567-17-000016:8k_2_02:86]
(Unaudited)

[0001327567-17-000016:8k_2_02:87]
Effective August 1, 2016, the Company voluntarily changed its accounting policy for sales commissions that are incremental and directly related to non-cancelable customer sales contracts from recording an expense when incurred to deferral and amortization of the sales commissions over the term of the related contract in proportion to the recognized revenue. The adoption of this accounting policy change has been applied retrospectively to all prior periods presented in this document, in which the cumulative effect of the change has been reflected as of the beginning of the earliest period presented.

[0001327567-17-000016:8k_2_02:88]
The following tables present the changes to financial statement line items as a result of the accounting change for the periods presented in the Company’s preliminary condensed consolidated financial statements (in millions, except per share data):

[0001327567-17-000016:8k_2_02:89]
|  | April 30, 2017 |  | July 31, 2016 |
|  | Computed under Prior Method |  | Impact of Commission Adjustment |  | As Reported |  | As Previously Reported |  | Impact of Commission Adjustment |  | As Adjusted |
| Preliminary Condensed Consolidated Balance Sheets |  |  |  |  |  |  |  |  |  |  |  |
| Prepaid expenses and other current assets | $ | 99.4 |  |  | $ | 59.7 |  |  | $ | 159.1 |  |  | $ | 84.8 |  |  | $ | 54.9 |  |  | $ | 139.7 |  |
| Other assets | 91.7 |  |  | 56.5 |  |  | 148.2 |  |  | 64.6 |  |  | 50.1 |  |  | 114.7 |  |
| Other long-term liabilities | 136.7 |  |  | 0.4 |  |  | 137.1 |  |  | 79.4 |  |  | — |  |  | 79.4 |  |
| Accumulated deficit | $ | (914.3 | ) |  | $ | 115.8 |  |  | $ | (798.5 | ) |  | $ | (726.6 | ) |  | $ | 105.0 |  |  | $ | (621.6 | ) |

[0001327567-17-000016:8k_2_02:90]
|  | Three Months Ended April 30, 2017 |  | Three Months Ended April 30, 2016 |
|  | Computed under Prior Method |  | Impact of Commission Adjustment |  | As Reported |  | As Previously Reported |  | Impact of Commission Adjustment |  | As Adjusted |
| Preliminary Condensed Consolidated Statements of Operations |  |  |  |  |  |  |  |  |  |  |  |
| Sales and marketing | $ | 234.6 |  |  | $ | (7.7 | ) |  | $ | 226.9 |  |  | $ | 202.0 |  |  | $ | (6.1 | ) |  | $ | 195.9 |  |
| Operating loss | (56.8 | ) |  | 7.7 |  |  | (49.1 | ) |  | (58.6 | ) |  | 6.1 |  |  | (52.5 | ) |
| Provision for income taxes | 7.3 |  |  | 0.4 |  |  | 7.7 |  |  | 6.8 |  |  | — |  |  | 6.8 |  |
| Net loss | $ | (68.2 | ) |  | $ | 7.3 |  |  | $ | (60.9 | ) |  | $ | (70.2 | ) |  | $ | 6.1 |  |  | $ | (64.1 | ) |
| Net loss per share, basic and diluted | $ | (0.75 | ) |  | $ | 0.08 |  |  | $ | (0.67 | ) |  | $ | (0.80 | ) |  | $ | 0.07 |  |  | $ | (0.73 | ) |
| Weighted-average shares used to compute net loss per share, basic and diluted | 91.0 |  |  | — |  |  | 91.0 |  |  | 87.8 |  |  | — |  |  | 87.8 |  |

[0001327567-17-000016:8k_2_02:91]
|  | Nine Months Ended April 30, 2017 |  | Nine Months Ended April 30, 2016 |
|  | Computed under Prior Method |  | Impact of Commission Adjustment |  | As Reported |  | As Previously Reported |  | Impact of Commission Adjustment |  | As Adjusted |
| Preliminary Condensed Consolidated Statements of Operations |  |  |  |  |  |  |  |  |  |  |  |
| Sales and marketing | $ | 684.8 |  |  | $ | (11.1 | ) |  | $ | 673.7 |  |  | $ | 547.9 |  |  | $ | (10.1 | ) |  | $ | 537.8 |  |
| Operating loss | (163.6 | ) |  | 11.1 |  |  | (152.5 | ) |  | (144.7 | ) |  | 10.1 |  |  | (134.6 | ) |
| Provision for income taxes | 14.6 |  |  | 0.3 |  |  | 14.9 |  |  | 15.0 |  |  | — |  |  | 15.0 |  |
| Net loss | $ | (189.2 | ) |  | $ | 10.8 |  |  | $ | (178.4 | ) |  | $ | (171.4 | ) |  | $ | 10.1 |  |  | $ | (161.3 | ) |
| Net loss per share, basic and diluted | $ | (2.09 | ) |  | $ | 0.12 |  |  | $ | (1.97 | ) |  | $ | (1.98 | ) |  | $ | 0.12 |  |  | $ | (1.86 | ) |
| Weighted-average shares used to compute net loss per share, basic and diluted | 90.5 |  |  | — |  |  | 90.5 |  |  | 86.5 |  |  | — |  |  | 86.5 |  |

[0001327567-17-000016:8k_2_02:92]
This change in accounting policy does not affect the Company’s balance of cash and cash equivalents and, as a result, did not change net cash flows from operating, investing, or financing activities or materially impact any individual line items in the Company’s preliminary condensed consolidated statement of cash flows for the nine months ended April 30, 2016.

[0001327567-17-000016:8k_2_02:93]
15
