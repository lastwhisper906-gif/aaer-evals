# PANW note change history — 0001327567-17-000007 → 0001327567-17-000018


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2017-06-01):
[0001327567-17-000018:note_history:1]
The following table presents details of the aggregate future non-cancelable minimum rental payments under our operating leases as of April 30, 2017 (in millions):
  (was, 2017-03-01, similarity 0.9747):
[0001327567-17-000007:note_history:1]
The following table presents details of the aggregate future non-cancelable minimum rental payments under our operating leases as of January 31, 2017 (in millions):

- changed (2017-06-01):
[0001327567-17-000018:note_history:2]
Manufacturing Purchase Commitments
  (was, 2017-03-01, similarity 0.6866):
[0001327567-17-000007:note_history:2]
Contract Manufacturer Commitments

- changed (2017-06-01):
[0001327567-17-000018:note_history:3]
Our independent contract manufacturer procures components and assembles our products based on our forecasts. These forecasts are based on estimates of demand for our products primarily for the next 12 months, which are in turn based on historical trends and an analysis from our sales and product marketing organizations, adjusted for overall market conditions. In order to reduce manufacturing lead times and plan for adequate supply, we may issue non-cancelable orders for components and products to our independent contract manufacturer, original design manufacturers, or component suppliers. As of April 30, 2017, our purchase commitments under such orders were $104.3 million, excluding obligations under contracts that we can cancel without a significant penalty.
  (was, 2017-03-01, similarity 0.8609):
[0001327567-17-000007:note_history:3]
Our independent contract manufacturer procures components and assembles our products based on our forecasts. These forecasts are based on estimates of demand for our products primarily for the next 12 months, which are in turn based on historical trends and an analysis from our sales and product marketing organizations, adjusted for overall market conditions. In order to reduce manufacturing lead times and plan for adequate supply, we may issue forecasts and orders for components and products that are non-cancelable. As of January 31, 2017, our purchase commitments under such orders were $77.6 million, excluding obligations under contracts that we can cancel without a significant penalty.

- added (2017-06-01):
[0001327567-17-000018:note_history:4]
To the extent there is a reasonable possibility that a loss exceeding amounts already recognized may be incurred and the amount of such additional loss would be material, we will either disclose the estimated additional loss or state that such an estimate cannot be made. As of April 30, 2017, we have not recorded any significant accruals for loss contingencies associated with such legal proceedings, determined that an unfavorable outcome is probable or reasonably possible, or determined that the amount or range of any possible loss is reasonably estimable.

- removed (2017-06-01):
[0001327567-17-000007:note_history:5]
To the extent there is a reasonable possibility that a loss exceeding amounts already recognized may be incurred and the amount of such additional loss would be material, we will either disclose the estimated additional loss or state that such an estimate cannot be made. As of January 31, 2017, we have not recorded any significant accruals for loss contingencies associated with such legal proceedings, determined that an unfavorable outcome is probable or reasonably possible, or determined that the amount or range of any possible loss is reasonably estimable.


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2017-06-01):
[0001327567-17-000018:note_history:6]
There have been no material changes to our significant accounting policies as of and for the nine months ended April 30, 2017, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended July 31, 2016, except for our voluntary change in accounting policy related to sales commissions and our early adoption of the new share-based payment accounting guidance discussed below.
  (was, 2017-03-01, similarity 0.9444):
[0001327567-17-000007:note_history:6]
There have been no material changes to our significant accounting policies as of and for the six months ended January 31, 2017, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended July 31, 2016, except for our voluntary change in accounting policy related to sales commissions and our early adoption of the new share-based payment accounting guidance discussed below.

- changed (2017-06-01):
[0001327567-17-000018:note_history:7]
|  | April 30, 2017 |  | July 31, 2016 |
|  | Computed under Prior Method |  | Impact of Commission Adjustment |  | As Reported |  | As Previously Reported |  | Impact of Commission Adjustment |  | As Adjusted |
| Condensed Consolidated Balance Sheets |  |  |  |  |  |  |  |  |  |  |  |
| Prepaid expenses and other current assets | $ | 99.4 |  |  | $ | 59.7 |  |  | $ | 159.1 |  |  | $ | 84.8 |  |  | $ | 54.9 |  |  | $ | 139.7 |  |
| Other assets | 91.7 |  |  | 56.5 |  |  | 148.2 |  |  | 64.6 |  |  | 50.1 |  |  | 114.7 |  |
| Other long-term liabilities | 136.7 |  |  | 0.4 |  |  | 137.1 |  |  | 79.4 |  |  | — |  |  | 79.4 |  |
| Accumulated deficit | $ | (914.3 | ) |  | $ | 115.8 |  |  | $ | (798.5 | ) |  | $ | (726.6 | ) |  | $ | 105.0 |  |  | $ | (621.6 | ) |
  (was, 2017-03-01, similarity 0.9124):
[0001327567-17-000007:note_history:7]
|  | January 31, 2017 |  | July 31, 2016 |
|  | Computed under Prior Method |  | Impact of Commission Adjustment |  | As Reported |  | As Previously Reported |  | Impact of Commission Adjustment |  | As Adjusted |
| Condensed Consolidated Balance Sheets |  |  |  |  |  |  |  |  |  |  |  |
| Prepaid expenses and other current assets | $ | 83.2 |  |  | $ | 56.7 |  |  | $ | 139.9 |  |  | $ | 84.8 |  |  | $ | 54.9 |  |  | $ | 139.7 |  |
| Other assets | 94.8 |  |  | 51.8 |  |  | 146.6 |  |  | 64.6 |  |  | 50.1 |  |  | 114.7 |  |
| Accumulated deficit | $ | (846.1 | ) |  | $ | 108.5 |  |  | $ | (737.6 | ) |  | $ | (726.6 | ) |  | $ | 105.0 |  |  | $ | (621.6 | ) |

- changed (2017-06-01):
[0001327567-17-000018:note_history:8]
|  | Three Months Ended April 30, 2017 |  | Three Months Ended April 30, 2016 |
|  | Computed under Prior Method |  | Impact of Commission Adjustment |  | As Reported |  | As Previously Reported |  | Impact of Commission Adjustment |  | As Adjusted |
| Condensed Consolidated Statements of Operations |  |  |  |  |  |  |  |  |  |  |  |
| Sales and marketing | $ | 234.6 |  |  | $ | (7.7 | ) |  | $ | 226.9 |  |  | $ | 202.0 |  |  | $ | (6.1 | ) |  | $ | 195.9 |  |
| Operating loss | (56.8 | ) |  | 7.7 |  |  | (49.1 | ) |  | (58.6 | ) |  | 6.1 |  |  | (52.5 | ) |
| Provision for income taxes | 7.3 |  |  | 0.4 |  |  | 7.7 |  |  | 6.8 |  |  | — |  |  | 6.8 |  |
| Net loss | $ | (68.2 | ) |  | $ | 7.3 |  |  | $ | (60.9 | ) |  | $ | (70.2 | ) |  | $ | 6.1 |  |  | $ | (64.1 | ) |
| Net loss per share, basic and diluted | $ | (0.75 | ) |  | $ | 0.08 |  |  | $ | (0.67 | ) |  | $ | (0.80 | ) |  | $ | 0.07 |  |  | $ | (0.73 | ) |
| Weighted-average shares used to compute net loss per share, basic and diluted | 91.0 |  |  | — |  |  | 91.0 |  |  | 87.8 |  |  | — |  |  | 87.8 |  |
| Condensed Consolidated Statements of Comprehensive Loss |  |  |  |  |  |  |  |  |  |  |  |
| Net loss | $ | (68.2 | ) |  | $ | 7.3 |  |  | $ | (60.9 | ) |  | $ | (70.2 | ) |  | $ | 6.1 |  |  | $ | (64.1 | ) |
| Comprehensive loss | $ | (67.3 | ) |  | $ | 7.3 |  |  | $ | (60.0 | ) |  | $ | (68.9 | ) |  | $ | 6.1 |  |  | $ | (62.8 | ) |
  (was, 2017-03-01, similarity 0.9891):
[0001327567-17-000007:note_history:8]
|  | Three Months Ended January 31, 2017 |  | Three Months Ended January 31, 2016 |
|  | Computed under Prior Method |  | Impact of Commission Adjustment |  | As Reported |  | As Previously Reported |  | Impact of Commission Adjustment |  | As Adjusted |
| Condensed Consolidated Statements of Operations |  |  |  |  |  |  |  |  |  |  |  |
| Sales and marketing | $ | 232.7 |  |  | $ | (6.0 | ) |  | $ | 226.7 |  |  | $ | 187.6 |  |  | $ | (5.2 | ) |  | $ | 182.4 |  |
| Operating loss | (60.4 | ) |  | 6.0 |  |  | (54.4 | ) |  | (55.3 | ) |  | 5.2 |  |  | (50.1 | ) |
| Provision for income taxes | 2.8 |  |  | — |  |  | 2.8 |  |  | 3.9 |  |  | — |  |  | 3.9 |  |
| Net loss | $ | (66.6 | ) |  | $ | 6.0 |  |  | $ | (60.6 | ) |  | $ | (62.5 | ) |  | $ | 5.2 |  |  | $ | (57.3 | ) |
| Net loss per share, basic and diluted | $ | (0.73 | ) |  | $ | 0.06 |  |  | $ | (0.67 | ) |  | $ | (0.72 | ) |  | $ | 0.06 |  |  | $ | (0.66 | ) |
| Weighted-average shares used to compute net loss per share, basic and diluted | 90.7 |  |  | — |  |  | 90.7 |  |  | 86.6 |  |  | — |  |  | 86.6 |  |
| Condensed Consolidated Statements of Comprehensive Loss |  |  |  |  |  |  |  |  |  |  |  |
| Net loss | $ | (66.6 | ) |  | $ | 6.0 |  |  | $ | (60.6 | ) |  | $ | (62.5 | ) |  | $ | 5.2 |  |  | $ | (57.3 | ) |
| Comprehensive loss | $ | (69.8 | ) |  | $ | 6.0 |  |  | $ | (63.8 | ) |  | $ | (62.8 | ) |  | $ | 5.2 |  |  | $ | (57.6 | ) |

- changed (2017-06-01):
[0001327567-17-000018:note_history:9]
|  | Nine Months Ended April 30, 2017(1) |  | Nine Months Ended April 30, 2016 |
|  | Computed under Prior Method |  | Impact of Commission Adjustment |  | As Reported |  | As Previously Reported |  | Impact of Commission Adjustment |  | As Adjusted |
| Condensed Consolidated Statements of Operations |  |  |  |  |  |  |  |  |  |  |  |
| Sales and marketing | $ | 684.8 |  |  | $ | (11.1 | ) |  | $ | 673.7 |  |  | $ | 547.9 |  |  | $ | (10.1 | ) |  | $ | 537.8 |  |
| Operating loss | (163.6 | ) |  | 11.1 |  |  | (152.5 | ) |  | (144.7 | ) |  | 10.1 |  |  | (134.6 | ) |
| Provision for income taxes | 14.6 |  |  | 0.3 |  |  | 14.9 |  |  | 15.0 |  |  | — |  |  | 15.0 |  |
| Net loss | $ | (189.2 | ) |  | $ | 10.8 |  |  | $ | (178.4 | ) |  | $ | (171.4 | ) |  | $ | 10.1 |  |  | $ | (161.3 | ) |
| Net loss per share, basic and diluted | $ | (2.09 | ) |  | $ | 0.12 |  |  | $ | (1.97 | ) |  | $ | (1.98 | ) |  | $ | 0.12 |  |  | $ | (1.86 | ) |
| Weighted-average shares used to compute net loss per share, basic and diluted | 90.5 |  |  | — |  |  | 90.5 |  |  | 86.5 |  |  | — |  |  | 86.5 |  |
| Condensed Consolidated Statements of Comprehensive Loss |  |  |  |  |  |  |  |  |  |  |  |
| Net loss | $ | (189.2 | ) |  | $ | 10.8 |  |  | $ | (178.4 | ) |  | $ | (171.4 | ) |  | $ | 10.1 |  |  | $ | (161.3 | ) |
| Comprehensive loss | $ | (194.4 | ) |  | $ | 10.8 |  |  | $ | (183.6 | ) |  | $ | (170.7 | ) |  | $ | 10.1 |  |  | $ | (160.6 | ) |
  (was, 2017-03-01, similarity 0.9702):
[0001327567-17-000007:note_history:9]
|  | Six Months Ended January 31, 2017(1) |  | Six Months Ended January 31, 2016 |
|  | Computed under Prior Method |  | Impact of Commission Adjustment |  | As Reported |  | As Previously Reported |  | Impact of Commission Adjustment |  | As Adjusted |
| Condensed Consolidated Statements of Operations |  |  |  |  |  |  |  |  |  |  |  |
| Sales and marketing | $ | 450.2 |  |  | $ | (3.4 | ) |  | $ | 446.8 |  |  | $ | 345.9 |  |  | $ | (4.0 | ) |  | $ | 341.9 |  |
| Operating loss | (106.8 | ) |  | 3.4 |  |  | (103.4 | ) |  | (86.1 | ) |  | 4.0 |  |  | (82.1 | ) |
| Provision for income taxes | 7.3 |  |  | (0.1 | ) |  | 7.2 |  |  | 8.2 |  |  | — |  |  | 8.2 |  |
| Net loss | $ | (121.0 | ) |  | $ | 3.5 |  |  | $ | (117.5 | ) |  | $ | (101.2 | ) |  | $ | 4.0 |  |  | $ | (97.2 | ) |
| Net loss per share, basic and diluted | $ | (1.34 | ) |  | $ | 0.04 |  |  | $ | (1.30 | ) |  | $ | (1.18 | ) |  | $ | 0.05 |  |  | $ | (1.13 | ) |
| Weighted-average shares used to compute net loss per share, basic and diluted | 90.2 |  |  | — |  |  | 90.2 |  |  | 85.8 |  |  | — |  |  | 85.8 |  |
| Condensed Consolidated Statements of Comprehensive Loss |  |  |  |  |  |  |  |  |  |  |  |
| Net loss | $ | (121.0 | ) |  | $ | 3.5 |  |  | $ | (117.5 | ) |  | $ | (101.2 | ) |  | $ | 4.0 |  |  | $ | (97.2 | ) |
| Comprehensive loss | $ | (127.1 | ) |  | $ | 3.5 |  |  | $ | (123.6 | ) |  | $ | (101.8 | ) |  | $ | 4.0 |  |  | $ | (97.8 | ) |

- changed (2017-06-01):
[0001327567-17-000018:note_history:10]
This change in accounting policy does not affect our balance of cash and cash equivalents and, as a result, did not change net cash flows from operating, investing, or financing activities, or materially impact any individual line items presented in our condensed consolidated statement of cash flows for the nine months ended April 30, 2016.
  (was, 2017-03-01, similarity 0.9302):
[0001327567-17-000007:note_history:10]
This change in accounting policy does not affect our balance of cash and cash equivalents and, as a result, did not change net cash flows from operating, investing, or financing activities, or materially impact any individual line items presented in our condensed consolidated statement of cash flows for the six months ended January 31, 2016.

- changed (2017-06-01):
[0001327567-17-000018:note_history:11]
In March 2016, the Financial Accounting Standards Board (“FASB”) issued authoritative guidance simplifying several aspects of the accounting for employee share-based payment transactions. The new standard requires us to recognize excess tax benefits or deficiencies as income tax expense or benefit in the period in which they occur, rather than additional paid-in capital, and also requires us to recognize excess tax benefits regardless of whether the benefit reduces taxes payable in the current period. In addition, excess tax benefits should be classified as an operating activity, along with other income tax cash flows, instead of a financing activity in our condensed consolidated statements of cash flows. The standard also allows us to make an accounting policy election to account for forfeitures of share-based payment awards when they occur, rather than estimate expected forfeitures.
  (was, 2017-03-01, similarity 0.9821):
[0001327567-17-000007:note_history:11]
In March 2016, the Financial Accounting Standards Board (“FASB”) issued authoritative guidance simplifying several aspects of the accounting for employee share-based payment transactions. The new guidance requires us to recognize excess tax benefits or deficiencies as income tax expense or benefit in the period in which they occur, rather than additional paid-in capital, and also requires us to recognize excess tax benefits regardless of whether the benefit reduces taxes payable in the current period. In addition, excess tax benefits should be classified as an operating activity, along with other income tax cash flows, instead of a financing activity in our condensed consolidated statements of cash flows. The guidance also allows us to make an accounting policy election to account for forfeitures of share-based payment awards when they occur, rather than estimate expected forfeitures.

- changed (2017-06-01):
[0001327567-17-000018:note_history:12]
We elected to early adopt the standard in our second quarter of fiscal 2017, which required us to reflect any adjustments related to the adoption as of the beginning of the fiscal year. The impact of the adoption on our condensed consolidated financial statements was as follows:
  (was, 2017-03-01, similarity 0.9709):
[0001327567-17-000007:note_history:12]
We elected to early adopt the guidance in our second quarter of fiscal 2017, which required us to reflect any adjustments related to the adoption as of the beginning of the fiscal year. The impact of the adoption on our condensed consolidated financial statements was as follows:

- changed (2017-06-01):
[0001327567-17-000018:note_history:13]
| • | Cash flow presentation of excess tax benefits - We elected to adopt the guidance related to the presentation of excess tax benefits in our condensed consolidated statements of cash flows on a retrospective basis, which increased net cash provided by operating activities by $0.7 million for the nine months ended April 30, 2016, with a corresponding decrease to net cash provided by financing activities. |
  (was, 2017-03-01, similarity 0.9765):
[0001327567-17-000007:note_history:13]
| • | Cash flow presentation of excess tax benefits - We elected to adopt the guidance related to the presentation of excess tax benefits in our condensed consolidated statements of cash flows on a retrospective basis, which increased net cash provided by operating activities by $0.5 million for the six months ended January 31, 2016, with a corresponding decrease to net cash provided by financing activities. |

- changed (2017-06-01):
[0001327567-17-000018:note_history:14]
The adoption of the standard also impacted our previously reported results for the three months ended October 31, 2016, as presented in the following tables (in millions, except per share data):
  (was, 2017-03-01, similarity 0.9681):
[0001327567-17-000007:note_history:14]
The adoption of the guidance also impacted our previously reported results for the three months ended October 31, 2016, as presented in the following tables (in millions, except per share data):

- changed (2017-06-01):
[0001327567-17-000018:note_history:15]
In April 2015, the FASB issued new authoritative guidance on fees paid in a cloud computing arrangement. The standard requires customers in a cloud computing arrangement to evaluate whether the arrangement includes a software license. If the arrangement includes a software license, the customer should account for the software license element of the arrangement consistent with the acquisition of other software licenses. If the arrangement does not include a software license, the customer should account for the arrangement as a service contract. We adopted the standard in our first quarter of fiscal 2017 on a prospective basis. Our adoption of this standard did not have a material impact on our condensed consolidated financial statements.
  (was, 2017-03-01, similarity 0.9783):
[0001327567-17-000007:note_history:15]
In April 2015, the FASB issued new authoritative guidance on fees paid in a cloud computing arrangement. The standard requires customers in a cloud computing arrangement to evaluate whether the arrangement includes a software license. If the arrangement includes a software license, the customer should account for the software license element of the arrangement consistent with the acquisition of other software licenses. If the arrangement does not include a software license, the customer should account for the arrangement as a service contract. We adopted the guidance in our first quarter of fiscal 2017 on a prospective basis. Our adoption of this guidance did not have a material impact on our condensed consolidated financial statements.

- changed (2017-06-01):
[0001327567-17-000018:note_history:16]
In April 2015, the FASB issued updated authoritative guidance to simplify the presentation of debt issuance costs. The amended standard requires that debt issuance costs related to a recognized debt liability be presented in the balance sheet as a direct deduction from the carrying amount of the related debt liability, consistent with the presentation of debt discounts, instead of being presented as an asset. We adopted the standard in our first quarter of fiscal 2017 on a retrospective basis, and as a result, we reduced other assets and convertible senior notes, net by $8.0 million on our condensed consolidated balance sheets as of July 31, 2016.
  (was, 2017-03-01, similarity 0.9875):
[0001327567-17-000007:note_history:16]
In April 2015, the FASB issued updated authoritative guidance to simplify the presentation of debt issuance costs. The amended standard requires that debt issuance costs related to a recognized debt liability be presented in the balance sheet as a direct deduction from the carrying amount of the related debt liability, consistent with the presentation of debt discounts, instead of being presented as an asset. We adopted the guidance in our first quarter of fiscal 2017 on a retrospective basis, and as a result, we reduced other assets and convertible senior notes, net by $8.0 million on our condensed consolidated balance sheets as of July 31, 2016.

- added (2017-06-01):
[0001327567-17-000018:note_history:17]
In January 2017, the FASB issued authoritative guidance simplifying the subsequent measurement of goodwill. The standard eliminates Step 2 of the current goodwill impairment test, which requires companies to determine the implied fair value of goodwill when measuring the amount of impairment loss. Under the new standard, goodwill impairment will be measured as the amount by which a reporting unit’s carrying value exceeds its fair value, with the loss limited to the total amount of goodwill allocated to that reporting unit. The standard is effective for us for our first quarter of fiscal 2021 and will be applied on a prospective basis. Early adoption is permitted. We do not expect the adoption of the standard will have a material impact on our condensed consolidated financial statements.

- added (2017-06-01):
[0001327567-17-000018:note_history:18]
In January 2017, the FASB issued authoritative guidance clarifying the definition of a business to assist companies with evaluating whether transactions should be accounted for as acquisitions (or disposals) of assets or businesses. The standard is effective for us for our first quarter of fiscal 2019 and will be applied on a prospective basis. Early adoption is permitted. We are currently evaluating whether this standard will have a material impact on our condensed consolidated financial statements.

- changed (2017-06-01):
[0001327567-17-000018:note_history:19]
In May 2014, the FASB issued new authoritative guidance on revenue from contracts with customers. The new standard provides principles for recognizing revenue for the transfer of promised goods or services to customers with the consideration to which the entity expects to be entitled in exchange for those goods or services. The standard also requires significantly expanded disclosures about revenue recognition. The FASB subsequently delayed the effective date of the standard by one year and as a result, the standard is now effective for us for our first quarter of fiscal 2019 using either of two methods: (i) retrospective to each prior reporting period presented with the option to elect certain practical expedients as defined within the guidance; or (ii) retrospective with the cumulative effect of initially applying the guidance recognized at the date of initial application and providing certain additional disclosures as defined per the guidance. Early adoption as of the original effective date is permitted. We do not plan to early adopt, and accordingly, we will adopt the new standard in our first quarter of fiscal 2019. We are continuing to evaluate the impact of the new standard on our accounting policies, processes, and system requirements, and have assigned cross-functional internal resources and engaged third-party service providers to assist in our evaluation and system implementation. Furthermore, we have made and will continue to make investments in systems to enable timely and accurate reporting under the new standard. We are also continuing to evaluate adoption methods and the potential impact that the implementation of this standard will have on our condensed consolidated financial statements, but have not yet determined whether the effect will be material. However, we believe this new standard will impact our accounting for revenue arrangements in the following areas:
  (was, 2017-03-01, similarity 0.8174):
[0001327567-17-000007:note_history:19]
In May 2014, the FASB issued new authoritative guidance on revenue from contracts with customers. The new standard provides principles for recognizing revenue for the transfer of promised goods or services to customers with the consideration to which the entity expects to be entitled in exchange for those goods or services. The standard also requires significantly expanded disclosures about revenue recognition. The FASB subsequently delayed the effective date of the standard by one year and as a result, the standard is now effective for us for our first quarter of fiscal 2019 using either of two methods: (i) retrospective to each prior reporting period presented with the option to elect certain practical expedients as defined within the guidance; or (ii) retrospective with the cumulative effect of initially applying the guidance recognized at the date of initial application and providing certain additional disclosures as defined per the guidance. Early adoption as of the original effective date is permitted. We do not plan to early adopt, and accordingly, we will adopt the new standard in our first quarter of fiscal 2019. We are in the initial stages of evaluating the impact of the new standard on our accounting policies, processes, and system requirements, and have assigned internal resources and engaged third party service providers to assist in our evaluation and system implementation. Furthermore, we have made and will continue to make investments in systems to enable timely and accurate reporting under the new standard. We are currently evaluating adoption methods and the potential impact that the implementation of this standard will have on our condensed consolidated financial statements.

- added (2017-06-01):
[0001327567-17-000018:note_history:20]
| • | removal of the current limitation on contingent revenue may result in revenue being recognized earlier for certain contracts; |

- added (2017-06-01):
[0001327567-17-000018:note_history:21]
| • | term license revenue associated with our virtual firewalls will be recognized upfront; |

- added (2017-06-01):
[0001327567-17-000018:note_history:22]
| • | allocation of revenue related to software due to the removal of the residual method of revenue recognition; and |

- added (2017-06-01):
[0001327567-17-000018:note_history:23]
| • | amortization period for deferred commissions. |

- added (2017-06-01):
[0001327567-17-000018:note_history:24]
We will continue to assess the new standard along with industry trends and additional interpretive guidance, and may adjust our implementation plan accordingly. We expect to finalize our adoption method and assessment of the impact that the implementation of this standard will have on our condensed consolidated financial statements by the end of fiscal 2017.


## us-gaap:ConvertibleDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-06-01):
[0001327567-17-000018:note_history:25]
The following table sets forth the components of the Notes as of April 30, 2017 and July 31, 2016 (in millions):
  (was, 2017-03-01, similarity 0.9612):
[0001327567-17-000007:note_history:25]
The following table sets forth the components of the Notes as of January 31, 2017 and July 31, 2016 (in millions):

- added (2017-06-01):
[0001327567-17-000018:note_history:26]
|  | April 30, 2017 |  | July 31, 2016 |
| Liability: |  |  |  |
| Principal | $ | 575.0 |  |  | $ | 575.0 |  |
| Less: debt discount and debt issuance costs, net of amortization | 56.6 |  |  | 74.8 |  |
| Net carrying amount | $ | 518.4 |  |  | $ | 500.2 |  |
| Equity | $ | 109.8 |  |  | $ | 109.8 |  |

- removed (2017-06-01):
[0001327567-17-000007:note_history:27]
|  | January 31, 2017 |  | July 31, 2016 |
| Liability: |  |  |  |
| Principal | $ | 575.0 |  |  | $ | 575.0 |  |
| Less: debt discount and debt issuance costs, net of amortization | 62.7 |  |  | 74.8 |  |
| Net carrying amount | $ | 512.3 |  |  | $ | 500.2 |  |
| Equity | $ | 109.8 |  |  | $ | 109.8 |  |


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-06-01):
[0001327567-17-000018:note_history:28]
The sale price condition was not met during the fiscal quarter ended April 30, 2017. Since the Notes were not convertible, the net carrying amount of the Notes was classified as a long-term liability and the equity component was included in additional paid-in capital in our condensed consolidated balance sheets as of April 30, 2017.
  (was, 2017-03-01, similarity 0.963):
[0001327567-17-000007:note_history:28]
The sale price condition was not met during the fiscal quarter ended January 31, 2017. Since the Notes were not convertible, the net carrying amount of the Notes was classified as a long-term liability and the equity component was included in additional paid-in capital in our condensed consolidated balance sheets as of January 31, 2017.

- changed (2017-06-01):
[0001327567-17-000018:note_history:29]
The following table sets forth the components of the Notes as of April 30, 2017 and July 31, 2016 (in millions):
  (was, 2017-03-01, similarity 0.9612):
[0001327567-17-000007:note_history:29]
The following table sets forth the components of the Notes as of January 31, 2017 and July 31, 2016 (in millions):

- added (2017-06-01):
[0001327567-17-000018:note_history:30]
|  | April 30, 2017 |  | July 31, 2016 |
| Liability: |  |  |  |
| Principal | $ | 575.0 |  |  | $ | 575.0 |  |
| Less: debt discount and debt issuance costs, net of amortization | 56.6 |  |  | 74.8 |  |
| Net carrying amount | $ | 518.4 |  |  | $ | 500.2 |  |
| Equity | $ | 109.8 |  |  | $ | 109.8 |  |

- changed (2017-06-01):
[0001327567-17-000018:note_history:31]
The total estimated fair value of the Notes was $671.3 million and $761.9 million at April 30, 2017 and July 31, 2016, respectively. The fair value was determined based on the closing trading price per $100 of the Notes as of the last day of trading for the period. We consider the fair value of the Notes at April 30, 2017 and July 31, 2016 to be a Level 2 measurement. The fair value of the Notes is primarily affected by the trading price of our common stock and market interest rates. As of April 30, 2017, the if-converted value of the Notes exceeded its principal amount by $7.7 million.
  (was, 2017-03-01, similarity 0.9354):
[0001327567-17-000007:note_history:31]
The total estimated fair value of the Notes was $820.2 million and $761.9 million at January 31, 2017 and July 31, 2016, respectively. The fair value was determined based on the closing trading price per $100 of the Notes as of the last day of trading for the period. We consider the fair value of the Notes at January 31, 2017 and July 31, 2016 to be a Level 2 measurement. The fair value of the Notes is primarily affected by the trading price of our common stock and market interest rates. As of January 31, 2017, the if-converted value of the Notes exceeded its principal amount by $125.0 million.

- changed (2017-06-01):
[0001327567-17-000018:note_history:32]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 30, |  | April 30, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Amortization of debt discount | $ | 5.5 |  |  | $ | 5.3 |  |  | $ | 16.4 |  |  | $ | 15.7 |  |
| Amortization of debt issuance costs | 0.7 |  |  | 0.6 |  |  | 1.9 |  |  | 1.7 |  |
| Total interest expense recognized | $ | 6.2 |  |  | $ | 5.9 |  |  | $ | 18.3 |  |  | $ | 17.4 |  |
| Effective interest rate of the liability component | 4.8 | % |  | 4.8 | % |  | 4.8 | % |  | 4.8 | % |
  (was, 2017-03-01, similarity 0.9348):
[0001327567-17-000007:note_history:32]
|  | Three Months Ended January 31, |  | Six Months Ended January 31, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Amortization of debt discount | $ | 5.5 |  |  | $ | 5.2 |  |  | $ | 10.9 |  |  | $ | 10.4 |  |
| Amortization of debt issuance costs | 0.6 |  |  | 0.6 |  |  | 1.2 |  |  | 1.1 |  |
| Total interest expense recognized | $ | 6.1 |  |  | $ | 5.8 |  |  | $ | 12.1 |  |  | $ | 11.5 |  |
| Effective interest rate of the liability component | 4.8 | % |  | 4.8 | % |  | 4.8 | % |  | 4.8 | % |

- changed (2017-06-01):
[0001327567-17-000018:note_history:33]
Separately, but concurrently with our issuance of the Notes, we entered into transactions whereby we sold warrants (the “Warrants”) to acquire up to 5.2 million shares of our common stock at a strike price of approximately $137.85 per share, subject to adjustments. The shares issuable under the Warrants will be included in the calculation of diluted earnings per share when the average market value per share of our common stock for the reporting period exceeds the strike price of the Warrants. The Warrants are separate transactions and are not part of the Notes or Note Hedges, and are not remeasured through earnings each reporting period. Holders of the Notes and Note Hedges will not have any rights with respect to the Warrants.
  (was, 2017-03-01, similarity 0.9993):
[0001327567-17-000007:note_history:33]
Separately, but concurrently with our issuance of the Notes, we entered into transactions whereby we sold warrants (the “Warrants”) to acquire up to 5.2 million shares of our common stock at a strike price of approximately $137.85 per share, subject to adjustments. The shares issuable under the Warrants will be included in the calculation of diluted earnings per share when the average market value per share of our common stock for the reporting period exceeds the strike price of the Warrants. The Warrants are separate transactions and are not part of the Notes or Notes Hedges, and are not remeasured through earnings each reporting period. Holders of the Notes and Note Hedges will not have any rights with respect to the Warrants.

- removed (2017-06-01):
[0001327567-17-000007:note_history:34]
|  | January 31, 2017 |  | July 31, 2016 |
| Liability: |  |  |  |
| Principal | $ | 575.0 |  |  | $ | 575.0 |  |
| Less: debt discount and debt issuance costs, net of amortization | 62.7 |  |  | 74.8 |  |
| Net carrying amount | $ | 512.3 |  |  | $ | 500.2 |  |
| Equity | $ | 109.8 |  |  | $ | 109.8 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-06-01):
[0001327567-17-000018:note_history:35]
The following tables summarize the amortized cost, unrealized gains and losses, and fair value of our available-for-sale investments as of April 30, 2017 and July 31, 2016 (in millions):
  (was, 2017-03-01, similarity 0.9774):
[0001327567-17-000007:note_history:35]
The following tables summarize the amortized cost, unrealized gains and losses, and fair value of our available-for-sale investments as of January 31, 2017 and July 31, 2016 (in millions):

- changed (2017-06-01):
[0001327567-17-000018:note_history:36]
|  | April 30, 2017 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Estimated Fair Value |
| Certificates of deposit | $ | 5.4 |  |  | $ | — |  |  | $ | — |  |  | $ | 5.4 |  |
| Commercial paper | 15.0 |  |  | — |  |  | — |  |  | 15.0 |  |
| Corporate debt securities | 336.6 |  |  | 0.2 |  |  | (0.6 | ) |  | 336.2 |  |
| U.S. government and agency securities | 1,064.2 |  |  | 0.1 |  |  | (2.8 | ) |  | 1,061.5 |  |
| Total | $ | 1,421.2 |  |  | $ | 0.3 |  |  | $ | (3.4 | ) |  | $ | 1,418.1 |  |
  (was, 2017-03-01, similarity 0.9859):
[0001327567-17-000007:note_history:36]
|  | January 31, 2017 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Estimated Fair Value |
| Certificates of deposit | $ | 5.4 |  |  | $ | — |  |  | $ | — |  |  | $ | 5.4 |  |
| Commercial paper | 17.9 |  |  | — |  |  | — |  |  | 17.9 |  |
| Corporate debt securities | 330.0 |  |  | 0.2 |  |  | (0.9 | ) |  | 329.3 |  |
| U.S. government and agency securities | 1,035.3 |  |  | 0.1 |  |  | (2.5 | ) |  | 1,032.9 |  |
| Total | $ | 1,388.6 |  |  | $ | 0.3 |  |  | $ | (3.4 | ) |  | $ | 1,385.5 |  |

- changed (2017-06-01):
[0001327567-17-000018:note_history:37]
Unrealized losses related to these investments are due to interest rate fluctuations as opposed to credit quality. In addition, we do not intend to sell and it is not likely that we would be required to sell these investments before recovery of their amortized cost basis, which may be at maturity. As a result, there were no other-than-temporary impairments for these investments at April 30, 2017 and July 31, 2016.
  (was, 2017-03-01, similarity 0.9853):
[0001327567-17-000007:note_history:37]
Unrealized losses related to these investments are due to interest rate fluctuations as opposed to credit quality. In addition, we do not intend to sell and it is not likely that we would be required to sell these investments before recovery of their amortized cost basis, which may be at maturity. As a result, there were no other-than-temporary impairments for these investments at January 31, 2017 and July 31, 2016.

- changed (2017-06-01):
[0001327567-17-000018:note_history:38]
The following table summarizes the amortized cost and fair value of our available-for-sale investments as of April 30, 2017, by contractual years-to-maturity (in millions):
  (was, 2017-03-01, similarity 0.976):
[0001327567-17-000007:note_history:38]
The following table summarizes the amortized cost and fair value of our available-for-sale investments as of January 31, 2017, by contractual years-to-maturity (in millions):


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_current_note, score: 0.0

- removed (2017-06-01):
[0001327567-17-000007:note_history:39]
Subsequent Events

- removed (2017-06-01):
[0001327567-17-000007:note_history:40]
Business Combination

- removed (2017-06-01):
[0001327567-17-000007:note_history:41]
On February 27, 2017, we completed our acquisition of LightCyber Ltd. (“LightCyber”), a privately-held cybersecurity company, in exchange for total consideration of approximately $105.0 million in cash. The acquisition expands the functionality of our next-generation security platform with the addition of LightCyber’s behavioral analytics technology. We are currently in the process of finalizing the accounting for this transaction and expect to complete our preliminary allocation of the purchase consideration to the assets acquired and liabilities assumed by the end of our third quarter of fiscal 2017.

- removed (2017-06-01):
[0001327567-17-000007:note_history:42]
Share Repurchase

- removed (2017-06-01):
[0001327567-17-000007:note_history:43]
On February 24, 2017, our board of directors authorized a $500.0 million increase to our existing share repurchase program, bringing the total authorization to $1.0 billion. Repurchases may be made at management’s discretion from time to time on the open market, through privately negotiated transactions, transactions structured through investment banking institutions, block purchase techniques, 10b5-1 trading plans, or a combination of the foregoing, and will be funded from available working capital. Additionally, our board of directors extended the term of the repurchase authorization, which will now expire on December 31, 2018, and may be suspended or discontinued at any time. Refer to Note 7. Stockholders’ Equity for more information on our existing repurchase authorization as of January 31, 2017.
