# PANW 8-K — 0001327567-25-000024 filed 2025-08-18

## item codes, every 8-K on or before 2025-08-29

- 2025-08-18 0001327567-25-000024 — 2.02, 5.02, 5.03, 9.01
- 2025-07-31 0001193125-25-169870 — 1.01, 9.01
- 2025-07-30 0001193125-25-168821 — 7.01, 8.01, 9.01
- 2025-05-20 0001327567-25-000015 — 2.02, 9.01
- 2025-02-13 0001327567-25-000006 — 2.02, 9.01
- 2025-02-13 0001327567-25-000004 — 5.02, 9.01
- 2024-12-17 0001193125-24-280058 — 5.02, 9.01
- 2024-12-12 0001193125-24-277082 — 5.02, 5.03, 5.07, 9.01
- 2024-11-20 0001327567-24-000036 — 2.02, 8.01, 9.01
- 2024-11-15 0001193125-24-259308 — 8.01
- 2024-09-04 0001327567-24-000026 — 8.01, 9.01
- 2024-08-19 0001327567-24-000023 — 2.02, 8.01, 9.01
- 2024-05-20 0001327567-24-000015 — 2.02, 9.01
- 2024-05-16 0001327567-24-000010 — 8.01, 9.01
- 2024-02-20 0001327567-24-000003 — 2.02, 9.01
- 2023-12-14 0001193125-23-295527 — 5.02, 5.07, 9.01
- 2023-11-29 0001193125-23-285277 — 8.01, 9.01
- 2023-11-17 0001327567-23-000035 — 8.01, 9.01
- 2023-11-15 0001327567-23-000030 — 2.02, 9.01
- 2023-11-15 0001193125-23-277318 — 8.01
- 2023-08-18 0001327567-23-000020 — 2.02, 9.01
- 2023-06-08 0001193125-23-163506 — 7.01, 9.01
- 2023-06-05 0001193125-23-160228 — 7.01
- 2023-05-23 0001327567-23-000012 — 2.02, 9.01
- 2023-04-19 0001327567-23-000009 — 1.01, 2.03, 9.01
- 2023-02-21 0001327567-23-000005 — 2.02, 9.01
- 2022-12-16 0001193125-22-307346 — 5.02, 5.07
- 2022-11-17 0001327567-22-000035 — 2.02, 9.01
- 2022-11-15 0001193125-22-285017 — 8.01
- 2022-08-22 0001327567-22-000020 — 2.02, 8.01, 9.01
- 2022-05-23 0001193125-22-157474 — 5.02, 5.03, 9.01
- 2022-05-19 0001327567-22-000014 — 2.02, 9.01
- 2022-02-23 0001193125-22-049906 — 5.02
- 2022-02-22 0001327567-22-000006 — 2.02, 9.01
- 2021-12-15 0001193125-21-358074 — 5.02, 5.07
- 2021-11-18 0001327567-21-000037 — 2.02, 9.01
- 2021-10-12 0001193125-21-296438 — 3.01, 7.01, 9.01
- 2021-09-13 0001193125-21-270979 — 7.01, 9.01
- 2021-09-08 0001193125-21-267862 — 5.02, 9.01
- 2021-08-23 0001327567-21-000020 — 2.02, 9.01
- 2021-08-12 0001193125-21-244832 — 5.02, 9.01
- 2021-05-20 0001327567-21-000012 — 2.02, 9.01
- 2021-05-18 0001193125-21-164169 — 5.02 — amendment of 0001193125-21-162161
- 2021-05-14 0001193125-21-162161 — 5.02, 9.01
- 2021-03-19 0001193125-21-087516 — 5.02, 9.01
- 2021-02-22 0001628280-21-002659 — 2.02, 9.01
- 2021-02-22 0001193125-21-049293 — 5.02, 9.01
- 2020-12-18 0001193125-20-321568 — 8.01, 9.01
- 2020-12-16 0001193125-20-319091 — 3.02 — amendment of 0001193125-20-291707
- 2020-12-10 0001193125-20-314920 — 5.07
- 2020-12-08 0001193125-20-312056 — 5.02, 8.01, 9.01
- 2020-11-16 0001327567-20-000037 — 2.02, 9.01
- 2020-11-12 0001193125-20-291707 — 3.02
- 2020-10-19 0001193125-20-272060 — 5.02
- 2020-08-24 0001327567-20-000025 — 2.02, 9.01
- 2020-06-23 0001193125-20-176553 — 5.02, 9.01
- 2020-06-22 0001193125-20-175603 — 5.02, 9.01
- 2020-06-08 0001193125-20-163579 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2020-05-21 0001327567-20-000015 — 2.02, 9.01
- 2020-02-27 0001193125-20-050335 — 1.01, 2.03
- 2020-02-24 0001327567-20-000002 — 2.02, 9.01
- 2019-12-19 0001193125-19-319166 — 1.02, 9.01
- 2019-12-10 0001193125-19-310251 — 5.07
- 2019-11-25 0001327567-19-000036 — 2.02, 9.01
- 2019-11-25 0001193125-19-299886 — 5.02, 8.01 — amendment of 0001327567-19-000011
- 2019-10-22 0001193125-19-271660 — 5.02
- 2019-09-06 0001327567-19-000026 — 9.01 — amendment of 0001327567-19-000023
- 2019-09-04 0001327567-19-000023 — 2.02, 7.01, 9.01
- 2019-07-11 0001193125-19-192415 — 5.02, 9.01
- 2019-05-29 0001327567-19-000014 — 2.02, 9.01
- 2019-04-15 0001327567-19-000011 — 5.02, 9.01
- 2019-04-01 0001193125-19-094613 — 8.01, 9.01
- 2019-03-28 0001193125-19-090572 — 3.02 — amendment of 0001327567-19-000003
- 2019-02-26 0001327567-19-000006 — 2.02, 8.01, 9.01
- 2019-02-19 0001327567-19-000003 — 3.02
- 2018-12-11 0001327567-18-000033 — 5.07
- 2018-11-29 0001327567-18-000029 — 2.02, 9.01
- 2018-10-15 0001193125-18-299312 — 5.02, 9.01
- 2018-09-25 0001193125-18-282542 — 5.02
- 2018-09-14 0001193125-18-274239 — 5.03, 9.01
- 2018-09-06 0001327567-18-000018 — 1.01, 2.02, 2.03, 9.01
- 2018-07-13 0001193125-18-217281 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2018-06-04 0001327567-18-000011 — 2.02, 5.02, 9.01
- 2018-02-26 0001327567-18-000004 — 2.02, 5.02, 7.01, 9.01
- 2017-12-12 0001193125-17-367477 — 5.07
- 2017-11-20 0001327567-17-000032 — 2.02, 5.02, 9.01
- 2017-08-31 0001327567-17-000021 — 2.02, 5.02, 9.01
- 2017-05-31 0001327567-17-000016 — 2.02, 9.01
- 2017-02-28 0001327567-17-000005 — 2.02, 8.01, 9.01
- 2016-12-12 0001193125-16-790757 — 5.07
- 2016-11-21 0001327567-16-000071 — 2.02, 9.01
- 2016-10-24 0001193125-16-745121 — 5.02, 9.01
- 2016-08-30 0001327567-16-000057 — 2.02, 5.03, 8.01, 9.01
- 2016-08-22 0001193125-16-687588 — 5.02, 9.01
- 2016-05-26 0001327567-16-000051 — 2.02, 9.01
- 2016-02-25 0001327567-16-000044 — 2.02, 5.02, 9.01
- 2015-12-14 0001327567-15-000038 — 5.07
- 2015-12-14 0001193125-15-402588 — 1.01, 9.01
- 2015-11-23 0001327567-15-000033 — 2.02, 9.01
- 2015-10-19 0001193125-15-347005 — 1.01, 9.01 — amendment, the index does not say of what
- 2015-09-09 0001327567-15-000022 — 2.02, 9.01
- 2015-08-19 0001193125-15-296115 — 1.01, 2.03
- 2015-06-01 0001193125-15-207786 — 1.01, 2.03
- 2015-05-27 0001327567-15-000015 — 2.02, 9.01
- 2015-03-02 0001327567-15-000006 — 2.02, 9.01
- 2014-12-15 0001327567-14-000046 — 5.07
- 2014-11-24 0001327567-14-000040 — 2.02, 9.01
- 2014-09-22 0001193125-14-348581 — 5.02, 9.01
- 2014-09-09 0001327567-14-000025 — 2.02, 9.01
- 2014-07-01 0001193125-14-257824 — 1.01, 2.03, 3.02, 9.01
- 2014-06-26 0001193125-14-249529 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2014-06-20 0001327567-14-000020 — 9.01 — amendment of 0001193125-14-140511
- 2014-06-04 0001327567-14-000016 — 3.02
- 2014-05-30 0001193125-14-218158 — 2.02 — amendment, the index does not say of what
- 2014-05-28 0001193125-14-215060 — 1.01, 2.02, 3.02, 9.01
- 2014-04-11 0001193125-14-140511 — 2.01, 3.02, 7.01, 9.01
- 2014-03-24 0001193125-14-111318 — 1.01, 3.02, 7.01, 9.01
- 2014-03-13 0001327567-14-000009 — 5.02
- 2014-02-24 0001193125-14-063754 — 2.02, 9.01
- 2013-12-12 0001327567-13-000040 — 5.07
- 2013-11-25 0001327567-13-000033 — 2.02, 9.01
- 2013-09-30 0001193125-13-384966 — 8.01
- 2013-09-09 0001193125-13-361421 — 2.02, 9.01
- 2013-05-30 0001193125-13-241542 — 2.02, 5.02, 9.01
- 2013-03-11 0001193125-13-101082 — 5.02, 9.01
- 2013-02-28 0001193125-13-084193 — 2.02, 9.01
- 2012-12-14 0001193125-12-503335 — 5.07
- 2012-12-06 0001193125-12-493700 — 2.02, 9.01
- 2012-09-24 0001193125-12-401534 — 1.01, 2.03
- 2012-09-20 0001193125-12-398433 — 5.02, 9.01
- 2012-09-10 0001193125-12-386605 — 2.02, 9.01

## late-filing notifications on or before 2025-08-29

- none on or before 2025-08-29

## item 2.02 — earnings release, exhibit 99.1

[0001327567-25-000024:8k_2_02:1]
EX-99.1
3
ex991q425earningsrelease.htm
EX-99.1

[0001327567-25-000024:8k_2_02:2]
Document

[0001327567-25-000024:8k_2_02:3]
Exhibit 99.1

[0001327567-25-000024:8k_2_02:4]
Palo Alto Networks Reports Fiscal Fourth Quarter and Fiscal Year 2025 Financial Results

[0001327567-25-000024:8k_2_02:5]
•Fiscal fourth quarter revenue grew 16% year over year to $2.5 billion. Fiscal year 2025 revenue grew 15% year over year to $9.2 billion.

[0001327567-25-000024:8k_2_02:6]
•Next-Generation Security ARR grew 32% year over year to $5.6 billion.

[0001327567-25-000024:8k_2_02:7]
•Remaining performance obligation grew 24% year over year to $15.8 billion.

[0001327567-25-000024:8k_2_02:8]
SANTA CLARA, Calif., Aug. 18, 2025 — Palo Alto Networks® (NASDAQ: PANW), the global cybersecurity leader, announced today financial results for its fiscal fourth quarter and fiscal year, ended July 31, 2025.

[0001327567-25-000024:8k_2_02:9]
Total revenue for the fiscal fourth quarter 2025 grew 16% year over year to $2.5 billion, compared with total revenue of $2.2 billion for the fiscal fourth quarter 2024. GAAP net income for the fiscal fourth quarter 2025 was $253.8 million, or $0.36 per diluted share, compared with GAAP net income of $357.7 million, or $0.51 per diluted share, for the fiscal fourth quarter 2024.

[0001327567-25-000024:8k_2_02:10]
Non-GAAP net income for the fiscal fourth quarter 2025 was $673.0 million, or $0.95 per diluted share, compared with non-GAAP net income of $522.2 million, or $0.75 per diluted share, for the fiscal fourth quarter 2024. A reconciliation between GAAP and non-GAAP information is contained in the tables below.

[0001327567-25-000024:8k_2_02:11]
"Our strong execution in Q4 reflects a fundamental market shift in which customers understand that a fragmented defense is no defense at all against modern threats. They are partnering with us because our platforms are designed to work in concert, creating powerful operational synergies that deliver superior, near real-time outcomes and the efficiency our customers need," said Nikesh Arora, chairman and CEO of Palo Alto Networks. "We exited fiscal year 2025 with an acceleration in RPO, and surpassed the $10 billion revenue run-rate milestone, positioning ourselves well for sustained growth ahead."

[0001327567-25-000024:8k_2_02:12]
"Our strong top-line results were complemented by continued operating efficiency and strong free cash flow generation, making us a ‘Rule-of-50’ company for the fifth consecutive year," said Dipak Golechha, chief financial officer of Palo Alto Networks. "We are excited to carry this momentum into fiscal year 2026, where we will continue to execute against our profitable growth framework."

[0001327567-25-000024:8k_2_02:13]
Financial Outlook

[0001327567-25-000024:8k_2_02:14]
Palo Alto Networks provides guidance based on current market conditions and expectations.

[0001327567-25-000024:8k_2_02:15]
For the fiscal first quarter 2026, we expect:

[0001327567-25-000024:8k_2_02:16]
•Next-Generation Security ARR of $5.82 billion to $5.84 billion, representing year-over-year growth of 29%.

[0001327567-25-000024:8k_2_02:17]
•Remaining performance obligation of $15.4 billion to $15.5 billion, representing year-over-year growth of 23%.

[0001327567-25-000024:8k_2_02:18]
•Total revenue in the range of $2.45 billion to $2.47 billion, representing year-over-year growth of 15%.

[0001327567-25-000024:8k_2_02:19]
•Diluted non-GAAP net income per share in the range of $0.88 to $0.90, using 709 million to 712 million shares outstanding.

[0001327567-25-000024:8k_2_02:20]
For the fiscal year 2026, we expect:

[0001327567-25-000024:8k_2_02:21]
•Next-Generation Security ARR of $7.00 billion to $7.10 billion, representing year-over-year growth of between 26% and 27%.

[0001327567-25-000024:8k_2_02:22]
•Remaining performance obligation of $18.6 billion to $18.7 billion, representing year-over-year growth of between 17% and 18%.

[0001327567-25-000024:8k_2_02:23]
•Total revenue in the range of $10.475 billion to $10.525 billion, representing year-over-year growth of 14%.

[0001327567-25-000024:8k_2_02:24]
•Non-GAAP operating margin in the range of 29.2% to 29.7%.

[0001327567-25-000024:8k_2_02:25]
•Diluted non-GAAP net income per share in the range of $3.75 to $3.85, using 710 million to 716 million shares outstanding.

[0001327567-25-000024:8k_2_02:26]
•Adjusted free cash flow margin in the range of 38.0% to 39.0%.

[0001327567-25-000024:8k_2_02:27]
Guidance for non-GAAP financial measures excludes share-based compensation-related charges, including share-based payroll tax expense, acquisition-related costs, including change in fair value of contingent consideration liability, amortization expense of acquired intangible assets, litigation-related charges, including legal settlements, non-cash charges related to convertible notes, and income tax and other tax adjustments related to our long-term non-GAAP effective tax rate, along with certain non-recurring expenses and certain non-recurring cash flows. We have not reconciled non-GAAP operating margin guidance to GAAP operating margin, diluted non-GAAP net income per share guidance to GAAP net income per diluted share or adjusted free cash flow margin guidance to GAAP net cash from operating activities because we do not provide guidance on GAAP operating margin, GAAP net income or net cash from operating activities and would not be able to present the various reconciling cash and non-cash items between GAAP and non-GAAP financial measures because certain items that impact these measures are uncertain or out of our control, or cannot be reasonably predicted, including share-based compensation expense, without unreasonable effort. The actual amounts of such reconciling items will have a significant impact on the company's GAAP net income per diluted share and GAAP net cash from operating activities.

[0001327567-25-000024:8k_2_02:28]
Earnings Call Information

[0001327567-25-000024:8k_2_02:29]
Palo Alto Networks will host a video webcast for analysts and investors to discuss the company’s fiscal fourth quarter and fiscal year 2025 results as well as the outlook for its fiscal first quarter and fiscal year 2026 today at 4:30 p.m. Eastern time/1:30 p.m. Pacific time. Open to the public, investors may access the webcast, supplemental financial information and earnings slides from the "Investors" section of the company’s website at investors.paloaltonetworks.com. A replay will be available three hours after the conclusion of the webcast and archived for one year.

[0001327567-25-000024:8k_2_02:30]
Forward-Looking Statements

[0001327567-25-000024:8k_2_02:31]
For additional risks and uncertainties on these and other factors that could affect our financial results and cause actual results to differ materially from those described in the forward-looking statements we make in this press release are included under the captions "Risk Factors" and "Management's Discussion and Analysis of Financial Condition and Results of Operations" and elsewhere in our Quarterly Report on Form 10-Q filed with the U.S. Securities and Exchange Commission (“SEC”) on May 21, 2025, which is available on our website at investors.paloaltonetworks.com and on the SEC's website at www.sec.gov. Additional information will also be set forth in other documents that we file with or furnish to the SEC from time to time. All forward-looking statements in this press release are based on our current beliefs and information available to management as of the date hereof and are inherently uncertain, and we do not assume any obligation to update the forward-looking statements provided to reflect events that occur or circumstances that exist after the date on which they were made.

[0001327567-25-000024:8k_2_02:32]
Non-GAAP Financial Measures and Other Key Metrics

[0001327567-25-000024:8k_2_02:33]
Palo Alto Networks has provided in this press release financial information that has not been prepared in accordance with generally accepted accounting principles in the United States (GAAP). The company uses these non-GAAP financial measures and other key metrics internally in analyzing its financial results and believes that the use of these non-GAAP financial measures and key metrics are helpful to investors as an additional tool to evaluate ongoing operating results and trends, and in comparing the company’s financial results with other companies in its industry, many of which present similar non-GAAP financial measures or key metrics.

[0001327567-25-000024:8k_2_02:34]
The presentation of these non-GAAP financial measures and key metrics are not meant to be considered in isolation or as a substitute for comparable GAAP financial measures and should be read only in conjunction with the company’s consolidated financial statements prepared in accordance with GAAP. A reconciliation of the company’s historical non-GAAP financial measures to their most directly comparable GAAP measures has been provided in the financial statement tables included in this press release, and investors are encouraged to review these reconciliations.

[0001327567-25-000024:8k_2_02:35]
Non-GAAP net income and net income per share, diluted. Palo Alto Networks defines non-GAAP net income as net income plus share-based compensation-related charges, including share-based payroll tax expense, acquisition-related costs, including change in fair value of contingent consideration liability, amortization expense of acquired intangible assets, litigation-related charges, including legal settlements, and non-cash charges related to convertible notes. The company also excludes from non-GAAP net income tax adjustments related to our long-term non-GAAP effective tax rate in order to provide a complete picture of the company’s recurring core business operating results. The company defines non-GAAP net income per share, diluted, as non-GAAP net income divided by the weighted-average diluted shares outstanding, which includes the potentially dilutive effect of the company’s employee equity incentive plan awards and the company’s convertible senior notes and related warrants, after giving effect to the anti-dilutive impact of the company’s note hedge agreements, which reduced the potential economic dilution that otherwise would have occurred in connection with the conversion and settlement of the company’s convertible senior notes. Under GAAP, the anti-dilutive impact of the note hedge is not reflected in diluted shares outstanding. The company considers these non-GAAP financial measures to be useful metrics for management and investors for the same reasons that it uses non-GAAP operating margin.

[0001327567-25-000024:8k_2_02:36]
Next-Generation Security ARR. Palo Alto Networks defines Next-Generation Security ARR as the annualized allocated revenue of all active contracts as of the final day of the reporting period related to all product, subscription and support offerings, excluding revenue from hardware products, and legacy attached subscriptions, support offerings and professional services. The company considers Next-Generation Security ARR to be a useful operating metric for management and investors to assess the performance of the company because Next-Generation Security is where the company has focused its innovation and the company expects its overall revenue to be disproportionately driven by this Next-Generation Security portfolio. Because Next-Generation Security ARR does not have the effect of providing a numerical measure that is different from any comparable GAAP measure, the company does not consider it a non-GAAP measure.

[0001327567-25-000024:8k_2_02:37]
Investors are cautioned that there are a number of limitations associated with the use of non-GAAP financial measures and key metrics as analytical tools. Many of the adjustments to the company’s GAAP financial measures reflect the exclusion of items that are recurring and will be reflected in the company’s financial results for the foreseeable future, such as share-based compensation, which is an important part of Palo Alto Networks’ employees’ compensation and impacts their performance. Furthermore, these non-GAAP financial measures are not based on any standardized methodology prescribed by GAAP, and the components that Palo Alto Networks excludes in its calculation of non-GAAP financial measures may differ from the components that its peer companies exclude when they report their non-GAAP results of operations. Palo Alto Networks compensates for these limitations by providing specific information regarding the GAAP amounts excluded from these non-GAAP financial measures. In the future, the company may also exclude non-recurring expenses and other expenses that do not reflect the company’s core business operating results.

[0001327567-25-000024:8k_2_02:38]
About Palo Alto Networks

[0001327567-25-000024:8k_2_02:39]
As the global AI and cybersecurity leader, Palo Alto Networks (NASDAQ: PANW) is dedicated to protecting our digital way of life via continuous innovation. Trusted by more than 70,000 organizations worldwide, we provide comprehensive AI-powered security solutions across network, cloud, and security operations, enhanced by the expertise and threat intelligence of Unit 42®. Our focus on platformization allows enterprises to streamline security at scale, ensuring protection fuels innovation. Explore more at www.paloaltonetworks.com.

[0001327567-25-000024:8k_2_02:40]
Palo Alto Networks and the Palo Alto Networks logo are trademarks of Palo Alto Networks, Inc. in the United States or in certain jurisdictions throughout the world. All other trademarks, trade names, or service marks used or mentioned herein belong to their respective owners. Any unreleased services or features (and any services or features not generally available to customers) referenced in this or other press releases or public statements are not currently available (or are not yet generally available to customers) and may not be delivered when expected or at all. Customers who purchase Palo Alto Networks applications should make their purchase decisions based on services and features currently generally available.

[0001327567-25-000024:8k_2_02:41]
Media Contact:

[0001327567-25-000024:8k_2_02:42]
Nicole Hockin

[0001327567-25-000024:8k_2_02:43]
VP, Global Communications, Palo Alto Networks

[0001327567-25-000024:8k_2_02:44]
press@paloaltonetworks.com

[0001327567-25-000024:8k_2_02:45]
Investor Relations Contact:

[0001327567-25-000024:8k_2_02:46]
Ryan Fenwick

[0001327567-25-000024:8k_2_02:47]
Director - Investor Relations, Palo Alto Networks

[0001327567-25-000024:8k_2_02:48]
ir@paloaltonetworks.com

[0001327567-25-000024:8k_2_02:49]
1

[0001327567-25-000024:8k_2_02:50]
| Palo Alto Networks, Inc. |
| Preliminary Condensed Consolidated Statements of Operations |
| (In millions, except per share data) |
| (Unaudited) |
|  | Three Months Ended |  | Year Ended |
|  | July 31, |  | July 31, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Revenue: |  |  |  |  |  |  |  |
| Product | $ | 573.9 |  |  | $ | 480.5 |  |  | $ | 1,801.9 |  |  | $ | 1,603.3 |  |
| Subscription and support | 1,962.4 |  |  | 1,709.0 |  |  | 7,419.6 |  |  | 6,424.2 |  |
| Total revenue | 2,536.3 |  |  | 2,189.5 |  |  | 9,221.5 |  |  | 8,027.5 |  |
| Cost of revenue: |  |  |  |  |  |  |  |
| Product | 136.2 |  |  | 104.7 |  |  | 413.2 |  |  | 348.2 |  |
| Subscription and support | 542.8 |  |  | 469.0 |  |  | 2,038.4 |  |  | 1,711.0 |  |
| Total cost of revenue | 679.0 |  |  | 573.7 |  |  | 2,451.6 |  |  | 2,059.2 |  |
| Total gross profit | 1,857.3 |  |  | 1,615.8 |  |  | 6,769.9 |  |  | 5,968.3 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 503.5 |  |  | 494.8 |  |  | 1,984.1 |  |  | 1,809.4 |  |
| Sales and marketing | 829.3 |  |  | 742.3 |  |  | 3,100.2 |  |  | 2,794.5 |  |
| General and administrative | 27.3 |  |  | 140.3 |  |  | 442.7 |  |  | 680.5 |  |
| Total operating expenses | 1,360.1 |  |  | 1,377.4 |  |  | 5,527.0 |  |  | 5,284.4 |  |
| Operating income | 497.2 |  |  | 238.4 |  |  | 1,242.9 |  |  | 683.9 |  |
| Interest expense | (0.2) |  |  | (0.3) |  |  | (3.0) |  |  | (8.3) |  |
| Other income, net | 94.8 |  |  | 80.9 |  |  | 355.8 |  |  | 312.7 |  |
| Income before income taxes | 591.8 |  |  | 319.0 |  |  | 1,595.7 |  |  | 988.3 |  |
| Provision for (benefit from) income taxes | 338.0 |  |  | (38.7) |  |  | 461.8 |  |  | (1,589.3) |  |
| Net income | $ | 253.8 |  |  | $ | 357.7 |  |  | $ | 1,133.9 |  |  | $ | 2,577.6 |  |
| Net income per share, basic | $ | 0.38 |  |  | $ | 0.55 |  |  | $ | 1.71 |  |  | $ | 4.04 |  |
| Net income per share, diluted | $ | 0.36 |  |  | $ | 0.51 |  |  | $ | 1.60 |  |  | $ | 3.64 |  |
| Weighted-average shares used to compute net income per share, basic | 669.4 |  |  | 648.8 |  |  | 662.5 |  |  | 638.5 |  |
| Weighted-average shares used to compute net income per share, diluted | 709.0 |  |  | 707.8 |  |  | 709.3 |  |  | 707.9 |  |

[0001327567-25-000024:8k_2_02:51]
2

[0001327567-25-000024:8k_2_02:52]
| Palo Alto Networks, Inc. |
| Reconciliation of GAAP to Non-GAAP Financial Measures |
| (In millions, except per share amounts) |
| (Unaudited) |
|  | Three Months Ended |  | Year Ended |
|  | July 31, |  | July 31, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| GAAP net income | $ | 253.8 |  |  | $ | 357.7 |  |  | $ | 1,133.9 |  |  | $ | 2,577.6 |  |
| Share-based compensation-related charges | 372.7 |  |  | 287.1 |  |  | 1,386.4 |  |  | 1,161.7 |  |
| Acquisition-related costs(1) | (141.8) |  |  | 3.5 |  |  | (109.7) |  |  | 13.6 |  |
| Amortization expense of acquired intangible assets | 36.9 |  |  | 33.7 |  |  | 164.0 |  |  | 119.0 |  |
| Litigation-related charges(2) | 3.2 |  |  | 25.6 |  |  | (31.7) |  |  | 211.5 |  |
| Non-cash charges related to convertible notes(3) | 0.1 |  |  | 0.6 |  |  | 1.1 |  |  | 3.5 |  |
| Income tax and other tax adjustments(4) | 148.1 |  |  | (186.0) |  |  | (199.5) |  |  | (2,138.8) |  |
| Non-GAAP net income | $ | 673.0 |  |  | $ | 522.2 |  |  | $ | 2,344.5 |  |  | $ | 1,948.1 |  |
| GAAP net income per share, diluted | $ | 0.36 |  |  | $ | 0.51 |  |  | $ | 1.60 |  |  | $ | 3.64 |  |
| Share-based compensation-related charges | 0.53 |  |  | 0.41 |  |  | 1.98 |  |  | 1.73 |  |
| Acquisition-related costs(1) | (0.20) |  |  | 0.00 |  |  | (0.15) |  |  | 0.02 |  |
| Amortization expense of acquired intangible assets | 0.05 |  |  | 0.05 |  |  | 0.23 |  |  | 0.17 |  |
| Litigation-related charges(2) | 0.00 |  |  | 0.04 |  |  | (0.04) |  |  | 0.30 |  |
| Non-cash charges related to convertible notes(3) | 0.00 |  |  | 0.00 |  |  | 0.00 |  |  | 0.00 |  |
| Income tax and other tax adjustments(4) | 0.21 |  |  | (0.26) |  |  | (0.28) |  |  | (3.02) |  |
| Non-GAAP net income per share, diluted | $ | 0.95 |  |  | $ | 0.75 |  |  | $ | 3.34 |  |  | $ | 2.84 |  |
| GAAP weighted-average shares used to compute net income per share, diluted | 709.0 |  |  | 707.8 |  |  | 709.3 |  |  | 707.9 |  |
| Weighted-average anti-dilutive impact of note hedge agreements | (2.1) |  |  | (14.7) |  |  | (7.3) |  |  | (20.7) |  |
| Non-GAAP weighted-average shares used to compute net income per share, diluted | 706.9 |  |  | 693.1 |  |  | 702.0 |  |  | 687.2 |  |

[0001327567-25-000024:8k_2_02:53]
(1)    Consists of acquisition transaction costs, share-based compensation related to the cash settlement of certain equity awards, change in fair value of contingent consideration liability, and costs to terminate certain employment, operating lease, and other contracts of the acquired companies.

[0001327567-25-000024:8k_2_02:54]
(2)    Consists of the amortization of intellectual property licenses and covenant not to sue, and a legal contingency charge (credit). During the three months and fiscal year ended July 31, 2024, it also includes a litigation settlement charge.

[0001327567-25-000024:8k_2_02:55]
(3)    Consists of non-cash interest expense for amortization of debt issuance costs related to the company's convertible senior notes.

[0001327567-25-000024:8k_2_02:56]
(4)    Consists of income tax adjustments related to our long-term non-GAAP effective tax rate. During the three months and fiscal year ended July 31, 2025, it included a one-time deferred tax provision adjustment relating to the enactment of One Big Beautiful Bill. During the three months and fiscal year ended July 31, 2024, it included a tax benefit from a release of our valuation allowance on U.S. federal, U.S. states other than California, and United Kingdom deferred tax assets.

[0001327567-25-000024:8k_2_02:57]
3

[0001327567-25-000024:8k_2_02:58]
| Palo Alto Networks, Inc. |
| Preliminary Condensed Consolidated Balance Sheets |
| (In millions) |
|  | July 31, 2025 |  | July 31, 2024 |
|  | (unaudited) |  |  |
| Assets |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 2,268.6 |  |  | $ | 1,535.2 |  |
| Short-term investments | 634.6 |  |  | 1,043.6 |  |
| Accounts receivable, net | 2,965.0 |  |  | 2,618.6 |  |
| Short-term financing receivables, net | 714.6 |  |  | 725.9 |  |
| Short-term deferred contract costs | 419.5 |  |  | 369.0 |  |
| Prepaid expenses and other current assets | 520.5 |  |  | 557.4 |  |
| Total current assets | 7,522.8 |  |  | 6,849.7 |  |
| Property and equipment, net | 387.3 |  |  | 361.1 |  |
| Operating lease right-of-use assets | 347.0 |  |  | 385.9 |  |
| Long-term investments | 5,555.6 |  |  | 4,173.2 |  |
| Long-term financing receivables, net | 1,002.3 |  |  | 1,182.1 |  |
| Long-term deferred contract costs | 585.9 |  |  | 562.0 |  |
| Goodwill | 4,566.6 |  |  | 3,350.1 |  |
| Intangible assets, net | 762.7 |  |  | 374.9 |  |
| Deferred tax assets | 2,424.2 |  |  | 2,399.0 |  |
| Other assets | 421.8 |  |  | 352.9 |  |
| Total assets | $ | 23,576.2 |  |  | $ | 19,990.9 |  |
| Liabilities and stockholders’ equity |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 232.2 |  |  | $ | 116.3 |  |
| Accrued compensation | 607.6 |  |  | 554.7 |  |
| Accrued and other liabilities | 846.0 |  |  | 506.7 |  |
| Deferred revenue | 6,302.2 |  |  | 5,541.1 |  |
| Convertible senior notes, net | — |  |  | 963.9 |  |
| Total current liabilities | 7,988.0 |  |  | 7,682.7 |  |
| Long-term deferred revenue | 6,449.7 |  |  | 5,939.4 |  |
| Deferred tax liabilities | 89.1 |  |  | 387.7 |  |
| Long-term operating lease liabilities | 338.2 |  |  | 380.5 |  |
| Other long-term liabilities | 886.8 |  |  | 430.9 |  |
| Total liabilities | 15,751.8 |  |  | 14,821.2 |  |
| Stockholders’ equity: |  |  |  |
| Preferred stock | — |  |  | — |  |
| Common stock and additional paid-in capital | 5,291.9 |  |  | 3,821.1 |  |
| Accumulated other comprehensive income (loss) | 48.4 |  |  | (1.6) |  |
| Retained earnings | 2,484.1 |  |  | 1,350.2 |  |
| Total stockholders’ equity | 7,824.4 |  |  | 5,169.7 |  |
| Total liabilities and stockholders’ equity | $ | 23,576.2 |  |  | $ | 19,990.9 |  |

[0001327567-25-000024:8k_2_02:59]
4

## item 5.02 — body, verbatim

[0001327567-25-000024:8k_body:1]
Item 5.02 Departure of Directors or Certain Officers; Election of Directors; Appointment of Certain Officers; Compensatory Arrangements of Certain Officers.

[0001327567-25-000024:8k_body:2]
Nir Zuk

[0001327567-25-000024:8k_body:3]
On August 13, 2025, Nir Zuk informed the Board of Directors (the “Board”) of the Company of his resignation as the Company’s Chief Technology Officer and as a director on the Board, effective August 14, 2025. Mr. Zuk is expected to continue to provide advisory services to the Company through November 2, 2026, in connection with the Company’s Continued Service Policy. Mr. Zuk resigned voluntarily for strictly personal reasons.

[0001327567-25-000024:8k_body:4]
The forgoing description of Mr. Zuk’s continued services to the Company is qualified in its entirety by the full text of the Company’s Continued Service Policy (see Exhibit 10.21 to our Annual Report on Form 10-K for the fiscal year ended July 31, 2024 filed with the Securities and Exchange Commission on September 6, 2024).

[0001327567-25-000024:8k_body:5]
Lee Klarich

[0001327567-25-000024:8k_body:6]
On August 14, 2025, the Board appointed Lee Klarich to the Board to serve as a Class I director whose term expires at the annual meeting of the Company to be held in 2027. In addition, the Board appointed Mr. Klarich as the chair of the Security Committee of the Board, and to assume an expanded role as the Company’s Chief Product and Technology Officer.

[0001327567-25-000024:8k_body:7]
Prior to this appointment, Mr. Klarich, age 50, served as the Company’s Chief Product Officer since  August 2017. Mr. Klarich served as the Company’s Executive Vice President of Product Management from November 2015 to August 2017, as the Company’s Senior Vice President, Product Management from November 2012 to November 2015, and as the Company’s Vice President, Product Management from May 2006 to November 2012. Prior to joining the Company, Mr. Klarich held various positions at NetScreen Technologies, Juniper Networks, Excite@Home, and Packard Bell-NEC. Mr. Klarich holds a B.S. in Engineering from Cornell University.

[0001327567-25-000024:8k_body:8]
As Mr. Klarich is an existing employee of the Company, he will not receive additional compensation in connection with his appointment to the Board under the Company’s Amended and Restated Outside Director Compensation Policy. Mr. Klarich will continue to be compensated in connection with his employment with the Company; as the Company’s Chief Product and Technology Officer.

[0001327567-25-000024:8k_body:9]
Mr. Klarich has executed the Company’s standard form of indemnification agreement (see Exhibit 10.1 to our Annual Report on Form 10-K for the fiscal year ended July 31, 2024 filed with the Securities and Exchange Commission on September 6, 2024).

[0001327567-25-000024:8k_body:10]
There is no arrangement or understanding between Mr. Klarich and any other persons pursuant to which Mr. Klarich was elected as a director.

[0001327567-25-000024:8k_body:11]
Mr. Klarich is not a party to any transaction, or series of transactions, required to be disclosed pursuant to Item 404(a) of Regulation S-K.

[0001327567-25-000024:8k_body:12]
On August 18, 2025, the Company issued a press release announcing the appointment of Mr. Klarich as a director, and the resignation of Mr. Zuk. The press release is attached herewith as Exhibit 99.2.
