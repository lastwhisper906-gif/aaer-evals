# PANW MD&A — 0001327567-25-000027


## mdna

[0001327567-25-000027:mdna:1]
Item 7. Management’s Discussion and Analysis of Financial Condition and Results of Operations

[0001327567-25-000027:mdna:2]
The following discussion and analysis of our financial condition and results of operations should be read in conjunction with our consolidated financial statements and related notes appearing elsewhere in this Annual Report on Form 10-K. The following discussion and analysis contains forward-looking statements based on current expectations and assumptions that are subject to risks and uncertainties, which could cause our actual results to differ materially from those anticipated or implied by any forward-looking statements. Factors that could cause or contribute to such differences include, but are not limited to, those discussed in this Annual Report on Form 10-K, and in particular, the risks discussed under the caption “Risk Factors” in Part I, Item 1A of this report.

[0001327567-25-000027:mdna:3]
Our Management’s Discussion and Analysis of Financial Condition and Results of Operations (“MD&A”) is organized as follows:

[0001327567-25-000027:mdna:4]
•Overview. A discussion of our business and overall analysis of financial and other highlights in order to provide context for the remainder of MD&A.

[0001327567-25-000027:mdna:5]
•Key Financial Metrics. A summary of our U.S. GAAP and non-GAAP key financial metrics, which management monitors to evaluate our performance.

[0001327567-25-000027:mdna:6]
•Results of Operations. A discussion of the nature and trends in our financial results and an analysis of our financial results comparing fiscal 2025 to fiscal 2024. For discussion and analysis related to our financial results comparing fiscal 2024 to 2023, refer to Part II, Item 7. Management’s Discussion and Analysis of Financial Condition and Results of Operations in our Annual Report on Form 10-K for fiscal 2024, which was filed with the Securities and Exchange Commission on September 6, 2024.

[0001327567-25-000027:mdna:7]
•Liquidity and Capital Resources. An analysis of changes on our balance sheets and cash flows, and a discussion of our financial condition and our ability to meet cash needs.

[0001327567-25-000027:mdna:8]
•Critical Accounting Estimates. A discussion of our accounting policies that require critical estimates, assumptions, and judgments.

[0001327567-25-000027:mdna:9]
•Recent Accounting Pronouncements. A discussion of expected impacts of impending accounting changes on financial information to be reported in the future.

[0001327567-25-000027:mdna:10]
Overview

[0001327567-25-000027:mdna:11]
Our mission is to be the cybersecurity partner of choice for enterprises, organizations, service providers, and government entities to protect our digital way of life. Our cybersecurity platforms and services help secure enterprise users, networks, clouds, and endpoints by delivering comprehensive cybersecurity backed by artificial intelligence (“AI”) and automation. A key element of our strategy is to help our customers simplify their security architectures through consolidating disparate point products. We execute on this strategy by developing our capabilities and packaging our offerings into platforms which are able to cover many of our customers’ needs in the markets in which we operate. Our platformization strategy combines various products and services into a tightly integrated architecture for more secure, faster, and cost-effective outcomes.

[0001327567-25-000027:mdna:12]
Network Security

[0001327567-25-000027:mdna:13]
Our network security platform is designed to deliver complete zero trust solutions to our customers. The platform includes:

[0001327567-25-000027:mdna:14]
•Secure Access Service Edge (“SASE”). Prisma® Access, when combined with Prisma SD-WAN, provides a comprehensive single-vendor SASE offering that is used to secure remote workforces and cloud-delivered branch offices. Prisma Access Browser further extends SASE security and data protection to the end user device, providing workers with freedom to access business applications securely using our secure browser from any device.

[0001327567-25-000027:mdna:15]
•Next-Generation Firewalls. Our hardware ML-Powered Next-Generation Firewalls (“NGFWs”) secure on-premises environments including campus locations and data centers. Our software NGFWs secure cloud networks.

[0001327567-25-000027:mdna:16]
•Cloud-Delivered Security Services (“CDSS”). Our network security platform integrates a suite of CDSS that complements our SASE and Firewall solutions. These include Advanced Threat Prevention, Advanced WildFire®, Advanced URL Filtering, Advanced DNS Security, IoT/OT Security, GlobalProtect®, Prisma Access Agent, Enterprise Data Loss Prevention (“Enterprise DLP”), AI for IT Operations (“AIOps”), Software as a Service (“SaaS”) Security, and AI Access Security. Through these add-on services, our customers are able to secure their content, applications, users, and devices across their entire organization.

[0001327567-25-000027:mdna:17]
•Prisma AIRS. Prisma AIRS is a comprehensive AI security platform that has been designed to protect customers’ entire AI ecosystem by providing AI model scanning, posture management, red teaming, run-time security, and AI agent security.

[0001327567-25-000027:mdna:18]
- 42 -

[0001327567-25-000027:mdna:19]
•Strata Cloud Manager (“SCM”). SCM, our network security management solution, centrally manages network security across all remote workers, branches, headquarters, campuses, and cloud. SCM leverages AI to simplify and strengthen network security by enabling customers to proactively pinpoint vulnerabilities, gain real-time remediation recommendations, and enhance overall digital experiences, thereby reducing operational burden. This comprehensive solution includes Strata Copilot, which offers a natural language interface for enhanced insights and guided remediation, and integrates Autonomous Digital Experience Monitoring (“ADEM”) to proactively maintain infrastructure health, facilitate AI-driven one-click troubleshooting, and ensure seamless end-user performance across the enterprise.

[0001327567-25-000027:mdna:20]
Security Operations

[0001327567-25-000027:mdna:21]
Our AI-powered Cortex platform transforms end-to-end security operations with unified data, AI, and automation for more secure, faster, and cost effective outcomes. We have consolidated our industry-leading Security Operations and Cloud Security capabilities on a single comprehensive platform to provide centralized visibility, proactive protection, real-time prevention, AI-driven insights, and automated remediation across enterprise and cloud.

[0001327567-25-000027:mdna:22]
•Security Operations. We deliver the next generation of security operations capabilities that unifies standalone Security Information and Event Management (“SIEM”) tools, endpoint security, security automation, cloud detection and response (“CDR”), as well as attack surface management (“ASM”) capabilities on our Cortex® platform. These include Cortex XSIAM®, for AI-powered security operations replacing traditional SIEM tools, Cortex XDR®, for the prevention, detection, and response to complex cybersecurity attacks, Cortex XSOAR®, for security orchestration, automation, and response (“SOAR”), and Cortex Xpanse®, for ASM.

[0001327567-25-000027:mdna:23]
•Cloud Security. We deliver comprehensive security across the cloud application development lifecycle through Cortex Cloud, delivered as a scalable SaaS offering. As a comprehensive Cloud Native Application Protection Platform (“CNAPP”) combined with CDR, Cortex Cloud secures multi- and hybrid-cloud environments for applications, data, generative AI (“GenAI”) ecosystem, and the cloud native technology stack across the full development lifecycle, from code to cloud to security operations. As part of the Cortex Cloud platform, customers can expand from Cortex Cloud to our security operations offerings available on a single user experience and unified agent. We also offer our VM-Series and CN-Series virtual firewalls for inline network security on multi- and hybrid-cloud environments.

[0001327567-25-000027:mdna:24]
Threat Intelligence and Advisory Services

[0001327567-25-000027:mdna:25]
•Unit 42 brings together world-renowned expertise across threat research, incident response, and security consulting to deliver intelligence-driven, response-ready outcomes that help customers reduce cyber risk. Our elite consultants serve as trusted advisors to our customers by assessing and testing their security controls against sophisticated threats, transforming their security strategy with a threat-informed approach, and responding to security incidents on behalf of our clients. Additionally, Unit 42 offers managed detection and response (“MDR”) and managed threat hunting services.

[0001327567-25-000027:mdna:26]
For fiscal 2025 and 2024, total revenue was $9.2 billion and $8.0 billion, respectively, representing year-over-year growth of 14.9%. Our growth reflects the increased adoption of our portfolio, which consists of product, subscriptions, and support. We believe our portfolio will enable us to benefit from recurring revenues and new revenues as we continue to grow our end-customer base. As of July 31, 2025, we had end-customers in over 180 countries. Our end-customers represent a broad range of industries, including education, energy, financial services, government entities, healthcare, Internet and media, manufacturing, public sector, and telecommunications, and include almost all of the Fortune 100 companies and a majority of the Global 2000 companies. We maintain a field sales force that works closely with our channel partners in developing sales opportunities. We primarily use a two-tiered, indirect fulfillment model whereby we sell our products, subscriptions, and support to our distributors, which, in turn, sell to our resellers, which then sell to our end-customers.

[0001327567-25-000027:mdna:27]
Our product revenue grew to $1.8 billion or 19.5% of total revenue for fiscal 2025, representing year-over-year growth of 12.4%. Product revenue is derived from sales of hardware products, primarily our ML-Powered Next-Generation Firewall, and software licenses, including SD-WAN, the VM-Series, and Panorama®. Our ML-Powered Next-Generation Firewall incorporates our PAN-OS operating system, which provides a consistent set of capabilities across our entire network security product line. Our hardware products and software licenses include a broad set of built-in networking and security features and functionalities. Our products are designed for different performance requirements throughout an organization, ranging from our PA-400, which is designed for small organizations and remote or branch offices, to our top-of-the-line PA-7500, which is designed for large-scale data centers and service provider use. The same firewall functionality that is delivered in our hardware products is also available in our VM-Series virtual firewalls, which secure virtualized and cloud-based computing environments, and in our CN-Series container firewalls, which secure container environments and traffic.

[0001327567-25-000027:mdna:28]
- 43 -

[0001327567-25-000027:mdna:29]
Our subscription and support revenue grew to $7.4 billion or 80.5% of total revenue for fiscal 2025, representing year-over-year growth of 15.5%. Our subscriptions provide our end-customers with near real-time access to the latest intrusion prevention, web security, modern malware prevention, data loss prevention, CASB and AI security capabilities across the network, endpoints, and the cloud. Our subscriptions also include security operations, which enable customers to leverage the AI-powered Cortex platform for advanced capabilities such as security information and event management, next-generation antivirus, endpoint detection and response, extended detection and response, identity threat detection and response, cloud detection and response, SOAR, ASM, and CNAPP for comprehensive cloud security. Additionally, we offer MDR for Cortex subscriptions, powered by Unit 42’s elite expertise. When customers purchase our physical, virtual, or container firewalls, or certain cloud offerings, they typically purchase support in order to receive ongoing security updates, upgrades, bug fixes, and repairs. In addition to the subscriptions purchased with these firewalls, customers may also purchase other subscriptions on a per-user, per-endpoint, or capacity-based basis. We also offer professional services, including incident response, risk management, and digital forensic services.

[0001327567-25-000027:mdna:30]
We continue to invest in innovation as we evolve and further extend the capabilities of our portfolio, as we believe that innovation and timely development of new features and products are essential to meeting the needs of our end-customers and improving our competitive position. During fiscal 2025, we introduced several new offerings, including: Prisma Access Browser, new capabilities in our OT Security solution, Cortex Cloud, Prisma AIRS, and Cortex XSIAM 3.0. Additionally, in August 2024, we completed the acquisition of certain IBM QRadar assets, which we expect will help accelerate the growth of our Cortex business. Additionally, in July 2025, we completed the acquisition of Protect AI, which we expect will enhance the capabilities of our AI security platform. In July 2025, we also entered into a definitive agreement to acquire Software Ltd. (“CyberArk”), an identity security company, which acquisition is expected to close during the second half of our fiscal 2026.

[0001327567-25-000027:mdna:31]
We believe that the growth of our business and our short-term and long-term success are dependent upon many factors, including our ability to extend our technology leadership, grow our base of end-customers, expand deployment of our portfolio and support offerings within existing end-customers, focus on end-customer satisfaction, and address any product vulnerabilities. To manage any future growth effectively, we must continue to improve and expand our information technology and financial infrastructure, our operating and administrative systems and controls, and our ability to manage headcount, capital, and processes in an efficient manner. While these areas present significant opportunities for us, they also pose challenges and risks that we must successfully address in order to sustain the growth of our business and improve our operating results. For additional information regarding the challenges and risks we face, see the “Risk Factors” section in Part I, Item 1A of this Annual Report on Form 10-K.

[0001327567-25-000027:mdna:32]
IMPACT OF MACROECONOMIC DEVELOPMENTS AND OTHER FACTORS ON OUR BUSINESS

[0001327567-25-000027:mdna:33]
Our overall performance depends in part on worldwide economic and geopolitical conditions and their impact on customer behavior. Changes in legislation or regulations and actions by regulators, including changes in enforcement and administration policies, may have an impact on our results of operations and financial condition. Significant changes in U.S. or global trade policy, including further expansion of U.S. export/imports controls and tariffs, as well as retaliatory actions by other countries, may materially and adversely affect our business. Further, economic conditions, including inflation, high interest rates, slow growth, fluctuations in foreign exchange rates, supply chain disruptions, impacts of trade regulations or international trade disputes, and other conditions, may adversely affect our results of operations and financial performance.

[0001327567-25-000027:mdna:34]
The hostilities in Israel and the surrounding region have continued to result in economic and political uncertainty. While we have business operations in Israel, and intend to continue growing our presence in Israel, we currently do not expect significant business disruption. We are actively monitoring, evaluating, and responding to the situation.

[0001327567-25-000027:mdna:35]
We are also monitoring the impact of inflationary pressures and the tensions between China and Taiwan, and between the U.S. and China, which could have an adverse impact on our business or results of operations in future periods.

[0001327567-25-000027:mdna:36]
Key Financial Metrics

[0001327567-25-000027:mdna:37]
We monitor the key financial metrics set forth in the tables below to help us evaluate growth trends, establish budgets, measure the effectiveness of our sales and marketing efforts, and assess operational efficiencies. We discuss revenue, gross margin, and the components of operating income and margin below under “Results of Operations.”

[0001327567-25-000027:mdna:38]
|  | July 31, |
|  | 2025 |  | 2024 |
|  | (in billions) |
| Next-Generation Security Annualized Recurring Revenue | $ | 5.6 |  |  | $ | 4.2 |  |
| Remaining performance obligations | $ | 15.8 |  |  | $ | 12.7 |  |

[0001327567-25-000027:mdna:39]
- 44 -

[0001327567-25-000027:mdna:40]
|  | Year Ended July 31, |
|  | 2025 |  | 2024 |  | 2023 |
|  | (dollars in millions) |
| Total revenue | $ | 9,221.5 |  |  | $ | 8,027.5 |  |  | $ | 6,892.7 |  |
| Total revenue year-over-year percentage increase | 14.9 | % |  | 16.5 | % |  | 25.3 | % |
| Gross margin | 73.4 | % |  | 74.3 | % |  | 72.3 | % |
| Operating income | $ | 1,242.9 |  |  | $ | 683.9 |  |  | $ | 387.3 |  |
| Operating margin | 13.5 | % |  | 8.5 | % |  | 5.6 | % |
| Cash flow provided by operating activities | $ | 3,716.0 |  |  | $ | 3,257.6 |  |  | $ | 2,777.5 |  |
| Free cash flow (non-GAAP) | $ | 3,469.8 |  |  | $ | 3,100.8 |  |  | $ | 2,631.2 |  |

[0001327567-25-000027:mdna:41]
•Next-Generation Security Annualized Recurring Revenue (“NGS ARR”). Our NGS ARR represents the annualized allocated revenue of all active contracts as of the final day of the reporting period related to all product, subscription and support offerings, excluding revenue from hardware products, and legacy attached subscriptions, support offerings and professional services. NGS ARR is an operating metric that we use to assess the strength and trajectory of our business. NGS ARR should be viewed independently of revenue, deferred revenue and remaining performance obligations and does not represent our revenue under U.S. GAAP on an annualized basis, as it is an operating metric that can be impacted by contract start and end dates and renewal rates. NGS ARR is not intended to be a replacement for forecasts of revenue. The scope of products, subscriptions, and support offerings that contribute to NGS ARR will generally increase over time as we introduce or acquire new next-generation products, subscriptions, and support offerings.

[0001327567-25-000027:mdna:42]
•Cash Flow Provided by Operating Activities. We monitor cash flow provided by operating activities as a measure of our overall business performance. Our cash flow provided by operating activities is driven in large part by sales of our products and from up-front payments for subscription and support offerings. Monitoring cash flow provided by operating activities enables us to analyze our financial performance without the non-cash effects of certain items such as share-based compensation costs, depreciation, and amortization, thereby allowing us to better understand and manage the cash needs of our business.

[0001327567-25-000027:mdna:43]
•Free Cash Flow (non-GAAP). We define free cash flow, a non-GAAP financial measure, as cash provided by operating activities less purchases of property, equipment, and other assets. We consider free cash flow to be a profitability and liquidity measure that provides useful information to management and investors about the amount of cash generated by the business after necessary capital expenditures. A limitation of the utility of free cash flow as a measure of our financial performance and liquidity is that it does not represent the total increase or decrease in our cash balance for the period. In addition, it is important to note that other companies, including companies in our industry, may not use free cash flow, may calculate free cash flow in a different manner than we do, or may use other financial measures to evaluate their performance, all of which could reduce the usefulness of free cash flow as a comparative measure. A reconciliation of free cash flow to cash flow provided by operating activities, the most directly comparable financial measure calculated and presented in accordance with U.S. GAAP, is provided below:

[0001327567-25-000027:mdna:44]
|  | Year Ended July 31, |
|  | 2025 |  | 2024 |  | 2023 |
|  | (in millions) |
| Free cash flow (non-GAAP): |  |  |  |  |  |
| Net cash provided by operating activities | $ | 3,716.0 |  |  | $ | 3,257.6 |  |  | $ | 2,777.5 |  |
| Less: purchases of property, equipment, and other assets | 246.2 |  |  | 156.8 |  |  | 146.3 |  |
| Free cash flow (non-GAAP) | $ | 3,469.8 |  |  | $ | 3,100.8 |  |  | $ | 2,631.2 |  |
| Net cash used in investing activities | $ | (2,204.7) |  |  | $ | (1,509.9) |  |  | $ | (2,033.8) |  |
| Net cash used in financing activities | $ | (778.9) |  |  | $ | (1,343.1) |  |  | $ | (1,726.3) |  |

[0001327567-25-000027:mdna:45]
- 45 -

[0001327567-25-000027:mdna:46]
Results of Operations

[0001327567-25-000027:mdna:47]
The following table summarizes our results of operations for the periods presented and as a percentage of our total revenue for those periods based on our consolidated statements of operations data. The period-to-period comparison of results is not necessarily indicative of results for future periods.

[0001327567-25-000027:mdna:48]
|  | Year Ended July 31, |
|  | 2025 |  | 2024 |  | 2023 |
|  | Amount |  | % of Revenue |  | Amount |  | % of Revenue |  | Amount |  | % of Revenue |
|  | (dollars in millions) |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 1,801.9 |  |  | 19.5 | % |  | $ | 1,603.3 |  |  | 20.0 | % |  | $ | 1,578.4 |  |  | 22.9 | % |
| Subscription and support | 7,419.6 |  |  | 80.5 | % |  | 6,424.2 |  |  | 80.0 | % |  | 5,314.3 |  |  | 77.1 | % |
| Total revenue | 9,221.5 |  |  | 100.0 | % |  | 8,027.5 |  |  | 100.0 | % |  | 6,892.7 |  |  | 100.0 | % |
| Cost of revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Product | 413.2 |  |  | 4.5 | % |  | 348.2 |  |  | 4.3 | % |  | 418.3 |  |  | 6.1 | % |
| Subscription and support | 2,038.4 |  |  | 22.1 | % |  | 1,711.0 |  |  | 21.4 | % |  | 1,491.4 |  |  | 21.6 | % |
| Total cost of revenue(1) | 2,451.6 |  |  | 26.6 | % |  | 2,059.2 |  |  | 25.7 | % |  | 1,909.7 |  |  | 27.7 | % |
| Total gross profit | 6,769.9 |  |  | 73.4 | % |  | 5,968.3 |  |  | 74.3 | % |  | 4,983.0 |  |  | 72.3 | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | 1,984.1 |  |  | 21.5 | % |  | 1,809.4 |  |  | 22.5 | % |  | 1,604.0 |  |  | 23.3 | % |
| Sales and marketing | 3,100.2 |  |  | 33.6 | % |  | 2,794.5 |  |  | 34.8 | % |  | 2,544.0 |  |  | 36.9 | % |
| General and administrative | 442.7 |  |  | 4.8 | % |  | 680.5 |  |  | 8.5 | % |  | 447.7 |  |  | 6.5 | % |
| Total operating expenses(1) | 5,527.0 |  |  | 59.9 | % |  | 5,284.4 |  |  | 65.8 | % |  | 4,595.7 |  |  | 66.7 | % |
| Operating income | 1,242.9 |  |  | 13.5 | % |  | 683.9 |  |  | 8.5 | % |  | 387.3 |  |  | 5.6 | % |
| Interest expense | (3.0) |  |  | — | % |  | (8.3) |  |  | (0.1) | % |  | (27.2) |  |  | (0.4) | % |
| Other income, net | 355.8 |  |  | 3.8 | % |  | 312.7 |  |  | 3.9 | % |  | 206.2 |  |  | 3.0 | % |
| Income before income taxes | 1,595.7 |  |  | 17.3 | % |  | 988.3 |  |  | 12.3 | % |  | 566.3 |  |  | 8.2 | % |
| Provision for (benefit from) income taxes | 461.8 |  |  | 5.0 | % |  | (1,589.3) |  |  | (19.8) | % |  | 126.6 |  |  | 1.8 | % |
| Net income | $ | 1,133.9 |  |  | 12.3 | % |  | $ | 2,577.6 |  |  | 32.1 | % |  | $ | 439.7 |  |  | 6.4 | % |

[0001327567-25-000027:mdna:49]
(1)Includes share-based compensation as follows:

[0001327567-25-000027:mdna:50]
|  | Year Ended July 31, |
|  | 2025 |  | 2024 |  | 2023 |
|  | (in millions) |
| Cost of product revenue | $ | 5.1 |  |  | $ | 7.3 |  |  | $ | 9.8 |  |
| Cost of subscription and support revenue | 127.0 |  |  | 121.0 |  |  | 123.4 |  |
| Research and development | 550.5 |  |  | 525.5 |  |  | 488.4 |  |
| Sales and marketing | 359.5 |  |  | 300.8 |  |  | 335.3 |  |
| General and administrative | 258.0 |  |  | 124.1 |  |  | 130.4 |  |
| Total share-based compensation | $ | 1,300.1 |  |  | $ | 1,078.7 |  |  | $ | 1,087.3 |  |

[0001327567-25-000027:mdna:51]
- 46 -

[0001327567-25-000027:mdna:52]
REVENUE

[0001327567-25-000027:mdna:53]
Our revenue consists of product revenue and subscription and support revenue. Revenue is recognized upon transfer of control of the corresponding promised products and subscriptions and support to our customers in an amount that reflects the consideration we expect to be entitled to in exchange for those products and subscriptions and support. We expect our revenue to vary from quarter to quarter based on seasonal and cyclical factors.

[0001327567-25-000027:mdna:54]
PRODUCT REVENUE

[0001327567-25-000027:mdna:55]
Product revenue is derived from sales of hardware products, primarily our ML-Powered Next-Generation Firewall, and software licenses, including SD-WAN, the VM-Series, and Panorama. Our hardware products and software licenses include a broad set of built-in networking and security features and functionalities. We recognize product revenue at the time of hardware shipment or delivery of software license. As a percentage of product revenue, we expect our revenue from software licenses to vary from quarter to quarter and increase over the long term as we improve features and capabilities of our on-premise software, renew our software license contracts, and expand our installed end-customer base.

[0001327567-25-000027:mdna:56]
|  | Year Ended July 31, |  |  |  | Year Ended July 31, |  |  |
|  | 2025 |  | 2024 |  | Change |  | 2024 |  | 2023 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Product | $ | 1,801.9 |  |  | $ | 1,603.3 |  |  | $ | 198.6 |  |  | 12.4 | % |  | $ | 1,603.3 |  |  | $ | 1,578.4 |  |  | $ | 24.9 |  |  | 1.6 | % |

[0001327567-25-000027:mdna:57]
Product revenue increased for fiscal 2025 compared to fiscal 2024 driven by an increase in price of, and allocation to, on-premise software licenses due to enhanced features and capabilities beginning in the second quarter of fiscal 2025, and an increased demand for our new generation of hardware products and accessories, partially offset by decreased demand for our prior generation of hardware products.

[0001327567-25-000027:mdna:58]
SUBSCRIPTION AND SUPPORT REVENUE

[0001327567-25-000027:mdna:59]
Subscription and support revenue is derived primarily from sales of our subscription and support offerings. Our subscription and support contracts are typically one to five years. We recognize revenue from subscriptions and support over time as the services are performed. As a percentage of total revenue, we expect our subscription and support revenue to vary from quarter to quarter and increase over the long term as we introduce new subscriptions, renew existing subscription and support contracts, and expand our installed end-customer base.

[0001327567-25-000027:mdna:60]
|  | Year Ended July 31, |  |  |  | Year Ended July 31, |  |  |
|  | 2025 |  | 2024 |  | Change |  | 2024 |  | 2023 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Subscription | $ | 4,974.4 |  |  | $ | 4,188.5 |  |  | $ | 785.9 |  |  | 18.8 | % |  | $ | 4,188.5 |  |  | $ | 3,335.4 |  |  | $ | 853.1 |  |  | 25.6 | % |
| Support | 2,445.2 |  |  | 2,235.7 |  |  | 209.5 |  |  | 9.4 | % |  | 2,235.7 |  |  | 1,978.9 |  |  | 256.8 |  |  | 13.0 | % |
| Total subscription and support | $ | 7,419.6 |  |  | $ | 6,424.2 |  |  | $ | 995.4 |  |  | 15.5 | % |  | $ | 6,424.2 |  |  | $ | 5,314.3 |  |  | $ | 1,109.9 |  |  | 20.9 | % |

[0001327567-25-000027:mdna:61]
Subscription and support revenue increased for fiscal 2025 compared to fiscal 2024 due to increased demand for our subscription and support offerings from our end-customers. The mix between subscription revenue and support revenue will fluctuate over time, depending on the introduction of new subscription offerings, renewals of support services, and our ability to increase sales to new and existing end-customers.

[0001327567-25-000027:mdna:62]
- 47 -

[0001327567-25-000027:mdna:63]
REVENUE BY GEOGRAPHIC THEATER

[0001327567-25-000027:mdna:64]
|  | Year Ended July 31, |  |  |  | Year Ended July 31, |  |  |
|  | 2025 |  | 2024 |  | Change |  | 2024 |  | 2023 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Americas | $ | 6,205.1 |  |  | $ | 5,482.9 |  |  | $ | 722.2 |  |  | 13.2 | % |  | $ | 5,482.9 |  |  | $ | 4,719.9 |  |  | $ | 763.0 |  |  | 16.2 | % |
| Europe, the Middle East, and Africa (“EMEA”) | 1,917.4 |  |  | 1,602.0 |  |  | 315.4 |  |  | 19.7 | % |  | 1,602.0 |  |  | 1,359.6 |  |  | 242.4 |  |  | 17.8 | % |
| Asia Pacific and Japan (“APAC”) | 1,099.0 |  |  | 942.6 |  |  | 156.4 |  |  | 16.6 | % |  | 942.6 |  |  | 813.2 |  |  | 129.4 |  |  | 15.9 | % |
| Total revenue | $ | 9,221.5 |  |  | $ | 8,027.5 |  |  | $ | 1,194.0 |  |  | 14.9 | % |  | $ | 8,027.5 |  |  | $ | 6,892.7 |  |  | $ | 1,134.8 |  |  | 16.5 | % |

[0001327567-25-000027:mdna:65]
Revenue from the Americas, EMEA and APAC increased year-over-year for fiscal 2025 as we continued to increase investment in our global sales force in order to support our growth and innovation, with the Americas contributing the highest increase in revenue due to its larger scale.

[0001327567-25-000027:mdna:66]
COST OF REVENUE

[0001327567-25-000027:mdna:67]
Our cost of revenue consists of cost of product revenue and cost of subscription and support revenue.

[0001327567-25-000027:mdna:68]
COST OF PRODUCT REVENUE

[0001327567-25-000027:mdna:69]
Cost of product revenue primarily includes costs paid to our manufacturing partners for procuring components and manufacturing our products. Our cost of product revenue also includes personnel costs, which consist of salaries, benefits, bonuses, share-based compensation, and travel associated with our operations organization, inventory excess and obsolete charges, shipping and tariff costs, amortization of intellectual property licenses, product testing costs, and shared costs. Shared costs consist of certain facilities, depreciation, benefits, recruiting, and information technology costs that we allocate based on headcount. We expect our cost of product revenue to fluctuate with our revenue from hardware products.

[0001327567-25-000027:mdna:70]
|  | Year Ended July 31, |  |  |  | Year Ended July 31, |  |  |
|  | 2025 |  | 2024 |  | Change |  | 2024 |  | 2023 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Cost of product revenue | $ | 413.2 |  |  | $ | 348.2 |  |  | $ | 65.0 |  |  | 18.7 | % |  | $ | 348.2 |  |  | $ | 418.3 |  |  | $ | (70.1) |  |  | (16.8) | % |

[0001327567-25-000027:mdna:71]
Cost of product revenue increased for fiscal 2025 compared to fiscal 2024 primarily due to an increase in inventory excess and obsolete charges and an increased demand for our new generation hardware products and accessories, partially offset by a decreased demand for our prior generation of hardware products.

[0001327567-25-000027:mdna:72]
COST OF SUBSCRIPTION AND SUPPORT REVENUE

[0001327567-25-000027:mdna:73]
Cost of subscription and support revenue includes personnel costs for our global customer support and technical operations organizations, data center and cloud hosting service costs, third-party professional services costs, amortization of acquired intangible assets and capitalized software development costs, customer support and repair costs, and shared costs. We expect our cost of subscription and support revenue to increase as our installed end-customer base grows and adoption of our cloud-based subscription offerings increases.

[0001327567-25-000027:mdna:74]
|  | Year Ended July 31, |  |  |  | Year Ended July 31, |  |  |
|  | 2025 |  | 2024 |  | Change |  | 2024 |  | 2023 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Cost of subscription and support revenue | $ | 2,038.4 |  |  | $ | 1,711.0 |  |  | $ | 327.4 |  |  | 19.1 | % |  | $ | 1,711.0 |  |  | $ | 1,491.4 |  |  | $ | 219.6 |  |  | 14.7 | % |

[0001327567-25-000027:mdna:75]
- 48 -

[0001327567-25-000027:mdna:76]
Cost of subscription and support revenue increased for fiscal 2025 compared to fiscal 2024 primarily due to increased costs to support the growth of our subscription and support offerings. Cloud hosting service costs, which support our cloud-based subscription offerings, increased $189.5 million for fiscal 2025 compared to fiscal 2024. Personnel costs grew $52.9 million for fiscal 2025 compared to fiscal 2024, primarily due to headcount growth. The increase in cost of subscription and support revenue was further driven by increased professional services expense.

[0001327567-25-000027:mdna:77]
GROSS MARGIN

[0001327567-25-000027:mdna:78]
Gross margin has been and will continue to be affected by a variety of factors, including the introduction of new products, manufacturing costs, the average sales price of our products, cloud hosting service costs, personnel costs, the mix of products sold, and the mix of revenue between product and subscription and support offerings. Our higher-end firewall products generally have higher gross margins than our lower-end firewall products within each product series. We expect our gross margins to vary over time depending on the factors described above.

[0001327567-25-000027:mdna:79]
|  | Year Ended July 31, |
|  | 2025 |  | 2024 |  | 2023 |
|  | Amount |  | Gross Margin |  | Amount |  | Gross Margin |  | Amount |  | Gross Margin |
|  | (dollars in millions) |
| Product | $ | 1,388.7 |  |  | 77.1 | % |  | $ | 1,255.1 |  |  | 78.3 | % |  | $ | 1,160.1 |  |  | 73.5 | % |
| Subscription and support | 5,381.2 |  |  | 72.5 | % |  | 4,713.2 |  |  | 73.4 | % |  | 3,822.9 |  |  | 71.9 | % |
| Total gross profit | $ | 6,769.9 |  |  | 73.4 | % |  | $ | 5,968.3 |  |  | 74.3 | % |  | $ | 4,983.0 |  |  | 72.3 | % |

[0001327567-25-000027:mdna:80]
Product gross margin decreased for fiscal 2025 compared to fiscal 2024 primarily due to unfavorable hardware product mix and an increase in inventory excess and obsolete charges, partially offset by increased software revenue.

[0001327567-25-000027:mdna:81]
Subscription and support gross margin decreased for fiscal 2025 compared to fiscal 2024 primarily due to an increase in costs related to our cloud-based offerings, partially offset by increased leverage of our global customer service organization.

[0001327567-25-000027:mdna:82]
OPERATING EXPENSES

[0001327567-25-000027:mdna:83]
Our operating expenses consist of research and development, sales and marketing, and general and administrative expenses. Personnel costs are the most significant component of operating expenses and consist of salaries, benefits, bonuses, share-based compensation, travel and entertainment, and with regard to sales and marketing expense, sales commissions. Our operating expenses also include shared costs, which consist of certain facilities, depreciation, benefits, recruiting, and information technology costs that we allocate based on headcount to each department. We expect operating expenses generally to increase in absolute dollars and to decrease over the long term as a percentage of revenue as we continue to scale our business. As of July 31, 2025, we expect to recognize approximately $2.2 billion of share-based compensation expense over a weighted-average period of approximately 2.5 years, excluding additional share-based compensation expense related to any future grants of share-based awards. Share-based compensation expense is generally recognized on a straight-line basis over the requisite service periods of the awards.

[0001327567-25-000027:mdna:84]
RESEARCH AND DEVELOPMENT

[0001327567-25-000027:mdna:85]
Research and development expense consists primarily of personnel costs. Research and development expense also includes prototype-related expenses and shared costs. We expect research and development expense to increase in absolute dollars as we continue to invest in our future products and services, although our research and development expense may fluctuate as a percentage of total revenue.

[0001327567-25-000027:mdna:86]
|  | Year Ended July 31, |  |  |  | Year Ended July 31, |  |  |
|  | 2025 |  | 2024 |  | Change |  | 2024 |  | 2023 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Research and development | $ | 1,984.1 |  |  | $ | 1,809.4 |  |  | $ | 174.7 |  |  | 9.7 | % |  | $ | 1,809.4 |  |  | $ | 1,604.0 |  |  | $ | 205.4 |  |  | 12.8 | % |

[0001327567-25-000027:mdna:87]
Research and development expense increased for fiscal 2025 compared to fiscal 2024 primarily due to increased personnel costs, which grew $123.4 million for fiscal 2025 compared to fiscal 2024, largely due to headcount growth. The increase in research and development expense was further driven by increased shared costs.

[0001327567-25-000027:mdna:88]
- 49 -

[0001327567-25-000027:mdna:89]
SALES AND MARKETING

[0001327567-25-000027:mdna:90]
Sales and marketing expense consists primarily of personnel costs, including commission expense. Sales and marketing expense also includes costs for market development programs, promotional and other marketing costs, professional services, and shared costs. We continue to strategically invest in headcount and have grown our sales presence. We expect sales and marketing expense to continue to increase in absolute dollars as we increase the size of our sales and marketing organizations to grow our customer base, increase touch points with end-customers, and expand our global presence, although our sales and marketing expense may fluctuate as a percentage of total revenue.

[0001327567-25-000027:mdna:91]
|  | Year Ended July 31, |  |  |  | Year Ended July 31, |  |  |
|  | 2025 |  | 2024 |  | Change |  | 2024 |  | 2023 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Sales and marketing | $ | 3,100.2 |  |  | $ | 2,794.5 |  |  | $ | 305.7 |  |  | 10.9 | % |  | $ | 2,794.5 |  |  | $ | 2,544.0 |  |  | $ | 250.5 |  |  | 9.8 | % |

[0001327567-25-000027:mdna:92]
Sales and marketing expense increased for fiscal 2025 compared to fiscal 2024 primarily due to increased personnel costs, which grew $263.6 million for fiscal 2025 compared to fiscal 2024, largely due to headcount growth.

[0001327567-25-000027:mdna:93]
GENERAL AND ADMINISTRATIVE

[0001327567-25-000027:mdna:94]
General and administrative expense consists primarily of personnel costs and shared costs for our executive, finance, human resources, information technology, and legal organizations, and professional services costs, which consist primarily of legal, auditing, accounting, and other consulting costs. General and administrative expense also includes change in fair value of contingent consideration liability. We expect general and administrative expense to increase in absolute dollars over time as we increase the size of our general and administrative organizations and incur additional costs to support our business growth, although our general and administrative expense may fluctuate as a percentage of total revenue.

[0001327567-25-000027:mdna:95]
|  | Year Ended July 31, |  |  |  | Year Ended July 31, |  |  |
|  | 2025 |  | 2024 |  | Change |  | 2024 |  | 2023 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| General and administrative | $ | 442.7 |  |  | $ | 680.5 |  |  | $ | (237.8) |  |  | (34.9) | % |  | $ | 680.5 |  |  | $ | 447.7 |  |  | $ | 232.8 |  |  | 52.0 | % |

[0001327567-25-000027:mdna:96]
General and administrative expenses decreased for fiscal 2025 compared to fiscal 2024 primarily due to litigation-related charges of $204.4 million in fiscal 2024 and a partial release of litigation-related accrual of $38.8 million in fiscal 2025. We also recorded a gain of $135.3 million in fiscal 2025 for the change in fair value of the contingent consideration liability from our acquisition of certain IBM QRadar assets. The decrease in general and administrative expense was partially offset by increased personnel costs, which grew $153.2 million, largely due to increased share-based compensation.

[0001327567-25-000027:mdna:97]
INTEREST EXPENSE

[0001327567-25-000027:mdna:98]
Interest expense primarily consists of interest expense related to our 0.75% Convertible Senior Notes due 2023 (the “2023 Notes”) and our 0.375% Convertible Senior Notes due 2025 (the “2025 Notes,” and together with “2023 Notes,” the “Notes”).

[0001327567-25-000027:mdna:99]
|  | Year Ended July 31, |  |  |  | Year Ended July 31, |  |  |
|  | 2025 |  | 2024 |  | Change |  | 2024 |  | 2023 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Interest expense | $ | 3.0 |  |  | $ | 8.3 |  |  | $ | (5.3) |  |  | (63.9) | % |  | $ | 8.3 |  |  | $ | 27.2 |  |  | $ | (18.9) |  |  | (69.5) | % |

[0001327567-25-000027:mdna:100]
Interest expense decreased for fiscal 2025 compared to fiscal 2024 primarily due to conversions of the 2025 Notes prior to or upon maturity in June 2025. Refer to Note 11. Debt in Part II, Item 8 of this Annual Report on Form 10-K for more information on the Notes.

[0001327567-25-000027:mdna:101]
- 50 -

[0001327567-25-000027:mdna:102]
OTHER INCOME, NET

[0001327567-25-000027:mdna:103]
Other income, net includes interest income earned on our cash, cash equivalents, and investments, and gains and losses from foreign currency remeasurement and foreign currency transactions.

[0001327567-25-000027:mdna:104]
|  | Year Ended July 31, |  |  |  | Year Ended July 31, |  |  |
|  | 2025 |  | 2024 |  | Change |  | 2024 |  | 2023 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Other income, net | $ | 355.8 |  |  | $ | 312.7 |  |  | $ | 43.1 |  |  | 13.8 | % |  | $ | 312.7 |  |  | $ | 206.2 |  |  | $ | 106.5 |  |  | 51.6 | % |

[0001327567-25-000027:mdna:105]
Other income, net increased for fiscal 2025 compared to fiscal 2024 primarily due to higher interest income as a result of higher average cash, cash equivalents, and investments balance for fiscal 2025 compared to fiscal 2024. The increase was further driven by increased gains from our non-designated derivative instruments and investments, partially offset by increased foreign currency exchange losses for fiscal 2025 compared to fiscal 2024.

[0001327567-25-000027:mdna:106]
PROVISION FOR (BENEFIT FROM) INCOME TAXES

[0001327567-25-000027:mdna:107]
Provision for income taxes consists primarily of U.S. and foreign income taxes. We had a benefit from income taxes during fiscal 2024 primarily due to the release of our valuation allowance on U.S. federal, U.S. states other than California, and U.K. deferred tax assets. We continue to maintain a valuation allowance for California and certain deferred tax assets.

[0001327567-25-000027:mdna:108]
|  | Year Ended July 31, |  |  |  |  |  | Year Ended July 31, |  |  |  |  |
|  | 2025 |  | 2024 |  | Change |  | 2024 |  | 2023 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Provision for (benefit from) income taxes | $ | 461.8 |  |  | $ | (1,589.3) |  |  | $ | 2,051.1 |  |  | * |  | $ | (1,589.3) |  |  | $ | 126.6 |  |  | $ | (1,715.9) |  |  | * |
| Effective tax rate | 28.9 | % |  | (160.8) | % |  |  |  |  |  | (160.8) | % |  | 22.4 | % |  |  |  |  |

[0001327567-25-000027:mdna:109]
*    Not meaningful

[0001327567-25-000027:mdna:110]
Our provision for income taxes in fiscal 2025 was $461.8 million, a net change of $2.1 billion compared to a benefit from income taxes of $1.6 billion in fiscal 2024, primarily due to the release of our valuation allowance in fiscal 2024. This is also the primary driver of the change in our effective tax rate for fiscal 2025 compared to fiscal 2024.

[0001327567-25-000027:mdna:111]
During the year ended July 31, 2025, we recorded a deferred tax provision of $218.5 million arising from the remeasurement of our basis differences associated with the U.S. tax effects of foreign deferred tax assets. Our remeasurement is a result of the One Big Beautiful Bill Act ("OBBB") enacted on July 4, 2025 which provides for significant tax law changes and modifications including changes to the U.S. effective tax rates on certain foreign earnings. Refer to Note 16. Income Taxes in Part II, Item 8 of this Annual Report on Form 10-K for more information on OBBB.

[0001327567-25-000027:mdna:112]
- 51 -

[0001327567-25-000027:mdna:113]
Liquidity and Capital Resources

[0001327567-25-000027:mdna:114]
|  | July 31, |
|  | 2025 |  | 2024 |
|  | (in millions) |
| Working capital (deficit)(1) | $ | (465.2) |  |  | $ | (833.0) |  |
| Cash, cash equivalents, and investments: |  |  |  |
| Cash and cash equivalents | $ | 2,268.6 |  |  | $ | 1,535.2 |  |
| Investments | 6,190.2 |  |  | 5,216.8 |  |
| Total cash, cash equivalents, and investments | $ | 8,458.8 |  |  | $ | 6,752.0 |  |

[0001327567-25-000027:mdna:115]
(1)Current liabilities included net carrying amounts of convertible senior notes of $1.0 billion as of July 31, 2024. Refer to Note 11. Debt in Part II, Item 8 of this Annual Report on Form 10-K for information on the Notes.

[0001327567-25-000027:mdna:116]
As of July 31, 2025, our total cash, cash equivalents, and investments of $8.5 billion were held for general corporate purposes. As of July 31, 2025, we had no unremitted earnings when evaluating our outside basis difference relating to our U.S. investment in foreign subsidiaries. However, there could be local withholding taxes due to various foreign countries if certain lower tier earnings are distributed. Withholding taxes that would be payable upon remittance of these lower tier earnings are not material.

[0001327567-25-000027:mdna:117]
DEBT

[0001327567-25-000027:mdna:118]
In June 2020, we issued the 2025 Notes with an aggregate principal amount of $2.0 billion. The 2025 Notes were converted prior to or settled on the maturity date of June 1, 2025. During fiscal 2025, we repaid in cash $965.6 million in aggregate principal amount of the 2025 Notes and issued 14.0 million shares of common stock to the holders for the conversion value in excess of the principal amount of the 2025 Notes converted, which were fully offset by shares we received from our exercise of the associated note hedges.

[0001327567-25-000027:mdna:119]
In April 2023, we entered into a credit agreement (the “Credit Agreement”) that provides for a $400.0 million unsecured revolving credit facility (the “Credit Facility”), with an option to increase the amount of the Credit Facility by up to an additional $350.0 million, subject to certain conditions. The interest rates and commitment fees are also subject to upward and downward adjustments based on our progress towards the achievement of certain sustainability goals. As of July 31, 2025, there were no amounts outstanding, and we were in compliance with all covenants under the Credit Agreement. Refer to Note 11. Debt in Part II, Item 8 of this Annual Report on Form 10-K for more information on the Credit Agreement.

[0001327567-25-000027:mdna:120]
CAPITAL RETURN

[0001327567-25-000027:mdna:121]
In February 2019, our board of directors authorized a $1.0 billion share repurchase program. Our board of directors subsequently authorized additional increases to this share repurchase program, bringing the total authorization to $4.1 billion. Repurchases will be funded from available working capital and may be made at management’s discretion from time to time. As of July 31, 2025, $1.0 billion remained available for future share repurchases under this repurchase program. The repurchase authorization will expire on December 31, 2025, and may be suspended or discontinued at any time without prior notice. Refer to Note 14. Stockholders’ Equity in Part II, Item 8 of this Annual Report on Form 10-K for more information on this repurchase program.

[0001327567-25-000027:mdna:122]
CONTRACTUAL OBLIGATIONS AND OTHER MATERIAL CASH REQUIREMENTS

[0001327567-25-000027:mdna:123]
We have entered into various non-cancelable operating leases, primarily for our offices and data centers, with lease terms expiring through fiscal 2036. As of July 31, 2025, we have total operating lease obligations of $417.4 million recorded on our consolidated balance sheet.

[0001327567-25-000027:mdna:124]
As of July 31, 2025, our commitments to purchase products, components, cloud hosting and other services totaled $7.1 billion. Refer to Note 13. Commitments and Contingencies in Part II, Item 8 of this Annual Report on Form 10-K for more information on these commitments.

[0001327567-25-000027:mdna:125]
Our acquisition of certain IBM QRadar assets on August 31, 2024 included contingent consideration that requires potential future payments through the fiscal quarter ending October 2028. As of July 31, 2025, we have total contingent consideration obligation of $513.6 million recorded on our consolidated balance sheet. Refer to Note 3. Fair Value Measurements and Note 8. Acquisitions in Part II, Item 8 of this Annual Report on Form 10-K for more information on our contingent consideration obligation.

[0001327567-25-000027:mdna:126]
- 52 -

[0001327567-25-000027:mdna:127]
On July 30, 2025, we entered into a definitive agreement to acquire CyberArk. The acquisition is expected to close during the second half of our fiscal 2026, subject to the satisfaction of customary closing conditions. Under the terms of the definitive agreement, CyberArk shareholders will receive $45.00 in cash and 2.2005 shares of our common stock for each CyberArk share. This represents an equity value for CyberArk of approximately $25 billion based on the unaffected 10-day average daily volume-weighted average trading prices of our common stock as of July 25, 2025. We expect to fund the cash portion of the consideration with our cash on hand. Refer to Part I, Item 1A “Risk Factors” in this Form 10-K and Note 8. Acquisitions in Part II, Item 8 of this Annual Report on Form 10-K for more information on the acquisition.

[0001327567-25-000027:mdna:128]
CASH FLOWS

[0001327567-25-000027:mdna:129]
The following table summarizes our cash flows for the years ended July 31, 2025, 2024, and 2023:

[0001327567-25-000027:mdna:130]
|  | Year Ended July 31, |
| 2025 |  | 2024 |  | 2023 |
|  | (in millions) |
| Net cash provided by operating activities | $ | 3,716.0 |  |  | $ | 3,257.6 |  |  | $ | 2,777.5 |  |
| Net cash used in investing activities | (2,204.7) |  |  | (1,509.9) |  |  | (2,033.8) |  |
| Net cash used in financing activities | (778.9) |  |  | (1,343.1) |  |  | (1,726.3) |  |
| Net increase (decrease) in cash, cash equivalents, and restricted cash | $ | 732.4 |  |  | $ | 404.6 |  |  | $ | (982.6) |  |

[0001327567-25-000027:mdna:131]
Cash from operations could be affected by various risks and uncertainties detailed in Part I, Item 1A “Risk Factors” in this Form 10-K. We believe that our cash flow from operations with existing cash and cash equivalents will be sufficient to meet our anticipated cash needs for at least the next 12 months and thereafter for the foreseeable future. Our future capital requirements will depend on many factors including our growth rate, the timing and extent of spending to support development efforts, the expansion of sales and marketing activities, the introduction of new and enhanced products and subscription and support offerings, the costs to acquire or invest in complementary businesses and technologies, the costs to ensure access to adequate manufacturing capacity, the investments in our infrastructure to support the adoption of our cloud-based subscription offerings, the continuing market acceptance of our products and subscription and support offerings and macroeconomic events. In addition, from time to time, we may incur additional tax liability in connection with certain corporate structuring decisions.

[0001327567-25-000027:mdna:132]
We may also choose to seek additional equity or debt financing. In the event that additional financing is required from outside sources, we may not be able to raise it on terms acceptable to us or at all. If we are unable to raise additional capital when desired, our business, operating results, and financial condition may be adversely affected.

[0001327567-25-000027:mdna:133]
OPERATING ACTIVITIES

[0001327567-25-000027:mdna:134]
Our operating activities have consisted of net income adjusted for certain non-cash items and changes in assets and liabilities. Our largest source of cash provided by our operations is receipts from our customers. Net cash provided by operating activities can be impacted by factors such as timing of payments and collections, vendor payment terms, and timing and amount of tax payments.

[0001327567-25-000027:mdna:135]
Cash provided by operating activities during fiscal 2025 was $3.7 billion, an increase of $458.4 million compared to fiscal 2024. The increase was primarily due to growth of our business as reflected by increases in collections during fiscal 2025, partially offset by higher cash expenditure to support our business growth.

[0001327567-25-000027:mdna:136]
INVESTING ACTIVITIES

[0001327567-25-000027:mdna:137]
Our investing activities have consisted of capital expenditures, net investment purchases, sales, and maturities, and business acquisitions. We expect to continue such activities as our business grows.

[0001327567-25-000027:mdna:138]
Cash used in investing activities during fiscal 2025 was $2.2 billion, an increase of $694.8 million compared to fiscal 2024. The increase was primarily due to an increase in net cash payments for business acquisitions and higher purchases of investments during fiscal 2025.

[0001327567-25-000027:mdna:139]
FINANCING ACTIVITIES

[0001327567-25-000027:mdna:140]
Our financing activities have consisted of repayments of our convertible senior notes, cash used to repurchase shares of our common stock, proceeds from sales of shares through employee equity incentive plans, and payments for tax withholding obligations of certain employees related to the net share settlement of equity awards.

[0001327567-25-000027:mdna:141]
Cash used in financing activities during fiscal 2025 was $778.9 million, a decrease of $564.2 million compared to fiscal 2024. The decrease was primarily due to a decrease in cash used to repurchase our common stock which did not recur during fiscal 2025.

[0001327567-25-000027:mdna:142]
- 53 -

[0001327567-25-000027:mdna:143]
Critical Accounting Estimates

[0001327567-25-000027:mdna:144]
Our consolidated financial statements have been prepared in accordance with U.S. GAAP. The preparation of these consolidated financial statements requires us to make estimates and assumptions that affect the reported amounts of assets, liabilities, revenue, expenses, and related disclosures. We base our estimates on historical experience and on various other assumptions that we believe are reasonable under the circumstances. We evaluate our estimates and assumptions on an ongoing basis. Actual results could differ materially from those estimates due to risks and uncertainties, including uncertainty in the current economic environment. To the extent that there are material differences between these estimates and our actual results, our future consolidated financial statements will be affected.

[0001327567-25-000027:mdna:145]
We believe that of our significant accounting policies described in Note 1. Description of Business and Summary of Significant Accounting Policies in Part II, Item 8 of this Annual Report on Form 10-K, the critical accounting estimates, assumptions, and judgments that have the most significant impact on our consolidated financial statements are described below.

[0001327567-25-000027:mdna:146]
REVENUE RECOGNITION

[0001327567-25-000027:mdna:147]
The majority of our contracts with our customers include various combinations of our products and subscriptions and support. Our hardware products and software licenses are distinct from our subscriptions and support services as the customer can benefit from the product without these services and such services are separately identifiable within the contract. We account for multiple agreements with a single customer as a single contract if the contractual terms and/or substance of those agreements indicate that they may be so closely related that they are, in effect, parts of a single contract. The amount of consideration we expect to receive in exchange for delivering on the contract is allocated to each performance obligation based on its relative standalone selling price.

[0001327567-25-000027:mdna:148]
When estimating standalone selling price, we first consider the prices charged for a deliverable when sold separately. If the standalone selling price is not observable through past transactions, we estimate it based on our pricing model and our go-to-market strategy, which include factors such as type of sales channel (channel partner or end-customer), the geographies in which our offerings were sold (domestic or international), and offering type (products, subscriptions, or support). As our business offerings evolve over time, we may be required to modify our estimated standalone selling prices, and as a result the timing and classification of our revenue could be affected.

[0001327567-25-000027:mdna:149]
INCOME TAXES

[0001327567-25-000027:mdna:150]
We account for income taxes using the asset and liability method, which requires the recognition of deferred tax assets and liabilities for the expected future tax consequences of events that have been recognized in our consolidated financial statements or tax returns. In addition, deferred tax assets are recorded for all future benefits including, but not limited to, net operating losses, research and development credit carryforwards, and basis differences relating to our global intangible low-taxed income. Valuation allowances are provided when necessary to reduce deferred tax assets to the amount more likely than not to be realized.

[0001327567-25-000027:mdna:151]
Significant judgment is required in determining any valuation allowance recorded against deferred tax assets. In assessing the need for a valuation allowance, we consider all available evidence, including past operating results, estimates of future taxable income, and the feasibility of tax planning strategies. In the event that we change our determination as to the amount of deferred tax assets that can be realized, we will adjust our valuation allowance with a corresponding impact to the provision for income taxes in the period in which such determination is made.

[0001327567-25-000027:mdna:152]
We recognize liabilities for uncertain tax positions based on a two-step process which includes evaluating if a tax position is more likely than not to be sustained on audit and then measuring the tax benefit as the largest amount that is more likely than not to be realized upon ultimate settlement. Assumptions, judgment, and the use of estimates are required in determining if the more-likely-than-not standard has been met and in determining the expected benefit when developing the provision for income taxes. Our evaluations are based upon a number of factors, including changes in facts or circumstances, changes in tax law or guidance, correspondence with tax authorities during the course of audits, and effective settlement of audit issues. Changes in these or other factors could result in material increases or decreases in our provision for (benefit from) income taxes in the period in which we make the change.

[0001327567-25-000027:mdna:153]
LOSS CONTINGENCIES

[0001327567-25-000027:mdna:154]
We are subject to the possibility of various loss contingencies arising in the ordinary course of business. We accrue for loss contingencies when it is probable that an asset has been impaired or a liability has been incurred and the amount of loss can be reasonably estimated. If we determine that a loss is reasonably possible, then we disclose the possible loss or range of the possible loss or state that such an estimate cannot be made. We regularly evaluate current information available to us to determine whether an accrual is required, an accrual should be adjusted, or a range of possible loss should be disclosed.

[0001327567-25-000027:mdna:155]
- 54 -

[0001327567-25-000027:mdna:156]
From time to time, we are involved in disputes, litigation, and other legal actions. However, there are many uncertainties associated with any litigation, and these actions or other third-party claims against us may cause us to incur substantial settlement charges, which are inherently difficult to estimate and could adversely affect our results of operations. The actual liability in any such matters may be materially different from our estimates, which could result in the need to adjust our liability and record additional expenses. Refer to the “Litigation” subheading in Note 13. Commitments and Contingencies in Part II, Item 8 of this Annual Report on Form 10-K for more information regarding our litigation.

[0001327567-25-000027:mdna:157]
BUSINESS COMBINATIONS

[0001327567-25-000027:mdna:158]
We make significant estimates, assumptions, and judgments when valuing assets acquired and liabilities assumed, especially with respect to purchased intangible assets, in connection with the initial purchase price allocation of an acquired business. Critical estimates in valuing certain purchased intangible assets include, but are not limited to, cash flows that an asset is expected to generate in the future, discount rates, the time and expense that would be necessary to recreate the assets, and the profit margin a market participant would receive on such recreated assets. The amounts and useful lives assigned to identified intangible assets impact the amount and timing of future amortization expense.

[0001327567-25-000027:mdna:159]
One of our business combinations has included post-closing payments contingent upon the occurrence of future events and/or certain conditions being met. Critical estimates used in valuing our contingent consideration obligation include, but are not limited to, estimated future cash payments related to customers entering into qualified new transactions and risk-adjusted discount rates used to present value the expected cash flows. These estimates and assumptions are updated to revalue our contingent consideration liability at the end of each reporting period. Accordingly, subsequent changes in underlying facts and circumstances could result in changes in these estimates and assumptions, which could have a material impact on the estimated future fair values of these obligations.

[0001327567-25-000027:mdna:160]
Recent Accounting Pronouncements

[0001327567-25-000027:mdna:161]
Refer to “Recently Adopted Accounting Pronouncement” and “Recently Issued Accounting Pronouncements” in Note 1. Description of Business and Summary of Significant Accounting Policies in Part II, Item 8 of this Annual Report on Form 10-K for a description of recent accounting pronouncements and our expectation of their impact, if any, on our results of operations and financial condition.

[0001327567-25-000027:mdna:162]
- 55 -
