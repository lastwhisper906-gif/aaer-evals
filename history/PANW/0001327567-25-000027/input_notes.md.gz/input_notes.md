# PANW notes — 0001327567-25-000027


## dei:DocumentsIncorporatedByReferenceTextBlock

[0001327567-25-000027:notes:1]
Portions of the information called for by Part III of this Annual Report on Form 10-K is hereby incorporated by reference from the definitive proxy statement for the registrant’s 2025 annual meeting of stockholders, which will be filed with the Securities and Exchange Commission not later than 120 days after the registrant’s fiscal year ended July 31, 2025.


## cyd:CybersecurityRiskManagementProcessesForAssessingIdentifyingAndManagingThreatsTextBlock

[0001327567-25-000027:notes:2]
Our cybersecurity risk management program includes written policies, standards, and procedures for maintaining data privacy, product security and information security to mitigate cybersecurity risks, and to identify, evaluate and respond to cybersecurity threats, vulnerabilities and incidents. Our cybersecurity risk management program and strategy is implemented across several areas, which include, but are not limited to, the following:

[0001327567-25-000027:notes:3]
•Information Security. We maintain a written information security program, which provides for policies, standards, guidelines, and administrative, technical and physical safeguards that we believe are reasonably designed, in light of the nature, size and complexity of our operations, to protect the resiliency of our operations and the confidentiality, integrity, and availability of our information systems, data, and information assets. The organizational, administrative and technical measures we implement are based on recognized security frameworks established by the National Institute of Standards and Technology, security measures aligned with the ISO/IEC 27000 series of standards, and other generally recognized industry standards. The program is assessed regularly and in light of new and emerging cybersecurity risks.

[0001327567-25-000027:notes:4]
•Technical Safeguards and Product Security. We deploy and maintain a variety of technologies to prevent and detect cybersecurity threats across the network, endpoint and cloud. We also apply security-by-design principles in our software development lifecycle, track vulnerabilities of open-source software, and run internal and external network scans at least weekly and after any meaningful change in our network configuration. We conduct regular application security assessments, including our assessments for internet-facing applications that collect, transmit, or display end user data. We also employ tooling in certain areas to help prevent deviations from policy.

[0001327567-25-000027:notes:5]
•Incident Response and Reporting. We maintain incident response and recovery protocols to enable prompt, effective and orderly identification, evaluation, management, and disposition of actual and potential security threats and incidents, including for purposes of escalation and internal and external-notification steps. We maintain a cross-functional incident response team, including senior representatives from information security, information technology, product, legal, privacy, communications, and finance, that is involved in assessing cybersecurity threats and incidents, assigning severity levels, and evaluating the potential impact, including the potential impact on our business strategy, results of operations and financial condition. This allows for prompt direction of appropriate personnel and resources for incident management and response, and internal notification to appropriate members of management, which may include our chief executive officer, chief product and technology officer, vice president acting as chief information security officer, general counsel, chief financial officer, and/or chief accounting officer, and the security committee of our board of directors (the “Security Committee”). The protocols also establish steps designed to publicly report and/or alert external stakeholders as and when required by applicable law or otherwise determined appropriate.

[0001327567-25-000027:notes:6]
•Third-Party Risk Management. We maintain a risk-based approach to identifying and overseeing cybersecurity risks presented by certain third parties, including vendors, service providers, suppliers, operations parties, and other external users of our systems, as well as the systems of third parties that could adversely impact our business in the event of a cybersecurity incident affecting those third-party systems. This includes a security process to conduct due diligence prior to engaging contractors and vendors and assess the security capabilities of subcontractors and vendors on a periodic basis.

[0001327567-25-000027:notes:7]
•Risk and Readiness Assessments. We engage in at least quarterly assessments and testing of the effectiveness of our cybersecurity risk management program and incident response protocols that are designed to identify and evaluate vulnerabilities and weaknesses, address cybersecurity threats and test our readiness to respond to cybersecurity incidents. These efforts include, but are not limited to, threat modeling, vulnerability scans, penetration testing, audits, and tabletop exercises. We regularly engage third parties to perform assessments on our cybersecurity measures, such as audits and independent reviews of our compliance with various security compliance standards, including those established by the American Institute of Certified Public Accountants, operating effectiveness and penetration tests. The results of such assessments are reported to management and we adjust our cybersecurity policies, standards, processes and practices as necessary based on the information provided by these assessments, audits and reviews.

[0001327567-25-000027:notes:8]
•Awareness and Training. We provide regular training for educating employees about corporate policies and procedures and information security designed to provide our employees with knowledge of best practices and effective tools for safeguarding our data and assets and reducing security risks based on the human threat vector. Our information security compliance training, data protection training, and code of conduct training is mandatory for all employees.

[0001327567-25-000027:notes:9]
•Governance. As discussed in more detail below under the heading, “Cybersecurity Governance,” our board of directors’ has delegated oversight of enterprise security risk management, including, but not limited to, cybersecurity risk management to the Security Committee. As part of our cybersecurity risk management procedures, senior members of management and the Security Committee are informed regarding security events based on established reporting thresholds, and are provided ongoing updates regarding any such meaningful threat or incident.
We have not identified any risks from cybersecurity threats, including as a result of any previous cybersecurity incidents, that have materially impacted or are reasonably likely to materially impact us, including our business strategy, results of operations, or financial condition, to date. However, we face ongoing and increasing cybersecurity risks, including from threat actors that are becoming more sophisticated and effective over time, and we can provide no assurance that there will not be incidents in the future or that past or future threats or incidents will not materially affect us, including our business strategy, results of operations, or financial conditions. For additional information regarding these risks, please refer to Part I, Item 1A, “Risk Factors,” in this Form 10-K, including, but not limited to, the risk factor entitled “A network or data security incident may allow unauthorized access to our network or data, harm our reputation, create additional liability, and adversely impact our financial results.”


## cyd:CybersecurityRiskBoardOfDirectorsOversightTextBlock

[0001327567-25-000027:notes:10]
The Security Committee, which is composed of our independent directors and chaired by our chief product and technology officer, facilitates our board of directors’ responsibility for oversight of security matters, including product security, data security, cybersecurity, security risk management, risk exposure and related controls and enterprise risk management related to these risks. The Security Committee reports regularly to the Board following meetings of the Security Committee with respect to its review and assessment of security matters and other matters that are relevant to the Security Committee’s discharge of its responsibilities. The Security Committee meets quarterly to review with our vice president acting as chief information security officer and other members of management, which may include our chief executive officer, chief product and technology officer, chief financial officer, and general counsel, our cybersecurity programs, cybersecurity risks, mitigation or remediation strategies, and other matters impacting the committee’s responsibilities.

[0001327567-25-000027:notes:11]
Management is responsible for day-to-day risk management activities, including identifying, assessing and managing our exposure to cybersecurity risks, establishing processes and procedures to ensure that potential cybersecurity risk exposures are monitored, implementing appropriate mitigation or remediation measures as needed, and maintaining cybersecurity risk management programs. Our vice president acting as chief information security officer is responsible for defining, overseeing, managing, implementing, and reviewing compliance with the information security programs described above under the heading “Cybersecurity Risk Management and Strategy.” This vice president receives regular reports from our information security team and monitors the prevention, detection, and mitigation or remediation of cybersecurity risks. In addition, as described in further detail above under the heading “Cybersecurity Risk Management and Strategy,” a cross functional team is involved in assessing and managing the risks from cybersecurity threats and incidents, and reporting information about risks to the Security Committee.

[0001327567-25-000027:notes:12]
Our information security team consists of dedicated personnel who are experienced information systems security professionals and information security managers with many years of experience across a variety of technology sub-specialties. In particular, our vice president acting as chief information security officer has extensive experience in the management of cybersecurity risk management programs, having served in various roles in information technology and security for over 25 years. In addition, six of the eleven members of our board of directors have expertise in overseeing cybersecurity and information security management.


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock

[0001327567-25-000027:notes:13]
Description of Business and Summary of Significant Accounting Policies
Description of Business

[0001327567-25-000027:notes:14]
Palo Alto Networks, Inc. (the “Company,” “we,” “us,” or “our”), headquartered in Santa Clara, California, was incorporated in March 2005 under the laws of the State of Delaware and commenced operations in April 2005. Our cybersecurity platforms and services help enterprises, organizations, service providers, and government entities to secure their users, networks, clouds, and endpoints by delivering comprehensive cybersecurity backed by artificial intelligence and automation.

[0001327567-25-000027:notes:15]
Basis of Presentation

[0001327567-25-000027:notes:16]
The accompanying consolidated financial statements have been prepared in conformity with U.S. generally accepted accounting principles (“U.S. GAAP”). The consolidated financial statements include all adjustments necessary for a fair presentation of our annual results. All adjustments are of a normal recurring nature.

[0001327567-25-000027:notes:17]
Principles of Consolidation

[0001327567-25-000027:notes:18]
The consolidated financial statements include our accounts and our wholly owned subsidiaries. All significant intercompany balances and transactions have been eliminated in consolidation.

[0001327567-25-000027:notes:19]
Use of Estimates

[0001327567-25-000027:notes:20]
The preparation of consolidated financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the amounts reported and disclosed in the consolidated financial statements and the accompanying notes. We evaluate our estimates on an ongoing basis. Management estimates include, but are not limited to, the standalone selling price for our products and services, share-based compensation, fair value of assets acquired and liabilities assumed in business combinations, fair value of our contingent consideration liability, the assessment of recoverability of our intangibles and goodwill, valuation allowance against deferred tax assets, valuation of inventory and manufacturing partner and supplier liabilities, deferred contract costs benefit period, and loss contingencies. We base our estimates on assumptions, both historical and forward looking, that we believe are reasonable. Actual results could differ materially from those estimates due to risks and uncertainties.

[0001327567-25-000027:notes:21]
Stock Split

[0001327567-25-000027:notes:22]
On December 12, 2024, we effected a two-for-one stock split of our outstanding shares of common stock through an amendment to our restated certificate of incorporation (“Stock Split”), which also effected a proportionate increase in the number of authorized shares of our common stock from 1.0 billion to 2.0 billion. The par value per share of our common stock remains unchanged at $0.0001 per share after the Stock Split. All references made to share or per share amounts related to our common stock have been retroactively adjusted on the accompanying consolidated financial statements and applicable disclosures to reflect the effects of the Stock Split.

[0001327567-25-000027:notes:23]
Concentrations of Risks

[0001327567-25-000027:notes:24]
Financial instruments that subject us to concentrations of credit risk consist primarily of cash and cash equivalents, investments, derivative contracts, accounts receivable and financing receivables.

[0001327567-25-000027:notes:25]
We invest only in high-quality credit instruments and our cash and cash equivalents and available-for-sale investments consist primarily of fixed income securities held at large, diverse financial institutions to reduce the credit risk exposure to any single financial institution. Deposits held with banks may exceed the amount of insurance provided on such deposits.

[0001327567-25-000027:notes:26]
Our derivative contracts expose us to credit risk to the extent that the counterparties are unable to meet the terms of the arrangement. We mitigate credit risk by transacting with multiple major financial institutions with high credit ratings and also enter into master netting arrangements, which permit net settlement of transactions with the same counterparty. We are not required to pledge, and are not entitled to receive, cash collateral related to these derivative instruments. We do not enter into derivative contracts for trading or speculative purposes.

[0001327567-25-000027:notes:27]
Our accounts receivable are primarily derived from our distributors in various geographical locations. Our financing receivables are with qualified end-customers and channel partners. We perform ongoing credit evaluations and generally do not require collateral on accounts receivable or financing receivables.

[0001327567-25-000027:notes:28]
As of July 31, 2025, three distributors individually represented 10% or more of our gross accounts receivable, and in the aggregate represented 44.8% of our gross accounts receivable. As of July 31, 2025, no end-customers or channel partners represented 10% or more of our gross financing receivables.

[0001327567-25-000027:notes:29]
For fiscal 2025, three distributors represented 10% or more of our total revenue, representing 18.8%, 14.4%, and 11.0% respectively. No single end-customer accounted for more than 10% of our total revenue in fiscal 2025, 2024, or 2023.

[0001327567-25-000027:notes:30]
We rely on an electronics manufacturing services provider (“EMS provider”) to assemble most of our products and sole source component suppliers for certain components.

[0001327567-25-000027:notes:31]
Comprehensive Income

[0001327567-25-000027:notes:32]
Comprehensive income is comprised of net income and other comprehensive income. Our other comprehensive income includes unrealized gains and losses on available-for-sale investments and unrealized gains and losses on cash flow hedges, net of tax effects.

[0001327567-25-000027:notes:33]
Foreign Currency Transactions

[0001327567-25-000027:notes:34]
The functional currency of our foreign subsidiaries is the U.S. dollar. Monetary assets and liabilities denominated in foreign currencies have been remeasured into U.S. dollars using the exchange rates in effect at the balance sheet dates. Foreign currency remeasurement gains and losses and foreign currency transaction gains and losses are not significant to the consolidated financial statements.

[0001327567-25-000027:notes:35]
Fair Value

[0001327567-25-000027:notes:36]
We define fair value as the price that would be received from selling an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date. When determining the fair value measurements for assets and liabilities which are required to be recorded at fair value, we consider the principal or most advantageous market in which to transact and the market-based risk.

[0001327567-25-000027:notes:37]
We categorize assets and liabilities recorded or disclosed at fair value on our consolidated balance sheets based upon the level of judgment associated with inputs used to measure their fair value. The categories are as follows:

[0001327567-25-000027:notes:38]
•Level 1—Inputs are unadjusted quoted prices in active markets for identical assets or liabilities.

[0001327567-25-000027:notes:39]
•Level 2—Inputs are quoted prices for similar assets and liabilities in active markets or inputs that are observable for the assets or liabilities, either directly or indirectly through market corroboration, for substantially the full term of the financial instruments.

[0001327567-25-000027:notes:40]
•Level 3—Inputs are unobservable inputs based on our own assumptions used to measure assets and liabilities at fair value. The inputs require significant management judgment or estimation.

[0001327567-25-000027:notes:41]
Our financial assets and liabilities that are measured at fair value on a recurring basis include marketable securities, derivative financial instruments, and contingent consideration liability. Goodwill, intangible assets, and other long-lived assets are measured at fair value on a nonrecurring basis, only if impairment is indicated. Certain certificates of deposit, time deposits, and overnight sweep accounts recorded in cash and cash equivalents and short-term investments are stated at their carrying amounts, which approximate fair value due to their short maturities. The carrying amounts of accounts receivable, accounts payable, and accrued liabilities approximate fair value due to their short-term nature.

[0001327567-25-000027:notes:42]
Cash, Cash Equivalents, and Investments

[0001327567-25-000027:notes:43]
We consider all highly liquid investments with original maturities of three months or less at the date of purchase to be cash equivalents. Investments not considered cash equivalents and with maturities of one year or less from the consolidated balance sheet date are classified as short-term investments. Investments with maturities greater than one year from the consolidated balance sheet date are classified as long-term investments.

[0001327567-25-000027:notes:44]
We determine the classification of our investments in marketable debt securities at the time of purchase and reevaluate such determination at each balance sheet date. Our marketable debt securities are classified as available-for-sale. Debt securities in an unrealized loss position are written down to its fair value with the corresponding charge recorded in other income, net on our consolidated statements of operations, if it is more likely than not that we will be required to sell the impaired security before recovery of its amortized cost basis, or we have the intention to sell the security. If neither of these conditions are met, we determine whether a credit loss exists by comparing the present value of the expected cash flows of the security with its amortized cost basis. An allowance for credit losses is recorded in other income, net on our consolidated statements of operations for an amount not to exceed the unrealized loss. Unrealized losses that are not credit-related are included in accumulated other comprehensive income (loss) (“AOCI”) in stockholders’ equity.

[0001327567-25-000027:notes:45]
Accounts Receivable

[0001327567-25-000027:notes:46]
Trade accounts receivable are recorded at the invoiced amount, net of allowances for credit losses. The allowance for credit losses is based on our assessment of collectability. Management regularly reviews the adequacy of the allowance for credit losses on a collective basis by considering the age of each outstanding invoice, each customer’s expected ability to pay and collection history, current market conditions, and, where appropriate, reasonable and supportable forecasts of future economic conditions. Accounts receivable deemed uncollectible are charged against the allowance for credit losses. For the years ended July 31, 2025, 2024 and 2023, the allowance for credit losses activity was not significant.

[0001327567-25-000027:notes:47]
Financing Receivables

[0001327567-25-000027:notes:48]
We provide financing arrangements for certain qualified end-customers and channel partners to purchase our products and services. Payment terms on these financing arrangements are generally two to five years. Financing receivables are recorded at amortized cost, which approximates fair value. As part of our financing credit risk management policy, we may sell financing receivables with an internal risk rating of 5 or greater on a non-recourse basis to third-party financial institutions when the outstanding balance of our financing receivables exceeds preestablished thresholds. The financing receivables are derecognized upon sale as these transactions qualify as true sales. We classify the proceeds from these sales as cash flows from operating activities on our consolidated statements of cash flows.

[0001327567-25-000027:notes:49]
We evaluate the allowance for credit losses by assessing the risks and losses inherent in our financing receivables on either an individual or a collective basis. Our assessment considers various factors, including lifetime expected losses determined using customer risk profile, current economic conditions that may affect a customer’s ability to pay, and forward-looking economic considerations. Financing receivables deemed uncollectible are charged against the allowance for credit losses.

[0001327567-25-000027:notes:50]
Derivatives

[0001327567-25-000027:notes:51]
We are exposed to foreign currency exchange risk, which we manage through the use of derivative financial instruments. Our derivative financial instruments are recorded at fair value, on a gross basis, as either assets or liabilities on our consolidated balance sheets.

[0001327567-25-000027:notes:52]
Our sales contracts are primarily denominated in U.S. dollars. A portion of our operating expenditures are denominated in foreign currencies, making them subject to fluctuations in foreign currency exchange rates. We enter into foreign currency derivative contracts with maturities of 24 months or less, which we designate as cash flow hedges, to manage the foreign currency exchange risk associated with our revenue and operating expenditures. Gains and losses related to the effective portion of our cash flow hedges are recorded as a component of AOCI on our consolidated balance sheets and are reclassified into the financial statement line item associated with the underlying hedged transaction on our consolidated statements of operations when the underlying hedged transaction is recognized in earnings. In the event the underlying hedged transaction does not occur, or it becomes probable that it will not occur within the defined hedge period, the gains or losses on the related cash flow hedges are recognized in other income, net on our consolidated statements of operations. Cash flows from foreign currency derivative contracts designated as cash flow hedges are classified on our consolidated statements of cash flows in the same manner as the underlying hedged transaction, primarily within cash flows from operating activities.

[0001327567-25-000027:notes:53]
We also enter into foreign currency derivative contracts to hedge a portion of our outstanding monetary assets and liabilities denominated in foreign currencies. These derivatives are not designated as hedging instruments for accounting purposes, and the related gains and losses are recorded in other income, net on our consolidated statements of operations.

[0001327567-25-000027:notes:54]
Inventory and Manufacturing Partner and Supplier Liabilities

[0001327567-25-000027:notes:55]
Inventory consists primarily of raw materials and service-related spares, and is stated at the lower of average cost and net realizable value. Inventory is included in prepaid expenses and other current assets on our consolidated balance sheets. Inventory that is obsolete or in excess of forecasted demand is written down to its estimated realizable value. Once inventory has been written down, a new, lower-cost basis for that inventory is established.

[0001327567-25-000027:notes:56]
We outsource most of our manufacturing, repair, and supply chain management operations to our EMS provider and payments to it are a significant portion of our cost of product revenue. Although we are contractually obligated to purchase manufactured products and components, we generally do not own the components and manufactured products. Product title transfers from our EMS provider to us and immediately to our customers upon shipment. We record a liability for manufacturing purchase commitments in excess of our forecasted demand.

[0001327567-25-000027:notes:57]
We use consistent demand forecasts for our valuation of excess and obsolete inventory and manufacturing partner and supplier liabilities. These forecasts are based upon historical trends and analysis, adjusted for overall market conditions. Inventory write-downs and excess manufacturing purchase commitment charges are included in cost of product revenue on our consolidated statements of operations.

[0001327567-25-000027:notes:58]
Property and Equipment

[0001327567-25-000027:notes:59]
Property and equipment are stated at cost, less accumulated depreciation. Depreciation is computed using the straight-line method over the estimated useful lives of the assets. Land is not depreciated. The estimated useful lives of our depreciable assets are as follows:

[0001327567-25-000027:notes:60]
| Asset category |  | Useful life |
| Computers, equipment, and software |  | 3 years - 5 years |
| Demonstration units |  | 4 years |
| Furniture and fixtures |  | 5 years |
| Leasehold improvements |  | Lesser of 10 years or remaining lease term |

[0001327567-25-000027:notes:61]
Business Combinations

[0001327567-25-000027:notes:62]
We include the results of operations of the businesses that we acquire as of the respective dates of acquisition. We allocate the fair value of the purchase price of our acquisitions to the assets acquired and liabilities assumed, including contingent consideration, generally based on their estimated fair values. The excess of the purchase price over the fair values of these identifiable assets and liabilities is recorded as goodwill. Additional information existing as of the acquisition date but unknown to us may become known during the remainder of the measurement period, not to exceed 12 months from the acquisition date, which may result in changes to the amounts and allocations recorded.

[0001327567-25-000027:notes:63]
Contingent consideration obligation incurred in connection with a business combination is recorded at fair value on the acquisition date and remeasured at each subsequent reporting period until the related contingencies have been resolved, with the change in fair value recognized in general and administrative expense on our consolidated statements of operations. Payments not made soon after the acquisition date to settle a contingent consideration liability are classified as cash flows from financing activities up to the amount of the contingent consideration liability recognized at the acquisition date.

[0001327567-25-000027:notes:64]
Intangible Assets

[0001327567-25-000027:notes:65]
Purchased intangible assets with finite lives are carried at cost, less accumulated amortization. Amortization is computed using the straight-line method over the estimated useful lives of the assets.

[0001327567-25-000027:notes:66]
Impairment of Goodwill, Intangible Assets, and Other Long-Lived Assets

[0001327567-25-000027:notes:67]
Goodwill is evaluated for impairment on an annual basis in the fourth quarter of our fiscal year, and whenever events or changes in circumstances indicate the carrying amount of goodwill may not be recoverable. We have elected to first assess qualitative factors to determine whether it is more likely than not that the fair value of our single reporting unit is less than its carrying amount, including goodwill. If we determine that it is more likely than not that the fair value is less than its carrying amount, then the quantitative impairment test will be performed. Under the quantitative impairment test, if the carrying amount exceeds its fair value, we will recognize an impairment loss in an amount equal to that excess but limited to the total amount of goodwill.

[0001327567-25-000027:notes:68]
We evaluate events and changes in circumstances that could indicate carrying amounts of purchased intangible assets and other long-lived assets may not be recoverable. When such events or changes in circumstances occur, we assess the recoverability of an asset or asset group by determining whether or not the carrying amount will be recovered through undiscounted expected future cash flows. If the total of the future undiscounted cash flows is less than the carrying amount of an asset or asset group, we record an impairment loss for the amount by which the carrying amount exceeds the fair value of the asset or asset group.

[0001327567-25-000027:notes:69]
We did not recognize any impairment losses on our goodwill, intangible assets, or other long-lived assets during the years ended July 31, 2025, 2024, and 2023.

[0001327567-25-000027:notes:70]
Convertible Senior Notes

[0001327567-25-000027:notes:71]
Our convertible senior notes were fully settled upon maturity as of July 31, 2025. Prior to settlement, our convertible senior notes were accounted for as a liability and measured at their amortized cost. Transaction costs related to the issuance of the notes were netted with the liability and were amortized on a straight-line basis, which approximates the effective interest rate method, to interest expense over the term of the notes.

[0001327567-25-000027:notes:72]
Revenue Recognition

[0001327567-25-000027:notes:73]
Our revenue consists of product revenue and subscription and support revenue. Revenue is recognized when control of promised products, subscriptions and support services are transferred to customers, in an amount that reflects the expected consideration in exchange for those products and services.

[0001327567-25-000027:notes:74]
We determine revenue recognition through the following steps:

[0001327567-25-000027:notes:75]
•Identification of the contract, or contracts, with a customer.

[0001327567-25-000027:notes:76]
•Identification of the performance obligations in the contract.

[0001327567-25-000027:notes:77]
•Determination of the transaction price.

[0001327567-25-000027:notes:78]
•Allocation of the transaction price to the performance obligations in the contract.

[0001327567-25-000027:notes:79]
•Recognition of revenue when, or as, we satisfy a performance obligation.

[0001327567-25-000027:notes:80]
Revenues are reported net of sales taxes. Shipping charges billed to our customers are included in revenue and related costs are included in cost of revenue.

[0001327567-25-000027:notes:81]
Product Revenue

[0001327567-25-000027:notes:82]
Product revenue is derived from sales of our hardware products and software licenses. Our hardware products and software licenses include a broad set of built-in networking and security features and functionalities. We recognize product revenue at the time of hardware shipment or delivery of software license.

[0001327567-25-000027:notes:83]
Subscription and Support Revenue

[0001327567-25-000027:notes:84]
Subscription and support revenue is derived primarily from sales of our subscription and support offerings. We recognize subscription and support revenue over time as the services are performed. Our contractual subscription and support contracts are typically one to five years.

[0001327567-25-000027:notes:85]
Contracts with Multiple Performance Obligations

[0001327567-25-000027:notes:86]
The majority of our contracts with our customers include various combinations of our products and subscriptions and support. Our hardware products and software licenses are distinct from our subscriptions and support services as the customer can benefit from the product without these services and such services are separately identifiable within the contract. We account for multiple agreements with a single customer as a single contract if the contractual terms and/or substance of those agreements indicate that they may be so closely related that they are, in effect, parts of a single contract. The amount of consideration we expect to receive in exchange for delivering on the contract is allocated to each performance obligation based on its relative standalone selling price.

[0001327567-25-000027:notes:87]
When estimating standalone selling price, we first consider the prices charged for a deliverable when sold separately. If the standalone selling price is not observable through past transactions, we estimate it based on our pricing model and our go-to-market strategy, which include factors such as type of sales channel (channel partner or end-customer), the geographies in which our offerings were sold (domestic or international), and offering type (products, subscriptions, or support).

[0001327567-25-000027:notes:88]
Deferred Revenue

[0001327567-25-000027:notes:89]
We record deferred revenue when customers are invoiced or cash payments are received in advance of our performance. Our payment terms typically require payment within 30 to 45 days of the date we issue an invoice. The current portion of deferred revenue represents the amounts that are expected to be recognized as revenue within one year of the consolidated balance sheet date.

[0001327567-25-000027:notes:90]
Deferred Contract Costs

[0001327567-25-000027:notes:91]
We defer contract costs that are recoverable and incremental to obtaining customer sales contracts. Contract costs, which primarily consist of sales commissions, are amortized on a systematic basis that is consistent with the transfer to the customer of the goods or services to which the asset relates. Certain sales commissions for initial contracts are not commensurate with the commissions for renewal contracts, given the substantive difference in commission rates in proportion to their respective contract values. Sales commissions for initial contracts that are not commensurate are amortized over a benefit period of five years. The benefit period is determined by taking into consideration contract length, expected renewals, technology life, and other quantitative and qualitative factors. Sales commissions for initial contracts that are commensurate and sales commissions for renewal contracts are amortized over the related contractual period.

[0001327567-25-000027:notes:92]
We classify deferred contract costs as short-term or long-term based on when we expect to recognize the expense. The amortization of deferred contract costs is included in sales and marketing expense on our consolidated statements of operations. Deferred contract costs are periodically reviewed for impairment. We did not recognize any impairment losses on our deferred contract costs during the years ended July 31, 2025, 2024, or 2023.

[0001327567-25-000027:notes:93]
Software Development Costs

[0001327567-25-000027:notes:94]
Internally developed software includes security software developed to deliver our cloud-based subscription offerings to our end-customers. We capitalize internal compensation-related costs and external direct costs incurred during the application development stage and amortize these costs over a useful life of three years. As of July 31, 2025 and 2024, we capitalized as other assets on our consolidated balance sheets $167.3 million and $129.2 million in costs, respectively, net of accumulated amortization, for security software developed to deliver our cloud-based subscription offerings. We recognized amortization expense of $82.7 million, $77.2 million, and $79.5 million related to these capitalized costs as cost of subscription and support revenue on our consolidated statements of operations during the years ended July 31, 2025, 2024, and 2023, respectively.

[0001327567-25-000027:notes:95]
The costs to develop software that is marketed externally have not been capitalized as we believe our current software development process is essentially completed concurrent with the establishment of technological feasibility. As such, all related software development costs are expensed as incurred and included in research and development expense on our consolidated statements of operations.

[0001327567-25-000027:notes:96]
Share-Based Compensation

[0001327567-25-000027:notes:97]
Compensation expense related to share-based transactions is measured at fair value on the grant date. We recognize share-based compensation expense for awards with only service conditions on a straight-line basis over the requisite service period. We recognize share-based compensation expense for awards with market conditions and awards with performance conditions on a straight-line basis over the requisite service period for each separately vesting tranche of the award. We recognize share-based compensation expense for awards with performance conditions when it is probable that the performance condition will be achieved. We account for forfeitures of all share-based payment awards when they occur.

[0001327567-25-000027:notes:98]
Leases

[0001327567-25-000027:notes:99]
We determine if an arrangement is a lease at inception. We evaluate the classification of leases at commencement and, as necessary, at modification. Operating lease related balances are included in operating lease right-of-use assets, accrued and other liabilities, and long-term operating lease liabilities on our consolidated balance sheets. We did not have any material finance leases in any of the periods presented.

[0001327567-25-000027:notes:100]
Operating lease right-of-use assets represent our right to use an underlying asset for the lease term. Operating lease liabilities represent our obligation to make payments arising from the lease. Operating lease right-of-use assets and liabilities are recognized at the present value of the future lease payments at the lease commencement date. The interest rate used to determine the present value of the future lease payments is our incremental borrowing rate, because the interest rates implicit in our leases are not readily determinable. Our incremental borrowing rate is estimated to approximate the interest rate on a collateralized basis with similar terms and payments, and in similar economic environments. Operating lease right-of-use assets also include adjustments related to lease incentives, prepaid or accrued rent and initial direct lease costs. Operating lease right-of-use assets are subject to evaluation for impairment or disposal on a basis consistent with other long-lived assets.

[0001327567-25-000027:notes:101]
Our lease terms may include periods under options to extend or terminate the lease when it is reasonably certain that we will exercise that option. We generally use the base, non-cancelable lease term when determining our operating lease right-of-use assets and lease liabilities. Operating lease costs are recognized on a straight-line basis over the lease term.

[0001327567-25-000027:notes:102]
We account for lease and non-lease components as a single lease component and do not recognize right-of-use assets and lease liabilities for leases with a term of 12 months or less. Payments under our lease arrangements are primarily fixed, however, certain lease agreements contain variable payments, which are expensed as incurred and not included in operating lease right-of-use assets and liabilities. Our variable lease payments primarily consist of real estate taxes, common area maintenance charges, and insurance costs.

[0001327567-25-000027:notes:103]
Income Taxes

[0001327567-25-000027:notes:104]
We account for income taxes using the asset and liability method, which requires the recognition of deferred tax assets and liabilities for the expected future tax consequences of events that have been recognized in our consolidated financial statements or tax returns. In addition, deferred tax assets are recorded for all future benefits including, but not limited to, net operating losses, research and development credit carryforwards, and basis differences relating to our global intangible low-taxed income. Valuation allowances are provided when necessary to reduce deferred tax assets to the amount more likely than not to be realized.

[0001327567-25-000027:notes:105]
Significant judgment is required in determining any valuation allowance recorded against deferred tax assets. In assessing the need for a valuation allowance, we consider all available evidence, including past operating results, estimates of future taxable income, and the feasibility of tax planning strategies. In the event that we change our determination as to the amount of deferred tax assets that can be realized, we will adjust our valuation allowance with a corresponding impact to the provision for income taxes in the period in which such determination is made.

[0001327567-25-000027:notes:106]
We recognize liabilities for uncertain tax positions based on a two-step process which includes evaluating if a tax position is more likely than not to be sustained on audit and then measuring the tax benefit as the largest amount that is more likely than not to be realized upon ultimate settlement.

[0001327567-25-000027:notes:107]
Loss Contingencies

[0001327567-25-000027:notes:108]
We are subject to the possibility of various loss contingencies arising in the ordinary course of business. In determining loss contingencies, we consider the likelihood of loss or impairment of an asset, or the incurrence of a liability, as well as our ability to reasonably estimate the amount of loss. An estimated loss contingency is accrued when it is probable that an asset has been impaired or a liability has been incurred and the amount of loss can be reasonably estimated. If we determine that a loss is reasonably possible, then we disclose the possible loss or range of the possible loss or state that such an estimate cannot be made. We regularly evaluate current information available to us to determine whether an accrual is required, an accrual should be adjusted, or a range of possible loss should be disclosed.

[0001327567-25-000027:notes:109]
Recently Adopted Accounting Pronouncement

[0001327567-25-000027:notes:110]
Segment Reporting

[0001327567-25-000027:notes:111]
In November 2023, the Financial Accounting Standards Board (“FASB”) issued authoritative guidance that expands annual and interim disclosure requirements for reportable segments, primarily through enhanced disclosures about significant segment expenses. We adopted the standard in our fourth quarter of fiscal 2025. Refer to Note 19. Segment Information for more details.

[0001327567-25-000027:notes:112]
Recently Issued Accounting Pronouncements

[0001327567-25-000027:notes:113]
Income Tax Disclosures

[0001327567-25-000027:notes:114]
In December 2023, the FASB issued authoritative guidance that requires consistent categories and greater disaggregation of information in the effective tax rate reconciliation and additional disclosures of income taxes paid by jurisdiction. The standard is effective for our fiscal 2026 and could be applied either prospectively or retrospectively. We are currently evaluating the impact of this standard on our disclosures in the consolidated financial statements.

[0001327567-25-000027:notes:115]
Expense Disaggregation Disclosures

[0001327567-25-000027:notes:116]
In November 2024, the FASB issued authoritative guidance that expands annual and interim disclosure of specified information about certain costs and expenses in the notes to financial statements. The standard is effective for our annual period in fiscal 2028 and interim period in our first quarter of fiscal 2029, and could be applied either prospectively or retrospectively. Early adoption is permitted. We are currently evaluating the impact of this standard on our disclosures in the consolidated financial statements.

[0001327567-25-000027:notes:117]
Measurement of Credit Losses for Accounts Receivable and Contract Assets

[0001327567-25-000027:notes:118]
In July 2025, the FASB issued authoritative guidance that provides a practical expedient for estimating expected credit losses on accounts receivable and contract assets. The standard is effective for us in our first quarter of fiscal 2027 and will be applied on a prospective basis. Early adoption is permitted. We are currently evaluating the impact of this standard on our consolidated financial statements.


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0001327567-25-000027:notes:119]
The estimated useful lives of our depreciable assets are as follows:

[0001327567-25-000027:notes:120]
The following table presents details of our property and equipment, net (in millions):

[0001327567-25-000027:notes:121]
|  | July 31, |
|  | 2025 |  | 2024 |
| Computers, equipment, and software | $ | 513.3 |  |  | $ | 466.0 |  |
| Leasehold improvements | 324.7 |  |  | 274.0 |  |
| Land | 87.2 |  |  | 87.2 |  |
| Demonstration units | 46.7 |  |  | 44.4 |  |
| Furniture and fixtures | 54.0 |  |  | 48.7 |  |
| Total property and equipment, gross | 1,025.9 |  |  | 920.3 |  |
| Less: accumulated depreciation | (638.6) |  |  | (559.2) |  |
| Total property and equipment, net | $ | 387.3 |  |  | $ | 361.1 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001327567-25-000027:notes:122]
Revenue
Disaggregation of Revenue

[0001327567-25-000027:notes:123]
The following table presents revenue by geographic theater (in millions):

[0001327567-25-000027:notes:124]
|  | Year Ended July 31, |
|  | 2025 |  | 2024 |  | 2023 |
| Revenue: |  |  |  |  |  |
| Americas |  |  |  |  |  |
| United States | $ | 5,786.2 |  |  | $ | 5,134.0 |  |  | $ | 4,424.2 |  |
| Other Americas | 418.9 |  |  | 348.9 |  |  | 295.7 |  |
| Total Americas | 6,205.1 |  |  | 5,482.9 |  |  | 4,719.9 |  |
| Europe, the Middle East, and Africa (“EMEA”) | 1,917.4 |  |  | 1,602.0 |  |  | 1,359.6 |  |
| Asia Pacific and Japan (“APAC”) | 1,099.0 |  |  | 942.6 |  |  | 813.2 |  |
| Total revenue | $ | 9,221.5 |  |  | $ | 8,027.5 |  |  | $ | 6,892.7 |  |

[0001327567-25-000027:notes:125]
The following table presents revenue for groups of similar products and services (in millions):

[0001327567-25-000027:notes:126]
|  | Year Ended July 31, |
|  | 2025 |  | 2024 |  | 2023 |
| Revenue: |  |  |  |  |  |
| Product | $ | 1,801.9 |  |  | $ | 1,603.3 |  |  | $ | 1,578.4 |  |
| Subscription and support |  |  |  |  |  |
| Subscription | 4,974.4 |  |  | 4,188.5 |  |  | 3,335.4 |  |
| Support | 2,445.2 |  |  | 2,235.7 |  |  | 1,978.9 |  |
| Total subscription and support | 7,419.6 |  |  | 6,424.2 |  |  | 5,314.3 |  |
| Total revenue | $ | 9,221.5 |  |  | $ | 8,027.5 |  |  | $ | 6,892.7 |  |

[0001327567-25-000027:notes:127]
During the years ended July 31, 2025 and 2024, we recognized approximately $5.5 billion and $4.6 billion of revenue pertaining to amounts that were deferred as of July 31, 2024 and 2023, respectively.

[0001327567-25-000027:notes:128]
Remaining Performance Obligations

[0001327567-25-000027:notes:129]
Remaining performance obligations were $15.8 billion as of July 31, 2025, of which we expect to recognize as revenue approximately $7.0 billion over the next 12 months and the remainder thereafter.


## us-gaap:FairValueDisclosuresTextBlock

[0001327567-25-000027:notes:130]
Fair Value Measurements
The following table presents our financial assets and liabilities measured at fair value on a recurring basis as of July 31, 2025 and 2024 (in millions):

[0001327567-25-000027:notes:131]
|  |  | July 31, 2025 |  | July 31, 2024 |
|  |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Cash equivalents: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 1,206.1 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,206.1 |  |  | $ | 494.0 |  |  | $ | — |  |  | $ | — |  |  | $ | 494.0 |  |
| Commercial paper |  | — |  |  | 168.5 |  |  | — |  |  | 168.5 |  |  | — |  |  | 299.6 |  |  | — |  |  | 299.6 |  |
| Corporate debt securities |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 18.2 |  |  | — |  |  | 18.2 |  |
| U.S. government and agency securities |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 149.6 |  |  | — |  |  | 149.6 |  |
| Total cash equivalents |  | 1,206.1 |  |  | 168.5 |  |  | — |  |  | 1,374.6 |  |  | 494.0 |  |  | 467.4 |  |  | — |  |  | 961.4 |  |
| Short-term investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Certificates of deposit |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 20.6 |  |  | — |  |  | 20.6 |  |
| Commercial paper |  | — |  |  | 14.8 |  |  | — |  |  | 14.8 |  |  | — |  |  | 79.9 |  |  | — |  |  | 79.9 |  |
| Corporate debt securities |  | — |  |  | 584.0 |  |  | — |  |  | 584.0 |  |  | — |  |  | 935.9 |  |  | — |  |  | 935.9 |  |
| U.S. government and agency securities |  | — |  |  | 5.9 |  |  | — |  |  | 5.9 |  |  | — |  |  | 2.7 |  |  | — |  |  | 2.7 |  |
| Non-U.S. government and agency securities |  | — |  |  | 3.1 |  |  | — |  |  | 3.1 |  |  | — |  |  | 4.2 |  |  | — |  |  | 4.2 |  |
| Asset-backed securities |  | — |  |  | 22.2 |  |  | — |  |  | 22.2 |  |  | — |  |  | 0.3 |  |  | — |  |  | 0.3 |  |
| Total short-term investments |  | — |  |  | 630.0 |  |  | — |  |  | 630.0 |  |  | — |  |  | 1,043.6 |  |  | — |  |  | 1,043.6 |  |
| Long-term investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate debt securities |  | — |  |  | 4,049.8 |  |  | — |  |  | 4,049.8 |  |  | — |  |  | 3,151.3 |  |  | — |  |  | 3,151.3 |  |
| U.S. government and agency securities |  | — |  |  | 164.5 |  |  | — |  |  | 164.5 |  |  | — |  |  | 19.0 |  |  | — |  |  | 19.0 |  |
| Non-U.S. government and agency securities |  | — |  |  | 26.2 |  |  | — |  |  | 26.2 |  |  | — |  |  | 54.4 |  |  | — |  |  | 54.4 |  |
| Asset-backed securities |  | — |  |  | 1,315.1 |  |  | — |  |  | 1,315.1 |  |  | — |  |  | 948.5 |  |  | — |  |  | 948.5 |  |
| Total long-term investments |  | — |  |  | 5,555.6 |  |  | — |  |  | 5,555.6 |  |  | — |  |  | 4,173.2 |  |  | — |  |  | 4,173.2 |  |

[0001327567-25-000027:notes:132]
|  |  | July 31, 2025 |  | July 31, 2024 |
|  |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Prepaid expenses and other current assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency forward contracts |  | — |  |  | 57.9 |  |  | — |  |  | 57.9 |  |  | — |  |  | 4.1 |  |  | — |  |  | 4.1 |  |
| Total prepaid expenses and other current assets |  | — |  |  | 57.9 |  |  | — |  |  | 57.9 |  |  | — |  |  | 4.1 |  |  | — |  |  | 4.1 |  |
| Other assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency forward contracts |  | — |  |  | 3.4 |  |  | — |  |  | 3.4 |  |  | — |  |  | 0.1 |  |  | — |  |  | 0.1 |  |
| Total other assets |  | — |  |  | 3.4 |  |  | — |  |  | 3.4 |  |  | — |  |  | 0.1 |  |  | — |  |  | 0.1 |  |
| Total assets measured at fair value |  | $ | 1,206.1 |  |  | $ | 6,415.4 |  |  | $ | — |  |  | $ | 7,621.5 |  |  | $ | 494.0 |  |  | $ | 5,688.4 |  |  | $ | — |  |  | $ | 6,182.4 |  |
| Accrued and other liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency forward contracts |  | $ | — |  |  | $ | 3.6 |  |  | $ | — |  |  | $ | 3.6 |  |  | $ | — |  |  | $ | 15.3 |  |  | $ | — |  |  | $ | 15.3 |  |
| Contingent consideration |  | — |  |  | — |  |  | 276.0 |  |  | 276.0 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Total accrued and other liabilities |  | — |  |  | 3.6 |  |  | 276.0 |  |  | 279.6 |  |  | — |  |  | 15.3 |  |  | — |  |  | 15.3 |  |
| Other long-term liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency forward contracts |  | — |  |  | 0.1 |  |  | — |  |  | 0.1 |  |  | — |  |  | 0.9 |  |  | — |  |  | 0.9 |  |
| Contingent consideration |  | — |  |  | — |  |  | 237.6 |  |  | 237.6 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Total other long-term liabilities |  | — |  |  | 0.1 |  |  | 237.6 |  |  | 237.7 |  |  | — |  |  | 0.9 |  |  | — |  |  | 0.9 |  |
| Total liabilities measured at fair value |  | $ | — |  |  | $ | 3.7 |  |  | $ | 513.6 |  |  | $ | 517.3 |  |  | $ | — |  |  | $ | 16.2 |  |  | $ | — |  |  | $ | 16.2 |  |

[0001327567-25-000027:notes:133]
The fair value of our contingent consideration liability is estimated using a discounted cash flow valuation technique. We consider the fair value of our contingent consideration liability to be a Level 3 measurement as we use unobservable inputs in determining discounted cash flows to estimate the fair value. The significant unobservable inputs include an estimate of future cash payments related to customers entering into qualified new transactions as well as a risk-adjusted discount rate used to present value the expected cash flows. A significant change in any of these assumptions could have a material impact to the fair value of our contingent consideration liability.

[0001327567-25-000027:notes:134]
In June 2025, we amended the terms of our contingent consideration arrangement with International Business Machines Corporation (“IBM”). During the three months ended July 31, 2025, we reduced our estimate of future cash payments based on the amended terms and our quarterly assessment of assumptions, including the magnitude and likelihood of customers entering into qualified new transactions, the competitive industry environment, and current market conditions.

[0001327567-25-000027:notes:135]
The following table presents a reconciliation of our contingent consideration liability (in millions):

[0001327567-25-000027:notes:136]
|  | Year Ended July 31, 2025 |  |  |  |  |
| Contingent consideration liability at the beginning of the period | $ | — |  |  |  |  |  |
| Initial valuation on the acquisition date | 648.9 |  |  |  |  |  |
| Change in fair value | (135.3) |  |  |  |  |  |
| Contingent consideration liability at the end of the period | $ | 513.6 |  |  |  |  |  |

[0001327567-25-000027:notes:137]
The total estimated fair value of our financing receivables approximates their carrying amounts as of July 31, 2025 and 2024. We consider the fair value of our financing receivables to be a Level 3 measurement as we use unobservable inputs in determining discounted cash flows to estimate the fair value.

[0001327567-25-000027:notes:138]
Refer to Note 11. Debt, for the carrying amount and estimated fair value of our convertible senior notes as of July 31, 2024.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001327567-25-000027:notes:139]
Cash Equivalents and Investments
Available-for-sale Debt Securities

[0001327567-25-000027:notes:140]
The following tables summarize the amortized cost, unrealized gains and losses, and fair value of our available-for-sale debt securities (in millions):

[0001327567-25-000027:notes:141]
|  | July 31, 2025 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | $ | 168.5 |  |  | $ | — |  |  | $ | — |  |  | $ | 168.5 |  |
| Total available-for-sale cash equivalents | $ | 168.5 |  |  | $ | — |  |  | $ | — |  |  | $ | 168.5 |  |
| Investments: |  |  |  |  |  |  |  |
| Commercial paper | $ | 14.8 |  |  | $ | — |  |  | $ | — |  |  | $ | 14.8 |  |
| Corporate debt securities | 4,587.9 |  |  | 47.0 |  |  | (1.1) |  |  | 4,633.8 |  |
| U.S. government and agency securities | 170.5 |  |  | — |  |  | (0.1) |  |  | 170.4 |  |
| Non-U.S. government and agency securities | 28.8 |  |  | 0.5 |  |  | — |  |  | 29.3 |  |
| Asset-backed securities | 1,328.3 |  |  | 9.3 |  |  | (0.3) |  |  | 1,337.3 |  |
| Total available-for-sale investments | $ | 6,130.3 |  |  | $ | 56.8 |  |  | $ | (1.5) |  |  | $ | 6,185.6 |  |

[0001327567-25-000027:notes:142]
|  | July 31, 2024 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | $ | 299.6 |  |  | $ | — |  |  | $ | — |  |  | $ | 299.6 |  |
| Corporate debt securities | 18.2 |  |  | — |  |  | — |  |  | 18.2 |  |
| U.S. government and agency securities | 149.6 |  |  | — |  |  | — |  |  | 149.6 |  |
| Total available-for-sale cash equivalents | $ | 467.4 |  |  | $ | — |  |  | $ | — |  |  | $ | 467.4 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 20.6 |  |  | $ | — |  |  | $ | — |  |  | $ | 20.6 |  |
| Commercial paper | 79.9 |  |  | 0.1 |  |  | (0.1) |  |  | 79.9 |  |
| Corporate debt securities | 4,065.5 |  |  | 28.3 |  |  | (6.6) |  |  | 4,087.2 |  |
| U.S. government and agency securities | 21.9 |  |  | — |  |  | (0.2) |  |  | 21.7 |  |
| Non-U.S. government and agency securities | 57.9 |  |  | 0.7 |  |  | — |  |  | 58.6 |  |
| Asset-backed securities | 943.1 |  |  | 6.3 |  |  | (0.6) |  |  | 948.8 |  |
| Total available-for-sale investments | $ | 5,188.9 |  |  | $ | 35.4 |  |  | $ | (7.5) |  |  | $ | 5,216.8 |  |

[0001327567-25-000027:notes:143]
Unrealized losses related to our available-for-sale debt securities are primarily due to interest rate fluctuations as opposed to credit quality. We do not intend to sell any of the securities in an unrealized loss position and it is not likely that we would be required to sell these securities before recovery of their amortized cost basis, which may be at maturity. We did not recognize any credit losses related to our available-for-sale debt securities during the years ended July 31, 2025 and 2024.

[0001327567-25-000027:notes:144]
The following table summarizes the amortized cost and fair value of our available-for-sale debt securities as of July 31, 2025, by contractual years-to-maturity (in millions):

[0001327567-25-000027:notes:145]
|  | Amortized Cost |  | Fair Value |
| Due within one year | $ | 797.3 |  |  | $ | 798.5 |  |
| Due between one and three years | 1,896.9 |  |  | 1,912.9 |  |
| Due between three and five years | 3,128.2 |  |  | 3,161.5 |  |
| Due between five and ten years | 293.2 |  |  | 295.5 |  |
| Due after ten years | 183.2 |  |  | 185.7 |  |
| Total | $ | 6,298.8 |  |  | $ | 6,354.1 |  |

[0001327567-25-000027:notes:146]
Marketable Equity Securities

[0001327567-25-000027:notes:147]
Marketable equity securities consist of money market funds and are included in cash and cash equivalents on our consolidated balance sheets. As of July 31, 2025 and 2024, the carrying values of our marketable equity securities were $1.2 billion and $494.0 million, respectively. There were no unrealized gains or losses recognized for these securities during the years ended July 31, 2025, 2024, and 2023.


## us-gaap:FinancingReceivablesTextBlock

[0001327567-25-000027:notes:148]
Financing Receivables
The following table summarizes our short-term and long-term financing receivables (in millions):

[0001327567-25-000027:notes:149]
|  | July 31, |
|  | 2025 |  | 2024 |
| Short-term financing receivables, gross | $ | 806.1 |  |  | $ | 830.2 |  |
| Unearned income | (85.8) |  |  | (95.7) |  |
| Allowance for credit losses | (5.7) |  |  | (8.6) |  |
| Short-term financing receivables, net | $ | 714.6 |  |  | $ | 725.9 |  |
| Long-term financing receivables, gross | $ | 1,079.4 |  |  | $ | 1,286.4 |  |
| Unearned income | (69.1) |  |  | (94.6) |  |
| Allowance for credit losses | (8.0) |  |  | (9.7) |  |
| Long-term financing receivables, net | $ | 1,002.3 |  |  | $ | 1,182.1 |  |

[0001327567-25-000027:notes:150]
The following table presents amortized cost basis of our financing receivables categorized by internal risk rating and year of origination (in millions):

[0001327567-25-000027:notes:151]
| Internal Risk Rating(1) |  | July 31, 2025 |  | July 31, 2024 |
|  | Fiscal Years Ended July 31, |  |  |  | Fiscal Years Ended July 31, |  |  |
|  | 2025 |  | 2024 |  | 2023 |  | 2022 |  | 2021 |  | Total |  | 2024 |  | 2023 |  | 2022 |  | 2021 |  | Total |
| 1 to 4 |  | $ | 260.9 |  |  | $ | 732.1 |  |  | $ | 242.4 |  |  | $ | 9.2 |  |  | $ | 17.8 |  |  | $ | 1,262.4 |  |  | $ | 885.9 |  |  | $ | 477.3 |  |  | $ | 14.7 |  |  | $ | 44.4 |  |  | $ | 1,422.3 |  |
| 5 to 6 |  | 174.3 |  |  | 226.1 |  |  | 49.8 |  |  | — |  |  | — |  |  | 450.2 |  |  | 272.2 |  |  | 172.0 |  |  | 21.1 |  |  | 1.1 |  |  | 466.4 |  |
| 7 to 10 |  | 0.1 |  |  | 3.9 |  |  | 14.0 |  |  | — |  |  | — |  |  | 18.0 |  |  | 3.2 |  |  | 25.0 |  |  | 0.3 |  |  | 9.1 |  |  | 37.6 |  |
| Amortized cost basis of financing receivables |  | $ | 435.3 |  |  | $ | 962.1 |  |  | $ | 306.2 |  |  | $ | 9.2 |  |  | $ | 17.8 |  |  | $ | 1,730.6 |  |  | $ | 1,161.3 |  |  | $ | 674.3 |  |  | $ | 36.1 |  |  | $ | 54.6 |  |  | $ | 1,926.3 |  |

[0001327567-25-000027:notes:152]
(1)Internal risk ratings are categorized as 1 through 10, with the lowest rating representing the highest quality.

[0001327567-25-000027:notes:153]
We sold $37.8 million of our financing receivables during the year ended July 31, 2025. The associated gains and losses were not material.
There was no significant activity in allowance for credit losses during the years ended July 31, 2025 and 2024. Past due amounts on financing receivables were not material as of July 31, 2025 and 2024.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001327567-25-000027:notes:154]
Derivative Instruments
As of July 31, 2025 and 2024, the notional amount of our outstanding foreign currency forward contracts designated as cash flow hedges was $964.3 million and $804.8 million, respectively. Refer to Note 3. Fair Value Measurements for the fair value of our derivative instruments as reported on our consolidated balance sheets as of July 31, 2025 and 2024.

[0001327567-25-000027:notes:155]
As of July 31, 2025, unrealized gains and losses in AOCI related to our cash flow hedges were a $39.8 million net gain, of which $38.4 million in gains are expected to be recognized into earnings within the next 12 months. As of July 31, 2024, unrealized gains and losses in AOCI related to our cash flow hedges were a $10.6 million net loss.

[0001327567-25-000027:notes:156]
As of July 31, 2025 and 2024, the notional amount of our outstanding foreign currency forward contracts not designated as hedging instruments was $504.2 million and $375.6 million, respectively.


## us-gaap:InventoryDisclosureTextBlock

[0001327567-25-000027:notes:157]
Inventory
As of July 31, 2025 and 2024, our inventory balance was $113.4 million and $115.9 million, respectively.
For the years ended July 31, 2025 and 2024, inventory write-downs and excess manufacturing purchase commitment charges were $71.2 million and $24.9 million, respectively. For the year ended July 31, 2023, inventory write-downs and excess manufacturing purchase commitment charges was not significant.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001327567-25-000027:notes:158]
Acquisitions
Fiscal 2025

[0001327567-25-000027:notes:159]
IBM QRadar Assets

[0001327567-25-000027:notes:160]
On August 31, 2024, we completed the acquisition of certain IBM QRadar assets, including certain intellectual property rights, customer relationships, and software as a service customer contracts. The total purchase consideration for the acquisition was $1.1 billion, which consisted of the following (in millions):

[0001327567-25-000027:notes:161]
|  | Amount |
| Cash | $ | 500.0 |  |
| Fair value of contingent consideration liability on the acquisition date | 648.9 |  |
| Return of purchase consideration | (6.3) |  |
| Total | $ | 1,142.6 |  |

[0001327567-25-000027:notes:162]
As part of the acquisition, we agreed to make post-closing payments to IBM contingent upon customers entering into qualified new transactions through June 30, 2028. We also expect to receive a return of purchase consideration of $6.3 million due to timing of transition of certain underlying customer contracts, of which $2.9 million was received during the year ended July 31, 2025. In addition, we have entered into a transition services arrangement with IBM, under which IBM will perform certain services supporting the acquired assets and customers for a period of time that ends in the fiscal quarter ending October 2026.

[0001327567-25-000027:notes:163]
Payments related to the contingent consideration liability are expected to begin in the fiscal quarter ending October 2025 and continue through the fiscal quarter ending October 2028. The estimated range of undiscounted contingent consideration is between $0.4 billion and $0.6 billion. Refer to Note 3. Fair Value Measurements, for more information on the fair value of our contingent consideration liability.

[0001327567-25-000027:notes:164]
We have accounted for this transaction as a business combination and allocated the purchase consideration to assets acquired and liabilities assumed based on estimated fair values, as presented in the following table (in millions):

[0001327567-25-000027:notes:165]
|  | Amount |
| Goodwill | $ | 700.7 |  |
| Identified intangible assets | 476.0 |  |
| Net liabilities assumed | (34.1) |  |
| Total | $ | 1,142.6 |  |

[0001327567-25-000027:notes:166]
Goodwill generated from this business combination is primarily attributable to the expected post-acquisition synergies from increased market penetration to support the growth of our Cortex Security Operations business. The goodwill is deductible for U.S. income tax purposes.

[0001327567-25-000027:notes:167]
The following table presents details of the identified intangible assets acquired (in millions, except years):

[0001327567-25-000027:notes:168]
|  | Fair Value |  | Estimated Useful Life |
| Customer relationships | $ | 464.0 |  |  | 12 years |
| Developed technology | 12.0 |  |  | 2 years |
| Total | $ | 476.0 |  |  |  |

[0001327567-25-000027:notes:169]
Protect AI, Inc.

[0001327567-25-000027:notes:170]
On July 22, 2025, we completed our acquisition of Protect AI, Inc. (“Protect AI”), a privately-held cyber security company focused on AI security. The total purchase consideration for the acquisition of Protect AI was $634.5 million, which consisted of the following (in millions):

[0001327567-25-000027:notes:171]
|  | Amount |
| Cash | $ | 607.4 |  |
| Fair value of replacement awards | 27.1 |  |
| Total | $ | 634.5 |  |

[0001327567-25-000027:notes:172]
As part of the acquisition, we issued $106.5 million of replacement awards, of which the portion attributable to services performed prior to the acquisition date was allocated to purchase consideration. The remaining fair value was allocated to future services and will be expensed over the remaining service periods as share-based compensation.

[0001327567-25-000027:notes:173]
We have accounted for this transaction as a business combination and allocated the purchase consideration to assets acquired and liabilities assumed based on preliminary estimated fair values, as presented in the following table (in millions):

[0001327567-25-000027:notes:174]
|  | Amount |
| Goodwill | $ | 515.8 |  |
| Identified intangible assets | 70.0 |  |
| Cash | 50.5 |  |
| Net liabilities assumed | (1.8) |  |
| Total | $ | 634.5 |  |

[0001327567-25-000027:notes:175]
Goodwill generated from this business combination is primarily attributable to the assembled workforce and expected post-acquisition synergies from integrating Protect AI technology into our platforms. The goodwill is not deductible for U.S. income tax purposes.

[0001327567-25-000027:notes:176]
The following table presents details of the identified intangible asset acquired (in millions, except years):

[0001327567-25-000027:notes:177]
|  | Fair Value |  | Estimated Useful Life |
| Developed technology | $ | 70.0 |  |  | 5 years |

[0001327567-25-000027:notes:178]
CyberArk Software Ltd.

[0001327567-25-000027:notes:179]
On July 30, 2025, we entered into a definitive agreement to acquire CyberArk Software Ltd., an identity security company (“CyberArk”). The acquisition is expected to close during the second half of our fiscal 2026, subject to the satisfaction of customary closing conditions, including the receipt of CyberArk shareholder approval, the expiration of the waiting period under the Hart-Scott-Rodino Antitrust Improvements Act of 1976, as amended, and receipt of other approvals under specified antitrust and foreign investment laws. Under the terms of the agreement, CyberArk shareholders will receive $45.00 in cash and 2.2005 shares of our common stock for each CyberArk share. This represents an equity value of approximately $25 billion for CyberArk based on the unaffected 10-day average daily volume-weighted average trading prices of our common stock as of July 25, 2025. We expect to fund the cash portion of the consideration with our cash on hand. The agreement also provides that we will assume certain unvested outstanding equity awards held by CyberArk employees.

[0001327567-25-000027:notes:180]
We and CyberArk each have certain termination rights under the definitive acquisition agreement. A termination fee of $1.0 billion may be payable by us to CyberArk, or a fee of $750.0 million may be payable by CyberArk to us, upon termination of the definitive acquisition agreement under specified circumstances.

[0001327567-25-000027:notes:181]
Fiscal 2024

[0001327567-25-000027:notes:182]
Dig Security Solutions Ltd.

[0001327567-25-000027:notes:183]
On December 5, 2023, we completed our acquisition of Dig Security Solutions Ltd. (“Dig”), a privately-held cyber security company providing a data security posture management solution for multi-cloud environments. The total purchase consideration for the acquisition of Dig was $255.4 million, which consisted of the following (in millions):

[0001327567-25-000027:notes:184]
|  | Amount |
| Cash | $ | 247.6 |  |
| Fair value of replacement awards | 7.8 |  |
| Total | $ | 255.4 |  |

[0001327567-25-000027:notes:185]
As part of the acquisition, we issued replacement equity awards, which included 0.4 million shares of our restricted common stock. The total fair value of the replacement equity awards was $72.0 million, of which the portion attributable to services performed prior to the acquisition date was allocated to purchase consideration. The remaining fair value was allocated to future services and will be expensed over the remaining service periods as share-based compensation.

[0001327567-25-000027:notes:186]
|  | Amount |
| Goodwill | $ | 186.4 |  |
| Identified intangible assets | 45.4 |  |
| Cash and restricted cash | 22.1 |  |
| Net assets acquired | 1.5 |  |
| Total | $ | 255.4 |  |

[0001327567-25-000027:notes:187]
Goodwill generated from this business combination is primarily attributable to the assembled workforce and expected post-acquisition synergies from integrating Dig technology into our platforms. The goodwill is deductible for U.S. income tax purposes.

[0001327567-25-000027:notes:188]
|  | Fair Value |  | Estimated Useful Life |
| Developed technology | $ | 45.4 |  |  | 5 years |

[0001327567-25-000027:notes:189]
Talon Cyber Security Ltd.

[0001327567-25-000027:notes:190]
On December 28, 2023, we completed our acquisition of Talon Cyber Security Ltd. (“Talon”), a privately-held cyber security company providing a secure enterprise browser solution. The total purchase consideration for the acquisition of Talon was $458.6 million, which consisted of the following (in millions):

[0001327567-25-000027:notes:191]
|  | Amount |
| Cash | $ | 439.0 |  |
| Fair value of replacement awards | 19.6 |  |
| Total | $ | 458.6 |  |

[0001327567-25-000027:notes:192]
As part of the acquisition, we issued replacement equity awards, which included 0.6 million shares of our restricted common stock. The total fair value of the replacement equity awards was $109.6 million, of which the portion attributable to services performed prior to the acquisition date was allocated to purchase consideration. The remaining fair value was allocated to future services and will be expensed over the remaining service periods as share-based compensation.

[0001327567-25-000027:notes:193]
|  | Amount |
| Goodwill | $ | 236.9 |  |
| Identified intangible assets | 131.4 |  |
| Cash and restricted cash | 53.9 |  |
| Net assets acquired | 36.4 |  |
| Total | $ | 458.6 |  |

[0001327567-25-000027:notes:194]
Goodwill generated from this business combination is primarily attributable to the assembled workforce and expected post-acquisition synergies from integrating Talon technology into our platforms. The goodwill is deductible for U.S. income tax purposes.

[0001327567-25-000027:notes:195]
|  | Fair Value |  | Estimated Useful Life |
| Developed technology | $ | 131.4 |  |  | 5 years |

[0001327567-25-000027:notes:196]
Fiscal 2023

[0001327567-25-000027:notes:197]
Cider Security Ltd.

[0001327567-25-000027:notes:198]
On December 20, 2022, we completed our acquisition of Cider Security Ltd. (“Cider”), a privately-held cloud security company. The total purchase consideration for the acquisition of Cider was $198.3 million, which consisted of the following (in millions):

[0001327567-25-000027:notes:199]
|  | Amount |
| Cash | $ | 198.0 |  |
| Fair value of replacement awards | 0.3 |  |
| Total | $ | 198.3 |  |

[0001327567-25-000027:notes:200]
As part of the acquisition, we issued replacement equity awards, which included 0.4 million shares of our restricted common stock. The total fair value of the replacement equity awards was $48.6 million, of which the portion attributable to services performed prior to the acquisition date was allocated to purchase consideration. The remaining fair value was allocated to future services and will be expensed over the remaining service periods as share-based compensation.

[0001327567-25-000027:notes:201]
We have accounted for this transaction as a business combination and allocated the purchase consideration to assets acquired and liabilities assumed based on estimated fair values, as presented in the following table (in millions):

[0001327567-25-000027:notes:202]
|  | Amount |
| Goodwill | $ | 164.6 |  |
| Identified intangible assets | 27.8 |  |
| Cash | 12.4 |  |
| Net liabilities assumed | (6.5) |  |
| Total | $ | 198.3 |  |

[0001327567-25-000027:notes:203]
Goodwill generated from this business combination is primarily attributable to the assembled workforce and expected post-acquisition synergies from integrating Cider technology into our platforms. The goodwill is deductible for U.S. income tax purposes.

[0001327567-25-000027:notes:204]
The following table presents the identified intangible asset acquired (in millions, except years):

[0001327567-25-000027:notes:205]
|  | Fair Value |  | Estimated Useful Life |
| Developed technology | $ | 27.8 |  |  | 5 years |

[0001327567-25-000027:notes:206]
Other acquisition

[0001327567-25-000027:notes:207]
In April 2023, we completed an acquisition for total purchase consideration of $18.9 million in cash. We have accounted for this transaction as a business combination and recorded goodwill of $14.5 million. The goodwill is not deductible for income tax purposes.

[0001327567-25-000027:notes:208]
Additional Acquisition-Related Information

[0001327567-25-000027:notes:209]
Pro forma results of operations have not been presented because the effects of the acquisitions were not material to our consolidated statements of operations.

[0001327567-25-000027:notes:210]
Additional information related to our Protect AI acquisition, such as that related to income tax and other contingencies, existing as of the acquisition date may become known during the remainder of the measurement period, not to exceed 12 months from the acquisition date, which may result in changes to the amounts and allocations recorded.


## us-gaap:ScheduleOfBusinessAcquisitionsByAcquisitionTextBlock

[0001327567-25-000027:notes:211]
The total purchase consideration for the acquisition was $1.1 billion, which consisted of the following (in millions):

[0001327567-25-000027:notes:212]
The total purchase consideration for the acquisition of Protect AI was $634.5 million, which consisted of the following (in millions):

[0001327567-25-000027:notes:213]
The total purchase consideration for the acquisition of Dig was $255.4 million, which consisted of the following (in millions):

[0001327567-25-000027:notes:214]
The total purchase consideration for the acquisition of Talon was $458.6 million, which consisted of the following (in millions):

[0001327567-25-000027:notes:215]
The total purchase consideration for the acquisition of Cider was $198.3 million, which consisted of the following (in millions):


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001327567-25-000027:notes:216]
Goodwill and Intangible Assets
Goodwill

[0001327567-25-000027:notes:217]
The following table presents details of our goodwill during the year ended July 31, 2025 (in millions):

[0001327567-25-000027:notes:218]
|  | Amount |
| Balance as of July 31, 2024 | $ | 3,350.1 |  |
| Goodwill acquired | 1,216.5 |  |
| Balance as of July 31, 2025 | $ | 4,566.6 |  |

[0001327567-25-000027:notes:219]
Purchased Intangible Assets

[0001327567-25-000027:notes:220]
The following table presents details of our purchased intangible assets (in millions):

[0001327567-25-000027:notes:221]
|  | July 31, |
|  | 2025 |  | 2024 |
|  | Gross Carrying Amount |  | Accumulated Amortization |  | Net Carrying Amount |  | Gross Carrying Amount |  | Accumulated Amortization |  | Net Carrying Amount |
| Intangible assets subject to amortization: |  |  |  |  |  |  |  |  |  |  |  |
| Developed technology | $ | 535.3 |  |  | $ | (274.3) |  |  | $ | 261.0 |  |  | $ | 813.9 |  |  | $ | (526.2) |  |  | $ | 287.7 |  |
| Customer relationships | 609.0 |  |  | (123.2) |  |  | 485.8 |  |  | 172.7 |  |  | (96.1) |  |  | 76.6 |  |
| Acquired intellectual property | 24.4 |  |  | (8.6) |  |  | 15.8 |  |  | 18.2 |  |  | (7.9) |  |  | 10.3 |  |
| Trade name and trademarks | — |  |  | — |  |  | — |  |  | 9.4 |  |  | (9.4) |  |  | — |  |
| Other | 0.9 |  |  | (0.8) |  |  | 0.1 |  |  | 0.9 |  |  | (0.6) |  |  | 0.3 |  |
| Total purchased intangible assets | $ | 1,169.6 |  |  | $ | (406.9) |  |  | $ | 762.7 |  |  | $ | 1,015.1 |  |  | $ | (640.2) |  |  | $ | 374.9 |  |

[0001327567-25-000027:notes:222]
We recognized amortization expense of $166.3 million, $120.9 million, and $104.9 million for the years ended July 31, 2025, 2024, and 2023, respectively.

[0001327567-25-000027:notes:223]
The following table summarizes estimated future amortization expense of our intangible assets subject to amortization as of July 31, 2025 (in millions):

[0001327567-25-000027:notes:224]
|  |  |  | Fiscal years ending July 31, |
|  | Total |  | 2026 |  | 2027 |  | 2028 |  | 2029 |  | 2030 |  | 2031 and Thereafter |
| Future amortization expense | $ | 762.7 |  |  | $ | 155.9 |  |  | $ | 125.0 |  |  | $ | 104.2 |  |  | $ | 78.2 |  |  | $ | 61.7 |  |  | $ | 237.7 |  |


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001327567-25-000027:notes:225]
Property and Equipment
The following table presents details of our property and equipment, net (in millions):

[0001327567-25-000027:notes:226]
We recognized depreciation expense of $94.4 million, $85.1 million, and $95.9 million related to property and equipment during the years ended July 31, 2025, 2024, and 2023, respectively.


## us-gaap:DebtDisclosureTextBlock

[0001327567-25-000027:notes:227]
Debt
Convertible Senior Notes

[0001327567-25-000027:notes:228]
In July 2018, we issued $1.7 billion aggregate principal amount of 0.75% Convertible Senior Notes due 2023 (the “2023 Notes”) and in June 2020, we issued $2.0 billion aggregate principal amount of 0.375% Convertible Senior Notes due 2025 (the “2025 Notes,” and together with the 2023 Notes, the “Notes”). The 2023 Notes bear interest at a fixed rate of 0.75% per year, payable semi-annually in arrears on January 1 and July 1 of each year, beginning on January 1, 2019. The 2023 Notes were converted prior to or settled on the maturity date of July 1, 2023 in accordance with their terms. The 2025 Notes bear interest at a fixed rate of 0.375% per year, payable semi-annually in arrears on June 1 and December 1 of each year, beginning on December 1, 2020. The 2025 Notes were converted prior to or settled on the maturity date of June 1, 2025 in accordance with their terms.

[0001327567-25-000027:notes:229]
The following table presents details of our Notes (number of shares in millions):

[0001327567-25-000027:notes:230]
|  | Conversion Rate per $1,000 Principal |  | Initial Conversion Price |  | Convertible Date |  | Initial Number of Shares |
| 2023 Notes | 22.5270 |  |  | $ | 44.39 |  |  | April 1, 2023 |  | 38.1 |  |
| 2025 Notes | 20.1612 |  |  | $ | 49.60 |  |  | March 1, 2025 |  | 40.3 |  |

[0001327567-25-000027:notes:231]
Holders of the 2023 Notes were able to early convert their 2023 Notes in fiscal 2023 up to April 1, 2023 and conversion requests received on or after April 1, 2023 were settled upon maturity of the 2023 Notes. Holders of the 2025 Notes were able to early convert their 2025 Notes in fiscal 2023, fiscal 2024, and fiscal 2025 up to March 1, 2025 and conversion requests received on or after March 1, 2025 were settled upon maturity of the 2025 Notes. During the years ended July 31, 2025, 2024, and 2023, we repaid in cash $965.6 million, $1.0 billion, and $1.7 billion, respectively, in aggregate principal amount of the Notes. We also issued 14.0 million, 14.0 million, and 22.9 million shares of our common stock to the holders of the Notes during the years ended July 31, 2025, 2024, and 2023, respectively, for the conversion value in excess of the principal amount. These shares were fully offset by shares we received from the corresponding exercise of the associated note hedges.

[0001327567-25-000027:notes:232]
The following table sets forth the net carrying amount of our 2025 Notes (in millions):

[0001327567-25-000027:notes:233]
|  | July 31, 2025 |  | July 31, 2024 |
| Principal | $ | — |  |  | $ | 965.6 |  |
| Less: debt issuance costs, net of amortization | — |  |  | (1.7) |  |
| Net carrying amount | $ | — |  |  | $ | 963.9 |  |

[0001327567-25-000027:notes:234]
The total estimated fair value of the 2025 Notes was $3.2 billion as of July 31, 2024. The fair value was determined based on the closing trading price per $100 of the 2025 Notes as of the last day of trading for the period. We consider the fair value of the 2025 Notes at July 31, 2024 to be a Level 2 measurement. The fair value of the 2025 Notes is primarily affected by the trading price of our common stock and market interest rates.

[0001327567-25-000027:notes:235]
The following table sets forth interest expense recognized related to the Notes (dollars in millions):

[0001327567-25-000027:notes:236]
|  | Year Ended July 31, 2025 |  | Year Ended July 31, 2024 |  | Year Ended July 31, 2023 |
|  | 2023 Notes |  | 2025 Notes |  | Total |  | 2023 Notes |  | 2025 Notes |  | Total |  | 2023 Notes |  | 2025 Notes |  | Total |
| Contractual interest expense | $ | — |  |  | $ | 1.9 |  |  | $ | 1.9 |  |  | $ | — |  |  | $ | 4.8 |  |  | $ | 4.8 |  |  | $ | 11.6 |  |  | $ | 7.5 |  |  | $ | 19.1 |  |
| Amortization of debt issuance costs | — |  |  | 1.1 |  |  | 1.1 |  |  | — |  |  | 3.5 |  |  | 3.5 |  |  | 2.6 |  |  | 4.1 |  |  | 6.7 |  |
| Total interest expense recognized | $ | — |  |  | $ | 3.0 |  |  | $ | 3.0 |  |  | $ | — |  |  | $ | 8.3 |  |  | $ | 8.3 |  |  | $ | 14.2 |  |  | $ | 11.6 |  |  | $ | 25.8 |  |
| Effective interest rate of the liability component | — | % |  | 0.6 | % |  |  |  | — | % |  | 0.6 | % |  |  |  | 0.9 | % |  | 0.6 | % |  |  |

[0001327567-25-000027:notes:237]
Note Hedges

[0001327567-25-000027:notes:238]
To minimize the impact of potential economic dilution upon conversion of our convertible senior notes, we entered into separate convertible note hedge transactions (the “2023 Note Hedges,” with respect to the 2023 Notes, the “2025 Note Hedges,” with respect to the 2025 Notes, and the 2023 Note Hedges together with 2025 Note Hedges, the “Note Hedges”) with respect to our common stock concurrent with the issuance of each series of the Notes.

[0001327567-25-000027:notes:239]
The following table presents details of our Note Hedges (in millions):

[0001327567-25-000027:notes:240]
|  | Initial Number of Shares |  | Aggregate Purchase |
| 2023 Note Hedges | 38.1 |  |  | $ | 332.0 |  |
| 2025 Note Hedges | 40.3 |  |  | $ | 370.8 |  |

[0001327567-25-000027:notes:241]
The Note Hedges covered shares of our common stock at a strike price per share that corresponded to the initial applicable conversion price of the applicable series of the Notes and were exercisable upon conversion of the applicable series of the Notes. The Note Hedges expired upon maturity of the applicable series of the Notes. The Note Hedges are separate transactions and are not part of the terms of the applicable series of the Notes. Holders of the Notes of either series do not have any rights with respect to the Note Hedges. Any shares of our common stock receivable by us under the Note Hedges are excluded from the calculation of diluted earnings per share as they are antidilutive.

[0001327567-25-000027:notes:242]
As a result of the conversions of the Notes during the years ended July 31, 2025, 2024, and 2023, we exercised the corresponding portion of our Note Hedges and received 14.0 million, 14.0 million, and 22.9 million shares of our common stock during the respective periods.

[0001327567-25-000027:notes:243]
Warrants

[0001327567-25-000027:notes:244]
Separately, but concurrently with the issuance of each series of our convertible senior notes, we entered into transactions whereby we sold warrants (the “2023 Warrants,” with respect to the 2023 Notes, the “2025 Warrants,” with respect to the 2025 Notes, and the 2023 Warrants together with the 2025 Warrants, the “Warrants”) to acquire shares of our common stock, subject to anti-dilution adjustments. The 2023 Warrants were, and the 2025 Warrants are, exercisable over 60 scheduled trading days beginning October 2023 and September 2025, respectively.

[0001327567-25-000027:notes:245]
The following table presents details of our Warrants (in millions, except per share data):

[0001327567-25-000027:notes:246]
|  | Initial Number of Shares |  | Strike Price per Share |  | Aggregate Proceeds |
| 2023 Warrants | 38.1 |  |  | $ | 69.63 |  |  | $ | 145.4 |  |
| 2025 Warrants | 40.3 |  |  | $ | 68.08 |  |  | $ | 202.8 |  |

[0001327567-25-000027:notes:247]
The shares issuable under the Warrants are included in the calculation of diluted earnings per share when the average market value per share of our common stock for the reporting period exceeds the applicable strike price for such series of Warrants. The Warrants are separate transactions and are not part of either series of Notes or Note Hedges and are not remeasured through earnings each reporting period. Holders of the Notes of either series do not have any rights with respect to the Warrants.

[0001327567-25-000027:notes:248]
During the year ended July 31, 2024, we net settled all of the 2023 Warrants with 18.0 million shares of our common stock with a fair value of $2.4 billion. The number of net shares issued was determined based on the number of 2023 Warrants exercised multiplied by the difference between the strike price of the 2023 Warrants and their daily volume-weighted-average stock price.

[0001327567-25-000027:notes:249]
Revolving Credit Facility

[0001327567-25-000027:notes:250]
On April 13, 2023, we entered into a credit agreement (the “Credit Agreement”) with certain institutional lenders that provides for a $400.0 million unsecured revolving credit facility (the “Credit Facility”), with an option to increase the amount of the Credit Facility by up to an additional $350.0 million, subject to certain conditions. The Credit Facility matures on April 13, 2028.

[0001327567-25-000027:notes:251]
The borrowings under the Credit Facility bear interest, at our option, at a base rate plus a spread of 0.000% to 0.375%, or an adjusted term Secured Overnight Financing Rate plus a spread of 1.000% to 1.375%, in each case with such spread being determined based on our leverage ratio. We are obligated to pay an ongoing commitment fee on undrawn amounts at a rate of 0.090% to 0.150%, depending on our leverage ratio. The interest rates and commitment fees are also subject to upward and downward adjustments based on our progress towards the achievement of certain sustainability goals.

[0001327567-25-000027:notes:252]
As of July 31, 2025, there were no amounts outstanding and we were in compliance with all covenants under the Credit Agreement.


## us-gaap:LesseeOperatingLeasesTextBlock

[0001327567-25-000027:notes:253]
Leases
We have entered into various non-cancelable operating leases, primarily for our offices and data centers, with lease terms expiring through the year ending July 31, 2036. Some of our leases contain rent holiday periods, scheduled rent increases, lease incentives, early termination rights, and/or renewal options.

[0001327567-25-000027:notes:254]
During the years ended July 31, 2025, 2024, and 2023, our net cost for operating leases was $121.7 million, $104.7 million, and $91.3 million, respectively, primarily consisting of operating lease costs of $88.1 million, $75.6 million, and $64.2 million, respectively. Our net cost for operating leases also included variable lease costs, short-term lease costs, and sublease income in the periods presented.

[0001327567-25-000027:notes:255]
The following tables present additional information for our operating leases (in millions, except for years and percentages):

[0001327567-25-000027:notes:256]
|  | Year Ended July 31, |  |  |  |  |  |  |
|  | 2025 |  | 2024 |  | 2023 |  |  |  |  |  |  |
| Operating cash flows used in payments of operating lease liabilities | $ | 91.2 |  |  | $ | 87.4 |  |  | $ | 82.7 |  |  |  |  |  |  |  |
| Right-of-use assets obtained in exchange for new operating lease liabilities | $ | 26.5 |  |  | $ | 177.9 |  |  | $ | 71.1 |  |  |  |  |  |  |  |

[0001327567-25-000027:notes:257]
|  | July 31, 2025 |  | July 31, 2024 |  |  |  |  |  |  |
| Weighted-average remaining lease term | 6.0 years |  | 6.6 years |  |  |  |  |  |  |
| Weighted-average discount rate | 5.4 | % |  | 5.3 | % |  |  |  |  |  |  |

[0001327567-25-000027:notes:258]
The following table presents maturities of operating lease liabilities as of July 31, 2025 (in millions):

[0001327567-25-000027:notes:259]
|  | Amount |
| Fiscal years ending July 31: |  |
| 2026 | $ | 99.4 |  |
| 2027 | 95.0 |  |
| 2028 | 94.3 |  |
| 2029 | 47.7 |  |
| 2030 | 45.2 |  |
| 2031 and thereafter | 112.3 |  |
| Total operating lease payments | 493.9 |  |
| Less: imputed interest | (76.5) |  |
| Present value of operating lease liabilities | $ | 417.4 |  |
| Current portion of operating lease liabilities(1) | $ | 79.2 |  |
| Long-term operating lease liabilities | $ | 338.2 |  |

[0001327567-25-000027:notes:260]
(1)Current portion of operating lease liabilities is included in accrued and other liabilities on our consolidated balance sheet.

[0001327567-25-000027:notes:261]
As of July 31, 2025, we had additional non-cancelable operating leases for office space that had been signed but had not yet commenced with total future minimum lease payments of $36.4 million. These leases are expected to commence on or after fiscal 2026, with lease terms ranging from four to seven years.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001327567-25-000027:notes:262]
Commitments and Contingencies
Purchase Commitments

[0001327567-25-000027:notes:263]
We have entered into various non-cancelable agreements with cloud hosting service providers, under which we are committed to minimum or fixed purchases of certain cloud hosting services. In addition, in order to reduce manufacturing lead times and plan for adequate supply, we have entered into agreements with manufacturing partners and component suppliers to procure inventory based on our demand forecasts. Other purchase obligations include non-cancellable subscription agreements and other commitments in the normal course of business. The following table presents details of the aggregate future non-cancelable purchase commitments under these agreements as of July 31, 2025 (in millions):

[0001327567-25-000027:notes:264]
|  |  |  | Fiscal years ending July 31, |
|  | Total |  | 2026 |  | 2027 |  | 2028 |  | 2029 |  | 2030 |  | 2031 and Thereafter |  |  |
| Cloud | $ | 6,580.5 |  |  | $ | 145.5 |  |  | $ | 774.1 |  |  | $ | 997.8 |  |  | $ | 1,017.5 |  |  | $ | 1,147.8 |  |  | $ | 2,497.8 |  |  |  |
| Manufacturing | 197.1 |  |  | 197.1 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  |  |
| Other | 187.3 |  |  | 112.9 |  |  | 60.7 |  |  | 6.8 |  |  | 3.4 |  |  | 3.5 |  |  | — |  |  |  |
| Total | $ | 6,964.9 |  |  | $ | 455.5 |  |  | $ | 834.8 |  |  | $ | 1,004.6 |  |  | $ | 1,020.9 |  |  | $ | 1,151.3 |  |  | $ | 2,497.8 |  |  |  |

[0001327567-25-000027:notes:265]
Additionally, we have a $119.0 million minimum purchase commitment with a cloud hosting service provider through September 2027 with no specified annual commitments.

[0001327567-25-000027:notes:266]
Mutual Covenant Not to Sue and Release Agreement

[0001327567-25-000027:notes:267]
In January 2020, we executed a Mutual Covenant Not to Sue and Release Agreement for $50.0 million to extend an existing covenant not to sue for seven years. As the primary benefit of the arrangement was attributable to future use, the amount was recorded in other assets on our consolidated balance sheets and is amortized to cost of product revenue on our consolidated statements of operations over the estimated period of benefit of seven years.

[0001327567-25-000027:notes:268]
Guarantee

[0001327567-25-000027:notes:269]
In October 2023, we established a multi-currency notional cash pool for a certain number of our entities with a third-party bank. As part of the notional cash pool agreement, the bank extends overdraft credit to our participating entities as needed, provided that the overall notionally pooled balance of all accounts in the pool at the end of each day is positive. In the unlikely event of a default, any overdraft balances incurred would be guaranteed by our collective entities participating in the pool.

[0001327567-25-000027:notes:270]
Litigation

[0001327567-25-000027:notes:271]
We are subject to legal proceedings, claims, tax matters, and litigation arising in the ordinary course of business, including, for instance, intellectual property and patent litigation. We accrue for contingencies when we believe that a loss is probable and that we can reasonably estimate the amount of any such loss.

[0001327567-25-000027:notes:272]
Legal matters could include speculative, substantial, or indeterminate monetary amounts. Significant judgment is required to determine both the likelihood of there being a loss and the estimated amount of a loss related to such matters, and we may be unable to estimate the reasonably possible loss or range of loss. The outcomes of outstanding legal matters are inherently unpredictable, and could, either individually or in aggregate, have a material adverse effect on us and our results of operations. To the extent there is a reasonable possibility that a loss exceeding any amounts already recognized may be incurred, we will either disclose the estimated additional loss or state that such an estimate cannot be made.

[0001327567-25-000027:notes:273]
The following matters arose in the ordinary course of business.

[0001327567-25-000027:notes:274]
Centripetal Networks, Inc. v. Palo Alto Networks

[0001327567-25-000027:notes:275]
On March 12, 2021, Centripetal Networks, Inc., filed a lawsuit against us in the United States District Court for the Eastern District of Virginia. The lawsuit alleges that our products infringe multiple Centripetal patents. We successfully challenged certain of these patents, which were found unpatentable by the U.S. Patent and Trademark Office (“PTO”). The case went to jury trial on January 22, 2024, on four patents. On January 31, 2024, the jury returned a verdict of non-willful infringement with a lump sum amount of $151.5 million, plus statutory interest. After post-trial motions, a judgment was issued on October 3, 2024 affirming infringement on three patents, reversing infringement on the fourth patent, and subsequently, reducing the damages amount to $113.6 million. We posted a surety bond that was agreed upon by the parties and approved by the court. This bond prevents execution of the judgment while appeals are pending. In addition, Centripetal filed infringement contentions on certain of their patents in the European Patent Office and Unified Patent Court in Germany, to which we filed appropriate legal challenges. Those matters are still pending.

[0001327567-25-000027:notes:276]
As of July 31, 2024, we accrued $184.4 million for the verdict amount and estimated interest. As of July 31, 2025, we accrued $145.6 million based on the judgment and estimated interest, which is recorded in other long-term liabilities on our consolidated balance sheets. The corresponding amount was a charge of $184.4 million for the year ended July 31, 2024, and a release of $38.8 million for the year ended July 31, 2025, which is included in general and administrative expense on our consolidated statements of operations.

[0001327567-25-000027:notes:277]
Finjan, Inc. v. Palo Alto Networks

[0001327567-25-000027:notes:278]
On November 4, 2014, Finjan, Inc., filed a lawsuit against us in the United States District Court for the Northern District of California. The lawsuit alleges that our products infringe multiple Finjan patents. The complaint requests injunctive relief, monetary damages, and attorneys’ fees. On March 21, 2025, the judge issued an order granting summary judgment of non-infringement on all remaining patents at issue. Plaintiff filed a Notice of Appeal on April 21, 2025. We are unable, at this time, to reasonably estimate a possible loss or potential range of loss, if any.

[0001327567-25-000027:notes:279]
Eire OG Innovations. v. Palo Alto Networks

[0001327567-25-000027:notes:280]
On April 3, 2024, Eire OG Innovations filed a lawsuit against us in the United States District Court for the Eastern District of Texas asserting infringement of multiple patents, certain of which were subsequently dismissed. The complaint requests monetary damages and attorneys’ fees. Trial is set for February 17, 2026. We are unable, at this time, to reasonably estimate a possible loss or potential range of loss, if any.

[0001327567-25-000027:notes:281]
Indemnification

[0001327567-25-000027:notes:282]
Under the indemnification provisions of our standard sales related contracts, we agree to defend our end-customers against third-party claims asserting infringement of certain intellectual property rights, which may include patents, copyrights, trademarks, or trade secrets, and to pay judgments or approved settlements attributable to such claims. Our exposure under these indemnification provisions is generally limited to payments made to us for the alleged infringing products over the preceding twelve months under the agreement. However, certain agreements include indemnification provisions that could potentially expose us to losses in excess of these payments. In addition, we indemnify our officers, directors, and certain key employees while they are serving in good faith in their company capacities. To date, we have not recorded any accruals for loss contingencies associated with indemnification claims or determined that an unfavorable outcome is probable or reasonably possible.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001327567-25-000027:notes:283]
Stockholders’ Equity
Share Repurchase Program

[0001327567-25-000027:notes:284]
In February 2019, our board of directors authorized a $1.0 billion share repurchase program, which is funded from available working capital. Our board of directors subsequently authorized additional increases to this share repurchase program, including $915.0 million in August 2022, $316.7 million in November 2023, and $500.0 million in August 2024, bringing the total authorization under this share repurchase program to $4.1 billion (our “current authorization”). The expiration date of our current authorization was extended to December 31, 2025, and our repurchase program may be suspended or discontinued at any time. Repurchases may be made at management’s discretion from time to time on the open market, through privately negotiated transactions, transactions structured through investment banking institutions, block purchase techniques, 10b5-1 trading plans, or a combination of the foregoing.

[0001327567-25-000027:notes:285]
The following table summarizes the share repurchase activity under our share repurchase program (in millions, except per share amounts):

[0001327567-25-000027:notes:286]
|  |  |  | Year Ended July 31, |
|  |  |  | 2024 |  | 2023 |
| Number of shares repurchased |  |  | 4.0 |  |  | 3.6 |  |
| Weighted-average price per share (1) |  |  | $ | 142.00 |  |  | $ | 69.32 |  |
| Aggregate purchase price (1) |  |  | $ | 566.7 |  |  | $ | 250.0 |  |

[0001327567-25-000027:notes:287]
(1)Includes transaction costs

[0001327567-25-000027:notes:288]
We did not repurchase shares of our common stock during the year ended July 31, 2025. During the year ended July 31, 2023, we paid $22.7 million related to share repurchases of our common stock that were not settled as of July 31, 2022.

[0001327567-25-000027:notes:289]
As of July 31, 2025, $1.0 billion remained available for future share repurchases under our current repurchase authorization. The total price of the shares repurchased and related transaction costs are reflected as a reduction to common stock and additional paid-in capital on our consolidated balance sheets.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001327567-25-000027:notes:290]
Equity Award Plans
Share-Based Compensation Plans

[0001327567-25-000027:notes:291]
Equity Incentive Plans

[0001327567-25-000027:notes:292]
Our 2021 Equity Incentive Plan (our “2021 Plan”) became effective in December 2021 and replaced our 2012 Equity Incentive Plan (our “2012 Plan”). Our 2021 Plan provides for the granting of stock options, stock appreciation rights, restricted stock awards (“RSAs”), restricted stock units (“RSUs”), performance shares (“PSAs”), performance-based stock units (“PSUs”) and performance stock options (“PSOs”) to our employees, directors, and consultants. Upon effectiveness of the 2021 Plan, the 2012 Plan was terminated and no further awards will be granted under the 2012 Plan. Awards that were outstanding upon such termination remained outstanding pursuant to their original terms, and any subsequent expiration, cancellation or forfeiture of awards under our 2012 Plan are returned to our 2021 Plan.

[0001327567-25-000027:notes:293]
The majority of our equity awards are RSUs, which generally vest over a period of four years from the date of grant. Until vested, RSUs do not have the voting and dividend participation rights of common stock and the shares underlying the awards are not considered issued and outstanding.

[0001327567-25-000027:notes:294]
Our PSUs generally vest over a period of one to four years from the date of grant. The number of PSUs eligible to vest is determined based on the level of achievement against certain performance conditions, market conditions, and a combination thereof.

[0001327567-25-000027:notes:295]
During the year ended July 31, 2023, we granted 1.8 million shares of PSUs with both service and market conditions. The market conditions are satisfied when the price of our common stock is equal to or exceeds stock price targets of $116.67, $133.34, $150.00, and $166.67 based on the average closing price for 30 consecutive trading days during the three- or four-year period following the date of grant. Once a market condition is met, its corresponding one-fourth of the awards vest on each anniversary date of the grant date, subject to continued service. As of July 31, 2025, all stock price targets for these PSU awards have been met, and the related shares will vest when the underlying service conditions are satisfied.

[0001327567-25-000027:notes:296]
During the year ended July 31, 2023, we granted 1.5 million shares of PSUs, which contain service and market conditions. The service conditions are satisfied after a period of five years. The market condition is measured based on our total shareholder return (“TSR”) relative to the TSR of the companies listed in the Standard & Poor’s 500 index.

[0001327567-25-000027:notes:297]
During the years ended July 31, 2025, 2024, and 2023, we granted 3.4 million, 4.2 million, and 3.2 million shares of PSUs, respectively, which contain service, performance and market conditions. The service conditions are satisfied over a period of one to three years. For PSUs granted during the year ended July 31, 2025, the performance conditions are based on an average of next-generation security annualized recurring revenue and non-GAAP net income per diluted share. For PSUs granted during the years ended July 31, 2024 and 2023, the performance conditions are based on revenue growth or billing growth. The market condition is measured based on our TSR relative to the TSR of the companies listed in the Standard & Poor’s 500 index. As of July 31, 2025, we have approved an additional 2.7 million shares of PSUs, which will be granted upon the performance condition being established during the next two years.

[0001327567-25-000027:notes:298]
We have also granted PSOs with both service and market conditions. The market condition for PSOs granted in the fiscal years 2018 and 2019 requires the price of our common stock to equal or exceed $49.63, $66.17, $82.71, and $99.25 based on the average closing price for 30 consecutive trading days during the four-, five-, six-, and seven-and-a-half-year periods following the date of grant in fiscal year 2018 and 2019, respectively. Once a market condition is met, its corresponding one-fourth of the PSOs vest on each anniversary date of the grant date, subject to continued service. The maximum contractual term of our outstanding PSOs is seven and a half years from the date of grant, depending on vesting period. As of July 31, 2025, all of our outstanding PSOs have been fully vested.

[0001327567-25-000027:notes:299]
We net-share settle equity awards held by certain employees by withholding shares upon vesting to satisfy tax withholding obligations. The shares withheld to satisfy employee tax withholding obligations are returned to our 2021 Plan and will be available for future issuance. Payments for employees’ tax obligations to the tax authorities are recognized as a reduction to additional paid-in capital and reflected as financing activities on our consolidated statements of cash flows.

[0001327567-25-000027:notes:300]
A total of 55.8 million shares of our common stock are reserved for issuance pursuant to our equity incentive plans as of July 31, 2025.

[0001327567-25-000027:notes:301]
2012 Employee Stock Purchase Plan

[0001327567-25-000027:notes:302]
Our 2012 Employee Stock Purchase Plan was adopted by our board of directors and approved by the stockholders on June 5, 2012, and was effective upon completion of our initial public offering. On August 29, 2017, we amended and restated our 2012 Employee Stock Purchase Plan (our “2012 ESPP”) to extend the length of our offering periods from 6 to 24 months.

[0001327567-25-000027:notes:303]
Our 2012 ESPP permits eligible employees to acquire shares of our common stock at 85% of the lower of the fair market value of our common stock on the first trading day of each offering period or on the purchase date. If the fair market value of our common stock on the purchase date is lower than the first trading day of the offering period, the current offering period will be cancelled after purchase and a new 24-month offering period will begin. Under our 2012 ESPP, each 24-month offering period consists of four consecutive 6-month purchase periods, with purchase dates on the first trading day on or after February 28 and August 31 of each year. Participants may purchase shares of common stock through payroll deductions of up to 15% of their eligible compensation, subject to purchase limits of 3,750 shares per six-month purchase period and $25,000 worth of stock for each calendar year. Shares purchased under our 2012 ESPP during the fiscal years ended July 31, 2025, 2024 and 2023 were 1.9 million, 2.2 million and 2.3 million, at an average exercise price of $106.99 per share, $80.32 per share, and $69.15 per share, respectively.

[0001327567-25-000027:notes:304]
A total of 41.5 million shares of our common stock are available for sale under our 2012 ESPP as of July 31, 2025. On the first day of each fiscal year, the number of shares in the reserve may be increased by the lesser of (i) 12.0 million shares, (ii) 1% of the outstanding shares of our common stock on the first day of the fiscal year, or (iii) such other amount as determined by our board of directors.

[0001327567-25-000027:notes:305]
Assumed Share-Based Compensation Plans

[0001327567-25-000027:notes:306]
In connection with our acquisitions, we have assumed equity incentive plans of certain acquired companies (collectively “the Assumed Plans”). The equity awards assumed in connection with each acquisition were granted from their respective assumed plans. The assumed equity awards will be settled in shares of our common stock and will retain the terms and conditions under which they were originally granted. No additional equity awards will be granted under and forfeited awards will not be returned to the Assumed Plans. Refer to Note 8. Acquisitions for more information on our acquisitions and the related equity awards assumed.

[0001327567-25-000027:notes:307]
Stock Option Activities

[0001327567-25-000027:notes:308]
The following table summarizes the stock option and PSO activity under our stock plans during the years ended July 31, 2025, 2024, and 2023 (in millions, except per share amounts):

[0001327567-25-000027:notes:309]
|  | Stock Options Outstanding |  | PSOs Outstanding |
|  | Number of Shares |  | Weighted-Average Exercise Price Per Share |  | Weighted-Average Remaining Contractual Term(Years) |  | Aggregate Intrinsic Value |  | Number of Shares |  | Weighted-Average Exercise Price Per Share |  | Weighted-Average Remaining Contractual Term(Years) |  | Aggregate Intrinsic Value |
| Balance—July 31, 2022 | 0.1 |  |  | $ | 9.23 |  |  | 0.5 |  | $ | 6.7 |  |  | 15.9 |  |  | $ | 32.42 |  |  | 3.2 |  | $ | 809.3 |  |
| Exercised | (0.1) |  |  | 9.23 |  |  |  |  |  |  | (3.1) |  |  | 31.70 |  |  |  |  |  |
| Balance—July 31, 2023 | — |  |  | $ | — |  |  | 0.0 |  | $ | — |  |  | 12.8 |  |  | $ | 32.60 |  |  | 2.2 |  | $ | 1,184.6 |  |
| Exercised | — |  |  | — |  |  |  |  |  |  | (3.2) |  |  | 32.42 |  |  |  |  |  |
| Balance—July 31, 2024 | — |  |  | $ | — |  |  | 0.0 |  | $ | — |  |  | 9.6 |  |  | $ | 32.66 |  |  | 1.2 |  | $ | 1,244.9 |  |
| Exercised(1) | — |  |  | — |  |  |  |  |  |  | (8.2) |  |  | 32.65 |  |  |  |  |  |
| Balance—July 31, 2025 | — |  |  | $ | — |  |  | 0.0 |  | $ | — |  |  | 1.4 |  |  | $ | 32.76 |  |  | 0.5 |  | $ | 197.0 |  |
| Exercisable—July 31, 2025 | — |  |  | $ | — |  |  | 0.0 |  | $ | — |  |  | 1.4 |  |  | $ | 32.76 |  |  | 0.5 |  | $ | 197.0 |  |

[0001327567-25-000027:notes:310]
(1)Includes 1.3 million shares withheld by us to satisfy the exercise price and tax withholding requirements.

[0001327567-25-000027:notes:311]
The intrinsic value of options exercised during the years ended July 31, 2025, 2024, and 2023 was $1.2 billion, $358.5 million, and $237.7 million, respectively.

[0001327567-25-000027:notes:312]
RSU and PSU Activities

[0001327567-25-000027:notes:313]
The following table summarizes the RSU and PSU activity under our stock plans during the years ended July 31, 2025, 2024, and 2023 (in millions, except per share amounts):

[0001327567-25-000027:notes:314]
|  | Unvested RSUs |  | Unvested PSUs |
|  | Number of Shares |  | Weighted-Average Grant-Date Fair Value Per Share |  |  |  | Aggregate Intrinsic Value |  | Number of Shares |  | Weighted-Average Grant-Date Fair Value Per Share |  |  |  | Aggregate Intrinsic Value |
| Balance—July 31, 2022 | 29.5 |  |  | $ | 57.75 |  |  |  |  | $ | 2,456.9 |  |  | 6.2 |  |  | $ | 53.19 |  |  |  |  | $ | 513.7 |  |
| Granted(1) | 11.5 |  |  | 84.52 |  |  |  |  |  |  | 7.1 |  |  | 71.44 |  |  |  |  |  |
| Vested(2) | (13.9) |  |  | 55.47 |  |  |  |  |  |  | (2.6) |  |  | 56.36 |  |  |  |  |  |
| Forfeited | (3.0) |  |  | 64.03 |  |  |  |  |  |  | (0.8) |  |  | 68.48 |  |  |  |  |  |
| Balance—July 31, 2023 | 24.1 |  |  | $ | 71.30 |  |  |  |  | $ | 3,013.0 |  |  | 9.9 |  |  | $ | 64.32 |  |  |  |  | $ | 1,242.3 |  |
| Granted(1) | 8.5 |  |  | 137.76 |  |  |  |  |  |  | 4.3 |  |  | 91.39 |  |  |  |  |  |
| Vested(2) | (11.8) |  |  | 68.63 |  |  |  |  |  |  | (3.2) |  |  | 57.28 |  |  |  |  |  |
| Forfeited | (2.8) |  |  | 84.12 |  |  |  |  |  |  | (1.0) |  |  | 68.54 |  |  |  |  |  |
| Balance—July 31, 2024 | 18.0 |  |  | $ | 102.59 |  |  |  |  | $ | 2,924.4 |  |  | 10.0 |  |  | $ | 77.95 |  |  |  |  | $ | 1,624.2 |  |
| Granted(1) | 6.0 |  |  | 189.45 |  |  |  |  |  |  | 3.8 |  |  | 201.59 |  |  |  |  |  |
| Vested(2) | (8.6) |  |  | 97.00 |  |  |  |  |  |  | (1.2) |  |  | 64.65 |  |  |  |  |  |
| Forfeited | (2.2) |  |  | 115.94 |  |  |  |  |  |  | (3.2) |  |  | 92.11 |  |  |  |  |  |
| Balance—July 31, 2025 | 13.2 |  |  | $ | 143.33 |  |  |  |  | $ | 2,284.7 |  |  | 9.4 |  |  | $ | 140.92 |  |  |  |  | $ | 1,635.4 |  |

[0001327567-25-000027:notes:315]
(1)For PSUs, shares granted represent the aggregate maximum number of shares that may be earned and issued with respect to these awards over their full terms.

[0001327567-25-000027:notes:316]
(2)Includes time-based vesting for PSUs.

[0001327567-25-000027:notes:317]
The aggregate fair value, as of the respective vesting dates, of RSUs vested during the years ended July 31, 2025, 2024, and 2023 was $1.6 billion, $1.6 billion, and $1.3 billion, respectively. The aggregate fair value, as of the respective vesting dates, of PSUs vested during the years ended July 31, 2025, 2024, and 2023 was $220.7 million, $377.7 million, and $218.9 million, respectively.

[0001327567-25-000027:notes:318]
Shares Available for Grant

[0001327567-25-000027:notes:319]
The following table presents the stock activity and the total number of shares available for grant under our equity incentive plans as of July 31, 2025 (in millions):

[0001327567-25-000027:notes:320]
|  | Number of shares |
| Balance—July 31, 2024 | 26.2 |  |
| Authorized | 6.0 |  |
| RSUs and PSUs granted | (9.8) |  |
| RSUs and PSUs forfeited | 5.5 |  |
| Shares withheld for taxes | 1.4 |  |
| Balance—July 31, 2025 | 29.3 |  |

[0001327567-25-000027:notes:321]
We record share-based compensation awards based on estimated fair value as of the grant date. The fair value of RSUs and PSUs not subject to market conditions is based on the closing market price of our common stock on the date of grant.

[0001327567-25-000027:notes:322]
The fair value of the PSUs subject to market conditions is estimated on the grant date using a Monte Carlo simulation model. The following table summarizes the assumptions used and the resulting grant-date fair value of our PSUs subject to market conditions granted during the years ended July 31, 2025, 2024, and 2023:

[0001327567-25-000027:notes:323]
|  | Year Ended July 31, |
|  | 2025 |  | 2024 |  | 2023 |
| Volatility | 43.5% - 47.6% |  | 40.8% - 43.4% |  | 38.3% - 44.8% |
| Expected term (in years) | 1.0 - 2.9 |  | 0.9 - 2.9 |  | 1.0 - 5.0 |
| Dividend yield | — | % |  | — | % |  | — | % |
| Risk-free interest rate | 3.7% - 4.5% |  | 4.4% - 5.3% |  | 3.2% - 4.1% |
| Grant-date fair value per share | $264.51 - $305.83 |  | $173.46 - $310.61 |  | $45.89 - $140.21 |

[0001327567-25-000027:notes:324]
The expected volatility is based on the historical volatility of our common stock. The expected term is based on the length of each tranche’s performance period from the grant date. The dividend yield assumption is based on our current expectations about our anticipated dividend policy. The risk-free interest rate is based on the implied yield available on U.S. Treasury zero-coupon issues with maturities that approximate the expected term.

[0001327567-25-000027:notes:325]
The fair value of PSOs was estimated on the grant date using a Monte Carlo simulation model, which predicts settlement of the PSOs midway between the vesting term and the contractual term. No PSOs were granted during the years ended July 31, 2025, 2024, and 2023.

[0001327567-25-000027:notes:326]
The fair value of shares issued under our 2012 ESPP are estimated on the grant date using the Black-Scholes option pricing model. The following table summarizes the assumptions used and the resulting grant-date fair values of our ESPP:

[0001327567-25-000027:notes:327]
|  | Year Ended July 31, |
|  | 2025 |  | 2024 |  | 2023 |
| Volatility | 34.3% - 43.3% |  | 39.6% - 50.0% |  | 38.6% - 44.7% |
| Expected term (in years) | 0.5 - 2.0 |  | 0.5 - 2.0 |  | 0.5 - 2.0 |
| Dividend yield | — | % |  | — | % |  | — | % |
| Risk-free interest rate | 3.9% - 4.8% |  | 4.6% - 5.5% |  | 3.3% - 5.2% |
| Grant-date fair value per share | $45.43 - $74.81 |  | $32.81 - $66.66 |  | $24.39 - $37.03 |

[0001327567-25-000027:notes:328]
The expected volatility is based on a combination of implied volatility from traded options on our common stock and the historical volatility of our common stock. The expected term represents the term from the first day of the offering period to the purchase dates within each offering period. The dividend yield assumption is based on our current expectations about our anticipated dividend policy. The risk-free interest rate is based on the implied yield available on U.S. Treasury zero-coupon issues with maturities that approximate the expected term.

[0001327567-25-000027:notes:329]
The following table summarizes share-based compensation included in costs and expenses (in millions):

[0001327567-25-000027:notes:330]
|  | Year Ended July 31, |
|  | 2025 |  | 2024 |  | 2023 |
| Cost of product revenue | $ | 5.1 |  |  | $ | 7.3 |  |  | $ | 9.8 |  |
| Cost of subscription and support revenue | 127.0 |  |  | 121.0 |  |  | 123.4 |  |
| Research and development | 550.5 |  |  | 525.5 |  |  | 488.4 |  |
| Sales and marketing | 359.5 |  |  | 300.8 |  |  | 335.3 |  |
| General and administrative | 258.0 |  |  | 124.1 |  |  | 130.4 |  |
| Total share-based compensation | $ | 1,300.1 |  |  | $ | 1,078.7 |  |  | $ | 1,087.3 |  |

[0001327567-25-000027:notes:331]
As of July 31, 2025, total compensation cost related to unvested share-based awards not yet recognized was $2.2 billion. This cost is expected to be amortized over a weighted-average period of approximately 2.5 years. Future grants will increase the amount of compensation expense to be recorded in these periods.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001327567-25-000027:notes:332]
Income Taxes
The following table presents the components of income before income taxes (in millions):

[0001327567-25-000027:notes:333]
|  | Year Ended July 31, |
|  | 2025 |  | 2024 |  | 2023 |
| United States | $ | 1,124.9 |  |  | $ | 669.2 |  |  | $ | 374.3 |  |
| Foreign | 470.8 |  |  | 319.1 |  |  | 192.0 |  |
| Total | $ | 1,595.7 |  |  | $ | 988.3 |  |  | $ | 566.3 |  |

[0001327567-25-000027:notes:334]
The following table summarizes our provision for (benefit from) income taxes (in millions):

[0001327567-25-000027:notes:335]
|  | Year Ended July 31, |
|  | 2025 |  | 2024 |  | 2023 |
| Federal: |  |  |  |  |  |
| Current | $ | 517.3 |  |  | $ | 213.4 |  |  | $ | 26.1 |  |
| Deferred | (300.2) |  |  | 311.7 |  |  | 19.3 |  |
| State: |  |  |  |  |  |
| Current | 108.2 |  |  | 101.5 |  |  | 44.0 |  |
| Deferred | (44.5) |  |  | (172.8) |  |  | 0.4 |  |
| Foreign: |  |  |  |  |  |
| Current | 186.0 |  |  | 129.6 |  |  | 44.0 |  |
| Deferred | (5.0) |  |  | (2,172.7) |  |  | (7.2) |  |
| Total | $ | 461.8 |  |  | $ | (1,589.3) |  |  | $ | 126.6 |  |

[0001327567-25-000027:notes:336]
For the year ended July 31, 2025, our provision for income taxes was $461.8 million, which included a deferred tax provision of $218.5 million arising from the remeasurement of our basis difference associated with the U.S. tax effects of foreign deferred tax assets. Our remeasurement is a result of the One Big Beautiful Bill Act ("OBBB") enacted on July 4, 2025 which provides for significant tax law changes and modifications including changes to the U.S. effective tax rates on certain foreign earnings. Although these specific provisions are not effective until our fiscal 2027, our policy to account for basis differences relating to our global intangible low-taxed income requires us to account for these changes in the period of enactment.

[0001327567-25-000027:notes:337]
For the year ended July 31, 2024, our benefit from income taxes was $1.6 billion, primarily due to the release of our valuation allowance on U.S. federal, U.S. states other than California, and United Kingdom (“U.K.”) deferred tax assets, partially offset by the deferred tax provision in our U.S. federal tax provision to recognize the indirect effect on basis differences relating to our global intangible low-taxed income in connection with the release of our valuation allowance in the U.K.

[0001327567-25-000027:notes:338]
The following table presents the items accounting for the difference between income taxes computed at the federal statutory income tax rate and our provision for (benefit from) income taxes:

[0001327567-25-000027:notes:339]
|  | Year Ended July 31, |
|  | 2025 |  | 2024 |  | 2023 |
| Federal statutory rate | 21.0 | % |  | 21.0 | % |  | 21.0 | % |
| Effect of: |  |  |  |  |  |
| State taxes, net of federal tax benefit | 3.8 |  |  | 3.1 |  |  | 2.8 |  |
| Non-U.S. operations | 2.2 |  |  | 9.5 |  |  | 9.7 |  |
| Change in valuation allowance | 1.1 |  |  | (341.9) |  |  | 15.5 |  |
| U.S. effect of foreign deferred tax assets | 11.2 |  |  | 175.8 |  |  | — |  |
| Share-based compensation | (5.5) |  |  | (16.9) |  |  | (12.6) |  |
| Tax credits | (6.2) |  |  | (13.4) |  |  | (15.6) |  |
| Non-deductible expenses | 1.2 |  |  | 1.5 |  |  | 2.3 |  |
| Other, net | 0.1 |  |  | 0.5 |  |  | (0.7) |  |
| Total | 28.9 | % |  | (160.8) | % |  | 22.4 | % |

[0001327567-25-000027:notes:340]
The following table presents the components of our deferred tax assets and liabilities as of July 31, 2025 and 2024 (in millions):

[0001327567-25-000027:notes:341]
|  | July 31, |
|  | 2025 |  | 2024 |
| Deferred tax assets: |  |  |  |
| Accruals and reserves | $ | 132.1 |  |  | $ | 109.7 |  |
| Operating lease liabilities | 126.5 |  |  | 132.6 |  |
| Deferred revenue | 1,266.1 |  |  | 1,004.9 |  |
| Net operating loss carryforwards | 620.0 |  |  | 585.2 |  |
| Tax credits | 222.3 |  |  | 175.3 |  |
| Capitalized research expenditures | 895.4 |  |  | 626.6 |  |
| Share-based compensation | 105.6 |  |  | 75.6 |  |
| Fixed assets and intangible assets | 1,561.4 |  |  | 1,631.7 |  |
| Gross deferred tax assets | 4,929.4 |  |  | 4,341.6 |  |
| Valuation allowance | (278.1) |  |  | (243.4) |  |
| Total deferred tax assets | 4,651.3 |  |  | 4,098.2 |  |
| Deferred tax liabilities: |  |  |  |
| U.S. effect of foreign deferred tax assets | (1,921.6) |  |  | (1,728.5) |  |
| Operating lease right-of-use assets | (108.2) |  |  | (115.8) |  |
| Deferred contract costs | (212.5) |  |  | (199.1) |  |
| Other deferred tax liabilities | (74.1) |  |  | (43.5) |  |
| Total deferred tax liabilities | (2,316.4) |  |  | (2,086.9) |  |
| Net deferred tax assets (liabilities) | $ | 2,334.9 |  |  | $ | 2,011.3 |  |

[0001327567-25-000027:notes:342]
We regularly assess the need for a valuation allowance on our deferred tax assets. In making this assessment, we consider both positive and negative evidence related to the likelihood of realization of the deferred tax assets to determine, based on the weight of available evidence, whether it is more likely than not that some or all the deferred tax assets will not be realized. The assessment requires significant judgment and is performed for each of the applicable jurisdictions. Based on our analysis of all positive and negative evidence during the year ended July 31, 2025, we continue to maintain a valuation allowance for our California deferred tax assets due to the uncertainty regarding realizability of these deferred tax assets as they have not met the “more likely than not” realization criterion. We expect future research and development tax credit generation in California to exceed our ability to use the existing tax credits.

[0001327567-25-000027:notes:343]
Our U.S. federal and state deferred tax assets largely consist of capitalized research expenditures and accelerated recognition of deferred revenue for tax purposes. U.S. tax carryforwards (including net operating losses and tax credits) are expected to be fully utilized to the extent allowable by law. Our U.K. deferred tax assets largely consist of basis differences in intangible assets and related net operating losses expected to be utilized in the future.

[0001327567-25-000027:notes:344]
As of July 31, 2025, we had federal, state, and foreign net operating loss carryforwards of approximately $129.1 million, $112.8 million, and $2.3 billion, respectively, as reported on our tax returns, available to reduce future taxable income, if any. If not utilized, our federal and state net operating loss carryforwards will expire in various amounts at various dates beginning in the years ending July 31, 2034 and July 31, 2030, respectively. Our foreign net operating loss will carry forward indefinitely.

[0001327567-25-000027:notes:345]
As of July 31, 2025, we had federal and state research and development tax credit carryforwards of approximately $2.0 million and $340.2 million, respectively, as reported on our tax returns. If not utilized, the federal credit carryforwards will expire in various amounts at various dates beginning in the year ending July 31, 2040. The state credit carryforwards have no expiration.

[0001327567-25-000027:notes:346]
As of July 31, 2025, we had foreign tax credit carryforwards of $1.7 million as reported on our tax returns. If not utilized, the foreign tax credit carryforwards will expire in various amounts at various dates beginning in the year ending July 31, 2029.

[0001327567-25-000027:notes:347]
Utilization of the net operating loss carryforwards and credits may be subject to a substantial annual limitation due to the ownership change limitations provided by the Internal Revenue Code of 1986, as amended, and similar state provisions. The annual limitation may result in the expiration of net operating losses and credits before utilization.

[0001327567-25-000027:notes:348]
As of July 31, 2025, we had $572.2 million of unrecognized tax benefits, $274.8 million of which would affect income tax expense if recognized, after consideration of our valuation allowance in California and other assets. As of July 31, 2024, we had $454.4 million of unrecognized tax benefits, $200.1 million of which would affect income tax expense if recognized, after consideration of our valuation allowance in the United States and other assets. We do not expect the amount of unrecognized tax benefits as of July 31, 2025 to materially change over the next 12 months.

[0001327567-25-000027:notes:349]
We file federal, state, and foreign income tax returns in jurisdictions with varying statutes of limitations. Generally, all years remain subject to adjustment due to our net operating loss and credit carryforwards. We currently have ongoing tax audits in various jurisdictions and at various times. The primary focus of these audits is, generally, profit allocation. The ultimate amount and timing of any future settlements cannot be predicted with reasonable certainty.

[0001327567-25-000027:notes:350]
We recognize both interest and penalties associated with uncertain tax positions as a component of income tax expense. During the years ended July 31, 2025, 2024, and 2023, we recognized an income tax expense of $42.4 million, an income tax expense of $5.8 million, and a net income tax benefit of $4.8 million related to interest and penalties, respectively. We had accrued interest and penalties on our consolidated balance sheets related to unrecognized tax benefits of $53.3 million and $10.9 million as of July 31, 2025 and 2024, respectively.

[0001327567-25-000027:notes:351]
The following table presents a reconciliation of the beginning and ending amount of our gross unrecognized tax benefits (in millions):

[0001327567-25-000027:notes:352]
|  | Year Ended July 31, |
|  | 2025 |  | 2024 |  | 2023 |
| Unrecognized tax benefits at the beginning of the period | $ | 454.4 |  |  | $ | 360.0 |  |  | $ | 414.0 |  |
| Additions for tax positions taken in prior years | 10.4 |  |  | 1.9 |  |  | 7.8 |  |
| Reductions for tax positions taken in prior years | (11.1) |  |  | (19.8) |  |  | (99.8) |  |
| Additions for tax positions taken in the current year | 118.5 |  |  | 112.3 |  |  | 66.9 |  |
| Reduction relating to audit settlement | — |  |  | — |  |  | (28.9) |  |
| Unrecognized tax benefits at the end of the period | $ | 572.2 |  |  | $ | 454.4 |  |  | $ | 360.0 |  |

[0001327567-25-000027:notes:353]
During the years ended July 31, 2025 and 2024, increases in uncertain tax positions were primarily due to our credits and incentives and intercompany transactions.

[0001327567-25-000027:notes:354]
As of July 31, 2025, we had no unremitted earnings when evaluating our outside basis difference relating to our U.S. investment in foreign subsidiaries. However, there could be local withholding taxes due to various foreign countries if certain lower tier earnings are distributed. Withholding taxes that would be payable upon remittance of these lower tier earnings are not material.


## us-gaap:EarningsPerShareTextBlock

[0001327567-25-000027:notes:355]
Net Income Per Share
Basic net income per share is computed by dividing net income by basic weighted-average shares outstanding during the period. Diluted net income per share is computed by dividing net income by diluted weighted-average shares outstanding during the period giving effect to all potentially dilutive securities to the extent they are dilutive. We compute the dilutive effect of shares issuable upon conversion of our convertible senior notes using the if-converted method, and the dilutive effect of warrants related to the issuance of convertible senior notes and equity awards under our employee equity incentive plans using the treasury stock method.

[0001327567-25-000027:notes:356]
The following table presents the computation of basic and diluted net income per share of common stock (in millions, except per share data):

[0001327567-25-000027:notes:357]
|  | Year Ended July 31, |
|  | 2025 |  | 2024 |  | 2023 |
| Net income | $ | 1,133.9 |  |  | $ | 2,577.6 |  |  | $ | 439.7 |  |
| Weighted-average shares used to compute net income per share, basic | 662.5 |  |  | 638.5 |  |  | 606.4 |
| Weighted-average effect of potentially dilutive securities: |  |  |  |  |  |
| Convertible senior notes | 7.3 |  |  | 20.7 |  |  | 35.7 |  |
| Warrants related to the issuance of convertible senior notes | 25.4 |  |  | 25.6 |  |  | 18.6 |  |
| Employee equity incentive plans | 14.1 |  |  | 23.1 |  |  | 23.8 |  |
| Weighted-average shares used to compute net income per share, diluted | 709.3 |  |  | 707.9 |  |  | 684.5 |
| Net income per share, basic | $ | 1.71 |  |  | $ | 4.04 |  |  | $ | 0.73 |  |
| Net income per share, diluted | $ | 1.60 |  |  | $ | 3.64 |  |  | $ | 0.64 |  |

[0001327567-25-000027:notes:358]
The following securities were excluded from the computation of diluted net income per share of common stock as their effect would have been antidilutive or issuance of such shares is contingent upon the satisfaction of certain conditions which were not satisfied by the end of the applicable period (in millions):

[0001327567-25-000027:notes:359]
|  | Year Ended July 31, |
|  | 2025 |  | 2024 |  | 2023 |
| Employee equity incentive plans | 3.4 |  |  | 4.7 |  |  | 7.7 |  |


## us-gaap:OtherNonoperatingIncomeAndExpenseTextBlock

[0001327567-25-000027:notes:360]
Other Income, Net
The following table sets forth the components of other income, net (in millions):

[0001327567-25-000027:notes:361]
|  | Year Ended July 31, |
|  | 2025 |  | 2024 |  | 2023 |
| Interest income | $ | 363.5 |  |  | $ | 317.9 |  |  | $ | 224.4 |  |
| Foreign currency exchange gains (losses), net | (32.8) |  |  | 0.2 |  |  | (7.9) |  |
| Other, net | 25.1 |  |  | (5.4) |  |  | (10.3) |  |
| Total other income, net | $ | 355.8 |  |  | $ | 312.7 |  |  | $ | 206.2 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001327567-25-000027:notes:362]
Segment Information
We have one operating and reportable segment. We conduct business globally and sales are primarily managed on a geographic theater basis. Our chief operating decision maker (“CODM”) is our Chairman and Chief Executive Officer who reviews financial information presented on a consolidated basis accompanied by revenue information for purposes of allocating resources and evaluating financial performance. Our CODM uses consolidated net income as our measure of segment profit or loss. The consolidated financial information by function as reflected on our consolidated statements of operations is used in our annual budget and forecasting process to establish goals and monitor budget versus actual results. The measure of segment assets is reported on the consolidated balance sheets as total consolidated assets.

[0001327567-25-000027:notes:363]
The following table presents our long-lived assets, which consist of property and equipment, net and operating lease right-of-use assets, by geographic area (in millions):

[0001327567-25-000027:notes:364]
|  | Year Ended July 31, |
|  | 2025 |  | 2024 |
| Long-lived assets: |  |  |  |
| United States | $ | 418.0 |  |  | $ | 438.9 |  |
| Israel | 162.1 |  |  | 141.1 |  |
| Other countries | 154.2 |  |  | 167.0 |  |
| Total long-lived assets | $ | 734.3 |  |  | $ | 747.0 |  |

[0001327567-25-000027:notes:365]
Refer to Note 2. Revenue for revenue by geographic theater and revenue for groups of similar products and services for the years ended July 31, 2025, 2024, and 2023.


## ecd:MtrlTermsOfTrdArrTextBlock

[0001327567-25-000027:notes:366]
The Rule 10b5-1 trading plans listed below are each intended to satisfy the affirmative defense of Rule 10b5-1(c).

[0001327567-25-000027:notes:367]
| Name |  | Title |  | Date Plan Was Adopted |  | Date Plan Was Terminated |  | Original Expiration Date |  | Total Amount of Common Stock to Be Sold Under the Plan |
| Nikesh Arora |  | Chief Executive Officer |  | June 24, 2025 |  | Not applicable |  | December 24, 2025 or when all shares have been sold |  | 846,408 |
