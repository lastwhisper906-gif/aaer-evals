# PANW notes — 0001327567-18-000024


## panw:ContractManufacturerLiabilitiesPolicyTextBlockPolicyTextBlock

[0001327567-18-000024:notes:1]
Manufacturing Partner and Supplier Liabilities

[0001327567-18-000024:notes:2]
We outsource most of our manufacturing, repair, and supply chain management operations to our EMS provider and payments to it are a significant portion of our cost of product revenue. Although we could be contractually obligated to purchase manufactured products and components, we generally do not own the manufactured products and components. Product title transfers from our EMS provider to us and immediately to our channel partners upon shipment. Our EMS provider assembles our products using design specifications, quality assurance programs, and standards that we establish and it procures components and assembles our products based on our demand forecasts. These forecasts represent our estimates of future demand for our products based upon historical trends and analysis from our sales and product management functions as adjusted for overall market conditions. If the actual component usage and product demand are significantly lower than forecast, we record a liability for manufacturing purchase commitments in excess of our forecasted demand including costs for excess components or for carrying costs incurred by our manufacturing partners and component suppliers. Through July 31, 2018, we have not accrued any significant costs associated with this exposure.


## panw:ConvertibleDebtOtherDetailsTableTextBlock

[0001327567-18-000024:notes:3]
The following table presents details of the Notes (number of shares in millions):

[0001327567-18-000024:notes:4]
|  | Conversion Rate per $1,000 Principal |  | Initial Conversion Price |  | Convertible Date |  | Number of Shares |
| 2019 Notes | 9.0680 |  |  | $ | 110.28 |  |  | January 1, 2019 |  | 5.2 |  |
| 2023 Notes | 3.7545 |  |  | $ | 266.35 |  |  | April 1, 2023 |  | 6.4 |  |


## panw:ScheduleofNoteHedgeTransactionsTableTextBlock

[0001327567-18-000024:notes:5]
The following table presents details of the Note Hedges (in millions):

[0001327567-18-000024:notes:6]
|  | Shares |  | Aggregate Purchase |
| 2019 Note Hedges | 5.2 |  |  | $ | 111.0 |  |
| 2023 Note Hedges | 6.4 |  |  | $ | 332.0 |  |


## panw:ScheduleofSharebasedCompensationSharesAvailableforGrantTableTextBlock

[0001327567-18-000024:notes:7]
The following table presents the stock activity and the total number of shares available for grant under our stock plans as of July 31, 2018 (in millions):

[0001327567-18-000024:notes:8]
|  | Number of shares |
| Balance—July 31, 2017 | 8.8 |  |
| Authorized | 4.1 |  |
| Options, RSUs, and PSUs granted | (5.3 | ) |
| RSAs, PSAs, and RSUs forfeited | 0.8 |  |
| Shares withheld for taxes | 0.4 |  |
| Balance—July 31, 2018 | 8.8 |  |


## us-gaap:AvailableForSaleSecuritiesTextBlock

[0001327567-18-000024:notes:9]
The following tables summarize the amortized cost, unrealized gains and losses, and fair value of our available-for-sale securities as of July 31, 2018 and July 31, 2017 (in millions):

[0001327567-18-000024:notes:10]
|  | July 31, 2018 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Estimated Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Money market funds | $ | 1,512.3 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,512.3 |  |
| Commercial paper | 52.0 |  |  | — |  |  | — |  |  | 52.0 |  |
| U.S. government and agency securities | 397.3 |  |  | — |  |  | — |  |  | 397.3 |  |
| Total cash equivalents | $ | 1,961.6 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,961.6 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 5.4 |  |  | $ | — |  |  | $ | — |  |  | $ | 5.4 |  |
| Non-U.S. government securities | 20.0 |  |  | — |  |  | — |  |  | 20.0 |  |
| Commercial paper | 22.3 |  |  | — |  |  | — |  |  | 22.3 |  |
| Corporate debt securities | 295.9 |  |  | — |  |  | (2.5 | ) |  | 293.4 |  |
| U.S. government and agency securities | 1,110.6 |  |  | — |  |  | (7.7 | ) |  | 1,102.9 |  |
| Total investments | $ | 1,454.2 |  |  | $ | — |  |  | $ | (10.2 | ) |  | $ | 1,444.0 |  |

[0001327567-18-000024:notes:11]
|  | July 31, 2017 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Estimated Fair Value |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 5.4 |  |  | $ | — |  |  | $ | — |  |  | $ | 5.4 |  |
| Corporate debt securities | 346.1 |  |  | 0.3 |  |  | (0.5 | ) |  | 345.9 |  |
| U.S. government and agency securities | 1,071.2 |  |  | 0.1 |  |  | (2.6 | ) |  | 1,068.7 |  |
| Total investments | $ | 1,422.7 |  |  | $ | 0.4 |  |  | $ | (3.1 | ) |  | $ | 1,420.0 |  |


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001327567-18-000024:notes:12]
Basis of Presentation

[0001327567-18-000024:notes:13]
The accompanying consolidated financial statements have been prepared in conformity with U.S. generally accepted accounting principles (“GAAP”). The consolidated financial statements include all adjustments necessary for a fair presentation of our annual results. All adjustments are of a normal recurring nature. Certain prior-period amounts have been reclassified to conform to current-period presentation.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001327567-18-000024:notes:14]
Acquisitions

[0001327567-18-000024:notes:15]
Fiscal 2018

[0001327567-18-000024:notes:16]
Evident.io, Inc.

[0001327567-18-000024:notes:17]
On March 26, 2018, we completed our acquisition of all outstanding shares of Evident.io, Inc. (“Evident.io”), a privately-held cloud security company. The acquisition expands our API-based security capabilities for the public cloud with the addition of Evident.io’s cloud services infrastructure protection technology. Total purchase consideration for the acquisition of Evident.io was $292.9 million in cash, of which $4.0 million was accrued and was paid over a period of five months from the acquisition date.

[0001327567-18-000024:notes:18]
We have accounted for this transaction as a business combination and allocated the purchase consideration to assets acquired and liabilities assumed based on preliminary estimated fair values, as presented in the following table (in millions):

[0001327567-18-000024:notes:19]
|  | Amount |
| Goodwill | $ | 209.8 |  |
| Identified intangible assets | 85.1 |  |
| Net liabilities assumed | (2.0 | ) |
| Total | $ | 292.9 |  |

[0001327567-18-000024:notes:20]
Goodwill generated from this business combination is primarily attributable to the assembled workforce and expected post-acquisition synergies from integrating Evident.io’s technology into our platform and sales opportunities of Evident.io’s software as a service (“SaaS”) offerings. The goodwill is not deductible for income tax purposes.

[0001327567-18-000024:notes:21]
The following table presents details of the identified intangible assets acquired (in millions, except years):

[0001327567-18-000024:notes:22]
|  | Fair Value |  | Estimated Useful Life |
| Developed technology | $ | 68.4 |  |  | 6 years |
| Trade name and trademarks | 8.5 |  |  | 8 years |
| Customer relationships | 8.2 |  |  | 8 years |
| Total | $ | 85.1 |  |  |  |

[0001327567-18-000024:notes:23]
In addition, we paid $6.6 million in cash to settle certain Evident.io stock options, for which vesting was accelerated in connection with the acquisition and the subsequent termination of the option holders’ services. This amount was recorded as post-acquisition share-based compensation included in general and administrative expenses in our consolidated statements of operations.

[0001327567-18-000024:notes:24]
Cyber Secdo Ltd.

[0001327567-18-000024:notes:25]
On April 24, 2018, we completed our acquisition of all outstanding shares of Cyber Secdo Ltd. (“Secdo”), a privately-held company specializing in endpoint detection and response (“EDR”). The acquisition expands the functionality of our platform by adding EDR capabilities. Total purchase consideration for the acquisition of Secdo was $82.7 million in cash.

[0001327567-18-000024:notes:26]
|  | Amount |
| Goodwill | $ | 68.6 |  |
| Identified intangible assets | 17.3 |  |
| Net liabilities assumed | (3.2 | ) |
| Total | $ | 82.7 |  |

[0001327567-18-000024:notes:27]
Goodwill generated from this business combination is primarily attributable to the assembled workforce and expected post-acquisition synergies from integrating Secdo’s technology into our advanced endpoint protection offering and our platform. The goodwill is not deductible for income tax purposes.

[0001327567-18-000024:notes:28]
|  | Fair Value |  | Estimated Useful Life |
| Developed technology | $ | 16.4 |  |  | 5 years |
| Customer relationships | 0.9 |  |  | 2 years |
| Total | $ | 17.3 |  |  |  |

[0001327567-18-000024:notes:29]
Fiscal 2017

[0001327567-18-000024:notes:30]
LightCyber Ltd.

[0001327567-18-000024:notes:31]
On February 27, 2017, we completed our acquisition of all outstanding shares of LightCyber Ltd. (“LightCyber”), a privately-held cybersecurity company, for total consideration of $103.1 million in cash. The acquisition expands the functionality of our platform with the addition of LightCyber’s behavioral analytics technology.

[0001327567-18-000024:notes:32]
We have accounted for this transaction as a business combination and allocated the purchase consideration to assets acquired and liabilities assumed based on their estimated fair values, as presented in the following table (in millions):

[0001327567-18-000024:notes:33]
|  | Amount |
| Cash | $ | 12.4 |  |
| Goodwill | 75.3 |  |
| Identified intangible assets | 19.5 |  |
| Net liabilities assumed | (4.1 | ) |
| Total | $ | 103.1 |  |

[0001327567-18-000024:notes:34]
|  | Fair Value |  | Estimated Useful Life |
| Developed technology | $ | 16.6 |  |  | 8 years |
| Customer relationships | 2.9 |  |  | 8 years |
| Total | $ | 19.5 |  |  |  |

[0001327567-18-000024:notes:35]
Goodwill generated from this business combination is primarily attributable to the assembled workforce and expected synergies from integrating the LightCyber technology into our platform. The goodwill is not deductible for income tax purposes.

[0001327567-18-000024:notes:36]
Additional Acquisition-Related Information

[0001327567-18-000024:notes:37]
The operating results of the acquired companies are included in our consolidated statements of operations from the respective dates of acquisition. Pro forma results of operations have not been presented because the effects of these acquisitions, individually and in the aggregate, were not material to our consolidated statements of operations.

[0001327567-18-000024:notes:38]
Additional information related to Evident.io and Secdo, such as that related to income tax and other contingencies, existing as of the acquisition date but unknown to us may become known during the remainder of the measurement period, not to exceed 12 months from the respective acquisition date, which may result in changes to the amounts and allocations recorded.


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock

[0001327567-18-000024:notes:39]
Description of Business and Summary of Significant Accounting Policies

[0001327567-18-000024:notes:40]
Description of Business

[0001327567-18-000024:notes:41]
Palo Alto Networks, Inc. (the “Company,” “we,” “us,” or “our”), located in Santa Clara, California, was incorporated in March 2005 under the laws of the State of Delaware and commenced operations in April 2005. We offer a security operating platform that empowers enterprises, service providers, and government entities to secure their organizations by safely enabling applications and data running in their networks, on their endpoints, and in the cloud, and by preventing breaches that stem from targeted cyberattacks.

[0001327567-18-000024:notes:42]
Principles of Consolidation

[0001327567-18-000024:notes:43]
The consolidated financial statements include our accounts and our wholly owned subsidiaries. All significant intercompany balances and transactions have been eliminated in consolidation.

[0001327567-18-000024:notes:44]
Use of Estimates

[0001327567-18-000024:notes:45]
The preparation of consolidated financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the consolidated financial statements and the reported amounts of revenues and expenses during the reporting period. Such management estimates include, but are not limited to the best estimate of selling price for our products and services, share-based compensation, fair value of assets acquired and liabilities assumed in business combinations, the assessment of recoverability of our property and equipment, identified intangibles and goodwill, future taxable income, manufacturing partner and supplier liabilities, fair value of debt component of convertible notes, cease-use loss related to facility exit, and loss contingencies. We base our estimates on historical experience and also on assumptions that we believe are reasonable. Actual results could differ materially from those estimates.

[0001327567-18-000024:notes:46]
Concentrations

[0001327567-18-000024:notes:47]
Financial instruments that subject us to concentrations of credit risk consist primarily of cash and cash equivalents, investments, accounts receivable, and derivative contracts.

[0001327567-18-000024:notes:48]
We invest only in high-quality credit instruments and maintain our cash and cash equivalents and available-for-sale investments in fixed income securities. Management believes that the financial institutions that hold our investments are financially sound and, accordingly, are subject to minimal credit risk. Deposits held with banks may exceed the amount of insurance provided on such deposits.

[0001327567-18-000024:notes:49]
Our derivative contracts expose us to credit risk to the extent that the counterparties may be unable to meet the terms of the arrangement. We mitigate this credit risk by transacting with major financial institutions with high credit ratings and also enter into master netting arrangements, which permit net settlement of transactions with the same counterparty. We are not required to pledge, and are not entitled to receive, cash collateral related to these derivative instruments. We do not enter into derivative contracts for trading or speculative purposes.

[0001327567-18-000024:notes:50]
Our accounts receivables are primarily derived from our distributors representing various geographical locations. We perform ongoing credit evaluations and generally do not require collateral on accounts receivable. We maintain an allowance for doubtful accounts for estimated potential credit losses. As of July 31, 2018, four distributors represented 27.9%, 21.5%, 11.5%, and 11.0% of our gross accounts receivable. For fiscal 2018, three distributors represented 33.4%, 23.0%, and 10.7% of our total revenue.

[0001327567-18-000024:notes:51]
We rely on an electronics manufacturing services provider (“EMS provider”) to assemble most of our products and sole source component suppliers for a certain number of our components.

[0001327567-18-000024:notes:52]
Comprehensive Loss

[0001327567-18-000024:notes:53]
Comprehensive loss is comprised of net loss and other comprehensive income (loss). Our other comprehensive income (loss) includes unrealized gains and losses on available-for-sale investments and unrealized gains and losses on cash flow hedges.

[0001327567-18-000024:notes:54]
Foreign Currency Transactions

[0001327567-18-000024:notes:55]
The functional currency of our foreign subsidiaries is the U.S. dollar. Monetary assets and liabilities denominated in foreign currencies have been remeasured into U.S. dollars using the exchange rates in effect at the balance sheet dates. Foreign currency denominated income and expenses have been remeasured using the average exchange rates in effect during each period. Foreign currency remeasurement gains and losses and foreign currency transaction gains and losses are not significant to the financial statements.

[0001327567-18-000024:notes:56]
Fair Value

[0001327567-18-000024:notes:57]
We define fair value as the price that would be received from selling an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date. When determining the fair value measurements for assets and liabilities which are required to be recorded at fair value, we consider the principal or most advantageous market in which to transact and the market-based risk. We apply fair value accounting for all financial assets and liabilities that are recognized or disclosed at fair value in the financial statements on a recurring basis. Goodwill, intangible assets, and other long-lived assets are measured at fair value on a nonrecurring basis, only if impairment is indicated. The carrying amounts reported in the consolidated financial statements approximate the fair value for cash and cash equivalents, accounts receivable, accounts payable, and accrued liabilities, due to their short-term nature.

[0001327567-18-000024:notes:58]
Cash, Cash Equivalents, and Investments

[0001327567-18-000024:notes:59]
We classify our investments as available-for-sale at the time of purchase since it is our intent that these investments are available for current operations, and include these investments on our consolidated balance sheets as cash equivalents, short-term investments, or long-term investments depending on their maturity.

[0001327567-18-000024:notes:60]
We consider all highly liquid investments with original maturities of three months or less at date of purchase to be cash equivalents. Investments not considered cash equivalents and with maturities one year or less from the consolidated balance sheet date are classified as short-term investments. Investments with maturities greater than one year from the consolidated balance sheet date are classified as long-term investments.

[0001327567-18-000024:notes:61]
Investments are considered impaired when a decline in fair value is judged to be other-than-temporary. We consult with our investment managers and consider available quantitative and qualitative evidence in evaluating potential impairment of our investments on a quarterly basis. If the cost of an individual investment exceeds its fair value, we evaluate, among other factors, general market conditions, the duration and extent to which the fair value is less than cost, and our intent and ability to hold the investment. Once a decline in fair value is determined to be other-than-temporary, an impairment charge is recorded and a new cost basis in the investment is established.

[0001327567-18-000024:notes:62]
Accounts Receivable

[0001327567-18-000024:notes:63]
Trade accounts receivable are recorded at the invoiced amount, net of allowances for doubtful accounts. The allowance for doubtful accounts is based on our assessment of the collectability of accounts. Management regularly reviews the adequacy of the allowance for doubtful accounts by considering the age of each outstanding invoice, each channel partner’s expected ability to pay, and the collection history with each channel partner, when applicable, to determine whether a specific allowance is appropriate. Accounts receivable deemed uncollectible are charged against the allowance for doubtful accounts when identified. As of July 31, 2018 and 2017, the allowance for doubtful accounts activity was not significant.

[0001327567-18-000024:notes:64]
Derivatives

[0001327567-18-000024:notes:65]
Our derivative financial instruments are recorded at fair value, on a gross basis, as either assets or liabilities in our consolidated balance sheets. Gains or losses related to our cash flow hedges are recorded as a component of accumulated other comprehensive income (“AOCI”) in our consolidated balance sheets and are reclassified into the financial statement line item associated with the underlying hedged transaction in our consolidated statements of operations when the underlying hedged transaction is recognized in earnings. If it becomes probable that the hedged transaction will not occur, the cumulative unrealized gain or loss is reclassified immediately from AOCI into the financial statement line item associated with the underlying hedged transaction in our consolidated statements of operations. Gains or losses related to non-designated derivative instruments are recognized in other income (expense), net in our consolidated statements of operations for each period until the instrument matures, is terminated, is re-designated as a qualified cash flow hedge, or is sold. Derivatives designated as cash flow hedges are classified in our consolidated statements of cash flows in the same manner as the underlying hedged transaction, primarily within cash flows from operating activities.

[0001327567-18-000024:notes:66]
Property and Equipment

[0001327567-18-000024:notes:67]
Property and equipment are stated at cost, less accumulated depreciation. Depreciation is computed using the straight-line method over the estimated useful lives of the assets, generally three to ten years. Leasehold improvements are depreciated over the shorter of the estimated useful lives of the improvements or the remaining lease term.

[0001327567-18-000024:notes:68]
Business Combinations

[0001327567-18-000024:notes:69]
We include the results of operations of the businesses that we acquire as of the respective dates of acquisition. We allocate the fair value of the purchase price of our acquisitions to the tangible assets acquired, liabilities assumed, and intangible assets acquired, based on their estimated fair values. The excess of the purchase price over the fair values of these identifiable assets and liabilities is recorded as goodwill. Additional information existing as of the acquisition date but unknown to us may become known during the remainder of the measurement period, not to exceed 12 months from the acquisition date, which may result in changes to the amounts and allocations recorded.

[0001327567-18-000024:notes:70]
Intangible Assets

[0001327567-18-000024:notes:71]
Purchased intangible assets with finite lives are carried at cost, less accumulated amortization. Amortization is computed over the estimated useful lives of the respective assets. Acquisition-related in-process research and development represents the fair value of incomplete research and development projects that have not reached technological feasibility as of the date of acquisition. Initially, these assets are not subject to amortization. Assets related to projects that have been completed are transferred to developed technology, which are subject to amortization.

[0001327567-18-000024:notes:72]
Impairment of Goodwill, Intangible Assets, and Other Long-Lived Assets

[0001327567-18-000024:notes:73]
Goodwill is evaluated for impairment on an annual basis in the fourth quarter of our fiscal year, and whenever events or changes in circumstances indicate the carrying amount of goodwill may not be recoverable. We have elected to first assess qualitative factors to determine whether it is more likely than not that the fair value of our single reporting unit is less than its carrying amount, including goodwill. If we determine that it is more likely than not that the fair value of our single reporting unit is less than its carrying amount, then the quantitative impairment test will be performed. Under the quantitative impairment test, if the carrying amount of our single reporting unit exceeds its fair value, we will recognize an impairment loss in an amount equal to that excess, but limited to the total amount of goodwill.

[0001327567-18-000024:notes:74]
We evaluate events and changes in circumstances that could indicate carrying amounts of purchased intangible assets and other long-lived assets may not be recoverable. When such events or changes in circumstances occur, we assess the recoverability of these assets by determining whether or not the carrying amount will be recovered through undiscounted expected future cash flows. If the total of the future undiscounted cash flows is less than the carrying amount of an asset, we record an impairment loss for the amount by which the carrying amount of the asset exceeds the fair value of the asset.

[0001327567-18-000024:notes:75]
Through July 31, 2018, we have not recognized any impairment losses on our goodwill and intangible assets. During the year ended July 31, 2017, we recognized an impairment loss of $20.9 million on property and equipment related to the relocation of our corporate headquarters. We did not recognize any impairment losses on our other long-lived assets during the year ended July 31, 2018, or prior to fiscal 2017.

[0001327567-18-000024:notes:76]
Convertible Senior Notes

[0001327567-18-000024:notes:77]
In accounting for the issuance of our convertible senior notes, we separate the notes into liability and equity components. The carrying amount of the liability component is calculated by measuring the fair value of a similar liability that does not have an associated convertible feature. The carrying amount of the equity component representing the conversion option is determined by deducting the fair value of the liability component from the par value of the notes as a whole. This difference represents a debt discount that is amortized to interest expense using the effective interest method over the term of the notes. The equity component is not remeasured as long as it continues to meet the conditions for equity classification. In accounting for the transaction costs related to the issuance of the notes, we allocate the total amount incurred to the liability and equity components using the same proportions as the proceeds from the notes. Transaction costs attributable to the liability component are netted with the liability component and amortized to interest expense using the effective interest method over the term of the notes. Transaction costs attributable to the equity component are netted with the equity component of the notes in additional paid-in capital in the consolidated balance sheets. When the notes are convertible, the net carrying amount of the notes is classified as a current liability and a portion of the equity component representing the conversion option is reclassified to temporary equity in our consolidated balance sheets. The portion of the equity component classified as temporary equity is measured as the difference between the principal and net carrying amount of the notes, excluding debt issuance costs.

[0001327567-18-000024:notes:78]
Revenue Recognition

[0001327567-18-000024:notes:79]
We generate revenue from the sales of hardware and software products, subscriptions, support, and other services primarily through a direct sales force and indirect relationships with channel partners, and, to a lesser extent, directly to end-customers.

[0001327567-18-000024:notes:80]
Revenue is recognized when all of the following criteria are met:

[0001327567-18-000024:notes:81]
| • | Persuasive Evidence of an Arrangement Exists. We rely upon non-cancelable sales agreements and purchase orders to determine the existence of an arrangement. |

[0001327567-18-000024:notes:82]
| • | Delivery has Occurred. We use shipping documents or transmissions of product or subscription and support contract registration codes to determine delivery. |

[0001327567-18-000024:notes:83]
| • | The Fee is Fixed or Determinable. We assess whether the fee is fixed or determinable based on the payment terms associated with the transaction. |

[0001327567-18-000024:notes:84]
| • | Collectability is Reasonably Assured. We assess collectability based on credit analysis and payment history. |

[0001327567-18-000024:notes:85]
We recognize product revenue at the time of shipment provided that all other revenue recognition criteria have been met. Our channel partners generally receive an order from an end-customer prior to placing an order with us. In addition, payment from our channel partners is not contingent on the partner’s success in sales to end-customers. Our channel partners generally do not stock appliances and only have limited stock rotation rights and no price protection rights. When necessary, we make certain estimates and maintain allowances for sales returns and other programs based on our historical experience. To date, these estimates have not been significant. We recognize subscription and support revenue ratably over the contractual service period, which is typically one to five years. Other services revenue is recognized as the services are rendered.

[0001327567-18-000024:notes:86]
Most of our arrangements, other than renewals of subscriptions and support contracts, are multiple-element arrangements with a combination of hardware, software, subscriptions, support, and other services. Products, subscriptions, support, and other services generally qualify as separate units of accounting. Our hardware deliverables typically include proprietary operating system software, which together deliver the essential functionality of our products. For multiple-element arrangements, we allocate revenue to each unit of accounting based on an estimated selling price at the arrangement inception. The estimated selling price for each element is based upon the following hierarchy: vendor-specific objective evidence (“VSOE”) of selling price, if available, third-party evidence (“TPE”) of selling price, if VSOE of selling price is not available, or best estimate of selling price (“BESP”), if neither VSOE of selling price nor TPE of selling price are available. The total arrangement consideration is allocated to each separate unit of accounting using the relative estimated selling prices of each unit based on the aforementioned selling price hierarchy. We limit the amount of revenue recognized for delivered elements to an amount that is not contingent upon future delivery of additional products or services or meeting of any specified performance conditions.

[0001327567-18-000024:notes:87]
In multiple-element arrangements where software deliverables are included, revenue is allocated to each separate unit of accounting for each of the non-software deliverables and to the software deliverables as a group using the relative estimated selling prices of each of the deliverables in the arrangement based on the aforementioned estimated selling price hierarchy. The arrangement consideration allocated to the software deliverables as a group is then allocated to each software deliverable using the residual method when VSOE of fair value of the undelivered items exists. Under the residual method, the amount of revenue allocated to delivered elements equals the total arrangement consideration less the aggregate fair value of any undelivered elements. In determining VSOE of fair value, we evaluate whether a substantial majority of the historical prices charged for a product or service sold on a standalone basis, as represented by a percentage of list price, fall within a reasonably narrow range. If VSOE of fair value of one or more undelivered items does not exist, revenue from the software portion of the arrangement is deferred and recognized at the earlier of: (i) delivery of those elements or (ii) when fair value can be established unless support is the only undelivered element, in which case, the entire software arrangement fee is recognized ratably over the contractual service period.

[0001327567-18-000024:notes:88]
We account for multiple agreements with a single partner as one arrangement if the contractual terms and/or substance of those agreements indicate that they may be so closely related that they are, in effect, parts of a single arrangement.

[0001327567-18-000024:notes:89]
Revenues are reported net of sales taxes. Shipping charges billed to channel partners are included in revenues and related costs are included in cost of revenue. After receipt of a partner order, any amounts billed in excess of revenue recognized are recorded as deferred revenue.

[0001327567-18-000024:notes:90]
Deferred Commissions

[0001327567-18-000024:notes:91]
Sales commissions that are incremental and directly related to non-cancelable customer sales contracts are deferred and amortized over the term of the related contract in proportion to the recognized revenue. Short-term deferred commissions are included in prepaid expenses and other current assets, while long-term deferred commissions are included in other assets in our consolidated balance sheets. The amortization of deferred commissions is included in sales and marketing expense in our consolidated statements of operations.

[0001327567-18-000024:notes:92]
Advertising Costs

[0001327567-18-000024:notes:93]
Advertising costs, which are expensed and included in sales and marketing expense when incurred, were $9.8 million, $13.7 million, and $6.6 million, during the years ended July 31, 2018, 2017, and 2016, respectively.

[0001327567-18-000024:notes:94]
Software Development Costs

[0001327567-18-000024:notes:95]
Internally developed software includes security software developed to meet our internal needs to provide cloud-based subscription offerings to our end-customers and business software that we customize to meet our specific operational needs. These capitalized costs consist of internal compensation related costs and external direct costs incurred during the application development stage and will be amortized over a useful life of three to five years.

[0001327567-18-000024:notes:96]
The costs to develop software that is marketed externally have not been capitalized as we believe our current software development process is essentially completed concurrent with the establishment of technological feasibility. As such, all related software development costs are expensed as incurred and included in research and development expense in our consolidated statements of operations.

[0001327567-18-000024:notes:97]
Share-Based Compensation

[0001327567-18-000024:notes:98]
Compensation expense related to share-based transactions, including employee and non-employee director awards, is measured and recognized in the financial statements based on fair value on the grant date. We recognize share-based compensation expense for awards with only service conditions on a straight-line basis over the requisite service period of the related award. We recognize share-based compensation expense for awards with market conditions and awards with performance conditions on a straight-line basis over the requisite service period for each separately vesting portion of the award and, for awards with performance conditions, when it is probable that the performance condition will be achieved. We account for forfeitures of all share-based payment awards when they occur.

[0001327567-18-000024:notes:99]
Leases

[0001327567-18-000024:notes:100]
We rent our facilities under operating lease agreements and recognize related rent expense on a straight-line basis over the term of the lease. Some of our lease agreements contain rent holidays, scheduled rent increases, lease incentives, and renewal options. Rent holidays and scheduled rent increases are included in the determination of rent expense to be recorded over the lease term. Lease incentives are recognized as a reduction of rent expense on a straight-line basis over the term of the lease. Renewals are not assumed in the determination of the lease term unless they are deemed to be reasonably assured at the inception of the lease. We begin recognizing rent expense on the date that we obtain the legal right to use and control the leased space.

[0001327567-18-000024:notes:101]
Upon exiting a leased property before the lease term expires, we assess the fair value of our remaining obligation under the lease and record a cease-use loss, if needed. The cease-use loss is calculated as the present value of the amount by which the remaining lease obligation, adjusted for the effects of any deferred items recognized under the lease and related costs, exceeds the estimated sublease rentals that could be reasonably obtained. The cease-use loss will be adjusted as a result of the remeasurement of the cease-use liability if the timing or amount of estimated cash flows change.

[0001327567-18-000024:notes:102]
Income Taxes

[0001327567-18-000024:notes:103]
We account for income taxes using the asset and liability method, which requires the recognition of deferred tax assets and liabilities for the expected future tax consequences of events that have been recognized in our financial statements or tax returns. In addition, deferred tax assets are recorded for the future benefit of utilizing net operating losses and research and development credit carryforwards. Valuation allowances are provided when necessary to reduce deferred tax assets to the amount expected to be realized.

[0001327567-18-000024:notes:104]
Significant judgment is required in determining any valuation allowance recorded against deferred tax assets. In assessing the need for a valuation allowance, we consider all available evidence, including past operating results, estimates of future taxable income, and the feasibility of tax planning strategies. In the event that we change our determination as to the amount of deferred tax assets that can be realized, we will adjust our valuation allowance with a corresponding impact to the provision for income taxes in the period in which such determination is made.

[0001327567-18-000024:notes:105]
We apply the authoritative accounting guidance prescribing a threshold and measurement attribute for the financial recognition and measurement of a tax position taken or expected to be taken in a tax return. We recognize liabilities for uncertain tax positions based on a two-step process. The first step is to evaluate the tax position for recognition by determining if the weight of available evidence indicates that it is more likely than not that the position will be sustained on audit, including resolution of related appeals or litigation processes, if any. The second step requires us to estimate and measure the tax benefit as the largest amount that is more likely than not to be realized upon ultimate settlement.

[0001327567-18-000024:notes:106]
We record deferred tax charges in prepaid expenses and other current assets and other assets on our consolidated balance sheets. These deferred tax charges are amortized on a straight-line basis over the life of the associated assets as a component of provision for income taxes in our consolidated statements of operations.

[0001327567-18-000024:notes:107]
Loss Contingencies

[0001327567-18-000024:notes:108]
We are subject to the possibility of various loss contingencies arising in the ordinary course of business. In determining loss contingencies, we consider the likelihood of loss or impairment of an asset, or the incurrence of a liability, as well as our ability to reasonably estimate the amount of loss. An estimated loss contingency is accrued when it is probable that an asset has been impaired or a liability has been incurred and the amount of loss can be reasonably estimated. If we determine that a loss is possible and the range of the loss can be reasonably determined, then we disclose the range of the possible loss. We regularly evaluate current information available to us to determine whether an accrual is required, an accrual should be adjusted or a range of possible loss should be disclosed.

[0001327567-18-000024:notes:109]
Recently Adopted Accounting Pronouncements

[0001327567-18-000024:notes:110]
Derivatives and Hedging

[0001327567-18-000024:notes:111]
In August 2017, the Financial Accounting Standards Board (“FASB”) issued new authoritative guidance on derivatives and hedging to better align an entity’s risk management activities and financial reporting for hedging relationships through changes to both the designation and measurement guidance for qualifying hedging relationships, and the presentation of hedge results. We early adopted the standard in our second quarter of fiscal 2018 on a modified retrospective basis. The adoption of this standard did not have a material impact on our consolidated financial statements.

[0001327567-18-000024:notes:112]
Recently Issued Accounting Pronouncements

[0001327567-18-000024:notes:113]
Business Combinations - Definition of a Business

[0001327567-18-000024:notes:114]
In January 2017, the FASB issued authoritative guidance clarifying the definition of a business to assist companies with evaluating whether transactions should be accounted for as acquisitions (or disposals) of assets or businesses. The standard is effective for us in our first quarter of fiscal 2019 and will be applied on a prospective basis. We do not expect the adoption of the standard will have a material impact on our consolidated financial statements.

[0001327567-18-000024:notes:115]
Statement of Cash Flows - Restricted Cash

[0001327567-18-000024:notes:116]
In November 2016, the FASB issued authoritative guidance on the presentation of restricted cash or restricted cash equivalents in the statement of cash flows. Under the new standard, restricted cash or restricted cash equivalents should be included with cash and cash equivalents when reconciling the beginning-of-period and end-of-period total amounts shown on the statement of cash flows. The standard is effective for us in our first quarter of fiscal 2019 and will be applied on a retrospective basis. We do not expect the adoption of the standard will have a material impact on our consolidated financial statements because our restricted cash balance has not been material.

[0001327567-18-000024:notes:117]
Income Taxes - Intra-Entity Asset Transfers

[0001327567-18-000024:notes:118]
In October 2016, the FASB issued authoritative guidance requiring the recognition of income tax consequences of an intra-entity transfer of an asset, other than inventory, when the transfer occurs. The standard is effective for us in our first quarter of fiscal 2019 and will be applied on a modified retrospective basis through a cumulative-effect adjustment to accumulated deficit as of the date of adoption. We will adopt the standard in our first quarter of fiscal 2019 and anticipate an increase in accumulated deficit of approximately $28.4 million upon adoption related to the reclassification of unrecognized income tax effects from intra-entity transfers of assets other than inventory that occurred prior to the date of adoption.

[0001327567-18-000024:notes:119]
Statement of Cash Flows - Classification of Certain Cash Receipts and Cash Payments

[0001327567-18-000024:notes:120]
In August 2016, the FASB issued new authoritative guidance addressing eight specific cash flow issues with the objective of reducing the existing diversity in practice in how certain transactions are presented and classified in the statement of cash flows. The standard is effective for us in our first quarter of fiscal 2019 and will be applied on a retrospective basis. We do not expect the adoption of the standard will have a material impact on our consolidated financial statements.

[0001327567-18-000024:notes:121]
Financial Instruments - Credit Losses

[0001327567-18-000024:notes:122]
In June 2016, the FASB issued new authoritative guidance on the accounting for credit losses on most financial assets and certain financial instruments. The standard replaces the existing incurred loss model with an expected credit loss model for financial assets measured at amortized cost, including trade receivables, and requires that credit losses on available-for-sale debt securities be presented as an allowance rather than as a write-down. The standard is effective for us in our first quarter of fiscal 2021 and will be applied on a modified retrospective basis. Early adoption is permitted beginning our first quarter of fiscal 2020. We are currently evaluating whether this standard will have a material impact on our consolidated financial statements.

[0001327567-18-000024:notes:123]
In February 2016, the FASB issued new authoritative guidance on lease accounting. Among its provisions, the standard requires lessees to recognize right-of-use assets and lease liabilities on the balance sheet for operating leases and also requires additional qualitative and quantitative disclosures about lease arrangements. The standard is effective for us in our first quarter of fiscal 2020 and will be applied on a modified retrospective basis, with the option to elect certain practical expedients. Early adoption is permitted. We are currently evaluating whether this standard will have a material impact on our consolidated financial statements.

[0001327567-18-000024:notes:124]
In May 2014, the FASB issued new authoritative guidance on revenue from contracts with customers. The new standard provides principles for recognizing revenue for the transfer of promised goods or services to customers with the consideration to which the entity expects to be entitled in exchange for those goods or services, as well as guidance on the recognition of costs related to obtaining and fulfilling customer contracts. The standard also requires expanded disclosures about the nature, amount, timing, and uncertainty of revenues and cash flows arising from customer contracts, including significant judgments and changes in judgments. The standard is effective for us in our first quarter of fiscal 2019 using either of two methods: (i) retrospective to each prior reporting period presented with the option to elect certain practical expedients as defined within the guidance (“full retrospective method”); or (ii) retrospective with the cumulative effect of initially applying the guidance recognized at the date of initial application and providing certain additional disclosures as defined per the guidance (“modified retrospective method”). We will adopt the standard in our first quarter of fiscal 2019 using the full retrospective method.

[0001327567-18-000024:notes:125]
In preparation for the new standard, we have updated our accounting policies, processes, internal controls over financial reporting, and system requirements. We have also finalized our assessment of the new standard, which will impact our accounting for revenue arrangements in the following areas:

[0001327567-18-000024:notes:126]
| • | removal of the current limitation on contingent revenue may result in revenue being recognized earlier for certain contracts; |

[0001327567-18-000024:notes:127]
| • | term license revenue associated with our virtual firewalls will be recognized upfront; |

[0001327567-18-000024:notes:128]
| • | allocation of revenue related to software due to the removal of the residual method of revenue recognition; and |

[0001327567-18-000024:notes:129]
| • | amortization period for incremental costs to obtain customer contracts, which primarily consist of sales commissions. |

[0001327567-18-000024:notes:130]
These changes did not have a material impact on our consolidated financial statements for the fiscal years ended July 31, 2018 and 2017, with the exception of the accounting for incremental costs to obtain customer contracts due to the longer period of amortization. Under the current accounting guidance, we defer and amortize these costs over the term of the related contract. Under the new standard, we will defer and amortize these costs for initial contracts that are not commensurate with renewal commissions over a benefit period of five years, which is typically longer than the initial contract term.

[0001327567-18-000024:notes:131]
The following tables present the expected impact of adoption of the new standard on our reported results for select consolidated statement of operations and consolidated balance sheet line items (in millions, except per share data):

[0001327567-18-000024:notes:132]
|  | Year Ended July 31, 2018 |  | Year Ended July 31, 2017 |
|  | As Reported |  | Impact of Adoption |  | As Adjusted |  | As Previously Reported |  | Impact of Adoption |  | As Adjusted |
| Consolidated Statements of Operations |  |  |  |  |  |  |  |  |  |  |  |
| Product revenue | $ | 871.5 |  |  | $ | 8.3 |  |  | $ | 879.8 |  |  | $ | 709.1 |  |  | $ | (0.6 | ) |  | $ | 708.5 |  |
| Subscription and support revenue | 1,401.6 |  |  | (7.8 | ) |  | 1,393.8 |  |  | 1,052.5 |  |  | (5.9 | ) |  | 1,046.6 |  |
| Total revenue | 2,273.1 |  |  | 0.5 |  |  | 2,273.6 |  |  | 1,761.6 |  |  | (6.5 | ) |  | 1,755.1 |  |
| Total operating expenses | 1,756.9 |  |  | (24.2 | ) |  | 1,732.7 |  |  | 1,464.8 |  |  | (20.3 | ) |  | 1,444.5 |  |
| Operating loss | (129.1 | ) |  | 24.9 |  |  | (104.2 | ) |  | (179.8 | ) |  | 14.0 |  |  | (165.8 | ) |
| Net loss | (147.9 | ) |  | 25.7 |  |  | (122.2 | ) |  | (216.6 | ) |  | 13.6 |  |  | (203.0 | ) |
| Net loss per share, basic and diluted | $ | (1.61 | ) |  | $ | 0.28 |  |  | $ | (1.33 | ) |  | $ | (2.39 | ) |  | $ | 0.15 |  |  | $ | (2.24 | ) |

[0001327567-18-000024:notes:133]
|  | July 31, 2018 |
|  | As Reported |  | Impact of Adoption |  | As Adjusted |
| Consolidated Balance Sheet |  |  |  |  |  |
| Accounts receivable, net | $ | 467.3 |  |  | $ | (0.3 | ) |  | $ | 467.0 |  |
| Prepaid expenses and other current assets | 261.3 |  |  | 6.8 |  |  | 268.1 |  |
| Other assets | 206.8 |  |  | 119.4 |  |  | 326.2 |  |
| Accrued and other liabilities | 107.0 |  |  | 17.6 |  |  | 124.6 |  |
| Deferred revenue | 1,268.9 |  |  | (55.3 | ) |  | 1,213.6 |  |
| Long-term deferred revenue | 1,096.0 |  |  | (30.3 | ) |  | 1,065.7 |  |
| Accumulated deficit | (984.6 | ) |  | 193.9 |  |  | (790.7 | ) |

[0001327567-18-000024:notes:134]
The adoption of the standard will not impact net cash flows from operating, investing, or financing activities in our consolidated statements of cash flows. The exact impact of the new standard will be dependent on facts and circumstances at adoption and could vary from quarter to quarter.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001327567-18-000024:notes:135]
Commitments and Contingencies

[0001327567-18-000024:notes:136]
We lease our facilities under various non-cancelable operating leases, which expire through the year ending July 31, 2028.

[0001327567-18-000024:notes:137]
In May 2015 and October 2015, we entered into a total of three lease agreements for approximately 941,000 square feet of corporate office space in Santa Clara, California, which serves as our new corporate headquarters. The leases contain rent holiday periods, scheduled rent increases, lease incentives, and renewal options which allow the lease terms to be extended beyond their expiration dates of July 2028 through July 2046. In September 2017, per the terms of the lease agreements, the landlords exercised their option to amend our lease payment schedules and eliminate our rent holiday periods, which increased our rental payments by $24.4 million, $11.8 million, and $2.0 million for fiscal 2018, 2019, and 2020, respectively. In exchange, we received an upfront cash reimbursement of $38.2 million during the three months ended October 31, 2017, which we will apply against the future additional rental payments when due. As amended, rental payments under the three lease agreements are approximately $412.0 million over the lease term.

[0001327567-18-000024:notes:138]
In May 2015, we also entered into a lease agreement for approximately 122,000 square feet of space in Santa Clara, California to serve as an extension of our previous corporate headquarters. The lease contains scheduled rent increases, lease incentives, and renewal options which allow the lease term to be extended beyond the expiration date of April 2021 through July 2046. Rental payments under the lease agreement are approximately $23.1 million over the lease term. In December 2017, we entered into an agreement to sublease this office space for the remaining lease term. Proceeds from this sublease will be approximately $16.3 million over the sublease term.

[0001327567-18-000024:notes:139]
In September 2012, we entered into two lease agreements for a total of approximately 300,000 square feet of space in Santa Clara, California, which served as our previous corporate headquarters through August 2017, when we relocated to our new corporate campus. The leases contain rent holiday periods and two separate five-year options to extend the lease term beyond their expiration dates of July 2023. Rental payments under these lease agreements are approximately $94.3 million over the lease term. In August 2017, we exited our previous headquarter facilities and relocated to our new corporate campus, which resulted in the recognition of a cease-use loss of $39.2 million as general and administrative expense in our consolidated statements of operations during the year ended July 31, 2018, and a corresponding liability in our consolidated balance sheets. During the year ended July 31, 2018, we released $10.1 million of the cease-use liability through rental payments. As of July 31, 2018, the remaining balance of the cease-use liability was $29.1 million, which is expected to be paid through the end of the lease term in July 2023.

[0001327567-18-000024:notes:140]
We recognized rent expense of $35.2 million, $35.9 million, and $20.2 million for the years ended July 31, 2018, 2017, and 2016, respectively. Rent expense is recognized on a straight-line basis over the term of the lease.

[0001327567-18-000024:notes:141]
The following table presents details of the aggregate future non-cancelable minimum rental payments under our operating leases as of July 31, 2018 (in millions):

[0001327567-18-000024:notes:142]
|  | Amount |
| Years ending July 31: |  |
| 2019 | $ | 66.3 |  |
| 2020 | 68.2 |  |
| 2021 | 64.0 |  |
| 2022 | 59.8 |  |
| 2023 | 58.5 |  |
| 2024 and thereafter | 223.8 |  |
| Committed gross lease payments | 540.6 |  |
| Less: proceeds from sublease rental | 14.0 |  |
| Net operating lease obligation | $ | 526.6 |  |

[0001327567-18-000024:notes:143]
Purchase Commitments

[0001327567-18-000024:notes:144]
Manufacturing Purchase Commitments

[0001327567-18-000024:notes:145]
Our EMS provider procures components and assembles our products based on our forecasts. These forecasts are based on estimates of demand for our products primarily for the next 12 months, which are in turn based on historical trends and an analysis from our sales and product management organizations, adjusted for overall market conditions. In order to reduce manufacturing lead times and plan for adequate supply, we may issue non-cancelable orders for products and components to our manufacturing partners or component suppliers. As of July 31, 2018, our purchase commitments under such orders were $134.6 million, excluding obligations under contracts that we can cancel without a significant penalty.

[0001327567-18-000024:notes:146]
Other Purchase Commitments

[0001327567-18-000024:notes:147]
In March 2018, we amended an agreement with a third-party provider for our use of certain cloud services through June 2020. Under the non-cancelable addendum, we are committed to a minimum purchase of $14.0 million between April 2018 and March 2019 and $8.0 million between April 2019 and March 2020. As of July 31, 2018, our purchase commitment under the addendum was $11.7 million.

[0001327567-18-000024:notes:148]
Litigation

[0001327567-18-000024:notes:149]
We are subject to legal proceedings, claims, and litigation arising in the ordinary course of business, including intellectual property litigation. Such matters are subject to many uncertainties and outcomes are not predictable with assurance. We accrue for contingencies when we believe that a loss is probable and that we can reasonably estimate the amount of any such loss.

[0001327567-18-000024:notes:150]
To the extent there is a reasonable possibility that a loss exceeding amounts already recognized may be incurred and the amount of such additional loss would be material, we will either disclose the estimated additional loss or state that such an estimate cannot be made. As of July 31, 2018, we have not recorded any significant accruals for loss contingencies associated with such legal proceedings, determined that an unfavorable outcome is probable or reasonably possible, or determined that the amount or range of any possible loss is reasonably estimable.

[0001327567-18-000024:notes:151]
Indemnification

[0001327567-18-000024:notes:152]
Under the indemnification provisions of our standard sales related contracts, we agree to defend our end-customers against third-party claims asserting infringement of certain intellectual property rights, which may include patents, copyrights, trademarks, or trade secrets, and to pay judgments entered on such claims. Our exposure under these indemnification provisions is generally limited to payments made to us for the alleged infringing products over the preceding twelve months under the agreement. However, certain agreements include indemnification provisions that could potentially expose us to losses in excess of these payments. In addition, we indemnify our officers, directors, and certain key employees while they are serving in good faith in their company capacities. To date, we have not recorded any accruals for loss contingencies associated with indemnification claims or determined that an unfavorable outcome is probable or reasonably possible.


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0001327567-18-000024:notes:153]
Employee Benefit Plan

[0001327567-18-000024:notes:154]
We have established a 401(k) tax-deferred savings plan which permits participants to make contributions by salary deduction pursuant to Section 401(k) of the Internal Revenue Code. In fiscal 2016, we began to make matching contributions based upon the amount of employees’ contributions, subject to certain limitations. Our matching contributions to the plan were immaterial for the years ended July 31, 2018, 2017, and 2016.


## us-gaap:ConvertibleDebtTableTextBlock

[0001327567-18-000024:notes:155]
The following table sets forth the components of the Notes as of July 31, 2018 and July 31, 2017 (in millions):

[0001327567-18-000024:notes:156]
|  | July 31, 2018 |  | July 31, 2017 |
|  | 2019 Notes |  | 2023 Notes |  | Total |  | 2019 Notes |  | 2023 Notes |  | Total |
| Liability component: |  |  |  |  |  |  |  |  |  |  |  |
| Principal | $ | 575.0 |  |  | $ | 1,693.0 |  |  | $ | 2,268.0 |  |  | $ | 575.0 |  |  | $ | — |  |  | $ | 575.0 |  |
| Less: debt discount and debt issuance costs, net of amortization | 24.6 |  |  | 323.3 |  |  | 347.9 |  |  | 50.3 |  |  | — |  |  | 50.3 |  |
| Net carrying amount | $ | 550.4 |  |  | $ | 1,369.7 |  |  | $ | 1,920.1 |  |  | $ | 524.7 |  |  | $ | — |  |  | $ | 524.7 |  |
| Equity component (including amounts classified as temporary equity) | $ | 109.8 |  |  | $ | 315.0 |  |  | $ | 424.8 |  |  | $ | 109.8 |  |  | $ | — |  |  | $ | 109.8 |  |


## us-gaap:DebtDisclosureTextBlock

[0001327567-18-000024:notes:157]
In June 2014, we issued $575.0 million aggregate principal amount of 0.0% Convertible Senior Notes due 2019 (the “2019 Notes”) and in July 2018, we issued $1.7 billion aggregate principal amount of 0.75% Convertible Senior Notes due 2023 (the “2023 Notes” and, together with the 2019 Notes, the “Notes”). The 2023 Notes bear interest at a fixed rate of 0.75% per year, payable semi-annually in arrears on January 1 and July 1 of each year, beginning on January 1, 2019. Each series of Notes is governed by an indenture between us, as the issuer, and U.S. Bank National Association, as Trustee (individually, each an “Indenture,” and together, the “Indentures”). The Notes of each series are unsecured, unsubordinated obligations and the applicable Indenture governing each series of Notes does not contain any financial covenants or restrictions on the payments of dividends, the incurrence of indebtedness, or the issuance or repurchase of securities by us or any of our subsidiaries. The 2019 Notes and 2023 Notes mature on July 1, 2019 and July 1, 2023, respectively. We cannot redeem either series of Notes prior to the applicable maturity date.

[0001327567-18-000024:notes:158]
Holders of the Notes may surrender their Notes for conversion at their option at any time prior to the close of business on the business day immediately preceding their respective convertible dates only under the following circumstances:

[0001327567-18-000024:notes:159]
| • | during any fiscal quarter commencing after the fiscal quarters ending on October 31, 2014 and October 31, 2018, for the 2019 Notes and 2023 Notes, respectively (and only during such fiscal quarter), if the last reported sale price of our common stock for at least 20 trading days (whether or not consecutive) during a period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the applicable conversion price for the respective Notes on each applicable trading day (the “sale price condition”); |

[0001327567-18-000024:notes:160]
| • | during the five business day period after any five consecutive trading day period (the “measurement period”) in which the trading price per $1,000 principal amount of the applicable series of Notes for each trading day of the measurement period was less than 98% of the product of the last reported sale price of our common stock and the applicable conversion rate for the respective Notes on each such trading day; or |

[0001327567-18-000024:notes:161]
| • | upon the occurrence of specified corporate events. |

[0001327567-18-000024:notes:162]
On or after the respective convertible date, holders may convert all or any portion of their Notes at any time prior to the close of business on the second scheduled trading day immediately preceding the applicable maturity date regardless of the foregoing conditions. Upon conversion, holders of the Notes of a series will receive cash equal to the aggregate principal amount of the Notes of such series to be converted, and, at our election, cash and/or shares of our common stock for any amounts in excess of the aggregate principal amount of the Notes of such series being converted.

[0001327567-18-000024:notes:163]
The conversion price will be subject to adjustment in some events. Holders of the Notes of a series who convert their Notes of such series in connection with certain corporate events that constitute a “make-whole fundamental change” under the applicable Indenture are, under certain circumstances, entitled to an increase in the conversion rate for such series of Notes. Additionally, upon the occurrence of a corporate event that constitutes a “fundamental change” under the applicable Indenture, holders of the Notes of such series may require us to repurchase for cash all or a portion of the Notes of such series at a repurchase price equal to 100% of the principal amount of the Notes of such series plus accrued and unpaid interest to, but excluding, the fundamental change repurchase date.

[0001327567-18-000024:notes:164]
The sale price condition was met for the 2019 Notes during the fiscal quarter ended July 31, 2018, and as a result, holders may convert their 2019 Notes at any time during the fiscal quarter ending October 31, 2018. Accordingly, the net carrying amount of the 2019 Notes was reclassified into current liabilities and the portion of the equity component representing the conversion option was reclassified into temporary equity in our consolidated balance sheets as of July 31, 2018. The sale price condition was not met for the 2023 Notes during the fiscal quarter ended July 31, 2018. Since the 2023 Notes were not convertible, the net carrying amount of the 2023 Notes was classified as a long-term liability and the equity component was included in additional paid-in capital in our consolidated balance sheets as of July 31, 2018.

[0001327567-18-000024:notes:165]
The sale price condition was not met for the 2019 Notes during the fiscal quarter ended July 31, 2017. Since the 2019 Notes were not convertible, the net carrying amount of the 2019 Notes was classified as a long-term liability and the equity component was included in additional paid-in capital in our consolidated balance sheets as of July 31, 2017.

[0001327567-18-000024:notes:166]
As of July 31, 2018, all of the Notes remained outstanding. Subsequent to July 31, 2018, through the filing date of this Annual Report on Form 10-K, $327.3 million in principal amount of the 2019 Notes was converted or had been submitted by the holders for conversion and will settle during the fiscal quarter ending October 31, 2018.

[0001327567-18-000024:notes:167]
The total estimated fair value of the Notes was $2.7 billion and $747.5 million at July 31, 2018 and July 31, 2017, respectively. The fair value was determined based on the closing trading price per $100 of the Notes as of the last day of trading for the period. We consider the fair value of the Notes at July 31, 2018 and July 31, 2017 to be a Level 2 measurement. The fair value of the Notes is primarily affected by the trading price of our common stock and market interest rates. As of July 31, 2018, the if-converted value of the 2019 Notes exceeded its principal amount by $519.1 million. Based on the closing price of our common stock on July 31, 2018, the if-converted value of the 2023 Notes was less than its principal amount.

[0001327567-18-000024:notes:168]
The following table sets forth interest expense recognized related to the Notes (dollars in millions):

[0001327567-18-000024:notes:169]
|  | Year Ended July 31, 2018 |  | Year Ended July 31, 2017 |  | Year Ended July 31, 2016 |
|  | 2019 Notes |  | 2023 Notes |  | Total |  | 2019 Notes |  | 2023 Notes |  | Total |  | 2019 Notes |  | 2023 Notes |  | Total |
| Contractual interest expense | $ | — |  |  | $ | 0.7 |  |  | $ | 0.7 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Amortization of debt discount | 22.9 |  |  | 3.0 |  |  | 25.9 |  |  | 22.0 |  |  | — |  |  | 22.0 |  |  | 21.1 |  |  | — |  |  | 21.1 |  |
| Amortization of debt issuance costs | 2.8 |  |  | 0.1 |  |  | 2.9 |  |  | 2.5 |  |  | — |  |  | 2.5 |  |  | 2.3 |  |  | — |  |  | 2.3 |  |
| Total interest expense recognized | $ | 25.7 |  |  | $ | 3.8 |  |  | $ | 29.5 |  |  | $ | 24.5 |  |  | $ | — |  |  | $ | 24.5 |  |  | $ | 23.4 |  |  | $ | — |  |  | $ | 23.4 |  |
| Effective interest rate of the liability component | 4.8 | % |  | 5.2 | % |  |  |  | 4.8 | % |  | — | % |  |  |  | 4.8 | % |  | — | % |  |  |

[0001327567-18-000024:notes:170]
Note Hedges

[0001327567-18-000024:notes:171]
To minimize the impact of potential economic dilution upon conversion of the Notes, we entered into separate convertible note hedge transactions (the “2019 Note Hedges,” with respect to the 2019 Notes, and the “2023 Note Hedges,” with respect to the 2023 Notes, and collectively, the “Note Hedges”) with respect to our common stock concurrent with the issuance of each series of Notes.

[0001327567-18-000024:notes:172]
The Note Hedges cover shares of our common stock at a strike price per share that corresponds to the initial applicable conversion price of the applicable series of Notes, which are also subject to adjustment, and are exercisable upon conversion of the applicable series of Notes. The Note Hedges will expire upon maturity of the applicable series of Notes. The Note Hedges are separate transactions and are not part of the terms of the applicable series of the Notes. Holders of the Notes of either series will not have any rights with respect to the Note Hedges. Any shares of our common stock receivable by us under the Note Hedges are excluded from the calculation of diluted earnings per share as they are antidilutive. The aggregate amounts paid for the Note Hedges are included in additional paid-in capital in our consolidated balance sheets.

[0001327567-18-000024:notes:173]
Warrants

[0001327567-18-000024:notes:174]
Separately, but concurrently with the issuance of each series of Notes, we entered into transactions whereby we sold warrants (the “2019 Warrants,” with respect to the 2019 Notes, and the “2023 Warrants,” with respect to the 2023 Notes, and collectively, the “Warrants”) to acquire shares of our common stock, subject to anti-dilution adjustments.

[0001327567-18-000024:notes:175]
The following table presents details of the Warrants (in millions, except per share data):

[0001327567-18-000024:notes:176]
|  | Shares |  | Strike Price per Share |  | Aggregate Proceeds |
| 2019 Warrants | 5.2 |  |  | $ | 137.85 |  |  | $ | 78.3 |  |
| 2023 Warrants | 6.4 |  |  | $ | 417.80 |  |  | $ | 145.4 |  |

[0001327567-18-000024:notes:177]
The shares issuable under the Warrants will be included in the calculation of diluted earnings per share when the average market value per share of our common stock for the reporting period exceeds the applicable strike price for such series of Warrants. The Warrants are separate transactions and are not part of either series of Notes or Note Hedges and are not remeasured through earnings each reporting period. Holders of the Notes of either series will not have any rights with respect to the Warrants. The aggregate proceeds received from the sale of the Warrants are included in additional paid-in capital in our consolidated balance sheets.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001327567-18-000024:notes:178]
Derivative Instruments

[0001327567-18-000024:notes:179]
As a global business, we are exposed to currency exchange rate risk. Substantially all of our revenue is transacted in U.S. dollars, however, a portion of our operating expenditures are incurred outside of the United States and are denominated in foreign currencies, making them subject to fluctuations in foreign currency exchange rates. We enter into foreign currency derivative contracts with maturities of 14 months or less, which we designate as cash flow hedges, to manage the foreign currency exchange rate risk associated with these expenditures.

[0001327567-18-000024:notes:180]
As of July 31, 2018, the total notional amount of our outstanding foreign currency forward contracts was $288.5 million. Refer to Note 2. Fair Value Measurements for the fair value of our derivative instruments as reported in our consolidated balance sheets as of July 31, 2018. We did not have any foreign currency forward contracts outstanding as of July 31, 2017.

[0001327567-18-000024:notes:181]
During the years ended July 31, 2018 and 2017, both unrealized gains (losses) recognized in AOCI related to our cash flow hedges and amounts reclassified into earnings were not material. Unrealized gains (losses) in AOCI related to our cash flow hedges as of July 31, 2018 and 2017 were not material.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001327567-18-000024:notes:182]
Equity Award Plans

[0001327567-18-000024:notes:183]
Share-Based Compensation Plans

[0001327567-18-000024:notes:184]
2012 Equity Incentive Plan

[0001327567-18-000024:notes:185]
Our 2012 Equity Incentive Plan (our “2012 Plan”) was adopted by our board of directors and approved by the stockholders on June 5, 2012 and was effective one business day prior to the effectiveness of our registration statement for our initial public offering (“IPO”). Our 2012 Plan replaced our 2005 Equity Incentive Plan (our “2005 Plan”), which terminated upon the completion of our IPO, however, awards that were outstanding upon termination remained outstanding pursuant to their original terms. Our 2012 Plan provides for the granting of stock options, restricted stock awards (“RSAs”), restricted stock units (“RSUs”), stock appreciation rights, performance-based stock units (“PSUs”), performance shares (“PSAs”), and performance stock options (“PSOs”) to our employees, directors, and consultants.

[0001327567-18-000024:notes:186]
Awards granted under our 2012 Plan vest over the periods determined by the board of directors, generally three to four years from the date of grant, and our options expire no more than ten years after the date of grant. Since our IPO in 2012, awards granted under our 2012 Plan consist primarily of RSUs. Until vested, RSUs do not have the voting and dividend participation rights of common stock and the shares underlying the awards are not considered issued and outstanding.

[0001327567-18-000024:notes:187]
We grant awards with performance conditions (PSAs and PSUs) to certain employees, which vest over a period of four years from the date of grant. The actual number of PSAs and PSUs earned and eligible to vest is determined based on level of achievement against a pre-established billings target for the fiscal year.

[0001327567-18-000024:notes:188]
In June 2018, we granted 1.2 million PSOs with both a market condition and a service condition to our chief executive officer. The market condition requires the price of our common stock to exceed 150%, 200%, 250%, and 300% of the exercise price of the PSOs (the “stock price targets”) during the four-, five-, six-, and seven-year periods following the date of grant, respectively. To the extent that the stock price targets have been met, one-fourth of the PSOs will vest on the anniversary date of the grant date for such PSOs, subject to continued service.

[0001327567-18-000024:notes:189]
We net-share settle equity awards held by certain employees by withholding shares upon vesting to satisfy tax withholding obligations. The shares withheld to satisfy employee tax withholding obligations are returned to our 2012 Plan and will be available for future issuance. Payments for employees’ tax obligations to the tax authorities are recognized as a reduction to additional paid-in capital and reflected as financing activities in our consolidated statements of cash flows.

[0001327567-18-000024:notes:190]
A total of 17.7 million shares of our common stock are reserved for issuance pursuant to our 2012 Plan as of July 31, 2018. This includes shares that are (i) reserved but unissued under our 2005 Plan on the effective date of our 2012 Plan or (ii) returned to our 2005 Plan as a result of expiration or termination of options. On the first day of each fiscal year, the number of shares in the reserve may be increased by the lesser of (i) 8,000,000 shares, (ii) 4.5% of the outstanding shares of common stock on the last day of our immediately preceding fiscal year, or (iii) such other amount as determined by our board of directors.

[0001327567-18-000024:notes:191]
2012 Employee Stock Purchase Plan

[0001327567-18-000024:notes:192]
Our 2012 Employee Stock Purchase Plan was adopted by our board of directors and approved by the stockholders on June 5, 2012, and was effective upon completion of our IPO. On August 29, 2017, we amended and restated our 2012 Employee Stock Purchase Plan (our “2012 ESPP”) to extend the length of our offering periods from 6 to 24 months.

[0001327567-18-000024:notes:193]
Our 2012 ESPP permits eligible employees to acquire shares of our common stock at 85% of the lower of the fair market value of our common stock on the first trading day of each offering period or on the purchase date. If the fair market value of our common stock on the purchase date is lower than the first trading day of the offering period, the current offering period will be cancelled after purchase and a new 24-month offering period will begin. Under our 2012 ESPP, each 24-month offering period consists of four consecutive 6-month purchase periods, with purchase dates on the first trading day on or after February 28 and August 31 of each year. Participants may purchase shares of common stock through payroll deductions of up to 15% of their eligible compensation, subject to purchase limits of 625 shares per six-month purchase period and $25,000 worth of stock for each calendar year. During the year ended July 31, 2018, employees purchased 0.4 million shares of common stock under our 2012 ESPP at an average exercise price of $110.87 per share.

[0001327567-18-000024:notes:194]
A total of 3.4 million shares of our common stock are available for sale under our 2012 ESPP as of July 31, 2018. On the first day of each fiscal year, the number of shares in the reserve may be increased by the lesser of (i) 2,000,000 shares, (ii) 1% of the outstanding shares of our common stock on the first day of the fiscal year, or (iii) such other amount as determined by our board of directors.

[0001327567-18-000024:notes:195]
Stock Option Activities

[0001327567-18-000024:notes:196]
The following table summarizes the stock option activity, including PSOs, under our stock plans during the reporting period (in millions, except per share amounts):

[0001327567-18-000024:notes:197]
|  | Options Outstanding |
|  | Number ofShares |  | Weighted- Average Exercise Price Per Share |  | Weighted- Average Remaining Contractual Term (Years) |  | Aggregate Intrinsic Value |
| Balance—July 31, 2017 | 1.6 |  |  | $ | 13.11 |  |  | 4.2 |  | $ | 190.6 |  |
| Options granted | 1.2 |  |  | $ | 198.50 |  |  |  |  |  |
| Options forfeited | — |  |  | $ | — |  |  |  |  |  |
| Options exercised | (0.6 | ) |  | $ | 12.76 |  |  |  |  |  |
| Balance—July 31, 2018 | 2.2 |  |  | $ | 109.12 |  |  | 5.2 |  | $ | 199.8 |  |
| Options exercisable—July 31, 2018 | 1.1 |  |  | $ | 13.28 |  |  | 3.2 |  | $ | 199.8 |  |

[0001327567-18-000024:notes:198]
The weighted-average grant-date fair value of stock options granted during the year ended July 31, 2018 was $56.14 per share. No stock options were granted during the years ended July 31, 2017 and 2016. The grant-date fair value of options vested during the year ended July 31, 2016 was $8.1 million. No options vested during the years ended July 31, 2018 and 2017. The intrinsic value of options exercised during the years ended July 31, 2018, 2017, and 2016 was $85.0 million, $61.2 million, and $176.1 million, respectively.

[0001327567-18-000024:notes:199]
RSA, PSA, RSU, and PSU Activities

[0001327567-18-000024:notes:200]
The following table summarizes the RSA, PSA, RSU, and PSU activity under our stock plans during the reporting period (in millions, except per share amounts):

[0001327567-18-000024:notes:201]
|  | RSAs and PSAs Outstanding |  | RSUs and PSUs Outstanding |
|  | Number of Shares |  | Weighted- Average Grant-Date Fair Value Per Share |  | Number of Shares |  | Weighted- Average Grant-Date Fair Value Per Share |  | Weighted- Average Remaining Contractual Term (Years) |  | Aggregate Intrinsic Value |
| Balance—July 31, 2017 | 1.0 |  |  | $ | 163.55 |  |  | 6.5 |  |  | $ | 141.16 |  |  | 1.3 |  | $ | 854.1 |  |
| Granted(1) | — |  |  | $ | — |  |  | 4.1 |  |  | $ | 170.44 |  |  |  |  |  |
| Vested | (0.5 | ) |  | $ | 168.62 |  |  | (3.3 | ) |  | $ | 138.75 |  |  |  |  |  |
| Forfeited | (0.2 | ) |  | $ | 157.49 |  |  | (0.6 | ) |  | $ | 144.33 |  |  |  |  |  |
| Balance—July 31, 2018 | 0.3 |  |  | $ | 160.85 |  |  | 6.7 |  |  | $ | 160.20 |  |  | 1.6 |  | $ | 1,335.2 |  |

[0001327567-18-000024:notes:202]
______________

[0001327567-18-000024:notes:203]
| (1) | For PSAs and PSUs, shares granted represents the aggregate maximum number of shares that may be earned and issued with respect to these awards over their full terms. |

[0001327567-18-000024:notes:204]
The weighted-average grant-date fair value of RSAs and PSAs granted during the years ended July 31, 2017 and 2016 was$148.54 and $170.97 per share, respectively. No RSAs or PSAs were granted during the year ended July 31, 2018. The aggregate fair value, as of the respective vesting dates, of RSAs and PSAs vested during the year ended July 31, 2018 was $67.5 million, and RSAs vested during the year ended July 31, 2017 was $62.6 million. No PSAs vested during the year ended July 31, 2017, and no RSAs or PSAs vested during the year ended July 31, 2016.

[0001327567-18-000024:notes:205]
The weighted-average grant-date fair value of RSUs and PSUs granted during the years ended July 31, 2018, 2017, and 2016 was $170.44, $141.35, and $160.60 per share, respectively. The aggregate fair value, as of the respective vesting dates, of RSUs vested during the years ended July 31, 2018, 2017, and 2016 was $546.3 million, $462.6 million, and $513.0 million, respectively. No PSUs vested during the three years ended July 31, 2018.

[0001327567-18-000024:notes:206]
Shares Available for Grant

[0001327567-18-000024:notes:207]
We record share-based compensation awards based on estimated fair value as of the grant date. The fair value of RSUs, PSUs, RSAs, and PSAs is based on the closing market price of our common stock on the date of grant. The fair value of PSOs is estimated on the grant date using a Monte Carlo simulation model and the following assumptions: expected volatility of 33.3%, based on a combination of implied volatility from traded options on our common stock and the historical volatility of our common stock; dividend yield of 0.0%, based on our current expectations about our anticipated dividend policy; risk-free interest rate of 2.9%, based on the implied yield available on U.S. Treasury zero-coupon issues with terms equal to the contractual terms of each tranche; and an expected term which takes into consideration the vesting term and the contractual term of the PSO.

[0001327567-18-000024:notes:208]
The fair value of shares issued under our 2012 ESPP are estimated on the grant date using the Black-Scholes option pricing model. The following table summarizes the assumptions used and the resulting grant-date fair values of our ESPP:

[0001327567-18-000024:notes:209]
|  | Year Ended July 31, |
|  | 2018 |  | 2017 |  | 2016 |
| Volatility | 26.8% - 43.6% |  |  | 41.0% - 50.1% |  |  | 33.4 % - 45.5% |  |
| Expected term (in years) | 0.5 - 2.0 |  |  | 0.5 |  |  | 0.5 |  |
| Dividend yield | — | % |  | — | % |  | — | % |
| Risk-free interest rate | 1.2% - 2.3% |  |  | 0.5% - 0.9% |  |  | 0.2% - 0.5% |  |
| Grant-date fair value per share | $34.94 - $65.04 |  |  | $34.15 - $39.65 |  |  | $43.07 - $44.62 |  |

[0001327567-18-000024:notes:210]
The expected volatility is based on the historical volatility of our common stock. The expected term represents the term from the first day of the offering period to the purchase dates within each offering period. The dividend yield assumption is based on our expectations about our anticipated dividend policy. The risk-free interest rate is based on the implied yield available on U.S. Treasury zero-coupon issues with maturities that approximate the expected term.

[0001327567-18-000024:notes:211]
The following table summarizes share-based compensation included in costs and expenses (in millions):

[0001327567-18-000024:notes:212]
|  | Year Ended July 31, |
|  | 2018 |  | 2017 |  | 2016 |
| Cost of product revenue | $ | 7.0 |  |  | $ | 7.3 |  |  | $ | 6.2 |  |
| Cost of subscription and support revenue | 66.7 |  |  | 56.2 |  |  | 40.9 |  |
| Research and development | 145.2 |  |  | 152.6 |  |  | 132.9 |  |
| Sales and marketing | 208.0 |  |  | 186.5 |  |  | 152.4 |  |
| General and administrative | 77.0 |  |  | 73.1 |  |  | 60.5 |  |
| Total share-based compensation | $ | 503.9 |  |  | $ | 475.7 |  |  | $ | 392.9 |  |

[0001327567-18-000024:notes:213]
As of July 31, 2018, total compensation cost related to unvested share-based awards not yet recognized was $1.1 billion. This cost is expected to be amortized over a weighted-average period of approximately 3.0 years. Future grants will increase the amount of compensation expense to be recorded in these periods.


## us-gaap:EarningsPerShareTextBlock

[0001327567-18-000024:notes:214]
Net Loss Per Share

[0001327567-18-000024:notes:215]
Basic net loss per share is computed by dividing net loss by basic weighted-average shares outstanding during the period. Diluted net loss per share is computed by dividing net loss by diluted weighted-average shares outstanding, including potentially dilutive securities.

[0001327567-18-000024:notes:216]
The following table presents the computation of basic and diluted net loss per share of common stock (in millions, except per share data):

[0001327567-18-000024:notes:217]
|  | Year Ended July 31, |
|  | 2018 |  | 2017 |  | 2016 |
| Net loss | $ | (147.9 | ) |  | $ | (216.6 | ) |  | $ | (192.7 | ) |
| Weighted-average shares used to compute net loss per share, basic and diluted | 91.7 |  |  | 90.6 |  |  | 87.1 |  |
| Net loss per share, basic and diluted | $ | (1.61 | ) |  | $ | (2.39 | ) |  | $ | (2.21 | ) |

[0001327567-18-000024:notes:218]
The following securities were excluded from the computation of diluted net loss per share of common stock for the periods presented as their effect would have been antidilutive (in millions):

[0001327567-18-000024:notes:219]
|  | Year Ended July 31, |
|  | 2018 |  | 2017 |  | 2016 |
| Convertible senior notes | 11.6 |  |  | 5.2 |  |  | 5.2 |  |
| Warrants related to the issuance of convertible senior notes | 11.6 |  |  | 5.2 |  |  | 5.2 |  |
| RSUs and PSUs | 6.7 |  |  | 6.5 |  |  | 6.5 |  |
| Options to purchase common stock | 2.2 |  |  | 1.6 |  |  | 2.1 |  |
| RSAs and PSAs | 0.3 |  |  | 1.0 |  |  | 1.1 |  |
| ESPP shares | 0.2 |  |  | 0.2 |  |  | 0.1 |  |
| Total | 32.6 |  |  | 19.7 |  |  | 20.2 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001327567-18-000024:notes:220]
Fair Value Measurements

[0001327567-18-000024:notes:221]
We categorize assets and liabilities recorded or disclosed at fair value on our consolidated balance sheets based upon the level of judgment associated with inputs used to measure their fair value. The categories are as follows:

[0001327567-18-000024:notes:222]
| • | Level 1—Inputs are unadjusted quoted prices in active markets for identical assets or liabilities. |

[0001327567-18-000024:notes:223]
| • | Level 2—Inputs are quoted prices for similar assets and liabilities in active markets or inputs that are observable for the assets or liabilities, either directly or indirectly through market corroboration, for substantially the full term of the financial instruments. |

[0001327567-18-000024:notes:224]
| • | Level 3—Inputs are unobservable inputs based on our own assumptions used to measure assets and liabilities at fair value. The inputs require significant management judgment or estimation. |

[0001327567-18-000024:notes:225]
The following table presents the fair value of our financial assets and liabilities measured at fair value on a recurring basis using the above input categories as of July 31, 2018 and July 31, 2017 (in millions):

[0001327567-18-000024:notes:226]
|  |  | July 31, 2018 |  | July 31, 2017 |
|  |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Cash equivalents: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 1,512.3 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,512.3 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Commercial paper |  | — |  |  | 52.0 |  |  | — |  |  | 52.0 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| U.S. government and agency securities |  | — |  |  | 397.3 |  |  | — |  |  | 397.3 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Total cash equivalents |  | 1,512.3 |  |  | 449.3 |  |  | — |  |  | 1,961.6 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Short-term investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Certificates of deposit |  | — |  |  | 5.4 |  |  | — |  |  | 5.4 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Non-U.S. government securities |  | — |  |  | 20.0 |  |  | — |  |  | 20.0 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Commercial paper |  | — |  |  | 22.3 |  |  | — |  |  | 22.3 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Corporate debt securities |  | — |  |  | 139.8 |  |  | — |  |  | 139.8 |  |  | — |  |  | 159.4 |  |  | — |  |  | 159.4 |  |
| U.S. government and agency securities |  | — |  |  | 709.0 |  |  | — |  |  | 709.0 |  |  | — |  |  | 471.3 |  |  | — |  |  | 471.3 |  |
| Total short-term investments |  | — |  |  | 896.5 |  |  | — |  |  | 896.5 |  |  | — |  |  | 630.7 |  |  | — |  |  | 630.7 |  |
| Long-term investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Certificates of deposit |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 5.4 |  |  | — |  |  | 5.4 |  |
| Corporate debt securities |  | — |  |  | 153.6 |  |  | — |  |  | 153.6 |  |  | — |  |  | 186.5 |  |  | — |  |  | 186.5 |  |
| U.S. government and agency securities |  | — |  |  | 393.9 |  |  | — |  |  | 393.9 |  |  | — |  |  | 597.4 |  |  | — |  |  | 597.4 |  |
| Total long-term investments |  | — |  |  | 547.5 |  |  | — |  |  | 547.5 |  |  | — |  |  | 789.3 |  |  | — |  |  | 789.3 |  |
| Total assets measured at fair value |  | $ | 1,512.3 |  |  | $ | 1,893.3 |  |  | $ | — |  |  | $ | 3,405.6 |  |  | $ | — |  |  | $ | 1,420.0 |  |  | $ | — |  |  | $ | 1,420.0 |  |
| Accrued and other liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency forward contracts |  | $ | — |  |  | $ | 6.9 |  |  | $ | — |  |  | $ | 6.9 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Total accrued and other liabilities |  | — |  |  | 6.9 |  |  | — |  |  | 6.9 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Total liabilities measured at fair value |  | $ | — |  |  | $ | 6.9 |  |  | $ | — |  |  | $ | 6.9 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |

[0001327567-18-000024:notes:227]
As of July 31, 2018, we did not have any assets or liabilities required to be measured at fair value on a nonrecurring basis. As of July 31, 2017, we determined that certain property and equipment related to our previous corporate headquarters were impaired. To support the growth of our business, in the fourth quarter of fiscal 2017, we committed to plans to relocate our corporate headquarters and sublet our previous headquarter facilities. In connection with our planned relocation, we assessed the recoverability of certain leasehold improvements and other long-lived assets associated with our previous headquarter facilities and determined that the carrying amount of these assets exceeded their fair value of $4.2 million. The resulting impairment loss of $20.9 million was recorded as general and administrative expense in our consolidated statements of operations during the year ended July 31, 2017. We calculated the fair value of the leasehold improvements and other long-lived assets based on estimated future discounted cash flows and classified the fair value as a Level 3 measurement due to the significance of unobservable inputs, which included the amount and timing of estimated sublease rental receipts that we could reasonably obtain over the remaining lease term and the discount rate. Refer to Note 9. Commitments and Contingencies for more information on the relocation of our corporate headquarters.

[0001327567-18-000024:notes:228]
Refer to Note 8. Convertible Senior Notes for the carrying amount and estimated fair value of our convertible senior notes as of July 31, 2018 and July 31, 2017.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001327567-18-000024:notes:229]
Goodwill and Intangible Assets

[0001327567-18-000024:notes:230]
Goodwill

[0001327567-18-000024:notes:231]
The following table presents details of our goodwill during the year ended July 31, 2018 (in millions):

[0001327567-18-000024:notes:232]
|  | Amount |
| Balance as of July 31, 2017 | $ | 238.8 |  |
| Goodwill acquired | 284.0 |  |
| Balance as of July 31, 2018 | $ | 522.8 |  |

[0001327567-18-000024:notes:233]
Through July 31, 2018, we have not recognized any impairment losses on our goodwill.

[0001327567-18-000024:notes:234]
Purchased Intangible Assets

[0001327567-18-000024:notes:235]
The following table presents details of our purchased intangible assets as of July 31, 2018 and July 31, 2017 (in millions):

[0001327567-18-000024:notes:236]
|  | July 31, |
|  | 2018 |  | 2017 |
|  | Gross Carrying Amount |  | Accumulated Amortization |  | Net Carrying Amount |  | Gross Carrying Amount |  | Accumulated Amortization |  | Net Carrying Amount |
| Intangible assets subject to amortization: |  |  |  |  |  |  |  |  |  |  |  |
| Developed technology | $ | 154.7 |  |  | $ | (38.2 | ) |  | $ | 116.5 |  |  | $ | 69.7 |  |  | $ | (23.8 | ) |  | $ | 45.9 |  |
| Customer relationships | 12.2 |  |  | (1.2 | ) |  | 11.0 |  |  | 3.1 |  |  | (0.4 | ) |  | 2.7 |  |
| Acquired intellectual property | 8.9 |  |  | (4.5 | ) |  | 4.4 |  |  | 8.9 |  |  | (3.8 | ) |  | 5.1 |  |
| Trade name and trademarks | 8.5 |  |  | (0.4 | ) |  | 8.1 |  |  | — |  |  | — |  |  | — |  |
| Other | 2.2 |  |  | (2.2 | ) |  | — |  |  | 2.2 |  |  | (2.2 | ) |  | — |  |
| Total intangible assets subject to amortization | 186.5 |  |  | (46.5 | ) |  | 140.0 |  |  | 83.9 |  |  | (30.2 | ) |  | 53.7 |  |
| Intangible assets not subject to amortization: |  |  |  |  |  |  |  |  |  |  |  |
| In-process research and development | 0.8 |  |  | — |  |  | 0.8 |  |  | — |  |  | — |  |  | — |  |
| Total purchased intangible assets | $ | 187.3 |  |  | $ | (46.5 | ) |  | $ | 140.8 |  |  | $ | 83.9 |  |  | $ | (30.2 | ) |  | $ | 53.7 |  |

[0001327567-18-000024:notes:237]
We recognized amortization expense of $16.3 million, $9.8 million, and $9.4 million for the years ended July 31, 2018, 2017, and 2016, respectively.

[0001327567-18-000024:notes:238]
The following table summarizes our estimated future amortization expense of intangible assets as of July 31, 2018 (in millions):

[0001327567-18-000024:notes:239]
|  | Amount |
| Years ending July 31: |  |
| 2019 | $ | 27.8 |  |
| 2020 | 27.7 |  |
| 2021 | 25.7 |  |
| 2022 | 21.2 |  |
| 2023 | 18.8 |  |
| 2024 and thereafter | 18.8 |  |
| Total future amortization expense | $ | 140.0 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001327567-18-000024:notes:240]
The following table presents the components of income (loss) before income taxes (in millions):

[0001327567-18-000024:notes:241]
|  | Year Ended July 31, |
|  | 2018 |  | 2017 |  | 2016 |
| United States | $ | (192.1 | ) |  | $ | (210.0 | ) |  | $ | (195.3 | ) |
| Foreign | 61.9 |  |  | 15.9 |  |  | 23.0 |  |
| Total | $ | (130.2 | ) |  | $ | (194.1 | ) |  | $ | (172.3 | ) |

[0001327567-18-000024:notes:242]
The following table summarizes our provision for income taxes (in millions):

[0001327567-18-000024:notes:243]
|  | Year Ended July 31, |
|  | 2018 |  | 2017 |  | 2016 |
| Federal: |  |  |  |  |  |
| Current | $ | (0.6 | ) |  | $ | 3.4 |  |  | $ | 1.9 |  |
| Deferred | (3.3 | ) |  | — |  |  | (0.6 | ) |
| State: |  |  |  |  |  |
| Current | 1.6 |  |  | 0.9 |  |  | 1.1 |  |
| Deferred | (1.3 | ) |  | — |  |  | (0.1 | ) |
| Foreign: |  |  |  |  |  |
| Current | 23.3 |  |  | 19.7 |  |  | 19.1 |  |
| Deferred | (2.0 | ) |  | (1.5 | ) |  | (1.0 | ) |
| Total | $ | 17.7 |  |  | $ | 22.5 |  |  | $ | 20.4 |  |

[0001327567-18-000024:notes:244]
For the year ended July 31, 2018, our provision for income taxes decreased compared to the year ended July 31, 2017, primarily due to changes in our valuation allowance related to our acquisition of Evident.io and future benefits from alternative minimum credits under the Tax Cuts and Jobs Act (“TCJA”).

[0001327567-18-000024:notes:245]
For the year ended July 31, 2017, our provision for income taxes increased compared to the year ended July 31, 2016, primarily due to increases in foreign withholding taxes and U.S. income taxes related to intercompany transactions, offset by tax benefits from our adoption of new share-based payment accounting guidance in fiscal 2017.

[0001327567-18-000024:notes:246]
As a result of adopting the new share-based payment guidance, we have not reflected the impact of excess tax benefits in additional paid-in capital for the years ended July 31, 2018 and 2017. Prior to adopting this guidance, we recorded excess tax benefits of $0.5 million directly to additional paid-in capital for the year ended July 31, 2016.

[0001327567-18-000024:notes:247]
On December 22, 2017, the TCJA was enacted into law. The TCJA provides for significant tax law changes and modifications including, but not limited to, the reduction of the U.S. federal corporate statutory tax rate from 35% to 21% as of January 1, 2018, the requirement for companies to pay a one-time transition tax on earnings of certain foreign subsidiaries that were previously tax deferred, and the creation of new taxes on certain foreign-sourced earnings. As a fiscal year-end taxpayer, certain provisions of the TCJA began to impact us during the fiscal quarter ended January 31, 2018, while other provisions will impact us beginning in our fiscal year ending July 31, 2019.

[0001327567-18-000024:notes:248]
As a result of the TCJA, we recorded a provisional benefit of $6.1 million during the year ended July 31, 2018, related to alternative minimum tax credits that will be refundable if not utilized. We adjusted our deferred tax assets as a result of changes in the federal tax rate. This change was offset by a corresponding adjustment to our valuation allowance. We have not recorded any amounts relating to the transition tax because we had no unremitted earnings as of the measurement date, based on our current estimate.

[0001327567-18-000024:notes:249]
Accounting standards require companies to recognize the effect of tax law changes in the period of enactment. However, the SEC staff and FASB issued guidance that allows companies to record provisional amounts for the effects of the TCJA during a measurement period not to extend beyond one year from the enactment date. In accordance with this guidance, we have determined the amounts recorded and positions taken, as discussed, are provisional as of July 31, 2018. We continue to assess the impacts of the TCJA, and the final impact of the TCJA recorded by us may differ from the provisional amounts due to a number of uncertainties and factors, including the need for further guidance and clarification of the new law by U.S. federal and state tax authorities, and the need for further guidance on the related income tax accounting.

[0001327567-18-000024:notes:250]
In addition to the previously discussed impacts on our fiscal year ended July 31, 2018, the TCJA also establishes new tax laws that will be effective beginning with our fiscal year ending July 31, 2019, including a provision for low-taxed income of foreign subsidiaries. Due to its complexity, we are continuing to evaluate this provision of the TCJA. Based on recent FASB deliberations, we will be allowed to make an accounting policy election to either (i) treat taxes due on future U.S. inclusions in taxable income as a current-period expense when incurred or (ii) factor such amounts into our measurement of deferred taxes. Our selection of accounting policy will depend, in part, on analyzing our facts and circumstances to determine the expected impact under each method. As of July 31, 2018, we have not made a policy election. We expect to make a policy election in fiscal year 2019, and anticipate any changes to deferred taxes from this election to be offset by a valuation allowance.

[0001327567-18-000024:notes:251]
The following table presents the items accounting for the difference between income taxes computed at the federal statutory income tax rate and our provision for income taxes:

[0001327567-18-000024:notes:252]
|  | Year Ended July 31, |
|  | 2018 |  | 2017 |  | 2016 |
| Federal statutory rate | 26.8 | % |  | 35.0 | % |  | 35.0 | % |
| Effect of: |  |  |  |  |  |
| State taxes, net of federal tax benefit | 5.0 |  |  | 2.8 |  |  | (1.7 | ) |
| Foreign income at other than U.S. rates | 12.6 |  |  | (14.4 | ) |  | (7.8 | ) |
| Change in valuation allowance | 29.0 |  |  | (39.4 | ) |  | (25.4 | ) |
| Effect of U.S. tax law change | (104.6 | ) |  | — |  |  | — |  |
| Share-based compensation | 8.6 |  |  | 1.6 |  |  | (15.9 | ) |
| Amortization of deferred tax charges | (6.5 | ) |  | (3.6 | ) |  | (3.4 | ) |
| Research credits | 25.4 |  |  | 10.1 |  |  | 11.3 |  |
| Non-deductible expenses | (4.9 | ) |  | (3.0 | ) |  | (1.3 | ) |
| Other, net | (5.0 | ) |  | (0.7 | ) |  | (2.6 | ) |
| Total | (13.6 | )% |  | (11.6 | )% |  | (11.8 | )% |

[0001327567-18-000024:notes:253]
As a result of the TCJA, our federal statutory tax rate for the fiscal year ended July 31, 2018 was 26.8% based on a blend of the statutory rates for 2017 and 2018. Further, we have reflected an adjustment to deferred taxes as a result of the TCJA, which is fully offset by changes in our valuation allowance.

[0001327567-18-000024:notes:254]
During the year ended July 31, 2017, we adopted new share-based payment accounting guidance that requires us to recognize excess tax benefits or deficiencies as income tax expense or benefit in the period in which they occur, rather than additional paid-in capital. The effect of the change from this guidance is reflected in the share-based compensation line above.

[0001327567-18-000024:notes:255]
During the year ended July 31, 2016, we accounted for the outcome of The Gillette Company et al. v. California Franchise Tax Board which disallowed the election to use an evenly weighted, three factor apportionment formula utilized by us on our tax return for the year ended July 31, 2014. The impact for the change in apportionment is reflected in state taxes, net of federal tax benefit above and is fully offset by changes in our valuation allowance.

[0001327567-18-000024:notes:256]
The following table presents the components of our deferred tax assets and liabilities as of July 31, 2018 and July 31, 2017 (in millions):

[0001327567-18-000024:notes:257]
|  | July 31, |
|  | 2018 |  | 2017 |
| Deferred tax assets: |  |  |  |
| Accruals and reserves | $ | 59.6 |  |  | $ | 30.0 |  |
| Deferred revenue | 132.9 |  |  | 133.5 |  |
| Net operating loss carryforwards | 189.5 |  |  | 245.3 |  |
| Research and development and foreign tax credits | 113.4 |  |  | 69.3 |  |
| Share-based compensation | 21.4 |  |  | 45.4 |  |
| Gross deferred tax assets | 516.8 |  |  | 523.5 |  |
| Valuation allowance | (420.1 | ) |  | (464.1 | ) |
| Total deferred tax assets | 96.7 |  |  | 59.4 |  |
| Deferred tax liabilities: |  |  |  |
| Fixed assets and intangible assets | (43.3 | ) |  | (13.5 | ) |
| Deferred commissions | (34.0 | ) |  | (36.8 | ) |
| Other deferred tax liabilities | (10.9 | ) |  | (4.0 | ) |
| Total deferred tax liabilities | (88.2 | ) |  | (54.3 | ) |
| Total | $ | 8.5 |  |  | $ | 5.1 |  |

[0001327567-18-000024:notes:258]
As a result of the TCJA, we have reflected an adjustment to deferred taxes during the year ended July 31, 2018, which was fully offset by changes in our valuation allowance.

[0001327567-18-000024:notes:259]
A valuation allowance is provided when it is more likely than not that the deferred tax asset will not be realized. Realization of deferred tax assets is dependent upon future taxable income, if any, the amount and timing of which are uncertain. At such time, if it is determined that it is more likely than not that the deferred tax assets are realizable, the valuation allowance will be adjusted. As of July 31, 2018, we have provided a valuation allowance for our federal, state, and certain foreign deferred tax assets that we believe will, more likely than not, be unrealizable. The net valuation allowance decreased by $44.0 million from the year ended July 31, 2017 to the year ended July 31, 2018, primarily due to a decrease in our U.S. federal tax rate as a result of the TCJA.

[0001327567-18-000024:notes:260]
As of July 31, 2018, we had federal, state, and foreign NOL carryforwards of approximately $1.3 billion, $800.1 million, and $59.2 million, respectively, as reported on our tax returns, available to reduce future taxable income, if any. If not utilized, our federal and state NOL carryforwards will expire in various amounts at various dates beginning in the years ending July 31, 2027 and July 31, 2019, respectively. Our foreign NOL will carry forward indefinitely.

[0001327567-18-000024:notes:261]
As of July 31, 2018, we had federal and state research and development tax credit carryforwards of approximately $80.7 million and $82.3 million, respectively as reported on our tax returns. If not utilized, the federal credit carryforwards will expire in various amounts at various dates beginning in the year ending July 31, 2026. The state credit will carry forward indefinitely.

[0001327567-18-000024:notes:262]
As of July 31, 2018, we had foreign tax credit carryforwards of $3.6 million as reported on our tax returns. If not utilized, the foreign tax credit carryforwards will expire in various amounts at various dates beginning in the year ending July 31, 2021.

[0001327567-18-000024:notes:263]
Utilization of the NOL carryforwards and credits may be subject to a substantial annual limitation due to the ownership change limitations provided by the Internal Revenue Code of 1986, as amended, and similar state provisions. The annual limitation may result in the expiration of NOLs and credits before utilization.

[0001327567-18-000024:notes:264]
During the year ended July 31, 2017, we were awarded a tax incentive by a foreign jurisdiction. The incentive is effective through September 30, 2031, and is conditional upon meeting certain investment and employment thresholds. The impact of this incentive on our provision for income taxes was not material for the years ended July 31, 2018 and 2017.

[0001327567-18-000024:notes:265]
As of July 31, 2018, we had $337.7 million of unrecognized tax benefits, $48.0 million of which would affect income tax expense if recognized, after consideration of our valuation allowance in the United States and other assets. As of July 31, 2017, we had $301.3 million of unrecognized tax benefits, $34.0 million of which would affect income tax expense if recognized, after consideration of our valuation allowance in the United States and other assets. As of July 31, 2018, our federal, state, and foreign returns for the tax years 2008 through the current period remain subject to adjustment due to examination. Fiscal years outside the normal statute of limitation remain open to audit by tax authorities due to tax attributes generated in earlier years, which have been carried forward and may be audited in subsequent years when utilized. We do not expect the amount of unrecognized tax benefits as of July 31, 2018 to change significantly over the next 12 months. We recognize both interest and penalties associated with uncertain tax positions as a component of income tax expense. During the years ended July 31, 2018, 2017, and 2016, we recognized income tax expense related to interest and penalties of $2.9 million, $2.1 million, and $1.6 million, respectively. We had accrued interest and penalties on our consolidated balance sheets related to unrecognized tax benefits of $8.3 million and $5.4 million as of July 31, 2018 and 2017, respectively. The ultimate amount and timing of any future cash settlements cannot be predicted with reasonable certainty.

[0001327567-18-000024:notes:266]
The following table presents a reconciliation of the beginning and ending amount of our gross unrecognized tax benefits (in millions):

[0001327567-18-000024:notes:267]
|  | Year Ended July 31, |
|  | 2018 |  | 2017 |  | 2016 |
| Unrecognized tax benefits at the beginning of the period | $ | 301.3 |  |  | $ | 127.7 |  |  | $ | 67.2 |  |
| Additions for tax positions taken in prior years | 3.1 |  |  | 3.1 |  |  | 25.2 |  |
| Reductions for tax positions taken in prior years | (6.3 | ) |  | — |  |  | — |  |
| Additions for tax positions taken in the current year | 39.6 |  |  | 170.5 |  |  | 35.3 |  |
| Unrecognized tax benefits at the end of the period | $ | 337.7 |  |  | $ | 301.3 |  |  | $ | 127.7 |  |

[0001327567-18-000024:notes:268]
During the year ended July 31, 2018, our additions for tax positions taken in the current year were primarily attributable to uncertain tax positions related to federal and state research and development credits, withholding taxes, and intercompany transactions.

[0001327567-18-000024:notes:269]
During the year ended July 31, 2017, our additions for tax positions taken in the current year were primarily attributable to uncertainties related to intercompany transactions.

[0001327567-18-000024:notes:270]
During the year ended July 31, 2016, our additions for tax positions taken in prior years and additions for tax positions taken in the current year were primarily attributable to uncertain tax positions relating to federal and state research and development credits, adjustments for California apportionment, and transfer pricing methodologies.

[0001327567-18-000024:notes:271]
As of July 31, 2018, we had no unremitted earnings when evaluating our outside basis difference relating to our U.S. investment in foreign subsidiaries. However, there could be local withholding taxes payable due to various foreign countries if certain lower tier earnings are distributed. Withholding taxes that would be payable upon remittance of these lower tier earnings were not material as of July 31, 2018.


## us-gaap:InvestmentsClassifiedByContractualMaturityDateTableTextBlock

[0001327567-18-000024:notes:272]
The following table summarizes the amortized cost and fair value of our available-for-sale securities as of July 31, 2018, by contractual years-to-maturity (in millions):

[0001327567-18-000024:notes:273]
|  | Amortized Cost |  | Fair Value |
| Due within one year | $ | 2,861.3 |  |  | $ | 2,858.1 |  |
| Due between one and three years | 554.5 |  |  | 547.5 |  |
| Total | $ | 3,415.8 |  |  | $ | 3,405.6 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001327567-18-000024:notes:274]
Investments

[0001327567-18-000024:notes:275]
Unrealized losses related to these securities are due to interest rate fluctuations as opposed to credit quality. In addition, we do not intend to sell and it is not likely that we would be required to sell these securities before recovery of their amortized cost basis, which may be at maturity. As a result, there were no other-than-temporary impairments for these securities at July 31, 2018 and 2017.

[0001327567-18-000024:notes:276]
We received proceeds of $141.9 million from sales of investments during the year ended July 31, 2016. We did not sell any investments during the years ended July 31, 2018 and 2017. We use the specific identification method to determine the cost basis of investments sold.


## us-gaap:LongLivedAssetsByGeographicAreasTableTextBlock

[0001327567-18-000024:notes:277]
The following table presents our property and equipment, net by geographic region (in millions):

[0001327567-18-000024:notes:278]
|  | Year Ended July 31, |
|  | 2018 |  | 2017 |
| Property and equipment, net: |  |  |  |
| United States | $ | 228.4 |  |  | $ | 178.4 |  |
| International | 44.7 |  |  | 32.7 |  |
| Total property and equipment, net | $ | 273.1 |  |  | $ | 211.1 |  |


## us-gaap:OtherNonoperatingIncomeAndExpenseTextBlock

[0001327567-18-000024:notes:279]
Other Income, Net

[0001327567-18-000024:notes:280]
The following table sets forth the components of other income, net (in millions):

[0001327567-18-000024:notes:281]
|  | Year Ended July 31, |
|  | 2018 |  | 2017 |  | 2016 |
| Interest income | $ | 27.1 |  |  | $ | 14.7 |  |  | $ | 8.8 |  |
| Foreign currency exchange gains (losses), net | 1.7 |  |  | (3.4 | ) |  | — |  |
| Other | (0.3 | ) |  | (1.1 | ) |  | (0.4 | ) |
| Total other income, net | $ | 28.5 |  |  | $ | 10.2 |  |  | $ | 8.4 |  |


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001327567-18-000024:notes:282]
The following table presents details of our property and equipment, net as of July 31, 2018 and July 31, 2017 (in millions):

[0001327567-18-000024:notes:283]
|  | July 31, |
|  | 2018 |  | 2017 |
| Computers, equipment, and software | $ | 217.9 |  |  | $ | 156.6 |  |
| Leasehold improvements | 159.5 |  |  | 110.1 |  |
| Demonstration units | 33.0 |  |  | 26.3 |  |
| Furniture and fixtures | 24.6 |  |  | 20.4 |  |
| Total property and equipment | 435.0 |  |  | 313.4 |  |
| Less: accumulated depreciation | (161.9 | ) |  | (102.3 | ) |
| Total property and equipment, net | $ | 273.1 |  |  | $ | 211.1 |  |

[0001327567-18-000024:notes:284]
We recognized depreciation expense of $74.7 million, $48.6 million, and $33.1 million related to property and equipment during the years ended July 31, 2018, 2017, and 2016, respectively. During the year ended July 31, 2017, we impaired certain property and equipment related to the relocation of our corporate headquarters and recognized a loss of $20.9 million in general and administrative expense on our consolidated statements of operations. Refer to Note 2. Fair Value Measurements for more information on our impairment assessment.


## us-gaap:QuarterlyFinancialInformationTextBlock

[0001327567-18-000024:notes:285]
Selected Quarterly Financial Data (Unaudited)

[0001327567-18-000024:notes:286]
The following tables set forth selected unaudited quarterly financial data for the years ended July 31, 2018 and 2017 (in millions, except per share amounts):

[0001327567-18-000024:notes:287]
|  | Three Months Ended |
|  | Oct. 31,2017 |  | Jan. 31,2018 |  | Apr. 30,2018 |  | Jul. 31,2018 |
| Revenue: |  |  |  |  |  |  |  |
| Product | $ | 186.5 |  |  | $ | 202.2 |  |  | $ | 215.2 |  |  | $ | 267.6 |  |
| Subscription and support | 319.0 |  |  | 340.2 |  |  | 351.9 |  |  | 390.5 |  |
| Total revenue | 505.5 |  |  | 542.4 |  |  | 567.1 |  |  | 658.1 |  |
| Cost of revenue: |  |  |  |  |  |  |  |
| Product | 57.6 |  |  | 63.9 |  |  | 68.9 |  |  | 82.0 |  |
| Subscription and support | 83.8 |  |  | 95.4 |  |  | 91.0 |  |  | 102.7 |  |
| Total cost of revenue | 141.4 |  |  | 159.3 |  |  | 159.9 |  |  | 184.7 |  |
| Total gross profit | 364.1 |  |  | 383.1 |  |  | 407.2 |  |  | 473.4 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 94.2 |  |  | 96.6 |  |  | 99.6 |  |  | 110.3 |  |
| Sales and marketing | 258.5 |  |  | 265.0 |  |  | 277.1 |  |  | 297.8 |  |
| General and administrative | 65.7 |  |  | 53.3 |  |  | 82.1 |  |  | 56.7 |  |
| Total operating expenses | 418.4 |  |  | 414.9 |  |  | 458.8 |  |  | 464.8 |  |
| Operating income (loss) | (54.3 | ) |  | (31.8 | ) |  | (51.6 | ) |  | 8.6 |  |
| Interest expense | (6.3 | ) |  | (6.4 | ) |  | (6.5 | ) |  | (10.4 | ) |
| Other income, net | 4.8 |  |  | 4.9 |  |  | 8.6 |  |  | 10.2 |  |
| Income (loss) before income taxes | (55.8 | ) |  | (33.3 | ) |  | (49.5 | ) |  | 8.4 |  |
| Provision for (benefit from) income taxes | 8.2 |  |  | 1.6 |  |  | (2.8 | ) |  | 10.7 |  |
| Net loss | $ | (64.0 | ) |  | $ | (34.9 | ) |  | $ | (46.7 | ) |  | $ | (2.3 | ) |
| Net loss per share, basic and diluted | $ | (0.70 | ) |  | $ | (0.38 | ) |  | $ | (0.51 | ) |  | $ | (0.02 | ) |

[0001327567-18-000024:notes:288]
|  | Three Months Ended |
|  | Oct. 31,2016 |  | Jan. 31,2017 |  | Apr. 30,2017 |  | Jul. 31,2017 |
| Revenue: |  |  |  |  |  |  |  |
| Product | $ | 163.8 |  |  | $ | 168.8 |  |  | $ | 164.2 |  |  | $ | 212.3 |  |
| Subscription and support | 234.3 |  |  | 253.8 |  |  | 267.6 |  |  | 296.8 |  |
| Total revenue | 398.1 |  |  | 422.6 |  |  | 431.8 |  |  | 509.1 |  |
| Cost of revenue: |  |  |  |  |  |  |  |
| Product | 42.2 |  |  | 45.8 |  |  | 49.7 |  |  | 63.7 |  |
| Subscription and support | 59.0 |  |  | 67.4 |  |  | 74.0 |  |  | 74.8 |  |
| Total cost of revenue | 101.2 |  |  | 113.2 |  |  | 123.7 |  |  | 138.5 |  |
| Total gross profit | 296.9 |  |  | 309.4 |  |  | 308.1 |  |  | 370.6 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 84.2 |  |  | 89.9 |  |  | 86.0 |  |  | 87.3 |  |
| Sales and marketing | 220.1 |  |  | 226.7 |  |  | 226.9 |  |  | 245.4 |  |
| General and administrative | 41.6 |  |  | 47.2 |  |  | 44.3 |  |  | 65.2 |  |
| Total operating expenses | 345.9 |  |  | 363.8 |  |  | 357.2 |  |  | 397.9 |  |
| Operating loss | (49.0 | ) |  | (54.4 | ) |  | (49.1 | ) |  | (27.3 | ) |
| Interest expense | (6.0 | ) |  | (6.1 | ) |  | (6.2 | ) |  | (6.2 | ) |
| Other income, net | 2.5 |  |  | 2.7 |  |  | 2.1 |  |  | 2.9 |  |
| Loss before income taxes | (52.5 | ) |  | (57.8 | ) |  | (53.2 | ) |  | (30.6 | ) |
| Provision for income taxes | 4.4 |  |  | 2.8 |  |  | 7.7 |  |  | 7.6 |  |
| Net loss | $ | (56.9 | ) |  | $ | (60.6 | ) |  | $ | (60.9 | ) |  | $ | (38.2 | ) |
| Net loss per share, basic and diluted | $ | (0.63 | ) |  | $ | (0.67 | ) |  | $ | (0.67 | ) |  | $ | (0.42 | ) |


## us-gaap:RevenueFromExternalCustomersByGeographicAreasTableTextBlock

[0001327567-18-000024:notes:289]
The following table presents revenue by geographic theater (in millions):

[0001327567-18-000024:notes:290]
|  | Year Ended July 31, |
|  | 2018 |  | 2017 |  | 2016 |
| Revenue: |  |  |  |  |  |
| Americas |  |  |  |  |  |
| United States | $ | 1,447.2 |  |  | $ | 1,155.3 |  |  | $ | 901.8 |  |
| Other Americas | 111.5 |  |  | 82.1 |  |  | 71.4 |  |
| Total Americas | 1,558.7 |  |  | 1,237.4 |  |  | 973.2 |  |
| Europe, the Middle East, and Africa (“EMEA”) | 439.3 |  |  | 320.1 |  |  | 247.1 |  |
| Asia Pacific and Japan (“APAC”) | 275.1 |  |  | 204.1 |  |  | 158.2 |  |
| Total revenue | $ | 2,273.1 |  |  | $ | 1,761.6 |  |  | $ | 1,378.5 |  |


## us-gaap:ScheduleOfEntityWideInformationRevenueFromExternalCustomersByProductsAndServicesTextBlock

[0001327567-18-000024:notes:291]
The following table presents revenue for groups of similar products and services (in millions):

[0001327567-18-000024:notes:292]
|  | Year Ended July 31, |
|  | 2018 |  | 2017 |  | 2016 |
| Revenue: |  |  |  |  |  |
| Product | $ | 871.5 |  |  | $ | 709.1 |  |  | $ | 670.8 |  |
| Subscription and support |  |  |  |  |  |
| Subscription | 759.6 |  |  | 550.8 |  |  | 357.0 |  |
| Support | 642.0 |  |  | 501.7 |  |  | 350.7 |  |
| Total subscription and support | 1,401.6 |  |  | 1,052.5 |  |  | 707.7 |  |
| Total revenue | $ | 2,273.1 |  |  | $ | 1,761.6 |  |  | $ | 1,378.5 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001327567-18-000024:notes:293]
Segment Information

[0001327567-18-000024:notes:294]
We conduct business globally and are primarily managed on a geographic theater basis. Our chief operating decision maker reviews financial information presented on a consolidated basis accompanied by information about revenue by geographic region for purposes of allocating resources and evaluating financial performance. We have one business activity and there are no segment managers who are held accountable for operations, operating results, and plans for levels, components, or types of products or services below the consolidated unit level. Accordingly, we are considered to be in a single reportable segment and operating unit structure.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001327567-18-000024:notes:295]
Stockholders’ Equity

[0001327567-18-000024:notes:296]
Share Repurchase

[0001327567-18-000024:notes:297]
In August 2016, our board of directors authorized a $500.0 million share repurchase which is funded from available working capital. In February 2017, our board of directors authorized a $500.0 million increase to the repurchase program, bringing the total authorization to $1.0 billion. Repurchases may be made at management’s discretion from time to time on the open market, through privately negotiated transactions, transactions structured through investment banking institutions, block purchase techniques, 10b5-1 trading plans, or a combination of the foregoing. The repurchase authorization will expire on December 31, 2018, and may be suspended or discontinued at any time.

[0001327567-18-000024:notes:298]
During the years ended July 31, 2018 and 2017, we repurchased and retired 1.7 million shares and 3.3 million shares, respectively, of our common stock under the authorization for an aggregate purchase price of $250.0 million and $420.1 million, respectively, including transaction costs. The total price of the shares repurchased and related transaction costs are reflected as a reduction to common stock and additional paid-in capital on our consolidated balance sheets. As of July 31, 2018, $330.0 million remained available for future share repurchases under the repurchase authorization.


## us-gaap:SubsequentEventsTextBlock

[0001327567-18-000024:notes:299]
Subsequent Event

[0001327567-18-000024:notes:300]
Credit Agreement

[0001327567-18-000024:notes:301]
On September 4, 2018, we entered into a credit agreement with certain institutional lenders (the “Credit Agreement”) that provides for a $400.0 million unsecured revolving credit facility, with an option to increase the amount of the credit facility by up to an additional $350.0 million, subject to certain conditions including obtaining commitments from existing lenders under the Credit Agreement or new lenders who would become party to the Credit Agreement. Proceeds from borrowings under the Credit Agreement may be used for general corporate purposes, including the financing of working capital requirements.
