# PANW 8-K — 0001327567-18-000018 filed 2018-09-06

## item codes, every 8-K on or before 2018-09-13

- 2018-09-06 0001327567-18-000018 — 1.01, 2.02, 2.03, 9.01
- 2018-07-13 0001193125-18-217281 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2018-06-04 0001327567-18-000011 — 2.02, 5.02, 9.01
- 2018-02-26 0001327567-18-000004 — 2.02, 5.02, 7.01, 9.01
- 2017-12-12 0001193125-17-367477 — 5.07
- 2017-11-20 0001327567-17-000032 — 2.02, 5.02, 9.01
- 2017-08-31 0001327567-17-000021 — 2.02, 5.02, 9.01
- 2017-05-31 0001327567-17-000016 — 2.02, 9.01
- 2017-02-28 0001327567-17-000005 — 2.02, 8.01, 9.01
- 2016-12-12 0001193125-16-790757 — 5.07
- 2016-11-21 0001327567-16-000071 — 2.02, 9.01
- 2016-10-24 0001193125-16-745121 — 5.02, 9.01
- 2016-08-30 0001327567-16-000057 — 2.02, 5.03, 8.01, 9.01
- 2016-08-22 0001193125-16-687588 — 5.02, 9.01
- 2016-05-26 0001327567-16-000051 — 2.02, 9.01
- 2016-02-25 0001327567-16-000044 — 2.02, 5.02, 9.01
- 2015-12-14 0001327567-15-000038 — 5.07
- 2015-12-14 0001193125-15-402588 — 1.01, 9.01
- 2015-11-23 0001327567-15-000033 — 2.02, 9.01
- 2015-10-19 0001193125-15-347005 — 1.01, 9.01 — amendment, the index does not say of what
- 2015-09-09 0001327567-15-000022 — 2.02, 9.01
- 2015-08-19 0001193125-15-296115 — 1.01, 2.03
- 2015-06-01 0001193125-15-207786 — 1.01, 2.03
- 2015-05-27 0001327567-15-000015 — 2.02, 9.01
- 2015-03-02 0001327567-15-000006 — 2.02, 9.01
- 2014-12-15 0001327567-14-000046 — 5.07
- 2014-11-24 0001327567-14-000040 — 2.02, 9.01
- 2014-09-22 0001193125-14-348581 — 5.02, 9.01
- 2014-09-09 0001327567-14-000025 — 2.02, 9.01
- 2014-07-01 0001193125-14-257824 — 1.01, 2.03, 3.02, 9.01
- 2014-06-26 0001193125-14-249529 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2014-06-20 0001327567-14-000020 — 9.01 — amendment of 0001193125-14-140511
- 2014-06-04 0001327567-14-000016 — 3.02
- 2014-05-30 0001193125-14-218158 — 2.02 — amendment, the index does not say of what
- 2014-05-28 0001193125-14-215060 — 1.01, 2.02, 3.02, 9.01
- 2014-04-11 0001193125-14-140511 — 2.01, 3.02, 7.01, 9.01
- 2014-03-24 0001193125-14-111318 — 1.01, 3.02, 7.01, 9.01
- 2014-03-13 0001327567-14-000009 — 5.02
- 2014-02-24 0001193125-14-063754 — 2.02, 9.01
- 2013-12-12 0001327567-13-000040 — 5.07
- 2013-11-25 0001327567-13-000033 — 2.02, 9.01
- 2013-09-30 0001193125-13-384966 — 8.01
- 2013-09-09 0001193125-13-361421 — 2.02, 9.01
- 2013-05-30 0001193125-13-241542 — 2.02, 5.02, 9.01
- 2013-03-11 0001193125-13-101082 — 5.02, 9.01
- 2013-02-28 0001193125-13-084193 — 2.02, 9.01
- 2012-12-14 0001193125-12-503335 — 5.07
- 2012-12-06 0001193125-12-493700 — 2.02, 9.01
- 2012-09-24 0001193125-12-401534 — 1.01, 2.03
- 2012-09-20 0001193125-12-398433 — 5.02, 9.01
- 2012-09-10 0001193125-12-386605 — 2.02, 9.01

## late-filing notifications on or before 2018-09-13

- none on or before 2018-09-13

## item 2.02 — earnings release, exhibit 99.1

[0001327567-18-000018:8k_2_02:1]
EX-99.1
3
ex991q418earningsrelease.htm
EXHIBIT 99.1

[0001327567-18-000018:8k_2_02:2]
Exhibit

[0001327567-18-000018:8k_2_02:3]
Exhibit 99.1

[0001327567-18-000018:8k_2_02:4]
Palo Alto Networks Reports Fiscal Fourth Quarter and Fiscal Year 2018 Financial Results

[0001327567-18-000018:8k_2_02:5]
| • | Fiscal fourth quarter revenue grows 29 percent year over year to $658.1 million; fiscal year 2018 revenue grows 29 percent year over year to $2.3 billion |

[0001327567-18-000018:8k_2_02:6]
| • | Fiscal fourth quarter billings grow 29 percent year over year to $868.1 million; fiscal year 2018 billings grow 25 percent year over year to $2.9 billion |

[0001327567-18-000018:8k_2_02:7]
| • | Deferred revenue grows 33 percent year over year to $2.4 billion |

[0001327567-18-000018:8k_2_02:8]
SANTA CLARA, Calif. — September 6, 2018 — Palo Alto Networks® (NYSE: PANW), the global cybersecurity leader, announced today financial results for its fiscal fourth quarter and fiscal year 2018, ended July 31, 2018.

[0001327567-18-000018:8k_2_02:9]
Total revenue for the fiscal fourth quarter 2018 grew 29 percent year over year to $658.1 million, compared with total revenue of $509.1 million for the fiscal fourth quarter 2017. GAAP net loss for the fiscal fourth quarter 2018 was $2.3 million, or $0.02 per diluted share, compared with GAAP net loss of $38.2 million, or $0.42 per diluted share, for the fiscal fourth quarter 2017.

[0001327567-18-000018:8k_2_02:10]
Non-GAAP net income for the fiscal fourth quarter 2018 was $125.0 million, or $1.28 per diluted share, compared with non-GAAP net income of $85.5 million, or $0.92 per diluted share, for the fiscal fourth quarter 2017. A reconciliation between GAAP and non-GAAP information is contained in the tables below.

[0001327567-18-000018:8k_2_02:11]
“We had a strong fourth quarter, continuing our global momentum at a growth rate that outpaces our peers and the cybersecurity market,” said Nikesh Arora, chief executive officer of Palo Alto Networks.

[0001327567-18-000018:8k_2_02:12]
“Enterprises are in the early stages of the cloud revolution. This poses new security challenges for businesses worldwide. We are becoming the strategic partner of choice to help businesses embrace the cloud and protect their digital information by reducing complexity and providing the same level of consistency, integration, and automation that we brought to network security.”

[0001327567-18-000018:8k_2_02:13]
“We are pleased with the strong finish to our fiscal fourth quarter and the year,” said Kathy Bonanno, chief financial officer of Palo Alto Networks. “Our revenue growth in the fourth quarter was solid across all regions, with particular strength in EMEA and APAC, each growing more than 40 percent year over year. We delivered on the bottom line as well, generating record cash flow from operations and free cash flow of $252.5 million.”

[0001327567-18-000018:8k_2_02:14]
Financial Outlook

[0001327567-18-000018:8k_2_02:15]
Palo Alto Networks provides guidance based on current market conditions and expectations. Palo Alto Networks adopted the new revenue standard ASC 606 as of August 1, 2018 using the full retrospective method. Therefore, the financial outlook provided is based on projected revenue under ASC 606. Please refer to the supplemental financial information posted on the company’s investor relations website (investors.paloaltonetworks.com) for select historical financial information adjusted under ASC 606.

[0001327567-18-000018:8k_2_02:16]
For the fiscal first quarter 2019, we expect:

[0001327567-18-000018:8k_2_02:17]
| • | Total revenue in the range of $625 to $635 million, representing year over year growth between 25 percent and 27 percent on an ASC 606 basis. |

[0001327567-18-000018:8k_2_02:18]
| • | Diluted non-GAAP net income per share in the range of $1.04 to $1.06 using 98 to 100 million shares on an ASC 606 basis. |

[0001327567-18-000018:8k_2_02:19]
2

[0001327567-18-000018:8k_2_02:20]
Guidance for non-GAAP financial measures excludes share-based compensation-related charges including share-based payroll tax expense, acquisition-related costs, amortization expense of acquired intangible assets, litigation-related charges, including legal settlements, facility exit costs, non-cash interest expense related to our convertible senior notes, foreign currency gains (losses), and income and other tax effects associated with these items, along with certain non-recurring expenses. We have not reconciled diluted non-GAAP net income per share guidance to GAAP net income (loss) per diluted share because we do not provide guidance on GAAP net income (loss) and would not be able to present the various reconciling cash and non-cash items between GAAP net income (loss) and non-GAAP net income, including share-based compensation expense, without unreasonable effort. Share-based compensation expense is impacted by the company’s future hiring and retention needs and, to a lesser extent, the future fair market value of the company’s common stock, all of which is difficult to predict and subject to constant change. The actual amounts of such reconciling items will have a significant impact on the company’s GAAP net income (loss) per diluted share.

[0001327567-18-000018:8k_2_02:21]
Conference Call Information

[0001327567-18-000018:8k_2_02:22]
Palo Alto Networks will host a conference call for analysts and investors to discuss its fiscal fourth quarter and fiscal year 2018 results and outlook for its fiscal first quarter 2019 today at 4:30 p.m. Eastern time/1:30 p.m. Pacific time. Open to the public, investors may access the call by dialing 1-800-458-4148 or 1-323-794-2597 and using conference ID 4260447. A live audio webcast of the conference call, along with supplemental financial information, will also be accessible from the “Investors” section of our website at investors.paloaltonetworks.com. Following the webcast, an archived version will be available on our website for one year. A telephonic replay of the call will be available three hours after the call, will run for ten days, and may be accessed by dialing 1-888-203-1112 or 1-719-457-0820 and entering the passcode 4260447.

[0001327567-18-000018:8k_2_02:23]
Forward-Looking Statements

[0001327567-18-000018:8k_2_02:24]
This press release contains forward-looking statements that involve risks and uncertainties, including statements regarding our future financial and operating performance, our financial outlook for the fiscal first quarter 2019, and us becoming the strategic partner of choice to help businesses embrace the cloud with respect to cybersecurity. There are a significant number of factors that could cause actual results to differ materially from statements made in this press release, including: our limited operating history; our ability as an organization to acquire and integrate other companies, products or technologies in a successful manner; risks associated with managing our rapid growth; the risks associated with new products and subscription and support offerings, including the discovery of software bugs; our ability to attract and retain new customers; delays in the development or release of new subscription offerings, or the failure to timely develop and achieve market acceptance of new products and subscriptions as well as existing products and subscription and support offerings; rapidly evolving technological developments in the market for security products and subscription and support offerings; length of sales cycles; and general market, political, economic and business conditions.

[0001327567-18-000018:8k_2_02:25]
Additional risks and uncertainties that could affect our financial results are included under the captions “Risk Factors” and “Management’s Discussion and Analysis of Financial Condition and Results of Operations” in our Quarterly Report on Form 10-Q filed with the SEC on June 5, 2018, which is available on our website at investors.paloaltonetworks.com and on the SEC’s website at www.sec.gov. Additional information will also be set forth in other filings that we make with the SEC from time to time. All forward-looking statements in this press release are based on information available to us as of the date hereof, and we do not assume any obligation to update the forward-looking statements provided to reflect events that occur or circumstances that exist after the date on which they were made.

[0001327567-18-000018:8k_2_02:26]
4

[0001327567-18-000018:8k_2_02:27]
Non-GAAP Financial Measures and Other Key Metrics

[0001327567-18-000018:8k_2_02:28]
Palo Alto Networks has provided in this press release financial information that has not been prepared in accordance with generally accepted accounting principles in the United States (GAAP). The company uses these non-GAAP financial measures and key metrics internally in analyzing its financial results and believes that the use of these non-GAAP financial measures and key metrics is useful to investors as an additional tool to evaluate ongoing operating results and trends, and in comparing the company’s financial results with other companies in its industry, many of which present similar non-GAAP financial measures or key metrics.

[0001327567-18-000018:8k_2_02:29]
The presentation of these non-GAAP financial measures and key metrics are not meant to be considered in isolation or as a substitute for comparable GAAP financial measures and should be read only in conjunction with the company’s consolidated financial statements prepared in accordance with GAAP. A reconciliation of the company’s historical non-GAAP financial measures and key metrics to their most directly comparable GAAP measures has been provided in the financial statement tables included in this press release, and investors are encouraged to review these reconciliations.

[0001327567-18-000018:8k_2_02:30]
Non-GAAP net income and net income per share, diluted. Palo Alto Networks defines non-GAAP net income as net income (loss) plus share-based compensation-related charges, including share-based payroll tax expense, acquisition-related costs, amortization expense of acquired intangible assets, litigation-related charges, including legal settlements, facility exit costs, non-cash interest expense related to the company’s convertible senior notes, and intellectual property restructuring-related charges. The company also excludes from non-GAAP net income the foreign currency gains (losses) and tax effects associated with these items in order to provide a complete picture of the company’s recurring core business operating results. The company defines non-GAAP net income per share, diluted, as non-GAAP net income divided by the weighted average diluted shares outstanding, which includes the potentially dilutive effect of the

[0001327567-18-000018:8k_2_02:31]
company’s employee equity incentive plan awards and the company’s convertible senior notes outstanding and related warrants, after giving effect to the anti-dilutive impact of the company’s note hedge agreements, which reduces the potential economic dilution that otherwise would occur upon conversion of the company’s convertible senior notes. Under GAAP, the anti-dilutive impact of the note hedge is not reflected in diluted shares outstanding. The company believes that excluding these items from non-GAAP net income and non-GAAP net income per share, diluted, provides management and investors with greater visibility into the underlying performance of the company’s core business operating results, meaning its operating performance excluding these items and, from time to time, other discrete charges that are infrequent in nature, over multiple periods.

[0001327567-18-000018:8k_2_02:32]
Billings. Palo Alto Networks defines billings as total revenue plus the change in total deferred revenue, net of acquired deferred revenue, during the period. The company considers billings to be a key metric used by management to manage the company’s business given the company’s hybrid-SaaS revenue model, and believes billings provides investors with an important indicator of the health and visibility of the company’s business because it includes subscription and support revenue, which is recognized ratably over the contractual service period, and product revenue, which is recognized at the time of shipment, provided that all other revenue recognition criteria have been met. The company considers billings to be a useful metric for management and investors, particularly if sales of subscriptions continue to increase and the company experiences strong renewal rates for subscriptions and support.

[0001327567-18-000018:8k_2_02:33]
Free cash flow. Palo Alto Networks defines free cash flow as cash provided by operating activities less purchases of property, equipment, and other assets. The company considers free cash flow to be a profitability and liquidity measure that provides useful information to management and investors about the amount of cash generated by the business after necessary capital expenditures.

[0001327567-18-000018:8k_2_02:34]
6

[0001327567-18-000018:8k_2_02:35]
Investors are cautioned that there are a number of limitations associated with the use of non-GAAP financial measures and key metrics as analytical tools. In particular, the billings metric reported by the company includes amounts that have not yet been recognized as revenue, and free cash flow does not represent the total increase or decrease in our cash balance for the period. In addition, many of the adjustments to the company’s GAAP financial measures reflect the exclusion of items that are recurring and will be reflected in the company’s financial results for the foreseeable future, such as share-based compensation, which is an important part of Palo Alto Networks employees’ compensation and impacts their performance. Furthermore, these non-GAAP financial measures are not based on any standardized methodology prescribed by GAAP, and the components that Palo Alto Networks excludes in its calculation of non-GAAP financial measures may differ from the components that its peer companies exclude when they report their non-GAAP results of operations. Palo Alto Networks compensates for these limitations by providing specific information regarding the GAAP amounts excluded from these non-GAAP financial measures. In the future, the company may also exclude non-recurring expenses and other expenses that do not reflect the company’s core business operating results.

[0001327567-18-000018:8k_2_02:36]
About Palo Alto Networks

[0001327567-18-000018:8k_2_02:37]
We are the global cybersecurity leader, known for always challenging the security status quo. Our mission is to protect our way of life in the digital age by preventing successful cyberattacks. This has given us the privilege of safely enabling tens of thousands of organizations and their customers. Our pioneering Security Operating Platform emboldens their digital transformation with continuous innovation that seizes the latest breakthroughs in security, automation, and analytics. By delivering a true platform and empowering a growing ecosystem of change-makers like us, we provide highly effective and innovative cybersecurity across clouds, networks, and mobile devices.

[0001327567-18-000018:8k_2_02:38]
Palo Alto Networks and the Palo Alto Networks logo are trademarks of Palo Alto Networks, Inc. in the United States and in jurisdictions throughout the world. All other trademarks, trade names or service marks used or mentioned herein belong to their respective owners.

[0001327567-18-000018:8k_2_02:39]
Media Contact:

[0001327567-18-000018:8k_2_02:40]
Kristen Batch

[0001327567-18-000018:8k_2_02:41]
Senior Vice President of Corporate Communications, Palo Alto Networks

[0001327567-18-000018:8k_2_02:42]
Mobile: 503-516-6297

[0001327567-18-000018:8k_2_02:43]
kbatch@paloaltonetworks.com

[0001327567-18-000018:8k_2_02:44]
Investor Relations Contact:

[0001327567-18-000018:8k_2_02:45]
Amber Ossman

[0001327567-18-000018:8k_2_02:46]
Director, Investor Relations, Palo Alto Networks

[0001327567-18-000018:8k_2_02:47]
Work: 408-753-4235

[0001327567-18-000018:8k_2_02:48]
aossman@paloaltonetworks.com

[0001327567-18-000018:8k_2_02:49]
| Palo Alto Networks, Inc. |
| Preliminary Consolidated Statements of Operations |
| (In millions, except per share data) |
| (Unaudited) |
|  | Three Months Ended July 31, |  | Year Ended July 31, |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Revenue: |  |  |  |  |  |  |  |
| Product | $ | 267.6 |  |  | $ | 212.3 |  |  | $ | 871.5 |  |  | $ | 709.1 |  |
| Subscription and support | 390.5 |  |  | 296.8 |  |  | 1,401.6 |  |  | 1,052.5 |  |
| Total revenue | 658.1 |  |  | 509.1 |  |  | 2,273.1 |  |  | 1,761.6 |  |
| Cost of revenue: |  |  |  |  |  |  |  |
| Product | 82.0 |  |  | 63.7 |  |  | 272.4 |  |  | 201.4 |  |
| Subscription and support | 102.7 |  |  | 74.8 |  |  | 372.9 |  |  | 275.2 |  |
| Total cost of revenue | 184.7 |  |  | 138.5 |  |  | 645.3 |  |  | 476.6 |  |
| Total gross profit | 473.4 |  |  | 370.6 |  |  | 1,627.8 |  |  | 1,285.0 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 110.3 |  |  | 87.3 |  |  | 400.7 |  |  | 347.4 |  |
| Sales and marketing | 297.8 |  |  | 245.4 |  |  | 1,098.4 |  |  | 919.1 |  |
| General and administrative | 56.7 |  |  | 65.2 |  |  | 257.8 |  |  | 198.3 |  |
| Total operating expenses | 464.8 |  |  | 397.9 |  |  | 1,756.9 |  |  | 1,464.8 |  |
| Operating income (loss) | 8.6 |  |  | (27.3 | ) |  | (129.1 | ) |  | (179.8 | ) |
| Interest expense | (10.4 | ) |  | (6.2 | ) |  | (29.6 | ) |  | (24.5 | ) |
| Other income, net | 10.2 |  |  | 2.9 |  |  | 28.5 |  |  | 10.2 |  |
| Income (loss) before income taxes | 8.4 |  |  | (30.6 | ) |  | (130.2 | ) |  | (194.1 | ) |
| Provision for income taxes | 10.7 |  |  | 7.6 |  |  | 17.7 |  |  | 22.5 |  |
| Net loss | $ | (2.3 | ) |  | $ | (38.2 | ) |  | $ | (147.9 | ) |  | $ | (216.6 | ) |
| Net loss per share, basic and diluted | $ | (0.02 | ) |  | $ | (0.42 | ) |  | $ | (1.61 | ) |  | $ | (2.39 | ) |
| Weighted-average shares used to compute net loss per share, basic and diluted | 92.8 |  |  | 90.9 |  |  | 91.7 |  |  | 90.6 |  |

[0001327567-18-000018:8k_2_02:50]
9

[0001327567-18-000018:8k_2_02:51]
| Palo Alto Networks, Inc. |
| Reconciliation of GAAP to Non-GAAP Financial Measures |
| (In millions, except per share amounts) |
| (Unaudited) |
|  | Three Months Ended |  | Year Ended |
|  | July 31, |  | July 31, |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| GAAP net loss | $ | (2.3 | ) |  | $ | (38.2 | ) |  | $ | (147.9 | ) |  | $ | (216.6 | ) |
| Share-based compensation related charges | 128.1 |  |  | 120.9 |  |  | 516.4 |  |  | 488.9 |  |
| Acquisition related costs(1) | 4.6 |  |  | — |  |  | 17.9 |  |  | 3.1 |  |
| Amortization expense of acquired intangible assets | 7.0 |  |  | 2.5 |  |  | 15.6 |  |  | 8.9 |  |
| Litigation related charges(2) | 3.1 |  |  | 3.1 |  |  | 12.3 |  |  | 12.3 |  |
| Facility exit costs(3) | — |  |  | 21.3 |  |  | 40.8 |  |  | 21.3 |  |
| Non-cash interest expense related to convertible notes | 9.6 |  |  | 6.2 |  |  | 28.8 |  |  | 24.5 |  |
| Foreign currency (gain) loss associated with non-GAAP adjustments | (0.5 | ) |  | 0.6 |  |  | (1.0 | ) |  | 2.4 |  |
| Income tax and other tax adjustments related to the above(4) | (24.6 | ) |  | (30.9 | ) |  | (101.5 | ) |  | (91.4 | ) |
| Non-GAAP net income | $ | 125.0 |  |  | $ | 85.5 |  |  | $ | 381.4 |  |  | $ | 253.4 |  |
| GAAP net loss per share, diluted | $ | (0.02 | ) |  | $ | (0.42 | ) |  | $ | (1.61 | ) |  | $ | (2.39 | ) |
| Share-based compensation related charges | 1.32 |  |  | 1.31 |  |  | 5.47 |  |  | 5.30 |  |
| Acquisition related costs(1) | 0.05 |  |  | 0.00 |  |  | 0.20 |  |  | 0.03 |  |
| Amortization expense of acquired intangible assets | 0.08 |  |  | 0.03 |  |  | 0.17 |  |  | 0.10 |  |
| Litigation related charges(2) | 0.03 |  |  | 0.03 |  |  | 0.13 |  |  | 0.14 |  |
| Facility exit costs(3) | 0.00 |  |  | 0.23 |  |  | 0.44 |  |  | 0.24 |  |
| Non-cash interest expense related to convertible notes | 0.10 |  |  | 0.07 |  |  | 0.31 |  |  | 0.27 |  |
| Foreign currency (gain) loss associated with non-GAAP adjustments | (0.01 | ) |  | 0.01 |  |  | (0.01 | ) |  | 0.03 |  |
| Income tax and other tax adjustments related to the above(4) | (0.27 | ) |  | (0.34 | ) |  | (1.11 | ) |  | (1.01 | ) |
| Non-GAAP net income per share, diluted | $ | 1.28 |  |  | $ | 0.92 |  |  | $ | 3.99 |  |  | $ | 2.71 |  |
| GAAP weighted-average shares used to compute net loss per share, diluted | 92.8 |  |  | 90.9 |  |  | 91.7 |  |  | 90.6 |  |
| Weighted-average effect of potentially dilutive securities(5) | 5.2 |  |  | 2.4 |  |  | 3.8 |  |  | 3.0 |  |
| Non-GAAP weighted-average shares used to compute net income per share, diluted | 98.0 |  |  | 93.3 |  |  | 95.5 |  |  | 93.6 |  |
| Net cash provided by operating activities | $ | 277.9 |  |  | $ | 239.5 |  |  | $ | 1,037.0 |  |  | $ | 868.5 |  |
| Less: purchases of property, equipment, and other assets | 25.4 |  |  | 49.2 |  |  | 112.0 |  |  | 163.4 |  |
| Free cash flow (non-GAAP) | $ | 252.5 |  |  | $ | 190.3 |  |  | $ | 925.0 |  |  | $ | 705.1 |  |
| Net cash used in investing activities | $ | (206.4 | ) |  | $ | (61.5 | ) |  | $ | (520.0 | ) |  | $ | (472.6 | ) |
| Net cash provided by (used in) financing activities | $ | 1,486.4 |  |  | $ | (125.7 | ) |  | $ | 1,245.6 |  |  | $ | (386.0 | ) |

[0001327567-18-000018:8k_2_02:52]
___________

[0001327567-18-000018:8k_2_02:53]
| (1) | Consists of acquisition transaction costs, share-based compensation related to the cash settlement of certain equity awards, and costs to terminate certain employment, operating lease, and other contracts of the acquired companies. |

[0001327567-18-000018:8k_2_02:54]
| (2) | Consists of the amortization of intellectual property licenses. |

[0001327567-18-000018:8k_2_02:55]
| (3) | Consists of charges related to the relocation of the company’s corporate headquarters, including an impairment loss of $20.9 million and accelerated depreciation during the fiscal year ended July 31, 2017, and a cease-use loss of $39.2 million and accelerated depreciation during the fiscal year ended July 31, 2018, as well as charges related to the relocation of the company’s research and development center in Israel, including a cease-use loss of $1.3 million and accelerated depreciation during the fiscal year ended July 31, 2018. |

[0001327567-18-000018:8k_2_02:56]
| (4) | The company changed its non-GAAP effective tax rate from 31% to 22% in its second quarter of fiscal 2018 due to the reduction of the U.S. federal corporate income tax rate under the U.S. Tax Cuts and Jobs Act, which was enacted into law on December 22, 2017. |

[0001327567-18-000018:8k_2_02:57]
| (5) | Non-GAAP net income per share, diluted, includes the potentially dilutive effect of employee equity incentive plan awards and convertible senior notes outstanding and related warrants. In addition, non-GAAP net income per share, diluted, includes the anti-dilutive impact of the company’s note hedge agreements, which reduced the potentially dilutive effect of the convertible notes by 2.5 million shares and 1.8 million shares for the fiscal fourth quarter and fiscal year ended July 31, 2018, respectively, and 1.0 million shares and 0.9 million shares for the fiscal fourth quarter and fiscal year ended July 31, 2017, respectively. |

[0001327567-18-000018:8k_2_02:58]
10

[0001327567-18-000018:8k_2_02:59]
| Palo Alto Networks, Inc. |
| Calculation of Billings |
| (In millions) |
| (Unaudited) |
|  | Three Months Ended |  | Year Ended |
|  | July 31, |  | July 31, |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Total revenue | $ | 658.1 |  |  | $ | 509.1 |  |  | $ | 2,273.1 |  |  | $ | 1,761.6 |  |
| Add: change in total deferred revenue, net of acquired deferred revenue | 210.0 |  |  | 161.7 |  |  | 587.1 |  |  | 531.8 |  |
| Billings | $ | 868.1 |  |  | $ | 670.8 |  |  | $ | 2,860.2 |  |  | $ | 2,293.4 |  |

[0001327567-18-000018:8k_2_02:60]
11

[0001327567-18-000018:8k_2_02:61]
| Palo Alto Networks, Inc. |
| Preliminary Consolidated Balance Sheets |
| (In millions) |
| (Unaudited) |
|  | July 31, 2018 |  | July 31, 2017 |
| Assets |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 2,506.9 |  |  | $ | 744.3 |  |
| Short-term investments | 896.5 |  |  | 630.7 |  |
| Accounts receivable, net | 467.3 |  |  | 432.1 |  |
| Prepaid expenses and other current assets | 261.3 |  |  | 169.2 |  |
| Total current assets | 4,132.0 |  |  | 1,976.3 |  |
| Property and equipment, net | 273.1 |  |  | 211.1 |  |
| Long-term investments | 547.5 |  |  | 789.3 |  |
| Goodwill | 522.8 |  |  | 238.8 |  |
| Intangible assets, net | 140.8 |  |  | 53.7 |  |
| Other assets | 206.8 |  |  | 169.1 |  |
| Total assets | $ | 5,823.0 |  |  | $ | 3,438.3 |  |
| Liabilities, temporary equity, and stockholders’ equity |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 49.4 |  |  | $ | 35.5 |  |
| Accrued compensation | 163.7 |  |  | 117.5 |  |
| Accrued and other liabilities | 107.0 |  |  | 79.9 |  |
| Deferred revenue | 1,268.9 |  |  | 968.4 |  |
| Convertible senior notes, net | 550.4 |  |  | — |  |
| Total current liabilities | 2,139.4 |  |  | 1,201.3 |  |
| Convertible senior notes, net | 1,369.7 |  |  | 524.7 |  |
| Long-term deferred revenue | 1,096.0 |  |  | 805.1 |  |
| Other long-term liabilities | 229.6 |  |  | 147.6 |  |
| Temporary equity | 21.9 |  |  | — |  |
| Stockholders’ equity: |  |  |  |
| Preferred stock | — |  |  | — |  |
| Common stock and additional paid-in capital | 1,967.4 |  |  | 1,599.7 |  |
| Accumulated other comprehensive loss | (16.4 | ) |  | (3.4 | ) |
| Accumulated deficit | (984.6 | ) |  | (836.7 | ) |
| Total stockholders’ equity | 966.4 |  |  | 759.6 |  |
| Total liabilities, temporary equity, and stockholders’ equity | $ | 5,823.0 |  |  | $ | 3,438.3 |  |

[0001327567-18-000018:8k_2_02:62]
12

[0001327567-18-000018:8k_2_02:63]
| Palo Alto Networks, Inc. |
| Preliminary Consolidated Statements of Cash Flows |
| (In millions) |
| (Unaudited) |
|  | Year Ended July 31, |
|  | 2018 |  | 2017 |
| Cash flows from operating activities |  |  |  |
| Net loss | $ | (147.9 | ) |  | $ | (216.6 | ) |
| Adjustments to reconcile net loss to net cash provided by operating activities: |  |  |  |
| Share-based compensation for equity based awards | 496.7 |  |  | 474.5 |  |
| Depreciation and amortization | 96.4 |  |  | 59.8 |  |
| Cease-use loss and asset impairment related to facility exit | 41.1 |  |  | 20.9 |  |
| Amortization of debt discount and debt issuance costs | 28.8 |  |  | 24.5 |  |
| Amortization of investment premiums, net of accretion of purchase discounts | 0.5 |  |  | 2.7 |  |
| Changes in operating assets and liabilities, net of effects of acquisitions: |  |  |  |
| Accounts receivable, net | (33.0 | ) |  | (82.9 | ) |
| Prepaid expenses and other assets | (125.5 | ) |  | (48.1 | ) |
| Accounts payable | 3.7 |  |  | 5.9 |  |
| Accrued compensation | 44.2 |  |  | 42.8 |  |
| Accrued and other liabilities | 44.9 |  |  | 53.2 |  |
| Deferred revenue | 587.1 |  |  | 531.8 |  |
| Net cash provided by operating activities(1) | 1,037.0 |  |  | 868.5 |  |
| Cash flows from investing activities |  |  |  |
| Purchases of investments | (725.7 | ) |  | (995.9 | ) |
| Proceeds from maturities of investments | 691.8 |  |  | 777.4 |  |
| Business acquisitions, net of cash acquired | (374.1 | ) |  | (90.7 | ) |
| Purchases of property, equipment, and other assets | (112.0 | ) |  | (163.4 | ) |
| Net cash used in investing activities | (520.0 | ) |  | (472.6 | ) |
| Cash flows from financing activities |  |  |  |
| Proceeds from borrowings on convertible senior notes, net | 1,682.4 |  |  | — |  |
| Proceeds from issuance of warrants | 145.4 |  |  | — |  |
| Purchase of note hedges | (332.0 | ) |  | — |  |
| Repurchases of common stock | (259.1 | ) |  | (411.0 | ) |
| Proceeds from sales of shares through employee equity incentive plans | 52.6 |  |  | 46.4 |  |
| Payments for taxes related to net share settlement of equity awards | (43.7 | ) |  | (21.4 | ) |
| Net cash provided by (used in) financing activities | 1,245.6 |  |  | (386.0 | ) |
| Net increase in cash and cash equivalents | 1,762.6 |  |  | 9.9 |  |
| Cash and cash equivalents - beginning of period | 744.3 |  |  | 734.4 |  |
| Cash and cash equivalents - end of period | $ | 2,506.9 |  |  | $ | 744.3 |  |
| Non-cash investing and financing activities |  |  |  |
| Property and equipment acquired through lease incentives | $ | 37.8 |  |  | $ | — |  |

[0001327567-18-000018:8k_2_02:64]
___________

[0001327567-18-000018:8k_2_02:65]
| (1) | Cash provided by operating activities for the fiscal year ended July 31, 2018 includes the receipt of an upfront cash reimbursement of $38.2 million from the company’s landlords during the three months ended October 31, 2017, in connection with the exercise of their option to amend the lease payment schedules and eliminate the rent holiday periods under certain of the company’s lease agreements. The upfront cash reimbursement will be applied against rental payments due in fiscal years 2018 through 2020 under the amended lease agreements. |

[0001327567-18-000018:8k_2_02:66]
13

## item 1.01 — body, verbatim

[0001327567-18-000018:8k_body:1]
Item 1.01 Entry into a Material Definitive Agreement.

[0001327567-18-000018:8k_body:2]
On September 4, 2018, Palo Alto Networks, Inc. (the “Company”) entered into a Credit Agreement, by and among the Company, the lenders from time to time party thereto and Citibank, N.A., as administrative agent (the “Credit Agreement”). The Credit Agreement provides for an unsecured revolving loan facility in an initial aggregate principal amount of $400.0 million. The Company may from time to time arrange with existing lenders and/or new lenders, subject to certain requirements, to provide up to an aggregate of $350.0 million in additional commitments (for an aggregate amount of up to $750.0 million). Pursuant to the Credit Agreement, certain material domestic subsidiaries of the Company are required to guarantee of the obligations under the Credit Agreement. As of September 4, 2018, there were no guarantors under the Credit Agreement and no outstanding revolving loans under the Credit Agreement.

[0001327567-18-000018:8k_body:3]
The proceeds of the loans under the Credit Agreement may be used by the Company for general corporate purposes of the Company and its subsidiaries. The Company may borrow, repay and reborrow funds under the revolving facility until its maturity on the earlier of (i) September 4, 2023 and (ii) the date that is 91 days prior to the maturity of the Company’s 0.75% Convertible Senior Notes due 2023 (the “2023 Notes”) if on such date (x) any 2023 Notes are still outstanding and (y) the Company has consolidated unrestricted cash and cash equivalents of less than the sum of (A) the principal amount of 2023 Notes outstanding on such date and (B) $400.0 million (the “Maturity Date”). On the Maturity Date, the revolving facility will terminate, and all outstanding loans under such facility, together with all accrued and unpaid interest and fees, must be repaid. Revolving loans may be prepaid and revolving loan commitments may be permanently reduced by the Company in whole or in part, subject to certain minimum thresholds, without penalty or premium, subject to customary breakage costs.

[0001327567-18-000018:8k_body:4]
Unused commitments under the Credit Agreement will be subject to a commitment fee, payable in arrears on the last day of March, June, September and December, ranging from 0.125% to 0.250%, depending on the Company’s total leverage ratio (determined pursuant to the Credit Agreement) at such time. The Company is also obligated to pay other customary closing fees and administration fees for a credit facility of this size and type.

[0001327567-18-000018:8k_body:5]
Borrowings under the Credit Agreement will bear interest, at the Company’s option, at either: (i) the Alternate Base Rate (as defined in the Credit Agreement), plus the Applicable Rate (as defined in the Credit Agreement) or (ii) the Adjusted LIBO Rate (as defined in the Credit Agreement), plus the Applicable Rate. The Applicable Rate in each case is determined based on the Company’s leverage ratio (determined pursuant to the Credit Agreement) and ranges from 0.00% to 0.75% for borrowings bearing interest at the Alternate Base Rate and 1.00% to 1.75% for borrowings bearing interest based on the Adjusted LIBO Rate. Interest is payable on the last day of March, June, September and December with respect to borrowings bearing interest at the Alternate Base Rate, or on the last day of an interest period, but at least every three months, with respect to borrowings bearing interest at the Adjusted LIBO Rate.

[0001327567-18-000018:8k_body:6]
The Credit Agreement contains customary representations and warranties by the Company, which include customary use of materiality, material adverse effect and knowledge qualifiers. The Credit Agreement contains customary affirmative and negative covenants including, among other requirements, negative covenants that restrict the ability of the subsidiaries of the Company to incur indebtedness and the ability of Company and its subsidiaries to create liens, make certain investments, loans, advances or acquisitions, to merge or consolidate with another entity or sell, transfer or lease substantially all assets of the Company and its subsidiaries taken as a whole, make certain restricted payments, enter into or engage in transactions with affiliates, enter into certain swap agreements and enter into certain restrictive agreements, in each case, subject to certain exceptions. Further, the Credit Agreement contains covenants requiring the Company to maintain (i) a leverage ratio (determined in accordance with the Credit Agreement) not to exceed 3.50 to 1.00 as of the last day of each fiscal quarter, beginning on January 31, 2019 and (ii) an interest coverage ratio (determined in accordance with the Credit Agreement) of at least 3.00 to 1.00 as of the last day of each fiscal quarter, beginning on January 31, 2019.

[0001327567-18-000018:8k_body:7]
The Credit Agreement contains events of default that include, among others, non-payment of principal, interest or fees, breach of covenants, inaccuracy of representations and warranties, cross defaults to certain other indebtedness, bankruptcy and insolvency events with respect to the Company and certain of its subsidiaries, material

[0001327567-18-000018:8k_body:8]
judgments, and events constituting a change of control. If any principal is not paid when due, interest on such amount will accrue at an increased rate. Upon the occurrence and during the continuance of an event of default, the lenders may accelerate the Company’s obligations under the Credit Agreement; however, that acceleration will be automatic in the case of bankruptcy and insolvency events of default involving the Company.

[0001327567-18-000018:8k_body:9]
A copy of the Credit Agreement is attached hereto as Exhibit 10.1. The foregoing description of the Credit Agreement does not purport to be complete and is qualified in its entirety by reference to the Credit Agreement.
