# PANW MD&A — 0001327567-18-000024


## mdna

[0001327567-18-000024:mdna:1]
| ITEM 7. | MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS |

[0001327567-18-000024:mdna:2]
The following discussion and analysis of our financial condition and results of operations should be read in conjunction with our consolidated financial statements and related notes appearing elsewhere in this Annual Report on Form 10-K. The following discussion and analysis contains forward-looking statements based on current expectations and assumptions that are subject to risks and uncertainties, which could cause our actual results to differ materially from those anticipated or implied by any forward-looking statements. Factors that could cause or contribute to such differences include, but are not limited to, those discussed in this Annual Report on Form 10-K, and in particular, the risks discussed under the caption “Risk Factors” in Part I, Item 1A of this report.

[0001327567-18-000024:mdna:3]
Our Management’s Discussion and Analysis of Financial Condition and Results of Operations (“MD&A”) is organized as follows:

[0001327567-18-000024:mdna:4]
| • | Overview. A discussion of our business and overall analysis of financial and other highlights in order to provide context for the remainder of MD&A. |

[0001327567-18-000024:mdna:5]
| • | Key Financial Metrics. A summary of our GAAP and non-GAAP key financial metrics, which management monitors to evaluate our performance. |

[0001327567-18-000024:mdna:6]
| • | Results of Operations. A discussion of the nature and trends in our financial results and an analysis of our financial results comparing fiscal 2018 to 2017 and fiscal 2017 to 2016. |

[0001327567-18-000024:mdna:7]
| • | Liquidity and Capital Resources. An analysis of changes in our balance sheets and cash flows, and a discussion of our financial condition and our ability to meet cash needs. |

[0001327567-18-000024:mdna:8]
| • | Contractual Obligations and Commitments. An overview of our contractual obligations, contingent liabilities, commitments, and off-balance sheet arrangements outstanding as of July 31, 2018, including expected payment schedules. |

[0001327567-18-000024:mdna:9]
| • | Critical Accounting Estimates. A discussion of our accounting policies that require critical estimates, assumptions, and judgments. |

[0001327567-18-000024:mdna:10]
| • | Recent Accounting Pronouncements. A discussion of expected impacts of impending accounting changes on financial information to be reported in the future. |

[0001327567-18-000024:mdna:11]
Overview

[0001327567-18-000024:mdna:12]
We have pioneered the next generation of security through our innovative Security Operating Platform that empowers enterprises, service providers, and government entities to secure their organizations by safely enabling applications and data running in their networks, on their endpoints, and in the cloud, and by preventing breaches that stem from targeted cyberattacks. Our platform uses an innovative traffic classification engine that identifies network traffic by application, user, and content and provides consistent security across the network, endpoint, and cloud. Accordingly, our platform enables our end-customers to pursue transformative digital initiatives, like public cloud and mobility, that grow their business, while maintaining the visibility and control needed to protect their valued data and critical control systems. We believe the architecture of our platform offers superior performance compared to legacy approaches and reduces the total cost of ownership for organizations by simplifying their security operations and infrastructure and eliminating the need for multiple, stand-alone hardware and software security products, and consists of four primary security capabilities:

[0001327567-18-000024:mdna:13]
| • | Security for networks through our Next-Generation Firewalls, available as physical appliances, virtual appliances (called VM-Series), or a cloud-delivered service (called GlobalProtect cloud service) and Panorama management delivered as an appliance or as a virtual machine for the public or private cloud. |

[0001327567-18-000024:mdna:14]
| • | Security for endpoints through our Traps advanced endpoint protection software, delivered as a light-weight software agent with cloud or on-premise management capabilities. |

[0001327567-18-000024:mdna:15]
| • | Security for the cloud through our VM-Series for in-line protection of workloads in public and private clouds, Traps for host-based public cloud infrastructure protection, Evident for infrastructure monitoring and compliance in public clouds, and Aperture for protecting SaaS applications. These products are delivered as software or SaaS applications. |

[0001327567-18-000024:mdna:16]
| • | Other security services, such as WildFire, Threat Prevention, URL Filtering, and GlobalProtect subscriptions that are delivered as attached software services to our appliances, as well as applications delivered in connection with our Application Framework, such as AutoFocus, Magnifier, and Logging Service that are delivered as SaaS applications. |

[0001327567-18-000024:mdna:17]
For fiscal 2018, 2017, and 2016, total revenue was $2.3 billion, $1.8 billion, and $1.4 billion, respectively, representing year-over-year growth of 29.0% for fiscal 2018 and 27.8% for fiscal 2017. Our growth reflects the increased adoption of our hybrid SaaS revenue model, which consists of product, subscriptions, and support. We believe this model will enable us to benefit from recurring revenues as we continue to grow our installed end-customer base. As of July 31, 2018, we had more than 54,000 end-customers in

[0001327567-18-000024:mdna:18]
- 37 -

[0001327567-18-000024:mdna:19]
over 150 countries. Our end-customers represent a broad range of industries including education, energy, financial services, government entities, healthcare, Internet and media, manufacturing, public sector, and telecommunications, and include some of the largest Fortune 100 and Global 2000 companies in the world. We maintain a field sales force that works closely with our channel partners in developing sales opportunities. We use a two-tiered, indirect fulfillment model whereby we sell our products, subscriptions, and support to our distributors, which, in turn, sell to our resellers, which then sell to our end-customers.

[0001327567-18-000024:mdna:20]
Our product revenue grew to $871.5 million or 38.3% of total revenue for fiscal 2018, representing year-over-year growth of 22.9%. Product revenue is generated from sales of our appliances, primarily our Next-Generation Firewall, which is available in physical and virtualized form. Our Next-Generation Firewall incorporates our proprietary PAN-OS operating system, which provides a consistent set of capabilities across our entire product line. Our products are designed for different performance requirements throughout an organization, ranging from our PA-200, which is designed for enterprise remote offices, to our top-of-the-line PA-7080, which is especially suited for very large enterprise deployments and service provider customers. The same firewall functionality that is delivered in our physical appliances is also available in our VM-Series virtual firewalls, which secure virtualized and cloud-based computing environments.

[0001327567-18-000024:mdna:21]
Our subscription and support revenue grew to $1.4 billion or 61.7% of total revenue for fiscal 2018, representing year-over-year growth of 33.2%. Our subscriptions provide our end-customers with real-time access to the latest antivirus, intrusion prevention, web filtering, and modern malware prevention capabilities across the network, endpoints, and the cloud. When end-customers purchase our physical or virtual firewall appliances, they typically purchase support in order to receive ongoing security updates, upgrades, bug fixes, and repairs. In addition to the subscriptions purchased with these appliances, end-customers may also purchase other subscriptions on a per-user, per-endpoint, or capacity-based basis.

[0001327567-18-000024:mdna:22]
We continue to invest in innovation as we evolve and further extend the capabilities of our platform, as we believe that innovation and timely development of new features and products is essential to meeting the needs of our end-customers and improving our competitive position. We introduced several new offerings during fiscal 2018, including:

[0001327567-18-000024:mdna:23]
| • | our GlobalProtect cloud service subscription, which provides our Security Operating Platform as a cloud-based service for remote offices and mobile users; |

[0001327567-18-000024:mdna:24]
| • | our Logging Service subscription, which functions as the central cloud-based repository for application data and logs generated by our security offerings, including those of our firewalls and GlobalProtect cloud service subscription, and allows end-customers to collect data without needing to plan for local processing power and storage; |

[0001327567-18-000024:mdna:25]
| • | Magnifier, a cloud-based subscription that enables organizations to identify and prevent behavior-based threats by applying machine learning to rich network, endpoint, and cloud data; |

[0001327567-18-000024:mdna:26]
| • | PAN-OS 8.1, with over 60 new features, and several new models of appliances, including the PA-3200 series, which increase SSL decryption throughput, bring higher performance and capacity for securing large data centers, and provide additional capabilities for managing large firewall deployments; and |

[0001327567-18-000024:mdna:27]
| • | Traps 5.0, which included a cloud-delivered management service and integration with our Logging Service to allow for the collection of detailed endpoint event data. |

[0001327567-18-000024:mdna:28]
We also expanded the capabilities of our platform with extended protections to the GCP and enhanced capabilities for AWS and Azure environments to enable customers to easily integrate with their cloud infrastructure and workloads in multi-cloud environments. Further, in March 2018, we acquired Evident.io, which has expanded our API-based security capabilities for the public cloud with the addition of Evident.io’s cloud services infrastructure protection technology, and, in April 2018, we acquired Secdo, which expands the functionality of Traps, as well as other capabilities of our platform, by adding endpoint detection and response capabilities, including unique data collection and visualization.

[0001327567-18-000024:mdna:29]
We believe that the growth of our business and our short-term and long-term success are dependent upon many factors, including our ability to extend our technology leadership, grow our base of end-customers, expand deployment of our platform and support offerings within existing end-customers, and focus on end-customer satisfaction. To manage any future growth effectively, we must continue to improve and expand our information technology and financial infrastructure, our operating and administrative systems and controls, and our ability to manage headcount, capital, and processes in an efficient manner. While these areas present significant opportunities for us, they also pose challenges and risks that we must successfully address in order to sustain the growth of our business and improve our operating results. For additional information regarding the challenges and risks we face, see the “Risk Factors” section in Part I, Item 1A of this Annual Report on Form 10-K.

[0001327567-18-000024:mdna:30]
- 38 -

[0001327567-18-000024:mdna:31]
Key Financial Metrics

[0001327567-18-000024:mdna:32]
We monitor the key financial metrics set forth in the tables below to help us evaluate growth trends, establish budgets, measure the effectiveness of our sales and marketing efforts, and assess operational efficiencies. We discuss revenue, gross margin, and the components of operating loss and margin below under “—Results of Operations.”

[0001327567-18-000024:mdna:33]
|  | Year Ended July 31, |
|  | 2018 |  | 2017 |  | 2016 |
|  | (dollars in millions) |
| Total revenue | $ | 2,273.1 |  |  | $ | 1,761.6 |  |  | $ | 1,378.5 |  |
| Total revenue year-over-year percentage increase | 29.0 | % |  | 27.8 | % |  | 48.5 | % |
| Gross margin | 71.6 | % |  | 72.9 | % |  | 73.2 | % |
| Operating loss | $ | (129.1 | ) |  | $ | (179.8 | ) |  | $ | (157.3 | ) |
| Operating margin | (5.7 | )% |  | (10.2 | )% |  | (11.4 | )% |
| Billings | $ | 2,860.2 |  |  | $ | 2,293.4 |  |  | $ | 1,905.6 |  |
| Billings year-over-year percentage increase | 24.7 | % |  | 20.4 | % |  | 56.3 | % |
| Cash flow provided by operating activities | $ | 1,037.0 |  |  | $ | 868.5 |  |  | $ | 658.6 |  |
| Free cash flow (non-GAAP) | $ | 925.0 |  |  | $ | 705.1 |  |  | $ | 586.1 |  |

[0001327567-18-000024:mdna:34]
|  | July 31, |
|  | 2018 |  | 2017 |
|  | (in millions) |
| Total deferred revenue | $ | 2,364.9 |  |  | $ | 1,773.5 |  |
| Cash, cash equivalents, and investments | $ | 3,950.9 |  |  | $ | 2,164.3 |  |

[0001327567-18-000024:mdna:35]
| • | Deferred Revenue. Our deferred revenue primarily consists of amounts that have been invoiced but have not been recognized as revenue as of the period end. The majority of our deferred revenue balance consists of subscription and support revenue that is recognized ratably over the contractual service period. We monitor our deferred revenue balance because it represents a significant portion of revenue to be recognized in future periods. |

[0001327567-18-000024:mdna:36]
| • | Billings. We define billings as total revenue plus the change in total deferred revenue, net of acquired deferred revenue, during the period. We consider billings to be a key measure used by management to manage our business given our hybrid SaaS revenue model, and believe billings provides investors with an important indicator of the health and visibility of our business because it includes subscription and support revenue, which is recognized ratably over the contractual service period, and product revenue, which is recognized at the time of shipment, provided that all other revenue recognition criteria have been met. We consider billings to be a useful metric for management and investors, particularly if we continue to experience increased sales of subscriptions and strong renewal rates for subscription and support offerings, and as we monitor our near term cash flows. While we believe that billings provides useful information to investors and others in understanding and evaluating our operating results in the same manner as our management, it is important to note that other companies, including companies in our industry, may not use billings, may calculate billings differently, may have different billing frequencies, or may use other financial measures to evaluate their performance, all of which could reduce the usefulness of billings as a comparative measure. We calculate billings in the following manner: |

[0001327567-18-000024:mdna:37]
|  | Year Ended July 31, |
|  | 2018 |  | 2017 |  | 2016 |
|  | (in millions) |
| Billings: |  |  |  |  |  |
| Total revenue | $ | 2,273.1 |  |  | $ | 1,761.6 |  |  | $ | 1,378.5 |  |
| Add: change in total deferred revenue, net of acquired deferred revenue | 587.1 |  |  | 531.8 |  |  | 527.1 |  |
| Billings | $ | 2,860.2 |  |  | $ | 2,293.4 |  |  | $ | 1,905.6 |  |

[0001327567-18-000024:mdna:38]
| • | Cash Flow Provided by Operating Activities. We monitor cash flow provided by operating activities as a measure of our overall business performance. Our cash flow provided by operating activities is driven in large part by sales of our products and from up-front payments for subscription and support offerings. Monitoring cash flow provided by operating |

[0001327567-18-000024:mdna:39]
- 39 -

[0001327567-18-000024:mdna:40]
activities enables us to analyze our financial performance without the non-cash effects of certain items such as depreciation, amortization, and share-based compensation costs, thereby allowing us to better understand and manage the cash needs of our business.

[0001327567-18-000024:mdna:41]
| • | Free Cash Flow (non-GAAP). We define free cash flow, a non-GAAP financial measure, as cash provided by operating activities less purchases of property, equipment, and other assets. We consider free cash flow to be a profitability and liquidity measure that provides useful information to management and investors about the amount of cash generated by the business after necessary capital expenditures. A limitation of the utility of free cash flow as a measure of our financial performance and liquidity is that it does not represent the total increase or decrease in our cash balance for the period. In addition, it is important to note that other companies, including companies in our industry, may not use free cash flow, may calculate free cash flow in a different manner than we do, or may use other financial measures to evaluate their performance, all of which could reduce the usefulness of free cash flow as a comparative measure. A reconciliation of free cash flow to cash flow provided by operating activities, the most directly comparable financial measure calculated and presented in accordance with GAAP, is provided below: |

[0001327567-18-000024:mdna:42]
|  | Year Ended July 31, |
|  | 2018 |  | 2017 |  | 2016 |
|  | (in millions) |
| Free cash flow (non-GAAP): |  |  |  |  |  |
| Net cash provided by operating activities | $ | 1,037.0 |  |  | $ | 868.5 |  |  | $ | 658.6 |  |
| Less: purchases of property, equipment, and other assets | 112.0 |  |  | 163.4 |  |  | 72.5 |  |
| Free cash flow (non-GAAP) | $ | 925.0 |  |  | $ | 705.1 |  |  | $ | 586.1 |  |
| Net cash used in investing activities | $ | (520.0 | ) |  | $ | (472.6 | ) |  | $ | (338.9 | ) |
| Net cash provided by (used in) financing activities | $ | 1,245.6 |  |  | $ | (386.0 | ) |  | $ | 38.9 |  |

[0001327567-18-000024:mdna:43]
- 40 -

[0001327567-18-000024:mdna:44]
Results of Operations

[0001327567-18-000024:mdna:45]
The following table summarizes our results of operations for the periods presented and as a percentage of our total revenue for those periods based on our consolidated statements of operations data. The period to period comparison of results is not necessarily indicative of results for future periods.

[0001327567-18-000024:mdna:46]
|  | Year Ended July 31, |
|  | 2018 |  | 2017 |  | 2016 |
|  | Amount |  | % of Revenue |  | Amount |  | % of Revenue |  | Amount |  | % of Revenue |
|  | (dollars in millions) |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 871.5 |  |  | 38.3 | % |  | $ | 709.1 |  |  | 40.3 | % |  | $ | 670.8 |  |  | 48.7 | % |
| Subscription and support | 1,401.6 |  |  | 61.7 | % |  | 1,052.5 |  |  | 59.7 | % |  | 707.7 |  |  | 51.3 | % |
| Total revenue | 2,273.1 |  |  | 100.0 | % |  | 1,761.6 |  |  | 100.0 | % |  | 1,378.5 |  |  | 100.0 | % |
| Cost of revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Product | 272.4 |  |  | 12.0 | % |  | 201.4 |  |  | 11.4 | % |  | 175.4 |  |  | 12.7 | % |
| Subscription and support | 372.9 |  |  | 16.4 | % |  | 275.2 |  |  | 15.7 | % |  | 194.6 |  |  | 14.1 | % |
| Total cost of revenue(1) | 645.3 |  |  | 28.4 | % |  | 476.6 |  |  | 27.1 | % |  | 370.0 |  |  | 26.8 | % |
| Total gross profit | 1,627.8 |  |  | 71.6 | % |  | 1,285.0 |  |  | 72.9 | % |  | 1,008.5 |  |  | 73.2 | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | 400.7 |  |  | 17.6 | % |  | 347.4 |  |  | 19.7 | % |  | 284.2 |  |  | 20.6 | % |
| Sales and marketing | 1,098.4 |  |  | 48.4 | % |  | 919.1 |  |  | 52.2 | % |  | 743.2 |  |  | 53.9 | % |
| General and administrative | 257.8 |  |  | 11.3 | % |  | 198.3 |  |  | 11.2 | % |  | 138.4 |  |  | 10.1 | % |
| Total operating expenses(1) | 1,756.9 |  |  | 77.3 | % |  | 1,464.8 |  |  | 83.1 | % |  | 1,165.8 |  |  | 84.6 | % |
| Operating loss | (129.1 | ) |  | (5.7 | )% |  | (179.8 | ) |  | (10.2 | )% |  | (157.3 | ) |  | (11.4 | )% |
| Interest expense | (29.6 | ) |  | (1.3 | )% |  | (24.5 | ) |  | (1.4 | )% |  | (23.4 | ) |  | (1.7 | )% |
| Other income, net | 28.5 |  |  | 1.3 | % |  | 10.2 |  |  | 0.6 | % |  | 8.4 |  |  | 0.6 | % |
| Loss before income taxes | (130.2 | ) |  | (5.7 | )% |  | (194.1 | ) |  | (11.0 | )% |  | (172.3 | ) |  | (12.5 | )% |
| Provision for income taxes | 17.7 |  |  | 0.8 | % |  | 22.5 |  |  | 1.3 | % |  | 20.4 |  |  | 1.5 | % |
| Net loss | $ | (147.9 | ) |  | (6.5 | )% |  | $ | (216.6 | ) |  | (12.3 | )% |  | $ | (192.7 | ) |  | (14.0 | )% |

[0001327567-18-000024:mdna:47]
______________

[0001327567-18-000024:mdna:48]
| (1) | Includes share-based compensation as follows: |

[0001327567-18-000024:mdna:49]
|  | Year Ended July 31, |
|  | 2018 |  | 2017 |  | 2016 |
|  | (in millions) |
| Cost of product revenue | $ | 7.0 |  |  | $ | 7.3 |  |  | $ | 6.2 |  |
| Cost of subscription and support revenue | 66.7 |  |  | 56.2 |  |  | 40.9 |  |
| Research and development | 145.2 |  |  | 152.6 |  |  | 132.9 |  |
| Sales and marketing | 208.0 |  |  | 186.5 |  |  | 152.4 |  |
| General and administrative | 77.0 |  |  | 73.1 |  |  | 60.5 |  |
| Total share-based compensation | $ | 503.9 |  |  | $ | 475.7 |  |  | $ | 392.9 |  |

[0001327567-18-000024:mdna:50]
- 41 -

[0001327567-18-000024:mdna:51]
Revenue

[0001327567-18-000024:mdna:52]
Our revenue consists of product revenue and subscription and support revenue. Revenue is recognized when persuasive evidence of an arrangement exists, delivery has occurred, the fee is fixed or determinable, and collectability is reasonably assured. We expect our revenue to vary from quarter to quarter based on seasonal and cyclical factors.

[0001327567-18-000024:mdna:53]
Product Revenue

[0001327567-18-000024:mdna:54]
Product revenue is derived primarily from sales of our appliances. Product revenue also includes revenue derived from software licenses of Panorama and the VM-Series. We recognize product revenue at the time of shipment, provided that all other revenue recognition criteria have been met.

[0001327567-18-000024:mdna:55]
|  | Year Ended July 31, |  |  |  | Year Ended July 31, |  |  |
|  | 2018 |  | 2017 |  | Change |  | 2017 |  | 2016 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Product | $ | 871.5 |  |  | $ | 709.1 |  |  | $ | 162.4 |  |  | 22.9 | % |  | $ | 709.1 |  |  | $ | 670.8 |  |  | $ | 38.3 |  |  | 5.7 | % |

[0001327567-18-000024:mdna:56]
Product revenue increased year-over-year for both fiscal 2018 and fiscal 2017 due to increased demand for our newly introduced appliances. The change in product revenue due to pricing was not significant for either period.

[0001327567-18-000024:mdna:57]
Subscription and Support Revenue

[0001327567-18-000024:mdna:58]
Subscription and support revenue is derived primarily from sales of our subscription and support offerings. Our contractual subscription and support terms are typically one to five years. We recognize revenue from subscriptions and support over the contractual service period. As a percentage of total revenue, we expect our subscription and support revenue to vary from quarter to quarter and increase over the long term as we introduce new subscriptions, renew existing subscription and support contracts, and expand our installed end-customer base. Prior to fiscal 2017, subscription and support revenue was referred to as services revenue. The composition of subscription and support revenue has not been modified.

[0001327567-18-000024:mdna:59]
|  | Year Ended July 31, |  |  |  | Year Ended July 31, |  |  |
|  | 2018 |  | 2017 |  | Change |  | 2017 |  | 2016 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Subscription | $ | 759.6 |  |  | $ | 550.8 |  |  | $ | 208.8 |  |  | 37.9 | % |  | $ | 550.8 |  |  | $ | 357.0 |  |  | $ | 193.8 |  |  | 54.3 | % |
| Support | 642.0 |  |  | 501.7 |  |  | 140.3 |  |  | 28.0 | % |  | 501.7 |  |  | 350.7 |  |  | 151.0 |  |  | 43.1 | % |
| Total subscription and support | $ | 1,401.6 |  |  | $ | 1,052.5 |  |  | $ | 349.1 |  |  | 33.2 | % |  | $ | 1,052.5 |  |  | $ | 707.7 |  |  | $ | 344.8 |  |  | 48.7 | % |

[0001327567-18-000024:mdna:60]
Subscription and support revenue increased year-over-year for both fiscal 2018 and fiscal 2017. The increase in both periods was due to increased demand for our subscription and support offerings from both new and existing end-customers. The mix between subscription revenue and support revenue will fluctuate over time, depending on the introduction of new subscription offerings, renewals of support services, and our ability to increase sales to new and existing customers. The change in subscription and support revenue due to changes in pricing was not significant for either period.

[0001327567-18-000024:mdna:61]
- 42 -

[0001327567-18-000024:mdna:62]
Revenue by Geographic Theater

[0001327567-18-000024:mdna:63]
|  | Year Ended July 31, |  |  |  | Year Ended July 31, |  |  |
|  | 2018 |  | 2017 |  | Change |  | 2017 |  | 2016 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Americas | $ | 1,558.7 |  |  | $ | 1,237.4 |  |  | $ | 321.3 |  |  | 26.0 | % |  | $ | 1,237.4 |  |  | $ | 973.2 |  |  | $ | 264.2 |  |  | 27.1 | % |
| EMEA | 439.3 |  |  | 320.1 |  |  | 119.2 |  |  | 37.2 | % |  | 320.1 |  |  | 247.1 |  |  | 73.0 |  |  | 29.5 | % |
| APAC | 275.1 |  |  | 204.1 |  |  | 71.0 |  |  | 34.8 | % |  | 204.1 |  |  | 158.2 |  |  | 45.9 |  |  | 29.0 | % |
| Total revenue | $ | 2,273.1 |  |  | $ | 1,761.6 |  |  | $ | 511.5 |  |  | 29.0 | % |  | $ | 1,761.6 |  |  | $ | 1,378.5 |  |  | $ | 383.1 |  |  | 27.8 | % |

[0001327567-18-000024:mdna:64]
With respect to geographic theaters, the Americas contributed the largest portion of the year-over-year increases in revenue for both fiscal 2018 and fiscal 2017 due to its larger and more established sales force compared to our other theaters. Revenue from both EMEA and APAC increased year-over-year for both fiscal 2018 and fiscal 2017 due to our investment in increasing the size of our sales force and number of channel partners in these theaters.

[0001327567-18-000024:mdna:65]
Cost of Revenue

[0001327567-18-000024:mdna:66]
Our cost of revenue consists of cost of product revenue and cost of subscription and support revenue.

[0001327567-18-000024:mdna:67]
Cost of Product Revenue

[0001327567-18-000024:mdna:68]
Cost of product revenue primarily includes costs paid to our manufacturing partners. Our cost of product revenue also includes personnel costs, which consist of salaries, benefits, bonuses, share-based compensation, and travel and entertainment associated with our operations organization, amortization of intellectual property licenses, product testing costs, shipping costs, and allocated costs. Allocated costs consist of certain facilities, depreciation, benefits, recruiting, and information technology costs that we allocate based on headcount. We expect our cost of product revenue to increase as our product revenue increases.

[0001327567-18-000024:mdna:69]
|  | Year Ended July 31, |  |  |  | Year Ended July 31, |  |  |
|  | 2018 |  | 2017 |  | Change |  | 2017 |  | 2016 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Cost of product revenue | $ | 272.4 |  |  | $ | 201.4 |  |  | $ | 71.0 |  |  | 35.3 | % |  | $ | 201.4 |  |  | $ | 175.4 |  |  | $ | 26.0 |  |  | 14.8 | % |
| Number of employees at period end | 97 |  |  | 96 |  |  | 1 |  |  | 1.0 | % |  | 96 |  |  | 91 |  |  | 5 |  |  | 5.5 | % |

[0001327567-18-000024:mdna:70]
Cost of product revenue increased year-over-year for both fiscal 2018 and fiscal 2017 primarily due to higher product costs related to our newly introduced appliances.

[0001327567-18-000024:mdna:71]
Cost of Subscription and Support Revenue

[0001327567-18-000024:mdna:72]
Cost of subscription and support revenue includes personnel costs for our global customer support and technical operations organizations, customer support and repair costs, third-party professional services costs, data center and cloud hosting costs, amortization of acquired intangible assets, and allocated costs. We expect our cost of subscription and support revenue to increase as our installed end-customer base grows and adoption of our cloud-based subscription offerings increases. Prior to fiscal 2017, cost of subscription and support revenue was referred to as cost of services revenue. The composition of cost of subscription and support revenue has not been modified.

[0001327567-18-000024:mdna:73]
|  | Year Ended July 31, |  |  |  | Year Ended July 31, |  |  |
|  | 2018 |  | 2017 |  | Change |  | 2017 |  | 2016 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Cost of subscription and support revenue | $ | 372.9 |  |  | $ | 275.2 |  |  | $ | 97.7 |  |  | 35.5 | % |  | $ | 275.2 |  |  | $ | 194.6 |  |  | $ | 80.6 |  |  | 41.4 | % |
| Number of employees at period end | 932 |  |  | 725 |  |  | 207 |  |  | 28.6 | % |  | 725 |  |  | 539 |  |  | 186 |  |  | 34.5 | % |

[0001327567-18-000024:mdna:74]
- 43 -

[0001327567-18-000024:mdna:75]
Cost of subscription and support revenue increased for fiscal 2018 compared to fiscal 2017 primarily due to an increase in personnel costs for our global customer support and technical operations organizations, which grew $53.5 million to $208.9 million, primarily due to headcount growth. The remaining increase was primarily due to data center and cloud hosting costs to support the adoption of our cloud-based subscription offerings, costs to expand our customer service capabilities, and allocated costs. The increase in allocated costs was primarily due to our expansion of facilities to support the growth of our business.

[0001327567-18-000024:mdna:76]
Cost of subscription and support revenue increased for fiscal 2017 compared to fiscal 2016 primarily due to an increase in personnel costs, which grew $45.3 million to $155.4 million, largely due to headcount growth. The remaining increase was primarily driven by costs to expand our customer service capabilities and infrastructure, customer support and repair costs, and allocated costs. The increase in allocated costs was primarily due to our expansion of facilities to support the growth of our business.

[0001327567-18-000024:mdna:77]
Gross Margin

[0001327567-18-000024:mdna:78]
Gross margin, or gross profit as a percentage of revenue, has been and will continue to be affected by a variety of factors, including the introduction of new products, manufacturing costs, the average sales price of our products, the mix of products sold, and the mix of revenue between product and subscription and support offerings. For sales of our products, our higher-end firewall products generally have higher gross margins than our lower-end firewall products within each product series. For sales of our subscription and support offerings, our subscription offerings typically have higher gross margins than our support offerings. We expect our gross margins to fluctuate over time depending on the factors described above.

[0001327567-18-000024:mdna:79]
|  | Year Ended July 31, |
|  | 2018 |  | 2017 |  | 2016 |
|  | Amount |  | GrossMargin |  | Amount |  | GrossMargin |  | Amount |  | GrossMargin |
|  | (dollars in millions) |
| Product | $ | 599.1 |  |  | 68.7 | % |  | $ | 507.7 |  |  | 71.6 | % |  | $ | 495.4 |  |  | 73.9 | % |
| Subscription and support | 1,028.7 |  |  | 73.4 | % |  | 777.3 |  |  | 73.9 | % |  | 513.1 |  |  | 72.5 | % |
| Total gross profit | $ | 1,627.8 |  |  | 71.6 | % |  | $ | 1,285.0 |  |  | 72.9 | % |  | $ | 1,008.5 |  |  | 73.2 | % |

[0001327567-18-000024:mdna:80]
Product gross margin decreased year-over-year for both fiscal 2018 and fiscal 2017, driven by higher product costs related to our newly introduced appliances, which have lower product margins.

[0001327567-18-000024:mdna:81]
Subscription and support gross margin decreased slightly for fiscal 2018 compared to fiscal 2017, primarily due to higher data center and cloud hosting costs to support the adoption of our cloud-based subscription offerings and costs to expand our customer service capabilities, partially offset by a decrease in customer support and repair costs. Subscription and support gross margin increased for fiscal 2017 compared to fiscal 2016 due to contributions from our higher margin subscription offerings.

[0001327567-18-000024:mdna:82]
Operating Expenses

[0001327567-18-000024:mdna:83]
Our operating expenses consist of research and development, sales and marketing, and general and administrative expense. Personnel costs are the most significant component of operating expenses and consist of salaries, benefits, bonuses, share-based compensation, travel and entertainment, and with regard to sales and marketing expense, sales commissions. Our operating expenses also include allocated costs, which consist of certain facilities, depreciation, benefits, recruiting, and information technology costs that we allocate based on headcount. We expect operating expenses to increase in absolute dollars and decrease over the long term as a percentage of revenue as we continue to scale our business. As of July 31, 2018, we expect to recognize approximately $1.1 billion of share-based compensation expense over a weighted-average period of approximately 3.0 years, excluding additional share-based compensation expense related to any future grants of share-based awards. Share-based compensation expense is generally recognized on a straight-line basis over the requisite service periods of the awards.

[0001327567-18-000024:mdna:84]
Research and Development

[0001327567-18-000024:mdna:85]
Research and development expense consists primarily of personnel costs. Research and development expense also includes prototype related expenses and allocated costs. We expect research and development expense to increase in absolute dollars as we continue to invest in our future products and services, although our research and development expense may fluctuate as a percentage of total revenue.

[0001327567-18-000024:mdna:86]
- 44 -

[0001327567-18-000024:mdna:87]
|  | Year Ended July 31, |  |  |  | Year Ended July 31, |  |  |
|  | 2018 |  | 2017 |  | Change |  | 2017 |  | 2016 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Research and development | $ | 400.7 |  |  | $ | 347.4 |  |  | $ | 53.3 |  |  | 15.3 | % |  | $ | 347.4 |  |  | $ | 284.2 |  |  | $ | 63.2 |  |  | 22.2 | % |
| Number of employees at period end | 947 |  |  | 766 |  |  | 181 |  |  | 23.6 | % |  | 766 |  |  | 637 |  |  | 129 |  |  | 20.3 | % |

[0001327567-18-000024:mdna:88]
Research and development expense increased year-over-year for both fiscal 2018 and fiscal 2017. The increase in both periods was primarily due to an increase in personnel costs, which grew $36.8 million to $330.9 million for fiscal 2018 compared to fiscal 2017 and grew $46.4 million to $286.0 million for fiscal 2017 compared to fiscal 2016. The increases in personnel costs in both periods were primarily due to headcount growth. The remaining increase for fiscal 2018 was primarily driven by an increase in allocated costs due to our expansion of facilities to support the growth of our business. The remaining increase for fiscal 2017 was primarily driven by an increase in allocated costs, due to our expansion of facilities to support the growth of our business, and development costs related to investments in our new and future offerings.

[0001327567-18-000024:mdna:89]
Sales and Marketing

[0001327567-18-000024:mdna:90]
Sales and marketing expense consists primarily of personnel costs, including commission expense. Sales and marketing expense also includes costs for market development programs, promotional and other marketing costs, professional services, and allocated costs. We continue to thoughtfully invest in headcount and have substantially grown our sales presence internationally. We expect sales and marketing expense to continue to increase in absolute dollars as we increase the size of our sales and marketing organizations to increase touch points with end-customers and to expand our international presence, although our sales and marketing expense may fluctuate as a percentage of total revenue.

[0001327567-18-000024:mdna:91]
|  | Year Ended July 31, |  |  |  | Year Ended July 31, |  |  |
|  | 2018 |  | 2017 |  | Change |  | 2017 |  | 2016 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Sales and marketing | $ | 1,098.4 |  |  | $ | 919.1 |  |  | $ | 179.3 |  |  | 19.5 | % |  | $ | 919.1 |  |  | $ | 743.2 |  |  | $ | 175.9 |  |  | 23.7 | % |
| Number of employees at period end | 2,704 |  |  | 2,418 |  |  | 286 |  |  | 11.8 | % |  | 2,418 |  |  | 2,092 |  |  | 326 |  |  | 15.6 | % |

[0001327567-18-000024:mdna:92]
Sales and marketing expense increased year-over-year for both fiscal 2018 and fiscal 2017. The increase in both periods was primarily due to an increase in personnel costs, which grew $137.7 million to $853.8 million for fiscal 2018 compared to fiscal 2017 and grew $145.0 million to $716.1 million for fiscal 2017 compared to fiscal 2016. The increases in personnel costs in both periods were primarily due to headcount growth. The remaining increase for fiscal 2018 was primarily driven by an increase in allocated costs due to our expansion of facilities to support the growth of our business. The remaining increase for fiscal 2017 was primarily driven by an increase in allocated costs, due to our expansion of facilities to support the growth of our business, and an increase in demand generation activities and sales related events to support our revenue growth.

[0001327567-18-000024:mdna:93]
General and Administrative

[0001327567-18-000024:mdna:94]
General and administrative expense consists primarily of personnel costs for our executive, finance, human resources, legal, and information technology organizations, and professional services costs, which consist primarily of legal, auditing, accounting, and other consulting costs. General and administrative expense also includes certain non-recurring general expenses and impairment losses. Certain facilities, depreciation, benefits, recruiting, and information technology costs are allocated to other organizations based on headcount. We expect general and administrative expense to increase in absolute dollars due to additional costs associated with accounting, compliance, and insurance, although our general and administrative expense may fluctuate as a percentage of total revenue.

[0001327567-18-000024:mdna:95]
|  | Year Ended July 31, |  |  |  | Year Ended July 31, |  |  |
|  | 2018 |  | 2017 |  | Change |  | 2017 |  | 2016 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| General and administrative | $ | 257.8 |  |  | $ | 198.3 |  |  | $ | 59.5 |  |  | 30.0 | % |  | $ | 198.3 |  |  | $ | 138.4 |  |  | $ | 59.9 |  |  | 43.3 | % |
| Number of employees at period end | 668 |  |  | 557 |  |  | 111 |  |  | 19.9 | % |  | 557 |  |  | 436 |  |  | 121 |  |  | 27.8 | % |

[0001327567-18-000024:mdna:96]
- 45 -

[0001327567-18-000024:mdna:97]
General and administrative expense increased for fiscal 2018 compared to fiscal 2017 primarily due to a cease-use loss of $39.2 million recognized on the lease of our previous headquarter facilities during fiscal 2018. Refer to Note 9. Commitments and Contingencies in Part II, Item 8 of this Annual Report on Form 10-K for more information. The remaining increase was primarily driven by costs related to business acquisitions completed during fiscal 2018, an increase in personnel costs, and increase in allocated costs due to our expansion of facilities to support the growth of our business. Personnel costs grew $10.2 million to $138.7 million for fiscal 2018 compared to fiscal 2017, largely due to headcount growth. These increases were partially offset by a decrease in impairment losses due to the $20.9 million loss recognized in fiscal 2017 on property and equipment related to the relocation of our corporate headquarters.

[0001327567-18-000024:mdna:98]
General and administrative expense increased for fiscal 2017 compared to fiscal 2016 primarily due to an increase in personnel costs, which grew $29.3 million to $128.1 million, largely due to headcount growth, and a fiscal 2017 impairment loss of $20.9 million on property and equipment related to the relocation of our corporate headquarters. The remaining increase for fiscal 2017 was primarily driven by an increase in allocated costs due to our expansion of facilities to support the growth of our business.

[0001327567-18-000024:mdna:99]
Interest Expense

[0001327567-18-000024:mdna:100]
Interest expense primarily consists of non-cash interest expense from the amortization of the debt discount and debt issuance costs related to our 2019 Notes and 2023 Notes, and also includes the contractual interest expense related to our 2023 Notes.

[0001327567-18-000024:mdna:101]
|  | Year Ended July 31, |  |  |  | Year Ended July 31, |  |  |
|  | 2018 |  | 2017 |  | Change |  | 2017 |  | 2016 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Interest expense | $ | 29.6 |  |  | $ | 24.5 |  |  | $ | 5.1 |  |  | 20.8 | % |  | $ | 24.5 |  |  | $ | 23.4 |  |  | $ | 1.1 |  |  | 4.7 | % |

[0001327567-18-000024:mdna:102]
Interest expense increased for fiscal 2018 compared to fiscal 2017 primarily due to interest expense recognized on the 2023 Notes issued in July 2018. We expect interest expense to increase in fiscal 2019 due to interest expense to be incurred on the 2023 Notes, partially offset by a reduction in interest expense on the 2019 Notes due to conversions before or upon maturity. Interest expense recognized in fiscal 2017 and fiscal 2016 was primarily related to the 2019 Notes. Refer to Note 8. Convertible Senior Notes in Part II, Item 8 of this Annual Report on Form 10-K for more information on the Notes.

[0001327567-18-000024:mdna:103]
Other Income, Net

[0001327567-18-000024:mdna:104]
Other income, net includes interest income earned on our cash, cash equivalents, and investments, foreign currency remeasurement gains and losses, and foreign currency transaction gains and losses.

[0001327567-18-000024:mdna:105]
|  | Year Ended July 31, |  |  |  | Year Ended July 31, |  |  |
|  | 2018 |  | 2017 |  | Change |  | 2017 |  | 2016 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Other income, net | $ | 28.5 |  |  | $ | 10.2 |  |  | $ | 18.3 |  |  | 179.4 | % |  | $ | 10.2 |  |  | $ | 8.4 |  |  | $ | 1.8 |  |  | 21.4 | % |

[0001327567-18-000024:mdna:106]
Other income, net increased for fiscal 2018 compared to fiscal 2017 primarily driven by a $12.4 million increase in interest income, largely due to higher cash, cash equivalents, and investments balances and higher yields on these balances during fiscal 2018, and an increase in foreign currency remeasurement gains. Other income, net increased for fiscal 2017 compared to fiscal 2016 due to an increase in interest income, partially offset by increased foreign currency remeasurement losses.

[0001327567-18-000024:mdna:107]
Provision for Income Taxes

[0001327567-18-000024:mdna:108]
Provision for income taxes consists primarily of income taxes in foreign jurisdictions in which we conduct business, withholding taxes, U.S. state income taxes, and amortization of our deferred tax charges. We maintain a full valuation allowance for domestic and certain foreign deferred tax assets, including net operating loss carryforwards and certain domestic tax credits. In recent years, we reorganized our corporate structure and intercompany relationships to more closely align with the international nature of our business activities. Our corporate structure has caused, and may continue to cause, disproportionate relationships between our overall effective tax rate and other jurisdictional measures. To the extent we revisit our corporate structure, it may have an impact on our tax provision.

[0001327567-18-000024:mdna:109]
On December 22, 2017, the Tax Cuts and Jobs Act (“TCJA”) was enacted into law. The TCJA provides for significant tax law changes and modifications including, but not limited to, the reduction of the U.S. federal corporate statutory tax rate from 35% to 21%

[0001327567-18-000024:mdna:110]
- 46 -

[0001327567-18-000024:mdna:111]
as of January 1, 2018, the requirement for companies to pay a one-time transition tax on earnings of certain foreign subsidiaries that were previously tax deferred, and the creation of new taxes on certain foreign-sourced earnings. As a fiscal year-end taxpayer, certain provisions of the TCJA began to impact us during the three months ended January 31, 2018, while other provisions will impact us beginning in our fiscal year ending July 31, 2019.

[0001327567-18-000024:mdna:112]
|  | Year Ended July 31, |  |  |  |  |  | Year Ended July 31, |  |  |  |  |
|  | 2018 |  | 2017 |  | Change |  | 2017 |  | 2016 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Provision for income taxes | $ | 17.7 |  |  | $ | 22.5 |  |  | $ | (4.8 | ) |  | (21.3 | )% |  | $ | 22.5 |  |  | $ | 20.4 |  |  | $ | 2.1 |  |  | 10.3 | % |
| Effective tax rate | (13.6 | )% |  | (11.6 | )% |  |  |  |  |  | (11.6 | )% |  | (11.8 | )% |  |  |  |  |

[0001327567-18-000024:mdna:113]
We recorded an income tax provision for fiscal 2018 due to foreign income taxes, withholding taxes, and amortization of our deferred tax charges. The provision for income taxes decreased for fiscal 2018 compared to fiscal 2017 primarily due to changes in valuation allowance related to the acquisition of Evident.io and future benefits from alternative minimum tax credits under the TCJA.

[0001327567-18-000024:mdna:114]
During the year ended July 31, 2018, we recognized provisional amounts for the tax effects of the TCJA which were included as components of income tax expense and reflected in the effective tax rates above. We will continue to assess the impact of the TCJA on our business and our consolidated financial statements, however, the final impact of the TCJA may differ from the provisional amounts due to a number of uncertainties and factors, including the need for further guidance and clarification of the new law by U.S. federal and state tax authorities, and the need for further guidance on the related income tax accounting. Refer to Note 12. Income Taxes in Part II, Item 8 of this Annual Report on Form 10-K for more information on the TCJA and its expected impact.

[0001327567-18-000024:mdna:115]
We recorded an income tax provision for fiscal 2017 due to foreign income taxes, withholding taxes, and amortization of our deferred tax charges. The provision for income taxes increased for fiscal 2017 compared to fiscal 2016 primarily due to increases in foreign withholding taxes and U.S. income taxes related to intercompany transactions, offset by tax benefits from our adoption of new share-based payment accounting guidance in fiscal 2017.

[0001327567-18-000024:mdna:116]
Liquidity and Capital Resources

[0001327567-18-000024:mdna:117]
|  | July 31, |
|  | 2018 |  | 2017 |
|  | (in millions) |
| Working capital(1) | $ | 1,992.6 |  |  | $ | 775.0 |  |
| Cash, cash equivalents, and investments: |  |  |  |
| Cash and cash equivalents | $ | 2,506.9 |  |  | 744.3 |  |
| Investments | 1,444.0 |  |  | 1,420.0 |  |
| Total cash, cash equivalents, and investments | $ | 3,950.9 |  |  | $ | 2,164.3 |  |

[0001327567-18-000024:mdna:118]
______________

[0001327567-18-000024:mdna:119]
| (1) | The net carrying amount of the 2019 Notes was classified in current liabilities in our consolidated balance sheets as of July 31, 2018. Refer to Note 8. Convertible Senior Notes in Part II, Item 8 of this Annual Report on Form 10-K for information on the Notes. |

[0001327567-18-000024:mdna:120]
As of July 31, 2018, our total cash, cash equivalents, and investments of $4.0 billion were held for general corporate purposes, of which approximately $271.4 million was held outside of the United States. As of July 31, 2018, we had no unremitted earnings when evaluating our outside basis difference relating to our U.S. investment in foreign subsidiaries. However, there could be local withholding taxes payable due to various foreign countries if certain lower tier earnings are distributed. Withholding taxes that would be payable upon remittance of these lower tier earnings were not material as of July 31, 2018.

[0001327567-18-000024:mdna:121]
In June 2014, we issued the 2019 Notes with an aggregate principal amount of $575.0 million and in July 2018, we issued the 2023 Notes with an aggregate principal amount of $1.7 billion. As of July 31, 2018, all of the outstanding aggregate principal amount of the Notes of each series remained outstanding. The 2019 Notes and the 2023 Notes mature on July 1, 2019 and July 1, 2023, respectively; however, under certain circumstances, holders may surrender their Notes of a series for conversion prior to the applicable maturity dates. Upon conversion of the Notes of a series, we will pay cash equal to the aggregate principal amount of the Notes of such series to be converted, and, at our election, will pay or deliver cash and/or shares of our common stock for the amount of our conversion obligation in excess of the aggregate principal amount of the Notes of such series being converted. Refer to Note 8.

[0001327567-18-000024:mdna:122]
- 47 -

[0001327567-18-000024:mdna:123]
Convertible Senior Notes in Part II, Item 8 of this Annual Report on Form 10-K for more information on the Notes. Subsequent to July 31, 2018, through the filing date of this Annual Report on Form 10-K, $327.3 million in principal amount of the 2019 Notes was converted or had been submitted by the holders for conversion and will settle during the fiscal quarter ending October 31, 2018.

[0001327567-18-000024:mdna:124]
On September 4, 2018, we entered into a credit agreement (the “Credit Agreement”) that provides for a $400.0 million unsecured revolving credit facility, with an option to increase the amount of the credit facility up to an additional $350.0 million, subject to certain conditions. Refer to Note 18. Subsequent Event in Part II, Item 8 of this Annual Report on Form 10-K for more information on the Credit Agreement.

[0001327567-18-000024:mdna:125]
In August 2016, our board of directors authorized a $500.0 million share repurchase and, in February 2017, authorized a $500.0 million increase to the repurchase program, bringing the total authorization to $1.0 billion. Repurchases are funded from available working capital and may be made at management’s discretion from time to time. The repurchase authorization will expire on December 31, 2018, and may be suspended or discontinued at any time. As of July 31, 2018, $330.0 million was available for future share repurchases under the repurchase authorization. Refer to Note 10. Stockholders’ Equity in Part II, Item 8 of this Annual Report on Form 10-K for information on the repurchase authorization.

[0001327567-18-000024:mdna:126]
The following table summarizes our cash flows for the years ended July 31, 2018, 2017, and 2016:

[0001327567-18-000024:mdna:127]
|  | Year Ended July 31, |
| 2018 |  | 2017 |  | 2016 |
|  | (in millions) |
| Net cash provided by operating activities | $ | 1,037.0 |  |  | $ | 868.5 |  |  | $ | 658.6 |  |
| Net cash used in investing activities | (520.0 | ) |  | (472.6 | ) |  | (338.9 | ) |
| Net cash provided by (used in) financing activities | 1,245.6 |  |  | (386.0 | ) |  | 38.9 |  |
| Net increase in cash and cash equivalents | $ | 1,762.6 |  |  | $ | 9.9 |  |  | $ | 358.6 |  |

[0001327567-18-000024:mdna:128]
We believe that our cash flow from operations with existing cash and cash equivalents will be sufficient to meet our anticipated cash needs for the foreseeable future. Our future capital requirements will depend on many factors including our growth rate, the timing and extent of spending to support development efforts, the expansion of sales and marketing activities, the introduction of new and enhanced products and subscription and support offerings, the costs to acquire or invest in complementary businesses and technologies, the costs to ensure access to adequate manufacturing capacity, the investments in our infrastructure to support the adoption of our cloud-based subscription offerings, the investments in our new corporate headquarters, and the continuing market acceptance of our products and subscription and support offerings. In addition, from time to time we may incur additional tax liability in connection with certain corporate structuring decisions.

[0001327567-18-000024:mdna:129]
We may also choose to seek additional equity or debt financing. In the event that additional financing is required from outside sources, we may not be able to raise it on terms acceptable to us or at all. If we are unable to raise additional capital when desired, our business, operating results, and financial condition may be adversely affected.

[0001327567-18-000024:mdna:130]
Operating Activities

[0001327567-18-000024:mdna:131]
Our operating activities have consisted of net losses adjusted for certain non-cash items and changes in assets and liabilities.

[0001327567-18-000024:mdna:132]
Cash provided by operating activities in fiscal 2018 was $1,037.0 million, an increase of $168.5 million compared to fiscal 2017. The increase was due to growth of our business, as reflected by an increase in billings during fiscal 2018.

[0001327567-18-000024:mdna:133]
Cash provided by operating activities in fiscal 2017 was $868.5 million, an increase of $209.9 million compared to fiscal 2016. The increase was due to growth of our business, as reflected by an increase in billings, and an increase in collections on accounts receivable during fiscal 2017.

[0001327567-18-000024:mdna:134]
Investing Activities

[0001327567-18-000024:mdna:135]
Our investing activities have consisted of capital expenditures, net investment purchases, sales, and maturities, and business acquisitions. We expect to continue such activities as our business grows.

[0001327567-18-000024:mdna:136]
Cash used in investing activities during fiscal 2018 was $520.0 million, an increase of $47.4 million compared to fiscal 2017, due to an increase in net cash payments for acquisitions, partially offset by lower net purchases of available-for-sale investments and capital expenditures.

[0001327567-18-000024:mdna:137]
Cash used in investing activities during fiscal 2017 was $472.6 million, an increase of $133.7 million compared to fiscal 2016, due to increased investment in facilities to support the growth of our business and a net cash payment of $90.7 million for our acquisition of LightCyber, partially offset by lower net purchases of available-for-sale investments during fiscal 2017.

[0001327567-18-000024:mdna:138]
- 48 -

[0001327567-18-000024:mdna:139]
Financing Activities

[0001327567-18-000024:mdna:140]
Our financing activities have consisted of net proceeds from the issuance of the Notes and related transactions, proceeds from sales of shares through employee equity incentive plans, cash used to repurchase shares of our common stock, and payments for tax withholding obligations of certain employees related to the net share settlement of equity awards.

[0001327567-18-000024:mdna:141]
Cash provided by financing activities during fiscal 2018 was $1,245.6 million, an increase of $1,631.6 million compared to fiscal 2017. The increase was mainly due to net proceeds of $1,495.8 million from the issuance of the 2023 Notes, issuance of warrants, and purchase of note hedges, partially offset by an increase in payments for tax withholding obligations of certain employees related to the net share settlement of equity awards during fiscal 2018.

[0001327567-18-000024:mdna:142]
Cash used in financing activities during fiscal 2017 was $386.0 million, a change of $424.9 million compared to fiscal 2016, due to the repurchase of $411.0 million of our common stock and payments for tax withholding obligations of certain employees related to the net share settlement of equity awards of $21.4 million during fiscal 2017.

[0001327567-18-000024:mdna:143]
Contractual Obligations and Commitments

[0001327567-18-000024:mdna:144]
The following summarizes our contractual obligations and commitments as of July 31, 2018:

[0001327567-18-000024:mdna:145]
|  | Payments Due by Period |
|  | Total |  | Less Than 1 Year |  | 1-3 Years |  | 3-5 Years |  | More Than 5 Years |
|  |  |  | (in millions) |  |  |
| 0.0% Convertible Senior Notes due 2019(1) | $ | 575.0 |  |  | $ | 575.0 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| 0.75% Convertible Senior Notes due 2023 | 1,693.0 |  |  | — |  |  | — |  |  | 1,693.0 |  |  | — |  |
| Operating lease obligations(2) | 540.6 |  |  | 66.3 |  |  | 132.2 |  |  | 118.3 |  |  | 223.8 |  |
| Purchase obligations(3) | 146.3 |  |  | 138.3 |  |  | 8.0 |  |  | — |  |  | — |  |
| Total(4) | $ | 2,954.9 |  |  | $ | 779.6 |  |  | $ | 140.2 |  |  | $ | 1,811.3 |  |  | $ | 223.8 |  |

[0001327567-18-000024:mdna:146]
______________

[0001327567-18-000024:mdna:147]
| (1) | As of July 31, 2018, holders may convert their 2019 Notes at any time during the fiscal quarter ending October 31, 2018. Refer to Note 8. Convertible Senior Notes in Part II, Item 8 of this Annual Report on Form 10-K for more information. |

[0001327567-18-000024:mdna:148]
| (2) | Consists of contractual obligations from our non-cancelable operating leases. Excludes contractual sublease proceeds of $14.0 million, which consists of $5.0 million to be received in less than one year, and $9.0 million to be received in one to three years. Refer to Note 9. Commitments and Contingencies in Part II, Item 8 of this Annual Report on Form 10-K for more information on our operating leases. |

[0001327567-18-000024:mdna:149]
| (3) | Consists of minimum purchase commitments of products and components with our manufacturing partners and component suppliers, as well as minimum purchase commitments for our use of certain cloud services with a third-party provider. Obligations under contracts that we can cancel without a significant penalty are not included in the table above. |

[0001327567-18-000024:mdna:150]
| (4) | No amounts related to income taxes are included. As of July 31, 2018, we had approximately $78.9 million of tax liabilities recorded related to uncertainty in income tax positions. |

[0001327567-18-000024:mdna:151]
Off-Balance Sheet Arrangements

[0001327567-18-000024:mdna:152]
As of July 31, 2018, we did not have any relationships with unconsolidated organizations or financial partnerships, such as structured finance or special purpose entities that would have been established for the purpose of facilitating off-balance sheet arrangements or other contractually narrow or limited purposes.

[0001327567-18-000024:mdna:153]
Critical Accounting Estimates

[0001327567-18-000024:mdna:154]
Our consolidated financial statements have been prepared in accordance with GAAP. The preparation of these consolidated financial statements requires us to make estimates and assumptions that affect the reported amounts of assets, liabilities, revenue, expenses, and related disclosures. We base our estimates on historical experience and on various other assumptions that we believe are reasonable under the circumstances. We evaluate our estimates and assumptions on an ongoing basis. Actual results may differ from these estimates. To the extent that there are material differences between these estimates and our actual results, our future financial statements will be affected.

[0001327567-18-000024:mdna:155]
- 49 -

[0001327567-18-000024:mdna:156]
We believe that of our significant accounting policies described in Note 1. Description of Business and Summary of Significant Accounting Policies in Part II, Item 8 of this Annual Report on Form 10-K, the critical accounting policies requiring estimates, assumptions, and judgments that have the most significant impact on our consolidated financial statements are described below.

[0001327567-18-000024:mdna:157]
Revenue Recognition

[0001327567-18-000024:mdna:158]
We recognize revenue when persuasive evidence of an arrangement exists, delivery has occurred, the fee is fixed or determinable, and collectability is reasonably assured. Most of our arrangements, other than renewals of subscriptions and support contracts, are multiple-element arrangements with a combination of hardware, software, subscriptions, support, and other services. For multiple-element arrangements, we allocate revenue to each unit of accounting based on an estimated selling price at the arrangement inception. The estimated selling price for each element is based upon the following hierarchy:

[0001327567-18-000024:mdna:159]
| • | Vendor-specific objective evidence (“VSOE”) of selling price, if available, |

[0001327567-18-000024:mdna:160]
| • | Third-party evidence (“TPE”) of selling price, if VSOE of selling price is not available, or |

[0001327567-18-000024:mdna:161]
| • | Best estimate of selling price (“BESP”), if neither VSOE of selling price nor TPE of selling price are available. |

[0001327567-18-000024:mdna:162]
We establish VSOE of selling price using the prices charged for a deliverable when sold separately. We establish TPE of selling price by evaluating similar and interchangeable competitor products or services in standalone arrangements with similarly situated partners. We establish BESP primarily based on historical transaction pricing, whereby historical transactions are segregated based on our pricing model and our go-to-market strategy, which include factors such as type of sales channel (reseller, distributor, or end-customer), the geographies in which our products and services were sold (domestic or international), and offering type (products or services). To further support BESP as determined by the historical transaction pricing or when such information is unavailable, such as when there are limited sales of a new product or service, we consider the same factors we have established through our pricing model and go-to-market strategy. The determination of BESP is made through consultation with and approval by our management. In determining BESP, we rely on certain assumptions and apply significant judgment. As our business offerings evolve over time, we may be required to modify our estimated selling prices in subsequent periods, and the timing of our revenue recognition could be affected.

[0001327567-18-000024:mdna:163]
Income Taxes

[0001327567-18-000024:mdna:164]
We account for income taxes using the asset and liability method, which requires the recognition of deferred tax assets and liabilities for the expected future tax consequences of events that have been recognized in our financial statements or tax returns. In addition, deferred tax assets are recorded for the future benefit of utilizing net operating losses and research and development credit carryforwards. Valuation allowances are provided when necessary to reduce deferred tax assets to the amount expected to be realized.

[0001327567-18-000024:mdna:165]
Significant judgment is required in determining any valuation allowance recorded against deferred tax assets. In assessing the need for a valuation allowance, we consider all available evidence, including past operating results, estimates of future taxable income, and the feasibility of tax planning strategies. In the event that we change our determination as to the amount of deferred tax assets that can be realized, we will adjust our valuation allowance with a corresponding impact to the provision for income taxes in the period in which such determination is made.

[0001327567-18-000024:mdna:166]
We apply the authoritative accounting guidance prescribing a threshold and measurement attribute for the financial recognition and measurement of a tax position taken or expected to be taken in a tax return. We recognize liabilities for uncertain tax positions based on a two-step process. The first step is to evaluate the tax position for recognition by determining if the weight of available evidence indicates that it is more likely than not that the position will be sustained on audit, including resolution of related appeals or litigation processes, if any. The second step requires us to estimate and measure the tax benefit as the largest amount that is more likely than not to be realized upon ultimate settlement.

[0001327567-18-000024:mdna:167]
Significant judgment is also required in evaluating our uncertain tax positions and determining our provision for income taxes. Although we believe our reserves are reasonable, no assurance can be given that the final tax outcome of these matters will not be different from that which is reflected in our historical income tax provisions and accruals. We adjust these reserves in light of changing facts and circumstances, such as the closing of a tax audit or the refinement of an estimate. To the extent that the final tax outcome of these matters is different than the amounts recorded, such differences may impact the provision for income taxes in the period in which such determination is made.

[0001327567-18-000024:mdna:168]
Accounting standards require companies to recognize the effect of tax law changes in the period of enactment. However, the SEC staff and FASB issued guidance that allows companies to record provisional amounts for the effects of the TCJA during a measurement period not to extend beyond one year from the enactment date. In accordance with this guidance, we have determined the amounts recorded and positions taken, as discussed, are provisional as of July 31, 2018. We continue to assess the impacts of the TCJA, and the final impact of the TCJA recorded by us may differ from the provisional amounts due to a number of uncertainties and factors, including the need for further guidance and clarification of the new law by U.S. federal and state tax authorities, and the need for further guidance on the related income tax accounting.

[0001327567-18-000024:mdna:169]
- 50 -

[0001327567-18-000024:mdna:170]
Manufacturing Partner and Supplier Liabilities

[0001327567-18-000024:mdna:171]
We outsource most of our manufacturing, repair, and supply chain management operations to our EMS provider, which procures components and assembles our products based on our demand forecasts. These forecasts of future demand are based upon historical trends and analysis from our sales and product management functions as adjusted for overall market conditions. We accrue for costs for manufacturing purchase commitments in excess of our forecasted demand, including costs for excess components or for carrying costs incurred by our manufacturing partners and component suppliers. Actual component usage and product demand may be materially different from our forecast, and could be caused by factors outside of our control, which could have an adverse impact on our results of operations. To date, we have not accrued significant costs associated with this exposure.

[0001327567-18-000024:mdna:172]
Loss Contingencies

[0001327567-18-000024:mdna:173]
We are subject to the possibility of various loss contingencies arising in the ordinary course of business. We accrue for loss contingencies when it is probable that an asset has been impaired or a liability has been incurred and the amount of loss can be reasonably estimated. If we determine that a loss is possible and the range of the loss can be reasonably determined, then we disclose the range of the possible loss. We regularly evaluate current information available to us to determine whether an accrual is required, an accrual should be adjusted or a range of possible loss should be disclosed.

[0001327567-18-000024:mdna:174]
From time to time, we are involved in disputes, litigation, and other legal actions. However, there are many uncertainties associated with any litigation, and these actions or other third-party claims against us may cause us to incur substantial settlement charges, which are inherently difficult to estimate and could adversely affect our results of operations. The actual liability in any such matters may be materially different from our estimates, which could result in the need to adjust our liability and record additional expenses.

[0001327567-18-000024:mdna:175]
Goodwill, Intangibles, and Other Long-Lived Assets

[0001327567-18-000024:mdna:176]
We make significant estimates, assumptions, and judgments when valuing goodwill and other purchased intangible assets in connection with the initial purchase price allocation of an acquired entity, as well as when evaluating impairment of goodwill and other purchased intangible assets on an ongoing basis. These estimates are based upon a number of factors, including historical experience, market conditions, and information obtained from the management of the acquired company. Critical estimates in valuing certain intangible assets include, but are not limited to, cash flows that an asset is expected to generate in the future, discount rates, the time and expense that would be necessary to recreate the assets, and the profit margin a market participant would receive. The amounts and useful lives assigned to identified intangible assets impacts the amount and timing of future amortization expense.

[0001327567-18-000024:mdna:177]
We evaluate goodwill for impairment on an annual basis in our fourth fiscal quarter or more frequently if we believe impairment indicators exist. We have elected to first assess qualitative factors to determine whether it is more likely than not that the fair value of our reporting unit is less than its carrying amount, including goodwill. The qualitative assessment includes our evaluation of relevant events and circumstances affecting our single reporting unit, including macroeconomic, industry, and market conditions, our overall financial performance, and trends in the market price of our common stock. If qualitative factors indicate that it is more likely than not that our reporting unit’s fair value is less than its carrying amount, then we will perform the quantitative impairment test by comparing our reporting unit’s carrying amount, including goodwill, to its fair value. If the carrying amount of our reporting unit exceeds its fair value, an impairment loss will be recognized in an amount equal to that excess. To date, the results of our qualitative assessment have indicated that the quantitative goodwill impairment test is not necessary.

[0001327567-18-000024:mdna:178]
We evaluate long-lived assets, such as property, equipment, and purchased intangible assets for impairment whenever events or changes in circumstances indicate that the carrying amount of the assets may not be recoverable. Such events or changes in circumstances include, but are not limited to, a significant decrease in the fair value of the underlying asset or asset group, a significant decrease in the benefits realized from the acquired assets, difficulty and delays in integrating the business, or a significant change in the operations of the acquired assets or use of an asset or asset group. A long-lived asset is considered impaired if its carrying amount exceeds the estimated future undiscounted cash flows the asset or asset group is expected to generate. Critical estimates in determining whether a long-lived asset is considered impaired include the amount and timing of future cash flows that the asset or asset group is expected to generate. If a long-lived asset is considered to be impaired, the impairment to be recognized is the amount by which the carrying amount of the asset exceeds the fair value of the asset or asset group, which is estimated using a present value technique. Critical estimates in determining the fair value of an asset or asset group and the amount of impairment to recognize include, but are not limited to, the amount and timing of future cash flows that the asset or asset group is expected to generate and the discount rate. Determining the fair value of an asset or asset group is highly judgmental in nature and involves the use of significant estimates and assumptions for market participants. We base our fair value estimates on assumptions we believe to be reasonable but that are unpredictable and inherently uncertain. Actual future results may differ from those estimates.

[0001327567-18-000024:mdna:179]
- 51 -

[0001327567-18-000024:mdna:180]
Cease-use Loss

[0001327567-18-000024:mdna:181]
Upon exiting a leased property before the lease term expires, we assess the fair value of our remaining obligation under the lease and record a cease-use loss, if needed. The cease-use loss is calculated as the present value of the amount by which the remaining lease obligation, adjusted for the effects of any deferred items recognized under the lease and related costs, exceeds the estimated sublease rentals that could be reasonably obtained. The key assumptions used in our discounted cash flow model include the amount and timing of estimated sublease rental receipts and the discount rate. The cease-use loss recorded or to be recorded may change significantly as a result of the remeasurement of the cease-use liability, if the timing or amount of estimated cash flows change.

[0001327567-18-000024:mdna:182]
Recent Accounting Pronouncements

[0001327567-18-000024:mdna:183]
Refer to “Recently Issued Accounting Pronouncements” in Note 1. Description of Business and Summary of Significant Accounting Policies in Part II, Item 8 of this Annual Report on Form 10-K for a description of recent accounting pronouncements and our expectation of their impact, if any, on our results of operations and financial condition.
