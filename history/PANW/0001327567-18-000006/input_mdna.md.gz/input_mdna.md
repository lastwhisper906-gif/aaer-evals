# PANW MD&A — 0001327567-18-000006


## mdna

[0001327567-18-000006:mdna:1]
[same as prior period, unchanged from 0001327567-17-000035:mdna:1]

[0001327567-18-000006:mdna:2]
[same as prior period, unchanged from 0001327567-17-000035:mdna:2]

[0001327567-18-000006:mdna:3]
[same as prior period, unchanged from 0001327567-17-000035:mdna:3]

[0001327567-18-000006:mdna:4]
[same as prior period, unchanged from 0001327567-17-000035:mdna:4]

[0001327567-18-000006:mdna:5]
| • | Results of Operations. A discussion of the nature and trends in our financial results and an analysis of our financial results comparing the three and six months ended January 31, 2018 to the three and six months ended January 31, 2017. |

[0001327567-18-000006:mdna:6]
[same as prior period, unchanged from 0001327567-17-000035:mdna:7]

[0001327567-18-000006:mdna:7]
| • | Contractual Obligations and Commitments. An overview of our contractual obligations, contingent liabilities, commitments, and off-balance sheet arrangements outstanding as of January 31, 2018, including expected payment schedules. |

[0001327567-18-000006:mdna:8]
[same as prior period, unchanged from 0001327567-17-000035:mdna:9]

[0001327567-18-000006:mdna:9]
[same as prior period, unchanged from 0001327567-17-000035:mdna:10]

[0001327567-18-000006:mdna:10]
[same as prior period, unchanged from 0001327567-17-000035:mdna:11]

[0001327567-18-000006:mdna:11]
[same as prior period, unchanged from 0001327567-17-000035:mdna:12]

[0001327567-18-000006:mdna:12]
[same as prior period, unchanged from 0001327567-17-000035:mdna:28]

[0001327567-18-000006:mdna:13]
[same as prior period, unchanged from 0001327567-17-000035:mdna:13]

[0001327567-18-000006:mdna:14]
For the second quarter of fiscal 2018 and 2017, total revenue was $542.4 million and $422.6 million, respectively, representing year-over-year growth of 28.3%. Our growth reflects the increased adoption of our hybrid SaaS revenue model, which consists of product, subscriptions, and support. We believe this model will enable us to benefit from recurring revenues as we continue to grow our installed end-customer base. As of January 31, 2018, we had approximately 48,000 end-customers in over 150 countries. Our end-customers represent a broad range of industries, including education, energy, financial services, government entities, healthcare, Internet and media, manufacturing, public sector, and telecommunications, and include some of the largest Fortune 100 and Global 2000 companies in the world. We maintain a field sales force that works closely with our channel partners in developing sales opportunities. We use a two-tiered, indirect fulfillment model whereby we sell our products, subscriptions, and support to our distributors, which, in turn, sell to our resellers, which then sell to our end-customers.

[0001327567-18-000006:mdna:15]
Our product revenue was $202.2 million, or 37.3% of total revenue, for the second quarter of fiscal 2018, representing year-over-year growth of 19.8%. Product revenue is generated from sales of our appliances, primarily our Next-Generation Firewall, which is available in physical and virtualized form. Our Next-Generation Firewall incorporates our proprietary PAN-OS operating system, which provides a consistent set of capabilities across our entire product line. Our products are designed for different performance requirements throughout an organization, ranging from our PA-200, which is designed for enterprise remote offices, to our top-of-the-line PA-7080, which is especially suited for very large enterprise deployments and service provider customers. The same firewall functionality that is delivered in our physical appliances is also available in our VM-Series virtual firewalls, which secure virtualized and cloud-based computing environments.

[0001327567-18-000006:mdna:16]
Our subscription and support revenue was $340.2 million, or 62.7% of total revenue, for the second quarter of fiscal 2018, representing year-over-year growth of 34.0%. Our subscriptions provide our end-customers with real-time access to the latest antivirus, intrusion prevention, web filtering, and modern malware prevention capabilities across the network, endpoints, and the cloud. When end-customers purchase our physical or virtual firewall appliances, they typically purchase support in order to receive ongoing security updates, upgrades, bug fixes, and repairs. In addition to the subscriptions purchased with these appliances, end-customers may also purchase other subscriptions on a per-user, per-endpoint, or capacity-based basis.

[0001327567-18-000006:mdna:17]
We continue our investment in innovation as we evolve and further extend the capabilities of our platform, as we believe that innovation and timely development of new features and products is essential to meeting the needs of our end-customers and improving our competitive position. We introduced several new offerings during the first two quarters of fiscal 2018, including: the release of our GlobalProtect cloud service subscription, which provides our Next-Generation Security Platform as a cloud-based service for remote offices and mobile users; the release of our Logging Service subscription, which functions as the central cloud-based repository for application data and logs generated by our security offerings, including those of our firewalls and GlobalProtect cloud service subscription, and allows end-customers to collect data without needing to plan for local processing power and storage; and the launch of Magnifier, a cloud-based subscription that enables organizations to identify and prevent behavior-based threats by applying machine learning to rich network, endpoint, and cloud data. In addition, in February 2018, we introduced PAN-OS 8.1, with over 60 new features, and several new models of appliances, including the PA-3200 series with three models. The new hardware appliances increase SSL decryption throughput, bring higher performance and capacity for securing large data centers, and provide additional capabilities for managing large firewall deployments. We also recently announced expanded capabilities of our platform with extended protections to the Google Cloud Platform in addition to enhanced capabilities for AWS and Azure environments to enable customers to easily integrate with their cloud infrastructure and workloads in multi-cloud environments.

[0001327567-18-000006:mdna:18]
We believe that the growth of our business and our short-term and long-term success are dependent upon many factors, including our ability to extend our technology leadership, grow our base of end-customers, expand deployment of our platform and support offerings within existing end-customers, and focus on end-customer satisfaction. To manage any future growth effectively, we must continue to improve and expand our information technology and financial infrastructure, our operating and administrative systems and controls, and our ability to manage headcount, capital, and processes in an efficient manner. While these areas present significant opportunities for us, they also pose challenges and risks that we must successfully address in order to sustain the growth of our business and improve our operating results. For additional information regarding the challenges and risks we face, see the “Risk Factors” section in Part II, Item 1A of this Quarterly Report on Form 10-Q.

[0001327567-18-000006:mdna:19]
[same as prior period, unchanged from 0001327567-17-000035:mdna:34]

[0001327567-18-000006:mdna:20]
[same as prior period, unchanged from 0001327567-17-000035:mdna:22]

[0001327567-18-000006:mdna:21]
We monitor the key financial metrics set forth in the tables below to help us evaluate growth trends, establish budgets, measure the effectiveness of our sales and marketing efforts, and assess operational efficiencies. We discuss revenue, gross margin, and the components of operating loss and margin below under “—Results of Operations.”

[0001327567-18-000006:mdna:22]
|  | January 31, 2018 |  | July 31, 2017 |
|  | (in millions) |
| Total deferred revenue | $ | 1,996.7 |  |  | $ | 1,773.5 |  |
| Cash, cash equivalents, and investments | $ | 2,358.0 |  |  | $ | 2,164.3 |  |

[0001327567-18-000006:mdna:23]
|  | Three Months Ended January 31, |  | Six Months Ended January 31, |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |
|  | (dollars in millions) |
| Total revenue | $ | 542.4 |  |  | $ | 422.6 |  |  | $ | 1,047.9 |  |  | $ | 820.7 |  |
| Total revenue year-over-year percentage increase | 28.3 | % |  | 26.3 | % |  | 27.7 | % |  | 29.9 | % |
| Gross margin | 70.6 | % |  | 73.2 | % |  | 71.3 | % |  | 73.9 | % |
| Operating loss | $ | (31.8 | ) |  | $ | (54.4 | ) |  | $ | (86.1 | ) |  | $ | (103.4 | ) |
| Operating margin | (5.9 | )% |  | (12.9 | )% |  | (8.2 | )% |  | (12.6 | )% |
| Billings | $ | 674.6 |  |  | $ | 561.6 |  |  | $ | 1,271.1 |  |  | $ | 1,078.5 |  |
| Billings year-over-year percentage increase | 20.1 | % |  | 22.4 | % |  | 17.9 | % |  | 27.3 | % |
| Cash flow provided by operating activities |  |  |  |  | $ | 517.8 |  |  | $ | 417.8 |  |
| Free cash flow (non-GAAP) |  |  |  |  | $ | 460.0 |  |  | $ | 352.2 |  |

[0001327567-18-000006:mdna:24]
| • | Deferred Revenue. Our deferred revenue primarily consists of amounts that have been invoiced but have not been recognized as revenue as of the period end. The majority of our deferred revenue balance consists of subscription and support revenue that is recognized ratably over the contractual service period. We monitor our deferred revenue balance because it represents a significant portion of revenue to be recognized in future periods. |

[0001327567-18-000006:mdna:25]
| • | Billings. We define billings as total revenue plus the change in total deferred revenue, net of acquired deferred revenue, during the period. We consider billings to be a key metric used by management to manage our business given our hybrid SaaS revenue model, and believe billings provides investors with an important indicator of the health and visibility of our business because it includes subscription and support revenue, which is recognized ratably over the contractual service period, and product revenue, which is recognized at the time of shipment, provided that all other revenue recognition criteria have been met. We consider billings to be a useful metric for management and investors, particularly if we continue to experience increased sales of subscriptions and strong renewal rates for subscription and support offerings, and as we monitor our near term cash flows. While we believe that billings provides useful information to investors and others in understanding and evaluating our operating results in the same manner as our management, it is important to note that other companies, including companies in our industry, may not use billings, may calculate billings differently, may have different billing frequencies, or may use other financial measures to evaluate their performance, all of which could reduce the usefulness of billings as a comparative measure. We calculate billings in the following manner: |

[0001327567-18-000006:mdna:26]
|  | Three Months Ended January 31, |  | Six Months Ended January 31, |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |
|  | (in millions) |
| Billings: |  |  |  |  |  |  |  |
| Total revenue | $ | 542.4 |  |  | $ | 422.6 |  |  | $ | 1,047.9 |  |  | $ | 820.7 |  |
| Add: change in total deferred revenue, net of acquired deferred revenue | 132.2 |  |  | 139.0 |  |  | 223.2 |  |  | 257.8 |  |
| Billings | $ | 674.6 |  |  | $ | 561.6 |  |  | $ | 1,271.1 |  |  | $ | 1,078.5 |  |

[0001327567-18-000006:mdna:27]
| • | Cash Flow Provided by Operating Activities. We monitor cash flow provided by operating activities as a measure of our overall business performance. Our cash flow provided by operating activities is driven in large part by sales of our products and from up-front payments for subscription and support offerings. Monitoring cash flow provided by operating activities enables us to analyze our financial performance without the non-cash effects of certain items such as |

[0001327567-18-000006:mdna:28]
[same as prior period, unchanged from 0001327567-17-000035:mdna:41]

[0001327567-18-000006:mdna:29]
depreciation, amortization, and share-based compensation costs, thereby allowing us to better understand and manage the cash needs of our business.

[0001327567-18-000006:mdna:30]
[same as prior period, unchanged from 0001327567-17-000035:mdna:32]

[0001327567-18-000006:mdna:31]
|  | Six Months Ended January 31, |
|  | 2018 |  | 2017 |
|  | (in millions) |
| Free cash flow (non-GAAP): |  |  |  |
| Net cash provided by operating activities | $ | 517.8 |  |  | $ | 417.8 |  |
| Less: purchases of property, equipment, and other assets | 57.8 |  |  | 65.6 |  |
| Free cash flow (non-GAAP) | $ | 460.0 |  |  | $ | 352.2 |  |
| Net cash used in investing activities | $ | (88.5 | ) |  | $ | (244.3 | ) |
| Net cash used in financing activities | $ | (258.6 | ) |  | $ | (146.5 | ) |

[0001327567-18-000006:mdna:32]
[same as prior period, unchanged from 0001327567-17-000035:mdna:54]

[0001327567-18-000006:mdna:33]
[same as prior period, unchanged from 0001327567-17-000035:mdna:35]

[0001327567-18-000006:mdna:34]
[same as prior period, unchanged from 0001327567-17-000035:mdna:36]

[0001327567-18-000006:mdna:35]
|  | Three Months Ended January 31, |  | Six Months Ended January 31, |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |
|  | Amount |  | % of Revenue |  | Amount |  | % of Revenue |  | Amount |  | % of Revenue |  | Amount |  | % of Revenue |
|  | (dollars in millions) |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 202.2 |  |  | 37.3 | % |  | $ | 168.8 |  |  | 39.9 | % |  | $ | 388.7 |  |  | 37.1 | % |  | $ | 332.6 |  |  | 40.5 | % |
| Subscription and support | 340.2 |  |  | 62.7 | % |  | 253.8 |  |  | 60.1 | % |  | 659.2 |  |  | 62.9 | % |  | 488.1 |  |  | 59.5 | % |
| Total revenue | 542.4 |  |  | 100.0 | % |  | 422.6 |  |  | 100.0 | % |  | 1,047.9 |  |  | 100.0 | % |  | 820.7 |  |  | 100.0 | % |
| Cost of revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product | 63.9 |  |  | 11.8 | % |  | 45.8 |  |  | 10.8 | % |  | 121.5 |  |  | 11.6 | % |  | 88.0 |  |  | 10.7 | % |
| Subscription and support | 95.4 |  |  | 17.6 | % |  | 67.4 |  |  | 16.0 | % |  | 179.2 |  |  | 17.1 | % |  | 126.4 |  |  | 15.4 | % |
| Total cost of revenue(1) | 159.3 |  |  | 29.4 | % |  | 113.2 |  |  | 26.8 | % |  | 300.7 |  |  | 28.7 | % |  | 214.4 |  |  | 26.1 | % |
| Total gross profit | 383.1 |  |  | 70.6 | % |  | 309.4 |  |  | 73.2 | % |  | 747.2 |  |  | 71.3 | % |  | 606.3 |  |  | 73.9 | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | 96.6 |  |  | 17.8 | % |  | 89.9 |  |  | 21.3 | % |  | 190.8 |  |  | 18.2 | % |  | 174.1 |  |  | 21.2 | % |
| Sales and marketing | 265.0 |  |  | 48.9 | % |  | 226.7 |  |  | 53.6 | % |  | 523.5 |  |  | 49.9 | % |  | 446.8 |  |  | 54.4 | % |
| General and administrative | 53.3 |  |  | 9.8 | % |  | 47.2 |  |  | 11.2 | % |  | 119.0 |  |  | 11.4 | % |  | 88.8 |  |  | 10.9 | % |
| Total operating expenses(1) | 414.9 |  |  | 76.5 | % |  | 363.8 |  |  | 86.1 | % |  | 833.3 |  |  | 79.5 | % |  | 709.7 |  |  | 86.5 | % |
| Operating loss | (31.8 | ) |  | (5.9 | )% |  | (54.4 | ) |  | (12.9 | )% |  | (86.1 | ) |  | (8.2 | )% |  | (103.4 | ) |  | (12.6 | )% |
| Interest expense | (6.4 | ) |  | (1.2 | )% |  | (6.1 | ) |  | (1.4 | )% |  | (12.7 | ) |  | (1.2 | )% |  | (12.1 | ) |  | (1.5 | )% |
| Other income, net | 4.9 |  |  | 1.0 | % |  | 2.7 |  |  | 0.6 | % |  | 9.7 |  |  | 0.9 | % |  | 5.2 |  |  | 0.7 | % |
| Loss before income taxes | (33.3 | ) |  | (6.1 | )% |  | (57.8 | ) |  | (13.7 | )% |  | (89.1 | ) |  | (8.5 | )% |  | (110.3 | ) |  | (13.4 | )% |
| Provision for income taxes | 1.6 |  |  | 0.3 | % |  | 2.8 |  |  | 0.6 | % |  | 9.8 |  |  | 0.9 | % |  | 7.2 |  |  | 0.9 | % |
| Net loss | $ | (34.9 | ) |  | (6.4 | )% |  | $ | (60.6 | ) |  | (14.3 | )% |  | $ | (98.9 | ) |  | (9.4 | )% |  | $ | (117.5 | ) |  | (14.3 | )% |

[0001327567-18-000006:mdna:36]
[same as prior period, unchanged from 0001327567-17-000035:mdna:38]

[0001327567-18-000006:mdna:37]
[same as prior period, unchanged from 0001327567-17-000035:mdna:39]

[0001327567-18-000006:mdna:38]
|  | Three Months Ended January 31, |  | Six Months Ended January 31, |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Cost of product revenue | $ | 1.9 |  |  | $ | 2.0 |  |  | $ | 3.8 |  |  | $ | 3.7 |  |
| Cost of subscription and support revenue | 19.9 |  |  | 15.0 |  |  | 35.8 |  |  | 27.3 |  |
| Research and development | 35.5 |  |  | 41.3 |  |  | 73.0 |  |  | 79.3 |  |
| Sales and marketing | 53.3 |  |  | 49.7 |  |  | 104.5 |  |  | 93.5 |  |
| General and administrative | 20.2 |  |  | 19.3 |  |  | 39.4 |  |  | 36.8 |  |
| Total share-based compensation | $ | 130.8 |  |  | $ | 127.3 |  |  | $ | 256.5 |  |  | $ | 240.6 |  |

[0001327567-18-000006:mdna:39]
[same as prior period, unchanged from 0001327567-17-000035:mdna:68]

[0001327567-18-000006:mdna:40]
[same as prior period, unchanged from 0001327567-17-000035:mdna:42]

[0001327567-18-000006:mdna:41]
[same as prior period, unchanged from 0001327567-17-000035:mdna:43]

[0001327567-18-000006:mdna:42]
[same as prior period, unchanged from 0001327567-17-000035:mdna:44]

[0001327567-18-000006:mdna:43]
[same as prior period, unchanged from 0001327567-17-000035:mdna:45]

[0001327567-18-000006:mdna:44]
|  | Three Months Ended January 31, |  |  |  |  |  | Six Months Ended January 31, |  |  |  |  |
|  | 2018 |  | 2017 |  | Change |  | 2018 |  | 2017 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Product | $ | 202.2 |  |  | $ | 168.8 |  |  | $ | 33.4 |  |  | 19.8 | % |  | $ | 388.7 |  |  | $ | 332.6 |  |  | $ | 56.1 |  |  | 16.9 | % |

[0001327567-18-000006:mdna:45]
Product revenue increased for the three and six months ended January 31, 2018 compared to the three and six months ended January 31, 2017. The increase in both periods was primarily driven by demand for our newly introduced appliances. The change in product revenue due to pricing was not significant for either period.

[0001327567-18-000006:mdna:46]
[same as prior period, unchanged from 0001327567-17-000035:mdna:48]

[0001327567-18-000006:mdna:47]
[same as prior period, unchanged from 0001327567-17-000035:mdna:49]

[0001327567-18-000006:mdna:48]
|  | Three Months Ended January 31, |  |  |  |  |  | Six Months Ended January 31, |  |  |  |  |
|  | 2018 |  | 2017 |  | Change |  | 2018 |  | 2017 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Subscription | $ | 183.3 |  |  | $ | 134.3 |  |  | $ | 49.0 |  |  | 36.5 | % |  | $ | 352.6 |  |  | $ | 255.5 |  |  | $ | 97.1 |  |  | 38.0 | % |
| Support | 156.9 |  |  | 119.5 |  |  | 37.4 |  |  | 31.3 | % |  | 306.6 |  |  | 232.6 |  |  | 74.0 |  |  | 31.8 | % |
| Total subscription and support | $ | 340.2 |  |  | $ | 253.8 |  |  | $ | 86.4 |  |  | 34.0 | % |  | $ | 659.2 |  |  | $ | 488.1 |  |  | $ | 171.1 |  |  | 35.1 | % |

[0001327567-18-000006:mdna:49]
Subscription and support revenue increased for the three and six months ended January 31, 2018 compared to the three and six months ended January 31, 2017. The increase in both periods was due to increased demand for our subscription and support offerings from both new and existing end-customers. The mix between subscription revenue and support revenue will fluctuate over time, depending on the introduction of new subscription offerings, renewals of support services, and our ability to increase sales to new and existing customers. The change in subscription and support revenue due to changes in pricing was not significant for either period.

[0001327567-18-000006:mdna:50]
[same as prior period, unchanged from 0001327567-17-000035:mdna:52]

[0001327567-18-000006:mdna:51]
|  | Three Months Ended January 31, |  |  |  |  |  | Six Months Ended January 31, |  |  |  |  |
|  | 2018 |  | 2017 |  | Change |  | 2018 |  | 2017 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Americas | $ | 371.3 |  |  | $ | 295.0 |  |  | $ | 76.3 |  |  | 25.9 | % |  | $ | 722.6 |  |  | $ | 575.2 |  |  | $ | 147.4 |  |  | 25.6 | % |
| EMEA | 106.3 |  |  | 78.8 |  |  | 27.5 |  |  | 34.9 | % |  | 201.7 |  |  | 149.5 |  |  | 52.2 |  |  | 34.9 | % |
| APAC | 64.8 |  |  | 48.8 |  |  | 16.0 |  |  | 32.8 | % |  | 123.6 |  |  | 96.0 |  |  | 27.6 |  |  | 28.8 | % |
| Total revenue | $ | 542.4 |  |  | $ | 422.6 |  |  | $ | 119.8 |  |  | 28.3 | % |  | $ | 1,047.9 |  |  | $ | 820.7 |  |  | $ | 227.2 |  |  | 27.7 | % |

[0001327567-18-000006:mdna:52]
[same as prior period, unchanged from 0001327567-17-000035:mdna:80]

[0001327567-18-000006:mdna:53]
With respect to geographic theaters, the Americas contributed the largest portion of the increase in revenue for the three and six months ended January 31, 2018 compared to the three and six months ended January 31, 2017, due to its larger and more established sales force compared to our other theaters. Revenue from both Europe, the Middle East, and Africa (“EMEA”) and Asia Pacific and Japan (“APAC”) increased for the three and six months ended January 31, 2018 compared to the three and six months ended January 31, 2017, due to our investment in increasing the size of our sales force and number of channel partners in these theaters.

[0001327567-18-000006:mdna:54]
[same as prior period, unchanged from 0001327567-17-000035:mdna:56]

[0001327567-18-000006:mdna:55]
[same as prior period, unchanged from 0001327567-17-000035:mdna:57]

[0001327567-18-000006:mdna:56]
[same as prior period, unchanged from 0001327567-17-000035:mdna:58]

[0001327567-18-000006:mdna:57]
[same as prior period, unchanged from 0001327567-17-000035:mdna:59]

[0001327567-18-000006:mdna:58]
|  | Three Months Ended January 31, |  |  |  | Six Months Ended January 31, |  |  |  |  |
|  | 2018 |  | 2017 |  | Change |  | 2018 |  | 2017 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Cost of product revenue | $ | 63.9 |  |  | $ | 45.8 |  |  | $ | 18.1 |  |  | 39.5 | % |  | $ | 121.5 |  |  | $ | 88.0 |  |  | $ | 33.5 |  |  | 38.1 | % |
| Number of employees at period end | 91 |  |  | 92 |  |  | (1 | ) |  | (1.1 | )% |  | 91 |  |  | 92 |  |  | (1 | ) |  | (1.1 | )% |

[0001327567-18-000006:mdna:59]
Cost of product revenue increased for the three and six months ended January 31, 2018 compared to the three and six months ended January 31, 2017. The increase in both periods was primarily due to higher product costs related to our newly introduced appliances.

[0001327567-18-000006:mdna:60]
[same as prior period, unchanged from 0001327567-17-000035:mdna:62]

[0001327567-18-000006:mdna:61]
[same as prior period, unchanged from 0001327567-17-000035:mdna:63]

[0001327567-18-000006:mdna:62]
|  | Three Months Ended January 31, |  |  |  | Six Months Ended January 31, |  |  |  |  |
|  | 2018 |  | 2017 |  | Change |  | 2018 |  | 2017 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Cost of subscription and support revenue | $ | 95.4 |  |  | $ | 67.4 |  |  | $ | 28.0 |  |  | 41.5 | % |  | $ | 179.2 |  |  | $ | 126.4 |  |  | $ | 52.8 |  |  | 41.8 | % |
| Number of employees at period end | 813 |  |  | 623 |  |  | 190 |  |  | 30.5 | % |  | 813 |  |  | 623 |  |  | 190 |  |  | 30.5 | % |

[0001327567-18-000006:mdna:63]
Cost of subscription and support revenue increased for the three and six months ended January 31, 2018 compared to the three and six months ended January 31, 2017. The increase in both periods was driven by an increase in personnel costs, which grew $14.6 million to $54.3 million for the three months ended January 31, 2018 compared to the three months ended January 31, 2017, and grew $27.2 million to $101.4 million for the six months ended January 31, 2018 compared to the six months ended January 31, 2017. The increase in personnel costs in both periods was primarily due to headcount growth. The remaining increase in both periods was primarily due to costs to expand our customer service capabilities and infrastructure and allocated costs. The increase in allocated costs in both periods was primarily due to our expansion of facilities to support the growth of our business.

[0001327567-18-000006:mdna:64]
[same as prior period, unchanged from 0001327567-17-000035:mdna:66]

[0001327567-18-000006:mdna:65]
Gross margin, or gross profit as a percentage of revenue, has been and will continue to be affected by a variety of factors, including the introduction of new products, manufacturing costs, the average sales price of our products, the mix of products sold, and the mix of revenue between product and subscription and support offerings. For sales of our products, our higher-end firewall products generally have higher gross margins than our lower-end firewall products within each product series. For sales of our subscription and

[0001327567-18-000006:mdna:66]
[same as prior period, unchanged from 0001327567-17-000035:mdna:91]

[0001327567-18-000006:mdna:67]
support offerings, our subscription offerings typically have higher gross margins than our support offerings. We expect our gross margins to fluctuate over time depending on the factors described above.

[0001327567-18-000006:mdna:68]
|  | Three Months Ended January 31, |  | Six Months Ended January 31, |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |
|  | Amount |  | Gross Margin |  | Amount |  | Gross Margin |  | Amount |  | Gross Margin |  | Amount |  | Gross Margin |
|  | (dollars in millions) |
| Product | $ | 138.3 |  |  | 68.4 | % |  | $ | 123.0 |  |  | 72.9 | % |  | $ | 267.2 |  |  | 68.7 | % |  | $ | 244.6 |  |  | 73.5 | % |
| Subscription and support | 244.8 |  |  | 72.0 | % |  | 186.4 |  |  | 73.4 | % |  | 480.0 |  |  | 72.8 | % |  | 361.7 |  |  | 74.1 | % |
| Total gross profit | $ | 383.1 |  |  | 70.6 | % |  | $ | 309.4 |  |  | 73.2 | % |  | $ | 747.2 |  |  | 71.3 | % |  | $ | 606.3 |  |  | 73.9 | % |

[0001327567-18-000006:mdna:69]
Product gross margin decreased for the three and six months ended January 31, 2018 compared to the three and six months ended January 31, 2017, driven by higher product costs related to our newly introduced appliances, which have lower product margins.

[0001327567-18-000006:mdna:70]
Subscription and support gross margin decreased for the three and six months ended January 31, 2018 compared to the three and six months ended January 31, 2017, primarily due to higher costs related to the expansion of our infrastructure to support the adoption of our cloud-based subscription offerings.

[0001327567-18-000006:mdna:71]
[same as prior period, unchanged from 0001327567-17-000035:mdna:72]

[0001327567-18-000006:mdna:72]
Our operating expenses consist of research and development, sales and marketing, and general and administrative expense. Personnel costs are the most significant component of operating expenses and consist of salaries, benefits, bonuses, share-based compensation, travel and entertainment, and with regard to sales and marketing expense, sales commissions. Our operating expenses also include allocated costs, which consist of certain facilities, depreciation, benefits, recruiting, and information technology costs that we allocate based on headcount. We expect operating expenses to increase in absolute dollars and decrease over the long term as a percentage of revenue as we continue to scale our business. As of January 31, 2018, we expect to recognize approximately $976.2 million of share-based compensation expense over a weighted-average period of approximately 2.7 years, excluding additional share-based compensation expense related to any future grants of share-based awards. Share-based compensation expense is generally recognized on a straight-line basis over the requisite service periods of the awards.

[0001327567-18-000006:mdna:73]
[same as prior period, unchanged from 0001327567-17-000035:mdna:74]

[0001327567-18-000006:mdna:74]
[same as prior period, unchanged from 0001327567-17-000035:mdna:75]

[0001327567-18-000006:mdna:75]
|  | Three Months Ended January 31, |  |  |  |  |  | Six Months Ended January 31, |  |  |  |  |
|  | 2018 |  | 2017 |  | Change |  | 2018 |  | 2017 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Research and development | $ | 96.6 |  |  | $ | 89.9 |  |  | $ | 6.7 |  |  | 7.5 | % |  | $ | 190.8 |  |  | $ | 174.1 |  |  | $ | 16.7 |  |  | 9.6 | % |
| Number of employees at period end | 814 |  |  | 661 |  |  | 153 |  |  | 23.1 | % |  | 814 |  |  | 661 |  |  | 153 |  |  | 23.1 | % |

[0001327567-18-000006:mdna:76]
Research and development expense increased for the three and six months ended January 31, 2018 compared to the three and six months ended January 31, 2017. The increase in both periods was primarily due to an increase in personnel costs, which grew $3.1 million to $80.7 million for the three months ended January 31, 2018 compared to the three months ended January 31, 2017, and grew $8.9 million to $158.4 million for the six months ended January 31, 2018 compared to the six months ended January 31, 2017, as well as an increase in allocated costs. The increase in personnel costs in both periods was largely due to headcount growth. The increase in allocated costs in both periods was primarily due to our expansion of facilities to support the growth of our business.

[0001327567-18-000006:mdna:77]
[same as prior period, unchanged from 0001327567-17-000035:mdna:78]

[0001327567-18-000006:mdna:78]
Sales and marketing expense consists primarily of personnel costs, including commission expense. Sales and marketing expense also includes costs for market development programs, promotional and other marketing costs, professional services, and allocated costs. We continue to thoughtfully invest in headcount and have substantially grown our sales presence internationally. We

[0001327567-18-000006:mdna:79]
[same as prior period, unchanged from 0001327567-17-000035:mdna:103]

[0001327567-18-000006:mdna:80]
expect sales and marketing expense to continue to increase in absolute dollars as we increase the size of our sales and marketing organizations to increase touch points with end-customers and to expand our international presence, although our sales and marketing expense may fluctuate as a percentage of total revenue.

[0001327567-18-000006:mdna:81]
|  | Three Months Ended January 31, |  |  |  |  |  | Six Months Ended January 31, |  |  |  |  |
|  | 2018 |  | 2017 |  | Change |  | 2018 |  | 2017 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Sales and marketing | $ | 265.0 |  |  | $ | 226.7 |  |  | $ | 38.3 |  |  | 16.9 | % |  | $ | 523.5 |  |  | $ | 446.8 |  |  | $ | 76.7 |  |  | 17.2 | % |
| Number of employees at period end | 2,511 |  |  | 2,269 |  |  | 242 |  |  | 10.7 | % |  | 2,511 |  |  | 2,269 |  |  | 242 |  |  | 10.7 | % |

[0001327567-18-000006:mdna:82]
Sales and marketing expense increased for the three and six months ended January 31, 2018 compared to the three and six months ended January 31, 2017. The increase in both periods was primarily due to an increase in personnel costs, which grew $31.3 million to $210.7 million for the three months ended January 31, 2018 compared to the three months ended January 31, 2017, and grew $63.0 million to $407.7 million for the six months ended January 31, 2018 compared to the six months ended January 31, 2017. The increase in personnel costs in both periods was largely due to headcount growth. The remaining increase in both periods was primarily driven by an increase in allocated costs due to our expansion of facilities to support the growth of our business.

[0001327567-18-000006:mdna:83]
[same as prior period, unchanged from 0001327567-17-000035:mdna:83]

[0001327567-18-000006:mdna:84]
[same as prior period, unchanged from 0001327567-17-000035:mdna:84]

[0001327567-18-000006:mdna:85]
|  | Three Months Ended January 31, |  |  |  |  |  | Six Months Ended January 31, |  |  |  |  |
|  | 2018 |  | 2017 |  | Change |  | 2018 |  | 2017 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| General and administrative | $ | 53.3 |  |  | $ | 47.2 |  |  | $ | 6.1 |  |  | 12.9 | % |  | $ | 119.0 |  |  | $ | 88.8 |  |  | $ | 30.2 |  |  | 34.0 | % |
| Number of employees at period end | 604 |  |  | 492 |  |  | 112 |  |  | 22.8 | % |  | 604 |  |  | 492 |  |  | 112 |  |  | 22.8 | % |

[0001327567-18-000006:mdna:86]
General and administrative expense increased for the three months ended January 31, 2018 compared to the three months ended January 31, 2017, primarily due to an increase in personnel costs, which grew $4.5 million to $38.8 million, largely due to headcount growth.

[0001327567-18-000006:mdna:87]
General and administrative expense increased for the six months ended January 31, 2018 compared to the six months ended January 31, 2017, primarily due to a loss of $15.4 million recognized on the lease of our previous headquarter facilities in August 2017, when we officially ceased use of such facilities. Refer to Note 6. Commitments and Contingencies in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information on our cease-use loss. The remaining increase was primarily driven by an increase in personnel costs, which grew $8.4 million to $73.6 million, largely due to headcount growth, and an increase in allocated costs due to our expansion of facilities to support the growth of our business.

[0001327567-18-000006:mdna:88]
[same as prior period, unchanged from 0001327567-17-000035:mdna:87]

[0001327567-18-000006:mdna:89]
Provision for income taxes consists primarily of income taxes in foreign jurisdictions in which we conduct business, withholding taxes, U.S. state income taxes, and amortization of our deferred tax charges. We maintain a valuation allowance for domestic and certain foreign deferred tax assets, including net operating loss carryforwards and certain domestic tax credits. In recent years, we reorganized our corporate structure and intercompany relationships to more closely align with the international nature of our business activities. To the extent we revisit our corporate structure, it may have an impact on our tax provision.

[0001327567-18-000006:mdna:90]
On December 22, 2017, the Tax Cuts and Jobs Act (“TCJA”) was enacted into law. The TCJA provides for significant tax law changes and modifications including, but not limited to, the reduction of the U.S. federal corporate statutory tax rate from 35% to 21% as of January 1, 2018, the requirement for companies to pay a one-time transition tax on earnings of certain foreign subsidiaries that were previously tax deferred, and the creation of new taxes on certain foreign-sourced earnings. As a fiscal year-end taxpayer, certain

[0001327567-18-000006:mdna:91]
[same as prior period, unchanged from 0001327567-17-000035:mdna:121]

[0001327567-18-000006:mdna:92]
provisions of the TCJA began to impact us during the three months ended January 31, 2018, while other provisions will impact us beginning in our fiscal year ending July 31, 2019.

[0001327567-18-000006:mdna:93]
|  | Three Months Ended January 31, |  | Change |  | Six Months Ended January 31, |  | Change |
|  | 2018 |  | 2017 |  | Amount |  | % |  | 2018 |  | 2017 |  | Amount |  | % |
|  | (dollars in millions) |
| Provision for income taxes | $ | 1.6 |  |  | $ | 2.8 |  |  | $ | (1.2 | ) |  | (42.9 | )% |  | $ | 9.8 |  |  | $ | 7.2 |  |  | $ | 2.6 |  |  | 36.1 | % |
| Effective tax rate | (4.8 | )% |  | (4.8 | )% |  |  |  |  |  |  | (11.0 | )% |  | (6.5 | )% |  |  |  |  |  |

[0001327567-18-000006:mdna:94]
We recorded an income tax provision for the three and six months ended January 31, 2018. Components of our provision for income taxes include foreign income taxes, withholding taxes, amortization of our deferred tax charges, and a one-time tax benefit resulting from the TCJA for the three months ended January 31, 2018. Our provision for income taxes decreased for the three months ended January 31, 2018 compared to the three months ended January 31, 2017, primarily due to a one-time provisional benefit of $6.2 million relating to alternative minimum tax credits that will be refundable if not utilized due to the enactment of the TCJA, partially offset by overall growth in operations. Our provision for income taxes increased for the six months ended January 31, 2018 compared to the six months ended January 31, 2017, primarily due to overall growth in operations, partially offset by the aforementioned benefit from the TCJA.

[0001327567-18-000006:mdna:95]
During the three months ended January 31, 2018, we recognized provisional amounts for the tax effects of the TCJA which were included as components of income tax expense and reflected in the effective tax rates above. We will continue to assess the impact of the TCJA on our business and our condensed consolidated financial statements, however, the final impact of the TCJA may differ from the provisional amounts due to a number of uncertainties and factors, including information not available until the close of our fiscal year ending July 31, 2018, the need for further guidance and clarification of the new law by U.S. federal and state tax authorities, and the need for further guidance on the related income tax accounting. Refer to Note 9. Income Taxes in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information on the TCJA and its expected impact.

[0001327567-18-000006:mdna:96]
[same as prior period, unchanged from 0001327567-17-000035:mdna:92]

[0001327567-18-000006:mdna:97]
|  | January 31, 2018 |  | July 31, 2017 |
|  | (in millions) |
| Working capital(1) | $ | 353.8 |  |  | $ | 775.0 |  |
| Cash, cash equivalents, and investments: |  |  |  |
| Cash and cash equivalents | $ | 915.0 |  |  | $ | 744.3 |  |
| Investments | 1,443.0 |  |  | 1,420.0 |  |
| Total cash, cash equivalents, and investments | $ | 2,358.0 |  |  | $ | 2,164.3 |  |

[0001327567-18-000006:mdna:98]
[same as prior period, unchanged from 0001327567-17-000035:mdna:94]

[0001327567-18-000006:mdna:99]
| (1) | The net carrying amount of the 0.0% Convertible Senior Notes due 2019 (the “Notes”) was classified in current liabilities in our condensed consolidated balance sheets as of January 31, 2018. Refer to Note 5. Convertible Senior Notes in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information. |

[0001327567-18-000006:mdna:100]
At January 31, 2018, our total cash, cash equivalents, and investments of $2.4 billion were held for general corporate purposes, of which approximately $357.5 million was held outside of the United States. As of January 31, 2018, we had no unremitted earnings that would be subject to taxation in the United States when evaluating our outside basis differences relating to our investment in foreign subsidiaries; accordingly, there is no restriction on the use of these funds.

[0001327567-18-000006:mdna:101]
As of January 31, 2018, all of the Notes remained outstanding. The Notes mature on July 1, 2019, however, prior to January 1, 2019, holders may surrender their Notes for early conversion under certain circumstances. During the fiscal quarter ended January 31, 2018, one of the early conversion conditions was met, and as a result, holders may convert their Notes at any time during the fiscal quarter ending April 30, 2018. Upon conversion, we will pay cash equal to the aggregate principal amount of the Notes to be converted, and, at our election, will pay or deliver cash and/or shares of our common stock for the amount of our conversion obligation in excess of the aggregate principal amount of the Notes being converted. Refer to Note 5. Convertible Senior Notes in Part I, Item 1 of this Quarterly Report on Form 10-Q for information on the Notes.

[0001327567-18-000006:mdna:102]
In August 2016, our board of directors authorized a $500.0 million share repurchase and, in February 2017, authorized a $500.0 million increase to our repurchase program, bringing the total authorization to $1.0 billion. Repurchases are funded from available working capital and may be made at management’s discretion from time to time. The repurchase authorization will expire on December 31, 2018, and may be suspended or discontinued at any time. As of January 31, 2018, $330.0 million remained available for

[0001327567-18-000006:mdna:103]
- 27 -

[0001327567-18-000006:mdna:104]
future share repurchases under the repurchase authorization. Refer to Note 7. Stockholders’ Equity in Part I, Item 1 of this Quarterly Report on Form 10-Q for information on the repurchase authorization.

[0001327567-18-000006:mdna:105]
The following table summarizes our cash flows for the six months ended January 31, 2018 and 2017:

[0001327567-18-000006:mdna:106]
|  | Six Months Ended January 31, |
| 2018 |  | 2017 |
|  | (in millions) |
| Net cash provided by operating activities | $ | 517.8 |  |  | $ | 417.8 |  |
| Net cash used in investing activities | (88.5 | ) |  | (244.3 | ) |
| Net cash used in financing activities | (258.6 | ) |  | (146.5 | ) |
| Net increase in cash and cash equivalents | $ | 170.7 |  |  | $ | 27.0 |  |

[0001327567-18-000006:mdna:107]
[same as prior period, unchanged from 0001327567-17-000035:mdna:101]

[0001327567-18-000006:mdna:108]
[same as prior period, unchanged from 0001327567-17-000035:mdna:102]

[0001327567-18-000006:mdna:109]
[same as prior period, unchanged from 0001327567-17-000035:mdna:104]

[0001327567-18-000006:mdna:110]
[same as prior period, unchanged from 0001327567-17-000035:mdna:105]

[0001327567-18-000006:mdna:111]
Cash provided by operating activities during the six months ended January 31, 2018 was $517.8 million, an increase of $100.0 million compared to the six months ended January 31, 2017. The increase was due to growth of our business, as reflected by increases in billings and collections on accounts receivable, and the receipt of an upfront cash reimbursement of $38.2 million related to certain of our lease agreements during the six months ended January 31, 2018. The upfront cash reimbursement was received from our landlords in connection with the amendment of our lease agreements and will be applied against rental payments due in fiscal years 2018 through 2020. Refer to Note 6. Commitments and Contingencies in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information.

[0001327567-18-000006:mdna:112]
[same as prior period, unchanged from 0001327567-17-000035:mdna:107]

[0001327567-18-000006:mdna:113]
[same as prior period, unchanged from 0001327567-17-000035:mdna:108]

[0001327567-18-000006:mdna:114]
Cash used in investing activities during the six months ended January 31, 2018 was $88.5 million, a decrease of $155.8 million compared to the six months ended January 31, 2017, due to lower net purchases of available-for-sale investments during the six months ended January 31, 2018.

[0001327567-18-000006:mdna:115]
[same as prior period, unchanged from 0001327567-17-000035:mdna:110]

[0001327567-18-000006:mdna:116]
[same as prior period, unchanged from 0001327567-17-000035:mdna:111]

[0001327567-18-000006:mdna:117]
Cash used in financing activities during the six months ended January 31, 2018 was $258.6 million, an increase of $112.1 million compared to the six months ended January 31, 2017, primarily due to an increase in repurchases of our common stock and payments for tax withholding obligations of certain employees related to the net share settlement of equity awards during the six months ended January 31, 2018.

[0001327567-18-000006:mdna:118]
- 28 -

[0001327567-18-000006:mdna:119]
[same as prior period, unchanged from 0001327567-17-000035:mdna:113]

[0001327567-18-000006:mdna:120]
The following table summarizes our contractual obligations and commitments as of January 31, 2018:

[0001327567-18-000006:mdna:121]
|  | Payments Due by Period |
|  | Total |  | Less Than 1 Year |  | 1-3 Years |  | 3-5 Years |  | More Than 5 Years |
|  |  |  | (in millions) |  |  |
| 0.0% Convertible Senior Notes due 2019(1) | $ | 575.0 |  |  | $ | — |  |  | $ | 575.0 |  |  | $ | — |  |  | $ | — |  |
| Operating lease obligations(2) | 548.9 |  |  | 65.2 |  |  | 129.5 |  |  | 113.9 |  |  | 240.3 |  |
| Purchase obligations(3) | 121.5 |  |  | 121.5 |  |  | — |  |  | — |  |  | — |  |
| Total(4) | $ | 1,245.4 |  |  | $ | 186.7 |  |  | $ | 704.5 |  |  | $ | 113.9 |  |  | $ | 240.3 |  |

[0001327567-18-000006:mdna:122]
[same as prior period, unchanged from 0001327567-17-000035:mdna:116]

[0001327567-18-000006:mdna:123]
| (1) | As of January 31, 2018, holders may convert their Notes at any time during the fiscal quarter ending April 30, 2018. Refer to Note 5. Convertible Senior Notes in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information. |

[0001327567-18-000006:mdna:124]
| (2) | Consists of contractual obligations from our non-cancelable operating leases. Excludes contractual sublease proceeds of $15.4 million, which consists of $4.3 million to be received in less than one year, $9.8 million to be received in one to three years, and $1.3 million to be received in three to five years. Refer to Note 6. Commitments and Contingencies in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information on our operating leases. |

[0001327567-18-000006:mdna:125]
[same as prior period, unchanged from 0001327567-17-000035:mdna:119]

[0001327567-18-000006:mdna:126]
| (4) | No amounts related to income taxes are included. As of January 31, 2018, we had approximately $71.2 million of tax liabilities recorded related to uncertainty in income tax positions. |

[0001327567-18-000006:mdna:127]
[same as prior period, unchanged from 0001327567-17-000035:mdna:122]

[0001327567-18-000006:mdna:128]
As of January 31, 2018, we did not have any relationships with unconsolidated organizations or financial partnerships, such as structured finance or special purpose entities that would have been established for the purpose of facilitating off-balance sheet arrangements or other contractually narrow or limited purposes.

[0001327567-18-000006:mdna:129]
[same as prior period, unchanged from 0001327567-17-000035:mdna:124]

[0001327567-18-000006:mdna:130]
[same as prior period, unchanged from 0001327567-17-000035:mdna:125]

[0001327567-18-000006:mdna:131]
[same as prior period, unchanged from 0001327567-17-000035:mdna:126]

[0001327567-18-000006:mdna:132]
[same as prior period, unchanged from 0001327567-17-000035:mdna:127]

[0001327567-18-000006:mdna:133]
Refer to “Recently Issued Accounting Pronouncements” in Note 1. Description of Business and Summary of Significant Accounting Policies in Part I, Item 1 of this Quarterly Report on Form 10-Q.
