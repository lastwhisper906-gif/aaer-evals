# PANW note change history — 0001327567-17-000035 → 0001327567-18-000006


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2018-02-27):
[0001327567-18-000006:note_history:1]
In May 2015 and October 2015, we entered into a total of three lease agreements for approximately 941,000 square feet of corporate office space in Santa Clara, California, which serves as our new corporate headquarters. The leases contain rent holiday periods, scheduled rent increases, lease incentives, and renewal options which allow the lease terms to be extended beyond their expiration dates of July 2028 through July 2046. In September 2017, per the terms of the lease agreements, the landlords exercised their option to amend our lease payment schedules and eliminate our rent holiday periods, which increased our rental payments by $24.4 million, $11.8 million, and $2.0 million for fiscal 2018, 2019, and 2020, respectively. In exchange, we received an upfront cash reimbursement of $38.2 million during the three months ended October 31, 2017, which we will apply against the future additional rental payments when due. As amended, rental payments under the three lease agreements are approximately $412.0 million over the lease terms.
  (was, 2017-11-21, similarity 0.7893):
[0001327567-17-000035:note_history:1]
In May 2015 and October 2015, we entered into a total of three lease agreements for approximately 941,000 square feet of corporate office space in Santa Clara, California, which serves as our new corporate headquarters. The leases contain rent holiday periods, scheduled rent increases, lease incentives, and renewal options which allow the lease terms to be extended beyond their expiration dates of July 2028 through July 2046. In September 2017, per the terms of the lease agreements, the landlords exercised their option to amend our lease payment schedules and eliminate our rent holiday periods, which increased our rental payments by $24.4 million, $11.8 million, and $2.0 million for fiscal 2018, 2019, and 2020, respectively. In exchange, we received an upfront cash reimbursement of $38.2 million, which we will apply against the future additional rental payments when due. As amended, rental payments under the three lease agreements are approximately $412.0 million over the lease term.

- changed (2018-02-27):
[0001327567-18-000006:note_history:2]
In May 2015, we also entered into a lease agreement for approximately 122,000 square feet of space in Santa Clara, California, to serve as an extension of our previous corporate headquarters. The lease contains scheduled rent increases, lease incentives, and renewal options which allow the lease term to be extended beyond the expiration date of April 2021 through July 2046. Rental payments under the lease agreement are approximately $23.1 million over the lease term. In December 2017, we entered into an agreement to sublease this office space for the remaining lease term. Proceeds from this sublease will be approximately $16.3 million over the sublease term.
  (was, 2017-11-21, similarity 0.8275):
[0001327567-17-000035:note_history:2]
In May 2015, we also entered into a lease agreement for approximately 122,000 square feet of space in Santa Clara, California, to serve as an extension of our previous corporate headquarters. The lease contains scheduled rent increases, lease incentives, and renewal options which allow the lease term to be extended beyond the expiration date of April 2021 through July 2046. Rental payments under the lease agreement are approximately $23.1 million over the lease term.

- changed (2018-02-27):
[0001327567-18-000006:note_history:3]
In September 2012, we entered into two lease agreements for a total of approximately 300,000 square feet of space in Santa Clara, California, which served as our previous corporate headquarters through August 2017, when we relocated to our new corporate campus. The leases contain rent holiday periods and two separate five-year options to extend the lease terms beyond their expiration dates of July 2023. Rental payments under these lease agreements are approximately $94.3 million over the lease term. In August 2017, we exited our previous headquarter facilities and relocated to our new corporate campus, which resulted in the recognition of a cease-use loss of $15.4 million as general administrative expense in our condensed consolidated statements of operations during the three months ended October 31, 2017, and a corresponding liability in our condensed consolidated balance sheets. The cease-use loss of $15.4 million was calculated as the present value of the excess of the remaining lease obligation for the vacated facilities, adjusted for the effects of any deferred items recognized under the leases and related costs, over the estimated sublease rentals that could be reasonably obtained. The amount of the cease-use loss may vary if the timing or amount of estimated cash flows change. During the three and six months ended January 31, 2018, we released $2.7 million and $4.6 million, respectively, of the cease-use liability through rental payments. As of January 31, 2018, the remaining balance of the cease-use liability was $10.8 million, which is expected to be paid through the end of the lease term in July 2023.
  (was, 2017-11-21, similarity 0.808):
[0001327567-17-000035:note_history:3]
In September 2012, we entered into two lease agreements for a total of approximately 300,000 square feet of space in Santa Clara, California, which served as our previous corporate headquarters through August 2017, when we relocated to our new corporate campus. The leases contain rent holiday periods and two separate five-year options to extend the lease terms beyond their expiration dates of July 2023. Rental payments under these lease agreements are approximately $94.3 million over the lease term. In August 2017, we exited our previous headquarter facilities and relocated to our new corporate campus. As a result, we recognized a cease-use loss of $15.4 million as general administrative expense in our condensed consolidated statements of operations during the three months ended October 31, 2017 and a corresponding liability in our condensed consolidated balance sheets. The cease-use loss of $15.4 million was calculated as the present value of the excess of the remaining lease obligation for the vacated facilities, adjusted for the effects of any deferred items recognized under the leases and related costs, over the estimated sublease rentals that could be reasonably obtained. The amount of the cease-use loss may vary if the timing or amount of estimated cash flows change. During the three months ended October 31, 2017, $1.9 million of the cease-use liability was released through rental payments. As of October 31, 2017, the remaining balance of the cease-use liability was $13.5 million, which is expected to be paid through the end of the lease term in July 2023.

- changed (2018-02-27):
[0001327567-18-000006:note_history:4]
The following table presents details of the aggregate future non-cancelable minimum rental payments under our operating leases as of January 31, 2018 (in millions):
  (was, 2017-11-21, similarity 0.9623):
[0001327567-17-000035:note_history:4]
The following table presents details of the aggregate future non-cancelable minimum rental payments under our operating leases as of October 31, 2017 (in millions):

- changed (2018-02-27):
[0001327567-18-000006:note_history:5]
|  | Amount |
| Fiscal years ending July 31: |  |
| Remaining 2018 | $ | 32.1 |  |
| 2019 | 65.8 |  |
| 2020 | 66.1 |  |
| 2021 | 60.2 |  |
| 2022 | 56.8 |  |
| 2023 and thereafter | 267.9 |  |
| Committed gross lease payments | 548.9 |  |
| Less: proceeds from sublease rentals | 15.4 |  |
| Net operating lease obligation | $ | 533.5 |  |
  (was, 2017-11-21, similarity 0.9982):
[0001327567-17-000035:note_history:5]
|  | Amount |
| Fiscal years ending July 31: |  |
| Remaining 2018 | $ | 46.3 |  |
| 2019 | 65.5 |  |
| 2020 | 65.8 |  |
| 2021 | 60.1 |  |
| 2022 | 56.7 |  |
| 2023 and thereafter | 267.8 |  |
| Committed gross lease payments | 562.2 |  |
| Less: proceeds from sublease rental | 1.3 |  |
| Net operating lease obligation | $ | 560.9 |  |

- changed (2018-02-27):
[0001327567-18-000006:note_history:6]
Our electronics manufacturing service provider (“EMS provider”) procures components and assembles our products based on our forecasts. These forecasts are based on estimates of demand for our products primarily for the next 12 months, which are in turn based on historical trends and an analysis from our sales and product management organizations, adjusted for overall market conditions. In order to reduce manufacturing lead times and plan for adequate supply, we may issue non-cancelable orders for products and components to our manufacturing partners or component suppliers. As of January 31, 2018, our purchase commitments under such orders were $121.5 million, excluding obligations under contracts that we can cancel without a significant penalty.
  (was, 2017-11-21, similarity 0.9431):
[0001327567-17-000035:note_history:6]
Our electronics manufacturing service provider (“EMS provider”) procures components and assembles our products based on our forecasts. These forecasts are based on estimates of demand for our products primarily for the next 12 months, which are in turn based on historical trends and an analysis from our sales and product management organizations, adjusted for overall market conditions. In order to reduce manufacturing lead times and plan for adequate supply, we may issue non-cancelable orders for products and components to our manufacturing partners or component suppliers. As of October 31, 2017, our purchase commitments under such orders were $95.3 million, of which $2.8 million represent commitments through the year ending July 31, 2019, excluding obligations under contracts that we can cancel without a significant penalty.

- changed (2018-02-27):
[0001327567-18-000006:note_history:7]
To the extent there is a reasonable possibility that a loss exceeding amounts already recognized may be incurred and the amount of such additional loss would be material, we will either disclose the estimated additional loss or state that such an estimate cannot be made. As of January 31, 2018, we have not recorded any significant accruals for loss contingencies associated with such legal proceedings, determined that an unfavorable outcome is probable or reasonably possible, or determined that the amount or range of any possible loss is reasonably estimable.
  (was, 2017-11-21, similarity 0.9875):
[0001327567-17-000035:note_history:7]
To the extent there is a reasonable possibility that a loss exceeding amounts already recognized may be incurred and the amount of such additional loss would be material, we will either disclose the estimated additional loss or state that such an estimate cannot be made. As of October 31, 2017, we have not recorded any significant accruals for loss contingencies associated with such legal proceedings, determined that an unfavorable outcome is probable or reasonably possible, or determined that the amount or range of any possible loss is reasonably estimable.


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2018-02-27):
[0001327567-18-000006:note_history:8]
Our condensed consolidated financial statements are unaudited, but include all adjustments of a normal recurring nature necessary for a fair presentation of our quarterly results. We have made estimates and judgments affecting the amounts reported in our condensed consolidated financial statements and the accompanying notes. The actual results that we experience may differ materially from our estimates. Certain prior-period amounts have been reclassified to conform to current-period presentation.
  (was, 2017-11-21, similarity 0.636):
[0001327567-17-000035:note_history:8]
Our condensed consolidated financial statements are unaudited, but include all adjustments of a normal recurring nature necessary for a fair presentation of our quarterly results. We have made estimates and judgments affecting the amounts reported in our condensed consolidated financial statements and the accompanying notes. The actual results that we experience may differ materially from our estimates. Certain prior period amounts have been adjusted due to our early adoption of new accounting guidance related to share-based payments in our second quarter of fiscal 2017. For more information, refer to “Recently Adopted Accounting Pronouncements” in Note 1. Description of Business and Summary of Significant Accounting Policies included in Part II, Item 8 of our Annual Report on Form 10-K for the fiscal year ended July 31, 2017.

- changed (2018-02-27):
[0001327567-18-000006:note_history:9]
There have been no material changes to our significant accounting policies as of and for the six months ended January 31, 2018, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended July 31, 2017.
  (was, 2017-11-21, similarity 0.9004):
[0001327567-17-000035:note_history:9]
There have been no material changes to our significant accounting policies as of and for the three months ended October 31, 2017, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended July 31, 2017.

- added (2018-02-27):
[0001327567-18-000006:note_history:10]
Recently Adopted Accounting Pronouncements

- changed (2018-02-27):
[0001327567-18-000006:note_history:11]
In August 2017, the Financial Accounting Standards Board (“FASB”) issued new authoritative guidance on derivatives and hedging to better align an entity’s risk management activities and financial reporting for hedging relationships through changes to both the designation and measurement guidance for qualifying hedging relationships, and the presentation of hedge results. We early adopted the standard in our second quarter of fiscal 2018 on a modified retrospective basis. The adoption of this standard did not have a material impact on our condensed consolidated financial statements.
  (was, 2017-11-21, similarity 0.6728):
[0001327567-17-000035:note_history:11]
In August 2017, the Financial Accounting Standards Board (“FASB”) issued new authoritative guidance on derivatives and hedging to better align an entity’s risk management activities and financial reporting for hedging relationships through changes to both the designation and measurement guidance for qualifying hedging relationships, and the presentation of hedge results. The standard is effective for us in our first quarter of fiscal 2020 and will be applied on a modified retrospective basis. Early adoption is permitted.   We plan to early adopt the standard in our second quarter of fiscal 2018. We do not expect the adoption of the standard will have a material impact on our condensed consolidated financial statements.

- changed (2018-02-27):
[0001327567-18-000006:note_history:12]
In October 2016, the FASB issued authoritative guidance requiring the recognition of income tax consequences of an intra-entity transfer of an asset, other than inventory, when the transfer occurs. The standard is effective for us in our first quarter of fiscal 2019 and will be applied on a modified retrospective basis. Early adoption is permitted. We plan to adopt the standard in our first quarter of fiscal 2019. The adoption of this standard may have a material impact on our condensed consolidated financial statements, subject to any potential intra-entity transfers of assets (excluding inventory) and additional guidance and interpretations issued by U.S. regulatory and standard-setting bodies related to the Tax Cuts and Jobs Act (“TCJA”) enacted into law on December 22, 2017. Refer to Note 9. Income Taxes for more information on the TCJA.
  (was, 2017-11-21, similarity 0.833):
[0001327567-17-000035:note_history:12]
In October 2016, the FASB issued authoritative guidance requiring the recognition of income tax consequences of an intra-entity transfer of an asset, other than inventory, when the transfer occurs. The standard is effective for us in our first quarter of fiscal 2019 and will be applied on a modified retrospective basis. Early adoption is permitted. We plan to adopt the standard in our first quarter of fiscal 2019. The adoption of this standard may have a material impact on our condensed consolidated financial statements, subject to any potential intra-entity transfers of assets (excluding inventory).

- changed (2018-02-27):
[0001327567-18-000006:note_history:13]
We will adopt the standard in our first quarter of fiscal 2019 using the full retrospective method. However, our ability to apply the full retrospective method is dependent on system readiness and the completion of our analysis of information necessary to restate prior-period financial statements.
  (was, 2017-11-21, similarity 0.9966):
[0001327567-17-000035:note_history:13]
We will adopt the standard in our first quarter of fiscal 2019 using the full retrospective method. However, our ability to apply the full retrospective method is dependent on system readiness and the completion of our analysis of information necessary to restate prior period financial statements.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2018-02-27):
[0001327567-18-000006:note_history:14]
Our condensed consolidated financial statements are unaudited, but include all adjustments of a normal recurring nature necessary for a fair presentation of our quarterly results. We have made estimates and judgments affecting the amounts reported in our condensed consolidated financial statements and the accompanying notes. The actual results that we experience may differ materially from our estimates. Certain prior-period amounts have been reclassified to conform to current-period presentation.
  (was, 2017-11-21, similarity 0.636):
[0001327567-17-000035:note_history:14]
Our condensed consolidated financial statements are unaudited, but include all adjustments of a normal recurring nature necessary for a fair presentation of our quarterly results. We have made estimates and judgments affecting the amounts reported in our condensed consolidated financial statements and the accompanying notes. The actual results that we experience may differ materially from our estimates. Certain prior period amounts have been adjusted due to our early adoption of new accounting guidance related to share-based payments in our second quarter of fiscal 2017. For more information, refer to “Recently Adopted Accounting Pronouncements” in Note 1. Description of Business and Summary of Significant Accounting Policies included in Part II, Item 8 of our Annual Report on Form 10-K for the fiscal year ended July 31, 2017.

- changed (2018-02-27):
[0001327567-18-000006:note_history:15]
There have been no material changes to our significant accounting policies as of and for the six months ended January 31, 2018, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended July 31, 2017.
  (was, 2017-11-21, similarity 0.9004):
[0001327567-17-000035:note_history:15]
There have been no material changes to our significant accounting policies as of and for the three months ended October 31, 2017, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended July 31, 2017.


## us-gaap:ConvertibleDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-02-27):
[0001327567-18-000006:note_history:16]
The following table sets forth the components of the Notes as of January 31, 2018 and July 31, 2017 (in millions):
  (was, 2017-11-21, similarity 0.9423):
[0001327567-17-000035:note_history:16]
The following table sets forth the components of the Notes as of October 31, 2017 and July 31, 2017 (in millions):

- changed (2018-02-27):
[0001327567-18-000006:note_history:17]
|  | January 31, 2018 |  | July 31, 2017 |
| Liability: |  |  |  |
| Principal | $ | 575.0 |  |  | $ | 575.0 |  |
| Less: debt discount and debt issuance costs, net of amortization | 37.6 |  |  | 50.3 |  |
| Net carrying amount | $ | 537.4 |  |  | $ | 524.7 |  |
| Equity (including temporary equity) | $ | 109.8 |  |  | $ | 109.8 |  |
  (was, 2017-11-21, similarity 0.9748):
[0001327567-17-000035:note_history:17]
|  | October 31, 2017 |  | July 31, 2017 |
| Liability: |  |  |  |
| Principal | $ | 575.0 |  |  | $ | 575.0 |  |
| Less: debt discount and debt issuance costs, net of amortization | 44.0 |  |  | 50.3 |  |
| Net carrying amount | $ | 531.0 |  |  | $ | 524.7 |  |
| Equity (including temporary equity) | $ | 109.8 |  |  | $ | 109.8 |  |


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-02-27):
[0001327567-18-000006:note_history:18]
On or after January 1, 2019, holders may convert all or any portion of their Notes at any time prior to the close of business on the second scheduled trading day immediately preceding the maturity date regardless of the foregoing conditions. Upon conversion, holders will receive cash equal to the aggregate principal amount of the Notes to be converted, and, at our election, cash and/or shares of our common stock for any amounts in excess of the aggregate principal amount of the Notes being converted. As of January 31, 2018, all of the Notes remained outstanding.
  (was, 2017-11-21, similarity 0.9461):
[0001327567-17-000035:note_history:18]
On or after January 1, 2019, holders may convert all or any portion of their Notes at any time prior to the close of business on the second scheduled trading day immediately preceding the maturity date regardless of the foregoing conditions. Upon conversion, holders will receive cash equal to the aggregate principal amount of the Notes to be converted, and, at our election, cash and/or shares of our common stock for any amounts in excess of the aggregate principal amount of the Notes being converted.

- added (2018-02-27):
[0001327567-18-000006:note_history:19]
The sale price condition was met during the fiscal quarter ended January 31, 2018, and as a result, holders may convert their Notes at any time during the fiscal quarter ending April 30, 2018. Accordingly, the net carrying amount of the Notes was reclassified into current liabilities and the portion of the equity component representing the conversion option was reclassified into temporary equity in our condensed consolidated balance sheets as of January 31, 2018. The portion of the equity component classified as temporary equity is measured as the difference between the principal and net carrying amount of the Notes, excluding debt issuance costs. The sale price condition was not met during the fiscal quarter ended July 31, 2017. Since the Notes were not convertible, the net carrying amount of the Notes was classified as a long-term liability and the equity component was included in additional paid-in capital in our condensed consolidated balance sheets as of July 31, 2017.

- changed (2018-02-27):
[0001327567-18-000006:note_history:20]
The following table sets forth the components of the Notes as of January 31, 2018 and July 31, 2017 (in millions):
  (was, 2017-11-21, similarity 0.9423):
[0001327567-17-000035:note_history:20]
The following table sets forth the components of the Notes as of October 31, 2017 and July 31, 2017 (in millions):

- changed (2018-02-27):
[0001327567-18-000006:note_history:21]
|  | January 31, 2018 |  | July 31, 2017 |
| Liability: |  |  |  |
| Principal | $ | 575.0 |  |  | $ | 575.0 |  |
| Less: debt discount and debt issuance costs, net of amortization | 37.6 |  |  | 50.3 |  |
| Net carrying amount | $ | 537.4 |  |  | $ | 524.7 |  |
| Equity (including temporary equity) | $ | 109.8 |  |  | $ | 109.8 |  |
  (was, 2017-11-21, similarity 0.9748):
[0001327567-17-000035:note_history:21]
|  | October 31, 2017 |  | July 31, 2017 |
| Liability: |  |  |  |
| Principal | $ | 575.0 |  |  | $ | 575.0 |  |
| Less: debt discount and debt issuance costs, net of amortization | 44.0 |  |  | 50.3 |  |
| Net carrying amount | $ | 531.0 |  |  | $ | 524.7 |  |
| Equity (including temporary equity) | $ | 109.8 |  |  | $ | 109.8 |  |

- added (2018-02-27):
[0001327567-18-000006:note_history:22]
The total estimated fair value of the Notes was $839.6 million and $747.5 million at January 31, 2018 and July 31, 2017, respectively. The fair value was determined based on the closing trading price per $100 of the Notes as of the last day of trading for the period. We consider the fair value of the Notes at January 31, 2018 and July 31, 2017 to be a Level 2 measurement. The fair value of the Notes is primarily affected by the trading price of our common stock and market interest rates. As of January 31, 2018, the if-converted value of the Notes exceeded its principal amount by $218.2 million.

- added (2018-02-27):
[0001327567-18-000006:note_history:23]
|  | Three Months Ended |  | Six Months Ended |
|  | January 31, |  | January 31, |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Amortization of debt discount | $ | 5.8 |  |  | $ | 5.5 |  |  | $ | 11.4 |  |  | $ | 10.9 |  |
| Amortization of debt issuance costs | 0.6 |  |  | 0.6 |  |  | 1.3 |  |  | 1.2 |  |
| Total interest expense recognized | $ | 6.4 |  |  | $ | 6.1 |  |  | $ | 12.7 |  |  | $ | 12.1 |  |
| Effective interest rate of the liability component | 4.8 | % |  | 4.8 | % |  | 4.8 | % |  | 4.8 | % |

- removed (2018-02-27):
[0001327567-17-000035:note_history:24]
The sale price condition was met during the fiscal quarter ended October 31, 2017, and as a result, holders may convert their Notes at any time during the fiscal quarter ending January 31, 2018. Accordingly, the net carrying amount of the Notes was reclassified into current liabilities and the portion of the equity component representing the conversion option was reclassified into temporary equity in our condensed consolidated balance sheets as of October 31, 2017. The portion of the equity component classified as temporary equity is measured as the difference between the principal and net carrying amount of the Notes, excluding debt issuance costs. The sale price condition was not met during the fiscal quarter ended July 31, 2017. Since the Notes were not convertible, the net carrying amount of the Notes was classified as a long-term liability and the equity component was included in additional paid-in capital in our condensed consolidated balance sheets as of July 31, 2017.

- removed (2018-02-27):
[0001327567-17-000035:note_history:25]
The total estimated fair value of the Notes was $806.2 million and $747.5 million at October 31, 2017 and July 31, 2017, respectively. The fair value was determined based on the closing trading price per $100 of the Notes as of the last day of trading for the period. We consider the fair value of the Notes at October 31, 2017 and July 31, 2017 to be a Level 2 measurement. The fair value of the Notes is primarily affected by the trading price of our common stock and market interest rates. As of October 31, 2017, the if-converted value of the Notes exceeded its principal amount by $185.7 million.

- removed (2018-02-27):
[0001327567-17-000035:note_history:26]
|  | Three Months Ended |
|  | October 31, |
|  | 2017 |  | 2016 |
| Amortization of debt discount | $ | 5.6 |  |  | $ | 5.4 |  |
| Amortization of debt issuance costs | 0.7 |  |  | 0.6 |  |
| Total interest expense recognized | $ | 6.3 |  |  | $ | 6.0 |  |
| Effective interest rate of the liability component | 4.8 | % |  | 4.8 | % |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-02-27):
[0001327567-18-000006:note_history:27]
The following tables summarize the amortized cost, unrealized gains and losses, and fair value of our available-for-sale securities as of January 31, 2018 and July 31, 2017 (in millions):
  (was, 2017-11-21, similarity 0.9661):
[0001327567-17-000035:note_history:27]
The following tables summarize the amortized cost, unrealized gains and losses, and fair value of our available-for-sale securities as of October 31, 2017 and July 31, 2017 (in millions):

- added (2018-02-27):
[0001327567-18-000006:note_history:28]
|  | January 31, 2018 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Estimated Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Money market funds | $ | 325.7 |  |  | $ | — |  |  | $ | — |  |  | $ | 325.7 |  |
| U.S. government and agency securities | 3.5 |  |  | — |  |  | — |  |  | 3.5 |  |
| Total cash equivalents | $ | 329.2 |  |  | $ | — |  |  | $ | — |  |  | $ | 329.2 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 5.4 |  |  | $ | — |  |  | $ | — |  |  | $ | 5.4 |  |
| Corporate debt securities | 352.1 |  |  | 0.1 |  |  | (2.1 | ) |  | 350.1 |  |
| U.S. government and agency securities | 1,095.4 |  |  | — |  |  | (7.9 | ) |  | 1,087.5 |  |
| Total investments | $ | 1,452.9 |  |  | $ | 0.1 |  |  | $ | (10.0 | ) |  | $ | 1,443.0 |  |

- changed (2018-02-27):
[0001327567-18-000006:note_history:29]
Unrealized losses related to these securities are due to interest rate fluctuations as opposed to credit quality. In addition, we do not intend to sell and it is not likely that we would be required to sell these securities before recovery of their amortized cost basis, which may be at maturity. As a result, there were no other-than-temporary impairments for these securities at January 31, 2018 and July 31, 2017.
  (was, 2017-11-21, similarity 0.9556):
[0001327567-17-000035:note_history:29]
Unrealized losses related to these securities are due to interest rate fluctuations as opposed to credit quality. In addition, we do not intend to sell and it is not likely that we would be required to sell these securities before recovery of their amortized cost basis, which may be at maturity. As a result, there were no other-than-temporary impairments for these securities at October 31, 2017 and July 31, 2017.

- changed (2018-02-27):
[0001327567-18-000006:note_history:30]
The following table summarizes the amortized cost and fair value of our available-for-sale securities as of January 31, 2018, by contractual years-to-maturity (in millions):
  (was, 2017-11-21, similarity 0.9641):
[0001327567-17-000035:note_history:30]
The following table summarizes the amortized cost and fair value of our available-for-sale securities as of October 31, 2017, by contractual years-to-maturity (in millions):

- removed (2018-02-27):
[0001327567-17-000035:note_history:31]
|  | October 31, 2017 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Estimated Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Money market funds | $ | 250.1 |  |  | $ | — |  |  | $ | — |  |  | $ | 250.1 |  |
| U.S. government and agency securities | 5.0 |  |  | — |  |  | — |  |  | 5.0 |  |
| Total cash equivalents | $ | 255.1 |  |  | $ | — |  |  | $ | — |  |  | $ | 255.1 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 5.4 |  |  | $ | — |  |  | $ | — |  |  | $ | 5.4 |  |
| Corporate debt securities | 355.0 |  |  | 0.2 |  |  | (0.8 | ) |  | 354.4 |  |
| U.S. government and agency securities | 1,082.2 |  |  | — |  |  | (4.0 | ) |  | 1,078.2 |  |
| Total investments | $ | 1,442.6 |  |  | $ | 0.2 |  |  | $ | (4.8 | ) |  | $ | 1,438.0 |  |
