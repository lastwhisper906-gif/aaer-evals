# PANW notes — 0001327567-18-000006


## us-gaap:AvailableForSaleSecuritiesTextBlock

[0001327567-18-000006:notes:1]
The following tables summarize the amortized cost, unrealized gains and losses, and fair value of our available-for-sale securities as of January 31, 2018 and July 31, 2017 (in millions):

[0001327567-18-000006:notes:2]
|  | January 31, 2018 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Estimated Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Money market funds | $ | 325.7 |  |  | $ | — |  |  | $ | — |  |  | $ | 325.7 |  |
| U.S. government and agency securities | 3.5 |  |  | — |  |  | — |  |  | 3.5 |  |
| Total cash equivalents | $ | 329.2 |  |  | $ | — |  |  | $ | — |  |  | $ | 329.2 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 5.4 |  |  | $ | — |  |  | $ | — |  |  | $ | 5.4 |  |
| Corporate debt securities | 352.1 |  |  | 0.1 |  |  | (2.1 | ) |  | 350.1 |  |
| U.S. government and agency securities | 1,095.4 |  |  | — |  |  | (7.9 | ) |  | 1,087.5 |  |
| Total investments | $ | 1,452.9 |  |  | $ | 0.1 |  |  | $ | (10.0 | ) |  | $ | 1,443.0 |  |

[0001327567-18-000006:notes:3]
[same as prior period, unchanged from 0001327567-17-000035:notes:3]


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock

[0001327567-18-000006:notes:4]
[same as prior period, unchanged from 0001327567-17-000035:notes:4]

[0001327567-18-000006:notes:5]
[same as prior period, unchanged from 0001327567-17-000035:notes:5]

[0001327567-18-000006:notes:6]
[same as prior period, unchanged from 0001327567-17-000035:notes:6]

[0001327567-18-000006:notes:7]
[same as prior period, unchanged from 0001327567-17-000035:notes:7]

[0001327567-18-000006:notes:8]
[same as prior period, unchanged from 0001327567-17-000035:notes:8]

[0001327567-18-000006:notes:9]
Our condensed consolidated financial statements are unaudited, but include all adjustments of a normal recurring nature necessary for a fair presentation of our quarterly results. We have made estimates and judgments affecting the amounts reported in our condensed consolidated financial statements and the accompanying notes. The actual results that we experience may differ materially from our estimates. Certain prior-period amounts have been reclassified to conform to current-period presentation.

[0001327567-18-000006:notes:10]
[same as prior period, unchanged from 0001327567-17-000035:notes:10]

[0001327567-18-000006:notes:11]
[same as prior period, unchanged from 0001327567-17-000035:notes:11]

[0001327567-18-000006:notes:12]
There have been no material changes to our significant accounting policies as of and for the six months ended January 31, 2018, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended July 31, 2017.

[0001327567-18-000006:notes:13]
Recently Adopted Accounting Pronouncements

[0001327567-18-000006:notes:14]
[same as prior period, unchanged from 0001327567-17-000035:notes:14]

[0001327567-18-000006:notes:15]
In August 2017, the Financial Accounting Standards Board (“FASB”) issued new authoritative guidance on derivatives and hedging to better align an entity’s risk management activities and financial reporting for hedging relationships through changes to both the designation and measurement guidance for qualifying hedging relationships, and the presentation of hedge results. We early adopted the standard in our second quarter of fiscal 2018 on a modified retrospective basis. The adoption of this standard did not have a material impact on our condensed consolidated financial statements.

[0001327567-18-000006:notes:16]
Recently Issued Accounting Pronouncements

[0001327567-18-000006:notes:17]
[same as prior period, unchanged from 0001327567-17-000035:notes:16]

[0001327567-18-000006:notes:18]
[same as prior period, unchanged from 0001327567-17-000035:notes:17]

[0001327567-18-000006:notes:19]
[same as prior period, unchanged from 0001327567-17-000035:notes:18]

[0001327567-18-000006:notes:20]
[same as prior period, unchanged from 0001327567-17-000035:notes:19]

[0001327567-18-000006:notes:21]
[same as prior period, unchanged from 0001327567-17-000035:notes:20]

[0001327567-18-000006:notes:22]
In October 2016, the FASB issued authoritative guidance requiring the recognition of income tax consequences of an intra-entity transfer of an asset, other than inventory, when the transfer occurs. The standard is effective for us in our first quarter of fiscal 2019 and will be applied on a modified retrospective basis. Early adoption is permitted. We plan to adopt the standard in our first quarter of fiscal 2019. The adoption of this standard may have a material impact on our condensed consolidated financial statements, subject to any potential intra-entity transfers of assets (excluding inventory) and additional guidance and interpretations issued by U.S. regulatory and standard-setting bodies related to the Tax Cuts and Jobs Act (“TCJA”) enacted into law on December 22, 2017. Refer to Note 9. Income Taxes for more information on the TCJA.

[0001327567-18-000006:notes:23]
[same as prior period, unchanged from 0001327567-17-000035:notes:22]

[0001327567-18-000006:notes:24]
[same as prior period, unchanged from 0001327567-17-000035:notes:23]

[0001327567-18-000006:notes:25]
[same as prior period, unchanged from 0001327567-17-000035:notes:24]

[0001327567-18-000006:notes:26]
[same as prior period, unchanged from 0001327567-17-000035:notes:25]

[0001327567-18-000006:notes:27]
[same as prior period, unchanged from 0001327567-17-000035:notes:26]

[0001327567-18-000006:notes:28]
[same as prior period, unchanged from 0001327567-17-000035:notes:27]

[0001327567-18-000006:notes:29]
[same as prior period, unchanged from 0001327567-17-000035:notes:28]

[0001327567-18-000006:notes:30]
[same as prior period, unchanged from 0001327567-17-000035:notes:29]

[0001327567-18-000006:notes:31]
We will adopt the standard in our first quarter of fiscal 2019 using the full retrospective method. However, our ability to apply the full retrospective method is dependent on system readiness and the completion of our analysis of information necessary to restate prior-period financial statements.

[0001327567-18-000006:notes:32]
[same as prior period, unchanged from 0001327567-17-000035:notes:31]

[0001327567-18-000006:notes:33]
[same as prior period, unchanged from 0001327567-17-000035:notes:32]

[0001327567-18-000006:notes:34]
[same as prior period, unchanged from 0001327567-17-000035:notes:33]

[0001327567-18-000006:notes:35]
[same as prior period, unchanged from 0001327567-17-000035:notes:34]

[0001327567-18-000006:notes:36]
[same as prior period, unchanged from 0001327567-17-000035:notes:35]

[0001327567-18-000006:notes:37]
[same as prior period, unchanged from 0001327567-17-000035:notes:36]

[0001327567-18-000006:notes:38]
[same as prior period, unchanged from 0001327567-17-000035:notes:37]


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001327567-18-000006:notes:39]
Commitments and Contingencies

[0001327567-18-000006:notes:40]
We lease our facilities under various non-cancelable operating leases, which expire through the year ending July 31, 2028.

[0001327567-18-000006:notes:41]
In May 2015 and October 2015, we entered into a total of three lease agreements for approximately 941,000 square feet of corporate office space in Santa Clara, California, which serves as our new corporate headquarters. The leases contain rent holiday periods, scheduled rent increases, lease incentives, and renewal options which allow the lease terms to be extended beyond their expiration dates of July 2028 through July 2046. In September 2017, per the terms of the lease agreements, the landlords exercised their option to amend our lease payment schedules and eliminate our rent holiday periods, which increased our rental payments by $24.4 million, $11.8 million, and $2.0 million for fiscal 2018, 2019, and 2020, respectively. In exchange, we received an upfront cash reimbursement of $38.2 million during the three months ended October 31, 2017, which we will apply against the future additional rental payments when due. As amended, rental payments under the three lease agreements are approximately $412.0 million over the lease terms.

[0001327567-18-000006:notes:42]
In May 2015, we also entered into a lease agreement for approximately 122,000 square feet of space in Santa Clara, California, to serve as an extension of our previous corporate headquarters. The lease contains scheduled rent increases, lease incentives, and renewal options which allow the lease term to be extended beyond the expiration date of April 2021 through July 2046. Rental payments under the lease agreement are approximately $23.1 million over the lease term. In December 2017, we entered into an agreement to sublease this office space for the remaining lease term. Proceeds from this sublease will be approximately $16.3 million over the sublease term.

[0001327567-18-000006:notes:43]
In September 2012, we entered into two lease agreements for a total of approximately 300,000 square feet of space in Santa Clara, California, which served as our previous corporate headquarters through August 2017, when we relocated to our new corporate campus. The leases contain rent holiday periods and two separate five-year options to extend the lease terms beyond their expiration dates of July 2023. Rental payments under these lease agreements are approximately $94.3 million over the lease term. In August 2017, we exited our previous headquarter facilities and relocated to our new corporate campus, which resulted in the recognition of a cease-use loss of $15.4 million as general administrative expense in our condensed consolidated statements of operations during the three months ended October 31, 2017, and a corresponding liability in our condensed consolidated balance sheets. The cease-use loss of $15.4 million was calculated as the present value of the excess of the remaining lease obligation for the vacated facilities, adjusted for the effects of any deferred items recognized under the leases and related costs, over the estimated sublease rentals that could be reasonably obtained. The amount of the cease-use loss may vary if the timing or amount of estimated cash flows change. During the three and six months ended January 31, 2018, we released $2.7 million and $4.6 million, respectively, of the cease-use liability through rental payments. As of January 31, 2018, the remaining balance of the cease-use liability was $10.8 million, which is expected to be paid through the end of the lease term in July 2023.

[0001327567-18-000006:notes:44]
The following table presents details of the aggregate future non-cancelable minimum rental payments under our operating leases as of January 31, 2018 (in millions):

[0001327567-18-000006:notes:45]
|  | Amount |
| Fiscal years ending July 31: |  |
| Remaining 2018 | $ | 32.1 |  |
| 2019 | 65.8 |  |
| 2020 | 66.1 |  |
| 2021 | 60.2 |  |
| 2022 | 56.8 |  |
| 2023 and thereafter | 267.9 |  |
| Committed gross lease payments | 548.9 |  |
| Less: proceeds from sublease rentals | 15.4 |  |
| Net operating lease obligation | $ | 533.5 |  |

[0001327567-18-000006:notes:46]
Manufacturing Purchase Commitments

[0001327567-18-000006:notes:47]
Our electronics manufacturing service provider (“EMS provider”) procures components and assembles our products based on our forecasts. These forecasts are based on estimates of demand for our products primarily for the next 12 months, which are in turn based on historical trends and an analysis from our sales and product management organizations, adjusted for overall market conditions. In order to reduce manufacturing lead times and plan for adequate supply, we may issue non-cancelable orders for products and components to our manufacturing partners or component suppliers. As of January 31, 2018, our purchase commitments under such orders were $121.5 million, excluding obligations under contracts that we can cancel without a significant penalty.

[0001327567-18-000006:notes:48]
Litigation

[0001327567-18-000006:notes:49]
We are subject to legal proceedings, claims, and litigation arising in the ordinary course of business, including intellectual property litigation. Such matters are subject to many uncertainties and outcomes are not predictable with assurance. We accrue for contingencies when we believe that a loss is probable and that we can reasonably estimate the amount of any such loss.

[0001327567-18-000006:notes:50]
To the extent there is a reasonable possibility that a loss exceeding amounts already recognized may be incurred and the amount of such additional loss would be material, we will either disclose the estimated additional loss or state that such an estimate cannot be made. As of January 31, 2018, we have not recorded any significant accruals for loss contingencies associated with such legal proceedings, determined that an unfavorable outcome is probable or reasonably possible, or determined that the amount or range of any possible loss is reasonably estimable.


## us-gaap:ConvertibleDebtTableTextBlock

[0001327567-18-000006:notes:51]
The following table sets forth the components of the Notes as of January 31, 2018 and July 31, 2017 (in millions):

[0001327567-18-000006:notes:52]
|  | January 31, 2018 |  | July 31, 2017 |
| Liability: |  |  |  |
| Principal | $ | 575.0 |  |  | $ | 575.0 |  |
| Less: debt discount and debt issuance costs, net of amortization | 37.6 |  |  | 50.3 |  |
| Net carrying amount | $ | 537.4 |  |  | $ | 524.7 |  |
| Equity (including temporary equity) | $ | 109.8 |  |  | $ | 109.8 |  |


## us-gaap:DebtDisclosureTextBlock

[0001327567-18-000006:notes:53]
Convertible Senior Notes

[0001327567-18-000006:notes:54]
On June 30, 2014, we issued $575.0 million aggregate principal amount of 0.0% Convertible Senior Notes due 2019 (the “Notes”). The Notes mature on July 1, 2019 unless converted or repurchased in accordance with their terms prior to such date. The Notes do not contain any financial covenants and we cannot redeem the Notes prior to maturity.

[0001327567-18-000006:notes:55]
The Notes are convertible for up to 5.2 million shares of our common stock at an initial conversion price of approximately $110.28 per share of common stock, subject to adjustment. Holders of the Notes may surrender their Notes for conversion at their option at any time prior to the close of business on the business day immediately preceding January 1, 2019, only under the following circumstances:

[0001327567-18-000006:notes:56]
| • | during any fiscal quarter commencing after the fiscal quarter ending on October 31, 2014 (and only during such fiscal quarter), if the last reported sale price of our common stock for at least 20 trading days (whether or not consecutive) during a period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the conversion price for the Notes on each applicable trading day (the “sale price condition”); |

[0001327567-18-000006:notes:57]
| • | during the five business day period after any five consecutive trading day period, in which the trading price per $1,000 principal amount of Notes for each trading day of the measurement period was less than 98% of the product of the last reported sale price of our common stock and the conversion rate for the Notes on each such trading day; or |

[0001327567-18-000006:notes:58]
| • | upon the occurrence of specified corporate events. |

[0001327567-18-000006:notes:59]
On or after January 1, 2019, holders may convert all or any portion of their Notes at any time prior to the close of business on the second scheduled trading day immediately preceding the maturity date regardless of the foregoing conditions. Upon conversion, holders will receive cash equal to the aggregate principal amount of the Notes to be converted, and, at our election, cash and/or shares of our common stock for any amounts in excess of the aggregate principal amount of the Notes being converted. As of January 31, 2018, all of the Notes remained outstanding.

[0001327567-18-000006:notes:60]
The sale price condition was met during the fiscal quarter ended January 31, 2018, and as a result, holders may convert their Notes at any time during the fiscal quarter ending April 30, 2018. Accordingly, the net carrying amount of the Notes was reclassified into current liabilities and the portion of the equity component representing the conversion option was reclassified into temporary equity in our condensed consolidated balance sheets as of January 31, 2018. The portion of the equity component classified as temporary equity is measured as the difference between the principal and net carrying amount of the Notes, excluding debt issuance costs. The sale price condition was not met during the fiscal quarter ended July 31, 2017. Since the Notes were not convertible, the net carrying amount of the Notes was classified as a long-term liability and the equity component was included in additional paid-in capital in our condensed consolidated balance sheets as of July 31, 2017.

[0001327567-18-000006:notes:61]
The total estimated fair value of the Notes was $839.6 million and $747.5 million at January 31, 2018 and July 31, 2017, respectively. The fair value was determined based on the closing trading price per $100 of the Notes as of the last day of trading for the period. We consider the fair value of the Notes at January 31, 2018 and July 31, 2017 to be a Level 2 measurement. The fair value of the Notes is primarily affected by the trading price of our common stock and market interest rates. As of January 31, 2018, the if-converted value of the Notes exceeded its principal amount by $218.2 million.

[0001327567-18-000006:notes:62]
The following table sets forth interest expense recognized related to the Notes (dollars in millions):

[0001327567-18-000006:notes:63]
|  | Three Months Ended |  | Six Months Ended |
|  | January 31, |  | January 31, |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Amortization of debt discount | $ | 5.8 |  |  | $ | 5.5 |  |  | $ | 11.4 |  |  | $ | 10.9 |  |
| Amortization of debt issuance costs | 0.6 |  |  | 0.6 |  |  | 1.3 |  |  | 1.2 |  |
| Total interest expense recognized | $ | 6.4 |  |  | $ | 6.1 |  |  | $ | 12.7 |  |  | $ | 12.1 |  |
| Effective interest rate of the liability component | 4.8 | % |  | 4.8 | % |  | 4.8 | % |  | 4.8 | % |

[0001327567-18-000006:notes:64]
Note Hedges

[0001327567-18-000006:notes:65]
To minimize the impact of potential economic dilution upon conversion of the Notes, we entered into convertible note hedge transactions (the “Note Hedges”) with respect to our common stock concurrent with the issuance of the Notes. The Note Hedges cover up to 5.2 million shares of our common stock at a strike price per share that corresponds to the initial conversion price of the Notes, which are also subject to adjustment, and are exercisable upon conversion of the Notes. The Note Hedges will expire upon maturity of the Notes. The Note Hedges are separate transactions and are not part of the terms of the Notes. Holders of the Notes will not have any rights with respect to the Note Hedges. The shares receivable related to the Note Hedges are excluded from the calculation of diluted earnings per share as they are antidilutive.

[0001327567-18-000006:notes:66]
Warrants

[0001327567-18-000006:notes:67]
Separately, but concurrently with our issuance of the Notes, we entered into transactions whereby we sold warrants (the “Warrants”) to acquire up to 5.2 million shares of our common stock at a strike price of approximately $137.85 per share, subject to adjustments. The shares issuable under the Warrants will be included in the calculation of diluted earnings per share when the average market value per share of our common stock for the reporting period exceeds the strike price of the Warrants. The Warrants are separate transactions and are not part of the Notes or Note Hedges, and are not remeasured through earnings each reporting period. Holders of the Notes and Note Hedges will not have any rights with respect to the Warrants.

[0001327567-18-000006:notes:68]
For more information on the Notes, the Note Hedges, and the Warrants, refer to Note 8. Convertible Senior Notes included in Part II, Item 8 of our Annual Report on Form 10-K for the fiscal year ended July 31, 2017.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001327567-18-000006:notes:69]
[same as prior period, unchanged from 0001327567-17-000035:notes:68]

[0001327567-18-000006:notes:70]
As a global business, we are exposed to currency exchange rate risk. Substantially all of our revenue is transacted in U.S. dollars, however, a portion of our operating expenditures are incurred outside of the United States and are denominated in foreign currencies, making them subject to fluctuations in foreign currency exchange rates. We enter into foreign currency derivative contracts with maturities of 13 months or less which we designate as cash flow hedges to manage the foreign currency exchange rate risk associated with these expenditures.

[0001327567-18-000006:notes:71]
[same as prior period, unchanged from 0001327567-17-000035:notes:70]

[0001327567-18-000006:notes:72]
Our derivative financial instruments are recorded at fair value, on a gross basis, as either assets or liabilities in our condensed consolidated balance sheets. Gains or losses related to our cash flow hedges are recorded as a component of accumulated other comprehensive income (loss) (“AOCI”) in our condensed consolidated balance sheets and are reclassified into the financial statement line item associated with the underlying hedged transaction in our condensed consolidated statements of operations when the underlying hedged transaction is recognized in earnings. If it becomes probable that the hedged transaction will not occur, the cumulative unrealized gain or loss is reclassified immediately from AOCI into the financial statement line item associated with the underlying hedged transaction in our condensed consolidated statements of operations. Gains or losses related to non-designated derivative instruments are recognized in other income (expense), net in our condensed consolidated statements of operations for each period until the instrument matures, is terminated, is re-designated as a qualified cash flow hedge, or is sold. Derivatives designated as cash flow hedges are classified in our condensed consolidated statements of cash flows in the same manner as the underlying hedged transaction, primarily within cash flows from operating activities.

[0001327567-18-000006:notes:73]
As of January 31, 2018, the total notional amount of our outstanding foreign currency forward contracts was $149.4 million. We did not have any forward contracts outstanding as of July 31, 2017. Refer to Note 2. Fair Value Measurements for the fair value of our derivative instruments as reported in our condensed consolidated balance sheets as of January 31, 2018.

[0001327567-18-000006:notes:74]
During the three and six months ended January 31, 2018 and 2017, both unrealized gains (losses) recognized in AOCI related to our cash flow hedges and amounts reclassified into earnings were not material. Total unrealized gains (losses) in AOCI related to our cash flow hedges as of January 31, 2018 and 2017 were not material.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001327567-18-000006:notes:75]
[same as prior period, unchanged from 0001327567-17-000035:notes:74]

[0001327567-18-000006:notes:76]
[same as prior period, unchanged from 0001327567-17-000035:notes:75]

[0001327567-18-000006:notes:77]
Our 2012 Employee Stock Purchase Plan was adopted by our board of directors and approved by the stockholders on June 5, 2012, and was effective upon completion of our initial public offering (“IPO”). On August 29, 2017, we amended and restated our 2012 Employee Stock Purchase Plan (our “2012 ESPP”) to extend the length of our offering periods from six to 24 months. Under our 2012 ESPP, each 24-month offering period consists of four consecutive six-month purchase periods, with purchase dates on the first trading day on or after February 28 and August 31 of each year. Our 2012 ESPP permits eligible employees to acquire shares of our common stock at 85% of the lower of the fair market value of our common stock on the first trading day of each offering period or on the purchase date. If the fair market value of our common stock on the purchase date is lower than the first trading day of the offering period, the current offering period will be cancelled after purchase and a new 24-month offering period will begin. Participants may purchase shares of common stock through payroll deductions of up to 15% of their eligible compensation, subject to purchase limits of 625 shares per six-month purchase period and $25,000 worth of stock for each calendar year.

[0001327567-18-000006:notes:78]
[same as prior period, unchanged from 0001327567-17-000035:notes:77]

[0001327567-18-000006:notes:79]
[same as prior period, unchanged from 0001327567-17-000035:notes:78]

[0001327567-18-000006:notes:80]
|  | Options Outstanding |
|  | Number of Shares |  | Weighted-Average Exercise Price Per Share |  | Weighted-Average Remaining Contractual Term(Years) |  | Aggregate Intrinsic Value |
| Balance—July 31, 2017 | 1.6 |  |  | $ | 13.11 |  |  | 4.2 |  | $ | 190.6 |  |
| Options granted | — |  |  | $ | — |  |  |  |  |  |
| Options forfeited | — |  |  | $ | — |  |  |  |  |  |
| Options exercised | (0.2 | ) |  | $ | 11.11 |  |  |  |  |  |
| Balance—January 31, 2018 | 1.4 |  |  | $ | 13.41 |  |  | 3.8 |  | $ | 201.5 |  |
| Options exercisable—January 31, 2018 | 1.4 |  |  | $ | 13.41 |  |  | 3.8 |  | $ | 201.5 |  |

[0001327567-18-000006:notes:81]
[same as prior period, unchanged from 0001327567-17-000035:notes:80]

[0001327567-18-000006:notes:82]
[same as prior period, unchanged from 0001327567-17-000035:notes:81]

[0001327567-18-000006:notes:83]
[same as prior period, unchanged from 0001327567-17-000035:notes:82]

[0001327567-18-000006:notes:84]
|  | RSAs and PSAs Outstanding |  | RSUs and PSUs Outstanding |
|  | Number of Shares |  | Weighted-Average Grant-Date Fair Value Per Share |  | Number of Shares |  | Weighted-Average Grant-Date Fair Value Per Share |  | Weighted-Average Remaining Contractual Term(Years) |  | Aggregate Intrinsic Value |
| Balance—July 31, 2017 | 1.0 |  |  | $ | 163.55 |  |  | 6.5 |  |  | $ | 141.16 |  |  | 1.3 |  | $ | 854.1 |  |
| Granted(1) | — |  |  | $ | — |  |  | 2.4 |  |  | $ | 146.94 |  |  |  |  |  |
| Vested | (0.2 | ) |  | $ | 167.69 |  |  | (1.9 | ) |  | $ | 136.33 |  |  |  |  |  |
| Forfeited | (0.2 | ) |  | $ | 156.56 |  |  | (0.4 | ) |  | $ | 142.34 |  |  |  |  |  |
| Balance—January 31, 2018 | 0.6 |  |  | $ | 164.01 |  |  | 6.6 |  |  | $ | 144.59 |  |  | 1.5 |  | $ | 1,040.7 |  |

[0001327567-18-000006:notes:85]
[same as prior period, unchanged from 0001327567-17-000035:notes:84]

[0001327567-18-000006:notes:86]
[same as prior period, unchanged from 0001327567-17-000035:notes:85]

[0001327567-18-000006:notes:87]
[same as prior period, unchanged from 0001327567-17-000035:notes:86]

[0001327567-18-000006:notes:88]
[same as prior period, unchanged from 0001327567-17-000035:notes:87]

[0001327567-18-000006:notes:89]
|  | Three Months Ended |  | Six Months Ended |
|  | January 31, |  | January 31, |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Cost of product revenue | $ | 1.9 |  |  | $ | 2.0 |  |  | $ | 3.8 |  |  | $ | 3.7 |  |
| Cost of subscription and support revenue | 19.9 |  |  | 15.0 |  |  | 35.8 |  |  | 27.3 |  |
| Research and development | 35.5 |  |  | 41.3 |  |  | 73.0 |  |  | 79.3 |  |
| Sales and marketing | 53.3 |  |  | 49.7 |  |  | 104.5 |  |  | 93.5 |  |
| General and administrative | 20.2 |  |  | 19.3 |  |  | 39.4 |  |  | 36.8 |  |
| Total share-based compensation | $ | 130.8 |  |  | $ | 127.3 |  |  | $ | 256.5 |  |  | $ | 240.6 |  |

[0001327567-18-000006:notes:90]
As of January 31, 2018, total compensation cost related to unvested share-based awards not yet recognized was $976.2 million. This cost is expected to be amortized on a straight-line basis over a weighted-average period of approximately 2.7 years.


## us-gaap:EarningsPerShareTextBlock

[0001327567-18-000006:notes:91]
[same as prior period, unchanged from 0001327567-17-000035:notes:90]

[0001327567-18-000006:notes:92]
[same as prior period, unchanged from 0001327567-17-000035:notes:91]

[0001327567-18-000006:notes:93]
[same as prior period, unchanged from 0001327567-17-000035:notes:92]

[0001327567-18-000006:notes:94]
|  | Three Months Ended |  | Six Months Ended |
|  | January 31, |  | January 31, |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Net loss | $ | (34.9 | ) |  | $ | (60.6 | ) |  | $ | (98.9 | ) |  | $ | (117.5 | ) |
| Weighted-average shares used to compute net loss per share, basic and diluted | 91.1 |  |  | 90.7 |  |  | 91.0 |  |  | 90.2 |  |
| Net loss per share, basic and diluted | $ | (0.38 | ) |  | $ | (0.67 | ) |  | $ | (1.09 | ) |  | $ | (1.30 | ) |

[0001327567-18-000006:notes:95]
[same as prior period, unchanged from 0001327567-17-000035:notes:94]

[0001327567-18-000006:notes:96]
|  | Three and Six Months Ended |
|  | January 31, |
|  | 2018 |  | 2017 |
| RSUs and PSUs | 6.6 |  |  | 6.7 |  |
| Convertible senior notes | 5.2 |  |  | 5.2 |  |
| Warrants related to the issuance of convertible senior notes | 5.2 |  |  | 5.2 |  |
| Options to purchase common stock | 1.4 |  |  | 1.7 |  |
| RSAs and PSAs | 0.6 |  |  | 1.2 |  |
| ESPP shares | 0.2 |  |  | 0.1 |  |
| Total | 19.2 |  |  | 20.1 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001327567-18-000006:notes:97]
[same as prior period, unchanged from 0001327567-17-000035:notes:96]

[0001327567-18-000006:notes:98]
[same as prior period, unchanged from 0001327567-17-000035:notes:97]

[0001327567-18-000006:notes:99]
[same as prior period, unchanged from 0001327567-17-000035:notes:98]

[0001327567-18-000006:notes:100]
[same as prior period, unchanged from 0001327567-17-000035:notes:99]

[0001327567-18-000006:notes:101]
[same as prior period, unchanged from 0001327567-17-000035:notes:100]

[0001327567-18-000006:notes:102]
The following table presents the fair value of our financial assets and liabilities measured at fair value on a recurring basis using the above input categories as of January 31, 2018 and July 31, 2017 (in millions):

[0001327567-18-000006:notes:103]
|  |  | January 31, 2018 |  | July 31, 2017 |
|  |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Cash equivalents: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 325.7 |  |  | $ | — |  |  | $ | — |  |  | $ | 325.7 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| U.S. government and agency securities |  | — |  |  | 3.5 |  |  | — |  |  | 3.5 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Total cash equivalents |  | 325.7 |  |  | 3.5 |  |  | — |  |  | 329.2 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Short-term investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Certificates of deposit |  | — |  |  | 5.4 |  |  | — |  |  | 5.4 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Corporate debt securities |  | — |  |  | 183.3 |  |  | — |  |  | 183.3 |  |  | — |  |  | 159.4 |  |  | — |  |  | 159.4 |  |
| U.S. government and agency securities |  | — |  |  | 532.0 |  |  | — |  |  | 532.0 |  |  | — |  |  | 471.3 |  |  | — |  |  | 471.3 |  |
| Total short-term investments |  | — |  |  | 720.7 |  |  | — |  |  | 720.7 |  |  | — |  |  | 630.7 |  |  | — |  |  | 630.7 |  |
| Prepaid expenses and other current assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency forward contracts |  | — |  |  | 4.7 |  |  | — |  |  | 4.7 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Total prepaid expenses and other current assets |  | — |  |  | 4.7 |  |  | — |  |  | 4.7 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Long-term investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Certificates of deposit |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 5.4 |  |  | — |  |  | 5.4 |  |
| Corporate debt securities |  | — |  |  | 166.8 |  |  | — |  |  | 166.8 |  |  | — |  |  | 186.5 |  |  | — |  |  | 186.5 |  |
| U.S. government and agency securities |  | — |  |  | 555.5 |  |  | — |  |  | 555.5 |  |  | — |  |  | 597.4 |  |  | — |  |  | 597.4 |  |
| Total long-term investments |  | — |  |  | 722.3 |  |  | — |  |  | 722.3 |  |  | — |  |  | 789.3 |  |  | — |  |  | 789.3 |  |
| Total assets measured at fair value |  | $ | 325.7 |  |  | $ | 1,451.2 |  |  | $ | — |  |  | $ | 1,776.9 |  |  | $ | — |  |  | $ | 1,420.0 |  |  | $ | — |  |  | $ | 1,420.0 |  |
| Accrued and other liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency forward contracts |  | $ | — |  |  | $ | 0.1 |  |  | $ | — |  |  | $ | 0.1 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Total accrued and other liabilities |  | — |  |  | 0.1 |  |  | — |  |  | 0.1 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Total liabilities measured at fair value |  | $ | — |  |  | $ | 0.1 |  |  | $ | — |  |  | $ | 0.1 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |

[0001327567-18-000006:notes:104]
As of January 31, 2018, we did not have any assets required to be measured at fair value on a nonrecurring basis. As of July 31, 2017, we determined that certain property and equipment related to our prior corporate headquarters were impaired. In connection with our planned relocation to our new corporate headquarters, we assessed the recoverability of certain leasehold improvements and other long-lived assets associated with our previous headquarter facilities and determined that the carrying amount of these assets exceeded their fair value of $4.2 million. The resulting impairment loss of $20.9 million was recorded as general and administrative expense in our consolidated statements of operations during the fiscal year ended July 31, 2017. We calculated the fair value of the leasehold improvements and other long-lived assets based on estimated future discounted cash flows and classified the fair value as a Level 3 measurement due to the significance of unobservable inputs, which included the amount and timing of estimated sublease rental receipts that we could reasonably obtain over the remaining lease term and the discount rate. We did not have any liabilities required to be measured at fair value on a nonrecurring basis as of January 31, 2018 and July 31, 2017.

[0001327567-18-000006:notes:105]
Refer to Note 5. Convertible Senior Notes for the carrying amount and estimated fair value of our convertible senior notes as of January 31, 2018 and July 31, 2017.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001327567-18-000006:notes:106]
[same as prior period, unchanged from 0001327567-17-000035:notes:105]

[0001327567-18-000006:notes:107]
Our provision for income taxes for the three and six months ended January 31, 2018 reflects an effective tax rate of (4.8)% and (11.0)%, respectively. Our effective tax rates for these periods were negative as we recorded a provision for income taxes on year to date losses. The key components of our income tax provision primarily consist of foreign income taxes, withholding taxes, amortization of our deferred tax charges, and a one-time tax benefit during the three months ended January 31, 2018, resulting from new tax legislation enacted during the period. Our effective tax rate differs from the U.S. statutory tax rate primarily due to changes in non-deductible share-based compensation, foreign income at other than U.S. tax rates, and changes in our valuation allowance.

[0001327567-18-000006:notes:108]
Our provision for income taxes for the three and six months ended January 31, 2017 reflects an effective tax rate of (4.8)% and (6.5)%, respectively. Our effective tax rates for these periods were negative as we recorded a provision for income taxes on year to date losses. The key components of our income tax provision primarily consisted of foreign income taxes, withholding taxes, and amortization of our deferred tax charges.

[0001327567-18-000006:notes:109]
On December 22, 2017, the TCJA was enacted into law. The TCJA provides for significant tax law changes and modifications including, but not limited to, the reduction of the U.S. federal corporate statutory tax rate from 35% to 21% as of January 1, 2018, the requirement for companies to pay a one-time transition tax on earnings of certain foreign subsidiaries that were previously tax deferred, and the creation of new taxes on certain foreign-sourced earnings. As a fiscal year-end taxpayer, certain provisions of the TCJA began to impact us during the three months ended January 31, 2018, while other provisions will impact us beginning in our fiscal year ending July 31, 2019.

[0001327567-18-000006:notes:110]
As a result of the TCJA, we recorded a one-time provisional benefit of $6.2 million for the three months ended January 31, 2018, relating to alternative minimum tax credits that will be refundable if not utilized. We expect adjustments to our deferred tax assets resulting from the TCJA to be offset by a corresponding adjustment to our valuation allowance. We have not recorded any amounts relating to the transition tax because we had no unremitted earnings as of the measurement date, based on our current estimate.

[0001327567-18-000006:notes:111]
Accounting standards require companies to recognize the effect of tax law changes in the period of enactment. However, the SEC staff issued guidance which will allow companies to record provisional amounts during a measurement period not to extend beyond one year from the enactment date. In accordance with the guidance, we have determined the amounts recorded and positions taken, as discussed, are provisional as of January 31, 2018. The final impact of the TCJA recorded by us may differ from the provisional amounts due to a number of uncertainties and factors, including information not available until the close of our fiscal year ending July 31, 2018, the need for further guidance and clarification of the new law by U.S. federal and state tax authorities, and the need for further guidance on the related income tax accounting.

[0001327567-18-000006:notes:112]
In addition to the previously discussed impacts on our fiscal year ending January 31, 2018, the TCJA also establishes new tax laws that will be effective beginning with our fiscal year ending July 31, 2019, including a provision for low-taxed income of foreign subsidiaries. Due to its complexity, we are continuing to evaluate this provision of the TCJA. Based on recent FASB deliberations, we will be allowed to make an accounting policy election to either (i) treat taxes due on future U.S. inclusions in taxable income as a current-period expense when incurred or (ii) factor such amounts into our measurement of deferred taxes. Our selection of accounting policy will depend, in part, on analyzing our facts and circumstances to determine the expected impact under each method.


## us-gaap:InvestmentsClassifiedByContractualMaturityDateTableTextBlock

[0001327567-18-000006:notes:113]
The following table summarizes the amortized cost and fair value of our available-for-sale securities as of January 31, 2018, by contractual years-to-maturity (in millions):

[0001327567-18-000006:notes:114]
|  | Amortized Cost |  | Fair Value |
| Due within one year | $ | 1,052.1 |  |  | $ | 1,049.9 |  |
| Due between one and three years | 730.0 |  |  | 722.3 |  |
| Total | $ | 1,782.1 |  |  | $ | 1,772.2 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001327567-18-000006:notes:115]
Cash Equivalents and Investments

[0001327567-18-000006:notes:116]
Unrealized losses related to these securities are due to interest rate fluctuations as opposed to credit quality. In addition, we do not intend to sell and it is not likely that we would be required to sell these securities before recovery of their amortized cost basis, which may be at maturity. As a result, there were no other-than-temporary impairments for these securities at January 31, 2018 and July 31, 2017.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001327567-18-000006:notes:117]
[same as prior period, unchanged from 0001327567-17-000035:notes:112]

[0001327567-18-000006:notes:118]
[same as prior period, unchanged from 0001327567-17-000035:notes:113]

[0001327567-18-000006:notes:119]
In August 2016, our board of directors authorized a $500.0 million share repurchase that is funded from available working capital. In February 2017, our board of directors authorized a $500.0 million increase to our repurchase program, bringing the total authorization to $1.0 billion. Repurchases may be made at management’s discretion from time to time on the open market, through privately negotiated transactions, transactions structured through investment banking institutions, block purchase techniques, 10b5-1 trading plans, or a combination of the foregoing. The repurchase authorization will expire on December 31, 2018, and may be suspended or discontinued at any time.

[0001327567-18-000006:notes:120]
During the three and six months ended January 31, 2018, we repurchased and retired 0.9 million and 1.7 million shares, respectively, of our common stock under the authorization for an aggregate purchase price of $125.0 million and $250.0 million, respectively, including transaction costs. The total price of the shares repurchased and related transaction costs are reflected as a reduction to common stock and additional paid-in capital on our condensed consolidated balance sheets. As of January 31, 2018, $330.0 million remained available for future share repurchases under the repurchase authorization.
