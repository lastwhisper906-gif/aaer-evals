# PANW MD&A — 0001327567-15-000027


## mdna

[0001327567-15-000027:mdna:1]
| ITEM 7. | MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS |

[0001327567-15-000027:mdna:2]
The following discussion and analysis of our financial condition and results of operations should be read in conjunction with our consolidated financial statements and related notes appearing elsewhere in this Annual Report on Form 10-K. The following discussion and analysis contains forward-looking statements based on current expectations and assumptions that are subject to risks and uncertainties, which could cause our actual results to differ materially from those anticipated or implied by any forward-looking statements. Factors that could cause or contribute to such differences include, but are not limited to, those discussed in this Annual Report on Form 10-K, and in particular, the risks discussed under the caption “Risk Factors” in Part I, Item 1A of this report.

[0001327567-15-000027:mdna:3]
Our Management’s Discussion and Analysis of Financial Condition and Results of Operations (MD&A) is organized as follows:

[0001327567-15-000027:mdna:4]
| • | Overview. A discussion of our business and overall analysis of financial and other highlights in order to provide context for the remainder of MD&A. |

[0001327567-15-000027:mdna:5]
| • | Key Financial Metrics. A summary of our GAAP and non-GAAP key financial metrics, which management monitors to evaluate our performance. |

[0001327567-15-000027:mdna:6]
| • | Results of Operations. A discussion of the nature and trends of the components of our financial results and an analysis of our financial results comparing fiscal 2015 to 2014 and fiscal 2014 to 2013. |

[0001327567-15-000027:mdna:7]
| • | Liquidity and Capital Resources. An analysis of changes in our balance sheets and cash flows, and a discussion of our financial condition and our ability to meet cash needs. |

[0001327567-15-000027:mdna:8]
| • | Contractual Obligations and Commitments. An overview of our contractual obligations, contingent liabilities, commitments, and off-balance sheet arrangements outstanding as of July 31, 2015, including expected payment schedule. |

[0001327567-15-000027:mdna:9]
| • | Critical Accounting Policies and Estimates. A discussion of accounting policies that require critical estimates, assumptions, and judgments. |

[0001327567-15-000027:mdna:10]
| • | Recent Accounting Pronouncements. A discussion of expected impacts of impending accounting changes on financial information to be reported in the future. |

[0001327567-15-000027:mdna:11]
- 38 -

[0001327567-15-000027:mdna:12]
Overview

[0001327567-15-000027:mdna:13]
We have pioneered the next-generation of security with our innovative platform that empowers enterprises, service providers, and government entities to secure their organizations by safely enabling the increasingly complex and rapidly growing number of applications running on their networks and by preventing breaches in real-time that stem from targeted cyber attacks. Our platform uses an innovative traffic classification engine that identifies network traffic by application, user, and content. As a result, it provides in-depth visibility into all traffic and all applications, at the user level, at all times, and at the full speed of the network in order to control usage, content, risks, and cyber threats. Our security platform consists of three major elements: our Next-Generation Firewall, our Advanced Endpoint Protection, and our Threat Intelligence Cloud. Our Next-Generation Firewall delivers application, user, and content visibility and control as well as protection against network-based cyber threats integrated within the firewall through our proprietary hardware and software architecture. Our Advanced Endpoint Protection prevents cyber attacks that aim to exploit software vulnerabilities on a broad variety of fixed and virtual endpoints and servers. Our Threat Intelligence Cloud provides central intelligence capabilities, security for SaaS applications, and automated delivery of preventative measures against cyber attacks.

[0001327567-15-000027:mdna:14]
The network-based element of our platform is delivered in the form of a physical or virtual appliance and includes a suite of subscription services. The cyber attack prevention capabilities of our platform are delivered in the form of subscription services that can be used either in the public cloud or in a private cloud using a dedicated appliance. Our subscription services can be easily activated on any of our appliances without requiring additional hardware or processing resources, thereby providing a seamless implementation path for our end-customers.

[0001327567-15-000027:mdna:15]
For fiscal 2015, 2014, and 2013, revenues were $928.1 million, $598.2 million, and $396.1 million, respectively, representing year over year growth of 55.1% for fiscal 2015 and 51.0% for fiscal 2014. All three components of our hybrid SaaS revenue model experienced year over year growth, led by revenue from subscription services, which grew 72.6% to $212.7 million, followed by support and maintenance services, which grew 65.2% to $222.7 million, and product, which grew 44.8% to $492.7 million.

[0001327567-15-000027:mdna:16]
Our growth reflects the rapid adoption of our hybrid SaaS revenue model, which consists of product, subscriptions, and support and maintenance. We believe this model will enable us to benefit from recurring revenues as we continue to grow our installed end-customer base. Our growth was also driven by increased security spending by customers, as security continues to be a critical business imperative for every business in the world. As of July 31, 2015, we had sold our products and services to more than 26,000 end-customers in over 140 countries. Our end-customers represent a broad range of industries including education, energy, financial services, government entities, healthcare, Internet and media, manufacturing, public sector, and telecommunications, and include some of the largest Fortune 100 and Global 2000 companies in the world.

[0001327567-15-000027:mdna:17]
Product revenue is generated from sales of our appliances, primarily our Next-Generation Firewall, which is available in physical and virtualized form. Our Next-Generation Firewall incorporates our proprietary PAN-OS operating system, which provides a consistent set of capabilities across our entire product line. Our products are designed for different performance requirements throughout an organization, ranging from the PA-200, which is designed for enterprise remote offices, to the PA-7080, which is especially suited for service provider customers. The same firewall functionality that is delivered in our physical appliances is also available in our VM-Series virtual firewalls, which secure virtualized and cloud-based computing environments.

[0001327567-15-000027:mdna:18]
Services revenue is generated from sales of subscriptions and support and maintenance, which together provide us with a source of recurring services revenue. Our subscriptions provide our end-customers with real-time access to the latest antivirus, intrusion prevention, web filtering, and modern malware prevention capabilities across fixed and mobile devices.

[0001327567-15-000027:mdna:19]
We maintain a field sales force that works closely with our channel partners in developing sales opportunities. We use a two-tier, indirect fulfillment model whereby we sell our products and services to our global distributor channel partners, which, in turn, sell our products and services to our reseller network, which then sell to our end-customers. We leverage our appliances to sell SaaS subscription services to meet our customers’ evolving security requirements. When end-customers purchase an appliance, they typically purchase one or more of our subscriptions for additional functionality, as well as support and maintenance in order to receive ongoing security updates, upgrades, bug fixes, and repairs.

[0001327567-15-000027:mdna:20]
We continue to invest in innovation and strengthening our product portfolio, which resulted in several new product offerings and announcements during fiscal 2015. These new product offerings include: Traps, our Advanced Endpoint Protection service; the PA-3060 appliance, which is aimed at mid-sized datacenters; the M-500 management appliance, which is aimed at data centers and large enterprise deployments; and the AutoFocus cyber threat intelligence service, which provides prioritized actionable intelligence on targeted cyber attacks and is expected to be generally available in fiscal 2016. In August 2015, we announced the launch of the PA-7080 appliance, which is our top-of-the-line chassis-based appliance ideally suited for service provider customers. Additionally, in May 2015, we acquired CirroSecure, which expands the functionality of our platform by providing additional security for SaaS applications. The CirroSecure technology will be the foundation for a new subscription service called Aperture, which we expect to launch in fiscal 2016.

[0001327567-15-000027:mdna:21]
- 39 -

[0001327567-15-000027:mdna:22]
We believe that the growth of our business and our short-term and long-term success are dependent upon many factors, including our ability to extend our technology leadership, grow our base of end-customers, expand deployment of our platform and services within existing end-customers, extend the length of service terms within existing end-customers, and focus on end-customer satisfaction. While these areas present significant opportunities for us, they also pose challenges and risks that we must successfully address in order to sustain the growth of our business and improve our operating results.

[0001327567-15-000027:mdna:23]
To manage any future growth effectively, we must continue to improve and expand our information technology and financial infrastructure, our operating and administrative systems and controls, and our ability to manage headcount, capital, and processes in an efficient manner. Additionally, we face intense competition in our market, and to succeed, we need to innovate and offer products that are differentiated from existing infrastructure products, as well as effectively hire, retain, train, and motivate qualified personnel and senior management. If we are unable to successfully address these challenges, our business, operating results, and prospects could be adversely affected.

[0001327567-15-000027:mdna:24]
Key Financial Metrics

[0001327567-15-000027:mdna:25]
We monitor the key financial metrics set forth below to help us evaluate growth trends, establish budgets, measure the effectiveness of our sales and marketing efforts, and assess operational efficiencies. We discuss revenue, gross margin, and the components of operating loss and margin below under “—Financial Overview” and “—Results of Operations.” The following tables summarize deferred revenue, cash flow provided by operating activities, free cash flow (non-GAAP), and billings (non-GAAP).

[0001327567-15-000027:mdna:26]
|  | July 31, |
|  | 2015 |  | 2014 |
|  | (in thousands) |
| Total deferred revenue | $ | 713,654 |  |  | $ | 422,578 |  |
| Cash, cash equivalents, and investments | $ | 1,327,820 |  |  | $ | 974,382 |  |

[0001327567-15-000027:mdna:27]
|  | Year Ended July 31, |
|  | 2015 |  | 2014 |  | 2013 |
|  | (dollars in thousands) |
| Total revenue | $ | 928,052 |  |  | $ | 598,179 |  |  | $ | 396,107 |  |
| Year over year percentage increase | 55.1 | % |  | 51.0 | % |  | 55.3 | % |
| Gross margin percentage | 72.9 | % |  | 73.3 | % |  | 72.3 | % |
| Operating loss | $ | (133,536 | ) |  | $ | (215,347 | ) |  | $ | (18,621 | ) |
| Operating margin percentage | (14.4 | )% |  | (36.0 | )% |  | (4.7 | )% |
| Billings (non-GAAP) | $ | 1,219,128 |  |  | $ | 771,375 |  |  | $ | 509,529 |  |
| Cash flow provided by operating activities | $ | 350,304 |  |  | $ | 88,406 |  |  | $ | 114,519 |  |
| Free cash flow (non-GAAP) | $ | 316,476 |  |  | $ | 52,299 |  |  | $ | 92,077 |  |

[0001327567-15-000027:mdna:28]
| • | Deferred Revenue. Our deferred revenue consists of amounts that have been invoiced, but have not been recognized as revenue as of the period end. The majority of our deferred revenue balance consists of subscription and support and maintenance revenue that is recognized ratably over the contractual service period. We monitor our deferred revenue balance because it represents a significant portion of revenue to be recognized in future periods. |

[0001327567-15-000027:mdna:29]
| • | Cash Flow Provided by Operating Activities. We monitor cash flow provided by operating activities as a measure of our overall business performance. Our cash flow provided by operating activities is driven in large part by sales of our products and from up-front payments for both subscriptions and support and maintenance services. Monitoring cash flow provided by operating activities enables us to analyze our financial performance without the non-cash effects of certain items such as depreciation, amortization, and share-based compensation costs, thereby allowing us to better understand and manage the cash needs of our business. |

[0001327567-15-000027:mdna:30]
| • | Free Cash Flow (non-GAAP). We define free cash flow, a non-GAAP financial measure, as cash provided by operating activities less purchases of property, equipment, and other assets. We consider free cash flow to be a liquidity measure that provides useful information to management and investors about the amount of cash generated by the business that, after the purchases of property, equipment, and other productive assets, can be used for strategic opportunities, including investing in our business, making strategic acquisitions, and strengthening the balance sheet. |

[0001327567-15-000027:mdna:31]
- 40 -

[0001327567-15-000027:mdna:32]
A limitation of the utility of free cash flow as a measure of our financial performance and liquidity is that it does not represent the total increase or decrease in our cash balance for the period. In addition, it is important to note that other companies, including companies in our industry, may not use free cash flow, may calculate free cash flow in a different manner than we do, or may use other financial measures to evaluate their performance, all of which could reduce the usefulness of free cash flow as a comparative measure. A reconciliation of free cash flow to cash flow provided by operating activities, the most directly comparable financial measure calculated and presented in accordance with GAAP, is provided below:

[0001327567-15-000027:mdna:33]
|  | Year Ended July 31, |
|  | 2015 |  | 2014 |  | 2013 |
|  | (in thousands) |
| Free cash flow (non-GAAP): |  |  |  |  |  |
| Cash flow provided by operating activities | $ | 350,304 |  |  | $ | 88,406 |  |  | $ | 114,519 |  |
| Less: purchases of property, equipment, and other assets | 33,828 |  |  | 36,107 |  |  | 22,442 |  |
| Free cash flow (non-GAAP) (1) | $ | 316,476 |  |  | $ | 52,299 |  |  | $ | 92,077 |  |
| Net cash used in investing activities | $ | (679,006 | ) |  | $ | (320,348 | ) |  | $ | (151,565 | ) |
| Net cash provided by financing activities | $ | 50,704 |  |  | $ | 575,140 |  |  | $ | 25,018 |  |

[0001327567-15-000027:mdna:34]
______________

[0001327567-15-000027:mdna:35]
| (1) | Includes our cash payments of $75.0 million and $20.0 million in fiscal 2014 for the legal settlement with Juniper and the Mutual Covenant Not to Sue and Release Agreement with Fortinet, respectively. |

[0001327567-15-000027:mdna:36]
| • | Billings (non-GAAP). We define billings, a non-GAAP financial measure, as total revenue plus the change in deferred revenue, net of acquired deferred revenue, during the period. Billings is a key measure used by our management to manage our business because billings drive deferred revenue, which is an important indicator of the health and visibility of our business. We consider billings to be a useful metric for management and investors, particularly as we experience increased sales of subscriptions and strong renewal rates for subscriptions and support and maintenance services, and monitor our near term cash flows. We believe that billings provides useful information to investors and others in understanding and evaluating our operating results in the same manner as our management. However, it is important to note that other companies, including companies in our industry, may not use billings, may calculate billings differently, may have different billing frequencies, or may use other financial measures to evaluate their performance, all of which could reduce the usefulness of billings as a comparative measure. A reconciliation of billings to revenue, the most directly comparable financial measure calculated and presented in accordance with GAAP, is provided below: |

[0001327567-15-000027:mdna:37]
|  | Year Ended July 31, |
|  | 2015 |  | 2014 |  | 2013 |
|  | (in thousands) |
| Billings (non-GAAP): |  |  |  |  |  |
| Total revenue | $ | 928,052 |  |  | $ | 598,179 |  |  | $ | 396,107 |  |
| Add: change in total deferred revenue, net of acquired deferred revenue | 291,076 |  |  | 173,196 |  |  | 113,422 |  |
| Billings (non-GAAP) | $ | 1,219,128 |  |  | $ | 771,375 |  |  | $ | 509,529 |  |

[0001327567-15-000027:mdna:38]
- 41 -

[0001327567-15-000027:mdna:39]
Results of Operations

[0001327567-15-000027:mdna:40]
The following tables summarize our results of operations for the periods presented and as a percentage of our total revenue for those periods. The period to period comparison of results is not necessarily indicative of results for future periods.

[0001327567-15-000027:mdna:41]
|  | Year Ended July 31, |
|  | 2015 |  | 2014 |  | 2013 |
|  | Amount |  | % of Revenue |  | Amount |  | % of Revenue |  | Amount |  | % of Revenue |
|  | (dollars in thousands) |
| Consolidated Statements of Operations Data: |  |  |  |  |  |  |  |  |  |  |  |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 492,658 |  |  | 53.1 | % |  | $ | 340,143 |  |  | 56.9 | % |  | $ | 243,707 |  |  | 61.5 | % |
| Services | 435,394 |  |  | 46.9 | % |  | 258,036 |  |  | 43.1 | % |  | 152,400 |  |  | 38.5 | % |
| Total revenue | 928,052 |  |  | 100.0 | % |  | 598,179 |  |  | 100.0 | % |  | 396,107 |  |  | 100.0 | % |
| Cost of revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Product | 131,094 |  |  | 14.1 | % |  | 85,503 |  |  | 14.3 | % |  | 63,412 |  |  | 16.0 | % |
| Services | 120,405 |  |  | 13.0 | % |  | 74,125 |  |  | 12.4 | % |  | 46,344 |  |  | 11.7 | % |
| Total cost of revenue | 251,499 |  |  | 27.1 | % |  | 159,628 |  |  | 26.7 | % |  | 109,756 |  |  | 27.7 | % |
| Total gross profit | 676,553 |  |  | 72.9 | % |  | 438,551 |  |  | 73.3 | % |  | 286,351 |  |  | 72.3 | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | 185,828 |  |  | 20.0 | % |  | 104,813 |  |  | 17.5 | % |  | 62,482 |  |  | 15.8 | % |
| Sales and marketing | 522,696 |  |  | 56.3 | % |  | 334,763 |  |  | 56.0 | % |  | 199,771 |  |  | 50.4 | % |
| General and administrative | 101,565 |  |  | 11.0 | % |  | 73,149 |  |  | 12.2 | % |  | 42,719 |  |  | 10.8 | % |
| Legal settlement | — |  |  | — | % |  | 141,173 |  |  | 23.6 | % |  | — |  |  | — | % |
| Total operating expenses | 810,089 |  |  | 87.3 | % |  | 653,898 |  |  | 109.3 | % |  | 304,972 |  |  | 77.0 | % |
| Operating loss | (133,536 | ) |  | (14.4 | )% |  | (215,347 | ) |  | (36.0 | )% |  | (18,621 | ) |  | (4.7 | )% |
| Interest expense | (22,325 | ) |  | (2.4 | )% |  | (1,883 | ) |  | (0.3 | )% |  | (74 | ) |  | — | % |
| Other income (expense), net | 284 |  |  | — | % |  | (4,930 | ) |  | (0.8 | )% |  | 39 |  |  | — | % |
| Loss before income taxes | (155,577 | ) |  | (16.8 | )% |  | (222,160 | ) |  | (37.1 | )% |  | (18,656 | ) |  | (4.7 | )% |
| Provision for income taxes | 9,405 |  |  | 1.0 | % |  | 4,292 |  |  | 0.8 | % |  | 10,590 |  |  | 2.7 | % |
| Net loss | $ | (164,982 | ) |  | (17.8 | )% |  | $ | (226,452 | ) |  | (37.9 | )% |  | $ | (29,246 | ) |  | (7.4 | )% |
| Number of employees at period end | 2,637 |  |  |  |  | 1,722 |  |  |  |  | 1,147 |  |  |  |

[0001327567-15-000027:mdna:42]
Revenue

[0001327567-15-000027:mdna:43]
We derive revenue from sales of our products and services. Revenue is recognized when persuasive evidence of an arrangement exists, delivery has occurred, the fee is fixed or determinable, and collectability is reasonably assured.

[0001327567-15-000027:mdna:44]
Our total revenue is comprised of the following:

[0001327567-15-000027:mdna:45]
| • | Product Revenue. Product revenue is derived primarily from sales of our appliances. Product revenue also includes revenue derived from software licenses of Panorama, GlobalProtect, and the VM-Series. We recognize product revenue at the time of shipment, provided that all other revenue recognition criteria have been met. As a percentage of total revenue, we expect our product revenue to vary from quarter to quarter based on seasonal and cyclical factors. |

[0001327567-15-000027:mdna:46]
| • | Services Revenue. Services revenue is derived primarily from sales of our subscriptions and support and maintenance. Our contractual subscription and support and maintenance terms are typically one year, although we also offer three to five year terms. We recognize revenue from subscriptions and support and maintenance over the contractual service period. As a percentage of total revenue, we expect our services revenue to vary from quarter to quarter and increase over the long term as we introduce new subscriptions, renew existing services contracts, and expand our installed end-customer base. |

[0001327567-15-000027:mdna:47]
- 42 -

[0001327567-15-000027:mdna:48]
|  | Year Ended July 31, |  |  |  | Year Ended July 31, |  |  |
|  | 2015 |  | 2014 |  | Change |  | 2014 |  | 2013 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in thousands) |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 492,658 |  |  | $ | 340,143 |  |  | $ | 152,515 |  |  | 44.8 | % |  | $ | 340,143 |  |  | $ | 243,707 |  |  | $ | 96,436 |  |  | 39.6 | % |
| Services |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Subscription | 212,676 |  |  | 123,236 |  |  | 89,440 |  |  | 72.6 | % |  | 123,236 |  |  | 71,203 |  |  | 52,033 |  |  | 73.1 | % |
| Support and maintenance | 222,718 |  |  | 134,800 |  |  | 87,918 |  |  | 65.2 | % |  | 134,800 |  |  | 81,197 |  |  | 53,603 |  |  | 66.0 | % |
| Total services | 435,394 |  |  | 258,036 |  |  | 177,358 |  |  | 68.7 | % |  | 258,036 |  |  | 152,400 |  |  | 105,636 |  |  | 69.3 | % |
| Total revenue | $ | 928,052 |  |  | $ | 598,179 |  |  | $ | 329,873 |  |  | 55.1 | % |  | $ | 598,179 |  |  | $ | 396,107 |  |  | $ | 202,072 |  |  | 51.0 | % |
| Revenue by geographic theater: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 639,328 |  |  | $ | 396,626 |  |  | $ | 242,702 |  |  | 61.2 | % |  | $ | 396,626 |  |  | $ | 247,616 |  |  | $ | 149,010 |  |  | 60.2 | % |
| EMEA | 178,719 |  |  | 126,915 |  |  | 51,804 |  |  | 40.8 | % |  | 126,915 |  |  | 91,496 |  |  | 35,419 |  |  | 38.7 | % |
| APAC | 110,005 |  |  | 74,638 |  |  | 35,367 |  |  | 47.4 | % |  | 74,638 |  |  | 56,995 |  |  | 17,643 |  |  | 31.0 | % |
| Total revenue | $ | 928,052 |  |  | $ | 598,179 |  |  | $ | 329,873 |  |  | 55.1 | % |  | $ | 598,179 |  |  | $ | 396,107 |  |  | $ | 202,072 |  |  | 51.0 | % |

[0001327567-15-000027:mdna:49]
Product revenue increased $152.5 million, or 44.8%, for fiscal 2015 compared to fiscal 2014 and increased $96.4 million, or 39.6%, for fiscal 2014 compared to fiscal 2013. The increases in both periods were driven by increased demand for our higher end appliances. The impact of changes in pricing on our product revenue was insignificant.

[0001327567-15-000027:mdna:50]
Services revenue increased $177.4 million, or 68.7%, for fiscal 2015 compared to fiscal 2014 and increased $105.6 million, or 69.3%, for fiscal 2014 compared to fiscal 2013. The increases in both periods were due to increased sales to new and existing end-customers. The relative increases in subscription revenue and support and maintenance revenue will fluctuate over time, depending on the mix of services revenue and the introduction of new subscription offerings. The impact of changes in pricing on our services revenue was insignificant.

[0001327567-15-000027:mdna:51]
With respect to geographic theaters, the Americas contributed the largest portion of the year over year increases in revenue for both fiscal 2015 and fiscal 2014 due to its larger and more established sales force compared to our other theaters. Revenue from both EMEA and APAC increased year over year for both fiscal 2015 and fiscal 2014 due to our investment in increasing the size of our sales force and number of channel partners in these theaters.

[0001327567-15-000027:mdna:52]
Cost of Revenue

[0001327567-15-000027:mdna:53]
Our cost of revenue consists of cost of product revenue and cost of services revenue. Our cost of revenue includes costs paid to our third-party contract manufacturer and personnel costs, which consist of salaries, benefits, bonuses, and share-based compensation associated with our operations, global customer support, and technical operations organizations. Our cost of revenue also includes allocated costs, which consist of certain facilities, depreciation, benefits, recruiting, and information technology costs that we allocate based on headcount, as well as amortization of intellectual property licenses and intangible assets.

[0001327567-15-000027:mdna:54]
| • | Cost of Product Revenue. Cost of product revenue primarily includes costs paid to our third-party contract manufacturer. Our cost of product revenue also includes amortization of intellectual property licenses, product testing costs, allocated costs, warranty costs, shipping costs, and personnel costs associated with logistics and quality control. We expect our cost of product revenue to increase as our product revenue increases. |

[0001327567-15-000027:mdna:55]
| • | Cost of Services Revenue. Cost of services revenue includes personnel costs for our global customer support and technical operations organizations, amortization of acquired intangible assets, allocated costs, and URL filtering database service fees. We expect our cost of services revenue to increase as our installed end-customer base grows. |

[0001327567-15-000027:mdna:56]
- 43 -

[0001327567-15-000027:mdna:57]
|  | Year Ended July 31, |  |  |  | Year Ended July 31, |  |  |
|  | 2015 |  | 2014 |  | Change |  | 2014 |  | 2013 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in thousands) |
| Cost of revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 131,094 |  |  | $ | 85,503 |  |  | $ | 45,591 |  |  | 53.3 | % |  | $ | 85,503 |  |  | $ | 63,412 |  |  | $ | 22,091 |  |  | 34.8 | % |
| Services | 120,405 |  |  | 74,125 |  |  | 46,280 |  |  | 62.4 | % |  | 74,125 |  |  | 46,344 |  |  | 27,781 |  |  | 59.9 | % |
| Total cost of revenue | $ | 251,499 |  |  | $ | 159,628 |  |  | $ | 91,871 |  |  | 57.6 | % |  | $ | 159,628 |  |  | $ | 109,756 |  |  | $ | 49,872 |  |  | 45.4 | % |
| Includes share-based compensation of: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 3,858 |  |  | $ | 1,636 |  |  | $ | 2,222 |  |  | 135.8 | % |  | $ | 1,636 |  |  | $ | 765 |  |  | $ | 871 |  |  | 113.9 | % |
| Services | 20,425 |  |  | 9,434 |  |  | 10,991 |  |  | 116.5 | % |  | 9,434 |  |  | 3,586 |  |  | 5,848 |  |  | 163.1 | % |
| Total share-based compensation included in cost of revenue | $ | 24,283 |  |  | $ | 11,070 |  |  | $ | 13,213 |  |  | 119.4 | % |  | $ | 11,070 |  |  | $ | 4,351 |  |  | $ | 6,719 |  |  | 154.4 | % |

[0001327567-15-000027:mdna:58]
Product cost increased $45.6 million, or 53.3%, for fiscal 2015 compared to fiscal 2014 due to an increase in product unit volume, as well as amortization of intellectual property licenses of $10.2 million.

[0001327567-15-000027:mdna:59]
Product cost increased $22.1 million, or 34.8%, for fiscal 2014 compared to fiscal 2013 due to an increase in product unit volume. Product cost for fiscal 2014 also includes amortization of intellectual property licenses of $2.0 million.

[0001327567-15-000027:mdna:60]
Services cost increased $46.3 million, or 62.4%, for fiscal 2015 compared to fiscal 2014 due to increases in personnel costs of $25.8 million related to increasing our headcount, third-party professional services costs of $4.8 million to expand our customer service capabilities to support our growing installed end-customer base, amortization of acquired intangible assets of $4.5 million, and allocated costs of $4.2 million.

[0001327567-15-000027:mdna:61]
Services cost increased $27.8 million, or 59.9%, for fiscal 2014 compared to fiscal 2013 due to an increase in personnel costs of $14.8 million related to increasing our headcount, allocated costs of $5.5 million, professional services costs of $2.1 million, amortization of acquired intangible assets of $1.6 million, and other costs incurred to expand our customer service capabilities to support our growing installed end-customer base.

[0001327567-15-000027:mdna:62]
Gross Margin

[0001327567-15-000027:mdna:63]
Gross margin, or gross profit as a percentage of revenue, has been and will continue to be affected by a variety of factors, including the average sales price of our products, manufacturing costs, the mix of products sold, and the mix of revenue between products and services. For sales of our products, our higher throughput firewall products generally have higher gross margins than our lower throughput firewall products within each product series. For sales of our services, our subscriptions typically have higher gross margins than our support and maintenance. We expect our gross margins to fluctuate over time depending on the factors described above.

[0001327567-15-000027:mdna:64]
|  | Year Ended July 31, |
|  | 2015 |  | 2014 |  | 2013 |
|  | Amount |  | GrossMargin |  | Amount |  | GrossMargin |  | Amount |  | GrossMargin |
|  | (dollars in thousands) |
| Gross profit: |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 361,564 |  |  | 73.4 | % |  | $ | 254,640 |  |  | 74.9 | % |  | $ | 180,295 |  |  | 74.0 | % |
| Services | 314,989 |  |  | 72.3 | % |  | 183,911 |  |  | 71.3 | % |  | 106,056 |  |  | 69.6 | % |
| Total gross profit | $ | 676,553 |  |  | 72.9 | % |  | $ | 438,551 |  |  | 73.3 | % |  | $ | 286,351 |  |  | 72.3 | % |

[0001327567-15-000027:mdna:65]
Gross margin decreased 40 basis points for fiscal 2015 compared to fiscal 2014. The decrease of 150 basis points in product margin was due to increased amortization of intellectual property licenses. The increase of 100 basis points in services margin was due to contributions from our higher margin subscription services, partially offset by an 80 basis points decrease due to amortization of purchased intangible assets.

[0001327567-15-000027:mdna:66]
- 44 -

[0001327567-15-000027:mdna:67]
Gross margin increased 100 basis points for fiscal 2014 compared to fiscal 2013. The increase of 90 basis points in product margin was due to continued focus on material cost reductions, partially offset by amortization of intellectual property licenses of $2.0 million. The increase of 170 basis points in services margin was due to contributions from our higher margin subscription services.

[0001327567-15-000027:mdna:68]
Operating Expenses

[0001327567-15-000027:mdna:69]
Our operating expenses consist of research and development, sales and marketing, general and administrative, and legal settlement expense. Personnel costs are the most significant component of operating expenses and consist of salaries, benefits, bonuses, share-based compensation, and with regard to sales and marketing expense, sales commissions. Our operating expenses also include allocated costs, which consist of certain facilities, depreciation, benefits, recruiting, and information technology costs that we allocate based on headcount. We expect operating expenses to increase in absolute dollars and decrease over the long term as a percentage of revenue as we continue to scale our business. As of July 31, 2015, we expect to recognize approximately $557.0 million of share-based compensation expense over a weighted-average period of approximately three years, excluding additional share-based compensation expense related to any future grants of share-based awards. Share-based compensation expense, net of forfeitures, is recognized on a straight-line basis over the requisite service periods of the awards.

[0001327567-15-000027:mdna:70]
| • | Research and Development. Research and development expense consists primarily of personnel costs. Research and development expense also includes prototype related expenses and allocated costs. We expect research and development expense to increase in absolute dollars as we continue to invest in our future products and services, although our research and development expense may fluctuate as a percentage of total revenue. |

[0001327567-15-000027:mdna:71]
| • | Sales and Marketing. Sales and marketing expense consists primarily of personnel costs, including commission costs. We expense commission costs as incurred. Sales and marketing expense also includes costs for market development programs, promotional and other marketing costs, travel costs, professional services, and allocated costs. We continue to increase the size of our sales force and have also substantially grown our sales presence internationally. We expect sales and marketing expense to continue to increase in absolute dollars as we increase the size of our sales and marketing organizations to increase touch points with end-customers and to expand our international presence, although our sales and marketing expense may fluctuate as a percentage of total revenue. |

[0001327567-15-000027:mdna:72]
| • | General and Administrative. General and administrative expense consists of personnel costs for our executive, finance, human resources, legal, and information technology organizations, professional services, and certain non-recurring general expenses. Professional services consist primarily of legal, auditing, accounting, and other consulting costs. We expect general and administrative expense to increase in absolute dollars due to additional costs associated with accounting, compliance, insurance, and investor relations, although our general and administrative expense may fluctuate as a percentage of total revenue. |

[0001327567-15-000027:mdna:73]
| • | Legal Settlement. Legal settlement expense consists of charges related to the Settlement Agreement with Juniper and the Mutual Covenant Not to Sue and Release Agreement with Fortinet. Refer to the discussion under Note 9. Legal Settlement of Notes to Consolidated Financial Statements in Part II, Item 8 of this Annual Report on Form 10-K for information related to these matters. |

[0001327567-15-000027:mdna:74]
- 45 -

[0001327567-15-000027:mdna:75]
|  | Year Ended July 31, |  |  |  | Year Ended July 31, |  |  |
|  | 2015 |  | 2014 |  | Change |  | 2014 |  | 2013 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in thousands) |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | $ | 185,828 |  |  | $ | 104,813 |  |  | $ | 81,015 |  |  | 77.3 | % |  | $ | 104,813 |  |  | $ | 62,482 |  |  | $ | 42,331 |  |  | 67.7 | % |
| Sales and marketing | 522,696 |  |  | 334,763 |  |  | 187,933 |  |  | 56.1 | % |  | 334,763 |  |  | 199,771 |  |  | 134,992 |  |  | 67.6 | % |
| General and administrative | 101,565 |  |  | 73,149 |  |  | 28,416 |  |  | 38.8 | % |  | 73,149 |  |  | 42,719 |  |  | 30,430 |  |  | 71.2 | % |
| Legal settlement | — |  |  | 141,173 |  |  | (141,173 | ) |  | (100.0 | )% |  | 141,173 |  |  | — |  |  | 141,173 |  |  | NM |  |
| Total operating expenses | $ | 810,089 |  |  | $ | 653,898 |  |  | $ | 156,191 |  |  | 23.9 | % |  | $ | 653,898 |  |  | $ | 304,972 |  |  | $ | 348,926 |  |  | 114.4 | % |
| Includes share-based compensation of: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | $ | 74,837 |  |  | $ | 29,524 |  |  | $ | 45,313 |  |  | 153.5 | % |  | $ | 29,524 |  |  | $ | 9,931 |  |  | $ | 19,593 |  |  | 197.3 | % |
| Sales and marketing | 84,113 |  |  | 42,647 |  |  | 41,466 |  |  | 97.2 | % |  | 42,647 |  |  | 20,493 |  |  | 22,154 |  |  | 108.1 | % |
| General and administrative | 38,198 |  |  | 16,668 |  |  | 21,530 |  |  | 129.2 | % |  | 16,668 |  |  | 9,101 |  |  | 7,567 |  |  | 83.1 | % |
| Total share-based compensation included in operating expenses | $ | 197,148 |  |  | $ | 88,839 |  |  | $ | 108,309 |  |  | 121.9 | % |  | $ | 88,839 |  |  | $ | 39,525 |  |  | $ | 49,314 |  |  | 124.8 | % |

[0001327567-15-000027:mdna:76]
Research and development expense increased $81.0 million, or 77.3%, for fiscal 2015 compared to fiscal 2014 due to an increase in personnel costs of $73.7 million largely due to an increase in headcount and an increase in allocated costs of $5.3 million.

[0001327567-15-000027:mdna:77]
Research and development expense increased $42.3 million, or 67.7%, for fiscal 2014 compared to fiscal 2013 due to an increase in personnel costs of $31.4 million largely due to an increase in headcount, an increase in allocated costs of $6.4 million, and an increase in development costs of $2.5 million to support continued investment in our future product and service offerings.

[0001327567-15-000027:mdna:78]
Sales and marketing expense increased $187.9 million, or 56.1%, for fiscal 2015 compared to fiscal 2014 due to an increase in personnel costs of $140.4 million largely due to an increase in headcount, an increase in allocated costs of $12.3 million, an increase in demand generation activities, trade shows, and other marketing activities of $11.8 million, and an increase in travel and entertainment costs of $11.8 million.

[0001327567-15-000027:mdna:79]
Sales and marketing expense increased $135.0 million, or 67.6%, for fiscal 2014 compared to fiscal 2013 due to an increase in personnel costs of $94.6 million largely due to an increase in headcount, an increase in allocated costs of $13.9 million, an increase in travel and entertainment costs of $8.9 million, an increase in professional services costs of $7.6 million, and an increase in demand generation activities, trade shows, and other marketing activities of $6.1 million.

[0001327567-15-000027:mdna:80]
General and administrative expense increased $28.4 million, or 38.8%, for fiscal 2015 compared to fiscal 2014 due to an increase in personnel costs of $31.4 million largely due to an increase in headcount and an increase in professional services costs of $7.5 million. In addition, in fiscal 2014, we recognized expenses related to the intellectual property litigation with Juniper of $11.3 million and expenses related to our acquisitions of Cyvera and Morta of $4.4 million.

[0001327567-15-000027:mdna:81]
General and administrative expense increased $30.4 million, or 71.2%, for fiscal 2014 compared to fiscal 2013 due to an increase in professional services costs of $12.5 million, including expenses related to the intellectual property litigation with Juniper of $7.7 million and expenses related to our acquisitions of Cyvera and Morta of $4.4 million, an increase in personnel costs of $12.3 million, largely due to an increase in headcount, and an increase in allocated costs of $2.4 million.

[0001327567-15-000027:mdna:82]
We incurred legal settlement expenses of $121.2 million and $20.0 million in fiscal 2014 related to the Settlement Agreement with Juniper and the Mutual Covenant Not to Sue and Release Agreement with Fortinet, respectively.

[0001327567-15-000027:mdna:83]
- 46 -

[0001327567-15-000027:mdna:84]
Interest Expense

[0001327567-15-000027:mdna:85]
Interest expense primarily consists of the amortization of the debt discount and debt issuance costs related to the Notes issued on June 30, 2014. This interest expense is non-cash and will range from $23.4 million to $25.7 million per year through fiscal 2019.

[0001327567-15-000027:mdna:86]
|  | Year Ended July 31, |  |  |  | Year Ended July 31, |  |  |
|  | 2015 |  | 2014 |  | Change |  | 2014 |  | 2013 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in thousands) |
| Interest expense | $ | 22,325 |  |  | $ | 1,883 |  |  | $ | 20,442 |  |  | NM |  | $ | 1,883 |  |  | $ | 74 |  |  | $ | 1,809 |  |  | NM |

[0001327567-15-000027:mdna:87]
Interest expense increased $20.4 million for fiscal 2015 compared to fiscal 2014 and increased $1.8 million for fiscal 2014 compared to fiscal 2013 due to the amortization of the debt discount and debt issuance costs related to the Notes.

[0001327567-15-000027:mdna:88]
Other Income (Expense), Net

[0001327567-15-000027:mdna:89]
Other income (expense), net includes interest income earned on our cash, cash equivalents, and investments, foreign currency remeasurement gains and losses, and foreign currency transaction gains and losses.

[0001327567-15-000027:mdna:90]
|  | Year Ended July 31, |  |  |  | Year Ended July 31, |  |  |
|  | 2015 |  | 2014 |  | Change |  | 2014 |  | 2013 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in thousands) |
| Other income (expense), net | $ | 284 |  |  | $ | (4,930 | ) |  | $ | 5,214 |  |  | NM |  | $ | (4,930 | ) |  | $ | 39 |  |  | $ | (4,969 | ) |  | NM |

[0001327567-15-000027:mdna:91]
In fiscal 2014, we recorded an expense of $5.9 million in other income (expense), net to record the change in fair value of the warrant issued to Juniper in connection with the Settlement Agreement. The warrant was classified as a liability on our consolidated balance sheets and remeasured to fair value from June 3, 2014, the issuance date of the warrant, through July 1, 2014, the date the warrant was exercised. In addition, for fiscal 2015 compared to fiscal 2014, our interest income and our foreign currency remeasurement losses increased by $2.9 million and $3.3 million, respectively.

[0001327567-15-000027:mdna:92]
Provision for Income Taxes

[0001327567-15-000027:mdna:93]
Provision for income taxes consists primarily of income taxes in foreign jurisdictions in which we conduct business, withholding taxes, federal and state income taxes in the United States, and amortization of our deferred tax charges. We maintain a full valuation allowance for domestic deferred tax assets, including net operating loss carryforwards and tax credits.

[0001327567-15-000027:mdna:94]
In fiscal 2015, we recorded deferred tax charges of $36.8 million. The current portion of the deferred tax charges is included in prepaid expenses and other current assets and the remainder in other assets in our consolidated balance sheets. The deferred tax charges are being amortized on a straight-line basis over approximately seven years as a component of provision for income taxes.

[0001327567-15-000027:mdna:95]
|  | Year Ended July 31, |  |  |  |  |  | Year Ended July 31, |  |  |  |  |
|  | 2015 |  | 2014 |  | Change |  | 2014 |  | 2013 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in thousands) |
| Provision for income taxes | $ | 9,405 |  |  | $ | 4,292 |  |  | $ | 5,113 |  |  | 119.1 | % |  | $ | 4,292 |  |  | $ | 10,590 |  |  | $ | (6,298 | ) |  | (59.5 | )% |
| Effective tax rate | (6.0 | )% |  | (1.9 | )% |  |  |  |  |  | (1.9 | )% |  | (56.8 | )% |  |  |  |  |

[0001327567-15-000027:mdna:96]
We recorded an income tax provision for fiscal 2015 due to federal, state, and foreign income taxes, foreign withholding taxes, and amortization of our deferred tax charges. The provision for income taxes increased $5.1 million for fiscal 2015 compared to fiscal 2014 due to amortization of our deferred tax charges and a shift in geographical mix of income, partially offset by the tax benefit from a partial release of the valuation allowance in connection with the acquisition of CirroSecure.

[0001327567-15-000027:mdna:97]
We recorded an income tax provision for fiscal 2014 due to foreign income taxes and foreign withholding taxes. The provision for income taxes decreased $6.3 million for fiscal 2014 compared to fiscal 2013 due to decreased U.S. taxable income, primarily attributable to the Settlement Agreement with Juniper and the Mutual Covenant Not to Sue and Release Agreement with Fortinet.

[0001327567-15-000027:mdna:98]
- 47 -

[0001327567-15-000027:mdna:99]
Liquidity and Capital Resources

[0001327567-15-000027:mdna:100]
|  | July 31, |
|  | 2015 |  | 2014 |
|  | (in thousands) |
| Working capital (1) | $ | 41,803 |  |  | $ | 610,155 |  |
| Cash, cash equivalents, and investments: |  |  |  |
| Cash and cash equivalents | $ | 375,814 |  |  | $ | 653,812 |  |
| Investments | 952,006 |  |  | 320,570 |  |
| Total cash, cash equivalents, and investments | $ | 1,327,820 |  |  | $ | 974,382 |  |

[0001327567-15-000027:mdna:101]
______________

[0001327567-15-000027:mdna:102]
| (1) | As of July 31, 2015, the net carrying amount of the Notes and related debt issuance costs were classified as current liabilities and current assets, respectively, in our consolidated balance sheets. Refer to Note 7. Convertible Senior Notes of Notes to Consolidated Financial Statements included in Part II, Item 8 of this Annual Report on Form 10-K for more information. |

[0001327567-15-000027:mdna:103]
At July 31, 2015, our cash and cash equivalents and investments of $1.3 billion were held for working capital purposes, of which approximately $84.0 million was held outside of the United States. We do not provide for federal income taxes on the undistributed earnings of our foreign subsidiaries, all of which we expect to reinvest outside of the United States indefinitely. However, if these funds were needed for our domestic operations, we would be required to accrue and pay U.S. taxes on undistributed earnings of foreign subsidiaries. There are no other restrictions on the use of these funds. If we were to repatriate these earnings to the United States, any associated income tax liability would be insignificant.

[0001327567-15-000027:mdna:104]
In June 2014, we issued the Notes, which mature on July 1, 2019, with an aggregate principal amount of $575.0 million. Prior to January 1, 2019, holders may surrender their Notes for early conversion under certain circumstances. Upon conversion of the Notes, we will pay cash up to the aggregate principal amount of the Notes to be converted, and we may choose to pay or deliver, as the case may be, cash, shares of our common stock or a combination of cash and shares of our common stock with respect to the remainder of our conversion obligation in excess of the aggregate principal amount of the Notes being converted.

[0001327567-15-000027:mdna:105]
During the fiscal quarter ended July 31, 2015, the last reported sale price of our common stock was greater than or equal to 130% of the conversion price of the Notes for at least 20 of the last 30 consecutive trading days of such quarter. As a result, holders may convert their Notes at any time during the fiscal quarter ending October 31, 2015. Refer to Note 7. Convertible Senior Notes of Notes to Consolidated Financial Statements included in Part II, Item 8 of this Annual Report on Form 10-K for information on the Notes.

[0001327567-15-000027:mdna:106]
The following table summarizes our cash flows for the years ended July 31, 2015, 2014, and 2013.

[0001327567-15-000027:mdna:107]
|  | Year Ended July 31, |
| 2015 |  | 2014 |  | 2013 |
|  | (in thousands) |
| Cash provided by operating activities | $ | 350,304 |  |  | $ | 88,406 |  |  | $ | 114,519 |  |
| Cash used in investing activities | (679,006 | ) |  | (320,348 | ) |  | (151,565 | ) |
| Cash provided by financing activities | 50,704 |  |  | 575,140 |  |  | 25,018 |  |
| Net increase (decrease) in cash and cash equivalents | $ | (277,998 | ) |  | $ | 343,198 |  |  | $ | (12,028 | ) |

[0001327567-15-000027:mdna:108]
We believe that our cash flow from operations with existing cash and cash equivalents will be sufficient to meet our anticipated cash needs for the foreseeable future. Our future capital requirements will depend on many factors including our growth rate, the timing and extent of spending to support development efforts, the expansion of sales and marketing activities, the introduction of new and enhanced products and services offerings, the costs to acquire or invest in complementary businesses and technologies, the costs to ensure access to adequate manufacturing capacity, and the continuing market acceptance of our products. In addition, from time to time we may incur additional tax liability in connection with certain tax structuring decisions.

[0001327567-15-000027:mdna:109]
We may also choose to seek additional equity or debt financing. In the event that additional financing is required from outside sources, we may not be able to raise it on terms acceptable to us or at all. If we are unable to raise additional capital when desired, our business, operating results, and financial condition may be adversely affected.

[0001327567-15-000027:mdna:110]
- 48 -

[0001327567-15-000027:mdna:111]
Operating Activities

[0001327567-15-000027:mdna:112]
Our operating activities have consisted of net loss adjusted for certain non-cash items and changes in assets and liabilities.

[0001327567-15-000027:mdna:113]
Cash provided by operating activities in fiscal 2015 was $350.3 million, an increase of $261.9 million compared to fiscal 2014. The increase was due to growth of our business and changes in our assets and liabilities during fiscal 2015. Additionally, in fiscal 2014, we made a total of $95.0 million in payments related to legal settlements. Changes in assets and liabilities for fiscal 2015 compared to fiscal 2014 include an increase in sales of subscriptions and support and maintenance contracts to new and existing customers as reflected by an increase in deferred revenue. In addition, during fiscal 2015, we made a tax payment of $12.8 million in connection with an intercompany transfer of intellectual property.

[0001327567-15-000027:mdna:114]
Cash provided by operating activities in fiscal 2014 was $88.4 million, a decrease of $26.1 million compared to fiscal 2013, due to payments of $75.0 million and $20.0 million in fiscal 2014 for the legal settlement with Juniper and the Mutual Covenant Not to Sue and Release Agreement with Fortinet, respectively. The decrease was partially offset by an increase in sales of subscriptions and support and maintenance contracts to new and existing customers as reflected by an increase in deferred revenue.

[0001327567-15-000027:mdna:115]
Investing Activities

[0001327567-15-000027:mdna:116]
Our investing activities have consisted of capital expenditures, net investment purchases, sales, and maturities, and business acquisitions. We expect to continue such activities as our business grows.

[0001327567-15-000027:mdna:117]
Cash used in investing activities during fiscal 2015 was $679.0 million, an increase of $358.7 million compared to fiscal 2014. The increase was due to higher net purchases of available-for-sale investments in fiscal 2015, partially offset by higher payments made in fiscal 2014 related to our acquisitions.

[0001327567-15-000027:mdna:118]
Cash used in investing activities during fiscal 2014 was $320.3 million, an increase of $168.8 million compared to fiscal 2013. The increase was due to net cash payments of $85.7 million related to our acquisitions in fiscal 2014, an increase of $69.4 million in net purchases of available-for-sale investments, and an increase of $13.7 million in purchases of property, equipment, and other assets.

[0001327567-15-000027:mdna:119]
Financing Activities

[0001327567-15-000027:mdna:120]
Our financing activities have consisted of proceeds from the issuance of the Notes and proceeds from sales of shares through employee equity incentive plans.

[0001327567-15-000027:mdna:121]
Cash provided by financing activities during fiscal 2015 was $50.7 million, a decrease of $524.4 million compared to fiscal 2014. The decrease was due to net proceeds from the issuance of the Notes of $527.7 million in fiscal 2014.

[0001327567-15-000027:mdna:122]
Cash provided by financing activities during fiscal 2014 was $575.1 million, an increase of $550.1 million compared to fiscal 2013. The increase was primarily due to net proceeds from the issuance of the Notes of $527.7 million. The remaining increase was due to higher proceeds from the sale of shares through employee equity incentive plans during fiscal 2014 and the last payments of our initial public offering costs in fiscal 2013.

[0001327567-15-000027:mdna:123]
Contractual Obligations and Commitments

[0001327567-15-000027:mdna:124]
The following summarizes our contractual obligations and commitments as of July 31, 2015:

[0001327567-15-000027:mdna:125]
|  | Payments Due by Period |
|  | Total |  | Less Than 1 Year |  | 1 - 3 Years |  | 3- 5 Years |  | More Than 5 Years |
|  |  |  | (in thousands) |  |  |
| 0.0% Convertible Senior Notes due 2019 (1) | $ | 575,000 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 575,000 |  |
| Operating lease obligations (2) (3) | 409,156 |  |  | 20,821 |  |  | 51,507 |  |  | 83,626 |  |  | 253,202 |  |
| Purchase obligations (4) | 42,805 |  |  | 42,805 |  |  | — |  |  | — |  |  | — |  |
| Total (5) | $ | 1,026,961 |  |  | $ | 63,626 |  |  | $ | 51,507 |  |  | $ | 83,626 |  |  | $ | 828,202 |  |

[0001327567-15-000027:mdna:126]
______________

[0001327567-15-000027:mdna:127]
| (1) | As of July 31, 2015, holders may convert their Notes at any time during the fiscal quarter ending October 31, 2015. Refer to Note 7. Convertible Senior Notes of Notes to Consolidated Financial Statements included in Part II, Item 8 of this Annual Report on Form 10-K for more information. |

[0001327567-15-000027:mdna:128]
- 49 -

[0001327567-15-000027:mdna:129]
| (2) | Consists of contractual obligations from our non-cancelable operating leases. In August 2015, we executed an expansion notice under one of our existing lease agreements in Santa Clara, California. As the related lease has not yet been executed, future non-cancelable minimum rental payments related to the expansion notice are not included in the table above. Refer to Note 8. Commitments and Contingencies of Notes to Consolidated Financial Statements included in Part II, Item 8 of this Annual Report on Form 10-K for more information. |

[0001327567-15-000027:mdna:130]
| (3) | Excludes contractual sublease proceeds of $8.2 million, of which $3.0 million will be received in less than one year and $5.2 million will be received in one to three years. |

[0001327567-15-000027:mdna:131]
| (4) | Consists of minimum purchase commitments of products and components with our independent contract manufacturer and original design manufacturers. Obligations under contracts that we can cancel without a significant penalty are not included in the table above. |

[0001327567-15-000027:mdna:132]
| (5) | No amounts related to income taxes are included. As of July 31, 2015, we had approximately $40.6 million of tax liabilities recorded related to uncertainty in income tax positions. |

[0001327567-15-000027:mdna:133]
Off-Balance Sheet Arrangements

[0001327567-15-000027:mdna:134]
Through July 31, 2015, we did not have any relationships with unconsolidated organizations or financial partnerships, such as structured finance or special purpose entities, that would have been established for the purpose of facilitating off-balance sheet arrangements or other contractually narrow or limited purposes.

[0001327567-15-000027:mdna:135]
Critical Accounting Policies and Estimates

[0001327567-15-000027:mdna:136]
Our consolidated financial statements have been prepared in accordance with U.S. GAAP. The preparation of these consolidated financial statements requires us to make estimates and assumptions that affect the reported amounts of assets, liabilities, revenue, expenses, and related disclosures. We base our estimates on historical experience and on various other assumptions that we believe are reasonable under the circumstances. We evaluate our estimates and assumptions on an ongoing basis. Actual results may differ from these estimates. To the extent that there are material differences between these estimates and our actual results, our future financial statements will be affected.

[0001327567-15-000027:mdna:137]
The critical accounting policies requiring estimates, assumptions, and judgments that we believe have the most significant impact on our consolidated financial statements are described below.

[0001327567-15-000027:mdna:138]
Revenue Recognition

[0001327567-15-000027:mdna:139]
We recognize revenue when persuasive evidence of an arrangement exists, delivery has occurred, the fee is fixed or determinable, and collectability is reasonably assured. Most of our arrangements, other than renewals of subscriptions and support and maintenance, are multiple-element arrangements with a combination of hardware, software, subscriptions, support and maintenance, and other services. For multiple-element arrangements, we allocate revenue to each unit of accounting based on an estimated selling price at the arrangement inception. The estimated selling price for each element is based upon the following hierarchy:

[0001327567-15-000027:mdna:140]
| • | Vendor-specific objective evidence (VSOE) of selling price, if available, |

[0001327567-15-000027:mdna:141]
| • | Third-party evidence (TPE) of selling price, if VSOE of selling price is not available, or |

[0001327567-15-000027:mdna:142]
| • | Best estimate of selling price (BESP), if neither VSOE of selling price nor TPE of selling price are available. |

[0001327567-15-000027:mdna:143]
We establish VSOE of selling price using the prices charged for a deliverable when sold separately. We establish TPE of selling price by evaluating similar and interchangeable competitor products or services in standalone arrangements with similarly situated partners. We establish BESP primarily based on historical transaction pricing, whereby historical transactions are segregated based on our pricing model and our go-to-market strategy, which include factors such as type of sales channel (reseller, distributor, or end-customer), the geographies in which our products and services were sold (domestic or international), and offering type (products or services). To further support the best estimate of selling price as determined by the historical transaction pricing or when such information is unavailable, such as when there are limited sales of a new product or service, we consider the same factors we have established through our pricing model and go-to-market strategy. The determination of BESP is made through consultation with and approval by our management. In determining BESP, we rely on certain assumptions and apply significant judgment. As our business offerings evolve over time, we may be required to modify our estimated selling prices in subsequent periods, and the timing of our revenue recognition could be affected.

[0001327567-15-000027:mdna:144]
Share-Based Compensation

[0001327567-15-000027:mdna:145]
Compensation expense related to share-based transactions is measured and recognized in the financial statements based on fair value estimated on the grant date. The fair value of restricted stock units (RSUs) is based on the closing market price of our

[0001327567-15-000027:mdna:146]
- 50 -

[0001327567-15-000027:mdna:147]
common stock on the date of grant. The fair value of stock options and shares sold through our employee stock purchase plan (ESPP) are estimated on the grant date using the Black Scholes option pricing model, which requires the use of subjective assumptions, including the expected term of the award and the expected volatility of the price of our common stock.

[0001327567-15-000027:mdna:148]
We recognize share-based compensation expense on a straight-line basis over the requisite service periods of the awards, net of estimated forfeitures. Our estimated forfeiture rate is based on an analysis of our actual historical forfeitures. A change in our estimated forfeiture rate could have a significant impact on our share-based compensation expense as the cumulative effect of adjusting the rate is recognized in the period the forfeiture estimate is changed.

[0001327567-15-000027:mdna:149]
We will continue to use judgment in evaluating the assumptions related to our share-based compensation expense on a prospective basis. As we continue to accumulate additional data, we may have refinements to our estimates, which could materially impact our future share-based compensation expense.

[0001327567-15-000027:mdna:150]
Income Taxes

[0001327567-15-000027:mdna:151]
We account for income taxes using the asset and liability method, which requires the recognition of deferred tax assets and liabilities for the expected future tax consequences of events that have been recognized in our financial statements or tax returns. In addition, deferred tax assets are recorded for the future benefit of utilizing net operating losses and research and development credit carryforwards. Valuation allowances are provided when necessary to reduce deferred tax assets to the amount expected to be realized.

[0001327567-15-000027:mdna:152]
Significant judgment is required in determining any valuation allowance recorded against deferred tax assets. In assessing the need for a valuation allowance, we consider all available evidence, including past operating results, estimates of future taxable income, and the feasibility of tax planning strategies. In the event that we change our determination as to the amount of deferred tax assets that can be realized, we will adjust our valuation allowance with a corresponding impact to the provision for income taxes in the period in which such determination is made.

[0001327567-15-000027:mdna:153]
We apply the authoritative accounting guidance prescribing a threshold and measurement attribute for the financial recognition and measurement of a tax position taken or expected to be taken in a tax return. We recognize liabilities for uncertain tax positions based on a two-step process. The first step is to evaluate the tax position for recognition by determining if the weight of available evidence indicates that it is more likely than not that the position will be sustained on audit, including resolution of related appeals or litigation processes, if any. The second step requires us to estimate and measure the tax benefit as the largest amount that is more likely than not to be realized upon ultimate settlement.

[0001327567-15-000027:mdna:154]
Significant judgment is also required in evaluating our uncertain tax positions and determining our provision for income taxes. Although we believe our reserves are reasonable, no assurance can be given that the final tax outcome of these matters will not be different from that which is reflected in our historical income tax provisions and accruals. We adjust these reserves in light of changing facts and circumstances, such as the closing of a tax audit or the refinement of an estimate. To the extent that the final tax outcome of these matters is different than the amounts recorded, such differences may impact the provision for income taxes in the period in which such determination is made.

[0001327567-15-000027:mdna:155]
Contract Manufacturer Liabilities

[0001327567-15-000027:mdna:156]
We outsource most of our manufacturing, repair, and supply chain management operations to our independent contract manufacturer, which procures components and assembles our products based on our demand forecasts. These forecasts of future demand are based upon historical trends and analysis from our sales and product management functions as adjusted for overall market conditions. We accrue for costs for manufacturing commitments in excess of our forecasted demand, including costs for excess components or for carrying costs incurred by our contract manufacturer. Actual component usage and product demand may be materially different from our forecast, and could be caused by factors outside of our control, which could have an adverse impact on our results of operations. To date, we have not accrued significant costs associated with this exposure.

[0001327567-15-000027:mdna:157]
Loss Contingencies

[0001327567-15-000027:mdna:158]
We are subject to the possibility of various loss contingencies arising in the ordinary course of business. We accrue for loss contingencies when it is probable that an asset has been impaired or a liability has been incurred and the amount of loss can be reasonably estimated. If we determine that a loss is possible and the range of the loss can be reasonably determined, then we disclose the range of the possible loss. We regularly evaluate current information available to us to determine whether an accrual is required, an accrual should be adjusted or a range of possible loss should be disclosed.

[0001327567-15-000027:mdna:159]
From time to time, we are involved in disputes, litigation, and other legal actions. However, there are many uncertainties associated with any litigation, and these actions or other third-party claims against us may cause us to incur substantial settlement charges, which are inherently difficult to estimate and could adversely affect our results of operations. The actual liability in any

[0001327567-15-000027:mdna:160]
- 51 -

[0001327567-15-000027:mdna:161]
such matters may be materially different from our estimates, which could result in the need to adjust our liability and record additional expenses.

[0001327567-15-000027:mdna:162]
Goodwill, Intangibles, and Other Long-Lived Assets

[0001327567-15-000027:mdna:163]
We make significant estimates, assumptions, and judgments when valuing goodwill and other purchased intangible assets in connection with the initial purchase price allocation of an acquired entity, as well as when evaluating impairment of goodwill and other purchased intangible assets on an ongoing basis. These estimates are based upon a number of factors, including historical experience, market conditions, and information obtained from the management of the acquired company. Critical estimates in valuing certain intangible assets include, but are not limited to, cash flows that an asset is expected to generate in the future, discount rates, the time and expense that would be necessary to recreate the assets, and the profit margin a market participant would receive. The amounts and useful lives assigned to identified intangible assets impacts the amount and timing of future amortization expense.

[0001327567-15-000027:mdna:164]
We evaluate goodwill for impairment on an annual basis in our fourth fiscal quarter or more frequently if we believe impairment indicators exist. We first analyze qualitative factors, which include industry and market considerations, overall financial performance, and other relevant events and factors affecting the reporting unit. If qualitative factors indicate that it is more likely than not that the reporting unit’s fair value is less than its carrying amount, then we will perform the quantitative analysis required under the two-step goodwill impairment test.

[0001327567-15-000027:mdna:165]
Under the two-step goodwill impairment test, we first compare the reporting unit's carrying amount, including goodwill, to the fair value of the reporting unit. The fair value of the reporting unit is estimated using significant judgment based on a combination of the income and the market approaches. If the fair value of the reporting unit does not exceed the carrying amount of the net assets assigned to the reporting unit, then we perform the second step of the impairment test in order to determine the implied fair value of the reporting unit's goodwill. When the carrying amount of a reporting unit's goodwill exceeds its implied fair value, we record an impairment loss equal to the difference. Determining the fair value of a reporting unit is highly judgmental in nature and involves the use of significant estimates and assumptions. These estimates and assumptions include revenue growth rates and operating margins used to calculate projected future cash flows, operating trends, risk-adjusted discount rates, future economic and market conditions, and determination of appropriate market comparables. We base our fair value estimates on assumptions we believe to be reasonable but that are unpredictable and inherently uncertain. Actual future results may differ from those estimates.

[0001327567-15-000027:mdna:166]
We evaluate long-lived assets, such as property, equipment, and purchased intangible assets for impairment whenever events or changes in circumstances indicate that the carrying amount of the assets may not be recoverable. Such events or changes in circumstances include, but are not limited to, a significant decrease in the fair value of the underlying asset or asset group, a significant decrease in the benefits realized from the acquired assets, difficulty and delays in integrating the business, or a significant change in the operations of the acquired assets or use of an asset. A long-lived asset is considered impaired if its carrying amount exceeds the estimated future undiscounted cash flows the asset or asset group is expected to generate. If a long-lived asset is considered to be impaired, the impairment to be recognized is the amount by which the carrying amount of the asset exceeds the fair value of the asset or asset group.

[0001327567-15-000027:mdna:167]
To date, we have not recognized any impairment losses on our goodwill, intangible assets, and long-lived assets.

[0001327567-15-000027:mdna:168]
Recent Accounting Pronouncements

[0001327567-15-000027:mdna:169]
Refer to “Recent Accounting Pronouncements” in Note 1. Description of Business and Summary of Significant Accounting Policies of Notes to Consolidated Financial Statements included in Part II, Item 8 of this Annual Report on Form 10-K.
