# PANW notes — 0001327567-15-000027


## panw:ContractManufacturerLiabilitiesPolicyTextBlockPolicyTextBlock

[0001327567-15-000027:notes:1]
Contract Manufacturer Liabilities

[0001327567-15-000027:notes:2]
We outsource most of our manufacturing, repair, and supply chain management operations to our independent contract manufacturer and payments to it are a significant portion of our product cost of revenues. Although we could be contractually obligated to purchase manufactured products, we generally do not own the manufactured products. Product title transfers from our independent contract manufacturer to us and immediately to our channel partners upon shipment. Our independent contract manufacturer assembles our products using design specifications, quality assurance programs, and standards that we establish and it procures components and assembles our products based on our demand forecasts. These forecasts represent our estimates of future demand for our products based upon historical trends and analysis from our sales and product management functions as adjusted for overall market conditions. If the actual component usage and product demand are significantly lower than forecast, we accrue for costs for contractual manufacturing commitments in excess of our forecasted demand including costs for excess components or for carrying costs incurred by our contract manufacturer.


## panw:SharesAvailableForGrantTextBlock

[0001327567-15-000027:notes:3]
The following table presents the stock activity and the total number of shares available for grant as of July 31, 2015 (in thousands):

[0001327567-15-000027:notes:4]
|  | Number of shares |
| Balance—July 31, 2014 | 8,066 |  |
| Authorized | 3,578 |  |
| RSUs granted | (4,142 | ) |
| Repurchased | — |  |
| Options forfeited | 54 |  |
| RSUs forfeited | 494 |  |
| Balance—July 31, 2015 | 8,050 |  |


## us-gaap:AvailableForSaleSecuritiesContinuousUnrealizedLossPositionFairValueTableTextBlock

[0001327567-15-000027:notes:5]
The following tables present our investments that were in an unrealized loss position as of July 31, 2015 and July 31, 2014 (in thousands):

[0001327567-15-000027:notes:6]
|  | July 31, 2015 |
|  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
|  | Fair Value |  | Unrealized Loss |  | Fair Value |  | Unrealized Loss |  | Fair Value |  | Unrealized Loss |
| Corporate debt securities | $ | 134,976 |  |  | $ | (179 | ) |  | $ | — |  |  | $ | — |  |  | $ | 134,976 |  |  | $ | (179 | ) |
| U.S. government and agency securities | 348,991 |  |  | (204 | ) |  | — |  |  | — |  |  | 348,991 |  |  | (204 | ) |
| Total | $ | 483,967 |  |  | $ | (383 | ) |  | $ | — |  |  | $ | — |  |  | $ | 483,967 |  |  | $ | (383 | ) |

[0001327567-15-000027:notes:7]
|  | July 31, 2014 |
|  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
|  | Fair Value |  | Unrealized Loss |  | Fair Value |  | Unrealized Loss |  | Fair Value |  | Unrealized Loss |
| Corporate debt securities | $ | 43,868 |  |  | $ | (58 | ) |  | $ | — |  |  | $ | — |  |  | $ | 43,868 |  |  | $ | (58 | ) |
| U.S. government and agency securities | 142,490 |  |  | (108 | ) |  | — |  |  | — |  |  | 142,490 |  |  | (108 | ) |
| Total | $ | 186,358 |  |  | $ | (166 | ) |  | $ | — |  |  | $ | — |  |  | $ | 186,358 |  |  | $ | (166 | ) |


## us-gaap:AvailableForSaleSecuritiesTextBlock

[0001327567-15-000027:notes:8]
The following tables summarize the unrealized gains and losses and fair value of our investments as of July 31, 2015 and July 31, 2014 (in thousands):

[0001327567-15-000027:notes:9]
|  | July 31, 2015 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Estimated Fair Value |
| Certificates of deposit | $ | 1,000 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,000 |  |
| Corporate debt securities | 190,882 |  |  | 24 |  |  | (179 | ) |  | 190,727 |  |
| U.S. government and agency securities | 760,212 |  |  | 271 |  |  | (204 | ) |  | 760,279 |  |
| Total | $ | 952,094 |  |  | $ | 295 |  |  | $ | (383 | ) |  | $ | 952,006 |  |

[0001327567-15-000027:notes:10]
|  | July 31, 2014 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Estimated Fair Value |
| Certificates of deposit | $ | 1,000 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,000 |  |
| Corporate debt securities | 61,299 |  |  | 16 |  |  | (58 | ) |  | 61,257 |  |
| U.S. government and agency securities | 258,376 |  |  | 45 |  |  | (108 | ) |  | 258,313 |  |
| Total | $ | 320,675 |  |  | $ | 61 |  |  | $ | (166 | ) |  | $ | 320,570 |  |


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001327567-15-000027:notes:11]
Basis of Presentation

[0001327567-15-000027:notes:12]
The accompanying consolidated financial statements have been prepared in conformity with U.S. generally accepted accounting principles (GAAP). The consolidated financial statements include all adjustments necessary for a fair presentation of our annual results. All adjustments are of a normal recurring nature. Certain prior period amounts have been reclassified to conform with current period presentation.


## us-gaap:BusinessAcquisitionProFormaInformationTextBlock

[0001327567-15-000027:notes:13]
The following table presents the unaudited pro forma financial information for the years ended July 31, 2014 and 2013, as though the companies were combined as of August 1, 2012 (in thousands):

[0001327567-15-000027:notes:14]
|  | Year Ended July 31, |
|  | 2014 |  | 2013 |
| Total revenue | $ | 598,254 |  |  | $ | 396,131 |  |
| Net loss | $ | (241,920 | ) |  | $ | (43,041 | ) |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001327567-15-000027:notes:15]
Acquisitions

[0001327567-15-000027:notes:16]
Business Combinations

[0001327567-15-000027:notes:17]
Fiscal 2015

[0001327567-15-000027:notes:18]
CirroSecure, Inc.

[0001327567-15-000027:notes:19]
On May 22, 2015, we completed our acquisition of CirroSecure, Inc. (“CirroSecure”), a privately-held cybersecurity company. The acquisition expands the functionality of our next-generation security platform by providing additional security for SaaS applications. We have accounted for this transaction as a business combination in exchange for total cash consideration of $15.3 million.

[0001327567-15-000027:notes:20]
We allocated the purchase consideration to the assets acquired and liabilities assumed based on their estimated fair values and as a result, recorded a developed technology intangible asset of $11.0 million, goodwill of $8.1 million, and net liabilities of $3.8 million in our consolidated balance sheets as of the acquisition date. The developed technology will be amortized over an estimated useful life of seven years. The goodwill is attributable to the assembled workforce and expected post-acquisition synergies and is not deductible for income tax purposes.

[0001327567-15-000027:notes:21]
Adjustments to the allocation of the purchase consideration, specifically income taxes payable and deferred taxes, may be required as additional information is received and certain tax returns are finalized. We expect to finalize the allocation of the purchase consideration to the assets acquired and liabilities assumed as soon as practicable, but not later than 12 months from the acquisition date.

[0001327567-15-000027:notes:22]
CirroSecure’s operating results are included in our consolidated statements of operations from the date of the acquisition and are considered immaterial for purposes of pro forma financial disclosures.

[0001327567-15-000027:notes:23]
Fiscal 2014

[0001327567-15-000027:notes:24]
Cyvera Ltd.

[0001327567-15-000027:notes:25]
On April 9, 2014, we completed our acquisition of Cyvera Ltd. (“Cyvera”), a privately-held cybersecurity company located in Tel Aviv, Israel. The acquisition extends our next-generation security platform with an innovative approach to preventing attacks on the endpoint. We have accounted for this transaction as a business combination in exchange for total consideration of approximately $177.6 million, which consisted of the following (in thousands):

[0001327567-15-000027:notes:26]
|  | Amount |
| Cash | $ | 90,170 |  |
| Common stock (1.3 million shares) | 87,477 |  |
| Total | $ | 177,647 |  |

[0001327567-15-000027:notes:27]
As part of the acquisition, we agreed to replace Cyvera's unvested options with our restricted stock units with an estimated fair value of $6.4 million. Of the total estimated fair value, a portion was allocated to the purchase consideration and the remainder was allocated to future services and will be expensed over the remaining service periods on a straight-line basis as share-based compensation.

[0001327567-15-000027:notes:28]
In addition, we issued 0.3 million shares of restricted common stock with a total fair value of $17.6 million to certain Cyvera employees. The restriction on these shares will be released over a period of three years from the acquisition date, subject to continued employment. These shares were excluded from the purchase consideration and are being expensed over the remaining service periods on a straight-line basis as share-based compensation.

[0001327567-15-000027:notes:29]
We expensed the related acquisition costs in the amount of $3.9 million in general and administrative expenses for the year ended July 31, 2014.

[0001327567-15-000027:notes:30]
The following table summarizes our allocation of the purchase consideration based on the fair value of assets acquired and liabilities assumed (in thousands):

[0001327567-15-000027:notes:31]
|  | Amount |
| Cash | $ | 6,930 |  |
| Goodwill | 145,275 |  |
| Identified intangible assets | 42,300 |  |
| Accrued and other liabilities, net | (6,950 | ) |
| Long-term deferred tax liability, net | (9,908 | ) |
| Total | $ | 177,647 |  |

[0001327567-15-000027:notes:32]
The fair values of assets acquired and liabilities assumed in the table above have been adjusted to reflect changes due to tax returns filed during the measurement period.

[0001327567-15-000027:notes:33]
The following table presents details of the identified intangible assets acquired as of the date of acquisition (in thousands, except years):

[0001327567-15-000027:notes:34]
|  | Fair Value |  | Estimated Useful Life |
| Developed technology | $ | 34,500 |  |  | 7 years |
| In-process research and development | 7,600 |  |  | N/A |
| Other | 200 |  |  | 2 years |
| Total | $ | 42,300 |  |  |  |

[0001327567-15-000027:notes:35]
Goodwill generated from this business combination is primarily attributable to the assembled workforce and synergies from combined selling opportunities of both network security products and endpoint security products. The goodwill is not deductible for income tax purposes.

[0001327567-15-000027:notes:36]
The pro forma financial information for the years ended July 31, 2014 and 2013 has been calculated after adjusting our results and those of Cyvera to reflect the business combination accounting effects resulting from this acquisition as though the acquisition occurred as of August 1, 2012, including acquisition related transaction costs, the amortization expense from acquired intangible assets, and post-acquisition share-based compensation expense related to restricted common stock and the replacement of unvested Cyvera options. The pro forma financial information is for informational purposes only and is not indicative of the results of operations that would have been achieved if the acquisition had taken place at the beginning of our fiscal 2013.

[0001327567-15-000027:notes:37]
The pro forma financial information for the years ended July 31, 2014 and 2013 combines our historical results for the years ended July 31, 2014 and 2013 and the adjusted historical results of Cyvera for the twelve months ended June 30, 2014 and 2013, due to differences in reporting periods and considering the date we acquired Cyvera.

[0001327567-15-000027:notes:38]
Morta Security, Inc.

[0001327567-15-000027:notes:39]
On December 26, 2013, we completed our acquisition of Morta Security, Inc. (“Morta”), a privately-held cybersecurity company. We have accounted for this transaction as a business combination and exchanged total cash consideration of $10.3 million. Morta brings us a team of cybersecurity experts which will enhance the proven detection and prevention capabilities of our WildFire offering.

[0001327567-15-000027:notes:40]
|  | Amount |
| Goodwill | $ | 10,127 |  |
| Identified intangible assets | 2,200 |  |
| Net liabilities assumed | (1,982 | ) |
| Total | $ | 10,345 |  |

[0001327567-15-000027:notes:41]
The following table presents details of the identified intangible assets acquired (in thousands, except years):

[0001327567-15-000027:notes:42]
|  | Fair Value |  | Estimated Useful Life |
| In-process research and development held for defensive purposes | $ | 1,900 |  |  | 3 years |
| Other | 300 |  |  | 2 years |
| Total | $ | 2,200 |  |  |  |

[0001327567-15-000027:notes:43]
Morta’s operating results are included in our consolidated statements of operations from the date of the acquisition and are considered immaterial for purposes of pro forma financial disclosures. Goodwill generated from this business combination is primarily attributable to human capital with threat intelligence experience and capabilities, and is not deductible for income tax purposes.


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock

[0001327567-15-000027:notes:44]
Description of Business and Summary of Significant Accounting Policies

[0001327567-15-000027:notes:45]
Description of Business

[0001327567-15-000027:notes:46]
Palo Alto Networks, Inc. (the “Company,” “we,” “us,” or “our”), located in Santa Clara, California, was incorporated in March 2005 under the laws of the State of Delaware and commenced operations in April 2005. We offer a next-generation security platform that empowers enterprises, service providers, and government entities to secure their organizations by safely enabling the increasingly complex and rapidly growing number of applications running on their networks and by preventing breaches in real-time that stem from targeted cyber attacks.

[0001327567-15-000027:notes:47]
Principles of Consolidation

[0001327567-15-000027:notes:48]
The consolidated financial statements include our accounts and our wholly owned subsidiaries. All significant intercompany balances and transactions have been eliminated in consolidation.

[0001327567-15-000027:notes:49]
Use of Estimates

[0001327567-15-000027:notes:50]
The preparation of consolidated financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the consolidated financial statements and the reported amounts of revenues and expenses during the reporting period. Such management estimates include, but are not limited to the best estimate of selling price for our products and services, share-based compensation, fair value of assets acquired and liabilities assumed in business combinations, the assessment of recoverability of our property and equipment, identified intangibles and goodwill, future taxable income, contract manufacturer liabilities, and loss contingencies. We base our estimates on historical experience and also on assumptions that we believe are reasonable. Actual results could differ materially from those estimates.

[0001327567-15-000027:notes:51]
Concentrations

[0001327567-15-000027:notes:52]
Financial instruments that subject us to concentrations of credit risk consist primarily of cash and cash equivalents, investments, and accounts receivable. We invest only in high-quality credit instruments and maintain our cash and cash equivalents and available-for-sale investments in fixed income securities. Management believes that the financial institutions that hold our investments are financially sound and, accordingly, are subject to minimal credit risk. Deposits held with banks may exceed the amount of insurance provided on such deposits.

[0001327567-15-000027:notes:53]
Our accounts receivables are primarily derived from our channel partners representing various geographical locations. We perform ongoing credit evaluations of our channel partners and generally do not require collateral on accounts receivable. We maintain an allowance for doubtful accounts for estimated potential credit losses. As of July 31, 2015, two channel partners represented 36% and 30% of our gross accounts receivable. For fiscal 2015, three channel partners represented 31%, 29%, and 11% of our total revenue. We rely on an independent contract manufacturer to assemble most of our products and sole suppliers for a certain number of our components.

[0001327567-15-000027:notes:54]
Comprehensive Loss

[0001327567-15-000027:notes:55]
Comprehensive loss is comprised of net loss and other comprehensive income (loss). Unrealized gains and losses on available-for-sale investments are included in our other comprehensive income or loss.

[0001327567-15-000027:notes:56]
Foreign Currency Transactions

[0001327567-15-000027:notes:57]
The functional currency of our foreign subsidiaries is the U.S. dollar. Monetary assets and liabilities denominated in foreign currencies have been remeasured into U.S. dollars using the exchange rates in effect at the balance sheet dates. Foreign currency denominated income and expenses have been remeasured using the average exchange rates in effect during each period. Foreign currency remeasurement gains and losses and foreign currency transaction gains and losses are not significant to the financial statements.

[0001327567-15-000027:notes:58]
Cash and Cash Equivalents

[0001327567-15-000027:notes:59]
We consider all highly liquid investments held at financial institutions, such as commercial paper, money market funds, and other money market securities with original maturities of three months or less at date of purchase to be cash equivalents.

[0001327567-15-000027:notes:60]
Fair Value

[0001327567-15-000027:notes:61]
We define fair value as the price that would be received from selling an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date. When determining the fair value measurements for assets and liabilities which are required to be recorded at fair value, we consider the principal or most advantageous market in which to transact and the market-based risk. We apply fair value accounting for all financial assets and liabilities that are recognized or disclosed at fair value in the financial statements on a recurring basis. The carrying amounts reported in the consolidated financial statements approximate the fair value for cash and cash equivalents, accounts receivable, accounts payable, and accrued liabilities, due to their short-term nature.

[0001327567-15-000027:notes:62]
Investments

[0001327567-15-000027:notes:63]
We classify our investments as available-for-sale at the time of purchase since it is our intent that these investments are available for current operations, and include these investments on our consolidated balance sheet as either short-term or long-term investments depending on their maturity. Investments not considered cash equivalents and with maturities one year or less from the consolidated balance sheet date are classified as short-term investments. Investments with maturities greater than one year from the consolidated balance sheet date are classified as long-term investments.

[0001327567-15-000027:notes:64]
Investments are considered impaired when a decline in fair value is judged to be other-than-temporary. We consult with our investment managers and consider available quantitative and qualitative evidence in evaluating potential impairment of our investments on a quarterly basis. If the cost of an individual investment exceeds its fair value, we evaluate, among other factors, general market conditions, the duration and extent to which the fair value is less than cost, and our intent and ability to hold the investment. Once a decline in fair value is determined to be other-than-temporary, an impairment charge is recorded and a new cost basis in the investment is established.

[0001327567-15-000027:notes:65]
Accounts Receivable

[0001327567-15-000027:notes:66]
Trade accounts receivable are recorded at the invoiced amount, net of allowances for doubtful accounts. The allowance for doubtful accounts is based on our assessment of the collectability of accounts. Management regularly reviews the adequacy of the allowance for doubtful accounts by considering the age of each outstanding invoice, each channel partner’s expected ability to pay, and the collection history with each channel partner, when applicable, to determine whether a specific allowance is appropriate. Accounts receivable deemed uncollectible are charged against the allowance for doubtful accounts when identified. As of July 31, 2015 and 2014, the allowance for doubtful accounts activity was not significant.

[0001327567-15-000027:notes:67]
Property and Equipment

[0001327567-15-000027:notes:68]
Property and equipment are recorded at cost. Depreciation is computed using the straight-line method over the estimated useful lives of the assets, generally three to ten years. Leasehold improvements are depreciated over the shorter of the estimated useful lives of the improvements or the remaining lease term.

[0001327567-15-000027:notes:69]
We include the results of operations of the businesses that we acquire as of the respective dates of acquisition. We allocate the fair value of the purchase price of our acquisitions to the tangible assets acquired, liabilities assumed, and intangible assets acquired, based on their estimated fair values. The excess of the purchase price over the fair values of these identifiable assets and liabilities is recorded as goodwill. Additional information existing as of the acquisition date but unknown to us may become known during the remainder of the measurement period, not to exceed 12 months from the acquisition date, which may result in changes to the amounts and allocations recorded.

[0001327567-15-000027:notes:70]
Amortization of Intangible Assets

[0001327567-15-000027:notes:71]
Purchased intangible assets with finite lives are carried at cost, less accumulated amortization. Amortization is computed over the estimated useful lives of the respective assets. Acquisition-related in-process research and development represents the fair value of incomplete research and development projects that have not reached technological feasibility as of the date of acquisition. Initially, these assets are not subject to amortization. Assets related to projects that have been completed are transferred to developed technology, which are subject to amortization.

[0001327567-15-000027:notes:72]
Impairment of Goodwill, Intangible Assets, and Long-Lived Assets

[0001327567-15-000027:notes:73]
Goodwill is evaluated for impairment on an annual basis in the fourth quarter of our fiscal year, and whenever events or changes in circumstances indicate the carrying amount of goodwill may not be recoverable. We have elected to first assess qualitative factors to determine whether it is more likely than not that the fair value of our single reporting unit is less than its carrying amount. If we determine that it is more likely than not that the fair value of our single reporting unit is less than its carrying amount, then the two-step goodwill impairment test will be performed. The first step, identifying a potential impairment, compares the fair value of our single reporting unit with its carrying amount. If the carrying amount exceeds its fair value, the second step will be performed; otherwise, no further step is required. The second step, measuring the impairment loss, compares the implied fair value of the goodwill with the carrying amount of the goodwill. Any excess of the goodwill carrying amount over the implied fair value is recognized as an impairment loss.

[0001327567-15-000027:notes:74]
We evaluate events and changes in circumstances that could indicate carrying amounts of purchased intangible assets and long-lived assets may not be recoverable. When such events or changes in circumstances occur, we assess the recoverability of these assets by determining whether or not the carrying amount will be recovered through undiscounted expected future cash flows. If the total of the future undiscounted cash flows is less than the carrying amount of an asset, we record an impairment loss for the amount by which the carrying amount of the asset exceeds the fair value of the asset.

[0001327567-15-000027:notes:75]
Through July 31, 2015, we have not recognized any impairment losses on our goodwill, intangible assets, and long-lived assets.

[0001327567-15-000027:notes:76]
We outsource most of our manufacturing, repair, and supply chain management operations to our independent contract manufacturer and payments to it are a significant portion of our product cost of revenues. Although we could be contractually obligated to purchase manufactured products, we generally do not own the manufactured products. Product title transfers from our independent contract manufacturer to us and immediately to our channel partners upon shipment. Our independent contract manufacturer assembles our products using design specifications, quality assurance programs, and standards that we establish and it procures components and assembles our products based on our demand forecasts. These forecasts represent our estimates of future demand for our products based upon historical trends and analysis from our sales and product management functions as adjusted for overall market conditions. If the actual component usage and product demand are significantly lower than forecast, we accrue for costs for contractual manufacturing commitments in excess of our forecasted demand including costs for excess components or for carrying costs incurred by our contract manufacturer. Through July 31, 2015, we have not accrued any significant costs associated with this exposure.

[0001327567-15-000027:notes:77]
Convertible Senior Notes

[0001327567-15-000027:notes:78]
On June 30, 2014, we issued $575.0 million aggregate principal amount of 0.0% Convertible Senior Notes due 2019 (the “Notes”). In accounting for the issuance of the Notes, we separated the Notes into liability and equity components. The carrying amount of the liability component was calculated by measuring the fair value of a similar liability that does not have an associated convertible feature. The carrying amount of the equity component representing the conversion option was determined by deducting the fair value of the liability component from the par value of the Notes as a whole. This difference represents a debt discount that is amortized to interest expense using the effective interest method over the term of the Notes. The equity component is not remeasured as long as it continues to meet the conditions for equity classification. In accounting for the transaction costs related to the issuance of the Notes, we allocated the total amount incurred to the liability and equity components using the same proportions as the proceeds from the Notes. Transaction costs attributable to the liability component are being amortized to interest expense using the effective interest method over the term of the Notes. Transaction costs attributable to the equity component were netted with the equity component of the Notes in additional paid-in capital in the consolidated balance sheets.

[0001327567-15-000027:notes:79]
When the Notes are convertible, the net carrying amount of the Notes and related debt issuance costs will be classified as current liabilities and current assets, respectively, in our consolidated balance sheets. In addition, a portion of the equity component representing the conversion option will be reclassified to temporary equity in our consolidated balance sheets.

[0001327567-15-000027:notes:80]
Revenue Recognition

[0001327567-15-000027:notes:81]
We generate revenue from the sales of hardware and software products, subscriptions, support and maintenance, and other services primarily through a direct sales force and indirect relationships with channel partners, and, to a lesser extent, directly to end-customers.

[0001327567-15-000027:notes:82]
Revenue is recognized when all of the following criteria are met:

[0001327567-15-000027:notes:83]
| • | Persuasive Evidence of an Arrangement Exists. We rely upon non-cancelable sales agreements and purchase orders to determine the existence of an arrangement. |

[0001327567-15-000027:notes:84]
| • | Delivery has Occurred. We use shipping documents or transmissions of product or service contract registration codes to determine delivery. |

[0001327567-15-000027:notes:85]
| • | The Fee is Fixed or Determinable. We assess whether the fee is fixed or determinable based on the payment terms associated with the transaction. |

[0001327567-15-000027:notes:86]
| • | Collectability is Reasonably Assured. We assess collectability based on credit analysis and payment history. |

[0001327567-15-000027:notes:87]
We recognize product revenue at the time of shipment provided that all other revenue recognition criteria have been met. Our channel partners generally receive an order from an end-customer prior to placing an order with us. In addition, payment from our channel partners is not contingent on the partner’s success in sales to end-customers. Our channel partners generally do not stock appliances and only have limited stock rotation rights and no price protection rights. When necessary, we make certain estimates and maintain allowances for sales returns and other programs based on our historical experience. To date, these estimates have not been significant. We recognize services revenue from subscriptions and support and maintenance ratably over the contractual service period, which is typically one to five years. Other services revenue is recognized as the services are rendered.

[0001327567-15-000027:notes:88]
Most of our arrangements, other than renewals of subscriptions and support and maintenance, are multiple-element arrangements with a combination of hardware, software, subscriptions, support and maintenance, and other services. Products and services generally qualify as separate units of accounting. Our hardware deliverables typically include proprietary operating system software, which together deliver the essential functionality of our products. For multiple-element arrangements, we allocate revenue to each unit of accounting based on an estimated selling price at the arrangement inception. The estimated selling price for each element is based upon the following hierarchy: vendor-specific objective evidence (VSOE) of selling price, if available, third-party evidence (TPE) of selling price, if VSOE of selling price is not available, or best estimate of selling price (BESP), if neither VSOE of selling price nor TPE of selling price are available. The total arrangement consideration is allocated to each separate unit of accounting using the relative estimated selling prices of each unit based on the aforementioned selling price hierarchy. We limit the amount of revenue recognized for delivered elements to an amount that is not contingent upon future delivery of additional products or services or meeting of any specified performance conditions.

[0001327567-15-000027:notes:89]
In multiple-element arrangements where software deliverables are included, revenue is allocated to each separate unit of accounting for each of the non-software deliverables and to the software deliverables as a group using the relative estimated selling prices of each of the deliverables in the arrangement based on the aforementioned estimated selling price hierarchy. The arrangement consideration allocated to the software deliverables as a group is then allocated to each software deliverable using the residual method when VSOE of fair value of the undelivered items exists. Under the residual method, the amount of revenue allocated to delivered elements equals the total arrangement consideration less the aggregate fair value of any undelivered elements. In determining VSOE of fair value, we evaluate whether a substantial majority of the historical prices charged for a product or service sold on a standalone basis, as represented by a percentage of list price, fall within a reasonably narrow range. If VSOE of fair value of one or more undelivered items does not exist, revenue from the software portion of the arrangement is deferred and recognized at the earlier of: (i) delivery of those elements or (ii) when fair value can be established unless support and maintenance is the only undelivered element, in which case, the entire software arrangement fee is recognized ratably over the contractual service period.

[0001327567-15-000027:notes:90]
We account for multiple agreements with a single partner as one arrangement if the contractual terms and/or substance of those agreements indicate that they may be so closely related that they are, in effect, parts of a single arrangement.

[0001327567-15-000027:notes:91]
Revenues are reported net of sales taxes. Shipping charges billed to channel partners are included in revenues and related costs are included in cost of revenue. Sales commissions and other incremental costs to acquire contracts are also expensed as incurred. After receipt of a partner order, any amounts billed in excess of revenue recognized are recorded as deferred revenue.

[0001327567-15-000027:notes:92]
Advertising Costs

[0001327567-15-000027:notes:93]
Advertising costs, which are expensed and included in sales and marketing expense when incurred, were $4.8 million, $3.7 million, and $1.8 million, during the years ended July 31, 2015, 2014, and 2013, respectively.

[0001327567-15-000027:notes:94]
Software Development Costs

[0001327567-15-000027:notes:95]
Internally developed software includes enterprise-level business software that we are customizing to meet our specific operational needs. These capitalized costs consisted of the external direct costs and the internal payroll and payroll related costs that are related to the implementation of our enterprise resource planning software system and will be amortized over a useful life of three to five years.

[0001327567-15-000027:notes:96]
The costs to develop software that is marketed externally have not been capitalized as we believe our current software development process is essentially completed concurrent with the establishment of technological feasibility. As such, all related software development costs are expensed as incurred and included in research and development expense in our consolidated statements of operations.

[0001327567-15-000027:notes:97]
Share-Based Compensation

[0001327567-15-000027:notes:98]
Compensation expense related to share-based transactions, including employee and non-employee director awards, is measured and recognized in the financial statements based on fair value on the grant date. We recognize share-based compensation expense, net of estimated forfeitures, on a straight-line basis over the requisite service periods of the related awards.

[0001327567-15-000027:notes:99]
Leases

[0001327567-15-000027:notes:100]
We rent our facilities under operating lease agreements and recognize related rent expense on a straight-line basis over the term of the lease. Some of our lease agreements contain rent holidays, scheduled rent increases, lease incentives, and renewal options. Rent holidays and scheduled rent increases are included in the determination of rent expense to be recorded over the lease term. Lease incentives are recognized as a reduction of rent expense on a straight-line basis over the term of the lease. Renewals are not assumed in the determination of the lease term unless they are deemed to be reasonably assured at the inception of the lease. We begin recognizing rent expense on the date that we obtain the legal right to use and control the leased space.

[0001327567-15-000027:notes:101]
Income Taxes

[0001327567-15-000027:notes:102]
We account for income taxes using the asset and liability method, which requires the recognition of deferred tax assets and liabilities for the expected future tax consequences of events that have been recognized in our financial statements or tax returns. In addition, deferred tax assets are recorded for the future benefit of utilizing net operating losses and research and development credit carryforwards. Valuation allowances are provided when necessary to reduce deferred tax assets to the amount expected to be realized.

[0001327567-15-000027:notes:103]
Significant judgment is required in determining any valuation allowance recorded against deferred tax assets. In assessing the need for a valuation allowance, we consider all available evidence, including past operating results, estimates of future taxable income, and the feasibility of tax planning strategies. In the event that we change our determination as to the amount of deferred tax assets that can be realized, we will adjust our valuation allowance with a corresponding impact to the provision for income taxes in the period in which such determination is made.

[0001327567-15-000027:notes:104]
We apply the authoritative accounting guidance prescribing a threshold and measurement attribute for the financial recognition and measurement of a tax position taken or expected to be taken in a tax return. We recognize liabilities for uncertain tax positions based on a two-step process. The first step is to evaluate the tax position for recognition by determining if the weight of available evidence indicates that it is more likely than not that the position will be sustained on audit, including resolution of related appeals or litigation processes, if any. The second step requires us to estimate and measure the tax benefit as the largest amount that is more likely than not to be realized upon ultimate settlement.

[0001327567-15-000027:notes:105]
Loss Contingencies

[0001327567-15-000027:notes:106]
We are subject to the possibility of various loss contingencies arising in the ordinary course of business. In determining loss contingencies, we consider the likelihood of loss or impairment of an asset, or the incurrence of a liability, as well as our ability to reasonably estimate the amount of loss. An estimated loss contingency is accrued when it is probable that an asset has been impaired or a liability has been incurred and the amount of loss can be reasonably estimated. If we determine that a loss is possible and the range of the loss can be reasonably determined, then we disclose the range of the possible loss. We regularly evaluate current information available to us to determine whether an accrual is required, an accrual should be adjusted or a range of possible loss should be disclosed.

[0001327567-15-000027:notes:107]
Recent Accounting Pronouncements

[0001327567-15-000027:notes:108]
In April 2015, the Financial Accounting Standards Board (FASB) issued new authoritative guidance on fees paid in a cloud computing arrangement. The standard requires customers in a cloud computing arrangement to evaluate whether the arrangement includes a software license. If the arrangement includes a software license, the customer should account for the software license element of the arrangement consistent with the acquisition of other software licenses. If the arrangement does not include a software license, the customer should account for the arrangement as a service contract. The standard is effective for us for our first quarter of fiscal 2017, although early adoption is permitted, and will be applied on either a prospective or retrospective basis. We are currently evaluating adoption methods and whether this standard will have a material impact on our consolidated financial statements.

[0001327567-15-000027:notes:109]
In April 2015, the FASB issued updated authoritative guidance to simplify the presentation of debt issuance costs. The amended standard requires that debt issuance costs related to a recognized debt liability be presented in the balance sheet as a direct deduction from the carrying amount of the related debt liability, consistent with the presentation of debt discounts, instead of being presented as an asset. The amended standard is effective for us for our first quarter of fiscal 2017, although early adoption is permitted, and will be applied on a retrospective basis. We do not expect the adoption of the standard will have a material impact on our consolidated financial statements.

[0001327567-15-000027:notes:110]
In May 2014, the FASB issued new authoritative guidance on revenue from contracts with customers. The new standard provides principles for recognizing revenue for the transfer of promised goods or services to customers with the consideration to which the entity expects to be entitled in exchange for those goods or services. The standard also requires significantly expanded disclosures about revenue recognition. In July 2015, the FASB decided to delay the effective date of the new standard by one year. The guidance is now effective for us for our first quarter of fiscal 2019 using either of two methods: (i) retrospective to each prior reporting period presented with the option to elect certain practical expedients as defined within the guidance; or (ii) retrospective with the cumulative effect of initially applying the guidance recognized at the date of initial application and providing certain additional disclosures as defined per the guidance. Early adoption as of the original effective date is permitted. We are currently evaluating adoption methods and whether this standard will have a material impact on our consolidated financial statements.

[0001327567-15-000027:notes:111]
In July 2013, the FASB issued new authoritative guidance on the financial statement presentation of an unrecognized tax benefit when a net operating loss carryforward, a similar tax loss, or a tax credit carryforward exists. The standard requires us to present an unrecognized tax benefit as a reduction of a deferred tax asset for a net operating loss (NOL) carryforward or other tax credit carryforward when settlement in this manner is available under applicable tax law. The guidance was effective for us in the first quarter of fiscal 2015. Our adoption of this guidance did not have an impact on our consolidated financial statements.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001327567-15-000027:notes:112]
Commitments and Contingencies

[0001327567-15-000027:notes:113]
We lease our facilities under various non-cancelable operating leases, which expire through the year ending July 31, 2028.

[0001327567-15-000027:notes:114]
In September 2012, we entered into two lease agreements for an aggregate of approximately 300,000 square feet of space in Santa Clara, California to serve as our corporate headquarters beginning in November 2013. The leases commenced in November 2012 and August 2013, expire in July 2023, and allow for two separate 5-year options to extend the lease term. Payments under these leases are approximately $94.3 million over the lease term. Each lease has a rent holiday, which was included in the determination of rent expense.

[0001327567-15-000027:notes:115]
In July 2013, we entered into a 51-month sub-lease agreement for our previous corporate headquarters with a commencement date of January 2014. Net proceeds from this sub-lease are approximately $10.7 million over the lease term. The sub-lease agreement contains a rent credit of $0.5 million, which was included in the determination of rental income.

[0001327567-15-000027:notes:116]
In May 2015, we entered into three lease agreements for approximately 752,000 square feet of corporate office space in Santa Clara, California to serve as our future corporate headquarters. The first lease will commence in May 2016 and expire in April 2021, although it can also be terminated by us under certain conditions. The remaining two leases will commence in May 2017 and expire in April 2028, however, the property is currently under construction and as a result, the lease commencement dates may change based on progress of the construction project. The leases contain a rent holiday period, scheduled rent increases, lease incentives, and renewal options which allow the lease terms to be extended through April 2046. Rental payments under the three lease agreements are approximately $275.1 million over the lease term. In August 2015, we executed the expansion notice under the lease agreements to notify the landlord of our intent to lease approximately 300,000 square feet of additional space in a building that will be constructed at a future date. The lease related to this additional space has not yet been executed.

[0001327567-15-000027:notes:117]
We recognized rent expense of $15.4 million, $13.2 million, and $4.4 million for the years ended July 31, 2015, 2014, and 2013, respectively. Rent expense is recognized on a straight-line basis over the term of the lease.

[0001327567-15-000027:notes:118]
The following table presents details of the aggregate future non-cancelable minimum rental payments under our operating leases as of July 31, 2015 (in thousands):

[0001327567-15-000027:notes:119]
|  | Amount |
| Years ending July 31: |  |
| 2016 | $ | 20,821 |  |
| 2017 | 24,374 |  |
| 2018 | 27,133 |  |
| 2019 | 41,583 |  |
| 2020 | 42,043 |  |
| 2021 and thereafter | 253,202 |  |
| Committed gross lease payments | 409,156 |  |
| Less: proceeds from sublease rental | 8,174 |  |
| Net operating lease obligation | $ | 400,982 |  |

[0001327567-15-000027:notes:120]
Contract Manufacturer Commitments

[0001327567-15-000027:notes:121]
Our independent contract manufacturer procures components and assembles our products based on our forecasts. These forecasts are based on estimates of demand for our products primarily for the next twelve months, which are in turn based on historical trends and an analysis from our sales and product marketing organizations, adjusted for overall market conditions. In order to reduce manufacturing lead times and plan for adequate supply, we may issue forecasts and orders for components and products that are non-cancelable. Obligations under contracts that we can cancel without a significant penalty are not included. As of July 31, 2015, we had $42.8 million of open orders.

[0001327567-15-000027:notes:122]
Litigation

[0001327567-15-000027:notes:123]
In December 2011, Juniper Networks, Inc. (“Juniper”) filed a complaint against us in the United States District Court for the District of Delaware alleging patent infringement, which sought preliminary and permanent injunctions against infringement, treble damages, and attorneys’ fees. On September 30, 2013, we filed a lawsuit against Juniper in the United States District Court for the Northern District of California alleging that Juniper’s products infringe three of our U.S. patents, and sought monetary damages and a permanent injunction. On May 27, 2014, we entered into a Settlement, Release and Cross-License Agreement (the “Settlement Agreement”) with Juniper to resolve all pending litigation between the parties, including those discussed above. Refer to Note 9. Legal Settlement for more information on the Settlement Agreement.

[0001327567-15-000027:notes:124]
In addition to the above matter, we are subject to legal proceedings, claims, and litigation arising in the ordinary course of business, including intellectual property litigation. Such matters are subject to many uncertainties and outcomes are not predictable with assurance. We accrue for contingencies when we believe that a loss is probable and that we can reasonably estimate the amount of any such loss.

[0001327567-15-000027:notes:125]
To the extent there is a reasonable possibility that a loss exceeding amounts already recognized may be incurred and the amount of such additional loss would be material, we will either disclose the estimated additional loss or state that such an estimate cannot be made. As of July 31, 2015, we have not recorded any significant accruals for loss contingencies associated with such legal proceedings, determined that an unfavorable outcome is probable or reasonably possible, or determined that the amount or range of any possible loss is reasonably estimable.

[0001327567-15-000027:notes:126]
Indemnification

[0001327567-15-000027:notes:127]
Under the indemnification provisions of our standard sales related contracts, we agree to defend our end-customers against third-party claims asserting infringement of certain intellectual property rights, which may include patents, copyrights, trademarks, or trade secrets, and to pay judgments entered on such claims. Our exposure under these indemnification provisions is generally limited to the total amount paid by our end-customer under the agreement. However, certain agreements include indemnification provisions that could potentially expose us to losses in excess of the amount received under the agreement. In addition, we indemnify our officers, directors, and certain key employees while they are serving in good faith in their company capacities. To date, there have been no claims under any indemnification provisions.


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0001327567-15-000027:notes:128]
Employee Benefit Plan

[0001327567-15-000027:notes:129]
We have established a 401(k) tax-deferred savings plan which permits participants to make contributions by salary deduction pursuant to Section 401(k) of the Internal Revenue Code. We are responsible for administrative costs of the plan and have made no contributions to the plan since inception.


## us-gaap:ConvertibleDebtTableTextBlock

[0001327567-15-000027:notes:130]
The following table sets forth the components of the Notes as of July 31, 2015 and July 31, 2014 (in thousands):

[0001327567-15-000027:notes:131]
|  | July 31, |
|  | 2015 |  | 2014 |
| Liability: |  |  |  |
| Principal | $ | 575,000 |  |  | $ | 575,000 |  |
| Less: debt discount, net of amortization | 87,916 |  |  | 108,125 |  |
| Net carrying amount | $ | 487,084 |  |  | $ | 466,875 |  |
| Equity (including temporary equity) | $ | (109,785 | ) |  | $ | (109,785 | ) |


## us-gaap:DebtDisclosureTextBlock

[0001327567-15-000027:notes:132]
On June 30, 2014, we issued $575.0 million aggregate principal amount of 0.0% Convertible Senior Notes due 2019 (the “Notes”). The Notes are governed by an indenture between us, as the issuer, and U.S. Bank National Association, as Trustee (the “Indenture”). The Notes are unsecured, unsubordinated obligations that do not contain any financial covenants or restrictions on the payments of dividends, the incurrence of indebtedness, or the issuance or repurchase of securities by us or any of our subsidiaries. The Notes mature on July 1, 2019 unless converted or repurchased in accordance with their terms prior to such date. We cannot redeem the Notes prior to maturity.

[0001327567-15-000027:notes:133]
The Notes are convertible for up to 5.2 million shares of our common stock at an initial conversion rate of approximately 9.068 shares of common stock per $1,000 principal amount, which is equal to an initial conversion price of approximately $110.28 per share of common stock, subject to adjustment. Holders of the Notes may surrender their Notes for conversion at their option at any time prior to the close of business on the business day immediately preceding January 1, 2019, only under the following circumstances:

[0001327567-15-000027:notes:134]
| • | during any fiscal quarter commencing after the fiscal quarter ending on October 31, 2014 (and only during such fiscal quarter), if the last reported sale price of our common stock for at least 20 trading days (whether or not consecutive) during a period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the conversion price for the Notes on each applicable trading day; |

[0001327567-15-000027:notes:135]
| • | during the five business day period after any five consecutive trading day period (the “measurement period”), in which the trading price per $1,000 principal amount of Notes for each trading day of the measurement period was less than 98% of the product of the last reported sale price of our common stock and the conversion rate for the Notes on each such trading day; or |

[0001327567-15-000027:notes:136]
| • | upon the occurrence of specified corporate events. |

[0001327567-15-000027:notes:137]
On or after January 1, 2019, holders may convert all or any portion of their Notes at any time prior to the close of business on the second scheduled trading day immediately preceding the maturity date regardless of the foregoing conditions. Upon conversion, holders will receive cash equal to the aggregate principal amount of the Notes to be converted, and, at our election, cash and/or shares of our common stock for any amounts in excess of the aggregate principal amount of the Notes being converted.

[0001327567-15-000027:notes:138]
The conversion price will be subject to adjustment in some events. Holders of the Notes who convert their Notes in connection with certain corporate events that constitute a “make-whole fundamental change” per the Indenture are, under certain circumstances, entitled to an increase in the conversion rate. Additionally, upon the occurrence of a corporate event that constitutes a “fundamental change” per the Indenture, holders of the Notes may require us to repurchase for cash all or a portion of the Notes at a purchase price equal to 100% of the principal amount of the Notes plus accrued and unpaid contingent interest.

[0001327567-15-000027:notes:139]
In accounting for the issuance of the Notes, we separated the Notes into liability and equity components. The carrying amount of the liability component was calculated by measuring the fair value of a similar liability that does not have an associated convertible feature. The carrying amount of the equity component representing the conversion option was determined by deducting the fair value of the liability component from the par value of the Notes as a whole. The difference between the principal amount of the Notes and the liability component (the “debt discount”), is amortized to interest expense using the effective interest method over the term of the Notes. The equity component of the Notes was recorded in additional paid-in capital in our consolidated balance sheets and is not remeasured as long as it continues to meet the conditions for equity classification.

[0001327567-15-000027:notes:140]
In accounting for the transaction costs related to the issuance of the Notes, we allocated the total amount incurred to the liability and equity components using the same proportions as the proceeds from the Notes. Transaction costs attributable to the liability component were recorded in other assets in our consolidated balance sheets and are being amortized to interest expense in our consolidated statements of operations using the effective interest method over the term of the Notes. Transaction costs attributable to the equity component were netted with the equity component of the Notes in additional paid-in capital in our consolidated balance sheets. We recorded liability issuance costs, or debt issuance costs, of $12.5 million and equity issuance costs of $2.9 million.

[0001327567-15-000027:notes:141]
During the fiscal quarter ended April 30, 2015, the last reported sale price of our common stock was greater than or equal to 130% of the conversion price of the Notes for at least 20 of the last 30 consecutive trading days of such quarter (the “stock price conversion right”). As a result, holders could convert their Notes at any time during the fiscal quarter ending July 31, 2015. Accordingly, we reclassified the net carrying amount of the Notes and related debt issuance costs to current liabilities and current assets, respectively, in our consolidated balance sheets. We also reclassified a portion of the equity component representing the conversion option to temporary equity in our consolidated balance sheets. The stock price conversion right continued to be met during the fiscal quarter ended July 31, 2015, and as a result, holders may convert their Notes at any time during the fiscal quarter ending October 31, 2015. Accordingly, a portion of the equity component remained classified in temporary equity in our consolidated balance sheets. The portion of the equity component classified as temporary equity is measured as the difference between the principal and net carrying amount of the Notes.

[0001327567-15-000027:notes:142]
The total estimated fair value of the Notes was $994.8 million and $587.1 million at July 31, 2015 and July 31, 2014, respectively. The fair value was determined based on the closing trading price per $100 of the Notes as of the last day of trading for the period. We consider the fair value of the Notes at July 31, 2015 and July 31, 2014 to be a Level 2 measurement. The fair value of the Notes is primarily affected by the trading price of our common stock and market interest rates. As of July 31, 2015, the if-converted value of the Notes exceeded its principal amount by $376.7 million.

[0001327567-15-000027:notes:143]
The following table sets forth interest expense recognized related to the Notes for the years ended July 31, 2015 and July 31, 2014 (dollars in thousands):

[0001327567-15-000027:notes:144]
|  | Year Ended July 31, |
|  | 2015 |  | 2014 |
| Amortization of debt issuance costs | $ | 2,056 |  |  | $ | 166 |  |
| Amortization of debt discount | 20,209 |  |  | 1,660 |  |
| Total interest expense recognized | $ | 22,265 |  |  | $ | 1,826 |  |
| Effective interest rate of the liability component | 4.8 | % |  | 4.8 | % |

[0001327567-15-000027:notes:145]
Note Hedges

[0001327567-15-000027:notes:146]
To minimize the impact of potential economic dilution upon conversion of the Notes, we entered into convertible note hedge transactions (the “Note Hedges”) with respect to our common stock concurrent with the issuance of the Notes. The Note Hedges cover up to 5.2 million shares of our common stock at a strike price per share that corresponds to the initial conversion price of the Notes, which are also subject to adjustment, and are exercisable upon conversion of the Notes. The Note Hedges will expire upon maturity of the Notes. The Note Hedges are separate transactions and are not part of the terms of the Notes. Holders of the Notes will not have any rights with respect to the Note Hedges. The shares receivable related to the Note Hedges are excluded from the calculation of diluted earnings per share as they are antidilutive.

[0001327567-15-000027:notes:147]
We paid an aggregate amount of $111.0 million for the Note Hedges, which is included in additional paid-in capital in our consolidated balance sheets.

[0001327567-15-000027:notes:148]
Warrants

[0001327567-15-000027:notes:149]
Separately, but concurrently with our issuance of the Notes, we entered into warrant transactions (the “Warrants”) whereby we sold warrants to acquire up to 5.2 million shares of our common stock at a strike price of approximately $137.85 per share, subject to adjustments. The shares issuable under the Warrants will be included in the calculation of diluted earnings per share when the average market value per share of our common stock for the reporting period exceeds the strike price of the Warrants. The Warrants are separate transactions and are not part of the Notes or Notes Hedges, and are not remeasured through earnings each reporting period. Holders of the Notes and Note Hedges will not have any rights with respect to the Warrants.

[0001327567-15-000027:notes:150]
We received aggregate proceeds of $78.3 million from the sale of the Warrants, which is included in additional paid-in capital in our consolidated balance sheets.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001327567-15-000027:notes:151]
Equity Award Plans

[0001327567-15-000027:notes:152]
Share-Based Compensation Plans

[0001327567-15-000027:notes:153]
2012 Equity Incentive Plan

[0001327567-15-000027:notes:154]
Our 2012 Equity Incentive Plan (our “2012 Plan”) was adopted by our board of directors and approved by the stockholders on June 5, 2012 and was effective one business day prior to the effectiveness of our registration statement for our initial public offering (IPO). Our 2012 Plan replaced our 2005 Equity Incentive Plan (our “2005 Plan”), which terminated upon the completion of our IPO, however, awards that were outstanding upon termination remained outstanding pursuant to their original terms. Our 2012 Plan provides for the granting of stock options, restricted stock awards, restricted stock units (RSUs), stock appreciation rights, performance units, and performance shares to our employees, directors, and consultants.

[0001327567-15-000027:notes:155]
Awards granted under our 2012 Plan vest over the periods determined by the board of directors, generally three to four years, and expire no more than ten years after the date of grant. In the case of an incentive stock option granted to an employee, who at the time of grant owns stock representing more than 10% of the total combined voting power of all classes of stock, the exercise price shall be no less than 110% of the fair value per share on the date of grant, and expire five years from the date of grant, and for options granted to any other employee, the per share exercise price shall be no less than 100% of the fair value per share on the date of grant. In the case of a non-statutory stock option and options granted to consultants, the per share exercise price shall be no less than 100% of the fair value per share on the date of grant. Stock that is purchased prior to vesting is subject to our right of repurchase at any time following termination of the participant. Since our IPO in 2012, awards granted under our 2012 Plan consist primarily of RSUs, which generally vest over a period of three to four years from the date of grant. Until vested, RSUs do not have the voting and dividend participation rights of common stock and the shares underlying the awards are not considered issued and outstanding.

[0001327567-15-000027:notes:156]
A total of 18.5 million shares of our common stock are reserved for issuance pursuant to our 2012 Plan as of July 31, 2015. This includes shares that are (i) reserved but unissued under our 2005 Plan on the effective date of our 2012 Plan or (ii) returned to our 2005 Plan as a result of expiration or termination of options. On the first day of each fiscal year, the number of shares in the reserve may be increased by the lesser of (i) 8,000,000 shares, (ii) 4.5% of the outstanding shares of common stock on the last day of our immediately preceding fiscal year, or (iii) such other amount as determined by our board of directors.

[0001327567-15-000027:notes:157]
2012 Employee Stock Purchase Plan

[0001327567-15-000027:notes:158]
Our 2012 Employee Stock Purchase Plan (our “2012 ESPP”) was adopted by our board of directors and approved by the stockholders on June 5, 2012 and was effective upon completion of our IPO.

[0001327567-15-000027:notes:159]
Our 2012 ESPP permits eligible employees to acquire shares of our common stock at 85% of the lower of the fair market value of our common stock on the first trading day of each offering period or on the exercise date. Each offering period will be approximately six months starting on the first trading date on or after March 15 and September 15 of each year. Participants may purchase shares of common stock through payroll deductions of up to 15% of their eligible compensation, subject to purchase limits of 625 shares during a six month period or $25,000 worth of stock for each calendar year.

[0001327567-15-000027:notes:160]
A total of 1.8 million shares of our common stock are available for sale under our 2012 ESPP as of July 31, 2015. On the first day of each fiscal year, the number of shares in the reserve may be increased by the lesser of (i) 2,000,000 shares, (ii) 1% of the outstanding shares of our common stock on the first day of the fiscal year, or (iii) such other amount as determined by our board of directors.

[0001327567-15-000027:notes:161]
Stock Option Activities

[0001327567-15-000027:notes:162]
A summary of the activity under our stock plans during the reporting period and a summary of information related to options exercisable, vested, and expected to vest are presented below (in thousands, except per share amounts):

[0001327567-15-000027:notes:163]
|  | Options Outstanding |
|  | Number ofShares |  | Weighted- Average Exercise Price Per Share |  | Weighted- Average Remaining Contractual Term (Years) |  | Aggregate Intrinsic Value |
| Balance—July 31, 2014 | 5,830 |  |  | $ | 13.02 |  |  | 7.0 |  | $ | 395,507 |  |
| Options granted | — |  |  | — |  |  |  |  |  |
| Options forfeited | (54 | ) |  | 17.43 |  |  |  |  |  |
| Options exercised | (2,505 | ) |  | 11.99 |  |  |  |  |  |
| Balance—July 31, 2015 | 3,271 |  |  | $ | 13.74 |  |  | 6.2 |  | $ | 562,906 |  |
| Options vested and expected to vest—July 31, 2015 | 3,254 |  |  | $ | 13.70 |  |  | 6.1 |  | $ | 560,111 |  |
| Options exercisable—July 31, 2015 | 2,578 |  |  | $ | 12.13 |  |  | 6.1 |  | $ | 447,799 |  |

[0001327567-15-000027:notes:164]
The weighted-average grant-date fair value of options granted during the year ended July 31, 2013 was $26.09. The intrinsic value of options exercised during the years ended July 31, 2015, 2014, and 2013 was $301.1 million, $198.8 million, and $186.8 million, respectively. The grant-date fair value of options vested during the years ended July 31, 2015, 2014, and 2013 was $14.6 million, $17.1 million, and $21.4 million, respectively.

[0001327567-15-000027:notes:165]
RSU Activities

[0001327567-15-000027:notes:166]
A summary of the activity under our stock plans during the reporting period and a summary of information related to RSUs vested and expected to vest are presented below (in thousands, except per share amounts):

[0001327567-15-000027:notes:167]
|  | RSUs Outstanding |
|  | Number of Shares |  | Weighted- Average Grant-Date Fair Value Per Share |  | Weighted- Average Remaining Contractual Term (Years) |  | Aggregate Intrinsic Value |
| Balance—July 31, 2014 | 6,046 |  |  | $ | 59.84 |  |  | 1.4 |  | $ | 488,880 |  |
| RSUs granted | 4,142 |  |  | 122.36 |  |  |  |  |  |
| RSUs vested | (2,511 | ) |  | 58.40 |  |  |  |  |  |
| RSUs forfeited | (494 | ) |  | 70.55 |  |  |  |  |  |
| Balance—July 31, 2015 | 7,183 |  |  | $ | 95.66 |  |  | 1.2 |  | $ | 1,334,817 |  |
| RSUs vested and expected to vest—July 31, 2015 | 6,582 |  |  | $ | 94.90 |  |  | 1.2 |  | $ | 1,223,133 |  |

[0001327567-15-000027:notes:168]
The weighted-average grant-date fair value of RSUs granted during the years ended July 31, 2015, 2014, and 2013 was $122.36, $61.00, and $54.51, respectively. The aggregate fair value, as of the respective vesting dates, of RSUs vested during the years ended July 31, 2015, 2014, and 2013 was $350.4 million, $57.4 million, and $0.3 million, respectively.

[0001327567-15-000027:notes:169]
Shares Available for Grant

[0001327567-15-000027:notes:170]
Employee Stock Purchase Plan

[0001327567-15-000027:notes:171]
We recognized compensation expense of $6.7 million, $4.5 million, and $5.3 million in connection with our 2012 ESPP during the years ended July 31, 2015, 2014, and 2013, respectively. Employees purchased 0.2 million shares of common stock at an average exercise price of $75.09 per share during the year ended July 31, 2015.

[0001327567-15-000027:notes:172]
We record share-based compensation awards based on fair value as of the grant date. For option awards and ESPP offerings we use the Black-Scholes option-pricing model to determine fair value. We recognize such costs as compensation expense on a straight-line basis over the requisite service period of the award. The assumptions for our option-pricing model are determined as follows:

[0001327567-15-000027:notes:173]
Risk-Free Interest Rate

[0001327567-15-000027:notes:174]
We base the risk-free interest rate used in the Black-Scholes valuation model on the implied yield available on U.S. Treasury zero-coupon issues with an equivalent remaining term of the options for each option group or the term of our 2012 ESPP offering.

[0001327567-15-000027:notes:175]
Expected Term

[0001327567-15-000027:notes:176]
The expected term represents the period that our share-based awards are expected to be outstanding. We determined the expected term assumption based on the contractual term of the options adjusted for estimates of our employees' expected exercise and expected post-vesting termination behavior. For our 2012 ESPP, the expected term is based on the length of the offering period.

[0001327567-15-000027:notes:177]
Volatility

[0001327567-15-000027:notes:178]
Beginning in fiscal 2014, we determine the price volatility factor based on the historical volatility of our common stock. Prior to fiscal 2014, we determined the price volatility factor based on the historical volatilities of our peer group as we did not have sufficient trading history for our common stock.

[0001327567-15-000027:notes:179]
Dividend Yield

[0001327567-15-000027:notes:180]
The expected dividend assumption is based on our current expectations about our anticipated dividend policy.

[0001327567-15-000027:notes:181]
The following table summarizes the assumptions related to our stock options:

[0001327567-15-000027:notes:182]
|  | Year Ended July 31, 2013 |
| Risk-free interest rate | 1.0% |
| Expected term | 6 years |
| Volatility | 50% |
| Dividend yield | —% |

[0001327567-15-000027:notes:183]
The following table summarizes the assumptions related to our 2012 ESPP:

[0001327567-15-000027:notes:184]
|  | Year Ended July 31, |
|  | 2015 |  | 2014 |  | 2013 |
| Risk-free interest rate | 0.1% |  | 0.1% |  | 0.1% |
| Expected term | < 1 year |  | < 1 year |  | < 1 year |
| Volatility | 40% |  | 40% |  | 42% |
| Dividend yield | —% |  | —% |  | —% |

[0001327567-15-000027:notes:185]
The following table summarizes share-based compensation included in costs and expenses (in thousands):

[0001327567-15-000027:notes:186]
|  | Year Ended July 31, |
|  | 2015 |  | 2014 |  | 2013 |
| Cost of product revenue | $ | 3,858 |  |  | $ | 1,636 |  |  | $ | 765 |  |
| Cost of services revenue | 20,425 |  |  | 9,434 |  |  | 3,586 |  |
| Research and development | 74,837 |  |  | 29,524 |  |  | 9,931 |  |
| Sales and marketing | 84,113 |  |  | 42,647 |  |  | 20,493 |  |
| General and administrative | 38,198 |  |  | 16,668 |  |  | 9,101 |  |
| Total share-based compensation | $ | 221,431 |  |  | $ | 99,909 |  |  | $ | 43,876 |  |

[0001327567-15-000027:notes:187]
At July 31, 2015, total compensation cost related to unvested share-based awards granted but not yet recognized was $557.0 million, net of estimated forfeitures. This cost is expected to be amortized on a straight-line basis over a weighted-average period of three years. Future grants will increase the amount of compensation expense to be recorded in these periods.

[0001327567-15-000027:notes:188]
For the year ended July 31, 2014, we accelerated the vesting of certain share-based awards in connection with our acquisitions of Morta and Cyvera and as a result, we recorded $3.4 million of compensation expense within general and administrative expense. For the year ended July 31, 2013, we modified the terms of certain share-based awards for a former employee and as a result, we recorded $1.9 million of compensation expense within sales and marketing expense.


## us-gaap:EarningsPerShareTextBlock

[0001327567-15-000027:notes:189]
Net Income (Loss) Per Share

[0001327567-15-000027:notes:190]
Basic net income (loss) per share is computed by dividing net income (loss) by basic weighted-average shares outstanding during the period. Diluted net income (loss) per share is computed by dividing net income (loss) by diluted weighted-average shares outstanding, including potentially dilutive securities.

[0001327567-15-000027:notes:191]
The following table presents the computation of basic and diluted net loss per share of common stock (in thousands, except per share data):

[0001327567-15-000027:notes:192]
|  | Year Ended July 31, |
|  | 2015 |  | 2014 |  | 2013 |
| Net loss | $ | (164,982 | ) |  | $ | (226,452 | ) |  | $ | (29,246 | ) |
| Weighted-average shares used to compute net loss per share, basic and diluted | 81,619 |  |  | 74,291 |  |  | 68,682 |  |
| Net loss per share, basic and diluted | $ | (2.02 | ) |  | $ | (3.05 | ) |  | $ | (0.43 | ) |

[0001327567-15-000027:notes:193]
The following securities were excluded from the computation of diluted net loss per share of common stock for the periods presented as their effect would have been antidilutive (in thousands):

[0001327567-15-000027:notes:194]
|  | Year Ended July 31, |
|  | 2015 |  | 2014 |  | 2013 |
| Options | 3,271 |  |  | 5,830 |  |  | 10,033 |  |
| RSUs | 7,183 |  |  | 6,046 |  |  | 2,241 |  |
| ESPP shares | 78 |  |  | 95 |  |  | 114 |  |
| Convertible senior notes | 5,214 |  |  | 5,214 |  |  | — |  |
| Warrants related to the issuance of convertible senior notes | 5,214 |  |  | 5,214 |  |  | — |  |
| Total | 20,960 |  |  | 22,399 |  |  | 12,388 |  |


## us-gaap:FairValueAssetsAndLiabilitiesMeasuredOnRecurringAndNonrecurringBasisTableTextBlock

[0001327567-15-000027:notes:195]
The following table presents the fair value of our financial assets and liabilities using the above input categories as of July 31, 2015 and July 31, 2014 (in thousands):

[0001327567-15-000027:notes:196]
|  |  | July 31, 2015 |  | July 31, 2014 |
|  |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Short-term investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Certificates of deposit |  | $ | — |  |  | $ | 1,000 |  |  | $ | — |  |  | $ | 1,000 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Corporate debt securities |  | — |  |  | 97,825 |  |  | — |  |  | 97,825 |  |  | — |  |  | 22,239 |  |  | — |  |  | 22,239 |  |
| U.S. government and agency securities |  | — |  |  | 314,340 |  |  | — |  |  | 314,340 |  |  | — |  |  | 96,451 |  |  | — |  |  | 96,451 |  |
| Total short-term investments |  | — |  |  | 413,165 |  |  | — |  |  | 413,165 |  |  | — |  |  | 118,690 |  |  | — |  |  | 118,690 |  |
| Long-term investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Certificates of deposit |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 1,000 |  |  | — |  |  | 1,000 |  |
| Corporate debt securities |  | — |  |  | 92,902 |  |  | — |  |  | 92,902 |  |  | — |  |  | 39,018 |  |  | — |  |  | 39,018 |  |
| U.S. government and agency securities |  | — |  |  | 445,939 |  |  | — |  |  | 445,939 |  |  | — |  |  | 161,862 |  |  | — |  |  | 161,862 |  |
| Total long-term investments |  | — |  |  | 538,841 |  |  | — |  |  | 538,841 |  |  | — |  |  | 201,880 |  |  | — |  |  | 201,880 |  |
| Other assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Certificates of deposit |  | — |  |  | — |  |  | — |  |  | — |  |  | 1,220 |  |  | — |  |  | — |  |  | 1,220 |  |
| Total other assets |  | — |  |  | — |  |  | — |  |  | — |  |  | 1,220 |  |  | — |  |  | — |  |  | 1,220 |  |
| Total assets measured at fair value |  | $ | — |  |  | $ | 952,006 |  |  | $ | — |  |  | $ | 952,006 |  |  | $ | 1,220 |  |  | $ | 320,570 |  |  | $ | — |  |  | $ | 321,790 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001327567-15-000027:notes:197]
Fair Value Measurements

[0001327567-15-000027:notes:198]
We categorize assets and liabilities recorded at fair value on our consolidated balance sheets based upon the level of judgment associated with inputs used to measure their fair value. The categories are as follows:

[0001327567-15-000027:notes:199]
| • | Level 1—Inputs are unadjusted quoted prices in active markets for identical assets or liabilities. |

[0001327567-15-000027:notes:200]
| • | Level 2—Inputs are quoted prices for similar assets and liabilities in active markets or inputs that are observable for the assets or liabilities, either directly or indirectly through market corroboration, for substantially the full term of the financial instruments. |

[0001327567-15-000027:notes:201]
| • | Level 3—Inputs are unobservable inputs based on our own assumptions used to measure assets and liabilities at fair value. The inputs require significant management judgment or estimation. |

[0001327567-15-000027:notes:202]
Refer to Note 7. Convertible Senior Notes for the carrying amount and estimated fair value of our convertible senior notes as of July 31, 2015.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001327567-15-000027:notes:203]
Goodwill and Intangible Assets

[0001327567-15-000027:notes:204]
Goodwill

[0001327567-15-000027:notes:205]
The following table presents the changes in the carrying amount of goodwill during the years ended July 31, 2015 and 2014 (in thousands):

[0001327567-15-000027:notes:206]
|  | Amount |
| Balance as of July 31, 2013 | $ | — |  |
| Goodwill acquired | 155,033 |  |
| Balance as of July 31, 2014 | 155,033 |  |
| Goodwill acquired | 8,120 |  |
| Measurement period adjustments | 369 |  |
| Balance as of July 31, 2015 | $ | 163,522 |  |

[0001327567-15-000027:notes:207]
There was no impairment of goodwill during the years ended July 31, 2015 and 2014.

[0001327567-15-000027:notes:208]
Purchased Intangible Assets

[0001327567-15-000027:notes:209]
The following table presents details of our purchased intangible assets as of July 31, 2015 and July 31, 2014 (in thousands):

[0001327567-15-000027:notes:210]
|  | July 31, |
|  | 2015 |  | 2014 |
|  | Gross Carrying Amount |  | Accumulated Amortization |  | Net Carrying Amount |  | Gross Carrying Amount |  | Accumulated Amortization |  | Net Carrying Amount |
| Intangible assets with finite lives: |  |  |  |  |  |  |  |  |  |  |  |
| Developed technology | $ | 53,100 |  |  | $ | (7,738 | ) |  | $ | 45,362 |  |  | $ | 34,500 |  |  | $ | (1,643 | ) |  | $ | 32,857 |  |
| Acquired intellectual property | 8,156 |  |  | (1,888 | ) |  | 6,268 |  |  | 6,546 |  |  | (958 | ) |  | 5,588 |  |
| In-process research and development held for defensive purposes | 1,900 |  |  | (1,003 | ) |  | 897 |  |  | 1,900 |  |  | (370 | ) |  | 1,530 |  |
| Other | 500 |  |  | (371 | ) |  | 129 |  |  | 500 |  |  | (120 | ) |  | 380 |  |
| Total intangible assets with finite lives | 63,656 |  |  | (11,000 | ) |  | 52,656 |  |  | 43,446 |  |  | (3,091 | ) |  | 40,355 |  |
| In-process research and development with indefinite lives | — |  |  | — |  |  | — |  |  | 7,600 |  |  | — |  |  | 7,600 |  |
| Total purchased intangible assets | $ | 63,656 |  |  | $ | (11,000 | ) |  | $ | 52,656 |  |  | $ | 51,046 |  |  | $ | (3,091 | ) |  | $ | 47,955 |  |

[0001327567-15-000027:notes:211]
We recognized amortization expense of $7.9 million, $2.9 million, and $0.1 million for the years ended July 31, 2015, 2014, and 2013, respectively. Our in-process research and development acquired from Cyvera in April 2014 was transferred to developed technology during the year ended July 31, 2015 and is being amortized over its estimated useful life of seven years.

[0001327567-15-000027:notes:212]
The following table summarizes our estimated future amortization expense of intangible assets with finite lives by type as of July 31, 2015 (in thousands):

[0001327567-15-000027:notes:213]
|  | Fiscal Years Ending July 31, |
|  | 2016 |  | 2017 |  | 2018 |  | 2019 |  | 2020 |  | 2021 and Thereafter |
| Developed technology | $ | 7,586 |  |  | $ | 7,586 |  |  | $ | 7,586 |  |  | $ | 7,586 |  |  | $ | 7,586 |  |  | $ | 7,432 |  |
| Acquired intellectual property | 947 |  |  | 853 |  |  | 617 |  |  | 511 |  |  | 485 |  |  | 2,855 |  |
| In-process research and development held for defensive purposes | 633 |  |  | 264 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Other | 129 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Total future amortization expense | $ | 9,295 |  |  | $ | 8,703 |  |  | $ | 8,203 |  |  | $ | 8,097 |  |  | $ | 8,071 |  |  | $ | 10,287 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001327567-15-000027:notes:214]
The following table presents the components of income (loss) before income taxes (in thousands):

[0001327567-15-000027:notes:215]
|  | Year Ended July 31, |
|  | 2015 |  | 2014 |  | 2013 |
| United States | $ | (47,493 | ) |  | $ | (149,243 | ) |  | $ | 5,198 |  |
| Foreign | (108,084 | ) |  | (72,917 | ) |  | (23,854 | ) |
| Total | $ | (155,577 | ) |  | $ | (222,160 | ) |  | $ | (18,656 | ) |

[0001327567-15-000027:notes:216]
The following table summarizes the provision for income taxes (in thousands):

[0001327567-15-000027:notes:217]
|  | Year Ended July 31, |
|  | 2015 |  | 2014 |  | 2013 |
| Federal: |  |  |  |  |  |
| Current | $ | 1,757 |  |  | $ | 795 |  |  | $ | 5,883 |  |
| Deferred | (2,972 | ) |  | — |  |  | — |  |
| State: |  |  |  |  |  |
| Current | 682 |  |  | 230 |  |  | 1,758 |  |
| Deferred | (431 | ) |  | (324 | ) |  | — |  |
| Foreign: |  |  |  |  |  |
| Current | 10,738 |  |  | 4,679 |  |  | 3,296 |  |
| Deferred | (369 | ) |  | (1,088 | ) |  | (347 | ) |
| Total | $ | 9,405 |  |  | $ | 4,292 |  |  | $ | 10,590 |  |

[0001327567-15-000027:notes:218]
The following table presents the items accounting for the difference between income taxes computed at the federal statutory income tax rate and the provision for income taxes:

[0001327567-15-000027:notes:219]
|  | Year Ended July 31, |
|  | 2015 |  | 2014 |  | 2013 |
| Federal statutory rate | 35.0 | % |  | 35.0 | % |  | 35.0 | % |
| Effect of: |  |  |  |  |  |
| State taxes, net of federal tax benefit | 3.6 |  |  | 1.3 |  |  | 1.0 |  |
| Foreign income at other than U.S. rates | (6.5 | ) |  | (12.1 | ) |  | (62.4 | ) |
| Change in valuation allowance | (28.5 | ) |  | (21.3 | ) |  | (32.5 | ) |
| Share-based compensation | (10.2 | ) |  | (3.2 | ) |  | (16.1 | ) |
| Meals and entertainment | (0.6 | ) |  | (0.3 | ) |  | (2.0 | ) |
| Amortization of deferred tax charges | (2.2 | ) |  | — |  |  | — |  |
| Research credits | 6.7 |  |  | 1.3 |  |  | 25.2 |  |
| Other, net | (3.3 | ) |  | (2.6 | ) |  | (5.0 | ) |
| Total | (6.0 | )% |  | (1.9 | )% |  | (56.8 | )% |

[0001327567-15-000027:notes:220]
During the year ended July 31, 2015, we completed several changes to our corporate structure to more closely align with the global nature of our business. As a result, we recorded deferred tax charges in prepaid expenses and other current assets and other assets on our consolidated balance sheets. These amounts are being amortized on a straight-line basis over the life of the associated assets as a component of provision for income taxes in our consolidated statements of operations.

[0001327567-15-000027:notes:221]
The following table presents the components of our deferred tax assets and liabilities as of July 31, 2015 and July 31, 2014 (in thousands):

[0001327567-15-000027:notes:222]
|  | July 31, |
|  | 2015 |  | 2014 |
| Deferred tax assets: |  |  |  |
| Accruals and reserves | $ | 38,936 |  |  | $ | 7,942 |  |
| Deferred revenue | 35,261 |  |  | 30,430 |  |
| Research and development and foreign tax credits | 20,123 |  |  | 8,741 |  |
| Net operating loss carryforwards | 18,376 |  |  | 32,282 |  |
| Share-based compensation | 35,893 |  |  | 17,715 |  |
| Gross deferred tax assets | 148,589 |  |  | 97,110 |  |
| Valuation allowance | (138,354 | ) |  | (89,309 | ) |
| Total deferred tax assets | 10,235 |  |  | 7,801 |  |
| Deferred tax liabilities: |  |  |  |
| Fixed assets and intangible assets | (7,919 | ) |  | (15,040 | ) |
| Other deferred tax liabilities | (1,631 | ) |  | (565 | ) |
| Total deferred tax liabilities | (9,550 | ) |  | (15,605 | ) |
| Total | $ | 685 |  |  | $ | (7,804 | ) |

[0001327567-15-000027:notes:223]
A valuation allowance is provided when it is more likely than not that the deferred tax asset will not be realized. Realization of deferred tax assets is dependent upon future taxable income, if any, the amount and timing of which are uncertain. At such time, if it is determined that it is more likely than not that the deferred tax assets are realizable, the valuation allowance will be adjusted. As of July 31, 2015, we have provided a valuation allowance for our federal, state, and certain foreign deferred tax assets that we believe will, more likely than not, be unrealizable. The net valuation allowance increased by approximately $49.0 million from the year ended July 31, 2014 to the year ended July 31, 2015, which was primarily attributable to an increase in deferred tax assets in our federal and state jurisdictions.

[0001327567-15-000027:notes:224]
Due to our acquisition of CirroSecure, a deferred tax liability was established for the book-tax basis difference related to purchased intangibles. The net deferred tax liability from acquisitions provided an additional source of income to support the realizability of our pre-existing deferred tax assets and as a result, we released a portion of the valuation allowance that was established in the previous year and recorded a tax benefit of $3.4 million for the year ended July 31, 2015.

[0001327567-15-000027:notes:225]
As of July 31, 2015, we had federal, state, and foreign NOL carryforwards of approximately $752.9 million, $808.5 million, and $12.5 million, respectively as reported on our tax returns, available to reduce future taxable income, if any. If not utilized, our federal and state NOL carryforwards will expire in various amounts from the years ending July 31, 2027 through 2035 and July 31, 2017 through 2035, respectively. Our foreign NOL will carry forward indefinitely.

[0001327567-15-000027:notes:226]
As of July 31, 2015, we had federal and state research and development tax credit carryforwards of approximately $17.2 million and $21.8 million, respectively as reported on our tax returns. If not utilized, the federal credit carryforwards will expire in various amounts from the years ending July 31, 2026 through 2035. The state credit will carry forward indefinitely.

[0001327567-15-000027:notes:227]
As of July 31, 2015, we had foreign tax credit carryforwards of $1.1 million as reported on our tax returns. If not utilized, the foreign tax credit carryforwards will expire in various amounts from the years ending July 31, 2021 through 2025.

[0001327567-15-000027:notes:228]
Utilization of the NOL carryforwards and credits may be subject to a substantial annual limitation due to the ownership change limitations provided by the Internal Revenue Code of 1986, as amended, and similar state provisions. The annual limitation may result in the expiration of NOLs and credits before utilization.

[0001327567-15-000027:notes:229]
We use the with-and-without approach to determine the recognition and measurement of excess tax benefits resulting from share-based awards. Accordingly, we have elected to recognize excess income tax benefits from share-based awards in additional paid-in capital only if an incremental income tax benefit would be realized after considering all other tax attributes presently available to us. As of July 31, 2015, we had excess tax benefits from share-based awards of $680.7 million, $648.2 million, and $12.5 million included in federal, state, and foreign NOL, respectively. We also had $5.3 million of excess tax benefits from share-based awards included in federal research and development tax credit. The impact of this excess tax benefit is recognized as additional paid-in capital when it reduces taxes payable. We have elected to account for the indirect effects of share-based awards on other tax attributes, such as the research, foreign and other tax credits, through the consolidated statements of operations.

[0001327567-15-000027:notes:230]
During the years ended July 31, 2015, 2014, and 2013, we recorded excess tax benefits that resulted from allocating certain tax effects related to exercises of stock options and vesting of RSUs directly to stockholders’ equity in the amount of $2.5 million, $1.0 million, and $6.8 million, respectively.

[0001327567-15-000027:notes:231]
In December 2014, the Tax Increase Prevention Act of 2014 was signed into law, which retroactively extends the federal research and development credit, bonus depreciation, and other corporate tax incentives through December 31, 2014. Due to the valuation allowance against our domestic deferred tax assets, we did not recognize any discrete tax benefits during the year ended July 31, 2015 as a result of the legislation.

[0001327567-15-000027:notes:232]
As of July 31, 2015, we had $67.2 million of unrecognized tax benefits, $10.8 million of which would affect income tax expense if recognized, after consideration of our valuation allowance in the United States and other assets. As of July 31, 2014, we had $10.4 million of unrecognized tax benefits, $3.9 million of which would affect income tax expense if recognized, after consideration of our valuation allowance in the United States. As of July 31, 2015, our federal, state, and foreign returns for the tax years 2008 through the current period remain open to examination. Fiscal years outside the normal statute of limitation remain open to audit by tax authorities due to tax attributes generated in earlier years, which have been carried forward and may be audited in subsequent years when utilized. We do not expect the amount of unrecognized tax benefits as of July 31, 2015 to change significantly over the next 12 months. We recognize both interest and penalties associated with uncertain tax positions as a component of income tax expense. During the years ended July 31, 2015, 2014, and 2013, we recognized income tax expense related to interest and penalties of $1.1 million, $0.3 million, and $0.2 million, respectively. We had accrued interest and penalties on our consolidated balance sheets related to unrecognized tax benefits of $1.8 million and $0.6 million as of July 31, 2015 and 2014, respectively. The ultimate amount and timing of any future cash settlements cannot be predicted with reasonable certainty.

[0001327567-15-000027:notes:233]
The following table presents a reconciliation of the beginning and ending amount of our gross unrecognized tax benefits (in thousands):

[0001327567-15-000027:notes:234]
|  | Year Ended July 31, |
|  | 2015 |  | 2014 |  | 2013 |
| Unrecognized tax benefits at the beginning of the period | $ | 10,385 |  |  | $ | 6,561 |  |  | $ | 2,630 |  |
| Additions for tax positions taken in prior years | 6,061 |  |  | 428 |  |  | 585 |  |
| Reductions for tax positions taken in prior years | (612 | ) |  | — |  |  | (3 | ) |
| Additions for tax positions taken in the current year | 51,324 |  |  | 3,396 |  |  | 3,349 |  |
| Unrecognized tax benefits at the end of the period | $ | 67,158 |  |  | $ | 10,385 |  |  | $ | 6,561 |  |

[0001327567-15-000027:notes:235]
As of July 31, 2015, we had approximately $7.0 million of undistributed earnings in foreign subsidiaries. We expect to permanently reinvest these earnings outside of the United States to fund future foreign operations. We project that we will have sufficient cash flow in the United States and will not need to repatriate the foreign earnings to finance our domestic operations. If we were to distribute these earnings to the United States, we would be subject to U.S. income taxes, an adjustment for foreign tax credits, and foreign withholding taxes. We have not recorded a deferred tax liability on any portion of our undistributed earnings in foreign subsidiaries. If we were to repatriate these earnings to the United States, any associated income tax liability would be insignificant.


## us-gaap:InvestmentsClassifiedByContractualMaturityDateTableTextBlock

[0001327567-15-000027:notes:236]
The following table summarizes the amortized cost and fair value of our investments as of July 31, 2015, by contractual years-to-maturity (in thousands):

[0001327567-15-000027:notes:237]
|  | Amortized Cost |  | Fair Value |
| Due within one year | $ | 413,148 |  |  | $ | 413,165 |  |
| Due between one and three years | 538,946 |  |  | 538,841 |  |
| Total | $ | 952,094 |  |  | $ | 952,006 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001327567-15-000027:notes:238]
Unrealized losses related to these investments are due to interest rate fluctuations as opposed to credit quality. In addition, we do not intend to sell and it is not likely that we would be required to sell these investments before recovery of their amortized cost basis, which may be at maturity. As a result, there is no other-than-temporary impairment for these investments at July 31, 2015 and 2014.

[0001327567-15-000027:notes:239]
We received proceeds of $18.5 million, $74.6 million, and $13.5 million from sales of investments during the years ended July 31, 2015, 2014, and 2013, respectively. We use the specific identification method to determine the cost basis of investments sold.


## us-gaap:LegalMattersAndContingenciesTextBlock

[0001327567-15-000027:notes:240]
Legal Settlement

[0001327567-15-000027:notes:241]
Settlement, Release and Cross-License Agreement with Juniper

[0001327567-15-000027:notes:242]
On May 27, 2014, we entered into the Settlement Agreement with Juniper, whereby we resolved all pending litigation matters. Under the terms of the Settlement Agreement, we agreed to pay Juniper a one-time settlement amount comprised of $75.0 million in cash, 1.1 million shares of our common stock, and a warrant to purchase 0.5 million shares of our common stock, in exchange for the following:

[0001327567-15-000027:notes:243]
| • | Mutual dismissal with prejudice of all pending litigation between the parties and general release of all liability for Palo Alto Networks and Juniper, |

[0001327567-15-000027:notes:244]
| • | Cross-license between both parties for the patents-in-suit and associated family members and counterparts worldwide for the life of the patents, and |

[0001327567-15-000027:notes:245]
| • | Mutual covenant not to sue for infringement of any other patents for a period of eight years. |

[0001327567-15-000027:notes:246]
The fair value of the total consideration as of the settlement date was $182.5 million, which was comprised of $75.0 million in cash, $75.2 million in common stock, and $32.2 million in warrant. The fair values of the common stock and warrant were measured using the closing price of our common stock on the settlement date.

[0001327567-15-000027:notes:247]
The warrant was issued on June 3, 2014 and entitled Juniper to purchase up to 0.5 million shares of common stock at an exercise price of $0.0001 per share and was classified as a liability during the period it was outstanding. On July 1, 2014, Juniper exercised the warrant in full. Accordingly, we recorded the change in the fair value of the warrant liability through the exercise date of $5.9 million within other income (expense), net in our consolidated statement of operations for the year ended July 31, 2014.

[0001327567-15-000027:notes:248]
We accounted for the Settlement Agreement as a multiple-element arrangement and allocated the fair value of the consideration as of the settlement date to the identifiable elements based on their estimated fair values. Of the total settlement amount, $61.3 million was allocated to the licensing of intellectual property, $54.3 million was allocated to the mutual dismissal of claims, and the remaining amount was allocated to the mutual covenant not to sue. The mutual dismissal of claims and the mutual covenant not to sue have no identifiable future benefit, and as a result we recorded a settlement charge within legal settlement expense in our consolidated statement of operations for the year ended July 31, 2014. The licensing of intellectual property is being amortized to cost of product revenue in our consolidated statements of operations over the estimated period of benefit of five years.

[0001327567-15-000027:notes:249]
Mutual Covenant Not to Sue and Release Agreement

[0001327567-15-000027:notes:250]
On January 27, 2014, we executed a Mutual Covenant Not to Sue and Release Agreement with Fortinet, Inc., thereby extending an existing covenant for six more years. We evaluated the transaction as a multiple-element arrangement and allocated the one-time payment that we made in the amount of $20.0 million to each identifiable element using its relative fair value. Based on our estimates of fair value, we determined that the primary benefit of the arrangement is avoided litigation cost and the release of any potential past claims, with no material value attributable to future use or benefit. Accordingly, we recorded a $20.0 million settlement charge within legal settlement expense in our consolidated statement of operations for the year ended July 31, 2014.


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001327567-15-000027:notes:251]
The following table presents details of property and equipment, net as of July 31, 2015 and July 31, 2014 (in thousands):

[0001327567-15-000027:notes:252]
|  | July 31, |
|  | 2015 |  | 2014 |
| Computers, equipment, and software | $ | 62,599 |  |  | $ | 38,147 |  |
| Leasehold improvements | 25,461 |  |  | 21,258 |  |
| Demonstration units | 15,971 |  |  | 14,832 |  |
| Furniture and fixtures | 6,631 |  |  | 5,129 |  |
| Total property and equipment | 110,662 |  |  | 79,366 |  |
| Less: accumulated depreciation | (47,784 | ) |  | (30,622 | ) |
| Total property and equipment, net | $ | 62,878 |  |  | $ | 48,744 |  |

[0001327567-15-000027:notes:253]
We recognized depreciation expense of $20.3 million, $14.0 million, and $9.8 million related to property and equipment during the years ended July 31, 2015, 2014, and 2013, respectively.


## us-gaap:QuarterlyFinancialInformationTextBlock

[0001327567-15-000027:notes:254]
Selected Quarterly Financial Data (Unaudited)

[0001327567-15-000027:notes:255]
The following tables set forth selected unaudited financial data for the years ended July 31, 2015 and 2014 (in thousands, except per share amounts):

[0001327567-15-000027:notes:256]
|  | Three Months Ended |
|  | Oct. 31,2014 |  | Jan. 31,2015 |  | Apr. 30,2015 |  | Jul. 31,2015 |
| Revenue: |  |  |  |  |  |  |  |
| Product | $ | 101,476 |  |  | $ | 115,621 |  |  | $ | 121,524 |  |  | $ | 154,037 |  |
| Services | 90,870 |  |  | 102,034 |  |  | 112,648 |  |  | 129,842 |  |
| Total revenue | 192,346 |  |  | 217,655 |  |  | 234,172 |  |  | 283,879 |  |
| Cost of revenue: |  |  |  |  |  |  |  |
| Product | 29,141 |  |  | 30,640 |  |  | 32,851 |  |  | 38,462 |  |
| Services | 24,320 |  |  | 28,685 |  |  | 31,544 |  |  | 35,856 |  |
| Total cost of revenue | 53,461 |  |  | 59,325 |  |  | 64,395 |  |  | 74,318 |  |
| Total gross profit | 138,885 |  |  | 158,330 |  |  | 169,777 |  |  | 209,561 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 37,305 |  |  | 46,948 |  |  | 48,486 |  |  | 53,089 |  |
| Sales and marketing | 106,366 |  |  | 122,875 |  |  | 131,026 |  |  | 162,429 |  |
| General and administrative | 18,977 |  |  | 27,023 |  |  | 26,989 |  |  | 28,576 |  |
| Total operating expenses | 162,648 |  |  | 196,846 |  |  | 206,501 |  |  | 244,094 |  |
| Operating loss | (23,763 | ) |  | (38,516 | ) |  | (36,724 | ) |  | (34,533 | ) |
| Interest expense | (5,489 | ) |  | (5,539 | ) |  | (5,631 | ) |  | (5,666 | ) |
| Other income (expense), net | 341 |  |  | 344 |  |  | (55 | ) |  | (346 | ) |
| Loss before income taxes | (28,911 | ) |  | (43,711 | ) |  | (42,410 | ) |  | (40,545 | ) |
| Provision for (benefit from) income taxes | 1,157 |  |  | (703 | ) |  | 3,525 |  |  | 5,426 |  |
| Net loss | $ | (30,068 | ) |  | $ | (43,008 | ) |  | $ | (45,935 | ) |  | $ | (45,971 | ) |
| Net loss per share, basic and diluted | $ | (0.38 | ) |  | $ | (0.53 | ) |  | $ | (0.56 | ) |  | $ | (0.55 | ) |

[0001327567-15-000027:notes:257]
|  | Three Months Ended |
|  | Oct. 31,2013 |  | Jan. 31,2014 |  | Apr. 30,2014 |  | Jul. 31,2014 |
| Revenue: |  |  |  |  |  |  |  |
| Product | $ | 75,485 |  |  | $ | 80,823 |  |  | $ | 84,128 |  |  | $ | 99,707 |  |
| Services | 52,695 |  |  | 60,245 |  |  | 66,572 |  |  | 78,524 |  |
| Total revenue | 128,180 |  |  | 141,068 |  |  | 150,700 |  |  | 178,231 |  |
| Cost of revenue: |  |  |  |  |  |  |  |
| Product | 17,954 |  |  | 20,221 |  |  | 20,425 |  |  | 26,903 |  |
| Services | 15,853 |  |  | 17,283 |  |  | 19,285 |  |  | 21,704 |  |
| Total cost of revenue | 33,807 |  |  | 37,504 |  |  | 39,710 |  |  | 48,607 |  |
| Total gross profit | 94,373 |  |  | 103,564 |  |  | 110,990 |  |  | 129,624 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 19,893 |  |  | 24,253 |  |  | 27,837 |  |  | 32,830 |  |
| Sales and marketing | 67,366 |  |  | 76,734 |  |  | 83,995 |  |  | 106,668 |  |
| General and administrative | 14,125 |  |  | 19,733 |  |  | 23,717 |  |  | 15,574 |  |
| Legal settlement (Note 9) | — |  |  | 20,000 |  |  | 121,173 |  |  | — |  |
| Total operating expenses | 101,384 |  |  | 140,720 |  |  | 256,722 |  |  | 155,072 |  |
| Operating loss | (7,011 | ) |  | (37,156 | ) |  | (145,732 | ) |  | (25,448 | ) |
| Interest expense | (8 | ) |  | (14 | ) |  | (13 | ) |  | (1,848 | ) |
| Other income (expense), net | 405 |  |  | (170 | ) |  | 430 |  |  | (5,595 | ) |
| Loss before income taxes | (6,614 | ) |  | (37,340 | ) |  | (145,315 | ) |  | (32,891 | ) |
| Provision for (benefit from) income taxes | 1,247 |  |  | 2,606 |  |  | 1,272 |  |  | (833 | ) |
| Net loss | $ | (7,861 | ) |  | $ | (39,946 | ) |  | $ | (146,587 | ) |  | $ | (32,058 | ) |
| Net loss per share, basic and diluted | $ | (0.11 | ) |  | $ | (0.55 | ) |  | $ | (1.96 | ) |  | $ | (0.41 | ) |


## us-gaap:RevenueFromExternalCustomersByGeographicAreasTableTextBlock

[0001327567-15-000027:notes:258]
The following table presents revenue by geographic theater (in thousands):

[0001327567-15-000027:notes:259]
|  | Year Ended July 31, |
|  | 2015 |  | 2014 |  | 2013 |
| Revenue: |  |  |  |  |  |
| Americas |  |  |  |  |  |
| United States | $ | 593,741 |  |  | $ | 363,174 |  |  | $ | 228,604 |  |
| Other Americas | 45,587 |  |  | 33,452 |  |  | 19,012 |  |
| Total Americas | 639,328 |  |  | 396,626 |  |  | 247,616 |  |
| EMEA | 178,719 |  |  | 126,915 |  |  | 91,496 |  |
| APAC | 110,005 |  |  | 74,638 |  |  | 56,995 |  |
| Total revenue | $ | 928,052 |  |  | $ | 598,179 |  |  | $ | 396,107 |  |


## us-gaap:ScheduleOfEntityWideInformationRevenueFromExternalCustomersByProductsAndServicesTextBlock

[0001327567-15-000027:notes:260]
The following table presents revenue for groups of similar products and services (in thousands):

[0001327567-15-000027:notes:261]
|  | Year Ended July 31, |
|  | 2015 |  | 2014 |  | 2013 |
| Revenue: |  |  |  |  |  |
| Product | $ | 492,658 |  |  | $ | 340,143 |  |  | $ | 243,707 |  |
| Services |  |  |  |  |  |
| Subscription | 212,676 |  |  | 123,236 |  |  | 71,203 |  |
| Support and maintenance | 222,718 |  |  | 134,800 |  |  | 81,197 |  |
| Total services | 435,394 |  |  | 258,036 |  |  | 152,400 |  |
| Total revenue | $ | 928,052 |  |  | $ | 598,179 |  |  | $ | 396,107 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001327567-15-000027:notes:262]
Segment Information

[0001327567-15-000027:notes:263]
We conduct business globally and are primarily managed on a geographic theater basis. Our chief operating decision maker reviews financial information presented on a consolidated basis accompanied by information about revenue by geographic region for purposes of allocating resources and evaluating financial performance. We have one business activity and there are no segment managers who are held accountable for operations, operating results, and plans for levels, components, or types of products or services below the consolidated unit level. Accordingly, we are considered to be in a single reportable segment and operating unit structure.

[0001327567-15-000027:notes:264]
Substantially all of our assets were attributable to the Americas operations as of July 31, 2015 and 2014.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001327567-15-000027:notes:265]
Stockholders’ Equity

[0001327567-15-000027:notes:266]
In October 2012, we completed our secondary offering whereby certain stockholders of our company sold 4.8 million shares of common stock to the public at a price of $63.00 per share. The aggregate offering price for shares sold in the offering was approximately $290.3 million, net of underwriting discounts and commissions. We did not receive any proceeds from the sale of shares in this offering. Offering expenses were paid by the stockholders who sold shares of common stock in the offering.
