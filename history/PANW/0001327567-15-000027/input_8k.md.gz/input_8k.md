# PANW 8-K — 0001327567-15-000022 filed 2015-09-09

## item codes, every 8-K on or before 2015-09-17

- 2015-09-09 0001327567-15-000022 — 2.02, 9.01
- 2015-08-19 0001193125-15-296115 — 1.01, 2.03
- 2015-06-01 0001193125-15-207786 — 1.01, 2.03
- 2015-05-27 0001327567-15-000015 — 2.02, 9.01
- 2015-03-02 0001327567-15-000006 — 2.02, 9.01
- 2014-12-15 0001327567-14-000046 — 5.07
- 2014-11-24 0001327567-14-000040 — 2.02, 9.01
- 2014-09-22 0001193125-14-348581 — 5.02, 9.01
- 2014-09-09 0001327567-14-000025 — 2.02, 9.01
- 2014-07-01 0001193125-14-257824 — 1.01, 2.03, 3.02, 9.01
- 2014-06-26 0001193125-14-249529 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2014-06-20 0001327567-14-000020 — 9.01 — amendment of 0001193125-14-140511
- 2014-06-04 0001327567-14-000016 — 3.02
- 2014-05-30 0001193125-14-218158 — 2.02 — amendment, the index does not say of what
- 2014-05-28 0001193125-14-215060 — 1.01, 2.02, 3.02, 9.01
- 2014-04-11 0001193125-14-140511 — 2.01, 3.02, 7.01, 9.01
- 2014-03-24 0001193125-14-111318 — 1.01, 3.02, 7.01, 9.01
- 2014-03-13 0001327567-14-000009 — 5.02
- 2014-02-24 0001193125-14-063754 — 2.02, 9.01
- 2013-12-12 0001327567-13-000040 — 5.07
- 2013-11-25 0001327567-13-000033 — 2.02, 9.01
- 2013-09-30 0001193125-13-384966 — 8.01
- 2013-09-09 0001193125-13-361421 — 2.02, 9.01
- 2013-05-30 0001193125-13-241542 — 2.02, 5.02, 9.01
- 2013-03-11 0001193125-13-101082 — 5.02, 9.01
- 2013-02-28 0001193125-13-084193 — 2.02, 9.01
- 2012-12-14 0001193125-12-503335 — 5.07
- 2012-12-06 0001193125-12-493700 — 2.02, 9.01
- 2012-09-24 0001193125-12-401534 — 1.01, 2.03
- 2012-09-20 0001193125-12-398433 — 5.02, 9.01
- 2012-09-10 0001193125-12-386605 — 2.02, 9.01

## late-filing notifications on or before 2015-09-17

- none on or before 2015-09-17

## item 2.02 — earnings release, exhibit 99.1

[0001327567-15-000022:8k_2_02:1]
EX-99.1
2
ex991q415earningsrelease.htm
EXHIBIT 99.1

[0001327567-15-000022:8k_2_02:2]
Exhibit

[0001327567-15-000022:8k_2_02:3]
Exhibit 99.1

[0001327567-15-000022:8k_2_02:4]
Palo Alto Networks Reports Fiscal Fourth Quarter and Fiscal Year 2015 Financial Results

[0001327567-15-000022:8k_2_02:5]
| • | Fiscal fourth quarter total revenue grows 59 percent year-over-year to $283.9 million |

[0001327567-15-000022:8k_2_02:6]
| • | Fiscal year 2015 total revenue grows 55 percent year-over-year to $928.1 million |

[0001327567-15-000022:8k_2_02:7]
| • | Fiscal fourth quarter billings grow 69 percent year-over-year to $393.6 million |

[0001327567-15-000022:8k_2_02:8]
| • | Fiscal year 2015 billings grow 58 percent year-over-year to $1.2 billion |

[0001327567-15-000022:8k_2_02:9]
SANTA CLARA, Calif., September 9, 2015 - Palo Alto Networks (NYSE: PANW), the next-generation security company, today announced financial results for its fiscal fourth quarter and fiscal year ended July 31, 2015.

[0001327567-15-000022:8k_2_02:10]
Total revenue for the fiscal fourth quarter 2015 grew 59 percent year-over-year to a record $283.9 million, compared with total revenue of $178.2 million for the fiscal fourth quarter 2014. GAAP net loss for the fiscal fourth quarter 2015 was $46.0 million, or $0.55 per diluted share, compared with GAAP net loss of $32.1 million, or $0.41 per diluted share, for the fiscal fourth quarter 2014.

[0001327567-15-000022:8k_2_02:11]
Non-GAAP net income for the fiscal fourth quarter 2015 was $25.0 million, or $0.28 per diluted share, compared with non-GAAP net income of $9.1 million, or $0.11 per diluted share, for the fiscal fourth quarter 2014. A reconciliation between GAAP and non-GAAP information is contained in the tables below.

[0001327567-15-000022:8k_2_02:12]
“We are very pleased with our results for both the fourth quarter and fiscal year 2015. During the year we grew our customer base to over 26,000 customers, expanded our technology partnerships and distribution relationships, enhanced our next-generation security platform with new offerings and achieved $928.1 million in revenue, an increase of 55 percent year-over-year. We are significantly outgrowing the market and rapidly taking share,” said Mark McLaughlin, president and chief executive officer of Palo Alto Networks. “Once again, our performance demonstrates that our natively integrated and automated security platform is highly differentiated, and our focus on innovation continues to increase our lead over the competition.”

[0001327567-15-000022:8k_2_02:13]
For fiscal year 2015, total revenue grew 55 percent to $928.1 million, compared with $598.2 million in fiscal year 2014. GAAP net loss was $165.0 million, or $2.02 per diluted share, in fiscal year 2015, compared with GAAP net loss of $226.5 million, or $3.05 per diluted share, in fiscal year 2014. Non-

[0001327567-15-000022:8k_2_02:14]
GAAP net income for fiscal year 2015 was $75.2 million, or $0.86 per diluted share, compared with non-GAAP net income of $31.8 million, or $0.40 per diluted share, in fiscal year 2014.

[0001327567-15-000022:8k_2_02:15]
Steffan Tomlinson, chief financial officer of Palo Alto Networks, commented, “We delivered strong fourth quarter and fiscal year 2015 results with accelerating revenue growth and expanding operating and cash flow margins. In the fourth quarter, our land and expand sales model once again drove substantial growth in billings, revenue and deferred revenue, which all reached new records. We generated $111.3 million in cash flow from operations in the fourth quarter and ended fiscal year 2015 with $1.3 billion of cash, cash equivalents and investments.”

[0001327567-15-000022:8k_2_02:16]
Recent Highlights

[0001327567-15-000022:8k_2_02:17]
| • | Rated Outstanding by the Technology Services Industry Association for Commitment to Customer Support and Success – This certification identifies Palo Alto Networks as one of an elite group of organizations that deliver excellence across all significant modes of technical support and recognizes that our support standards and processes will help customers maximize their technology investment. |

[0001327567-15-000022:8k_2_02:18]
| • | Released PAN-OS 7.0 – The newest release of our next-generation security platform operating system included more than 70 feature enhancements, including analysis, automation and operational efficiencies designed to help customers block threats from compromising their networks, endpoints and cloud-enabled data centers. |

[0001327567-15-000022:8k_2_02:19]
| • | Introduced the PA-7080 – This new 200Gbps chassis-based device represents our most powerful next-generation firewall, delivering unrivaled performance and scalability for service providers and large enterprises. |

[0001327567-15-000022:8k_2_02:20]
| • | Established exclusive alliance with Tanium – This alliance marries our respective capabilities and will transform the effectiveness, accuracy, and speed by which large, distributed organizations prevent, detect, and respond to today’s cyberthreats in their network and endpoints before damage is done. |

[0001327567-15-000022:8k_2_02:21]
| • | Hosted more than 500 channel partners at our 2016 Sales Kickoff – We continued our investment in our channel relationships by hosting more than 500 channel partners who |

[0001327567-15-000022:8k_2_02:22]
2

[0001327567-15-000022:8k_2_02:23]
participated side-by-side with our sales representatives in our annual sales training event in early August.

[0001327567-15-000022:8k_2_02:24]
Financial Outlook

[0001327567-15-000022:8k_2_02:25]
Palo Alto Networks provides guidance based on current market conditions and expectations.

[0001327567-15-000022:8k_2_02:26]
For the fiscal first quarter 2016, we expect:

[0001327567-15-000022:8k_2_02:27]
| • | Total revenue in the range of $280 to $284 million, representing year-over-year growth between 46 percent and 48 percent. |

[0001327567-15-000022:8k_2_02:28]
| • | Diluted non-GAAP earnings per share in the range of $0.31 to $0.32 using 91 to 92 million shares. |

[0001327567-15-000022:8k_2_02:29]
Guidance for non-GAAP financial measures excludes share-based compensation and related payroll taxes, acquisition related costs, amortization expense of acquired intangible assets, litigation related charges including legal settlements, non-cash interest expense related to our convertible senior notes, the foreign currency gains (losses) and tax effects associated with these items, and certain non-recurring expenses. We have not reconciled diluted non-GAAP earnings per share guidance to GAAP net income (loss) per diluted share because we do not provide guidance on GAAP net income (loss) or the various reconciling cash and non-cash items between GAAP net income (loss) and non-GAAP net income (loss). Items that impact these measures are out of our control and/or cannot be reasonably predicted. Accordingly, a reconciliation of the non-GAAP financial measure guidance to the corresponding GAAP measures is not available without unreasonable effort.

[0001327567-15-000022:8k_2_02:30]
Conference Call Information

[0001327567-15-000022:8k_2_02:31]
Palo Alto Networks will host a conference call for analysts and investors to discuss its fiscal fourth quarter and fiscal year 2015 results and outlook for its fiscal first quarter 2016 today at 4:30 PM Eastern time/1:30 PM Pacific time. Open to the public, investors may access the call by dialing 1-877-857-6151 or 1-719-325-4839 and entering the passcode 8970610. A live audio webcast of the conference call along with supplemental financial information will also be accessible from the “Investors” section of our website at investors.paloaltonetworks.com. Following the webcast, an archived version will be available on our website for one year. A telephonic replay of the call will be available three hours after the call and will run for ten days and may be accessed by dialing 1-888-203-1112 or 1-719-457-0820 and entering the passcode 8970610.

[0001327567-15-000022:8k_2_02:32]
Forward-Looking Statements

[0001327567-15-000022:8k_2_02:33]
This press release contains forward-looking statements that involve risks and uncertainties, including statements regarding our financial outlook for the fiscal first quarter of 2016, and our ability to continue to expand market share with growth rates that outpace the market. There are a significant number of factors that could cause actual results to differ materially from statements made in this press release, including: our limited operating history; risks associated with managing our rapid growth, particularly outside of the United States; our limited experience with new product introductions and the risks associated with new products, including software bugs; our ability to successfully integrate our operations with those of recently acquired CirroSecure; the failure to timely develop and achieve market acceptance of new products as well as existing products and services; rapidly evolving technological developments in the market for network security products; and general market, political, economic and business conditions.

[0001327567-15-000022:8k_2_02:34]
Additional risks and uncertainties that could affect our financial results are included under the captions “Risk Factors” and “Management’s Discussion and Analysis of Financial Condition and Results of Operations” in our Quarterly Report on Form 10-Q filed with the SEC on May 28, 2015, which is available on our website at investors.paloaltonetworks.com and on the SEC’s website at www.sec.gov. Additional information will also be set forth in other filings that we make with the SEC from time to time. All forward-looking statements in this press release are based on information available to us as of the date hereof, and we do not assume any obligation to update the forward-looking statements provided to reflect events that occur or circumstances that exist after the date on which they were made.

[0001327567-15-000022:8k_2_02:35]
Non-GAAP Financial Measures

[0001327567-15-000022:8k_2_02:36]
Palo Alto Networks has provided in this press release financial information that has not been prepared in accordance with generally accepted accounting principles in the United States (GAAP). The company uses these non-GAAP financial measures internally in analyzing its financial results and believes that the use of these non-GAAP financial measures is useful to investors as an additional tool to evaluate ongoing operating results and trends and in comparing the company’s financial results with other companies in its industry, many of which present similar non-GAAP financial measures.

[0001327567-15-000022:8k_2_02:37]
Non-GAAP financial measures are not meant to be considered in isolation or as a substitute for comparable GAAP financial measures, and should be read only in conjunction with the company’s consolidated financial statements prepared in accordance with GAAP. A reconciliation of the company’s non-GAAP financial measures to their most directly comparable GAAP measures has been provided in

[0001327567-15-000022:8k_2_02:38]
4

[0001327567-15-000022:8k_2_02:39]
the financial statement tables included in this press release, and investors are encouraged to review the reconciliation.

[0001327567-15-000022:8k_2_02:40]
Non-GAAP net income and net income per share, diluted. Palo Alto Networks defines non-GAAP net income as net income (loss) plus share-based compensation related charges including share-based payroll tax expense, acquisition related costs, amortization expense of acquired intangible assets, litigation related charges including legal settlements, non-cash interest expense related to the company’s convertible senior notes, and intellectual property restructuring related charges. The company also excludes from non-GAAP net income the foreign currency gains (losses) and tax effects associated with these items in order to provide a complete picture of the company’s recurring core business operating results. The company defines non-GAAP net income per share, diluted, as non-GAAP net income divided by the weighted average diluted shares outstanding after giving effect to the anti-dilutive impact of the company’s note hedge agreements, which reduces the potential economic dilution that otherwise would occur upon conversion of the company’s convertible senior notes. Under GAAP, the anti-dilutive impact of the note hedge is not reflected in diluted shares outstanding. Palo Alto Networks believes that excluding these items from non-GAAP net income and non-GAAP net income per share, diluted, provides management and investors with greater visibility into the underlying performance of the company’s core business operating results, meaning its operating performance excluding these items and, from time to time, other discrete charges that are infrequent in nature, over multiple periods.

[0001327567-15-000022:8k_2_02:41]
Billings. Palo Alto Networks defines billings as total revenue plus the change in deferred revenue, net of acquired deferred revenue, during the period. The company’s management monitors billings because billings drive deferred revenue, which is an important indicator of the health and visibility of the company’s business. The company considers billings to be a useful metric for management and investors, particularly as sales of subscriptions increase and the company experiences strong renewal rates for subscriptions and support and maintenance.

[0001327567-15-000022:8k_2_02:42]
Investors are cautioned that there are a number of limitations associated with the use of non-GAAP financial measures as an analytical tool. In particular, many of the adjustments to the company’s GAAP financial measures reflect the exclusion of items that are recurring and will be reflected in the company’s financial results for the foreseeable future, such as share-based compensation. Share-based compensation is an important part of Palo Alto Networks employees’ compensation and impacts their performance. In addition, the billings metric reported by the company includes amounts that have not yet been recognized as revenue. Furthermore, the components that Palo Alto Networks excludes in its calculation of non-

[0001327567-15-000022:8k_2_02:43]
GAAP financial measures may differ from the components that its peer companies exclude when they report their non-GAAP results of operations. Palo Alto Networks compensates for these limitations by providing specific information regarding the GAAP amounts excluded from these non-GAAP financial measures. In the future, the company may also exclude non-recurring expenses and other expenses that do not reflect the company’s core business operating results.

[0001327567-15-000022:8k_2_02:44]
About Palo Alto Networks

[0001327567-15-000022:8k_2_02:45]
Palo Alto Networks is the next-generation security company, leading a new era in cybersecurity by safely enabling applications and preventing cyber breaches for tens of thousands of organizations worldwide. Built with an innovative approach and highly differentiated cyberthreat prevention capabilities, our game-changing security platform delivers security far superior to legacy or point products, safely enables daily business operations, and protects an organization’s most valuable assets. Find out more at www.paloaltonetworks.com.

[0001327567-15-000022:8k_2_02:46]
Palo Alto Networks and the Palo Alto Networks Logo are trademarks of Palo Alto Networks, Inc. in the United States and in jurisdictions throughout the world. All other trademarks, trade names or service marks used or mentioned herein belong to their respective owners.

[0001327567-15-000022:8k_2_02:47]
Media Contact:

[0001327567-15-000022:8k_2_02:48]
Jennifer Jasper Smith

[0001327567-15-000022:8k_2_02:49]
Head of Corporate Communications

[0001327567-15-000022:8k_2_02:50]
Palo Alto Networks

[0001327567-15-000022:8k_2_02:51]
408-638-3280

[0001327567-15-000022:8k_2_02:52]
jjsmith@paloaltonetworks.com

[0001327567-15-000022:8k_2_02:53]
Investor Relations Contact:

[0001327567-15-000022:8k_2_02:54]
Kelsey Turcotte

[0001327567-15-000022:8k_2_02:55]
Vice President of Investor Relations

[0001327567-15-000022:8k_2_02:56]
408-753-3872

[0001327567-15-000022:8k_2_02:57]
kturcotte@paloaltonetworks.com

[0001327567-15-000022:8k_2_02:58]
Chris Danne/Maria Riley

[0001327567-15-000022:8k_2_02:59]
The Blueshirt Group

[0001327567-15-000022:8k_2_02:60]
415-217-7722

[0001327567-15-000022:8k_2_02:61]
ir@paloaltonetworks.com

[0001327567-15-000022:8k_2_02:62]
| Palo Alto Networks, Inc. |
| Preliminary Consolidated Statements of Operations |
| (In thousands, except per share data) |
| (Unaudited) |
|  | Three Months Ended July 31, |  | Year Ended July 31, |
|  | 2015 |  | 2014 |  | 2015 |  | 2014 |
| Revenue: |  |  |  |  |  |  |  |
| Product | $ | 154,037 |  |  | $ | 99,707 |  |  | $ | 492,658 |  |  | $ | 340,143 |  |
| Services | 129,842 |  |  | 78,524 |  |  | 435,394 |  |  | 258,036 |  |
| Total revenue | 283,879 |  |  | 178,231 |  |  | 928,052 |  |  | 598,179 |  |
| Cost of revenue: |  |  |  |  |  |  |  |
| Product | 38,462 |  |  | 26,903 |  |  | 131,094 |  |  | 85,503 |  |
| Services | 35,856 |  |  | 21,704 |  |  | 120,405 |  |  | 74,125 |  |
| Total cost of revenue | 74,318 |  |  | 48,607 |  |  | 251,499 |  |  | 159,628 |  |
| Total gross profit | 209,561 |  |  | 129,624 |  |  | 676,553 |  |  | 438,551 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 53,089 |  |  | 32,830 |  |  | 185,828 |  |  | 104,813 |  |
| Sales and marketing | 162,429 |  |  | 106,668 |  |  | 522,696 |  |  | 334,763 |  |
| General and administrative | 28,576 |  |  | 15,574 |  |  | 101,565 |  |  | 73,149 |  |
| Legal settlement | — |  |  | — |  |  | — |  |  | 141,173 |  |
| Total operating expenses | 244,094 |  |  | 155,072 |  |  | 810,089 |  |  | 653,898 |  |
| Operating loss | (34,533 | ) |  | (25,448 | ) |  | (133,536 | ) |  | (215,347 | ) |
| Interest expense | (5,666 | ) |  | (1,848 | ) |  | (22,325 | ) |  | (1,883 | ) |
| Other income (expense), net | (346 | ) |  | (5,595 | ) |  | 284 |  |  | (4,930 | ) |
| Loss before income taxes | (40,545 | ) |  | (32,891 | ) |  | (155,577 | ) |  | (222,160 | ) |
| Provision for (benefit from) income taxes | 5,426 |  |  | (833 | ) |  | 9,405 |  |  | 4,292 |  |
| Net loss | $ | (45,971 | ) |  | $ | (32,058 | ) |  | $ | (164,982 | ) |  | $ | (226,452 | ) |
| Net loss per share, basic and diluted | $ | (0.55 | ) |  | $ | (0.41 | ) |  | $ | (2.02 | ) |  | $ | (3.05 | ) |
| Weighted-average shares used to compute net loss per share, basic and diluted | 83,968 |  |  | 77,859 |  |  | 81,619 |  |  | 74,291 |  |

[0001327567-15-000022:8k_2_02:63]
7

[0001327567-15-000022:8k_2_02:64]
| Palo Alto Networks, Inc. |
| Reconciliation of GAAP to Non-GAAP Financial Measures |
| (In thousands, except per share amounts) |
| (Unaudited) |
|  | Three Months Ended July 31, |  | Year Ended July 31, |
|  | 2015 |  | 2014 |  | 2015 |  | 2014 |
| GAAP net loss | $ | (45,971 | ) |  | $ | (32,058 | ) |  | $ | (164,982 | ) |  | $ | (226,452 | ) |
| Share-based compensation related charges | 68,993 |  |  | 34,060 |  |  | 233,305 |  |  | 101,288 |  |
| Acquisition related costs | 393 |  |  | 329 |  |  | 742 |  |  | 7,809 |  |
| Amortization expense of acquired intangible assets | 1,985 |  |  | 1,453 |  |  | 6,978 |  |  | 2,132 |  |
| Litigation related charges [a] | 3,065 |  |  | 9,937 |  |  | 12,260 |  |  | 160,384 |  |
| Non-cash interest expense related to convertible notes | 5,656 |  |  | 1,826 |  |  | 22,265 |  |  | 1,826 |  |
| Foreign currency loss associated with an acquisition related tax liability | 727 |  |  | — |  |  | 1,241 |  |  | — |  |
| Income tax and other tax adjustments related to the above | (9,878 | ) |  | (6,424 | ) |  | (36,656 | ) |  | (15,193 | ) |
| Non-GAAP net income | $ | 24,970 |  |  | $ | 9,123 |  |  | $ | 75,153 |  |  | $ | 31,794 |  |
| GAAP net loss per share, diluted | $ | (0.55 | ) |  | $ | (0.41 | ) |  | $ | (2.02 | ) |  | $ | (3.05 | ) |
| Share-based compensation related charges | 0.81 |  |  | 0.43 |  |  | 2.79 |  |  | 1.33 |  |
| Acquisition related costs | 0.00 |  |  | 0.00 |  |  | 0.01 |  |  | 0.11 |  |
| Amortization expense of acquired intangible assets | 0.02 |  |  | 0.02 |  |  | 0.09 |  |  | 0.03 |  |
| Litigation related charges [a] | 0.04 |  |  | 0.13 |  |  | 0.15 |  |  | 2.16 |  |
| Non-cash interest expense related to convertible notes | 0.07 |  |  | 0.02 |  |  | 0.27 |  |  | 0.02 |  |
| Foreign currency loss associated with an acquisition related tax liability | 0.01 |  |  | 0.00 |  |  | 0.02 |  |  | 0.00 |  |
| Income tax and other tax adjustments related to the above | (0.12 | ) |  | (0.08 | ) |  | (0.45 | ) |  | (0.20 | ) |
| Non-GAAP net income per share, diluted | $ | 0.28 |  |  | $ | 0.11 |  |  | $ | 0.86 |  |  | $ | 0.40 |  |
| GAAP weighted-average shares used to compute net loss per share, diluted | 83,968 |  |  | 77,859 |  |  | 81,619 |  |  | 74,291 |  |
| Weighted-average effect of potentially dilutive securities [b] | 6,178 |  |  | 5,092 |  |  | 5,759 |  |  | 5,281 |  |
| Non-GAAP weighted-average shares used to compute net income per share, diluted | 90,146 |  |  | 82,951 |  |  | 87,378 |  |  | 79,572 |  |
| Revenue | $ | 283,879 |  |  | $ | 178,231 |  |  | $ | 928,052 |  |  | $ | 598,179 |  |
| Change in deferred revenue, net of acquired deferred revenue | 109,764 |  |  | 54,645 |  |  | 291,076 |  |  | 173,196 |  |
| Billings | $ | 393,643 |  |  | $ | 232,876 |  |  | $ | 1,219,128 |  |  | $ | 771,375 |  |

[0001327567-15-000022:8k_2_02:65]
___________

[0001327567-15-000022:8k_2_02:66]
[a]    Includes expenses for legal services and settlements, including the legal settlement with Fortinet, Inc. of $20.0M in Q2’14, the legal settlement with Juniper Networks, Inc. (“Juniper”) of $121.2M in Q3’14, the mark-to-market for the warrants issued as part of the settlement with Juniper of $5.9M in Q4’14, and the amortization of intellectual property licenses entered into as part of the settlement with Juniper of $2.0M in Q4’14 and $3.1M each quarter thereafter.

[0001327567-15-000022:8k_2_02:67]
[b]    Non-GAAP net income per share, diluted, includes the potentially dilutive effect of employee equity incentive plan awards and convertible senior notes outstanding. In addition, non-GAAP net income per share, diluted, includes the anti-dilutive impact of the company’s note hedge agreements, which reduced the potentially dilutive effect of the convertible notes for the fiscal fourth quarter and fiscal year ended July 31, 2015 by 2.1 million shares and 1.0 million shares, respectively. The potentially dilutive effect of the convertible notes for the fiscal fourth quarter and fiscal year ended July 31, 2014 was nil.

[0001327567-15-000022:8k_2_02:68]
8

[0001327567-15-000022:8k_2_02:69]
| Palo Alto Networks, Inc. |
| Preliminary Consolidated Balance Sheets |
| (In thousands) |
| (Unaudited) |
|  | July 31, 2015 |  | July 31, 2014 |
| Assets |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 375,814 |  |  | $ | 653,812 |  |
| Short-term investments | 413,165 |  |  | 118,690 |  |
| Accounts receivable, net | 212,366 |  |  | 135,518 |  |
| Prepaid expenses and other current assets | 72,685 |  |  | 50,306 |  |
| Total current assets | 1,074,030 |  |  | 958,326 |  |
| Property and equipment, net | 62,878 |  |  | 48,744 |  |
| Long-term investments | 538,841 |  |  | 201,880 |  |
| Goodwill | 163,522 |  |  | 155,033 |  |
| Intangible assets, net | 52,656 |  |  | 47,955 |  |
| Other assets | 73,251 |  |  | 66,528 |  |
| Total assets | $ | 1,965,178 |  |  | $ | 1,478,466 |  |
| Liabilities, temporary equity, and stockholders’ equity |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 13,204 |  |  | $ | 14,526 |  |
| Accrued compensation | 79,795 |  |  | 48,727 |  |
| Accrued and other liabilities | 28,291 |  |  | 25,000 |  |
| Deferred revenue | 423,853 |  |  | 259,918 |  |
| Convertible senior notes, net | 487,084 |  |  | — |  |
| Total current liabilities | 1,032,227 |  |  | 348,171 |  |
| Convertible senior notes, net | — |  |  | 466,875 |  |
| Long-term deferred revenue | 289,801 |  |  | 162,660 |  |
| Other long-term liabilities | 67,335 |  |  | 32,177 |  |
| Temporary equity | 87,916 |  |  | — |  |
| Stockholders’ equity: |  |  |  |
| Preferred stock | — |  |  | — |  |
| Common stock | 8 |  |  | 8 |  |
| Additional paid-in capital | 988,687 |  |  | 804,406 |  |
| Accumulated other comprehensive loss | (88 | ) |  | (105 | ) |
| Accumulated deficit | (500,708 | ) |  | (335,726 | ) |
| Total stockholders’ equity | 487,899 |  |  | 468,583 |  |
| Total liabilities, temporary equity, and stockholders’ equity | $ | 1,965,178 |  |  | $ | 1,478,466 |  |

[0001327567-15-000022:8k_2_02:70]
9

[0001327567-15-000022:8k_2_02:71]
| Palo Alto Networks, Inc. |
| Preliminary Consolidated Statements of Cash Flows |
| (In thousands) |
| (Unaudited) |
|  | Year Ended July 31, |
|  | 2015 |  | 2014 |
| Cash flows from operating activities |  |  |  |
| Net loss | $ | (164,982 | ) |  | $ | (226,452 | ) |
| Adjustments to reconcile net loss to net cash provided by operating activities: |  |  |  |
| Share-based compensation for equity based awards | 221,315 |  |  | 99,774 |  |
| Issuance of common stock for legal settlement | — |  |  | 46,173 |  |
| Depreciation and amortization | 28,881 |  |  | 19,419 |  |
| Amortization of investment premiums, net of accretion of purchase discounts | 3,161 |  |  | 1,518 |  |
| Amortization of debt discount and debt issuance costs | 22,265 |  |  | 1,826 |  |
| Change in fair value of common stock warrant | — |  |  | 5,859 |  |
| Excess tax benefit from share-based compensation arrangements | (2,455 | ) |  | (957 | ) |
| Changes in operating assets and liabilities, net of effects of acquisitions: |  |  |  |
| Accounts receivable, net | (76,830 | ) |  | (47,949 | ) |
| Prepaid expenses and other assets | (34,185 | ) |  | (10,308 | ) |
| Accounts payable | (3,498 | ) |  | (1,100 | ) |
| Accrued compensation | 31,068 |  |  | 26,331 |  |
| Accrued and other liabilities | 34,488 |  |  | 1,076 |  |
| Deferred revenue | 291,076 |  |  | 173,196 |  |
| Net cash provided by operating activities | 350,304 |  |  | 88,406 |  |
| Cash flows from investing activities |  |  |  |
| Purchases of investments | (987,598 | ) |  | (506,642 | ) |
| Proceeds from sales of investments | 18,508 |  |  | 74,597 |  |
| Proceeds from maturities of investments | 339,040 |  |  | 233,530 |  |
| Business acquisitions, net of cash acquired | (15,128 | ) |  | (85,726 | ) |
| Purchases of property, equipment, and other assets | (33,828 | ) |  | (36,107 | ) |
| Net cash used in investing activities | (679,006 | ) |  | (320,348 | ) |
| Cash flows from financing activities |  |  |  |
| Proceeds from borrowings on convertible senior notes, net | — |  |  | 560,433 |  |
| Proceeds from issuance of warrants | — |  |  | 78,258 |  |
| Purchase of convertible note hedges | — |  |  | (110,975 | ) |
| Proceeds from sales of shares through employee equity incentive plans | 48,249 |  |  | 46,599 |  |
| Excess tax benefit from share-based compensation arrangements | 2,455 |  |  | 957 |  |
| Repurchases of restricted common stock from terminated employees | — |  |  | (132 | ) |
| Net cash provided by financing activities | 50,704 |  |  | 575,140 |  |
| Net increase (decrease) in cash and cash equivalents | (277,998 | ) |  | 343,198 |  |
| Cash and cash equivalents - beginning of period | 653,812 |  |  | 310,614 |  |
| Cash and cash equivalents - end of period | $ | 375,814 |  |  | $ | 653,812 |  |

[0001327567-15-000022:8k_2_02:72]
10
