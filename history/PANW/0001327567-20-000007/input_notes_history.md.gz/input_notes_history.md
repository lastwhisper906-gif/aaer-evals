# PANW note change history — 0001327567-19-000038 → 0001327567-20-000007


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2020-02-25):
[0001327567-20-000007:note_history:1]
Our electronics manufacturing service provider (“EMS provider”) procures components and assembles our products based on our forecasts. These forecasts are based on estimates of demand for our products primarily for the next 12 months, which are in turn based on historical trends and an analysis from our sales and product management organizations, adjusted for overall market conditions. In order to reduce manufacturing lead times and plan for adequate supply, we may issue non-cancelable orders for products and components to our manufacturing partners or component suppliers. As of January 31, 2020, our purchase commitments under such orders were $106.0 million, excluding obligations under contracts that we can cancel without a significant penalty.
  (was, 2019-11-26, similarity 0.9906):
[0001327567-19-000038:note_history:1]
Our electronics manufacturing service provider (“EMS provider”) procures components and assembles our products based on our forecasts. These forecasts are based on estimates of demand for our products primarily for the next 12 months, which are in turn based on historical trends and an analysis from our sales and product management organizations, adjusted for overall market conditions. In order to reduce manufacturing lead times and plan for adequate supply, we may issue non-cancelable orders for products and components to our manufacturing partners or component suppliers. As of October 31, 2019, our purchase commitments under such orders were $106.7 million, excluding obligations under contracts that we can cancel without a significant penalty.

- changed (2020-02-25):
[0001327567-20-000007:note_history:2]
We have entered into various non-cancelable agreements with third-party providers for our use of certain cloud and other services, under which we are committed to minimum or fixed purchases through the year ending July 31, 2026. The following table presents details of the aggregate future non-cancelable purchase commitments under these agreements as of January 31, 2020 (in millions):
  (was, 2019-11-26, similarity 0.9813):
[0001327567-19-000038:note_history:2]
We have entered into various non-cancelable agreements with third-party providers for our use of certain cloud and other services, under which we are committed to minimum or fixed purchases through the year ending July 31, 2026. The following table presents details of the aggregate future non-cancelable purchase commitments under these agreements as of October 31, 2019 (in millions):

- changed (2020-02-25):
[0001327567-20-000007:note_history:3]
|  | Amount |
| Fiscal years ending July 31: |  |
| Remaining 2020 | $ | 2.3 |  |
| 2021 | 14.5 |  |
| 2022 | 59.3 |  |
| 2023 | 58.5 |  |
| 2024 | 67.5 |  |
| 2025 and thereafter | 97.5 |  |
| Total other purchase commitments | $ | 299.6 |  |
  (was, 2019-11-26, similarity 0.9948):
[0001327567-19-000038:note_history:3]
|  | Amount |
| Fiscal years ending July 31: |  |
| Remaining 2020 | $ | — |  |
| 2021 | 19.0 |  |
| 2022 | 55.9 |  |
| 2023 | 57.5 |  |
| 2024 | 67.5 |  |
| 2025 and thereafter | 97.5 |  |
| Total other purchase commitments | $ | 297.4 |  |

- added (2020-02-25):
[0001327567-20-000007:note_history:4]
Mutual Covenant Not to Sue and Release Agreement

- added (2020-02-25):
[0001327567-20-000007:note_history:5]
In January 2020, we executed a Mutual Covenant Not to Sue and Release Agreement for $50.0 million, to extend an existing covenant not to sue for seven years. As the primary benefit of the arrangement was attributable to future use, we recorded $50.0 million in other assets and a corresponding balance in accrued and other liabilities on our condensed consolidated balance sheets as of January 31, 2020. The amount recorded in other assets will be amortized to cost of product revenue in our condensed consolidated statements of operations over the estimated period of benefit of seven years.

- changed (2020-02-25):
[0001327567-20-000007:note_history:6]
To the extent there is a reasonable possibility that a loss exceeding amounts already recognized may be incurred and the amount of such additional loss would be material, we will either disclose the estimated additional loss or state that such an estimate cannot be made. As of January 31, 2020, we have not recorded any significant accruals for loss contingencies associated with such legal proceedings, determined that an unfavorable outcome is probable or reasonably possible, or determined that the amount or range of any possible loss is reasonably estimable.
  (was, 2019-11-26, similarity 0.9875):
[0001327567-19-000038:note_history:6]
To the extent there is a reasonable possibility that a loss exceeding amounts already recognized may be incurred and the amount of such additional loss would be material, we will either disclose the estimated additional loss or state that such an estimate cannot be made. As of October 31, 2019, we have not recorded any significant accruals for loss contingencies associated with such legal proceedings, determined that an unfavorable outcome is probable or reasonably possible, or determined that the amount or range of any possible loss is reasonably estimable.


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2020-02-25):
[0001327567-20-000007:note_history:7]
There have been no material changes to our significant accounting policies as of and for the six months ended January 31, 2020, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended July 31, 2019, except for the change in our accounting policies for leases due to our adoption of new lease accounting guidance. Refer to “Recently Adopted Accounting Pronouncements” below and Note 10. Leases.
  (was, 2019-11-26, similarity 0.9752):
[0001327567-19-000038:note_history:7]
There have been no material changes to our significant accounting policies as of and for the three months ended October 31, 2019, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended July 31, 2019, except for the change in our accounting policies for leases due to our adoption of new lease accounting guidance. Refer to “Recently Adopted Accounting Pronouncements” below and Note 10. Leases.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2020-02-25):
[0001327567-20-000007:note_history:8]
There have been no material changes to our significant accounting policies as of and for the six months ended January 31, 2020, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended July 31, 2019, except for the change in our accounting policies for leases due to our adoption of new lease accounting guidance. Refer to “Recently Adopted Accounting Pronouncements” below and Note 10. Leases.
  (was, 2019-11-26, similarity 0.9752):
[0001327567-19-000038:note_history:8]
There have been no material changes to our significant accounting policies as of and for the three months ended October 31, 2019, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended July 31, 2019, except for the change in our accounting policies for leases due to our adoption of new lease accounting guidance. Refer to “Recently Adopted Accounting Pronouncements” below and Note 10. Leases.


## us-gaap:ConvertibleDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-02-25):
[0001327567-20-000007:note_history:9]
The following table sets forth the components of the 2023 Notes as of January 31, 2020 and July 31, 2019 (in millions):
  (was, 2019-11-26, similarity 0.9434):
[0001327567-19-000038:note_history:9]
The following table sets forth the components of the 2023 Notes as of October 31, 2019 and July 31, 2019 (in millions):

- changed (2020-02-25):
[0001327567-20-000007:note_history:10]
|  | January 31, 2020 |  | July 31, 2019 |
| Liability component: |  |  |  |
| Principal | $ | 1,693.0 |  |  | $ | 1,693.0 |  |
| Less: debt discount and debt issuance costs, net of amortization | 231.8 |  |  | 263.0 |  |
| Net carrying amount | $ | 1,461.2 |  |  | $ | 1,430.0 |  |
| Equity component | $ | 315.0 |  |  | $ | 315.0 |  |
  (was, 2019-11-26, similarity 0.9405):
[0001327567-19-000038:note_history:10]
|  | October 31, 2019 |  | July 31, 2019 |
| Liability component: |  |  |  |
| Principal | $ | 1,693.0 |  |  | $ | 1,693.0 |  |
| Less: debt discount and debt issuance costs, net of amortization | 247.5 |  |  | 263.0 |  |
| Net carrying amount | $ | 1,445.5 |  |  | $ | 1,430.0 |  |
| Equity component | $ | 315.0 |  |  | $ | 315.0 |  |


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-02-25):
[0001327567-20-000007:note_history:11]
The sale price condition was not met for the 2023 Notes during the fiscal quarters ended January 31, 2020 or July 31, 2019. Since the 2023 Notes were not convertible, the net carrying amount of the 2023 Notes was classified as a long-term liability and the
  (was, 2019-11-26, similarity 0.6867):
[0001327567-19-000038:note_history:11]
The sale price condition was not met for the 2023 Notes during the fiscal quarters ended October 31, 2019 or July 31, 2019. Since the 2023 Notes were not convertible, the net carrying amount of the 2023 Notes was classified as a long-term liability and the equity component was included in additional paid-in capital in our condensed consolidated balance sheets as of October 31, 2019 and July 31, 2019. As of October 31, 2019, all of the 2023 Notes remained outstanding.

- added (2020-02-25):
[0001327567-20-000007:note_history:12]
equity component was included in additional paid-in capital in our condensed consolidated balance sheets as of January 31, 2020 and July 31, 2019. As of January 31, 2020, all of the 2023 Notes remained outstanding.

- changed (2020-02-25):
[0001327567-20-000007:note_history:13]
The following table sets forth the components of the 2023 Notes as of January 31, 2020 and July 31, 2019 (in millions):
  (was, 2019-11-26, similarity 0.9434):
[0001327567-19-000038:note_history:13]
The following table sets forth the components of the 2023 Notes as of October 31, 2019 and July 31, 2019 (in millions):

- changed (2020-02-25):
[0001327567-20-000007:note_history:14]
|  | January 31, 2020 |  | July 31, 2019 |
| Liability component: |  |  |  |
| Principal | $ | 1,693.0 |  |  | $ | 1,693.0 |  |
| Less: debt discount and debt issuance costs, net of amortization | 231.8 |  |  | 263.0 |  |
| Net carrying amount | $ | 1,461.2 |  |  | $ | 1,430.0 |  |
| Equity component | $ | 315.0 |  |  | $ | 315.0 |  |
  (was, 2019-11-26, similarity 0.9405):
[0001327567-19-000038:note_history:14]
|  | October 31, 2019 |  | July 31, 2019 |
| Liability component: |  |  |  |
| Principal | $ | 1,693.0 |  |  | $ | 1,693.0 |  |
| Less: debt discount and debt issuance costs, net of amortization | 247.5 |  |  | 263.0 |  |
| Net carrying amount | $ | 1,445.5 |  |  | $ | 1,430.0 |  |
| Equity component | $ | 315.0 |  |  | $ | 315.0 |  |

- added (2020-02-25):
[0001327567-20-000007:note_history:15]
The total estimated fair value of the 2023 Notes was $1.9 billion at both January 31, 2020 and July 31, 2019. The fair value was determined based on the closing trading price per $100 of the 2023 Notes as of the last day of trading for the period. We consider the fair value of the 2023 Notes at January 31, 2020 and July 31, 2019 to be a Level 2 measurement. The fair value of the 2023 Notes is primarily affected by the trading price of our common stock and market interest rates. Based on the closing price of our common stock on January 31, 2020, the if-converted value of the 2023 Notes was less than its principal amount.

- changed (2020-02-25):
[0001327567-20-000007:note_history:16]
|  | Three Months Ended January 31, |  | Six Months Ended January 31, |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
|  | 2019 Notes |  | 2023 Notes |  | Total |  | 2019 Notes |  | 2023 Notes |  | Total |  | 2019 Notes |  | 2023 Notes |  | Total |  | 2019 Notes |  | 2023 Notes |  | Total |
| Contractual interest expense | $ | — |  |  | $ | 3.1 |  |  | $ | 3.1 |  |  | $ | — |  |  | $ | 3.1 |  |  | $ | 3.1 |  |  | $ | — |  |  | $ | 6.3 |  |  | $ | 6.3 |  |  | $ | — |  |  | $ | 6.3 |  |  | $ | 6.3 |  |
| Amortization of debt discount | — |  |  | 15.2 |  |  | 15.2 |  |  | 2.0 |  |  | 14.5 |  |  | 16.5 |  |  | — |  |  | 30.2 |  |  | 30.2 |  |  | 6.0 |  |  | 28.9 |  |  | 34.9 |  |
| Amortization of debt issuance costs | — |  |  | 0.5 |  |  | 0.5 |  |  | 0.2 |  |  | 0.4 |  |  | 0.6 |  |  | — |  |  | 1.0 |  |  | 1.0 |  |  | 0.7 |  |  | 0.9 |  |  | 1.6 |  |
| Total interest expense recognized | $ | — |  |  | $ | 18.8 |  |  | $ | 18.8 |  |  | $ | 2.2 |  |  | $ | 18.0 |  |  | $ | 20.2 |  |  | $ | — |  |  | $ | 37.5 |  |  | $ | 37.5 |  |  | $ | 6.7 |  |  | $ | 36.1 |  |  | $ | 42.8 |  |
| Effective interest rate of the liability component | — | % |  | 5.2 | % |  |  |  | 4.8 | % |  | 5.2 | % |  |  |  | — | % |  | 5.2 | % |  |  |  | 4.8 | % |  | 5.2 | % |  |  |
  (was, 2019-11-26, similarity 0.6285):
[0001327567-19-000038:note_history:16]
|  | Three Months Ended October 31, |
|  | 2019 |  | 2018 |
|  | 2019 Notes |  | 2023 Notes |  | Total |  | 2019 Notes |  | 2023 Notes |  | Total |
| Contractual interest expense | $ | — |  |  | $ | 3.2 |  |  | $ | 3.2 |  |  | $ | — |  |  | $ | 3.2 |  |  | $ | 3.2 |  |
| Amortization of debt discount | — |  |  | 15.0 |  |  | 15.0 |  |  | 4.0 |  |  | 14.4 |  |  | 18.4 |  |
| Amortization of debt issuance costs | — |  |  | 0.5 |  |  | 0.5 |  |  | 0.5 |  |  | 0.5 |  |  | 1.0 |  |
| Total interest expense recognized | $ | — |  |  | $ | 18.7 |  |  | $ | 18.7 |  |  | $ | 4.5 |  |  | $ | 18.1 |  |  | $ | 22.6 |  |
| Effective interest rate of the liability component | — | % |  | 5.2 | % |  |  |  | 4.8 | % |  | 5.2 | % |  |  |

- changed (2020-02-25):
[0001327567-20-000007:note_history:17]
The 2023 Note Hedges cover up to 6.4 million shares of our common stock at a strike price per share that corresponds to the initial applicable conversion price of the 2023 Notes, which are also subject to adjustment, and are exercisable upon conversion of the 2023 Notes. The 2023 Note Hedges will expire upon maturity of the 2023 Notes. The 2023 Note Hedges are separate transactions and are not part of the terms of 2023 Notes. Holders of the 2023 Notes will not have any rights with respect to the 2023 Note Hedges. Any shares of our common stock receivable by us under the 2023 Note Hedges are excluded from the calculation of diluted earnings per share as they are antidilutive. We paid an aggregate amount of $332.0 million for the 2023 Note Hedges, which is included in additional paid-in capital in our consolidated balance sheets.
  (was, 2019-11-26, similarity 0.7002):
[0001327567-19-000038:note_history:17]
are not part of the terms of 2023 Notes. Holders of the 2023 Notes will not have any rights with respect to the 2023 Note Hedges. Any shares of our common stock receivable by us under the 2023 Note Hedges are excluded from the calculation of diluted earnings per share as they are antidilutive. We paid an aggregate amount of $332.0 million for the 2023 Note Hedges, which is included in additional paid-in capital in our consolidated balance sheets.

- changed (2020-02-25):
[0001327567-20-000007:note_history:18]
Separately, but concurrently with the issuance of each series of Notes, we entered into transactions whereby we sold warrants (the “2019 Warrants,” with respect to the 2019 Notes, and the “2023 Warrants,” with respect to the 2023 Notes, and collectively, the
  (was, 2019-11-26, similarity 0.713):
[0001327567-19-000038:note_history:18]
Separately, but concurrently with the issuance of each series of Notes, we entered into transactions whereby we sold warrants (the “2019 Warrants,” with respect to the 2019 Notes, and the “2023 Warrants,” with respect to the 2023 Notes, and collectively, the “Warrants”) to acquire shares of our common stock, subject to anti-dilution adjustments. The 2019 Warrants became exercisable beginning October 2019 and the 2023 Warrants are exercisable beginning October 2023.

- added (2020-02-25):
[0001327567-20-000007:note_history:19]
“Warrants”) to acquire shares of our common stock, subject to anti-dilution adjustments. The 2019 Warrants became exercisable beginning October 2019 and the 2023 Warrants are exercisable beginning October 2023.

- added (2020-02-25):
[0001327567-20-000007:note_history:20]
During the six months ended January 31, 2020, we net settled all 2019 Warrants with approximately 2.0 million shares or $462.0 million in fair value of our common stock, of which 1.3 million shares or $308.4 million in fair value of our common stock were net settled during the three months ended January 31, 2020. The number of net shares issued was determined based on the number of 2019 Warrants exercised multiplied by the difference between the strike price of the 2019 Warrants and their daily volume weighted-average stock price.

- changed (2020-02-25):
[0001327567-20-000007:note_history:21]
The borrowings under the Credit Facility bear interest, at our option, at a base rate plus a spread of 0.00% to 0.75%, or an adjusted LIBO rate plus a spread of 1.00% to 1.75%, in each case with such spread being determined based on our leverage ratio. We are obligated to pay an ongoing commitment fee on undrawn amounts at a rate of 0.125% to 0.250%, depending on our leverage ratio. As of January 31, 2020, there were no amounts outstanding and we were in compliance with all covenants under the Credit Agreement.
  (was, 2019-11-26, similarity 0.9857):
[0001327567-19-000038:note_history:21]
The borrowings under the Credit Facility bear interest, at our option, at a base rate plus a spread of 0.00% to 0.75%, or an adjusted LIBO rate plus a spread of 1.00% to 1.75%, in each case with such spread being determined based on our leverage ratio. We are obligated to pay an ongoing commitment fee on undrawn amounts at a rate of 0.125% to 0.250%, depending on our leverage ratio. As of October 31, 2019, there were no amounts outstanding and we were in compliance with all covenants under the Credit Agreement.

- removed (2020-02-25):
[0001327567-19-000038:note_history:22]
The total estimated fair value of the 2023 Notes was $1.9 billion at both October 31, 2019 and July 31, 2019. The fair value was determined based on the closing trading price per $100 of the 2023 Notes as of the last day of trading for the period. We consider the fair value of the 2023 Notes at October 31, 2019 and July 31, 2019 to be a Level 2 measurement. The fair value of the 2023 Notes is primarily affected by the trading price of our common stock and market interest rates. Based on the closing price of our common stock on October 31, 2019, the if-converted value of the 2023 Notes was less than its principal amount.

- removed (2020-02-25):
[0001327567-19-000038:note_history:23]
The 2023 Note Hedges cover up to 6.4 million shares of our common stock at a strike price per share that corresponds to the initial applicable conversion price of the 2023 Notes, which are also subject to adjustment, and are exercisable upon conversion of the 2023 Notes. The 2023 Note Hedges will expire upon maturity of the 2023 Notes. The 2023 Note Hedges are separate transactions and

- removed (2020-02-25):
[0001327567-19-000038:note_history:24]
During the three months ended October 31, 2019, we net settled the 2019 Warrants exercised with 0.7 million shares or $153.6 million in fair value of our common stock. The number of net shares issued was determined based on the number of 2019 Warrants exercised multiplied by the difference between the strike price of the 2019 Warrants and their daily volume weighted-average stock price. As of October 31, 2019, up to 3.2 million shares of our common stock were issuable for gross settlement under the remaining outstanding 2019 Warrants, which will be net settled when exercised through the end of December 2019.


## us-gaap:DebtSecuritiesAvailableForSaleTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-02-25):
[0001327567-20-000007:note_history:25]
The following tables summarize the amortized cost, unrealized gains and losses, and fair value of our available-for-sale debt securities as of January 31, 2020 and July 31, 2019 (in millions):
  (was, 2019-11-26, similarity 0.967):
[0001327567-19-000038:note_history:25]
The following tables summarize the amortized cost, unrealized gains and losses, and fair value of our available-for-sale debt securities as of October 31, 2019 and July 31, 2019 (in millions):

- changed (2020-02-25):
[0001327567-20-000007:note_history:26]
|  | January 31, 2020 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 65.5 |  |  | $ | — |  |  | $ | — |  |  | $ | 65.5 |  |
| U.S. government and agency securities | 479.5 |  |  | — |  |  | — |  |  | 479.5 |  |
| Total available-for-sale cash equivalents | $ | 545.0 |  |  | $ | — |  |  | $ | — |  |  | $ | 545.0 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 24.0 |  |  | $ | — |  |  | $ | — |  |  | $ | 24.0 |  |
| Corporate debt securities | 456.5 |  |  | 2.8 |  |  | — |  |  | 459.3 |  |
| U.S. government and agency securities | 966.1 |  |  | 2.5 |  |  | (0.1 | ) |  | 968.5 |  |
| Total available-for-sale investments | $ | 1,446.6 |  |  | $ | 5.3 |  |  | $ | (0.1 | ) |  | $ | 1,451.8 |  |
  (was, 2019-11-26, similarity 0.9228):
[0001327567-19-000038:note_history:26]
|  | October 31, 2019 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 4.0 |  |  | $ | — |  |  | $ | — |  |  | $ | 4.0 |  |
| Commercial paper | 4.5 |  |  | — |  |  | — |  |  | 4.5 |  |
| U.S. government and agency securities | 15.0 |  |  | — |  |  | — |  |  | 15.0 |  |
| Total available-for-sale cash equivalents | $ | 23.5 |  |  | $ | — |  |  | $ | — |  |  | $ | 23.5 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 23.7 |  |  | $ | — |  |  | $ | — |  |  | $ | 23.7 |  |
| Commercial paper | 15.9 |  |  | — |  |  | — |  |  | 15.9 |  |
| Corporate debt securities | 565.2 |  |  | 3.0 |  |  | — |  |  | 568.2 |  |
| U.S. government and agency securities | 1,454.0 |  |  | 3.6 |  |  | (0.3 | ) |  | 1,457.3 |  |
| Total available-for-sale investments | $ | 2,058.8 |  |  | $ | 6.6 |  |  | $ | (0.3 | ) |  | $ | 2,065.1 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-02-25):
[0001327567-20-000007:note_history:27]
The following tables summarize the amortized cost, unrealized gains and losses, and fair value of our available-for-sale debt securities as of January 31, 2020 and July 31, 2019 (in millions):
  (was, 2019-11-26, similarity 0.967):
[0001327567-19-000038:note_history:27]
The following tables summarize the amortized cost, unrealized gains and losses, and fair value of our available-for-sale debt securities as of October 31, 2019 and July 31, 2019 (in millions):

- changed (2020-02-25):
[0001327567-20-000007:note_history:28]
|  | January 31, 2020 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 65.5 |  |  | $ | — |  |  | $ | — |  |  | $ | 65.5 |  |
| U.S. government and agency securities | 479.5 |  |  | — |  |  | — |  |  | 479.5 |  |
| Total available-for-sale cash equivalents | $ | 545.0 |  |  | $ | — |  |  | $ | — |  |  | $ | 545.0 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 24.0 |  |  | $ | — |  |  | $ | — |  |  | $ | 24.0 |  |
| Corporate debt securities | 456.5 |  |  | 2.8 |  |  | — |  |  | 459.3 |  |
| U.S. government and agency securities | 966.1 |  |  | 2.5 |  |  | (0.1 | ) |  | 968.5 |  |
| Total available-for-sale investments | $ | 1,446.6 |  |  | $ | 5.3 |  |  | $ | (0.1 | ) |  | $ | 1,451.8 |  |
  (was, 2019-11-26, similarity 0.9228):
[0001327567-19-000038:note_history:28]
|  | October 31, 2019 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 4.0 |  |  | $ | — |  |  | $ | — |  |  | $ | 4.0 |  |
| Commercial paper | 4.5 |  |  | — |  |  | — |  |  | 4.5 |  |
| U.S. government and agency securities | 15.0 |  |  | — |  |  | — |  |  | 15.0 |  |
| Total available-for-sale cash equivalents | $ | 23.5 |  |  | $ | — |  |  | $ | — |  |  | $ | 23.5 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 23.7 |  |  | $ | — |  |  | $ | — |  |  | $ | 23.7 |  |
| Commercial paper | 15.9 |  |  | — |  |  | — |  |  | 15.9 |  |
| Corporate debt securities | 565.2 |  |  | 3.0 |  |  | — |  |  | 568.2 |  |
| U.S. government and agency securities | 1,454.0 |  |  | 3.6 |  |  | (0.3 | ) |  | 1,457.3 |  |
| Total available-for-sale investments | $ | 2,058.8 |  |  | $ | 6.6 |  |  | $ | (0.3 | ) |  | $ | 2,065.1 |  |

- changed (2020-02-25):
[0001327567-20-000007:note_history:29]
Unrealized losses related to these securities are due to interest rate fluctuations as opposed to credit quality. In addition, we do not intend to sell and it is not likely that we would be required to sell these securities before recovery of their amortized cost basis, which may be at maturity. As a result, there were no other-than-temporary impairments for these securities at January 31, 2020 and July 31, 2019.
  (was, 2019-11-26, similarity 0.9556):
[0001327567-19-000038:note_history:29]
Unrealized losses related to these securities are due to interest rate fluctuations as opposed to credit quality. In addition, we do not intend to sell and it is not likely that we would be required to sell these securities before recovery of their amortized cost basis, which may be at maturity. As a result, there were no other-than-temporary impairments for these securities at October 31, 2019 and July 31, 2019.

- changed (2020-02-25):
[0001327567-20-000007:note_history:30]
The following table summarizes the amortized cost and fair value of our available-for-sale debt securities as of January 31, 2020, by contractual years-to-maturity (in millions):
  (was, 2019-11-26, similarity 0.9651):
[0001327567-19-000038:note_history:30]
The following table summarizes the amortized cost and fair value of our available-for-sale debt securities as of October 31, 2019, by contractual years-to-maturity (in millions):

- changed (2020-02-25):
[0001327567-20-000007:note_history:31]
Marketable equity securities consist of money market funds and are included in cash and cash equivalents in our condensed consolidated balance sheets. As of January 31, 2020 and July 31, 2019, the carrying value of our marketable equity securities were $577.1 million and $369.1 million, respectively. There were no unrealized gains or losses recognized for these securities during the three and six months ended January 31, 2020 and 2019.
  (was, 2019-11-26, similarity 0.6902):
[0001327567-19-000038:note_history:31]
Marketable equity securities consist of money market funds and are included in cash and cash equivalents in our condensed consolidated balance sheets. As of October 31, 2019 and July 31, 2019, the carrying value of our marketable equity securities were

- removed (2020-02-25):
[0001327567-19-000038:note_history:32]
$617.3 million and $369.1 million, respectively. There were no unrealized gains or losses recognized for these securities during the three months ended October 31, 2019 and 2018.


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2020-02-25):
[0001327567-20-000007:note_history:33]
|  | Three Months Ended January 31, |  | Six Months Ended January 31, |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Revenue: |  |  |  |  |  |  |  |
| Americas |  |  |  |  |  |  |  |
| United States | $ | 505.6 |  |  | $ | 434.6 |  |  | $ | 1,000.5 |  |  | $ | 850.5 |  |
| Other Americas | 39.1 |  |  | 40.4 |  |  | 73.8 |  |  | 74.7 |  |
| Total Americas | 544.7 |  |  | 475.0 |  |  | 1,074.3 |  |  | 925.2 |  |
| Europe, the Middle East, and Africa (“EMEA”) | 166.2 |  |  | 148.3 |  |  | 313.8 |  |  | 276.0 |  |
| Asia Pacific and Japan (“APAC”) | 105.8 |  |  | 87.9 |  |  | 200.5 |  |  | 166.0 |  |
| Total revenue | $ | 816.7 |  |  | $ | 711.2 |  |  | $ | 1,588.6 |  |  | $ | 1,367.2 |  |

- added (2020-02-25):
[0001327567-20-000007:note_history:34]
|  | Three Months Ended January 31, |  | Six Months Ended January 31, |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Revenue: |  |  |  |  |  |  |  |
| Product | $ | 246.5 |  |  | $ | 271.6 |  |  | $ | 477.7 |  |  | $ | 512.1 |  |
| Subscription and support |  |  |  |  |  |  |  |
| Subscription | 342.6 |  |  | 249.7 |  |  | 661.2 |  |  | 481.0 |  |
| Support | 227.6 |  |  | 189.9 |  |  | 449.7 |  |  | 374.1 |  |
| Total subscription and support | 570.2 |  |  | 439.6 |  |  | 1,110.9 |  |  | 855.1 |  |
| Total revenue | $ | 816.7 |  |  | $ | 711.2 |  |  | $ | 1,588.6 |  |  | $ | 1,367.2 |  |

- changed (2020-02-25):
[0001327567-20-000007:note_history:35]
During the six months ended January 31, 2020, we recognized approximately $915.0 million of revenue pertaining to amounts that were deferred as of July 31, 2019.
  (was, 2019-11-26, similarity 0.9315):
[0001327567-19-000038:note_history:35]
During the three months ended October 31, 2019, we recognized approximately $485.0 million of revenue pertaining to amounts that were deferred as of July 31, 2019.

- added (2020-02-25):
[0001327567-20-000007:note_history:36]
Revenue expected to be recognized from remaining performance obligations was $3.3 billion as of January 31, 2020, of which we expect to recognize approximately $1.8 billion over the next 12 months and the remainder thereafter.
Deferred Contract Costs
The following table presents details of our short-term and long-term deferred contract costs as of January 31, 2020 and July 31, 2019 (in millions):

- changed (2020-02-25):
[0001327567-20-000007:note_history:37]
|  | January 31, 2020 |  | July 31, 2019 |
| Short-term deferred contract costs | $ | 164.6 |  |  | $ | 151.1 |  |
| Long-term deferred contract costs | 327.2 |  |  | 324.2 |  |
| Total deferred contract costs | $ | 491.8 |  |  | $ | 475.3 |  |
  (was, 2019-11-26, similarity 0.9698):
[0001327567-19-000038:note_history:37]
|  | October 31, 2019 |  | July 31, 2019 |
| Short-term deferred contract costs | $ | 155.4 |  |  | $ | 151.1 |  |
| Long-term deferred contract costs | 317.6 |  |  | 324.2 |  |
| Total deferred contract costs | $ | 473.0 |  |  | $ | 475.3 |  |

- changed (2020-02-25):
[0001327567-20-000007:note_history:38]
We recognized amortization expense for our deferred contract costs of $55.3 million and $110.9 million during the three and six months ended January 31, 2020, respectively, and $46.8 million and $90.4 million during the three and six months ended January 31, 2019, respectively. We did not recognize any impairment losses on our deferred contract costs during the three and six months ended January 31, 2020 or 2019.
  (was, 2019-11-26, similarity 0.6697):
[0001327567-19-000038:note_history:38]
We recognized amortization expense for our deferred contract costs of $55.6 million and $43.6 million during the three months ended October 31, 2019 and 2018, respectively. We did not recognize any impairment losses on our deferred contract costs during the three months ended October 31, 2019 or 2018.

- removed (2020-02-25):
[0001327567-19-000038:note_history:39]
|  | Three Months Ended October 31, |
|  | 2019 |  | 2018 |
| Revenue: |  |  |  |
| Americas |  |  |  |
| United States | $ | 494.9 |  |  | $ | 415.9 |  |
| Other Americas | 34.7 |  |  | 34.3 |  |
| Total Americas | 529.6 |  |  | 450.2 |  |
| Europe, the Middle East, and Africa (“EMEA”) | 147.6 |  |  | 127.7 |  |
| Asia Pacific and Japan (“APAC”) | 94.7 |  |  | 78.1 |  |
| Total revenue | $ | 771.9 |  |  | $ | 656.0 |  |

- removed (2020-02-25):
[0001327567-19-000038:note_history:40]
|  | Three Months Ended October 31, |
|  | 2019 |  | 2018 |
| Revenue: |  |  |  |
| Product | $ | 231.2 |  |  | $ | 240.5 |  |
| Subscription and support |  |  |  |  |  |
| Subscription | 318.6 |  |  | 231.3 |  |
| Support | 222.1 |  |  | 184.2 |  |
| Total subscription and support | 540.7 |  |  | 415.5 |  |
| Total revenue | $ | 771.9 |  |  | $ | 656.0 |  |

- removed (2020-02-25):
[0001327567-19-000038:note_history:41]
Revenue expected to be recognized from remaining performance obligations was $3.1 billion as of October 31, 2019, of which we expect to recognize approximately $1.7 billion over the next 12 months and the remainder thereafter.
Deferred Contract Costs
The following table presents details of our short-term and long-term deferred contract costs as of October 31, 2019 and July 31, 2019 (in millions):


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- added (2020-02-25):
[0001327567-20-000007:note_history:42]
Subsequent Events
Accelerated Share Repurchase

- added (2020-02-25):
[0001327567-20-000007:note_history:43]
On February 21, 2020, our board of directors approved the repurchase of $1.0 billion of our common stock through an accelerated share repurchase (“ASR”) transaction, which we expect to enter into during our fiscal quarter ending April 30, 2020, subject to market conditions. The ASR transaction is in addition to our $1.0 billion share repurchase program that our board of directors authorized in February 2019.

- added (2020-02-25):
[0001327567-20-000007:note_history:44]
Land Purchase Agreement

- added (2020-02-25):
[0001327567-20-000007:note_history:45]
In February 2020, we entered into an agreement to purchase 5.8 acres of land adjacent to our headquarters in Santa Clara, California for $51.0 million in cash.  The arrangement is expected to close during our fiscal quarter ending April 30, 2020.

- removed (2020-02-25):
[0001327567-19-000038:note_history:46]
Subsequent Event
Business Combination

- removed (2020-02-25):
[0001327567-19-000038:note_history:47]
In November 2019, we entered into a definitive agreement to acquire Aporeto, Inc., a privately-held company, for total consideration of approximately $150.0 million in cash, subject to adjustment. We expect the acquisition will strengthen our Cloud-Native Security Platform capabilities delivered by Prisma Cloud. The acquisition is expected to close during our second quarter of fiscal 2020.
