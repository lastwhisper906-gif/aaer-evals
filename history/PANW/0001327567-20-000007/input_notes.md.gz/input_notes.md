# PANW notes — 0001327567-20-000007


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock

[0001327567-20-000007:notes:1]
[same as prior period, unchanged from 0001327567-19-000038:notes:1]

[0001327567-20-000007:notes:2]
[same as prior period, unchanged from 0001327567-19-000038:notes:2]

[0001327567-20-000007:notes:3]
[same as prior period, unchanged from 0001327567-19-000038:notes:3]

[0001327567-20-000007:notes:4]
The accompanying condensed consolidated financial statements have been prepared in conformity with U.S. generally accepted accounting principles (“GAAP”), consistent in all material respects with those applied in our Annual Report on Form 10-K for the fiscal year ended July 31, 2019, filed with the Securities and Exchange Commission (“SEC”) on September 9, 2019. Our condensed consolidated financial statements include our accounts and our wholly owned subsidiaries. All significant intercompany balances and transactions have been eliminated in consolidation.

[0001327567-20-000007:notes:5]
[same as prior period, unchanged from 0001327567-19-000038:notes:5]

[0001327567-20-000007:notes:6]
[same as prior period, unchanged from 0001327567-19-000038:notes:6]

[0001327567-20-000007:notes:7]
Our condensed consolidated financial statements should be read in conjunction with the audited consolidated financial statements and related notes in our Annual Report on Form 10-K for the fiscal year ended July 31, 2019.

[0001327567-20-000007:notes:8]
[same as prior period, unchanged from 0001327567-19-000038:notes:8]

[0001327567-20-000007:notes:9]
There have been no material changes to our significant accounting policies as of and for the six months ended January 31, 2020, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended July 31, 2019, except for the change in our accounting policies for leases due to our adoption of new lease accounting guidance. Refer to “Recently Adopted Accounting Pronouncements” below and Note 10. Leases.

[0001327567-20-000007:notes:10]
Recently Adopted Accounting Pronouncements

[0001327567-20-000007:notes:11]
[same as prior period, unchanged from 0001327567-19-000038:notes:11]

[0001327567-20-000007:notes:12]
[same as prior period, unchanged from 0001327567-19-000038:notes:12]

[0001327567-20-000007:notes:13]
[same as prior period, unchanged from 0001327567-19-000038:notes:13]

[0001327567-20-000007:notes:14]
The most significant impact of adopting this guidance was the recognition of $286.4 million of operating lease right-of-use assets and $442.4 million of operating lease liabilities on our condensed consolidated balance sheet as of August 1, 2019, which included reclassifying previously recognized $129.0 million in lease incentives, deferred or prepaid rent, as well as $27.0 million in cease-use liabilities to operating lease right-of-use assets.

[0001327567-20-000007:notes:15]
[same as prior period, unchanged from 0001327567-19-000038:notes:15]

[0001327567-20-000007:notes:16]
Recently Issued Accounting Pronouncements

[0001327567-20-000007:notes:17]
[same as prior period, unchanged from 0001327567-19-000038:notes:17]

[0001327567-20-000007:notes:18]
[same as prior period, unchanged from 0001327567-19-000038:notes:18]

[0001327567-20-000007:notes:19]
[same as prior period, unchanged from 0001327567-19-000038:notes:19]


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001327567-20-000007:notes:20]
[same as prior period, unchanged from 0001327567-19-000038:notes:20]

[0001327567-20-000007:notes:21]
[same as prior period, unchanged from 0001327567-19-000038:notes:21]

[0001327567-20-000007:notes:22]
|  | Three Months Ended January 31, |  | Six Months Ended January 31, |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Revenue: |  |  |  |  |  |  |  |
| Americas |  |  |  |  |  |  |  |
| United States | $ | 505.6 |  |  | $ | 434.6 |  |  | $ | 1,000.5 |  |  | $ | 850.5 |  |
| Other Americas | 39.1 |  |  | 40.4 |  |  | 73.8 |  |  | 74.7 |  |
| Total Americas | 544.7 |  |  | 475.0 |  |  | 1,074.3 |  |  | 925.2 |  |
| Europe, the Middle East, and Africa (“EMEA”) | 166.2 |  |  | 148.3 |  |  | 313.8 |  |  | 276.0 |  |
| Asia Pacific and Japan (“APAC”) | 105.8 |  |  | 87.9 |  |  | 200.5 |  |  | 166.0 |  |
| Total revenue | $ | 816.7 |  |  | $ | 711.2 |  |  | $ | 1,588.6 |  |  | $ | 1,367.2 |  |

[0001327567-20-000007:notes:23]
[same as prior period, unchanged from 0001327567-19-000038:notes:23]

[0001327567-20-000007:notes:24]
|  | Three Months Ended January 31, |  | Six Months Ended January 31, |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Revenue: |  |  |  |  |  |  |  |
| Product | $ | 246.5 |  |  | $ | 271.6 |  |  | $ | 477.7 |  |  | $ | 512.1 |  |
| Subscription and support |  |  |  |  |  |  |  |
| Subscription | 342.6 |  |  | 249.7 |  |  | 661.2 |  |  | 481.0 |  |
| Support | 227.6 |  |  | 189.9 |  |  | 449.7 |  |  | 374.1 |  |
| Total subscription and support | 570.2 |  |  | 439.6 |  |  | 1,110.9 |  |  | 855.1 |  |
| Total revenue | $ | 816.7 |  |  | $ | 711.2 |  |  | $ | 1,588.6 |  |  | $ | 1,367.2 |  |

[0001327567-20-000007:notes:25]
[same as prior period, unchanged from 0001327567-19-000038:notes:25]

[0001327567-20-000007:notes:26]
During the six months ended January 31, 2020, we recognized approximately $915.0 million of revenue pertaining to amounts that were deferred as of July 31, 2019.

[0001327567-20-000007:notes:27]
[same as prior period, unchanged from 0001327567-19-000038:notes:27]

[0001327567-20-000007:notes:28]
Revenue expected to be recognized from remaining performance obligations was $3.3 billion as of January 31, 2020, of which we expect to recognize approximately $1.8 billion over the next 12 months and the remainder thereafter.
Deferred Contract Costs
The following table presents details of our short-term and long-term deferred contract costs as of January 31, 2020 and July 31, 2019 (in millions):

[0001327567-20-000007:notes:29]
|  | January 31, 2020 |  | July 31, 2019 |
| Short-term deferred contract costs | $ | 164.6 |  |  | $ | 151.1 |  |
| Long-term deferred contract costs | 327.2 |  |  | 324.2 |  |
| Total deferred contract costs | $ | 491.8 |  |  | $ | 475.3 |  |

[0001327567-20-000007:notes:30]
We recognized amortization expense for our deferred contract costs of $55.3 million and $110.9 million during the three and six months ended January 31, 2020, respectively, and $46.8 million and $90.4 million during the three and six months ended January 31, 2019, respectively. We did not recognize any impairment losses on our deferred contract costs during the three and six months ended January 31, 2020 or 2019.


## us-gaap:FairValueDisclosuresTextBlock

[0001327567-20-000007:notes:31]
[same as prior period, unchanged from 0001327567-19-000038:notes:31]

[0001327567-20-000007:notes:32]
[same as prior period, unchanged from 0001327567-19-000038:notes:32]

[0001327567-20-000007:notes:33]
[same as prior period, unchanged from 0001327567-19-000038:notes:33]

[0001327567-20-000007:notes:34]
[same as prior period, unchanged from 0001327567-19-000038:notes:34]

[0001327567-20-000007:notes:35]
The following table presents the fair value of our financial assets and liabilities measured at fair value on a recurring basis using the above input categories as of January 31, 2020 and July 31, 2019 (in millions):

[0001327567-20-000007:notes:36]
|  |  | January 31, 2020 |  | July 31, 2019 |
|  |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Cash equivalents: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 577.1 |  |  | $ | — |  |  | $ | — |  |  | $ | 577.1 |  |  | $ | 369.1 |  |  | $ | — |  |  | $ | — |  |  | $ | 369.1 |  |
| Certificates of deposit |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 12.0 |  |  |  |  | 12.0 |  |
| Commercial paper |  | — |  |  | 65.5 |  |  | — |  |  | 65.5 |  |  | — |  |  | 19.3 |  |  | — |  |  | 19.3 |  |
| U.S. government and agency securities |  | — |  |  | 479.5 |  |  | — |  |  | 479.5 |  |  | — |  |  | 54.4 |  |  | — |  |  | 54.4 |  |
| Total cash equivalents |  | 577.1 |  |  | 545.0 |  |  | — |  |  | 1,122.1 |  |  | 369.1 |  |  | 85.7 |  |  | — |  |  | 454.8 |  |
| Short-term investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Certificates of deposit |  | — |  |  | 24.0 |  |  | — |  |  | 24.0 |  |  | — |  |  | 17.5 |  |  | — |  |  | 17.5 |  |
| Commercial paper |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 8.9 |  |  | — |  |  | 8.9 |  |
| Corporate debt securities |  | — |  |  | 318.7 |  |  | — |  |  | 318.7 |  |  | — |  |  | 375.5 |  |  | — |  |  | 375.5 |  |
| U.S. government and agency securities |  | — |  |  | 791.2 |  |  | — |  |  | 791.2 |  |  | — |  |  | 1,439.8 |  |  | — |  |  | 1,439.8 |  |
| Total short-term investments |  | — |  |  | 1,133.9 |  |  | — |  |  | 1,133.9 |  |  | — |  |  | 1,841.7 |  |  | — |  |  | 1,841.7 |  |
| Long-term investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate debt securities |  | — |  |  | 140.6 |  |  | — |  |  | 140.6 |  |  | — |  |  | 214.3 |  |  | — |  |  | 214.3 |  |
| U.S. government and agency securities |  | — |  |  | 177.3 |  |  | — |  |  | 177.3 |  |  | — |  |  | 361.1 |  |  | — |  |  | 361.1 |  |
| Total long-term investments |  | — |  |  | 317.9 |  |  | — |  |  | 317.9 |  |  | — |  |  | 575.4 |  |  | — |  |  | 575.4 |  |
| Prepaid expenses and other current assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency forward contracts |  | — |  |  | 0.9 |  |  | — |  |  | 0.9 |  |  | — |  |  | 1.3 |  |  | — |  |  | 1.3 |  |
| Total prepaid expenses and other current assets |  | — |  |  | 0.9 |  |  | — |  |  | 0.9 |  |  | — |  |  | 1.3 |  |  | — |  |  | 1.3 |  |
| Total assets measured at fair value |  | $ | 577.1 |  |  | $ | 1,997.7 |  |  | $ | — |  |  | $ | 2,574.8 |  |  | $ | 369.1 |  |  | $ | 2,504.1 |  |  | $ | — |  |  | $ | 2,873.2 |  |
| Accrued and other liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency forward contracts |  | $ | — |  |  | $ | 2.8 |  |  | $ | — |  |  | $ | 2.8 |  |  | $ | — |  |  | $ | 3.8 |  |  | $ | — |  |  | $ | 3.8 |  |
| Total accrued and other liabilities |  | — |  |  | 2.8 |  |  | — |  |  | 2.8 |  |  | — |  |  | 3.8 |  |  | — |  |  | 3.8 |  |
| Total liabilities measured at fair value |  | $ | — |  |  | $ | 2.8 |  |  | $ | — |  |  | $ | 2.8 |  |  | $ | — |  |  | $ | 3.8 |  |  | $ | — |  |  | $ | 3.8 |  |

[0001327567-20-000007:notes:37]
Refer to Note 9. Debt for the carrying amount and estimated fair value of our convertible senior notes as of January 31, 2020 and July 31, 2019.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001327567-20-000007:notes:38]
Cash Equivalents and Investments
Available-for-sale Debt Securities

[0001327567-20-000007:notes:39]
The following tables summarize the amortized cost, unrealized gains and losses, and fair value of our available-for-sale debt securities as of January 31, 2020 and July 31, 2019 (in millions):

[0001327567-20-000007:notes:40]
|  | January 31, 2020 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 65.5 |  |  | $ | — |  |  | $ | — |  |  | $ | 65.5 |  |
| U.S. government and agency securities | 479.5 |  |  | — |  |  | — |  |  | 479.5 |  |
| Total available-for-sale cash equivalents | $ | 545.0 |  |  | $ | — |  |  | $ | — |  |  | $ | 545.0 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 24.0 |  |  | $ | — |  |  | $ | — |  |  | $ | 24.0 |  |
| Corporate debt securities | 456.5 |  |  | 2.8 |  |  | — |  |  | 459.3 |  |
| U.S. government and agency securities | 966.1 |  |  | 2.5 |  |  | (0.1 | ) |  | 968.5 |  |
| Total available-for-sale investments | $ | 1,446.6 |  |  | $ | 5.3 |  |  | $ | (0.1 | ) |  | $ | 1,451.8 |  |

[0001327567-20-000007:notes:41]
|  | July 31, 2019 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 12.0 |  |  | $ | — |  |  | $ | — |  |  | $ | 12.0 |  |
| Commercial paper | 19.3 |  |  | — |  |  | — |  |  | 19.3 |  |
| U.S. government and agency securities | 54.4 |  |  | — |  |  | — |  |  | 54.4 |  |
| Total available-for-sale cash equivalents | $ | 85.7 |  |  | $ | — |  |  | $ | — |  |  | $ | 85.7 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 17.5 |  |  | $ | — |  |  | $ | — |  |  | $ | 17.5 |  |
| Commercial paper | 8.9 |  |  | — |  |  | — |  |  | 8.9 |  |
| Corporate debt securities | 587.8 |  |  | 2.3 |  |  | (0.3 | ) |  | 589.8 |  |
| U.S. government and agency securities | 1,799.5 |  |  | 2.6 |  |  | (1.2 | ) |  | 1,800.9 |  |
| Total available-for-sale investments | $ | 2,413.7 |  |  | $ | 4.9 |  |  | $ | (1.5 | ) |  | $ | 2,417.1 |  |

[0001327567-20-000007:notes:42]
Unrealized losses related to these securities are due to interest rate fluctuations as opposed to credit quality. In addition, we do not intend to sell and it is not likely that we would be required to sell these securities before recovery of their amortized cost basis, which may be at maturity. As a result, there were no other-than-temporary impairments for these securities at January 31, 2020 and July 31, 2019.

[0001327567-20-000007:notes:43]
The following table summarizes the amortized cost and fair value of our available-for-sale debt securities as of January 31, 2020, by contractual years-to-maturity (in millions):

[0001327567-20-000007:notes:44]
|  | Amortized Cost |  | Fair Value |
| Due within one year | $ | 1,676.7 |  |  | $ | 1,678.9 |  |
| Due between one and three years | 314.9 |  |  | 317.9 |  |
| Total | $ | 1,991.6 |  |  | $ | 1,996.8 |  |

[0001327567-20-000007:notes:45]
Marketable Equity Securities

[0001327567-20-000007:notes:46]
Marketable equity securities consist of money market funds and are included in cash and cash equivalents in our condensed consolidated balance sheets. As of January 31, 2020 and July 31, 2019, the carrying value of our marketable equity securities were $577.1 million and $369.1 million, respectively. There were no unrealized gains or losses recognized for these securities during the three and six months ended January 31, 2020 and 2019.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001327567-20-000007:notes:47]
[same as prior period, unchanged from 0001327567-19-000038:notes:48]

[0001327567-20-000007:notes:48]
[same as prior period, unchanged from 0001327567-19-000038:notes:49]

[0001327567-20-000007:notes:49]
[same as prior period, unchanged from 0001327567-19-000038:notes:50]

[0001327567-20-000007:notes:50]
As of January 31, 2020 and July 31, 2019, the total notional amount of our outstanding foreign currency forward contracts was $186.1 million and $307.2 million, respectively. Refer to Note 3. Fair Value Measurements for the fair value of our derivative instruments as reported on our condensed consolidated balance sheets as of January 31, 2020.

[0001327567-20-000007:notes:51]
During the three and six months ended January 31, 2020 and 2019, both unrealized gains and losses recognized in AOCI related to our cash flow hedges and amounts reclassified into earnings were not material. Unrealized losses in AOCI related to our cash flow hedges as of January 31, 2020 and 2019 were not material.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001327567-20-000007:notes:52]
Acquisitions
Aporeto, Inc.

[0001327567-20-000007:notes:53]
On December 23, 2019, we completed our acquisition of 100% of the voting interest of Aporeto, Inc., (“Aporeto”), a privately-held machine identity-based microsegmentation company. We believe the acquisition will strengthen our cloud-native security platform capabilities delivered by Prisma Cloud. The total purchase consideration for the acquisition of Aporeto was $144.1 million, which consisted of the following (in millions):

[0001327567-20-000007:notes:54]
|  | Amount |
| Cash | $ | 139.8 |  |
| Fair value of replacement awards | 4.3 |  |
| Total | $ | 144.1 |  |

[0001327567-20-000007:notes:55]
As part of the acquisition, we issued $16.4 million of replacement awards, of which the portion attributable to services performed prior to the acquisition date was allocated to purchase consideration. The remaining fair value was allocated to future services and will be expensed over the remaining service periods as share-based compensation.

[0001327567-20-000007:notes:56]
[same as prior period, unchanged from 0001327567-19-000038:notes:56]

[0001327567-20-000007:notes:57]
|  | Amount |
| Goodwill | $ | 111.3 |  |
| Identified intangible assets | 23.8 |  |
| Cash | 10.5 |  |
| Net liabilities assumed | (1.5 | ) |
| Total | $ | 144.1 |  |

[0001327567-20-000007:notes:58]
Goodwill generated from this business combination is primarily attributable to the assembled workforce and expected post-acquisition synergies from integrating Aporeto’s technology into our platforms. The goodwill is not deductible for income tax purposes.

[0001327567-20-000007:notes:59]
[same as prior period, unchanged from 0001327567-19-000038:notes:59]

[0001327567-20-000007:notes:60]
|  | Fair Value |  | Estimated Useful Life |
| Developed technology | $ | 20.5 |  |  | 7 years |
| Customer relationships | 3.3 |  |  | 4 years |
| Total | $ | 23.8 |  |  |  |

[0001327567-20-000007:notes:61]
Zingbox, Inc.

[0001327567-20-000007:notes:62]
On September 20, 2019, we completed our acquisition of 100% of the voting equity interest of Zingbox, Inc. (“Zingbox”), a privately-held Internet of Things (“IoT”) security company. We believe the acquisition will accelerate our delivery of IoT security through our Next-Generation Firewall and Cortex platforms. The total purchase consideration for the acquisition of Zingbox was $66.4 million in cash.

[0001327567-20-000007:notes:63]
[same as prior period, unchanged from 0001327567-19-000038:notes:55]

[0001327567-20-000007:notes:64]
[same as prior period, unchanged from 0001327567-19-000038:notes:57]

[0001327567-20-000007:notes:65]
[same as prior period, unchanged from 0001327567-19-000038:notes:58]

[0001327567-20-000007:notes:66]
[same as prior period, unchanged from 0001327567-19-000038:notes:60]

[0001327567-20-000007:notes:67]
Additional Acquisition-Related Information

[0001327567-20-000007:notes:68]
The operating results of the acquired companies are included in our condensed consolidated statements of operations from the dates of acquisition. Pro forma results of operations have not been presented because the effects of the acquisitions were not material to our condensed consolidated statements of operations.

[0001327567-20-000007:notes:69]
Additional information related to the acquired companies, such as that related to income tax and other contingencies, existing as of the respective acquisition dates but unknown to us may become known during the remainder of the measurement period, not to exceed 12 months from the acquisition date, which may result in changes to the amounts and allocations recorded.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001327567-20-000007:notes:70]
[same as prior period, unchanged from 0001327567-19-000038:notes:63]

[0001327567-20-000007:notes:71]
The following table presents details of our goodwill during the six months ended January 31, 2020 (in millions):

[0001327567-20-000007:notes:72]
|  | Amount |
| Balance as of July 31, 2019 | $ | 1,352.3 |  |
| Goodwill acquired | 159.4 |  |
| Balance as of January 31, 2020 | $ | 1,511.7 |  |

[0001327567-20-000007:notes:73]
[same as prior period, unchanged from 0001327567-19-000038:notes:66]

[0001327567-20-000007:notes:74]
The following table presents details of our purchased intangible assets as of January 31, 2020 and July 31, 2019 (in millions):

[0001327567-20-000007:notes:75]
|  | January 31, 2020 |  | July 31, 2019 |
|  | Gross Carrying Amount |  | Accumulated Amortization |  | Net Carrying Amount |  | Gross Carrying Amount |  | Accumulated Amortization |  | Net Carrying Amount |
| Intangible assets subject to amortization: |  |  |  |  |  |  |  |  |  |  |  |
| Developed technology | $ | 358.7 |  |  | $ | (110.0 | ) |  | $ | 248.7 |  |  | $ | 318.8 |  |  | $ | (78.7 | ) |  | $ | 240.1 |  |
| Customer relationships | 44.9 |  |  | (7.9 | ) |  | 37.0 |  |  | 39.8 |  |  | (4.7 | ) |  | 35.1 |  |
| Acquired intellectual property | 8.9 |  |  | (5.4 | ) |  | 3.5 |  |  | 8.9 |  |  | (5.1 | ) |  | 3.8 |  |
| Trade name and trademarks | 9.4 |  |  | (9.4 | ) |  | — |  |  | 9.4 |  |  | (9.4 | ) |  | — |  |
| Other | 2.2 |  |  | (2.2 | ) |  | — |  |  | 2.2 |  |  | (2.2 | ) |  | — |  |
| Total intangible assets subject to amortization | 424.1 |  |  | (134.9 | ) |  | 289.2 |  |  | 379.1 |  |  | (100.1 | ) |  | 279.0 |  |
| Intangible assets not subject to amortization: |  |  |  |  |  |  |  |  |  |  |  |
| In-process research and development | 0.8 |  |  | — |  |  | 0.8 |  |  | 1.6 |  |  | — |  |  | 1.6 |  |
| Total purchased intangible assets | $ | 424.9 |  |  | $ | (134.9 | ) |  | $ | 290.0 |  |  | $ | 380.7 |  |  | $ | (100.1 | ) |  | $ | 280.6 |  |

[0001327567-20-000007:notes:76]
We recognized amortization expense of $17.9 million and $34.8 million for the three and six months ended January 31, 2020, respectively, and $14.4 million and $23.8 million for the three and six months ended January 31, 2019, respectively.

[0001327567-20-000007:notes:77]
The following table summarizes estimated future amortization expense of our intangible assets as of January 31, 2020 (in millions):

[0001327567-20-000007:notes:78]
|  | Amount |
| Fiscal years ending July 31: |  |
| Remaining 2020 | $ | 37.0 |  |
| 2021 | 72.0 |  |
| 2022 | 67.5 |  |
| 2023 | 41.4 |  |
| 2024 | 33.3 |  |
| 2025 and thereafter | 38.0 |  |
| Total future amortization expense | $ | 289.2 |  |


## us-gaap:DebtDisclosureTextBlock

[0001327567-20-000007:notes:79]
Debt
Convertible Senior Notes

[0001327567-20-000007:notes:80]
In June 2014, we issued $575.0 million aggregate principal amount of 0.0% Convertible Senior Notes due 2019 (the “2019 Notes”), and in July 2018, we issued $1.7 billion aggregate principal amount of 0.75% Convertible Senior Notes due 2023 (the “2023 Notes” and, together with the 2019 Notes, the “Notes”). The 2023 Notes bear interest at a fixed rate of 0.75% per year, payable semi-annually in arrears on January 1 and July 1 of each year, beginning on January 1, 2019. The 2023 Notes are governed by an indenture between us, as the issuer, and U.S. Bank National Association, as Trustee (the “Indenture”). The 2023 Notes are unsecured, unsubordinated obligations and the Indenture governing the 2023 Notes does not contain any financial covenants or restrictions on the payments of dividends, the incurrence of indebtedness, or the issuance or repurchase of securities by us or any of our subsidiaries. The 2019 Notes were converted prior to or settled on the maturity date of July 1, 2019, in accordance with their terms. The 2023 Notes mature on July 1, 2023. We cannot redeem the 2023 Notes prior to maturity.

[0001327567-20-000007:notes:81]
The 2023 Notes are convertible for up to 6.4 million shares of our common stock at an initial conversion rate of approximately 3.7545 shares of common stock per $1,000 principal amount, which is equal to an initial conversion price of approximately $266.35 per share of common stock, subject to adjustments. Holders of the 2023 Notes may surrender their 2023 Notes for conversion at their option at any time prior to the close of business on the business day immediately preceding April 1, 2023, only under the following circumstances:

[0001327567-20-000007:notes:82]
| • | during any fiscal quarter commencing after the fiscal quarter ending on October 31, 2018 (and only during such fiscal quarter), if the last reported sale price of our common stock for at least 20 trading days (whether or not consecutive) during a period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the applicable conversion price for the 2023 Notes on each applicable trading day (the “sale price condition”); |

[0001327567-20-000007:notes:83]
| • | during the five business day period after any five consecutive trading day period (the “measurement period”), in which the trading price per $1,000 principal amount of the 2023 Notes for each trading day of the measurement period was less than 98% of the product of the last reported sale price of our common stock and the applicable conversion rate for the 2023 Notes on each such trading day; or |

[0001327567-20-000007:notes:84]
| • | upon the occurrence of specified corporate events. |

[0001327567-20-000007:notes:85]
On or after April 1, 2023, holders may surrender all or any portion of their 2023 Notes for conversion at any time prior to the close of business on the second scheduled trading day immediately preceding the maturity date regardless of the foregoing conditions, and such conversions will be settled upon the maturity date. Upon conversion, holders of the 2023 Notes will receive cash equal to the aggregate principal amount of the 2023 Notes to be converted, and, at our election, cash and/or shares of our common stock for any amounts in excess of the aggregate principal amount of the 2023 Notes being converted.

[0001327567-20-000007:notes:86]
The conversion price will be subject to adjustment in some events. Holders who convert their 2023 Notes in connection with certain corporate events that constitute a “make-whole fundamental change” under the Indenture are, under certain circumstances, entitled to an increase in the conversion rate. Additionally, upon the occurrence of a corporate event that constitutes a “fundamental change” under the Indenture, holders of the 2023 Notes may require us to repurchase for cash all or a portion of the 2023 Notes at a repurchase price equal to 100% of the principal amount of the 2023 Notes plus accrued and unpaid interest to, but excluding, the fundamental change repurchase date.

[0001327567-20-000007:notes:87]
The sale price condition was not met for the 2023 Notes during the fiscal quarters ended January 31, 2020 or July 31, 2019. Since the 2023 Notes were not convertible, the net carrying amount of the 2023 Notes was classified as a long-term liability and the

[0001327567-20-000007:notes:88]
equity component was included in additional paid-in capital in our condensed consolidated balance sheets as of January 31, 2020 and July 31, 2019. As of January 31, 2020, all of the 2023 Notes remained outstanding.

[0001327567-20-000007:notes:89]
The following table sets forth the components of the 2023 Notes as of January 31, 2020 and July 31, 2019 (in millions):

[0001327567-20-000007:notes:90]
|  | January 31, 2020 |  | July 31, 2019 |
| Liability component: |  |  |  |
| Principal | $ | 1,693.0 |  |  | $ | 1,693.0 |  |
| Less: debt discount and debt issuance costs, net of amortization | 231.8 |  |  | 263.0 |  |
| Net carrying amount | $ | 1,461.2 |  |  | $ | 1,430.0 |  |
| Equity component | $ | 315.0 |  |  | $ | 315.0 |  |

[0001327567-20-000007:notes:91]
The total estimated fair value of the 2023 Notes was $1.9 billion at both January 31, 2020 and July 31, 2019. The fair value was determined based on the closing trading price per $100 of the 2023 Notes as of the last day of trading for the period. We consider the fair value of the 2023 Notes at January 31, 2020 and July 31, 2019 to be a Level 2 measurement. The fair value of the 2023 Notes is primarily affected by the trading price of our common stock and market interest rates. Based on the closing price of our common stock on January 31, 2020, the if-converted value of the 2023 Notes was less than its principal amount.

[0001327567-20-000007:notes:92]
The following table sets forth interest expense recognized related to the Notes (dollars in millions):

[0001327567-20-000007:notes:93]
|  | Three Months Ended January 31, |  | Six Months Ended January 31, |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
|  | 2019 Notes |  | 2023 Notes |  | Total |  | 2019 Notes |  | 2023 Notes |  | Total |  | 2019 Notes |  | 2023 Notes |  | Total |  | 2019 Notes |  | 2023 Notes |  | Total |
| Contractual interest expense | $ | — |  |  | $ | 3.1 |  |  | $ | 3.1 |  |  | $ | — |  |  | $ | 3.1 |  |  | $ | 3.1 |  |  | $ | — |  |  | $ | 6.3 |  |  | $ | 6.3 |  |  | $ | — |  |  | $ | 6.3 |  |  | $ | 6.3 |  |
| Amortization of debt discount | — |  |  | 15.2 |  |  | 15.2 |  |  | 2.0 |  |  | 14.5 |  |  | 16.5 |  |  | — |  |  | 30.2 |  |  | 30.2 |  |  | 6.0 |  |  | 28.9 |  |  | 34.9 |  |
| Amortization of debt issuance costs | — |  |  | 0.5 |  |  | 0.5 |  |  | 0.2 |  |  | 0.4 |  |  | 0.6 |  |  | — |  |  | 1.0 |  |  | 1.0 |  |  | 0.7 |  |  | 0.9 |  |  | 1.6 |  |
| Total interest expense recognized | $ | — |  |  | $ | 18.8 |  |  | $ | 18.8 |  |  | $ | 2.2 |  |  | $ | 18.0 |  |  | $ | 20.2 |  |  | $ | — |  |  | $ | 37.5 |  |  | $ | 37.5 |  |  | $ | 6.7 |  |  | $ | 36.1 |  |  | $ | 42.8 |  |
| Effective interest rate of the liability component | — | % |  | 5.2 | % |  |  |  | 4.8 | % |  | 5.2 | % |  |  |  | — | % |  | 5.2 | % |  |  |  | 4.8 | % |  | 5.2 | % |  |  |

[0001327567-20-000007:notes:94]
Note Hedges

[0001327567-20-000007:notes:95]
To minimize the impact of potential economic dilution upon conversion of the Notes, we entered into separate convertible note hedge transactions (the “2019 Note Hedges,” with respect to the 2019 Notes, and the “2023 Note Hedges,” with respect to the 2023 Notes, and collectively, the “Note Hedges”) with respect to our common stock concurrent with the issuance of each series of Notes.

[0001327567-20-000007:notes:96]
Upon the settlement of the 2019 Notes, we exercised the corresponding portion of our 2019 Note Hedges during the year ended July 31, 2019 and received shares of our common stock that fully offset the shares issued in excess of the principal amount of the converted 2019 Notes. The 2019 Note Hedges expired upon maturity of the 2019 Notes.

[0001327567-20-000007:notes:97]
The 2023 Note Hedges cover up to 6.4 million shares of our common stock at a strike price per share that corresponds to the initial applicable conversion price of the 2023 Notes, which are also subject to adjustment, and are exercisable upon conversion of the 2023 Notes. The 2023 Note Hedges will expire upon maturity of the 2023 Notes. The 2023 Note Hedges are separate transactions and are not part of the terms of 2023 Notes. Holders of the 2023 Notes will not have any rights with respect to the 2023 Note Hedges. Any shares of our common stock receivable by us under the 2023 Note Hedges are excluded from the calculation of diluted earnings per share as they are antidilutive. We paid an aggregate amount of $332.0 million for the 2023 Note Hedges, which is included in additional paid-in capital in our consolidated balance sheets.

[0001327567-20-000007:notes:98]
Warrants

[0001327567-20-000007:notes:99]
Separately, but concurrently with the issuance of each series of Notes, we entered into transactions whereby we sold warrants (the “2019 Warrants,” with respect to the 2019 Notes, and the “2023 Warrants,” with respect to the 2023 Notes, and collectively, the

[0001327567-20-000007:notes:100]
“Warrants”) to acquire shares of our common stock, subject to anti-dilution adjustments. The 2019 Warrants became exercisable beginning October 2019 and the 2023 Warrants are exercisable beginning October 2023.

[0001327567-20-000007:notes:101]
The following table presents details of the Warrants (in millions, except per share data):

[0001327567-20-000007:notes:102]
|  | Initial Number of Shares |  | Strike Price per Share |  | Aggregate Proceeds |
| 2019 Warrants | 5.2 |  |  | $ | 137.85 |  |  | $ | 78.3 |  |
| 2023 Warrants | 6.4 |  |  | $ | 417.80 |  |  | $ | 145.4 |  |

[0001327567-20-000007:notes:103]
The shares issuable under the Warrants will be included in the calculation of diluted earnings per share when the average market value per share of our common stock for the reporting period exceeds the applicable strike price for such series of Warrants. The Warrants are separate transactions and are not part of either series of Notes or Note Hedges and are not remeasured through earnings each reporting period. Holders of the Notes of either series will not have any rights with respect to the Warrants. The aggregate proceeds received from the sale of the Warrants are included in additional paid-in capital in our consolidated balance sheets.

[0001327567-20-000007:notes:104]
During the six months ended January 31, 2020, we net settled all 2019 Warrants with approximately 2.0 million shares or $462.0 million in fair value of our common stock, of which 1.3 million shares or $308.4 million in fair value of our common stock were net settled during the three months ended January 31, 2020. The number of net shares issued was determined based on the number of 2019 Warrants exercised multiplied by the difference between the strike price of the 2019 Warrants and their daily volume weighted-average stock price.

[0001327567-20-000007:notes:105]
Revolving Credit Facility

[0001327567-20-000007:notes:106]
On September 4, 2018, we entered into a credit agreement (the “Credit Agreement”) with certain institutional lenders that provides for a $400.0 million unsecured revolving credit facility (the “Credit Facility”), with an option to increase the amount of the Credit Facility by up to an additional $350.0 million, subject to certain conditions. The Credit Facility matures on the earlier of (i) September 4, 2023 and (ii) the date that is 91 days prior to the stated maturity of our 2023 Notes if (a) any of the 2023 Notes are still outstanding and (b) our unrestricted cash and cash equivalents are less than the then outstanding principal amount of our 2023 Notes plus $400.0 million.

[0001327567-20-000007:notes:107]
The borrowings under the Credit Facility bear interest, at our option, at a base rate plus a spread of 0.00% to 0.75%, or an adjusted LIBO rate plus a spread of 1.00% to 1.75%, in each case with such spread being determined based on our leverage ratio. We are obligated to pay an ongoing commitment fee on undrawn amounts at a rate of 0.125% to 0.250%, depending on our leverage ratio. As of January 31, 2020, there were no amounts outstanding and we were in compliance with all covenants under the Credit Agreement.


## us-gaap:LesseeOperatingLeasesTextBlock

[0001327567-20-000007:notes:108]
[same as prior period, unchanged from 0001327567-19-000038:notes:100]

[0001327567-20-000007:notes:109]
[same as prior period, unchanged from 0001327567-19-000038:notes:101]

[0001327567-20-000007:notes:110]
[same as prior period, unchanged from 0001327567-19-000038:notes:102]

[0001327567-20-000007:notes:111]
[same as prior period, unchanged from 0001327567-19-000038:notes:103]

[0001327567-20-000007:notes:112]
[same as prior period, unchanged from 0001327567-19-000038:notes:104]

[0001327567-20-000007:notes:113]
In December 2019, we entered into lease termination agreements for our previous corporate headquarters in Santa Clara, California, which we ceased use of in August 2017. Under the arrangements, we terminated these leases effective in December 2019, prior to their expiration date of July 2023. The early termination fee is $25.0 million, payable in equal quarterly installments from April 2020 through July 2023. Upon termination, we recorded a decrease of $13.6 million in operating lease liabilities based on the payment schedule of the early termination fee discounted by the incremental borrowing rate for the remaining payment term. We also decreased right-of-use asset by $8.7 million upon surrendering possession of the properties. As a result, during the three months ended January 31, 2020, we recorded a gain of $3.1 million net of other related fees of $1.8 million in general and administrative expense in our condensed consolidated statements of operations.

[0001327567-20-000007:notes:114]
During the three months ended January 31, 2020, our net cost for operating leases was $16.6 million and primarily consisted of operating lease costs of $14.5 million, in addition to variable lease costs, short-term lease costs, and sublease income. During the six months ended January 31, 2020, our net cost for operating leases was $33.4 million and primarily consisted of operating lease costs of $29.2 million, in addition to variable lease costs, short-term lease costs and sublease income.

[0001327567-20-000007:notes:115]
[same as prior period, unchanged from 0001327567-19-000038:notes:106]

[0001327567-20-000007:notes:116]
|  | Six Months Ended |
|  | January 31, 2020 |
| Operating cash flows used in payments of operating lease liabilities | $ | 34.7 |  |
| Right-of-use assets obtained in exchange for new operating lease liabilities | $ | 14.0 |  |
|  | January 31, 2020 |
| Weighted-average remaining lease term | 7.7 years |  |
| Weighted-average discount rate | 3.9 | % |

[0001327567-20-000007:notes:117]
The following table presents maturities of operating lease liabilities as of January 31, 2020 (in millions):

[0001327567-20-000007:notes:118]
|  | Amount |
| Fiscal years ending July 31: |  |
| Remaining 2020 | $ | 33.5 |  |
| 2021 | 71.8 |  |
| 2022 | 66.0 |  |
| 2023 | 60.1 |  |
| 2024 | 49.4 |  |
| 2025 and thereafter | 193.0 |  |
| Total operating lease payments | 473.8 |  |
| Less: imputed interest | 65.5 |  |
| Present value of operating lease liabilities | $ | 408.3 |  |
| Current portion of operating lease liabilities(1) | $ | 54.8 |  |
| Long-term operating lease liabilities | $ | 353.5 |  |

[0001327567-20-000007:notes:119]
[same as prior period, unchanged from 0001327567-19-000038:notes:110]

[0001327567-20-000007:notes:120]
[same as prior period, unchanged from 0001327567-19-000038:notes:111]

[0001327567-20-000007:notes:121]
Operating lease liabilities above do not include sublease income. As of January 31, 2020, we expect to receive sublease income of approximately $6.4 million, which consists of $2.6 million to be received for the remainder of fiscal 2020 and $3.8 million to be received in fiscal 2021.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001327567-20-000007:notes:122]
Commitments and Contingencies
Purchase Commitments

[0001327567-20-000007:notes:123]
Manufacturing Purchase Commitments

[0001327567-20-000007:notes:124]
Our electronics manufacturing service provider (“EMS provider”) procures components and assembles our products based on our forecasts. These forecasts are based on estimates of demand for our products primarily for the next 12 months, which are in turn based on historical trends and an analysis from our sales and product management organizations, adjusted for overall market conditions. In order to reduce manufacturing lead times and plan for adequate supply, we may issue non-cancelable orders for products and components to our manufacturing partners or component suppliers. As of January 31, 2020, our purchase commitments under such orders were $106.0 million, excluding obligations under contracts that we can cancel without a significant penalty.

[0001327567-20-000007:notes:125]
Other Purchase Commitments

[0001327567-20-000007:notes:126]
We have entered into various non-cancelable agreements with third-party providers for our use of certain cloud and other services, under which we are committed to minimum or fixed purchases through the year ending July 31, 2026. The following table presents details of the aggregate future non-cancelable purchase commitments under these agreements as of January 31, 2020 (in millions):

[0001327567-20-000007:notes:127]
|  | Amount |
| Fiscal years ending July 31: |  |
| Remaining 2020 | $ | 2.3 |  |
| 2021 | 14.5 |  |
| 2022 | 59.3 |  |
| 2023 | 58.5 |  |
| 2024 | 67.5 |  |
| 2025 and thereafter | 97.5 |  |
| Total other purchase commitments | $ | 299.6 |  |

[0001327567-20-000007:notes:128]
Mutual Covenant Not to Sue and Release Agreement

[0001327567-20-000007:notes:129]
In January 2020, we executed a Mutual Covenant Not to Sue and Release Agreement for $50.0 million, to extend an existing covenant not to sue for seven years. As the primary benefit of the arrangement was attributable to future use, we recorded $50.0 million in other assets and a corresponding balance in accrued and other liabilities on our condensed consolidated balance sheets as of January 31, 2020. The amount recorded in other assets will be amortized to cost of product revenue in our condensed consolidated statements of operations over the estimated period of benefit of seven years.

[0001327567-20-000007:notes:130]
Litigation

[0001327567-20-000007:notes:131]
We are subject to legal proceedings, claims, and litigation arising in the ordinary course of business, including intellectual property litigation. Such matters are subject to many uncertainties and outcomes are not predictable with assurance. We accrue for contingencies when we believe that a loss is probable and that we can reasonably estimate the amount of any such loss.

[0001327567-20-000007:notes:132]
To the extent there is a reasonable possibility that a loss exceeding amounts already recognized may be incurred and the amount of such additional loss would be material, we will either disclose the estimated additional loss or state that such an estimate cannot be made. As of January 31, 2020, we have not recorded any significant accruals for loss contingencies associated with such legal proceedings, determined that an unfavorable outcome is probable or reasonably possible, or determined that the amount or range of any possible loss is reasonably estimable.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001327567-20-000007:notes:133]
[same as prior period, unchanged from 0001327567-19-000038:notes:122]

[0001327567-20-000007:notes:134]
In February 2019, our board of directors authorized a $1.0 billion share repurchase program which is funded from available working capital. Repurchases may be made at management’s discretion from time to time on the open market, through privately negotiated transactions, transactions structured through investment banking institutions, block purchase techniques, 10b5-1 trading plans, or a combination of the foregoing. This repurchase authorization will expire on December 31, 2020 and may be suspended or discontinued at any time.

[0001327567-20-000007:notes:135]
During the six months ended January 31, 2020, we repurchased and retired 0.9 million shares of our common stock under the authorization for an aggregate purchase price of $198.1 million, including transaction costs. The total price of the shares repurchased and related transaction costs are reflected as a reduction to common stock and additional paid-in capital on our condensed consolidated balance sheets. As of January 31, 2020, $801.9 million remained available for future share repurchases under our current repurchase authorization.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001327567-20-000007:notes:136]
[same as prior period, unchanged from 0001327567-19-000038:notes:125]

[0001327567-20-000007:notes:137]
Aporeto Inc. Stock Incentive Plan

[0001327567-20-000007:notes:138]
In connection with our acquisition of Aporeto in December 2019, we assumed Aporeto’s 2015 Stock Option and Grant Plan, as amended and restated (the “Aporeto Plan”), under which the assumed Aporeto equity awards were granted. The assumed equity awards will be settled in shares of our common stock and will retain the terms and conditions under which they were originally granted; forfeited awards will not be returned to the Aporeto Plan. No additional equity awards will be granted under the Aporeto Plan. Refer to Note 6. Acquisitions for more information on the Aporeto acquisition and the related equity awards assumed.

[0001327567-20-000007:notes:139]
[same as prior period, unchanged from 0001327567-19-000038:notes:126]

[0001327567-20-000007:notes:140]
[same as prior period, unchanged from 0001327567-19-000038:notes:127]

[0001327567-20-000007:notes:141]
[same as prior period, unchanged from 0001327567-19-000038:notes:128]

[0001327567-20-000007:notes:142]
[same as prior period, unchanged from 0001327567-19-000038:notes:129]

[0001327567-20-000007:notes:143]
|  | Stock Options Outstanding |  | PSOs Outstanding |
|  | Number of Shares |  | Weighted-Average Exercise Price Per Share |  | Weighted-Average Remaining Contractual Term(Years) |  | Aggregate Intrinsic Value |  | Number of Shares |  | Weighted-Average Exercise Price Per Share |  | Weighted-Average Remaining Contractual Term(Years) |  | Aggregate Intrinsic Value |
| Balance—July 31, 2019 | 0.3 |  |  | $ | 14.53 |  |  | 2.2 |  | $ | 81.4 |  |  | 3.7 |  |  | $ | 193.99 |  |  | 6.2 |  | $ | 120.1 |  |
| Exercised | (0.1) |  |  | $ | 10.86 |  |  |  |  |  |  | — |  |  | $ | — |  |  |  |  |  |
| Forfeited | — |  |  | $ | — |  |  |  |  |  |  | (0.8) |  |  | $ | 193.51 |  |  |  |  |  |
| Balance—January 31, 2020 | 0.2 |  |  | $ | 17.39 |  |  | 1.9 |  | $ | 46.9 |  |  | 2.9 |  |  | $ | 194.11 |  |  | 5.7 |  | $ | 119.3 |  |
| Exercisable—January 31, 2020 | 0.2 |  |  | $ | 17.39 |  |  | 1.9 |  | $ | 46.9 |  |  | 2.9 |  |  | $ | 194.11 |  |  | 5.7 |  | $ | 119.3 |  |

[0001327567-20-000007:notes:144]
[same as prior period, unchanged from 0001327567-19-000038:notes:131]

[0001327567-20-000007:notes:145]
[same as prior period, unchanged from 0001327567-19-000038:notes:132]

[0001327567-20-000007:notes:146]
|  | RSAs Outstanding |  | PSAs Outstanding |
|  | Number of Shares |  | Weighted-Average Grant-Date Fair Value Per Share |  | Number of Shares |  | Weighted-Average Grant-Date Fair Value Per Share |
| Balance—July 31, 2019 | 0.0 |  |  | $ | 148.54 |  |  | 0.1 |  |  | $ | 148.54 |  |
| Vested | 0.0 |  |  | $ | 148.54 |  |  | 0.0 |  |  | $ | 148.54 |  |
| Balance—January 31, 2020 | 0.0 |  |  | $ | 148.54 |  |  | 0.1 |  |  | $ | 148.54 |  |

[0001327567-20-000007:notes:147]
[same as prior period, unchanged from 0001327567-19-000038:notes:134]

[0001327567-20-000007:notes:148]
|  | RSUs Outstanding |  | PSUs Outstanding |
|  | Number of Shares |  | Weighted-Average Grant-Date Fair Value Per Share |  | Weighted-Average Remaining Contractual Term(Years) |  | Aggregate Intrinsic Value |  | Number of Shares |  | Weighted-Average Grant-Date Fair Value Per Share |  | Weighted-Average Remaining Contractual Term(Years) |  | Aggregate Intrinsic Value |
| Balance—July 31, 2019 | 6.9 |  | $ | 188.16 |  |  | 1.5 |  | $ | 1,554.0 |  |  | 0.3 |  |  | $ | 197.86 |  |  | 1.8 |  | $ | 67.0 |  |
| Granted | 2.0 |  | $ | 217.39 |  |  |  |  |  |  | — |  |  | $ | — |  |  |  |  |  |
| Vested | (1.4) |  | $ | 175.68 |  |  |  |  |  |  | 0.0 |  |  | $ | 169.41 |  |  |  |  |  |
| Forfeited | (0.5) |  | $ | 183.16 |  |  |  |  |  |  | (0.1) |  |  | $ | 181.48 |  |  |  |  |  |
| Balance—January 31, 2020 | 7.0 |  | $ | 199.40 |  |  | 1.5 |  | $ | 1,641.2 |  |  | 0.2 |  |  | $ | 201.03 |  |  | 1.5 |  | $ | 53.0 |  |

[0001327567-20-000007:notes:149]
Our PSAs and PSUs generally vest over a period of three to four years from the date of grant. The actual number of PSAs and PSUs earned and eligible to vest is determined based on level of achievement against pre-established billings or revenue growth targets for the fiscal year. We recognize share-based compensation expense for our PSAs and PSUs on a straight-line basis over the requisite service period for each separately vesting portion of the award when it is probable that the performance condition will be achieved.

[0001327567-20-000007:notes:150]
[same as prior period, unchanged from 0001327567-19-000038:notes:138]

[0001327567-20-000007:notes:151]
[same as prior period, unchanged from 0001327567-19-000038:notes:139]

[0001327567-20-000007:notes:152]
|  | Three Months Ended |  | Six Months Ended |
|  | January 31, |  | January 31, |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Cost of product revenue | $ | 1.6 |  |  | $ | 1.4 |  |  | $ | 2.9 |  |  | $ | 3.0 |  |
| Cost of subscription and support revenue | 20.0 |  |  | 18.2 |  |  | 38.9 |  |  | 35.7 |  |
| Research and development | 67.0 |  |  | 44.0 |  |  | 129.4 |  |  | 84.5 |  |
| Sales and marketing | 54.9 |  |  | 58.7 |  |  | 98.7 |  |  | 114.7 |  |
| General and administrative | 29.4 |  |  | 20.1 |  |  | 54.2 |  |  | 55.6 |  |
| Total share-based compensation | $ | 172.9 |  |  | $ | 142.4 |  |  | $ | 324.1 |  |  | $ | 293.5 |  |

[0001327567-20-000007:notes:153]
During the three and six months ended January 31, 2020, we accelerated the vesting of certain equity awards in connection with our acquisitions, as a result, we recorded $4.4 million and $5.7 million, respectively, of share-based compensation within general and administrative expense.

[0001327567-20-000007:notes:154]
As of January 31, 2020, total compensation cost related to unvested share-based awards not yet recognized was $1.5 billion. This cost is expected to be amortized over a weighted-average period of approximately 2.7 years. Future grants will increase the amount of compensation expense to be recorded in these periods.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001327567-20-000007:notes:155]
Income Taxes
Our provision for income taxes for the three and six months ended January 31, 2020 reflects an effective tax rate of negative 20.6% and negative 15.3%, respectively. Our effective tax rate for the six months ended January 31, 2020 was negative as we recorded a provision for income taxes on year to date losses. The provision for income taxes for the six months ended January 31, 2020 is primarily due to income taxes in profitable foreign jurisdictions, U.S. state taxes, and withholding taxes. Our effective tax rates differ from the U.S. statutory tax rate primarily due to deductibility of our share-based compensation, foreign income at other than U.S. tax rates, and changes in our valuation allowance.

[0001327567-20-000007:notes:156]
In December 2019, we transferred certain intellectual property rights to a wholly owned United Kingdom subsidiary, primarily to align our legal structure to our evolving operations. This resulted in an increase in the tax basis of these intellectual property rights and a corresponding increase in foreign deferred tax assets. As of January 31, 2020, it is not more likely than not that these additional deferred tax assets will be realizable, and therefore, are offset by a full valuation allowance. This resulted in no net impact to our condensed consolidated financial statements.

[0001327567-20-000007:notes:157]
Our provision for income taxes for the three and six months ended January 31, 2019 reflects an effective tax rate of 230.0% and negative 2.8%, respectively. Our effective tax rate for the six months ended January 31, 2019 was negative as we recorded a provision

[0001327567-20-000007:notes:158]
for income taxes on year to date losses. The key components of our income tax provision, excluding one-time items, primarily consisted of foreign income taxes and withholding taxes. During the six months ended January 31, 2019, the effect of these key components was primarily offset by a one-time tax benefit of $9.4 million from a partial release of our valuation allowance related to the acquisition of RedLock Inc. Our effective tax rate differed from the U.S. statutory tax rate primarily due to deductibility of our share-based compensation, foreign income at other than U.S. tax rates, and changes in our valuation allowance.


## us-gaap:EarningsPerShareTextBlock

[0001327567-20-000007:notes:159]
[same as prior period, unchanged from 0001327567-19-000038:notes:144]

[0001327567-20-000007:notes:160]
[same as prior period, unchanged from 0001327567-19-000038:notes:145]

[0001327567-20-000007:notes:161]
|  | Three Months Ended |  | Six Months Ended |
|  | January 31, |  | January 31, |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Net loss | $ | (73.7 | ) |  | $ | (2.6 | ) |  | $ | (133.3 | ) |  | $ | (40.9 | ) |
| Weighted-average shares used to compute net loss per share, basic and diluted | 98.3 |  |  | 94.0 |  |  | 97.5 |  |  | 93.9 |  |
| Net loss per share, basic and diluted | $ | (0.75 | ) |  | $ | (0.03 | ) |  | $ | (1.37 | ) |  | $ | (0.44 | ) |

[0001327567-20-000007:notes:162]
[same as prior period, unchanged from 0001327567-19-000038:notes:147]

[0001327567-20-000007:notes:163]
|  | Three and Six Months Ended |
|  | January 31, |
|  | 2020 |  | 2019 |
| Convertible senior notes | 6.4 |  |  | 7.8 |  |
| Warrants related to the issuance of convertible senior notes | 6.4 |  |  | 11.6 |  |
| RSUs and PSUs | 7.2 |  |  | 7.1 |  |
| Options to purchase common stock, including PSOs | 3.1 |  |  | 4.4 |  |
| RSAs and PSAs | 0.1 |  |  | 0.1 |  |
| ESPP shares | 0.2 |  |  | 0.2 |  |
| Total | 23.4 |  |  | 31.2 |  |


## us-gaap:OtherNonoperatingIncomeAndExpenseTextBlock

[0001327567-20-000007:notes:164]
[same as prior period, unchanged from 0001327567-19-000038:notes:149]

[0001327567-20-000007:notes:165]
|  | Three Months Ended |  | Six Months Ended |
|  | January 31, |  | January 31, |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Interest income | $ | 13.9 |  |  | $ | 18.0 |  |  | $ | 29.7 |  |  | $ | 33.4 |  |
| Foreign currency exchange gains (losses), net | (2.4 | ) |  | (1.2 | ) |  | (2.0 | ) |  | (1.2 | ) |
| Other | (0.7 | ) |  | (0.8 | ) |  | (0.7 | ) |  | (3.2 | ) |
| Total other income, net | $ | 10.8 |  |  | $ | 16.0 |  |  | $ | 27.0 |  |  | $ | 29.0 |  |


## us-gaap:SubsequentEventsTextBlock

[0001327567-20-000007:notes:166]
Subsequent Events
Accelerated Share Repurchase

[0001327567-20-000007:notes:167]
On February 21, 2020, our board of directors approved the repurchase of $1.0 billion of our common stock through an accelerated share repurchase (“ASR”) transaction, which we expect to enter into during our fiscal quarter ending April 30, 2020, subject to market conditions. The ASR transaction is in addition to our $1.0 billion share repurchase program that our board of directors authorized in February 2019.

[0001327567-20-000007:notes:168]
Land Purchase Agreement

[0001327567-20-000007:notes:169]
In February 2020, we entered into an agreement to purchase 5.8 acres of land adjacent to our headquarters in Santa Clara, California for $51.0 million in cash.  The arrangement is expected to close during our fiscal quarter ending April 30, 2020.
