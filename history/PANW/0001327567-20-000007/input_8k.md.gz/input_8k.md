# PANW 8-K — 0001327567-20-000002 filed 2020-02-24

## item codes, every 8-K on or before 2020-02-25

- 2020-02-24 0001327567-20-000002 — 2.02, 9.01
- 2019-12-19 0001193125-19-319166 — 1.02, 9.01
- 2019-12-10 0001193125-19-310251 — 5.07
- 2019-11-25 0001327567-19-000036 — 2.02, 9.01
- 2019-11-25 0001193125-19-299886 — 5.02, 8.01 — amendment of 0001327567-19-000011
- 2019-10-22 0001193125-19-271660 — 5.02
- 2019-09-06 0001327567-19-000026 — 9.01 — amendment of 0001327567-19-000023
- 2019-09-04 0001327567-19-000023 — 2.02, 7.01, 9.01
- 2019-07-11 0001193125-19-192415 — 5.02, 9.01
- 2019-05-29 0001327567-19-000014 — 2.02, 9.01
- 2019-04-15 0001327567-19-000011 — 5.02, 9.01
- 2019-04-01 0001193125-19-094613 — 8.01, 9.01
- 2019-03-28 0001193125-19-090572 — 3.02 — amendment of 0001327567-19-000003
- 2019-02-26 0001327567-19-000006 — 2.02, 8.01, 9.01
- 2019-02-19 0001327567-19-000003 — 3.02
- 2018-12-11 0001327567-18-000033 — 5.07
- 2018-11-29 0001327567-18-000029 — 2.02, 9.01
- 2018-10-15 0001193125-18-299312 — 5.02, 9.01
- 2018-09-25 0001193125-18-282542 — 5.02
- 2018-09-14 0001193125-18-274239 — 5.03, 9.01
- 2018-09-06 0001327567-18-000018 — 1.01, 2.02, 2.03, 9.01
- 2018-07-13 0001193125-18-217281 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2018-06-04 0001327567-18-000011 — 2.02, 5.02, 9.01
- 2018-02-26 0001327567-18-000004 — 2.02, 5.02, 7.01, 9.01
- 2017-12-12 0001193125-17-367477 — 5.07
- 2017-11-20 0001327567-17-000032 — 2.02, 5.02, 9.01
- 2017-08-31 0001327567-17-000021 — 2.02, 5.02, 9.01
- 2017-05-31 0001327567-17-000016 — 2.02, 9.01
- 2017-02-28 0001327567-17-000005 — 2.02, 8.01, 9.01
- 2016-12-12 0001193125-16-790757 — 5.07
- 2016-11-21 0001327567-16-000071 — 2.02, 9.01
- 2016-10-24 0001193125-16-745121 — 5.02, 9.01
- 2016-08-30 0001327567-16-000057 — 2.02, 5.03, 8.01, 9.01
- 2016-08-22 0001193125-16-687588 — 5.02, 9.01
- 2016-05-26 0001327567-16-000051 — 2.02, 9.01
- 2016-02-25 0001327567-16-000044 — 2.02, 5.02, 9.01
- 2015-12-14 0001327567-15-000038 — 5.07
- 2015-12-14 0001193125-15-402588 — 1.01, 9.01
- 2015-11-23 0001327567-15-000033 — 2.02, 9.01
- 2015-10-19 0001193125-15-347005 — 1.01, 9.01 — amendment, the index does not say of what
- 2015-09-09 0001327567-15-000022 — 2.02, 9.01
- 2015-08-19 0001193125-15-296115 — 1.01, 2.03
- 2015-06-01 0001193125-15-207786 — 1.01, 2.03
- 2015-05-27 0001327567-15-000015 — 2.02, 9.01
- 2015-03-02 0001327567-15-000006 — 2.02, 9.01
- 2014-12-15 0001327567-14-000046 — 5.07
- 2014-11-24 0001327567-14-000040 — 2.02, 9.01
- 2014-09-22 0001193125-14-348581 — 5.02, 9.01
- 2014-09-09 0001327567-14-000025 — 2.02, 9.01
- 2014-07-01 0001193125-14-257824 — 1.01, 2.03, 3.02, 9.01
- 2014-06-26 0001193125-14-249529 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2014-06-20 0001327567-14-000020 — 9.01 — amendment of 0001193125-14-140511
- 2014-06-04 0001327567-14-000016 — 3.02
- 2014-05-30 0001193125-14-218158 — 2.02 — amendment, the index does not say of what
- 2014-05-28 0001193125-14-215060 — 1.01, 2.02, 3.02, 9.01
- 2014-04-11 0001193125-14-140511 — 2.01, 3.02, 7.01, 9.01
- 2014-03-24 0001193125-14-111318 — 1.01, 3.02, 7.01, 9.01
- 2014-03-13 0001327567-14-000009 — 5.02
- 2014-02-24 0001193125-14-063754 — 2.02, 9.01
- 2013-12-12 0001327567-13-000040 — 5.07
- 2013-11-25 0001327567-13-000033 — 2.02, 9.01
- 2013-09-30 0001193125-13-384966 — 8.01
- 2013-09-09 0001193125-13-361421 — 2.02, 9.01
- 2013-05-30 0001193125-13-241542 — 2.02, 5.02, 9.01
- 2013-03-11 0001193125-13-101082 — 5.02, 9.01
- 2013-02-28 0001193125-13-084193 — 2.02, 9.01
- 2012-12-14 0001193125-12-503335 — 5.07
- 2012-12-06 0001193125-12-493700 — 2.02, 9.01
- 2012-09-24 0001193125-12-401534 — 1.01, 2.03
- 2012-09-20 0001193125-12-398433 — 5.02, 9.01
- 2012-09-10 0001193125-12-386605 — 2.02, 9.01

## late-filing notifications on or before 2020-02-25

- none on or before 2020-02-25

## item 2.02 — earnings release, exhibit 99.1

[0001327567-20-000002:8k_2_02:1]
EX-99.1
2
ex991q220earningsrelease.htm
EXHIBIT 99.1

[0001327567-20-000002:8k_2_02:2]
Exhibit

[0001327567-20-000002:8k_2_02:3]
Exhibit 99.1

[0001327567-20-000002:8k_2_02:4]
Palo Alto Networks Reports Fiscal Second Quarter 2020 Financial Results

[0001327567-20-000002:8k_2_02:5]
| • | Fiscal second quarter revenue grows 15% year over year to $816.7 million |

[0001327567-20-000002:8k_2_02:6]
| • | Billings increase 17% year over year to $998.9 million |

[0001327567-20-000002:8k_2_02:7]
| • | Deferred revenue grows 27% year over year to $3.2 billion |

[0001327567-20-000002:8k_2_02:8]
| • | Announces proposed $1 billion accelerated share repurchase transaction |

[0001327567-20-000002:8k_2_02:9]
SANTA CLARA, Calif. - Feb. 24, 2020 - Palo Alto Networks (NYSE: PANW), the global cybersecurity leader, announced today financial results for its fiscal second quarter 2020, ended January 31, 2020.

[0001327567-20-000002:8k_2_02:10]
Total revenue for the fiscal second quarter 2020 grew 15% year over year to $816.7 million, compared with total revenue of $711.2 million for the fiscal second quarter 2019. GAAP net loss for the fiscal second quarter 2020 was $73.7 million, or $0.75 per diluted share, compared with GAAP net loss of $2.6 million, or $0.03 per diluted share, for the fiscal second quarter 2019.

[0001327567-20-000002:8k_2_02:11]
Non-GAAP net income for the fiscal second quarter 2020 was $120.3 million, or $1.19 per diluted share, compared with non-GAAP net income of $147.0 million, or $1.51 per diluted share, for the fiscal second quarter 2019. A reconciliation between GAAP and non-GAAP information is contained in the tables below.

[0001327567-20-000002:8k_2_02:12]
“Our fiscal second quarter displayed many signs of positive momentum; notably billings for our Next-Generation Security offerings continued to perform very well. As customers progress on their journey to the cloud and elevate cybersecurity as an integral part of network transformations, Palo Alto Networks remains a trusted partner to organizations worldwide,” said Nikesh Arora, chairman and CEO of Palo Alto Networks. “Fiscal second quarter revenue was below our expectations primarily as a result of continued impact of sales incentives related to our Next-Generation Security products from our prior fiscal year. We have made progress to address this and have implemented several go-to-market programs to reignite our firewall sales growth.”

[0001327567-20-000002:8k_2_02:13]
Accelerated Share Repurchase

[0001327567-20-000002:8k_2_02:14]
The Company’s board of directors authorized the Company to enter into a $1 billion accelerated share repurchase (“ASR”) transaction. The Company intends to enter into an ASR transaction with a financial institution during its fiscal third quarter 2020, subject to market conditions. The ASR transaction is in addition to the Company’s $1 billion share repurchase program that was announced in February 2019. As of January 31, 2020, $801.9 million remained available for future share repurchases under this program.

[0001327567-20-000002:8k_2_02:15]
Financial Outlook

[0001327567-20-000002:8k_2_02:16]
Palo Alto Networks provides guidance based on current market conditions and expectations.

[0001327567-20-000002:8k_2_02:17]
For the fiscal third quarter 2020, we expect:

[0001327567-20-000002:8k_2_02:18]
| • | Total revenue in the range of $835 to $850 million, representing year-over-year growth between 15% and 17%. |

[0001327567-20-000002:8k_2_02:19]
| • | Total billings in the range of $980 million to $1.000 billion, representing year-over-year growth between 19% and 22%. |

[0001327567-20-000002:8k_2_02:20]
| • | Diluted non-GAAP net income per share in the range of $0.96 to $0.98, using 99.5 to 101.5 million shares. |

[0001327567-20-000002:8k_2_02:21]
For the fiscal year 2020, we expect:

[0001327567-20-000002:8k_2_02:22]
| • | Total revenue in the range of $3.350 to $3.390 billion, representing year-over-year growth between 16% and 17%. |

[0001327567-20-000002:8k_2_02:23]
| • | Total billings in the range of $4.075 to $4.125 billion, representing year-over-year growth between 17% and 18%. |

[0001327567-20-000002:8k_2_02:24]
| • | Diluted non-GAAP net income per share in the range of $4.55 to $4.65, using 99 to 101 million shares. |

[0001327567-20-000002:8k_2_02:25]
| • | Adjusted free cash flow margin of approximately 28%, which excludes cash flow associated with the additional investment in its headquarters in Santa Clara and a cash payment associated with a litigation-related settlement. |

[0001327567-20-000002:8k_2_02:26]
Guidance for non-GAAP financial measures excludes share-based compensation-related charges, including share-based payroll tax expense, acquisition-related costs, amortization expense of acquired intangible assets, litigation-related charges, including legal settlements, gains (losses) related to facility exit, non-cash charges related to convertible notes, foreign currency gains (losses), and income and other tax effects associated with these items, along

[0001327567-20-000002:8k_2_02:27]
with certain non-recurring expenses. We have not reconciled diluted non-GAAP net income per share guidance to GAAP net income (loss) per diluted share because we do not provide guidance on GAAP net income (loss) and would not be able to present the various reconciling cash and non-cash items between GAAP net income (loss) and non-GAAP net income, including share-based compensation expense, without unreasonable effort. Share-based compensation expense is impacted by the company's future hiring and retention needs and, to a lesser extent, the future fair market value of the company's common stock, all of which is difficult to predict and subject to constant change. The actual amounts of such reconciling items will have a significant impact on the company's GAAP net income (loss) per diluted share.

[0001327567-20-000002:8k_2_02:28]
Conference Call Information

[0001327567-20-000002:8k_2_02:29]
Palo Alto Networks will host a conference call for analysts and investors to discuss its fiscal second quarter 2020 results and outlook for its fiscal third quarter and full fiscal year 2020 today at 4:30 p.m. Eastern time/1:30 p.m. Pacific time. Open to the public, investors may access the call by dialing 1-888-254-3590 or 1-720-543-0214 and using conference ID 2494262. A live audio webcast of the conference call, along with supplemental financial information, will also be accessible from the “Investors” section of our website at investors.paloaltonetworks.com. Following the webcast, an archived version will be available on our website for one year. A telephonic replay of the call will be available three hours after the call, will run for ten days, and may be accessed by dialing 1-888-203-1112 or 1-719-457-0820 and entering the passcode 2494262.

[0001327567-20-000002:8k_2_02:30]
Investor Briefing at RSA

[0001327567-20-000002:8k_2_02:31]
Palo Alto Networks announced today that members of its management team will host an investor briefing during the RSA Conference 2020 in San Francisco, California, on Tuesday, February 25, 2020, at 4:00 p.m. Eastern time/1:00 p.m. Pacific time. The in-person event is by invitation only; however, it will be simultaneously accessible via phone and webcast. Investors may access the session by dialing +1 323-794-2442 and using conference ID 408471. A live audio webcast of the session will be accessible from the “Investors” section of the Palo Alto Networks website at investors.paloaltonetworks.com. Space for the event is limited, and preregistration is required.

[0001327567-20-000002:8k_2_02:32]
3

[0001327567-20-000002:8k_2_02:33]
Forward-Looking Statements

[0001327567-20-000002:8k_2_02:34]
This press release contains forward-looking statements that involve risks and uncertainties, including statements regarding (1) our proposed ASR transaction, and (2) our financial outlook for the fiscal third quarter and full fiscal year 2020. With respect to our proposed ASR transaction, our ability to execute such a transaction is subject to risks and uncertainties including, (1) developments or changes in economic or market conditions, (2) developments or changes in the securities markets, and (3) fluctuations in the trading volume and market price of our common stock.  With respect to our financial outlook for the fiscal third quarter and full fiscal year 2020, there are a significant number of factors that could cause actual results to differ materially from statements made in this press release, including: our ability as an organization to acquire and integrate other companies, products or technologies in a successful manner; risks associated with managing our growth; the risks associated with new products and subscription and support offerings, including the discovery of software bugs; our competitive position; our ability to attract and retain new customers; delays in the development or release of new subscription offerings, or the failure to timely develop and achieve market acceptance of new products and subscriptions as well as existing products and subscription and support offerings; rapidly evolving technological developments in the market for security products and subscription and support offerings; length of sales cycles; the coronavirus’s effect on our supply chain and our ability to ship products; and general market, political, economic, and business conditions.

[0001327567-20-000002:8k_2_02:35]
Additional risks and uncertainties that could affect our financial results are included under the captions “Risk Factors” and “Management’s Discussion and Analysis of Financial Condition and Results of Operations” in our Quarterly Report on Form 10-Q filed with the SEC on November 26, 2019, which is available on our website at investors.paloaltonetworks.com and on the SEC’s website at www.sec.gov. Additional information will also be set forth in other filings that we make with the SEC from time to time. All forward-looking statements in this press release are based on information available to us as of the date hereof, and we do not assume any obligation to update the forward-looking statements provided to reflect events that occur or circumstances that exist after the date on which they were made.

[0001327567-20-000002:8k_2_02:36]
Non-GAAP Financial Measures and Other Key Metrics

[0001327567-20-000002:8k_2_02:37]
Palo Alto Networks has provided in this press release financial information that has not been prepared in accordance with generally accepted accounting principles in the United States (GAAP). The company uses these non-GAAP financial measures and other key metrics internally in analyzing its financial results and believes that the use of these non-GAAP financial measures and key metrics are useful to investors as an additional tool to evaluate ongoing operating results and trends, and in comparing the company’s financial results with other companies in its industry, many of which present similar non-GAAP financial measures or key metrics.

[0001327567-20-000002:8k_2_02:38]
The presentation of these non-GAAP financial measures and key metrics are not meant to be considered in isolation or as a substitute for comparable GAAP financial measures and should be read only in conjunction with the company’s consolidated financial statements prepared in accordance with GAAP. A reconciliation of the company’s historical non-GAAP financial measures to their most directly comparable GAAP measures has been provided in the financial statement tables included in this press release, and investors are encouraged to review these reconciliations.

[0001327567-20-000002:8k_2_02:39]
Non-GAAP net income and net income per share, diluted. Palo Alto Networks defines non-GAAP net income as net income (loss) plus share-based compensation-related charges, including share-based payroll tax expense, acquisition-related costs, amortization expense of acquired intangible assets, litigation-related charges, including legal settlements, gains (losses) related to facility exit, non-cash charges related to convertible notes, and intellectual property restructuring-related charges. The company also excludes from non-GAAP net income the foreign currency gains (losses) and tax effects associated with these items in order to provide a complete picture of the company’s recurring core business operating results. The company defines non-GAAP net income per share, diluted, as non-GAAP net income divided by the weighted-average diluted shares outstanding, which includes the potentially dilutive effect of the company’s employee equity incentive plan awards and the company’s convertible senior notes outstanding and related warrants, after giving effect to the anti-dilutive impact of the company’s note hedge agreements, which reduces the potential economic dilution that otherwise would occur upon conversion of the company’s convertible senior notes. Under GAAP, the anti-dilutive impact of the note hedge is not reflected in diluted shares outstanding. The company believes that excluding these items from non-GAAP net income and net income per share, diluted,

[0001327567-20-000002:8k_2_02:40]
5

[0001327567-20-000002:8k_2_02:41]
provides management and investors with greater visibility into the underlying performance of the company’s core business operating results, meaning its operating performance excluding these items and, from time to time, other discrete charges that are infrequent in nature, over multiple periods.

[0001327567-20-000002:8k_2_02:42]
Billings. Palo Alto Networks defines billings as total revenue plus the change in total deferred revenue, net of acquired deferred revenue, during the period. The company considers billings to be a key metric used by management to manage the company's business given the company's hybrid-SaaS revenue model, and believes billings provides investors with an important indicator of the health and visibility of the company's business because it includes subscription and support revenue, which is recognized ratably over the contractual service period, and product revenue, which is recognized at the time of shipment, provided that all other conditions for revenue recognition have been met. The company considers billings to be a useful metric for management and investors, particularly if sales of subscriptions continue to increase and the company experiences strong renewal rates for subscriptions and support.

[0001327567-20-000002:8k_2_02:43]
Investors are cautioned that there are a number of limitations associated with the use of non-GAAP financial measures and key metrics as analytical tools. In particular, the billings metric reported by the company includes amounts that have not yet been recognized as revenue. Additionally, many of the adjustments to the company’s GAAP financial measures reflect the exclusion of items that are recurring and will be reflected in the company’s financial results for the foreseeable future, such as share-based compensation, which is an important part of Palo Alto Networks employees’ compensation and impacts their performance. Furthermore, these non-GAAP financial measures are not based on any standardized methodology prescribed by GAAP, and the components that Palo Alto Networks excludes in its calculation of non-GAAP financial measures may differ from the components that its peer companies exclude when they report their non-GAAP results of operations. Palo Alto Networks compensates for these limitations by providing specific information regarding the GAAP amounts excluded from these non-GAAP financial measures. In the future, the company may also exclude non-recurring expenses and other expenses that do not reflect the company’s core business operating results.

[0001327567-20-000002:8k_2_02:44]
About Palo Alto Networks

[0001327567-20-000002:8k_2_02:45]
Palo Alto Networks, the global cybersecurity leader, is shaping the cloud-centric future with technology that is transforming the way people and organizations operate. Our mission is to be the cybersecurity partner of choice, protecting our digital way of life. We help address the world's greatest security challenges with continuous innovation that seizes the latest breakthroughs in artificial intelligence, analytics, automation, and orchestration. By delivering an integrated platform and empowering a growing ecosystem of partners, we are at the forefront of protecting tens of thousands of organizations across clouds, networks, and mobile devices. Our vision is a world where each day is safer and more secure than the one before. For more information, visit www.paloaltonetworks.com.

[0001327567-20-000002:8k_2_02:46]
Palo Alto Networks and the Palo Alto Networks logo are trademarks of Palo Alto Networks, Inc. in the United States and in jurisdictions throughout the world. All other trademarks, trade names, or service marks used or mentioned herein belong to their respective owners.

[0001327567-20-000002:8k_2_02:47]
Media Contact:

[0001327567-20-000002:8k_2_02:48]
Mara Mort

[0001327567-20-000002:8k_2_02:49]
Senior Director of Corporate Communications, Palo Alto Networks

[0001327567-20-000002:8k_2_02:50]
Mobile: 1-415-850-8645

[0001327567-20-000002:8k_2_02:51]
mmort@paloaltonetworks.com

[0001327567-20-000002:8k_2_02:52]
Investor Relations Contact:

[0001327567-20-000002:8k_2_02:53]
David Niederman

[0001327567-20-000002:8k_2_02:54]
Vice President of Investor Relations, Palo Alto Networks

[0001327567-20-000002:8k_2_02:55]
Office: 1-669-400-7323

[0001327567-20-000002:8k_2_02:56]
dniederman@paloaltonetworks.com

[0001327567-20-000002:8k_2_02:57]
| Palo Alto Networks, Inc. |
| Preliminary Condensed Consolidated Statements of Operations |
| (In millions, except per share data) |
| (Unaudited) |
|  | Three Months Ended January 31, |  | Six Months Ended January 31, |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Revenue: |  |  |  |  |  |  |  |
| Product | $ | 246.5 |  |  | $ | 271.6 |  |  | $ | 477.7 |  |  | $ | 512.1 |  |
| Subscription and support | 570.2 |  |  | 439.6 |  |  | 1,110.9 |  |  | 855.1 |  |
| Total revenue | 816.7 |  |  | 711.2 |  |  | 1,588.6 |  |  | 1,367.2 |  |
| Cost of revenue: |  |  |  |  |  |  |  |
| Product | 68.7 |  |  | 82.5 |  |  | 133.8 |  |  | 155.7 |  |
| Subscription and support | 164.4 |  |  | 120.1 |  |  | 317.0 |  |  | 230.4 |  |
| Total cost of revenue | 233.1 |  |  | 202.6 |  |  | 450.8 |  |  | 386.1 |  |
| Total gross profit | 583.6 |  |  | 508.6 |  |  | 1,137.8 |  |  | 981.1 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 185.4 |  |  | 128.3 |  |  | 355.9 |  |  | 241.7 |  |
| Sales and marketing | 374.9 |  |  | 320.0 |  |  | 740.6 |  |  | 634.6 |  |
| General and administrative | 76.2 |  |  | 53.7 |  |  | 146.0 |  |  | 130.3 |  |
| Total operating expenses | 636.5 |  |  | 502.0 |  |  | 1,242.5 |  |  | 1,006.6 |  |
| Operating income (loss) | (52.9 | ) |  | 6.6 |  |  | (104.7 | ) |  | (25.5 | ) |
| Interest expense | (19.0 | ) |  | (20.6 | ) |  | (37.9 | ) |  | (43.3 | ) |
| Other income, net | 10.8 |  |  | 16.0 |  |  | 27.0 |  |  | 29.0 |  |
| Income (loss) before income taxes | (61.1 | ) |  | 2.0 |  |  | (115.6 | ) |  | (39.8 | ) |
| Provision for income taxes | 12.6 |  |  | 4.6 |  |  | 17.7 |  |  | 1.1 |  |
| Net loss | $ | (73.7 | ) |  | $ | (2.6 | ) |  | $ | (133.3 | ) |  | $ | (40.9 | ) |
| Net loss per share, basic and diluted | $ | (0.75 | ) |  | $ | (0.03 | ) |  | $ | (1.37 | ) |  | $ | (0.44 | ) |
| Weighted-average shares used to compute net loss per share, basic and diluted | 98.3 |  |  | 94.0 |  |  | 97.5 |  |  | 93.9 |  |

[0001327567-20-000002:8k_2_02:58]
8

[0001327567-20-000002:8k_2_02:59]
| Palo Alto Networks, Inc. |
| Reconciliation of GAAP to Non-GAAP Financial Measures |
| (In millions, except per share amounts) |
| (Unaudited) |
|  | Three Months Ended |  | Six Months Ended |
|  | January 31, |  | January 31, |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| GAAP net loss | $ | (73.7 | ) |  | $ | (2.6 | ) |  | $ | (133.3 | ) |  | $ | (40.9 | ) |
| Share-based compensation-related charges | 177.0 |  |  | 149.5 |  |  | 330.7 |  |  | 290.2 |  |
| Acquisition-related costs(1) | 7.0 |  |  | 1.6 |  |  | 10.4 |  |  | 17.1 |  |
| Amortization expense of acquired intangible assets | 17.8 |  |  | 14.1 |  |  | 34.5 |  |  | 23.4 |  |
| Litigation-related charges(2) | — |  |  | 3.0 |  |  | — |  |  | 6.1 |  |
| Gain related to facility exit (3) | (3.1 | ) |  | — |  |  | (3.1 | ) |  | — |  |
| Non-cash charges related to convertible notes(4) | 15.7 |  |  | 17.5 |  |  | 31.2 |  |  | 39.1 |  |
| Foreign currency loss associated with non-GAAP adjustments | 1.0 |  |  | 0.6 |  |  | 0.5 |  |  | 0.1 |  |
| Income tax and other tax adjustments related to the above | (21.4 | ) |  | (36.7 | ) |  | (45.8 | ) |  | (72.7 | ) |
| Non-GAAP net income | $ | 120.3 |  |  | $ | 147.0 |  |  | $ | 225.1 |  |  | $ | 262.4 |  |
| GAAP net loss per share, diluted | $ | (0.75 | ) |  | $ | (0.03 | ) |  | $ | (1.37 | ) |  | $ | (0.44 | ) |
| Share-based compensation-related charges | 1.77 |  |  | 1.53 |  |  | 3.32 |  |  | 2.97 |  |
| Acquisition-related costs(1) | 0.07 |  |  | 0.02 |  |  | 0.11 |  |  | 0.18 |  |
| Amortization expense of acquired intangible assets | 0.18 |  |  | 0.15 |  |  | 0.35 |  |  | 0.25 |  |
| Litigation-related charges(2) | 0.00 |  |  | 0.03 |  |  | 0.00 |  |  | 0.06 |  |
| Gain related to facility exit (3) | (0.03 | ) |  | 0.00 |  |  | (0.03 | ) |  | 0.00 |  |
| Non-cash charges related to convertible notes(4) | 0.16 |  |  | 0.19 |  |  | 0.32 |  |  | 0.42 |  |
| Foreign currency loss associated with non-GAAP adjustments | 0.01 |  |  | 0.01 |  |  | 0.01 |  |  | 0.00 |  |
| Income tax and other tax adjustments related to the above | (0.22 | ) |  | (0.39 | ) |  | (0.47 | ) |  | (0.77 | ) |
| Non-GAAP net income per share, diluted | $ | 1.19 |  |  | $ | 1.51 |  |  | $ | 2.24 |  |  | $ | 2.67 |  |
| GAAP weighted-average shares used to compute net loss per share, diluted | 98.3 |  |  | 94.0 |  |  | 97.5 |  |  | 93.9 |  |
| Weighted-average effect of potentially dilutive securities(5) | 2.8 |  |  | 3.6 |  |  | 3.1 |  |  | 4.4 |  |
| Non-GAAP weighted-average shares used to compute net income per share, diluted | 101.1 |  |  | 97.6 |  |  | 100.6 |  |  | 98.3 |  |

[0001327567-20-000002:8k_2_02:60]
| (1) | Consists of acquisition transaction costs, share-based compensation related to the cash settlement of certain equity awards, and costs to terminate certain employment and operating lease contracts of the acquired company. |

[0001327567-20-000002:8k_2_02:61]
| (2) | Consists of the amortization of intellectual property licenses. |

[0001327567-20-000002:8k_2_02:62]
| (3) | Consists of a gain related to the early termination of our previous headquarters leases. |

[0001327567-20-000002:8k_2_02:63]
| (4) | Consists primarily of non-cash interest expense related to the company’s convertible senior notes. Also includes non-cash losses of $0.4 million and $2.6 million during the three and six months ended January 31, 2019, respectively, related to early conversions of the convertible notes during those periods. |

[0001327567-20-000002:8k_2_02:64]
| (5) | Non-GAAP net income per share, diluted, includes the potentially dilutive effect of employee equity incentive plan awards and convertible senior notes outstanding and related warrants. In addition, non-GAAP net income per share, diluted, includes the anti-dilutive impact of the company’s note hedge agreements, which reduced the potentially dilutive effect of the convertible notes by 0.6 million shares and 0.8 million shares for the three and six months ended January 31, 2019, respectively. |

[0001327567-20-000002:8k_2_02:65]
9

[0001327567-20-000002:8k_2_02:66]
| Palo Alto Networks, Inc. |
| Calculation of Billings |
| (In millions) |
| (Unaudited) |
|  | Three Months Ended |  | Six Months Ended |
|  | January 31, |  | January 31, |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Total revenue | $ | 816.7 |  |  | $ | 711.2 |  |  | $ | 1,588.6 |  |  | $ | 1,367.2 |  |
| Add: change in total deferred revenue, net of acquired deferred revenue | 182.2 |  |  | 141.3 |  |  | 307.7 |  |  | 243.8 |  |
| Billings | $ | 998.9 |  |  | $ | 852.5 |  |  | $ | 1,896.3 |  |  | $ | 1,611.0 |  |

[0001327567-20-000002:8k_2_02:67]
10

[0001327567-20-000002:8k_2_02:68]
| Palo Alto Networks, Inc. |
| Preliminary Condensed Consolidated Balance Sheets |
| (In millions) |
| (Unaudited) |
|  | January 31, 2020 |  | July 31, 2019 |
| Assets |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 2,000.0 |  |  | $ | 961.4 |  |
| Short-term investments | 1,133.9 |  |  | 1,841.7 |  |
| Accounts receivable, net | 540.3 |  |  | 582.4 |  |
| Prepaid expenses and other current assets | 304.0 |  |  | 279.3 |  |
| Total current assets | 3,978.2 |  |  | 3,664.8 |  |
| Property and equipment, net | 311.4 |  |  | 296.0 |  |
| Operating lease right-of-use assets | 270.0 |  |  | — |  |
| Long-term investments | 317.9 |  |  | 575.4 |  |
| Goodwill | 1,511.7 |  |  | 1,352.3 |  |
| Intangible assets, net | 290.0 |  |  | 280.6 |  |
| Other assets | 504.9 |  |  | 423.1 |  |
| Total assets | $ | 7,184.1 |  |  | $ | 6,592.2 |  |
| Liabilities and stockholders’ equity |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 55.4 |  |  | $ | 73.3 |  |
| Accrued compensation | 175.2 |  |  | 235.5 |  |
| Accrued and other liabilities | 251.2 |  |  | 162.4 |  |
| Deferred revenue | 1,757.7 |  |  | 1,582.1 |  |
| Total current liabilities | 2,239.5 |  |  | 2,053.3 |  |
| Convertible senior notes, net | 1,461.2 |  |  | 1,430.0 |  |
| Long-term deferred revenue | 1,440.8 |  |  | 1,306.6 |  |
| Long-term operating lease liabilities | 353.5 |  |  | — |  |
| Other long-term liabilities | 80.6 |  |  | 216.0 |  |
| Stockholders’ equity: |  |  |  |
| Preferred stock | — |  |  | — |  |
| Common stock and additional paid-in capital | 2,644.5 |  |  | 2,490.9 |  |
| Accumulated other comprehensive loss | (1.8 | ) |  | (3.7 | ) |
| Accumulated deficit | (1,034.2 | ) |  | (900.9 | ) |
| Total stockholders’ equity | 1,608.5 |  |  | 1,586.3 |  |
| Total liabilities and stockholders’ equity | $ | 7,184.1 |  |  | $ | 6,592.2 |  |

[0001327567-20-000002:8k_2_02:69]
11
