# PANW MD&A — 0001327567-20-000007


## mdna

[0001327567-20-000007:mdna:1]
[same as prior period, unchanged from 0001327567-19-000038:mdna:1]

[0001327567-20-000007:mdna:2]
[same as prior period, unchanged from 0001327567-19-000038:mdna:2]

[0001327567-20-000007:mdna:3]
[same as prior period, unchanged from 0001327567-19-000038:mdna:3]

[0001327567-20-000007:mdna:4]
[same as prior period, unchanged from 0001327567-19-000038:mdna:4]

[0001327567-20-000007:mdna:5]
| • | Results of Operations. A discussion of the nature and trends in our financial results and an analysis of our financial results comparing the three and six months ended January 31, 2020 to the three and six months ended January 31, 2019. |

[0001327567-20-000007:mdna:6]
[same as prior period, unchanged from 0001327567-19-000038:mdna:6]

[0001327567-20-000007:mdna:7]
[same as prior period, unchanged from 0001327567-19-000038:mdna:8]

[0001327567-20-000007:mdna:8]
[same as prior period, unchanged from 0001327567-19-000038:mdna:9]

[0001327567-20-000007:mdna:9]
[same as prior period, unchanged from 0001327567-19-000038:mdna:10]

[0001327567-20-000007:mdna:10]
[same as prior period, unchanged from 0001327567-19-000038:mdna:11]

[0001327567-20-000007:mdna:11]
[same as prior period, unchanged from 0001327567-19-000038:mdna:12]

[0001327567-20-000007:mdna:12]
| • | Secure the network through our Next-Generation Firewalls, available as physical appliances, virtual appliances called VM-Series, or a cloud-delivered service called Prisma Access (formerly GlobalProtect cloud service), and Panorama |

[0001327567-20-000007:mdna:13]
[same as prior period, unchanged from 0001327567-19-000038:mdna:32]

[0001327567-20-000007:mdna:14]
management delivered as an appliance or as a virtual machine for the public or private cloud. This also includes security services such as WildFire, Threat Prevention, URL Filtering, GlobalProtect, DNS Security and SD-WAN that are delivered as SaaS subscriptions to our Next-Generation Firewalls.

[0001327567-20-000007:mdna:15]
[same as prior period, unchanged from 0001327567-19-000038:mdna:15]

[0001327567-20-000007:mdna:16]
| • | Secure the cloud through our Prisma security offerings, such as Prisma Cloud (formerly RedLock, Twistlock and PureSec) with comprehensive security and compliance coverage for cloud native applications throughout the full development lifecycle and across multi- and hybrid- cloud environments, Prisma Access (formerly GlobalProtect cloud service) for securing user access, Prisma SaaS (formerly Aperture) for protecting SaaS applications and VM-Series for in-line network security in multi- and hybrid- cloud environments. |

[0001327567-20-000007:mdna:17]
[same as prior period, unchanged from 0001327567-19-000038:mdna:17]

[0001327567-20-000007:mdna:18]
| • | Secure the future of security operations through Cortex, which includes Cortex XDR for prevention, detection and response (one unified product that was formerly Cortex XDR and Traps), Cortex SOAR (formerly Demisto) for security orchestration, automation and response (“SOAR”), AutoFocus for threat intelligence, Zingbox IoT Guardian for Internet of Things (“IoT”) security and Cortex Data Lake to collect and integrate security data for analytics. These products are delivered as software or SaaS subscriptions. |

[0001327567-20-000007:mdna:19]
For the second quarter of fiscal 2020 and 2019, total revenue was $816.7 million and $711.2 million, respectively, representing year-over-year growth of 14.8%. Our growth reflected the increased adoption of our hybrid SaaS revenue model, which consists of product, subscriptions, and support. We believe this model will enable us to benefit from recurring revenues as we continue to grow our installed end-customer base. As of January 31, 2020, we had end-customers in more than 150 countries. Our end-customers represent a broad range of industries, including education, energy, financial services, government entities, healthcare, Internet and media, manufacturing, public sector, and telecommunications, and include some of the largest Fortune 100 and Global 2000 companies in the world. We maintain a field sales force that works closely with our channel partners in developing sales opportunities. We use a two-tiered, indirect fulfillment model whereby we sell our products, subscriptions, and support to our distributors, which, in turn, sell to our resellers, which then sell to our end-customers.

[0001327567-20-000007:mdna:20]
Our product revenue was $246.5 million, or 30.2% of total revenue, for the second quarter of fiscal 2020, representing a year-over-year decrease of 9.2%. Product revenue is generated from sales of our appliances, primarily our Next-Generation Firewall, which is available in physical and virtualized form. Our Next-Generation Firewall incorporates our proprietary PAN-OS operating system, which provides a consistent set of capabilities across our entire product line. Our products are designed for different performance requirements throughout an organization, ranging from our PA-220, which is designed for small organizations and remote or branch offices, to our top-of-the-line PA-7080, which is especially suited for very large enterprise deployments and service provider customers. The same firewall functionality that is delivered in our physical appliances is also available in our VM-Series virtual firewalls, which secure virtualized and cloud-based computing environments.

[0001327567-20-000007:mdna:21]
Our subscription and support revenue grew to $570.2 million, or 69.8% of total revenue, for the second quarter of fiscal 2020, representing year-over-year growth of 29.7%. Our subscriptions provide our end-customers with real-time access to the latest antivirus, intrusion prevention, web filtering, and modern malware prevention capabilities across the network, endpoints, and the cloud. When end-customers purchase our physical or virtual firewall appliances, they typically purchase support in order to receive ongoing security updates, upgrades, bug fixes, and repairs. In addition to the subscriptions purchased with these appliances, end-customers may also purchase other subscriptions on a per-user, per-endpoint, or capacity-based basis.

[0001327567-20-000007:mdna:22]
We continue to invest in innovation as we evolve and further extend the capabilities of our platforms, as we believe that innovation and timely development of new features and products is essential to meeting the needs of our end-customers and improving our competitive position. For example, in December 2019, we acquired Aporeto Inc. (“Aporeto”), which we believe will strengthen our cloud-native security platform capabilities delivered by Prisma Cloud.

[0001327567-20-000007:mdna:23]
[same as prior period, unchanged from 0001327567-19-000038:mdna:25]

[0001327567-20-000007:mdna:24]
[same as prior period, unchanged from 0001327567-19-000038:mdna:26]

[0001327567-20-000007:mdna:25]
[same as prior period, unchanged from 0001327567-19-000038:mdna:27]

[0001327567-20-000007:mdna:26]
[same as prior period, unchanged from 0001327567-19-000038:mdna:38]

[0001327567-20-000007:mdna:27]
|  | January 31, 2020 |  | July 31, 2019 |
|  | (in millions) |
| Total deferred revenue | $ | 3,198.5 |  |  | $ | 2,888.7 |  |
| Cash, cash equivalents, and investments | $ | 3,451.8 |  |  | $ | 3,378.5 |  |

[0001327567-20-000007:mdna:28]
|  | Three Months Ended January 31, |  | Six Months Ended January 31, |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
|  | (dollars in millions) |
| Total revenue | $ | 816.7 |  |  | $ | 711.2 |  |  | $ | 1,588.6 |  |  | $ | 1,367.2 |  |
| Total revenue year-over-year percentage increase | 14.8 | % |  | 30.4 | % |  | 16.2 | % |  | 30.5 | % |
| Gross margin | 71.5 | % |  | 71.5 | % |  | 71.6 | % |  | 71.8 | % |
| Operating loss | $ | (52.9 | ) |  | $ | 6.6 |  |  | $ | (104.7 | ) |  | $ | (25.5 | ) |
| Operating margin | (6.5 | )% |  | 0.9 | % |  | (6.6 | )% |  | (1.9 | )% |
| Billings | $ | 998.9 |  |  | $ | 852.5 |  |  | $ | 1,896.3 |  |  | $ | 1,611.0 |  |
| Billings year-over-year percentage increase | 17.2 | % |  | 26.6 | % |  | 17.7 | % |  | 27.0 | % |
| Cash flow provided by operating activities |  |  |  |  | $ | 532.1 |  |  | $ | 527.7 |  |
| Free cash flow (non-GAAP) |  |  |  |  | $ | 435.8 |  |  | $ | 469.9 |  |

[0001327567-20-000007:mdna:29]
[same as prior period, unchanged from 0001327567-19-000038:mdna:30]

[0001327567-20-000007:mdna:30]
| • | Billings. We define billings as total revenue plus the change in total deferred revenue, net of acquired deferred revenue, during the period. We consider billings to be a key metric used by management to manage our business given our hybrid SaaS revenue model, and believe billings provides investors with an important indicator of the health and visibility of our business because it includes subscription and support revenue, which is recognized ratably over the contractual service period, and product revenue, which is recognized at the time of shipment, provided that all other conditions for revenue recognition have been met. We consider billings to be a useful metric for management and investors, particularly if we continue to experience increased sales of subscriptions and strong renewal rates for subscription and support offerings, and as we monitor our near-term cash flows. While we believe that billings provides useful information to investors and others in understanding and evaluating our operating results in the same manner as our management, it is important to note that other companies, including companies in our industry, may not use billings, may calculate billings differently, may have different billing frequencies, or may use other financial measures to evaluate their performance, all of which could reduce the usefulness of billings as a comparative measure. We calculate billings in the following manner: |

[0001327567-20-000007:mdna:31]
|  | Three Months Ended January 31, |  | Six Months Ended January 31, |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
|  | (in millions) |  | (in millions) |
| Billings: |  |  |  |  |  |  |  |
| Total revenue | $ | 816.7 |  |  | $ | 711.2 |  |  | $ | 1,588.6 |  |  | $ | 1,367.2 |  |
| Add: change in total deferred revenue, net of acquired deferred revenue | 182.2 |  |  | 141.3 |  |  | 307.7 |  |  | 243.8 |  |
| Billings | $ | 998.9 |  |  | $ | 852.5 |  |  | $ | 1,896.3 |  |  | $ | 1,611.0 |  |

[0001327567-20-000007:mdna:32]
[same as prior period, unchanged from 0001327567-19-000038:mdna:35]

[0001327567-20-000007:mdna:33]
| • | Free Cash Flow (non-GAAP). We define free cash flow, a non-GAAP financial measure, as cash provided by operating activities less purchases of property, equipment, and other assets. We consider free cash flow to be a profitability and liquidity measure that provides useful information to management and investors about the amount of cash generated by |

[0001327567-20-000007:mdna:34]
[same as prior period, unchanged from 0001327567-19-000038:mdna:47]

[0001327567-20-000007:mdna:35]
the business after necessary capital expenditures. A limitation of the utility of free cash flow as a measure of our financial performance and liquidity is that it does not represent the total increase or decrease in our cash balance for the period. In addition, it is important to note that other companies, including companies in our industry, may not use free cash flow, may calculate free cash flow in a different manner than we do, or may use other financial measures to evaluate their performance, all of which could reduce the usefulness of free cash flow as a comparative measure. A reconciliation of free cash flow to cash flow provided by operating activities, the most directly comparable financial measure calculated and presented in accordance with GAAP, is provided below:

[0001327567-20-000007:mdna:36]
|  | Six Months Ended January 31, |
|  | 2020 |  | 2019 |
|  | (in millions) |
| Free cash flow (non-GAAP): |  |  |  |
| Net cash provided by operating activities | $ | 532.1 |  |  | $ | 527.7 |  |
| Less: purchases of property, equipment, and other assets | 96.3 |  |  | 57.8 |  |
| Free cash flow (non-GAAP) | $ | 435.8 |  |  | $ | 469.9 |  |
| Net cash provided by (used in) investing activities | $ | 680.9 |  |  | $ | (1,236.9 | ) |
| Net cash used in financing activities | $ | (173.2 | ) |  | $ | (669.6 | ) |

[0001327567-20-000007:mdna:37]
[same as prior period, unchanged from 0001327567-19-000038:mdna:39]

[0001327567-20-000007:mdna:38]
[same as prior period, unchanged from 0001327567-19-000038:mdna:40]

[0001327567-20-000007:mdna:39]
|  | Three Months Ended January 31, |  | Six Months Ended January 31, |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
|  | Amount |  | % of Revenue |  | Amount |  | % of Revenue |  | Amount |  | % of Revenue |  | Amount |  | % of Revenue |
|  | (dollars in millions) |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 246.5 |  |  | 30.2 | % |  | $ | 271.6 |  |  | 38.2 | % |  | $ | 477.7 |  |  | 30.1 | % |  | $ | 512.1 |  |  | 37.5 | % |
| Subscription and support | 570.2 |  |  | 69.8 | % |  | 439.6 |  |  | 61.8 | % |  | 1,110.9 |  |  | 69.9 | % |  | 855.1 |  |  | 62.5 | % |
| Total revenue | 816.7 |  |  | 100.0 | % |  | 711.2 |  |  | 100.0 | % |  | 1,588.6 |  |  | 100.0 | % |  | 1,367.2 |  |  | 100.0 | % |
| Cost of revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product | 68.7 |  |  | 8.4 | % |  | 82.5 |  |  | 11.6 | % |  | 133.8 |  |  | 8.4 | % |  | 155.7 |  |  | 11.4 | % |
| Subscription and support | 164.4 |  |  | 20.1 | % |  | 120.1 |  |  | 16.9 | % |  | 317.0 |  |  | 20.0 | % |  | 230.4 |  |  | 16.8 | % |
| Total cost of revenue(1) | 233.1 |  |  | 28.5 | % |  | 202.6 |  |  | 28.5 | % |  | 450.8 |  |  | 28.4 | % |  | 386.1 |  |  | 28.2 | % |
| Total gross profit | 583.6 |  |  | 71.5 | % |  | 508.6 |  |  | 71.5 | % |  | 1,137.8 |  |  | 71.6 | % |  | 981.1 |  |  | 71.8 | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | 185.4 |  |  | 22.7 | % |  | 128.3 |  |  | 18.0 | % |  | 355.9 |  |  | 22.4 | % |  | 241.7 |  |  | 17.7 | % |
| Sales and marketing | 374.9 |  |  | 46.0 | % |  | 320.0 |  |  | 45.0 | % |  | 740.6 |  |  | 46.6 | % |  | 634.6 |  |  | 46.5 | % |
| General and administrative | 76.2 |  |  | 9.3 | % |  | 53.7 |  |  | 7.6 | % |  | 146.0 |  |  | 9.2 | % |  | 130.3 |  |  | 9.5 | % |
| Total operating expenses(1) | 636.5 |  |  | 78.0 | % |  | 502.0 |  |  | 70.6 | % |  | 1,242.5 |  |  | 78.2 | % |  | 1,006.6 |  |  | 73.7 | % |
| Operating loss | (52.9 | ) |  | (6.5 | )% |  | 6.6 |  |  | 0.9 | % |  | (104.7 | ) |  | (6.6 | )% |  | (25.5 | ) |  | (1.9 | )% |
| Interest expense | (19.0 | ) |  | (2.3 | )% |  | (20.6 | ) |  | (2.9 | )% |  | (37.9 | ) |  | (2.4 | )% |  | (43.3 | ) |  | (3.2 | )% |
| Other income, net | 10.8 |  |  | 1.3 | % |  | 16.0 |  |  | 2.3 | % |  | 27.0 |  |  | 1.7 | % |  | 29.0 |  |  | 2.2 | % |
| Loss before income taxes | (61.1 | ) |  | (7.5 | )% |  | 2.0 |  |  | 0.3 | % |  | (115.6 | ) |  | (7.3 | )% |  | (39.8 | ) |  | (2.9 | )% |
| Provision for income taxes | 12.6 |  |  | 1.5 | % |  | 4.6 |  |  | 0.7 | % |  | 17.7 |  |  | 1.1 | % |  | 1.1 |  |  | 0.1 | % |
| Net loss | $ | (73.7 | ) |  | (9.0 | )% |  | $ | (2.6 | ) |  | (0.4 | )% |  | $ | (133.3 | ) |  | (8.4 | )% |  | $ | (40.9 | ) |  | (3.0 | )% |

[0001327567-20-000007:mdna:40]
[same as prior period, unchanged from 0001327567-19-000038:mdna:59]

[0001327567-20-000007:mdna:41]
[same as prior period, unchanged from 0001327567-19-000038:mdna:42]

[0001327567-20-000007:mdna:42]
[same as prior period, unchanged from 0001327567-19-000038:mdna:43]

[0001327567-20-000007:mdna:43]
|  | Three Months Ended January 31, |  | Six Months Ended January 31, |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
|  | (in millions) |
| Cost of product revenue | $ | 1.6 |  |  | $ | 1.4 |  |  | $ | 2.9 |  |  | $ | 3.0 |  |
| Cost of subscription and support revenue | 20.0 |  |  | 18.2 |  |  | 38.9 |  |  | 35.7 |  |
| Research and development | 67.0 |  |  | 44.0 |  |  | 129.4 |  |  | 84.5 |  |
| Sales and marketing | 54.9 |  |  | 58.7 |  |  | 98.7 |  |  | 114.7 |  |
| General and administrative | 29.4 |  |  | 20.1 |  |  | 54.2 |  |  | 55.6 |  |
| Total share-based compensation | $ | 172.9 |  |  | $ | 142.4 |  |  | $ | 324.1 |  |  | $ | 293.5 |  |

[0001327567-20-000007:mdna:44]
[same as prior period, unchanged from 0001327567-19-000038:mdna:45]

[0001327567-20-000007:mdna:45]
[same as prior period, unchanged from 0001327567-19-000038:mdna:46]

[0001327567-20-000007:mdna:46]
[same as prior period, unchanged from 0001327567-19-000038:mdna:48]

[0001327567-20-000007:mdna:47]
Product revenue is derived primarily from sales of our appliances. Product revenue also includes revenue derived from software licenses of Panorama and the VM-Series. Our appliances and software licenses include a broad set of built-in networking and security features and functionalities. We generally recognize product revenue at the time of hardware shipment or delivery of software licenses.

[0001327567-20-000007:mdna:48]
|  | Three Months Ended January 31, |  |  |  |  |  | Six Months Ended January 31, |  |  |  |  |
|  | 2020 |  | 2019 |  | Change |  | 2020 |  | 2019 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Product | $ | 246.5 |  |  | $ | 271.6 |  |  | $ | (25.1 | ) |  | (9.2 | )% |  | $ | 477.7 |  |  | $ | 512.1 |  |  | $ | (34.4 | ) |  | (6.7 | )% |

[0001327567-20-000007:mdna:49]
Product revenue decreased for the three and six months ended January 31, 2020 compared to the three and six months ended January 31, 2019. The decrease was primarily due to a decrease in product unit volume. The change in product revenue due to pricing was not significant for either period.

[0001327567-20-000007:mdna:50]
[same as prior period, unchanged from 0001327567-19-000038:mdna:52]

[0001327567-20-000007:mdna:51]
[same as prior period, unchanged from 0001327567-19-000038:mdna:53]

[0001327567-20-000007:mdna:52]
|  | Three Months Ended January 31, |  |  |  |  |  | Six Months Ended January 31, |  |  |  |  |
|  | 2020 |  | 2019 |  | Change |  | 2020 |  | 2019 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Subscription | $ | 342.6 |  |  | $ | 249.7 |  |  | $ | 92.9 |  |  | 37.2 | % |  | $ | 661.2 |  |  | $ | 481.0 |  |  | $ | 180.2 |  |  | 37.5 | % |
| Support | 227.6 |  |  | 189.9 |  |  | 37.7 |  |  | 19.9 | % |  | 449.7 |  |  | 374.1 |  |  | 75.6 |  |  | 20.2 | % |
| Total subscription and support | $ | 570.2 |  |  | $ | 439.6 |  |  | $ | 130.6 |  |  | 29.7 | % |  | $ | 1,110.9 |  |  | $ | 855.1 |  |  | $ | 255.8 |  |  | 29.9 | % |

[0001327567-20-000007:mdna:53]
Subscription and support revenue increased for the three and six months ended January 31, 2020 compared to the three and six months ended January 31, 2019. The increase in both periods was due to increased demand for our subscription and support offerings from both new and existing end-customers. The mix between subscription revenue and support revenue will fluctuate over time,

[0001327567-20-000007:mdna:54]
[same as prior period, unchanged from 0001327567-19-000038:mdna:72]

[0001327567-20-000007:mdna:55]
depending on the introduction of new subscription offerings, renewals of support services, and our ability to increase sales to new and existing end customers. The change in subscription and support revenue due to changes in pricing was not significant for either period.

[0001327567-20-000007:mdna:56]
[same as prior period, unchanged from 0001327567-19-000038:mdna:56]

[0001327567-20-000007:mdna:57]
|  | Three Months Ended January 31, |  |  |  |  |  | Six Months Ended January 31, |  |  |  |  |
|  | 2020 |  | 2019 |  | Change |  | 2020 |  | 2019 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Americas | $ | 544.7 |  |  | $ | 475.0 |  |  | $ | 69.7 |  |  | 14.7 | % |  | $ | 1,074.3 |  |  | $ | 925.2 |  |  | $ | 149.1 |  |  | 16.1 | % |
| EMEA | 166.2 |  |  | 148.3 |  |  | $ | 17.9 |  |  | 12.1 | % |  | 313.8 |  |  | 276.0 |  |  | 37.8 |  |  | 13.7 | % |
| APAC | 105.8 |  |  | 87.9 |  |  | 17.9 |  |  | 20.4 | % |  | 200.5 |  |  | 166.0 |  |  | 34.5 |  |  | 20.8 | % |
| Total revenue | $ | 816.7 |  |  | $ | 711.2 |  |  | $ | 105.5 |  |  | 14.8 | % |  | $ | 1,588.6 |  |  | $ | 1,367.2 |  |  | $ | 221.4 |  |  | 16.2 | % |

[0001327567-20-000007:mdna:58]
With respect to geographic theaters, the Americas contributed the largest portion of the increase in revenue for the three and six months ended January 31, 2020 compared to the three and six months ended January 31, 2019, due to its larger and more established sales force compared to our other theaters. Revenue from both Europe, the Middle East, and Africa (“EMEA”) and Asia Pacific and Japan (“APAC”) increased for the three and six months ended January 31, 2020 compared to the three and six months ended January 31, 2019, due to our investment in increasing the size of our sales force in these theaters.

[0001327567-20-000007:mdna:59]
[same as prior period, unchanged from 0001327567-19-000038:mdna:60]

[0001327567-20-000007:mdna:60]
[same as prior period, unchanged from 0001327567-19-000038:mdna:61]

[0001327567-20-000007:mdna:61]
[same as prior period, unchanged from 0001327567-19-000038:mdna:62]

[0001327567-20-000007:mdna:62]
[same as prior period, unchanged from 0001327567-19-000038:mdna:63]

[0001327567-20-000007:mdna:63]
|  | Three Months Ended January 31, |  |  |  |  |  | Six Months Ended January 31, |  |  |  |  |
|  | 2020 |  | 2019 |  | Change |  | 2020 |  | 2019 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Cost of product revenue | $ | 68.7 |  |  | $ | 82.5 |  |  | $ | (13.8 | ) |  | (16.7 | )% |  | $ | 133.8 |  |  | $ | 155.7 |  |  | $ | (21.9 | ) |  | (14.1 | )% |
| Number of employees at period end | 111 |  |  | 98 |  |  | 13 |  |  | 13.3 | % |  | 111 |  |  | 98 |  |  | 13 |  |  | 13.3 | % |

[0001327567-20-000007:mdna:64]
Cost of product revenue decreased for the three and six months ended January 31, 2020 compared to the three and six months ended January 31, 2019. The decrease for the three months ended January 31, 2020 was primarily due to a decrease in product unit volume and lower amortization of intellectual property licenses. The decrease for the six months ended January 31, 2020 was primarily due to reductions in costs of materials and lower amortization of intellectual property licenses.

[0001327567-20-000007:mdna:65]
[same as prior period, unchanged from 0001327567-19-000038:mdna:66]

[0001327567-20-000007:mdna:66]
[same as prior period, unchanged from 0001327567-19-000038:mdna:67]

[0001327567-20-000007:mdna:67]
[same as prior period, unchanged from 0001327567-19-000038:mdna:84]

[0001327567-20-000007:mdna:68]
|  | Three Months Ended January 31, |  |  |  |  |  | Six Months Ended January 31, |  |  |  |  |
|  | 2020 |  | 2019 |  | Change |  | 2020 |  | 2019 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Cost of subscription and support revenue | $ | 164.4 |  |  | $ | 120.1 |  |  | $ | 44.3 |  |  | 36.9 | % |  | $ | 317.0 |  |  | $ | 230.4 |  |  | $ | 86.6 |  |  | 37.6 | % |
| Number of employees at period end | 1,331 |  |  | 1030 |  |  | 301 |  |  | 29.2 | % |  | 1,331 |  |  | 1,030 |  |  | 301 |  |  | 29.2 | % |

[0001327567-20-000007:mdna:69]
Cost of subscription and support revenue increased for the three and six months ended January 31, 2020 compared to the three and six months ended January 31, 2019. The increase in both periods was primarily due to increased costs to support the growth of our subscription and support offerings. Personnel costs grew $16.5 million to $79.5 million for the three months ended January 31, 2020 compared to the three months ended January 31, 2019, and grew $31.8 million to $153.4 million for the six months ended January 31, 2020 compared to the six months ended January 31, 2019 primarily due to headcount growth. Data center and cloud hosting costs to support the adoption of our cloud-based subscription offerings increased $16.3 million for the three months ended January 31, 2020 compared to the three months ended January 31, 2019, and increased $30.5 million for the six months ended January 31, 2020 compared to the six months ended January 31, 2019. The remaining increase was primarily due to amortization of purchased intangible assets, which increased $7.0 million for the three months ended January 31, 2020 compared to the three months ended January 31, 2019 and increased $15.1 million for the six months ended January 31, 2020 compared to the six months ended January 31, 2019, as a result of our recent acquisitions.

[0001327567-20-000007:mdna:70]
[same as prior period, unchanged from 0001327567-19-000038:mdna:70]

[0001327567-20-000007:mdna:71]
[same as prior period, unchanged from 0001327567-19-000038:mdna:71]

[0001327567-20-000007:mdna:72]
|  | Three Months Ended January 31, |  | Six Months Ended January 31, |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
|  | Amount |  | Gross Margin |  | Amount |  | Gross Margin |  | Amount |  | Gross Margin |  | Amount |  | Gross Margin |
|  | (dollars in millions) |
| Product | $ | 177.8 |  |  | 72.1 | % |  | $ | 189.1 |  |  | 69.6 | % |  | $ | 343.9 |  |  | 72.0 | % |  | $ | 356.4 |  |  | 69.6 | % |
| Subscription and support | 405.8 |  |  | 71.2 | % |  | 319.5 |  |  | 72.7 | % |  | 793.9 |  |  | 71.5 | % |  | 624.7 |  |  | 73.1 | % |
| Total gross profit | $ | 583.6 |  |  | 71.5 | % |  | $ | 508.6 |  |  | 71.5 | % |  | $ | 1,137.8 |  |  | 71.6 | % |  | $ | 981.1 |  |  | 71.8 | % |

[0001327567-20-000007:mdna:73]
Product gross margin increased for the three and six months ended January 31, 2020 compared to the three and six months ended January 31, 2019, primarily due to reductions in costs of materials and lower amortization of intellectual property licenses.

[0001327567-20-000007:mdna:74]
Subscription and support gross margin decreased for the three and six months ended January 31, 2020 compared to the three and six months ended January 31, 2019, primarily due to an increase in costs to support the adoption of our cloud-based subscription offerings and higher amortization of purchased intangibles as a result of our recent acquisitions.

[0001327567-20-000007:mdna:75]
[same as prior period, unchanged from 0001327567-19-000038:mdna:76]

[0001327567-20-000007:mdna:76]
Our operating expenses consist of research and development, sales and marketing, and general and administrative expense. Personnel costs are the most significant component of operating expenses and consist of salaries, benefits, bonuses, share-based compensation, travel and entertainment, and with regard to sales and marketing expense, sales commissions. Our operating expenses also include allocated costs, which consist of certain facilities, depreciation, benefits, recruiting, and information technology costs that we allocate based on headcount. We expect operating expenses to increase in absolute dollars and decrease over the long term as a percentage of revenue as we continue to scale our business. As of January 31, 2020, we expect to recognize approximately $1.5 billion of share-based compensation expense over a weighted-average period of approximately 2.7 years, excluding additional share-based compensation expense related to any future grants of share-based awards. Share-based compensation expense is generally recognized on a straight-line basis over the requisite service periods of the awards.

[0001327567-20-000007:mdna:77]
[same as prior period, unchanged from 0001327567-19-000038:mdna:95]

[0001327567-20-000007:mdna:78]
[same as prior period, unchanged from 0001327567-19-000038:mdna:78]

[0001327567-20-000007:mdna:79]
[same as prior period, unchanged from 0001327567-19-000038:mdna:79]

[0001327567-20-000007:mdna:80]
|  | Three Months Ended January 31, |  |  |  |  |  | Six Months Ended January 31, |  |  |  |  |
|  | 2020 |  | 2019 |  | Change |  | 2020 |  | 2019 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Research and development | $ | 185.4 |  |  | $ | 128.3 |  |  | $ | 57.1 |  |  | 44.5 | % |  | $ | 355.9 |  |  | $ | 241.7 |  |  | $ | 114.2 |  |  | 47.2 | % |
| Number of employees at period end | 1,646 |  |  | 1,098 |  |  | 548 |  |  | 49.9 | % |  | 1,646 |  |  | 1,098 |  |  | 548 |  |  | 49.9 | % |

[0001327567-20-000007:mdna:81]
Research and development expense increased for the three and six months ended January 31, 2020 compared to the three and six months ended January 31, 2019. The increase was primarily due to personnel costs, which grew $46.2 million to $143.7 million for the three months ended January 31, 2020 compared to the three months ended January 31, 2019, and grew $91.5 million to $276.9 million for the six months ended January 31, 2020 compared to the six months ended January 31, 2019. The increase in personnel costs in both periods was primarily due to headcount growth. The remaining increase in both periods was primarily driven by an increase in allocated costs.

[0001327567-20-000007:mdna:82]
[same as prior period, unchanged from 0001327567-19-000038:mdna:82]

[0001327567-20-000007:mdna:83]
[same as prior period, unchanged from 0001327567-19-000038:mdna:83]

[0001327567-20-000007:mdna:84]
|  | Three Months Ended January 31, |  |  |  |  |  | Six Months Ended January 31, |  |  |  |  |
|  | 2020 |  | 2019 |  | Change |  | 2020 |  | 2019 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Sales and marketing | $ | 374.9 |  |  | $ | 320.0 |  |  | $ | 54.9 |  |  | 17.2 | % |  | $ | 740.6 |  |  | $ | 634.6 |  |  | $ | 106.0 |  |  | 16.7 | % |
| Number of employees at period end | 3,699 |  |  | 2,919 |  | 780 |  |  | 26.7 | % |  | 3,699 |  |  | 2,919 |  |  | 780 |  |  | 26.7 | % |

[0001327567-20-000007:mdna:85]
Sales and marketing expense increased for the three and six months ended January 31, 2020 compared to the three and six months ended January 31, 2019. The increase was primarily due to personnel costs, which grew $44.5 million to $288.5 million for the three months ended January 31, 2020 compared to the three months ended January 31, 2019, and grew $80.3 million to $551.6 million for the six months ended January 31, 2020 compared to the six months ended January 31, 2019. The increase in personnel costs in both periods was largely due to headcount growth. The remaining increase in both periods was primarily driven by an increase in costs associated with marketing-related activities.

[0001327567-20-000007:mdna:86]
[same as prior period, unchanged from 0001327567-19-000038:mdna:87]

[0001327567-20-000007:mdna:87]
[same as prior period, unchanged from 0001327567-19-000038:mdna:88]

[0001327567-20-000007:mdna:88]
[same as prior period, unchanged from 0001327567-19-000038:mdna:108]

[0001327567-20-000007:mdna:89]
|  | Three Months Ended January 31, |  |  |  |  |  | Six Months Ended January 31, |  |  |  |  |
|  | 2020 |  | 2019 |  | Change |  | 2020 |  | 2019 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| General and administrative | $ | 76.2 |  |  | $ | 53.7 |  |  | $ | 22.5 |  |  | 41.9 | % |  | $ | 146.0 |  |  | $ | 130.3 |  |  | $ | 15.7 |  |  | 12.0 | % |
| Number of employees at period end | 856 |  |  | 711 |  |  | 145 |  |  | 20.4 | % |  | 856 |  |  | 711 |  |  | 145 |  |  | 20.4 | % |

[0001327567-20-000007:mdna:90]
General and administrative expense increased for the three and six months ended January 31, 2020 compared to the three and six months ended January 31, 2019, primarily due to personnel costs, which increased $18.6 million to $55.6 million for the three months ended January 31, 2020 compared to the three months ended January 31, 2019, and increased $12.1 million to $101.9 million for the six months ended January 31, 2020 compared to the six months ended January 31, 2019. The increase in both periods were largely due to headcount growth. The increase in the six months ended January 31, 2020 was partially offset by the accelerated vesting of certain equity awards in connection with the RedLock acquisition of $14.2 million during the six months ended January 31, 2019.

[0001327567-20-000007:mdna:91]
[same as prior period, unchanged from 0001327567-19-000038:mdna:91]

[0001327567-20-000007:mdna:92]
Interest expense primarily consists of non-cash interest expense from the amortization of the debt discount and debt issuance costs related to our 0.0% Convertible Senior Notes due 2019 (the “2019 Notes”) and 0.75% Convertible Senior Notes due 2023 (the “2023 Notes” and, together with the 2019 Notes, the “Notes”), and also includes the contractual interest expense related to our 2023 Notes.

[0001327567-20-000007:mdna:93]
|  | Three Months Ended January 31, |  |  |  | Six Months Ended January 31, |  |  |
|  | 2020 |  | 2019 |  | Change |  | 2020 |  | 2019 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Interest expense | $ | 19.0 |  |  | $ | 20.6 |  |  | $ | (1.6 | ) |  | (7.8 | )% |  | $ | 37.9 |  |  | $ | 43.3 |  |  | $ | (5.4 | ) |  | (12.5 | )% |

[0001327567-20-000007:mdna:94]
Interest expense decreased for the three and six months ended January 31, 2020 compared to the three and six months ended January 31, 2019. The decrease in both periods was primarily due to conversions of the 2019 Notes before and upon maturity in July 2019. Refer to Note 9. Debt in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information on the Notes.

[0001327567-20-000007:mdna:95]
[same as prior period, unchanged from 0001327567-19-000038:mdna:96]

[0001327567-20-000007:mdna:96]
[same as prior period, unchanged from 0001327567-19-000038:mdna:97]

[0001327567-20-000007:mdna:97]
|  | Three Months Ended January 31, |  |  |  | Six Months Ended January 31, |  |  |
|  | 2020 |  | 2019 |  | Change |  | 2020 |  | 2019 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Other income, net | $ | 10.8 |  |  | $ | 16.0 |  |  | $ | (5.2 | ) |  | (32.5 | )% |  | $ | 27.0 |  |  | $ | 29.0 |  |  | $ | (2.0 | ) |  | (6.9 | )% |

[0001327567-20-000007:mdna:98]
Other income, net decreased for the three and six months ended January 31, 2020 compared to the three and six months ended January 31, 2019. The decrease was primarily due to lower interest income on our investments.

[0001327567-20-000007:mdna:99]
[same as prior period, unchanged from 0001327567-19-000038:mdna:124]

[0001327567-20-000007:mdna:100]
Provision for Income Taxes

[0001327567-20-000007:mdna:101]
Provision for income taxes consists primarily of income taxes in foreign jurisdictions in which we conduct business, withholding taxes, and U.S. state income taxes. We maintain a full valuation allowance for domestic and certain foreign deferred tax assets, including net operating loss carryforwards and certain domestic tax credits. In recent years, we reorganized our corporate structure and intercompany relationships to more closely align with the international nature of our business activities. Our corporate structure has caused, and may continue to cause, disproportionate relationships between our overall effective tax rate and other jurisdictional measures. To the extent we revisit our corporate structure, it may have an impact on our tax provision.

[0001327567-20-000007:mdna:102]
|  | Three Months Ended January 31, |  | Change |  | Six Months Ended January 31, |  | Change |
|  | 2020 |  | 2019 |  | Amount |  | % |  | 2020 |  | 2019 |  | Amount |  | % |
|  | (dollars in millions) |
| Provision for income taxes | $ | 12.6 |  |  | $ | 4.6 |  |  | $ | 8.0 |  |  | 173.9 | % |  | $ | 17.7 |  |  | $ | 1.1 |  |  | $ | 16.6 |  |  | 1,509.1 | % |
| Effective tax rate | (20.6 | )% |  | 230.0 | % |  |  |  |  |  | (15.3 | )% |  | (2.8 | )% |  |  |  |  |

[0001327567-20-000007:mdna:103]
We recorded an income tax provision for the three and six months ended January 31, 2020. The provision for income taxes for the three and six months ended January 31, 2020 was primarily due to income taxes in profitable foreign jurisdictions, U.S. state taxes, and withholding taxes. Our provision for income taxes increased for the three months ended January 31, 2020 compared to the three months ended January 31, 2019, primarily due to an increase in foreign withholding taxes. Our provision for income taxes increased for the six months ended January 31, 2020 compared to the six months ended January 31, 2019, due to an increase in withholding taxes and a decrease in one-time tax benefits relating to partial releases of our U.S. valuation allowance resulting from acquisitions. Refer to Note 14. Income Taxes in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information.

[0001327567-20-000007:mdna:104]
[same as prior period, unchanged from 0001327567-19-000038:mdna:104]

[0001327567-20-000007:mdna:105]
|  | January 31, 2020 |  | July 31, 2019 |
|  | (in millions) |
| Working capital | $ | 1,738.7 |  |  | $ | 1,611.5 |  |
| Cash, cash equivalents, and investments: |  |  |  |
| Cash and cash equivalents | $ | 2,000.0 |  |  | $ | 961.4 |  |
| Investments | 1,451.8 |  |  | 2,417.1 |  |
| Total cash, cash equivalents, and investments | $ | 3,451.8 |  |  | $ | 3,378.5 |  |

[0001327567-20-000007:mdna:106]
As of January 31, 2020, our total cash, cash equivalents, and investments of $3.5 billion were held for general corporate purposes, of which approximately $452.3 million was held outside of the United States. As of January 31, 2020, we had no unremitted earnings when evaluating our outside basis difference relating to our U.S. investment in foreign subsidiaries. However, there could be local withholding taxes payable due to various foreign countries if certain lower tier earnings are distributed. Withholding taxes that would be payable upon remittance of these lower tier earnings are not expected to be material.

[0001327567-20-000007:mdna:107]
In July 2018, we issued the 2023 Notes with an aggregate principal amount of $1.7 billion. The 2023 Notes mature on July 1, 2023; however, under certain circumstances, holders may surrender their 2023 Notes for conversion prior to the maturity date. Upon conversion of the 2023 Notes, we will pay cash equal to the aggregate principal amount of the 2023 Notes to be converted, and, at our election, will pay or deliver cash and/or shares of our common stock for the amount of our conversion obligation in excess of the aggregate principal amount of the 2023 Notes being converted. As of January 31, 2020, all of the 2023 Notes remained outstanding. Refer to Note 9. Debt in Part I, Item 1 of this Quarterly Report on Form 10-Q for information on the Notes.

[0001327567-20-000007:mdna:108]
In September 2018, we entered into a credit agreement (the “Credit Agreement”) that provides for a $400.0 million unsecured revolving credit facility (the “Credit Facility”), with an option to increase the amount of the credit facility up to an additional $350.0 million, subject to certain conditions. As of January 31, 2020, there were no amounts outstanding, and we were in compliance with all covenants under the Credit Agreement. Refer to Note 9. Debt in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information on the Credit Agreement.

[0001327567-20-000007:mdna:109]
In February 2019, our board of directors authorized a $1.0 billion share repurchase program which is funded from available working capital and will expire on December 31, 2020. As of January 31, 2020, $801.9 million remained available for future share repurchases under our current repurchase authorization. Refer to Note 12. Stockholders’ Equity in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information on the repurchase program. In February 2020, our board of directors approved the repurchase of $1.0 billion of our common stock through an accelerated share repurchase (“ASR”) transaction, which we expect to enter into during our fiscal quarter ending April 30, 2020, subject to market conditions. The ASR transaction is in addition to our

[0001327567-20-000007:mdna:110]
- 33 -

[0001327567-20-000007:mdna:111]
$1.0 billion share repurchase program that our board of directors authorized in February 2019. Refer to Note 17. Subsequent Events in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information on the ASR transaction.

[0001327567-20-000007:mdna:112]
The following table summarizes our cash flows for the six months ended January 31, 2020 and 2019:

[0001327567-20-000007:mdna:113]
|  | Six Months Ended January 31, |
| 2020 |  | 2019 |
|  | (in millions) |
| Net cash provided by operating activities | $ | 532.1 |  |  | $ | 527.7 |  |
| Net cash provided by (used in) investing activities | 680.9 |  |  | (1,236.9 | ) |
| Net cash used in financing activities | (173.2 | ) |  | (669.6 | ) |
| Net increase (decrease) in cash, cash equivalents, and restricted cash | $ | 1,039.8 |  |  | $ | (1,378.8 | ) |

[0001327567-20-000007:mdna:114]
[same as prior period, unchanged from 0001327567-19-000038:mdna:114]

[0001327567-20-000007:mdna:115]
[same as prior period, unchanged from 0001327567-19-000038:mdna:115]

[0001327567-20-000007:mdna:116]
[same as prior period, unchanged from 0001327567-19-000038:mdna:116]

[0001327567-20-000007:mdna:117]
[same as prior period, unchanged from 0001327567-19-000038:mdna:117]

[0001327567-20-000007:mdna:118]
Cash provided by operating activities during the six months ended January 31, 2020 was $532.1 million, a slight increase of $4.4 million compared to the six months ended January 31, 2019. The increase was primarily due to repayments of the 2019 Notes attributable to the debt discount during the six months ended January 31, 2019, partially offset by higher cash expenditure during the six months ended January 31, 2020.

[0001327567-20-000007:mdna:119]
[same as prior period, unchanged from 0001327567-19-000038:mdna:119]

[0001327567-20-000007:mdna:120]
[same as prior period, unchanged from 0001327567-19-000038:mdna:120]

[0001327567-20-000007:mdna:121]
Cash provided by investing activities during the six months ended January 31, 2020 was $680.9 million, a net change of $1,917.8 million compared to cash used in investing activities of $1,236.9 million during the six months ended January 31, 2019. The change was primarily due to lower purchases of investments and higher proceeds from maturities of investments, partially offset by an increase in net cash payments for business acquisitions and an increase in purchases of property, equipment and other assets during the six months ended January 31, 2020.

[0001327567-20-000007:mdna:122]
[same as prior period, unchanged from 0001327567-19-000038:mdna:122]

[0001327567-20-000007:mdna:123]
Our financing activities have consisted of repayments of the 2019 Notes, proceeds from sales of shares through employee equity incentive plans, cash used to repurchase shares of our common stock, and payments for tax withholding obligations of certain employees related to the net share settlement of equity awards.

[0001327567-20-000007:mdna:124]
Cash used in financing activities during the six months ended January 31, 2020 was $173.2 million, a decrease of $496.4 million compared to the six months ended January 31, 2019. The decrease was primarily due to repayments of our 2019 Notes during the six months ended January 31, 2019, and lower repurchases of our common stock during the six months ended January 31, 2020.

[0001327567-20-000007:mdna:125]
[same as prior period, unchanged from 0001327567-19-000038:mdna:126]

[0001327567-20-000007:mdna:126]
As of January 31, 2020, we did not have any relationships with unconsolidated organizations or financial partnerships, such as structured finance or special purpose entities that would have been established for the purpose of facilitating off-balance sheet arrangements or other contractually narrow or limited purposes.

[0001327567-20-000007:mdna:127]
- 34 -

[0001327567-20-000007:mdna:128]
[same as prior period, unchanged from 0001327567-19-000038:mdna:128]

[0001327567-20-000007:mdna:129]
[same as prior period, unchanged from 0001327567-19-000038:mdna:129]

[0001327567-20-000007:mdna:130]
[same as prior period, unchanged from 0001327567-19-000038:mdna:130]

[0001327567-20-000007:mdna:131]
[same as prior period, unchanged from 0001327567-19-000038:mdna:131]

[0001327567-20-000007:mdna:132]
Refer to “Recently Adopted Accounting Pronouncements” and “Recently Issued Accounting Pronouncements” in Note 1. Description of Business and Summary of Significant Accounting Policies in Part I, Item 1 of this Quarterly Report on Form 10-Q.
