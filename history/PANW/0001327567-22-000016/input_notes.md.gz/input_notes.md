# PANW notes — 0001327567-22-000016


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0001327567-22-000016:notes:1]
[same as prior period, unchanged from 0001327567-22-000008:notes:1]

[0001327567-22-000016:notes:2]
[same as prior period, unchanged from 0001327567-22-000008:notes:2]

[0001327567-22-000016:notes:3]
[same as prior period, unchanged from 0001327567-22-000008:notes:3]

[0001327567-22-000016:notes:4]
[same as prior period, unchanged from 0001327567-22-000008:notes:4]

[0001327567-22-000016:notes:5]
[same as prior period, unchanged from 0001327567-22-000008:notes:5]

[0001327567-22-000016:notes:6]
[same as prior period, unchanged from 0001327567-22-000008:notes:6]

[0001327567-22-000016:notes:7]
The preparation of condensed consolidated financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the condensed consolidated financial statements and the reported amounts of revenues and expenses during the reporting period. We base our estimates on historical experience and also on assumptions that we believe are reasonable. Actual results could differ materially from those estimates due to risks and uncertainties, including uncertainty in the economic environment such as the global impact of the coronavirus disease discovered in 2019 (“COVID-19”).

[0001327567-22-000016:notes:8]
[same as prior period, unchanged from 0001327567-22-000008:notes:8]

[0001327567-22-000016:notes:9]
There have been no material changes to our significant accounting policies as of and for the nine months ended April 30, 2022, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended July 31, 2021, except for the change in our accounting policies due to our adoption of recently issued guidance. Refer to “Recently Adopted Accounting Pronouncements” below.

[0001327567-22-000016:notes:10]
Recently Adopted Accounting Pronouncements

[0001327567-22-000016:notes:11]
[same as prior period, unchanged from 0001327567-22-000008:notes:11]

[0001327567-22-000016:notes:12]
[same as prior period, unchanged from 0001327567-22-000008:notes:12]

[0001327567-22-000016:notes:13]
[same as prior period, unchanged from 0001327567-22-000008:notes:13]

[0001327567-22-000016:notes:14]
[same as prior period, unchanged from 0001327567-22-000008:notes:14]

[0001327567-22-000016:notes:15]
[same as prior period, unchanged from 0001327567-22-000008:notes:15]

[0001327567-22-000016:notes:16]
[same as prior period, unchanged from 0001327567-22-000008:notes:16]

[0001327567-22-000016:notes:17]
[same as prior period, unchanged from 0001327567-22-000008:notes:17]

[0001327567-22-000016:notes:18]
[same as prior period, unchanged from 0001327567-22-000008:notes:18]

[0001327567-22-000016:notes:19]
[same as prior period, unchanged from 0001327567-22-000008:notes:19]

[0001327567-22-000016:notes:20]
[same as prior period, unchanged from 0001327567-22-000008:notes:20]

[0001327567-22-000016:notes:21]
[same as prior period, unchanged from 0001327567-22-000008:notes:21]


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001327567-22-000016:notes:22]
[same as prior period, unchanged from 0001327567-22-000008:notes:22]

[0001327567-22-000016:notes:23]
[same as prior period, unchanged from 0001327567-22-000008:notes:23]

[0001327567-22-000016:notes:24]
|  | Three Months Ended April 30, |  | Nine Months Ended April 30, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Revenue: |  |  |  |  |  |  |  |
| Americas |  |  |  |  |  |  |  |
| United States | $ | 887.2 |  |  | $ | 683.1 |  |  | $ | 2,557.5 |  |  | $ | 1,950.3 |  |
| Other Americas | 61.5 |  |  | 49.3 |  |  | 173.8 |  |  | 138.4 |  |
| Total Americas | 948.7 |  |  | 732.4 |  |  | 2,731.3 |  |  | 2,088.7 |  |
| Europe, the Middle East, and Africa (“EMEA”) | 269.5 |  |  | 211.0 |  |  | 755.5 |  |  | 590.6 |  |
| Asia Pacific and Japan (“APAC”) | 168.5 |  |  | 130.5 |  |  | 464.2 |  |  | 357.5 |  |
| Total revenue | $ | 1,386.7 |  |  | $ | 1,073.9 |  |  | $ | 3,951.0 |  |  | $ | 3,036.8 |  |

[0001327567-22-000016:notes:25]
[same as prior period, unchanged from 0001327567-22-000008:notes:25]

[0001327567-22-000016:notes:26]
|  | Three Months Ended April 30, |  | Nine Months Ended April 30, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Revenue: |  |  |  |  |  |  |  |
| Product | $ | 351.5 |  |  | $ | 288.9 |  |  | $ | 955.0 |  |  | $ | 780.9 |  |
| Subscription and support |  |  |  |  |  |  |  |
| Subscription | 639.8 |  |  | 473.8 |  |  | 1,836.6 |  |  | 1,363.5 |  |
| Support | 395.4 |  |  | 311.2 |  |  | 1,159.4 |  |  | 892.4 |  |
| Total subscription and support | 1,035.2 |  |  | 785.0 |  |  | 2,996.0 |  |  | 2,255.9 |  |
| Total revenue | $ | 1,386.7 |  |  | $ | 1,073.9 |  |  | $ | 3,951.0 |  |  | $ | 3,036.8 |  |

[0001327567-22-000016:notes:27]
[same as prior period, unchanged from 0001327567-22-000008:notes:27]

[0001327567-22-000016:notes:28]
During the nine months ended April 30, 2022 and 2021, we recognized approximately $2.2 billion and $1.6 billion of revenue pertaining to amounts that were deferred as of July 31, 2021 and 2020, respectively.

[0001327567-22-000016:notes:29]
[same as prior period, unchanged from 0001327567-22-000008:notes:29]

[0001327567-22-000016:notes:30]
Revenue expected to be recognized from remaining performance obligations was $6.9 billion as of April 30, 2022, of which we expect to recognize approximately $3.6 billion over the next 12 months and the remainder thereafter.


## us-gaap:FairValueDisclosuresTextBlock

[0001327567-22-000016:notes:31]
[same as prior period, unchanged from 0001327567-22-000008:notes:31]

[0001327567-22-000016:notes:32]
[same as prior period, unchanged from 0001327567-22-000008:notes:32]

[0001327567-22-000016:notes:33]
[same as prior period, unchanged from 0001327567-22-000008:notes:33]

[0001327567-22-000016:notes:34]
•Level 3—Inputs are unobservable inputs based on our own assumptions used to measure assets and liabilities at fair value. The inputs require significant management judgment or estimation.
The following table presents the fair value of our financial assets and liabilities measured at fair value on a recurring basis as of April 30, 2022 and July 31, 2021 (in millions):

[0001327567-22-000016:notes:35]
|  |  | April 30, 2022 |  | July 31, 2021 |
|  |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Cash equivalents: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 923.0 |  |  | $ | — |  |  | $ | — |  |  | $ | 923.0 |  |  | $ | 124.2 |  |  | $ | — |  |  | $ | — |  |  | $ | 124.2 |  |
| Certificates of deposit |  | — |  |  | 50.0 |  |  | — |  |  | 50.0 |  |  | — |  |  | 150.4 |  |  | — |  |  | 150.4 |  |
| Commercial paper |  | — |  |  | 17.9 |  |  | — |  |  | 17.9 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Corporate debt securities |  | — |  |  | 3.9 |  |  | — |  |  | 3.9 |  |  | — |  |  | 1.0 |  |  | — |  |  | 1.0 |  |
| U.S. government and agency securities |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 116.3 |  |  | — |  |  | 116.3 |  |
| Total cash equivalents |  | 923.0 |  |  | 71.8 |  |  | — |  |  | 994.8 |  |  | 124.2 |  |  | 267.7 |  |  | — |  |  | 391.9 |  |
| Short-term investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Certificates of deposit |  | — |  |  | 205.5 |  |  | — |  |  | 205.5 |  |  | — |  |  | 12.4 |  |  | — |  |  | 12.4 |  |
| Commercial paper |  | — |  |  | 11.0 |  |  | — |  |  | 11.0 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Corporate debt securities |  | — |  |  | 351.4 |  |  | — |  |  | 351.4 |  |  | — |  |  | 208.9 |  |  | — |  |  | 208.9 |  |
| U.S. government and agency securities |  | — |  |  | 826.7 |  |  | — |  |  | 826.7 |  |  | — |  |  | 762.1 |  |  | — |  |  | 762.1 |  |
| Non-U.S. government and agency securities |  |  |  | 60.1 |  |  |  |  | 60.1 |  |  |  |  | 43.5 |  |  |  |  | 43.5 |  |
| Total short-term investments |  | — |  |  | 1,454.7 |  |  | — |  |  | 1,454.7 |  |  | — |  |  | 1,026.9 |  |  | — |  |  | 1,026.9 |  |
| Long-term investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Certificates of deposit |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 5.0 |  |  | — |  |  | 5.0 |  |
| Corporate debt securities |  | — |  |  | 393.2 |  |  | — |  |  | 393.2 |  |  | — |  |  | 180.7 |  |  | — |  |  | 180.7 |  |
| U.S. government and agency securities |  | — |  |  | 242.9 |  |  | — |  |  | 242.9 |  |  | — |  |  | 674.1 |  |  | — |  |  | 674.1 |  |
| Non-U.S. government and agency securities |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 28.5 |  |  | — |  |  | 28.5 |  |
| Asset-backed securities |  | — |  |  | 78.6 |  |  | — |  |  | 78.6 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Total long-term investments |  | — |  |  | 714.7 |  |  | — |  |  | 714.7 |  |  | — |  |  | 888.3 |  |  | — |  |  | 888.3 |  |
| Prepaid expenses and other current assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency forward contracts |  | — |  |  | 0.3 |  |  | — |  |  | 0.3 |  |  | — |  |  | 4.1 |  |  | — |  |  | 4.1 |  |
| Total prepaid expenses and other current assets |  | — |  |  | 0.3 |  |  | — |  |  | 0.3 |  |  | — |  |  | 4.1 |  |  | — |  |  | 4.1 |  |
| Other assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency forward contracts |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 0.1 |  |  | — |  |  | 0.1 |  |
| Total other assets: |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 0.1 |  |  | — |  |  | 0.1 |  |
| Total assets measured at fair value |  | $ | 923.0 |  |  | $ | 2,241.5 |  |  | $ | — |  |  | $ | 3,164.5 |  |  | $ | 124.2 |  |  | $ | 2,187.1 |  |  | $ | — |  |  | $ | 2,311.3 |  |
| Accrued and other liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency forward contracts |  | $ | — |  |  | $ | 31.6 |  |  | $ | — |  |  | $ | 31.6 |  |  | $ | — |  |  | $ | 6.4 |  |  | $ | — |  |  | $ | 6.4 |  |
| Total accrued and other liabilities |  | — |  |  | 31.6 |  |  | — |  |  | 31.6 |  |  | — |  |  | 6.4 |  |  | — |  |  | 6.4 |  |
| Other long-term liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency forward contracts |  | — |  |  | 1.0 |  |  | — |  |  | 1.0 |  |  | — |  |  | 0.5 |  |  | — |  |  | 0.5 |  |
| Total other long-term liabilities |  | — |  |  | 1.0 |  |  | — |  |  | 1.0 |  |  | — |  |  | 0.5 |  |  | — |  |  | 0.5 |  |
| Total liabilities measured at fair value |  | $ | — |  |  | $ | 32.6 |  |  | $ | — |  |  | $ | 32.6 |  |  | $ | — |  |  | $ | 6.9 |  |  | $ | — |  |  | $ | 6.9 |  |

[0001327567-22-000016:notes:36]
Refer to Note 9. Debt for the carrying amount and estimated fair value of our convertible senior notes as of April 30, 2022 and July 31, 2021.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001327567-22-000016:notes:37]
Cash Equivalents and Investments
Available-for-sale Debt Securities

[0001327567-22-000016:notes:38]
The following tables summarize the amortized cost, unrealized gains and losses, and fair value of our available-for-sale debt securities as of April 30, 2022 and July 31, 2021 (in millions):

[0001327567-22-000016:notes:39]
|  | April 30, 2022 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 50.0 |  |  | $ | — |  |  | $ | — |  |  | $ | 50.0 |  |
| Commercial paper | 17.9 |  |  | — |  |  | — |  |  | 17.9 |  |
| Corporate debt securities | 3.9 |  |  | — |  |  | — |  |  | 3.9 |  |
| Total available-for-sale cash equivalents | $ | 71.8 |  |  | $ | — |  |  | $ | — |  |  | $ | 71.8 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 205.5 |  |  | $ | — |  |  | $ | — |  |  | $ | 205.5 |  |
| Commercial paper | 11.0 |  |  | — |  |  | — |  |  | 11.0 |  |
| Corporate debt securities | 755.7 |  |  | — |  |  | (11.1) |  |  | 744.6 |  |
| U.S. government and agency securities | 1,081.6 |  |  | — |  |  | (12.0) |  |  | 1,069.6 |  |
| Non-U.S. government and agency securities | 60.4 |  |  | — |  |  | (0.3) |  |  | 60.1 |  |
| Asset-backed securities | 79.3 |  |  | — |  |  | (0.7) |  |  | 78.6 |  |
| Total available-for-sale investments | $ | 2,193.5 |  |  | $ | — |  |  | $ | (24.1) |  |  | $ | 2,169.4 |  |

[0001327567-22-000016:notes:40]
|  | July 31, 2021 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 150.4 |  |  | $ | — |  |  | $ | — |  |  | $ | 150.4 |  |
| Corporate debt securities | 1.0 |  |  | — |  |  | — |  |  | 1.0 |  |
| U.S. government and agency securities | 116.3 |  |  | — |  |  | — |  |  | 116.3 |  |
| Total available-for-sale cash equivalents | $ | 267.7 |  |  | $ | — |  |  | $ | — |  |  | $ | 267.7 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 17.4 |  |  | $ | — |  |  | $ | — |  |  | $ | 17.4 |  |
| Corporate debt securities | 389.2 |  |  | 0.5 |  |  | (0.1) |  |  | 389.6 |  |
| U.S. government and agency securities | 1,435.1 |  |  | 1.1 |  |  | — |  |  | 1,436.2 |  |
| Non-U.S. government and agency securities | 72.0 |  |  | — |  |  | — |  |  | 72.0 |  |
| Total available-for-sale investments | $ | 1,913.7 |  |  | $ | 1.6 |  |  | $ | (0.1) |  |  | $ | 1,915.2 |  |

[0001327567-22-000016:notes:41]
We do not intend to sell any of the securities in an unrealized loss position and it is not likely that we would be required to sell these securities before recovery of their amortized cost basis, which may be at maturity. We did not recognize any credit losses related to our available-for-sale debt securities during the three and nine months ended April 30, 2022 and 2021.

[0001327567-22-000016:notes:42]
The following table summarizes the amortized cost and fair value of our available-for-sale debt securities as of April 30, 2022, by contractual years-to-maturity (in millions):

[0001327567-22-000016:notes:43]
|  | Amortized Cost |  | Fair Value |
| Due within one year | $ | 1,536.2 |  |  | $ | 1,526.5 |  |
| Due between one and three years | 675.2 |  |  | 661.3 |  |
| Due between three to five years | 49.6 |  |  | 49.1 |  |
| Due between five to ten years | 4.3 |  |  | 4.3 |  |
| Total | $ | 2,265.3 |  |  | $ | 2,241.2 |  |

[0001327567-22-000016:notes:44]
Marketable Equity Securities

[0001327567-22-000016:notes:45]
Marketable equity securities consist of money market funds and are included in cash and cash equivalents on our condensed consolidated balance sheets. As of April 30, 2022 and July 31, 2021, the carrying values of our marketable equity securities were $923.0 million and $124.2 million, respectively. There were no unrealized gains or losses recognized for these securities during the three and nine months ended April 30, 2022 and 2021.


## us-gaap:FinancingReceivablesTextBlock

[0001327567-22-000016:notes:46]
Financing ReceivablesWe provide financing arrangements, primarily loans, to qualified end-user customers to purchase our products and services. The following table summarizes our short-term and long-term financing receivables as of April 30, 2022 and July 31, 2021 (in millions):

[0001327567-22-000016:notes:47]
|  |  | April 30, 2022 |  | July 31, 2021 |
| Short-term financing receivables, gross |  | $ | 118.1 |  |  | $ | 80.0 |  |
| Allowance for credit losses |  | (1.3) |  |  | (1.0) |  |
| Short-term financing receivables, net |  | $ | 116.8 |  |  | $ | 79.0 |  |
| Long-term financing receivables, gross |  | $ | 180.0 |  |  | $ | 198.6 |  |
| Allowance for credit losses |  | (2.7) |  |  | (4.3) |  |
| Long-term financing receivables, net |  | $ | 177.3 |  |  | $ | 194.3 |  |

[0001327567-22-000016:notes:48]
There was no significant activity in allowance for credit losses during the three and nine months ended April 30, 2022 and 2021. Past due amounts on financing receivables were immaterial as of April 30, 2022 and July 31, 2021.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001327567-22-000016:notes:49]
[same as prior period, unchanged from 0001327567-22-000008:notes:49]

[0001327567-22-000016:notes:50]
As of April 30, 2022 and July 31, 2021, the total notional amount of our outstanding foreign currency forward contracts including designated and non-designated derivative instruments was $886.7 million and $531.9 million, respectively. Refer to Note 3. Fair Value Measurements for the fair value of our foreign currency derivative instruments as reported on our condensed consolidated balance sheets as of April 30, 2022 and July 31, 2021.

[0001327567-22-000016:notes:51]
During the three and nine months ended April 30, 2022 and 2021, both unrealized gains and losses recognized in accumulated other comprehensive income (loss) (“AOCI”) related to our cash flow hedges and amounts reclassified into earnings were not material. Unrealized gains and losses in AOCI related to our cash flow hedges as of April 30, 2022 and July 31, 2021 were not material.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001327567-22-000016:notes:52]
[same as prior period, unchanged from 0001327567-22-000008:notes:52]


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001327567-22-000016:notes:53]
[same as prior period, unchanged from 0001327567-22-000008:notes:53]

[0001327567-22-000016:notes:54]
The following table presents details of our goodwill during the nine months ended April 30, 2022 (in millions):

[0001327567-22-000016:notes:55]
|  | Amount |
| Balance as of July 31, 2021 | $ | 2,710.1 |  |
| Goodwill acquired | 21.2 |  |
| Balance as of April 30, 2022 | $ | 2,731.3 |  |

[0001327567-22-000016:notes:56]
[same as prior period, unchanged from 0001327567-22-000008:notes:56]

[0001327567-22-000016:notes:57]
The following table presents details of our purchased intangible assets as of April 30, 2022 and July 31, 2021 (in millions):

[0001327567-22-000016:notes:58]
|  | April 30, 2022 |  | July 31, 2021 |
|  | Gross Carrying Amount |  | Accumulated Amortization |  | Net Carrying Amount |  | Gross Carrying Amount |  | Accumulated Amortization |  | Net Carrying Amount |
| Intangible assets subject to amortization: |  |  |  |  |  |  |  |  |  |  |  |
| Developed technology | $ | 600.7 |  |  | $ | (322.2) |  |  | $ | 278.5 |  |  | $ | 596.2 |  |  | $ | (243.8) |  |  | $ | 352.4 |  |
| Customer relationships | 172.7 |  |  | (46.8) |  |  | 125.9 |  |  | 172.7 |  |  | (30.6) |  |  | 142.1 |  |
| Acquired intellectual property | 11.3 |  |  | (4.5) |  |  | 6.8 |  |  | 7.9 |  |  | (3.8) |  |  | 4.1 |  |
| Trade name and trademarks | 9.4 |  |  | (9.4) |  |  | — |  |  | 9.4 |  |  | (9.4) |  |  | — |  |
| Other | 0.9 |  |  | — |  |  | 0.9 |  |  | 1.8 |  |  | (1.8) |  |  | — |  |
| Total purchased intangible assets | $ | 795.0 |  |  | $ | (382.9) |  |  | $ | 412.1 |  |  | $ | 788.0 |  |  | $ | (289.4) |  |  | $ | 498.6 |  |

[0001327567-22-000016:notes:59]
We recognized amortization expense of $31.8 million and $95.3 million for the three and nine months ended April 30, 2022, respectively, and $32.8 million and $86.1 million for the three and nine months ended April 30, 2021, respectively.

[0001327567-22-000016:notes:60]
The following table summarizes estimated future amortization expense of our intangible assets as of April 30, 2022 (in millions):

[0001327567-22-000016:notes:61]
|  |  |  | Fiscal years ending July 31, |
|  | Total |  | Remaining 2022 |  | 2023 |  | 2024 |  | 2025 |  | 2026 |  | 2027 and thereafter |
| Future amortization expense | $ | 412.1 |  |  | $ | 31.6 |  |  | $ | 101.1 |  |  | $ | 91.1 |  |  | $ | 77.4 |  |  | $ | 55.6 |  |  | $ | 55.3 |  |

[0001327567-22-000016:notes:62]
[same as prior period, unchanged from 0001327567-22-000008:notes:62]

[0001327567-22-000016:notes:63]
During the nine months ended April 30, 2022, we purchased 4.6 acres of land adjacent to our headquarters in Santa Clara, California, along with the associated buildings, for $39.5 million to accommodate future expansion of our headquarters. This amount was recorded in property and equipment, net on our condensed consolidated balance sheet as of April 30, 2022.


## us-gaap:DebtDisclosureTextBlock

[0001327567-22-000016:notes:64]
Debt
Convertible Senior Notes

[0001327567-22-000016:notes:65]
In July 2018, we issued $1.7 billion aggregate principal amount of 0.75% Convertible Senior Notes due 2023 (the “2023 Notes”) and in June 2020, we issued $2.0 billion aggregate principal amount of 0.375% Convertible Senior Notes due 2025 (the “2025 Notes,” and together with the 2023 Notes, the “Notes”). The 2023 Notes bear interest at a fixed rate of 0.75% per year, payable semi-annually in arrears on January 1 and July 1 of each year, beginning on January 1, 2019. The 2025 Notes bear interest at a fixed rate of 0.375% per year, payable semi-annually in arrears on June 1 and December 1 of each year, beginning on December 1, 2020. Each series of the convertible notes is governed by an indenture between us, as the issuer, and U.S. Bank National Association, as Trustee (individually, each an “Indenture,” and together, the “Indentures”). The Notes of each series are unsecured, unsubordinated obligations and the applicable Indenture governing each series of Notes does not contain any financial covenants or restrictions on the payments of dividends, the incurrence of indebtedness, or the issuance or repurchase of securities by us or any of our subsidiaries. The 2023 Notes and the 2025 Notes mature on July 1, 2023 and June 1, 2025, respectively. We cannot redeem the 2023 Notes prior to maturity. We may redeem for cash all or any portion of the 2025 Notes, at our option, on or after June 5, 2023, and prior to the 31st scheduled trading day immediately preceding the maturity date if the last reported sale price of our common stock has been at least 130% of the conversion price then in effect for at least 20 trading days during any 30 consecutive trading day period ending on and including the trading day preceding the date on which we provide notice of redemption. The redemption will be at a price equal to 100% of the

[0001327567-22-000016:notes:66]
principal amount of the 2025 Notes and adjusted for interest. If we call any or all of the 2025 Notes for redemption, holders may convert such 2025 Notes called for redemption at any time prior to the close of business on the second scheduled trading day immediately preceding the redemption date.

[0001327567-22-000016:notes:67]
The following table presents details of our Notes (number of shares in millions):

[0001327567-22-000016:notes:68]
|  | Conversion Rate per $1,000 Principal |  | Initial Conversion Price |  | Convertible Date |  | Initial Number of Shares |
| 2023 Notes | 3.7545 |  |  | $ | 266.35 |  |  | April 1, 2023 |  | 6.4 |  |
| 2025 Notes | 3.3602 |  |  | $ | 297.60 |  |  | March 1, 2025 |  | 6.7 |  |

[0001327567-22-000016:notes:69]
Holders of the Notes may surrender their Notes for conversion at their option at any time prior to the close of business on the business day immediately preceding their respective convertible dates only under the following circumstances:

[0001327567-22-000016:notes:70]
•during any fiscal quarter commencing after the fiscal quarters ending on October 31, 2018 and October 31, 2020 for the 2023 Notes and the 2025 Notes, respectively (and only during such fiscal quarter), if the last reported sale price of our common stock for at least 20 trading days (whether or not consecutive) during a period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the applicable conversion price for the respective Notes on each applicable trading day (the “sale price condition”);

[0001327567-22-000016:notes:71]
•during the five business day period after any five consecutive trading day period (the “measurement period”) in which the trading price per $1,000 principal amount of the applicable series of Notes for each trading day of the measurement period was less than 98% of the product of the last reported sale price of our common stock and the applicable conversion rate for the respective Notes on each such trading day; or

[0001327567-22-000016:notes:72]
•upon the occurrence of specified corporate events.

[0001327567-22-000016:notes:73]
On or after the respective convertible date, holders may surrender all or any portion of their Notes for conversion at any time prior to the close of business on the second scheduled trading day immediately preceding the applicable maturity date regardless of the foregoing conditions, and such conversions will be settled upon the applicable maturity date. Upon conversion, holders of the Notes of a series will receive cash equal to the aggregate principal amount of the Notes of such series to be converted, and, at our election, cash and/or shares of our common stock for any amounts in excess of the aggregate principal amount of the Notes of such series being converted.

[0001327567-22-000016:notes:74]
The conversion price will be subject to adjustment in some events. Holders of the Notes of a series who convert their Notes of such series in connection with certain corporate events that constitute a “make-whole fundamental change” under the applicable Indenture are, under certain circumstances, entitled to an increase in the conversion rate for such series of Notes. Additionally, upon the occurrence of a corporate event that constitutes a “fundamental change” under the applicable Indenture, holders of the Notes of such series may require us to repurchase for cash all or a portion of the Notes of such series at a repurchase price equal to 100% of the principal amount of the Notes of such series plus accrued and unpaid interest to, but excluding, the fundamental change repurchase date.

[0001327567-22-000016:notes:75]
The sale price condition for the Notes was met during the fiscal quarter ended April 30, 2022, and as a result, holders may convert their Notes at any time during the fiscal quarter ending July 31, 2022. Accordingly, the net carrying amount of the Notes was classified as a current liability on our condensed consolidated balance sheet as of April 30, 2022.

[0001327567-22-000016:notes:76]
The following table sets forth the components of the Notes as of April 30, 2022 and July 31, 2021 (in millions):

[0001327567-22-000016:notes:77]
|  | April 30, 2022 (1) | July 31, 2021 |
|  | 2023 Notes |  | 2025 Notes |  | Total |  | 2023 Notes |  | 2025 Notes |  | Total |
| Liability component: |  |  |  |  |  |  |  |  |  |  |  |
| Principal | $ | 1,692.0 |  |  | $ | 2,000.0 |  |  | $ | 3,692.0 |  |  | $ | 1,692.0 |  |  | $ | 2,000.0 |  |  | $ | 3,692.0 |  |
| Less: debt discount and debt issuance costs, net of amortization | (3.3) |  |  | (13.0) |  |  | (16.3) |  |  | (134.1) |  |  | (331.9) |  |  | (466.0) |  |
| Net carrying amount | $ | 1,688.7 |  |  | $ | 1,987.0 |  |  | $ | 3,675.7 |  |  | $ | 1,557.9 |  |  | $ | 1,668.1 |  |  | $ | 3,226.0 |  |
| Equity component (including amounts classified as temporary equity) | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 315.0 |  |  | $ | 403.0 |  |  | $ | 718.0 |  |

[0001327567-22-000016:notes:78]
______________

[0001327567-22-000016:notes:79]
(1)     As described in Note 1. Description of Business and Summary of Significant Accounting Policies, we adopted new debt guidance effective August 1, 2021, using a modified retrospective method, under which financial results reported in prior periods were not adjusted. Upon adoption, our convertible senior notes are accounted for entirely as a liability and measured at their amortized cost. Transaction costs related to the issuance of the notes are netted with the liability and are amortized on a straight-line basis, which approximates the effective interest rate method, to interest expense over the term of the notes.

[0001327567-22-000016:notes:80]
The total estimated fair value of the 2023 Notes and 2025 Notes were $3.6 billion and $4.0 billion at April 30, 2022, respectively and $2.6 billion and $2.9 billion at July 31, 2021, respectively. The fair value was determined based on the closing trading price per $100 of the applicable series of the Notes as of the last day of trading for the period. We consider the fair value of the Notes at April 30, 2022 and July 31, 2021 to be a Level 2 measurement. The fair value of the Notes is primarily affected by the trading price of our common stock and market interest rates.

[0001327567-22-000016:notes:81]
The following table sets forth interest expense recognized related to the Notes (dollars in millions):

[0001327567-22-000016:notes:82]
|  | Three Months Ended April 30, |  | Nine Months Ended April 30, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
|  | 2023 Notes |  | 2025 Notes |  | Total |  | 2023 Notes |  |  |  | 2025 Notes |  | Total |  | 2023 Notes |  | 2025 Notes |  | Total |  | 2023 Notes |  | 2025 Notes |  | Total |
| Contractual interest expense | $ | 3.2 |  | $ | 1.8 |  | $ | 5.0 |  |  | $ | 3.2 |  |  |  | $ | 1.8 |  | $ | 5.0 |  | $ | 9.5 |  | $ | 5.6 |  | $ | 15.1 |  |  | $ | 9.5 |  | $ | 5.6 |  | $ | 15.1 |  |
| Amortization of debt discount(1) | — |  | — |  | — |  |  | 16.0 |  |  |  | 18.6 |  | 34.6 |  | — |  | — |  | — |  |  | 47.4 |  | 55.3 |  | 102.7 |  |
| Amortization of debt issuance costs | 0.7 |  | 1.1 |  | 1.8 |  |  | 0.6 |  |  |  | 0.7 |  | 1.3 |  | 2.1 |  | 3.3 |  | 5.4 |  |  | 1.7 |  | 2.1 |  | 3.8 |  |
| Total interest expense | $ | 3.9 |  | $ | 2.9 |  | $ | 6.8 |  |  | $ | 19.8 |  |  |  | $ | 21.1 |  | $ | 40.9 |  | $ | 11.6 |  | $ | 8.9 |  | $ | 20.5 |  |  | $ | 58.6 |  | $ | 63.0 |  | $ | 121.6 |  |
| Effective interest rate | 0.9 | % |  | 0.6 | % |  |  |  | 5.2 | % |  |  |  | 5.4 | % |  |  |  | 0.9 | % |  | 0.6 | % |  |  |  | 5.2 | % |  | 5.4 | % |  |  |

[0001327567-22-000016:notes:83]
(1)    Upon adoption of the new debt guidance, the conversion option is no longer separately accounted for as debt discount. Our convertible senior notes are accounted for entirely as a liability.

[0001327567-22-000016:notes:84]
Note Hedges

[0001327567-22-000016:notes:85]
To minimize the impact of potential economic dilution upon conversion of our Notes, we entered into separate convertible note hedge transactions (the “2023 Note Hedges,” with respect to the 2023 Notes, the “2025 Note Hedges,” with respect to the 2025 Notes, and the 2023 Notes Hedges together with 2025 Note Hedges, the “Note Hedges”) with respect to our common stock concurrent with the issuance of each series of the Notes.

[0001327567-22-000016:notes:86]
The following table presents details of our Note Hedges (in millions):

[0001327567-22-000016:notes:87]
|  | Initial Number of Shares |  | Aggregate Purchase |
| 2023 Note Hedges | 6.4 |  |  | $ | 332.0 |  |
| 2025 Note Hedges | 6.7 |  |  | $ | 370.8 |  |

[0001327567-22-000016:notes:88]
The Note Hedges cover shares of our common stock at a strike price per share that corresponds to the initial applicable conversion price of the applicable series of the Notes, which are also subject to adjustment, and are exercisable upon conversion of the applicable series of the Notes. The Note Hedges will expire upon maturity of the applicable series of the Notes. The Note Hedges are

[0001327567-22-000016:notes:89]
separate transactions and are not part of the terms of the applicable series of the Notes. Holders of the Notes of either series will not have any rights with respect to the Note Hedges. Any shares of our common stock receivable by us under the Note Hedges are excluded from the calculation of diluted earnings per share as they are antidilutive. The aggregate amounts paid for the Note Hedges are included in additional paid-in capital on our condensed consolidated balance sheets.

[0001327567-22-000016:notes:90]
Warrants

[0001327567-22-000016:notes:91]
Separately, but concurrently with the issuance of each series of our Notes, we entered into transactions whereby we sold warrants (the “2023 Warrants,” with respect to the 2023 Notes, the “2025 Warrants,” with respect to the 2025 Notes, and the 2023 Warrants together with the 2025 Warrants, the “Warrants”) to acquire shares of our common stock, subject to anti-dilution adjustments. The 2023 Warrants and 2025 Warrants are exercisable beginning October 2023 and September 2025, respectively.

[0001327567-22-000016:notes:92]
The following table presents details of the Warrants (in millions, except per share data):

[0001327567-22-000016:notes:93]
|  | Initial Number of Shares |  | Strike Price per Share |  | Aggregate Proceeds |
| 2023 Warrants | 6.4 |  |  | $ | 417.80 |  |  | $ | 145.4 |  |
| 2025 Warrants | 6.7 |  |  | $ | 408.47 |  |  | $ | 202.8 |  |

[0001327567-22-000016:notes:94]
The shares issuable under the Warrants will be included in the calculation of diluted earnings per share when the average market value per share of our common stock for the reporting period exceeds the applicable strike price for such series of Warrants. The Warrants are separate transactions and are not part of either series of Notes or Note Hedges and are not remeasured through earnings each reporting period. Holders of the Notes of either series will not have any rights with respect to the Warrants. The aggregate proceeds received from the sale of the Warrants are included in additional paid-in capital on our condensed consolidated balance sheets.

[0001327567-22-000016:notes:95]
Revolving Credit Facility

[0001327567-22-000016:notes:96]
On September 4, 2018, we entered into a credit agreement (the “Credit Agreement”) with certain institutional lenders that provides for a $400.0 million unsecured revolving credit facility (the “Credit Facility”), with an option to increase the amount of the Credit Facility by up to an additional $350.0 million, subject to certain conditions. The Credit Facility matures on the earlier of (i) September 4, 2023 and (ii) the date that is 91 days prior to the stated maturity of our 2023 Notes if (a) any of the 2023 Notes are still outstanding and (b) our unrestricted cash and cash equivalents are less than the then outstanding principal amount of our 2023 Notes plus $400.0 million.

[0001327567-22-000016:notes:97]
The borrowings under the Credit Facility currently bear interest, at our option, at a base rate plus a spread of 0.00% to 0.75%, or an adjusted LIBO Rate plus a spread of 1.00% to 1.75%, in each case with such spread being determined based on our leverage ratio. We are obligated to pay an ongoing commitment fee on undrawn amounts at a rate of 0.125% to 0.250%, depending on our leverage ratio. In March 2021, the ICE Benchmark Administration, the administrator of LIBO Rate, announced that it will cease publication of LIBO rate by June 2023. Under the terms of our Credit Facility, in the event of the discontinuance of the LIBO Rate, a mutually agreed-upon alternative benchmark rate will be established to replace the LIBO Rate, which may include the Secured Overnight Financing Rate (“SOFR”). We do not anticipate that the discontinuance of the LIBO Rate will materially impact our liquidity or financial position.

[0001327567-22-000016:notes:98]
As of April 30, 2022, there were no amounts outstanding and we were in compliance with all covenants under the Credit Agreement.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001327567-22-000016:notes:99]
Commitments and Contingencies
Purchase Commitments

[0001327567-22-000016:notes:100]
Manufacturing Purchase Commitments

[0001327567-22-000016:notes:101]
In order to reduce manufacturing lead times and plan for adequate supply, we enter into agreements with manufacturing partners and component suppliers to procure inventory based on our demand forecasts. The following table presents details of the aggregate future purchase commitments under these arrangements, excluding obligations under contracts that we can cancel without a significant penalty as of April 30, 2022 (in millions):

[0001327567-22-000016:notes:102]
|  |  |  | Fiscal years ending July 31, |
|  | Total |  | Remaining 2022 |  | 2023 |  | 2024 |  | 2025 |  | 2026 |  | 2027 and thereafter |
| Manufacturing purchase commitments | $ | 360.6 |  |  | $ | 84.4 |  |  | $ | 171.2 |  |  | $ | 30.0 |  |  | $ | 35.0 |  |  | $ | 40.0 |  |  | $ | — |  |

[0001327567-22-000016:notes:103]
Other Purchase Commitments

[0001327567-22-000016:notes:104]
We have entered into various non-cancelable agreements with certain service providers, under which we are committed to minimum or fixed purchases. The following table presents details of the aggregate future non-cancelable purchase commitments under these agreements as of April 30, 2022 (in millions):

[0001327567-22-000016:notes:105]
|  |  |  | Fiscal years ending July 31, |
|  | Total |  | Remaining 2022 |  | 2023 |  | 2024 |  | 2025 |  | 2026 |  | 2027 and thereafter |
| Other purchase commitments | $ | 1,962.9 |  |  | $ | 18.6 |  |  | $ | 146.2 |  |  | $ | 366.5 |  |  | $ | 415.3 |  |  | $ | 531.6 |  |  | $ | 484.7 |  |

[0001327567-22-000016:notes:106]
Additionally, we have a $162.8 million minimum purchase commitment with a service provider through September 2027 with no specified annual commitments.

[0001327567-22-000016:notes:107]
Litigation

[0001327567-22-000016:notes:108]
We are subject to legal proceedings, claims, and litigation arising in the ordinary course of business, including intellectual property litigation. Such matters are subject to many uncertainties and outcomes are not predictable with assurance. We accrue for contingencies when we believe that a loss is probable and that we can reasonably estimate the amount of any such loss.

[0001327567-22-000016:notes:109]
To the extent there is a reasonable possibility that a loss exceeding amounts already recognized may be incurred and the amount of such additional loss would be material, we will either disclose the estimated additional loss or state that such an estimate cannot be made. As of April 30, 2022, we have not recorded any significant accruals for loss contingencies associated with such legal proceedings, determined that an unfavorable outcome is probable or reasonably possible, or determined that the amount or range of any possible loss is reasonably estimable.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001327567-22-000016:notes:110]
[same as prior period, unchanged from 0001327567-22-000008:notes:110]

[0001327567-22-000016:notes:111]
In February 2019, our board of directors authorized a $1.0 billion share repurchase program, which is funded from available working capital. In December 2020 and August 2021, our board of directors authorized additional $700.0 million and $676.1 million increases, respectively, bringing the total authorization under this share repurchase program to $2.4 billion. The expiration date of this repurchase authorization was extended to December 31, 2022, and our repurchase program may be suspended or discontinued at any time. Repurchases under our program are to be made at management’s discretion from time to time on the open market, through privately negotiated transactions, transactions structured through investment banking institutions, block purchase techniques, 10b5-1 trading plans, or a combination of the foregoing.

[0001327567-22-000016:notes:112]
[same as prior period, unchanged from 0001327567-22-000008:notes:112]

[0001327567-22-000016:notes:113]
|  | Three Months Ended April 30, |  | Nine Months Ended April 30, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Number of shares repurchased | — |  |  | 1.0 |  |  | 1.0 |  |  | 3.1 |  |
| Weighted average price per share (1) | $ | — |  |  | $ | 321.97 |  |  | $ | 533.80 |  |  | $ | 269.89 |  |
| Aggregate purchase price (1) | $ | — |  |  | $ | 350.0 |  |  | $ | 550.0 |  |  | $ | 850.0 |  |

[0001327567-22-000016:notes:114]
[same as prior period, unchanged from 0001327567-22-000008:notes:114]

[0001327567-22-000016:notes:115]
As of April 30, 2022, $450.0 million remained available for future share repurchases under our current repurchase authorization.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001327567-22-000016:notes:116]
[same as prior period, unchanged from 0001327567-22-000008:notes:116]

[0001327567-22-000016:notes:117]
Our 2021 Equity Incentive Plan (our “2021 Plan”) became effective in December 2021 and replaced the 2012 Equity Incentive Plan (our “2012 Plan”). Our 2021 Plan provides for the granting of stock options, stock appreciation rights, restricted stock awards (“RSA”), restricted stock units (“RSU”), performance share awards (“PSAs”), performance stock units (“PSUs”) and performance stock options (“PSOs”) to our employees, directors, and consultants. Our 2012 Plan continues to govern the terms of outstanding equity awards that were granted thereunder prior to the adoption of the 2021 Plan.

[0001327567-22-000016:notes:118]
[same as prior period, unchanged from 0001327567-22-000008:notes:118]

[0001327567-22-000016:notes:119]
[same as prior period, unchanged from 0001327567-22-000008:notes:119]

[0001327567-22-000016:notes:120]
We have also granted PSOs with both a market condition and a service condition to certain executives. The market condition for PSOs granted in fiscal 2018 and fiscal 2019 requires the price of our common stock to equal or exceed $297.75, $397.00, $496.25, and $595.50 based on the average closing price for 30 consecutive trading days during the four-, five-, six-, and seven-and-a-half-year periods following the date of grant in fiscal 2018 and 2019, respectively. To the extent that the market condition has been met, one-fourth of the PSOs will vest on each anniversary date of the grant date for such PSOs, subject to continued service. All outstanding PSOs may be exercised prior to vesting (“early exercise”). Shares of common stock issued upon early exercise of the PSOs will be restricted and, at our option, subject to repurchase if the option holder ceases to be a service provider. The maximum contractual term of our PSOs is seven and a half years from the date of grant, depending on vesting period. As of April 30, 2022, all stock price targets for our outstanding PSOs have been satisfied.

[0001327567-22-000016:notes:121]
A total of 4.7 million shares of our common stock are reserved for issuance pursuant to our 2021 Plan as of April 30, 2022.

[0001327567-22-000016:notes:122]
[same as prior period, unchanged from 0001327567-22-000008:notes:122]

[0001327567-22-000016:notes:123]
[same as prior period, unchanged from 0001327567-22-000008:notes:123]

[0001327567-22-000016:notes:124]
|  |  |  | PSOs Outstanding |
|  |  |  |  |  |  |  |  |  | Number of Shares |  | Weighted-Average Exercise Price Per Share |  | Weighted-Average Remaining Contractual Term(Years) |  | Aggregate Intrinsic Value |
| Balance—July 31, 2021 |  |  |  |  |  |  |  |  | 2.8 |  |  | $ | 194.14 |  |  | 4.2 |  | $ | 566.8 |  |
| Forfeited |  |  |  |  |  |  |  |  | (0.1) |  |  | $ | 184.24 |  |  |  |  |  |
| Balance—April 30, 2022 |  |  |  |  |  |  |  |  | 2.7 |  |  | $ | 194.55 |  |  | 3.4 |  | $ | 974.6 |  |
| Exercisable—April 30, 2022 |  |  |  |  |  |  |  |  | 2.7 |  |  | $ | 194.55 |  |  | 3.4 |  | $ | 974.6 |  |

[0001327567-22-000016:notes:125]
[same as prior period, unchanged from 0001327567-22-000008:notes:125]

[0001327567-22-000016:notes:126]
[same as prior period, unchanged from 0001327567-22-000008:notes:126]

[0001327567-22-000016:notes:127]
|  | RSUs Outstanding |  | PSUs Outstanding |
|  | Number of Shares |  | Weighted-Average Grant-Date Fair Value Per Share |  |  |  | Aggregate Intrinsic Value |  | Number of Shares |  | Weighted-Average Grant-Date Fair Value Per Share |  |  |  | Aggregate Intrinsic Value |
| Balance—July 31, 2021 | 6.9 |  |  | $ | 257.56 |  |  |  |  | $ | 2,760.2 |  |  | 1.3 |  |  | $ | 292.93 |  |  |  |  | $ | 498.4 |  |
| Granted(1) | 1.7 |  |  | $ | 495.98 |  |  |  |  |  |  | 0.3 |  |  | $ | 333.56 |  |  |  |  |  |
| Vested | (2.3) |  |  | $ | 251.42 |  |  |  |  |  |  | (0.4) |  |  | $ | 249.70 |  |  |  |  |  |
| Forfeited | (0.7) |  |  | $ | 280.58 |  |  |  |  |  |  | (0.1) |  |  | $ | 331.76 |  |  |  |  |  |
| Balance—April 30, 2022 | 5.6 |  |  | $ | 328.61 |  |  |  |  | $ | 3,131.9 |  |  | 1.1 |  |  | $ | 313.09 |  |  |  |  | $ | 632.9 |  |

[0001327567-22-000016:notes:128]
[same as prior period, unchanged from 0001327567-22-000008:notes:128]

[0001327567-22-000016:notes:129]
During the nine months ended April 30, 2022, we granted 0.1 million shares of PSUs, which contain service, performance and market conditions. The performance condition is based on revenue growth, whereas the market condition measures our total shareholder return (“TSR”) relative to the TSR of the companies listed in the Standard & Poor’s 500 index. In addition to this grant, we have also approved the future grant of 0.1 million shares of PSUs with similar terms, which will be considered granted at the time their related vesting conditions are established in the next two years. The fair value of the PSUs subject to the market condition is estimated on the grant date using a Monte Carlo simulation model. The following table summarizes the assumptions used and the grant-date fair value of our PSUs granted:

[0001327567-22-000016:notes:130]
|  | Three Months Ended April 30, 2022 |  | Nine Months Ended April 30, 2022 |
| Volatility | 39.1% - 41.1% |  | 36.0% - 41.1% |
| Expected term (in years) | 1.4 - 2.4 |  | 1.4 - 3.0 |
| Dividend yield | 0.0 | % |  | 0.0 | % |
| Risk-free interest rate | 1.5% - 2.0% |  | 0.2% - 2.0% |
| Grant-date fair value per share | $770.84 - $782.13 |  | $411.49 - $782.13 |

[0001327567-22-000016:notes:131]
[same as prior period, unchanged from 0001327567-22-000008:notes:131]

[0001327567-22-000016:notes:132]
[same as prior period, unchanged from 0001327567-22-000008:notes:132]

[0001327567-22-000016:notes:133]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 30, |  | April 30, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Cost of product revenue | $ | 2.3 |  |  | $ | 1.6 |  |  | $ | 6.9 |  |  | $ | 4.7 |  |
| Cost of subscription and support revenue | 27.4 |  |  | 23.3 |  |  | 81.8 |  |  | 69.3 |  |
| Research and development | 112.7 |  |  | 118.2 |  |  | 361.9 |  |  | 317.2 |  |
| Sales and marketing | 75.7 |  |  | 69.2 |  |  | 228.8 |  |  | 203.8 |  |
| General and administrative | 29.2 |  |  | 30.6 |  |  | 93.3 |  |  | 101.9 |  |
| Total share-based compensation | $ | 247.3 |  |  | $ | 242.9 |  |  | $ | 772.7 |  |  | $ | 696.9 |  |

[0001327567-22-000016:notes:134]
As of April 30, 2022, total compensation cost related to unvested share-based awards not yet recognized was $2.0 billion. This cost is expected to be amortized over a weighted-average period of approximately 2.6 years.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001327567-22-000016:notes:135]
Income TaxesFor the three and nine months ended April 30, 2022, our provision for income taxes reflected an effective tax rate of negative 39.4% and negative 20.4%, respectively. For the three and nine months ended April 30, 2021, our provision for income taxes reflected an effective tax rate of 3.5% and negative 4.7%, respectively. Our taxes are primarily due to foreign income tax and withholding tax. Our effective tax rates differed from the U.S. statutory tax rate primarily due to changes in our valuation allowance.


## us-gaap:EarningsPerShareTextBlock

[0001327567-22-000016:notes:136]
[same as prior period, unchanged from 0001327567-22-000008:notes:136]

[0001327567-22-000016:notes:137]
[same as prior period, unchanged from 0001327567-22-000008:notes:137]

[0001327567-22-000016:notes:138]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 30, |  | April 30, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Net loss | $ | (73.2) |  |  | $ | (145.1) |  |  | $ | (270.3) |  |  | $ | (379.6) |  |
| Weighted-average shares used to compute net loss per share, basic and diluted | 98.9 |  |  | 96.9 |  |  | 98.2 |  |  | 96.1 |  |
| Net loss per share, basic and diluted | $ | (0.74) |  |  | $ | (1.50) |  |  | $ | (2.75) |  |  | $ | (3.95) |  |

[0001327567-22-000016:notes:139]
[same as prior period, unchanged from 0001327567-22-000008:notes:139]

[0001327567-22-000016:notes:140]
|  | Three and Nine Months Ended |
|  | April 30, |
|  | 2022 |  | 2021 |
| Convertible senior notes | 13.1 |  |  | 13.1 |  |
| Warrants related to the issuance of convertible senior notes | 13.1 |  |  | 13.1 |  |
| RSUs and PSUs | 6.7 |  |  | 8.3 |  |
| Options to purchase common stock, including PSOs | 2.7 |  |  | 2.8 |  |
| Restricted stock awards and performance-based stock awards | 0.2 |  |  | 0.4 |  |
| ESPP shares | 0.1 |  |  | 0.1 |  |
| Total | 35.9 |  |  | 37.8 |  |
