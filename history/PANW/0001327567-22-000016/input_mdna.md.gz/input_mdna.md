# PANW MD&A — 0001327567-22-000016


## mdna

[0001327567-22-000016:mdna:1]
[same as prior period, unchanged from 0001327567-22-000008:mdna:1]

[0001327567-22-000016:mdna:2]
[same as prior period, unchanged from 0001327567-22-000008:mdna:2]

[0001327567-22-000016:mdna:3]
[same as prior period, unchanged from 0001327567-22-000008:mdna:3]

[0001327567-22-000016:mdna:4]
[same as prior period, unchanged from 0001327567-22-000008:mdna:4]

[0001327567-22-000016:mdna:5]
•Results of Operations. A discussion of the nature and trends in our financial results and an analysis of our financial results comparing the three and nine months ended April 30, 2022 to the three and nine months ended April 30, 2021.

[0001327567-22-000016:mdna:6]
[same as prior period, unchanged from 0001327567-22-000008:mdna:6]

[0001327567-22-000016:mdna:7]
[same as prior period, unchanged from 0001327567-22-000008:mdna:7]

[0001327567-22-000016:mdna:8]
[same as prior period, unchanged from 0001327567-22-000008:mdna:8]

[0001327567-22-000016:mdna:9]
[same as prior period, unchanged from 0001327567-22-000008:mdna:9]

[0001327567-22-000016:mdna:10]
[same as prior period, unchanged from 0001327567-22-000008:mdna:10]

[0001327567-22-000016:mdna:11]
[same as prior period, unchanged from 0001327567-22-000008:mdna:11]

[0001327567-22-000016:mdna:12]
•Enabling network security through our ML-Powered Next-Generation Firewalls, available in a number of form factors, including physical, virtual, and containerized appliances, Cloud NGFW for Amazon Web Services, as well as a cloud-

[0001327567-22-000016:mdna:13]
[same as prior period, unchanged from 0001327567-22-000008:mdna:28]

[0001327567-22-000016:mdna:14]
[same as prior period, unchanged from 0001327567-22-000008:mdna:14]

[0001327567-22-000016:mdna:15]
delivered service. Network security also includes our add-on Cloud-Delivered Security Services, such as Advanced Threat Prevention, Threat Prevention, WildFire, Advanced URL Filtering, DNS Security, IoT Security, GlobalProtect, SD-WAN, Enterprise Data Loss Prevention (“Enterprise DLP”), SaaS Security API, SaaS Security Inline, and AIOps for NGFW. These services secure content, applications, users, and devices across our ML-Powered Next-Generation Firewalls, Prisma, and Cortex product lines, to enable best-in-class security across a broad range of applications. Panorama, our network security management solution, available as hardware or virtual machine, can centrally manage all of our firewalls irrespective of their form factor, location, or scale.

[0001327567-22-000016:mdna:16]
[same as prior period, unchanged from 0001327567-22-000008:mdna:16]

[0001327567-22-000016:mdna:17]
•Prisma Access, the industry’s most complete cloud-delivered security platform, together with Prisma SD-WAN, provide a comprehensive Secure Access Service Edge (“SASE”) offering that is used to secure remote workforces and enable the cloud-delivered branch. Prisma Access’ integration with the recently announced Okyo Garde Enterprise Edition extends SASE to protect the home networks of work-from-home employees.

[0001327567-22-000016:mdna:18]
[same as prior period, unchanged from 0001327567-22-000008:mdna:18]

[0001327567-22-000016:mdna:19]
•Enabling cloud security through our Prisma security offerings. Prisma Cloud, the industry’s most comprehensive Cloud Native Application Protection Platform (“CNAPP”), secures multi- and hybrid-cloud environments and cloud native applications from code to cloud, integrating security across the full deployment lifecycle. For customers deploying virtual firewalls in cloud environments, VM-Series and CN-Series enforce in-line network security in multi- and hybrid-cloud environments.

[0001327567-22-000016:mdna:20]
[same as prior period, unchanged from 0001327567-22-000008:mdna:20]

[0001327567-22-000016:mdna:21]
•Delivering the next generation of endpoint security, vulnerability management, security analytics and automation solutions through our Cortex portfolio. These include our industry-leading Cortex XDR to prevent, detect, and respond to complex cybersecurity attacks, Cortex XSOAR for security orchestration, automation, and response (“SOAR”), Cortex Xpanse for attack surface management (“ASM”) and Cortex Data Lake allowing our customers to collect and analyze large amounts of context-rich data across endpoints, networks, and clouds. We have also recently announced the limited availability of Cortex XSIAM, our broader security intelligence and automation platform to deliver on the vision of autonomous security operations. These products are delivered as software or SaaS subscriptions.

[0001327567-22-000016:mdna:22]
[same as prior period, unchanged from 0001327567-22-000008:mdna:22]

[0001327567-22-000016:mdna:23]
[same as prior period, unchanged from 0001327567-22-000008:mdna:23]

[0001327567-22-000016:mdna:24]
For the third quarter of fiscal 2022 and 2021, total revenue was $1.4 billion and $1.1 billion, respectively, representing year-over-year growth of 29.1%. Our growth reflects the increased adoption of our portfolio, which consists of product, subscriptions, and support. We believe our portfolio will enable us to benefit from recurring revenues as we continue to grow our installed end-customer base. As of April 30, 2022, we had end-customers in over 170 countries. Our end-customers represent a broad range of industries, including education, energy, financial services, government entities, healthcare, Internet and media, manufacturing, public sector, and telecommunications, and include almost all of the Fortune 100 companies and a majority of the Global 2000 companies in the world. We maintain a field sales force that works closely with our channel partners in developing sales opportunities. We primarily use a two-tiered, indirect fulfillment model whereby we sell our products, subscriptions, and support to our distributors, which, in turn, sell to our resellers, which then sell to our end-customers.

[0001327567-22-000016:mdna:25]
Our product revenue grew to $351.5 million, or 25.3% of total revenue, for the third quarter of fiscal 2022, representing year-over-year growth of 21.7%. Product revenue is generated from sales of our appliances, primarily our ML-Powered Next-Generation Firewall, which is available in a number of form factors, including as physical, virtual, and containerized appliances. Our ML-Powered Next-Generation Firewall incorporates our PAN-OS operating system, which provides a consistent set of capabilities across our entire network security product line. Our products are designed for different performance requirements throughout an organization, ranging from our PA-410, which is designed for small organizations and remote or branch offices, to our top-of-the-line PA-7080, which is designed for large-scale data centers and service provider use. The same firewall functionality that is delivered in our physical appliances is also available in our VM-Series virtual firewalls, which secure virtualized and cloud-based computing environments, and in our CN-Series container firewalls, which secure container environments and traffic.

[0001327567-22-000016:mdna:26]
Our subscription and support revenue grew to $1.0 billion, or 74.7% of total revenue, for the third quarter of fiscal 2022, representing year-over-year growth of 31.9%. Our subscriptions provide our end-customers with near real-time access to the latest antivirus, intrusion prevention, web filtering, modern malware prevention, data loss prevention, and cloud access security broker capabilities across the network, endpoints, and the cloud. When end-customers purchase our physical, virtual, or container firewall appliances, or certain cloud offerings they typically purchase support in order to receive ongoing security updates, upgrades, bug fixes, and repairs. In addition to the subscriptions purchased with these appliances, end-customers may also purchase other subscriptions on

[0001327567-22-000016:mdna:27]
[same as prior period, unchanged from 0001327567-22-000008:mdna:35]

[0001327567-22-000016:mdna:28]
[same as prior period, unchanged from 0001327567-22-000008:mdna:29]

[0001327567-22-000016:mdna:29]
a per-user, per-endpoint, or capacity-based basis. We also offer professional services, including incident response, risk management, and digital forensic services.

[0001327567-22-000016:mdna:30]
We continue to invest in innovation and acquire businesses as we evolve and further extend the capabilities of our portfolio, as we believe that innovation and timely development of new features and products are essential to meeting the needs of our end-customers and improving our competitive position. For example, in February 2022, we introduced PAN-OS 10.2 Nebula, the latest upgrade of our industry leading PAN-OS software that collects, analyzes, and interprets potential zero-day threats using deep learning in real time, resulting in faster detection and prevention of more evasive threats.

[0001327567-22-000016:mdna:31]
[same as prior period, unchanged from 0001327567-22-000008:mdna:31]

[0001327567-22-000016:mdna:32]
[same as prior period, unchanged from 0001327567-22-000008:mdna:32]

[0001327567-22-000016:mdna:33]
We are actively monitoring, evaluating, and responding to developments relating to COVID-19, which has resulted in, and is expected to continue to result in significant global, social, and business disruption. While we instituted a global work-from-home policy beginning in March 2020, which has been modified to provide employees with the choice to work in our offices for a set number of days per week or completely remotely, we have not experienced significant disruptions in our work operations. We are conducting business as usual with modifications to employee travel and hold some marketing events virtually. We expect these changes will substantially remain in effect in the fourth quarter of fiscal 2022 and could extend to future quarters. We will continue to actively monitor the situation, including progress made through vaccinations, and we will make further changes to our business operations as may be required by federal, state, or local authorities or that we determine are in the best interests of our employees, end-customers, partners, suppliers, and stockholders. Our focus remains on the safety of our employees, and we strive to protect the health and well-being of the communities in which we operate, in part, by providing technology to our employees, end-customers, and partners to help them do their best work while working remotely.

[0001327567-22-000016:mdna:34]
[same as prior period, unchanged from 0001327567-22-000008:mdna:34]

[0001327567-22-000016:mdna:35]
[same as prior period, unchanged from 0001327567-22-000008:mdna:45]

[0001327567-22-000016:mdna:36]
[same as prior period, unchanged from 0001327567-22-000008:mdna:36]

[0001327567-22-000016:mdna:37]
[same as prior period, unchanged from 0001327567-22-000008:mdna:37]

[0001327567-22-000016:mdna:38]
[same as prior period, unchanged from 0001327567-22-000008:mdna:38]

[0001327567-22-000016:mdna:39]
|  | April 30, 2022 |  | July 31, 2021 |
|  | (in millions) |
| Total deferred revenue | $ | 5,859.4 |  |  | $ | 5,024.0 |  |
| Cash, cash equivalents, and investments | $ | 4,589.3 |  |  | $ | 3,789.4 |  |

[0001327567-22-000016:mdna:40]
|  | Three Months Ended April 30, |  | Nine Months Ended April 30, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
|  | (dollars in millions) |
| Total revenue | $ | 1,386.7 |  |  | $ | 1,073.9 |  |  | $ | 3,951.0 |  |  | $ | 3,036.8 |  |
| Total revenue year-over-year percentage increase | 29.1 | % |  | 23.5 | % |  | 30.1 | % |  | 23.5 | % |
| Gross margin | 68.2 | % |  | 69.2 | % |  | 69.0 | % |  | 69.8 | % |
| Operating loss | $ | (47.6) |  |  | $ | (110.4) |  |  | $ | (204.2) |  |  | $ | (243.7) |  |
| Operating margin | (3.4) | % |  | (10.3) | % |  | (5.2) | % |  | (8.0) | % |
| Billings | $ | 1,796.9 |  |  | $ | 1,286.4 |  |  | $ | 4,786.4 |  |  | $ | 3,583.9 |  |
| Billings year-over-year percentage increase | 39.7 | % |  | 26.7 | % |  | 33.6 | % |  | 23.1 | % |
| Cash flow provided by operating activities |  |  |  |  | $ | 1,461.0 |  |  | $ | 1,177.2 |  |
| Free cash flow (non-GAAP) |  |  |  |  | $ | 1,307.4 |  |  | $ | 1,088.6 |  |

[0001327567-22-000016:mdna:41]
[same as prior period, unchanged from 0001327567-22-000008:mdna:41]

[0001327567-22-000016:mdna:42]
[same as prior period, unchanged from 0001327567-22-000008:mdna:42]

[0001327567-22-000016:mdna:43]
|  | Three Months Ended April 30, |  | Nine Months Ended April 30, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
|  | (in millions) |  | (in millions) |
| Billings: |  |  |  |  |  |  |  |
| Total revenue | $ | 1,386.7 |  |  | $ | 1,073.9 |  |  | $ | 3,951.0 |  |  | $ | 3,036.8 |  |
| Add: change in total deferred revenue, net of acquired deferred revenue | 410.2 |  |  | 212.5 |  |  | 835.4 |  |  | 547.1 |  |
| Billings | $ | 1,796.9 |  |  | $ | 1,286.4 |  |  | $ | 4,786.4 |  |  | $ | 3,583.9 |  |

[0001327567-22-000016:mdna:44]
[same as prior period, unchanged from 0001327567-22-000008:mdna:44]

[0001327567-22-000016:mdna:45]
[same as prior period, unchanged from 0001327567-22-000008:mdna:49]

[0001327567-22-000016:mdna:46]
[same as prior period, unchanged from 0001327567-22-000008:mdna:46]

[0001327567-22-000016:mdna:47]
[same as prior period, unchanged from 0001327567-22-000008:mdna:47]

[0001327567-22-000016:mdna:48]
|  | Nine Months Ended April 30, |
|  | 2022 |  | 2021 |
|  | (in millions) |
| Free cash flow (non-GAAP): |  |  |  |
| Net cash provided by operating activities | $ | 1,461.0 |  |  | $ | 1,177.2 |  |
| Less: purchases of property, equipment, and other assets | 153.6 |  |  | 88.6 |  |
| Free cash flow (non-GAAP) | $ | 1,307.4 |  |  | $ | 1,088.6 |  |
| Net cash used in investing activities | $ | (461.3) |  |  | $ | (1,478.2) |  |
| Net cash used in financing activities | $ | (453.5) |  |  | $ | (768.4) |  |

[0001327567-22-000016:mdna:49]
[same as prior period, unchanged from 0001327567-22-000008:mdna:59]

[0001327567-22-000016:mdna:50]
[same as prior period, unchanged from 0001327567-22-000008:mdna:50]

[0001327567-22-000016:mdna:51]
[same as prior period, unchanged from 0001327567-22-000008:mdna:51]

[0001327567-22-000016:mdna:52]
[same as prior period, unchanged from 0001327567-22-000008:mdna:52]

[0001327567-22-000016:mdna:53]
|  | Three Months Ended April 30, |  | Nine Months Ended April 30, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
|  | Amount |  | % of Revenue |  | Amount |  | % of Revenue |  | Amount |  | % of Revenue |  | Amount |  | % of Revenue |
|  | (dollars in millions) |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 351.5 |  |  | 25.3 | % |  | $ | 288.9 |  |  | 26.9 | % |  | $ | 955.0 |  | 24.2 | % |  | $ | 780.9 |  |  | 25.7 | % |
| Subscription and support | 1,035.2 |  |  | 74.7 | % |  | 785.0 |  |  | 73.1 | % |  | 2,996.0 |  | 75.8 | % |  | 2,255.9 |  |  | 74.3 | % |
| Total revenue | 1,386.7 |  |  | 100.0 | % |  | 1,073.9 |  |  | 100.0 | % |  | 3,951.0 |  | 100.0 | % |  | 3,036.8 |  |  | 100.0 | % |
| Cost of revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product | 126.0 |  |  | 9.1 | % |  | 81.9 |  |  | 7.6 | % |  | 312.7 |  | 7.9 | % |  | 219.7 |  |  | 7.2 | % |
| Subscription and support | 314.5 |  |  | 22.7 | % |  | 248.7 |  |  | 23.2 | % |  | 913.7 |  | 23.1 | % |  | 696.3 |  |  | 23.0 | % |
| Total cost of revenue(1) | 440.5 |  |  | 31.8 | % |  | 330.6 |  |  | 30.8 | % |  | 1,226.4 |  | 31.0 | % |  | 916.0 |  |  | 30.2 | % |
| Total gross profit | 946.2 |  |  | 68.2 | % |  | 743.3 |  |  | 69.2 | % |  | 2,724.6 |  | 69.0 | % |  | 2,120.8 |  |  | 69.8 | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | 355.4 |  |  | 25.6 | % |  | 311.0 |  |  | 29.0 | % |  | 1,053.9 |  | 26.7 | % |  | 815.1 |  |  | 26.8 | % |
| Sales and marketing | 543.6 |  |  | 39.2 | % |  | 448.0 |  |  | 41.7 | % |  | 1,578.3 |  | 40.0 | % |  | 1,264.0 |  |  | 41.6 | % |
| General and administrative | 94.8 |  |  | 6.8 | % |  | 94.7 |  |  | 8.8 | % |  | 296.6 |  | 7.5 | % |  | 285.4 |  |  | 9.4 | % |
| Total operating expenses(1) | 993.8 |  |  | 71.6 | % |  | 853.7 |  |  | 79.5 | % |  | 2,928.8 |  | 74.2 | % |  | 2,364.5 |  |  | 77.8 | % |
| Operating loss | (47.6) |  |  | (3.4) | % |  | (110.4) |  |  | (10.3) | % |  | (204.2) |  |  | (5.2) | % |  | (243.7) |  |  | (8.0) | % |
| Interest expense | (6.8) |  |  | (0.5) | % |  | (41.0) |  |  | (3.8) | % |  | (20.5) |  |  | (0.5) | % |  | (121.9) |  |  | (4.0) | % |
| Other income, net | 1.9 |  |  | 0.1 | % |  | 1.0 |  |  | 0.1 | % |  | 0.2 |  |  | — | % |  | 2.9 |  |  | 0.1 | % |
| Loss before income taxes | (52.5) |  |  | (3.8) | % |  | (150.4) |  |  | (14.0) | % |  | (224.5) |  |  | (5.7) | % |  | (362.7) |  |  | (11.9) | % |
| Provision for (benefit from) income taxes | 20.7 |  |  | 1.5 | % |  | (5.3) |  |  | (0.5) | % |  | 45.8 |  |  | 1.1 | % |  | 16.9 |  |  | 0.6 | % |
| Net loss | $ | (73.2) |  |  | (5.3) | % |  | $ | (145.1) |  |  | (13.5) | % |  | $ | (270.3) |  |  | (6.8) | % |  | $ | (379.6) |  |  | (12.5) | % |

[0001327567-22-000016:mdna:54]
[same as prior period, unchanged from 0001327567-22-000008:mdna:54]

[0001327567-22-000016:mdna:55]
[same as prior period, unchanged from 0001327567-22-000008:mdna:55]

[0001327567-22-000016:mdna:56]
|  | Three Months Ended April 30, |  | Nine Months Ended April 30, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
|  | (in millions) |
| Cost of product revenue | $ | 2.3 |  |  | $ | 1.6 |  |  | $ | 6.9 |  |  | $ | 4.7 |  |
| Cost of subscription and support revenue | 27.4 |  |  | 23.3 |  |  | 81.8 |  |  | 69.3 |  |
| Research and development | 112.7 |  |  | 118.2 |  |  | 361.9 |  |  | 317.2 |  |
| Sales and marketing | 75.7 |  |  | 69.2 |  |  | 228.8 |  |  | 203.8 |  |
| General and administrative | 29.2 |  |  | 30.6 |  |  | 93.3 |  |  | 101.9 |  |
| Total share-based compensation | $ | 247.3 |  |  | $ | 242.9 |  |  | $ | 772.7 |  |  | $ | 696.9 |  |

[0001327567-22-000016:mdna:57]
[same as prior period, unchanged from 0001327567-22-000008:mdna:57]

[0001327567-22-000016:mdna:58]
[same as prior period, unchanged from 0001327567-22-000008:mdna:58]

[0001327567-22-000016:mdna:59]
[same as prior period, unchanged from 0001327567-22-000008:mdna:74]

[0001327567-22-000016:mdna:60]
[same as prior period, unchanged from 0001327567-22-000008:mdna:60]

[0001327567-22-000016:mdna:61]
[same as prior period, unchanged from 0001327567-22-000008:mdna:61]

[0001327567-22-000016:mdna:62]
[same as prior period, unchanged from 0001327567-22-000008:mdna:62]

[0001327567-22-000016:mdna:63]
|  | Three Months Ended April 30, |  |  |  |  |  | Nine Months Ended April 30, |  |  |  |  |
|  | 2022 |  | 2021 |  | Change |  | 2022 |  | 2021 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Product | $ | 351.5 |  |  | $ | 288.9 |  |  | $ | 62.6 |  |  | 21.7 | % |  | $ | 955.0 |  |  | $ | 780.9 |  |  | $ | 174.1 |  |  | 22.3 | % |

[0001327567-22-000016:mdna:64]
Product revenue for the three and nine months ended April 30, 2022 increased compared to the same periods in 2021 primarily due to increased demand for our new and existing product offerings in both periods.

[0001327567-22-000016:mdna:65]
[same as prior period, unchanged from 0001327567-22-000008:mdna:65]

[0001327567-22-000016:mdna:66]
[same as prior period, unchanged from 0001327567-22-000008:mdna:66]

[0001327567-22-000016:mdna:67]
|  | Three Months Ended April 30, |  |  |  |  |  | Nine Months Ended April 30, |  |  |  |  |
|  | 2022 |  | 2021 |  | Change |  | 2022 |  | 2021 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Subscription | $ | 639.8 |  |  | $ | 473.8 |  |  | $ | 166.0 |  |  | 35.0 | % |  | $ | 1,836.6 |  |  | $ | 1,363.5 |  |  | $ | 473.1 |  |  | 34.7 | % |
| Support | 395.4 |  |  | 311.2 |  |  | 84.2 |  |  | 27.1 | % |  | 1,159.4 |  |  | 892.4 |  |  | 267.0 |  |  | 29.9 | % |
| Total subscription and support | $ | 1,035.2 |  |  | $ | 785.0 |  |  | $ | 250.2 |  |  | 31.9 | % |  | $ | 2,996.0 |  |  | $ | 2,255.9 |  |  | $ | 740.1 |  |  | 32.8 | % |

[0001327567-22-000016:mdna:68]
Subscription and support revenue increased for the three and nine months ended April 30, 2022 compared to the same periods in 2021. The increase in both periods was due to increased demand for our subscription and support offerings from our end-customers. The mix between subscription revenue and support revenue will fluctuate over time, depending on the introduction of new subscription offerings, renewals of support services, and our ability to increase sales to new and existing end-customers.

[0001327567-22-000016:mdna:69]
[same as prior period, unchanged from 0001327567-22-000008:mdna:69]

[0001327567-22-000016:mdna:70]
|  | Three Months Ended April 30, |  |  |  |  |  | Nine Months Ended April 30, |  |  |  |  |
|  | 2022 |  | 2021 |  | Change |  | 2022 |  | 2021 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Americas | $ | 948.7 |  |  | $ | 732.4 |  |  | $ | 216.3 |  |  | 29.5 | % |  | $ | 2,731.3 |  |  | $ | 2,088.7 |  |  | $ | 642.6 |  |  | 30.8 | % |
| EMEA | 269.5 |  |  | 211.0 |  |  | 58.5 |  |  | 27.7 | % |  | 755.5 |  |  | 590.6 |  |  | 164.9 |  |  | 27.9 | % |
| APAC | 168.5 |  |  | 130.5 |  |  | 38.0 |  |  | 29.1 | % |  | 464.2 |  |  | 357.5 |  |  | 106.7 |  |  | 29.8 | % |
| Total revenue | $ | 1,386.7 |  |  | $ | 1,073.9 |  |  | $ | 312.8 |  |  | 29.1 | % |  | $ | 3,951.0 |  |  | $ | 3,036.8 |  |  | $ | 914.2 |  |  | 30.1 | % |

[0001327567-22-000016:mdna:71]
With respect to geographic theaters, the increase in revenue for the three and nine months ended April 30, 2022 compared to the same periods in 2021 was driven primarily by the Americas, due to its larger sales force and a larger percentage of our customers located in the Americas. Revenue from our other geographic theaters, both Europe, the Middle East, and Africa (“EMEA”) and Asia Pacific and Japan (“APAC”), increased for the three and nine months ended April 30, 2022 compared to the same periods in 2021 due to continued investment in our global sales force to support our growth and increase our customer base in the regions.

[0001327567-22-000016:mdna:72]
[same as prior period, unchanged from 0001327567-22-000008:mdna:72]

[0001327567-22-000016:mdna:73]
[same as prior period, unchanged from 0001327567-22-000008:mdna:73]

[0001327567-22-000016:mdna:74]
[same as prior period, unchanged from 0001327567-22-000008:mdna:87]

[0001327567-22-000016:mdna:75]
[same as prior period, unchanged from 0001327567-22-000008:mdna:75]

[0001327567-22-000016:mdna:76]
[same as prior period, unchanged from 0001327567-22-000008:mdna:76]

[0001327567-22-000016:mdna:77]
Cost of product revenue primarily includes costs paid to our manufacturing partners for procuring components and manufacturing our products. Our cost of product revenue also includes personnel costs, which consist of salaries, benefits, bonuses, share-based compensation, and travel and entertainment associated with our operations organization, amortization of intellectual property licenses, product testing costs, shipping and tariff costs, and shared costs. Shared costs consist of certain facilities, depreciation, benefits, recruiting, and information technology costs that we allocate based on headcount. We expect our cost of product revenue to fluctuate with our product revenue.

[0001327567-22-000016:mdna:78]
|  | Three Months Ended April 30, |  |  |  |  |  | Nine Months Ended April 30, |  |  |  |  |
|  | 2022 |  | 2021 |  | Change |  | 2022 |  | 2021 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Cost of product revenue | $ | 126.0 |  |  | $ | 81.9 |  |  | $ | 44.1 |  |  | 53.8 | % |  | $ | 312.7 |  |  | $ | 219.7 |  |  | $ | 93.0 |  |  | 42.3 | % |
| Number of employees at period end | 147 |  |  | 129 |  |  | 18 |  |  | 14.0 | % |  | 147 |  |  | 129 |  |  | 18 |  |  | 14.0 | % |

[0001327567-22-000016:mdna:79]
Cost of product revenue increased for the three and nine months ended April 30, 2022 compared to the same periods in 2021, primarily due to an increase in product volume in both periods. The remaining increase was due to higher costs related to our product offerings in both periods, primarily driven by supply chain challenges.

[0001327567-22-000016:mdna:80]
[same as prior period, unchanged from 0001327567-22-000008:mdna:80]

[0001327567-22-000016:mdna:81]
Cost of subscription and support revenue includes personnel costs, which consist of salaries, benefits, bonuses, share-based compensation, and travel and entertainment for our global customer support and technical operations organizations, customer support and repair costs, third-party professional services costs, data center and cloud hosting service costs, amortization of acquired intangible assets and capitalized software development costs, and shared costs. Shared costs consist of certain facilities, depreciation, benefits, recruiting, and information technology costs that we allocate based on headcount. We expect our cost of subscription and support revenue to increase as our installed end-customer base grows and adoption of our cloud-based subscription offerings increases.

[0001327567-22-000016:mdna:82]
|  | Three Months Ended April 30, |  |  |  |  |  | Nine Months Ended April 30, |  |  |  |  |
|  | 2022 |  | 2021 |  | Change |  | 2022 |  | 2021 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Cost of subscription and support revenue | $ | 314.5 |  |  | $ | 248.7 |  |  | $ | 65.8 |  |  | 26.5 | % |  | $ | 913.7 |  |  | $ | 696.3 |  |  | $ | 217.4 |  |  | 31.2 | % |
| Number of employees at period end | 2,400 |  |  | 1,871 |  |  | 529 |  |  | 28.3 | % |  | 2,400 |  |  | 1,871 |  |  | 529 |  |  | 28.3 | % |

[0001327567-22-000016:mdna:83]
Cost of subscription and support revenue increased for the three and nine months ended April 30, 2022 compared to the same periods in 2021, primarily due to personnel costs, which grew $34.6 million to $142.5 million for the three months ended April 30, 2022 compared to the same period in 2021, and grew $108.2 million to $403.9 million for the nine months ended April 30, 2022 compared to the same period in 2021 primarily due to headcount growth. The remaining increase for both periods was primarily due to increased outside service costs for global customer support resulting from the expansions of our customer base and product portfolio, cloud hosting service costs to support our cloud-based subscription offerings, and shared costs.

[0001327567-22-000016:mdna:84]
[same as prior period, unchanged from 0001327567-22-000008:mdna:84]

[0001327567-22-000016:mdna:85]
[same as prior period, unchanged from 0001327567-22-000008:mdna:85]

[0001327567-22-000016:mdna:86]
|  | Three Months Ended April 30, |  | Nine Months Ended April 30, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
|  | Amount |  | Gross Margin |  | Amount |  | Gross Margin |  | Amount |  | Gross Margin |  | Amount |  | Gross Margin |
|  | (dollars in millions) |
| Product | $ | 225.5 |  |  | 64.2 | % |  | $ | 207.0 |  |  | 71.7 | % |  | $ | 642.3 |  |  | 67.3 | % |  | $ | 561.2 |  |  | 71.9 | % |
| Subscription and support | 720.7 |  |  | 69.6 | % |  | 536.3 |  |  | 68.3 | % |  | 2,082.3 |  |  | 69.5 | % |  | 1,559.6 |  |  | 69.1 | % |
| Total gross profit | $ | 946.2 |  |  | 68.2 | % |  | $ | 743.3 |  |  | 69.2 | % |  | $ | 2,724.6 |  |  | 69.0 | % |  | $ | 2,120.8 |  |  | 69.8 | % |

[0001327567-22-000016:mdna:87]
[same as prior period, unchanged from 0001327567-22-000008:mdna:103]

[0001327567-22-000016:mdna:88]
[same as prior period, unchanged from 0001327567-22-000008:mdna:88]

[0001327567-22-000016:mdna:89]
Product gross margin decreased for the three and nine months ended April 30, 2022 compared to the same periods in 2021, primarily due to higher costs related to our product offerings in both periods, primarily driven by supply chain challenges.

[0001327567-22-000016:mdna:90]
Subscription and support gross margin increased for the three months ended April 30, 2022 compared to the same period in 2021, primarily due to our growth in subscription and support revenue, which outpaced the subscription and support costs. Subscription and support gross margin was relatively flat for the nine months ended April 30, 2022 compared to the same period in 2021.

[0001327567-22-000016:mdna:91]
[same as prior period, unchanged from 0001327567-22-000008:mdna:91]

[0001327567-22-000016:mdna:92]
[same as prior period, unchanged from 0001327567-22-000008:mdna:92]

[0001327567-22-000016:mdna:93]
[same as prior period, unchanged from 0001327567-22-000008:mdna:93]

[0001327567-22-000016:mdna:94]
Research and development expense consists primarily of personnel costs. Research and development expense also includes prototype-related expenses and shared costs. We expect research and development expense to increase in absolute dollars as we continue to invest in our future products and services, although our research and development expense may fluctuate as a percentage of total revenue.

[0001327567-22-000016:mdna:95]
|  | Three Months Ended April 30, |  |  |  |  |  | Nine Months Ended April 30, |  |  |  |  |
|  | 2022 |  | 2021 |  | Change |  | 2022 |  | 2021 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Research and development | $ | 355.4 |  |  | $ | 311.0 |  |  | $ | 44.4 |  |  | 14.3 | % |  | $ | 1,053.9 |  |  | $ | 815.1 |  |  | $ | 238.8 |  |  | 29.3 | % |
| Number of employees at period end | 3,047 |  |  | 2,425 |  |  | 622 |  |  | 25.6 | % |  | 3,047 |  |  | 2,425 |  |  | 622 |  |  | 25.6 | % |

[0001327567-22-000016:mdna:96]
Research and development expense increased for the three and nine months ended April 30, 2022 compared to the same periods in 2021 primarily due to personnel costs, which grew $25.9 million to $277.8 million for the three months ended April 30, 2022 compared to the same period in 2021, and grew $175.0 million to $830.9 million for the nine months ended April 30, 2022 compared to the same period in 2021. The increase in personnel costs in both periods was primarily due to headcount growth. The increase in research and development expense for both periods was further driven by increased shared costs and third-party product development costs.

[0001327567-22-000016:mdna:97]
[same as prior period, unchanged from 0001327567-22-000008:mdna:97]

[0001327567-22-000016:mdna:98]
Sales and marketing expense consists primarily of personnel costs, including commission expense. Sales and marketing expense also includes costs for market development programs, promotional and other marketing costs, professional services, and shared costs. We continue to strategically invest in headcount and have grown our sales presence. We expect sales and marketing expense to continue to increase in absolute dollars as we increase the size of our sales and marketing organizations to grow customer base, increase touch points with end-customers and expand our global presence, although our sales and marketing expense may fluctuate as a percentage of total revenue.

[0001327567-22-000016:mdna:99]
|  | Three Months Ended April 30, |  |  |  |  |  | Nine Months Ended April 30, |  |  |  |  |
|  | 2022 |  | 2021 |  | Change |  | 2022 |  | 2021 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Sales and marketing | $ | 543.6 |  |  | $ | 448.0 |  |  | $ | 95.6 |  |  | 21.3 | % |  | $ | 1,578.3 |  |  | $ | 1,264.0 |  |  | $ | 314.3 |  |  | 24.9 | % |
| Number of employees at period end | 4,908 |  |  | 4,237 |  | 671 |  |  | 15.8 | % |  | 4,908 |  |  | 4,237 |  |  | 671 |  |  | 15.8 | % |

[0001327567-22-000016:mdna:100]
Sales and marketing expense increased for the three and nine months ended April 30, 2022 compared to the same periods in 2021, primarily due to personnel costs, which grew $70.8 million to $412.9 million for the three months ended April 30, 2022 compared to the same period in 2021, and grew $238.3 million to $1,197.1 million for the nine months ended April 30, 2022 compared to the same period in 2021. The increase in personnel costs in both periods was primarily due to headcount growth and increased travel and entertainment expenses. The increase in both periods was also driven by an increase in costs associated with go-to-market initiatives, including advertising.

[0001327567-22-000016:mdna:101]
[same as prior period, unchanged from 0001327567-22-000008:mdna:116]

[0001327567-22-000016:mdna:102]
[same as prior period, unchanged from 0001327567-22-000008:mdna:104]

[0001327567-22-000016:mdna:103]
[same as prior period, unchanged from 0001327567-22-000008:mdna:101]

[0001327567-22-000016:mdna:104]
General and administrative expense consists primarily of personnel costs and shared costs for our executive, finance, human resources, and legal organizations, and professional services costs, which consist primarily of legal, auditing, accounting, and other consulting costs. General and administrative expense also includes certain non-recurring general expenses. We expect general and administrative expense to increase in absolute dollars due to additional costs associated with accounting, compliance, and insurance, although our general and administrative expense may fluctuate as a percentage of total revenue.

[0001327567-22-000016:mdna:105]
|  | Three Months Ended April 30, |  |  |  |  |  | Nine Months Ended April 30, |  |  |  |  |
|  | 2022 |  | 2021 |  | Change |  | 2022 |  | 2021 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| General and administrative | $ | 94.8 |  |  | $ | 94.7 |  |  | $ | 0.1 |  |  | 0.1 | % |  | $ | 296.6 |  |  | $ | 285.4 |  |  | $ | 11.2 |  |  | 3.9 | % |
| Number of employees at period end | 1,368 |  |  | 1053 |  |  | 315 |  |  | 29.9 | % |  | 1,368 |  |  | 1,053 |  |  | 315 |  |  | 29.9 | % |

[0001327567-22-000016:mdna:106]
General and administrative expense was relatively flat for the three months ended April 30, 2022 compared to the same period in 2021, primarily due to an increase in personnel costs, offset by a decrease in professional services expense. Personnel costs increased $10.1 million to $68.4 million for the three months ended April 30, 2022, primarily due to headcount growth, partially offset by share-based compensation related to accelerated vesting of equity awards incurred in connection with acquisitions during the three months ended April 30, 2021, which did not recur in the three months ended April 30, 2022. General and administrative expense increased for the nine months ended April 30, 2022 compared to the same period in 2021, primarily due to personnel costs, which increased $21.1 million to $205.1 million for the nine months ended April 30, 2022, partially offset by a decrease in acquisition-related costs. The increase in personnel costs in the nine months ended April 30, 2022 was primarily due to headcount growth, partially offset by lower share-based compensation related to accelerated vesting of equity awards in connection with acquisitions compared to the same period in 2021.

[0001327567-22-000016:mdna:107]
[same as prior period, unchanged from 0001327567-22-000008:mdna:108]

[0001327567-22-000016:mdna:108]
Interest expense primarily consists of interest expense related to our 0.75% Convertible Senior Notes due 2023 (the “2023 Notes”) and the 0.375% Convertible Senior Notes due 2025 (the “2025 Notes,” and together with “2023 Notes,” the “Notes”).

[0001327567-22-000016:mdna:109]
|  | Three Months Ended April 30, |  |  |  | Nine Months Ended April 30, |  |  |
|  | 2022 |  | 2021 |  | Change |  | 2022 |  | 2021 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Interest expense | $ | 6.8 |  |  | $ | 41.0 |  |  | $ | (34.2) |  |  | (83.4) | % |  | $ | 20.5 |  |  | $ | 121.9 |  |  | $ | (101.4) |  |  | (83.2) | % |

[0001327567-22-000016:mdna:110]
Interest expense decreased for the three and nine months ended April 30, 2022 compared to the same periods in 2021 primarily because we no longer recognize interest expense for amortization of the debt discount as a result of the adoption of new debt guidance. Refer to Note 1. Description of Business and Summary of Significant Accounting Policies and Note 9. Debt in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information.

[0001327567-22-000016:mdna:111]
Other Income, Net

[0001327567-22-000016:mdna:112]
Other income, net includes interest income earned on our cash, cash equivalents, and investments, and gains and losses from foreign currency remeasurement and foreign currency transactions.

[0001327567-22-000016:mdna:113]
|  | Three Months Ended April 30, |  |  |  | Nine Months Ended April 30, |  |  |
|  | 2022 |  | 2021 |  | Change |  | 2022 |  | 2021 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Other income, net | $ | 1.9 |  |  | $ | 1.0 |  |  | $ | 0.9 |  |  | 90.0 | % |  | $ | 0.2 |  |  | $ | 2.9 |  |  | $ | (2.7) |  |  | (93.1) | % |

[0001327567-22-000016:mdna:114]
The increase in other income, net for the three months ended April 30, 2022 compared to the same period in 2021 was primarily due to increased foreign currency exchange gains. The decrease in other income, net for the nine months ended April 30, 2022 compared to the same period in 2021 was primarily due to increased losses related to non-designated derivative instruments.

[0001327567-22-000016:mdna:115]
[same as prior period, unchanged from 0001327567-22-000008:mdna:130]

[0001327567-22-000016:mdna:116]
[same as prior period, unchanged from 0001327567-22-000008:mdna:117]

[0001327567-22-000016:mdna:117]
Provision for (Benefit from) Income Taxes

[0001327567-22-000016:mdna:118]
Provision for (benefit from) income taxes consists primarily of income taxes in foreign jurisdictions in which we conduct business and withholding taxes. We maintain a full valuation allowance for domestic and certain foreign deferred tax assets, including net operating loss carryforwards and certain domestic tax credits. Our valuation allowance has caused, and may continue to cause, disproportionate relationships between our overall effective tax rate and other jurisdictional measures.

[0001327567-22-000016:mdna:119]
|  | Three Months Ended April 30, |  | Change |  | Nine Months Ended April 30, |  | Change |
|  | 2022 |  | 2021 |  | Amount |  | % |  | 2022 |  | 2021 |  | Amount |  | % |
|  | (dollars in millions) |
| Provision for (benefit from) income taxes | $ | 20.7 |  |  | $ | (5.3) |  |  | $ | 26.0 |  |  | (490.6) | % |  | $ | 45.8 |  |  | $ | 16.9 |  |  | $ | 28.9 |  |  | 171.0 | % |
| Effective tax rate | (39.4) | % |  | 3.5 | % |  |  |  |  |  | (20.4) | % |  | (4.7) | % |  |  |  |  |

[0001327567-22-000016:mdna:120]
Our income taxes for the three and nine months ended April 30, 2022 and 2021 were primarily due to foreign income taxes in profitable jurisdictions and withholding taxes. Our effective tax rate varied for the three and nine months ended April 30, 2022 compared to the same periods in 2021 primarily due to our valuation allowance. Refer to Note 13. Income Taxes in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information.

[0001327567-22-000016:mdna:121]
[same as prior period, unchanged from 0001327567-22-000008:mdna:122]

[0001327567-22-000016:mdna:122]
|  | April 30, 2022 |  | July 31, 2021 |
|  | (in millions) |
| Working capital(1) | $ | (1,979.6) |  |  | $ | (469.4) |  |
| Cash, cash equivalents, and investments: |  |  |  |
| Cash and cash equivalents | $ | 2,419.9 |  |  | $ | 1,874.2 |  |
| Investments | 2,169.4 |  |  | 1,915.2 |  |
| Total cash, cash equivalents, and investments | $ | 4,589.3 |  |  | $ | 3,789.4 |  |

[0001327567-22-000016:mdna:123]
[same as prior period, unchanged from 0001327567-22-000008:mdna:124]

[0001327567-22-000016:mdna:124]
(1)Current liabilities included net carrying amounts of convertible senior notes of $3.7 billion and $1.6 billion as of April 30, 2022 and July 31, 2021, respectively. Refer to Note 9. Debt in Part I, Item 1 of this Quarterly Report on Form 10-Q for information on the Notes.

[0001327567-22-000016:mdna:125]
As of April 30, 2022, our total cash, cash equivalents, and investments of $4.6 billion were held for general corporate purposes, of which approximately $993.8 million was held outside of the United States. As of April 30, 2022, we had no unremitted earnings when evaluating our outside basis difference relating to our U.S. investment in foreign subsidiaries. However, there could be local withholding taxes payable due to various foreign countries if certain lower tier earnings are distributed. Withholding taxes that would be payable upon remittance of these lower tier earnings are not expected to be material.

[0001327567-22-000016:mdna:126]
[same as prior period, unchanged from 0001327567-22-000008:mdna:127]

[0001327567-22-000016:mdna:127]
In July 2018, we issued the 2023 Notes with an aggregate principal amount of $1.7 billion. In June 2020, we issued the 2025 Notes with an aggregate principal amount of $2.0 billion. The 2023 Notes mature on July 1, 2023 and the 2025 Notes mature on June 1, 2025; however, under certain circumstances, holders may surrender their Notes of a series for conversion prior to the applicable maturity date. Upon conversion of the Notes of a series, we will pay cash equal to the aggregate principal amount of the Notes of such series to be converted, and, at our election, will pay or deliver cash and/or shares of our common stock for the amount of our conversion obligation in excess of the aggregate principal amount of the Notes of such series being converted. The sale price condition for the Notes was met during the fiscal quarter ended April 30, 2022, and as a result, holders may convert their Notes at any time during the fiscal quarter ending July 31, 2022. If all of the holders of the Notes converted their Notes during this period, we would be obligated to settle the $3.7 billion principal amount of the Notes in cash. We believe that our cash provided by operating activities, our existing cash, cash equivalents and investments, and existing sources of and access to financing will be sufficient to meet our anticipated cash needs should the holders choose to convert their Notes during the fiscal quarter ending July 31, 2022. As of April 30, 2022, substantially all of our Notes remained outstanding. Refer to Note 9. Debt in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information on the Notes.

[0001327567-22-000016:mdna:128]
In September 2018, we entered into a credit agreement (the “Credit Agreement”) that provides for a $400.0 million unsecured revolving credit facility (the “Credit Facility”), with an option to increase the amount of the credit facility up to an additional $350.0 million, subject to certain conditions. As of April 30, 2022, there were no amounts outstanding and we were in compliance with all covenants under the Credit Agreement. Refer to Note 9. Debt in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information on the Credit Agreement.

[0001327567-22-000016:mdna:129]
[same as prior period, unchanged from 0001327567-22-000008:mdna:147]

[0001327567-22-000016:mdna:130]
[same as prior period, unchanged from 0001327567-22-000008:mdna:131]

[0001327567-22-000016:mdna:131]
[same as prior period, unchanged from 0001327567-22-000008:mdna:132]

[0001327567-22-000016:mdna:132]
In February 2019, our board of directors authorized a $1.0 billion share repurchase program. In December 2020 and August 2021, our board of directors authorized additional $700.0 million and $676.1 million increases, respectively, bringing the total authorization under this share repurchase program to $2.4 billion. Repurchases will be funded from available working capital and may be made at management’s discretion from time to time. The expiration date of this repurchase authorization was extended to December 31, 2022, and our repurchase program may be suspended or discontinued at any time. As of April 30, 2022, $450.0 million remained available for future share repurchases under this repurchase program. Refer to Note 11. Stockholders’ Equity in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information on this repurchase program.

[0001327567-22-000016:mdna:133]
[same as prior period, unchanged from 0001327567-22-000008:mdna:134]

[0001327567-22-000016:mdna:134]
We have entered into various non-cancelable operating leases primarily for our facilities with original lease periods expiring through the year ending July 31, 2028, with the most significant leases relating to corporate headquarters in Santa Clara, California. As of April 30, 2022, we have total of $337.4 million operating lease obligations recorded on our condensed consolidated balance sheet.

[0001327567-22-000016:mdna:135]
As of April 30, 2022, our purchase obligations including commitments of products and components with our manufacturing partners and component suppliers, as well as minimum or fixed purchase commitments for our use of certain cloud and other services with third-party providers, totaled $2.5 billion. Refer to Note 10. Commitments and Contingencies in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information on these commitments,

[0001327567-22-000016:mdna:136]
[same as prior period, unchanged from 0001327567-22-000008:mdna:137]

[0001327567-22-000016:mdna:137]
The following table summarizes our cash flows for the nine months ended April 30, 2022 and 2021:

[0001327567-22-000016:mdna:138]
|  | Nine Months Ended April 30, |
| 2022 |  | 2021 |
|  | (in millions) |
| Net cash provided by operating activities | $ | 1,461.0 |  |  | $ | 1,177.2 |  |
| Net cash used in investing activities | (461.3) |  |  | (1,478.2) |  |
| Net cash used in financing activities | (453.5) |  |  | (768.4) |  |
| Net increase (decrease) in cash, cash equivalents, and restricted cash | $ | 546.2 |  |  | $ | (1,069.4) |  |

[0001327567-22-000016:mdna:139]
[same as prior period, unchanged from 0001327567-22-000008:mdna:140]

[0001327567-22-000016:mdna:140]
[same as prior period, unchanged from 0001327567-22-000008:mdna:141]

[0001327567-22-000016:mdna:141]
[same as prior period, unchanged from 0001327567-22-000008:mdna:142]

[0001327567-22-000016:mdna:142]
[same as prior period, unchanged from 0001327567-22-000008:mdna:143]

[0001327567-22-000016:mdna:143]
Cash provided by operating activities during the nine months ended April 30, 2022 was $1.5 billion, an increase of $283.8 million compared to the same period in 2021. The increase was primarily due to growth of our business as reflected by an increase in billings, and an increase in collections during the nine months ended April 30, 2022, partially offset by higher cash expenditure to support our business growth.

[0001327567-22-000016:mdna:144]
[same as prior period, unchanged from 0001327567-22-000008:mdna:145]

[0001327567-22-000016:mdna:145]
[same as prior period, unchanged from 0001327567-22-000008:mdna:146]

[0001327567-22-000016:mdna:146]
Cash used in investing activities during the nine months ended April 30, 2022 was $461.3 million, a decrease of $1.0 billion compared to the same period in 2021. The decrease was primarily due to a decrease in net cash payments for business acquisitions, a

[0001327567-22-000016:mdna:147]
- 34 -

[0001327567-22-000016:mdna:148]
[same as prior period, unchanged from 0001327567-22-000008:mdna:148]

[0001327567-22-000016:mdna:149]
decrease in purchases of investments, and an increase in proceeds from sales and maturities of investments during the nine months ended April 30, 2022.

[0001327567-22-000016:mdna:150]
[same as prior period, unchanged from 0001327567-22-000008:mdna:150]

[0001327567-22-000016:mdna:151]
[same as prior period, unchanged from 0001327567-22-000008:mdna:151]

[0001327567-22-000016:mdna:152]
Cash used in financing activities during the nine months ended April 30, 2022 was $453.5 million, an decrease of $314.9 million compared to the same period in 2021. The decrease was primarily due to a decrease in repurchases of our common stock during the nine months ended April 30, 2022.

[0001327567-22-000016:mdna:153]
[same as prior period, unchanged from 0001327567-22-000008:mdna:153]

[0001327567-22-000016:mdna:154]
Our condensed consolidated financial statements have been prepared in accordance with GAAP. The preparation of these condensed consolidated financial statements requires us to make estimates and assumptions that affect the reported amounts of assets, liabilities, revenue, expenses, and related disclosures. We base our estimates on historical experience and on various other assumptions that we believe are reasonable under the circumstances. We evaluate our estimates and assumptions on an ongoing basis. Actual results could differ materially from those estimates due to risks and uncertainties, including uncertainty in the economic environment due to the global impact of events such as COVID-19. To the extent that there are material differences between these estimates and our actual results, our future financial statements will be affected.

[0001327567-22-000016:mdna:155]
[same as prior period, unchanged from 0001327567-22-000008:mdna:155]

[0001327567-22-000016:mdna:156]
[same as prior period, unchanged from 0001327567-22-000008:mdna:156]

[0001327567-22-000016:mdna:157]
[same as prior period, unchanged from 0001327567-22-000008:mdna:157]
