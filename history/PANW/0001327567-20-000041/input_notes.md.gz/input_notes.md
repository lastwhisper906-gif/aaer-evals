# PANW notes — 0001327567-20-000041


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0001327567-20-000041:notes:1]
Description of Business and Summary of Significant Accounting Policies 
Description of Business

[0001327567-20-000041:notes:2]
Palo Alto Networks, Inc. (the “Company,” “we,” “us,” or “our”), located in Santa Clara, California, was incorporated in March 2005 under the laws of the State of Delaware and commenced operations in April 2005. We empower enterprises, service providers, and government entities to secure all users, applications, data, networks, and devices with comprehensive context at all times, across all locations.

[0001327567-20-000041:notes:3]
Basis of Presentation and Principles of Consolidation

[0001327567-20-000041:notes:4]
The accompanying condensed consolidated financial statements have been prepared in conformity with U.S. generally accepted accounting principles (“GAAP”), consistent in all material respects with those applied in our Annual Report on Form 10-K for the fiscal year ended July 31, 2020, filed with the Securities and Exchange Commission (“SEC”) on September 4, 2020. Our condensed consolidated financial statements include our accounts and our wholly owned subsidiaries. All significant intercompany balances and transactions have been eliminated in consolidation.

[0001327567-20-000041:notes:5]
Our condensed consolidated financial statements are unaudited, but include all adjustments of a normal recurring nature necessary for a fair presentation of our quarterly results. Our condensed consolidated financial statements should be read in conjunction with the audited consolidated financial statements and related notes in our Annual Report on Form 10-K for the fiscal year ended July 31, 2020.

[0001327567-20-000041:notes:6]
Use of Estimates

[0001327567-20-000041:notes:7]
The preparation of condensed consolidated financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the consolidated financial statements and the reported amounts of revenues and expenses during the reporting period. We base our estimates on historical experience and also on assumptions that we believe are reasonable. Actual results could differ materially from those estimates due to risks and uncertainties, including uncertainty in the current economic environment due to COVID-19.

[0001327567-20-000041:notes:8]
Summary of Significant Accounting Policies

[0001327567-20-000041:notes:9]
There have been no material changes to our significant accounting policies as of and for the three months ended October 31, 2020, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended July 31, 2020, except for the change in our accounting policies for credit losses due to our adoption of the new credit losses guidance. Refer to “Recently Adopted Accounting Pronouncements” below.

[0001327567-20-000041:notes:10]
Recently Adopted Accounting Pronouncements

[0001327567-20-000041:notes:11]
Credit Losses

[0001327567-20-000041:notes:12]
In June 2016, the Financial Accounting Standards Board (“FASB”) issued new authoritative guidance on the accounting for credit losses on most financial assets and certain financial instruments. The standard replaces the incurred loss model with an expected credit loss model for financial assets measured at amortized cost, including trade accounts receivables and financing receivables. Credit losses on available-for-sale debt securities are required to be recorded through an allowance rather than as a write-down.

[0001327567-20-000041:notes:13]
We adopted this standard in our first quarter of fiscal 2021 using the modified-retrospective approach. The adoption of this standard did not have a material impact on our condensed consolidated financial statements. We updated the following accounting policies as a result of the adoption of this guidance.

[0001327567-20-000041:notes:14]
Cash, Cash Equivalents, and Investments

[0001327567-20-000041:notes:15]
We consider all highly liquid investments with original maturities of three months or less at the date of purchase to be cash equivalents. Investments not considered cash equivalents, and with maturities of one year or less from the condensed consolidated balance sheet date, are classified as short-term investments. Investments with maturities greater than one year from the condensed consolidated balance sheet date are classified as long-term investments.

[0001327567-20-000041:notes:16]
We classify our investments in marketable debt securities as available-for-sale at the time of purchase. When the fair value of a security is below its amortized cost, the amortized cost will be reduced to its fair value if it is more likely than not that we are required to sell the impaired security before recovery of its amortized cost basis, or we have the intention to sell the security. If neither of these conditions are met, we determine whether the impairment is due to credit losses by comparing the present value of the expected cash flows of the security with its amortized cost basis. The amount of impairment recognized is limited to the excess of the amortized cost over the fair value of the security. An allowance for credit losses for the excess of amortized cost over the expected cash flows is

[0001327567-20-000041:notes:17]
recorded in other income, net in our condensed consolidated statements of operations. Impairment losses that are not credit-related are included in accumulated other comprehensive income (loss) (“AOCI”) in stockholders’ equity.

[0001327567-20-000041:notes:18]
Accounts Receivable

[0001327567-20-000041:notes:19]
Trade accounts receivable are recorded at the invoiced amount, net of allowances for credit losses for any potential uncollectible amounts. The allowance for credit losses is based on our assessment of the collectability of accounts. Management regularly reviews the adequacy of the allowance for credit losses on a collective basis by considering the age of each outstanding invoice, each customer’s expected ability to pay and collection history, current market conditions, and reasonable and supportable forecasts of future economic conditions to determine whether the allowance is appropriate. Accounts receivable deemed uncollectible are charged against the allowance for credit losses when identified. For the three months ended October 31, 2020 and 2019, the allowance for credit losses activity was not significant.

[0001327567-20-000041:notes:20]
Financing Receivables

[0001327567-20-000041:notes:21]
We provide financing arrangements, primarily loans, for certain qualified end-user customers to purchase our products and services. Payment terms on these financing arrangements are generally up to three years. We evaluate our allowance for credit losses by assessing the risks and losses inherent in our financing receivables on either an individual or a collective basis. Our assessment considers various factors, including lifetime expected losses determined using customer risk profile, current economic conditions that may affect a customer’s ability to pay, and forward-looking economic considerations. Financing receivables are written off when they are considered uncollectible, and related outstanding balances are reversed and charged against the allowance for credit losses. Short-term financing receivables are included in prepaid expenses and other current assets, and long-term financing receivables are included in other assets on our condensed consolidated balance sheets. Refer to Note 5. Financing Receivables for additional information.

[0001327567-20-000041:notes:22]
Recently Issued Accounting Pronouncements

[0001327567-20-000041:notes:23]
Debt with Conversion Options

[0001327567-20-000041:notes:24]
In August 2020, the FASB issued new authoritative guidance to simplify the accounting for certain financial instruments with characteristics of liabilities and equity, including convertible instruments and contracts on an entity’s own equity. The standard reduces the number of models used to account for convertible instruments, and simplifies both the classification of debt on the balance sheet and the earnings per share calculation. The standard is effective for us in our first quarter of fiscal 2023 and will be applied on a modified retrospective basis. Early adoption is permitted from our first quarter of fiscal 2022. We are currently evaluating the impact of this standard on our condensed consolidated financial statements.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001327567-20-000041:notes:25]
[same as prior period, unchanged from 0001327567-20-000017:notes:21]

[0001327567-20-000041:notes:26]
[same as prior period, unchanged from 0001327567-20-000017:notes:22]

[0001327567-20-000041:notes:27]
|  |  |  | Three Months Ended October 31, |
|  |  |  |  |  | 2020 |  | 2019 |
| Revenue: |  |  |  |  |  |  |  |
| Americas |  |  |  |  |  |  |  |
| United States |  |  |  |  | $ | 628.4 |  |  | $ | 494.9 |  |
| Other Americas |  |  |  |  | 41.9 |  |  | 34.7 |  |
| Total Americas |  |  |  |  | 670.3 |  |  | 529.6 |  |
| Europe, the Middle East, and Africa (“EMEA”) |  |  |  |  | 170.9 |  |  | 147.6 |  |
| Asia Pacific and Japan (“APAC”) |  |  |  |  | 104.8 |  |  | 94.7 |  |
| Total revenue |  |  |  |  | $ | 946.0 |  |  | $ | 771.9 |  |

[0001327567-20-000041:notes:28]
[same as prior period, unchanged from 0001327567-20-000017:notes:24]

[0001327567-20-000041:notes:29]
|  |  |  | Three Months Ended October 31, |
|  |  |  |  |  | 2020 |  | 2019 |
| Revenue: |  |  |  |  |  |  |  |
| Product |  |  |  |  | $ | 237.3 |  |  | $ | 231.2 |  |
| Subscription and support |  |  |  |  |  |  |  |
| Subscription |  |  |  |  | 428.0 |  |  | 318.6 |  |
| Support |  |  |  |  | 280.7 |  |  | 222.1 |  |
| Total subscription and support |  |  |  |  | 708.7 |  |  | 540.7 |  |
| Total revenue |  |  |  |  | $ | 946.0 |  |  | $ | 771.9 |  |

[0001327567-20-000041:notes:30]
[same as prior period, unchanged from 0001327567-20-000017:notes:26]

[0001327567-20-000041:notes:31]
During the three months ended October 31, 2020, we recognized approximately $630.0 million of revenue pertaining to amounts that were deferred as of July 31, 2020.

[0001327567-20-000041:notes:32]
[same as prior period, unchanged from 0001327567-20-000017:notes:28]

[0001327567-20-000041:notes:33]
Revenue expected to be recognized from remaining performance obligations was $4.4 billion as of October 31, 2020, of which we expect to recognize approximately $2.3 billion over the next 12 months and the remainder thereafter.
Deferred Contract Costs
The following table presents details of our short-term and long-term deferred contract costs as of October 31, 2020 and July 31, 2020 (in millions):

[0001327567-20-000041:notes:34]
|  | October 31, 2020 |  | July 31, 2020 |
| Short-term deferred contract costs | $ | 213.0 |  |  | $ | 206.0 |  |
| Long-term deferred contract costs | 408.8 |  |  | 422.3 |  |
| Total deferred contract costs | $ | 621.8 |  |  | $ | 628.3 |  |

[0001327567-20-000041:notes:35]
We recognized amortization expense for our deferred contract costs of $65.8 million and $55.6 million during the three months ended October 31, 2020 and 2019, respectively. We did not recognize any impairment losses on our deferred contract costs during the three months ended October 31, 2020 or 2019.


## us-gaap:FairValueMeasurementPolicyPolicyTextBlock

[0001327567-20-000041:notes:36]
[same as prior period, unchanged from 0001327567-20-000017:notes:32]

[0001327567-20-000041:notes:37]
[same as prior period, unchanged from 0001327567-20-000017:notes:33]

[0001327567-20-000041:notes:38]
•Level 2—Inputs are quoted prices for similar assets and liabilities in active markets or inputs that are observable for the assets or liabilities, either directly or indirectly through market corroboration, for substantially the full term of the financial instruments.

[0001327567-20-000041:notes:39]
•Level 3—Inputs are unobservable inputs based on our own assumptions used to measure assets and liabilities at fair value. The inputs require significant management judgment or estimation.


## us-gaap:FairValueDisclosuresTextBlock

[0001327567-20-000041:notes:40]
The following table presents the fair value of our financial assets and liabilities measured at fair value on a recurring basis using the above input categories as of October 31, 2020 and July 31, 2020 (in millions):

[0001327567-20-000041:notes:41]
|  |  | October 31, 2020 |  | July 31, 2020 |
|  |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Cash equivalents: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 392.3 |  |  | $ | — |  |  | $ | — |  |  | $ | 392.3 |  |  | $ | 1,589.5 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,589.5 |  |
| Certificates of deposit |  | — |  |  | 150.0 |  |  | — |  |  | 150.0 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| U.S. government and agency securities |  | — |  |  | 407.6 |  |  | — |  |  | 407.6 |  |  | — |  |  | 342.0 |  |  | — |  |  | 342.0 |  |
| Total cash equivalents |  | 392.3 |  |  | 557.6 |  |  | — |  |  | 949.9 |  |  | 1,589.5 |  |  | 342.0 |  |  | — |  |  | 1,931.5 |  |
| Short-term investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Certificates of deposit |  | — |  |  | 31.1 |  |  | — |  |  | 31.1 |  |  | — |  |  | 26.9 |  |  | — |  |  | 26.9 |  |
| Commercial paper |  | — |  |  | 10.0 |  |  | — |  |  | 10.0 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Corporate debt securities |  | — |  |  | 169.1 |  |  | — |  |  | 169.1 |  |  | — |  |  | 100.2 |  |  | — |  |  | 100.2 |  |
| U.S. government and agency securities |  | — |  |  | 827.3 |  |  | — |  |  | 827.3 |  |  | — |  |  | 645.6 |  |  | — |  |  | 645.6 |  |
| Non-U.S. government and agency securities |  |  |  | 38.1 |  |  |  |  | 38.1 |  |  |  |  | 17.1 |  |  |  |  | 17.1 |  |
| Total short-term investments |  | — |  |  | 1,075.6 |  |  | — |  |  | 1,075.6 |  |  | — |  |  | 789.8 |  |  | — |  |  | 789.8 |  |
| Long-term investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Certificates of deposit |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 5.0 |  |  | — |  |  | 5.0 |  |
| Corporate debt securities |  | — |  |  | 162.9 |  |  | — |  |  | 162.9 |  |  | — |  |  | 91.7 |  |  | — |  |  | 91.7 |  |
| U.S. government and agency securities |  | — |  |  | 667.2 |  |  | — |  |  | 667.2 |  |  | — |  |  | 447.4 |  |  | — |  |  | 447.4 |  |
| Non-U.S. government and agency securities |  | — |  |  | 43.1 |  |  | — |  |  | 43.1 |  |  | — |  |  | 10.3 |  |  | — |  |  | 10.3 |  |
| Total long-term investments |  | — |  |  | 873.2 |  |  | — |  |  | 873.2 |  |  | — |  |  | 554.4 |  |  | — |  |  | 554.4 |  |
| Prepaid expenses and other current assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency forward contracts |  | — |  |  | 9.2 |  |  | — |  |  | 9.2 |  |  | — |  |  | 13.6 |  |  | — |  |  | 13.6 |  |
| Total prepaid expenses and other current assets |  | — |  |  | 9.2 |  |  | — |  |  | 9.2 |  |  | — |  |  | 13.6 |  |  | — |  |  | 13.6 |  |
| Other assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency forward contracts |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 1.4 |  |  | — |  |  | 1.4 |  |
| Total other assets: |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 1.4 |  |  | — |  |  | 1.4 |  |
| Total assets measured at fair value |  | $ | 392.3 |  |  | $ | 2,515.6 |  |  | $ | — |  |  | $ | 2,907.9 |  |  | $ | 1,589.5 |  |  | $ | 1,701.2 |  |  | $ | — |  |  | $ | 3,290.7 |  |

[0001327567-20-000041:notes:42]
Refer to Note 10. Debt for the carrying amount and estimated fair value of our convertible senior notes as of October 31, 2020 and July 31, 2020.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001327567-20-000041:notes:43]
Cash Equivalents and Investments
Available-for-sale Debt Securities

[0001327567-20-000041:notes:44]
The following tables summarize the amortized cost, unrealized gains and losses, and fair value of our available-for-sale debt securities as of October 31, 2020 and July 31, 2020 (in millions):

[0001327567-20-000041:notes:45]
|  | October 31, 2020 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 150.0 |  |  | $ | — |  |  | $ | — |  |  | $ | 150.0 |  |
| U.S. government and agency securities | 407.6 |  |  | — |  |  | — |  |  | 407.6 |  |
| Total available-for-sale cash equivalents | $ | 557.6 |  |  | $ | — |  |  | $ | — |  |  | $ | 557.6 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 31.1 |  |  | $ | — |  |  | $ | — |  |  | $ | 31.1 |  |
| Commercial paper | 10.0 |  |  | — |  |  | — |  |  | 10.0 |  |
| Corporate debt securities | 330.7 |  |  | 1.3 |  |  | — |  |  | 332.0 |  |
| U.S. government and agency securities | 1,492.6 |  |  | 2.0 |  |  | (0.1) |  |  | 1,494.5 |  |
| Non-U.S. government securities | 81.2 |  |  | — |  |  | — |  |  | 81.2 |  |
| Total available-for-sale investments | $ | 1,945.6 |  |  | $ | 3.3 |  |  | $ | (0.1) |  |  | $ | 1,948.8 |  |

[0001327567-20-000041:notes:46]
|  | July 31, 2020 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| U.S. government and agency securities | $ | 342.0 |  |  | $ | — |  |  | $ | — |  |  | $ | 342.0 |  |
| Total available-for-sale cash equivalents | $ | 342.0 |  |  | $ | — |  |  | $ | — |  |  | $ | 342.0 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 31.9 |  |  | $ | — |  |  | $ | — |  |  | $ | 31.9 |  |
| Corporate debt securities | 190.1 |  |  | 1.8 |  |  | — |  |  | 191.9 |  |
| U.S. government and agency securities | 1,090.3 |  |  | 2.8 |  |  | (0.1) |  |  | 1,093.0 |  |
| Non-U.S. government and agency securities | 27.4 |  |  | — |  |  | — |  |  | 27.4 |  |
| Total available-for-sale investments | $ | 1,339.7 |  |  | $ | 4.6 |  |  | $ | (0.1) |  |  | $ | 1,344.2 |  |

[0001327567-20-000041:notes:47]
We do not intend to sell any of the securities in an unrealized loss position and it is not likely that we would be required to sell these securities before recovery of their amortized cost basis, which may be at maturity. We did not recognize any credit losses related to our available-for-sale debt securities during the three months ended October 31, 2020.

[0001327567-20-000041:notes:48]
The following table summarizes the amortized cost and fair value of our available-for-sale debt securities as of October 31, 2020, by contractual years-to-maturity (in millions):

[0001327567-20-000041:notes:49]
|  | Amortized Cost |  | Fair Value |
| Due within one year | $ | 1,631.7 |  |  | $ | 1,633.2 |  |
| Due between one and three years | 871.5 |  |  | 873.2 |  |
| Total | $ | 2,503.2 |  |  | $ | 2,506.4 |  |

[0001327567-20-000041:notes:50]
Marketable Equity Securities

[0001327567-20-000041:notes:51]
Marketable equity securities consist of money market funds and are included in cash and cash equivalents on our condensed consolidated balance sheets. As of October 31, 2020 and July 31, 2020, the carrying value of our marketable equity securities were $392.3 million and $1.6 billion, respectively. There were no unrealized gains or losses recognized for these securities during the three months ended October 31, 2020 and 2019.


## us-gaap:FinancingReceivablesTextBlock

[0001327567-20-000041:notes:52]
Financing Receivables
We provide financing arrangements, primarily loans, for certain qualified end-user customers to purchase our products. The following table summarizes our short-term and long-term financing receivables as of October 31, 2020 (in millions):

[0001327567-20-000041:notes:53]
|  |  | October 31, 2020 |
| Short-term financing receivables, gross |  | $ | 11.2 |  |
| Allowance for credit losses |  | (0.2) |  |
| Short-term financing receivables, net |  | $ | 11.0 |  |
| Long-term financing receivables, gross |  | $ | 9.5 |  |
| Allowance for credit losses |  | (0.2) |  |
| Long-term financing receivables, net |  | $ | 9.3 |  |

[0001327567-20-000041:notes:54]
Through July 31, 2020, financing receivables were not significant to our condensed consolidated balance sheet. There was no significant activity in allowance for credit losses during the three months ended October 31, 2020. There were no past due amounts on financing receivables as of October 31, 2020 and July 31, 2020.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001327567-20-000041:notes:55]
Derivative Instruments
As a global business, we are exposed to currency exchange rate risk. Substantially all of our revenue is transacted in U.S. dollars, however, a portion of our operating expenditures are incurred outside of the United States and are denominated in foreign currencies, making them subject to fluctuations in foreign currency exchange rates. We enter into foreign currency derivative contracts with maturities of 15 months or less, which we designate as cash flow hedges, to manage the foreign currency exchange rate risk associated with these expenditures.

[0001327567-20-000041:notes:56]
As of October 31, 2020 and July 31, 2020, the total notional amount of our outstanding foreign currency forward contracts was $386.7 million and $443.6 million, respectively. Refer to Note 3. Fair Value Measurements for the fair value of our derivative instruments as reported on our condensed consolidated balance sheets as of October 31, 2020.

[0001327567-20-000041:notes:57]
During the three months ended October 31, 2020 and 2019, both unrealized gains and losses recognized in AOCI related to our cash flow hedges and amounts reclassified into earnings were not material. Unrealized gains and losses in AOCI related to our cash flow hedges as of October 31, 2020 and 2019 were not material.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001327567-20-000041:notes:58]
Acquisition
The Crypsis Group

[0001327567-20-000041:notes:59]
On September 17, 2020, we completed our acquisition of The Crypsis Group (“Crypsis”), an incident response, risk management, and digital forensics consulting firm. We believe the acquisition will expand our capabilities and strengthen our Cortex strategy. The total purchase consideration for the acquisition of Crypsis was $227.7 million, which consisted of the following (in millions):

[0001327567-20-000041:notes:60]
|  | Amount |
| Cash | $ | 225.7 |  |
| Fair value of replacement awards | 2.0 |  |
| Total | $ | 227.7 |  |

[0001327567-20-000041:notes:61]
As part of the acquisition, we issued $27.1 million of replacement awards, of which the portion attributable to services performed prior to the acquisition date was allocated to purchase consideration. The remaining fair value was allocated to future services and will be expensed over the remaining service periods as share-based compensation.

[0001327567-20-000041:notes:62]
[same as prior period, unchanged from 0001327567-20-000017:notes:57]

[0001327567-20-000041:notes:63]
|  | Amount |
| Goodwill | $ | 157.6 |  |
| Identified intangible assets | 54.4 |  |
| Net assets acquired | 15.7 |  |
| Total | $ | 227.7 |  |

[0001327567-20-000041:notes:64]
Goodwill generated from this business combination is primarily attributable to the assembled workforce and expected post-acquisition synergies from integrating Crypsis technology into our platforms. The goodwill is deductible for income tax purposes.

[0001327567-20-000041:notes:65]
[same as prior period, unchanged from 0001327567-20-000017:notes:60]

[0001327567-20-000041:notes:66]
|  | Fair Value |  | Estimated Useful Life |
| Developed technology | $ | 6.9 |  |  | 3 years |
| Customer relationships | 47.5 |  |  | 7 years |
| Total | $ | 54.4 |  |  |  |

[0001327567-20-000041:notes:67]
[same as prior period, unchanged from 0001327567-20-000017:notes:75]

[0001327567-20-000041:notes:68]
The operating results of the acquired company are included in our condensed consolidated statement of operations from the date of acquisition. Pro forma results of operations have not been presented because the effects of the acquisition were not material to our condensed consolidated statements of operations.

[0001327567-20-000041:notes:69]
Additional information related to the acquired company, such as that related to income tax and other contingencies, existing as of the acquisition date but unknown to us, may become known during the remainder of the measurement period, not to exceed 12 months from the acquisition date, which may result in changes to the amounts and allocations recorded.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001327567-20-000041:notes:70]
[same as prior period, unchanged from 0001327567-20-000017:notes:78]

[0001327567-20-000041:notes:71]
The following table presents details of our goodwill during the three months ended October 31, 2020 (in millions):

[0001327567-20-000041:notes:72]
|  | Amount |
| Balance as of July 31, 2020 | $ | 1,812.9 |  |
| Goodwill acquired | 157.6 |  |
| Measurement period adjustment | (1.9) |  |
| Balance as of October 31, 2020 | $ | 1,968.6 |  |

[0001327567-20-000041:notes:73]
[same as prior period, unchanged from 0001327567-20-000017:notes:81]

[0001327567-20-000041:notes:74]
The following table presents details of our purchased intangible assets as of October 31, 2020 and July 31, 2020 (in millions):

[0001327567-20-000041:notes:75]
|  | October 31, 2020 |  | July 31, 2020 |
|  | Gross Carrying Amount |  | Accumulated Amortization |  | Net Carrying Amount |  | Gross Carrying Amount |  | Accumulated Amortization |  | Net Carrying Amount |
| Intangible assets subject to amortization: |  |  |  |  |  |  |  |  |  |  |  |
| Developed technology | $ | 432.6 |  |  | $ | (166.6) |  |  | $ | 266.0 |  |  | $ | 425.9 |  |  | $ | (146.6) |  |  | $ | 279.3 |  |
| Customer relationships | 134.0 |  |  | (14.6) |  |  | 119.4 |  |  | 87.6 |  |  | (12.4) |  |  | 75.2 |  |
| Acquired intellectual property | 6.3 |  |  | (3.3) |  |  | 3.0 |  |  | 6.3 |  |  | (3.2) |  |  | 3.1 |  |
| Trade name and trademarks | 9.4 |  |  | (9.4) |  |  | — |  |  | 9.4 |  |  | (9.4) |  |  | — |  |
| Other | 2.8 |  |  | (2.4) |  |  | 0.4 |  |  | 3.1 |  |  | (2.5) |  |  | 0.6 |  |
| Total purchased intangible assets | $ | 585.1 |  |  | $ | (196.3) |  |  | $ | 388.8 |  |  | $ | 532.3 |  |  | $ | (174.1) |  |  | $ | 358.2 |  |

[0001327567-20-000041:notes:76]
We recognized amortization expense of $23.6 million and $16.9 million for the three months ended October 31, 2020 and 2019, respectively.

[0001327567-20-000041:notes:77]
The following table summarizes estimated future amortization expense of our intangible assets as of October 31, 2020 (in millions):

[0001327567-20-000041:notes:78]
|  | Amount |
| Fiscal years ending July 31: |  |
| Remaining 2021 | $ | 74.1 |  |
| 2022 | 94.3 |  |
| 2023 | 68.2 |  |
| 2024 | 58.2 |  |
| 2025 | 44.5 |  |
| 2026 and thereafter | 49.5 |  |
| Total future amortization expense | $ | 388.8 |  |


## us-gaap:DebtDisclosureTextBlock

[0001327567-20-000041:notes:79]
Debt
Convertible Senior Notes

[0001327567-20-000041:notes:80]
In July 2018, we issued $1.7 billion aggregate principal amount of 0.75% Convertible Senior Notes due 2023 (the “2023 Notes”) and, in June 2020, we issued $2.0 billion aggregate principal amount of 0.375% Convertible Senior Notes due 2025 (the “2025 Notes,” and together with the 2023 Notes, the “Notes”). The 2023 Notes bear interest at a fixed rate of 0.75% per year, payable semi-annually in arrears on January 1 and July 1 of each year, beginning on January 1, 2019. The 2025 Notes bear interest at a fixed rate of 0.375% per year, payable semi-annually in arrears on June 1 and December 1 of each year, beginning on December 1, 2020. Each series of the convertible notes is governed by an indenture between us, as the issuer, and U.S. Bank National Association, as Trustee (individually, each an “Indenture,” and together, the “Indentures”). The Notes of each series are unsecured, unsubordinated obligations and the applicable Indenture governing each series of Notes does not contain any financial covenants or restrictions on the payments of dividends, the incurrence of indebtedness, or the issuance or repurchase of securities by us or any of our subsidiaries. The 2023 Notes and the 2025 Notes mature on July 1, 2023 and June 1, 2025, respectively. We cannot redeem the 2023 Notes prior to maturity. We may redeem for cash all or any portion of the 2025 Notes, at our option, on or after June 5, 2023, and prior to the 31st scheduled trading day immediately preceding the maturity date if the last reported sale price of our common stock has been at least 130% of the conversion price then in effect for at least 20 trading days during any 30 consecutive trading day period ending on and including the trading day preceding the date on which we provide notice of redemption. The redemption will be at a price equal to 100% of the principal amount of the 2025 Notes and adjusted for interest. If we call any or all of the 2025 Notes for redemption, holders may convert such 2025 Notes called for redemption at any time prior to the close of business on the second scheduled trading day immediately preceding the redemption date.

[0001327567-20-000041:notes:81]
The following table presents details of our Notes (number of shares in millions):

[0001327567-20-000041:notes:82]
|  | Conversion Rate per $1,000 Principal |  | Initial Conversion Price |  | Convertible Date |  | Initial Number of Shares |
| 2023 Notes | 3.7545 |  |  | $ | 266.35 |  |  | April 1, 2023 |  | 6.4 |  |
| 2025 Notes | 3.3602 |  |  | $ | 297.60 |  |  | March 1, 2025 |  | 6.7 |  |

[0001327567-20-000041:notes:83]
Holders of the Notes may surrender their Notes for conversion at their option at any time prior to the close of business on the business day immediately preceding their respective convertible dates only under the following circumstances:

[0001327567-20-000041:notes:84]
•during any fiscal quarter commencing after the fiscal quarters ending on October 31, 2018 and October 31, 2020 for the 2023 Notes and the 2025 Notes, respectively (and only during such fiscal quarter), if the last reported sale price of our common stock for at least 20 trading days (whether or not consecutive) during a period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the applicable conversion price for the respective Notes on each applicable trading day (the “sale price condition”);

[0001327567-20-000041:notes:85]
•during the five business day period after any five consecutive trading day period (the “measurement period”) in which the trading price per $1,000 principal amount of the applicable series of Notes for each trading day of the measurement period was less than 98% of the product of the last reported sale price of our common stock and the applicable conversion rate for the respective Notes on each such trading day; or

[0001327567-20-000041:notes:86]
•upon the occurrence of specified corporate events.

[0001327567-20-000041:notes:87]
On or after the respective convertible date, holders may surrender all or any portion of their Notes for conversion at any time prior to the close of business on the second scheduled trading day immediately preceding the applicable maturity date regardless of the foregoing conditions, and such conversions will be settled upon the applicable maturity date. Upon conversion, holders of the Notes of a series will receive cash equal to the aggregate principal amount of the Notes of such series to be converted, and, at our election, cash and/or shares of our common stock for any amounts in excess of the aggregate principal amount of the Notes of such series being converted.

[0001327567-20-000041:notes:88]
The conversion price will be subject to adjustment in some events. Holders of the Notes of a series who convert their Notes of such series in connection with certain corporate events that constitute a “make-whole fundamental change” under the applicable Indenture are, under certain circumstances, entitled to an increase in the conversion rate for such series of Notes. Additionally, upon the occurrence of a corporate event that constitutes a “fundamental change” under the applicable Indenture, holders of the Notes of such series may require us to repurchase for cash all or a portion of the Notes of such series at a repurchase price equal to 100% of the principal amount of the Notes of such series plus accrued and unpaid interest to, but excluding, the fundamental change repurchase date.

[0001327567-20-000041:notes:89]
The sale price condition was not met for the Notes during the fiscal quarters ended October 31, 2020 or July 31, 2020. Since the Notes were not convertible, the net carrying amount of the Notes was classified as a long-term liability and the equity component was included in additional paid-in capital in our condensed consolidated balance sheets in the periods presented. As of October 31, 2020, all of the Notes remained outstanding.

[0001327567-20-000041:notes:90]
The following table sets forth the components of the Notes as of October 31, 2020 and July 31, 2020 (in millions):

[0001327567-20-000041:notes:91]
|  | October 31, 2020 | July 31, 2020 |
|  | 2023 Notes |  | 2025 Notes |  | Total |  | 2023 Notes |  | 2025 Notes |  | Total |
| Liability component: |  |  |  |  |  |  |  |  |  |  |  |
| Principal | $ | 1,693.0 |  |  | $ | 2,000.0 |  |  | $ | 3,693.0 |  |  | $ | 1,693.0 |  |  | $ | 2,000.0 |  |  | $ | 3,693.0 |  |
| Less: debt discount and debt issuance costs, net of amortization | 183.8 |  |  | 390.1 |  |  | 573.9 |  |  | 200.0 |  |  | 408.9 |  |  | 608.9 |  |
| Net carrying amount | $ | 1,509.2 |  |  | $ | 1,609.9 |  |  | $ | 3,119.1 |  |  | $ | 1,493.0 |  |  | $ | 1,591.1 |  |  | $ | 3,084.1 |  |
| Equity component | $ | 315.0 |  |  | $ | 403.0 |  |  | $ | 718.0 |  |  | $ | 315.0 |  |  | $ | 403.0 |  |  | $ | 718.0 |  |

[0001327567-20-000041:notes:92]
The total estimated fair value of the Notes was $3.9 billion and $4.1 billion at October 31, 2020 and July 31, 2020, respectively. The fair value was determined based on the closing trading price per $100 of the Notes as of the last day of trading for the period. We consider the fair value of the Notes at October 31, 2020 and July 31, 2020 to be a Level 2 measurement. The fair value of the Notes is primarily affected by the trading price of our common stock and market interest rates. Based on the closing price of our common stock on October 31, 2020, the if-converted value of the Notes was less than its respective principal amount.

[0001327567-20-000041:notes:93]
The following table sets forth interest expense recognized related to the Notes (dollars in millions):

[0001327567-20-000041:notes:94]
|  |  |  | Three Months Ended October 31, |
|  |  |  |  |  | 2020 |  | 2019 |
|  |  |  |  |  |  |  |  |  |  |  |  |  | 2023 Notes |  | 2025 Notes |  | Total |  | 2023 Notes |  |  |  | Total |
| Contractual interest expense |  |  |  |  |  |  |  |  |  |  |  |  | $ | 3.2 |  |  | $ | 1.9 |  |  | $ | 5.1 |  |  | $ | 3.2 |  |  |  | $ | 3.2 |  |
| Amortization of debt discount |  |  |  |  |  |  |  |  |  |  |  |  | 15.7 |  |  | 18.2 |  |  | 33.9 |  |  | 15.0 |  |  |  | 15.0 |  |
| Amortization of debt issuance costs |  |  |  |  |  |  |  |  |  |  |  |  | 0.5 |  |  | 0.7 |  |  | 1.2 |  |  | 0.5 |  |  |  | 0.5 |  |
| Total interest expense recognized |  |  |  |  |  |  |  |  |  |  |  |  | $ | 19.4 |  |  | $ | 20.8 |  |  | $ | 40.2 |  |  | $ | 18.7 |  |  |  | $ | 18.7 |  |
| Effective interest rate of the liability component |  |  |  |  |  |  |  |  |  |  |  |  | 5.2 | % |  | 5.4 | % |  |  |  | 5.2 | % |  |  |  |  |

[0001327567-20-000041:notes:95]
Note Hedges

[0001327567-20-000041:notes:96]
To minimize the impact of potential economic dilution upon conversion of our Notes, we entered into separate convertible note hedge transactions (the “2023 Note Hedges,” with respect to the 2023 Notes, the “2025 Note Hedges,” with respect to the 2025 Notes, and the 2023 Notes Hedges together with 2025 Note Hedges, the “Note Hedges”) with respect to our common stock concurrent with the issuance of each series of the Notes.

[0001327567-20-000041:notes:97]
The following table presents details of our Note Hedges (in millions):

[0001327567-20-000041:notes:98]
|  | Initial Number of Shares |  | Aggregate Purchase |
| 2023 Note Hedges | 6.4 |  |  | $ | 332.0 |  |
| 2025 Note Hedges | 6.7 |  |  | $ | 370.8 |  |

[0001327567-20-000041:notes:99]
The Note Hedges cover shares of our common stock at a strike price per share that corresponds to the initial applicable conversion price of the applicable series of the Notes, which are also subject to adjustment, and are exercisable upon conversion of the applicable series of the Notes. The Note Hedges will expire upon maturity of the applicable series of the Notes. The Note Hedges are separate transactions and are not part of the terms of the applicable series of the Notes. Holders of the Notes of either series will not have any rights with respect to the Note Hedges. Any shares of our common stock receivable by us under the Note Hedges are excluded from the calculation of diluted earnings per share as they are antidilutive. The aggregate amounts paid for the Note Hedges are included in additional paid-in capital in our condensed consolidated balance sheets.

[0001327567-20-000041:notes:100]
Warrants

[0001327567-20-000041:notes:101]
Separately, but concurrently with the issuance of each series of our Notes, we entered into transactions whereby we sold warrants (the “2023 Warrants,” with respect to the 2023 Notes, the “2025 Warrants,” with respect to the 2025 Notes, and the 2023 Warrants together with the 2025 Warrants, the “Warrants”) to acquire shares of our common stock, subject to anti-dilution adjustments. The 2023 Warrants and 2025 Warrants are exercisable beginning October 2023 and September 2025, respectively.

[0001327567-20-000041:notes:102]
The following table presents details of the Warrants (in millions, except per share data):

[0001327567-20-000041:notes:103]
|  | Initial Number of Shares |  | Strike Price per Share |  | Aggregate Proceeds |
| 2023 Warrants | 6.4 |  |  | $ | 417.80 |  |  | $ | 145.4 |  |
| 2025 Warrants | 6.7 |  |  | $ | 408.47 |  |  | $ | 202.8 |  |

[0001327567-20-000041:notes:104]
The shares issuable under the Warrants will be included in the calculation of diluted earnings per share when the average market value per share of our common stock for the reporting period exceeds the applicable strike price for such series of Warrants. The Warrants are separate transactions and are not part of either series of Notes or Note Hedges and are not remeasured through earnings each reporting period. Holders of the Notes of either series will not have any rights with respect to the Warrants. The aggregate proceeds received from the sale of the Warrants are included in additional paid-in capital in our condensed consolidated balance sheets.

[0001327567-20-000041:notes:105]
Revolving Credit Facility

[0001327567-20-000041:notes:106]
On September 4, 2018, we entered into a credit agreement (the “Credit Agreement”) with certain institutional lenders that provides for a $400.0 million unsecured revolving credit facility (the “Credit Facility”), with an option to increase the amount of the Credit Facility by up to an additional $350.0 million, subject to certain conditions. The Credit Facility matures on the earlier of (i) September 4, 2023 and (ii) the date that is 91 days prior to the stated maturity of our 2023 Notes if (a) any of the 2023 Notes are

[0001327567-20-000041:notes:107]
still outstanding and (b) our unrestricted cash and cash equivalents are less than the then outstanding principal amount of our 2023 Notes plus $400.0 million.

[0001327567-20-000041:notes:108]
The borrowings under the Credit Facility currently bear interest, at our option, at a base rate plus a spread of 0.00% to 0.75%, or an adjusted LIBO Rate plus a spread of 1.00% to 1.75%, in each case with such spread being determined based on our leverage ratio. We are obligated to pay an ongoing commitment fee on undrawn amounts at a rate of 0.125% to 0.250%, depending on our leverage ratio. Regulatory authorities that oversee financial markets have announced that after the end of 2021, they would no longer compel banks currently reporting information used to set the LIBO Rate to continue to make rate submissions. As a result, it is possible that beginning in 2022, the LIBO Rate will no longer be available as a reference rate. Under the terms of our Credit Facility, in the event of the discontinuance of the LIBO Rate, a mutually agreed-upon alternative benchmark rate will be established to replace the LIBO Rate, which may include the Secured Overnight Financing Rate (“SOFR”). We do not anticipate that the discontinuance of the LIBO Rate will materially impact our liquidity or financial position.

[0001327567-20-000041:notes:109]
As of October 31, 2020, there were no amounts outstanding and we were in compliance with all covenants under the Credit Agreement.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001327567-20-000041:notes:110]
Commitments and Contingencies
Purchase Commitments

[0001327567-20-000041:notes:111]
Manufacturing Purchase Commitments

[0001327567-20-000041:notes:112]
Our electronics manufacturing service provider (“EMS provider”) procures components and assembles our products based on our forecasts. These forecasts are based on estimates of demand for our products primarily for the next 12 months, which are in turn based on historical trends and an analysis from our sales and product management organizations, adjusted for overall market conditions. In order to reduce manufacturing lead times and plan for adequate supply, we may issue non-cancelable orders for products and components to our manufacturing partners or component suppliers. As of October 31, 2020, our purchase commitments under such orders were $140.8 million excluding obligations under contracts that we can cancel without a significant penalty.

[0001327567-20-000041:notes:113]
Other Purchase Commitments

[0001327567-20-000041:notes:114]
We have entered into various non-cancelable agreements with certain service providers, under which we are committed to minimum or fixed purchases through the year ending July 31, 2026. The following table presents details of the aggregate future non-cancelable purchase commitments under these agreements as of October 31, 2020 (in millions):

[0001327567-20-000041:notes:115]
|  | Amount |
| Fiscal years ending July 31: |  |
| Remaining 2021 | $ | — |  |
| 2022 | 159.2 |  |
| 2023 | 227.2 |  |
| 2024 | 285.7 |  |
| 2025 | 345.3 |  |
| 2026 and thereafter | 551.1 |  |
| Total other purchase commitments | $ | 1,568.5 |  |

[0001327567-20-000041:notes:116]
Litigation

[0001327567-20-000041:notes:117]
We are subject to legal proceedings, claims, and litigation arising in the ordinary course of business, including intellectual property litigation. Such matters are subject to many uncertainties and outcomes are not predictable with assurance. We accrue for contingencies when we believe that a loss is probable and that we can reasonably estimate the amount of any such loss.

[0001327567-20-000041:notes:118]
To the extent there is a reasonable possibility that a loss exceeding amounts already recognized may be incurred and the amount of such additional loss would be material, we will either disclose the estimated additional loss or state that such an estimate cannot be made. As of October 31, 2020, we have not recorded any significant accruals for loss contingencies associated with such legal proceedings, determined that an unfavorable outcome is probable or reasonably possible, or determined that the amount or range of any possible loss is reasonably estimable.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001327567-20-000041:notes:119]
[same as prior period, unchanged from 0001327567-20-000017:notes:142]

[0001327567-20-000041:notes:120]
In February 2019, our board of directors authorized a $1.0 billion share repurchase program which is funded from available working capital. Repurchases may be made at management’s discretion from time to time on the open market, through privately negotiated transactions, transactions structured through investment banking institutions, block purchase techniques, 10b5-1 trading

[0001327567-20-000041:notes:121]
plans, or a combination of the foregoing. This repurchase authorization will expire on December 31, 2020 and may be suspended or discontinued at any time.

[0001327567-20-000041:notes:122]
During the three months ended October 31, 2020, we repurchased and retired 2.1 million shares of our common stock under the authorization for an aggregate purchase price of $500.0 million, including transaction costs. The total price of the shares repurchased and related transaction costs are reflected as a reduction to common stock and additional paid-in capital on our condensed consolidated balance sheets. As of October 31, 2020, $301.9 million remained available for future share repurchases under our current repurchase authorization.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001327567-20-000041:notes:123]
[same as prior period, unchanged from 0001327567-20-000017:notes:148]

[0001327567-20-000041:notes:124]
The Crypsis Group Stock Incentive Plan

[0001327567-20-000041:notes:125]
In connection with our acquisition of Crypsis in September 2020, we assumed the Crypsis Group Holdings, LLC 2017 Equity Incentive Plan (the “Crypsis Group Plan”), under which the assumed Crypsis equity awards were granted. The assumed equity awards will be settled in shares of our common stock and will retain the terms and conditions under which they were originally granted; forfeited awards will not be returned to the Crypsis Group Plan. No additional equity awards will be granted under the Crypsis Group Plan. Refer to Note 7. Acquisition for more information on our Crypsis acquisition and the related equity awards assumed.

[0001327567-20-000041:notes:126]
Performance Stock Option (“PSO”) Activities

[0001327567-20-000041:notes:127]
There was no PSO activity under our stock plans during the three months ended October 31, 2020. As of October 31, 2020, we had 2.8 million shares of PSO outstanding and exercisable with a weighted-average exercise price per share of $194.14, a weighted-average remaining contract term of 4.9 years, and an aggregate intrinsic value of $74.8 million.

[0001327567-20-000041:notes:128]
Restricted Stock Unit (“RSU”) and Performance-Based Stock Unit (“PSU”) Activities

[0001327567-20-000041:notes:129]
[same as prior period, unchanged from 0001327567-20-000017:notes:162]

[0001327567-20-000041:notes:130]
|  | RSUs Outstanding |  | PSUs Outstanding |
|  | Number of Shares |  | Weighted-Average Grant-Date Fair Value Per Share |  |  |  | Aggregate Intrinsic Value |  | Number of Shares |  | Weighted-Average Grant-Date Fair Value Per Share |  |  |  | Aggregate Intrinsic Value |
| Balance—July 31, 2020 | 6.6 |  |  | $ | 203.30 |  |  |  |  | $ | 1,688.1 |  |  | 0.6 |  |  | $ | 231.42 |  |  |  |  | $ | 147.2 |  |
| Granted | 1.8 |  |  | $ | 241.67 |  |  |  |  |  |  | 0.4 |  |  | $ | 244.15 |  |  |  |  |  |
| Vested | (0.8) |  |  | $ | 187.16 |  |  |  |  |  |  | (0.1) |  |  | $ | 210.57 |  |  |  |  |  |
| Forfeited | (0.2) |  |  | $ | 207.01 |  |  |  |  |  |  | — |  |  | $ | 229.47 |  |  |  |  |  |
| Balance—October 31, 2020 | 7.4 |  |  | $ | 213.78 |  |  |  |  | $ | 1,644.1 |  |  | 0.9 |  |  | $ | 238.35 |  |  |  |  | $ | 196.2 |  |

[0001327567-20-000041:notes:131]
Our PSUs generally vest over a period of one to four years from the date of grant. The actual number of PSUs earned and eligible to vest is determined based on the level of achievement against revenue growth, pre-established billings and operating margin goals, or pre-defined individual performance targets for the fiscal year. We recognize share-based compensation expense for our PSUs on a straight-line basis over the requisite service period for each separately vesting portion of the award when it is probable that the performance condition will be achieved.

[0001327567-20-000041:notes:132]
[same as prior period, unchanged from 0001327567-20-000017:notes:165]

[0001327567-20-000041:notes:133]
[same as prior period, unchanged from 0001327567-20-000017:notes:166]

[0001327567-20-000041:notes:134]
|  |  |  | Three Months Ended |
|  |  |  | October 31, |
|  |  |  |  |  | 2020 |  | 2019 |
| Cost of product revenue |  |  |  |  | $ | 1.5 |  |  | $ | 1.3 |  |
| Cost of subscription and support revenue |  |  |  |  | 22.2 |  |  | 18.9 |  |
| Research and development |  |  |  |  | 95.4 |  |  | 62.4 |  |
| Sales and marketing |  |  |  |  | 64.9 |  |  | 43.8 |  |
| General and administrative |  |  |  |  | 28.9 |  |  | 24.8 |  |
| Total share-based compensation |  |  |  |  | $ | 212.9 |  |  | $ | 151.2 |  |

[0001327567-20-000041:notes:135]
During the three months ended October 31, 2020, we accelerated the vesting of certain equity awards in connection with our acquisition; as a result, we recorded $7.1 million of share-based compensation within general and administrative expense in our condensed consolidated statements of operations.

[0001327567-20-000041:notes:136]
As of October 31, 2020, total compensation cost related to unvested share-based awards not yet recognized was $1.8 billion. This cost is expected to be amortized over a weighted-average period of approximately 2.7 years. Future grants will increase the amount of compensation expense to be recorded in these periods.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001327567-20-000041:notes:137]
Income Taxes
For the three months ended October 31, 2020, our provision for income taxes reflects an effective tax rate of negative 12.0%. Our effective tax rate for the three months ended October 31, 2020 was negative as we recorded a provision for income taxes on year-to-date losses. The provision for income taxes for the three months ended October 31, 2020 was primarily due to income taxes in profitable foreign jurisdictions and withholding taxes. Our effective tax rate differs from the U.S. statutory tax rate primarily due to changes in our valuation allowance.

[0001327567-20-000041:notes:138]
Our provision for income taxes for the three months ended October 31, 2019 reflects an effective tax rate of negative 9.4%. Our effective tax rate for the three months ended October 31, 2019 was negative as we recorded a provision for income taxes on year-to-date losses. The provision for income taxes for the three months ended October 31, 2019 was primarily due to income taxes in profitable foreign jurisdictions, U.S. state taxes, and withholding taxes. Our effective tax rate differs from the U.S. statutory tax rate primarily due to deductibility of our share-based compensation, foreign income at other than U.S. tax rates, and changes in our valuation allowance.


## us-gaap:EarningsPerShareTextBlock

[0001327567-20-000041:notes:139]
[same as prior period, unchanged from 0001327567-20-000017:notes:173]

[0001327567-20-000041:notes:140]
[same as prior period, unchanged from 0001327567-20-000017:notes:174]

[0001327567-20-000041:notes:141]
|  |  |  | Three Months Ended |
|  |  |  | October 31, |
|  |  |  |  |  | 2020 |  | 2019 |
| Net loss |  |  |  |  | $ | (92.2) |  |  | $ | (59.6) |  |
| Weighted-average shares used to compute net loss per share, basic and diluted |  |  |  |  | 95.5 |  |  | 96.6 |  |
| Net loss per share, basic and diluted |  |  |  |  | $ | (0.97) |  |  | $ | (0.62) |  |

[0001327567-20-000041:notes:142]
[same as prior period, unchanged from 0001327567-20-000017:notes:176]

[0001327567-20-000041:notes:143]
|  | Three Months Ended |
|  | October 31, |
|  | 2020 |  | 2019 |
| Convertible senior notes | 13.1 |  |  | 6.4 |  |
| Warrants related to the issuance of convertible senior notes | 13.1 |  |  | 9.6 |  |
| RSUs and PSUs | 8.3 |  |  | 7.7 |  |
| Options to purchase common stock, including PSOs | 2.8 |  |  | 3.2 |  |
| Restricted stock awards and performance-based stock awards | — |  |  | 0.1 |  |
| ESPP shares | 0.1 |  |  | 0.1 |  |
| Total | 37.4 |  |  | 27.1 |  |


## us-gaap:OtherNonoperatingIncomeAndExpenseTextBlock

[0001327567-20-000041:notes:144]
[same as prior period, unchanged from 0001327567-20-000017:notes:178]

[0001327567-20-000041:notes:145]
|  |  |  | Three Months Ended |
|  |  |  | October 31, |
|  |  |  |  |  | 2020 |  | 2019 |
| Interest income |  |  |  |  | $ | 2.9 |  |  | $ | 15.8 |  |
| Foreign currency exchange gains (losses), net |  |  |  |  | 2.1 |  |  | 0.4 |  |
| Other |  |  |  |  | (2.6) |  |  | — |  |
| Total other income, net |  |  |  |  | $ | 2.4 |  |  | $ | 16.2 |  |


## us-gaap:SubsequentEventsTextBlock

[0001327567-20-000041:notes:146]
Subsequent Events
Business Combinations

[0001327567-20-000041:notes:147]
In November 2020, we entered into a definitive agreement to acquire Expanse Inc. (“Expanse”), a privately-held company specializing in attack surface management, for total consideration of approximately $800 million, including approximately $670 million in cash and common stock, and approximately $130 million in replacement equity awards, subject to adjustment. We expect the acquisition will enrich our Cortex offerings and enable organizations an integrated view of the enterprise to combine external, internal, and threat data. The acquisition is expected to close during our second quarter of fiscal 2021.

[0001327567-20-000041:notes:148]
In November 2020, we entered into a definitive agreement to acquire Sinefa Group, Inc. and its wholly owned subsidiaries (“Sinefa”), a privately-held digital experience monitoring company, for total consideration of approximately $44 million in cash, subject to adjustment. We expect the acquisition will extend our Prisma Access offering. The acquisition is expected to close during our second quarter of fiscal 2021.
