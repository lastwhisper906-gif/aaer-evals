# PANW 8-K — 0001327567-20-000037 filed 2020-11-16

## item codes, every 8-K on or before 2020-11-19

- 2020-11-16 0001327567-20-000037 — 2.02, 9.01
- 2020-11-12 0001193125-20-291707 — 3.02
- 2020-10-19 0001193125-20-272060 — 5.02
- 2020-08-24 0001327567-20-000025 — 2.02, 9.01
- 2020-06-23 0001193125-20-176553 — 5.02, 9.01
- 2020-06-22 0001193125-20-175603 — 5.02, 9.01
- 2020-06-08 0001193125-20-163579 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2020-05-21 0001327567-20-000015 — 2.02, 9.01
- 2020-02-27 0001193125-20-050335 — 1.01, 2.03
- 2020-02-24 0001327567-20-000002 — 2.02, 9.01
- 2019-12-19 0001193125-19-319166 — 1.02, 9.01
- 2019-12-10 0001193125-19-310251 — 5.07
- 2019-11-25 0001327567-19-000036 — 2.02, 9.01
- 2019-11-25 0001193125-19-299886 — 5.02, 8.01 — amendment of 0001327567-19-000011
- 2019-10-22 0001193125-19-271660 — 5.02
- 2019-09-06 0001327567-19-000026 — 9.01 — amendment of 0001327567-19-000023
- 2019-09-04 0001327567-19-000023 — 2.02, 7.01, 9.01
- 2019-07-11 0001193125-19-192415 — 5.02, 9.01
- 2019-05-29 0001327567-19-000014 — 2.02, 9.01
- 2019-04-15 0001327567-19-000011 — 5.02, 9.01
- 2019-04-01 0001193125-19-094613 — 8.01, 9.01
- 2019-03-28 0001193125-19-090572 — 3.02 — amendment of 0001327567-19-000003
- 2019-02-26 0001327567-19-000006 — 2.02, 8.01, 9.01
- 2019-02-19 0001327567-19-000003 — 3.02
- 2018-12-11 0001327567-18-000033 — 5.07
- 2018-11-29 0001327567-18-000029 — 2.02, 9.01
- 2018-10-15 0001193125-18-299312 — 5.02, 9.01
- 2018-09-25 0001193125-18-282542 — 5.02
- 2018-09-14 0001193125-18-274239 — 5.03, 9.01
- 2018-09-06 0001327567-18-000018 — 1.01, 2.02, 2.03, 9.01
- 2018-07-13 0001193125-18-217281 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2018-06-04 0001327567-18-000011 — 2.02, 5.02, 9.01
- 2018-02-26 0001327567-18-000004 — 2.02, 5.02, 7.01, 9.01
- 2017-12-12 0001193125-17-367477 — 5.07
- 2017-11-20 0001327567-17-000032 — 2.02, 5.02, 9.01
- 2017-08-31 0001327567-17-000021 — 2.02, 5.02, 9.01
- 2017-05-31 0001327567-17-000016 — 2.02, 9.01
- 2017-02-28 0001327567-17-000005 — 2.02, 8.01, 9.01
- 2016-12-12 0001193125-16-790757 — 5.07
- 2016-11-21 0001327567-16-000071 — 2.02, 9.01
- 2016-10-24 0001193125-16-745121 — 5.02, 9.01
- 2016-08-30 0001327567-16-000057 — 2.02, 5.03, 8.01, 9.01
- 2016-08-22 0001193125-16-687588 — 5.02, 9.01
- 2016-05-26 0001327567-16-000051 — 2.02, 9.01
- 2016-02-25 0001327567-16-000044 — 2.02, 5.02, 9.01
- 2015-12-14 0001327567-15-000038 — 5.07
- 2015-12-14 0001193125-15-402588 — 1.01, 9.01
- 2015-11-23 0001327567-15-000033 — 2.02, 9.01
- 2015-10-19 0001193125-15-347005 — 1.01, 9.01 — amendment, the index does not say of what
- 2015-09-09 0001327567-15-000022 — 2.02, 9.01
- 2015-08-19 0001193125-15-296115 — 1.01, 2.03
- 2015-06-01 0001193125-15-207786 — 1.01, 2.03
- 2015-05-27 0001327567-15-000015 — 2.02, 9.01
- 2015-03-02 0001327567-15-000006 — 2.02, 9.01
- 2014-12-15 0001327567-14-000046 — 5.07
- 2014-11-24 0001327567-14-000040 — 2.02, 9.01
- 2014-09-22 0001193125-14-348581 — 5.02, 9.01
- 2014-09-09 0001327567-14-000025 — 2.02, 9.01
- 2014-07-01 0001193125-14-257824 — 1.01, 2.03, 3.02, 9.01
- 2014-06-26 0001193125-14-249529 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2014-06-20 0001327567-14-000020 — 9.01 — amendment of 0001193125-14-140511
- 2014-06-04 0001327567-14-000016 — 3.02
- 2014-05-30 0001193125-14-218158 — 2.02 — amendment, the index does not say of what
- 2014-05-28 0001193125-14-215060 — 1.01, 2.02, 3.02, 9.01
- 2014-04-11 0001193125-14-140511 — 2.01, 3.02, 7.01, 9.01
- 2014-03-24 0001193125-14-111318 — 1.01, 3.02, 7.01, 9.01
- 2014-03-13 0001327567-14-000009 — 5.02
- 2014-02-24 0001193125-14-063754 — 2.02, 9.01
- 2013-12-12 0001327567-13-000040 — 5.07
- 2013-11-25 0001327567-13-000033 — 2.02, 9.01
- 2013-09-30 0001193125-13-384966 — 8.01
- 2013-09-09 0001193125-13-361421 — 2.02, 9.01
- 2013-05-30 0001193125-13-241542 — 2.02, 5.02, 9.01
- 2013-03-11 0001193125-13-101082 — 5.02, 9.01
- 2013-02-28 0001193125-13-084193 — 2.02, 9.01
- 2012-12-14 0001193125-12-503335 — 5.07
- 2012-12-06 0001193125-12-493700 — 2.02, 9.01
- 2012-09-24 0001193125-12-401534 — 1.01, 2.03
- 2012-09-20 0001193125-12-398433 — 5.02, 9.01
- 2012-09-10 0001193125-12-386605 — 2.02, 9.01

## late-filing notifications on or before 2020-11-19

- none on or before 2020-11-19

## item 2.02 — earnings release, exhibit 99.1

[0001327567-20-000037:8k_2_02:1]
EX-99.1
2
ex991q121earningsrelea.htm
EX-99.1

[0001327567-20-000037:8k_2_02:2]
Document

[0001327567-20-000037:8k_2_02:3]
Exhibit 99.1

[0001327567-20-000037:8k_2_02:4]
Palo Alto Networks Reports Fiscal First Quarter 2021 Financial Results

[0001327567-20-000037:8k_2_02:5]
•Fiscal first quarter revenue grows 23% year over year to $946.0 million

[0001327567-20-000037:8k_2_02:6]
•Fiscal first quarter billings grows 21% year over year to $1.1 billion

[0001327567-20-000037:8k_2_02:7]
•Deferred revenue grows 31% year over year to $3.9 billion

[0001327567-20-000037:8k_2_02:8]
SANTA CLARA, Calif. - November 16, 2020 - Palo Alto Networks (NYSE: PANW), the global cybersecurity leader, announced today financial results for its fiscal first quarter 2021, ended October 31, 2020.

[0001327567-20-000037:8k_2_02:9]
Total revenue for the fiscal first quarter 2021 grew 23% year over year to $946.0 million, compared with total revenue of $771.9 million for the fiscal first quarter 2020. GAAP net loss for the fiscal first quarter 2021 was $92.2 million, or $0.97 per diluted share, compared with GAAP net loss of $59.6 million, or $0.62 per diluted share, for the fiscal first quarter 2020.

[0001327567-20-000037:8k_2_02:10]
Non-GAAP net income for the fiscal first quarter 2021 was $158.1 million, or $1.62 per diluted share, compared with non-GAAP net income of $104.8 million, or $1.05 per diluted share, for the fiscal first quarter 2020. A reconciliation between GAAP and non-GAAP information is contained in the tables below.

[0001327567-20-000037:8k_2_02:11]
“We delivered another consecutive strong quarter of solid results, with first quarter billings of 21% year-over-year growth; both our firewall transformation and our Next-Generation Security services continue to make great progress, giving us confidence to raise previously issued guidance for the year,” said Nikesh Arora, chairman and CEO of Palo Alto Networks. “We introduced several significant product enhancements across the portfolio and were recognized by industry analysts as a leader in two Gartner Magic Quadrants as well as Zero Trust. Additionally, we are excited about our proposed acquisition of Expanse, Inc., which we announced last week.”

[0001327567-20-000037:8k_2_02:12]
Financial Outlook

[0001327567-20-000037:8k_2_02:13]
Palo Alto Networks provides guidance based on current market conditions and expectations.

[0001327567-20-000037:8k_2_02:14]
For the fiscal second quarter 2021, we expect:

[0001327567-20-000037:8k_2_02:15]
•Total billings in the range of $1.17 billion to $1.19 billion, representing year-over-year growth of between 17% and 19%.

[0001327567-20-000037:8k_2_02:16]
•Total revenue in the range of $975 million to $990 million, representing year-over-year growth of between 19% and 21%.

[0001327567-20-000037:8k_2_02:17]
•Diluted non-GAAP net income per share in the range of $1.42 to $1.44, using 98 million to 100 million shares.

[0001327567-20-000037:8k_2_02:18]
For the fiscal year 2021, we are raising guidance and expect:

[0001327567-20-000037:8k_2_02:19]
•Total billings in the range of $5.08 billion to $5.13 billion, representing year-over-year growth of between 18% and 19%.

[0001327567-20-000037:8k_2_02:20]
•Total revenue in the range of $4.09 billion to $4.14 billion, representing year-over-year growth of between 20% and 21%.

[0001327567-20-000037:8k_2_02:21]
•Diluted non-GAAP net income per share in the range of $5.70 to $5.80, using 99 million to 101 million shares.

[0001327567-20-000037:8k_2_02:22]
•Adjusted free cash flow margin of approximately 29%.

[0001327567-20-000037:8k_2_02:23]
Our fiscal year 2021 guidance includes the expected impact from the proposed acquisition of Expanse, Inc. We expect Expanse to contribute approximately 100 basis points of billings growth and approximately 50 basis points of revenue growth, after acquisition accounting adjustments.

[0001327567-20-000037:8k_2_02:24]
Guidance for non-GAAP financial measures excludes share-based compensation-related charges, including share-based payroll tax expense, acquisition-related costs, amortization expense of acquired intangible assets, litigation-related charges, including legal settlements, gains (losses) related to facility exit, non-cash charges related to convertible notes, foreign currency gains (losses), and income and other tax effects associated with these items, along with certain non-recurring expenses. We have not reconciled diluted non-GAAP net income per share guidance to GAAP net income (loss) per diluted share because we do not provide guidance on GAAP net income (loss) and would not be able to present the various reconciling cash and non-cash items between GAAP net income (loss) and non-GAAP net income, including share-based compensation expense, without unreasonable effort. Share-based compensation expense is impacted by the company's future hiring and retention needs and, to a lesser extent, the future fair market value of the company's common stock, all of which is difficult to predict and subject to

[0001327567-20-000037:8k_2_02:25]
constant change. The actual amounts of such reconciling items will have a significant impact on the company's GAAP net income (loss) per diluted share.

[0001327567-20-000037:8k_2_02:26]
Earnings Call Information

[0001327567-20-000037:8k_2_02:27]
Palo Alto Networks will host a video webcast for analysts and investors to discuss the company’s fiscal first quarter 2021 results as well as the outlook for its fiscal second quarter 2021 today at 8:00 a.m. Eastern time/5:00 a.m. Pacific time. Open to the public, investors may access the webcast, supplemental financial information and earnings slides from the “Investors” section of the company’s website at investors.paloaltonetworks.com. A replay will be available three hours after the conclusion of the webcast and archived for one year.

[0001327567-20-000037:8k_2_02:28]
Forward-Looking Statements

[0001327567-20-000037:8k_2_02:29]
This press release contains forward-looking statements that involve risks, uncertainties, and assumptions including statements regarding our financial outlook for the fiscal second quarter 2021 and fiscal year 2021, including the expected impact of our proposed acquisition of Expanse, Inc., and our proposed acquisition of Expanse, including the timing of the closing and the benefits to us and our end-customers once the transaction closes and we integrate Expanse into our operations. There are a significant number of factors that could cause actual results to differ materially from statements made in this press release, including: developments and changes in general market, political, economic, and business conditions; the duration and global impact of COVID-19, including the timeframes for and severity of social distancing and other mitigation requirements, the impact of COVID-19 on our customers’ purchasing decisions; our ability as an organization to acquire and integrate other companies, products or technologies in a successful manner; risks associated with managing our growth; the risks associated with new products and subscription and support offerings, including the discovery of software bugs; our competitive position; our ability to attract and retain new customers; shift in priorities or delays in the development or release of new subscription offerings, or the failure to timely develop and achieve market acceptance of new products and subscriptions as well as existing products and subscription and support offerings; rapidly evolving technological developments in the market for security products and subscription and support offerings; and length of sales cycles.

[0001327567-20-000037:8k_2_02:30]
Additional risks and uncertainties that could affect our financial results are included under the captions “Risk Factors” and “Management’s Discussion and Analysis of Financial Condition and Results of Operations” in our Annual Report on Form 10-K filed with the SEC on September 4,

[0001327567-20-000037:8k_2_02:31]
3

[0001327567-20-000037:8k_2_02:32]
2020, which is available on our website at investors.paloaltonetworks.com and on the SEC’s website at www.sec.gov. Additional information will also be set forth in other filings that we make with the SEC from time to time. All forward-looking statements in this press release are based on information available to us as of the date hereof, and we do not assume any obligation to update the forward-looking statements provided to reflect events that occur or circumstances that exist after the date on which they were made.

[0001327567-20-000037:8k_2_02:33]
Non-GAAP Financial Measures and Other Key Metrics

[0001327567-20-000037:8k_2_02:34]
Palo Alto Networks has provided in this press release financial information that has not been prepared in accordance with generally accepted accounting principles in the United States (GAAP). The company uses these non-GAAP financial measures and other key metrics internally in analyzing its financial results and believes that the use of these non-GAAP financial measures and key metrics are useful to investors as an additional tool to evaluate ongoing operating results and trends, and in comparing the company’s financial results with other companies in its industry, many of which present similar non-GAAP financial measures or key metrics.

[0001327567-20-000037:8k_2_02:35]
The presentation of these non-GAAP financial measures and key metrics are not meant to be considered in isolation or as a substitute for comparable GAAP financial measures and should be read only in conjunction with the company’s consolidated financial statements prepared in accordance with GAAP. A reconciliation of the company’s historical non-GAAP financial measures to their most directly comparable GAAP measures has been provided in the financial statement tables included in this press release, and investors are encouraged to review these reconciliations.

[0001327567-20-000037:8k_2_02:36]
Non-GAAP net income and net income per share, diluted. Palo Alto Networks defines non-GAAP net income as net income (loss) plus share-based compensation-related charges, including share-based payroll tax expense, acquisition-related costs, amortization expense of acquired intangible assets, litigation-related charges, including legal settlements, gains (losses) related to facility exit, non-cash charges related to convertible notes, and intellectual property restructuring-related charges. The company also excludes from non-GAAP net income the foreign currency gains (losses) and tax effects associated with these items in order to provide a complete picture of the company’s recurring core business operating results. The company defines non-GAAP net income per share, diluted, as non-GAAP net income divided by the weighted-average diluted shares outstanding, which includes the potentially dilutive effect of the company’s employee equity incentive plan awards and the company’s convertible senior notes outstanding and related

[0001327567-20-000037:8k_2_02:37]
warrants, after giving effect to the anti-dilutive impact of the company’s note hedge agreements, which reduces the potential economic dilution that otherwise would occur upon conversion of the company’s convertible senior notes. Under GAAP, the anti-dilutive impact of the note hedge is not reflected in diluted shares outstanding. The company believes that excluding these items from non-GAAP net income and net income per share, diluted, provides management and investors with greater visibility into the underlying performance of the company’s core business operating results, meaning its operating performance excluding these items and, from time to time, other discrete charges that are infrequent in nature, over multiple periods.

[0001327567-20-000037:8k_2_02:38]
Billings. Palo Alto Networks defines billings as total revenue plus the change in total deferred revenue, net of acquired deferred revenue, during the period. The company considers billings to be a key metric used by management to manage the company's business given the company's hybrid-SaaS revenue model, and believes billings provides investors with an important indicator of the health and visibility of the company's business because it includes subscription and support revenue, which is recognized ratably over the contractual service period, and product revenue, which is recognized at the time of shipment, provided that all other conditions for revenue recognition have been met. The company considers billings to be a useful metric for management and investors, particularly if sales of subscriptions continue to increase and the company experiences strong renewal rates for subscriptions and support.

[0001327567-20-000037:8k_2_02:39]
Investors are cautioned that there are a number of limitations associated with the use of non-GAAP financial measures and key metrics as analytical tools. In particular, the billings metric reported by the company includes amounts that have not yet been recognized as revenue. Additionally, many of the adjustments to the company’s GAAP financial measures reflect the exclusion of items that are recurring and will be reflected in the company’s financial results for the foreseeable future, such as share-based compensation, which is an important part of Palo Alto Networks employees’ compensation and impacts their performance. Furthermore, these non-GAAP financial measures are not based on any standardized methodology prescribed by GAAP, and the components that Palo Alto Networks excludes in its calculation of non-GAAP financial measures may differ from the components that its peer companies exclude when they report their non-GAAP results of operations. Palo Alto Networks compensates for these limitations by providing specific information regarding the GAAP amounts excluded from these non-GAAP financial measures. In the future, the company may also exclude non-recurring expenses and other expenses that do not reflect the company’s core business operating results.

[0001327567-20-000037:8k_2_02:40]
5

[0001327567-20-000037:8k_2_02:41]
About Palo Alto Networks

[0001327567-20-000037:8k_2_02:42]
Palo Alto Networks, the global cybersecurity leader, is shaping the cloud-centric future with technology that is transforming the way people and organizations operate. Our mission is to be the cybersecurity partner of choice, protecting our digital way of life. We help address the world's greatest security challenges with continuous innovation that seizes the latest breakthroughs in artificial intelligence, analytics, automation, and orchestration. By delivering an integrated platform and empowering a growing ecosystem of partners, we are at the forefront of protecting tens of thousands of organizations across clouds, networks, and mobile devices. Our vision is a world where each day is safer and more secure than the one before. For more information, visit www.paloaltonetworks.com.

[0001327567-20-000037:8k_2_02:43]
Palo Alto Networks, and the Palo Alto Networks logo are trademarks of Palo Alto Networks, Inc. in the United States and in jurisdictions throughout the world. All other trademarks, trade names, or service marks used or mentioned herein belong to their respective owners.

[0001327567-20-000037:8k_2_02:44]
Media Contact:

[0001327567-20-000037:8k_2_02:45]
Mara Mort

[0001327567-20-000037:8k_2_02:46]
Senior Director of Corporate Communications, Palo Alto Networks

[0001327567-20-000037:8k_2_02:47]
Mobile: 1-415-850-8645

[0001327567-20-000037:8k_2_02:48]
mmort@paloaltonetworks.com

[0001327567-20-000037:8k_2_02:49]
Investor Relations Contact:

[0001327567-20-000037:8k_2_02:50]
Karen Fung

[0001327567-20-000037:8k_2_02:51]
Senior Director of Investor Relations, Palo Alto Networks

[0001327567-20-000037:8k_2_02:52]
Office: 1-408-638-3296

[0001327567-20-000037:8k_2_02:53]
kfung@paloaltonetworks.com

[0001327567-20-000037:8k_2_02:54]
| Palo Alto Networks, Inc. |
| Preliminary Condensed Consolidated Statements of Operations |
| (In millions, except per share data) |
| (Unaudited) |
|  |  |  |  |  | Three Months Ended |
|  |  |  | October 31, |
|  |  |  |  |  | 2020 |  | 2019 |
| Revenue: |  |  |  |  |  |  |  |
| Product |  |  |  |  | $ | 237.3 |  |  | $ | 231.2 |  |
| Subscription and support |  |  |  |  | 708.7 |  |  | 540.7 |  |
| Total revenue |  |  |  |  | 946.0 |  |  | 771.9 |  |
| Cost of revenue: |  |  |  |  |  |  |  |
| Product |  |  |  |  | 62.2 |  |  | 65.1 |  |
| Subscription and support |  |  |  |  | 215.6 |  |  | 152.6 |  |
| Total cost of revenue |  |  |  |  | 277.8 |  |  | 217.7 |  |
| Total gross profit |  |  |  |  | 668.2 |  |  | 554.2 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development |  |  |  |  | 237.4 |  |  | 170.5 |  |
| Sales and marketing |  |  |  |  | 388.6 |  |  | 365.7 |  |
| General and administrative |  |  |  |  | 86.7 |  |  | 69.8 |  |
| Total operating expenses |  |  |  |  | 712.7 |  |  | 606.0 |  |
| Operating loss |  |  |  |  | (44.5) |  |  | (51.8) |  |
| Interest expense |  |  |  |  | (40.2) |  |  | (18.9) |  |
| Other income, net |  |  |  |  | 2.4 |  |  | 16.2 |  |
| Loss before income taxes |  |  |  |  | (82.3) |  |  | (54.5) |  |
| Provision for income taxes |  |  |  |  | 9.9 |  |  | 5.1 |  |
| Net loss |  |  |  |  | $ | (92.2) |  |  | $ | (59.6) |  |
| Net loss per share, basic and diluted |  |  |  |  | $ | (0.97) |  |  | $ | (0.62) |  |
| Weighted-average shares used to compute net loss per share, basic and diluted |  |  |  |  | 95.5 |  |  | 96.6 |  |

[0001327567-20-000037:8k_2_02:55]
7

[0001327567-20-000037:8k_2_02:56]
| Palo Alto Networks, Inc. |
| Reconciliation of GAAP to Non-GAAP Financial Measures |
| (In millions, except per share amounts) |
| (Unaudited) |
|  |  |  | Three Months Ended |
|  |  |  | October 31, |
|  |  |  |  |  | 2020 |  | 2019 |
| GAAP net loss |  |  |  |  | $ | (92.2) |  |  | $ | (59.6) |  |
| Share-based compensation-related charges |  |  |  |  | 211.5 |  |  | 153.7 |  |
| Acquisition-related costs(1) |  |  |  |  | 13.1 |  |  | 3.4 |  |
| Amortization expense of acquired intangible assets |  |  |  |  | 23.5 |  |  | 16.7 |  |
| Litigation-related charges(2) |  |  |  |  | 1.8 |  |  | — |  |
| Non-cash charges related to convertible notes(3) |  |  |  |  | 35.1 |  |  | 15.5 |  |
| Foreign currency gain associated with non-GAAP adjustments |  |  |  |  | (0.1) |  |  | (0.5) |  |
| Income tax and other tax adjustments related to the above |  |  |  |  | (34.6) |  |  | (24.4) |  |
| Non-GAAP net income |  |  |  |  | $ | 158.1 |  |  | $ | 104.8 |  |
| GAAP net loss per share, diluted |  |  |  |  | $ | (0.97) |  |  | $ | (0.62) |  |
| Share-based compensation-related charges |  |  |  |  | 2.17 |  |  | 1.56 |  |
| Acquisition-related costs(1) |  |  |  |  | 0.14 |  |  | 0.04 |  |
| Amortization expense of acquired intangible assets |  |  |  |  | 0.25 |  |  | 0.17 |  |
| Litigation-related charges(2) |  |  |  |  | 0.02 |  |  | 0.00 |  |
| Non-cash charges related to convertible notes(3) |  |  |  |  | 0.37 |  |  | 0.16 |  |
| Foreign currency (gain) loss associated with non-GAAP adjustments |  |  |  |  | 0.00 |  |  | (0.01) |  |
| Income tax and other tax adjustments related to the above |  |  |  |  | (0.36) |  |  | (0.25) |  |
| Non-GAAP net income per share, diluted |  |  |  |  | $ | 1.62 |  |  | $ | 1.05 |  |
| GAAP weighted-average shares used to compute net loss per share, diluted |  |  |  |  | 95.5 |  |  | 96.6 |  |
| Weighted-average effect of potentially dilutive securities(4) |  |  |  |  | 2.2 |  |  | 3.5 |  |
| Non-GAAP weighted-average shares used to compute net income per share, diluted |  |  |  |  | 97.7 |  |  | 100.1 |  |

[0001327567-20-000037:8k_2_02:57]
(1)    Consists of acquisition transaction costs, share-based compensation related to the cash settlement of certain equity awards, and costs to terminate certain employment, operating lease, and other contracts of the acquired companies.

[0001327567-20-000037:8k_2_02:58]
(2)    Consists of the amortization of intellectual property licenses and covenant not to sue.

[0001327567-20-000037:8k_2_02:59]
(3)    Consists primarily of non-cash interest expense related to the company’s convertible senior notes.

[0001327567-20-000037:8k_2_02:60]
(4)    Non-GAAP net income per share, diluted, includes the potentially dilutive effect of employee equity incentive plan awards and convertible senior notes outstanding and related warrants. In addition, non-GAAP net income per share, diluted includes the anti-dilutive impact of the company’s note hedge agreements.

[0001327567-20-000037:8k_2_02:61]
8

[0001327567-20-000037:8k_2_02:62]
| Palo Alto Networks, Inc. |
| Calculation of Billings |
| (In millions) |
| (Unaudited) |
|  |  |  | Three Months Ended |
|  |  |  | October 31, |
|  |  |  |  |  | 2020 |  | 2019 |
| Total revenue |  |  |  |  | $ | 946.0 |  |  | $ | 771.9 |  |
| Add: change in total deferred revenue, net of acquired deferred revenue |  |  |  |  | 136.8 |  |  | 125.5 |  |
| Billings |  |  |  |  | $ | 1,082.8 |  |  | $ | 897.4 |  |

[0001327567-20-000037:8k_2_02:63]
9

[0001327567-20-000037:8k_2_02:64]
| Palo Alto Networks, Inc. |
| Preliminary Condensed Consolidated Balance Sheets |
| (In millions) |
| (Unaudited) |
|  | October 31, 2020 |  | July 31, 2020 |
| Assets |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 2,142.0 |  |  | $ | 2,958.0 |  |
| Short-term investments | 1,075.6 |  |  | 789.8 |  |
| Accounts receivable, net | 675.5 |  |  | 1,037.1 |  |
| Prepaid expenses and other current assets | 407.8 |  |  | 344.3 |  |
| Total current assets | 4,300.9 |  |  | 5,129.2 |  |
| Property and equipment, net | 337.9 |  |  | 348.1 |  |
| Operating lease right-of-use assets | 251.2 |  |  | 258.7 |  |
| Long-term investments | 873.2 |  |  | 554.4 |  |
| Goodwill | 1,968.6 |  |  | 1,812.9 |  |
| Intangible assets, net | 388.8 |  |  | 358.2 |  |
| Other assets | 605.9 |  |  | 603.9 |  |
| Total assets | $ | 8,726.5 |  |  | $ | 9,065.4 |  |
| Liabilities and stockholders’ equity |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 48.5 |  |  | $ | 63.6 |  |
| Accrued compensation | 188.4 |  |  | 322.2 |  |
| Accrued and other liabilities | 260.7 |  |  | 256.8 |  |
| Deferred revenue | 2,137.5 |  |  | 2,049.1 |  |
| Total current liabilities | 2,635.1 |  |  | 2,691.7 |  |
| Convertible senior notes, net | 3,119.2 |  |  | 3,084.1 |  |
| Long-term deferred revenue | 1,809.3 |  |  | 1,761.1 |  |
| Long-term operating lease liabilities | 323.9 |  |  | 336.6 |  |
| Other long-term liabilities | 92.0 |  |  | 90.1 |  |
| Stockholders’ equity: |  |  |  |
| Preferred stock | — |  |  | — |  |
| Common stock and additional paid-in capital | 2,003.9 |  |  | 2,259.2 |  |
| Accumulated other comprehensive income | 3.2 |  |  | 10.5 |  |
| Accumulated deficit | (1,260.1) |  |  | (1,167.9) |  |
| Total stockholders’ equity | 747.0 |  |  | 1,101.8 |  |
| Total liabilities and stockholders’ equity | $ | 8,726.5 |  |  | $ | 9,065.4 |  |

[0001327567-20-000037:8k_2_02:65]
10
