# PANW note change history — 0001327567-20-000017 → 0001327567-20-000041


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2020-11-19):
[0001327567-20-000041:note_history:1]
Our electronics manufacturing service provider (“EMS provider”) procures components and assembles our products based on our forecasts. These forecasts are based on estimates of demand for our products primarily for the next 12 months, which are in turn based on historical trends and an analysis from our sales and product management organizations, adjusted for overall market conditions. In order to reduce manufacturing lead times and plan for adequate supply, we may issue non-cancelable orders for products and components to our manufacturing partners or component suppliers. As of October 31, 2020, our purchase commitments under such orders were $140.8 million excluding obligations under contracts that we can cancel without a significant penalty.
  (was, 2020-05-22, similarity 0.9919):
[0001327567-20-000017:note_history:1]
Our electronics manufacturing service provider (“EMS provider”) procures components and assembles our products based on our forecasts. These forecasts are based on estimates of demand for our products primarily for the next 12 months, which are in turn based on historical trends and an analysis from our sales and product management organizations, adjusted for overall market conditions. In order to reduce manufacturing lead times and plan for adequate supply, we may issue non-cancelable orders for products and components to our manufacturing partners or component suppliers. As of April 30, 2020, our purchase commitments under such orders were $124.3 million excluding obligations under contracts that we can cancel without a significant penalty.

- changed (2020-11-19):
[0001327567-20-000041:note_history:2]
We have entered into various non-cancelable agreements with certain service providers, under which we are committed to minimum or fixed purchases through the year ending July 31, 2026. The following table presents details of the aggregate future non-cancelable purchase commitments under these agreements as of October 31, 2020 (in millions):
  (was, 2020-05-22, similarity 0.8636):
[0001327567-20-000017:note_history:2]
We have entered into various non-cancelable agreements with third-party providers for our use of certain cloud and other services, under which we are committed to minimum or fixed purchases through the year ending July 31, 2026. The following table presents details of the aggregate future non-cancelable purchase commitments under these agreements as of April 30, 2020 (in millions):

- changed (2020-11-19):
[0001327567-20-000041:note_history:3]
|  | Amount |
| Fiscal years ending July 31: |  |
| Remaining 2021 | $ | — |  |
| 2022 | 159.2 |  |
| 2023 | 227.2 |  |
| 2024 | 285.7 |  |
| 2025 | 345.3 |  |
| 2026 and thereafter | 551.1 |  |
| Total other purchase commitments | $ | 1,568.5 |  |
  (was, 2020-05-22, similarity 0.9948):
[0001327567-20-000017:note_history:3]
|  | Amount |
| Fiscal years ending July 31: |  |
| Remaining 2020 | $ | 1.7 |  |
| 2021 | 11.7 |  |
| 2022 | 49.8 |  |
| 2023 | 58.5 |  |
| 2024 | 67.5 |  |
| 2025 and thereafter | 97.5 |  |
| Total other purchase commitments | $ | 286.7 |  |

- changed (2020-11-19):
[0001327567-20-000041:note_history:4]
To the extent there is a reasonable possibility that a loss exceeding amounts already recognized may be incurred and the amount of such additional loss would be material, we will either disclose the estimated additional loss or state that such an estimate cannot be made. As of October 31, 2020, we have not recorded any significant accruals for loss contingencies associated with such legal proceedings, determined that an unfavorable outcome is probable or reasonably possible, or determined that the amount or range of any possible loss is reasonably estimable.
  (was, 2020-05-22, similarity 0.9892):
[0001327567-20-000017:note_history:4]
To the extent there is a reasonable possibility that a loss exceeding amounts already recognized may be incurred and the amount of such additional loss would be material, we will either disclose the estimated additional loss or state that such an estimate cannot be made. As of April 30, 2020, we have not recorded any significant accruals for loss contingencies associated with such legal proceedings, determined that an unfavorable outcome is probable or reasonably possible, or determined that the amount or range of any possible loss is reasonably estimable.

- removed (2020-11-19):
[0001327567-20-000017:note_history:5]
Mutual Covenant Not to Sue and Release Agreement

- removed (2020-11-19):
[0001327567-20-000017:note_history:6]
In January 2020, we executed a Mutual Covenant Not to Sue and Release Agreement for $50.0 million, to extend an existing covenant not to sue for seven years. As the primary benefit of the arrangement was attributable to future use, the amount was recorded in other assets on our condensed consolidated balance sheets and is amortized to cost of product revenue in our condensed consolidated statements of operations over the estimated period of benefit of seven years. This amount was paid in the three months ended April 30, 2020.


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: no_current_note, score: 0.0

- removed (2020-11-19):
[0001327567-20-000017:note_history:7]
Description of Business and Summary of Significant Accounting Policies 
Description of Business

- removed (2020-11-19):
[0001327567-20-000017:note_history:8]
Palo Alto Networks, Inc. (the “Company,” “we,” “us,” or “our”), located in Santa Clara, California, was incorporated in March 2005 under the laws of the State of Delaware and commenced operations in April 2005. We offer platforms that empower enterprises, service providers, and government entities to secure their organizations by safely enabling applications and data running in their networks, on their endpoints, and in the cloud, and by preventing breaches that stem from targeted cyberattacks.

- removed (2020-11-19):
[0001327567-20-000017:note_history:9]
Basis of Presentation and Principles of Consolidation

- removed (2020-11-19):
[0001327567-20-000017:note_history:10]
The accompanying condensed consolidated financial statements have been prepared in conformity with U.S. generally accepted accounting principles (“GAAP”), consistent in all material respects with those applied in our Annual Report on Form 10-K for the fiscal year ended July 31, 2019, filed with the Securities and Exchange Commission (“SEC”) on September 9, 2019. Our condensed consolidated financial statements include our accounts and our wholly owned subsidiaries. All significant intercompany balances and transactions have been eliminated in consolidation.

- removed (2020-11-19):
[0001327567-20-000017:note_history:11]
Our condensed consolidated financial statements are unaudited, but include all adjustments of a normal recurring nature necessary for a fair presentation of our quarterly results. We have made estimates and judgments affecting the amounts reported in our condensed consolidated financial statements and the accompanying notes. The actual results that we experience may differ materially from our estimates.

- removed (2020-11-19):
[0001327567-20-000017:note_history:12]
Certain prior period amounts have been reclassified to conform to our current period presentation.

- removed (2020-11-19):
[0001327567-20-000017:note_history:13]
Our condensed consolidated financial statements should be read in conjunction with the audited consolidated financial statements and related notes in our Annual Report on Form 10-K for the fiscal year ended July 31, 2019.

- removed (2020-11-19):
[0001327567-20-000017:note_history:14]
Use of Estimates

- removed (2020-11-19):
[0001327567-20-000017:note_history:15]
The preparation of condensed consolidated financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the consolidated financial statements and the reported amounts of revenues and expenses during the reporting period. We base our estimates on historical experience and also on assumptions that we believe are reasonable. Actual results could differ materially from those estimates due to risks and uncertainties, including uncertainty in the current economic environment due to the recent outbreak of COVID-19.

- removed (2020-11-19):
[0001327567-20-000017:note_history:16]
Summary of Significant Accounting Policies

- removed (2020-11-19):
[0001327567-20-000017:note_history:17]
There have been no material changes to our significant accounting policies as of and for the nine months ended April 30, 2020, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended July 31, 2019, except for the change in our accounting policies for leases due to our adoption of new lease accounting guidance. Refer to “Recently Adopted Accounting Pronouncements” below and Note 10. Leases and Other Office Facilities.

- removed (2020-11-19):
[0001327567-20-000017:note_history:18]
Recently Adopted Accounting Pronouncements

- removed (2020-11-19):
[0001327567-20-000017:note_history:19]
Leases

- removed (2020-11-19):
[0001327567-20-000017:note_history:20]
In February 2016, the Financial Accounting Standards Board (“FASB”) issued new authoritative guidance on lease accounting. Among its provisions, the standard requires lessees to recognize right-of-use assets and lease liabilities on the balance sheet for operating leases and also requires additional qualitative and quantitative disclosures about lease arrangements.

- removed (2020-11-19):
[0001327567-20-000017:note_history:21]
We adopted this standard effective August 1, 2019 on a modified retrospective basis, under which financial results reported in periods prior to fiscal 2020 were not adjusted. We elected the package of practical expedients, which allowed us to carry forward our historical assessments of whether contracts are or contain leases, lease classification, and initial direct costs. Additionally, we elected to account for lease and non-lease components as a single lease component and to not recognize right-of-use assets and lease liabilities for leases with a term of 12 months or less.

- removed (2020-11-19):
[0001327567-20-000017:note_history:22]
The most significant impact of adopting this guidance was the recognition of $286.4 million of operating lease right-of-use assets and $442.4 million of operating lease liabilities on our condensed consolidated balance sheet as of August 1, 2019, which included reclassifying previously recognized $129.0 million in lease incentives, deferred or prepaid rent, as well as $27.0 million in cease-use liabilities to operating lease right-of-use assets.

- removed (2020-11-19):
[0001327567-20-000017:note_history:23]
The adoption of this standard had no impact on our condensed consolidated statements of operations and condensed consolidated statements of cash flows. Refer to Note 10. Leases and Other Office Facilities for further discussion.

- removed (2020-11-19):
[0001327567-20-000017:note_history:24]
Recently Issued Accounting Pronouncements

- removed (2020-11-19):
[0001327567-20-000017:note_history:25]
Financial Instruments - Credit Losses

- removed (2020-11-19):
[0001327567-20-000017:note_history:26]
In June 2016, the FASB issued new authoritative guidance on the accounting for credit losses on most financial assets and certain financial instruments. The standard replaces the existing incurred loss model with an expected credit loss model for financial assets measured at amortized cost, including trade receivables, and requires that credit losses on available-for-sale debt securities be presented as an allowance rather than as a write-down. The standard is effective for us in our first quarter of fiscal 2021 and will be applied on a modified retrospective basis. We are currently evaluating whether this standard will have a material impact on our condensed consolidated financial statements.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2020-11-19):
[0001327567-20-000041:note_history:27]
Description of Business and Summary of Significant Accounting Policies 
Description of Business

- changed (2020-11-19):
[0001327567-20-000041:note_history:28]
Palo Alto Networks, Inc. (the “Company,” “we,” “us,” or “our”), located in Santa Clara, California, was incorporated in March 2005 under the laws of the State of Delaware and commenced operations in April 2005. We empower enterprises, service providers, and government entities to secure all users, applications, data, networks, and devices with comprehensive context at all times, across all locations.
  (was, 2020-05-22, similarity 0.6667):
[0001327567-20-000017:note_history:28]
Palo Alto Networks, Inc. (the “Company,” “we,” “us,” or “our”), located in Santa Clara, California, was incorporated in March 2005 under the laws of the State of Delaware and commenced operations in April 2005. We offer platforms that empower enterprises, service providers, and government entities to secure their organizations by safely enabling applications and data running in their networks, on their endpoints, and in the cloud, and by preventing breaches that stem from targeted cyberattacks.

- changed (2020-11-19):
[0001327567-20-000041:note_history:29]
Our condensed consolidated financial statements are unaudited, but include all adjustments of a normal recurring nature necessary for a fair presentation of our quarterly results. Our condensed consolidated financial statements should be read in conjunction with the audited consolidated financial statements and related notes in our Annual Report on Form 10-K for the fiscal year ended July 31, 2020.
  (was, 2020-05-22, similarity 0.7039):
[0001327567-20-000017:note_history:29]
Our condensed consolidated financial statements should be read in conjunction with the audited consolidated financial statements and related notes in our Annual Report on Form 10-K for the fiscal year ended July 31, 2019.

- changed (2020-11-19):
[0001327567-20-000041:note_history:30]
The preparation of condensed consolidated financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the consolidated financial statements and the reported amounts of revenues and expenses during the reporting period. We base our estimates on historical experience and also on assumptions that we believe are reasonable. Actual results could differ materially from those estimates due to risks and uncertainties, including uncertainty in the current economic environment due to COVID-19.
  (was, 2020-05-22, similarity 0.9826):
[0001327567-20-000017:note_history:30]
The preparation of condensed consolidated financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the consolidated financial statements and the reported amounts of revenues and expenses during the reporting period. We base our estimates on historical experience and also on assumptions that we believe are reasonable. Actual results could differ materially from those estimates due to risks and uncertainties, including uncertainty in the current economic environment due to the recent outbreak of COVID-19.

- changed (2020-11-19):
[0001327567-20-000041:note_history:31]
There have been no material changes to our significant accounting policies as of and for the three months ended October 31, 2020, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended July 31, 2020, except for the change in our accounting policies for credit losses due to our adoption of the new credit losses guidance. Refer to “Recently Adopted Accounting Pronouncements” below.
  (was, 2020-05-22, similarity 0.8199):
[0001327567-20-000017:note_history:31]
There have been no material changes to our significant accounting policies as of and for the nine months ended April 30, 2020, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended July 31, 2019, except for the change in our accounting policies for leases due to our adoption of new lease accounting guidance. Refer to “Recently Adopted Accounting Pronouncements” below and Note 10. Leases and Other Office Facilities.

- added (2020-11-19):
[0001327567-20-000041:note_history:32]
Recently Adopted Accounting Pronouncements

- added (2020-11-19):
[0001327567-20-000041:note_history:33]
Credit Losses

- added (2020-11-19):
[0001327567-20-000041:note_history:34]
In June 2016, the Financial Accounting Standards Board (“FASB”) issued new authoritative guidance on the accounting for credit losses on most financial assets and certain financial instruments. The standard replaces the incurred loss model with an expected credit loss model for financial assets measured at amortized cost, including trade accounts receivables and financing receivables. Credit losses on available-for-sale debt securities are required to be recorded through an allowance rather than as a write-down.

- added (2020-11-19):
[0001327567-20-000041:note_history:35]
We adopted this standard in our first quarter of fiscal 2021 using the modified-retrospective approach. The adoption of this standard did not have a material impact on our condensed consolidated financial statements. We updated the following accounting policies as a result of the adoption of this guidance.

- added (2020-11-19):
[0001327567-20-000041:note_history:36]
Cash, Cash Equivalents, and Investments

- added (2020-11-19):
[0001327567-20-000041:note_history:37]
We consider all highly liquid investments with original maturities of three months or less at the date of purchase to be cash equivalents. Investments not considered cash equivalents, and with maturities of one year or less from the condensed consolidated balance sheet date, are classified as short-term investments. Investments with maturities greater than one year from the condensed consolidated balance sheet date are classified as long-term investments.

- added (2020-11-19):
[0001327567-20-000041:note_history:38]
We classify our investments in marketable debt securities as available-for-sale at the time of purchase. When the fair value of a security is below its amortized cost, the amortized cost will be reduced to its fair value if it is more likely than not that we are required to sell the impaired security before recovery of its amortized cost basis, or we have the intention to sell the security. If neither of these conditions are met, we determine whether the impairment is due to credit losses by comparing the present value of the expected cash flows of the security with its amortized cost basis. The amount of impairment recognized is limited to the excess of the amortized cost over the fair value of the security. An allowance for credit losses for the excess of amortized cost over the expected cash flows is

- added (2020-11-19):
[0001327567-20-000041:note_history:39]
recorded in other income, net in our condensed consolidated statements of operations. Impairment losses that are not credit-related are included in accumulated other comprehensive income (loss) (“AOCI”) in stockholders’ equity.

- added (2020-11-19):
[0001327567-20-000041:note_history:40]
Accounts Receivable

- added (2020-11-19):
[0001327567-20-000041:note_history:41]
Trade accounts receivable are recorded at the invoiced amount, net of allowances for credit losses for any potential uncollectible amounts. The allowance for credit losses is based on our assessment of the collectability of accounts. Management regularly reviews the adequacy of the allowance for credit losses on a collective basis by considering the age of each outstanding invoice, each customer’s expected ability to pay and collection history, current market conditions, and reasonable and supportable forecasts of future economic conditions to determine whether the allowance is appropriate. Accounts receivable deemed uncollectible are charged against the allowance for credit losses when identified. For the three months ended October 31, 2020 and 2019, the allowance for credit losses activity was not significant.

- added (2020-11-19):
[0001327567-20-000041:note_history:42]
Financing Receivables

- added (2020-11-19):
[0001327567-20-000041:note_history:43]
We provide financing arrangements, primarily loans, for certain qualified end-user customers to purchase our products and services. Payment terms on these financing arrangements are generally up to three years. We evaluate our allowance for credit losses by assessing the risks and losses inherent in our financing receivables on either an individual or a collective basis. Our assessment considers various factors, including lifetime expected losses determined using customer risk profile, current economic conditions that may affect a customer’s ability to pay, and forward-looking economic considerations. Financing receivables are written off when they are considered uncollectible, and related outstanding balances are reversed and charged against the allowance for credit losses. Short-term financing receivables are included in prepaid expenses and other current assets, and long-term financing receivables are included in other assets on our condensed consolidated balance sheets. Refer to Note 5. Financing Receivables for additional information.

- added (2020-11-19):
[0001327567-20-000041:note_history:44]
Recently Issued Accounting Pronouncements

- added (2020-11-19):
[0001327567-20-000041:note_history:45]
Debt with Conversion Options

- added (2020-11-19):
[0001327567-20-000041:note_history:46]
In August 2020, the FASB issued new authoritative guidance to simplify the accounting for certain financial instruments with characteristics of liabilities and equity, including convertible instruments and contracts on an entity’s own equity. The standard reduces the number of models used to account for convertible instruments, and simplifies both the classification of debt on the balance sheet and the earnings per share calculation. The standard is effective for us in our first quarter of fiscal 2023 and will be applied on a modified retrospective basis. Early adoption is permitted from our first quarter of fiscal 2022. We are currently evaluating the impact of this standard on our condensed consolidated financial statements.

- removed (2020-11-19):
[0001327567-20-000017:note_history:47]
Description of Business

- removed (2020-11-19):
[0001327567-20-000017:note_history:48]
Our condensed consolidated financial statements are unaudited, but include all adjustments of a normal recurring nature necessary for a fair presentation of our quarterly results. We have made estimates and judgments affecting the amounts reported in our condensed consolidated financial statements and the accompanying notes. The actual results that we experience may differ materially from our estimates.

- removed (2020-11-19):
[0001327567-20-000017:note_history:49]
Certain prior period amounts have been reclassified to conform to our current period presentation.


## panw:ConvertibleDebtOtherDetailsTableTextBlock (debt) — matched_by: no_prior_note, score: 0.0

- added (2020-11-19):
[0001327567-20-000041:note_history:50]
The following table presents details of our Notes (number of shares in millions):

- added (2020-11-19):
[0001327567-20-000041:note_history:51]
|  | Conversion Rate per $1,000 Principal |  | Initial Conversion Price |  | Convertible Date |  | Initial Number of Shares |
| 2023 Notes | 3.7545 |  |  | $ | 266.35 |  |  | April 1, 2023 |  | 6.4 |  |
| 2025 Notes | 3.3602 |  |  | $ | 297.60 |  |  | March 1, 2025 |  | 6.7 |  |


## us-gaap:ConvertibleDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-11-19):
[0001327567-20-000041:note_history:52]
The following table sets forth the components of the Notes as of October 31, 2020 and July 31, 2020 (in millions):
  (was, 2020-05-22, similarity 0.9423):
[0001327567-20-000017:note_history:52]
The following table sets forth the components of the 2023 Notes as of April 30, 2020 and July 31, 2019 (in millions):

- added (2020-11-19):
[0001327567-20-000041:note_history:53]
|  | October 31, 2020 | July 31, 2020 |
|  | 2023 Notes |  | 2025 Notes |  | Total |  | 2023 Notes |  | 2025 Notes |  | Total |
| Liability component: |  |  |  |  |  |  |  |  |  |  |  |
| Principal | $ | 1,693.0 |  |  | $ | 2,000.0 |  |  | $ | 3,693.0 |  |  | $ | 1,693.0 |  |  | $ | 2,000.0 |  |  | $ | 3,693.0 |  |
| Less: debt discount and debt issuance costs, net of amortization | 183.8 |  |  | 390.1 |  |  | 573.9 |  |  | 200.0 |  |  | 408.9 |  |  | 608.9 |  |
| Net carrying amount | $ | 1,509.2 |  |  | $ | 1,609.9 |  |  | $ | 3,119.1 |  |  | $ | 1,493.0 |  |  | $ | 1,591.1 |  |  | $ | 3,084.1 |  |
| Equity component | $ | 315.0 |  |  | $ | 403.0 |  |  | $ | 718.0 |  |  | $ | 315.0 |  |  | $ | 403.0 |  |  | $ | 718.0 |  |

- removed (2020-11-19):
[0001327567-20-000017:note_history:54]
|  | April 30, 2020 |  | July 31, 2019 |
| Liability component: |  |  |  |
| Principal | $ | 1,693.0 |  |  | $ | 1,693.0 |  |
| Less: debt discount and debt issuance costs, net of amortization | 216.0 |  |  | 263.0 |  |
| Net carrying amount | $ | 1,477.0 |  |  | $ | 1,430.0 |  |
| Equity component | $ | 315.0 |  |  | $ | 315.0 |  |


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2020-11-19):
[0001327567-20-000041:note_history:55]
In July 2018, we issued $1.7 billion aggregate principal amount of 0.75% Convertible Senior Notes due 2023 (the “2023 Notes”) and, in June 2020, we issued $2.0 billion aggregate principal amount of 0.375% Convertible Senior Notes due 2025 (the “2025 Notes,” and together with the 2023 Notes, the “Notes”). The 2023 Notes bear interest at a fixed rate of 0.75% per year, payable semi-annually in arrears on January 1 and July 1 of each year, beginning on January 1, 2019. The 2025 Notes bear interest at a fixed rate of 0.375% per year, payable semi-annually in arrears on June 1 and December 1 of each year, beginning on December 1, 2020. Each series of the convertible notes is governed by an indenture between us, as the issuer, and U.S. Bank National Association, as Trustee (individually, each an “Indenture,” and together, the “Indentures”). The Notes of each series are unsecured, unsubordinated obligations and the applicable Indenture governing each series of Notes does not contain any financial covenants or restrictions on the payments of dividends, the incurrence of indebtedness, or the issuance or repurchase of securities by us or any of our subsidiaries. The 2023 Notes and the 2025 Notes mature on July 1, 2023 and June 1, 2025, respectively. We cannot redeem the 2023 Notes prior to maturity. We may redeem for cash all or any portion of the 2025 Notes, at our option, on or after June 5, 2023, and prior to the 31st scheduled trading day immediately preceding the maturity date if the last reported sale price of our common stock has been at least 130% of the conversion price then in effect for at least 20 trading days during any 30 consecutive trading day period ending on and including the trading day preceding the date on which we provide notice of redemption. The redemption will be at a price equal to 100% of the principal amount of the 2025 Notes and adjusted for interest. If we call any or all of the 2025 Notes for redemption, holders may convert such 2025 Notes called for redemption at any time prior to the close of business on the second scheduled trading day immediately preceding the redemption date.

- changed (2020-11-19):
[0001327567-20-000041:note_history:56]
The following table presents details of our Notes (number of shares in millions):
  (was, 2020-05-22, similarity 0.6054):
[0001327567-20-000017:note_history:56]
The following table sets forth the components of the 2023 Notes as of April 30, 2020 and July 31, 2019 (in millions):

- added (2020-11-19):
[0001327567-20-000041:note_history:57]
|  | Conversion Rate per $1,000 Principal |  | Initial Conversion Price |  | Convertible Date |  | Initial Number of Shares |
| 2023 Notes | 3.7545 |  |  | $ | 266.35 |  |  | April 1, 2023 |  | 6.4 |  |
| 2025 Notes | 3.3602 |  |  | $ | 297.60 |  |  | March 1, 2025 |  | 6.7 |  |

- added (2020-11-19):
[0001327567-20-000041:note_history:58]
Holders of the Notes may surrender their Notes for conversion at their option at any time prior to the close of business on the business day immediately preceding their respective convertible dates only under the following circumstances:

- changed (2020-11-19):
[0001327567-20-000041:note_history:59]
•during any fiscal quarter commencing after the fiscal quarters ending on October 31, 2018 and October 31, 2020 for the 2023 Notes and the 2025 Notes, respectively (and only during such fiscal quarter), if the last reported sale price of our common stock for at least 20 trading days (whether or not consecutive) during a period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the applicable conversion price for the respective Notes on each applicable trading day (the “sale price condition”);
  (was, 2020-05-22, similarity 0.9305):
[0001327567-20-000017:note_history:59]
•during any fiscal quarter commencing after the fiscal quarter ending on October 31, 2018 (and only during such fiscal quarter), if the last reported sale price of our common stock for at least 20 trading days (whether or not consecutive) during a period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the applicable conversion price for the 2023 Notes on each applicable trading day (the “sale price condition”);

- changed (2020-11-19):
[0001327567-20-000041:note_history:60]
•during the five business day period after any five consecutive trading day period (the “measurement period”) in which the trading price per $1,000 principal amount of the applicable series of Notes for each trading day of the measurement period was less than 98% of the product of the last reported sale price of our common stock and the applicable conversion rate for the respective Notes on each such trading day; or
  (was, 2020-05-22, similarity 0.9588):
[0001327567-20-000017:note_history:60]
•during the five business day period after any five consecutive trading day period (the “measurement period”), in which the trading price per $1,000 principal amount of the 2023 Notes for each trading day of the measurement period was less than 98% of the product of the last reported sale price of our common stock and the applicable conversion rate for the 2023 Notes on each such trading day; or

- added (2020-11-19):
[0001327567-20-000041:note_history:61]
On or after the respective convertible date, holders may surrender all or any portion of their Notes for conversion at any time prior to the close of business on the second scheduled trading day immediately preceding the applicable maturity date regardless of the foregoing conditions, and such conversions will be settled upon the applicable maturity date. Upon conversion, holders of the Notes of a series will receive cash equal to the aggregate principal amount of the Notes of such series to be converted, and, at our election, cash and/or shares of our common stock for any amounts in excess of the aggregate principal amount of the Notes of such series being converted.

- changed (2020-11-19):
[0001327567-20-000041:note_history:62]
The conversion price will be subject to adjustment in some events. Holders of the Notes of a series who convert their Notes of such series in connection with certain corporate events that constitute a “make-whole fundamental change” under the applicable Indenture are, under certain circumstances, entitled to an increase in the conversion rate for such series of Notes. Additionally, upon the occurrence of a corporate event that constitutes a “fundamental change” under the applicable Indenture, holders of the Notes of such series may require us to repurchase for cash all or a portion of the Notes of such series at a repurchase price equal to 100% of the principal amount of the Notes of such series plus accrued and unpaid interest to, but excluding, the fundamental change repurchase date.
  (was, 2020-05-22, similarity 0.888):
[0001327567-20-000017:note_history:62]
The conversion price will be subject to adjustment in some events. Holders who convert their 2023 Notes in connection with certain corporate events that constitute a “make-whole fundamental change” under the Indenture are, under certain circumstances, entitled to an increase in the conversion rate. Additionally, upon the occurrence of a corporate event that constitutes a “fundamental change” under the Indenture, holders of the 2023 Notes may require us to repurchase for cash all or a portion of the 2023 Notes at a repurchase price equal to 100% of the principal amount of the 2023 Notes plus accrued and unpaid interest to, but excluding, the fundamental change repurchase date.

- changed (2020-11-19):
[0001327567-20-000041:note_history:63]
The sale price condition was not met for the Notes during the fiscal quarters ended October 31, 2020 or July 31, 2020. Since the Notes were not convertible, the net carrying amount of the Notes was classified as a long-term liability and the equity component was included in additional paid-in capital in our condensed consolidated balance sheets in the periods presented. As of October 31, 2020, all of the Notes remained outstanding.
  (was, 2020-05-22, similarity 0.6904):
[0001327567-20-000017:note_history:63]
The sale price condition was not met for the 2023 Notes during the fiscal quarters ended April 30, 2020 or July 31, 2019. Since the 2023 Notes were not convertible, the net carrying amount of the 2023 Notes was classified as a long-term liability and the equity component was included in additional paid-in capital in our condensed consolidated balance sheets as of April 30, 2020 and July 31, 2019. As of April 30, 2020, all of the 2023 Notes remained outstanding.

- added (2020-11-19):
[0001327567-20-000041:note_history:64]
The following table sets forth the components of the Notes as of October 31, 2020 and July 31, 2020 (in millions):

- added (2020-11-19):
[0001327567-20-000041:note_history:65]
|  | October 31, 2020 | July 31, 2020 |
|  | 2023 Notes |  | 2025 Notes |  | Total |  | 2023 Notes |  | 2025 Notes |  | Total |
| Liability component: |  |  |  |  |  |  |  |  |  |  |  |
| Principal | $ | 1,693.0 |  |  | $ | 2,000.0 |  |  | $ | 3,693.0 |  |  | $ | 1,693.0 |  |  | $ | 2,000.0 |  |  | $ | 3,693.0 |  |
| Less: debt discount and debt issuance costs, net of amortization | 183.8 |  |  | 390.1 |  |  | 573.9 |  |  | 200.0 |  |  | 408.9 |  |  | 608.9 |  |
| Net carrying amount | $ | 1,509.2 |  |  | $ | 1,609.9 |  |  | $ | 3,119.1 |  |  | $ | 1,493.0 |  |  | $ | 1,591.1 |  |  | $ | 3,084.1 |  |
| Equity component | $ | 315.0 |  |  | $ | 403.0 |  |  | $ | 718.0 |  |  | $ | 315.0 |  |  | $ | 403.0 |  |  | $ | 718.0 |  |

- changed (2020-11-19):
[0001327567-20-000041:note_history:66]
The total estimated fair value of the Notes was $3.9 billion and $4.1 billion at October 31, 2020 and July 31, 2020, respectively. The fair value was determined based on the closing trading price per $100 of the Notes as of the last day of trading for the period. We consider the fair value of the Notes at October 31, 2020 and July 31, 2020 to be a Level 2 measurement. The fair value of the Notes is primarily affected by the trading price of our common stock and market interest rates. Based on the closing price of our common stock on October 31, 2020, the if-converted value of the Notes was less than its respective principal amount.
  (was, 2020-05-22, similarity 0.9029):
[0001327567-20-000017:note_history:66]
The total estimated fair value of the 2023 Notes was $1.7 billion and $1.9 billion at April 30, 2020 and July 31, 2019, respectively. The fair value was determined based on the closing trading price per $100 of the 2023 Notes as of the last day of trading for the period. We consider the fair value of the 2023 Notes at April 30, 2020 and July 31, 2019 to be a Level 2 measurement. The fair value of the 2023 Notes is primarily affected by the trading price of our common stock and market interest rates. Based on the closing price of our common stock on April 30, 2020, the if-converted value of the 2023 Notes was less than its principal amount.

- added (2020-11-19):
[0001327567-20-000041:note_history:67]
|  |  |  | Three Months Ended October 31, |
|  |  |  |  |  | 2020 |  | 2019 |
|  |  |  |  |  |  |  |  |  |  |  |  |  | 2023 Notes |  | 2025 Notes |  | Total |  | 2023 Notes |  |  |  | Total |
| Contractual interest expense |  |  |  |  |  |  |  |  |  |  |  |  | $ | 3.2 |  |  | $ | 1.9 |  |  | $ | 5.1 |  |  | $ | 3.2 |  |  |  | $ | 3.2 |  |
| Amortization of debt discount |  |  |  |  |  |  |  |  |  |  |  |  | 15.7 |  |  | 18.2 |  |  | 33.9 |  |  | 15.0 |  |  |  | 15.0 |  |
| Amortization of debt issuance costs |  |  |  |  |  |  |  |  |  |  |  |  | 0.5 |  |  | 0.7 |  |  | 1.2 |  |  | 0.5 |  |  |  | 0.5 |  |
| Total interest expense recognized |  |  |  |  |  |  |  |  |  |  |  |  | $ | 19.4 |  |  | $ | 20.8 |  |  | $ | 40.2 |  |  | $ | 18.7 |  |  |  | $ | 18.7 |  |
| Effective interest rate of the liability component |  |  |  |  |  |  |  |  |  |  |  |  | 5.2 | % |  | 5.4 | % |  |  |  | 5.2 | % |  |  |  |  |

- changed (2020-11-19):
[0001327567-20-000041:note_history:68]
To minimize the impact of potential economic dilution upon conversion of our Notes, we entered into separate convertible note hedge transactions (the “2023 Note Hedges,” with respect to the 2023 Notes, the “2025 Note Hedges,” with respect to the 2025 Notes, and the 2023 Notes Hedges together with 2025 Note Hedges, the “Note Hedges”) with respect to our common stock concurrent with the issuance of each series of the Notes.
  (was, 2020-05-22, similarity 0.9077):
[0001327567-20-000017:note_history:68]
To minimize the impact of potential economic dilution upon conversion of the Notes, we entered into separate convertible note hedge transactions (the “2019 Note Hedges,” with respect to the 2019 Notes, and the “2023 Note Hedges,” with respect to the 2023 Notes, and collectively, the “Note Hedges”) with respect to our common stock concurrent with the issuance of each series of Notes.

- added (2020-11-19):
[0001327567-20-000041:note_history:69]
The following table presents details of our Note Hedges (in millions):

- added (2020-11-19):
[0001327567-20-000041:note_history:70]
|  | Initial Number of Shares |  | Aggregate Purchase |
| 2023 Note Hedges | 6.4 |  |  | $ | 332.0 |  |
| 2025 Note Hedges | 6.7 |  |  | $ | 370.8 |  |

- changed (2020-11-19):
[0001327567-20-000041:note_history:71]
The Note Hedges cover shares of our common stock at a strike price per share that corresponds to the initial applicable conversion price of the applicable series of the Notes, which are also subject to adjustment, and are exercisable upon conversion of the applicable series of the Notes. The Note Hedges will expire upon maturity of the applicable series of the Notes. The Note Hedges are separate transactions and are not part of the terms of the applicable series of the Notes. Holders of the Notes of either series will not have any rights with respect to the Note Hedges. Any shares of our common stock receivable by us under the Note Hedges are excluded from the calculation of diluted earnings per share as they are antidilutive. The aggregate amounts paid for the Note Hedges are included in additional paid-in capital in our condensed consolidated balance sheets.
  (was, 2020-05-22, similarity 0.7428):
[0001327567-20-000017:note_history:71]
The 2023 Note Hedges cover up to 6.4 million shares of our common stock at a strike price per share that corresponds to the initial applicable conversion price of the 2023 Notes, which are also subject to adjustment, and are exercisable upon conversion of the 2023 Notes. The 2023 Note Hedges will expire upon maturity of the 2023 Notes. The 2023 Note Hedges are separate transactions and are not part of the terms of 2023 Notes. Holders of the 2023 Notes will not have any rights with respect to the 2023 Note Hedges. Any shares of our common stock receivable by us under the 2023 Note Hedges are excluded from the calculation of diluted earnings per share as they are antidilutive. We paid an aggregate amount of $332.0 million for the 2023 Note Hedges, which is included in additional paid-in capital in our consolidated balance sheets.

- changed (2020-11-19):
[0001327567-20-000041:note_history:72]
Separately, but concurrently with the issuance of each series of our Notes, we entered into transactions whereby we sold warrants (the “2023 Warrants,” with respect to the 2023 Notes, the “2025 Warrants,” with respect to the 2025 Notes, and the 2023 Warrants together with the 2025 Warrants, the “Warrants”) to acquire shares of our common stock, subject to anti-dilution adjustments. The 2023 Warrants and 2025 Warrants are exercisable beginning October 2023 and September 2025, respectively.
  (was, 2020-05-22, similarity 0.8234):
[0001327567-20-000017:note_history:72]
Separately, but concurrently with the issuance of each series of Notes, we entered into transactions whereby we sold warrants (the “2019 Warrants,” with respect to the 2019 Notes, and the “2023 Warrants,” with respect to the 2023 Notes, and collectively, the “Warrants”) to acquire shares of our common stock, subject to anti-dilution adjustments. The 2019 Warrants became exercisable beginning October 2019 and the 2023 Warrants are exercisable beginning October 2023.

- changed (2020-11-19):
[0001327567-20-000041:note_history:73]
The shares issuable under the Warrants will be included in the calculation of diluted earnings per share when the average market value per share of our common stock for the reporting period exceeds the applicable strike price for such series of Warrants. The Warrants are separate transactions and are not part of either series of Notes or Note Hedges and are not remeasured through earnings each reporting period. Holders of the Notes of either series will not have any rights with respect to the Warrants. The aggregate proceeds received from the sale of the Warrants are included in additional paid-in capital in our condensed consolidated balance sheets.
  (was, 2020-05-22, similarity 0.9923):
[0001327567-20-000017:note_history:73]
The shares issuable under the Warrants will be included in the calculation of diluted earnings per share when the average market value per share of our common stock for the reporting period exceeds the applicable strike price for such series of Warrants. The Warrants are separate transactions and are not part of either series of Notes or Note Hedges and are not remeasured through earnings each reporting period. Holders of the Notes of either series will not have any rights with respect to the Warrants. The aggregate proceeds received from the sale of the Warrants are included in additional paid-in capital in our consolidated balance sheets.

- changed (2020-11-19):
[0001327567-20-000041:note_history:74]
On September 4, 2018, we entered into a credit agreement (the “Credit Agreement”) with certain institutional lenders that provides for a $400.0 million unsecured revolving credit facility (the “Credit Facility”), with an option to increase the amount of the Credit Facility by up to an additional $350.0 million, subject to certain conditions. The Credit Facility matures on the earlier of (i) September 4, 2023 and (ii) the date that is 91 days prior to the stated maturity of our 2023 Notes if (a) any of the 2023 Notes are
  (was, 2020-05-22, similarity 0.6622):
[0001327567-20-000017:note_history:74]
On September 4, 2018, we entered into a credit agreement (the “Credit Agreement”) with certain institutional lenders that provides for a $400.0 million unsecured revolving credit facility (the “Credit Facility”), with an option to increase the amount of the

- added (2020-11-19):
[0001327567-20-000041:note_history:75]
still outstanding and (b) our unrestricted cash and cash equivalents are less than the then outstanding principal amount of our 2023 Notes plus $400.0 million.

- added (2020-11-19):
[0001327567-20-000041:note_history:76]
The borrowings under the Credit Facility currently bear interest, at our option, at a base rate plus a spread of 0.00% to 0.75%, or an adjusted LIBO Rate plus a spread of 1.00% to 1.75%, in each case with such spread being determined based on our leverage ratio. We are obligated to pay an ongoing commitment fee on undrawn amounts at a rate of 0.125% to 0.250%, depending on our leverage ratio. Regulatory authorities that oversee financial markets have announced that after the end of 2021, they would no longer compel banks currently reporting information used to set the LIBO Rate to continue to make rate submissions. As a result, it is possible that beginning in 2022, the LIBO Rate will no longer be available as a reference rate. Under the terms of our Credit Facility, in the event of the discontinuance of the LIBO Rate, a mutually agreed-upon alternative benchmark rate will be established to replace the LIBO Rate, which may include the Secured Overnight Financing Rate (“SOFR”). We do not anticipate that the discontinuance of the LIBO Rate will materially impact our liquidity or financial position.

- added (2020-11-19):
[0001327567-20-000041:note_history:77]
As of October 31, 2020, there were no amounts outstanding and we were in compliance with all covenants under the Credit Agreement.

- removed (2020-11-19):
[0001327567-20-000017:note_history:78]
In June 2014, we issued $575.0 million aggregate principal amount of 0.0% Convertible Senior Notes due 2019 (the “2019 Notes”), and in July 2018, we issued $1.7 billion aggregate principal amount of 0.75% Convertible Senior Notes due 2023 (the “2023 Notes” and, together with the 2019 Notes, the “Notes”). The 2023 Notes bear interest at a fixed rate of 0.75% per year, payable semi-annually in arrears on January 1 and July 1 of each year, beginning on January 1, 2019. The 2023 Notes are governed by an indenture

- removed (2020-11-19):
[0001327567-20-000017:note_history:79]
between us, as the issuer, and U.S. Bank National Association, as Trustee (the “Indenture”). The 2023 Notes are unsecured, unsubordinated obligations and the Indenture governing the 2023 Notes does not contain any financial covenants or restrictions on the payments of dividends, the incurrence of indebtedness, or the issuance or repurchase of securities by us or any of our subsidiaries. The 2019 Notes were converted prior to or settled on the maturity date of July 1, 2019, in accordance with their terms. The 2023 Notes mature on July 1, 2023. We cannot redeem the 2023 Notes prior to maturity.

- removed (2020-11-19):
[0001327567-20-000017:note_history:80]
The 2023 Notes are convertible for up to 6.4 million shares of our common stock at an initial conversion rate of approximately 3.7545 shares of common stock per $1,000 principal amount, which is equal to an initial conversion price of approximately $266.35 per share of common stock, subject to adjustments. Holders of the 2023 Notes may surrender their 2023 Notes for conversion at their option at any time prior to the close of business on the business day immediately preceding April 1, 2023, only under the following circumstances:

- removed (2020-11-19):
[0001327567-20-000017:note_history:81]
On or after April 1, 2023, holders may surrender all or any portion of their 2023 Notes for conversion at any time prior to the close of business on the second scheduled trading day immediately preceding the maturity date regardless of the foregoing conditions, and such conversions will be settled upon the maturity date. Upon conversion, holders of the 2023 Notes will receive cash equal to the aggregate principal amount of the 2023 Notes to be converted, and, at our election, cash and/or shares of our common stock for any amounts in excess of the aggregate principal amount of the 2023 Notes being converted.

- removed (2020-11-19):
[0001327567-20-000017:note_history:82]
|  | April 30, 2020 |  | July 31, 2019 |
| Liability component: |  |  |  |
| Principal | $ | 1,693.0 |  |  | $ | 1,693.0 |  |
| Less: debt discount and debt issuance costs, net of amortization | 216.0 |  |  | 263.0 |  |
| Net carrying amount | $ | 1,477.0 |  |  | $ | 1,430.0 |  |
| Equity component | $ | 315.0 |  |  | $ | 315.0 |  |

- removed (2020-11-19):
[0001327567-20-000017:note_history:83]
|  | Three Months Ended April 30, |  |  |  |  |  |  |  |  |  |  |  | Nine Months Ended April 30, |  |  |  |  |  |  |  |  |  |  |
|  | 2020 |  |  |  |  |  | 2019 |  |  |  |  |  | 2020 |  |  |  |  |  | 2019 |  |  |  |  |
|  | 2019 Notes |  | 2023 Notes |  | Total |  | 2019 Notes |  | 2023 Notes |  | Total |  | 2019 Notes |  | 2023 Notes |  | Total |  | 2019 Notes |  | 2023 Notes |  | Total |
| Contractual interest expense | $ | — |  |  | $ | 3.2 |  |  | $ | 3.2 |  |  | $ | — |  |  | $ | 3.3 |  |  | $ | 3.3 |  |  | $ | — |  |  | $ | 9.5 |  |  | $ | 9.5 |  |  | $ | — |  |  | $ | 9.6 |  |  | $ | 9.6 |  |
| Amortization of debt discount | — |  |  | 15.3 |  |  | 15.3 |  |  | 1.6 |  |  | 14.7 |  |  | 16.3 |  |  | — |  |  | 45.5 |  |  | 45.5 |  |  | 7.6 |  |  | 43.6 |  |  | 51.2 |  |
| Amortization of debt issuance costs | — |  |  | 0.5 |  |  | 0.5 |  |  | 0.3 |  |  | 0.5 |  |  | 0.8 |  |  | — |  |  | 1.5 |  |  | 1.5 |  |  | 1.0 |  |  | 1.4 |  |  | 2.4 |  |
| Total interest expense recognized | $ | — |  |  | $ | 19.0 |  |  | $ | 19.0 |  |  | $ | 1.9 |  |  | $ | 18.5 |  |  | $ | 20.4 |  |  | $ | — |  |  | $ | 56.5 |  |  | $ | 56.5 |  |  | $ | 8.6 |  |  | $ | 54.6 |  |  | $ | 63.2 |  |
| Effective interest rate of the liability component | — | % |  | 5.2 | % |  |  |  | 4.8 | % |  | 5.2 | % |  |  |  | — | % |  | 5.2 | % |  |  |  | 4.8 | % |  | 5.2 | % |  |  |

- removed (2020-11-19):
[0001327567-20-000017:note_history:84]
Upon the settlement of the 2019 Notes, we exercised the corresponding portion of our 2019 Note Hedges during the year ended July 31, 2019 and received shares of our common stock that fully offset the shares issued in excess of the principal amount of the converted 2019 Notes. The 2019 Note Hedges expired upon maturity of the 2019 Notes.

- removed (2020-11-19):
[0001327567-20-000017:note_history:85]
During the nine months ended April 30, 2020, we net settled all 2019 Warrants with 2.0 million shares or $462.0 million in fair value of our common stock. The number of net shares issued was determined based on the number of 2019 Warrants exercised multiplied by the difference between the strike price of the 2019 Warrants and their daily volume weighted-average stock price.

- removed (2020-11-19):
[0001327567-20-000017:note_history:86]
Credit Facility by up to an additional $350.0 million, subject to certain conditions. The Credit Facility matures on the earlier of (i) September 4, 2023 and (ii) the date that is 91 days prior to the stated maturity of our 2023 Notes if (a) any of the 2023 Notes are still outstanding and (b) our unrestricted cash and cash equivalents are less than the then outstanding principal amount of our 2023 Notes plus $400.0 million.

- removed (2020-11-19):
[0001327567-20-000017:note_history:87]
The borrowings under the Credit Facility bear interest, at our option, at a base rate plus a spread of 0.00% to 0.75%, or an adjusted LIBO rate plus a spread of 1.00% to 1.75%, in each case with such spread being determined based on our leverage ratio. We are obligated to pay an ongoing commitment fee on undrawn amounts at a rate of 0.125% to 0.250%, depending on our leverage ratio. As of April 30, 2020, there were no amounts outstanding and we were in compliance with all covenants under the Credit Agreement.


## us-gaap:DebtSecuritiesAvailableForSaleTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-11-19):
[0001327567-20-000041:note_history:88]
The following tables summarize the amortized cost, unrealized gains and losses, and fair value of our available-for-sale debt securities as of October 31, 2020 and July 31, 2020 (in millions):
  (was, 2020-05-22, similarity 0.9724):
[0001327567-20-000017:note_history:88]
The following tables summarize the amortized cost, unrealized gains and losses, and fair value of our available-for-sale debt securities as of April 30, 2020 and July 31, 2019 (in millions):

- changed (2020-11-19):
[0001327567-20-000041:note_history:89]
|  | October 31, 2020 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 150.0 |  |  | $ | — |  |  | $ | — |  |  | $ | 150.0 |  |
| U.S. government and agency securities | 407.6 |  |  | — |  |  | — |  |  | 407.6 |  |
| Total available-for-sale cash equivalents | $ | 557.6 |  |  | $ | — |  |  | $ | — |  |  | $ | 557.6 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 31.1 |  |  | $ | — |  |  | $ | — |  |  | $ | 31.1 |  |
| Commercial paper | 10.0 |  |  | — |  |  | — |  |  | 10.0 |  |
| Corporate debt securities | 330.7 |  |  | 1.3 |  |  | — |  |  | 332.0 |  |
| U.S. government and agency securities | 1,492.6 |  |  | 2.0 |  |  | (0.1) |  |  | 1,494.5 |  |
| Non-U.S. government securities | 81.2 |  |  | — |  |  | — |  |  | 81.2 |  |
| Total available-for-sale investments | $ | 1,945.6 |  |  | $ | 3.3 |  |  | $ | (0.1) |  |  | $ | 1,948.8 |  |
  (was, 2020-05-22, similarity 0.9071):
[0001327567-20-000017:note_history:89]
|  | July 31, 2019 |  |  |  |  |  |  |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 12.0 |  |  | $ | — |  |  | $ | — |  |  | $ | 12.0 |  |
| Commercial paper | 19.3 |  |  | — |  |  | — |  |  | 19.3 |  |
| U.S. government and agency securities | 54.4 |  |  | — |  |  | — |  |  | 54.4 |  |
| Total available-for-sale cash equivalents | $ | 85.7 |  |  | $ | — |  |  | $ | — |  |  | $ | 85.7 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 17.5 |  |  | $ | — |  |  | $ | — |  |  | $ | 17.5 |  |
| Commercial paper | 8.9 |  |  | — |  |  | — |  |  | 8.9 |  |
| Corporate debt securities | 587.8 |  |  | 2.3 |  |  | (0.3) |  |  | 589.8 |  |
| U.S. government and agency securities | 1,799.5 |  |  | 2.6 |  |  | (1.2) |  |  | 1,800.9 |  |
| Total available-for-sale investments | $ | 2,413.7 |  |  | $ | 4.9 |  |  | $ | (1.5) |  |  | $ | 2,417.1 |  |

- added (2020-11-19):
[0001327567-20-000041:note_history:90]
|  | July 31, 2020 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| U.S. government and agency securities | $ | 342.0 |  |  | $ | — |  |  | $ | — |  |  | $ | 342.0 |  |
| Total available-for-sale cash equivalents | $ | 342.0 |  |  | $ | — |  |  | $ | — |  |  | $ | 342.0 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 31.9 |  |  | $ | — |  |  | $ | — |  |  | $ | 31.9 |  |
| Corporate debt securities | 190.1 |  |  | 1.8 |  |  | — |  |  | 191.9 |  |
| U.S. government and agency securities | 1,090.3 |  |  | 2.8 |  |  | (0.1) |  |  | 1,093.0 |  |
| Non-U.S. government and agency securities | 27.4 |  |  | — |  |  | — |  |  | 27.4 |  |
| Total available-for-sale investments | $ | 1,339.7 |  |  | $ | 4.6 |  |  | $ | (0.1) |  |  | $ | 1,344.2 |  |

- removed (2020-11-19):
[0001327567-20-000017:note_history:91]
|  | April 30, 2020 |  |  |  |  |  |  |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 22.3 |  |  | $ | — |  |  | $ | — |  |  | $ | 22.3 |  |
| Corporate debt securities | 139.4 |  |  | 1.7 |  |  | — |  |  | 141.1 |  |
| U.S. government and agency securities | 537.6 |  |  | 4.3 |  |  | — |  |  | 541.9 |  |
| Total available-for-sale investments | $ | 699.3 |  |  | $ | 6.0 |  |  | $ | — |  |  | $ | 705.3 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-11-19):
[0001327567-20-000041:note_history:92]
The following tables summarize the amortized cost, unrealized gains and losses, and fair value of our available-for-sale debt securities as of October 31, 2020 and July 31, 2020 (in millions):
  (was, 2020-05-22, similarity 0.9724):
[0001327567-20-000017:note_history:92]
The following tables summarize the amortized cost, unrealized gains and losses, and fair value of our available-for-sale debt securities as of April 30, 2020 and July 31, 2019 (in millions):

- changed (2020-11-19):
[0001327567-20-000041:note_history:93]
|  | October 31, 2020 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 150.0 |  |  | $ | — |  |  | $ | — |  |  | $ | 150.0 |  |
| U.S. government and agency securities | 407.6 |  |  | — |  |  | — |  |  | 407.6 |  |
| Total available-for-sale cash equivalents | $ | 557.6 |  |  | $ | — |  |  | $ | — |  |  | $ | 557.6 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 31.1 |  |  | $ | — |  |  | $ | — |  |  | $ | 31.1 |  |
| Commercial paper | 10.0 |  |  | — |  |  | — |  |  | 10.0 |  |
| Corporate debt securities | 330.7 |  |  | 1.3 |  |  | — |  |  | 332.0 |  |
| U.S. government and agency securities | 1,492.6 |  |  | 2.0 |  |  | (0.1) |  |  | 1,494.5 |  |
| Non-U.S. government securities | 81.2 |  |  | — |  |  | — |  |  | 81.2 |  |
| Total available-for-sale investments | $ | 1,945.6 |  |  | $ | 3.3 |  |  | $ | (0.1) |  |  | $ | 1,948.8 |  |
  (was, 2020-05-22, similarity 0.9071):
[0001327567-20-000017:note_history:93]
|  | July 31, 2019 |  |  |  |  |  |  |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 12.0 |  |  | $ | — |  |  | $ | — |  |  | $ | 12.0 |  |
| Commercial paper | 19.3 |  |  | — |  |  | — |  |  | 19.3 |  |
| U.S. government and agency securities | 54.4 |  |  | — |  |  | — |  |  | 54.4 |  |
| Total available-for-sale cash equivalents | $ | 85.7 |  |  | $ | — |  |  | $ | — |  |  | $ | 85.7 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 17.5 |  |  | $ | — |  |  | $ | — |  |  | $ | 17.5 |  |
| Commercial paper | 8.9 |  |  | — |  |  | — |  |  | 8.9 |  |
| Corporate debt securities | 587.8 |  |  | 2.3 |  |  | (0.3) |  |  | 589.8 |  |
| U.S. government and agency securities | 1,799.5 |  |  | 2.6 |  |  | (1.2) |  |  | 1,800.9 |  |
| Total available-for-sale investments | $ | 2,413.7 |  |  | $ | 4.9 |  |  | $ | (1.5) |  |  | $ | 2,417.1 |  |

- added (2020-11-19):
[0001327567-20-000041:note_history:94]
|  | July 31, 2020 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| U.S. government and agency securities | $ | 342.0 |  |  | $ | — |  |  | $ | — |  |  | $ | 342.0 |  |
| Total available-for-sale cash equivalents | $ | 342.0 |  |  | $ | — |  |  | $ | — |  |  | $ | 342.0 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 31.9 |  |  | $ | — |  |  | $ | — |  |  | $ | 31.9 |  |
| Corporate debt securities | 190.1 |  |  | 1.8 |  |  | — |  |  | 191.9 |  |
| U.S. government and agency securities | 1,090.3 |  |  | 2.8 |  |  | (0.1) |  |  | 1,093.0 |  |
| Non-U.S. government and agency securities | 27.4 |  |  | — |  |  | — |  |  | 27.4 |  |
| Total available-for-sale investments | $ | 1,339.7 |  |  | $ | 4.6 |  |  | $ | (0.1) |  |  | $ | 1,344.2 |  |

- added (2020-11-19):
[0001327567-20-000041:note_history:95]
We do not intend to sell any of the securities in an unrealized loss position and it is not likely that we would be required to sell these securities before recovery of their amortized cost basis, which may be at maturity. We did not recognize any credit losses related to our available-for-sale debt securities during the three months ended October 31, 2020.

- changed (2020-11-19):
[0001327567-20-000041:note_history:96]
The following table summarizes the amortized cost and fair value of our available-for-sale debt securities as of October 31, 2020, by contractual years-to-maturity (in millions):
  (was, 2020-05-22, similarity 0.9708):
[0001327567-20-000017:note_history:96]
The following table summarizes the amortized cost and fair value of our available-for-sale debt securities as of April 30, 2020, by contractual years-to-maturity (in millions):

- added (2020-11-19):
[0001327567-20-000041:note_history:97]
Marketable equity securities consist of money market funds and are included in cash and cash equivalents on our condensed consolidated balance sheets. As of October 31, 2020 and July 31, 2020, the carrying value of our marketable equity securities were $392.3 million and $1.6 billion, respectively. There were no unrealized gains or losses recognized for these securities during the three months ended October 31, 2020 and 2019.

- removed (2020-11-19):
[0001327567-20-000017:note_history:98]
|  | April 30, 2020 |  |  |  |  |  |  |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 22.3 |  |  | $ | — |  |  | $ | — |  |  | $ | 22.3 |  |
| Corporate debt securities | 139.4 |  |  | 1.7 |  |  | — |  |  | 141.1 |  |
| U.S. government and agency securities | 537.6 |  |  | 4.3 |  |  | — |  |  | 541.9 |  |
| Total available-for-sale investments | $ | 699.3 |  |  | $ | 6.0 |  |  | $ | — |  |  | $ | 705.3 |  |

- removed (2020-11-19):
[0001327567-20-000017:note_history:99]
Unrealized losses related to these securities are due to interest rate fluctuations as opposed to credit quality. In addition, we do not intend to sell and it is not likely that we would be required to sell these securities before recovery of their amortized cost basis, which may be at maturity. As a result, there were no other-than-temporary impairments for these securities at April 30, 2020 and July 31, 2019.

- removed (2020-11-19):
[0001327567-20-000017:note_history:100]
Marketable equity securities consist of money market funds and are included in cash and cash equivalents in our condensed consolidated balance sheets. As of April 30, 2020 and July 31, 2019, the carrying value of our marketable equity securities were $762.6 million and $369.1 million, respectively. There were no unrealized gains or losses recognized for these securities during the three and nine months ended April 30, 2020 and 2019.


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2020-11-19):
[0001327567-20-000041:note_history:101]
|  |  |  | Three Months Ended October 31, |
|  |  |  |  |  | 2020 |  | 2019 |
| Revenue: |  |  |  |  |  |  |  |
| Americas |  |  |  |  |  |  |  |
| United States |  |  |  |  | $ | 628.4 |  |  | $ | 494.9 |  |
| Other Americas |  |  |  |  | 41.9 |  |  | 34.7 |  |
| Total Americas |  |  |  |  | 670.3 |  |  | 529.6 |  |
| Europe, the Middle East, and Africa (“EMEA”) |  |  |  |  | 170.9 |  |  | 147.6 |  |
| Asia Pacific and Japan (“APAC”) |  |  |  |  | 104.8 |  |  | 94.7 |  |
| Total revenue |  |  |  |  | $ | 946.0 |  |  | $ | 771.9 |  |

- added (2020-11-19):
[0001327567-20-000041:note_history:102]
|  |  |  | Three Months Ended October 31, |
|  |  |  |  |  | 2020 |  | 2019 |
| Revenue: |  |  |  |  |  |  |  |
| Product |  |  |  |  | $ | 237.3 |  |  | $ | 231.2 |  |
| Subscription and support |  |  |  |  |  |  |  |
| Subscription |  |  |  |  | 428.0 |  |  | 318.6 |  |
| Support |  |  |  |  | 280.7 |  |  | 222.1 |  |
| Total subscription and support |  |  |  |  | 708.7 |  |  | 540.7 |  |
| Total revenue |  |  |  |  | $ | 946.0 |  |  | $ | 771.9 |  |

- changed (2020-11-19):
[0001327567-20-000041:note_history:103]
During the three months ended October 31, 2020, we recognized approximately $630.0 million of revenue pertaining to amounts that were deferred as of July 31, 2020.
  (was, 2020-05-22, similarity 0.9416):
[0001327567-20-000017:note_history:103]
During the nine months ended April 30, 2020, we recognized approximately $1,265.0 million of revenue pertaining to amounts that were deferred as of July 31, 2019.

- changed (2020-11-19):
[0001327567-20-000041:note_history:104]
Revenue expected to be recognized from remaining performance obligations was $4.4 billion as of October 31, 2020, of which we expect to recognize approximately $2.3 billion over the next 12 months and the remainder thereafter.
Deferred Contract Costs
The following table presents details of our short-term and long-term deferred contract costs as of October 31, 2020 and July 31, 2020 (in millions):
  (was, 2020-05-22, similarity 0.9681):
[0001327567-20-000017:note_history:104]
Revenue expected to be recognized from remaining performance obligations was $3.5 billion as of April 30, 2020, of which we expect to recognize approximately $1.9 billion over the next 12 months and the remainder thereafter.
Deferred Contract Costs
The following table presents details of our short-term and long-term deferred contract costs as of April 30, 2020 and July 31, 2019 (in millions):

- changed (2020-11-19):
[0001327567-20-000041:note_history:105]
|  | October 31, 2020 |  | July 31, 2020 |
| Short-term deferred contract costs | $ | 213.0 |  |  | $ | 206.0 |  |
| Long-term deferred contract costs | 408.8 |  |  | 422.3 |  |
| Total deferred contract costs | $ | 621.8 |  |  | $ | 628.3 |  |
  (was, 2020-05-22, similarity 0.9747):
[0001327567-20-000017:note_history:105]
|  | April 30, 2020 |  | July 31, 2019 |
| Short-term deferred contract costs | $ | 173.7 |  |  | $ | 151.1 |  |
| Long-term deferred contract costs | 343.6 |  |  | 324.2 |  |
| Total deferred contract costs | $ | 517.3 |  |  | $ | 475.3 |  |

- changed (2020-11-19):
[0001327567-20-000041:note_history:106]
We recognized amortization expense for our deferred contract costs of $65.8 million and $55.6 million during the three months ended October 31, 2020 and 2019, respectively. We did not recognize any impairment losses on our deferred contract costs during the three months ended October 31, 2020 or 2019.
  (was, 2020-05-22, similarity 0.6728):
[0001327567-20-000017:note_history:106]
We recognized amortization expense for our deferred contract costs of $60.5 million and $171.4 million during the three and nine months ended April 30, 2020, respectively, and $57.2 million and $147.6 million during the three and nine months ended April 30, 2019, respectively. We did not recognize any impairment losses on our deferred contract costs during the three and nine months ended April 30, 2020 or 2019.

- removed (2020-11-19):
[0001327567-20-000017:note_history:107]
|  | Three Months Ended April 30, |  |  |  | Nine Months Ended April 30, |  |  |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Revenue: |  |  |  |  |  |  |  |
| Americas |  |  |  |  |  |  |  |
| United States | $ | 553.5 |  |  | $ | 464.3 |  |  | $ | 1,554.0 |  |  | $ | 1,314.8 |  |
| Other Americas | 40.7 |  |  | 33.5 |  |  | 114.5 |  |  | 108.2 |  |
| Total Americas | 594.2 |  |  | 497.8 |  |  | 1,668.5 |  |  | 1,423.0 |  |
| Europe, the Middle East, and Africa (“EMEA”) | 171.5 |  |  | 138.7 |  |  | 485.3 |  |  | 414.7 |  |
| Asia Pacific and Japan (“APAC”) | 103.7 |  |  | 90.1 |  |  | 304.2 |  |  | 256.1 |  |
| Total revenue | $ | 869.4 |  |  | $ | 726.6 |  |  | $ | 2,458.0 |  |  | $ | 2,093.8 |  |

- removed (2020-11-19):
[0001327567-20-000017:note_history:108]
|  | Three Months Ended April 30, |  |  |  | Nine Months Ended April 30, |  |  |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Revenue: |  |  |  |  |  |  |  |
| Product | $ | 280.9 |  |  | $ | 278.4 |  |  | $ | 758.6 |  |  | $ | 790.5 |  |
| Subscription and support |  |  |  |  |  |  |  |
| Subscription | 354.3 |  |  | 258.8 |  |  | 1,015.5 |  |  | 739.8 |  |
| Support | 234.2 |  |  | 189.4 |  |  | 683.9 |  |  | 563.5 |  |
| Total subscription and support | 588.5 |  |  | 448.2 |  |  | 1,699.4 |  |  | 1,303.3 |  |
| Total revenue | $ | 869.4 |  |  | $ | 726.6 |  |  | $ | 2,458.0 |  |  | $ | 2,093.8 |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_prior_note, score: 0.0

- added (2020-11-19):
[0001327567-20-000041:note_history:109]
Subsequent Events
Business Combinations

- added (2020-11-19):
[0001327567-20-000041:note_history:110]
In November 2020, we entered into a definitive agreement to acquire Expanse Inc. (“Expanse”), a privately-held company specializing in attack surface management, for total consideration of approximately $800 million, including approximately $670 million in cash and common stock, and approximately $130 million in replacement equity awards, subject to adjustment. We expect the acquisition will enrich our Cortex offerings and enable organizations an integrated view of the enterprise to combine external, internal, and threat data. The acquisition is expected to close during our second quarter of fiscal 2021.

- added (2020-11-19):
[0001327567-20-000041:note_history:111]
In November 2020, we entered into a definitive agreement to acquire Sinefa Group, Inc. and its wholly owned subsidiaries (“Sinefa”), a privately-held digital experience monitoring company, for total consideration of approximately $44 million in cash, subject to adjustment. We expect the acquisition will extend our Prisma Access offering. The acquisition is expected to close during our second quarter of fiscal 2021.
