# PANW MD&A — 0001327567-20-000041


## mdna

[0001327567-20-000041:mdna:1]
ITEM 2.     MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS

[0001327567-20-000041:mdna:2]
[same as prior period, unchanged from 0001327567-20-000017:mdna:2]

[0001327567-20-000041:mdna:3]
[same as prior period, unchanged from 0001327567-20-000017:mdna:3]

[0001327567-20-000041:mdna:4]
[same as prior period, unchanged from 0001327567-20-000017:mdna:4]

[0001327567-20-000041:mdna:5]
•Results of Operations. A discussion of the nature and trends in our financial results and an analysis of our financial results comparing the three months ended October 31, 2020 to the three months ended October 31, 2019.

[0001327567-20-000041:mdna:6]
[same as prior period, unchanged from 0001327567-20-000017:mdna:6]

[0001327567-20-000041:mdna:7]
[same as prior period, unchanged from 0001327567-20-000017:mdna:7]

[0001327567-20-000041:mdna:8]
[same as prior period, unchanged from 0001327567-20-000017:mdna:8]

[0001327567-20-000041:mdna:9]
[same as prior period, unchanged from 0001327567-20-000017:mdna:9]

[0001327567-20-000041:mdna:10]
We empower enterprises, service providers, and government entities to secure all users, applications, data, networks and devices with comprehensive visibility and context continuously across all locations. We deliver cybersecurity products covering a broad range of use cases, enabling our end-customers to secure their networks, remote workforce, access to the service edge, branch locations, public and private clouds, and to advance their Security Operations Centers (“SOC”). We believe our portfolio offers advanced prevention and security, while reducing the total cost of ownership for organizations by improving operational efficiency and eliminating the need for siloed point products. We do this with solutions focused on delivering value in three fundamental areas:

[0001327567-20-000041:mdna:11]
[same as prior period, unchanged from 0001327567-20-000017:mdna:12]

[0001327567-20-000041:mdna:12]
•Secure the network through our ML-powered Next-Generation Firewalls, available in a number of form factors, including physical, virtual, and containerized appliances, as well as a cloud-delivered service. This also includes our add-on Cloud-delivered Security Services (“Security Services”), such as Threat Prevention, WildFire, URL Filtering, DNS Security, IoT Security, GlobalProtect, SD-WAN, and Enterprise Data Loss Prevention that secure applications, users,

[0001327567-20-000041:mdna:13]
- 24 -

[0001327567-20-000041:mdna:14]
and devices across our ML-powered Next-Generation Firewalls, Prisma, and Cortex product lines. Panorama, our network security management solution, available as hardware or virtual machine, can centrally manage all of our firewalls irrespective of their form factor, location, or scale.

[0001327567-20-000041:mdna:15]
[same as prior period, unchanged from 0001327567-20-000017:mdna:14]

[0001327567-20-000041:mdna:16]
•Secure the cloud through our Prisma security offerings. Prisma Cloud, the industry’s most comprehensive Cloud Native Security Platform (“CNSP”), secures multi- and hybrid-cloud environments and cloud native applications integrating security across the full deployment lifecycle. Prisma SaaS protects SaaS applications. Prisma Access, a comprehensive Secure Access Service Edge (“SASE”) offering, together with CloudGenix SD-WAN, is used to secure remote work forces and enable the cloud-delivered branch. CloudGenix SD-WAN autonomous networking and integrated security is available as a combination of physical, virtual, and cloud-delivered appliances and services. VM-Series and CN-Series enforces in-line network security in multi- and hybrid- cloud environments.

[0001327567-20-000041:mdna:17]
[same as prior period, unchanged from 0001327567-20-000017:mdna:16]

[0001327567-20-000041:mdna:18]
•Secure the future through our Cortex security offerings, which includes Cortex XDR for prevention, detection, and response platforms to stop modern security attacks, Cortex XSOAR for security orchestration, automation, and response (“SOAR”), Autofocus for threat intelligence, and Cortex Data Lake to collect and integrate security data for analytics. These products are delivered as software or SaaS subscriptions. In addition, Crypsis provides incident response, risk management, and digital forensics services to help and protect our customers.

[0001327567-20-000041:mdna:19]
For the first quarter of fiscal 2021 and 2020, total revenue was $946.0 million and $771.9 million, respectively, representing year-over-year growth of 22.6%. Our growth reflects the increased adoption of our portfolio, which consists of product, subscriptions, and support. We believe our portfolio will enable us to benefit from recurring revenues as we continue to grow our installed end-customer base. As of October 31, 2020, we had end-customers in more than 170 countries. Our end-customers represent a broad range of industries including education, energy, financial services, government entities, healthcare, Internet and media, manufacturing, public sector, and telecommunications, and include some of the largest Fortune 100 and Global 2000 companies in the world. We maintain a field sales force that works closely with our channel partners in developing sales opportunities. We use a two-tiered, indirect fulfillment model whereby we sell our products, subscriptions, and support to our distributors, which, in turn, sell to our resellers, which then sell to our end-customers.

[0001327567-20-000041:mdna:20]
Our product revenue was $237.3 million, or 25.1% of total revenue, for the first quarter of fiscal 2021, representing year-over-year growth of 2.6%. Product revenue is generated from sales of our appliances, primarily our ML-powered Next-Generation Firewall, which is available in a number of form factors, including as physical, virtual, and containerized appliances. Our ML-powered Next-Generation Firewall incorporates our PAN-OS operating system, which provides a consistent set of capabilities across our entire product line. Our products are designed for different performance requirements throughout an organization, ranging from our PA-220, which is designed for small organizations and remote or branch offices, to our top-of-the-line PA-7080, which is designed for large-scale data centers and service provider use. The same firewall functionality that is delivered in our physical appliances is also available in our VM-Series virtual firewalls, which secure virtualized and cloud-based computing environments, and in our CN-Series container firewalls, which secure container environments and traffic.

[0001327567-20-000041:mdna:21]
Our subscription and support revenue grew to $708.7 million, or 74.9% of total revenue, for the first quarter of fiscal 2021, representing year-over-year growth of 31.1%. Our subscriptions provide our end-customers with near real-time access to the latest antivirus, intrusion prevention, web filtering, and modern malware prevention capabilities across the network, endpoints, and the cloud. When end-customers purchase our physical, virtual, or container firewall appliances, they typically purchase support in order to receive ongoing security updates, upgrades, bug fixes, and repairs. In addition to the subscriptions purchased with these appliances, end-customers may also purchase other subscriptions on a per-user, per-endpoint, or capacity-based basis. We also offer professional services, including incident response, risk management, and digital forensic services.

[0001327567-20-000041:mdna:22]
We continue to invest in innovation as we evolve and further extend the capabilities of our platforms, as we believe that innovation and timely development of new features and products are essential to meeting the needs of our end-customers and improving our competitive position. For example, in September 2020, we acquired The Crypsis Group (“Crypsis”), which we believe will expand our capabilities and strengthen our Cortex strategy.

[0001327567-20-000041:mdna:23]
We believe that the growth of our business and our short-term and long-term success are dependent upon many factors, including our ability to extend our technology leadership, grow our base of end-customers, expand deployment of our portfolio and support offerings within existing end-customers, and focus on end-customer satisfaction. To manage any future growth effectively, we must continue to improve and expand our information technology and financial infrastructure, our operating and administrative systems and controls, and our ability to manage headcount, capital, and processes in an efficient manner. While these areas present significant opportunities for us, they also pose challenges and risks that we must successfully address in order to sustain the growth of our business and improve our operating results. For additional information regarding the challenges and risks we face, see the “Risk Factors” section in Part II, Item 1A of this Quarterly Report on Form 10-Q.

[0001327567-20-000041:mdna:24]
- 25 -

[0001327567-20-000041:mdna:25]
Impact of COVID-19 on Our Business

[0001327567-20-000041:mdna:26]
We are actively monitoring, evaluating, and responding to developments relating to COVID-19, which has and is expected to result in continued significant global, social, and business disruption. While we instituted a global work-from-home policy beginning in March 2020, we did not incur significant disruptions in our work operations during the first quarter of fiscal 2021. We are conducting business as usual with restrictions to employee travel and transitioning of in-person marketing events to virtual formats, among other modifications. These changes will substantially remain in effect in the second quarter of fiscal 2021, and are likely to extend to future quarters. We will continue to actively monitor the situation and will make further changes to our business operations as may be required by federal, state, or local authorities or that we determine are in the best interests of our employees, end-customers, partners, suppliers, and stockholders. Our focus remains on the safety of our employees, striving to protect the health and well-being of the communities in which we operate, and providing technology to our employees, end-customers, and partners to help them do their best work while remote.

[0001327567-20-000041:mdna:27]
Although some end-customers adopted Prisma Access as their secure work-from-home solution for the longer term, COVID-19 may curtail our end-customers’ spending and could lead them to delay or defer purchasing decisions, and lengthen sales cycles and payment terms, which could materially adversely impact our business, results of operations, and overall financial performance. Also, certain of our end-customers or partners may be or may become credit or cash constrained, making it difficult for them to fulfill their payment obligations to us. The extent of the impact of COVID-19 on our operational and financial performance will depend on developments, including the duration and spread of the virus, impact on our end-customers’ spending, volume of sales and length of our sales cycles, impact on our partners, suppliers, and employees, actions that may be taken by governmental authorities, and other factors identified in Part II, Item 1A “Risk Factors” in this Form 10-Q. Given the dynamic nature of these circumstances, the full impact of COVID-19 on our ongoing business, results of operations, and overall financial performance cannot be reasonably estimated at this time.

[0001327567-20-000041:mdna:28]
[same as prior period, unchanged from 0001327567-20-000017:mdna:27]

[0001327567-20-000041:mdna:29]
[same as prior period, unchanged from 0001327567-20-000017:mdna:28]

[0001327567-20-000041:mdna:30]
|  | October 31, 2020 |  | July 31, 2020 |
|  | (in millions) |
| Total deferred revenue | $ | 3,946.8 |  |  | $ | 3,810.2 |  |
| Cash, cash equivalents, and investments | $ | 4,090.8 |  |  | $ | 4,302.2 |  |

[0001327567-20-000041:mdna:31]
|  |  |  | Three Months Ended October 31, |
|  |  |  |  |  | 2020 |  | 2019 |
|  |  |  |  |  | (dollars in millions) |
| Total revenue |  |  |  |  | $ | 946.0 |  |  | $ | 771.9 |  |
| Total revenue year-over-year percentage increase |  |  |  |  | 22.6 | % |  | 17.7 | % |
| Gross margin |  |  |  |  | 70.6 | % |  | 71.8 | % |
| Operating loss |  |  |  |  | $ | (44.5) |  |  | $ | (51.8) |  |
| Operating margin |  |  |  |  | (4.7) | % |  | (6.7) | % |
| Billings |  |  |  |  | $ | 1,082.8 |  |  | $ | 897.4 |  |
| Billings year-over-year percentage increase |  |  |  |  | 20.7 | % |  | 18.3 | % |
| Cash flow provided by operating activities |  |  |  |  | $ | 534.9 |  |  | $ | 225.2 |  |
| Free cash flow (non-GAAP) |  |  |  |  | $ | 505.3 |  |  | $ | 178.0 |  |

[0001327567-20-000041:mdna:32]
[same as prior period, unchanged from 0001327567-20-000017:mdna:31]

[0001327567-20-000041:mdna:33]
•Billings. We define billings as total revenue plus the change in total deferred revenue, net of acquired deferred revenue, during the period. We consider billings to be a key metric used by management to manage our business given our hybrid SaaS revenue model, and believe billings provides investors with an important indicator of the health and visibility of our business because it includes subscription and support revenue, which is recognized ratably over the contractual service period, and product revenue, which is recognized at the time of shipment, provided that all other conditions for revenue recognition have been met. We consider billings to be a useful metric for management and investors, particularly if we

[0001327567-20-000041:mdna:34]
[same as prior period, unchanged from 0001327567-20-000017:mdna:11]

[0001327567-20-000041:mdna:35]
continue to experience increased sales of subscriptions and strong renewal rates for subscription and support offerings, and as we monitor our near-term cash flows. While we believe that billings provides useful information to investors and others in understanding and evaluating our operating results in the same manner as our management, it is important to note that other companies, including companies in our industry, may not use billings, may calculate billings differently, may have different billing frequencies, or may use other financial measures to evaluate their performance, all of which could reduce the usefulness of billings as a comparative measure. We calculate billings in the following manner:

[0001327567-20-000041:mdna:36]
|  |  |  | Three Months Ended October 31, |
|  |  |  |  |  | 2020 |  | 2019 |
|  |  |  | (in millions) |
| Billings: |  |  |  |  |  |  |  |
| Total revenue |  |  |  |  | $ | 946.0 |  |  | $ | 771.9 |  |
| Add: change in total deferred revenue, net of acquired deferred revenue |  |  |  |  | 136.8 |  |  | 125.5 |  |
| Billings |  |  |  |  | $ | 1,082.8 |  |  | $ | 897.4 |  |

[0001327567-20-000041:mdna:37]
•    Cash Flow Provided by Operating Activities. We monitor cash flow provided by operating activities as a measure of our overall business performance. Our cash flow provided by operating activities is driven in large part by sales of our products and from up-front payments for subscription and support offerings. Monitoring cash flow provided by operating activities enables us to analyze our financial performance without the non-cash effects of certain items such as depreciation, amortization, and share-based compensation costs, thereby allowing us to better understand and manage the cash needs of our business.

[0001327567-20-000041:mdna:38]
•    Free Cash Flow (non-GAAP). We define free cash flow, a non-GAAP financial measure, as cash provided by operating activities less purchases of property, equipment, and other assets. We consider free cash flow to be a profitability and liquidity measure that provides useful information to management and investors about the amount of cash generated by the business after necessary capital expenditures. A limitation of the utility of free cash flow as a measure of our financial performance and liquidity is that it does not represent the total increase or decrease in our cash balance for the period. In addition, it is important to note that other companies, including companies in our industry, may not use free cash flow, may calculate free cash flow in a different manner than we do, or may use other financial measures to evaluate their performance, all of which could reduce the usefulness of free cash flow as a comparative measure. A reconciliation of free cash flow to cash flow provided by operating activities, the most directly comparable financial measure calculated and presented in accordance with GAAP, is provided below:

[0001327567-20-000041:mdna:39]
|  | Three Months Ended October 31, |
|  | 2020 |  | 2019 |
|  | (in millions) |
| Free cash flow (non-GAAP): |  |  |  |
| Net cash provided by operating activities | $ | 534.9 |  |  | $ | 225.2 |  |
| Less: purchases of property, equipment, and other assets | 29.6 |  |  | 47.2 |  |
| Free cash flow (non-GAAP) | $ | 505.3 |  |  | $ | 178.0 |  |
| Net cash provided by (used in) investing activities | $ | (886.2) |  |  | $ | 244.5 |  |
| Net cash used in financing activities | $ | (464.5) |  |  | $ | (167.1) |  |

[0001327567-20-000041:mdna:40]
[same as prior period, unchanged from 0001327567-20-000017:mdna:23]

[0001327567-20-000041:mdna:41]
[same as prior period, unchanged from 0001327567-20-000017:mdna:40]

[0001327567-20-000041:mdna:42]
The following table summarizes our results of operations for the periods presented and as a percentage of our total revenue for those periods based on our condensed consolidated statements of operations data. The period-to-period comparison of results is not necessarily indicative of results for future periods.

[0001327567-20-000041:mdna:43]
|  |  |  | Three Months Ended October 31, |
|  |  |  |  |  | 2020 |  | 2019 |
|  |  |  |  |  |  |  |  |  | Amount |  | % of Revenue |  | Amount |  | % of Revenue |
|  |  |  |  |  |  |  |  |  | (dollars in millions) |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  |  |  |  |  |  |  |  | $ | 237.3 |  | 25.1 | % |  | $ | 231.2 |  |  | 30.0 | % |
| Subscription and support |  |  |  |  |  |  |  |  | 708.7 |  | 74.9 | % |  | 540.7 |  |  | 70.0 | % |
| Total revenue |  |  |  |  |  |  |  |  | 946.0 |  | 100.0 | % |  | 771.9 |  |  | 100.0 | % |
| Cost of revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  |  |  |  |  |  |  |  | 62.2 |  | 6.6 | % |  | 65.1 |  |  | 8.4 | % |
| Subscription and support |  |  |  |  |  |  |  |  | 215.6 |  | 22.8 | % |  | 152.6 |  |  | 19.8 | % |
| Total cost of revenue(1) |  |  |  |  |  |  |  |  | 277.8 |  | 29.4 | % |  | 217.7 |  |  | 28.2 | % |
| Total gross profit |  |  |  |  |  |  |  |  | 668.2 |  | 70.6 | % |  | 554.2 |  |  | 71.8 | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development |  |  |  |  |  |  |  |  | 237.4 |  | 25.1 | % |  | 170.5 |  |  | 22.1 | % |
| Sales and marketing |  |  |  |  |  |  |  |  | 388.6 |  | 41.0 | % |  | 365.7 |  |  | 47.4 | % |
| General and administrative |  |  |  |  |  |  |  |  | 86.7 |  | 9.2 | % |  | 69.8 |  |  | 9.0 | % |
| Total operating expenses(1) |  |  |  |  |  |  |  |  | 712.7 |  | 75.3 | % |  | 606.0 |  |  | 78.5 | % |
| Operating loss |  |  |  |  |  |  |  |  | (44.5) |  |  | (4.7) | % |  | (51.8) |  |  | (6.7) | % |
| Interest expense |  |  |  |  |  |  |  |  | (40.2) |  |  | (4.2) | % |  | (18.9) |  |  | (2.4) | % |
| Other income, net |  |  |  |  |  |  |  |  | 2.4 |  |  | 0.2 | % |  | 16.2 |  |  | 2.0 | % |
| Loss before income taxes |  |  |  |  |  |  |  |  | (82.3) |  |  | (8.7) | % |  | (54.5) |  |  | (7.1) | % |
| Provision for income taxes |  |  |  |  |  |  |  |  | 9.9 |  |  | 1.0 | % |  | 5.1 |  |  | 0.6 | % |
| Net loss |  |  |  |  |  |  |  |  | $ | (92.2) |  |  | (9.7) | % |  | $ | (59.6) |  |  | (7.7) | % |

[0001327567-20-000041:mdna:44]
[same as prior period, unchanged from 0001327567-20-000017:mdna:43]

[0001327567-20-000041:mdna:45]
[same as prior period, unchanged from 0001327567-20-000017:mdna:44]

[0001327567-20-000041:mdna:46]
|  |  |  | Three Months Ended October 31, |
|  |  |  |  |  | 2020 |  | 2019 |
|  |  |  |  |  | (in millions) |
| Cost of product revenue |  |  |  |  | $ | 1.5 |  |  | $ | 1.3 |  |
| Cost of subscription and support revenue |  |  |  |  | 22.2 |  |  | 18.9 |  |
| Research and development |  |  |  |  | 95.4 |  |  | 62.4 |  |
| Sales and marketing |  |  |  |  | 64.9 |  |  | 43.8 |  |
| General and administrative |  |  |  |  | 28.9 |  |  | 24.8 |  |
| Total share-based compensation |  |  |  |  | $ | 212.9 |  |  | $ | 151.2 |  |

[0001327567-20-000041:mdna:47]
[same as prior period, unchanged from 0001327567-20-000017:mdna:46]

[0001327567-20-000041:mdna:48]
[same as prior period, unchanged from 0001327567-20-000017:mdna:47]

[0001327567-20-000041:mdna:49]
[same as prior period, unchanged from 0001327567-20-000017:mdna:33]

[0001327567-20-000041:mdna:50]
[same as prior period, unchanged from 0001327567-20-000017:mdna:49]

[0001327567-20-000041:mdna:51]
[same as prior period, unchanged from 0001327567-20-000017:mdna:50]

[0001327567-20-000041:mdna:52]
|  |  |  |  |  |  |  | Three Months Ended October 31, |  |  |  |  |
|  |  |  |  |  |  |  | 2020 |  | 2019 |  | Change |
|  |  |  |  |  |  |  |  |  | Amount |  | Amount |  | Amount |  | % |
|  |  |  |  |  |  |  |  | (dollars in millions) |
| Product |  |  |  |  |  |  |  |  | $ | 237.3 |  |  | $ | 231.2 |  |  | $ | 6.1 |  |  | 2.6 | % |

[0001327567-20-000041:mdna:53]
The change in product revenue for the three months ended October 31, 2020 compared to the same period in 2019 represented a modest increase in product sales.

[0001327567-20-000041:mdna:54]
[same as prior period, unchanged from 0001327567-20-000017:mdna:53]

[0001327567-20-000041:mdna:55]
Subscription and support revenue is derived primarily from sales of our subscription and support offerings. Our contractual subscription and support contracts are typically one to five years. We recognize revenue from subscriptions and support over time as the services are performed. As a percentage of total revenue, we expect our subscription and support revenue to vary from quarter to quarter and to increase over the long term as we introduce new subscriptions, renew existing subscription and support contracts, and expand our installed end-customer base.

[0001327567-20-000041:mdna:56]
|  |  |  |  |  |  |  | Three Months Ended October 31, |  |  |  |  |
|  |  |  |  |  |  |  | 2020 |  | 2019 |  | Change |
|  |  |  |  |  |  |  |  |  | Amount |  | Amount |  | Amount |  | % |
|  |  |  |  |  |  |  |  |  | (dollars in millions) |
| Subscription |  |  |  |  |  |  |  |  | $ | 428.0 |  |  | $ | 318.6 |  |  | $ | 109.4 |  |  | 34.3 | % |
| Support |  |  |  |  |  |  |  |  | 280.7 |  |  | 222.1 |  |  | 58.6 |  |  | 26.4 | % |
| Total subscription and support |  |  |  |  |  |  |  |  | $ | 708.7 |  |  | $ | 540.7 |  |  | $ | 168.0 |  |  | 31.1 | % |

[0001327567-20-000041:mdna:57]
Subscription and support revenue increased for the three months ended October 31, 2020 compared to the same period in 2019. The increase was due to increased demand for our subscription and support offerings from both new and existing end-customers. The mix between subscription revenue and support revenue will fluctuate over time, depending on the introduction of new subscription offerings, renewals of support services, and our ability to increase sales to new and existing end-customers. The change in subscription and support revenue due to changes in pricing was not significant.

[0001327567-20-000041:mdna:58]
[same as prior period, unchanged from 0001327567-20-000017:mdna:57]

[0001327567-20-000041:mdna:59]
|  |  |  |  |  |  |  | Three Months Ended October 31, |  |  |  |  |
|  |  |  |  |  |  |  | 2020 |  | 2019 |  | Change |
|  |  |  |  |  |  |  |  |  | Amount |  | Amount |  | Amount |  | % |
|  |  |  |  |  |  |  |  |  | (dollars in millions) |
| Americas |  |  |  |  |  |  |  |  | $ | 670.3 |  |  | $ | 529.6 |  |  | $ | 140.7 |  |  | 26.6 | % |
| EMEA |  |  |  |  |  |  |  |  | 170.9 |  |  | 147.6 |  |  | 23.3 |  |  | 15.8 | % |
| APAC |  |  |  |  |  |  |  |  | 104.8 |  |  | 94.7 |  |  | 10.1 |  |  | 10.7 | % |
| Total revenue |  |  |  |  |  |  |  |  | $ | 946.0 |  |  | $ | 771.9 |  |  | $ | 174.1 |  |  | 22.6 | % |

[0001327567-20-000041:mdna:60]
With respect to geographic theaters, the increase in revenue for the three months ended October 31, 2020 compared to the same period in 2019 was driven primarily by the Americas, due to its larger and more established sales force. Revenue from our other geographic theaters, both Europe, the Middle East, and Africa (“EMEA”) and Asia Pacific and Japan (“APAC”), increased for the three months ended October 31, 2020 compared to the same period in 2019 due to continued investment in our global sales force in order to support our growth and innovation.

[0001327567-20-000041:mdna:61]
[same as prior period, unchanged from 0001327567-20-000017:mdna:60]

[0001327567-20-000041:mdna:62]
[same as prior period, unchanged from 0001327567-20-000017:mdna:61]

[0001327567-20-000041:mdna:63]
[same as prior period, unchanged from 0001327567-20-000017:mdna:39]

[0001327567-20-000041:mdna:64]
[same as prior period, unchanged from 0001327567-20-000017:mdna:63]

[0001327567-20-000041:mdna:65]
[same as prior period, unchanged from 0001327567-20-000017:mdna:64]

[0001327567-20-000041:mdna:66]
|  |  |  |  |  |  |  | Three Months Ended October 31, |  |  |  |  |
|  |  |  |  |  |  |  | 2020 |  | 2019 |  | Change |
|  |  |  |  |  |  |  |  |  | Amount |  | Amount |  | Amount |  | % |
|  |  |  |  |  |  |  |  |  | (dollars in millions) |
| Cost of product revenue |  |  |  |  |  |  |  |  | $ | 62.2 |  |  | $ | 65.1 |  |  | $ | (2.9) |  |  | (4.5) | % |
| Number of employees at period end |  |  |  |  |  |  |  |  | 114 |  |  | 108 |  |  | 6 |  |  | 5.6 | % |

[0001327567-20-000041:mdna:67]
Cost of product revenue decreased slightly for the three months ended October 31, 2020 compared to the same period in 2019, primarily due to product mix.

[0001327567-20-000041:mdna:68]
[same as prior period, unchanged from 0001327567-20-000017:mdna:67]

[0001327567-20-000041:mdna:69]
Cost of subscription and support revenue includes personnel costs for our global customer support and technical operations organizations, customer support and repair costs, third-party professional services costs, data center and cloud hosting service costs, amortization of acquired intangible assets and capitalized software development costs, and allocated costs. We expect our cost of subscription and support revenue to increase as our installed end-customer base grows and adoption of our cloud-based subscription offerings increases.

[0001327567-20-000041:mdna:70]
|  |  |  |  |  |  |  | Three Months Ended October 31, |  |  |  |  |
|  |  |  |  |  |  |  | 2020 |  | 2019 |  | Change |
|  |  |  |  |  |  |  |  |  | Amount |  | Amount |  | Amount |  | % |
|  |  |  |  |  |  |  |  |  | (dollars in millions) |
| Cost of subscription and support revenue |  |  |  |  |  |  |  |  | $ | 215.6 |  |  | $ | 152.6 |  |  | $ | 63.0 |  |  | 41.3 | % |
| Number of employees at period end |  |  |  |  |  |  |  |  | 1,569 |  |  | 1,288 |  |  | 281 |  |  | 21.8 | % |

[0001327567-20-000041:mdna:71]
Cost of subscription and support revenue increased for the three months ended October 31, 2020 compared to the same period in 2019, primarily due to increased costs to support the growth of our subscription and support offerings. Cloud hosting service costs, which support the adoption of our cloud-based subscription offerings, increased $26.2 million for the three months ended October 31, 2020 compared to the same period in 2019. Personnel costs grew $13.7 million to $87.6 million for the three months ended October 31, 2020 compared to the same period in 2019, primarily due to headcount growth. The remaining increase was primarily due to increases in outside service costs and amortization of internally developed software.

[0001327567-20-000041:mdna:72]
[same as prior period, unchanged from 0001327567-20-000017:mdna:71]

[0001327567-20-000041:mdna:73]
Gross margin, or gross profit as a percentage of revenue, has been and will continue to be affected by a variety of factors, including the introduction of new products, manufacturing costs, tariff costs, the average sales price of our products, cloud hosting service costs, personnel costs, the mix of products sold, and the mix of revenue between product and subscription and support offerings. For sales of our products, our higher-end firewall products generally have higher gross margins than our lower-end firewall products within each product series. We expect our gross margins to fluctuate over time depending on the factors described above.

[0001327567-20-000041:mdna:74]
|  |  |  | Three Months Ended October 31, |
|  |  |  |  |  | 2020 |  | 2019 |
|  |  |  |  |  |  |  |  |  | Amount |  | Gross Margin |  | Amount |  | Gross Margin |
|  |  |  |  |  |  |  |  |  | (dollars in millions) |
| Product |  |  |  |  |  |  |  |  | $ | 175.1 |  |  | 73.8 | % |  | $ | 166.1 |  |  | 71.8 | % |
| Subscription and support |  |  |  |  |  |  |  |  | 493.1 |  |  | 69.6 | % |  | 388.1 |  |  | 71.8 | % |
| Total gross profit |  |  |  |  |  |  |  |  | $ | 668.2 |  |  | 70.6 | % |  | $ | 554.2 |  |  | 71.8 | % |

[0001327567-20-000041:mdna:75]
Product gross margin increased for the three months ended October 31, 2020 compared to the same period in 2019, primarily due to product mix.

[0001327567-20-000041:mdna:76]
[same as prior period, unchanged from 0001327567-20-000017:mdna:48]

[0001327567-20-000041:mdna:77]
Subscription and support gross margin decreased for the three months ended October 31, 2020 compared to the same period in 2019, primarily due to an increase in costs to support our cloud-based subscription offerings.

[0001327567-20-000041:mdna:78]
[same as prior period, unchanged from 0001327567-20-000017:mdna:77]

[0001327567-20-000041:mdna:79]
Our operating expenses consist of research and development, sales and marketing, and general and administrative expense. Personnel costs are the most significant component of operating expenses and consist of salaries, benefits, bonuses, share-based compensation, travel and entertainment, and with regard to sales and marketing expense, sales commissions. Our operating expenses also include allocated costs, which consist of certain facilities, depreciation, benefits, recruiting, and information technology costs that we allocate based on headcount. We expect operating expenses generally to increase in absolute dollars and decrease over the long term as a percentage of revenue as we continue to scale our business. In response to COVID-19, we instituted a global work-from-home policy and limited employee travel beginning in March 2020. Further, we have canceled in-person events and either replaced them with virtual events or postponed them to future periods. As of October 31, 2020, we expect to recognize approximately $1.8 billion of share-based compensation expense over a weighted-average period of approximately 2.7 years, excluding additional share-based compensation expense related to any future grants of share-based awards. Share-based compensation expense is generally recognized on a straight-line basis over the requisite service periods of the awards.

[0001327567-20-000041:mdna:80]
[same as prior period, unchanged from 0001327567-20-000017:mdna:79]

[0001327567-20-000041:mdna:81]
Research and development expense consists primarily of personnel costs. Research and development expense also includes prototype-related expenses and allocated costs. We expect research and development expense to increase in absolute dollars as we continue to invest in our future products and services, although our research and development expense may fluctuate as a percentage of total revenue.

[0001327567-20-000041:mdna:82]
|  |  |  |  |  |  |  | Three Months Ended October 31, |  |  |  |  |
|  |  |  |  |  |  |  | 2020 |  | 2019 |  | Change |
|  |  |  |  |  |  |  |  |  | Amount |  | Amount |  | Amount |  | % |
|  |  |  |  |  |  |  |  |  | (dollars in millions) |
| Research and development |  |  |  |  |  |  |  |  | $ | 237.4 |  |  | $ | 170.5 |  |  | $ | 66.9 |  |  | 39.2 | % |
| Number of employees at period end |  |  |  |  |  |  |  |  | 1,943 |  |  | 1,598 |  |  | 345 |  |  | 21.6 | % |

[0001327567-20-000041:mdna:83]
Research and development expense increased for the three months ended October 31, 2020 compared to the same period in 2019, primarily due to personnel costs, which grew $54.8 million to $188.0 million. The increase in personnel costs was primarily due to headcount growth and accelerated vesting of certain equity awards.

[0001327567-20-000041:mdna:84]
[same as prior period, unchanged from 0001327567-20-000017:mdna:83]

[0001327567-20-000041:mdna:85]
Sales and marketing expense consists primarily of personnel costs, including commission expense. Sales and marketing expense also includes costs for market development programs, promotional and other marketing costs, professional services, and allocated costs. We continue to thoughtfully invest in headcount and have substantially grown our international sales presence. We expect sales and marketing expense to continue to increase in absolute dollars as we increase the size of our sales and marketing organizations to increase touch points with end-customers and to expand our international presence, although our sales and marketing expense may fluctuate as a percentage of total revenue.

[0001327567-20-000041:mdna:86]
|  |  |  |  |  |  |  | Three Months Ended October 31, |  |  |  |  |
|  |  |  |  |  |  |  | 2020 |  | 2019 |  | Change |
|  |  |  |  |  |  |  |  |  | Amount |  | Amount |  | Amount |  | % |
|  |  |  |  |  |  |  |  |  | (dollars in millions) |
| Sales and marketing |  |  |  |  |  |  |  |  | $ | 388.6 |  |  | $ | 365.7 |  |  | $ | 22.9 |  |  | 6.3 | % |
| Number of employees at period end |  |  |  |  |  |  |  |  | 3,855 |  |  | 3,557 |  |  | 298 |  |  | 8.4 | % |

[0001327567-20-000041:mdna:87]
Sales and marketing expense increased for the three months ended October 31, 2020 compared to the same period in 2019, primarily due to personnel costs, which grew $30.2 million to $293.3 million, and increased expenses for go-to-market initiatives, which were partially offset by a decrease in trade shows and convention expenses as in-person events were replaced with virtual events due to COVID-19. The increase in personnel costs was largely due to headcount growth, and partially offset by decreased travel expenses due to COVID-19.

[0001327567-20-000041:mdna:88]
[same as prior period, unchanged from 0001327567-20-000017:mdna:88]

[0001327567-20-000041:mdna:89]
General and administrative expense consists primarily of personnel costs for our executive, finance, human resources, legal, and information technology organizations, and professional services costs, which consist primarily of legal, auditing, accounting, and other consulting costs. General and administrative expense also includes certain non-recurring general expenses and impairment losses. Certain facilities, depreciation, benefits, recruiting, and information technology costs are allocated to other organizations based on

[0001327567-20-000041:mdna:90]
[same as prior period, unchanged from 0001327567-20-000017:mdna:62]

[0001327567-20-000041:mdna:91]
headcount. We expect general and administrative expense to increase in absolute dollars due to additional costs associated with accounting, compliance, and insurance, although our general and administrative expense may fluctuate as a percentage of total revenue.

[0001327567-20-000041:mdna:92]
|  |  |  |  |  |  |  | Three Months Ended October 31, |  |  |  |  |
|  |  |  |  |  |  |  | 2020 |  | 2019 |  | Change |
|  |  |  |  |  |  |  |  |  | Amount |  | Amount |  | Amount |  | % |
|  |  |  |  |  |  |  |  |  | (dollars in millions) |
| General and administrative |  |  |  |  |  |  |  |  | $ | 86.7 |  |  | $ | 69.8 |  |  | $ | 16.9 |  |  | 24.2 | % |
| Number of employees at period end |  |  |  |  |  |  |  |  | 895 |  |  | 831 |  |  | 64 |  |  | 7.7 | % |

[0001327567-20-000041:mdna:93]
General and administrative expense increased for the three months ended October 31, 2020 compared to the same period in 2019. Personnel costs increased $7.2 million to $53.5 million, primarily due to the accelerated vesting of certain equity awards in connection with our acquisitions. The remaining increase was due to increases in credit losses and acquisition-related costs.

[0001327567-20-000041:mdna:94]
[same as prior period, unchanged from 0001327567-20-000017:mdna:92]

[0001327567-20-000041:mdna:95]
Interest expense primarily consists of non-cash interest expense from the amortization of the debt discount and debt issuance costs related to our 0.75% Convertible Senior Notes due 2023 (the “2023 Notes”) and the 0.375% Convertible Senior Notes due 2025 (the “2025 Notes,” and together with “2023 Notes,” the “Notes”), and also includes the contractual interest expense related to our Notes.

[0001327567-20-000041:mdna:96]
|  |  |  |  |  | Three Months Ended October 31, |  |  |
|  |  |  |  |  |  |  | 2020 |  | 2019 |  | Change |
|  |  |  |  |  |  |  |  |  | Amount |  | Amount |  | Amount |  | % |
|  |  |  |  |  |  |  |  |  | (dollars in millions) |
| Interest expense |  |  |  |  |  |  |  |  | $ | 40.2 |  |  | $ | 18.9 |  |  | $ | 21.3 |  |  | 112.7 | % |

[0001327567-20-000041:mdna:97]
Interest expense increased for the three months ended October 31, 2020 compared to the same period in 2019 primarily due to our 2025 Notes issued in fiscal 2020. Refer to Note 10. Debt in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information on our Notes.

[0001327567-20-000041:mdna:98]
[same as prior period, unchanged from 0001327567-20-000017:mdna:97]

[0001327567-20-000041:mdna:99]
[same as prior period, unchanged from 0001327567-20-000017:mdna:98]

[0001327567-20-000041:mdna:100]
|  |  |  |  |  | Three Months Ended October 31, |  |  |
|  |  |  |  |  |  |  | 2020 |  | 2019 |  | Change |
|  |  |  |  |  |  |  |  |  | Amount |  | Amount |  | Amount |  | % |
|  |  |  |  |  |  |  |  |  | (dollars in millions) |
| Other income, net |  |  |  |  |  |  |  |  | $ | 2.4 |  |  | $ | 16.2 |  |  | $ | (13.8) |  |  | (85.2) | % |

[0001327567-20-000041:mdna:101]
Other income, net decreased for the three months ended October 31, 2020 compared to the same period in 2019. The decrease was primarily due to lower interest income earned on our cash, cash equivalents, and investments balances as a result of lower interest rates at October 31, 2020 compared to October 31, 2019.

[0001327567-20-000041:mdna:102]
[same as prior period, unchanged from 0001327567-20-000017:mdna:73]

[0001327567-20-000041:mdna:103]
[same as prior period, unchanged from 0001327567-20-000017:mdna:101]

[0001327567-20-000041:mdna:104]
Provision for income taxes consists primarily of income taxes in foreign jurisdictions in which we conduct business and withholding taxes. We maintain a full valuation allowance for domestic and certain foreign deferred tax assets, including net operating loss carryforwards and certain domestic tax credits. In recent years, we reorganized our corporate structure and intercompany relationships to more closely align with the international nature of our business activities. Our corporate structure has caused, and may continue to cause, disproportionate relationships between our overall effective tax rate and other jurisdictional measures. To the extent we revisit our corporate structure, it may have an impact on our tax provision.

[0001327567-20-000041:mdna:105]
|  |  |  |  |  | Three Months Ended October 31, |  | Change |
|  |  |  |  |  |  |  |  |  | 2020 |  | 2019 |  | Amount |  | % |
|  |  |  |  |  |  |  |  |  | (dollars in millions) |
| Provision for income taxes |  |  |  |  |  |  |  |  | $ | 9.9 |  |  | $ | 5.1 |  |  | $ | 4.8 |  |  | 94.1 | % |
| Effective tax rate |  |  |  |  |  |  |  |  | (12.0) | % |  | (9.4) | % |  |  |  |  |

[0001327567-20-000041:mdna:106]
We recorded an income tax provision for the three months ended October 31, 2020 primarily due to income taxes in profitable foreign jurisdictions and withholding taxes. Our provision for income taxes increased for the three months ended October 31, 2020 compared to the same period in 2019, primarily due to an increase in foreign income and withholding taxes. Refer to Note 14. Income Taxes in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information.

[0001327567-20-000041:mdna:107]
[same as prior period, unchanged from 0001327567-20-000017:mdna:105]

[0001327567-20-000041:mdna:108]
|  | October 31, 2020 |  | July 31, 2020 |
|  | (in millions) |
| Working capital | $ | 1,665.8 |  |  | $ | 2,437.5 |  |
| Cash, cash equivalents, and investments: |  |  |  |
| Cash and cash equivalents | $ | 2,142.0 |  |  | $ | 2,958.0 |  |
| Investments | 1,948.8 |  |  | 1,344.2 |  |
| Total cash, cash equivalents, and investments | $ | 4,090.8 |  |  | $ | 4,302.2 |  |

[0001327567-20-000041:mdna:109]
As of October 31, 2020, our total cash, cash equivalents, and investments of $4.1 billion were held for general corporate purposes, of which approximately $595.1 million was held outside of the United States. As of October 31, 2020, we had no unremitted earnings when evaluating our outside basis difference relating to our U.S. investment in foreign subsidiaries. However, there could be local withholding taxes payable due to various foreign countries if certain lower tier earnings are distributed. Withholding taxes that would be payable upon remittance of these lower tier earnings are not expected to be material.

[0001327567-20-000041:mdna:110]
In July 2018, we issued the 2023 Notes with an aggregate principal amount of $1.7 billion. In June 2020, we issued the 2025 Notes with an aggregate principal amount of $2.0 billion. The 2023 Notes mature on July 1, 2023 and the 2025 Notes mature on June 1, 2025; however, under certain circumstances, holders may surrender their Notes of a series for conversion prior to the applicable maturity date. Upon conversion of the Notes of a series, we will pay cash equal to the aggregate principal amount of the Notes of such series to be converted, and, at our election, will pay or deliver cash and/or shares of our common stock for the amount of our conversion obligation in excess of the aggregate principal amount of the Notes of such series being converted. As of October 31, 2020, all of our Notes remained outstanding. Refer to Note 10. Debt in Part I, Item 1 of this Quarterly Report on Form 10-Q for information on the Notes.

[0001327567-20-000041:mdna:111]
In September 2018, we entered into a credit agreement (the “Credit Agreement”) that provides for a $400.0 million unsecured revolving credit facility (the “Credit Facility”), with an option to increase the amount of the credit facility up to an additional $350.0 million, subject to certain conditions. As of October 31, 2020, there were no amounts outstanding and we were in compliance with all covenants under the Credit Agreement. Refer to Note 10. Debt in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information on the Credit Agreement.

[0001327567-20-000041:mdna:112]
In February 2019, our board of directors authorized a $1.0 billion share repurchase program which is funded from available working capital and will expire on December 31, 2020. During the three months ended October 31, 2020, we purchased 2.1 million shares for $500.0 million, leaving $301.9 million available for future share repurchases under this repurchase authorization. Refer to Note 12. Stockholders’ Equity in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information on our repurchase programs.

[0001327567-20-000041:mdna:113]
[same as prior period, unchanged from 0001327567-20-000017:mdna:85]

[0001327567-20-000041:mdna:114]
The following table summarizes our cash flows for the three months ended October 31, 2020 and 2019:

[0001327567-20-000041:mdna:115]
|  | Three Months Ended October 31, |
| 2020 |  | 2019 |
|  | (in millions) |
| Net cash provided by operating activities | $ | 534.9 |  |  | $ | 225.2 |  |
| Net cash provided by (used in) investing activities | (886.2) |  |  | 244.5 |  |
| Net cash used in financing activities | (464.5) |  |  | (167.1) |  |
| Net increase (decrease) in cash, cash equivalents, and restricted cash | $ | (815.8) |  |  | $ | 302.6 |  |

[0001327567-20-000041:mdna:116]
Cash from operations could be affected by various risks and uncertainties, including, but not limited to, the effects of COVID-19 and other risks detailed in Part II, Item 1A “Risk Factors” in this Form 10-Q. We believe that our cash flow from operations with existing cash and cash equivalents will be sufficient to meet our anticipated cash needs for at least the next 12 months and thereafter for the foreseeable future. Our future capital requirements will depend on many factors including our growth rate, the timing and extent of spending to support development efforts, the expansion of sales and marketing activities, the introduction of new and enhanced products and subscription and support offerings, the costs to acquire or invest in complementary businesses and technologies, the costs to ensure access to adequate manufacturing capacity, the investments in our infrastructure to support the adoption of our cloud-based subscription offerings, the investments in our new corporate headquarters, the continuing market acceptance of our products and subscription and support offerings, and macroeconomic events such as COVID-19. In addition, from time to time we may incur additional tax liability in connection with certain corporate structuring decisions.

[0001327567-20-000041:mdna:117]
[same as prior period, unchanged from 0001327567-20-000017:mdna:116]

[0001327567-20-000041:mdna:118]
[same as prior period, unchanged from 0001327567-20-000017:mdna:117]

[0001327567-20-000041:mdna:119]
[same as prior period, unchanged from 0001327567-20-000017:mdna:118]

[0001327567-20-000041:mdna:120]
Cash provided by operating activities during the three months ended October 31, 2020 was $534.9 million, an increase of $309.7 million compared to the same period in 2019. The increase was primarily due to growth of our business as reflected by an increase in billings, and an increase in collections during the three months ended October 31, 2020.

[0001327567-20-000041:mdna:121]
[same as prior period, unchanged from 0001327567-20-000017:mdna:120]

[0001327567-20-000041:mdna:122]
[same as prior period, unchanged from 0001327567-20-000017:mdna:121]

[0001327567-20-000041:mdna:123]
Cash used in investing activities during the three months ended October 31, 2020 was $886.2 million, a net change of $1.1 billion compared to cash provided by investing activities of $244.5 million during the same period in 2019. The change was primarily due to higher purchases of investments, an increase in net cash payments for business acquisitions and a decrease in proceeds from maturities of investments during fiscal 2020.

[0001327567-20-000041:mdna:124]
[same as prior period, unchanged from 0001327567-20-000017:mdna:125]

[0001327567-20-000041:mdna:125]
Our financing activities have consisted of cash used to repurchase shares of our common stock, and payments for tax withholding obligations of certain employees related to the net share settlement of equity awards.

[0001327567-20-000041:mdna:126]
Cash used in financing activities during the three months ended October 31, 2020 was $464.5 million, an increase of $297.4 million compared to the same period in 2019. The increase was primarily due to higher repurchases of our common stock during the three months ended October 31, 2020.

[0001327567-20-000041:mdna:127]
Contractual Obligations and Commitments

[0001327567-20-000041:mdna:128]
Except for those disclosed in Note 11. Commitments and Contingencies in Part I, Item 1 of this Quarterly Report on Form 10-Q, there have been no material changes outside of the ordinary course of business to our contractual obligations and commitments disclosed in our Annual Report on Form 10-K for the fiscal year ended July 31, 2020.

[0001327567-20-000041:mdna:129]
[same as prior period, unchanged from 0001327567-20-000017:mdna:128]

[0001327567-20-000041:mdna:130]
As of October 31, 2020, we did not have any relationships with unconsolidated organizations or financial partnerships, such as structured finance or special purpose entities that would have been established for the purpose of facilitating off-balance sheet arrangements or other contractually narrow or limited purposes.

[0001327567-20-000041:mdna:131]
[same as prior period, unchanged from 0001327567-20-000017:mdna:96]

[0001327567-20-000041:mdna:132]
[same as prior period, unchanged from 0001327567-20-000017:mdna:130]

[0001327567-20-000041:mdna:133]
Our condensed consolidated financial statements have been prepared in accordance with U.S. GAAP. The preparation of these condensed consolidated financial statements requires us to make estimates and assumptions that affect the reported amounts of assets, liabilities, revenue, expenses, and related disclosures. We base our estimates on historical experience and on various other assumptions that we believe are reasonable under the circumstances. These estimates and assumptions are affected by management’s application of accounting policies, as well as uncertainties, including the current economic environment due to the global impact of COVID-19. We evaluate our estimates and assumptions on an ongoing basis. Actual results may differ from these estimates. To the extent that there are material differences between these estimates and our actual results, our future financial statements will be affected.

[0001327567-20-000041:mdna:134]
We believe the critical accounting estimates discussed under Item 7, “Management’s Discussion and Analysis of Financial Condition and Results of Operations” in our Annual Report on Form 10-K for the fiscal year ended July 31, 2020 reflect our more significant judgments and estimates used in the preparation of our condensed consolidated financial statements. There have been no significant changes to our critical accounting estimates as filed in such report.

[0001327567-20-000041:mdna:135]
[same as prior period, unchanged from 0001327567-20-000017:mdna:133]

[0001327567-20-000041:mdna:136]
For a discussion of the recent accounting pronouncements, refer to “Recently Adopted Accounting Pronouncements” and “Recently Issued Accounting Pronouncements” in Note 1. Description of Business and Summary of Significant Accounting Policies in Part I, Item 1 of this Quarterly Report on Form 10-Q.
