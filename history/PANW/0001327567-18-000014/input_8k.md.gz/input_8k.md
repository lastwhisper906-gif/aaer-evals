# PANW 8-K — 0001327567-18-000011 filed 2018-06-04

## item codes, every 8-K on or before 2018-06-05

- 2018-06-04 0001327567-18-000011 — 2.02, 5.02, 9.01
- 2018-02-26 0001327567-18-000004 — 2.02, 5.02, 7.01, 9.01
- 2017-12-12 0001193125-17-367477 — 5.07
- 2017-11-20 0001327567-17-000032 — 2.02, 5.02, 9.01
- 2017-08-31 0001327567-17-000021 — 2.02, 5.02, 9.01
- 2017-05-31 0001327567-17-000016 — 2.02, 9.01
- 2017-02-28 0001327567-17-000005 — 2.02, 8.01, 9.01
- 2016-12-12 0001193125-16-790757 — 5.07
- 2016-11-21 0001327567-16-000071 — 2.02, 9.01
- 2016-10-24 0001193125-16-745121 — 5.02, 9.01
- 2016-08-30 0001327567-16-000057 — 2.02, 5.03, 8.01, 9.01
- 2016-08-22 0001193125-16-687588 — 5.02, 9.01
- 2016-05-26 0001327567-16-000051 — 2.02, 9.01
- 2016-02-25 0001327567-16-000044 — 2.02, 5.02, 9.01
- 2015-12-14 0001327567-15-000038 — 5.07
- 2015-12-14 0001193125-15-402588 — 1.01, 9.01
- 2015-11-23 0001327567-15-000033 — 2.02, 9.01
- 2015-10-19 0001193125-15-347005 — 1.01, 9.01 — amendment, the index does not say of what
- 2015-09-09 0001327567-15-000022 — 2.02, 9.01
- 2015-08-19 0001193125-15-296115 — 1.01, 2.03
- 2015-06-01 0001193125-15-207786 — 1.01, 2.03
- 2015-05-27 0001327567-15-000015 — 2.02, 9.01
- 2015-03-02 0001327567-15-000006 — 2.02, 9.01
- 2014-12-15 0001327567-14-000046 — 5.07
- 2014-11-24 0001327567-14-000040 — 2.02, 9.01
- 2014-09-22 0001193125-14-348581 — 5.02, 9.01
- 2014-09-09 0001327567-14-000025 — 2.02, 9.01
- 2014-07-01 0001193125-14-257824 — 1.01, 2.03, 3.02, 9.01
- 2014-06-26 0001193125-14-249529 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2014-06-20 0001327567-14-000020 — 9.01 — amendment of 0001193125-14-140511
- 2014-06-04 0001327567-14-000016 — 3.02
- 2014-05-30 0001193125-14-218158 — 2.02 — amendment, the index does not say of what
- 2014-05-28 0001193125-14-215060 — 1.01, 2.02, 3.02, 9.01
- 2014-04-11 0001193125-14-140511 — 2.01, 3.02, 7.01, 9.01
- 2014-03-24 0001193125-14-111318 — 1.01, 3.02, 7.01, 9.01
- 2014-03-13 0001327567-14-000009 — 5.02
- 2014-02-24 0001193125-14-063754 — 2.02, 9.01
- 2013-12-12 0001327567-13-000040 — 5.07
- 2013-11-25 0001327567-13-000033 — 2.02, 9.01
- 2013-09-30 0001193125-13-384966 — 8.01
- 2013-09-09 0001193125-13-361421 — 2.02, 9.01
- 2013-05-30 0001193125-13-241542 — 2.02, 5.02, 9.01
- 2013-03-11 0001193125-13-101082 — 5.02, 9.01
- 2013-02-28 0001193125-13-084193 — 2.02, 9.01
- 2012-12-14 0001193125-12-503335 — 5.07
- 2012-12-06 0001193125-12-493700 — 2.02, 9.01
- 2012-09-24 0001193125-12-401534 — 1.01, 2.03
- 2012-09-20 0001193125-12-398433 — 5.02, 9.01
- 2012-09-10 0001193125-12-386605 — 2.02, 9.01

## late-filing notifications on or before 2018-06-05

- none on or before 2018-06-05

## item 2.02 — earnings release, exhibit 99.1

[0001327567-18-000011:8k_2_02:1]
EX-99.1
4
ex991june1newsrelease.htm
EXHIBIT 99.1

[0001327567-18-000011:8k_2_02:2]
Exhibit

[0001327567-18-000011:8k_2_02:3]
Exhibit 99.1

[0001327567-18-000011:8k_2_02:4]
Palo Alto Networks Announces Record Revenues and Billings and Board Appoints Nikesh Arora as CEO and Chairman

[0001327567-18-000011:8k_2_02:5]
- Current CEO and chairman of the Board Mark McLaughlin to become vice chairman of the Board.

[0001327567-18-000011:8k_2_02:6]
- Company announces record revenue and billings for its fiscal third quarter 2018.

[0001327567-18-000011:8k_2_02:7]
- Company to hold full earnings call before markets open on Monday, June 4.

[0001327567-18-000011:8k_2_02:8]
SANTA CLARA, Calif. — June 1, 2018 — Palo Alto Networks® (NYSE: PANW), the global cybersecurity leader, today announced that its Board of Directors has named Nikesh Arora as its new chief executive officer and chairman of the Board of Directors, effective June 6, 2018.  He succeeds Mark McLaughlin, who is transitioning to the role of vice chairman of the Board for Palo Alto Networks.

[0001327567-18-000011:8k_2_02:9]
Arora formerly served as president and chief operating officer at SoftBank and as chief business officer at Google. At Google, Arora was instrumental in growing Google’s search business from $2 billion in revenues to over $60 billion in revenues, led more than 20,000 employees, and developed a substantial track record of driving innovation and delivering business success. Arora has extensive experience in scaling technology businesses, running very large organizations, and operating globally.

[0001327567-18-000011:8k_2_02:10]
McLaughlin said: “The company is executing extremely well and is the clear leader in next-generation security. Over the course of several quarters, I have been discussing succession planning with the Board and I couldn’t be more pleased that we have found a leader in Nikesh who is ideally suited to take the company on the next leg of its journey. I look forward to working with Nikesh as we transition and serving as vice chairman of the Board.”

[0001327567-18-000011:8k_2_02:11]
Daniel J. Warmenhoven, lead independent director said: “Mark has been an outstanding leader whose strong leadership was critical to building the company into the fastest-growing enterprise cybersecurity company in the world and we are grateful for his contributions. As we move forward in this era of digital and security transformation, there is no better person to lead Palo Alto Networks than Nikesh Arora. The Board of Directors is very pleased to have such a proven business and technology leader who brings demonstrated leadership and ability to scale to the company.”

[0001327567-18-000011:8k_2_02:12]
Added Arora: “I am thrilled and honored to join Palo Alto Networks. I have developed a deep appreciation for the company’s culture, values and pioneering spirit as innovators and disruptors and I look forward to working with the entire Palo Alto Networks team on our mission of protecting our customers in the digital age.”

[0001327567-18-000011:8k_2_02:13]
The company also announced the following strong fiscal third quarter 2018 results, and will hold its earnings call before the market opens on Monday, June 4th.

[0001327567-18-000011:8k_2_02:14]
In the fiscal third quarter, total revenue grew 31 percent year over year to $567.1 million, product revenue grew 31 percent year over year to $215.2 million, and billings grew 33 percent year over year to $721.0 million.

[0001327567-18-000011:8k_2_02:15]
Kathy Bonanno, chief financial officer commented: “We had a strong fiscal third quarter 2018 and will be reporting top line and bottom line results above all our third quarter guided ranges.”

[0001327567-18-000011:8k_2_02:16]
Conference Call Information

[0001327567-18-000011:8k_2_02:17]
Palo Alto Networks will host a conference call for analysts and investors to discuss its fiscal third quarter 2018 results and outlook for its fiscal fourth quarter and full fiscal year 2018 on Monday, June 4th before the market opens. A separate news release will be issued with the conference call details.

[0001327567-18-000011:8k_2_02:18]
Forward-Looking Statements

[0001327567-18-000011:8k_2_02:19]
This press release contains forward-looking statements that involve risks and uncertainties, including statements regarding the company’s transition to a new chief executive officer and Mark McLaughlin’s transition to vice chairman of the Board. There are a significant number of factors that could cause actual results to differ materially from statements made in this press release, including: our limited operating history; our ability as an organization to acquire and integrate other companies, products or technologies in a successful manner; risks associated with managing our rapid growth; the risks associated with new products and subscription and support offerings, including the discovery of software bugs; organizational changes and the timing of these changes; our ability to attract and retain new customers; delays in the development or release of new subscription offerings, or the failure to timely develop and achieve market acceptance of new products and subscriptions as well as existing products and subscription and support offerings; rapidly evolving technological developments in the market for network

[0001327567-18-000011:8k_2_02:20]
1

[0001327567-18-000011:8k_2_02:21]
security products and subscription and support offerings; length of sales cycles; and general market, political, economic and business conditions.

[0001327567-18-000011:8k_2_02:22]
About Palo Alto Networks

[0001327567-18-000011:8k_2_02:23]
We are the global cybersecurity leader, known for always challenging the security status quo. Our mission is to protect our way of life in the digital age by preventing successful cyberattacks. This has given us the privilege of safely enabling tens of thousands of organizations and their customers. Our pioneering Security Operating Platform emboldens their digital transformation with continuous innovation that seizes the latest breakthroughs in security, automation, and analytics. By delivering a true platform and empowering a growing ecosystem of change-makers like us, we provide highly effective and innovative cybersecurity across clouds, networks, and mobile devices.

[0001327567-18-000011:8k_2_02:24]
Palo Alto Networks and the Palo Alto Networks logo are trademarks of Palo Alto Networks, Inc. in the United States and in jurisdictions throughout the world. All other trademarks, trade names or service marks used or mentioned herein belong to their respective owners.

[0001327567-18-000011:8k_2_02:25]
Media contact:

[0001327567-18-000011:8k_2_02:26]
Kristen Batch 
Senior Vice President of Corporate Communications, Palo Alto Networks 
Mobile: 503-516-6297 
kbatch@paloaltonetworks.com

[0001327567-18-000011:8k_2_02:27]
Investor Relations Contact:

[0001327567-18-000011:8k_2_02:28]
Amber Ossman 
Director, Investor Relations, Palo Alto Networks 
Work: 408-753-4235

[0001327567-18-000011:8k_2_02:29]
aossman@paloaltonetworks.com

[0001327567-18-000011:8k_2_02:30]
2

[0001327567-18-000011:8k_2_02:31]
| Palo Alto Networks, Inc. |
| Calculation of Billings |
| (In millions) |
| (Unaudited) |
|  | Three Months Ended |  | Nine Months Ended |
|  | April 30, |  | April 30, |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Total revenue | $ | 567.1 |  |  | $ | 431.8 |  |  | $ | 1,615.0 |  |  | $ | 1,252.5 |  |
| Add: change in total deferred revenue, net of acquired deferred revenue | 153.9 |  |  | 112.3 |  |  | 377.1 |  |  | 370.1 |  |
| Billings | $ | 721.0 |  |  | $ | 544.1 |  |  | $ | 1,992.1 |  |  | $ | 1,622.6 |  |

[0001327567-18-000011:8k_2_02:32]
3

## item 5.02 — body, verbatim

[0001327567-18-000011:8k_body:1]
Item 5.02 Departure of Directors or Certain Officers; Election of Directors; Appointment of Certain Officers; Compensatory Arrangements of Certain Officers.

[0001327567-18-000011:8k_body:2]
Mark McLaughlin

[0001327567-18-000011:8k_body:3]
On May 30, 2018, Mark McLaughlin informed the Board of Directors (the “Board”) of his retirement as Chief Executive Officer and Chairman of the Board, effective June 6, 2018. Mr. McLaughlin will continue to be an employee of the Company and serve on the Board as Vice Chairman, effective June 6, 2018. In connection with Mr. McLaughlin’s retirement as Chief Executive Officer, the Company entered into a new offer letter with Mr. McLaughlin on May 31, 2018 (the “New Offer Letter”). Under the terms of the New Offer Letter, (1) Mr. McLaughlin’s base salary will continue at an annualized rate of $900,000 until August 1, 2018 and thereafter shall be reduced to an annualized rate of $500,000, (2) Mr. McLaughlin will continue to be eligible to receive his target annual bonus of 100% for fiscal 2018, based on achievement of certain objectives, and after August 1, 2018, shall no longer be eligible to earn a bonus, and (3) in the event that the Company or its successor terminates Mr. McLaughlin’s service without “cause” (as defined in the New Offer Letter), then Mr. McLaughlin will be eligible to receive twenty-four months accelerated vesting of his then-outstanding time based equity awards, subject to his signing a release of claims.

[0001327567-18-000011:8k_body:4]
The foregoing description of Mr. McLaughlin’s compensation and terms and conditions of his ongoing employment is qualified in its entirety by the full text of Mr. McLaughlin’s New Offer Letter, which is filed as Exhibit 10.1 to this Current Report on Form 8-K and incorporated herein by reference.

[0001327567-18-000011:8k_body:5]
Nikesh Arora

[0001327567-18-000011:8k_body:6]
On May 30, 2018, the Board appointed Nikesh Arora as the next Chief Executive Officer, effective as of June 6, 2018. The Board also increased the size of the Board from eleven to twelve directors and elected Mr. Arora to serve as a Class III member of the Board and Chairman of the Board, effective as of June 6, 2018.

[0001327567-18-000011:8k_body:7]
Prior to joining the Company, from 2016 through 2018 Mr. Arora, age 50, was an angel investor and from June 2016 through December 2017, Mr. Arora served as an advisor to SoftBank Group Corp., a multinational conglomerate company (“SoftBank”). From July 2015 through June 2016, Mr. Arora served as president and chief operating officer of SoftBank and from July 2014 through June 2015, Mr. Arora served as vice chairman and chief executive officer of SoftBank Internet and Media, a subsidiary of SoftBank. Prior to SoftBank, from December 2004 through July 2014, Mr. Arora held multiple senior leadership operating roles at Google, Inc., including serving as senior vice president and chief business officer, from January 2011 to June 2014. Mr. Arora also serves on the board of Compagnie Financiere Richemont S.A., a public Switzerland-based luxury goods holding company. Mr. Arora previously served on the boards of Sprint Corp., a communications services company, from November 2014 to June 2016, Colgate-Palmolive Company, a worldwide consumer products company focused on the production, distribution and provision of household, health care and personal care products, from March 2012 to September 2014, SoftBank from 2014 to 2016, and Yahoo! Japan, an internet company, from 2015 to 2016. Mr. Arora holds an M.S. in Business Administration from Northeastern University, an M.S. in Finance from Boston College, and a B.Tech in electrical engineering from the Institute of Technology at Banaras Hindu University.

[0001327567-18-000011:8k_body:8]
Mr. Arora was chosen to serve on the Company’s Board due to his extensive experience scaling technology businesses and executive leadership at leading edge technology companies.

[0001327567-18-000011:8k_body:9]
The Company entered into an offer letter with Mr. Arora on May 30, 2018 (the “Offer Letter”), in connection with Mr. Arora’s appointment as Chief Executive Officer. The Offer Letter provides that effective upon his start date, Mr. Arora’s annual base salary will be $1,000,000 and his target annual incentive compensation will be 100% of his base salary. In addition, Mr. Arora will receive the following:

[0001327567-18-000011:8k_body:10]
•

[0001327567-18-000011:8k_body:11]
a time-based restricted stock unit award (the “Time-Based RSU”) having an approximate value of $40,000,000, with the number of shares to be determined based on the average closing price of the Company’s stock for the 30 trading days ending on June 5, 2018. The Time-Based RSUs will vest over a 7-year period with a 1-year cliff and quarterly vesting thereafter, subject to Mr. Arora’s continued service.

[0001327567-18-000011:8k_body:12]
•

[0001327567-18-000011:8k_body:13]
contingent upon Mr. Arora’s purchase of $20,000,000 worth of Company common stock on the public market within generally 30 days following his start date (the “Investment Shares”), a number of restricted stock units equal to the number of Investment Shares, up to $20,000,000 aggregate value (the “Investment RSUs”). The Investment RSUs shall vest over a 4-year period with a 1-year cliff and quarterly vesting thereafter, subject to Mr. Arora’s continued service and Mr. Arora holding all of the Investment Shares through each vesting date. If Mr. Arora ceases to hold all of the Investment Shares until June 6, 2022, Mr. Arora will forfeit all of the Investment RSUs.

[0001327567-18-000011:8k_body:14]
•

[0001327567-18-000011:8k_body:15]
a performance-based stock option to purchase a number of shares of the Company’s common stock that results in an approximate aggregate grant date fair value for financial accounting purposes of $66,000,000 (the “Performance Option”). If the number of shares determined per the preceding sentence would result in an option to purchase less than 1,046,000 shares of the Company’s common stock, then the Performance Option will be with respect to 1,046,000 shares. The Performance Option will have a per share exercise price equal to the fair market value of a share of the Company’s common stock on the grant date (the “Baseline Price”), which is expected to be June 7, 2018. Shares subject to the Performance Option become eligible to vest (the “Eligible Option Shares”) upon achievement of certain stock price targets (the “Stock Price Achievements”) as set forth below:

[0001327567-18-000011:8k_body:16]
% of Performance Option becoming Eligible Option Shares

[0001327567-18-000011:8k_body:17]
Stock Price Achievement in Excess of Baseline Price

[0001327567-18-000011:8k_body:18]
Time to Achieve

[0001327567-18-000011:8k_body:19]
Expiration of Option

[0001327567-18-000011:8k_body:20]
25%

[0001327567-18-000011:8k_body:21]
150%

[0001327567-18-000011:8k_body:22]
4 years

[0001327567-18-000011:8k_body:23]
7 years

[0001327567-18-000011:8k_body:24]
25%

[0001327567-18-000011:8k_body:25]
200%

[0001327567-18-000011:8k_body:26]
5 years

[0001327567-18-000011:8k_body:27]
7 years

[0001327567-18-000011:8k_body:28]
25%

[0001327567-18-000011:8k_body:29]
250%

[0001327567-18-000011:8k_body:30]
6 years

[0001327567-18-000011:8k_body:31]
7 years

[0001327567-18-000011:8k_body:32]
25%

[0001327567-18-000011:8k_body:33]
300%

[0001327567-18-000011:8k_body:34]
7 years

[0001327567-18-000011:8k_body:35]
7.5 years

[0001327567-18-000011:8k_body:36]
To the extent that Stock Price Achievements have been met, Eligible Option Shares will vest as to one-fourth (1/4) of the shares on each anniversary of the Performance Option grant date, subject to Mr. Arora’s continued service. Upon a “Change in Control” (as defined in the Offer Letter) the price payable to Company stockholders at closing will be the final Stock Price Achievement.

[0001327567-18-000011:8k_body:37]
The equity grants described above will be granted under the Company’s 2012 Equity Incentive Plan.

[0001327567-18-000011:8k_body:38]
In the event that there is a “Change in Control” of the Company and the Company or the Company’s successor terminates Mr. Arora’s employment other than for “Cause” or Mr. Arora terminates his employment for “Good Reason” (each as defined in the Offer Letter), in either case upon or within 12 months following a “Change in Control,” then Mr. Arora will be entitled to receive (subject to signing a release of claims):

[0001327567-18-000011:8k_body:39]
•

[0001327567-18-000011:8k_body:40]
a lump sum payment equal to his then-current annual base salary, 100% of his incentive compensation for that fiscal year and reimbursement of 12 months of COBRA premiums;

[0001327567-18-000011:8k_body:41]
•

[0001327567-18-000011:8k_body:42]
accelerated vesting of the Time-Based RSUs and Investment RSUs as to the greater of: (x) 50% of unvested shares or (y) shares that would vest through the date 24 months after termination of employment; and

[0001327567-18-000011:8k_body:43]
•

[0001327567-18-000011:8k_body:44]
accelerated vesting of 100% of Eligible Option Shares subject to the Performance Option.

[0001327567-18-000011:8k_body:45]
In the event, that Mr. Arora’s employment is terminated by the Company other than for “Cause,” at any time before a “Change in Control” or more than 12 months following a “Change in Control,” then Mr. Arora will be entitled to receive:

[0001327567-18-000011:8k_body:46]
•

[0001327567-18-000011:8k_body:47]
continued payment of his then-current base salary for a period of 12 months and reimbursement of 12 months of COBRA premiums; and

[0001327567-18-000011:8k_body:48]
•

[0001327567-18-000011:8k_body:49]
accelerated vesting of the Time-Based RSUs, Investment RSUs and Eligible Option Shares for shares that would vest through the date 12 months after termination of employment.

[0001327567-18-000011:8k_body:50]
The foregoing description of Mr. Arora’s compensation, terms and conditions of his employment and treatment of Mr. Arora upon certain terminations of employment is qualified in its entirety by the full text of Mr. Arora’s Offer Letter, which is filed as Exhibit 10.2 to this Current Report on Form 8-K and incorporated herein by reference.

[0001327567-18-000011:8k_body:51]
In addition, Mr. Arora has entered into the Company’s standard form of indemnification agreement, a copy of which has been filed as Exhibit 10.1 to the Company’s Registration Statement on Form S-1 (File No. 333-180620) filed with the Securities and Exchange Commission on July 9, 2012.

[0001327567-18-000011:8k_body:52]
There is no arrangement or understanding between Mr. Arora and any other persons pursuant to which Mr. Arora was elected as Chief Executive Officer or as a director. There are no family relationships between Mr. Arora and any director or executive officer of the Company, and he has no direct or indirect material interest in any transaction required to be disclosed pursuant to Item 404(a) of Regulation S-K.
