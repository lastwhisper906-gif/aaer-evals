# PANW note change history — 0001327567-18-000006 → 0001327567-18-000014


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- added (2018-06-05):
[0001327567-18-000014:note_history:1]
In September 2012, we entered into two lease agreements for a total of approximately 300,000 square feet of space in Santa Clara, California, which served as our previous corporate headquarters through August 2017, when we relocated to our new corporate campus. The leases contain rent holiday periods and two separate five-year options to extend the lease terms beyond their expiration dates of July 2023. Rental payments under these lease agreements are approximately $94.3 million over the lease term. In August 2017, we exited our previous headquarter facilities and relocated to our new corporate campus, which resulted in the recognition of a cease-use loss of $15.4 million during the three months ended October 31, 2017. Due to the changes in market conditions in recent months, we recognized an additional cease-use loss of $23.8 million during the three months ended April 30, 2018, based on changes to the amount and timing of estimated cash flows from sublease rentals that could be reasonably obtained. The total cease-use loss of $39.2 million, recognized as general and administrative expense in our condensed consolidated statements of operations during the nine months ended April 30, 2018, and a corresponding liability in our condensed consolidated balance sheets, was calculated as the present value of the excess of the remaining lease obligation for the vacated facilities, adjusted for the effects of any deferred items recognized under the leases and related costs, over the estimated sublease rentals that could be reasonably obtained. The amount of the cease-use loss may vary if the timing or amount of estimated cash flows change. During the three and nine months ended April 30, 2018, we released $2.8 million and $7.4 million, respectively, of the cease-use liability through rental payments. As of April 30, 2018, the remaining balance of the cease-use liability was $31.8 million, which is expected to be paid through the end of the lease term in July 2023.

- changed (2018-06-05):
[0001327567-18-000014:note_history:2]
The following table presents details of the aggregate future non-cancelable minimum rental payments under our operating leases as of April 30, 2018 (in millions):
  (was, 2018-02-27, similarity 0.9747):
[0001327567-18-000006:note_history:2]
The following table presents details of the aggregate future non-cancelable minimum rental payments under our operating leases as of January 31, 2018 (in millions):

- changed (2018-06-05):
[0001327567-18-000014:note_history:3]
Our electronics manufacturing service provider (“EMS provider”) procures components and assembles our products based on our forecasts. These forecasts are based on estimates of demand for our products primarily for the next 12 months, which are in turn based on historical trends and an analysis from our sales and product management organizations, adjusted for overall market conditions. In order to reduce manufacturing lead times and plan for adequate supply, we may issue non-cancelable orders for products and components to our manufacturing partners or component suppliers. As of April 30, 2018, our purchase commitments under such orders were $142.7 million, excluding obligations under contracts that we can cancel without a significant penalty.
  (was, 2018-02-27, similarity 0.9919):
[0001327567-18-000006:note_history:3]
Our electronics manufacturing service provider (“EMS provider”) procures components and assembles our products based on our forecasts. These forecasts are based on estimates of demand for our products primarily for the next 12 months, which are in turn based on historical trends and an analysis from our sales and product management organizations, adjusted for overall market conditions. In order to reduce manufacturing lead times and plan for adequate supply, we may issue non-cancelable orders for products and components to our manufacturing partners or component suppliers. As of January 31, 2018, our purchase commitments under such orders were $121.5 million, excluding obligations under contracts that we can cancel without a significant penalty.

- added (2018-06-05):
[0001327567-18-000014:note_history:4]
Other Purchase Commitments

- added (2018-06-05):
[0001327567-18-000014:note_history:5]
In March 2018, we amended an agreement with a third-party provider for our use of certain cloud services through June 2020. Under the non-cancelable addendum, we are committed to a minimum purchase of $14.0 million between April 2018 and March 2019 and $8.0 million between April 2019 and March 2020. As of April 30, 2018, our purchase commitment under the addendum was $22.0 million.

- added (2018-06-05):
[0001327567-18-000014:note_history:6]
To the extent there is a reasonable possibility that a loss exceeding amounts already recognized may be incurred and the amount of such additional loss would be material, we will either disclose the estimated additional loss or state that such an estimate cannot be made. As of April 30, 2018, we have not recorded any significant accruals for loss contingencies associated with such legal proceedings, determined that an unfavorable outcome is probable or reasonably possible, or determined that the amount or range of any possible loss is reasonably estimable.

- removed (2018-06-05):
[0001327567-18-000006:note_history:7]
In September 2012, we entered into two lease agreements for a total of approximately 300,000 square feet of space in Santa Clara, California, which served as our previous corporate headquarters through August 2017, when we relocated to our new corporate campus. The leases contain rent holiday periods and two separate five-year options to extend the lease terms beyond their expiration dates of July 2023. Rental payments under these lease agreements are approximately $94.3 million over the lease term. In August 2017, we exited our previous headquarter facilities and relocated to our new corporate campus, which resulted in the recognition of a cease-use loss of $15.4 million as general administrative expense in our condensed consolidated statements of operations during the three months ended October 31, 2017, and a corresponding liability in our condensed consolidated balance sheets. The cease-use loss of $15.4 million was calculated as the present value of the excess of the remaining lease obligation for the vacated facilities, adjusted for the effects of any deferred items recognized under the leases and related costs, over the estimated sublease rentals that could be reasonably obtained. The amount of the cease-use loss may vary if the timing or amount of estimated cash flows change. During the three and six months ended January 31, 2018, we released $2.7 million and $4.6 million, respectively, of the cease-use liability through rental payments. As of January 31, 2018, the remaining balance of the cease-use liability was $10.8 million, which is expected to be paid through the end of the lease term in July 2023.

- removed (2018-06-05):
[0001327567-18-000006:note_history:8]
To the extent there is a reasonable possibility that a loss exceeding amounts already recognized may be incurred and the amount of such additional loss would be material, we will either disclose the estimated additional loss or state that such an estimate cannot be made. As of January 31, 2018, we have not recorded any significant accruals for loss contingencies associated with such legal proceedings, determined that an unfavorable outcome is probable or reasonably possible, or determined that the amount or range of any possible loss is reasonably estimable.


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2018-06-05):
[0001327567-18-000014:note_history:9]
Palo Alto Networks, Inc. (the “Company,” “we,” “us,” or “our”), located in Santa Clara, California, was incorporated in March 2005 under the laws of the State of Delaware and commenced operations in April 2005. We offer a security operating platform that empowers enterprises, service providers, and government entities to secure their organizations by safely enabling applications running in their networks, on their endpoints, and in the cloud, and by preventing breaches that stem from targeted cyberattacks.
  (was, 2018-02-27, similarity 0.9149):
[0001327567-18-000006:note_history:9]
Palo Alto Networks, Inc. (the “Company,” “we,” “us,” or “our”), located in Santa Clara, California, was incorporated in March 2005 under the laws of the State of Delaware and commenced operations in April 2005. We offer a next-generation security platform that empowers enterprises, service providers, and government entities to secure their organizations by safely enabling applications running on their networks and by preventing breaches that stem from targeted cyberattacks.

- changed (2018-06-05):
[0001327567-18-000014:note_history:10]
There have been no material changes to our significant accounting policies as of and for the nine months ended April 30, 2018, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended July 31, 2017.
  (was, 2018-02-27, similarity 0.9058):
[0001327567-18-000006:note_history:10]
There have been no material changes to our significant accounting policies as of and for the six months ended January 31, 2018, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended July 31, 2017.

- changed (2018-06-05):
[0001327567-18-000014:note_history:11]
In October 2016, the FASB issued authoritative guidance requiring the recognition of income tax consequences of an intra-entity transfer of an asset, other than inventory, when the transfer occurs. The standard is effective for us in our first quarter of fiscal 2019 and will be applied on a modified retrospective basis through a cumulative-effect adjustment to accumulated deficit as of the date of adoption. Early adoption is permitted. We plan to adopt the standard in our first quarter of fiscal 2019. The adoption of this standard may have a material impact on our condensed consolidated financial statements, subject to any potential intra-entity transfers of assets (excluding inventory) and additional guidance and interpretations issued by U.S. regulatory and standard-setting bodies related to the Tax Cuts and Jobs Act (“TCJA”) enacted into law on December 22, 2017. Refer to Note 11. Income Taxes for more information on the TCJA.
  (was, 2018-02-27, similarity 0.9494):
[0001327567-18-000006:note_history:11]
In October 2016, the FASB issued authoritative guidance requiring the recognition of income tax consequences of an intra-entity transfer of an asset, other than inventory, when the transfer occurs. The standard is effective for us in our first quarter of fiscal 2019 and will be applied on a modified retrospective basis. Early adoption is permitted. We plan to adopt the standard in our first quarter of fiscal 2019. The adoption of this standard may have a material impact on our condensed consolidated financial statements, subject to any potential intra-entity transfers of assets (excluding inventory) and additional guidance and interpretations issued by U.S. regulatory and standard-setting bodies related to the Tax Cuts and Jobs Act (“TCJA”) enacted into law on December 22, 2017. Refer to Note 9. Income Taxes for more information on the TCJA.

- added (2018-06-05):
[0001327567-18-000014:note_history:12]
We will adopt the standard in our first quarter of fiscal 2019 using the full retrospective method and are on schedule with the preparation of our relevant prior-period financial statements.

- changed (2018-06-05):
[0001327567-18-000014:note_history:13]
We are also continuing to evaluate the impact the standard will have on our condensed consolidated financial statements and disclosures, including reviewing the provisions of our customer contracts and identifying performance obligations under the requirements of the new standard, and comparing to our current accounting policies and practices. Although we have not yet determined whether the effect will be material, we believe the new standard will impact our accounting for revenue arrangements in the following areas:
  (was, 2018-02-27, similarity 0.9844):
[0001327567-18-000006:note_history:13]
We are also continuing to evaluate the impact the standard will have on our condensed consolidated financial statements, including reviewing the provisions of our customer contracts and identifying performance obligations under the requirements of the new standard, and comparing to our current accounting policies and practices. Although we have not yet determined whether the effect will be material, we believe the new standard will impact our accounting for revenue arrangements in the following areas:

- changed (2018-06-05):
[0001327567-18-000014:note_history:14]
| • | amortization period for incremental costs to obtain or fulfill customer contracts. |
  (was, 2018-02-27, similarity 0.6154):
[0001327567-18-000006:note_history:14]
| • | amortization period for deferred commissions. |

- added (2018-06-05):
[0001327567-18-000014:note_history:15]
The exact impact of the new standard will be dependent on facts and circumstances at adoption and could vary from quarter to quarter.

- removed (2018-06-05):
[0001327567-18-000006:note_history:16]
We will adopt the standard in our first quarter of fiscal 2019 using the full retrospective method. However, our ability to apply the full retrospective method is dependent on system readiness and the completion of our analysis of information necessary to restate prior-period financial statements.

- removed (2018-06-05):
[0001327567-18-000006:note_history:17]
We will continue to assess the new standard along with industry trends and additional interpretive guidance, and may adjust our implementation plan accordingly.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2018-06-05):
[0001327567-18-000014:note_history:18]
Palo Alto Networks, Inc. (the “Company,” “we,” “us,” or “our”), located in Santa Clara, California, was incorporated in March 2005 under the laws of the State of Delaware and commenced operations in April 2005. We offer a security operating platform that empowers enterprises, service providers, and government entities to secure their organizations by safely enabling applications running in their networks, on their endpoints, and in the cloud, and by preventing breaches that stem from targeted cyberattacks.
  (was, 2018-02-27, similarity 0.9149):
[0001327567-18-000006:note_history:18]
Palo Alto Networks, Inc. (the “Company,” “we,” “us,” or “our”), located in Santa Clara, California, was incorporated in March 2005 under the laws of the State of Delaware and commenced operations in April 2005. We offer a next-generation security platform that empowers enterprises, service providers, and government entities to secure their organizations by safely enabling applications running on their networks and by preventing breaches that stem from targeted cyberattacks.

- changed (2018-06-05):
[0001327567-18-000014:note_history:19]
There have been no material changes to our significant accounting policies as of and for the nine months ended April 30, 2018, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended July 31, 2017.
  (was, 2018-02-27, similarity 0.9058):
[0001327567-18-000006:note_history:19]
There have been no material changes to our significant accounting policies as of and for the six months ended January 31, 2018, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended July 31, 2017.


## us-gaap:ConvertibleDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-06-05):
[0001327567-18-000014:note_history:20]
The following table sets forth the components of the Notes as of April 30, 2018 and July 31, 2017 (in millions):
  (was, 2018-02-27, similarity 0.9612):
[0001327567-18-000006:note_history:20]
The following table sets forth the components of the Notes as of January 31, 2018 and July 31, 2017 (in millions):

- changed (2018-06-05):
[0001327567-18-000014:note_history:21]
|  | April 30, 2018 |  | July 31, 2017 |
| Liability: |  |  |  |
| Principal | $ | 575.0 |  |  | $ | 575.0 |  |
| Less: debt discount and debt issuance costs, net of amortization | 31.2 |  |  | 50.3 |  |
| Net carrying amount | $ | 543.8 |  |  | $ | 524.7 |  |
| Equity (including temporary equity) | $ | 109.8 |  |  | $ | 109.8 |  |
  (was, 2018-02-27, similarity 0.9783):
[0001327567-18-000006:note_history:21]
|  | January 31, 2018 |  | July 31, 2017 |
| Liability: |  |  |  |
| Principal | $ | 575.0 |  |  | $ | 575.0 |  |
| Less: debt discount and debt issuance costs, net of amortization | 37.6 |  |  | 50.3 |  |
| Net carrying amount | $ | 537.4 |  |  | $ | 524.7 |  |
| Equity (including temporary equity) | $ | 109.8 |  |  | $ | 109.8 |  |


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-06-05):
[0001327567-18-000014:note_history:22]
On or after January 1, 2019, holders may convert all or any portion of their Notes at any time prior to the close of business on the second scheduled trading day immediately preceding the maturity date regardless of the foregoing conditions. Upon conversion, holders will receive cash equal to the aggregate principal amount of the Notes to be converted, and, at our election, cash and/or shares of our common stock for any amounts in excess of the aggregate principal amount of the Notes being converted. As of April 30, 2018, all of the Notes remained outstanding.
  (was, 2018-02-27, similarity 0.9892):
[0001327567-18-000006:note_history:22]
On or after January 1, 2019, holders may convert all or any portion of their Notes at any time prior to the close of business on the second scheduled trading day immediately preceding the maturity date regardless of the foregoing conditions. Upon conversion, holders will receive cash equal to the aggregate principal amount of the Notes to be converted, and, at our election, cash and/or shares of our common stock for any amounts in excess of the aggregate principal amount of the Notes being converted. As of January 31, 2018, all of the Notes remained outstanding.

- added (2018-06-05):
[0001327567-18-000014:note_history:23]
The sale price condition was met during the fiscal quarter ended April 30, 2018, and as a result, holders may convert their Notes at any time during the fiscal quarter ending July 31, 2018. Accordingly, the net carrying amount of the Notes was reclassified into current liabilities and the portion of the equity component representing the conversion option was reclassified into temporary equity in our condensed consolidated balance sheets as of April 30, 2018. The portion of the equity component classified as temporary equity is measured as the difference between the principal and net carrying amount of the Notes, excluding debt issuance costs. The sale price condition was not met during the fiscal quarter ended July 31, 2017. Since the Notes were not convertible, the net carrying amount of the Notes was classified as a long-term liability and the equity component was included in additional paid-in capital in our condensed consolidated balance sheets as of July 31, 2017.

- changed (2018-06-05):
[0001327567-18-000014:note_history:24]
The following table sets forth the components of the Notes as of April 30, 2018 and July 31, 2017 (in millions):
  (was, 2018-02-27, similarity 0.9612):
[0001327567-18-000006:note_history:24]
The following table sets forth the components of the Notes as of January 31, 2018 and July 31, 2017 (in millions):

- changed (2018-06-05):
[0001327567-18-000014:note_history:25]
|  | April 30, 2018 |  | July 31, 2017 |
| Liability: |  |  |  |
| Principal | $ | 575.0 |  |  | $ | 575.0 |  |
| Less: debt discount and debt issuance costs, net of amortization | 31.2 |  |  | 50.3 |  |
| Net carrying amount | $ | 543.8 |  |  | $ | 524.7 |  |
| Equity (including temporary equity) | $ | 109.8 |  |  | $ | 109.8 |  |
  (was, 2018-02-27, similarity 0.9783):
[0001327567-18-000006:note_history:25]
|  | January 31, 2018 |  | July 31, 2017 |
| Liability: |  |  |  |
| Principal | $ | 575.0 |  |  | $ | 575.0 |  |
| Less: debt discount and debt issuance costs, net of amortization | 37.6 |  |  | 50.3 |  |
| Net carrying amount | $ | 537.4 |  |  | $ | 524.7 |  |
| Equity (including temporary equity) | $ | 109.8 |  |  | $ | 109.8 |  |

- added (2018-06-05):
[0001327567-18-000014:note_history:26]
The total estimated fair value of the Notes was $1.0 billion and $747.5 million at April 30, 2018 and July 31, 2017, respectively. The fair value was determined based on the closing trading price per $100 of the Notes as of the last day of trading for the period. We consider the fair value of the Notes at April 30, 2018 and July 31, 2017 to be a Level 2 measurement. The fair value of the Notes is primarily affected by the trading price of our common stock and market interest rates. As of April 30, 2018, the if-converted value of the Notes exceeded its principal amount by $406.8 million.

- changed (2018-06-05):
[0001327567-18-000014:note_history:27]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 30, |  | April 30, |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Amortization of debt discount | $ | 5.7 |  |  | $ | 5.5 |  |  | $ | 17.1 |  |  | $ | 16.4 |  |
| Amortization of debt issuance costs | 0.8 |  |  | 0.7 |  |  | 2.1 |  |  | 1.9 |  |
| Total interest expense recognized | $ | 6.5 |  |  | $ | 6.2 |  |  | $ | 19.2 |  |  | $ | 18.3 |  |
| Effective interest rate of the liability component | 4.8 | % |  | 4.8 | % |  | 4.8 | % |  | 4.8 | % |
  (was, 2018-02-27, similarity 0.9472):
[0001327567-18-000006:note_history:27]
|  | Three Months Ended |  | Six Months Ended |
|  | January 31, |  | January 31, |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Amortization of debt discount | $ | 5.8 |  |  | $ | 5.5 |  |  | $ | 11.4 |  |  | $ | 10.9 |  |
| Amortization of debt issuance costs | 0.6 |  |  | 0.6 |  |  | 1.3 |  |  | 1.2 |  |
| Total interest expense recognized | $ | 6.4 |  |  | $ | 6.1 |  |  | $ | 12.7 |  |  | $ | 12.1 |  |
| Effective interest rate of the liability component | 4.8 | % |  | 4.8 | % |  | 4.8 | % |  | 4.8 | % |

- removed (2018-06-05):
[0001327567-18-000006:note_history:28]
The sale price condition was met during the fiscal quarter ended January 31, 2018, and as a result, holders may convert their Notes at any time during the fiscal quarter ending April 30, 2018. Accordingly, the net carrying amount of the Notes was reclassified into current liabilities and the portion of the equity component representing the conversion option was reclassified into temporary equity in our condensed consolidated balance sheets as of January 31, 2018. The portion of the equity component classified as temporary equity is measured as the difference between the principal and net carrying amount of the Notes, excluding debt issuance costs. The sale price condition was not met during the fiscal quarter ended July 31, 2017. Since the Notes were not convertible, the net carrying amount of the Notes was classified as a long-term liability and the equity component was included in additional paid-in capital in our condensed consolidated balance sheets as of July 31, 2017.

- removed (2018-06-05):
[0001327567-18-000006:note_history:29]
The total estimated fair value of the Notes was $839.6 million and $747.5 million at January 31, 2018 and July 31, 2017, respectively. The fair value was determined based on the closing trading price per $100 of the Notes as of the last day of trading for the period. We consider the fair value of the Notes at January 31, 2018 and July 31, 2017 to be a Level 2 measurement. The fair value of the Notes is primarily affected by the trading price of our common stock and market interest rates. As of January 31, 2018, the if-converted value of the Notes exceeded its principal amount by $218.2 million.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-06-05):
[0001327567-18-000014:note_history:30]
The following tables summarize the amortized cost, unrealized gains and losses, and fair value of our available-for-sale securities as of April 30, 2018 and July 31, 2017 (in millions):
  (was, 2018-02-27, similarity 0.9773):
[0001327567-18-000006:note_history:30]
The following tables summarize the amortized cost, unrealized gains and losses, and fair value of our available-for-sale securities as of January 31, 2018 and July 31, 2017 (in millions):

- added (2018-06-05):
[0001327567-18-000014:note_history:31]
|  | April 30, 2018 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Estimated Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Money market funds | $ | 361.8 |  |  | $ | — |  |  | $ | — |  |  | $ | 361.8 |  |
| Commercial paper | 32.1 |  |  | — |  |  | — |  |  | 32.1 |  |
| Corporate debt securities | 1.0 |  |  | — |  |  | — |  |  | 1.0 |  |
| U.S. government and agency securities | 129.6 |  |  | — |  |  | — |  |  | 129.6 |  |
| Total cash equivalents | $ | 524.5 |  |  | $ | — |  |  | $ | — |  |  | $ | 524.5 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 5.4 |  |  | $ | — |  |  | $ | — |  |  | $ | 5.4 |  |
| Corporate debt securities | 283.9 |  |  | 0.1 |  |  | (2.8 | ) |  | 281.2 |  |
| U.S. government and agency securities | 987.6 |  |  | — |  |  | (9.1 | ) |  | 978.5 |  |
| Total investments | $ | 1,276.9 |  |  | $ | 0.1 |  |  | $ | (11.9 | ) |  | $ | 1,265.1 |  |

- changed (2018-06-05):
[0001327567-18-000014:note_history:32]
Unrealized losses related to these securities are due to interest rate fluctuations as opposed to credit quality. In addition, we do not intend to sell and it is not likely that we would be required to sell these securities before recovery of their amortized cost basis, which may be at maturity. As a result, there were no other-than-temporary impairments for these securities at April 30, 2018 and July 31, 2017.
  (was, 2018-02-27, similarity 0.9851):
[0001327567-18-000006:note_history:32]
Unrealized losses related to these securities are due to interest rate fluctuations as opposed to credit quality. In addition, we do not intend to sell and it is not likely that we would be required to sell these securities before recovery of their amortized cost basis, which may be at maturity. As a result, there were no other-than-temporary impairments for these securities at January 31, 2018 and July 31, 2017.

- changed (2018-06-05):
[0001327567-18-000014:note_history:33]
The following table summarizes the amortized cost and fair value of our available-for-sale securities as of April 30, 2018, by contractual years-to-maturity (in millions):
  (was, 2018-02-27, similarity 0.9759):
[0001327567-18-000006:note_history:33]
The following table summarizes the amortized cost and fair value of our available-for-sale securities as of January 31, 2018, by contractual years-to-maturity (in millions):

- removed (2018-06-05):
[0001327567-18-000006:note_history:34]
|  | January 31, 2018 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Estimated Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Money market funds | $ | 325.7 |  |  | $ | — |  |  | $ | — |  |  | $ | 325.7 |  |
| U.S. government and agency securities | 3.5 |  |  | — |  |  | — |  |  | 3.5 |  |
| Total cash equivalents | $ | 329.2 |  |  | $ | — |  |  | $ | — |  |  | $ | 329.2 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 5.4 |  |  | $ | — |  |  | $ | — |  |  | $ | 5.4 |  |
| Corporate debt securities | 352.1 |  |  | 0.1 |  |  | (2.1 | ) |  | 350.1 |  |
| U.S. government and agency securities | 1,095.4 |  |  | — |  |  | (7.9 | ) |  | 1,087.5 |  |
| Total investments | $ | 1,452.9 |  |  | $ | 0.1 |  |  | $ | (10.0 | ) |  | $ | 1,443.0 |  |
