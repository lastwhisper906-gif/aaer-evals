# PANW MD&A — 0001327567-18-000014


## mdna

[0001327567-18-000014:mdna:1]
[same as prior period, unchanged from 0001327567-18-000006:mdna:1]

[0001327567-18-000014:mdna:2]
[same as prior period, unchanged from 0001327567-18-000006:mdna:2]

[0001327567-18-000014:mdna:3]
[same as prior period, unchanged from 0001327567-18-000006:mdna:3]

[0001327567-18-000014:mdna:4]
[same as prior period, unchanged from 0001327567-18-000006:mdna:4]

[0001327567-18-000014:mdna:5]
| • | Results of Operations. A discussion of the nature and trends in our financial results and an analysis of our financial results comparing the three and nine months ended April 30, 2018 to the three and nine months ended April 30, 2017. |

[0001327567-18-000014:mdna:6]
[same as prior period, unchanged from 0001327567-18-000006:mdna:6]

[0001327567-18-000014:mdna:7]
| • | Contractual Obligations and Commitments. An overview of our contractual obligations, contingent liabilities, commitments, and off-balance sheet arrangements outstanding as of April 30, 2018, including expected payment schedules. |

[0001327567-18-000014:mdna:8]
[same as prior period, unchanged from 0001327567-18-000006:mdna:8]

[0001327567-18-000014:mdna:9]
[same as prior period, unchanged from 0001327567-18-000006:mdna:9]

[0001327567-18-000014:mdna:10]
[same as prior period, unchanged from 0001327567-18-000006:mdna:10]

[0001327567-18-000014:mdna:11]
We have pioneered the next generation of security through our innovative security operating platform that empowers enterprises, service providers, and government entities to secure their organizations by safely enabling applications and data running in their networks, on their endpoints, and in the cloud, and by preventing breaches that stem from targeted cyberattacks. Our platform uses an innovative traffic classification engine that identifies network traffic by application, user, and content and provides consistent security across the network, endpoint, and cloud. Accordingly, our platform enables our end-customers to pursue transformative digital initiatives, like public cloud and mobility, that grow their business, while maintaining the visibility and control needed to protect their valued data and critical control systems. We believe our platform offers superior performance compared to legacy approaches and reduces the total cost of ownership for organizations by simplifying their security operations and infrastructure and eliminating the need for multiple, stand-alone security hardware and software security products.

[0001327567-18-000014:mdna:12]
[same as prior period, unchanged from 0001327567-18-000006:mdna:32]

[0001327567-18-000014:mdna:13]
Our platform consists of four major elements:

[0001327567-18-000014:mdna:14]
| • | Security for networks through our Next-Generation Firewalls, available as physical appliances, virtual appliances (called VM-Series), or a cloud-delivered service (called GlobalProtect cloud service) and Panorama management delivered as an appliance or as a virtual machine for the public or private cloud. |

[0001327567-18-000014:mdna:15]
| • | Security for endpoints through our Traps advanced endpoint protection software, delivered as a light-weight software agent with cloud or on-premise management capabilities. |

[0001327567-18-000014:mdna:16]
| • | Security for the cloud through our VM-Series for in-line protection of workloads in public and private clouds, Traps for host-based public cloud infrastructure protection, Evident for infrastructure monitoring and compliance in public clouds, and Aperture for protecting SaaS applications. These products are delivered as software or SaaS applications. |

[0001327567-18-000014:mdna:17]
| • | Cloud-delivered security services, such as WildFire, Threat Prevention, URL Filtering, and GlobalProtect subscriptions that are delivered as attached software services to our appliances, as well as applications delivered in connection with our Application Framework, such as AutoFocus, Magnifier, and Logging Service that are delivered as SaaS applications. |

[0001327567-18-000014:mdna:18]
For the third quarter of fiscal 2018 and 2017, total revenue was $567.1 million and $431.8 million, respectively, representing year-over-year growth of 31.3%. Our growth reflects the increased adoption of our hybrid SaaS revenue model, which consists of product, subscriptions, and support. We believe this model will enable us to benefit from recurring revenues as we continue to grow our installed end-customer base. As of April 30, 2018, we had approximately 51,000 end-customers in over 150 countries. Our end-customers represent a broad range of industries, including education, energy, financial services, government entities, healthcare, Internet and media, manufacturing, public sector, and telecommunications, and include some of the largest Fortune 100 and Global 2000 companies in the world. We maintain a field sales force that works closely with our channel partners in developing sales opportunities. We use a two-tiered, indirect fulfillment model whereby we sell our products, subscriptions, and support to our distributors, which, in turn, sell to our resellers, which then sell to our end-customers.

[0001327567-18-000014:mdna:19]
Our product revenue was $215.2 million, or 37.9% of total revenue, for the third quarter of fiscal 2018, representing year-over-year growth of 31.1%. Product revenue is generated from sales of our appliances, primarily our Next-Generation Firewall, which is available in physical and virtualized form. Our Next-Generation Firewall incorporates our proprietary PAN-OS operating system, which provides a consistent set of capabilities across our entire product line. Our products are designed for different performance requirements throughout an organization, ranging from our PA-200, which is designed for enterprise remote offices, to our top-of-the-line PA-7080, which is especially suited for very large enterprise deployments and service provider customers. The same firewall functionality that is delivered in our physical appliances is also available in our VM-Series virtual firewalls, which secure virtualized and cloud-based computing environments.

[0001327567-18-000014:mdna:20]
Our subscription and support revenue was $351.9 million, or 62.1% of total revenue, for the third quarter of fiscal 2018, representing year-over-year growth of 31.5%. Our subscriptions provide our end-customers with real-time access to the latest antivirus, intrusion prevention, web filtering, and modern malware prevention capabilities across the network, endpoints, and the cloud. When end-customers purchase our physical or virtual firewall appliances, they typically purchase support in order to receive ongoing security updates, upgrades, bug fixes, and repairs. In addition to the subscriptions purchased with these appliances, end-customers may also purchase other subscriptions on a per-user, per-endpoint, or capacity-based basis.

[0001327567-18-000014:mdna:21]
We continue our investment in innovation as we evolve and further extend the capabilities of our platform, as we believe that innovation and timely development of new features and products is essential to meeting the needs of our end-customers and improving our competitive position. We introduced several new offerings during the first three quarters of fiscal 2018, including:

[0001327567-18-000014:mdna:22]
| • | our GlobalProtect cloud service subscription, which provides our Security Operating Platform as a cloud-based service for remote offices and mobile users; |

[0001327567-18-000014:mdna:23]
| • | our Logging Service subscription, which functions as the central cloud-based repository for application data and logs generated by our security offerings, including those of our firewalls and GlobalProtect cloud service subscription, and allows end-customers to collect data without needing to plan for local processing power and storage; |

[0001327567-18-000014:mdna:24]
| • | Magnifier, a cloud-based subscription that enables organizations to identify and prevent behavior-based threats by applying machine learning to rich network, endpoint, and cloud data; |

[0001327567-18-000014:mdna:25]
| • | PAN-OS 8.1, with over 60 new features, and several new models of appliances, including the PA-3200 series, which increase SSL decryption throughput, bring higher performance and capacity for securing large data centers, and provide additional capabilities for managing large firewall deployments; and |

[0001327567-18-000014:mdna:26]
| • | Traps 5.0, which included a cloud-delivered management service and integration with our Logging Service to allow for the collection of detailed endpoint event data. |

[0001327567-18-000014:mdna:27]
We also expanded the capabilities of our platform with extended protections to the Google Cloud Platform and enhanced capabilities for AWS and Azure environments to enable customers to easily integrate with their cloud infrastructure and workloads in

[0001327567-18-000014:mdna:28]
[same as prior period, unchanged from 0001327567-18-000006:mdna:39]

[0001327567-18-000014:mdna:29]
multi-cloud environments. Further, in March 2018, we acquired Evident.io, Inc. (“Evident.io”), which expands our API-based security capabilities for the public cloud with the addition of Evident.io’s cloud services infrastructure protection technology, and, in April 2018, we acquired Cyber Secdo Ltd. (“Secdo”), which expands the functionality of our platform by adding endpoint detection and response capabilities, including unique data collection and visualization.

[0001327567-18-000014:mdna:30]
We believe that the growth of our business and our short-term and long-term success are dependent upon many factors, including our ability to extend our technology leadership, grow our base of end-customers, expand deployment of our platform and support offerings within existing end-customers, and focus on end-customer satisfaction. To manage any future growth effectively, we must continue to improve and expand our information technology and financial infrastructure, our operating and administrative systems and controls, and our ability to manage headcount, capital, and processes in an efficient manner. While these areas present significant opportunities for us, they also pose challenges and risks that we must successfully address in order to sustain the growth of our business and improve our operating results. For additional information regarding the challenges and risks we face, see the “Risk Factors” section in Part II, Item 1A of this Quarterly Report on Form 10-Q.

[0001327567-18-000014:mdna:31]
[same as prior period, unchanged from 0001327567-18-000006:mdna:20]

[0001327567-18-000014:mdna:32]
[same as prior period, unchanged from 0001327567-18-000006:mdna:21]

[0001327567-18-000014:mdna:33]
|  | April 30, 2018 |  | July 31, 2017 |
|  | (in millions) |
| Total deferred revenue | $ | 2,154.9 |  |  | $ | 1,773.5 |  |
| Cash, cash equivalents, and investments | $ | 2,214.1 |  |  | $ | 2,164.3 |  |

[0001327567-18-000014:mdna:34]
|  | Three Months Ended April 30, |  | Nine Months Ended April 30, |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |
|  | (dollars in millions) |
| Total revenue | $ | 567.1 |  |  | $ | 431.8 |  |  | $ | 1,615.0 |  |  | $ | 1,252.5 |  |
| Total revenue year-over-year percentage increase | 31.3 | % |  | 24.9 | % |  | 28.9 | % |  | 28.1 | % |
| Gross margin | 71.8 | % |  | 71.4 | % |  | 71.5 | % |  | 73.0 | % |
| Operating loss | $ | (51.6 | ) |  | $ | (49.1 | ) |  | $ | (137.7 | ) |  | $ | (152.5 | ) |
| Operating margin | (9.1 | )% |  | (11.4 | )% |  | (8.5 | )% |  | (12.2 | )% |
| Billings | $ | 721.0 |  |  | $ | 544.1 |  |  | $ | 1,992.1 |  |  | $ | 1,622.6 |  |
| Billings year-over-year percentage increase | 32.5 | % |  | 11.9 | % |  | 22.8 | % |  | 21.7 | % |
| Cash flow provided by operating activities |  |  |  |  | $ | 759.1 |  |  | $ | 629.0 |  |
| Free cash flow (non-GAAP) |  |  |  |  | $ | 672.5 |  |  | $ | 514.8 |  |

[0001327567-18-000014:mdna:35]
[same as prior period, unchanged from 0001327567-18-000006:mdna:24]

[0001327567-18-000014:mdna:36]
[same as prior period, unchanged from 0001327567-18-000006:mdna:25]

[0001327567-18-000014:mdna:37]
[same as prior period, unchanged from 0001327567-18-000006:mdna:52]

[0001327567-18-000014:mdna:38]
|  | Three Months Ended April 30, |  | Nine Months Ended April 30, |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |
|  | (in millions) |
| Billings: |  |  |  |  |  |  |  |
| Total revenue | $ | 567.1 |  |  | $ | 431.8 |  |  | $ | 1,615.0 |  |  | $ | 1,252.5 |  |
| Add: change in total deferred revenue, net of acquired deferred revenue | 153.9 |  |  | 112.3 |  |  | 377.1 |  |  | 370.1 |  |
| Billings | $ | 721.0 |  |  | $ | 544.1 |  |  | $ | 1,992.1 |  |  | $ | 1,622.6 |  |

[0001327567-18-000014:mdna:39]
| • | Cash Flow Provided by Operating Activities. We monitor cash flow provided by operating activities as a measure of our overall business performance. Our cash flow provided by operating activities is driven in large part by sales of our products and from up-front payments for subscription and support offerings. Monitoring cash flow provided by operating activities enables us to analyze our financial performance without the non-cash effects of certain items such as depreciation, amortization, and share-based compensation costs, thereby allowing us to better understand and manage the cash needs of our business. |

[0001327567-18-000014:mdna:40]
[same as prior period, unchanged from 0001327567-18-000006:mdna:30]

[0001327567-18-000014:mdna:41]
|  | Nine Months Ended April 30, |
|  | 2018 |  | 2017 |
|  | (in millions) |
| Free cash flow (non-GAAP): |  |  |  |
| Net cash provided by operating activities | $ | 759.1 |  |  | $ | 629.0 |  |
| Less: purchases of property, equipment, and other assets | 86.6 |  |  | 114.2 |  |
| Free cash flow (non-GAAP) | $ | 672.5 |  |  | $ | 514.8 |  |
| Net cash used in investing activities | $ | (313.6 | ) |  | $ | (411.1 | ) |
| Net cash used in financing activities | $ | (240.8 | ) |  | $ | (260.3 | ) |

[0001327567-18-000014:mdna:42]
[same as prior period, unchanged from 0001327567-18-000006:mdna:66]

[0001327567-18-000014:mdna:43]
[same as prior period, unchanged from 0001327567-18-000006:mdna:33]

[0001327567-18-000014:mdna:44]
[same as prior period, unchanged from 0001327567-18-000006:mdna:34]

[0001327567-18-000014:mdna:45]
|  | Three Months Ended April 30, |  | Nine Months Ended April 30, |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |
|  | Amount |  | % of Revenue |  | Amount |  | % of Revenue |  | Amount |  | % of Revenue |  | Amount |  | % of Revenue |
|  | (dollars in millions) |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 215.2 |  |  | 37.9 | % |  | $ | 164.2 |  |  | 38.0 | % |  | $ | 603.9 |  |  | 37.4 | % |  | $ | 496.8 |  |  | 39.7 | % |
| Subscription and support | 351.9 |  |  | 62.1 | % |  | 267.6 |  |  | 62.0 | % |  | 1,011.1 |  |  | 62.6 | % |  | 755.7 |  |  | 60.3 | % |
| Total revenue | 567.1 |  |  | 100.0 | % |  | 431.8 |  |  | 100.0 | % |  | 1,615.0 |  |  | 100.0 | % |  | 1,252.5 |  |  | 100.0 | % |
| Cost of revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product | 68.9 |  |  | 12.1 | % |  | 49.7 |  |  | 11.5 | % |  | 190.4 |  |  | 11.8 | % |  | 137.7 |  |  | 11.0 | % |
| Subscription and support | 91.0 |  |  | 16.1 | % |  | 74.0 |  |  | 17.1 | % |  | 270.2 |  |  | 16.7 | % |  | 200.4 |  |  | 16.0 | % |
| Total cost of revenue(1) | 159.9 |  |  | 28.2 | % |  | 123.7 |  |  | 28.6 | % |  | 460.6 |  |  | 28.5 | % |  | 338.1 |  |  | 27.0 | % |
| Total gross profit | 407.2 |  |  | 71.8 | % |  | 308.1 |  |  | 71.4 | % |  | 1,154.4 |  |  | 71.5 | % |  | 914.4 |  |  | 73.0 | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | 99.6 |  |  | 17.6 | % |  | 86.0 |  |  | 19.9 | % |  | 290.4 |  |  | 18.0 | % |  | 260.1 |  |  | 20.8 | % |
| Sales and marketing | 277.1 |  |  | 48.8 | % |  | 226.9 |  |  | 52.5 | % |  | 800.6 |  |  | 49.5 | % |  | 673.7 |  |  | 53.8 | % |
| General and administrative | 82.1 |  |  | 14.5 | % |  | 44.3 |  |  | 10.4 | % |  | 201.1 |  |  | 12.5 | % |  | 133.1 |  |  | 10.6 | % |
| Total operating expenses(1) | 458.8 |  |  | 80.9 | % |  | 357.2 |  |  | 82.8 | % |  | 1,292.1 |  |  | 80.0 | % |  | 1,066.9 |  |  | 85.2 | % |
| Operating loss | (51.6 | ) |  | (9.1 | )% |  | (49.1 | ) |  | (11.4 | )% |  | (137.7 | ) |  | (8.5 | )% |  | (152.5 | ) |  | (12.2 | )% |
| Interest expense | (6.5 | ) |  | (1.1 | )% |  | (6.2 | ) |  | (1.4 | )% |  | (19.2 | ) |  | (1.2 | )% |  | (18.3 | ) |  | (1.5 | )% |
| Other income, net | 8.6 |  |  | 1.5 | % |  | 2.1 |  |  | 0.5 | % |  | 18.3 |  |  | 1.1 | % |  | 7.3 |  |  | 0.6 | % |
| Loss before income taxes | (49.5 | ) |  | (8.7 | )% |  | (53.2 | ) |  | (12.3 | )% |  | (138.6 | ) |  | (8.6 | )% |  | (163.5 | ) |  | (13.1 | )% |
| Provision for (benefit from) income taxes | (2.8 | ) |  | (0.5 | )% |  | 7.7 |  |  | 1.8 | % |  | 7.0 |  |  | 0.4 | % |  | 14.9 |  |  | 1.1 | % |
| Net loss | $ | (46.7 | ) |  | (8.2 | )% |  | $ | (60.9 | ) |  | (14.1 | )% |  | $ | (145.6 | ) |  | (9.0 | )% |  | $ | (178.4 | ) |  | (14.2 | )% |

[0001327567-18-000014:mdna:46]
[same as prior period, unchanged from 0001327567-18-000006:mdna:36]

[0001327567-18-000014:mdna:47]
[same as prior period, unchanged from 0001327567-18-000006:mdna:37]

[0001327567-18-000014:mdna:48]
|  | Three Months Ended April 30, |  | Nine Months Ended April 30, |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Cost of product revenue | $ | 1.7 |  |  | $ | 1.8 |  |  | $ | 5.5 |  |  | $ | 5.5 |  |
| Cost of subscription and support revenue | 15.1 |  |  | 14.0 |  |  | 50.9 |  |  | 41.3 |  |
| Research and development | 35.4 |  |  | 37.1 |  |  | 108.4 |  |  | 116.4 |  |
| Sales and marketing | 50.7 |  |  | 46.2 |  |  | 155.2 |  |  | 139.7 |  |
| General and administrative | 20.8 |  |  | 18.3 |  |  | 60.2 |  |  | 55.1 |  |
| Total share-based compensation | $ | 123.7 |  |  | $ | 117.4 |  |  | $ | 380.2 |  |  | $ | 358.0 |  |

[0001327567-18-000014:mdna:49]
[same as prior period, unchanged from 0001327567-18-000006:mdna:79]

[0001327567-18-000014:mdna:50]
[same as prior period, unchanged from 0001327567-18-000006:mdna:40]

[0001327567-18-000014:mdna:51]
[same as prior period, unchanged from 0001327567-18-000006:mdna:41]

[0001327567-18-000014:mdna:52]
[same as prior period, unchanged from 0001327567-18-000006:mdna:42]

[0001327567-18-000014:mdna:53]
[same as prior period, unchanged from 0001327567-18-000006:mdna:43]

[0001327567-18-000014:mdna:54]
|  | Three Months Ended April 30, |  |  |  |  |  | Nine Months Ended April 30, |  |  |  |  |
|  | 2018 |  | 2017 |  | Change |  | 2018 |  | 2017 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Product | $ | 215.2 |  |  | $ | 164.2 |  |  | $ | 51.0 |  |  | 31.1 | % |  | $ | 603.9 |  |  | $ | 496.8 |  |  | $ | 107.1 |  |  | 21.6 | % |

[0001327567-18-000014:mdna:55]
Product revenue increased for the three and nine months ended April 30, 2018 compared to the three and nine months ended April 30, 2017. The increase in both periods was primarily driven by demand for our newly introduced appliances. The change in product revenue due to pricing was not significant for either period.

[0001327567-18-000014:mdna:56]
[same as prior period, unchanged from 0001327567-18-000006:mdna:46]

[0001327567-18-000014:mdna:57]
[same as prior period, unchanged from 0001327567-18-000006:mdna:47]

[0001327567-18-000014:mdna:58]
|  | Three Months Ended April 30, |  |  |  |  |  | Nine Months Ended April 30, |  |  |  |  |
|  | 2018 |  | 2017 |  | Change |  | 2018 |  | 2017 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Subscription | $ | 192.5 |  |  | $ | 139.6 |  |  | $ | 52.9 |  |  | 37.9 | % |  | $ | 545.1 |  |  | $ | 395.1 |  |  | $ | 150.0 |  |  | 38.0 | % |
| Support | 159.4 |  |  | 128.0 |  |  | 31.4 |  |  | 24.5 | % |  | 466.0 |  |  | 360.6 |  |  | 105.4 |  |  | 29.2 | % |
| Total subscription and support | $ | 351.9 |  |  | $ | 267.6 |  |  | $ | 84.3 |  |  | 31.5 | % |  | $ | 1,011.1 |  |  | $ | 755.7 |  |  | $ | 255.4 |  |  | 33.8 | % |

[0001327567-18-000014:mdna:59]
Subscription and support revenue increased for the three and nine months ended April 30, 2018 compared to the three and nine months ended April 30, 2017. The increase in both periods was due to increased demand for our subscription and support offerings from both new and existing end-customers. The mix between subscription revenue and support revenue will fluctuate over time, depending on the introduction of new subscription offerings, renewals of support services, and our ability to increase sales to new and existing customers. The change in subscription and support revenue due to changes in pricing was not significant for either period.

[0001327567-18-000014:mdna:60]
[same as prior period, unchanged from 0001327567-18-000006:mdna:50]

[0001327567-18-000014:mdna:61]
|  | Three Months Ended April 30, |  |  |  |  |  | Nine Months Ended April 30, |  |  |  |  |
|  | 2018 |  | 2017 |  | Change |  | 2018 |  | 2017 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Americas | $ | 387.6 |  |  | $ | 299.9 |  |  | $ | 87.7 |  |  | 29.2 | % |  | $ | 1,110.2 |  |  | $ | 875.1 |  |  | $ | 235.1 |  |  | 26.9 | % |
| EMEA | 109.8 |  |  | 81.1 |  |  | 28.7 |  |  | 35.4 | % |  | 311.5 |  |  | 230.6 |  |  | 80.9 |  |  | 35.1 | % |
| APAC | 69.7 |  |  | 50.8 |  |  | 18.9 |  |  | 37.2 | % |  | 193.3 |  |  | 146.8 |  |  | 46.5 |  |  | 31.7 | % |
| Total revenue | $ | 567.1 |  |  | $ | 431.8 |  |  | $ | 135.3 |  |  | 31.3 | % |  | $ | 1,615.0 |  |  | $ | 1,252.5 |  |  | $ | 362.5 |  |  | 28.9 | % |

[0001327567-18-000014:mdna:62]
[same as prior period, unchanged from 0001327567-18-000006:mdna:91]

[0001327567-18-000014:mdna:63]
With respect to geographic theaters, the Americas contributed the largest portion of the increase in revenue for the three and nine months ended April 30, 2018 compared to the three and nine months ended April 30, 2017, due to its larger and more established sales force compared to our other theaters. Revenue from both Europe, the Middle East, and Africa (“EMEA”) and Asia Pacific and Japan (“APAC”) increased for the three and nine months ended April 30, 2018 compared to the three and nine months ended April 30, 2017, due to our investment in increasing the size of our sales force and number of channel partners in these theaters.

[0001327567-18-000014:mdna:64]
[same as prior period, unchanged from 0001327567-18-000006:mdna:54]

[0001327567-18-000014:mdna:65]
[same as prior period, unchanged from 0001327567-18-000006:mdna:55]

[0001327567-18-000014:mdna:66]
[same as prior period, unchanged from 0001327567-18-000006:mdna:56]

[0001327567-18-000014:mdna:67]
[same as prior period, unchanged from 0001327567-18-000006:mdna:57]

[0001327567-18-000014:mdna:68]
|  | Three Months Ended April 30, |  |  |  | Nine Months Ended April 30, |  |  |  |  |
|  | 2018 |  | 2017 |  | Change |  | 2018 |  | 2017 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Cost of product revenue | $ | 68.9 |  |  | $ | 49.7 |  |  | $ | 19.2 |  |  | 38.6 | % |  | $ | 190.4 |  |  | $ | 137.7 |  |  | $ | 52.7 |  |  | 38.3 | % |
| Number of employees at period end | 92 |  |  | 94 |  |  | (2 | ) |  | (2.1 | )% |  | 92 |  |  | 94 |  |  | (2 | ) |  | (2.1 | )% |

[0001327567-18-000014:mdna:69]
Cost of product revenue increased for the three and nine months ended April 30, 2018 compared to the three and nine months ended April 30, 2017. The increase in both periods was primarily due to higher product costs related to our newly introduced appliances.

[0001327567-18-000014:mdna:70]
[same as prior period, unchanged from 0001327567-18-000006:mdna:60]

[0001327567-18-000014:mdna:71]
Cost of subscription and support revenue includes personnel costs for our global customer support and technical operations organizations, customer support and repair costs, third-party professional services costs, data center and cloud hosting costs, amortization of acquired intangible assets, and allocated costs. We expect our cost of subscription and support revenue to increase as our installed end-customer base grows and adoption of our cloud-based subscription offerings increases.

[0001327567-18-000014:mdna:72]
|  | Three Months Ended April 30, |  |  |  | Nine Months Ended April 30, |  |  |  |  |
|  | 2018 |  | 2017 |  | Change |  | 2018 |  | 2017 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Cost of subscription and support revenue | $ | 91.0 |  |  | $ | 74.0 |  |  | $ | 17.0 |  |  | 23.0 | % |  | $ | 270.2 |  |  | $ | 200.4 |  |  | $ | 69.8 |  |  | 34.8 | % |
| Number of employees at period end | 895 |  |  | 668 |  |  | 227 |  |  | 34.0 | % |  | 895 |  |  | 668 |  |  | 227 |  |  | 34.0 | % |

[0001327567-18-000014:mdna:73]
Cost of subscription and support revenue increased for the three and nine months ended April 30, 2018 compared to the three and nine months ended April 30, 2017. The increase in both periods was mainly driven by an increase in personnel costs for our global customer support and technical operations organizations, which grew $11.0 million to $50.5 million for the three months ended April 30, 2018 compared to the three months ended April 30, 2017, and grew $38.2 million to $152.0 million for the nine months ended April 30, 2018 compared to the nine months ended April 30, 2017. The increase in personnel costs in both periods was primarily due to headcount growth. The remaining increase in both periods was primarily due to data center and cloud hosting costs to support the adoption of our cloud-based subscription offerings, costs to expand our customer service capabilities, and allocated costs. The increase in allocated costs in both periods was primarily due to our expansion of facilities to support the growth of our business.

[0001327567-18-000014:mdna:74]
[same as prior period, unchanged from 0001327567-18-000006:mdna:64]

[0001327567-18-000014:mdna:75]
Gross margin, or gross profit as a percentage of revenue, has been and will continue to be affected by a variety of factors, including the introduction of new products, manufacturing costs, the average sales price of our products, the mix of products sold, and the mix of revenue between product and subscription and support offerings. For sales of our products, our higher-end firewall products

[0001327567-18-000014:mdna:76]
[same as prior period, unchanged from 0001327567-18-000006:mdna:103]

[0001327567-18-000014:mdna:77]
generally have higher gross margins than our lower-end firewall products within each product series. For sales of our subscription and support offerings, our subscription offerings typically have higher gross margins than our support offerings. We expect our gross margins to fluctuate over time depending on the factors described above.

[0001327567-18-000014:mdna:78]
|  | Three Months Ended April 30, |  | Nine Months Ended April 30, |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |
|  | Amount |  | Gross Margin |  | Amount |  | Gross Margin |  | Amount |  | Gross Margin |  | Amount |  | Gross Margin |
|  | (dollars in millions) |
| Product | $ | 146.3 |  |  | 68.0 | % |  | $ | 114.5 |  |  | 69.7 | % |  | $ | 413.5 |  |  | 68.5 | % |  | $ | 359.1 |  |  | 72.3 | % |
| Subscription and support | 260.9 |  |  | 74.1 | % |  | 193.6 |  |  | 72.3 | % |  | 740.9 |  |  | 73.3 | % |  | 555.3 |  |  | 73.5 | % |
| Total gross profit | $ | 407.2 |  |  | 71.8 | % |  | $ | 308.1 |  |  | 71.4 | % |  | $ | 1,154.4 |  |  | 71.5 | % |  | $ | 914.4 |  |  | 73.0 | % |

[0001327567-18-000014:mdna:79]
Product gross margin decreased for the three and nine months ended April 30, 2018 compared to the three and nine months ended April 30, 2017, driven by higher product costs related to our newly introduced appliances, which have lower product margins.

[0001327567-18-000014:mdna:80]
Subscription and support gross margin increased for the three months ended April 30, 2018 compared to the three months ended April 30, 2017, mainly driven by a decrease in customer support and repair costs. Subscription and support gross margin decreased slightly for the nine months ended April 30, 2018 compared to the nine months ended April 30, 2017, primarily due to higher data center and cloud hosting costs to support the adoption of our cloud-based subscription offerings, partially offset by a decrease in customer support and repair costs.

[0001327567-18-000014:mdna:81]
[same as prior period, unchanged from 0001327567-18-000006:mdna:71]

[0001327567-18-000014:mdna:82]
Our operating expenses consist of research and development, sales and marketing, and general and administrative expense. Personnel costs are the most significant component of operating expenses and consist of salaries, benefits, bonuses, share-based compensation, travel and entertainment, and with regard to sales and marketing expense, sales commissions. Our operating expenses also include allocated costs, which consist of certain facilities, depreciation, benefits, recruiting, and information technology costs that we allocate based on headcount. We expect operating expenses to increase in absolute dollars and decrease over the long term as a percentage of revenue as we continue to scale our business. As of April 30, 2018, we expect to recognize approximately $920.0 million of share-based compensation expense over a weighted-average period of approximately 2.6 years, excluding additional share-based compensation expense related to any future grants of share-based awards. Share-based compensation expense is generally recognized on a straight-line basis over the requisite service periods of the awards.

[0001327567-18-000014:mdna:83]
[same as prior period, unchanged from 0001327567-18-000006:mdna:73]

[0001327567-18-000014:mdna:84]
[same as prior period, unchanged from 0001327567-18-000006:mdna:74]

[0001327567-18-000014:mdna:85]
|  | Three Months Ended April 30, |  |  |  |  |  | Nine Months Ended April 30, |  |  |  |  |
|  | 2018 |  | 2017 |  | Change |  | 2018 |  | 2017 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Research and development | $ | 99.6 |  |  | $ | 86.0 |  |  | $ | 13.6 |  |  | 15.8 | % |  | $ | 290.4 |  |  | $ | 260.1 |  |  | $ | 30.3 |  |  | 11.6 | % |
| Number of employees at period end | 899 |  |  | 728 |  |  | 171 |  |  | 23.5 | % |  | 899 |  |  | 728 |  |  | 171 |  |  | 23.5 | % |

[0001327567-18-000014:mdna:86]
Research and development expense increased for the three and nine months ended April 30, 2018 compared to the three and nine months ended April 30, 2017. The increase in both periods was primarily due to an increase in personnel costs, which grew $9.8 million to $82.4 million for the three months ended April 30, 2018 compared to the three months ended April 30, 2017, and grew $18.7 million to $240.8 million for the nine months ended April 30, 2018 compared to the nine months ended April 30, 2017. The increase in personnel costs in both periods was largely due to headcount growth. The remaining increase in both periods was primarily driven by an increase in allocated costs due to our expansion of facilities to support the growth of our business.

[0001327567-18-000014:mdna:87]
[same as prior period, unchanged from 0001327567-18-000006:mdna:118]

[0001327567-18-000014:mdna:88]
[same as prior period, unchanged from 0001327567-18-000006:mdna:77]

[0001327567-18-000014:mdna:89]
Sales and marketing expense consists primarily of personnel costs, including commission expense. Sales and marketing expense also includes costs for market development programs, promotional and other marketing costs, professional services, and allocated costs. We continue to thoughtfully invest in headcount and have substantially grown our sales presence internationally. We expect sales and marketing expense to continue to increase in absolute dollars as we increase the size of our sales and marketing organizations to increase touch points with end-customers and to expand our international presence, although our sales and marketing expense may fluctuate as a percentage of total revenue.

[0001327567-18-000014:mdna:90]
|  | Three Months Ended April 30, |  |  |  |  |  | Nine Months Ended April 30, |  |  |  |  |
|  | 2018 |  | 2017 |  | Change |  | 2018 |  | 2017 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Sales and marketing | $ | 277.1 |  |  | $ | 226.9 |  |  | $ | 50.2 |  |  | 22.1 | % |  | $ | 800.6 |  |  | $ | 673.7 |  |  | $ | 126.9 |  |  | 18.8 | % |
| Number of employees at period end | 2,599 |  |  | 2,327 |  |  | 272 |  |  | 11.7 | % |  | 2,599 |  |  | 2,327 |  |  | 272 |  |  | 11.7 | % |

[0001327567-18-000014:mdna:91]
Sales and marketing expense increased for the three and nine months ended April 30, 2018 compared to the three and nine months ended April 30, 2017. The increase in both periods was primarily due to an increase in personnel costs, which grew $38.9 million to $216.2 million for the three months ended April 30, 2018 compared to the three months ended April 30, 2017, and grew $101.9 million to $623.9 million for the nine months ended April 30, 2018 compared to the nine months ended April 30, 2017. The increase in personnel costs in both periods was largely due to headcount growth. The remaining increase in both periods was primarily driven by an increase in allocated costs due to our expansion of facilities to support the growth of our business.

[0001327567-18-000014:mdna:92]
[same as prior period, unchanged from 0001327567-18-000006:mdna:83]

[0001327567-18-000014:mdna:93]
[same as prior period, unchanged from 0001327567-18-000006:mdna:84]

[0001327567-18-000014:mdna:94]
|  | Three Months Ended April 30, |  |  |  |  |  | Nine Months Ended April 30, |  |  |  |  |
|  | 2018 |  | 2017 |  | Change |  | 2018 |  | 2017 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| General and administrative | $ | 82.1 |  |  | $ | 44.3 |  |  | $ | 37.8 |  |  | 85.3 | % |  | $ | 201.1 |  |  | $ | 133.1 |  |  | $ | 68.0 |  |  | 51.1 | % |
| Number of employees at period end | 636 |  |  | 523 |  |  | 113 |  |  | 21.6 | % |  | 636 |  |  | 523 |  |  | 113 |  |  | 21.6 | % |

[0001327567-18-000014:mdna:95]
General and administrative expense increased for the three months ended April 30, 2018 compared to the three months ended April 30, 2017, primarily due to an additional cease-use loss of $23.8 million recognized on the lease of our previous headquarter facilities during the three months ended April 30, 2018, due to the changes in market conditions in recent months. Refer to Note 8. Commitments and Contingencies in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information on our cease-use loss. The remaining increase was primarily driven by costs related to business acquisitions completed during the three months ended April 30, 2018. Refer to Note 5. Acquisitions in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information on our acquisitions.

[0001327567-18-000014:mdna:96]
General and administrative expense increased for the nine months ended April 30, 2018 compared to the nine months ended April 30, 2017, primarily due to a total cease-use loss of $39.2 million recognized on the lease of our previous headquarter facilities during the nine months ended April 30, 2018. The remaining increase was primarily driven by costs related to business acquisitions completed during the three months ended April 30, 2018, and an increase in personnel costs. Personnel costs grew $8.1 million to $104.5 million for the nine months ended April 30, 2018 compared to the nine months ended April 30, 2017, largely due to headcount growth.

[0001327567-18-000014:mdna:97]
Provision for (Benefit from) Income Taxes

[0001327567-18-000014:mdna:98]
Provision for (benefit from) income taxes consists primarily of income taxes in foreign jurisdictions in which we conduct business, withholding taxes, U.S. state income taxes, and amortization of our deferred tax charges. We maintain a valuation allowance

[0001327567-18-000014:mdna:99]
- 29 -

[0001327567-18-000014:mdna:100]
for domestic and certain foreign deferred tax assets, including net operating loss carryforwards and certain domestic tax credits. In recent years, we reorganized our corporate structure and intercompany relationships to more closely align with the international nature of our business activities. To the extent we revisit our corporate structure, it may have an impact on our tax provision.

[0001327567-18-000014:mdna:101]
On December 22, 2017, the Tax Cuts and Jobs Act (“TCJA”) was enacted into law. The TCJA provides for significant tax law changes and modifications including, but not limited to, the reduction of the U.S. federal corporate statutory tax rate from 35% to 21% as of January 1, 2018, the requirement for companies to pay a one-time transition tax on earnings of certain foreign subsidiaries that were previously tax deferred, and the creation of new taxes on certain foreign-sourced earnings. As a fiscal year-end taxpayer, certain provisions of the TCJA began to impact us during the three months ended January 31, 2018, while other provisions will impact us beginning in our fiscal year ending July 31, 2019.

[0001327567-18-000014:mdna:102]
|  | Three Months Ended April 30, |  | Change |  | Nine Months Ended April 30, |  | Change |
|  | 2018 |  | 2017 |  | Amount |  | % |  | 2018 |  | 2017 |  | Amount |  | % |
|  | (dollars in millions) |
| Provision for (benefit from) income taxes | $ | (2.8 | ) |  | $ | 7.7 |  |  | $ | (10.5 | ) |  | (136.4 | )% |  | $ | 7.0 |  |  | $ | 14.9 |  |  | $ | (7.9 | ) |  | (53.0 | )% |
| Effective tax rate | 5.7 | % |  | (14.5 | )% |  |  |  |  |  |  | (5.1 | )% |  | (9.1 | )% |  |  |  |  |  |

[0001327567-18-000014:mdna:103]
We recorded an income tax benefit and an income tax provision for the three and nine months ended April 30, 2018, respectively. Key components of our provision for income taxes include foreign income taxes, withholding taxes, and amortization of our deferred tax charges. Our provision for income taxes decreased for the three months ended April 30, 2018 compared to the three months ended April 30, 2017, primarily due to one-time tax benefits during the three months ended April 30, 2018 from a partial release of our valuation allowance related to the acquisition of Evident.io of $4.6 million and an Israeli judicial ruling related to share-based compensation of $3.5 million. Our provision for income taxes decreased for the nine months ended April 30, 2018 compared to the nine months ended April 30, 2017, primarily due to one-time tax benefits from the TCJA of $5.8 million, a partial release of our valuation allowance related to the acquisition of Evident.io of $4.6 million, and an Israeli judicial ruling related to share-based compensation of $3.5 million, partially offset by an increase in amortization of our deferred tax charges from intercompany transactions and an increase in foreign taxes due to growth in non-U.S. operations.

[0001327567-18-000014:mdna:104]
During the nine months ended April 30, 2018, we recognized provisional amounts for the tax effects of the TCJA which were included as components of income tax expense and reflected in the effective tax rates above. We will continue to assess the impact of the TCJA on our business and our condensed consolidated financial statements, however, the final impact of the TCJA may differ from the provisional amounts due to a number of uncertainties and factors, including information not available until the close of our fiscal year ending July 31, 2018, the need for further guidance and clarification of the new law by U.S. federal and state tax authorities, and the need for further guidance on the related income tax accounting. Refer to Note 11. Income Taxes in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information on the TCJA and its expected impact.

[0001327567-18-000014:mdna:105]
[same as prior period, unchanged from 0001327567-18-000006:mdna:96]

[0001327567-18-000014:mdna:106]
|  | April 30, 2018 |  | July 31, 2017 |
|  | (in millions) |
| Working capital(1) | $ | 262.4 |  |  | $ | 775.0 |  |
| Cash, cash equivalents, and investments: |  |  |  |
| Cash and cash equivalents | $ | 949.0 |  |  | $ | 744.3 |  |
| Investments | 1,265.1 |  |  | 1,420.0 |  |
| Total cash, cash equivalents, and investments | $ | 2,214.1 |  |  | $ | 2,164.3 |  |

[0001327567-18-000014:mdna:107]
[same as prior period, unchanged from 0001327567-18-000006:mdna:98]

[0001327567-18-000014:mdna:108]
| (1) | The net carrying amount of the 0.0% Convertible Senior Notes due 2019 (the “Notes”) was classified in current liabilities in our condensed consolidated balance sheets as of April 30, 2018. Refer to Note 7. Convertible Senior Notes in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information. |

[0001327567-18-000014:mdna:109]
As of April 30, 2018, our total cash, cash equivalents, and investments of $2.2 billion were held for general corporate purposes, of which approximately $182.5 million was held outside of the United States. As of April 30, 2018, we had no unremitted earnings that would be subject to taxation in the United States when evaluating our outside basis differences relating to our investment in foreign subsidiaries; accordingly, there is no restriction on the use of these funds.

[0001327567-18-000014:mdna:110]
- 30 -

[0001327567-18-000014:mdna:111]
As of April 30, 2018, all of the Notes remained outstanding. The Notes mature on July 1, 2019; however, prior to January 1, 2019, holders may surrender their Notes for early conversion under certain circumstances. During the fiscal quarter ended April 30, 2018, one of the early conversion conditions was met, and as a result, holders may convert their Notes at any time during the fiscal quarter ending July 31, 2018. Upon conversion, we will pay cash equal to the aggregate principal amount of the Notes to be converted, and, at our election, will pay or deliver cash and/or shares of our common stock for the amount of our conversion obligation in excess of the aggregate principal amount of the Notes being converted. Refer to Note 7. Convertible Senior Notes in Part I, Item 1 of this Quarterly Report on Form 10-Q for information on the Notes.

[0001327567-18-000014:mdna:112]
In August 2016, our board of directors authorized a $500.0 million share repurchase and, in February 2017, authorized a $500.0 million increase to our repurchase program, bringing the total authorization to $1.0 billion. Repurchases are funded from available working capital and may be made at management’s discretion from time to time. The repurchase authorization will expire on December 31, 2018, and may be suspended or discontinued at any time. As of April 30, 2018, $330.0 million remained available for future share repurchases under the repurchase authorization. Refer to Note 9. Stockholders’ Equity in Part I, Item 1 of this Quarterly Report on Form 10-Q for information on the repurchase authorization.

[0001327567-18-000014:mdna:113]
The following table summarizes our cash flows for the nine months ended April 30, 2018 and 2017:

[0001327567-18-000014:mdna:114]
|  | Nine Months Ended April 30, |
| 2018 |  | 2017 |
|  | (in millions) |
| Net cash provided by operating activities | $ | 759.1 |  |  | $ | 629.0 |  |
| Net cash used in investing activities | (313.6 | ) |  | (411.1 | ) |
| Net cash used in financing activities | (240.8 | ) |  | (260.3 | ) |
| Net increase (decrease) in cash and cash equivalents | $ | 204.7 |  |  | $ | (42.4 | ) |

[0001327567-18-000014:mdna:115]
We believe that our cash flow from operations with existing cash and cash equivalents will be sufficient to meet our anticipated cash needs for the foreseeable future. Our future capital requirements will depend on many factors including our growth rate, the timing and extent of spending to support development efforts, the expansion of sales and marketing activities, the introduction of new and enhanced products and subscription and support offerings, the costs to acquire or invest in complementary businesses and technologies, the costs to ensure access to adequate manufacturing capacity, the investments in our infrastructure to support the adoption of our cloud-based subscription offerings, the investments in our new corporate headquarters, and the continuing market acceptance of our products and subscription and support offerings. In addition, from time to time we may incur additional tax liability in connection with certain corporate structuring decisions.

[0001327567-18-000014:mdna:116]
[same as prior period, unchanged from 0001327567-18-000006:mdna:108]

[0001327567-18-000014:mdna:117]
[same as prior period, unchanged from 0001327567-18-000006:mdna:109]

[0001327567-18-000014:mdna:118]
[same as prior period, unchanged from 0001327567-18-000006:mdna:110]

[0001327567-18-000014:mdna:119]
Cash provided by operating activities during the nine months ended April 30, 2018 was $759.1 million, an increase of $130.1 million compared to the nine months ended April 30, 2017. The increase was due to growth of our business, as reflected by an increase in billings during the nine months ended April 30, 2018.

[0001327567-18-000014:mdna:120]
[same as prior period, unchanged from 0001327567-18-000006:mdna:112]

[0001327567-18-000014:mdna:121]
[same as prior period, unchanged from 0001327567-18-000006:mdna:113]

[0001327567-18-000014:mdna:122]
Cash used in investing activities during the nine months ended April 30, 2018 was $313.6 million, a decrease of $97.5 million compared to the nine months ended April 30, 2017, due to lower net purchases of available-for-sale investments and capital expenditures, partially offset by an increase in net cash payments for acquisitions, during the nine months ended April 30, 2018.

[0001327567-18-000014:mdna:123]
[same as prior period, unchanged from 0001327567-18-000006:mdna:115]

[0001327567-18-000014:mdna:124]
[same as prior period, unchanged from 0001327567-18-000006:mdna:116]

[0001327567-18-000014:mdna:125]
- 31 -

[0001327567-18-000014:mdna:126]
Cash used in financing activities during the nine months ended April 30, 2018 was $240.8 million, a decrease of $19.5 million compared to the nine months ended April 30, 2017, primarily due to a decrease in repurchases of our common stock, partially offset by an increase in payments for tax withholding obligations of certain employees related to the net share settlement of equity awards during the nine months ended April 30, 2018.

[0001327567-18-000014:mdna:127]
[same as prior period, unchanged from 0001327567-18-000006:mdna:119]

[0001327567-18-000014:mdna:128]
The following table summarizes our contractual obligations and commitments as of April 30, 2018:

[0001327567-18-000014:mdna:129]
|  | Payments Due by Period |
|  | Total |  | Less Than 1 Year |  | 1-3 Years |  | 3-5 Years |  | More Than 5 Years |
|  |  |  | (in millions) |  |  |
| 0.0% Convertible Senior Notes due 2019(1) | $ | 575.0 |  |  | $ | — |  |  | $ | 575.0 |  |  | $ | — |  |  | $ | — |  |
| Operating lease obligations(2) | 554.7 |  |  | 66.0 |  |  | 132.9 |  |  | 118.4 |  |  | 237.4 |  |
| Purchase obligations(3) | 164.7 |  |  | 156.7 |  |  | 8.0 |  |  | — |  |  | — |  |
| Total(4) | $ | 1,294.4 |  |  | $ | 222.7 |  |  | $ | 715.9 |  |  | $ | 118.4 |  |  | $ | 237.4 |  |

[0001327567-18-000014:mdna:130]
[same as prior period, unchanged from 0001327567-18-000006:mdna:122]

[0001327567-18-000014:mdna:131]
| (1) | As of April 30, 2018, holders may convert their Notes at any time during the fiscal quarter ending July 31, 2018. Refer to Note 7. Convertible Senior Notes in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information. |

[0001327567-18-000014:mdna:132]
| (2) | Consists of contractual obligations from our non-cancelable operating leases. Excludes contractual sublease proceeds of $14.6 million, which consists of $4.7 million to be received in less than one year, and $9.9 million to be received in one to three years. Refer to Note 8. Commitments and Contingencies in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information on our operating leases. |

[0001327567-18-000014:mdna:133]
| (3) | Consists of minimum purchase commitments of products and components with our manufacturing partners and component suppliers, as well as minimum purchase commitments for our use of certain cloud services with a third-party provider. Obligations under contracts that we can cancel without a significant penalty are not included in the table above. |

[0001327567-18-000014:mdna:134]
| (4) | No amounts related to income taxes are included. As of April 30, 2018, we had approximately $70.0 million of tax liabilities recorded related to uncertainty in income tax positions. |

[0001327567-18-000014:mdna:135]
[same as prior period, unchanged from 0001327567-18-000006:mdna:127]

[0001327567-18-000014:mdna:136]
As of April 30, 2018, we did not have any relationships with unconsolidated organizations or financial partnerships, such as structured finance or special purpose entities that would have been established for the purpose of facilitating off-balance sheet arrangements or other contractually narrow or limited purposes.

[0001327567-18-000014:mdna:137]
[same as prior period, unchanged from 0001327567-18-000006:mdna:129]

[0001327567-18-000014:mdna:138]
[same as prior period, unchanged from 0001327567-18-000006:mdna:130]

[0001327567-18-000014:mdna:139]
We believe the critical accounting estimates discussed under Item 7, “Management’s Discussion and Analysis of Financial Condition and Results of Operations” in our Annual Report on Form 10-K for the fiscal year ended July 31, 2017, reflect our more significant judgments and estimates used in the preparation of our condensed consolidated financial statements. There have been no significant changes to our critical accounting estimates as filed in such report.

[0001327567-18-000014:mdna:140]
[same as prior period, unchanged from 0001327567-18-000006:mdna:132]

[0001327567-18-000014:mdna:141]
Refer to “Recently Issued Accounting Pronouncements” in Note 1. Description of Business and Summary of Significant Accounting Policies in Part I, Item 1 of this Quarterly Report on Form 10-Q.

[0001327567-18-000014:mdna:142]
- 32 -
