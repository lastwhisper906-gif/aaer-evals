# PANW notes — 0001327567-18-000014


## us-gaap:AvailableForSaleSecuritiesTextBlock

[0001327567-18-000014:notes:1]
The following tables summarize the amortized cost, unrealized gains and losses, and fair value of our available-for-sale securities as of April 30, 2018 and July 31, 2017 (in millions):

[0001327567-18-000014:notes:2]
|  | April 30, 2018 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Estimated Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Money market funds | $ | 361.8 |  |  | $ | — |  |  | $ | — |  |  | $ | 361.8 |  |
| Commercial paper | 32.1 |  |  | — |  |  | — |  |  | 32.1 |  |
| Corporate debt securities | 1.0 |  |  | — |  |  | — |  |  | 1.0 |  |
| U.S. government and agency securities | 129.6 |  |  | — |  |  | — |  |  | 129.6 |  |
| Total cash equivalents | $ | 524.5 |  |  | $ | — |  |  | $ | — |  |  | $ | 524.5 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 5.4 |  |  | $ | — |  |  | $ | — |  |  | $ | 5.4 |  |
| Corporate debt securities | 283.9 |  |  | 0.1 |  |  | (2.8 | ) |  | 281.2 |  |
| U.S. government and agency securities | 987.6 |  |  | — |  |  | (9.1 | ) |  | 978.5 |  |
| Total investments | $ | 1,276.9 |  |  | $ | 0.1 |  |  | $ | (11.9 | ) |  | $ | 1,265.1 |  |

[0001327567-18-000014:notes:3]
[same as prior period, unchanged from 0001327567-18-000006:notes:3]


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001327567-18-000014:notes:4]
Acquisitions

[0001327567-18-000014:notes:5]
Evident.io, Inc.

[0001327567-18-000014:notes:6]
On March 26, 2018, we completed our acquisition of all outstanding shares of Evident.io, Inc. (“Evident.io”), a privately-held cloud security company. The acquisition expands our API-based security capabilities for the public cloud with the addition of Evident.io’s cloud services infrastructure protection technology. Total purchase consideration for the acquisition of Evident.io was $292.9 million in cash, of which $4.0 million was accrued and will be paid over a period of five months from the acquisition date.

[0001327567-18-000014:notes:7]
We have accounted for this transaction as a business combination and allocated the purchase consideration to assets acquired and liabilities assumed based on preliminary estimated fair values, as presented in the following table (in millions):

[0001327567-18-000014:notes:8]
|  | Amount |
| Goodwill | $ | 209.8 |  |
| Identified intangible assets | 85.1 |  |
| Net liabilities assumed | (2.0 | ) |
| Total | $ | 292.9 |  |

[0001327567-18-000014:notes:9]
Goodwill generated from this business combination is primarily attributable to the assembled workforce and expected post-acquisition synergies from integrating Evident.io’s technology into our platform and sales opportunities of Evident.io’s software as a service (“SaaS”) offerings. The goodwill is not deductible for income tax purposes.

[0001327567-18-000014:notes:10]
The following table presents details of the identified intangible assets acquired (in millions, except years):

[0001327567-18-000014:notes:11]
|  | Fair Value |  | Estimated Useful Life |
| Developed technology | $ | 68.4 |  |  | 6 years |
| Trade name and trademarks | 8.5 |  |  | 8 years |
| Customer relationships | 8.2 |  |  | 8 years |
| Total | $ | 85.1 |  |  |  |

[0001327567-18-000014:notes:12]
In addition, we paid $6.6 million in cash to settle certain Evident.io stock options, for which vesting was accelerated in connection with the acquisition and the subsequent termination of the option holders’ services. This amount was recorded as post-acquisition share-based compensation included in general and administrative expenses in our condensed consolidated statements of operations.

[0001327567-18-000014:notes:13]
Cyber Secdo Ltd.

[0001327567-18-000014:notes:14]
On April 24, 2018, we completed our acquisition of all outstanding shares of Cyber Secdo Ltd. (“Secdo”), a privately-held company specializing in endpoint detection and response (“EDR”). The acquisition expands the functionality of our platform by adding EDR capabilities. Total purchase consideration for the acquisition of Secdo was $82.7 million in cash.

[0001327567-18-000014:notes:15]
|  | Amount |
| Goodwill | $ | 68.6 |  |
| Identified intangible assets | 17.3 |  |
| Net liabilities assumed | (3.2 | ) |
| Total | $ | 82.7 |  |

[0001327567-18-000014:notes:16]
Goodwill generated from this business combination is primarily attributable to the assembled workforce and expected post-acquisition synergies from integrating Secdo’s technology into our advanced endpoint protection offering and our platform. The goodwill is not deductible for income tax purposes.

[0001327567-18-000014:notes:17]
|  | Fair Value |  | Estimated Useful Life |
| Developed technology | $ | 16.4 |  |  | 5 years |
| Customer relationships | 0.9 |  |  | 2 years |
| Total | $ | 17.3 |  |  |  |

[0001327567-18-000014:notes:18]
Additional Acquisition-Related Information

[0001327567-18-000014:notes:19]
The operating results of the acquired companies are included in our condensed consolidated statements of operations from the respective dates of acquisition. Pro forma results of operations have not been presented because the effects of these acquisitions, individually and in the aggregate, were not material to our condensed consolidated statements of operations.

[0001327567-18-000014:notes:20]
Additional information, such as that related to income tax and other contingencies, existing as of the acquisition date but unknown to us may become known during the remainder of the measurement period, not to exceed 12 months from the respective acquisition date, which may result in changes to the amounts and allocations recorded.


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock

[0001327567-18-000014:notes:21]
[same as prior period, unchanged from 0001327567-18-000006:notes:4]

[0001327567-18-000014:notes:22]
[same as prior period, unchanged from 0001327567-18-000006:notes:5]

[0001327567-18-000014:notes:23]
Palo Alto Networks, Inc. (the “Company,” “we,” “us,” or “our”), located in Santa Clara, California, was incorporated in March 2005 under the laws of the State of Delaware and commenced operations in April 2005. We offer a security operating platform that empowers enterprises, service providers, and government entities to secure their organizations by safely enabling applications running in their networks, on their endpoints, and in the cloud, and by preventing breaches that stem from targeted cyberattacks.

[0001327567-18-000014:notes:24]
[same as prior period, unchanged from 0001327567-18-000006:notes:7]

[0001327567-18-000014:notes:25]
The accompanying condensed consolidated financial statements have been prepared in conformity with U.S. generally accepted accounting principles (“GAAP”), consistent in all material respects with those applied in our Annual Report on Form 10-K for the fiscal year ended July 31, 2017, filed with the Securities and Exchange Commission (“SEC”) on September 7, 2017. Our condensed consolidated financial statements include our accounts and our wholly owned subsidiaries. All significant intercompany balances and transactions have been eliminated in consolidation.

[0001327567-18-000014:notes:26]
[same as prior period, unchanged from 0001327567-18-000006:notes:9]

[0001327567-18-000014:notes:27]
[same as prior period, unchanged from 0001327567-18-000006:notes:10]

[0001327567-18-000014:notes:28]
[same as prior period, unchanged from 0001327567-18-000006:notes:11]

[0001327567-18-000014:notes:29]
There have been no material changes to our significant accounting policies as of and for the nine months ended April 30, 2018, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended July 31, 2017.

[0001327567-18-000014:notes:30]
Recently Adopted Accounting Pronouncements

[0001327567-18-000014:notes:31]
[same as prior period, unchanged from 0001327567-18-000006:notes:14]

[0001327567-18-000014:notes:32]
[same as prior period, unchanged from 0001327567-18-000006:notes:15]

[0001327567-18-000014:notes:33]
Recently Issued Accounting Pronouncements

[0001327567-18-000014:notes:34]
[same as prior period, unchanged from 0001327567-18-000006:notes:17]

[0001327567-18-000014:notes:35]
[same as prior period, unchanged from 0001327567-18-000006:notes:18]

[0001327567-18-000014:notes:36]
[same as prior period, unchanged from 0001327567-18-000006:notes:19]

[0001327567-18-000014:notes:37]
[same as prior period, unchanged from 0001327567-18-000006:notes:20]

[0001327567-18-000014:notes:38]
[same as prior period, unchanged from 0001327567-18-000006:notes:21]

[0001327567-18-000014:notes:39]
In October 2016, the FASB issued authoritative guidance requiring the recognition of income tax consequences of an intra-entity transfer of an asset, other than inventory, when the transfer occurs. The standard is effective for us in our first quarter of fiscal 2019 and will be applied on a modified retrospective basis through a cumulative-effect adjustment to accumulated deficit as of the date of adoption. Early adoption is permitted. We plan to adopt the standard in our first quarter of fiscal 2019. The adoption of this standard may have a material impact on our condensed consolidated financial statements, subject to any potential intra-entity transfers of assets (excluding inventory) and additional guidance and interpretations issued by U.S. regulatory and standard-setting bodies related to the Tax Cuts and Jobs Act (“TCJA”) enacted into law on December 22, 2017. Refer to Note 11. Income Taxes for more information on the TCJA.

[0001327567-18-000014:notes:40]
[same as prior period, unchanged from 0001327567-18-000006:notes:23]

[0001327567-18-000014:notes:41]
[same as prior period, unchanged from 0001327567-18-000006:notes:24]

[0001327567-18-000014:notes:42]
[same as prior period, unchanged from 0001327567-18-000006:notes:25]

[0001327567-18-000014:notes:43]
[same as prior period, unchanged from 0001327567-18-000006:notes:26]

[0001327567-18-000014:notes:44]
[same as prior period, unchanged from 0001327567-18-000006:notes:27]

[0001327567-18-000014:notes:45]
[same as prior period, unchanged from 0001327567-18-000006:notes:28]

[0001327567-18-000014:notes:46]
[same as prior period, unchanged from 0001327567-18-000006:notes:29]

[0001327567-18-000014:notes:47]
[same as prior period, unchanged from 0001327567-18-000006:notes:30]

[0001327567-18-000014:notes:48]
We will adopt the standard in our first quarter of fiscal 2019 using the full retrospective method and are on schedule with the preparation of our relevant prior-period financial statements.

[0001327567-18-000014:notes:49]
[same as prior period, unchanged from 0001327567-18-000006:notes:32]

[0001327567-18-000014:notes:50]
We are also continuing to evaluate the impact the standard will have on our condensed consolidated financial statements and disclosures, including reviewing the provisions of our customer contracts and identifying performance obligations under the requirements of the new standard, and comparing to our current accounting policies and practices. Although we have not yet determined whether the effect will be material, we believe the new standard will impact our accounting for revenue arrangements in the following areas:

[0001327567-18-000014:notes:51]
[same as prior period, unchanged from 0001327567-18-000006:notes:34]

[0001327567-18-000014:notes:52]
[same as prior period, unchanged from 0001327567-18-000006:notes:35]

[0001327567-18-000014:notes:53]
[same as prior period, unchanged from 0001327567-18-000006:notes:36]

[0001327567-18-000014:notes:54]
| • | amortization period for incremental costs to obtain or fulfill customer contracts. |

[0001327567-18-000014:notes:55]
The exact impact of the new standard will be dependent on facts and circumstances at adoption and could vary from quarter to quarter.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001327567-18-000014:notes:56]
Commitments and Contingencies

[0001327567-18-000014:notes:57]
We lease our facilities under various non-cancelable operating leases, which expire through the year ending July 31, 2028.

[0001327567-18-000014:notes:58]
In May 2015 and October 2015, we entered into a total of three lease agreements for approximately 941,000 square feet of corporate office space in Santa Clara, California, which serves as our new corporate headquarters. The leases contain rent holiday periods, scheduled rent increases, lease incentives, and renewal options which allow the lease terms to be extended beyond their expiration dates of July 2028 through July 2046. In September 2017, per the terms of the lease agreements, the landlords exercised their option to amend our lease payment schedules and eliminate our rent holiday periods, which increased our rental payments by $24.4 million, $11.8 million, and $2.0 million for fiscal 2018, 2019, and 2020, respectively. In exchange, we received an upfront cash reimbursement of $38.2 million during the three months ended October 31, 2017, which we will apply against the future additional rental payments when due. As amended, rental payments under the three lease agreements are approximately $412.0 million over the lease terms.

[0001327567-18-000014:notes:59]
In May 2015, we also entered into a lease agreement for approximately 122,000 square feet of space in Santa Clara, California, to serve as an extension of our previous corporate headquarters. The lease contains scheduled rent increases, lease incentives, and renewal options which allow the lease term to be extended beyond the expiration date of April 2021 through July 2046. Rental payments under the lease agreement are approximately $23.1 million over the lease term. In December 2017, we entered into an agreement to sublease this office space for the remaining lease term. Proceeds from this sublease will be approximately $16.3 million over the sublease term.

[0001327567-18-000014:notes:60]
In September 2012, we entered into two lease agreements for a total of approximately 300,000 square feet of space in Santa Clara, California, which served as our previous corporate headquarters through August 2017, when we relocated to our new corporate campus. The leases contain rent holiday periods and two separate five-year options to extend the lease terms beyond their expiration dates of July 2023. Rental payments under these lease agreements are approximately $94.3 million over the lease term. In August 2017, we exited our previous headquarter facilities and relocated to our new corporate campus, which resulted in the recognition of a cease-use loss of $15.4 million during the three months ended October 31, 2017. Due to the changes in market conditions in recent months, we recognized an additional cease-use loss of $23.8 million during the three months ended April 30, 2018, based on changes to the amount and timing of estimated cash flows from sublease rentals that could be reasonably obtained. The total cease-use loss of $39.2 million, recognized as general and administrative expense in our condensed consolidated statements of operations during the nine months ended April 30, 2018, and a corresponding liability in our condensed consolidated balance sheets, was calculated as the present value of the excess of the remaining lease obligation for the vacated facilities, adjusted for the effects of any deferred items recognized under the leases and related costs, over the estimated sublease rentals that could be reasonably obtained. The amount of the cease-use loss may vary if the timing or amount of estimated cash flows change. During the three and nine months ended April 30, 2018, we released $2.8 million and $7.4 million, respectively, of the cease-use liability through rental payments. As of April 30, 2018, the remaining balance of the cease-use liability was $31.8 million, which is expected to be paid through the end of the lease term in July 2023.

[0001327567-18-000014:notes:61]
The following table presents details of the aggregate future non-cancelable minimum rental payments under our operating leases as of April 30, 2018 (in millions):

[0001327567-18-000014:notes:62]
|  | Amount |
| Fiscal years ending July 31: |  |
| Remaining 2018 | $ | 16.7 |  |
| 2019 | 65.9 |  |
| 2020 | 67.8 |  |
| 2021 | 63.3 |  |
| 2022 | 59.7 |  |
| 2023 and thereafter | 281.3 |  |
| Committed gross lease payments | 554.7 |  |
| Less: proceeds from sublease rentals | 14.6 |  |
| Net operating lease obligation | $ | 540.1 |  |

[0001327567-18-000014:notes:63]
Manufacturing Purchase Commitments

[0001327567-18-000014:notes:64]
Our electronics manufacturing service provider (“EMS provider”) procures components and assembles our products based on our forecasts. These forecasts are based on estimates of demand for our products primarily for the next 12 months, which are in turn based on historical trends and an analysis from our sales and product management organizations, adjusted for overall market conditions. In order to reduce manufacturing lead times and plan for adequate supply, we may issue non-cancelable orders for products and components to our manufacturing partners or component suppliers. As of April 30, 2018, our purchase commitments under such orders were $142.7 million, excluding obligations under contracts that we can cancel without a significant penalty.

[0001327567-18-000014:notes:65]
Other Purchase Commitments

[0001327567-18-000014:notes:66]
In March 2018, we amended an agreement with a third-party provider for our use of certain cloud services through June 2020. Under the non-cancelable addendum, we are committed to a minimum purchase of $14.0 million between April 2018 and March 2019 and $8.0 million between April 2019 and March 2020. As of April 30, 2018, our purchase commitment under the addendum was $22.0 million.

[0001327567-18-000014:notes:67]
Litigation

[0001327567-18-000014:notes:68]
We are subject to legal proceedings, claims, and litigation arising in the ordinary course of business, including intellectual property litigation. Such matters are subject to many uncertainties and outcomes are not predictable with assurance. We accrue for contingencies when we believe that a loss is probable and that we can reasonably estimate the amount of any such loss.

[0001327567-18-000014:notes:69]
To the extent there is a reasonable possibility that a loss exceeding amounts already recognized may be incurred and the amount of such additional loss would be material, we will either disclose the estimated additional loss or state that such an estimate cannot be made. As of April 30, 2018, we have not recorded any significant accruals for loss contingencies associated with such legal proceedings, determined that an unfavorable outcome is probable or reasonably possible, or determined that the amount or range of any possible loss is reasonably estimable.


## us-gaap:ConvertibleDebtTableTextBlock

[0001327567-18-000014:notes:70]
The following table sets forth the components of the Notes as of April 30, 2018 and July 31, 2017 (in millions):

[0001327567-18-000014:notes:71]
|  | April 30, 2018 |  | July 31, 2017 |
| Liability: |  |  |  |
| Principal | $ | 575.0 |  |  | $ | 575.0 |  |
| Less: debt discount and debt issuance costs, net of amortization | 31.2 |  |  | 50.3 |  |
| Net carrying amount | $ | 543.8 |  |  | $ | 524.7 |  |
| Equity (including temporary equity) | $ | 109.8 |  |  | $ | 109.8 |  |


## us-gaap:DebtDisclosureTextBlock

[0001327567-18-000014:notes:72]
Convertible Senior Notes

[0001327567-18-000014:notes:73]
On June 30, 2014, we issued $575.0 million aggregate principal amount of 0.0% Convertible Senior Notes due 2019 (the “Notes”). The Notes mature on July 1, 2019 unless converted or repurchased in accordance with their terms prior to such date. The Notes do not contain any financial covenants and we cannot redeem the Notes prior to maturity.

[0001327567-18-000014:notes:74]
The Notes are convertible for up to 5.2 million shares of our common stock at an initial conversion price of approximately $110.28 per share of common stock, subject to adjustment. Holders of the Notes may surrender their Notes for conversion at their option at any time prior to the close of business on the business day immediately preceding January 1, 2019, only under the following circumstances:

[0001327567-18-000014:notes:75]
| • | during any fiscal quarter commencing after the fiscal quarter ending on October 31, 2014 (and only during such fiscal quarter), if the last reported sale price of our common stock for at least 20 trading days (whether or not consecutive) during a period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the conversion price for the Notes on each applicable trading day (the “sale price condition”); |

[0001327567-18-000014:notes:76]
| • | during the five business day period after any five consecutive trading day period, in which the trading price per $1,000 principal amount of Notes for each trading day of the measurement period was less than 98% of the product of the last reported sale price of our common stock and the conversion rate for the Notes on each such trading day; or |

[0001327567-18-000014:notes:77]
| • | upon the occurrence of specified corporate events. |

[0001327567-18-000014:notes:78]
On or after January 1, 2019, holders may convert all or any portion of their Notes at any time prior to the close of business on the second scheduled trading day immediately preceding the maturity date regardless of the foregoing conditions. Upon conversion, holders will receive cash equal to the aggregate principal amount of the Notes to be converted, and, at our election, cash and/or shares of our common stock for any amounts in excess of the aggregate principal amount of the Notes being converted. As of April 30, 2018, all of the Notes remained outstanding.

[0001327567-18-000014:notes:79]
The sale price condition was met during the fiscal quarter ended April 30, 2018, and as a result, holders may convert their Notes at any time during the fiscal quarter ending July 31, 2018. Accordingly, the net carrying amount of the Notes was reclassified into current liabilities and the portion of the equity component representing the conversion option was reclassified into temporary equity in our condensed consolidated balance sheets as of April 30, 2018. The portion of the equity component classified as temporary equity is measured as the difference between the principal and net carrying amount of the Notes, excluding debt issuance costs. The sale price condition was not met during the fiscal quarter ended July 31, 2017. Since the Notes were not convertible, the net carrying amount of the Notes was classified as a long-term liability and the equity component was included in additional paid-in capital in our condensed consolidated balance sheets as of July 31, 2017.

[0001327567-18-000014:notes:80]
The total estimated fair value of the Notes was $1.0 billion and $747.5 million at April 30, 2018 and July 31, 2017, respectively. The fair value was determined based on the closing trading price per $100 of the Notes as of the last day of trading for the period. We consider the fair value of the Notes at April 30, 2018 and July 31, 2017 to be a Level 2 measurement. The fair value of the Notes is primarily affected by the trading price of our common stock and market interest rates. As of April 30, 2018, the if-converted value of the Notes exceeded its principal amount by $406.8 million.

[0001327567-18-000014:notes:81]
The following table sets forth interest expense recognized related to the Notes (dollars in millions):

[0001327567-18-000014:notes:82]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 30, |  | April 30, |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Amortization of debt discount | $ | 5.7 |  |  | $ | 5.5 |  |  | $ | 17.1 |  |  | $ | 16.4 |  |
| Amortization of debt issuance costs | 0.8 |  |  | 0.7 |  |  | 2.1 |  |  | 1.9 |  |
| Total interest expense recognized | $ | 6.5 |  |  | $ | 6.2 |  |  | $ | 19.2 |  |  | $ | 18.3 |  |
| Effective interest rate of the liability component | 4.8 | % |  | 4.8 | % |  | 4.8 | % |  | 4.8 | % |

[0001327567-18-000014:notes:83]
Note Hedges

[0001327567-18-000014:notes:84]
To minimize the impact of potential economic dilution upon conversion of the Notes, we entered into convertible note hedge transactions (the “Note Hedges”) with respect to our common stock concurrent with the issuance of the Notes. The Note Hedges cover up to 5.2 million shares of our common stock at a strike price per share that corresponds to the initial conversion price of the Notes, which are also subject to adjustment, and are exercisable upon conversion of the Notes. The Note Hedges will expire upon maturity of the Notes. The Note Hedges are separate transactions and are not part of the terms of the Notes. Holders of the Notes will not have any rights with respect to the Note Hedges. The shares receivable related to the Note Hedges are excluded from the calculation of diluted earnings per share as they are antidilutive.

[0001327567-18-000014:notes:85]
Warrants

[0001327567-18-000014:notes:86]
Separately, but concurrently with our issuance of the Notes, we entered into transactions whereby we sold warrants (the “Warrants”) to acquire up to 5.2 million shares of our common stock at a strike price of approximately $137.85 per share, subject to adjustments. The shares issuable under the Warrants will be included in the calculation of diluted earnings per share when the average market value per share of our common stock for the reporting period exceeds the strike price of the Warrants. The Warrants are separate transactions and are not part of the Notes or Note Hedges, and are not remeasured through earnings each reporting period. Holders of the Notes and Note Hedges will not have any rights with respect to the Warrants.

[0001327567-18-000014:notes:87]
For more information on the Notes, the Note Hedges, and the Warrants, refer to Note 8. Convertible Senior Notes included in Part II, Item 8 of our Annual Report on Form 10-K for the fiscal year ended July 31, 2017.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001327567-18-000014:notes:88]
[same as prior period, unchanged from 0001327567-18-000006:notes:69]

[0001327567-18-000014:notes:89]
[same as prior period, unchanged from 0001327567-18-000006:notes:70]

[0001327567-18-000014:notes:90]
[same as prior period, unchanged from 0001327567-18-000006:notes:71]

[0001327567-18-000014:notes:91]
[same as prior period, unchanged from 0001327567-18-000006:notes:72]

[0001327567-18-000014:notes:92]
As of April 30, 2018, the total notional amount of our outstanding foreign currency forward contracts was $154.6 million. We did not have any forward contracts outstanding as of July 31, 2017. Refer to Note 2. Fair Value Measurements for the fair value of our derivative instruments as reported in our condensed consolidated balance sheets as of April 30, 2018.

[0001327567-18-000014:notes:93]
During the three and nine months ended April 30, 2018 and 2017, both unrealized gains and losses recognized in AOCI related to our cash flow hedges and amounts reclassified into earnings were not material. Unrealized losses in AOCI related to our cash flow hedges as of April 30, 2018 and 2017 were not material.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001327567-18-000014:notes:94]
[same as prior period, unchanged from 0001327567-18-000006:notes:75]

[0001327567-18-000014:notes:95]
[same as prior period, unchanged from 0001327567-18-000006:notes:76]

[0001327567-18-000014:notes:96]
[same as prior period, unchanged from 0001327567-18-000006:notes:77]

[0001327567-18-000014:notes:97]
[same as prior period, unchanged from 0001327567-18-000006:notes:78]

[0001327567-18-000014:notes:98]
[same as prior period, unchanged from 0001327567-18-000006:notes:79]

[0001327567-18-000014:notes:99]
|  | Options Outstanding |
|  | Number of Shares |  | Weighted-Average Exercise Price Per Share |  | Weighted-Average Remaining Contractual Term(Years) |  | Aggregate Intrinsic Value |
| Balance—July 31, 2017 | 1.6 |  |  | $ | 13.11 |  |  | 4.2 |  | $ | 190.6 |  |
| Options granted | — |  |  | $ | — |  |  |  |  |  |
| Options forfeited | — |  |  | $ | — |  |  |  |  |  |
| Options exercised | (0.4 | ) |  | $ | 11.77 |  |  |  |  |  |
| Balance—April 30, 2018 | 1.2 |  |  | $ | 13.54 |  |  | 3.5 |  | $ | 217.0 |  |
| Options exercisable—April 30, 2018 | 1.2 |  |  | $ | 13.54 |  |  | 3.5 |  | $ | 217.0 |  |

[0001327567-18-000014:notes:100]
[same as prior period, unchanged from 0001327567-18-000006:notes:81]

[0001327567-18-000014:notes:101]
[same as prior period, unchanged from 0001327567-18-000006:notes:82]

[0001327567-18-000014:notes:102]
[same as prior period, unchanged from 0001327567-18-000006:notes:83]

[0001327567-18-000014:notes:103]
|  | RSAs and PSAs Outstanding |  | RSUs and PSUs Outstanding |
|  | Number of Shares |  | Weighted-Average Grant-Date Fair Value Per Share |  | Number of Shares |  | Weighted-Average Grant-Date Fair Value Per Share |  | Weighted-Average Remaining Contractual Term(Years) |  | Aggregate Intrinsic Value |
| Balance—July 31, 2017 | 1.0 |  |  | $ | 163.55 |  |  | 6.5 |  |  | $ | 141.16 |  |  | 1.3 |  | $ | 854.1 |  |
| Granted(1) | — |  |  | $ | — |  |  | 2.8 |  |  | $ | 152.36 |  |  |  |  |  |
| Vested | (0.3 | ) |  | $ | 168.33 |  |  | (2.7 | ) |  | $ | 137.19 |  |  |  |  |  |
| Forfeited | (0.3 | ) |  | $ | 157.49 |  |  | (0.5 | ) |  | $ | 143.24 |  |  |  |  |  |
| Balance—April 30, 2018 | 0.4 |  |  | $ | 162.85 |  |  | 6.1 |  |  | $ | 147.82 |  |  | 1.5 |  | $ | 1,181.3 |  |

[0001327567-18-000014:notes:104]
[same as prior period, unchanged from 0001327567-18-000006:notes:85]

[0001327567-18-000014:notes:105]
[same as prior period, unchanged from 0001327567-18-000006:notes:86]

[0001327567-18-000014:notes:106]
[same as prior period, unchanged from 0001327567-18-000006:notes:87]

[0001327567-18-000014:notes:107]
[same as prior period, unchanged from 0001327567-18-000006:notes:88]

[0001327567-18-000014:notes:108]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 30, |  | April 30, |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Cost of product revenue | $ | 1.7 |  |  | $ | 1.8 |  |  | $ | 5.5 |  |  | $ | 5.5 |  |
| Cost of subscription and support revenue | 15.1 |  |  | 14.0 |  |  | 50.9 |  |  | 41.3 |  |
| Research and development | 35.4 |  |  | 37.1 |  |  | 108.4 |  |  | 116.4 |  |
| Sales and marketing | 50.7 |  |  | 46.2 |  |  | 155.2 |  |  | 139.7 |  |
| General and administrative | 20.8 |  |  | 18.3 |  |  | 60.2 |  |  | 55.1 |  |
| Total share-based compensation | $ | 123.7 |  |  | $ | 117.4 |  |  | $ | 380.2 |  |  | $ | 358.0 |  |

[0001327567-18-000014:notes:109]
As of April 30, 2018, total compensation cost related to unvested share-based awards not yet recognized was $920.0 million. This cost is expected to be amortized on a straight-line basis over a weighted-average period of approximately 2.6 years.


## us-gaap:EarningsPerShareTextBlock

[0001327567-18-000014:notes:110]
[same as prior period, unchanged from 0001327567-18-000006:notes:91]

[0001327567-18-000014:notes:111]
[same as prior period, unchanged from 0001327567-18-000006:notes:92]

[0001327567-18-000014:notes:112]
[same as prior period, unchanged from 0001327567-18-000006:notes:93]

[0001327567-18-000014:notes:113]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 30, |  | April 30, |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Net loss | $ | (46.7 | ) |  | $ | (60.9 | ) |  | $ | (145.6 | ) |  | $ | (178.4 | ) |
| Weighted-average shares used to compute net loss per share, basic and diluted | 91.9 |  |  | 91.0 |  |  | 91.3 |  |  | 90.5 |  |
| Net loss per share, basic and diluted | $ | (0.51 | ) |  | $ | (0.67 | ) |  | $ | (1.59 | ) |  | $ | (1.97 | ) |

[0001327567-18-000014:notes:114]
[same as prior period, unchanged from 0001327567-18-000006:notes:95]

[0001327567-18-000014:notes:115]
|  | Three and Nine Months Ended |
|  | April 30, |
|  | 2018 |  | 2017 |
| RSUs and PSUs | 6.1 |  |  | 6.3 |  |
| Convertible senior notes | 5.2 |  |  | 5.2 |  |
| Warrants related to the issuance of convertible senior notes | 5.2 |  |  | 5.2 |  |
| Options to purchase common stock | 1.2 |  |  | 1.6 |  |
| RSAs and PSAs | 0.4 |  |  | 1.1 |  |
| ESPP shares | 0.1 |  |  | — |  |
| Total | 18.2 |  |  | 19.4 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001327567-18-000014:notes:116]
[same as prior period, unchanged from 0001327567-18-000006:notes:97]

[0001327567-18-000014:notes:117]
[same as prior period, unchanged from 0001327567-18-000006:notes:98]

[0001327567-18-000014:notes:118]
[same as prior period, unchanged from 0001327567-18-000006:notes:99]

[0001327567-18-000014:notes:119]
[same as prior period, unchanged from 0001327567-18-000006:notes:100]

[0001327567-18-000014:notes:120]
[same as prior period, unchanged from 0001327567-18-000006:notes:101]

[0001327567-18-000014:notes:121]
The following table presents the fair value of our financial assets and liabilities measured at fair value on a recurring basis using the above input categories as of April 30, 2018 and July 31, 2017 (in millions):

[0001327567-18-000014:notes:122]
|  |  | April 30, 2018 |  | July 31, 2017 |
|  |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Cash equivalents: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 361.8 |  |  | $ | — |  |  | $ | — |  |  | $ | 361.8 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Commercial paper |  | — |  |  | 32.1 |  |  | — |  |  | 32.1 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Corporate debt securities |  | — |  |  | 1.0 |  |  | — |  |  | 1.0 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| U.S. government and agency securities |  | — |  |  | 129.6 |  |  | — |  |  | 129.6 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Total cash equivalents |  | 361.8 |  |  | 162.7 |  |  | — |  |  | 524.5 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Short-term investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Certificates of deposit |  | — |  |  | 5.4 |  |  | — |  |  | 5.4 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Corporate debt securities |  | — |  |  | 145.6 |  |  | — |  |  | 145.6 |  |  | — |  |  | 159.4 |  |  | — |  |  | 159.4 |  |
| U.S. government and agency securities |  | — |  |  | 521.2 |  |  | — |  |  | 521.2 |  |  | — |  |  | 471.3 |  |  | — |  |  | 471.3 |  |
| Total short-term investments |  | — |  |  | 672.2 |  |  | — |  |  | 672.2 |  |  | — |  |  | 630.7 |  |  | — |  |  | 630.7 |  |
| Prepaid expenses and other current assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency forward contracts |  | — |  |  | 1.0 |  |  | — |  |  | 1.0 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Total prepaid expenses and other current assets |  | — |  |  | 1.0 |  |  | — |  |  | 1.0 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Long-term investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Certificates of deposit |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 5.4 |  |  | — |  |  | 5.4 |  |
| Corporate debt securities |  | — |  |  | 135.6 |  |  | — |  |  | 135.6 |  |  | — |  |  | 186.5 |  |  | — |  |  | 186.5 |  |
| U.S. government and agency securities |  | — |  |  | 457.3 |  |  | — |  |  | 457.3 |  |  | — |  |  | 597.4 |  |  | — |  |  | 597.4 |  |
| Total long-term investments |  | — |  |  | 592.9 |  |  | — |  |  | 592.9 |  |  | — |  |  | 789.3 |  |  | — |  |  | 789.3 |  |
| Total assets measured at fair value |  | $ | 361.8 |  |  | $ | 1,428.8 |  |  | $ | — |  |  | $ | 1,790.6 |  |  | $ | — |  |  | $ | 1,420.0 |  |  | $ | — |  |  | $ | 1,420.0 |  |
| Accrued and other liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency forward contracts |  | $ | — |  |  | $ | 2.3 |  |  | $ | — |  |  | $ | 2.3 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Total accrued and other liabilities |  | — |  |  | 2.3 |  |  | — |  |  | 2.3 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Total liabilities measured at fair value |  | $ | — |  |  | $ | 2.3 |  |  | $ | — |  |  | $ | 2.3 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |

[0001327567-18-000014:notes:123]
As of April 30, 2018, we did not have any assets required to be measured at fair value on a nonrecurring basis. As of July 31, 2017, we determined that certain property and equipment related to our previous corporate headquarters were impaired. In connection with our planned relocation to our new corporate headquarters, we assessed the recoverability of certain leasehold improvements and other long-lived assets associated with our previous headquarter facilities and determined that the carrying amount of these assets exceeded their fair value of $4.2 million. The resulting impairment loss of $20.9 million was recorded as general and administrative expense in our consolidated statements of operations during the fiscal year ended July 31, 2017. We calculated the fair value of the leasehold improvements and other long-lived assets based on estimated future discounted cash flows and classified the fair value as a Level 3 measurement due to the significance of unobservable inputs, which included the amount and timing of estimated sublease rental receipts that we could reasonably obtain over the remaining lease term and the discount rate. We did not have any liabilities required to be measured at fair value on a nonrecurring basis as of April 30, 2018 and July 31, 2017.

[0001327567-18-000014:notes:124]
Refer to Note 7. Convertible Senior Notes for the carrying amount and estimated fair value of our convertible senior notes as of April 30, 2018 and July 31, 2017.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001327567-18-000014:notes:125]
Goodwill and Intangible Assets

[0001327567-18-000014:notes:126]
Goodwill

[0001327567-18-000014:notes:127]
The following table presents details of our goodwill during the nine months ended April 30, 2018 (in millions):

[0001327567-18-000014:notes:128]
|  | Amount |
| Balance as of July 31, 2017 | $ | 238.8 |  |
| Goodwill acquired | 283.4 |  |
| Balance as of April 30, 2018 | $ | 522.2 |  |

[0001327567-18-000014:notes:129]
Purchased Intangible Assets

[0001327567-18-000014:notes:130]
The following table presents details of our purchased intangible assets as of April 30, 2018 and July 31, 2017 (in millions):

[0001327567-18-000014:notes:131]
|  | April 30, 2018 |  | July 31, 2017 |
|  | Gross Carrying Amount |  | Accumulated Amortization |  | Net Carrying Amount |  | Gross Carrying Amount |  | Accumulated Amortization |  | Net Carrying Amount |
| Intangible assets subject to amortization: |  |  |  |  |  |  |  |  |  |  |  |
| Developed technology | $ | 154.5 |  |  | $ | (32.0 | ) |  | $ | 122.5 |  |  | $ | 69.7 |  |  | $ | (23.8 | ) |  | $ | 45.9 |  |
| Customer relationships | 12.2 |  |  | (0.7 | ) |  | 11.5 |  |  | 3.1 |  |  | (0.4 | ) |  | 2.7 |  |
| Acquired intellectual property | 8.9 |  |  | (4.4 | ) |  | 4.5 |  |  | 8.9 |  |  | (3.8 | ) |  | 5.1 |  |
| Trade name and trademarks | 8.5 |  |  | (0.1 | ) |  | 8.4 |  |  | — |  |  | — |  |  | — |  |
| Other | 2.2 |  |  | (2.2 | ) |  | — |  |  | 2.2 |  |  | (2.2 | ) |  | — |  |
| Total intangible assets subject to amortization | 186.3 |  |  | (39.4 | ) |  | 146.9 |  |  | 83.9 |  |  | (30.2 | ) |  | 53.7 |  |
| Intangible assets not subject to amortization: |  |  |  |  |  |  |  |  |  |  |  |
| In-process research and development | 0.8 |  |  | — |  |  | 0.8 |  |  | — |  |  | — |  |  | — |  |
| Total purchased intangible assets | $ | 187.1 |  |  | $ | (39.4 | ) |  | $ | 147.7 |  |  | $ | 83.9 |  |  | $ | (30.2 | ) |  | $ | 53.7 |  |

[0001327567-18-000014:notes:132]
We recognized amortization expense of $3.8 million and $9.2 million for the three and nine months ended April 30, 2018, respectively, and $2.5 million and $7.1 million for the three and nine months ended April 30, 2017, respectively.

[0001327567-18-000014:notes:133]
The following table summarizes estimated future amortization expense of our intangible assets as of April 30, 2018 (in millions):

[0001327567-18-000014:notes:134]
|  | Amount |
| Fiscal years ending July 31: |  |
| Remaining 2018 | $ | 7.0 |  |
| 2019 | 27.8 |  |
| 2020 | 27.7 |  |
| 2021 | 25.7 |  |
| 2022 | 21.2 |  |
| 2023 and thereafter | 37.5 |  |
| Total future amortization expense | $ | 146.9 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001327567-18-000014:notes:135]
[same as prior period, unchanged from 0001327567-18-000006:notes:106]

[0001327567-18-000014:notes:136]
Our provision for (benefit from) income taxes for the three and nine months ended April 30, 2018 reflects an effective tax rate of 5.7% and (5.1)%, respectively. Our effective tax rate for the nine months ended April 30, 2018 was negative as we recorded a provision for income taxes on year to date losses. The key components of our income tax provision primarily consisted of foreign income taxes, withholding taxes, and amortization of our deferred tax charges. In addition, we recorded the following one-time tax benefits during the nine months ended April 30, 2018: $5.8 million due to new tax legislation enacted during the fiscal quarter ended January 31, 2018; $4.6 million due to a partial release of our valuation allowance related to our acquisition of Evident.io during the fiscal quarter ended April 30, 2018; and $3.5 million due to an Israeli judicial ruling related to share-based compensation during the fiscal quarter ended April 30, 2018. Our effective tax rate differs from the U.S. statutory tax rate primarily due to deductibility of our share-based compensation, foreign income at other than U.S. tax rates, and changes in our valuation allowance.

[0001327567-18-000014:notes:137]
Our provision for income taxes for the three and nine months ended April 30, 2017 reflects an effective tax rate of (14.5)% and (9.1)%, respectively. Our effective tax rates for these periods were negative as we recorded a provision for income taxes on year to date losses. The key components of our income tax provision primarily consisted of foreign income taxes, withholding taxes, and amortization of our deferred tax charges.

[0001327567-18-000014:notes:138]
On December 22, 2017, the TCJA was enacted into law. The TCJA provides for significant tax law changes and modifications including, but not limited to, the reduction of the U.S. federal corporate statutory tax rate from 35% to 21% as of January 1, 2018, the requirement for companies to pay a one-time transition tax on earnings of certain foreign subsidiaries that were previously tax deferred, and the creation of new taxes on certain foreign-sourced earnings. As a fiscal year-end taxpayer, certain provisions of the TCJA began to impact us during the fiscal quarter ended January 31, 2018, while other provisions will impact us beginning in our fiscal year ending July 31, 2019.

[0001327567-18-000014:notes:139]
As a result of the TCJA, we recorded a provisional benefit of $5.8 million for the nine months ended April 30, 2018, related to alternative minimum tax credits that will be refundable if not utilized. We expect adjustments to our deferred tax assets resulting from the TCJA to be offset by a corresponding adjustment to our valuation allowance. We have not recorded any amounts relating to the transition tax because we had no unremitted earnings as of the measurement date, based on our current estimate.

[0001327567-18-000014:notes:140]
Accounting standards require companies to recognize the effect of tax law changes in the period of enactment. However, the SEC staff and FASB issued guidance that allows companies to record provisional amounts for the effects of the TCJA during a measurement period not to extend beyond one year from the enactment date. In accordance with this guidance, we have determined the amounts recorded and positions taken, as discussed, are provisional as of April 30, 2018. We continue to assess the impacts of the TCJA, and the final impact of the TCJA recorded by us may differ from the provisional amounts due to a number of uncertainties and factors, including information not available until the close of our fiscal year ending July 31, 2018, the need for further guidance and clarification of the new law by U.S. federal and state tax authorities, and the need for further guidance on the related income tax accounting.

[0001327567-18-000014:notes:141]
In addition to the previously discussed impacts on our fiscal year ending July 31, 2018, the TCJA also establishes new tax laws that will be effective beginning with our fiscal year ending July 31, 2019, including a provision for low-taxed income of foreign subsidiaries. Due to its complexity, we are continuing to evaluate this provision of the TCJA. Based on recent FASB deliberations, we will be allowed to make an accounting policy election to either (i) treat taxes due on future U.S. inclusions in taxable income as a current-period expense when incurred or (ii) factor such amounts into our measurement of deferred taxes. Our selection of accounting policy will depend, in part, on analyzing our facts and circumstances to determine the expected impact under each method.


## us-gaap:InvestmentsClassifiedByContractualMaturityDateTableTextBlock

[0001327567-18-000014:notes:142]
The following table summarizes the amortized cost and fair value of our available-for-sale securities as of April 30, 2018, by contractual years-to-maturity (in millions):

[0001327567-18-000014:notes:143]
|  | Amortized Cost |  | Fair Value |
| Due within one year | $ | 1,199.8 |  |  | $ | 1,196.7 |  |
| Due between one and three years | 601.6 |  |  | 592.9 |  |
| Total | $ | 1,801.4 |  |  | $ | 1,789.6 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001327567-18-000014:notes:144]
Cash Equivalents and Investments

[0001327567-18-000014:notes:145]
Unrealized losses related to these securities are due to interest rate fluctuations as opposed to credit quality. In addition, we do not intend to sell and it is not likely that we would be required to sell these securities before recovery of their amortized cost basis, which may be at maturity. As a result, there were no other-than-temporary impairments for these securities at April 30, 2018 and July 31, 2017.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001327567-18-000014:notes:146]
[same as prior period, unchanged from 0001327567-18-000006:notes:117]

[0001327567-18-000014:notes:147]
[same as prior period, unchanged from 0001327567-18-000006:notes:118]

[0001327567-18-000014:notes:148]
In August 2016, our board of directors authorized a $500.0 million share repurchase that is funded from available working capital. In February 2017, our board of directors authorized a $500.0 million increase to our repurchase program, bringing the total authorization to $1.0 billion. Repurchases may be made at management’s discretion from time to time on the open market, through privately negotiated transactions, transactions structured through investment banking institutions, block purchase techniques, 10b5-1 trading plans, or a combination of the foregoing. The repurchase authorization will expire on December 31, 2018, and may be suspended or discontinued at any time.

[0001327567-18-000014:notes:149]
During the nine months ended April 30, 2018, we repurchased and retired 1.7 million shares of our common stock under the authorization for an aggregate purchase price of $250.0 million, including transaction costs. The total price of the shares repurchased and related transaction costs are reflected as a reduction to common stock and additional paid-in capital on our condensed consolidated balance sheets. As of April 30, 2018, $330.0 million remained available for future share repurchases under the repurchase authorization.
