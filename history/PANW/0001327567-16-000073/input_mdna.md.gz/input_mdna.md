# PANW MD&A — 0001327567-16-000073


## mdna

[0001327567-16-000073:mdna:1]
[same as prior period, unchanged from 0001327567-16-000053:mdna:1]

[0001327567-16-000073:mdna:2]
[same as prior period, unchanged from 0001327567-16-000053:mdna:2]

[0001327567-16-000073:mdna:3]
[same as prior period, unchanged from 0001327567-16-000053:mdna:3]

[0001327567-16-000073:mdna:4]
| • | Key Financial Metrics. A summary of our generally accepted accounting principles (“GAAP”) and non-GAAP key financial metrics, which management monitors to evaluate our performance. |

[0001327567-16-000073:mdna:5]
| • | Results of Operations. A discussion of the nature and trends in our financial results and an analysis of our financial results comparing the three months ended October 31, 2016 to the three months ended October 31, 2015. |

[0001327567-16-000073:mdna:6]
[same as prior period, unchanged from 0001327567-16-000053:mdna:6]

[0001327567-16-000073:mdna:7]
| • | Critical Accounting Estimates. A discussion of our accounting policies that require critical estimates, assumptions, and judgments. |

[0001327567-16-000073:mdna:8]
[same as prior period, unchanged from 0001327567-16-000053:mdna:9]

[0001327567-16-000073:mdna:9]
[same as prior period, unchanged from 0001327567-16-000053:mdna:26]

[0001327567-16-000073:mdna:10]
[same as prior period, unchanged from 0001327567-16-000053:mdna:11]

[0001327567-16-000073:mdna:11]
We have pioneered the next generation of security through our innovative platform that allows enterprises, service providers, and government entities to secure their organizations by safely enabling applications running on their networks and by preventing breaches that stem from targeted cyber attacks. Our platform uses an innovative traffic classification engine that identifies network traffic by application, user, and content and provides consistent security across the network, endpoint, and cloud. Accordingly, our platform enables our end-customers to maintain the visibility and control needed to protect their valued data and critical control systems while pursuing technology initiatives, like cloud and mobility, that grow their business. We believe our platform offers superior performance compared to legacy approaches and reduces the total cost of ownership for organizations by simplifying their security infrastructure and eliminating the need for multiple, stand-alone security appliances and software products.

[0001327567-16-000073:mdna:12]
Our Next-Generation Security Platform consists of three major elements: our Next-Generation Firewall, our Advanced Endpoint Protection, and our Threat Intelligence Cloud. Our Next-Generation Firewall delivers application, user, and content visibility and control as well as protection against network-based cyber threats integrated within the firewall through our proprietary hardware and software architecture. Our Advanced Endpoint Protection prevents cyber attacks that aim to run malicious code or exploit software vulnerabilities on a broad variety of fixed and virtual endpoints and servers. Our Threat Intelligence Cloud provides central intelligence capabilities, security for software as a service (“SaaS”) applications, and automated delivery of preventative measures against cyber attacks.

[0001327567-16-000073:mdna:13]
For the first quarter of fiscal 2017 and 2016, total revenue was $398.1 million and $297.2 million, respectively, representing year-over-year growth of 34.0%. Our growth reflects the increased adoption of our hybrid SaaS revenue model, which consists of product, subscription, and support. We believe this model will enable us to benefit from recurring revenues as we continue to grow our installed end-customer base. As of October 31, 2016, we had over 35,500 end-customers in over 150 countries. Our end-customers represent a broad range of industries including education, energy, financial services, government entities, healthcare, Internet and media, manufacturing, public sector, and telecommunications, and include some of the largest Fortune 100 and Global 2000 companies in the world. We maintain a field sales force that works closely with our channel partners in developing sales opportunities. We use a two-tiered, indirect fulfillment model whereby we sell our products and services to our distributors, which, in turn, sell to our resellers, which then sell to our end-customers.

[0001327567-16-000073:mdna:14]
Our product revenue grew to $163.8 million, or 41.1% of total revenue, for the first quarter of fiscal 2017, representing year-over-year growth of 10.9%. Product revenue is generated from sales of our appliances, primarily our Next-Generation Firewall, which is available in physical and virtualized form. Our Next-Generation Firewall incorporates our proprietary PAN-OS operating system, which provides a consistent set of capabilities across our entire product line. Our products are designed for different performance requirements throughout an organization, ranging from our PA-200, which is designed for enterprise remote offices, to our top-of-the-line PA-7080, which is especially suited for very large enterprise deployments and service provider customers. The same firewall functionality that is delivered in our physical appliances is also available in our VM-Series virtual firewalls, which secure virtualized and cloud-based computing environments.

[0001327567-16-000073:mdna:15]
Our subscription and support revenue grew to $234.3 million, or 58.9% of total revenue, for the first quarter of fiscal 2017, representing year-over-year growth of 56.7%. Our subscriptions provide our end-customers with real-time access to the latest antivirus, intrusion prevention, web filtering, and modern malware prevention capabilities across fixed and mobile devices. When end-customers purchase an appliance, they typically purchase one or more of our subscriptions for additional functionality, as well as support in order to receive ongoing security updates, upgrades, bug fixes, and repairs.

[0001327567-16-000073:mdna:16]
We believe that the growth of our business and our short-term and long-term success are dependent upon many factors, including our ability to extend our technology leadership, grow our base of end-customers, expand deployment of our platform and support offerings within existing end-customers, and focus on end-customer satisfaction. To manage any future growth effectively, we must continue to improve and expand our information technology and financial infrastructure, our operating and administrative systems and controls, and our ability to manage headcount, capital, and processes in an efficient manner. While these areas present significant opportunities for us, they also pose challenges and risks that we must successfully address in order to sustain the growth of our business and improve our operating results. For additional information regarding the challenges and risks we face, see the “Risk Factors” section in Part II, Item 1A of this Quarterly Report on Form 10-Q.

[0001327567-16-000073:mdna:17]
[same as prior period, unchanged from 0001327567-16-000053:mdna:20]

[0001327567-16-000073:mdna:18]
[same as prior period, unchanged from 0001327567-16-000053:mdna:21]

[0001327567-16-000073:mdna:19]
[same as prior period, unchanged from 0001327567-16-000053:mdna:31]

[0001327567-16-000073:mdna:20]
|  | October 31, 2016 |  | July 31, 2016 |
|  | (in millions) |
| Total deferred revenue | $ | 1,359.6 |  |  | $ | 1,240.8 |  |
| Cash, cash equivalents, and investments | $ | 2,098.4 |  |  | $ | 1,938.4 |  |

[0001327567-16-000073:mdna:21]
|  | Three Months Ended October 31, |
|  | 2016 |  | 2015 |
|  | (dollars in millions) |
| Total revenue | $ | 398.1 |  |  | $ | 297.2 |  |
| Total revenue year-over-year percentage increase | 34.0 | % |  | 54.5 | % |
| Gross margin percentage | 74.6 | % |  | 73.3 | % |
| Operating loss(1) | $ | (49.9 | ) |  | $ | (32.0 | ) |
| Operating margin percentage(1) | (12.5 | )% |  | (10.8 | )% |
| Billings | $ | 516.9 |  |  | $ | 388.0 |  |
| Billings year-over-year percentage increase | 33.2 | % |  | 61.4 | % |
| Cash flow provided by operating activities | $ | 203.3 |  |  | $ | 146.7 |  |
| Free cash flow (non-GAAP) | $ | 182.4 |  |  | $ | 127.2 |  |

[0001327567-16-000073:mdna:22]
[same as prior period, unchanged from 0001327567-16-000053:mdna:90]

[0001327567-16-000073:mdna:23]
| (1) | Amounts have been adjusted for the three months ended October 31, 2015, as a result of our voluntary change in accounting policy for sales commissions. Refer to Note 1. Description of Business and Summary of Significant Accounting Policies of Notes to Condensed Consolidated Financial Statements included in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information. |

[0001327567-16-000073:mdna:24]
| • | Deferred Revenue. Our deferred revenue consists of amounts that have been invoiced but have not been recognized as revenue as of the period end. The majority of our deferred revenue balance consists of subscription and support revenue that is recognized ratably over the contractual service period. We monitor our deferred revenue balance because it represents a significant portion of revenue to be recognized in future periods. |

[0001327567-16-000073:mdna:25]
| • | Billings. We define billings as total revenue plus the change in total deferred revenue during the period. We consider billings to be a key measure used by management to manage our business given our hybrid SaaS revenue model, and believe billings provides investors with an important indicator of the health and visibility of our business because it includes subscription and support revenue, which is recognized ratably over the contractual service period, and product revenue, which is recognized at the time of shipment, provided that all other revenue recognition criteria have been met. We consider billings to be a useful metric for management and investors, particularly if we continue to experience increased sales of subscriptions and strong renewal rates for subscription and support offerings, and as we monitor our near term cash flows. While we believe that billings provides useful information to investors and others in understanding and evaluating our operating results in the same manner as our management, it is important to note that other companies, including companies in our industry, may not use billings, may calculate billings differently, may have different billing frequencies, or may use other financial measures to evaluate their performance, all of which could reduce the usefulness of billings as a comparative measure. We calculate billings in the following manner: |

[0001327567-16-000073:mdna:26]
|  | Three Months Ended October 31, |
|  | 2016 |  | 2015 |
|  | (in millions) |
| Billings: |  |  |  |
| Total revenue | $ | 398.1 |  |  | $ | 297.2 |  |
| Add: change in total deferred revenue | 118.8 |  |  | 90.8 |  |
| Billings | $ | 516.9 |  |  | $ | 388.0 |  |

[0001327567-16-000073:mdna:27]
| • | Cash Flow Provided by Operating Activities. We monitor cash flow provided by operating activities as a measure of our overall business performance. Our cash flow provided by operating activities is driven in large part by sales of our products and from up-front payments for subscription and support offerings. Monitoring cash flow provided by |

[0001327567-16-000073:mdna:28]
[same as prior period, unchanged from 0001327567-16-000053:mdna:37]

[0001327567-16-000073:mdna:29]
operating activities enables us to analyze our financial performance without the non-cash effects of certain items such as depreciation, amortization, and share-based compensation costs, thereby allowing us to better understand and manage the cash needs of our business.

[0001327567-16-000073:mdna:30]
| • | Free Cash Flow (non-GAAP). We define free cash flow, a non-GAAP financial measure, as cash provided by operating activities less purchases of property, equipment, and other assets. We consider free cash flow to be a profitability and liquidity measure that provides useful information to management and investors about the amount of cash generated by the business after necessary capital expenditures. A limitation of the utility of free cash flow as a measure of our financial performance and liquidity is that it does not represent the total increase or decrease in our cash balance for the period. In addition, it is important to note that other companies, including companies in our industry, may not use free cash flow, may calculate free cash flow in a different manner than we do, or may use other financial measures to evaluate their performance, all of which could reduce the usefulness of free cash flow as a comparative measure. A reconciliation of free cash flow to cash flow provided by operating activities, the most directly comparable financial measure calculated and presented in accordance with GAAP, is provided below: |

[0001327567-16-000073:mdna:31]
|  | Three Months Ended October 31, |
|  | 2016 |  | 2015 |
|  | (in millions) |
| Free cash flow (non-GAAP): |  |  |  |
| Net cash provided by operating activities | $ | 203.3 |  |  | $ | 146.7 |  |
| Less: purchases of property, equipment, and other assets | 20.9 |  |  | 19.5 |  |
| Free cash flow (non-GAAP) | $ | 182.4 |  |  | $ | 127.2 |  |
| Net cash used in investing activities | $ | (71.2 | ) |  | $ | (263.5 | ) |
| Net cash provided by (used in) financing activities | $ | (27.1 | ) |  | $ | 16.8 |  |

[0001327567-16-000073:mdna:32]
[same as prior period, unchanged from 0001327567-16-000053:mdna:49]

[0001327567-16-000073:mdna:33]
[same as prior period, unchanged from 0001327567-16-000053:mdna:32]

[0001327567-16-000073:mdna:34]
[same as prior period, unchanged from 0001327567-16-000053:mdna:33]

[0001327567-16-000073:mdna:35]
|  | Three Months Ended October 31, |
|  | 2016 |  | 2015 |
|  | Amount |  | % of Revenue |  | Amount(1) |  | % of Revenue(1) |
|  | (dollars in millions) |
| Revenue: |  |  |  |  |  |  |  |
| Product | $ | 163.8 |  |  | 41.1 | % |  | $ | 147.7 |  |  | 49.7 | % |
| Subscription and support | 234.3 |  |  | 58.9 | % |  | 149.5 |  |  | 50.3 | % |
| Total revenue | 398.1 |  |  | 100.0 | % |  | 297.2 |  |  | 100.0 | % |
| Cost of revenue: |  |  |  |  |  |  |  |
| Product | 42.2 |  |  | 10.6 | % |  | 38.8 |  |  | 13.0 | % |
| Subscription and support | 59.1 |  |  | 14.8 | % |  | 40.4 |  |  | 13.7 | % |
| Total cost of revenue(2) | 101.3 |  |  | 25.4 | % |  | 79.2 |  |  | 26.7 | % |
| Total gross profit | 296.8 |  |  | 74.6 | % |  | 218.0 |  |  | 73.3 | % |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 84.6 |  |  | 21.3 | % |  | 59.7 |  |  | 20.1 | % |
| Sales and marketing | 220.3 |  |  | 55.3 | % |  | 159.5 |  |  | 53.7 | % |
| General and administrative | 41.8 |  |  | 10.5 | % |  | 30.8 |  |  | 10.3 | % |
| Total operating expenses(2) | 346.7 |  |  | 87.1 | % |  | 250.0 |  |  | 84.1 | % |
| Operating loss | (49.9 | ) |  | (12.5 | )% |  | (32.0 | ) |  | (10.8 | )% |
| Interest expense | (6.0 | ) |  | (1.5 | )% |  | (5.8 | ) |  | (1.9 | )% |
| Other income, net | 2.5 |  |  | 0.6 | % |  | 2.2 |  |  | 0.7 | % |
| Loss before income taxes | (53.4 | ) |  | (13.4 | )% |  | (35.6 | ) |  | (12.0 | )% |
| Provision for income taxes | 8.4 |  |  | 2.1 | % |  | 4.3 |  |  | 1.4 | % |
| Net loss | $ | (61.8 | ) |  | (15.5 | )% |  | $ | (39.9 | ) |  | (13.4 | )% |

[0001327567-16-000073:mdna:36]
[same as prior period, unchanged from 0001327567-16-000053:mdna:112]

[0001327567-16-000073:mdna:37]
| (1) | Certain prior period amounts have been adjusted as a result of our voluntary change in accounting policy for sales commissions. Refer to Note 1. Description of Business and Summary of Significant Accounting Policies of Notes to Condensed Consolidated Financial Statements included in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information. |

[0001327567-16-000073:mdna:38]
| (2) | Includes share-based compensation as follows: |

[0001327567-16-000073:mdna:39]
|  | Three Months Ended October 31, |
|  | 2016 |  | 2015 |
| Cost of product revenue | $ | 1.7 |  |  | $ | 1.3 |  |
| Cost of subscription and support revenue | 12.4 |  |  | 7.0 |  |
| Research and development | 38.4 |  |  | 25.0 |  |
| Sales and marketing | 44.0 |  |  | 27.2 |  |
| General and administrative | 17.7 |  |  | 12.4 |  |
| Total share-based compensation | $ | 114.2 |  |  | $ | 72.9 |  |

[0001327567-16-000073:mdna:40]
[same as prior period, unchanged from 0001327567-16-000053:mdna:60]

[0001327567-16-000073:mdna:41]
[same as prior period, unchanged from 0001327567-16-000053:mdna:38]

[0001327567-16-000073:mdna:42]
Our revenue consists of product revenue and subscription and support revenue. Revenue is recognized when persuasive evidence of an arrangement exists, delivery has occurred, the fee is fixed or determinable, and collectability is reasonably assured. We expect our revenue to vary from quarter to quarter based on seasonal and cyclical factors.

[0001327567-16-000073:mdna:43]
Product Revenue

[0001327567-16-000073:mdna:44]
Product revenue is derived primarily from sales of our appliances. Product revenue also includes revenue derived from software licenses of Panorama and, to a lesser extent, the VM-Series. We recognize product revenue at the time of shipment, provided that all other revenue recognition criteria have been met.

[0001327567-16-000073:mdna:45]
|  | Three Months Ended October 31, |  |  |  |  |
|  | 2016 |  | 2015 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Product | $ | 163.8 |  |  | $ | 147.7 |  |  | $ | 16.1 |  |  | 10.9 | % |

[0001327567-16-000073:mdna:46]
Product revenue increased for the three months ended October 31, 2016 compared to the three months ended October 31, 2015, driven by increased demand for our higher end appliances. The change in product revenue due to changes in pricing was not significant.

[0001327567-16-000073:mdna:47]
Subscription and Support Revenue

[0001327567-16-000073:mdna:48]
Subscription and support revenue is derived primarily from sales of our subscription and support offerings. Our contractual subscription and support terms are typically one to five years. We recognize revenue from subscriptions and support over the contractual service period. As a percentage of total revenue, we expect our subscription and support revenue to vary from quarter to quarter and increase over the long term as we introduce new subscriptions, renew existing subscription and support contracts, and expand our installed end-customer base. Prior to fiscal 2017, subscription and support revenue was referred to as services revenue, however, the composition of subscription and support revenue has not been modified.

[0001327567-16-000073:mdna:49]
|  | Three Months Ended October 31, |  |  |  |  |
|  | 2016 |  | 2015 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Subscription | $ | 121.2 |  |  | $ | 73.6 |  |  | $ | 47.6 |  |  | 64.7 | % |
| Support | 113.1 |  |  | 75.9 |  |  | 37.2 |  |  | 49.0 | % |
| Total subscription and support | $ | 234.3 |  |  | $ | 149.5 |  |  | $ | 84.8 |  |  | 56.7 | % |

[0001327567-16-000073:mdna:50]
Subscription and support revenue increased for the three months ended October 31, 2016 compared to the three months ended October 31, 2015, due to increased demand for our subscription and support offerings from both new and existing end-customers. The mix between subscription revenue and support revenue will fluctuate over time, depending on the introduction of new subscription offerings, renewals of support services, and our ability to increase sales to new and existing customers. The change in subscription and support revenue due to changes in pricing was not significant.

[0001327567-16-000073:mdna:51]
Revenue by Geographic Theater

[0001327567-16-000073:mdna:52]
|  | Three Months Ended October 31, |  |  |  |  |
|  | 2016 |  | 2015 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Americas | $ | 280.2 |  |  | $ | 211.3 |  |  | $ | 68.9 |  |  | 32.6 | % |
| EMEA | 70.7 |  |  | 53.7 |  |  | 17.0 |  |  | 31.7 | % |
| APAC | 47.2 |  |  | 32.2 |  |  | 15.0 |  |  | 46.6 | % |
| Total revenue | $ | 398.1 |  |  | $ | 297.2 |  |  | $ | 100.9 |  |  | 34.0 | % |

[0001327567-16-000073:mdna:53]
[same as prior period, unchanged from 0001327567-16-000053:mdna:71]

[0001327567-16-000073:mdna:54]
With respect to geographic theaters, the Americas contributed the largest portion of the increase in revenue for the three months ended October 31, 2016 compared to the three months ended October 31, 2015, due to its larger and more established sales force compared to our other theaters. Revenue from both Europe, the Middle East, and Africa (“EMEA”) and Asia Pacific and Japan (“APAC”) increased for the three months ended October 31, 2016 compared to the three months ended October 31, 2015, due to our investment in increasing the size of our sales force and number of channel partners in these theaters.

[0001327567-16-000073:mdna:55]
[same as prior period, unchanged from 0001327567-16-000053:mdna:47]

[0001327567-16-000073:mdna:56]
Our cost of revenue consists of cost of product revenue and cost of subscription and support revenue.

[0001327567-16-000073:mdna:57]
[same as prior period, unchanged from 0001327567-16-000053:mdna:50]

[0001327567-16-000073:mdna:58]
Cost of product revenue primarily includes costs paid to our third-party contract manufacturer. Our cost of product revenue also includes amortization of intellectual property licenses, product testing costs, shipping costs, personnel costs, which consist of salaries, benefits, bonuses, share-based compensation, and travel and entertainment associated with our operations organization, and allocated costs. Allocated costs consist of certain facilities, depreciation, benefits, recruiting, and information technology costs that we allocate based on headcount. We expect our cost of product revenue to increase as our product revenue increases.

[0001327567-16-000073:mdna:59]
|  | Three Months Ended October 31, |  |  |  |  |
|  | 2016 |  | 2015 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Cost of product revenue | $ | 42.2 |  |  | $ | 38.8 |  |  | $ | 3.4 |  |  | 8.8 | % |
| Number of employees at period end | 92 |  |  | 75 |  |  | 17 |  |  | 22.7 | % |

[0001327567-16-000073:mdna:60]
Cost of product revenue increased for the three months ended October 31, 2016 compared to the three months ended October 31, 2015 due to an increase in product unit volume for our higher end appliances.

[0001327567-16-000073:mdna:61]
Cost of Subscription and Support Revenue

[0001327567-16-000073:mdna:62]
Cost of subscription and support revenue includes personnel costs for our global customer support and technical operations organizations, amortization of acquired intangible assets, third-party professional services costs, and allocated costs. We expect our cost of subscription and support revenue to increase as our installed end-customer base grows.

[0001327567-16-000073:mdna:63]
|  | Three Months Ended October 31, |  |  |  |  |
|  | 2016 |  | 2015 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Cost of subscription and support revenue | $ | 59.1 |  |  | $ | 40.4 |  |  | $ | 18.7 |  |  | 46.3 | % |
| Number of employees at period end | 575 |  |  | 406 |  |  | 169 |  |  | 41.6 | % |

[0001327567-16-000073:mdna:64]
Cost of subscription and support revenue increased for the three months ended October 31, 2016 compared to the three months ended October 31, 2015, driven by increases in personnel costs, which grew $12.8 million to $34.7 million for the three months ended October 31, 2016 compared to the three months ended October 31, 2015. The increase in personnel costs were due to headcount growth. The remaining increase was due to expansion of our customer service capabilities and infrastructure to support our growing installed end-customer base.

[0001327567-16-000073:mdna:65]
[same as prior period, unchanged from 0001327567-16-000053:mdna:58]

[0001327567-16-000073:mdna:66]
Gross margin, or gross profit as a percentage of revenue, has been and will continue to be affected by a variety of factors, including the average sales price of our products, manufacturing costs, the mix of products sold, and the mix of revenue between product and subscription and support offerings. For sales of our products, our higher end firewall products generally have higher gross margins than our lower end firewall products within each product series. For sales of our subscription and support offerings, our subscription offerings typically have higher gross margins than our support offerings. We expect our gross margins to fluctuate over time depending on the factors described above.

[0001327567-16-000073:mdna:67]
[same as prior period, unchanged from 0001327567-16-000053:mdna:83]

[0001327567-16-000073:mdna:68]
|  | Three Months Ended October 31, |
|  | 2016 |  | 2015 |
|  | Amount |  | Gross Margin |  | Amount |  | Gross Margin |
|  | (dollars in millions) |
| Product | $ | 121.6 |  |  | 74.2 | % |  | $ | 108.9 |  |  | 73.8 | % |
| Subscription and support | 175.2 |  |  | 74.8 | % |  | 109.1 |  |  | 72.9 | % |
| Total gross profit | $ | 296.8 |  |  | 74.6 | % |  | $ | 218.0 |  |  | 73.3 | % |

[0001327567-16-000073:mdna:69]
Product gross margin increased for the three months ended October 31, 2016 compared to the three months ended October 31, 2015, driven by our continued focus on material cost reductions. Subscription and support gross margin increased for the three months ended October 31, 2016 compared to the three months ended October 31, 2015 due to contributions from our higher margin subscription offerings.

[0001327567-16-000073:mdna:70]
[same as prior period, unchanged from 0001327567-16-000053:mdna:63]

[0001327567-16-000073:mdna:71]
Our operating expenses consist of research and development, sales and marketing, and general and administrative expense. Personnel costs are the most significant component of operating expenses and consist of salaries, benefits, bonuses, share-based compensation, travel and entertainment, and with regard to sales and marketing expense, sales commissions. Our operating expenses also include allocated costs, which consist of certain facilities, depreciation, benefits, recruiting, and information technology costs that we allocate based on headcount. We expect operating expenses to increase in absolute dollars and decrease over the long term as a percentage of revenue as we continue to scale our business. As of October 31, 2016, we expect to recognize approximately $1.0 billion of share-based compensation expense over a weighted-average period of approximately 2.7 years, excluding additional share-based compensation expense related to any future grants of share-based awards. Share-based compensation expense, net of forfeitures, is recognized on a straight-line basis over the requisite service periods of the awards.

[0001327567-16-000073:mdna:72]
[same as prior period, unchanged from 0001327567-16-000053:mdna:65]

[0001327567-16-000073:mdna:73]
[same as prior period, unchanged from 0001327567-16-000053:mdna:66]

[0001327567-16-000073:mdna:74]
|  | Three Months Ended October 31, |  |  |  |  |
|  | 2016 |  | 2015 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Research and development | $ | 84.6 |  |  | $ | 59.7 |  |  | $ | 24.9 |  |  | 41.7 | % |
| Number of employees at period end | 648 |  |  | 520 |  |  | 128 |  |  | 24.6 | % |

[0001327567-16-000073:mdna:75]
Research and development expense increased for the three months ended October 31, 2016 compared to the three months ended October 31, 2015, driven by an increase in personnel costs, which grew $20.5 million to $70.3 million for the three months ended October 31, 2016 compared to the three months ended October 31, 2015. The increase in personnel costs was due to headcount growth.

[0001327567-16-000073:mdna:76]
[same as prior period, unchanged from 0001327567-16-000053:mdna:69]

[0001327567-16-000073:mdna:77]
Sales and marketing expense consists primarily of personnel costs, including commission expense. Sales and marketing expense also includes costs for market development programs, promotional and other marketing costs, professional services, and allocated costs. We continue to thoughtfully invest in headcount and have substantially grown our sales presence internationally. We expect sales and marketing expense to continue to increase in absolute dollars as we increase the size of our sales and marketing organizations to increase touch points with end-customers and to expand our international presence, although our sales and marketing expense may fluctuate as a percentage of total revenue.

[0001327567-16-000073:mdna:78]
[same as prior period, unchanged from 0001327567-16-000053:mdna:94]

[0001327567-16-000073:mdna:79]
|  | Three Months Ended October 31, |  |  |  |  |
|  | 2016 |  | 2015 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Sales and marketing(1) | $ | 220.3 |  |  | $ | 159.5 |  |  | $ | 60.8 |  |  | 38.1 | % |
| Number of employees at period end | 2,181 |  |  | 1,642 |  |  | 539 |  |  | 32.8 | % |

[0001327567-16-000073:mdna:80]
______________

[0001327567-16-000073:mdna:81]
| (1) | Prior period amount has been adjusted as a result of our voluntary change in accounting policy for sales commissions. Refer to Note 1. Description of Business and Summary of Significant Accounting Policies of Notes to Condensed Consolidated Financial Statements included in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information. |

[0001327567-16-000073:mdna:82]
Sales and marketing expense increased for the three months ended October 31, 2016 compared to the three months ended October 31, 2015. The increase was primarily driven by an increase in personnel costs, which grew $48.9 million to $165.5 million for the three months ended October 31, 2016 compared to the three months ended October 31, 2015, due to headcount growth. The remaining increase includes $6.7 million related to investments in demand generation activities and sales related events to support our revenue growth.

[0001327567-16-000073:mdna:83]
[same as prior period, unchanged from 0001327567-16-000053:mdna:74]

[0001327567-16-000073:mdna:84]
[same as prior period, unchanged from 0001327567-16-000053:mdna:75]

[0001327567-16-000073:mdna:85]
|  | Three Months Ended October 31, |  |  |  |  |
|  | 2016 |  | 2015 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| General and administrative | $ | 41.8 |  |  | $ | 30.8 |  |  | $ | 11.0 |  |  | 35.7 | % |
| Number of employees at period end | 464 |  |  | 355 |  |  | 109 |  |  | 30.7 | % |

[0001327567-16-000073:mdna:86]
General and administrative expense increased for the three months ended October 31, 2016 compared to the three months ended October 31, 2015, driven by an increase in personnel costs, which grew $10.3 million to $31.1 million for the three months ended October 31, 2016 compared to the three months ended October 31, 2015. The increase in personnel costs was due to headcount growth.

[0001327567-16-000073:mdna:87]
[same as prior period, unchanged from 0001327567-16-000053:mdna:84]

[0001327567-16-000073:mdna:88]
[same as prior period, unchanged from 0001327567-16-000053:mdna:85]

[0001327567-16-000073:mdna:89]
|  | Three Months Ended October 31, |  | Change |
|  | 2016 |  | 2015 |  | Amount |  | % |
|  | (dollars in millions) |
| Provision for income taxes | $ | 8.4 |  |  | $ | 4.3 |  |  | $ | 4.1 |  |  | 95.3 | % |
| Effective tax rate(1) | (15.7 | )% |  | (12.1 | )% |  |  |  |  |

[0001327567-16-000073:mdna:90]
______________

[0001327567-16-000073:mdna:91]
| (1) | Prior period effective tax rate has been adjusted as a result of our voluntary change in accounting policy for sales commissions. Refer to Note 1. Description of Business and Summary of Significant Accounting Policies of |

[0001327567-16-000073:mdna:92]
[same as prior period, unchanged from 0001327567-16-000053:mdna:108]

[0001327567-16-000073:mdna:93]
Notes to Condensed Consolidated Financial Statements included in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information.

[0001327567-16-000073:mdna:94]
We recorded an income tax provision for the three months ended October 31, 2016, due to federal, state, and foreign income taxes, withholding taxes, and amortization of our deferred tax charges. The provision for income taxes increased for the three months ended October 31, 2016 compared to the three months ended October 31, 2015, primarily due to an increase in U.S. profits resulting in an increase in U.S. taxes.

[0001327567-16-000073:mdna:95]
[same as prior period, unchanged from 0001327567-16-000053:mdna:88]

[0001327567-16-000073:mdna:96]
|  | October 31, 2016 |  | July 31, 2016 |
|  | (in millions) |
| Working capital(1)(2) | $ | 465.0 |  |  | $ | 927.2 |  |
| Cash, cash equivalents, and investments: |  |  |  |
| Cash and cash equivalents | $ | 839.4 |  |  | $ | 734.4 |  |
| Investments | 1,259.0 |  |  | 1,204.0 |  |
| Total cash, cash equivalents, and investments | $ | 2,098.4 |  |  | $ | 1,938.4 |  |

[0001327567-16-000073:mdna:97]
______________

[0001327567-16-000073:mdna:98]
| (1) | Working capital as of July 31, 2016, has been adjusted as a result of our voluntary change in accounting policy for sales commissions. Refer to Note 1. Description of Business and Summary of Significant Accounting Policies of Notes to Condensed Consolidated Financial Statements included in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information. |

[0001327567-16-000073:mdna:99]
| (2) | The net carrying amount of the Notes was classified in current liabilities in our condensed consolidated balance sheets as of October 31, 2016. Refer to Note 5. Convertible Senior Notes of Notes to Condensed Consolidated Financial Statements included in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information. |

[0001327567-16-000073:mdna:100]
At October 31, 2016, our total cash, cash equivalents, and investments of $2.1 billion were held for general corporate purposes, of which approximately $208.3 million was held outside of the United States. We do not provide for federal income taxes on the undistributed earnings of our foreign subsidiaries, all of which we expect to reinvest outside of the United States indefinitely. However, if these funds were needed for our domestic operations, we would be required to accrue and pay U.S. taxes on undistributed earnings of foreign subsidiaries. There are no other restrictions on the use of these funds. If we were to repatriate these earnings to the United States, any associated income tax liability would be insignificant.

[0001327567-16-000073:mdna:101]
As of October 31, 2016, all of our 0.0% Convertible Senior Notes due 2019 (the “Notes”) remained outstanding. The Notes mature on July 1, 2019, however, prior to January 1, 2019, holders may surrender their Notes for early conversion under certain circumstances. Upon conversion, we will pay cash equal to the aggregate principal amount of the Notes to be converted, and, at our election, will pay or deliver cash and/or shares of our common stock for the amount of our conversion obligation in excess of the aggregate principal amount of the Notes being converted. Refer to Note 5. Convertible Senior Notes of Notes to Condensed Consolidated Financial Statements included in Part I, Item 1 of this Quarterly Report on Form 10-Q for information on the Notes.

[0001327567-16-000073:mdna:102]
In August 2016, our board of directors authorized a $500.0 million share repurchase which will be funded from available working capital. Repurchases may be made at management’s discretion from time to time. The repurchase authorization will expire on August 31, 2018, and may be suspended or discontinued at any time. As of October 31, 2016, $450.0 million was available for future share repurchases under the repurchase authorization. Refer to Note 7. Stockholders’ Equity of Notes to Condensed Consolidated Financial Statements included in Part I, Item 1 of this Quarterly Report on Form 10-Q for information on the repurchase authorization.

[0001327567-16-000073:mdna:103]
[same as prior period, unchanged from 0001327567-16-000053:mdna:125]

[0001327567-16-000073:mdna:104]
The following table summarizes our cash flows for the three months ended October 31, 2016 and 2015:

[0001327567-16-000073:mdna:105]
|  | Three Months Ended October 31, |
| 2016 |  | 2015 |
|  | (in millions) |
| Net cash provided by operating activities | $ | 203.3 |  |  | $ | 146.7 |  |
| Net cash used in investing activities | (71.2 | ) |  | (263.5 | ) |
| Net cash provided by (used in) financing activities | (27.1 | ) |  | 16.8 |  |
| Net increase (decrease) in cash and cash equivalents | $ | 105.0 |  |  | $ | (100.0 | ) |

[0001327567-16-000073:mdna:106]
We believe that our cash flow from operations with existing cash and cash equivalents will be sufficient to meet our anticipated cash needs for the foreseeable future. Our future capital requirements will depend on many factors including our growth rate, the timing and extent of spending to support development efforts, the expansion of sales and marketing activities, the introduction of new and enhanced products and subscription and support offerings, the costs to acquire or invest in complementary businesses and technologies, the costs to ensure access to adequate manufacturing capacity, the investments in our new corporate headquarters, and the continuing market acceptance of our products and subscription and support offerings. In addition, from time to time we may incur additional tax liability in connection with certain corporate structuring decisions.

[0001327567-16-000073:mdna:107]
[same as prior period, unchanged from 0001327567-16-000053:mdna:98]

[0001327567-16-000073:mdna:108]
[same as prior period, unchanged from 0001327567-16-000053:mdna:99]

[0001327567-16-000073:mdna:109]
[same as prior period, unchanged from 0001327567-16-000053:mdna:100]

[0001327567-16-000073:mdna:110]
Cash provided by operating activities during the three months ended October 31, 2016 was $203.3 million, an increase of $56.6 million compared to the three months ended October 31, 2015. The increase was due to growth of our business and changes in our assets and liabilities during the three months ended October 31, 2016, which included an increase in sales of subscription and support contracts to new and existing customers as reflected by an increase in deferred revenue.

[0001327567-16-000073:mdna:111]
[same as prior period, unchanged from 0001327567-16-000053:mdna:102]

[0001327567-16-000073:mdna:112]
[same as prior period, unchanged from 0001327567-16-000053:mdna:103]

[0001327567-16-000073:mdna:113]
Cash used in investing activities during the three months ended October 31, 2016 was $71.2 million, a decrease of $192.3 million compared to the three months ended October 31, 2015, due to lower net purchases of available-for-sale investments.

[0001327567-16-000073:mdna:114]
[same as prior period, unchanged from 0001327567-16-000053:mdna:105]

[0001327567-16-000073:mdna:115]
Our financing activities have consisted of proceeds from sales of shares through employee equity incentive plans and cash used in repurchases of shares of our common stock.

[0001327567-16-000073:mdna:116]
Cash used in financing activities during the three months ended October 31, 2016 was $27.1 million, a change of $43.9 million compared to the three months ended October 31, 2015, due to the repurchase of $50.0 million of common stock during the three months ended October 31, 2016.

[0001327567-16-000073:mdna:117]
[same as prior period, unchanged from 0001327567-16-000053:mdna:118]

[0001327567-16-000073:mdna:118]
As of October 31, 2016, we did not have any relationships with unconsolidated organizations or financial partnerships, such as structured finance or special purpose entities that would have been established for the purpose of facilitating off-balance sheet arrangements or other contractually narrow or limited purposes.

[0001327567-16-000073:mdna:119]
[same as prior period, unchanged from 0001327567-16-000053:mdna:120]

[0001327567-16-000073:mdna:120]
[same as prior period, unchanged from 0001327567-16-000053:mdna:121]

[0001327567-16-000073:mdna:121]
- 26 -

[0001327567-16-000073:mdna:122]
We believe the critical accounting estimates discussed under Item 7, “Management’s Discussion and Analysis of Financial Condition and Results of Operations” in our Annual Report on Form 10-K filed with the SEC on September 8, 2016, reflect our more significant judgments and estimates used in the preparation of our condensed consolidated financial statements. There have been no significant changes to our critical accounting estimates as filed in such report.

[0001327567-16-000073:mdna:123]
[same as prior period, unchanged from 0001327567-16-000053:mdna:123]

[0001327567-16-000073:mdna:124]
[same as prior period, unchanged from 0001327567-16-000053:mdna:124]
