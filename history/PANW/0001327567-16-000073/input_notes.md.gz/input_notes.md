# PANW notes — 0001327567-16-000073


## us-gaap:AvailableForSaleSecuritiesTextBlock

[0001327567-16-000073:notes:1]
The following tables summarize the amortized cost, unrealized gains and losses, and fair value of our available-for-sale investments as of October 31, 2016 and July 31, 2016 (in millions):

[0001327567-16-000073:notes:2]
|  | October 31, 2016 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Estimated Fair Value |
| Certificates of deposit | $ | 5.4 |  |  | $ | — |  |  | $ | — |  |  | $ | 5.4 |  |
| Commercial paper | 17.9 |  |  | — |  |  | — |  |  | 17.9 |  |
| Corporate debt securities | 298.9 |  |  | 0.4 |  |  | (0.3 | ) |  | 299.0 |  |
| U.S. government and agency securities | 937.0 |  |  | 0.3 |  |  | (0.6 | ) |  | 936.7 |  |
| Total | $ | 1,259.2 |  |  | $ | 0.7 |  |  | $ | (0.9 | ) |  | $ | 1,259.0 |  |

[0001327567-16-000073:notes:3]
|  | July 31, 2016 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Estimated Fair Value |
| Certificates of deposit | $ | 5.4 |  |  | $ | — |  |  | $ | — |  |  | $ | 5.4 |  |
| Commercial paper | 3.0 |  |  | — |  |  | — |  |  | 3.0 |  |
| Corporate debt securities | 286.7 |  |  | 0.8 |  |  | — |  |  | 287.5 |  |
| U.S. government and agency securities | 907.3 |  |  | 0.9 |  |  | (0.1 | ) |  | 908.1 |  |
| Total | $ | 1,202.4 |  |  | $ | 1.7 |  |  | $ | (0.1 | ) |  | $ | 1,204.0 |  |


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001327567-16-000073:notes:4]
[same as prior period, unchanged from 0001327567-16-000053:notes:4]

[0001327567-16-000073:notes:5]
The accompanying condensed consolidated financial statements have been prepared in conformity with U.S. generally accepted accounting principles, consistent in all material respects with those applied in our Annual Report on Form 10-K for the fiscal year ended July 31, 2016, filed with the Securities and Exchange Commission on September 8, 2016. Our condensed consolidated financial statements include our accounts and our wholly owned subsidiaries. All significant intercompany balances and transactions have been eliminated in consolidation.

[0001327567-16-000073:notes:6]
Our condensed consolidated financial statements are unaudited, but include all adjustments of a normal recurring nature necessary for a fair presentation of our quarterly results. We have made estimates and judgments affecting the amounts reported in our condensed consolidated financial statements and the accompanying notes. The actual results that we experience may differ materially from our estimates. Certain prior period amounts have been adjusted as a result of our voluntary change in accounting policy for sales commissions and our adoption of new accounting guidance related to debt issuance costs. Refer to “Summary of Significant Accounting Policies” and “Recent Accounting Pronouncements” below for more information.

[0001327567-16-000073:notes:7]
Our condensed consolidated financial statements should be read in conjunction with the consolidated financial statements and related notes in our Annual Report on Form 10-K for the fiscal year ended July 31, 2016.


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock

[0001327567-16-000073:notes:8]
[same as prior period, unchanged from 0001327567-16-000053:notes:8]

[0001327567-16-000073:notes:9]
[same as prior period, unchanged from 0001327567-16-000053:notes:9]

[0001327567-16-000073:notes:10]
Palo Alto Networks, Inc. (the “Company,” “we,” “us,” or “our”), located in Santa Clara, California, was incorporated in March 2005 under the laws of the State of Delaware and commenced operations in April 2005. We offer a next-generation security platform that empowers enterprises, service providers, and government entities to secure their organizations by safely enabling applications running on their networks and by preventing breaches that stem from targeted cyber attacks.

[0001327567-16-000073:notes:11]
[same as prior period, unchanged from 0001327567-16-000053:notes:11]

[0001327567-16-000073:notes:12]
There have been no material changes to our significant accounting policies as of and for the three months ended October 31, 2016, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended July 31, 2016, except for our voluntary change in accounting policy related to sales commissions discussed below.

[0001327567-16-000073:notes:13]
Change in Accounting Policy for Sales Commissions

[0001327567-16-000073:notes:14]
Effective August 1, 2016, we voluntarily changed our accounting policy for sales commissions that are incremental and directly related to non-cancelable customer sales contracts from recording an expense when incurred to deferral and amortization of the sales commissions over the term of the related contract in proportion to the recognized revenue. We believe this change in accounting policy is preferable as the direct and incremental commission costs are closely related to the associated revenue, and therefore should be deferred and recognized as an expense over the same period that the related revenue is recognized.

[0001327567-16-000073:notes:15]
Short-term deferred commissions are included in prepaid expenses and other current assets, while long-term deferred commissions are included in other assets in our condensed consolidated balance sheets. The amortization of deferred commissions is included in sales and marketing expense in our condensed consolidated statements of operations.

[0001327567-16-000073:notes:16]
The adoption of this accounting policy change has been applied retrospectively to all prior periods presented in this Quarterly Report on Form 10-Q, in which the cumulative effect of the change of $71.8 million has been reflected in accumulated deficit as of August 1, 2015, the beginning of the earliest period presented.

[0001327567-16-000073:notes:17]
The following tables present the changes to financial statement line items as a result of the accounting change for the periods presented in our condensed consolidated financial statements (in millions, except per share data):

[0001327567-16-000073:notes:18]
|  | October 31, 2016 |  | July 31, 2016 |
|  | Computed under Prior Method |  | Impact of Commission Adjustment |  | As Reported |  | As Previously Reported |  | Impact of Commission Adjustment |  | As Adjusted |
| Condensed Consolidated Balance Sheets |  |  |  |  |  |  |  |  |  |  |  |
| Prepaid expenses and other current assets | $ | 75.4 |  |  | $ | 54.0 |  |  | $ | 129.4 |  |  | $ | 84.8 |  |  | $ | 54.9 |  |  | $ | 139.7 |  |
| Other assets | 53.6 |  |  | 48.4 |  |  | 102.0 |  |  | 64.6 |  |  | 50.1 |  |  | 114.7 |  |
| Other long-term liabilities | 85.0 |  |  | 0.8 |  |  | 85.8 |  |  | 79.4 |  |  | — |  |  | 79.4 |  |
| Accumulated deficit | $ | (785.0 | ) |  | $ | 101.6 |  |  | $ | (683.4 | ) |  | $ | (726.6 | ) |  | $ | 105.0 |  |  | $ | (621.6 | ) |

[0001327567-16-000073:notes:19]
|  | Three Months Ended October 31, 2016 |  | Three Months Ended October 31, 2015 |
|  | Computed under Prior Method |  | Impact of Commission Adjustment |  | As Reported |  | As Previously Reported |  | Impact of Commission Adjustment |  | As Adjusted |
| Condensed Consolidated Statements of Operations |  |  |  |  |  |  |  |  |  |  |  |
| Sales and marketing | $ | 217.7 |  |  | $ | 2.6 |  |  | $ | 220.3 |  |  | $ | 158.3 |  |  | $ | 1.2 |  |  | $ | 159.5 |  |
| Operating loss | (47.3 | ) |  | (2.6 | ) |  | (49.9 | ) |  | (30.8 | ) |  | (1.2 | ) |  | (32.0 | ) |
| Provision for income taxes | 7.6 |  |  | 0.8 |  |  | 8.4 |  |  | 4.3 |  |  | — |  |  | 4.3 |  |
| Net loss | $ | (58.4 | ) |  | $ | (3.4 | ) |  | $ | (61.8 | ) |  | $ | (38.7 | ) |  | $ | (1.2 | ) |  | $ | (39.9 | ) |
| Net loss per share, basic and diluted | $ | (0.65 | ) |  | $ | (0.04 | ) |  | $ | (0.69 | ) |  | $ | (0.45 | ) |  | $ | (0.02 | ) |  | $ | (0.47 | ) |
| Weighted-average shares used to compute net loss per share, basic and diluted | 89.8 |  |  | — |  |  | 89.8 |  |  | 85.1 |  |  | — |  |  | 85.1 |  |
| Condensed Consolidated Statements of Comprehensive Loss |  |  |  |  |  |  |  |  |  |  |  |
| Net loss | $ | (58.4 | ) |  | $ | (3.4 | ) |  | $ | (61.8 | ) |  | $ | (38.7 | ) |  | $ | (1.2 | ) |  | $ | (39.9 | ) |
| Comprehensive loss | $ | (61.3 | ) |  | $ | (3.4 | ) |  | $ | (64.7 | ) |  | $ | (39.0 | ) |  | $ | (1.2 | ) |  | $ | (40.2 | ) |

[0001327567-16-000073:notes:20]
This change in accounting policy does not affect our balance of cash and cash equivalents and, as a result, did not change net cash flows from operating, investing, or financing activities, or materially impact any individual line items presented in our condensed consolidated statement of cash flows for the three months ended October 31, 2015.

[0001327567-16-000073:notes:21]
[same as prior period, unchanged from 0001327567-16-000053:notes:13]

[0001327567-16-000073:notes:22]
Recently Adopted Accounting Pronouncements

[0001327567-16-000073:notes:23]
In April 2015, the Financial Accounting Standards Board (“FASB”) issued new authoritative guidance on fees paid in a cloud computing arrangement. The standard requires customers in a cloud computing arrangement to evaluate whether the arrangement includes a software license. If the arrangement includes a software license, the customer should account for the software license element of the arrangement consistent with the acquisition of other software licenses. If the arrangement does not include a software license, the customer should account for the arrangement as a service contract. We adopted the guidance in our first quarter of fiscal 2017 on a prospective basis. Our adoption of this guidance did not have a material impact on our condensed consolidated financial statements.

[0001327567-16-000073:notes:24]
In April 2015, the FASB issued updated authoritative guidance to simplify the presentation of debt issuance costs. The amended standard requires that debt issuance costs related to a recognized debt liability be presented in the balance sheet as a direct deduction from the carrying amount of the related debt liability, consistent with the presentation of debt discounts, instead of being presented as an asset. We adopted the guidance in our first quarter of fiscal 2017 on a retrospective basis, and as a result, we reduced other assets and convertible senior notes, net by $8.0 million on our condensed consolidated balance sheets as of July 31, 2016.

[0001327567-16-000073:notes:25]
Recently Issued Accounting Pronouncements

[0001327567-16-000073:notes:26]
In October 2016, the FASB issued authoritative guidance requiring the recognition of income tax consequences of an intra-entity transfer of an asset, other than inventory, when the transfer occurs. The standard is effective for us for our first quarter of fiscal 2019 and will be applied on a modified retrospective basis. Early adoption is permitted. We are currently evaluating whether this standard will have a material impact on our condensed consolidated financial statements.

[0001327567-16-000073:notes:27]
In August 2016, the FASB issued new authoritative guidance addressing eight specific cash flow issues with the objective of reducing the existing diversity in practice in how certain transactions are presented and classified in the statement of cash flows. The standard is effective for us for our first quarter of fiscal 2019 and will be applied on a retrospective basis. Early adoption is permitted. We are currently evaluating whether this standard will have a material impact on our condensed consolidated financial statements.

[0001327567-16-000073:notes:28]
In June 2016, the FASB issued new authoritative guidance on the accounting for credit losses on most financial assets and certain financial instruments. The standard replaces the existing incurred loss model with an expected credit loss model for financial assets measured at amortized cost, including trade receivables, and requires that credit losses on available-for-sale debt securities be presented as an allowance rather than as a write-down. The standard is effective for us for our first quarter of fiscal 2021 and will be applied on a modified retrospective basis. Early adoption is permitted beginning our first quarter of fiscal 2020. We are currently evaluating whether this standard will have a material impact on our condensed consolidated financial statements.

[0001327567-16-000073:notes:29]
In March 2016, the FASB issued authoritative guidance simplifying several aspects of the accounting for employee share-based payment transactions, including the income tax consequences, accounting for forfeitures, and classification of excess tax benefits on the statement of cash flows. The standard is effective for us for our first quarter of fiscal 2018, however, early adoption is permitted. We are currently evaluating whether this standard will have a material impact on our condensed consolidated financial statements.

[0001327567-16-000073:notes:30]
[same as prior period, unchanged from 0001327567-16-000053:notes:15]

[0001327567-16-000073:notes:31]
[same as prior period, unchanged from 0001327567-16-000053:notes:18]


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001327567-16-000073:notes:32]
Commitments and Contingencies

[0001327567-16-000073:notes:33]
Leases

[0001327567-16-000073:notes:34]
We lease our facilities under various non-cancelable operating leases, which expire through the year ending July 31, 2028.

[0001327567-16-000073:notes:35]
The following table presents details of the aggregate future non-cancelable minimum rental payments under our operating leases as of October 31, 2016 (in millions):

[0001327567-16-000073:notes:36]
|  | Amount |
| Fiscal years ending July 31: |  |
| Remaining 2017 | $ | 20.6 |  |
| 2018 | 27.2 |  |
| 2019 | 46.5 |  |
| 2020 | 50.2 |  |
| 2021 | 55.0 |  |
| 2022 and thereafter | 316.6 |  |
| Committed gross lease payments | 516.1 |  |
| Less: proceeds from sublease rental | 4.4 |  |
| Net operating lease obligation | $ | 511.7 |  |

[0001327567-16-000073:notes:37]
Contract Manufacturer Commitments

[0001327567-16-000073:notes:38]
Our independent contract manufacturer procures components and assembles our products based on our forecasts. These forecasts are based on estimates of demand for our products primarily for the next 12 months, which are in turn based on historical trends and an analysis from our sales and product marketing organizations, adjusted for overall market conditions. In order to reduce manufacturing lead times and plan for adequate supply, we may issue forecasts and orders for components and products that are non-cancelable. As of October 31, 2016, our purchase commitments under such orders were $63.9 million, excluding obligations under contracts that we can cancel without a significant penalty.

[0001327567-16-000073:notes:39]
Litigation

[0001327567-16-000073:notes:40]
We are subject to legal proceedings, claims, and litigation arising in the ordinary course of business, including intellectual property litigation. Such matters are subject to many uncertainties and outcomes are not predictable with assurance. We accrue for contingencies when we believe that a loss is probable and that we can reasonably estimate the amount of any such loss.

[0001327567-16-000073:notes:41]
To the extent there is a reasonable possibility that a loss exceeding amounts already recognized may be incurred and the amount of such additional loss would be material, we will either disclose the estimated additional loss or state that such an estimate cannot be made. As of October 31, 2016, we have not recorded any significant accruals for loss contingencies associated with such legal proceedings, determined that an unfavorable outcome is probable or reasonably possible, or determined that the amount or range of any possible loss is reasonably estimable.


## us-gaap:ConvertibleDebtTableTextBlock

[0001327567-16-000073:notes:42]
The following table sets forth the components of the Notes as of October 31, 2016 and July 31, 2016 (in millions):

[0001327567-16-000073:notes:43]
|  | October 31, 2016 |  | July 31, 2016 |
| Liability: |  |  |  |
| Principal | $ | 575.0 |  |  | $ | 575.0 |  |
| Less: debt discount and debt issuance costs, net of amortization | 68.8 |  |  | 74.8 |  |
| Net carrying amount | $ | 506.2 |  |  | $ | 500.2 |  |
| Equity (including temporary equity) | $ | 109.8 |  |  | $ | 109.8 |  |


## us-gaap:DebtDisclosureTextBlock

[0001327567-16-000073:notes:44]
Convertible Senior Notes

[0001327567-16-000073:notes:45]
On June 30, 2014, we issued $575.0 million aggregate principal amount of 0.0% Convertible Senior Notes due 2019 (the “Notes”). The Notes mature on July 1, 2019, unless converted or repurchased in accordance with their terms prior to such date. The Notes do not contain any financial covenants and we cannot redeem the Notes prior to maturity.

[0001327567-16-000073:notes:46]
The Notes are convertible for up to 5.2 million shares of our common stock at an initial conversion price of approximately $110.28 per share of common stock, subject to adjustment. Holders of the Notes may surrender their Notes for conversion at their option at any time prior to the close of business on the business day immediately preceding January 1, 2019, only under the following circumstances:

[0001327567-16-000073:notes:47]
| • | if the last reported sale price of our common stock for at least 20 trading days (whether or not consecutive) during a period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the conversion price for the Notes on each applicable trading day (the “sale price condition”); |

[0001327567-16-000073:notes:48]
| • | during the five business day period after any five consecutive trading day period, in which the trading price per $1,000 principal amount of Notes for each trading day of the measurement period was less than 98% of the product of the last reported sale price of our common stock and the conversion rate for the Notes on each such trading day; or |

[0001327567-16-000073:notes:49]
| • | upon the occurrence of specified corporate events. |

[0001327567-16-000073:notes:50]
On or after January 1, 2019, holders may convert all or any portion of their Notes at any time prior to the close of business on the second scheduled trading day immediately preceding the maturity date regardless of the foregoing conditions. Upon conversion, holders will receive cash equal to the aggregate principal amount of the Notes to be converted, and, at our election, cash and/or shares of our common stock for any amounts in excess of the aggregate principal amount of the Notes being converted.

[0001327567-16-000073:notes:51]
The sale price condition was not met during the fiscal quarter ended July 31, 2016. Since the Notes were not convertible, the net carrying amount of the Notes and related debt issuance costs were classified as long-term liabilities and the equity component was included in additional paid-in capital in our condensed consolidated balance sheets as of July 31, 2016. The sale price condition was met during the fiscal quarter ended October 31, 2016, and as a result, holders may convert their Notes at any time during the fiscal quarter ending January 31, 2017. Accordingly, the net carrying amount of the Notes and related debt issuance costs were reclassified into current liabilities and the portion of the equity component representing the conversion option was reclassified into temporary equity in our condensed consolidated balance sheets as of October 31, 2016. The portion of the equity component classified as temporary equity is measured as the difference between the principal and net carrying amount of the Notes, excluding debt issuance costs.

[0001327567-16-000073:notes:52]
The total estimated fair value of the Notes was $851.0 million and $761.9 million at October 31, 2016 and July 31, 2016, respectively. The fair value was determined based on the closing trading price per $100 of the Notes as of the last day of trading for the period. We consider the fair value of the Notes at October 31, 2016 and July 31, 2016 to be a Level 2 measurement. The fair value of the Notes is primarily affected by the trading price of our common stock and market interest rates. As of October 31, 2016, the if-converted value of the Notes exceeded its principal amount by $223.6 million.

[0001327567-16-000073:notes:53]
The following table sets forth interest expense recognized related to the Notes (dollars in millions):

[0001327567-16-000073:notes:54]
|  | Three Months Ended October 31, |
|  | 2016 |  | 2015 |
| Amortization of debt discount | $ | 5.4 |  |  | $ | 5.2 |  |
| Amortization of debt issuance costs | 0.6 |  |  | 0.5 |  |
| Total interest expense recognized | $ | 6.0 |  |  | $ | 5.7 |  |
| Effective interest rate of the liability component | 4.8 | % |  | 4.8 | % |

[0001327567-16-000073:notes:55]
Note Hedges

[0001327567-16-000073:notes:56]
To minimize the impact of potential economic dilution upon conversion of the Notes, we entered into convertible note hedge transactions (the “Note Hedges”) with respect to our common stock concurrent with the issuance of the Notes. The Note Hedges cover up to 5.2 million shares of our common stock and are exercisable upon conversion of the Notes. The Note Hedges will expire upon maturity of the Notes. The Note Hedges are separate transactions and are not part of the terms of the Notes. Holders of the Notes will not have any rights with respect to the Note Hedges. The shares receivable related to the Note Hedges are excluded from the calculation of diluted earnings per share as they are antidilutive.

[0001327567-16-000073:notes:57]
Warrants

[0001327567-16-000073:notes:58]
Separately, but concurrently with our issuance of the Notes, we entered into transactions whereby we sold warrants (the “Warrants”) to acquire up to 5.2 million shares of our common stock at a strike price of approximately $137.85 per share, subject to adjustments. The shares issuable under the Warrants will be included in the calculation of diluted earnings per share when the average market value per share of our common stock for the reporting period exceeds the strike price of the Warrants. The Warrants are separate transactions and are not part of the Notes or Notes Hedges, and are not remeasured through earnings each reporting period. Holders of the Notes and Note Hedges will not have any rights with respect to the Warrants.

[0001327567-16-000073:notes:59]
For more information on the Notes, the Note Hedges, and the Warrants, refer to Note 7. Convertible Senior Notes of Notes to Consolidated Financial Statements included in Part II, Item 8 of our Annual Report on Form 10-K for the fiscal year ended July 31, 2016.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001327567-16-000073:notes:60]
4. Derivative Instruments

[0001327567-16-000073:notes:61]
As a global business, we are exposed to currency exchange rate risk. Substantially all of our revenue is transacted in U.S. dollars, however, a portion of our operating expenditures are incurred outside of the United States and are denominated in foreign currencies, making them subject to fluctuations in foreign currency exchange rates. We enter into foreign currency derivative contracts with maturities of 12 months or less which we designate as cash flow hedges to manage the foreign currency exchange rate risk associated with these expenditures.

[0001327567-16-000073:notes:62]
These derivative contracts expose us to credit risk to the extent that the counterparties may be unable to meet the terms of the arrangement. We mitigate this credit risk by transacting with major financial institutions with high credit ratings and also enter into master netting arrangements, which permit net settlement of transactions with the same counterparty. We are not required to pledge, and are not entitled to receive, cash collateral related to these derivative instruments. We do not enter into derivative contracts for trading or speculative purposes.

[0001327567-16-000073:notes:63]
Our derivative financial instruments are recorded at fair value, on a gross basis, as either assets or liabilities in our condensed consolidated balance sheets. Gains or losses related to the effective portion of our cash flow hedges are recorded as a component of accumulated other comprehensive income (“AOCI”) in our condensed consolidated balance sheets and are reclassified into the financial statement line item associated with the underlying hedged transaction in our condensed consolidated statements of operations when the underlying hedged transaction is recognized in earnings. Any gains or losses related to the ineffective portion of our cash flow hedges are recorded immediately in other income (expense), net in our condensed consolidated statements of operations. If it becomes probable that the hedged transaction will not occur, the cumulative unrealized gain or loss is reclassified immediately from AOCI into other income (expense), net. Gains or losses related to non-designated derivative instruments are recognized in other income (expense), net each period until the instrument matures, is terminated, is re-designated as a qualified cash flow hedge, or is sold. Derivatives designated as cash flow hedges are classified in our condensed consolidated statements of cash flows in the same manner as the underlying hedged transaction, primarily within cash flows from operating activities.

[0001327567-16-000073:notes:64]
In August 2016, we entered into forward contracts to hedge the foreign currency exchange rate risk arising from our euro-denominated expenditures to be incurred during the fiscal year ending July 31, 2017. These forward contracts were designated as cash flow hedges. As of October 31, 2016, the total notional amount of our outstanding foreign currency forward contracts was $63.8 million. Refer to Note 2. Fair Value Measurements for the total estimated fair value of our derivative instruments as of October 31, 2016.

[0001327567-16-000073:notes:65]
During the three months ended October 31, 2016, we accumulated unrealized losses of $1.1 million in AOCI related to the effective portion of our cash flow hedges, substantially all of which we expect to be reclassified into earnings within the next 12 months. The amounts reclassified into earnings related to our cash flow hedges were not significant for the three months ended October 31, 2016.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001327567-16-000073:notes:66]
[same as prior period, unchanged from 0001327567-16-000053:notes:48]

[0001327567-16-000073:notes:67]
[same as prior period, unchanged from 0001327567-16-000053:notes:49]

[0001327567-16-000073:notes:68]
[same as prior period, unchanged from 0001327567-16-000053:notes:50]

[0001327567-16-000073:notes:69]
|  | Options Outstanding |
|  | Number of Shares |  | Weighted- Average Exercise Price Per Share |  | Weighted- Average Remaining Contractual Term (Years) |  | Aggregate Intrinsic Value |
| Balance—July 31, 2016 | 2.1 |  |  | $ | 13.42 |  |  | 5.2 |  | $ | 244.9 |  |
| Options granted | — |  |  | — |  |  |  |  |  |
| Options forfeited | — |  |  | — |  |  |  |  |  |
| Options exercised | (0.3 | ) |  | 15.93 |  |  |  |  |  |
| Balance—October 31, 2016 | 1.8 |  |  | $ | 13.01 |  |  | 4.9 |  | $ | 253.1 |  |
| Options vested and expected to vest—October 31, 2016 | 1.8 |  |  | $ | 13.01 |  |  | 4.9 |  | $ | 253.1 |  |
| Options exercisable—October 31, 2016 | 1.8 |  |  | $ | 13.01 |  |  | 4.9 |  | $ | 253.1 |  |

[0001327567-16-000073:notes:70]
Restricted Stock Unit (“RSU”), Restricted Stock Award (“RSA”), and Performance-Based Stock Award (“PSA”) Activities

[0001327567-16-000073:notes:71]
During the three months ended October 31, 2016, we granted PSAs to our employees, which will vest over a period of four years from the date of grant. The actual number of PSAs earned and eligible to vest will be determined based on level of achievement against a pre-established billings target for the fiscal year ending July 31, 2017, with a maximum of 0.2 million shares issuable at the end of the performance period. Share-based compensation expense for our PSAs is recognized, net of estimated forfeitures, on a straight-line basis over the requisite service period for each separately vesting portion of the award when it is probable that the performance condition will be achieved.

[0001327567-16-000073:notes:72]
The following table summarizes the RSU, RSA, and PSA activity under our stock plans during the reporting period (in millions, except per share amounts):

[0001327567-16-000073:notes:73]
|  | RSAs and PSAs Outstanding |  | RSUs Outstanding |
|  | Number of Shares |  | Weighted- Average Grant-Date Fair Value Per Share |  | Number of Shares |  | Weighted- Average Grant-Date Fair Value Per Share |  | Weighted- Average Remaining Contractual Term (Years) |  | Aggregate Intrinsic Value |
| Balance—July 31, 2016 | 1.1 |  |  | $ | 170.97 |  |  | 6.5 |  |  | $ | 130.14 |  |  | 1.1 |  | $ | 852.7 |  |
| Granted(1) | 0.3 |  |  | 148.54 |  |  | 2.0 |  |  | 147.51 |  |  |  |  |  |
| Vested | — |  |  | — |  |  | (0.7 | ) |  | 98.49 |  |  |  |  |  |
| Forfeited | — |  |  | — |  |  | (0.1 | ) |  | 140.21 |  |  |  |  |  |
| Balance—October 31, 2016 | 1.4 |  |  | $ | 165.81 |  |  | 7.7 |  |  | $ | 137.59 |  |  | 1.3 |  | $ | 1,187.5 |  |
| Expected to vest—October 31, 2016 | 1.4 |  |  | $ | 166.55 |  |  | 7.3 |  |  | $ | 137.19 |  |  | 1.3 |  | $ | 1,119.0 |  |

[0001327567-16-000073:notes:74]
______________

[0001327567-16-000073:notes:75]
| (1) | The number of PSAs granted represents the aggregate maximum number of shares that may be earned and issued with respect to these awards over their full terms. |

[0001327567-16-000073:notes:76]
[same as prior period, unchanged from 0001327567-16-000053:notes:55]

[0001327567-16-000073:notes:77]
[same as prior period, unchanged from 0001327567-16-000053:notes:56]

[0001327567-16-000073:notes:78]
|  | Three Months Ended October 31, |
|  | 2016 |  | 2015 |
| Cost of product revenue | $ | 1.7 |  |  | $ | 1.3 |  |
| Cost of subscription and support revenue | 12.4 |  |  | 7.0 |  |
| Research and development | 38.4 |  |  | 25.0 |  |
| Sales and marketing | 44.0 |  |  | 27.2 |  |
| General and administrative | 17.7 |  |  | 12.4 |  |
| Total share-based compensation | $ | 114.2 |  |  | $ | 72.9 |  |

[0001327567-16-000073:notes:79]
At October 31, 2016, total compensation cost related to unvested share-based awards not yet recognized was $1.0 billion, net of estimated forfeitures. This cost is expected to be amortized on a straight-line basis over a weighted-average period of approximately 2.7 years.


## us-gaap:EarningsPerShareTextBlock

[0001327567-16-000073:notes:80]
[same as prior period, unchanged from 0001327567-16-000053:notes:59]

[0001327567-16-000073:notes:81]
[same as prior period, unchanged from 0001327567-16-000053:notes:60]

[0001327567-16-000073:notes:82]
[same as prior period, unchanged from 0001327567-16-000053:notes:61]

[0001327567-16-000073:notes:83]
|  | Three Months Ended |
|  | October 31, |
|  | 2016 |  | 2015 |
| Net loss | $ | (61.8 | ) |  | $ | (39.9 | ) |
| Weighted-average shares used to compute net loss per share, basic and diluted | 89.8 |  |  | 85.1 |  |
| Net loss per share, basic and diluted | $ | (0.69 | ) |  | $ | (0.47 | ) |

[0001327567-16-000073:notes:84]
[same as prior period, unchanged from 0001327567-16-000053:notes:63]

[0001327567-16-000073:notes:85]
|  | Three Months Ended |
|  | October 31, |
|  | 2016 |  | 2015 |
| RSUs | 7.7 |  |  | 6.8 |  |
| Convertible senior notes | 5.2 |  |  | 5.2 |  |
| Warrants related to the issuance of convertible senior notes | 5.2 |  |  | 5.2 |  |
| Options to purchase common stock | 1.8 |  |  | 2.9 |  |
| RSAs and PSAs | 1.4 |  |  | — |  |
| Total | 21.3 |  |  | 20.1 |  |


## us-gaap:FairValueAssetsAndLiabilitiesMeasuredOnRecurringAndNonrecurringBasisTableTextBlock

[0001327567-16-000073:notes:86]
The following table presents the fair value of our financial assets and liabilities using the above input categories as of October 31, 2016 and July 31, 2016 (in millions):

[0001327567-16-000073:notes:87]
|  |  | October 31, 2016 |  | July 31, 2016 |
|  |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Short-term investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Commercial paper |  | $ | — |  |  | $ | 17.9 |  |  | $ | — |  |  | $ | 17.9 |  |  | $ | — |  |  | $ | 3.0 |  |  | $ | — |  |  | $ | 3.0 |  |
| Corporate debt securities |  | — |  |  | 110.3 |  |  | — |  |  | 110.3 |  |  | — |  |  | 121.4 |  |  | — |  |  | 121.4 |  |
| U.S. government and agency securities |  | — |  |  | 422.4 |  |  | — |  |  | 422.4 |  |  | — |  |  | 426.8 |  |  | — |  |  | 426.8 |  |
| Total short-term investments |  | — |  |  | 550.6 |  |  | — |  |  | 550.6 |  |  | — |  |  | 551.2 |  |  | — |  |  | 551.2 |  |
| Long-term investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Certificates of deposit |  | — |  |  | 5.4 |  |  | — |  |  | 5.4 |  |  | — |  |  | 5.4 |  |  | — |  |  | 5.4 |  |
| Corporate debt securities |  | — |  |  | 188.7 |  |  | — |  |  | 188.7 |  |  | — |  |  | 166.1 |  |  | — |  |  | 166.1 |  |
| U.S. government and agency securities |  | — |  |  | 514.3 |  |  | — |  |  | 514.3 |  |  | — |  |  | 481.3 |  |  | — |  |  | 481.3 |  |
| Total long-term investments |  | — |  |  | 708.4 |  |  | — |  |  | 708.4 |  |  | — |  |  | 652.8 |  |  | — |  |  | 652.8 |  |
| Total assets measured at fair value |  | $ | — |  |  | $ | 1,259.0 |  |  | $ | — |  |  | $ | 1,259.0 |  |  | $ | — |  |  | $ | 1,204.0 |  |  | $ | — |  |  | $ | 1,204.0 |  |
| Accrued and other liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency forward contracts |  | $ | — |  |  | $ | 1.2 |  |  | $ | — |  |  | $ | 1.2 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Total accrued and other liabilities |  | — |  |  | 1.2 |  |  | — |  |  | 1.2 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Total liabilities measured at fair value |  | $ | — |  |  | $ | 1.2 |  |  | $ | — |  |  | $ | 1.2 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001327567-16-000073:notes:88]
[same as prior period, unchanged from 0001327567-16-000053:notes:67]

[0001327567-16-000073:notes:89]
[same as prior period, unchanged from 0001327567-16-000053:notes:68]

[0001327567-16-000073:notes:90]
[same as prior period, unchanged from 0001327567-16-000053:notes:69]

[0001327567-16-000073:notes:91]
[same as prior period, unchanged from 0001327567-16-000053:notes:70]

[0001327567-16-000073:notes:92]
[same as prior period, unchanged from 0001327567-16-000053:notes:71]

[0001327567-16-000073:notes:93]
Refer to Note 5. Convertible Senior Notes for the carrying amount and estimated fair value of our convertible senior notes as of October 31, 2016 and July 31, 2016.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001327567-16-000073:notes:94]
[same as prior period, unchanged from 0001327567-16-000053:notes:73]

[0001327567-16-000073:notes:95]
Our provision for income taxes for the three months ended October 31, 2016 reflects an effective tax rate of (15.7)%. Our effective tax rate for this period was negative as we recorded a provision for income taxes on year to date losses. The key components of our income tax provision primarily consist of foreign income taxes, withholding taxes, U.S. federal and state income taxes, and amortization of our deferred tax charges. Our effective tax rate differs from the U.S. statutory tax rate primarily due to non-deductible share-based compensation and changes in our valuation allowance. As compared to the same period last year, our effective tax rate changed primarily due to an increase in non-deductible share-based compensation and changes in our valuation allowance against deferred tax assets.

[0001327567-16-000073:notes:96]
Our provision for income taxes for the three months ended October 31, 2015 reflects an effective tax rate of (12.1)%. Our effective tax rate for this period was negative as we recorded a provision for income taxes on year to date losses. The key components of our income tax provision primarily consisted of foreign income taxes, withholding taxes, U.S. federal and state income taxes, and amortization of our deferred tax charges. Key components of our effective tax rate consisted of foreign tax losses which derive no benefit, non-deductible share-based compensation, and changes in our valuation allowance.


## us-gaap:InvestmentsClassifiedByContractualMaturityDateTableTextBlock

[0001327567-16-000073:notes:97]
The following table summarizes the amortized cost and fair value of our available-for-sale investments as of October 31, 2016, by contractual years-to-maturity (in millions):

[0001327567-16-000073:notes:98]
|  | Amortized Cost |  | Fair Value |
| Due within one year | $ | 550.5 |  |  | $ | 550.6 |  |
| Due between one and three years | 708.7 |  |  | 708.4 |  |
| Total | $ | 1,259.2 |  |  | $ | 1,259.0 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001327567-16-000073:notes:99]
Investments

[0001327567-16-000073:notes:100]
Unrealized losses related to these investments are due to interest rate fluctuations as opposed to credit quality. In addition, we do not intend to sell and it is not likely that we would be required to sell these investments before recovery of their amortized cost basis, which may be at maturity. As a result, there were no other-than-temporary impairments for these investments at October 31, 2016 and July 31, 2016.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001327567-16-000073:notes:101]
Stockholders’ Equity

[0001327567-16-000073:notes:102]
Share Repurchase

[0001327567-16-000073:notes:103]
On August 26, 2016, our board of directors authorized a $500.0 million share repurchase which will be funded from available working capital. Repurchases may be made at management’s discretion from time to time on the open market, through privately negotiated transactions, transactions structured through investment banking institutions, block purchase techniques, 10b5-1 trading plans, or a combination of the foregoing. The repurchase authorization will expire on August 31, 2018, and may be suspended or discontinued at any time. During the three months ended October 31, 2016, we repurchased and retired 0.3 million shares of our common stock under the authorization for an aggregate purchase price of $50.0 million. The total price of the shares repurchased and related transaction costs are reflected as a reduction to common stock and additional paid-in capital on our condensed consolidated balance sheets. As of October 31, 2016, $450.0 million remained available for future share repurchases under the repurchase authorization.
