# PANW note change history — 0001327567-16-000053 → 0001327567-16-000073


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2016-11-22):
[0001327567-16-000073:note_history:1]
The following table presents details of the aggregate future non-cancelable minimum rental payments under our operating leases as of October 31, 2016 (in millions):
  (was, 2016-05-27, similarity 0.9684):
[0001327567-16-000053:note_history:1]
The following table presents details of the aggregate future non-cancelable minimum rental payments under our operating leases as of April 30, 2016 (in millions):

- changed (2016-11-22):
[0001327567-16-000073:note_history:2]
Our independent contract manufacturer procures components and assembles our products based on our forecasts. These forecasts are based on estimates of demand for our products primarily for the next 12 months, which are in turn based on historical trends and an analysis from our sales and product marketing organizations, adjusted for overall market conditions. In order to reduce manufacturing lead times and plan for adequate supply, we may issue forecasts and orders for components and products that are non-cancelable. As of October 31, 2016, our purchase commitments under such orders were $63.9 million, excluding obligations under contracts that we can cancel without a significant penalty.
  (was, 2016-05-27, similarity 0.9913):
[0001327567-16-000053:note_history:2]
Our independent contract manufacturer procures components and assembles our products based on our forecasts. These forecasts are based on estimates of demand for our products primarily for the next 12 months, which are in turn based on historical trends and an analysis from our sales and product marketing organizations, adjusted for overall market conditions. In order to reduce manufacturing lead times and plan for adequate supply, we may issue forecasts and orders for components and products that are non-cancelable. As of April 30, 2016, our purchase commitments under such orders were $54.5 million, excluding obligations under contracts that we can cancel without a significant penalty.

- changed (2016-11-22):
[0001327567-16-000073:note_history:3]
To the extent there is a reasonable possibility that a loss exceeding amounts already recognized may be incurred and the amount of such additional loss would be material, we will either disclose the estimated additional loss or state that such an estimate cannot be made. As of October 31, 2016, we have not recorded any significant accruals for loss contingencies associated with such legal proceedings, determined that an unfavorable outcome is probable or reasonably possible, or determined that the amount or range of any possible loss is reasonably estimable.
  (was, 2016-05-27, similarity 0.9892):
[0001327567-16-000053:note_history:3]
To the extent there is a reasonable possibility that a loss exceeding amounts already recognized may be incurred and the amount of such additional loss would be material, we will either disclose the estimated additional loss or state that such an estimate cannot be made. As of April 30, 2016, we have not recorded any significant accruals for loss contingencies associated with such legal proceedings, determined that an unfavorable outcome is probable or reasonably possible, or determined that the amount or range of any possible loss is reasonably estimable.

- removed (2016-11-22):
[0001327567-16-000053:note_history:4]
In May 2015, we entered into three lease agreements for approximately 752,000 square feet of corporate office space in Santa Clara, California to serve as our future corporate headquarters. In October 2015, we entered into a fourth lease agreement for approximately 310,000 square feet of additional office space at the same location. The fourth lease will commence in December 2017 and expire in April 2028, however, the site is currently under construction and as a result, the lease commencement date may change based on progress of the construction project. The fourth lease agreement contains a rent holiday period, scheduled rent increases, lease incentives, and renewal options which allow the lease term to be extended through April 2046. Rental payments under the fourth lease agreement are approximately $101.2 million over the initial lease term. For more information on the three lease agreements entered into in May 2015, refer to Note 8. Commitments and Contingencies of Notes to Consolidated Financial Statements included in Part II, Item 8 of our Annual Report on Form 10-K for the fiscal year ended July 31, 2015.


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2016-11-22):
[0001327567-16-000073:note_history:5]
Palo Alto Networks, Inc. (the “Company,” “we,” “us,” or “our”), located in Santa Clara, California, was incorporated in March 2005 under the laws of the State of Delaware and commenced operations in April 2005. We offer a next-generation security platform that empowers enterprises, service providers, and government entities to secure their organizations by safely enabling applications running on their networks and by preventing breaches that stem from targeted cyber attacks.
  (was, 2016-05-27, similarity 0.9328):
[0001327567-16-000053:note_history:5]
Palo Alto Networks, Inc. (the “Company,” “we,” “us,” or “our”), located in Santa Clara, California, was incorporated in March 2005 under the laws of the State of Delaware and commenced operations in April 2005. We offer a next-generation security platform that empowers enterprises, service providers, and government entities to secure their organizations by safely enabling the increasingly complex and rapidly growing number of applications running on their networks and by preventing breaches in real-time that stem from targeted cyber attacks.

- changed (2016-11-22):
[0001327567-16-000073:note_history:6]
Our condensed consolidated financial statements are unaudited, but include all adjustments of a normal recurring nature necessary for a fair presentation of our quarterly results. We have made estimates and judgments affecting the amounts reported in our condensed consolidated financial statements and the accompanying notes. The actual results that we experience may differ materially from our estimates. Certain prior period amounts have been adjusted as a result of our voluntary change in accounting policy for sales commissions and our adoption of new accounting guidance related to debt issuance costs. Refer to “Summary of Significant Accounting Policies” and “Recent Accounting Pronouncements” below for more information.
  (was, 2016-05-27, similarity 0.7262):
[0001327567-16-000053:note_history:6]
Our condensed consolidated financial statements are unaudited, but include all adjustments of a normal recurring nature necessary for a fair presentation of our quarterly results. We have made estimates and judgments affecting the amounts reported in our condensed consolidated financial statements and the accompanying notes. The actual results that we experience may differ materially from our estimates. Certain prior period amounts have been reclassified to conform to current period presentation.

- changed (2016-11-22):
[0001327567-16-000073:note_history:7]
There have been no material changes to our significant accounting policies as of and for the three months ended October 31, 2016, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended July 31, 2016, except for our voluntary change in accounting policy related to sales commissions discussed below.
  (was, 2016-05-27, similarity 0.7533):
[0001327567-16-000053:note_history:7]
There have been no material changes to our significant accounting policies as of and for the nine months ended April 30, 2016, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended July 31, 2015.

- added (2016-11-22):
[0001327567-16-000073:note_history:8]
Change in Accounting Policy for Sales Commissions

- added (2016-11-22):
[0001327567-16-000073:note_history:9]
Effective August 1, 2016, we voluntarily changed our accounting policy for sales commissions that are incremental and directly related to non-cancelable customer sales contracts from recording an expense when incurred to deferral and amortization of the sales commissions over the term of the related contract in proportion to the recognized revenue. We believe this change in accounting policy is preferable as the direct and incremental commission costs are closely related to the associated revenue, and therefore should be deferred and recognized as an expense over the same period that the related revenue is recognized.

- added (2016-11-22):
[0001327567-16-000073:note_history:10]
Short-term deferred commissions are included in prepaid expenses and other current assets, while long-term deferred commissions are included in other assets in our condensed consolidated balance sheets. The amortization of deferred commissions is included in sales and marketing expense in our condensed consolidated statements of operations.

- added (2016-11-22):
[0001327567-16-000073:note_history:11]
The adoption of this accounting policy change has been applied retrospectively to all prior periods presented in this Quarterly Report on Form 10-Q, in which the cumulative effect of the change of $71.8 million has been reflected in accumulated deficit as of August 1, 2015, the beginning of the earliest period presented.

- added (2016-11-22):
[0001327567-16-000073:note_history:12]
The following tables present the changes to financial statement line items as a result of the accounting change for the periods presented in our condensed consolidated financial statements (in millions, except per share data):

- added (2016-11-22):
[0001327567-16-000073:note_history:13]
|  | October 31, 2016 |  | July 31, 2016 |
|  | Computed under Prior Method |  | Impact of Commission Adjustment |  | As Reported |  | As Previously Reported |  | Impact of Commission Adjustment |  | As Adjusted |
| Condensed Consolidated Balance Sheets |  |  |  |  |  |  |  |  |  |  |  |
| Prepaid expenses and other current assets | $ | 75.4 |  |  | $ | 54.0 |  |  | $ | 129.4 |  |  | $ | 84.8 |  |  | $ | 54.9 |  |  | $ | 139.7 |  |
| Other assets | 53.6 |  |  | 48.4 |  |  | 102.0 |  |  | 64.6 |  |  | 50.1 |  |  | 114.7 |  |
| Other long-term liabilities | 85.0 |  |  | 0.8 |  |  | 85.8 |  |  | 79.4 |  |  | — |  |  | 79.4 |  |
| Accumulated deficit | $ | (785.0 | ) |  | $ | 101.6 |  |  | $ | (683.4 | ) |  | $ | (726.6 | ) |  | $ | 105.0 |  |  | $ | (621.6 | ) |

- added (2016-11-22):
[0001327567-16-000073:note_history:14]
|  | Three Months Ended October 31, 2016 |  | Three Months Ended October 31, 2015 |
|  | Computed under Prior Method |  | Impact of Commission Adjustment |  | As Reported |  | As Previously Reported |  | Impact of Commission Adjustment |  | As Adjusted |
| Condensed Consolidated Statements of Operations |  |  |  |  |  |  |  |  |  |  |  |
| Sales and marketing | $ | 217.7 |  |  | $ | 2.6 |  |  | $ | 220.3 |  |  | $ | 158.3 |  |  | $ | 1.2 |  |  | $ | 159.5 |  |
| Operating loss | (47.3 | ) |  | (2.6 | ) |  | (49.9 | ) |  | (30.8 | ) |  | (1.2 | ) |  | (32.0 | ) |
| Provision for income taxes | 7.6 |  |  | 0.8 |  |  | 8.4 |  |  | 4.3 |  |  | — |  |  | 4.3 |  |
| Net loss | $ | (58.4 | ) |  | $ | (3.4 | ) |  | $ | (61.8 | ) |  | $ | (38.7 | ) |  | $ | (1.2 | ) |  | $ | (39.9 | ) |
| Net loss per share, basic and diluted | $ | (0.65 | ) |  | $ | (0.04 | ) |  | $ | (0.69 | ) |  | $ | (0.45 | ) |  | $ | (0.02 | ) |  | $ | (0.47 | ) |
| Weighted-average shares used to compute net loss per share, basic and diluted | 89.8 |  |  | — |  |  | 89.8 |  |  | 85.1 |  |  | — |  |  | 85.1 |  |
| Condensed Consolidated Statements of Comprehensive Loss |  |  |  |  |  |  |  |  |  |  |  |
| Net loss | $ | (58.4 | ) |  | $ | (3.4 | ) |  | $ | (61.8 | ) |  | $ | (38.7 | ) |  | $ | (1.2 | ) |  | $ | (39.9 | ) |
| Comprehensive loss | $ | (61.3 | ) |  | $ | (3.4 | ) |  | $ | (64.7 | ) |  | $ | (39.0 | ) |  | $ | (1.2 | ) |  | $ | (40.2 | ) |

- added (2016-11-22):
[0001327567-16-000073:note_history:15]
This change in accounting policy does not affect our balance of cash and cash equivalents and, as a result, did not change net cash flows from operating, investing, or financing activities, or materially impact any individual line items presented in our condensed consolidated statement of cash flows for the three months ended October 31, 2015.

- added (2016-11-22):
[0001327567-16-000073:note_history:16]
Recently Adopted Accounting Pronouncements

- added (2016-11-22):
[0001327567-16-000073:note_history:17]
In April 2015, the Financial Accounting Standards Board (“FASB”) issued new authoritative guidance on fees paid in a cloud computing arrangement. The standard requires customers in a cloud computing arrangement to evaluate whether the arrangement includes a software license. If the arrangement includes a software license, the customer should account for the software license element of the arrangement consistent with the acquisition of other software licenses. If the arrangement does not include a software license, the customer should account for the arrangement as a service contract. We adopted the guidance in our first quarter of fiscal 2017 on a prospective basis. Our adoption of this guidance did not have a material impact on our condensed consolidated financial statements.

- changed (2016-11-22):
[0001327567-16-000073:note_history:18]
In April 2015, the FASB issued updated authoritative guidance to simplify the presentation of debt issuance costs. The amended standard requires that debt issuance costs related to a recognized debt liability be presented in the balance sheet as a direct deduction from the carrying amount of the related debt liability, consistent with the presentation of debt discounts, instead of being presented as an asset. We adopted the guidance in our first quarter of fiscal 2017 on a retrospective basis, and as a result, we reduced other assets and convertible senior notes, net by $8.0 million on our condensed consolidated balance sheets as of July 31, 2016.
  (was, 2016-05-27, similarity 0.6811):
[0001327567-16-000053:note_history:18]
In April 2015, the FASB issued updated authoritative guidance to simplify the presentation of debt issuance costs. The amended standard requires that debt issuance costs related to a recognized debt liability be presented in the balance sheet as a direct deduction from the carrying amount of the related debt liability, consistent with the presentation of debt discounts, instead of being presented as an asset. The amended standard is effective for us for our first quarter of fiscal 2017 and will be applied on a retrospective basis. We do not expect the adoption of the standard will have a material impact on our condensed consolidated financial statements.

- added (2016-11-22):
[0001327567-16-000073:note_history:19]
Recently Issued Accounting Pronouncements

- added (2016-11-22):
[0001327567-16-000073:note_history:20]
In October 2016, the FASB issued authoritative guidance requiring the recognition of income tax consequences of an intra-entity transfer of an asset, other than inventory, when the transfer occurs. The standard is effective for us for our first quarter of fiscal 2019 and will be applied on a modified retrospective basis. Early adoption is permitted. We are currently evaluating whether this standard will have a material impact on our condensed consolidated financial statements.

- added (2016-11-22):
[0001327567-16-000073:note_history:21]
In August 2016, the FASB issued new authoritative guidance addressing eight specific cash flow issues with the objective of reducing the existing diversity in practice in how certain transactions are presented and classified in the statement of cash flows. The standard is effective for us for our first quarter of fiscal 2019 and will be applied on a retrospective basis. Early adoption is permitted. We are currently evaluating whether this standard will have a material impact on our condensed consolidated financial statements.

- added (2016-11-22):
[0001327567-16-000073:note_history:22]
In June 2016, the FASB issued new authoritative guidance on the accounting for credit losses on most financial assets and certain financial instruments. The standard replaces the existing incurred loss model with an expected credit loss model for financial assets measured at amortized cost, including trade receivables, and requires that credit losses on available-for-sale debt securities be presented as an allowance rather than as a write-down. The standard is effective for us for our first quarter of fiscal 2021 and will be applied on a modified retrospective basis. Early adoption is permitted beginning our first quarter of fiscal 2020. We are currently evaluating whether this standard will have a material impact on our condensed consolidated financial statements.

- changed (2016-11-22):
[0001327567-16-000073:note_history:23]
In March 2016, the FASB issued authoritative guidance simplifying several aspects of the accounting for employee share-based payment transactions, including the income tax consequences, accounting for forfeitures, and classification of excess tax benefits on the statement of cash flows. The standard is effective for us for our first quarter of fiscal 2018, however, early adoption is permitted. We are currently evaluating whether this standard will have a material impact on our condensed consolidated financial statements.
  (was, 2016-05-27, similarity 0.9582):
[0001327567-16-000053:note_history:23]
In March 2016, the Financial Accounting Standards Board (“FASB”) issued authoritative guidance simplifying several aspects of the accounting for employee share-based payment transactions, including the income tax consequences, accounting for forfeitures, and classification of excess tax benefits on the statement of cash flows. The standard is effective for us for our first quarter of fiscal 2018, however, early adoption is permitted. We are currently evaluating whether this standard will have a material impact on our condensed consolidated financial statements.

- removed (2016-11-22):
[0001327567-16-000053:note_history:24]
In April 2015, the FASB issued new authoritative guidance on fees paid in a cloud computing arrangement. The standard requires customers in a cloud computing arrangement to evaluate whether the arrangement includes a software license. If the arrangement includes a software license, the customer should account for the software license element of the arrangement consistent with the acquisition of other software licenses. If the arrangement does not include a software license, the customer should account for the arrangement as a service contract. The standard is effective for us for our first quarter of fiscal 2017 and will be applied on a prospective basis. We do not expect the adoption of the standard will have a material impact on our condensed consolidated financial statements.


## us-gaap:ConvertibleDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2016-11-22):
[0001327567-16-000073:note_history:25]
The following table sets forth the components of the Notes as of October 31, 2016 and July 31, 2016 (in millions):
  (was, 2016-05-27, similarity 0.9515):
[0001327567-16-000053:note_history:25]
The following table sets forth the components of the Notes as of April 30, 2016 and July 31, 2015 (in millions):

- added (2016-11-22):
[0001327567-16-000073:note_history:26]
|  | October 31, 2016 |  | July 31, 2016 |
| Liability: |  |  |  |
| Principal | $ | 575.0 |  |  | $ | 575.0 |  |
| Less: debt discount and debt issuance costs, net of amortization | 68.8 |  |  | 74.8 |  |
| Net carrying amount | $ | 506.2 |  |  | $ | 500.2 |  |
| Equity (including temporary equity) | $ | 109.8 |  |  | $ | 109.8 |  |

- removed (2016-11-22):
[0001327567-16-000053:note_history:27]
|  | April 30, 2016 |  | July 31, 2015 |
| Liability: |  |  |  |
| Principal | $ | 575.0 |  |  | $ | 575.0 |  |
| Less: debt discount, net of amortization | 72.2 |  |  | 87.9 |  |
| Net carrying amount | $ | 502.8 |  |  | $ | 487.1 |  |
| Equity (including temporary equity) | $ | (109.8 | ) |  | $ | (109.8 | ) |


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2016-11-22):
[0001327567-16-000073:note_history:28]
The sale price condition was not met during the fiscal quarter ended July 31, 2016. Since the Notes were not convertible, the net carrying amount of the Notes and related debt issuance costs were classified as long-term liabilities and the equity component was included in additional paid-in capital in our condensed consolidated balance sheets as of July 31, 2016. The sale price condition was met during the fiscal quarter ended October 31, 2016, and as a result, holders may convert their Notes at any time during the fiscal quarter ending January 31, 2017. Accordingly, the net carrying amount of the Notes and related debt issuance costs were reclassified into current liabilities and the portion of the equity component representing the conversion option was reclassified into temporary equity in our condensed consolidated balance sheets as of October 31, 2016. The portion of the equity component classified as temporary equity is measured as the difference between the principal and net carrying amount of the Notes, excluding debt issuance costs.

- changed (2016-11-22):
[0001327567-16-000073:note_history:29]
The following table sets forth the components of the Notes as of October 31, 2016 and July 31, 2016 (in millions):
  (was, 2016-05-27, similarity 0.9515):
[0001327567-16-000053:note_history:29]
The following table sets forth the components of the Notes as of April 30, 2016 and July 31, 2015 (in millions):

- added (2016-11-22):
[0001327567-16-000073:note_history:30]
|  | October 31, 2016 |  | July 31, 2016 |
| Liability: |  |  |  |
| Principal | $ | 575.0 |  |  | $ | 575.0 |  |
| Less: debt discount and debt issuance costs, net of amortization | 68.8 |  |  | 74.8 |  |
| Net carrying amount | $ | 506.2 |  |  | $ | 500.2 |  |
| Equity (including temporary equity) | $ | 109.8 |  |  | $ | 109.8 |  |

- added (2016-11-22):
[0001327567-16-000073:note_history:31]
The total estimated fair value of the Notes was $851.0 million and $761.9 million at October 31, 2016 and July 31, 2016, respectively. The fair value was determined based on the closing trading price per $100 of the Notes as of the last day of trading for the period. We consider the fair value of the Notes at October 31, 2016 and July 31, 2016 to be a Level 2 measurement. The fair value of the Notes is primarily affected by the trading price of our common stock and market interest rates. As of October 31, 2016, the if-converted value of the Notes exceeded its principal amount by $223.6 million.

- added (2016-11-22):
[0001327567-16-000073:note_history:32]
|  | Three Months Ended October 31, |
|  | 2016 |  | 2015 |
| Amortization of debt discount | $ | 5.4 |  |  | $ | 5.2 |  |
| Amortization of debt issuance costs | 0.6 |  |  | 0.5 |  |
| Total interest expense recognized | $ | 6.0 |  |  | $ | 5.7 |  |
| Effective interest rate of the liability component | 4.8 | % |  | 4.8 | % |

- removed (2016-11-22):
[0001327567-16-000053:note_history:33]
The sale price condition was initially met during the fiscal quarter ended April 30, 2015. The sale price condition continued to be met through the fiscal quarter ended April 30, 2016, and as a result, holders may convert their Notes at any time during the fiscal quarter ending July 31, 2016. Accordingly, the net carrying amount of the Notes was classified in current liabilities and a portion of the equity component representing the conversion option was classified as temporary equity in our condensed consolidated balance sheets as of April 30, 2016. The portion of the equity component classified as temporary equity is measured as the difference between the principal and net carrying amount of the Notes.

- removed (2016-11-22):
[0001327567-16-000053:note_history:34]
|  | April 30, 2016 |  | July 31, 2015 |
| Liability: |  |  |  |
| Principal | $ | 575.0 |  |  | $ | 575.0 |  |
| Less: debt discount, net of amortization | 72.2 |  |  | 87.9 |  |
| Net carrying amount | $ | 502.8 |  |  | $ | 487.1 |  |
| Equity (including temporary equity) | $ | (109.8 | ) |  | $ | (109.8 | ) |

- removed (2016-11-22):
[0001327567-16-000053:note_history:35]
The total estimated fair value of the Notes was $844.4 million and $994.8 million at April 30, 2016 and July 31, 2015, respectively. The fair value was determined based on the closing trading price per $100 of the Notes as of the last day of trading for the period. We consider the fair value of the Notes at April 30, 2016 and July 31, 2015 to be a Level 2 measurement. The fair value of the Notes is primarily affected by the trading price of our common stock and market interest rates. As of April 30, 2016, the if-converted value of the Notes exceeded its principal amount by $210.9 million.

- removed (2016-11-22):
[0001327567-16-000053:note_history:36]
|  | Three Months Ended April 30, |  | Nine Months Ended April 30, |
|  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Amortization of debt discount | $ | 5.3 |  |  | $ | 5.1 |  |  | $ | 15.7 |  |  | $ | 15.1 |  |
| Amortization of debt issuance costs | 0.6 |  |  | 0.5 |  |  | 1.7 |  |  | 1.5 |  |
| Total interest expense recognized | $ | 5.9 |  |  | $ | 5.6 |  |  | $ | 17.4 |  |  | $ | 16.6 |  |
| Effective interest rate of the liability component | 4.8 | % |  | 4.8 | % |  | 4.8 | % |  | 4.8 | % |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2016-11-22):
[0001327567-16-000073:note_history:37]
The following tables summarize the amortized cost, unrealized gains and losses, and fair value of our available-for-sale investments as of October 31, 2016 and July 31, 2016 (in millions):
  (was, 2016-05-27, similarity 0.9718):
[0001327567-16-000053:note_history:37]
The following tables summarize the amortized cost, unrealized gains and losses, and fair value of our available-for-sale investments as of April 30, 2016 and July 31, 2015 (in millions):

- added (2016-11-22):
[0001327567-16-000073:note_history:38]
|  | October 31, 2016 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Estimated Fair Value |
| Certificates of deposit | $ | 5.4 |  |  | $ | — |  |  | $ | — |  |  | $ | 5.4 |  |
| Commercial paper | 17.9 |  |  | — |  |  | — |  |  | 17.9 |  |
| Corporate debt securities | 298.9 |  |  | 0.4 |  |  | (0.3 | ) |  | 299.0 |  |
| U.S. government and agency securities | 937.0 |  |  | 0.3 |  |  | (0.6 | ) |  | 936.7 |  |
| Total | $ | 1,259.2 |  |  | $ | 0.7 |  |  | $ | (0.9 | ) |  | $ | 1,259.0 |  |

- changed (2016-11-22):
[0001327567-16-000073:note_history:39]
|  | July 31, 2016 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Estimated Fair Value |
| Certificates of deposit | $ | 5.4 |  |  | $ | — |  |  | $ | — |  |  | $ | 5.4 |  |
| Commercial paper | 3.0 |  |  | — |  |  | — |  |  | 3.0 |  |
| Corporate debt securities | 286.7 |  |  | 0.8 |  |  | — |  |  | 287.5 |  |
| U.S. government and agency securities | 907.3 |  |  | 0.9 |  |  | (0.1 | ) |  | 908.1 |  |
| Total | $ | 1,202.4 |  |  | $ | 1.7 |  |  | $ | (0.1 | ) |  | $ | 1,204.0 |  |
  (was, 2016-05-27, similarity 0.7362):
[0001327567-16-000053:note_history:39]
|  | July 31, 2015 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Estimated Fair Value |
| Certificates of deposit | $ | 1.0 |  |  | $ | — |  |  | $ | — |  |  | $ | 1.0 |  |
| Corporate debt securities | 190.9 |  |  | — |  |  | (0.2 | ) |  | 190.7 |  |
| U.S. government and agency securities | 760.2 |  |  | 0.3 |  |  | (0.2 | ) |  | 760.3 |  |
| Total | $ | 952.1 |  |  | $ | 0.3 |  |  | $ | (0.4 | ) |  | $ | 952.0 |  |

- changed (2016-11-22):
[0001327567-16-000073:note_history:40]
Unrealized losses related to these investments are due to interest rate fluctuations as opposed to credit quality. In addition, we do not intend to sell and it is not likely that we would be required to sell these investments before recovery of their amortized cost basis, which may be at maturity. As a result, there were no other-than-temporary impairments for these investments at October 31, 2016 and July 31, 2016.
  (was, 2016-05-27, similarity 0.9853):
[0001327567-16-000053:note_history:40]
Unrealized losses related to these investments are due to interest rate fluctuations as opposed to credit quality. In addition, we do not intend to sell and it is not likely that we would be required to sell these investments before recovery of their amortized cost basis, which may be at maturity. As a result, there were no other-than-temporary impairments for these investments at April 30, 2016 and July 31, 2015.

- changed (2016-11-22):
[0001327567-16-000073:note_history:41]
The following table summarizes the amortized cost and fair value of our available-for-sale investments as of October 31, 2016, by contractual years-to-maturity (in millions):
  (was, 2016-05-27, similarity 0.9701):
[0001327567-16-000053:note_history:41]
The following table summarizes the amortized cost and fair value of our available-for-sale investments as of April 30, 2016, by contractual years-to-maturity (in millions):

- removed (2016-11-22):
[0001327567-16-000053:note_history:42]
|  | April 30, 2016 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Estimated Fair Value |
| Certificates of deposit | $ | 5.4 |  |  | $ | — |  |  | $ | — |  |  | $ | 5.4 |  |
| Corporate debt securities | 299.8 |  |  | 0.5 |  |  | — |  |  | 300.3 |  |
| U.S. government and agency securities | 914.4 |  |  | 0.5 |  |  | (0.2 | ) |  | 914.7 |  |
| Total | $ | 1,219.6 |  |  | $ | 1.0 |  |  | $ | (0.2 | ) |  | $ | 1,220.4 |  |
