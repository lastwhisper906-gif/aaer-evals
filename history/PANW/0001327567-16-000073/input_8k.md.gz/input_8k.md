# PANW 8-K — 0001327567-16-000071 filed 2016-11-21

## item codes, every 8-K on or before 2016-11-22

- 2016-11-21 0001327567-16-000071 — 2.02, 9.01
- 2016-10-24 0001193125-16-745121 — 5.02, 9.01
- 2016-08-30 0001327567-16-000057 — 2.02, 5.03, 8.01, 9.01
- 2016-08-22 0001193125-16-687588 — 5.02, 9.01
- 2016-05-26 0001327567-16-000051 — 2.02, 9.01
- 2016-02-25 0001327567-16-000044 — 2.02, 5.02, 9.01
- 2015-12-14 0001327567-15-000038 — 5.07
- 2015-12-14 0001193125-15-402588 — 1.01, 9.01
- 2015-11-23 0001327567-15-000033 — 2.02, 9.01
- 2015-10-19 0001193125-15-347005 — 1.01, 9.01 — amendment, the index does not say of what
- 2015-09-09 0001327567-15-000022 — 2.02, 9.01
- 2015-08-19 0001193125-15-296115 — 1.01, 2.03
- 2015-06-01 0001193125-15-207786 — 1.01, 2.03
- 2015-05-27 0001327567-15-000015 — 2.02, 9.01
- 2015-03-02 0001327567-15-000006 — 2.02, 9.01
- 2014-12-15 0001327567-14-000046 — 5.07
- 2014-11-24 0001327567-14-000040 — 2.02, 9.01
- 2014-09-22 0001193125-14-348581 — 5.02, 9.01
- 2014-09-09 0001327567-14-000025 — 2.02, 9.01
- 2014-07-01 0001193125-14-257824 — 1.01, 2.03, 3.02, 9.01
- 2014-06-26 0001193125-14-249529 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2014-06-20 0001327567-14-000020 — 9.01 — amendment of 0001193125-14-140511
- 2014-06-04 0001327567-14-000016 — 3.02
- 2014-05-30 0001193125-14-218158 — 2.02 — amendment, the index does not say of what
- 2014-05-28 0001193125-14-215060 — 1.01, 2.02, 3.02, 9.01
- 2014-04-11 0001193125-14-140511 — 2.01, 3.02, 7.01, 9.01
- 2014-03-24 0001193125-14-111318 — 1.01, 3.02, 7.01, 9.01
- 2014-03-13 0001327567-14-000009 — 5.02
- 2014-02-24 0001193125-14-063754 — 2.02, 9.01
- 2013-12-12 0001327567-13-000040 — 5.07
- 2013-11-25 0001327567-13-000033 — 2.02, 9.01
- 2013-09-30 0001193125-13-384966 — 8.01
- 2013-09-09 0001193125-13-361421 — 2.02, 9.01
- 2013-05-30 0001193125-13-241542 — 2.02, 5.02, 9.01
- 2013-03-11 0001193125-13-101082 — 5.02, 9.01
- 2013-02-28 0001193125-13-084193 — 2.02, 9.01
- 2012-12-14 0001193125-12-503335 — 5.07
- 2012-12-06 0001193125-12-493700 — 2.02, 9.01
- 2012-09-24 0001193125-12-401534 — 1.01, 2.03
- 2012-09-20 0001193125-12-398433 — 5.02, 9.01
- 2012-09-10 0001193125-12-386605 — 2.02, 9.01

## late-filing notifications on or before 2016-11-22

- none on or before 2016-11-22

## item 2.02 — earnings release, exhibit 99.1

[0001327567-16-000071:8k_2_02:1]
EX-99.1
2
ex991q117earningsrelease.htm
EXHIBIT 99.1

[0001327567-16-000071:8k_2_02:2]
Exhibit

[0001327567-16-000071:8k_2_02:3]
Exhibit 99.1

[0001327567-16-000071:8k_2_02:4]
Palo Alto Networks Reports Fiscal First Quarter 2017 Financial Results

[0001327567-16-000071:8k_2_02:5]
| • | Fiscal first quarter total revenue grows 34 percent year over year to $398.1 million |

[0001327567-16-000071:8k_2_02:6]
| • | Fiscal first quarter billings grow 33 percent year over year to $516.9 million |

[0001327567-16-000071:8k_2_02:7]
| • | Fiscal first quarter deferred revenue grows 69 percent year over year to $1.4 billion |

[0001327567-16-000071:8k_2_02:8]
| • | Fiscal first quarter cash flow from operations grows 39 percent year over year to $203.3 million, and free cash flow grows 43 percent year over year to $182.4 million |

[0001327567-16-000071:8k_2_02:9]
SANTA CLARA, Calif. — November 21, 2016 — Palo Alto Networks® (NYSE: PANW), the next-generation security company, today announced financial results for its fiscal first quarter 2017 ended October 31, 2016.

[0001327567-16-000071:8k_2_02:10]
Total revenue for the fiscal first quarter 2017 grew 34 percent year over year to $398.1 million, compared with total revenue of $297.2 million for the fiscal first quarter 2016. GAAP net loss for the fiscal first quarter 2017 was $61.8 million, or $0.69 per diluted share, compared with GAAP net loss of $39.9 million, or $0.47 per diluted share, for the fiscal first quarter 2016.

[0001327567-16-000071:8k_2_02:11]
Non-GAAP net income for the fiscal first quarter 2017 was $51.2 million, or $0.55 per diluted share, compared with non-GAAP net income of $30.8 million, or $0.34 per diluted share, for the fiscal first quarter 2016. A reconciliation between GAAP and non-GAAP information is contained in the tables below.

[0001327567-16-000071:8k_2_02:12]
“Our first quarter 2017 results underscore that our Next-Generation Security Platform uniquely solves customers’ most complex security challenges,” said Mark McLaughlin, chief executive officer of Palo Alto Networks. “Our platform's ability to provide high degrees of prevention, automation, leverage and consistent security, regardless of wherever data may be, is becoming increasingly important in the face of

[0001327567-16-000071:8k_2_02:13]
today’s important macro technology changes. As a result, customers and prospects globally are adopting our platform at high rates.”

[0001327567-16-000071:8k_2_02:14]
“In the first quarter fiscal 2017, we added well over 1,500 new customers and saw broad adoption of our Next-Generation Security Platform by our existing customer base. We are now privileged to serve more than 35,500 customers worldwide,” commented Steffan Tomlinson, chief financial officer of Palo Alto Networks. “The power of our hybrid-SaaS model was also evident as we continued to grow multiples of our total addressable market at scale, resulting in record quarterly deferred revenue, cash flow from operations of $203.3 million, and free cash flow of $182.4 million.”

[0001327567-16-000071:8k_2_02:15]
Recent Highlights

[0001327567-16-000071:8k_2_02:16]
| • | Teamed with leading Service Providers in APAC – We recently signed agreements with leading service providers in APAC, helping partners reach new revenue sources. Singapore Telecommunications Ltd. (Singtel) is offering its new Managed Advanced Threat Prevention Service, a unique managed security service that harnesses the expertise of Singtel Managed Security Service and the technology of Palo Alto Networks Next-Generation Security Platform, including AutoFocus™ contextual threat intelligence, to protect large enterprise organizations against sophisticated cyberthreats. Meanwhile M1 Limited (M1) is offering Palo Alto Networks Next-Generation Firewall as part of its Cyber Security Solution to enterprise customers, delivering an industry-leading, carrier-grade, cloud-based “internet clean pipe” solution to protect the enterprise’s network and architecture – without sacrificing effectiveness or performance. |

[0001327567-16-000071:8k_2_02:17]
| • | Verified that Traps™ helps customers meet HIPAA and PCI cybersecurity compliance requirements – Our Traps™ advanced endpoint protection offering received independent verification from Coalfire Systems, a respected leader in cyber risk management and compliance services and a Qualified Security Assessor, that it meets specific cybersecurity requirements outlined by both Health Insurance Portability and Accountability Act (HIPAA) and the Payment |

[0001327567-16-000071:8k_2_02:18]
2

[0001327567-16-000071:8k_2_02:19]
Card Industry (PCI) Data Security Standard, concluding that organizations in the healthcare and financial sectors can replace legacy antivirus endpoint products with Traps™ while remaining compliant with federal law and industry standards.

[0001327567-16-000071:8k_2_02:20]
| • | Continued cyber education efforts with new cybersecurity guides for C-suites and boards – In conjunction with industry experts, we published regionally tailored guides in both France and Australia designed to provide executives and directors practical advice on a range of cybersecurity issues, including compliance and breach avoidance, prevention and response. |

[0001327567-16-000071:8k_2_02:21]
| • | Appointed Mary Pat McCarthy to the board of directors – Ms. McCarthy joined our board and audit committee and brings more than 34 years of experience in financial and accounting matters. Ms. McCarthy has served in numerous senior leadership positions at KPMG LLP, most recently as vice chair, and on various other boards and audit committees. |

[0001327567-16-000071:8k_2_02:22]
Financial Outlook

[0001327567-16-000071:8k_2_02:23]
Palo Alto Networks provides guidance based on current market conditions and expectations.

[0001327567-16-000071:8k_2_02:24]
For the fiscal second quarter 2017, we expect:

[0001327567-16-000071:8k_2_02:25]
| • | Total revenue in the range of $426 to $432 million, representing year-over-year growth between 27 percent and 29 percent. |

[0001327567-16-000071:8k_2_02:26]
| • | Diluted non-GAAP net income per share in the range of $0.61 to $0.63 using 93.5 to 95.5 million shares. |

[0001327567-16-000071:8k_2_02:27]
Guidance for non-GAAP financial measures excludes share-based compensation related charges, including share-based payroll tax expense, acquisition related costs, amortization expense of acquired intangible assets, litigation related charges including legal settlements, non-cash interest expense related to our convertible senior notes, foreign currency gains (losses) and income and other tax effects associated with these items, and certain non-recurring expenses. We have not reconciled diluted non-GAAP net

[0001327567-16-000071:8k_2_02:28]
income per share guidance to GAAP net income (loss) per diluted share because we do not provide guidance on GAAP net income (loss) and would not be able to present the various reconciling cash and non-cash items between GAAP net income (loss) and non-GAAP net income (loss), including share-based compensation expense, without unreasonable efforts. Share-based compensation expense is impacted by the company’s future hiring and retention needs and, to a lesser extent, the future fair market value of the company’s common stock, all of which is difficult to predict and subject to constant change. While the actual amounts of such reconciling items will have a significant impact on the company’s GAAP net income (loss) per diluted share, a reconciliation of the non-GAAP financial measure guidance to the corresponding GAAP measure is not available without unreasonable effort.

[0001327567-16-000071:8k_2_02:29]
Conference Call Information

[0001327567-16-000071:8k_2_02:30]
Palo Alto Networks will host a conference call for analysts and investors to discuss its fiscal first quarter 2017 results and outlook for its fiscal second quarter 2017 today at 4:30 p.m. Eastern time/1:30 p.m. Pacific time. Open to the public, investors may access the call by dialing 1-877-856-1958 or 1-719-325-4825 and using conference ID 3370101. A live audio webcast of the conference call, along with supplemental financial information, will also be accessible from the “Investors” section of our website at investors.paloaltonetworks.com. Following the webcast, an archived version will be available on our website for one year. A telephonic replay of the call will be available three hours after the call, will run for ten days, and may be accessed by dialing 1-888-203-1112 or 1-719-457-0820 and entering the passcode 3370101.

[0001327567-16-000071:8k_2_02:31]
Forward-Looking Statements

[0001327567-16-000071:8k_2_02:32]
This press release contains forward-looking statements that involve risks and uncertainties, including statements regarding our future financial and operating performance, including our financial outlook for the fiscal second quarter 2017, and the increasing importance of our platform’s ability to provide high degrees of prevention, automation, leverage and security consistently. There are a significant number of

[0001327567-16-000071:8k_2_02:33]
4

[0001327567-16-000071:8k_2_02:34]
factors that could cause actual results to differ materially from statements made in this press release, including: our limited operating history, which makes it difficult to predict future results; risks associated with managing our rapid growth; our limited experience with new product and subscription and support introductions and the risks associated with new products and subscription and support offerings, including software bugs; the failure to timely develop and achieve market acceptance of new products and subscriptions as well as existing products and subscription and support; rapidly evolving technological developments in the market for network security products and subscription and support offerings; length of sales cycles; and general market, political, economic and business conditions.

[0001327567-16-000071:8k_2_02:35]
Additional risks and uncertainties that could affect our financial results are included under the captions “Risk Factors” and “Management’s Discussion and Analysis of Financial Condition and Results of Operations” in our Annual Report on Form 10-K filed with the SEC on September 8, 2016, which is available on our website at investors.paloaltonetworks.com and on the SEC’s website at www.sec.gov. Additional information will also be set forth in other filings that we make with the SEC from time to time. All forward-looking statements in this press release are based on information available to us as of the date hereof, and we do not assume any obligation to update the forward-looking statements provided to reflect events that occur or circumstances that exist after the date on which they were made.

[0001327567-16-000071:8k_2_02:36]
Non-GAAP Financial Measures and Other Key Metrics

[0001327567-16-000071:8k_2_02:37]
Palo Alto Networks has provided in this press release financial information that has not been prepared in accordance with generally accepted accounting principles in the United States (GAAP). The company uses these non-GAAP financial measures and key metrics internally in analyzing its financial results and believes that the use of these non-GAAP financial measures and key metrics is useful to investors as an additional tool to evaluate ongoing operating results and trends and in comparing the company’s financial results with other companies in its industry, many of which present similar non-GAAP financial measures or key metrics.

[0001327567-16-000071:8k_2_02:38]
The presentation of these non-GAAP financial measures and key metrics are not meant to be considered in isolation or as a substitute for comparable GAAP financial measures, and should be read only in conjunction with the company’s consolidated financial statements prepared in accordance with GAAP. A reconciliation of the company’s historical non-GAAP financial measures and key metrics to their most directly comparable GAAP measures has been provided in the financial statement tables included in this press release, and investors are encouraged to review these reconciliations.

[0001327567-16-000071:8k_2_02:39]
Non-GAAP net income and net income per share, diluted. Palo Alto Networks defines non-GAAP net income as net income (loss) plus share-based compensation related charges including share-based payroll tax expense, acquisition related costs, amortization expense of acquired intangible assets, litigation related charges including legal settlements, non-cash interest expense related to the company’s convertible senior notes, and intellectual property restructuring related charges. The company also excludes from non-GAAP net income the foreign currency gains (losses) and tax effects associated with these items in order to provide a complete picture of the company’s recurring core business operating results. The company defines non-GAAP net income per share, diluted, as non-GAAP net income divided by the weighted average diluted shares outstanding after giving effect to the anti-dilutive impact of the company’s note hedge agreements, which reduces the potential economic dilution that otherwise would occur upon conversion of the company’s convertible senior notes. Under GAAP, the anti-dilutive impact of the note hedge is not reflected in diluted shares outstanding. Palo Alto Networks believes that excluding these items from non-GAAP net income and non-GAAP net income per share, diluted, provides management and investors with greater visibility into the underlying performance of the company’s core business operating results, meaning its operating performance excluding these items and, from time to time, other discrete charges that are infrequent in nature, over multiple periods.

[0001327567-16-000071:8k_2_02:40]
6

[0001327567-16-000071:8k_2_02:41]
Billings. Palo Alto Networks defines billings as total revenue plus the change in total deferred revenue during the period. The company considers billings to be a key metric used by management to manage the company’s business given the company’s hybrid-SaaS revenue model, and believes billings provides investors with an important indicator of the health and visibility of the company’s business because it includes subscription and support revenue, which is recognized ratably over the contractual service period, and product revenue, which is recognized at the time of shipment, provided that all other revenue recognition criteria have been met. The company considers billings to be a useful metric for management and investors, particularly if sales of subscriptions continue to increase and the company experiences strong renewal rates for subscription and support offerings.

[0001327567-16-000071:8k_2_02:42]
Free cash flow. Palo Alto Networks defines free cash flow as cash provided by operating activities less purchases of property, equipment, and other assets. The company considers free cash flow to be a profitability and liquidity measure that provides useful information to management and investors about the amount of cash generated by the business after necessary capital expenditures.

[0001327567-16-000071:8k_2_02:43]
Investors are cautioned that there are a number of limitations associated with the use of non-GAAP financial measures and key metrics as analytical tools. In particular, the billings metric reported by the company includes amounts that have not yet been recognized as revenue and free cash flow does not represent the total increase or decrease in our cash balance for the period. In addition, many of the adjustments to the company’s GAAP financial measures reflect the exclusion of items that are recurring and will be reflected in the company’s financial results for the foreseeable future, such as share-based compensation, which is an important part of Palo Alto Networks employees’ compensation and impacts their performance. Furthermore, these non-GAAP financial measures are not based on any standardized methodology prescribed by GAAP, and the components that Palo Alto Networks excludes in its calculation of non-GAAP financial measures may differ from the components that its peer companies exclude when they report their non-GAAP results of operations. Palo Alto Networks compensates for

[0001327567-16-000071:8k_2_02:44]
7

[0001327567-16-000071:8k_2_02:45]
these limitations by providing specific information regarding the GAAP amounts excluded from these non-GAAP financial measures. In the future, the company may also exclude non-recurring expenses and other expenses that do not reflect the company’s core business operating results.

[0001327567-16-000071:8k_2_02:46]
About Palo Alto Networks

[0001327567-16-000071:8k_2_02:47]
Palo Alto Networks is the next-generation security company, leading a new era in cybersecurity by safely enabling applications and preventing cyber breaches for tens of thousands of organizations worldwide. Built with an innovative approach and highly differentiated cyberthreat prevention capabilities, our game-changing security platform delivers security far superior to legacy or point products, safely enables daily business operations, and protects an organization’s most valuable assets. Find out more at www.paloaltonetworks.com.

[0001327567-16-000071:8k_2_02:48]
Palo Alto Networks and the Palo Alto Networks logo are trademarks of Palo Alto Networks, Inc. in the United States and in jurisdictions throughout the world. All other trademarks, trade names or service marks used or mentioned herein belong to their respective owners.

[0001327567-16-000071:8k_2_02:49]
Media Contact:

[0001327567-16-000071:8k_2_02:50]
Jennifer Jasper Smith

[0001327567-16-000071:8k_2_02:51]
Head of Corporate Communications

[0001327567-16-000071:8k_2_02:52]
Palo Alto Networks

[0001327567-16-000071:8k_2_02:53]
408-638-3280

[0001327567-16-000071:8k_2_02:54]
jjsmith@paloaltonetworks.com

[0001327567-16-000071:8k_2_02:55]
Investor Relations Contact:

[0001327567-16-000071:8k_2_02:56]
Kelsey Turcotte

[0001327567-16-000071:8k_2_02:57]
Vice President of Investor Relations

[0001327567-16-000071:8k_2_02:58]
Palo Alto Networks

[0001327567-16-000071:8k_2_02:59]
408-753-3872

[0001327567-16-000071:8k_2_02:60]
kturcotte@paloaltonetworks.com

[0001327567-16-000071:8k_2_02:61]
| Palo Alto Networks, Inc. |
| Preliminary Condensed Consolidated Statements of Operations |
| (In millions, except per share data) |
| (Unaudited) |
|  | Three Months Ended October 31, |
|  | 2016 |  | 2015 |
|  |  |  | (As Adjusted)(1) |
| Revenue: |  |  |  |
| Product | $ | 163.8 |  |  | $ | 147.7 |  |
| Subscription and support | 234.3 |  |  | 149.5 |  |
| Total revenue | 398.1 |  |  | 297.2 |  |
| Cost of revenue: |  |  |  |
| Product | 42.2 |  |  | 38.8 |  |
| Subscription and support | 59.1 |  |  | 40.4 |  |
| Total cost of revenue | 101.3 |  |  | 79.2 |  |
| Total gross profit | 296.8 |  |  | 218.0 |  |
| Operating expenses: |  |  |  |
| Research and development | 84.6 |  |  | 59.7 |  |
| Sales and marketing | 220.3 |  |  | 159.5 |  |
| General and administrative | 41.8 |  |  | 30.8 |  |
| Total operating expenses | 346.7 |  |  | 250.0 |  |
| Operating loss | (49.9 | ) |  | (32.0 | ) |
| Interest expense | (6.0 | ) |  | (5.8 | ) |
| Other income, net | 2.5 |  |  | 2.2 |  |
| Loss before income taxes | (53.4 | ) |  | (35.6 | ) |
| Provision for income taxes | 8.4 |  |  | 4.3 |  |
| Net loss | $ | (61.8 | ) |  | $ | (39.9 | ) |
| Net loss per share, basic and diluted | $ | (0.69 | ) |  | $ | (0.47 | ) |
| Weighted-average shares used to compute net loss per share, basic and diluted | 89.8 |  |  | 85.1 |  |

[0001327567-16-000071:8k_2_02:62]
___________

[0001327567-16-000071:8k_2_02:63]
| (1) | Certain amounts have been adjusted as a result of the Company’s change in accounting policy for sales commissions. Refer to Appendix A for more information. |

[0001327567-16-000071:8k_2_02:64]
10

[0001327567-16-000071:8k_2_02:65]
| Palo Alto Networks, Inc. |
| Reconciliation of GAAP to Non-GAAP Financial Measures |
| (In millions, except per share amounts) |
| (Unaudited) |
|  | Three Months Ended October 31, |
|  | 2016 |  | 2015 |
|  |  |  | (As Adjusted)(1) |
| GAAP net loss | $ | (61.8 | ) |  | $ | (39.9 | ) |
| Share-based compensation related charges | 116.5 |  |  | 75.2 |  |
| Amortization expense of acquired intangible assets | 2.1 |  |  | 2.1 |  |
| Litigation related charges | 3.1 |  |  | 3.1 |  |
| Non-cash interest expense related to convertible notes | 6.0 |  |  | 5.8 |  |
| Foreign currency gains associated with non-GAAP adjustments | (0.2 | ) |  | (0.8 | ) |
| Income tax and other tax adjustments related to the above | (14.5 | ) |  | (14.7 | ) |
| Non-GAAP net income | $ | 51.2 |  |  | $ | 30.8 |  |
| GAAP net loss per share, diluted | $ | (0.69 | ) |  | $ | (0.47 | ) |
| Share-based compensation related charges | 1.28 |  |  | 0.86 |  |
| Amortization expense of acquired intangible assets | 0.02 |  |  | 0.02 |  |
| Litigation related charges | 0.03 |  |  | 0.04 |  |
| Non-cash interest expense related to convertible notes | 0.07 |  |  | 0.07 |  |
| Foreign currency gains associated with non-GAAP adjustments | 0.00 |  |  | (0.01 | ) |
| Income tax and other tax adjustments related to the above | (0.16 | ) |  | (0.17 | ) |
| Non-GAAP net income per share, diluted | $ | 0.55 |  |  | $ | 0.34 |  |
| GAAP weighted-average shares used to compute net loss per share, diluted | 89.8 |  |  | 85.1 |  |
| Weighted-average effect of potentially dilutive securities(2) | 3.4 |  |  | 5.6 |  |
| Non-GAAP weighted-average shares used to compute net income per share, diluted | 93.2 |  |  | 90.7 |  |
| Net cash provided by operating activities | $ | 203.3 |  |  | $ | 146.7 |  |
| Less: purchases of property, equipment, and other assets | 20.9 |  |  | 19.5 |  |
| Free cash flow | $ | 182.4 |  |  | $ | 127.2 |  |
| Net cash used in investing activities | $ | (71.2 | ) |  | $ | (263.5 | ) |
| Net cash provided by (used in) financing activities | $ | (27.1 | ) |  | $ | 16.8 |  |

[0001327567-16-000071:8k_2_02:66]
___________

[0001327567-16-000071:8k_2_02:67]
| (1) | Certain amounts have been adjusted as a result of the Company’s change in accounting policy for sales commissions. Refer to Appendix A for more information. |

[0001327567-16-000071:8k_2_02:68]
| (2) | Non-GAAP net income per share, diluted, includes the potentially dilutive effect of employee equity incentive plan awards and convertible senior notes outstanding. In addition, non-GAAP net income per share, diluted, includes the anti-dilutive impact of the Company’s note hedge agreements, which reduced the potentially dilutive effect of the convertible notes for the three months ended October 31, 2016 and October 31, 2015 by 1.5 million shares and 1.8 million shares, respectively. |

[0001327567-16-000071:8k_2_02:69]
11

[0001327567-16-000071:8k_2_02:70]
| Palo Alto Networks, Inc. |
| Calculation of Billings |
| (In millions) |
| (Unaudited) |
|  | Three Months Ended |
|  | October 31, |
|  | 2016 |  | 2015 |
| Total revenue | $ | 398.1 |  |  | $ | 297.2 |  |
| Add: change in total deferred revenue | 118.8 |  |  | 90.8 |  |
| Billings | $ | 516.9 |  |  | $ | 388.0 |  |

[0001327567-16-000071:8k_2_02:71]
12

[0001327567-16-000071:8k_2_02:72]
| Palo Alto Networks, Inc. |
| Preliminary Condensed Consolidated Balance Sheets |
| (In millions) |
| (Unaudited) |
|  | October 31, 2016 |  | July 31, 2016 |
|  |  |  | (As Adjusted)(1) |
| Assets |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 839.4 |  |  | $ | 734.4 |  |
| Short-term investments | 550.6 |  |  | 551.2 |  |
| Accounts receivable, net | 346.5 |  |  | 348.7 |  |
| Prepaid expenses and other current assets | 129.4 |  |  | 139.7 |  |
| Total current assets | 1,865.9 |  |  | 1,774.0 |  |
| Property and equipment, net | 125.0 |  |  | 117.2 |  |
| Long-term investments | 708.4 |  |  | 652.8 |  |
| Goodwill | 163.5 |  |  | 163.5 |  |
| Intangible assets, net | 41.7 |  |  | 44.0 |  |
| Other assets | 102.0 |  |  | 106.7 |  |
| Total assets | $ | 3,006.5 |  |  | $ | 2,858.2 |  |
| Liabilities, temporary equity, and stockholders’ equity |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 29.2 |  |  | $ | 30.2 |  |
| Accrued compensation | 59.0 |  |  | 73.5 |  |
| Accrued and other liabilities | 48.4 |  |  | 39.2 |  |
| Deferred revenue | 758.1 |  |  | 703.9 |  |
| Convertible senior notes, net | 506.2 |  |  | — |  |
| Total current liabilities | 1,400.9 |  |  | 846.8 |  |
| Convertible senior notes, net | — |  |  | 500.2 |  |
| Long-term deferred revenue | 601.5 |  |  | 536.9 |  |
| Other long-term liabilities | 85.8 |  |  | 79.4 |  |
| Temporary equity | 61.4 |  |  | — |  |
| Stockholders’ equity: |  |  |  |
| Preferred stock | — |  |  | — |  |
| Common stock and additional paid-in capital | 1,542.2 |  |  | 1,515.5 |  |
| Accumulated other comprehensive income (loss) | (1.9 | ) |  | 1.0 |  |
| Accumulated deficit | (683.4 | ) |  | (621.6 | ) |
| Total stockholders’ equity | 856.9 |  |  | 894.9 |  |
| Total liabilities, temporary equity, and stockholders’ equity | $ | 3,006.5 |  |  | $ | 2,858.2 |  |

[0001327567-16-000071:8k_2_02:73]
___________

[0001327567-16-000071:8k_2_02:74]
| (1) | Certain amounts have been adjusted as a result of the Company’s change in accounting policy for sales commissions. Refer to Appendix A for more information. |

[0001327567-16-000071:8k_2_02:75]
13

[0001327567-16-000071:8k_2_02:76]
| Palo Alto Networks, Inc. |
| Preliminary Condensed Consolidated Statements of Cash Flows |
| (In millions) |
| (Unaudited) |
|  | Three Months Ended October 31, |
|  | 2016 |  | 2015 |
|  |  |  | (As Adjusted)(1) |
| Cash flows from operating activities |  |  |  |
| Net loss | $ | (61.8 | ) |  | $ | (39.9 | ) |
| Adjustments to reconcile net loss to net cash provided by operating activities: |  |  |  |
| Share-based compensation for equity based awards | 114.2 |  |  | 72.9 |  |
| Depreciation and amortization | 13.6 |  |  | 9.2 |  |
| Amortization of investment premiums, net of accretion of purchase discounts | 0.7 |  |  | 0.8 |  |
| Amortization of debt discount and debt issuance costs | 6.0 |  |  | 5.7 |  |
| Excess tax benefit from share-based compensation arrangements | (0.2 | ) |  | (0.2 | ) |
| Changes in operating assets and liabilities: |  |  |  |
| Accounts receivable, net | 2.2 |  |  | 16.0 |  |
| Prepaid expenses and other assets | 10.1 |  |  | 7.3 |  |
| Accounts payable | 1.8 |  |  | 5.2 |  |
| Accrued compensation | (14.5 | ) |  | (27.0 | ) |
| Accrued and other liabilities | 12.4 |  |  | 5.9 |  |
| Deferred revenue | 118.8 |  |  | 90.8 |  |
| Net cash provided by operating activities | 203.3 |  |  | 146.7 |  |
| Cash flows from investing activities |  |  |  |
| Purchases of investments | (285.7 | ) |  | (512.5 | ) |
| Proceeds from sales of investments | — |  |  | 124.4 |  |
| Proceeds from maturities of investments | 235.4 |  |  | 144.1 |  |
| Purchases of property, equipment, and other assets | (20.9 | ) |  | (19.5 | ) |
| Net cash used in investing activities | (71.2 | ) |  | (263.5 | ) |
| Cash flows from financing activities |  |  |  |
| Repurchases of common stock | (50.0 | ) |  | — |  |
| Proceeds from sales of shares through employee equity incentive plans | 22.7 |  |  | 16.6 |  |
| Excess tax benefit from share-based compensation arrangements | 0.2 |  |  | 0.2 |  |
| Net cash provided by (used in) financing activities | (27.1 | ) |  | 16.8 |  |
| Net increase (decrease) in cash and cash equivalents | 105.0 |  |  | (100.0 | ) |
| Cash and cash equivalents - beginning of period | 734.4 |  |  | 375.8 |  |
| Cash and cash equivalents - end of period | $ | 839.4 |  |  | $ | 275.8 |  |

[0001327567-16-000071:8k_2_02:77]
___________

[0001327567-16-000071:8k_2_02:78]
| (1) | Certain amounts have been adjusted as a result of the Company’s change in accounting policy for sales commissions. Refer to Appendix A for more information. |

[0001327567-16-000071:8k_2_02:79]
14

[0001327567-16-000071:8k_2_02:80]
Palo Alto Networks, Inc.

[0001327567-16-000071:8k_2_02:81]
Appendix A

[0001327567-16-000071:8k_2_02:82]
Change in Accounting Policy

[0001327567-16-000071:8k_2_02:83]
(Unaudited)

[0001327567-16-000071:8k_2_02:84]
Effective August 1, 2016, the Company voluntarily changed its accounting policy for sales commissions that are incremental and directly related to non-cancelable customer sales contracts from recording an expense when incurred to deferral and amortization of the sales commissions over the term of the related contract in proportion to the recognized revenue. The adoption of this accounting policy change has been applied retrospectively to all prior periods presented in this document, in which the cumulative effect of the change has been reflected as of the beginning of the earliest period presented.

[0001327567-16-000071:8k_2_02:85]
The following tables present the changes to financial statement line items as a result of the accounting change for the periods presented in the Company’s preliminary condensed consolidated financial statements (in millions, except per share data):

[0001327567-16-000071:8k_2_02:86]
|  | October 31, 2016 |  | July 31, 2016 |
|  | Computed under Prior Method |  | Impact of Commission Adjustment |  | As Reported |  | As Previously Reported |  | Impact of Commission Adjustment |  | As Adjusted |
| Preliminary Condensed Consolidated Balance Sheets |  |  |  |  |  |  |  |  |  |  |  |
| Prepaid expenses and other current assets | $ | 75.4 |  |  | $ | 54.0 |  |  | $ | 129.4 |  |  | $ | 84.8 |  |  | $ | 54.9 |  |  | $ | 139.7 |  |
| Other assets | 53.6 |  |  | 48.4 |  |  | 102.0 |  |  | 64.6 |  |  | 50.1 |  |  | 114.7 |  |
| Other long-term liabilities | 85.0 |  |  | 0.8 |  |  | 85.8 |  |  | 79.4 |  |  | — |  |  | 79.4 |  |
| Accumulated deficit | $ | (785.0 | ) |  | $ | 101.6 |  |  | $ | (683.4 | ) |  | $ | (726.6 | ) |  | $ | 105.0 |  |  | $ | (621.6 | ) |

[0001327567-16-000071:8k_2_02:87]
|  | Three Months Ended October 31, 2016 |  | Three Months Ended October 31, 2015 |
|  | Computed under Prior Method |  | Impact of Commission Adjustment |  | As Reported |  | As Previously Reported |  | Impact of Commission Adjustment |  | As Adjusted |
| Preliminary Condensed Consolidated Statements of Operations |  |  |  |  |  |  |  |  |  |  |  |
| Sales and marketing | $ | 217.7 |  |  | $ | 2.6 |  |  | $ | 220.3 |  |  | $ | 158.3 |  |  | $ | 1.2 |  |  | $ | 159.5 |  |
| Operating loss | (47.3 | ) |  | (2.6 | ) |  | $ | (49.9 | ) |  | (30.8 | ) |  | (1.2 | ) |  | (32.0 | ) |
| Provision for income taxes | 7.6 |  |  | 0.8 |  |  | 8.4 |  |  | 4.3 |  |  | — |  |  | 4.3 |  |
| Net loss | $ | (58.4 | ) |  | $ | (3.4 | ) |  | $ | (61.8 | ) |  | $ | (38.7 | ) |  | $ | (1.2 | ) |  | $ | (39.9 | ) |
| Net loss per share, basic and diluted | $ | (0.65 | ) |  | $ | (0.04 | ) |  | $ | (0.69 | ) |  | $ | (0.45 | ) |  | $ | (0.02 | ) |  | $ | (0.47 | ) |
| Weighted-average shares used to compute net loss per share, basic and diluted | 89.8 |  |  | — |  |  | 89.8 |  |  | 85.1 |  |  | — |  |  | 85.1 |  |

[0001327567-16-000071:8k_2_02:88]
This change in accounting policy does not affect the Company’s balance of cash and cash equivalents and, as a result, did not change net cash flows from operating, investing, or financing activities or materially impact any individual line items in the Company’s preliminary condensed consolidated statement of cash flows for the three months ended October 31, 2015.

[0001327567-16-000071:8k_2_02:89]
15
