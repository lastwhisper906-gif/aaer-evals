# PANW notes — 0001327567-22-000028


## dei:DocumentsIncorporatedByReferenceTextBlock

[0001327567-22-000028:notes:1]
Portions of the information called for by Part III of this Annual Report on Form 10-K is hereby incorporated by reference from the definitive proxy statement for the registrant’s 2022 annual meeting of stockholders, which will be filed with the Securities and Exchange Commission not later than 120 days after the registrant’s fiscal year ended July 31, 2022.


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock

[0001327567-22-000028:notes:2]
Description of Business and Summary of Significant Accounting Policies 
Description of Business

[0001327567-22-000028:notes:3]
Palo Alto Networks, Inc. (the “Company,” “we,” “us,” or “our”), headquartered in Santa Clara, California, was incorporated in March 2005 under the laws of the State of Delaware and commenced operations in April 2005. We empower enterprises, organizations, service providers, and government entities to secure their users, networks, clouds and endpoints by delivering comprehensive cybersecurity backed by artificial intelligence and automation.

[0001327567-22-000028:notes:4]
Basis of Presentation

[0001327567-22-000028:notes:5]
The accompanying consolidated financial statements have been prepared in conformity with U.S. generally accepted accounting principles (“GAAP”). The consolidated financial statements include all adjustments necessary for a fair presentation of our annual results. All adjustments are of a normal recurring nature.

[0001327567-22-000028:notes:6]
Principles of Consolidation

[0001327567-22-000028:notes:7]
The consolidated financial statements include our accounts and our wholly owned subsidiaries. All significant intercompany balances and transactions have been eliminated in consolidation.

[0001327567-22-000028:notes:8]
Use of Estimates

[0001327567-22-000028:notes:9]
The preparation of consolidated financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the amounts reported and disclosed in the consolidated financial statements and the accompanying notes. We evaluate our estimates on an ongoing basis. Management estimates include, but are not limited to, the standalone selling price for our products and services, share-based compensation, fair value of assets acquired and liabilities assumed in business combinations, the assessment of recoverability of our intangibles and goodwill, valuation allowance against deferred tax assets, manufacturing partner and supplier liabilities, deferred contract cost benefit period, and loss contingencies. We base our estimates on assumptions, both historical and forward looking, that we believe are reasonable. Actual results could differ materially from those estimates due to risks and uncertainties, including uncertainty in the current economic environment.

[0001327567-22-000028:notes:10]
Concentrations

[0001327567-22-000028:notes:11]
Financial instruments that subject us to concentrations of credit risk consist primarily of cash and cash equivalents, investments, derivative contracts, accounts receivable and financing receivables.

[0001327567-22-000028:notes:12]
We invest only in high-quality credit instruments and our cash and cash equivalents and available-for-sale investments consist primarily of fixed income securities. Management believes that the financial institutions that hold our investments are financially sound and, accordingly, are subject to minimal credit risk. Deposits held with banks may exceed the amount of insurance provided on such deposits.

[0001327567-22-000028:notes:13]
Our derivative contracts expose us to credit risk to the extent that the counterparties may be unable to meet the terms of the arrangement. We mitigate this credit risk by transacting with major financial institutions with high credit ratings and also enter into master netting arrangements, which permit net settlement of transactions with the same counterparty. We are not required to pledge, and are not entitled to receive, cash collateral related to these derivative instruments. We do not enter into derivative contracts for trading or speculative purposes.

[0001327567-22-000028:notes:14]
Our accounts receivable are primarily derived from our distributors in various geographical locations. Our financing receivables are with qualified end-customers. We perform ongoing credit evaluations and generally do not require collateral on accounts receivable or financing receivables.

[0001327567-22-000028:notes:15]
As of July 31, 2022, three distributors individually represented 10% or more of our gross accounts receivable, and in the aggregate represented 47.7% of our gross accounts receivable. As of July 31, 2022, two end-customers represented 10% or more of our gross financing receivables, and in aggregate represented 33.7% of our gross financing receivables.

[0001327567-22-000028:notes:16]
For fiscal 2022, three distributors represented 10% or more of our total revenue, representing 29.7%, 12.4%, and 11.5%, respectively. No single end-customer accounted for more than 10% of our total revenue in fiscal 2022, 2021, or 2020.

[0001327567-22-000028:notes:17]
We rely on an electronics manufacturing services provider (“EMS provider”) to assemble most of our products and sole source component suppliers for a certain number of our components.

[0001327567-22-000028:notes:18]
Comprehensive Loss

[0001327567-22-000028:notes:19]
Comprehensive loss is comprised of net loss and other comprehensive income (loss). Our other comprehensive income (loss) includes unrealized gains and losses on available-for-sale investments and unrealized gains and losses on cash flow hedges.

[0001327567-22-000028:notes:20]
Foreign Currency Transactions

[0001327567-22-000028:notes:21]
The functional currency of our foreign subsidiaries is the U.S. dollar. Monetary assets and liabilities denominated in foreign currencies have been remeasured into U.S. dollars using the exchange rates in effect at the balance sheet dates. Foreign currency remeasurement gains and losses and foreign currency transaction gains and losses are not significant to the consolidated financial statements.

[0001327567-22-000028:notes:22]
Fair Value

[0001327567-22-000028:notes:23]
We define fair value as the price that would be received from selling an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date. When determining the fair value measurements for assets and liabilities which are required to be recorded at fair value, we consider the principal or most advantageous market in which to transact and the market-based risk.

[0001327567-22-000028:notes:24]
We categorize assets and liabilities recorded or disclosed at fair value on our consolidated balance sheets based upon the level of judgment associated with inputs used to measure their fair value. The categories are as follows:

[0001327567-22-000028:notes:25]
•Level 1—Inputs are unadjusted quoted prices in active markets for identical assets or liabilities.

[0001327567-22-000028:notes:26]
•Level 2—Inputs are quoted prices for similar assets and liabilities in active markets or inputs that are observable for the assets or liabilities, either directly or indirectly through market corroboration, for substantially the full term of the financial instruments.

[0001327567-22-000028:notes:27]
•Level 3—Inputs are unobservable inputs based on our own assumptions used to measure assets and liabilities at fair value. The inputs require significant management judgment or estimation.

[0001327567-22-000028:notes:28]
Our financial assets and liabilities that are measured at fair value on a recurring basis include marketable securities and derivative financial instruments. Goodwill, intangible assets, and other long-lived assets are measured at fair value on a nonrecurring basis, only if impairment is indicated. The carrying amounts reported in the consolidated financial statements approximate the fair value for cash and cash equivalents, accounts receivable, accounts payable, and accrued liabilities, due to their short-term nature.

[0001327567-22-000028:notes:29]
Cash, Cash Equivalents, and Investments

[0001327567-22-000028:notes:30]
We consider all highly liquid investments with original maturities of three months or less at the date of purchase to be cash equivalents. Investments not considered cash equivalents, and with maturities of one year or less from the consolidated balance sheet date, are classified as short-term investments. Investments with maturities greater than one year from the consolidated balance sheet date are classified as long-term investments.

[0001327567-22-000028:notes:31]
We determine the classification of our investments in marketable debt securities at the time of purchase and reevaluate such determination at each balance sheet date. Our marketable debt securities are classified as available-for-sale. Debt securities in an unrealized loss position are written down to its fair value with the corresponding charge recorded in other income, net in our consolidated statements of operations, if it is more likely than not that we will be required to sell the impaired security before recovery of its amortized cost basis, or we have the intention to sell the security. If neither of these conditions are met, we determine whether a credit loss exists by comparing the present value of the expected cash flows of the security with its amortized cost basis. An allowance for credit losses is recorded in other income, net in our consolidated statements of operations for an amount not to exceed the unrealized loss. Unrealized losses that are not credit-related are included in accumulated other comprehensive income (loss) (“AOCI”) in stockholders’ equity.

[0001327567-22-000028:notes:32]
Accounts Receivable

[0001327567-22-000028:notes:33]
Trade accounts receivable are recorded at the invoiced amount, net of allowances for credit losses. The allowance for credit losses is based on our assessment of collectability. Management regularly reviews the adequacy of the allowance for credit losses on a collective basis by considering the age of each outstanding invoice, each customer’s expected ability to pay and collection history, current market conditions, and reasonable and supportable forecasts of future economic conditions. Accounts receivable deemed uncollectible are charged against the allowance for credit losses. For the years ended July 31, 2022 and 2021, the allowance for credit losses activity was not significant.

[0001327567-22-000028:notes:34]
Financing Receivables

[0001327567-22-000028:notes:35]
We provide financing arrangements for certain qualified end-user customers to purchase our products and services. Payment terms on these financing arrangements are up to five years. Financing receivables are recorded at amortized cost, which approximates fair value. We may sell, in certain instances, these financing arrangements on a non-recourse basis to third party financial institutions. The financing receivables are derecognized upon transfer as these sales qualify as true sales.

[0001327567-22-000028:notes:36]
We evaluate the allowance for credit losses by assessing the risks and losses inherent in our financing receivables on either an individual or a collective basis. Our assessment considers various factors, including lifetime expected losses determined using customer risk profile, current economic conditions that may affect a customer’s ability to pay, and forward-looking economic considerations. Financing receivables deemed uncollectible are charged against the allowance for credit losses. Short-term financing receivables are included in prepaid expenses and other current assets, and long-term financing receivables are included in other assets on our consolidated balance sheets.

[0001327567-22-000028:notes:37]
Derivatives

[0001327567-22-000028:notes:38]
We are exposed to foreign currency exchange risk. Substantially all of our revenue is transacted in U.S. dollars, however, a portion of our operating expenditures are incurred outside of the United States and are denominated in foreign currencies, making them subject to fluctuations in foreign currency exchange rates. We enter into foreign currency derivative contracts with maturities of 16 months or less, which we designate as cash flow hedges, to manage the foreign currency exchange risk associated with our operating expenditures.

[0001327567-22-000028:notes:39]
Our derivative financial instruments are recorded at fair value, on a gross basis, as either assets or liabilities on our consolidated balance sheets. Gains or losses related to our cash flow hedges are recorded as a component of AOCI on our consolidated balance sheets and are reclassified into the financial statement line item associated with the underlying hedged transaction in our consolidated statements of operations when the underlying hedged transaction is recognized in earnings. Gains or losses related to non-designated derivative instruments are recognized in other income, net in our consolidated statements of operations for each period until the instrument matures, is terminated, is re-designated as a qualified cash flow hedge, or is sold. Derivatives designated as cash flow hedges are classified in our consolidated statements of cash flows in the same manner as the underlying hedged transaction, primarily within cash flows from operating activities.

[0001327567-22-000028:notes:40]
Property and Equipment

[0001327567-22-000028:notes:41]
Property and equipment are stated at cost, less accumulated depreciation. Depreciation is computed using the straight-line method over the estimated useful lives of the assets, generally three to ten years. Leasehold improvements are depreciated over the shorter of the estimated useful lives of the improvements or the remaining lease term. Land is not depreciated.

[0001327567-22-000028:notes:42]
Business Combinations

[0001327567-22-000028:notes:43]
We include the results of operations of the businesses that we acquire as of the respective dates of acquisition. We allocate the fair value of the purchase price of our acquisitions to the assets acquired and liabilities assumed, generally based on their estimated fair values. The excess of the purchase price over the fair values of these identifiable assets and liabilities is recorded as goodwill. Additional information existing as of the acquisition date but unknown to us may become known during the remainder of the measurement period, not to exceed 12 months from the acquisition date, which may result in changes to the amounts and allocations recorded.

[0001327567-22-000028:notes:44]
Intangible Assets

[0001327567-22-000028:notes:45]
Purchased intangible assets with finite lives are carried at cost, less accumulated amortization. Amortization is computed over the estimated useful lives of the respective assets. Acquisition-related in-process research and development represents the fair value of incomplete research and development projects that have not reached technological feasibility as of the date of acquisition. Initially, these assets are not subject to amortization. Assets related to projects that have been completed are transferred to developed technology, which are subject to amortization.

[0001327567-22-000028:notes:46]
Impairment of Goodwill, Intangible Assets, and Other Long-Lived Assets

[0001327567-22-000028:notes:47]
Goodwill is evaluated for impairment on an annual basis in the fourth quarter of our fiscal year, and whenever events or changes in circumstances indicate the carrying amount of goodwill may not be recoverable. We have elected to first assess qualitative factors to determine whether it is more likely than not that the fair value of our single reporting unit is less than its carrying amount, including goodwill. If we determine that it is more likely than not that the fair value is less than its carrying amount, then the quantitative impairment test will be performed. Under the quantitative impairment test, if the carrying amount exceeds its fair value, we will recognize an impairment loss in an amount equal to that excess but limited to the total amount of goodwill.

[0001327567-22-000028:notes:48]
We evaluate events and changes in circumstances that could indicate carrying amounts of purchased intangible assets and other long-lived assets may not be recoverable. When such events or changes in circumstances occur, we assess the recoverability of these assets or asset groups by determining whether or not the carrying amount will be recovered through undiscounted expected future cash flows. If the total of the future undiscounted cash flows is less than the carrying amount of an asset or asset group, we record an impairment loss for the amount by which the carrying amount exceeds the fair value of the asset or asset group.

[0001327567-22-000028:notes:49]
We did not recognize any impairment losses on our goodwill, intangible assets, or other long-lived assets during the years ended July 31, 2022, 2021, and 2020.

[0001327567-22-000028:notes:50]
Manufacturing Partner and Supplier Liabilities

[0001327567-22-000028:notes:51]
We outsource most of our manufacturing, repair, and supply chain management operations to our EMS provider and payments to it are a significant portion of our cost of product revenue. Although we are contractually obligated to purchase manufactured products and components, we generally do not own the components and manufactured products. Product title transfers from our EMS provider to us and immediately to our customers upon shipment. Our EMS provider assembles our products using design specifications, quality assurance programs, and standards that we establish, and it procures components and assembles products based on our demand forecasts. These forecasts represent our estimates of future demand for our products based upon historical trends and analysis from our sales and product management functions as adjusted for overall market conditions. If the actual component usage and product demand are significantly lower than forecast, we record a liability for manufacturing purchase commitments in excess of our forecasted demand including costs for excess components or for carrying costs incurred by our manufacturing partners and component suppliers. Through July 31, 2022, we have not accrued any significant costs associated with this exposure.

[0001327567-22-000028:notes:52]
Convertible Senior Notes

[0001327567-22-000028:notes:53]
Prior to August 1, 2021, our convertible senior notes were separated into a liability and an equity component. The carrying amount of the liability component was calculated by measuring the fair value of a similar liability that did not have an associated convertible feature, using a discounted cash flow model with a risk-adjusted yield. The carrying amount of the equity component representing the conversion option was determined by deducting the fair value of the liability component from the par value of the notes as a whole. This difference represented a debt discount that was amortized to interest expense using the effective interest method over the term of the notes. The equity component was not remeasured as it continued to meet the conditions for equity classification. Transaction costs related to the issuance of the notes were allocated to the liability and equity components using the same proportions as the proceeds from the notes. Transaction costs attributable to the liability component were netted with the liability component and amortized to interest expense using the effective interest method over the term of the notes. Transaction costs attributable to the equity component were netted with the equity component of the notes in additional paid-in capital. Upon the notes becoming convertible, the net carrying amount of the liability component was classified as a current liability and a portion of the equity component representing the conversion option was reclassified to temporary equity. The portion of the equity component classified as temporary equity was measured as the difference between the principal and net carrying amount of the notes, excluding debt issuance costs.

[0001327567-22-000028:notes:54]
Upon adoption of the new debt guidance on August 1, 2021, our convertible senior notes are accounted for entirely as a liability and measured at their amortized cost. Transaction costs related to the issuance of the notes are netted with the liability and are amortized on a straight-line basis, which approximates the effective interest rate method, to interest expense over the term of the notes.

[0001327567-22-000028:notes:55]
Revenue Recognition

[0001327567-22-000028:notes:56]
Our revenue consists of product revenue and subscription and support revenue. Revenue is recognized when control of promised products, subscriptions and support services are transferred to customers, in an amount that reflects the expected consideration in exchange for those products and services.

[0001327567-22-000028:notes:57]
We determine revenue recognition through the following steps:

[0001327567-22-000028:notes:58]
•Identification of the contract, or contracts, with a customer.

[0001327567-22-000028:notes:59]
•Identification of the performance obligations in the contract.

[0001327567-22-000028:notes:60]
•Determination of the transaction price.

[0001327567-22-000028:notes:61]
•Allocation of the transaction price to the performance obligations in the contract.

[0001327567-22-000028:notes:62]
•Recognition of revenue when, or as, we satisfy a performance obligation.

[0001327567-22-000028:notes:63]
Revenues are reported net of sales taxes. Shipping charges billed to our customers are included in revenues and related costs are included in cost of revenue.

[0001327567-22-000028:notes:64]
Product Revenue

[0001327567-22-000028:notes:65]
Product revenue is derived primarily from sales of our appliances. Product revenue also includes revenue derived from software licenses of Panorama and the VM-Series. Our appliances and software licenses include a broad set of built-in networking and security features and functionalities. We recognize product revenue at the time of hardware shipment or delivery of software license.

[0001327567-22-000028:notes:66]
Subscription and Support Revenue

[0001327567-22-000028:notes:67]
Subscription and support revenue is derived primarily from sales of our subscription and support offerings. We recognize subscription and support revenue over time as the services are performed. Our contractual subscription and support contracts are typically one to five years.

[0001327567-22-000028:notes:68]
Contracts with Multiple Performance Obligations

[0001327567-22-000028:notes:69]
The majority of our contracts with our customers include various combinations of our products and subscriptions and support. Our appliances and software licenses have significant standalone functionalities and capabilities. Accordingly, these appliances and software licenses are distinct from our subscriptions and support services as the customer can benefit from the product without these services and such services are separately identifiable within the contract. We account for multiple agreements with a single customer as a single contract if the contractual terms and/or substance of those agreements indicate that they may be so closely related that they are, in effect, parts of a single contract. The amount of consideration we expect to receive in exchange for delivering on the contract is allocated to each performance obligation based on its relative standalone selling price. If a contract contains a single performance obligation, no allocation is required.

[0001327567-22-000028:notes:70]
We establish standalone selling price using the prices charged for a deliverable when sold separately. If the standalone selling price is not observable through past transactions, we estimate the standalone selling price based on our pricing model and our go-to-market strategy, which include factors such as type of sales channel (reseller, distributor, or end-customer), the geographies in which our offerings were sold (domestic or international), and offering type (products, subscriptions, or support).

[0001327567-22-000028:notes:71]
Deferred Revenue

[0001327567-22-000028:notes:72]
We record deferred revenue when cash payments are received or due in advance of our performance. Our payment terms typically require payment within 30 to 45 days of the date we issue an invoice. The current portion of deferred revenue represents the amounts that are expected to be recognized as revenue within one year of the consolidated balance sheet date.

[0001327567-22-000028:notes:73]
Deferred Contract Costs

[0001327567-22-000028:notes:74]
We defer contract costs that are recoverable and incremental to obtaining customer sales contracts. Contract costs, which primarily consist of sales commissions, are amortized on a systematic basis that is consistent with the transfer to the customer of the goods or services to which the asset relates. Sales commissions paid for initial contracts are generally not commensurate with the commissions paid for renewal contracts, given the substantive difference in commission rates in proportion to their respective contract values. Sales commissions for initial contracts that are not commensurate are amortized over a benefit period of five years, consistent with the revenue recognition pattern of the performance obligations in the related contracts including expected renewals. The benefit period is determined by taking into consideration contract length, technology life, and other quantitative and qualitative factors. The expected renewals are estimated based on historical renewal trends. Sales commissions for initial contracts that are commensurate and sales commissions for renewal contracts are amortized over the related contractual period in proportion to the revenue recognized.

[0001327567-22-000028:notes:75]
We classify deferred contract costs as short-term or long-term based on when we expect to recognize the expense. The amortization of deferred contract costs is included in sales and marketing expense in our consolidated statements of operations. Deferred contract costs are periodically reviewed for impairment. We did not recognize any impairment losses on our deferred contract costs during the years ended July 31, 2022, 2021, or 2020.

[0001327567-22-000028:notes:76]
Software Development Costs

[0001327567-22-000028:notes:77]
Internally developed software includes security software developed to meet our internal needs to provide cloud-based subscription offerings to our end-customers and business software that we customize to meet our specific operational needs. These capitalized costs consist of internal compensation related costs and external direct costs incurred during the application development stage and will be amortized over a useful life of three to five years. As of July 31, 2022 and 2021, we capitalized as other assets on our consolidated balance sheets $130.9 million and $114.8 million in costs, respectively, net of accumulated amortization, for security software developed to meet our internal needs to provide our cloud-based subscription offerings. We recognized amortization expense of $62.4 million, $47.8 million, and $31.3 million related to these capitalized costs as cost of subscription and support revenue in our consolidated statements of operations during the years ended July 31, 2022, 2021, and 2020, respectively.

[0001327567-22-000028:notes:78]
The costs to develop software that is marketed externally have not been capitalized as we believe our current software development process is essentially completed concurrent with the establishment of technological feasibility. As such, all related software development costs are expensed as incurred and included in research and development expense in our consolidated statements of operations.

[0001327567-22-000028:notes:79]
Share-Based Compensation

[0001327567-22-000028:notes:80]
Compensation expense related to share-based transactions is measured and recognized in the consolidated financial statements based on fair value on the grant date. We recognize share-based compensation expense for awards with only service conditions on a straight-line basis over the requisite service period of the related award. We recognize share-based compensation expense for awards with market conditions and awards with performance conditions on a straight-line basis over the requisite service period for each separately vesting portion of the award and, for awards with performance conditions, when it is probable that the performance condition will be achieved. We account for forfeitures of all share-based payment awards when they occur.

[0001327567-22-000028:notes:81]
Leases

[0001327567-22-000028:notes:82]
We determine if an arrangement is a lease at inception. We evaluate the classification of leases at commencement and, as necessary, at modification. Operating leases related balances are included in operating lease right-of-use assets, accrued and other liabilities, and long-term operating lease liabilities on our consolidated balance sheets. We did not have any material finance leases in any of the periods presented.

[0001327567-22-000028:notes:83]
Operating lease right-of-use assets represent our right to use an underlying asset for the lease term. Operating lease liabilities represent our obligation to make payments arising from the lease. Operating lease right-of-use assets and liabilities are recognized at the present value of the future lease payments at the lease commencement date. The interest rate used to determine the present value of the future lease payments is our incremental borrowing rate, because the interest rates implicit in most of our leases are not readily determinable. Our incremental borrowing rate is estimated to approximate the interest rate on a collateralized basis with similar terms and payments, and in economic environments where the leased asset is located. Operating lease right-of-use assets also include adjustments related to lease incentives, prepaid or accrued rent and initial direct lease costs. Operating lease right-of-use assets are subject to evaluation for impairment or disposal on a basis consistent with other long-lived assets.

[0001327567-22-000028:notes:84]
Our lease terms may include periods under options to extend or terminate the lease when it is reasonably certain that we will exercise that option. We generally use the base, non-cancelable lease term when determining the lease assets and liabilities. Operating lease cost is recognized on a straight-line basis over the lease term.

[0001327567-22-000028:notes:85]
We account for lease and non-lease components as a single lease component and do not recognize right-of-use assets and lease liabilities for leases with a term of 12 months or less. Payments under our lease arrangements are primarily fixed, however, certain lease agreements contain variable payments, which are expensed as incurred and not included in the operating lease right-of-use assets and liabilities. Variable lease payments are primarily comprised of real estate taxes, common area maintenance charges, and insurance costs.

[0001327567-22-000028:notes:86]
Income Taxes

[0001327567-22-000028:notes:87]
We account for income taxes using the asset and liability method, which requires the recognition of deferred tax assets and liabilities for the expected future tax consequences of events that have been recognized in our consolidated financial statements or tax returns. In addition, deferred tax assets are recorded for the future benefit of utilizing net operating losses and research and development credit carryforwards. Valuation allowances are provided when necessary to reduce deferred tax assets to the amount expected to be realized.

[0001327567-22-000028:notes:88]
Significant judgment is required in determining any valuation allowance recorded against deferred tax assets. In assessing the need for a valuation allowance, we consider all available evidence, including past operating results, estimates of future taxable income, and the feasibility of tax planning strategies. In the event that we change our determination as to the amount of deferred tax assets that can be realized, we will adjust our valuation allowance with a corresponding impact to the provision for income taxes in the period in which such determination is made.

[0001327567-22-000028:notes:89]
We recognize liabilities for uncertain tax positions based on a two-step process. The first step is to evaluate the tax position for recognition by determining if the weight of available evidence indicates that it is more likely than not that the position will be sustained on audit, including resolution of related appeals or litigation processes, if any. The second step requires us to estimate and measure the tax benefit as the largest amount that is more likely than not to be realized upon ultimate settlement.

[0001327567-22-000028:notes:90]
Loss Contingencies

[0001327567-22-000028:notes:91]
We are subject to the possibility of various loss contingencies arising in the ordinary course of business. In determining loss contingencies, we consider the likelihood of loss or impairment of an asset, or the incurrence of a liability, as well as our ability to reasonably estimate the amount of loss. An estimated loss contingency is accrued when it is probable that an asset has been impaired, or a liability has been incurred and the amount of loss can be reasonably estimated. If we determine that a loss is possible and the range of the loss can be reasonably determined, then we disclose the range of the possible loss. We regularly evaluate current information available to us to determine whether an accrual is required, an accrual should be adjusted, or a range of possible loss should be disclosed.

[0001327567-22-000028:notes:92]
Recently Adopted Accounting Pronouncements

[0001327567-22-000028:notes:93]
Acquired Contract Assets and Contract Liabilities

[0001327567-22-000028:notes:94]
In October 2021, the Financial Accounting Standards Board (“FASB”) issued authoritative guidance that requires companies to apply revenue guidance to recognize and measure contract assets and contract liabilities from contracts with customers acquired in a business combination on the acquisition date, instead of measuring them at fair value. We early adopted this guidance in our first quarter of fiscal 2022 on a prospective basis. The adoption of this standard did not have a material impact on our consolidated financial statements.

[0001327567-22-000028:notes:95]
Debt with Conversion Options

[0001327567-22-000028:notes:96]
In August 2020, the FASB issued authoritative guidance that simplifies the accounting for certain financial instruments with characteristics of liabilities and equity, including convertible instruments. The standard reduces the number of models used to account for convertible instruments and simplifies the classification of debt on the balance sheet.

[0001327567-22-000028:notes:97]
We adopted this standard in our first quarter of fiscal 2022 using the modified-retrospective approach, under which financial results reported in periods prior to fiscal 2022 were not adjusted. The adoption of this standard resulted in an increase to convertible senior notes, net of $444.3 million, a decrease to accumulated deficit of $266.7 million, and a decrease to additional paid-in capital and temporary equity of $711.0 million upon adoption.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001327567-22-000028:notes:98]
Revenue 
Disaggregation of Revenue

[0001327567-22-000028:notes:99]
The following table presents revenue by geographic theater (in millions):

[0001327567-22-000028:notes:100]
|  | Year Ended July 31, |
|  | 2022 |  | 2021 |  | 2020 |
| Revenue: |  |  |  |  |  |
| Americas |  |  |  |  |  |
| United States | $ | 3,560.3 |  |  | $ | 2,747.8 |  |  | $ | 2,157.6 |  |
| Other Americas | 242.3 |  |  | 189.7 |  |  | 160.4 |  |
| Total Americas | 3,802.6 |  |  | 2,937.5 |  |  | 2,318.0 |  |
| Europe, the Middle East, and Africa (“EMEA”) | 1,055.8 |  |  | 817.3 |  |  | 671.9 |  |
| Asia Pacific and Japan (“APAC”) | 643.1 |  |  | 501.3 |  |  | 418.5 |  |
| Total revenue | $ | 5,501.5 |  |  | $ | 4,256.1 |  |  | $ | 3,408.4 |  |

[0001327567-22-000028:notes:101]
The following table presents revenue for groups of similar products and services (in millions):

[0001327567-22-000028:notes:102]
|  | Year Ended July 31, |
|  | 2022 |  | 2021 |  | 2020 |
| Revenue: |  |  |  |  |  |
| Product | $ | 1,363.1 |  |  | $ | 1,120.3 |  |  | $ | 1,064.2 |  |
| Subscription and support |  |  |  |  |  |
| Subscription | 2,539.0 |  |  | 1,898.8 |  |  | 1405.3 |
| Support | 1,599.4 |  |  | 1,237.0 |  |  | 938.9 |
| Total subscription and support | 4,138.4 |  |  | 3,135.8 |  |  | 2,344.2 |  |
| Total revenue | $ | 5,501.5 |  |  | $ | 4,256.1 |  |  | $ | 3,408.4 |  |

[0001327567-22-000028:notes:103]
During the years ended July 31, 2022 and 2021, we recognized approximately $2.7 billion and $2.0 billion of revenue pertaining to amounts that were deferred as of July 31, 2021 and 2020, respectively.

[0001327567-22-000028:notes:104]
Remaining Performance Obligations

[0001327567-22-000028:notes:105]
Revenue expected to be recognized from remaining performance obligations was $8.2 billion as of July 31, 2022, of which we expect to recognize approximately $4.1 billion over the next 12 months and the remainder thereafter.


## us-gaap:FairValueDisclosuresTextBlock

[0001327567-22-000028:notes:106]
Fair Value Measurements The following table presents our financial assets and liabilities measured at fair value on a recurring basis as of July 31, 2022 and 2021 (in millions):

[0001327567-22-000028:notes:107]
|  |  | July 31, 2022 |  | July 31, 2021 |
|  |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Cash equivalents: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 1,205.2 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,205.2 |  |  | $ | 124.2 |  |  | $ | — |  |  | $ | — |  |  | $ | 124.2 |  |
| Certificates of deposit |  | — |  |  | 155.3 |  |  | — |  |  | 155.3 |  |  | — |  |  | 150.4 |  |  | — |  |  | 150.4 |  |
| Commercial paper |  | — |  |  | 69.1 |  |  | — |  |  | 69.1 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Corporate debt securities |  | — |  |  | 19.5 |  |  | — |  |  | 19.5 |  |  | — |  |  | 1.0 |  |  | — |  |  | 1.0 |  |
| U.S. government and agency securities |  | — |  |  | 10.0 |  |  | — |  |  | 10.0 |  |  | — |  |  | 116.3 |  |  | — |  |  | 116.3 |  |
| Non-U.S. government and agency securities |  | — |  |  | 5.1 |  |  | — |  |  | 5.1 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Total cash equivalents |  | 1,205.2 |  |  | 259.0 |  |  | — |  |  | 1,464.2 |  |  | 124.2 |  |  | 267.7 |  |  | — |  |  | 391.9 |  |
| Short-term investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Certificates of deposit |  | — |  |  | 116.4 |  |  | — |  |  | 116.4 |  |  | — |  |  | 12.4 |  |  | — |  |  | 12.4 |  |
| Commercial paper |  | — |  |  | 79.0 |  |  | — |  |  | 79.0 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Corporate debt securities |  | — |  |  | 505.0 |  |  | — |  |  | 505.0 |  |  | — |  |  | 208.9 |  |  | — |  |  | 208.9 |  |
| U.S. government and agency securities |  | — |  |  | 798.2 |  |  | — |  |  | 798.2 |  |  | — |  |  | 762.1 |  |  | — |  |  | 762.1 |  |
| Non-U.S. government and agency securities |  | — |  |  | 17.4 |  |  | — |  |  | 17.4 |  |  | — |  |  | 43.5 |  |  | — |  |  | 43.5 |  |
| Total short-term investments |  | — |  |  | 1,516.0 |  |  | — |  |  | 1,516.0 |  |  | — |  |  | 1,026.9 |  |  | — |  |  | 1,026.9 |  |
| Long-term investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Certificates of deposit |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 5.0 |  |  | — |  |  | 5.0 |  |
| Corporate debt securities |  | — |  |  | 761.2 |  |  | — |  |  | 761.2 |  |  | — |  |  | 180.7 |  |  | — |  |  | 180.7 |  |
| U.S. government and agency securities |  | — |  |  | 118.2 |  |  | — |  |  | 118.2 |  |  | — |  |  | 674.1 |  |  | — |  |  | 674.1 |  |
| Non-U.S. government and agency securities |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 28.5 |  |  | — |  |  | 28.5 |  |
| Asset-backed securities |  | — |  |  | 172.5 |  |  | — |  |  | 172.5 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Total long-term investments |  | — |  |  | 1,051.9 |  |  | — |  |  | 1,051.9 |  |  | — |  |  | 888.3 |  |  | — |  |  | 888.3 |  |
| Prepaid expenses and other current assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency forward contracts |  | — |  |  | 2.4 |  |  | — |  |  | 2.4 |  |  | — |  |  | 4.1 |  |  | — |  |  | 4.1 |  |
| Total prepaid expenses and other current assets |  | — |  |  | 2.4 |  |  | — |  |  | 2.4 |  |  | — |  |  | 4.1 |  |  | — |  |  | 4.1 |  |
| Other assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency forward contracts |  | — |  |  | 0.7 |  |  | — |  |  | 0.7 |  |  | — |  |  | 0.1 |  |  | — |  |  | 0.1 |  |
| Total other assets |  | — |  |  | 0.7 |  |  | — |  |  | 0.7 |  |  | — |  |  | 0.1 |  |  | — |  |  | 0.1 |  |
| Total assets measured at fair value |  | $ | 1,205.2 |  |  | $ | 2,830.0 |  |  | $ | — |  |  | $ | 4,035.2 |  |  | $ | 124.2 |  |  | $ | 2,187.1 |  |  | $ | — |  |  | $ | 2,311.3 |  |

[0001327567-22-000028:notes:108]
|  |  | July 31, 2022 |  | July 31, 2021 |
|  |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Accrued and other liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency forward contracts |  | $ | — |  |  | $ | 32.4 |  |  | $ | — |  |  | $ | 32.4 |  |  | $ | — |  |  | $ | 6.4 |  |  | $ | — |  |  | $ | 6.4 |  |
| Total accrued and other liabilities |  | — |  |  | 32.4 |  |  | — |  |  | 32.4 |  |  | — |  |  | 6.4 |  |  | — |  |  | 6.4 |  |
| Other long-term liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency forward contracts |  | — |  |  | 0.8 |  |  | — |  |  | 0.8 |  |  | — |  |  | 0.5 |  |  | — |  |  | 0.5 |  |
| Total other long-term liabilities |  | — |  |  | 0.8 |  |  | — |  |  | 0.8 |  |  | — |  |  | 0.5 |  |  | — |  |  | 0.5 |  |
| Total liabilities measured at fair value |  | $ | — |  |  | $ | 33.2 |  |  | $ | — |  |  | $ | 33.2 |  |  | $ | — |  |  | $ | 6.9 |  |  | $ | — |  |  | $ | 6.9 |  |

[0001327567-22-000028:notes:109]
Refer to Note 10. Debt, for the carrying amount and estimated fair value of our convertible senior notes as of July 31, 2022 and 2021.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001327567-22-000028:notes:110]
Cash Equivalents and Investments
Available-for-sale Debt Securities

[0001327567-22-000028:notes:111]
The following tables summarize the amortized cost, unrealized gains and losses, and fair value of our available-for-sale debt securities (in millions):

[0001327567-22-000028:notes:112]
|  | July 31, 2022 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 155.3 |  |  | $ | — |  |  | $ | — |  |  | $ | 155.3 |  |
| Commercial paper | 69.1 |  |  | — |  |  | — |  |  | 69.1 |  |
| Corporate debt securities | 19.5 |  |  | — |  |  | — |  |  | 19.5 |  |
| U.S. government and agency securities | 10.0 |  |  | — |  |  | — |  |  | 10.0 |  |
| Non-U.S. government and agency securities | 5.0 |  |  | 0.1 |  |  | — |  |  | 5.1 |  |
| Total available-for-sale cash equivalents | $ | 258.9 |  |  | $ | 0.1 |  |  | $ | — |  |  | $ | 259.0 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 116.5 |  |  | $ | — |  |  | $ | (0.1) |  |  | $ | 116.4 |  |
| Commercial paper | 79.1 |  |  | — |  |  | (0.1) |  |  | 79.0 |  |
| Corporate debt securities | 1,276.8 |  |  | 1.3 |  |  | (11.9) |  |  | 1,266.2 |  |
| U.S. government and agency securities | 928.1 |  |  | 0.1 |  |  | (11.8) |  |  | 916.4 |  |
| Non-U.S. government and agency securities | 17.6 |  |  | — |  |  | (0.2) |  |  | 17.4 |  |
| Asset-backed securities | 173.4 |  |  | 0.2 |  |  | (1.1) |  |  | 172.5 |  |
| Total available-for-sale investments | $ | 2,591.5 |  |  | $ | 1.6 |  |  | $ | (25.2) |  |  | $ | 2,567.9 |  |

[0001327567-22-000028:notes:113]
|  | July 31, 2021 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 150.4 |  |  | $ | — |  |  | $ | — |  |  | $ | 150.4 |  |
| Corporate debt securities | 1.0 |  |  | — |  |  | — |  |  | 1.0 |  |
| U.S. government and agency securities | 116.3 |  |  | — |  |  | — |  |  | 116.3 |  |
| Total available-for-sale cash equivalents | $ | 267.7 |  |  | $ | — |  |  | $ | — |  |  | $ | 267.7 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 17.4 |  |  | $ | — |  |  | $ | — |  |  | $ | 17.4 |  |
| Corporate debt securities | 389.2 |  |  | 0.5 |  |  | (0.1) |  |  | 389.6 |  |
| U.S. government and agency securities | 1,435.1 |  |  | 1.1 |  |  | — |  |  | 1,436.2 |  |
| Non-U.S. government and agency securities | 72.0 |  | — |  | — |  |  | 72.0 |
| Total available-for-sale investments | $ | 1,913.7 |  |  | $ | 1.6 |  |  | $ | (0.1) |  |  | $ | 1,915.2 |  |

[0001327567-22-000028:notes:114]
As of July 31, 2022, the gross unrealized losses that have been in a continuous unrealized loss position for less than 12 months were $24.8 million, which were related to $2.0 billion of available-for-sale debt securities, and the gross unrealized losses that have been in a continuous unrealized loss position for more than 12 months were not material. The gross unrealized losses on our available-for-sale debt securities as of July 31, 2021 were not material.

[0001327567-22-000028:notes:115]
Unrealized losses related to our available-for-sale debt securities are due to interest rate fluctuations as opposed to credit quality. We do not intend to sell any of the securities in an unrealized loss position and it is not likely that we would be required to sell these securities before recovery of their amortized cost basis, which may be at maturity. We did not recognize any credit losses related to our available-for-sale debt securities during the years ended July 31, 2022 and 2021.

[0001327567-22-000028:notes:116]
The following table summarizes the amortized cost and fair value of our available-for-sale debt securities as of July 31, 2022, by contractual years-to-maturity (in millions):

[0001327567-22-000028:notes:117]
|  | Amortized Cost |  | Fair Value |
| Due within one year | $ | 1,789.4 |  |  | $ | 1,775.0 |  |
| Due between one and three years | 965.2 |  |  | 956.4 |  |
| Due between three to five years | 91.5 |  |  | 91.2 |  |
| Due between five to ten years | 4.3 |  |  | 4.3 |  |
| Total | $ | 2,850.4 |  |  | $ | 2,826.9 |  |

[0001327567-22-000028:notes:118]
Marketable Equity Securities

[0001327567-22-000028:notes:119]
Marketable equity securities consist of money market funds and are included in cash and cash equivalents on our consolidated balance sheets. As of July 31, 2022 and 2021, the carrying value of our marketable equity securities were $1.2 billion and $124.2 million, respectively. There were no unrealized gains or losses recognized for these securities during the years ended July 31, 2022, 2021, and 2020.


## us-gaap:FinancingReceivablesTextBlock

[0001327567-22-000028:notes:120]
Financing Receivables
The following table summarizes our short-term and long-term financing receivables (in millions):

[0001327567-22-000028:notes:121]
|  | July 31, |
|  | 2022 |  | 2021 |
| Short-term financing receivables, gross | $ | 112.6 |  |  | $ | 80.0 |  |
| Allowance for credit losses | (1.3) |  |  | (1.0) |  |
| Short-term financing receivables, net | $ | 111.3 |  |  | $ | 79.0 |  |
| Long-term financing receivables, gross | $ | 194.6 |  |  | $ | 198.6 |  |
| Allowance for credit losses | (2.5) |  |  | (4.3) |  |
| Long-term financing receivables, net | $ | 192.1 |  |  | $ | 194.3 |  |

[0001327567-22-000028:notes:122]
There was no significant activity in allowance for credit losses during the years ended July 31, 2022 and 2021. Past due amounts on financing receivables were not material as of July 31, 2022 and 2021.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001327567-22-000028:notes:123]
Derivative Instruments
As of July 31, 2022 and 2021, the total notional amount of our outstanding foreign currency forward contracts was $856.9 million and $531.9 million, respectively. Refer to Note 3. Fair Value Measurements for the fair value of our derivative instruments as reported on our consolidated balance sheets as of July 31, 2022.

[0001327567-22-000028:notes:124]
As of July 31, 2022, unrealized losses in AOCI related to our cash flow hedges were $24.8 million, of which $22.0 million of losses are expected to be recognized into earnings within the next 12 months. As of July 31, 2021, unrealized gains and losses in AOCI related to our cash flow hedges were not material.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001327567-22-000028:notes:125]
Acquisitions
Fiscal 2022

[0001327567-22-000028:notes:126]
During the year ended July 31, 2022, we completed acquisitions for a combined total purchase consideration of $40.1 million, which was primarily cash. We have accounted for these transactions as business combinations, and recorded goodwill of $37.6 million. The goodwill is not deductible for income tax purposes.

[0001327567-22-000028:notes:127]
Fiscal 2021

[0001327567-22-000028:notes:128]
Bridgecrew Inc.

[0001327567-22-000028:notes:129]
On March 2, 2021, we completed our acquisition of Bridgecrew Inc. (“Bridgecrew”), a privately-held cloud security company. We expect the acquisition will expand our Prisma Cloud offering to deliver security across the full application lifecycle. The total purchase consideration for the acquisition of Bridgecrew was $156.9 million, which consisted of the following (in millions):

[0001327567-22-000028:notes:130]
|  | Amount |
| Cash | $ | 155.9 |  |
| Fair value of replacement awards | 1.0 |  |
| Total | $ | 156.9 |  |

[0001327567-22-000028:notes:131]
As part of the acquisition, we issued $42.5 million of replacement awards, of which the portion attributable to services performed prior to the acquisition date was allocated to purchase consideration. The remaining fair value was allocated to future services and will be expensed over the remaining service periods as share-based compensation.

[0001327567-22-000028:notes:132]
We have accounted for this transaction as a business combination and allocated the purchase consideration to assets acquired and liabilities assumed based on preliminary estimated fair values, as presented in the following table (in millions):

[0001327567-22-000028:notes:133]
|  | Amount |
| Goodwill | $ | 129.6 |  |
| Identified intangible assets | 21.6 |  |
| Cash | 9.0 |  |
| Net liabilities assumed | (3.3) |  |
| Total | $ | 156.9 |  |

[0001327567-22-000028:notes:134]
Goodwill generated from this business combination is primarily attributable to the assembled workforce and expected post-acquisition synergies from integrating Bridgecrew technology into our platforms. The goodwill is not deductible for income tax purposes.

[0001327567-22-000028:notes:135]
The following table presents details of the identified intangible asset acquired (in millions, except years):

[0001327567-22-000028:notes:136]
|  | Fair Value |  | Estimated Useful Life |
| Developed technology | $ | 21.6 |  |  | 6 years |

[0001327567-22-000028:notes:137]
Expanse Inc.

[0001327567-22-000028:notes:138]
On December 15, 2020, we completed our acquisition of Expanse Inc. (“Expanse”), a privately-held company specializing in attack surface management. We expect the acquisition will enrich our Cortex offerings and provide organizations an integrated view of the enterprise to combine external, internal, and threat data. The total purchase consideration for the acquisition of Expanse was $797.2 million, which consisted of the following (in millions):

[0001327567-22-000028:notes:139]
|  | Amount |
| Cash | $ | 434.9 |  |
| Common stock (1.1 million shares) | 340.7 |  |
| Fair value of replacement awards | 21.6 |  |
| Total | $ | 797.2 |  |

[0001327567-22-000028:notes:140]
As part of the acquisition, we issued replacement equity awards, which included 0.2 million shares of our restricted common stock. The total fair value of the replacement equity awards was $160.0 million, of which the portion attributable to services performed prior to the acquisition date was allocated to purchase consideration. The remaining fair value was allocated to future services and will be expensed over the remaining service periods as share-based compensation.

[0001327567-22-000028:notes:141]
|  | Amount |
| Goodwill | $ | 598.2 |  |
| Identified intangible assets | 160.3 |  |
| Cash | 51.1 |  |
| Net liabilities assumed | (12.4) |  |
| Total | $ | 797.2 |  |

[0001327567-22-000028:notes:142]
Goodwill generated from this business combination is primarily attributable to the assembled workforce and expected post-acquisition synergies from integrating Expanse technology into our platforms. The goodwill is not deductible for income tax purposes.

[0001327567-22-000028:notes:143]
The following table presents details of the identified intangible assets acquired (in millions, except years):

[0001327567-22-000028:notes:144]
|  | Fair Value |  | Estimated Useful Life |
| Developed technology | $ | 123.4 |  |  | 6 years |
| Customer relationships | 36.9 |  |  | 10 years |
| Total | $ | 160.3 |  |  |  |

[0001327567-22-000028:notes:145]
Sinefa Group, Inc.

[0001327567-22-000028:notes:146]
On November 24, 2020, we completed our acquisition of Sinefa Group, Inc. and its wholly owned subsidiaries (“Sinefa”), a privately-held digital experience monitoring company. We expect the acquisition will extend our Prisma Access offering. The total purchase consideration for the acquisition of Sinefa was $27.0 million, which consisted of the following (in millions):

[0001327567-22-000028:notes:147]
|  | Amount |
| Cash | $ | 26.9 |  |
| Fair value of replacement awards | 0.1 |  |
| Total | $ | 27.0 |  |

[0001327567-22-000028:notes:148]
As part of the acquisition, we issued $11.5 million of replacement equity awards, of which the portion attributable to services performed prior to the acquisition date was allocated to purchase consideration. The remaining fair value was allocated to future services and will be expensed over the remaining service periods as share-based compensation.

[0001327567-22-000028:notes:149]
|  | Amount |
| Goodwill | $ | 13.7 |  |
| Identified intangible assets | 20.4 |  |
| Net liabilities assumed | (7.1) |  |
| Total | $ | 27.0 |  |

[0001327567-22-000028:notes:150]
Goodwill generated from this business combination is primarily attributable to the assembled workforce and expected post-acquisition synergies from integrating Sinefa technology into our platforms. The goodwill is deductible for income tax purposes.

[0001327567-22-000028:notes:151]
|  | Fair Value |  | Estimated Useful Life |
| Developed technology | $ | 18.6 |  |  | 6 years |
| Customer relationships | 1.8 |  |  | 8 years |
| Total | $ | 20.4 |  |  |  |

[0001327567-22-000028:notes:152]
The Crypsis Group

[0001327567-22-000028:notes:153]
On September 17, 2020, we completed our acquisition of The Crypsis Group (“Crypsis”), an incident response, risk management, and digital forensics consulting firm. We expect the acquisition will expand our capabilities and strengthen our Cortex strategy. The total purchase consideration for the acquisition of Crypsis was $227.7 million, which consisted of the following (in millions):

[0001327567-22-000028:notes:154]
|  | Amount |
| Cash | $ | 225.7 |  |
| Fair value of replacement awards | 2.0 |  |
| Total | $ | 227.7 |  |

[0001327567-22-000028:notes:155]
As part of the acquisition, we issued $27.1 million of replacement awards, of which the portion attributable to services performed prior to the acquisition date was allocated to purchase consideration. The remaining fair value was allocated to future services and will be expensed over the remaining service periods as share-based compensation.

[0001327567-22-000028:notes:156]
|  | Amount |
| Goodwill | $ | 157.6 |  |
| Identified intangible assets | 54.4 |  |
| Net assets acquired | 15.7 |  |
| Total | $ | 227.7 |  |

[0001327567-22-000028:notes:157]
Goodwill generated from this business combination is primarily attributable to the assembled workforce and expected post-acquisition synergies from integrating Crypsis technology into our platforms. The goodwill is deductible for income tax purposes.

[0001327567-22-000028:notes:158]
|  | Fair Value |  | Estimated Useful Life |
| Developed technology | $ | 6.9 |  |  | 3 years |
| Customer relationships | 47.5 |  |  | 7 years |
| Total | $ | 54.4 |  |  |  |

[0001327567-22-000028:notes:159]
Fiscal 2020

[0001327567-22-000028:notes:160]
CloudGenix Inc.

[0001327567-22-000028:notes:161]
On April 21, 2020, we completed our acquisition of CloudGenix, Inc. (“CloudGenix”), a privately-held company. We believe the acquisition will strengthen our secure access service edge (“SASE”) offering. The total purchase consideration for the acquisition of CloudGenix was $402.7 million, which consisted of the following (in millions):

[0001327567-22-000028:notes:162]
|  | Amount |
| Cash | $ | 396.1 |  |
| Fair value of replacement awards | 6.6 |  |
| Total | $ | 402.7 |  |

[0001327567-22-000028:notes:163]
As part of the acquisition, we issued $30.3 million of replacement awards, of which the portion attributable to services performed prior to the acquisition date was allocated to purchase consideration. The remaining fair value was allocated to future services and will be expensed over the remaining service periods as share-based compensation.

[0001327567-22-000028:notes:164]
We have accounted for this transaction as a business combination and allocated the purchase consideration to assets acquired and liabilities assumed based on estimated fair values, as presented in the following table (in millions):

[0001327567-22-000028:notes:165]
|  | Amount |
| Goodwill | $ | 301.2 |  |
| Identified intangible assets | 109.9 |  |
| Cash | 8.3 |  |
| Net liabilities assumed | (16.7) |  |
| Total | $ | 402.7 |  |

[0001327567-22-000028:notes:166]
Goodwill generated from this business combination is primarily attributable to the assembled workforce and expected post-acquisition synergies from integrating CloudGenix technology into our portfolio. The goodwill is not deductible for income tax purposes.

[0001327567-22-000028:notes:167]
|  | Fair Value |  | Estimated Useful Life |
| Developed technology | $ | 67.2 |  |  | 5 years |
| Customer relationships | 42.7 |  |  | 10 years |
| Total | $ | 109.9 |  |  |  |

[0001327567-22-000028:notes:168]
Aporeto, Inc.

[0001327567-22-000028:notes:169]
On December 23, 2019, we completed our acquisition of Aporeto, Inc. (“Aporeto”), a privately-held machine identity-based microsegmentation company. We believe the acquisition will strengthen our cloud-native security platform capabilities delivered by Prisma Cloud. The total purchase consideration for the acquisition of Aporeto was $144.1 million, which consisted of the following (in millions):

[0001327567-22-000028:notes:170]
|  | Amount |
| Cash | $ | 139.8 |  |
| Fair value of replacement awards | 4.3 |  |
| Total | $ | 144.1 |  |

[0001327567-22-000028:notes:171]
As part of the acquisition, we issued $16.4 million of replacement awards, of which the portion attributable to services performed prior to the acquisition date was allocated to purchase consideration. The remaining fair value was allocated to future services and will be expensed over the remaining service periods as share-based compensation.

[0001327567-22-000028:notes:172]
|  | Amount |
| Goodwill | $ | 111.3 |  |
| Identified intangible assets | 23.8 |  |
| Cash | 10.5 |  |
| Net liabilities assumed | (1.5) |  |
| Total | $ | 144.1 |  |

[0001327567-22-000028:notes:173]
Goodwill generated from this business combination is primarily attributable to the assembled workforce and expected post-acquisition synergies from integrating Aporeto’s technology into our platform. The goodwill is not deductible for income tax purposes.

[0001327567-22-000028:notes:174]
|  | Fair Value |  | Estimated Useful Life |
| Developed technology | $ | 20.5 |  |  | 7 years |
| Customer relationships | 3.3 |  |  | 4 years |
| Total | $ | 23.8 |  |  |  |

[0001327567-22-000028:notes:175]
Zingbox, Inc.

[0001327567-22-000028:notes:176]
On September 20, 2019, we completed our acquisition of Zingbox, Inc. (“Zingbox”), a privately-held Internet of Things (“IoT”) security company. We believe the acquisition will accelerate our delivery of IoT security through our ML-Powered Next-Generation Firewall and Cortex offerings. The total purchase consideration for the acquisition of Zingbox was $66.4 million in cash.

[0001327567-22-000028:notes:177]
As part of the acquisition, we issued replacement equity awards with a total fair value of $5.7 million, which will be expensed over the remaining service periods as share-based compensation.

[0001327567-22-000028:notes:178]
|  | Amount |
| Goodwill | $ | 48.1 |  |
| Identified intangible assets | 20.4 |  |
| Net liabilities assumed | (2.1) |  |
| Total | $ | 66.4 |  |

[0001327567-22-000028:notes:179]
Goodwill generated from this business combination is primarily attributable to the assembled workforce and expected post-acquisition synergies from integrating Zingbox’s technology into our portfolio. The goodwill is not deductible for income tax purposes.

[0001327567-22-000028:notes:180]
|  | Fair Value |  | Estimated Useful Life |
| Developed technology | $ | 18.6 |  |  | 5 years |
| Customer relationships | 1.8 |  |  | 8 years |
| Total | $ | 20.4 |  |  |  |

[0001327567-22-000028:notes:181]
Additional Acquisition-Related Information

[0001327567-22-000028:notes:182]
Pro forma results of operations have not been presented because the effects of the acquisitions were not material to our consolidated statements of operations.

[0001327567-22-000028:notes:183]
Additional information related to our acquisitions completed in fiscal 2022, such as that related to income tax and other contingencies, existing as of the acquisition date but unknown to us may become known during the remainder of the measurement period, not to exceed 12 months from the respective acquisition date, which may result in changes to the amounts and allocations recorded.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001327567-22-000028:notes:184]
Goodwill and Intangible Assets
Goodwill

[0001327567-22-000028:notes:185]
The following table presents details of our goodwill during the year ended July 31, 2022 (in millions):

[0001327567-22-000028:notes:186]
|  | Amount |
| Balance as of July 31, 2021 | $ | 2,710.1 |  |
| Goodwill acquired | 37.6 |  |
| Balance as of July 31, 2022 | $ | 2,747.7 |  |

[0001327567-22-000028:notes:187]
Purchased Intangible Assets

[0001327567-22-000028:notes:188]
The following table presents details of our purchased intangible assets (in millions):

[0001327567-22-000028:notes:189]
|  | July 31, |
|  | 2022 |  | 2021 |
|  | Gross Carrying Amount |  | Accumulated Amortization |  | Net Carrying Amount |  | Gross Carrying Amount |  | Accumulated Amortization |  | Net Carrying Amount |
| Intangible assets subject to amortization: |  |  |  |  |  |  |  |  |  |  |  |
| Developed technology | $ | 600.7 |  |  | $ | (347.9) |  |  | $ | 252.8 |  |  | $ | 596.2 |  |  | $ | (243.8) |  |  | $ | 352.4 |  |
| Customer relationships | 172.7 |  |  | (52.2) |  |  | 120.5 |  |  | 172.7 |  |  | (30.6) |  |  | 142.1 |  |
| Acquired intellectual property | 11.3 |  |  | (4.8) |  |  | 6.5 |  |  | 7.9 |  |  | (3.8) |  |  | 4.1 |  |
| Trade name and trademarks | 9.4 |  |  | (9.4) |  |  | — |  |  | 9.4 |  |  | (9.4) |  |  | — |  |
| Other | 0.9 |  |  | (0.1) |  |  | 0.8 |  |  | 1.8 |  |  | (1.8) |  |  | — |  |
| Total intangible assets subject to amortization | 795.0 |  |  | (414.4) |  |  | 380.6 |  |  | 788.0 |  |  | (289.4) |  |  | 498.6 |  |
| Intangible assets not subject to amortization: |  |  |  |  |  |  |  |  |  |  |  |
| In-process research and development | 3.9 |  | — |  |  | 3.9 |  |  | — |  | — |  |  | — |  |
| Total purchased intangible assets | $ | 798.9 |  |  | $ | (414.4) |  |  | $ | 384.5 |  |  | $ | 788.0 |  |  | $ | (289.4) |  |  | $ | 498.6 |  |

[0001327567-22-000028:notes:190]
We recognized amortization expense of $126.9 million, $117.8 million, and $77.3 million for the years ended July 31, 2022, 2021, and 2020, respectively.

[0001327567-22-000028:notes:191]
The following table summarizes estimated future amortization expense of our intangible assets subject to amortization as of July 31, 2022 (in millions):

[0001327567-22-000028:notes:192]
|  |  |  | Fiscal years ending July 31, |
|  | Total |  | 2023 |  | 2024 |  | 2025 |  | 2026 |  | 2027 |  | 2028 and Thereafter |
| Future amortization expense | $ | 380.6 |  |  | $ | 101.1 |  |  | $ | 91.1 |  |  | $ | 77.4 |  |  | $ | 55.6 |  |  | $ | 28.5 |  |  | $ | 26.9 |  |


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001327567-22-000028:notes:193]
Property and EquipmentThe following table presents details of our property and equipment, net (in millions):

[0001327567-22-000028:notes:194]
|  | July 31, |
|  | 2022 |  | 2021 |
| Computers, equipment, and software | $ | 404.3 |  |  | $ | 352.1 |  |
| Leasehold improvements | 249.3 |  |  | 231.6 |  |
| Land | 87.2 |  |  | 49.6 |  |
| Demonstration units | 41.6 |  |  | 43.8 |  |
| Furniture and fixtures | 45.1 |  |  | 40.3 |  |
| Total property and equipment, gross | 827.5 |  |  | 717.4 |  |
| Less: accumulated depreciation | (469.7) |  |  | (399.0) |  |
| Total property and equipment, net | $ | 357.8 |  |  | $ | 318.4 |  |

[0001327567-22-000028:notes:195]
During the year ended July 31, 2022, we purchased 4.6 acres of land adjacent to our headquarters in Santa Clara, California, along with the associated buildings, for $39.5 million to accommodate future expansion of our headquarters. This amount was recorded in property and equipment, net on our consolidated balance sheet as of July 31, 2022.

[0001327567-22-000028:notes:196]
We recognized depreciation expense of $92.8 million, $94.2 million, and $96.0 million related to property and equipment during the years ended July 31, 2022, 2021, and 2020, respectively.


## us-gaap:DebtDisclosureTextBlock

[0001327567-22-000028:notes:197]
Debt
Convertible Senior Notes

[0001327567-22-000028:notes:198]
In July 2018, we issued $1.7 billion aggregate principal amount of 0.75% Convertible Senior Notes due 2023 (the “2023 Notes”) and, in June 2020, we issued $2.0 billion aggregate principal amount of 0.375% Convertible Senior Notes due 2025 (the “2025 Notes,” and together with the 2023 Notes, the “Notes”). The 2023 Notes bear interest at a fixed rate of 0.75% per year, payable semi-annually in arrears on January 1 and July 1 of each year, beginning on January 1, 2019. The 2025 Notes bear interest at a fixed rate of 0.375% per year, payable semi-annually in arrears on June 1 and December 1 of each year, beginning on December 1, 2020. Each series of the convertible notes is governed by an indenture between us, as the issuer, and U.S. Bank National Association, as Trustee (individually, each an “Indenture,” and together, the “Indentures”). The Notes of each series are unsecured, unsubordinated obligations and the applicable Indenture governing each series of Notes does not contain any financial covenants or restrictions on the payments of dividends, the incurrence of indebtedness, or the issuance or repurchase of securities by us or any of our subsidiaries. The 2023 Notes and the 2025 Notes mature on July 1, 2023 and June 1, 2025, respectively. We cannot redeem the 2023 Notes prior to maturity. We may redeem for cash all or any portion of the 2025 Notes, at our option, on or after June 5, 2023, and prior to the 31st scheduled trading day immediately preceding the maturity date if the last reported sale price of our common stock has been at least 130% of the conversion price then in effect for at least 20 trading days during any 30 consecutive trading day period ending on and including the trading day preceding the date on which we provide notice of redemption. The redemption will be at a price equal to 100% of the principal amount of the 2025 Notes and adjusted for interest. If we call any or all of the 2025 Notes for redemption, holders may convert such 2025 Notes called for redemption at any time prior to the close of business on the second scheduled trading day immediately preceding the redemption date.

[0001327567-22-000028:notes:199]
The following table presents details of our Notes (number of shares in millions):

[0001327567-22-000028:notes:200]
|  | Conversion Rate per $1,000 Principal |  | Initial Conversion Price |  | Convertible Date |  | Initial Number of Shares |
| 2023 Notes | 3.7545 |  |  | $ | 266.35 |  |  | April 1, 2023 |  | 6.4 |  |
| 2025 Notes | 3.3602 |  |  | $ | 297.60 |  |  | March 1, 2025 |  | 6.7 |  |

[0001327567-22-000028:notes:201]
Holders of the Notes may surrender their Notes for conversion at their option at any time prior to the close of business on the business day immediately preceding their respective convertible dates only under the following circumstances:

[0001327567-22-000028:notes:202]
•during any fiscal quarter commencing after the fiscal quarters ending on October 31, 2018 and October 31, 2020 for the 2023 Notes and the 2025 Notes, respectively (and only during such fiscal quarter), if the last reported sale price of our common stock for at least 20 trading days (whether or not consecutive) during a period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the applicable conversion price for the respective Notes on each applicable trading day (the “sale price condition”);

[0001327567-22-000028:notes:203]
•during the five business day period after any five consecutive trading day period (the “measurement period”) in which the trading price per $1,000 principal amount of the applicable series of Notes for each trading day of the measurement period was less than 98% of the product of the last reported sale price of our common stock and the applicable conversion rate for the respective Notes on each such trading day; or

[0001327567-22-000028:notes:204]
•upon the occurrence of specified corporate events.

[0001327567-22-000028:notes:205]
On or after the respective convertible date, holders may surrender all or any portion of their Notes for conversion at any time prior to the close of business on the second scheduled trading day immediately preceding the applicable maturity date regardless of the foregoing conditions, and such conversions will be settled upon the applicable maturity date. Upon conversion, holders of the Notes of a series will receive cash equal to the aggregate principal amount of the Notes of such series to be converted, and, at our election, cash and/or shares of our common stock for any amounts in excess of the aggregate principal amount of the Notes of such series being converted.

[0001327567-22-000028:notes:206]
The conversion price will be subject to adjustment in some events. Holders of the Notes of a series who convert their Notes of such series in connection with certain corporate events that constitute a “make-whole fundamental change” under the applicable Indenture are, under certain circumstances, entitled to an increase in the conversion rate for such series of Notes. Additionally, upon the occurrence of a corporate event that constitutes a “fundamental change” under the applicable Indenture, holders of the Notes of such series may require us to repurchase for cash all or a portion of the Notes of such series at a repurchase price equal to 100% of the principal amount of the Notes of such series plus accrued and unpaid interest to, but excluding, the fundamental change repurchase date.

[0001327567-22-000028:notes:207]
The sale price condition for the Notes was met during the fiscal quarter ended July 31, 2022, and as a result, holders may convert their Notes at any time during the fiscal quarter ending October 31, 2022. The net carrying amount of the Notes was classified as a current liability on our consolidated balance sheet as of July 31, 2022.

[0001327567-22-000028:notes:208]
The sale price condition for the 2023 Notes was met during the fiscal quarter ended July 31, 2021, and as a result, holders may convert their 2023 Notes at any time during the fiscal quarter ended October 31, 2021. Accordingly, the net carrying amount of the 2023 Notes was classified as a current liability and the portion of the equity component representing the conversion option was classified as temporary equity on our consolidated balance sheet as of July 31, 2021. The sale price condition for the 2025 Notes was not met during the fiscal quarter ended July 31, 2021. Since the 2025 Notes were not convertible during the fiscal quarter ended October 31, 2021, the associated net carrying amount was classified as a long-term liability and the equity component was included in additional paid-in capital on our consolidated balance sheet as of July 31, 2021.

[0001327567-22-000028:notes:209]
The following table sets forth the components of the Notes (in millions):

[0001327567-22-000028:notes:210]
|  | July 31, 2022(1) |  | July 31, 2021 |
|  | 2023 Notes |  | 2025 Notes |  | Total |  | 2023 Notes |  | 2025 Notes |  | Total |
| Liability component: |  |  |  |  |  |  |  |  |  |  |  |
| Principal | $ | 1,691.9 |  |  | $ | 1,999.4 |  |  | $ | 3,691.3 |  |  | $ | 1,692.0 |  |  | $ | 2,000.0 |  |  | $ | 3,692.0 |  |
| Less: debt discount and debt issuance costs, net of amortization | (2.6) |  |  | (11.9) |  |  | (14.5) |  |  | (134.1) |  |  | (331.9) |  |  | (466.0) |  |
| Net carrying amount | $ | 1,689.3 |  |  | $ | 1,987.5 |  |  | $ | 3,676.8 |  |  | $ | 1,557.9 |  |  | $ | 1,668.1 |  |  | $ | 3,226.0 |  |
| Equity component (including amounts classified as temporary equity) | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 315.0 |  |  | $ | 403.0 |  |  | $ | 718.0 |  |

[0001327567-22-000028:notes:211]
______________

[0001327567-22-000028:notes:212]
(1)     As described in Note 1. Description of Business and Summary of Significant Accounting Policies, we adopted new debt guidance effective August 1, 2021, using a modified retrospective method, under which financial results reported in prior periods were not adjusted. Upon adoption, our convertible senior notes are accounted for entirely as a liability and measured at their amortized cost. Transaction costs related to the issuance of the notes are netted with the liability and are amortized on a straight-line basis, which approximates the effective interest rate method, to interest expense over the term of the notes.

[0001327567-22-000028:notes:213]
The total estimated fair value of the 2023 Notes and 2025 Notes were $3.2 billion and $3.5 billion at July 31, 2022, respectively and $2.6 billion and $2.9 billion at July 31, 2021, respectively. The fair value was determined based on the closing trading price per $100 of the applicable series of the Notes as of the last day of trading for the period. We consider the fair value of the Notes at July 31, 2022 and 2021 to be a Level 2 measurement. The fair value of the Notes is primarily affected by the trading price of our common stock and market interest rates.

[0001327567-22-000028:notes:214]
The following table sets forth interest expense recognized related to the Notes (dollars in millions):

[0001327567-22-000028:notes:215]
|  | Year Ended July 31, 2022 |  | Year Ended July 31, 2021 |  | Year Ended July 31, 2020 |
|  | 2023 Notes |  | 2025 Notes |  | Total |  | 2023 Notes |  | 2025 Notes |  | Total |  | 2023 Notes |  | 2025 Notes |  | Total |
| Contractual interest expense | $ | 12.7 |  |  | $ | 7.5 |  |  | $ | 20.2 |  |  | $ | 12.7 |  |  | $ | 7.5 |  |  | $ | 20.2 |  |  | $ | 12.7 |  |  | $ | 1.1 |  |  | $ | 13.8 |  |
| Amortization of debt discount(1) | — |  |  | — |  |  | — |  |  | 63.5 |  |  | 74.3 |  |  | 137.8 |  |  | 60.9 |  |  | 10.5 |  |  | 71.4 |  |
| Amortization of debt issuance costs | 2.8 |  |  | 4.4 |  |  | 7.2 |  |  | 2.3 |  |  | 2.8 |  |  | 5.1 |  |  | 2.1 |  |  | 0.4 |  |  | 2.5 |  |
| Total interest expense recognized | $ | 15.5 |  |  | $ | 11.9 |  |  | $ | 27.4 |  |  | $ | 78.5 |  |  | $ | 84.6 |  |  | $ | 163.1 |  |  | $ | 75.7 |  |  | $ | 12.0 |  |  | $ | 87.7 |  |
| Effective interest rate of the liability component | 0.9 | % |  | 0.6 | % |  |  |  | 5.2 | % |  | 5.4 | % |  |  |  | 5.2 | % |  | 5.4 | % |  |  |

[0001327567-22-000028:notes:216]
(1)    Upon adoption of the new debt guidance on August 1, 2021, the conversion option is no longer separately accounted for as debt discount. Our convertible senior notes are accounted for entirely as a liability.

[0001327567-22-000028:notes:217]
Note Hedges

[0001327567-22-000028:notes:218]
To minimize the impact of potential economic dilution upon conversion of our convertible senior notes, we entered into separate convertible note hedge transactions (the “2023 Note Hedges,” with respect to the 2023 Notes, the “2025 Note Hedges,” with respect to the 2025 Notes, and the 2023 Notes Hedges together with 2025 Note Hedges, the “Note Hedges”) with respect to our common stock concurrent with the issuance of each series of the Notes.

[0001327567-22-000028:notes:219]
The following table presents details of our Note Hedges (in millions):

[0001327567-22-000028:notes:220]
|  | Initial Number of Shares |  | Aggregate Purchase |
| 2023 Note Hedges | 6.4 |  |  | $ | 332.0 |  |
| 2025 Note Hedges | 6.7 |  |  | $ | 370.8 |  |

[0001327567-22-000028:notes:221]
The Note Hedges cover shares of our common stock at a strike price per share that corresponds to the initial applicable conversion price of the applicable series of the Notes, which are also subject to adjustment, and are exercisable upon conversion of the applicable series of the Notes. The Note Hedges will expire upon maturity of the applicable series of the Notes. The Note Hedges are separate transactions and are not part of the terms of the applicable series of the Notes. Holders of the Notes of either series will not have any rights with respect to the Note Hedges. Any shares of our common stock receivable by us under the Note Hedges are excluded from the calculation of diluted earnings per share as they are antidilutive. The aggregate amounts paid for the Note Hedges are included in additional paid-in capital on our consolidated balance sheets.

[0001327567-22-000028:notes:222]
Warrants

[0001327567-22-000028:notes:223]
Separately, but concurrently with the issuance of each series of our convertible senior notes, we entered into transactions whereby we sold warrants (the “2023 Warrants,” with respect to the 2023 Notes, the “2025 Warrants,” with respect to the 2025 Notes, and the 2023 Warrants together with the 2025 Warrants, the “Warrants”) to acquire shares of our common stock, subject to anti-dilution adjustments. The 2023 Warrants and 2025 Warrants are exercisable beginning October 2023 and September 2025, respectively.

[0001327567-22-000028:notes:224]
The following table presents details of our Warrants (in millions, except per share data):

[0001327567-22-000028:notes:225]
|  | Initial Number of Shares |  | Strike Price per Share |  | Aggregate Proceeds |
| 2023 Warrants | 6.4 |  |  | $ | 417.80 |  |  | $ | 145.4 |  |
| 2025 Warrants | 6.7 |  |  | $ | 408.47 |  |  | $ | 202.8 |  |

[0001327567-22-000028:notes:226]
The shares issuable under the Warrants will be included in the calculation of diluted earnings per share when the average market value per share of our common stock for the reporting period exceeds the applicable strike price for such series of Warrants. The Warrants are separate transactions and are not part of either series of Notes or Note Hedges and are not remeasured through earnings each reporting period. Holders of the Notes of either series will not have any rights with respect to the Warrants. The aggregate proceeds received from the sale of the Warrants are included in additional paid-in capital on our consolidated balance sheets.

[0001327567-22-000028:notes:227]
Revolving Credit Facility

[0001327567-22-000028:notes:228]
On September 4, 2018, we entered into a credit agreement (the “Credit Agreement”) with certain institutional lenders that provides for a $400.0 million unsecured revolving credit facility (the “Credit Facility”), with an option to increase the amount of the Credit Facility by up to an additional $350.0 million, subject to certain conditions. The Credit Facility matures on the earlier of (i) September 4, 2023 and (ii) the date that is 91 days prior to the stated maturity of our 2023 Notes if (a) any of the 2023 Notes are still outstanding and (b) our unrestricted cash and cash equivalents are less than the then outstanding principal amount of our 2023 Notes plus $400.0 million.

[0001327567-22-000028:notes:229]
The borrowings under the Credit Facility currently bear interest, at our option, at a base rate plus a spread of 0.00% to 0.75%, or an adjusted LIBO Rate plus a spread of 1.00% to 1.75%, in each case with such spread being determined based on our leverage ratio. We are obligated to pay an ongoing commitment fee on undrawn amounts at a rate of 0.125% to 0.250%, depending on our leverage ratio. In March 2021, the ICE Benchmark Administration, the administrator of LIBO Rate, announced that it will cease publication of LIBO Rate by June 2023. Under the terms of our Credit Facility, in the event of the discontinuance of the LIBO Rate, a mutually agreed-upon alternative benchmark rate will be established to replace the LIBO Rate, which may include the Secured Overnight Financing Rate (“SOFR”). We do not anticipate that the discontinuance of the LIBO Rate will materially impact our liquidity or financial position.

[0001327567-22-000028:notes:230]
As of July 31, 2022, there were no amounts outstanding and we were in compliance with all covenants under the Credit Agreement.


## us-gaap:LesseeOperatingLeasesTextBlock

[0001327567-22-000028:notes:231]
Leases
We have entered into various non-cancelable operating leases primarily for our facilities with original lease periods expiring through the year ending July 31, 2032, with the most significant leases relating to corporate headquarters in Santa Clara.

[0001327567-22-000028:notes:232]
In May 2015 and October 2015, we entered into a total of three lease agreements for approximately 941,000 square feet of corporate office space in Santa Clara, California, which serves as our current corporate headquarters. The leases contain rent holiday periods, scheduled rent increases, lease incentives, and renewal options which allow the lease terms to be extended beyond their expiration dates of July 2028 through July 2046. Rental payments under the three lease agreements are approximately $412.0 million over the lease term.

[0001327567-22-000028:notes:233]
In September 2012, we entered into two lease agreements for a total of approximately 300,000 square feet of space in Santa Clara, California, which served as our previous corporate headquarters through August 2017, when we relocated to our current corporate campus. In December 2019, we terminated these leases prior to their expiration date. The early termination fee is $25.0 million, payable in equal quarterly installments from April 2020 through July 2023. Upon termination, we recorded a decrease of $13.6 million in operating lease liabilities based on the payment schedule of the early termination fee discounted by the incremental borrowing rate for the remaining payment term. We also decreased right-of-use assets by $8.7 million upon surrendering possession of the properties. As a result, during the year ended July 31, 2020, we recorded a gain of $3.1 million net of other related fees of $1.8 million in general and administrative expense in our consolidated statements of operations.

[0001327567-22-000028:notes:234]
During the years ended July 31, 2022, 2021 and 2020, our net cost for operating leases was $89.7 million, $75.2 million, and $80.4 million, respectively, primarily consisting of operating lease costs of $67.6 million, $59.3 million, and $63.5 million, respectively. Our net cost for operating leases also included variable lease costs, short-term lease costs and sublease income in the periods presented.

[0001327567-22-000028:notes:235]
The following tables present additional information for our operating leases (in millions, except for years and percentages):

[0001327567-22-000028:notes:236]
|  | Year Ended July 31, |  |  |  |  |  |  |
|  | 2022 |  | 2021 |  | 2020 |  |  |  |  |  |  |
| Operating cash flows used in payments of operating lease liabilities | $ | 81.5 |  |  | $ | 81.7 |  |  | $ | 78.3 |  |  |  |  |  |  |  |
| Right-of-use assets obtained in exchange for new operating lease liabilities | $ | 33.0 |  |  | $ | 48.6 |  |  | $ | 28.4 |  |  |  |  |  |  |  |

[0001327567-22-000028:notes:237]
|  | July 31, 2022 |  | July 31, 2021 |  |  |  |  |  |  |
| Weighted-average remaining lease term | 5.5 years |  | 6.1 years |  |  |  |  |  |  |
| Weighted-average discount rate | 4.0 | % |  | 3.8 | % |  |  |  |  |  |  |

[0001327567-22-000028:notes:238]
The following table presents maturities of operating lease liabilities as of July 31, 2022 (in millions):

[0001327567-22-000028:notes:239]
|  | Amount |
| Fiscal years ending July 31: |  |
| 2023 | $ | 73.5 |  |
| 2024 | 66.6 |  |
| 2025 | 64.5 |  |
| 2026 | 62.1 |  |
| 2027 | 56.0 |  |
| 2028 and thereafter | 57.4 |  |
| Total operating lease payments | 380.1 |  |
| Less: imputed interest | (41.7) |  |
| Present value of operating lease liabilities | $ | 338.4 |  |
| Current portion of operating lease liabilities(1) | $ | 62.3 |  |
| Long-term operating lease liabilities | $ | 276.1 |  |

[0001327567-22-000028:notes:240]
________________________

[0001327567-22-000028:notes:241]
(1)    Current portion of operating lease liabilities is included in accrued and other liabilities on our consolidated balance sheet.

[0001327567-22-000028:notes:242]
As of July 31, 2022, we have additional non-cancelable operating leases for office space that had been signed but had not yet commenced with total future minimum lease payments of $26.0 million. These leases will commence in fiscal 2023, with lease terms ranging from three to ten years.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001327567-22-000028:notes:243]
Commitments and Contingencies 
Purchase Commitments

[0001327567-22-000028:notes:244]
Manufacturing Purchase Commitments

[0001327567-22-000028:notes:245]
In order to reduce manufacturing lead times and plan for adequate supply, we enter into agreements with manufacturing partners and component suppliers to procure inventory based on our demand forecasts. The following table presents details of the aggregate future minimum or fixed purchase commitments under these arrangements excluding obligations under contracts that we can cancel without a significant penalty as of July 31, 2022 (in millions):

[0001327567-22-000028:notes:246]
|  |  |  | Fiscal years ending July 31, |
|  | Total |  | 2023 |  | 2024 |  | 2025 |  | 2026 |  | 2027 |  | 2028 and Thereafter |  |  |
| Manufacturing purchase commitments | $ | 331.7 |  |  | $ | 226.7 |  |  | $ | 30.0 |  |  | $ | 35.0 |  |  | $ | 40.0 |  |  | $ | — |  |  | $ | — |  |  |  |

[0001327567-22-000028:notes:247]
Other Purchase Commitments

[0001327567-22-000028:notes:248]
We have entered into various non-cancelable agreements with certain service providers, under which we are committed to minimum or fixed purchases. The following table presents details of the aggregate future non-cancelable purchase commitments under these agreements as of July 31, 2022 (in millions):

[0001327567-22-000028:notes:249]
|  |  |  | Fiscal years ending July 31, |
|  | Total |  | 2023 |  | 2024 |  | 2025 |  | 2026 |  | 2027 |  | 2028 and Thereafter |  |  |
| Other purchase commitments | $ | 1,881.4 |  |  | $ | 82.7 |  |  | $ | 368.5 |  |  | $ | 413.9 |  |  | $ | 531.6 |  |  | $ | 483.9 |  |  | $ | 0.8 |  |  |  |

[0001327567-22-000028:notes:250]
Additionally, we have a $162.2 million minimum purchase commitment with a service provider through September 2027 with no specified annual commitments.

[0001327567-22-000028:notes:251]
Mutual Covenant Not to Sue and Release Agreement

[0001327567-22-000028:notes:252]
In January 2020, we executed a Mutual Covenant Not to Sue and Release Agreement for $50.0 million to extend an existing covenant not to sue for seven years. As the primary benefit of the arrangement was attributable to future use, the amount was recorded in other assets on our consolidated balance sheets and is amortized to cost of product revenue in our consolidated statements of operations over the estimated period of benefit of seven years.

[0001327567-22-000028:notes:253]
Litigation

[0001327567-22-000028:notes:254]
We are subject to legal proceedings, claims, and litigation arising in the ordinary course of business, including intellectual property litigation. Such matters are subject to many uncertainties and outcomes are not predictable with assurance. We accrue for contingencies when we believe that a loss is probable and that we can reasonably estimate the amount of any such loss.

[0001327567-22-000028:notes:255]
To the extent there is a reasonable possibility that a loss exceeding amounts already recognized may be incurred and the amount of such additional loss would be material, we will either disclose the estimated additional loss or state that such an estimate cannot be made. As of July 31, 2022, we have not recorded any significant accruals for loss contingencies associated with such legal proceedings, determined that an unfavorable outcome is probable or reasonably possible, or determined that the amount or range of any possible loss is reasonably estimable.

[0001327567-22-000028:notes:256]
Indemnification

[0001327567-22-000028:notes:257]
Under the indemnification provisions of our standard sales related contracts, we agree to defend our end-customers against third-party claims asserting infringement of certain intellectual property rights, which may include patents, copyrights, trademarks, or trade secrets, and to pay judgments entered on such claims. Our exposure under these indemnification provisions is generally limited to payments made to us for the alleged infringing products over the preceding twelve months under the agreement. However, certain agreements include indemnification provisions that could potentially expose us to losses in excess of these payments. In addition, we indemnify our officers, directors, and certain key employees while they are serving in good faith in their company capacities. To date, we have not recorded any accruals for loss contingencies associated with indemnification claims or determined that an unfavorable outcome is probable or reasonably possible.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001327567-22-000028:notes:258]
Stockholders’ Equity
Share Repurchase Program

[0001327567-22-000028:notes:259]
In February 2019, our board of directors authorized a $1.0 billion share repurchase program, which is funded from available working capital. In December 2020 and August 2021, our board of directors authorized additional $700.0 million and $676.1 million increases to this share repurchase program, respectively, bringing the total authorization under this share repurchase program to $2.4 billion (our “current authorization”). The expiration date of our current authorization was extended to December 31, 2022, and our repurchase program may be suspended or discontinued at any time. Repurchases may be made at management’s discretion from time to time on the open market, through privately negotiated transactions, transactions structured through investment banking institutions, block purchase techniques, 10b5-1 trading plans, or a combination of the foregoing.

[0001327567-22-000028:notes:260]
The following table summarizes the share repurchase activity under our share repurchase program (in millions, except per share amounts):

[0001327567-22-000028:notes:261]
|  | Year Ended July 31, |
|  | 2022 |  | 2021 |  | 2020 |
| Number of shares repurchased | 1.8 |  |  | 4.0 |  |  | 0.9 |  |
| Weighted average price per share (1) | $ | 512.49 |  |  | $ | 294.87 |  |  | $ | 209.12 |  |
| Aggregate purchase price (1) | $ | 915.0 |  |  | $ | 1,178.1 |  |  | $ | 198.1 |  |

[0001327567-22-000028:notes:262]
(1)     Includes transaction costs

[0001327567-22-000028:notes:263]
As of July 31, 2022, $85.0 million remained available for future share repurchases under our current repurchase authorization. The total price of the shares repurchased and related transaction costs are reflected as a reduction to common stock and additional paid-in capital on our consolidated balance sheets.

[0001327567-22-000028:notes:264]
Accelerated Stock Repurchase

[0001327567-22-000028:notes:265]
In February 2020, our board of directors approved the repurchase of $1.0 billion of our common stock through an accelerated share repurchase (“ASR”) transaction with a financial institution. This ASR transaction was in addition to our share repurchase program. 
During the fiscal year ended July 31, 2020, we completed the ASR transaction with an aggregate of 5.2 million shares of our common stock repurchased and retired. The total price of the ASR transaction is reflected as a reduction to common stock and additional paid-in capital on our consolidated balance sheet.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001327567-22-000028:notes:266]
Equity Award Plans
Share-Based Compensation Plans

[0001327567-22-000028:notes:267]
Equity Incentive Plans

[0001327567-22-000028:notes:268]
Our 2021 Equity Incentive Plan (our “2021 Plan”) became effective in December 2021 and replaced our 2012 Equity Incentive Plan (our “2012 Plan”). Our 2021 Plan provides for the granting of stock options, stock appreciation rights, restricted stock awards (“RSAs”), restricted stock units (“RSUs”), performance shares (“PSAs”), performance-based stock units (“PSUs”) and performance stock options (“PSOs”) to our employees, directors, and consultants. Upon effectiveness of the 2021 Plan, the 2012 Plan was terminated and no further awards will be granted under the 2012 Plan. Awards that were outstanding upon such termination remained outstanding pursuant to their original terms, and any subsequent expiration, cancellation or forfeiture of awards under our 2012 Plan are returned to our 2021 Plan.

[0001327567-22-000028:notes:269]
The majority of our equity awards are RSUs, which generally vest over a period of three to four years from the date of grant. Until vested, RSUs do not have the voting and dividend participation rights of common stock and the shares underlying the awards are not considered issued and outstanding. Our options expire no more than ten years after the date of grant.

[0001327567-22-000028:notes:270]
We grant PSUs to certain employees, which vest over a period of one to four years from the date of grant. The actual number of PSUs earned and eligible to vest is determined based on the level of achievement against revenue growth, pre-established billings and operating margin goals, or pre-defined individual performance targets for the fiscal year, and market conditions, if applicable. During the year ended July 31, 2022, we granted 0.1 million shares of PSUs, which contain service, performance and market conditions. The performance condition is based on revenue growth, whereas the market condition measures our total shareholder return (“TSR”) relative to the TSR of the companies listed in the Standard & Poor’s 500 index. In addition to this grant, we have also approved the future grant of 0.1 million shares of PSUs with similar terms, which will be considered granted at the time their related vesting conditions are established in the next two years.

[0001327567-22-000028:notes:271]
We have also granted PSOs with both a market condition and a service condition to certain executives. The market condition for PSOs granted in the fiscal years 2018 and 2019 requires the price of our common stock to equal or exceed $297.75, $397.00, $496.25, and $595.50 based on the average closing price for 30 consecutive trading days during the four-, five-, six-, and seven-and-a-half-year periods following the date of grant in fiscal year 2018 and 2019, respectively. The market condition for PSOs granted in the fiscal year 2021 requires the price of our common stock to equal or exceed $397.00, $496.25, $595.50 and $700.00 based on the average closing price for 30 consecutive trading days during the three-, four-, five-, and six-and-a-half-year periods following the date of grant. All of the PSOs granted in the fiscal year 2021 were forfeited in the same fiscal year and are no longer outstanding. To the extent that the market condition has been met, one-fourth of the PSOs will vest on each anniversary date of the grant date for such PSOs, subject to continued service. All outstanding PSOs may be exercised prior to vesting (“early exercise”). Shares of common stock issued upon early exercise of the PSOs will be restricted and, at our option, subject to repurchase if the option holder ceases to be a service provider. The maximum contractual term of our outstanding PSOs is seven and a half years from the date of grant, depending on vesting period. As of July 31, 2022, all stock price targets for our outstanding PSOs have been satisfied.

[0001327567-22-000028:notes:272]
We net-share settle equity awards held by certain employees by withholding shares upon vesting to satisfy tax withholding obligations. The shares withheld to satisfy employee tax withholding obligations are returned to our 2021 Plan and will be available for future issuance. Payments for employees’ tax obligations to the tax authorities are recognized as a reduction to additional paid-in capital and reflected as financing activities in our consolidated statements of cash flows.

[0001327567-22-000028:notes:273]
A total of 13.1 million shares of our common stock are reserved for issuance pursuant to our equity incentive plans as of July 31, 2022.

[0001327567-22-000028:notes:274]
2012 Employee Stock Purchase Plan

[0001327567-22-000028:notes:275]
Our 2012 Employee Stock Purchase Plan was adopted by our board of directors and approved by the stockholders on June 5, 2012, and was effective upon completion of our initial public offering (“IPO”). On August 29, 2017, we amended and restated our 2012 Employee Stock Purchase Plan (our “2012 ESPP”) to extend the length of our offering periods from 6 to 24 months.

[0001327567-22-000028:notes:276]
Our 2012 ESPP permits eligible employees to acquire shares of our common stock at 85% of the lower of the fair market value of our common stock on the first trading day of each offering period or on the purchase date. If the fair market value of our common stock on the purchase date is lower than the first trading day of the offering period, the current offering period will be cancelled after purchase and a new 24-month offering period will begin. Under our 2012 ESPP, each 24-month offering period consists of four consecutive 6-month purchase periods, with purchase dates on the first trading day on or after February 28 and August 31 of each year. Participants may purchase shares of common stock through payroll deductions of up to 15% of their eligible compensation, subject to purchase limits of 625 shares per six-month purchase period and $25,000 worth of stock for each calendar year. Shares purchased under our 2012 ESPP during the fiscal years ended July 31, 2022, 2021 and 2020 were 0.7 million, 0.6 million and 0.6 million, at an average exercise price of $192.81 per share, $161.07 per share and $146.90 per share respectively.

[0001327567-22-000028:notes:277]
A total of 4.9 million shares of our common stock are available for sale under our 2012 ESPP as of July 31, 2022. On the first day of each fiscal year, the number of shares in the reserve may be increased by the lesser of (i) 2,000,000 shares, (ii) 1% of the outstanding shares of our common stock on the first day of the fiscal year, or (iii) such other amount as determined by our board of directors.

[0001327567-22-000028:notes:278]
Assumed Share-Based Compensation Plans

[0001327567-22-000028:notes:279]
In connection with our acquisitions, we have assumed equity incentive plans of certain acquired companies (collectively “the Assumed Plans”). The equity awards assumed in connection with each acquisition were granted from their respective assumed plans. The assumed equity awards will be settled in shares of our common stock and will retain the terms and conditions under which they were originally granted. No additional equity awards will be granted under and forfeited awards will not be returned to the Assumed Plans. Refer to Note 7. Acquisitions for more information on our acquisitions and the related equity awards assumed.

[0001327567-22-000028:notes:280]
Stock Option Activities

[0001327567-22-000028:notes:281]
The following table summarizes the stock option and PSO activity under our stock plans during the years ended July 31, 2022, 2021, and 2020 (in millions, except per share amounts):

[0001327567-22-000028:notes:282]
|  | Stock Options Outstanding |  | PSOs Outstanding |
|  | Number of Shares |  | Weighted-Average Exercise Price Per Share |  | Weighted-Average Remaining Contractual Term(Years) |  | Aggregate Intrinsic Value |  | Number of Shares |  | Weighted-Average Exercise Price Per Share |  | Weighted-Average Remaining Contractual Term(Years) |  | Aggregate Intrinsic Value |
| Balance—July 31, 2019 | 0.3 |  |  | $ | 14.53 |  |  | 2.2 |  | $ | 81.4 |  |  | 3.7 |  |  | $ | 193.99 |  |  | 6.2 |  | $ | 120.1 |  |
| Exercised | (0.2) |  |  | $ | 11.46 |  |  |  |  |  |  | — |  |  | $ | — |  |  |  |  |  |
| Forfeited | — |  |  | $ | — |  |  |  |  |  |  | (0.9) |  |  | $ | 193.51 |  |  |  |  |  |
| Balance—July 31, 2020 | 0.1 |  |  | $ | 19.59 |  |  | 1.5 |  | $ | 34.2 |  |  | 2.8 |  |  | $ | 194.14 |  |  | 5.2 |  | $ | 170.9 |  |
| Granted | — |  |  | $ | — |  |  |  |  |  |  | 0.2 |  |  | $ | 304.29 |  |  |  |  |  |
| Exercised | 0.0 |  |  | $ | 12.82 |  |  |  |  |  |  | — |  |  | $ | — |  |  |  |  |  |
| Forfeited | — |  |  | $ | 7.84 |  |  |  |  |  |  | (0.2) |  |  | $ | 304.29 |  |  |  |  |  |
| Balance—July 31, 2021 | 0.1 |  |  | $ | 26.20 |  |  | 0.8 |  | $ | 27.4 |  |  | 2.8 |  |  | $ | 194.14 |  |  | 4.2 |  | $ | 566.8 |  |
| Exercised | (0.1) |  |  | $ | 18.72 |  |  |  |  |  |  | — |  |  | $ | — |  |  |  |  |  |
| Forfeited | — |  |  | $ | — |  |  |  |  |  |  | (0.1) |  |  | $ | 184.24 |  |  |  |  |  |
| Balance—July 31, 2022 | 0.0 |  |  | $ | 55.36 |  |  | 0.5 |  | $ | 6.7 |  |  | 2.7 |  |  | $ | 194.55 |  |  | 3.2 |  | $ | 809.3 |  |
| Exercisable—July 31, 2022 | 0.0 |  |  | $ | 55.36 |  |  | 0.5 |  | $ | 6.7 |  |  | 2.7 |  |  | $ | 194.55 |  |  | 3.2 |  | $ | 809.3 |  |

[0001327567-22-000028:notes:283]
The weighted-average grant-date fair value of PSOs granted during the year ended July 31, 2021 was $82.12 per share. The intrinsic value of options exercised during the years ended July 31, 2022, 2021, and 2020 was $29.2 million, $22.2 million and $50.2 million, respectively.

[0001327567-22-000028:notes:284]
RSU and PSU Activities

[0001327567-22-000028:notes:285]
The following table summarizes the RSU and PSU activity under our stock plans during the years ended July 31, 2022, 2021, and 2020 (in millions, except per share amounts):

[0001327567-22-000028:notes:286]
|  | RSUs Outstanding |  | PSUs Outstanding |
|  | Number of Shares |  | Weighted- Average Grant-Date Fair Value Per Share |  |  |  | Aggregate Intrinsic Value |  | Number of Shares |  | Weighted- Average Grant-Date Fair Value Per Share |  |  |  | Aggregate Intrinsic Value |
| Balance—July 31, 2019 | 6.9 |  |  | $ | 188.16 |  |  |  |  | $ | 1,554.0 |  |  | 0.3 |  |  | $ | 197.86 |  |  |  |  | $ | 67.0 |  |
| Granted(1)(2) | 3.5 |  |  | $ | 211.38 |  |  |  |  |  |  | 0.4 |  |  | $ | 248.55 |  |  |  |  |  |
| Vested(3) | (2.8) |  |  | $ | 181.19 |  |  |  |  |  |  | (0.1) |  |  | $ | 166.90 |  |  |  |  |  |
| Forfeited | (1.0) |  |  | $ | 188.18 |  |  |  |  |  |  | 0.0 |  |  | $ | 175.88 |  |  |  |  |  |
| Balance—July 31, 2020 | 6.6 |  |  | $ | 203.30 |  |  |  |  | $ | 1,688.1 |  |  | 0.6 |  |  | $ | 231.42 |  |  |  |  | $ | 147.2 |  |
| Granted(1)(2) | 4.1 |  |  | $ | 297.89 |  |  |  |  |  |  | 0.8 |  |  | $ | 321.45 |  |  |  |  |  |
| Vested(3) | (2.9) |  |  | $ | 200.91 |  |  |  |  |  |  | (0.1) |  |  | $ | 195.60 |  |  |  |  |  |
| Forfeited | (0.9) |  |  | $ | 226.79 |  |  |  |  |  |  | 0.0 |  |  | $ | 235.98 |  |  |  |  |  |
| Balance—July 31, 2021 | 6.9 |  |  | $ | 257.56 |  |  |  |  | $ | 2,760.2 |  |  | 1.3 |  |  | $ | 292.93 |  |  |  |  | $ | 498.4 |  |
| Granted(1) | 1.9 |  |  | $ | 494.54 |  |  |  |  |  |  | 0.3 |  |  | $ | 351.14 |  |  |  |  |  |
| Vested(3) | (3.0) |  |  | $ | 257.07 |  |  |  |  |  |  | (0.4) |  |  | $ | 250.42 |  |  |  |  |  |
| Forfeited | (0.9) |  |  | $ | 286.49 |  |  |  |  |  |  | (0.2) |  |  | $ | 321.92 |  |  |  |  |  |
| Balance—July 31, 2022 | 4.9 |  |  | $ | 346.54 |  |  |  |  | $ | 2,456.9 |  |  | 1.0 |  |  | $ | 319.15 |  |  |  |  | $ | 513.7 |  |

[0001327567-22-000028:notes:287]
(1)    For PSUs, shares granted represent the aggregate maximum number of shares that may be earned and issued with respect to these awards over their full terms.

[0001327567-22-000028:notes:288]
(2)    Includes 0.4 million RSUs assumed in connection with the acquisitions of Crypsis, Sinefa, Expanse and Bridgecrew, with weighted-average grant-date fair value of $241.43, $297.17, $317.45 and $354.66, respectively, for the year ended July 31, 2021, and 0.1 million RSUs assumed in connection with the acquisitions of Zingbox, Aporeto and CloudGenix, with weighted-average grant-date fair value of $208.25, $231.30 and $181.48, respectively, for the year ended July 31, 2020.

[0001327567-22-000028:notes:289]
(3)    Includes time-based vesting for PSUs.

[0001327567-22-000028:notes:290]
The aggregate fair value, as of the respective vesting dates, of RSUs vested during the years ended July 31, 2022, 2021, and 2020 was $1.6 billion, $986.4 million, and $615.7 million, respectively. The aggregate fair value, as of the respective vesting dates, of PSUs vested during the year ended July 31, 2022, 2021, and 2020 was $184.0 million, $20.8 million and $11.9 million, respectively.

[0001327567-22-000028:notes:291]
Shares Available for Grant

[0001327567-22-000028:notes:292]
The following table presents the stock activity and the total number of shares available for grant under our equity incentive plans as of July 31, 2022 (in millions):

[0001327567-22-000028:notes:293]
|  | Number of shares |
| Balance—July 31, 2021 | 11.3 |  |
| Authorized | 8.8 |  |
| Cancelled upon effectiveness of the 2021 Plan | (14.6) |  |
| RSUs and PSUs granted | (2.2) |  |
| PSOs, RSUs, and PSUs forfeited | 1.2 |  |
| Shares withheld for taxes | 0.1 |  |
| Balance—July 31, 2022 | 4.6 |  |

[0001327567-22-000028:notes:294]
We record share-based compensation awards based on estimated fair value as of the grant date. The fair value of RSUs and PSUs not subject to market conditions is based on the closing market price of our common stock on the date of grant.

[0001327567-22-000028:notes:295]
The fair value of the PSUs subject to the market condition is estimated on the grant date using a Monte Carlo simulation model. No such PSUs were granted during the years ended July 31, 2021 or 2020. The following table summarizes the assumptions used and the resulting grant-date fair value of our PSUs subject to the market condition granted during the year ended July 31, 2022:

[0001327567-22-000028:notes:296]
|  | Year Ended July 31, 2022 |
| Volatility | 36.0% - 41.1% |
| Expected term (in years) | 1.4 - 3.0 |
| Dividend yield | — | % |
| Risk-free interest rate | 0.2% - 2.0% |
| Grant-date fair value per share | $411.49 - $782.13 |

[0001327567-22-000028:notes:297]
The expected volatility is based on the historical volatility of our common stock. The expected term is based on the length of each tranche’s performance period from the grant date. The dividend yield assumption is based on our current expectations about our anticipated dividend policy. The risk-free interest rate is based on the implied yield available on U.S. Treasury zero-coupon issues with maturities that approximate the expected term.

[0001327567-22-000028:notes:298]
The fair value of PSOs is estimated on the grant date using a Monte Carlo simulation model, which predicts settlement of the options midway between the vesting term and the contractual term. No PSOs were granted during the years ended July 31, 2022 or 2020. The following table summarizes the assumptions used and the resulting grant-date fair values of our PSOs granted during the year ended July 31, 2021:

[0001327567-22-000028:notes:299]
|  | Year Ended July 31, 2021 |  |  |
| Volatility | 35.9 | % |  |  |
| Dividend yield | — | % |  |  |
| Risk-free interest rate | 0.6 | % |  |  |
| Weighted-average grant-date fair value per share | $ | 82.12 |  |  |  |

[0001327567-22-000028:notes:300]
The expected volatility is based on a combination of implied volatility from traded options on our common stock and the historical volatility of our common stock. The dividend yield assumption is based on our current expectations about our anticipated dividend policy. The risk-free interest rate is based on the implied yield available on U.S. Treasury zero-coupon issues with terms equal to the contractual terms of each tranche.

[0001327567-22-000028:notes:301]
The fair value of shares issued under our 2012 ESPP are estimated on the grant date using the Black-Scholes option pricing model. The following table summarizes the assumptions used and the resulting grant-date fair values of our ESPP:

[0001327567-22-000028:notes:302]
|  | Year Ended July 31, |
|  | 2022 |  | 2021 |  | 2020 |
| Volatility | 33.6% - 39.4% |  | 34.9% - 42.6% |  | 31.0% - 35.7% |
| Expected term (in years) | 0.5 - 2.0 |  | 0.5 - 2.0 |  | 0.5 - 2.0 |
| Dividend yield | — | % |  | — | % |  | — | % |
| Risk-free interest rate | 0.1% - 1.4% |  | 0.1% |  | 0.9% - 1.9% |
| Grant-date fair value per share | $112.76 - $222.30 |  | $69.48 - $129.05 |  | $46.75 - $66.47 |

[0001327567-22-000028:notes:303]
The expected volatility is based on a combination of implied volatility from traded options on our common stock and the historical volatility of our common stock. The expected term represents the term from the first day of the offering period to the purchase dates within each offering period. The dividend yield assumption is based on our current expectations about our anticipated dividend policy. The risk-free interest rate is based on the implied yield available on U.S. Treasury zero-coupon issues with maturities that approximate the expected term.

[0001327567-22-000028:notes:304]
The following table summarizes share-based compensation included in costs and expenses (in millions):

[0001327567-22-000028:notes:305]
|  | Year Ended July 31, |
|  | 2022 |  | 2021 |  | 2020 |
| Cost of product revenue | $ | 9.3 |  |  | $ | 6.2 |  |  | $ | 5.7 |  |
| Cost of subscription and support revenue | 110.2 |  |  | 93.0 |  |  | 77.7 |  |
| Research and development | 471.1 |  |  | 428.9 |  |  | 274.6 |  |
| Sales and marketing | 304.7 |  |  | 269.9 |  |  | 214.5 |  |
| General and administrative | 118.1 |  |  | 128.9 |  |  | 92.0 |  |
| Total share-based compensation | $ | 1,013.4 |  |  | $ | 926.9 |  |  | $ | 664.5 |

[0001327567-22-000028:notes:306]
As of July 31, 2022, total compensation cost related to unvested share-based awards not yet recognized was $1.8 billion. This cost is expected to be amortized over a weighted-average period of approximately 2.6 years. Future grants will increase the amount of compensation expense to be recorded in these periods.


## us-gaap:ScheduleOfShareBasedPaymentAwardStockOptionsValuationAssumptionsTableTextBlock

[0001327567-22-000028:notes:307]
The following table summarizes the assumptions used and the resulting grant-date fair value of our PSUs subject to the market condition granted during the year ended July 31, 2022:

[0001327567-22-000028:notes:308]
The following table summarizes the assumptions used and the resulting grant-date fair values of our PSOs granted during the year ended July 31, 2021:


## us-gaap:IncomeTaxDisclosureTextBlock

[0001327567-22-000028:notes:309]
Income Taxes 
The following table presents the components of income (loss) before income taxes (in millions):

[0001327567-22-000028:notes:310]
|  | Year Ended July 31, |
|  | 2022 |  | 2021 |  | 2020 |
| United States | $ | (152.3) |  |  | $ | (482.2) |  |  | $ | (56.1) |  |
| Foreign | (54.9) |  |  | 17.2 |  |  | (175.7) |  |
| Total | $ | (207.2) |  |  | $ | (465.0) |  |  | $ | (231.8) |  |

[0001327567-22-000028:notes:311]
The following table summarizes our provision for income taxes (in millions):

[0001327567-22-000028:notes:312]
|  | Year Ended July 31, |
|  | 2022 |  | 2021 |  | 2020 |
| Federal: |  |  |  |  |  |
| Current | $ | 2.6 |  |  | $ | 3.3 |  |  | $ | 3.8 |  |
| Deferred | (0.3) |  |  | (5.9) |  |  | (1.3) |  |
| State: |  |  |  |  |  |
| Current | 1.5 |  |  | 1.7 |  |  | 1.3 |  |
| Deferred | 0.1 |  |  | 0.1 |  |  | 0.1 |  |
| Foreign: |  |  |  |  |  |
| Current | 58.8 |  |  | 41.3 |  |  | 39.2 |  |
| Deferred | (2.9) |  |  | (6.6) |  |  | (7.9) |  |
| Total | $ | 59.8 |  |  | $ | 33.9 |  |  | $ | 35.2 |  |

[0001327567-22-000028:notes:313]
For the year ended July 31, 2022, our provision for income taxes increased compared to the year ended July 31, 2021, primarily due to foreign income and withholding taxes.

[0001327567-22-000028:notes:314]
For the year ended July 31, 2021, our provision for income taxes decreased slightly compared to the year ended July 31, 2020, primarily due to tax benefits from changes in our valuation allowances.

[0001327567-22-000028:notes:315]
The following table presents the items accounting for the difference between income taxes computed at the federal statutory income tax rate and our provision for income taxes:

[0001327567-22-000028:notes:316]
|  | Year Ended July 31, |
|  | 2022 |  | 2021 |  | 2020 |
| Federal statutory rate | 21.0 | % |  | 21.0 | % |  | 21.0 | % |
| Effect of: |  |  |  |  |  |
| State taxes, net of federal tax benefit | 2.7 |  |  | 1.3 |  |  | 3.0 |  |
| Effects of non-U.S. operations | (16.5) |  |  | (3.1) |  |  | 667.5 |  |
| Change in valuation allowance | (158.7) |  |  | (40.7) |  |  | (714.1) |  |
| Share-based compensation | 83.6 |  |  | 5.0 |  |  | (5.1) |  |
| Tax credits | 41.5 |  |  | 9.9 |  |  | 17.9 |  |
| Non-deductible expenses | (2.5) |  |  | (1.3) |  |  | (3.9) |  |
| Other, net | — |  |  | 0.6 |  |  | (1.5) |  |
| Total | (28.9) | % |  | (7.3) | % |  | (15.2) | % |

[0001327567-22-000028:notes:317]
In fiscal 2020, we transferred certain intellectual property rights to a wholly owned United Kingdom subsidiary, primarily to align our legal structure to our evolving operations. The tax benefit from an increase in the tax basis of intellectual property rights resulted in an increase in effects of non-U.S. operations and was fully offset by a full valuation.

[0001327567-22-000028:notes:318]
The following table presents the components of our deferred tax assets and liabilities as of July 31, 2022 and 2021 (in millions):

[0001327567-22-000028:notes:319]
|  | July 31, |
|  | 2022 |  | 2021 |
| Deferred tax assets: |  |  |  |
| Accruals and reserves | $ | 227.1 |  |  | $ | 125.0 |  |
| Deferred revenue | 475.5 |  |  | 364.9 |  |
| Net operating loss carryforwards | 759.1 |  |  | 556.7 |  |
| Tax credits | 317.4 |  |  | 230.8 |  |
| Share-based compensation | 59.2 |  |  | 53.9 |  |
| Fixed assets and intangible assets | 1,742.6 |  |  | 1,789.6 |  |
| Interest carryforward | 55.8 |  |  | 19.2 |  |
| Gross deferred tax assets | 3,636.7 |  |  | 3,140.1 |  |
| Valuation allowance | (3,414.1) |  |  | (2,933.3) |  |
| Total deferred tax assets | 222.6 |  |  | 206.8 |  |
| Deferred tax liabilities: |  |  |  |
| Deferred contract costs | (183.6) |  |  | (165.4) |  |
| Other deferred tax liabilities | (27.8) |  |  | (32.3) |  |
| Total deferred tax liabilities | (211.4) |  |  | (197.7) |  |
| Net deferred tax assets | $ | 11.2 |  |  | $ | 9.1 |  |

[0001327567-22-000028:notes:320]
A valuation allowance is provided when it is more likely than not that the deferred tax asset will not be realized. Realization of deferred tax assets is dependent upon future taxable income, if any, the amount and timing of which are uncertain. At such time, if it is determined that it is more likely than not that the deferred tax assets are realizable, the valuation allowance will be adjusted. As of July 31, 2022, we have provided a valuation allowance for our federal, state, United Kingdom and certain other foreign deferred tax assets that we believe will, more likely than not, be unrealizable. The net valuation allowance increased by $0.5 billion from the year ended July 31, 2021 to the year ended July 31, 2022, primarily due to an increase in our NOL carryforwards and deferred revenue as a result of current year operations.

[0001327567-22-000028:notes:321]
As of July 31, 2022, we had federal, state, and foreign NOL carryforwards of approximately $2.0 billion, $1.0 billion, and $1.8 billion, respectively, as reported on our tax returns, available to reduce future taxable income, if any. If not utilized, our federal and state NOL carryforwards will expire in various amounts at various dates beginning in the years ending July 31, 2033 and July 31, 2023, respectively. Our foreign NOL will carry forward indefinitely.

[0001327567-22-000028:notes:322]
As of July 31, 2022, we had federal and state research and development tax credit carryforwards of approximately $243.8 million and $197.4 million, respectively, as reported on our tax returns. If not utilized, the federal credit carryforwards will expire in various amounts at various dates beginning in the year ending July 31, 2026. The state credit will carry forward indefinitely.

[0001327567-22-000028:notes:323]
As of July 31, 2022, we had foreign tax credit carryforwards of $3.5 million as reported on our tax returns. If not utilized, the foreign tax credit carryforwards will expire in various amounts at various dates beginning in the year ending July 31, 2023.

[0001327567-22-000028:notes:324]
Utilization of the NOL carryforwards and credits may be subject to a substantial annual limitation due to the ownership change limitations provided by the Internal Revenue Code of 1986, as amended, and similar state provisions. The annual limitation may result in the expiration of NOLs and credits before utilization.

[0001327567-22-000028:notes:325]
As of July 31, 2022, we had $414.0 million of unrecognized tax benefits, $76.1 million of which would affect income tax expense if recognized, after consideration of our valuation allowance in the United States and other assets. As of July 31, 2021, we had $372.9 million of unrecognized tax benefits, $68.7 million of which would affect income tax expense if recognized, after consideration of our valuation allowance in the United States and other assets. We do not expect the amount of unrecognized tax benefits as of July 31, 2022 to materially change over the next 12 months.

[0001327567-22-000028:notes:326]
We file federal, state, and foreign income tax returns in jurisdictions with varying statutes of limitations. Generally, all years remain subject to adjustment due to our NOL and credit carryforwards. We currently have ongoing tax audits in various jurisdictions and at various times. The primary focus of these audits is, generally, profit allocation. The ultimate amount and timing of any future settlements cannot be predicted with reasonable certainty.

[0001327567-22-000028:notes:327]
We recognize both interest and penalties associated with uncertain tax positions as a component of income tax expense. During the years ended July 31, 2022, 2021, and 2020, we recognized income tax expense related to interest and penalties of $5.2 million, $3.5 million, and $1.6 million, respectively. We had accrued interest and penalties on our consolidated balance sheets related to unrecognized tax benefits of $20.9 million and $15.7 million as of July 31, 2022 and 2021, respectively.

[0001327567-22-000028:notes:328]
The following table presents a reconciliation of the beginning and ending amount of our gross unrecognized tax benefits (in millions):

[0001327567-22-000028:notes:329]
|  | Year Ended July 31, |
|  | 2022 |  | 2021 |  | 2020 |
| Unrecognized tax benefits at the beginning of the period | $ | 372.9 |  |  | $ | 326.4 |  |  | $ | 314.5 |  |
| Additions for tax positions taken in prior years | 3.5 |  |  | 26.5 |  |  | 3.2 |  |
| Reductions for tax positions taken in prior years | (7.4) |  |  | (2.5) |  |  | (1.6) |  |
| Additions for tax positions taken in the current year | 45.0 |  |  | 22.5 |  |  | 10.3 |  |
| Unrecognized tax benefits at the end of the period | $ | 414.0 |  |  | $ | 372.9 |  |  | $ | 326.4 |  |

[0001327567-22-000028:notes:330]
During the year ended July 31, 2022 and 2021, our additions for tax positions taken in the given year were primarily attributable to uncertain tax positions related to tax credits.

[0001327567-22-000028:notes:331]
During the year ended July 31, 2020, our additions for tax positions taken in the given year were primarily attributable to intercompany transactions.
As of July 31, 2022, we had no unremitted earnings when evaluating our outside basis difference relating to our U.S. investment in foreign subsidiaries. However, there could be local withholding taxes payable due to various foreign countries if certain lower tier earnings are distributed. Withholding taxes that would be payable upon remittance of these lower tier earnings are not material.


## us-gaap:EarningsPerShareTextBlock

[0001327567-22-000028:notes:332]
Net Loss Per Share 
Basic net loss per share is computed by dividing net loss by basic weighted-average shares outstanding during the period. Diluted net loss per share is computed by dividing net loss by diluted weighted-average shares outstanding, including potentially dilutive securities.

[0001327567-22-000028:notes:333]
The following table presents the computation of basic and diluted net loss per share of common stock (in millions, except per share data):

[0001327567-22-000028:notes:334]
|  | Year Ended July 31, |
|  | 2022 |  | 2021 |  | 2020 |
| Net loss | $ | (267.0) |  |  | $ | (498.9) |  |  | $ | (267.0) |  |
| Weighted-average shares used to compute net loss per share, basic and diluted | 98.5 |  |  | 96.4 |  |  | 96.9 |
| Net loss per share, basic and diluted | $ | (2.71) |  |  | $ | (5.18) |  |  | $ | (2.76) |  |

[0001327567-22-000028:notes:335]
The following securities were excluded from the computation of diluted net loss per share of common stock for the periods presented as their effect would have been antidilutive (in millions):

[0001327567-22-000028:notes:336]
|  | Year Ended July 31, |
|  | 2022 |  | 2021 |  | 2020 |
| Convertible senior notes | 13.1 |  |  | 13.1 |  |  | 13.1 |  |
| Warrants related to the issuance of convertible senior notes | 13.1 |  |  | 13.1 |  |  | 13.1 |  |
| RSUs and PSUs | 5.9 |  |  | 8.2 |  |  | 7.2 |  |
| Options to purchase common stock, including PSOs | 2.7 |  |  | 2.9 |  |  | 2.9 |  |
| RSAs and PSAs | 0.1 |  |  | 0.3 |  |  | 0.1 |  |
| ESPP shares | 0.2 |  |  | 0.3 |  |  | 0.3 |  |
| Total | 35.1 |  |  | 37.9 |  |  | 36.7 |  |


## us-gaap:OtherNonoperatingIncomeAndExpenseTextBlock

[0001327567-22-000028:notes:337]
Other Income, NetThe following table sets forth the components of other income, net (in millions):

[0001327567-22-000028:notes:338]
|  | Year Ended July 31, |
|  | 2022 |  | 2021 |  | 2020 |
| Interest income | $ | 15.6 |  |  | $ | 8.5 |  |  | $ | 41.4 |  |
| Foreign currency exchange gains (losses), net | 1.8 |  |  | (5.4) |  |  | (6.7) |  |
| Other | (8.4) |  |  | (0.7) |  |  | 1.2 |  |
| Total other income, net | $ | 9.0 |  |  | $ | 2.4 |  |  | $ | 35.9 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001327567-22-000028:notes:339]
Segment Information
We conduct business globally and sales are primarily managed on a geographic theater basis. Our chief operating decision maker reviews financial information presented on a consolidated basis accompanied by information about revenue by geographic region for purposes of allocating resources and evaluating financial performance. We have one business activity and there are no segment managers who are held accountable for operations, operating results, and plans for levels, components, or types of products or services below the consolidated unit level. Accordingly, we are considered to be in a single reportable segment and operating unit structure.

[0001327567-22-000028:notes:340]
The following table presents our long-lived assets, which consist of property and equipment, net and operating lease right-of-use assets, by geographic region (in millions):

[0001327567-22-000028:notes:341]
|  | Year Ended July 31, |
|  | 2022 |  | 2021 |
| Long-lived assets: |  |  |  |
| United States | $ | 446.1 |  |  | $ | 461.1 |  |
| Israel | 55.4 |  |  | 61.9 |  |
| Other countries | 98.3 |  |  | 58.3 |  |
| Total long-lived assets | $ | 599.8 |  |  | $ | 581.3 |  |

[0001327567-22-000028:notes:342]
Refer to Note 2. Revenue for revenue by geographic theater and revenue for groups of similar products and services for the years ended July 31, 2022, 2021, and 2020.


## us-gaap:SubsequentEventsTextBlock

[0001327567-22-000028:notes:343]
Subsequent Events
Share Repurchase

[0001327567-22-000028:notes:344]
On August 19, 2022, our board of directors authorized a $915.0 million increase to our share repurchase program under the current authorization, bringing the total remaining authorization for future share repurchases to $1.0 billion. Repurchases may be made at management’s discretion from time to time on the open market, through privately negotiated transactions, transactions structured through investment banking institutions, block purchase techniques, 10b5-1 trading plans, or a combination of the foregoing. The repurchase authorization will expire on December 31, 2023, and may be suspended or discontinued at any time without prior notice.

[0001327567-22-000028:notes:345]
Stock Split Effected in the Form of a Stock Dividend (“Stock Split”)

[0001327567-22-000028:notes:346]
On August 22, 2022, we announced that our board of directors had approved a three-for-one stock split of our outstanding shares of common stock to be effected in the form of a stock dividend. Each stockholder of record at the close of business on September 6, 2022 (the “record date”), will receive, after the close of business on September 13, 2022, two additional shares for every share held on the record date, and trading will begin on a split-adjusted basis on September 14, 2022.
