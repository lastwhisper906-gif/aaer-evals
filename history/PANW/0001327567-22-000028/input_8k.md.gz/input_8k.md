# PANW 8-K — 0001327567-22-000020 filed 2022-08-22

## item codes, every 8-K on or before 2022-09-06

- 2022-08-22 0001327567-22-000020 — 2.02, 8.01, 9.01
- 2022-05-23 0001193125-22-157474 — 5.02, 5.03, 9.01
- 2022-05-19 0001327567-22-000014 — 2.02, 9.01
- 2022-02-23 0001193125-22-049906 — 5.02
- 2022-02-22 0001327567-22-000006 — 2.02, 9.01
- 2021-12-15 0001193125-21-358074 — 5.02, 5.07
- 2021-11-18 0001327567-21-000037 — 2.02, 9.01
- 2021-10-12 0001193125-21-296438 — 3.01, 7.01, 9.01
- 2021-09-13 0001193125-21-270979 — 7.01, 9.01
- 2021-09-08 0001193125-21-267862 — 5.02, 9.01
- 2021-08-23 0001327567-21-000020 — 2.02, 9.01
- 2021-08-12 0001193125-21-244832 — 5.02, 9.01
- 2021-05-20 0001327567-21-000012 — 2.02, 9.01
- 2021-05-18 0001193125-21-164169 — 5.02 — amendment of 0001193125-21-162161
- 2021-05-14 0001193125-21-162161 — 5.02, 9.01
- 2021-03-19 0001193125-21-087516 — 5.02, 9.01
- 2021-02-22 0001628280-21-002659 — 2.02, 9.01
- 2021-02-22 0001193125-21-049293 — 5.02, 9.01
- 2020-12-18 0001193125-20-321568 — 8.01, 9.01
- 2020-12-16 0001193125-20-319091 — 3.02 — amendment of 0001193125-20-291707
- 2020-12-10 0001193125-20-314920 — 5.07
- 2020-12-08 0001193125-20-312056 — 5.02, 8.01, 9.01
- 2020-11-16 0001327567-20-000037 — 2.02, 9.01
- 2020-11-12 0001193125-20-291707 — 3.02
- 2020-10-19 0001193125-20-272060 — 5.02
- 2020-08-24 0001327567-20-000025 — 2.02, 9.01
- 2020-06-23 0001193125-20-176553 — 5.02, 9.01
- 2020-06-22 0001193125-20-175603 — 5.02, 9.01
- 2020-06-08 0001193125-20-163579 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2020-05-21 0001327567-20-000015 — 2.02, 9.01
- 2020-02-27 0001193125-20-050335 — 1.01, 2.03
- 2020-02-24 0001327567-20-000002 — 2.02, 9.01
- 2019-12-19 0001193125-19-319166 — 1.02, 9.01
- 2019-12-10 0001193125-19-310251 — 5.07
- 2019-11-25 0001327567-19-000036 — 2.02, 9.01
- 2019-11-25 0001193125-19-299886 — 5.02, 8.01 — amendment of 0001327567-19-000011
- 2019-10-22 0001193125-19-271660 — 5.02
- 2019-09-06 0001327567-19-000026 — 9.01 — amendment of 0001327567-19-000023
- 2019-09-04 0001327567-19-000023 — 2.02, 7.01, 9.01
- 2019-07-11 0001193125-19-192415 — 5.02, 9.01
- 2019-05-29 0001327567-19-000014 — 2.02, 9.01
- 2019-04-15 0001327567-19-000011 — 5.02, 9.01
- 2019-04-01 0001193125-19-094613 — 8.01, 9.01
- 2019-03-28 0001193125-19-090572 — 3.02 — amendment of 0001327567-19-000003
- 2019-02-26 0001327567-19-000006 — 2.02, 8.01, 9.01
- 2019-02-19 0001327567-19-000003 — 3.02
- 2018-12-11 0001327567-18-000033 — 5.07
- 2018-11-29 0001327567-18-000029 — 2.02, 9.01
- 2018-10-15 0001193125-18-299312 — 5.02, 9.01
- 2018-09-25 0001193125-18-282542 — 5.02
- 2018-09-14 0001193125-18-274239 — 5.03, 9.01
- 2018-09-06 0001327567-18-000018 — 1.01, 2.02, 2.03, 9.01
- 2018-07-13 0001193125-18-217281 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2018-06-04 0001327567-18-000011 — 2.02, 5.02, 9.01
- 2018-02-26 0001327567-18-000004 — 2.02, 5.02, 7.01, 9.01
- 2017-12-12 0001193125-17-367477 — 5.07
- 2017-11-20 0001327567-17-000032 — 2.02, 5.02, 9.01
- 2017-08-31 0001327567-17-000021 — 2.02, 5.02, 9.01
- 2017-05-31 0001327567-17-000016 — 2.02, 9.01
- 2017-02-28 0001327567-17-000005 — 2.02, 8.01, 9.01
- 2016-12-12 0001193125-16-790757 — 5.07
- 2016-11-21 0001327567-16-000071 — 2.02, 9.01
- 2016-10-24 0001193125-16-745121 — 5.02, 9.01
- 2016-08-30 0001327567-16-000057 — 2.02, 5.03, 8.01, 9.01
- 2016-08-22 0001193125-16-687588 — 5.02, 9.01
- 2016-05-26 0001327567-16-000051 — 2.02, 9.01
- 2016-02-25 0001327567-16-000044 — 2.02, 5.02, 9.01
- 2015-12-14 0001327567-15-000038 — 5.07
- 2015-12-14 0001193125-15-402588 — 1.01, 9.01
- 2015-11-23 0001327567-15-000033 — 2.02, 9.01
- 2015-10-19 0001193125-15-347005 — 1.01, 9.01 — amendment, the index does not say of what
- 2015-09-09 0001327567-15-000022 — 2.02, 9.01
- 2015-08-19 0001193125-15-296115 — 1.01, 2.03
- 2015-06-01 0001193125-15-207786 — 1.01, 2.03
- 2015-05-27 0001327567-15-000015 — 2.02, 9.01
- 2015-03-02 0001327567-15-000006 — 2.02, 9.01
- 2014-12-15 0001327567-14-000046 — 5.07
- 2014-11-24 0001327567-14-000040 — 2.02, 9.01
- 2014-09-22 0001193125-14-348581 — 5.02, 9.01
- 2014-09-09 0001327567-14-000025 — 2.02, 9.01
- 2014-07-01 0001193125-14-257824 — 1.01, 2.03, 3.02, 9.01
- 2014-06-26 0001193125-14-249529 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2014-06-20 0001327567-14-000020 — 9.01 — amendment of 0001193125-14-140511
- 2014-06-04 0001327567-14-000016 — 3.02
- 2014-05-30 0001193125-14-218158 — 2.02 — amendment, the index does not say of what
- 2014-05-28 0001193125-14-215060 — 1.01, 2.02, 3.02, 9.01
- 2014-04-11 0001193125-14-140511 — 2.01, 3.02, 7.01, 9.01
- 2014-03-24 0001193125-14-111318 — 1.01, 3.02, 7.01, 9.01
- 2014-03-13 0001327567-14-000009 — 5.02
- 2014-02-24 0001193125-14-063754 — 2.02, 9.01
- 2013-12-12 0001327567-13-000040 — 5.07
- 2013-11-25 0001327567-13-000033 — 2.02, 9.01
- 2013-09-30 0001193125-13-384966 — 8.01
- 2013-09-09 0001193125-13-361421 — 2.02, 9.01
- 2013-05-30 0001193125-13-241542 — 2.02, 5.02, 9.01
- 2013-03-11 0001193125-13-101082 — 5.02, 9.01
- 2013-02-28 0001193125-13-084193 — 2.02, 9.01
- 2012-12-14 0001193125-12-503335 — 5.07
- 2012-12-06 0001193125-12-493700 — 2.02, 9.01
- 2012-09-24 0001193125-12-401534 — 1.01, 2.03
- 2012-09-20 0001193125-12-398433 — 5.02, 9.01
- 2012-09-10 0001193125-12-386605 — 2.02, 9.01

## late-filing notifications on or before 2022-09-06

- none on or before 2022-09-06

## item 2.02 — earnings release, exhibit 99.1

[0001327567-22-000020:8k_2_02:1]
EX-99.1
2
ex991q422earningsrelease.htm
EX-99.1

[0001327567-22-000020:8k_2_02:2]
Document

[0001327567-22-000020:8k_2_02:3]
Exhibit 99.1

[0001327567-22-000020:8k_2_02:4]
Palo Alto Networks Reports Fiscal Fourth Quarter and Fiscal Year 2022 Financial Results

[0001327567-22-000020:8k_2_02:5]
•Fiscal fourth quarter revenue grew 27% year over year to $1.6 billion. Fiscal year 2022 revenue grew 29% year over year to $5.5 billion.

[0001327567-22-000020:8k_2_02:6]
•Fiscal fourth quarter billings grew 44% year over year to $2.7 billion. Fiscal year 2022 billings grew 37% year over year to $7.5 billion.

[0001327567-22-000020:8k_2_02:7]
•Remaining performance obligation grew 40% year over year to $8.2 billion.

[0001327567-22-000020:8k_2_02:8]
•Board of directors approved a three-for-one stock split.

[0001327567-22-000020:8k_2_02:9]
SANTA CLARA, Calif., Aug. 22, 2022 — Palo Alto Networks (NASDAQ: PANW), the global cybersecurity leader, announced today financial results for its fiscal fourth quarter and fiscal year 2022, ended July 31, 2022.

[0001327567-22-000020:8k_2_02:10]
Total revenue for the fiscal fourth quarter 2022 grew 27% year over year to $1.6 billion, compared with total revenue of $1.2 billion for the fiscal fourth quarter 2021. GAAP net income for the fiscal fourth quarter 2022 was $3.3 million, or $0.03 per basic and diluted share, compared with GAAP net loss of $119.3 million, or $1.23 per diluted share, for the fiscal fourth quarter 2021.

[0001327567-22-000020:8k_2_02:11]
Non-GAAP net income for the fiscal fourth quarter 2022 was $254.1 million, or $2.39 per diluted share, compared with non-GAAP net income of $161.9 million, or $1.60 per diluted share, for the fiscal fourth quarter 2021. A reconciliation between GAAP and non-GAAP information is contained in the tables below.

[0001327567-22-000020:8k_2_02:12]
“We were pleased by our fourth quarter results, which included GAAP profitability for the first time in four years. Next-Generation Security growth, driven by our rapid pace of innovation and strong sales execution, drove our results,” said Nikesh Arora, chairman and CEO of Palo Alto Networks. “As cybersecurity posture remains critical, our integrated three-platform strategy continues to drive large deal momentum as we consolidate and simplify our customers’ security architectures.”

[0001327567-22-000020:8k_2_02:13]
“Our focus on maximizing total shareholder return in any environment was exhibited by strong revenue and billings growth, paired with non-GAAP operating margin and non-GAAP adjusted free cash flow margin expansion in fiscal year 2022,” said Dipak Golechha, chief financial officer of

[0001327567-22-000020:8k_2_02:14]
Palo Alto Networks. “As we enter fiscal year 2023, we look forward to again delivering this balance of growth and margin expansion, while also achieving GAAP profitability for the year.”

[0001327567-22-000020:8k_2_02:15]
Stock Split Authorization

[0001327567-22-000020:8k_2_02:16]
Palo Alto Networks announced that the board of directors has approved and declared a three-for-one split of Palo Alto Networks’ common stock in the form of a stock dividend. Each stockholder of record at the close of business on September 6, 2022 (the “record date”), will receive, after the close of business on September 13, 2022, two additional shares for every share held on the record date, and trading will begin on a split-adjusted basis on September 14, 2022.

[0001327567-22-000020:8k_2_02:17]
Financial Outlook

[0001327567-22-000020:8k_2_02:18]
Palo Alto Networks provides guidance based on current market conditions and expectations.

[0001327567-22-000020:8k_2_02:19]
For the fiscal first quarter 2023, we expect:

[0001327567-22-000020:8k_2_02:20]
•Total billings in the range of $1.68 billion to $1.70 billion, representing year-over-year growth of between 22% and 23%.

[0001327567-22-000020:8k_2_02:21]
•Total revenue in the range of $1.535 billion to $1.555 billion, representing year-over-year growth of between 23% and 25%.

[0001327567-22-000020:8k_2_02:22]
•Diluted non-GAAP net income per share in the range of $2.03 to $2.06, using 108 million to 110 million shares outstanding.

[0001327567-22-000020:8k_2_02:23]
For the fiscal year 2023, we expect:

[0001327567-22-000020:8k_2_02:24]
•Total billings in the range of $8.95 billion to $9.05 billion, representing year-over-year growth of between 20% and 21%.

[0001327567-22-000020:8k_2_02:25]
•Total revenue in the range of $6.85 billion to $6.90 billion, representing year-over-year growth of 25%.

[0001327567-22-000020:8k_2_02:26]
•Diluted non-GAAP net income per share in the range of $9.40 to $9.50, using 111 million to 113 million shares outstanding.

[0001327567-22-000020:8k_2_02:27]
•Adjusted free cash flow margin in the range of 33.5% to 34.5%.

[0001327567-22-000020:8k_2_02:28]
•Achieve positive GAAP net income.

[0001327567-22-000020:8k_2_02:29]
The board of directors authorized an additional $915 million for share repurchase, increasing the remaining authorization for future share repurchases to $1 billion, expiring December 31, 2023.

[0001327567-22-000020:8k_2_02:30]
Guidance for non-GAAP financial measures excludes share-based compensation-related charges (including share-based payroll tax expense), acquisition-related costs, amortization expense of acquired intangible assets, litigation-related charges, including legal settlements, restructuring and other costs, non-cash charges related to convertible notes, and foreign currency gains (losses) and income and other tax effects associated with these items, along with certain non-recurring expenses and certain non-recurring cash flows. We have not reconciled diluted non-GAAP net income per share guidance to GAAP net income (loss) per diluted share or adjusted free cash flow margin guidance to GAAP net cash from operating activities because we do not provide guidance on GAAP net income (loss) or net cash from operating activities and would not be able to present the various reconciling cash and non-cash items between GAAP and non-GAAP financial measures because certain items that impact these measures are uncertain or out of our control, or cannot be reasonably predicted, including share-based compensation expense, without unreasonable effort. The actual amounts of such reconciling items will have a significant impact on the company's GAAP net income (loss) per diluted share and GAAP net cash from operating activities.

[0001327567-22-000020:8k_2_02:31]
Earnings Call Information

[0001327567-22-000020:8k_2_02:32]
Palo Alto Networks will host a video webcast for analysts and investors to discuss the company’s fiscal fourth quarter and fiscal year 2022 results as well as the outlook for its fiscal first quarter and fiscal year 2023 today at 4:30 p.m. Eastern time/1:30 p.m. Pacific time. Open to the public, investors may access the webcast, supplemental financial information and earnings slides from the “Investors” section of the company’s website at investors.paloaltonetworks.com. A replay will be available three hours after the conclusion of the webcast and archived for one year.

[0001327567-22-000020:8k_2_02:33]
Forward-Looking Statements

[0001327567-22-000020:8k_2_02:34]
This press release contains forward-looking statements that involve risks, uncertainties, and assumptions including statements regarding our ability to balance future revenue growth with operating margin and free cash flow margin expansion, achieve GAAP profitability for the year and our financial outlook for the fiscal first quarter 2023 and fiscal year 2023. There are a significant number of factors that could cause actual results to differ materially from statements made in this press release, including: the effects of supply chain constraints and the global chip and component shortages and other factors affecting the manufacture, delivery, and cost of certain of our products; developments and changes in general market, political, economic, and business conditions; the duration and global impact of COVID-19; risks associated with managing our

[0001327567-22-000020:8k_2_02:35]
3

[0001327567-22-000020:8k_2_02:36]
growth; risks associated with new products and subscription and support offerings, including the discovery of software bugs; shifts in priorities or delays in the development or release of new subscription offerings, or the failure to timely develop and achieve market acceptance of new products and subscriptions as well as existing products and subscription and support offerings; rapidly evolving technological developments in the market for security products and subscription and support offerings; our customers’ purchasing decisions and the length of sales cycles; our competition; our ability to attract and retain new customers; our ability as an organization to acquire and integrate other companies, products, or technologies in a successful manner; our debt repayment obligations; and our share repurchase program, which may not be fully consummated or enhance shareholder value, and any share repurchases which could affect the price of our common stock.

[0001327567-22-000020:8k_2_02:37]
Additional risks and uncertainties that could affect our financial results are included under the captions "Risk Factors" and "Management's Discussion and Analysis of Financial Condition and Results of Operations" in our Quarterly Report on Form 10-Q filed with the SEC on May 19, 2022, which is available on our website at investors.paloaltonetworks.com and on the SEC's website at www.sec.gov. Additional information will also be set forth in other filings that we make with the SEC from time to time. All forward-looking statements in this press release are based on information available to us as of the date hereof, and we do not assume any obligation to update the forward-looking statements provided to reflect events that occur or circumstances that exist after the date on which they were made.

[0001327567-22-000020:8k_2_02:38]
Non-GAAP Financial Measures and Other Key Metrics

[0001327567-22-000020:8k_2_02:39]
Palo Alto Networks has provided in this press release financial information that has not been prepared in accordance with generally accepted accounting principles in the United States (GAAP). The company uses these non-GAAP financial measures and other key metrics internally in analyzing its financial results and believes that the use of these non-GAAP financial measures and key metrics are useful to investors as an additional tool to evaluate ongoing operating results and trends, and in comparing the company’s financial results with other companies in its industry, many of which present similar non-GAAP financial measures or key metrics.

[0001327567-22-000020:8k_2_02:40]
The presentation of these non-GAAP financial measures and key metrics are not meant to be considered in isolation or as a substitute for comparable GAAP financial measures and should be read only in conjunction with the company’s consolidated financial statements prepared in

[0001327567-22-000020:8k_2_02:41]
accordance with GAAP. A reconciliation of the company’s historical non-GAAP financial measures to their most directly comparable GAAP measures has been provided in the financial statement tables included in this press release, and investors are encouraged to review these reconciliations.

[0001327567-22-000020:8k_2_02:42]
Non-GAAP net income and net income per share, diluted. Palo Alto Networks defines non-GAAP net income as net income (loss) plus share-based compensation-related charges, including share-based payroll tax expense, acquisition-related costs, amortization expense of acquired intangible assets, litigation-related charges, including legal settlements, restructuring and other costs, and non-cash charges related to convertible notes. The company also excludes from non-GAAP net income foreign currency gains (losses) and tax effects associated with these items in order to provide a complete picture of the company’s recurring core business operating results. The company defines non-GAAP net income per share, diluted, as non-GAAP net income divided by the weighted-average diluted shares outstanding, which includes the potentially dilutive effect of the company’s employee equity incentive plan awards and the company’s convertible senior notes outstanding and related warrants, after giving effect to the anti-dilutive impact of the company’s note hedge agreements, which reduces the potential economic dilution that otherwise would occur upon conversion of the company’s convertible senior notes. Under GAAP, the anti-dilutive impact of the note hedge is not reflected in diluted shares outstanding. The company believes that excluding these items from non-GAAP net income and net income per share, diluted, provides management and investors with greater visibility into the underlying performance of the company’s core business operating results, meaning its operating performance excluding these items and, from time to time, other discrete charges that are infrequent in nature, over multiple periods.

[0001327567-22-000020:8k_2_02:43]
Billings. Palo Alto Networks defines billings as total revenue plus the change in total deferred revenue, net of acquired deferred revenue, during the period. The company considers billings to be a key metric used by management to manage the company’s business and believes billings provides investors with an important indicator of the health and visibility of the company’s business because it includes subscription and support revenue, which is recognized ratably over the contractual service period, and product revenue, which is recognized at the time of shipment, provided that all other conditions for revenue recognition have been met. The company considers billings to be a useful metric for management and investors, particularly if sales of subscriptions continue to increase and the company experiences strong renewal rates for subscriptions and support.

[0001327567-22-000020:8k_2_02:44]
5

[0001327567-22-000020:8k_2_02:45]
Investors are cautioned that there are a number of limitations associated with the use of non-GAAP financial measures and key metrics as analytical tools. In particular, the billings metric reported by the company includes amounts that have not yet been recognized as revenue. Additionally, many of the adjustments to the company’s GAAP financial measures reflect the exclusion of items that are recurring and will be reflected in the company’s financial results for the foreseeable future, such as share-based compensation, which is an important part of Palo Alto Networks employees’ compensation and impacts their performance. Furthermore, these non-GAAP financial measures are not based on any standardized methodology prescribed by GAAP, and the components that Palo Alto Networks excludes in its calculation of non-GAAP financial measures may differ from the components that its peer companies exclude when they report their non-GAAP results of operations. Palo Alto Networks compensates for these limitations by providing specific information regarding the GAAP amounts excluded from these non-GAAP financial measures. In the future, the company may also exclude non-recurring expenses and other expenses that do not reflect the company’s core business operating results.

[0001327567-22-000020:8k_2_02:46]
About Palo Alto Networks

[0001327567-22-000020:8k_2_02:47]
Palo Alto Networks is the world’s cybersecurity leader. We innovate to outpace cyberthreats, so organizations can embrace technology with confidence. We provide next-gen cybersecurity to thousands of customers globally, across all sectors. Our best-in-class cybersecurity platforms and services are backed by industry-leading threat intelligence and strengthened by state-of-the-art automation. Whether deploying our products to enable the Zero Trust Enterprise, responding to a security incident, or partnering to deliver better security outcomes through a world-class partner ecosystem, we’re committed to helping ensure each day is safer than the one before. It’s what makes us the cybersecurity partner of choice.

[0001327567-22-000020:8k_2_02:48]
At Palo Alto Networks, we’re committed to bringing together the very best people in service of our mission, so we’re also proud to be the cybersecurity workplace of choice, recognized among Newsweek’s Most Loved Workplaces (2021), Comparably Best Companies for Diversity (2021), and HRC Best Places for LGBTQ Equality (2022). For more information, visit www.paloaltonetworks.com.

[0001327567-22-000020:8k_2_02:49]
Palo Alto Networks and the Palo Alto Networks logo are trademarks of Palo Alto Networks, Inc. in the United States and in jurisdictions throughout the world. All other trademarks, trade names, or service marks used or mentioned herein belong to their respective owners.

[0001327567-22-000020:8k_2_02:50]
Media Contact:

[0001327567-22-000020:8k_2_02:51]
Andria Leaf

[0001327567-22-000020:8k_2_02:52]
Director of Corporate Communications, Palo Alto Networks

[0001327567-22-000020:8k_2_02:53]
press@paloaltonetworks.com

[0001327567-22-000020:8k_2_02:54]
Investor Relations Contact:

[0001327567-22-000020:8k_2_02:55]
Clay Bilby

[0001327567-22-000020:8k_2_02:56]
Head of Investor Relations, Palo Alto Networks

[0001327567-22-000020:8k_2_02:57]
ir@paloaltonetworks.com

[0001327567-22-000020:8k_2_02:58]
| Palo Alto Networks, Inc. |
| Preliminary Condensed Consolidated Statements of Operations |
| (In millions, except per share data) |
| (Unaudited) |
|  | Three Months Ended |  | Year Ended |
|  | July 31, |  | July 31, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Revenue: |  |  |  |  |  |  |  |
| Product | $ | 408.1 |  |  | $ | 339.4 |  |  | $ | 1,363.1 |  |  | $ | 1,120.3 |  |
| Subscription and support | 1,142.4 |  |  | 879.9 |  |  | 4,138.4 |  |  | 3,135.8 |  |
| Total revenue | 1,550.5 |  |  | 1,219.3 |  |  | 5,501.5 |  |  | 4,256.1 |  |
| Cost of revenue: |  |  |  |  |  |  |  |
| Product | 142.8 |  |  | 88.8 |  |  | 455.5 |  |  | 308.5 |  |
| Subscription and support | 349.5 |  |  | 270.1 |  |  | 1,263.2 |  |  | 966.4 |  |
| Total cost of revenue | 492.3 |  |  | 358.9 |  |  | 1,718.7 |  |  | 1,274.9 |  |
| Total gross profit | 1,058.2 |  |  | 860.4 |  |  | 3,782.8 |  |  | 2,981.2 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 363.8 |  |  | 325.3 |  |  | 1,417.7 |  |  | 1,140.4 |  |
| Sales and marketing | 570.6 |  |  | 489.8 |  |  | 2,148.9 |  |  | 1,753.8 |  |
| General and administrative | 108.4 |  |  | 105.7 |  |  | 405.0 |  |  | 391.1 |  |
| Total operating expenses | 1,042.8 |  |  | 920.8 |  |  | 3,971.6 |  |  | 3,285.3 |  |
| Operating income (loss) | 15.4 |  |  | (60.4) |  |  | (188.8) |  |  | (304.1) |  |
| Interest expense | (6.9) |  |  | (41.4) |  |  | (27.4) |  |  | (163.3) |  |
| Other income (expense), net | 8.8 |  |  | (0.5) |  |  | 9.0 |  |  | 2.4 |  |
| Income (loss) before income taxes | 17.3 |  |  | (102.3) |  |  | (207.2) |  |  | (465.0) |  |
| Provision for income taxes | 14.0 |  |  | 17.0 |  |  | 59.8 |  |  | 33.9 |  |
| Net income (loss) | $ | 3.3 |  |  | $ | (119.3) |  |  | $ | (267.0) |  |  | $ | (498.9) |  |
| Net income (loss) per share, basic | $ | 0.03 |  |  | $ | (1.23) |  |  | $ | (2.71) |  |  | $ | (5.18) |  |
| Weighted-average shares used to compute net income (loss) per share, basic | 99.5 |  |  | 97.2 |  |  | 98.5 |  |  | 96.4 |  |
| Net income (loss) per share, diluted | $ | 0.03 |  |  | $ | (1.23) |  |  | $ | (2.71) |  |  | $ | (5.18) |  |
| Weighted-average shares used to compute net income (loss) per share, diluted | 112.1 |  |  | 97.2 |  |  | 98.5 |  |  | 96.4 |  |

[0001327567-22-000020:8k_2_02:59]
8

[0001327567-22-000020:8k_2_02:60]
| Palo Alto Networks, Inc. |
| Reconciliation of GAAP to Non-GAAP Financial Measures |
| (In millions, except per share amounts) |
| (Unaudited) |
|  | Three Months Ended |  | Year Ended |
|  | July 31, |  | July 31, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| GAAP net income (loss) | $ | 3.3 |  |  | $ | (119.3) |  |  | $ | (267.0) |  |  | $ | (498.9) |  |
| Share-based compensation-related charges | 251.3 |  |  | 239.2 |  |  | 1,072.0 |  |  | 936.5 |  |
| Acquisition-related costs(1) | 2.4 |  |  | 0.7 |  |  | 5.5 |  |  | 46.1 |  |
| Amortization expense of acquired intangible assets | 31.2 |  |  | 31.6 |  |  | 125.8 |  |  | 116.7 |  |
| Litigation-related charges(2) | 1.7 |  |  | 1.7 |  |  | 7.1 |  |  | 7.1 |  |
| Restructuring and other costs(3) | 21.2 |  |  | — |  |  | 21.2 |  |  | — |  |
| Non-cash charges related to convertible notes(4) | 1.8 |  |  | 36.4 |  |  | 7.2 |  |  | 142.9 |  |
| Foreign currency (gain) loss associated with non-GAAP adjustments | (1.0) |  |  | 0.2 |  |  | (2.7) |  |  | 2.4 |  |
| Income tax and other tax adjustments related to the above | (57.8) |  |  | (28.6) |  |  | (166.6) |  |  | (139.1) |  |
| Non-GAAP net income | $ | 254.1 |  |  | $ | 161.9 |  |  | $ | 823.7 |  |  | $ | 613.7 |  |
| GAAP net income (loss) per share, diluted | $ | 0.03 |  |  | $ | (1.23) |  |  | $ | (2.71) |  |  | $ | (5.18) |  |
| Share-based compensation-related charges | 2.36 |  |  | 2.39 |  |  | 10.29 |  |  | 9.50 |  |
| Acquisition-related costs(1) | 0.02 |  |  | 0.01 |  |  | 0.06 |  |  | 0.48 |  |
| Amortization expense of acquired intangible assets | 0.28 |  |  | 0.33 |  |  | 1.28 |  |  | 1.21 |  |
| Litigation-related charges(2) | 0.02 |  |  | 0.02 |  |  | 0.07 |  |  | 0.07 |  |
| Restructuring and other costs(3) | 0.19 |  |  | 0.00 |  |  | 0.22 |  |  | 0.00 |  |
| Non-cash charges related to convertible notes(4) | 0.02 |  |  | 0.37 |  |  | 0.07 |  |  | 1.48 |  |
| Foreign currency (gain) loss associated with non-GAAP adjustments | (0.01) |  |  | 0.00 |  |  | (0.03) |  |  | 0.02 |  |
| Income tax and other tax adjustments related to the above | (0.52) |  |  | (0.29) |  |  | (1.69) |  |  | (1.44) |  |
| Non-GAAP net income per share, diluted | $ | 2.39 |  |  | $ | 1.60 |  |  | $ | 7.56 |  |  | $ | 6.14 |  |
| GAAP weighted-average shares used to compute net income (loss) per share, diluted | 112.1 |  |  | 97.2 |  |  | 98.5 |  |  | 96.4 |  |
| Weighted-average effect of potentially dilutive securities(5) | (5.7) |  |  | 4.2 |  |  | 7.6 |  |  | 3.5 |  |
| Non-GAAP weighted-average shares used to compute net income per share, diluted | 106.4 |  |  | 101.4 |  |  | 106.1 |  |  | 99.9 |  |

[0001327567-22-000020:8k_2_02:61]
(1)    Consists of acquisition transaction costs, share-based compensation related to the cash settlement of certain equity awards, and costs to terminate certain employment, operating lease, and other contracts of the acquired companies.

[0001327567-22-000020:8k_2_02:62]
(2)    Consists of the amortization of intellectual property licenses and covenant not to sue.

[0001327567-22-000020:8k_2_02:63]
(3)    Consists of manufacturing related charges, loss on the closure of an office facility, and other costs.

[0001327567-22-000020:8k_2_02:64]
(4)     Consists primarily of non-cash interest expense for amortization of debt discount and issuance costs related to the company's convertible senior notes. Effective Q1'22, the company no longer recognizes interest expense for amortization of debt discount as a result of the adoption of new debt guidance.

[0001327567-22-000020:8k_2_02:65]
(5)    Potentially dilutive securities include the dilutive effect of employee equity incentive plan awards and convertible senior notes outstanding and related warrants for the fiscal year ended July 31, 2022, the fiscal fourth quarter and fiscal year ended July 31, 2021. Potentially dilutive securities for all periods presented are offset by the anti-dilutive impact of the company’s note hedge agreements, which reduced the potentially dilutive effect of the convertible notes by 5.7 million and

[0001327567-22-000020:8k_2_02:66]
5.8 million for the fiscal fourth quarter and fiscal year ended July 31, 2022, respectively, and 3.5 million and 2.1 million for the fiscal fourth quarter and fiscal year ended July 31, 2021, respectively.

[0001327567-22-000020:8k_2_02:67]
| Palo Alto Networks, Inc. |
| Calculation of Billings |
| (In millions) |
| (Unaudited) |
|  | Three Months Ended |  | Year Ended |
|  | July 31, |  | July 31, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Total revenue | $ | 1,550.5 |  |  | $ | 1,219.3 |  |  | $ | 5,501.5 |  |  | $ | 4,256.1 |  |
| Add: change in total deferred revenue, net of acquired deferred revenue | 1,134.6 |  |  | 649.0 |  |  | 1,970.0 |  |  | 1,196.1 |  |
| Billings | $ | 2,685.1 |  |  | $ | 1,868.3 |  |  | $ | 7,471.5 |  |  | $ | 5,452.2 |  |

[0001327567-22-000020:8k_2_02:68]
10

[0001327567-22-000020:8k_2_02:69]
| Palo Alto Networks, Inc. |
| Preliminary Condensed Consolidated Balance Sheets |
| (In millions) |
|  | July 31, 2022 |  | July 31, 2021 |
|  | (unaudited) |  |  |
| Assets |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 2,118.5 |  |  | $ | 1,874.2 |  |
| Short-term investments | 1,516.0 |  |  | 1,026.9 |  |
| Accounts receivable, net | 2,142.5 |  |  | 1,240.4 |  |
| Short-term deferred contract costs | 317.7 |  |  | 276.5 |  |
| Prepaid expenses and other current assets | 320.2 |  |  | 229.3 |  |
| Total current assets | 6,414.9 |  |  | 4,647.3 |  |
| Property and equipment, net | 357.8 |  |  | 318.4 |  |
| Operating lease right-of-use assets | 242.0 |  |  | 262.9 |  |
| Long-term investments | 1,051.9 |  |  | 888.3 |  |
| Long-term deferred contract costs | 550.1 |  |  | 494.6 |  |
| Goodwill | 2,747.7 |  |  | 2,710.1 |  |
| Intangible assets, net | 384.5 |  |  | 498.6 |  |
| Other assets | 504.7 |  |  | 421.4 |  |
| Total assets | $ | 12,253.6 |  |  | $ | 10,241.6 |  |
| Liabilities, temporary equity and stockholders’ equity |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 128.0 |  |  | $ | 56.9 |  |
| Accrued compensation | 461.1 |  |  | 430.6 |  |
| Accrued and other liabilities | 399.2 |  |  | 329.4 |  |
| Deferred revenue | 3,641.2 |  |  | 2,741.9 |  |
| Convertible senior notes, net | 3,676.8 |  |  | 1,557.9 |  |
| Total current liabilities | 8,306.3 |  |  | 5,116.7 |  |
| Convertible senior notes, net | — |  |  | 1,668.1 |  |
| Long-term deferred revenue | 3,352.8 |  |  | 2,282.1 |  |
| Long-term operating lease liabilities | 276.1 |  |  | 313.4 |  |
| Other long-term liabilities | 108.4 |  |  | 97.7 |  |
| Total liabilities | 12,043.6 |  |  | 9,478.0 |  |
| Temporary equity | — |  |  | 129.1 |  |
| Stockholders’ equity: |  |  |  |
| Preferred stock | — |  |  | — |  |
| Common stock and additional paid-in capital | 1,932.7 |  |  | 2,311.2 |  |
| Accumulated other comprehensive loss | (55.6) |  |  | (9.9) |  |
| Accumulated deficit | (1,667.1) |  |  | (1,666.8) |  |
| Total stockholders’ equity | 210.0 |  |  | 634.5 |  |
| Total liabilities, temporary equity and stockholders’ equity | $ | 12,253.6 |  |  | $ | 10,241.6 |  |

[0001327567-22-000020:8k_2_02:70]
11
