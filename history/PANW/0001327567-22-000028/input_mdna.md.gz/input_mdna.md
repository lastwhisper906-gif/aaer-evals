# PANW MD&A — 0001327567-22-000028


## mdna

[0001327567-22-000028:mdna:1]
ITEM 7.     MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS

[0001327567-22-000028:mdna:2]
The following discussion and analysis of our financial condition and results of operations should be read in conjunction with our consolidated financial statements and related notes appearing elsewhere in this Annual Report on Form 10-K. The following discussion and analysis contains forward-looking statements based on current expectations and assumptions that are subject to risks and uncertainties, which could cause our actual results to differ materially from those anticipated or implied by any forward-looking statements. Factors that could cause or contribute to such differences include, but are not limited to, those discussed in this Annual Report on Form 10-K, and in particular, the risks discussed under the caption “Risk Factors” in Part I, Item 1A of this report.

[0001327567-22-000028:mdna:3]
Our Management’s Discussion and Analysis of Financial Condition and Results of Operations (“MD&A”) is organized as follows:

[0001327567-22-000028:mdna:4]
•Overview. A discussion of our business and overall analysis of financial and other highlights in order to provide context for the remainder of MD&A.

[0001327567-22-000028:mdna:5]
•Key Financial Metrics. A summary of our GAAP and non-GAAP key financial metrics, which management monitors to evaluate our performance.

[0001327567-22-000028:mdna:6]
•Results of Operations. A discussion of the nature and trends in our financial results and an analysis of our financial results comparing fiscal 2022 to fiscal 2021. For discussion and analysis related to our financial results comparing fiscal 2021 to 2020, refer to Part II, Item 7. Management’s Discussion and Analysis of Financial Condition and Results of Operations in our Annual Report on Form 10-K for fiscal 2021, which was filed with the Securities and Exchange Commission on September 3, 2021.

[0001327567-22-000028:mdna:7]
•Liquidity and Capital Resources. An analysis of changes on our balance sheets and cash flows, and a discussion of our financial condition and our ability to meet cash needs.

[0001327567-22-000028:mdna:8]
•Contractual Obligations and Commitments. An overview of our contractual obligations, contingent liabilities, commitments, and off-balance sheet arrangements outstanding as of July 31, 2022, including expected payment schedules.

[0001327567-22-000028:mdna:9]
•Critical Accounting Estimates. A discussion of our accounting policies that require critical estimates, assumptions, and judgments.

[0001327567-22-000028:mdna:10]
•Recent Accounting Pronouncements. A discussion of expected impacts of impending accounting changes on financial information to be reported in the future.

[0001327567-22-000028:mdna:11]
Overview

[0001327567-22-000028:mdna:12]
We empower enterprises, organizations, service providers, and government entities to protect themselves against today’s most sophisticated cyber threats. Our cybersecurity platforms and services help secure enterprise users, networks, clouds, and endpoints by delivering comprehensive cybersecurity backed by industry leading artificial intelligence and automation. We are a leading provider of zero trust solutions that start with the next-generation of zero trust network access to secure remote workforces and extend into securing all users, applications and infrastructure with zero trust principles. Our security solutions are designed to reduce customers’ total cost of ownership by improving operational efficiency and eliminating the need for siloed point products. Our company focuses on delivering value in five fundamental areas:

[0001327567-22-000028:mdna:13]
Network Security:

[0001327567-22-000028:mdna:14]
•Our network security platform, which includes our ML-Powered Next-Generation Firewalls, available in a number of form factors, including physical, virtual, and containerized appliances, as well as a cloud-delivered service, has been a leader in the industry for ten consecutive years. Our network security platform also includes our Cloud-Delivered Security Services, such as Threat Prevention, Advanced Threat Prevention, WildFire®, Advanced URL Filtering, DNS Security, IoT Security, GlobalProtect™, SD-WAN, Enterprise Data Loss Prevention (“Enterprise DLP”), SaaS Security API and SaaS Security Inline. Through these add-on security services, our customers are able to secure their content, applications, users, and devices across our network security platform as well as the Prisma® and Cortex® product lines. Panorama™, our network security management solution, available as hardware or virtual machine, can centrally manage our network security platform irrespective of form factor, location, or scale.

[0001327567-22-000028:mdna:15]
- 43 -

[0001327567-22-000028:mdna:16]
Secure Access Service Edge:

[0001327567-22-000028:mdna:17]
•Prisma Access is our next-generation Zero Trust Network Access (“ZTNA”) platform that provides secure network access for all employees with unified policy management and continuous threat inspection. We have recently introduced ZTNA 2.0, which addresses major shortcomings in the first-generation ZTNA products in the industry (which we refer to as ZTNA 1.0). Prisma Access delivers granular least-privileged access along with continuous trust verification and security inspection and protects security for all applications and data across the enterprise infrastructure. Prisma Access, when combined with Prisma SD-WAN, provides a comprehensive single-vendor Secure Access Service Edge (“SASE”) offering that is used to secure remote workforces and enable the cloud-delivered branch.

[0001327567-22-000028:mdna:18]
Cloud Security:

[0001327567-22-000028:mdna:19]
•We enable cloud native security through our Prisma Cloud platform. As a comprehensive Cloud Native Application Protection Platform (“CNAPP”), Prisma Cloud secures hybrid and multi-cloud environments for applications, data, and the entire cloud native technology stack across the full development lifecycle; from code to runtime. For inline network security on multi and hybrid-cloud environments, we also offer our VM-Series and CN-Series Firewall offerings.

[0001327567-22-000028:mdna:20]
Security Operations:

[0001327567-22-000028:mdna:21]
•We deliver the next generation of endpoint security, security analytics and security automation solutions through our Cortex portfolio. These include our industry-leading extended detection and response platform Cortex XDR® to prevent, detect, and respond to complex cybersecurity attacks, Cortex XSOAR® for security orchestration, automation, and response (“SOAR”), Cortex Xpanse® for attack surface management (“ASM”) and Cortex Data Lake allowing our customers to collect and analyze large amounts of context-rich data across endpoints, networks, and clouds. These products are delivered as software or SaaS subscriptions.

[0001327567-22-000028:mdna:22]
Threat Intelligence and Security Consulting (Unit 42):

[0001327567-22-000028:mdna:23]
•We enable security teams with up-to-date threat intelligence and deep cybersecurity expertise before, during and after attacks through our Unit 42 threat research and security consulting team. Unit 42 offers incident response, risk management, board advisory and proactive cybersecurity assessment services.

[0001327567-22-000028:mdna:24]
For fiscal 2022 and 2021, total revenue was $5.5 billion and $4.3 billion, respectively, representing year-over-year growth of 29.3%. Our growth reflects the increased adoption of our portfolio, which consists of product, subscriptions, and support. We believe our portfolio will enable us to benefit from recurring revenues and new revenues as we continue to grow our end-customer base. As of July 31, 2022, we had end-customers in over 180 countries. Our end-customers represent a broad range of industries, including education, energy, financial services, government entities, healthcare, Internet and media, manufacturing, public sector, and telecommunications, and include almost all of the Fortune 100 companies and a majority of the Global 2000 companies in the world. We maintain a field sales force that works closely with our channel partners in developing sales opportunities. We primarily use a two-tiered, indirect fulfillment model whereby we sell our products, subscriptions, and support to our distributors, which, in turn, sell to our resellers, which then sell to our end-customers.

[0001327567-22-000028:mdna:25]
Our product revenue grew to $1.4 billion or 24.8% of total revenue for fiscal 2022, representing year-over-year growth of 21.7%. Product revenue is primarily generated from sales of our appliances, primarily our ML-Powered Next-Generation Firewall, which is available in a number of form factors, including as physical, virtual, and containerized appliances. Our ML-Powered Next-Generation Firewall incorporates our PAN-OS operating system, which provides a consistent set of capabilities across our entire network security product line. Our products are designed for different performance requirements throughout an organization, ranging from our PA-410, which is designed for small organizations and remote or branch offices, to our top-of-the-line PA-7080, which is designed for large-scale data centers and service provider use. The same firewall functionality that is delivered in our physical appliances is also available in our VM-Series virtual firewalls, which secure virtualized and cloud-based computing environments, and in our CN-Series container firewalls, which secure container environments and traffic.

[0001327567-22-000028:mdna:26]
Our subscription and support revenue grew to $4.1 billion or 75.2% of total revenue for fiscal 2022, representing year-over-year growth of 32.0%. Our subscriptions provide our end-customers with near real-time access to the latest antivirus, intrusion prevention, web filtering, modern malware prevention, data loss prevention, and cloud access security broker capabilities across the network, endpoints, and the cloud. When end-customers purchase our physical, virtual, or container firewall appliances, or certain cloud offerings, they typically purchase support in order to receive ongoing security updates, upgrades, bug fixes, and repairs. In addition to the subscriptions purchased with these appliances, end-customers may also purchase other subscriptions on a per-user, per-endpoint, or capacity-based basis. We also offer professional services, including incident response, risk management, and digital forensic services.

[0001327567-22-000028:mdna:27]
We continue to invest in innovation as we evolve and further extend the capabilities of our portfolio, as we believe that innovation and timely development of new features and products are essential to meeting the needs of our end-customers and improving our competitive position. During fiscal 2022, we introduced several new offerings, including: Prisma Cloud 3.0, Prisma Access 3.0, AIOps for NGFW, PAN-OS 10.2, and Cloud NGFW for AWS.

[0001327567-22-000028:mdna:28]
- 44 -

[0001327567-22-000028:mdna:29]
We believe that the growth of our business and our short-term and long-term success are dependent upon many factors, including our ability to extend our technology leadership, grow our base of end-customers, expand deployment of our portfolio and support offerings within existing end-customers, and focus on end-customer satisfaction. To manage any future growth effectively, we must continue to improve and expand our information technology and financial infrastructure, our operating and administrative systems and controls, and our ability to manage headcount, capital, and processes in an efficient manner. While these areas present significant opportunities for us, they also pose challenges and risks that we must successfully address in order to sustain the growth of our business and improve our operating results. For additional information regarding the challenges and risks we face, see the “Risk Factors” section in Part I, Item 1A of this Annual Report on Form 10-K.

[0001327567-22-000028:mdna:30]
Impact of COVID-19 and Other Macroeconomic Factors on Our Business

[0001327567-22-000028:mdna:31]
We are actively monitoring, evaluating, and responding to developments relating to COVID-19, which has resulted in and is expected to continue to result in significant global, social, and business disruption. While we instituted a global work-from-home policy beginning in March 2020, which has been modified to provide employees with the choice to work in our offices for a set number of days per week or completely remotely, we did not experience significant disruption in our work operations during fiscal 2022. We will continue to actively monitor the situation, including progress made through vaccinations, and we will make further changes to our business operations as may be required by federal, state, or local authorities or that we determine are in the best interests of our employees, end-customers, partners, suppliers, and stockholders. Our focus remains on the safety of our employees, and we strive to protect the health and well-being of the communities in which we operate, in part, by providing technology to our employees, end-customers, and partners to help them do their best work while working remotely.

[0001327567-22-000028:mdna:32]
COVID-19 has affected our end-customers’ spending and could lead them to delay or defer purchasing decisions, and lengthen sales cycles and payment terms, which could materially adversely impact our business, results of operations, and overall financial performance. The extent of the impact of COVID-19 on our operational and financial performance will depend on developments, including the duration and spread of the virus and its variants, impact on our end-customers’ spending, volume of sales and length of our sales cycles, impact on our partners, suppliers, and employees, actions that may be taken by governmental authorities, and other factors identified in Part I, Item 1A “Risk Factors” in this Form 10-K. The global supply chain and the semiconductor industry are experiencing significant challenges. We have seen supply chain challenges increase, including chip and component shortages, which have, in certain cases, caused delays for us in acquiring chips, components and inventory and have resulted in increased costs as compared to historic levels. While we incurred increased costs and experienced increased lead time for certain product deliveries to our end-customers, we continue to work to minimize the effects from supply chain challenges.

[0001327567-22-000028:mdna:33]
In addition, our overall performance depends in part on worldwide economic and geopolitical conditions. Worsening economic conditions, including inflation, higher interest rates, fluctuations in foreign exchange rates and other changes in economic conditions, may adversely affect our financial performance.

[0001327567-22-000028:mdna:34]
- 45 -

[0001327567-22-000028:mdna:35]
Key Financial Metrics

[0001327567-22-000028:mdna:36]
We monitor the key financial metrics set forth in the tables below to help us evaluate growth trends, establish budgets, measure the effectiveness of our sales and marketing efforts, and assess operational efficiencies. We discuss revenue, gross margin, and the components of operating loss and margin below under “Results of Operations.”

[0001327567-22-000028:mdna:37]
|  | July 31, |
|  | 2022 |  | 2021 |
|  | (in millions) |
| Total deferred revenue | $ | 6,994.0 |  |  | $ | 5,024.0 |  |
| Cash, cash equivalents, and investments | $ | 4,686.4 |  |  | $ | 3,789.4 |  |

[0001327567-22-000028:mdna:38]
|  | Year Ended July 31, |
|  | 2022 |  | 2021 |  | 2020 |
|  | (dollars in millions) |
| Total revenue | $ | 5,501.5 |  |  | $ | 4,256.1 |  |  | $ | 3,408.4 |  |
| Total revenue year-over-year percentage increase | 29.3 | % |  | 24.9 | % |  | 17.5 | % |
| Gross margin | 68.8 | % |  | 70.0 | % |  | 70.7 | % |
| Operating loss | $ | (188.8) |  |  | $ | (304.1) |  |  | $ | (179.0) |  |
| Operating margin | (3.4) | % |  | (7.1) | % |  | (5.3) | % |
| Billings | $ | 7,471.5 |  |  | $ | 5,452.2 |  |  | $ | 4,301.7 |  |
| Billings year-over-year percentage increase | 37.0 | % |  | 26.7 | % |  | 23.3 | % |
| Cash flow provided by operating activities | $ | 1,984.7 |  |  | $ | 1,503.0 |  |  | $ | 1,035.7 |  |
| Free cash flow (non-GAAP) | $ | 1,791.9 |  |  | $ | 1,387.0 |  |  | $ | 821.3 |  |

[0001327567-22-000028:mdna:39]
•Deferred Revenue. Our deferred revenue primarily consists of amounts that have been invoiced but have not been recognized as revenue as of the period end. The majority of our deferred revenue balance consists of subscription and support revenue that is recognized ratably over the contractual service period. We monitor our deferred revenue balance because it represents a significant portion of revenue to be recognized in future periods.

[0001327567-22-000028:mdna:40]
•Billings. We define billings as total revenue plus the change in total deferred revenue, net of acquired deferred revenue, during the period. We consider billings to be a key metric used by management to manage our business. We believe billings provides investors with an important indicator of the health and visibility of our business because it includes subscription and support revenue, which is recognized ratably over the contractual service period, and product revenue, which is recognized at the time of shipment, provided that all other conditions for revenue recognition have been met. We consider billings to be a useful metric for management and investors, particularly if we continue to experience increased sales of subscriptions and strong renewal rates for subscription and support offerings, and as we monitor our near-term cash flows. While we believe that billings provides useful information to investors and others in understanding and evaluating our operating results in the same manner as our management, it is important to note that other companies, including companies in our industry, may not use billings, may calculate billings differently, may have different billing frequencies, or may use other financial measures to evaluate their performance, all of which could reduce the usefulness of billings as a comparative measure. We calculate billings in the following manner:

[0001327567-22-000028:mdna:41]
|  | Year Ended July 31, |
|  | 2022 |  | 2021 |  | 2020 |
|  | (in millions) |
| Billings: |  |  |  |  |  |
| Total revenue | $ | 5,501.5 |  |  | $ | 4,256.1 |  |  | $ | 3,408.4 |  |
| Add: change in total deferred revenue, net of acquired deferred revenue | 1,970.0 |  |  | 1,196.1 |  |  | 893.3 |  |
| Billings | $ | 7,471.5 |  |  | $ | 5,452.2 |  |  | $ | 4,301.7 |  |

[0001327567-22-000028:mdna:42]
- 46 -

[0001327567-22-000028:mdna:43]
•    Cash Flow Provided by Operating Activities. We monitor cash flow provided by operating activities as a measure of our overall business performance. Our cash flow provided by operating activities is driven in large part by sales of our products and from up-front payments for subscription and support offerings. Monitoring cash flow provided by operating activities enables us to analyze our financial performance without the non-cash effects of certain items such as depreciation, amortization, and share-based compensation costs, thereby allowing us to better understand and manage the cash needs of our business.

[0001327567-22-000028:mdna:44]
•    Free Cash Flow (non-GAAP). We define free cash flow, a non-GAAP financial measure, as cash provided by operating activities less purchases of property, equipment, and other assets. We consider free cash flow to be a profitability and liquidity measure that provides useful information to management and investors about the amount of cash generated by the business after necessary capital expenditures. A limitation of the utility of free cash flow as a measure of our financial performance and liquidity is that it does not represent the total increase or decrease in our cash balance for the period. In addition, it is important to note that other companies, including companies in our industry, may not use free cash flow, may calculate free cash flow in a different manner than we do, or may use other financial measures to evaluate their performance, all of which could reduce the usefulness of free cash flow as a comparative measure. A reconciliation of free cash flow to cash flow provided by operating activities, the most directly comparable financial measure calculated and presented in accordance with GAAP, is provided below:

[0001327567-22-000028:mdna:45]
|  | Year Ended July 31, |
|  | 2022 |  | 2021 |  | 2020 |
|  | (in millions) |
| Free cash flow (non-GAAP): |  |  |  |  |  |
| Net cash provided by operating activities | $ | 1,984.7 |  |  | $ | 1,503.0 |  |  | $ | 1,035.7 |  |
| Less: purchases of property, equipment, and other assets | 192.8 |  |  | 116.0 |  |  | 214.4 |  |
| Free cash flow (non-GAAP) | $ | 1,791.9 |  |  | $ | 1,387.0 |  |  | $ | 821.3 |  |
| Net cash provided by (used in) investing activities | $ | (933.4) |  |  | $ | (1,480.6) |  |  | $ | 288.0 |  |
| Net cash provided by (used in) financing activities | $ | (806.6) |  |  | $ | (1,104.0) |  |  | $ | 673.0 |  |

[0001327567-22-000028:mdna:46]
- 47 -

[0001327567-22-000028:mdna:47]
Results of Operations

[0001327567-22-000028:mdna:48]
The following table summarizes our results of operations for the periods presented and as a percentage of our total revenue for those periods based on our consolidated statements of operations data. The period to period comparison of results is not necessarily indicative of results for future periods.

[0001327567-22-000028:mdna:49]
|  | Year Ended July 31, |
|  | 2022 |  | 2021 |  | 2020 |
|  | Amount |  | % of Revenue |  | Amount |  | % of Revenue |  | Amount |  | % of Revenue |
|  | (dollars in millions) |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 1,363.1 |  |  | 24.8 | % |  | $ | 1,120.3 |  |  | 26.3 | % |  | $ | 1,064.2 |  |  | 31.2 | % |
| Subscription and support | 4,138.4 |  |  | 75.2 | % |  | 3,135.8 |  |  | 73.7 | % |  | 2,344.2 |  |  | 68.8 | % |
| Total revenue | 5,501.5 |  |  | 100.0 | % |  | 4,256.1 |  |  | 100.0 | % |  | 3,408.4 |  |  | 100.0 | % |
| Cost of revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Product | 455.5 |  |  | 8.3 | % |  | 308.5 |  |  | 7.2 | % |  | 294.4 |  |  | 8.6 | % |
| Subscription and support | 1,263.2 |  |  | 22.9 | % |  | 966.4 |  |  | 22.8 | % |  | 705.1 |  |  | 20.7 | % |
| Total cost of revenue(1) | 1,718.7 |  |  | 31.2 | % |  | 1,274.9 |  |  | 30.0 | % |  | 999.5 |  |  | 29.3 | % |
| Total gross profit | 3,782.8 |  |  | 68.8 | % |  | 2,981.2 |  |  | 70.0 | % |  | 2,408.9 |  |  | 70.7 | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | 1,417.7 |  |  | 25.8 | % |  | 1,140.4 |  |  | 26.8 | % |  | 768.1 |  |  | 22.5 | % |
| Sales and marketing | 2,148.9 |  |  | 39.0 | % |  | 1,753.8 |  |  | 41.1 | % |  | 1,520.2 |  |  | 44.7 | % |
| General and administrative | 405.0 |  |  | 7.4 | % |  | 391.1 |  |  | 9.2 | % |  | 299.6 |  |  | 8.8 | % |
| Total operating expenses(1) | 3,971.6 |  |  | 72.2 | % |  | 3,285.3 |  |  | 77.1 | % |  | 2,587.9 |  |  | 76.0 | % |
| Operating loss | (188.8) |  |  | (3.4) | % |  | (304.1) |  |  | (7.1) | % |  | (179.0) |  |  | (5.3) | % |
| Interest expense | (27.4) |  |  | (0.5) | % |  | (163.3) |  |  | (3.8) | % |  | (88.7) |  |  | (2.6) | % |
| Other income, net | 9.0 |  |  | 0.1 | % |  | 2.4 |  |  | 0.0 | % |  | 35.9 |  |  | 1.1 | % |
| Loss before income taxes | (207.2) |  |  | (3.8) | % |  | (465.0) |  |  | (10.9) | % |  | (231.8) |  |  | (6.8) | % |
| Provision for income taxes | 59.8 |  |  | 1.1 | % |  | 33.9 |  |  | 0.8 | % |  | 35.2 |  |  | 1.0 | % |
| Net loss | $ | (267.0) |  |  | (4.9) | % |  | $ | (498.9) |  |  | (11.7) | % |  | $ | (267.0) |  |  | (7.8) | % |

[0001327567-22-000028:mdna:50]
______________

[0001327567-22-000028:mdna:51]
(1)Includes share-based compensation as follows:

[0001327567-22-000028:mdna:52]
|  | Year Ended July 31, |
|  | 2022 |  | 2021 |  | 2020 |
|  | (in millions) |
| Cost of product revenue | $ | 9.3 |  |  | $ | 6.2 |  |  | $ | 5.7 |  |
| Cost of subscription and support revenue | 110.2 |  |  | 93.0 |  |  | 77.7 |  |
| Research and development | 471.1 |  |  | 428.9 |  |  | 274.6 |  |
| Sales and marketing | 304.7 |  |  | 269.9 |  |  | 214.5 |  |
| General and administrative | 118.1 |  |  | 128.9 |  |  | 92.0 |  |
| Total share-based compensation | $ | 1,013.4 |  |  | $ | 926.9 |  |  | $ | 664.5 |  |

[0001327567-22-000028:mdna:53]
- 48 -

[0001327567-22-000028:mdna:54]
Revenue

[0001327567-22-000028:mdna:55]
Our revenue consists of product revenue and subscription and support revenue. Revenue is recognized upon transfer of control of the corresponding promised products and subscriptions and support to our customers in an amount that reflects the consideration we expect to be entitled to in exchange for those products and subscriptions and support. We expect our revenue to vary from quarter to quarter based on seasonal and cyclical factors.

[0001327567-22-000028:mdna:56]
Product Revenue

[0001327567-22-000028:mdna:57]
Product revenue is derived from sales of our appliances, primarily our ML-Powered Next-Generation Firewall, which is available in a number of form factors, including as physical, virtual, and containerized appliances. Product revenue also includes revenue derived from software licenses of Panorama. Our appliances and software licenses include a broad set of built-in networking and security features and functionalities. We recognize product revenue at the time of hardware shipment or delivery of software license.

[0001327567-22-000028:mdna:58]
|  | Year Ended July 31, |  |  |  | Year Ended July 31, |  |  |
|  | 2022 |  | 2021 |  | Change |  | 2021 |  | 2020 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Product | $ | 1,363.1 |  |  | $ | 1,120.3 |  |  | $ | 242.8 |  |  | 21.7 | % |  | $ | 1,120.3 |  |  | $ | 1,064.2 |  |  | $ | 56.1 |  |  | 5.3 | % |

[0001327567-22-000028:mdna:59]
Product revenue increased for fiscal 2022 compared to fiscal 2021 primarily due to increased demand for our new generation of products, which includes customer transition from our legacy products.

[0001327567-22-000028:mdna:60]
Subscription and Support Revenue

[0001327567-22-000028:mdna:61]
Subscription and support revenue is derived primarily from sales of our subscription and support offerings. Our contractual subscription and support contracts are typically one to five years. We recognize revenue from subscriptions and support over time as the services are performed. As a percentage of total revenue, we expect our subscription and support revenue to vary from quarter to quarter and increase over the long term as we introduce new subscriptions, renew existing subscription and support contracts, and expand our installed end-customer base.

[0001327567-22-000028:mdna:62]
|  | Year Ended July 31, |  |  |  | Year Ended July 31, |  |  |
|  | 2022 |  | 2021 |  | Change |  | 2021 |  | 2020 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Subscription | $ | 2,539.0 |  |  | $ | 1,898.8 |  |  | $ | 640.2 |  |  | 33.7 | % |  | $ | 1,898.8 |  |  | $ | 1,405.3 |  |  | $ | 493.5 |  |  | 35.1 | % |
| Support | 1,599.4 |  |  | 1,237.0 |  |  | 362.4 |  |  | 29.3 | % |  | 1,237.0 |  |  | 938.9 |  | 298.1 |  |  | 31.7 | % |
| Total subscription and support | $ | 4,138.4 |  |  | $ | 3,135.8 |  |  | $ | 1,002.6 |  |  | 32.0 | % |  | $ | 3,135.8 |  |  | $ | 2,344.2 |  |  | $ | 791.6 |  |  | 33.8 | % |

[0001327567-22-000028:mdna:63]
Subscription and support revenue increased for fiscal 2022 compared to fiscal 2021 due to increased demand for our subscription and support offerings from our end-customers. The mix between subscription revenue and support revenue will fluctuate over time, depending on the introduction of new subscription offerings, renewals of support services, and our ability to increase sales to new and existing end-customers.

[0001327567-22-000028:mdna:64]
Revenue by Geographic Theater

[0001327567-22-000028:mdna:65]
|  | Year Ended July 31, |  |  |  | Year Ended July 31, |  |  |
|  | 2022 |  | 2021 |  | Change |  | 2021 |  | 2020 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Americas | $ | 3,802.6 |  |  | $ | 2,937.5 |  |  | $ | 865.1 |  |  | 29.5 | % |  | $ | 2,937.5 |  |  | $ | 2,318.0 |  |  | $ | 619.5 |  |  | 26.7 | % |
| EMEA | 1,055.8 |  |  | 817.3 |  |  | 238.5 |  |  | 29.2 | % |  | 817.3 |  |  | 671.9 |  |  | 145.4 |  |  | 21.6 | % |
| APAC | 643.1 |  |  | 501.3 |  |  | 141.8 |  |  | 28.3 | % |  | 501.3 |  |  | 418.5 |  |  | 82.8 |  |  | 19.8 | % |
| Total revenue | $ | 5,501.5 |  |  | $ | 4,256.1 |  |  | $ | 1,245.4 |  |  | 29.3 | % |  | $ | 4,256.1 |  |  | $ | 3,408.4 |  |  | $ | 847.7 |  |  | 24.9 | % |

[0001327567-22-000028:mdna:66]
With respect to geographic theaters, the Americas contributed the largest portion of the year-over-year increases in revenue for fiscal 2022 due to its larger and more established sales force compared to our other theaters. Revenue from Europe, the Middle East, and Africa (“EMEA”) and Asia Pacific and Japan (“APAC”) increased year-over-year for fiscal 2022 due to increasing investment in global sales force in order to support our growth and innovation.

[0001327567-22-000028:mdna:67]
- 49 -

[0001327567-22-000028:mdna:68]
Cost of Revenue

[0001327567-22-000028:mdna:69]
Our cost of revenue consists of cost of product revenue and cost of subscription and support revenue.

[0001327567-22-000028:mdna:70]
Cost of Product Revenue

[0001327567-22-000028:mdna:71]
Cost of product revenue primarily includes costs paid to our manufacturing partners for procuring components and manufacturing our products. Our cost of product revenue also includes personnel costs, which consist of salaries, benefits, bonuses, share-based compensation and travel and entertainment associated with our operations organization, amortization of intellectual property licenses, product testing costs, shipping and tariff costs, and shared costs. Shared costs consist of certain facilities, depreciation, benefits, recruiting, and information technology costs that we allocate based on headcount. We expect our cost of product revenue to fluctuate with our product revenue.

[0001327567-22-000028:mdna:72]
|  | Year Ended July 31, |  |  |  | Year Ended July 31, |  |  |
|  | 2022 |  | 2021 |  | Change |  | 2021 |  | 2020 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Cost of product revenue | $ | 455.5 |  |  | $ | 308.5 |  |  | $ | 147.0 |  |  | 47.6 | % |  | $ | 308.5 |  |  | $ | 294.4 |  |  | $ | 14.1 |  |  | 4.8 | % |
| Number of employees at period end | 149 |  |  | 127 |  |  | 22 |  |  | 17.3 | % |  | 127 |  |  | 117 |  |  | 10 |  |  | 8.5 | % |

[0001327567-22-000028:mdna:73]
Cost of product revenue increased for fiscal 2022 compared to fiscal 2021 primarily due to an increase in the volume of product sold. The remaining increase in costs was primarily driven by supply chain challenges.

[0001327567-22-000028:mdna:74]
Cost of Subscription and Support Revenue

[0001327567-22-000028:mdna:75]
Cost of subscription and support revenue includes personnel costs for our global customer support and technical operations organizations, customer support and repair costs, third-party professional services costs, data center and cloud hosting service costs, amortization of acquired intangible assets and capitalized software development costs, and shared costs. We expect our cost of subscription and support revenue to increase as our installed end-customer base grows and adoption of our cloud-based subscription offerings increases.

[0001327567-22-000028:mdna:76]
|  | Year Ended July 31, |  |  |  | Year Ended July 31, |  |  |
|  | 2022 |  | 2021 |  | Change |  | 2021 |  | 2020 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Cost of subscription and support revenue | $ | 1,263.2 |  |  | $ | 966.4 |  |  | $ | 296.8 |  |  | 30.7 | % |  | $ | 966.4 |  |  | $ | 705.1 |  |  | $ | 261.3 |  |  | 37.1 | % |
| Number of employees at period end | 2,515 |  |  | 2,108 |  |  | 407 |  |  | 19.3 | % |  | 2,108 |  |  | 1,402 |  |  | 706 |  |  | 50.4 | % |

[0001327567-22-000028:mdna:77]
Cost of subscription and support revenue increased for fiscal 2022 compared to fiscal 2021 primarily due to increased costs to support the growth of our subscription and support offerings. Personnel costs grew $135.4 million to $547.8 million for fiscal 2022 compared to fiscal 2021 primarily due to headcount growth. The remaining increase was primarily due to increased cloud hosting service costs to support our cloud-based subscription offerings, outside service costs for global customer support resulting from the expansions of our customer base and product portfolio, and shared costs.

[0001327567-22-000028:mdna:78]
Gross Margin

[0001327567-22-000028:mdna:79]
Gross margin has been and will continue to be affected by a variety of factors, including the introduction of new products, manufacturing costs, the average sales price of our products, cloud hosting service costs, personnel costs, the mix of products sold, and the mix of revenue between product and subscription and support offerings. Our virtual and higher-end firewall products generally have higher gross margins than our lower-end firewall products within each product series. We expect our gross margins to vary over time depending on the factors described above.

[0001327567-22-000028:mdna:80]
|  | Year Ended July 31, |
|  | 2022 |  | 2021 |  | 2020 |
|  | Amount |  | GrossMargin |  | Amount |  | GrossMargin |  | Amount |  | GrossMargin |
|  | (dollars in millions) |
| Product | $ | 907.6 |  |  | 66.6 | % |  | $ | 811.8 |  |  | 72.5 | % |  | $ | 769.8 |  |  | 72.3 | % |
| Subscription and support | 2,875.2 |  |  | 69.5 | % |  | 2,169.4 |  |  | 69.2 | % |  | 1,639.1 |  |  | 69.9 | % |
| Total gross profit | $ | 3,782.8 |  |  | 68.8 | % |  | $ | 2,981.2 |  |  | 70.0 | % |  | $ | 2,408.9 |  |  | 70.7 | % |

[0001327567-22-000028:mdna:81]
- 50 -

[0001327567-22-000028:mdna:82]
Product gross margin decreased for fiscal 2022 compared to fiscal 2021 primarily due to higher costs related to our product offerings driven by supply chain challenges.

[0001327567-22-000028:mdna:83]
Subscription and support gross margin was relatively flat for fiscal 2022 compared to fiscal 2021.

[0001327567-22-000028:mdna:84]
Operating Expenses

[0001327567-22-000028:mdna:85]
Our operating expenses consist of research and development, sales and marketing, and general and administrative expenses. Personnel costs are the most significant component of operating expenses and consist of salaries, benefits, bonuses, share-based compensation, travel and entertainment, and with regard to sales and marketing expense, sales commissions. Our operating expenses also include shared costs, which consist of certain facilities, depreciation, benefits, recruiting, and information technology costs that we allocate based on headcount to each department. We expect operating expenses generally to increase in absolute dollars and decrease over the long term as a percentage of revenue as we continue to scale our business. As of July 31, 2022, we expect to recognize approximately $1.8 billion of share-based compensation expense over a weighted-average period of approximately 2.6 years, excluding additional share-based compensation expense related to any future grants of share-based awards. Share-based compensation expense is generally recognized on a straight-line basis over the requisite service periods of the awards.

[0001327567-22-000028:mdna:86]
Research and Development

[0001327567-22-000028:mdna:87]
Research and development expense consists primarily of personnel costs. Research and development expense also includes prototype related expenses and shared costs. We expect research and development expense to increase in absolute dollars as we continue to invest in our future products and services, although our research and development expense may fluctuate as a percentage of total revenue.

[0001327567-22-000028:mdna:88]
|  | Year Ended July 31, |  |  |  | Year Ended July 31, |  |  |
|  | 2022 |  | 2021 |  | Change |  | 2021 |  | 2020 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Research and development | $ | 1,417.7 |  |  | $ | 1,140.4 |  |  | $ | 277.3 |  |  | 24.3 | % |  | $ | 1,140.4 |  |  | $ | 768.1 |  |  | $ | 372.3 |  |  | 48.5 | % |
| Number of employees at period end | 3,268 |  |  | 2,595 |  |  | 673 |  |  | 25.9 | % |  | 2,595 |  |  | 1,821 |  |  | 774 |  |  | 42.5 | % |

[0001327567-22-000028:mdna:89]
Research and development expense increased for fiscal 2022 compared to fiscal 2021 primarily due to an increase in personnel costs, which grew $193.5 million to $1.1 billion, primarily due to headcount growth. The increase in research and development expense was further driven by increased shared costs and third-party product development costs.

[0001327567-22-000028:mdna:90]
Sales and Marketing

[0001327567-22-000028:mdna:91]
Sales and marketing expense consists primarily of personnel costs, including commission expense. Sales and marketing expense also includes costs for market development programs, promotional and other marketing costs, professional services, and shared costs. We continue to strategically invest in headcount and have grown our sales presence. We expect sales and marketing expense to continue to increase in absolute dollars as we increase the size of our sales and marketing organizations to grow our customer base, increase touch points with end-customers, and expand our global presence, although our sales and marketing expense may fluctuate as a percentage of total revenue.

[0001327567-22-000028:mdna:92]
|  | Year Ended July 31, |  |  |  | Year Ended July 31, |  |  |
|  | 2022 |  | 2021 |  | Change |  | 2021 |  | 2020 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Sales and marketing | $ | 2,148.9 |  |  | $ | 1,753.8 |  |  | $ | 395.1 |  |  | 22.5 | % |  | $ | 1,753.8 |  |  | $ | 1,520.2 |  |  | $ | 233.6 |  |  | 15.4 | % |
| Number of employees at period end | 5,167 |  |  | 4,493 |  |  | 674 |  |  | 15.0 | % |  | 4,493 |  |  | 3,800 |  |  | 693 |  |  | 18.2 | % |

[0001327567-22-000028:mdna:93]
Sales and marketing expense increased for fiscal 2022 compared to fiscal 2021 primarily due to an increase in personnel costs, which grew $291.8 million to $1.6 billion, primarily due to headcount growth and increased travel and entertainment expenses. The increase in sales and marketing expense was further driven by an increase in costs associated with marketing activities.

[0001327567-22-000028:mdna:94]
- 51 -

[0001327567-22-000028:mdna:95]
General and Administrative

[0001327567-22-000028:mdna:96]
General and administrative expense consists primarily of personnel costs and shared costs for our executive, finance, human resources, information technology, and legal organizations, and professional services costs, which consist primarily of legal, auditing, accounting, and other consulting costs. We expect general and administrative expense to increase in absolute dollars as we increase the size of our general and administrative organizations and incur additional costs to support our business growth, although our general and administrative expense may fluctuate as a percentage of total revenue.

[0001327567-22-000028:mdna:97]
|  | Year Ended July 31, |  |  |  | Year Ended July 31, |  |  |
|  | 2022 |  | 2021 |  | Change |  | 2021 |  | 2020 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| General and administrative | $ | 405.0 |  |  | $ | 391.1 |  |  | $ | 13.9 |  |  | 3.6 | % |  | $ | 391.1 |  |  | $ | 299.6 |  |  | $ | 91.5 |  |  | 30.5 | % |
| Number of employees at period end | 1,462 |  |  | 1,150 |  |  | 312 |  |  | 27.1 | % |  | 1,150 |  |  | 874 |  |  | 276 |  |  | 31.6 | % |

[0001327567-22-000028:mdna:98]
General and administrative expenses increased for fiscal 2022 compared to fiscal 2021 primarily due to personnel costs, which grew $24.6 million to $268.6 million, partially offset by a decrease in acquisition-related costs. The increase in personnel costs was primarily due to headcount growth, partially offset by lower share-based compensation related to accelerated vesting of equity awards in connection with acquisitions.

[0001327567-22-000028:mdna:99]
Interest Expense

[0001327567-22-000028:mdna:100]
Interest expense primarily consists of interest expense related to our 0.75% Convertible Senior Notes due 2023 (the “2023 Notes”) and the 0.375% Convertible Senior Notes due 2025 (the “2025 Notes,” and together with “2023 Notes,” the “Notes”).

[0001327567-22-000028:mdna:101]
|  | Year Ended July 31, |  |  |  | Year Ended July 31, |  |  |
|  | 2022 |  | 2021 |  | Change |  | 2021 |  | 2020 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Interest expense | $ | 27.4 |  |  | $ | 163.3 |  |  | $ | (135.9) |  |  | (83.2) | % |  | $ | 163.3 |  |  | $ | 88.7 |  |  | $ | 74.6 |  |  | 84.1 | % |

[0001327567-22-000028:mdna:102]
Interest expense decreased for fiscal 2022 compared to fiscal 2021 primarily because we no longer recognize interest expense for amortization of the debt discount as a result of the adoption of new debt guidance. Refer to Note 1. Description of Business and Summary of Significant Accounting Policies and Note 10. Debt in Part II, Item 8 of this Annual Report on Form 10-K for more information.

[0001327567-22-000028:mdna:103]
Other Income, Net

[0001327567-22-000028:mdna:104]
Other income, net includes interest income earned on our cash, cash equivalents, and investments, and gains and losses from foreign currency remeasurement and foreign currency transactions.

[0001327567-22-000028:mdna:105]
|  | Year Ended July 31, |  |  |  | Year Ended July 31, |  |  |
|  | 2022 |  | 2021 |  | Change |  | 2021 |  | 2020 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Other income, net | $ | 9.0 |  |  | $ | 2.4 |  |  | $ | 6.6 |  |  | 275.0 | % |  | $ | 2.4 |  |  | $ | 35.9 |  |  | $ | (33.5) |  |  | (93.3) | % |

[0001327567-22-000028:mdna:106]
Other income, net increased for fiscal 2022 compared to fiscal 2021 primarily due to increased foreign currency exchange gains and higher interest income earned on our cash, cash equivalent, and investment balances as a result of higher interest rates for fiscal 2022 compared to fiscal 2021, partially offset by increased losses related to non-designated derivative instruments.

[0001327567-22-000028:mdna:107]
- 52 -

[0001327567-22-000028:mdna:108]
Provision for Income Taxes

[0001327567-22-000028:mdna:109]
Provision for income taxes consists primarily of income taxes in foreign jurisdictions in which we conduct business and withholding taxes. We maintain a full valuation allowance for domestic and certain foreign deferred tax assets, including net operating loss carryforwards and certain domestic tax credits. Our valuation allowance has caused, and may continue to cause, disproportionate relationships between our overall effective tax rate and other jurisdictional measures.

[0001327567-22-000028:mdna:110]
|  | Year Ended July 31, |  |  |  |  |  | Year Ended July 31, |  |  |  |  |
|  | 2022 |  | 2021 |  | Change |  | 2021 |  | 2020 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Provision for income taxes | $ | 59.8 |  |  | $ | 33.9 |  |  | $ | 25.9 |  |  | 76.4 | % |  | $ | 33.9 |  |  | $ | 35.2 |  |  | $ | (1.3) |  |  | (3.7) | % |
| Effective tax rate | (28.9) | % |  | (7.3) | % |  |  |  |  |  | (7.3) | % |  | (15.2) | % |  |  |  |  |

[0001327567-22-000028:mdna:111]
We recorded an income tax provision for fiscal 2022. The provision for income taxes for fiscal 2022 was primarily due to income taxes in profitable foreign jurisdictions and withholding taxes. Our provision for income taxes increased for fiscal 2022 compared to fiscal 2021, primarily due to foreign income and withholding taxes. Refer to Note 15. Income Taxes in Part II, Item 8 of this Annual Report on Form 10-K for more information.

[0001327567-22-000028:mdna:112]
Liquidity and Capital Resources

[0001327567-22-000028:mdna:113]
|  | July 31, |
|  | 2022 |  | 2021 |
|  | (in millions) |
| Working capital(1) | $ | (1,891.4) |  |  | $ | (469.4) |  |
| Cash, cash equivalents, and investments: |  |  |  |
| Cash and cash equivalents | $ | 2,118.5 |  |  | $ | 1,874.2 |  |
| Investments | 2,567.9 |  |  | 1,915.2 |  |
| Total cash, cash equivalents, and investments | $ | 4,686.4 |  |  | $ | 3,789.4 |  |

[0001327567-22-000028:mdna:114]
______________

[0001327567-22-000028:mdna:115]
(1)Current liabilities included net carrying amounts of convertible senior notes of $3.7 billion and $1.6 billion as of July 31, 2022 and 2021, respectively. Refer to Note 10. Debt in Part II, Item 8 of this Annual Report on Form 10-K for information on the Notes.

[0001327567-22-000028:mdna:116]
As of July 31, 2022, our total cash, cash equivalents, and investments of $4.7 billion were held for general corporate purposes. As of July 31, 2022, we had no unremitted earnings when evaluating our outside basis difference relating to our U.S. investment in foreign subsidiaries. However, there could be local withholding taxes payable due to various foreign countries if certain lower tier earnings are distributed. Withholding taxes that would be payable upon remittance of these lower tier earnings are not expected to be material.

[0001327567-22-000028:mdna:117]
Debt

[0001327567-22-000028:mdna:118]
In July 2018, we issued the 2023 Notes with an aggregate principal amount of $1.7 billion. In June 2020, we issued the 2025 Notes with an aggregate principal amount of $2.0 billion. The 2023 Notes mature on July 1, 2023 and the 2025 Notes mature on June 1, 2025; however, under certain circumstances, holders may surrender their Notes of a series for conversion prior to the applicable maturity date. Upon conversion of the Notes of a series, we will pay cash equal to the aggregate principal amount of the Notes of such series to be converted, and, at our election, will pay or deliver cash and/or shares of our common stock for the amount of our conversion obligation in excess of the aggregate principal amount of the Notes of such series being converted. The sale price condition for the Notes was met during the fiscal quarter ended July 31, 2022, and as a result, holders may convert their Notes at any time during the fiscal quarter ending October 31, 2022. If all of the holders of the Notes converted their Notes during this period, we would be obligated to settle the $3.7 billion principal amount of the Notes in cash. We believe that our cash provided by operating activities, our existing cash, cash equivalents and investments, and existing sources of and access to financing will be sufficient to meet our anticipated cash needs should the holders choose to convert their Notes during the fiscal quarter ending October 31, 2022 or hold the 2023 Notes until maturity on July 1, 2023. As of July 31, 2022, substantially all of our Notes remained outstanding. Refer to Note 10. Debt in Part II, Item 8 of this Annual Report on Form 10-K for more information on the Notes.

[0001327567-22-000028:mdna:119]
In September 2018, we entered into a credit agreement (the “Credit Agreement”) that provides for a $400.0 million unsecured revolving credit facility (the “Credit Facility”), with an option to increase the amount of the Credit Facility by up to an additional $350.0 million, subject to certain conditions. As of July 31, 2022, there were no amounts outstanding, and we were in compliance with all covenants under the Credit Agreement. Refer to Note 10. Debt in Part II, Item 8 of this Annual Report on Form 10-K for more information on the Credit Agreement.

[0001327567-22-000028:mdna:120]
- 53 -

[0001327567-22-000028:mdna:121]
Capital Return

[0001327567-22-000028:mdna:122]
In February 2019, our board of directors authorized a $1.0 billion share repurchase program. In December 2020 and August 2021, our board of directors authorized additional $700.0 million and $676.1 million increases, respectively, bringing the total authorization under this share repurchase program to $2.4 billion. Repurchases will be funded from available working capital and may be made at management’s discretion from time to time. The expiration date of this repurchase authorization was extended to December 31, 2022, and our repurchase program may be suspended or discontinued at any time. As of July 31, 2022, 85.0 million remained available for future share repurchases under this repurchase program. In February 2020, our board of directors approved the repurchase of $1.0 billion of our common stock through an accelerated share repurchase (“ASR”) transaction, which was in addition to our current authorization. During fiscal 2020, we completed the ASR transaction with an aggregate of 5.2 million shares of our common stock repurchased and retired. Refer to Note 13. Stockholders’ Equity in Part II, Item 8 of this Annual Report on Form 10-K for information on these repurchase programs.

[0001327567-22-000028:mdna:123]
Leases and Other Material Cash Requirements

[0001327567-22-000028:mdna:124]
We have entered into various non-cancelable operating leases primarily for our facilities with original lease periods expiring through the year ending July 31, 2032, with the most significant leases relating to our corporate headquarters in Santa Clara, California. As of July 31, 2022, we have total operating lease obligations of $338.4 million recorded on our consolidated balance sheet.

[0001327567-22-000028:mdna:125]
As of July 31, 2022, our commitments to purchase products, components, cloud and other services totaled $2.4 billion. Refer to Note 12. Commitments and Contingencies in Part II, Item 8 of this Annual Report on Form 10-K for more information on these commitments.

[0001327567-22-000028:mdna:126]
Cash Flows

[0001327567-22-000028:mdna:127]
The following table summarizes our cash flows for the years ended July 31, 2022, 2021, and 2020:

[0001327567-22-000028:mdna:128]
|  | Year Ended July 31, |
| 2022 |  | 2021 |  | 2020 |
|  | (in millions) |
| Net cash provided by operating activities | $ | 1,984.7 |  |  | $ | 1,503.0 |  |  | $ | 1,035.7 |  |
| Net cash provided by (used in) investing activities | (933.4) |  |  | (1,480.6) |  |  | 288.0 |  |
| Net cash provided by (used in) financing activities | (806.6) |  |  | (1,104.0) |  |  | 673.0 |  |
| Net increase (decrease) in cash, cash equivalents, and restricted cash | $ | 244.7 |  |  | $ | (1,081.6) |  |  | $ | 1,996.7 |  |

[0001327567-22-000028:mdna:129]
Cash from operations could be affected by various risks and uncertainties, including, but not limited to, the effects of COVID-19 and other risks detailed in Part I, Item 1A “Risk Factors” in this Form 10-K. We believe that our cash flow from operations with existing cash and cash equivalents will be sufficient to meet our anticipated cash needs for at least the next 12 months and thereafter for the foreseeable future. Our future capital requirements will depend on many factors including our growth rate, the timing and extent of spending to support development efforts, the expansion of sales and marketing activities, the introduction of new and enhanced products and subscription and support offerings, the costs to acquire or invest in complementary businesses and technologies, the costs to ensure access to adequate manufacturing capacity, the investments in our infrastructure to support the adoption of our cloud-based subscription offerings, the repayment obligations associated with our Notes, the continuing market acceptance of our products and subscription and support offerings and macroeconomic events such as COVID-19. In addition, from time to time, we may incur additional tax liability in connection with certain corporate structuring decisions.

[0001327567-22-000028:mdna:130]
We may also choose to seek additional equity or debt financing. In the event that additional financing is required from outside sources, we may not be able to raise it on terms acceptable to us or at all. If we are unable to raise additional capital when desired, our business, operating results, and financial condition may be adversely affected.

[0001327567-22-000028:mdna:131]
Operating Activities

[0001327567-22-000028:mdna:132]
Our operating activities have consisted of net losses adjusted for certain non-cash items and changes in assets and liabilities. Our largest source of cash provided by our operations is receipts from our product revenue and subscription and support revenue.

[0001327567-22-000028:mdna:133]
Cash provided by operating activities during fiscal 2022 was $2.0 billion, an increase of $481.7 million compared to fiscal 2021. The increase was primarily due to growth of our business as reflected by increases in billings and collections during fiscal 2022, partially offset by higher cash expenditure to support our business growth.

[0001327567-22-000028:mdna:134]
Investing Activities

[0001327567-22-000028:mdna:135]
Our investing activities have consisted of capital expenditures, net investment purchases, sales, and maturities, and business acquisitions. We expect to continue such activities as our business grows.

[0001327567-22-000028:mdna:136]
- 54 -

[0001327567-22-000028:mdna:137]
Cash used in investing activities during fiscal 2022 was $933.4 million, a decrease of $547.2 million compared to fiscal 2021. The decrease was primarily due to a decrease in net cash payments for business acquisitions, partially offset by an increase in net investment purchases, sales and maturities during fiscal 2022.

[0001327567-22-000028:mdna:138]
Financing Activities

[0001327567-22-000028:mdna:139]
Our financing activities have consisted of cash used to repurchase shares of our common stock, proceeds from sales of shares through employee equity incentive plans, and payments for tax withholding obligations of certain employees related to the net share settlement of equity awards.

[0001327567-22-000028:mdna:140]
Cash used in financing activities during fiscal 2022 was $806.6 million, a decrease of $297.4 million compared to fiscal 2021. The decrease was primarily due to a decrease in repurchases of our common stock during fiscal 2022.

[0001327567-22-000028:mdna:141]
Critical Accounting Estimates

[0001327567-22-000028:mdna:142]
Our consolidated financial statements have been prepared in accordance with GAAP. The preparation of these consolidated financial statements requires us to make estimates and assumptions that affect the reported amounts of assets, liabilities, revenue, expenses, and related disclosures. We base our estimates on historical experience and on various other assumptions that we believe are reasonable under the circumstances. We evaluate our estimates and assumptions on an ongoing basis. Actual results could differ materially from those estimates due to risks and uncertainties, including uncertainty in the current economic environment. To the extent that there are material differences between these estimates and our actual results, our future consolidated financial statements will be affected.

[0001327567-22-000028:mdna:143]
We believe that of our significant accounting policies described in Note 1. Description of Business and Summary of Significant Accounting Policies in Part II, Item 8 of this Annual Report on Form 10-K, the critical accounting estimates, assumptions, and judgments that have the most significant impact on our consolidated financial statements are described below.

[0001327567-22-000028:mdna:144]
Revenue Recognition

[0001327567-22-000028:mdna:145]
The majority of our contracts with our customers include various combinations of our products and subscriptions and support. Our appliances and software licenses have significant standalone functionalities and capabilities and, accordingly, are distinct from our subscriptions and support services, as the customer can benefit from the product without these services and such services are separately identifiable within the contract. We account for multiple agreements with a single customer as a single contract if the contractual terms and/or substance of those agreements indicate that they may be so closely related that they are, in effect, parts of a single contract. The amount we are due in exchange for delivering on the contract is allocated to each performance obligation based on its relative standalone selling price.

[0001327567-22-000028:mdna:146]
We establish standalone selling price using the prices charged for a deliverable when sold separately. If not observable through past transactions, we estimate the standalone selling price based on our pricing model and our go-to-market strategy, which include factors such as type of sales channel (channel partner or end-customer), the geographies in which our offerings were sold (domestic or international) and offering type (products, subscriptions, or support). As our business offerings evolve over time, we may be required to modify our estimated standalone selling prices, and as a result the timing and classification of our revenue could be affected.

[0001327567-22-000028:mdna:147]
Deferred Contract Costs

[0001327567-22-000028:mdna:148]
We defer contract costs that are recoverable and incremental to obtaining customer sales contracts. Contract costs, which primarily consist of sales commissions, are amortized on a systematic basis that is consistent with the transfer to the customer of the goods or services to which the asset relates. Sales commissions for initial contracts that are not commensurate with renewal commissions are amortized over a benefit period of five years, consistent with the revenue recognition pattern of the performance obligations in the related contracts including expected renewals. The benefit period is determined by taking into consideration contract length, technology life, and other quantitative and qualitative factors. The expected renewals are estimated based on historical renewal trends. Sales commissions for initial contracts that are commensurate and sales commissions for renewal contracts are amortized over the related contractual period in proportion to the revenue recognized.

[0001327567-22-000028:mdna:149]
Income Taxes

[0001327567-22-000028:mdna:150]
We account for income taxes using the asset and liability method, which requires the recognition of deferred tax assets and liabilities for the expected future tax consequences of events that have been recognized in our consolidated financial statements or tax returns. In addition, deferred tax assets are recorded for the future benefit of utilizing net operating losses and research and development credit carryforwards. Valuation allowances are provided when necessary to reduce deferred tax assets to the amount expected to be realized.

[0001327567-22-000028:mdna:151]
Significant judgment is required in determining any valuation allowance recorded against deferred tax assets. In assessing the need for a valuation allowance, we consider all available evidence, including past operating results, estimates of future taxable income, and the feasibility of tax planning strategies. In the event that we change our determination as to the amount of deferred tax assets that can be realized, we will adjust our valuation allowance with a corresponding impact to the provision for income taxes in the period in which such determination is made.

[0001327567-22-000028:mdna:152]
- 55 -

[0001327567-22-000028:mdna:153]
We recognize liabilities for uncertain tax positions based on a two-step process. The first step is to evaluate the tax position for recognition by determining if the weight of available evidence indicates that it is more likely than not that the position will be sustained on audit, including resolution of related appeals or litigation processes, if any. The second step requires us to estimate and measure the tax benefit as the largest amount that is more likely than not to be realized upon ultimate settlement.

[0001327567-22-000028:mdna:154]
Significant judgment is required in evaluating our uncertain tax positions and determining our provision for income taxes. Although we believe our reserves are reasonable, no assurance can be given that the final tax outcome of these matters will not be different from that which is reflected in our historical income tax provisions and accruals. We adjust these reserves in light of changing facts and circumstances, such as the closing of a tax audit or the refinement of an estimate. To the extent that the final tax outcome of these matters is different than the amounts recorded, such differences may impact the provision for income taxes in the period in which such determination is made.

[0001327567-22-000028:mdna:155]
Manufacturing Partner and Supplier Liabilities

[0001327567-22-000028:mdna:156]
We outsource most of our manufacturing, repair, and supply chain management operations to our EMS provider, which procures components and assembles our products based on our demand forecasts. These forecasts of future demand are based upon historical trends and analysis from our sales and product management functions as adjusted for overall market conditions. We accrue costs for manufacturing purchase commitments in excess of our forecasted demand, including costs for excess components or for carrying costs incurred by our manufacturing partners and component suppliers. Actual component usage and product demand may be materially different from our forecast and could be caused by factors outside of our control, which could have an adverse impact on our results of operations. To date, we have not accrued significant costs associated with this exposure.

[0001327567-22-000028:mdna:157]
Loss Contingencies

[0001327567-22-000028:mdna:158]
We are subject to the possibility of various loss contingencies arising in the ordinary course of business. We accrue for loss contingencies when it is probable that an asset has been impaired or a liability has been incurred and the amount of loss can be reasonably estimated. If we determine that a loss is possible and the range of the loss can be reasonably determined, then we disclose the range of the possible loss. We regularly evaluate current information available to us to determine whether an accrual is required, an accrual should be adjusted, or a range of possible loss should be disclosed.

[0001327567-22-000028:mdna:159]
From time to time, we are involved in disputes, litigation, and other legal actions. However, there are many uncertainties associated with any litigation, and these actions or other third-party claims against us may cause us to incur substantial settlement charges, which are inherently difficult to estimate and could adversely affect our results of operations. The actual liability in any such matters may be materially different from our estimates, which could result in the need to adjust our liability and record additional expenses.

[0001327567-22-000028:mdna:160]
Goodwill, Intangibles, and Other Long-Lived Assets

[0001327567-22-000028:mdna:161]
We make significant estimates, assumptions, and judgments when valuing goodwill and other purchased intangible assets in connection with the initial purchase price allocation of an acquired entity, as well as when evaluating impairment of goodwill and other purchased intangible assets on an ongoing basis. These estimates are based upon a number of factors, including historical experience, market conditions, and information obtained from the management of the acquired company. Critical estimates in valuing certain intangible assets include, but are not limited to, cash flows that an asset is expected to generate in the future, discount rates, the time and expense that would be necessary to recreate the assets, and the profit margin a market participant would receive. The amounts and useful lives assigned to identified intangible assets impact the amount and timing of future amortization expense.

[0001327567-22-000028:mdna:162]
We evaluate goodwill for impairment on an annual basis in our fourth fiscal quarter or more frequently if we believe impairment indicators exist. We have elected to first assess qualitative factors to determine whether it is more likely than not that the fair value of our reporting unit is less than its carrying amount, including goodwill. The qualitative assessment includes our evaluation of relevant events and circumstances affecting our single reporting unit, including macroeconomic, industry, and market conditions, our overall financial performance, and trends in the market price of our common stock. If qualitative factors indicate that it is more likely than not that our reporting unit’s fair value is less than its carrying amount, then we will perform the quantitative impairment test by comparing our reporting unit’s carrying amount, including goodwill, to its fair value. If the carrying amount of our reporting unit exceeds its fair value, an impairment loss will be recognized in an amount equal to that excess but limited to the total amount of goodwill. To date, the results of our qualitative assessment have indicated that the quantitative goodwill impairment test is not necessary.

[0001327567-22-000028:mdna:163]
- 56 -

[0001327567-22-000028:mdna:164]
We evaluate purchased intangible assets and other long-lived assets for impairment whenever events or changes in circumstances indicate that the carrying amount of the assets may not be recoverable. Such events or changes in circumstances include, but are not limited to, a significant decrease in the fair value of the underlying asset or asset group, a significant decrease in the benefits realized from the acquired assets, difficulty and delays in integrating the business, or a significant change in the operations of the acquired assets or use of an asset or asset group. A long-lived asset is considered impaired if its carrying amount exceeds the estimated future undiscounted cash flows the asset or asset group is expected to generate. Critical estimates in determining whether a long-lived asset is considered impaired include the amount and timing of future cash flows that the asset or asset group is expected to generate. If a long-lived asset is considered to be impaired, the impairment to be recognized is the amount by which the carrying amount of the asset exceeds the fair value of the asset or asset group, which is estimated using a present value technique. Critical estimates in determining the fair value of an asset or asset group and the amount of impairment to recognize include, but are not limited to, the amount and timing of future cash flows that the asset or asset group is expected to generate and the discount rate. Determining the fair value of an asset or asset group is highly judgmental in nature and involves the use of significant estimates and assumptions for market participants. We base our fair value estimates on assumptions we believe to be reasonable but that are unpredictable and inherently uncertain. Actual future results may differ from those estimates.

[0001327567-22-000028:mdna:165]
Recent Accounting Pronouncements

[0001327567-22-000028:mdna:166]
Refer to “Recently Issued Accounting Pronouncements” in Note 1. Description of Business and Summary of Significant Accounting Policies in Part II, Item 8 of this Annual Report on Form 10-K for a description of recent accounting pronouncements and our expectation of their impact, if any, on our results of operations and financial condition.
