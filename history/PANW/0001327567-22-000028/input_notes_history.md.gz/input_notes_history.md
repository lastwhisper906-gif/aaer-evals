# PANW note change history — 0001327567-22-000008 → 0001327567-22-000016


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2022-05-20):
[0001327567-22-000016:note_history:1]
In order to reduce manufacturing lead times and plan for adequate supply, we enter into agreements with manufacturing partners and component suppliers to procure inventory based on our demand forecasts. The following table presents details of the aggregate future purchase commitments under these arrangements, excluding obligations under contracts that we can cancel without a significant penalty as of April 30, 2022 (in millions):
  (was, 2022-02-23, similarity 0.986):
[0001327567-22-000008:note_history:1]
In order to reduce manufacturing lead times and plan for adequate supply, we enter into agreements with manufacturing partners and component suppliers to procure inventory based on our demand forecasts. The following table presents details of the aggregate future purchase commitments under these arrangements, excluding obligations under contracts that we can cancel without a significant penalty as of January 31, 2022 (in millions):

- changed (2022-05-20):
[0001327567-22-000016:note_history:2]
We have entered into various non-cancelable agreements with certain service providers, under which we are committed to minimum or fixed purchases. The following table presents details of the aggregate future non-cancelable purchase commitments under these agreements as of April 30, 2022 (in millions):
  (was, 2022-02-23, similarity 0.9799):
[0001327567-22-000008:note_history:2]
We have entered into various non-cancelable agreements with certain service providers, under which we are committed to minimum or fixed purchases. The following table presents details of the aggregate future non-cancelable purchase commitments under these agreements as of January 31, 2022 (in millions):

- added (2022-05-20):
[0001327567-22-000016:note_history:3]
To the extent there is a reasonable possibility that a loss exceeding amounts already recognized may be incurred and the amount of such additional loss would be material, we will either disclose the estimated additional loss or state that such an estimate cannot be made. As of April 30, 2022, we have not recorded any significant accruals for loss contingencies associated with such legal proceedings, determined that an unfavorable outcome is probable or reasonably possible, or determined that the amount or range of any possible loss is reasonably estimable.

- removed (2022-05-20):
[0001327567-22-000008:note_history:4]
To the extent there is a reasonable possibility that a loss exceeding amounts already recognized may be incurred and the amount of such additional loss would be material, we will either disclose the estimated additional loss or state that such an estimate cannot be made. As of January 31, 2022, we have not recorded any significant accruals for loss contingencies associated with such legal proceedings, determined that an unfavorable outcome is probable or reasonably possible, or determined that the amount or range of any possible loss is reasonably estimable.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2022-05-20):
[0001327567-22-000016:note_history:5]
The preparation of condensed consolidated financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the condensed consolidated financial statements and the reported amounts of revenues and expenses during the reporting period. We base our estimates on historical experience and also on assumptions that we believe are reasonable. Actual results could differ materially from those estimates due to risks and uncertainties, including uncertainty in the economic environment such as the global impact of the coronavirus disease discovered in 2019 (“COVID-19”).
  (was, 2022-02-23, similarity 0.991):
[0001327567-22-000008:note_history:5]
The preparation of condensed consolidated financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the condensed consolidated financial statements and the reported amounts of revenues and expenses during the reporting period. We base our estimates on historical experience and also on assumptions that we believe are reasonable. Actual results could differ materially from those estimates due to risks and uncertainties, including uncertainty in the economic environment due to the global impact of the coronavirus disease discovered in 2019 (“COVID-19”).

- changed (2022-05-20):
[0001327567-22-000016:note_history:6]
There have been no material changes to our significant accounting policies as of and for the nine months ended April 30, 2022, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended July 31, 2021, except for the change in our accounting policies due to our adoption of recently issued guidance. Refer to “Recently Adopted Accounting Pronouncements” below.
  (was, 2022-02-23, similarity 0.9767):
[0001327567-22-000008:note_history:6]
There have been no material changes to our significant accounting policies as of and for the six months ended January 31, 2022, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended July 31, 2021, except for the change in our accounting policies due to our adoption of recently issued guidance. Refer to “Recently Adopted Accounting Pronouncements” below.


## us-gaap:ConvertibleDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-05-20):
[0001327567-22-000016:note_history:7]
The following table sets forth the components of the Notes as of April 30, 2022 and July 31, 2021 (in millions):
  (was, 2022-02-23, similarity 0.9612):
[0001327567-22-000008:note_history:7]
The following table sets forth the components of the Notes as of January 31, 2022 and July 31, 2021 (in millions):

- changed (2022-05-20):
[0001327567-22-000016:note_history:8]
|  | April 30, 2022 (1) | July 31, 2021 |
|  | 2023 Notes |  | 2025 Notes |  | Total |  | 2023 Notes |  | 2025 Notes |  | Total |
| Liability component: |  |  |  |  |  |  |  |  |  |  |  |
| Principal | $ | 1,692.0 |  |  | $ | 2,000.0 |  |  | $ | 3,692.0 |  |  | $ | 1,692.0 |  |  | $ | 2,000.0 |  |  | $ | 3,692.0 |  |
| Less: debt discount and debt issuance costs, net of amortization | (3.3) |  |  | (13.0) |  |  | (16.3) |  |  | (134.1) |  |  | (331.9) |  |  | (466.0) |  |
| Net carrying amount | $ | 1,688.7 |  |  | $ | 1,987.0 |  |  | $ | 3,675.7 |  |  | $ | 1,557.9 |  |  | $ | 1,668.1 |  |  | $ | 3,226.0 |  |
| Equity component (including amounts classified as temporary equity) | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 315.0 |  |  | $ | 403.0 |  |  | $ | 718.0 |  |
  (was, 2022-02-23, similarity 0.9899):
[0001327567-22-000008:note_history:8]
|  | January 31, 2022 (1) | July 31, 2021 |
|  | 2023 Notes |  | 2025 Notes |  | Total |  | 2023 Notes |  | 2025 Notes |  | Total |
| Liability component: |  |  |  |  |  |  |  |  |  |  |  |
| Principal | $ | 1,692.0 |  |  | $ | 2,000.0 |  |  | $ | 3,692.0 |  |  | $ | 1,692.0 |  |  | $ | 2,000.0 |  |  | $ | 3,692.0 |  |
| Less: debt discount and debt issuance costs, net of amortization | (4.0) |  |  | (14.1) |  |  | (18.1) |  |  | (134.1) |  |  | (331.9) |  |  | (466.0) |  |
| Net carrying amount | $ | 1,688.0 |  |  | $ | 1,985.9 |  |  | $ | 3,673.9 |  |  | $ | 1,557.9 |  |  | $ | 1,668.1 |  |  | $ | 3,226.0 |  |
| Equity component (including amounts classified as temporary equity) | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 315.0 |  |  | $ | 403.0 |  |  | $ | 718.0 |  |


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-05-20):
[0001327567-22-000016:note_history:9]
In July 2018, we issued $1.7 billion aggregate principal amount of 0.75% Convertible Senior Notes due 2023 (the “2023 Notes”) and in June 2020, we issued $2.0 billion aggregate principal amount of 0.375% Convertible Senior Notes due 2025 (the “2025 Notes,” and together with the 2023 Notes, the “Notes”). The 2023 Notes bear interest at a fixed rate of 0.75% per year, payable semi-annually in arrears on January 1 and July 1 of each year, beginning on January 1, 2019. The 2025 Notes bear interest at a fixed rate of 0.375% per year, payable semi-annually in arrears on June 1 and December 1 of each year, beginning on December 1, 2020. Each series of the convertible notes is governed by an indenture between us, as the issuer, and U.S. Bank National Association, as Trustee (individually, each an “Indenture,” and together, the “Indentures”). The Notes of each series are unsecured, unsubordinated obligations and the applicable Indenture governing each series of Notes does not contain any financial covenants or restrictions on the payments of dividends, the incurrence of indebtedness, or the issuance or repurchase of securities by us or any of our subsidiaries. The 2023 Notes and the 2025 Notes mature on July 1, 2023 and June 1, 2025, respectively. We cannot redeem the 2023 Notes prior to maturity. We may redeem for cash all or any portion of the 2025 Notes, at our option, on or after June 5, 2023, and prior to the 31st scheduled trading day immediately preceding the maturity date if the last reported sale price of our common stock has been at least 130% of the conversion price then in effect for at least 20 trading days during any 30 consecutive trading day period ending on and including the trading day preceding the date on which we provide notice of redemption. The redemption will be at a price equal to 100% of the
  (was, 2022-02-23, similarity 0.9237):
[0001327567-22-000008:note_history:9]
In July 2018, we issued $1.7 billion aggregate principal amount of 0.75% Convertible Senior Notes due 2023 (the “2023 Notes”) and in June 2020, we issued $2.0 billion aggregate principal amount of 0.375% Convertible Senior Notes due 2025 (the “2025 Notes,” and together with the 2023 Notes, the “Notes”). The 2023 Notes bear interest at a fixed rate of 0.75% per year, payable semi-annually in arrears on January 1 and July 1 of each year, beginning on January 1, 2019. The 2025 Notes bear interest at a fixed rate of 0.375% per year, payable semi-annually in arrears on June 1 and December 1 of each year, beginning on December 1, 2020. Each series of the convertible notes is governed by an indenture between us, as the issuer, and U.S. Bank National Association, as Trustee (individually, each an “Indenture,” and together, the “Indentures”). The Notes of each series are unsecured, unsubordinated obligations and the applicable Indenture governing each series of Notes does not contain any financial covenants or restrictions on the payments of dividends, the incurrence of indebtedness, or the issuance or repurchase of securities by us or any of our subsidiaries. The 2023 Notes and the 2025 Notes mature on July 1, 2023 and June 1, 2025, respectively. We cannot redeem the 2023 Notes prior to maturity. We may redeem for cash all or any portion of the 2025 Notes, at our option, on or after June 5, 2023, and prior to the 31st scheduled trading day immediately preceding the maturity date if the last reported sale price of our common stock has been at least 130% of the conversion price then in effect for at least 20 trading days during any 30 consecutive trading day period ending on and including the trading day preceding the date on which we provide notice of redemption. The redemption will be at a price equal to 100% of the principal amount of the 2025 Notes and adjusted for interest. If we call any or all of the 2025 Notes for redemption, holders may convert such 2025 Notes called for redemption at any time prior to the close of business on the second scheduled trading day immediately preceding the redemption date.

- added (2022-05-20):
[0001327567-22-000016:note_history:10]
principal amount of the 2025 Notes and adjusted for interest. If we call any or all of the 2025 Notes for redemption, holders may convert such 2025 Notes called for redemption at any time prior to the close of business on the second scheduled trading day immediately preceding the redemption date.

- added (2022-05-20):
[0001327567-22-000016:note_history:11]
The sale price condition for the Notes was met during the fiscal quarter ended April 30, 2022, and as a result, holders may convert their Notes at any time during the fiscal quarter ending July 31, 2022. Accordingly, the net carrying amount of the Notes was classified as a current liability on our condensed consolidated balance sheet as of April 30, 2022.

- changed (2022-05-20):
[0001327567-22-000016:note_history:12]
The following table sets forth the components of the Notes as of April 30, 2022 and July 31, 2021 (in millions):
  (was, 2022-02-23, similarity 0.9612):
[0001327567-22-000008:note_history:12]
The following table sets forth the components of the Notes as of January 31, 2022 and July 31, 2021 (in millions):

- changed (2022-05-20):
[0001327567-22-000016:note_history:13]
|  | April 30, 2022 (1) | July 31, 2021 |
|  | 2023 Notes |  | 2025 Notes |  | Total |  | 2023 Notes |  | 2025 Notes |  | Total |
| Liability component: |  |  |  |  |  |  |  |  |  |  |  |
| Principal | $ | 1,692.0 |  |  | $ | 2,000.0 |  |  | $ | 3,692.0 |  |  | $ | 1,692.0 |  |  | $ | 2,000.0 |  |  | $ | 3,692.0 |  |
| Less: debt discount and debt issuance costs, net of amortization | (3.3) |  |  | (13.0) |  |  | (16.3) |  |  | (134.1) |  |  | (331.9) |  |  | (466.0) |  |
| Net carrying amount | $ | 1,688.7 |  |  | $ | 1,987.0 |  |  | $ | 3,675.7 |  |  | $ | 1,557.9 |  |  | $ | 1,668.1 |  |  | $ | 3,226.0 |  |
| Equity component (including amounts classified as temporary equity) | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 315.0 |  |  | $ | 403.0 |  |  | $ | 718.0 |  |
  (was, 2022-02-23, similarity 0.9899):
[0001327567-22-000008:note_history:13]
|  | January 31, 2022 (1) | July 31, 2021 |
|  | 2023 Notes |  | 2025 Notes |  | Total |  | 2023 Notes |  | 2025 Notes |  | Total |
| Liability component: |  |  |  |  |  |  |  |  |  |  |  |
| Principal | $ | 1,692.0 |  |  | $ | 2,000.0 |  |  | $ | 3,692.0 |  |  | $ | 1,692.0 |  |  | $ | 2,000.0 |  |  | $ | 3,692.0 |  |
| Less: debt discount and debt issuance costs, net of amortization | (4.0) |  |  | (14.1) |  |  | (18.1) |  |  | (134.1) |  |  | (331.9) |  |  | (466.0) |  |
| Net carrying amount | $ | 1,688.0 |  |  | $ | 1,985.9 |  |  | $ | 3,673.9 |  |  | $ | 1,557.9 |  |  | $ | 1,668.1 |  |  | $ | 3,226.0 |  |
| Equity component (including amounts classified as temporary equity) | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 315.0 |  |  | $ | 403.0 |  |  | $ | 718.0 |  |

- changed (2022-05-20):
[0001327567-22-000016:note_history:14]
The total estimated fair value of the 2023 Notes and 2025 Notes were $3.6 billion and $4.0 billion at April 30, 2022, respectively and $2.6 billion and $2.9 billion at July 31, 2021, respectively. The fair value was determined based on the closing trading price per $100 of the applicable series of the Notes as of the last day of trading for the period. We consider the fair value of the Notes at April 30, 2022 and July 31, 2021 to be a Level 2 measurement. The fair value of the Notes is primarily affected by the trading price of our common stock and market interest rates.
  (was, 2022-02-23, similarity 0.6836):
[0001327567-22-000008:note_history:14]
The total estimated fair value of the 2023 Notes and 2025 Notes were $3.3 billion and $3.6 billion at January 31, 2022, respectively and $2.6 billion and $2.9 billion at July 31, 2021, respectively. The fair value was determined based on the closing trading price per $100 of the applicable series of the Notes as of the last day of trading for the period. We consider the fair value of the Notes

- changed (2022-05-20):
[0001327567-22-000016:note_history:15]
|  | Three Months Ended April 30, |  | Nine Months Ended April 30, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
|  | 2023 Notes |  | 2025 Notes |  | Total |  | 2023 Notes |  |  |  | 2025 Notes |  | Total |  | 2023 Notes |  | 2025 Notes |  | Total |  | 2023 Notes |  | 2025 Notes |  | Total |
| Contractual interest expense | $ | 3.2 |  | $ | 1.8 |  | $ | 5.0 |  |  | $ | 3.2 |  |  |  | $ | 1.8 |  | $ | 5.0 |  | $ | 9.5 |  | $ | 5.6 |  | $ | 15.1 |  |  | $ | 9.5 |  | $ | 5.6 |  | $ | 15.1 |  |
| Amortization of debt discount(1) | — |  | — |  | — |  |  | 16.0 |  |  |  | 18.6 |  | 34.6 |  | — |  | — |  | — |  |  | 47.4 |  | 55.3 |  | 102.7 |  |
| Amortization of debt issuance costs | 0.7 |  | 1.1 |  | 1.8 |  |  | 0.6 |  |  |  | 0.7 |  | 1.3 |  | 2.1 |  | 3.3 |  | 5.4 |  |  | 1.7 |  | 2.1 |  | 3.8 |  |
| Total interest expense | $ | 3.9 |  | $ | 2.9 |  | $ | 6.8 |  |  | $ | 19.8 |  |  |  | $ | 21.1 |  | $ | 40.9 |  | $ | 11.6 |  | $ | 8.9 |  | $ | 20.5 |  |  | $ | 58.6 |  | $ | 63.0 |  | $ | 121.6 |  |
| Effective interest rate | 0.9 | % |  | 0.6 | % |  |  |  | 5.2 | % |  |  |  | 5.4 | % |  |  |  | 0.9 | % |  | 0.6 | % |  |  |  | 5.2 | % |  | 5.4 | % |  |  |
  (was, 2022-02-23, similarity 0.9758):
[0001327567-22-000008:note_history:15]
|  | Three Months Ended January 31, |  | Six Months Ended January 31, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
|  | 2023 Notes |  | 2025 Notes |  | Total |  | 2023 Notes |  |  |  | 2025 Notes |  | Total |  | 2023 Notes |  | 2025 Notes |  | Total |  | 2023 Notes |  | 2025 Notes |  | Total |
| Contractual interest expense | $ | 3.1 |  | $ | 1.9 |  | $ | 5.0 |  |  | $ | 3.1 |  |  |  | $ | 1.9 |  | $ | 5.0 |  | $ | 6.3 |  | $ | 3.8 |  | $ | 10.1 |  |  | $ | 6.3 |  | $ | 3.8 |  | $ | 10.1 |  |
| Amortization of debt discount(1) | — |  | — |  | — |  |  | 15.7 |  |  |  | 18.5 |  | 34.2 |  | — |  | — |  | — |  |  | 31.4 |  | 36.7 |  | 68.1 |  |
| Amortization of debt issuance costs | 0.7 |  | 1.1 |  | 1.8 |  |  | 0.6 |  |  |  | 0.7 |  | 1.3 |  | 1.4 |  | 2.2 |  | 3.6 |  |  | 1.1 |  | 1.4 |  | 2.5 |  |
| Total interest expense | $ | 3.8 |  | $ | 3.0 |  | $ | 6.8 |  |  | $ | 19.4 |  |  |  | $ | 21.1 |  | $ | 40.5 |  | $ | 7.7 |  | $ | 6.0 |  | $ | 13.7 |  |  | $ | 38.8 |  | $ | 41.9 |  | $ | 80.7 |  |
| Effective interest rate | 0.9 | % |  | 0.6 | % |  |  |  | 5.2% |  |  |  | 5.4 | % |  |  |  | 0.9 | % |  | 0.6 | % |  |  |  | 5.2 | % |  | 5.4 | % |  |  |

- changed (2022-05-20):
[0001327567-22-000016:note_history:16]
The Note Hedges cover shares of our common stock at a strike price per share that corresponds to the initial applicable conversion price of the applicable series of the Notes, which are also subject to adjustment, and are exercisable upon conversion of the applicable series of the Notes. The Note Hedges will expire upon maturity of the applicable series of the Notes. The Note Hedges are
  (was, 2022-02-23, similarity 0.617):
[0001327567-22-000008:note_history:16]
The Note Hedges cover shares of our common stock at a strike price per share that corresponds to the initial applicable conversion price of the applicable series of the Notes, which are also subject to adjustment, and are exercisable upon conversion of the applicable series of the Notes. The Note Hedges will expire upon maturity of the applicable series of the Notes. The Note Hedges are separate transactions and are not part of the terms of the applicable series of the Notes. Holders of the Notes of either series will not have any rights with respect to the Note Hedges. Any shares of our common stock receivable by us under the Note Hedges are excluded from the calculation of diluted earnings per share as they are antidilutive. The aggregate amounts paid for the Note Hedges are included in additional paid-in capital on our condensed consolidated balance sheets.

- added (2022-05-20):
[0001327567-22-000016:note_history:17]
separate transactions and are not part of the terms of the applicable series of the Notes. Holders of the Notes of either series will not have any rights with respect to the Note Hedges. Any shares of our common stock receivable by us under the Note Hedges are excluded from the calculation of diluted earnings per share as they are antidilutive. The aggregate amounts paid for the Note Hedges are included in additional paid-in capital on our condensed consolidated balance sheets.

- changed (2022-05-20):
[0001327567-22-000016:note_history:18]
The shares issuable under the Warrants will be included in the calculation of diluted earnings per share when the average market value per share of our common stock for the reporting period exceeds the applicable strike price for such series of Warrants. The Warrants are separate transactions and are not part of either series of Notes or Note Hedges and are not remeasured through earnings each reporting period. Holders of the Notes of either series will not have any rights with respect to the Warrants. The aggregate proceeds received from the sale of the Warrants are included in additional paid-in capital on our condensed consolidated balance sheets.
  (was, 2022-02-23, similarity 0.8743):
[0001327567-22-000008:note_history:18]
The shares issuable under the Warrants will be included in the calculation of diluted earnings per share when the average market value per share of our common stock for the reporting period exceeds the applicable strike price for such series of Warrants. The Warrants are separate transactions and are not part of either series of Notes or Note Hedges and are not remeasured through earnings each reporting period. Holders of the Notes of either series will not have any rights with respect to the Warrants. The

- changed (2022-05-20):
[0001327567-22-000016:note_history:19]
As of April 30, 2022, there were no amounts outstanding and we were in compliance with all covenants under the Credit Agreement.
  (was, 2022-02-23, similarity 0.9675):
[0001327567-22-000008:note_history:19]
As of January 31, 2022, there were no amounts outstanding and we were in compliance with all covenants under the Credit Agreement.

- removed (2022-05-20):
[0001327567-22-000008:note_history:20]
The sale price condition for the Notes was met during the fiscal quarter ended January 31, 2022, and as a result, holders may convert their Notes at any time during the fiscal quarter ending April 30, 2022. Accordingly, the net carrying amount of the Notes was classified as a current liability on our condensed consolidated balance sheet as of January 31, 2022.

- removed (2022-05-20):
[0001327567-22-000008:note_history:21]
at January 31, 2022 and July 31, 2021 to be a Level 2 measurement. The fair value of the Notes is primarily affected by the trading price of our common stock and market interest rates.

- removed (2022-05-20):
[0001327567-22-000008:note_history:22]
aggregate proceeds received from the sale of the Warrants are included in additional paid-in capital on our condensed consolidated balance sheets.


## us-gaap:DebtSecuritiesAvailableForSaleTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-05-20):
[0001327567-22-000016:note_history:23]
The following tables summarize the amortized cost, unrealized gains and losses, and fair value of our available-for-sale debt securities as of April 30, 2022 and July 31, 2021 (in millions):
  (was, 2022-02-23, similarity 0.9779):
[0001327567-22-000008:note_history:23]
The following tables summarize the amortized cost, unrealized gains and losses, and fair value of our available-for-sale debt securities as of January 31, 2022 and July 31, 2021 (in millions):

- added (2022-05-20):
[0001327567-22-000016:note_history:24]
|  | April 30, 2022 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 50.0 |  |  | $ | — |  |  | $ | — |  |  | $ | 50.0 |  |
| Commercial paper | 17.9 |  |  | — |  |  | — |  |  | 17.9 |  |
| Corporate debt securities | 3.9 |  |  | — |  |  | — |  |  | 3.9 |  |
| Total available-for-sale cash equivalents | $ | 71.8 |  |  | $ | — |  |  | $ | — |  |  | $ | 71.8 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 205.5 |  |  | $ | — |  |  | $ | — |  |  | $ | 205.5 |  |
| Commercial paper | 11.0 |  |  | — |  |  | — |  |  | 11.0 |  |
| Corporate debt securities | 755.7 |  |  | — |  |  | (11.1) |  |  | 744.6 |  |
| U.S. government and agency securities | 1,081.6 |  |  | — |  |  | (12.0) |  |  | 1,069.6 |  |
| Non-U.S. government and agency securities | 60.4 |  |  | — |  |  | (0.3) |  |  | 60.1 |  |
| Asset-backed securities | 79.3 |  |  | — |  |  | (0.7) |  |  | 78.6 |  |
| Total available-for-sale investments | $ | 2,193.5 |  |  | $ | — |  |  | $ | (24.1) |  |  | $ | 2,169.4 |  |

- removed (2022-05-20):
[0001327567-22-000008:note_history:25]
|  | January 31, 2022 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Corporate debt securities | $ | 8.7 |  |  | $ | — |  |  | $ | — |  |  | $ | 8.7 |  |
| Total available-for-sale cash equivalents | $ | 8.7 |  |  | $ | — |  |  | $ | — |  |  | $ | 8.7 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 305.6 |  |  | $ | — |  |  | $ | — |  |  | $ | 305.6 |  |
| Commercial paper | 1.2 |  |  | — |  |  | — |  |  | 1.2 |  |
| Corporate debt securities | 782.8 |  |  | 0.1 |  |  | (3.7) |  |  | 779.2 |  |
| U.S. government and agency securities | 1,102.6 |  |  | 0.1 |  |  | (5.7) |  |  | 1,097.0 |  |
| Non-U.S. government and agency securities | 60.5 |  |  | — |  |  | (0.2) |  |  | 60.3 |  |
| Asset-backed securities | 25.4 |  |  | — |  |  | (0.1) |  |  | 25.3 |  |
| Total available-for-sale investments | $ | 2,278.1 |  |  | $ | 0.2 |  |  | $ | (9.7) |  |  | $ | 2,268.6 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-05-20):
[0001327567-22-000016:note_history:26]
The following tables summarize the amortized cost, unrealized gains and losses, and fair value of our available-for-sale debt securities as of April 30, 2022 and July 31, 2021 (in millions):
  (was, 2022-02-23, similarity 0.9779):
[0001327567-22-000008:note_history:26]
The following tables summarize the amortized cost, unrealized gains and losses, and fair value of our available-for-sale debt securities as of January 31, 2022 and July 31, 2021 (in millions):

- added (2022-05-20):
[0001327567-22-000016:note_history:27]
|  | April 30, 2022 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 50.0 |  |  | $ | — |  |  | $ | — |  |  | $ | 50.0 |  |
| Commercial paper | 17.9 |  |  | — |  |  | — |  |  | 17.9 |  |
| Corporate debt securities | 3.9 |  |  | — |  |  | — |  |  | 3.9 |  |
| Total available-for-sale cash equivalents | $ | 71.8 |  |  | $ | — |  |  | $ | — |  |  | $ | 71.8 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 205.5 |  |  | $ | — |  |  | $ | — |  |  | $ | 205.5 |  |
| Commercial paper | 11.0 |  |  | — |  |  | — |  |  | 11.0 |  |
| Corporate debt securities | 755.7 |  |  | — |  |  | (11.1) |  |  | 744.6 |  |
| U.S. government and agency securities | 1,081.6 |  |  | — |  |  | (12.0) |  |  | 1,069.6 |  |
| Non-U.S. government and agency securities | 60.4 |  |  | — |  |  | (0.3) |  |  | 60.1 |  |
| Asset-backed securities | 79.3 |  |  | — |  |  | (0.7) |  |  | 78.6 |  |
| Total available-for-sale investments | $ | 2,193.5 |  |  | $ | — |  |  | $ | (24.1) |  |  | $ | 2,169.4 |  |

- changed (2022-05-20):
[0001327567-22-000016:note_history:28]
We do not intend to sell any of the securities in an unrealized loss position and it is not likely that we would be required to sell these securities before recovery of their amortized cost basis, which may be at maturity. We did not recognize any credit losses related to our available-for-sale debt securities during the three and nine months ended April 30, 2022 and 2021.
  (was, 2022-02-23, similarity 0.9741):
[0001327567-22-000008:note_history:28]
We do not intend to sell any of the securities in an unrealized loss position and it is not likely that we would be required to sell these securities before recovery of their amortized cost basis, which may be at maturity. We did not recognize any credit losses related to our available-for-sale debt securities during the three and six months ended January 31, 2022 and 2021.

- changed (2022-05-20):
[0001327567-22-000016:note_history:29]
The following table summarizes the amortized cost and fair value of our available-for-sale debt securities as of April 30, 2022, by contractual years-to-maturity (in millions):
  (was, 2022-02-23, similarity 0.9766):
[0001327567-22-000008:note_history:29]
The following table summarizes the amortized cost and fair value of our available-for-sale debt securities as of January 31, 2022, by contractual years-to-maturity (in millions):

- changed (2022-05-20):
[0001327567-22-000016:note_history:30]
|  | Amortized Cost |  | Fair Value |
| Due within one year | $ | 1,536.2 |  |  | $ | 1,526.5 |  |
| Due between one and three years | 675.2 |  |  | 661.3 |  |
| Due between three to five years | 49.6 |  |  | 49.1 |  |
| Due between five to ten years | 4.3 |  |  | 4.3 |  |
| Total | $ | 2,265.3 |  |  | $ | 2,241.2 |  |
  (was, 2022-02-23, similarity 0.8987):
[0001327567-22-000008:note_history:30]
|  | Amortized Cost |  | Fair Value |
| Due within one year | $ | 1,429.2 |  |  | $ | 1,426.3 |  |
| Due between one and three years | 839.2 |  |  | 832.7 |  |
| Due between three to five years | 18.4 |  |  | 18.3 |  |
| Total | $ | 2,286.8 |  |  | $ | 2,277.3 |  |

- added (2022-05-20):
[0001327567-22-000016:note_history:31]
Marketable equity securities consist of money market funds and are included in cash and cash equivalents on our condensed consolidated balance sheets. As of April 30, 2022 and July 31, 2021, the carrying values of our marketable equity securities were $923.0 million and $124.2 million, respectively. There were no unrealized gains or losses recognized for these securities during the three and nine months ended April 30, 2022 and 2021.

- removed (2022-05-20):
[0001327567-22-000008:note_history:32]
|  | January 31, 2022 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Corporate debt securities | $ | 8.7 |  |  | $ | — |  |  | $ | — |  |  | $ | 8.7 |  |
| Total available-for-sale cash equivalents | $ | 8.7 |  |  | $ | — |  |  | $ | — |  |  | $ | 8.7 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 305.6 |  |  | $ | — |  |  | $ | — |  |  | $ | 305.6 |  |
| Commercial paper | 1.2 |  |  | — |  |  | — |  |  | 1.2 |  |
| Corporate debt securities | 782.8 |  |  | 0.1 |  |  | (3.7) |  |  | 779.2 |  |
| U.S. government and agency securities | 1,102.6 |  |  | 0.1 |  |  | (5.7) |  |  | 1,097.0 |  |
| Non-U.S. government and agency securities | 60.5 |  |  | — |  |  | (0.2) |  |  | 60.3 |  |
| Asset-backed securities | 25.4 |  |  | — |  |  | (0.1) |  |  | 25.3 |  |
| Total available-for-sale investments | $ | 2,278.1 |  |  | $ | 0.2 |  |  | $ | (9.7) |  |  | $ | 2,268.6 |  |

- removed (2022-05-20):
[0001327567-22-000008:note_history:33]
Marketable equity securities consist of money market funds and are included in cash and cash equivalents on our condensed consolidated balance sheets. As of January 31, 2022 and July 31, 2021, the carrying values of our marketable equity securities were 
$475.0 million and $124.2 million, respectively. There were no unrealized gains or losses recognized for these securities during the three and six months ended January 31, 2022 and 2021.


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2022-05-20):
[0001327567-22-000016:note_history:34]
|  | Three Months Ended April 30, |  | Nine Months Ended April 30, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Revenue: |  |  |  |  |  |  |  |
| Americas |  |  |  |  |  |  |  |
| United States | $ | 887.2 |  |  | $ | 683.1 |  |  | $ | 2,557.5 |  |  | $ | 1,950.3 |  |
| Other Americas | 61.5 |  |  | 49.3 |  |  | 173.8 |  |  | 138.4 |  |
| Total Americas | 948.7 |  |  | 732.4 |  |  | 2,731.3 |  |  | 2,088.7 |  |
| Europe, the Middle East, and Africa (“EMEA”) | 269.5 |  |  | 211.0 |  |  | 755.5 |  |  | 590.6 |  |
| Asia Pacific and Japan (“APAC”) | 168.5 |  |  | 130.5 |  |  | 464.2 |  |  | 357.5 |  |
| Total revenue | $ | 1,386.7 |  |  | $ | 1,073.9 |  |  | $ | 3,951.0 |  |  | $ | 3,036.8 |  |
  (was, 2022-02-23, similarity 0.9563):
[0001327567-22-000008:note_history:34]
|  | Three Months Ended January 31, |  | Six Months Ended January 31, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Revenue: |  |  |  |  |  |  |  |
| Americas |  |  |  |  |  |  |  |
| United States | $ | 858.6 |  |  | $ | 642.8 |  |  | $ | 1,670.3 |  |  | $ | 1,267.2 |  |
| Other Americas | 57.3 |  |  | 47.0 |  |  | 112.3 |  |  | 89.1 |  |
| Total Americas | 915.9 |  |  | 689.8 |  |  | 1,782.6 |  |  | 1,356.3 |  |
| Europe, the Middle East, and Africa (“EMEA”) | 252.2 |  |  | 206.2 |  |  | 486.0 |  |  | 379.6 |  |
| Asia Pacific and Japan (“APAC”) | 148.8 |  |  | 120.9 |  |  | 295.7 |  |  | 227.0 |  |
| Total revenue | $ | 1,316.9 |  |  | $ | 1,016.9 |  |  | $ | 2,564.3 |  |  | $ | 1,962.9 |  |

- added (2022-05-20):
[0001327567-22-000016:note_history:35]
|  | Three Months Ended April 30, |  | Nine Months Ended April 30, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Revenue: |  |  |  |  |  |  |  |
| Product | $ | 351.5 |  |  | $ | 288.9 |  |  | $ | 955.0 |  |  | $ | 780.9 |  |
| Subscription and support |  |  |  |  |  |  |  |
| Subscription | 639.8 |  |  | 473.8 |  |  | 1,836.6 |  |  | 1,363.5 |  |
| Support | 395.4 |  |  | 311.2 |  |  | 1,159.4 |  |  | 892.4 |  |
| Total subscription and support | 1,035.2 |  |  | 785.0 |  |  | 2,996.0 |  |  | 2,255.9 |  |
| Total revenue | $ | 1,386.7 |  |  | $ | 1,073.9 |  |  | $ | 3,951.0 |  |  | $ | 3,036.8 |  |

- changed (2022-05-20):
[0001327567-22-000016:note_history:36]
During the nine months ended April 30, 2022 and 2021, we recognized approximately $2.2 billion and $1.6 billion of revenue pertaining to amounts that were deferred as of July 31, 2021 and 2020, respectively.
  (was, 2022-02-23, similarity 0.965):
[0001327567-22-000008:note_history:36]
During the six months ended January 31, 2022 and 2021, we recognized approximately $1.6 billion and $1.2 billion of revenue pertaining to amounts that were deferred as of July 31, 2021 and 2020, respectively.

- changed (2022-05-20):
[0001327567-22-000016:note_history:37]
Revenue expected to be recognized from remaining performance obligations was $6.9 billion as of April 30, 2022, of which we expect to recognize approximately $3.6 billion over the next 12 months and the remainder thereafter.
  (was, 2022-02-23, similarity 0.972):
[0001327567-22-000008:note_history:37]
Revenue expected to be recognized from remaining performance obligations was $6.3 billion as of January 31, 2022, of which we expect to recognize approximately $3.4 billion over the next 12 months and the remainder thereafter.

- removed (2022-05-20):
[0001327567-22-000008:note_history:38]
|  | Three Months Ended January 31, |  | Six Months Ended January 31, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Revenue: |  |  |  |  |  |  |  |
| Product | $ | 308.0 |  |  | $ | 254.7 |  |  | $ | 603.5 |  |  | $ | 492.0 |  |
| Subscription and support |  |  |  |  |  |  |  |
| Subscription | 618.0 |  |  | 461.7 |  |  | 1,196.8 |  |  | 889.7 |  |
| Support | 390.9 |  |  | 300.5 |  |  | 764.0 |  |  | 581.2 |  |
| Total subscription and support | 1,008.9 |  |  | 762.2 |  |  | 1,960.8 |  |  | 1,470.9 |  |
| Total revenue | $ | 1,316.9 |  |  | $ | 1,016.9 |  |  | $ | 2,564.3 |  |  | $ | 1,962.9 |  |
