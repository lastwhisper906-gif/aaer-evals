# PANW 8-K — 0001327567-18-000029 filed 2018-11-29

## item codes, every 8-K on or before 2018-11-30

- 2018-11-29 0001327567-18-000029 — 2.02, 9.01
- 2018-10-15 0001193125-18-299312 — 5.02, 9.01
- 2018-09-25 0001193125-18-282542 — 5.02
- 2018-09-14 0001193125-18-274239 — 5.03, 9.01
- 2018-09-06 0001327567-18-000018 — 1.01, 2.02, 2.03, 9.01
- 2018-07-13 0001193125-18-217281 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2018-06-04 0001327567-18-000011 — 2.02, 5.02, 9.01
- 2018-02-26 0001327567-18-000004 — 2.02, 5.02, 7.01, 9.01
- 2017-12-12 0001193125-17-367477 — 5.07
- 2017-11-20 0001327567-17-000032 — 2.02, 5.02, 9.01
- 2017-08-31 0001327567-17-000021 — 2.02, 5.02, 9.01
- 2017-05-31 0001327567-17-000016 — 2.02, 9.01
- 2017-02-28 0001327567-17-000005 — 2.02, 8.01, 9.01
- 2016-12-12 0001193125-16-790757 — 5.07
- 2016-11-21 0001327567-16-000071 — 2.02, 9.01
- 2016-10-24 0001193125-16-745121 — 5.02, 9.01
- 2016-08-30 0001327567-16-000057 — 2.02, 5.03, 8.01, 9.01
- 2016-08-22 0001193125-16-687588 — 5.02, 9.01
- 2016-05-26 0001327567-16-000051 — 2.02, 9.01
- 2016-02-25 0001327567-16-000044 — 2.02, 5.02, 9.01
- 2015-12-14 0001327567-15-000038 — 5.07
- 2015-12-14 0001193125-15-402588 — 1.01, 9.01
- 2015-11-23 0001327567-15-000033 — 2.02, 9.01
- 2015-10-19 0001193125-15-347005 — 1.01, 9.01 — amendment, the index does not say of what
- 2015-09-09 0001327567-15-000022 — 2.02, 9.01
- 2015-08-19 0001193125-15-296115 — 1.01, 2.03
- 2015-06-01 0001193125-15-207786 — 1.01, 2.03
- 2015-05-27 0001327567-15-000015 — 2.02, 9.01
- 2015-03-02 0001327567-15-000006 — 2.02, 9.01
- 2014-12-15 0001327567-14-000046 — 5.07
- 2014-11-24 0001327567-14-000040 — 2.02, 9.01
- 2014-09-22 0001193125-14-348581 — 5.02, 9.01
- 2014-09-09 0001327567-14-000025 — 2.02, 9.01
- 2014-07-01 0001193125-14-257824 — 1.01, 2.03, 3.02, 9.01
- 2014-06-26 0001193125-14-249529 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2014-06-20 0001327567-14-000020 — 9.01 — amendment of 0001193125-14-140511
- 2014-06-04 0001327567-14-000016 — 3.02
- 2014-05-30 0001193125-14-218158 — 2.02 — amendment, the index does not say of what
- 2014-05-28 0001193125-14-215060 — 1.01, 2.02, 3.02, 9.01
- 2014-04-11 0001193125-14-140511 — 2.01, 3.02, 7.01, 9.01
- 2014-03-24 0001193125-14-111318 — 1.01, 3.02, 7.01, 9.01
- 2014-03-13 0001327567-14-000009 — 5.02
- 2014-02-24 0001193125-14-063754 — 2.02, 9.01
- 2013-12-12 0001327567-13-000040 — 5.07
- 2013-11-25 0001327567-13-000033 — 2.02, 9.01
- 2013-09-30 0001193125-13-384966 — 8.01
- 2013-09-09 0001193125-13-361421 — 2.02, 9.01
- 2013-05-30 0001193125-13-241542 — 2.02, 5.02, 9.01
- 2013-03-11 0001193125-13-101082 — 5.02, 9.01
- 2013-02-28 0001193125-13-084193 — 2.02, 9.01
- 2012-12-14 0001193125-12-503335 — 5.07
- 2012-12-06 0001193125-12-493700 — 2.02, 9.01
- 2012-09-24 0001193125-12-401534 — 1.01, 2.03
- 2012-09-20 0001193125-12-398433 — 5.02, 9.01
- 2012-09-10 0001193125-12-386605 — 2.02, 9.01

## late-filing notifications on or before 2018-11-30

- none on or before 2018-11-30

## item 2.02 — earnings release, exhibit 99.1

[0001327567-18-000029:8k_2_02:1]
EX-99.1
2
ex991q119earningsrelease.htm
EXHIBIT 99.1

[0001327567-18-000029:8k_2_02:2]
Exhibit

[0001327567-18-000029:8k_2_02:3]
Exhibit 99.1

[0001327567-18-000029:8k_2_02:4]
Palo Alto Networks Reports Fiscal First Quarter 2019 Financial Results

[0001327567-18-000029:8k_2_02:5]
| • | Fiscal first quarter revenue grows 31 percent year over year to $656 million |

[0001327567-18-000029:8k_2_02:6]
| • | Fiscal first quarter billings grow 27 percent year over year to $758.5 million |

[0001327567-18-000029:8k_2_02:7]
| • | Deferred revenue grows 34 percent year over year to $2.4 billion |

[0001327567-18-000029:8k_2_02:8]
SANTA CLARA, Calif. — November 29, 2018 — Palo Alto Networks (NYSE: PANW), the global cybersecurity leader, announced today financial results for its fiscal first quarter 2019, ended October 31, 2018. Palo Alto Networks adopted the new revenue standard ASC 606 as of August 1, 2018 using the full retrospective method. Prior period information, and the financial outlook provided below (including all comparative references), have been adjusted to reflect the adoption of the new standard.

[0001327567-18-000029:8k_2_02:9]
Total revenue for the fiscal first quarter 2019 grew 31 percent year over year to $656 million, compared with total revenue of $501.8 million for the fiscal first quarter 2018. GAAP net loss for the fiscal first quarter 2019 was $38.3 million, or $0.41 per diluted share, compared with GAAP net loss of $63.2 million, or $0.70 per diluted share, for the fiscal first quarter 2018.

[0001327567-18-000029:8k_2_02:10]
Non-GAAP net income for the fiscal first quarter 2019 was $115.4 million, or $1.17 per diluted share, compared with non-GAAP net income of $70.3 million, or $0.75 per diluted share, for the fiscal first quarter 2018. A reconciliation between GAAP and non-GAAP information is contained in the tables below.

[0001327567-18-000029:8k_2_02:11]
“We had an excellent start to the fiscal year that highlights the continued strength of our platform,” said Nikesh Arora, chief executive officer of Palo Alto Networks. “Our approach of providing best-in-class security products, combined with automation and integration to remove complexity, continues to resonate with customers. The completion of our RedLock acquisition during the quarter marks another important step forward in our cloud security strategy. We expect to deliver an integrated offering early next year that combines RedLock’s technologies with our existing cloud security products to help our customers secure their mobile workforce, protect the public cloud and stop advanced threats.”

[0001327567-18-000029:8k_2_02:12]
“We are very pleased with our first quarter results,” said Kathy Bonanno, chief financial officer of Palo Alto Networks. “On the top line, both product and subscription revenue increased by more than 30 percent year over year, and on the bottom line, we expanded both GAAP and non-GAAP earnings per share and operating margin.”

[0001327567-18-000029:8k_2_02:13]
Financial Outlook

[0001327567-18-000029:8k_2_02:14]
Palo Alto Networks provides guidance based on current market conditions and expectations.

[0001327567-18-000029:8k_2_02:15]
For the fiscal second quarter 2019, we expect:

[0001327567-18-000029:8k_2_02:16]
| • | Total revenue in the range of $675 to $685 million, representing year-over-year growth between 24 percent and 26 percent on an ASC 606 basis. |

[0001327567-18-000029:8k_2_02:17]
| • | Diluted non-GAAP net income per share in the range of $1.20 to $1.22 using 99 to 101 million shares on an ASC 606 basis. |

[0001327567-18-000029:8k_2_02:18]
Guidance for non-GAAP financial measures excludes share-based compensation-related charges, including share-based payroll tax expense, acquisition-related costs, amortization

[0001327567-18-000029:8k_2_02:19]
2

[0001327567-18-000029:8k_2_02:20]
expense of acquired intangible assets, litigation-related charges, including legal settlements, facility exit costs, non-cash charges related to convertible notes, foreign currency gains (losses), and income and other tax effects associated with these items, along with certain non-recurring expenses. We have not reconciled diluted non-GAAP net income per share guidance to GAAP net income (loss) per diluted share because we do not provide guidance on GAAP net income (loss) and would not be able to present the various reconciling cash and non-cash items between GAAP net income (loss) and non-GAAP net income, including share-based compensation expense, without unreasonable effort. Share-based compensation expense is impacted by the company’s future hiring and retention needs and, to a lesser extent, the future fair market value of the company’s common stock, all of which is difficult to predict and subject to constant change. The actual amounts of such reconciling items will have a significant impact on the company’s GAAP net income (loss) per diluted share.

[0001327567-18-000029:8k_2_02:21]
Conference Call Information

[0001327567-18-000029:8k_2_02:22]
Palo Alto Networks will host a conference call for analysts and investors to discuss its fiscal first quarter 2019 results and outlook for its fiscal second quarter 2019 today at 4:30 p.m. Eastern time/1:30 p.m. Pacific time. Open to the public, investors may access the call by dialing 1-855-719-5012 or 1-334-323-0522 and using conference ID 2202662. A live audio webcast of the conference call, along with supplemental financial information, will also be accessible from the “Investors” section of our website at investors.paloaltonetworks.com. Following the webcast, an archived version will be available on our website for one year. A telephonic replay of the call will be available three hours after the call, will run for ten days, and may be accessed by dialing 1-888-203-1112 or 1-719-457-0820 and entering the passcode 2202662.

[0001327567-18-000029:8k_2_02:23]
Forward-Looking Statements

[0001327567-18-000029:8k_2_02:24]
This press release contains forward-looking statements that involve risks and uncertainties, including statements regarding the timing and effectiveness of the integration of RedLock’s technologies to our existing cloud security products, our future financial and operating performance, our financial outlook for the fiscal second quarter 2019, and the continued ability of our business strategy to resonate with customers. There are a significant number of factors that could cause actual results to differ materially from statements made in this press release, including: our limited operating history; our ability as an organization to acquire and integrate other companies, products or technologies in a successful manner; risks associated with managing our rapid growth; the risks associated with new products and subscription and support offerings, including the discovery of software bugs; disclosed organizational changes and the timing of those changes; our ability to attract and retain new customers; delays in the development or release of new subscription offerings, or the failure to timely develop and achieve market acceptance of new products and subscriptions as well as existing products and subscription and support offerings; rapidly evolving technological developments in the market for security products and subscription and support offerings; length of sales cycles; and general market, political, economic and business conditions.

[0001327567-18-000029:8k_2_02:25]
Additional risks and uncertainties that could affect our financial results are included under the captions “Risk Factors” and “Management’s Discussion and Analysis of Financial Condition and Results of Operations” in our Annual Report on Form 10-K filed with the SEC on September 13, 2018, which is available on our website at investors.paloaltonetworks.com and on the SEC’s website at www.sec.gov. Additional information will also be set forth in other filings that we make with the SEC from time to time. All forward-looking statements in this press release are based on information available to us as of the date hereof, and we do not assume any obligation to

[0001327567-18-000029:8k_2_02:26]
4

[0001327567-18-000029:8k_2_02:27]
update the forward-looking statements provided to reflect events that occur or circumstances that exist after the date on which they were made.

[0001327567-18-000029:8k_2_02:28]
Non-GAAP Financial Measures and Other Key Metrics

[0001327567-18-000029:8k_2_02:29]
Palo Alto Networks has provided in this press release financial information that has not been prepared in accordance with generally accepted accounting principles in the United States (GAAP). The company uses these non-GAAP financial measures and key metrics internally in analyzing its financial results and believes that the use of these non-GAAP financial measures and key metrics is useful to investors as an additional tool to evaluate ongoing operating results and trends, and in comparing the company’s financial results with other companies in its industry, many of which present similar non-GAAP financial measures or key metrics.

[0001327567-18-000029:8k_2_02:30]
The presentation of these non-GAAP financial measures and key metrics are not meant to be considered in isolation or as a substitute for comparable GAAP financial measures and should be read only in conjunction with the company’s consolidated financial statements prepared in accordance with GAAP. A reconciliation of the company’s historical non-GAAP financial measures and key metrics to their most directly comparable GAAP measures has been provided in the financial statement tables included in this press release, and investors are encouraged to review these reconciliations.

[0001327567-18-000029:8k_2_02:31]
Non-GAAP net income and net income per share, diluted. Palo Alto Networks defines non-GAAP net income as net income (loss) plus share-based compensation-related charges, including share-based payroll tax expense, acquisition-related costs, amortization expense of acquired intangible assets, litigation-related charges, including legal settlements, facility exit costs, non-cash charges related to convertible notes, and intellectual property restructuring-

[0001327567-18-000029:8k_2_02:32]
related charges. The company also excludes from non-GAAP net income the foreign currency gains (losses) and tax effects associated with these items in order to provide a complete picture of the company’s recurring core business operating results. The company defines non-GAAP net income per share, diluted, as non-GAAP net income divided by the weighted-average diluted shares outstanding, which includes the potentially dilutive effect of the company’s employee equity incentive plan awards and the company’s convertible senior notes outstanding and related warrants, after giving effect to the anti-dilutive impact of the company’s note hedge agreements, which reduces the potential economic dilution that otherwise would occur upon conversion of the company’s convertible senior notes. Under GAAP, the anti-dilutive impact of the note hedge is not reflected in diluted shares outstanding. The company believes that excluding these items from non-GAAP net income and net income per share, diluted, provides management and investors with greater visibility into the underlying performance of the company’s core business operating results, meaning its operating performance excluding these items and, from time to time, other discrete charges that are infrequent in nature, over multiple periods.

[0001327567-18-000029:8k_2_02:33]
Billings. Palo Alto Networks defines billings as total revenue plus the change in total deferred revenue, net of acquired deferred revenue, during the period. The company considers billings to be a key metric used by management to manage the company’s business given the company’s hybrid-SaaS revenue model, and believes billings provides investors with an important indicator of the health and visibility of the company’s business because it includes subscription and support revenue, which is recognized ratably over the contractual service period, and product revenue, which is recognized at the time of shipment, provided that all other conditions for revenue recognition have been met. The company considers billings to be a useful metric for

[0001327567-18-000029:8k_2_02:34]
6

[0001327567-18-000029:8k_2_02:35]
management and investors, particularly if sales of subscriptions continue to increase and the company experiences strong renewal rates for subscriptions and support.

[0001327567-18-000029:8k_2_02:36]
Investors are cautioned that there are a number of limitations associated with the use of non-GAAP financial measures and key metrics as analytical tools. In particular, the billings metric reported by the company includes amounts that have not yet been recognized as revenue. In addition, many of the adjustments to the company’s GAAP financial measures reflect the exclusion of items that are recurring and will be reflected in the company’s financial results for the foreseeable future, such as share-based compensation, which is an important part of Palo Alto Networks employees’ compensation and impacts their performance. Furthermore, these non-GAAP financial measures are not based on any standardized methodology prescribed by GAAP, and the components that Palo Alto Networks excludes in its calculation of non-GAAP financial measures may differ from the components that its peer companies exclude when they report their non-GAAP results of operations. Palo Alto Networks compensates for these limitations by providing specific information regarding the GAAP amounts excluded from these non-GAAP financial measures. In the future, the company may also exclude non-recurring expenses and other expenses that do not reflect the company’s core business operating results.

[0001327567-18-000029:8k_2_02:37]
About Palo Alto Networks

[0001327567-18-000029:8k_2_02:38]
We are the global cybersecurity leader, known for always challenging the security status quo. Our mission is to protect our way of life in the digital age by preventing successful cyberattacks. This has given us the privilege of safely enabling tens of thousands of organizations and their customers. Our pioneering Security Operating Platform emboldens their digital transformation with continuous innovation that seizes the latest breakthroughs in security, automation, and analytics. By delivering a true platform and empowering a growing ecosystem of change-makers

[0001327567-18-000029:8k_2_02:39]
like us, we provide highly effective and innovative cybersecurity across clouds, networks, and mobile devices.

[0001327567-18-000029:8k_2_02:40]
Palo Alto Networks and the Palo Alto Networks logo are trademarks of Palo Alto Networks, Inc. in the United States and in jurisdictions throughout the world. All other trademarks, trade names or service marks used or mentioned herein belong to their respective owners.

[0001327567-18-000029:8k_2_02:41]
Media Contact:

[0001327567-18-000029:8k_2_02:42]
Kristen Batch

[0001327567-18-000029:8k_2_02:43]
Senior Vice President of Corporate Communications, Palo Alto Networks

[0001327567-18-000029:8k_2_02:44]
Mobile: 503-516-6297

[0001327567-18-000029:8k_2_02:45]
kbatch@paloaltonetworks.com

[0001327567-18-000029:8k_2_02:46]
Investor Relations Contact:

[0001327567-18-000029:8k_2_02:47]
Amber Ossman

[0001327567-18-000029:8k_2_02:48]
Director, Investor Relations, Palo Alto Networks

[0001327567-18-000029:8k_2_02:49]
Work: 408-753-4235

[0001327567-18-000029:8k_2_02:50]
aossman@paloaltonetworks.com

[0001327567-18-000029:8k_2_02:51]
| Palo Alto Networks, Inc. |
| Preliminary Condensed Consolidated Statements of Operations |
| (In millions, except per share data) |
| (Unaudited) |
|  | Three Months Ended October 31, |
|  | 2018 |  | 2017 |
|  |  |  | (As Adjusted)(1) |
| Revenue: |  |  |  |
| Product | $ | 240.5 |  |  | $ | 184.8 |  |
| Subscription and support | 415.5 |  |  | 317.0 |  |
| Total revenue | 656.0 |  |  | 501.8 |  |
| Cost of revenue: |  |  |  |
| Product | 73.2 |  |  | 57.6 |  |
| Subscription and support | 110.3 |  |  | 83.7 |  |
| Total cost of revenue | 183.5 |  |  | 141.3 |  |
| Total gross profit | 472.5 |  |  | 360.5 |  |
| Operating expenses: |  |  |  |
| Research and development | 113.4 |  |  | 94.2 |  |
| Sales and marketing | 314.6 |  |  | 254.1 |  |
| General and administrative | 76.6 |  |  | 65.7 |  |
| Total operating expenses | 504.6 |  |  | 414.0 |  |
| Operating loss | (32.1 | ) |  | (53.5 | ) |
| Interest expense | (22.7 | ) |  | (6.3 | ) |
| Other income, net | 13.0 |  |  | 4.8 |  |
| Loss before income taxes | (41.8 | ) |  | (55.0 | ) |
| Provision for (benefit from) income taxes | (3.5 | ) |  | 8.2 |  |
| Net loss | $ | (38.3 | ) |  | $ | (63.2 | ) |
| Net loss per share, basic and diluted | $ | (0.41 | ) |  | $ | (0.70 | ) |
| Weighted-average shares used to compute net loss per share, basic and diluted | 93.8 |  |  | 90.9 |  |

[0001327567-18-000029:8k_2_02:52]
______________

[0001327567-18-000029:8k_2_02:53]
| (1) | Certain amounts have been adjusted due to the company’s adoption of the new revenue recognition standard. |

[0001327567-18-000029:8k_2_02:54]
9

[0001327567-18-000029:8k_2_02:55]
| Palo Alto Networks, Inc. |
| Reconciliation of GAAP to Non-GAAP Financial Measures |
| (In millions, except per share amounts) |
| (Unaudited) |
|  | Three Months Ended |
|  | October 31, |
|  | 2018 |  | 2017 |
|  |  |  | (As Adjusted)(1) |
| GAAP net loss | $ | (38.3 | ) |  | $ | (63.2 | ) |
| Share-based compensation-related charges | 140.7 |  |  | 128.9 |  |
| Acquisition-related costs(2) | 15.5 |  |  | — |  |
| Amortization expense of acquired intangible assets | 9.3 |  |  | 2.5 |  |
| Litigation-related charges(3) | 3.1 |  |  | 3.1 |  |
| Facility exit costs(4) | — |  |  | 15.6 |  |
| Non-cash charges related to convertible notes(5) | 21.6 |  |  | 6.3 |  |
| Foreign currency (gain) loss associated with non-GAAP adjustments | (0.5 | ) |  | 0.5 |  |
| Income tax and other tax adjustments related to the above(6) | (36.0 | ) |  | (23.4 | ) |
| Non-GAAP net income | $ | 115.4 |  |  | $ | 70.3 |  |
| GAAP net loss per share, diluted | $ | (0.41 | ) |  | $ | (0.70 | ) |
| Share-based compensation-related charges | 1.44 |  |  | 1.38 |  |
| Acquisition-related costs(2) | 0.17 |  |  | 0.00 |  |
| Amortization expense of acquired intangible assets | 0.10 |  |  | 0.03 |  |
| Litigation-related charges(3) | 0.03 |  |  | 0.03 |  |
| Facility exit costs(4) | 0.00 |  |  | 0.17 |  |
| Non-cash charges related to convertible notes(5) | 0.23 |  |  | 0.07 |  |
| Foreign currency (gain) loss associated with non-GAAP adjustments | (0.01 | ) |  | 0.01 |  |
| Income tax and other tax adjustments related to the above(6) | (0.38 | ) |  | (0.24 | ) |
| Non-GAAP net income per share, diluted | $ | 1.17 |  |  | $ | 0.75 |  |
| GAAP weighted-average shares used to compute net loss per share, diluted | 93.8 |  |  | 90.9 |  |
| Weighted-average effect of potentially dilutive securities(7) | 5.2 |  |  | 2.8 |  |
| Non-GAAP weighted-average shares used to compute net income per share, diluted | 99.0 |  |  | 93.7 |  |

[0001327567-18-000029:8k_2_02:56]
___________

[0001327567-18-000029:8k_2_02:57]
| (1) | Certain amounts have been adjusted due to the company’s adoption of the new revenue recognition standard. |

[0001327567-18-000029:8k_2_02:58]
| (2) | Consists of acquisition transaction costs, share-based compensation related to the cash settlement of certain equity awards, and costs to terminate certain employment and operating lease contracts of the acquired company. |

[0001327567-18-000029:8k_2_02:59]
| (3) | Consists of the amortization of intellectual property licenses. |

[0001327567-18-000029:8k_2_02:60]
| (4) | Consists of charges related to the relocation of the company’s corporate headquarters, including a cease-use loss of $15.4 million and accelerated depreciation. |

[0001327567-18-000029:8k_2_02:61]
| (5) | Consists of non-cash interest expense of $19.4 million related to the company’s convertible senior notes and a non-cash loss of $2.2 million related to early conversions of the convertible notes during the three months ended October 31, 2018. |

[0001327567-18-000029:8k_2_02:62]
| (6) | The company changed its non-GAAP effective tax rate from 31% to 22% in its second quarter of fiscal 2018 due to the reduction of the U.S. federal corporate income tax rate under the U.S. Tax Cuts and Jobs Act, which was enacted into law on December 22, 2017. |

[0001327567-18-000029:8k_2_02:63]
| (7) | Non-GAAP net income per share, diluted, includes the potentially dilutive effect of employee equity incentive plan awards and convertible senior notes outstanding and related warrants. In addition, non-GAAP net income per share, diluted, includes the anti-dilutive impact of the company’s note hedge agreements, which reduced the potentially dilutive effect of the convertible notes by 1.1 million and 1.3 million shares for the three months ended October 31, 2018 and October 31, 2017, respectively. |

[0001327567-18-000029:8k_2_02:64]
10

[0001327567-18-000029:8k_2_02:65]
| Palo Alto Networks, Inc. |
| Calculation of Billings |
| (In millions) |
| (Unaudited) |
|  | Three Months Ended |
|  | October 31, |
|  | 2018 |  | 2017 |
|  |  |  | (As Adjusted)(1) |
| Total revenue | $ | 656.0 |  |  | $ | 501.8 |  |
| Add: change in total deferred revenue, net of acquired deferred revenue | 102.5 |  |  | 93.6 |  |
| Billings | $ | 758.5 |  |  | $ | 595.4 |  |

[0001327567-18-000029:8k_2_02:66]
___________

[0001327567-18-000029:8k_2_02:67]
| (1) | These amounts have been adjusted due to the company’s adoption of the new revenue recognition standard. |

[0001327567-18-000029:8k_2_02:68]
11

[0001327567-18-000029:8k_2_02:69]
| Palo Alto Networks, Inc. |
| Preliminary Condensed Consolidated Balance Sheets |
| (In millions) |
| (Unaudited) |
|  | October 31, 2018 |  | July 31, 2018 |
|  |  |  | (As Adjusted)(1) |
| Assets |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 1,784.4 |  |  | $ | 2,506.9 |  |
| Short-term investments | 1,419.4 |  |  | 896.5 |  |
| Accounts receivable, net | 382.3 |  |  | 467.0 |  |
| Prepaid expenses and other current assets | 229.1 |  |  | 268.1 |  |
| Total current assets | 3,815.2 |  |  | 4,138.5 |  |
| Property and equipment, net | 276.5 |  |  | 273.1 |  |
| Long-term investments | 565.5 |  |  | 547.5 |  |
| Goodwill | 636.4 |  |  | 522.8 |  |
| Intangible assets, net | 186.2 |  |  | 140.8 |  |
| Other assets | 321.7 |  |  | 326.2 |  |
| Total assets | $ | 5,801.5 |  |  | $ | 5,948.9 |  |
| Liabilities, temporary equity, and stockholders’ equity |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 43.0 |  |  | $ | 49.4 |  |
| Accrued compensation | 99.4 |  |  | 163.7 |  |
| Accrued and other liabilities | 163.6 |  |  | 124.6 |  |
| Deferred revenue | 1,269.8 |  |  | 1,213.6 |  |
| Convertible senior notes, net | 239.9 |  |  | 550.4 |  |
| Total current liabilities | 1,815.7 |  |  | 2,101.7 |  |
| Convertible senior notes, net | 1,384.5 |  |  | 1,369.7 |  |
| Long-term deferred revenue | 1,114.6 |  |  | 1,065.7 |  |
| Other long-term liabilities | 226.8 |  |  | 229.6 |  |
| Temporary equity | 6.9 |  |  | 21.9 |  |
| Stockholders’ equity: |  |  |  |
| Preferred stock | — |  |  | — |  |
| Common stock and additional paid-in capital | 2,129.3 |  |  | 1,967.4 |  |
| Accumulated other comprehensive loss | (19.0 | ) |  | (16.4 | ) |
| Accumulated deficit | (857.3 | ) |  | (790.7 | ) |
| Total stockholders’ equity | 1,253.0 |  |  | 1,160.3 |  |
| Total liabilities, temporary equity, and stockholders’ equity | $ | 5,801.5 |  |  | $ | 5,948.9 |  |

[0001327567-18-000029:8k_2_02:70]
______________

[0001327567-18-000029:8k_2_02:71]
| (1) | Certain amounts have been adjusted due to the company’s adoption of the new revenue recognition standard. |

[0001327567-18-000029:8k_2_02:72]
12
