# PANW note change history — 0001327567-18-000014 → 0001327567-18-000031


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2018-11-30):
[0001327567-18-000031:note_history:1]
In May 2015 and October 2015, we entered into a total of three lease agreements for approximately 941,000 square feet of corporate office space in Santa Clara, California, which serves as our new corporate headquarters. The leases contain rent holiday periods, scheduled rent increases, lease incentives, and renewal options which allow the lease terms to be extended beyond their expiration dates of July 2028 through July 2046. In September 2017, per the terms of the lease agreements, the landlords exercised their option to amend our lease payment schedules and eliminate our rent holiday periods, which increased our rental payments by $24.4 million, $11.8 million, and $2.0 million for fiscal 2018, 2019, and 2020, respectively. In exchange, we received an upfront cash reimbursement of $38.2 million during the three months ended October 31, 2017, which we have applied and will apply against the future additional rental payments when due. As amended, rental payments under the three lease agreements are approximately $412.0 million over the lease term.
  (was, 2018-06-05, similarity 0.8164):
[0001327567-18-000014:note_history:1]
In May 2015 and October 2015, we entered into a total of three lease agreements for approximately 941,000 square feet of corporate office space in Santa Clara, California, which serves as our new corporate headquarters. The leases contain rent holiday periods, scheduled rent increases, lease incentives, and renewal options which allow the lease terms to be extended beyond their expiration dates of July 2028 through July 2046. In September 2017, per the terms of the lease agreements, the landlords exercised their option to amend our lease payment schedules and eliminate our rent holiday periods, which increased our rental payments by $24.4 million, $11.8 million, and $2.0 million for fiscal 2018, 2019, and 2020, respectively. In exchange, we received an upfront cash reimbursement of $38.2 million during the three months ended October 31, 2017, which we will apply against the future additional rental payments when due. As amended, rental payments under the three lease agreements are approximately $412.0 million over the lease terms.

- added (2018-11-30):
[0001327567-18-000031:note_history:2]
In September 2012, we entered into two lease agreements for a total of approximately 300,000 square feet of space in Santa Clara, California, which served as our previous corporate headquarters through August 2017, when we relocated to our new corporate campus. The leases contain rent holiday periods and two separate five-year options to extend the lease term beyond their expiration dates of July 2023. Rental payments under these lease agreements are approximately $94.3 million over the lease term. In August 2017, we exited our previous headquarter facilities and relocated to our new corporate campus, which resulted in the recognition of a cease-use loss of $39.2 million as general and administrative expense in our consolidated statements of operations during the year ended July 31, 2018, and a corresponding liability in our consolidated balance sheets. During the three months ended October 31, 2018, we released $2.5 million of the cease-use liability through rental payments. As of October 31, 2018, the remaining balance of the cease-use liability was $26.6 million, which is expected to be paid through the end of the lease term in July 2023.

- changed (2018-11-30):
[0001327567-18-000031:note_history:3]
The following table presents details of the aggregate future non-cancelable minimum rental payments under our operating leases as of October 31, 2018 (in millions):
  (was, 2018-06-05, similarity 0.9684):
[0001327567-18-000014:note_history:3]
The following table presents details of the aggregate future non-cancelable minimum rental payments under our operating leases as of April 30, 2018 (in millions):

- added (2018-11-30):
[0001327567-18-000031:note_history:4]
Purchase Commitments

- changed (2018-11-30):
[0001327567-18-000031:note_history:5]
Our electronics manufacturing service provider (“EMS provider”) procures components and assembles our products based on our forecasts. These forecasts are based on estimates of demand for our products primarily for the next 12 months, which are in turn based on historical trends and an analysis from our sales and product management organizations, adjusted for overall market conditions. In order to reduce manufacturing lead times and plan for adequate supply, we may issue non-cancelable orders for products and components to our manufacturing partners or component suppliers. As of October 31, 2018, our purchase commitments under such orders were $155.6 million, excluding obligations under contracts that we can cancel without a significant penalty.
  (was, 2018-06-05, similarity 0.9919):
[0001327567-18-000014:note_history:5]
Our electronics manufacturing service provider (“EMS provider”) procures components and assembles our products based on our forecasts. These forecasts are based on estimates of demand for our products primarily for the next 12 months, which are in turn based on historical trends and an analysis from our sales and product management organizations, adjusted for overall market conditions. In order to reduce manufacturing lead times and plan for adequate supply, we may issue non-cancelable orders for products and components to our manufacturing partners or component suppliers. As of April 30, 2018, our purchase commitments under such orders were $142.7 million, excluding obligations under contracts that we can cancel without a significant penalty.

- changed (2018-11-30):
[0001327567-18-000031:note_history:6]
In March 2018, we amended an agreement with a third-party provider for our use of certain cloud services through June 2020. Under the non-cancelable addendum, we are committed to a minimum purchase of $14.0 million between April 2018 and March 2019 and $8.0 million between April 2019 and March 2020. As of October 31, 2018, our purchase commitment under the addendum was $8.0 million.
  (was, 2018-06-05, similarity 0.9829):
[0001327567-18-000014:note_history:6]
In March 2018, we amended an agreement with a third-party provider for our use of certain cloud services through June 2020. Under the non-cancelable addendum, we are committed to a minimum purchase of $14.0 million between April 2018 and March 2019 and $8.0 million between April 2019 and March 2020. As of April 30, 2018, our purchase commitment under the addendum was $22.0 million.

- changed (2018-11-30):
[0001327567-18-000031:note_history:7]
To the extent there is a reasonable possibility that a loss exceeding amounts already recognized may be incurred and the amount of such additional loss would be material, we will either disclose the estimated additional loss or state that such an estimate cannot be made. As of October 31, 2018, we have not recorded any significant accruals for loss contingencies associated with such legal proceedings, determined that an unfavorable outcome is probable or reasonably possible, or determined that the amount or range of any possible loss is reasonably estimable.
  (was, 2018-06-05, similarity 0.9892):
[0001327567-18-000014:note_history:7]
To the extent there is a reasonable possibility that a loss exceeding amounts already recognized may be incurred and the amount of such additional loss would be material, we will either disclose the estimated additional loss or state that such an estimate cannot be made. As of April 30, 2018, we have not recorded any significant accruals for loss contingencies associated with such legal proceedings, determined that an unfavorable outcome is probable or reasonably possible, or determined that the amount or range of any possible loss is reasonably estimable.

- removed (2018-11-30):
[0001327567-18-000014:note_history:8]
In September 2012, we entered into two lease agreements for a total of approximately 300,000 square feet of space in Santa Clara, California, which served as our previous corporate headquarters through August 2017, when we relocated to our new corporate campus. The leases contain rent holiday periods and two separate five-year options to extend the lease terms beyond their expiration dates of July 2023. Rental payments under these lease agreements are approximately $94.3 million over the lease term. In August 2017, we exited our previous headquarter facilities and relocated to our new corporate campus, which resulted in the recognition of a cease-use loss of $15.4 million during the three months ended October 31, 2017. Due to the changes in market conditions in recent months, we recognized an additional cease-use loss of $23.8 million during the three months ended April 30, 2018, based on changes to the amount and timing of estimated cash flows from sublease rentals that could be reasonably obtained. The total cease-use loss of $39.2 million, recognized as general and administrative expense in our condensed consolidated statements of operations during the nine months ended April 30, 2018, and a corresponding liability in our condensed consolidated balance sheets, was calculated as the present value of the excess of the remaining lease obligation for the vacated facilities, adjusted for the effects of any deferred items recognized under the leases and related costs, over the estimated sublease rentals that could be reasonably obtained. The amount of the cease-use loss may vary if the timing or amount of estimated cash flows change. During the three and nine months ended April 30, 2018, we released $2.8 million and $7.4 million, respectively, of the cease-use liability through rental payments. As of April 30, 2018, the remaining balance of the cease-use liability was $31.8 million, which is expected to be paid through the end of the lease term in July 2023.


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2018-11-30):
[0001327567-18-000031:note_history:9]
Palo Alto Networks, Inc. (the “Company,” “we,” “us,” or “our”), located in Santa Clara, California, was incorporated in March 2005 under the laws of the State of Delaware and commenced operations in April 2005. We offer a security operating platform that empowers enterprises, service providers, and government entities to secure their organizations by safely enabling applications and data running in their networks, on their endpoints, and in the cloud, and by preventing breaches that stem from targeted cyberattacks.
  (was, 2018-06-05, similarity 0.9912):
[0001327567-18-000014:note_history:9]
Palo Alto Networks, Inc. (the “Company,” “we,” “us,” or “our”), located in Santa Clara, California, was incorporated in March 2005 under the laws of the State of Delaware and commenced operations in April 2005. We offer a security operating platform that empowers enterprises, service providers, and government entities to secure their organizations by safely enabling applications running in their networks, on their endpoints, and in the cloud, and by preventing breaches that stem from targeted cyberattacks.

- changed (2018-11-30):
[0001327567-18-000031:note_history:10]
Our condensed consolidated financial statements are unaudited, but include all adjustments of a normal recurring nature necessary for a fair presentation of our quarterly results. We have made estimates and judgments affecting the amounts reported in our condensed consolidated financial statements and the accompanying notes. The actual results that we experience may differ materially from our estimates.
  (was, 2018-06-05, similarity 0.8953):
[0001327567-18-000014:note_history:10]
Our condensed consolidated financial statements are unaudited, but include all adjustments of a normal recurring nature necessary for a fair presentation of our quarterly results. We have made estimates and judgments affecting the amounts reported in our condensed consolidated financial statements and the accompanying notes. The actual results that we experience may differ materially from our estimates. Certain prior-period amounts have been reclassified to conform to current-period presentation.

- added (2018-11-30):
[0001327567-18-000031:note_history:11]
Certain prior period amounts have been adjusted due to our retrospective adoption of new accounting guidance related to revenue from contracts with customers and new accounting guidance related to the presentation of restricted cash and cash equivalents in the statement of cash flows. Refer to “Recently Adopted Accounting Pronouncements” below for more information.

- added (2018-11-30):
[0001327567-18-000031:note_history:12]
There have been no material changes to our significant accounting policies as of and for the three months ended October 31, 2018, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended July 31, 2018, except for the change in our accounting policies for revenue recognition and deferred contract costs due to our adoption of new accounting guidance related to revenue from contracts with customers. Refer to “Recently Adopted Accounting Pronouncements” below, Note 2. Revenue, and Note 8. Deferred Contract Costs for more information.

- added (2018-11-30):
[0001327567-18-000031:note_history:13]
In January 2017, the Financial Accounting Standards Board (“FASB”) issued authoritative guidance clarifying the definition of a business to assist companies with evaluating whether transactions should be accounted for as acquisitions (or disposals) of assets or businesses. We adopted this standard in our first quarter of fiscal 2019 on a prospective basis. The adoption of the standard did not have an impact on our condensed consolidated financial statements.

- changed (2018-11-30):
[0001327567-18-000031:note_history:14]
In November 2016, the FASB issued authoritative guidance on the presentation of restricted cash or restricted cash equivalents in the statement of cash flows. Under the new standard, restricted cash or restricted cash equivalents should be included with cash and cash equivalents when reconciling the beginning-of-period and end-of-period total amounts shown on the statement of cash flows. We adopted this standard in our first quarter of fiscal 2019 on a retrospective basis. The adoption of the standard did not have a material impact on our condensed consolidated financial statements because our restricted cash balance has not been material.
  (was, 2018-06-05, similarity 0.8586):
[0001327567-18-000014:note_history:14]
In November 2016, the FASB issued authoritative guidance on the presentation of restricted cash or restricted cash equivalents in the statement of cash flows. Under the new standard, restricted cash or restricted cash equivalents should be included with cash and cash equivalents when reconciling the beginning-of-period and end-of-period total amounts shown on the statement of cash flows. The standard is effective for us in our first quarter of fiscal 2019 and will be applied on a retrospective basis. Early adoption is permitted. We do not expect the adoption of the standard will have a material impact on our condensed consolidated financial statements because our restricted cash balance has not been material.

- added (2018-11-30):
[0001327567-18-000031:note_history:15]
In October 2016, the FASB issued authoritative guidance requiring the recognition of income tax consequences of an intra-entity transfer of an asset, other than inventory, when the transfer occurs. We adopted the standard in our first quarter of fiscal 2019 on a modified retrospective basis. As a result, we recorded the cumulative effect of the change as an increase to accumulated deficit of $28.4 million, with a corresponding decrease to prepaid expenses and other current assets and other assets in our condensed consolidated balance sheets as of August 1, 2018, the date of adoption. The cumulative effect adjustment represents the reclassification of unrecognized income tax effects from intra-entity transfers of assets other than inventory that occurred prior to the date of adoption.

- changed (2018-11-30):
[0001327567-18-000031:note_history:16]
In August 2016, the FASB issued new authoritative guidance addressing eight specific cash flow issues with the objective of reducing the existing diversity in practice in how certain transactions are presented and classified in the statement of cash flows. We adopted this standard in our first quarter of fiscal 2019 on a retrospective basis. The adoption of the standard did not have an impact on our condensed consolidated financial statements.
  (was, 2018-06-05, similarity 0.682):
[0001327567-18-000014:note_history:16]
In August 2016, the FASB issued new authoritative guidance addressing eight specific cash flow issues with the objective of reducing the existing diversity in practice in how certain transactions are presented and classified in the statement of cash flows. The standard is effective for us in our first quarter of fiscal 2019 and will be applied on a retrospective basis. Early adoption is permitted. We do not expect the adoption of the standard will have a material impact on our condensed consolidated financial statements.

- added (2018-11-30):
[0001327567-18-000031:note_history:17]
Financial Instruments - Recognition and Measurement

- added (2018-11-30):
[0001327567-18-000031:note_history:18]
In January 2016, the FASB issued authoritative guidance requiring equity instruments to be measured at fair value with changes in fair value recognized through net income. We adopted this standard in our first quarter of fiscal 2019 on a prospective basis for non-marketable equity securities and a modified retrospective basis for marketable equity investments. The adoption of the standard did not have an impact on our condensed consolidated financial statements.

- changed (2018-11-30):
[0001327567-18-000031:note_history:19]
In May 2014, the FASB issued new authoritative guidance on revenue from contracts with customers. The new standard provides principles for recognizing revenue when control of promised goods or services is transferred to customers with the expected consideration in exchange for those goods or services, as well as guidance on the recognition of costs related to obtaining and fulfilling customer contracts. The standard also requires expanded disclosures about the nature, amount, timing, and uncertainty of revenues and cash flows arising from customer contracts, including significant judgments and changes in judgments, and assets recognized from costs incurred to obtain or fulfill a contract. We adopted the standard in our first quarter of fiscal 2019 using the full retrospective method.
  (was, 2018-06-05, similarity 0.6007):
[0001327567-18-000014:note_history:19]
In May 2014, the FASB issued new authoritative guidance on revenue from contracts with customers. The new standard provides principles for recognizing revenue for the transfer of promised goods or services to customers with the consideration to which the entity expects to be entitled in exchange for those goods or services, as well as guidance on the recognition of costs related to obtaining and fulfilling customer contracts. The standard also requires expanded disclosures about the nature, amount, timing, and uncertainty of revenues and cash flows arising from customer contracts, including significant judgments and changes in judgments, and assets recognized from costs incurred to obtain or fulfill a contract. The standard is effective for us in our first quarter of fiscal 2019 using either of two methods: (i) retrospective to each prior reporting period presented with the option to elect certain practical expedients as defined within the guidance (“full retrospective method”); or (ii) retrospective with the cumulative effect of initially applying the guidance recognized at the date of initial application and providing certain additional disclosures as defined per the guidance (“modified retrospective method”).

- added (2018-11-30):
[0001327567-18-000031:note_history:20]
The adoption of the new standard did not have a material impact on our condensed consolidated financial statements for the fiscal years ended July 31, 2018 and 2017, with the exception of the accounting for incremental costs to obtain customer contracts, which primarily consist of sales commissions, due to the longer period of amortization. Under the previous accounting guidance, we deferred and amortized these costs over the term of the related contract. Under the new standard, we defer and amortize these costs for initial contracts that are not commensurate with renewal commissions over a benefit period of five years, which is typically longer than the initial contract term.

- added (2018-11-30):
[0001327567-18-000031:note_history:21]
The adoption of the standard using the full retrospective method required us to restate the prior periods presented in this Quarterly Report on Form 10-Q, with the cumulative effect of the change of $168.2 million reflected in accumulated deficit as of August 1, 2017. In adopting the new standard, we have also applied a transition practical expedient and have not disclosed revenue expected to be recognized from remaining performance obligations for periods prior to August 1, 2018.

- added (2018-11-30):
[0001327567-18-000031:note_history:22]
The following tables present the impact of the adoption of the standard on our previously reported results (in millions, except per share data):

- added (2018-11-30):
[0001327567-18-000031:note_history:23]
|  | Three Months Ended October 31, 2017 |
|  | As Previously Reported |  | Impact of Adoption |  | As Adjusted |
| Condensed Consolidated Statements of Operations |  |  |  |  |  |
| Product revenue | $ | 186.5 |  |  | $ | (1.7 | ) |  | $ | 184.8 |  |
| Subscription and support revenue | 319.0 |  |  | (2.0 | ) |  | 317.0 |  |
| Total revenue | 505.5 |  |  | (3.7 | ) |  | 501.8 |  |
| Total cost of revenue | 141.4 |  |  | (0.1 | ) |  | 141.3 |  |
| Total operating expenses | 418.4 |  |  | (4.4 | ) |  | 414.0 |  |
| Operating loss | (54.3 | ) |  | 0.8 |  |  | (53.5 | ) |
| Net loss | (64.0 | ) |  | 0.8 |  |  | (63.2 | ) |
| Net loss per share, basic and diluted | $ | (0.70 | ) |  | $ | — |  |  | $ | (0.70 | ) |

- added (2018-11-30):
[0001327567-18-000031:note_history:24]
|  | July 31, 2018 |
|  | As Previously Reported |  | Impact of Adoption |  | As Adjusted |
| Condensed Consolidated Balance Sheet |  |  |  |  |  |
| Accounts receivable, net | $ | 467.3 |  |  | $ | (0.3 | ) |  | $ | 467.0 |  |
| Prepaid expenses and other current assets | 261.3 |  |  | 6.8 |  |  | 268.1 |  |
| Other assets | 206.8 |  |  | 119.4 |  |  | 326.2 |  |
| Accrued and other liabilities | 107.0 |  |  | 17.6 |  |  | 124.6 |  |
| Deferred revenue | 1,268.9 |  |  | (55.3 | ) |  | 1,213.6 |  |
| Long-term deferred revenue | 1,096.0 |  |  | (30.3 | ) |  | 1,065.7 |  |
| Accumulated deficit | $ | (984.6 | ) |  | $ | 193.9 |  |  | $ | (790.7 | ) |

- added (2018-11-30):
[0001327567-18-000031:note_history:25]
The adoption of the standard did not impact net cash flows from operating, investing, or financing activities in our condensed consolidated statements of cash flows.

- added (2018-11-30):
[0001327567-18-000031:note_history:26]
Implementation Costs Incurred in a Cloud Computing Arrangement

- added (2018-11-30):
[0001327567-18-000031:note_history:27]
In August 2018, the FASB issued new authoritative guidance on customer’s accounting for implementation costs incurred in a cloud computing arrangement that is a service contract, which will require customers to apply internal-use software guidance to determine the implementation costs that are able to be capitalized. Capitalized implementation costs will be required to be amortized over the term of the arrangement, beginning when the module or component of the hosting arrangement is ready for its intended use. The standard is effective for us in our first quarter of fiscal 2021 and will be applied on either a prospective or retrospective basis. Early adoption is permitted. We are currently evaluating adoption timing and whether this standard will have a material impact on our condensed consolidated financial statements.

- changed (2018-11-30):
[0001327567-18-000031:note_history:28]
In June 2016, the FASB issued new authoritative guidance on the accounting for credit losses on most financial assets and certain financial instruments. The standard replaces the existing incurred loss model with an expected credit loss model for financial assets measured at amortized cost, including trade receivables, and requires that credit losses on available-for-sale debt securities be presented as an allowance rather than as a write-down. The standard is effective for us in our first quarter of fiscal 2021 and will be applied on a modified retrospective basis. Early adoption is permitted beginning our first quarter of fiscal 2020. We are currently evaluating adoption timing and whether this standard will have a material impact on our condensed consolidated financial statements.
  (was, 2018-06-05, similarity 0.9871):
[0001327567-18-000014:note_history:28]
In June 2016, the FASB issued new authoritative guidance on the accounting for credit losses on most financial assets and certain financial instruments. The standard replaces the existing incurred loss model with an expected credit loss model for financial assets measured at amortized cost, including trade receivables, and requires that credit losses on available-for-sale debt securities be presented as an allowance rather than as a write-down. The standard is effective for us in our first quarter of fiscal 2021 and will be applied on a modified retrospective basis. Early adoption is permitted beginning our first quarter of fiscal 2020. We are currently evaluating whether this standard will have a material impact on our condensed consolidated financial statements.

- changed (2018-11-30):
[0001327567-18-000031:note_history:29]
In February 2016, the FASB issued new authoritative guidance on lease accounting. Among its provisions, the standard requires lessees to recognize right-of-use assets and lease liabilities on the balance sheet for operating leases and also requires additional qualitative and quantitative disclosures about lease arrangements. The standard is effective for us in our first quarter of fiscal 2020 and will be applied on a modified retrospective basis, with the option to elect certain practical expedients. Early adoption is permitted; however, we plan to adopt the new standard in our first quarter of fiscal 2020. Upon adoption, we will recognize right-of-use assets and operating lease liabilities on our condensed consolidated balance sheets, which will increase our total assets and total liabilities. We are currently evaluating the accounting, transition, and disclosure requirements of this standard, including its impact on our accounting policies and processes.
  (was, 2018-06-05, similarity 0.6597):
[0001327567-18-000014:note_history:29]
In February 2016, the FASB issued new authoritative guidance on lease accounting. Among its provisions, the standard requires lessees to recognize right-of-use assets and lease liabilities on the balance sheet for operating leases and also requires additional qualitative and quantitative disclosures about lease arrangements. The standard is effective for us in our first quarter of fiscal 2020 and will be applied on a modified retrospective basis, with the option to elect certain practical expedients. Early adoption is permitted. We are currently evaluating whether this standard will have a material impact on our condensed consolidated financial statements.

- removed (2018-11-30):
[0001327567-18-000014:note_history:30]
There have been no material changes to our significant accounting policies as of and for the nine months ended April 30, 2018, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended July 31, 2017.

- removed (2018-11-30):
[0001327567-18-000014:note_history:31]
Derivatives and Hedging

- removed (2018-11-30):
[0001327567-18-000014:note_history:32]
In August 2017, the Financial Accounting Standards Board (“FASB”) issued new authoritative guidance on derivatives and hedging to better align an entity’s risk management activities and financial reporting for hedging relationships through changes to both the designation and measurement guidance for qualifying hedging relationships, and the presentation of hedge results. We early adopted the standard in our second quarter of fiscal 2018 on a modified retrospective basis. The adoption of this standard did not have a material impact on our condensed consolidated financial statements.

- removed (2018-11-30):
[0001327567-18-000014:note_history:33]
In January 2017, the FASB issued authoritative guidance clarifying the definition of a business to assist companies with evaluating whether transactions should be accounted for as acquisitions (or disposals) of assets or businesses. The standard is effective for us in our first quarter of fiscal 2019 and will be applied on a prospective basis. Early adoption is permitted. We do not expect the adoption of the standard will have a material impact on our condensed consolidated financial statements.

- removed (2018-11-30):
[0001327567-18-000014:note_history:34]
In October 2016, the FASB issued authoritative guidance requiring the recognition of income tax consequences of an intra-entity transfer of an asset, other than inventory, when the transfer occurs. The standard is effective for us in our first quarter of fiscal 2019 and will be applied on a modified retrospective basis through a cumulative-effect adjustment to accumulated deficit as of the date of adoption. Early adoption is permitted. We plan to adopt the standard in our first quarter of fiscal 2019. The adoption of this standard may have a material impact on our condensed consolidated financial statements, subject to any potential intra-entity transfers of assets (excluding inventory) and additional guidance and interpretations issued by U.S. regulatory and standard-setting bodies related to the Tax Cuts and Jobs Act (“TCJA”) enacted into law on December 22, 2017. Refer to Note 11. Income Taxes for more information on the TCJA.

- removed (2018-11-30):
[0001327567-18-000014:note_history:35]
We will adopt the standard in our first quarter of fiscal 2019 using the full retrospective method and are on schedule with the preparation of our relevant prior-period financial statements.

- removed (2018-11-30):
[0001327567-18-000014:note_history:36]
We are continuing to evaluate the impact of the new standard on our accounting policies, processes, internal controls over financial reporting, and system requirements, and have assigned cross-functional internal resources and engaged third-party service providers to assist in our evaluation and system implementation. Furthermore, we have made and will continue to make investments in systems to enable timely and accurate reporting under the new standard.

- removed (2018-11-30):
[0001327567-18-000014:note_history:37]
We are also continuing to evaluate the impact the standard will have on our condensed consolidated financial statements and disclosures, including reviewing the provisions of our customer contracts and identifying performance obligations under the requirements of the new standard, and comparing to our current accounting policies and practices. Although we have not yet determined whether the effect will be material, we believe the new standard will impact our accounting for revenue arrangements in the following areas:

- removed (2018-11-30):
[0001327567-18-000014:note_history:38]
| • | removal of the current limitation on contingent revenue may result in revenue being recognized earlier for certain contracts; |

- removed (2018-11-30):
[0001327567-18-000014:note_history:39]
| • | term license revenue associated with our virtual firewalls will be recognized upfront; |

- removed (2018-11-30):
[0001327567-18-000014:note_history:40]
| • | allocation of revenue related to software due to the removal of the residual method of revenue recognition; and |

- removed (2018-11-30):
[0001327567-18-000014:note_history:41]
| • | amortization period for incremental costs to obtain or fulfill customer contracts. |

- removed (2018-11-30):
[0001327567-18-000014:note_history:42]
The exact impact of the new standard will be dependent on facts and circumstances at adoption and could vary from quarter to quarter.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2018-11-30):
[0001327567-18-000031:note_history:43]
Palo Alto Networks, Inc. (the “Company,” “we,” “us,” or “our”), located in Santa Clara, California, was incorporated in March 2005 under the laws of the State of Delaware and commenced operations in April 2005. We offer a security operating platform that empowers enterprises, service providers, and government entities to secure their organizations by safely enabling applications and data running in their networks, on their endpoints, and in the cloud, and by preventing breaches that stem from targeted cyberattacks.
  (was, 2018-06-05, similarity 0.9912):
[0001327567-18-000014:note_history:43]
Palo Alto Networks, Inc. (the “Company,” “we,” “us,” or “our”), located in Santa Clara, California, was incorporated in March 2005 under the laws of the State of Delaware and commenced operations in April 2005. We offer a security operating platform that empowers enterprises, service providers, and government entities to secure their organizations by safely enabling applications running in their networks, on their endpoints, and in the cloud, and by preventing breaches that stem from targeted cyberattacks.

- changed (2018-11-30):
[0001327567-18-000031:note_history:44]
Our condensed consolidated financial statements are unaudited, but include all adjustments of a normal recurring nature necessary for a fair presentation of our quarterly results. We have made estimates and judgments affecting the amounts reported in our condensed consolidated financial statements and the accompanying notes. The actual results that we experience may differ materially from our estimates.
  (was, 2018-06-05, similarity 0.8953):
[0001327567-18-000014:note_history:44]
Our condensed consolidated financial statements are unaudited, but include all adjustments of a normal recurring nature necessary for a fair presentation of our quarterly results. We have made estimates and judgments affecting the amounts reported in our condensed consolidated financial statements and the accompanying notes. The actual results that we experience may differ materially from our estimates. Certain prior-period amounts have been reclassified to conform to current-period presentation.

- added (2018-11-30):
[0001327567-18-000031:note_history:45]
Certain prior period amounts have been adjusted due to our retrospective adoption of new accounting guidance related to revenue from contracts with customers and new accounting guidance related to the presentation of restricted cash and cash equivalents in the statement of cash flows. Refer to “Recently Adopted Accounting Pronouncements” below for more information.

- added (2018-11-30):
[0001327567-18-000031:note_history:46]
There have been no material changes to our significant accounting policies as of and for the three months ended October 31, 2018, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended July 31, 2018, except for the change in our accounting policies for revenue recognition and deferred contract costs due to our adoption of new accounting guidance related to revenue from contracts with customers. Refer to “Recently Adopted Accounting Pronouncements” below, Note 2. Revenue, and Note 8. Deferred Contract Costs for more information.

- removed (2018-11-30):
[0001327567-18-000014:note_history:47]
There have been no material changes to our significant accounting policies as of and for the nine months ended April 30, 2018, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended July 31, 2017.


## panw:ConvertibleDebtOtherDetailsTableTextBlock (debt) — matched_by: no_prior_note, score: 0.0

- added (2018-11-30):
[0001327567-18-000031:note_history:48]
The following table presents details of the Notes (number of shares in millions):

- added (2018-11-30):
[0001327567-18-000031:note_history:49]
|  | Conversion Rate per $1,000 Principal |  | Initial Conversion Price |  | Convertible Date |  | Initial Number of Shares |
| 2019 Notes | 9.0680 |  |  | $ | 110.28 |  |  | January 1, 2019 |  | 5.2 |  |
| 2023 Notes | 3.7545 |  |  | $ | 266.35 |  |  | April 1, 2023 |  | 6.4 |  |


## panw:DebtSecuritiesAvailableforsaleTableTextBlock (debt) — matched_by: no_prior_note, score: 0.0

- added (2018-11-30):
[0001327567-18-000031:note_history:50]
The following tables summarize the amortized cost, unrealized gains and losses, and fair value of our available-for-sale securities as of October 31, 2018 and July 31, 2018 (in millions):

- added (2018-11-30):
[0001327567-18-000031:note_history:51]
|  | October 31, 2018 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | $ | 5.0 |  |  | $ | — |  |  | $ | — |  |  | $ | 5.0 |  |
| Corporate debt securities | 2.5 |  |  | — |  |  | — |  |  | 2.5 |  |
| U.S. government and agency securities | 210.3 |  |  | — |  |  | — |  |  | 210.3 |  |
| Total available-for-sale cash equivalents | $ | 217.8 |  |  | $ | — |  |  | $ | — |  |  | $ | 217.8 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 5.4 |  |  | $ | — |  |  | $ | — |  |  | $ | 5.4 |  |
| Non-U.S. government securities | 20.0 |  |  | — |  |  | — |  |  | 20.0 |  |
| Commercial paper | 97.3 |  |  | — |  |  | — |  |  | 97.3 |  |
| Corporate debt securities | 382.5 |  |  | — |  |  | (2.4 | ) |  | 380.1 |  |
| U.S. government and agency securities | 1,489.0 |  |  | — |  |  | (6.9 | ) |  | 1,482.1 |  |
| Total available-for-sale investments | $ | 1,994.2 |  |  | $ | — |  |  | $ | (9.3 | ) |  | $ | 1,984.9 |  |

- added (2018-11-30):
[0001327567-18-000031:note_history:52]
|  | July 31, 2018 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | $ | 52.0 |  |  | $ | — |  |  | $ | — |  |  | $ | 52.0 |  |
| U.S. government and agency securities | 397.3 |  |  | — |  |  | — |  |  | 397.3 |  |
| Total available-for-sale cash equivalents | $ | 449.3 |  |  | $ | — |  |  | $ | — |  |  | $ | 449.3 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 5.4 |  |  | $ | — |  |  | $ | — |  |  | $ | 5.4 |  |
| Non-U.S. government securities | 20.0 |  |  | — |  |  | — |  |  | 20.0 |  |
| Commercial paper | 22.3 |  |  | — |  |  | — |  |  | 22.3 |  |
| Corporate debt securities | 295.9 |  |  | — |  |  | (2.5 | ) |  | 293.4 |  |
| U.S. government and agency securities | 1,110.6 |  |  | — |  |  | (7.7 | ) |  | 1,102.9 |  |
| Total available-for-sale investments | $ | 1,454.2 |  |  | $ | — |  |  | $ | (10.2 | ) |  | $ | 1,444.0 |  |


## us-gaap:ConvertibleDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-11-30):
[0001327567-18-000031:note_history:53]
The following table sets forth the components of the Notes as of October 31, 2018 and July 31, 2018 (in millions):
  (was, 2018-06-05, similarity 0.9515):
[0001327567-18-000014:note_history:53]
The following table sets forth the components of the Notes as of April 30, 2018 and July 31, 2017 (in millions):

- added (2018-11-30):
[0001327567-18-000031:note_history:54]
|  | October 31, 2018 |  | July 31, 2018 |
|  | 2019 Notes |  | 2023 Notes |  | Total |  | 2019 Notes |  | 2023 Notes |  | Total |
| Liability component: |  |  |  |  |  |  |  |  |  |  |  |
| Principal | $ | 247.7 |  |  | $ | 1,693.0 |  |  | $ | 1,940.7 |  |  | $ | 575.0 |  |  | $ | 1,693.0 |  |  | $ | 2,268.0 |  |
| Less: debt discount and debt issuance costs, net of amortization | 7.8 |  |  | 308.5 |  |  | 316.3 |  |  | 24.6 |  |  | 323.3 |  |  | 347.9 |  |
| Net carrying amount | $ | 239.9 |  |  | $ | 1,384.5 |  |  | $ | 1,624.4 |  |  | $ | 550.4 |  |  | $ | 1,369.7 |  |  | $ | 1,920.1 |  |
| Equity component (including amounts classified as temporary equity) | $ | 47.3 |  |  | $ | 315.0 |  |  | $ | 362.3 |  |  | $ | 109.8 |  |  | $ | 315.0 |  |  | $ | 424.8 |  |

- removed (2018-11-30):
[0001327567-18-000014:note_history:55]
|  | April 30, 2018 |  | July 31, 2017 |
| Liability: |  |  |  |
| Principal | $ | 575.0 |  |  | $ | 575.0 |  |
| Less: debt discount and debt issuance costs, net of amortization | 31.2 |  |  | 50.3 |  |
| Net carrying amount | $ | 543.8 |  |  | $ | 524.7 |  |
| Equity (including temporary equity) | $ | 109.8 |  |  | $ | 109.8 |  |


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2018-11-30):
[0001327567-18-000031:note_history:56]
Debt

- added (2018-11-30):
[0001327567-18-000031:note_history:57]
In June 2014, we issued $575.0 million aggregate principal amount of 0.0% Convertible Senior Notes due 2019 (the “2019 Notes”) and in July 2018, we issued $1.7 billion aggregate principal amount of 0.75% Convertible Senior Notes due 2023 (the “2023 Notes” and, together with the 2019 Notes, the “Notes”). The 2023 Notes bear interest at a fixed rate of 0.75% per year, payable semi-annually in arrears on January 1 and July 1 of each year, beginning on January 1, 2019. Each series of Notes is governed by an indenture between us, as the issuer, and U.S. Bank National Association, as Trustee (individually, each an “Indenture,” and together, the “Indentures”). The Notes of each series are unsecured, unsubordinated obligations and the applicable Indenture governing each series of Notes does not contain any financial covenants or restrictions on the payments of dividends, the incurrence of indebtedness, or the issuance or repurchase of securities by us or any of our subsidiaries. The 2019 Notes and 2023 Notes mature on July 1, 2019 and July 1, 2023, respectively. We cannot redeem either series of Notes prior to the applicable maturity date.

- changed (2018-11-30):
[0001327567-18-000031:note_history:58]
The following table presents details of the Notes (number of shares in millions):
  (was, 2018-06-05, similarity 0.6448):
[0001327567-18-000014:note_history:58]
The following table sets forth the components of the Notes as of April 30, 2018 and July 31, 2017 (in millions):

- added (2018-11-30):
[0001327567-18-000031:note_history:59]
|  | Conversion Rate per $1,000 Principal |  | Initial Conversion Price |  | Convertible Date |  | Initial Number of Shares |
| 2019 Notes | 9.0680 |  |  | $ | 110.28 |  |  | January 1, 2019 |  | 5.2 |  |
| 2023 Notes | 3.7545 |  |  | $ | 266.35 |  |  | April 1, 2023 |  | 6.4 |  |

- added (2018-11-30):
[0001327567-18-000031:note_history:60]
Holders of the Notes may surrender their Notes for conversion at their option at any time prior to the close of business on the business day immediately preceding their respective convertible dates only under the following circumstances:

- changed (2018-11-30):
[0001327567-18-000031:note_history:61]
| • | during any fiscal quarter commencing after the fiscal quarters ending on October 31, 2014 and October 31, 2018, for the 2019 Notes and 2023 Notes, respectively (and only during such fiscal quarter), if the last reported sale price of our common stock for at least 20 trading days (whether or not consecutive) during a period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the applicable conversion price for the respective Notes on each applicable trading day (the “sale price condition”); |
  (was, 2018-06-05, similarity 0.9237):
[0001327567-18-000014:note_history:61]
| • | during any fiscal quarter commencing after the fiscal quarter ending on October 31, 2014 (and only during such fiscal quarter), if the last reported sale price of our common stock for at least 20 trading days (whether or not consecutive) during a period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the conversion price for the Notes on each applicable trading day (the “sale price condition”); |

- changed (2018-11-30):
[0001327567-18-000031:note_history:62]
| • | during the five business day period after any five consecutive trading day period (the “measurement period”) in which the trading price per $1,000 principal amount of the applicable series of Notes for each trading day of the measurement period was less than 98% of the product of the last reported sale price of our common stock and the applicable conversion rate for the respective Notes on each such trading day; or |
  (was, 2018-06-05, similarity 0.9025):
[0001327567-18-000014:note_history:62]
| • | during the five business day period after any five consecutive trading day period, in which the trading price per $1,000 principal amount of Notes for each trading day of the measurement period was less than 98% of the product of the last reported sale price of our common stock and the conversion rate for the Notes on each such trading day; or |

- added (2018-11-30):
[0001327567-18-000031:note_history:63]
On or after the respective convertible date, holders may convert all or any portion of their Notes at any time prior to the close of business on the second scheduled trading day immediately preceding the applicable maturity date regardless of the foregoing conditions. Upon conversion, holders of the Notes of a series will receive cash equal to the aggregate principal amount of the Notes of such series to be converted, and, at our election, cash and/or shares of our common stock for any amounts in excess of the aggregate principal amount of the Notes of such series being converted.

- added (2018-11-30):
[0001327567-18-000031:note_history:64]
The conversion price will be subject to adjustment in some events. Holders of the Notes of a series who convert their Notes of such series in connection with certain corporate events that constitute a “make-whole fundamental change” under the applicable Indenture are, under certain circumstances, entitled to an increase in the conversion rate for such series of Notes. Additionally, upon the occurrence of a corporate event that constitutes a “fundamental change” under the applicable Indenture, holders of the Notes of such series may require us to repurchase for cash all or a portion of the Notes of such series at a repurchase price equal to 100% of the principal amount of the Notes of such series plus accrued and unpaid interest to, but excluding, the fundamental change repurchase date.

- added (2018-11-30):
[0001327567-18-000031:note_history:65]
The sale price condition was met for the 2019 Notes during the fiscal quarter ended July 31, 2018, and, as a result, holders were able to convert their 2019 Notes at any time during the fiscal quarter ended October 31, 2018. During the three months ended October 31, 2018, holders converted $327.3 million in aggregate principal amount of the 2019 Notes, which we repaid in cash. We also issued 1.4 million shares of our common stock to the holders for the conversion value in excess of the principal amount. These shares were fully offset by shares received from the corresponding exercise of the associated note hedges. We allocated $317.1 million of the cash consideration to the liability component of the converted 2019 Notes, which was calculated by measuring the fair value of a similar liability that did not have an associated convertible feature. We recorded a loss of $2.2 million related to the settlement of the 2019 Notes converted, which represented the difference between the cash consideration allocated to the liability component and the net carrying amount of the liability component on the respective settlement dates. The loss was included in other income, net in our condensed consolidated statement of operations for the three months ended October 31, 2018. During the three months ended October 31, 2018, we also recorded a $10.2 million net reduction to additional paid-in capital in our condensed consolidated balance sheets, reflecting the portion of the cash consideration allocated to the equity component.

- added (2018-11-30):
[0001327567-18-000031:note_history:66]
The sale price condition continued to be met through the fiscal quarter ended October 31, 2018, and, as a result, holders may convert their 2019 Notes at any time prior to January 1, 2019 (the “2019 Notes Convertible Date”). On or after the 2019 Notes Convertible Date, holders may convert their 2019 Notes at any time prior to maturity, in accordance with the terms described above, regardless of the sale price condition. Accordingly, the net carrying amount of the 2019 Notes was classified as a current liability and the portion of the equity component representing the conversion option was classified as temporary equity in our condensed consolidated balance sheets as of October 31, 2018.

- added (2018-11-30):
[0001327567-18-000031:note_history:67]
The sale price condition was not met for the 2023 Notes during the fiscal quarters ended October 31, 2018 and July 31, 2018. Since the 2023 Notes were not convertible, the net carrying amount of the 2023 Notes was classified as a long-term liability and the equity component was included in additional paid-in capital in our condensed consolidated balance sheets as of October 31, 2018.

- added (2018-11-30):
[0001327567-18-000031:note_history:68]
As of October 31, 2018, $247.7 million in aggregate principal amount of the 2019 Notes remained outstanding and all of the 2023 Notes remained outstanding. Subsequent to October 31, 2018, through the filing date of this Quarterly Report on Form 10-Q, $88.3 million in principal amount of the 2019 Notes was converted or had been submitted by the holders for conversion and will settle during the fiscal quarter ending January 31, 2019.

- added (2018-11-30):
[0001327567-18-000031:note_history:69]
The following table sets forth the components of the Notes as of October 31, 2018 and July 31, 2018 (in millions):

- added (2018-11-30):
[0001327567-18-000031:note_history:70]
|  | October 31, 2018 |  | July 31, 2018 |
|  | 2019 Notes |  | 2023 Notes |  | Total |  | 2019 Notes |  | 2023 Notes |  | Total |
| Liability component: |  |  |  |  |  |  |  |  |  |  |  |
| Principal | $ | 247.7 |  |  | $ | 1,693.0 |  |  | $ | 1,940.7 |  |  | $ | 575.0 |  |  | $ | 1,693.0 |  |  | $ | 2,268.0 |  |
| Less: debt discount and debt issuance costs, net of amortization | 7.8 |  |  | 308.5 |  |  | 316.3 |  |  | 24.6 |  |  | 323.3 |  |  | 347.9 |  |
| Net carrying amount | $ | 239.9 |  |  | $ | 1,384.5 |  |  | $ | 1,624.4 |  |  | $ | 550.4 |  |  | $ | 1,369.7 |  |  | $ | 1,920.1 |  |
| Equity component (including amounts classified as temporary equity) | $ | 47.3 |  |  | $ | 315.0 |  |  | $ | 362.3 |  |  | $ | 109.8 |  |  | $ | 315.0 |  |  | $ | 424.8 |  |

- added (2018-11-30):
[0001327567-18-000031:note_history:71]
The total estimated fair value of the Notes was $2.1 billion and $2.7 billion at October 31, 2018 and July 31, 2018, respectively. The fair value was determined based on the closing trading price per $100 of the Notes as of the last day of trading for the period. We consider the fair value of the Notes at October 31, 2018 and July 31, 2018 to be a Level 2 measurement. The fair value of the Notes is primarily affected by the trading price of our common stock and market interest rates. As of October 31, 2018, the if-converted value of the 2019 Notes exceeded its principal amount by $220.2 million. Based on the closing price of our common stock on October 31, 2018, the if-converted value of the 2023 Notes was less than its principal amount.

- added (2018-11-30):
[0001327567-18-000031:note_history:72]
|  | Three Months Ended |  | Three Months Ended |
|  | October 31, 2018 |  | October 31, 2017 |
|  | 2019 Notes |  | 2023 Notes |  | Total |  | 2019 Notes |  | 2023 Notes |  | Total |
| Contractual interest expense | $ | — |  |  | $ | 3.2 |  |  | $ | 3.2 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Amortization of debt discount | 4.0 |  |  | 14.4 |  |  | 18.4 |  |  | 5.6 |  |  | — |  |  | 5.6 |  |
| Amortization of debt issuance costs | 0.5 |  |  | 0.5 |  |  | 1.0 |  |  | 0.7 |  |  | — |  |  | 0.7 |  |
| Total interest expense recognized | $ | 4.5 |  |  | $ | 18.1 |  |  | $ | 22.6 |  |  | $ | 6.3 |  |  | $ | — |  |  | $ | 6.3 |  |
| Effective interest rate of the liability component | 4.8 | % |  | 5.2 | % |  |  |  | 4.8 | % |  | — | % |  |  |

- added (2018-11-30):
[0001327567-18-000031:note_history:73]
To minimize the impact of potential economic dilution upon conversion of the Notes, we entered into separate convertible note hedge transactions (the “2019 Note Hedges,” with respect to the 2019 Notes, and the “2023 Note Hedges,” with respect to the 2023 Notes, and collectively, the “Note Hedges”) with respect to our common stock concurrent with the issuance of each series of Notes.

- added (2018-11-30):
[0001327567-18-000031:note_history:74]
The following table presents details of the Note Hedges (in millions):

- added (2018-11-30):
[0001327567-18-000031:note_history:75]
|  | Initial Number of Shares |  | Aggregate Purchase |
| 2019 Note Hedges | 5.2 |  |  | $ | 111.0 |  |
| 2023 Note Hedges | 6.4 |  |  | $ | 332.0 |  |

- added (2018-11-30):
[0001327567-18-000031:note_history:76]
The Note Hedges cover shares of our common stock at a strike price per share that corresponds to the initial applicable conversion price of the applicable series of Notes, which are also subject to adjustment, and are exercisable upon conversion of the applicable series of Notes. The Note Hedges will expire upon maturity of the applicable series of Notes. The Note Hedges are separate transactions and are not part of the terms of the applicable series of the Notes. Holders of the Notes of either series will not have any rights with respect to the Note Hedges. Any shares of our common stock receivable by us under the Note Hedges are excluded from the calculation of diluted earnings per share as they are antidilutive. The aggregate amounts paid for the Note Hedges are included in additional paid-in capital in our consolidated balance sheets.

- added (2018-11-30):
[0001327567-18-000031:note_history:77]
As a result of the conversions of the 2019 Notes settled during the fiscal quarter ended October 31, 2018, we exercised the corresponding portion of our 2019 Note Hedges and received 1.4 million shares of common stock during the period.

- added (2018-11-30):
[0001327567-18-000031:note_history:78]
Separately, but concurrently with the issuance of each series of Notes, we entered into transactions whereby we sold warrants (the “2019 Warrants,” with respect to the 2019 Notes, and the “2023 Warrants,” with respect to the 2023 Notes, and collectively, the “Warrants”) to acquire shares of our common stock, subject to anti-dilution adjustments. The 2019 Warrants and 2023 Warrants are exercisable beginning October 2019 and October 2023, respectively.

- added (2018-11-30):
[0001327567-18-000031:note_history:79]
The following table presents details of the Warrants (in millions, except per share data):

- added (2018-11-30):
[0001327567-18-000031:note_history:80]
|  | Initial Number of Shares |  | Strike Price per Share |  | Aggregate Proceeds |
| 2019 Warrants | 5.2 |  |  | $ | 137.85 |  |  | $ | 78.3 |  |
| 2023 Warrants | 6.4 |  |  | $ | 417.80 |  |  | $ | 145.4 |  |

- added (2018-11-30):
[0001327567-18-000031:note_history:81]
The shares issuable under the Warrants will be included in the calculation of diluted earnings per share when the average market value per share of our common stock for the reporting period exceeds the applicable strike price for such series of Warrants. The Warrants are separate transactions and are not part of either series of Notes or Note Hedges and are not remeasured through earnings each reporting period. Holders of the Notes of either series will not have any rights with respect to the Warrants. The aggregate proceeds received from the sale of the Warrants are included in additional paid-in capital in our consolidated balance sheets.

- added (2018-11-30):
[0001327567-18-000031:note_history:82]
Revolving Credit Facility

- added (2018-11-30):
[0001327567-18-000031:note_history:83]
On September 4, 2018, we entered into a credit agreement (the “Credit Agreement”) with certain institutional lenders that provides for a $400.0 million unsecured revolving credit facility (the “Credit Facility”), with an option to increase the amount of the Credit Facility by up to an additional $350.0 million, subject to certain conditions. The Credit Facility matures on the earlier of (i) September 4, 2023 and (ii) the date that is 91 days prior to the stated maturity of our 2023 Notes if (a) any of the 2023 Notes are still outstanding and (b) our unrestricted cash and cash equivalents are less than the then outstanding principal amount of our 2023 Notes plus $400.0 million.

- added (2018-11-30):
[0001327567-18-000031:note_history:84]
The borrowings under the Credit Facility bear interest, at our option, at a base rate plus a spread of 0.00% to 0.75%, or an adjusted LIBO rate plus a spread of 1.00% to 1.75%, in each case with such spread being determined based on our leverage ratio. We are obligated to pay an ongoing commitment fee on undrawn amounts at a rate of 0.125% to 0.250%, depending on our leverage ratio. As of October 31, 2018, there were no amounts outstanding and we were in compliance with all covenants under the Credit Agreement.

- removed (2018-11-30):
[0001327567-18-000014:note_history:85]
Convertible Senior Notes

- removed (2018-11-30):
[0001327567-18-000014:note_history:86]
On June 30, 2014, we issued $575.0 million aggregate principal amount of 0.0% Convertible Senior Notes due 2019 (the “Notes”). The Notes mature on July 1, 2019 unless converted or repurchased in accordance with their terms prior to such date. The Notes do not contain any financial covenants and we cannot redeem the Notes prior to maturity.

- removed (2018-11-30):
[0001327567-18-000014:note_history:87]
The Notes are convertible for up to 5.2 million shares of our common stock at an initial conversion price of approximately $110.28 per share of common stock, subject to adjustment. Holders of the Notes may surrender their Notes for conversion at their option at any time prior to the close of business on the business day immediately preceding January 1, 2019, only under the following circumstances:

- removed (2018-11-30):
[0001327567-18-000014:note_history:88]
On or after January 1, 2019, holders may convert all or any portion of their Notes at any time prior to the close of business on the second scheduled trading day immediately preceding the maturity date regardless of the foregoing conditions. Upon conversion, holders will receive cash equal to the aggregate principal amount of the Notes to be converted, and, at our election, cash and/or shares of our common stock for any amounts in excess of the aggregate principal amount of the Notes being converted. As of April 30, 2018, all of the Notes remained outstanding.

- removed (2018-11-30):
[0001327567-18-000014:note_history:89]
The sale price condition was met during the fiscal quarter ended April 30, 2018, and as a result, holders may convert their Notes at any time during the fiscal quarter ending July 31, 2018. Accordingly, the net carrying amount of the Notes was reclassified into current liabilities and the portion of the equity component representing the conversion option was reclassified into temporary equity in our condensed consolidated balance sheets as of April 30, 2018. The portion of the equity component classified as temporary equity is measured as the difference between the principal and net carrying amount of the Notes, excluding debt issuance costs. The sale price condition was not met during the fiscal quarter ended July 31, 2017. Since the Notes were not convertible, the net carrying amount of the Notes was classified as a long-term liability and the equity component was included in additional paid-in capital in our condensed consolidated balance sheets as of July 31, 2017.

- removed (2018-11-30):
[0001327567-18-000014:note_history:90]
|  | April 30, 2018 |  | July 31, 2017 |
| Liability: |  |  |  |
| Principal | $ | 575.0 |  |  | $ | 575.0 |  |
| Less: debt discount and debt issuance costs, net of amortization | 31.2 |  |  | 50.3 |  |
| Net carrying amount | $ | 543.8 |  |  | $ | 524.7 |  |
| Equity (including temporary equity) | $ | 109.8 |  |  | $ | 109.8 |  |

- removed (2018-11-30):
[0001327567-18-000014:note_history:91]
The total estimated fair value of the Notes was $1.0 billion and $747.5 million at April 30, 2018 and July 31, 2017, respectively. The fair value was determined based on the closing trading price per $100 of the Notes as of the last day of trading for the period. We consider the fair value of the Notes at April 30, 2018 and July 31, 2017 to be a Level 2 measurement. The fair value of the Notes is primarily affected by the trading price of our common stock and market interest rates. As of April 30, 2018, the if-converted value of the Notes exceeded its principal amount by $406.8 million.

- removed (2018-11-30):
[0001327567-18-000014:note_history:92]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 30, |  | April 30, |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Amortization of debt discount | $ | 5.7 |  |  | $ | 5.5 |  |  | $ | 17.1 |  |  | $ | 16.4 |  |
| Amortization of debt issuance costs | 0.8 |  |  | 0.7 |  |  | 2.1 |  |  | 1.9 |  |
| Total interest expense recognized | $ | 6.5 |  |  | $ | 6.2 |  |  | $ | 19.2 |  |  | $ | 18.3 |  |
| Effective interest rate of the liability component | 4.8 | % |  | 4.8 | % |  | 4.8 | % |  | 4.8 | % |

- removed (2018-11-30):
[0001327567-18-000014:note_history:93]
To minimize the impact of potential economic dilution upon conversion of the Notes, we entered into convertible note hedge transactions (the “Note Hedges”) with respect to our common stock concurrent with the issuance of the Notes. The Note Hedges cover up to 5.2 million shares of our common stock at a strike price per share that corresponds to the initial conversion price of the Notes, which are also subject to adjustment, and are exercisable upon conversion of the Notes. The Note Hedges will expire upon maturity of the Notes. The Note Hedges are separate transactions and are not part of the terms of the Notes. Holders of the Notes will not have any rights with respect to the Note Hedges. The shares receivable related to the Note Hedges are excluded from the calculation of diluted earnings per share as they are antidilutive.

- removed (2018-11-30):
[0001327567-18-000014:note_history:94]
Separately, but concurrently with our issuance of the Notes, we entered into transactions whereby we sold warrants (the “Warrants”) to acquire up to 5.2 million shares of our common stock at a strike price of approximately $137.85 per share, subject to adjustments. The shares issuable under the Warrants will be included in the calculation of diluted earnings per share when the average market value per share of our common stock for the reporting period exceeds the strike price of the Warrants. The Warrants are separate transactions and are not part of the Notes or Note Hedges, and are not remeasured through earnings each reporting period. Holders of the Notes and Note Hedges will not have any rights with respect to the Warrants.

- removed (2018-11-30):
[0001327567-18-000014:note_history:95]
For more information on the Notes, the Note Hedges, and the Warrants, refer to Note 8. Convertible Senior Notes included in Part II, Item 8 of our Annual Report on Form 10-K for the fiscal year ended July 31, 2017.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2018-11-30):
[0001327567-18-000031:note_history:96]
Available-for-sale Securities

- changed (2018-11-30):
[0001327567-18-000031:note_history:97]
The following tables summarize the amortized cost, unrealized gains and losses, and fair value of our available-for-sale securities as of October 31, 2018 and July 31, 2018 (in millions):
  (was, 2018-06-05, similarity 0.9716):
[0001327567-18-000014:note_history:97]
The following tables summarize the amortized cost, unrealized gains and losses, and fair value of our available-for-sale securities as of April 30, 2018 and July 31, 2017 (in millions):

- added (2018-11-30):
[0001327567-18-000031:note_history:98]
|  | October 31, 2018 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | $ | 5.0 |  |  | $ | — |  |  | $ | — |  |  | $ | 5.0 |  |
| Corporate debt securities | 2.5 |  |  | — |  |  | — |  |  | 2.5 |  |
| U.S. government and agency securities | 210.3 |  |  | — |  |  | — |  |  | 210.3 |  |
| Total available-for-sale cash equivalents | $ | 217.8 |  |  | $ | — |  |  | $ | — |  |  | $ | 217.8 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 5.4 |  |  | $ | — |  |  | $ | — |  |  | $ | 5.4 |  |
| Non-U.S. government securities | 20.0 |  |  | — |  |  | — |  |  | 20.0 |  |
| Commercial paper | 97.3 |  |  | — |  |  | — |  |  | 97.3 |  |
| Corporate debt securities | 382.5 |  |  | — |  |  | (2.4 | ) |  | 380.1 |  |
| U.S. government and agency securities | 1,489.0 |  |  | — |  |  | (6.9 | ) |  | 1,482.1 |  |
| Total available-for-sale investments | $ | 1,994.2 |  |  | $ | — |  |  | $ | (9.3 | ) |  | $ | 1,984.9 |  |

- added (2018-11-30):
[0001327567-18-000031:note_history:99]
|  | July 31, 2018 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | $ | 52.0 |  |  | $ | — |  |  | $ | — |  |  | $ | 52.0 |  |
| U.S. government and agency securities | 397.3 |  |  | — |  |  | — |  |  | 397.3 |  |
| Total available-for-sale cash equivalents | $ | 449.3 |  |  | $ | — |  |  | $ | — |  |  | $ | 449.3 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 5.4 |  |  | $ | — |  |  | $ | — |  |  | $ | 5.4 |  |
| Non-U.S. government securities | 20.0 |  |  | — |  |  | — |  |  | 20.0 |  |
| Commercial paper | 22.3 |  |  | — |  |  | — |  |  | 22.3 |  |
| Corporate debt securities | 295.9 |  |  | — |  |  | (2.5 | ) |  | 293.4 |  |
| U.S. government and agency securities | 1,110.6 |  |  | — |  |  | (7.7 | ) |  | 1,102.9 |  |
| Total available-for-sale investments | $ | 1,454.2 |  |  | $ | — |  |  | $ | (10.2 | ) |  | $ | 1,444.0 |  |

- changed (2018-11-30):
[0001327567-18-000031:note_history:100]
Unrealized losses related to these securities are due to interest rate fluctuations as opposed to credit quality. In addition, we do not intend to sell and it is not likely that we would be required to sell these securities before recovery of their amortized cost basis, which may be at maturity. As a result, there were no other-than-temporary impairments for these securities at October 31, 2018 and July 31, 2018.
  (was, 2018-06-05, similarity 0.9851):
[0001327567-18-000014:note_history:100]
Unrealized losses related to these securities are due to interest rate fluctuations as opposed to credit quality. In addition, we do not intend to sell and it is not likely that we would be required to sell these securities before recovery of their amortized cost basis, which may be at maturity. As a result, there were no other-than-temporary impairments for these securities at April 30, 2018 and July 31, 2017.

- changed (2018-11-30):
[0001327567-18-000031:note_history:101]
The following table summarizes the amortized cost and fair value of our available-for-sale securities as of October 31, 2018, by contractual years-to-maturity (in millions):
  (was, 2018-06-05, similarity 0.9699):
[0001327567-18-000014:note_history:101]
The following table summarizes the amortized cost and fair value of our available-for-sale securities as of April 30, 2018, by contractual years-to-maturity (in millions):

- added (2018-11-30):
[0001327567-18-000031:note_history:102]
Marketable Equity Securities

- added (2018-11-30):
[0001327567-18-000031:note_history:103]
Marketable equity securities consist of money market funds and are included in cash and cash equivalents in our condensed consolidated balance sheets. As of October 31, 2018 and July 31, 2018, the carrying value of our marketable equity securities were $904.4 million and $1.5 billion, respectively. During the three months ended October 31, 2018 and 2017, there were no unrealized gains or losses recognized for these securities.

- removed (2018-11-30):
[0001327567-18-000014:note_history:104]
|  | April 30, 2018 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Estimated Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Money market funds | $ | 361.8 |  |  | $ | — |  |  | $ | — |  |  | $ | 361.8 |  |
| Commercial paper | 32.1 |  |  | — |  |  | — |  |  | 32.1 |  |
| Corporate debt securities | 1.0 |  |  | — |  |  | — |  |  | 1.0 |  |
| U.S. government and agency securities | 129.6 |  |  | — |  |  | — |  |  | 129.6 |  |
| Total cash equivalents | $ | 524.5 |  |  | $ | — |  |  | $ | — |  |  | $ | 524.5 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 5.4 |  |  | $ | — |  |  | $ | — |  |  | $ | 5.4 |  |
| Corporate debt securities | 283.9 |  |  | 0.1 |  |  | (2.8 | ) |  | 281.2 |  |
| U.S. government and agency securities | 987.6 |  |  | — |  |  | (9.1 | ) |  | 978.5 |  |
| Total investments | $ | 1,276.9 |  |  | $ | 0.1 |  |  | $ | (11.9 | ) |  | $ | 1,265.1 |  |

- removed (2018-11-30):
[0001327567-18-000014:note_history:105]
|  | July 31, 2017 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Estimated Fair Value |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 5.4 |  |  | $ | — |  |  | $ | — |  |  | $ | 5.4 |  |
| Corporate debt securities | 346.1 |  |  | 0.3 |  |  | (0.5 | ) |  | 345.9 |  |
| U.S. government and agency securities | 1,071.2 |  |  | 0.1 |  |  | (2.6 | ) |  | 1,068.7 |  |
| Total investments | $ | 1,422.7 |  |  | $ | 0.4 |  |  | $ | (3.1 | ) |  | $ | 1,420.0 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: no_prior_note, score: 0.0

- added (2018-11-30):
[0001327567-18-000031:note_history:106]
Revenue

- added (2018-11-30):
[0001327567-18-000031:note_history:107]
Revenue Recognition

- added (2018-11-30):
[0001327567-18-000031:note_history:108]
Our revenue consists of product revenue and subscription and support revenue. Revenue is recognized when control of promised products, subscriptions and support services are transferred to customers with the expected consideration in exchange for those products and services. Depending on who the contract is with, our customers are either our channel partners or our end-customers.

- added (2018-11-30):
[0001327567-18-000031:note_history:109]
We determine revenue recognition through the following steps:

- added (2018-11-30):
[0001327567-18-000031:note_history:110]
| • | Identification of the contract, or contracts, with a customer. |

- added (2018-11-30):
[0001327567-18-000031:note_history:111]
| • | Identification of the performance obligations in the contract. |

- added (2018-11-30):
[0001327567-18-000031:note_history:112]
| • | Determination of the transaction price. |

- added (2018-11-30):
[0001327567-18-000031:note_history:113]
| • | Allocation of the transaction price to the performance obligations in the contract. |

- added (2018-11-30):
[0001327567-18-000031:note_history:114]
| • | Recognition of revenue when, or as, we satisfy a performance obligation. |

- added (2018-11-30):
[0001327567-18-000031:note_history:115]
Revenues are reported net of sales taxes. Shipping charges billed to channel partners are included in revenues and related costs are included in cost of revenue.

- added (2018-11-30):
[0001327567-18-000031:note_history:116]
Product Revenue

- added (2018-11-30):
[0001327567-18-000031:note_history:117]
Product revenue is derived primarily from sales of our appliances. Product revenue also includes revenue derived from software licenses of Panorama and the VM-Series. We recognize product revenue at the time of hardware shipment or delivery of software license.

- added (2018-11-30):
[0001327567-18-000031:note_history:118]
Subscription and Support Revenue

- added (2018-11-30):
[0001327567-18-000031:note_history:119]
Subscription and support revenue is derived primarily from sales of our subscription and support offerings. We recognize subscription and support revenue over time as the services are performed. Our contractual subscription and support contracts are typically one to five years.

- added (2018-11-30):
[0001327567-18-000031:note_history:120]
Contracts with Multiple Performance Obligations

- added (2018-11-30):
[0001327567-18-000031:note_history:121]
The majority of our contracts with our customers include various combinations of our products and subscriptions and support which are distinct and accounted for as separate performance obligations. We account for multiple agreements with a single customer as a single contract if the contractual terms and/or substance of those agreements indicate that they may be so closely related that they are, in effect, parts of a single contract. The amount of consideration we expect to receive in exchange for delivering on the contract is allocated to each performance obligation based on its relative standalone selling price. If a contract contains a single performance obligation, no allocation is required.

- added (2018-11-30):
[0001327567-18-000031:note_history:122]
We establish standalone selling price using the prices charged for a deliverable when sold separately. If the standalone selling price is not observable through past transactions, we estimate the standalone selling price based on our pricing model and our go-to-market strategy, which include factors such as type of sales channel (reseller, distributor, or end-customer), the geographies in which our offerings were sold (domestic or international), and offering type (products, subscriptions, or support).

- added (2018-11-30):
[0001327567-18-000031:note_history:123]
Deferred Revenue

- added (2018-11-30):
[0001327567-18-000031:note_history:124]
We record deferred revenue when cash payments are received or due in advance of our performance. Our payment terms typically require payment within 30 to 45 days of the date we issue an invoice. The current portion of deferred revenue represents the amounts that are expected to be recognized as revenue within one year of the condensed consolidated balance sheet date. During the three months ended October 31, 2018, we recognized approximately $370.0 million of revenue pertaining to amounts that were deferred as of July 31, 2018.

- added (2018-11-30):
[0001327567-18-000031:note_history:125]
Remaining Performance Obligations

- added (2018-11-30):
[0001327567-18-000031:note_history:126]
Revenue expected to be recognized from remaining performance obligations was $2.5 billion as of October 31, 2018, of which we expect to recognize approximately $1.3 billion over the next 12 months and the remainder thereafter.

- added (2018-11-30):
[0001327567-18-000031:note_history:127]
Disaggregation of Revenue

- added (2018-11-30):
[0001327567-18-000031:note_history:128]
The following table presents revenue by geographic theater (in millions):

- added (2018-11-30):
[0001327567-18-000031:note_history:129]
|  | Three Months Ended October 31, |
|  | 2018 |  | 2017 |
|  |  |  | (As Adjusted) |
| Revenue: |  |  |  |
| Americas |  |  |  |
| United States | $ | 415.9 |  |  | $ | 326.0 |  |
| Other Americas | 34.3 |  |  | 23.3 |  |
| Total Americas | 450.2 |  |  | 349.3 |  |
| Europe, the Middle East, and Africa (“EMEA”) | 127.7 |  |  | 94.7 |  |
| Asia Pacific and Japan (“APAC”) | 78.1 |  |  | 57.8 |  |
| Total revenue | $ | 656.0 |  |  | $ | 501.8 |  |

- added (2018-11-30):
[0001327567-18-000031:note_history:130]
The following table presents revenue for groups of similar products and services (in millions):

- added (2018-11-30):
[0001327567-18-000031:note_history:131]
|  | Three Months Ended October 31, |
|  | 2018 |  | 2017 |
|  |  |  | (As Adjusted) |
| Revenue: |  |  |  |
| Product | $ | 240.5 |  |  | $ | 184.8 |  |
| Subscription and support |  |  |  |
| Subscription | 231.3 |  |  | 169.0 |  |
| Support | 184.2 |  |  | 148.0 |  |
| Total subscription and support | 415.5 |  |  | 317.0 |  |
| Total revenue | $ | 656.0 |  |  | $ | 501.8 |  |

- added (2018-11-30):
[0001327567-18-000031:note_history:132]
Deferred Contract Costs

- added (2018-11-30):
[0001327567-18-000031:note_history:133]
We defer contract costs that are recoverable and incremental to obtaining customer sales contracts. Contract costs, which primarily consist of sales commissions, are amortized on a systematic basis that is consistent with the transfer to the customer of the goods or services to which the asset relates. Sales commissions paid for initial contracts are generally not commensurate with the commissions paid for renewal contracts, given the substantive difference in commission rates in proportion to their respective contract values. Sales commissions for initial contracts that are not commensurate are amortized over a benefit period of five years, consistent with the revenue recognition pattern of the performance obligations in the related contracts including expected renewals. The benefit period is determined by taking into consideration contract length, technology life, and other quantitative and qualitative factors. The expected renewals are estimated based on historical renewal trends. Sales commissions for initial contracts that are commensurate and sales commissions for renewal contracts are amortized over the related contractual period in proportion to the revenue recognized.

- added (2018-11-30):
[0001327567-18-000031:note_history:134]
We classify deferred contract costs as short-term or long-term based on when we expect to recognize the expense. Short-term deferred contract costs are included in prepaid expenses and other current assets and long-term deferred contract costs are included in other assets in our condensed consolidated balance sheets. Deferred contract costs are periodically reviewed for impairment. The amortization of deferred contract costs is included in sales and marketing expense in our condensed consolidated statements of operations.

- added (2018-11-30):
[0001327567-18-000031:note_history:135]
The following table presents details of our short-term and long-term deferred contract costs as of October 31, 2018 and July 31, 2018 (in millions):

- added (2018-11-30):
[0001327567-18-000031:note_history:136]
|  | October 31, 2018 |  | July 31, 2018 |
| Short-term deferred contract costs | $ | 112.1 |  |  | $ | 113.2 |  |
| Long-term deferred contract costs | 223.1 |  |  | 224.8 |  |
| Total deferred contract costs | $ | 335.2 |  |  | $ | 338.0 |  |

- added (2018-11-30):
[0001327567-18-000031:note_history:137]
We recognized amortization expense for our deferred contract costs of $41.1 million and $28.1 million during the three months ended October 31, 2018 and 2017, respectively. We did not recognize any impairment losses on our deferred contract costs during the three months ended October 31, 2018 or 2017.


## us-gaap:RevenueRecognitionPolicyTextBlock (revenue_recognition_policy) — matched_by: no_prior_note, score: 0.0

- added (2018-11-30):
[0001327567-18-000031:note_history:138]
Revenue Recognition

- added (2018-11-30):
[0001327567-18-000031:note_history:139]
Our revenue consists of product revenue and subscription and support revenue. Revenue is recognized when control of promised products, subscriptions and support services are transferred to customers with the expected consideration in exchange for those products and services. Depending on who the contract is with, our customers are either our channel partners or our end-customers.

- added (2018-11-30):
[0001327567-18-000031:note_history:140]
We determine revenue recognition through the following steps:

- added (2018-11-30):
[0001327567-18-000031:note_history:141]
| • | Identification of the contract, or contracts, with a customer. |

- added (2018-11-30):
[0001327567-18-000031:note_history:142]
| • | Identification of the performance obligations in the contract. |

- added (2018-11-30):
[0001327567-18-000031:note_history:143]
| • | Determination of the transaction price. |

- added (2018-11-30):
[0001327567-18-000031:note_history:144]
| • | Allocation of the transaction price to the performance obligations in the contract. |

- added (2018-11-30):
[0001327567-18-000031:note_history:145]
| • | Recognition of revenue when, or as, we satisfy a performance obligation. |

- added (2018-11-30):
[0001327567-18-000031:note_history:146]
Revenues are reported net of sales taxes. Shipping charges billed to channel partners are included in revenues and related costs are included in cost of revenue.

- added (2018-11-30):
[0001327567-18-000031:note_history:147]
Product Revenue

- added (2018-11-30):
[0001327567-18-000031:note_history:148]
Product revenue is derived primarily from sales of our appliances. Product revenue also includes revenue derived from software licenses of Panorama and the VM-Series. We recognize product revenue at the time of hardware shipment or delivery of software license.

- added (2018-11-30):
[0001327567-18-000031:note_history:149]
Subscription and Support Revenue

- added (2018-11-30):
[0001327567-18-000031:note_history:150]
Subscription and support revenue is derived primarily from sales of our subscription and support offerings. We recognize subscription and support revenue over time as the services are performed. Our contractual subscription and support contracts are typically one to five years.

- added (2018-11-30):
[0001327567-18-000031:note_history:151]
Contracts with Multiple Performance Obligations

- added (2018-11-30):
[0001327567-18-000031:note_history:152]
The majority of our contracts with our customers include various combinations of our products and subscriptions and support which are distinct and accounted for as separate performance obligations. We account for multiple agreements with a single customer as a single contract if the contractual terms and/or substance of those agreements indicate that they may be so closely related that they are, in effect, parts of a single contract. The amount of consideration we expect to receive in exchange for delivering on the contract is allocated to each performance obligation based on its relative standalone selling price. If a contract contains a single performance obligation, no allocation is required.

- added (2018-11-30):
[0001327567-18-000031:note_history:153]
We establish standalone selling price using the prices charged for a deliverable when sold separately. If the standalone selling price is not observable through past transactions, we estimate the standalone selling price based on our pricing model and our go-to-market strategy, which include factors such as type of sales channel (reseller, distributor, or end-customer), the geographies in which our offerings were sold (domestic or international), and offering type (products, subscriptions, or support).
