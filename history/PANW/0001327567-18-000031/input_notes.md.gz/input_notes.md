# PANW notes — 0001327567-18-000031


## panw:ConvertibleDebtOtherDetailsTableTextBlock

[0001327567-18-000031:notes:1]
The following table presents details of the Notes (number of shares in millions):

[0001327567-18-000031:notes:2]
|  | Conversion Rate per $1,000 Principal |  | Initial Conversion Price |  | Convertible Date |  | Initial Number of Shares |
| 2019 Notes | 9.0680 |  |  | $ | 110.28 |  |  | January 1, 2019 |  | 5.2 |  |
| 2023 Notes | 3.7545 |  |  | $ | 266.35 |  |  | April 1, 2023 |  | 6.4 |  |


## panw:DebtSecuritiesAvailableforsaleTableTextBlock

[0001327567-18-000031:notes:3]
The following tables summarize the amortized cost, unrealized gains and losses, and fair value of our available-for-sale securities as of October 31, 2018 and July 31, 2018 (in millions):

[0001327567-18-000031:notes:4]
|  | October 31, 2018 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | $ | 5.0 |  |  | $ | — |  |  | $ | — |  |  | $ | 5.0 |  |
| Corporate debt securities | 2.5 |  |  | — |  |  | — |  |  | 2.5 |  |
| U.S. government and agency securities | 210.3 |  |  | — |  |  | — |  |  | 210.3 |  |
| Total available-for-sale cash equivalents | $ | 217.8 |  |  | $ | — |  |  | $ | — |  |  | $ | 217.8 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 5.4 |  |  | $ | — |  |  | $ | — |  |  | $ | 5.4 |  |
| Non-U.S. government securities | 20.0 |  |  | — |  |  | — |  |  | 20.0 |  |
| Commercial paper | 97.3 |  |  | — |  |  | — |  |  | 97.3 |  |
| Corporate debt securities | 382.5 |  |  | — |  |  | (2.4 | ) |  | 380.1 |  |
| U.S. government and agency securities | 1,489.0 |  |  | — |  |  | (6.9 | ) |  | 1,482.1 |  |
| Total available-for-sale investments | $ | 1,994.2 |  |  | $ | — |  |  | $ | (9.3 | ) |  | $ | 1,984.9 |  |

[0001327567-18-000031:notes:5]
|  | July 31, 2018 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | $ | 52.0 |  |  | $ | — |  |  | $ | — |  |  | $ | 52.0 |  |
| U.S. government and agency securities | 397.3 |  |  | — |  |  | — |  |  | 397.3 |  |
| Total available-for-sale cash equivalents | $ | 449.3 |  |  | $ | — |  |  | $ | — |  |  | $ | 449.3 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 5.4 |  |  | $ | — |  |  | $ | — |  |  | $ | 5.4 |  |
| Non-U.S. government securities | 20.0 |  |  | — |  |  | — |  |  | 20.0 |  |
| Commercial paper | 22.3 |  |  | — |  |  | — |  |  | 22.3 |  |
| Corporate debt securities | 295.9 |  |  | — |  |  | (2.5 | ) |  | 293.4 |  |
| U.S. government and agency securities | 1,110.6 |  |  | — |  |  | (7.7 | ) |  | 1,102.9 |  |
| Total available-for-sale investments | $ | 1,454.2 |  |  | $ | — |  |  | $ | (10.2 | ) |  | $ | 1,444.0 |  |


## panw:ScheduleofNoteHedgeTransactionsTableTextBlock

[0001327567-18-000031:notes:6]
The following table presents details of the Note Hedges (in millions):

[0001327567-18-000031:notes:7]
|  | Initial Number of Shares |  | Aggregate Purchase |
| 2019 Note Hedges | 5.2 |  |  | $ | 111.0 |  |
| 2023 Note Hedges | 6.4 |  |  | $ | 332.0 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001327567-18-000031:notes:8]
[same as prior period, unchanged from 0001327567-18-000014:notes:4]

[0001327567-18-000031:notes:9]
RedLock Inc.

[0001327567-18-000031:notes:10]
On October 12, 2018, we completed our acquisition of 100% of the voting equity interest of RedLock Inc. (“RedLock”), a privately-held cloud security company. The acquisition expands our security capabilities for the public cloud with the addition of RedLock’s cloud security analytics technology. Total purchase consideration for the acquisition of RedLock was $158.2 million, which consisted of $155.0 million in cash paid upon closing and $3.2 million in fair value of unvested equity awards attributable to services performed prior to the acquisition date.

[0001327567-18-000031:notes:11]
As part of the acquisition, we assumed RedLock equity awards with a total fair value of $57.4 million. Of the total fair value, a portion was allocated to the purchase consideration and the remainder was allocated to future services and will be expensed over the remaining service periods as share-based compensation.

[0001327567-18-000031:notes:12]
[same as prior period, unchanged from 0001327567-18-000014:notes:7]

[0001327567-18-000031:notes:13]
|  | Amount |
| Goodwill | $ | 113.6 |  |
| Identified intangible assets | 54.8 |  |
| Net liabilities assumed | (10.2 | ) |
| Total | $ | 158.2 |  |

[0001327567-18-000031:notes:14]
Goodwill generated from this business combination is primarily attributable to the assembled workforce and expected post-acquisition synergies from integrating RedLock’s technology into our platform. The goodwill is not deductible for income tax purposes.

[0001327567-18-000031:notes:15]
[same as prior period, unchanged from 0001327567-18-000014:notes:10]

[0001327567-18-000031:notes:16]
|  | Fair Value |  | Estimated Useful Life |
| Developed technology | $ | 48.6 |  |  | 4 years |
| Customer relationships | 5.3 |  |  | 8 years |
| Trade name and trademarks | 0.9 |  |  | 6 months |
| Total | $ | 54.8 |  |  |  |

[0001327567-18-000031:notes:17]
RedLock’s operating results are included in our condensed consolidated statements of operations from the date of acquisition. Pro forma results of operations have not been presented because the effect of the acquisition was not material to our condensed consolidated statements of operations.

[0001327567-18-000031:notes:18]
Additional information, such as that related to income tax and other contingencies, existing as of the acquisition date but unknown to us may become known during the remainder of the measurement period, not to exceed 12 months from the acquisition date, which may result in changes to the amounts and allocations recorded.


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock

[0001327567-18-000031:notes:19]
[same as prior period, unchanged from 0001327567-18-000014:notes:21]

[0001327567-18-000031:notes:20]
[same as prior period, unchanged from 0001327567-18-000014:notes:22]

[0001327567-18-000031:notes:21]
Palo Alto Networks, Inc. (the “Company,” “we,” “us,” or “our”), located in Santa Clara, California, was incorporated in March 2005 under the laws of the State of Delaware and commenced operations in April 2005. We offer a security operating platform that empowers enterprises, service providers, and government entities to secure their organizations by safely enabling applications and data running in their networks, on their endpoints, and in the cloud, and by preventing breaches that stem from targeted cyberattacks.

[0001327567-18-000031:notes:22]
[same as prior period, unchanged from 0001327567-18-000014:notes:24]

[0001327567-18-000031:notes:23]
The accompanying condensed consolidated financial statements have been prepared in conformity with U.S. generally accepted accounting principles (“GAAP”), consistent in all material respects with those applied in our Annual Report on Form 10-K for the fiscal year ended July 31, 2018, filed with the Securities and Exchange Commission (“SEC”) on September 13, 2018. Our condensed consolidated financial statements include our accounts and our wholly owned subsidiaries. All significant intercompany balances and transactions have been eliminated in consolidation.

[0001327567-18-000031:notes:24]
Our condensed consolidated financial statements are unaudited, but include all adjustments of a normal recurring nature necessary for a fair presentation of our quarterly results. We have made estimates and judgments affecting the amounts reported in our condensed consolidated financial statements and the accompanying notes. The actual results that we experience may differ materially from our estimates.

[0001327567-18-000031:notes:25]
Certain prior period amounts have been adjusted due to our retrospective adoption of new accounting guidance related to revenue from contracts with customers and new accounting guidance related to the presentation of restricted cash and cash equivalents in the statement of cash flows. Refer to “Recently Adopted Accounting Pronouncements” below for more information.

[0001327567-18-000031:notes:26]
Our condensed consolidated financial statements should be read in conjunction with the audited consolidated financial statements and related notes in our Annual Report on Form 10-K for the fiscal year ended July 31, 2018.

[0001327567-18-000031:notes:27]
[same as prior period, unchanged from 0001327567-18-000014:notes:28]

[0001327567-18-000031:notes:28]
There have been no material changes to our significant accounting policies as of and for the three months ended October 31, 2018, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended July 31, 2018, except for the change in our accounting policies for revenue recognition and deferred contract costs due to our adoption of new accounting guidance related to revenue from contracts with customers. Refer to “Recently Adopted Accounting Pronouncements” below, Note 2. Revenue, and Note 8. Deferred Contract Costs for more information.

[0001327567-18-000031:notes:29]
Recently Adopted Accounting Pronouncements

[0001327567-18-000031:notes:30]
[same as prior period, unchanged from 0001327567-18-000014:notes:34]

[0001327567-18-000031:notes:31]
In January 2017, the Financial Accounting Standards Board (“FASB”) issued authoritative guidance clarifying the definition of a business to assist companies with evaluating whether transactions should be accounted for as acquisitions (or disposals) of assets or businesses. We adopted this standard in our first quarter of fiscal 2019 on a prospective basis. The adoption of the standard did not have an impact on our condensed consolidated financial statements.

[0001327567-18-000031:notes:32]
[same as prior period, unchanged from 0001327567-18-000014:notes:36]

[0001327567-18-000031:notes:33]
In November 2016, the FASB issued authoritative guidance on the presentation of restricted cash or restricted cash equivalents in the statement of cash flows. Under the new standard, restricted cash or restricted cash equivalents should be included with cash and cash equivalents when reconciling the beginning-of-period and end-of-period total amounts shown on the statement of cash flows. We adopted this standard in our first quarter of fiscal 2019 on a retrospective basis. The adoption of the standard did not have a material impact on our condensed consolidated financial statements because our restricted cash balance has not been material.

[0001327567-18-000031:notes:34]
[same as prior period, unchanged from 0001327567-18-000014:notes:38]

[0001327567-18-000031:notes:35]
In October 2016, the FASB issued authoritative guidance requiring the recognition of income tax consequences of an intra-entity transfer of an asset, other than inventory, when the transfer occurs. We adopted the standard in our first quarter of fiscal 2019 on a modified retrospective basis. As a result, we recorded the cumulative effect of the change as an increase to accumulated deficit of $28.4 million, with a corresponding decrease to prepaid expenses and other current assets and other assets in our condensed consolidated balance sheets as of August 1, 2018, the date of adoption. The cumulative effect adjustment represents the reclassification of unrecognized income tax effects from intra-entity transfers of assets other than inventory that occurred prior to the date of adoption.

[0001327567-18-000031:notes:36]
[same as prior period, unchanged from 0001327567-18-000014:notes:40]

[0001327567-18-000031:notes:37]
In August 2016, the FASB issued new authoritative guidance addressing eight specific cash flow issues with the objective of reducing the existing diversity in practice in how certain transactions are presented and classified in the statement of cash flows. We adopted this standard in our first quarter of fiscal 2019 on a retrospective basis. The adoption of the standard did not have an impact on our condensed consolidated financial statements.

[0001327567-18-000031:notes:38]
Financial Instruments - Recognition and Measurement

[0001327567-18-000031:notes:39]
In January 2016, the FASB issued authoritative guidance requiring equity instruments to be measured at fair value with changes in fair value recognized through net income. We adopted this standard in our first quarter of fiscal 2019 on a prospective basis for non-marketable equity securities and a modified retrospective basis for marketable equity investments. The adoption of the standard did not have an impact on our condensed consolidated financial statements.

[0001327567-18-000031:notes:40]
[same as prior period, unchanged from 0001327567-18-000014:notes:46]

[0001327567-18-000031:notes:41]
In May 2014, the FASB issued new authoritative guidance on revenue from contracts with customers. The new standard provides principles for recognizing revenue when control of promised goods or services is transferred to customers with the expected consideration in exchange for those goods or services, as well as guidance on the recognition of costs related to obtaining and fulfilling customer contracts. The standard also requires expanded disclosures about the nature, amount, timing, and uncertainty of revenues and cash flows arising from customer contracts, including significant judgments and changes in judgments, and assets recognized from costs incurred to obtain or fulfill a contract. We adopted the standard in our first quarter of fiscal 2019 using the full retrospective method.

[0001327567-18-000031:notes:42]
The adoption of the new standard did not have a material impact on our condensed consolidated financial statements for the fiscal years ended July 31, 2018 and 2017, with the exception of the accounting for incremental costs to obtain customer contracts, which primarily consist of sales commissions, due to the longer period of amortization. Under the previous accounting guidance, we deferred and amortized these costs over the term of the related contract. Under the new standard, we defer and amortize these costs for initial contracts that are not commensurate with renewal commissions over a benefit period of five years, which is typically longer than the initial contract term.

[0001327567-18-000031:notes:43]
The adoption of the standard using the full retrospective method required us to restate the prior periods presented in this Quarterly Report on Form 10-Q, with the cumulative effect of the change of $168.2 million reflected in accumulated deficit as of August 1, 2017. In adopting the new standard, we have also applied a transition practical expedient and have not disclosed revenue expected to be recognized from remaining performance obligations for periods prior to August 1, 2018.

[0001327567-18-000031:notes:44]
The following tables present the impact of the adoption of the standard on our previously reported results (in millions, except per share data):

[0001327567-18-000031:notes:45]
|  | Three Months Ended October 31, 2017 |
|  | As Previously Reported |  | Impact of Adoption |  | As Adjusted |
| Condensed Consolidated Statements of Operations |  |  |  |  |  |
| Product revenue | $ | 186.5 |  |  | $ | (1.7 | ) |  | $ | 184.8 |  |
| Subscription and support revenue | 319.0 |  |  | (2.0 | ) |  | 317.0 |  |
| Total revenue | 505.5 |  |  | (3.7 | ) |  | 501.8 |  |
| Total cost of revenue | 141.4 |  |  | (0.1 | ) |  | 141.3 |  |
| Total operating expenses | 418.4 |  |  | (4.4 | ) |  | 414.0 |  |
| Operating loss | (54.3 | ) |  | 0.8 |  |  | (53.5 | ) |
| Net loss | (64.0 | ) |  | 0.8 |  |  | (63.2 | ) |
| Net loss per share, basic and diluted | $ | (0.70 | ) |  | $ | — |  |  | $ | (0.70 | ) |

[0001327567-18-000031:notes:46]
|  | July 31, 2018 |
|  | As Previously Reported |  | Impact of Adoption |  | As Adjusted |
| Condensed Consolidated Balance Sheet |  |  |  |  |  |
| Accounts receivable, net | $ | 467.3 |  |  | $ | (0.3 | ) |  | $ | 467.0 |  |
| Prepaid expenses and other current assets | 261.3 |  |  | 6.8 |  |  | 268.1 |  |
| Other assets | 206.8 |  |  | 119.4 |  |  | 326.2 |  |
| Accrued and other liabilities | 107.0 |  |  | 17.6 |  |  | 124.6 |  |
| Deferred revenue | 1,268.9 |  |  | (55.3 | ) |  | 1,213.6 |  |
| Long-term deferred revenue | 1,096.0 |  |  | (30.3 | ) |  | 1,065.7 |  |
| Accumulated deficit | $ | (984.6 | ) |  | $ | 193.9 |  |  | $ | (790.7 | ) |

[0001327567-18-000031:notes:47]
The adoption of the standard did not impact net cash flows from operating, investing, or financing activities in our condensed consolidated statements of cash flows.

[0001327567-18-000031:notes:48]
Recently Issued Accounting Pronouncements

[0001327567-18-000031:notes:49]
Implementation Costs Incurred in a Cloud Computing Arrangement

[0001327567-18-000031:notes:50]
In August 2018, the FASB issued new authoritative guidance on customer’s accounting for implementation costs incurred in a cloud computing arrangement that is a service contract, which will require customers to apply internal-use software guidance to determine the implementation costs that are able to be capitalized. Capitalized implementation costs will be required to be amortized over the term of the arrangement, beginning when the module or component of the hosting arrangement is ready for its intended use. The standard is effective for us in our first quarter of fiscal 2021 and will be applied on either a prospective or retrospective basis. Early adoption is permitted. We are currently evaluating adoption timing and whether this standard will have a material impact on our condensed consolidated financial statements.

[0001327567-18-000031:notes:51]
[same as prior period, unchanged from 0001327567-18-000014:notes:42]

[0001327567-18-000031:notes:52]
In June 2016, the FASB issued new authoritative guidance on the accounting for credit losses on most financial assets and certain financial instruments. The standard replaces the existing incurred loss model with an expected credit loss model for financial assets measured at amortized cost, including trade receivables, and requires that credit losses on available-for-sale debt securities be presented as an allowance rather than as a write-down. The standard is effective for us in our first quarter of fiscal 2021 and will be applied on a modified retrospective basis. Early adoption is permitted beginning our first quarter of fiscal 2020. We are currently evaluating adoption timing and whether this standard will have a material impact on our condensed consolidated financial statements.

[0001327567-18-000031:notes:53]
[same as prior period, unchanged from 0001327567-18-000014:notes:44]

[0001327567-18-000031:notes:54]
In February 2016, the FASB issued new authoritative guidance on lease accounting. Among its provisions, the standard requires lessees to recognize right-of-use assets and lease liabilities on the balance sheet for operating leases and also requires additional qualitative and quantitative disclosures about lease arrangements. The standard is effective for us in our first quarter of fiscal 2020 and will be applied on a modified retrospective basis, with the option to elect certain practical expedients. Early adoption is permitted; however, we plan to adopt the new standard in our first quarter of fiscal 2020. Upon adoption, we will recognize right-of-use assets and operating lease liabilities on our condensed consolidated balance sheets, which will increase our total assets and total liabilities. We are currently evaluating the accounting, transition, and disclosure requirements of this standard, including its impact on our accounting policies and processes.


## us-gaap:CapitalizedContractCostTableTextBlock

[0001327567-18-000031:notes:55]
The following table presents details of our short-term and long-term deferred contract costs as of October 31, 2018 and July 31, 2018 (in millions):

[0001327567-18-000031:notes:56]
|  | October 31, 2018 |  | July 31, 2018 |
| Short-term deferred contract costs | $ | 112.1 |  |  | $ | 113.2 |  |
| Long-term deferred contract costs | 223.1 |  |  | 224.8 |  |
| Total deferred contract costs | $ | 335.2 |  |  | $ | 338.0 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001327567-18-000031:notes:57]
Commitments and Contingencies

[0001327567-18-000031:notes:58]
We lease our facilities under various non-cancelable operating leases, which expire through the year ending July 31, 2028.

[0001327567-18-000031:notes:59]
In May 2015 and October 2015, we entered into a total of three lease agreements for approximately 941,000 square feet of corporate office space in Santa Clara, California, which serves as our new corporate headquarters. The leases contain rent holiday periods, scheduled rent increases, lease incentives, and renewal options which allow the lease terms to be extended beyond their expiration dates of July 2028 through July 2046. In September 2017, per the terms of the lease agreements, the landlords exercised their option to amend our lease payment schedules and eliminate our rent holiday periods, which increased our rental payments by $24.4 million, $11.8 million, and $2.0 million for fiscal 2018, 2019, and 2020, respectively. In exchange, we received an upfront cash reimbursement of $38.2 million during the three months ended October 31, 2017, which we have applied and will apply against the future additional rental payments when due. As amended, rental payments under the three lease agreements are approximately $412.0 million over the lease term.

[0001327567-18-000031:notes:60]
In May 2015, we also entered into a lease agreement for approximately 122,000 square feet of space in Santa Clara, California, to serve as an extension of our previous corporate headquarters. The lease contains scheduled rent increases, lease incentives, and renewal options which allow the lease term to be extended beyond the expiration date of April 2021 through July 2046. Rental payments under the lease agreement are approximately $23.1 million over the lease term. In December 2017, we entered into an agreement to sublease this office space for the remaining lease term. Proceeds from this sublease will be approximately $16.3 million over the sublease term.

[0001327567-18-000031:notes:61]
In September 2012, we entered into two lease agreements for a total of approximately 300,000 square feet of space in Santa Clara, California, which served as our previous corporate headquarters through August 2017, when we relocated to our new corporate campus. The leases contain rent holiday periods and two separate five-year options to extend the lease term beyond their expiration dates of July 2023. Rental payments under these lease agreements are approximately $94.3 million over the lease term. In August 2017, we exited our previous headquarter facilities and relocated to our new corporate campus, which resulted in the recognition of a cease-use loss of $39.2 million as general and administrative expense in our consolidated statements of operations during the year ended July 31, 2018, and a corresponding liability in our consolidated balance sheets. During the three months ended October 31, 2018, we released $2.5 million of the cease-use liability through rental payments. As of October 31, 2018, the remaining balance of the cease-use liability was $26.6 million, which is expected to be paid through the end of the lease term in July 2023.

[0001327567-18-000031:notes:62]
The following table presents details of the aggregate future non-cancelable minimum rental payments under our operating leases as of October 31, 2018 (in millions):

[0001327567-18-000031:notes:63]
|  | Amount |
| Fiscal years ending July 31: |  |
| Remaining 2019 | $ | 50.4 |  |
| 2020 | 68.9 |  |
| 2021 | 64.1 |  |
| 2022 | 59.8 |  |
| 2023 | 58.5 |  |
| 2024 and thereafter | 224.1 |  |
| Committed gross lease payments | 525.8 |  |
| Less: proceeds from sublease rentals | 12.8 |  |
| Net operating lease obligation | $ | 513.0 |  |

[0001327567-18-000031:notes:64]
Purchase Commitments

[0001327567-18-000031:notes:65]
Manufacturing Purchase Commitments

[0001327567-18-000031:notes:66]
Our electronics manufacturing service provider (“EMS provider”) procures components and assembles our products based on our forecasts. These forecasts are based on estimates of demand for our products primarily for the next 12 months, which are in turn based on historical trends and an analysis from our sales and product management organizations, adjusted for overall market conditions. In order to reduce manufacturing lead times and plan for adequate supply, we may issue non-cancelable orders for products and components to our manufacturing partners or component suppliers. As of October 31, 2018, our purchase commitments under such orders were $155.6 million, excluding obligations under contracts that we can cancel without a significant penalty.

[0001327567-18-000031:notes:67]
Other Purchase Commitments

[0001327567-18-000031:notes:68]
In March 2018, we amended an agreement with a third-party provider for our use of certain cloud services through June 2020. Under the non-cancelable addendum, we are committed to a minimum purchase of $14.0 million between April 2018 and March 2019 and $8.0 million between April 2019 and March 2020. As of October 31, 2018, our purchase commitment under the addendum was $8.0 million.

[0001327567-18-000031:notes:69]
Litigation

[0001327567-18-000031:notes:70]
We are subject to legal proceedings, claims, and litigation arising in the ordinary course of business, including intellectual property litigation. Such matters are subject to many uncertainties and outcomes are not predictable with assurance. We accrue for contingencies when we believe that a loss is probable and that we can reasonably estimate the amount of any such loss.

[0001327567-18-000031:notes:71]
To the extent there is a reasonable possibility that a loss exceeding amounts already recognized may be incurred and the amount of such additional loss would be material, we will either disclose the estimated additional loss or state that such an estimate cannot be made. As of October 31, 2018, we have not recorded any significant accruals for loss contingencies associated with such legal proceedings, determined that an unfavorable outcome is probable or reasonably possible, or determined that the amount or range of any possible loss is reasonably estimable.


## us-gaap:ConvertibleDebtTableTextBlock

[0001327567-18-000031:notes:72]
The following table sets forth the components of the Notes as of October 31, 2018 and July 31, 2018 (in millions):

[0001327567-18-000031:notes:73]
|  | October 31, 2018 |  | July 31, 2018 |
|  | 2019 Notes |  | 2023 Notes |  | Total |  | 2019 Notes |  | 2023 Notes |  | Total |
| Liability component: |  |  |  |  |  |  |  |  |  |  |  |
| Principal | $ | 247.7 |  |  | $ | 1,693.0 |  |  | $ | 1,940.7 |  |  | $ | 575.0 |  |  | $ | 1,693.0 |  |  | $ | 2,268.0 |  |
| Less: debt discount and debt issuance costs, net of amortization | 7.8 |  |  | 308.5 |  |  | 316.3 |  |  | 24.6 |  |  | 323.3 |  |  | 347.9 |  |
| Net carrying amount | $ | 239.9 |  |  | $ | 1,384.5 |  |  | $ | 1,624.4 |  |  | $ | 550.4 |  |  | $ | 1,369.7 |  |  | $ | 1,920.1 |  |
| Equity component (including amounts classified as temporary equity) | $ | 47.3 |  |  | $ | 315.0 |  |  | $ | 362.3 |  |  | $ | 109.8 |  |  | $ | 315.0 |  |  | $ | 424.8 |  |


## us-gaap:DebtDisclosureTextBlock

[0001327567-18-000031:notes:74]
Debt

[0001327567-18-000031:notes:75]
Convertible Senior Notes

[0001327567-18-000031:notes:76]
In June 2014, we issued $575.0 million aggregate principal amount of 0.0% Convertible Senior Notes due 2019 (the “2019 Notes”) and in July 2018, we issued $1.7 billion aggregate principal amount of 0.75% Convertible Senior Notes due 2023 (the “2023 Notes” and, together with the 2019 Notes, the “Notes”). The 2023 Notes bear interest at a fixed rate of 0.75% per year, payable semi-annually in arrears on January 1 and July 1 of each year, beginning on January 1, 2019. Each series of Notes is governed by an indenture between us, as the issuer, and U.S. Bank National Association, as Trustee (individually, each an “Indenture,” and together, the “Indentures”). The Notes of each series are unsecured, unsubordinated obligations and the applicable Indenture governing each series of Notes does not contain any financial covenants or restrictions on the payments of dividends, the incurrence of indebtedness, or the issuance or repurchase of securities by us or any of our subsidiaries. The 2019 Notes and 2023 Notes mature on July 1, 2019 and July 1, 2023, respectively. We cannot redeem either series of Notes prior to the applicable maturity date.

[0001327567-18-000031:notes:77]
Holders of the Notes may surrender their Notes for conversion at their option at any time prior to the close of business on the business day immediately preceding their respective convertible dates only under the following circumstances:

[0001327567-18-000031:notes:78]
| • | during any fiscal quarter commencing after the fiscal quarters ending on October 31, 2014 and October 31, 2018, for the 2019 Notes and 2023 Notes, respectively (and only during such fiscal quarter), if the last reported sale price of our common stock for at least 20 trading days (whether or not consecutive) during a period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the applicable conversion price for the respective Notes on each applicable trading day (the “sale price condition”); |

[0001327567-18-000031:notes:79]
| • | during the five business day period after any five consecutive trading day period (the “measurement period”) in which the trading price per $1,000 principal amount of the applicable series of Notes for each trading day of the measurement period was less than 98% of the product of the last reported sale price of our common stock and the applicable conversion rate for the respective Notes on each such trading day; or |

[0001327567-18-000031:notes:80]
| • | upon the occurrence of specified corporate events. |

[0001327567-18-000031:notes:81]
On or after the respective convertible date, holders may convert all or any portion of their Notes at any time prior to the close of business on the second scheduled trading day immediately preceding the applicable maturity date regardless of the foregoing conditions. Upon conversion, holders of the Notes of a series will receive cash equal to the aggregate principal amount of the Notes of such series to be converted, and, at our election, cash and/or shares of our common stock for any amounts in excess of the aggregate principal amount of the Notes of such series being converted.

[0001327567-18-000031:notes:82]
The conversion price will be subject to adjustment in some events. Holders of the Notes of a series who convert their Notes of such series in connection with certain corporate events that constitute a “make-whole fundamental change” under the applicable Indenture are, under certain circumstances, entitled to an increase in the conversion rate for such series of Notes. Additionally, upon the occurrence of a corporate event that constitutes a “fundamental change” under the applicable Indenture, holders of the Notes of such series may require us to repurchase for cash all or a portion of the Notes of such series at a repurchase price equal to 100% of the principal amount of the Notes of such series plus accrued and unpaid interest to, but excluding, the fundamental change repurchase date.

[0001327567-18-000031:notes:83]
The sale price condition was met for the 2019 Notes during the fiscal quarter ended July 31, 2018, and, as a result, holders were able to convert their 2019 Notes at any time during the fiscal quarter ended October 31, 2018. During the three months ended October 31, 2018, holders converted $327.3 million in aggregate principal amount of the 2019 Notes, which we repaid in cash. We also issued 1.4 million shares of our common stock to the holders for the conversion value in excess of the principal amount. These shares were fully offset by shares received from the corresponding exercise of the associated note hedges. We allocated $317.1 million of the cash consideration to the liability component of the converted 2019 Notes, which was calculated by measuring the fair value of a similar liability that did not have an associated convertible feature. We recorded a loss of $2.2 million related to the settlement of the 2019 Notes converted, which represented the difference between the cash consideration allocated to the liability component and the net carrying amount of the liability component on the respective settlement dates. The loss was included in other income, net in our condensed consolidated statement of operations for the three months ended October 31, 2018. During the three months ended October 31, 2018, we also recorded a $10.2 million net reduction to additional paid-in capital in our condensed consolidated balance sheets, reflecting the portion of the cash consideration allocated to the equity component.

[0001327567-18-000031:notes:84]
The sale price condition continued to be met through the fiscal quarter ended October 31, 2018, and, as a result, holders may convert their 2019 Notes at any time prior to January 1, 2019 (the “2019 Notes Convertible Date”). On or after the 2019 Notes Convertible Date, holders may convert their 2019 Notes at any time prior to maturity, in accordance with the terms described above, regardless of the sale price condition. Accordingly, the net carrying amount of the 2019 Notes was classified as a current liability and the portion of the equity component representing the conversion option was classified as temporary equity in our condensed consolidated balance sheets as of October 31, 2018.

[0001327567-18-000031:notes:85]
The sale price condition was not met for the 2023 Notes during the fiscal quarters ended October 31, 2018 and July 31, 2018. Since the 2023 Notes were not convertible, the net carrying amount of the 2023 Notes was classified as a long-term liability and the equity component was included in additional paid-in capital in our condensed consolidated balance sheets as of October 31, 2018.

[0001327567-18-000031:notes:86]
As of October 31, 2018, $247.7 million in aggregate principal amount of the 2019 Notes remained outstanding and all of the 2023 Notes remained outstanding. Subsequent to October 31, 2018, through the filing date of this Quarterly Report on Form 10-Q, $88.3 million in principal amount of the 2019 Notes was converted or had been submitted by the holders for conversion and will settle during the fiscal quarter ending January 31, 2019.

[0001327567-18-000031:notes:87]
The total estimated fair value of the Notes was $2.1 billion and $2.7 billion at October 31, 2018 and July 31, 2018, respectively. The fair value was determined based on the closing trading price per $100 of the Notes as of the last day of trading for the period. We consider the fair value of the Notes at October 31, 2018 and July 31, 2018 to be a Level 2 measurement. The fair value of the Notes is primarily affected by the trading price of our common stock and market interest rates. As of October 31, 2018, the if-converted value of the 2019 Notes exceeded its principal amount by $220.2 million. Based on the closing price of our common stock on October 31, 2018, the if-converted value of the 2023 Notes was less than its principal amount.

[0001327567-18-000031:notes:88]
The following table sets forth interest expense recognized related to the Notes (dollars in millions):

[0001327567-18-000031:notes:89]
|  | Three Months Ended |  | Three Months Ended |
|  | October 31, 2018 |  | October 31, 2017 |
|  | 2019 Notes |  | 2023 Notes |  | Total |  | 2019 Notes |  | 2023 Notes |  | Total |
| Contractual interest expense | $ | — |  |  | $ | 3.2 |  |  | $ | 3.2 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Amortization of debt discount | 4.0 |  |  | 14.4 |  |  | 18.4 |  |  | 5.6 |  |  | — |  |  | 5.6 |  |
| Amortization of debt issuance costs | 0.5 |  |  | 0.5 |  |  | 1.0 |  |  | 0.7 |  |  | — |  |  | 0.7 |  |
| Total interest expense recognized | $ | 4.5 |  |  | $ | 18.1 |  |  | $ | 22.6 |  |  | $ | 6.3 |  |  | $ | — |  |  | $ | 6.3 |  |
| Effective interest rate of the liability component | 4.8 | % |  | 5.2 | % |  |  |  | 4.8 | % |  | — | % |  |  |

[0001327567-18-000031:notes:90]
Note Hedges

[0001327567-18-000031:notes:91]
To minimize the impact of potential economic dilution upon conversion of the Notes, we entered into separate convertible note hedge transactions (the “2019 Note Hedges,” with respect to the 2019 Notes, and the “2023 Note Hedges,” with respect to the 2023 Notes, and collectively, the “Note Hedges”) with respect to our common stock concurrent with the issuance of each series of Notes.

[0001327567-18-000031:notes:92]
The Note Hedges cover shares of our common stock at a strike price per share that corresponds to the initial applicable conversion price of the applicable series of Notes, which are also subject to adjustment, and are exercisable upon conversion of the applicable series of Notes. The Note Hedges will expire upon maturity of the applicable series of Notes. The Note Hedges are separate transactions and are not part of the terms of the applicable series of the Notes. Holders of the Notes of either series will not have any rights with respect to the Note Hedges. Any shares of our common stock receivable by us under the Note Hedges are excluded from the calculation of diluted earnings per share as they are antidilutive. The aggregate amounts paid for the Note Hedges are included in additional paid-in capital in our consolidated balance sheets.

[0001327567-18-000031:notes:93]
As a result of the conversions of the 2019 Notes settled during the fiscal quarter ended October 31, 2018, we exercised the corresponding portion of our 2019 Note Hedges and received 1.4 million shares of common stock during the period.

[0001327567-18-000031:notes:94]
Warrants

[0001327567-18-000031:notes:95]
Separately, but concurrently with the issuance of each series of Notes, we entered into transactions whereby we sold warrants (the “2019 Warrants,” with respect to the 2019 Notes, and the “2023 Warrants,” with respect to the 2023 Notes, and collectively, the “Warrants”) to acquire shares of our common stock, subject to anti-dilution adjustments. The 2019 Warrants and 2023 Warrants are exercisable beginning October 2019 and October 2023, respectively.

[0001327567-18-000031:notes:96]
The following table presents details of the Warrants (in millions, except per share data):

[0001327567-18-000031:notes:97]
|  | Initial Number of Shares |  | Strike Price per Share |  | Aggregate Proceeds |
| 2019 Warrants | 5.2 |  |  | $ | 137.85 |  |  | $ | 78.3 |  |
| 2023 Warrants | 6.4 |  |  | $ | 417.80 |  |  | $ | 145.4 |  |

[0001327567-18-000031:notes:98]
The shares issuable under the Warrants will be included in the calculation of diluted earnings per share when the average market value per share of our common stock for the reporting period exceeds the applicable strike price for such series of Warrants. The Warrants are separate transactions and are not part of either series of Notes or Note Hedges and are not remeasured through earnings each reporting period. Holders of the Notes of either series will not have any rights with respect to the Warrants. The aggregate proceeds received from the sale of the Warrants are included in additional paid-in capital in our consolidated balance sheets.

[0001327567-18-000031:notes:99]
Revolving Credit Facility

[0001327567-18-000031:notes:100]
On September 4, 2018, we entered into a credit agreement (the “Credit Agreement”) with certain institutional lenders that provides for a $400.0 million unsecured revolving credit facility (the “Credit Facility”), with an option to increase the amount of the Credit Facility by up to an additional $350.0 million, subject to certain conditions. The Credit Facility matures on the earlier of (i) September 4, 2023 and (ii) the date that is 91 days prior to the stated maturity of our 2023 Notes if (a) any of the 2023 Notes are still outstanding and (b) our unrestricted cash and cash equivalents are less than the then outstanding principal amount of our 2023 Notes plus $400.0 million.

[0001327567-18-000031:notes:101]
The borrowings under the Credit Facility bear interest, at our option, at a base rate plus a spread of 0.00% to 0.75%, or an adjusted LIBO rate plus a spread of 1.00% to 1.75%, in each case with such spread being determined based on our leverage ratio. We are obligated to pay an ongoing commitment fee on undrawn amounts at a rate of 0.125% to 0.250%, depending on our leverage ratio. As of October 31, 2018, there were no amounts outstanding and we were in compliance with all covenants under the Credit Agreement.


## us-gaap:DeferredChargesPolicyTextBlock

[0001327567-18-000031:notes:102]
Deferred Contract Costs

[0001327567-18-000031:notes:103]
We defer contract costs that are recoverable and incremental to obtaining customer sales contracts. Contract costs, which primarily consist of sales commissions, are amortized on a systematic basis that is consistent with the transfer to the customer of the goods or services to which the asset relates. Sales commissions paid for initial contracts are generally not commensurate with the commissions paid for renewal contracts, given the substantive difference in commission rates in proportion to their respective contract values. Sales commissions for initial contracts that are not commensurate are amortized over a benefit period of five years, consistent with the revenue recognition pattern of the performance obligations in the related contracts including expected renewals. The benefit period is determined by taking into consideration contract length, technology life, and other quantitative and qualitative factors. The expected renewals are estimated based on historical renewal trends. Sales commissions for initial contracts that are commensurate and sales commissions for renewal contracts are amortized over the related contractual period in proportion to the revenue recognized.

[0001327567-18-000031:notes:104]
We classify deferred contract costs as short-term or long-term based on when we expect to recognize the expense. Short-term deferred contract costs are included in prepaid expenses and other current assets and long-term deferred contract costs are included in other assets in our condensed consolidated balance sheets. Deferred contract costs are periodically reviewed for impairment. The amortization of deferred contract costs is included in sales and marketing expense in our condensed consolidated statements of operations.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001327567-18-000031:notes:105]
[same as prior period, unchanged from 0001327567-18-000014:notes:88]

[0001327567-18-000031:notes:106]
As a global business, we are exposed to currency exchange rate risk. Substantially all of our revenue is transacted in U.S. dollars, however, a portion of our operating expenditures are incurred outside of the United States and are denominated in foreign currencies, making them subject to fluctuations in foreign currency exchange rates. We enter into foreign currency derivative contracts with maturities of 12 months or less which we designate as cash flow hedges to manage the foreign currency exchange rate risk associated with these expenditures.

[0001327567-18-000031:notes:107]
[same as prior period, unchanged from 0001327567-18-000014:notes:90]

[0001327567-18-000031:notes:108]
[same as prior period, unchanged from 0001327567-18-000014:notes:91]

[0001327567-18-000031:notes:109]
As of October 31, 2018 and July 31, 2018, the total notional amount of our outstanding foreign currency forward contracts was $238.0 million and $288.5 million, respectively. Refer to Note 3. Fair Value Measurements for the fair value of our derivative instruments as reported in our condensed consolidated balance sheets as of October 31, 2018.

[0001327567-18-000031:notes:110]
During the three months ended October 31, 2018 and 2017, both unrealized gains and losses recognized in AOCI related to our cash flow hedges and amounts reclassified into earnings were not material. Unrealized losses in AOCI related to our cash flow hedges as of October 31, 2018 and 2017 were not material.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001327567-18-000031:notes:111]
[same as prior period, unchanged from 0001327567-18-000014:notes:94]

[0001327567-18-000031:notes:112]
Share-Based Compensation Plans

[0001327567-18-000031:notes:113]
RedLock Inc. 2015 Stock Plan

[0001327567-18-000031:notes:114]
In connection with our acquisition of RedLock on October 12, 2018, we assumed RedLock’s 2015 Stock Plan, as amended (the “RedLock Plan”), under which the assumed RedLock equity awards were granted. The assumed equity awards will be settled in shares of our common stock and will retain the terms and conditions under which they were originally granted; forfeited awards will not be returned to the RedLock Plan. No additional equity awards will be granted under the RedLock Plan. Refer to Note 6. Acquisitions for more information on the RedLock acquisition and the related equity awards assumed.

[0001327567-18-000031:notes:115]
[same as prior period, unchanged from 0001327567-18-000014:notes:97]

[0001327567-18-000031:notes:116]
The following table summarizes the stock option and performance stock option (“PSO”) activity under our stock plans during the reporting period (in millions, except per share amounts):

[0001327567-18-000031:notes:117]
|  | Stock Options Outstanding |  | PSOs Outstanding |
|  | Number of Shares |  | Weighted-Average Exercise Price Per Share |  | Weighted-Average Remaining Contractual Term(Years) |  | Aggregate Intrinsic Value |  | Number of Shares |  | Weighted-Average Exercise Price Per Share |  | Weighted-Average Remaining Contractual Term(Years) |  | Aggregate Intrinsic Value |
| Balance—July 31, 2018 | 1.1 |  |  | $ | 13.29 |  |  | 3.1 |  | $ | 199.8 |  |  | 1.1 |  |  | $ | 198.50 |  |  | 7.0 |  | $ | — |  |
| Granted | — |  |  | $ | — |  |  |  |  |  |  | 2.2 |  |  | $ | 193.51 |  |  |  |  |  |
| Exercised | (0.2 | ) |  | $ | 13.51 |  |  |  |  |  |  | — |  |  | $ | — |  |  |  |  |  |
| Forfeited | — |  |  | $ | — |  |  |  |  |  |  | — |  |  | $ | — |  |  |  |  |  |
| Balance—October 31, 2018 | 0.9 |  |  | $ | 13.23 |  |  | 2.9 |  | $ | 150.7 |  |  | 3.3 |  |  | $ | 195.24 |  |  | 7.0 |  | $ | — |  |
| Exercisable—October 31, 2018 | 0.9 |  |  | $ | 13.23 |  |  | 2.9 |  | $ | 150.7 |  |  | — |  |  | $ | — |  |  | 0.0 |  | $ | — |  |

[0001327567-18-000031:notes:118]
In October 2018, we granted 2.2 million PSOs with both a market condition and a service condition to certain executives. The market condition requires the price of our common stock to equal or exceed $297.75, $397.00, $496.25, and $595.50 (the “stock price targets”) during the four-, five-, six-, and seven-year periods following the date of grant, respectively. To the extent that the stock price targets have been met, one-fourth of the PSOs will vest on the anniversary date of the grant date for such PSOs, subject to continued service.

[0001327567-18-000031:notes:119]
The aggregate fair value of the PSOs granted in October 2018 was $130.0 million based on a weighted-average fair value of $59.64 per share, which was estimated on the grant date using a Monte Carlo simulation model and the following assumptions: expected volatility of 35.6%, based on a combination of implied volatility from traded options on our common stock and the historical volatility of our common stock; dividend yield of 0.0%, based on our current expectations about our anticipated dividend policy; risk-free interest rates ranging from 3.1% to 3.2%, based on the implied yield available on U.S. Treasury zero-coupon issues with terms equal to the contractual terms of each tranche; and an expected term which takes into consideration the vesting term and the contractual term of the PSOs. We recognize share-based compensation expense for our PSOs on a straight-line basis over the requisite service period for each separately vesting portion of the award.

[0001327567-18-000031:notes:120]
In November 2018, we granted PSOs and restricted stock units with a total value of $34.5 million to our newly appointed president.

[0001327567-18-000031:notes:121]
[same as prior period, unchanged from 0001327567-18-000014:notes:100]

[0001327567-18-000031:notes:122]
[same as prior period, unchanged from 0001327567-18-000014:notes:102]

[0001327567-18-000031:notes:123]
|  | RSAs and PSAs Outstanding |  | RSUs and PSUs Outstanding |
|  | Number of Shares |  | Weighted-Average Grant-Date Fair Value Per Share |  | Number of Shares |  | Weighted-Average Grant-Date Fair Value Per Share |  | Weighted-Average Remaining Contractual Term(Years) |  | Aggregate Intrinsic Value |
| Balance—July 31, 2018 | 0.3 |  |  | $ | 160.85 |  |  | 6.7 |  |  | $ | 160.20 |  |  | 1.6 |  | $ | 1,335.2 |  |
| Granted(1)(2) | — |  |  | $ | — |  |  | 1.6 |  |  | $ | 198.48 |  |  |  |  |  |
| Vested | (0.1 | ) |  | $ | 167.18 |  |  | (0.6 | ) |  | $ | 149.95 |  |  |  |  |  |
| Forfeited | — |  |  | $ | — |  |  | (0.2 | ) |  | $ | 156.39 |  |  |  |  |  |
| Balance—October 31, 2018 | 0.2 |  |  | $ | 157.84 |  |  | 7.5 |  |  | $ | 169.81 |  |  | 1.6 |  | $ | 1,367.9 |  |

[0001327567-18-000031:notes:124]
[same as prior period, unchanged from 0001327567-18-000014:notes:104]

[0001327567-18-000031:notes:125]
[same as prior period, unchanged from 0001327567-18-000014:notes:105]

[0001327567-18-000031:notes:126]
| (2) | Includes 0.2 million RSUs granted under the assumed RedLock Plan with a weighted-average grant-date fair value of $211.95 per share. |

[0001327567-18-000031:notes:127]
[same as prior period, unchanged from 0001327567-18-000014:notes:101]

[0001327567-18-000031:notes:128]
[same as prior period, unchanged from 0001327567-18-000014:notes:106]

[0001327567-18-000031:notes:129]
[same as prior period, unchanged from 0001327567-18-000014:notes:107]

[0001327567-18-000031:notes:130]
|  | Three Months Ended |
|  | October 31, |
|  | 2018 |  | 2017 |
| Cost of product revenue | $ | 1.6 |  |  | $ | 1.9 |  |
| Cost of subscription and support revenue | 17.5 |  |  | 15.9 |  |
| Research and development | 40.5 |  |  | 37.5 |  |
| Sales and marketing | 56.0 |  |  | 51.2 |  |
| General and administrative | 35.5 |  |  | 19.2 |  |
| Total share-based compensation | $ | 151.1 |  |  | $ | 125.7 |  |

[0001327567-18-000031:notes:131]
In connection with our acquisition of RedLock, we accelerated the vesting of certain equity awards and as a result, we recorded $14.2 million of share-based compensation within general and administrative expense during the three months ended October 31, 2018.

[0001327567-18-000031:notes:132]
As of October 31, 2018, total compensation cost related to unvested share-based awards not yet recognized was $1.4 billion. This cost is expected to be amortized over a weighted-average period of approximately 2.9 years. Future grants will increase the amount of compensation expense to be recorded in these periods.


## us-gaap:EarningsPerShareTextBlock

[0001327567-18-000031:notes:133]
[same as prior period, unchanged from 0001327567-18-000014:notes:110]

[0001327567-18-000031:notes:134]
[same as prior period, unchanged from 0001327567-18-000014:notes:111]

[0001327567-18-000031:notes:135]
[same as prior period, unchanged from 0001327567-18-000014:notes:112]

[0001327567-18-000031:notes:136]
|  | Three Months Ended |
|  | October 31, |
|  | 2018 |  | 2017 |
|  |  |  | (As Adjusted) |
| Net loss | $ | (38.3 | ) |  | $ | (63.2 | ) |
| Weighted-average shares used to compute net loss per share, basic and diluted | 93.8 |  |  | 90.9 |  |
| Net loss per share, basic and diluted | $ | (0.41 | ) |  | $ | (0.70 | ) |

[0001327567-18-000031:notes:137]
[same as prior period, unchanged from 0001327567-18-000014:notes:114]

[0001327567-18-000031:notes:138]
|  | Three Months Ended |
|  | October 31, |
|  | 2018 |  | 2017 |
| Convertible senior notes | 8.6 |  |  | 5.2 |  |
| Warrants related to the issuance of convertible senior notes | 11.6 |  |  | 5.2 |  |
| RSUs and PSUs | 7.5 |  |  | 7.3 |  |
| Options to purchase common stock, including PSOs | 4.2 |  |  | 1.5 |  |
| RSAs and PSAs | 0.2 |  |  | 0.8 |  |
| ESPP shares | 0.1 |  |  | 0.1 |  |
| Total | 32.2 |  |  | 20.1 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001327567-18-000031:notes:139]
[same as prior period, unchanged from 0001327567-18-000014:notes:116]

[0001327567-18-000031:notes:140]
[same as prior period, unchanged from 0001327567-18-000014:notes:117]

[0001327567-18-000031:notes:141]
[same as prior period, unchanged from 0001327567-18-000014:notes:118]

[0001327567-18-000031:notes:142]
[same as prior period, unchanged from 0001327567-18-000014:notes:119]

[0001327567-18-000031:notes:143]
[same as prior period, unchanged from 0001327567-18-000014:notes:120]

[0001327567-18-000031:notes:144]
The following table presents the fair value of our financial assets and liabilities measured at fair value on a recurring basis using the above input categories as of October 31, 2018 and July 31, 2018 (in millions):

[0001327567-18-000031:notes:145]
|  |  | October 31, 2018 |  | July 31, 2018 |
|  |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Cash equivalents: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 904.4 |  |  | $ | — |  |  | $ | — |  |  | $ | 904.4 |  |  | $ | 1,512.3 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,512.3 |  |
| Commercial paper |  | — |  |  | 5.0 |  |  | — |  |  | 5.0 |  |  | — |  |  | 52.0 |  |  | — |  |  | 52.0 |  |
| Corporate debt securities |  | — |  |  | 2.5 |  |  | — |  |  | 2.5 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| U.S. government and agency securities |  | — |  |  | 210.3 |  |  | — |  |  | 210.3 |  |  | — |  |  | 397.3 |  |  | — |  |  | 397.3 |  |
| Total cash equivalents |  | 904.4 |  |  | 217.8 |  |  | — |  |  | 1,122.2 |  |  | 1,512.3 |  |  | 449.3 |  |  | — |  |  | 1,961.6 |  |
| Short-term investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Certificates of deposit |  | — |  |  | 5.4 |  |  | — |  |  | 5.4 |  |  | — |  |  | 5.4 |  |  | — |  |  | 5.4 |  |
| Non-U.S. government securities |  | — |  |  | 20.0 |  |  | — |  |  | 20.0 |  |  | — |  |  | 20.0 |  |  | — |  |  | 20.0 |  |
| Commercial paper |  | — |  |  | 97.3 |  |  | — |  |  | 97.3 |  |  | — |  |  | 22.3 |  |  | — |  |  | 22.3 |  |
| Corporate debt securities |  | — |  |  | 188.9 |  |  | — |  |  | 188.9 |  |  | — |  |  | 139.8 |  |  | — |  |  | 139.8 |  |
| U.S. government and agency securities |  | — |  |  | 1,107.8 |  |  | — |  |  | 1,107.8 |  |  | — |  |  | 709.0 |  |  | — |  |  | 709.0 |  |
| Total short-term investments |  | — |  |  | 1,419.4 |  |  | — |  |  | 1,419.4 |  |  | — |  |  | 896.5 |  |  | — |  |  | 896.5 |  |
| Long-term investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate debt securities |  | — |  |  | 191.2 |  |  | — |  |  | 191.2 |  |  | — |  |  | 153.6 |  |  | — |  |  | 153.6 |  |
| U.S. government and agency securities |  | — |  |  | 374.3 |  |  | — |  |  | 374.3 |  |  | — |  |  | 393.9 |  |  | — |  |  | 393.9 |  |
| Total long-term investments |  | — |  |  | 565.5 |  |  | — |  |  | 565.5 |  |  | — |  |  | 547.5 |  |  | — |  |  | 547.5 |  |
| Total assets measured at fair value |  | $ | 904.4 |  |  | $ | 2,202.7 |  |  | $ | — |  |  | $ | 3,107.1 |  |  | $ | 1,512.3 |  |  | $ | 1,893.3 |  |  | $ | — |  |  | $ | 3,405.6 |  |
| Accrued and other liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency forward contracts |  | $ | — |  |  | $ | 11.4 |  |  | $ | — |  |  | $ | 11.4 |  |  | $ | — |  |  | $ | 6.9 |  |  | $ | — |  |  | $ | 6.9 |  |
| Total accrued and other liabilities |  | — |  |  | 11.4 |  |  | — |  |  | 11.4 |  |  | — |  |  | 6.9 |  |  | — |  |  | 6.9 |  |
| Total liabilities measured at fair value |  | $ | — |  |  | $ | 11.4 |  |  | $ | — |  |  | $ | 11.4 |  |  | $ | — |  |  | $ | 6.9 |  |  | $ | — |  |  | $ | 6.9 |  |

[0001327567-18-000031:notes:146]
Refer to Note 9. Debt for the carrying amount and estimated fair value of our convertible senior notes as of October 31, 2018 and July 31, 2018.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001327567-18-000031:notes:147]
[same as prior period, unchanged from 0001327567-18-000014:notes:125]

[0001327567-18-000031:notes:148]
[same as prior period, unchanged from 0001327567-18-000014:notes:126]

[0001327567-18-000031:notes:149]
The following table presents details of our goodwill during the three months ended October 31, 2018 (in millions):

[0001327567-18-000031:notes:150]
|  | Amount |
| Balance as of July 31, 2018 | $ | 522.8 |  |
| Goodwill acquired | 113.6 |  |
| Balance as of October 31, 2018 | $ | 636.4 |  |

[0001327567-18-000031:notes:151]
[same as prior period, unchanged from 0001327567-18-000014:notes:129]

[0001327567-18-000031:notes:152]
The following table presents details of our purchased intangible assets as of October 31, 2018 and July 31, 2018 (in millions):

[0001327567-18-000031:notes:153]
|  | October 31, 2018 |  | July 31, 2018 |
|  | Gross Carrying Amount |  | Accumulated Amortization |  | Net Carrying Amount |  | Gross Carrying Amount |  | Accumulated Amortization |  | Net Carrying Amount |
| Intangible assets subject to amortization: |  |  |  |  |  |  |  |  |  |  |  |
| Developed technology | $ | 203.3 |  |  | $ | (45.3 | ) |  | $ | 158.0 |  |  | $ | 154.7 |  |  | $ | (38.2 | ) |  | $ | 116.5 |  |
| Customer relationships | 17.5 |  |  | (1.7 | ) |  | 15.8 |  |  | 12.2 |  |  | (1.2 | ) |  | 11.0 |  |
| Acquired intellectual property | 8.9 |  |  | (4.7 | ) |  | 4.2 |  |  | 8.9 |  |  | (4.5 | ) |  | 4.4 |  |
| Trade name and trademarks | 9.4 |  |  | (2.0 | ) |  | 7.4 |  |  | 8.5 |  |  | (0.4 | ) |  | 8.1 |  |
| Other | 2.2 |  |  | (2.2 | ) |  | — |  |  | 2.2 |  |  | (2.2 | ) |  | — |  |
| Total intangible assets subject to amortization | 241.3 |  |  | (55.9 | ) |  | 185.4 |  |  | 186.5 |  |  | (46.5 | ) |  | 140.0 |  |
| Intangible assets not subject to amortization: |  |  |  |  |  |  |  |  |  |  |  |
| In-process research and development | 0.8 |  |  | — |  |  | 0.8 |  |  | 0.8 |  |  | — |  |  | 0.8 |  |
| Total purchased intangible assets | $ | 242.1 |  |  | $ | (55.9 | ) |  | $ | 186.2 |  |  | $ | 187.3 |  |  | $ | (46.5 | ) |  | $ | 140.8 |  |

[0001327567-18-000031:notes:154]
We recognized amortization expense of $9.4 million and $2.7 million for the three months ended October 31, 2018 and 2017, respectively.

[0001327567-18-000031:notes:155]
The following table summarizes estimated future amortization expense of our intangible assets as of October 31, 2018 (in millions):

[0001327567-18-000031:notes:156]
|  | Amount |
| Fiscal years ending July 31: |  |
| Remaining 2019 | $ | 37.1 |  |
| 2020 | 39.4 |  |
| 2021 | 37.4 |  |
| 2022 | 32.9 |  |
| 2023 | 20.4 |  |
| 2024 and thereafter | 18.2 |  |
| Total future amortization expense | $ | 185.4 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001327567-18-000031:notes:157]
[same as prior period, unchanged from 0001327567-18-000014:notes:135]

[0001327567-18-000031:notes:158]
Our provision for income taxes for the three months ended October 31, 2018 reflects an effective tax rate of 8.4%. Our effective tax rate for the three months ended October 31, 2018 was positive as we recorded a benefit from income taxes on year to date losses. The key components of our income tax provision, excluding one-time items, primarily consist of foreign income taxes and withholding taxes. During the three months ended October 31, 2018, the effect of these key components were offset by a one-time tax benefit of $9.4 million from a partial release of our valuation allowance related to the acquisition of RedLock Inc. Our effective tax rate differs from the U.S. statutory tax rate primarily due to deductibility of our share-based compensation, foreign income at other than U.S. tax rates, and changes in our valuation allowance.

[0001327567-18-000031:notes:159]
Our provision for income taxes for the three months ended October 31, 2017 reflects an effective tax rate of (14.9)%. Our effective tax rate for this period was negative as we recorded a provision for income taxes on year to date losses. The key components of our income tax provision primarily consisted of foreign income taxes, withholding taxes, and amortization of our deferred tax charges. Our effective tax rate differed from the U.S. statutory tax rate primarily due to changes in non-deductible share-based compensation, foreign income at other than U.S. tax rates, and charges in our valuation allowance.

[0001327567-18-000031:notes:160]
In December 2017, the Tax Cuts and Jobs Act (“TCJA”) was enacted into law. The SEC staff and FASB previously issued guidance that allows companies to record provisional amounts for the effects of the TCJA during a measurement period not to extend beyond one year from the enactment date. As of October 31, 2018, we did not have any significant adjustments to our assessment performed as of July 31, 2018. We continue to analyze the tax effects of the TCJA, which are still subject to change during the measurement period, and anticipate further guidance on accounting interpretations from the FASB and application of the TCJA from the U.S. federal and state tax authorities.


## us-gaap:InvestmentsClassifiedByContractualMaturityDateTableTextBlock

[0001327567-18-000031:notes:161]
The following table summarizes the amortized cost and fair value of our available-for-sale securities as of October 31, 2018, by contractual years-to-maturity (in millions):

[0001327567-18-000031:notes:162]
|  | Amortized Cost |  | Fair Value |
| Due within one year | $ | 1,640.9 |  |  | $ | 1,637.2 |  |
| Due between one and three years | 571.1 |  |  | 565.5 |  |
| Total | $ | 2,212.0 |  |  | $ | 2,202.7 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001327567-18-000031:notes:163]
Cash Equivalents and Investments

[0001327567-18-000031:notes:164]
Available-for-sale Securities

[0001327567-18-000031:notes:165]
Unrealized losses related to these securities are due to interest rate fluctuations as opposed to credit quality. In addition, we do not intend to sell and it is not likely that we would be required to sell these securities before recovery of their amortized cost basis, which may be at maturity. As a result, there were no other-than-temporary impairments for these securities at October 31, 2018 and July 31, 2018.

[0001327567-18-000031:notes:166]
Marketable Equity Securities

[0001327567-18-000031:notes:167]
Marketable equity securities consist of money market funds and are included in cash and cash equivalents in our condensed consolidated balance sheets. As of October 31, 2018 and July 31, 2018, the carrying value of our marketable equity securities were $904.4 million and $1.5 billion, respectively. During the three months ended October 31, 2018 and 2017, there were no unrealized gains or losses recognized for these securities.


## us-gaap:OtherNonoperatingIncomeAndExpenseTextBlock

[0001327567-18-000031:notes:168]
Other Income, Net

[0001327567-18-000031:notes:169]
The following table sets forth the components of other income, net (in millions):

[0001327567-18-000031:notes:170]
|  | Three Months Ended |
|  | October 31, |
|  | 2018 |  | 2017 |
| Interest income | $ | 15.4 |  |  | $ | 5.1 |  |
| Foreign currency exchange gains (losses), net | — |  |  | (0.6 | ) |
| Other | (2.4 | ) |  | 0.3 |  |
| Total other income, net | $ | 13.0 |  |  | $ | 4.8 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001327567-18-000031:notes:171]
Revenue

[0001327567-18-000031:notes:172]
Our revenue consists of product revenue and subscription and support revenue. Revenue is recognized when control of promised products, subscriptions and support services are transferred to customers with the expected consideration in exchange for those products and services. Depending on who the contract is with, our customers are either our channel partners or our end-customers.

[0001327567-18-000031:notes:173]
We determine revenue recognition through the following steps:

[0001327567-18-000031:notes:174]
| • | Identification of the contract, or contracts, with a customer. |

[0001327567-18-000031:notes:175]
| • | Identification of the performance obligations in the contract. |

[0001327567-18-000031:notes:176]
| • | Determination of the transaction price. |

[0001327567-18-000031:notes:177]
| • | Allocation of the transaction price to the performance obligations in the contract. |

[0001327567-18-000031:notes:178]
| • | Recognition of revenue when, or as, we satisfy a performance obligation. |

[0001327567-18-000031:notes:179]
Revenues are reported net of sales taxes. Shipping charges billed to channel partners are included in revenues and related costs are included in cost of revenue.

[0001327567-18-000031:notes:180]
Product Revenue

[0001327567-18-000031:notes:181]
Product revenue is derived primarily from sales of our appliances. Product revenue also includes revenue derived from software licenses of Panorama and the VM-Series. We recognize product revenue at the time of hardware shipment or delivery of software license.

[0001327567-18-000031:notes:182]
Subscription and Support Revenue

[0001327567-18-000031:notes:183]
Subscription and support revenue is derived primarily from sales of our subscription and support offerings. We recognize subscription and support revenue over time as the services are performed. Our contractual subscription and support contracts are typically one to five years.

[0001327567-18-000031:notes:184]
Contracts with Multiple Performance Obligations

[0001327567-18-000031:notes:185]
The majority of our contracts with our customers include various combinations of our products and subscriptions and support which are distinct and accounted for as separate performance obligations. We account for multiple agreements with a single customer as a single contract if the contractual terms and/or substance of those agreements indicate that they may be so closely related that they are, in effect, parts of a single contract. The amount of consideration we expect to receive in exchange for delivering on the contract is allocated to each performance obligation based on its relative standalone selling price. If a contract contains a single performance obligation, no allocation is required.

[0001327567-18-000031:notes:186]
We establish standalone selling price using the prices charged for a deliverable when sold separately. If the standalone selling price is not observable through past transactions, we estimate the standalone selling price based on our pricing model and our go-to-market strategy, which include factors such as type of sales channel (reseller, distributor, or end-customer), the geographies in which our offerings were sold (domestic or international), and offering type (products, subscriptions, or support).

[0001327567-18-000031:notes:187]
Deferred Revenue

[0001327567-18-000031:notes:188]
We record deferred revenue when cash payments are received or due in advance of our performance. Our payment terms typically require payment within 30 to 45 days of the date we issue an invoice. The current portion of deferred revenue represents the amounts that are expected to be recognized as revenue within one year of the condensed consolidated balance sheet date. During the three months ended October 31, 2018, we recognized approximately $370.0 million of revenue pertaining to amounts that were deferred as of July 31, 2018.

[0001327567-18-000031:notes:189]
Remaining Performance Obligations

[0001327567-18-000031:notes:190]
Revenue expected to be recognized from remaining performance obligations was $2.5 billion as of October 31, 2018, of which we expect to recognize approximately $1.3 billion over the next 12 months and the remainder thereafter.

[0001327567-18-000031:notes:191]
Disaggregation of Revenue

[0001327567-18-000031:notes:192]
The following table presents revenue by geographic theater (in millions):

[0001327567-18-000031:notes:193]
|  | Three Months Ended October 31, |
|  | 2018 |  | 2017 |
|  |  |  | (As Adjusted) |
| Revenue: |  |  |  |
| Americas |  |  |  |
| United States | $ | 415.9 |  |  | $ | 326.0 |  |
| Other Americas | 34.3 |  |  | 23.3 |  |
| Total Americas | 450.2 |  |  | 349.3 |  |
| Europe, the Middle East, and Africa (“EMEA”) | 127.7 |  |  | 94.7 |  |
| Asia Pacific and Japan (“APAC”) | 78.1 |  |  | 57.8 |  |
| Total revenue | $ | 656.0 |  |  | $ | 501.8 |  |

[0001327567-18-000031:notes:194]
The following table presents revenue for groups of similar products and services (in millions):

[0001327567-18-000031:notes:195]
|  | Three Months Ended October 31, |
|  | 2018 |  | 2017 |
|  |  |  | (As Adjusted) |
| Revenue: |  |  |  |
| Product | $ | 240.5 |  |  | $ | 184.8 |  |
| Subscription and support |  |  |  |
| Subscription | 231.3 |  |  | 169.0 |  |
| Support | 184.2 |  |  | 148.0 |  |
| Total subscription and support | 415.5 |  |  | 317.0 |  |
| Total revenue | $ | 656.0 |  |  | $ | 501.8 |  |

[0001327567-18-000031:notes:196]
We recognized amortization expense for our deferred contract costs of $41.1 million and $28.1 million during the three months ended October 31, 2018 and 2017, respectively. We did not recognize any impairment losses on our deferred contract costs during the three months ended October 31, 2018 or 2017.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001327567-18-000031:notes:197]
[same as prior period, unchanged from 0001327567-18-000014:notes:146]

[0001327567-18-000031:notes:198]
Share Repurchase Program

[0001327567-18-000031:notes:199]
In August 2016, our board of directors authorized a $500.0 million share repurchase program that is funded from available working capital. In February 2017, our board of directors authorized a $500.0 million increase to our repurchase program, bringing the total authorization to $1.0 billion. Repurchases may be made at management’s discretion from time to time on the open market, through privately negotiated transactions, transactions structured through investment banking institutions, block purchase techniques, 10b5-1 trading plans, or a combination of the foregoing. The repurchase authorization will expire on December 31, 2018 and may be suspended or discontinued at any time.

[0001327567-18-000031:notes:200]
There were no shares repurchased under the authorization during the three months ended October 31, 2018. As of October 31, 2018, $330.0 million remained available for future share repurchases under the repurchase authorization.
