# PANW MD&A — 0001327567-18-000031


## mdna

[0001327567-18-000031:mdna:1]
[same as prior period, unchanged from 0001327567-18-000014:mdna:1]

[0001327567-18-000031:mdna:2]
[same as prior period, unchanged from 0001327567-18-000014:mdna:2]

[0001327567-18-000031:mdna:3]
[same as prior period, unchanged from 0001327567-18-000014:mdna:3]

[0001327567-18-000031:mdna:4]
[same as prior period, unchanged from 0001327567-18-000014:mdna:4]

[0001327567-18-000031:mdna:5]
| • | Results of Operations. A discussion of the nature and trends in our financial results and an analysis of our financial results comparing the three months ended October 31, 2018 to the three months ended October 31, 2017. |

[0001327567-18-000031:mdna:6]
[same as prior period, unchanged from 0001327567-18-000014:mdna:6]

[0001327567-18-000031:mdna:7]
| • | Contractual Obligations and Commitments. An overview of our contractual obligations, contingent liabilities, commitments, and off-balance sheet arrangements outstanding as of October 31, 2018, including expected payment schedules. |

[0001327567-18-000031:mdna:8]
[same as prior period, unchanged from 0001327567-18-000014:mdna:8]

[0001327567-18-000031:mdna:9]
[same as prior period, unchanged from 0001327567-18-000014:mdna:42]

[0001327567-18-000031:mdna:10]
[same as prior period, unchanged from 0001327567-18-000014:mdna:9]

[0001327567-18-000031:mdna:11]
[same as prior period, unchanged from 0001327567-18-000014:mdna:10]

[0001327567-18-000031:mdna:12]
We have pioneered the next generation of security through our innovative Security Operating Platform that empowers enterprises, service providers, and government entities to secure their organizations by safely enabling applications and data running in their networks, on their endpoints, and in the cloud, and by preventing breaches that stem from targeted cyberattacks. Our platform uses an innovative traffic classification engine that identifies network traffic by application, user, and content and provides consistent security across the network, endpoint, and cloud. Accordingly, our platform enables our end-customers to pursue transformative digital initiatives, like public cloud and mobility, that grow their business, while maintaining the visibility and control needed to protect their valued data and critical control systems. We believe the architecture of our platform offers superior performance compared to legacy approaches and reduces the total cost of ownership for organizations by simplifying their security operations and infrastructure and eliminating the need for multiple, stand-alone hardware and software security products, and consists of four primary security capabilities.

[0001327567-18-000031:mdna:13]
[same as prior period, unchanged from 0001327567-18-000014:mdna:14]

[0001327567-18-000031:mdna:14]
[same as prior period, unchanged from 0001327567-18-000014:mdna:15]

[0001327567-18-000031:mdna:15]
[same as prior period, unchanged from 0001327567-18-000014:mdna:16]

[0001327567-18-000031:mdna:16]
| • | Other security services, such as WildFire, Threat Prevention, URL Filtering, and GlobalProtect subscriptions that are delivered as attached software services to our appliances, as well as applications delivered in connection with our Application Framework, such as AutoFocus, Magnifier, and Logging Service that are delivered as SaaS applications. |

[0001327567-18-000031:mdna:17]
For the first quarter of fiscal 2019 and 2018, total revenue was $656.0 million and $501.8 million, respectively, representing year-over-year growth of 30.7%. Our growth reflects the increased adoption of our hybrid SaaS revenue model, which consists of product, subscriptions, and support. We believe this model will enable us to benefit from recurring revenues as we continue to grow our installed end-customer base. As of October 31, 2018, we had end-customers in over 150 countries. Our end-customers represent a broad range of industries, including education, energy, financial services, government entities, healthcare, Internet and media, manufacturing, public sector, and telecommunications, and include some of the largest Fortune 100 and Global 2000 companies in the world. We maintain a field sales force that works closely with our channel partners in developing sales opportunities. We use a two-tiered, indirect fulfillment model whereby we sell our products, subscriptions, and support to our distributors, which, in turn, sell to our resellers, which then sell to our end-customers.

[0001327567-18-000031:mdna:18]
Our product revenue grew to $240.5 million, or 36.7% of total revenue, for the first quarter of fiscal 2019, representing year-over-year growth of 30.1%. Product revenue is generated from sales of our appliances, primarily our Next-Generation Firewall, which is available in physical and virtualized form. Our Next-Generation Firewall incorporates our proprietary PAN-OS operating system, which provides a consistent set of capabilities across our entire product line. Our products are designed for different performance requirements throughout an organization, ranging from our PA-200, which is designed for enterprise remote offices, to our top-of-the-line PA-7080, which is especially suited for very large enterprise deployments and service provider customers. The same firewall functionality that is delivered in our physical appliances is also available in our VM-Series virtual firewalls, which secure virtualized and cloud-based computing environments.

[0001327567-18-000031:mdna:19]
Our subscription and support revenue grew to $415.5 million, or 63.3% of total revenue, for the first quarter of fiscal 2019, representing year-over-year growth of 31.1%. Our subscriptions provide our end-customers with real-time access to the latest antivirus, intrusion prevention, web filtering, and modern malware prevention capabilities across the network, endpoints, and the cloud. When end-customers purchase our physical or virtual firewall appliances, they typically purchase support in order to receive ongoing security updates, upgrades, bug fixes, and repairs. In addition to the subscriptions purchased with these appliances, end-customers may also purchase other subscriptions on a per-user, per-endpoint, or capacity-based basis.

[0001327567-18-000031:mdna:20]
We continue to invest in innovation as we evolve and further extend the capabilities of our platform, as we believe that innovation and timely development of new features and products is essential to meeting the needs of our end-customers and improving our competitive position. For example, in October 2018, we acquired RedLock Inc. (“RedLock”), which expands our security capabilities for the public cloud with the addition of RedLock’s cloud security analytics technology.

[0001327567-18-000031:mdna:21]
We believe that the growth of our business and our short-term and long-term success are dependent upon many factors, including our ability to extend our technology leadership, grow our base of end-customers, expand deployment of our platform and

[0001327567-18-000031:mdna:22]
[same as prior period, unchanged from 0001327567-18-000014:mdna:49]

[0001327567-18-000031:mdna:23]
support offerings within existing end-customers, and focus on end-customer satisfaction. To manage any future growth effectively, we must continue to improve and expand our information technology and financial infrastructure, our operating and administrative systems and controls, and our ability to manage headcount, capital, and processes in an efficient manner. While these areas present significant opportunities for us, they also pose challenges and risks that we must successfully address in order to sustain the growth of our business and improve our operating results. For additional information regarding the challenges and risks we face, see the “Risk Factors” section in Part II, Item 1A of this Quarterly Report on Form 10-Q.

[0001327567-18-000031:mdna:24]
[same as prior period, unchanged from 0001327567-18-000014:mdna:31]

[0001327567-18-000031:mdna:25]
[same as prior period, unchanged from 0001327567-18-000014:mdna:32]

[0001327567-18-000031:mdna:26]
|  | October 31, 2018 |  | July 31, 2018 |
|  | (in millions) |
| Total deferred revenue(1) | $ | 2,384.4 |  |  | $ | 2,279.3 |  |
| Cash, cash equivalents, and investments | $ | 3,769.3 |  |  | $ | 3,950.9 |  |

[0001327567-18-000031:mdna:27]
[same as prior period, unchanged from 0001327567-18-000014:mdna:46]

[0001327567-18-000031:mdna:28]
| (1) | The amount for fiscal 2018 has been adjusted due to our adoption of the new revenue recognition standard. Refer to Note 1. Description of Business and Summary of Significant Accounting Policies in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information. |

[0001327567-18-000031:mdna:29]
|  | Three Months Ended October 31, |
|  | 2018 |  | 2017(1) |
|  | (dollars in millions) |
| Total revenue | $ | 656.0 |  |  | $ | 501.8 |  |
| Total revenue year-over-year percentage increase | 30.7 | % |  | 26.0 | % |
| Gross margin | 72.0 | % |  | 71.8 | % |
| Operating loss | $ | (32.1 | ) |  | $ | (53.5 | ) |
| Operating margin | (4.9 | )% |  | (10.7 | )% |
| Billings | $ | 758.5 |  |  | $ | 595.4 |  |
| Billings year-over-year percentage increase | 27.4 | % |  | 24.6 | % |
| Cash flow provided by operating activities | $ | 252.3 |  |  | $ | 274.0 |  |
| Free cash flow (non-GAAP) | $ | 218.0 |  |  | $ | 241.8 |  |

[0001327567-18-000031:mdna:30]
[same as prior period, unchanged from 0001327567-18-000014:mdna:107]

[0001327567-18-000031:mdna:31]
| (1) | These amounts have been adjusted due to our adoption of the new revenue recognition standard and new guidance related to the presentation of restricted cash and cash equivalents in the statement of cash flows. Refer to Note 1. Description of Business and Summary of Significant Accounting Policies in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information. |

[0001327567-18-000031:mdna:32]
[same as prior period, unchanged from 0001327567-18-000014:mdna:35]

[0001327567-18-000031:mdna:33]
| • | Billings. We define billings as total revenue plus the change in total deferred revenue, net of acquired deferred revenue, during the period. We consider billings to be a key metric used by management to manage our business given our hybrid SaaS revenue model, and believe billings provides investors with an important indicator of the health and visibility of our business because it includes subscription and support revenue, which is recognized ratably over the contractual service period, and product revenue, which is recognized at the time of shipment, provided that all other conditions for revenue recognition have been met. We consider billings to be a useful metric for management and investors, particularly if we continue to experience increased sales of subscriptions and strong renewal rates for subscription and support offerings, and as we monitor our near-term cash flows. While we believe that billings provides useful information to investors and others in understanding and evaluating our operating results in the same manner as our management, it is important to note that other companies, including companies in our industry, may not use billings, may calculate billings differently, |

[0001327567-18-000031:mdna:34]
[same as prior period, unchanged from 0001327567-18-000014:mdna:62]

[0001327567-18-000031:mdna:35]
may have different billing frequencies, or may use other financial measures to evaluate their performance, all of which could reduce the usefulness of billings as a comparative measure. We calculate billings in the following manner:

[0001327567-18-000031:mdna:36]
|  | Three Months Ended October 31, |
|  | 2018 |  | 2017(1) |
|  | (in millions) |
| Billings: |  |  |  |
| Total revenue | $ | 656.0 |  |  | $ | 501.8 |  |
| Add: change in total deferred revenue, net of acquired deferred revenue | 102.5 |  |  | 93.6 |  |
| Billings | $ | 758.5 |  |  | $ | 595.4 |  |

[0001327567-18-000031:mdna:37]
[same as prior period, unchanged from 0001327567-18-000014:mdna:130]

[0001327567-18-000031:mdna:38]
| (1) | These amounts have been adjusted due to our adoption of the new revenue recognition standard. Refer to Note 1. Description of Business and Summary of Significant Accounting Policies in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information. |

[0001327567-18-000031:mdna:39]
[same as prior period, unchanged from 0001327567-18-000014:mdna:39]

[0001327567-18-000031:mdna:40]
[same as prior period, unchanged from 0001327567-18-000014:mdna:40]

[0001327567-18-000031:mdna:41]
|  | Three Months Ended October 31, |
|  | 2018 |  | 2017 |
|  | (in millions) |
| Free cash flow (non-GAAP): |  |  |  |
| Net cash provided by operating activities(1) | $ | 252.3 |  |  | $ | 274.0 |  |
| Less: purchases of property, equipment, and other assets | 34.3 |  |  | 32.2 |  |
| Free cash flow (non-GAAP)(1) | $ | 218.0 |  |  | $ | 241.8 |  |
| Net cash used in investing activities | $ | (713.1 | ) |  | $ | (52.4 | ) |
| Net cash used in financing activities | $ | (261.8 | ) |  | $ | (123.4 | ) |

[0001327567-18-000031:mdna:42]
______________

[0001327567-18-000031:mdna:43]
| (1) | The amount for fiscal 2018 has been adjusted due to our adoption of new guidance related to the presentation of restricted cash and cash equivalents in the statement of cash flows. Refer to Note 1. Description of Business and Summary of Significant Accounting Policies in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information. |

[0001327567-18-000031:mdna:44]
[same as prior period, unchanged from 0001327567-18-000014:mdna:76]

[0001327567-18-000031:mdna:45]
[same as prior period, unchanged from 0001327567-18-000014:mdna:43]

[0001327567-18-000031:mdna:46]
[same as prior period, unchanged from 0001327567-18-000014:mdna:44]

[0001327567-18-000031:mdna:47]
|  | Three Months Ended October 31, |
|  | 2018 |  | 2017(1) |
|  | Amount |  | % of Revenue |  | Amount |  | % of Revenue |
|  | (dollars in millions) |
| Revenue: |  |  |  |  |  |  |  |
| Product | $ | 240.5 |  |  | 36.7 | % |  | $ | 184.8 |  |  | 36.8 | % |
| Subscription and support | 415.5 |  |  | 63.3 | % |  | 317.0 |  |  | 63.2 | % |
| Total revenue | 656.0 |  |  | 100.0 | % |  | 501.8 |  |  | 100.0 | % |
| Cost of revenue: |  |  |  |  |  |  |  |
| Product | 73.2 |  |  | 11.2 | % |  | 57.6 |  |  | 11.5 | % |
| Subscription and support | 110.3 |  |  | 16.8 | % |  | 83.7 |  |  | 16.7 | % |
| Total cost of revenue(2) | 183.5 |  |  | 28.0 | % |  | 141.3 |  |  | 28.2 | % |
| Total gross profit | 472.5 |  |  | 72.0 | % |  | 360.5 |  |  | 71.8 | % |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 113.4 |  |  | 17.3 | % |  | 94.2 |  |  | 18.8 | % |
| Sales and marketing | 314.6 |  |  | 47.9 | % |  | 254.1 |  |  | 50.6 | % |
| General and administrative | 76.6 |  |  | 11.7 | % |  | 65.7 |  |  | 13.1 | % |
| Total operating expenses(2) | 504.6 |  |  | 76.9 | % |  | 414.0 |  |  | 82.5 | % |
| Operating loss | (32.1 | ) |  | (4.9 | )% |  | (53.5 | ) |  | (10.7 | )% |
| Interest expense | (22.7 | ) |  | (3.5 | )% |  | (6.3 | ) |  | (1.3 | )% |
| Other income, net | 13.0 |  |  | 2.0 | % |  | 4.8 |  |  | 1.0 | % |
| Loss before income taxes | (41.8 | ) |  | (6.4 | )% |  | (55.0 | ) |  | (11.0 | )% |
| Provision for (benefit from) income taxes | (3.5 | ) |  | (0.6 | )% |  | 8.2 |  |  | 1.6 | % |
| Net loss | $ | (38.3 | ) |  | (5.8 | )% |  | $ | (63.2 | ) |  | (12.6 | )% |

[0001327567-18-000031:mdna:48]
______________

[0001327567-18-000031:mdna:49]
| (1) | Certain amounts have been adjusted due to our adoption of the new revenue recognition standard. Refer to Note 1. Description of Business and Summary of Significant Accounting Policies in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information. |

[0001327567-18-000031:mdna:50]
| (2) | Includes share-based compensation as follows: |

[0001327567-18-000031:mdna:51]
|  | Three Months Ended October 31, |
|  | 2018 |  | 2017 |
|  | (in millions) |
| Cost of product revenue | $ | 1.6 |  |  | $ | 1.9 |  |
| Cost of subscription and support revenue | 17.5 |  |  | 15.9 |  |
| Research and development | 40.5 |  |  | 37.5 |  |
| Sales and marketing | 56.0 |  |  | 51.2 |  |
| General and administrative | 35.5 |  |  | 19.2 |  |
| Total share-based compensation | $ | 151.1 |  |  | $ | 125.7 |  |

[0001327567-18-000031:mdna:52]
[same as prior period, unchanged from 0001327567-18-000014:mdna:87]

[0001327567-18-000031:mdna:53]
[same as prior period, unchanged from 0001327567-18-000014:mdna:50]

[0001327567-18-000031:mdna:54]
Our revenue consists of product revenue and subscription and support revenue. Revenue is recognized upon transfer of control of the corresponding promised products and subscriptions and support to our customers in an amount that reflects the consideration we expect to be entitled to in exchange for those products and subscriptions and support. We expect our revenue to vary from quarter to quarter based on seasonal and cyclical factors.

[0001327567-18-000031:mdna:55]
[same as prior period, unchanged from 0001327567-18-000014:mdna:52]

[0001327567-18-000031:mdna:56]
Product revenue is derived primarily from sales of our appliances. Product revenue also includes revenue derived from software licenses of Panorama and the VM-Series. We recognize product revenue at the time of hardware shipment or delivery of software license.

[0001327567-18-000031:mdna:57]
|  | Three Months Ended October 31, |  |  |  |  |
|  | 2018 |  | 2017(1) |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Product | $ | 240.5 |  |  | $ | 184.8 |  |  | $ | 55.7 |  |  | 30.1 | % |

[0001327567-18-000031:mdna:58]
______________

[0001327567-18-000031:mdna:59]
| (1) | This amount has been adjusted due to our adoption of the new revenue recognition standard. Refer to Note 1. Description of Business and Summary of Significant Accounting Policies in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information. |

[0001327567-18-000031:mdna:60]
Product revenue increased for the three months ended October 31, 2018 compared to the three months ended October 31, 2017 due to increased demand for our appliances. The change in product revenue due to pricing was not significant.

[0001327567-18-000031:mdna:61]
[same as prior period, unchanged from 0001327567-18-000014:mdna:56]

[0001327567-18-000031:mdna:62]
Subscription and support revenue is derived primarily from sales of our subscription and support offerings. Our contractual subscription and support contracts are typically one to five years. We recognize revenue from subscriptions and support over time as the services are performed. As a percentage of total revenue, we expect our subscription and support revenue to vary from quarter to quarter and increase over the long term as we introduce new subscriptions, renew existing subscription and support contracts, and expand our installed end-customer base.

[0001327567-18-000031:mdna:63]
|  | Three Months Ended October 31, |  |  |  |  |
|  | 2018 |  | 2017(1) |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Subscription | $ | 231.3 |  |  | $ | 169.0 |  |  | $ | 62.3 |  |  | 36.9 | % |
| Support | 184.2 |  |  | 148.0 |  |  | 36.2 |  |  | 24.5 | % |
| Total subscription and support | $ | 415.5 |  |  | $ | 317.0 |  |  | $ | 98.5 |  |  | 31.1 | % |

[0001327567-18-000031:mdna:64]
______________

[0001327567-18-000031:mdna:65]
| (1) | These amounts have been adjusted due to our adoption of the new revenue recognition standard. Refer to Note 1. Description of Business and Summary of Significant Accounting Policies in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information. |

[0001327567-18-000031:mdna:66]
Subscription and support revenue increased for the three months ended October 31, 2018 compared to the three months ended October 31, 2017. The increase was due to increased demand for our subscription and support offerings from both new and existing end-customers. The mix between subscription revenue and support revenue will fluctuate over time, depending on the introduction of new subscription offerings, renewals of support services, and our ability to increase sales to new and existing customers. The change in subscription and support revenue due to changes in pricing was not significant for either period.

[0001327567-18-000031:mdna:67]
[same as prior period, unchanged from 0001327567-18-000014:mdna:99]

[0001327567-18-000031:mdna:68]
[same as prior period, unchanged from 0001327567-18-000014:mdna:60]

[0001327567-18-000031:mdna:69]
|  | Three Months Ended October 31, |  |  |  |  |
|  | 2018 |  | 2017(1) |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Americas | $ | 450.2 |  |  | $ | 349.3 |  |  | $ | 100.9 |  |  | 28.9 | % |
| EMEA | 127.7 |  |  | 94.7 |  |  | 33.0 |  |  | 34.8 | % |
| APAC | 78.1 |  |  | 57.8 |  |  | 20.3 |  |  | 35.1 | % |
| Total revenue | $ | 656.0 |  |  | $ | 501.8 |  |  | $ | 154.2 |  |  | 30.7 | % |

[0001327567-18-000031:mdna:70]
______________

[0001327567-18-000031:mdna:71]
| (1) | These amounts have been adjusted due to our adoption of the new revenue recognition standard. Refer to Note 1. Description of Business and Summary of Significant Accounting Policies in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information. |

[0001327567-18-000031:mdna:72]
With respect to geographic theaters, the Americas contributed the largest portion of the increase in revenue for the three months ended October 31, 2018 compared to the three months ended October 31, 2017, due to its larger and more established sales force compared to our other theaters. Revenue from both Europe, the Middle East, and Africa (“EMEA”) and Asia Pacific and Japan (“APAC”) increased for the three months ended October 31, 2018 compared to the three months ended October 31, 2017, due to our investment in increasing the size of our sales force and number of channel partners in these theaters.

[0001327567-18-000031:mdna:73]
[same as prior period, unchanged from 0001327567-18-000014:mdna:64]

[0001327567-18-000031:mdna:74]
[same as prior period, unchanged from 0001327567-18-000014:mdna:65]

[0001327567-18-000031:mdna:75]
[same as prior period, unchanged from 0001327567-18-000014:mdna:66]

[0001327567-18-000031:mdna:76]
[same as prior period, unchanged from 0001327567-18-000014:mdna:67]

[0001327567-18-000031:mdna:77]
|  | Three Months Ended October 31, |  |  |  |  |
|  | 2018 |  | 2017 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Cost of product revenue | $ | 73.2 |  |  | $ | 57.6 |  |  | $ | 15.6 |  |  | 27.1 | % |
| Number of employees at period end | 97 |  |  | 98 |  |  | (1 | ) |  | (1.0 | )% |

[0001327567-18-000031:mdna:78]
Cost of product revenue increased for the three months ended October 31, 2018 compared to the three months ended October 31, 2017 primarily due to an increase in product unit volume.

[0001327567-18-000031:mdna:79]
[same as prior period, unchanged from 0001327567-18-000014:mdna:110]

[0001327567-18-000031:mdna:80]
[same as prior period, unchanged from 0001327567-18-000014:mdna:70]

[0001327567-18-000031:mdna:81]
[same as prior period, unchanged from 0001327567-18-000014:mdna:71]

[0001327567-18-000031:mdna:82]
|  | Three Months Ended October 31, |  |  |  |  |
|  | 2018 |  | 2017 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Cost of subscription and support revenue(1) | $ | 110.3 |  |  | $ | 83.7 |  |  | $ | 26.6 |  |  | 31.8 | % |
| Number of employees at period end | 985 |  |  | 778 |  |  | 207 |  |  | 26.6 | % |

[0001327567-18-000031:mdna:83]
______________

[0001327567-18-000031:mdna:84]
| (1) | The amount for fiscal 2018 has been adjusted due to our adoption of the new revenue recognition standard. Refer to Note 1. Description of Business and Summary of Significant Accounting Policies in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information. |

[0001327567-18-000031:mdna:85]
Cost of subscription and support revenue increased for the three months ended October 31, 2018 compared to the three months ended October 31, 2017, primarily due to an increase in personnel costs for our global customer support and technical operations organizations, which grew $11.5 million to $58.6 million for the three months ended October 31, 2018 compared to the three months ended October 31, 2017, primarily due to headcount growth. The remaining increase was primarily due to data center and cloud hosting costs to support the adoption of our cloud-based subscription offerings, costs to expand our customer service capabilities, and amortization of purchased intangible assets.

[0001327567-18-000031:mdna:86]
[same as prior period, unchanged from 0001327567-18-000014:mdna:74]

[0001327567-18-000031:mdna:87]
Gross margin, or gross profit as a percentage of revenue, has been and will continue to be affected by a variety of factors, including the introduction of new products, manufacturing costs, the average sales price of our products, the mix of products sold, and the mix of revenue between product and subscription and support offerings. For sales of our products, our higher-end firewall products generally have higher gross margins than our lower-end firewall products within each product series. For sales of our subscription and support offerings, our subscription offerings typically have higher gross margins than our support offerings. We expect our gross margins to fluctuate over time depending on the factors described above.

[0001327567-18-000031:mdna:88]
|  | Three Months Ended October 31, |
|  | 2018 |  | 2017(1) |
|  | Amount |  | Gross Margin |  | Amount |  | Gross Margin |
|  | (dollars in millions) |
| Product | $ | 167.3 |  |  | 69.6 | % |  | $ | 127.2 |  |  | 68.8 | % |
| Subscription and support | 305.2 |  |  | 73.5 | % |  | 233.3 |  |  | 73.6 | % |
| Total gross profit | $ | 472.5 |  |  | 72.0 | % |  | $ | 360.5 |  |  | 71.8 | % |

[0001327567-18-000031:mdna:89]
______________

[0001327567-18-000031:mdna:90]
| (1) | These amounts have been adjusted due to our adoption of the new revenue recognition standard. Refer to Note 1. Description of Business and Summary of Significant Accounting Policies in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information. |

[0001327567-18-000031:mdna:91]
Product gross margin increased for the three months ended October 31, 2018 compared to the three months ended October 31, 2017, due to increased leverage of our operations organization, partially offset by higher product costs related to our newly introduced appliances, which have lower product margins.

[0001327567-18-000031:mdna:92]
Subscription and support gross margin was flat for the three months ended October 31, 2018 compared to the three months ended October 31, 2017.

[0001327567-18-000031:mdna:93]
[same as prior period, unchanged from 0001327567-18-000014:mdna:125]

[0001327567-18-000031:mdna:94]
[same as prior period, unchanged from 0001327567-18-000014:mdna:81]

[0001327567-18-000031:mdna:95]
Our operating expenses consist of research and development, sales and marketing, and general and administrative expense. Personnel costs are the most significant component of operating expenses and consist of salaries, benefits, bonuses, share-based compensation, travel and entertainment, and with regard to sales and marketing expense, sales commissions. Our operating expenses also include allocated costs, which consist of certain facilities, depreciation, benefits, recruiting, and information technology costs that we allocate based on headcount. We expect operating expenses to increase in absolute dollars and decrease over the long term as a percentage of revenue as we continue to scale our business. As of October 31, 2018, we expect to recognize approximately $1.4 billion of share-based compensation expense over a weighted-average period of approximately 2.9 years, excluding additional share-based compensation expense related to any future grants of share-based awards. Share-based compensation expense is generally recognized on a straight-line basis over the requisite service periods of the awards.

[0001327567-18-000031:mdna:96]
[same as prior period, unchanged from 0001327567-18-000014:mdna:83]

[0001327567-18-000031:mdna:97]
[same as prior period, unchanged from 0001327567-18-000014:mdna:84]

[0001327567-18-000031:mdna:98]
|  | Three Months Ended October 31, |  |  |  |  |
|  | 2018 |  | 2017 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Research and development | $ | 113.4 |  |  | $ | 94.2 |  |  | $ | 19.2 |  |  | 20.4 | % |
| Number of employees at period end | 1,047 |  |  | 787 |  |  | 260 |  |  | 33.0 | % |

[0001327567-18-000031:mdna:99]
Research and development expense increased for the three months ended October 31, 2018 compared to the three months ended October 31, 2017. The increase was primarily due to an increase in personnel costs, which grew $15.6 million to $93.3 million for the three months ended October 31, 2018 compared to the three months ended October 31, 2017, largely due to headcount growth. The remaining increase was primarily driven by an increase in allocated costs.

[0001327567-18-000031:mdna:100]
[same as prior period, unchanged from 0001327567-18-000014:mdna:88]

[0001327567-18-000031:mdna:101]
[same as prior period, unchanged from 0001327567-18-000014:mdna:89]

[0001327567-18-000031:mdna:102]
|  | Three Months Ended October 31, |  |  |  |  |
|  | 2018 |  | 2017 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Sales and marketing(1) | $ | 314.6 |  |  | $ | 254.1 |  |  | $ | 60.5 |  |  | 23.8 | % |
| Number of employees at period end | 2,826 |  |  | 2,466 |  |  | 360 |  |  | 14.6 | % |

[0001327567-18-000031:mdna:103]
______________

[0001327567-18-000031:mdna:104]
| (1) | The amount for fiscal 2018 has been adjusted due to our adoption of the new revenue recognition standard. Refer to Note 1. Description of Business and Summary of Significant Accounting Policies in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information. |

[0001327567-18-000031:mdna:105]
Sales and marketing expense increased for the three months ended October 31, 2018 compared to the three months ended October 31, 2017. The increase was primarily due to an increase in personnel costs, which grew $34.8 million to $227.3 million for the three months ended October 31, 2018 compared to the three months ended October 31, 2017, largely due to headcount growth. The remaining increase was primarily driven by an increase in allocated costs and costs related to user conferences.

[0001327567-18-000031:mdna:106]
[same as prior period, unchanged from 0001327567-18-000014:mdna:142]

[0001327567-18-000031:mdna:107]
[same as prior period, unchanged from 0001327567-18-000014:mdna:92]

[0001327567-18-000031:mdna:108]
General and administrative expense consists primarily of personnel costs for our executive, finance, human resources, legal, and information technology organizations, and professional services costs, which consist primarily of legal, auditing, accounting, and other consulting costs. General and administrative expense also includes certain non-recurring general expenses and impairment losses. Certain facilities, depreciation, benefits, recruiting, and information technology costs are allocated to other organizations based on headcount. We expect general and administrative expense to increase in absolute dollars due to additional costs associated with accounting, compliance, and insurance, although our general and administrative expense may fluctuate as a percentage of total revenue.

[0001327567-18-000031:mdna:109]
|  | Three Months Ended October 31, |  |  |  |  |
|  | 2018 |  | 2017 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| General and administrative | $ | 76.6 |  |  | $ | 65.7 |  |  | $ | 10.9 |  |  | 16.6 | % |
| Number of employees at period end | 690 |  |  | 578 |  |  | 112 |  |  | 19.4 | % |

[0001327567-18-000031:mdna:110]
General and administrative expense increased for the three months ended October 31, 2018 compared to the three months ended October 31, 2017. The increase was driven by an increase in personnel costs, which grew $17.9 million to $52.8 million for the three months ended October 31, 2018 compared to the three months ended October 31, 2017, primarily due to expense related to the accelerated vesting of certain equity awards in connection with the RedLock acquisition of $14.2 million. This increase was partially offset by a decrease due to the cease-use loss of $15.4 million recognized on the lease of our previous headquarter facilities during the three months ended October 31, 2017. The remaining increase was primarily due to an increase in legal expenses during the three months ended October 31, 2018.

[0001327567-18-000031:mdna:111]
Interest Expense

[0001327567-18-000031:mdna:112]
Interest expense primarily consists of non-cash interest expense from the amortization of the debt discount and debt issuance costs related to our 2019 Notes and 2023 Notes, and also includes the contractual interest expense related to our 2023 Notes.

[0001327567-18-000031:mdna:113]
|  | Three Months Ended October 31, |  |  |
|  | 2018 |  | 2017 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Interest expense | $ | (22.7 | ) |  | $ | (6.3 | ) |  | $ | (16.4 | ) |  | 260.3 | % |

[0001327567-18-000031:mdna:114]
Interest expense increased for the three months ended October 31, 2018 compared to the three months ended October 31, 2017, primarily due to interest expense recognized on the 2023 Notes issued in July 2018. We expect interest expense to increase in fiscal 2019 due to interest expense to be incurred on the 2023 Notes, partially offset by a reduction in interest expense on the 2019 Notes due to conversions before or upon maturity. Refer to Note 9. Debt in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information on the Notes.

[0001327567-18-000031:mdna:115]
Other Income, Net

[0001327567-18-000031:mdna:116]
Other income, net includes interest income earned on our cash, cash equivalents, and investments, foreign currency remeasurement gains and losses, and foreign currency transaction gains and losses.

[0001327567-18-000031:mdna:117]
|  | Three Months Ended October 31, |  |  |
|  | 2018 |  | 2017 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Other income, net | $ | 13.0 |  |  | $ | 4.8 |  |  | $ | 8.2 |  |  | 170.8 | % |

[0001327567-18-000031:mdna:118]
Other income, net increased for the three months ended October 31, 2018 compared to the three months ended October 31, 2017, primarily driven by a $10.3 million increase in interest income, largely due to higher cash, cash equivalents, and investments

[0001327567-18-000031:mdna:119]
- 33 -

[0001327567-18-000031:mdna:120]
balances and higher yields on these balances during the three months ended October 31, 2018 compared to the three months ended October 31, 2017. This increase was partially offset by a $2.2 million loss recognized related to the settlement of the 2019 Notes converted during the three months ended October 31, 2018. Refer to Note 9. Debt in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information on the Notes.

[0001327567-18-000031:mdna:121]
[same as prior period, unchanged from 0001327567-18-000014:mdna:97]

[0001327567-18-000031:mdna:122]
Provision for (benefit from) income taxes consists primarily of income taxes in foreign jurisdictions in which we conduct business, withholding taxes, and U.S. state income taxes. We maintain a full valuation allowance for domestic and certain foreign deferred tax assets, including net operating loss carryforwards and certain domestic tax credits. In recent years, we reorganized our corporate structure and intercompany relationships to more closely align with the international nature of our business activities. Our corporate structure has caused, and may continue to cause, disproportionate relationships between our overall effective tax rate and other jurisdictional measures. To the extent we revisit our corporate structure, it may have an impact on our tax provision.

[0001327567-18-000031:mdna:123]
|  | Three Months Ended October 31, |  | Change |
|  | 2018 |  | 2017 |  | Amount |  | % |
|  | (dollars in millions) |
| Provision for (benefit from) income taxes | $ | (3.5 | ) |  | $ | 8.2 |  |  | $ | (11.7 | ) |  | (142.7 | )% |
| Effective tax rate | 8.4 | % |  | (14.9 | )% |  |  |  |  |  |

[0001327567-18-000031:mdna:124]
We recorded an income tax benefit for the three months ended October 31, 2018. Key components of our provision for income taxes, excluding one-time items, include foreign income taxes and withholding taxes. Our provision for income taxes decreased for the three months ended October 31, 2018 compared to the three months ended October 31, 2017, primarily due to a one-time tax benefit of $9.4 million from a partial release of our valuation allowance related to the acquisition of RedLock Inc. and due to our adoption of new accounting guidance for intra-entity asset transfers, other than inventory.

[0001327567-18-000031:mdna:125]
In December 2017, the Tax Cuts and Jobs Act (“TCJA”) was enacted into law. Since the enactment of the TCJA, we have recognized provisional amounts for the related tax effects as components of income tax expense. As of October 31, 2018, we did not have any significant adjustments to our assessment performed as of July 31, 2018. Refer to Note 13. Income Taxes in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information on the TCJA.

[0001327567-18-000031:mdna:126]
[same as prior period, unchanged from 0001327567-18-000014:mdna:105]

[0001327567-18-000031:mdna:127]
|  | October 31, 2018 |  | July 31, 2018 |
|  | (in millions) |
| Working capital(1)(2) | $ | 1,999.5 |  |  | $ | 2,036.8 |  |
| Cash, cash equivalents, and investments: |  |  |  |
| Cash and cash equivalents | $ | 1,784.4 |  |  | $ | 2,506.9 |  |
| Investments | 1,984.9 |  |  | 1,444.0 |  |
| Total cash, cash equivalents, and investments | $ | 3,769.3 |  |  | $ | 3,950.9 |  |

[0001327567-18-000031:mdna:128]
______________

[0001327567-18-000031:mdna:129]
| (1) | The amount for fiscal 2018 has been adjusted due to our adoption of the new revenue recognition standard. Refer to Note 1. Description of Business and Summary of Significant Accounting Policies in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information. |

[0001327567-18-000031:mdna:130]
| (2) | The net carrying amount of the 0.0% Convertible Senior Notes due 2019 (the “2019 Notes”) was classified in current liabilities in our condensed consolidated balance sheets as of October 31, 2018 and July 31, 2018, respectively. Refer to Note 9. Debt in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information. |

[0001327567-18-000031:mdna:131]
As of October 31, 2018, our total cash, cash equivalents, and investments of $3.8 billion were held for general corporate purposes, of which approximately $225.5 million was held outside of the United States. As of October 31, 2018, we had no unremitted earnings when evaluating our outside basis difference relating to our U.S. investment in foreign subsidiaries. However, there could be local withholding taxes payable due to various foreign countries if certain lower tier earnings are distributed. Withholding taxes that would be payable upon remittance of these lower tier earnings were not material as of October 31, 2018.

[0001327567-18-000031:mdna:132]
In June 2014, we issued 2019 Notes with an aggregate principal amount of $575.0 million and in July 2018, we issued the 2023 Notes with an aggregate principal amount of $1.7 billion. As of October 31, 2018, $247.7 million of the 2019 Notes remained

[0001327567-18-000031:mdna:133]
- 34 -

[0001327567-18-000031:mdna:134]
outstanding and all of the 2023 Notes remained outstanding. The 2019 Notes and the 2023 Notes mature on July 1, 2019 and July 1, 2023, respectively; however, under certain circumstances, holders may surrender their Notes of a series for conversion prior to the applicable maturity dates. Upon conversion of the Notes of a series, we will pay cash equal to the aggregate principal amount of the Notes of such series to be converted, and, at our election, will pay or deliver cash and/or shares of our common stock for the amount of our conversion obligation in excess of the aggregate principal amount of the Notes of such series being converted. During the three months ended October 31, 2018, holders converted $327.3 million in aggregate principal amount of the 2019 Notes, which we repaid in cash. We also issued 1.4 million shares of our common stock to the holders for the conversion value in excess of the principal amount of the 2019 Notes converted, which were fully offset by shares received from our exercise of the associated note hedges. Subsequent to October 31, 2018, through the filing date of this Quarterly Report on Form 10-Q, $88.3 million in principal amount of the 2019 Notes was converted or had been submitted by the holders for conversion and will settle during the fiscal quarter ending January 31, 2019. Refer to Note 9. Debt in Part I, Item 1 of this Quarterly Report on Form 10-Q for information on the Notes.

[0001327567-18-000031:mdna:135]
In September 2018, we entered into a credit agreement (the “Credit Agreement”) that provides for a $400.0 million unsecured revolving credit facility (the “Credit Facility”), with an option to increase the amount of the credit facility up to an additional $350.0 million, subject to certain conditions. As of October 31, 2018, there were no amounts outstanding, and we were in compliance with all covenants under the Credit Agreement. Refer to Note 9. Debt in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information on the Credit Agreement.

[0001327567-18-000031:mdna:136]
In August 2016, our board of directors authorized a $500.0 million share repurchase program and, in February 2017, authorized a $500.0 million increase to the repurchase program, bringing the total authorization to $1.0 billion. Repurchases are funded from available working capital and may be made at management’s discretion from time to time. The repurchase authorization will expire on December 31, 2018 and may be suspended or discontinued at any time. As of October 31, 2018, $330.0 million was available for future share repurchases under the repurchase authorization. Refer to Note 11. Stockholders’ Equity in Part I, Item 1 of this Quarterly Report on Form 10-Q for information on the repurchase authorization.

[0001327567-18-000031:mdna:137]
The following table summarizes our cash flows for the three months ended October 31, 2018 and 2017:

[0001327567-18-000031:mdna:138]
|  | Three Months Ended October 31, |
| 2018 |  | 2017 |
|  | (in millions) |
| Net cash provided by operating activities(1) | $ | 252.3 |  |  | $ | 274.0 |  |
| Net cash used in investing activities | (713.1 | ) |  | (52.4 | ) |
| Net cash used in financing activities | (261.8 | ) |  | (123.4 | ) |
| Net increase (decrease) in cash, cash equivalents, and restricted cash(1) | $ | (722.6 | ) |  | $ | 98.2 |  |

[0001327567-18-000031:mdna:139]
______________

[0001327567-18-000031:mdna:140]
| (1) | The amount for fiscal 2018 has been adjusted due to our adoption of new guidance related to the presentation of restricted cash and cash equivalents in the statement of cash flows. Refer to Note 1. Description of Business and Summary of Significant Accounting Policies in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information. |

[0001327567-18-000031:mdna:141]
[same as prior period, unchanged from 0001327567-18-000014:mdna:115]

[0001327567-18-000031:mdna:142]
[same as prior period, unchanged from 0001327567-18-000014:mdna:116]

[0001327567-18-000031:mdna:143]
[same as prior period, unchanged from 0001327567-18-000014:mdna:117]

[0001327567-18-000031:mdna:144]
[same as prior period, unchanged from 0001327567-18-000014:mdna:118]

[0001327567-18-000031:mdna:145]
Cash provided by operating activities during the three months ended October 31, 2018 was $252.3 million, a decrease of $21.7 million compared to the three months ended October 31, 2017. The decrease was due to repayments of the 2019 Notes attributable to the debt discount of $52.3 million during the three months ended October 31, 2018, and the receipt of an upfront cash reimbursement of $38.2 million related to certain of our lease agreements during the three months ended October 31, 2017. This was

[0001327567-18-000031:mdna:146]
- 35 -

[0001327567-18-000031:mdna:147]
partially offset by an increase due to growth of our business, as reflected by an increase in billings during the three months ended October 31, 2018.

[0001327567-18-000031:mdna:148]
[same as prior period, unchanged from 0001327567-18-000014:mdna:120]

[0001327567-18-000031:mdna:149]
[same as prior period, unchanged from 0001327567-18-000014:mdna:121]

[0001327567-18-000031:mdna:150]
Cash used in investing activities during the three months ended October 31, 2018 was $713.1 million, an increase of $660.7 million compared to the three months ended October 31, 2017, due to higher net purchases of investments and cash paid for our acquisition of RedLock during the three months ended October 31, 2018.

[0001327567-18-000031:mdna:151]
[same as prior period, unchanged from 0001327567-18-000014:mdna:123]

[0001327567-18-000031:mdna:152]
Our financing activities have consisted of net proceeds from the issuance of the Notes and related transactions, proceeds from sales of shares through employee equity incentive plans, cash used to repurchase shares of our common stock, and payments for tax withholding obligations of certain employees related to the net share settlement of equity awards.

[0001327567-18-000031:mdna:153]
Cash used in financing activities during the three months ended October 31, 2018 was $261.8 million, an increase of $138.4 million compared to the three months ended October 31, 2017, primarily due to repayments of our 2019 Notes, partially offset by a decrease in repurchases of our common stock during the three months ended October 31, 2018.

[0001327567-18-000031:mdna:154]
[same as prior period, unchanged from 0001327567-18-000014:mdna:127]

[0001327567-18-000031:mdna:155]
The following summarizes our contractual obligations and commitments as of October 31, 2018:

[0001327567-18-000031:mdna:156]
|  | Payments Due by Period |
|  | Total |  | Less Than 1 Year |  | 1-3 Years |  | 3-5 Years |  | More Than 5 Years |
|  |  |  | (in millions) |  |  |
| 0.0% Convertible Senior Notes due 2019(1) | $ | 247.7 |  |  | $ | 247.7 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| 0.75% Convertible Senior Notes due 2023 | 1,693.0 |  |  | — |  |  | — |  |  | 1,693.0 |  |  | — |  |
| Operating lease obligations(2) | 525.8 |  |  | 67.8 |  |  | 130.5 |  |  | 114.5 |  |  | 213.0 |  |
| Purchase obligations(3) | 163.6 |  |  | 155.6 |  |  | 8.0 |  |  | — |  |  | — |  |
| Total(4) | $ | 2,630.1 |  |  | $ | 471.1 |  |  | $ | 138.5 |  |  | $ | 1,807.5 |  |  | $ | 213.0 |  |

[0001327567-18-000031:mdna:157]
______________

[0001327567-18-000031:mdna:158]
| (1) | As of October 31, 2018, holders may convert their 2019 Notes at any time during the fiscal quarter ending January 31, 2019. Refer to Note 9. Debt in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information. |

[0001327567-18-000031:mdna:159]
| (2) | Consists of contractual obligations from our non-cancelable operating leases. Excludes contractual sublease proceeds of $12.8 million, which consists of $5.0 million to be received in less than one year, and $7.8 million to be received in one to three years. Refer to Note 10. Commitments and Contingencies in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information on our operating leases. |

[0001327567-18-000031:mdna:160]
[same as prior period, unchanged from 0001327567-18-000014:mdna:133]

[0001327567-18-000031:mdna:161]
| (4) | No amounts related to income taxes are included. As of October 31, 2018, we had approximately $81.7 million of tax liabilities recorded related to uncertainty in income tax positions. |

[0001327567-18-000031:mdna:162]
[same as prior period, unchanged from 0001327567-18-000014:mdna:135]

[0001327567-18-000031:mdna:163]
As of October 31, 2018, we did not have any relationships with unconsolidated organizations or financial partnerships, such as structured finance or special purpose entities that would have been established for the purpose of facilitating off-balance sheet arrangements or other contractually narrow or limited purposes.

[0001327567-18-000031:mdna:164]
[same as prior period, unchanged from 0001327567-18-000014:mdna:137]

[0001327567-18-000031:mdna:165]
Our condensed consolidated financial statements have been prepared in accordance with U.S. GAAP. The preparation of these condensed consolidated financial statements requires us to make estimates and assumptions that affect the reported amounts of assets,

[0001327567-18-000031:mdna:166]
- 36 -

[0001327567-18-000031:mdna:167]
liabilities, revenue, expenses, and related disclosures. We base our estimates on historical experience and on various other assumptions that we believe are reasonable under the circumstances. We evaluate our estimates and assumptions on an ongoing basis. Actual results may differ from these estimates. To the extent that there are material differences between these estimates and our actual results, our future financial statements will be affected.

[0001327567-18-000031:mdna:168]
We believe the critical accounting estimates discussed under Item 7, “Management’s Discussion and Analysis of Financial Condition and Results of Operations” in our Annual Report on Form 10-K for the fiscal year ended July 31, 2018, reflect our more significant judgments and estimates used in the preparation of our condensed consolidated financial statements. There have been no significant changes to our critical accounting estimates as filed in such report, except for revenue recognition and deferred contract costs, due to our adoption of new accounting guidance, as described below. Refer to “Recently Adopted Accounting Pronouncements” in Note 1. Description of Business and Summary of Significant Accounting Policies in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information on our adoption of the new accounting guidance.

[0001327567-18-000031:mdna:169]
Revenue Recognition

[0001327567-18-000031:mdna:170]
The majority of our contracts with our customers include various combinations of our products and subscriptions and support which are distinct and accounted for as separate performance obligations. We account for multiple agreements with a single customer as a single contract if the contractual terms and/or substance of those agreements indicate that they may be so closely related that they are, in effect, parts of a single contract. The amount we are due in exchange for delivering on the contract is allocated to each performance obligation based on its relative standalone selling price.

[0001327567-18-000031:mdna:171]
We establish standalone selling price using the prices charged for a deliverable when sold separately. If not observable through past transactions, we estimate the standalone selling price based on our pricing model and our go-to-market strategy, which include factors such as type of sales channel (reseller, distributor, or end-customer), the geographies in which our offerings were sold (domestic or international) and offering type (products, subscriptions, or support). As our business offerings evolve over time, we may be required to modify our estimated standalone selling prices, and as a result the timing and classification of our revenue could be affected.

[0001327567-18-000031:mdna:172]
Deferred Contract Costs

[0001327567-18-000031:mdna:173]
We defer contract costs that are recoverable and incremental to obtaining customer sales contracts. Contract costs, which primarily consist of sales commissions, are amortized on a systematic basis that is consistent with the transfer to the customer of the goods or services to which the asset relates. Sales commissions for initial contracts that are not commensurate with renewal commissions are amortized over a benefit period of five years, consistent with the revenue recognition pattern of the performance obligations in the related contracts including expected renewals. The benefit period is determined by taking into consideration of contract length, technology life, and other quantitative and qualitative factors. The expected renewals are estimated based on historical renewal trends. Sales commissions for initial contracts that are commensurate and sales commissions for renewal contracts are amortized over the related contractual period in proportion to the revenue recognized.

[0001327567-18-000031:mdna:174]
[same as prior period, unchanged from 0001327567-18-000014:mdna:140]

[0001327567-18-000031:mdna:175]
Refer to “Recently Issued Accounting Pronouncements” in Note 1. Description of Business and Summary of Significant Accounting Policies in Part I, Item 1 of this Quarterly Report on Form 10-Q.
