# PANW MD&A — 0001327567-16-000048


## mdna

[0001327567-16-000048:mdna:1]
[same as prior period, unchanged from 0001327567-15-000036:mdna:1]

[0001327567-16-000048:mdna:2]
Our Management’s Discussion and Analysis of Financial Condition and Results of Operations (“MD&A”) is organized as follows:

[0001327567-16-000048:mdna:3]
[same as prior period, unchanged from 0001327567-15-000036:mdna:4]

[0001327567-16-000048:mdna:4]
| • | Key Financial Metrics. An analysis of our generally accepted accounting principles (“GAAP”) and non-GAAP key financial metrics, which management monitors to evaluate our performance. |

[0001327567-16-000048:mdna:5]
| • | Results of Operations. A discussion of the nature and trends in our financial results and an analysis of our financial results comparing the three and six months ended January 31, 2016 to the three and six months ended January 31, 2015. |

[0001327567-16-000048:mdna:6]
[same as prior period, unchanged from 0001327567-15-000036:mdna:7]

[0001327567-16-000048:mdna:7]
| • | Contractual Obligations and Commitments. An overview of our contractual obligations, contingent liabilities, commitments, and off-balance sheet arrangements outstanding as of January 31, 2016, including expected payment schedule. |

[0001327567-16-000048:mdna:8]
| • | Critical Accounting Estimates. A discussion of accounting policies that require critical estimates, assumptions, and judgments. |

[0001327567-16-000048:mdna:9]
[same as prior period, unchanged from 0001327567-15-000036:mdna:10]

[0001327567-16-000048:mdna:10]
[same as prior period, unchanged from 0001327567-15-000036:mdna:16]

[0001327567-16-000048:mdna:11]
[same as prior period, unchanged from 0001327567-15-000036:mdna:11]

[0001327567-16-000048:mdna:12]
We have pioneered the next-generation of security with our innovative platform that empowers enterprises, service providers, and government entities to secure their organizations by safely enabling the increasingly complex and rapidly growing number of applications running on their networks and by preventing breaches that stem from targeted cyber attacks. Our platform uses an innovative traffic classification engine that identifies network traffic by application, user, and content. As a result, it provides in-depth visibility into all traffic and all applications at the user level in order to control usage, content, risks, and cyber threats. Our security platform consists of three major elements: our Next-Generation Firewall, our Advanced Endpoint Protection, and our Threat Intelligence Cloud. Our Next-Generation Firewall delivers application, user, and content visibility and control, as well as protection against network-based cyber threats, through our proprietary hardware and software architecture that is integrated within the firewall. Our Advanced Endpoint Protection prevents cyber attacks that aim to exploit software vulnerabilities on a broad variety of fixed and virtual endpoints and servers. Our Threat Intelligence Cloud provides central intelligence capabilities, security for software as a service (“SaaS”) applications, and automated delivery of preventative measures against cyber attacks.

[0001327567-16-000048:mdna:13]
[same as prior period, unchanged from 0001327567-15-000036:mdna:13]

[0001327567-16-000048:mdna:14]
For the second quarter of fiscal 2016 and 2015, revenues were $334.7 million and $217.7 million, respectively, representing year over year growth of 53.8%. All three components of our hybrid SaaS revenue model experienced year over year growth, led by revenue from subscription services, which grew 68.2% to $84.3 million, followed by support and maintenance services, which grew 55.1% to $80.5 million, and product, which grew 46.9% to $169.9 million.

[0001327567-16-000048:mdna:15]
Our growth reflects the increased adoption of our hybrid SaaS revenue model, which consists of product, subscriptions, and support and maintenance. We believe this model will enable us to benefit from recurring revenues as we continue to grow our installed end-customer base. As of January 31, 2016, we had sold our products and services to more than 30,000 end-customers in over 140 countries. Our end-customers represent a broad range of industries including education, energy, financial services, government entities, healthcare, Internet and media, manufacturing, public sector, and telecommunications, and include some of the largest Fortune 100 and Global 2000 companies in the world.

[0001327567-16-000048:mdna:16]
[same as prior period, unchanged from 0001327567-15-000036:mdna:18]

[0001327567-16-000048:mdna:17]
[same as prior period, unchanged from 0001327567-15-000036:mdna:19]

[0001327567-16-000048:mdna:18]
[same as prior period, unchanged from 0001327567-15-000036:mdna:20]

[0001327567-16-000048:mdna:19]
We believe that the growth of our business and our short-term and long-term success are dependent upon many factors, including our ability to extend our technology leadership, grow our base of end-customers, expand deployment of our platform and services within existing end-customers, extend the length of service terms within existing end-customers, and focus on end-customer satisfaction. To manage any future growth effectively, we must continue to improve and expand our information technology and financial infrastructure, our operating and administrative systems and controls, and our ability to manage headcount, capital, and processes in an efficient manner. While these areas present significant opportunities for us, they also pose challenges and risks that we must successfully address in order to sustain the growth of our business and improve our operating results.

[0001327567-16-000048:mdna:20]
[same as prior period, unchanged from 0001327567-15-000036:mdna:26]

[0001327567-16-000048:mdna:21]
[same as prior period, unchanged from 0001327567-15-000036:mdna:23]

[0001327567-16-000048:mdna:22]
[same as prior period, unchanged from 0001327567-15-000036:mdna:24]

[0001327567-16-000048:mdna:23]
|  | January 31, 2016 |  | July 31, 2015 |
|  | (in millions) |
| Total deferred revenue | $ | 928.8 |  |  | $ | 713.7 |  |
| Cash, cash equivalents, and investments | $ | 1,595.7 |  |  | $ | 1,327.8 |  |

[0001327567-16-000048:mdna:24]
|  | Three Months Ended January 31, |  | Six Months Ended January 31, |
|  | 2016 |  | 2015 |  | 2016 |  | 2015 |
|  | (dollars in millions) |
| Total revenue | $ | 334.7 |  |  | $ | 217.7 |  |  | $ | 631.9 |  |  | $ | 410.0 |  |
| Year over year percentage increase | 53.8 | % |  | 54.3 | % |  | 54.1 | % |  | 52.3 | % |
| Gross margin percentage | 71.9 | % |  | 72.7 | % |  | 72.6 | % |  | 72.5 | % |
| Operating loss | $ | (55.3 | ) |  | $ | (38.5 | ) |  | $ | (86.1 | ) |  | $ | (62.3 | ) |
| Operating margin percentage | (16.5 | )% |  | (17.7 | )% |  | (13.6 | )% |  | (15.2 | )% |
| Billings (non-GAAP) | $ | 459.0 |  |  | $ | 282.8 |  |  | $ | 847.0 |  |  | $ | 523.3 |  |
| Cash flow provided by operating activities |  |  |  |  |  |  | $ | 300.5 |  |  | $ | 151.8 |  |
| Free cash flow (non-GAAP) |  |  |  |  |  |  | $ | 263.6 |  |  | $ | 139.7 |  |

[0001327567-16-000048:mdna:25]
| • | Deferred Revenue. Our deferred revenue consists of amounts that have been invoiced but have not been recognized as revenue as of the period end. The majority of our deferred revenue balance consists of subscription and support and maintenance revenue that is recognized ratably over the contractual service period. We monitor our deferred revenue balance because it represents a significant portion of revenue to be recognized in future periods. |

[0001327567-16-000048:mdna:26]
[same as prior period, unchanged from 0001327567-15-000036:mdna:29]

[0001327567-16-000048:mdna:27]
[same as prior period, unchanged from 0001327567-15-000036:mdna:33]

[0001327567-16-000048:mdna:28]
| • | Free Cash Flow (non-GAAP). We define free cash flow, a non-GAAP financial measure, as cash provided by operating activities less purchases of property, equipment, and other assets. We consider free cash flow to be a profitability and liquidity measure that provides useful information to management and investors about the amount of cash generated by the business that, after the purchases of property, equipment, and other productive assets, can be used for strategic opportunities, including investing in our business, making strategic acquisitions, and strengthening the balance sheet. A limitation of the utility of free cash flow as a measure of our financial performance and liquidity is that it does not represent the total increase or decrease in our cash balance for the period. In addition, it is important to note that other companies, including companies in our industry, may not use free cash flow, may calculate free cash flow in a different manner than we do, or may use other financial measures to evaluate their performance, all of which could reduce the usefulness of free cash flow as a comparative measure. A reconciliation of free cash flow to cash flow provided by operating activities, the most directly comparable financial measure calculated and presented in accordance with GAAP, is provided below: |

[0001327567-16-000048:mdna:29]
|  | Six Months Ended January 31, |
|  | 2016 |  | 2015 |
|  | (in millions) |
| Free cash flow (non-GAAP): |  |  |  |
| Net cash provided by operating activities | $ | 300.5 |  |  | $ | 151.8 |  |
| Less: purchases of property, equipment, and other assets | 36.9 |  |  | 12.1 |  |
| Free cash flow (non-GAAP) | $ | 263.6 |  |  | $ | 139.7 |  |
| Net cash used in investing activities | $ | (284.7 | ) |  | $ | (487.4 | ) |
| Net cash provided by financing activities | $ | 21.6 |  |  | $ | 24.8 |  |

[0001327567-16-000048:mdna:30]
| • | Billings (non-GAAP). We define billings, a non-GAAP financial measure, as total revenue plus the change in deferred revenue during the period. We consider billings to be a key measure used by management to manage our business given our hybrid SaaS revenue model, and believe billings provides investors with an important indicator of the health and visibility of our business because it includes services revenue, which is recognized ratably over the subscription period or the period in which the services are expected to be performed, as the case may be, and product revenue, which is recognized at the time of shipment, provided that all other revenue recognition criteria have been met. We consider billings to be a useful metric for management and investors, particularly if we continue to experience increased sales of subscriptions and strong renewal rates for subscriptions and support and maintenance services, and as we monitor our near term cash flows. While we believe that billings provides useful information to investors and others in understanding and evaluating our operating results in the same manner as our management, it is important to note that other companies, including companies in our industry, may not use billings, may calculate billings differently, may have different billing frequencies, or may use other financial measures to evaluate their performance, all of which could reduce the usefulness of billings as a comparative measure. A reconciliation of billings to revenue, the most directly comparable financial measure calculated and presented in accordance with GAAP, is provided below: |

[0001327567-16-000048:mdna:31]
|  | Three Months Ended January 31, |  | Six Months Ended January 31, |
|  | 2016 |  | 2015 |  | 2016 |  | 2015 |
|  | (in millions) |
| Billings (non-GAAP): |  |  |  |  |  |  |  |
| Total revenue | $ | 334.7 |  |  | $ | 217.7 |  |  | $ | 631.9 |  |  | $ | 410.0 |  |
| Add: change in total deferred revenue | 124.3 |  |  | 65.1 |  |  | 215.1 |  |  | 113.3 |  |
| Billings (non-GAAP) | $ | 459.0 |  |  | $ | 282.8 |  |  | $ | 847.0 |  |  | $ | 523.3 |  |

[0001327567-16-000048:mdna:32]
[same as prior period, unchanged from 0001327567-15-000036:mdna:39]

[0001327567-16-000048:mdna:33]
[same as prior period, unchanged from 0001327567-15-000036:mdna:36]

[0001327567-16-000048:mdna:34]
[same as prior period, unchanged from 0001327567-15-000036:mdna:37]

[0001327567-16-000048:mdna:35]
|  | Three Months Ended January 31, |  | Six Months Ended January 31, |
|  | 2016 |  | 2015 |  | 2016 |  | 2015 |
|  | Amount |  | % of Revenue |  | Amount |  | % of Revenue |  | Amount |  | % of Revenue |  | Amount |  | % of Revenue |
|  | (dollars in millions) |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 169.9 |  |  | 50.7 | % |  | $ | 115.6 |  |  | 53.1 | % |  | $ | 317.6 |  |  | 50.3 | % |  | $ | 217.1 |  |  | 53.0 | % |
| Services | 164.8 |  |  | 49.3 | % |  | 102.1 |  |  | 46.9 | % |  | 314.3 |  |  | 49.7 | % |  | 192.9 |  |  | 47.0 | % |
| Total revenue | 334.7 |  |  | 100.0 | % |  | 217.7 |  |  | 100.0 | % |  | 631.9 |  |  | 100.0 | % |  | 410.0 |  |  | 100.0 | % |
| Cost of revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product | 44.9 |  |  | 13.4 | % |  | 30.7 |  |  | 14.1 | % |  | 83.7 |  |  | 13.2 | % |  | 59.8 |  |  | 14.6 | % |
| Services | 49.3 |  |  | 14.7 | % |  | 28.7 |  |  | 13.2 | % |  | 89.7 |  |  | 14.2 | % |  | 53.0 |  |  | 12.9 | % |
| Total cost of revenue | 94.2 |  |  | 28.1 | % |  | 59.4 |  |  | 27.3 | % |  | 173.4 |  |  | 27.4 | % |  | 112.8 |  |  | 27.5 | % |
| Total gross profit | 240.5 |  |  | 71.9 | % |  | 158.3 |  |  | 72.7 | % |  | 458.5 |  |  | 72.6 | % |  | 297.2 |  |  | 72.5 | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | 74.0 |  |  | 22.1 | % |  | 47.0 |  |  | 21.6 | % |  | 133.7 |  |  | 21.2 | % |  | 84.3 |  |  | 20.5 | % |
| Sales and marketing | 187.6 |  |  | 56.0 | % |  | 122.8 |  |  | 56.5 | % |  | 345.9 |  |  | 54.7 | % |  | 229.2 |  |  | 55.9 | % |
| General and administrative | 34.2 |  |  | 10.3 | % |  | 27.0 |  |  | 12.3 | % |  | 65.0 |  |  | 10.3 | % |  | 46.0 |  |  | 11.3 | % |
| Total operating expenses | 295.8 |  |  | 88.4 | % |  | 196.8 |  |  | 90.4 | % |  | 544.6 |  |  | 86.2 | % |  | 359.5 |  |  | 87.7 | % |
| Operating loss | (55.3 | ) |  | (16.5 | )% |  | (38.5 | ) |  | (17.7 | )% |  | (86.1 | ) |  | (13.6 | )% |  | (62.3 | ) |  | (15.2 | )% |
| Interest expense | (5.8 | ) |  | (1.7 | )% |  | (5.5 | ) |  | (2.5 | )% |  | (11.6 | ) |  | (1.8 | )% |  | (11.0 | ) |  | (2.7 | )% |
| Other income, net | 2.5 |  |  | 0.7 | % |  | 0.3 |  |  | 0.1 | % |  | 4.7 |  |  | 0.7 | % |  | 0.7 |  |  | 0.2 | % |
| Loss before income taxes | (58.6 | ) |  | (17.5 | )% |  | (43.7 | ) |  | (20.1 | )% |  | (93.0 | ) |  | (14.7 | )% |  | (72.6 | ) |  | (17.7 | )% |
| Provision for (benefit from) income taxes | 3.9 |  |  | 1.2 | % |  | (0.7 | ) |  | (0.3 | )% |  | 8.2 |  |  | 1.3 | % |  | 0.5 |  |  | 0.1 | % |
| Net loss | $ | (62.5 | ) |  | (18.7 | )% |  | $ | (43.0 | ) |  | (19.8 | )% |  | $ | (101.2 | ) |  | (16.0 | )% |  | $ | (73.1 | ) |  | (17.8 | )% |
| Number of employees at period end |  |  |  |  |  |  |  |  | 3,343 |  |  |  |  | 2,083 |  |  |  |

[0001327567-16-000048:mdna:36]
[same as prior period, unchanged from 0001327567-15-000036:mdna:40]

[0001327567-16-000048:mdna:37]
[same as prior period, unchanged from 0001327567-15-000036:mdna:41]

[0001327567-16-000048:mdna:38]
[same as prior period, unchanged from 0001327567-15-000036:mdna:42]

[0001327567-16-000048:mdna:39]
[same as prior period, unchanged from 0001327567-15-000036:mdna:43]

[0001327567-16-000048:mdna:40]
[same as prior period, unchanged from 0001327567-15-000036:mdna:44]

[0001327567-16-000048:mdna:41]
[same as prior period, unchanged from 0001327567-15-000036:mdna:52]

[0001327567-16-000048:mdna:42]
|  | Three Months Ended January 31, |  |  |  |  |  | Six Months Ended January 31, |  |  |  |  |
|  | 2016 |  | 2015 |  | Change |  | 2016 |  | 2015 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 169.9 |  |  | $ | 115.6 |  |  | $ | 54.3 |  |  | 46.9 | % |  | $ | 317.6 |  |  | $ | 217.1 |  |  | $ | 100.5 |  |  | 46.3 | % |
| Services |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Subscription | 84.3 |  |  | 50.1 |  |  | 34.2 |  |  | 68.2 | % |  | 157.9 |  |  | 93.8 |  |  | 64.1 |  |  | 68.4 | % |
| Support and maintenance | 80.5 |  |  | 52.0 |  |  | 28.5 |  |  | 55.1 | % |  | 156.4 |  |  | 99.1 |  |  | 57.3 |  |  | 57.9 | % |
| Total services | 164.8 |  |  | 102.1 |  |  | 62.7 |  |  | 61.6 | % |  | 314.3 |  |  | 192.9 |  |  | 121.4 |  |  | 63.0 | % |
| Total revenue | $ | 334.7 |  |  | $ | 217.7 |  |  | $ | 117.0 |  |  | 53.8 | % |  | $ | 631.9 |  |  | $ | 410.0 |  |  | $ | 221.9 |  |  | 54.1 | % |
| Revenue by geographic theater: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 229.7 |  |  | $ | 147.1 |  |  | $ | 82.6 |  |  | 56.2 | % |  | $ | 441.0 |  |  | $ | 278.9 |  |  | $ | 162.1 |  |  | 58.1 | % |
| EMEA | 62.1 |  |  | 44.8 |  |  | 17.3 |  |  | 38.4 | % |  | 115.8 |  |  | 83.3 |  |  | 32.5 |  |  | 39.0 | % |
| APAC | 42.9 |  |  | 25.8 |  |  | 17.1 |  |  | 66.7 | % |  | 75.1 |  |  | 47.8 |  |  | 27.3 |  |  | 57.3 | % |
| Total revenue | $ | 334.7 |  |  | $ | 217.7 |  |  | $ | 117.0 |  |  | 53.8 | % |  | $ | 631.9 |  |  | $ | 410.0 |  |  | $ | 221.9 |  |  | 54.1 | % |

[0001327567-16-000048:mdna:43]
Product revenue increased $54.3 million, or 46.9%, for the three months ended January 31, 2016 compared to the three months ended January 31, 2015, and increased $100.5 million, or 46.3%, for the six months ended January 31, 2016 compared to the six months ended January 31, 2015. The increases in both periods were driven by increased demand for our higher end appliances. The change in product revenue due to pricing was not significant for either period.

[0001327567-16-000048:mdna:44]
Services revenue increased $62.7 million, or 61.6%, for the three months ended January 31, 2016 compared to the three months ended January 31, 2015, and increased $121.4 million, or 63.0%, for the six months ended January 31, 2016 compared to the six months ended January 31, 2015. The increases in both periods were due to increased sales to new and existing end-customers. The mix between subscription revenue and support and maintenance revenue will fluctuate over time, depending on the introduction of new subscription offerings, renewals of support and maintenance services, and our ability to increase sales to new and existing customers. The change in services revenue due to pricing was not significant for either period.

[0001327567-16-000048:mdna:45]
With respect to geographic theaters, the Americas contributed the largest portion of the increase in revenue for the three and six months ended January 31, 2016 compared to the three and six months ended January 31, 2015, due to its larger and more established sales force compared to our other theaters. Revenue from both Europe, the Middle East, and Africa (“EMEA”) and Asia Pacific and Japan (“APAC”) increased for the three and six months ended January 31, 2016 compared to the three and six months ended January 31, 2015, due to our investment in increasing the size of our sales force and number of channel partners in these theaters.

[0001327567-16-000048:mdna:46]
[same as prior period, unchanged from 0001327567-15-000036:mdna:49]

[0001327567-16-000048:mdna:47]
[same as prior period, unchanged from 0001327567-15-000036:mdna:50]

[0001327567-16-000048:mdna:48]
| • | Cost of Product Revenue. Cost of product revenue primarily includes costs paid to our third-party contract manufacturer. Our cost of product revenue also includes amortization of intellectual property licenses, product testing costs, warranty costs, shipping costs, and personnel costs, which consist of salaries, benefits, bonuses, and share-based compensation associated with our operations organization. In addition, our cost of product revenue also includes allocated costs, which consist of certain facilities, depreciation, benefits, recruiting, and information technology costs that we allocate based on headcount. We expect our cost of product revenue to increase as our product revenue increases. |

[0001327567-16-000048:mdna:49]
| • | Cost of Services Revenue. Cost of services revenue includes personnel costs for our global customer support and technical operations organizations, amortization of acquired intangible assets, allocated costs, and uniform resource locator (“URL”) filtering database service fees. We expect our cost of services revenue to increase as our installed end-customer base grows. |

[0001327567-16-000048:mdna:50]
[same as prior period, unchanged from 0001327567-15-000036:mdna:62]

[0001327567-16-000048:mdna:51]
|  | Three Months Ended January 31, |  |  |  | Six Months Ended January 31, |  |  |  |  |
|  | 2016 |  | 2015 |  | Change |  | 2016 |  | 2015 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Cost of revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 44.9 |  |  | $ | 30.7 |  |  | $ | 14.2 |  |  | 46.7 | % |  | $ | 83.7 |  |  | $ | 59.8 |  |  | $ | 23.9 |  |  | 40.0 | % |
| Services | 49.3 |  |  | 28.7 |  |  | 20.6 |  |  | 71.4 | % |  | 89.7 |  |  | 53.0 |  |  | 36.7 |  |  | 69.2 | % |
| Total cost of revenue | $ | 94.2 |  |  | $ | 59.4 |  |  | $ | 34.8 |  |  | 58.7 | % |  | $ | 173.4 |  |  | $ | 112.8 |  |  | $ | 60.6 |  |  | 53.8 | % |
| Includes share-based compensation of: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 1.6 |  |  | $ | 1.0 |  |  | $ | 0.6 |  |  | 72.5 | % |  | $ | 2.9 |  |  | $ | 1.7 |  |  | $ | 1.2 |  |  | 72.2 | % |
| Services | 10.5 |  |  | 5.1 |  |  | 5.4 |  |  | 105.8 | % |  | 17.5 |  |  | 8.6 |  |  | 8.9 |  |  | 103.1 | % |
| Total share-based compensation included in cost of revenue | $ | 12.1 |  |  | $ | 6.1 |  |  | $ | 6.0 |  |  | 100.6 | % |  | $ | 20.4 |  |  | $ | 10.3 |  |  | $ | 10.1 |  |  | 98.0 | % |

[0001327567-16-000048:mdna:52]
Cost of product revenue increased $14.2 million, or 46.7%, for the three months ended January 31, 2016 compared to the three months ended January 31, 2015, and increased $23.9 million, or 40.0%, for the six months ended January 31, 2016 compared to the six months ended January 31, 2015. The increases in both periods were due to an increase in product unit volume.

[0001327567-16-000048:mdna:53]
Cost of services revenue increased $20.6 million, or 71.4%, for the three months ended January 31, 2016 compared to the three months ended January 31, 2015, due to increases in personnel costs of $10.5 million related to headcount growth, allocated costs of $3.2 million, and third-party professional services costs of $2.6 million to expand our customer service capabilities to support our growing installed end-customer base.

[0001327567-16-000048:mdna:54]
Cost of services revenue increased $36.7 million, or 69.2%, for the six months ended January 31, 2016 compared to the six months ended January 31, 2015, due to increases in personnel costs of $19.0 million related to headcount growth, allocated costs of $5.7 million, and third-party professional services costs of $4.0 million to expand our customer service capabilities to support our growing installed end-customer base.

[0001327567-16-000048:mdna:55]
[same as prior period, unchanged from 0001327567-15-000036:mdna:58]

[0001327567-16-000048:mdna:56]
[same as prior period, unchanged from 0001327567-15-000036:mdna:59]

[0001327567-16-000048:mdna:57]
|  | Three Months Ended January 31, |  | Six Months Ended January 31, |
|  | 2016 |  | 2015 |  | 2016 |  | 2015 |
|  | Amount |  | Gross Margin |  | Amount |  | Gross Margin |  | Amount |  | Gross Margin |  | Amount |  | Gross Margin |
|  | (dollars in millions) |
| Gross profit: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 125.0 |  |  | 73.5 | % |  | $ | 84.9 |  |  | 73.5 | % |  | $ | 233.9 |  |  | 73.6 | % |  | $ | 157.3 |  |  | 72.5 | % |
| Services | 115.5 |  |  | 70.2 | % |  | 73.4 |  |  | 71.9 | % |  | 224.6 |  |  | 71.5 | % |  | 139.9 |  |  | 72.5 | % |
| Total gross profit | $ | 240.5 |  |  | 71.9 | % |  | $ | 158.3 |  |  | 72.7 | % |  | $ | 458.5 |  |  | 72.6 | % |  | $ | 297.2 |  |  | 72.5 | % |

[0001327567-16-000048:mdna:58]
Product gross margin was flat for the three months ended January 31, 2016 compared to the three months ended January 31, 2015. Services gross margin decreased 170 basis points for the three months ended January 31, 2016 compared to the three months ended January 31, 2015, driven by headcount growth within our global customer support organization in order to support our growing installed end-customer base.

[0001327567-16-000048:mdna:59]
Product gross margin increased 110 basis points for the six months ended January 31, 2016 compared to the six months ended January 31, 2015, driven by our continued focus on material cost reductions. Services gross margin decreased 100 basis

[0001327567-16-000048:mdna:60]
[same as prior period, unchanged from 0001327567-15-000036:mdna:71]

[0001327567-16-000048:mdna:61]
points for the six months ended January 31, 2016 compared to the six months ended January 31, 2015, driven by headcount growth within our global customer support organization in order to support our growing installed end-customer base.

[0001327567-16-000048:mdna:62]
[same as prior period, unchanged from 0001327567-15-000036:mdna:63]

[0001327567-16-000048:mdna:63]
Our operating expenses consist of research and development, sales and marketing, and general and administrative expense. Personnel costs are the most significant component of operating expenses and consist of salaries, benefits, bonuses, share-based compensation, and with regard to sales and marketing expense, sales commissions. Our operating expenses also include allocated costs, which consist of certain facilities, depreciation, benefits, recruiting, and information technology costs that we allocate based on headcount. We expect operating expenses to increase in absolute dollars and decrease over the long term as a percentage of revenue as we continue to scale our business. As of January 31, 2016, we expect to recognize approximately $924.1 million of share-based compensation expense over a weighted-average period of approximately three years, excluding additional share-based compensation expense related to any future grants of share-based awards. Share-based compensation expense, net of forfeitures, is recognized on a straight-line basis over the requisite service periods of the awards.

[0001327567-16-000048:mdna:64]
[same as prior period, unchanged from 0001327567-15-000036:mdna:65]

[0001327567-16-000048:mdna:65]
[same as prior period, unchanged from 0001327567-15-000036:mdna:66]

[0001327567-16-000048:mdna:66]
[same as prior period, unchanged from 0001327567-15-000036:mdna:67]

[0001327567-16-000048:mdna:67]
|  | Three Months Ended January 31, |  |  |  |  |  | Six Months Ended January 31, |  |  |  |  |
|  | 2016 |  | 2015 |  | Change |  | 2016 |  | 2015 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | $ | 74.0 |  |  | $ | 47.0 |  |  | $ | 27.0 |  |  | 57.5 | % |  | $ | 133.7 |  |  | $ | 84.3 |  |  | $ | 49.4 |  |  | 58.6 | % |
| Sales and marketing | 187.6 |  |  | 122.8 |  |  | 64.8 |  |  | 52.7 | % |  | 345.9 |  |  | 229.2 |  |  | 116.7 |  |  | 50.9 | % |
| General and administrative | 34.2 |  |  | 27.0 |  |  | 7.2 |  |  | 27.3 | % |  | 65.0 |  |  | 46.0 |  |  | 19.0 |  |  | 41.6 | % |
| Total operating expenses | $ | 295.8 |  |  | $ | 196.8 |  |  | $ | 99.0 |  |  | 50.3 | % |  | $ | 544.6 |  |  | $ | 359.5 |  |  | $ | 185.1 |  |  | 51.5 | % |
| Includes share-based compensation of: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | $ | 34.9 |  |  | $ | 19.0 |  |  | $ | 15.9 |  |  | 84.0 | % |  | $ | 59.9 |  |  | $ | 33.0 |  |  | $ | 26.9 |  |  | 81.6 | % |
| Sales and marketing | 39.4 |  |  | 21.7 |  |  | 17.7 |  |  | 81.2 | % |  | 66.6 |  |  | 37.5 |  |  | 29.1 |  |  | 77.4 | % |
| General and administrative | 15.5 |  |  | 10.1 |  |  | 5.4 |  |  | 53.1 | % |  | 27.9 |  |  | 14.6 |  |  | 13.3 |  |  | 92.2 | % |
| Total share-based compensation included in operating expenses | $ | 89.8 |  |  | $ | 50.8 |  |  | $ | 39.0 |  |  | 76.7 | % |  | $ | 154.4 |  |  | $ | 85.1 |  |  | $ | 69.3 |  |  | 81.6 | % |

[0001327567-16-000048:mdna:68]
Research and development expense increased $27.0 million, or 57.5%, for the three months ended January 31, 2016 compared to the three months ended January 31, 2015, due to an increase in personnel costs of $23.9 million, largely due to headcount growth, and an increase in allocated costs of $2.5 million.

[0001327567-16-000048:mdna:69]
[same as prior period, unchanged from 0001327567-15-000036:mdna:86]

[0001327567-16-000048:mdna:70]
Research and development expense increased $49.4 million, or 58.6%, for the six months ended January 31, 2016 compared to the six months ended January 31, 2015, due to an increase in personnel costs of $43.5 million, largely due to headcount growth, and an increase in allocated costs of $4.6 million.

[0001327567-16-000048:mdna:71]
Sales and marketing expense increased $64.8 million, or 52.7%, for the three months ended January 31, 2016 compared to the three months ended January 31, 2015, due to an increase in personnel costs of $44.9 million, largely due to headcount growth, an increase in allocated costs of $8.2 million, an increase in travel and entertainment costs of $4.0 million, and an increase in demand generation activities, trade shows, and other marketing activities of $1.6 million.

[0001327567-16-000048:mdna:72]
Sales and marketing expense increased $116.7 million, or 50.9%, for the six months ended January 31, 2016 compared to the six months ended January 31, 2015, due to an increase in personnel costs of $79.0 million, largely due to headcount growth, an increase in allocated costs of $14.7 million, an increase in travel and entertainment costs of $8.2 million, and an increase in demand generation activities, trade shows, and other marketing activities of $3.2 million.

[0001327567-16-000048:mdna:73]
General and administrative expense increased $7.2 million, or 27.3%, for the three months ended January 31, 2016 compared to the three months ended January 31, 2015, due to an increase in personnel costs of $7.4 million, largely due to headcount growth.

[0001327567-16-000048:mdna:74]
General and administrative expense increased $19.0 million, or 41.6%, for the six months ended January 31, 2016 compared to the six months ended January 31, 2015, due to an increase in personnel costs of $18.0 million, largely due to headcount growth.

[0001327567-16-000048:mdna:75]
[same as prior period, unchanged from 0001327567-15-000036:mdna:73]

[0001327567-16-000048:mdna:76]
[same as prior period, unchanged from 0001327567-15-000036:mdna:74]

[0001327567-16-000048:mdna:77]
|  | Three Months Ended January 31, |  |  |  |  |  | Six Months Ended January 31, |  |  |  |  |
|  | 2016 |  | 2015 |  | Change |  | 2016 |  | 2015 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Other income, net | $ | 2.5 |  |  | $ | 0.3 |  |  | $ | 2.2 |  |  | NM |  | $ | 4.7 |  |  | $ | 0.7 |  |  | $ | 4.0 |  |  | NM |

[0001327567-16-000048:mdna:78]
Other income, net increased $2.2 million and $4.0 million for the three and six months ended January 31, 2016 compared to the three and six months ended January 31, 2015, due to an increase in interest income and higher foreign currency remeasurement gains.

[0001327567-16-000048:mdna:79]
Provision for (Benefit from) Income Taxes

[0001327567-16-000048:mdna:80]
Provision for (benefit from) income taxes consists primarily of income taxes in foreign jurisdictions in which we conduct business, withholding taxes, federal and state income taxes in the United States, and amortization of our deferred tax charges. We maintain a full valuation allowance for domestic deferred tax assets, including net operating loss carryforwards and tax credits.

[0001327567-16-000048:mdna:81]
|  | Three Months Ended January 31, |  | Six Months Ended January 31, |
|  | 2016 |  | 2015 |  | 2016 |  | 2015 |
|  | (dollars in millions) |
| Provision for (benefit from) income taxes | $ | 3.9 |  |  | $ | (0.7 | ) |  | $ | 8.2 |  |  | $ | 0.5 |  |
| Effective tax rate | (6.9 | )% |  | 1.6 | % |  | (8.9 | )% |  | (0.6 | )% |

[0001327567-16-000048:mdna:82]
We recorded an income tax provision for the three and six months ended January 31, 2016, due to federal, state, and foreign income taxes, withholding taxes, and amortization of our deferred tax charges. The provision for income taxes increased for the three and six months ended January 31, 2016 compared to the three and six months ended January 31, 2015, primarily due to an increase in non-deductible share-based compensation, changes in our valuation allowance against deferred tax assets, and amortization of our deferred tax charges.

[0001327567-16-000048:mdna:83]
[same as prior period, unchanged from 0001327567-15-000036:mdna:102]

[0001327567-16-000048:mdna:84]
[same as prior period, unchanged from 0001327567-15-000036:mdna:81]

[0001327567-16-000048:mdna:85]
|  | January 31, 2016 |  | July 31, 2015 |
|  | (in millions) |
| Working capital (1) | $ | 120.7 |  |  | $ | 41.8 |  |
| Cash, cash equivalents, and investments: |  |  |  |
| Cash and cash equivalents | $ | 413.2 |  |  | $ | 375.8 |  |
| Investments | 1,182.5 |  |  | 952.0 |  |
| Total cash, cash equivalents, and investments | $ | 1,595.7 |  |  | $ | 1,327.8 |  |

[0001327567-16-000048:mdna:86]
[same as prior period, unchanged from 0001327567-15-000036:mdna:83]

[0001327567-16-000048:mdna:87]
| (1) | The net carrying amount of the Notes was classified in current liabilities in our condensed consolidated balance sheets as of January 31, 2016 and July 31, 2015. Refer to Note 4. Convertible Senior Notes of Notes to Condensed Consolidated Financial Statements included in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information. |

[0001327567-16-000048:mdna:88]
At January 31, 2016, our total cash, cash equivalents, and investments of $1.6 billion were held for general corporate purposes, of which approximately $130.9 million was held outside of the United States. We do not provide for federal income taxes on the undistributed earnings of our foreign subsidiaries, all of which we expect to reinvest outside of the United States indefinitely. However, if these funds were needed for our domestic operations, we would be required to accrue and pay U.S. taxes on undistributed earnings of foreign subsidiaries. There are no other restrictions on the use of these funds. If we were to repatriate these earnings to the United States, any associated income tax liability would be insignificant.

[0001327567-16-000048:mdna:89]
In June 2014, we issued $575.0 million aggregate principal amount of 0.0% Convertible Senior Notes due 2019 (the “Notes”), which mature on July 1, 2019. Prior to January 1, 2019, holders may surrender their Notes for early conversion under certain circumstances. Upon conversion, we will pay cash equal to the aggregate principal amount of the Notes to be converted, and, at our election, will pay or deliver cash and/or shares of our common stock for the amount of our conversion obligation in excess of the aggregate principal amount of the Notes being converted. Refer to Note 4. Convertible Senior Notes of Notes to Condensed Consolidated Financial Statements included in Part I, Item 1 of this Quarterly Report on Form 10-Q for information on the Notes.

[0001327567-16-000048:mdna:90]
The following table summarizes our cash flows for the six months ended January 31, 2016 and 2015:

[0001327567-16-000048:mdna:91]
|  | Six Months Ended January 31, |
| 2016 |  | 2015 |
|  | (in millions) |
| Net cash provided by operating activities | $ | 300.5 |  |  | $ | 151.8 |  |
| Net cash used in investing activities | (284.7 | ) |  | (487.4 | ) |
| Net cash provided by financing activities | 21.6 |  |  | 24.8 |  |
| Net increase (decrease) in cash and cash equivalents | $ | 37.4 |  |  | $ | (310.8 | ) |

[0001327567-16-000048:mdna:92]
[same as prior period, unchanged from 0001327567-15-000036:mdna:91]

[0001327567-16-000048:mdna:93]
[same as prior period, unchanged from 0001327567-15-000036:mdna:92]

[0001327567-16-000048:mdna:94]
[same as prior period, unchanged from 0001327567-15-000036:mdna:93]

[0001327567-16-000048:mdna:95]
[same as prior period, unchanged from 0001327567-15-000036:mdna:94]

[0001327567-16-000048:mdna:96]
Cash provided by operating activities during the six months ended January 31, 2016 was $300.5 million, an increase of $148.7 million compared to the six months ended January 31, 2015. The increase was due to growth of our business and changes

[0001327567-16-000048:mdna:97]
[same as prior period, unchanged from 0001327567-15-000036:mdna:119]

[0001327567-16-000048:mdna:98]
in our assets and liabilities during the six months ended January 31, 2016, which included an increase in sales of subscription and support and maintenance contracts to new and existing customers as reflected by an increase in deferred revenue.

[0001327567-16-000048:mdna:99]
[same as prior period, unchanged from 0001327567-15-000036:mdna:96]

[0001327567-16-000048:mdna:100]
[same as prior period, unchanged from 0001327567-15-000036:mdna:97]

[0001327567-16-000048:mdna:101]
Cash used in investing activities during the six months ended January 31, 2016 was $284.7 million, a decrease of $202.7 million compared to the six months ended January 31, 2015, due to lower net purchases of available-for-sale investments, partially offset by an increase in investment in infrastructure and facilities to support the growth of our business.

[0001327567-16-000048:mdna:102]
[same as prior period, unchanged from 0001327567-15-000036:mdna:99]

[0001327567-16-000048:mdna:103]
[same as prior period, unchanged from 0001327567-15-000036:mdna:100]

[0001327567-16-000048:mdna:104]
Cash provided by financing activities during the six months ended January 31, 2016 was $21.6 million, a decrease of $3.2 million compared to the six months ended January 31, 2015, due to lower proceeds from the sale of shares through employee equity incentive plans.

[0001327567-16-000048:mdna:105]
[same as prior period, unchanged from 0001327567-15-000036:mdna:103]

[0001327567-16-000048:mdna:106]
The following table summarizes our contractual obligations and commitments as of January 31, 2016:

[0001327567-16-000048:mdna:107]
|  | Payments Due by Period |
|  | Total |  | Less Than 1 Year |  | 1 - 3 Years |  | 3 - 5 Years |  | More Than 5 Years |
|  |  |  | (in millions) |  |  |
| 0.0% Convertible Senior Notes due 2019 (1) | $ | 575.0 |  |  | $ | — |  |  | $ | — |  |  | $ | 575.0 |  |  | $ | — |  |
| Operating lease obligations (2) (3) | 503.5 |  |  | 24.6 |  |  | 61.5 |  |  | 93.8 |  |  | 323.6 |  |
| Purchase obligations (4) | 39.0 |  |  | 39.0 |  |  | — |  |  | — |  |  | — |  |
| Total (5) | $ | 1,117.5 |  |  | $ | 63.6 |  |  | $ | 61.5 |  |  | $ | 668.8 |  |  | $ | 323.6 |  |

[0001327567-16-000048:mdna:108]
[same as prior period, unchanged from 0001327567-15-000036:mdna:106]

[0001327567-16-000048:mdna:109]
| (1) | As of January 31, 2016, holders may convert their Notes at any time during the fiscal quarter ending April 30, 2016. Refer to Note 4. Convertible Senior Notes of Notes to Condensed Consolidated Financial Statements included in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information. |

[0001327567-16-000048:mdna:110]
| (2) | Consists of contractual obligations from our non-cancelable operating leases, including the lease agreement executed in October 2015 for additional corporate office space in Santa Clara, California. Refer to Note 5. Commitments and Contingencies of Notes to Condensed Consolidated Financial Statements included in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information. |

[0001327567-16-000048:mdna:111]
| (3) | Excludes contractual sublease proceeds of $6.6 million, of which $3.0 million will be received in less than one year and $3.6 million will be received in one to three years. |

[0001327567-16-000048:mdna:112]
[same as prior period, unchanged from 0001327567-15-000036:mdna:110]

[0001327567-16-000048:mdna:113]
| (5) | No amounts related to income taxes are included. As of January 31, 2016, we had approximately $42.2 million of tax liabilities recorded related to uncertainty in income tax positions. |

[0001327567-16-000048:mdna:114]
[same as prior period, unchanged from 0001327567-15-000036:mdna:112]

[0001327567-16-000048:mdna:115]
As of January 31, 2016, we did not have any relationships with unconsolidated organizations or financial partnerships, such as structured finance or special purpose entities that would have been established for the purpose of facilitating off-balance sheet arrangements or other contractually narrow or limited purposes.

[0001327567-16-000048:mdna:116]
- 24 -

[0001327567-16-000048:mdna:117]
Critical Accounting Estimates

[0001327567-16-000048:mdna:118]
[same as prior period, unchanged from 0001327567-15-000036:mdna:115]

[0001327567-16-000048:mdna:119]
We believe the critical accounting estimates discussed under Item 7, “Management’s Discussion and Analysis of Financial Condition and Results of Operations” in our Annual Report on Form 10-K filed with the SEC on September 17, 2015, reflect our more significant judgments and estimates used in the preparation of our condensed consolidated financial statements. There have been no significant changes to our critical accounting estimates as filed in such report.

[0001327567-16-000048:mdna:120]
[same as prior period, unchanged from 0001327567-15-000036:mdna:117]

[0001327567-16-000048:mdna:121]
[same as prior period, unchanged from 0001327567-15-000036:mdna:118]
