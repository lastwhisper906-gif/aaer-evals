# PANW notes — 0001327567-16-000048


## us-gaap:AvailableForSaleSecuritiesTextBlock

[0001327567-16-000048:notes:1]
The following tables summarize the unrealized gains and losses and fair value of our available-for-sale investments as of January 31, 2016 and July 31, 2015 (in millions):

[0001327567-16-000048:notes:2]
|  | January 31, 2016 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Estimated Fair Value |
| Certificates of deposit | $ | 5.4 |  |  | $ | — |  |  | $ | — |  |  | $ | 5.4 |  |
| Corporate debt securities | 294.9 |  |  | 0.1 |  |  | (0.5 | ) |  | 294.5 |  |
| U.S. government and agency securities | 882.9 |  |  | 0.2 |  |  | (0.5 | ) |  | 882.6 |  |
| Total | $ | 1,183.2 |  |  | $ | 0.3 |  |  | $ | (1.0 | ) |  | $ | 1,182.5 |  |

[0001327567-16-000048:notes:3]
[same as prior period, unchanged from 0001327567-15-000036:notes:3]


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001327567-16-000048:notes:4]
[same as prior period, unchanged from 0001327567-15-000036:notes:4]

[0001327567-16-000048:notes:5]
The accompanying condensed consolidated financial statements have been prepared in conformity with U.S. generally accepted accounting principles, consistent in all material respects with those applied in our Annual Report on Form 10-K for the fiscal year ended July 31, 2015, filed with the Securities and Exchange Commission on September 17, 2015. Our condensed consolidated financial statements include our accounts and our wholly owned subsidiaries. All significant intercompany balances and transactions have been eliminated in consolidation.

[0001327567-16-000048:notes:6]
Our condensed consolidated financial statements are unaudited, but include all adjustments of a normal recurring nature necessary for a fair presentation of our quarterly results. We have made estimates and judgments affecting the amounts reported in our condensed consolidated financial statements and the accompanying notes. The actual results that we experience may differ materially from our estimates. Certain prior period amounts have been reclassified to conform to current period presentation.

[0001327567-16-000048:notes:7]
Our condensed consolidated financial statements should be read in conjunction with the consolidated financial statements and related notes in our Annual Report on Form 10-K for the fiscal year ended July 31, 2015.


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock

[0001327567-16-000048:notes:8]
[same as prior period, unchanged from 0001327567-15-000036:notes:7]

[0001327567-16-000048:notes:9]
[same as prior period, unchanged from 0001327567-15-000036:notes:8]

[0001327567-16-000048:notes:10]
[same as prior period, unchanged from 0001327567-15-000036:notes:9]

[0001327567-16-000048:notes:11]
[same as prior period, unchanged from 0001327567-15-000036:notes:12]

[0001327567-16-000048:notes:12]
There have been no material changes to our significant accounting policies as of and for the six months ended January 31, 2016, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended July 31, 2015.

[0001327567-16-000048:notes:13]
[same as prior period, unchanged from 0001327567-15-000036:notes:14]

[0001327567-16-000048:notes:14]
In April 2015, the Financial Accounting Standards Board (“FASB”) issued new authoritative guidance on fees paid in a cloud computing arrangement. The standard requires customers in a cloud computing arrangement to evaluate whether the arrangement includes a software license. If the arrangement includes a software license, the customer should account for the software license element of the arrangement consistent with the acquisition of other software licenses. If the arrangement does not include a software license, the customer should account for the arrangement as a service contract. The standard is effective for us for our first quarter of fiscal 2017 and will be applied on either a prospective or retrospective basis. We are currently evaluating adoption methods and whether this standard will have a material impact on our condensed consolidated financial statements.

[0001327567-16-000048:notes:15]
[same as prior period, unchanged from 0001327567-15-000036:notes:16]

[0001327567-16-000048:notes:16]
[same as prior period, unchanged from 0001327567-15-000036:notes:17]


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001327567-16-000048:notes:17]
Commitments and Contingencies

[0001327567-16-000048:notes:18]
Leases

[0001327567-16-000048:notes:19]
We lease our facilities under various non-cancelable operating leases, which expire through the year ending July 31, 2028.

[0001327567-16-000048:notes:20]
In May 2015, we entered into three lease agreements for approximately 752,000 square feet of corporate office space in Santa Clara, California to serve as our future corporate headquarters. In October 2015, we entered into a fourth lease agreement for approximately 310,000 square feet of additional office space at the same location. The fourth lease will commence in December 2017 and expire in April 2028, however, the site is currently under construction and as a result, the lease commencement date may change based on progress of the construction project. The fourth lease agreement contains a rent holiday period, scheduled rent increases, lease incentives, and renewal options which allow the lease term to be extended through April 2046. Rental payments under the fourth lease agreement are approximately $101.2 million over the initial lease term. For more information on the three lease agreements entered into in May 2015, refer to Note 8. Commitments and Contingencies of Notes to Consolidated Financial Statements included in Part II, Item 8 of our Annual Report on Form 10-K for the fiscal year ended July 31, 2015.

[0001327567-16-000048:notes:21]
The following table presents details of the aggregate future non-cancelable minimum rental payments under our operating leases as of January 31, 2016 (in millions):

[0001327567-16-000048:notes:22]
|  | Amount |
| Fiscal years ending July 31: |  |
| Remaining 2016 | $ | 12.0 |  |
| 2017 | 25.0 |  |
| 2018 | 28.2 |  |
| 2019 | 41.8 |  |
| 2020 | 45.9 |  |
| 2021 and thereafter | 350.6 |  |
| Committed gross lease payments | 503.5 |  |
| Less: proceeds from sublease rental | 6.6 |  |
| Net operating lease obligation | $ | 496.9 |  |

[0001327567-16-000048:notes:23]
Contract Manufacturer Commitments

[0001327567-16-000048:notes:24]
Our independent contract manufacturer procures components and assembles our products based on our forecasts. These forecasts are based on estimates of demand for our products primarily for the next 12 months, which are in turn based on historical trends and an analysis from our sales and product marketing organizations, adjusted for overall market conditions. In order to reduce manufacturing lead times and plan for adequate supply, we may issue forecasts and orders for components and products that are non-cancelable. As of January 31, 2016, our purchase commitments under such orders were $39.0 million, excluding obligations under contracts that we can cancel without a significant penalty.

[0001327567-16-000048:notes:25]
Litigation

[0001327567-16-000048:notes:26]
We are subject to legal proceedings, claims, and litigation arising in the ordinary course of business, including intellectual property litigation. Such matters are subject to many uncertainties and outcomes are not predictable with assurance. We accrue for contingencies when we believe that a loss is probable and that we can reasonably estimate the amount of any such loss.

[0001327567-16-000048:notes:27]
To the extent there is a reasonable possibility that a loss exceeding amounts already recognized may be incurred and the amount of such additional loss would be material, we will either disclose the estimated additional loss or state that such an estimate cannot be made. As of January 31, 2016, we have not recorded any significant accruals for loss contingencies associated with such legal proceedings, determined that an unfavorable outcome is probable or reasonably possible, or determined that the amount or range of any possible loss is reasonably estimable.


## us-gaap:ConvertibleDebtTableTextBlock

[0001327567-16-000048:notes:28]
The following table sets forth the components of the Notes as of January 31, 2016 and July 31, 2015 (in millions):

[0001327567-16-000048:notes:29]
|  | January 31, 2016 |  | July 31, 2015 |
| Liability: |  |  |  |
| Principal | $ | 575.0 |  |  | $ | 575.0 |  |
| Less: debt discount, net of amortization | 77.5 |  |  | 87.9 |  |
| Net carrying amount | $ | 497.5 |  |  | $ | 487.1 |  |
| Equity (including temporary equity) | $ | (109.8 | ) |  | $ | (109.8 | ) |


## us-gaap:DebtDisclosureTextBlock

[0001327567-16-000048:notes:30]
Convertible Senior Notes

[0001327567-16-000048:notes:31]
On June 30, 2014, we issued $575.0 million aggregate principal amount of 0.0% Convertible Senior Notes due 2019 (the “Notes”). The Notes mature on July 1, 2019, unless converted or repurchased in accordance with their terms prior to such date. The Notes do not contain any financial covenants and we cannot redeem the Notes prior to maturity.

[0001327567-16-000048:notes:32]
The Notes are convertible for up to 5.2 million shares of our common stock at an initial conversion price of approximately $110.28 per share of common stock, subject to adjustment. Holders of the Notes may surrender their Notes for conversion at their option at any time prior to the close of business on the business day immediately preceding January 1, 2019, only under the following circumstances:

[0001327567-16-000048:notes:33]
| • | if the last reported sale price of our common stock for at least 20 trading days (whether or not consecutive) during a period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the conversion price for the Notes on each applicable trading day (the “sale price condition”); |

[0001327567-16-000048:notes:34]
| • | during the five business day period after any five consecutive trading day period, in which the trading price per $1,000 principal amount of Notes for each trading day of the measurement period was less than 98% of the product of the last reported sale price of our common stock and the conversion rate for the Notes on each such trading day (the “trading price condition”); or |

[0001327567-16-000048:notes:35]
| • | upon the occurrence of specified corporate events. |

[0001327567-16-000048:notes:36]
On or after January 1, 2019, holders may convert all or any portion of their Notes at any time prior to the close of business on the second scheduled trading day immediately preceding the maturity date regardless of the foregoing conditions. Upon conversion, holders will receive cash equal to the aggregate principal amount of the Notes to be converted, and, at our election, cash and/or shares of our common stock for any amounts in excess of the aggregate principal amount of the Notes being converted.

[0001327567-16-000048:notes:37]
The sale price condition was initially met during the fiscal quarter ended April 30, 2015. The sale price condition continued to be met through the fiscal quarter ended January 31, 2016, and as a result, holders may convert their Notes at any time during the fiscal quarter ending April 30, 2016. Accordingly, the net carrying amount of the Notes was classified in current liabilities and a portion of the equity component representing the conversion option was classified as temporary equity in our condensed consolidated balance sheets as of January 31, 2016. The portion of the equity component classified as temporary equity is measured as the difference between the principal and net carrying amount of the Notes.

[0001327567-16-000048:notes:38]
The total estimated fair value of the Notes was $840.2 million and $994.8 million at January 31, 2016 and July 31, 2015, respectively. The fair value was determined based on the closing trading price per $100 of the Notes as of the last day of trading for the period. We consider the fair value of the Notes at January 31, 2016 and July 31, 2015 to be a Level 2 measurement. The fair value of the Notes is primarily affected by the trading price of our common stock and market interest rates. As of January 31, 2016, the if-converted value of the Notes exceeded its principal amount by $278.7 million.

[0001327567-16-000048:notes:39]
The following table sets forth interest expense recognized related to the Notes (dollars in millions):

[0001327567-16-000048:notes:40]
|  | Three Months Ended January 31, |  | Six Months Ended January 31, |
|  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Amortization of debt discount | $ | 5.2 |  |  | $ | 5.0 |  |  | $ | 10.4 |  |  | $ | 10.0 |  |
| Amortization of debt issuance costs | 0.6 |  |  | 0.5 |  |  | 1.1 |  |  | 1.0 |  |
| Total interest expense recognized | $ | 5.8 |  |  | $ | 5.5 |  |  | $ | 11.5 |  |  | $ | 11.0 |  |
| Effective interest rate of the liability component | 4.8 | % |  | 4.8 | % |  | 4.8 | % |  | 4.8 | % |

[0001327567-16-000048:notes:41]
Note Hedges

[0001327567-16-000048:notes:42]
To minimize the impact of potential economic dilution upon conversion of the Notes, we entered into convertible note hedge transactions (the “Note Hedges”) with respect to our common stock concurrent with the issuance of the Notes. The Note Hedges cover up to 5.2 million shares of our common stock and are exercisable upon conversion of the Notes. The Note Hedges will expire upon maturity of the Notes. The Note Hedges are separate transactions and are not part of the terms of the Notes. Holders of the Notes will not have any rights with respect to the Note Hedges. The shares receivable related to the Note Hedges are excluded from the calculation of diluted earnings per share as they are antidilutive.

[0001327567-16-000048:notes:43]
Warrants

[0001327567-16-000048:notes:44]
Separately, but concurrently with our issuance of the Notes, we entered into transactions whereby we sold warrants (the “Warrants”) to acquire up to 5.2 million shares of our common stock at a strike price of approximately $137.85 per share, subject to adjustments. The shares issuable under the Warrants will be included in the calculation of diluted earnings per share when the average market value per share of our common stock for the reporting period exceeds the strike price of the Warrants. The Warrants are separate transactions and are not part of the Notes or Notes Hedges, and are not remeasured through earnings each reporting period. Holders of the Notes and Note Hedges will not have any rights with respect to the Warrants.

[0001327567-16-000048:notes:45]
For more information on the Notes, the Note Hedges, and the Warrants, refer to Note 7. Convertible Senior Notes of Notes to Consolidated Financial Statements included in Part II, Item 8 of our Annual Report on Form 10-K for the fiscal year ended July 31, 2015.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001327567-16-000048:notes:46]
[same as prior period, unchanged from 0001327567-15-000036:notes:47]

[0001327567-16-000048:notes:47]
[same as prior period, unchanged from 0001327567-15-000036:notes:48]

[0001327567-16-000048:notes:48]
[same as prior period, unchanged from 0001327567-15-000036:notes:49]

[0001327567-16-000048:notes:49]
|  | Options Outstanding |
|  | Number of Shares |  | Weighted- Average Exercise Price Per Share |  | Weighted- Average Remaining Contractual Term (Years) |  | Aggregate Intrinsic Value |
| Balance—July 31, 2015 | 3.3 |  |  | $ | 13.74 |  |  | 6.2 |  | $ | 562.9 |  |
| Options granted | — |  |  | — |  |  |  |  |  |
| Options forfeited | — |  |  | — |  |  |  |  |  |
| Options exercised | (0.8 | ) |  | 12.20 |  |  |  |  |  |
| Balance—January 31, 2016 | 2.5 |  |  | $ | 14.16 |  |  | 5.8 |  | $ | 339.9 |  |
| Options vested and expected to vest—January 31, 2016 | 2.5 |  |  | $ | 14.15 |  |  | 5.8 |  | $ | 339.7 |  |
| Options exercisable—January 31, 2016 | 2.3 |  |  | $ | 13.51 |  |  | 5.7 |  | $ | 316.3 |  |

[0001327567-16-000048:notes:50]
[same as prior period, unchanged from 0001327567-15-000036:notes:51]

[0001327567-16-000048:notes:51]
[same as prior period, unchanged from 0001327567-15-000036:notes:52]

[0001327567-16-000048:notes:52]
|  | RSUs Outstanding |
|  | Number of Shares |  | Weighted- Average Grant-Date Fair Value Per Share |  | Weighted- Average Remaining Contractual Term (Years) |  | Aggregate Intrinsic Value |
| Balance—July 31, 2015 | 7.2 |  |  | $ | 95.66 |  |  | 1.2 |  | $ | 1,334.8 |  |
| RSUs granted | 2.3 |  |  | 170.24 |  |  |  |  |  |
| RSUs vested | (1.7 | ) |  | 81.41 |  |  |  |  |  |
| RSUs forfeited | (0.3 | ) |  | 93.67 |  |  |  |  |  |
| Balance—January 31, 2016 | 7.5 |  |  | $ | 121.61 |  |  | 1.2 |  | $ | 1,117.5 |  |
| RSUs vested and expected to vest—January 31, 2016 | 7.1 |  |  | $ | 120.88 |  |  | 1.2 |  | $ | 1,057.1 |  |

[0001327567-16-000048:notes:53]
Restricted Stock Award (RSA) Activities

[0001327567-16-000048:notes:54]
During the three months ended January 31, 2016, we issued 1.1 million restricted shares of common stock to our employees with a grant-date fair value of $170.97 per share. The awards will vest over a period of three years from the date of grant. As of January 31, 2016, all of the restricted shares of common stock remained unvested and outstanding.

[0001327567-16-000048:notes:55]
[same as prior period, unchanged from 0001327567-15-000036:notes:54]

[0001327567-16-000048:notes:56]
[same as prior period, unchanged from 0001327567-15-000036:notes:55]

[0001327567-16-000048:notes:57]
|  | Three Months Ended January 31, |  | Six Months Ended January 31, |
|  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Cost of product revenue | $ | 1.6 |  |  | $ | 1.0 |  |  | $ | 2.9 |  |  | $ | 1.7 |  |
| Cost of services revenue | 10.5 |  |  | 5.1 |  |  | 17.5 |  |  | 8.6 |  |
| Research and development | 34.9 |  |  | 19.0 |  |  | 59.9 |  |  | 33.0 |  |
| Sales and marketing | 39.4 |  |  | 21.7 |  |  | 66.6 |  |  | 37.5 |  |
| General and administrative | 15.5 |  |  | 10.1 |  |  | 27.9 |  |  | 14.6 |  |
| Total | $ | 101.9 |  |  | $ | 56.9 |  |  | $ | 174.8 |  |  | $ | 95.4 |  |

[0001327567-16-000048:notes:58]
At January 31, 2016, total compensation cost related to unvested share-based awards not yet recognized was $924.1 million, net of estimated forfeitures. This cost is expected to be amortized on a straight-line basis over a weighted-average period of approximately three years.


## us-gaap:EarningsPerShareTextBlock

[0001327567-16-000048:notes:59]
[same as prior period, unchanged from 0001327567-15-000036:notes:58]

[0001327567-16-000048:notes:60]
[same as prior period, unchanged from 0001327567-15-000036:notes:59]

[0001327567-16-000048:notes:61]
[same as prior period, unchanged from 0001327567-15-000036:notes:60]

[0001327567-16-000048:notes:62]
|  | Three Months Ended |  | Six Months Ended |
|  | January 31, |  | January 31, |
|  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Net loss | $ | (62.5 | ) |  | $ | (43.0 | ) |  | $ | (101.2 | ) |  | $ | (73.1 | ) |
| Weighted-average shares used to compute net loss per share, basic and diluted | 86.6 |  |  | 80.8 |  |  | 85.8 |  |  | 80.1 |  |
| Net loss per share, basic and diluted | $ | (0.72 | ) |  | $ | (0.53 | ) |  | $ | (1.18 | ) |  | $ | (0.91 | ) |

[0001327567-16-000048:notes:63]
[same as prior period, unchanged from 0001327567-15-000036:notes:62]

[0001327567-16-000048:notes:64]
|  | Three and Six Months Ended |
|  | January 31, |
|  | 2016 |  | 2015 |
| RSUs | 7.5 |  |  | 7.7 |  |
| Convertible senior notes | 5.2 |  |  | 5.2 |  |
| Warrants related to the issuance of convertible senior notes | 5.2 |  |  | 5.2 |  |
| Options to purchase common stock | 2.5 |  |  | 4.5 |  |
| RSAs | 1.1 |  |  | — |  |
| ESPP shares | 0.1 |  |  | 0.1 |  |
| Total | 21.6 |  |  | 22.7 |  |


## us-gaap:FairValueAssetsAndLiabilitiesMeasuredOnRecurringAndNonrecurringBasisTableTextBlock

[0001327567-16-000048:notes:65]
The following table presents the fair value of our financial assets and liabilities using the above input categories as of January 31, 2016 and July 31, 2015 (in millions):

[0001327567-16-000048:notes:66]
|  |  | January 31, 2016 |  | July 31, 2015 |
|  |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Short-term investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Certificates of deposit |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1.0 |  |  | $ | — |  |  | $ | 1.0 |  |
| Corporate debt securities |  | — |  |  | 127.3 |  |  | — |  |  | 127.3 |  |  | — |  |  | 97.8 |  |  | — |  |  | 97.8 |  |
| U.S. government and agency securities |  | — |  |  | 424.1 |  |  | — |  |  | 424.1 |  |  | — |  |  | 314.4 |  |  | — |  |  | 314.4 |  |
| Total short-term investments |  | — |  |  | 551.4 |  |  | — |  |  | 551.4 |  |  | — |  |  | 413.2 |  |  | — |  |  | 413.2 |  |
| Long-term investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Certificates of deposit |  | — |  |  | 5.4 |  |  | — |  |  | 5.4 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Corporate debt securities |  | — |  |  | 167.2 |  |  | — |  |  | 167.2 |  |  | — |  |  | 92.9 |  |  | — |  |  | 92.9 |  |
| U.S. government and agency securities |  | — |  |  | 458.5 |  |  | — |  |  | 458.5 |  |  | — |  |  | 445.9 |  |  | — |  |  | 445.9 |  |
| Total long-term investments |  | — |  |  | 631.1 |  |  | — |  |  | 631.1 |  |  | — |  |  | 538.8 |  |  | — |  |  | 538.8 |  |
| Total assets measured at fair value |  | $ | — |  |  | $ | 1,182.5 |  |  | $ | — |  |  | $ | 1,182.5 |  |  | $ | — |  |  | $ | 952.0 |  |  | $ | — |  |  | $ | 952.0 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001327567-16-000048:notes:67]
[same as prior period, unchanged from 0001327567-15-000036:notes:66]

[0001327567-16-000048:notes:68]
[same as prior period, unchanged from 0001327567-15-000036:notes:67]

[0001327567-16-000048:notes:69]
[same as prior period, unchanged from 0001327567-15-000036:notes:68]

[0001327567-16-000048:notes:70]
[same as prior period, unchanged from 0001327567-15-000036:notes:69]

[0001327567-16-000048:notes:71]
[same as prior period, unchanged from 0001327567-15-000036:notes:70]

[0001327567-16-000048:notes:72]
Refer to Note 4. Convertible Senior Notes for the carrying amount and estimated fair value of our convertible senior notes as of January 31, 2016.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001327567-16-000048:notes:73]
[same as prior period, unchanged from 0001327567-15-000036:notes:72]

[0001327567-16-000048:notes:74]
Our provision for income taxes for the three and six months ended January 31, 2016 reflects an effective tax rate of (6.9)% and (8.9)%, respectively. Our effective tax rates for these periods were negative as we recorded a provision for income taxes on quarter and year to date losses. The key components of our income tax provision primarily consist of foreign income taxes, withholding taxes, U.S. federal and state income taxes, and amortization of our deferred tax charges. Our effective tax rate differs from the U.S. statutory tax rate primarily due to foreign tax losses which derive no benefit, non-deductible share-based compensation, and changes in our valuation allowance. As compared to the same periods last year, our effective tax rate changed primarily due to an increase in non-deductible share-based compensation, changes in our valuation allowance against deferred tax assets, and amortization of our deferred tax charges.

[0001327567-16-000048:notes:75]
Our provision for (benefit from) income taxes for the three and six months ended January 31, 2015 reflects an effective tax rate of 1.6% and (0.6)%, respectively. Our effective tax rate for the six months ended January 31, 2015 was negative as we recorded a provision for income taxes on year to date losses. Our effective tax rate differs from the U.S. statutory tax rate primarily due to foreign tax losses which derive no benefit, non-deductible share-based compensation, and foreign income and withholding taxes.

[0001327567-16-000048:notes:76]
In December 2015, the Protecting Americans from Tax Hikes Act of 2015 (the “PATH Act”) was signed into law. Among its provisions, the PATH Act retroactively extends the bonus depreciation and other corporate tax incentives through December 31, 2019, and permanently extends the federal research and development credit. The adjustment to our deferred tax assets as a result of the PATH Act was fully offset by our valuation allowance. The income tax benefit derived from the PATH Act for the fiscal year ending July 31, 2016 is dependent on actual results for the year.


## us-gaap:InvestmentsClassifiedByContractualMaturityDateTableTextBlock

[0001327567-16-000048:notes:77]
The following table summarizes the amortized cost and fair value of our available-for-sale investments as of January 31, 2016, by contractual years-to-maturity (in millions):

[0001327567-16-000048:notes:78]
|  | Amortized Cost |  | Fair Value |
| Due within one year | $ | 551.6 |  |  | $ | 551.4 |  |
| Due between one and three years | 631.6 |  |  | 631.1 |  |
| Total | $ | 1,183.2 |  |  | $ | 1,182.5 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001327567-16-000048:notes:79]
Investments

[0001327567-16-000048:notes:80]
Unrealized losses related to these investments are due to interest rate fluctuations as opposed to credit quality. In addition, we do not intend to sell and it is not likely that we would be required to sell these investments before recovery of their amortized cost basis, which may be at maturity. As a result, there were no other-than-temporary impairments for these investments at January 31, 2016 and July 31, 2015.
