# PANW 8-K — 0001327567-16-000044 filed 2016-02-25

## item codes, every 8-K on or before 2016-02-26

- 2016-02-25 0001327567-16-000044 — 2.02, 5.02, 9.01
- 2015-12-14 0001327567-15-000038 — 5.07
- 2015-12-14 0001193125-15-402588 — 1.01, 9.01
- 2015-11-23 0001327567-15-000033 — 2.02, 9.01
- 2015-10-19 0001193125-15-347005 — 1.01, 9.01 — amendment, the index does not say of what
- 2015-09-09 0001327567-15-000022 — 2.02, 9.01
- 2015-08-19 0001193125-15-296115 — 1.01, 2.03
- 2015-06-01 0001193125-15-207786 — 1.01, 2.03
- 2015-05-27 0001327567-15-000015 — 2.02, 9.01
- 2015-03-02 0001327567-15-000006 — 2.02, 9.01
- 2014-12-15 0001327567-14-000046 — 5.07
- 2014-11-24 0001327567-14-000040 — 2.02, 9.01
- 2014-09-22 0001193125-14-348581 — 5.02, 9.01
- 2014-09-09 0001327567-14-000025 — 2.02, 9.01
- 2014-07-01 0001193125-14-257824 — 1.01, 2.03, 3.02, 9.01
- 2014-06-26 0001193125-14-249529 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2014-06-20 0001327567-14-000020 — 9.01 — amendment of 0001193125-14-140511
- 2014-06-04 0001327567-14-000016 — 3.02
- 2014-05-30 0001193125-14-218158 — 2.02 — amendment, the index does not say of what
- 2014-05-28 0001193125-14-215060 — 1.01, 2.02, 3.02, 9.01
- 2014-04-11 0001193125-14-140511 — 2.01, 3.02, 7.01, 9.01
- 2014-03-24 0001193125-14-111318 — 1.01, 3.02, 7.01, 9.01
- 2014-03-13 0001327567-14-000009 — 5.02
- 2014-02-24 0001193125-14-063754 — 2.02, 9.01
- 2013-12-12 0001327567-13-000040 — 5.07
- 2013-11-25 0001327567-13-000033 — 2.02, 9.01
- 2013-09-30 0001193125-13-384966 — 8.01
- 2013-09-09 0001193125-13-361421 — 2.02, 9.01
- 2013-05-30 0001193125-13-241542 — 2.02, 5.02, 9.01
- 2013-03-11 0001193125-13-101082 — 5.02, 9.01
- 2013-02-28 0001193125-13-084193 — 2.02, 9.01
- 2012-12-14 0001193125-12-503335 — 5.07
- 2012-12-06 0001193125-12-493700 — 2.02, 9.01
- 2012-09-24 0001193125-12-401534 — 1.01, 2.03
- 2012-09-20 0001193125-12-398433 — 5.02, 9.01
- 2012-09-10 0001193125-12-386605 — 2.02, 9.01

## late-filing notifications on or before 2016-02-26

- none on or before 2016-02-26

## item 2.02 — earnings release, exhibit 99.1

[0001327567-16-000044:8k_2_02:1]
EX-99.1
3
ex991q216earningsrelease.htm
EXHIBIT 99.1

[0001327567-16-000044:8k_2_02:2]
Exhibit

[0001327567-16-000044:8k_2_02:3]
Exhibit 99.1

[0001327567-16-000044:8k_2_02:4]
Palo Alto Networks Reports Fiscal Second Quarter 2016 Financial Results

[0001327567-16-000044:8k_2_02:5]
| • | Fiscal second quarter total revenue grows 54 percent year-over-year to $334.7 million |

[0001327567-16-000044:8k_2_02:6]
| • | Fiscal second quarter billings grow 62 percent year-over-year to $459.0 million |

[0001327567-16-000044:8k_2_02:7]
| • | Fiscal second quarter cash flow from operations grows 100 percent year-over-year to $153.8 million and free cash flow grows 93 percent year-over-year to $136.4 million |

[0001327567-16-000044:8k_2_02:8]
SANTA CLARA, Calif., February 25, 2016 - Palo Alto Networks (NYSE: PANW), the next-generation security company, today announced financial results for its fiscal second quarter 2016 ended January 31, 2016.

[0001327567-16-000044:8k_2_02:9]
Total revenue for the fiscal second quarter 2016 grew 54 percent year-over-year to a record $334.7 million, compared with total revenue of $217.7 million for the fiscal second quarter 2015. GAAP net loss for the fiscal second quarter 2016 was $62.5 million, or $0.72 per diluted share, compared with GAAP net loss of $43.0 million, or $0.53 per diluted share, for the fiscal second quarter 2015.

[0001327567-16-000044:8k_2_02:10]
Non-GAAP net income for the fiscal second quarter 2016 was $36.3 million, or $0.40 per diluted share, compared with non-GAAP net income of $16.9 million, or $0.19 per diluted share, for the fiscal second quarter 2015. A reconciliation between GAAP and non-GAAP information is contained in the tables below.

[0001327567-16-000044:8k_2_02:11]
“We reported strong fiscal second quarter results across all metrics, including record revenue of $334.7 million, which increased 54 percent year-over-year. We are proud to now be serving more than 30,000 customers globally who are rapidly adopting the prevention capabilities of our Next-Generation Platform to achieve superior security, simplify their networks and greatly improve total cost of ownership,” said Mark McLaughlin, president and chief executive officer of Palo Alto Networks. “Security is a critical aspect of the digital age and a strategic priority embedded in all technology decisions for enterprises and organizations around the world.”

[0001327567-16-000044:8k_2_02:12]
“During the quarter we saw broad adoption of all aspects of our Next-Generation Security Platform with particular strength in our subscription services,” said Steffan Tomlinson, chief financial officer of Palo Alto Networks. “Our results demonstrate our commitment to balancing high growth and profitability as well as the increasing strength in free cash flow from our hybrid-SaaS model.”

[0001327567-16-000044:8k_2_02:13]
Recent Highlights

[0001327567-16-000044:8k_2_02:14]
| • | Partnered with Proofpoint – Palo Alto Networks and Proofpoint teamed up to share intelligence on sophisticated attacks, enabling the creation of automated and coordinated protection across both Palo Alto Networks Next-Generation Security Platform and Proofpoint Targeted Attack Protection and Proofpoint SocialPatrol. Palo Alto Networks WildFire automatically generates new protections and distributes them to all WildFire subscribers globally. |

[0001327567-16-000044:8k_2_02:15]
| • | Recognized by J.D. Power and TSIA for exceptional support services – This recognition underscores the exceptional customer support we offer, including new certifications under the esteemed J.D. Power Certified Assisted Technical Support Program and TSIA “Outstanding Worldwide” rating.* |

[0001327567-16-000044:8k_2_02:16]
| • | Expanded Common Criteria certifications – Adding to the validation of our products’ security capabilities, these certifications of our newest firewall devices with the latest rigorous National Information Assurance Partnership protection profiles set a consistent confidence bar for government and critical infrastructure customer organizations. |

[0001327567-16-000044:8k_2_02:17]
| • | Extended our cloud ecosystem presence – To help organizations seamlessly secure an OpenStack cloud infrastructure with next-generation security, we announced a partnership with Mirantis and made our platform available as a virtual network function within Mirantis OpenStack. |

[0001327567-16-000044:8k_2_02:18]
| • | Appointed Frank Calderoni to the Board of Directors – Mr. Calderoni joined our audit committee and brings a wealth of valuable experience cultivated from his previous and current executive and board positions at some of the world’s leading technology companies. |

[0001327567-16-000044:8k_2_02:19]
Financial Outlook

[0001327567-16-000044:8k_2_02:20]
Palo Alto Networks provides guidance based on current market conditions and expectations.

[0001327567-16-000044:8k_2_02:21]
___________

[0001327567-16-000044:8k_2_02:22]
* Claim:  Palo Alto Networks, Inc. North America Assisted Support has been recognized by J.D. Power for providing outstanding customer service for its Assisted Technical Support.

[0001327567-16-000044:8k_2_02:23]
Disclaimer:  J.D. Power 2015 Certified Assisted Technical Support Program, developed in conjunction with TSIA. Based on successful completion of an audit and exceeding a customer satisfaction benchmark for assisted support operations. For more information, visit www.jdpower.com or www.tsia.com.

[0001327567-16-000044:8k_2_02:24]
2

[0001327567-16-000044:8k_2_02:25]
For the fiscal third quarter 2016, we expect:

[0001327567-16-000044:8k_2_02:26]
| • | Total revenue in the range of $335 to $339 million, representing year-over-year growth between 43 percent and 45 percent. |

[0001327567-16-000044:8k_2_02:27]
| • | Diluted non-GAAP earnings per share in the range of $0.41 to $0.42 using 90 to 92 million shares. |

[0001327567-16-000044:8k_2_02:28]
| • | Free cash flow margin of approximately 40 percent. |

[0001327567-16-000044:8k_2_02:29]
Guidance for non-GAAP financial measures excludes share-based compensation and related payroll taxes, acquisition related costs, amortization expense of acquired intangible assets, litigation related charges including legal settlements, non-cash interest expense related to our convertible senior notes, the foreign currency gains (losses) and tax effects associated with these items, and certain non-recurring expenses. We have not reconciled diluted non-GAAP earnings per share guidance to GAAP net income (loss) per diluted share because we do not provide guidance on GAAP net income (loss) or the various reconciling cash and non-cash items between GAAP net income (loss) and non-GAAP net income (loss). We have not reconciled non-GAAP free cash flow margin to GAAP cash provided by operating activities because we do not provide guidance on GAAP cash provided by operating activities or purchases of property, equipment, and other assets. Certain items that impact these measures are subject to variability that are not entirely within our control. Accordingly, a reconciliation of the non-GAAP financial measure guidance to the corresponding GAAP measures is not available without unreasonable effort.

[0001327567-16-000044:8k_2_02:30]
Conference Call Information

[0001327567-16-000044:8k_2_02:31]
Palo Alto Networks will host a conference call for analysts and investors to discuss its fiscal second quarter 2016 results and outlook for its fiscal third quarter 2016 today at 4:30 PM Eastern time/1:30 PM Pacific time. Open to the public, investors may access the call by dialing 1-877-681-3374 or 1-719-325-4907 and using conference ID 6229459. A live audio webcast of the conference call along with supplemental financial information will also be accessible from the “Investors” section of our website at investors.paloaltonetworks.com. Following the webcast, an archived version will be available on our website for one year. A telephonic replay of the call will be available three hours after the call and will run for ten days and may be accessed by dialing 1-888-203-1112 or 1-719-457-0820 and entering the passcode 6229459.

[0001327567-16-000044:8k_2_02:32]
Forward-Looking Statements

[0001327567-16-000044:8k_2_02:33]
This press release contains forward-looking statements that involve risks and uncertainties, including statements regarding our financial outlook for the fiscal third quarter of 2016, our commitment to balancing high growth and profitability, as well as the increasing strength in free cash flow from our

[0001327567-16-000044:8k_2_02:34]
hybrid-SaaS model. There are a significant number of factors that could cause actual results to differ materially from statements made in this press release, including: our limited operating history; risks associated with managing our rapid growth, particularly outside of the United States; our limited experience with new product introductions and the risks associated with new products, including software bugs; the failure to timely develop and achieve market acceptance of new products as well as existing products and services; rapidly evolving technological developments in the market for network security products; and general market, political, economic and business conditions.

[0001327567-16-000044:8k_2_02:35]
Additional risks and uncertainties that could affect our financial results are included under the captions “Risk Factors” and “Management’s Discussion and Analysis of Financial Condition and Results of Operations” in our Quarterly Report on Form 10-Q filed with the SEC on November 24, 2015, which is available on our website at investors.paloaltonetworks.com and on the SEC’s website at www.sec.gov. Additional information will also be set forth in other filings that we make with the SEC from time to time. All forward-looking statements in this press release are based on information available to us as of the date hereof, and we do not assume any obligation to update the forward-looking statements provided to reflect events that occur or circumstances that exist after the date on which they were made.

[0001327567-16-000044:8k_2_02:36]
Non-GAAP Financial Measures

[0001327567-16-000044:8k_2_02:37]
Palo Alto Networks has provided in this press release financial information that has not been prepared in accordance with generally accepted accounting principles in the United States (GAAP). The company uses these non-GAAP financial measures internally in analyzing its financial results and believes that the use of these non-GAAP financial measures is useful to investors as an additional tool to evaluate ongoing operating results and trends and in comparing the company’s financial results with other companies in its industry, many of which present similar non-GAAP financial measures.

[0001327567-16-000044:8k_2_02:38]
Non-GAAP financial measures are not meant to be considered in isolation or as a substitute for comparable GAAP financial measures, and should be read only in conjunction with the company’s consolidated financial statements prepared in accordance with GAAP. A reconciliation of the company’s historical non-GAAP financial measures to their most directly comparable GAAP measures has been provided in the financial statement tables included in this press release, and investors are encouraged to review the reconciliation.

[0001327567-16-000044:8k_2_02:39]
Non-GAAP net income and net income per share, diluted. Palo Alto Networks defines non-GAAP net income as net income (loss) plus share-based compensation related charges including share-based payroll

[0001327567-16-000044:8k_2_02:40]
4

[0001327567-16-000044:8k_2_02:41]
tax expense, amortization expense of acquired intangible assets, litigation related charges including legal settlements, non-cash interest expense related to the company’s convertible senior notes, and intellectual property restructuring related charges. The company also excludes from non-GAAP net income the foreign currency gains (losses) and tax effects associated with these items in order to provide a complete picture of the company’s recurring core business operating results. The company defines non-GAAP net income per share, diluted, as non-GAAP net income divided by the weighted average diluted shares outstanding after giving effect to the anti-dilutive impact of the company’s note hedge agreements, which reduces the potential economic dilution that otherwise would occur upon conversion of the company’s convertible senior notes. Under GAAP, the anti-dilutive impact of the note hedge is not reflected in diluted shares outstanding. Palo Alto Networks believes that excluding these items from non-GAAP net income and non-GAAP net income per share, diluted, provides management and investors with greater visibility into the underlying performance of the company’s core business operating results, meaning its operating performance excluding these items and, from time to time, other discrete charges that are infrequent in nature, over multiple periods.

[0001327567-16-000044:8k_2_02:42]
Billings. Palo Alto Networks defines billings as total revenue plus the change in deferred revenue during the period. The company considers billings to be a key measure used by management to manage the company’s business given the company’s hybrid SaaS revenue model, and believes billings provides investors with an important indicator of the health and visibility of the company’s business because it includes services revenue, which is recognized ratably over the subscription period or the period in which the services are expected to be performed, as the case may be, and product revenue, which is recognized at the time of shipment, provided that all other revenue recognition criteria have been met. The company considers billings to be a useful metric for management and investors, particularly if sales of subscriptions continue to increase and the company experiences strong renewal rates for subscriptions and support and maintenance.

[0001327567-16-000044:8k_2_02:43]
Free cash flow and free cash flow margin. Palo Alto Networks defines free cash flow as cash provided by operating activities less purchases of property, equipment, and other assets. Palo Alto Networks defines free cash flow margin as free cash flow as a percentage of total revenue. The company considers free cash flow and free cash flow margin to be profitability and liquidity measures that provide useful information to management and investors about the amount of cash generated by the business that, after the purchases of property, equipment, and other assets, can be used for strategic opportunities, including investing in our business, making strategic acquisitions, and strengthening the balance sheet.

[0001327567-16-000044:8k_2_02:44]
Investors are cautioned that there are a number of limitations associated with the use of non-GAAP financial measures as an analytical tool. In particular, the billings metric reported by the company includes amounts that have not yet been recognized as revenue and the free cash flow measure does not represent the total increase or decrease in our cash balance for the period. In addition, many of the adjustments to the company’s GAAP financial measures reflect the exclusion of items that are recurring and will be reflected in the company’s financial results for the foreseeable future, such as share-based compensation, which is an important part of Palo Alto Networks employees’ compensation and impacts their performance. Furthermore, the components that Palo Alto Networks excludes in its calculation of non-GAAP financial measures may differ from the components that its peer companies exclude when they report their non-GAAP results of operations. Palo Alto Networks compensates for these limitations by providing specific information regarding the GAAP amounts excluded from these non-GAAP financial measures. In the future, the company may also exclude non-recurring expenses and other expenses that do not reflect the company’s core business operating results.

[0001327567-16-000044:8k_2_02:45]
About Palo Alto Networks

[0001327567-16-000044:8k_2_02:46]
Palo Alto Networks is the next-generation security company, leading a new era in cybersecurity by safely enabling applications and preventing cyber breaches for tens of thousands of organizations worldwide. Built with an innovative approach and highly differentiated cyberthreat prevention capabilities, our game-changing security platform delivers security far superior to legacy or point products, safely enables daily business operations, and protects an organization’s most valuable assets. Find out more at www.paloaltonetworks.com.

[0001327567-16-000044:8k_2_02:47]
Palo Alto Networks and the Palo Alto Networks Logo are trademarks of Palo Alto Networks, Inc. in the United States and in jurisdictions throughout the world. All other trademarks, trade names or service marks used or mentioned herein belong to their respective owners.

[0001327567-16-000044:8k_2_02:48]
Media Contact:

[0001327567-16-000044:8k_2_02:49]
Jennifer Jasper Smith

[0001327567-16-000044:8k_2_02:50]
Head of Corporate Communications

[0001327567-16-000044:8k_2_02:51]
Palo Alto Networks

[0001327567-16-000044:8k_2_02:52]
408-638-3280

[0001327567-16-000044:8k_2_02:53]
jjsmith@paloaltonetworks.com

[0001327567-16-000044:8k_2_02:54]
Investor Relations Contact:

[0001327567-16-000044:8k_2_02:55]
Kelsey Turcotte

[0001327567-16-000044:8k_2_02:56]
Vice President of Investor Relations

[0001327567-16-000044:8k_2_02:57]
Palo Alto Networks

[0001327567-16-000044:8k_2_02:58]
408-753-3872

[0001327567-16-000044:8k_2_02:59]
kturcotte@paloaltonetworks.com

[0001327567-16-000044:8k_2_02:60]
7

[0001327567-16-000044:8k_2_02:61]
| Palo Alto Networks, Inc. |
| Preliminary Condensed Consolidated Statements of Operations |
| (In millions, except per share data) |
| (Unaudited) |
|  | Three Months Ended January 31, |  | Six Months Ended January 31, |
|  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Revenue: |  |  |  |  |  |  |  |
| Product | $ | 169.9 |  |  | $ | 115.6 |  |  | $ | 317.6 |  |  | $ | 217.1 |  |
| Services | 164.8 |  |  | 102.1 |  |  | 314.3 |  |  | 192.9 |  |
| Total revenue | 334.7 |  |  | 217.7 |  |  | 631.9 |  |  | 410.0 |  |
| Cost of revenue: |  |  |  |  |  |  |  |
| Product | 44.9 |  |  | 30.7 |  |  | 83.7 |  |  | 59.8 |  |
| Services | 49.3 |  |  | 28.7 |  |  | 89.7 |  |  | 53.0 |  |
| Total cost of revenue | 94.2 |  |  | 59.4 |  |  | 173.4 |  |  | 112.8 |  |
| Total gross profit | 240.5 |  |  | 158.3 |  |  | 458.5 |  |  | 297.2 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 74.0 |  |  | 47.0 |  |  | 133.7 |  |  | 84.3 |  |
| Sales and marketing | 187.6 |  |  | 122.8 |  |  | 345.9 |  |  | 229.2 |  |
| General and administrative | 34.2 |  |  | 27.0 |  |  | 65.0 |  |  | 46.0 |  |
| Total operating expenses | 295.8 |  |  | 196.8 |  |  | 544.6 |  |  | 359.5 |  |
| Operating loss | (55.3 | ) |  | (38.5 | ) |  | (86.1 | ) |  | (62.3 | ) |
| Interest expense | (5.8 | ) |  | (5.5 | ) |  | (11.6 | ) |  | (11.0 | ) |
| Other income, net | 2.5 |  |  | 0.3 |  |  | 4.7 |  |  | 0.7 |  |
| Loss before income taxes | (58.6 | ) |  | (43.7 | ) |  | (93.0 | ) |  | (72.6 | ) |
| Provision for (benefit from) income taxes | 3.9 |  |  | (0.7 | ) |  | 8.2 |  |  | 0.5 |  |
| Net loss | $ | (62.5 | ) |  | $ | (43.0 | ) |  | $ | (101.2 | ) |  | $ | (73.1 | ) |
| Net loss per share, basic and diluted | $ | (0.72 | ) |  | $ | (0.53 | ) |  | $ | (1.18 | ) |  | $ | (0.91 | ) |
| Weighted-average shares used to compute net loss per share, basic and diluted | 86.6 |  |  | 80.8 |  |  | 85.8 |  |  | 80.1 |  |

[0001327567-16-000044:8k_2_02:62]
| Palo Alto Networks, Inc. |
| Reconciliation of GAAP to Non-GAAP Financial Measures |
| (In millions, except per share amounts) |
| (Unaudited) |
|  | Three Months Ended January 31, |  | Six Months Ended January 31, |
|  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| GAAP net loss | $ | (62.5 | ) |  | $ | (43.0 | ) |  | $ | (101.2 | ) |  | $ | (73.1 | ) |
| Share-based compensation related charges | 106.9 |  |  | 60.6 |  |  | 182.1 |  |  | 100.2 |  |
| Amortization expense of acquired intangible assets | 2.1 |  |  | 1.8 |  |  | 4.2 |  |  | 3.3 |  |
| Litigation related charges | 3.0 |  |  | 3.0 |  |  | 6.1 |  |  | 6.1 |  |
| Non-cash interest expense related to convertible notes | 5.7 |  |  | 5.5 |  |  | 11.5 |  |  | 11.0 |  |
| Foreign currency gain associated with non-GAAP adjustments | (0.7 | ) |  | — |  |  | (1.5 | ) |  | (0.1 | ) |
| Income tax and other tax adjustments related to the above | (18.2 | ) |  | (11.0 | ) |  | (33.3 | ) |  | (17.7 | ) |
| Non-GAAP net income | $ | 36.3 |  |  | $ | 16.9 |  |  | $ | 67.9 |  |  | $ | 29.7 |  |
| GAAP net loss per share, diluted | $ | (0.72 | ) |  | $ | (0.53 | ) |  | $ | (1.18 | ) |  | $ | (0.91 | ) |
| Share-based compensation related charges | 1.21 |  |  | 0.73 |  |  | 2.08 |  |  | 1.22 |  |
| Amortization expense of acquired intangible assets | 0.02 |  |  | 0.02 |  |  | 0.05 |  |  | 0.04 |  |
| Litigation related charges | 0.04 |  |  | 0.04 |  |  | 0.07 |  |  | 0.08 |  |
| Non-cash interest expense related to convertible notes | 0.07 |  |  | 0.07 |  |  | 0.13 |  |  | 0.14 |  |
| Foreign currency gain associated with non-GAAP adjustments | (0.01 | ) |  | 0.00 |  |  | (0.02 | ) |  | 0.00 |  |
| Income tax and other tax adjustments related to the above | (0.21 | ) |  | (0.14 | ) |  | (0.39 | ) |  | (0.22 | ) |
| Non-GAAP net income per share, diluted | $ | 0.40 |  |  | $ | 0.19 |  |  | $ | 0.74 |  |  | $ | 0.35 |  |
| GAAP weighted-average shares used to compute net loss per share, diluted | 86.6 |  |  | 80.8 |  |  | 85.8 |  |  | 80.1 |  |
| Weighted-average effect of potentially dilutive securities [a] | 5.1 |  |  | 5.8 |  |  | 5.4 |  |  | 5.7 |  |
| Non-GAAP weighted-average shares used to compute net income per share, diluted | 91.7 |  |  | 86.6 |  |  | 91.2 |  |  | 85.8 |  |
| Revenue | $ | 334.7 |  |  | $ | 217.7 |  |  | $ | 631.9 |  |  | $ | 410.0 |  |
| Change in deferred revenue | 124.3 |  |  | 65.1 |  |  | 215.1 |  |  | 113.3 |  |
| Billings | $ | 459.0 |  |  | $ | 282.8 |  |  | $ | 847.0 |  |  | $ | 523.3 |  |
| Net cash provided by operating activities | $ | 153.8 |  |  | $ | 76.9 |  |  | $ | 300.5 |  |  | $ | 151.8 |  |
| Less: purchases of property, equipment, and other assets | 17.4 |  |  | 6.2 |  |  | 36.9 |  |  | 12.1 |  |
| Free cash flow | $ | 136.4 |  |  | $ | 70.7 |  |  | $ | 263.6 |  |  | $ | 139.7 |  |
| Net cash used in investing activities | $ | (21.2 | ) |  | $ | (286.3 | ) |  | $ | (284.7 | ) |  | $ | (487.4 | ) |
| Net cash provided by financing activities | $ | 4.8 |  |  | $ | 8.7 |  |  | $ | 21.6 |  |  | $ | 24.8 |  |

[0001327567-16-000044:8k_2_02:63]
___________

[0001327567-16-000044:8k_2_02:64]
[a]    Non-GAAP net income per share, diluted, includes the potentially dilutive effect of employee equity incentive plan awards and convertible senior notes outstanding. In addition, non-GAAP net income per share, diluted, includes the anti-dilutive impact of the company’s note hedge agreements, which reduced the potentially dilutive effect of the convertible notes for the three and six months ended January 31, 2016 by 1.7 million shares and 1.8 million shares, respectively, and 0.6 million shares and 0.3 million shares, for the three and six months ended January 31, 2015, respectively.

[0001327567-16-000044:8k_2_02:65]
9

[0001327567-16-000044:8k_2_02:66]
| Palo Alto Networks, Inc. |
| Preliminary Condensed Consolidated Balance Sheets |
| (In millions) |
| (Unaudited) |
|  | January 31, 2016 |  | July 31, 2015 |
| Assets |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 413.2 |  |  | $ | 375.8 |  |
| Short-term investments | 551.4 |  |  | 413.2 |  |
| Accounts receivable, net | 254.4 |  |  | 212.4 |  |
| Prepaid expenses and other current assets | 88.1 |  |  | 72.6 |  |
| Total current assets | 1,307.1 |  |  | 1,074.0 |  |
| Property and equipment, net | 92.6 |  |  | 62.9 |  |
| Long-term investments | 631.1 |  |  | 538.8 |  |
| Goodwill | 163.5 |  |  | 163.5 |  |
| Intangible assets, net | 48.7 |  |  | 52.7 |  |
| Other assets | 73.6 |  |  | 73.3 |  |
| Total assets | $ | 2,316.6 |  |  | $ | 1,965.2 |  |
| Liabilities, temporary equity, and stockholders’ equity |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 32.5 |  |  | $ | 13.2 |  |
| Accrued compensation | 71.2 |  |  | 79.8 |  |
| Accrued and other liabilities | 44.0 |  |  | 28.2 |  |
| Deferred revenue | 541.2 |  |  | 423.9 |  |
| Convertible senior notes, net | 497.5 |  |  | 487.1 |  |
| Total current liabilities | 1,186.4 |  |  | 1,032.2 |  |
| Long-term deferred revenue | 387.6 |  |  | 289.8 |  |
| Other long-term liabilities | 72.3 |  |  | 67.4 |  |
| Temporary equity | 77.5 |  |  | 87.9 |  |
| Stockholders’ equity: |  |  |  |
| Preferred stock | — |  |  | — |  |
| Common stock and additional paid-in capital | 1,195.4 |  |  | 988.7 |  |
| Accumulated other comprehensive loss | (0.7 | ) |  | (0.1 | ) |
| Accumulated deficit | (601.9 | ) |  | (500.7 | ) |
| Total stockholders’ equity | 592.8 |  |  | 487.9 |  |
| Total liabilities, temporary equity, and stockholders’ equity | $ | 2,316.6 |  |  | $ | 1,965.2 |  |

[0001327567-16-000044:8k_2_02:67]
10

[0001327567-16-000044:8k_2_02:68]
| Palo Alto Networks, Inc. |
| Preliminary Condensed Consolidated Statements of Cash Flows |
| (In millions) |
| (Unaudited) |
|  | Six Months Ended January 31, |
|  | 2016 |  | 2015 |
| Cash flows from operating activities |  |  |  |
| Net loss | $ | (101.2 | ) |  | $ | (73.1 | ) |
| Adjustments to reconcile net loss to net cash provided by operating activities: |  |  |  |
| Share-based compensation for equity based awards | 174.8 |  |  | 95.3 |  |
| Depreciation and amortization | 19.5 |  |  | 12.9 |  |
| Amortization of investment premiums, net of accretion of purchase discounts | 1.6 |  |  | 1.5 |  |
| Amortization of debt discount and debt issuance costs | 11.5 |  |  | 11.0 |  |
| Excess tax benefit from share-based compensation arrangements | (0.5 | ) |  | (1.3 | ) |
| Changes in operating assets and liabilities: |  |  |  |
| Accounts receivable, net | (42.0 | ) |  | 0.3 |  |
| Prepaid expenses and other assets | (8.3 | ) |  | (32.4 | ) |
| Accounts payable | 13.6 |  |  | (1.9 | ) |
| Accrued compensation | (8.6 | ) |  | 4.4 |  |
| Accrued and other liabilities | 25.0 |  |  | 21.8 |  |
| Deferred revenue | 215.1 |  |  | 113.3 |  |
| Net cash provided by operating activities | 300.5 |  |  | 151.8 |  |
| Cash flows from investing activities |  |  |  |
| Purchases of investments | (610.2 | ) |  | (587.2 | ) |
| Proceeds from sales of investments | 134.4 |  |  | 2.0 |  |
| Proceeds from maturities of investments | 228.0 |  |  | 109.9 |  |
| Purchases of property, equipment, and other assets | (36.9 | ) |  | (12.1 | ) |
| Net cash used in investing activities | (284.7 | ) |  | (487.4 | ) |
| Cash flows from financing activities |  |  |  |
| Proceeds from sales of shares through employee equity incentive plans | 21.1 |  |  | 23.5 |  |
| Excess tax benefit from share-based compensation arrangements | 0.5 |  |  | 1.3 |  |
| Net cash provided by financing activities | 21.6 |  |  | 24.8 |  |
| Net increase (decrease) in cash and cash equivalents | 37.4 |  |  | (310.8 | ) |
| Cash and cash equivalents - beginning of period | 375.8 |  |  | 653.8 |  |
| Cash and cash equivalents - end of period | $ | 413.2 |  |  | $ | 343.0 |  |

[0001327567-16-000044:8k_2_02:69]
11

## item 5.02 — body, verbatim

[0001327567-16-000044:8k_body:1]
Item 5.02 Departure of Directors or Certain Officers; Election of Directors; Appointment of Certain Officers; Compensatory Arrangements of Certain Officers.

[0001327567-16-000044:8k_body:2]
(d) Appointment of New Director

[0001327567-16-000044:8k_body:3]
On February 24, 2016, the Company’s Board of Directors (the “Board”) increased the size of the Board from eight to nine and appointed Frank Calderoni to the Board, to serve as a class III director whose term expires at the annual meeting of stockholders to be held in 2017. In addition, the Board appointed Mr. Calderoni to replace Carl Eschenbach on the Audit Committee of the Board (the “Audit Committee”), and appointed Mr. Eschenbach to the Compensation Committee of the Board and the Nominating and Corporate Governance Committee of the Board.

[0001327567-16-000044:8k_body:4]
Mr. Calderoni, age 58, has served as Executive Vice President, Operations and Chief Financial Officer of Red Hat, Inc. since June 2015. From May 2004 to January 2015, Mr. Calderoni served in various positions at Cisco Systems, Inc., including as Executive Vice President and Chief Financial Officer. Mr. Calderoni currently serves on the boards of directors of Nimble Storage, Inc. and Adobe Systems Incorporated. Mr. Calderoni holds a B.S. in Accounting and Finance from Fordham University and an M.B.A. from Pace University.

[0001327567-16-000044:8k_body:5]
In connection with his appointment to the Board and in accordance with the Company’s Director Compensation Policy, the Board approved an initial award of restricted stock units for Mr. Calderoni having a value of approximately $1,000,000, which will be granted effective March 20, 2016 (the “Grant Date”). These restricted stock units will vest over three years, with one-third of the shares subject to the award vesting on the first anniversary of the Grant Date, and the remaining shares vesting equally over the next two years on a quarterly basis, subject to continued service on the Board on the applicable vesting date. In the event of a change of control, all shares subject to the award would become fully vested and immediately exercisable. The restricted stock units are subject to the terms and conditions of the Company’s 2012 Equity Incentive Plan and its related grant agreements. In addition, the Company expects to grant an annual award of restricted stock units having a value of approximately $320,000 to Mr. Calderoni on the date of each annual meeting of stockholders, beginning with the annual meeting of stockholders to be held in 2016, subject to continued service on the Board and the Audit Committee. Each annual award of restricted stock units is expected to vest over one year on a quarterly basis. The Company will also reimburse Mr. Calderoni for all reasonable expenses in connection with his services to the Company. A copy of the offer letter between Mr. Calderoni and the Company is filed herewith as Exhibit 10.1.

[0001327567-16-000044:8k_body:6]
Mr. Calderoni executed the Company’s standard form of indemnification agreement, a copy of which has been filed as Exhibit 10.1 to the Company’s Registration Statement on Form S-1 (File No. 333-180620) filed with the Securities and Exchange Commission on July 9, 2012.

[0001327567-16-000044:8k_body:7]
There is no arrangement or understanding between Mr. Calderoni and any other persons pursuant to which Mr. Calderoni was elected as a director. In addition, Mr. Calderoni is not a party to any transaction, or series of transactions, required to be disclosed pursuant to Item 404(a) of Regulation S-K.

[0001327567-16-000044:8k_body:8]
On February 25, 2016, the Company issued a press release announcing Mr. Calderoni’s appointment as a director. The press release is attached herewith as Exhibit 99.2.
