# PANW note change history — 0001327567-15-000036 → 0001327567-16-000048


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2016-02-26):
[0001327567-16-000048:note_history:1]
In May 2015, we entered into three lease agreements for approximately 752,000 square feet of corporate office space in Santa Clara, California to serve as our future corporate headquarters. In October 2015, we entered into a fourth lease agreement for approximately 310,000 square feet of additional office space at the same location. The fourth lease will commence in December 2017 and expire in April 2028, however, the site is currently under construction and as a result, the lease commencement date may change based on progress of the construction project. The fourth lease agreement contains a rent holiday period, scheduled rent increases, lease incentives, and renewal options which allow the lease term to be extended through April 2046. Rental payments under the fourth lease agreement are approximately $101.2 million over the initial lease term. For more information on the three lease agreements entered into in May 2015, refer to Note 8. Commitments and Contingencies of Notes to Consolidated Financial Statements included in Part II, Item 8 of our Annual Report on Form 10-K for the fiscal year ended July 31, 2015.
  (was, 2015-11-24, similarity 0.621):
[0001327567-15-000036:note_history:1]
In May 2015, we entered into three lease agreements for approximately 752,000 square feet of corporate office space in Santa Clara, California to serve as our future corporate headquarters. In October 2015, we entered into a fourth lease agreement for approximately 310,000 square feet of additional office space at the same location, which will commence in December 2017 and expire in April 2028. The site is currently under construction and as a result, the lease commencement date may change based on progress of the construction project. The lease contains a rent holiday period, scheduled rent increases, lease incentives, and renewal options which allow the lease term to be extended through April 2046. Rental payments under the fourth lease agreement are approximately $101.2 million over the initial lease term.

- changed (2016-02-26):
[0001327567-16-000048:note_history:2]
The following table presents details of the aggregate future non-cancelable minimum rental payments under our operating leases as of January 31, 2016 (in millions):
  (was, 2015-11-24, similarity 0.9623):
[0001327567-15-000036:note_history:2]
The following table presents details of the aggregate future non-cancelable minimum rental payments under our operating leases as of October 31, 2015 (in millions):

- changed (2016-02-26):
[0001327567-16-000048:note_history:3]
Our independent contract manufacturer procures components and assembles our products based on our forecasts. These forecasts are based on estimates of demand for our products primarily for the next 12 months, which are in turn based on historical trends and an analysis from our sales and product marketing organizations, adjusted for overall market conditions. In order to reduce manufacturing lead times and plan for adequate supply, we may issue forecasts and orders for components and products that are non-cancelable. As of January 31, 2016, our purchase commitments under such orders were $39.0 million, excluding obligations under contracts that we can cancel without a significant penalty.
  (was, 2015-11-24, similarity 0.9898):
[0001327567-15-000036:note_history:3]
Our independent contract manufacturer procures components and assembles our products based on our forecasts. These forecasts are based on estimates of demand for our products primarily for the next 12 months, which are in turn based on historical trends and an analysis from our sales and product marketing organizations, adjusted for overall market conditions. In order to reduce manufacturing lead times and plan for adequate supply, we may issue forecasts and orders for components and products that are non-cancelable. As of October 31, 2015, our purchase commitments under such orders were $46.3 million, excluding obligations under contracts that we can cancel without a significant penalty.

- changed (2016-02-26):
[0001327567-16-000048:note_history:4]
To the extent there is a reasonable possibility that a loss exceeding amounts already recognized may be incurred and the amount of such additional loss would be material, we will either disclose the estimated additional loss or state that such an estimate cannot be made. As of January 31, 2016, we have not recorded any significant accruals for loss contingencies associated with such legal proceedings, determined that an unfavorable outcome is probable or reasonably possible, or determined that the amount or range of any possible loss is reasonably estimable.
  (was, 2015-11-24, similarity 0.9875):
[0001327567-15-000036:note_history:4]
To the extent there is a reasonable possibility that a loss exceeding amounts already recognized may be incurred and the amount of such additional loss would be material, we will either disclose the estimated additional loss or state that such an estimate cannot be made. As of October 31, 2015, we have not recorded any significant accruals for loss contingencies associated with such legal proceedings, determined that an unfavorable outcome is probable or reasonably possible, or determined that the amount or range of any possible loss is reasonably estimable.


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2016-02-26):
[0001327567-16-000048:note_history:5]
The accompanying condensed consolidated financial statements have been prepared in conformity with U.S. generally accepted accounting principles, consistent in all material respects with those applied in our Annual Report on Form 10-K for the fiscal year ended July 31, 2015, filed with the Securities and Exchange Commission on September 17, 2015. Our condensed consolidated financial statements include our accounts and our wholly owned subsidiaries. All significant intercompany balances and transactions have been eliminated in consolidation.

- changed (2016-02-26):
[0001327567-16-000048:note_history:6]
Our condensed consolidated financial statements are unaudited, but include all adjustments of a normal recurring nature necessary for a fair presentation of our quarterly results. We have made estimates and judgments affecting the amounts reported in our condensed consolidated financial statements and the accompanying notes. The actual results that we experience may differ materially from our estimates. Certain prior period amounts have been reclassified to conform to current period presentation.
  (was, 2015-11-24, similarity 0.6577):
[0001327567-15-000036:note_history:6]
The accompanying condensed consolidated financial statements have been prepared in conformity with U.S. generally accepted accounting principles, consistent in all material respects with those applied in our Annual Report on Form 10-K for the fiscal year ended July 31, 2015, filed with the Securities and Exchange Commission on September 17, 2015. The condensed consolidated financial statements are unaudited, but include all adjustments of a normal recurring nature necessary for a fair presentation of our quarterly results. We have made estimates and judgments affecting the amounts reported in our condensed consolidated financial statements and the accompanying notes. The actual results that we experience may differ materially from our estimates. Certain prior period amounts have been reclassified to conform to current period presentation.

- changed (2016-02-26):
[0001327567-16-000048:note_history:7]
Our condensed consolidated financial statements should be read in conjunction with the consolidated financial statements and related notes in our Annual Report on Form 10-K for the fiscal year ended July 31, 2015.
  (was, 2015-11-24, similarity 0.9854):
[0001327567-15-000036:note_history:7]
The condensed consolidated financial statements should be read in conjunction with the consolidated financial statements and related notes in our Annual Report on Form 10-K for the fiscal year ended July 31, 2015.

- changed (2016-02-26):
[0001327567-16-000048:note_history:8]
There have been no material changes to our significant accounting policies as of and for the six months ended January 31, 2016, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended July 31, 2015.
  (was, 2015-11-24, similarity 0.9004):
[0001327567-15-000036:note_history:8]
There have been no material changes to our significant accounting policies as of and for the three months ended October 31, 2015, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended July 31, 2015.

- changed (2016-02-26):
[0001327567-16-000048:note_history:9]
In April 2015, the Financial Accounting Standards Board (“FASB”) issued new authoritative guidance on fees paid in a cloud computing arrangement. The standard requires customers in a cloud computing arrangement to evaluate whether the arrangement includes a software license. If the arrangement includes a software license, the customer should account for the software license element of the arrangement consistent with the acquisition of other software licenses. If the arrangement does not include a software license, the customer should account for the arrangement as a service contract. The standard is effective for us for our first quarter of fiscal 2017 and will be applied on either a prospective or retrospective basis. We are currently evaluating adoption methods and whether this standard will have a material impact on our condensed consolidated financial statements.
  (was, 2015-11-24, similarity 0.9989):
[0001327567-15-000036:note_history:9]
In April 2015, the Financial Accounting Standards Board (FASB) issued new authoritative guidance on fees paid in a cloud computing arrangement. The standard requires customers in a cloud computing arrangement to evaluate whether the arrangement includes a software license. If the arrangement includes a software license, the customer should account for the software license element of the arrangement consistent with the acquisition of other software licenses. If the arrangement does not include a software license, the customer should account for the arrangement as a service contract. The standard is effective for us for our first quarter of fiscal 2017 and will be applied on either a prospective or retrospective basis. We are currently evaluating adoption methods and whether this standard will have a material impact on our condensed consolidated financial statements.

- removed (2016-02-26):
[0001327567-15-000036:note_history:10]
Principles of Consolidation

- removed (2016-02-26):
[0001327567-15-000036:note_history:11]
The condensed consolidated financial statements include our accounts and our wholly owned subsidiaries. All significant intercompany balances and transactions have been eliminated in consolidation.


## us-gaap:ConvertibleDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2016-02-26):
[0001327567-16-000048:note_history:12]
The following table sets forth the components of the Notes as of January 31, 2016 and July 31, 2015 (in millions):
  (was, 2015-11-24, similarity 0.9423):
[0001327567-15-000036:note_history:12]
The following table sets forth the components of the Notes as of October 31, 2015 and July 31, 2015 (in millions):

- changed (2016-02-26):
[0001327567-16-000048:note_history:13]
|  | January 31, 2016 |  | July 31, 2015 |
| Liability: |  |  |  |
| Principal | $ | 575.0 |  |  | $ | 575.0 |  |
| Less: debt discount, net of amortization | 77.5 |  |  | 87.9 |  |
| Net carrying amount | $ | 497.5 |  |  | $ | 487.1 |  |
| Equity (including temporary equity) | $ | (109.8 | ) |  | $ | (109.8 | ) |
  (was, 2015-11-24, similarity 0.9731):
[0001327567-15-000036:note_history:13]
|  | October 31, 2015 |  | July 31, 2015 |
| Liability: |  |  |  |
| Principal | $ | 575.0 |  |  | $ | 575.0 |  |
| Less: debt discount, net of amortization | 82.7 |  |  | 87.9 |  |
| Net carrying amount | $ | 492.3 |  |  | $ | 487.1 |  |
| Equity (including temporary equity) | $ | (109.8 | ) |  | $ | (109.8 | ) |


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2016-02-26):
[0001327567-16-000048:note_history:14]
The sale price condition was initially met during the fiscal quarter ended April 30, 2015. The sale price condition continued to be met through the fiscal quarter ended January 31, 2016, and as a result, holders may convert their Notes at any time during the fiscal quarter ending April 30, 2016. Accordingly, the net carrying amount of the Notes was classified in current liabilities and a portion of the equity component representing the conversion option was classified as temporary equity in our condensed consolidated balance sheets as of January 31, 2016. The portion of the equity component classified as temporary equity is measured as the difference between the principal and net carrying amount of the Notes.

- changed (2016-02-26):
[0001327567-16-000048:note_history:15]
The following table sets forth the components of the Notes as of January 31, 2016 and July 31, 2015 (in millions):
  (was, 2015-11-24, similarity 0.9423):
[0001327567-15-000036:note_history:15]
The following table sets forth the components of the Notes as of October 31, 2015 and July 31, 2015 (in millions):

- changed (2016-02-26):
[0001327567-16-000048:note_history:16]
|  | January 31, 2016 |  | July 31, 2015 |
| Liability: |  |  |  |
| Principal | $ | 575.0 |  |  | $ | 575.0 |  |
| Less: debt discount, net of amortization | 77.5 |  |  | 87.9 |  |
| Net carrying amount | $ | 497.5 |  |  | $ | 487.1 |  |
| Equity (including temporary equity) | $ | (109.8 | ) |  | $ | (109.8 | ) |
  (was, 2015-11-24, similarity 0.9731):
[0001327567-15-000036:note_history:16]
|  | October 31, 2015 |  | July 31, 2015 |
| Liability: |  |  |  |
| Principal | $ | 575.0 |  |  | $ | 575.0 |  |
| Less: debt discount, net of amortization | 82.7 |  |  | 87.9 |  |
| Net carrying amount | $ | 492.3 |  |  | $ | 487.1 |  |
| Equity (including temporary equity) | $ | (109.8 | ) |  | $ | (109.8 | ) |

- added (2016-02-26):
[0001327567-16-000048:note_history:17]
The total estimated fair value of the Notes was $840.2 million and $994.8 million at January 31, 2016 and July 31, 2015, respectively. The fair value was determined based on the closing trading price per $100 of the Notes as of the last day of trading for the period. We consider the fair value of the Notes at January 31, 2016 and July 31, 2015 to be a Level 2 measurement. The fair value of the Notes is primarily affected by the trading price of our common stock and market interest rates. As of January 31, 2016, the if-converted value of the Notes exceeded its principal amount by $278.7 million.

- added (2016-02-26):
[0001327567-16-000048:note_history:18]
|  | Three Months Ended January 31, |  | Six Months Ended January 31, |
|  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Amortization of debt discount | $ | 5.2 |  |  | $ | 5.0 |  |  | $ | 10.4 |  |  | $ | 10.0 |  |
| Amortization of debt issuance costs | 0.6 |  |  | 0.5 |  |  | 1.1 |  |  | 1.0 |  |
| Total interest expense recognized | $ | 5.8 |  |  | $ | 5.5 |  |  | $ | 11.5 |  |  | $ | 11.0 |  |
| Effective interest rate of the liability component | 4.8 | % |  | 4.8 | % |  | 4.8 | % |  | 4.8 | % |

- changed (2016-02-26):
[0001327567-16-000048:note_history:19]
Separately, but concurrently with our issuance of the Notes, we entered into transactions whereby we sold warrants (the “Warrants”) to acquire up to 5.2 million shares of our common stock at a strike price of approximately $137.85 per share, subject to adjustments. The shares issuable under the Warrants will be included in the calculation of diluted earnings per share when the average market value per share of our common stock for the reporting period exceeds the strike price of the Warrants. The Warrants are separate transactions and are not part of the Notes or Notes Hedges, and are not remeasured through earnings each reporting period. Holders of the Notes and Note Hedges will not have any rights with respect to the Warrants.
  (was, 2015-11-24, similarity 0.9551):
[0001327567-15-000036:note_history:19]
Separately, but concurrently with our issuance of the Notes, we entered into warrant transactions (the “Warrants”) whereby we sold warrants to acquire up to 5.2 million shares of our common stock at a strike price of approximately $137.85 per share, subject to adjustments. The shares issuable under the Warrants will be included in the calculation of diluted earnings per share when the average market value per share of our common stock for the reporting period exceeds the strike price of the Warrants. The Warrants are separate transactions and are not part of the Notes or Notes Hedges, and are not remeasured through earnings each reporting period. Holders of the Notes and Note Hedges will not have any rights with respect to the Warrants.

- removed (2016-02-26):
[0001327567-15-000036:note_history:20]
The sale price condition was initially met during the fiscal quarter ended April 30, 2015. The sale price condition continued to be met through the fiscal quarter ended October 31, 2015 and as a result, holders may convert their Notes at any time during the fiscal quarter ending January 31, 2016. Accordingly, the net carrying amount of the Notes was classified in current liabilities and a portion of the equity component representing the conversion option was classified as temporary equity in our condensed consolidated balance sheets as of October 31, 2015. The portion of the equity component classified as temporary equity is measured as the difference between the principal and net carrying amount of the Notes.

- removed (2016-02-26):
[0001327567-15-000036:note_history:21]
The total estimated fair value of the Notes was $896.3 million and $994.8 million at October 31, 2015 and July 31, 2015, respectively. The fair value was determined based on the closing trading price per $100 of the Notes as of the last day of trading for the period. We consider the fair value of the Notes at October 31, 2015 and July 31, 2015 to be a Level 2 measurement. The fair value of the Notes is primarily affected by the trading price of our common stock and market interest rates. As of October 31, 2015, the if-converted value of the Notes exceeded its principal amount by $308.0 million.

- removed (2016-02-26):
[0001327567-15-000036:note_history:22]
|  | Three Months Ended October 31, |
|  | 2015 |  | 2014 |
| Amortization of debt discount | $ | 5.2 |  |  | $ | 5.0 |  |
| Amortization of debt issuance costs | 0.5 |  |  | 0.5 |  |
| Total interest expense recognized | $ | 5.7 |  |  | $ | 5.5 |  |
| Effective interest rate of the liability component | 4.8 | % |  | 4.8 | % |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2016-02-26):
[0001327567-16-000048:note_history:23]
The following tables summarize the unrealized gains and losses and fair value of our available-for-sale investments as of January 31, 2016 and July 31, 2015 (in millions):
  (was, 2015-11-24, similarity 0.9627):
[0001327567-15-000036:note_history:23]
The following tables summarize the unrealized gains and losses and fair value of our available-for-sale investments as of October 31, 2015 and July 31, 2015 (in millions):

- added (2016-02-26):
[0001327567-16-000048:note_history:24]
|  | January 31, 2016 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Estimated Fair Value |
| Certificates of deposit | $ | 5.4 |  |  | $ | — |  |  | $ | — |  |  | $ | 5.4 |  |
| Corporate debt securities | 294.9 |  |  | 0.1 |  |  | (0.5 | ) |  | 294.5 |  |
| U.S. government and agency securities | 882.9 |  |  | 0.2 |  |  | (0.5 | ) |  | 882.6 |  |
| Total | $ | 1,183.2 |  |  | $ | 0.3 |  |  | $ | (1.0 | ) |  | $ | 1,182.5 |  |

- changed (2016-02-26):
[0001327567-16-000048:note_history:25]
Unrealized losses related to these investments are due to interest rate fluctuations as opposed to credit quality. In addition, we do not intend to sell and it is not likely that we would be required to sell these investments before recovery of their amortized cost basis, which may be at maturity. As a result, there were no other-than-temporary impairments for these investments at January 31, 2016 and July 31, 2015.
  (was, 2015-11-24, similarity 0.9559):
[0001327567-15-000036:note_history:25]
Unrealized losses related to these investments are due to interest rate fluctuations as opposed to credit quality. In addition, we do not intend to sell and it is not likely that we would be required to sell these investments before recovery of their amortized cost basis, which may be at maturity. As a result, there were no other-than-temporary impairments for these investments at October 31, 2015 and July 31, 2015.

- changed (2016-02-26):
[0001327567-16-000048:note_history:26]
The following table summarizes the amortized cost and fair value of our available-for-sale investments as of January 31, 2016, by contractual years-to-maturity (in millions):
  (was, 2015-11-24, similarity 0.9643):
[0001327567-15-000036:note_history:26]
The following table summarizes the amortized cost and fair value of our available-for-sale investments as of October 31, 2015, by contractual years-to-maturity (in millions):

- removed (2016-02-26):
[0001327567-15-000036:note_history:27]
|  | October 31, 2015 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Estimated Fair Value |
| Certificates of deposit | $ | 1.0 |  |  | $ | — |  |  | $ | — |  |  | $ | 1.0 |  |
| Corporate debt securities | 292.1 |  |  | 0.1 |  |  | (0.3 | ) |  | 291.9 |  |
| U.S. government and agency securities | 902.1 |  |  | 0.2 |  |  | (0.4 | ) |  | 901.9 |  |
| Total | $ | 1,195.2 |  |  | $ | 0.3 |  |  | $ | (0.7 | ) |  | $ | 1,194.8 |  |
