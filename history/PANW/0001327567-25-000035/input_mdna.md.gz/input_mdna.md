# PANW MD&A — 0001327567-25-000035


## mdna

[0001327567-25-000035:mdna:1]
[same as prior period, unchanged from 0001327567-25-000017:mdna:1]

[0001327567-25-000035:mdna:2]
[same as prior period, unchanged from 0001327567-25-000017:mdna:2]

[0001327567-25-000035:mdna:3]
[same as prior period, unchanged from 0001327567-25-000017:mdna:3]

[0001327567-25-000035:mdna:4]
[same as prior period, unchanged from 0001327567-25-000017:mdna:4]

[0001327567-25-000035:mdna:5]
•Results of Operations. A discussion of the nature and trends in our financial results and an analysis of our financial results comparing the three months ended October 31, 2025 to the three months ended October 31, 2024.

[0001327567-25-000035:mdna:6]
[same as prior period, unchanged from 0001327567-25-000017:mdna:6]

[0001327567-25-000035:mdna:7]
[same as prior period, unchanged from 0001327567-25-000017:mdna:7]

[0001327567-25-000035:mdna:8]
[same as prior period, unchanged from 0001327567-25-000017:mdna:8]

[0001327567-25-000035:mdna:9]
- 20 -

[0001327567-25-000035:mdna:10]
[same as prior period, unchanged from 0001327567-25-000017:mdna:10]

[0001327567-25-000035:mdna:11]
Our mission is to be the cybersecurity partner of choice for enterprises, organizations, service providers, and government entities to protect our digital way of life. Our cybersecurity platforms and services help secure enterprise users, networks, clouds, and endpoints by delivering comprehensive cybersecurity backed by artificial intelligence (“AI”) and automation. A key element of our strategy is to help our customers simplify their security architectures through consolidating disparate point products. We execute on this strategy by developing our capabilities and packaging our offerings into platforms which are able to cover many of our customers’ needs in the markets in which we operate. Our platformization strategy combines various products and services into a tightly integrated architecture for more secure, faster and cost-effective outcomes.

[0001327567-25-000035:mdna:12]
Network Security

[0001327567-25-000035:mdna:13]
Our network security platform is designed to deliver complete zero trust solutions to our customers. The platform includes:

[0001327567-25-000035:mdna:14]
•Secure Access Service Edge (“SASE”). Prisma® Access, when combined with Prisma SD-WAN, provides a comprehensive SASE offering that secures users working from anywhere and pioneers the modernization of branch offices. Prisma Browser further extends zero-trust security and data protection to the browser, where the majority of work is done today, providing users with the freedom to work securely using our secure browser from any device.

[0001327567-25-000035:mdna:15]
•Next-Generation Firewalls. Our hardware ML-Powered Next-Generation Firewalls (“NGFWs”) secure on-premises environments including campus locations and data centers. Our software NGFWs secure cloud networks.

[0001327567-25-000035:mdna:16]
•Cloud-Delivered Security Services (“CDSS”). Our network security platform integrates a suite of CDSS that complements our SASE and Firewall solutions. These include Advanced Threat Prevention, Advanced WildFire®, Advanced URL Filtering, Advanced DNS Security, Device Security, GlobalProtect®, Prisma Access Agent, Enterprise Data Loss Prevention (“Enterprise DLP”), AI for IT Operations (“AIOps”), Software as a Service (“SaaS”) Security, and AI Access Security. Through these add-on services, our customers are able to secure their content, applications, users, and devices across their entire organization.

[0001327567-25-000035:mdna:17]
•Prisma AIRS. Prisma AIRS™ is a comprehensive AI security platform that has been designed to protect customers’ entire AI ecosystem by providing AI Model Security, AI Posture Management, AI Red Teaming, AI Runtime Security, and AI Agent Security.

[0001327567-25-000035:mdna:18]
•Strata Cloud Manager (“SCM”). SCM, our network security management solution, centrally manages network security across all remote workers, branches, headquarters, campuses, and cloud. This comprehensive solution includes Strata Copilot, which offers a natural language interface for enhanced insights and guided remediation, and integrates Autonomous Digital Experience Monitoring (“ADEM”) to proactively maintain infrastructure health, facilitate AI-driven one-click troubleshooting, and ensure seamless end-user performance across the enterprise.

[0001327567-25-000035:mdna:19]
Security Operations

[0001327567-25-000035:mdna:20]
Our AI-powered Cortex platform transforms end-to-end security operations with unified data, AI, and automation for more secure, faster, and cost effective outcomes. We have consolidated our industry-leading Security Operations and Cloud Security capabilities on a single comprehensive platform to provide centralized visibility, proactive protection, real-time prevention, AI-driven insights, and automated remediation across enterprise and cloud.

[0001327567-25-000035:mdna:21]
•Security Operations. We deliver the next generation of security operations capabilities that unifies standalone Security Information and Event Management (“SIEM”) tools, endpoint security, security automation, cloud detection and response (“CDR”), as well as attack surface management (“ASM”) capabilities on our Cortex® platform. These include Cortex XSIAM®, for AI-powered security operations replacing traditional SIEM tools; Cortex XDR®, for the prevention, detection, and response to complex cybersecurity attacks; Cortex XSOAR®, for security orchestration, automation, and response (“SOAR”); and Cortex Xpanse®, for ASM.

[0001327567-25-000035:mdna:22]
•Cloud Security. We deliver comprehensive security across the cloud application development lifecycle through Cortex Cloud, delivered as a scalable SaaS offering. As a comprehensive Cloud Native Application Protection Platform (“CNAPP”) combined with CDR, Cortex Cloud secures multi- and hybrid-cloud environments for applications, data, generative AI (“GenAI”) ecosystem, and the cloud native technology stack across the full development lifecycle, from code to cloud to security operations. As part of the Cortex Cloud platform, customers can expand from Cortex Cloud to our security operations offerings available on a single user experience and unified agent. We also offer our VM-Series and CN-Series virtual firewalls for inline network security on multi- and hybrid-cloud environments.

[0001327567-25-000035:mdna:23]
Threat Intelligence and Advisory Services

[0001327567-25-000035:mdna:24]
•Unit 42 brings together world-renowned expertise across threat research, incident response, and security consulting to deliver intelligence-driven, response-ready outcomes that help customers reduce cyber risk. Our elite consultants serve as trusted advisors to our customers by assessing and testing their security controls against sophisticated threats, transforming their security strategy with a threat-informed approach, and responding to security incidents on behalf of our clients. Additionally, Unit 42 offers managed detection and response (“MDR”) and managed threat hunting services.

[0001327567-25-000035:mdna:25]
- 21 -

[0001327567-25-000035:mdna:26]
For the first quarter of fiscal 2026 and 2025, total revenue was $2.5 billion and $2.1 billion, respectively, representing year-over-year growth of 16%. Our growth reflects the increased adoption of our portfolio, which consists of product, subscriptions, and support. We believe our portfolio will enable us to benefit from recurring revenues and new revenues as we continue to grow our end-customer base. As of October 31, 2025, we had end-customers in over 180 countries. Our end-customers represent a broad range of industries, including education, energy, financial services, government entities, healthcare, Internet and media, manufacturing, public sector, and telecommunications, and include almost all of the Fortune 100 companies and a majority of the Global 2000 companies. We maintain a field sales force that works closely with our channel partners in developing sales opportunities. We primarily use a two-tiered, indirect fulfillment model whereby we sell our products, subscriptions, and support to our distributors, which, in turn, sell to our resellers, which then sell to our end-customers.

[0001327567-25-000035:mdna:27]
Our product revenue grew to $434 million, or 17.5% of total revenue, for the first quarter of fiscal 2026, representing year-over-year growth of 23%. Product revenue is derived from sales of hardware products, primarily our ML-Powered Next-Generation Firewall and software licenses, including SD-WAN, VM-Series, and Panorama®. Our ML-Powered Next-Generation Firewall incorporates our PAN-OS operating system, which provides a consistent set of capabilities across our entire network security product line. Our hardware products and software licenses include a broad set of built-in networking and security features and functionalities. Our products are designed for different performance requirements throughout an organization, ranging from our PA-400, which is designed for small organizations and remote or branch offices, to our top-of-the-line PA-7500, which is designed for large-scale data centers and service provider use. The same firewall functionality that is delivered in our hardware products is also available in our VM-Series virtual firewalls, which secure virtualized and cloud-based computing environments, and in our CN-Series container firewalls, which secure container environments and traffic.

[0001327567-25-000035:mdna:28]
Our subscription and support revenue grew to $2.0 billion, or 82.5% of total revenue, for the first quarter of fiscal 2026, representing year-over-year growth of 14%. Our subscriptions provide our end-customers with near real-time access to the latest intrusion prevention, web security, modern malware prevention, data loss prevention, CASB and AI security capabilities across the network, endpoints, and the cloud. Our subscriptions also include security operations, which enable customers to leverage the AI-powered Cortex platform for advanced capabilities such as security information and event management, next-generation antivirus, endpoint detection and response, extended detection and response, identity threat detection and response, cloud detection and response, SOAR, ASM, and CNAPP for comprehensive cloud security. Additionally, we offer MDR for Cortex subscriptions, powered by Unit 42’s elite expertise. When customers purchase our physical, virtual, or container firewalls, or certain cloud offerings, they typically purchase support in order to receive ongoing security updates, upgrades, bug fixes, and repairs. In addition to the subscriptions purchased with these firewalls, customers may also purchase other subscriptions on a per-user, per-endpoint, or capacity-based basis. We also offer professional services, including incident response, risk management, and digital forensic services.

[0001327567-25-000035:mdna:29]
We continue to invest in innovation as we evolve and further extend the capabilities of our portfolio, as we believe that innovation and timely development of and investment in new features and products are essential to meeting the needs of our end-customers and improving our competitive position. For example, in August 2025, we introduced innovations through a software upgrade to PAN-OS 12.1 Orion to provide enterprise wide quantum security readiness for our customers. In October 2025, we launched Prisma AIRS 2.0, a major platform upgrade that completes the native integration of the recently acquired Protect AI, Inc. to provide customers with end-to-end protection across AI application lifecycle. Additionally, in July 2025, we entered into a definitive agreement to acquire CyberArk Software Ltd. (“CyberArk”), an identity security company, which acquisition is expected to close during the third quarter of our fiscal 2026, subject to the satisfaction of customary closing conditions.

[0001327567-25-000035:mdna:30]
[same as prior period, unchanged from 0001327567-25-000017:mdna:25]

[0001327567-25-000035:mdna:31]
[same as prior period, unchanged from 0001327567-25-000017:mdna:26]

[0001327567-25-000035:mdna:32]
Our overall performance depends in part on worldwide economic and geopolitical conditions and their impact on customer behavior. Changes in legislation or regulations and actions by regulators, including changes in enforcement and administration policies, may have an impact on our results of operations and financial condition. Significant changes in U.S. or global trade policy, including further expansion of U.S. export/imports controls and tariffs, as well as retaliatory actions by other countries, may materially and adversely affect our business. Further, economic conditions, including inflation, high interest rates, slow growth, fluctuations in foreign exchange rates, supply chain disruptions, impacts of trade regulations or international trade disputes, and other conditions, may adversely affect our results of operations and financial performance.

[0001327567-25-000035:mdna:33]
- 22 -

[0001327567-25-000035:mdna:34]
[same as prior period, unchanged from 0001327567-25-000017:mdna:29]

[0001327567-25-000035:mdna:35]
[same as prior period, unchanged from 0001327567-25-000017:mdna:30]

[0001327567-25-000035:mdna:36]
[same as prior period, unchanged from 0001327567-25-000017:mdna:31]

[0001327567-25-000035:mdna:37]
[same as prior period, unchanged from 0001327567-25-000017:mdna:32]

[0001327567-25-000035:mdna:38]
|  | October 31, 2025 |  | July 31, 2025 |
|  | (in billions) |
| Next-Generation Security Annualized Recurring Revenue | $ | 5.9 |  |  | $ | 5.6 |  |
| Remaining performance obligations | $ | 15.5 |  |  | $ | 15.8 |  |

[0001327567-25-000035:mdna:39]
|  |  |  | Three Months Ended October 31, |
|  |  |  |  |  | 2025 |  | 2024 |
|  |  |  |  |  | (dollars in millions) |
| Total revenue |  |  |  |  | $ | 2,474 |  |  | $ | 2,139 |  |
| Total revenue year-over-year percentage increase |  |  |  |  | 16 | % |  | 14 | % |
| Gross margin |  |  |  |  | 74.2 | % |  | 74.1 | % |
| Operating income |  |  |  |  | $ | 309 |  |  | $ | 286 |  |
| Operating margin |  |  |  |  | 12.5 | % |  | 13.4 | % |
| Cash flow provided by operating activities |  |  |  |  | $ | 1,771 |  |  | $ | 1,510 |  |
| Free cash flow (non-GAAP) |  |  |  |  | $ | 1,687 |  |  | $ | 1,466 |  |

[0001327567-25-000035:mdna:40]
•Next-Generation Security Annualized Recurring Revenue (“NGS ARR”). Our NGS ARR represents the annualized allocated revenue of all active contracts as of the final day of the reporting period related to all product, subscription and support offerings, excluding revenue from hardware products, and legacy attached subscriptions, support offerings and professional services. NGS ARR is an operating metric that we use to assess the strength and trajectory of our business. NGS ARR should be viewed independently of revenue, deferred revenue and remaining performance obligations and does not represent our revenue under U.S. GAAP on an annualized basis, as it is an operating metric that can be impacted by contract start and end dates and renewal rates. NGS ARR is not intended to be a replacement for forecasts of revenue. The scope of products, subscriptions, and support offerings that contribute to NGS ARR will generally increase over time as we introduce or acquire new next-generation products, subscriptions, and support offerings.

[0001327567-25-000035:mdna:41]
[same as prior period, unchanged from 0001327567-25-000017:mdna:36]

[0001327567-25-000035:mdna:42]
- 23 -

[0001327567-25-000035:mdna:43]
[same as prior period, unchanged from 0001327567-25-000017:mdna:38]

[0001327567-25-000035:mdna:44]
|  | Three Months Ended October 31, |
|  | 2025 |  | 2024 |
|  | (in millions) |
| Free cash flow (non-GAAP): |  |  |  |
| Net cash provided by operating activities | $ | 1,771 |  |  | $ | 1,510 |  |
| Less: purchases of property, equipment, and other assets | 84 |  |  | 44 |  |
| Free cash flow (non-GAAP) | $ | 1,687 |  |  | $ | 1,466 |  |
| Net cash used in investing activities | $ | (983) |  |  | $ | (544) |  |
| Net cash provided by (used in) financing activities | $ | 8 |  |  | $ | (220) |  |

[0001327567-25-000035:mdna:45]
[same as prior period, unchanged from 0001327567-25-000017:mdna:9]

[0001327567-25-000035:mdna:46]
[same as prior period, unchanged from 0001327567-25-000017:mdna:41]

[0001327567-25-000035:mdna:47]
[same as prior period, unchanged from 0001327567-25-000017:mdna:42]

[0001327567-25-000035:mdna:48]
|  |  |  | Three Months Ended October 31, |
|  |  |  |  |  | 2025 |  | 2024 |
|  |  |  |  |  |  |  |  |  | Amount |  | % of Revenue |  | Amount |  | % of Revenue |
|  |  |  |  |  |  |  |  |  | (dollars in millions) |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  |  |  |  |  |  |  |  | $ | 434 |  |  | 17.5 | % |  | $ | 354 |  |  | 16.5 | % |
| Subscription and support |  |  |  |  |  |  |  |  | 2,040 |  |  | 82.5 | % |  | 1,785 |  |  | 83.5 | % |
| Total revenue |  |  |  |  |  |  |  |  | 2,474 |  |  | 100.0 | % |  | 2,139 |  |  | 100.0 | % |
| Cost of revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  |  |  |  |  |  |  |  | 89 |  |  | 3.6 | % |  | 75 |  |  | 3.5 | % |
| Subscription and support |  |  |  |  |  |  |  |  | 549 |  |  | 22.2 | % |  | 479 |  |  | 22.4 | % |
| Total cost of revenue(1) |  |  |  |  |  |  |  |  | 638 |  |  | 25.8 | % |  | 554 |  |  | 25.9 | % |
| Total gross profit |  |  |  |  |  |  |  |  | 1,836 |  |  | 74.2 | % |  | 1,585 |  |  | 74.1 | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development |  |  |  |  |  |  |  |  | 528 |  |  | 21.3 | % |  | 481 |  |  | 22.5 | % |
| Sales and marketing |  |  |  |  |  |  |  |  | 820 |  |  | 33.2 | % |  | 720 |  |  | 33.6 | % |
| General and administrative |  |  |  |  |  |  |  |  | 179 |  |  | 7.2 | % |  | 98 |  |  | 4.6 | % |
| Total operating expenses(1) |  |  |  |  |  |  |  |  | 1,527 |  |  | 61.7 | % |  | 1,299 |  |  | 60.7 | % |
| Operating income |  |  |  |  |  |  |  |  | 309 |  |  | 12.5 | % |  | 286 |  |  | 13.4 | % |
| Interest expense |  |  |  |  |  |  |  |  | — |  |  | — | % |  | (1) |  |  | (0.1) | % |
| Other income, net |  |  |  |  |  |  |  |  | 103 |  |  | 4.2 | % |  | 83 |  |  | 3.9 | % |
| Income before income taxes |  |  |  |  |  |  |  |  | 412 |  |  | 16.7 | % |  | 368 |  |  | 17.2 | % |
| Provision for income taxes |  |  |  |  |  |  |  |  | 78 |  |  | 3.2 | % |  | 17 |  |  | 0.8 | % |
| Net income |  |  |  |  |  |  |  |  | $ | 334 |  |  | 13.5 | % |  | $ | 351 |  |  | 16.4 | % |

[0001327567-25-000035:mdna:49]
[same as prior period, unchanged from 0001327567-25-000017:mdna:44]

[0001327567-25-000035:mdna:50]
|  |  |  | Three Months Ended October 31, |
|  |  |  |  |  | 2025 |  | 2024 |
|  |  |  |  |  | (in millions) |
| Cost of product revenue |  |  |  |  | $ | 1 |  |  | $ | 1 |  |
| Cost of subscription and support revenue |  |  |  |  | 32 |  |  | 31 |  |
| Research and development |  |  |  |  | 155 |  |  | 138 |  |
| Sales and marketing |  |  |  |  | 102 |  |  | 76 |  |
| General and administrative |  |  |  |  | 80 |  |  | 49 |  |
| Total share-based compensation |  |  |  |  | $ | 370 |  |  | $ | 295 |  |

[0001327567-25-000035:mdna:51]
[same as prior period, unchanged from 0001327567-25-000017:mdna:20]

[0001327567-25-000035:mdna:52]
[same as prior period, unchanged from 0001327567-25-000017:mdna:47]

[0001327567-25-000035:mdna:53]
[same as prior period, unchanged from 0001327567-25-000017:mdna:48]

[0001327567-25-000035:mdna:54]
[same as prior period, unchanged from 0001327567-25-000017:mdna:49]

[0001327567-25-000035:mdna:55]
Product revenue is derived from sales of hardware products, primarily our ML-Powered Next-Generation Firewall, and  software licenses, including SD-WAN, VM-Series, and Panorama. Our hardware products and software licenses include a broad set of built-in networking and security features and functionalities. We recognize product revenue at the time of hardware shipment or delivery of software license. As a percentage of product revenue, we expect our revenue from software licenses to vary from quarter to quarter and increase over the long term as we improve features and capabilities of our on-premise software, renew our software license contracts, and expand our installed end-customer base.

[0001327567-25-000035:mdna:56]
|  |  |  |  |  |  |  | Three Months Ended October 31, |  |  |  |  |
|  |  |  |  |  |  |  | 2025 |  | 2024 |  | Change |
|  |  |  |  |  |  |  |  |  | Amount |  | Amount |  | Amount |  | % |
|  |  |  |  |  |  |  |  |  | (dollars in millions) |
| Product |  |  |  |  |  |  |  |  | $ | 434 |  |  | $ | 354 |  |  | $ | 80 |  |  | 23 | % |

[0001327567-25-000035:mdna:57]
Product revenue increased for the three months ended October 31, 2025 compared to the same period in 2024 driven by an increased product demand and an increase in price of and allocation to on-premise software licenses due to enhanced features and capabilities beginning in the second quarter of fiscal 2025.

[0001327567-25-000035:mdna:58]
[same as prior period, unchanged from 0001327567-25-000017:mdna:53]

[0001327567-25-000035:mdna:59]
[same as prior period, unchanged from 0001327567-25-000017:mdna:54]

[0001327567-25-000035:mdna:60]
|  |  |  |  |  |  |  | Three Months Ended October 31, |  |  |  |  |
|  |  |  |  |  |  |  | 2025 |  | 2024 |  | Change |
|  |  |  |  |  |  |  |  |  | Amount |  | Amount |  | Amount |  | % |
|  |  |  |  |  |  |  |  |  | (dollars in millions) |
| Subscription |  |  |  |  |  |  |  |  | $ | 1,364 |  |  | $ | 1,192 |  |  | $ | 172 |  |  | 14 | % |
| Support |  |  |  |  |  |  |  |  | 676 |  |  | 593 |  |  | 83 |  |  | 14 | % |
| Total subscription and support |  |  |  |  |  |  |  |  | $ | 2,040 |  |  | $ | 1,785 |  |  | $ | 255 |  |  | 14 | % |

[0001327567-25-000035:mdna:61]
Subscription and support revenue increased for the three months ended October 31, 2025 compared to the same period in 2024 due to increased demand for our subscription and support offerings from our end-customers. The mix between subscription revenue and support revenue will fluctuate over time, depending on the introduction of new subscription offerings, renewals of support services, and our ability to increase sales to new and existing end-customers.

[0001327567-25-000035:mdna:62]
[same as prior period, unchanged from 0001327567-25-000017:mdna:28]

[0001327567-25-000035:mdna:63]
[same as prior period, unchanged from 0001327567-25-000017:mdna:58]

[0001327567-25-000035:mdna:64]
|  |  |  |  |  |  |  | Three Months Ended October 31, |  |  |  |  |
|  |  |  |  |  |  |  | 2025 |  | 2024 |  | Change |
|  |  |  |  |  |  |  |  |  | Amount |  | Amount |  | Amount |  | % |
|  |  |  |  |  |  |  |  |  | (dollars in millions) |
| Americas |  |  |  |  |  |  |  |  | $ | 1,641 |  |  | $ | 1,442 |  |  | $ | 199 |  |  | 14 | % |
| Europe, the Middle East, and Africa (“EMEA”) |  |  |  |  |  |  |  |  | 521 |  |  | 442 |  |  | 79 |  |  | 18 | % |
| Asia Pacific and Japan (“APAC”) |  |  |  |  |  |  |  |  | 312 |  |  | 255 |  |  | 57 |  |  | 22 | % |
| Total revenue |  |  |  |  |  |  |  |  | $ | 2,474 |  |  | $ | 2,139 |  |  | $ | 335 |  |  | 16 | % |

[0001327567-25-000035:mdna:65]
Revenue from the Americas, EMEA, and APAC increased for the three months ended October 31, 2025 compared to the same period in 2024 as we continued to increase investment in our global sales force in order to support our growth and innovation, with the Americas contributing the highest increase in revenue due to its larger scale.

[0001327567-25-000035:mdna:66]
[same as prior period, unchanged from 0001327567-25-000017:mdna:61]

[0001327567-25-000035:mdna:67]
[same as prior period, unchanged from 0001327567-25-000017:mdna:62]

[0001327567-25-000035:mdna:68]
[same as prior period, unchanged from 0001327567-25-000017:mdna:63]

[0001327567-25-000035:mdna:69]
Cost of product revenue primarily includes costs paid to our manufacturing partners for procuring components and manufacturing our products. Our cost of product revenue also includes personnel costs, which consist of salaries, benefits, bonuses, share-based compensation, and travel associated with our operations organization, inventory excess and obsolete charges, shipping and tariff costs, amortization of intellectual property licenses, product testing costs, and shared costs. Shared costs consist of certain facilities, depreciation, benefits, recruiting, and information technology costs that we allocate based on headcount. We expect our cost of product revenue to fluctuate with our revenue from hardware products.

[0001327567-25-000035:mdna:70]
|  |  |  |  |  |  |  | Three Months Ended October 31, |  |  |  |  |
|  |  |  |  |  |  |  | 2025 |  | 2024 |  | Change |
|  |  |  |  |  |  |  |  |  | Amount |  | Amount |  | Amount |  | % |
|  |  |  |  |  |  |  |  |  | (dollars in millions) |
| Cost of product revenue |  |  |  |  |  |  |  |  | $ | 89 |  |  | $ | 75 |  |  | $ | 14 |  |  | 19 | % |

[0001327567-25-000035:mdna:71]
Cost of product revenue increased for the three months ended October 31, 2025 compared to the same period in 2024 primarily due to increased product volume and other product costs. The remaining increase was primarily driven by higher tariff costs.

[0001327567-25-000035:mdna:72]
[same as prior period, unchanged from 0001327567-25-000017:mdna:37]

[0001327567-25-000035:mdna:73]
[same as prior period, unchanged from 0001327567-25-000017:mdna:68]

[0001327567-25-000035:mdna:74]
[same as prior period, unchanged from 0001327567-25-000017:mdna:69]

[0001327567-25-000035:mdna:75]
|  |  |  |  |  |  |  | Three Months Ended October 31, |  |  |  |  |
|  |  |  |  |  |  |  | 2025 |  | 2024 |  | Change |
|  |  |  |  |  |  |  |  |  | Amount |  | Amount |  | Amount |  | % |
|  |  |  |  |  |  |  |  |  | (dollars in millions) |
| Cost of subscription and support revenue |  |  |  |  |  |  |  |  | $ | 549 |  |  | $ | 479 |  |  | $ | 70 |  |  | 15 | % |

[0001327567-25-000035:mdna:76]
Cost of subscription and support revenue increased for the three months ended October 31, 2025 compared to the same period in 2024 primarily due to increased costs to support the growth of our subscription and support offerings. Cloud hosting service costs, which support our cloud-based subscription offerings, increased $48 million for the three months ended October 31, 2025 compared to the same period in 2024. Personnel costs grew $14 million for the three months ended October 31, 2025 compared to the same period in 2024, primarily due to headcount growth.

[0001327567-25-000035:mdna:77]
[same as prior period, unchanged from 0001327567-25-000017:mdna:72]

[0001327567-25-000035:mdna:78]
Gross margin has been and will continue to be affected by a variety of factors, including the introduction of new products, manufacturing costs, the average sales price of our products, cloud hosting service costs, personnel costs, the mix of products sold, and the mix of revenue between product and subscription and support offerings. Our higher-end firewall products generally have higher gross margins than our lower-end firewall products within each product series. We expect our gross margins to vary over time depending on the factors described above.

[0001327567-25-000035:mdna:79]
|  |  |  | Three Months Ended October 31, |
|  |  |  |  |  | 2025 |  | 2024 |
|  |  |  |  |  |  |  |  |  | Amount |  | Gross Margin |  | Amount |  | Gross Margin |
|  |  |  |  |  |  |  |  |  | (dollars in millions) |
| Product |  |  |  |  |  |  |  |  | $ | 345 |  |  | 79.5 | % |  | $ | 279 |  |  | 78.8 | % |
| Subscription and support |  |  |  |  |  |  |  |  | 1,491 |  |  | 73.1 | % |  | 1,306 |  |  | 73.2 | % |
| Total gross profit |  |  |  |  |  |  |  |  | $ | 1,836 |  |  | 74.2 | % |  | $ | 1,585 |  |  | 74.1 | % |

[0001327567-25-000035:mdna:80]
Product gross margin increased for the three months ended October 31, 2025 compared to the same period in 2024 primarily due to continued shift in our product revenue mix toward software, partially offset by a decrease in gross margin on our hardware products.

[0001327567-25-000035:mdna:81]
Subscription and support gross margin was flat for the three months ended October 31, 2025 compared to the same period in 2024.

[0001327567-25-000035:mdna:82]
[same as prior period, unchanged from 0001327567-25-000017:mdna:78]

[0001327567-25-000035:mdna:83]
Our operating expenses consist of research and development, sales and marketing, and general and administrative expenses. Personnel costs are the most significant component of operating expenses and consist of salaries, benefits, bonuses, share-based compensation, travel and entertainment, and with regard to sales and marketing expense, sales commissions. Our operating expenses also include shared costs, which consist of certain facilities, depreciation, benefits, recruiting, and information technology costs that we allocate based on headcount to each department. We expect operating expenses generally to increase in absolute dollars and to decrease over the long term as a percentage of revenue as we continue to scale our business. As of October 31, 2025, we expect to recognize approximately $2.2 billion of share-based compensation expense over a weighted-average period of approximately 2.4 years, excluding additional share-based compensation expense related to any future grants of share-based awards. Share-based compensation expense is generally recognized on a straight-line basis over the requisite service periods of the awards.

[0001327567-25-000035:mdna:84]
[same as prior period, unchanged from 0001327567-25-000017:mdna:40]

[0001327567-25-000035:mdna:85]
[same as prior period, unchanged from 0001327567-25-000017:mdna:80]

[0001327567-25-000035:mdna:86]
[same as prior period, unchanged from 0001327567-25-000017:mdna:81]

[0001327567-25-000035:mdna:87]
|  |  |  |  |  |  |  | Three Months Ended October 31, |  |  |  |  |
|  |  |  |  |  |  |  | 2025 |  | 2024 |  | Change |
|  |  |  |  |  |  |  |  |  | Amount |  | Amount |  | Amount |  | % |
|  |  |  |  |  |  |  |  |  | (dollars in millions) |
| Research and development |  |  |  |  |  |  |  |  | $ | 528 |  |  | $ | 481 |  |  | $ | 47 |  |  | 10 | % |

[0001327567-25-000035:mdna:88]
Research and development expense increased for the three months ended October 31, 2025 compared to the same period in 2024 primarily due to increased personnel costs, which grew $45 million for the three months ended October 31, 2025 compared to the same period in 2024, largely due to headcount growth.

[0001327567-25-000035:mdna:89]
[same as prior period, unchanged from 0001327567-25-000017:mdna:84]

[0001327567-25-000035:mdna:90]
[same as prior period, unchanged from 0001327567-25-000017:mdna:85]

[0001327567-25-000035:mdna:91]
|  |  |  |  |  |  |  | Three Months Ended October 31, |  |  |  |  |
|  |  |  |  |  |  |  | 2025 |  | 2024 |  | Change |
|  |  |  |  |  |  |  |  |  | Amount |  | Amount |  | Amount |  | % |
|  |  |  |  |  |  |  |  |  | (dollars in millions) |
| Sales and marketing |  |  |  |  |  |  |  |  | $ | 820 |  |  | $ | 720 |  |  | $ | 100 |  |  | 14 | % |

[0001327567-25-000035:mdna:92]
Sales and marketing expense increased for the three months ended October 31, 2025 compared to the same period in 2024 primarily due to increased personnel costs, which grew $86 million for the three months ended October 31, 2025 compared to the same period in 2024, largely due to headcount growth.

[0001327567-25-000035:mdna:93]
[same as prior period, unchanged from 0001327567-25-000017:mdna:89]

[0001327567-25-000035:mdna:94]
[same as prior period, unchanged from 0001327567-25-000017:mdna:90]

[0001327567-25-000035:mdna:95]
|  |  |  |  |  |  |  | Three Months Ended October 31, |  |  |  |  |
|  |  |  |  |  |  |  | 2025 |  | 2024 |  | Change |
|  |  |  |  |  |  |  |  |  | Amount |  | Amount |  | Amount |  | % |
|  |  |  |  |  |  |  |  |  | (dollars in millions) |
| General and administrative |  |  |  |  |  |  |  |  | $ | 179 |  |  | $ | 98 |  |  | $ | 81 |  |  | 83 | % |

[0001327567-25-000035:mdna:96]
General and administrative expense increased for the three months ended October 31, 2025 compared to the same period in 2024 primarily due to a partial release of litigation-related accrual of $43 million during the three months ended October 31, 2024. The increase in general and administrative expense was further driven by increased personnel costs, which grew $37 million, largely due to increased share-based compensation and headcount growth.

[0001327567-25-000035:mdna:97]
[same as prior period, unchanged from 0001327567-25-000017:mdna:46]

[0001327567-25-000035:mdna:98]
[same as prior period, unchanged from 0001327567-25-000017:mdna:93]

[0001327567-25-000035:mdna:99]
Interest expense consists of interest expense related to our 0.375% Convertible Senior Notes due 2025 (the “2025 Notes”).

[0001327567-25-000035:mdna:100]
|  |  |  |  |  | Three Months Ended October 31, |  |  |
|  |  |  |  |  |  |  | 2025 |  | 2024 |  | Change |
|  |  |  |  |  |  |  |  |  | Amount |  | Amount |  | Amount |  | % |
|  |  |  |  |  |  |  |  |  | (dollars in millions) |
| Interest expense |  |  |  |  |  |  |  |  | $ | — |  |  | $ | 1 |  |  | $ | (1) |  |  | (100) | % |

[0001327567-25-000035:mdna:101]
Interest expense decreased for the three months ended October 31, 2025 compared to the same period in 2024 due to the maturity of our 2025 Notes in June 2025. Refer to Note 9. Debt in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information on the Notes.

[0001327567-25-000035:mdna:102]
[same as prior period, unchanged from 0001327567-25-000017:mdna:97]

[0001327567-25-000035:mdna:103]
[same as prior period, unchanged from 0001327567-25-000017:mdna:98]

[0001327567-25-000035:mdna:104]
|  |  |  |  |  | Three Months Ended October 31, |  |  |
|  |  |  |  |  |  |  | 2025 |  | 2024 |  | Change |
|  |  |  |  |  |  |  |  |  | Amount |  | Amount |  | Amount |  | % |
|  |  |  |  |  |  |  |  |  | (dollars in millions) |
| Other income, net |  |  |  |  |  |  |  |  | $ | 103 |  |  | $ | 83 |  |  | $ | 20 |  |  | 24 | % |

[0001327567-25-000035:mdna:105]
Other income, net increased for the three months ended October 31, 2025 compared to the same period in 2024 primarily due to higher interest income as a result of higher average cash, cash equivalents, and investment balance, partially offset by lower interest rates for the three months ended October 31, 2025 compared to the same period in 2024.

[0001327567-25-000035:mdna:106]
PROVISION FOR INCOME TAXES

[0001327567-25-000035:mdna:107]
Provision for income taxes consists primarily of U.S. and foreign income taxes. Our effective tax rate during the three months ended October 31, 2025 was lower than our statutory tax rate primarily due to excess tax benefits from share-based compensation. We continue to maintain a valuation allowance for our California deferred tax assets due to the uncertainty regarding realizability of these deferred tax assets as they have not met the “more likely than not” realization criterion. We expect future research and development tax credit generation in California to exceed our ability to use the existing tax credits.

[0001327567-25-000035:mdna:108]
|  |  |  |  |  |  |  | Three Months Ended October 31, |  |  |  |  |
|  |  |  |  |  |  |  | 2025 |  | 2024 |  | Change |
|  |  |  |  |  |  |  |  |  | Amount |  | Amount |  | Amount |  | % |
|  |  |  |  |  |  |  |  |  | (dollars in millions) |
| Provision for income taxes |  |  |  |  |  |  |  |  | $ | 78 |  |  | $ | 17 |  |  | $ | 61 |  |  | 359 | % |
| Effective tax rate |  |  |  |  |  |  |  |  | 18.9 | % |  | 4.9 | % |  |  |  |  |

[0001327567-25-000035:mdna:109]
Our provision for income taxes for the three months ended October 31, 2025 was primarily due to U.S. and foreign income taxes. Our effective tax rate increased for the three months ended October 31, 2025 compared to the same period in 2024 primarily due to increased earnings before income taxes and decreased excess tax benefits from share-based compensation. Refer to Note 13. Income Taxes in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information.

[0001327567-25-000035:mdna:110]
[same as prior period, unchanged from 0001327567-25-000017:mdna:57]

[0001327567-25-000035:mdna:111]
[same as prior period, unchanged from 0001327567-25-000017:mdna:106]

[0001327567-25-000035:mdna:112]
|  | October 31, 2025 |  | July 31, 2025 |
|  | (in millions) |
| Working capital (deficit) | $ | (108) |  |  | $ | (465) |  |
| Cash, cash equivalents, and investments: |  |  |  |
| Cash and cash equivalents | $ | 3,066 |  |  | $ | 2,269 |  |
| Investments | 7,126 |  |  | 6,190 |  |
| Total cash, cash equivalents, and investments | $ | 10,192 |  |  | $ | 8,459 |  |

[0001327567-25-000035:mdna:113]
As of October 31, 2025, our total cash, cash equivalents, and investments of $10.2 billion were held for general corporate purposes. As of October 31, 2025, we had no unremitted earnings when evaluating our outside basis difference relating to our U.S. investment in foreign subsidiaries. However, there could be local withholding taxes due to various foreign countries if certain lower tier earnings are distributed. Withholding taxes that would be payable upon remittance of these lower tier earnings are not material.

[0001327567-25-000035:mdna:114]
[same as prior period, unchanged from 0001327567-25-000017:mdna:110]

[0001327567-25-000035:mdna:115]
In April 2023, we entered into a credit agreement (the “Credit Agreement”) that provides for a $400 million unsecured revolving credit facility (the “Credit Facility”), with an option to increase the amount of the Credit Facility by up to an additional $350 million, subject to certain conditions. The interest rates and commitment fees are also subject to upward and downward adjustments based on our progress towards the achievement of certain sustainability goals. As of October 31, 2025, there were no amounts outstanding, and we were in compliance with all covenants under the Credit Agreement. Refer to Note 9. Debt in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information on the Credit Agreement.

[0001327567-25-000035:mdna:116]
[same as prior period, unchanged from 0001327567-25-000017:mdna:115]

[0001327567-25-000035:mdna:117]
In February 2019, our board of directors authorized a $1.0 billion share repurchase program. Our board of directors subsequently authorized additional increases to this share repurchase program, bringing the total authorization to $4.1 billion. Repurchases will be funded from available working capital and may be made at management’s discretion from time to time. As of October 31, 2025, $1.0 billion remained available for future share repurchases under this repurchase program. The repurchase authorization will expire on December 31, 2026, and may be suspended or discontinued at any time without prior notice. Refer to Note 11. Stockholders’ Equity in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information on this repurchase program.

[0001327567-25-000035:mdna:118]
CONTRACTUAL OBLIGATIONS AND OTHER MATERIAL CASH REQUIREMENTS

[0001327567-25-000035:mdna:119]
We have entered into various non-cancelable operating leases, primarily for our offices and data centers, with lease terms expiring through fiscal 2036. As of October 31, 2025, we have total operating lease obligations of $429 million recorded on our condensed consolidated balance sheet.

[0001327567-25-000035:mdna:120]
As of October 31, 2025, our commitments to purchase products, components, cloud hosting and other services totaled $6.8 billion. Refer to Note 10. Commitments and Contingencies in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information on these commitments.

[0001327567-25-000035:mdna:121]
Our acquisition of certain QRadar assets from International Business Machines Corporation (“IBM”) on August 31, 2024 included contingent consideration that requires potential future payments through the fiscal quarter ending October 2028. As of October 31, 2025, we have total contingent consideration obligation of $380 million recorded on our condensed consolidated balance sheet. Refer to Note 3. Fair Value Measurements and Note 7. Acquisition in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information on our contingent consideration obligation.

[0001327567-25-000035:mdna:122]
On July 30, 2025, we entered into a definitive agreement to acquire CyberArk. The acquisition is expected to close during the third quarter of our fiscal 2026, subject to the satisfaction of customary closing conditions. Under the terms of the definitive agreement, CyberArk shareholders will receive $45.00 in cash and 2.2005 shares of our common stock for each CyberArk share. This represents an equity value for CyberArk of approximately $25 billion based on the unaffected 10-day average daily volume-weighted average trading prices of our common stock as of July 25, 2025. We expect to fund the cash portion of the consideration with our cash on hand. Refer to Part II, Item 1A “Risk Factors” and Note 7. Acquisitions in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information on the acquisition.

[0001327567-25-000035:mdna:123]
[same as prior period, unchanged from 0001327567-25-000017:mdna:67]

[0001327567-25-000035:mdna:124]
[same as prior period, unchanged from 0001327567-25-000017:mdna:121]

[0001327567-25-000035:mdna:125]
The following table summarizes our cash flows for the three months ended October 31, 2025 and 2024:

[0001327567-25-000035:mdna:126]
|  | Three Months Ended October 31, |
|  | 2025 |  | 2024 |
|  | (in millions) |
| Net cash provided by operating activities | $ | 1,771 |  |  | $ | 1,510 |  |
| Net cash used in investing activities | (983) |  |  | (544) |  |
| Net cash provided by (used in) financing activities | 8 |  |  | (220) |  |
| Net increase in cash, cash equivalents, and restricted cash | $ | 796 |  |  | $ | 746 |  |

[0001327567-25-000035:mdna:127]
Cash from operations could be affected by various risks and uncertainties detailed in Part II, Item 1A “Risk Factors” in this Quarterly Report on Form 10-Q. We believe that our cash flow from operations with existing cash and cash equivalents will be sufficient to meet our anticipated cash needs for at least the next 12 months and thereafter for the foreseeable future. Our future capital requirements will depend on many factors, including our growth rate, the timing and extent of spending to support development efforts, the expansion of sales and marketing activities, the introduction of new and enhanced products and subscription and support offerings, the costs to acquire or invest in complementary businesses and technologies, the costs to ensure access to adequate manufacturing capacity, the investments in our infrastructure to support the adoption of our cloud-based subscription offerings, the continuing market acceptance of our products and subscription and support offerings and macroeconomic events. In addition, from time to time, we may incur additional tax liability in connection with certain corporate structuring decisions.

[0001327567-25-000035:mdna:128]
[same as prior period, unchanged from 0001327567-25-000017:mdna:126]

[0001327567-25-000035:mdna:129]
[same as prior period, unchanged from 0001327567-25-000017:mdna:127]

[0001327567-25-000035:mdna:130]
[same as prior period, unchanged from 0001327567-25-000017:mdna:128]

[0001327567-25-000035:mdna:131]
Cash provided by operating activities during the three months ended October 31, 2025 was $1.8 billion, an increase of $261 million compared to the same period in 2024. The increase was primarily due to growth of our business as reflected by increases in collections during the three months ended October 31, 2025, partially offset by higher cash expenditure to support our business growth.

[0001327567-25-000035:mdna:132]
[same as prior period, unchanged from 0001327567-25-000017:mdna:130]

[0001327567-25-000035:mdna:133]
[same as prior period, unchanged from 0001327567-25-000017:mdna:131]

[0001327567-25-000035:mdna:134]
Cash used in investing activities during the three months ended October 31, 2025 was $1.0 billion, an increase of $439 million compared to the same period in 2024. The increase was primarily due to higher purchases of investments and lower proceeds from sales and maturities of investments, partially offset by a decrease in net cash payments for business acquisitions during the three months ended October 31, 2025.

[0001327567-25-000035:mdna:135]
[same as prior period, unchanged from 0001327567-25-000017:mdna:133]

[0001327567-25-000035:mdna:136]
Our financing activities have consisted of repayments of our convertible senior notes, proceeds from sales of shares through employee equity incentive plans, payments for tax withholding obligations of certain employees related to the net share settlement of equity awards, and payments of contingent consideration liability.

[0001327567-25-000035:mdna:137]
Cash provided by financing activities during the three months ended October 31, 2025 was $8 million, a change of $228 million compared to cash used in financing activities of $220 million during the same period in 2024. The change was primarily due to a decrease in cash used for repayments of our 2025 Notes which did not recur during the three months ended October 31, 2025 as a result of its maturity, partially offset by payments of our contingent consideration liability during the three months ended October 31, 2025.

[0001327567-25-000035:mdna:138]
[same as prior period, unchanged from 0001327567-25-000017:mdna:77]

[0001327567-25-000035:mdna:139]
[same as prior period, unchanged from 0001327567-25-000017:mdna:136]

[0001327567-25-000035:mdna:140]
[same as prior period, unchanged from 0001327567-25-000017:mdna:137]

[0001327567-25-000035:mdna:141]
We believe the critical accounting estimates discussed under Item 7, “Management’s Discussion and Analysis of Financial Condition and Results of Operations” in our Annual Report on Form 10-K for the fiscal year ended July 31, 2025 reflect our more significant estimates, assumptions, and judgments that have the most significant impact on our condensed consolidated financial statements. There have been no significant changes to our critical accounting estimates as filed in such report.

[0001327567-25-000035:mdna:142]
[same as prior period, unchanged from 0001327567-25-000017:mdna:143]

[0001327567-25-000035:mdna:143]
Refer to “Recently Issued Accounting Pronouncements” in Note 1. Description of Business and Summary of Significant Accounting Policies in Part I, Item 1 of this Quarterly Report on Form 10-Q for a description of recent accounting pronouncements and our expectation of their impact, if any, on our results of operations and financial condition.
