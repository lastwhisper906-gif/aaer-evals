# PANW note change history — 0001327567-25-000017 → 0001327567-25-000035


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2025-11-20):
[0001327567-25-000035:note_history:1]
We have entered into various non-cancelable agreements with cloud hosting service providers, under which we are committed to minimum or fixed purchases of certain cloud hosting services. In addition, in order to reduce manufacturing lead times and plan for adequate supply, we have entered into agreements with manufacturing partners and component suppliers to procure inventory based on our demand forecasts. Other purchase obligations include non-cancellable subscription agreements and other commitments in the normal course of business. The following table presents details of the aggregate future non-cancelable purchase commitments under these agreements as of October 31, 2025 (in millions):
  (was, 2025-05-21, similarity 0.9795):
[0001327567-25-000017:note_history:1]
We have entered into various non-cancelable agreements with cloud service providers, under which we are committed to minimum or fixed purchases of certain cloud services. In addition, in order to reduce manufacturing lead times and plan for adequate supply, we have entered into agreements with manufacturing partners and component suppliers to procure inventory based on our demand forecasts. Other purchase obligations include non-cancellable subscription agreements and other commitments in the normal course of business. The following table presents details of the aggregate future non-cancelable purchase commitments under these agreements as of April 30, 2025 (in millions):

- changed (2025-11-20):
[0001327567-25-000035:note_history:2]
|  |  |  | Fiscal years ending July 31, |
|  | Total |  | Remaining 2026 |  | 2027 |  | 2028 |  | 2029 |  | 2030 |  | 2031 and Thereafter |
| Cloud | $ | 6,380 |  |  | $ | 60 |  |  | $ | 660 |  |  | $ | 998 |  |  | $ | 1,017 |  |  | $ | 1,148 |  |  | $ | 2,497 |  |
| Manufacturing | 185 |  |  | 185 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Other | 141 |  |  | 66 |  |  | 61 |  |  | 7 |  |  | 3 |  |  | 4 |  |  | — |  |
| Total | $ | 6,706 |  |  | $ | 311 |  |  | $ | 721 |  |  | $ | 1,005 |  |  | $ | 1,020 |  |  | $ | 1,152 |  |  | $ | 2,497 |  |
  (was, 2025-05-21, similarity 0.7668):
[0001327567-25-000017:note_history:2]
|  |  |  | Fiscal years ending July 31, |
|  | Total |  | Remaining 2025 |  | 2026 |  | 2027 |  | 2028 |  | 2029 |  | 2030 and Thereafter |
| Cloud | $ | 3,797.2 |  |  | $ | 64.1 |  |  | $ | 137.2 |  |  | $ | 518.1 |  |  | $ | 599.8 |  |  | $ | 685.3 |  |  | $ | 1,792.7 |  |
| Manufacturing | 196.7 |  |  | 61.5 |  |  | 135.2 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Other | 213.0 |  |  | 37.1 |  |  | 104.3 |  |  | 57.9 |  |  | 6.8 |  |  | 3.4 |  |  | 3.5 |  |
| Total purchase commitments | $ | 4,206.9 |  |  | $ | 162.7 |  |  | $ | 376.7 |  |  | $ | 576.0 |  |  | $ | 606.6 |  |  | $ | 688.7 |  |  | $ | 1,796.2 |  |

- changed (2025-11-20):
[0001327567-25-000035:note_history:3]
Additionally, we have a $112 million minimum purchase commitment with a cloud hosting service provider through September 2027 with no specified annual commitments.
  (was, 2025-05-21, similarity 0.974):
[0001327567-25-000017:note_history:3]
Additionally, we have a $127.3 million minimum purchase commitment with a cloud service provider through September 2027 with no specified annual commitments.

- changed (2025-11-20):
[0001327567-25-000035:note_history:4]
On March 12, 2021, Centripetal Networks, Inc., filed a lawsuit against us in the United States District Court for the Eastern District of Virginia. The lawsuit alleges that our products infringe multiple Centripetal patents. We successfully challenged certain of these patents, which were found unpatentable by the U.S. Patent and Trademark Office (“PTO”). The case went to jury trial on January 22, 2024, on four patents. On January 31, 2024, the jury returned a verdict of non-willful infringement with a lump sum amount of $152 million, plus statutory interest. After post-trial motions, a judgment was issued on October 3, 2024 affirming infringement on three patents, reversing infringement on the fourth patent, and subsequently, reducing the damages amount to $114 million. We posted a surety bond that was agreed upon by the parties and approved by the court. This bond prevents execution of the judgment while appeals are pending. In addition, Centripetal filed infringement contentions on certain of their patents in the European Patent Office and Unified Patent Court in Germany, to which we filed appropriate legal challenges. Those matters are still pending.
  (was, 2025-05-21, similarity 0.9371):
[0001327567-25-000017:note_history:4]
On March 12, 2021, Centripetal Networks, Inc., filed a lawsuit against us in the United States District Court for the Eastern District of Virginia. The lawsuit alleges that our products infringe multiple Centripetal patents. We successfully challenged certain of these patents, which were found unpatentable by the U.S. Patent and Trademark Office (“PTO”). The case went to jury trial on January 22, 2024, on four patents. On January 31, 2024, the jury returned a verdict of non-willful infringement with a lump sum amount of $151.5 million, plus statutory interest. After post-trial motions, a judgment was issued on October 3, 2024 affirming infringement on three patents, reversing infringement on the fourth patent, and subsequently, reducing the damages amount to $113.6 million. We posted a surety bond that was agreed upon by the parties and approved by the court. This bond prevents execution of the judgment while appeals are pending. In addition, Centripetal filed infringement contentions on certain of their patents in the European Patent Office in Germany, to which we filed invalidity challenges. Those matters are still pending.

- changed (2025-11-20):
[0001327567-25-000035:note_history:5]
As of October 31, 2025 and July 31, 2025, we accrued $147 million and $146 million based on the judgment and estimated interest, which is recorded in other long-term liabilities on our condensed consolidated balance sheets. The corresponding charge was $1 million for the three months ended October 31, 2025. We recorded a release of $43 million for the three months ended October 31, 2024. These amounts are included in general and administrative expense on our condensed consolidated statements of operations.
  (was, 2025-05-21, similarity 0.6337):
[0001327567-25-000017:note_history:5]
As of July 31, 2024, we accrued $184.4 million for the verdict amount and estimated interest. As of April 30, 2025, we accrued $144.1 million based on the judgment and estimated interest, which is recorded in other long-term liabilities on our condensed consolidated balance sheets. The corresponding amount was a charge of $1.3 million for the three months ended April 30, 2025, and a release of $40.3 million for the nine months ended April 30, 2025, which is included in general and administrative expense on our condensed consolidated statements of operations.

- added (2025-11-20):
[0001327567-25-000035:note_history:6]
Finjan, Inc. v. Palo Alto Networks

- changed (2025-11-20):
[0001327567-25-000035:note_history:7]
On November 4, 2014, Finjan, Inc., filed a lawsuit against us in the United States District Court for the Northern District of California. The lawsuit alleges that our products infringe multiple Finjan patents. The complaint requests injunctive relief, monetary damages, and attorneys’ fees. On March 21, 2025, the judge issued an order granting summary judgment of non-infringement on all remaining patents at issue. Plaintiff filed a Notice of Appeal on April 21, 2025. We are unable, at this time, to reasonably estimate a possible loss or potential range of loss, if any.
  (was, 2025-05-21, similarity 0.9609):
[0001327567-25-000017:note_history:7]
Finjan, Inc. v. Palo Alto Networks
On November 4, 2014, Finjan, Inc., filed a lawsuit against us in the United States District Court for the Northern District of California. The lawsuit alleges that our products infringe multiple Finjan patents. The complaint requests injunctive relief, monetary damages, and attorneys’ fees. On March 21, 2025, the judge issued an order granting summary judgment of non-infringement on all remaining patents at issue. Plaintiff filed a Notice of Appeal on April 21, 2025. We are unable, at this time, to reasonably estimate a possible loss or potential range of loss, if any.

- added (2025-11-20):
[0001327567-25-000035:note_history:8]
Eire OG Innovations. v. Palo Alto Networks

- added (2025-11-20):
[0001327567-25-000035:note_history:9]
On April 3, 2024, Eire OG Innovations filed a lawsuit against us in the United States District Court for the Eastern District of Texas asserting infringement of multiple patents, certain of which were subsequently dismissed. The complaint requests monetary damages and attorneys’ fees. Trial is set for February 17, 2026. As of October 31, 2025, we accrued for an immaterial amount related to this matter.


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2025-11-20):
[0001327567-25-000035:note_history:10]
Palo Alto Networks, Inc. (the “Company,” “we,” “us,” or “our”), headquartered in Santa Clara, California, was incorporated in March 2005 under the laws of the State of Delaware and commenced operations in April 2005. Our cybersecurity platforms and services help enterprises, organizations, service providers, and government entities to secure their users, networks, clouds, and endpoints by delivering comprehensive cybersecurity backed by artificial intelligence and automation.

- changed (2025-11-20):
[0001327567-25-000035:note_history:11]
The accompanying condensed consolidated financial statements have been prepared in conformity with U.S. generally accepted accounting principles (“U.S. GAAP”), consistent in all material respects with those applied in our Annual Report on Form 10-K for the fiscal year ended July 31, 2025, filed with the Securities and Exchange Commission (“SEC”) on August 29, 2025. The condensed consolidated financial statements include our accounts and our wholly owned subsidiaries. All significant intercompany balances and transactions have been eliminated in consolidation.
  (was, 2025-05-21, similarity 0.6269):
[0001327567-25-000017:note_history:11]
The accompanying condensed consolidated financial statements have been prepared in conformity with U.S. generally accepted accounting principles (“U.S. GAAP”), consistent in all material respects with those applied in our Annual Report on Form 10-K for the fiscal year ended July 31, 2024, filed with the Securities and Exchange Commission (“SEC”) on September 6, 2024. The condensed consolidated financial statements include our accounts and our wholly owned subsidiaries. All significant intercompany balances and transactions have been eliminated in consolidation.

- changed (2025-11-20):
[0001327567-25-000035:note_history:12]
The preparation of condensed consolidated financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the amounts reported and disclosed in the condensed consolidated financial statements and the accompanying notes. We evaluate our estimates on an ongoing basis. Management estimates include, but are not limited to, the standalone selling price for our products and services, share-based compensation, fair value of assets acquired and liabilities assumed in business combinations, fair value of contingent consideration liability, the assessment of recoverability of our intangibles and goodwill, valuation allowance against deferred tax assets, valuation of inventory and manufacturing partner and supplier liabilities, deferred contract cost benefit period, and loss contingencies. We base our estimates on assumptions, both historical and forward looking, that we believe are reasonable. Actual results could differ materially from those estimates due to risks and uncertainties.
  (was, 2025-05-21, similarity 0.6705):
[0001327567-25-000017:note_history:12]
The preparation of condensed consolidated financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the amounts reported and disclosed in the condensed consolidated financial statements and the accompanying notes. We evaluate our estimates on an ongoing basis. Management estimates include, but are not limited to, the standalone selling price for our products and services, share-based compensation, fair value of assets acquired and liabilities assumed in business combinations, fair value of contingent consideration liability, the assessment of recoverability of our intangibles and goodwill, valuation allowance against deferred tax assets, manufacturing partner and supplier liabilities, deferred contract cost benefit period, and loss contingencies. We base our estimates on assumptions, both historical and forward looking, that we believe are reasonable. Actual results could differ materially from those estimates due to risks and uncertainties, including uncertainty in the current economic environment.

- added (2025-11-20):
[0001327567-25-000035:note_history:13]
There have been no material changes to our significant accounting policies as of and for the three months ended October 31, 2025, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended July 31, 2025.

- changed (2025-11-20):
[0001327567-25-000035:note_history:14]
In December 2023, the Financial Accounting Standards Board (“FASB”) issued authoritative guidance that requires consistent categories and greater disaggregation of information in the effective tax rate reconciliation and additional disclosures of income taxes paid by jurisdiction. The standard is effective for our annual periods beginning in fiscal 2026 and could be applied either prospectively or retrospectively. We are currently evaluating the impact of this standard on our disclosures in the consolidated financial statements.
  (was, 2025-05-21, similarity 0.9176):
[0001327567-25-000017:note_history:14]
In December 2023, the FASB issued authoritative guidance that requires consistent categories and greater disaggregation of information in the effective tax rate reconciliation and additional disclosures of income taxes paid by jurisdiction. The standard is effective for our annual period in fiscal 2026 and could be applied either prospectively or retrospectively. Early adoption is permitted. We are currently evaluating the impact of this standard on our disclosures in the consolidated financial statements.

- changed (2025-11-20):
[0001327567-25-000035:note_history:15]
In November 2024, the FASB issued authoritative guidance that expands annual and interim disclosure of specified information about certain costs and expenses in the notes to financial statements. The standard is effective for our annual periods beginning in fiscal 2028 and interim periods beginning in the first quarter of fiscal 2029, and could be applied either prospectively or retrospectively. Early adoption is permitted. We are currently evaluating the impact of this standard on our disclosures in the consolidated financial statements.
  (was, 2025-05-21, similarity 0.9896):
[0001327567-25-000017:note_history:15]
In November 2024, the FASB issued authoritative guidance that expands annual and interim disclosure of specified information about certain costs and expenses in the notes to financial statements. The standard is effective for our annual period in fiscal 2028 and interim periods beginning in the first quarter of fiscal 2029, and could be applied either prospectively or retrospectively. Early adoption is permitted. We are currently evaluating the impact of this standard on our disclosures in the consolidated financial statements.

- added (2025-11-20):
[0001327567-25-000035:note_history:16]
Measurement of Credit Losses for Accounts Receivable and Contract Assets

- added (2025-11-20):
[0001327567-25-000035:note_history:17]
In July 2025, the FASB issued authoritative guidance that provides a practical expedient for estimating expected credit losses on accounts receivable and contract assets. The standard is effective for our annual and interim periods beginning in the first quarter of fiscal 2027 and will be applied on a prospective basis. Early adoption is permitted. We are currently evaluating the impact of this standard on our consolidated financial statements.

- added (2025-11-20):
[0001327567-25-000035:note_history:18]
Accounting for Internal-Use Software

- added (2025-11-20):
[0001327567-25-000035:note_history:19]
In September 2025, the FASB issued authoritative guidance that modernizes the accounting for internal-use software by eliminating project stage-based capitalization and clarifying the requirements, including probable-to-complete threshold, to commence the capitalization of software development costs. The standard is effective for our annual and interim periods beginning in the first quarter of fiscal 2029 and could be applied either prospectively or retrospectively. Early adoption is permitted. We are currently evaluating the impact of this standard on our consolidated financial statements.

- removed (2025-11-20):
[0001327567-25-000017:note_history:20]
Palo Alto Networks, Inc. (the “Company,” “we,” “us,” or “our”), headquartered in Santa Clara, California, was incorporated in March 2005 under the laws of the State of Delaware and commenced operations in April 2005. We empower enterprises, organizations, service providers, and government entities to secure their users, networks, clouds, and endpoints by delivering comprehensive cybersecurity backed by artificial intelligence and automation.

- removed (2025-11-20):
[0001327567-25-000017:note_history:21]
Stock Split

- removed (2025-11-20):
[0001327567-25-000017:note_history:22]
On December 12, 2024, we effected a two-for-one stock split of our outstanding shares of common stock through an amendment to our restated certificate of incorporation (“Stock Split”), which also effected a proportionate increase in the number of authorized shares of our common stock from 1.0 billion to 2.0 billion. The par value per share of our common stock remains unchanged at $0.0001 per share after the Stock Split. All references made to share or per share amounts related to our common stock have been retroactively adjusted on the accompanying condensed consolidated financial statements and applicable disclosures to reflect the effects of the Stock Split.

- removed (2025-11-20):
[0001327567-25-000017:note_history:23]
There have been no material changes to our significant accounting policies as of and for the nine months ended April 30, 2025, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended July 31, 2024, except for the update to the disclosure of our accounting policies as described below resulting from our acquisition of certain QRadar assets from International Business Machines Corporation (“IBM”). Refer to Note 7. Acquisition for additional information.

- removed (2025-11-20):
[0001327567-25-000017:note_history:24]
Business Combinations

- removed (2025-11-20):
[0001327567-25-000017:note_history:25]
We include the results of operations of the businesses that we acquire as of the respective dates of acquisition. We allocate the fair value of the purchase price of our acquisitions to the assets acquired and liabilities assumed, including contingent consideration, generally based on their estimated fair values. The excess of the purchase price over the fair values of these identifiable assets and liabilities is recorded as goodwill. Additional information existing as of the acquisition date but unknown to us may become known during the remainder of the measurement period, not to exceed 12 months from the acquisition date, which may result in changes to the amounts and allocations recorded.

- removed (2025-11-20):
[0001327567-25-000017:note_history:26]
Contingent consideration obligations incurred in connection with a business combination are recorded at fair value on the acquisition date and remeasured at each subsequent reporting period until the related contingencies have been resolved, with the change in fair value recognized in general and administrative expense on our condensed consolidated statements of operations. Payments not made soon after the acquisition date to settle a contingent consideration liability are classified as cash flows from financing activities up to the amount of the contingent consideration liability recognized at the acquisition date.

- removed (2025-11-20):
[0001327567-25-000017:note_history:27]
Segment Reporting

- removed (2025-11-20):
[0001327567-25-000017:note_history:28]
In November 2023, the Financial Accounting Standards Board (“FASB”) issued authoritative guidance that expands annual and interim disclosure requirements for reportable segments, primarily through enhanced disclosures about significant segment expenses. The standard is effective for our annual period in fiscal 2025 and interim periods beginning in the first quarter of fiscal 2026, and requires retrospective application for all prior periods presented in the financial statements. Early adoption is permitted. We expect the adoption of this standard will not have a material impact on our consolidated financial statements.


## us-gaap:ConvertibleDebtTableTextBlock (debt) — matched_by: no_current_note, score: 0.0

- removed (2025-11-20):
[0001327567-25-000017:note_history:29]
The following table sets forth the net carrying amount of our 2025 Notes (in millions):

- removed (2025-11-20):
[0001327567-25-000017:note_history:30]
|  | April 30, 2025 |  | July 31, 2024 |
| Principal | $ | 383.3 |  |  | $ | 965.6 |  |
| Less: debt issuance costs, net of amortization | (0.1) |  |  | (1.7) |  |
| Net carrying amount | $ | 383.2 |  |  | $ | 963.9 |  |


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-11-20):
[0001327567-25-000035:note_history:31]
Debt
Convertible Senior Notes, Note Hedges, and Warrants
  (was, 2025-05-21, similarity 0.6824):
[0001327567-25-000017:note_history:31]
Debt
Convertible Senior Notes

- added (2025-11-20):
[0001327567-25-000035:note_history:32]
In June 2020, we issued $2.0 billion aggregate principal amount of 0.375% Convertible Senior Notes due 2025 (the “2025 Notes”). The 2025 Notes were converted prior to or settled on the maturity date of June 1, 2025 in accordance with their terms.

- added (2025-11-20):
[0001327567-25-000035:note_history:33]
Concurrent with the issuance of the 2025 Notes, we entered into separate convertible note hedge transactions (the “2025 Note Hedges”) with respect to our common stock for an aggregate payment of $371 million. The 2025 Note Hedges expired upon maturity of the 2025 Notes. Any shares of our common stock receivable by us under the 2025 Note Hedges are excluded from the calculation of diluted earnings per share as they are antidilutive.

- added (2025-11-20):
[0001327567-25-000035:note_history:34]
Separately, but concurrently with the issuance of our 2025 Notes, we entered into transactions whereby we sold warrants (the “2025 Warrants”) to acquire 40 million shares of our common stock with a strike price of $68.08 per share, subject to anti-dilution adjustments, for aggregate proceeds of $203 million. The 2025 Warrants are exercisable over 60 scheduled trading days beginning September 2025. The shares issuable under the 2025 Warrants are included in the calculation of diluted earnings per share when the average market value per share of our common stock for the reporting period exceeds the strike price of the 2025 Warrants.

- changed (2025-11-20):
[0001327567-25-000035:note_history:35]
During the three months ended October 31, 2025, we net settled a portion of the 2025 Warrants with 20 million shares of our common stock with a fair value of $4.1 billion. The number of net shares issued was determined based on the number of 2025 Warrants exercised multiplied by the difference between the strike price of the 2025 Warrants and their daily volume-weighted-average stock price. As of October 31, 2025, up to 11 million shares of our common stock were issuable for gross settlement under the remaining outstanding 2025 Warrants, which will be net settled when exercised through the end of November 2025.
  (was, 2025-05-21, similarity 0.6744):
[0001327567-25-000017:note_history:35]
During the nine months ended April 30, 2024, we net settled all of the 2023 Warrants with 18.0 million shares of our common stock with a fair value of $2.4 billion. The number of net shares issued was determined based on the number of 2023 Warrants exercised multiplied by the difference between the strike price of the 2023 Warrants and their daily volume-weighted-average stock price.

- changed (2025-11-20):
[0001327567-25-000035:note_history:36]
The borrowings under the Credit Facility bear interest, at our option, at a base rate plus a spread of 0.000% to 0.375%, or an adjusted term Secured Overnight Financing Rate plus a spread of 1.000% to 1.375%, in each case with such spread being determined based on our leverage ratio. We are obligated to pay an ongoing commitment fee on undrawn amounts at a rate of 0.090% to 0.150%, depending on our leverage ratio. The interest rates and commitment fees are also subject to upward and downward adjustments based on our progress towards the achievement of certain sustainability goals.
  (was, 2025-05-21, similarity 0.9616):
[0001327567-25-000017:note_history:36]
The borrowings under the Credit Facility bear interest, at our option, at a base rate plus a spread of 0.000% to 0.375%, or an adjusted term Secured Overnight Financing Rate (“SOFR”) plus a spread of 1.000% to 1.375%, in each case with such spread being determined based on our leverage ratio. We are obligated to pay an ongoing commitment fee on undrawn amounts at a rate of 0.090% to 0.150%, depending on our leverage ratio. The interest rates and commitment fees are also subject to upward and downward adjustments based on our progress towards the achievement of certain sustainability goals related to greenhouse gas emissions.

- changed (2025-11-20):
[0001327567-25-000035:note_history:37]
As of October 31, 2025, there were no amounts outstanding and we were in compliance with all covenants under the Credit Agreement.
  (was, 2025-05-21, similarity 0.9593):
[0001327567-25-000017:note_history:37]
As of April 30, 2025, there were no amounts outstanding and we were in compliance with all covenants under the Credit Agreement.

- removed (2025-11-20):
[0001327567-25-000017:note_history:38]
In June 2020, we issued $2.0 billion aggregate principal amount of 0.375% Convertible Senior Notes due 2025 (the “2025 Notes”). The 2025 Notes bear interest at a fixed rate of 0.375% per year, payable semi-annually in arrears on June 1 and December 1 of each year, beginning on December 1, 2020. The 2025 Notes are governed by an indenture between us, as the issuer, and U.S. Bank National Association, as Trustee (the “Indenture”). The 2025 Notes are unsecured, unsubordinated obligations and the Indenture governing the 2025 Notes does not contain any financial covenants or restrictions on the payments of dividends, the incurrence of indebtedness, or the issuance or repurchase of securities by us or any of our subsidiaries. The 2025 Notes mature on June 1, 2025. We may redeem for cash all or any portion of the 2025 Notes, at our option, on or after June 5, 2023 and prior to the 31st scheduled trading day immediately preceding the maturity date if the last reported sale price of our common stock has been at least 130% of the conversion price then in effect for at least 20 trading days during any 30 consecutive trading day period ending on and including the trading day preceding the date on which we provide notice of redemption. The redemption will be at a price equal to 100% of the principal amount of the 2025 Notes and adjusted for interest. If we call any or all of the 2025 Notes for redemption, holders may convert such 2025 Notes called for redemption at any time prior to the close of business on the second scheduled trading day immediately preceding the redemption date.

- removed (2025-11-20):
[0001327567-25-000017:note_history:39]
The 2025 Notes are convertible for an initial 40.3 million shares of our common stock at a conversion rate of approximately 20.1612 shares of common stock per $1,000 principal amount, which is equal to an initial conversion price of approximately $49.60 per share of common stock, subject to adjustments. Holders of the 2025 Notes may surrender their 2025 Notes for conversion at their option at any time prior to the close of business on the business day immediately preceding March 1, 2025 only under the following circumstances:

- removed (2025-11-20):
[0001327567-25-000017:note_history:40]
•during any fiscal quarter commencing after the fiscal quarters ending on October 31, 2020 (and only during such fiscal quarter), if the last reported sale price of our common stock for at least 20 trading days (whether or not consecutive) during a period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the conversion price for the 2025 Notes on each applicable trading day (the “sale price condition”);

- removed (2025-11-20):
[0001327567-25-000017:note_history:41]
•during the five business day period after any five consecutive trading day period (the “measurement period”) in which the trading price per $1,000 principal amount of the 2025 Notes for each trading day of the measurement period was less than 98% of the product of the last reported sale price of our common stock and the conversion rate for the 2025 Notes on each such trading day; or

- removed (2025-11-20):
[0001327567-25-000017:note_history:42]
•upon the occurrence of specified corporate events.

- removed (2025-11-20):
[0001327567-25-000017:note_history:43]
On or after March 1, 2025, holders may surrender all or any portion of their 2025 Notes for conversion at any time prior to the close of business on the second scheduled trading day immediately preceding the maturity date regardless of the foregoing conditions, and such conversions will be settled upon the maturity date. Upon conversion, holders of the 2025 Notes will receive cash equal to the aggregate principal amount of the 2025 Notes to be converted, and, at our election, cash and/or shares of our common stock for any amounts in excess of the aggregate principal amount of the 2025 Notes being converted.

- removed (2025-11-20):
[0001327567-25-000017:note_history:44]
The conversion price will be subject to adjustment in some events. Holders of the 2025 Notes who convert their 2025 Notes in connection with certain corporate events that constitute a “make-whole fundamental change” under the Indenture are, under certain circumstances, entitled to an increase in the conversion rate. Additionally, upon the occurrence of a corporate event that constitutes a “fundamental change” under the Indenture, holders of the 2025 Notes may require us to repurchase for cash all or a portion of the 2025 Notes at a repurchase price equal to 100% of the principal amount of the 2025 Notes plus accrued and unpaid interest to, but excluding, the fundamental change repurchase date.

- removed (2025-11-20):
[0001327567-25-000017:note_history:45]
Holders of the 2025 Notes were able to early convert their 2025 Notes at any time prior to the close of business on the business day immediately preceding March 1, 2025 for settlement prior to the maturity date as the sales price condition had been met during the fiscal quarter ended January 31, 2025. During the three and nine months ended April 30, 2025, holders of the 2025 Notes converted $150.9 million and $582.3 million, respectively, in aggregate principal amount of the 2025 Notes, which we repaid in cash. We also issued 2.2 million and 8.4 million shares of our common stock to the holders of the 2025 Notes during the three and nine months ended April 30, 2025, respectively, for the conversion value in excess of the principal amount. During the three and nine months ended April 30, 2024, holders of the 2025 Notes converted $661.8 million and $834.1 million, respectively, in aggregate principal amount of the 2025 Notes, which we repaid in cash. We also issued 9.1 million and 11.3 million shares of our common stock to the holders of the 2025 Notes during the three and nine months ended April 30, 2024, respectively, for the conversion value in excess of the principal amount. These shares were fully offset by shares we received from the corresponding exercise of the note hedges.

- removed (2025-11-20):
[0001327567-25-000017:note_history:46]
On or after March 1, 2025, holders may surrender their 2025 Notes for conversion at any time prior to maturity, in accordance with the terms described above. Such conversion requests will settle upon maturity of the 2025 Notes. The net carrying amount of the 2025 Notes was classified as a current liability on our condensed consolidated balance sheet as of April 30, 2025.

- removed (2025-11-20):
[0001327567-25-000017:note_history:47]
The following table sets forth the net carrying amount of our 2025 Notes (in millions):

- removed (2025-11-20):
[0001327567-25-000017:note_history:48]
|  | April 30, 2025 |  | July 31, 2024 |
| Principal | $ | 383.3 |  |  | $ | 965.6 |  |
| Less: debt issuance costs, net of amortization | (0.1) |  |  | (1.7) |  |
| Net carrying amount | $ | 383.2 |  |  | $ | 963.9 |  |

- removed (2025-11-20):
[0001327567-25-000017:note_history:49]
The total estimated fair value of the 2025 Notes was $1.4 billion as of April 30, 2025 and $3.2 billion as of July 31, 2024. The fair value was determined based on the closing trading price per $100 of the 2025 Notes as of the last day of trading for the period. We consider the fair value of the 2025 Notes as of April 30, 2025 and July 31, 2024 to be a Level 2 measurement. The fair value of the 2025 Notes is primarily affected by the trading price of our common stock and market interest rates.

- removed (2025-11-20):
[0001327567-25-000017:note_history:50]
The following table sets forth interest expense recognized related to the 2025 Notes (dollars in millions):

- removed (2025-11-20):
[0001327567-25-000017:note_history:51]
|  | Three Months Ended April 30, |  | Nine Months Ended April 30, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Contractual interest expense | $ | 0.5 |  |  | $ | 1.5 |  |  | $ | 1.8 |  |  | $ | 5.1 |  |
| Amortization of debt issuance costs | 0.2 |  |  | 0.8 |  |  | 1.0 |  |  | 2.9 |  |
| Total interest expense | $ | 0.7 |  |  | $ | 2.3 |  |  | $ | 2.8 |  |  | $ | 8.0 |  |
| Effective interest rate | 0.6 | % |  | 0.6 | % |  | 0.6 | % |  | 0.6 | % |

- removed (2025-11-20):
[0001327567-25-000017:note_history:52]
Note Hedges

- removed (2025-11-20):
[0001327567-25-000017:note_history:53]
To minimize the impact of potential economic dilution upon conversion of our convertible senior notes, we entered into separate convertible note hedge transactions (the “2025 Note Hedges”) with respect to our common stock concurrent with the issuance of the 2025 Notes.

- removed (2025-11-20):
[0001327567-25-000017:note_history:54]
The 2025 Note Hedges cover up to 40.3 million shares of our common stock at a strike price per share that corresponds to the initial conversion price of the 2025 Notes, which are also subject to adjustment, and are exercisable upon conversion of the 2025 Notes. The 2025 Note Hedges will expire upon maturity of the 2025 Notes. The 2025 Note Hedges are separate transactions and are not part of the terms of the 2025 Notes. Holders of the 2025 Notes will not have any rights with respect to the 2025 Note Hedges. Any shares of our common stock receivable by us under the 2025 Note Hedges are excluded from the calculation of diluted earnings per share as they are antidilutive. We paid an aggregate amount of $370.8 million for the 2025 Note Hedges, which is included in additional paid-in capital on our condensed consolidated balance sheets.

- removed (2025-11-20):
[0001327567-25-000017:note_history:55]
As a result of the conversions of the 2025 Notes settled during the three and nine months ended April 30, 2025, we exercised the corresponding portion of our 2025 Note Hedges and received 2.2 million and 8.4 million shares of our common stock during the respective periods. As a result of the conversions of the 2025 Notes settled during the three and nine months ended April 30, 2024, we exercised the corresponding portion of our 2025 Note Hedges and received 9.1 million and 11.3 million shares of our common stock during the respective periods.

- removed (2025-11-20):
[0001327567-25-000017:note_history:56]
Warrants

- removed (2025-11-20):
[0001327567-25-000017:note_history:57]
Separately, but concurrently with the issuance of each series of our convertible senior notes, we entered into transactions whereby we sold warrants (the “2023 Warrants,” with respect to the 0.75% convertible senior notes due 2023 issued in July 2018, the “2025 Warrants,” with respect to the 2025 Notes, and the 2023 Warrants together with the 2025 Warrants, the “Warrants”) to acquire shares of our common stock, subject to anti-dilution adjustments. The 2023 Warrants were, and the 2025 Warrants are, exercisable over 60 scheduled trading days beginning October 2023 and September 2025, respectively.

- removed (2025-11-20):
[0001327567-25-000017:note_history:58]
The following table presents details of our Warrants (in millions, except per share data):

- removed (2025-11-20):
[0001327567-25-000017:note_history:59]
|  | Initial Number of Shares |  | Strike Price per Share |  | Aggregate Proceeds |
| 2023 Warrants (1) | 38.1 |  |  | $ | 69.63 |  |  | $ | 145.4 |  |
| 2025 Warrants | 40.3 |  |  | $ | 68.08 |  |  | $ | 202.8 |  |

- removed (2025-11-20):
[0001327567-25-000017:note_history:60]
(1)The 2023 Warrants were net settled during the 60 scheduled trading days from October to December 2023.

- removed (2025-11-20):
[0001327567-25-000017:note_history:61]
The shares issuable under the Warrants are included in the calculation of diluted earnings per share when the average market value per share of our common stock for the reporting period exceeds the applicable strike price for such series of Warrants. The Warrants are separate transactions and are not part of either series of Notes or Note Hedges and are not remeasured through earnings each reporting period. Holders of the Notes of either series will not have any rights with respect to the Warrants. The aggregate proceeds received from the sale of the Warrants are included in additional paid-in capital on our condensed consolidated balance sheets.


## us-gaap:DebtSecuritiesAvailableForSaleTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-11-20):
[0001327567-25-000035:note_history:62]
The following tables summarize the amortized cost, unrealized gains and losses, and fair value of our available-for-sale debt securities as of October 31, 2025 and July 31, 2025 (in millions):
  (was, 2025-05-21, similarity 0.9724):
[0001327567-25-000017:note_history:62]
The following tables summarize the amortized cost, unrealized gains and losses, and fair value of our available-for-sale debt securities as of April 30, 2025 and July 31, 2024 (in millions):

- changed (2025-11-20):
[0001327567-25-000035:note_history:63]
|  | October 31, 2025 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | $ | 755 |  |  | $ | — |  |  | $ | — |  |  | $ | 755 |  |
| Corporate debt securities | 157 |  |  | — |  |  | — |  |  | 157 |  |
| U.S. government and agency securities | 178 |  |  | — |  |  | — |  |  | 178 |  |
| Total available-for-sale cash equivalents | $ | 1,090 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,090 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 25 |  |  | $ | — |  |  | $ | — |  |  | $ | 25 |  |
| Commercial paper | 340 |  |  | — |  |  | — |  |  | 340 |  |
| Corporate debt securities | 5,120 |  |  | 73 |  |  | (1) |  |  | 5,192 |  |
| U.S. government and agency securities | 99 |  |  | — |  |  | — |  |  | 99 |  |
| Non-U.S. government and agency securities | 29 |  |  | — |  |  | — |  |  | 29 |  |
| Asset-backed securities | 1,421 |  |  | 15 |  |  | — |  |  | 1,436 |  |
| Total available-for-sale investments | $ | 7,034 |  |  | $ | 88 |  |  | $ | (1) |  |  | $ | 7,121 |  |
  (was, 2025-05-21, similarity 0.9781):
[0001327567-25-000017:note_history:63]
|  | July 31, 2024 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | $ | 299.6 |  |  | $ | — |  |  | $ | — |  |  | $ | 299.6 |  |
| Corporate debt securities | 18.2 |  |  | — |  |  | — |  |  | 18.2 |  |
| U.S. government and agency securities | 149.6 |  |  | — |  |  | — |  |  | 149.6 |  |
| Total available-for-sale cash equivalents | $ | 467.4 |  |  | $ | — |  |  | $ | — |  |  | $ | 467.4 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 20.6 |  |  | $ | — |  |  | $ | — |  |  | $ | 20.6 |  |
| Commercial paper | 79.9 |  |  | 0.1 |  |  | (0.1) |  |  | 79.9 |  |
| Corporate debt securities | 4,065.5 |  |  | 28.3 |  |  | (6.6) |  |  | 4,087.2 |  |
| U.S. government and agency securities | 21.9 |  |  | — |  |  | (0.2) |  |  | 21.7 |  |
| Non-U.S. government and agency securities | 57.9 |  |  | 0.7 |  |  | — |  |  | 58.6 |  |
| Asset-backed securities | 943.1 |  |  | 6.3 |  |  | (0.6) |  |  | 948.8 |  |
| Total available-for-sale investments | $ | 5,188.9 |  |  | $ | 35.4 |  |  | $ | (7.5) |  |  | $ | 5,216.8 |  |

- changed (2025-11-20):
[0001327567-25-000035:note_history:64]
|  | July 31, 2025 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | $ | 169 |  |  | $ | — |  |  | $ | — |  |  | $ | 169 |  |
| Total available-for-sale cash equivalents | $ | 169 |  |  | $ | — |  |  | $ | — |  |  | $ | 169 |  |
| Investments: |  |  |  |  |  |  |  |
| Commercial paper | 15 |  |  | — |  |  | — |  |  | 15 |  |
| Corporate debt securities | 4,588 |  |  | 47 |  |  | (1) |  |  | 4,634 |  |
| U.S. government and agency securities | 170 |  |  | — |  |  | — |  |  | 170 |  |
| Non-U.S. government and agency securities | 29 |  |  | — |  |  | — |  |  | 29 |  |
| Asset-backed securities | 1,328 |  |  | 9 |  |  | — |  |  | 1,337 |  |
| Total available-for-sale investments | $ | 6,130 |  |  | $ | 56 |  |  | $ | (1) |  |  | $ | 6,185 |  |
  (was, 2025-05-21, similarity 0.9492):
[0001327567-25-000017:note_history:64]
|  | April 30, 2025 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | $ | 575.0 |  |  | $ | — |  |  | $ | — |  |  | $ | 575.0 |  |
| Corporate debt securities | 0.7 |  |  | — |  |  | — |  |  | 0.7 |  |
| Total available-for-sale cash equivalents | $ | 575.7 |  |  | $ | — |  |  | $ | — |  |  | $ | 575.7 |  |
| Investments: |  |  |  |  |  |  |  |
| Commercial paper | 53.6 |  |  | — |  |  | — |  |  | 53.6 |  |
| Corporate debt securities | 4,607.4 |  |  | 51.2 |  |  | (1.2) |  |  | 4,657.4 |  |
| U.S. government and agency securities | 85.4 |  |  | 0.1 |  |  | — |  |  | 85.5 |  |
| Non-U.S. government and agency securities | 28.8 |  |  | 0.6 |  |  | — |  |  | 29.4 |  |
| Asset-backed securities | 1,231.7 |  |  | 11.9 |  |  | (0.4) |  |  | 1,243.2 |  |
| Total available-for-sale investments | $ | 6,006.9 |  |  | $ | 63.8 |  |  | $ | (1.6) |  |  | $ | 6,069.1 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-11-20):
[0001327567-25-000035:note_history:65]
The following tables summarize the amortized cost, unrealized gains and losses, and fair value of our available-for-sale debt securities as of October 31, 2025 and July 31, 2025 (in millions):
  (was, 2025-05-21, similarity 0.9724):
[0001327567-25-000017:note_history:65]
The following tables summarize the amortized cost, unrealized gains and losses, and fair value of our available-for-sale debt securities as of April 30, 2025 and July 31, 2024 (in millions):

- changed (2025-11-20):
[0001327567-25-000035:note_history:66]
|  | October 31, 2025 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | $ | 755 |  |  | $ | — |  |  | $ | — |  |  | $ | 755 |  |
| Corporate debt securities | 157 |  |  | — |  |  | — |  |  | 157 |  |
| U.S. government and agency securities | 178 |  |  | — |  |  | — |  |  | 178 |  |
| Total available-for-sale cash equivalents | $ | 1,090 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,090 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 25 |  |  | $ | — |  |  | $ | — |  |  | $ | 25 |  |
| Commercial paper | 340 |  |  | — |  |  | — |  |  | 340 |  |
| Corporate debt securities | 5,120 |  |  | 73 |  |  | (1) |  |  | 5,192 |  |
| U.S. government and agency securities | 99 |  |  | — |  |  | — |  |  | 99 |  |
| Non-U.S. government and agency securities | 29 |  |  | — |  |  | — |  |  | 29 |  |
| Asset-backed securities | 1,421 |  |  | 15 |  |  | — |  |  | 1,436 |  |
| Total available-for-sale investments | $ | 7,034 |  |  | $ | 88 |  |  | $ | (1) |  |  | $ | 7,121 |  |
  (was, 2025-05-21, similarity 0.9781):
[0001327567-25-000017:note_history:66]
|  | July 31, 2024 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | $ | 299.6 |  |  | $ | — |  |  | $ | — |  |  | $ | 299.6 |  |
| Corporate debt securities | 18.2 |  |  | — |  |  | — |  |  | 18.2 |  |
| U.S. government and agency securities | 149.6 |  |  | — |  |  | — |  |  | 149.6 |  |
| Total available-for-sale cash equivalents | $ | 467.4 |  |  | $ | — |  |  | $ | — |  |  | $ | 467.4 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 20.6 |  |  | $ | — |  |  | $ | — |  |  | $ | 20.6 |  |
| Commercial paper | 79.9 |  |  | 0.1 |  |  | (0.1) |  |  | 79.9 |  |
| Corporate debt securities | 4,065.5 |  |  | 28.3 |  |  | (6.6) |  |  | 4,087.2 |  |
| U.S. government and agency securities | 21.9 |  |  | — |  |  | (0.2) |  |  | 21.7 |  |
| Non-U.S. government and agency securities | 57.9 |  |  | 0.7 |  |  | — |  |  | 58.6 |  |
| Asset-backed securities | 943.1 |  |  | 6.3 |  |  | (0.6) |  |  | 948.8 |  |
| Total available-for-sale investments | $ | 5,188.9 |  |  | $ | 35.4 |  |  | $ | (7.5) |  |  | $ | 5,216.8 |  |

- changed (2025-11-20):
[0001327567-25-000035:note_history:67]
|  | July 31, 2025 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | $ | 169 |  |  | $ | — |  |  | $ | — |  |  | $ | 169 |  |
| Total available-for-sale cash equivalents | $ | 169 |  |  | $ | — |  |  | $ | — |  |  | $ | 169 |  |
| Investments: |  |  |  |  |  |  |  |
| Commercial paper | 15 |  |  | — |  |  | — |  |  | 15 |  |
| Corporate debt securities | 4,588 |  |  | 47 |  |  | (1) |  |  | 4,634 |  |
| U.S. government and agency securities | 170 |  |  | — |  |  | — |  |  | 170 |  |
| Non-U.S. government and agency securities | 29 |  |  | — |  |  | — |  |  | 29 |  |
| Asset-backed securities | 1,328 |  |  | 9 |  |  | — |  |  | 1,337 |  |
| Total available-for-sale investments | $ | 6,130 |  |  | $ | 56 |  |  | $ | (1) |  |  | $ | 6,185 |  |
  (was, 2025-05-21, similarity 0.9492):
[0001327567-25-000017:note_history:67]
|  | April 30, 2025 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | $ | 575.0 |  |  | $ | — |  |  | $ | — |  |  | $ | 575.0 |  |
| Corporate debt securities | 0.7 |  |  | — |  |  | — |  |  | 0.7 |  |
| Total available-for-sale cash equivalents | $ | 575.7 |  |  | $ | — |  |  | $ | — |  |  | $ | 575.7 |  |
| Investments: |  |  |  |  |  |  |  |
| Commercial paper | 53.6 |  |  | — |  |  | — |  |  | 53.6 |  |
| Corporate debt securities | 4,607.4 |  |  | 51.2 |  |  | (1.2) |  |  | 4,657.4 |  |
| U.S. government and agency securities | 85.4 |  |  | 0.1 |  |  | — |  |  | 85.5 |  |
| Non-U.S. government and agency securities | 28.8 |  |  | 0.6 |  |  | — |  |  | 29.4 |  |
| Asset-backed securities | 1,231.7 |  |  | 11.9 |  |  | (0.4) |  |  | 1,243.2 |  |
| Total available-for-sale investments | $ | 6,006.9 |  |  | $ | 63.8 |  |  | $ | (1.6) |  |  | $ | 6,069.1 |  |

- changed (2025-11-20):
[0001327567-25-000035:note_history:68]
Unrealized losses related to our available-for-sale debt securities are primarily due to interest rate fluctuations as opposed to credit quality. We do not intend to sell any of the securities in an unrealized loss position and it is not likely that we would be required to sell these securities before recovery of their amortized cost basis, which may be at maturity. We did not recognize any credit losses related to our available-for-sale debt securities during the three months ended October 31, 2025 and 2024.
  (was, 2025-05-21, similarity 0.9794):
[0001327567-25-000017:note_history:68]
Unrealized losses related to our available-for-sale debt securities are primarily due to interest rate fluctuations as opposed to credit quality. We do not intend to sell any of the securities in an unrealized loss position and it is not likely that we would be required to sell these securities before recovery of their amortized cost basis, which may be at maturity. We did not recognize any credit losses related to our available-for-sale debt securities during the three and nine months ended April 30, 2025 and 2024.

- changed (2025-11-20):
[0001327567-25-000035:note_history:69]
The following table summarizes the amortized cost and fair value of our available-for-sale debt securities as of October 31, 2025, by contractual years-to-maturity (in millions):
  (was, 2025-05-21, similarity 0.9708):
[0001327567-25-000017:note_history:69]
The following table summarizes the amortized cost and fair value of our available-for-sale debt securities as of April 30, 2025, by contractual years-to-maturity (in millions):

- added (2025-11-20):
[0001327567-25-000035:note_history:70]
Marketable equity securities consist of money market funds and are included in cash and cash equivalents on our condensed consolidated balance sheets. As of October 31, 2025 and July 31, 2025, the carrying values of our marketable equity securities were $1.1 billion and $1.2 billion, respectively. There were no unrealized gains or losses recognized for these securities during the three months ended October 31, 2025 and 2024.

- removed (2025-11-20):
[0001327567-25-000017:note_history:71]
As of April 30, 2025, the gross unrealized losses that have been in a continuous unrealized loss position for less than 12 months were $1.4 million, which were related to $691.9 million of available-for-sale debt securities, and the gross unrealized losses that have been in a continuous unrealized loss position for more than 12 months were $0.2 million, which were related to $145.5 million of available-for-sale debt securities. As of July 31, 2024 the gross unrealized losses that have been in a continuous unrealized loss position for less than 12 months were $1.5 million, which were related to $949.4 million of available-for-sale debt securities, and the gross unrealized losses that have been in a continuous unrealized loss position for more than 12 months were $6.0 million, which were related to $915.3 million of available-for-sale debt securities.

- removed (2025-11-20):
[0001327567-25-000017:note_history:72]
Marketable equity securities consist of money market funds and are included in cash and cash equivalents on our condensed consolidated balance sheets. As of April 30, 2025 and July 31, 2024, the carrying values of our marketable equity securities were $1.1 billion and $494.0 million, respectively. There were no unrealized gains or losses recognized for these securities during the three and nine months ended April 30, 2025 and 2024.


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2025-11-20):
[0001327567-25-000035:note_history:73]
|  |  |  | Three Months Ended October 31, |
|  |  |  |  |  | 2025 |  | 2024 |
| Revenue: |  |  |  |  |  |  |  |
| Americas |  |  |  |  |  |  |  |
| United States |  |  |  |  | $ | 1,526 |  |  | $ | 1,344 |  |
| Other Americas |  |  |  |  | 115 |  |  | 98 |  |
| Total Americas |  |  |  |  | 1,641 |  |  | 1,442 |  |
| Europe, the Middle East, and Africa (“EMEA”) |  |  |  |  | 521 |  |  | 442 |  |
| Asia Pacific and Japan (“APAC”) |  |  |  |  | 312 |  |  | 255 |  |
| Total revenue |  |  |  |  | $ | 2,474 |  |  | $ | 2,139 |  |

- added (2025-11-20):
[0001327567-25-000035:note_history:74]
|  |  |  | Three Months Ended October 31, |
|  |  |  |  |  | 2025 |  | 2024 |
| Revenue: |  |  |  |  |  |  |  |
| Product |  |  |  |  | $ | 434 |  |  | $ | 354 |  |
| Subscription and support |  |  |  |  |  |  |  |
| Subscription |  |  |  |  | 1,364 |  |  | 1,192 |  |
| Support |  |  |  |  | 676 |  |  | 593 |  |
| Total subscription and support |  |  |  |  | 2,040 |  |  | 1,785 |  |
| Total revenue |  |  |  |  | $ | 2,474 |  |  | $ | 2,139 |  |

- changed (2025-11-20):
[0001327567-25-000035:note_history:75]
During the three months ended October 31, 2025 and 2024, we recognized approximately $1.9 billion and $1.6 billion of revenue pertaining to amounts that were deferred as of July 31, 2025 and 2024, respectively.
  (was, 2025-05-21, similarity 0.9544):
[0001327567-25-000017:note_history:75]
During the nine months ended April 30, 2025 and 2024, we recognized approximately $4.4 billion and $3.7 billion of revenue pertaining to amounts that were deferred as of July 31, 2024 and 2023, respectively.

- changed (2025-11-20):
[0001327567-25-000035:note_history:76]
Remaining performance obligations were $15.5 billion as of October 31, 2025, of which we expect to recognize as revenue approximately $6.9 billion over the next 12 months and the remainder thereafter.
  (was, 2025-05-21, similarity 0.9733):
[0001327567-25-000017:note_history:76]
Remaining performance obligations were $13.5 billion as of April 30, 2025, of which we expect to recognize as revenue approximately $6.2 billion over the next 12 months and the remainder thereafter.

- removed (2025-11-20):
[0001327567-25-000017:note_history:77]
|  | Three Months Ended April 30, |  | Nine Months Ended April 30, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Revenue: |  |  |  |  |  |  |  |
| Americas |  |  |  |  |  |  |  |
| United States | $ | 1,424.4 |  |  | $ | 1,271.1 |  |  | $ | 4,169.0 |  |  | $ | 3,723.6 |  |
| Other Americas | 104.8 |  |  | 88.5 |  |  | 304.7 |  |  | 256.8 |  |
| Total Americas | 1,529.2 |  |  | 1,359.6 |  |  | 4,473.7 |  |  | 3,980.4 |  |
| Europe, the Middle East, and Africa (“EMEA”) | 480.9 |  |  | 399.2 |  |  | 1,402.3 |  |  | 1,170.9 |  |
| Asia Pacific and Japan (“APAC”) | 278.9 |  |  | 226.0 |  |  | 809.2 |  |  | 686.7 |  |
| Total revenue | $ | 2,289.0 |  |  | $ | 1,984.8 |  |  | $ | 6,685.2 |  |  | $ | 5,838.0 |  |

- removed (2025-11-20):
[0001327567-25-000017:note_history:78]
|  | Three Months Ended April 30, |  | Nine Months Ended April 30, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Revenue: |  |  |  |  |  |  |  |
| Product | $ | 452.7 |  |  | $ | 391.0 |  |  | $ | 1,228.0 |  |  | $ | 1,122.8 |  |
| Subscription and support |  |  |  |  |  |  |  |
| Subscription | 1,234.4 |  |  | 1,045.6 |  |  | 3,659.4 |  |  | 3,061.0 |  |
| Support | 601.9 |  |  | 548.2 |  |  | 1,797.8 |  |  | 1,654.2 |  |
| Total subscription and support | 1,836.3 |  |  | 1,593.8 |  |  | 5,457.2 |  |  | 4,715.2 |  |
| Total revenue | $ | 2,289.0 |  |  | $ | 1,984.8 |  |  | $ | 6,685.2 |  |  | $ | 5,838.0 |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_prior_note, score: 0.0

- added (2025-11-20):
[0001327567-25-000035:note_history:79]
Subsequent Events
Share Repurchase

- added (2025-11-20):
[0001327567-25-000035:note_history:80]
On November 18, 2025, our board of directors authorized the extension of the expiration date of our current share repurchase authorization to December 31, 2026. Our repurchase program may be suspended or discontinued at any time without prior notice. Repurchases may be made at management’s discretion from time to time on the open market, through privately negotiated transactions, transactions structured through investment banking institutions, block purchase techniques, 10b5-1 trading plans, or a combination of the foregoing.

- added (2025-11-20):
[0001327567-25-000035:note_history:81]
Chronosphere, Inc.

- added (2025-11-20):
[0001327567-25-000035:note_history:82]
On November 19, 2025, we entered into a definitive agreement to acquire Chronosphere, Inc., a privately-held observability technology company (“Chronosphere”), in exchange for total consideration of $3.35 billion in cash and replacement awards, subject to adjustments. We expect the acquisition to be our entry into the observability space. The acquisition of Chronosphere is expected to close during the second half of our fiscal 2026, subject to the satisfaction of closing conditions, including regulatory clearance.
