# PANW notes — 0001327567-25-000035


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock

[0001327567-25-000035:notes:1]
[same as prior period, unchanged from 0001327567-25-000017:notes:1]

[0001327567-25-000035:notes:2]
Palo Alto Networks, Inc. (the “Company,” “we,” “us,” or “our”), headquartered in Santa Clara, California, was incorporated in March 2005 under the laws of the State of Delaware and commenced operations in April 2005. Our cybersecurity platforms and services help enterprises, organizations, service providers, and government entities to secure their users, networks, clouds, and endpoints by delivering comprehensive cybersecurity backed by artificial intelligence and automation.

[0001327567-25-000035:notes:3]
[same as prior period, unchanged from 0001327567-25-000017:notes:3]

[0001327567-25-000035:notes:4]
The accompanying condensed consolidated financial statements have been prepared in conformity with U.S. generally accepted accounting principles (“U.S. GAAP”), consistent in all material respects with those applied in our Annual Report on Form 10-K for the fiscal year ended July 31, 2025, filed with the Securities and Exchange Commission (“SEC”) on August 29, 2025. The condensed consolidated financial statements include our accounts and our wholly owned subsidiaries. All significant intercompany balances and transactions have been eliminated in consolidation.

[0001327567-25-000035:notes:5]
The condensed consolidated financial statements are unaudited but include all adjustments of a normal recurring nature necessary for a fair presentation of our quarterly results. Our condensed consolidated financial statements should be read in conjunction with the audited consolidated financial statements and related notes in our Annual Report on Form 10-K for the fiscal year ended July 31, 2025.

[0001327567-25-000035:notes:6]
[same as prior period, unchanged from 0001327567-25-000017:notes:6]

[0001327567-25-000035:notes:7]
The preparation of condensed consolidated financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the amounts reported and disclosed in the condensed consolidated financial statements and the accompanying notes. We evaluate our estimates on an ongoing basis. Management estimates include, but are not limited to, the standalone selling price for our products and services, share-based compensation, fair value of assets acquired and liabilities assumed in business combinations, fair value of contingent consideration liability, the assessment of recoverability of our intangibles and goodwill, valuation allowance against deferred tax assets, valuation of inventory and manufacturing partner and supplier liabilities, deferred contract cost benefit period, and loss contingencies. We base our estimates on assumptions, both historical and forward looking, that we believe are reasonable. Actual results could differ materially from those estimates due to risks and uncertainties.

[0001327567-25-000035:notes:8]
[same as prior period, unchanged from 0001327567-25-000017:notes:10]

[0001327567-25-000035:notes:9]
There have been no material changes to our significant accounting policies as of and for the three months ended October 31, 2025, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended July 31, 2025.

[0001327567-25-000035:notes:10]
Recently Issued Accounting Pronouncements

[0001327567-25-000035:notes:11]
[same as prior period, unchanged from 0001327567-25-000017:notes:18]

[0001327567-25-000035:notes:12]
In December 2023, the Financial Accounting Standards Board (“FASB”) issued authoritative guidance that requires consistent categories and greater disaggregation of information in the effective tax rate reconciliation and additional disclosures of income taxes paid by jurisdiction. The standard is effective for our annual periods beginning in fiscal 2026 and could be applied either prospectively or retrospectively. We are currently evaluating the impact of this standard on our disclosures in the consolidated financial statements.

[0001327567-25-000035:notes:13]
[same as prior period, unchanged from 0001327567-25-000017:notes:20]

[0001327567-25-000035:notes:14]
In November 2024, the FASB issued authoritative guidance that expands annual and interim disclosure of specified information about certain costs and expenses in the notes to financial statements. The standard is effective for our annual periods beginning in fiscal 2028 and interim periods beginning in the first quarter of fiscal 2029, and could be applied either prospectively or retrospectively. Early adoption is permitted. We are currently evaluating the impact of this standard on our disclosures in the consolidated financial statements.

[0001327567-25-000035:notes:15]
Measurement of Credit Losses for Accounts Receivable and Contract Assets

[0001327567-25-000035:notes:16]
In July 2025, the FASB issued authoritative guidance that provides a practical expedient for estimating expected credit losses on accounts receivable and contract assets. The standard is effective for our annual and interim periods beginning in the first quarter of fiscal 2027 and will be applied on a prospective basis. Early adoption is permitted. We are currently evaluating the impact of this standard on our consolidated financial statements.

[0001327567-25-000035:notes:17]
Accounting for Internal-Use Software

[0001327567-25-000035:notes:18]
In September 2025, the FASB issued authoritative guidance that modernizes the accounting for internal-use software by eliminating project stage-based capitalization and clarifying the requirements, including probable-to-complete threshold, to commence the capitalization of software development costs. The standard is effective for our annual and interim periods beginning in the first quarter of fiscal 2029 and could be applied either prospectively or retrospectively. Early adoption is permitted. We are currently evaluating the impact of this standard on our consolidated financial statements.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001327567-25-000035:notes:19]
[same as prior period, unchanged from 0001327567-25-000017:notes:22]

[0001327567-25-000035:notes:20]
[same as prior period, unchanged from 0001327567-25-000017:notes:23]

[0001327567-25-000035:notes:21]
|  |  |  | Three Months Ended October 31, |
|  |  |  |  |  | 2025 |  | 2024 |
| Revenue: |  |  |  |  |  |  |  |
| Americas |  |  |  |  |  |  |  |
| United States |  |  |  |  | $ | 1,526 |  |  | $ | 1,344 |  |
| Other Americas |  |  |  |  | 115 |  |  | 98 |  |
| Total Americas |  |  |  |  | 1,641 |  |  | 1,442 |  |
| Europe, the Middle East, and Africa (“EMEA”) |  |  |  |  | 521 |  |  | 442 |  |
| Asia Pacific and Japan (“APAC”) |  |  |  |  | 312 |  |  | 255 |  |
| Total revenue |  |  |  |  | $ | 2,474 |  |  | $ | 2,139 |  |

[0001327567-25-000035:notes:22]
[same as prior period, unchanged from 0001327567-25-000017:notes:25]

[0001327567-25-000035:notes:23]
|  |  |  | Three Months Ended October 31, |
|  |  |  |  |  | 2025 |  | 2024 |
| Revenue: |  |  |  |  |  |  |  |
| Product |  |  |  |  | $ | 434 |  |  | $ | 354 |  |
| Subscription and support |  |  |  |  |  |  |  |
| Subscription |  |  |  |  | 1,364 |  |  | 1,192 |  |
| Support |  |  |  |  | 676 |  |  | 593 |  |
| Total subscription and support |  |  |  |  | 2,040 |  |  | 1,785 |  |
| Total revenue |  |  |  |  | $ | 2,474 |  |  | $ | 2,139 |  |

[0001327567-25-000035:notes:24]
[same as prior period, unchanged from 0001327567-25-000017:notes:27]

[0001327567-25-000035:notes:25]
During the three months ended October 31, 2025 and 2024, we recognized approximately $1.9 billion and $1.6 billion of revenue pertaining to amounts that were deferred as of July 31, 2025 and 2024, respectively.

[0001327567-25-000035:notes:26]
[same as prior period, unchanged from 0001327567-25-000017:notes:29]

[0001327567-25-000035:notes:27]
Remaining performance obligations were $15.5 billion as of October 31, 2025, of which we expect to recognize as revenue approximately $6.9 billion over the next 12 months and the remainder thereafter.


## us-gaap:FairValueDisclosuresTextBlock

[0001327567-25-000035:notes:28]
Fair Value Measurements
The following table presents our financial assets and liabilities measured at fair value on a recurring basis as of October 31, 2025 and July 31, 2025 (in millions):

[0001327567-25-000035:notes:29]
|  | October 31, 2025 |  | July 31, 2025 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Cash equivalents: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | $ | 1,105 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,105 |  |  | $ | 1,206 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,206 |  |
| Commercial paper | — |  |  | 755 |  |  | — |  |  | 755 |  |  | — |  |  | 169 |  |  | — |  |  | 169 |  |
| Corporate debt securities | — |  |  | 157 |  |  | — |  |  | 157 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| U.S. government and agency securities | — |  |  | 178 |  |  | — |  |  | 178 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Total cash equivalents | 1,105 |  |  | 1,090 |  |  | — |  |  | 2,195 |  |  | 1,206 |  |  | 169 |  |  | — |  |  | 1,375 |  |
| Short-term investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Certificates of deposit | — |  |  | 25 |  |  | — |  |  | 25 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Commercial paper | — |  |  | 340 |  |  | — |  |  | 340 |  |  | — |  |  | 15 |  |  | — |  |  | 15 |  |
| Corporate debt securities | — |  |  | 744 |  |  | — |  |  | 744 |  |  | — |  |  | 584 |  |  | — |  |  | 584 |  |
| U.S. government and agency securities | — |  |  | 14 |  |  | — |  |  | 14 |  |  | — |  |  | 6 |  |  | — |  |  | 6 |  |
| Non-U.S. government and agency securities | — |  |  | 3 |  |  | — |  |  | 3 |  |  | — |  |  | 3 |  |  | — |  |  | 3 |  |
| Asset-backed securities | — |  |  | 13 |  |  | — |  |  | 13 |  |  | — |  |  | 22 |  |  | — |  |  | 22 |  |
| Total short-term investments | — |  |  | 1,139 |  |  | — |  |  | 1,139 |  |  | — |  |  | 630 |  |  | — |  |  | 630 |  |
| Long-term investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | — |  |  | 4,448 |  |  | — |  |  | 4,448 |  |  | — |  |  | 4,050 |  |  | — |  |  | 4,050 |  |
| U.S. government and agency securities | — |  |  | 85 |  |  | — |  |  | 85 |  |  | — |  |  | 164 |  |  | — |  |  | 164 |  |
| Non-U.S. government and agency securities | — |  |  | 26 |  |  | — |  |  | 26 |  |  | — |  |  | 26 |  |  | — |  |  | 26 |  |
| Asset-backed securities | — |  |  | 1,423 |  |  | — |  |  | 1,423 |  |  | — |  |  | 1,315 |  |  | — |  |  | 1,315 |  |
| Total long-term investments | — |  |  | 5,982 |  |  | — |  |  | 5,982 |  |  | — |  |  | 5,555 |  |  | — |  |  | 5,555 |  |
| Prepaid expenses and other current assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency forward contracts | — |  |  | 64 |  |  | — |  |  | 64 |  |  | — |  |  | 58 |  |  | — |  |  | 58 |  |
| Total prepaid expenses and other current assets | — |  |  | 64 |  |  | — |  |  | 64 |  |  | — |  |  | 58 |  |  | — |  |  | 58 |  |
| Other assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency forward contracts | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 3 |  |  | — |  |  | 3 |  |
| Total other assets | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 3 |  |  | — |  |  | 3 |  |
| Total assets measured at fair value | $ | 1,105 |  |  | $ | 8,275 |  |  | $ | — |  |  | $ | 9,380 |  |  | $ | 1,206 |  |  | $ | 6,415 |  |  | $ | — |  |  | $ | 7,621 |  |

[0001327567-25-000035:notes:30]
|  | October 31, 2025 |  | July 31, 2025 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Accrued and other liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency forward contracts | $ | — |  |  | $ | 7 |  |  | $ | — |  |  | $ | 7 |  |  | $ | — |  |  | $ | 4 |  |  | $ | — |  |  | $ | 4 |  |
| Contingent consideration | — |  |  | — |  |  | 168 |  |  | 168 |  |  | — |  |  | — |  |  | 276 |  |  | 276 |  |
| Total accrued and other liabilities | — |  |  | 7 |  |  | 168 |  |  | 175 |  |  | — |  |  | 4 |  |  | 276 |  |  | 280 |  |
| Other long-term liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Contingent consideration | — |  |  | — |  |  | 212 |  |  | 212 |  |  | — |  |  | — |  |  | 238 |  |  | 238 |  |
| Total other long-term liabilities | — |  |  | — |  |  | 212 |  |  | 212 |  |  | — |  |  | — |  |  | 238 |  |  | 238 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 7 |  |  | $ | 380 |  |  | $ | 387 |  |  | $ | — |  |  | $ | 4 |  |  | $ | 514 |  |  | $ | 518 |  |

[0001327567-25-000035:notes:31]
As part of our acquisition of certain QRadar assets from International Business Machines Corporation (“IBM”) on August 31, 2024, we agreed to make post-closing payments to IBM contingent upon customers entering into qualified new transactions through June 30, 2028. Payments related to the contingent consideration liability commenced in the fiscal quarter ended October 2025 and are expected to continue through the fiscal quarter ending October 2028. The estimated range of undiscounted contingent consideration is between $0.4 billion and $0.6 billion.

[0001327567-25-000035:notes:32]
The fair value of our contingent consideration liability is estimated using a discounted cash flow valuation technique. We consider the fair value of our contingent consideration liability to be a Level 3 measurement as we use unobservable inputs in determining discounted cash flows to estimate the fair value. The significant unobservable inputs include an estimate of future cash payments related to customers entering into qualified new transactions as well as a risk-adjusted discount rate used to present value the expected cash flows. A significant change in any of these assumptions could have a material impact to the fair value of our contingent consideration liability.

[0001327567-25-000035:notes:33]
[same as prior period, unchanged from 0001327567-25-000017:notes:35]

[0001327567-25-000035:notes:34]
|  | Three Months Ended October 31, |  |  |
|  | 2025 |  | 2024 |  |  |
| Contingent consideration liability at the beginning of the period | $ | 514 |  |  | $ | — |  |  |  |
| Initial valuation on the acquisition date | — |  |  | 649 |  |  |  |
| Change in fair value | (13) |  |  | 6 |  |  |  |
| Payments | (121) |  |  | — |  |  |  |
| Contingent consideration liability at the end of the period | $ | 380 |  |  | $ | 655 |  |  |  |

[0001327567-25-000035:notes:35]
The total estimated fair value of our financing receivables approximates their carrying amounts as of October 31, 2025 and July 31, 2025. We consider the fair value of our financing receivables to be a Level 3 measurement as we use unobservable inputs in determining discounted cash flows to estimate the fair value.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001327567-25-000035:notes:36]
Cash Equivalents and Investments
Available-for-sale Debt Securities

[0001327567-25-000035:notes:37]
The following tables summarize the amortized cost, unrealized gains and losses, and fair value of our available-for-sale debt securities as of October 31, 2025 and July 31, 2025 (in millions):

[0001327567-25-000035:notes:38]
|  | October 31, 2025 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | $ | 755 |  |  | $ | — |  |  | $ | — |  |  | $ | 755 |  |
| Corporate debt securities | 157 |  |  | — |  |  | — |  |  | 157 |  |
| U.S. government and agency securities | 178 |  |  | — |  |  | — |  |  | 178 |  |
| Total available-for-sale cash equivalents | $ | 1,090 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,090 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 25 |  |  | $ | — |  |  | $ | — |  |  | $ | 25 |  |
| Commercial paper | 340 |  |  | — |  |  | — |  |  | 340 |  |
| Corporate debt securities | 5,120 |  |  | 73 |  |  | (1) |  |  | 5,192 |  |
| U.S. government and agency securities | 99 |  |  | — |  |  | — |  |  | 99 |  |
| Non-U.S. government and agency securities | 29 |  |  | — |  |  | — |  |  | 29 |  |
| Asset-backed securities | 1,421 |  |  | 15 |  |  | — |  |  | 1,436 |  |
| Total available-for-sale investments | $ | 7,034 |  |  | $ | 88 |  |  | $ | (1) |  |  | $ | 7,121 |  |

[0001327567-25-000035:notes:39]
|  | July 31, 2025 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | $ | 169 |  |  | $ | — |  |  | $ | — |  |  | $ | 169 |  |
| Total available-for-sale cash equivalents | $ | 169 |  |  | $ | — |  |  | $ | — |  |  | $ | 169 |  |
| Investments: |  |  |  |  |  |  |  |
| Commercial paper | 15 |  |  | — |  |  | — |  |  | 15 |  |
| Corporate debt securities | 4,588 |  |  | 47 |  |  | (1) |  |  | 4,634 |  |
| U.S. government and agency securities | 170 |  |  | — |  |  | — |  |  | 170 |  |
| Non-U.S. government and agency securities | 29 |  |  | — |  |  | — |  |  | 29 |  |
| Asset-backed securities | 1,328 |  |  | 9 |  |  | — |  |  | 1,337 |  |
| Total available-for-sale investments | $ | 6,130 |  |  | $ | 56 |  |  | $ | (1) |  |  | $ | 6,185 |  |

[0001327567-25-000035:notes:40]
Unrealized losses related to our available-for-sale debt securities are primarily due to interest rate fluctuations as opposed to credit quality. We do not intend to sell any of the securities in an unrealized loss position and it is not likely that we would be required to sell these securities before recovery of their amortized cost basis, which may be at maturity. We did not recognize any credit losses related to our available-for-sale debt securities during the three months ended October 31, 2025 and 2024.

[0001327567-25-000035:notes:41]
The following table summarizes the amortized cost and fair value of our available-for-sale debt securities as of October 31, 2025, by contractual years-to-maturity (in millions):

[0001327567-25-000035:notes:42]
|  | Amortized Cost |  | Fair Value |
| Due within one year | $ | 2,226 |  |  | $ | 2,229 |  |
| Due between one and three years | 2,299 |  |  | 2,327 |  |
| Due between three and five years | 3,133 |  |  | 3,182 |  |
| Due between five and ten years | 286 |  |  | 290 |  |
| Due after ten years | 180 |  |  | 183 |  |
| Total | $ | 8,124 |  |  | $ | 8,211 |  |

[0001327567-25-000035:notes:43]
Marketable Equity Securities

[0001327567-25-000035:notes:44]
Marketable equity securities consist of money market funds and are included in cash and cash equivalents on our condensed consolidated balance sheets. As of October 31, 2025 and July 31, 2025, the carrying values of our marketable equity securities were $1.1 billion and $1.2 billion, respectively. There were no unrealized gains or losses recognized for these securities during the three months ended October 31, 2025 and 2024.


## us-gaap:FinancingReceivablesTextBlock

[0001327567-25-000035:notes:45]
Financing Receivables
The following table summarizes our short-term and long-term financing receivables as of October 31, 2025 and July 31, 2025 (in millions):

[0001327567-25-000035:notes:46]
|  | October 31, 2025 |  | July 31, 2025 |
| Short-term financing receivables, gross | $ | 823 |  |  | $ | 806 |  |
| Unearned income | (80) |  |  | (86) |  |
| Allowance for credit losses | (6) |  |  | (5) |  |
| Short-term financing receivables, net | $ | 737 |  |  | $ | 715 |  |
| Long-term financing receivables, gross | $ | 927 |  |  | $ | 1,079 |  |
| Unearned income | (63) |  |  | (69) |  |
| Allowance for credit losses | (9) |  |  | (8) |  |
| Long-term financing receivables, net | $ | 855 |  |  | $ | 1,002 |  |

[0001327567-25-000035:notes:47]
[same as prior period, unchanged from 0001327567-25-000017:notes:51]

[0001327567-25-000035:notes:48]
| Internal Risk Rating(1) |  | October 31, 2025 |  | July 31, 2025 |
|  | Fiscal Year of Origination |  |  |  | Fiscal Year of Origination |  |  |
|  | 2026 |  | 2025 |  | 2024 |  | 2023 |  | 2022 |  | Total |  | 2025 |  | 2024 |  | 2023 |  | 2022 |  | 2021 |  | Total |
| 1 to 4 |  | $ | — |  |  | $ | 301 |  |  | $ | 675 |  |  | $ | 177 |  |  | $ | 5 |  |  | $ | 1,158 |  |  | $ | 261 |  |  | $ | 732 |  |  | $ | 242 |  |  | $ | 9 |  |  | $ | 18 |  |  | $ | 1,262 |  |
| 5 to 6 |  | 28 |  |  | 188 |  |  | 183 |  |  | 36 |  |  | — |  |  | 435 |  |  | 174 |  |  | 226 |  |  | 50 |  |  | — |  |  | — |  |  | 450 |  |
| 7 to 10 |  | — |  |  | — |  |  | 4 |  |  | 10 |  |  | — |  |  | 14 |  |  | — |  |  | 4 |  |  | 14 |  |  | — |  |  | — |  |  | 18 |  |
| Amortized cost basis of financing receivables |  | $ | 28 |  |  | $ | 489 |  |  | $ | 862 |  |  | $ | 223 |  |  | $ | 5 |  |  | $ | 1,607 |  |  | $ | 435 |  |  | $ | 962 |  |  | $ | 306 |  |  | $ | 9 |  |  | $ | 18 |  |  | $ | 1,730 |  |

[0001327567-25-000035:notes:49]
[same as prior period, unchanged from 0001327567-25-000017:notes:53]

[0001327567-25-000035:notes:50]
There was no significant activity in allowance for credit losses during the three months ended October 31, 2025 and 2024. Past due amounts on financing receivables were not material as of October 31, 2025 and July 31, 2025.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001327567-25-000035:notes:51]
[same as prior period, unchanged from 0001327567-25-000017:notes:56]

[0001327567-25-000035:notes:52]
As of October 31, 2025 and July 31, 2025, the total notional amount of our outstanding foreign currency forward contracts designated as cash flow hedges was $760 million and $964 million, respectively. Refer to Note 3. Fair Value Measurements for the fair value of our derivative instruments as reported on our condensed consolidated balance sheets as of October 31, 2025 and July 31, 2025.

[0001327567-25-000035:notes:53]
As of October 31, 2025, unrealized gains and losses in accumulated other comprehensive income (“AOCI”) related to our cash flow hedges were a $32 million net gain, of which $34 million in gains are expected to be recognized into earnings within the next 12 months. As of July 31, 2025, unrealized gains and losses in AOCI related to our cash flow hedges were a $40 million net gain.

[0001327567-25-000035:notes:54]
As of October 31, 2025 and July 31, 2025, the notional amount of our outstanding foreign currency forward contracts not designated as hedging instruments was $586 million and $504 million, respectively.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001327567-25-000035:notes:55]
Acquisition
CyberArk Software Ltd.

[0001327567-25-000035:notes:56]
On July 30, 2025, we entered into a definitive agreement to acquire CyberArk Software Ltd., an identity security company (“CyberArk”). The acquisition is expected to close during the third quarter of our fiscal 2026, subject to the satisfaction of customary closing conditions, including the receipt of certain approvals under specified antitrust and foreign investment laws. Under the terms of the agreement, CyberArk shareholders will receive $45.00 in cash and 2.2005 shares of our common stock for each CyberArk share. This represents an equity value of approximately $25 billion for CyberArk based on the unaffected 10-day average daily volume-weighted average trading prices of our common stock as of July 25, 2025. We expect to fund the cash portion of the consideration with our cash on hand. The agreement also provides that we will assume certain unvested outstanding equity awards held by CyberArk employees.

[0001327567-25-000035:notes:57]
We and CyberArk each have certain termination rights under the definitive acquisition agreement. A termination fee of $1.0 billion may be payable by us to CyberArk, or a fee of $750 million may be payable by CyberArk to us, upon termination of the definitive acquisition agreement under specified circumstances.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001327567-25-000035:notes:58]
Intangible Assets
Purchased Intangible Assets

[0001327567-25-000035:notes:59]
The following table presents details of our purchased intangible assets as of October 31, 2025 and July 31, 2025 (in millions):

[0001327567-25-000035:notes:60]
|  | October 31, 2025 |  | July 31, 2025 |
|  | Gross Carrying Amount |  | Accumulated Amortization |  | Net Carrying Amount |  | Gross Carrying Amount |  | Accumulated Amortization |  | Net Carrying Amount |
| Intangible assets subject to amortization: |  |  |  |  |  |  |  |  |  |  |  |
| Developed technology | $ | 515 |  |  | $ | (279) |  |  | $ | 236 |  |  | $ | 536 |  |  | $ | (274) |  |  | $ | 262 |  |
| Customer relationships | 609 |  |  | (137) |  |  | 472 |  |  | 609 |  |  | (123) |  |  | 486 |  |
| Acquired intellectual property | 24 |  |  | (9) |  |  | 15 |  |  | 24 |  |  | (9) |  |  | 15 |  |
| Other | 1 |  |  | (1) |  |  | — |  |  | 1 |  |  | (1) |  |  | — |  |
| Total purchased intangible assets | $ | 1,149 |  |  | $ | (426) |  |  | $ | 723 |  |  | $ | 1,170 |  |  | $ | (407) |  |  | $ | 763 |  |

[0001327567-25-000035:notes:61]
We recognized amortization expense of $40 million and $41 million for the three months ended October 31, 2025 and 2024 respectively.

[0001327567-25-000035:notes:62]
The following table summarizes estimated future amortization expense of our intangible assets subject to amortization as of October 31, 2025 (in millions):

[0001327567-25-000035:notes:63]
|  |  |  | Fiscal years ending July 31, |
|  | Total |  | Remaining 2026 |  | 2027 |  | 2028 |  | 2029 |  | 2030 |  | 2031 and Thereafter |
| Future amortization expense | $ | 723 |  |  | $ | 116 |  |  | $ | 125 |  |  | $ | 104 |  |  | $ | 78 |  |  | $ | 62 |  |  | $ | 238 |  |


## us-gaap:DebtDisclosureTextBlock

[0001327567-25-000035:notes:64]
Debt
Convertible Senior Notes, Note Hedges, and Warrants

[0001327567-25-000035:notes:65]
In June 2020, we issued $2.0 billion aggregate principal amount of 0.375% Convertible Senior Notes due 2025 (the “2025 Notes”). The 2025 Notes were converted prior to or settled on the maturity date of June 1, 2025 in accordance with their terms.

[0001327567-25-000035:notes:66]
Concurrent with the issuance of the 2025 Notes, we entered into separate convertible note hedge transactions (the “2025 Note Hedges”) with respect to our common stock for an aggregate payment of $371 million. The 2025 Note Hedges expired upon maturity of the 2025 Notes. Any shares of our common stock receivable by us under the 2025 Note Hedges are excluded from the calculation of diluted earnings per share as they are antidilutive.

[0001327567-25-000035:notes:67]
Separately, but concurrently with the issuance of our 2025 Notes, we entered into transactions whereby we sold warrants (the “2025 Warrants”) to acquire 40 million shares of our common stock with a strike price of $68.08 per share, subject to anti-dilution adjustments, for aggregate proceeds of $203 million. The 2025 Warrants are exercisable over 60 scheduled trading days beginning September 2025. The shares issuable under the 2025 Warrants are included in the calculation of diluted earnings per share when the average market value per share of our common stock for the reporting period exceeds the strike price of the 2025 Warrants.

[0001327567-25-000035:notes:68]
During the three months ended October 31, 2025, we net settled a portion of the 2025 Warrants with 20 million shares of our common stock with a fair value of $4.1 billion. The number of net shares issued was determined based on the number of 2025 Warrants exercised multiplied by the difference between the strike price of the 2025 Warrants and their daily volume-weighted-average stock price. As of October 31, 2025, up to 11 million shares of our common stock were issuable for gross settlement under the remaining outstanding 2025 Warrants, which will be net settled when exercised through the end of November 2025.

[0001327567-25-000035:notes:69]
Revolving Credit Facility

[0001327567-25-000035:notes:70]
On April 13, 2023, we entered into a credit agreement (the “Credit Agreement”) with certain institutional lenders that provides for a $400 million unsecured revolving credit facility (the “Credit Facility”), with an option to increase the amount of the Credit Facility by up to an additional $350 million, subject to certain conditions. The Credit Facility matures on April 13, 2028.

[0001327567-25-000035:notes:71]
The borrowings under the Credit Facility bear interest, at our option, at a base rate plus a spread of 0.000% to 0.375%, or an adjusted term Secured Overnight Financing Rate plus a spread of 1.000% to 1.375%, in each case with such spread being determined based on our leverage ratio. We are obligated to pay an ongoing commitment fee on undrawn amounts at a rate of 0.090% to 0.150%, depending on our leverage ratio. The interest rates and commitment fees are also subject to upward and downward adjustments based on our progress towards the achievement of certain sustainability goals.

[0001327567-25-000035:notes:72]
As of October 31, 2025, there were no amounts outstanding and we were in compliance with all covenants under the Credit Agreement.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001327567-25-000035:notes:73]
Commitments and Contingencies
Purchase Commitments

[0001327567-25-000035:notes:74]
We have entered into various non-cancelable agreements with cloud hosting service providers, under which we are committed to minimum or fixed purchases of certain cloud hosting services. In addition, in order to reduce manufacturing lead times and plan for adequate supply, we have entered into agreements with manufacturing partners and component suppliers to procure inventory based on our demand forecasts. Other purchase obligations include non-cancellable subscription agreements and other commitments in the normal course of business. The following table presents details of the aggregate future non-cancelable purchase commitments under these agreements as of October 31, 2025 (in millions):

[0001327567-25-000035:notes:75]
|  |  |  | Fiscal years ending July 31, |
|  | Total |  | Remaining 2026 |  | 2027 |  | 2028 |  | 2029 |  | 2030 |  | 2031 and Thereafter |
| Cloud | $ | 6,380 |  |  | $ | 60 |  |  | $ | 660 |  |  | $ | 998 |  |  | $ | 1,017 |  |  | $ | 1,148 |  |  | $ | 2,497 |  |
| Manufacturing | 185 |  |  | 185 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Other | 141 |  |  | 66 |  |  | 61 |  |  | 7 |  |  | 3 |  |  | 4 |  |  | — |  |
| Total | $ | 6,706 |  |  | $ | 311 |  |  | $ | 721 |  |  | $ | 1,005 |  |  | $ | 1,020 |  |  | $ | 1,152 |  |  | $ | 2,497 |  |

[0001327567-25-000035:notes:76]
Additionally, we have a $112 million minimum purchase commitment with a cloud hosting service provider through September 2027 with no specified annual commitments.

[0001327567-25-000035:notes:77]
Litigation

[0001327567-25-000035:notes:78]
We are subject to legal proceedings, claims, tax matters, and litigation arising in the ordinary course of business, including, for instance, intellectual property and patent litigation. We accrue for contingencies when we believe that a loss is probable and that we can reasonably estimate the amount of any such loss.

[0001327567-25-000035:notes:79]
Legal matters could include speculative, substantial, or indeterminate monetary amounts. Significant judgment is required to determine both the likelihood of there being a loss and the estimated amount of a loss related to such matters, and we may be unable to estimate the reasonably possible loss or range of loss. The outcomes of outstanding legal matters are inherently unpredictable, and could, either individually or in aggregate, have a material adverse effect on us and our results of operations. To the extent there is a reasonable possibility that a loss exceeding any amounts already recognized may be incurred, we will either disclose the estimated additional loss or state that such an estimate cannot be made.

[0001327567-25-000035:notes:80]
The following matters arose in the ordinary course of business.

[0001327567-25-000035:notes:81]
Centripetal Networks, Inc. v. Palo Alto Networks

[0001327567-25-000035:notes:82]
On March 12, 2021, Centripetal Networks, Inc., filed a lawsuit against us in the United States District Court for the Eastern District of Virginia. The lawsuit alleges that our products infringe multiple Centripetal patents. We successfully challenged certain of these patents, which were found unpatentable by the U.S. Patent and Trademark Office (“PTO”). The case went to jury trial on January 22, 2024, on four patents. On January 31, 2024, the jury returned a verdict of non-willful infringement with a lump sum amount of $152 million, plus statutory interest. After post-trial motions, a judgment was issued on October 3, 2024 affirming infringement on three patents, reversing infringement on the fourth patent, and subsequently, reducing the damages amount to $114 million. We posted a surety bond that was agreed upon by the parties and approved by the court. This bond prevents execution of the judgment while appeals are pending. In addition, Centripetal filed infringement contentions on certain of their patents in the European Patent Office and Unified Patent Court in Germany, to which we filed appropriate legal challenges. Those matters are still pending.

[0001327567-25-000035:notes:83]
As of October 31, 2025 and July 31, 2025, we accrued $147 million and $146 million based on the judgment and estimated interest, which is recorded in other long-term liabilities on our condensed consolidated balance sheets. The corresponding charge was $1 million for the three months ended October 31, 2025. We recorded a release of $43 million for the three months ended October 31, 2024. These amounts are included in general and administrative expense on our condensed consolidated statements of operations.

[0001327567-25-000035:notes:84]
Finjan, Inc. v. Palo Alto Networks

[0001327567-25-000035:notes:85]
On November 4, 2014, Finjan, Inc., filed a lawsuit against us in the United States District Court for the Northern District of California. The lawsuit alleges that our products infringe multiple Finjan patents. The complaint requests injunctive relief, monetary damages, and attorneys’ fees. On March 21, 2025, the judge issued an order granting summary judgment of non-infringement on all remaining patents at issue. Plaintiff filed a Notice of Appeal on April 21, 2025. We are unable, at this time, to reasonably estimate a possible loss or potential range of loss, if any.

[0001327567-25-000035:notes:86]
Eire OG Innovations. v. Palo Alto Networks

[0001327567-25-000035:notes:87]
On April 3, 2024, Eire OG Innovations filed a lawsuit against us in the United States District Court for the Eastern District of Texas asserting infringement of multiple patents, certain of which were subsequently dismissed. The complaint requests monetary damages and attorneys’ fees. Trial is set for February 17, 2026. As of October 31, 2025, we accrued for an immaterial amount related to this matter.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001327567-25-000035:notes:88]
[same as prior period, unchanged from 0001327567-25-000017:notes:126]

[0001327567-25-000035:notes:89]
In February 2019, our board of directors authorized a $1.0 billion share repurchase program, which is funded from available working capital. Our board of directors subsequently authorized additional increases to this share repurchase program, bringing the total authorization under this share repurchase program to $4.1 billion (our “current authorization”). As of October 31, 2025, the expiration date of our current authorization was December 31, 2025. The expiration date of the authorization was subsequently extended to December 31, 2026. Refer to Note 16. Subsequent Events for additional information. Our repurchase program may be suspended or discontinued at any time. Repurchases may be made at management’s discretion from time to time on the open market, through privately negotiated transactions, transactions structured through investment banking institutions, block purchase techniques, 10b5-1 trading plans, or a combination of the foregoing.

[0001327567-25-000035:notes:90]
We did not repurchase shares of our common stock during the three months ended October 31, 2025 and 2024.
As of October 31, 2025, $1.0 billion remained available for future share repurchases under our current repurchase authorization.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001327567-25-000035:notes:91]
[same as prior period, unchanged from 0001327567-25-000017:notes:130]

[0001327567-25-000035:notes:92]
The following table summarizes the RSU and PSU activity under our stock plans during the three months ended October 31, 2025 (in millions, except per share amounts):

[0001327567-25-000035:notes:93]
|  | Unvested RSUs |  | Unvested PSUs |
|  | Number of Shares |  | Weighted-Average Grant-Date Fair Value Per Share |  |  |  | Aggregate Intrinsic Value |  | Number of Shares |  | Weighted-Average Grant-Date Fair Value Per Share |  |  |  | Aggregate Intrinsic Value |
| Balance—July 31, 2025 | 13 |  |  | $ | 143.33 |  |  |  |  | $ | 2,285 |  |  | 9 |  |  | $ | 140.92 |  |  |  |  | $ | 1,635 |  |
| Granted(1) | 1 |  |  | $ | 190.48 |  |  |  |  |  |  | 3 |  |  | $ | 182.59 |  |  |  |  |  |
| Vested(2) | (2) |  |  | $ | 122.51 |  |  |  |  |  |  | — |  |  | $ | 62.72 |  |  |  |  |  |
| Forfeited | — |  |  | $ | 136.82 |  |  |  |  |  |  | — |  |  | $ | 194.01 |  |  |  |  |  |
| Balance—October 31, 2025 | 12 |  |  | $ | 150.94 |  |  |  |  | $ | 2,623 |  |  | 12 |  |  | $ | 153.01 |  |  |  |  | $ | 2,677 |  |

[0001327567-25-000035:notes:94]
[same as prior period, unchanged from 0001327567-25-000017:notes:133]

[0001327567-25-000035:notes:95]
[same as prior period, unchanged from 0001327567-25-000017:notes:134]

[0001327567-25-000035:notes:96]
Our RSUs generally vest over a period of four years from the date of grant. Until vested, RSUs do not have the voting and dividend participation rights of common stock and the shares underlying the awards are not considered issued and outstanding.

[0001327567-25-000035:notes:97]
[same as prior period, unchanged from 0001327567-25-000017:notes:136]

[0001327567-25-000035:notes:98]
During the three months ended October 31, 2025, we granted 3 million shares of PSUs that contain service, performance, and market conditions. The service conditions are satisfied after a period of one to three years. The performance conditions are based on an average of next-generation security annualized recurring revenue and non-GAAP net income per diluted share. The market condition is measured based on our total shareholder return (“TSR”) relative to the TSR of the companies listed in the Standard & Poor’s 500 index. As of October 31, 2025, we have approved 3 million shares of PSUs, which will be granted upon the performance condition being established during the next two fiscal years.

[0001327567-25-000035:notes:99]
The fair value of the PSUs subject to market conditions is estimated on the grant date using a Monte Carlo simulation model. The following table summarizes the assumptions used and the resulting grant-date fair value of our PSUs subject to market conditions granted during the three months ended October 31, 2025 and 2024:

[0001327567-25-000035:notes:100]
|  |  |  | Three Months Ended October 31, |
|  |  |  |  |  | 2025 |  | 2024 |
| Volatility |  |  |  |  | 36.6% - 42.6% |  | 44.1% - 47.6% |
| Expected term (in years) |  |  |  |  | 1.0 - 3.0 |  | 1.0 - 2.9 |
| Dividend yield |  |  |  |  | 0.0 | % |  | 0.0 | % |
| Risk-free interest rate |  |  |  |  | 3.6% - 3.9% |  | 3.7% - 4.5% |
| Grant-date fair value per share |  |  |  |  | $226.06 - $261.62 |  | $264.51 - $305.83 |

[0001327567-25-000035:notes:101]
[same as prior period, unchanged from 0001327567-25-000017:notes:140]

[0001327567-25-000035:notes:102]
We have granted PSOs with both service and market conditions. The market conditions were achieved when certain stock price targets were met. As of October 31, 2025 and July 31, 2025, all of our outstanding PSOs have been fully vested. The maximum contractual term of our outstanding PSOs is seven and a half years from the date of grant in fiscal year 2018 and 2019.

[0001327567-25-000035:notes:103]
The following table summarizes the PSO activity under our stock plans during the three months ended October 31, 2025 (in millions, except per share amounts):

[0001327567-25-000035:notes:104]
|  |  |  |  |  |  |  |  |  | Number of Shares |  | Weighted-Average Exercise Price Per Share |  | Weighted-Average Remaining Contractual Term (Years) |  | Aggregate Intrinsic Value |
| Balance—July 31, 2025 |  |  |  |  |  |  |  |  | 1 |  |  | $ | 32.76 |  |  | 0.5 |  | $ | 197 |  |
| Exercised |  |  |  |  |  |  |  |  | (1) |  |  | $ | 32.88 |  |  |  |  |  |
| Balance—October 31, 2025 |  |  |  |  |  |  |  |  | — |  |  | $ | 32.25 |  |  | 0.5 |  | $ | 52 |  |
| Exercisable—October 31, 2025 |  |  |  |  |  |  |  |  | — |  |  | $ | 32.25 |  |  | 0.5 |  | $ | 52 |  |

[0001327567-25-000035:notes:105]
[same as prior period, unchanged from 0001327567-25-000017:notes:144]

[0001327567-25-000035:notes:106]
[same as prior period, unchanged from 0001327567-25-000017:notes:145]

[0001327567-25-000035:notes:107]
|  |  |  | Three Months Ended October 31, |
|  |  |  |  |  | 2025 |  | 2024 |
| Cost of product revenue |  |  |  |  | $ | 1 |  |  | $ | 1 |  |
| Cost of subscription and support revenue |  |  |  |  | 32 |  |  | 31 |  |
| Research and development |  |  |  |  | 155 |  |  | 138 |  |
| Sales and marketing |  |  |  |  | 102 |  |  | 76 |  |
| General and administrative |  |  |  |  | 80 |  |  | 49 |  |
| Total share-based compensation |  |  |  |  | $ | 370 |  |  | $ | 295 |  |

[0001327567-25-000035:notes:108]
As of October 31, 2025, total compensation cost related to unvested share-based awards not yet recognized was $2.2 billion. This cost is expected to be amortized over a weighted-average period of approximately 2.4 years.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001327567-25-000035:notes:109]
Income Taxes
For the three months ended October 31, 2025 and 2024, our provision for income taxes reflected effective tax rates of 18.9% and 4.9%, respectively. Our income taxes for the three months ended October 31, 2025 and 2024 were primarily due to U.S. and foreign income taxes.

[0001327567-25-000035:notes:110]
Our effective tax rates for the three months ended October 31, 2025 and 2024 differed from the U.S. statutory tax rate primarily due to excess tax benefits from share-based compensation.


## us-gaap:EarningsPerShareTextBlock

[0001327567-25-000035:notes:111]
[same as prior period, unchanged from 0001327567-25-000017:notes:150]

[0001327567-25-000035:notes:112]
[same as prior period, unchanged from 0001327567-25-000017:notes:151]

[0001327567-25-000035:notes:113]
|  |  |  | Three Months Ended October 31, |
|  |  |  |  |  | 2025 |  | 2024 |
| Net income |  |  |  |  | $ | 334 |  |  | $ | 351 |  |
| Weighted-average shares used to compute net income per share, basic |  |  |  |  | 679 |  |  | 654 |  |
| Weighted-average effect of potentially dilutive securities: |  |  |  |  |  |  |  |
| Convertible senior notes |  |  |  |  | — |  |  | 12 |  |
| Warrants related to the issuance of convertible senior notes |  |  |  |  | 20 |  |  | 24 |  |
| Employee equity incentive plans |  |  |  |  | 10 |  |  | 19 |  |
| Weighted-average shares used to compute net income per share, diluted |  |  |  |  | 709 |  |  | 709 |  |
| Net income per share, basic |  |  |  |  | $ | 0.49 |  |  | $ | 0.54 |  |
| Net income per share, diluted |  |  |  |  | $ | 0.47 |  |  | $ | 0.49 |  |

[0001327567-25-000035:notes:114]
[same as prior period, unchanged from 0001327567-25-000017:notes:153]

[0001327567-25-000035:notes:115]
|  |  |  | Three Months Ended October 31, |
|  |  |  |  |  | 2025 |  | 2024 |
| Employee equity incentive plans |  |  |  |  | 3 |  |  | 3 |  |


## us-gaap:OtherNonoperatingIncomeAndExpenseTextBlock

[0001327567-25-000035:notes:116]
[same as prior period, unchanged from 0001327567-25-000017:notes:155]

[0001327567-25-000035:notes:117]
|  |  |  | Three Months Ended October 31, |
|  |  |  |  |  | 2025 |  | 2024 |
| Interest income |  |  |  |  | $ | 105 |  |  | $ | 86 |  |
| Foreign currency exchange gains (losses), net |  |  |  |  | (11) |  |  | (8) |  |
| Other, net |  |  |  |  | 9 |  |  | 5 |  |
| Total other income, net |  |  |  |  | $ | 103 |  |  | $ | 83 |  |


## us-gaap:SubsequentEventsTextBlock

[0001327567-25-000035:notes:118]
Subsequent Events
Share Repurchase

[0001327567-25-000035:notes:119]
On November 18, 2025, our board of directors authorized the extension of the expiration date of our current share repurchase authorization to December 31, 2026. Our repurchase program may be suspended or discontinued at any time without prior notice. Repurchases may be made at management’s discretion from time to time on the open market, through privately negotiated transactions, transactions structured through investment banking institutions, block purchase techniques, 10b5-1 trading plans, or a combination of the foregoing.

[0001327567-25-000035:notes:120]
Chronosphere, Inc.

[0001327567-25-000035:notes:121]
On November 19, 2025, we entered into a definitive agreement to acquire Chronosphere, Inc., a privately-held observability technology company (“Chronosphere”), in exchange for total consideration of $3.35 billion in cash and replacement awards, subject to adjustments. We expect the acquisition to be our entry into the observability space. The acquisition of Chronosphere is expected to close during the second half of our fiscal 2026, subject to the satisfaction of closing conditions, including regulatory clearance.


## ecd:MtrlTermsOfTrdArrTextBlock

[0001327567-25-000035:notes:122]
Set forth below is certain information regarding Rule 10b5-1 trading plans adopted or terminated by our directors and officers (as defined in Rule 16a-1(f)) during the first quarter of fiscal 2026. The Rule 10b5-1 trading plans listed below are each intended to satisfy the affirmative defense of Rule 10b5-1(c).

[0001327567-25-000035:notes:123]
| Name |  | Title |  | Date Plan Was Adopted |  | Date Plan Was Terminated |  | Expiration Date |  | Total Amount of Common Stock to Be Sold Under the Plan |
| William “BJ” Jenkins |  | President |  | September 26, 2025 |  | Not applicable |  | June 15, 2026 |  | 7,122 |

[0001327567-25-000035:notes:124]
No other officers or directors, as defined in Rule 16a-1(f), adopted, modified, and/or terminated a “Rule 10b5-1 trading arrangement” or a “non-Rule 10b5-1 trading arrangement,” as defined in Regulation S-K Item 408, during the first quarter of fiscal 2026.
