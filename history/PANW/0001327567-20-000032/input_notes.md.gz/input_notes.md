# PANW notes — 0001327567-20-000032


## dei:DocumentsIncorporatedByReferenceTextBlock

[0001327567-20-000032:notes:1]
Portions of the information called for by Part III of this Annual Report on Form 10-K is hereby incorporated by reference from the definitive proxy statement for the registrant’s 2020 annual meeting of stockholders, which will be filed with the Securities and Exchange Commission not later than 120 days after the registrant’s fiscal year ended July 31, 2020.


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock

[0001327567-20-000032:notes:2]
1. Description of Business and Summary of Significant Accounting Policies

[0001327567-20-000032:notes:3]
Description of Business

[0001327567-20-000032:notes:4]
Palo Alto Networks, Inc. (the “Company,” “we,” “us,” or “our”), located in Santa Clara, California, was incorporated in March 2005 under the laws of the State of Delaware and commenced operations in April 2005. We empower enterprises, service providers, and government entities to secure all users, applications, data, networks and devices with comprehensive context at all times, across all locations.

[0001327567-20-000032:notes:5]
Basis of Presentation

[0001327567-20-000032:notes:6]
The accompanying consolidated financial statements have been prepared in conformity with U.S. generally accepted accounting principles (“GAAP”). The consolidated financial statements include all adjustments necessary for a fair presentation of our annual results. All adjustments are of a normal recurring nature.

[0001327567-20-000032:notes:7]
Principles of Consolidation

[0001327567-20-000032:notes:8]
The consolidated financial statements include our accounts and our wholly owned subsidiaries. All significant intercompany balances and transactions have been eliminated in consolidation.

[0001327567-20-000032:notes:9]
Use of Estimates

[0001327567-20-000032:notes:10]
The preparation of consolidated financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the consolidated financial statements and the reported amounts of revenues and expenses during the reporting period. Such management estimates include, but are not limited to the standalone selling price for our products and services, share-based compensation, fair value of assets acquired and liabilities assumed in business combinations, identified intangibles and goodwill, valuation allowance against deferred tax assets, manufacturing partner and supplier liabilities, fair value of debt component of convertible notes, interest rate for operating lease liabilities, deferred contract cost benefit period, and loss contingencies. We base our estimates on historical experience and also on assumptions that we believe are reasonable. Actual results could differ materially from those estimates due to risks and uncertainties, including uncertainty in the current economic environment due to the global impact of COVID-19.

[0001327567-20-000032:notes:11]
Concentrations

[0001327567-20-000032:notes:12]
Financial instruments that subject us to concentrations of credit risk consist primarily of cash and cash equivalents, investments, accounts receivable, derivative contracts and financing receivable.

[0001327567-20-000032:notes:13]
We invest only in high-quality credit instruments and maintain our cash and cash equivalents and available-for-sale investments in fixed income securities. Management believes that the financial institutions that hold our investments are financially sound and, accordingly, are subject to minimal credit risk. Deposits held with banks may exceed the amount of insurance provided on such deposits.

[0001327567-20-000032:notes:14]
Our derivative contracts expose us to credit risk to the extent that the counterparties may be unable to meet the terms of the arrangement. We mitigate this credit risk by transacting with major financial institutions with high credit ratings and also enter into master netting arrangements, which permit net settlement of transactions with the same counterparty. We are not required to pledge, and are not entitled to receive, cash collateral related to these derivative instruments. We do not enter into derivative contracts for trading or speculative purposes.

[0001327567-20-000032:notes:15]
Our accounts receivables are primarily derived from our distributors in various geographical locations. We perform ongoing credit evaluations and generally do not require collateral on accounts receivable. As of July 31, 2020, one distributor accounted for over 10% of our gross accounts receivable representing 31.5%. For fiscal 2020, four distributors accounted for over 10% of our total revenue, representing 34.4%, 12.1%, 11.8%, and 10.5% each.

[0001327567-20-000032:notes:16]
We rely on an electronics manufacturing services provider (“EMS provider”) to assemble most of our products and sole source component suppliers for a certain number of our components.

[0001327567-20-000032:notes:17]
Comprehensive Loss

[0001327567-20-000032:notes:18]
Comprehensive loss is comprised of net loss and other comprehensive income (loss). Our other comprehensive income (loss) includes unrealized gains and losses on available-for-sale investments and unrealized gains and losses on cash flow hedges.

[0001327567-20-000032:notes:19]
Foreign Currency Transactions

[0001327567-20-000032:notes:20]
The functional currency of our foreign subsidiaries is the U.S. dollar. Monetary assets and liabilities denominated in foreign currencies have been remeasured into U.S. dollars using the exchange rates in effect at the balance sheet dates. Foreign currency denominated income and expenses have been remeasured using the average exchange rates in effect during each period. Foreign

[0001327567-20-000032:notes:21]
currency remeasurement gains and losses and foreign currency transaction gains and losses are not significant to the financial statements.

[0001327567-20-000032:notes:22]
Fair Value

[0001327567-20-000032:notes:23]
We define fair value as the price that would be received from selling an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date. When determining the fair value measurements for assets and liabilities which are required to be recorded at fair value, we consider the principal or most advantageous market in which to transact and the market-based risk. We apply fair value accounting for all financial assets and liabilities that are recognized or disclosed at fair value in the financial statements on a recurring basis. Goodwill, intangible assets, and other long-lived assets are measured at fair value on a nonrecurring basis, only if impairment is indicated. The carrying amounts reported in the consolidated financial statements approximate the fair value for cash and cash equivalents, accounts receivable, accounts payable, and accrued liabilities, due to their short-term nature.

[0001327567-20-000032:notes:24]
Cash, Cash Equivalents, and Investments

[0001327567-20-000032:notes:25]
We consider all highly liquid investments with original maturities of three months or less at date of purchase to be cash equivalents. Investments not considered cash equivalents and with maturities one year or less from the consolidated balance sheet date are classified as short-term investments. Investments with maturities greater than one year from the consolidated balance sheet date are classified as long-term investments.

[0001327567-20-000032:notes:26]
We classify our investments in marketable debt securities as available-for-sale at the time of purchase. These investments are considered impaired when a decline in fair value is judged to be other-than-temporary. We consult with our investment managers and consider available quantitative and qualitative evidence in evaluating potential impairment of our investments on a quarterly basis. If the cost of an individual investment exceeds its fair value, we evaluate, among other factors, general market conditions, the duration and extent to which the fair value is less than cost, and our intent and ability to hold the investment. Once a decline in fair value is determined to be other-than-temporary, an impairment charge is recorded and a new cost basis in the investment is established.

[0001327567-20-000032:notes:27]
Accounts Receivable

[0001327567-20-000032:notes:28]
Trade accounts receivable are recorded at the invoiced amount, net of allowances for doubtful accounts. The allowance for doubtful accounts is based on our assessment of the collectability of accounts. Management regularly reviews the adequacy of the allowance for doubtful accounts by considering the age of each outstanding invoice, each customer’s expected ability to pay, and the collection history with each customer, when applicable, to determine whether a specific allowance is appropriate. Accounts receivable deemed uncollectible are charged against the allowance for doubtful accounts when identified. As of July 31, 2020 and 2019, the allowance for doubtful accounts activity was not significant.

[0001327567-20-000032:notes:29]
Financing Receivables

[0001327567-20-000032:notes:30]
We provide financing arrangements, primarily loans, for certain qualified end-user customers to purchase our products. We determine the adequacy of our allowance for credit loss by assessing the risks and losses inherent in our financing receivables on either an individual or a collective basis. Our assessment considers various factors, including our historical experience, credit quality and age of the receivable balances, and economic conditions that may affect a customer’s ability to pay. Financing receivables are written off when they are considered uncollectible, and all outstanding balances will be reversed and charged against the allowance for credit loss. Short-term financing receivables are included in prepaid expenses and other current assets and long-term financing receivables are included in other assets on our consolidated balance sheets. As of July 31, 2020, financing receivables were not significant to our consolidated balance sheet. As of July 31, 2019, there were no financing receivables on our consolidated balance sheet.

[0001327567-20-000032:notes:31]
Derivatives

[0001327567-20-000032:notes:32]
As a global business, we are exposed to currency exchange rate risk. Substantially all of our revenue is transacted in U.S. dollars, however, a portion of our operating expenditures are incurred outside of the United States and are denominated in foreign currencies, making them subject to fluctuations in foreign currency exchange rates. We enter into foreign currency derivative contracts with maturities of 15 months or less, which we designate as cash flow hedges, to manage the foreign currency exchange rate risk associated with these expenditures.

[0001327567-20-000032:notes:33]
Our derivative financial instruments are recorded at fair value, on a gross basis, as either assets or liabilities in our consolidated balance sheets. Gains or losses related to our cash flow hedges are recorded as a component of accumulated other comprehensive income (loss) (“AOCI”) in our consolidated balance sheets and are reclassified into the financial statement line item associated with the underlying hedged transaction in our consolidated statements of operations when the underlying hedged transaction is recognized in earnings. If it becomes probable that the hedged transaction will not occur, the cumulative unrealized gain or loss is reclassified immediately from AOCI into the financial statement line item associated with the underlying hedged transaction in our consolidated statements of operations. Gains or losses related to non-designated derivative instruments are recognized in other income, net in our consolidated statements of operations for each period until the instrument matures, is terminated, is re-designated as a qualified cash

[0001327567-20-000032:notes:34]
flow hedge, or is sold. Derivatives designated as cash flow hedges are classified in our consolidated statements of cash flows in the same manner as the underlying hedged transaction, primarily within cash flows from operating activities.

[0001327567-20-000032:notes:35]
Property and Equipment

[0001327567-20-000032:notes:36]
Property and equipment are stated at cost, less accumulated depreciation. Depreciation is computed using the straight-line method over the estimated useful lives of the assets, generally three to ten years. Leasehold improvements are depreciated over the shorter of the estimated useful lives of the improvements or the remaining lease term. Land is not depreciated.

[0001327567-20-000032:notes:37]
Business Combinations

[0001327567-20-000032:notes:38]
We include the results of operations of the businesses that we acquire as of the respective dates of acquisition. We allocate the fair value of the purchase price of our acquisitions to the tangible assets acquired, liabilities assumed, and intangible assets acquired, based on their estimated fair values. The excess of the purchase price over the fair values of these identifiable assets and liabilities is recorded as goodwill. Additional information existing as of the acquisition date but unknown to us may become known during the remainder of the measurement period, not to exceed 12 months from the acquisition date, which may result in changes to the amounts and allocations recorded.

[0001327567-20-000032:notes:39]
Intangible Assets

[0001327567-20-000032:notes:40]
Purchased intangible assets with finite lives are carried at cost, less accumulated amortization. Amortization is computed over the estimated useful lives of the respective assets. Acquisition-related in-process research and development represents the fair value of incomplete research and development projects that have not reached technological feasibility as of the date of acquisition. Initially, these assets are not subject to amortization. Assets related to projects that have been completed are transferred to developed technology, which are subject to amortization.

[0001327567-20-000032:notes:41]
Impairment of Goodwill, Intangible Assets, and Other Long-Lived Assets

[0001327567-20-000032:notes:42]
Goodwill is evaluated for impairment on an annual basis in the fourth quarter of our fiscal year, and whenever events or changes in circumstances indicate the carrying amount of goodwill may not be recoverable. We have elected to first assess qualitative factors to determine whether it is more likely than not that the fair value of our single reporting unit is less than its carrying amount, including goodwill. If we determine that it is more likely than not that the fair value of our single reporting unit is less than its carrying amount, then the quantitative impairment test will be performed. Under the quantitative impairment test, if the carrying amount of our single reporting unit exceeds its fair value, we will recognize an impairment loss in an amount equal to that excess but limited to the total amount of goodwill.

[0001327567-20-000032:notes:43]
We evaluate events and changes in circumstances that could indicate carrying amounts of purchased intangible assets and other long-lived assets may not be recoverable. When such events or changes in circumstances occur, we assess the recoverability of these assets by determining whether or not the carrying amount will be recovered through undiscounted expected future cash flows. If the total of the future undiscounted cash flows is less than the carrying amount of an asset, we record an impairment loss for the amount by which the carrying amount of the asset exceeds the fair value of the asset.

[0001327567-20-000032:notes:44]
We did not recognize any impairment losses on our goodwill, intangible assets or other long-lived assets during the years ended July 31, 2020, 2019 and 2018.

[0001327567-20-000032:notes:45]
Manufacturing Partner and Supplier Liabilities

[0001327567-20-000032:notes:46]
We outsource most of our manufacturing, repair, and supply chain management operations to our EMS provider and payments to it are a significant portion of our cost of product revenue. Although we could be contractually obligated to purchase manufactured products and components, we generally do not own the manufactured products and components. Product title transfers from our EMS provider to us and immediately to our customers upon shipment. Our EMS provider assembles our products using design specifications, quality assurance programs, and standards that we establish, and it procures components and assembles our products based on our demand forecasts. These forecasts represent our estimates of future demand for our products based upon historical trends and analysis from our sales and product management functions as adjusted for overall market conditions. If the actual component usage and product demand are significantly lower than forecast, we record a liability for manufacturing purchase commitments in excess of our forecasted demand including costs for excess components or for carrying costs incurred by our manufacturing partners and component suppliers. Through July 31, 2020, we have not accrued any significant costs associated with this exposure.

[0001327567-20-000032:notes:47]
Convertible Senior Notes

[0001327567-20-000032:notes:48]
In accounting for the issuance of our convertible senior notes, we separate the notes into liability and equity components. The carrying amount of the liability component is calculated by measuring the fair value of a similar liability that does not have an associated convertible feature, using a discounted cash flow model with a risk adjusted yield. The carrying amount of the equity component representing the conversion option is determined by deducting the fair value of the liability component from the par value of the notes as a whole. This difference represents a debt discount that is amortized to interest expense using the effective interest method over the term of the notes. The equity component is not remeasured as long as it continues to meet the conditions for equity classification. In accounting for the transaction costs related to the issuance of the notes, we allocate the total amount incurred to the

[0001327567-20-000032:notes:49]
liability and equity components using the same proportions as the proceeds from the notes. Transaction costs attributable to the liability component are netted with the liability component and amortized to interest expense using the effective interest method over the term of the notes. Transaction costs attributable to the equity component are netted with the equity component of the notes in additional paid-in capital in the consolidated balance sheets. When the notes are convertible, the net carrying amount of the notes is classified as a current liability and a portion of the equity component representing the conversion option is reclassified to temporary equity in our consolidated balance sheets. The portion of the equity component classified as temporary equity is measured as the difference between the principal and net carrying amount of the notes, excluding debt issuance costs.

[0001327567-20-000032:notes:50]
Revenue Recognition

[0001327567-20-000032:notes:51]
Our revenue consists of product revenue and subscription and support revenue. Revenue is recognized when control of promised products, subscriptions and support services are transferred to customers, in an amount that reflects the expected consideration in exchange for those products and services.

[0001327567-20-000032:notes:52]
We determine revenue recognition through the following steps:

[0001327567-20-000032:notes:53]
•Identification of the contract, or contracts, with a customer.

[0001327567-20-000032:notes:54]
•Identification of the performance obligations in the contract.

[0001327567-20-000032:notes:55]
•Determination of the transaction price.

[0001327567-20-000032:notes:56]
•Allocation of the transaction price to the performance obligations in the contract.

[0001327567-20-000032:notes:57]
•Recognition of revenue when, or as, we satisfy a performance obligation.

[0001327567-20-000032:notes:58]
Revenues are reported net of sales taxes. Shipping charges billed to channel partners are included in revenues and related costs are included in cost of revenue.

[0001327567-20-000032:notes:59]
Product Revenue

[0001327567-20-000032:notes:60]
Product revenue is derived primarily from sales of our appliances. Product revenue also includes revenue derived from software licenses of Panorama and the VM-Series. Our appliances and software licenses include a broad set of built-in networking and security features and functionalities. We recognize product revenue at the time of hardware shipment or delivery of software license.

[0001327567-20-000032:notes:61]
Subscription and Support Revenue

[0001327567-20-000032:notes:62]
Subscription and support revenue is derived primarily from sales of our subscription and support offerings. We recognize subscription and support revenue over time as the services are performed. Our contractual subscription and support contracts are typically one to five years.

[0001327567-20-000032:notes:63]
Contracts with Multiple Performance Obligations

[0001327567-20-000032:notes:64]
The majority of our contracts with our customers include various combinations of our products and subscriptions and support. Our appliances and software licenses have significant standalone functionalities and capabilities. Accordingly, these appliances and software licenses are distinct from our subscriptions and support services as the customer can benefit from the product without these services and such services are separately identifiable within the contract. We account for multiple agreements with a single customer as a single contract if the contractual terms and/or substance of those agreements indicate that they may be so closely related that they are, in effect, parts of a single contract. The amount of consideration we expect to receive in exchange for delivering on the contract is allocated to each performance obligation based on its relative standalone selling price. If a contract contains a single performance obligation, no allocation is required.

[0001327567-20-000032:notes:65]
We establish standalone selling price using the prices charged for a deliverable when sold separately. If the standalone selling price is not observable through past transactions, we estimate the standalone selling price based on our pricing model and our go-to-market strategy, which include factors such as type of sales channel (reseller, distributor, or end-customer), the geographies in which our offerings were sold (domestic or international), and offering type (products, subscriptions, or support).

[0001327567-20-000032:notes:66]
Deferred Revenue

[0001327567-20-000032:notes:67]
We record deferred revenue when cash payments are received or due in advance of our performance. Our payment terms typically require payment within 30 to 45 days of the date we issue an invoice. The current portion of deferred revenue represents the amounts that are expected to be recognized as revenue within one year of the consolidated balance sheet date.

[0001327567-20-000032:notes:68]
Deferred Contract Costs

[0001327567-20-000032:notes:69]
We defer contract costs that are recoverable and incremental to obtaining customer sales contracts. Contract costs, which primarily consist of sales commissions, are amortized on a systematic basis that is consistent with the transfer to the customer of the goods or services to which the asset relates. Sales commissions paid for initial contracts are generally not commensurate with the commissions paid for renewal contracts, given the substantive difference in commission rates in proportion to their respective contract values. Sales commissions for initial contracts that are not commensurate are amortized over a benefit period of five years, consistent

[0001327567-20-000032:notes:70]
with the revenue recognition pattern of the performance obligations in the related contracts including expected renewals. The benefit period is determined by taking into consideration contract length, technology life, and other quantitative and qualitative factors. The expected renewals are estimated based on historical renewal trends. Sales commissions for initial contracts that are commensurate and sales commissions for renewal contracts are amortized over the related contractual period in proportion to the revenue recognized.

[0001327567-20-000032:notes:71]
We classify deferred contract costs as short-term or long-term based on when we expect to recognize the expense. Short-term deferred contract costs are included in prepaid expenses and other current assets and long-term deferred contract costs are included in other assets on our consolidated balance sheets. Deferred contract costs are periodically reviewed for impairment. The amortization of deferred contract costs is included in sales and marketing expense in our consolidated statements of operations.

[0001327567-20-000032:notes:72]
Software Development Costs

[0001327567-20-000032:notes:73]
Internally developed software includes security software developed to meet our internal needs to provide cloud-based subscription offerings to our end-customers and business software that we customize to meet our specific operational needs. These capitalized costs consist of internal compensation related costs and external direct costs incurred during the application development stage and will be amortized over a useful life of three to five years. As of July 31, 2020 and 2019, we capitalized as other assets on our consolidated balance sheets $90.1 million and $44.9 million in costs, respectively, net of accumulated amortization, for security software developed to meet our internal needs to provide our cloud-based subscription offerings. We recognized amortization expense of $31.3 million, $12.9 million, and $4.3 million related to these capitalized costs as cost of subscription and support revenue in our consolidated statements of operations during the years ended July 31, 2020, 2019, and 2018, respectively.

[0001327567-20-000032:notes:74]
The costs to develop software that is marketed externally have not been capitalized as we believe our current software development process is essentially completed concurrent with the establishment of technological feasibility. As such, all related software development costs are expensed as incurred and included in research and development expense in our consolidated statements of operations.

[0001327567-20-000032:notes:75]
Share-Based Compensation

[0001327567-20-000032:notes:76]
Compensation expense related to share-based transactions, including employee and non-employee director awards, is measured and recognized in the financial statements based on fair value on the grant date. We recognize share-based compensation expense for awards with only service conditions on a straight-line basis over the requisite service period of the related award. We recognize share-based compensation expense for awards with market conditions and awards with performance conditions on a straight-line basis over the requisite service period for each separately vesting portion of the award and, for awards with performance conditions, when it is probable that the performance condition will be achieved. We account for forfeitures of all share-based payment awards when they occur.

[0001327567-20-000032:notes:77]
Leases

[0001327567-20-000032:notes:78]
We determine if an arrangement is a lease at inception. We evaluate the classification of leases at commencement and, as necessary, at modification. Operating leases are included in operating lease right-of-use assets, accrued and other liabilities, and long-term operating lease liabilities on our consolidated balance sheets beginning August 1, 2019. We did not have any material finance leases in any of the periods presented.

[0001327567-20-000032:notes:79]
Operating lease right-of-use assets represent our right to use an underlying asset for the lease term. Operating lease liabilities represent our obligation to make payments arising from the lease. Operating lease right-of-use assets and liabilities are recognized at the present value of the future lease payments at the lease commencement date. The interest rate used to determine the present value of the future lease payments is our incremental borrowing rate, because the interest rates implicit in most of our leases are not readily determinable. Our incremental borrowing rate is estimated to approximate the interest rate on a collateralized basis with similar terms and payments, and in economic environments where the leased asset is located. Operating lease right-of-use assets also include adjustments related to lease incentives, prepaid or accrued rent and initial direct lease costs. Operating lease right-of-use assets are subject to evaluation for impairment or disposal on a basis consistent with other long-lived assets.

[0001327567-20-000032:notes:80]
Our lease terms may include periods under options to extend or terminate the lease when it is reasonably certain that we will exercise that option. We generally use the base, non-cancelable lease term when determining the lease assets and liabilities. Operating lease cost is recognized on a straight-line basis over the lease term.

[0001327567-20-000032:notes:81]
We account for lease and non-lease components as a single lease component and do not recognize right-of-use assets and lease liabilities for leases with a term of 12 months or less. Payments under our lease arrangements are primarily fixed, however, certain lease agreements contain variable payments, which are expensed as incurred and not included in the operating lease right-of-use assets and liabilities. Variable lease payments are primarily comprised of real estate taxes, common area maintenance, and insurance.

[0001327567-20-000032:notes:82]
Income Taxes

[0001327567-20-000032:notes:83]
We account for income taxes using the asset and liability method, which requires the recognition of deferred tax assets and liabilities for the expected future tax consequences of events that have been recognized in our financial statements or tax returns. In

[0001327567-20-000032:notes:84]
addition, deferred tax assets are recorded for the future benefit of utilizing net operating losses and research and development credit carryforwards. Valuation allowances are provided when necessary to reduce deferred tax assets to the amount expected to be realized.

[0001327567-20-000032:notes:85]
Significant judgment is required in determining any valuation allowance recorded against deferred tax assets. In assessing the need for a valuation allowance, we consider all available evidence, including past operating results, estimates of future taxable income, and the feasibility of tax planning strategies. In the event that we change our determination as to the amount of deferred tax assets that can be realized, we will adjust our valuation allowance with a corresponding impact to the provision for income taxes in the period in which such determination is made.

[0001327567-20-000032:notes:86]
We apply the authoritative accounting guidance prescribing a threshold and measurement attribute for the financial recognition and measurement of a tax position taken or expected to be taken in a tax return. We recognize liabilities for uncertain tax positions based on a two-step process. The first step is to evaluate the tax position for recognition by determining if the weight of available evidence indicates that it is more likely than not that the position will be sustained on audit, including resolution of related appeals or litigation processes, if any. The second step requires us to estimate and measure the tax benefit as the largest amount that is more likely than not to be realized upon ultimate settlement.

[0001327567-20-000032:notes:87]
Loss Contingencies

[0001327567-20-000032:notes:88]
We are subject to the possibility of various loss contingencies arising in the ordinary course of business. In determining loss contingencies, we consider the likelihood of loss or impairment of an asset, or the incurrence of a liability, as well as our ability to reasonably estimate the amount of loss. An estimated loss contingency is accrued when it is probable that an asset has been impaired, or a liability has been incurred and the amount of loss can be reasonably estimated. If we determine that a loss is possible and the range of the loss can be reasonably determined, then we disclose the range of the possible loss. We regularly evaluate current information available to us to determine whether an accrual is required, an accrual should be adjusted, or a range of possible loss should be disclosed.

[0001327567-20-000032:notes:89]
Recently Adopted Accounting Pronouncements

[0001327567-20-000032:notes:90]
In February 2016, the Financial Accounting Standards Board (“FASB”) issued new authoritative guidance on lease accounting. Among its provisions, the standard requires lessees to recognize right-of-use assets and lease liabilities on the balance sheet for operating leases and also requires additional qualitative and quantitative disclosures about lease arrangements.

[0001327567-20-000032:notes:91]
We adopted this standard effective August 1, 2019 on a modified retrospective basis, under which financial results reported in periods prior to fiscal 2020 were not adjusted. We elected the package of practical expedients, which allowed us to carry forward our historical assessments of whether contracts are or contain leases, lease classification, and initial direct costs. Additionally, we elected to account for lease and non-lease components as a single lease component and to not recognize right-of-use assets and lease liabilities for leases with a term of 12 months or less.

[0001327567-20-000032:notes:92]
The most significant impact of adopting this guidance was the recognition of $286.4 million of operating lease right-of-use assets and $442.4 million of operating lease liabilities on our consolidated balance sheet as of August 1, 2019, which included reclassifying previously recognized $129.0 million in lease incentives, deferred or prepaid rent, as well as $27.0 million in cease-use liabilities to operating lease right-of-use assets.

[0001327567-20-000032:notes:93]
The adoption of this standard had no impact on our consolidated statements of operations and consolidated statements of cash flows. Refer to Note 11. Leases for further discussion.

[0001327567-20-000032:notes:94]
Recently Issued Accounting Pronouncements

[0001327567-20-000032:notes:95]
Debt with Conversion Options

[0001327567-20-000032:notes:96]
In August 2020, the FASB issued new authoritative guidance to simplify the accounting for certain financial instruments with characteristics of liabilities and equity, including convertible instruments and contracts on an entity’s own equity. The standard eliminates beneficial conversion feature and cash conversion models resulting in more convertible instruments being accounted for as a single unit; and simplifies classification of debt on the balance sheet and earnings per share calculation. The standard is effective for us in our first quarter of fiscal 2023 and will be applied on a modified retrospective basis. Early adoption is permitted from our first quarter of fiscal 2022. We are currently evaluating whether this standard will have a material impact on our consolidated financial statements.

[0001327567-20-000032:notes:97]
Financial Instruments - Credit Losses

[0001327567-20-000032:notes:98]
In June 2016, the FASB issued new authoritative guidance on the accounting for credit losses on most financial assets and certain financial instruments. The standard replaces the existing incurred loss model with an expected credit loss model for financial assets measured at amortized cost, including trade receivables and financing receivables, and requires that credit losses on available-for-sale debt securities be presented as an allowance rather than as a write-down. The standard is effective for us in our first quarter of 
fiscal 2021 and will be applied on a modified retrospective basis. We do not expect the adoption of the standard will have a material impact on our consolidated financial statements.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001327567-20-000032:notes:99]
Disaggregation of Revenue

[0001327567-20-000032:notes:100]
The following table presents revenue by geographic theater (in millions):

[0001327567-20-000032:notes:101]
|  | Year Ended July 31, |  |  |  |  |
|  | 2020 |  | 2019 |  | 2018 |
| Revenue: |  |  |  |  |  |
| Americas |  |  |  |  |  |
| United States | $ | 2,168.6 |  |  | $ | 1,830.3 |  |  | $ | 1,446.7 |  |
| Other Americas | 159.3 |  |  | 152.0 |  |  | 112.0 |  |
| Total Americas | 2,327.9 |  |  | 1,982.3 |  |  | 1,558.7 |  |
| Europe, the Middle East, and Africa (“EMEA”) | 664.8 |  |  | 564.8 |  |  | 439.6 |  |
| Asia Pacific and Japan (“APAC”) | 415.7 |  |  | 352.5 |  |  | 275.3 |  |
| Total revenue | $ | 3,408.4 |  |  | $ | 2,899.6 |  |  | $ | 2,273.6 |  |

[0001327567-20-000032:notes:102]
The following table presents revenue for groups of similar products and services (in millions):

[0001327567-20-000032:notes:103]
|  | Year Ended July 31, |  |  |  |  |
|  | 2020 |  | 2019 |  | 2018 |
| Revenue: |  |  |  |  |  |
| Product | $ | 1,064.2 |  |  | $ | 1,096.2 |  |  | $ | 879.8 |  |
| Subscription and support |  |  |  |  |  |
| Subscription | 1,405.3 |  |  | 1,032.7 |  |  | 758.1 |
| Support | 938.9 |  |  | 770.7 |  |  | 635.7 |
| Total subscription and support | 2,344.2 |  |  | 1,803.4 |  |  | 1,393.8 |  |
| Total revenue | $ | 3,408.4 |  |  | $ | 2,899.6 |  |  | $ | 2,273.6 |  |

[0001327567-20-000032:notes:104]
During the year ended July 31, 2020, we recognized approximately $1.5 billion of revenue pertaining to amounts that were deferred as of July 31, 2019.

[0001327567-20-000032:notes:105]
Remaining Performance Obligations

[0001327567-20-000032:notes:106]
Revenue expected to be recognized from remaining performance obligations was $4.3 billion as of July 31, 2020, of which we expect to recognize approximately $2.2 billion over the next 12 months and the remainder thereafter.
Deferred Contract Costs
The following table presents details of our short-term and long-term deferred contract costs as of July 31, 2020 and July 31, 2019 (in millions):

[0001327567-20-000032:notes:107]
|  | July 31, |  |  |
|  | 2020 |  | 2019 |
| Short-term deferred contract costs | $ | 206.0 |  |  | $ | 151.1 |  |
| Long-term deferred contract costs | 422.3 |  |  | 324.2 |  |
| Total deferred contract costs | $ | 628.3 |  |  | $ | 475.3 |  |

[0001327567-20-000032:notes:108]
We recognized amortization expense for our deferred contract costs of $254.4 million, $223.8 million, and $149.8 million during the years ended July 31, 2020, 2019, and 2018, respectively. We did not recognize any impairment losses on our deferred contract costs during the years ended July 31, 2020, 2019, or 2018.


## us-gaap:FairValueMeasurementPolicyPolicyTextBlock

[0001327567-20-000032:notes:109]
We categorize assets and liabilities recorded or disclosed at fair value on our consolidated balance sheets based upon the level of judgment associated with inputs used to measure their fair value. The categories are as follows:

[0001327567-20-000032:notes:110]
•Level 1—Inputs are unadjusted quoted prices in active markets for identical assets or liabilities.

[0001327567-20-000032:notes:111]
•Level 2—Inputs are quoted prices for similar assets and liabilities in active markets or inputs that are observable for the assets or liabilities, either directly or indirectly through market corroboration, for substantially the full term of the financial instruments.

[0001327567-20-000032:notes:112]
•Level 3—Inputs are unobservable inputs based on our own assumptions used to measure assets and liabilities at fair value. The inputs require significant management judgment or estimation.


## us-gaap:FairValueDisclosuresTextBlock

[0001327567-20-000032:notes:113]
The following table presents the fair value of our financial assets and liabilities measured at fair value on a recurring basis using the above input categories as of July 31, 2020 and July 31, 2019 (in millions):

[0001327567-20-000032:notes:114]
|  |  | July 31, 2020 |  |  |  |  |  |  |  | July 31, 2019 |  |  |  |  |  |  |
|  |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Cash equivalents: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 1,589.5 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,589.5 |  |  | $ | 369.1 |  |  | $ | — |  |  | $ | — |  |  | $ | 369.1 |  |
| Certificates of deposit |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 12.0 |  |  | — |  |  | 12.0 |  |
| Commercial paper |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 19.3 |  |  | — |  |  | 19.3 |  |
| U.S. government and agency securities |  | — |  |  | 342.0 |  |  | — |  |  | 342.0 |  |  | — |  |  | 54.4 |  |  | — |  |  | 54.4 |  |
| Total cash equivalents |  | 1,589.5 |  |  | 342.0 |  |  | — |  |  | 1,931.5 |  |  | 369.1 |  |  | 85.7 |  |  | — |  |  | 454.8 |  |
| Short-term investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Certificates of deposit |  | — |  |  | 26.9 |  |  | — |  |  | 26.9 |  |  | — |  |  | 17.5 |  |  | — |  |  | 17.5 |  |
| Commercial paper |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 8.9 |  |  | — |  |  | 8.9 |  |
| Corporate debt securities |  | — |  |  | 100.2 |  |  | — |  |  | 100.2 |  |  | — |  |  | 375.5 |  |  | — |  |  | 375.5 |  |
| U.S. government and agency securities |  | — |  |  | 645.6 |  |  | — |  |  | 645.6 |  |  | — |  |  | 1,439.8 |  |  | — |  |  | 1,439.8 |  |
| Non-U.S. government and agency securities |  | — |  |  | 17.1 |  |  | — |  |  | 17.1 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Total short-term investments |  | — |  |  | 789.8 |  |  | — |  |  | 789.8 |  |  | — |  |  | 1,841.7 |  |  | — |  |  | 1,841.7 |  |
| Long-term investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate debt securities |  | — |  |  | 91.7 |  |  | — |  |  | 91.7 |  |  | — |  |  | 214.3 |  |  | — |  |  | 214.3 |  |
| Certificates of deposit |  | — |  |  | 5.0 |  |  | — |  |  | 5.0 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| U.S. government and agency securities |  | — |  |  | 447.4 |  |  | — |  |  | 447.4 |  |  | — |  |  | 361.1 |  |  | — |  |  | 361.1 |  |
| Non-U.S. government and agency securities |  | — |  |  | 10.3 |  |  | — |  |  | 10.3 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Total long-term investments |  | — |  |  | 554.4 |  |  | — |  |  | 554.4 |  |  | — |  |  | 575.4 |  |  | — |  |  | 575.4 |  |
| Prepaid expenses and other current assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency forward contracts |  | — |  |  | 13.6 |  |  | — |  |  | 13.6 |  |  | — |  |  | 1.3 |  |  | — |  |  | 1.3 |  |
| Total prepaid expenses and other current assets |  | — |  |  | 13.6 |  |  | — |  |  | 13.6 |  |  | — |  |  | 1.3 |  |  | — |  |  | 1.3 |  |
| Other assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency forward contracts |  | — |  |  | 1.4 |  |  | — |  |  | 1.4 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Total other assets |  | — |  |  | 1.4 |  |  | — |  |  | 1.4 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Total assets measured at fair value |  | $ | 1,589.5 |  |  | $ | 1,701.2 |  |  | $ | — |  |  | $ | 3,290.7 |  |  | $ | 369.1 |  |  | $ | 2,504.1 |  |  | $ | — |  |  | $ | 2,873.2 |  |
| Accrued and other liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency forward contracts |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 3.8 |  |  | $ | — |  |  | $ | 3.8 |  |
| Total accrued and other liabilities |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 3.8 |  |  | — |  |  | 3.8 |  |
| Total liabilities measured at fair value |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 3.8 |  |  | $ | — |  |  | $ | 3.8 |  |

[0001327567-20-000032:notes:115]
Refer to Note 10. Debt, for the carrying amount and estimated fair value of our convertible senior notes as of July 31, 2020 and July 31, 2019.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001327567-20-000032:notes:116]
Cash Equivalents and Investments
Available-for-sale Debt Securities

[0001327567-20-000032:notes:117]
The following tables summarize the amortized cost, unrealized gains and losses, and fair value of our available-for-sale debt securities as of July 31, 2020 and July 31, 2019 (in millions):

[0001327567-20-000032:notes:118]
|  | July 31, 2020 |  |  |  |  |  |  |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| U.S. government and agency securities | $ | 342.0 |  |  | $ | — |  |  | $ | — |  |  | $ | 342.0 |  |
| Total available-for-sale cash equivalents | $ | 342.0 |  |  | $ | — |  |  | $ | — |  |  | $ | 342.0 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 31.9 |  |  | $ | — |  |  | $ | — |  |  | $ | 31.9 |  |
| Corporate debt securities | 190.1 |  |  | 1.8 |  |  | — |  |  | 191.9 |  |
| U.S. government and agency securities | 1,090.3 |  |  | 2.8 |  |  | (0.1) |  |  | 1,093.0 |  |
| Non-U.S. government and agency securities | 27.4 |  |  | — |  |  | — |  |  | 27.4 |  |
| Total available-for-sale investments | $ | 1,339.7 |  |  | $ | 4.6 |  |  | $ | (0.1) |  |  | $ | 1,344.2 |  |

[0001327567-20-000032:notes:119]
|  | July 31, 2019 |  |  |  |  |  |  |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 12.0 |  |  | $ | — |  |  | $ | — |  |  | $ | 12.0 |  |
| Commercial paper | 19.3 |  |  | — |  |  | — |  |  | 19.3 |  |
| U.S. government and agency securities | 54.4 |  |  | — |  |  | — |  |  | 54.4 |  |
| Total available-for-sale cash equivalents | $ | 85.7 |  |  | $ | — |  |  | $ | — |  |  | $ | 85.7 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 17.5 |  |  | $ | — |  |  | $ | — |  |  | $ | 17.5 |  |
| Commercial paper | 8.9 |  |  | — |  |  | — |  |  | 8.9 |  |
| Corporate debt securities | 587.8 |  |  | 2.3 |  |  | (0.3) |  |  | 589.8 |  |
| U.S. government and agency securities | 1,799.5 |  |  | 2.6 |  |  | (1.2) |  |  | 1,800.9 |  |
| Total available-for-sale investments | $ | 2,413.7 |  |  | $ | 4.9 |  |  | $ | (1.5) |  |  | $ | 2,417.1 |  |

[0001327567-20-000032:notes:120]
We do not intend to sell any of the securities in an unrealized loss position and it is not likely that we would be required to sell these securities before recovery of their amortized cost basis, which may be at maturity. As a result, there were no other-than-temporary impairments for these securities at July 31, 2020 and 2019.

[0001327567-20-000032:notes:121]
The following table summarizes the amortized cost and fair value of our available-for-sale debt securities as of July 31, 2020, by contractual years-to-maturity (in millions):

[0001327567-20-000032:notes:122]
|  | Amortized Cost |  | Fair Value |
| Due within one year | $ | 1,129.9 |  |  | $ | 1,131.8 |  |
| Due between one and three years | 551.8 |  |  | 554.4 |  |
| Total | $ | 1,681.7 |  |  | $ | 1,686.2 |  |

[0001327567-20-000032:notes:123]
Marketable Equity Securities

[0001327567-20-000032:notes:124]
Marketable equity securities consist of money market funds and are included in cash and cash equivalents in our consolidated balance sheets. As of July 31, 2020 and 2019, the carrying value of our marketable equity securities were $1.6 billion and $369.1 million, respectively. There were no unrealized gains or losses recognized for these securities during the years ended July 31, 2020, 2019, and 2018.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001327567-20-000032:notes:125]
As of July 31, 2020 and 2019, the total notional amount of our outstanding foreign currency forward contracts was $443.6 million and $307.2 million, respectively. Refer to Note 3. Fair Value Measurements for the fair value of our derivative instruments as reported on our consolidated balance sheets as of July 31, 2020.

[0001327567-20-000032:notes:126]
During the years ended July 31, 2020, 2019, and 2018, both unrealized gains and losses recognized in AOCI related to our cash flow hedges and amounts reclassified into earnings were not material. Unrealized gains and losses in AOCI related to our cash flow hedges as of July 31, 2020 and 2019 were not material.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001327567-20-000032:notes:127]
Fiscal 2020

[0001327567-20-000032:notes:128]
CloudGenix Inc.

[0001327567-20-000032:notes:129]
On April 21, 2020, we completed our acquisition of CloudGenix Inc. (“CloudGenix”), a privately-held company. We believe the acquisition will strengthen our secure access service edge (“SASE”) offering. The total purchase consideration for the acquisition of CloudGenix was $402.7 million, which consisted of the following (in millions):

[0001327567-20-000032:notes:130]
|  | Amount |
| Cash | $ | 396.1 |  |
| Fair value of replacement awards | 6.6 |  |
| Total | $ | 402.7 |  |

[0001327567-20-000032:notes:131]
As part of the acquisition, we issued $30.3 million of replacement awards, of which the portion attributable to services performed prior to the acquisition date was allocated to purchase consideration. The remaining fair value was allocated to future services and will be expensed over the remaining service periods as share-based compensation.

[0001327567-20-000032:notes:132]
We have accounted for this transaction as a business combination and allocated the purchase consideration to assets acquired and liabilities assumed based on preliminary estimated fair values, as presented in the following table (in millions):

[0001327567-20-000032:notes:133]
|  | Amount |
| Goodwill | $ | 301.2 |  |
| Identified intangible assets | 109.9 |  |
| Cash | 8.3 |  |
| Net liabilities assumed | (16.7) |  |
| Total | $ | 402.7 |  |

[0001327567-20-000032:notes:134]
Goodwill generated from this business combination is primarily attributable to the assembled workforce and expected post-acquisition synergies from integrating CloudGenix technology into our portfolio. The goodwill is not deductible for income tax purposes.

[0001327567-20-000032:notes:135]
The following table presents details of the identified intangible assets acquired (in millions, except years):

[0001327567-20-000032:notes:136]
|  | Fair Value |  | Estimated Useful Life |
| Developed technology | $ | 67.2 |  |  | 5 years |
| Customer relationships | 42.7 |  |  | 10 years |
| Total | $ | 109.9 |  |  |  |

[0001327567-20-000032:notes:137]
Aporeto, Inc.

[0001327567-20-000032:notes:138]
On December 23, 2019, we completed our acquisition of Aporeto, Inc. (“Aporeto”), a privately-held machine identity-based microsegmentation company. We believe the acquisition will strengthen our cloud-native security platform capabilities delivered by Prisma Cloud. The total purchase consideration for the acquisition of Aporeto was $144.1 million, which consisted of the following (in millions):

[0001327567-20-000032:notes:139]
|  | Amount |
| Cash | $ | 139.8 |  |
| Fair value of replacement awards | 4.3 |  |
| Total | $ | 144.1 |  |

[0001327567-20-000032:notes:140]
As part of the acquisition, we issued $16.4 million of replacement awards, of which the portion attributable to services performed prior to the acquisition date was allocated to purchase consideration. The remaining fair value was allocated to future services and will be expensed over the remaining service periods as share-based compensation.

[0001327567-20-000032:notes:141]
|  | Amount |
| Goodwill | $ | 111.3 |  |
| Identified intangible assets | 23.8 |  |
| Cash | 10.5 |  |
| Net liabilities assumed | (1.5) |  |
| Total | $ | 144.1 |  |

[0001327567-20-000032:notes:142]
Goodwill generated from this business combination is primarily attributable to the assembled workforce and expected post-acquisition synergies from integrating Aporeto’s technology into our platform. The goodwill is not deductible for income tax purposes.

[0001327567-20-000032:notes:143]
|  | Fair Value |  | Estimated Useful Life |
| Developed technology | $ | 20.5 |  |  | 7 years |
| Customer relationships | 3.3 |  |  | 4 years |
| Total | $ | 23.8 |  |  |  |

[0001327567-20-000032:notes:144]
Zingbox, Inc.

[0001327567-20-000032:notes:145]
On September 20, 2019, we completed our acquisition of Zingbox, Inc. (“Zingbox”), a privately-held Internet of Things (“IoT”) security company. We believe the acquisition will accelerate our delivery of IoT security through our ML-powered Next-Generation Firewall and Cortex offerings. The total purchase consideration for the acquisition of Zingbox was $66.4 million in cash.

[0001327567-20-000032:notes:146]
As part of the acquisition, we issued replacement equity awards with a total fair value of $5.7 million, which will be expensed over the remaining service periods as share-based compensation.

[0001327567-20-000032:notes:147]
|  | Amount |
| Goodwill | $ | 48.1 |  |
| Identified intangible assets | 20.4 |  |
| Net liabilities assumed | (2.1) |  |
| Total | $ | 66.4 |  |

[0001327567-20-000032:notes:148]
Goodwill generated from this business combination is primarily attributable to the assembled workforce and expected post-acquisition synergies from integrating Zingbox’s technology into our portfolio. The goodwill is not deductible for income tax purposes.

[0001327567-20-000032:notes:149]
|  | Fair Value |  | Estimated Useful Life |
| Developed technology | $ | 18.6 |  |  | 5 years |
| Customer relationships | 1.8 |  |  | 8 years |
| Total | $ | 20.4 |  |  |  |

[0001327567-20-000032:notes:150]
Fiscal 2019

[0001327567-20-000032:notes:151]
Twistlock Ltd.

[0001327567-20-000032:notes:152]
On July 9, 2019, we completed our acquisition of Twistlock Ltd. (“Twistlock”), a privately-held company specializing in container security. The acquisition extends our cloud security strategy with the addition of Twistlock to our Prisma cloud security

[0001327567-20-000032:notes:153]
offerings. The total purchase consideration for the acquisition of Twistlock was $378.1 million, which consisted of the following (in millions):

[0001327567-20-000032:notes:154]
|  | Amount |
| Cash | $ | 375.4 |  |
| Fair value of replacement equity awards | 2.7 |  |
| Total purchase consideration | $ | 378.1 |  |

[0001327567-20-000032:notes:155]
As part of the acquisition, we issued replacement equity awards, which included 0.1 million shares of our restricted common stock. The total fair value of the replacement equity awards was $51.8 million, of which the portion attributable to services performed prior to the acquisition date was allocated to the purchase consideration. The remaining fair value was allocated to future services and will be expensed over the remaining service periods as share-based compensation.

[0001327567-20-000032:notes:156]
|  | Amount |
| Goodwill | $ | 300.6 |  |
| Identified intangible assets | 54.1 |  |
| Cash and cash equivalents | 14.0 |  |
| Net assets acquired | 9.4 |  |
| Total | $ | 378.1 |  |

[0001327567-20-000032:notes:157]
Goodwill generated from this business combination is primarily attributable to the assembled workforce and expected post-acquisition synergies from integrating Twistlock’s product into our platform. The goodwill is deductible for U.S. income tax purposes.

[0001327567-20-000032:notes:158]
|  | Fair Value |  | Estimated Useful Life |
| Developed technology | $ | 51.5 |  |  | 7 years |
| Customer relationships | 2.6 |  |  | 8 years |
| Total | $ | 54.1 |  |  |  |

[0001327567-20-000032:notes:159]
PureSec Ltd.

[0001327567-20-000032:notes:160]
On June 12, 2019, we completed our acquisition of PureSec Ltd. (“PureSec”), a privately-held company specializing in cybersecurity solutions for serverless architectures. The acquisition extends our cloud security strategy with the addition of PureSec to our Prisma cloud security offerings. The total purchase consideration for the acquisition of PureSec was $36.8 million, which consisted of the following (in millions):

[0001327567-20-000032:notes:161]
|  | Amount |
| Cash | $ | 35.9 |  |
| Fair value of replacement equity awards | 0.9 |  |
| Total purchase consideration | $ | 36.8 |  |

[0001327567-20-000032:notes:162]
As part of the acquisition, we issued replacement equity awards. The total fair value of the replacement equity awards was $9.1 million, of which the portion attributable to services performed prior to the acquisition date was allocated to the purchase consideration. The remaining fair value was allocated to future services and will be expensed over the remaining service periods as share-based compensation.

[0001327567-20-000032:notes:163]
|  | Amount |
| Goodwill | $ | 24.4 |  |
| Identified intangible assets | 7.4 |  |
| Cash | 4.0 |  |
| Net assets acquired | 1.0 |  |
| Total | $ | 36.8 |  |

[0001327567-20-000032:notes:164]
Goodwill generated from this business combination is primarily attributable to the assembled workforce and expected post-acquisition synergies from integrating PureSec’s product into our platform. The goodwill is deductible for U.S. income tax purposes.

[0001327567-20-000032:notes:165]
|  | Fair Value |  | Estimated Useful Life |
| Developed technology | $ | 7.4 |  |  | 5 years |
| Total | $ | 7.4 |  |  |  |

[0001327567-20-000032:notes:166]
Demisto, Inc.

[0001327567-20-000032:notes:167]
On March 28, 2019, we completed our acquisition of Demisto, Inc. (“Demisto”), a privately-held security company specializing in security orchestration, automation and response (“SOAR”). The acquisition expands the functionality of our portfolio with the addition of Demisto’s SOAR product. The total purchase consideration for the acquisition of Demisto was $474.2 million, which consisted of the following (in millions):

[0001327567-20-000032:notes:168]
|  | Amount |
| Cash | $ | 250.0 |  |
| Common stock (0.9 million shares) | 214.7 |  |
| Fair value of replacement equity awards | 9.5 |  |
| Total purchase consideration | $ | 474.2 |  |

[0001327567-20-000032:notes:169]
As part of the acquisition, we issued replacement equity awards, which included 0.3 million shares of our restricted common stock. The total fair value of the replacement equity awards was $105.2 million, of which the portion attributable to services performed prior to the acquisition date was allocated to the purchase consideration. The remaining fair value was allocated to future services and will be expensed over the remaining service periods as share-based compensation.

[0001327567-20-000032:notes:170]
|  | Amount |
| Goodwill | $ | 387.8 |  |
| Identified intangible assets | 76.3 |  |
| Cash | 25.9 |  |
| Net liabilities assumed | (15.8) |  |
| Total | $ | 474.2 |  |

[0001327567-20-000032:notes:171]
Goodwill generated from this business combination is primarily attributable to the assembled workforce and expected post-acquisition synergies from integrating Demisto’s product into our portfolio. The goodwill is not deductible for income tax purposes.

[0001327567-20-000032:notes:172]
|  | Fair Value |  | Estimated Useful Life |
| Developed technology | $ | 56.6 |  |  | 6 years |
| Customer relationships | 19.7 |  |  | 6 years |
| Total | $ | 76.3 |  |  |  |

[0001327567-20-000032:notes:173]
RedLock Inc.

[0001327567-20-000032:notes:174]
On October 12, 2018, we completed our acquisition of RedLock Inc. (“RedLock”), a privately-held cloud security company. The acquisition expands our security capabilities for the public cloud with the addition of RedLock’s cloud security analytics technology. The total purchase consideration for the acquisition of RedLock was $158.2 million, which consisted of $155.0 million in cash paid upon closing and $3.2 million in fair value of unvested equity awards attributable to services performed prior to the acquisition date.

[0001327567-20-000032:notes:175]
As part of the acquisition, we assumed RedLock equity awards with a total fair value of $57.4 million. Of the total fair value, a portion was allocated to the purchase consideration and the remainder was allocated to future services and will be expensed over the remaining service periods as share-based compensation.

[0001327567-20-000032:notes:176]
|  | Amount |
| Goodwill | $ | 113.6 |  |
| Identified intangible assets | 54.8 |  |
| Net liabilities assumed | (10.2) |  |
| Total | $ | 158.2 |  |

[0001327567-20-000032:notes:177]
Goodwill generated from this business combination is primarily attributable to the assembled workforce and expected post-acquisition synergies from integrating RedLock’s technology into our platform. The goodwill is not deductible for income tax purposes.

[0001327567-20-000032:notes:178]
|  | Fair Value |  | Estimated Useful Life |
| Developed technology | $ | 48.6 |  |  | 4 years |
| Customer relationships | 5.3 |  |  | 8 years |
| Trade name and trademarks | 0.9 |  |  | 6 months |
| Total | $ | 54.8 |  |  |  |

[0001327567-20-000032:notes:179]
Fiscal 2018

[0001327567-20-000032:notes:180]
Cyber Secdo Ltd.

[0001327567-20-000032:notes:181]
On April 24, 2018, we completed our acquisition of Cyber Secdo Ltd. (“Secdo”), a privately-held company specializing in endpoint detection and response (“EDR”). The acquisition expands the functionality of our portfolio by adding EDR capabilities. The total purchase consideration for the acquisition of Secdo was $82.7 million in cash.

[0001327567-20-000032:notes:182]
We have accounted for this transaction as a business combination and allocated the purchase consideration to assets acquired and liabilities assumed based on their estimated fair values, as presented in the following table (in millions):

[0001327567-20-000032:notes:183]
|  | Amount |
| Goodwill | $ | 68.6 |  |
| Identified intangible assets | 17.3 |  |
| Net liabilities assumed | (3.2) |  |
| Total | $ | 82.7 |  |

[0001327567-20-000032:notes:184]
Goodwill generated from this business combination is primarily attributable to the assembled workforce and expected post-acquisition synergies from integrating Secdo’s technology into our advanced endpoint protection offering and our portfolio. The goodwill is deductible for income tax purposes.

[0001327567-20-000032:notes:185]
|  | Fair Value |  | Estimated Useful Life |
| Developed technology | $ | 16.4 |  |  | 5 years |
| Customer relationships | 0.9 |  |  | 2 years |
| Total | $ | 17.3 |  |  |  |

[0001327567-20-000032:notes:186]
Evident.io, Inc.

[0001327567-20-000032:notes:187]
On March 26, 2018, we completed our acquisition of Evident.io, Inc. (“Evident.io”), a privately-held cloud security company. The acquisition expanded our API-based security capabilities for the public cloud with the addition of Evident.io’s cloud services infrastructure protection technology. The total purchase consideration for the acquisition of Evident.io was $292.9 million in cash, of which $4.0 million was accrued and was paid over a period of five months from the acquisition date.

[0001327567-20-000032:notes:188]
|  | Amount |
| Goodwill | $ | 209.8 |  |
| Identified intangible assets | 85.1 |  |
| Net liabilities assumed | (2.0) |  |
| Total | $ | 292.9 |  |

[0001327567-20-000032:notes:189]
Goodwill generated from this business combination is primarily attributable to the assembled workforce and expected post-acquisition synergies from integrating Evident.io’s technology into our platform and sales opportunities of Evident.io’s software as a service (“SaaS”) offerings. The goodwill is not deductible for income tax purposes.

[0001327567-20-000032:notes:190]
|  | Fair Value |  | Estimated Useful Life |
| Developed technology | $ | 68.4 |  |  | 4.5 years |
| Trade name and trademarks | 8.5 |  |  | 1 year |
| Customer relationships | 8.2 |  |  | 8 years |
| Total | $ | 85.1 |  |  |  |

[0001327567-20-000032:notes:191]
Additional Acquisition-Related Information

[0001327567-20-000032:notes:192]
The operating results of the acquired companies are included in our consolidated statements of operations from the respective dates of acquisition. Pro forma results of operations have not been presented because the effects of the acquisitions were not material to our consolidated statements of operations.

[0001327567-20-000032:notes:193]
Additional information related to our acquisitions completed in fiscal 2020, such as that related to income tax and other contingencies, existing as of the acquisition date but unknown to us may become known during the remainder of the measurement period, not to exceed 12 months from the respective acquisition date, which may result in changes to the amounts and allocations recorded.

[0001327567-20-000032:notes:194]
A portion of the goodwill from prior year foreign acquisitions may be deductible in future periods.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001327567-20-000032:notes:195]
Goodwill and Intangible Assets
Goodwill

[0001327567-20-000032:notes:196]
The following table presents details of our goodwill during the year ended July 31, 2020 (in millions):

[0001327567-20-000032:notes:197]
|  | Amount |
| Balance as of July 31, 2019 | $ | 1,352.3 |  |
| Goodwill acquired | 460.6 |  |
| Balance as of July 31, 2020 | $ | 1,812.9 |  |

[0001327567-20-000032:notes:198]
Purchased Intangible Assets

[0001327567-20-000032:notes:199]
The following table presents details of our purchased intangible assets as of July 31, 2020 and July 31, 2019 (in millions):

[0001327567-20-000032:notes:200]
|  | July 31, |  |  |  |  |  |  |  |  |  |  |
|  | 2020 |  |  |  |  |  | 2019 |  |  |  |  |
|  | Gross Carrying Amount |  | Accumulated Amortization |  | Net Carrying Amount |  | Gross Carrying Amount |  | Accumulated Amortization |  | Net Carrying Amount |
| Intangible assets subject to amortization: |  |  |  |  |  |  |  |  |  |  |  |
| Developed technology | $ | 425.9 |  |  | $ | (146.6) |  |  | $ | 279.3 |  |  | $ | 318.8 |  |  | $ | (78.7) |  |  | $ | 240.1 |  |
| Customer relationships | 87.6 |  |  | (12.4) |  |  | 75.2 |  |  | 39.8 |  |  | (4.7) |  |  | 35.1 |  |
| Acquired intellectual property | 6.3 |  |  | (3.2) |  |  | 3.1 |  |  | 8.9 |  |  | (5.1) |  |  | 3.8 |  |
| Trade name and trademarks | 9.4 |  |  | (9.4) |  |  | — |  |  | 9.4 |  |  | (9.4) |  |  | — |  |
| Other | 3.1 |  |  | (2.5) |  |  | 0.6 |  |  | 2.2 |  |  | (2.2) |  |  | — |  |
| Total intangible assets subject to amortization | 532.3 |  |  | (174.1) |  |  | 358.2 |  |  | 379.1 |  |  | (100.1) |  |  | 279.0 |  |
| Intangible assets not subject to amortization: |  |  |  |  |  |  |  |  |  |  |  |
| In-process research and development | — |  |  | — |  |  | — |  |  | 1.6 |  |  | — |  |  | 1.6 |  |
| Total purchased intangible assets | $ | 532.3 |  |  | $ | (174.1) |  |  | $ | 358.2 |  |  | $ | 380.7 |  |  | $ | (100.1) |  |  | $ | 280.6 |  |

[0001327567-20-000032:notes:201]
We recognized amortization expense of $77.3 million, $53.6 million, and $16.3 million for the years ended July 31, 2020, 2019, and 2018, respectively.

[0001327567-20-000032:notes:202]
The following table summarizes estimated future amortization expense of our intangible assets as of July 31, 2020 (in millions):

[0001327567-20-000032:notes:203]
|  | Amount |
| Years ending July 31: |  |
| 2021 | $ | 90.3 |  |
| 2022 | 85.2 |  |
| 2023 | 59.1 |  |
| 2024 | 51.0 |  |
| 2025 | 37.8 |  |
| 2026 and thereafter | 34.8 |  |
| Total future amortization expense | $ | 358.2 |  |


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001327567-20-000032:notes:204]
Property and Equipment
The following table presents details of our property and equipment, net as of July 31, 2020 and July 31, 2019 (in millions):

[0001327567-20-000032:notes:205]
|  | July 31, |  |  |
|  | 2020 |  | 2019 |
| Computers, equipment, and software | $ | 306.8 |  |  | $ | 264.1 |  |
| Leasehold improvements | 229.5 |  |  | 204.8 |  |
| Land | 49.6 |  |  | — |  |
| Demonstration units | 43.3 |  |  | 40.7 |  |
| Furniture and fixtures | 39.9 |  |  | 30.6 |  |
| Total property and equipment | 669.1 |  |  | 540.2 |  |
| Less: accumulated depreciation | (321.0) |  |  | (244.2) |  |
| Total property and equipment, net | $ | 348.1 |  |  | $ | 296.0 |  |

[0001327567-20-000032:notes:206]
We recognized depreciation expense of $96.0 million, $86.2 million, and $74.7 million related to property and equipment during the years ended July 31, 2020, 2019, and 2018, respectively.


## us-gaap:DebtDisclosureTextBlock

[0001327567-20-000032:notes:207]
Debt
Convertible Senior Notes

[0001327567-20-000032:notes:208]
In June 2014, we issued $575.0 million aggregate principal amount of 0.0% Convertible Senior Notes due 2019 (the “2019 Notes”), in July 2018, we issued $1.7 billion aggregate principal amount of 0.75% Convertible Senior Notes due 2023 (the “2023 Notes”) and, in June 2020, we issued $2.0 billion aggregate principal amount of 0.375% Convertible Senior Notes due 2025 (the “2025 Notes”, and together with the 2023 Notes, the “Notes”). The 2019 Notes were converted prior to or settled on the maturity date of July 1, 2019, in accordance with their terms. The 2023 Notes bear interest at a fixed rate of 0.75% per year, payable semi-annually in arrears on January 1 and July 1 of each year, beginning on January 1, 2019. The 2025 Notes bear interest at a fixed rate of 0.375% per year, payable semi-annually in arrears on June 1 and December 1 of each year, beginning on December 1, 2020. Each series of the convertible notes is governed by an indenture between us, as the issuer, and U.S. Bank National Association, as Trustee (individually, each an “Indenture,” and together, the “Indentures”). The Notes of each series are unsecured, unsubordinated obligations and the applicable Indenture governing each series of Notes does not contain any financial covenants or restrictions on the payments of dividends, the incurrence of indebtedness, or the issuance or repurchase of securities by us or any of our subsidiaries. The 2023 Notes and the 2025 Notes mature on July 1, 2023 and June 1, 2025, respectively. We cannot redeem the 2023 Notes prior to maturity. We may redeem for cash all or any portion of the 2025 Notes, at our option, on or after June 5, 2023, and prior to the 31st scheduled trading day immediately preceding the maturity date if the last reported sale price of our common stock has been at least 130% of the conversion price then in effect for at least 20 trading days during any 30 consecutive trading day period ending on and including the trading day preceding the date on which we provide notice of redemption. The redemption will be at a price equal to 100% of the principal amount of the 2025 Notes and adjusted for interest. If we call any or all of the 2025 Notes for redemption, holders may convert such 2025 Notes called for redemption at any time prior to the close of business on the second scheduled trading day immediately preceding the redemption date.

[0001327567-20-000032:notes:209]
The following table presents details of our convertible senior notes (number of shares in millions):

[0001327567-20-000032:notes:210]
|  | Conversion Rate per $1,000 Principal |  | Initial Conversion Price |  | Convertible Date |  | Initial Number of Shares |
| 2019 Notes | 9.0680 |  |  | $ | 110.28 |  |  | January 1, 2019 |  | 5.2 |  |
| 2023 Notes | 3.7545 |  |  | $ | 266.35 |  |  | April 1, 2023 |  | 6.4 |  |
| 2025 Notes | 3.3602 |  |  | $ | 297.60 |  |  | March 1, 2025 |  | 6.7 |  |

[0001327567-20-000032:notes:211]
Holders of the Notes may surrender their Notes for conversion at their option at any time prior to the close of business on the business day immediately preceding their respective convertible dates only under the following circumstances:

[0001327567-20-000032:notes:212]
•during any fiscal quarter commencing after the fiscal quarters ending on October 31, 2018 and October 31, 2020 for the 2023 Notes and the 2025 Notes respectively (and only during such fiscal quarter), if the last reported sale price of our common stock for at least 20 trading days (whether or not consecutive) during a period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the applicable conversion price for the respective Notes on each applicable trading day (the “sale price condition”);

[0001327567-20-000032:notes:213]
•during the five business day period after any five consecutive trading day period (the “measurement period”) in which the trading price per $1,000 principal amount of the applicable series of Notes for each trading day of the measurement period was less than 98% of the product of the last reported sale price of our common stock and the applicable conversion rate for the respective Notes on each such trading day; or

[0001327567-20-000032:notes:214]
•upon the occurrence of specified corporate events.

[0001327567-20-000032:notes:215]
On or after the respective convertible date, holders may surrender all or any portion of their Notes for conversion at any time prior to the close of business on the second scheduled trading day immediately preceding the applicable maturity date regardless of the foregoing conditions, and such conversions will be settled upon the applicable maturity date. Upon conversion, holders of the Notes of a series will receive cash equal to the aggregate principal amount of the Notes of such series to be converted, and, at our election, cash and/or shares of our common stock for any amounts in excess of the aggregate principal amount of the Notes of such series being converted.

[0001327567-20-000032:notes:216]
The conversion price will be subject to adjustment in some events. Holders of the Notes of a series who convert their Notes of such series in connection with certain corporate events that constitute a “make-whole fundamental change” under the applicable Indenture are, under certain circumstances, entitled to an increase in the conversion rate for such series of Notes. Additionally, upon the occurrence of a corporate event that constitutes a “fundamental change” under the applicable Indenture, holders of the Notes of such series may require us to repurchase for cash all or a portion of the Notes of such series at a repurchase price equal to 100% of the principal amount of the Notes of such series plus accrued and unpaid interest to, but excluding, the fundamental change repurchase date.

[0001327567-20-000032:notes:217]
The sale price condition was not met for the 2023 Notes during the fiscal quarters ended July 31, 2020 or July 31, 2019, and the sale price condition was not met for the 2025 Notes during the fiscal quarter ended July 31, 2020. Since our Notes were not convertible, the net carrying amount of the Notes was classified as a long-term liability and the equity component was included in additional paid-in capital in our consolidated balance sheets in the periods they each were presented.

[0001327567-20-000032:notes:218]
During the year ended July 31, 2019, we repaid $575.0 million in aggregate principal amount of the 2019 Notes, of which $415.6 million in aggregate principal amount pertained to early conversions submitted by the holders prior to January 1, 2019.

[0001327567-20-000032:notes:219]
The following table presents details of early conversions of the 2019 Notes during the year ended July 31, 2019 (in millions):

[0001327567-20-000032:notes:220]
|  | Year Ended |
|  | July 31, 2019 |
| 2019 Notes principal early converted and repaid in cash: |  |
| Allocated to liability component(1) | $ | 403.4 |  |
| Allocated to equity component(2) | 12.2 |  |
| Total principal early converted and repaid in cash | $ | 415.6 |  |
| Loss on early conversions of convertible senior notes(3) | $ | 2.6 |  |

[0001327567-20-000032:notes:221]
______________

[0001327567-20-000032:notes:222]
(1) Recorded as a reduction to convertible senior notes, net in our consolidated balance sheets and calculated by measuring the fair value of a similar liability that did not have an associated convertible feature.

[0001327567-20-000032:notes:223]
(2) Recorded as a reduction to additional paid-in capital in our consolidated balance sheets.

[0001327567-20-000032:notes:224]
(3) Represents the difference between the cash consideration allocated to the liability component and the net carrying amount of the liability component on the respective settlement dates. The amount is included in other income, net in our consolidated statement of operations.

[0001327567-20-000032:notes:225]
The remaining $159.4 million in aggregate principal amount was repaid on the July 1, 2019 maturity date. We issued 2.5 million shares of common stock to the holders of the 2019 Notes for the conversion value in excess of the principal amount during the year ended July 31, 2019. These shares were fully offset by shares received from the corresponding exercise of the associated note hedges.

[0001327567-20-000032:notes:226]
The following table sets forth the components of the Notes as of July 31, 2020 and July 31, 2019 (in millions):

[0001327567-20-000032:notes:227]
|  |  |  | July 31, 2020 |  |  |  |  |  |  |  | July 31, 2019 |  |  |
|  |  |  | 2023 Notes |  | 2025 Notes |  | Total |  |  |  | 2023 Notes |  | Total |
| Liability component: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Principal |  |  | $ | 1,693.0 |  |  | $ | 2,000.0 |  |  | $ | 3,693.0 |  |  |  |  | $ | 1,693.0 |  |  | $ | 1,693.0 |  |
| Less: debt discount and debt issuance costs, net of amortization |  |  | 200.0 |  |  | 408.9 |  |  | 608.9 |  |  |  |  | 263.0 |  |  | 263.0 |  |
| Net carrying amount |  |  | $ | 1,493.0 |  |  | $ | 1,591.1 |  |  | $ | 3,084.1 |  |  |  |  | $ | 1,430.0 |  |  | $ | 1,430.0 |  |
| Equity component |  |  | $ | 315.0 |  |  | $ | 403.0 |  |  | $ | 718.0 |  |  |  |  | $ | 315.0 |  |  | $ | 315.0 |  |

[0001327567-20-000032:notes:228]
The total estimated fair value of the Notes was $4.1 billion at July 31, 2020. The total estimated fair value of the 2023 Notes was $1.9 billion at July 31, 2019. The fair value was determined based on the closing trading price per $100 of the Notes as of the last day of trading for the period. We consider the fair value of the Notes at July 31, 2020 and July 31, 2019 to be a Level 2 measurement. The fair value of the Notes is primarily affected by the trading price of our common stock and market interest rates. Based on the closing price of our common stock on July 31, 2020, the if-converted value of the 2023 Notes and the 2025 Notes each was less than its principal amount.

[0001327567-20-000032:notes:229]
The following table sets forth interest expense recognized related to our convertible senior notes (dollars in millions):

[0001327567-20-000032:notes:230]
|  |  |  | Year Ended July 31, 2020 |  |  |  |  |  | Year Ended July 31, 2019 |  |  |  |  |  | Year Ended July 31, 2018 |  |  |  |  |
|  |  |  | 2023 Notes |  | 2025 Notes |  | Total |  | 2019 Notes |  | 2023 Notes |  | Total |  | 2019 Notes |  | 2023 Notes |  | Total |
| Contractual interest expense |  |  | $ | 12.7 |  |  | $ | 1.1 |  |  | $ | 13.8 |  |  | $ | — |  |  | $ | 12.7 |  |  | $ | 12.7 |  |  | $ | — |  |  | $ | 0.7 |  |  | $ | 0.7 |  |
| Amortization of debt discount |  |  | 60.9 |  |  | 10.5 |  |  | 71.4 |  |  | 8.7 |  |  | 58.5 |  |  | 67.2 |  |  | 22.9 |  |  | 3.0 |  |  | 25.9 |  |
| Amortization of debt issuance costs |  |  | 2.1 |  |  | 0.4 |  |  | 2.5 |  |  | 1.1 |  |  | 1.9 |  |  | 3.0 |  |  | 2.8 |  |  | 0.1 |  |  | 2.9 |  |
| Total interest expense recognized |  |  | $ | 75.7 |  |  | $ | 12.0 |  |  | $ | 87.7 |  |  | $ | 9.8 |  |  | $ | 73.1 |  |  | $ | 82.9 |  |  | $ | 25.7 |  |  | $ | 3.8 |  |  | $ | 29.5 |  |
| Effective interest rate of the liability component |  |  | 5.2 | % |  | 5.4 | % |  |  |  | 4.8 | % |  | 5.2 | % |  |  |  | 4.8 | % |  | 5.2 | % |  |  |

[0001327567-20-000032:notes:231]
Note Hedges

[0001327567-20-000032:notes:232]
To minimize the impact of potential economic dilution upon conversion of our convertible senior notes, we entered into separate convertible note hedge transactions (the “2019 Note Hedges,” with respect to the 2019 Notes, the “2023 Note Hedges,” with respect to the 2023 Notes, the “2025 Note Hedges,” with respect to the 2025 Notes and the 2023 Notes Hedgers together with 2025 Note Hedges, the “Note Hedges”) with respect to our common stock concurrent with the issuance of each series of our convertible senior notes.

[0001327567-20-000032:notes:233]
The following table presents details of our note hedges (in millions):

[0001327567-20-000032:notes:234]
|  | Initial Number of Shares |  | Aggregate Purchase |
| 2019 Note Hedges | 5.2 |  |  | $ | 111.0 |  |
| 2023 Note Hedges | 6.4 |  |  | $ | 332.0 |  |
| 2025 Note Hedges | 6.7 |  |  | $ | 370.8 |  |

[0001327567-20-000032:notes:235]
Upon the settlement of the 2019 Notes, we exercised the corresponding portion of our 2019 Note Hedges during the year ended July 31, 2019 and received shares of our common stock that fully offset the shares issued in excess of the principal amount of the converted 2019 Notes. The 2019 Note Hedges expired upon maturity of the 2019 Notes.

[0001327567-20-000032:notes:236]
The Note Hedges cover shares of our common stock at a strike price per share that corresponds to the initial applicable conversion price of the applicable series of Notes, which are also subject to adjustment, and are exercisable upon conversion of the applicable series of the Notes. The Note Hedges will expire upon maturity of the applicable series of Notes. The Note Hedges are separate transactions and are not part of the terms of the applicable series of the Notes. Holders of the Notes of either series will not have any rights with respect to the Note Hedges. Any shares of our common stock receivable by us under the Note Hedges are excluded from the calculation of diluted earnings per share as they are antidilutive. The aggregate amounts paid for the Note Hedges are included in additional paid-in capital in our consolidated balance sheets.

[0001327567-20-000032:notes:237]
Warrants

[0001327567-20-000032:notes:238]
Separately, but concurrently with the issuance of each series of our convertible senior notes, we entered into transactions whereby we sold warrants (the “2019 Warrants,” with respect to the 2019 Notes, the “2023 Warrants,” with respect to the 2023 Notes, the “2025 Warrants,” with respect to the 2025 Notes and the 2023 Warrants together with the 2025 Warrants, the “Warrants”) to acquire shares of our common stock, subject to anti-dilution adjustments. The 2019 Warrants were exercisable as of October 2019, and the 2023 Warrants and 2025 Warrants are exercisable beginning October 2023 and September 2025, respectively.

[0001327567-20-000032:notes:239]
The following table presents details of all our warrants (in millions, except per share data):

[0001327567-20-000032:notes:240]
|  | Initial Number of Shares |  | Strike Price per Share |  | Aggregate Proceeds |
| 2019 Warrants | 5.2 |  |  | $ | 137.85 |  |  | $ | 78.3 |  |
| 2023 Warrants | 6.4 |  |  | $ | 417.80 |  |  | $ | 145.4 |  |
| 2025 Warrants | 6.7 |  |  | $ | 408.47 |  |  | $ | 202.8 |  |

[0001327567-20-000032:notes:241]
During the year ended July 31, 2020, we net settled all 2019 Warrants with 2.0 million shares or $462.0 million in fair value of our common stock. The number of net shares issued was determined based on the number of 2019 Warrants exercised multiplied by the difference between the strike price of the 2019 Warrants and their daily volume weighted-average stock price.

[0001327567-20-000032:notes:242]
The shares issuable under the Warrants will be included in the calculation of diluted earnings per share when the average market value per share of our common stock for the reporting period exceeds the applicable strike price for such series of Warrants. The Warrants are separate transactions and are not part of either series of Notes or Note Hedges and are not remeasured through earnings each reporting period. Holders of the Notes of either series will not have any rights with respect to the Warrants. The aggregate proceeds received from the sale of the Warrants are included in additional paid-in capital in our consolidated balance sheets.

[0001327567-20-000032:notes:243]
Revolving Credit Facility

[0001327567-20-000032:notes:244]
On September 4, 2018, we entered into a credit agreement (the “Credit Agreement”) with certain institutional lenders that provides for a $400.0 million unsecured revolving credit facility (the “Credit Facility”), with an option to increase the amount of the Credit Facility by up to an additional $350.0 million, subject to certain conditions. The Credit Facility matures on the earlier of (i) September 4, 2023 and (ii) the date that is 91 days prior to the stated maturity of our 2023 Notes if (a) any of the 2023 Notes are still outstanding and (b) our unrestricted cash and cash equivalents are less than the then outstanding principal amount of our 2023 Notes plus $400.0 million.

[0001327567-20-000032:notes:245]
The borrowings under the Credit Facility currently bear interest, at our option, at a base rate plus a spread of 0.00% to 0.75%, or an adjusted LIBO rate plus a spread of 1.00% to 1.75%, in each case with such spread being determined based on our leverage ratio. We are obligated to pay an ongoing commitment fee on undrawn amounts at a rate of 0.125% to 0.250%, depending on our leverage ratio. Regulatory authorities that oversee financial markets have announced that after the end of 2021, they would no longer compel banks currently reporting information used to set the LIBO Rate to continue to make rate submissions. As a result, it is possible that beginning in 2022, the LIBO Rate will no longer be available as a reference rate. Under the terms of our Credit Facility, in the event of the discontinuance of the LIBO Rate, a mutually agreed-upon alternative benchmark rate will be established to replace the LIBO Rate, which may include the Secured Overnight Financing Rate ("SOFR"). We do not anticipate that the discontinuance of the LIBO Rate will materially impact our liquidity or financial position.

[0001327567-20-000032:notes:246]
As of July 31, 2020, there were no amounts outstanding, and we were in compliance with all covenants under the Credit Agreement.


## us-gaap:LesseeOperatingLeasesTextBlock

[0001327567-20-000032:notes:247]
11. Leases

[0001327567-20-000032:notes:248]
We have entered into various non-cancelable operating leases primarily for our facilities with original lease periods expiring through the year ending July 31, 2028.

[0001327567-20-000032:notes:249]
In May 2015 and October 2015, we entered into a total of three lease agreements for approximately 941,000 square feet of corporate office space in Santa Clara, California, which serves as our new corporate headquarters. The leases contain rent holiday periods, scheduled rent increases, lease incentives, and renewal options which allow the lease terms to be extended beyond their expiration dates of July 2028 through July 2046. In September 2017, per the terms of the lease agreements, the landlords exercised their option to amend our lease payment schedules and eliminate our rent holiday periods, which increased our rental payments by $24.4 million, $11.8 million, and $2.0 million for fiscal 2018, 2019, and 2020, respectively. In exchange, we received an upfront cash reimbursement of $38.2 million during the three months ended October 31, 2017, which we have applied against the future additional rental payments when due. As amended, rental payments under the three lease agreements are approximately $412.0 million over the lease term.

[0001327567-20-000032:notes:250]
In May 2015, we also entered into a lease agreement for approximately 122,000 square feet of space in Santa Clara, California to serve as an extension of our previous corporate headquarters. The lease contains scheduled rent increases, lease incentives, and

[0001327567-20-000032:notes:251]
renewal options which allow the lease term to be extended beyond the expiration date of April 2021 through July 2046. Rental payments under the lease agreement are approximately $23.1 million over the lease term. In December 2017, we entered into an agreement to sublease this office space for the remaining lease term. Proceeds from this sublease are approximately $16.3 million over the sublease term.

[0001327567-20-000032:notes:252]
In September 2012, we entered into two lease agreements for a total of approximately 300,000 square feet of space in Santa Clara, California, which served as our previous corporate headquarters through August 2017, when we relocated to our new corporate campus. The leases contain rent holiday periods and two separate five-year options to extend the lease term beyond their expiration dates of July 2023. Rental payments under these lease agreements are approximately $94.3 million over the lease term. In August 2017, we exited our previous corporate headquarter facilities and relocated to our new corporate campus, which resulted in the recognition of a cease-use loss of $39.2 million during the year ended July 31, 2018. Due to changes in market conditions, and the resulting changes to the amount and timing of estimated cash flows from sublease rentals that could be reasonably obtained, we recognized an additional cease-use loss of $7.0 million as general and administrative expense in our consolidated statements of operations during the year ended July 31, 2019. In December 2019, we terminated these leases prior to their expiration date. The early termination fee is $25.0 million, payable in equal quarterly installments from April 2020 through July 2023. Upon termination, we recorded a decrease of $13.6 million in operating lease liabilities based on the payment schedule of the early termination fee discounted by the incremental borrowing rate for the remaining payment term. We also decreased right-of-use assets by $8.7 million upon surrendering possession of the properties. As a result, during the year ended July 31, 2020, we recorded a gain of $3.1 million net of other related fees of $1.8 million in general and administrative expense in our consolidated statements of operations.

[0001327567-20-000032:notes:253]
During the year ended July 31, 2020, our net cost for operating leases was $80.4 million and primarily consisted of operating lease costs of $63.5 million, in addition to variable lease costs, short-term lease costs and sublease income. We recognized rent expense of $43.0 million, and $35.2 million for the years ended July 31, 2019, and 2018, respectively prior to our adoption of the new lease guidance.

[0001327567-20-000032:notes:254]
The following tables present additional information for our operating leases (in millions, except for years and percentages):

[0001327567-20-000032:notes:255]
|  | Year Ended July 31, 2020 |
| Operating cash flows used in payments of operating lease liabilities | $ | 78.3 |  |
| Right-of-use assets obtained in exchange for new operating lease liabilities | $ | 28.4 |  |
|  | July 31, 2020 |
| Weighted-average remaining lease term | 7.0 years |
| Weighted-average discount rate | 3.9 | % |

[0001327567-20-000032:notes:256]
The following table presents maturities of operating lease liabilities as of July 31, 2020 (in millions):

[0001327567-20-000032:notes:257]
|  | Amount |
| Fiscal years ending July 31: |  |
| 2021 | $ | 72.2 |  |
| 2022 | 70.4 |  |
| 2023 | 62.4 |  |
| 2024 | 51.6 |  |
| 2025 | 50.9 |  |
| 2026 and thereafter | 145.8 |  |
| Total operating lease payments | 453.3 |  |
| Less: imputed interest | 58.8 |  |
| Present value of operating lease liabilities | $ | 394.5 |  |
| Current portion of operating lease liabilities(1) | $ | 57.9 |  |
| Long-term operating lease liabilities | $ | 336.6 |  |

[0001327567-20-000032:notes:258]
________________________

[0001327567-20-000032:notes:259]
(1) Current portion of operating lease liabilities is included in accrued and other liabilities on our consolidated balance sheet.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001327567-20-000032:notes:260]
12. Commitments and Contingencies

[0001327567-20-000032:notes:261]
Manufacturing Purchase Commitments

[0001327567-20-000032:notes:262]
Our EMS provider procures components and assembles our products based on our forecasts. These forecasts are based on estimates of demand for our products primarily for the next 12 months, which are in turn based on historical trends and an analysis from our sales and product management organizations, adjusted for overall market conditions. In order to reduce manufacturing lead times and plan for adequate supply, we may issue non-cancelable orders for products and components to our manufacturing partners or component suppliers. As of July 31, 2020, our purchase commitments under such orders were $108.5 million, excluding obligations under contracts that we can cancel without a significant penalty.

[0001327567-20-000032:notes:263]
Other Purchase Commitments

[0001327567-20-000032:notes:264]
We have entered into various non-cancelable agreements with third-party providers for our use of certain cloud and other services, under which we are committed to minimum or fixed purchases through the year ending July 31, 2026. The following table presents details of the aggregate future non-cancelable purchase commitments under these agreements as of July 31, 2020 (in millions):

[0001327567-20-000032:notes:265]
|  | Amount |
| Fiscal years ending July 31: |  |
| 2021 | $ | 48.3 |  |
| 2022 | 48.3 |  |
| 2023 | 51.8 |  |
| 2024 | 67.5 |  |
| 2025 | 77.5 |  |
| 2026 and thereafter | 20.0 |  |
| Total other purchase commitments | $ | 313.4 |  |

[0001327567-20-000032:notes:266]
Mutual Covenant Not to Sue and Release Agreement

[0001327567-20-000032:notes:267]
In January 2020, we executed a Mutual Covenant Not to Sue and Release Agreement for $50.0 million to extend an existing covenant not to sue for seven years. As the primary benefit of the arrangement was attributable to future use, the amount was recorded in other assets on our consolidated balance sheets and is amortized to cost of product revenue in our consolidated statements of operations over the estimated period of benefit of seven years.

[0001327567-20-000032:notes:268]
Litigation

[0001327567-20-000032:notes:269]
We are subject to legal proceedings, claims, and litigation arising in the ordinary course of business, including intellectual property litigation. Such matters are subject to many uncertainties and outcomes are not predictable with assurance. We accrue for contingencies when we believe that a loss is probable and that we can reasonably estimate the amount of any such loss.

[0001327567-20-000032:notes:270]
To the extent there is a reasonable possibility that a loss exceeding amounts already recognized may be incurred and the amount of such additional loss would be material, we will either disclose the estimated additional loss or state that such an estimate cannot be made. As of July 31, 2020, we have not recorded any significant accruals for loss contingencies associated with such legal proceedings, determined that an unfavorable outcome is probable or reasonably possible, or determined that the amount or range of any possible loss is reasonably estimable.

[0001327567-20-000032:notes:271]
Indemnification

[0001327567-20-000032:notes:272]
Under the indemnification provisions of our standard sales related contracts, we agree to defend our end-customers against third-party claims asserting infringement of certain intellectual property rights, which may include patents, copyrights, trademarks, or trade secrets, and to pay judgments entered on such claims. Our exposure under these indemnification provisions is generally limited to payments made to us for the alleged infringing products over the preceding twelve months under the agreement. However, certain agreements include indemnification provisions that could potentially expose us to losses in excess of these payments. In addition, we indemnify our officers, directors, and certain key employees while they are serving in good faith in their company capacities. To date, we have not recorded any accruals for loss contingencies associated with indemnification claims or determined that an unfavorable outcome is probable or reasonably possible.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001327567-20-000032:notes:273]
13. Stockholders’ Equity

[0001327567-20-000032:notes:274]
Share Repurchase Program

[0001327567-20-000032:notes:275]
In August 2016, our board of directors authorized a $500.0 million share repurchase program and in February 2017 authorized a $500.0 million increase to the repurchase program, bringing the total authorization to $1.0 billion (our “original authorization”). This repurchase program expired on December 31, 2018. In February 2019, our board of directors authorized a new $1.0 billion share repurchase program which is funded from available working capital (our “current authorization”). This repurchase program will expire on December 31, 2020 and may be suspended or discontinued at any time. Repurchases may be made at management’s discretion from time to time on the open market, through privately negotiated transactions, transactions structured through investment banking institutions, block purchase techniques, 10b5-1 trading plans, or a combination of the foregoing.

[0001327567-20-000032:notes:276]
During the years ended July 31, 2019 and 2018, we repurchased and retired 1.9 million shares and 1.7 million shares, respectively, of our common stock under our original authorization for an aggregate purchase price of $330.0 million, and $250.0 million, respectively, including transaction costs. During the fiscal year ended July 31, 2020, we repurchased and retired 0.9 million shares of our common stock under our current authorization for an aggregate purchase price of $198.1 million, including transaction costs. As of July 31, 2020, $801.9 million remained available for future share repurchases under our current repurchase authorization. The total price of the shares repurchased and related transaction costs are reflected as a reduction to common stock and additional paid-in capital on our consolidated balance sheets.

[0001327567-20-000032:notes:277]
Accelerated Stock Repurchase

[0001327567-20-000032:notes:278]
In February 2020, our board of directors approved the repurchase of $1.0 billion of our common stock through an accelerated share repurchase (“ASR”) transaction with a financial institution. This ASR transaction was in addition to our share repurchase program. 
During the fiscal year ended July 31, 2020, we completed the ASR transaction with an aggregate of 5.2 million shares of our common stock repurchased and retired. The total price of the ASR transaction is reflected as a reduction to common stock and additional paid-in capital on our consolidated balance sheet.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001327567-20-000032:notes:279]
Equity Award Plans 
Share-Based Compensation Plans

[0001327567-20-000032:notes:280]
2012 Equity Incentive Plan

[0001327567-20-000032:notes:281]
Our 2012 Equity Incentive Plan (our “2012 Plan”) was adopted by our board of directors and approved by the stockholders on June 5, 2012 and was effective one business day prior to the effectiveness of our registration statement for our initial public offering (“IPO”). Our 2012 Plan replaced our 2005 Equity Incentive Plan (our “2005 Plan”), which terminated upon the completion of our IPO, however, awards that were outstanding upon termination remained outstanding pursuant to their original terms. Our 2012 Plan provides for the granting of stock options, restricted stock award (“RSA”), restricted stock unit (“RSU”), stock appreciation rights, performance-based stock units (“PSUs”), performance shares (“PSAs”), and performance stock options (“PSOs”) to our employees, directors, and consultants.

[0001327567-20-000032:notes:282]
Awards granted under our 2012 Plan vest over the periods determined by the board of directors, generally three to four years from the date of grant, and our options expire no more than ten years after the date of grant. Since our IPO in 2012, awards granted under our 2012 Plan consist primarily of RSUs. Until vested, RSUs do not have the voting and dividend participation rights of common stock and the shares underlying the awards are not considered issued and outstanding.

[0001327567-20-000032:notes:283]
We grant awards with performance conditions (PSAs and PSUs) to certain employees, which vest over a period of one to four years from the date of grant. The actual number of PSAs and PSUs earned and eligible to vest is determined based on the level of achievement against revenue growth, pre-established billings and operating margin goals, or pre-defined individual performance targets for the fiscal year.

[0001327567-20-000032:notes:284]
We have also granted PSOs with both a market condition and a service condition to certain executives. The market condition requires the price of our common stock to equal or exceed $297.75, $397.00, $496.25, and $595.50 (the “stock price targets”) during the four-, five-, six-, and seven-year periods following the date of grant in fiscal year 2018 and 2019, respectively. To the extent that the stock price targets have been met, one-fourth of the PSOs will vest on the anniversary date of the grant date for such PSOs, subject to continued service. All outstanding PSOs may be exercised prior to vesting (“early exercised”). Shares of common stock issued upon early exercise of the PSOs will be restricted and, at our option, subject to repurchase if the option holder ceases to be a service provider. The contractual term of our PSOs is seven to seven and a half years from the date of grant, depending on vesting period. As of July 31, 2020, the market condition for the PSOs has not been met.

[0001327567-20-000032:notes:285]
We net-share settle equity awards held by certain employees by withholding shares upon vesting to satisfy tax withholding obligations. The shares withheld to satisfy employee tax withholding obligations are returned to our 2012 Plan and will be available for future issuance. Payments for employees’ tax obligations to the tax authorities are recognized as a reduction to additional paid-in capital and reflected as financing activities in our consolidated statements of cash flows.

[0001327567-20-000032:notes:286]
A total of 20.3 million shares of our common stock are reserved for issuance pursuant to our 2012 Plan as of July 31, 2020. This includes shares that are (i) reserved but unissued under our 2005 Plan on the effective date of our 2012 Plan or (ii) returned to our 2005 Plan as a result of expiration or termination of options. On the first day of each fiscal year, the number of shares in the reserve may be increased by the lesser of (i) 8,000,000 shares, (ii) 4.5% of the outstanding shares of common stock on the last day of our immediately preceding fiscal year, or (iii) such other amount as determined by our board of directors.

[0001327567-20-000032:notes:287]
2012 Employee Stock Purchase Plan

[0001327567-20-000032:notes:288]
Our 2012 Employee Stock Purchase Plan was adopted by our board of directors and approved by the stockholders on June 5, 2012, and was effective upon completion of our IPO. On August 29, 2017, we amended and restated our 2012 Employee Stock Purchase Plan (our “2012 ESPP”) to extend the length of our offering periods from 6 to 24 months.

[0001327567-20-000032:notes:289]
Our 2012 ESPP permits eligible employees to acquire shares of our common stock at 85% of the lower of the fair market value of our common stock on the first trading day of each offering period or on the purchase date. If the fair market value of our common stock on the purchase date is lower than the first trading day of the offering period, the current offering period will be cancelled after purchase and a new 24-month offering period will begin. Under our 2012 ESPP, each 24-month offering period consists of four consecutive 6-month purchase periods, with purchase dates on the first trading day on or after February 28 and August 31 of each year. Participants may purchase shares of common stock through payroll deductions of up to 15% of their eligible compensation, subject to purchase limits of 625 shares per six-month purchase period and $25,000 worth of stock for each calendar year. During the year ended July 31, 2020, employees purchased 0.6 million shares of common stock under our 2012 ESPP at an average exercise price of $146.90 per share.

[0001327567-20-000032:notes:290]
A total of 4.3 million shares of our common stock are available for sale under our 2012 ESPP as of July 31, 2020. On the first day of each fiscal year, the number of shares in the reserve may be increased by the lesser of (i) 2,000,000 shares, (ii) 1% of the outstanding shares of our common stock on the first day of the fiscal year, or (iii) such other amount as determined by our board of directors.

[0001327567-20-000032:notes:291]
Acquisition-related Activities

[0001327567-20-000032:notes:292]
Assumed Share-based Compensation Plans

[0001327567-20-000032:notes:293]
In connection with our acquisitions of CloudGenix, Aporeto, and Zingbox during the year ended July 31, 2020, we assumed CloudGenix’s 2013 Equity Incentive Plan, Aporeto’s Amended and Restated 2015 Stock Option and Grant Plan and Zingbox’s Stock Incentive Plan, as amended and restated (together, the “2020 assumed Plans”). The equity awards assumed in connection with each acquisition were granted from their respective assumed plans. The assumed equity awards will be settled in shares of our common stock and will retain the terms and conditions under which they were originally granted. No additional equity awards will be granted under and forfeited awards will not be returned to the 2020 assumed Plans.

[0001327567-20-000032:notes:294]
In connection with our acquisitions of RedLock, Demisto, and Twistlock during the year ended July 31, 2019, we assumed RedLock’s 2015 Stock Plan, as amended, Demisto’s 2015 Stock Option Plan, as amended, and Twistlock’s 2015 Share Option Plan, as amended and restated (together, the “2019 assumed Plans”). The equity awards assumed in connection with each acquisition were granted from their respective assumed plans. The assumed equity awards will be settled in shares of our common stock and will retain the terms and conditions under which they were originally granted. No additional equity awards will be granted under and forfeited awards will not be returned to the 2019 assumed Plans.

[0001327567-20-000032:notes:295]
Refer to Note 6. Acquisitions for more information on our acquisitions and the related equity awards assumed.

[0001327567-20-000032:notes:296]
Restricted Stock Issuances

[0001327567-20-000032:notes:297]
In connection with our acquisition of Zingbox during the year ended July 31, 2020, we issued a total of 0.1 million shares of restricted common stock as replacement equity awards which are subject to additional time-based vesting requirements and continued service by the award holder.

[0001327567-20-000032:notes:298]
In connection with our acquisitions of RedLock, Demisto, PureSec, and Twistlock during the year ended July 31, 2019, we issued a total of 0.5 million shares of restricted common stock as replacement equity awards which are subject to additional time-based vesting requirements and continued service by the award holder.

[0001327567-20-000032:notes:299]
Stock Option Activities

[0001327567-20-000032:notes:300]
The following table summarizes the stock option and PSO activity under our stock plans during the years ended July 31, 2020, 2019, and 2018 (in millions, except per share amounts):

[0001327567-20-000032:notes:301]
|  | Stock Options Outstanding |  |  |  |  |  |  |  | PSOs Outstanding |  |  |  |  |  |  |
|  | Number of Shares |  | Weighted-Average Exercise Price Per Share |  | Weighted-Average Remaining Contractual Term(Years) |  | Aggregate Intrinsic Value |  | Number of Shares |  | Weighted-Average Exercise Price Per Share |  | Weighted-Average Remaining Contractual Term(Years) |  | Aggregate Intrinsic Value |
| Balance—July 31, 2017 | 1.6 |  |  | $ | 13.11 |  |  | 4.2 |  | $ | 190.6 |  |  | — |  |  | $ | — |  |  | 0.0 |  | $ | — |  |
| Granted | — |  |  | $ | — |  |  |  |  |  |  | 1.2 |  |  | $ | 198.50 |  |  |  |  |  |
| Exercised | (0.6) |  |  | $ | 12.76 |  |  |  |  |  |  | — |  |  | $ | — |  |  |  |  |  |
| Balance—July 31, 2018 | 1.0 |  |  | $ | 13.28 |  |  | 3.1 |  | $ | 199.8 |  |  | 1.2 |  |  | $ | 198.50 |  |  | 7.0 |  | $ | — |  |
| Granted | — |  |  | $ | — |  |  |  |  |  |  | 2.6 |  |  | $ | 191.97 |  |  |  |  |  |
| Exercised | (0.7) |  |  | $ | 12.61 |  |  |  |  |  |  | — |  |  | $ | — |  |  |  |  |  |
| Forfeited | — |  |  | $ | 1.24 |  |  |  |  |  |  | (0.1) |  |  | $ | 193.51 |  |  |  |  |  |
| Balance—July 31, 2019 | 0.3 |  |  | $ | 14.53 |  |  | 2.2 |  | $ | 81.4 |  |  | 3.7 |  |  | $ | 193.99 |  |  | 6.2 |  | $ | 120.1 |  |
| Exercised | (0.2) |  |  | $ | 11.46 |  |  |  |  |  |  | — |  |  | $ | — |  |  |  |  |  |
| Forfeited | — |  |  | $ | — |  |  |  |  |  |  | (0.9) |  |  | $ | 193.51 |  |  |  |  |  |
| Balance—July 31, 2020 | 0.1 |  |  | $ | 19.59 |  |  | 1.5 |  | $ | 34.2 |  |  | 2.8 |  |  | $ | 194.14 |  |  | 5.2 |  | $ | 170.9 |  |
| Exercisable—July 31, 2020 | 0.1 |  |  | $ | 19.59 |  |  | 1.5 |  | $ | 34.2 |  |  | 2.8 |  |  | $ | 194.14 |  |  | 5.2 |  | $ | 170.9 |  |

[0001327567-20-000032:notes:302]
The weighted-average grant-date fair value of PSOs granted during the years ended July 31, 2019 and 2018 was $59.11, and $56.14 per share, respectively. The intrinsic value of options exercised during the years ended July 31, 2020, 2019, and 2018 was $50.2 million, $139.5 million and $85.0 million, respectively.

[0001327567-20-000032:notes:303]
RSA and PSA Activities

[0001327567-20-000032:notes:304]
The following table summarizes the RSA and PSA activity under our stock plans during the years ended July 31, 2020, 2019, and 2018 (in millions, except per share amounts):

[0001327567-20-000032:notes:305]
|  | RSAs Outstanding |  |  |  | PSAs Outstanding |  |  |
|  | Number of Shares |  | Weighted- Average Grant-Date Fair Value Per Share |  | Number of Shares |  | Weighted- Average Grant-Date Fair Value Per Share |
| Balance—July 31, 2017 | 0.8 |  |  | $ | 166.86 |  |  | 0.2 |  |  | $ | 148.54 |  |
| Vested | (0.5) |  |  | $ | 169.38 |  |  | 0.0 |  |  | $ | 148.54 |  |
| Forfeited | (0.1) |  |  | $ | 166.05 |  |  | (0.1) |  |  | $ | 148.54 |  |
| Balance—July 31, 2018 | 0.2 |  |  | $ | 163.14 |  |  | 0.1 |  |  | $ | 148.54 |  |
| Vested | (0.2) |  |  | $ | 166.83 |  |  | 0.0 |  |  | $ | 148.54 |  |
| Forfeited | 0.0 |  |  | $ | 152.09 |  |  | 0.0 |  |  | $ | 148.54 |  |
| Balance—July 31, 2019 | 0.0 |  |  | $ | 148.54 |  |  | 0.1 |  |  | $ | 148.54 |  |
| Vested | 0.0 |  |  | $ | 148.54 |  |  | 0.0 |  |  | $ | 148.54 |  |
| Forfeited | 0.0 |  |  | $ | 148.54 |  |  | 0.0 |  |  | $ | 148.54 |  |
| Balance—July 31, 2020 | 0.0 |  |  | $ | 148.54 |  |  | 0.1 |  |  | $ | 148.54 |  |

[0001327567-20-000032:notes:306]
The aggregate fair value, as of respective vesting dates, of RSAs vested during the years ended July 31, 2020, 2019, and 2018, was $7.0 million, $41.1 million and $65.0 million, respectively. The aggregate fair value, as of the respective vesting dates, of PSAs vested during the years ended July 31, 2020, 2019, and 2018 was $3.8 million, $4.5 million and $2.5 million, respectively.

[0001327567-20-000032:notes:307]
RSU and PSU Activities

[0001327567-20-000032:notes:308]
The following table summarizes the RSU and PSU activity under our stock plans during the years ended July 31, 2020, 2019, and 2018 (in millions, except per share amounts):

[0001327567-20-000032:notes:309]
|  | RSUs Outstanding |  |  |  |  |  |  |  | PSUs Outstanding |  |  |  |  |  |  |
|  | Number of Shares |  | Weighted- Average Grant-Date Fair Value Per Share |  |  |  | Aggregate Intrinsic Value |  | Number of Shares |  | Weighted- Average Grant-Date Fair Value Per Share |  |  |  | Aggregate Intrinsic Value |
| Balance—July 31, 2017 | 6.5 |  |  | $ | 141.16 |  |  |  |  | $ | 854.1 |  |  | — |  |  | $ | — |  |  |  |  | $ | — |  |
| Granted(1) | 3.9 |  |  | $ | 171.74 |  |  |  |  |  |  | 0.2 |  |  | $ | 149.73 |  |  |  |  |  |
| Vested | (3.3) |  |  | $ | 138.93 |  |  |  |  |  |  | — |  |  | $ | — |  |  |  |  |  |
| Forfeited | (0.6) |  |  | $ | 144.33 |  |  |  |  |  |  | — |  |  | $ | — |  |  |  |  |  |
| Balance—July 31, 2018 | 6.5 |  |  | $ | 160.70 |  |  |  |  | $ | 1,291.4 |  |  | 0.2 |  |  | $ | 149.73 |  |  |  |  | $ | 43.7 |  |
| Granted(1)(2) | 3.9 |  |  | $ | 210.14 |  |  |  |  |  |  | 0.2 |  |  | $ | 215.64 |  |  |  |  |  |
| Vested(3) | (2.7) |  |  | $ | 160.87 |  |  |  |  |  |  | (0.1) |  |  | $ | 149.73 |  |  |  |  |  |
| Forfeited | (0.8) |  |  | $ | 162.73 |  |  |  |  |  |  | — |  |  | $ | 155.38 |  |  |  |  |  |
| Balance—July 31, 2019 | 6.9 |  |  | $ | 188.16 |  |  |  |  | $ | 1,554.0 |  |  | 0.3 |  |  | $ | 197.86 |  |  |  |  | $ | 67.0 |  |
| Granted(2) | 3.5 |  |  | $ | 211.38 |  |  |  |  |  |  | 0.4 |  |  | $ | 248.55 |  |  |  |  |  |
| Vested(3) | (2.8) |  |  | $ | 181.19 |  |  |  |  |  |  | (0.1) |  |  | $ | 166.90 |  |  |  |  |  |
| Forfeited | (1.0) |  |  | $ | 188.18 |  |  |  |  |  |  | 0.0 |  |  | $ | 175.88 |  |  |  |  |  |
| Balance—July 31, 2020 | 6.6 |  |  | $ | 203.30 |  |  |  |  | $ | 1,688.1 |  |  | 0.6 |  |  | $ | 231.42 |  |  |  |  | $ | 147.2 |  |

[0001327567-20-000032:notes:310]
(1) For PSUs, shares granted represent the aggregate maximum number of shares that may be earned and issued with respect to these awards over their full terms.

[0001327567-20-000032:notes:311]
(2) Includes 0.1 million RSUs assumed in connection with the acquisitions of Zingbox, Aporeto and CloudGenix, with weighted-average grant-date fair value of $208.25, $231.30 and $181.48, respectively for the year ended July 31, 2020; and includes 0.4 million RSUs assumed and 0.1 million replacement RSUs granted in connection with the acquisitions of RedLock, Demisto, PureSec, and Twistlock, with weighted-average grant-date fair values of $218.69 and $224.31 per share, respectively for the year ended July 31, 2019.

[0001327567-20-000032:notes:312]
(3) Includes time-based vesting for PSUs.

[0001327567-20-000032:notes:313]
The aggregate fair value, as of the respective vesting dates, of RSUs vested during the years ended July 31, 2020, 2019, and 2018 was $615.7 million, $566.4 million, and $546.3 million, respectively. The aggregate fair value, as of the respective vesting dates, of PSUs vested during the year ended July 31, 2020 and 2019 was $11.9 million and $17.2 million.

[0001327567-20-000032:notes:314]
Shares Available for Grant

[0001327567-20-000032:notes:315]
The following table presents the stock activity and the total number of shares available for grant under our stock plans as of July 31, 2020 (in millions):

[0001327567-20-000032:notes:316]
|  | Number of shares |
| Balance—July 31, 2019 | 7.8 |  |
| Authorized | 4.5 |  |
| PSOs, RSUs, and PSUs granted | (3.9) |  |
| Options, PSOs, RSAs, PSAs, RSUs, and PSUs forfeited | 2.0 |  |
| Shares withheld for taxes | 0.1 |  |
| Balance—July 31, 2020 | 10.5 |  |

[0001327567-20-000032:notes:317]
We record share-based compensation awards based on estimated fair value as of the grant date. The fair value of RSUs, PSUs, RSAs, and PSAs is based on the closing market price of our common stock on the date of grant.

[0001327567-20-000032:notes:318]
The fair value of PSOs is estimated on the grant date using a Monte Carlo simulation model, which predicts settlement of the options midway between the vesting term and the contractual term. No new PSOs were granted during the year ended July 31, 2020. The following table summarizes the assumptions used and the resulting grant-date fair values of our PSOs granted during the years ended July 31, 2019 and 2018:

[0001327567-20-000032:notes:319]
|  |  | Year Ended July 31, |  |  |  |
|  |  |  | 2019 |  | 2018 |
| Volatility |  |  | 35.6% - 36.5% |  | 33.3 | % |
| Dividend yield |  |  | — | % |  | — | % |
| Risk-free interest rate |  |  | 3.1% - 3.2% |  | 2.9 | % |
| Weighted-average grant-date fair value per share |  |  | $ | 59.11 |  |  | $ | 56.14 |  |

[0001327567-20-000032:notes:320]
The expected volatility is based on a combination of implied volatility from traded options on our common stock and the historical volatility of our common stock. The dividend yield assumption is based on our current expectations about our anticipated dividend policy. The risk-free interest rate is based on the implied yield available on U.S. Treasury zero-coupon issues with terms equal to the contractual terms of each tranche.

[0001327567-20-000032:notes:321]
The fair value of shares issued under our 2012 ESPP are estimated on the grant date using the Black-Scholes option pricing model. The following table summarizes the assumptions used and the resulting grant-date fair values of our ESPP:

[0001327567-20-000032:notes:322]
|  | Year Ended July 31, |  |  |  |  |
|  | 2020 |  | 2019 |  | 2018 |
| Volatility | 31.0% - 35.7% |  | 30.0% - 34.5% |  | 26.8% - 43.6% |
| Expected term (in years) | 0.5 - 2.0 |  | 0.5 - 2.0 |  | 0.5 - 2.0 |
| Dividend yield | — | % |  | — | % |  | — | % |
| Risk-free interest rate | 0.9% - 1.9% |  | 2.3% - 2.6% |  | 1.2% - 2.3% |
| Grant-date fair value per share | $46.75 - $66.47 |  | $55.03 - $87.04 |  | $34.94 - $65.04 |

[0001327567-20-000032:notes:323]
The expected volatility is based on a combination of implied volatility from traded options on our common stock and the historical volatility of our common stock. The expected term represents the term from the first day of the offering period to the purchase dates within each offering period. The dividend yield assumption is based on our expectations about our anticipated dividend policy. The risk-free interest rate is based on the implied yield available on U.S. Treasury zero-coupon issues with maturities that approximate the expected term.

[0001327567-20-000032:notes:324]
The following table summarizes share-based compensation included in costs and expenses (in millions):

[0001327567-20-000032:notes:325]
|  | Year Ended July 31, |  |  |  |  |
|  | 2020 |  | 2019 |  | 2018 |
| Cost of product revenue | $ | 5.7 |  |  | $ | 5.6 |  |  | $ | 7.0 |  |
| Cost of subscription and support revenue | 77.7 |  |  | 71.3 |  |  | 66.7 |  |
| Research and development | 274.6 |  |  | 186.8 |  |  | 145.2 |  |
| Sales and marketing | 214.5 |  |  | 221.9 |  |  | 208.0 |  |
| General and administrative | 92.0 |  |  | 102.1 |  |  | 77.0 |  |
| Total share-based compensation | $ | 664.5 |  |  | $ | 587.7 |  |  | $ | 503.9 |  |

[0001327567-20-000032:notes:326]
During the year ended July 31, 2020, we accelerated the vesting of certain equity awards in connection with our acquisitions of Zingbox, Aporeto and CloudGenix and recorded $1.3 million, $4.4 million and $0.3 million, respectively, and during the year ended July 31, 2019, we accelerated the vesting of certain equity awards in connection with our acquisitions of RedLock and Twistlock and recorded $14.2 million and $5.8 million, respectively, of share-based compensation within general and administrative expense. During the year ended July 31, 2018, we paid $6.6 million in cash to settle certain Evident.io stock options, for which vesting was accelerated in connection with the acquisition and the subsequent termination of the option holders’ services. This amount was recorded as post-acquisition share-based compensation included in general and administrative expense.
As of July 31, 2020, total compensation cost related to unvested share-based awards not yet recognized was $1.5 billion. This cost is expected to be amortized over a weighted-average period of approximately 2.5 years. Future grants will increase the amount of compensation expense to be recorded in these periods.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001327567-20-000032:notes:327]
The following table presents the components of income (loss) before income taxes (in millions):

[0001327567-20-000032:notes:328]
|  | Year Ended July 31, |  |  |  |  |
|  | 2020 |  | 2019 |  | 2018 |
| United States | $ | (56.1) |  |  | $ | (198.1) |  |  | $ | (181.1) |  |
| Foreign | (175.7) |  |  | 123.5 |  |  | 75.8 |  |
| Total | $ | (231.8) |  |  | $ | (74.6) |  |  | $ | (105.3) |  |

[0001327567-20-000032:notes:329]
The following table summarizes our provision for income taxes (in millions):

[0001327567-20-000032:notes:330]
|  | Year Ended July 31, |  |  |  |  |
|  | 2020 |  | 2019 |  | 2018 |
| Federal: |  |  |  |  |  |
| Current | $ | 3.8 |  |  | $ | (1.3) |  |  | $ | (0.6) |  |
| Deferred | (1.3) |  |  | (11.3) |  |  | (3.3) |  |
| State: |  |  |  |  |  |
| Current | 1.3 |  |  | (0.9) |  |  | 1.6 |  |
| Deferred | 0.1 |  |  | (3.0) |  |  | (1.3) |  |
| Foreign: |  |  |  |  |  |
| Current | 39.2 |  |  | 27.5 |  |  | 23.3 |  |
| Deferred | (7.9) |  |  | (3.7) |  |  | (2.8) |  |
| Total | $ | 35.2 |  |  | $ | 7.3 |  |  | $ | 16.9 |  |

[0001327567-20-000032:notes:331]
For the year ended July 31, 2020, our provision for income taxes increased compared to the year ended July 31, 2019, primarily due to an increase in foreign income as a result of increased business operations and withholding taxes from an increase in billings in the relevant jurisdictions. We also had a change in our valuation allowance related to acquisitions completed during fiscal 2019.

[0001327567-20-000032:notes:332]
For the year ended July 31, 2019, our provision for income taxes decreased compared to the year ended July 31, 2018, primarily due to changes in our valuation allowance related to acquisitions completed during fiscal 2019 and our adoption of accounting guidance requiring the recognition of income tax consequences of an intra-entity transfer of an asset, other than inventory, when the transfer occurs. These decreases were partially offset by an increase in our foreign taxes due to growth in non-U.S. operations.

[0001327567-20-000032:notes:333]
The following table presents the items accounting for the difference between income taxes computed at the federal statutory income tax rate and our provision for income taxes:

[0001327567-20-000032:notes:334]
|  | Year Ended July 31, |  |  |  |  |
|  | 2020 |  | 2019 |  | 2018 |
| Federal statutory rate | 21.0 | % |  | 21.0 | % |  | 26.8 | % |
| Effect of: |  |  |  |  |  |
| State taxes, net of federal tax benefit | 3.0 |  |  | 7.9 |  |  | 5.7 |  |
| Effects of non-U.S. operations | 667.5 |  |  | 89.3 |  |  | 19.9 |  |
| Change in valuation allowance | (714.1) |  |  | (196.9) |  |  | 39.2 |  |
| Effect of U.S. tax law change | — |  |  | 0.6 |  |  | (129.3) |  |
| Share-based compensation | (5.1) |  |  | 44.9 |  |  | 10.6 |  |
| Amortization of deferred tax charges | — |  |  | — |  |  | (8.0) |  |
| Research credits | 17.9 |  |  | 35.0 |  |  | 31.4 |  |
| Non-deductible expenses | (3.9) |  |  | (11.5) |  |  | (6.1) |  |
| Other, net | (1.5) |  |  | (0.1) |  |  | (6.2) |  |
| Total | (15.2) | % |  | (9.8) | % |  | (16.0) | % |

[0001327567-20-000032:notes:335]
In December 2019, we transferred certain intellectual property rights to a wholly owned United Kingdom subsidiary, primarily to align our legal structure to our evolving operations. The tax benefit from an increase in the tax basis of intellectual property rights resulted in an increase in effects of non-U.S. operations and was fully offset by a full valuation.

[0001327567-20-000032:notes:336]
The following table presents the components of our deferred tax assets and liabilities as of July 31, 2020 and July 31, 2019 (in millions):

[0001327567-20-000032:notes:337]
|  | July 31, |  |  |
|  | 2020 |  | 2019 |
| Deferred tax assets: |  |  |  |
| Accruals and reserves | $ | 116.5 |  |  | $ | 53.3 |  |
| Deferred revenue | 272.5 |  |  | 212.8 |  |
| Net operating loss carryforwards | 348.0 |  |  | 269.9 |  |
| Research and development and foreign tax credits | 179.6 |  |  | 143.3 |  |
| Share-based compensation | 33.7 |  |  | 25.9 |  |
| Fixed assets and intangible assets | 1,458.8 |  |  | — |  |
| Gross deferred tax assets | 2,409.1 |  |  | 705.2 |  |
| Valuation allowance | (2,240.4) |  |  | (561.9) |  |
| Total deferred tax assets | 168.7 |  |  | 143.3 |  |
| Deferred tax liabilities: |  |  |  |
| Fixed assets and intangible assets | — |  |  | (26.0) |  |
| Deferred commissions | (130.8) |  |  | (94.6) |  |
| Other deferred tax liabilities | (28.9) |  |  | (15.7) |  |
| Total deferred tax liabilities | (159.7) |  |  | (136.3) |  |
| Net deferred tax assets | $ | 9.0 |  |  | $ | 7.0 |  |

[0001327567-20-000032:notes:338]
Our increase in deferred tax assets relating to fixed assets and intangibles is largely due to transferring our intellectual property rights to a wholly owned United Kingdom subsidiary, primarily to align our legal structure to our evolving operations. This resulted in an increase in the tax basis of these intellectual property rights and a corresponding increase in foreign deferred tax assets. As of July 31, 2020, it is not more likely than not that these additional deferred tax assets will be realizable, and therefore, are offset by a full valuation allowance.

[0001327567-20-000032:notes:339]
A valuation allowance is provided when it is more likely than not that the deferred tax asset will not be realized. Realization of deferred tax assets is dependent upon future taxable income, if any, the amount and timing of which are uncertain. At such time, if it is determined that it is more likely than not that the deferred tax assets are realizable, the valuation allowance will be adjusted. As of July 31, 2020, we have provided a valuation allowance for our federal, state, UK and certain other foreign deferred tax assets that we

[0001327567-20-000032:notes:340]
believe will, more likely than not, be unrealizable. The net valuation allowance increased by $1.7 billion from the year ended July 31, 2019 to the year ended July 31, 2020, primarily due to an increase in intangible tax basis as discussed above.

[0001327567-20-000032:notes:341]
As of July 31, 2020, we had federal, state, and foreign NOL carryforwards of approximately $1.6 billion, $0.7 billion, and $0.6 billion, respectively, as reported on our tax returns, available to reduce future taxable income, if any. If not utilized, our federal and state NOL carryforwards will expire in various amounts at various dates beginning in the years ending July 31, 2027 and July 31, 2021, respectively. Our foreign NOL will carry forward indefinitely.

[0001327567-20-000032:notes:342]
As of July 31, 2020, we had federal and state research and development tax credit carryforwards of approximately $116.9 million and $105.7 million, respectively, as reported on our tax returns. If not utilized, the federal credit carryforwards will expire in various amounts at various dates beginning in the year ending July 31, 2026. The state credit will carry forward indefinitely.

[0001327567-20-000032:notes:343]
As of July 31, 2020, we had foreign tax credit carryforwards of $3.7 million as reported on our tax returns. If not utilized, the foreign tax credit carryforwards will expire in various amounts at various dates beginning in the year ending July 31, 2021.

[0001327567-20-000032:notes:344]
Utilization of the NOL carryforwards and credits may be subject to a substantial annual limitation due to the ownership change limitations provided by the Internal Revenue Code of 1986, as amended, and similar state provisions. The annual limitation may result in the expiration of NOLs and credits before utilization.

[0001327567-20-000032:notes:345]
As of July 31, 2020, we had $326.4 million of unrecognized tax benefits, $63.9 million of which would affect income tax expense if recognized, after consideration of our valuation allowance in the United States and other assets. As of July 31, 2019, we had $314.5 million of unrecognized tax benefits, $68.0 million of which would affect income tax expense if recognized, after consideration of our valuation allowance in the United States and other assets. As of July 31, 2020, our federal, state, and foreign returns for the tax years 2009 through the current period remain subject to adjustment due to current and future examinations. Fiscal years outside the normal statute of limitation remain open to audit by tax authorities due to tax attributes generated in earlier years, which have been carried forward and may be audited in subsequent years when utilized. We do not expect the amount of unrecognized tax benefits as of July 31, 2020 to change significantly over the next 12 months. We recognize both interest and penalties associated with uncertain tax positions as a component of income tax expense. During the years ended July 31, 2020, 2019, and 2018, we recognized income tax expense related to interest and penalties of $1.6 million, $2.3 million, and $2.9 million, respectively. We had accrued interest and penalties on our consolidated balance sheets related to unrecognized tax benefits of $12.2 million and $10.6 million as of July 31, 2020 and 2019, respectively. The ultimate amount and timing of any future cash settlements cannot be predicted with reasonable certainty.

[0001327567-20-000032:notes:346]
The following table presents a reconciliation of the beginning and ending amount of our gross unrecognized tax benefits (in millions):

[0001327567-20-000032:notes:347]
|  | Year Ended July 31, |  |  |  |  |
|  | 2020 |  | 2019 |  | 2018 |
| Unrecognized tax benefits at the beginning of the period | $ | 314.5 |  |  | $ | 337.7 |  |  | $ | 301.3 |  |
| Additions for tax positions taken in prior years | 3.2 |  |  | 0.3 |  |  | 3.1 |  |
| Reductions for tax positions taken in prior years | (1.6) |  |  | (33.4) |  |  | (6.3) |  |
| Additions for tax positions taken in the current year | 10.3 |  |  | 9.9 |  |  | 39.6 |  |
| Unrecognized tax benefits at the end of the period | $ | 326.4 |  |  | $ | 314.5 |  |  | $ | 337.7 |  |

[0001327567-20-000032:notes:348]
During the years ended July 31, 2020 and July 31, 2019, our additions for tax positions taken in the given year were primarily attributable to intercompany transactions.

[0001327567-20-000032:notes:349]
During the year ended July 31, 2018, our additions for tax positions taken in the current year were primarily attributable to uncertain tax positions related to federal and state research and development credits, withholding taxes, and intercompany transactions.
As of July 31, 2020, we had no unremitted earnings when evaluating our outside basis difference relating to our U.S. investment in foreign subsidiaries. However, there could be local withholding taxes payable due to various foreign countries if certain lower tier earnings are distributed. Withholding taxes that would be payable upon remittance of these lower tier earnings are not material.


## us-gaap:EarningsPerShareTextBlock

[0001327567-20-000032:notes:350]
Net Loss Per Share Basic net loss per share is computed by dividing net loss by basic weighted-average shares outstanding during the period. Diluted net loss per share is computed by dividing net loss by diluted weighted-average shares outstanding, including potentially dilutive securities.
The following table presents the computation of basic and diluted net loss per share of common stock (in millions, except per share data):

[0001327567-20-000032:notes:351]
|  | Year Ended July 31, |  |  |  |  |
|  | 2020 |  | 2019 |  | 2018 |
| Net loss | $ | (267.0) |  |  | $ | (81.9) |  |  | $ | (122.2) |  |
| Weighted-average shares used to compute net loss per share, basic and diluted | 96.9 |  |  | 94.5 |  |  | 91.7 |
| Net loss per share, basic and diluted | $ | (2.76) |  |  | $ | (0.87) |  |  | $ | (1.33) |  |

[0001327567-20-000032:notes:352]
The following securities were excluded from the computation of diluted net loss per share of common stock for the periods presented as their effect would have been antidilutive (in millions):

[0001327567-20-000032:notes:353]
|  | Year Ended July 31, |  |  |  |  |
|  | 2020 |  | 2019 |  | 2018 |
| Convertible senior notes | 13.1 |  |  | 6.4 |  |  | 11.6 |  |
| Warrants related to the issuance of convertible senior notes | 13.1 |  |  | 11.6 |  |  | 11.6 |  |
| RSUs and PSUs | 7.2 |  |  | 7.2 |  |  | 6.7 |  |
| Options to purchase common stock, including PSOs | 2.9 |  |  | 4.0 |  |  | 2.2 |  |
| RSAs and PSAs | 0.1 |  |  | 0.1 |  |  | 0.3 |  |
| ESPP shares | 0.3 |  |  | 0.2 |  |  | 0.2 |  |
| Total | 36.7 |  |  | 29.5 |  |  | 32.6 |  |


## us-gaap:OtherNonoperatingIncomeAndExpenseTextBlock

[0001327567-20-000032:notes:354]
Other Income, Net
The following table sets forth the components of other income, net (in millions):

[0001327567-20-000032:notes:355]
|  | Year Ended July 31, |  |  |  |  |
|  | 2020 |  | 2019 |  | 2018 |
| Interest income | $ | 41.4 |  |  | $ | 69.8 |  |  | $ | 27.1 |  |
| Foreign currency exchange gains (losses), net | (6.7) |  |  | (3.5) |  |  | 1.7 |  |
| Other | 1.2 |  |  | (2.9) |  |  | (0.3) |  |
| Total other income, net | $ | 35.9 |  |  | $ | 63.4 |  |  | $ | 28.5 |  |


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0001327567-20-000032:notes:356]
Employee Benefit PlanWe have established a 401(k) tax-deferred savings plan which permits participants to make contributions by salary deduction pursuant to Section 401(k) of the Internal Revenue Code. We make matching contributions based upon the amount of employees’ contributions, subject to certain limitations. Our matching contributions to the plan were immaterial for the years ended July 31, 2020, 2019, and 2018.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001327567-20-000032:notes:357]
Segment InformationWe conduct business globally and are primarily managed on a geographic theater basis. Our chief operating decision maker reviews financial information presented on a consolidated basis accompanied by information about revenue by geographic region for purposes of allocating resources and evaluating financial performance. We have one business activity and there are no segment managers who are held accountable for operations, operating results, and plans for levels, components, or types of products or services below the consolidated unit level. Accordingly, we are considered to be in a single reportable segment and operating unit structure.
The following table presents our long-lived assets, which consist of property and equipment, net and operating lease right-of-use assets, by geographic region (in millions):

[0001327567-20-000032:notes:358]
|  | Year Ended July 31, |  |  |
|  | 2020 |  | 2019 |
| Long-lived assets: |  |  |  |
| United States | $ | 502.3 |  |  | $ | 240.5 |  |
| International | 104.5 |  |  | 55.5 |  |
| Total long-lived assets | $ | 606.8 |  |  | $ | 296.0 |  |

[0001327567-20-000032:notes:359]
Refer to Note 2. Revenue for revenue by geographic theater and revenue for groups of similar products and services for the years ended July 31, 2020, 2019, and 2018.


## us-gaap:QuarterlyFinancialInformationTextBlock

[0001327567-20-000032:notes:360]
Selected Quarterly Financial Data (Unaudited)
The following tables set forth selected unaudited quarterly financial data for the years ended July 31, 2020 and 2019 (in millions, except per share amounts):

[0001327567-20-000032:notes:361]
|  | Three Months Ended |  |  |  |  |  |  |
|  | October 31,2019 |  | January 31,2020 |  | April 30,2020 |  | July 31,2020 |
| Revenue: |  |  |  |  |  |  |  |
| Product | $ | 231.2 |  |  | $ | 246.5 |  |  | $ | 280.9 |  |  | $ | 305.6 |  |
| Subscription and support | 540.7 |  |  | 570.2 |  |  | 588.5 |  |  | 644.8 |  |
| Total revenue | 771.9 |  |  | 816.7 |  |  | 869.4 |  |  | 950.4 |  |
| Cost of revenue: |  |  |  |  |  |  |  |
| Product | 65.1 |  |  | 68.7 |  |  | 73.3 |  |  | 87.3 |  |
| Subscription and support | 152.6 |  |  | 164.4 |  |  | 185.0 |  |  | 203.1 |  |
| Total cost of revenue | 217.7 |  |  | 233.1 |  |  | 258.3 |  |  | 290.4 |  |
| Total gross profit | 554.2 |  |  | 583.6 |  |  | 611.1 |  |  | 660.0 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 170.5 |  |  | 185.4 |  |  | 196.3 |  |  | 215.9 |  |
| Sales and marketing | 365.7 |  |  | 374.9 |  |  | 388.4 |  |  | 391.2 |  |
| General and administrative | 69.8 |  |  | 76.2 |  |  | 82.9 |  |  | 70.7 |  |
| Total operating expenses | 606.0 |  |  | 636.5 |  |  | 667.6 |  |  | 677.8 |  |
| Operating loss | (51.8) |  |  | (52.9) |  |  | (56.5) |  |  | (17.8) |  |
| Interest expense | (18.9) |  |  | (19.0) |  |  | (19.4) |  |  | (31.4) |  |
| Other income, net | 16.2 |  |  | 10.8 |  |  | 8.1 |  |  | 0.8 |  |
| Loss before income taxes | (54.5) |  |  | (61.1) |  |  | (67.8) |  |  | (48.4) |  |
| Provision for income taxes | 5.1 |  |  | 12.6 |  |  | 7.0 |  |  | 10.5 |  |
| Net loss | $ | (59.6) |  |  | $ | (73.7) |  |  | $ | (74.8) |  |  | $ | (58.9) |  |
| Net loss per share, basic and diluted | $ | (0.62) |  |  | $ | (0.75) |  |  | $ | (0.77) |  |  | $ | (0.61) |  |

[0001327567-20-000032:notes:362]
|  | Three Months Ended |  |  |  |  |  |  |
|  | October 31,2018 |  | January 31,2019 |  | April 30,2019 |  | July 31,2019 |
| Revenue: |  |  |  |  |  |  |  |
| Product | $ | 240.5 |  |  | $ | 271.6 |  |  | $ | 278.4 |  |  | $ | 305.7 |  |
| Subscription and support | 415.5 |  |  | 439.6 |  |  | 448.2 |  |  | 500.1 |  |
| Total revenue | 656.0 |  |  | 711.2 |  |  | 726.6 |  |  | 805.8 |  |
| Cost of revenue: |  |  |  |  |  |  |  |
| Product | 73.2 |  |  | 82.5 |  |  | 78.0 |  |  | 82.2 |  |
| Subscription and support | 110.3 |  |  | 120.1 |  |  | 126.9 |  |  | 135.2 |  |
| Total cost of revenue | 183.5 |  |  | 202.6 |  |  | 204.9 |  |  | 217.4 |  |
| Total gross profit | 472.5 |  |  | 508.6 |  |  | 521.7 |  |  | 588.4 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 113.4 |  |  | 128.3 |  |  | 139.1 |  |  | 158.7 |  |
| Sales and marketing | 314.6 |  |  | 320.0 |  |  | 339.0 |  |  | 370.4 |  |
| General and administrative | 76.6 |  |  | 53.7 |  |  | 62.3 |  |  | 69.2 |  |
| Total operating expenses | 504.6 |  |  | 502.0 |  |  | 540.4 |  |  | 598.3 |  |
| Operating income (loss) | (32.1) |  |  | 6.6 |  |  | (18.7) |  |  | (9.9) |  |
| Interest expense | (22.7) |  |  | (20.6) |  |  | (20.6) |  |  | (20.0) |  |
| Other income, net | 13.0 |  |  | 16.0 |  |  | 18.2 |  |  | 16.2 |  |
| Income (loss) before income taxes | (41.8) |  |  | 2.0 |  |  | (21.1) |  |  | (13.7) |  |
| Provision for (benefit from) income taxes | (3.5) |  |  | 4.6 |  |  | (0.9) |  |  | 7.1 |  |
| Net loss | $ | (38.3) |  |  | $ | (2.6) |  |  | $ | (20.2) |  |  | $ | (20.8) |  |
| Net loss per share, basic and diluted | $ | (0.41) |  |  | $ | (0.03) |  |  | $ | (0.21) |  |  | $ | (0.22) |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001327567-20-000032:notes:363]
Related Party TransactionsCertain members of our board of directors are affiliated with Greylock Partners (“Greylock”), a venture capital firm. Entities affiliated with Greylock owned a portion of the outstanding shares of Demisto immediately prior to completion of our acquisition of Demisto on March 28, 2019 and, as a result, received purchase consideration valued at $85.6 million during the year ended July 31, 2019. Refer to Note 6. Acquisitions for more information on our acquisition of Demisto.


## us-gaap:SubsequentEventsTextBlock

[0001327567-20-000032:notes:364]
Subsequent Event
Business Combination

[0001327567-20-000032:notes:365]
In August 2020, we entered into a definitive agreement to acquire The Crypsis Group, an incident response, risk management and digital forensics consulting firm, in exchange for total consideration of $265.0 million in cash, subject to adjustments. We expect the acquisition will expand our capabilities and strengthen our Cortex strategy. The acquisition is expected to close during our first quarter of fiscal 2021, subject to regulatory approvals and other customary closing conditions.
