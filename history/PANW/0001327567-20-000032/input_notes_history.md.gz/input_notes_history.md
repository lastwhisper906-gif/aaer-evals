# PANW note change history — 0001327567-20-000007 → 0001327567-20-000017


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2020-05-22):
[0001327567-20-000017:note_history:1]
Our electronics manufacturing service provider (“EMS provider”) procures components and assembles our products based on our forecasts. These forecasts are based on estimates of demand for our products primarily for the next 12 months, which are in turn based on historical trends and an analysis from our sales and product management organizations, adjusted for overall market conditions. In order to reduce manufacturing lead times and plan for adequate supply, we may issue non-cancelable orders for products and components to our manufacturing partners or component suppliers. As of April 30, 2020, our purchase commitments under such orders were $124.3 million excluding obligations under contracts that we can cancel without a significant penalty.
  (was, 2020-02-25, similarity 0.9912):
[0001327567-20-000007:note_history:1]
Our electronics manufacturing service provider (“EMS provider”) procures components and assembles our products based on our forecasts. These forecasts are based on estimates of demand for our products primarily for the next 12 months, which are in turn based on historical trends and an analysis from our sales and product management organizations, adjusted for overall market conditions. In order to reduce manufacturing lead times and plan for adequate supply, we may issue non-cancelable orders for products and components to our manufacturing partners or component suppliers. As of January 31, 2020, our purchase commitments under such orders were $106.0 million, excluding obligations under contracts that we can cancel without a significant penalty.

- changed (2020-05-22):
[0001327567-20-000017:note_history:2]
We have entered into various non-cancelable agreements with third-party providers for our use of certain cloud and other services, under which we are committed to minimum or fixed purchases through the year ending July 31, 2026. The following table presents details of the aggregate future non-cancelable purchase commitments under these agreements as of April 30, 2020 (in millions):
  (was, 2020-02-25, similarity 0.984):
[0001327567-20-000007:note_history:2]
We have entered into various non-cancelable agreements with third-party providers for our use of certain cloud and other services, under which we are committed to minimum or fixed purchases through the year ending July 31, 2026. The following table presents details of the aggregate future non-cancelable purchase commitments under these agreements as of January 31, 2020 (in millions):

- changed (2020-05-22):
[0001327567-20-000017:note_history:3]
In January 2020, we executed a Mutual Covenant Not to Sue and Release Agreement for $50.0 million, to extend an existing covenant not to sue for seven years. As the primary benefit of the arrangement was attributable to future use, the amount was recorded in other assets on our condensed consolidated balance sheets and is amortized to cost of product revenue in our condensed consolidated statements of operations over the estimated period of benefit of seven years. This amount was paid in the three months ended April 30, 2020.
  (was, 2020-02-25, similarity 0.6782):
[0001327567-20-000007:note_history:3]
In January 2020, we executed a Mutual Covenant Not to Sue and Release Agreement for $50.0 million, to extend an existing covenant not to sue for seven years. As the primary benefit of the arrangement was attributable to future use, we recorded $50.0 million in other assets and a corresponding balance in accrued and other liabilities on our condensed consolidated balance sheets as of January 31, 2020. The amount recorded in other assets will be amortized to cost of product revenue in our condensed consolidated statements of operations over the estimated period of benefit of seven years.

- added (2020-05-22):
[0001327567-20-000017:note_history:4]
To the extent there is a reasonable possibility that a loss exceeding amounts already recognized may be incurred and the amount of such additional loss would be material, we will either disclose the estimated additional loss or state that such an estimate cannot be made. As of April 30, 2020, we have not recorded any significant accruals for loss contingencies associated with such legal proceedings, determined that an unfavorable outcome is probable or reasonably possible, or determined that the amount or range of any possible loss is reasonably estimable.

- removed (2020-05-22):
[0001327567-20-000007:note_history:5]
To the extent there is a reasonable possibility that a loss exceeding amounts already recognized may be incurred and the amount of such additional loss would be material, we will either disclose the estimated additional loss or state that such an estimate cannot be made. As of January 31, 2020, we have not recorded any significant accruals for loss contingencies associated with such legal proceedings, determined that an unfavorable outcome is probable or reasonably possible, or determined that the amount or range of any possible loss is reasonably estimable.


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2020-05-22):
[0001327567-20-000017:note_history:6]
Use of Estimates

- added (2020-05-22):
[0001327567-20-000017:note_history:7]
The preparation of condensed consolidated financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the consolidated financial statements and the reported amounts of revenues and expenses during the reporting period. We base our estimates on historical experience and also on assumptions that we believe are reasonable. Actual results could differ materially from those estimates due to risks and uncertainties, including uncertainty in the current economic environment due to the recent outbreak of COVID-19.

- changed (2020-05-22):
[0001327567-20-000017:note_history:8]
There have been no material changes to our significant accounting policies as of and for the nine months ended April 30, 2020, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended July 31, 2019, except for the change in our accounting policies for leases due to our adoption of new lease accounting guidance. Refer to “Recently Adopted Accounting Pronouncements” below and Note 10. Leases and Other Office Facilities.
  (was, 2020-02-25, similarity 0.9485):
[0001327567-20-000007:note_history:8]
There have been no material changes to our significant accounting policies as of and for the six months ended January 31, 2020, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended July 31, 2019, except for the change in our accounting policies for leases due to our adoption of new lease accounting guidance. Refer to “Recently Adopted Accounting Pronouncements” below and Note 10. Leases.

- changed (2020-05-22):
[0001327567-20-000017:note_history:9]
The adoption of this standard had no impact on our condensed consolidated statements of operations and condensed consolidated statements of cash flows. Refer to Note 10. Leases and Other Office Facilities for further discussion.
  (was, 2020-02-25, similarity 0.934):
[0001327567-20-000007:note_history:9]
The adoption of this standard had no impact on our condensed consolidated statements of operations and condensed consolidated statements of cash flows. Refer to Note 10. Leases for further discussion.

- changed (2020-05-22):
[0001327567-20-000017:note_history:10]
In June 2016, the FASB issued new authoritative guidance on the accounting for credit losses on most financial assets and certain financial instruments. The standard replaces the existing incurred loss model with an expected credit loss model for financial assets measured at amortized cost, including trade receivables, and requires that credit losses on available-for-sale debt securities be presented as an allowance rather than as a write-down. The standard is effective for us in our first quarter of fiscal 2021 and will be applied on a modified retrospective basis. We are currently evaluating whether this standard will have a material impact on our condensed consolidated financial statements.
  (was, 2020-02-25, similarity 0.7775):
[0001327567-20-000007:note_history:10]
assets measured at amortized cost, including trade receivables, and requires that credit losses on available-for-sale debt securities be presented as an allowance rather than as a write-down. The standard is effective for us in our first quarter of fiscal 2021 and will be applied on a modified retrospective basis. We are currently evaluating whether this standard will have a material impact on our condensed consolidated financial statements.

- removed (2020-05-22):
[0001327567-20-000007:note_history:11]
In June 2016, the FASB issued new authoritative guidance on the accounting for credit losses on most financial assets and certain financial instruments. The standard replaces the existing incurred loss model with an expected credit loss model for financial


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2020-05-22):
[0001327567-20-000017:note_history:12]
Use of Estimates

- added (2020-05-22):
[0001327567-20-000017:note_history:13]
The preparation of condensed consolidated financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the consolidated financial statements and the reported amounts of revenues and expenses during the reporting period. We base our estimates on historical experience and also on assumptions that we believe are reasonable. Actual results could differ materially from those estimates due to risks and uncertainties, including uncertainty in the current economic environment due to the recent outbreak of COVID-19.

- changed (2020-05-22):
[0001327567-20-000017:note_history:14]
There have been no material changes to our significant accounting policies as of and for the nine months ended April 30, 2020, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended July 31, 2019, except for the change in our accounting policies for leases due to our adoption of new lease accounting guidance. Refer to “Recently Adopted Accounting Pronouncements” below and Note 10. Leases and Other Office Facilities.
  (was, 2020-02-25, similarity 0.9485):
[0001327567-20-000007:note_history:14]
There have been no material changes to our significant accounting policies as of and for the six months ended January 31, 2020, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended July 31, 2019, except for the change in our accounting policies for leases due to our adoption of new lease accounting guidance. Refer to “Recently Adopted Accounting Pronouncements” below and Note 10. Leases.


## us-gaap:ConvertibleDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-05-22):
[0001327567-20-000017:note_history:15]
The following table sets forth the components of the 2023 Notes as of April 30, 2020 and July 31, 2019 (in millions):
  (was, 2020-02-25, similarity 0.9619):
[0001327567-20-000007:note_history:15]
The following table sets forth the components of the 2023 Notes as of January 31, 2020 and July 31, 2019 (in millions):

- changed (2020-05-22):
[0001327567-20-000017:note_history:16]
|  | April 30, 2020 |  | July 31, 2019 |
| Liability component: |  |  |  |
| Principal | $ | 1,693.0 |  |  | $ | 1,693.0 |  |
| Less: debt discount and debt issuance costs, net of amortization | 216.0 |  |  | 263.0 |  |
| Net carrying amount | $ | 1,477.0 |  |  | $ | 1,430.0 |  |
| Equity component | $ | 315.0 |  |  | $ | 315.0 |  |
  (was, 2020-02-25, similarity 0.944):
[0001327567-20-000007:note_history:16]
|  | January 31, 2020 |  | July 31, 2019 |
| Liability component: |  |  |  |
| Principal | $ | 1,693.0 |  |  | $ | 1,693.0 |  |
| Less: debt discount and debt issuance costs, net of amortization | 231.8 |  |  | 263.0 |  |
| Net carrying amount | $ | 1,461.2 |  |  | $ | 1,430.0 |  |
| Equity component | $ | 315.0 |  |  | $ | 315.0 |  |


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-05-22):
[0001327567-20-000017:note_history:17]
In June 2014, we issued $575.0 million aggregate principal amount of 0.0% Convertible Senior Notes due 2019 (the “2019 Notes”), and in July 2018, we issued $1.7 billion aggregate principal amount of 0.75% Convertible Senior Notes due 2023 (the “2023 Notes” and, together with the 2019 Notes, the “Notes”). The 2023 Notes bear interest at a fixed rate of 0.75% per year, payable semi-annually in arrears on January 1 and July 1 of each year, beginning on January 1, 2019. The 2023 Notes are governed by an indenture
  (was, 2020-02-25, similarity 0.6184):
[0001327567-20-000007:note_history:17]
In June 2014, we issued $575.0 million aggregate principal amount of 0.0% Convertible Senior Notes due 2019 (the “2019 Notes”), and in July 2018, we issued $1.7 billion aggregate principal amount of 0.75% Convertible Senior Notes due 2023 (the “2023 Notes” and, together with the 2019 Notes, the “Notes”). The 2023 Notes bear interest at a fixed rate of 0.75% per year, payable semi-annually in arrears on January 1 and July 1 of each year, beginning on January 1, 2019. The 2023 Notes are governed by an indenture between us, as the issuer, and U.S. Bank National Association, as Trustee (the “Indenture”). The 2023 Notes are unsecured, unsubordinated obligations and the Indenture governing the 2023 Notes does not contain any financial covenants or restrictions on the payments of dividends, the incurrence of indebtedness, or the issuance or repurchase of securities by us or any of our subsidiaries. The 2019 Notes were converted prior to or settled on the maturity date of July 1, 2019, in accordance with their terms. The 2023 Notes mature on July 1, 2023. We cannot redeem the 2023 Notes prior to maturity.

- added (2020-05-22):
[0001327567-20-000017:note_history:18]
between us, as the issuer, and U.S. Bank National Association, as Trustee (the “Indenture”). The 2023 Notes are unsecured, unsubordinated obligations and the Indenture governing the 2023 Notes does not contain any financial covenants or restrictions on the payments of dividends, the incurrence of indebtedness, or the issuance or repurchase of securities by us or any of our subsidiaries. The 2019 Notes were converted prior to or settled on the maturity date of July 1, 2019, in accordance with their terms. The 2023 Notes mature on July 1, 2023. We cannot redeem the 2023 Notes prior to maturity.

- changed (2020-05-22):
[0001327567-20-000017:note_history:19]
•during any fiscal quarter commencing after the fiscal quarter ending on October 31, 2018 (and only during such fiscal quarter), if the last reported sale price of our common stock for at least 20 trading days (whether or not consecutive) during a period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the applicable conversion price for the 2023 Notes on each applicable trading day (the “sale price condition”);
  (was, 2020-02-25, similarity 0.993):
[0001327567-20-000007:note_history:19]
| • | during any fiscal quarter commencing after the fiscal quarter ending on October 31, 2018 (and only during such fiscal quarter), if the last reported sale price of our common stock for at least 20 trading days (whether or not consecutive) during a period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the applicable conversion price for the 2023 Notes on each applicable trading day (the “sale price condition”); |

- changed (2020-05-22):
[0001327567-20-000017:note_history:20]
•during the five business day period after any five consecutive trading day period (the “measurement period”), in which the trading price per $1,000 principal amount of the 2023 Notes for each trading day of the measurement period was less than 98% of the product of the last reported sale price of our common stock and the applicable conversion rate for the 2023 Notes on each such trading day; or
  (was, 2020-02-25, similarity 0.991):
[0001327567-20-000007:note_history:20]
| • | during the five business day period after any five consecutive trading day period (the “measurement period”), in which the trading price per $1,000 principal amount of the 2023 Notes for each trading day of the measurement period was less than 98% of the product of the last reported sale price of our common stock and the applicable conversion rate for the 2023 Notes on each such trading day; or |

- changed (2020-05-22):
[0001327567-20-000017:note_history:21]
•upon the occurrence of specified corporate events.
  (was, 2020-02-25, similarity 0.9358):
[0001327567-20-000007:note_history:21]
| • | upon the occurrence of specified corporate events. |

- changed (2020-05-22):
[0001327567-20-000017:note_history:22]
The sale price condition was not met for the 2023 Notes during the fiscal quarters ended April 30, 2020 or July 31, 2019. Since the 2023 Notes were not convertible, the net carrying amount of the 2023 Notes was classified as a long-term liability and the equity component was included in additional paid-in capital in our condensed consolidated balance sheets as of April 30, 2020 and July 31, 2019. As of April 30, 2020, all of the 2023 Notes remained outstanding.
  (was, 2020-02-25, similarity 0.6929):
[0001327567-20-000007:note_history:22]
The sale price condition was not met for the 2023 Notes during the fiscal quarters ended January 31, 2020 or July 31, 2019. Since the 2023 Notes were not convertible, the net carrying amount of the 2023 Notes was classified as a long-term liability and the

- changed (2020-05-22):
[0001327567-20-000017:note_history:23]
The following table sets forth the components of the 2023 Notes as of April 30, 2020 and July 31, 2019 (in millions):
  (was, 2020-02-25, similarity 0.9619):
[0001327567-20-000007:note_history:23]
The following table sets forth the components of the 2023 Notes as of January 31, 2020 and July 31, 2019 (in millions):

- changed (2020-05-22):
[0001327567-20-000017:note_history:24]
|  | April 30, 2020 |  | July 31, 2019 |
| Liability component: |  |  |  |
| Principal | $ | 1,693.0 |  |  | $ | 1,693.0 |  |
| Less: debt discount and debt issuance costs, net of amortization | 216.0 |  |  | 263.0 |  |
| Net carrying amount | $ | 1,477.0 |  |  | $ | 1,430.0 |  |
| Equity component | $ | 315.0 |  |  | $ | 315.0 |  |
  (was, 2020-02-25, similarity 0.944):
[0001327567-20-000007:note_history:24]
|  | January 31, 2020 |  | July 31, 2019 |
| Liability component: |  |  |  |
| Principal | $ | 1,693.0 |  |  | $ | 1,693.0 |  |
| Less: debt discount and debt issuance costs, net of amortization | 231.8 |  |  | 263.0 |  |
| Net carrying amount | $ | 1,461.2 |  |  | $ | 1,430.0 |  |
| Equity component | $ | 315.0 |  |  | $ | 315.0 |  |

- added (2020-05-22):
[0001327567-20-000017:note_history:25]
The total estimated fair value of the 2023 Notes was $1.7 billion and $1.9 billion at April 30, 2020 and July 31, 2019, respectively. The fair value was determined based on the closing trading price per $100 of the 2023 Notes as of the last day of trading for the period. We consider the fair value of the 2023 Notes at April 30, 2020 and July 31, 2019 to be a Level 2 measurement. The fair value of the 2023 Notes is primarily affected by the trading price of our common stock and market interest rates. Based on the closing price of our common stock on April 30, 2020, the if-converted value of the 2023 Notes was less than its principal amount.

- changed (2020-05-22):
[0001327567-20-000017:note_history:26]
|  | Three Months Ended April 30, |  |  |  |  |  |  |  |  |  |  |  | Nine Months Ended April 30, |  |  |  |  |  |  |  |  |  |  |
|  | 2020 |  |  |  |  |  | 2019 |  |  |  |  |  | 2020 |  |  |  |  |  | 2019 |  |  |  |  |
|  | 2019 Notes |  | 2023 Notes |  | Total |  | 2019 Notes |  | 2023 Notes |  | Total |  | 2019 Notes |  | 2023 Notes |  | Total |  | 2019 Notes |  | 2023 Notes |  | Total |
| Contractual interest expense | $ | — |  |  | $ | 3.2 |  |  | $ | 3.2 |  |  | $ | — |  |  | $ | 3.3 |  |  | $ | 3.3 |  |  | $ | — |  |  | $ | 9.5 |  |  | $ | 9.5 |  |  | $ | — |  |  | $ | 9.6 |  |  | $ | 9.6 |  |
| Amortization of debt discount | — |  |  | 15.3 |  |  | 15.3 |  |  | 1.6 |  |  | 14.7 |  |  | 16.3 |  |  | — |  |  | 45.5 |  |  | 45.5 |  |  | 7.6 |  |  | 43.6 |  |  | 51.2 |  |
| Amortization of debt issuance costs | — |  |  | 0.5 |  |  | 0.5 |  |  | 0.3 |  |  | 0.5 |  |  | 0.8 |  |  | — |  |  | 1.5 |  |  | 1.5 |  |  | 1.0 |  |  | 1.4 |  |  | 2.4 |  |
| Total interest expense recognized | $ | — |  |  | $ | 19.0 |  |  | $ | 19.0 |  |  | $ | 1.9 |  |  | $ | 18.5 |  |  | $ | 20.4 |  |  | $ | — |  |  | $ | 56.5 |  |  | $ | 56.5 |  |  | $ | 8.6 |  |  | $ | 54.6 |  |  | $ | 63.2 |  |
| Effective interest rate of the liability component | — | % |  | 5.2 | % |  |  |  | 4.8 | % |  | 5.2 | % |  |  |  | — | % |  | 5.2 | % |  |  |  | 4.8 | % |  | 5.2 | % |  |  |
  (was, 2020-02-25, similarity 0.916):
[0001327567-20-000007:note_history:26]
|  | Three Months Ended January 31, |  | Six Months Ended January 31, |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
|  | 2019 Notes |  | 2023 Notes |  | Total |  | 2019 Notes |  | 2023 Notes |  | Total |  | 2019 Notes |  | 2023 Notes |  | Total |  | 2019 Notes |  | 2023 Notes |  | Total |
| Contractual interest expense | $ | — |  |  | $ | 3.1 |  |  | $ | 3.1 |  |  | $ | — |  |  | $ | 3.1 |  |  | $ | 3.1 |  |  | $ | — |  |  | $ | 6.3 |  |  | $ | 6.3 |  |  | $ | — |  |  | $ | 6.3 |  |  | $ | 6.3 |  |
| Amortization of debt discount | — |  |  | 15.2 |  |  | 15.2 |  |  | 2.0 |  |  | 14.5 |  |  | 16.5 |  |  | — |  |  | 30.2 |  |  | 30.2 |  |  | 6.0 |  |  | 28.9 |  |  | 34.9 |  |
| Amortization of debt issuance costs | — |  |  | 0.5 |  |  | 0.5 |  |  | 0.2 |  |  | 0.4 |  |  | 0.6 |  |  | — |  |  | 1.0 |  |  | 1.0 |  |  | 0.7 |  |  | 0.9 |  |  | 1.6 |  |
| Total interest expense recognized | $ | — |  |  | $ | 18.8 |  |  | $ | 18.8 |  |  | $ | 2.2 |  |  | $ | 18.0 |  |  | $ | 20.2 |  |  | $ | — |  |  | $ | 37.5 |  |  | $ | 37.5 |  |  | $ | 6.7 |  |  | $ | 36.1 |  |  | $ | 42.8 |  |
| Effective interest rate of the liability component | — | % |  | 5.2 | % |  |  |  | 4.8 | % |  | 5.2 | % |  |  |  | — | % |  | 5.2 | % |  |  |  | 4.8 | % |  | 5.2 | % |  |  |

- changed (2020-05-22):
[0001327567-20-000017:note_history:27]
Separately, but concurrently with the issuance of each series of Notes, we entered into transactions whereby we sold warrants (the “2019 Warrants,” with respect to the 2019 Notes, and the “2023 Warrants,” with respect to the 2023 Notes, and collectively, the “Warrants”) to acquire shares of our common stock, subject to anti-dilution adjustments. The 2019 Warrants became exercisable beginning October 2019 and the 2023 Warrants are exercisable beginning October 2023.
  (was, 2020-02-25, similarity 0.713):
[0001327567-20-000007:note_history:27]
Separately, but concurrently with the issuance of each series of Notes, we entered into transactions whereby we sold warrants (the “2019 Warrants,” with respect to the 2019 Notes, and the “2023 Warrants,” with respect to the 2023 Notes, and collectively, the

- changed (2020-05-22):
[0001327567-20-000017:note_history:28]
During the nine months ended April 30, 2020, we net settled all 2019 Warrants with 2.0 million shares or $462.0 million in fair value of our common stock. The number of net shares issued was determined based on the number of 2019 Warrants exercised multiplied by the difference between the strike price of the 2019 Warrants and their daily volume weighted-average stock price.
  (was, 2020-02-25, similarity 0.6876):
[0001327567-20-000007:note_history:28]
During the six months ended January 31, 2020, we net settled all 2019 Warrants with approximately 2.0 million shares or $462.0 million in fair value of our common stock, of which 1.3 million shares or $308.4 million in fair value of our common stock were net settled during the three months ended January 31, 2020. The number of net shares issued was determined based on the number of 2019 Warrants exercised multiplied by the difference between the strike price of the 2019 Warrants and their daily volume weighted-average stock price.

- added (2020-05-22):
[0001327567-20-000017:note_history:29]
On September 4, 2018, we entered into a credit agreement (the “Credit Agreement”) with certain institutional lenders that provides for a $400.0 million unsecured revolving credit facility (the “Credit Facility”), with an option to increase the amount of the

- changed (2020-05-22):
[0001327567-20-000017:note_history:30]
Credit Facility by up to an additional $350.0 million, subject to certain conditions. The Credit Facility matures on the earlier of (i) September 4, 2023 and (ii) the date that is 91 days prior to the stated maturity of our 2023 Notes if (a) any of the 2023 Notes are still outstanding and (b) our unrestricted cash and cash equivalents are less than the then outstanding principal amount of our 2023 Notes plus $400.0 million.
  (was, 2020-02-25, similarity 0.7649):
[0001327567-20-000007:note_history:30]
On September 4, 2018, we entered into a credit agreement (the “Credit Agreement”) with certain institutional lenders that provides for a $400.0 million unsecured revolving credit facility (the “Credit Facility”), with an option to increase the amount of the Credit Facility by up to an additional $350.0 million, subject to certain conditions. The Credit Facility matures on the earlier of (i) September 4, 2023 and (ii) the date that is 91 days prior to the stated maturity of our 2023 Notes if (a) any of the 2023 Notes are still outstanding and (b) our unrestricted cash and cash equivalents are less than the then outstanding principal amount of our 2023 Notes plus $400.0 million.

- changed (2020-05-22):
[0001327567-20-000017:note_history:31]
The borrowings under the Credit Facility bear interest, at our option, at a base rate plus a spread of 0.00% to 0.75%, or an adjusted LIBO rate plus a spread of 1.00% to 1.75%, in each case with such spread being determined based on our leverage ratio. We are obligated to pay an ongoing commitment fee on undrawn amounts at a rate of 0.125% to 0.250%, depending on our leverage ratio. As of April 30, 2020, there were no amounts outstanding and we were in compliance with all covenants under the Credit Agreement.
  (was, 2020-02-25, similarity 0.9877):
[0001327567-20-000007:note_history:31]
The borrowings under the Credit Facility bear interest, at our option, at a base rate plus a spread of 0.00% to 0.75%, or an adjusted LIBO rate plus a spread of 1.00% to 1.75%, in each case with such spread being determined based on our leverage ratio. We are obligated to pay an ongoing commitment fee on undrawn amounts at a rate of 0.125% to 0.250%, depending on our leverage ratio. As of January 31, 2020, there were no amounts outstanding and we were in compliance with all covenants under the Credit Agreement.

- removed (2020-05-22):
[0001327567-20-000007:note_history:32]
equity component was included in additional paid-in capital in our condensed consolidated balance sheets as of January 31, 2020 and July 31, 2019. As of January 31, 2020, all of the 2023 Notes remained outstanding.

- removed (2020-05-22):
[0001327567-20-000007:note_history:33]
The total estimated fair value of the 2023 Notes was $1.9 billion at both January 31, 2020 and July 31, 2019. The fair value was determined based on the closing trading price per $100 of the 2023 Notes as of the last day of trading for the period. We consider the fair value of the 2023 Notes at January 31, 2020 and July 31, 2019 to be a Level 2 measurement. The fair value of the 2023 Notes is primarily affected by the trading price of our common stock and market interest rates. Based on the closing price of our common stock on January 31, 2020, the if-converted value of the 2023 Notes was less than its principal amount.

- removed (2020-05-22):
[0001327567-20-000007:note_history:34]
“Warrants”) to acquire shares of our common stock, subject to anti-dilution adjustments. The 2019 Warrants became exercisable beginning October 2019 and the 2023 Warrants are exercisable beginning October 2023.


## us-gaap:DebtSecuritiesAvailableForSaleTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-05-22):
[0001327567-20-000017:note_history:35]
The following tables summarize the amortized cost, unrealized gains and losses, and fair value of our available-for-sale debt securities as of April 30, 2020 and July 31, 2019 (in millions):
  (was, 2020-02-25, similarity 0.9779):
[0001327567-20-000007:note_history:35]
The following tables summarize the amortized cost, unrealized gains and losses, and fair value of our available-for-sale debt securities as of January 31, 2020 and July 31, 2019 (in millions):

- added (2020-05-22):
[0001327567-20-000017:note_history:36]
|  | April 30, 2020 |  |  |  |  |  |  |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 22.3 |  |  | $ | — |  |  | $ | — |  |  | $ | 22.3 |  |
| Corporate debt securities | 139.4 |  |  | 1.7 |  |  | — |  |  | 141.1 |  |
| U.S. government and agency securities | 537.6 |  |  | 4.3 |  |  | — |  |  | 541.9 |  |
| Total available-for-sale investments | $ | 699.3 |  |  | $ | 6.0 |  |  | $ | — |  |  | $ | 705.3 |  |

- changed (2020-05-22):
[0001327567-20-000017:note_history:37]
|  | July 31, 2019 |  |  |  |  |  |  |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 12.0 |  |  | $ | — |  |  | $ | — |  |  | $ | 12.0 |  |
| Commercial paper | 19.3 |  |  | — |  |  | — |  |  | 19.3 |  |
| U.S. government and agency securities | 54.4 |  |  | — |  |  | — |  |  | 54.4 |  |
| Total available-for-sale cash equivalents | $ | 85.7 |  |  | $ | — |  |  | $ | — |  |  | $ | 85.7 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 17.5 |  |  | $ | — |  |  | $ | — |  |  | $ | 17.5 |  |
| Commercial paper | 8.9 |  |  | — |  |  | — |  |  | 8.9 |  |
| Corporate debt securities | 587.8 |  |  | 2.3 |  |  | (0.3) |  |  | 589.8 |  |
| U.S. government and agency securities | 1,799.5 |  |  | 2.6 |  |  | (1.2) |  |  | 1,800.9 |  |
| Total available-for-sale investments | $ | 2,413.7 |  |  | $ | 4.9 |  |  | $ | (1.5) |  |  | $ | 2,417.1 |  |
  (was, 2020-02-25, similarity 0.9721):
[0001327567-20-000007:note_history:37]
|  | July 31, 2019 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 12.0 |  |  | $ | — |  |  | $ | — |  |  | $ | 12.0 |  |
| Commercial paper | 19.3 |  |  | — |  |  | — |  |  | 19.3 |  |
| U.S. government and agency securities | 54.4 |  |  | — |  |  | — |  |  | 54.4 |  |
| Total available-for-sale cash equivalents | $ | 85.7 |  |  | $ | — |  |  | $ | — |  |  | $ | 85.7 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 17.5 |  |  | $ | — |  |  | $ | — |  |  | $ | 17.5 |  |
| Commercial paper | 8.9 |  |  | — |  |  | — |  |  | 8.9 |  |
| Corporate debt securities | 587.8 |  |  | 2.3 |  |  | (0.3 | ) |  | 589.8 |  |
| U.S. government and agency securities | 1,799.5 |  |  | 2.6 |  |  | (1.2 | ) |  | 1,800.9 |  |
| Total available-for-sale investments | $ | 2,413.7 |  |  | $ | 4.9 |  |  | $ | (1.5 | ) |  | $ | 2,417.1 |  |

- removed (2020-05-22):
[0001327567-20-000007:note_history:38]
|  | January 31, 2020 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 65.5 |  |  | $ | — |  |  | $ | — |  |  | $ | 65.5 |  |
| U.S. government and agency securities | 479.5 |  |  | — |  |  | — |  |  | 479.5 |  |
| Total available-for-sale cash equivalents | $ | 545.0 |  |  | $ | — |  |  | $ | — |  |  | $ | 545.0 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 24.0 |  |  | $ | — |  |  | $ | — |  |  | $ | 24.0 |  |
| Corporate debt securities | 456.5 |  |  | 2.8 |  |  | — |  |  | 459.3 |  |
| U.S. government and agency securities | 966.1 |  |  | 2.5 |  |  | (0.1 | ) |  | 968.5 |  |
| Total available-for-sale investments | $ | 1,446.6 |  |  | $ | 5.3 |  |  | $ | (0.1 | ) |  | $ | 1,451.8 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-05-22):
[0001327567-20-000017:note_history:39]
The following tables summarize the amortized cost, unrealized gains and losses, and fair value of our available-for-sale debt securities as of April 30, 2020 and July 31, 2019 (in millions):
  (was, 2020-02-25, similarity 0.9779):
[0001327567-20-000007:note_history:39]
The following tables summarize the amortized cost, unrealized gains and losses, and fair value of our available-for-sale debt securities as of January 31, 2020 and July 31, 2019 (in millions):

- added (2020-05-22):
[0001327567-20-000017:note_history:40]
|  | April 30, 2020 |  |  |  |  |  |  |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 22.3 |  |  | $ | — |  |  | $ | — |  |  | $ | 22.3 |  |
| Corporate debt securities | 139.4 |  |  | 1.7 |  |  | — |  |  | 141.1 |  |
| U.S. government and agency securities | 537.6 |  |  | 4.3 |  |  | — |  |  | 541.9 |  |
| Total available-for-sale investments | $ | 699.3 |  |  | $ | 6.0 |  |  | $ | — |  |  | $ | 705.3 |  |

- changed (2020-05-22):
[0001327567-20-000017:note_history:41]
|  | July 31, 2019 |  |  |  |  |  |  |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 12.0 |  |  | $ | — |  |  | $ | — |  |  | $ | 12.0 |  |
| Commercial paper | 19.3 |  |  | — |  |  | — |  |  | 19.3 |  |
| U.S. government and agency securities | 54.4 |  |  | — |  |  | — |  |  | 54.4 |  |
| Total available-for-sale cash equivalents | $ | 85.7 |  |  | $ | — |  |  | $ | — |  |  | $ | 85.7 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 17.5 |  |  | $ | — |  |  | $ | — |  |  | $ | 17.5 |  |
| Commercial paper | 8.9 |  |  | — |  |  | — |  |  | 8.9 |  |
| Corporate debt securities | 587.8 |  |  | 2.3 |  |  | (0.3) |  |  | 589.8 |  |
| U.S. government and agency securities | 1,799.5 |  |  | 2.6 |  |  | (1.2) |  |  | 1,800.9 |  |
| Total available-for-sale investments | $ | 2,413.7 |  |  | $ | 4.9 |  |  | $ | (1.5) |  |  | $ | 2,417.1 |  |
  (was, 2020-02-25, similarity 0.9721):
[0001327567-20-000007:note_history:41]
|  | July 31, 2019 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 12.0 |  |  | $ | — |  |  | $ | — |  |  | $ | 12.0 |  |
| Commercial paper | 19.3 |  |  | — |  |  | — |  |  | 19.3 |  |
| U.S. government and agency securities | 54.4 |  |  | — |  |  | — |  |  | 54.4 |  |
| Total available-for-sale cash equivalents | $ | 85.7 |  |  | $ | — |  |  | $ | — |  |  | $ | 85.7 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 17.5 |  |  | $ | — |  |  | $ | — |  |  | $ | 17.5 |  |
| Commercial paper | 8.9 |  |  | — |  |  | — |  |  | 8.9 |  |
| Corporate debt securities | 587.8 |  |  | 2.3 |  |  | (0.3 | ) |  | 589.8 |  |
| U.S. government and agency securities | 1,799.5 |  |  | 2.6 |  |  | (1.2 | ) |  | 1,800.9 |  |
| Total available-for-sale investments | $ | 2,413.7 |  |  | $ | 4.9 |  |  | $ | (1.5 | ) |  | $ | 2,417.1 |  |

- changed (2020-05-22):
[0001327567-20-000017:note_history:42]
Unrealized losses related to these securities are due to interest rate fluctuations as opposed to credit quality. In addition, we do not intend to sell and it is not likely that we would be required to sell these securities before recovery of their amortized cost basis, which may be at maturity. As a result, there were no other-than-temporary impairments for these securities at April 30, 2020 and July 31, 2019.
  (was, 2020-02-25, similarity 0.9851):
[0001327567-20-000007:note_history:42]
Unrealized losses related to these securities are due to interest rate fluctuations as opposed to credit quality. In addition, we do not intend to sell and it is not likely that we would be required to sell these securities before recovery of their amortized cost basis, which may be at maturity. As a result, there were no other-than-temporary impairments for these securities at January 31, 2020 and July 31, 2019.

- changed (2020-05-22):
[0001327567-20-000017:note_history:43]
The following table summarizes the amortized cost and fair value of our available-for-sale debt securities as of April 30, 2020, by contractual years-to-maturity (in millions):
  (was, 2020-02-25, similarity 0.9766):
[0001327567-20-000007:note_history:43]
The following table summarizes the amortized cost and fair value of our available-for-sale debt securities as of January 31, 2020, by contractual years-to-maturity (in millions):

- added (2020-05-22):
[0001327567-20-000017:note_history:44]
Marketable equity securities consist of money market funds and are included in cash and cash equivalents in our condensed consolidated balance sheets. As of April 30, 2020 and July 31, 2019, the carrying value of our marketable equity securities were $762.6 million and $369.1 million, respectively. There were no unrealized gains or losses recognized for these securities during the three and nine months ended April 30, 2020 and 2019.

- removed (2020-05-22):
[0001327567-20-000007:note_history:45]
|  | January 31, 2020 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 65.5 |  |  | $ | — |  |  | $ | — |  |  | $ | 65.5 |  |
| U.S. government and agency securities | 479.5 |  |  | — |  |  | — |  |  | 479.5 |  |
| Total available-for-sale cash equivalents | $ | 545.0 |  |  | $ | — |  |  | $ | — |  |  | $ | 545.0 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 24.0 |  |  | $ | — |  |  | $ | — |  |  | $ | 24.0 |  |
| Corporate debt securities | 456.5 |  |  | 2.8 |  |  | — |  |  | 459.3 |  |
| U.S. government and agency securities | 966.1 |  |  | 2.5 |  |  | (0.1 | ) |  | 968.5 |  |
| Total available-for-sale investments | $ | 1,446.6 |  |  | $ | 5.3 |  |  | $ | (0.1 | ) |  | $ | 1,451.8 |  |

- removed (2020-05-22):
[0001327567-20-000007:note_history:46]
Marketable equity securities consist of money market funds and are included in cash and cash equivalents in our condensed consolidated balance sheets. As of January 31, 2020 and July 31, 2019, the carrying value of our marketable equity securities were $577.1 million and $369.1 million, respectively. There were no unrealized gains or losses recognized for these securities during the three and six months ended January 31, 2020 and 2019.


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2020-05-22):
[0001327567-20-000017:note_history:47]
|  | Three Months Ended April 30, |  |  |  | Nine Months Ended April 30, |  |  |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Revenue: |  |  |  |  |  |  |  |
| Americas |  |  |  |  |  |  |  |
| United States | $ | 553.5 |  |  | $ | 464.3 |  |  | $ | 1,554.0 |  |  | $ | 1,314.8 |  |
| Other Americas | 40.7 |  |  | 33.5 |  |  | 114.5 |  |  | 108.2 |  |
| Total Americas | 594.2 |  |  | 497.8 |  |  | 1,668.5 |  |  | 1,423.0 |  |
| Europe, the Middle East, and Africa (“EMEA”) | 171.5 |  |  | 138.7 |  |  | 485.3 |  |  | 414.7 |  |
| Asia Pacific and Japan (“APAC”) | 103.7 |  |  | 90.1 |  |  | 304.2 |  |  | 256.1 |  |
| Total revenue | $ | 869.4 |  |  | $ | 726.6 |  |  | $ | 2,458.0 |  |  | $ | 2,093.8 |  |
  (was, 2020-02-25, similarity 0.945):
[0001327567-20-000007:note_history:47]
|  | Three Months Ended January 31, |  | Six Months Ended January 31, |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Revenue: |  |  |  |  |  |  |  |
| Americas |  |  |  |  |  |  |  |
| United States | $ | 505.6 |  |  | $ | 434.6 |  |  | $ | 1,000.5 |  |  | $ | 850.5 |  |
| Other Americas | 39.1 |  |  | 40.4 |  |  | 73.8 |  |  | 74.7 |  |
| Total Americas | 544.7 |  |  | 475.0 |  |  | 1,074.3 |  |  | 925.2 |  |
| Europe, the Middle East, and Africa (“EMEA”) | 166.2 |  |  | 148.3 |  |  | 313.8 |  |  | 276.0 |  |
| Asia Pacific and Japan (“APAC”) | 105.8 |  |  | 87.9 |  |  | 200.5 |  |  | 166.0 |  |
| Total revenue | $ | 816.7 |  |  | $ | 711.2 |  |  | $ | 1,588.6 |  |  | $ | 1,367.2 |  |

- added (2020-05-22):
[0001327567-20-000017:note_history:48]
|  | Three Months Ended April 30, |  |  |  | Nine Months Ended April 30, |  |  |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Revenue: |  |  |  |  |  |  |  |
| Product | $ | 280.9 |  |  | $ | 278.4 |  |  | $ | 758.6 |  |  | $ | 790.5 |  |
| Subscription and support |  |  |  |  |  |  |  |
| Subscription | 354.3 |  |  | 258.8 |  |  | 1,015.5 |  |  | 739.8 |  |
| Support | 234.2 |  |  | 189.4 |  |  | 683.9 |  |  | 563.5 |  |
| Total subscription and support | 588.5 |  |  | 448.2 |  |  | 1,699.4 |  |  | 1,303.3 |  |
| Total revenue | $ | 869.4 |  |  | $ | 726.6 |  |  | $ | 2,458.0 |  |  | $ | 2,093.8 |  |

- changed (2020-05-22):
[0001327567-20-000017:note_history:49]
During the nine months ended April 30, 2020, we recognized approximately $1,265.0 million of revenue pertaining to amounts that were deferred as of July 31, 2019.
  (was, 2020-02-25, similarity 0.955):
[0001327567-20-000007:note_history:49]
During the six months ended January 31, 2020, we recognized approximately $915.0 million of revenue pertaining to amounts that were deferred as of July 31, 2019.

- changed (2020-05-22):
[0001327567-20-000017:note_history:50]
Revenue expected to be recognized from remaining performance obligations was $3.5 billion as of April 30, 2020, of which we expect to recognize approximately $1.9 billion over the next 12 months and the remainder thereafter.
Deferred Contract Costs
The following table presents details of our short-term and long-term deferred contract costs as of April 30, 2020 and July 31, 2019 (in millions):
  (was, 2020-02-25, similarity 0.9681):
[0001327567-20-000007:note_history:50]
Revenue expected to be recognized from remaining performance obligations was $3.3 billion as of January 31, 2020, of which we expect to recognize approximately $1.8 billion over the next 12 months and the remainder thereafter.
Deferred Contract Costs
The following table presents details of our short-term and long-term deferred contract costs as of January 31, 2020 and July 31, 2019 (in millions):

- changed (2020-05-22):
[0001327567-20-000017:note_history:51]
|  | April 30, 2020 |  | July 31, 2019 |
| Short-term deferred contract costs | $ | 173.7 |  |  | $ | 151.1 |  |
| Long-term deferred contract costs | 343.6 |  |  | 324.2 |  |
| Total deferred contract costs | $ | 517.3 |  |  | $ | 475.3 |  |
  (was, 2020-02-25, similarity 0.9798):
[0001327567-20-000007:note_history:51]
|  | January 31, 2020 |  | July 31, 2019 |
| Short-term deferred contract costs | $ | 164.6 |  |  | $ | 151.1 |  |
| Long-term deferred contract costs | 327.2 |  |  | 324.2 |  |
| Total deferred contract costs | $ | 491.8 |  |  | $ | 475.3 |  |

- added (2020-05-22):
[0001327567-20-000017:note_history:52]
We recognized amortization expense for our deferred contract costs of $60.5 million and $171.4 million during the three and nine months ended April 30, 2020, respectively, and $57.2 million and $147.6 million during the three and nine months ended April 30, 2019, respectively. We did not recognize any impairment losses on our deferred contract costs during the three and nine months ended April 30, 2020 or 2019.

- removed (2020-05-22):
[0001327567-20-000007:note_history:53]
|  | Three Months Ended January 31, |  | Six Months Ended January 31, |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Revenue: |  |  |  |  |  |  |  |
| Product | $ | 246.5 |  |  | $ | 271.6 |  |  | $ | 477.7 |  |  | $ | 512.1 |  |
| Subscription and support |  |  |  |  |  |  |  |
| Subscription | 342.6 |  |  | 249.7 |  |  | 661.2 |  |  | 481.0 |  |
| Support | 227.6 |  |  | 189.9 |  |  | 449.7 |  |  | 374.1 |  |
| Total subscription and support | 570.2 |  |  | 439.6 |  |  | 1,110.9 |  |  | 855.1 |  |
| Total revenue | $ | 816.7 |  |  | $ | 711.2 |  |  | $ | 1,588.6 |  |  | $ | 1,367.2 |  |

- removed (2020-05-22):
[0001327567-20-000007:note_history:54]
We recognized amortization expense for our deferred contract costs of $55.3 million and $110.9 million during the three and six months ended January 31, 2020, respectively, and $46.8 million and $90.4 million during the three and six months ended January 31, 2019, respectively. We did not recognize any impairment losses on our deferred contract costs during the three and six months ended January 31, 2020 or 2019.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_current_note, score: 0.0

- removed (2020-05-22):
[0001327567-20-000007:note_history:55]
Subsequent Events
Accelerated Share Repurchase

- removed (2020-05-22):
[0001327567-20-000007:note_history:56]
On February 21, 2020, our board of directors approved the repurchase of $1.0 billion of our common stock through an accelerated share repurchase (“ASR”) transaction, which we expect to enter into during our fiscal quarter ending April 30, 2020, subject to market conditions. The ASR transaction is in addition to our $1.0 billion share repurchase program that our board of directors authorized in February 2019.

- removed (2020-05-22):
[0001327567-20-000007:note_history:57]
Land Purchase Agreement

- removed (2020-05-22):
[0001327567-20-000007:note_history:58]
In February 2020, we entered into an agreement to purchase 5.8 acres of land adjacent to our headquarters in Santa Clara, California for $51.0 million in cash.  The arrangement is expected to close during our fiscal quarter ending April 30, 2020.
