# PANW notes — 0001327567-22-000038


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0001327567-22-000038:notes:1]
[same as prior period, unchanged from 0001327567-22-000016:notes:1]

[0001327567-22-000038:notes:2]
Palo Alto Networks, Inc. (the “Company,” “we,” “us,” or “our”), headquartered in Santa Clara, California, was incorporated in March 2005 under the laws of the State of Delaware and commenced operations in April 2005. We empower enterprises, organizations, service providers, and government entities to secure their users, networks, clouds, and endpoints by delivering comprehensive cybersecurity backed by artificial intelligence and automation.

[0001327567-22-000038:notes:3]
[same as prior period, unchanged from 0001327567-22-000016:notes:3]

[0001327567-22-000038:notes:4]
The accompanying condensed consolidated financial statements have been prepared in conformity with U.S. generally accepted accounting principles (“GAAP”), consistent in all material respects with those applied in our Annual Report on Form 10-K for the fiscal year ended July 31, 2022, filed with the Securities and Exchange Commission (“SEC”) on September 6, 2022. Our condensed consolidated financial statements include our accounts and our wholly owned subsidiaries. All significant intercompany balances and transactions have been eliminated in consolidation.

[0001327567-22-000038:notes:5]
The condensed consolidated financial statements are unaudited but include all adjustments of a normal recurring nature necessary for a fair presentation of our quarterly results. Our condensed consolidated financial statements should be read in conjunction with the audited consolidated financial statements and related notes in our Annual Report on Form 10-K for the fiscal year ended July 31, 2022.

[0001327567-22-000038:notes:6]
[same as prior period, unchanged from 0001327567-22-000016:notes:6]

[0001327567-22-000038:notes:7]
The preparation of condensed consolidated financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the amounts reported and disclosed in the condensed consolidated financial statements and the accompanying notes. We base our estimates on assumptions, both historical and forward looking, that we believe are reasonable. Actual results could differ materially from those estimates due to risks and uncertainties, including uncertainty in the current economic environment.

[0001327567-22-000038:notes:8]
[same as prior period, unchanged from 0001327567-22-000016:notes:8]

[0001327567-22-000038:notes:9]
There have been no material changes to our significant accounting policies as of and for the three months ended October 31, 2022, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended July 31, 2022.

[0001327567-22-000038:notes:10]
Stock Split Effected in the Form of a Stock Dividend (“Stock Split”)

[0001327567-22-000038:notes:11]
On September 13, 2022, we executed a three-for-one stock split of our common stock, effected in the form of a stock dividend. The par value per share of our common stock remains unchanged at $0.001 per share after the Stock Split. All references made to share or per share amounts on the accompanying condensed consolidated financial statements and applicable disclosures have been retroactively adjusted to reflect the effects of the Stock Split.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001327567-22-000038:notes:12]
[same as prior period, unchanged from 0001327567-22-000016:notes:22]

[0001327567-22-000038:notes:13]
[same as prior period, unchanged from 0001327567-22-000016:notes:23]

[0001327567-22-000038:notes:14]
|  |  |  | Three Months Ended October 31, |
|  |  |  |  |  | 2022 |  | 2021 |
| Revenue: |  |  |  |  |  |  |  |
| Americas |  |  |  |  |  |  |  |
| United States |  |  |  |  | $ | 1,006.3 |  |  | $ | 811.7 |  |
| Other Americas |  |  |  |  | 64.4 |  |  | 55.0 |  |
| Total Americas |  |  |  |  | 1,070.7 |  |  | 866.7 |  |
| Europe, the Middle East, and Africa (“EMEA”) |  |  |  |  | 307.9 |  |  | 233.8 |  |
| Asia Pacific and Japan (“APAC”) |  |  |  |  | 184.8 |  |  | 146.9 |  |
| Total revenue |  |  |  |  | $ | 1,563.4 |  |  | $ | 1,247.4 |  |

[0001327567-22-000038:notes:15]
[same as prior period, unchanged from 0001327567-22-000016:notes:25]

[0001327567-22-000038:notes:16]
|  |  |  | Three Months Ended October 31, |
|  |  |  |  |  | 2022 |  | 2021 |
| Revenue: |  |  |  |  |  |  |  |
| Product |  |  |  |  | $ | 330.0 |  |  | $ | 295.5 |  |
| Subscription and support |  |  |  |  |  |  |  |
| Subscription |  |  |  |  | 764.0 |  |  | 578.8 |  |
| Support |  |  |  |  | 469.4 |  |  | 373.1 |  |
| Total subscription and support |  |  |  |  | 1,233.4 |  |  | 951.9 |  |
| Total revenue |  |  |  |  | $ | 1,563.4 |  |  | $ | 1,247.4 |  |

[0001327567-22-000038:notes:17]
[same as prior period, unchanged from 0001327567-22-000016:notes:27]

[0001327567-22-000038:notes:18]
During the three months ended October 31, 2022 and 2021, we recognized approximately $1.1 billion and $840.0 million of revenue pertaining to amounts that were deferred as of July 31, 2022 and 2021, respectively.

[0001327567-22-000038:notes:19]
[same as prior period, unchanged from 0001327567-22-000016:notes:29]

[0001327567-22-000038:notes:20]
Remaining performance obligations were $8.3 billion as of October 31, 2022, of which we expect to recognize as revenue approximately $4.2 billion over the next 12 months and the remainder thereafter.


## us-gaap:FairValueDisclosuresTextBlock

[0001327567-22-000038:notes:21]
Fair Value Measurements The following table presents our financial assets and liabilities measured at fair value on a recurring basis as of October 31, 2022 and July 31, 2022 (in millions):

[0001327567-22-000038:notes:22]
|  |  | October 31, 2022 |  | July 31, 2022 |
|  |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Cash equivalents: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 933.2 |  |  | $ | — |  |  | $ | — |  |  | $ | 933.2 |  |  | $ | 1,205.2 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,205.2 |  |
| Certificates of deposit |  | — |  |  | 150.6 |  |  | — |  |  | 150.6 |  |  | — |  |  | 155.3 |  |  | — |  |  | 155.3 |  |
| Commercial paper |  | — |  |  | 338.5 |  |  | — |  |  | 338.5 |  |  | — |  |  | 69.1 |  |  | — |  |  | 69.1 |  |
| Corporate debt securities |  | — |  |  | 37.2 |  |  | — |  |  | 37.2 |  |  | — |  |  | 19.5 |  |  | — |  |  | 19.5 |  |
| U.S. government and agency securities |  | — |  |  | 159.9 |  |  | — |  |  | 159.9 |  |  | — |  |  | 10.0 |  |  | — |  |  | 10.0 |  |
| Non-U.S. government and agency securities |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 5.1 |  |  | — |  |  | 5.1 |  |
| Total cash equivalents |  | 933.2 |  |  | 686.2 |  |  | — |  |  | 1,619.4 |  |  | 1,205.2 |  |  | 259.0 |  |  | — |  |  | 1,464.2 |  |
| Short-term investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Certificates of deposit |  | — |  |  | 213.0 |  |  | — |  |  | 213.0 |  |  | — |  |  | 116.4 |  |  | — |  |  | 116.4 |  |
| Commercial paper |  | — |  |  | 288.3 |  |  | — |  |  | 288.3 |  |  | — |  |  | 79.0 |  |  | — |  |  | 79.0 |  |
| Corporate debt securities |  | — |  |  | 661.4 |  |  | — |  |  | 661.4 |  |  | — |  |  | 505.0 |  |  | — |  |  | 505.0 |  |
| U.S. government and agency securities |  | — |  |  | 546.9 |  |  | — |  |  | 546.9 |  |  | — |  |  | 798.2 |  |  | — |  |  | 798.2 |  |
| Non-U.S. government and agency securities |  | — |  |  | 26.9 |  |  | — |  |  | 26.9 |  |  | — |  |  | 17.4 |  |  | — |  |  | 17.4 |  |
| Total short-term investments |  | — |  |  | 1,736.5 |  |  | — |  |  | 1,736.5 |  |  | — |  |  | 1,516.0 |  |  | — |  |  | 1,516.0 |  |
| Long-term investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate debt securities |  | — |  |  | 1,623.8 |  |  | — |  |  | 1,623.8 |  |  | — |  |  | 761.2 |  |  | — |  |  | 761.2 |  |
| U.S. government and agency securities |  | — |  |  | 50.2 |  |  | — |  |  | 50.2 |  |  | — |  |  | 118.2 |  |  | — |  |  | 118.2 |  |
| Non-U.S. government and agency securities |  | — |  |  | 52.0 |  |  | — |  |  | 52.0 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Asset-backed securities |  | — |  |  | 368.7 |  |  | — |  |  | 368.7 |  |  | — |  |  | 172.5 |  |  | — |  |  | 172.5 |  |
| Total long-term investments |  | — |  |  | 2,094.7 |  |  | — |  |  | 2,094.7 |  |  | — |  |  | 1,051.9 |  |  | — |  |  | 1,051.9 |  |

[0001327567-22-000038:notes:23]
|  |  | October 31, 2022 |  | July 31, 2022 |
|  |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Prepaid expenses and other current assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency forward contracts |  | — |  |  | 0.5 |  |  | — |  |  | 0.5 |  |  | — |  |  | 2.4 |  |  | — |  |  | 2.4 |  |
| Total prepaid expenses and other current assets |  | — |  |  | 0.5 |  |  | — |  |  | 0.5 |  |  | — |  |  | 2.4 |  |  | — |  |  | 2.4 |  |
| Other assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency forward contracts |  | — |  |  | 0.2 |  |  | — |  |  | 0.2 |  |  | — |  |  | 0.7 |  |  | — |  |  | 0.7 |  |
| Total other assets |  | — |  |  | 0.2 |  |  | — |  |  | 0.2 |  |  | — |  |  | 0.7 |  |  | — |  |  | 0.7 |  |
| Total assets measured at fair value |  | $ | 933.2 |  |  | $ | 4,518.1 |  |  | $ | — |  |  | $ | 5,451.3 |  |  | $ | 1,205.2 |  |  | $ | 2,830.0 |  |  | $ | — |  |  | $ | 4,035.2 |  |
| Accrued and other liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency forward contracts |  | $ | — |  |  | $ | 51.4 |  |  | $ | — |  |  | $ | 51.4 |  |  | $ | — |  |  | $ | 32.4 |  |  | $ | — |  |  | $ | 32.4 |  |
| Total accrued and other liabilities |  | — |  |  | 51.4 |  |  | — |  |  | 51.4 |  |  | — |  |  | 32.4 |  |  | — |  |  | 32.4 |  |
| Other long-term liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency forward contracts |  | — |  |  | 5.2 |  |  | — |  |  | 5.2 |  |  | — |  |  | 0.8 |  |  | — |  |  | 0.8 |  |
| Total other long-term liabilities |  | — |  |  | 5.2 |  |  | — |  |  | 5.2 |  |  | — |  |  | 0.8 |  |  | — |  |  | 0.8 |  |
| Total liabilities measured at fair value |  | $ | — |  |  | $ | 56.6 |  |  | $ | — |  |  | $ | 56.6 |  |  | $ | — |  |  | $ | 33.2 |  |  | $ | — |  |  | $ | 33.2 |  |

[0001327567-22-000038:notes:24]
Refer to Note 8. Debt for the carrying amount and estimated fair value of our convertible senior notes as of October 31, 2022 and July 31, 2022.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001327567-22-000038:notes:25]
Cash Equivalents and Investments
Available-for-sale Debt Securities

[0001327567-22-000038:notes:26]
The following tables summarize the amortized cost, unrealized gains and losses, and fair value of our available-for-sale debt securities as of October 31, 2022 and July 31, 2022 (in millions):

[0001327567-22-000038:notes:27]
|  | October 31, 2022 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 150.6 |  |  | $ | — |  |  | $ | — |  |  | $ | 150.6 |  |
| Commercial paper | 338.5 |  |  | — |  |  | — |  |  | 338.5 |  |
| Corporate debt securities | 37.3 |  |  | — |  |  | (0.1) |  |  | 37.2 |  |
| U.S. government and agency securities | 159.9 |  |  | — |  |  | — |  |  | 159.9 |  |
| Total available-for-sale cash equivalents | $ | 686.3 |  |  | $ | — |  |  | $ | (0.1) |  |  | $ | 686.2 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 213.3 |  |  | $ | — |  |  | $ | (0.3) |  |  | $ | 213.0 |  |
| Commercial paper | 289.4 |  |  | — |  |  | (1.1) |  |  | 288.3 |  |
| Corporate debt securities | 2,321.6 |  |  | 0.4 |  |  | (36.8) |  |  | 2,285.2 |  |
| U.S. government and agency securities | 605.3 |  |  | — |  |  | (8.2) |  |  | 597.1 |  |
| Non-U.S. government and agency securities | 80.0 |  |  | — |  |  | (1.1) |  |  | 78.9 |  |
| Asset-backed securities | 372.8 |  |  | — |  |  | (4.1) |  |  | 368.7 |  |
| Total available-for-sale investments | $ | 3,882.4 |  |  | $ | 0.4 |  |  | $ | (51.6) |  |  | $ | 3,831.2 |  |

[0001327567-22-000038:notes:28]
|  | July 31, 2022 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 155.3 |  |  | $ | — |  |  | $ | — |  |  | $ | 155.3 |  |
| Commercial paper | 69.1 |  |  | — |  |  | — |  |  | 69.1 |  |
| Corporate debt securities | 19.5 |  |  | — |  |  | — |  |  | 19.5 |  |
| U.S. government and agency securities | 10.0 |  |  | — |  |  | — |  |  | 10.0 |  |
| Non-U.S. government and agency securities | 5.0 |  |  | 0.1 |  |  | — |  |  | 5.1 |  |
| Total available-for-sale cash equivalents | $ | 258.9 |  |  | $ | 0.1 |  |  | $ | — |  |  | $ | 259.0 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 116.5 |  |  | $ | — |  |  | $ | (0.1) |  |  | $ | 116.4 |  |
| Commercial paper | 79.1 |  |  | — |  |  | (0.1) |  |  | 79.0 |  |
| Corporate debt securities | 1,276.8 |  |  | 1.3 |  |  | (11.9) |  |  | 1,266.2 |  |
| U.S. government and agency securities | 928.1 |  |  | 0.1 |  |  | (11.8) |  |  | 916.4 |  |
| Non-U.S. government and agency securities | 17.6 |  |  | — |  |  | (0.2) |  |  | 17.4 |  |
| Asset-backed securities | $ | 173.4 |  |  | $ | 0.2 |  |  | $ | (1.1) |  |  | $ | 172.5 |  |
| Total available-for-sale investments | $ | 2,591.5 |  |  | $ | 1.6 |  |  | $ | (25.2) |  |  | $ | 2,567.9 |  |

[0001327567-22-000038:notes:29]
As of October 31, 2022, the gross unrealized losses that have been in a continuous unrealized loss position for less than 12 months were $45.7 million, which were related to $3.5 billion of available-for-sale debt securities, and the gross unrealized losses that have been in a continuous unrealized loss position for more than 12 months were not material. As of July 31, 2022 the gross unrealized losses that have been in a continuous unrealized loss position for less than 12 months were $24.8 million, which were related to $2.0 billion of available-for-sale debt securities, and the gross unrealized losses that have been in a continuous unrealized loss position for more than 12 months were not material.

[0001327567-22-000038:notes:30]
Unrealized losses related to our available-for-sale debt securities are due to interest rate fluctuations as opposed to credit quality. We do not intend to sell any of the securities in an unrealized loss position and it is not likely that we would be required to sell these securities before recovery of their amortized cost basis, which may be at maturity. We did not recognize any credit losses related to our available-for-sale debt securities during the three months ended October 31, 2022 and 2021.

[0001327567-22-000038:notes:31]
The following table summarizes the amortized cost and fair value of our available-for-sale debt securities as of October 31, 2022, by contractual years-to-maturity (in millions):

[0001327567-22-000038:notes:32]
|  | Amortized Cost |  | Fair Value |
| Due within one year | $ | 2,438.8 |  |  | $ | 2,422.7 |  |
| Due between one and three years | 2,001.9 |  |  | 1,968.5 |  |
| Due between three to five years | 106.9 |  |  | 105.4 |  |
| Due between five to ten years | 21.1 |  |  | 20.8 |  |
| Total | $ | 4,568.7 |  |  | $ | 4,517.4 |  |

[0001327567-22-000038:notes:33]
Marketable Equity Securities

[0001327567-22-000038:notes:34]
Marketable equity securities consist of money market funds and are included in cash and cash equivalents on our condensed consolidated balance sheets. As of October 31, 2022 and July 31, 2022, the carrying values of our marketable equity securities were $933.2 million and $1.2 billion, respectively. There were no unrealized gains or losses recognized for these securities during the three months ended October 31, 2022 and 2021.


## us-gaap:FinancingReceivablesTextBlock

[0001327567-22-000038:notes:35]
Financing ReceivablesThe following table summarizes our short-term and long-term financing receivables as of October 31, 2022 and July 31, 2022 (in millions):

[0001327567-22-000038:notes:36]
|  |  | October 31, 2022 |  | July 31, 2022 |
| Short-term financing receivables, gross |  | $ | 155.5 |  |  | $ | 112.6 |  |
| Allowance for credit losses |  | (1.8) |  |  | (1.3) |  |
| Short-term financing receivables, net |  | $ | 153.7 |  |  | $ | 111.3 |  |
| Long-term financing receivables, gross |  | $ | 165.2 |  |  | $ | 194.6 |  |
| Allowance for credit losses |  | (3.1) |  |  | (2.5) |  |
| Long-term financing receivables, net |  | $ | 162.1 |  |  | $ | 192.1 |  |

[0001327567-22-000038:notes:37]
There was no significant activity in allowance for credit losses during the three months ended October 31, 2022 and 2021. Past due amounts on financing receivables were not material as of October 31, 2022 and July 31, 2022.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001327567-22-000038:notes:38]
Derivative Instruments
We are exposed to foreign currency exchange risk. Substantially all of our revenue is transacted in U.S. dollars, however, a portion of our operating expenditures are incurred outside of the United States and are denominated in foreign currencies, making them subject to fluctuations in foreign currency exchange rates. We enter into foreign currency derivative contracts with maturities of 24 months or less, which we designate as cash flow hedges, to manage the foreign currency exchange risk associated with our operating expenditures.

[0001327567-22-000038:notes:39]
As of October 31, 2022 and July 31, 2022, the total notional amount of our outstanding foreign currency forward contracts was $1.3 billion and $856.9 million, respectively. Refer to Note 3. Fair Value Measurements for the fair value of our derivative instruments as reported on our condensed consolidated balance sheets as of October 31, 2022 and July 31, 2022.
As of October 31, 2022, unrealized losses in accumulated other comprehensive income (“AOCI”) related to our cash flow hedges were $52.5 million, of which $44.2 million of losses are expected to be recognized into earnings within the next 12 months. As of July 31, 2022, unrealized losses in AOCI related to our cash flow hedges were $24.8 million, of which $22.0 million of losses are expected to be recognized into earnings within the next 12 months.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001327567-22-000038:notes:40]
Intangible Assets
Purchased Intangible Assets

[0001327567-22-000038:notes:41]
The following table presents details of our purchased intangible assets as of October 31, 2022 and July 31, 2022 (in millions):

[0001327567-22-000038:notes:42]
|  | October 31, 2022 |  | July 31, 2022 |
|  | Gross Carrying Amount |  | Accumulated Amortization |  | Net Carrying Amount |  | Gross Carrying Amount |  | Accumulated Amortization |  | Net Carrying Amount |
| Intangible assets subject to amortization: |  |  |  |  |  |  |  |  |  |  |  |
| Developed technology | $ | 600.7 |  |  | $ | (371.2) |  |  | $ | 229.5 |  |  | $ | 600.7 |  |  | $ | (347.9) |  |  | $ | 252.8 |  |
| Customer relationships | 172.7 |  |  | (57.7) |  |  | 115.0 |  |  | 172.7 |  |  | (52.2) |  |  | 120.5 |  |
| Acquired intellectual property | 11.3 |  |  | (5.0) |  |  | 6.3 |  |  | 11.3 |  |  | (4.8) |  |  | 6.5 |  |
| Trade name and trademarks | 9.4 |  |  | (9.4) |  |  | — |  |  | 9.4 |  |  | (9.4) |  |  | — |  |
| Other | 0.9 |  |  | (0.2) |  |  | 0.7 |  |  | 0.9 |  |  | (0.1) |  |  | 0.8 |  |
| Total intangible assets subject to amortization | 795.0 |  |  | (443.5) |  |  | 351.5 |  |  | 795.0 |  |  | (414.4) |  |  | 380.6 |  |
| Intangible assets not subject to amortization: |  |  |  |  |  |  |  |  |  |  |  |
| In-process research and development | 3.9 |  |  | — |  |  | 3.9 |  |  | 3.9 |  | — |  |  | 3.9 |  |
| Total purchased intangible assets | $ | 798.9 |  |  | $ | (443.5) |  |  | $ | 355.4 |  |  | $ | 798.9 |  |  | $ | (414.4) |  |  | $ | 384.5 |  |

[0001327567-22-000038:notes:43]
We recognized amortization expense of $29.1 million and $31.8 million for the three months ended October 31, 2022 and 2021, respectively.
The following table summarizes estimated future amortization expense of our intangible assets subject to amortization as of October 31, 2022 (in millions):

[0001327567-22-000038:notes:44]
|  |  |  | Fiscal years ending July 31, |
|  | Total |  | Remaining 2023 |  | 2024 |  | 2025 |  | 2026 |  | 2027 |  | 2028 and Thereafter |
| Future amortization expense | $ | 351.5 |  |  | $ | 72.0 |  |  | $ | 91.1 |  |  | $ | 77.4 |  |  | $ | 55.6 |  |  | $ | 28.5 |  |  | $ | 26.9 |  |


## us-gaap:DebtDisclosureTextBlock

[0001327567-22-000038:notes:45]
Debt
Convertible Senior Notes

[0001327567-22-000038:notes:46]
In July 2018, we issued $1.7 billion aggregate principal amount of 0.75% Convertible Senior Notes due 2023 (the “2023 Notes”) and in June 2020, we issued $2.0 billion aggregate principal amount of 0.375% Convertible Senior Notes due 2025 (the “2025 Notes,” and together with the 2023 Notes, the “Notes”). The 2023 Notes bear interest at a fixed rate of 0.75% per year, payable semi-annually in arrears on January 1 and July 1 of each year, beginning on January 1, 2019. The 2025 Notes bear interest at a fixed rate of 0.375% per year, payable semi-annually in arrears on June 1 and December 1 of each year, beginning on December 1, 2020. Each series of the convertible notes is governed by an indenture between us, as the issuer, and U.S. Bank National Association, as Trustee (individually, each an “Indenture,” and together, the “Indentures”). The Notes of each series are unsecured, unsubordinated obligations and the applicable Indenture governing each series of Notes does not contain any financial covenants or restrictions on the payments of dividends, the incurrence of indebtedness, or the issuance or repurchase of securities by us or any of our subsidiaries. The 2023 Notes and the 2025 Notes mature on July 1, 2023 and June 1, 2025, respectively. We cannot redeem the 2023 Notes prior to maturity. We may redeem for cash all or any portion of the 2025 Notes, at our option, on or after June 5, 2023, and prior to the 31st scheduled trading day immediately preceding the maturity date if the last reported sale price of our common stock has been at least 130% of the conversion price then in effect for at least 20 trading days during any 30 consecutive trading day period ending on and including the trading day preceding the date on which we provide notice of redemption. The redemption will be at a price equal to 100% of the principal amount of the 2025 Notes and adjusted for interest. If we call any or all of the 2025 Notes for redemption, holders may convert such 2025 Notes called for redemption at any time prior to the close of business on the second scheduled trading day immediately preceding the redemption date.

[0001327567-22-000038:notes:47]
The following table presents details of our Notes (number of shares in millions):

[0001327567-22-000038:notes:48]
|  | Conversion Rate per $1,000 Principal |  | Initial Conversion Price |  | Convertible Date |  | Initial Number of Shares |
| 2023 Notes | 11.2635 |  |  | $ | 88.78 |  |  | April 1, 2023 |  | 19.1 |  |
| 2025 Notes | 10.0806 |  |  | $ | 99.20 |  |  | March 1, 2025 |  | 20.1 |  |

[0001327567-22-000038:notes:49]
Holders of the Notes may surrender their Notes for conversion at their option at any time prior to the close of business on the business day immediately preceding their respective convertible dates only under the following circumstances:

[0001327567-22-000038:notes:50]
•during any fiscal quarter commencing after the fiscal quarters ending on October 31, 2018 and October 31, 2020 for the 2023 Notes and the 2025 Notes, respectively (and only during such fiscal quarter), if the last reported sale price of our common stock for at least 20 trading days (whether or not consecutive) during a period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the applicable conversion price for the respective Notes on each applicable trading day (the “sale price condition”);

[0001327567-22-000038:notes:51]
•during the five business day period after any five consecutive trading day period (the “measurement period”) in which the trading price per $1,000 principal amount of the applicable series of Notes for each trading day of the measurement period was less than 98% of the product of the last reported sale price of our common stock and the applicable conversion rate for the respective Notes on each such trading day; or

[0001327567-22-000038:notes:52]
•upon the occurrence of specified corporate events.

[0001327567-22-000038:notes:53]
On or after the respective convertible date, holders may surrender all or any portion of their Notes for conversion at any time prior to the close of business on the second scheduled trading day immediately preceding the applicable maturity date regardless of the foregoing conditions, and such conversions will be settled upon the applicable maturity date. Upon conversion, holders of the Notes of a series will receive cash equal to the aggregate principal amount of the Notes of such series to be converted, and, at our election, cash and/or shares of our common stock for any amounts in excess of the aggregate principal amount of the Notes of such series being converted.

[0001327567-22-000038:notes:54]
The conversion price will be subject to adjustment in some events. Holders of the Notes of a series who convert their Notes of such series in connection with certain corporate events that constitute a “make-whole fundamental change” under the applicable Indenture are, under certain circumstances, entitled to an increase in the conversion rate for such series of Notes. Additionally, upon the occurrence of a corporate event that constitutes a “fundamental change” under the applicable Indenture, holders of the Notes of such series may require us to repurchase for cash all or a portion of the Notes of such series at a repurchase price equal to 100% of the

[0001327567-22-000038:notes:55]
principal amount of the Notes of such series plus accrued and unpaid interest to, but excluding, the fundamental change repurchase date.

[0001327567-22-000038:notes:56]
The sale price condition for the Notes was met during the fiscal quarter ended October 31, 2022, and as a result, holders may convert their Notes at any time during the fiscal quarter ending January 31, 2023. The net carrying amount of the Notes was classified as a current liability on our condensed consolidated balance sheet as of October 31, 2022.

[0001327567-22-000038:notes:57]
The following table sets forth the components of the Notes (in millions):

[0001327567-22-000038:notes:58]
|  | October 31, 2022 | July 31, 2022 |
|  | 2023 Notes |  | 2025 Notes |  | Total |  | 2023 Notes |  | 2025 Notes |  | Total |
| Liability component: |  |  |  |  |  |  |  |  |  |  |  |
| Principal | $ | 1,691.9 |  |  | $ | 1,999.4 |  |  | $ | 3,691.3 |  |  | $ | 1,691.9 |  |  | $ | 1,999.4 |  |  | $ | 3,691.3 |  |
| Less: debt discount and debt issuance costs, net of amortization | (1.9) |  |  | (10.8) |  |  | (12.7) |  |  | (2.6) |  |  | (11.9) |  |  | (14.5) |  |
| Net carrying amount | $ | 1,690.0 |  |  | $ | 1,988.6 |  |  | $ | 3,678.6 |  |  | $ | 1,689.3 |  |  | $ | 1,987.5 |  |  | $ | 3,676.8 |  |

[0001327567-22-000038:notes:59]
The total estimated fair value of the 2023 Notes and 2025 Notes were $3.3 billion and $3.5 billion at October 31, 2022, respectively, and $3.2 billion and $3.5 billion at July 31, 2022, respectively. The fair value was determined based on the closing trading price per $100 of the applicable series of the Notes as of the last day of trading for the period. We consider the fair value of the Notes at October 31, 2022 and July 31, 2022 to be a Level 2 measurement. The fair value of the Notes is primarily affected by the trading price of our common stock and market interest rates.

[0001327567-22-000038:notes:60]
The following table sets forth interest expense recognized related to the Notes (dollars in millions):

[0001327567-22-000038:notes:61]
|  |  |  | Three Months Ended October 31, |
|  |  |  |  |  | 2022 |  | 2021 |
|  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 2023 Notes |  | 2025 Notes |  | Total |  | 2023 Notes |  | 2025 Notes |  | Total |
| Contractual interest expense |  |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 3.2 |  | $ | 1.8 |  | $ | 5.0 |  |  | $ | 3.2 |  | $ | 1.9 |  | $ | 5.1 |  |
| Amortization of debt issuance costs |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 0.7 |  | 1.1 |  | 1.8 |  |  | 0.7 |  | 1.1 |  | 1.8 |  |
| Total interest expense |  |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 3.9 |  | $ | 2.9 |  | $ | 6.8 |  |  | $ | 3.9 |  | $ | 3.0 |  | $ | 6.9 |  |
| Effective interest rate |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 0.9 | % |  | 0.6 | % |  |  |  | 0.9 | % |  | 0.6 | % |  |  |

[0001327567-22-000038:notes:62]
Note Hedges

[0001327567-22-000038:notes:63]
To minimize the impact of potential economic dilution upon conversion of our Notes, we entered into separate convertible note hedge transactions (the “2023 Note Hedges,” with respect to the 2023 Notes, the “2025 Note Hedges,” with respect to the 2025 Notes, and the 2023 Notes Hedges together with 2025 Note Hedges, the “Note Hedges”) with respect to our common stock concurrent with the issuance of each series of the Notes.

[0001327567-22-000038:notes:64]
The following table presents details of our Note Hedges (in millions):

[0001327567-22-000038:notes:65]
|  | Initial Number of Shares |  | Aggregate Purchase |
| 2023 Note Hedges | 19.1 |  |  | $ | 332.0 |  |
| 2025 Note Hedges | 20.1 |  |  | $ | 370.8 |  |

[0001327567-22-000038:notes:66]
The Note Hedges cover shares of our common stock at a strike price per share that corresponds to the initial applicable conversion price of the applicable series of the Notes, which are also subject to adjustment, and are exercisable upon conversion of the applicable series of the Notes. The Note Hedges will expire upon maturity of the applicable series of the Notes. The Note Hedges are separate transactions and are not part of the terms of the applicable series of the Notes. Holders of the Notes of either series will not have any rights with respect to the Note Hedges. Any shares of our common stock receivable by us under the Note Hedges are excluded from the calculation of diluted earnings per share as they are antidilutive. The aggregate amounts paid for the Note Hedges are included in additional paid-in capital on our condensed consolidated balance sheets.

[0001327567-22-000038:notes:67]
Warrants

[0001327567-22-000038:notes:68]
Separately, but concurrently with the issuance of each series of our Notes, we entered into transactions whereby we sold warrants (the “2023 Warrants,” with respect to the 2023 Notes, the “2025 Warrants,” with respect to the 2025 Notes, and the 2023 Warrants together with the 2025 Warrants, the “Warrants”) to acquire shares of our common stock, subject to anti-dilution adjustments. The 2023 Warrants and 2025 Warrants are exercisable beginning October 2023 and September 2025, respectively.

[0001327567-22-000038:notes:69]
The following table presents details of our Warrants (in millions, except per share data):

[0001327567-22-000038:notes:70]
|  | Initial Number of Shares |  | Strike Price per Share |  | Aggregate Proceeds |
| 2023 Warrants | 19.1 |  |  | $ | 139.27 |  |  | $ | 145.4 |  |
| 2025 Warrants | 20.1 |  |  | $ | 136.16 |  |  | $ | 202.8 |  |

[0001327567-22-000038:notes:71]
The shares issuable under the Warrants will be included in the calculation of diluted earnings per share when the average market value per share of our common stock for the reporting period exceeds the applicable strike price for such series of Warrants. The Warrants are separate transactions and are not part of either series of Notes or Note Hedges and are not remeasured through earnings each reporting period. Holders of the Notes of either series will not have any rights with respect to the Warrants. The aggregate proceeds received from the sale of the Warrants are included in additional paid-in capital on our condensed consolidated balance sheets.

[0001327567-22-000038:notes:72]
Revolving Credit Facility

[0001327567-22-000038:notes:73]
On September 4, 2018, we entered into a credit agreement (the “Credit Agreement”) with certain institutional lenders that provides for a $400.0 million unsecured revolving credit facility (the “Credit Facility”), with an option to increase the amount of the Credit Facility by up to an additional $350.0 million, subject to certain conditions. The Credit Facility matures on the earlier of (i) September 4, 2023 and (ii) the date that is 91 days prior to the stated maturity of our 2023 Notes if (a) any of the 2023 Notes are still outstanding and (b) our unrestricted cash and cash equivalents are less than the then outstanding principal amount of our 2023 Notes plus $400.0 million.

[0001327567-22-000038:notes:74]
The borrowings under the Credit Facility currently bear interest, at our option, at a base rate plus a spread of 0.00% to 0.75%, or an adjusted LIBO Rate plus a spread of 1.00% to 1.75%, in each case with such spread being determined based on our leverage ratio. We are obligated to pay an ongoing commitment fee on undrawn amounts at a rate of 0.125% to 0.250%, depending on our leverage ratio. In March 2021, the ICE Benchmark Administration, the administrator of LIBO Rate, announced that it will cease publication of the LIBO Rate by June 2023. Under the terms of our Credit Facility, in the event of the discontinuance of the LIBO Rate, a mutually agreed-upon alternative benchmark rate will be established to replace the LIBO Rate, which may include the Secured Overnight Financing Rate (“SOFR”). We do not anticipate that the discontinuance of the LIBO Rate will materially impact our liquidity or financial position.

[0001327567-22-000038:notes:75]
As of October 31, 2022, there were no amounts outstanding and we were in compliance with all covenants under the Credit Agreement.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001327567-22-000038:notes:76]
Commitments and Contingencies
Purchase Commitments

[0001327567-22-000038:notes:77]
Manufacturing Purchase Commitments

[0001327567-22-000038:notes:78]
In order to reduce manufacturing lead times and plan for adequate supply, we enter into agreements with manufacturing partners and component suppliers to procure inventory based on our demand forecasts. The following table presents details of the aggregate future minimum or fixed purchase commitments under these arrangements, excluding obligations under contracts that we can cancel as of October 31, 2022 (in millions):

[0001327567-22-000038:notes:79]
|  |  |  | Fiscal years ending July 31, |
|  | Total |  | Remaining 2023 |  | 2024 |  | 2025 |  | 2026 |  | 2027 |  | 2028 and Thereafter |
| Manufacturing purchase commitments | $ | 319.7 |  |  | $ | 189.7 |  |  | $ | 55.0 |  |  | $ | 35.0 |  |  | $ | 40.0 |  |  | $ | — |  |  | $ | — |  |

[0001327567-22-000038:notes:80]
Other Purchase Commitments

[0001327567-22-000038:notes:81]
We have entered into various non-cancelable agreements with certain service providers, under which we are committed to minimum or fixed purchases. The following table presents details of the aggregate future non-cancelable purchase commitments under these agreements as of October 31, 2022 (in millions):

[0001327567-22-000038:notes:82]
|  |  |  | Fiscal years ending July 31, |
|  | Total |  | Remaining 2023 |  | 2024 |  | 2025 |  | 2026 |  | 2027 |  | 2028 and Thereafter |
| Other purchase commitments | $ | 1,801.4 |  |  | $ | 58.1 |  |  | $ | 357.6 |  |  | $ | 413.9 |  |  | $ | 516.3 |  |  | $ | 454.7 |  |  | $ | 0.8 |  |

[0001327567-22-000038:notes:83]
Additionally, we have a $160.6 million minimum purchase commitment with a service provider through September 2027 with no specified annual commitments.

[0001327567-22-000038:notes:84]
Litigation

[0001327567-22-000038:notes:85]
We are subject to legal proceedings, claims, and litigation arising in the ordinary course of business, including intellectual property litigation. Such matters are subject to many uncertainties and outcomes are not predictable with assurance. We accrue for contingencies when we believe that a loss is probable and that we can reasonably estimate the amount of any such loss.

[0001327567-22-000038:notes:86]
To the extent there is a reasonable possibility that a loss exceeding amounts already recognized may be incurred and the amount of such additional loss would be material, we will either disclose the estimated additional loss or state that such an estimate cannot be made. As of October 31, 2022, we have not recorded any significant accruals for loss contingencies associated with such legal proceedings, determined that an unfavorable outcome is probable or reasonably possible, or determined that the amount or range of any possible loss is reasonably estimable.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001327567-22-000038:notes:87]
[same as prior period, unchanged from 0001327567-22-000016:notes:110]

[0001327567-22-000038:notes:88]
In February 2019, our board of directors authorized a $1.0 billion share repurchase program, which is funded from available working capital. In December 2020, August 2021, and August 2022, our board of directors authorized additional $700.0 million, $676.1 million, and $915.0 million increases to this share repurchase program, respectively, bringing the total authorization under this share repurchase program to $3.3 billion (our “current authorization”). The expiration date of our current authorization was extended to December 31, 2023, and our repurchase program may be suspended or discontinued at any time. Repurchases may be made at management’s discretion from time to time on the open market, through privately negotiated transactions, transactions structured through investment banking institutions, block purchase techniques, 10b5-1 trading plans, or a combination of the foregoing.

[0001327567-22-000038:notes:89]
We did not repurchase shares of our common stock during the three months ended October 31, 2022 and 2021. During the three months ended October 31, 2022, we paid $22.7 million related to share repurchases of our common stock that were not settled as of July 31, 2022.

[0001327567-22-000038:notes:90]
As of October 31, 2022, $1.0 billion remained available for future share repurchases under our current repurchase authorization. The total price of the shares repurchased and related transaction costs are reflected as a reduction to common stock and additional paid-in capital on our condensed consolidated balance sheets.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001327567-22-000038:notes:91]
Equity Award Plans
Restricted Stock Unit (“RSU”) and Performance-Based Stock Unit (“PSU”) Activities

[0001327567-22-000038:notes:92]
The following table summarizes the RSU and PSU activity under our stock plans during the three months ended October 31, 2022 (in millions, except per share amounts):

[0001327567-22-000038:notes:93]
|  | RSUs Outstanding |  | PSUs Outstanding |
|  | Number of Shares |  | Weighted-Average Grant-Date Fair Value Per Share |  |  |  | Aggregate Intrinsic Value |  | Number of Shares |  | Weighted-Average Grant-Date Fair Value Per Share |  |  |  | Aggregate Intrinsic Value |
| Balance—July 31, 2022 | 14.8 |  |  | $ | 115.51 |  |  |  |  | $ | 2,456.9 |  |  | 3.1 |  |  | $ | 106.38 |  |  |  |  | $ | 513.7 |  |
| Granted(1) | 1.0 |  |  | $ | 174.04 |  |  |  |  |  |  | 2.6 |  |  | $ | 140.41 |  |  |  |  |  |
| Vested | (1.9) |  |  | $ | 99.25 |  |  |  |  |  |  | (1.1) |  |  | $ | 117.42 |  |  |  |  |  |
| Forfeited | (0.4) |  |  | $ | 113.23 |  |  |  |  |  |  | (0.1) |  |  | $ | 124.01 |  |  |  |  |  |
| Balance—October 31, 2022 | 13.5 |  |  | $ | 122.57 |  |  |  |  | $ | 2,311.7 |  |  | 4.5 |  |  | $ | 123.10 |  |  |  |  | $ | 772.7 |  |

[0001327567-22-000038:notes:94]
______________

[0001327567-22-000038:notes:95]
[same as prior period, unchanged from 0001327567-22-000016:notes:128]

[0001327567-22-000038:notes:96]
Our RSUs generally vest over a period of three to four years from the date of grant. Until vested, RSUs do not have the voting and dividend participation rights of common stock and the shares underlying the awards are not considered issued and outstanding.

[0001327567-22-000038:notes:97]
Our PSUs generally vest over a period of one to four years from the date of grant. The actual number of PSUs earned and eligible to vest is determined based on the level of achievement against certain performance conditions such as revenue growth, billings and operating margin, or individual performance for the fiscal year, or market conditions, or a combination of performance and market conditions for certain awards.

[0001327567-22-000038:notes:98]
During the three months ended October 31, 2022, we granted 0.8 million shares of PSUs with both service and market conditions to certain employees. The market conditions are satisfied when the price of our common stock is equal to or exceeds stock price targets of $233.33, $266.67, $300.00, and $333.33 based on the average closing price for 30 consecutive trading days during the three- or four-year period following the date of grant. To the extent that the market conditions have been met, one-fourth of the awards will vest on each anniversary date of the grant date, subject to continued service. As of October 31, 2022, the stock price targets for these PSU awards have not been met.

[0001327567-22-000038:notes:99]
During the three months ended October 31, 2022 and 2021, we granted 1.6 million and 0.6 million shares of PSUs, respectively, which contain service, performance and market conditions, to certain employees. The service conditions are satisfied over a period of one to three years. The performance conditions are based on revenue growth or billing growth. The market condition is measured based on our total shareholder return (“TSR”) relative to the TSR of the companies listed in the Standard & Poor’s 500 index. As of October 31, 2022, we have approved 2.3 million shares of PSUs, which will be granted upon the performance condition being established during the next two years.

[0001327567-22-000038:notes:100]
The fair value of the PSUs subject to market conditions is estimated on the grant date using a Monte Carlo simulation model. The following table summarizes the assumptions used and the grant-date fair value of these PSUs granted:

[0001327567-22-000038:notes:101]
|  | Three Months Ended |  |  |
|  | October 31, |  |  |
|  | 2022 |  | 2021 |  |  |
| Volatility | 39.6% - 44.8% |  | 36.0% - 38.0% |  |  |
| Expected term (in years) | 1.0 - 4.0 |  | 1.9 - 3.0 |  |  |
| Dividend yield | 0.0 | % |  | 0.0 | % |  |  |
| Risk-free interest rate | 3.2% - 3.6% |  | 0.2% - 0.4% |  |  |
| Grant-date fair value per share | $105.60 - $280.41 |  | $137.16 - $140.22 |  |  |

[0001327567-22-000038:notes:102]
Performance Stock Option (“PSO”) Activities

[0001327567-22-000038:notes:103]
We have granted PSOs with both service and market conditions to certain executives. The market conditions were achieved when certain stock price targets were met. As of October 31, 2022, all stock price targets for our outstanding PSOs have been satisfied. One-fourth of the PSOs will vest on each anniversary date of the grant date, subject to continued service. The contractual term for the PSOs outstanding ranges from seven to seven and a half years following the date of grant in fiscal year 2018 and 2019.

[0001327567-22-000038:notes:104]
The following table summarizes the PSO activity under our stock plans during the three months ended October 31, 2022 (in millions, except per share amounts):

[0001327567-22-000038:notes:105]
|  |  |  | PSOs Outstanding |
|  |  |  |  |  |  |  |  |  | Number of Shares |  | Weighted-Average Exercise Price Per Share |  | Weighted-Average Remaining Contractual Term(Years) |  | Aggregate Intrinsic Value |
| Balance—July 31, 2022 |  |  |  |  |  |  |  |  | 8.0 |  |  | $ | 64.85 |  |  | 3.2 |  | $ | 809.3 |  |
| Balance—October 31, 2022 |  |  |  |  |  |  |  |  | 8.0 |  |  | $ | 64.85 |  |  | 2.9 |  | $ | 851.0 |  |
| Exercisable—October 31, 2022 |  |  |  |  |  |  |  |  | 8.0 |  |  | $ | 64.85 |  |  | 2.9 |  | $ | 851.0 |  |

[0001327567-22-000038:notes:106]
[same as prior period, unchanged from 0001327567-22-000016:notes:131]

[0001327567-22-000038:notes:107]
[same as prior period, unchanged from 0001327567-22-000016:notes:132]

[0001327567-22-000038:notes:108]
|  |  |  | Three Months Ended |
|  |  |  | October 31, |
|  |  |  |  |  | 2022 |  | 2021 |
| Cost of product revenue |  |  |  |  | $ | 2.4 |  |  | $ | 2.3 |  |
| Cost of subscription and support revenue |  |  |  |  | 28.8 |  |  | 26.7 |  |
| Research and development |  |  |  |  | 118.0 |  |  | 125.6 |  |
| Sales and marketing |  |  |  |  | 87.4 |  |  | 73.3 |  |
| General and administrative |  |  |  |  | 29.4 |  |  | 32.4 |  |
| Total share-based compensation |  |  |  |  | $ | 266.0 |  |  | $ | 260.3 |  |

[0001327567-22-000038:notes:109]
As of October 31, 2022, total compensation cost related to unvested share-based awards not yet recognized was $2.0 billion. This cost is expected to be amortized over a weighted-average period of approximately 2.5 years.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001327567-22-000038:notes:110]
Income Taxes
For the three months ended October 31, 2022 and 2021, our provision for income taxes reflected an effective tax rate of 41.9% and negative 13.6%, respectively.

[0001327567-22-000038:notes:111]
Our income taxes for the three months ended October 31, 2022 were primarily due to U.S. taxes, withholding taxes, and foreign income taxes. Our effective tax rate increased compared to the same period last year primarily due to an increase in current U.S. taxes as a result of mandatory capitalization and amortization of research and development expenditures incurred in fiscal year 2023, as required by the 2017 Tax Cuts and Jobs Act (“TCJA”). There is no offsetting deferred benefit due to our valuation allowance.

[0001327567-22-000038:notes:112]
Our income taxes for the three months ended October 31, 2021 were primarily due to foreign income taxes and withholding taxes. Our effective tax rates differed from the U.S. statutory tax rate primarily due to changes in our valuation allowance.


## us-gaap:EarningsPerShareTextBlock

[0001327567-22-000038:notes:113]
Net Income (Loss) Per Share
Basic net income (loss) per share is computed by dividing net income (loss) by basic weighted-average shares outstanding during the period. Diluted net income (loss) per share is computed by dividing net income (loss) by diluted weighted-average shares outstanding during the period giving effect to all potentially dilutive securities to the extent they are dilutive. Potentially dilutive securities include shares issuable upon conversion of our convertible senior notes using the if-converted method. Potentially dilutive securities also include warrants related to the issuance of convertible senior notes and equity awards under our employee equity incentive plans using the treasury stock method.

[0001327567-22-000038:notes:114]
The following table presents the computation of basic and diluted net income (loss) per share of common stock (in millions, except per share data):

[0001327567-22-000038:notes:115]
|  |  |  | Three Months Ended |
|  |  |  | October 31, |
|  |  |  |  |  | 2022 |  | 2021 |
| Net income (loss) |  |  |  |  | $ | 20.0 |  |  | $ | (103.6) |  |
| Weighted-average shares used to compute net income (loss) per share, basic |  |  |  |  | 299.8 |  |  | 292.9 |  |
| Weighted-average effect of potentially dilutive securities: |  |  |  |  |  |  |  |
| Convertible senior notes |  |  |  |  | 17.8 |  |  | — |  |
| Warrants related to the issuance of convertible senior notes |  |  |  |  | 7.8 |  |  | — |  |
| Employee equity incentive plans |  |  |  |  | 13.0 |  |  | — |  |
| Weighted-average shares used to compute net income (loss) per share, diluted |  |  |  |  | 338.4 |  |  | 292.9 |  |
| Net income (loss) per share, basic |  |  |  |  | $ | 0.07 |  |  | $ | (0.35) |  |
| Net income (loss) per share, diluted |  |  |  |  | $ | 0.06 |  |  | $ | (0.35) |  |

[0001327567-22-000038:notes:116]
The following securities were excluded from the computation of diluted net income (loss) per share of common stock as their effect would have been antidilutive or issuance of such shares is contingent upon the satisfaction of certain conditions which were not satisfied by the end of the applicable period (in millions):

[0001327567-22-000038:notes:117]
|  | Three Months Ended |
|  | October 31, |
|  | 2022 |  | 2021 |
| Convertible senior notes | — |  |  | 39.2 |  |
| Warrants related to the issuance of convertible senior notes | — |  |  | 39.2 |  |
| Employee equity incentive plans | 2.7 |  |  | 34.5 |  |
| Total | 2.7 |  |  | 112.9 |  |


## us-gaap:OtherNonoperatingIncomeAndExpenseTextBlock

[0001327567-22-000038:notes:118]
Other Income (Expense), NetThe following table sets forth the components of other income (expense), net (in millions):

[0001327567-22-000038:notes:119]
|  | Three Months Ended |  |  |
|  | October 31, |  |  |
|  | 2022 |  | 2021 |  |  |  |  |
| Interest income | $ | 29.4 |  |  | $ | 1.4 |  |  |  |  |  |
| Foreign currency exchange gains (losses), net | 4.4 |  |  | (3.9) |  |  |  |  |  |
| Other | (7.8) |  |  | 0.9 |  |  |  |  |  |
| Total other income (expense), net | $ | 26.0 |  |  | $ | (1.6) |  |  |  |  |  |


## us-gaap:SubsequentEventsTextBlock

[0001327567-22-000038:notes:120]
Subsequent Event
Business Combination

[0001327567-22-000038:notes:121]
On November 17, 2022, we entered into a definitive agreement to acquire Cider Security Ltd., a privately-held cyber security company, for total consideration of approximately $250.0 million, including approximately $194.6 million in cash and approximately $55.4 million in replacement equity awards, subject to adjustment. We expect the acquisition will support Prisma Cloud’s platform approach to securing the entire application security lifecycle from code-to-cloud. The proposed acquisition is expected to close during our second quarter of fiscal 2023, subject to the satisfaction of customary closing conditions.
