# PANW MD&A — 0001327567-22-000038


## mdna

[0001327567-22-000038:mdna:1]
[same as prior period, unchanged from 0001327567-22-000016:mdna:1]

[0001327567-22-000038:mdna:2]
[same as prior period, unchanged from 0001327567-22-000016:mdna:2]

[0001327567-22-000038:mdna:3]
[same as prior period, unchanged from 0001327567-22-000016:mdna:3]

[0001327567-22-000038:mdna:4]
[same as prior period, unchanged from 0001327567-22-000016:mdna:4]

[0001327567-22-000038:mdna:5]
•Results of Operations. A discussion of the nature and trends in our financial results and an analysis of our financial results comparing the three months ended October 31, 2022 to the three months ended October 31, 2021.

[0001327567-22-000038:mdna:6]
•Liquidity and Capital Resources. An analysis of changes in our balance sheets and cash flows, and a discussion of our financial condition and our ability to meet cash needs.

[0001327567-22-000038:mdna:7]
[same as prior period, unchanged from 0001327567-22-000016:mdna:7]

[0001327567-22-000038:mdna:8]
[same as prior period, unchanged from 0001327567-22-000016:mdna:8]

[0001327567-22-000038:mdna:9]
[same as prior period, unchanged from 0001327567-22-000016:mdna:9]

[0001327567-22-000038:mdna:10]
We empower enterprises, organizations, service providers, and government entities to protect themselves against today’s most sophisticated cyber threats. Our cybersecurity platforms and services help secure enterprise users, networks, clouds, and endpoints by delivering comprehensive cybersecurity backed by industry-leading artificial intelligence and automation. We are a leading provider of zero trust solutions that start with the next-generation of zero trust network access to secure remote workforces and extend into securing all users, applications and infrastructure with zero trust principles. Our security solutions are designed to reduce customers’ total cost of ownership by improving operational efficiency and eliminating the need for siloed point products. Our company focuses on delivering value in five fundamental areas:

[0001327567-22-000038:mdna:11]
- 20 -

[0001327567-22-000038:mdna:12]
[same as prior period, unchanged from 0001327567-22-000016:mdna:14]

[0001327567-22-000038:mdna:13]
[same as prior period, unchanged from 0001327567-22-000016:mdna:11]

[0001327567-22-000038:mdna:14]
•Our network security platform, which includes our ML-Powered Next-Generation Firewalls, available in a number of form factors, including physical, virtual, and containerized appliances, as well as a cloud-delivered service, has been a leader in the industry for ten consecutive years. Our network security platform also includes our Cloud-Delivered Security Services, such as Threat Prevention, Advanced Threat Prevention, WildFire®, Advanced URL Filtering, DNS Security, IoT Security, GlobalProtect™, SD-WAN, Enterprise Data Loss Prevention (“Enterprise DLP”), AIOps, SaaS Security API and SaaS Security Inline. Through these add-on security services, our customers are able to secure their applications, users, devices, and content across our network security platform as well as the Prisma® and Cortex® product lines. Panorama™, our network security management solution, available as hardware or virtual machine, can centrally manage our network security platform irrespective of form factor, location, or scale.

[0001327567-22-000038:mdna:15]
[same as prior period, unchanged from 0001327567-22-000016:mdna:16]

[0001327567-22-000038:mdna:16]
•Prisma Access is our next-generation Zero Trust Network Access (“ZTNA”) platform that provides secure network access for all employees with unified policy management and continuous threat inspection. We have recently introduced ZTNA 2.0, which addresses major shortcomings in the first-generation ZTNA products in the industry (which we refer to as ZTNA 1.0). Prisma Access delivers granular least-privileged access along with continuous trust verification and security inspection and protects security for all applications and data across the enterprise infrastructure. Prisma Access, when combined with Prisma SD-WAN, provides a comprehensive single-vendor Secure Access Service Edge (“SASE”) offering that is used to secure remote workforces and enable the cloud-delivered branch.

[0001327567-22-000038:mdna:17]
[same as prior period, unchanged from 0001327567-22-000016:mdna:18]

[0001327567-22-000038:mdna:18]
•We enable cloud native security through our Prisma Cloud platform. As a comprehensive Cloud Native Application Protection Platform (“CNAPP”), Prisma Cloud secures hybrid and multi-cloud environments for applications, data, and the entire cloud-native technology stack across the full development lifecycle; from code to runtime. For inline network security on multi and hybrid-cloud environments, we also offer our VM-Series and CN-Series Firewall offerings.

[0001327567-22-000038:mdna:19]
Security Operations:

[0001327567-22-000038:mdna:20]
•We deliver the next generation of endpoint security, security analytics and security automation solutions through our Cortex portfolio. These include our industry-leading extended detection and response solution Cortex XDR® to prevent, detect, and respond to complex cybersecurity attacks, Cortex XSOAR® for security orchestration, automation, and response (“SOAR”), and Cortex Xpanse® for attack surface management (“ASM”). In October 2022, we released Cortex XSIAM®, our autonomous Security Operations Services (“SOC”) platform that delivers unified security operations functions including automated threat detection and response, user behavioral analytics, threat intelligence management, orchestration and workflow, endpoint protection, and cloud detection and response. These products are delivered as software or SaaS subscriptions.

[0001327567-22-000038:mdna:21]
[same as prior period, unchanged from 0001327567-22-000016:mdna:22]

[0001327567-22-000038:mdna:22]
•We enable security teams with up-to-date threat intelligence and deep cybersecurity expertise before, during and after attacks through our Unit 42 threat research and security consulting team. Unit 42 offers incident response, risk management, board advisory, proactive cybersecurity assessment services, and managed detection and response and threat hunting services.

[0001327567-22-000038:mdna:23]
For the first quarter of fiscal 2023 and 2022, total revenue was $1.6 billion and $1.2 billion, respectively, representing year-over-year growth of 25.3%. Our growth reflects the increased adoption of our portfolio, which consists of product, subscriptions, and support. We believe our portfolio will enable us to benefit from recurring revenues and new revenues as we continue to grow our end-customer base. As of October 31, 2022, we had end-customers in over 180 countries. Our end-customers represent a broad range of industries, including education, energy, financial services, government entities, healthcare, Internet and media, manufacturing, public sector, and telecommunications, and include almost all of the Fortune 100 companies and a majority of the Global 2000 companies. We maintain a field sales force that works closely with our channel partners in developing sales opportunities. We primarily use a two-tiered, indirect fulfillment model whereby we sell our products, subscriptions, and support to our distributors, which, in turn, sell to our resellers, which then sell to our end-customers.

[0001327567-22-000038:mdna:24]
Our product revenue grew to $330.0 million, or 21.1% of total revenue, for the first quarter of fiscal 2023, representing year-over-year growth of 11.7%. Product revenue is primarily generated from sales of our appliances, primarily our ML-Powered Next-Generation Firewall, which is available in a number of form factors, including as physical, virtual, and containerized appliances. Our ML-Powered Next-Generation Firewall incorporates our PAN-OS operating system, which provides a consistent set of capabilities across our entire network security product line. Our products are designed for different performance requirements throughout an organization, ranging from our PA-410, which is designed for small organizations and remote or branch offices, to our top-of-the-line PA-7080, which is designed for large-scale data centers and service provider use. The same firewall functionality that is delivered in our physical appliances is also available in our VM-Series virtual firewalls, which secure virtualized and cloud-based computing environments, and in our CN-Series container firewalls, which secure container environments and traffic.

[0001327567-22-000038:mdna:25]
- 21 -

[0001327567-22-000038:mdna:26]
[same as prior period, unchanged from 0001327567-22-000016:mdna:28]

[0001327567-22-000038:mdna:27]
Our subscription and support revenue grew to $1.2 billion, or 78.9% of total revenue, for the first quarter of fiscal 2023, representing year-over-year growth of 29.6%. Our subscriptions provide our end-customers with near real-time access to the latest antivirus, intrusion prevention, web filtering, modern malware prevention, data loss prevention, and cloud access security broker capabilities across the network, endpoints, and the cloud. When end-customers purchase our physical, virtual, or container firewall appliances, or certain cloud offerings, they typically purchase support in order to receive ongoing security updates, upgrades, bug fixes, and repairs. In addition to the subscriptions purchased with these appliances, end-customers may also purchase other subscriptions on a per-user, per-endpoint, or capacity-based basis. We also offer professional services, including incident response, risk management, and digital forensic services.

[0001327567-22-000038:mdna:28]
We continue to invest in innovation as we evolve and further extend the capabilities of our portfolio, as we believe that innovation and timely development of new features and products are essential to meeting the needs of our end-customers and improving our competitive position. For example, in October 2022, we announced the general availability of Cortex XSIAM, our autonomous SOC platform that delivers unified security operations functions.

[0001327567-22-000038:mdna:29]
[same as prior period, unchanged from 0001327567-22-000016:mdna:31]

[0001327567-22-000038:mdna:30]
Impact of Macroeconomic Developments and Other Factors on Our Business

[0001327567-22-000038:mdna:31]
Our overall performance depends in part on worldwide economic and geopolitical conditions and their impact on customer behavior. Worsening economic conditions, including inflation, higher interest rates, slower growth, fluctuations in foreign exchange rates, and other changes in economic conditions, may adversely affect our results of operations and financial performance.

[0001327567-22-000038:mdna:32]
We continue to monitor and respond to developments relating to COVID-19, which has resulted in significant global, social, and business disruption. The extent of the continued impact of COVID-19 on our operational and financial performance will depend on developments, including the duration and spread of the virus and its variants, impact on our end-customers’ spending, volume of sales and length of our sales cycles, impact on our partners, suppliers, and employees, actions that may be taken by governmental authorities, and other factors identified in the “Risk Factors” section in Part II, Item 1A of this Quarterly Report on Form 10-Q. The global supply chain and the semiconductor industry continue to experience significant challenges. We have experienced supply chain challenges, including chip and component shortages, which have, in certain cases, caused delays for us in acquiring chips, components and inventory and have resulted in increased costs as compared to historic levels. While we incurred increased costs and experienced increased lead time for certain product deliveries to our end-customers, we continue to work to minimize the effects from supply chain challenges.

[0001327567-22-000038:mdna:33]
- 22 -

[0001327567-22-000038:mdna:34]
[same as prior period, unchanged from 0001327567-22-000016:mdna:36]

[0001327567-22-000038:mdna:35]
[same as prior period, unchanged from 0001327567-22-000016:mdna:37]

[0001327567-22-000038:mdna:36]
We monitor the key financial metrics set forth in the tables below to help us evaluate growth trends, establish budgets, measure the effectiveness of our sales and marketing efforts, and assess operational efficiencies. We discuss revenue, gross margin, and the components of operating income (loss) and margin below under “Results of Operations.”

[0001327567-22-000038:mdna:37]
|  | October 31, 2022 |  | July 31, 2022 |
|  | (in millions) |
| Total deferred revenue | $ | 7,179.6 |  |  | $ | 6,994.0 |  |
| Cash, cash equivalents, and investments | $ | 5,898.4 |  |  | $ | 4,686.4 |  |

[0001327567-22-000038:mdna:38]
|  |  |  | Three Months Ended October 31, |
|  |  |  |  |  | 2022 |  | 2021 |
|  |  |  |  |  | (dollars in millions) |
| Total revenue |  |  |  |  | $ | 1,563.4 |  |  | $ | 1,247.4 |  |
| Total revenue year-over-year percentage increase |  |  |  |  | 25.3 | % |  | 31.9 | % |
| Gross margin |  |  |  |  | 70.5 | % |  | 69.5 | % |
| Operating income (loss) |  |  |  |  | $ | 15.2 |  |  | $ | (82.7) |  |
| Operating margin |  |  |  |  | 1.0 | % |  | (6.6) | % |
| Billings |  |  |  |  | $ | 1,749.0 |  |  | $ | 1,381.6 |  |
| Billings year-over-year percentage increase |  |  |  |  | 26.6 | % |  | 27.6 | % |
| Cash flow provided by operating activities |  |  |  |  | $ | 1,236.7 |  |  | $ | 588.9 |  |
| Free cash flow (non-GAAP) |  |  |  |  | $ | 1,197.1 |  |  | $ | 554.3 |  |

[0001327567-22-000038:mdna:39]
[same as prior period, unchanged from 0001327567-22-000016:mdna:41]

[0001327567-22-000038:mdna:40]
[same as prior period, unchanged from 0001327567-22-000016:mdna:42]

[0001327567-22-000038:mdna:41]
|  |  |  | Three Months Ended October 31, |
|  |  |  |  |  | 2022 |  | 2021 |
|  |  |  | (in millions) |
| Billings: |  |  |  |  |  |  |  |
| Total revenue |  |  |  |  | $ | 1,563.4 |  |  | $ | 1,247.4 |  |
| Add: change in total deferred revenue, net of acquired deferred revenue |  |  |  |  | 185.6 |  |  | 134.2 |  |
| Billings |  |  |  |  | $ | 1,749.0 |  |  | $ | 1,381.6 |  |

[0001327567-22-000038:mdna:42]
[same as prior period, unchanged from 0001327567-22-000016:mdna:44]

[0001327567-22-000038:mdna:43]
[same as prior period, unchanged from 0001327567-22-000016:mdna:13]

[0001327567-22-000038:mdna:44]
[same as prior period, unchanged from 0001327567-22-000016:mdna:46]

[0001327567-22-000038:mdna:45]
•    Free Cash Flow (non-GAAP). We define free cash flow, a non-GAAP financial measure, as cash provided by operating activities less purchases of property, equipment, and other assets. We consider free cash flow to be a profitability and liquidity measure that provides useful information to management and investors about the amount of cash generated by the business after necessary capital expenditures. A limitation of the utility of free cash flow as a measure of our financial performance and liquidity is that it does not represent the total increase or decrease in our cash balance for the period. In addition, it is important to note that other companies, including companies in our industry, may not use free cash flow, may calculate free cash flow in a different manner than we do, or may use other financial measures to evaluate their performance, all of which could reduce the usefulness of free cash flow as a comparative measure. A reconciliation of free cash flow to cash flow provided by operating activities, the most directly comparable financial measure calculated and presented in accordance with GAAP, is provided below:

[0001327567-22-000038:mdna:46]
|  | Three Months Ended October 31, |
|  | 2022 |  | 2021 |
|  | (in millions) |
| Free cash flow (non-GAAP): |  |  |  |
| Net cash provided by operating activities | $ | 1,236.7 |  |  | $ | 588.9 |  |
| Less: purchases of property, equipment, and other assets | 39.6 |  |  | 34.6 |  |
| Free cash flow (non-GAAP) | $ | 1,197.1 |  |  | $ | 554.3 |  |
| Net cash used in investing activities | $ | (1,319.8) |  |  | $ | (229.9) |  |
| Net cash provided by financing activities | $ | 31.1 |  |  | $ | 38.7 |  |

[0001327567-22-000038:mdna:47]
[same as prior period, unchanged from 0001327567-22-000016:mdna:27]

[0001327567-22-000038:mdna:48]
[same as prior period, unchanged from 0001327567-22-000016:mdna:50]

[0001327567-22-000038:mdna:49]
[same as prior period, unchanged from 0001327567-22-000016:mdna:51]

[0001327567-22-000038:mdna:50]
[same as prior period, unchanged from 0001327567-22-000016:mdna:52]

[0001327567-22-000038:mdna:51]
|  |  |  | Three Months Ended October 31, |
|  |  |  |  |  | 2022 |  | 2021 |
|  |  |  |  |  |  |  |  |  | Amount |  | % of Revenue |  | Amount |  | % of Revenue |
|  |  |  |  |  |  |  |  |  | (dollars in millions) |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  |  |  |  |  |  |  |  | $ | 330.0 |  |  | 21.1 | % |  | $ | 295.5 |  |  | 23.7 | % |
| Subscription and support |  |  |  |  |  |  |  |  | 1,233.4 |  |  | 78.9 | % |  | 951.9 |  |  | 76.3 | % |
| Total revenue |  |  |  |  |  |  |  |  | 1,563.4 |  |  | 100.0 | % |  | 1,247.4 |  |  | 100.0 | % |
| Cost of revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  |  |  |  |  |  |  |  | 120.1 |  |  | 7.7 | % |  | 88.9 |  |  | 7.1 | % |
| Subscription and support |  |  |  |  |  |  |  |  | 341.8 |  |  | 21.8 | % |  | 291.7 |  |  | 23.4 | % |
| Total cost of revenue(1) |  |  |  |  |  |  |  |  | 461.9 |  |  | 29.5 | % |  | 380.6 |  |  | 30.5 | % |
| Total gross profit |  |  |  |  |  |  |  |  | 1,101.5 |  |  | 70.5 | % |  | 866.8 |  |  | 69.5 | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development |  |  |  |  |  |  |  |  | 371.8 |  |  | 23.8 | % |  | 339.5 |  |  | 27.2 | % |
| Sales and marketing |  |  |  |  |  |  |  |  | 615.0 |  |  | 39.3 | % |  | 505.9 |  |  | 40.6 | % |
| General and administrative |  |  |  |  |  |  |  |  | 99.5 |  |  | 6.4 | % |  | 104.1 |  |  | 8.3 | % |
| Total operating expenses(1) |  |  |  |  |  |  |  |  | 1,086.3 |  |  | 69.5 | % |  | 949.5 |  |  | 76.1 | % |
| Operating income (loss) |  |  |  |  |  |  |  |  | 15.2 |  |  | 1.0 | % |  | (82.7) |  |  | (6.6) | % |
| Interest expense |  |  |  |  |  |  |  |  | (6.8) |  |  | (0.4) | % |  | (6.9) |  |  | (0.6) | % |
| Other income (expense), net |  |  |  |  |  |  |  |  | 26.0 |  |  | 1.6 | % |  | (1.6) |  |  | (0.1) | % |
| Income (loss) before income taxes |  |  |  |  |  |  |  |  | 34.4 |  |  | 2.2 | % |  | (91.2) |  |  | (7.3) | % |
| Provision for income taxes |  |  |  |  |  |  |  |  | 14.4 |  |  | 0.9 | % |  | 12.4 |  |  | 1.0 | % |
| Net income (loss) |  |  |  |  |  |  |  |  | $ | 20.0 |  |  | 1.3 | % |  | $ | (103.6) |  |  | (8.3) | % |

[0001327567-22-000038:mdna:52]
[same as prior period, unchanged from 0001327567-22-000016:mdna:54]

[0001327567-22-000038:mdna:53]
[same as prior period, unchanged from 0001327567-22-000016:mdna:55]

[0001327567-22-000038:mdna:54]
|  |  |  | Three Months Ended October 31, |
|  |  |  |  |  | 2022 |  | 2021 |
|  |  |  |  |  | (in millions) |
| Cost of product revenue |  |  |  |  | $ | 2.4 |  |  | $ | 2.3 |  |
| Cost of subscription and support revenue |  |  |  |  | 28.8 |  |  | 26.7 |  |
| Research and development |  |  |  |  | 118.0 |  |  | 125.6 |  |
| Sales and marketing |  |  |  |  | 87.4 |  |  | 73.3 |  |
| General and administrative |  |  |  |  | 29.4 |  |  | 32.4 |  |
| Total share-based compensation |  |  |  |  | $ | 266.0 |  |  | $ | 260.3 |  |

[0001327567-22-000038:mdna:55]
[same as prior period, unchanged from 0001327567-22-000016:mdna:57]

[0001327567-22-000038:mdna:56]
[same as prior period, unchanged from 0001327567-22-000016:mdna:58]

[0001327567-22-000038:mdna:57]
[same as prior period, unchanged from 0001327567-22-000016:mdna:35]

[0001327567-22-000038:mdna:58]
[same as prior period, unchanged from 0001327567-22-000016:mdna:60]

[0001327567-22-000038:mdna:59]
[same as prior period, unchanged from 0001327567-22-000016:mdna:61]

[0001327567-22-000038:mdna:60]
[same as prior period, unchanged from 0001327567-22-000016:mdna:62]

[0001327567-22-000038:mdna:61]
|  |  |  |  |  |  |  | Three Months Ended October 31, |  |  |  |  |
|  |  |  |  |  |  |  | 2022 |  | 2021 |  | Change |
|  |  |  |  |  |  |  |  |  | Amount |  | Amount |  | Amount |  | % |
|  |  |  |  |  |  |  |  |  | (dollars in millions) |
| Product |  |  |  |  |  |  |  |  | $ | 330.0 |  |  | $ | 295.5 |  |  | $ | 34.5 |  |  | 11.7 | % |

[0001327567-22-000038:mdna:62]
Product revenue for the three months ended October 31, 2022 increased compared to the same period in 2021, primarily due to increased demand for our new and existing product offerings.

[0001327567-22-000038:mdna:63]
[same as prior period, unchanged from 0001327567-22-000016:mdna:65]

[0001327567-22-000038:mdna:64]
[same as prior period, unchanged from 0001327567-22-000016:mdna:66]

[0001327567-22-000038:mdna:65]
|  |  |  |  |  |  |  | Three Months Ended October 31, |  |  |  |  |
|  |  |  |  |  |  |  | 2022 |  | 2021 |  | Change |
|  |  |  |  |  |  |  |  |  | Amount |  | Amount |  | Amount |  | % |
|  |  |  |  |  |  |  |  |  | (dollars in millions) |
| Subscription |  |  |  |  |  |  |  |  | $ | 764.0 |  |  | $ | 578.8 |  |  | $ | 185.2 |  |  | 32.0 | % |
| Support |  |  |  |  |  |  |  |  | 469.4 |  |  | 373.1 |  |  | 96.3 |  |  | 25.8 | % |
| Total subscription and support |  |  |  |  |  |  |  |  | $ | 1,233.4 |  |  | $ | 951.9 |  |  | $ | 281.5 |  |  | 29.6 | % |

[0001327567-22-000038:mdna:66]
Subscription and support revenue increased for the three months ended October 31, 2022 compared to the same period in 2021 due to increased demand for our subscription and support offerings from our end-customers. The mix between subscription revenue and support revenue will fluctuate over time, depending on the introduction of new subscription offerings, renewals of support services, and our ability to increase sales to new and existing end-customers.

[0001327567-22-000038:mdna:67]
[same as prior period, unchanged from 0001327567-22-000016:mdna:69]

[0001327567-22-000038:mdna:68]
|  |  |  |  |  |  |  | Three Months Ended October 31, |  |  |  |  |
|  |  |  |  |  |  |  | 2022 |  | 2021 |  | Change |
|  |  |  |  |  |  |  |  |  | Amount |  | Amount |  | Amount |  | % |
|  |  |  |  |  |  |  |  |  | (dollars in millions) |
| Americas |  |  |  |  |  |  |  |  | $ | 1,070.7 |  |  | $ | 866.7 |  |  | $ | 204.0 |  |  | 23.5 | % |
| EMEA |  |  |  |  |  |  |  |  | 307.9 |  |  | 233.8 |  |  | 74.1 |  |  | 31.7 | % |
| APAC |  |  |  |  |  |  |  |  | 184.8 |  |  | 146.9 |  |  | 37.9 |  |  | 25.8 | % |
| Total revenue |  |  |  |  |  |  |  |  | $ | 1,563.4 |  |  | $ | 1,247.4 |  |  | $ | 316.0 |  |  | 25.3 | % |

[0001327567-22-000038:mdna:69]
With respect to geographic theaters, the increase in revenue for the three months ended October 31, 2022 compared to the same periods in 2021 was driven primarily by the Americas, due to its larger sales force and a larger percentage of our customers located in the Americas. Revenue from our other geographic theaters, both Europe, the Middle East, and Africa (“EMEA”) and Asia Pacific and Japan (“APAC”), increased for the three months ended October 31, 2022 compared to the same periods in 2021 due to continued investment in our global sales force to support our growth and increase our customer base in the regions.

[0001327567-22-000038:mdna:70]
[same as prior period, unchanged from 0001327567-22-000016:mdna:72]

[0001327567-22-000038:mdna:71]
[same as prior period, unchanged from 0001327567-22-000016:mdna:73]

[0001327567-22-000038:mdna:72]
[same as prior period, unchanged from 0001327567-22-000016:mdna:45]

[0001327567-22-000038:mdna:73]
[same as prior period, unchanged from 0001327567-22-000016:mdna:75]

[0001327567-22-000038:mdna:74]
[same as prior period, unchanged from 0001327567-22-000016:mdna:76]

[0001327567-22-000038:mdna:75]
Cost of product revenue primarily includes costs paid to our manufacturing partners for procuring components and manufacturing our products. Our cost of product revenue also includes personnel costs, which consist of salaries, benefits, bonuses, share-based compensation and travel and entertainment associated with our operations organization, amortization of intellectual property licenses, product testing costs, shipping and tariff costs, and shared costs. Shared costs consist of certain facilities, depreciation, benefits, recruiting, and information technology costs that we allocate based on headcount. We expect our cost of product revenue to fluctuate with our product revenue.

[0001327567-22-000038:mdna:76]
|  |  |  |  |  |  |  | Three Months Ended October 31, |  |  |  |  |
|  |  |  |  |  |  |  | 2022 |  | 2021 |  | Change |
|  |  |  |  |  |  |  |  |  | Amount |  | Amount |  | Amount |  | % |
|  |  |  |  |  |  |  |  |  | (dollars in millions) |
| Cost of product revenue |  |  |  |  |  |  |  |  | $ | 120.1 |  |  | $ | 88.9 |  |  | $ | 31.2 |  |  | 35.1 | % |
| Number of employees at period end |  |  |  |  |  |  |  |  | 154 |  |  | 130 |  |  | 24 |  |  | 18.5 | % |

[0001327567-22-000038:mdna:77]
Cost of product revenue increased for the three months ended October 31, 2022 compared to the same period in 2021 due to an increase in product volume and higher costs related to our product offerings, primarily driven by supply chain challenges.

[0001327567-22-000038:mdna:78]
[same as prior period, unchanged from 0001327567-22-000016:mdna:80]

[0001327567-22-000038:mdna:79]
Cost of subscription and support revenue includes personnel costs for our global customer support and technical operations organizations, customer support and repair costs, third-party professional services costs, data center and cloud hosting service costs, amortization of acquired intangible assets and capitalized software development costs, and shared costs. We expect our cost of subscription and support revenue to increase as our installed end-customer base grows and adoption of our cloud-based subscription offerings increases.

[0001327567-22-000038:mdna:80]
|  |  |  |  |  |  |  | Three Months Ended October 31, |  |  |  |  |
|  |  |  |  |  |  |  | 2022 |  | 2021 |  | Change |
|  |  |  |  |  |  |  |  |  | Amount |  | Amount |  | Amount |  | % |
|  |  |  |  |  |  |  |  |  | (dollars in millions) |
| Cost of subscription and support revenue |  |  |  |  |  |  |  |  | $ | 341.8 |  |  | $ | 291.7 |  |  | $ | 50.1 |  |  | 17.2 | % |
| Number of employees at period end |  |  |  |  |  |  |  |  | 2,616 |  |  | 2,321 |  |  | 295 |  |  | 12.7 | % |

[0001327567-22-000038:mdna:81]
Cost of subscription and support revenue increased for the three months ended October 31, 2022 compared to the same period in 2021, primarily due to increased costs to support the growth of our subscription and support offerings. Personnel costs grew $19.8 million to $142.6 million, primarily due to headcount growth. The remaining increase was primarily due to increased cloud hosting service costs to support our cloud-based subscription offerings and increased shared costs.

[0001327567-22-000038:mdna:82]
[same as prior period, unchanged from 0001327567-22-000016:mdna:84]

[0001327567-22-000038:mdna:83]
Gross margin has been and will continue to be affected by a variety of factors, including the introduction of new products, manufacturing costs, the average sales price of our products, cloud hosting service costs, personnel costs, the mix of products sold, and the mix of revenue between product and subscription and support offerings. Our virtual and higher-end firewall products generally have higher gross margins than our lower-end firewall products within each product series. We expect our gross margins to vary over time depending on the factors described above.

[0001327567-22-000038:mdna:84]
|  |  |  | Three Months Ended October 31, |
|  |  |  |  |  | 2022 |  | 2021 |
|  |  |  |  |  |  |  |  |  | Amount |  | Gross Margin |  | Amount |  | Gross Margin |
|  |  |  |  |  |  |  |  |  | (dollars in millions) |
| Product |  |  |  |  |  |  |  |  | $ | 209.9 |  |  | 63.6 | % |  | $ | 206.6 |  |  | 69.9 | % |
| Subscription and support |  |  |  |  |  |  |  |  | 891.6 |  |  | 72.3 | % |  | 660.2 |  |  | 69.4 | % |
| Total gross profit |  |  |  |  |  |  |  |  | $ | 1,101.5 |  |  | 70.5 | % |  | $ | 866.8 |  |  | 69.5 | % |

[0001327567-22-000038:mdna:85]
Product gross margin decreased for the three months ended October 31, 2022 compared to the same period in 2021, primarily due to higher costs related to our product offerings driven by supply chain challenges.

[0001327567-22-000038:mdna:86]
Subscription and support gross margin increased for the three months ended October 31, 2022 compared to the same period in 2021, primarily due to our growth in subscription and support revenue, which outpaced the subscription and support costs.

[0001327567-22-000038:mdna:87]
[same as prior period, unchanged from 0001327567-22-000016:mdna:49]

[0001327567-22-000038:mdna:88]
[same as prior period, unchanged from 0001327567-22-000016:mdna:88]

[0001327567-22-000038:mdna:89]
[same as prior period, unchanged from 0001327567-22-000016:mdna:91]

[0001327567-22-000038:mdna:90]
Our operating expenses consist of research and development, sales and marketing, and general and administrative expenses. Personnel costs are the most significant component of operating expenses and consist of salaries, benefits, bonuses, share-based compensation, travel and entertainment, and with regard to sales and marketing expense, sales commissions. Our operating expenses also include shared costs, which consist of certain facilities, depreciation, benefits, recruiting, and information technology costs that we allocate based on headcount to each department. We expect operating expenses generally to increase in absolute dollars and decrease over the long term as a percentage of revenue as we continue to scale our business. As of October 31, 2022, we expect to recognize approximately $2.0 billion of share-based compensation expense over a weighted-average period of approximately 2.5 years, excluding additional share-based compensation expense related to any future grants of share-based awards. Share-based compensation expense is generally recognized on a straight-line basis over the requisite service periods of the awards.

[0001327567-22-000038:mdna:91]
[same as prior period, unchanged from 0001327567-22-000016:mdna:93]

[0001327567-22-000038:mdna:92]
[same as prior period, unchanged from 0001327567-22-000016:mdna:94]

[0001327567-22-000038:mdna:93]
|  |  |  |  |  |  |  | Three Months Ended October 31, |  |  |  |  |
|  |  |  |  |  |  |  | 2022 |  | 2021 |  | Change |
|  |  |  |  |  |  |  |  |  | Amount |  | Amount |  | Amount |  | % |
|  |  |  |  |  |  |  |  |  | (dollars in millions) |
| Research and development |  |  |  |  |  |  |  |  | $ | 371.8 |  |  | $ | 339.5 |  |  | $ | 32.3 |  |  | 9.5 | % |
| Number of employees at period end |  |  |  |  |  |  |  |  | 3,532 |  |  | 2,745 |  |  | 787 |  |  | 28.7 | % |

[0001327567-22-000038:mdna:94]
Research and development expense increased for the three months ended October 31, 2022 compared to the same period in 2021, primarily due to an increase in personnel costs, which grew $23.2 million to $290.1 million, largely due to headcount growth. The remaining increase in research and development expense was further driven by increased shared costs.

[0001327567-22-000038:mdna:95]
[same as prior period, unchanged from 0001327567-22-000016:mdna:97]

[0001327567-22-000038:mdna:96]
Sales and marketing expense consists primarily of personnel costs, including commission expense. Sales and marketing expense also includes costs for market development programs, promotional and other marketing costs, professional services, and shared costs. We continue to strategically invest in headcount and have grown our sales presence. We expect sales and marketing expense to continue to increase in absolute dollars as we increase the size of our sales and marketing organizations to grow our customer base, increase touch points with end-customers, and expand our global presence, although our sales and marketing expense may fluctuate as a percentage of total revenue.

[0001327567-22-000038:mdna:97]
|  |  |  |  |  |  |  | Three Months Ended October 31, |  |  |  |  |
|  |  |  |  |  |  |  | 2022 |  | 2021 |  | Change |
|  |  |  |  |  |  |  |  |  | Amount |  | Amount |  | Amount |  | % |
|  |  |  |  |  |  |  |  |  | (dollars in millions) |
| Sales and marketing |  |  |  |  |  |  |  |  | $ | 615.0 |  |  | $ | 505.9 |  |  | $ | 109.1 |  |  | 21.6 | % |
| Number of employees at period end |  |  |  |  |  |  |  |  | 5,616 |  |  | 4,664 |  |  | 952 |  |  | 20.4 | % |

[0001327567-22-000038:mdna:98]
Sales and marketing expense increased for the three months ended October 31, 2022 compared to the same period in 2021, primarily due to an increase in personnel costs, which grew $75.1 million to $456.1 million, largely due to headcount growth and increased travel and entertainment expenses. The increase in sales and marketing expense was further driven by increased costs associated with in-person events and go-to-market initiatives, and increased shared costs.

[0001327567-22-000038:mdna:99]
[same as prior period, unchanged from 0001327567-22-000016:mdna:59]

[0001327567-22-000038:mdna:100]
[same as prior period, unchanged from 0001327567-22-000016:mdna:102]

[0001327567-22-000038:mdna:101]
[same as prior period, unchanged from 0001327567-22-000016:mdna:103]

[0001327567-22-000038:mdna:102]
General and administrative expense consists primarily of personnel costs and shared costs for our executive, finance, human resources, information technology, and legal organizations, and professional services costs, which consist primarily of legal, auditing, accounting, and other consulting costs. We expect general and administrative expense to increase in absolute dollars over time as we increase the size of our general and administrative organizations and incur additional costs to support our business growth, although our general and administrative expense may fluctuate as a percentage of total revenue.

[0001327567-22-000038:mdna:103]
|  |  |  |  |  |  |  | Three Months Ended October 31, |  |  |  |  |
|  |  |  |  |  |  |  | 2022 |  | 2021 |  | Change |
|  |  |  |  |  |  |  |  |  | Amount |  | Amount |  | Amount |  | % |
|  |  |  |  |  |  |  |  |  | (dollars in millions) |
| General and administrative |  |  |  |  |  |  |  |  | $ | 99.5 |  |  | $ | 104.1 |  |  | $ | (4.6) |  |  | (4.4) | % |
| Number of employees at period end |  |  |  |  |  |  |  |  | 1,595 |  |  | 1,238 |  |  | 357 |  |  | 28.8 | % |

[0001327567-22-000038:mdna:104]
General and administrative expense decreased for the three months ended October 31, 2022 compared to the same period in 2021 primarily due to a decrease in professional services expense and acquisition-related costs, partially offset by a modest increase in personnel costs.

[0001327567-22-000038:mdna:105]
[same as prior period, unchanged from 0001327567-22-000016:mdna:107]

[0001327567-22-000038:mdna:106]
Interest expense primarily consists of interest expense related to our 0.75% Convertible Senior Notes due 2023 (the “2023 Notes”) and the 0.375% Convertible Senior Notes due 2025 (the “2025 Notes,” and together with “2023 Notes,” the “Notes”).

[0001327567-22-000038:mdna:107]
|  |  |  |  |  | Three Months Ended October 31, |  |  |
|  |  |  |  |  |  |  | 2022 |  | 2021 |  | Change |
|  |  |  |  |  |  |  |  |  | Amount |  | Amount |  | Amount |  | % |
|  |  |  |  |  |  |  |  |  | (dollars in millions) |
| Interest expense |  |  |  |  |  |  |  |  | $ | 6.8 |  |  | $ | 6.9 |  |  | $ | (0.1) |  |  | (1.4) | % |

[0001327567-22-000038:mdna:108]
Interest expense was relatively flat for the three months ended October 31, 2022 compared to the same period in 2021.

[0001327567-22-000038:mdna:109]
Other Income (Expense), Net

[0001327567-22-000038:mdna:110]
Other income (expense), net includes interest income earned on our cash, cash equivalents, and investments, and gains and losses from foreign currency remeasurement and foreign currency transactions.

[0001327567-22-000038:mdna:111]
|  |  |  |  |  | Three Months Ended October 31, |  |  |
|  |  |  |  |  |  |  | 2022 |  | 2021 |  | Change |
|  |  |  |  |  |  |  |  |  | Amount |  | Amount |  | Amount |  | % |
|  |  |  |  |  |  |  |  |  | (dollars in millions) |
| Other income (expense), net |  |  |  |  |  |  |  |  | $ | 26.0 |  |  | $ | (1.6) |  |  | $ | 27.6 |  |  | * |

[0001327567-22-000038:mdna:112]
[same as prior period, unchanged from 0001327567-22-000016:mdna:123]

[0001327567-22-000038:mdna:113]
*    Not meaningful

[0001327567-22-000038:mdna:114]
The increase in other income (expense), net for the three months ended October 31, 2022 compared to the same period in 2021 was primarily due to higher interest income earned on our cash, cash equivalent, and investment balances as a result of higher interest rates for the three months ended October 31, 2022 compared to 2021, and increased foreign currency exchange gains, partially offset by increased losses from our investments and non-designated derivative instruments.

[0001327567-22-000038:mdna:115]
[same as prior period, unchanged from 0001327567-22-000016:mdna:74]

[0001327567-22-000038:mdna:116]
[same as prior period, unchanged from 0001327567-22-000016:mdna:116]

[0001327567-22-000038:mdna:117]
Provision for Income Taxes

[0001327567-22-000038:mdna:118]
Provision for income taxes consists primarily of U.S. taxes driven by capitalization of research and development expenditures, foreign income taxes, and withholding taxes. We maintain a full valuation allowance for domestic and certain foreign deferred tax assets, including net operating loss carryforwards and certain domestic tax credits. Our valuation allowance has caused, and may continue to cause, disproportionate relationships between our overall effective tax rate and other jurisdictional measures.

[0001327567-22-000038:mdna:119]
|  |  |  |  |  |  |  |  |  | Three Months Ended October 31, |  |  |  |  |
|  |  |  |  |  | 2022 |  | 2021 |  | Change |
|  |  |  |  |  |  |  |  |  | Amount |  | Amount |  | Amount |  | % |
|  |  |  |  |  |  |  |  |  | (dollars in millions) |
| Provision for income taxes |  |  |  |  |  |  |  |  | $ | 14.4 |  |  | $ | 12.4 |  |  | $ | 2.0 |  |  | 16.1 | % |
| Effective tax rate |  |  |  |  |  |  |  |  | 41.9 | % |  | (13.6) | % |  |  |  |  |

[0001327567-22-000038:mdna:120]
Our provision for income taxes for the three months ended October 31, 2022 was primarily due to U.S. taxes driven by capitalization of research and development expenditures, withholding taxes, and foreign income taxes. Our income taxes for the three months ended October 31, 2021 was primarily due to income taxes in profitable foreign jurisdictions and withholding taxes. Our effective tax rate varied for the three months ended October 31, 2022 compared to the same period in 2021, primarily due to an increase in current taxes with no offsetting deferred benefit as a result of our valuation allowance. Refer to Note 12. Income Taxes in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information.

[0001327567-22-000038:mdna:121]
[same as prior period, unchanged from 0001327567-22-000016:mdna:121]

[0001327567-22-000038:mdna:122]
|  | October 31, 2022 |  | July 31, 2022 |
|  | (in millions) |
| Working capital(1) | $ | (2,461.6) |  |  | $ | (1,891.4) |  |
| Cash, cash equivalents, and investments: |  |  |  |
| Cash and cash equivalents | $ | 2,067.2 |  |  | $ | 2,118.5 |  |
| Investments | 3,831.2 |  |  | 2,567.9 |  |
| Total cash, cash equivalents, and investments | $ | 5,898.4 |  |  | $ | 4,686.4 |  |

[0001327567-22-000038:mdna:123]
______________

[0001327567-22-000038:mdna:124]
(1)Current liabilities included net carrying amounts of convertible senior notes of $3.7 billion as of both October 31, 2022 and July 31, 2022. Refer to Note 8. Debt in Part I, Item 1 of this Quarterly Report on Form 10-Q for information on the Notes.

[0001327567-22-000038:mdna:125]
As of October 31, 2022, our total cash, cash equivalents, and investments of $5.9 billion were held for general corporate purposes. As of October 31, 2022, we had no unremitted earnings when evaluating our outside basis difference relating to our U.S. investment in foreign subsidiaries. However, there could be local withholding taxes payable due to various foreign countries if certain lower tier earnings are distributed. Withholding taxes that would be payable upon remittance of these lower tier earnings are not expected to be material.

[0001327567-22-000038:mdna:126]
[same as prior period, unchanged from 0001327567-22-000016:mdna:126]

[0001327567-22-000038:mdna:127]
In July 2018, we issued the 2023 Notes with an aggregate principal amount of $1.7 billion. In June 2020, we issued the 2025 Notes with an aggregate principal amount of $2.0 billion. The 2023 Notes mature on July 1, 2023 and the 2025 Notes mature on June 1, 2025; however, under certain circumstances, holders may surrender their Notes of a series for conversion prior to the applicable maturity date. Upon conversion of the Notes of a series, we will pay cash equal to the aggregate principal amount of the Notes of such series to be converted, and, at our election, will pay or deliver cash and/or shares of our common stock for the amount of our conversion obligation in excess of the aggregate principal amount of the Notes of such series being converted. The sale price condition for the Notes was met during the fiscal quarter ended October 31, 2022, and as a result, holders may convert their Notes at any time during the fiscal quarter ending January 31, 2023. If all of the holders of the Notes converted their Notes during this period, we would be obligated to settle the $3.7 billion principal amount of the Notes in cash. We believe that our cash provided by operating activities, our existing cash, cash equivalents and investments, and existing sources of and access to financing will be sufficient to meet our anticipated cash needs should the holders choose to convert their Notes during the fiscal quarter ending January 31, 2023 or hold the 2023 Notes until maturity on July 1, 2023. As of October 31, 2022, substantially all of our Notes remained outstanding. Refer to Note 8. Debt in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information on the Notes.

[0001327567-22-000038:mdna:128]
In September 2018, we entered into a credit agreement (the “Credit Agreement”) that provides for a $400.0 million unsecured revolving credit facility (the “Credit Facility”), with an option to increase the amount of the Credit Facility up to an additional $350.0 million, subject to certain conditions. As of October 31, 2022, there were no amounts outstanding and we were in compliance

[0001327567-22-000038:mdna:129]
[same as prior period, unchanged from 0001327567-22-000016:mdna:87]

[0001327567-22-000038:mdna:130]
[same as prior period, unchanged from 0001327567-22-000016:mdna:130]

[0001327567-22-000038:mdna:131]
with all covenants under the Credit Agreement. Refer to Note 8. Debt in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information on the Credit Agreement.

[0001327567-22-000038:mdna:132]
[same as prior period, unchanged from 0001327567-22-000016:mdna:131]

[0001327567-22-000038:mdna:133]
In February 2019, our board of directors authorized a $1.0 billion share repurchase program. In December 2020, August 2021, and August 2022, our board of directors authorized additional $700.0 million, $676.1 million, and $915.0 million increases to this share repurchase program, respectively, bringing the total authorization under this share repurchase program to $3.3 billion. Repurchases will be funded from available working capital and may be made at management’s discretion from time to time. The expiration date of this repurchase authorization was extended to December 31, 2023, and our repurchase program may be suspended or discontinued at any time. As of October 31, 2022, $1.0 billion remained available for future share repurchases under this repurchase program. Refer to Note 10. Stockholders’ Equity in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information on this repurchase program.

[0001327567-22-000038:mdna:134]
[same as prior period, unchanged from 0001327567-22-000016:mdna:133]

[0001327567-22-000038:mdna:135]
We have entered into various non-cancelable operating leases primarily for our facilities with original lease periods expiring through the year ending July 31, 2032, with the most significant leases relating to our corporate headquarters in Santa Clara, California. As of October 31, 2022, we have total operating lease obligations of $346.1 million recorded on our condensed consolidated balance sheet.

[0001327567-22-000038:mdna:136]
As of October 31, 2022, our commitments to purchase products, components, cloud and other services totaled $2.3 billion. Refer to Note 9. Commitments and Contingencies in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information on these commitments.

[0001327567-22-000038:mdna:137]
[same as prior period, unchanged from 0001327567-22-000016:mdna:136]

[0001327567-22-000038:mdna:138]
The following table summarizes our cash flows for the three months ended October 31, 2022 and 2021:

[0001327567-22-000038:mdna:139]
|  | Three Months Ended October 31, |
|  | 2022 |  | 2021 |
|  | (in millions) |
| Net cash provided by operating activities | $ | 1,236.7 |  |  | $ | 588.9 |  |
| Net cash used in investing activities | (1,319.8) |  |  | (229.9) |  |
| Net cash provided by financing activities | 31.1 |  |  | 38.7 |  |
| Net increase (decrease) in cash, cash equivalents, and restricted cash | $ | (52.0) |  |  | $ | 397.7 |  |

[0001327567-22-000038:mdna:140]
Cash from operations could be affected by various risks and uncertainties, including, but not limited to, the effects of COVID-19 and other risks detailed in Part II, Item 1A “Risk Factors” in this Quarterly Report on Form 10-Q. We believe that our cash flow from operations with existing cash and cash equivalents will be sufficient to meet our anticipated cash needs for at least the next 12 months and thereafter for the foreseeable future. Our future capital requirements will depend on many factors, including our growth rate, the timing and extent of spending to support development efforts, the expansion of sales and marketing activities, the introduction of new and enhanced products and subscription and support offerings, the costs to acquire or invest in complementary businesses and technologies, the costs to ensure access to adequate manufacturing capacity, the investments in our infrastructure to support the adoption of our cloud-based subscription offerings, the repayment obligations associated with our Notes, the continuing market acceptance of our products and subscription and support offerings and macroeconomic events such as COVID-19. In addition, from time to time, we may incur additional tax liability in connection with certain corporate structuring decisions.

[0001327567-22-000038:mdna:141]
[same as prior period, unchanged from 0001327567-22-000016:mdna:140]

[0001327567-22-000038:mdna:142]
[same as prior period, unchanged from 0001327567-22-000016:mdna:141]

[0001327567-22-000038:mdna:143]
Our operating activities have consisted of net income (losses) adjusted for certain non-cash items and changes in assets and liabilities. Our largest source of cash provided by our operations is receipts from our product revenue and subscription and support revenue.

[0001327567-22-000038:mdna:144]
Cash provided by operating activities during the three months ended October 31, 2022 was $1.2 billion, an increase of $647.8 million compared to the same period in 2021. The increase was primarily due to growth of our business as reflected by increases in collections during the three months ended October 31, 2022, partially offset by higher cash expenditure to support our business growth.

[0001327567-22-000038:mdna:145]
[same as prior period, unchanged from 0001327567-22-000016:mdna:101]

[0001327567-22-000038:mdna:146]
[same as prior period, unchanged from 0001327567-22-000016:mdna:148]

[0001327567-22-000038:mdna:147]
[same as prior period, unchanged from 0001327567-22-000016:mdna:144]

[0001327567-22-000038:mdna:148]
[same as prior period, unchanged from 0001327567-22-000016:mdna:145]

[0001327567-22-000038:mdna:149]
Cash used in investing activities during the three months ended October 31, 2022 was $1.3 billion, a increase of $1.1 billion compared to the same period in 2021. The increase was primarily due to an increase in purchases of investments, offset by an increase in proceeds from sales and maturities of investments and a decrease in net cash payments for business acquisitions during the three months ended October 31, 2022.

[0001327567-22-000038:mdna:150]
[same as prior period, unchanged from 0001327567-22-000016:mdna:150]

[0001327567-22-000038:mdna:151]
Our financing activities have consisted of cash used to repurchase shares of our common stock, proceeds from sales of shares through employee equity incentive plans, and payments for tax withholding obligations of certain employees related to the net share settlement of equity awards.

[0001327567-22-000038:mdna:152]
Cash provided by financing activities during the three months ended October 31, 2022 was $31.1 million, a decrease of $7.6 million compared to the same period in 2021. The decrease was primarily due to payments made for share repurchases of our common stock that were not settled as of July 31, 2022, offset by an increase in proceeds from the sale of shares through employee equity incentive plans and a decrease in payments for tax withholding obligations of certain employees related to the net share settlement of equity awards during the three months ended October 31, 2022.

[0001327567-22-000038:mdna:153]
[same as prior period, unchanged from 0001327567-22-000016:mdna:153]

[0001327567-22-000038:mdna:154]
Our condensed consolidated financial statements have been prepared in accordance with GAAP. The preparation of these condensed consolidated financial statements requires us to make estimates and assumptions that affect the reported amounts of assets, liabilities, revenue, expenses, and related disclosures. We base our estimates on historical experience and on various other assumptions that we believe are reasonable under the circumstances. We evaluate our estimates and assumptions on an ongoing basis. Actual results could differ materially from those estimates due to risks and uncertainties, including uncertainty in the current economic environment. To the extent that there are material differences between these estimates and our actual results, our future consolidated financial statements will be affected.

[0001327567-22-000038:mdna:155]
We believe the critical accounting estimates discussed under Item 7, “Management’s Discussion and Analysis of Financial Condition and Results of Operations” in our Annual Report on Form 10-K for the fiscal year ended July 31, 2022 reflect our more significant judgments and estimates used in the preparation of our condensed consolidated financial statements. There have been no significant changes to our critical accounting estimates as filed in such report.
