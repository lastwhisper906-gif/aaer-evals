# PANW note change history — 0001327567-22-000016 → 0001327567-22-000038


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2022-11-18):
[0001327567-22-000038:note_history:1]
In order to reduce manufacturing lead times and plan for adequate supply, we enter into agreements with manufacturing partners and component suppliers to procure inventory based on our demand forecasts. The following table presents details of the aggregate future minimum or fixed purchase commitments under these arrangements, excluding obligations under contracts that we can cancel as of October 31, 2022 (in millions):
  (was, 2022-05-20, similarity 0.8024):
[0001327567-22-000016:note_history:1]
In order to reduce manufacturing lead times and plan for adequate supply, we enter into agreements with manufacturing partners and component suppliers to procure inventory based on our demand forecasts. The following table presents details of the aggregate future purchase commitments under these arrangements, excluding obligations under contracts that we can cancel without a significant penalty as of April 30, 2022 (in millions):

- changed (2022-11-18):
[0001327567-22-000038:note_history:2]
|  |  |  | Fiscal years ending July 31, |
|  | Total |  | Remaining 2023 |  | 2024 |  | 2025 |  | 2026 |  | 2027 |  | 2028 and Thereafter |
| Manufacturing purchase commitments | $ | 319.7 |  |  | $ | 189.7 |  |  | $ | 55.0 |  |  | $ | 35.0 |  |  | $ | 40.0 |  |  | $ | — |  |  | $ | — |  |
  (was, 2022-05-20, similarity 0.9478):
[0001327567-22-000016:note_history:2]
|  |  |  | Fiscal years ending July 31, |
|  | Total |  | Remaining 2022 |  | 2023 |  | 2024 |  | 2025 |  | 2026 |  | 2027 and thereafter |
| Manufacturing purchase commitments | $ | 360.6 |  |  | $ | 84.4 |  |  | $ | 171.2 |  |  | $ | 30.0 |  |  | $ | 35.0 |  |  | $ | 40.0 |  |  | $ | — |  |

- changed (2022-11-18):
[0001327567-22-000038:note_history:3]
We have entered into various non-cancelable agreements with certain service providers, under which we are committed to minimum or fixed purchases. The following table presents details of the aggregate future non-cancelable purchase commitments under these agreements as of October 31, 2022 (in millions):
  (was, 2022-05-20, similarity 0.9799):
[0001327567-22-000016:note_history:3]
We have entered into various non-cancelable agreements with certain service providers, under which we are committed to minimum or fixed purchases. The following table presents details of the aggregate future non-cancelable purchase commitments under these agreements as of April 30, 2022 (in millions):

- changed (2022-11-18):
[0001327567-22-000038:note_history:4]
To the extent there is a reasonable possibility that a loss exceeding amounts already recognized may be incurred and the amount of such additional loss would be material, we will either disclose the estimated additional loss or state that such an estimate cannot be made. As of October 31, 2022, we have not recorded any significant accruals for loss contingencies associated with such legal proceedings, determined that an unfavorable outcome is probable or reasonably possible, or determined that the amount or range of any possible loss is reasonably estimable.
  (was, 2022-05-20, similarity 0.9892):
[0001327567-22-000016:note_history:4]
To the extent there is a reasonable possibility that a loss exceeding amounts already recognized may be incurred and the amount of such additional loss would be material, we will either disclose the estimated additional loss or state that such an estimate cannot be made. As of April 30, 2022, we have not recorded any significant accruals for loss contingencies associated with such legal proceedings, determined that an unfavorable outcome is probable or reasonably possible, or determined that the amount or range of any possible loss is reasonably estimable.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2022-11-18):
[0001327567-22-000038:note_history:5]
Palo Alto Networks, Inc. (the “Company,” “we,” “us,” or “our”), headquartered in Santa Clara, California, was incorporated in March 2005 under the laws of the State of Delaware and commenced operations in April 2005. We empower enterprises, organizations, service providers, and government entities to secure their users, networks, clouds, and endpoints by delivering comprehensive cybersecurity backed by artificial intelligence and automation.

- added (2022-11-18):
[0001327567-22-000038:note_history:6]
The condensed consolidated financial statements are unaudited but include all adjustments of a normal recurring nature necessary for a fair presentation of our quarterly results. Our condensed consolidated financial statements should be read in conjunction with the audited consolidated financial statements and related notes in our Annual Report on Form 10-K for the fiscal year ended July 31, 2022.

- added (2022-11-18):
[0001327567-22-000038:note_history:7]
The preparation of condensed consolidated financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the amounts reported and disclosed in the condensed consolidated financial statements and the accompanying notes. We base our estimates on assumptions, both historical and forward looking, that we believe are reasonable. Actual results could differ materially from those estimates due to risks and uncertainties, including uncertainty in the current economic environment.

- changed (2022-11-18):
[0001327567-22-000038:note_history:8]
There have been no material changes to our significant accounting policies as of and for the three months ended October 31, 2022, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended July 31, 2022.
  (was, 2022-05-20, similarity 0.7303):
[0001327567-22-000016:note_history:8]
There have been no material changes to our significant accounting policies as of and for the nine months ended April 30, 2022, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended July 31, 2021, except for the change in our accounting policies due to our adoption of recently issued guidance. Refer to “Recently Adopted Accounting Pronouncements” below.

- added (2022-11-18):
[0001327567-22-000038:note_history:9]
Stock Split Effected in the Form of a Stock Dividend (“Stock Split”)

- added (2022-11-18):
[0001327567-22-000038:note_history:10]
On September 13, 2022, we executed a three-for-one stock split of our common stock, effected in the form of a stock dividend. The par value per share of our common stock remains unchanged at $0.001 per share after the Stock Split. All references made to share or per share amounts on the accompanying condensed consolidated financial statements and applicable disclosures have been retroactively adjusted to reflect the effects of the Stock Split.

- removed (2022-11-18):
[0001327567-22-000016:note_history:11]
Palo Alto Networks, Inc. (the “Company,” “we,” “us,” or “our”), headquartered in Santa Clara, California, was incorporated in March 2005 under the laws of the State of Delaware and commenced operations in April 2005. We empower enterprises, service providers, and government entities to secure all users, applications, data, networks, clouds and devices with comprehensive visibility and context, continuously across all locations.

- removed (2022-11-18):
[0001327567-22-000016:note_history:12]
Our condensed consolidated financial statements are unaudited but include all adjustments of a normal recurring nature necessary for a fair presentation of our quarterly results. Certain prior period amounts have been reclassified to conform to our current period presentation. Our condensed consolidated financial statements should be read in conjunction with the audited consolidated financial statements and related notes in our Annual Report on Form 10-K for the fiscal year ended July 31, 2021.

- removed (2022-11-18):
[0001327567-22-000016:note_history:13]
The preparation of condensed consolidated financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the condensed consolidated financial statements and the reported amounts of revenues and expenses during the reporting period. We base our estimates on historical experience and also on assumptions that we believe are reasonable. Actual results could differ materially from those estimates due to risks and uncertainties, including uncertainty in the economic environment such as the global impact of the coronavirus disease discovered in 2019 (“COVID-19”).

- removed (2022-11-18):
[0001327567-22-000016:note_history:14]
Recently Adopted Accounting Pronouncements

- removed (2022-11-18):
[0001327567-22-000016:note_history:15]
Acquired Contract Assets and Contract Liabilities

- removed (2022-11-18):
[0001327567-22-000016:note_history:16]
In October 2021, the Financial Accounting Standards Board (“FASB”) issued authoritative guidance that requires companies to apply revenue guidance to recognize and measure contract assets and contract liabilities from contracts with customers acquired in a business combination on the acquisition date, instead of measuring them at fair value. We early adopted this guidance in our first quarter of fiscal 2022 on a prospective basis. The adoption of this standard did not have a material impact on our condensed consolidated financial statements.

- removed (2022-11-18):
[0001327567-22-000016:note_history:17]
Debt with Conversion Options

- removed (2022-11-18):
[0001327567-22-000016:note_history:18]
In August 2020, the FASB issued authoritative guidance that simplifies the accounting for certain financial instruments with characteristics of liabilities and equity, including convertible instrument. The standard reduces the number of models used to account for convertible instruments and simplifies the classification of debt on the balance sheet.

- removed (2022-11-18):
[0001327567-22-000016:note_history:19]
We adopted this standard in our first quarter of fiscal 2022 using the modified-retrospective approach, under which financial results reported in periods prior to fiscal 2022 were not adjusted. The adoption of this standard resulted in an increase to convertible senior notes, net of $444.3 million, a decrease to accumulated deficit of $266.7 million, and a decrease to additional paid-in capital and temporary equity of $711.0 million upon adoption.

- removed (2022-11-18):
[0001327567-22-000016:note_history:20]
Below is the update to our Summary of Significant Accounting Policies in our Annual Report on Form 10-K for the fiscal year ended July 31, 2021 as a result of the adoption of the above guidance.

- removed (2022-11-18):
[0001327567-22-000016:note_history:21]
Business Combinations

- removed (2022-11-18):
[0001327567-22-000016:note_history:22]
We include the results of operations of the businesses that we acquire as of the respective dates of acquisition. We generally allocate the fair value of the purchase price of our acquisitions to the assets acquired and liabilities assumed based on their estimated

- removed (2022-11-18):
[0001327567-22-000016:note_history:23]
fair values. The excess of the purchase price over the values of these identifiable assets and liabilities is recorded as goodwill. Additional information existing as of the acquisition date but unknown to us may become known during the remainder of the measurement period, not to exceed 12 months from the acquisition date, which may result in changes to the amounts and allocations recorded.

- removed (2022-11-18):
[0001327567-22-000016:note_history:24]
Convertible Senior Notes

- removed (2022-11-18):
[0001327567-22-000016:note_history:25]
Prior to August 1, 2021, our convertible senior notes were separated into a liability and an equity component. The carrying amount of the liability component was calculated by measuring the fair value of a similar liability that did not have an associated convertible feature, using a discounted cash flow model with a risk-adjusted yield. The carrying amount of the equity component representing the conversion option was determined by deducting the fair value of the liability component from the par value of the notes as a whole. This difference represented a debt discount that was amortized to interest expense using the effective interest method over the term of the notes. The equity component was not remeasured as it continued to meet the conditions for equity classification. Transaction costs related to the issuance of the notes were allocated to the liability and equity components using the same proportions as the proceeds from the notes. Transaction costs attributable to the liability component were netted with the liability component and amortized to interest expense using the effective interest method over the term of the notes. Transaction costs attributable to the equity component were netted with the equity component of the notes in additional paid-in capital. Upon the notes becoming convertible, the net carrying amount of the liability component was classified as a current liability and a portion of the equity component representing the conversion option was reclassified to temporary equity. The portion of the equity component classified as temporary equity was measured as the difference between the principal and net carrying amount of the notes, excluding debt issuance costs.
Upon adoption of the new debt guidance on August 1, 2021, our convertible senior notes are accounted for entirely as a liability and measured at their amortized cost. Transaction costs related to the issuance of the notes are netted with the liability and are amortized on a straight-line basis, which approximates the effective interest rate method, to interest expense over the term of the notes. Refer to Note 9. Debt for additional information.


## panw:ConvertibleSeniorNotesPolicyPolicyTextBlock (debt) — matched_by: no_current_note, score: 0.0

- removed (2022-11-18):
[0001327567-22-000016:note_history:26]
Convertible Senior Notes

- removed (2022-11-18):
[0001327567-22-000016:note_history:27]
Prior to August 1, 2021, our convertible senior notes were separated into a liability and an equity component. The carrying amount of the liability component was calculated by measuring the fair value of a similar liability that did not have an associated convertible feature, using a discounted cash flow model with a risk-adjusted yield. The carrying amount of the equity component representing the conversion option was determined by deducting the fair value of the liability component from the par value of the notes as a whole. This difference represented a debt discount that was amortized to interest expense using the effective interest method over the term of the notes. The equity component was not remeasured as it continued to meet the conditions for equity classification. Transaction costs related to the issuance of the notes were allocated to the liability and equity components using the same proportions as the proceeds from the notes. Transaction costs attributable to the liability component were netted with the liability component and amortized to interest expense using the effective interest method over the term of the notes. Transaction costs attributable to the equity component were netted with the equity component of the notes in additional paid-in capital. Upon the notes becoming convertible, the net carrying amount of the liability component was classified as a current liability and a portion of the equity component representing the conversion option was reclassified to temporary equity. The portion of the equity component classified as temporary equity was measured as the difference between the principal and net carrying amount of the notes, excluding debt issuance costs.
Upon adoption of the new debt guidance on August 1, 2021, our convertible senior notes are accounted for entirely as a liability and measured at their amortized cost. Transaction costs related to the issuance of the notes are netted with the liability and are amortized on a straight-line basis, which approximates the effective interest rate method, to interest expense over the term of the notes.


## us-gaap:ConvertibleDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-11-18):
[0001327567-22-000038:note_history:28]
The following table sets forth the components of the Notes (in millions):
  (was, 2022-05-20, similarity 0.8343):
[0001327567-22-000016:note_history:28]
The following table sets forth the components of the Notes as of April 30, 2022 and July 31, 2021 (in millions):

- changed (2022-11-18):
[0001327567-22-000038:note_history:29]
|  | October 31, 2022 | July 31, 2022 |
|  | 2023 Notes |  | 2025 Notes |  | Total |  | 2023 Notes |  | 2025 Notes |  | Total |
| Liability component: |  |  |  |  |  |  |  |  |  |  |  |
| Principal | $ | 1,691.9 |  |  | $ | 1,999.4 |  |  | $ | 3,691.3 |  |  | $ | 1,691.9 |  |  | $ | 1,999.4 |  |  | $ | 3,691.3 |  |
| Less: debt discount and debt issuance costs, net of amortization | (1.9) |  |  | (10.8) |  |  | (12.7) |  |  | (2.6) |  |  | (11.9) |  |  | (14.5) |  |
| Net carrying amount | $ | 1,690.0 |  |  | $ | 1,988.6 |  |  | $ | 3,678.6 |  |  | $ | 1,689.3 |  |  | $ | 1,987.5 |  |  | $ | 3,676.8 |  |
  (was, 2022-05-20, similarity 0.841):
[0001327567-22-000016:note_history:29]
|  | April 30, 2022 (1) | July 31, 2021 |
|  | 2023 Notes |  | 2025 Notes |  | Total |  | 2023 Notes |  | 2025 Notes |  | Total |
| Liability component: |  |  |  |  |  |  |  |  |  |  |  |
| Principal | $ | 1,692.0 |  |  | $ | 2,000.0 |  |  | $ | 3,692.0 |  |  | $ | 1,692.0 |  |  | $ | 2,000.0 |  |  | $ | 3,692.0 |  |
| Less: debt discount and debt issuance costs, net of amortization | (3.3) |  |  | (13.0) |  |  | (16.3) |  |  | (134.1) |  |  | (331.9) |  |  | (466.0) |  |
| Net carrying amount | $ | 1,688.7 |  |  | $ | 1,987.0 |  |  | $ | 3,675.7 |  |  | $ | 1,557.9 |  |  | $ | 1,668.1 |  |  | $ | 3,226.0 |  |
| Equity component (including amounts classified as temporary equity) | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 315.0 |  |  | $ | 403.0 |  |  | $ | 718.0 |  |

- removed (2022-11-18):
[0001327567-22-000016:note_history:30]
______________

- removed (2022-11-18):
[0001327567-22-000016:note_history:31]
(1)     As described in Note 1. Description of Business and Summary of Significant Accounting Policies, we adopted new debt guidance effective August 1, 2021, using a modified retrospective method, under which financial results reported in prior periods were not adjusted. Upon adoption, our convertible senior notes are accounted for entirely as a liability and measured at their amortized cost. Transaction costs related to the issuance of the notes are netted with the liability and are amortized on a straight-line basis, which approximates the effective interest rate method, to interest expense over the term of the notes.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-11-18):
[0001327567-22-000038:note_history:32]
In July 2018, we issued $1.7 billion aggregate principal amount of 0.75% Convertible Senior Notes due 2023 (the “2023 Notes”) and in June 2020, we issued $2.0 billion aggregate principal amount of 0.375% Convertible Senior Notes due 2025 (the “2025 Notes,” and together with the 2023 Notes, the “Notes”). The 2023 Notes bear interest at a fixed rate of 0.75% per year, payable semi-annually in arrears on January 1 and July 1 of each year, beginning on January 1, 2019. The 2025 Notes bear interest at a fixed rate of 0.375% per year, payable semi-annually in arrears on June 1 and December 1 of each year, beginning on December 1, 2020. Each series of the convertible notes is governed by an indenture between us, as the issuer, and U.S. Bank National Association, as Trustee (individually, each an “Indenture,” and together, the “Indentures”). The Notes of each series are unsecured, unsubordinated obligations and the applicable Indenture governing each series of Notes does not contain any financial covenants or restrictions on the payments of dividends, the incurrence of indebtedness, or the issuance or repurchase of securities by us or any of our subsidiaries. The 2023 Notes and the 2025 Notes mature on July 1, 2023 and June 1, 2025, respectively. We cannot redeem the 2023 Notes prior to maturity. We may redeem for cash all or any portion of the 2025 Notes, at our option, on or after June 5, 2023, and prior to the 31st scheduled trading day immediately preceding the maturity date if the last reported sale price of our common stock has been at least 130% of the conversion price then in effect for at least 20 trading days during any 30 consecutive trading day period ending on and including the trading day preceding the date on which we provide notice of redemption. The redemption will be at a price equal to 100% of the principal amount of the 2025 Notes and adjusted for interest. If we call any or all of the 2025 Notes for redemption, holders may convert such 2025 Notes called for redemption at any time prior to the close of business on the second scheduled trading day immediately preceding the redemption date.
  (was, 2022-05-20, similarity 0.9237):
[0001327567-22-000016:note_history:32]
In July 2018, we issued $1.7 billion aggregate principal amount of 0.75% Convertible Senior Notes due 2023 (the “2023 Notes”) and in June 2020, we issued $2.0 billion aggregate principal amount of 0.375% Convertible Senior Notes due 2025 (the “2025 Notes,” and together with the 2023 Notes, the “Notes”). The 2023 Notes bear interest at a fixed rate of 0.75% per year, payable semi-annually in arrears on January 1 and July 1 of each year, beginning on January 1, 2019. The 2025 Notes bear interest at a fixed rate of 0.375% per year, payable semi-annually in arrears on June 1 and December 1 of each year, beginning on December 1, 2020. Each series of the convertible notes is governed by an indenture between us, as the issuer, and U.S. Bank National Association, as Trustee (individually, each an “Indenture,” and together, the “Indentures”). The Notes of each series are unsecured, unsubordinated obligations and the applicable Indenture governing each series of Notes does not contain any financial covenants or restrictions on the payments of dividends, the incurrence of indebtedness, or the issuance or repurchase of securities by us or any of our subsidiaries. The 2023 Notes and the 2025 Notes mature on July 1, 2023 and June 1, 2025, respectively. We cannot redeem the 2023 Notes prior to maturity. We may redeem for cash all or any portion of the 2025 Notes, at our option, on or after June 5, 2023, and prior to the 31st scheduled trading day immediately preceding the maturity date if the last reported sale price of our common stock has been at least 130% of the conversion price then in effect for at least 20 trading days during any 30 consecutive trading day period ending on and including the trading day preceding the date on which we provide notice of redemption. The redemption will be at a price equal to 100% of the

- changed (2022-11-18):
[0001327567-22-000038:note_history:33]
The conversion price will be subject to adjustment in some events. Holders of the Notes of a series who convert their Notes of such series in connection with certain corporate events that constitute a “make-whole fundamental change” under the applicable Indenture are, under certain circumstances, entitled to an increase in the conversion rate for such series of Notes. Additionally, upon the occurrence of a corporate event that constitutes a “fundamental change” under the applicable Indenture, holders of the Notes of such series may require us to repurchase for cash all or a portion of the Notes of such series at a repurchase price equal to 100% of the
  (was, 2022-05-20, similarity 0.9056):
[0001327567-22-000016:note_history:33]
The conversion price will be subject to adjustment in some events. Holders of the Notes of a series who convert their Notes of such series in connection with certain corporate events that constitute a “make-whole fundamental change” under the applicable Indenture are, under certain circumstances, entitled to an increase in the conversion rate for such series of Notes. Additionally, upon the occurrence of a corporate event that constitutes a “fundamental change” under the applicable Indenture, holders of the Notes of such series may require us to repurchase for cash all or a portion of the Notes of such series at a repurchase price equal to 100% of the principal amount of the Notes of such series plus accrued and unpaid interest to, but excluding, the fundamental change repurchase date.

- added (2022-11-18):
[0001327567-22-000038:note_history:34]
principal amount of the Notes of such series plus accrued and unpaid interest to, but excluding, the fundamental change repurchase date.

- added (2022-11-18):
[0001327567-22-000038:note_history:35]
The sale price condition for the Notes was met during the fiscal quarter ended October 31, 2022, and as a result, holders may convert their Notes at any time during the fiscal quarter ending January 31, 2023. The net carrying amount of the Notes was classified as a current liability on our condensed consolidated balance sheet as of October 31, 2022.

- changed (2022-11-18):
[0001327567-22-000038:note_history:36]
The following table sets forth the components of the Notes (in millions):
  (was, 2022-05-20, similarity 0.8343):
[0001327567-22-000016:note_history:36]
The following table sets forth the components of the Notes as of April 30, 2022 and July 31, 2021 (in millions):

- changed (2022-11-18):
[0001327567-22-000038:note_history:37]
|  | October 31, 2022 | July 31, 2022 |
|  | 2023 Notes |  | 2025 Notes |  | Total |  | 2023 Notes |  | 2025 Notes |  | Total |
| Liability component: |  |  |  |  |  |  |  |  |  |  |  |
| Principal | $ | 1,691.9 |  |  | $ | 1,999.4 |  |  | $ | 3,691.3 |  |  | $ | 1,691.9 |  |  | $ | 1,999.4 |  |  | $ | 3,691.3 |  |
| Less: debt discount and debt issuance costs, net of amortization | (1.9) |  |  | (10.8) |  |  | (12.7) |  |  | (2.6) |  |  | (11.9) |  |  | (14.5) |  |
| Net carrying amount | $ | 1,690.0 |  |  | $ | 1,988.6 |  |  | $ | 3,678.6 |  |  | $ | 1,689.3 |  |  | $ | 1,987.5 |  |  | $ | 3,676.8 |  |
  (was, 2022-05-20, similarity 0.841):
[0001327567-22-000016:note_history:37]
|  | April 30, 2022 (1) | July 31, 2021 |
|  | 2023 Notes |  | 2025 Notes |  | Total |  | 2023 Notes |  | 2025 Notes |  | Total |
| Liability component: |  |  |  |  |  |  |  |  |  |  |  |
| Principal | $ | 1,692.0 |  |  | $ | 2,000.0 |  |  | $ | 3,692.0 |  |  | $ | 1,692.0 |  |  | $ | 2,000.0 |  |  | $ | 3,692.0 |  |
| Less: debt discount and debt issuance costs, net of amortization | (3.3) |  |  | (13.0) |  |  | (16.3) |  |  | (134.1) |  |  | (331.9) |  |  | (466.0) |  |
| Net carrying amount | $ | 1,688.7 |  |  | $ | 1,987.0 |  |  | $ | 3,675.7 |  |  | $ | 1,557.9 |  |  | $ | 1,668.1 |  |  | $ | 3,226.0 |  |
| Equity component (including amounts classified as temporary equity) | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 315.0 |  |  | $ | 403.0 |  |  | $ | 718.0 |  |

- changed (2022-11-18):
[0001327567-22-000038:note_history:38]
The total estimated fair value of the 2023 Notes and 2025 Notes were $3.3 billion and $3.5 billion at October 31, 2022, respectively, and $3.2 billion and $3.5 billion at July 31, 2022, respectively. The fair value was determined based on the closing trading price per $100 of the applicable series of the Notes as of the last day of trading for the period. We consider the fair value of the Notes at October 31, 2022 and July 31, 2022 to be a Level 2 measurement. The fair value of the Notes is primarily affected by the trading price of our common stock and market interest rates.
  (was, 2022-05-20, similarity 0.9455):
[0001327567-22-000016:note_history:38]
The total estimated fair value of the 2023 Notes and 2025 Notes were $3.6 billion and $4.0 billion at April 30, 2022, respectively and $2.6 billion and $2.9 billion at July 31, 2021, respectively. The fair value was determined based on the closing trading price per $100 of the applicable series of the Notes as of the last day of trading for the period. We consider the fair value of the Notes at April 30, 2022 and July 31, 2021 to be a Level 2 measurement. The fair value of the Notes is primarily affected by the trading price of our common stock and market interest rates.

- added (2022-11-18):
[0001327567-22-000038:note_history:39]
|  |  |  | Three Months Ended October 31, |
|  |  |  |  |  | 2022 |  | 2021 |
|  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 2023 Notes |  | 2025 Notes |  | Total |  | 2023 Notes |  | 2025 Notes |  | Total |
| Contractual interest expense |  |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 3.2 |  | $ | 1.8 |  | $ | 5.0 |  |  | $ | 3.2 |  | $ | 1.9 |  | $ | 5.1 |  |
| Amortization of debt issuance costs |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 0.7 |  | 1.1 |  | 1.8 |  |  | 0.7 |  | 1.1 |  | 1.8 |  |
| Total interest expense |  |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 3.9 |  | $ | 2.9 |  | $ | 6.8 |  |  | $ | 3.9 |  | $ | 3.0 |  | $ | 6.9 |  |
| Effective interest rate |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 0.9 | % |  | 0.6 | % |  |  |  | 0.9 | % |  | 0.6 | % |  |  |

- changed (2022-11-18):
[0001327567-22-000038:note_history:40]
The Note Hedges cover shares of our common stock at a strike price per share that corresponds to the initial applicable conversion price of the applicable series of the Notes, which are also subject to adjustment, and are exercisable upon conversion of the applicable series of the Notes. The Note Hedges will expire upon maturity of the applicable series of the Notes. The Note Hedges are separate transactions and are not part of the terms of the applicable series of the Notes. Holders of the Notes of either series will not have any rights with respect to the Note Hedges. Any shares of our common stock receivable by us under the Note Hedges are excluded from the calculation of diluted earnings per share as they are antidilutive. The aggregate amounts paid for the Note Hedges are included in additional paid-in capital on our condensed consolidated balance sheets.
  (was, 2022-05-20, similarity 0.617):
[0001327567-22-000016:note_history:40]
The Note Hedges cover shares of our common stock at a strike price per share that corresponds to the initial applicable conversion price of the applicable series of the Notes, which are also subject to adjustment, and are exercisable upon conversion of the applicable series of the Notes. The Note Hedges will expire upon maturity of the applicable series of the Notes. The Note Hedges are

- changed (2022-11-18):
[0001327567-22-000038:note_history:41]
The following table presents details of our Warrants (in millions, except per share data):
  (was, 2022-05-20, similarity 0.9667):
[0001327567-22-000016:note_history:41]
The following table presents details of the Warrants (in millions, except per share data):

- changed (2022-11-18):
[0001327567-22-000038:note_history:42]
The borrowings under the Credit Facility currently bear interest, at our option, at a base rate plus a spread of 0.00% to 0.75%, or an adjusted LIBO Rate plus a spread of 1.00% to 1.75%, in each case with such spread being determined based on our leverage ratio. We are obligated to pay an ongoing commitment fee on undrawn amounts at a rate of 0.125% to 0.250%, depending on our leverage ratio. In March 2021, the ICE Benchmark Administration, the administrator of LIBO Rate, announced that it will cease publication of the LIBO Rate by June 2023. Under the terms of our Credit Facility, in the event of the discontinuance of the LIBO Rate, a mutually agreed-upon alternative benchmark rate will be established to replace the LIBO Rate, which may include the Secured Overnight Financing Rate (“SOFR”). We do not anticipate that the discontinuance of the LIBO Rate will materially impact our liquidity or financial position.
  (was, 2022-05-20, similarity 0.9978):
[0001327567-22-000016:note_history:42]
The borrowings under the Credit Facility currently bear interest, at our option, at a base rate plus a spread of 0.00% to 0.75%, or an adjusted LIBO Rate plus a spread of 1.00% to 1.75%, in each case with such spread being determined based on our leverage ratio. We are obligated to pay an ongoing commitment fee on undrawn amounts at a rate of 0.125% to 0.250%, depending on our leverage ratio. In March 2021, the ICE Benchmark Administration, the administrator of LIBO Rate, announced that it will cease publication of LIBO rate by June 2023. Under the terms of our Credit Facility, in the event of the discontinuance of the LIBO Rate, a mutually agreed-upon alternative benchmark rate will be established to replace the LIBO Rate, which may include the Secured Overnight Financing Rate (“SOFR”). We do not anticipate that the discontinuance of the LIBO Rate will materially impact our liquidity or financial position.

- changed (2022-11-18):
[0001327567-22-000038:note_history:43]
As of October 31, 2022, there were no amounts outstanding and we were in compliance with all covenants under the Credit Agreement.
  (was, 2022-05-20, similarity 0.9593):
[0001327567-22-000016:note_history:43]
As of April 30, 2022, there were no amounts outstanding and we were in compliance with all covenants under the Credit Agreement.

- removed (2022-11-18):
[0001327567-22-000016:note_history:44]
principal amount of the 2025 Notes and adjusted for interest. If we call any or all of the 2025 Notes for redemption, holders may convert such 2025 Notes called for redemption at any time prior to the close of business on the second scheduled trading day immediately preceding the redemption date.

- removed (2022-11-18):
[0001327567-22-000016:note_history:45]
The sale price condition for the Notes was met during the fiscal quarter ended April 30, 2022, and as a result, holders may convert their Notes at any time during the fiscal quarter ending July 31, 2022. Accordingly, the net carrying amount of the Notes was classified as a current liability on our condensed consolidated balance sheet as of April 30, 2022.

- removed (2022-11-18):
[0001327567-22-000016:note_history:46]
______________

- removed (2022-11-18):
[0001327567-22-000016:note_history:47]
(1)     As described in Note 1. Description of Business and Summary of Significant Accounting Policies, we adopted new debt guidance effective August 1, 2021, using a modified retrospective method, under which financial results reported in prior periods were not adjusted. Upon adoption, our convertible senior notes are accounted for entirely as a liability and measured at their amortized cost. Transaction costs related to the issuance of the notes are netted with the liability and are amortized on a straight-line basis, which approximates the effective interest rate method, to interest expense over the term of the notes.

- removed (2022-11-18):
[0001327567-22-000016:note_history:48]
|  | Three Months Ended April 30, |  | Nine Months Ended April 30, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
|  | 2023 Notes |  | 2025 Notes |  | Total |  | 2023 Notes |  |  |  | 2025 Notes |  | Total |  | 2023 Notes |  | 2025 Notes |  | Total |  | 2023 Notes |  | 2025 Notes |  | Total |
| Contractual interest expense | $ | 3.2 |  | $ | 1.8 |  | $ | 5.0 |  |  | $ | 3.2 |  |  |  | $ | 1.8 |  | $ | 5.0 |  | $ | 9.5 |  | $ | 5.6 |  | $ | 15.1 |  |  | $ | 9.5 |  | $ | 5.6 |  | $ | 15.1 |  |
| Amortization of debt discount(1) | — |  | — |  | — |  |  | 16.0 |  |  |  | 18.6 |  | 34.6 |  | — |  | — |  | — |  |  | 47.4 |  | 55.3 |  | 102.7 |  |
| Amortization of debt issuance costs | 0.7 |  | 1.1 |  | 1.8 |  |  | 0.6 |  |  |  | 0.7 |  | 1.3 |  | 2.1 |  | 3.3 |  | 5.4 |  |  | 1.7 |  | 2.1 |  | 3.8 |  |
| Total interest expense | $ | 3.9 |  | $ | 2.9 |  | $ | 6.8 |  |  | $ | 19.8 |  |  |  | $ | 21.1 |  | $ | 40.9 |  | $ | 11.6 |  | $ | 8.9 |  | $ | 20.5 |  |  | $ | 58.6 |  | $ | 63.0 |  | $ | 121.6 |  |
| Effective interest rate | 0.9 | % |  | 0.6 | % |  |  |  | 5.2 | % |  |  |  | 5.4 | % |  |  |  | 0.9 | % |  | 0.6 | % |  |  |  | 5.2 | % |  | 5.4 | % |  |  |

- removed (2022-11-18):
[0001327567-22-000016:note_history:49]
______________

- removed (2022-11-18):
[0001327567-22-000016:note_history:50]
(1)    Upon adoption of the new debt guidance, the conversion option is no longer separately accounted for as debt discount. Our convertible senior notes are accounted for entirely as a liability.

- removed (2022-11-18):
[0001327567-22-000016:note_history:51]
separate transactions and are not part of the terms of the applicable series of the Notes. Holders of the Notes of either series will not have any rights with respect to the Note Hedges. Any shares of our common stock receivable by us under the Note Hedges are excluded from the calculation of diluted earnings per share as they are antidilutive. The aggregate amounts paid for the Note Hedges are included in additional paid-in capital on our condensed consolidated balance sheets.


## us-gaap:DebtSecuritiesAvailableForSaleTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-11-18):
[0001327567-22-000038:note_history:52]
The following tables summarize the amortized cost, unrealized gains and losses, and fair value of our available-for-sale debt securities as of October 31, 2022 and July 31, 2022 (in millions):
  (was, 2022-05-20, similarity 0.9724):
[0001327567-22-000016:note_history:52]
The following tables summarize the amortized cost, unrealized gains and losses, and fair value of our available-for-sale debt securities as of April 30, 2022 and July 31, 2021 (in millions):

- changed (2022-11-18):
[0001327567-22-000038:note_history:53]
|  | October 31, 2022 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 150.6 |  |  | $ | — |  |  | $ | — |  |  | $ | 150.6 |  |
| Commercial paper | 338.5 |  |  | — |  |  | — |  |  | 338.5 |  |
| Corporate debt securities | 37.3 |  |  | — |  |  | (0.1) |  |  | 37.2 |  |
| U.S. government and agency securities | 159.9 |  |  | — |  |  | — |  |  | 159.9 |  |
| Total available-for-sale cash equivalents | $ | 686.3 |  |  | $ | — |  |  | $ | (0.1) |  |  | $ | 686.2 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 213.3 |  |  | $ | — |  |  | $ | (0.3) |  |  | $ | 213.0 |  |
| Commercial paper | 289.4 |  |  | — |  |  | (1.1) |  |  | 288.3 |  |
| Corporate debt securities | 2,321.6 |  |  | 0.4 |  |  | (36.8) |  |  | 2,285.2 |  |
| U.S. government and agency securities | 605.3 |  |  | — |  |  | (8.2) |  |  | 597.1 |  |
| Non-U.S. government and agency securities | 80.0 |  |  | — |  |  | (1.1) |  |  | 78.9 |  |
| Asset-backed securities | 372.8 |  |  | — |  |  | (4.1) |  |  | 368.7 |  |
| Total available-for-sale investments | $ | 3,882.4 |  |  | $ | 0.4 |  |  | $ | (51.6) |  |  | $ | 3,831.2 |  |
  (was, 2022-05-20, similarity 0.9473):
[0001327567-22-000016:note_history:53]
|  | April 30, 2022 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 50.0 |  |  | $ | — |  |  | $ | — |  |  | $ | 50.0 |  |
| Commercial paper | 17.9 |  |  | — |  |  | — |  |  | 17.9 |  |
| Corporate debt securities | 3.9 |  |  | — |  |  | — |  |  | 3.9 |  |
| Total available-for-sale cash equivalents | $ | 71.8 |  |  | $ | — |  |  | $ | — |  |  | $ | 71.8 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 205.5 |  |  | $ | — |  |  | $ | — |  |  | $ | 205.5 |  |
| Commercial paper | 11.0 |  |  | — |  |  | — |  |  | 11.0 |  |
| Corporate debt securities | 755.7 |  |  | — |  |  | (11.1) |  |  | 744.6 |  |
| U.S. government and agency securities | 1,081.6 |  |  | — |  |  | (12.0) |  |  | 1,069.6 |  |
| Non-U.S. government and agency securities | 60.4 |  |  | — |  |  | (0.3) |  |  | 60.1 |  |
| Asset-backed securities | 79.3 |  |  | — |  |  | (0.7) |  |  | 78.6 |  |
| Total available-for-sale investments | $ | 2,193.5 |  |  | $ | — |  |  | $ | (24.1) |  |  | $ | 2,169.4 |  |

- added (2022-11-18):
[0001327567-22-000038:note_history:54]
|  | July 31, 2022 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 155.3 |  |  | $ | — |  |  | $ | — |  |  | $ | 155.3 |  |
| Commercial paper | 69.1 |  |  | — |  |  | — |  |  | 69.1 |  |
| Corporate debt securities | 19.5 |  |  | — |  |  | — |  |  | 19.5 |  |
| U.S. government and agency securities | 10.0 |  |  | — |  |  | — |  |  | 10.0 |  |
| Non-U.S. government and agency securities | 5.0 |  |  | 0.1 |  |  | — |  |  | 5.1 |  |
| Total available-for-sale cash equivalents | $ | 258.9 |  |  | $ | 0.1 |  |  | $ | — |  |  | $ | 259.0 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 116.5 |  |  | $ | — |  |  | $ | (0.1) |  |  | $ | 116.4 |  |
| Commercial paper | 79.1 |  |  | — |  |  | (0.1) |  |  | 79.0 |  |
| Corporate debt securities | 1,276.8 |  |  | 1.3 |  |  | (11.9) |  |  | 1,266.2 |  |
| U.S. government and agency securities | 928.1 |  |  | 0.1 |  |  | (11.8) |  |  | 916.4 |  |
| Non-U.S. government and agency securities | 17.6 |  |  | — |  |  | (0.2) |  |  | 17.4 |  |
| Asset-backed securities | $ | 173.4 |  |  | $ | 0.2 |  |  | $ | (1.1) |  |  | $ | 172.5 |  |
| Total available-for-sale investments | $ | 2,591.5 |  |  | $ | 1.6 |  |  | $ | (25.2) |  |  | $ | 2,567.9 |  |

- removed (2022-11-18):
[0001327567-22-000016:note_history:55]
|  | July 31, 2021 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 150.4 |  |  | $ | — |  |  | $ | — |  |  | $ | 150.4 |  |
| Corporate debt securities | 1.0 |  |  | — |  |  | — |  |  | 1.0 |  |
| U.S. government and agency securities | 116.3 |  |  | — |  |  | — |  |  | 116.3 |  |
| Total available-for-sale cash equivalents | $ | 267.7 |  |  | $ | — |  |  | $ | — |  |  | $ | 267.7 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 17.4 |  |  | $ | — |  |  | $ | — |  |  | $ | 17.4 |  |
| Corporate debt securities | 389.2 |  |  | 0.5 |  |  | (0.1) |  |  | 389.6 |  |
| U.S. government and agency securities | 1,435.1 |  |  | 1.1 |  |  | — |  |  | 1,436.2 |  |
| Non-U.S. government and agency securities | 72.0 |  |  | — |  |  | — |  |  | 72.0 |  |
| Total available-for-sale investments | $ | 1,913.7 |  |  | $ | 1.6 |  |  | $ | (0.1) |  |  | $ | 1,915.2 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-11-18):
[0001327567-22-000038:note_history:56]
The following tables summarize the amortized cost, unrealized gains and losses, and fair value of our available-for-sale debt securities as of October 31, 2022 and July 31, 2022 (in millions):
  (was, 2022-05-20, similarity 0.9724):
[0001327567-22-000016:note_history:56]
The following tables summarize the amortized cost, unrealized gains and losses, and fair value of our available-for-sale debt securities as of April 30, 2022 and July 31, 2021 (in millions):

- changed (2022-11-18):
[0001327567-22-000038:note_history:57]
|  | October 31, 2022 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 150.6 |  |  | $ | — |  |  | $ | — |  |  | $ | 150.6 |  |
| Commercial paper | 338.5 |  |  | — |  |  | — |  |  | 338.5 |  |
| Corporate debt securities | 37.3 |  |  | — |  |  | (0.1) |  |  | 37.2 |  |
| U.S. government and agency securities | 159.9 |  |  | — |  |  | — |  |  | 159.9 |  |
| Total available-for-sale cash equivalents | $ | 686.3 |  |  | $ | — |  |  | $ | (0.1) |  |  | $ | 686.2 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 213.3 |  |  | $ | — |  |  | $ | (0.3) |  |  | $ | 213.0 |  |
| Commercial paper | 289.4 |  |  | — |  |  | (1.1) |  |  | 288.3 |  |
| Corporate debt securities | 2,321.6 |  |  | 0.4 |  |  | (36.8) |  |  | 2,285.2 |  |
| U.S. government and agency securities | 605.3 |  |  | — |  |  | (8.2) |  |  | 597.1 |  |
| Non-U.S. government and agency securities | 80.0 |  |  | — |  |  | (1.1) |  |  | 78.9 |  |
| Asset-backed securities | 372.8 |  |  | — |  |  | (4.1) |  |  | 368.7 |  |
| Total available-for-sale investments | $ | 3,882.4 |  |  | $ | 0.4 |  |  | $ | (51.6) |  |  | $ | 3,831.2 |  |
  (was, 2022-05-20, similarity 0.9473):
[0001327567-22-000016:note_history:57]
|  | April 30, 2022 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 50.0 |  |  | $ | — |  |  | $ | — |  |  | $ | 50.0 |  |
| Commercial paper | 17.9 |  |  | — |  |  | — |  |  | 17.9 |  |
| Corporate debt securities | 3.9 |  |  | — |  |  | — |  |  | 3.9 |  |
| Total available-for-sale cash equivalents | $ | 71.8 |  |  | $ | — |  |  | $ | — |  |  | $ | 71.8 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 205.5 |  |  | $ | — |  |  | $ | — |  |  | $ | 205.5 |  |
| Commercial paper | 11.0 |  |  | — |  |  | — |  |  | 11.0 |  |
| Corporate debt securities | 755.7 |  |  | — |  |  | (11.1) |  |  | 744.6 |  |
| U.S. government and agency securities | 1,081.6 |  |  | — |  |  | (12.0) |  |  | 1,069.6 |  |
| Non-U.S. government and agency securities | 60.4 |  |  | — |  |  | (0.3) |  |  | 60.1 |  |
| Asset-backed securities | 79.3 |  |  | — |  |  | (0.7) |  |  | 78.6 |  |
| Total available-for-sale investments | $ | 2,193.5 |  |  | $ | — |  |  | $ | (24.1) |  |  | $ | 2,169.4 |  |

- added (2022-11-18):
[0001327567-22-000038:note_history:58]
|  | July 31, 2022 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 155.3 |  |  | $ | — |  |  | $ | — |  |  | $ | 155.3 |  |
| Commercial paper | 69.1 |  |  | — |  |  | — |  |  | 69.1 |  |
| Corporate debt securities | 19.5 |  |  | — |  |  | — |  |  | 19.5 |  |
| U.S. government and agency securities | 10.0 |  |  | — |  |  | — |  |  | 10.0 |  |
| Non-U.S. government and agency securities | 5.0 |  |  | 0.1 |  |  | — |  |  | 5.1 |  |
| Total available-for-sale cash equivalents | $ | 258.9 |  |  | $ | 0.1 |  |  | $ | — |  |  | $ | 259.0 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 116.5 |  |  | $ | — |  |  | $ | (0.1) |  |  | $ | 116.4 |  |
| Commercial paper | 79.1 |  |  | — |  |  | (0.1) |  |  | 79.0 |  |
| Corporate debt securities | 1,276.8 |  |  | 1.3 |  |  | (11.9) |  |  | 1,266.2 |  |
| U.S. government and agency securities | 928.1 |  |  | 0.1 |  |  | (11.8) |  |  | 916.4 |  |
| Non-U.S. government and agency securities | 17.6 |  |  | — |  |  | (0.2) |  |  | 17.4 |  |
| Asset-backed securities | $ | 173.4 |  |  | $ | 0.2 |  |  | $ | (1.1) |  |  | $ | 172.5 |  |
| Total available-for-sale investments | $ | 2,591.5 |  |  | $ | 1.6 |  |  | $ | (25.2) |  |  | $ | 2,567.9 |  |

- added (2022-11-18):
[0001327567-22-000038:note_history:59]
As of October 31, 2022, the gross unrealized losses that have been in a continuous unrealized loss position for less than 12 months were $45.7 million, which were related to $3.5 billion of available-for-sale debt securities, and the gross unrealized losses that have been in a continuous unrealized loss position for more than 12 months were not material. As of July 31, 2022 the gross unrealized losses that have been in a continuous unrealized loss position for less than 12 months were $24.8 million, which were related to $2.0 billion of available-for-sale debt securities, and the gross unrealized losses that have been in a continuous unrealized loss position for more than 12 months were not material.

- added (2022-11-18):
[0001327567-22-000038:note_history:60]
Unrealized losses related to our available-for-sale debt securities are due to interest rate fluctuations as opposed to credit quality. We do not intend to sell any of the securities in an unrealized loss position and it is not likely that we would be required to sell these securities before recovery of their amortized cost basis, which may be at maturity. We did not recognize any credit losses related to our available-for-sale debt securities during the three months ended October 31, 2022 and 2021.

- changed (2022-11-18):
[0001327567-22-000038:note_history:61]
The following table summarizes the amortized cost and fair value of our available-for-sale debt securities as of October 31, 2022, by contractual years-to-maturity (in millions):
  (was, 2022-05-20, similarity 0.9708):
[0001327567-22-000016:note_history:61]
The following table summarizes the amortized cost and fair value of our available-for-sale debt securities as of April 30, 2022, by contractual years-to-maturity (in millions):

- added (2022-11-18):
[0001327567-22-000038:note_history:62]
Marketable equity securities consist of money market funds and are included in cash and cash equivalents on our condensed consolidated balance sheets. As of October 31, 2022 and July 31, 2022, the carrying values of our marketable equity securities were $933.2 million and $1.2 billion, respectively. There were no unrealized gains or losses recognized for these securities during the three months ended October 31, 2022 and 2021.

- removed (2022-11-18):
[0001327567-22-000016:note_history:63]
|  | July 31, 2021 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 150.4 |  |  | $ | — |  |  | $ | — |  |  | $ | 150.4 |  |
| Corporate debt securities | 1.0 |  |  | — |  |  | — |  |  | 1.0 |  |
| U.S. government and agency securities | 116.3 |  |  | — |  |  | — |  |  | 116.3 |  |
| Total available-for-sale cash equivalents | $ | 267.7 |  |  | $ | — |  |  | $ | — |  |  | $ | 267.7 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 17.4 |  |  | $ | — |  |  | $ | — |  |  | $ | 17.4 |  |
| Corporate debt securities | 389.2 |  |  | 0.5 |  |  | (0.1) |  |  | 389.6 |  |
| U.S. government and agency securities | 1,435.1 |  |  | 1.1 |  |  | — |  |  | 1,436.2 |  |
| Non-U.S. government and agency securities | 72.0 |  |  | — |  |  | — |  |  | 72.0 |  |
| Total available-for-sale investments | $ | 1,913.7 |  |  | $ | 1.6 |  |  | $ | (0.1) |  |  | $ | 1,915.2 |  |

- removed (2022-11-18):
[0001327567-22-000016:note_history:64]
We do not intend to sell any of the securities in an unrealized loss position and it is not likely that we would be required to sell these securities before recovery of their amortized cost basis, which may be at maturity. We did not recognize any credit losses related to our available-for-sale debt securities during the three and nine months ended April 30, 2022 and 2021.

- removed (2022-11-18):
[0001327567-22-000016:note_history:65]
Marketable equity securities consist of money market funds and are included in cash and cash equivalents on our condensed consolidated balance sheets. As of April 30, 2022 and July 31, 2021, the carrying values of our marketable equity securities were $923.0 million and $124.2 million, respectively. There were no unrealized gains or losses recognized for these securities during the three and nine months ended April 30, 2022 and 2021.


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2022-11-18):
[0001327567-22-000038:note_history:66]
|  |  |  | Three Months Ended October 31, |
|  |  |  |  |  | 2022 |  | 2021 |
| Revenue: |  |  |  |  |  |  |  |
| Americas |  |  |  |  |  |  |  |
| United States |  |  |  |  | $ | 1,006.3 |  |  | $ | 811.7 |  |
| Other Americas |  |  |  |  | 64.4 |  |  | 55.0 |  |
| Total Americas |  |  |  |  | 1,070.7 |  |  | 866.7 |  |
| Europe, the Middle East, and Africa (“EMEA”) |  |  |  |  | 307.9 |  |  | 233.8 |  |
| Asia Pacific and Japan (“APAC”) |  |  |  |  | 184.8 |  |  | 146.9 |  |
| Total revenue |  |  |  |  | $ | 1,563.4 |  |  | $ | 1,247.4 |  |

- added (2022-11-18):
[0001327567-22-000038:note_history:67]
|  |  |  | Three Months Ended October 31, |
|  |  |  |  |  | 2022 |  | 2021 |
| Revenue: |  |  |  |  |  |  |  |
| Product |  |  |  |  | $ | 330.0 |  |  | $ | 295.5 |  |
| Subscription and support |  |  |  |  |  |  |  |
| Subscription |  |  |  |  | 764.0 |  |  | 578.8 |  |
| Support |  |  |  |  | 469.4 |  |  | 373.1 |  |
| Total subscription and support |  |  |  |  | 1,233.4 |  |  | 951.9 |  |
| Total revenue |  |  |  |  | $ | 1,563.4 |  |  | $ | 1,247.4 |  |

- changed (2022-11-18):
[0001327567-22-000038:note_history:68]
During the three months ended October 31, 2022 and 2021, we recognized approximately $1.1 billion and $840.0 million of revenue pertaining to amounts that were deferred as of July 31, 2022 and 2021, respectively.
  (was, 2022-05-20, similarity 0.9491):
[0001327567-22-000016:note_history:68]
During the nine months ended April 30, 2022 and 2021, we recognized approximately $2.2 billion and $1.6 billion of revenue pertaining to amounts that were deferred as of July 31, 2021 and 2020, respectively.

- changed (2022-11-18):
[0001327567-22-000038:note_history:69]
Remaining performance obligations were $8.3 billion as of October 31, 2022, of which we expect to recognize as revenue approximately $4.2 billion over the next 12 months and the remainder thereafter.
  (was, 2022-05-20, similarity 0.7082):
[0001327567-22-000016:note_history:69]
Revenue expected to be recognized from remaining performance obligations was $6.9 billion as of April 30, 2022, of which we expect to recognize approximately $3.6 billion over the next 12 months and the remainder thereafter.

- removed (2022-11-18):
[0001327567-22-000016:note_history:70]
|  | Three Months Ended April 30, |  | Nine Months Ended April 30, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Revenue: |  |  |  |  |  |  |  |
| Americas |  |  |  |  |  |  |  |
| United States | $ | 887.2 |  |  | $ | 683.1 |  |  | $ | 2,557.5 |  |  | $ | 1,950.3 |  |
| Other Americas | 61.5 |  |  | 49.3 |  |  | 173.8 |  |  | 138.4 |  |
| Total Americas | 948.7 |  |  | 732.4 |  |  | 2,731.3 |  |  | 2,088.7 |  |
| Europe, the Middle East, and Africa (“EMEA”) | 269.5 |  |  | 211.0 |  |  | 755.5 |  |  | 590.6 |  |
| Asia Pacific and Japan (“APAC”) | 168.5 |  |  | 130.5 |  |  | 464.2 |  |  | 357.5 |  |
| Total revenue | $ | 1,386.7 |  |  | $ | 1,073.9 |  |  | $ | 3,951.0 |  |  | $ | 3,036.8 |  |

- removed (2022-11-18):
[0001327567-22-000016:note_history:71]
|  | Three Months Ended April 30, |  | Nine Months Ended April 30, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Revenue: |  |  |  |  |  |  |  |
| Product | $ | 351.5 |  |  | $ | 288.9 |  |  | $ | 955.0 |  |  | $ | 780.9 |  |
| Subscription and support |  |  |  |  |  |  |  |
| Subscription | 639.8 |  |  | 473.8 |  |  | 1,836.6 |  |  | 1,363.5 |  |
| Support | 395.4 |  |  | 311.2 |  |  | 1,159.4 |  |  | 892.4 |  |
| Total subscription and support | 1,035.2 |  |  | 785.0 |  |  | 2,996.0 |  |  | 2,255.9 |  |
| Total revenue | $ | 1,386.7 |  |  | $ | 1,073.9 |  |  | $ | 3,951.0 |  |  | $ | 3,036.8 |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_prior_note, score: 0.0

- added (2022-11-18):
[0001327567-22-000038:note_history:72]
Subsequent Event
Business Combination

- added (2022-11-18):
[0001327567-22-000038:note_history:73]
On November 17, 2022, we entered into a definitive agreement to acquire Cider Security Ltd., a privately-held cyber security company, for total consideration of approximately $250.0 million, including approximately $194.6 million in cash and approximately $55.4 million in replacement equity awards, subject to adjustment. We expect the acquisition will support Prisma Cloud’s platform approach to securing the entire application security lifecycle from code-to-cloud. The proposed acquisition is expected to close during our second quarter of fiscal 2023, subject to the satisfaction of customary closing conditions.
