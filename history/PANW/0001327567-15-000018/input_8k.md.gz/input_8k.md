# PANW 8-K — 0001327567-15-000015 filed 2015-05-27

## item codes, every 8-K on or before 2015-05-28

- 2015-05-27 0001327567-15-000015 — 2.02, 9.01
- 2015-03-02 0001327567-15-000006 — 2.02, 9.01
- 2014-12-15 0001327567-14-000046 — 5.07
- 2014-11-24 0001327567-14-000040 — 2.02, 9.01
- 2014-09-22 0001193125-14-348581 — 5.02, 9.01
- 2014-09-09 0001327567-14-000025 — 2.02, 9.01
- 2014-07-01 0001193125-14-257824 — 1.01, 2.03, 3.02, 9.01
- 2014-06-26 0001193125-14-249529 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2014-06-20 0001327567-14-000020 — 9.01 — amendment of 0001193125-14-140511
- 2014-06-04 0001327567-14-000016 — 3.02
- 2014-05-30 0001193125-14-218158 — 2.02 — amendment, the index does not say of what
- 2014-05-28 0001193125-14-215060 — 1.01, 2.02, 3.02, 9.01
- 2014-04-11 0001193125-14-140511 — 2.01, 3.02, 7.01, 9.01
- 2014-03-24 0001193125-14-111318 — 1.01, 3.02, 7.01, 9.01
- 2014-03-13 0001327567-14-000009 — 5.02
- 2014-02-24 0001193125-14-063754 — 2.02, 9.01
- 2013-12-12 0001327567-13-000040 — 5.07
- 2013-11-25 0001327567-13-000033 — 2.02, 9.01
- 2013-09-30 0001193125-13-384966 — 8.01
- 2013-09-09 0001193125-13-361421 — 2.02, 9.01
- 2013-05-30 0001193125-13-241542 — 2.02, 5.02, 9.01
- 2013-03-11 0001193125-13-101082 — 5.02, 9.01
- 2013-02-28 0001193125-13-084193 — 2.02, 9.01
- 2012-12-14 0001193125-12-503335 — 5.07
- 2012-12-06 0001193125-12-493700 — 2.02, 9.01
- 2012-09-24 0001193125-12-401534 — 1.01, 2.03
- 2012-09-20 0001193125-12-398433 — 5.02, 9.01
- 2012-09-10 0001193125-12-386605 — 2.02, 9.01

## late-filing notifications on or before 2015-05-28

- none on or before 2015-05-28

## item 2.02 — earnings release, exhibit 99.1

[0001327567-15-000015:8k_2_02:1]
EX-99.1
2
ex991q315earningsrelease.htm
EXHIBIT 99.1

[0001327567-15-000015:8k_2_02:2]
Ex 99.1 (Q3'15 Earnings Release)

[0001327567-15-000015:8k_2_02:3]
Exhibit 99.1

[0001327567-15-000015:8k_2_02:4]
Palo Alto Networks Reports Fiscal Third Quarter 2015 Financial Results

[0001327567-15-000015:8k_2_02:5]
| • | Fiscal third quarter total revenue grows 55 percent year-over-year to $234.2 million |

[0001327567-15-000015:8k_2_02:6]
| • | Billings grow 56 percent year-over-year to $302.2 million |

[0001327567-15-000015:8k_2_02:7]
| • | Deferred revenue grows 64 percent year-over-year to $603.9 million |

[0001327567-15-000015:8k_2_02:8]
SANTA CLARA, Calif., May 27, 2015 - Palo Alto Networks, Inc. (NYSE: PANW) today announced financial results for its fiscal third quarter 2015 ended April 30, 2015.

[0001327567-15-000015:8k_2_02:9]
Total revenue for the fiscal third quarter 2015 grew 55 percent year-over-year to a record $234.2 million, compared with $150.7 million for the fiscal third quarter 2014. GAAP net loss for the fiscal third quarter 2015 was $45.9 million, or $0.56 per diluted share, compared with GAAP net loss of $146.6 million, or $1.96 per diluted share, for the fiscal third quarter 2014.

[0001327567-15-000015:8k_2_02:10]
Palo Alto Networks recorded fiscal third quarter 2015 non-GAAP net income of $20.5 million, or $0.23 per diluted share, compared with non-GAAP net income of $8.7 million, or $0.11 per diluted share, for the fiscal third quarter 2014. A reconciliation between GAAP and non-GAAP information is contained in the tables below.

[0001327567-15-000015:8k_2_02:11]
“We reported record revenue in the fiscal third quarter 2015 as we continue to expand market share with growth rates that significantly outpace the market. Our ongoing success is due to our natively integrated and highly automated enterprise security platform that delivers prevention capabilities at every step in the cyber-attack lifecycle,” said Mark McLaughlin, president and chief executive officer of Palo Alto Networks. “Our customers are benefitting from the leverage gained by our flexible and extensible platform, the network-effect of insights from across our customer base, and our consistent delivery of innovative technology that extends the value of the platform and enhances our customers’ security.”

[0001327567-15-000015:8k_2_02:12]
Steffan Tomlinson, chief financial officer of Palo Alto Networks, commented, “Year-over-year revenue growth of 55 percent was driven by new customer acquisition and expansion in existing accounts, resulting in substantial growth across all three components of our business: product, recurring subscription and support. At the same time we continued to realize the leverage inherent in our ramping hybrid-SaaS

[0001327567-15-000015:8k_2_02:13]
model, delivering sequential and year-over-year expansion of non-GAAP operating margin, non-GAAP earnings per share, and cash flow from operations.”

[0001327567-15-000015:8k_2_02:14]
Recent Highlights

[0001327567-15-000015:8k_2_02:15]
| • | Acquired CirroSecure - This acquisition expands the functionality of our enterprise security platform by providing additional security for SaaS applications and is expected to be available as a new subscription-based service in the second half of 2015. |

[0001327567-15-000015:8k_2_02:16]
| • | Introduced new AutoFocus threat intelligence offering - At Ignite, our annual user conference, we introduced our newest subscription service AutoFocus, which provides prioritized, actionable intelligence to help customers take quick, preventive action against targeted cyber threats. More than 750 customers have already submitted requests to enroll in the AutoFocus community access program. |

[0001327567-15-000015:8k_2_02:17]
| • | Positioned in the “Leaders” quadrant of Gartner, Inc.’s April 2015 Magic Quadrant for Enterprise Network Firewalls - This is the fourth consecutive year in which Palo Alto Networks has been recognized as a leader in the Magic Quadrant for Enterprise Network Firewalls report.[1] |

[0001327567-15-000015:8k_2_02:18]
| • | Received Superior Security Score in head-to-head product test - In the NSS Labs 2015 Next-Generation Intrusion Prevention System (NGIPS) test, our platform achieved the highest security efficacy ratings of any other offering tested when exposed to live (real-time) drive-by exploits. |

[0001327567-15-000015:8k_2_02:19]
Financial Outlook

[0001327567-15-000015:8k_2_02:20]
Palo Alto Networks provides guidance based on current market conditions and expectations.

[0001327567-15-000015:8k_2_02:21]
For the fiscal fourth quarter 2015, we expect:

[0001327567-15-000015:8k_2_02:22]
| • | Total revenue in the range of $252 to $256 million, representing year-over-year growth between 41 percent and 44 percent. |

[0001327567-15-000015:8k_2_02:23]
| • | Diluted non-GAAP earnings per share in the range of $0.24 to $0.25 using 88.5 to 90.5 million shares. |

[0001327567-15-000015:8k_2_02:24]
______________

[0001327567-15-000015:8k_2_02:25]
[1]    Gartner, “Magic Quadrant for Enterprise Network Firewalls”, Adam Hils, Greg Young, Jeremy D’Hoinne; April 22, 2015.

[0001327567-15-000015:8k_2_02:26]
Guidance for non-GAAP financial measures excludes share-based compensation and related payroll taxes, amortization of acquired intangible assets, acquisition related expenses, discrete tax benefits, non-cash interest expense related to our convertible senior notes, and certain non-recurring expenses. We have not reconciled diluted non-GAAP earnings per share guidance to GAAP net income (loss) per diluted share because we do not provide guidance on GAAP net income (loss) or the various reconciling cash and non-cash items between GAAP net income (loss) and non-GAAP net income (loss). Items that impact these measures are out of our control and/or cannot be reasonably predicted. Accordingly, a reconciliation of the non-GAAP financial measure guidance to the corresponding GAAP measures is not available without unreasonable effort.

[0001327567-15-000015:8k_2_02:27]
Conference Call Information

[0001327567-15-000015:8k_2_02:28]
Palo Alto Networks will host a conference call for analysts and investors to discuss its fiscal third quarter 2015 results and outlook for its fiscal fourth quarter 2015 today at 4:30 PM Eastern time/1:30 PM Pacific time. Open to the public, investors may access the call by dialing 1-877-795-3635 or 1-719-325-4784 and entering the passcode 6909255. A live audio webcast of the conference call along with supplemental financial information will also be accessible from the “Investors” section of the company’s website at investors.paloaltonetworks.com. Following the webcast, an archived version will be available on the website for one year. A telephonic replay of the call will be available two hours after the call and will run for five business days and may be accessed by dialing 1-888-203-1112 or 1-719-457-0820 and entering the passcode 6909255.

[0001327567-15-000015:8k_2_02:29]
Forward-Looking Statements

[0001327567-15-000015:8k_2_02:30]
This press release contains forward-looking statements that involve risks and uncertainties, including statements regarding our financial outlook for the fiscal fourth quarter of 2015, the expected timing of when we will offer CirroSecure as a new subscription-based service, our ability to continue to expand market share with growth rates that significantly outpace the market and continued leverage resulting from our hybrid-SAAS model. There are a significant number of factors that could cause actual results to differ materially from statements made in this press release, including: our limited operating history; risks associated with our rapid growth, particularly outside of the United States; our limited experience with new product introductions and the risks associated with new products, including software bugs; our ability to successfully integrate our operations with those of recently acquired CirroSecure; the failure to timely develop and achieve market acceptance of new products as well as existing products and services; rapidly evolving technological developments in the market for network security products; and general market, political, economic and business conditions.

[0001327567-15-000015:8k_2_02:31]
3

[0001327567-15-000015:8k_2_02:32]
Additional risks and uncertainties that could affect our financial results are included under the captions “Risk Factors” and “Management’s Discussion and Analysis of Financial Condition and Results of Operations,” in our quarterly report on Form 10-Q filed with the SEC on March 3, 2015, which is available on our website at investors.paloaltonetworks.com and on the SEC’s website at www.sec.gov. Additional information will also be set forth in other filings that we make with the SEC from time to time. All forward-looking statements in this press release are based on information available to us as of the date hereof, and we do not assume any obligation to update the forward-looking statements provided to reflect events that occur or circumstances that exist after the date on which they were made.

[0001327567-15-000015:8k_2_02:33]
Non-GAAP Financial Measures

[0001327567-15-000015:8k_2_02:34]
Palo Alto Networks has provided in this release financial information that has not been prepared in accordance with generally accepted accounting principles in the United States (GAAP). The company uses these non-GAAP financial measures internally in analyzing its financial results and believes that the use of these non-GAAP financial measures is useful to investors as an additional tool to evaluate ongoing operating results and trends and in comparing the company’s financial results with other companies in its industry, many of which present similar non-GAAP financial measures.

[0001327567-15-000015:8k_2_02:35]
Non-GAAP financial measures are not meant to be considered in isolation or as a substitute for comparable GAAP financial measures, and should be read only in conjunction with the company’s consolidated financial statements prepared in accordance with GAAP. A reconciliation of the company’s non-GAAP financial measures to their most directly comparable GAAP measures has been provided in the financial statement tables included in this press release, and investors are encouraged to review the reconciliation.

[0001327567-15-000015:8k_2_02:36]
Non-GAAP net income and diluted net income per share. Palo Alto Networks defines non-GAAP net income as net income (loss) plus share-based compensation related charges including share-based payroll tax expense, acquisition related costs, amortization expense of acquired intangible assets, litigation related charges including legal settlements, non-cash interest expense related to the company’s convertible senior notes, and intellectual property restructuring related charges. The company also excludes from non-GAAP net income the foreign currency gains (losses) and tax effects associated with these items in order to provide a complete picture of the company’s recurring core business operating results. The Company defines non-GAAP net income per share as non-GAAP net income divided by the weighted average diluted shares outstanding after giving effect to the anti-dilutive impact of the company’s note hedge

[0001327567-15-000015:8k_2_02:37]
agreements. The anti-dilutive impact reduces the potential economic dilution that otherwise would occur upon conversion of the company’s convertible senior notes. Under GAAP, the anti-dilutive impact of the note hedge is not reflected in diluted shares. Palo Alto Networks believes that excluding these items from non-GAAP net income and non-GAAP diluted net income per share provides management and investors with greater visibility into the underlying performance of the company’s core business operating results, meaning its operating performance excluding these items and, from time to time, other discrete charges that are infrequent in nature, over multiple periods.

[0001327567-15-000015:8k_2_02:38]
Billings. Palo Alto Networks defines billings as total revenue plus the change in deferred revenue, net of acquired deferred revenue, during the period. The company’s management monitors billings because billings drive deferred revenue, which is an important indicator of the health and visibility of the company’s business. The company considers billings to be a useful metric for management and investors, particularly as sales of subscriptions increase and the company experiences strong renewal rates for subscriptions and support and maintenance.

[0001327567-15-000015:8k_2_02:39]
Investors are cautioned that there are a number of limitations associated with the use of non-GAAP financial measures as an analytical tool. In particular, many of the adjustments to the company’s GAAP financial measures reflect the exclusion of items that are recurring and will be reflected in the company’s financial results for the foreseeable future, such as share-based compensation. Share-based compensation is an important part of Palo Alto Networks employees’ compensation and impacts their performance. In addition, the billings metric reported by the company includes amounts that have not yet been recognized as revenue. The components that Palo Alto Networks excludes in its calculation of non-GAAP financial measures may differ from the components that its peer companies exclude when they report their non-GAAP results of operations. Palo Alto Networks compensates for these limitations by providing specific information regarding the GAAP amounts excluded from these non-GAAP financial measures. In the future, the company may also exclude non-recurring expenses and other expenses that do not reflect the company’s core business operating results.

[0001327567-15-000015:8k_2_02:40]
About Palo Alto Networks

[0001327567-15-000015:8k_2_02:41]
Palo Alto Networks is leading a new era in cybersecurity by protecting thousands of enterprise, government, and service provider networks from cyber threats. Unlike fragmented legacy products, our security platform safely enables business operations and delivers protection based on what matters most in today’s dynamic computing environments: applications, users, and content. Find out more at www.paloaltonetworks.com.

[0001327567-15-000015:8k_2_02:42]
5

[0001327567-15-000015:8k_2_02:43]
Palo Alto Networks and the Palo Alto Networks Logo are trademarks of Palo Alto Networks, Inc. in the United States and in jurisdictions throughout the world. All other trademarks, trade names or service marks used or mentioned herein belong to their respective owners.

[0001327567-15-000015:8k_2_02:44]
Gartner does not endorse any vendor, product or service depicted in its research publications, and does not advise technology users to select only those vendors with the highest ratings or other designation. Gartner research publications consist of the opinions of Gartner's research organization and should not be construed as statements of fact. Gartner disclaims all warranties, expressed or implied, with respect to this research, including any warranties of merchantability or fitness for a particular purpose.

[0001327567-15-000015:8k_2_02:45]
Media Contact:

[0001327567-15-000015:8k_2_02:46]
Jennifer Jasper Smith

[0001327567-15-000015:8k_2_02:47]
Head of Corporate Communications

[0001327567-15-000015:8k_2_02:48]
Palo Alto Networks

[0001327567-15-000015:8k_2_02:49]
408-638-3280

[0001327567-15-000015:8k_2_02:50]
jjsmith@paloaltonetworks.com

[0001327567-15-000015:8k_2_02:51]
Investor Relations Contact:

[0001327567-15-000015:8k_2_02:52]
Kelsey Turcotte

[0001327567-15-000015:8k_2_02:53]
Vice President of Investor Relations

[0001327567-15-000015:8k_2_02:54]
408-753-3872

[0001327567-15-000015:8k_2_02:55]
kturcotte@paloaltonetworks.com

[0001327567-15-000015:8k_2_02:56]
Chris Danne/Maria Riley

[0001327567-15-000015:8k_2_02:57]
The Blueshirt Group

[0001327567-15-000015:8k_2_02:58]
415-217-7722

[0001327567-15-000015:8k_2_02:59]
ir@paloaltonetworks.com

[0001327567-15-000015:8k_2_02:60]
| Palo Alto Networks, Inc. |
| Preliminary Condensed Consolidated Statements of Operations |
| (In thousands, except per share data) |
| (Unaudited) |
|  | Three Months Ended April 30, |  | Nine Months Ended April 30, |
|  | 2015 |  | 2014 |  | 2015 |  | 2014 |
| Revenue: |  |  |  |  |  |  |  |
| Product | $ | 121,524 |  |  | $ | 84,128 |  |  | $ | 338,621 |  |  | $ | 240,436 |  |
| Services | 112,648 |  |  | 66,572 |  |  | 305,552 |  |  | 179,512 |  |
| Total revenue | 234,172 |  |  | 150,700 |  |  | 644,173 |  |  | 419,948 |  |
| Cost of revenue: |  |  |  |  |  |  |  |
| Product | 32,851 |  |  | 20,425 |  |  | 92,632 |  |  | 58,600 |  |
| Services | 31,544 |  |  | 19,285 |  |  | 84,549 |  |  | 52,421 |  |
| Total cost of revenue | 64,395 |  |  | 39,710 |  |  | 177,181 |  |  | 111,021 |  |
| Total gross profit | 169,777 |  |  | 110,990 |  |  | 466,992 |  |  | 308,927 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 48,486 |  |  | 27,837 |  |  | 132,739 |  |  | 71,983 |  |
| Sales and marketing | 131,026 |  |  | 83,995 |  |  | 360,267 |  |  | 228,095 |  |
| General and administrative | 26,989 |  |  | 23,717 |  |  | 72,989 |  |  | 57,575 |  |
| Legal settlement | — |  |  | 121,173 |  |  | — |  |  | 141,173 |  |
| Total operating expenses | 206,501 |  |  | 256,722 |  |  | 565,995 |  |  | 498,826 |  |
| Operating loss | (36,724 | ) |  | (145,732 | ) |  | (99,003 | ) |  | (189,899 | ) |
| Interest expense | (5,631 | ) |  | (13 | ) |  | (16,659 | ) |  | (35 | ) |
| Other income (expense), net | (55 | ) |  | 430 |  |  | 630 |  |  | 665 |  |
| Loss before income taxes | (42,410 | ) |  | (145,315 | ) |  | (115,032 | ) |  | (189,269 | ) |
| Provision for income taxes | 3,525 |  |  | 1,272 |  |  | 3,979 |  |  | 5,125 |  |
| Net loss | $ | (45,935 | ) |  | $ | (146,587 | ) |  | $ | (119,011 | ) |  | $ | (194,394 | ) |
| Net loss per share, basic and diluted | $ | (0.56 | ) |  | $ | (1.96 | ) |  | $ | (1.47 | ) |  | $ | (2.66 | ) |
| Weighted-average shares used to compute net loss per share, basic and diluted | 82,320 |  |  | 74,967 |  |  | 80,828 |  |  | 73,127 |  |

[0001327567-15-000015:8k_2_02:61]
7

[0001327567-15-000015:8k_2_02:62]
| Palo Alto Networks, Inc. |
| Reconciliation of GAAP to Non-GAAP Financial Measures |
| (In thousands, except per share amounts) |
| (Unaudited) |
|  | Three Months Ended April 30, |  | Nine Months Ended April 30, |
|  | 2015 |  | 2014 |  | 2015 |  | 2014 |
| GAAP net loss | $ | (45,935 | ) |  | $ | (146,587 | ) |  | $ | (119,011 | ) |  | $ | (194,394 | ) |
| Share-based compensation related charges | 64,175 |  |  | 29,197 |  |  | 164,312 |  |  | 67,228 |  |
| Acquisition related costs | 349 |  |  | 3,681 |  |  | 349 |  |  | 7,480 |  |
| Amortization expense of acquired intangible assets | 1,725 |  |  | 614 |  |  | 4,993 |  |  | 679 |  |
| Litigation related charges [a] | 3,065 |  |  | 125,905 |  |  | 9,195 |  |  | 150,447 |  |
| Non-cash interest expense related to convertible notes | 5,610 |  |  | — |  |  | 16,609 |  |  | — |  |
| Foreign currency loss associated with an acquisition related tax liability | 514 |  |  | — |  |  | 514 |  |  | — |  |
| Income tax and other tax adjustments related to the above | (9,025 | ) |  | (4,079 | ) |  | (26,778 | ) |  | (8,769 | ) |
| Non-GAAP net income | $ | 20,478 |  |  | $ | 8,731 |  |  | $ | 50,183 |  |  | $ | 22,671 |  |
| GAAP net loss per share, diluted | $ | (0.56 | ) |  | $ | (1.96 | ) |  | $ | (1.47 | ) |  | $ | (2.66 | ) |
| Share-based compensation related charges | 0.76 |  |  | 0.38 |  |  | 1.99 |  |  | 0.90 |  |
| Acquisition related costs | 0.00 |  |  | 0.05 |  |  | 0.00 |  |  | 0.10 |  |
| Amortization expense of acquired intangible assets | 0.02 |  |  | 0.01 |  |  | 0.06 |  |  | 0.01 |  |
| Litigation related charges [a] | 0.04 |  |  | 1.68 |  |  | 0.11 |  |  | 2.06 |  |
| Non-cash interest expense related to convertible notes | 0.07 |  |  | 0.00 |  |  | 0.21 |  |  | 0.00 |  |
| Foreign currency loss associated with an acquisition related tax liability | 0.01 |  |  | 0.00 |  |  | 0.01 |  |  | 0.00 |  |
| Income tax and other tax adjustments related to the above | (0.11 | ) |  | (0.05 | ) |  | (0.33 | ) |  | (0.12 | ) |
| Non-GAAP net income per share, diluted | $ | 0.23 |  |  | $ | 0.11 |  |  | $ | 0.58 |  |  | $ | 0.29 |  |
| GAAP weighted-average shares used to compute net loss per share, diluted | 82,320 |  |  | 74,967 |  |  | 80,828 |  |  | 73,127 |  |
| Weighted-average effect of potentially dilutive securities [b] | 5,711 |  |  | 5,248 |  |  | 5,618 |  |  | 5,350 |  |
| Non-GAAP weighted-average shares used to compute net income per share, diluted | 88,031 |  |  | 80,215 |  |  | 86,446 |  |  | 78,477 |  |
| Revenue | $ | 234,172 |  |  | $ | 150,700 |  |  | $ | 644,173 |  |  | $ | 419,948 |  |
| Change in deferred revenue, net of acquired deferred revenue | 68,047 |  |  | 43,190 |  |  | 181,312 |  |  | 118,551 |  |
| Billings | $ | 302,219 |  |  | $ | 193,890 |  |  | $ | 825,485 |  |  | $ | 538,499 |  |

[0001327567-15-000015:8k_2_02:63]
___________

[0001327567-15-000015:8k_2_02:64]
[a]    Litigation related charges during the three and nine months ended April 30, 2015 includes the amortization of intellectual property licenses entered into as part of the legal settlement with Juniper Networks, Inc. (“Juniper”). Litigation related charges during the three and nine months ended April 30, 2014 includes expenses for legal services, the legal settlement with Fortinet, Inc. of $20.0 million, and the legal settlement with Juniper of $121.2 million.

[0001327567-15-000015:8k_2_02:65]
[b]    Non-GAAP net income per share, diluted, includes the potentially dilutive effect of options, restricted stock units, and convertible senior notes outstanding. In addition, Non-GAAP net income per share, diluted, includes the anti-dilutive impact of the company’s note hedge agreements, which reduced the potentially dilutive effect of the convertible notes for the three and nine months ended April 30, 2015 by 1.3 million shares and 0.6 million shares, respectively. The potentially dilutive effect of the convertible notes for the three and nine months ended April 30, 2014 was nil.

[0001327567-15-000015:8k_2_02:66]
8

[0001327567-15-000015:8k_2_02:67]
| Palo Alto Networks, Inc. |
| Preliminary Condensed Consolidated Balance Sheets |
| (In thousands) |
| (Unaudited) |
|  | April 30, 2015 |  | July 31, 2014 |
| Assets |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 454,123 |  |  | $ | 653,812 |  |
| Short-term investments | 368,850 |  |  | 118,690 |  |
| Accounts receivable, net | 150,523 |  |  | 135,518 |  |
| Prepaid expenses and other current assets | 67,013 |  |  | 50,306 |  |
| Total current assets | 1,040,509 |  |  | 958,326 |  |
| Property and equipment, net | 59,546 |  |  | 48,744 |  |
| Long-term investments | 408,465 |  |  | 201,880 |  |
| Goodwill | 155,402 |  |  | 155,033 |  |
| Intangible assets, net | 43,885 |  |  | 47,955 |  |
| Other assets | 76,625 |  |  | 66,528 |  |
| Total assets | $ | 1,784,432 |  |  | $ | 1,478,466 |  |
| Liabilities, temporary equity, and stockholders’ equity |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 14,661 |  |  | $ | 14,526 |  |
| Accrued compensation | 53,467 |  |  | 48,727 |  |
| Accrued and other liabilities | 28,535 |  |  | 25,000 |  |
| Deferred revenue | 365,384 |  |  | 259,918 |  |
| Convertible senior notes, net | 481,960 |  |  | — |  |
| Total current liabilities | 944,007 |  |  | 348,171 |  |
| Convertible senior notes, net | — |  |  | 466,875 |  |
| Long-term deferred revenue | 238,506 |  |  | 162,660 |  |
| Other long-term liabilities | 54,601 |  |  | 32,177 |  |
| Temporary equity | 93,040 |  |  | — |  |
| Stockholders’ equity: |  |  |  |
| Preferred stock | — |  |  | — |  |
| Common stock | 8 |  |  | 8 |  |
| Additional paid-in capital | 908,867 |  |  | 804,406 |  |
| Accumulated other comprehensive income (loss) | 140 |  |  | (105 | ) |
| Accumulated deficit | (454,737 | ) |  | (335,726 | ) |
| Total stockholders’ equity | 454,278 |  |  | 468,583 |  |
| Total liabilities, temporary equity, and stockholders’ equity | $ | 1,784,432 |  |  | $ | 1,478,466 |  |

[0001327567-15-000015:8k_2_02:68]
9

[0001327567-15-000015:8k_2_02:69]
| Palo Alto Networks, Inc. |
| Preliminary Condensed Consolidated Statements of Cash Flows |
| (In thousands) |
| (Unaudited) |
|  | Nine Months Ended April 30, |
|  | 2015 |  | 2014 |
| Cash flows from operating activities |  |  |  |
| Net loss | $ | (119,011 | ) |  | $ | (194,394 | ) |
| Adjustments to reconcile net loss to net cash provided by operating activities: |  |  |  |
| Share-based compensation for equity based awards | 155,498 |  |  | 66,685 |  |
| Depreciation and amortization | 20,273 |  |  | 11,638 |  |
| Amortization of investment premiums, net of accretion of purchase discounts | 2,308 |  |  | 1,180 |  |
| Amortization of debt discount and debt issuance costs | 16,610 |  |  | — |  |
| Excess tax benefit from share-based compensation arrangements | (518 | ) |  | (758 | ) |
| Changes in operating assets and liabilities, net of effects of acquisitions: |  |  |  |
| Accounts receivable, net | (15,005 | ) |  | (27,220 | ) |
| Prepaid expenses and other assets | (30,885 | ) |  | (7,926 | ) |
| Accounts payable | (3,896 | ) |  | 8,965 |  |
| Accrued compensation | 4,750 |  |  | 6,792 |  |
| Accrued and other liabilities | 27,543 |  |  | 131,043 |  |
| Deferred revenue | 181,312 |  |  | 118,551 |  |
| Net cash provided by operating activities | 238,979 |  |  | 114,556 |  |
| Cash flows from investing activities |  |  |  |
| Purchases of investments | (666,471 | ) |  | (316,911 | ) |
| Proceeds from sales of investments | 7,000 |  |  | 6,630 |  |
| Proceeds from maturities of investments | 200,798 |  |  | 198,080 |  |
| Business acquisitions, net of cash acquired | — |  |  | (85,726 | ) |
| Purchases of property, equipment, and other assets | (21,862 | ) |  | (31,379 | ) |
| Net cash used in investing activities | (480,535 | ) |  | (229,306 | ) |
| Cash flows from financing activities |  |  |  |
| Proceeds from exercises of stock options | 23,136 |  |  | 25,431 |  |
| Proceeds from employee stock purchase plan | 18,213 |  |  | 12,869 |  |
| Excess tax benefit from share-based compensation arrangements | 518 |  |  | 758 |  |
| Repurchases of restricted common stock from terminated employees | — |  |  | (132 | ) |
| Net cash provided by financing activities | 41,867 |  |  | 38,926 |  |
| Net decrease in cash and cash equivalents | (199,689 | ) |  | (75,824 | ) |
| Cash and cash equivalents - beginning of period | 653,812 |  |  | 310,614 |  |
| Cash and cash equivalents - end of period | $ | 454,123 |  |  | $ | 234,790 |  |

[0001327567-15-000015:8k_2_02:70]
10
