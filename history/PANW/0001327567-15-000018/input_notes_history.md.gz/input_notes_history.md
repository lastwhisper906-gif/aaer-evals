# PANW note change history — 0001327567-15-000008 → 0001327567-15-000018


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2015-05-28):
[0001327567-15-000018:note_history:1]
The following table presents details of the aggregate future non-cancelable minimum rental payments under our operating leases as of April 30, 2015 (in thousands):
  (was, 2015-03-03, similarity 0.9748):
[0001327567-15-000008:note_history:1]
The following table presents details of the aggregate future non-cancelable minimum rental payments under our operating leases as of January 31, 2015 (in thousands):

- changed (2015-05-28):
[0001327567-15-000018:note_history:2]
Our independent contract manufacturer procures components and assembles our products based on our forecasts. These forecasts are based on estimates of demand for our products primarily for the next twelve months, which are in turn based on historical trends and an analysis from our sales and product marketing organizations, adjusted for overall market conditions. In order to reduce manufacturing lead times and plan for adequate supply, we may issue forecasts and orders for components and products that are non-cancelable. Obligations under contracts that we can cancel without a significant penalty are not included. As of April 30, 2015, we had $41,772,000 of open orders.
  (was, 2015-03-03, similarity 0.991):
[0001327567-15-000008:note_history:2]
Our independent contract manufacturer procures components and assembles our products based on our forecasts. These forecasts are based on estimates of demand for our products primarily for the next twelve months, which are in turn based on historical trends and an analysis from our sales and product marketing organizations, adjusted for overall market conditions. In order to reduce manufacturing lead times and plan for adequate supply, we may issue forecasts and orders for components and products that are non-cancelable. Obligations under contracts that we can cancel without a significant penalty are not included. As of January 31, 2015, we had $38,893,000 of open orders.

- changed (2015-05-28):
[0001327567-15-000018:note_history:3]
In addition to the above matter, we are subject to legal proceedings, claims, and litigation arising in the ordinary course of business, including intellectual property litigation. Such matters are subject to many uncertainties and outcomes are not predictable with assurance. We accrue for contingencies when we believe that a loss is probable and that we can reasonably estimate the amount of any such loss.
  (was, 2015-03-03, similarity 0.8702):
[0001327567-15-000008:note_history:3]
In addition to the above matter, we are subject to legal proceedings, claims, and litigation arising in the ordinary course of business, including intellectual property litigation. Such matters are subject to many uncertainties and outcomes are not predictable with assurance. We accrue for contingencies when we believe that a loss is probable and that we can reasonably estimate the amount of any such loss. We have made an assessment of the probability of incurring any such losses and whether or not those losses are estimable.

- added (2015-05-28):
[0001327567-15-000018:note_history:4]
To the extent there is a reasonable possibility that a loss exceeding amounts already recognized may be incurred and the amount of such additional loss would be material, we will either disclose the estimated additional loss or state that such an estimate cannot be made. As of April 30, 2015, we have not recorded any significant accruals for loss contingencies associated with such legal proceedings, determined that an unfavorable outcome is probable or reasonably possible, or determined that the amount or range of any possible loss is reasonably estimable.

- removed (2015-05-28):
[0001327567-15-000008:note_history:5]
To the extent there is a reasonable possibility that a loss exceeding amounts already recognized may be incurred and the amount of such additional loss would be material, we will either disclose the estimated additional loss or state that such an estimate cannot be made. As of January 31, 2015, we have not recorded any accrual for loss contingencies associated with such legal proceedings, determined that an unfavorable outcome is probable or reasonably possible, or determined that the amount or range of any possible loss is reasonably estimable.


## us-gaap:LegalMattersAndContingenciesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2015-05-28):
[0001327567-15-000018:note_history:6]
On May 27, 2014, we entered into the settlement agreement with Juniper, whereby we resolved all pending litigation matters. Under the terms of the settlement agreement, we agreed to pay Juniper a one-time settlement amount comprised of $75,000,000 in cash, 1,081,000 shares of our common stock, and a warrant to purchase 463,000 shares of our common stock, in exchange for the following:
  (was, 2015-03-03, similarity 0.8391):
[0001327567-15-000008:note_history:6]
On May 27, 2014, we entered into the settlement agreement with Juniper, whereby we resolved all pending litigation matters. Under the terms of the settlement agreement, we agreed to pay Juniper a one-time settlement amount of approximately $175,000,000, which was comprised of $75,000,000 in cash, 1,081,000 shares of our common stock with an approximate value of $70,000,000, and a warrant to purchase 463,000 shares of our common stock with an approximate value of $30,000,000, in exchange for the following:

- changed (2015-05-28):
[0001327567-15-000018:note_history:7]
The fair value of the total consideration as of the settlement date was $182,473,000, which was comprised of $75,000,000 in cash, $75,231,000 in common stock, and $32,242,000 in warrant. The fair values of the common stock and warrant were measured using the closing price of our common stock on the settlement date.
  (was, 2015-03-03, similarity 0.957):
[0001327567-15-000008:note_history:7]
For accounting purposes, the fair value of the total consideration as of the settlement date was $182,473,000, which was comprised of $75,000,000 in cash, $75,231,000 in common stock, and $32,242,000 in warrant. The fair values of the common stock and warrant were measured using the closing price of our common stock on the settlement date.

- changed (2015-05-28):
[0001327567-15-000018:note_history:8]
We accounted for the settlement agreement as a multiple-element arrangement and allocated the fair value of the consideration as of the settlement date to the identifiable elements based on their estimated fair values. Of the total settlement amount, $61,300,000 was allocated to the licensing of intellectual property, $54,300,000 was allocated to the mutual dismissal of claims, and the remaining amount was allocated to the mutual covenant not to sue. The mutual dismissal of claims and the mutual covenant not to sue have no identifiable future benefit, and as a result we recorded a settlement charge within legal settlement expense in our condensed consolidated statement of operations during the three months ended April 30, 2014. The licensing of intellectual property is being amortized to cost of product revenue in our condensed consolidated statements of operations over the estimated period of benefit of five years.
  (was, 2015-03-03, similarity 0.9062):
[0001327567-15-000008:note_history:8]
We accounted for the settlement agreement as a multiple-element arrangement and allocated the fair value of the consideration as of the settlement date to the identifiable elements based on their estimated fair values. Of the total settlement amount, $61,300,000 was allocated to the licensing of intellectual property, $54,300,000 was allocated to the mutual dismissal of claims, and the remaining amount was allocated to the mutual covenant not to sue. The mutual dismissal of claims and the mutual covenant not to sue have no identifiable future benefit, and as a result we recorded a settlement charge within legal settlement expense in our condensed consolidated statement of operations during the three months ended April 30, 2014. The licensing of intellectual property is being amortized over the estimated period of benefit of five years.


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2015-05-28):
[0001327567-15-000018:note_history:9]
There have been no material changes to our significant accounting policies as of and for the nine months ended April 30, 2015, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended July 31, 2014.
  (was, 2015-03-03, similarity 0.9058):
[0001327567-15-000008:note_history:9]
There have been no material changes to our significant accounting policies as of and for the six months ended January 31, 2015, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended July 31, 2014.

- added (2015-05-28):
[0001327567-15-000018:note_history:10]
In April 2015, the Financial Accounting Standards Board (FASB) issued new authoritative guidance on fees paid in a cloud computing arrangement. The standard requires customers in a cloud computing arrangement to evaluate whether the arrangement includes a software license. If the arrangement includes a software license, the customer should account for the software license element of the arrangement consistent with the acquisition of other software licenses. If the arrangement does not include a software license, the customer should account for the arrangement as a service contract. The standard is effective for us for our first quarter of fiscal 2017, although early adoption is permitted, and will be applied on either a prospective or retrospective basis. We are currently evaluating adoption methods and whether this standard will have a material impact on our condensed consolidated financial statements.

- added (2015-05-28):
[0001327567-15-000018:note_history:11]
In April 2015, the FASB issued updated authoritative guidance to simplify the presentation of debt issuance costs. The amended standard requires that debt issuance costs related to a recognized debt liability be presented in the balance sheet as a direct deduction from the carrying amount of the related debt liability, consistent with the presentation of debt discounts, instead of being presented as an asset. The amended standard is effective for us for our first quarter of fiscal 2017, although early adoption is permitted, and will be applied on a retrospective basis. Upon adoption, the amended standard will change the classification of our unamortized debt issuance costs in our condensed consolidated balance sheets.

- changed (2015-05-28):
[0001327567-15-000018:note_history:12]
In August 2014, the FASB issued new authoritative guidance about management's responsibility to evaluate whether there is substantial doubt about an entity's ability to continue as a going concern and to provide related footnote disclosures. The standard is effective for us for our fourth quarter of fiscal 2017, although early adoption is permitted. The adoption of this standard is not expected to have a material impact on our condensed consolidated financial statements.
  (was, 2015-03-03, similarity 0.6312):
[0001327567-15-000008:note_history:12]
In August 2014, the Financial Accounting Standards Board (FASB) issued Accounting Standards Update (ASU) No. 2014-15, Presentation of Financial Statements-Going Concern (Subtopic 205-40)-Disclosure of Uncertainties about an Entity’s Ability to Continue as a Going Concern. The standard provides guidance about management's responsibility to evaluate whether there is substantial doubt about an entity's ability to continue as a going concern and to provide related footnote disclosures. The standard is effective for fiscal years ending after December 15, 2016, and for interim periods thereafter. Early adoption is permitted. We will adopt the new standard in our fiscal year ending 2017. The adoption of this standard is not expected to have a material impact on our condensed consolidated financial statements.

- added (2015-05-28):
[0001327567-15-000018:note_history:13]
In May 2014, the FASB issued new authoritative guidance on revenue from contracts with customers. The new standard provides principles for recognizing revenue for the transfer of promised goods or services to customers with the consideration to which the entity expects to be entitled in exchange for those goods or services. The standard also requires significantly expanded disclosures about revenue recognition. The guidance is effective for us for our first quarter of fiscal 2018 using either of two methods: (i) retrospective to each prior reporting period presented with the option to elect certain practical expedients as defined within the guidance; or (ii) retrospective with the cumulative effect of initially applying the guidance recognized at the date of initial application and providing certain additional disclosures as defined per the guidance. Early adoption is not permitted. We are currently evaluating adoption methods and whether this standard will have a material impact on our condensed consolidated financial statements.

- added (2015-05-28):
[0001327567-15-000018:note_history:14]
In July 2013, the FASB issued new authoritative guidance on the financial statement presentation of an unrecognized tax benefit when a net operating loss carryforward, a similar tax loss, or a tax credit carryforward exists. The standard requires us to present an unrecognized tax benefit as a reduction of a deferred tax asset for a net operating loss (NOL) carryforward or other tax credit carryforward when settlement in this manner is available under applicable tax law. The guidance was effective for us in the first quarter of fiscal 2015. Our adoption of this guidance did not have an impact on our condensed consolidated financial statements.

- removed (2015-05-28):
[0001327567-15-000008:note_history:15]
In May 2014, the FASB issued ASU No. 2014-09 regarding Accounting Standards Codification (ASC) Topic 606-Revenue from Contracts with Customers. The standard provides principles for recognizing revenue for the transfer of promised goods or services to customers with the consideration to which the entity expects to be entitled in exchange for those goods or services. The standard also requires significantly expanded disclosures about revenue recognition. The guidance is effective for us in the first quarter of fiscal 2018 using either of two methods: (i) retrospective to each prior reporting period presented with the option to elect certain practical expedients as defined within the guidance; or (ii) retrospective with the cumulative effect of initially applying the guidance recognized at the date of initial application and providing certain additional disclosures as defined per the guidance. Early adoption is not permitted. We are currently evaluating adoption methods and whether this standard will have a material impact on our condensed consolidated financial statements.

- removed (2015-05-28):
[0001327567-15-000008:note_history:16]
In July 2013, the FASB issued ASU No. 2013-11, Income Taxes (Topic 740)-Presentation of an Unrecognized Tax Benefit When a Net Operating Loss Carryforward, a Similar Tax Loss, or a Tax Credit Carryforward Exists. The standard requires us to present an unrecognized tax benefit as a reduction of a deferred tax asset for a net operating loss (NOL) carryforward or other tax credit carryforward when settlement in this manner is available under applicable tax law. The guidance was effective for us in the first quarter of fiscal 2015. Our adoption of this guidance did not have an impact on our condensed consolidated financial statements.


## us-gaap:ConvertibleDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2015-05-28):
[0001327567-15-000018:note_history:17]
The following table sets forth the components of the Notes as of April 30, 2015 and July 31, 2014 (in thousands):
  (was, 2015-03-03, similarity 0.9615):
[0001327567-15-000008:note_history:17]
The following table sets forth the components of the Notes as of January 31, 2015 and July 31, 2014 (in thousands):

- changed (2015-05-28):
[0001327567-15-000018:note_history:18]
|  | April 30, 2015 |  | July 31, 2014 |
| Liability: |  |  |  |
| Principal | $ | 575,000 |  |  | $ | 575,000 |  |
| Less: debt discount, net of amortization | 93,040 |  |  | 108,125 |  |
| Net carrying amount | $ | 481,960 |  |  | $ | 466,875 |  |
  (was, 2015-03-03, similarity 0.8789):
[0001327567-15-000008:note_history:18]
|  | January 31, 2015 |  | July 31, 2014 |
| Liability: |  |  |  |
| Principal | $ | 575,000 |  |  | $ | 575,000 |  |
| Less: debt discount, net of amortization | 98,128 |  |  | 108,125 |  |
| Net carrying amount | $ | 476,872 |  |  | $ | 466,875 |  |
| Equity | $ | (109,785 | ) |  | $ | (109,785 | ) |


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2015-05-28):
[0001327567-15-000018:note_history:19]
The Notes are convertible for up to 5,214,000 shares of our common stock at an initial conversion rate of approximately 9.068 shares of common stock per $1,000 principal amount, which is equal to an initial conversion price of approximately $110.28 per share of common stock, subject to adjustment. Holders of the Notes may surrender their Notes for conversion at their option at any time prior to the close of business on the business day immediately preceding January 1, 2019, only under the following circumstances:
  (was, 2015-03-03, similarity 0.9638):
[0001327567-15-000008:note_history:19]
The Notes are convertible for up to 5,214,000 shares of our common stock at an initial conversion rate of approximately 9.068 shares of common stock per $1,000 principal amount, which is equal to an initial conversion price of approximately $110.28 per share of common stock, subject to adjustment. Holders of the Notes may surrender their Notes for conversion at their option at any time prior to the close of business on the business day immediately preceding January 1, 2019, only under the following circumstances, none of which have occurred to date:

- changed (2015-05-28):
[0001327567-15-000018:note_history:20]
In accounting for the issuance of the Notes, we separated the Notes into liability and equity components. The carrying amount of the liability component was calculated by measuring the fair value of a similar liability that does not have an associated convertible feature. The carrying amount of the equity component representing the conversion option was determined by deducting the fair value of the liability component from the par value of the Notes as a whole. The difference between the principal amount of the Notes and the liability component (the “debt discount”), is amortized to interest expense using the effective interest method over the term of the Notes. The equity component of the Notes was recorded in additional paid-in capital in our condensed consolidated balance sheets and is not remeasured as long as it continues to meet the conditions for equity classification.
  (was, 2015-03-03, similarity 0.9904):
[0001327567-15-000008:note_history:20]
In accounting for the issuance of the Notes, we separated the Notes into liability and equity components. The carrying amount of the liability component was calculated by measuring the fair value of a similar liability that does not have an associated convertible feature. The carrying amount of the equity component representing the conversion option was determined by deducting the fair value of the liability component from the par value of the Notes as a whole. The difference between the principal amount of the Notes and the liability component (the “debt discount”), is amortized to interest expense using the effective interest method over the term of the Notes. The equity component of the Notes is included in additional paid-in capital in our condensed consolidated balance sheets and is not remeasured as long as it continues to meet the conditions for equity classification.

- added (2015-05-28):
[0001327567-15-000018:note_history:21]
During the fiscal quarter ended April 30, 2015, the last reported sale price of our common stock was greater than or equal to 130% of the conversion price of the Notes for at least 20 of the last 30 consecutive trading days of such quarter. As a result, holders may convert their Notes at any time during the fiscal quarter ending July 31, 2015. Accordingly, as of April 30, 2015, we reclassified the net carrying amount of the Notes and related debt issuance costs to current liabilities and current assets, respectively, in our condensed consolidated balance sheets. We also reclassified a portion of the equity component representing the conversion option to temporary equity in our condensed consolidated balance sheets. The amount reclassified to temporary equity was measured as the difference between the principal and net carrying amount of the Notes as of April 30, 2015.

- changed (2015-05-28):
[0001327567-15-000018:note_history:22]
The following table sets forth the components of the Notes as of April 30, 2015 and July 31, 2014 (in thousands):
  (was, 2015-03-03, similarity 0.9615):
[0001327567-15-000008:note_history:22]
The following table sets forth the components of the Notes as of January 31, 2015 and July 31, 2014 (in thousands):

- changed (2015-05-28):
[0001327567-15-000018:note_history:23]
|  | April 30, 2015 |  | July 31, 2014 |
| Liability: |  |  |  |
| Principal | $ | 575,000 |  |  | $ | 575,000 |  |
| Less: debt discount, net of amortization | 93,040 |  |  | 108,125 |  |
| Net carrying amount | $ | 481,960 |  |  | $ | 466,875 |  |
  (was, 2015-03-03, similarity 0.8789):
[0001327567-15-000008:note_history:23]
|  | January 31, 2015 |  | July 31, 2014 |
| Liability: |  |  |  |
| Principal | $ | 575,000 |  |  | $ | 575,000 |  |
| Less: debt discount, net of amortization | 98,128 |  |  | 108,125 |  |
| Net carrying amount | $ | 476,872 |  |  | $ | 466,875 |  |
| Equity | $ | (109,785 | ) |  | $ | (109,785 | ) |

- changed (2015-05-28):
[0001327567-15-000018:note_history:24]
The total estimated fair value of the Notes was $836,987,000 and $587,087,000 at April 30, 2015 and July 31, 2014, respectively. The fair value was determined based on the closing trading price per $100 of the Notes as of the last day of trading for the period. We consider the fair value of the Notes at April 30, 2015 and July 31, 2014 to be a Level 2 measurement. The fair value of the Notes is primarily affected by the trading price of our common stock and market interest rates. As of April 30, 2015, the if-converted value of the Notes exceeded its principal amount by $188,879,000.
  (was, 2015-03-03, similarity 0.9323):
[0001327567-15-000008:note_history:24]
The total estimated fair value of the Notes was $751,813,000 and $587,087,000 at January 31, 2015 and July 31, 2014, respectively. The fair value was determined based on the closing trading price per $100 of the Notes as of the last day of trading for the period. We consider the fair value of the Notes at January 31, 2015 and July 31, 2014 to be a Level 2 measurement. The fair value of the Notes is primarily affected by the trading price of our common stock and market interest rates. As of January 31, 2015, the if-converted value of the Notes exceeded its principal amount by $74,929,000.

- changed (2015-05-28):
[0001327567-15-000018:note_history:25]
The following table sets forth interest expense recognized related to the Notes for the three and nine months ended April 30, 2015 (dollars in thousands):
  (was, 2015-03-03, similarity 0.9565):
[0001327567-15-000008:note_history:25]
The following table sets forth interest expense recognized related to the Notes for the three and six months ended January 31, 2015 (dollars in thousands):

- changed (2015-05-28):
[0001327567-15-000018:note_history:26]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 30, 2015 |
| Amortization of debt issuance costs | $ | 522 |  |  | $ | 1,524 |  |
| Amortization of debt discount | 5,088 |  |  | 15,085 |  |
| Total interest expense recognized | $ | 5,610 |  |  | $ | 16,609 |  |
| Effective interest rate of the liability component | 4.8 | % |  | 4.8 | % |
  (was, 2015-03-03, similarity 0.9689):
[0001327567-15-000008:note_history:26]
|  | Three Months Ended |  | Six Months Ended |
|  | January 31, 2015 |
| Amortization of debt issuance costs | $ | 505 |  |  | $ | 1,002 |  |
| Amortization of debt discount | 5,016 |  |  | 9,997 |  |
| Total interest expense recognized | $ | 5,521 |  |  | $ | 10,999 |  |
| Effective interest rate of the liability component | 4.8 | % |  | 4.8 | % |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2015-05-28):
[0001327567-15-000018:note_history:27]
The following tables summarize the unrealized gains and losses and fair value of our investments as of April 30, 2015 and July 31, 2014 (in thousands):
  (was, 2015-03-03, similarity 0.9718):
[0001327567-15-000008:note_history:27]
The following tables summarize the unrealized gains and losses and fair value of our investments as of January 31, 2015 and July 31, 2014 (in thousands):

- added (2015-05-28):
[0001327567-15-000018:note_history:28]
|  | April 30, 2015 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Estimated Fair Value |
| Certificates of deposit | $ | 1,000 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,000 |  |
| Corporate debt securities | 161,005 |  |  | 53 |  |  | (48 | ) |  | 161,010 |  |
| U.S. government and agency securities | 615,087 |  |  | 322 |  |  | (104 | ) |  | 615,305 |  |
| Total | $ | 777,092 |  |  | $ | 375 |  |  | $ | (152 | ) |  | $ | 777,315 |  |

- changed (2015-05-28):
[0001327567-15-000018:note_history:29]
The following tables present our investments that were in an unrealized loss position as of April 30, 2015 and July 31, 2014 (in thousands):
  (was, 2015-03-03, similarity 0.9695):
[0001327567-15-000008:note_history:29]
The following tables present our investments that were in an unrealized loss position as of January 31, 2015 and July 31, 2014 (in thousands):

- changed (2015-05-28):
[0001327567-15-000018:note_history:30]
|  | April 30, 2015 |
|  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
|  | Fair Value |  | Unrealized Loss |  | Fair Value |  | Unrealized Loss |  | Fair Value |  | Unrealized Loss |
| Corporate debt securities | $ | 77,534 |  |  | $ | (48 | ) |  | $ | — |  |  | $ | — |  |  | $ | 77,534 |  |  | $ | (48 | ) |
| U.S. government and agency securities | 181,639 |  |  | (104 | ) |  | — |  |  | — |  |  | 181,639 |  |  | (104 | ) |
| Total | $ | 259,173 |  |  | $ | (152 | ) |  | $ | — |  |  | $ | — |  |  | $ | 259,173 |  |  | $ | (152 | ) |
  (was, 2015-03-03, similarity 0.9872):
[0001327567-15-000008:note_history:30]
|  | January 31, 2015 |
|  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
|  | Fair Value |  | Unrealized Loss |  | Fair Value |  | Unrealized Loss |  | Fair Value |  | Unrealized Loss |
| Corporate debt securities | $ | 84,073 |  |  | $ | (62 | ) |  | $ | — |  |  | $ | — |  |  | $ | 84,073 |  |  | $ | (62 | ) |
| U.S. government and agency securities | 206,056 |  |  | (75 | ) |  | — |  |  | — |  |  | 206,056 |  |  | (75 | ) |
| Total | $ | 290,129 |  |  | $ | (137 | ) |  | $ | — |  |  | $ | — |  |  | $ | 290,129 |  |  | $ | (137 | ) |

- changed (2015-05-28):
[0001327567-15-000018:note_history:31]
Unrealized losses related to these investments are due to interest rate fluctuations as opposed to credit quality. In addition, we do not intend to sell and it is not likely that we would be required to sell these investments before recovery of their amortized cost basis, which may be at maturity. As a result, there is no other-than-temporary impairment for these investments at April 30, 2015.
  (was, 2015-03-03, similarity 0.9847):
[0001327567-15-000008:note_history:31]
Unrealized losses related to these investments are due to interest rate fluctuations as opposed to credit quality. In addition, we do not intend to sell and it is not likely that we would be required to sell these investments before recovery of their amortized cost basis, which may be at maturity. As a result, there is no other-than-temporary impairment for these investments at January 31, 2015.

- changed (2015-05-28):
[0001327567-15-000018:note_history:32]
The following table summarizes the amortized cost and fair value of our investments as of April 30, 2015, by contractual years-to-maturity (in thousands):
  (was, 2015-03-03, similarity 0.9732):
[0001327567-15-000008:note_history:32]
The following table summarizes the amortized cost and fair value of our investments as of January 31, 2015, by contractual years-to-maturity (in thousands):

- changed (2015-05-28):
[0001327567-15-000018:note_history:33]
|  | Amortized Cost |  | Fair Value |
| Due within one year | $ | 368,766 |  |  | $ | 368,850 |  |
| Due between one and three years | 408,326 |  |  | 408,465 |  |
| Total | $ | 777,092 |  |  | $ | 777,315 |  |
  (was, 2015-03-03, similarity 0.7676):
[0001327567-15-000008:note_history:33]
|  | Amortized Cost |  | Fair Value |
| Due within one year | $ | 332,047 |  |  | $ | 332,074 |  |
| Due within one to two years | 462,498 |  |  | 462,819 |  |
| Due within two to three years | 1,090 |  |  | 1,089 |  |
| Total | $ | 795,635 |  |  | $ | 795,982 |  |

- removed (2015-05-28):
[0001327567-15-000008:note_history:34]
|  | January 31, 2015 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Estimated Fair Value |
| Certificates of deposit | $ | 1,000 |  |  | $ | 1 |  |  | $ | — |  |  | $ | 1,001 |  |
| Corporate debt securities | 158,933 |  |  | 60 |  |  | (62 | ) |  | 158,931 |  |
| U.S. government and agency securities | 635,702 |  |  | 423 |  |  | (75 | ) |  | 636,050 |  |
| Total | $ | 795,635 |  |  | $ | 484 |  |  | $ | (137 | ) |  | $ | 795,982 |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_prior_note, score: 0.0

- added (2015-05-28):
[0001327567-15-000018:note_history:35]
Subsequent Event

- added (2015-05-28):
[0001327567-15-000018:note_history:36]
In May 2015, we completed our acquisition of CirroSecure, Inc., a privately-held cybersecurity company, in exchange for total consideration of approximately $18,000,000. The acquisition expands the functionality of our enterprise security platform by providing additional security for SaaS applications. We are currently in the process of finalizing the accounting for this transaction and expect to complete our preliminary allocation of the purchase consideration to the assets acquired and liabilities assumed by the end of fiscal 2015.
