# PANW MD&A — 0001327567-15-000018


## mdna

[0001327567-15-000018:mdna:1]
[same as prior period, unchanged from 0001327567-15-000008:mdna:1]

[0001327567-15-000018:mdna:2]
[same as prior period, unchanged from 0001327567-15-000008:mdna:2]

[0001327567-15-000018:mdna:3]
[same as prior period, unchanged from 0001327567-15-000008:mdna:3]

[0001327567-15-000018:mdna:4]
[same as prior period, unchanged from 0001327567-15-000008:mdna:4]

[0001327567-15-000018:mdna:5]
[same as prior period, unchanged from 0001327567-15-000008:mdna:5]

[0001327567-15-000018:mdna:6]
| • | Results of Operations. An analysis of our financial results comparing the three and nine months ended April 30, 2015 to the three and nine months ended April 30, 2014. |

[0001327567-15-000018:mdna:7]
[same as prior period, unchanged from 0001327567-15-000008:mdna:7]

[0001327567-15-000018:mdna:8]
| • | Contractual Obligations and Commitments. An overview of our contractual obligations, contingent liabilities, commitments, and off-balance sheet arrangements outstanding as of April 30, 2015, including expected payment schedule. |

[0001327567-15-000018:mdna:9]
[same as prior period, unchanged from 0001327567-15-000008:mdna:9]

[0001327567-15-000018:mdna:10]
[same as prior period, unchanged from 0001327567-15-000008:mdna:10]

[0001327567-15-000018:mdna:11]
[same as prior period, unchanged from 0001327567-15-000008:mdna:11]

[0001327567-15-000018:mdna:12]
[same as prior period, unchanged from 0001327567-15-000008:mdna:12]

[0001327567-15-000018:mdna:13]
[same as prior period, unchanged from 0001327567-15-000008:mdna:13]

[0001327567-15-000018:mdna:14]
[same as prior period, unchanged from 0001327567-15-000008:mdna:14]

[0001327567-15-000018:mdna:15]
[same as prior period, unchanged from 0001327567-15-000008:mdna:15]

[0001327567-15-000018:mdna:16]
[same as prior period, unchanged from 0001327567-15-000008:mdna:16]

[0001327567-15-000018:mdna:17]
[same as prior period, unchanged from 0001327567-15-000008:mdna:17]

[0001327567-15-000018:mdna:18]
[same as prior period, unchanged from 0001327567-15-000008:mdna:18]

[0001327567-15-000018:mdna:19]
We continue to invest in innovation and strengthening our product portfolio and in September 2014, announced the availability of Traps, our Advanced Endpoint Protection offering designed to prevent sophisticated cyber attacks on endpoints. We anticipate billings (non-GAAP) from Traps will continue to ramp through the end of fiscal 2015 with a more meaningful revenue contribution in fiscal 2016.

[0001327567-15-000018:mdna:20]
As of April 30, 2015, we had sold to more than 24,000 end-customers in over 140 countries. Our end-customers represent a broad range of industries including education, energy, financial services, government entities, healthcare, Internet and media, manufacturing, public sector, and telecommunications, and include some of the largest Fortune 100 and Global 2000 companies in the world. Also, during the nine months ended April 30, 2015, our headcount increased by 595 to 2,317 employees.

[0001327567-15-000018:mdna:21]
For the third quarter of fiscal 2015 and 2014, revenues were $234.2 million and $150.7 million, respectively, representing year over year growth of 55.4%. All three components of our hybrid SaaS revenue model experienced year over year growth, led by revenue from subscription services, which grew 71.3% to $54.8 million, followed by support and maintenance services, which grew 67.3% to $57.8 million, and product, which grew 44.5% to $121.5 million. Revenue growth reflected rapid adoption of our Next-Generation Firewall and related support and maintenance, as well as increasing momentum in our subscription services business. We believe the growth was also driven by increased security spending by customers, as security continues to be a critical business imperative for every business in the world.

[0001327567-15-000018:mdna:22]
[same as prior period, unchanged from 0001327567-15-000008:mdna:22]

[0001327567-15-000018:mdna:23]
[same as prior period, unchanged from 0001327567-15-000008:mdna:23]

[0001327567-15-000018:mdna:24]
[same as prior period, unchanged from 0001327567-15-000008:mdna:24]

[0001327567-15-000018:mdna:25]
[same as prior period, unchanged from 0001327567-15-000008:mdna:25]

[0001327567-15-000018:mdna:26]
[same as prior period, unchanged from 0001327567-15-000008:mdna:26]

[0001327567-15-000018:mdna:27]
|  | April 30, 2015 |  | July 31, 2014 |
|  | (in thousands) |
| Total deferred revenue | $ | 603,890 |  |  | $ | 422,578 |  |
| Cash, cash equivalents, and investments | $ | 1,231,438 |  |  | $ | 974,382 |  |

[0001327567-15-000018:mdna:28]
|  | Three Months Ended April 30, |  | Nine Months Ended April 30, |
|  | 2015 |  | 2014 |  | 2015 |  | 2014 |
|  | (dollars in thousands) |
| Total revenue | $ | 234,172 |  |  | $ | 150,700 |  |  | $ | 644,173 |  |  | $ | 419,948 |  |
| Year over year percentage increase | 55.4 | % |  | 48.8 | % |  | 53.4 | % |  | 48.0 | % |
| Gross margin percentage | 72.5 | % |  | 73.6 | % |  | 72.5 | % |  | 73.6 | % |
| Operating loss | $ | (36,724 | ) |  | $ | (145,732 | ) |  | $ | (99,003 | ) |  | $ | (189,899 | ) |
| Operating margin percentage | (15.7 | )% |  | (96.7 | )% |  | (15.4 | )% |  | (45.2 | )% |
| Billings (non-GAAP) | $ | 302,219 |  |  | $ | 193,890 |  |  | $ | 825,485 |  |  | $ | 538,499 |  |
| Cash flow provided by operating activities |  |  |  |  | $ | 238,979 |  |  | $ | 114,556 |  |
| Free cash flow (non-GAAP) |  |  |  |  | $ | 217,117 |  |  | $ | 83,177 |  |

[0001327567-15-000018:mdna:29]
[same as prior period, unchanged from 0001327567-15-000008:mdna:29]

[0001327567-15-000018:mdna:30]
[same as prior period, unchanged from 0001327567-15-000008:mdna:30]

[0001327567-15-000018:mdna:31]
[same as prior period, unchanged from 0001327567-15-000008:mdna:31]

[0001327567-15-000018:mdna:32]
[same as prior period, unchanged from 0001327567-15-000008:mdna:32]

[0001327567-15-000018:mdna:33]
|  | Nine Months Ended April 30, |
|  | 2015 |  | 2014 |
|  | (in thousands) |
| Free cash flow (non-GAAP): |  |  |  |
| Cash flow provided by operating activities | $ | 238,979 |  |  | $ | 114,556 |  |
| Less: purchases of property, equipment, and other assets | 21,862 |  |  | 31,379 |  |
| Free cash flow (non-GAAP) | $ | 217,117 |  |  | $ | 83,177 |  |
| Net cash used in investing activities | $ | (480,535 | ) |  | $ | (229,306 | ) |
| Net cash provided by financing activities | $ | 41,867 |  |  | $ | 38,926 |  |

[0001327567-15-000018:mdna:34]
| • | Billings (non-GAAP). We define billings, a non-GAAP financial measure, as total revenue plus the change in deferred revenue, net of acquired deferred revenue, during the period. Billings is a key measure used by our management to manage our business because billings drive deferred revenue, which is an important indicator of the health and visibility of our business. We consider billings to be a useful metric for management and investors, particularly as we experience increased sales of subscriptions and strong renewal rates for subscriptions and support and maintenance services, and monitor our near term cash flows. We believe that billings provides useful information to investors and others in understanding and evaluating our operating results in the same manner as our management. However, it is important to note that other companies, including companies in our industry, may not use billings, may calculate billings differently, may have different billing frequencies, or may use other financial measures to evaluate their performance, all of which could reduce the usefulness of billings as a comparative measure. A reconciliation of billings to revenue, the most directly comparable financial measure calculated and presented in accordance with GAAP, is provided below: |

[0001327567-15-000018:mdna:35]
|  | Three Months Ended April 30, |  | Nine Months Ended April 30, |
|  | 2015 |  | 2014 |  | 2015 |  | 2014 |
|  | (in thousands) |
| Billings (non-GAAP): |  |  |  |  |  |  |  |
| Total revenue | $ | 234,172 |  |  | $ | 150,700 |  |  | $ | 644,173 |  |  | $ | 419,948 |  |
| Add: change in total deferred revenue, net of acquired deferred revenue | 68,047 |  |  | 43,190 |  |  | 181,312 |  |  | 118,551 |  |
| Billings (non-GAAP) | $ | 302,219 |  |  | $ | 193,890 |  |  | $ | 825,485 |  |  | $ | 538,499 |  |

[0001327567-15-000018:mdna:36]
[same as prior period, unchanged from 0001327567-15-000008:mdna:36]

[0001327567-15-000018:mdna:37]
[same as prior period, unchanged from 0001327567-15-000008:mdna:37]

[0001327567-15-000018:mdna:38]
[same as prior period, unchanged from 0001327567-15-000008:mdna:38]

[0001327567-15-000018:mdna:39]
[same as prior period, unchanged from 0001327567-15-000008:mdna:39]

[0001327567-15-000018:mdna:40]
[same as prior period, unchanged from 0001327567-15-000008:mdna:40]

[0001327567-15-000018:mdna:41]
| • | Services Revenue. Services revenue is derived primarily from Threat Prevention, URL Filtering, WildFire, and GlobalProtect subscriptions and support and maintenance. In addition, in September 2014, we released Traps, our Advanced Endpoint Protection subscription. Our contractual subscription and support and maintenance terms are typically one year, with three to five year terms available. We recognize revenue from subscriptions and support and maintenance over the contractual service period. As a percentage of total revenue, we expect our services revenue to vary from quarter to quarter and increase over the long term as we introduce new subscriptions, renew existing services contracts, and expand our installed end-customer base. |

[0001327567-15-000018:mdna:42]
[same as prior period, unchanged from 0001327567-15-000008:mdna:42]

[0001327567-15-000018:mdna:43]
[same as prior period, unchanged from 0001327567-15-000008:mdna:43]

[0001327567-15-000018:mdna:44]
Our cost of revenue consists of cost of product revenue and cost of services revenue. Our cost of revenue includes costs paid to our third-party contract manufacturer and personnel costs, which consist of salaries, bonuses, and share-based compensation associated with our operations and global customer support organizations. Our cost of revenue also includes allocated costs, which consist of certain facilities, depreciation, benefits, recruiting, and information technology costs that we allocate based on headcount, as well as amortization of intellectual property licenses and intangible assets.

[0001327567-15-000018:mdna:45]
[same as prior period, unchanged from 0001327567-15-000008:mdna:45]

[0001327567-15-000018:mdna:46]
[same as prior period, unchanged from 0001327567-15-000008:mdna:46]

[0001327567-15-000018:mdna:47]
[same as prior period, unchanged from 0001327567-15-000008:mdna:47]

[0001327567-15-000018:mdna:48]
[same as prior period, unchanged from 0001327567-15-000008:mdna:48]

[0001327567-15-000018:mdna:49]
[same as prior period, unchanged from 0001327567-15-000008:mdna:49]

[0001327567-15-000018:mdna:50]
Our operating expenses consist of research and development, sales and marketing, general and administrative, and legal settlement expense. Personnel costs are the most significant component of operating expenses and consist of salaries, benefits, bonuses, share-based compensation, and with regard to sales and marketing expense, sales commissions. We expect operating expenses to increase in absolute dollars, and decrease over the long term as a percentage of revenue as we continue to scale our business. As of April 30, 2015, we expect to recognize approximately $510.4 million of share-based compensation expense over a weighted-average period of approximately three years, excluding additional share-based compensation expense related to any future grants of share-based awards. Share-based compensation expense, net of forfeitures, is recognized on a straight-line basis over the requisite service periods of the awards.

[0001327567-15-000018:mdna:51]
[same as prior period, unchanged from 0001327567-15-000008:mdna:51]

[0001327567-15-000018:mdna:52]
[same as prior period, unchanged from 0001327567-15-000008:mdna:52]

[0001327567-15-000018:mdna:53]
[same as prior period, unchanged from 0001327567-15-000008:mdna:53]

[0001327567-15-000018:mdna:54]
| • | Legal Settlement. Legal settlement expense consists of charges related to the Settlement, Release and Cross-License Agreement (the “Settlement Agreement”) with Juniper Networks, Inc. (“Juniper”) and the Mutual Covenant Not to Sue and Release Agreement with Fortinet, Inc. (“Fortinet”). Refer to the discussion under Note 8. Legal Settlement of Notes to Condensed Consolidated Financial Statements in Part I, Item 1 of this Quarterly Report on Form 10-Q for information related to these matters. |

[0001327567-15-000018:mdna:55]
[same as prior period, unchanged from 0001327567-15-000008:mdna:55]

[0001327567-15-000018:mdna:56]
[same as prior period, unchanged from 0001327567-15-000008:mdna:56]

[0001327567-15-000018:mdna:57]
Interest expense consists of the amortization of the debt discount and debt issuance costs related to our 0.0% Convertible Senior Notes due 2019 (the “Notes”). This interest expense is non-cash and will range from $22.3 million to $25.7 million per year through fiscal 2019.

[0001327567-15-000018:mdna:58]
[same as prior period, unchanged from 0001327567-15-000008:mdna:58]

[0001327567-15-000018:mdna:59]
[same as prior period, unchanged from 0001327567-15-000008:mdna:59]

[0001327567-15-000018:mdna:60]
Provision for Income Taxes

[0001327567-15-000018:mdna:61]
Provision for income taxes consists primarily of income taxes in foreign jurisdictions in which we conduct business, withholding taxes, federal and state income taxes in the United States, and amortization of our deferred tax charge. We maintain a full valuation allowance for domestic deferred tax assets, including net operating loss carryforwards and tax credits.

[0001327567-15-000018:mdna:62]
During the second quarter of fiscal 2015, we recorded a deferred tax charge of $36.7 million. The current portion of the deferred tax charge is included in prepaid expenses and other current assets and the remainder in other assets in our condensed consolidated balance sheets. The deferred tax charge is being amortized on a straight-line basis over approximately six years as a component of provision for income taxes.

[0001327567-15-000018:mdna:63]
[same as prior period, unchanged from 0001327567-15-000008:mdna:63]

[0001327567-15-000018:mdna:64]
[same as prior period, unchanged from 0001327567-15-000008:mdna:64]

[0001327567-15-000018:mdna:65]
|  | Three Months Ended April 30, |  | Nine Months Ended April 30, |
|  | 2015 |  | 2014 |  | 2015 |  | 2014 |
|  | (dollars in thousands) |
| Condensed Consolidated Statements of Operations Data: |  |  |  |  |  |  |  |
| Revenue: |  |  |  |  |  |  |  |
| Product | $ | 121,524 |  |  | $ | 84,128 |  |  | $ | 338,621 |  |  | $ | 240,436 |  |
| Services | 112,648 |  |  | 66,572 |  |  | 305,552 |  |  | 179,512 |  |
| Total revenue | 234,172 |  |  | 150,700 |  |  | 644,173 |  |  | 419,948 |  |
| Cost of revenue: |  |  |  |  |  |  |  |
| Product | 32,851 |  |  | 20,425 |  |  | 92,632 |  |  | 58,600 |  |
| Services | 31,544 |  |  | 19,285 |  |  | 84,549 |  |  | 52,421 |  |
| Total cost of revenue | 64,395 |  |  | 39,710 |  |  | 177,181 |  |  | 111,021 |  |
| Total gross profit | 169,777 |  |  | 110,990 |  |  | 466,992 |  |  | 308,927 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 48,486 |  |  | 27,837 |  |  | 132,739 |  |  | 71,983 |  |
| Sales and marketing | 131,026 |  |  | 83,995 |  |  | 360,267 |  |  | 228,095 |  |
| General and administrative | 26,989 |  |  | 23,717 |  |  | 72,989 |  |  | 57,575 |  |
| Legal settlement | — |  |  | 121,173 |  |  | — |  |  | 141,173 |  |
| Total operating expenses | 206,501 |  |  | 256,722 |  |  | 565,995 |  |  | 498,826 |  |
| Operating loss | (36,724 | ) |  | (145,732 | ) |  | (99,003 | ) |  | (189,899 | ) |
| Interest expense | (5,631 | ) |  | (13 | ) |  | (16,659 | ) |  | (35 | ) |
| Other income (expense), net | (55 | ) |  | 430 |  |  | 630 |  |  | 665 |  |
| Loss before income taxes | (42,410 | ) |  | (145,315 | ) |  | (115,032 | ) |  | (189,269 | ) |
| Provision for income taxes | 3,525 |  |  | 1,272 |  |  | 3,979 |  |  | 5,125 |  |
| Net loss | $ | (45,935 | ) |  | $ | (146,587 | ) |  | $ | (119,011 | ) |  | $ | (194,394 | ) |
| Number of employees at period end |  |  |  |  | 2,317 |  |  | 1,556 |  |

[0001327567-15-000018:mdna:66]
[same as prior period, unchanged from 0001327567-15-000008:mdna:66]

[0001327567-15-000018:mdna:67]
|  | Three Months Ended April 30, |  | Nine Months Ended April 30, |
|  | 2015 |  | 2014 |  | 2015 |  | 2014 |
|  | (as a percentage of revenue) |
| Condensed Consolidated Statements of Operations Data: |  |  |  |  |  |  |  |
| Revenue: |  |  |  |  |  |  |  |
| Product | 51.9 | % |  | 55.8 | % |  | 52.6 | % |  | 57.3 | % |
| Services | 48.1 | % |  | 44.2 | % |  | 47.4 | % |  | 42.7 | % |
| Total revenue | 100.0 | % |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |
| Cost of revenue: |  |  |  |  |  |  |  |
| Product | 14.0 | % |  | 13.6 | % |  | 14.4 | % |  | 14.0 | % |
| Services | 13.5 | % |  | 12.8 | % |  | 13.1 | % |  | 12.4 | % |
| Total cost of revenue | 27.5 | % |  | 26.4 | % |  | 27.5 | % |  | 26.4 | % |
| Total gross profit | 72.5 | % |  | 73.6 | % |  | 72.5 | % |  | 73.6 | % |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 20.7 | % |  | 18.5 | % |  | 20.6 | % |  | 17.1 | % |
| Sales and marketing | 56.0 | % |  | 55.7 | % |  | 55.9 | % |  | 54.3 | % |
| General and administrative | 11.5 | % |  | 15.7 | % |  | 11.4 | % |  | 13.8 | % |
| Legal settlement | — | % |  | 80.4 | % |  | — | % |  | 33.6 | % |
| Total operating expenses | 88.2 | % |  | 170.3 | % |  | 87.9 | % |  | 118.8 | % |
| Operating loss | (15.7 | )% |  | (96.7 | )% |  | (15.4 | )% |  | (45.2 | )% |
| Interest expense | (2.4 | )% |  | — | % |  | (2.6 | )% |  | — | % |
| Other income (expense), net | — | % |  | 0.3 | % |  | 0.1 | % |  | 0.1 | % |
| Loss before income taxes | (18.1 | )% |  | (96.4 | )% |  | (17.9 | )% |  | (45.1 | )% |
| Provision for income taxes | 1.5 | % |  | 0.9 | % |  | 0.6 | % |  | 1.2 | % |
| Net loss | (19.6 | )% |  | (97.3 | )% |  | (18.5 | )% |  | (46.3 | )% |

[0001327567-15-000018:mdna:68]
[same as prior period, unchanged from 0001327567-15-000008:mdna:68]

[0001327567-15-000018:mdna:69]
Comparison of the Three and Nine Month Periods Ended April 30, 2015 and 2014

[0001327567-15-000018:mdna:70]
[same as prior period, unchanged from 0001327567-15-000008:mdna:70]

[0001327567-15-000018:mdna:71]
|  | Three Months Ended April 30, |  |  |  |  |  | Nine Months Ended April 30, |  |  |  |  |
|  | 2015 |  | 2014 |  | Change |  | 2015 |  | 2014 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in thousands) |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 121,524 |  |  | $ | 84,128 |  |  | $ | 37,396 |  |  | 44.5 | % |  | $ | 338,621 |  |  | $ | 240,436 |  |  | $ | 98,185 |  |  | 40.8 | % |
| Services |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Subscription | 54,832 |  |  | 32,005 |  |  | 22,827 |  |  | 71.3 | % |  | 148,606 |  |  | 85,619 |  |  | 62,987 |  |  | 73.6 | % |
| Support and maintenance | 57,816 |  |  | 34,567 |  |  | 23,249 |  |  | 67.3 | % |  | 156,946 |  |  | 93,893 |  |  | 63,053 |  |  | 67.2 | % |
| Total services | 112,648 |  |  | 66,572 |  |  | 46,076 |  |  | 69.2 | % |  | 305,552 |  |  | 179,512 |  |  | 126,040 |  |  | 70.2 | % |
| Total revenue | $ | 234,172 |  |  | $ | 150,700 |  |  | $ | 83,472 |  |  | 55.4 | % |  | $ | 644,173 |  |  | $ | 419,948 |  |  | $ | 224,225 |  |  | 53.4 | % |
| Revenue by geographic theater: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 157,725 |  |  | $ | 98,689 |  |  | $ | 59,036 |  |  | 59.8 | % |  | $ | 436,660 |  |  | $ | 275,724 |  |  | $ | 160,936 |  |  | 58.4 | % |
| EMEA | 45,852 |  |  | 32,326 |  |  | 13,526 |  |  | 41.8 | % |  | 129,156 |  |  | 89,299 |  |  | 39,857 |  |  | 44.6 | % |
| APAC | 30,595 |  |  | 19,685 |  |  | 10,910 |  |  | 55.4 | % |  | 78,357 |  |  | 54,925 |  |  | 23,432 |  |  | 42.7 | % |
| Total revenue | $ | 234,172 |  |  | $ | 150,700 |  |  | $ | 83,472 |  |  | 55.4 | % |  | $ | 644,173 |  |  | $ | 419,948 |  |  | $ | 224,225 |  |  | 53.4 | % |

[0001327567-15-000018:mdna:72]
Product revenue increased $37.4 million, or 44.5%, for the three months ended April 30, 2015 compared to the three months ended April 30, 2014. Product revenue increased $98.2 million, or 40.8%, for the nine months ended April 30, 2015 compared to the nine months ended April 30, 2014. The increases in both periods were driven by increased demand, including broader adoption of our PA-7050 firewall. The impact of changes in pricing on our product revenue was insignificant.

[0001327567-15-000018:mdna:73]
Services revenue increased $46.1 million, or 69.2%, for the three months ended April 30, 2015 compared to the three months ended April 30, 2014. Services revenue increased $126.0 million, or 70.2%, for the nine months ended April 30, 2015 compared to the nine months ended April 30, 2014. The increases in both periods were due to increased sales to new and existing end-customers. The relative increases in subscription revenue and support and maintenance revenue will fluctuate over time, depending on the mix of services revenue and the introduction of new subscription offerings. The impact of changes in pricing on our services revenue was insignificant.

[0001327567-15-000018:mdna:74]
With respect to geographic theaters, the Americas contributed the largest portion of the increase in revenue for the three and nine months ended April 30, 2015 compared to the three and nine months ended April 30, 2014 due to its larger and more established sales force compared to our other theaters. Revenue from both EMEA and APAC increased for the three and nine months ended April 30, 2015 compared to the three and nine months ended April 30, 2014 due to our investment in increasing the size of our sales force and number of channel partners in these theaters.

[0001327567-15-000018:mdna:75]
[same as prior period, unchanged from 0001327567-15-000008:mdna:75]

[0001327567-15-000018:mdna:76]
[same as prior period, unchanged from 0001327567-15-000008:mdna:76]

[0001327567-15-000018:mdna:77]
|  | Three Months Ended April 30, |  | Nine Months Ended April 30, |
|  | 2015 |  | 2014 |  | 2015 |  | 2014 |
|  | Amount |  | Gross Margin |  | Amount |  | Gross Margin |  | Amount |  | Gross Margin |  | Amount |  | Gross Margin |
|  | (dollars in thousands) |
| Cost of revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 32,851 |  |  |  |  | $ | 20,425 |  |  |  |  | $ | 92,632 |  |  |  |  | $ | 58,600 |  |  |  |
| Services | 31,544 |  |  |  |  | 19,285 |  |  |  |  | 84,549 |  |  |  |  | 52,421 |  |  |  |
| Total cost of revenue | $ | 64,395 |  |  |  |  | $ | 39,710 |  |  |  |  | $ | 177,181 |  |  |  |  | $ | 111,021 |  |  |  |
| Includes share-based compensation of: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 1,031 |  |  |  |  | $ | 417 |  |  |  |  | $ | 2,735 |  |  |  |  | $ | 1,001 |  |  |  |
| Services | 5,587 |  |  |  |  | 2,739 |  |  |  |  | 14,222 |  |  |  |  | 6,310 |  |  |  |
| Total share-based compensation included in cost of revenue | $ | 6,618 |  |  |  |  | $ | 3,156 |  |  |  |  | $ | 16,957 |  |  |  |  | $ | 7,311 |  |  |  |
| Gross profit: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 88,673 |  |  | 73.0 | % |  | $ | 63,703 |  |  | 75.7 | % |  | $ | 245,989 |  |  | 72.6 | % |  | $ | 181,836 |  |  | 75.6 | % |
| Services | 81,104 |  |  | 72.0 | % |  | 47,287 |  |  | 71.0 | % |  | 221,003 |  |  | 72.3 | % |  | 127,091 |  |  | 70.8 | % |
| Total gross profit | $ | 169,777 |  |  | 72.5 | % |  | $ | 110,990 |  |  | 73.6 | % |  | $ | 466,992 |  |  | 72.5 | % |  | $ | 308,927 |  |  | 73.6 | % |

[0001327567-15-000018:mdna:78]
Product cost increased $12.4 million, or 60.8%, for the three months ended April 30, 2015 compared to the three months ended April 30, 2014 due to an increase in product unit volume, as well as amortization of intellectual property licenses of $3.1 million.

[0001327567-15-000018:mdna:79]
Product cost increased $34.0 million, or 58.1%, for the nine months ended April 30, 2015 compared to the nine months ended April 30, 2014 due to an increase in product unit volume, as well as amortization of intellectual property licenses of $9.2 million.

[0001327567-15-000018:mdna:80]
Services cost increased $12.3 million, or 63.6%, for the three months ended April 30, 2015 compared to the three months ended April 30, 2014 due to increases in personnel costs of $6.3 million related to increasing our headcount, third party professional services costs of $1.7 million to expand our customer service capabilities to support our growing installed end-customer base, allocated costs of $1.6 million, and amortization of acquired intangible assets of $1.1 million.

[0001327567-15-000018:mdna:81]
Services cost increased $32.1 million, or 61.3%, for the nine months ended April 30, 2015 compared to the nine months ended April 30, 2014 due to increases in personnel costs of $17.2 million related to increasing our headcount, amortization of acquired intangible assets of $3.9 million, allocated costs of $3.7 million, and third party professional services costs of $3.1 million to expand our customer service capabilities to support our growing installed end-customer base.

[0001327567-15-000018:mdna:82]
Gross margin decreased 110 basis points for the three months ended April 30, 2015 compared to the three months ended April 30, 2014. The decrease of 270 basis points in product margin was due to amortization of intellectual property licenses. The increase of 100 basis points in services margin was due to contributions from our higher margin subscription services, partially offset by a 70 basis points decrease due to amortization of purchased intangible assets.

[0001327567-15-000018:mdna:83]
Gross margin decreased 110 basis points for the nine months ended April 30, 2015 compared to the nine months ended April 30, 2014. The decrease of 300 basis points in product margin was due to amortization of intellectual property licenses. The increase of 150 basis points in services margin was due to contributions from our higher margin subscription services, partially offset by a 120 basis points decrease due to amortization of purchased intangible assets.

[0001327567-15-000018:mdna:84]
[same as prior period, unchanged from 0001327567-15-000008:mdna:84]

[0001327567-15-000018:mdna:85]
[same as prior period, unchanged from 0001327567-15-000008:mdna:85]

[0001327567-15-000018:mdna:86]
|  | Three Months Ended April 30, |  |  |  |  |  | Nine Months Ended April 30, |  |  |  |  |
|  | 2015 |  | 2014 |  | Change |  | 2015 |  | 2014 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in thousands) |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | $ | 48,486 |  |  | $ | 27,837 |  |  | $ | 20,649 |  |  | 74.2 | % |  | $ | 132,739 |  |  | $ | 71,983 |  |  | $ | 60,756 |  |  | 84.4 | % |
| Sales and marketing | 131,026 |  |  | 83,995 |  |  | 47,031 |  |  | 56.0 | % |  | 360,267 |  |  | 228,095 |  |  | 132,172 |  |  | 57.9 | % |
| General and administrative | 26,989 |  |  | 23,717 |  |  | 3,272 |  |  | 13.8 | % |  | 72,989 |  |  | 57,575 |  |  | 15,414 |  |  | 26.8 | % |
| Legal settlement | — |  |  | 121,173 |  |  | (121,173 | ) |  | (100.0 | )% |  | — |  |  | 141,173 |  |  | (141,173 | ) |  | (100.0 | )% |
| Total operating expenses | $ | 206,501 |  |  | $ | 256,722 |  |  | $ | (50,221 | ) |  | (19.6 | )% |  | $ | 565,995 |  |  | $ | 498,826 |  |  | $ | 67,169 |  |  | 13.5 | % |
| Includes share-based compensation of: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | $ | 19,821 |  |  | $ | 8,666 |  |  | $ | 11,155 |  |  | 128.7 | % |  | $ | 52,810 |  |  | $ | 17,825 |  |  | $ | 34,985 |  |  | 196.3 | % |
| Sales and marketing | 22,168 |  |  | 12,372 |  |  | 9,796 |  |  | 79.2 | % |  | 59,694 |  |  | 29,050 |  |  | 30,644 |  |  | 105.5 | % |
| General and administrative | 11,627 |  |  | 3,798 |  |  | 7,829 |  |  | 206.1 | % |  | 26,129 |  |  | 12,601 |  |  | 13,528 |  |  | 107.4 | % |
| Total share-based compensation included in operating expenses | $ | 53,616 |  |  | $ | 24,836 |  |  | $ | 28,780 |  |  | 115.9 | % |  | $ | 138,633 |  |  | $ | 59,476 |  |  | $ | 79,157 |  |  | 133.1 | % |

[0001327567-15-000018:mdna:87]
Research and development expense increased $20.6 million, or 74.2%, for the three months ended April 30, 2015 compared to the three months ended April 30, 2014, due to an increase in personnel costs of $17.7 million, largely due to an increase in headcount, and an increase in allocated costs of $2.1 million.

[0001327567-15-000018:mdna:88]
Research and development expense increased $60.8 million, or 84.4%, for the nine months ended April 30, 2015 compared to the nine months ended April 30, 2014, due to an increase in personnel costs of $53.7 million, largely due to an increase in headcount, and an increase in allocated costs of $4.7 million.

[0001327567-15-000018:mdna:89]
Sales and marketing expense increased $47.0 million, or 56.0%, for the three months ended April 30, 2015 compared to the three months ended April 30, 2014, due to an increase in personnel costs of $34.9 million, largely due to an increase in headcount, an increase in allocated costs of $4.6 million, an increase in demand generation activities, trade shows, and other marketing activities of $2.7 million, and an increase in travel and entertainment costs of $2.2 million.

[0001327567-15-000018:mdna:90]
Sales and marketing expense increased $132.2 million, or 57.9%, for the nine months ended April 30, 2015 compared to the nine months ended April 30, 2014, due to an increase in personnel costs of $93.9 million, largely due to an increase in headcount, an increase in allocated costs of $10.9 million, an increase in demand generation activities, trade shows, and other marketing activities of $10.6 million, and an increase in travel and entertainment costs of $7.4 million.

[0001327567-15-000018:mdna:91]
General and administrative expense increased $3.3 million, or 13.8%, for the three months ended April 30, 2015 compared to the three months ended April 30, 2014, due to an increase in personnel costs of $9.8 million, largely due to an increase in headcount. The increase was partially offset by a decrease in professional services costs due to the recognition of expenses related to the intellectual property litigation with Juniper of $4.7 million and expenses related to our acquisition of Cyvera Ltd. (“Cyvera”) of $3.6 million in the three months ended April 30, 2014.

[0001327567-15-000018:mdna:92]
General and administrative expense increased $15.4 million, or 26.8%, for the nine months ended April 30, 2015 compared to the nine months ended April 30, 2014, due to an increase in personnel costs of $20.0 million, largely due to an increase in headcount. The increase was partially offset by a decrease in professional services costs due to the recognition of expenses related to the intellectual property litigation with Juniper of $9.3 million and expenses related to our acquisitions of Cyvera and Morta Security, Inc. (“Morta”) of $4.0 million in the nine months ended April 30, 2014.

[0001327567-15-000018:mdna:93]
Legal settlement expense decreased $121.2 million for the three months ended April 30, 2015 compared to the three months ended April 30, 2014 due to the recognition of an expense of $121.2 million for the Settlement Agreement with Juniper in the three months ended April 30, 2014.

[0001327567-15-000018:mdna:94]
[same as prior period, unchanged from 0001327567-15-000008:mdna:94]

[0001327567-15-000018:mdna:95]
Legal settlement expense decreased $141.2 million for the nine months ended April 30, 2015 compared to the nine months ended April 30, 2014 due to the recognition of an expense of $121.2 million for the Settlement Agreement with Juniper and $20.0 million for the Mutual Covenant Not to Sue and Release Agreement with Fortinet in the nine months ended April 30, 2014.

[0001327567-15-000018:mdna:96]
[same as prior period, unchanged from 0001327567-15-000008:mdna:95]

[0001327567-15-000018:mdna:97]
|  | Three Months Ended April 30, |  |  |  |  |  | Nine Months Ended April 30, |  |  |  |  |
|  | 2015 |  | 2014 |  | Change |  | 2015 |  | 2014 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in thousands) |
| Interest expense | $ | 5,631 |  |  | $ | 13 |  |  | $ | 5,618 |  |  | NM |  | $ | 16,659 |  |  | $ | 35 |  |  | $ | 16,624 |  |  | NM |

[0001327567-15-000018:mdna:98]
Interest expense increased $5.6 million and $16.6 million for the three and nine months ended April 30, 2015 compared to the three and nine months ended April 30, 2014, respectively, due to the amortization of the debt discount and debt issuance costs related to the Notes. This interest expense is non-cash and will range from $22.3 million to $25.7 million per year through fiscal 2019.

[0001327567-15-000018:mdna:99]
Provision for Income Taxes

[0001327567-15-000018:mdna:100]
|  | Three Months Ended April 30, |  | Nine Months Ended April 30, |
|  | 2015 |  | 2014 |  | 2015 |  | 2014 |
|  | (dollars in thousands) |
| Provision for income taxes | $ | 3,525 |  |  | $ | 1,272 |  |  | $ | 3,979 |  |  | $ | 5,125 |  |
| Effective tax rate | (8.3 | )% |  | (0.9 | )% |  | (3.5 | )% |  | (2.7 | )% |

[0001327567-15-000018:mdna:101]
We recorded an income tax provision for the three and nine months ended April 30, 2015 due to federal, state, and foreign income taxes, foreign withholding taxes, and amortization of our deferred tax charge. The provision for income taxes changed for the three and nine months ended April 30, 2015 compared to the three and nine months ended April 30, 2014 due to a shift in geographical mix of income and amortization of our deferred tax charge.

[0001327567-15-000018:mdna:102]
[same as prior period, unchanged from 0001327567-15-000008:mdna:101]

[0001327567-15-000018:mdna:103]
|  | April 30, 2015 |  | July 31, 2014 |
|  | (in thousands) |
| Working capital | $ | 96,502 |  |  | $ | 610,155 |  |
| Cash, cash equivalents, and investments: |  |  |  |
| Cash and cash equivalents | $ | 454,123 |  |  | $ | 653,812 |  |
| Investments | 777,315 |  |  | 320,570 |  |
| Total cash, cash equivalents, and investments | $ | 1,231,438 |  |  | $ | 974,382 |  |

[0001327567-15-000018:mdna:104]
At April 30, 2015, our cash, cash equivalents, and investments of $1.2 billion were held for general corporate purposes, of which approximately $208.0 million was held outside the United States. Our current plans do not include repatriating these funds. However, if these funds were needed for our domestic operations, we would be required to accrue and pay U.S. taxes on undistributed earnings of foreign subsidiaries. There are no other restrictions on the use of these funds. We do not provide for federal income taxes on the undistributed earnings of our foreign subsidiaries, all of which we expect to reinvest outside of the United States indefinitely. If we were to repatriate these earnings to the United States, any associated income tax liability would be insignificant.

[0001327567-15-000018:mdna:105]
In June 2014, we issued the Notes with an aggregate principal amount of $575.0 million. The Notes will mature on July 1, 2019. Prior to January 1, 2019, holders may surrender their Notes for early conversion under certain circumstances. Upon conversion of the Notes, we will pay cash up to the aggregate principal amount of the Notes to be converted and we may choose to pay or deliver, as the case may be, cash, shares of our common stock or a combination of cash and shares of our common stock with respect to the remainder of our conversion obligation in excess of the aggregate principal amount of the Notes being converted.

[0001327567-15-000018:mdna:106]
[same as prior period, unchanged from 0001327567-15-000008:mdna:106]

[0001327567-15-000018:mdna:107]
During the fiscal quarter ended April 30, 2015, the last reported sale price of our common stock was greater than or equal to 130% of the conversion price of the Notes for at least 20 of the last 30 consecutive trading days of such quarter. As a result, holders may convert their Notes at any time during the fiscal quarter ending July 31, 2015. Accordingly, as of April 30, 2015, we reclassified the net carrying amount of the Notes and related debt issuance costs to current liabilities and current assets, respectively, in our condensed consolidated balance sheets. Refer to Note 6. Convertible Senior Notes of Notes to Condensed Consolidated Financial Statements included in Part I, Item 1 of this Quarterly Report on Form 10-Q for information on the Notes.

[0001327567-15-000018:mdna:108]
The following table summarizes our cash flows for the nine months ended April 30, 2015 and 2014.

[0001327567-15-000018:mdna:109]
|  | Nine Months Ended April 30, |
| 2015 |  | 2014 |
|  | (in thousands) |
| Cash provided by operating activities | $ | 238,979 |  |  | $ | 114,556 |  |
| Cash used in investing activities | (480,535 | ) |  | (229,306 | ) |
| Cash provided by financing activities | 41,867 |  |  | 38,926 |  |
| Net decrease in cash and cash equivalents | $ | (199,689 | ) |  | $ | (75,824 | ) |

[0001327567-15-000018:mdna:110]
[same as prior period, unchanged from 0001327567-15-000008:mdna:108]

[0001327567-15-000018:mdna:111]
[same as prior period, unchanged from 0001327567-15-000008:mdna:109]

[0001327567-15-000018:mdna:112]
[same as prior period, unchanged from 0001327567-15-000008:mdna:110]

[0001327567-15-000018:mdna:113]
[same as prior period, unchanged from 0001327567-15-000008:mdna:111]

[0001327567-15-000018:mdna:114]
Cash provided by operating activities during the nine months ended April 30, 2015 was $239.0 million, an increase of $124.4 million compared to the nine months ended April 30, 2014. The increase was due to growth of our business and changes in our assets and liabilities during the nine months ended April 30, 2015. In addition, during the second quarter of fiscal 2014, we made a payment of $20.0 million for the Mutual Covenant Not to Sue and Release Agreement with Fortinet.

[0001327567-15-000018:mdna:115]
Changes in assets and liabilities during the nine months ended April 30, 2015 compared to the nine months ended April 30, 2014 include an increase in sales of subscriptions and support and maintenance contracts to new and existing customers as reflected by an increase in deferred revenue. In addition, during the second quarter of fiscal 2015, we made a tax payment of $12.8 million in connection with an intercompany transfer of intellectual property.

[0001327567-15-000018:mdna:116]
[same as prior period, unchanged from 0001327567-15-000008:mdna:114]

[0001327567-15-000018:mdna:117]
[same as prior period, unchanged from 0001327567-15-000008:mdna:115]

[0001327567-15-000018:mdna:118]
Cash used in investing activities during the nine months ended April 30, 2015 was $480.5 million, an increase of $251.2 million as compared to the nine months ended April 30, 2014. The increase was due to higher net purchases of available-for-sale investments during the nine months ended April 30, 2015, partially offset by payments related to our acquisitions during the nine months ended April 30, 2014.

[0001327567-15-000018:mdna:119]
[same as prior period, unchanged from 0001327567-15-000008:mdna:117]

[0001327567-15-000018:mdna:120]
[same as prior period, unchanged from 0001327567-15-000008:mdna:118]

[0001327567-15-000018:mdna:121]
Cash provided by financing activities during the nine months ended April 30, 2015 was $41.9 million, an increase of $2.9 million as compared to the nine months ended April 30, 2014. The increase was due to higher proceeds from the sale of shares through employee equity incentive plans during the nine months ended April 30, 2015.

[0001327567-15-000018:mdna:122]
[same as prior period, unchanged from 0001327567-15-000008:mdna:120]

[0001327567-15-000018:mdna:123]
[same as prior period, unchanged from 0001327567-15-000008:mdna:121]

[0001327567-15-000018:mdna:124]
The following summarizes our contractual obligations and commitments as of April 30, 2015:

[0001327567-15-000018:mdna:125]
|  | Payments Due by Period |
|  | Total |  | Less Than 1 Year |  | 1 - 3 Years |  | 3- 5 Years |  | More Than 5 Years |
|  |  |  | (in thousands) |  |  |
| 0.0% Convertible Senior Notes due 2019 (1) | $ | 575,000 |  |  | $ | — |  |  | $ | — |  |  | $ | 575,000 |  |  | $ | — |  |
| Operating lease obligations (2) (3) | 106,220 |  |  | 17,760 |  |  | 31,520 |  |  | 21,867 |  |  | 35,073 |  |
| Purchase obligations (4) | 41,772 |  |  | 41,772 |  |  | — |  |  | — |  |  | — |  |
| Total (5) | $ | 722,992 |  |  | $ | 59,532 |  |  | $ | 31,520 |  |  | $ | 596,867 |  |  | $ | 35,073 |  |

[0001327567-15-000018:mdna:126]
[same as prior period, unchanged from 0001327567-15-000008:mdna:124]

[0001327567-15-000018:mdna:127]
| (1) | As of April 30, 2015, holders may convert their Notes at any time during the fiscal quarter ending July 31, 2015. Refer to Note 6. Convertible Senior Notes of Notes to Condensed Consolidated Financial Statements included in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information. |

[0001327567-15-000018:mdna:128]
| (2) | Consists of contractual obligations from our non-cancelable operating leases. |

[0001327567-15-000018:mdna:129]
| (3) | Excludes proceeds from contractual sublease of $8.9 million, which consists of $3.0 million to be received in less than one year and $5.9 million to be received in one to three years. |

[0001327567-15-000018:mdna:130]
| (4) | Consists of minimum purchase commitments of products and components with our independent contract manufacturer and original design manufacturers. Obligations under contracts that we can cancel without a significant penalty are not included in the table above. |

[0001327567-15-000018:mdna:131]
| (5) | No amounts related to Financial Accounting Standards Board (FASB) Accounting Standard Codification Topic 740-10, Income Taxes, are included. As of April 30, 2015, we had approximately $37.4 million of tax liabilities recorded related to uncertainty in income tax positions. |

[0001327567-15-000018:mdna:132]
[same as prior period, unchanged from 0001327567-15-000008:mdna:129]

[0001327567-15-000018:mdna:133]
Through April 30, 2015, we did not have any relationships with unconsolidated organizations or financial partnerships, such as structured finance or special purpose entities, that would have been established for the purpose of facilitating off-balance sheet arrangements or other contractually narrow or limited purposes.

[0001327567-15-000018:mdna:134]
[same as prior period, unchanged from 0001327567-15-000008:mdna:131]

[0001327567-15-000018:mdna:135]
[same as prior period, unchanged from 0001327567-15-000008:mdna:132]

[0001327567-15-000018:mdna:136]
[same as prior period, unchanged from 0001327567-15-000008:mdna:133]

[0001327567-15-000018:mdna:137]
[same as prior period, unchanged from 0001327567-15-000008:mdna:134]

[0001327567-15-000018:mdna:138]
[same as prior period, unchanged from 0001327567-15-000008:mdna:135]

[0001327567-15-000018:mdna:139]
[same as prior period, unchanged from 0001327567-15-000008:mdna:138]

[0001327567-15-000018:mdna:140]
[same as prior period, unchanged from 0001327567-15-000008:mdna:136]

[0001327567-15-000018:mdna:141]
Our website is located at www.paloaltonetworks.com, and our investor relations website is located at http://investors.paloaltonetworks.com. Copies of Annual Reports on Form 10-K, Quarterly Reports on Form 10-Q, Current Reports on Form 8-K, and amendments to these reports filed or furnished pursuant to Section 13(a) or 15(d) of the Securities Exchange Act of 1934, as amended (the “Exchange Act”), are available, free of charge, on our investor relations website as soon as reasonably practicable after we file such material electronically with or furnish it to the SEC. The SEC also maintains a website that contains our SEC filings. The address of the site is www.sec.gov. Further, a copy of this Quarterly Report on Form 10-Q is located at the SEC's Public Reference Room at 100 F Street, NE, Washington, D.C. 20549. Information on the operation of the Public Reference Room can be obtained by calling the SEC at 1-800-SEC-0330.

[0001327567-15-000018:mdna:142]
[same as prior period, unchanged from 0001327567-15-000008:mdna:140]
