# PANW notes — 0001327567-15-000018


## panw:ScheduleOfIntangibleAssetsByMajorClassTableTextBlock

[0001327567-15-000018:notes:1]
The following table presents details of our purchased intangible assets as of April 30, 2015 and July 31, 2014 (in thousands):

[0001327567-15-000018:notes:2]
|  |  | April 30, 2015 |  | July 31, 2014 |
|  |  | Gross Carrying Amount |  | Accumulated Amortization |  | Net Carrying Amount |  | Gross Carrying Amount |  | Accumulated Amortization |  | Net Carrying Amount |
| Intangible assets with finite lives: |  |  |  |  |  |  |  |  |  |  |  |  |
| Developed technology |  | $ | 42,100 |  |  | $ | (5,974 | ) |  | $ | 36,126 |  |  | $ | 34,500 |  |  | $ | (1,643 | ) |  | $ | 32,857 |  |
| Acquired intellectual property |  | 8,156 |  |  | (1,645 | ) |  | 6,511 |  |  | 6,546 |  |  | (958 | ) |  | 5,588 |  |
| In-process research and development held for defensive purposes |  | 1,900 |  |  | (844 | ) |  | 1,056 |  |  | 1,900 |  |  | (370 | ) |  | 1,530 |  |
| Other |  | 500 |  |  | (308 | ) |  | 192 |  |  | 500 |  |  | (120 | ) |  | 380 |  |
| Total intangible assets with finite lives |  | 52,656 |  |  | (8,771 | ) |  | 43,885 |  |  | 43,446 |  |  | (3,091 | ) |  | 40,355 |  |
| In-process research and development with indefinite lives |  | — |  |  | — |  |  | — |  |  | 7,600 |  |  | — |  |  | 7,600 |  |
| Total purchased intangible assets |  | $ | 52,656 |  |  | $ | (8,771 | ) |  | $ | 43,885 |  |  | $ | 51,046 |  |  | $ | (3,091 | ) |  | $ | 47,955 |  |


## us-gaap:AvailableForSaleSecuritiesContinuousUnrealizedLossPositionFairValueTableTextBlock

[0001327567-15-000018:notes:3]
The following tables present our investments that were in an unrealized loss position as of April 30, 2015 and July 31, 2014 (in thousands):

[0001327567-15-000018:notes:4]
|  | April 30, 2015 |
|  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
|  | Fair Value |  | Unrealized Loss |  | Fair Value |  | Unrealized Loss |  | Fair Value |  | Unrealized Loss |
| Corporate debt securities | $ | 77,534 |  |  | $ | (48 | ) |  | $ | — |  |  | $ | — |  |  | $ | 77,534 |  |  | $ | (48 | ) |
| U.S. government and agency securities | 181,639 |  |  | (104 | ) |  | — |  |  | — |  |  | 181,639 |  |  | (104 | ) |
| Total | $ | 259,173 |  |  | $ | (152 | ) |  | $ | — |  |  | $ | — |  |  | $ | 259,173 |  |  | $ | (152 | ) |

[0001327567-15-000018:notes:5]
[same as prior period, unchanged from 0001327567-15-000008:notes:5]


## us-gaap:AvailableForSaleSecuritiesTextBlock

[0001327567-15-000018:notes:6]
The following tables summarize the unrealized gains and losses and fair value of our investments as of April 30, 2015 and July 31, 2014 (in thousands):

[0001327567-15-000018:notes:7]
|  | April 30, 2015 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Estimated Fair Value |
| Certificates of deposit | $ | 1,000 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,000 |  |
| Corporate debt securities | 161,005 |  |  | 53 |  |  | (48 | ) |  | 161,010 |  |
| U.S. government and agency securities | 615,087 |  |  | 322 |  |  | (104 | ) |  | 615,305 |  |
| Total | $ | 777,092 |  |  | $ | 375 |  |  | $ | (152 | ) |  | $ | 777,315 |  |

[0001327567-15-000018:notes:8]
[same as prior period, unchanged from 0001327567-15-000008:notes:8]


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001327567-15-000018:notes:9]
[same as prior period, unchanged from 0001327567-15-000008:notes:9]

[0001327567-15-000018:notes:10]
[same as prior period, unchanged from 0001327567-15-000008:notes:10]


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock

[0001327567-15-000018:notes:11]
[same as prior period, unchanged from 0001327567-15-000008:notes:11]

[0001327567-15-000018:notes:12]
[same as prior period, unchanged from 0001327567-15-000008:notes:12]

[0001327567-15-000018:notes:13]
[same as prior period, unchanged from 0001327567-15-000008:notes:13]

[0001327567-15-000018:notes:14]
[same as prior period, unchanged from 0001327567-15-000008:notes:14]

[0001327567-15-000018:notes:15]
[same as prior period, unchanged from 0001327567-15-000008:notes:15]

[0001327567-15-000018:notes:16]
[same as prior period, unchanged from 0001327567-15-000008:notes:16]

[0001327567-15-000018:notes:17]
There have been no material changes to our significant accounting policies as of and for the nine months ended April 30, 2015, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended July 31, 2014.

[0001327567-15-000018:notes:18]
[same as prior period, unchanged from 0001327567-15-000008:notes:18]

[0001327567-15-000018:notes:19]
In April 2015, the Financial Accounting Standards Board (FASB) issued new authoritative guidance on fees paid in a cloud computing arrangement. The standard requires customers in a cloud computing arrangement to evaluate whether the arrangement includes a software license. If the arrangement includes a software license, the customer should account for the software license element of the arrangement consistent with the acquisition of other software licenses. If the arrangement does not include a software license, the customer should account for the arrangement as a service contract. The standard is effective for us for our first quarter of fiscal 2017, although early adoption is permitted, and will be applied on either a prospective or retrospective basis. We are currently evaluating adoption methods and whether this standard will have a material impact on our condensed consolidated financial statements.

[0001327567-15-000018:notes:20]
In April 2015, the FASB issued updated authoritative guidance to simplify the presentation of debt issuance costs. The amended standard requires that debt issuance costs related to a recognized debt liability be presented in the balance sheet as a direct deduction from the carrying amount of the related debt liability, consistent with the presentation of debt discounts, instead of being presented as an asset. The amended standard is effective for us for our first quarter of fiscal 2017, although early adoption is permitted, and will be applied on a retrospective basis. Upon adoption, the amended standard will change the classification of our unamortized debt issuance costs in our condensed consolidated balance sheets.

[0001327567-15-000018:notes:21]
In August 2014, the FASB issued new authoritative guidance about management's responsibility to evaluate whether there is substantial doubt about an entity's ability to continue as a going concern and to provide related footnote disclosures. The standard is effective for us for our fourth quarter of fiscal 2017, although early adoption is permitted. The adoption of this standard is not expected to have a material impact on our condensed consolidated financial statements.

[0001327567-15-000018:notes:22]
In May 2014, the FASB issued new authoritative guidance on revenue from contracts with customers. The new standard provides principles for recognizing revenue for the transfer of promised goods or services to customers with the consideration to which the entity expects to be entitled in exchange for those goods or services. The standard also requires significantly expanded disclosures about revenue recognition. The guidance is effective for us for our first quarter of fiscal 2018 using either of two methods: (i) retrospective to each prior reporting period presented with the option to elect certain practical expedients as defined within the guidance; or (ii) retrospective with the cumulative effect of initially applying the guidance recognized at the date of initial application and providing certain additional disclosures as defined per the guidance. Early adoption is not permitted. We are currently evaluating adoption methods and whether this standard will have a material impact on our condensed consolidated financial statements.

[0001327567-15-000018:notes:23]
In July 2013, the FASB issued new authoritative guidance on the financial statement presentation of an unrecognized tax benefit when a net operating loss carryforward, a similar tax loss, or a tax credit carryforward exists. The standard requires us to present an unrecognized tax benefit as a reduction of a deferred tax asset for a net operating loss (NOL) carryforward or other tax credit carryforward when settlement in this manner is available under applicable tax law. The guidance was effective for us in the first quarter of fiscal 2015. Our adoption of this guidance did not have an impact on our condensed consolidated financial statements.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001327567-15-000018:notes:24]
Commitments and Contingencies

[0001327567-15-000018:notes:25]
Leases

[0001327567-15-000018:notes:26]
We lease our facilities under various non-cancelable operating leases, which expire through the year ending July 31, 2023.

[0001327567-15-000018:notes:27]
The following table presents details of the aggregate future non-cancelable minimum rental payments under our operating leases as of April 30, 2015 (in thousands):

[0001327567-15-000018:notes:28]
|  | Amount |
| Fiscal years ending July 31: |  |
| Remaining 2015 | $ | 4,344 |  |
| 2016 | 17,818 |  |
| 2017 | 16,467 |  |
| 2018 | 13,339 |  |
| 2019 | 11,056 |  |
| 2020 and thereafter | 43,196 |  |
| Committed gross lease payments | 106,220 |  |
| Less: proceeds from sublease rental | 8,939 |  |
| Net operating lease obligation | $ | 97,281 |  |

[0001327567-15-000018:notes:29]
Contract Manufacturer Commitments

[0001327567-15-000018:notes:30]
Our independent contract manufacturer procures components and assembles our products based on our forecasts. These forecasts are based on estimates of demand for our products primarily for the next twelve months, which are in turn based on historical trends and an analysis from our sales and product marketing organizations, adjusted for overall market conditions. In order to reduce manufacturing lead times and plan for adequate supply, we may issue forecasts and orders for components and products that are non-cancelable. Obligations under contracts that we can cancel without a significant penalty are not included. As of April 30, 2015, we had $41,772,000 of open orders.

[0001327567-15-000018:notes:31]
Litigation

[0001327567-15-000018:notes:32]
In December 2011, Juniper Networks, Inc. (“Juniper”) filed a complaint against us in the United States District Court for the District of Delaware alleging patent infringement, which sought preliminary and permanent injunctions against infringement, treble damages, and attorneys' fees. On September 30, 2013, we filed a lawsuit against Juniper in the United States District Court for the Northern District of California alleging that Juniper’s products infringe three of our U.S. patents, and sought monetary damages and a permanent injunction. On May 27, 2014, we entered into a Settlement, Release and Cross-License Agreement (the “settlement agreement”) with Juniper to resolve all pending litigation between the parties, including those discussed above. Refer to Note 8. Legal Settlement for more information on the settlement agreement.

[0001327567-15-000018:notes:33]
In addition to the above matter, we are subject to legal proceedings, claims, and litigation arising in the ordinary course of business, including intellectual property litigation. Such matters are subject to many uncertainties and outcomes are not predictable with assurance. We accrue for contingencies when we believe that a loss is probable and that we can reasonably estimate the amount of any such loss.

[0001327567-15-000018:notes:34]
To the extent there is a reasonable possibility that a loss exceeding amounts already recognized may be incurred and the amount of such additional loss would be material, we will either disclose the estimated additional loss or state that such an estimate cannot be made. As of April 30, 2015, we have not recorded any significant accruals for loss contingencies associated with such legal proceedings, determined that an unfavorable outcome is probable or reasonably possible, or determined that the amount or range of any possible loss is reasonably estimable.


## us-gaap:ConvertibleDebtTableTextBlock

[0001327567-15-000018:notes:35]
The following table sets forth the components of the Notes as of April 30, 2015 and July 31, 2014 (in thousands):

[0001327567-15-000018:notes:36]
|  | April 30, 2015 |  | July 31, 2014 |
| Liability: |  |  |  |
| Principal | $ | 575,000 |  |  | $ | 575,000 |  |
| Less: debt discount, net of amortization | 93,040 |  |  | 108,125 |  |
| Net carrying amount | $ | 481,960 |  |  | $ | 466,875 |  |


## us-gaap:DebtDisclosureTextBlock

[0001327567-15-000018:notes:37]
Convertible Senior Notes

[0001327567-15-000018:notes:38]
On June 30, 2014, we issued $575,000,000 aggregate principal amount of 0.0% Convertible Senior Notes due 2019 (the “Notes”). The Notes are governed by an indenture between us, as the issuer, and U.S. Bank National Association, as Trustee (the “Indenture”). The Notes are unsecured, unsubordinated obligations that do not contain any financial covenants or restrictions on the payments of dividends, the incurrence of indebtedness, or the issuance or repurchase of securities by us or any of our subsidiaries. The Notes mature on July 1, 2019 unless converted or repurchased in accordance with their terms prior to such date. We cannot redeem the Notes prior to maturity.

[0001327567-15-000018:notes:39]
The Notes are convertible for up to 5,214,000 shares of our common stock at an initial conversion rate of approximately 9.068 shares of common stock per $1,000 principal amount, which is equal to an initial conversion price of approximately $110.28 per share of common stock, subject to adjustment. Holders of the Notes may surrender their Notes for conversion at their option at any time prior to the close of business on the business day immediately preceding January 1, 2019, only under the following circumstances:

[0001327567-15-000018:notes:40]
| • | during any fiscal quarter commencing after the fiscal quarter ending on October 31, 2014 (and only during such fiscal quarter), if the last reported sale price of our common stock for at least 20 trading days (whether or not consecutive) during a period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the conversion price for the Notes on each applicable trading day; |

[0001327567-15-000018:notes:41]
| • | during the five business day period after any five consecutive trading day period (the “measurement period”), in which the trading price per $1,000 principal amount of Notes for each trading day of the measurement period was less than 98% of the product of the last reported sale price of our common stock and the conversion rate for the Notes on each such trading day; or |

[0001327567-15-000018:notes:42]
| • | upon the occurrence of specified corporate events. |

[0001327567-15-000018:notes:43]
On or after January 1, 2019, holders may convert all or any portion of their Notes at any time prior to the close of business on the second scheduled trading day immediately preceding the maturity date regardless of the foregoing conditions. Upon conversion, holders will receive cash equal to the aggregate principal amount of the Notes to be converted, and, at our election, cash and/or shares of our common stock for any amounts in excess of the aggregate principal amount of the Notes being converted.

[0001327567-15-000018:notes:44]
The conversion price will be subject to adjustment in some events. Holders of the Notes who convert their Notes in connection with certain corporate events that constitute a “make-whole fundamental change” per the Indenture are, under certain circumstances, entitled to an increase in the conversion rate. Additionally, upon the occurrence of a corporate event that constitutes a “fundamental change” per the Indenture, holders of the Notes may require us to repurchase for cash all or a portion of the Notes at a purchase price equal to 100% of the principal amount of the Notes plus accrued and unpaid contingent interest.

[0001327567-15-000018:notes:45]
In accounting for the issuance of the Notes, we separated the Notes into liability and equity components. The carrying amount of the liability component was calculated by measuring the fair value of a similar liability that does not have an associated convertible feature. The carrying amount of the equity component representing the conversion option was determined by deducting the fair value of the liability component from the par value of the Notes as a whole. The difference between the principal amount of the Notes and the liability component (the “debt discount”), is amortized to interest expense using the effective interest method over the term of the Notes. The equity component of the Notes was recorded in additional paid-in capital in our condensed consolidated balance sheets and is not remeasured as long as it continues to meet the conditions for equity classification.

[0001327567-15-000018:notes:46]
In accounting for the transaction costs related to the issuance of the Notes, we allocated the total amount incurred to the liability and equity components using the same proportions as the proceeds from the Notes. Transaction costs attributable to the liability component were recorded in other assets in our condensed consolidated balance sheets and are being amortized to interest expense in our condensed consolidated statements of operations using the effective interest method over the term of the Notes. Transaction costs attributable to the equity component were netted with the equity component of the Notes in additional paid-in capital in our condensed consolidated balance sheets. We recorded liability issuance costs, or debt issuance costs, of $12,497,000 and equity issuance costs of $2,949,000.

[0001327567-15-000018:notes:47]
During the fiscal quarter ended April 30, 2015, the last reported sale price of our common stock was greater than or equal to 130% of the conversion price of the Notes for at least 20 of the last 30 consecutive trading days of such quarter. As a result, holders may convert their Notes at any time during the fiscal quarter ending July 31, 2015. Accordingly, as of April 30, 2015, we reclassified the net carrying amount of the Notes and related debt issuance costs to current liabilities and current assets, respectively, in our condensed consolidated balance sheets. We also reclassified a portion of the equity component representing the conversion option to temporary equity in our condensed consolidated balance sheets. The amount reclassified to temporary equity was measured as the difference between the principal and net carrying amount of the Notes as of April 30, 2015.

[0001327567-15-000018:notes:48]
The total estimated fair value of the Notes was $836,987,000 and $587,087,000 at April 30, 2015 and July 31, 2014, respectively. The fair value was determined based on the closing trading price per $100 of the Notes as of the last day of trading for the period. We consider the fair value of the Notes at April 30, 2015 and July 31, 2014 to be a Level 2 measurement. The fair value of the Notes is primarily affected by the trading price of our common stock and market interest rates. As of April 30, 2015, the if-converted value of the Notes exceeded its principal amount by $188,879,000.

[0001327567-15-000018:notes:49]
The following table sets forth interest expense recognized related to the Notes for the three and nine months ended April 30, 2015 (dollars in thousands):

[0001327567-15-000018:notes:50]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 30, 2015 |
| Amortization of debt issuance costs | $ | 522 |  |  | $ | 1,524 |  |
| Amortization of debt discount | 5,088 |  |  | 15,085 |  |
| Total interest expense recognized | $ | 5,610 |  |  | $ | 16,609 |  |
| Effective interest rate of the liability component | 4.8 | % |  | 4.8 | % |

[0001327567-15-000018:notes:51]
Note Hedges

[0001327567-15-000018:notes:52]
To minimize the impact of potential economic dilution upon conversion of the Notes, we entered into convertible note hedge transactions (the “Note Hedges”) with respect to our common stock concurrent with the issuance of the Notes. The Note Hedges cover up to 5,214,000 shares of our common stock at a strike price per share that corresponds to the initial conversion price of the Notes, which are also subject to adjustment, and are exercisable upon conversion of the Notes. The Note Hedges will expire upon maturity of the Notes. The Note Hedges are separate transactions and are not part of the terms of the Notes. Holders of the Notes will not have any rights with respect to the Note Hedges. The shares receivable related to the Note Hedges are excluded from the calculation of diluted earnings per share as they are antidilutive.

[0001327567-15-000018:notes:53]
We paid an aggregate amount of $110,975,000 for the Note Hedges, which is included in additional paid-in capital in our condensed consolidated balance sheets.

[0001327567-15-000018:notes:54]
Warrants

[0001327567-15-000018:notes:55]
Separately, but concurrently with our issuance of the Notes, we entered into warrant transactions (the “Warrants”) whereby we sold warrants to acquire up to 5,214,000 shares of our common stock at a strike price of approximately $137.85 per share, subject to adjustments. The shares issuable under the Warrants will be included in the calculation of diluted earnings per share when the average market value per share of our common stock for the reporting period exceeds the strike price of the Warrants. The Warrants are separate transactions and are not part of the Notes or Notes Hedges, and are not remeasured through earnings each reporting period. Holders of the Notes and Note Hedges will not have any rights with respect to the Warrants.

[0001327567-15-000018:notes:56]
We received aggregate proceeds of $78,258,000 from the sale of the Warrants, which is included in additional paid-in capital in our condensed consolidated balance sheets.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001327567-15-000018:notes:57]
[same as prior period, unchanged from 0001327567-15-000008:notes:54]

[0001327567-15-000018:notes:58]
[same as prior period, unchanged from 0001327567-15-000008:notes:55]

[0001327567-15-000018:notes:59]
[same as prior period, unchanged from 0001327567-15-000008:notes:56]

[0001327567-15-000018:notes:60]
|  | Options Outstanding |
|  | Number of Shares |  | Weighted- Average Exercise Price Per Share |  | Weighted- Average Remaining Contractual Term (Years) |  | Aggregate Intrinsic Value |
| Balance—July 31, 2014 | 5,830 |  |  | $ | 13.02 |  |  | 7.0 |  | $ | 395,507 |  |
| Options granted | — |  |  | — |  |  |  |  |  |
| Options forfeited | (51 | ) |  | 17.57 |  |  |  |  |  |
| Options exercised | (1,953 | ) |  | 11.85 |  |  |  |  |  |
| Balance—April 30, 2015 | 3,826 |  |  | $ | 13.56 |  |  | 6.4 |  | $ | 513,296 |  |
| Options vested and expected to vest—April 30, 2015 | 3,792 |  |  | $ | 13.50 |  |  | 6.4 |  | $ | 508,962 |  |
| Options exercisable—April 30, 2015 | 2,748 |  |  | $ | 11.67 |  |  | 6.2 |  | $ | 373,865 |  |

[0001327567-15-000018:notes:61]
[same as prior period, unchanged from 0001327567-15-000008:notes:58]

[0001327567-15-000018:notes:62]
[same as prior period, unchanged from 0001327567-15-000008:notes:59]

[0001327567-15-000018:notes:63]
|  | RSUs Outstanding |
|  | Number of Shares |  | Weighted- Average Grant-Date Fair Value Per Share |  | Weighted- Average Remaining Contractual Term (Years) |  | Aggregate Intrinsic Value |
| Balance—July 31, 2014 | 6,046 |  |  | $ | 59.84 |  |  | 1.4 |  | $ | 488,880 |  |
| RSUs granted | 3,459 |  |  | 110.53 |  |  |  |  |  |
| RSUs vested | (1,885 | ) |  | 56.59 |  |  |  |  |  |
| RSUs forfeited | (370 | ) |  | 67.64 |  |  |  |  |  |
| Balance—April 30, 2015 | 7,250 |  |  | $ | 84.47 |  |  | 1.3 |  | $ | 1,070,970 |  |
| RSUs vested and expected to vest—April 30, 2015 | 6,610 |  |  | $ | 83.99 |  |  | 1.3 |  | $ | 976,429 |  |

[0001327567-15-000018:notes:64]
[same as prior period, unchanged from 0001327567-15-000008:notes:61]

[0001327567-15-000018:notes:65]
[same as prior period, unchanged from 0001327567-15-000008:notes:62]

[0001327567-15-000018:notes:66]
|  | Three Months Ended April 30, |  | Nine Months Ended April 30, |
|  | 2015 |  | 2014 |  | 2015 |  | 2014 |
| Cost of product revenue | $ | 1,031 |  |  | $ | 417 |  |  | $ | 2,735 |  |  | $ | 1,001 |  |
| Cost of services revenue | 5,587 |  |  | 2,739 |  |  | 14,222 |  |  | 6,310 |  |
| Research and development | 19,821 |  |  | 8,666 |  |  | 52,810 |  |  | 17,825 |  |
| Sales and marketing | 22,168 |  |  | 12,372 |  |  | 59,694 |  |  | 29,050 |  |
| General and administrative | 11,627 |  |  | 3,798 |  |  | 26,129 |  |  | 12,601 |  |
| Total | $ | 60,234 |  |  | $ | 27,992 |  |  | $ | 155,590 |  |  | $ | 66,787 |  |

[0001327567-15-000018:notes:67]
At April 30, 2015, total compensation cost related to unvested share-based awards not yet recognized was $510,411,000, net of estimated forfeitures. This cost is expected to be amortized on a straight-line basis over a weighted-average period of approximately three years.


## us-gaap:EarningsPerShareTextBlock

[0001327567-15-000018:notes:68]
[same as prior period, unchanged from 0001327567-15-000008:notes:65]

[0001327567-15-000018:notes:69]
[same as prior period, unchanged from 0001327567-15-000008:notes:66]

[0001327567-15-000018:notes:70]
[same as prior period, unchanged from 0001327567-15-000008:notes:67]

[0001327567-15-000018:notes:71]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 30, |  | April 30, |
|  | 2015 |  | 2014 |  | 2015 |  | 2014 |
| Net loss | $ | (45,935 | ) |  | $ | (146,587 | ) |  | $ | (119,011 | ) |  | $ | (194,394 | ) |
| Weighted-average shares used to compute net loss per share, basic and diluted | 82,320 |  |  | 74,967 |  |  | 80,828 |  |  | 73,127 |  |
| Net loss per share, basic and diluted | $ | (0.56 | ) |  | $ | (1.96 | ) |  | $ | (1.47 | ) |  | $ | (2.66 | ) |

[0001327567-15-000018:notes:72]
The following securities were excluded from the computation of diluted net loss per share of common stock for the periods presented as their effect would have been antidilutive (in thousands):

[0001327567-15-000018:notes:73]
|  | April 30, |
|  | 2015 |  | 2014 |
| Options to purchase common stock | 3,826 |  |  | 6,596 |  |
| RSUs | 7,250 |  |  | 5,310 |  |
| ESPP shares | 28 |  |  | 41 |  |
| Convertible senior notes | 5,214 |  |  | — |  |
| Warrants related to the issuance of convertible senior notes | 5,214 |  |  | — |  |
| Total | 21,532 |  |  | 11,947 |  |


## us-gaap:FairValueAssetsAndLiabilitiesMeasuredOnRecurringAndNonrecurringBasisTableTextBlock

[0001327567-15-000018:notes:74]
The following table presents the fair value of our financial assets and liabilities using the above input categories as of April 30, 2015 and July 31, 2014 (in thousands):

[0001327567-15-000018:notes:75]
|  |  | April 30, 2015 |  | July 31, 2014 |
|  |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Short-term investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Certificates of deposit |  | $ | — |  |  | $ | 1,000 |  |  | $ | — |  |  | $ | 1,000 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Corporate debt securities |  | — |  |  | 72,072 |  |  | — |  |  | 72,072 |  |  | — |  |  | 22,239 |  |  | — |  |  | 22,239 |  |
| U.S. government and agency securities |  | — |  |  | 295,778 |  |  | — |  |  | 295,778 |  |  | — |  |  | 96,451 |  |  | — |  |  | 96,451 |  |
| Total short-term investments |  | — |  |  | 368,850 |  |  | — |  |  | 368,850 |  |  | — |  |  | 118,690 |  |  | — |  |  | 118,690 |  |
| Long-term investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Certificates of deposit |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 1,000 |  |  | — |  |  | 1,000 |  |
| Corporate debt securities |  | — |  |  | 88,938 |  |  | — |  |  | 88,938 |  |  | — |  |  | 39,018 |  |  | — |  |  | 39,018 |  |
| U.S. government and agency securities |  | — |  |  | 319,527 |  |  | — |  |  | 319,527 |  |  | — |  |  | 161,862 |  |  | — |  |  | 161,862 |  |
| Total long-term investments |  | — |  |  | 408,465 |  |  | — |  |  | 408,465 |  |  | — |  |  | 201,880 |  |  | — |  |  | 201,880 |  |
| Other assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Certificates of deposit |  | — |  |  | — |  |  | — |  |  | — |  |  | 1,220 |  |  | — |  |  | — |  |  | 1,220 |  |
| Total other assets |  | — |  |  | — |  |  | — |  |  | — |  |  | 1,220 |  |  | — |  |  | — |  |  | 1,220 |  |
| Total assets measured at fair value |  | $ | — |  |  | $ | 777,315 |  |  | $ | — |  |  | $ | 777,315 |  |  | $ | 1,220 |  |  | $ | 320,570 |  |  | $ | — |  |  | $ | 321,790 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001327567-15-000018:notes:76]
[same as prior period, unchanged from 0001327567-15-000008:notes:73]

[0001327567-15-000018:notes:77]
[same as prior period, unchanged from 0001327567-15-000008:notes:74]

[0001327567-15-000018:notes:78]
[same as prior period, unchanged from 0001327567-15-000008:notes:75]

[0001327567-15-000018:notes:79]
[same as prior period, unchanged from 0001327567-15-000008:notes:76]

[0001327567-15-000018:notes:80]
[same as prior period, unchanged from 0001327567-15-000008:notes:77]

[0001327567-15-000018:notes:81]
Refer to Note 6. Convertible Senior Notes for the carrying amount and estimated fair value of our convertible senior notes as of April 30, 2015.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001327567-15-000018:notes:82]
[same as prior period, unchanged from 0001327567-15-000008:notes:79]

[0001327567-15-000018:notes:83]
Our provision for income taxes for the three and nine months ended April 30, 2015 reflects an effective tax rate of negative 8.3% and negative 3.5%, respectively. Our effective tax rate for these periods were negative as we recorded a provision for income taxes on year to date losses. The key components of our income tax provision consist of foreign income, foreign withholding taxes, U.S. federal and state income taxes, and amortization of our deferred tax charge. Key components of our effective tax rate consist of foreign tax losses which derive no benefit, non-deductible share-based compensation, and changes in our valuation allowance. As compared to the same periods last year, our effective tax rate changed due to a shift in geographical mix of income and amortization of our deferred tax charge.

[0001327567-15-000018:notes:84]
Our provision for income taxes for the three and nine months ended April 30, 2014 reflects an effective tax rate of negative 0.9% and negative 2.7%, respectively. Our effective tax rates for these periods were negative due to the fact that we recorded a provision for income taxes on year to date losses. The key components of our income tax provision, and the related effective tax rate, consist of foreign tax losses which derive no benefit, non-deductible share-based compensation, and foreign withholding taxes.

[0001327567-15-000018:notes:85]
[same as prior period, unchanged from 0001327567-15-000008:notes:82]

[0001327567-15-000018:notes:86]
As of April 30, 2015, we had $57,573,000 of unrecognized tax benefits, $4,888,000 of which would affect income tax expense if recognized, after consideration of our valuation allowance in the U.S. and other assets. The increase in unrecognized tax benefits since July 31, 2014 relates to positions taken in the current year. As of April 30, 2015, our federal, state, and foreign returns for the tax years 2008 through the current period remain open to examination. Fiscal years outside the normal statute of limitation remain open to audit by tax authorities due to tax attributes generated in earlier years, which have been carried forward and may be audited in subsequent years when utilized. We do not expect the unrecognized tax benefits to change significantly over the next 12 months. We recognize both interest and penalties associated with uncertain tax positions as a component of income tax expense. The ultimate amount and timing of any future cash settlements cannot be predicted with reasonable certainty.


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001327567-15-000018:notes:87]
[same as prior period, unchanged from 0001327567-15-000008:notes:84]

[0001327567-15-000018:notes:88]
We recognized amortization expense of $1,971,000 and $5,680,000 for the three and nine months ended April 30, 2015, respectively, and $820,000 and $1,245,000 for the three and nine months ended April 30, 2014, respectively. Our in-process research and development acquired from Cyvera Ltd. (“Cyvera”) in April 2014 was transferred to developed technology during the three months ended October 31, 2014 and is being amortized over its estimated useful life of seven years.

[0001327567-15-000018:notes:89]
The following table summarizes our estimated future amortization expense of intangible assets with finite lives by type as of April 30, 2015 (in thousands):

[0001327567-15-000018:notes:90]
|  | Fiscal Years Ending July 31, |
|  | Remaining 2015 |  | 2016 |  | 2017 |  | 2018 |  | 2019 |  | 2020 and Thereafter |
| Developed technology | $ | 1,502 |  |  | $ | 6,014 |  |  | $ | 6,014 |  |  | $ | 6,014 |  |  | $ | 6,014 |  |  | $ | 10,568 |  |
| Acquired intellectual property | 245 |  |  | 947 |  |  | 853 |  |  | 617 |  |  | 511 |  |  | 3,338 |  |
| In-process research and development held for defensive purposes | 159 |  |  | 633 |  |  | 264 |  |  | — |  |  | — |  |  | — |  |
| Other | 62 |  |  | 130 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Total future amortization expense | $ | 1,968 |  |  | $ | 7,724 |  |  | $ | 7,131 |  |  | $ | 6,631 |  |  | $ | 6,525 |  |  | $ | 13,906 |  |


## us-gaap:InvestmentsClassifiedByContractualMaturityDateTableTextBlock

[0001327567-15-000018:notes:91]
The following table summarizes the amortized cost and fair value of our investments as of April 30, 2015, by contractual years-to-maturity (in thousands):

[0001327567-15-000018:notes:92]
|  | Amortized Cost |  | Fair Value |
| Due within one year | $ | 368,766 |  |  | $ | 368,850 |  |
| Due between one and three years | 408,326 |  |  | 408,465 |  |
| Total | $ | 777,092 |  |  | $ | 777,315 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001327567-15-000018:notes:93]
Investments

[0001327567-15-000018:notes:94]
Unrealized losses related to these investments are due to interest rate fluctuations as opposed to credit quality. In addition, we do not intend to sell and it is not likely that we would be required to sell these investments before recovery of their amortized cost basis, which may be at maturity. As a result, there is no other-than-temporary impairment for these investments at April 30, 2015.


## us-gaap:LegalMattersAndContingenciesTextBlock

[0001327567-15-000018:notes:95]
Legal Settlement

[0001327567-15-000018:notes:96]
Mutual Covenant Not to Sue and Release Agreement

[0001327567-15-000018:notes:97]
On January 27, 2014, we executed a Mutual Covenant Not to Sue and Release Agreement with Fortinet, Inc., thereby extending an existing covenant for six more years. We evaluated the transaction as a multiple-element arrangement and allocated the one-time payment that we made in the amount of $20,000,000 to each identifiable element using its relative fair value. Based on our estimates of fair value, we determined that the primary benefit of the arrangement is avoided litigation cost and the release of any potential past claims, with no material value attributable to future use or benefit. Accordingly, we recorded a $20,000,000 settlement charge within legal settlement expense in our condensed consolidated statement of operations during the three months ended January 31, 2014.

[0001327567-15-000018:notes:98]
Settlement, Release and Cross-License Agreement with Juniper

[0001327567-15-000018:notes:99]
On May 27, 2014, we entered into the settlement agreement with Juniper, whereby we resolved all pending litigation matters. Under the terms of the settlement agreement, we agreed to pay Juniper a one-time settlement amount comprised of $75,000,000 in cash, 1,081,000 shares of our common stock, and a warrant to purchase 463,000 shares of our common stock, in exchange for the following:

[0001327567-15-000018:notes:100]
| • | Mutual dismissal with prejudice of all pending litigation between the parties and general release of all liability for Palo Alto Networks and Juniper, |

[0001327567-15-000018:notes:101]
| • | Cross-license between both parties for the patents-in-suit and associated family members and counterparts worldwide for the life of the patents, and |

[0001327567-15-000018:notes:102]
| • | Mutual covenant not to sue for infringement of any other patents for a period of eight years. |

[0001327567-15-000018:notes:103]
The fair value of the total consideration as of the settlement date was $182,473,000, which was comprised of $75,000,000 in cash, $75,231,000 in common stock, and $32,242,000 in warrant. The fair values of the common stock and warrant were measured using the closing price of our common stock on the settlement date.

[0001327567-15-000018:notes:104]
The warrant was issued on June 3, 2014 and entitled Juniper to purchase up to 463,000 shares of common stock at an exercise price of $0.0001 per share and was classified as a liability during the period it was outstanding. On July 1, 2014, Juniper exercised the warrant in full. Accordingly, we recorded the change in the fair value of the warrant liability through the exercise date of $5,859,000 within other income (expense), net in our consolidated statement of operations during the three months ended July 31, 2014.

[0001327567-15-000018:notes:105]
We accounted for the settlement agreement as a multiple-element arrangement and allocated the fair value of the consideration as of the settlement date to the identifiable elements based on their estimated fair values. Of the total settlement amount, $61,300,000 was allocated to the licensing of intellectual property, $54,300,000 was allocated to the mutual dismissal of claims, and the remaining amount was allocated to the mutual covenant not to sue. The mutual dismissal of claims and the mutual covenant not to sue have no identifiable future benefit, and as a result we recorded a settlement charge within legal settlement expense in our condensed consolidated statement of operations during the three months ended April 30, 2014. The licensing of intellectual property is being amortized to cost of product revenue in our condensed consolidated statements of operations over the estimated period of benefit of five years.


## us-gaap:OtherAssetsDisclosureTextBlock

[0001327567-15-000018:notes:106]
[same as prior period, unchanged from 0001327567-15-000008:notes:103]

[0001327567-15-000018:notes:107]
The following table presents details of our other assets as of April 30, 2015 and July 31, 2014 (in thousands):

[0001327567-15-000018:notes:108]
|  | April 30, 2015 |  | July 31, 2014 |
| Intellectual property licenses | $ | 41,310 |  |  | $ | 46,997 |  |
| Deferred tax charge | 29,009 |  |  | — |  |
| Debt issuance costs | — |  |  | 12,332 |  |
| Other assets | 6,306 |  |  | 7,199 |  |
| Total other assets | $ | 76,625 |  |  | $ | 66,528 |  |

[0001327567-15-000018:notes:109]
In December 2014, we reorganized our corporate structure to more closely align with the global nature of our business. As a result, we recorded a deferred tax charge in other assets in our condensed consolidated balance sheets. This amount is being amortized on a straight-line basis over approximately six years as a component of provision for income taxes in our condensed consolidated statements of operations.


## us-gaap:SubsequentEventsTextBlock

[0001327567-15-000018:notes:110]
Subsequent Event

[0001327567-15-000018:notes:111]
In May 2015, we completed our acquisition of CirroSecure, Inc., a privately-held cybersecurity company, in exchange for total consideration of approximately $18,000,000. The acquisition expands the functionality of our enterprise security platform by providing additional security for SaaS applications. We are currently in the process of finalizing the accounting for this transaction and expect to complete our preliminary allocation of the purchase consideration to the assets acquired and liabilities assumed by the end of fiscal 2015.
