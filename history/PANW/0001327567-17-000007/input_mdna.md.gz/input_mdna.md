# PANW MD&A — 0001327567-17-000007


## mdna

[0001327567-17-000007:mdna:1]
[same as prior period, unchanged from 0001327567-16-000073:mdna:1]

[0001327567-17-000007:mdna:2]
[same as prior period, unchanged from 0001327567-16-000073:mdna:2]

[0001327567-17-000007:mdna:3]
[same as prior period, unchanged from 0001327567-16-000073:mdna:3]

[0001327567-17-000007:mdna:4]
[same as prior period, unchanged from 0001327567-16-000073:mdna:4]

[0001327567-17-000007:mdna:5]
| • | Results of Operations. A discussion of the nature and trends in our financial results and an analysis of our financial results comparing the three and six months ended January 31, 2017 to the three and six months ended January 31, 2016. |

[0001327567-17-000007:mdna:6]
[same as prior period, unchanged from 0001327567-16-000073:mdna:6]

[0001327567-17-000007:mdna:7]
[same as prior period, unchanged from 0001327567-16-000073:mdna:7]

[0001327567-17-000007:mdna:8]
[same as prior period, unchanged from 0001327567-16-000073:mdna:8]

[0001327567-17-000007:mdna:9]
[same as prior period, unchanged from 0001327567-16-000073:mdna:10]

[0001327567-17-000007:mdna:10]
[same as prior period, unchanged from 0001327567-16-000073:mdna:11]

[0001327567-17-000007:mdna:11]
Our Next-Generation Security Platform consists of three major elements: our Next-Generation Firewall, our Advanced Endpoint Protection, and our Threat Intelligence Cloud. Our Next-Generation Firewall delivers application, user, and content visibility and control as well as protection against network-based cyber threats integrated within the firewall through our

[0001327567-17-000007:mdna:12]
[same as prior period, unchanged from 0001327567-16-000073:mdna:32]

[0001327567-17-000007:mdna:13]
proprietary hardware and software architecture. Our Advanced Endpoint Protection prevents cyber attacks that aim to run malicious code or exploit software vulnerabilities on a broad variety of fixed and virtual endpoints and servers. Our Threat Intelligence Cloud provides central intelligence capabilities, security for software as a service (“SaaS”) applications, and automated delivery of preventative measures against cyber attacks.

[0001327567-17-000007:mdna:14]
For the second quarter of fiscal 2017 and 2016, total revenue was $422.6 million and $334.7 million, respectively, representing year-over-year growth of 26.3%. Our growth reflects the increased adoption of our hybrid SaaS revenue model, which consists of product, subscription, and support. We believe this model will enable us to benefit from recurring revenues as we continue to grow our installed end-customer base. As of January 31, 2017, we had more than 37,500 end-customers in over 150 countries. Our end-customers represent a broad range of industries including education, energy, financial services, government entities, healthcare, Internet and media, manufacturing, public sector, and telecommunications, and include some of the largest Fortune 100 and Global 2000 companies in the world. We maintain a field sales force that works closely with our channel partners in developing sales opportunities. We use a two-tiered, indirect fulfillment model whereby we sell our products and services to our distributors, which, in turn, sell to our resellers, which then sell to our end-customers.

[0001327567-17-000007:mdna:15]
Our product revenue was $168.8 million, or 39.9% of total revenue, for the second quarter of fiscal 2017, representing a year-over-year decrease of 0.6%. Product revenue is generated from sales of our appliances, primarily our Next-Generation Firewall, which is available in physical and virtualized form. Our Next-Generation Firewall incorporates our proprietary PAN-OS operating system, which provides a consistent set of capabilities across our entire product line. Our products are designed for different performance requirements throughout an organization, ranging from our PA-200, which is designed for enterprise remote offices, to our top-of-the-line PA-7080, which is especially suited for very large enterprise deployments and service provider customers. The same firewall functionality that is delivered in our physical appliances is also available in our VM-Series virtual firewalls, which secure virtualized and cloud-based computing environments.

[0001327567-17-000007:mdna:16]
Our subscription and support revenue was $253.8 million, or 60.1% of total revenue, for the second quarter of fiscal 2017, representing year-over-year growth of 54.0%. Our subscriptions provide our end-customers with real-time access to the latest antivirus, intrusion prevention, web filtering, and modern malware prevention capabilities across fixed and mobile devices. When end-customers purchase an appliance, they typically purchase one or more of our subscriptions for additional functionality, as well as support in order to receive ongoing security updates, upgrades, bug fixes, and repairs.

[0001327567-17-000007:mdna:17]
We continue to invest in innovation and extending our platform and, in February 2017, introduced several new products and features. First, we further expanded our family of firewalls with the launch of several new appliances: our PA-220, which is designed for small branch offices and remote locations; our PA-800 series, which are ideal for medium-sized networks and branch and remote office environments; our PA-5200 series, which deliver security for high throughput environments in a compact form factor; and the addition of three new VM-Series virtual firewall models, which support cloud and virtualization initiatives ranging from virtualized branch offices to data center and service provider deployments. Additionally, we delivered PAN-OS 8.0, an important software release that expands security for public and private clouds, provides new SaaS application security functionality, and provides the capabilities to prevent the theft and abuse of stolen credentials.

[0001327567-17-000007:mdna:18]
[same as prior period, unchanged from 0001327567-16-000073:mdna:16]

[0001327567-17-000007:mdna:19]
[same as prior period, unchanged from 0001327567-16-000073:mdna:17]

[0001327567-17-000007:mdna:20]
[same as prior period, unchanged from 0001327567-16-000073:mdna:18]

[0001327567-17-000007:mdna:21]
|  | January 31, 2017 |  | July 31, 2016 |
|  | (in millions) |
| Total deferred revenue | $ | 1,498.6 |  |  | $ | 1,240.8 |  |
| Cash, cash equivalents, and investments | $ | 2,144.9 |  |  | $ | 1,938.4 |  |

[0001327567-17-000007:mdna:22]
[same as prior period, unchanged from 0001327567-16-000073:mdna:40]

[0001327567-17-000007:mdna:23]
|  | Three Months Ended January 31, |  | Six Months Ended January 31, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
|  | (dollars in millions) |
| Total revenue | $ | 422.6 |  |  | $ | 334.7 |  |  | $ | 820.7 |  |  | $ | 631.9 |  |
| Total revenue year-over-year percentage increase | 26.3 | % |  | 53.8 | % |  | 29.9 | % |  | 54.1 | % |
| Gross margin(2) | 73.2 | % |  | 71.9 | % |  | 73.9 | % |  | 72.6 | % |
| Operating loss(1)(2) | $ | (54.4 | ) |  | $ | (50.1 | ) |  | $ | (103.4 | ) |  | $ | (82.1 | ) |
| Operating margin(1)(2) | (12.9 | )% |  | (15.0 | )% |  | (12.6 | )% |  | (13.0 | )% |
| Billings | $ | 561.6 |  |  | $ | 459.0 |  |  | $ | 1,078.5 |  |  | $ | 847.0 |  |
| Billings year-over-year percentage increase | 22.4 | % |  | 62.3 | % |  | 27.3 | % |  | 61.9 | % |
| Cash flow provided by operating activities(2) |  |  |  |  | $ | 417.8 |  |  | $ | 301.0 |  |
| Free cash flow (non-GAAP)(2) |  |  |  |  | $ | 352.2 |  |  | $ | 264.1 |  |

[0001327567-17-000007:mdna:24]
[same as prior period, unchanged from 0001327567-16-000073:mdna:22]

[0001327567-17-000007:mdna:25]
| (1) | Amounts have been adjusted for the three and six months ended January 31, 2016, as a result of our voluntary change in accounting policy for sales commissions. Refer to Note 1. Description of Business and Summary of Significant Accounting Policies in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information. |

[0001327567-17-000007:mdna:26]
| (2) | Certain amounts reflect adjustments as a result of our early adoption of new share-based payment accounting guidance. Refer to Note 1. Description of Business and Summary of Significant Accounting Policies in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information. |

[0001327567-17-000007:mdna:27]
[same as prior period, unchanged from 0001327567-16-000073:mdna:24]

[0001327567-17-000007:mdna:28]
[same as prior period, unchanged from 0001327567-16-000073:mdna:25]

[0001327567-17-000007:mdna:29]
|  | Three Months Ended January 31, |  | Six Months Ended January 31, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
|  | (in millions) |
| Billings: |  |  |  |  |  |  |  |
| Total revenue | $ | 422.6 |  |  | $ | 334.7 |  |  | $ | 820.7 |  |  | $ | 631.9 |  |
| Add: change in total deferred revenue | 139.0 |  |  | 124.3 |  |  | 257.8 |  |  | 215.1 |  |
| Billings | $ | 561.6 |  |  | $ | 459.0 |  |  | $ | 1,078.5 |  |  | $ | 847.0 |  |

[0001327567-17-000007:mdna:30]
| • | Cash Flow Provided by Operating Activities. We monitor cash flow provided by operating activities as a measure of our overall business performance. Our cash flow provided by operating activities is driven in large part by sales of our products and from up-front payments for subscription and support offerings. Monitoring cash flow provided by operating activities enables us to analyze our financial performance without the non-cash effects of certain items such as depreciation, amortization, and share-based compensation costs, thereby allowing us to better understand and manage the cash needs of our business. |

[0001327567-17-000007:mdna:31]
[same as prior period, unchanged from 0001327567-16-000073:mdna:53]

[0001327567-17-000007:mdna:32]
[same as prior period, unchanged from 0001327567-16-000073:mdna:30]

[0001327567-17-000007:mdna:33]
|  | Six Months Ended January 31, |
|  | 2017 |  | 2016 |
|  | (in millions) |
| Free cash flow (non-GAAP): |  |  |  |
| Net cash provided by operating activities(1) | $ | 417.8 |  |  | $ | 301.0 |  |
| Less: purchases of property, equipment, and other assets | 65.6 |  |  | 36.9 |  |
| Free cash flow (non-GAAP)(1) | $ | 352.2 |  |  | $ | 264.1 |  |
| Net cash used in investing activities | $ | (244.3 | ) |  | $ | (284.7 | ) |
| Net cash provided by (used in) financing activities(1) | $ | (146.5 | ) |  | $ | 21.1 |  |

[0001327567-17-000007:mdna:34]
[same as prior period, unchanged from 0001327567-16-000073:mdna:36]

[0001327567-17-000007:mdna:35]
| (1) | Amounts reflect adjustments as a result of our early adoption of new share-based payment accounting guidance. Refer to Note 1. Description of Business and Summary of Significant Accounting Policies in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information. |

[0001327567-17-000007:mdna:36]
[same as prior period, unchanged from 0001327567-16-000073:mdna:67]

[0001327567-17-000007:mdna:37]
[same as prior period, unchanged from 0001327567-16-000073:mdna:33]

[0001327567-17-000007:mdna:38]
[same as prior period, unchanged from 0001327567-16-000073:mdna:34]

[0001327567-17-000007:mdna:39]
Due to our early adoption of new share-based payment accounting guidance in the second quarter of fiscal 2017, certain amounts for the six months ended January 31, 2017 in the tables and discussion that follow reflect an adjustment for the three months ended October 31, 2016. Refer to Note 1. Description of Business and Summary of Significant Accounting Policies in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information.

[0001327567-17-000007:mdna:40]
|  | Three Months Ended January 31, |  | Six Months Ended January 31, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
|  | Amount |  | % of Revenue |  | Amount(1) |  | % of Revenue(1) |  | Amount |  | % of Revenue |  | Amount(1) |  | % of Revenue(1) |
|  | (dollars in millions) |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 168.8 |  |  | 39.9 | % |  | $ | 169.9 |  |  | 50.7 | % |  | $ | 332.6 |  |  | 40.5 | % |  | $ | 317.6 |  |  | 50.3 | % |
| Subscription and support | 253.8 |  |  | 60.1 | % |  | 164.8 |  |  | 49.3 | % |  | 488.1 |  |  | 59.5 | % |  | 314.3 |  |  | 49.7 | % |
| Total revenue | 422.6 |  |  | 100.0 | % |  | 334.7 |  |  | 100.0 | % |  | 820.7 |  |  | 100.0 | % |  | 631.9 |  |  | 100.0 | % |
| Cost of revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product | 45.8 |  |  | 10.8 | % |  | 44.9 |  |  | 13.4 | % |  | 88.0 |  |  | 10.7 | % |  | 83.7 |  |  | 13.2 | % |
| Subscription and support | 67.4 |  |  | 16.0 | % |  | 49.3 |  |  | 14.7 | % |  | 126.4 |  |  | 15.4 | % |  | 89.7 |  |  | 14.2 | % |
| Total cost of revenue(2) | 113.2 |  |  | 26.8 | % |  | 94.2 |  |  | 28.1 | % |  | 214.4 |  |  | 26.1 | % |  | 173.4 |  |  | 27.4 | % |
| Total gross profit | 309.4 |  |  | 73.2 | % |  | 240.5 |  |  | 71.9 | % |  | 606.3 |  |  | 73.9 | % |  | 458.5 |  |  | 72.6 | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | 89.9 |  |  | 21.3 | % |  | 74.0 |  |  | 22.1 | % |  | 174.1 |  |  | 21.2 | % |  | 133.7 |  |  | 21.2 | % |
| Sales and marketing | 226.7 |  |  | 53.6 | % |  | 182.4 |  |  | 54.5 | % |  | 446.8 |  |  | 54.4 | % |  | 341.9 |  |  | 54.1 | % |
| General and administrative | 47.2 |  |  | 11.2 | % |  | 34.2 |  |  | 10.3 | % |  | 88.8 |  |  | 10.9 | % |  | 65.0 |  |  | 10.3 | % |
| Total operating expenses(2) | 363.8 |  |  | 86.1 | % |  | 290.6 |  |  | 86.9 | % |  | 709.7 |  |  | 86.5 | % |  | 540.6 |  |  | 85.6 | % |
| Operating loss | (54.4 | ) |  | (12.9 | )% |  | (50.1 | ) |  | (15.0 | )% |  | (103.4 | ) |  | (12.6 | )% |  | (82.1 | ) |  | (13.0 | )% |
| Interest expense | (6.1 | ) |  | (1.4 | )% |  | (5.8 | ) |  | (1.7 | )% |  | (12.1 | ) |  | (1.5 | )% |  | (11.6 | ) |  | (1.8 | )% |
| Other income, net | 2.7 |  |  | 0.6 | % |  | 2.5 |  |  | 0.7 | % |  | 5.2 |  |  | 0.7 | % |  | 4.7 |  |  | 0.7 | % |
| Loss before income taxes | (57.8 | ) |  | (13.7 | )% |  | (53.4 | ) |  | (16.0 | )% |  | (110.3 | ) |  | (13.4 | )% |  | (89.0 | ) |  | (14.1 | )% |
| Provision for income taxes | 2.8 |  |  | 0.6 | % |  | 3.9 |  |  | 1.2 | % |  | 7.2 |  |  | 0.9 | % |  | 8.2 |  |  | 1.3 | % |
| Net loss | $ | (60.6 | ) |  | (14.3 | )% |  | $ | (57.3 | ) |  | (17.2 | )% |  | $ | (117.5 | ) |  | (14.3 | )% |  | $ | (97.2 | ) |  | (15.4 | )% |

[0001327567-17-000007:mdna:41]
[same as prior period, unchanged from 0001327567-16-000073:mdna:80]

[0001327567-17-000007:mdna:42]
| (1) | Certain prior period amounts have been adjusted as a result of our voluntary change in accounting policy for sales commissions. Refer to Note 1. Description of Business and Summary of Significant Accounting Policies in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information. |

[0001327567-17-000007:mdna:43]
[same as prior period, unchanged from 0001327567-16-000073:mdna:38]

[0001327567-17-000007:mdna:44]
|  | Three Months Ended January 31, |  | Six Months Ended January 31, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Cost of product revenue | $ | 2.0 |  |  | $ | 1.6 |  |  | $ | 3.7 |  |  | $ | 2.9 |  |
| Cost of subscription and support revenue | 15.0 |  |  | 10.5 |  |  | 27.3 |  |  | 17.5 |  |
| Research and development | 41.3 |  |  | 34.9 |  |  | 79.3 |  |  | 59.9 |  |
| Sales and marketing | 49.7 |  |  | 39.4 |  |  | 93.5 |  |  | 66.6 |  |
| General and administrative | 19.3 |  |  | 15.5 |  |  | 36.8 |  |  | 27.9 |  |
| Total share-based compensation | $ | 127.3 |  |  | $ | 101.9 |  |  | $ | 240.6 |  |  | $ | 174.8 |  |

[0001327567-17-000007:mdna:45]
[same as prior period, unchanged from 0001327567-16-000073:mdna:78]

[0001327567-17-000007:mdna:46]
[same as prior period, unchanged from 0001327567-16-000073:mdna:41]

[0001327567-17-000007:mdna:47]
[same as prior period, unchanged from 0001327567-16-000073:mdna:42]

[0001327567-17-000007:mdna:48]
[same as prior period, unchanged from 0001327567-16-000073:mdna:43]

[0001327567-17-000007:mdna:49]
[same as prior period, unchanged from 0001327567-16-000073:mdna:44]

[0001327567-17-000007:mdna:50]
|  | Three Months Ended January 31, |  |  |  |  |  | Six Months Ended January 31, |  |  |  |  |
|  | 2017 |  | 2016 |  | Change |  | 2017 |  | 2016 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Product | $ | 168.8 |  |  | $ | 169.9 |  |  | $ | (1.1 | ) |  | (0.6 | )% |  | $ | 332.6 |  |  | $ | 317.6 |  |  | $ | 15.0 |  |  | 4.7 | % |

[0001327567-17-000007:mdna:51]
Product revenue decreased slightly for the three months ended January 31, 2017 compared to the three months ended January 31, 2016 due to lower sales productivity in certain markets in the U.S.

[0001327567-17-000007:mdna:52]
Product revenue increased for the six months ended January 31, 2017 compared to the six months ended January 31, 2016 due to increased demand for our higher-end appliances.

[0001327567-17-000007:mdna:53]
[same as prior period, unchanged from 0001327567-16-000073:mdna:47]

[0001327567-17-000007:mdna:54]
[same as prior period, unchanged from 0001327567-16-000073:mdna:48]

[0001327567-17-000007:mdna:55]
|  | Three Months Ended January 31, |  |  |  |  |  | Six Months Ended January 31, |  |  |  |  |
|  | 2017 |  | 2016 |  | Change |  | 2017 |  | 2016 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Subscription | $ | 134.3 |  |  | $ | 84.3 |  |  | $ | 50.0 |  |  | 59.3 | % |  | $ | 255.5 |  |  | $ | 157.9 |  |  | $ | 97.6 |  |  | 61.8 | % |
| Support | 119.5 |  |  | 80.5 |  |  | 39.0 |  |  | 48.4 | % |  | 232.6 |  |  | 156.4 |  |  | 76.2 |  |  | 48.7 | % |
| Total subscription and support | $ | 253.8 |  |  | $ | 164.8 |  |  | $ | 89.0 |  |  | 54.0 | % |  | $ | 488.1 |  |  | $ | 314.3 |  |  | $ | 173.8 |  |  | 55.3 | % |

[0001327567-17-000007:mdna:56]
Subscription and support revenue increased for the three and six months ended January 31, 2017 compared to the three and six months ended January 31, 2016. The increases in both periods were due to increased demand for our subscription and support offerings from both new and existing end-customers. The mix between subscription revenue and support revenue will fluctuate over time, depending on the introduction of new subscription offerings, renewals of support services, and our ability to increase sales to new and existing customers. The change in subscription and support revenue due to changes in pricing was not significant for either period.

[0001327567-17-000007:mdna:57]
[same as prior period, unchanged from 0001327567-16-000073:mdna:92]

[0001327567-17-000007:mdna:58]
[same as prior period, unchanged from 0001327567-16-000073:mdna:51]

[0001327567-17-000007:mdna:59]
|  | Three Months Ended January 31, |  |  |  |  |  | Six Months Ended January 31, |  |  |  |  |
|  | 2017 |  | 2016 |  | Change |  | 2017 |  | 2016 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Americas | $ | 295.0 |  |  | $ | 229.7 |  |  | $ | 65.3 |  |  | 28.4 | % |  | $ | 575.2 |  |  | $ | 441.0 |  |  | $ | 134.2 |  |  | 30.4 | % |
| EMEA | 78.8 |  |  | 62.1 |  |  | 16.7 |  |  | 26.9 | % |  | 149.5 |  |  | 115.8 |  |  | 33.7 |  |  | 29.1 | % |
| APAC | 48.8 |  |  | 42.9 |  |  | 5.9 |  |  | 13.8 | % |  | 96.0 |  |  | 75.1 |  |  | 20.9 |  |  | 27.8 | % |
| Total revenue | $ | 422.6 |  |  | $ | 334.7 |  |  | $ | 87.9 |  |  | 26.3 | % |  | $ | 820.7 |  |  | $ | 631.9 |  |  | $ | 188.8 |  |  | 29.9 | % |

[0001327567-17-000007:mdna:60]
With respect to geographic theaters, the Americas contributed the largest portion of the increase in revenue for the three and six months ended January 31, 2017 compared to the three and six months ended January 31, 2016, due to its larger and more established sales force compared to our other theaters. Revenue from both Europe, the Middle East, and Africa (“EMEA”) and Asia Pacific and Japan (“APAC”) increased for the three and six months ended January 31, 2017 compared to the three and six months ended January 31, 2016, due to our investment in increasing the size of our sales force and number of channel partners in these theaters.

[0001327567-17-000007:mdna:61]
[same as prior period, unchanged from 0001327567-16-000073:mdna:55]

[0001327567-17-000007:mdna:62]
[same as prior period, unchanged from 0001327567-16-000073:mdna:56]

[0001327567-17-000007:mdna:63]
[same as prior period, unchanged from 0001327567-16-000073:mdna:57]

[0001327567-17-000007:mdna:64]
[same as prior period, unchanged from 0001327567-16-000073:mdna:58]

[0001327567-17-000007:mdna:65]
|  | Three Months Ended January 31, |  |  |  | Six Months Ended January 31, |  |  |  |  |
|  | 2017 |  | 2016 |  | Change |  | 2017 |  | 2016 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Cost of product revenue | $ | 45.8 |  |  | $ | 44.9 |  |  | $ | 0.9 |  |  | 2.0 | % |  | $ | 88.0 |  |  | $ | 83.7 |  |  | $ | 4.3 |  |  | 5.1 | % |
| Number of employees at period end | 92 |  |  | 82 |  |  | 10 |  |  | 12.2 | % |  | 92 |  |  | 82 |  |  | 10 |  |  | 12.2 | % |

[0001327567-17-000007:mdna:66]
Cost of product revenue increased slightly for the three months ended January 31, 2017 compared to the three months ended January 31, 2016, primarily due to an increase in personnel costs due to headcount growth.

[0001327567-17-000007:mdna:67]
Cost of product revenue increased for the six months ended January 31, 2017 compared to the six months ended January 31, 2016, primarily due to an increase in product unit volume for our higher end appliances.

[0001327567-17-000007:mdna:68]
[same as prior period, unchanged from 0001327567-16-000073:mdna:103]

[0001327567-17-000007:mdna:69]
[same as prior period, unchanged from 0001327567-16-000073:mdna:61]

[0001327567-17-000007:mdna:70]
Cost of subscription and support revenue includes personnel costs for our global customer support and technical operations organizations, amortization of acquired intangible assets, third-party professional services costs, and allocated costs. We expect our cost of subscription and support revenue to increase as our installed end-customer base grows. Prior to fiscal 2017, cost of subscription and support revenue was referred to as cost of services revenue, however, the composition of cost of subscription and support revenue has not been modified.

[0001327567-17-000007:mdna:71]
|  | Three Months Ended January 31, |  |  |  | Six Months Ended January 31, |  |  |  |  |
|  | 2017 |  | 2016 |  | Change |  | 2017 |  | 2016 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Cost of subscription and support revenue | $ | 67.4 |  |  | $ | 49.3 |  |  | $ | 18.1 |  |  | 36.7 | % |  | $ | 126.4 |  |  | $ | 89.7 |  |  | $ | 36.7 |  |  | 40.9 | % |
| Number of employees at period end | 623 |  |  | 457 |  |  | 166 |  |  | 36.3 | % |  | 623 |  |  | 457 |  |  | 166 |  |  | 36.3 | % |

[0001327567-17-000007:mdna:72]
Cost of subscription and support revenue increased for the three and six months ended January 31, 2017 compared to the three and six months ended January 31, 2016. The increases in both periods were driven by increases in personnel costs, which grew $12.3 million to $39.7 million for the three months ended January 31, 2017 compared to the three months ended January 31, 2016 and grew $25.2 million to $74.3 million for the six months ended January 31, 2017 compared to the six months ended January 31, 2016. The increases in personnel costs in both periods were primarily due to headcount growth. The remaining increases in both periods were primarily due to expansion of our customer service capabilities and infrastructure to support our growing installed end-customer base.

[0001327567-17-000007:mdna:73]
[same as prior period, unchanged from 0001327567-16-000073:mdna:65]

[0001327567-17-000007:mdna:74]
Gross margin, or gross profit as a percentage of revenue, has been and will continue to be affected by a variety of factors, including the average sales price of our products, manufacturing costs, the introduction of new products, the mix of products sold, and the mix of revenue between product and subscription and support offerings. For sales of our products, our higher end firewall products generally have higher gross margins than our lower end firewall products within each product series. For sales of our subscription and support offerings, our subscription offerings typically have higher gross margins than our support offerings. We expect our gross margins to fluctuate over time depending on the factors described above.

[0001327567-17-000007:mdna:75]
|  | Three Months Ended January 31, |  | Six Months Ended January 31, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
|  | Amount |  | Gross Margin |  | Amount |  | Gross Margin |  | Amount |  | Gross Margin |  | Amount |  | Gross Margin |
|  | (dollars in millions) |
| Product | $ | 123.0 |  |  | 72.9 | % |  | $ | 125.0 |  |  | 73.5 | % |  | $ | 244.6 |  |  | 73.5 | % |  | $ | 233.9 |  |  | 73.6 | % |
| Subscription and support | 186.4 |  |  | 73.4 | % |  | 115.5 |  |  | 70.2 | % |  | 361.7 |  |  | 74.1 | % |  | 224.6 |  |  | 71.5 | % |
| Total gross profit | $ | 309.4 |  |  | 73.2 | % |  | $ | 240.5 |  |  | 71.9 | % |  | $ | 606.3 |  |  | 73.9 | % |  | $ | 458.5 |  |  | 72.6 | % |

[0001327567-17-000007:mdna:76]
Product gross margin decreased for the three and six months ended January 31, 2017 compared to the three and six months ended January 31, 2016. The decreases in both periods were driven by increases in personnel costs, which grew $1.1 million, or 20.5%, for the three months ended January 31, 2017 compared to the three months ended January 31, 2016 and grew $2.8 million, or 28.0%, for the six months ended January 31, 2017 compared to the six months ended January 31, 2016. The increases in personnel costs in both periods were primarily due to headcount growth.

[0001327567-17-000007:mdna:77]
Subscription and support gross margin increased for the three and six months ended January 31, 2017 compared to the three and six months ended January 31, 2016. The increases in both periods were due to contributions from our higher margin subscription offerings.

[0001327567-17-000007:mdna:78]
[same as prior period, unchanged from 0001327567-16-000073:mdna:70]

[0001327567-17-000007:mdna:79]
Our operating expenses consist of research and development, sales and marketing, and general and administrative expense. Personnel costs are the most significant component of operating expenses and consist of salaries, benefits, bonuses, share-based compensation, travel and entertainment, and with regard to sales and marketing expense, sales commissions. Our operating

[0001327567-17-000007:mdna:80]
[same as prior period, unchanged from 0001327567-16-000073:mdna:121]

[0001327567-17-000007:mdna:81]
expenses also include allocated costs, which consist of certain facilities, depreciation, benefits, recruiting, and information technology costs that we allocate based on headcount. We expect operating expenses to increase in absolute dollars and decrease over the long term as a percentage of revenue as we continue to scale our business. As of January 31, 2017, we expect to recognize approximately $989.7 million of share-based compensation expense over a weighted-average period of approximately 2.6 years, excluding additional share-based compensation expense related to any future grants of share-based awards. Share-based compensation expense is recognized on a straight-line basis over the requisite service periods of the awards.

[0001327567-17-000007:mdna:82]
[same as prior period, unchanged from 0001327567-16-000073:mdna:72]

[0001327567-17-000007:mdna:83]
[same as prior period, unchanged from 0001327567-16-000073:mdna:73]

[0001327567-17-000007:mdna:84]
|  | Three Months Ended January 31, |  |  |  |  |  | Six Months Ended January 31, |  |  |  |  |
|  | 2017 |  | 2016 |  | Change |  | 2017 |  | 2016 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Research and development | $ | 89.9 |  |  | $ | 74.0 |  |  | $ | 15.9 |  |  | 21.5 | % |  | $ | 174.1 |  |  | $ | 133.7 |  |  | $ | 40.4 |  |  | 30.2 | % |
| Number of employees at period end | 661 |  |  | 558 |  |  | 103 |  |  | 18.5 | % |  | 661 |  |  | 558 |  |  | 103 |  |  | 18.5 | % |

[0001327567-17-000007:mdna:85]
Research and development expense increased for the three and six months ended January 31, 2017 compared to the three and six months ended January 31, 2016. The increases in both periods were driven by increases in personnel costs, which grew $12.7 million to $75.6 million for the three months ended January 31, 2017 compared to the three months ended January 31, 2016 and grew $33.2 million to $145.9 million for the six months ended January 31, 2017 compared to the six months ended January 31, 2016. The increases in personnel costs in both periods were primarily due to headcount growth. The remaining increase for the six months ended January 31, 2017 compared to the six months ended January 31, 2016 includes $3.3 million of development costs related to investments in our future offerings.

[0001327567-17-000007:mdna:86]
[same as prior period, unchanged from 0001327567-16-000073:mdna:76]

[0001327567-17-000007:mdna:87]
[same as prior period, unchanged from 0001327567-16-000073:mdna:77]

[0001327567-17-000007:mdna:88]
|  | Three Months Ended January 31, |  |  |  |  |  | Six Months Ended January 31, |  |  |  |  |
|  | 2017 |  | 2016 |  | Change |  | 2017 |  | 2016 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Sales and marketing(1) | $ | 226.7 |  |  | $ | 182.4 |  |  | $ | 44.3 |  |  | 24.3 | % |  | $ | 446.8 |  |  | $ | 341.9 |  |  | $ | 104.9 |  |  | 30.7 | % |
| Number of employees at period end | 2,269 |  |  | 1,847 |  |  | 422 |  |  | 22.8 | % |  | 2,269 |  |  | 1,847 |  |  | 422 |  |  | 22.8 | % |

[0001327567-17-000007:mdna:89]
[same as prior period, unchanged from 0001327567-16-000073:mdna:90]

[0001327567-17-000007:mdna:90]
| (1) | Prior period amount has been adjusted as a result of our voluntary change in accounting policy for sales commissions. Refer to Note 1. Description of Business and Summary of Significant Accounting Policies in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information. |

[0001327567-17-000007:mdna:91]
Sales and marketing expense increased for the three and six months ended January 31, 2017 compared to the three and six months ended January 31, 2016. The increases in both periods were primarily driven by increases in personnel costs, which grew $39.8 million to $179.5 million for the three months ended January 31, 2017 compared to the three months ended January 31, 2016 and grew $88.7 million to $345.0 million for the six months ended January 31, 2017 compared to the six months ended January 31, 2016. The increases in personnel costs in both periods were primarily due to headcount growth. The remaining increases in both periods were primarily due to investments in demand generation activities and sales related events to support our revenue growth.

[0001327567-17-000007:mdna:92]
- 27 -

[0001327567-17-000007:mdna:93]
[same as prior period, unchanged from 0001327567-16-000073:mdna:83]

[0001327567-17-000007:mdna:94]
[same as prior period, unchanged from 0001327567-16-000073:mdna:84]

[0001327567-17-000007:mdna:95]
|  | Three Months Ended January 31, |  |  |  |  |  | Six Months Ended January 31, |  |  |  |  |
|  | 2017 |  | 2016 |  | Change |  | 2017 |  | 2016 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| General and administrative | $ | 47.2 |  |  | $ | 34.2 |  |  | $ | 13.0 |  |  | 38.0 | % |  | $ | 88.8 |  |  | $ | 65.0 |  |  | $ | 23.8 |  |  | 36.6 | % |
| Number of employees at period end | 492 |  |  | 399 |  |  | 93 |  |  | 23.3 | % |  | 492 |  |  | 399 |  |  | 93 |  |  | 23.3 | % |

[0001327567-17-000007:mdna:96]
General and administrative expense increased for the three and six months ended January 31, 2017 compared to the three and six months ended January 31, 2016. The increases in both periods were driven by increases in personnel costs, which grew $8.9 million to $34.3 million for the three months ended January 31, 2017 compared to the three months ended January 31, 2016 and grew $19.3 million to $65.4 million for the six months ended January 31, 2017 compared to the six months ended January 31, 2016. The increases in personnel costs in both periods were primarily due to headcount growth.

[0001327567-17-000007:mdna:97]
[same as prior period, unchanged from 0001327567-16-000073:mdna:87]

[0001327567-17-000007:mdna:98]
Provision for income taxes consists primarily of income taxes in foreign jurisdictions in which we conduct business, withholding taxes, and amortization of our deferred tax charges. We maintain a full valuation allowance for domestic deferred tax assets, including net operating loss carryforwards and tax credits.

[0001327567-17-000007:mdna:99]
|  | Three Months Ended January 31, |  | Change |  | Six Months Ended January 31, |  | Change |
|  | 2017 |  | 2016 |  | Amount |  | % |  | 2017 |  | 2016 |  | Amount |  | % |
|  | (dollars in millions) |
| Provision for income taxes | $ | 2.8 |  |  | $ | 3.9 |  |  | $ | (1.1 | ) |  | (28.2 | )% |  | $ | 7.2 |  |  | $ | 8.2 |  |  | $ | (1.0 | ) |  | (12.2 | )% |
| Effective tax rate(1) | (4.8 | )% |  | (7.3 | )% |  |  |  |  |  | (6.5 | )% |  | (9.2 | )% |  |  |  |  |

[0001327567-17-000007:mdna:100]
[same as prior period, unchanged from 0001327567-16-000073:mdna:97]

[0001327567-17-000007:mdna:101]
| (1) | Prior period effective tax rate has been adjusted as a result of our voluntary change in accounting policy for sales commissions. Refer to Note 1. Description of Business and Summary of Significant Accounting Policies in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information. |

[0001327567-17-000007:mdna:102]
We recorded an income tax provision for the three and six months ended January 31, 2017, due to foreign income taxes, withholding taxes, and amortization of our deferred tax charges. The provision for income taxes decreased for the three and six months ended January 31, 2017 compared to the three and six months ended January 31, 2016, primarily due to our early adoption of new share-based payment accounting guidance.

[0001327567-17-000007:mdna:103]
- 28 -

[0001327567-17-000007:mdna:104]
[same as prior period, unchanged from 0001327567-16-000073:mdna:95]

[0001327567-17-000007:mdna:105]
|  | January 31, 2017 |  | July 31, 2016 |
|  | (in millions) |
| Working capital(1) | $ | 886.8 |  |  | $ | 927.2 |  |
| Cash, cash equivalents, and investments: |  |  |  |
| Cash and cash equivalents | $ | 761.4 |  |  | $ | 734.4 |  |
| Investments | 1,383.5 |  |  | 1,204.0 |  |
| Total cash, cash equivalents, and investments | $ | 2,144.9 |  |  | $ | 1,938.4 |  |

[0001327567-17-000007:mdna:106]
______________

[0001327567-17-000007:mdna:107]
| (1) | Working capital as of July 31, 2016, has been adjusted as a result of our voluntary change in accounting policy for sales commissions. Refer to Note 1. Description of Business and Summary of Significant Accounting Policies in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information. |

[0001327567-17-000007:mdna:108]
At January 31, 2017, our total cash, cash equivalents, and investments of $2.1 billion were held for general corporate purposes, of which approximately $237.1 million was held outside of the United States. We do not provide for federal income taxes on the undistributed earnings of our foreign subsidiaries, all of which we expect to reinvest outside of the United States indefinitely. However, if these funds were needed for our domestic operations, we would be required to accrue and pay U.S. taxes on undistributed earnings of foreign subsidiaries. There are no other restrictions on the use of these funds. If we were to repatriate these earnings to the United States, any associated income tax liability would be insignificant.

[0001327567-17-000007:mdna:109]
As of January 31, 2017, all of our 0.0% Convertible Senior Notes due 2019 (the “Notes”) remained outstanding. The Notes mature on July 1, 2019, however, prior to January 1, 2019, holders may surrender their Notes for early conversion under certain circumstances. Upon conversion, we will pay cash equal to the aggregate principal amount of the Notes to be converted, and, at our election, will pay or deliver cash and/or shares of our common stock for the amount of our conversion obligation in excess of the aggregate principal amount of the Notes being converted. Refer to Note 5. Convertible Senior Notes in Part I, Item 1 of this Quarterly Report on Form 10-Q for information on the Notes.

[0001327567-17-000007:mdna:110]
In August 2016, our board of directors authorized a $500.0 million share repurchase which is funded from available working capital. Repurchases may be made at management’s discretion from time to time. The repurchase authorization will expire on August 31, 2018, and may be suspended or discontinued at any time. As of January 31, 2017, $329.9 million was available for future share repurchases under the repurchase authorization. Refer to Note 7. Stockholders’ Equity in Part I, Item 1 of this Quarterly Report on Form 10-Q for information on the repurchase authorization. In February 2017, our board of directors authorized a $500.0 million increase to our existing share repurchase program, bringing the total authorization to $1.0 billion, and extended the term of the repurchase authorization so that it will now expire on December 31, 2018. Refer to Note 11. Subsequent Events in Part I, Item 1 of this Quarterly Report on Form 10-Q for information on the increase to the repurchase authorization.

[0001327567-17-000007:mdna:111]
On February 27, 2017, we completed our acquisition of LightCyber Ltd., a privately-held cybersecurity company, in exchange for total consideration of approximately $105.0 million in cash. Refer to Note 11. Subsequent Events in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information.

[0001327567-17-000007:mdna:112]
The following table summarizes our cash flows for the six months ended January 31, 2017 and 2016.

[0001327567-17-000007:mdna:113]
|  | Six Months Ended January 31, |
| 2017 |  | 2016 |
|  | (in millions) |
| Net cash provided by operating activities(1) | $ | 417.8 |  |  | $ | 301.0 |  |
| Net cash used in investing activities | (244.3 | ) |  | (284.7 | ) |
| Net cash provided by (used in) financing activities(1) | (146.5 | ) |  | 21.1 |  |
| Net increase in cash and cash equivalents | $ | 27.0 |  |  | $ | 37.4 |  |

[0001327567-17-000007:mdna:114]
______________

[0001327567-17-000007:mdna:115]
| (1) | Amounts reflect adjustments as a result of our early adoption of new share-based payment accounting guidance. Refer to Note 1. Description of Business and Summary of Significant Accounting Policies in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information. |

[0001327567-17-000007:mdna:116]
- 29 -

[0001327567-17-000007:mdna:117]
[same as prior period, unchanged from 0001327567-16-000073:mdna:106]

[0001327567-17-000007:mdna:118]
[same as prior period, unchanged from 0001327567-16-000073:mdna:107]

[0001327567-17-000007:mdna:119]
[same as prior period, unchanged from 0001327567-16-000073:mdna:108]

[0001327567-17-000007:mdna:120]
Our operating activities have consisted of net losses adjusted for certain non-cash items and changes in assets and liabilities.

[0001327567-17-000007:mdna:121]
Cash provided by operating activities during the six months ended January 31, 2017 was $417.8 million, an increase of $116.8 million compared to the six months ended January 31, 2016. The increase was due to growth of our business and changes in our assets and liabilities during the six months ended January 31, 2017, which included an increase in sales of subscription and support contracts to new and existing customers as reflected by an increase in deferred revenue.

[0001327567-17-000007:mdna:122]
[same as prior period, unchanged from 0001327567-16-000073:mdna:111]

[0001327567-17-000007:mdna:123]
[same as prior period, unchanged from 0001327567-16-000073:mdna:112]

[0001327567-17-000007:mdna:124]
Cash used in investing activities during the six months ended January 31, 2017 was $244.3 million, a decrease of $40.4 million compared to the six months ended January 31, 2016, due to lower net purchases of available-for-sale investments, partially offset by increased investment in facilities to support the growth of our business.

[0001327567-17-000007:mdna:125]
[same as prior period, unchanged from 0001327567-16-000073:mdna:114]

[0001327567-17-000007:mdna:126]
Our financing activities have consisted of proceeds from sales of shares through employee equity incentive plans and cash used to repurchase shares of our common stock.

[0001327567-17-000007:mdna:127]
Cash used in financing activities during the six months ended January 31, 2017 was $146.5 million, a change of $167.6 million compared to the six months ended January 31, 2016, due to the repurchase of $170.1 million of our common stock during the six months ended January 31, 2017.

[0001327567-17-000007:mdna:128]
[same as prior period, unchanged from 0001327567-16-000073:mdna:117]

[0001327567-17-000007:mdna:129]
As of January 31, 2017, we did not have any relationships with unconsolidated organizations or financial partnerships, such as structured finance or special purpose entities that would have been established for the purpose of facilitating off-balance sheet arrangements or other contractually narrow or limited purposes.

[0001327567-17-000007:mdna:130]
[same as prior period, unchanged from 0001327567-16-000073:mdna:119]

[0001327567-17-000007:mdna:131]
[same as prior period, unchanged from 0001327567-16-000073:mdna:120]

[0001327567-17-000007:mdna:132]
We believe the critical accounting estimates discussed under Item 7, “Management’s Discussion and Analysis of Financial Condition and Results of Operations” in our Annual Report on Form 10-K filed with the SEC on September 8, 2016, reflect our more significant judgments and estimates used in the preparation of our condensed consolidated financial statements. There have been no significant changes to our critical accounting estimates as filed in such report, except for the change in our accounting policy for forfeitures of share-based compensation awards due to our early adoption of new accounting guidance. Refer to “Recent Accounting Pronouncements” in Note 1. Description of Business and Summary of Significant Accounting Policies in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information.

[0001327567-17-000007:mdna:133]
- 30 -

[0001327567-17-000007:mdna:134]
[same as prior period, unchanged from 0001327567-16-000073:mdna:123]

[0001327567-17-000007:mdna:135]
Refer to “Recent Accounting Pronouncements” in Note 1. Description of Business and Summary of Significant Accounting Policies in Part I, Item 1 of this Quarterly Report on Form 10-Q.
