# PANW 8-K — 0001327567-17-000005 filed 2017-02-28

## item codes, every 8-K on or before 2017-03-01

- 2017-02-28 0001327567-17-000005 — 2.02, 8.01, 9.01
- 2016-12-12 0001193125-16-790757 — 5.07
- 2016-11-21 0001327567-16-000071 — 2.02, 9.01
- 2016-10-24 0001193125-16-745121 — 5.02, 9.01
- 2016-08-30 0001327567-16-000057 — 2.02, 5.03, 8.01, 9.01
- 2016-08-22 0001193125-16-687588 — 5.02, 9.01
- 2016-05-26 0001327567-16-000051 — 2.02, 9.01
- 2016-02-25 0001327567-16-000044 — 2.02, 5.02, 9.01
- 2015-12-14 0001327567-15-000038 — 5.07
- 2015-12-14 0001193125-15-402588 — 1.01, 9.01
- 2015-11-23 0001327567-15-000033 — 2.02, 9.01
- 2015-10-19 0001193125-15-347005 — 1.01, 9.01 — amendment, the index does not say of what
- 2015-09-09 0001327567-15-000022 — 2.02, 9.01
- 2015-08-19 0001193125-15-296115 — 1.01, 2.03
- 2015-06-01 0001193125-15-207786 — 1.01, 2.03
- 2015-05-27 0001327567-15-000015 — 2.02, 9.01
- 2015-03-02 0001327567-15-000006 — 2.02, 9.01
- 2014-12-15 0001327567-14-000046 — 5.07
- 2014-11-24 0001327567-14-000040 — 2.02, 9.01
- 2014-09-22 0001193125-14-348581 — 5.02, 9.01
- 2014-09-09 0001327567-14-000025 — 2.02, 9.01
- 2014-07-01 0001193125-14-257824 — 1.01, 2.03, 3.02, 9.01
- 2014-06-26 0001193125-14-249529 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2014-06-20 0001327567-14-000020 — 9.01 — amendment of 0001193125-14-140511
- 2014-06-04 0001327567-14-000016 — 3.02
- 2014-05-30 0001193125-14-218158 — 2.02 — amendment, the index does not say of what
- 2014-05-28 0001193125-14-215060 — 1.01, 2.02, 3.02, 9.01
- 2014-04-11 0001193125-14-140511 — 2.01, 3.02, 7.01, 9.01
- 2014-03-24 0001193125-14-111318 — 1.01, 3.02, 7.01, 9.01
- 2014-03-13 0001327567-14-000009 — 5.02
- 2014-02-24 0001193125-14-063754 — 2.02, 9.01
- 2013-12-12 0001327567-13-000040 — 5.07
- 2013-11-25 0001327567-13-000033 — 2.02, 9.01
- 2013-09-30 0001193125-13-384966 — 8.01
- 2013-09-09 0001193125-13-361421 — 2.02, 9.01
- 2013-05-30 0001193125-13-241542 — 2.02, 5.02, 9.01
- 2013-03-11 0001193125-13-101082 — 5.02, 9.01
- 2013-02-28 0001193125-13-084193 — 2.02, 9.01
- 2012-12-14 0001193125-12-503335 — 5.07
- 2012-12-06 0001193125-12-493700 — 2.02, 9.01
- 2012-09-24 0001193125-12-401534 — 1.01, 2.03
- 2012-09-20 0001193125-12-398433 — 5.02, 9.01
- 2012-09-10 0001193125-12-386605 — 2.02, 9.01

## late-filing notifications on or before 2017-03-01

- none on or before 2017-03-01

## item 2.02 — earnings release, exhibit 99.1

[0001327567-17-000005:8k_2_02:1]
EX-99.1
2
ex991q217earningsrelease.htm
EXHIBIT 99.1

[0001327567-17-000005:8k_2_02:2]
Exhibit

[0001327567-17-000005:8k_2_02:3]
Exhibit 99.1

[0001327567-17-000005:8k_2_02:4]
Palo Alto Networks Reports Fiscal Second Quarter 2017 Financial Results

[0001327567-17-000005:8k_2_02:5]
| • | Revenue grows 26 percent year over year to $422.6 million |

[0001327567-17-000005:8k_2_02:6]
| • | Billings grow 22 percent year over year to $561.6 million |

[0001327567-17-000005:8k_2_02:7]
| • | Deferred revenue grows 61 percent year over year to $1.5 billion |

[0001327567-17-000005:8k_2_02:8]
| • | Cash flow from operations grows 39 percent year over year to $214.3 million, and free cash flow grows 24 percent year over year to $169.6 million |

[0001327567-17-000005:8k_2_02:9]
| • | Announces $500 million share repurchase increase bringing total repurchase authorization to $1 billion |

[0001327567-17-000005:8k_2_02:10]
SANTA CLARA, Calif. — February 28, 2017 — Palo Alto Networks® (NYSE: PANW), the next-generation security company, today announced financial results for its fiscal second quarter 2017 ended January 31, 2017.

[0001327567-17-000005:8k_2_02:11]
Total revenue for the fiscal second quarter 2017 grew 26 percent year over year to $422.6 million, compared with total revenue of $334.7 million for the fiscal second quarter 2016. GAAP net loss for the fiscal second quarter 2017 was $60.6 million, or $0.67 per diluted share, compared with GAAP net loss of $57.3 million, or $0.66 per diluted share, for the fiscal second quarter 2016.

[0001327567-17-000005:8k_2_02:12]
Non-GAAP net income for the fiscal second quarter 2017 was $59.6 million, or $0.63 per diluted share, compared with non-GAAP net income of $39.5 million, or $0.43 per diluted share, for the fiscal second quarter 2016. A reconciliation between GAAP and non-GAAP information is contained in the tables below.

[0001327567-17-000005:8k_2_02:13]
“While fiscal second quarter revenue of $423 million was yet another record for the company, we were disappointed that we came in below top-line expectations due to some execution challenges, which we are moving quickly to address,” said Mark McLaughlin, chief executive officer of Palo Alto Networks. “Our

[0001327567-17-000005:8k_2_02:14]
customers rely on us to solve their most difficult cybersecurity challenges, and we have yet again widened the technology gap between our Next-Generation Security Platform and the competition with the largest product and features launch in our history, including expansion of our virtual and cloud capabilities. We are also extending our capabilities in data analytics and machine learning with today’s announcement of our acquisition of LightCyber.”

[0001327567-17-000005:8k_2_02:15]
“Our hybrid-SaaS model drove cash flow from operations to a record $214.3 million and free cash flow to $169.6 million,” commented Steffan Tomlinson, chief financial officer of Palo Alto Networks. “We ended the quarter with approximately $2.1 billion in cash, cash equivalents and investments and are pleased to announce an incremental $500 million share repurchase authorization, bringing our total repurchase authorization to $1 billion.”

[0001327567-17-000005:8k_2_02:16]
Recent Highlights

[0001327567-17-000005:8k_2_02:17]
| • | Announced the biggest product and features launch in the history of Palo Alto Networks – More than 20,000 security professionals from more than 150 countries attended the online and in-person launch events to learn about the biggest highlights of the announcement, which included: |

[0001327567-17-000005:8k_2_02:18]
| ◦ | Six new hardware appliances designed to enable customers to deploy next-generation security from large data centers to small branches. The PA-5200 Series, PA-800 Series and PA-220 provide faster performance with deep visibility into and control over all traffic, including encrypted traffic, which is becoming an increasingly strategic necessity for effective security. |

[0001327567-17-000005:8k_2_02:19]
| ◦ | Three new VM-Series models add to the existing four we currently offer. With throughput ranging from 200 Mbps to 16 Gbps, we offer the broadest line of virtualized firewall appliances on the market. Improved integrations with Amazon® Web Services (AWS®), Microsoft® Azure® and VMware® NSX® enable a wider range of deployment scenarios and |

[0001327567-17-000005:8k_2_02:20]
2

[0001327567-17-000005:8k_2_02:21]
deliver the scale, redundancy and automation that customers require to build cloud-centric architectures.

[0001327567-17-000005:8k_2_02:22]
| ◦ | The industry’s first multi-method, scalable and automated approach designed to prevent credential-based theft and abuse by attackers, including a new policy-based multi-factor authentication capability at the network layer. |

[0001327567-17-000005:8k_2_02:23]
| ◦ | The introduction of both PAN-OS® and Panorama™ 8.0 with more than 70 new features. |

[0001327567-17-000005:8k_2_02:24]
| • | Announced the acquisition of LightCyber – This acquisition expands our Next-Generation Security Platform with the addition of the award-winning, highly automated behavioral analytics capabilities of LightCyber®, using sophisticated machine learning to quickly, efficiently and accurately identify attacks based on behavioral anomalies inside the network. We will continue to offer the LightCyber products and support existing customer implementations while we engineer the technology into our Next-Generation Security Platform, which we expect to complete by the end of the calendar year. At that time, we plan to offer it as a subscription that further enhances our platform’s automated threat prevention capabilities and the ability for customer organizations to prevent cyber breaches throughout the entire attack lifecycle. To learn more about LightCyber and how it enhances the Palo Alto Networks platform, visit www.paloaltonetworks.com. |

[0001327567-17-000005:8k_2_02:25]
| • | Honored for cloud and advanced endpoint product innovation – CRN®, a brand of The Channel Company, has named Palo Alto Networks to its 100 Coolest Cloud Computing Vendors of 2017 list, recognizing the most innovative cloud technology suppliers. CRN also recognized our Traps™ advanced endpoint protection offering by naming it the overall winner in the 2016 Product of the Year Awards in the Endpoint Security category. |

[0001327567-17-000005:8k_2_02:26]
| • | Achieved qualification in the Amazon Web Services Competency Program for Security – Our VM-Series achieved this Amazon qualification, reserved for very select partners, that demonstrates |

[0001327567-17-000005:8k_2_02:27]
3

[0001327567-17-000005:8k_2_02:28]
technical proficiency and proven customer success in the ability to enable organizations to deploy a comprehensive security architecture and a more seamless experience across their cloud and on-premise environments.

[0001327567-17-000005:8k_2_02:29]
| • | Recognized by J.D. Power and TSIA for exceptional support services – This includes certifications under the esteemed J.D. Power Certified Assisted Technical Support Program and TSIA “Rated Outstanding Worldwide” certification* for the second consecutive year, and underscores the exceptional customer support we offer our customers around the globe. |

[0001327567-17-000005:8k_2_02:30]
Financial Outlook

[0001327567-17-000005:8k_2_02:31]
Palo Alto Networks provides guidance based on current market conditions and expectations.

[0001327567-17-000005:8k_2_02:32]
For the fiscal third quarter 2017, we expect:

[0001327567-17-000005:8k_2_02:33]
| • | Total revenue in the range of $406 to $416 million, representing year-over-year growth between 17 percent and 20 percent. |

[0001327567-17-000005:8k_2_02:34]
| • | Diluted non-GAAP net income per share in the range of $0.54 to $0.56, including a $0.04 investment in LightCyber, using 93 to 95 million shares. |

[0001327567-17-000005:8k_2_02:35]
Guidance for non-GAAP financial measures excludes share-based compensation related charges including share-based payroll tax expense, acquisition related costs, amortization expense of acquired intangible assets, litigation-related charges including legal settlements, non-cash interest expense related to our convertible senior notes, foreign currency gains (losses) and income and other tax effects associated with

[0001327567-17-000005:8k_2_02:36]
___________

[0001327567-17-000005:8k_2_02:37]
* Palo Alto Networks has been recognized by J.D. Power for providing “An Outstanding Customer Service Experience” for its Assisted Technical Support.

[0001327567-17-000005:8k_2_02:38]
J.D. Power 2016 Certified Assisted Technical Support Program, developed in conjunction with TSIA. Based on successful completion of an audit and exceeding a customer satisfaction benchmark for assisted support operations. For more information, visit www.jdpower.com or www.tsia.com.

[0001327567-17-000005:8k_2_02:39]
these items, and certain non-recurring expenses. We have not reconciled diluted non-GAAP net income per share guidance to GAAP net income (loss) per diluted share because we do not provide guidance on GAAP net income (loss) and would not be able to present the various reconciling cash and non-cash items between GAAP net income (loss) and non-GAAP net income (loss), including share-based compensation expense, without unreasonable effort. Share-based compensation expense is impacted by the company’s future hiring and retention needs and, to a lesser extent, the future fair market value of the company’s common stock, all of which is difficult to predict and subject to constant change. While the actual amounts of such reconciling items will have a significant impact on the company’s GAAP net income (loss) per diluted share, a reconciliation of the non-GAAP financial measure guidance to the corresponding GAAP measure is not available without unreasonable effort.

[0001327567-17-000005:8k_2_02:40]
$500 Million Share Repurchase Increase Bringing Total Repurchase Authorization to $1 Billion

[0001327567-17-000005:8k_2_02:41]
On February 24, 2017, the board of directors authorized a $500 million increase to the existing share repurchase program, bringing the total authorization to $1 billion. As of January 31, 2017, $330 million remained available for repurchase under our initial $500 million authorization. This incremental authorization allows the company to repurchase its shares opportunistically and will be funded from available working capital. Repurchases may be made at management’s discretion from time to time on the open market, through privately negotiated transactions, transactions structured through investment banking institutions, block purchase techniques, 10b5-1 trading plans, or a combination of the foregoing. The repurchase authorization has been extended and will expire on December 31, 2018, and may be suspended or discontinued at any time. The company had approximately 92.0 million shares of common stock outstanding as of January 31, 2017.

[0001327567-17-000005:8k_2_02:42]
5

[0001327567-17-000005:8k_2_02:43]
Conference Call Information

[0001327567-17-000005:8k_2_02:44]
Palo Alto Networks will host a conference call for analysts and investors to discuss its fiscal second quarter 2017 results and outlook for its fiscal third quarter 2017 today at 4:30 p.m. Eastern time/1:30 p.m. Pacific time. Open to the public, investors may access the call by dialing 1-888-430-8690 or 1-719-325-2356 and using conference ID 3525187. A live audio webcast of the conference call, along with supplemental financial information, will also be accessible from the “Investors” section of our website at investors.paloaltonetworks.com. Following the webcast, an archived version will be available on our website for one year. A telephonic replay of the call will be available three hours after the call, will run for ten days, and may be accessed by dialing 1-888-203-1112 or 1-719-457-0820 and entering the passcode 3525187.

[0001327567-17-000005:8k_2_02:45]
Forward-Looking Statements

[0001327567-17-000005:8k_2_02:46]
This press release contains forward-looking statements that involve risks and uncertainties, including statements regarding our future financial and operating performance, including our financial outlook for the fiscal third quarter 2017, our efforts to quickly address execution challenges, our intention to opportunistically repurchase shares of our common stock under our share repurchase program, and our plans, expectations and intentions with respect to the products and technologies that we acquired from LightCyber. There are a significant number of factors that could cause actual results to differ materially from statements made in this press release, including: our limited operating history; the possibility that share repurchases may be suspended or discontinued; our ability to identify and effectively implement the necessary changes to address our execution challenges; fluctuations in the trading volume and market price of shares of our common stock; competing future investment opportunities and alternative uses of cash; risks associated with managing our rapid growth; our limited experience with new product and subscription and support introductions and the risks associated with new products and subscription and support offerings, including the discovery of software bugs; the failure to timely develop and achieve market acceptance of new products and subscriptions as well as existing products and subscription and

[0001327567-17-000005:8k_2_02:47]
support; our ability as an organization to acquire and integrate other companies, products, or technologies in a successful manner; rapidly evolving technological developments in the market for network security products and subscription and support offerings; length of sales cycles; and general market, political, economic and business conditions.

[0001327567-17-000005:8k_2_02:48]
Additional risks and uncertainties that could affect our financial results are included under the captions “Risk Factors” and “Management’s Discussion and Analysis of Financial Condition and Results of Operations” in our Quarterly Report on Form 10-Q filed with the SEC on November 22, 2016, which is available on our website at investors.paloaltonetworks.com and on the SEC’s website at www.sec.gov. Additional information will also be set forth in other filings that we make with the SEC from time to time. All forward-looking statements in this press release are based on information available to us as of the date hereof, and we do not assume any obligation to update the forward-looking statements provided to reflect events that occur or circumstances that exist after the date on which they were made.

[0001327567-17-000005:8k_2_02:49]
Non-GAAP Financial Measures and Other Key Metrics

[0001327567-17-000005:8k_2_02:50]
Palo Alto Networks has provided in this press release financial information that has not been prepared in accordance with generally accepted accounting principles in the United States (GAAP). The company uses these non-GAAP financial measures and key metrics internally in analyzing its financial results and believes that the use of these non-GAAP financial measures and key metrics is useful to investors as an additional tool to evaluate ongoing operating results and trends and in comparing the company’s financial results with other companies in its industry, many of which present similar non-GAAP financial measures or key metrics.

[0001327567-17-000005:8k_2_02:51]
The presentation of these non-GAAP financial measures and key metrics are not meant to be considered in isolation or as a substitute for comparable GAAP financial measures, and should be read only in conjunction with the company’s consolidated financial statements prepared in accordance with GAAP. A

[0001327567-17-000005:8k_2_02:52]
7

[0001327567-17-000005:8k_2_02:53]
reconciliation of the company’s historical non-GAAP financial measures and key metrics to their most directly comparable GAAP measures has been provided in the financial statement tables included in this press release, and investors are encouraged to review these reconciliations.

[0001327567-17-000005:8k_2_02:54]
Non-GAAP net income and net income per share, diluted. Palo Alto Networks defines non-GAAP net income as net income (loss) plus share-based compensation related charges including share-based payroll tax expense, acquisition related costs, amortization expense of acquired intangible assets, litigation related charges including legal settlements, non-cash interest expense related to the company’s convertible senior notes, and intellectual property restructuring related charges. The company also excludes from non-GAAP net income the foreign currency gains (losses) and tax effects associated with these items in order to provide a complete picture of the company’s recurring core business operating results. The company defines non-GAAP net income per share, diluted, as non-GAAP net income divided by the weighted average diluted shares outstanding, which includes the potentially dilutive effect of the company’s employee equity incentive plan awards and the company’s convertible senior notes outstanding, after giving effect to the anti-dilutive impact of the company’s note hedge agreements, which reduces the potential economic dilution that otherwise would occur upon conversion of the company’s convertible senior notes. Under GAAP, the anti-dilutive impact of the note hedge is not reflected in diluted shares outstanding. The company believes that excluding these items from non-GAAP net income and non-GAAP net income per share, diluted, provides management and investors with greater visibility into the underlying performance of the company’s core business operating results, meaning its operating performance excluding these items and, from time to time, other discrete charges that are infrequent in nature, over multiple periods.

[0001327567-17-000005:8k_2_02:55]
Billings. Palo Alto Networks defines billings as total revenue plus the change in total deferred revenue during the period. The company considers billings to be a key metric used by management to manage the company’s business given the company’s hybrid-SaaS revenue model, and believes billings provides

[0001327567-17-000005:8k_2_02:56]
investors with an important indicator of the health and visibility of the company’s business because it includes subscription and support revenue, which is recognized ratably over the contractual service period, and product revenue, which is recognized at the time of shipment, provided that all other revenue recognition criteria have been met. The company considers billings to be a useful metric for management and investors, particularly if sales of subscriptions continue to increase and the company experiences strong renewal rates for subscription and support.

[0001327567-17-000005:8k_2_02:57]
Free cash flow. Palo Alto Networks defines free cash flow as cash provided by operating activities less purchases of property, equipment, and other assets. The company considers free cash flow to be a profitability and liquidity measure that provides useful information to management and investors about the amount of cash generated by the business after necessary capital expenditures.

[0001327567-17-000005:8k_2_02:58]
Investors are cautioned that there are a number of limitations associated with the use of non-GAAP financial measures and key metrics as analytical tools. In particular, the billings metric reported by the company includes amounts that have not yet been recognized as revenue and free cash flow does not represent the total increase or decrease in our cash balance for the period. In addition, many of the adjustments to the company’s GAAP financial measures reflect the exclusion of items that are recurring and will be reflected in the company’s financial results for the foreseeable future, such as share-based compensation, which is an important part of Palo Alto Networks employees’ compensation and impacts their performance. Furthermore, these non-GAAP financial measures are not based on any standardized methodology prescribed by GAAP, and the components that Palo Alto Networks excludes in its calculation of non-GAAP financial measures may differ from the components that its peer companies exclude when they report their non-GAAP results of operations. Palo Alto Networks compensates for these limitations by providing specific information regarding the GAAP amounts excluded from these non-GAAP financial measures. In the future, the company may also exclude non-recurring expenses and other expenses that do not reflect the company’s core business operating results.

[0001327567-17-000005:8k_2_02:59]
9

[0001327567-17-000005:8k_2_02:60]
About Palo Alto Networks

[0001327567-17-000005:8k_2_02:61]
Palo Alto Networks is the next-generation security company, leading a new era in cybersecurity by safely enabling applications and preventing cyber breaches for tens of thousands of organizations worldwide. Built with an innovative approach and highly differentiated cyberthreat prevention capabilities, our game-changing security platform delivers security far superior to legacy or point products, safely enables daily business operations, and protects an organization’s most valuable assets. Find out more at www.paloaltonetworks.com.

[0001327567-17-000005:8k_2_02:62]
Palo Alto Networks and the Palo Alto Networks logo are trademarks of Palo Alto Networks, Inc. in the United States and in jurisdictions throughout the world. All other trademarks, trade names or service marks used or mentioned herein belong to their respective owners.

[0001327567-17-000005:8k_2_02:63]
Media Contact:

[0001327567-17-000005:8k_2_02:64]
Jennifer Jasper Smith

[0001327567-17-000005:8k_2_02:65]
Head of Corporate Communications

[0001327567-17-000005:8k_2_02:66]
Palo Alto Networks

[0001327567-17-000005:8k_2_02:67]
408-638-3280

[0001327567-17-000005:8k_2_02:68]
jjsmith@paloaltonetworks.com

[0001327567-17-000005:8k_2_02:69]
Investor Relations Contact:

[0001327567-17-000005:8k_2_02:70]
Kelsey Turcotte

[0001327567-17-000005:8k_2_02:71]
Vice President of Investor Relations

[0001327567-17-000005:8k_2_02:72]
Palo Alto Networks

[0001327567-17-000005:8k_2_02:73]
408-753-3872

[0001327567-17-000005:8k_2_02:74]
kturcotte@paloaltonetworks.com

[0001327567-17-000005:8k_2_02:75]
| Palo Alto Networks, Inc. |
| Preliminary Condensed Consolidated Statements of Operations |
| (In millions, except per share data) |
| (Unaudited) |
|  | Three Months Ended January 31, |  | Six Months Ended January 31, |
|  | 2017(2) |  | 2016 |  | 2017(2) |  | 2016 |
|  |  |  | (As Adjusted)(1) |  |  |  | (As Adjusted)(1) |
| Revenue: |  |  |  |  |  |  |  |
| Product | $ | 168.8 |  |  | $ | 169.9 |  |  | $ | 332.6 |  |  | $ | 317.6 |  |
| Subscription and support | 253.8 |  |  | 164.8 |  |  | 488.1 |  |  | 314.3 |  |
| Total revenue | 422.6 |  |  | 334.7 |  |  | 820.7 |  |  | 631.9 |  |
| Cost of revenue: |  |  |  |  |  |  |  |
| Product | 45.8 |  |  | 44.9 |  |  | 88.0 |  |  | 83.7 |  |
| Subscription and support | 67.4 |  |  | 49.3 |  |  | 126.4 |  |  | 89.7 |  |
| Total cost of revenue | 113.2 |  |  | 94.2 |  |  | 214.4 |  |  | 173.4 |  |
| Total gross profit | 309.4 |  |  | 240.5 |  |  | 606.3 |  |  | 458.5 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 89.9 |  |  | 74.0 |  |  | 174.1 |  |  | 133.7 |  |
| Sales and marketing | 226.7 |  |  | 182.4 |  |  | 446.8 |  |  | 341.9 |  |
| General and administrative | 47.2 |  |  | 34.2 |  |  | 88.8 |  |  | 65.0 |  |
| Total operating expenses | 363.8 |  |  | 290.6 |  |  | 709.7 |  |  | 540.6 |  |
| Operating loss | (54.4 | ) |  | (50.1 | ) |  | (103.4 | ) |  | (82.1 | ) |
| Interest expense | (6.1 | ) |  | (5.8 | ) |  | (12.1 | ) |  | (11.6 | ) |
| Other income, net | 2.7 |  |  | 2.5 |  |  | 5.2 |  |  | 4.7 |  |
| Loss before income taxes | (57.8 | ) |  | (53.4 | ) |  | (110.3 | ) |  | (89.0 | ) |
| Provision for income taxes | 2.8 |  |  | 3.9 |  |  | 7.2 |  |  | 8.2 |  |
| Net loss | $ | (60.6 | ) |  | $ | (57.3 | ) |  | $ | (117.5 | ) |  | $ | (97.2 | ) |
| Net loss per share, basic and diluted | $ | (0.67 | ) |  | $ | (0.66 | ) |  | $ | (1.30 | ) |  | $ | (1.13 | ) |
| Weighted-average shares used to compute net loss per share, basic and diluted | 90.7 |  |  | 86.6 |  |  | 90.2 |  |  | 85.8 |  |

[0001327567-17-000005:8k_2_02:76]
___________

[0001327567-17-000005:8k_2_02:77]
| (1) | Certain amounts have been adjusted as a result of the Company’s change in accounting policy for sales commissions. Refer to Appendix A for more information. |

[0001327567-17-000005:8k_2_02:78]
| (2) | The Company early adopted new share-based payment accounting guidance in its second quarter of fiscal 2017, which simplified, among other things, the accounting for income tax consequences and the method of accounting for forfeitures of share-based payment awards. As a result of the early adoption, the Company’s share-based compensation and provision for income taxes decreased by $0.9 million and $4.0 million, respectively, for the three months ended October 31, 2016. These adjustments are reflected in the results for the six months ended January 31, 2017. |

[0001327567-17-000005:8k_2_02:79]
11

[0001327567-17-000005:8k_2_02:80]
| Palo Alto Networks, Inc. |
| Reconciliation of GAAP to Non-GAAP Financial Measures |
| (In millions, except per share amounts) |
| (Unaudited) |
|  | Three Months Ended |  | Six Months Ended |
|  | January 31, |  | January 31, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
|  |  |  | (As Adjusted)(1) |  |  |  | (As Adjusted)(1) |
| GAAP net loss | $ | (60.6 | ) |  | $ | (57.3 | ) |  | $ | (117.5 | ) |  | $ | (97.2 | ) |
| Share-based compensation related charges | 131.8 |  |  | 106.9 |  |  | 247.4 |  |  | 182.1 |  |
| Acquisition related costs | 0.7 |  |  | — |  |  | 0.7 |  |  | — |  |
| Amortization expense of acquired intangible assets | 2.0 |  |  | 2.1 |  |  | 4.1 |  |  | 4.2 |  |
| Litigation related charges | 3.0 |  |  | 3.0 |  |  | 6.1 |  |  | 6.1 |  |
| Non-cash interest expense related to convertible notes | 6.1 |  |  | 5.7 |  |  | 12.1 |  |  | 11.5 |  |
| Foreign currency (gain) loss associated with non-GAAP adjustments | 0.6 |  |  | (0.7 | ) |  | 0.4 |  |  | (1.5 | ) |
| Income tax and other tax adjustments related to the above | (24.0 | ) |  | (20.2 | ) |  | (42.5 | ) |  | (34.9 | ) |
| Non-GAAP net income | $ | 59.6 |  |  | $ | 39.5 |  |  | $ | 110.8 |  |  | $ | 70.3 |  |
| GAAP net loss per share, diluted | $ | (0.67 | ) |  | $ | (0.66 | ) |  | $ | (1.30 | ) |  | $ | (1.13 | ) |
| Share-based compensation related charges | 1.42 |  |  | 1.21 |  |  | 2.69 |  |  | 2.08 |  |
| Acquisition related costs | 0.01 |  |  | 0.00 |  |  | 0.01 |  |  | 0.00 |  |
| Amortization expense of acquired intangible assets | 0.02 |  |  | 0.02 |  |  | 0.05 |  |  | 0.05 |  |
| Litigation related charges | 0.03 |  |  | 0.04 |  |  | 0.07 |  |  | 0.07 |  |
| Non-cash interest expense related to convertible notes | 0.07 |  |  | 0.07 |  |  | 0.13 |  |  | 0.13 |  |
| Foreign currency (gain) loss associated with non-GAAP adjustments | 0.01 |  |  | (0.01 | ) |  | 0.00 |  |  | (0.02 | ) |
| Income tax and other tax adjustments related to the above | (0.26 | ) |  | (0.24 | ) |  | (0.47 | ) |  | (0.41 | ) |
| Non-GAAP net income per share, diluted | $ | 0.63 |  |  | $ | 0.43 |  |  | $ | 1.18 |  |  | $ | 0.77 |  |
| GAAP weighted-average shares used to compute net loss per share, diluted | 90.7 |  |  | 86.6 |  |  | 90.2 |  |  | 85.8 |  |
| Weighted-average effect of potentially dilutive securities(2) | 3.2 |  |  | 5.1 |  |  | 3.6 |  |  | 5.4 |  |
| Non-GAAP weighted-average shares used to compute net income per share, diluted | 93.9 |  |  | 91.7 |  |  | 93.8 |  |  | 91.2 |  |
| Net cash provided by operating activities | $ | 214.3 |  |  | $ | 154.1 |  |  | $ | 417.8 |  |  | $ | 301.0 |  |
| Less: purchases of property, equipment, and other assets | 44.7 |  |  | 17.4 |  |  | 65.6 |  |  | 36.9 |  |
| Free cash flow (non-GAAP) | $ | 169.6 |  |  | $ | 136.7 |  |  | $ | 352.2 |  |  | $ | 264.1 |  |
| Net cash used in investing activities | $ | (173.1 | ) |  | $ | (21.2 | ) |  | $ | (244.3 | ) |  | $ | (284.7 | ) |
| Net cash provided by (used in) financing activities | $ | (119.2 | ) |  | $ | 4.5 |  |  | $ | (146.5 | ) |  | $ | 21.1 |  |

[0001327567-17-000005:8k_2_02:81]
___________

[0001327567-17-000005:8k_2_02:82]
| (1) | Certain amounts have been adjusted as a result of the Company’s change in accounting policy for sales commissions. Refer to Appendix A for more information. |

[0001327567-17-000005:8k_2_02:83]
| (2) | Non-GAAP net income per share, diluted, includes the potentially dilutive effect of employee equity incentive plan awards and convertible senior notes outstanding. In addition, non-GAAP net income per share, diluted, includes the anti-dilutive impact of the Company’s note hedge agreements, which reduced the potentially dilutive effect of the convertible notes by 0.9 million shares and 1.2 million shares for the three and six months ended January 31, 2017, respectively, and 1.7 million shares and 1.8 million shares for the three and six months ended January 31, 2016, respectively. |

[0001327567-17-000005:8k_2_02:84]
12

[0001327567-17-000005:8k_2_02:85]
| Palo Alto Networks, Inc. |
| Calculation of Billings |
| (In millions) |
| (Unaudited) |
|  | Three Months Ended January 31, |  | Six Months Ended January 31, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Total revenue | $ | 422.6 |  |  | $ | 334.7 |  |  | $ | 820.7 |  |  | $ | 631.9 |  |
| Add: change in total deferred revenue | 139.0 |  |  | 124.3 |  |  | 257.8 |  |  | 215.1 |  |
| Billings | $ | 561.6 |  |  | $ | 459.0 |  |  | $ | 1,078.5 |  |  | $ | 847.0 |  |

[0001327567-17-000005:8k_2_02:86]
13

[0001327567-17-000005:8k_2_02:87]
| Palo Alto Networks, Inc. |
| Preliminary Condensed Consolidated Balance Sheets |
| (In millions) |
| (Unaudited) |
|  | January 31, 2017 |  | July 31, 2016 |
|  |  |  | (As Adjusted)(1) |
| Assets |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 761.4 |  |  | $ | 734.4 |  |
| Short-term investments | 593.0 |  |  | 551.2 |  |
| Accounts receivable, net | 386.1 |  |  | 348.7 |  |
| Prepaid expenses and other current assets | 139.9 |  |  | 139.7 |  |
| Total current assets | 1,880.4 |  |  | 1,774.0 |  |
| Property and equipment, net | 154.1 |  |  | 117.2 |  |
| Long-term investments | 790.5 |  |  | 652.8 |  |
| Goodwill | 163.5 |  |  | 163.5 |  |
| Intangible assets, net | 39.5 |  |  | 44.0 |  |
| Other assets | 146.6 |  |  | 106.7 |  |
| Total assets | $ | 3,174.6 |  |  | $ | 2,858.2 |  |
| Liabilities and stockholders’ equity |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 28.0 |  |  | $ | 30.2 |  |
| Accrued compensation | 78.8 |  |  | 73.5 |  |
| Accrued and other liabilities | 58.8 |  |  | 39.2 |  |
| Deferred revenue | 828.0 |  |  | 703.9 |  |
| Total current liabilities | 993.6 |  |  | 846.8 |  |
| Convertible senior notes, net | 512.3 |  |  | 500.2 |  |
| Long-term deferred revenue | 670.6 |  |  | 536.9 |  |
| Other long-term liabilities | 127.5 |  |  | 79.4 |  |
| Stockholders’ equity: |  |  |  |
| Preferred stock | — |  |  | — |  |
| Common stock and additional paid-in capital | 1,613.3 |  |  | 1,515.5 |  |
| Accumulated other comprehensive income (loss) | (5.1 | ) |  | 1.0 |  |
| Accumulated deficit | (737.6 | ) |  | (621.6 | ) |
| Total stockholders’ equity | 870.6 |  |  | 894.9 |  |
| Total liabilities and stockholders’ equity | $ | 3,174.6 |  |  | $ | 2,858.2 |  |

[0001327567-17-000005:8k_2_02:88]
___________

[0001327567-17-000005:8k_2_02:89]
| (1) | Certain amounts have been adjusted as a result of the Company’s change in accounting policy for sales commissions. Refer to Appendix A for more information. |

[0001327567-17-000005:8k_2_02:90]
14

[0001327567-17-000005:8k_2_02:91]
| Palo Alto Networks, Inc. |
| Preliminary Condensed Consolidated Statements of Cash Flows |
| (In millions) |
| (Unaudited) |
|  | Six Months Ended January 31, |
|  | 2017 |  | 2016 |
|  |  |  | (As Adjusted)(1) |
| Cash flows from operating activities |  |  |  |
| Net loss | $ | (117.5 | ) |  | $ | (97.2 | ) |
| Adjustments to reconcile net loss to net cash provided by operating activities: |  |  |  |
| Share-based compensation for equity based awards | 240.6 |  |  | 174.8 |  |
| Depreciation and amortization | 28.0 |  |  | 19.5 |  |
| Amortization of investment premiums, net of accretion of purchase discounts | 1.4 |  |  | 1.6 |  |
| Amortization of debt discount and debt issuance costs | 12.1 |  |  | 11.5 |  |
| Changes in operating assets and liabilities: |  |  |  |
| Accounts receivable, net | (37.3 | ) |  | (42.0 | ) |
| Prepaid expenses and other assets | (41.6 | ) |  | (12.9 | ) |
| Accounts payable | 0.2 |  |  | 13.6 |  |
| Accrued compensation | 5.3 |  |  | (8.6 | ) |
| Accrued and other liabilities | 68.8 |  |  | 25.6 |  |
| Deferred revenue | 257.8 |  |  | 215.1 |  |
| Net cash provided by operating activities(2) | 417.8 |  |  | 301.0 |  |
| Cash flows from investing activities |  |  |  |
| Purchases of investments | (562.7 | ) |  | (610.2 | ) |
| Proceeds from sales of investments | — |  |  | 134.4 |  |
| Proceeds from maturities of investments | 384.0 |  |  | 228.0 |  |
| Purchases of property, equipment, and other assets | (65.6 | ) |  | (36.9 | ) |
| Net cash used in investing activities | (244.3 | ) |  | (284.7 | ) |
| Cash flows from financing activities |  |  |  |
| Repurchases of common stock | (170.1 | ) |  | — |  |
| Proceeds from sales of shares through employee equity incentive plans | 23.6 |  |  | 21.1 |  |
| Net cash provided by (used in) financing activities(2) | (146.5 | ) |  | 21.1 |  |
| Net increase in cash and cash equivalents | 27.0 |  |  | 37.4 |  |
| Cash and cash equivalents - beginning of period | 734.4 |  |  | 375.8 |  |
| Cash and cash equivalents - end of period | $ | 761.4 |  |  | $ | 413.2 |  |

[0001327567-17-000005:8k_2_02:92]
___________

[0001327567-17-000005:8k_2_02:93]
| (1) | Certain amounts have been adjusted as a result of the Company’s change in accounting policy for sales commissions. Refer to Appendix A for more information. |

[0001327567-17-000005:8k_2_02:94]
| (2) | The Company early adopted new share-based payment accounting guidance in its second quarter of fiscal 2017, which simplified, among other things, the presentation of excess tax benefits in the statement of cash flows. The Company adopted this portion of the guidance on a retrospective basis, which increased net cash provided by operating activities by $0.5 million for the six months ended January 31, 2016, with a corresponding decrease to net cash provided by financing activities. |

[0001327567-17-000005:8k_2_02:95]
15

[0001327567-17-000005:8k_2_02:96]
Palo Alto Networks, Inc.

[0001327567-17-000005:8k_2_02:97]
Appendix A

[0001327567-17-000005:8k_2_02:98]
Change in Accounting Policy

[0001327567-17-000005:8k_2_02:99]
(Unaudited)

[0001327567-17-000005:8k_2_02:100]
Effective August 1, 2016, the Company voluntarily changed its accounting policy for sales commissions that are incremental and directly related to non-cancelable customer sales contracts from recording an expense when incurred to deferral and amortization of the sales commissions over the term of the related contract in proportion to the recognized revenue. The adoption of this accounting policy change has been applied retrospectively to all prior periods presented in this document, in which the cumulative effect of the change has been reflected as of the beginning of the earliest period presented.

[0001327567-17-000005:8k_2_02:101]
The following tables present the changes to financial statement line items as a result of the accounting change for the periods presented in the Company’s preliminary condensed consolidated financial statements (in millions, except per share data):

[0001327567-17-000005:8k_2_02:102]
|  | January 31, 2017 |  | July 31, 2016 |
|  | Computed under Prior Method |  | Impact of Commission Adjustment |  | As Reported |  | As Previously Reported |  | Impact of Commission Adjustment |  | As Adjusted |
| Preliminary Condensed Consolidated Balance Sheets |  |  |  |  |  |  |  |  |  |  |  |
| Prepaid expenses and other current assets | $ | 83.2 |  |  | $ | 56.7 |  |  | $ | 139.9 |  |  | $ | 84.8 |  |  | $ | 54.9 |  |  | $ | 139.7 |  |
| Other assets | 94.8 |  |  | 51.8 |  |  | 146.6 |  |  | 64.6 |  |  | 50.1 |  |  | 114.7 |  |
| Accumulated deficit | $ | (846.1 | ) |  | $ | 108.5 |  |  | $ | (737.6 | ) |  | $ | (726.6 | ) |  | $ | 105.0 |  |  | $ | (621.6 | ) |

[0001327567-17-000005:8k_2_02:103]
|  | Three Months Ended January 31, 2017 |  | Three Months Ended January 31, 2016 |
|  | Computed under Prior Method |  | Impact of Commission Adjustment |  | As Reported |  | As Previously Reported |  | Impact of Commission Adjustment |  | As Adjusted |
| Preliminary Condensed Consolidated Statements of Operations |  |  |  |  |  |  |  |  |  |  |  |
| Sales and marketing | $ | 232.7 |  |  | $ | (6.0 | ) |  | $ | 226.7 |  |  | $ | 187.6 |  |  | $ | (5.2 | ) |  | $ | 182.4 |  |
| Operating loss | (60.4 | ) |  | 6.0 |  |  | (54.4 | ) |  | (55.3 | ) |  | 5.2 |  |  | (50.1 | ) |
| Provision for income taxes | 2.8 |  |  | — |  |  | 2.8 |  |  | 3.9 |  |  | — |  |  | 3.9 |  |
| Net loss | $ | (66.6 | ) |  | $ | 6.0 |  |  | $ | (60.6 | ) |  | $ | (62.5 | ) |  | $ | 5.2 |  |  | $ | (57.3 | ) |
| Net loss per share, basic and diluted | $ | (0.73 | ) |  | $ | 0.06 |  |  | $ | (0.67 | ) |  | $ | (0.72 | ) |  | $ | 0.06 |  |  | $ | (0.66 | ) |
| Weighted-average shares used to compute net loss per share, basic and diluted | 90.7 |  |  | — |  |  | 90.7 |  |  | 86.6 |  |  | — |  |  | 86.6 |  |

[0001327567-17-000005:8k_2_02:104]
|  | Six Months Ended January 31, 2017 |  | Six Months Ended January 31, 2016 |
|  | Computed under Prior Method |  | Impact of Commission Adjustment |  | As Reported |  | As Previously Reported |  | Impact of Commission Adjustment |  | As Adjusted |
| Preliminary Condensed Consolidated Statements of Operations |  |  |  |  |  |  |  |  |  |  |  |
| Sales and marketing | $ | 450.2 |  |  | $ | (3.4 | ) |  | $ | 446.8 |  |  | $ | 345.9 |  |  | $ | (4.0 | ) |  | $ | 341.9 |  |
| Operating loss | (106.8 | ) |  | 3.4 |  |  | (103.4 | ) |  | (86.1 | ) |  | 4.0 |  |  | (82.1 | ) |
| Provision for income taxes | 7.3 |  |  | (0.1 | ) |  | 7.2 |  |  | 8.2 |  |  | — |  |  | 8.2 |  |
| Net loss | $ | (121.0 | ) |  | $ | 3.5 |  |  | $ | (117.5 | ) |  | $ | (101.2 | ) |  | $ | 4.0 |  |  | $ | (97.2 | ) |
| Net loss per share, basic and diluted | $ | (1.34 | ) |  | $ | 0.04 |  |  | $ | (1.30 | ) |  | $ | (1.18 | ) |  | $ | 0.05 |  |  | $ | (1.13 | ) |
| Weighted-average shares used to compute net loss per share, basic and diluted | 90.2 |  |  | — |  |  | 90.2 |  |  | 85.8 |  |  | — |  |  | 85.8 |  |

[0001327567-17-000005:8k_2_02:105]
This change in accounting policy does not affect the Company’s balance of cash and cash equivalents and, as a result, did not change net cash flows from operating, investing, or financing activities or materially impact any individual line items in the Company’s preliminary condensed consolidated statement of cash flows for the six months ended January 31, 2016.

[0001327567-17-000005:8k_2_02:106]
16
