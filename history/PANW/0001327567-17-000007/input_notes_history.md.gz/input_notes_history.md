# PANW note change history — 0001327567-16-000073 → 0001327567-17-000007


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2017-03-01):
[0001327567-17-000007:note_history:1]
The following table presents details of the aggregate future non-cancelable minimum rental payments under our operating leases as of January 31, 2017 (in millions):
  (was, 2016-11-22, similarity 0.9623):
[0001327567-16-000073:note_history:1]
The following table presents details of the aggregate future non-cancelable minimum rental payments under our operating leases as of October 31, 2016 (in millions):

- changed (2017-03-01):
[0001327567-17-000007:note_history:2]
Our independent contract manufacturer procures components and assembles our products based on our forecasts. These forecasts are based on estimates of demand for our products primarily for the next 12 months, which are in turn based on historical trends and an analysis from our sales and product marketing organizations, adjusted for overall market conditions. In order to reduce manufacturing lead times and plan for adequate supply, we may issue forecasts and orders for components and products that are non-cancelable. As of January 31, 2017, our purchase commitments under such orders were $77.6 million, excluding obligations under contracts that we can cancel without a significant penalty.
  (was, 2016-11-22, similarity 0.9898):
[0001327567-16-000073:note_history:2]
Our independent contract manufacturer procures components and assembles our products based on our forecasts. These forecasts are based on estimates of demand for our products primarily for the next 12 months, which are in turn based on historical trends and an analysis from our sales and product marketing organizations, adjusted for overall market conditions. In order to reduce manufacturing lead times and plan for adequate supply, we may issue forecasts and orders for components and products that are non-cancelable. As of October 31, 2016, our purchase commitments under such orders were $63.9 million, excluding obligations under contracts that we can cancel without a significant penalty.

- changed (2017-03-01):
[0001327567-17-000007:note_history:3]
To the extent there is a reasonable possibility that a loss exceeding amounts already recognized may be incurred and the amount of such additional loss would be material, we will either disclose the estimated additional loss or state that such an estimate cannot be made. As of January 31, 2017, we have not recorded any significant accruals for loss contingencies associated with such legal proceedings, determined that an unfavorable outcome is probable or reasonably possible, or determined that the amount or range of any possible loss is reasonably estimable.
  (was, 2016-11-22, similarity 0.9875):
[0001327567-16-000073:note_history:3]
To the extent there is a reasonable possibility that a loss exceeding amounts already recognized may be incurred and the amount of such additional loss would be material, we will either disclose the estimated additional loss or state that such an estimate cannot be made. As of October 31, 2016, we have not recorded any significant accruals for loss contingencies associated with such legal proceedings, determined that an unfavorable outcome is probable or reasonably possible, or determined that the amount or range of any possible loss is reasonably estimable.


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2017-03-01):
[0001327567-17-000007:note_history:4]
Our condensed consolidated financial statements are unaudited, but include all adjustments of a normal recurring nature necessary for a fair presentation of our quarterly results. We have made estimates and judgments affecting the amounts reported in our condensed consolidated financial statements and the accompanying notes. The actual results that we experience may differ materially from our estimates. Certain prior period amounts have been adjusted as a result of our voluntary change in accounting policy for sales commissions, our early adoption of new accounting guidance related to share-based payments, and our adoption of new accounting guidance related to debt issuance costs. Refer to “Summary of Significant Accounting Policies” and “Recent Accounting Pronouncements” below for more information.
  (was, 2016-11-22, similarity 0.6987):
[0001327567-16-000073:note_history:4]
Our condensed consolidated financial statements are unaudited, but include all adjustments of a normal recurring nature necessary for a fair presentation of our quarterly results. We have made estimates and judgments affecting the amounts reported in our condensed consolidated financial statements and the accompanying notes. The actual results that we experience may differ materially from our estimates. Certain prior period amounts have been adjusted as a result of our voluntary change in accounting policy for sales commissions and our adoption of new accounting guidance related to debt issuance costs. Refer to “Summary of Significant Accounting Policies” and “Recent Accounting Pronouncements” below for more information.

- changed (2017-03-01):
[0001327567-17-000007:note_history:5]
There have been no material changes to our significant accounting policies as of and for the six months ended January 31, 2017, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended July 31, 2016, except for our voluntary change in accounting policy related to sales commissions and our early adoption of the new share-based payment accounting guidance discussed below.
  (was, 2016-11-22, similarity 0.8398):
[0001327567-16-000073:note_history:5]
There have been no material changes to our significant accounting policies as of and for the three months ended October 31, 2016, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended July 31, 2016, except for our voluntary change in accounting policy related to sales commissions discussed below.

- changed (2017-03-01):
[0001327567-17-000007:note_history:6]
The following tables present the changes to financial statement line items as a result of the accounting policy change for the periods presented in our condensed consolidated financial statements (in millions, except per share data):
  (was, 2016-11-22, similarity 0.9847):
[0001327567-16-000073:note_history:6]
The following tables present the changes to financial statement line items as a result of the accounting change for the periods presented in our condensed consolidated financial statements (in millions, except per share data):

- added (2017-03-01):
[0001327567-17-000007:note_history:7]
|  | January 31, 2017 |  | July 31, 2016 |
|  | Computed under Prior Method |  | Impact of Commission Adjustment |  | As Reported |  | As Previously Reported |  | Impact of Commission Adjustment |  | As Adjusted |
| Condensed Consolidated Balance Sheets |  |  |  |  |  |  |  |  |  |  |  |
| Prepaid expenses and other current assets | $ | 83.2 |  |  | $ | 56.7 |  |  | $ | 139.9 |  |  | $ | 84.8 |  |  | $ | 54.9 |  |  | $ | 139.7 |  |
| Other assets | 94.8 |  |  | 51.8 |  |  | 146.6 |  |  | 64.6 |  |  | 50.1 |  |  | 114.7 |  |
| Accumulated deficit | $ | (846.1 | ) |  | $ | 108.5 |  |  | $ | (737.6 | ) |  | $ | (726.6 | ) |  | $ | 105.0 |  |  | $ | (621.6 | ) |

- changed (2017-03-01):
[0001327567-17-000007:note_history:8]
|  | Three Months Ended January 31, 2017 |  | Three Months Ended January 31, 2016 |
|  | Computed under Prior Method |  | Impact of Commission Adjustment |  | As Reported |  | As Previously Reported |  | Impact of Commission Adjustment |  | As Adjusted |
| Condensed Consolidated Statements of Operations |  |  |  |  |  |  |  |  |  |  |  |
| Sales and marketing | $ | 232.7 |  |  | $ | (6.0 | ) |  | $ | 226.7 |  |  | $ | 187.6 |  |  | $ | (5.2 | ) |  | $ | 182.4 |  |
| Operating loss | (60.4 | ) |  | 6.0 |  |  | (54.4 | ) |  | (55.3 | ) |  | 5.2 |  |  | (50.1 | ) |
| Provision for income taxes | 2.8 |  |  | — |  |  | 2.8 |  |  | 3.9 |  |  | — |  |  | 3.9 |  |
| Net loss | $ | (66.6 | ) |  | $ | 6.0 |  |  | $ | (60.6 | ) |  | $ | (62.5 | ) |  | $ | 5.2 |  |  | $ | (57.3 | ) |
| Net loss per share, basic and diluted | $ | (0.73 | ) |  | $ | 0.06 |  |  | $ | (0.67 | ) |  | $ | (0.72 | ) |  | $ | 0.06 |  |  | $ | (0.66 | ) |
| Weighted-average shares used to compute net loss per share, basic and diluted | 90.7 |  |  | — |  |  | 90.7 |  |  | 86.6 |  |  | — |  |  | 86.6 |  |
| Condensed Consolidated Statements of Comprehensive Loss |  |  |  |  |  |  |  |  |  |  |  |
| Net loss | $ | (66.6 | ) |  | $ | 6.0 |  |  | $ | (60.6 | ) |  | $ | (62.5 | ) |  | $ | 5.2 |  |  | $ | (57.3 | ) |
| Comprehensive loss | $ | (69.8 | ) |  | $ | 6.0 |  |  | $ | (63.8 | ) |  | $ | (62.8 | ) |  | $ | 5.2 |  |  | $ | (57.6 | ) |
  (was, 2016-11-22, similarity 0.7303):
[0001327567-16-000073:note_history:8]
|  | Three Months Ended October 31, 2016 |  | Three Months Ended October 31, 2015 |
|  | Computed under Prior Method |  | Impact of Commission Adjustment |  | As Reported |  | As Previously Reported |  | Impact of Commission Adjustment |  | As Adjusted |
| Condensed Consolidated Statements of Operations |  |  |  |  |  |  |  |  |  |  |  |
| Sales and marketing | $ | 217.7 |  |  | $ | 2.6 |  |  | $ | 220.3 |  |  | $ | 158.3 |  |  | $ | 1.2 |  |  | $ | 159.5 |  |
| Operating loss | (47.3 | ) |  | (2.6 | ) |  | (49.9 | ) |  | (30.8 | ) |  | (1.2 | ) |  | (32.0 | ) |
| Provision for income taxes | 7.6 |  |  | 0.8 |  |  | 8.4 |  |  | 4.3 |  |  | — |  |  | 4.3 |  |
| Net loss | $ | (58.4 | ) |  | $ | (3.4 | ) |  | $ | (61.8 | ) |  | $ | (38.7 | ) |  | $ | (1.2 | ) |  | $ | (39.9 | ) |
| Net loss per share, basic and diluted | $ | (0.65 | ) |  | $ | (0.04 | ) |  | $ | (0.69 | ) |  | $ | (0.45 | ) |  | $ | (0.02 | ) |  | $ | (0.47 | ) |
| Weighted-average shares used to compute net loss per share, basic and diluted | 89.8 |  |  | — |  |  | 89.8 |  |  | 85.1 |  |  | — |  |  | 85.1 |  |
| Condensed Consolidated Statements of Comprehensive Loss |  |  |  |  |  |  |  |  |  |  |  |
| Net loss | $ | (58.4 | ) |  | $ | (3.4 | ) |  | $ | (61.8 | ) |  | $ | (38.7 | ) |  | $ | (1.2 | ) |  | $ | (39.9 | ) |
| Comprehensive loss | $ | (61.3 | ) |  | $ | (3.4 | ) |  | $ | (64.7 | ) |  | $ | (39.0 | ) |  | $ | (1.2 | ) |  | $ | (40.2 | ) |

- added (2017-03-01):
[0001327567-17-000007:note_history:9]
|  | Six Months Ended January 31, 2017(1) |  | Six Months Ended January 31, 2016 |
|  | Computed under Prior Method |  | Impact of Commission Adjustment |  | As Reported |  | As Previously Reported |  | Impact of Commission Adjustment |  | As Adjusted |
| Condensed Consolidated Statements of Operations |  |  |  |  |  |  |  |  |  |  |  |
| Sales and marketing | $ | 450.2 |  |  | $ | (3.4 | ) |  | $ | 446.8 |  |  | $ | 345.9 |  |  | $ | (4.0 | ) |  | $ | 341.9 |  |
| Operating loss | (106.8 | ) |  | 3.4 |  |  | (103.4 | ) |  | (86.1 | ) |  | 4.0 |  |  | (82.1 | ) |
| Provision for income taxes | 7.3 |  |  | (0.1 | ) |  | 7.2 |  |  | 8.2 |  |  | — |  |  | 8.2 |  |
| Net loss | $ | (121.0 | ) |  | $ | 3.5 |  |  | $ | (117.5 | ) |  | $ | (101.2 | ) |  | $ | 4.0 |  |  | $ | (97.2 | ) |
| Net loss per share, basic and diluted | $ | (1.34 | ) |  | $ | 0.04 |  |  | $ | (1.30 | ) |  | $ | (1.18 | ) |  | $ | 0.05 |  |  | $ | (1.13 | ) |
| Weighted-average shares used to compute net loss per share, basic and diluted | 90.2 |  |  | — |  |  | 90.2 |  |  | 85.8 |  |  | — |  |  | 85.8 |  |
| Condensed Consolidated Statements of Comprehensive Loss |  |  |  |  |  |  |  |  |  |  |  |
| Net loss | $ | (121.0 | ) |  | $ | 3.5 |  |  | $ | (117.5 | ) |  | $ | (101.2 | ) |  | $ | 4.0 |  |  | $ | (97.2 | ) |
| Comprehensive loss | $ | (127.1 | ) |  | $ | 3.5 |  |  | $ | (123.6 | ) |  | $ | (101.8 | ) |  | $ | 4.0 |  |  | $ | (97.8 | ) |

- added (2017-03-01):
[0001327567-17-000007:note_history:10]
______________

- added (2017-03-01):
[0001327567-17-000007:note_history:11]
| (1) | Amounts reflect an adjustment for the three months ended October 31, 2016, due to our early adoption of new share-based payment accounting guidance in our second quarter of fiscal 2017. Refer to “Recent Accounting Pronouncements” below for more information. |

- changed (2017-03-01):
[0001327567-17-000007:note_history:12]
This change in accounting policy does not affect our balance of cash and cash equivalents and, as a result, did not change net cash flows from operating, investing, or financing activities, or materially impact any individual line items presented in our condensed consolidated statement of cash flows for the six months ended January 31, 2016.
  (was, 2016-11-22, similarity 0.926):
[0001327567-16-000073:note_history:12]
This change in accounting policy does not affect our balance of cash and cash equivalents and, as a result, did not change net cash flows from operating, investing, or financing activities, or materially impact any individual line items presented in our condensed consolidated statement of cash flows for the three months ended October 31, 2015.

- added (2017-03-01):
[0001327567-17-000007:note_history:13]
In March 2016, the Financial Accounting Standards Board (“FASB”) issued authoritative guidance simplifying several aspects of the accounting for employee share-based payment transactions. The new guidance requires us to recognize excess tax benefits or deficiencies as income tax expense or benefit in the period in which they occur, rather than additional paid-in capital, and also requires us to recognize excess tax benefits regardless of whether the benefit reduces taxes payable in the current period. In addition, excess tax benefits should be classified as an operating activity, along with other income tax cash flows, instead of a financing activity in our condensed consolidated statements of cash flows. The guidance also allows us to make an accounting policy election to account for forfeitures of share-based payment awards when they occur, rather than estimate expected forfeitures.

- added (2017-03-01):
[0001327567-17-000007:note_history:14]
We elected to early adopt the guidance in our second quarter of fiscal 2017, which required us to reflect any adjustments related to the adoption as of the beginning of the fiscal year. The impact of the adoption on our condensed consolidated financial statements was as follows:

- added (2017-03-01):
[0001327567-17-000007:note_history:15]
| • | Income tax accounting - We adopted the guidance related to the timing of when excess tax benefits are recognized on a modified retrospective basis. As a result, we recorded the cumulative effect of the change as a $3.5 million reduction to accumulated deficit as of August 1, 2016, to reflect the recognition of excess tax benefits in prior years, with a corresponding adjustment to deferred tax assets and long-term tax liabilities. We adopted the guidance related to the recognition of excess tax benefits and deficiencies as income tax expense or benefit on a prospective basis. |

- added (2017-03-01):
[0001327567-17-000007:note_history:16]
| • | Cash flow presentation of excess tax benefits - We elected to adopt the guidance related to the presentation of excess tax benefits in our condensed consolidated statements of cash flows on a retrospective basis, which increased net cash provided by operating activities by $0.5 million for the six months ended January 31, 2016, with a corresponding decrease to net cash provided by financing activities. |

- added (2017-03-01):
[0001327567-17-000007:note_history:17]
| • | Forfeitures - We elected to account for forfeitures when they occur and adopted this change on a modified retrospective basis. As a result, we recorded the cumulative effect of the change as a $2.0 million increase to accumulated deficit as of August 1, 2016. |

- added (2017-03-01):
[0001327567-17-000007:note_history:18]
The adoption of the guidance also impacted our previously reported results for the three months ended October 31, 2016, as presented in the following tables (in millions, except per share data):

- added (2017-03-01):
[0001327567-17-000007:note_history:19]
|  | October 31, 2016 |
|  | As Previously Reported |  | Impact of Adoption |  | As Adjusted |
| Condensed Consolidated Balance Sheets |  |  |  |  |  |
| Other assets | $ | 102.0 |  |  | $ | 1.7 |  |  | $ | 103.7 |  |
| Other long-term liabilities | 85.8 |  |  | (5.6 | ) |  | 80.2 |  |
| Common stock and additional paid-in capital | 1,542.2 |  |  | 0.9 |  |  | 1,543.1 |  |
| Accumulated deficit | $ | (683.4 | ) |  | $ | 6.4 |  |  | $ | (677.0 | ) |

- added (2017-03-01):
[0001327567-17-000007:note_history:20]
|  | Three Months Ended October 31, 2016 |
|  | As Previously Reported |  | Impact of Adoption |  | As Adjusted |
| Condensed Consolidated Statements of Operations |  |  |  |  |  |
| Total cost of revenue(1) | $ | 101.3 |  |  | $ | (0.1 | ) |  | $ | 101.2 |  |
| Total operating expenses(1) | 346.7 |  |  | (0.8 | ) |  | 345.9 |  |
| Provision for income taxes | 8.4 |  |  | (4.0 | ) |  | 4.4 |  |
| Net loss | $ | (61.8 | ) |  | $ | 4.9 |  |  | $ | (56.9 | ) |
| Net loss per share, basic and diluted | $ | (0.69 | ) |  | $ | 0.06 |  |  | $ | (0.63 | ) |
| Weighted-average shares used to compute net loss per share, basic and diluted | 89.8 |  |  | — |  |  | 89.8 |  |
| Condensed Consolidated Statements of Comprehensive Loss |  |  |  |  |  |
| Net loss | $ | (61.8 | ) |  | $ | 4.9 |  |  | $ | (56.9 | ) |
| Comprehensive loss | $ | (64.7 | ) |  | $ | 4.9 |  |  | $ | (59.8 | ) |
| Condensed Consolidated Statements of Cash Flows |  |  |  |  |  |
| Net cash provided by operating activities | $ | 203.3 |  |  | $ | 0.2 |  |  | $ | 203.5 |  |
| Net cash used in financing activities | $ | (27.1 | ) |  | $ | (0.2 | ) |  | $ | (27.3 | ) |

- added (2017-03-01):
[0001327567-17-000007:note_history:21]
______________

- added (2017-03-01):
[0001327567-17-000007:note_history:22]
| (1) | Adjustments consist of share-based compensation, which was impacted by our policy election to account for forfeitures when they occur. The impact of adoption on each cost and expense line item within these subtotals was not significant. |

- changed (2017-03-01):
[0001327567-17-000007:note_history:23]
In April 2015, the FASB issued new authoritative guidance on fees paid in a cloud computing arrangement. The standard requires customers in a cloud computing arrangement to evaluate whether the arrangement includes a software license. If the arrangement includes a software license, the customer should account for the software license element of the arrangement consistent with the acquisition of other software licenses. If the arrangement does not include a software license, the customer should account for the arrangement as a service contract. We adopted the guidance in our first quarter of fiscal 2017 on a prospective basis. Our adoption of this guidance did not have a material impact on our condensed consolidated financial statements.
  (was, 2016-11-22, similarity 0.9704):
[0001327567-16-000073:note_history:23]
In April 2015, the Financial Accounting Standards Board (“FASB”) issued new authoritative guidance on fees paid in a cloud computing arrangement. The standard requires customers in a cloud computing arrangement to evaluate whether the arrangement includes a software license. If the arrangement includes a software license, the customer should account for the software license element of the arrangement consistent with the acquisition of other software licenses. If the arrangement does not include a software license, the customer should account for the arrangement as a service contract. We adopted the guidance in our first quarter of fiscal 2017 on a prospective basis. Our adoption of this guidance did not have a material impact on our condensed consolidated financial statements.

- changed (2017-03-01):
[0001327567-17-000007:note_history:24]
In May 2014, the FASB issued new authoritative guidance on revenue from contracts with customers. The new standard provides principles for recognizing revenue for the transfer of promised goods or services to customers with the consideration to which the entity expects to be entitled in exchange for those goods or services. The standard also requires significantly expanded disclosures about revenue recognition. The FASB subsequently delayed the effective date of the standard by one year and as a result, the standard is now effective for us for our first quarter of fiscal 2019 using either of two methods: (i) retrospective to each prior reporting period presented with the option to elect certain practical expedients as defined within the guidance; or (ii) retrospective with the cumulative effect of initially applying the guidance recognized at the date of initial application and providing certain additional disclosures as defined per the guidance. Early adoption as of the original effective date is permitted. We do not plan to early adopt, and accordingly, we will adopt the new standard in our first quarter of fiscal 2019. We are in the initial stages of evaluating the impact of the new standard on our accounting policies, processes, and system requirements, and have assigned internal resources and engaged third party service providers to assist in our evaluation and system implementation. Furthermore, we have made and will continue to make investments in systems to enable timely and accurate reporting under the new standard. We are currently evaluating adoption methods and the potential impact that the implementation of this standard will have on our condensed consolidated financial statements.
  (was, 2016-11-22, similarity 0.7155):
[0001327567-16-000073:note_history:24]
In May 2014, the FASB issued new authoritative guidance on revenue from contracts with customers. The new standard provides principles for recognizing revenue for the transfer of promised goods or services to customers with the consideration to which the entity expects to be entitled in exchange for those goods or services. The standard also requires significantly expanded disclosures about revenue recognition. The FASB subsequently delayed the effective date of the standard by one year and as a result, the standard is now effective for us for our first quarter of fiscal 2019 using either of two methods: (i) retrospective to each prior reporting period presented with the option to elect certain practical expedients as defined within the guidance; or (ii) retrospective with the cumulative effect of initially applying the guidance recognized at the date of initial application and providing certain additional disclosures as defined per the guidance. Early adoption as of the original effective date is permitted. We are currently evaluating adoption methods and whether this standard will have a material impact on our condensed consolidated financial statements.

- removed (2017-03-01):
[0001327567-16-000073:note_history:25]
|  | October 31, 2016 |  | July 31, 2016 |
|  | Computed under Prior Method |  | Impact of Commission Adjustment |  | As Reported |  | As Previously Reported |  | Impact of Commission Adjustment |  | As Adjusted |
| Condensed Consolidated Balance Sheets |  |  |  |  |  |  |  |  |  |  |  |
| Prepaid expenses and other current assets | $ | 75.4 |  |  | $ | 54.0 |  |  | $ | 129.4 |  |  | $ | 84.8 |  |  | $ | 54.9 |  |  | $ | 139.7 |  |
| Other assets | 53.6 |  |  | 48.4 |  |  | 102.0 |  |  | 64.6 |  |  | 50.1 |  |  | 114.7 |  |
| Other long-term liabilities | 85.0 |  |  | 0.8 |  |  | 85.8 |  |  | 79.4 |  |  | — |  |  | 79.4 |  |
| Accumulated deficit | $ | (785.0 | ) |  | $ | 101.6 |  |  | $ | (683.4 | ) |  | $ | (726.6 | ) |  | $ | 105.0 |  |  | $ | (621.6 | ) |

- removed (2017-03-01):
[0001327567-16-000073:note_history:26]
In March 2016, the FASB issued authoritative guidance simplifying several aspects of the accounting for employee share-based payment transactions, including the income tax consequences, accounting for forfeitures, and classification of excess tax benefits on the statement of cash flows. The standard is effective for us for our first quarter of fiscal 2018, however, early adoption is permitted. We are currently evaluating whether this standard will have a material impact on our condensed consolidated financial statements.


## us-gaap:ConvertibleDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-03-01):
[0001327567-17-000007:note_history:27]
The following table sets forth the components of the Notes as of January 31, 2017 and July 31, 2016 (in millions):
  (was, 2016-11-22, similarity 0.9423):
[0001327567-16-000073:note_history:27]
The following table sets forth the components of the Notes as of October 31, 2016 and July 31, 2016 (in millions):

- changed (2017-03-01):
[0001327567-17-000007:note_history:28]
|  | January 31, 2017 |  | July 31, 2016 |
| Liability: |  |  |  |
| Principal | $ | 575.0 |  |  | $ | 575.0 |  |
| Less: debt discount and debt issuance costs, net of amortization | 62.7 |  |  | 74.8 |  |
| Net carrying amount | $ | 512.3 |  |  | $ | 500.2 |  |
| Equity | $ | 109.8 |  |  | $ | 109.8 |  |
  (was, 2016-11-22, similarity 0.797):
[0001327567-16-000073:note_history:28]
|  | October 31, 2016 |  | July 31, 2016 |
| Liability: |  |  |  |
| Principal | $ | 575.0 |  |  | $ | 575.0 |  |
| Less: debt discount and debt issuance costs, net of amortization | 68.8 |  |  | 74.8 |  |
| Net carrying amount | $ | 506.2 |  |  | $ | 500.2 |  |
| Equity (including temporary equity) | $ | 109.8 |  |  | $ | 109.8 |  |


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2017-03-01):
[0001327567-17-000007:note_history:29]
The sale price condition was not met during the fiscal quarter ended January 31, 2017. Since the Notes were not convertible, the net carrying amount of the Notes was classified as a long-term liability and the equity component was included in additional paid-in capital in our condensed consolidated balance sheets as of January 31, 2017.

- changed (2017-03-01):
[0001327567-17-000007:note_history:30]
The following table sets forth the components of the Notes as of January 31, 2017 and July 31, 2016 (in millions):
  (was, 2016-11-22, similarity 0.9423):
[0001327567-16-000073:note_history:30]
The following table sets forth the components of the Notes as of October 31, 2016 and July 31, 2016 (in millions):

- changed (2017-03-01):
[0001327567-17-000007:note_history:31]
|  | January 31, 2017 |  | July 31, 2016 |
| Liability: |  |  |  |
| Principal | $ | 575.0 |  |  | $ | 575.0 |  |
| Less: debt discount and debt issuance costs, net of amortization | 62.7 |  |  | 74.8 |  |
| Net carrying amount | $ | 512.3 |  |  | $ | 500.2 |  |
| Equity | $ | 109.8 |  |  | $ | 109.8 |  |
  (was, 2016-11-22, similarity 0.797):
[0001327567-16-000073:note_history:31]
|  | October 31, 2016 |  | July 31, 2016 |
| Liability: |  |  |  |
| Principal | $ | 575.0 |  |  | $ | 575.0 |  |
| Less: debt discount and debt issuance costs, net of amortization | 68.8 |  |  | 74.8 |  |
| Net carrying amount | $ | 506.2 |  |  | $ | 500.2 |  |
| Equity (including temporary equity) | $ | 109.8 |  |  | $ | 109.8 |  |

- added (2017-03-01):
[0001327567-17-000007:note_history:32]
The total estimated fair value of the Notes was $820.2 million and $761.9 million at January 31, 2017 and July 31, 2016, respectively. The fair value was determined based on the closing trading price per $100 of the Notes as of the last day of trading for the period. We consider the fair value of the Notes at January 31, 2017 and July 31, 2016 to be a Level 2 measurement. The fair value of the Notes is primarily affected by the trading price of our common stock and market interest rates. As of January 31, 2017, the if-converted value of the Notes exceeded its principal amount by $125.0 million.

- added (2017-03-01):
[0001327567-17-000007:note_history:33]
|  | Three Months Ended January 31, |  | Six Months Ended January 31, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Amortization of debt discount | $ | 5.5 |  |  | $ | 5.2 |  |  | $ | 10.9 |  |  | $ | 10.4 |  |
| Amortization of debt issuance costs | 0.6 |  |  | 0.6 |  |  | 1.2 |  |  | 1.1 |  |
| Total interest expense recognized | $ | 6.1 |  |  | $ | 5.8 |  |  | $ | 12.1 |  |  | $ | 11.5 |  |
| Effective interest rate of the liability component | 4.8 | % |  | 4.8 | % |  | 4.8 | % |  | 4.8 | % |

- changed (2017-03-01):
[0001327567-17-000007:note_history:34]
For more information on the Notes, the Note Hedges, and the Warrants, refer to Note 7. Convertible Senior Notes included in Part II, Item 8 of our Annual Report on Form 10-K for the fiscal year ended July 31, 2016.
  (was, 2016-11-22, similarity 0.8996):
[0001327567-16-000073:note_history:34]
For more information on the Notes, the Note Hedges, and the Warrants, refer to Note 7. Convertible Senior Notes of Notes to Consolidated Financial Statements included in Part II, Item 8 of our Annual Report on Form 10-K for the fiscal year ended July 31, 2016.

- removed (2017-03-01):
[0001327567-16-000073:note_history:35]
The sale price condition was not met during the fiscal quarter ended July 31, 2016. Since the Notes were not convertible, the net carrying amount of the Notes and related debt issuance costs were classified as long-term liabilities and the equity component was included in additional paid-in capital in our condensed consolidated balance sheets as of July 31, 2016. The sale price condition was met during the fiscal quarter ended October 31, 2016, and as a result, holders may convert their Notes at any time during the fiscal quarter ending January 31, 2017. Accordingly, the net carrying amount of the Notes and related debt issuance costs were reclassified into current liabilities and the portion of the equity component representing the conversion option was reclassified into temporary equity in our condensed consolidated balance sheets as of October 31, 2016. The portion of the equity component classified as temporary equity is measured as the difference between the principal and net carrying amount of the Notes, excluding debt issuance costs.

- removed (2017-03-01):
[0001327567-16-000073:note_history:36]
The total estimated fair value of the Notes was $851.0 million and $761.9 million at October 31, 2016 and July 31, 2016, respectively. The fair value was determined based on the closing trading price per $100 of the Notes as of the last day of trading for the period. We consider the fair value of the Notes at October 31, 2016 and July 31, 2016 to be a Level 2 measurement. The fair value of the Notes is primarily affected by the trading price of our common stock and market interest rates. As of October 31, 2016, the if-converted value of the Notes exceeded its principal amount by $223.6 million.

- removed (2017-03-01):
[0001327567-16-000073:note_history:37]
|  | Three Months Ended October 31, |
|  | 2016 |  | 2015 |
| Amortization of debt discount | $ | 5.4 |  |  | $ | 5.2 |  |
| Amortization of debt issuance costs | 0.6 |  |  | 0.5 |  |
| Total interest expense recognized | $ | 6.0 |  |  | $ | 5.7 |  |
| Effective interest rate of the liability component | 4.8 | % |  | 4.8 | % |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-03-01):
[0001327567-17-000007:note_history:38]
The following tables summarize the amortized cost, unrealized gains and losses, and fair value of our available-for-sale investments as of January 31, 2017 and July 31, 2016 (in millions):
  (was, 2016-11-22, similarity 0.9663):
[0001327567-16-000073:note_history:38]
The following tables summarize the amortized cost, unrealized gains and losses, and fair value of our available-for-sale investments as of October 31, 2016 and July 31, 2016 (in millions):

- changed (2017-03-01):
[0001327567-17-000007:note_history:39]
|  | January 31, 2017 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Estimated Fair Value |
| Certificates of deposit | $ | 5.4 |  |  | $ | — |  |  | $ | — |  |  | $ | 5.4 |  |
| Commercial paper | 17.9 |  |  | — |  |  | — |  |  | 17.9 |  |
| Corporate debt securities | 330.0 |  |  | 0.2 |  |  | (0.9 | ) |  | 329.3 |  |
| U.S. government and agency securities | 1,035.3 |  |  | 0.1 |  |  | (2.5 | ) |  | 1,032.9 |  |
| Total | $ | 1,388.6 |  |  | $ | 0.3 |  |  | $ | (3.4 | ) |  | $ | 1,385.5 |  |
  (was, 2016-11-22, similarity 0.9836):
[0001327567-16-000073:note_history:39]
|  | October 31, 2016 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Estimated Fair Value |
| Certificates of deposit | $ | 5.4 |  |  | $ | — |  |  | $ | — |  |  | $ | 5.4 |  |
| Commercial paper | 17.9 |  |  | — |  |  | — |  |  | 17.9 |  |
| Corporate debt securities | 298.9 |  |  | 0.4 |  |  | (0.3 | ) |  | 299.0 |  |
| U.S. government and agency securities | 937.0 |  |  | 0.3 |  |  | (0.6 | ) |  | 936.7 |  |
| Total | $ | 1,259.2 |  |  | $ | 0.7 |  |  | $ | (0.9 | ) |  | $ | 1,259.0 |  |

- changed (2017-03-01):
[0001327567-17-000007:note_history:40]
Unrealized losses related to these investments are due to interest rate fluctuations as opposed to credit quality. In addition, we do not intend to sell and it is not likely that we would be required to sell these investments before recovery of their amortized cost basis, which may be at maturity. As a result, there were no other-than-temporary impairments for these investments at January 31, 2017 and July 31, 2016.
  (was, 2016-11-22, similarity 0.9559):
[0001327567-16-000073:note_history:40]
Unrealized losses related to these investments are due to interest rate fluctuations as opposed to credit quality. In addition, we do not intend to sell and it is not likely that we would be required to sell these investments before recovery of their amortized cost basis, which may be at maturity. As a result, there were no other-than-temporary impairments for these investments at October 31, 2016 and July 31, 2016.

- changed (2017-03-01):
[0001327567-17-000007:note_history:41]
The following table summarizes the amortized cost and fair value of our available-for-sale investments as of January 31, 2017, by contractual years-to-maturity (in millions):
  (was, 2016-11-22, similarity 0.9643):
[0001327567-16-000073:note_history:41]
The following table summarizes the amortized cost and fair value of our available-for-sale investments as of October 31, 2016, by contractual years-to-maturity (in millions):


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_prior_note, score: 0.0

- added (2017-03-01):
[0001327567-17-000007:note_history:42]
Subsequent Events

- added (2017-03-01):
[0001327567-17-000007:note_history:43]
Business Combination

- added (2017-03-01):
[0001327567-17-000007:note_history:44]
On February 27, 2017, we completed our acquisition of LightCyber Ltd. (“LightCyber”), a privately-held cybersecurity company, in exchange for total consideration of approximately $105.0 million in cash. The acquisition expands the functionality of our next-generation security platform with the addition of LightCyber’s behavioral analytics technology. We are currently in the process of finalizing the accounting for this transaction and expect to complete our preliminary allocation of the purchase consideration to the assets acquired and liabilities assumed by the end of our third quarter of fiscal 2017.

- added (2017-03-01):
[0001327567-17-000007:note_history:45]
Share Repurchase

- added (2017-03-01):
[0001327567-17-000007:note_history:46]
On February 24, 2017, our board of directors authorized a $500.0 million increase to our existing share repurchase program, bringing the total authorization to $1.0 billion. Repurchases may be made at management’s discretion from time to time on the open market, through privately negotiated transactions, transactions structured through investment banking institutions, block purchase techniques, 10b5-1 trading plans, or a combination of the foregoing, and will be funded from available working capital. Additionally, our board of directors extended the term of the repurchase authorization, which will now expire on December 31, 2018, and may be suspended or discontinued at any time. Refer to Note 7. Stockholders’ Equity for more information on our existing repurchase authorization as of January 31, 2017.
