# PANW notes — 0001327567-17-000007


## us-gaap:AvailableForSaleSecuritiesTextBlock

[0001327567-17-000007:notes:1]
The following tables summarize the amortized cost, unrealized gains and losses, and fair value of our available-for-sale investments as of January 31, 2017 and July 31, 2016 (in millions):

[0001327567-17-000007:notes:2]
|  | January 31, 2017 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Estimated Fair Value |
| Certificates of deposit | $ | 5.4 |  |  | $ | — |  |  | $ | — |  |  | $ | 5.4 |  |
| Commercial paper | 17.9 |  |  | — |  |  | — |  |  | 17.9 |  |
| Corporate debt securities | 330.0 |  |  | 0.2 |  |  | (0.9 | ) |  | 329.3 |  |
| U.S. government and agency securities | 1,035.3 |  |  | 0.1 |  |  | (2.5 | ) |  | 1,032.9 |  |
| Total | $ | 1,388.6 |  |  | $ | 0.3 |  |  | $ | (3.4 | ) |  | $ | 1,385.5 |  |

[0001327567-17-000007:notes:3]
[same as prior period, unchanged from 0001327567-16-000073:notes:3]


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001327567-17-000007:notes:4]
[same as prior period, unchanged from 0001327567-16-000073:notes:4]

[0001327567-17-000007:notes:5]
[same as prior period, unchanged from 0001327567-16-000073:notes:5]

[0001327567-17-000007:notes:6]
Our condensed consolidated financial statements are unaudited, but include all adjustments of a normal recurring nature necessary for a fair presentation of our quarterly results. We have made estimates and judgments affecting the amounts reported in our condensed consolidated financial statements and the accompanying notes. The actual results that we experience may differ materially from our estimates. Certain prior period amounts have been adjusted as a result of our voluntary change in accounting policy for sales commissions, our early adoption of new accounting guidance related to share-based payments, and our adoption of new accounting guidance related to debt issuance costs. Refer to “Summary of Significant Accounting Policies” and “Recent Accounting Pronouncements” below for more information.

[0001327567-17-000007:notes:7]
[same as prior period, unchanged from 0001327567-16-000073:notes:7]


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock

[0001327567-17-000007:notes:8]
[same as prior period, unchanged from 0001327567-16-000073:notes:8]

[0001327567-17-000007:notes:9]
[same as prior period, unchanged from 0001327567-16-000073:notes:9]

[0001327567-17-000007:notes:10]
[same as prior period, unchanged from 0001327567-16-000073:notes:10]

[0001327567-17-000007:notes:11]
[same as prior period, unchanged from 0001327567-16-000073:notes:11]

[0001327567-17-000007:notes:12]
There have been no material changes to our significant accounting policies as of and for the six months ended January 31, 2017, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended July 31, 2016, except for our voluntary change in accounting policy related to sales commissions and our early adoption of the new share-based payment accounting guidance discussed below.

[0001327567-17-000007:notes:13]
[same as prior period, unchanged from 0001327567-16-000073:notes:13]

[0001327567-17-000007:notes:14]
[same as prior period, unchanged from 0001327567-16-000073:notes:14]

[0001327567-17-000007:notes:15]
[same as prior period, unchanged from 0001327567-16-000073:notes:15]

[0001327567-17-000007:notes:16]
[same as prior period, unchanged from 0001327567-16-000073:notes:16]

[0001327567-17-000007:notes:17]
The following tables present the changes to financial statement line items as a result of the accounting policy change for the periods presented in our condensed consolidated financial statements (in millions, except per share data):

[0001327567-17-000007:notes:18]
|  | January 31, 2017 |  | July 31, 2016 |
|  | Computed under Prior Method |  | Impact of Commission Adjustment |  | As Reported |  | As Previously Reported |  | Impact of Commission Adjustment |  | As Adjusted |
| Condensed Consolidated Balance Sheets |  |  |  |  |  |  |  |  |  |  |  |
| Prepaid expenses and other current assets | $ | 83.2 |  |  | $ | 56.7 |  |  | $ | 139.9 |  |  | $ | 84.8 |  |  | $ | 54.9 |  |  | $ | 139.7 |  |
| Other assets | 94.8 |  |  | 51.8 |  |  | 146.6 |  |  | 64.6 |  |  | 50.1 |  |  | 114.7 |  |
| Accumulated deficit | $ | (846.1 | ) |  | $ | 108.5 |  |  | $ | (737.6 | ) |  | $ | (726.6 | ) |  | $ | 105.0 |  |  | $ | (621.6 | ) |

[0001327567-17-000007:notes:19]
|  | Three Months Ended January 31, 2017 |  | Three Months Ended January 31, 2016 |
|  | Computed under Prior Method |  | Impact of Commission Adjustment |  | As Reported |  | As Previously Reported |  | Impact of Commission Adjustment |  | As Adjusted |
| Condensed Consolidated Statements of Operations |  |  |  |  |  |  |  |  |  |  |  |
| Sales and marketing | $ | 232.7 |  |  | $ | (6.0 | ) |  | $ | 226.7 |  |  | $ | 187.6 |  |  | $ | (5.2 | ) |  | $ | 182.4 |  |
| Operating loss | (60.4 | ) |  | 6.0 |  |  | (54.4 | ) |  | (55.3 | ) |  | 5.2 |  |  | (50.1 | ) |
| Provision for income taxes | 2.8 |  |  | — |  |  | 2.8 |  |  | 3.9 |  |  | — |  |  | 3.9 |  |
| Net loss | $ | (66.6 | ) |  | $ | 6.0 |  |  | $ | (60.6 | ) |  | $ | (62.5 | ) |  | $ | 5.2 |  |  | $ | (57.3 | ) |
| Net loss per share, basic and diluted | $ | (0.73 | ) |  | $ | 0.06 |  |  | $ | (0.67 | ) |  | $ | (0.72 | ) |  | $ | 0.06 |  |  | $ | (0.66 | ) |
| Weighted-average shares used to compute net loss per share, basic and diluted | 90.7 |  |  | — |  |  | 90.7 |  |  | 86.6 |  |  | — |  |  | 86.6 |  |
| Condensed Consolidated Statements of Comprehensive Loss |  |  |  |  |  |  |  |  |  |  |  |
| Net loss | $ | (66.6 | ) |  | $ | 6.0 |  |  | $ | (60.6 | ) |  | $ | (62.5 | ) |  | $ | 5.2 |  |  | $ | (57.3 | ) |
| Comprehensive loss | $ | (69.8 | ) |  | $ | 6.0 |  |  | $ | (63.8 | ) |  | $ | (62.8 | ) |  | $ | 5.2 |  |  | $ | (57.6 | ) |

[0001327567-17-000007:notes:20]
|  | Six Months Ended January 31, 2017(1) |  | Six Months Ended January 31, 2016 |
|  | Computed under Prior Method |  | Impact of Commission Adjustment |  | As Reported |  | As Previously Reported |  | Impact of Commission Adjustment |  | As Adjusted |
| Condensed Consolidated Statements of Operations |  |  |  |  |  |  |  |  |  |  |  |
| Sales and marketing | $ | 450.2 |  |  | $ | (3.4 | ) |  | $ | 446.8 |  |  | $ | 345.9 |  |  | $ | (4.0 | ) |  | $ | 341.9 |  |
| Operating loss | (106.8 | ) |  | 3.4 |  |  | (103.4 | ) |  | (86.1 | ) |  | 4.0 |  |  | (82.1 | ) |
| Provision for income taxes | 7.3 |  |  | (0.1 | ) |  | 7.2 |  |  | 8.2 |  |  | — |  |  | 8.2 |  |
| Net loss | $ | (121.0 | ) |  | $ | 3.5 |  |  | $ | (117.5 | ) |  | $ | (101.2 | ) |  | $ | 4.0 |  |  | $ | (97.2 | ) |
| Net loss per share, basic and diluted | $ | (1.34 | ) |  | $ | 0.04 |  |  | $ | (1.30 | ) |  | $ | (1.18 | ) |  | $ | 0.05 |  |  | $ | (1.13 | ) |
| Weighted-average shares used to compute net loss per share, basic and diluted | 90.2 |  |  | — |  |  | 90.2 |  |  | 85.8 |  |  | — |  |  | 85.8 |  |
| Condensed Consolidated Statements of Comprehensive Loss |  |  |  |  |  |  |  |  |  |  |  |
| Net loss | $ | (121.0 | ) |  | $ | 3.5 |  |  | $ | (117.5 | ) |  | $ | (101.2 | ) |  | $ | 4.0 |  |  | $ | (97.2 | ) |
| Comprehensive loss | $ | (127.1 | ) |  | $ | 3.5 |  |  | $ | (123.6 | ) |  | $ | (101.8 | ) |  | $ | 4.0 |  |  | $ | (97.8 | ) |

[0001327567-17-000007:notes:21]
______________

[0001327567-17-000007:notes:22]
| (1) | Amounts reflect an adjustment for the three months ended October 31, 2016, due to our early adoption of new share-based payment accounting guidance in our second quarter of fiscal 2017. Refer to “Recent Accounting Pronouncements” below for more information. |

[0001327567-17-000007:notes:23]
This change in accounting policy does not affect our balance of cash and cash equivalents and, as a result, did not change net cash flows from operating, investing, or financing activities, or materially impact any individual line items presented in our condensed consolidated statement of cash flows for the six months ended January 31, 2016.

[0001327567-17-000007:notes:24]
[same as prior period, unchanged from 0001327567-16-000073:notes:21]

[0001327567-17-000007:notes:25]
Recently Adopted Accounting Pronouncements

[0001327567-17-000007:notes:26]
In March 2016, the Financial Accounting Standards Board (“FASB”) issued authoritative guidance simplifying several aspects of the accounting for employee share-based payment transactions. The new guidance requires us to recognize excess tax benefits or deficiencies as income tax expense or benefit in the period in which they occur, rather than additional paid-in capital, and also requires us to recognize excess tax benefits regardless of whether the benefit reduces taxes payable in the current period. In addition, excess tax benefits should be classified as an operating activity, along with other income tax cash flows, instead of a financing activity in our condensed consolidated statements of cash flows. The guidance also allows us to make an accounting policy election to account for forfeitures of share-based payment awards when they occur, rather than estimate expected forfeitures.

[0001327567-17-000007:notes:27]
We elected to early adopt the guidance in our second quarter of fiscal 2017, which required us to reflect any adjustments related to the adoption as of the beginning of the fiscal year. The impact of the adoption on our condensed consolidated financial statements was as follows:

[0001327567-17-000007:notes:28]
| • | Income tax accounting - We adopted the guidance related to the timing of when excess tax benefits are recognized on a modified retrospective basis. As a result, we recorded the cumulative effect of the change as a $3.5 million reduction to accumulated deficit as of August 1, 2016, to reflect the recognition of excess tax benefits in prior years, with a corresponding adjustment to deferred tax assets and long-term tax liabilities. We adopted the guidance related to the recognition of excess tax benefits and deficiencies as income tax expense or benefit on a prospective basis. |

[0001327567-17-000007:notes:29]
| • | Cash flow presentation of excess tax benefits - We elected to adopt the guidance related to the presentation of excess tax benefits in our condensed consolidated statements of cash flows on a retrospective basis, which increased net cash provided by operating activities by $0.5 million for the six months ended January 31, 2016, with a corresponding decrease to net cash provided by financing activities. |

[0001327567-17-000007:notes:30]
| • | Forfeitures - We elected to account for forfeitures when they occur and adopted this change on a modified retrospective basis. As a result, we recorded the cumulative effect of the change as a $2.0 million increase to accumulated deficit as of August 1, 2016. |

[0001327567-17-000007:notes:31]
The adoption of the guidance also impacted our previously reported results for the three months ended October 31, 2016, as presented in the following tables (in millions, except per share data):

[0001327567-17-000007:notes:32]
|  | October 31, 2016 |
|  | As Previously Reported |  | Impact of Adoption |  | As Adjusted |
| Condensed Consolidated Balance Sheets |  |  |  |  |  |
| Other assets | $ | 102.0 |  |  | $ | 1.7 |  |  | $ | 103.7 |  |
| Other long-term liabilities | 85.8 |  |  | (5.6 | ) |  | 80.2 |  |
| Common stock and additional paid-in capital | 1,542.2 |  |  | 0.9 |  |  | 1,543.1 |  |
| Accumulated deficit | $ | (683.4 | ) |  | $ | 6.4 |  |  | $ | (677.0 | ) |

[0001327567-17-000007:notes:33]
|  | Three Months Ended October 31, 2016 |
|  | As Previously Reported |  | Impact of Adoption |  | As Adjusted |
| Condensed Consolidated Statements of Operations |  |  |  |  |  |
| Total cost of revenue(1) | $ | 101.3 |  |  | $ | (0.1 | ) |  | $ | 101.2 |  |
| Total operating expenses(1) | 346.7 |  |  | (0.8 | ) |  | 345.9 |  |
| Provision for income taxes | 8.4 |  |  | (4.0 | ) |  | 4.4 |  |
| Net loss | $ | (61.8 | ) |  | $ | 4.9 |  |  | $ | (56.9 | ) |
| Net loss per share, basic and diluted | $ | (0.69 | ) |  | $ | 0.06 |  |  | $ | (0.63 | ) |
| Weighted-average shares used to compute net loss per share, basic and diluted | 89.8 |  |  | — |  |  | 89.8 |  |
| Condensed Consolidated Statements of Comprehensive Loss |  |  |  |  |  |
| Net loss | $ | (61.8 | ) |  | $ | 4.9 |  |  | $ | (56.9 | ) |
| Comprehensive loss | $ | (64.7 | ) |  | $ | 4.9 |  |  | $ | (59.8 | ) |
| Condensed Consolidated Statements of Cash Flows |  |  |  |  |  |
| Net cash provided by operating activities | $ | 203.3 |  |  | $ | 0.2 |  |  | $ | 203.5 |  |
| Net cash used in financing activities | $ | (27.1 | ) |  | $ | (0.2 | ) |  | $ | (27.3 | ) |

[0001327567-17-000007:notes:34]
| (1) | Adjustments consist of share-based compensation, which was impacted by our policy election to account for forfeitures when they occur. The impact of adoption on each cost and expense line item within these subtotals was not significant. |

[0001327567-17-000007:notes:35]
In April 2015, the FASB issued new authoritative guidance on fees paid in a cloud computing arrangement. The standard requires customers in a cloud computing arrangement to evaluate whether the arrangement includes a software license. If the arrangement includes a software license, the customer should account for the software license element of the arrangement consistent with the acquisition of other software licenses. If the arrangement does not include a software license, the customer should account for the arrangement as a service contract. We adopted the guidance in our first quarter of fiscal 2017 on a prospective basis. Our adoption of this guidance did not have a material impact on our condensed consolidated financial statements.

[0001327567-17-000007:notes:36]
[same as prior period, unchanged from 0001327567-16-000073:notes:24]

[0001327567-17-000007:notes:37]
Recently Issued Accounting Pronouncements

[0001327567-17-000007:notes:38]
[same as prior period, unchanged from 0001327567-16-000073:notes:26]

[0001327567-17-000007:notes:39]
[same as prior period, unchanged from 0001327567-16-000073:notes:27]

[0001327567-17-000007:notes:40]
[same as prior period, unchanged from 0001327567-16-000073:notes:28]

[0001327567-17-000007:notes:41]
[same as prior period, unchanged from 0001327567-16-000073:notes:30]

[0001327567-17-000007:notes:42]
In May 2014, the FASB issued new authoritative guidance on revenue from contracts with customers. The new standard provides principles for recognizing revenue for the transfer of promised goods or services to customers with the consideration to which the entity expects to be entitled in exchange for those goods or services. The standard also requires significantly expanded disclosures about revenue recognition. The FASB subsequently delayed the effective date of the standard by one year and as a result, the standard is now effective for us for our first quarter of fiscal 2019 using either of two methods: (i) retrospective to each prior reporting period presented with the option to elect certain practical expedients as defined within the guidance; or (ii) retrospective with the cumulative effect of initially applying the guidance recognized at the date of initial application and providing certain additional disclosures as defined per the guidance. Early adoption as of the original effective date is permitted. We do not plan to early adopt, and accordingly, we will adopt the new standard in our first quarter of fiscal 2019. We are in the initial stages of evaluating the impact of the new standard on our accounting policies, processes, and system requirements, and have assigned internal resources and engaged third party service providers to assist in our evaluation and system implementation. Furthermore, we have made and will continue to make investments in systems to enable timely and accurate reporting under the new standard. We are currently evaluating adoption methods and the potential impact that the implementation of this standard will have on our condensed consolidated financial statements.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001327567-17-000007:notes:43]
Commitments and Contingencies

[0001327567-17-000007:notes:44]
Leases

[0001327567-17-000007:notes:45]
We lease our facilities under various non-cancelable operating leases, which expire through the year ending July 31, 2028.

[0001327567-17-000007:notes:46]
The following table presents details of the aggregate future non-cancelable minimum rental payments under our operating leases as of January 31, 2017 (in millions):

[0001327567-17-000007:notes:47]
|  | Amount |
| Fiscal years ending July 31: |  |
| Remaining 2017 | $ | 14.0 |  |
| 2018 | 27.6 |  |
| 2019 | 46.9 |  |
| 2020 | 50.6 |  |
| 2021 | 55.0 |  |
| 2022 and thereafter | 316.3 |  |
| Committed gross lease payments | 510.4 |  |
| Less: proceeds from sublease rental | 3.6 |  |
| Net operating lease obligation | $ | 506.8 |  |

[0001327567-17-000007:notes:48]
Contract Manufacturer Commitments

[0001327567-17-000007:notes:49]
Our independent contract manufacturer procures components and assembles our products based on our forecasts. These forecasts are based on estimates of demand for our products primarily for the next 12 months, which are in turn based on historical trends and an analysis from our sales and product marketing organizations, adjusted for overall market conditions. In order to reduce manufacturing lead times and plan for adequate supply, we may issue forecasts and orders for components and products that are non-cancelable. As of January 31, 2017, our purchase commitments under such orders were $77.6 million, excluding obligations under contracts that we can cancel without a significant penalty.

[0001327567-17-000007:notes:50]
Litigation

[0001327567-17-000007:notes:51]
We are subject to legal proceedings, claims, and litigation arising in the ordinary course of business, including intellectual property litigation. Such matters are subject to many uncertainties and outcomes are not predictable with assurance. We accrue for contingencies when we believe that a loss is probable and that we can reasonably estimate the amount of any such loss.

[0001327567-17-000007:notes:52]
To the extent there is a reasonable possibility that a loss exceeding amounts already recognized may be incurred and the amount of such additional loss would be material, we will either disclose the estimated additional loss or state that such an estimate cannot be made. As of January 31, 2017, we have not recorded any significant accruals for loss contingencies associated with such legal proceedings, determined that an unfavorable outcome is probable or reasonably possible, or determined that the amount or range of any possible loss is reasonably estimable.


## us-gaap:ConvertibleDebtTableTextBlock

[0001327567-17-000007:notes:53]
The following table sets forth the components of the Notes as of January 31, 2017 and July 31, 2016 (in millions):

[0001327567-17-000007:notes:54]
|  | January 31, 2017 |  | July 31, 2016 |
| Liability: |  |  |  |
| Principal | $ | 575.0 |  |  | $ | 575.0 |  |
| Less: debt discount and debt issuance costs, net of amortization | 62.7 |  |  | 74.8 |  |
| Net carrying amount | $ | 512.3 |  |  | $ | 500.2 |  |
| Equity | $ | 109.8 |  |  | $ | 109.8 |  |


## us-gaap:DebtDisclosureTextBlock

[0001327567-17-000007:notes:55]
Convertible Senior Notes

[0001327567-17-000007:notes:56]
On June 30, 2014, we issued $575.0 million aggregate principal amount of 0.0% Convertible Senior Notes due 2019 (the “Notes”). The Notes mature on July 1, 2019, unless converted or repurchased in accordance with their terms prior to such date. The Notes do not contain any financial covenants and we cannot redeem the Notes prior to maturity.

[0001327567-17-000007:notes:57]
The Notes are convertible for up to 5.2 million shares of our common stock at an initial conversion price of approximately $110.28 per share of common stock, subject to adjustment. Holders of the Notes may surrender their Notes for conversion at their option at any time prior to the close of business on the business day immediately preceding January 1, 2019, only under the following circumstances:

[0001327567-17-000007:notes:58]
| • | if the last reported sale price of our common stock for at least 20 trading days (whether or not consecutive) during a period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the conversion price for the Notes on each applicable trading day (the “sale price condition”); |

[0001327567-17-000007:notes:59]
| • | during the five business day period after any five consecutive trading day period, in which the trading price per $1,000 principal amount of Notes for each trading day of the measurement period was less than 98% of the product of the last reported sale price of our common stock and the conversion rate for the Notes on each such trading day; or |

[0001327567-17-000007:notes:60]
| • | upon the occurrence of specified corporate events. |

[0001327567-17-000007:notes:61]
On or after January 1, 2019, holders may convert all or any portion of their Notes at any time prior to the close of business on the second scheduled trading day immediately preceding the maturity date regardless of the foregoing conditions. Upon conversion, holders will receive cash equal to the aggregate principal amount of the Notes to be converted, and, at our election, cash and/or shares of our common stock for any amounts in excess of the aggregate principal amount of the Notes being converted.

[0001327567-17-000007:notes:62]
The sale price condition was not met during the fiscal quarter ended January 31, 2017. Since the Notes were not convertible, the net carrying amount of the Notes was classified as a long-term liability and the equity component was included in additional paid-in capital in our condensed consolidated balance sheets as of January 31, 2017.

[0001327567-17-000007:notes:63]
The total estimated fair value of the Notes was $820.2 million and $761.9 million at January 31, 2017 and July 31, 2016, respectively. The fair value was determined based on the closing trading price per $100 of the Notes as of the last day of trading for the period. We consider the fair value of the Notes at January 31, 2017 and July 31, 2016 to be a Level 2 measurement. The fair value of the Notes is primarily affected by the trading price of our common stock and market interest rates. As of January 31, 2017, the if-converted value of the Notes exceeded its principal amount by $125.0 million.

[0001327567-17-000007:notes:64]
The following table sets forth interest expense recognized related to the Notes (dollars in millions):

[0001327567-17-000007:notes:65]
|  | Three Months Ended January 31, |  | Six Months Ended January 31, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Amortization of debt discount | $ | 5.5 |  |  | $ | 5.2 |  |  | $ | 10.9 |  |  | $ | 10.4 |  |
| Amortization of debt issuance costs | 0.6 |  |  | 0.6 |  |  | 1.2 |  |  | 1.1 |  |
| Total interest expense recognized | $ | 6.1 |  |  | $ | 5.8 |  |  | $ | 12.1 |  |  | $ | 11.5 |  |
| Effective interest rate of the liability component | 4.8 | % |  | 4.8 | % |  | 4.8 | % |  | 4.8 | % |

[0001327567-17-000007:notes:66]
Note Hedges

[0001327567-17-000007:notes:67]
To minimize the impact of potential economic dilution upon conversion of the Notes, we entered into convertible note hedge transactions (the “Note Hedges”) with respect to our common stock concurrent with the issuance of the Notes. The Note Hedges cover up to 5.2 million shares of our common stock and are exercisable upon conversion of the Notes. The Note Hedges will expire upon maturity of the Notes. The Note Hedges are separate transactions and are not part of the terms of the Notes. Holders of the Notes will not have any rights with respect to the Note Hedges. The shares receivable related to the Note Hedges are excluded from the calculation of diluted earnings per share as they are antidilutive.

[0001327567-17-000007:notes:68]
Warrants

[0001327567-17-000007:notes:69]
Separately, but concurrently with our issuance of the Notes, we entered into transactions whereby we sold warrants (the “Warrants”) to acquire up to 5.2 million shares of our common stock at a strike price of approximately $137.85 per share, subject to adjustments. The shares issuable under the Warrants will be included in the calculation of diluted earnings per share when the average market value per share of our common stock for the reporting period exceeds the strike price of the Warrants. The Warrants are separate transactions and are not part of the Notes or Notes Hedges, and are not remeasured through earnings each reporting period. Holders of the Notes and Note Hedges will not have any rights with respect to the Warrants.

[0001327567-17-000007:notes:70]
For more information on the Notes, the Note Hedges, and the Warrants, refer to Note 7. Convertible Senior Notes included in Part II, Item 8 of our Annual Report on Form 10-K for the fiscal year ended July 31, 2016.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001327567-17-000007:notes:71]
Derivative Instruments

[0001327567-17-000007:notes:72]
[same as prior period, unchanged from 0001327567-16-000073:notes:61]

[0001327567-17-000007:notes:73]
[same as prior period, unchanged from 0001327567-16-000073:notes:62]

[0001327567-17-000007:notes:74]
[same as prior period, unchanged from 0001327567-16-000073:notes:63]

[0001327567-17-000007:notes:75]
Beginning August 2016, we entered into forward contracts to hedge the foreign currency exchange rate risk arising from our euro-denominated expenditures to be incurred during the fiscal year ending July 31, 2017. As of January 31, 2017, the total notional amount of our outstanding foreign currency forward contracts was $54.4 million. Refer to Note 2. Fair Value Measurements for the fair value of our derivative instruments as reported in our condensed consolidated balance sheets as of January 31, 2017.

[0001327567-17-000007:notes:76]
During the three and six months ended January 31, 2017, both unrealized losses recognized in AOCI related to the effective portion of our cash flow hedges and amounts reclassified into earnings were not material. Total unrealized losses in AOCI related to the effective portion of our cash flow hedges as of January 31, 2017 were also not material.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001327567-17-000007:notes:77]
[same as prior period, unchanged from 0001327567-16-000073:notes:66]

[0001327567-17-000007:notes:78]
[same as prior period, unchanged from 0001327567-16-000073:notes:67]

[0001327567-17-000007:notes:79]
[same as prior period, unchanged from 0001327567-16-000073:notes:68]

[0001327567-17-000007:notes:80]
|  | Options Outstanding |
|  | Number of Shares |  | Weighted- Average Exercise Price Per Share |  | Weighted- Average Remaining Contractual Term (Years) |  | Aggregate Intrinsic Value |
| Balance—July 31, 2016 | 2.1 |  |  | $ | 13.42 |  |  | 5.2 |  | $ | 244.9 |  |
| Options granted | — |  |  | — |  |  |  |  |  |
| Options forfeited | — |  |  | — |  |  |  |  |  |
| Options exercised | (0.4 | ) |  | 15.48 |  |  |  |  |  |
| Balance—January 31, 2017 | 1.7 |  |  | $ | 12.99 |  |  | 4.7 |  | $ | 232.5 |  |
| Options exercisable—January 31, 2017 | 1.7 |  |  | $ | 12.99 |  |  | 4.7 |  | $ | 232.5 |  |

[0001327567-17-000007:notes:81]
[same as prior period, unchanged from 0001327567-16-000073:notes:70]

[0001327567-17-000007:notes:82]
In October 2016, we granted PSAs to our employees, which will vest over a period of four years from the date of grant. The actual number of PSAs earned and eligible to vest will be determined based on level of achievement against a pre-established billings target for the fiscal year ending July 31, 2017, with a maximum of 0.2 million shares issuable at the end of the performance period. Share-based compensation expense for our PSAs is recognized on a straight-line basis over the requisite service period for each separately vesting portion of the award when it is probable that the performance condition will be achieved.

[0001327567-17-000007:notes:83]
[same as prior period, unchanged from 0001327567-16-000073:notes:72]

[0001327567-17-000007:notes:84]
|  | RSAs and PSAs Outstanding |  | RSUs Outstanding |
|  | Number of Shares |  | Weighted- Average Grant-Date Fair Value Per Share |  | Number of Shares |  | Weighted- Average Grant-Date Fair Value Per Share |  | Weighted- Average Remaining Contractual Term (Years) |  | Aggregate Intrinsic Value |
| Balance—July 31, 2016 | 1.1 |  |  | $ | 170.97 |  |  | 6.5 |  |  | $ | 130.14 |  |  | 1.1 |  | $ | 852.7 |  |
| Granted(1) | 0.3 |  |  | 148.54 |  |  | 2.4 |  |  | 147.47 |  |  |  |  |  |
| Vested | (0.2 | ) |  | 170.97 |  |  | (1.9 | ) |  | 116.72 |  |  |  |  |  |
| Forfeited | — |  |  | — |  |  | (0.3 | ) |  | 138.69 |  |  |  |  |  |
| Balance—January 31, 2017 | 1.2 |  |  | $ | 164.82 |  |  | 6.7 |  |  | $ | 139.77 |  |  | 1.3 |  | $ | 989.0 |  |

[0001327567-17-000007:notes:85]
[same as prior period, unchanged from 0001327567-16-000073:notes:75]

[0001327567-17-000007:notes:86]
[same as prior period, unchanged from 0001327567-16-000073:notes:76]

[0001327567-17-000007:notes:87]
[same as prior period, unchanged from 0001327567-16-000073:notes:77]

[0001327567-17-000007:notes:88]
|  | Three Months Ended January 31, |  | Six Months Ended January 31, |
|  | 2017 |  | 2016 |  | 2017(1) |  | 2016 |
| Cost of product revenue | $ | 2.0 |  |  | $ | 1.6 |  |  | $ | 3.7 |  |  | $ | 2.9 |  |
| Cost of subscription and support revenue | 15.0 |  |  | 10.5 |  |  | 27.3 |  |  | 17.5 |  |
| Research and development | 41.3 |  |  | 34.9 |  |  | 79.3 |  |  | 59.9 |  |
| Sales and marketing | 49.7 |  |  | 39.4 |  |  | 93.5 |  |  | 66.6 |  |
| General and administrative | 19.3 |  |  | 15.5 |  |  | 36.8 |  |  | 27.9 |  |
| Total share-based compensation | $ | 127.3 |  |  | $ | 101.9 |  |  | $ | 240.6 |  |  | $ | 174.8 |  |

[0001327567-17-000007:notes:89]
| (1) | Amounts reflect an adjustment for the three months ended October 31, 2016, due to our early adoption of new share-based payment accounting guidance. Refer to Note 1. Description of Business and Summary of Significant Accounting Policies for more information. |

[0001327567-17-000007:notes:90]
As of January 31, 2017, total compensation cost related to unvested share-based awards not yet recognized was $989.7 million. This cost is expected to be amortized on a straight-line basis over a weighted-average period of approximately 2.6 years.


## us-gaap:EarningsPerShareTextBlock

[0001327567-17-000007:notes:91]
[same as prior period, unchanged from 0001327567-16-000073:notes:80]

[0001327567-17-000007:notes:92]
[same as prior period, unchanged from 0001327567-16-000073:notes:81]

[0001327567-17-000007:notes:93]
[same as prior period, unchanged from 0001327567-16-000073:notes:82]

[0001327567-17-000007:notes:94]
|  | Three Months Ended |  | Six Months Ended |
|  | January 31, |  | January 31, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Net loss | $ | (60.6 | ) |  | $ | (57.3 | ) |  | $ | (117.5 | ) |  | $ | (97.2 | ) |
| Weighted-average shares used to compute net loss per share, basic and diluted | 90.7 |  |  | 86.6 |  |  | 90.2 |  |  | 85.8 |  |
| Net loss per share, basic and diluted | $ | (0.67 | ) |  | $ | (0.66 | ) |  | $ | (1.30 | ) |  | $ | (1.13 | ) |

[0001327567-17-000007:notes:95]
[same as prior period, unchanged from 0001327567-16-000073:notes:84]

[0001327567-17-000007:notes:96]
|  | Three and Six Months Ended |
|  | January 31, |
|  | 2017 |  | 2016 |
| RSUs | 6.7 |  |  | 7.5 |  |
| Convertible senior notes | 5.2 |  |  | 5.2 |  |
| Warrants related to the issuance of convertible senior notes | 5.2 |  |  | 5.2 |  |
| Options to purchase common stock | 1.7 |  |  | 2.5 |  |
| RSAs and PSAs | 1.2 |  |  | 1.1 |  |
| ESPP shares | 0.1 |  |  | 0.1 |  |
| Total | 20.1 |  |  | 21.6 |  |


## us-gaap:FairValueAssetsAndLiabilitiesMeasuredOnRecurringAndNonrecurringBasisTableTextBlock

[0001327567-17-000007:notes:97]
The following table presents the fair value of our financial assets and liabilities using the above input categories as of January 31, 2017 and July 31, 2016 (in millions):

[0001327567-17-000007:notes:98]
|  |  | January 31, 2017 |  | July 31, 2016 |
|  |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Cash equivalents: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. government and agency securities |  | $ | — |  |  | $ | 2.0 |  |  | $ | — |  |  | $ | 2.0 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Total cash equivalents |  | — |  |  | 2.0 |  |  | — |  |  | 2.0 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Short-term investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Commercial paper |  | — |  |  | 17.9 |  |  | — |  |  | 17.9 |  |  | — |  |  | 3.0 |  |  | — |  |  | 3.0 |  |
| Corporate debt securities |  | — |  |  | 99.7 |  |  | — |  |  | 99.7 |  |  | — |  |  | 121.4 |  |  | — |  |  | 121.4 |  |
| U.S. government and agency securities |  | — |  |  | 475.4 |  |  | — |  |  | 475.4 |  |  | — |  |  | 426.8 |  |  | — |  |  | 426.8 |  |
| Total short-term investments |  | — |  |  | 593.0 |  |  | — |  |  | 593.0 |  |  | — |  |  | 551.2 |  |  | — |  |  | 551.2 |  |
| Long-term investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Certificates of deposit |  | — |  |  | 5.4 |  |  | — |  |  | 5.4 |  |  | — |  |  | 5.4 |  |  | — |  |  | 5.4 |  |
| Corporate debt securities |  | — |  |  | 229.6 |  |  | — |  |  | 229.6 |  |  | — |  |  | 166.1 |  |  | — |  |  | 166.1 |  |
| U.S. government and agency securities |  | — |  |  | 555.5 |  |  | — |  |  | 555.5 |  |  | — |  |  | 481.3 |  |  | — |  |  | 481.3 |  |
| Total long-term investments |  | — |  |  | 790.5 |  |  | — |  |  | 790.5 |  |  | — |  |  | 652.8 |  |  | — |  |  | 652.8 |  |
| Total assets measured at fair value |  | $ | — |  |  | $ | 1,385.5 |  |  | $ | — |  |  | $ | 1,385.5 |  |  | $ | — |  |  | $ | 1,204.0 |  |  | $ | — |  |  | $ | 1,204.0 |  |
| Accrued and other liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency forward contracts |  | $ | — |  |  | $ | 1.9 |  |  | $ | — |  |  | $ | 1.9 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Total accrued and other liabilities |  | — |  |  | 1.9 |  |  | — |  |  | 1.9 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Total liabilities measured at fair value |  | $ | — |  |  | $ | 1.9 |  |  | $ | — |  |  | $ | 1.9 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001327567-17-000007:notes:99]
[same as prior period, unchanged from 0001327567-16-000073:notes:88]

[0001327567-17-000007:notes:100]
[same as prior period, unchanged from 0001327567-16-000073:notes:89]

[0001327567-17-000007:notes:101]
[same as prior period, unchanged from 0001327567-16-000073:notes:90]

[0001327567-17-000007:notes:102]
[same as prior period, unchanged from 0001327567-16-000073:notes:91]

[0001327567-17-000007:notes:103]
[same as prior period, unchanged from 0001327567-16-000073:notes:92]

[0001327567-17-000007:notes:104]
Refer to Note 5. Convertible Senior Notes for the carrying amount and estimated fair value of our convertible senior notes as of January 31, 2017 and July 31, 2016.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001327567-17-000007:notes:105]
[same as prior period, unchanged from 0001327567-16-000073:notes:94]

[0001327567-17-000007:notes:106]
Our provision for income taxes for the three and six months ended January 31, 2017 reflects an effective tax rate of (4.8)% and (6.5)%, respectively. Our effective tax rates for these periods were negative as we recorded a provision for income taxes on year to date losses. The key components of our income tax provision primarily consist of foreign income taxes, withholding taxes, and amortization of our deferred tax charges. Our effective tax rate differs from the U.S. statutory tax rate primarily due to changes in non-deductible share-based compensation, foreign income at other than U.S. tax rates, and changes in our valuation allowance. As compared to the same periods last year, our effective tax rate changed primarily due to an increase in non-deductible share-based compensation, foreign income at other than U.S. tax rates, and changes in our valuation allowance.

[0001327567-17-000007:notes:107]
Our provision for income taxes for the three and six months ended January 31, 2016 reflects an effective tax rate of (7.3)% and (9.2)%, respectively. Our effective tax rates for these periods were negative as we recorded a provision for income taxes on year to date losses. The key components of our income tax provision primarily consisted of foreign income taxes, withholding taxes, U.S. federal and state income taxes, and amortization of our deferred tax charges. Key components of our effective tax rate consisted of foreign tax losses which derive no benefit, non-deductible share-based compensation, and changes in our valuation allowance.

[0001327567-17-000007:notes:108]
As of January 31, 2017, we had $265.4 million of unrecognized tax benefits, $24.0 million of which would affect income tax expense if recognized, after consideration of our valuation allowance in the United States and other assets. As of July 31, 2016, we had $127.7 million of unrecognized tax benefits, $21.9 million of which would affect income tax expense if recognized, after consideration of our valuation allowance in the United States and other assets. The increase in unrecognized tax benefits since July 31, 2016 relates to positions taken relating to transfer pricing in the current year. As of January 31, 2017, our federal, state, and foreign returns for the tax years 2008 through the current period remain open to examination. Fiscal years outside the normal statute of limitation remain open to audit by tax authorities due to tax attributes generated in earlier years, which have been carried forward and may be audited in subsequent years when utilized. We do not expect our unrecognized tax benefits to change significantly over the next 12 months. We recognize both interest and penalties associated with uncertain tax positions as a component of income tax expense. The ultimate amount and timing of any future cash settlements cannot be predicted with reasonable certainty.


## us-gaap:InvestmentsClassifiedByContractualMaturityDateTableTextBlock

[0001327567-17-000007:notes:109]
The following table summarizes the amortized cost and fair value of our available-for-sale investments as of January 31, 2017, by contractual years-to-maturity (in millions):

[0001327567-17-000007:notes:110]
|  | Amortized Cost |  | Fair Value |
| Due within one year | $ | 595.2 |  |  | $ | 595.0 |  |
| Due between one and three years | 793.4 |  |  | 790.5 |  |
| Total | $ | 1,388.6 |  |  | $ | 1,385.5 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001327567-17-000007:notes:111]
Investments

[0001327567-17-000007:notes:112]
Unrealized losses related to these investments are due to interest rate fluctuations as opposed to credit quality. In addition, we do not intend to sell and it is not likely that we would be required to sell these investments before recovery of their amortized cost basis, which may be at maturity. As a result, there were no other-than-temporary impairments for these investments at January 31, 2017 and July 31, 2016.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001327567-17-000007:notes:113]
[same as prior period, unchanged from 0001327567-16-000073:notes:101]

[0001327567-17-000007:notes:114]
[same as prior period, unchanged from 0001327567-16-000073:notes:102]

[0001327567-17-000007:notes:115]
On August 26, 2016, our board of directors authorized a $500.0 million share repurchase which is funded from available working capital. Repurchases may be made at management’s discretion from time to time on the open market, through privately negotiated transactions, transactions structured through investment banking institutions, block purchase techniques, 10b5-1 trading plans, or a combination of the foregoing. The repurchase authorization will expire on August 31, 2018, and may be suspended or discontinued at any time. During the three and six months ended January 31, 2017, we repurchased and retired 0.9 million and 1.3 million shares, respectively, of our common stock under the authorization for an aggregate purchase price of $120.1 million and $170.1 million, respectively. The total price of the shares repurchased and related transaction costs are reflected as a reduction to common stock and additional paid-in capital on our condensed consolidated balance sheets. As of January 31, 2017, $329.9 million remained available for future share repurchases under the repurchase authorization.


## us-gaap:SubsequentEventsTextBlock

[0001327567-17-000007:notes:116]
Subsequent Events

[0001327567-17-000007:notes:117]
Business Combination

[0001327567-17-000007:notes:118]
On February 27, 2017, we completed our acquisition of LightCyber Ltd. (“LightCyber”), a privately-held cybersecurity company, in exchange for total consideration of approximately $105.0 million in cash. The acquisition expands the functionality of our next-generation security platform with the addition of LightCyber’s behavioral analytics technology. We are currently in the process of finalizing the accounting for this transaction and expect to complete our preliminary allocation of the purchase consideration to the assets acquired and liabilities assumed by the end of our third quarter of fiscal 2017.

[0001327567-17-000007:notes:119]
On February 24, 2017, our board of directors authorized a $500.0 million increase to our existing share repurchase program, bringing the total authorization to $1.0 billion. Repurchases may be made at management’s discretion from time to time on the open market, through privately negotiated transactions, transactions structured through investment banking institutions, block purchase techniques, 10b5-1 trading plans, or a combination of the foregoing, and will be funded from available working capital. Additionally, our board of directors extended the term of the repurchase authorization, which will now expire on December 31, 2018, and may be suspended or discontinued at any time. Refer to Note 7. Stockholders’ Equity for more information on our existing repurchase authorization as of January 31, 2017.
