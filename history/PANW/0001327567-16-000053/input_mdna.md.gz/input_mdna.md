# PANW MD&A — 0001327567-16-000053


## mdna

[0001327567-16-000053:mdna:1]
[same as prior period, unchanged from 0001327567-16-000048:mdna:1]

[0001327567-16-000053:mdna:2]
[same as prior period, unchanged from 0001327567-16-000048:mdna:2]

[0001327567-16-000053:mdna:3]
[same as prior period, unchanged from 0001327567-16-000048:mdna:3]

[0001327567-16-000053:mdna:4]
[same as prior period, unchanged from 0001327567-16-000048:mdna:4]

[0001327567-16-000053:mdna:5]
| • | Results of Operations. A discussion of the nature and trends in our financial results and an analysis of our financial results comparing the three and nine months ended April 30, 2016 to the three and nine months ended April 30, 2015. |

[0001327567-16-000053:mdna:6]
[same as prior period, unchanged from 0001327567-16-000048:mdna:6]

[0001327567-16-000053:mdna:7]
| • | Contractual Obligations and Commitments. An overview of our contractual obligations, contingent liabilities, commitments, and off-balance sheet arrangements outstanding as of April 30, 2016, including expected payment schedules. |

[0001327567-16-000053:mdna:8]
[same as prior period, unchanged from 0001327567-16-000048:mdna:8]

[0001327567-16-000053:mdna:9]
[same as prior period, unchanged from 0001327567-16-000048:mdna:9]

[0001327567-16-000053:mdna:10]
[same as prior period, unchanged from 0001327567-16-000048:mdna:10]

[0001327567-16-000053:mdna:11]
[same as prior period, unchanged from 0001327567-16-000048:mdna:11]

[0001327567-16-000053:mdna:12]
[same as prior period, unchanged from 0001327567-16-000048:mdna:12]

[0001327567-16-000053:mdna:13]
[same as prior period, unchanged from 0001327567-16-000048:mdna:13]

[0001327567-16-000053:mdna:14]
For the third quarter of fiscal 2016 and 2015, revenues were $345.8 million and $234.2 million, respectively, representing year-over-year growth of 47.7%. Our growth reflects the increased adoption of our hybrid SaaS revenue model, which consists of product, subscriptions, and support and maintenance. We believe this model will enable us to benefit from recurring revenues as we continue to grow our installed end-customer base. As of April 30, 2016, we had sold our products and services to more than 31,000 end-customers in over 140 countries. Our end-customers represent a broad range of industries including education, energy, financial services, government entities, healthcare, Internet and media, manufacturing, public sector, and telecommunications, and include some of the largest Fortune 100 and Global 2000 companies in the world.

[0001327567-16-000053:mdna:15]
Our product revenue grew to $162.1 million or 46.9% of total revenue for the third quarter of fiscal 2016, representing year-over-year growth of 33.4%. Product revenue is generated from sales of our appliances, primarily our Next-Generation Firewall, which is available in physical and virtualized form. Our Next-Generation Firewall incorporates our proprietary PAN-OS operating system, which provides a consistent set of capabilities across our entire product line. Our products are designed for different performance requirements throughout an organization, ranging from our PA-200, which is designed for enterprise remote offices, to our top-of-the-line PA-7080, which was released in August 2015 and is especially suited for service provider customers. The same firewall functionality that is delivered in our physical appliances is also available in our VM-Series virtual firewalls, which secure virtualized and cloud-based computing environments.

[0001327567-16-000053:mdna:16]
Our recurring services revenue grew to $183.7 million or 53.1% of total revenue for the third quarter of fiscal 2016, representing year-over-year growth of 63.0%, led by revenue from subscription services, which grew 68.9% to $92.6 million, and followed by support and maintenance services, which grew 57.4% to $91.1 million. Our subscriptions include two new services released during the first quarter of fiscal 2016: our Aperture subscription service, which provides content control for IT-sanctioned SaaS applications that are used to store and share end-customer’s data, and our AutoFocus cyber threat intelligence service, which provides prioritized actionable intelligence on targeted cyber attacks. Our subscriptions provide our end-customers with real-time access to the latest antivirus, intrusion prevention, web filtering, and modern malware prevention capabilities across fixed and mobile devices.

[0001327567-16-000053:mdna:17]
We maintain a field sales force that works closely with our channel partners in developing sales opportunities. We use a two-tier, indirect fulfillment model whereby we sell our products and services to our global distributor channel partners, which, in turn, sell our products and services to our reseller network, which then sell to our end-customers. When end-customers purchase an appliance, they typically purchase one or more of our subscriptions for additional functionality, as well as support and maintenance in order to receive ongoing security updates, upgrades, bug fixes, and repairs.

[0001327567-16-000053:mdna:18]
We believe that the growth of our business and our short-term and long-term success are dependent upon many factors, including our ability to extend our technology leadership, grow our base of end-customers, expand deployment of our platform and services within existing end-customers, extend the length of service terms within existing end-customers, and focus on end-customer satisfaction. To manage any future growth effectively, we must continue to improve and expand our information technology and financial infrastructure, our operating and administrative systems and controls, and our ability to manage headcount, capital, and processes in an efficient manner. While these areas present significant opportunities for us, they also pose challenges and risks that we must successfully address in order to sustain the growth of our business and improve our operating results. For additional information regarding the challenges and risks we face, see the “Risk Factors” section in Part II, Item 1A of this Quarterly Report on Form 10-Q.

[0001327567-16-000053:mdna:19]
[same as prior period, unchanged from 0001327567-16-000048:mdna:20]

[0001327567-16-000053:mdna:20]
[same as prior period, unchanged from 0001327567-16-000048:mdna:21]

[0001327567-16-000053:mdna:21]
[same as prior period, unchanged from 0001327567-16-000048:mdna:22]

[0001327567-16-000053:mdna:22]
|  | April 30, 2016 |  | July 31, 2015 |
|  | (in millions) |
| Total deferred revenue | $ | 1,069.2 |  |  | $ | 713.7 |  |
| Cash, cash equivalents, and investments | $ | 1,770.4 |  |  | $ | 1,327.8 |  |

[0001327567-16-000053:mdna:23]
|  | Three Months Ended April 30, |  | Nine Months Ended April 30, |
|  | 2016 |  | 2015 |  | 2016 |  | 2015 |
|  | (dollars in millions) |
| Total revenue | $ | 345.8 |  |  | $ | 234.2 |  |  | $ | 977.7 |  |  | $ | 644.2 |  |
| Year-over-year percentage increase | 47.7 | % |  | 55.4 | % |  | 51.8 | % |  | 53.4 | % |
| Gross margin percentage | 72.6 | % |  | 72.5 | % |  | 72.6 | % |  | 72.5 | % |
| Operating loss | $ | (58.6 | ) |  | $ | (36.7 | ) |  | $ | (144.7 | ) |  | $ | (99.0 | ) |
| Operating margin percentage | (16.9 | )% |  | (15.7 | )% |  | (14.8 | )% |  | (15.4 | )% |
| Billings (non-GAAP) | $ | 486.2 |  |  | $ | 302.2 |  |  | $ | 1,333.2 |  |  | $ | 825.5 |  |
| Cash flow provided by operating activities |  |  |  |  | $ | 470.6 |  |  | $ | 239.0 |  |
| Free cash flow (non-GAAP) |  |  |  |  | $ | 414.4 |  |  | $ | 217.1 |  |

[0001327567-16-000053:mdna:24]
[same as prior period, unchanged from 0001327567-16-000048:mdna:25]

[0001327567-16-000053:mdna:25]
[same as prior period, unchanged from 0001327567-16-000048:mdna:26]

[0001327567-16-000053:mdna:26]
[same as prior period, unchanged from 0001327567-16-000048:mdna:27]

[0001327567-16-000053:mdna:27]
| • | Free Cash Flow (non-GAAP). We define free cash flow, a non-GAAP financial measure, as cash provided by operating activities less purchases of property, equipment, and other assets. We consider free cash flow to be a profitability and liquidity measure that provides useful information to management and investors about the amount of cash generated by the business that, after the purchases of property, equipment, and other productive assets, can be used for operational expenses and for strategic opportunities, including investing in our business, making strategic acquisitions, and strengthening the balance sheet. A limitation of the utility of free cash flow as a measure of our financial performance and liquidity is that it does not represent the total increase or decrease in our cash balance for the period. In addition, it is important to note that other companies, including companies in our industry, may not use free cash flow, may calculate free cash flow in a different manner than we do, or may use other financial measures to evaluate their performance, all of which could reduce the usefulness of free cash flow as a comparative measure. A reconciliation of free cash flow to cash flow provided by operating activities, the most directly comparable financial measure calculated and presented in accordance with GAAP, is provided below: |

[0001327567-16-000053:mdna:28]
|  | Nine Months Ended April 30, |
|  | 2016 |  | 2015 |
|  | (in millions) |
| Free cash flow (non-GAAP): |  |  |  |
| Net cash provided by operating activities | $ | 470.6 |  |  | $ | 239.0 |  |
| Less: purchases of property, equipment, and other assets | 56.2 |  |  | 21.9 |  |
| Free cash flow (non-GAAP) | $ | 414.4 |  |  | $ | 217.1 |  |
| Net cash used in investing activities | $ | (339.3 | ) |  | $ | (480.6 | ) |
| Net cash provided by financing activities | $ | 42.9 |  |  | $ | 41.9 |  |

[0001327567-16-000053:mdna:29]
[same as prior period, unchanged from 0001327567-16-000048:mdna:30]

[0001327567-16-000053:mdna:30]
|  | Three Months Ended April 30, |  | Nine Months Ended April 30, |
|  | 2016 |  | 2015 |  | 2016 |  | 2015 |
|  | (in millions) |
| Billings (non-GAAP): |  |  |  |  |  |  |  |
| Total revenue | $ | 345.8 |  |  | $ | 234.2 |  |  | $ | 977.7 |  |  | $ | 644.2 |  |
| Add: change in total deferred revenue | 140.4 |  |  | 68.0 |  |  | 355.5 |  |  | 181.3 |  |
| Billings (non-GAAP) | $ | 486.2 |  |  | $ | 302.2 |  |  | $ | 1,333.2 |  |  | $ | 825.5 |  |

[0001327567-16-000053:mdna:31]
[same as prior period, unchanged from 0001327567-16-000048:mdna:32]

[0001327567-16-000053:mdna:32]
[same as prior period, unchanged from 0001327567-16-000048:mdna:33]

[0001327567-16-000053:mdna:33]
[same as prior period, unchanged from 0001327567-16-000048:mdna:34]

[0001327567-16-000053:mdna:34]
|  | Three Months Ended April 30, |  | Nine Months Ended April 30, |
|  | 2016 |  | 2015 |  | 2016 |  | 2015 |
|  | Amount |  | % of Revenue |  | Amount |  | % of Revenue |  | Amount |  | % of Revenue |  | Amount |  | % of Revenue |
|  | (dollars in millions) |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 162.1 |  |  | 46.9 | % |  | $ | 121.5 |  |  | 51.9 | % |  | $ | 479.7 |  |  | 49.1 | % |  | $ | 338.6 |  |  | 52.6 | % |
| Services | 183.7 |  |  | 53.1 | % |  | 112.7 |  |  | 48.1 | % |  | 498.0 |  |  | 50.9 | % |  | 305.6 |  |  | 47.4 | % |
| Total revenue | 345.8 |  |  | 100.0 | % |  | 234.2 |  |  | 100.0 | % |  | 977.7 |  |  | 100.0 | % |  | 644.2 |  |  | 100.0 | % |
| Cost of revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product | 43.2 |  |  | 12.5 | % |  | 32.8 |  |  | 14.0 | % |  | 126.9 |  |  | 13.0 | % |  | 92.6 |  |  | 14.4 | % |
| Services | 51.7 |  |  | 14.9 | % |  | 31.6 |  |  | 13.5 | % |  | 141.4 |  |  | 14.4 | % |  | 84.6 |  |  | 13.1 | % |
| Total cost of revenue (1) | 94.9 |  |  | 27.4 | % |  | 64.4 |  |  | 27.5 | % |  | 268.3 |  |  | 27.4 | % |  | 177.2 |  |  | 27.5 | % |
| Total gross profit | 250.9 |  |  | 72.6 | % |  | 169.8 |  |  | 72.5 | % |  | 709.4 |  |  | 72.6 | % |  | 467.0 |  |  | 72.5 | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | 74.0 |  |  | 21.4 | % |  | 48.4 |  |  | 20.7 | % |  | 207.7 |  |  | 21.2 | % |  | 132.7 |  |  | 20.6 | % |
| Sales and marketing | 202.0 |  |  | 58.4 | % |  | 131.1 |  |  | 56.0 | % |  | 547.9 |  |  | 56.0 | % |  | 360.3 |  |  | 55.9 | % |
| General and administrative | 33.5 |  |  | 9.7 | % |  | 27.0 |  |  | 11.5 | % |  | 98.5 |  |  | 10.2 | % |  | 73.0 |  |  | 11.4 | % |
| Total operating expenses (1) | 309.5 |  |  | 89.5 | % |  | 206.5 |  |  | 88.2 | % |  | 854.1 |  |  | 87.4 | % |  | 566.0 |  |  | 87.9 | % |
| Operating loss | (58.6 | ) |  | (16.9 | )% |  | (36.7 | ) |  | (15.7 | )% |  | (144.7 | ) |  | (14.8 | )% |  | (99.0 | ) |  | (15.4 | )% |
| Interest expense | (5.8 | ) |  | (1.7 | )% |  | (5.7 | ) |  | (2.4 | )% |  | (17.4 | ) |  | (1.8 | )% |  | (16.7 | ) |  | (2.6 | )% |
| Other income, net | 1.0 |  |  | 0.3 | % |  | — |  |  | — | % |  | 5.7 |  |  | 0.6 | % |  | 0.7 |  |  | 0.1 | % |
| Loss before income taxes | (63.4 | ) |  | (18.3 | )% |  | (42.4 | ) |  | (18.1 | )% |  | (156.4 | ) |  | (16.0 | )% |  | (115.0 | ) |  | (17.9 | )% |
| Provision for income taxes | 6.8 |  |  | 2.0 | % |  | 3.5 |  |  | 1.5 | % |  | 15.0 |  |  | 1.5 | % |  | 4.0 |  |  | 0.6 | % |
| Net loss | $ | (70.2 | ) |  | (20.3 | )% |  | $ | (45.9 | ) |  | (19.6 | )% |  | $ | (171.4 | ) |  | (17.5 | )% |  | $ | (119.0 | ) |  | (18.5 | )% |

[0001327567-16-000053:mdna:35]
(1)Includes share-based compensation as follows:

[0001327567-16-000053:mdna:36]
|  | Three Months Ended April 30, |  | Nine Months Ended April 30, |
|  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Cost of product revenue | $ | 1.6 |  |  | $ | 1.0 |  |  | $ | 4.5 |  |  | $ | 2.7 |  |
| Cost of services revenue | 11.5 |  |  | 5.6 |  |  | 29.0 |  |  | 14.2 |  |
| Research and development | 36.0 |  |  | 19.8 |  |  | 95.9 |  |  | 52.8 |  |
| Sales and marketing | 43.8 |  |  | 22.2 |  |  | 110.4 |  |  | 59.7 |  |
| General and administrative | 15.6 |  |  | 11.6 |  |  | 43.5 |  |  | 26.2 |  |
| Total share-based compensation | $ | 108.5 |  |  | $ | 60.2 |  |  | $ | 283.3 |  |  | $ | 155.6 |  |

[0001327567-16-000053:mdna:37]
[same as prior period, unchanged from 0001327567-16-000048:mdna:41]

[0001327567-16-000053:mdna:38]
[same as prior period, unchanged from 0001327567-16-000048:mdna:36]

[0001327567-16-000053:mdna:39]
We derive revenue from sales of our products and services. Revenue is recognized when persuasive evidence of an arrangement exists, delivery has occurred, the fee is fixed or determinable, and collectability is reasonably assured. We expect our revenue to vary from quarter to quarter based on seasonal and cyclical factors.

[0001327567-16-000053:mdna:40]
[same as prior period, unchanged from 0001327567-16-000048:mdna:38]

[0001327567-16-000053:mdna:41]
| • | Product Revenue. Product revenue is derived primarily from sales of our appliances. Product revenue also includes revenue derived from software licenses of Panorama, GlobalProtect, and the VM-Series. We recognize product revenue at the time of shipment, provided that all other revenue recognition criteria have been met. |

[0001327567-16-000053:mdna:42]
[same as prior period, unchanged from 0001327567-16-000048:mdna:40]

[0001327567-16-000053:mdna:43]
|  | Three Months Ended April 30, |  |  |  |  |  | Nine Months Ended April 30, |  |  |  |  |
|  | 2016 |  | 2015 |  | Change |  | 2016 |  | 2015 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 162.1 |  |  | $ | 121.5 |  |  | $ | 40.6 |  |  | 33.4 | % |  | $ | 479.7 |  |  | $ | 338.6 |  |  | $ | 141.1 |  |  | 41.7 | % |
| Services |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Subscription | 92.6 |  |  | 54.8 |  |  | 37.8 |  |  | 68.9 | % |  | 250.5 |  |  | 148.6 |  |  | 101.9 |  |  | 68.6 | % |
| Support and maintenance | 91.1 |  |  | 57.9 |  |  | 33.2 |  |  | 57.4 | % |  | 247.5 |  |  | 157.0 |  |  | 90.5 |  |  | 57.7 | % |
| Total services | 183.7 |  |  | 112.7 |  |  | 71.0 |  |  | 63.0 | % |  | 498.0 |  |  | 305.6 |  |  | 192.4 |  |  | 63.0 | % |
| Total revenue | $ | 345.8 |  |  | $ | 234.2 |  |  | $ | 111.6 |  |  | 47.7 | % |  | $ | 977.7 |  |  | $ | 644.2 |  |  | $ | 333.5 |  |  | 51.8 | % |
| Revenue by geographic theater: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 246.3 |  |  | $ | 157.7 |  |  | $ | 88.6 |  |  | 56.2 | % |  | $ | 687.3 |  |  | $ | 436.6 |  |  | $ | 250.7 |  |  | 57.4 | % |
| EMEA | 61.4 |  |  | 45.9 |  |  | 15.5 |  |  | 33.9 | % |  | 177.2 |  |  | 129.2 |  |  | 48.0 |  |  | 37.2 | % |
| APAC | 38.1 |  |  | 30.6 |  |  | 7.5 |  |  | 24.4 | % |  | 113.2 |  |  | 78.4 |  |  | 34.8 |  |  | 44.5 | % |
| Total revenue | $ | 345.8 |  |  | $ | 234.2 |  |  | $ | 111.6 |  |  | 47.7 | % |  | $ | 977.7 |  |  | $ | 644.2 |  |  | $ | 333.5 |  |  | 51.8 | % |

[0001327567-16-000053:mdna:44]
Product revenue increased for the three and nine months ended April 30, 2016 compared to the three and nine months ended April 30, 2015. The increases in both periods were driven by increased demand for our higher end appliances. The change in product revenue due to pricing was not significant for either period.

[0001327567-16-000053:mdna:45]
Services revenue increased for the three and nine months ended April 30, 2016 compared to the three and nine months ended April 30, 2015. The increases in both periods were due to the adoption of subscriptions and high renewal rates for both subscriptions and support and maintenance services. The mix between subscription revenue and support and maintenance revenue will fluctuate over time, depending on the introduction of new subscription offerings, renewals of support and maintenance services, and our ability to increase sales to new and existing customers. The change in services revenue due to pricing was not significant for either period.

[0001327567-16-000053:mdna:46]
With respect to geographic theaters, the Americas contributed the largest portion of the increase in revenue for the three and nine months ended April 30, 2016 compared to the three and nine months ended April 30, 2015, due to its larger and more established sales force compared to our other theaters. Revenue from both Europe, the Middle East, and Africa (“EMEA”) and Asia Pacific and Japan (“APAC”) increased for the three and nine months ended April 30, 2016 compared to the three and nine months ended April 30, 2015, due to our investment in increasing the size of our sales force and number of channel partners in these theaters.

[0001327567-16-000053:mdna:47]
[same as prior period, unchanged from 0001327567-16-000048:mdna:46]

[0001327567-16-000053:mdna:48]
[same as prior period, unchanged from 0001327567-16-000048:mdna:47]

[0001327567-16-000053:mdna:49]
[same as prior period, unchanged from 0001327567-16-000048:mdna:50]

[0001327567-16-000053:mdna:50]
Cost of Product Revenue

[0001327567-16-000053:mdna:51]
Cost of product revenue primarily includes costs paid to our third-party contract manufacturer. Our cost of product revenue also includes amortization of intellectual property licenses, product testing costs, warranty costs, shipping costs, and personnel costs, which consist of salaries, benefits, bonuses, and share-based compensation associated with our operations organization. In addition, our cost of product revenue also includes allocated costs, which consist of certain facilities, depreciation, benefits, recruiting, and information technology costs that we allocate based on headcount. We expect our cost of product revenue to increase as our product revenue increases.

[0001327567-16-000053:mdna:52]
|  | Three Months Ended April 30, |  |  |  | Nine Months Ended April 30, |  |  |  |  |
|  | 2016 |  | 2015 |  | Change |  | 2016 |  | 2015 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Cost of product revenue | $ | 43.2 |  |  | $ | 32.8 |  |  | $ | 10.4 |  |  | 31.5 | % |  | $ | 126.9 |  |  | $ | 92.6 |  |  | $ | 34.3 |  |  | 37.0 | % |
| Number of employees at period end | 86 |  |  | 64 |  |  | 22 |  |  | 34.4 | % |  | 86 |  |  | 64 |  |  | 22 |  |  | 34.4 | % |

[0001327567-16-000053:mdna:53]
Cost of product revenue increased for the three and nine months ended April 30, 2016 compared to the three and nine months ended April 30, 2015. The increases in both periods were due to an increase in product unit volume for our higher end appliances.

[0001327567-16-000053:mdna:54]
Cost of Services Revenue

[0001327567-16-000053:mdna:55]
Cost of services revenue includes personnel costs for our global customer support and technical operations organizations, amortization of acquired intangible assets, and allocated costs. We expect our cost of services revenue to increase as our installed end-customer base grows.

[0001327567-16-000053:mdna:56]
|  | Three Months Ended April 30, |  |  |  | Nine Months Ended April 30, |  |  |  |  |
|  | 2016 |  | 2015 |  | Change |  | 2016 |  | 2015 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Cost of services revenue | $ | 51.7 |  |  | $ | 31.6 |  |  | $ | 20.1 |  |  | 63.8 | % |  | $ | 141.4 |  |  | $ | 84.6 |  |  | $ | 56.8 |  |  | 67.2 | % |
| Number of employees at period end | 514 |  |  | 316 |  |  | 198 |  |  | 62.7 | % |  | 514 |  |  | 316 |  |  | 198 |  |  | 62.7 | % |

[0001327567-16-000053:mdna:57]
Cost of services revenue increased for the three and nine months ended April 30, 2016 compared to the three and nine months ended April 30, 2015. The increases in both periods were driven by increases in personnel costs, which grew $11.7 million to $28.2 million for the three months ended April 30, 2016 compared to the three months ended April 30, 2015 and grew $30.8 million to $74.7 million for the nine months ended April 30, 2016 compared to the nine months ended April 30, 2015. The increases in personnel costs in both periods were due to headcount growth. The remaining increases in both periods were driven by increases in expenses incurred to expand our customer service capabilities and infrastructure to support our growing installed end-customer base.

[0001327567-16-000053:mdna:58]
[same as prior period, unchanged from 0001327567-16-000048:mdna:55]

[0001327567-16-000053:mdna:59]
[same as prior period, unchanged from 0001327567-16-000048:mdna:56]

[0001327567-16-000053:mdna:60]
[same as prior period, unchanged from 0001327567-16-000048:mdna:60]

[0001327567-16-000053:mdna:61]
|  | Three Months Ended April 30, |  | Nine Months Ended April 30, |
|  | 2016 |  | 2015 |  | 2016 |  | 2015 |
|  | Amount |  | Gross Margin |  | Amount |  | Gross Margin |  | Amount |  | Gross Margin |  | Amount |  | Gross Margin |
|  | (dollars in millions) |
| Gross profit: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 118.9 |  |  | 73.4 | % |  | $ | 88.7 |  |  | 73.0 | % |  | $ | 352.8 |  |  | 73.5 | % |  | $ | 246.0 |  |  | 72.6 | % |
| Services | 132.0 |  |  | 71.9 | % |  | 81.1 |  |  | 72.0 | % |  | 356.6 |  |  | 71.6 | % |  | 221.0 |  |  | 72.3 | % |
| Total gross profit | $ | 250.9 |  |  | 72.6 | % |  | $ | 169.8 |  |  | 72.5 | % |  | $ | 709.4 |  |  | 72.6 | % |  | $ | 467.0 |  |  | 72.5 | % |

[0001327567-16-000053:mdna:62]
Product gross margin increased for the three and nine months ended April 30, 2016 compared to the three and nine months ended April 30, 2015. The increases in both periods were driven by our continued focus on material cost reductions. Services gross margin decreased for the three and nine months ended April 30, 2016 compared to the three and nine months ended April 30, 2015. The decreases in both periods were driven by headcount growth within our global customer support organization in order to support our growing installed end-customer base.

[0001327567-16-000053:mdna:63]
[same as prior period, unchanged from 0001327567-16-000048:mdna:62]

[0001327567-16-000053:mdna:64]
Our operating expenses consist of research and development, sales and marketing, and general and administrative expense. Personnel costs are the most significant component of operating expenses and consist of salaries, benefits, bonuses, share-based compensation, and with regard to sales and marketing expense, sales commissions. Our operating expenses also include allocated costs, which consist of certain facilities, depreciation, benefits, recruiting, and information technology costs that we allocate based on headcount. We expect operating expenses to increase in absolute dollars and decrease over the long term as a percentage of revenue as we continue to scale our business. As of April 30, 2016, we expect to recognize approximately $879.0 million of share-based compensation expense over a weighted-average period of approximately three years, excluding additional share-based compensation expense related to any future grants of share-based awards. Share-based compensation expense, net of forfeitures, is recognized on a straight-line basis over the requisite service periods of the awards.

[0001327567-16-000053:mdna:65]
Research and Development

[0001327567-16-000053:mdna:66]
Research and development expense consists primarily of personnel costs. Research and development expense also includes prototype related expenses and allocated costs. We expect research and development expense to increase in absolute dollars as we continue to invest in our future products and services, although our research and development expense may fluctuate as a percentage of total revenue.

[0001327567-16-000053:mdna:67]
|  | Three Months Ended April 30, |  |  |  |  |  | Nine Months Ended April 30, |  |  |  |  |
|  | 2016 |  | 2015 |  | Change |  | 2016 |  | 2015 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Research and development | $ | 74.0 |  |  | $ | 48.4 |  |  | $ | 25.6 |  |  | 52.7 | % |  | $ | 207.7 |  |  | $ | 132.7 |  |  | $ | 75.0 |  |  | 56.5 | % |
| Number of employees at period end | 601 |  |  | 412 |  |  | 189 |  |  | 45.9 | % |  | 601 |  |  | 412 |  |  | 189 |  |  | 45.9 | % |

[0001327567-16-000053:mdna:68]
Research and development expense increased for the three and nine months ended April 30, 2016 compared to the three and nine months ended April 30, 2015. The increases in both periods were driven by increases in personnel costs, which grew $22.9 million to $61.9 million for the three months ended April 30, 2016 compared to the three months ended April 30, 2015 and grew $66.4 million to $172.8 million for the nine months ended April 30, 2016 compared to the nine months ended April 30, 2015. The increases in personnel costs in both periods were due to headcount growth.

[0001327567-16-000053:mdna:69]
Sales and Marketing

[0001327567-16-000053:mdna:70]
Sales and marketing expense consists primarily of personnel costs, including commission costs. We expense commission costs as incurred. Sales and marketing expense also includes costs for market development programs, promotional and other marketing costs, travel costs, professional services, and allocated costs. We continue to increase the size of our sales force and have also substantially grown our sales presence internationally. We expect sales and marketing expense to continue to increase in absolute dollars as we increase the size of our sales and marketing organizations to increase touch points with end-customers and to expand our international presence, although our sales and marketing expense may fluctuate as a percentage of total revenue.

[0001327567-16-000053:mdna:71]
[same as prior period, unchanged from 0001327567-16-000048:mdna:69]

[0001327567-16-000053:mdna:72]
|  | Three Months Ended April 30, |  |  |  |  |  | Nine Months Ended April 30, |  |  |  |  |
|  | 2016 |  | 2015 |  | Change |  | 2016 |  | 2015 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Sales and marketing | $ | 202.0 |  |  | $ | 131.1 |  |  | $ | 70.9 |  |  | 54.2 | % |  | $ | 547.9 |  |  | $ | 360.3 |  |  | $ | 187.6 |  |  | 52.1 | % |
| Number of employees at period end | 1,972 |  |  | 1,268 |  |  | 704 |  |  | 55.5 | % |  | 1,972 |  |  | 1,268 |  |  | 704 |  |  | 55.5 | % |

[0001327567-16-000053:mdna:73]
Sales and marketing expense increased for the three and nine months ended April 30, 2016 compared to the three and nine months ended April 30, 2015. The increases in both periods were driven by increases in personnel costs, which grew $53.7 million to $145.1 million for the three months ended April 30, 2016 compared to the three months ended April 30, 2015 and grew $132.7 million to $380.4 million for the nine months ended April 30, 2016 compared to the nine months ended April 30, 2015. The increases in personnel costs in both periods were due to headcount growth.

[0001327567-16-000053:mdna:74]
General and Administrative

[0001327567-16-000053:mdna:75]
General and administrative expense consists of personnel costs for our executive, finance, human resources, legal, and information technology organizations, professional services costs, which consist primarily of legal, auditing, accounting, and other consulting costs, and certain non-recurring general expenses. Certain facilities, depreciation, benefits, recruiting, and information technology costs are allocated to other organizations based on headcount. We expect general and administrative expense to increase in absolute dollars due to additional costs associated with accounting, compliance, insurance, and investor relations, although our general and administrative expense may fluctuate as a percentage of total revenue.

[0001327567-16-000053:mdna:76]
|  | Three Months Ended April 30, |  |  |  |  |  | Nine Months Ended April 30, |  |  |  |  |
|  | 2016 |  | 2015 |  | Change |  | 2016 |  | 2015 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| General and administrative | $ | 33.5 |  |  | $ | 27.0 |  |  | $ | 6.5 |  |  | 23.7 | % |  | $ | 98.5 |  |  | $ | 73.0 |  |  | $ | 25.5 |  |  | 35.0 | % |
| Number of employees at period end | 418 |  |  | 257 |  |  | 161 |  |  | 62.6 | % |  | 418 |  |  | 257 |  |  | 161 |  |  | 62.6 | % |

[0001327567-16-000053:mdna:77]
General and administrative expense increased for the three and nine months ended April 30, 2016 compared to the three and nine months ended April 30, 2015. The increases in both periods were driven by increases in personnel costs, which grew $6.3 million to $24.2 million for the three months ended April 30, 2016 compared to the three months ended April 30, 2015 and grew $24.3 million to $68.7 million for the nine months ended April 30, 2016 compared to the nine months ended April 30, 2015. The increases in personnel costs in both periods were due to headcount growth.

[0001327567-16-000053:mdna:78]
[same as prior period, unchanged from 0001327567-16-000048:mdna:75]

[0001327567-16-000053:mdna:79]
[same as prior period, unchanged from 0001327567-16-000048:mdna:76]

[0001327567-16-000053:mdna:80]
|  | Three Months Ended April 30, |  |  |  |  |  | Nine Months Ended April 30, |  |  |  |  |
|  | 2016 |  | 2015 |  | Change |  | 2016 |  | 2015 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Other income, net | $ | 1.0 |  |  | $ | — |  |  | $ | 1.0 |  |  | NM |  | $ | 5.7 |  |  | $ | 0.7 |  |  | $ | 5.0 |  |  | NM |

[0001327567-16-000053:mdna:81]
Other income, net increased for the three months ended April 30, 2016 compared to the three months April 30, 2015 due to an increase in interest income.

[0001327567-16-000053:mdna:82]
Other income, net increased for the nine months ended April 30, 2016 compared to the nine months ended April 30, 2015, due to an increase in interest income and higher foreign currency remeasurement gains.

[0001327567-16-000053:mdna:83]
[same as prior period, unchanged from 0001327567-16-000048:mdna:83]

[0001327567-16-000053:mdna:84]
Provision for Income Taxes

[0001327567-16-000053:mdna:85]
Provision for income taxes consists primarily of income taxes in foreign jurisdictions in which we conduct business, withholding taxes, federal and state income taxes in the United States, and amortization of our deferred tax charges. We maintain a full valuation allowance for domestic deferred tax assets, including net operating loss carryforwards and tax credits.

[0001327567-16-000053:mdna:86]
|  | Three Months Ended April 30, |  | Change |  | Nine Months Ended April 30, |  | Change |
|  | 2016 |  | 2015 |  | Amount |  | % |  | 2016 |  | 2015 |  | Amount |  | % |
|  | (dollars in millions) |
| Provision for income taxes | $ | 6.8 |  |  | $ | 3.5 |  |  | $ | 3.3 |  |  | 94.3 | % |  | $ | 15.0 |  |  | $ | 4.0 |  |  | $ | 11.0 |  |  | 279.1 | % |
| Effective tax rate | (10.8 | )% |  | (8.3 | )% |  |  |  |  |  | (9.6 | )% |  | (3.5 | )% |  |  |  |  |

[0001327567-16-000053:mdna:87]
We recorded an income tax provision for the three and nine months ended April 30, 2016, due to federal, state, and foreign income taxes, withholding taxes, and amortization of our deferred tax charges. The provision for income taxes increased for the three and nine months ended April 30, 2016 compared to the three and nine months ended April 30, 2015, primarily due to an increase in non-deductible share-based compensation, changes in our valuation allowance against deferred tax assets, and amortization of our deferred tax charges.

[0001327567-16-000053:mdna:88]
[same as prior period, unchanged from 0001327567-16-000048:mdna:84]

[0001327567-16-000053:mdna:89]
|  | April 30, 2016 |  | July 31, 2015 |
|  | (in millions) |
| Working capital (1) | $ | 207.2 |  |  | $ | 41.8 |  |
| Cash, cash equivalents, and investments: |  |  |  |
| Cash and cash equivalents | $ | 550.0 |  |  | $ | 375.8 |  |
| Investments | 1,220.4 |  |  | 952.0 |  |
| Total cash, cash equivalents, and investments | $ | 1,770.4 |  |  | $ | 1,327.8 |  |

[0001327567-16-000053:mdna:90]
[same as prior period, unchanged from 0001327567-16-000048:mdna:86]

[0001327567-16-000053:mdna:91]
| (1) | The net carrying amount of the Notes was classified in current liabilities in our condensed consolidated balance sheets as of April 30, 2016 and July 31, 2015. Refer to Note 4. Convertible Senior Notes of Notes to Condensed Consolidated Financial Statements included in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information. |

[0001327567-16-000053:mdna:92]
At April 30, 2016, our total cash, cash equivalents, and investments of $1.8 billion were held for general corporate purposes, of which approximately $126.0 million was held outside of the United States. We do not provide for federal income taxes on the undistributed earnings of our foreign subsidiaries, all of which we expect to reinvest outside of the United States indefinitely. However, if these funds were needed for our domestic operations, we would be required to accrue and pay U.S. taxes on undistributed earnings of foreign subsidiaries. There are no other restrictions on the use of these funds. If we were to repatriate these earnings to the United States, any associated income tax liability would be insignificant.

[0001327567-16-000053:mdna:93]
In June 2014, we issued $575.0 million aggregate principal amount of 0.0% Convertible Senior Notes due 2019 (the “Notes”), which mature on July 1, 2019. Prior to January 1, 2019, holders may surrender their Notes for early conversion under certain circumstances. Upon conversion, we will pay cash equal to the aggregate principal amount of the Notes to be converted, and, at our election, will pay or deliver cash and/or shares of our common stock for the amount of our conversion obligation in excess of the aggregate principal amount of the Notes being converted. Refer to Note 4. Convertible Senior Notes of Notes to Condensed Consolidated Financial Statements included in Part I, Item 1 of this Quarterly Report on Form 10-Q for information on the Notes.

[0001327567-16-000053:mdna:94]
[same as prior period, unchanged from 0001327567-16-000048:mdna:97]

[0001327567-16-000053:mdna:95]
The following table summarizes our cash flows for the nine months ended April 30, 2016 and 2015:

[0001327567-16-000053:mdna:96]
|  | Nine Months Ended April 30, |
| 2016 |  | 2015 |
|  | (in millions) |
| Net cash provided by operating activities | $ | 470.6 |  |  | $ | 239.0 |  |
| Net cash used in investing activities | (339.3 | ) |  | (480.6 | ) |
| Net cash provided by financing activities | 42.9 |  |  | 41.9 |  |
| Net increase (decrease) in cash and cash equivalents | $ | 174.2 |  |  | $ | (199.7 | ) |

[0001327567-16-000053:mdna:97]
[same as prior period, unchanged from 0001327567-16-000048:mdna:92]

[0001327567-16-000053:mdna:98]
[same as prior period, unchanged from 0001327567-16-000048:mdna:93]

[0001327567-16-000053:mdna:99]
[same as prior period, unchanged from 0001327567-16-000048:mdna:94]

[0001327567-16-000053:mdna:100]
[same as prior period, unchanged from 0001327567-16-000048:mdna:95]

[0001327567-16-000053:mdna:101]
Cash provided by operating activities during the nine months ended April 30, 2016 was $470.6 million, an increase of $231.6 million compared to the nine months ended April 30, 2015. The increase was due to growth of our business and changes in our assets and liabilities during the nine months ended April 30, 2016, which included an increase in sales of subscription and support and maintenance contracts to new and existing customers as reflected by an increase in deferred revenue.

[0001327567-16-000053:mdna:102]
[same as prior period, unchanged from 0001327567-16-000048:mdna:99]

[0001327567-16-000053:mdna:103]
[same as prior period, unchanged from 0001327567-16-000048:mdna:100]

[0001327567-16-000053:mdna:104]
Cash used in investing activities during the nine months ended April 30, 2016 was $339.3 million, a decrease of $141.3 million compared to the nine months ended April 30, 2015, due to lower net purchases of available-for-sale investments, partially offset by increased investment in infrastructure and facilities to support the growth of our business.

[0001327567-16-000053:mdna:105]
[same as prior period, unchanged from 0001327567-16-000048:mdna:102]

[0001327567-16-000053:mdna:106]
[same as prior period, unchanged from 0001327567-16-000048:mdna:103]

[0001327567-16-000053:mdna:107]
Cash provided by financing activities during the nine months ended April 30, 2016 was $42.9 million, an increase of $1.0 million compared to the nine months ended April 30, 2015, due to higher proceeds from the sale of shares through employee equity incentive plans.

[0001327567-16-000053:mdna:108]
[same as prior period, unchanged from 0001327567-16-000048:mdna:116]

[0001327567-16-000053:mdna:109]
[same as prior period, unchanged from 0001327567-16-000048:mdna:105]

[0001327567-16-000053:mdna:110]
The following table summarizes our contractual obligations and commitments as of April 30, 2016:

[0001327567-16-000053:mdna:111]
|  | Payments Due by Period |
|  | Total |  | Less Than 1 Year |  | 1 - 3 Years |  | 3 - 5 Years |  | More Than 5 Years |
|  | (in millions) |
| 0.0% Convertible Senior Notes due 2019 (1) | $ | 575.0 |  |  | $ | — |  |  | $ | — |  |  | $ | 575.0 |  |  | $ | — |  |
| Operating lease obligations (2) (3) | 498.8 |  |  | 25.3 |  |  | 66.1 |  |  | 97.4 |  |  | 310.0 |  |
| Purchase obligations (4) | 54.5 |  |  | 54.5 |  |  | — |  |  | — |  |  | — |  |
| Total (5) | $ | 1,128.3 |  |  | $ | 79.8 |  |  | $ | 66.1 |  |  | $ | 672.4 |  |  | $ | 310.0 |  |

[0001327567-16-000053:mdna:112]
[same as prior period, unchanged from 0001327567-16-000048:mdna:108]

[0001327567-16-000053:mdna:113]
| (1) | As of April 30, 2016, holders may convert their Notes at any time during the fiscal quarter ending July 31, 2016. Refer to Note 4. Convertible Senior Notes of Notes to Condensed Consolidated Financial Statements included in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information. |

[0001327567-16-000053:mdna:114]
| (2) | Consists of contractual obligations from our non-cancelable operating leases, including the lease agreement executed in October 2015 for additional corporate office space in Santa Clara, California. Refer to Note 5. Commitments and Contingencies of Notes to Condensed Consolidated Financial Statements included in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information. |

[0001327567-16-000053:mdna:115]
| (3) | Excludes contractual sublease proceeds of $5.9 million, of which $3.0 million will be received in less than one year and $2.9 million will be received in one to two years. |

[0001327567-16-000053:mdna:116]
[same as prior period, unchanged from 0001327567-16-000048:mdna:112]

[0001327567-16-000053:mdna:117]
| (5) | No amounts related to income taxes are included. As of April 30, 2016, we had approximately $46.3 million of tax liabilities recorded related to uncertainty in income tax positions. |

[0001327567-16-000053:mdna:118]
[same as prior period, unchanged from 0001327567-16-000048:mdna:114]

[0001327567-16-000053:mdna:119]
As of April 30, 2016, we did not have any relationships with unconsolidated organizations or financial partnerships, such as structured finance or special purpose entities that would have been established for the purpose of facilitating off-balance sheet arrangements or other contractually narrow or limited purposes.

[0001327567-16-000053:mdna:120]
[same as prior period, unchanged from 0001327567-16-000048:mdna:117]

[0001327567-16-000053:mdna:121]
[same as prior period, unchanged from 0001327567-16-000048:mdna:118]

[0001327567-16-000053:mdna:122]
[same as prior period, unchanged from 0001327567-16-000048:mdna:119]

[0001327567-16-000053:mdna:123]
[same as prior period, unchanged from 0001327567-16-000048:mdna:120]

[0001327567-16-000053:mdna:124]
[same as prior period, unchanged from 0001327567-16-000048:mdna:121]

[0001327567-16-000053:mdna:125]
- 25 -
