# PANW notes — 0001327567-16-000053


## us-gaap:AvailableForSaleSecuritiesTextBlock

[0001327567-16-000053:notes:1]
The following tables summarize the amortized cost, unrealized gains and losses, and fair value of our available-for-sale investments as of April 30, 2016 and July 31, 2015 (in millions):

[0001327567-16-000053:notes:2]
|  | April 30, 2016 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Estimated Fair Value |
| Certificates of deposit | $ | 5.4 |  |  | $ | — |  |  | $ | — |  |  | $ | 5.4 |  |
| Corporate debt securities | 299.8 |  |  | 0.5 |  |  | — |  |  | 300.3 |  |
| U.S. government and agency securities | 914.4 |  |  | 0.5 |  |  | (0.2 | ) |  | 914.7 |  |
| Total | $ | 1,219.6 |  |  | $ | 1.0 |  |  | $ | (0.2 | ) |  | $ | 1,220.4 |  |

[0001327567-16-000053:notes:3]
[same as prior period, unchanged from 0001327567-16-000048:notes:3]


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001327567-16-000053:notes:4]
Basis of Presentation and Principles of Consolidation

[0001327567-16-000053:notes:5]
[same as prior period, unchanged from 0001327567-16-000048:notes:5]

[0001327567-16-000053:notes:6]
[same as prior period, unchanged from 0001327567-16-000048:notes:6]

[0001327567-16-000053:notes:7]
[same as prior period, unchanged from 0001327567-16-000048:notes:7]


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock

[0001327567-16-000053:notes:8]
[same as prior period, unchanged from 0001327567-16-000048:notes:8]

[0001327567-16-000053:notes:9]
[same as prior period, unchanged from 0001327567-16-000048:notes:9]

[0001327567-16-000053:notes:10]
[same as prior period, unchanged from 0001327567-16-000048:notes:10]

[0001327567-16-000053:notes:11]
[same as prior period, unchanged from 0001327567-16-000048:notes:11]

[0001327567-16-000053:notes:12]
There have been no material changes to our significant accounting policies as of and for the nine months ended April 30, 2016, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended July 31, 2015.

[0001327567-16-000053:notes:13]
[same as prior period, unchanged from 0001327567-16-000048:notes:13]

[0001327567-16-000053:notes:14]
In March 2016, the Financial Accounting Standards Board (“FASB”) issued authoritative guidance simplifying several aspects of the accounting for employee share-based payment transactions, including the income tax consequences, accounting for forfeitures, and classification of excess tax benefits on the statement of cash flows. The standard is effective for us for our first quarter of fiscal 2018, however, early adoption is permitted. We are currently evaluating whether this standard will have a material impact on our condensed consolidated financial statements.

[0001327567-16-000053:notes:15]
In February 2016, the FASB issued new authoritative guidance on lease accounting. Among its provisions, the standard requires lessees to recognize right-of-use assets and lease liabilities on the balance sheet for operating leases and also requires additional qualitative and quantitative disclosures about lease arrangements. The standard is effective for us for our first quarter of fiscal 2020 and will be applied on a modified retrospective basis, with the option to elect certain practical expedients. Early adoption is permitted. We are currently evaluating whether this standard will have a material impact on our condensed consolidated financial statements.

[0001327567-16-000053:notes:16]
In April 2015, the FASB issued new authoritative guidance on fees paid in a cloud computing arrangement. The standard requires customers in a cloud computing arrangement to evaluate whether the arrangement includes a software license. If the arrangement includes a software license, the customer should account for the software license element of the arrangement consistent with the acquisition of other software licenses. If the arrangement does not include a software license, the customer should account for the arrangement as a service contract. The standard is effective for us for our first quarter of fiscal 2017 and will be applied on a prospective basis. We do not expect the adoption of the standard will have a material impact on our condensed consolidated financial statements.

[0001327567-16-000053:notes:17]
[same as prior period, unchanged from 0001327567-16-000048:notes:15]

[0001327567-16-000053:notes:18]
[same as prior period, unchanged from 0001327567-16-000048:notes:16]


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001327567-16-000053:notes:19]
Commitments and Contingencies

[0001327567-16-000053:notes:20]
Leases

[0001327567-16-000053:notes:21]
We lease our facilities under various non-cancelable operating leases, which expire through the year ending July 31, 2028.

[0001327567-16-000053:notes:22]
In May 2015, we entered into three lease agreements for approximately 752,000 square feet of corporate office space in Santa Clara, California to serve as our future corporate headquarters. In October 2015, we entered into a fourth lease agreement for approximately 310,000 square feet of additional office space at the same location. The fourth lease will commence in December 2017 and expire in April 2028, however, the site is currently under construction and as a result, the lease commencement date may change based on progress of the construction project. The fourth lease agreement contains a rent holiday period, scheduled rent increases, lease incentives, and renewal options which allow the lease term to be extended through April 2046. Rental payments under the fourth lease agreement are approximately $101.2 million over the initial lease term. For more information on the three lease agreements entered into in May 2015, refer to Note 8. Commitments and Contingencies of Notes to Consolidated Financial Statements included in Part II, Item 8 of our Annual Report on Form 10-K for the fiscal year ended July 31, 2015.

[0001327567-16-000053:notes:23]
The following table presents details of the aggregate future non-cancelable minimum rental payments under our operating leases as of April 30, 2016 (in millions):

[0001327567-16-000053:notes:24]
|  | Amount |
| Fiscal years ending July 31: |  |
| Remaining 2016 | $ | 6.4 |  |
| 2017 | 25.1 |  |
| 2018 | 28.4 |  |
| 2019 | 42.1 |  |
| 2020 | 46.1 |  |
| 2021 and thereafter | 350.7 |  |
| Committed gross lease payments | 498.8 |  |
| Less: proceeds from sublease rental | 5.9 |  |
| Net operating lease obligation | $ | 492.9 |  |

[0001327567-16-000053:notes:25]
Contract Manufacturer Commitments

[0001327567-16-000053:notes:26]
Our independent contract manufacturer procures components and assembles our products based on our forecasts. These forecasts are based on estimates of demand for our products primarily for the next 12 months, which are in turn based on historical trends and an analysis from our sales and product marketing organizations, adjusted for overall market conditions. In order to reduce manufacturing lead times and plan for adequate supply, we may issue forecasts and orders for components and products that are non-cancelable. As of April 30, 2016, our purchase commitments under such orders were $54.5 million, excluding obligations under contracts that we can cancel without a significant penalty.

[0001327567-16-000053:notes:27]
Litigation

[0001327567-16-000053:notes:28]
We are subject to legal proceedings, claims, and litigation arising in the ordinary course of business, including intellectual property litigation. Such matters are subject to many uncertainties and outcomes are not predictable with assurance. We accrue for contingencies when we believe that a loss is probable and that we can reasonably estimate the amount of any such loss.

[0001327567-16-000053:notes:29]
To the extent there is a reasonable possibility that a loss exceeding amounts already recognized may be incurred and the amount of such additional loss would be material, we will either disclose the estimated additional loss or state that such an estimate cannot be made. As of April 30, 2016, we have not recorded any significant accruals for loss contingencies associated with such legal proceedings, determined that an unfavorable outcome is probable or reasonably possible, or determined that the amount or range of any possible loss is reasonably estimable.


## us-gaap:ConvertibleDebtTableTextBlock

[0001327567-16-000053:notes:30]
The following table sets forth the components of the Notes as of April 30, 2016 and July 31, 2015 (in millions):

[0001327567-16-000053:notes:31]
|  | April 30, 2016 |  | July 31, 2015 |
| Liability: |  |  |  |
| Principal | $ | 575.0 |  |  | $ | 575.0 |  |
| Less: debt discount, net of amortization | 72.2 |  |  | 87.9 |  |
| Net carrying amount | $ | 502.8 |  |  | $ | 487.1 |  |
| Equity (including temporary equity) | $ | (109.8 | ) |  | $ | (109.8 | ) |


## us-gaap:DebtDisclosureTextBlock

[0001327567-16-000053:notes:32]
Convertible Senior Notes

[0001327567-16-000053:notes:33]
On June 30, 2014, we issued $575.0 million aggregate principal amount of 0.0% Convertible Senior Notes due 2019 (the “Notes”). The Notes mature on July 1, 2019, unless converted or repurchased in accordance with their terms prior to such date. The Notes do not contain any financial covenants and we cannot redeem the Notes prior to maturity.

[0001327567-16-000053:notes:34]
The Notes are convertible for up to 5.2 million shares of our common stock at an initial conversion price of approximately $110.28 per share of common stock, subject to adjustment. Holders of the Notes may surrender their Notes for conversion at their option at any time prior to the close of business on the business day immediately preceding January 1, 2019, only under the following circumstances:

[0001327567-16-000053:notes:35]
| • | if the last reported sale price of our common stock for at least 20 trading days (whether or not consecutive) during a period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the conversion price for the Notes on each applicable trading day (the “sale price condition”); |

[0001327567-16-000053:notes:36]
| • | during the five business day period after any five consecutive trading day period, in which the trading price per $1,000 principal amount of Notes for each trading day of the measurement period was less than 98% of the product of the last reported sale price of our common stock and the conversion rate for the Notes on each such trading day; or |

[0001327567-16-000053:notes:37]
| • | upon the occurrence of specified corporate events. |

[0001327567-16-000053:notes:38]
On or after January 1, 2019, holders may convert all or any portion of their Notes at any time prior to the close of business on the second scheduled trading day immediately preceding the maturity date regardless of the foregoing conditions. Upon conversion, holders will receive cash equal to the aggregate principal amount of the Notes to be converted, and, at our election, cash and/or shares of our common stock for any amounts in excess of the aggregate principal amount of the Notes being converted.

[0001327567-16-000053:notes:39]
The sale price condition was initially met during the fiscal quarter ended April 30, 2015. The sale price condition continued to be met through the fiscal quarter ended April 30, 2016, and as a result, holders may convert their Notes at any time during the fiscal quarter ending July 31, 2016. Accordingly, the net carrying amount of the Notes was classified in current liabilities and a portion of the equity component representing the conversion option was classified as temporary equity in our condensed consolidated balance sheets as of April 30, 2016. The portion of the equity component classified as temporary equity is measured as the difference between the principal and net carrying amount of the Notes.

[0001327567-16-000053:notes:40]
The total estimated fair value of the Notes was $844.4 million and $994.8 million at April 30, 2016 and July 31, 2015, respectively. The fair value was determined based on the closing trading price per $100 of the Notes as of the last day of trading for the period. We consider the fair value of the Notes at April 30, 2016 and July 31, 2015 to be a Level 2 measurement. The fair value of the Notes is primarily affected by the trading price of our common stock and market interest rates. As of April 30, 2016, the if-converted value of the Notes exceeded its principal amount by $210.9 million.

[0001327567-16-000053:notes:41]
The following table sets forth interest expense recognized related to the Notes (dollars in millions):

[0001327567-16-000053:notes:42]
|  | Three Months Ended April 30, |  | Nine Months Ended April 30, |
|  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Amortization of debt discount | $ | 5.3 |  |  | $ | 5.1 |  |  | $ | 15.7 |  |  | $ | 15.1 |  |
| Amortization of debt issuance costs | 0.6 |  |  | 0.5 |  |  | 1.7 |  |  | 1.5 |  |
| Total interest expense recognized | $ | 5.9 |  |  | $ | 5.6 |  |  | $ | 17.4 |  |  | $ | 16.6 |  |
| Effective interest rate of the liability component | 4.8 | % |  | 4.8 | % |  | 4.8 | % |  | 4.8 | % |

[0001327567-16-000053:notes:43]
Note Hedges

[0001327567-16-000053:notes:44]
To minimize the impact of potential economic dilution upon conversion of the Notes, we entered into convertible note hedge transactions (the “Note Hedges”) with respect to our common stock concurrent with the issuance of the Notes. The Note Hedges cover up to 5.2 million shares of our common stock and are exercisable upon conversion of the Notes. The Note Hedges will expire upon maturity of the Notes. The Note Hedges are separate transactions and are not part of the terms of the Notes. Holders of the Notes will not have any rights with respect to the Note Hedges. The shares receivable related to the Note Hedges are excluded from the calculation of diluted earnings per share as they are antidilutive.

[0001327567-16-000053:notes:45]
Warrants

[0001327567-16-000053:notes:46]
Separately, but concurrently with our issuance of the Notes, we entered into transactions whereby we sold warrants (the “Warrants”) to acquire up to 5.2 million shares of our common stock at a strike price of approximately $137.85 per share, subject to adjustments. The shares issuable under the Warrants will be included in the calculation of diluted earnings per share when the average market value per share of our common stock for the reporting period exceeds the strike price of the Warrants. The Warrants are separate transactions and are not part of the Notes or Notes Hedges, and are not remeasured through earnings each reporting period. Holders of the Notes and Note Hedges will not have any rights with respect to the Warrants.

[0001327567-16-000053:notes:47]
For more information on the Notes, the Note Hedges, and the Warrants, refer to Note 7. Convertible Senior Notes of Notes to Consolidated Financial Statements included in Part II, Item 8 of our Annual Report on Form 10-K for the fiscal year ended July 31, 2015.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001327567-16-000053:notes:48]
[same as prior period, unchanged from 0001327567-16-000048:notes:46]

[0001327567-16-000053:notes:49]
[same as prior period, unchanged from 0001327567-16-000048:notes:47]

[0001327567-16-000053:notes:50]
The following table summarizes the stock option activity under our stock plans during the reporting period (in millions, except per share amounts):

[0001327567-16-000053:notes:51]
|  | Options Outstanding |
|  | Number of Shares |  | Weighted- Average Exercise Price Per Share |  | Weighted- Average Remaining Contractual Term (Years) |  | Aggregate Intrinsic Value |
| Balance—July 31, 2015 | 3.3 |  |  | $ | 13.74 |  |  | 6.2 |  | $ | 562.9 |  |
| Options granted | — |  |  | — |  |  |  |  |  |
| Options forfeited | — |  |  | — |  |  |  |  |  |
| Options exercised | (1.0 | ) |  | 14.05 |  |  |  |  |  |
| Balance—April 30, 2016 | 2.3 |  |  | $ | 13.56 |  |  | 5.5 |  | $ | 313.3 |  |
| Options vested and expected to vest—April 30, 2016 | 2.3 |  |  | $ | 13.56 |  |  | 5.5 |  | $ | 313.3 |  |
| Options exercisable—April 30, 2016 | 2.2 |  |  | $ | 13.27 |  |  | 5.5 |  | $ | 306.9 |  |

[0001327567-16-000053:notes:52]
Restricted Stock Unit (RSU) and Restricted Stock Award (RSA) Activities

[0001327567-16-000053:notes:53]
The following table summarizes the RSU and RSA activity under our stock plans during the reporting period (in millions, except per share amounts):

[0001327567-16-000053:notes:54]
|  | RSAs Outstanding |  | RSUs Outstanding |
|  | Number of Shares |  | Weighted- Average Grant-Date Fair Value Per Share |  | Number of Shares |  | Weighted- Average Grant-Date Fair Value Per Share |  | Weighted- Average Remaining Contractual Term (Years) |  | Aggregate Intrinsic Value |
| Balance—July 31, 2015 | — |  |  | $ | — |  |  | 7.2 |  |  | $ | 95.66 |  |  | 1.2 |  | $ | 1,334.8 |  |
| Granted | 1.1 |  |  | 170.97 |  |  | 2.8 |  |  | 165.24 |  |  |  |  |  |
| Vested | — |  |  | — |  |  | (2.5 | ) |  | 84.89 |  |  |  |  |  |
| Forfeited | — |  |  | — |  |  | (0.5 | ) |  | 98.78 |  |  |  |  |  |
| Balance—April 30, 2016 | 1.1 |  |  | $ | 170.97 |  |  | 7.0 |  |  | $ | 126.97 |  |  | 1.2 |  | $ | 1,049.3 |  |
| RSUs vested and expected to vest—April 30, 2016 |  |  |  |  | 6.6 |  |  | $ | 126.36 |  |  | 1.2 |  | $ | 994.5 |  |

[0001327567-16-000053:notes:55]
[same as prior period, unchanged from 0001327567-16-000048:notes:55]

[0001327567-16-000053:notes:56]
[same as prior period, unchanged from 0001327567-16-000048:notes:56]

[0001327567-16-000053:notes:57]
|  | Three Months Ended April 30, |  | Nine Months Ended April 30, |
|  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Cost of product revenue | $ | 1.6 |  |  | $ | 1.0 |  |  | $ | 4.5 |  |  | $ | 2.7 |  |
| Cost of services revenue | 11.5 |  |  | 5.6 |  |  | 29.0 |  |  | 14.2 |  |
| Research and development | 36.0 |  |  | 19.8 |  |  | 95.9 |  |  | 52.8 |  |
| Sales and marketing | 43.8 |  |  | 22.2 |  |  | 110.4 |  |  | 59.7 |  |
| General and administrative | 15.6 |  |  | 11.6 |  |  | 43.5 |  |  | 26.2 |  |
| Total share-based compensation | $ | 108.5 |  |  | $ | 60.2 |  |  | $ | 283.3 |  |  | $ | 155.6 |  |

[0001327567-16-000053:notes:58]
At April 30, 2016, total compensation cost related to unvested share-based awards not yet recognized was $879.0 million, net of estimated forfeitures. This cost is expected to be amortized on a straight-line basis over a weighted-average period of approximately three years.


## us-gaap:EarningsPerShareTextBlock

[0001327567-16-000053:notes:59]
[same as prior period, unchanged from 0001327567-16-000048:notes:59]

[0001327567-16-000053:notes:60]
[same as prior period, unchanged from 0001327567-16-000048:notes:60]

[0001327567-16-000053:notes:61]
[same as prior period, unchanged from 0001327567-16-000048:notes:61]

[0001327567-16-000053:notes:62]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 30, |  | April 30, |
|  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Net loss | $ | (70.2 | ) |  | $ | (45.9 | ) |  | $ | (171.4 | ) |  | $ | (119.0 | ) |
| Weighted-average shares used to compute net loss per share, basic and diluted | 87.8 |  |  | 82.3 |  |  | 86.5 |  |  | 80.8 |  |
| Net loss per share, basic and diluted | $ | (0.80 | ) |  | $ | (0.56 | ) |  | $ | (1.98 | ) |  | $ | (1.47 | ) |

[0001327567-16-000053:notes:63]
[same as prior period, unchanged from 0001327567-16-000048:notes:63]

[0001327567-16-000053:notes:64]
|  | Three and Nine Months Ended |
|  | April 30, |
|  | 2016 |  | 2015 |
| RSUs | 7.0 |  |  | 7.3 |  |
| Convertible senior notes | 5.2 |  |  | 5.2 |  |
| Warrants related to the issuance of convertible senior notes | 5.2 |  |  | 5.2 |  |
| Options to purchase common stock | 2.3 |  |  | 3.8 |  |
| RSAs | 1.1 |  |  | — |  |
| Total | 20.8 |  |  | 21.5 |  |


## us-gaap:FairValueAssetsAndLiabilitiesMeasuredOnRecurringAndNonrecurringBasisTableTextBlock

[0001327567-16-000053:notes:65]
The following table presents the fair value of our financial assets and liabilities using the above input categories as of April 30, 2016 and July 31, 2015 (in millions):

[0001327567-16-000053:notes:66]
|  |  | April 30, 2016 |  | July 31, 2015 |
|  |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Short-term investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Certificates of deposit |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1.0 |  |  | $ | — |  |  | $ | 1.0 |  |
| Corporate debt securities |  | — |  |  | 110.3 |  |  | — |  |  | 110.3 |  |  | — |  |  | 97.8 |  |  | — |  |  | 97.8 |  |
| U.S. government and agency securities |  | — |  |  | 427.2 |  |  | — |  |  | 427.2 |  |  | — |  |  | 314.4 |  |  | — |  |  | 314.4 |  |
| Total short-term investments |  | — |  |  | 537.5 |  |  | — |  |  | 537.5 |  |  | — |  |  | 413.2 |  |  | — |  |  | 413.2 |  |
| Long-term investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Certificates of deposit |  | — |  |  | 5.4 |  |  | — |  |  | 5.4 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Corporate debt securities |  | — |  |  | 190.0 |  |  | — |  |  | 190.0 |  |  | — |  |  | 92.9 |  |  | — |  |  | 92.9 |  |
| U.S. government and agency securities |  | — |  |  | 487.5 |  |  | — |  |  | 487.5 |  |  | — |  |  | 445.9 |  |  | — |  |  | 445.9 |  |
| Total long-term investments |  | — |  |  | 682.9 |  |  | — |  |  | 682.9 |  |  | — |  |  | 538.8 |  |  | — |  |  | 538.8 |  |
| Total assets measured at fair value |  | $ | — |  |  | $ | 1,220.4 |  |  | $ | — |  |  | $ | 1,220.4 |  |  | $ | — |  |  | $ | 952.0 |  |  | $ | — |  |  | $ | 952.0 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001327567-16-000053:notes:67]
[same as prior period, unchanged from 0001327567-16-000048:notes:67]

[0001327567-16-000053:notes:68]
[same as prior period, unchanged from 0001327567-16-000048:notes:68]

[0001327567-16-000053:notes:69]
[same as prior period, unchanged from 0001327567-16-000048:notes:69]

[0001327567-16-000053:notes:70]
[same as prior period, unchanged from 0001327567-16-000048:notes:70]

[0001327567-16-000053:notes:71]
[same as prior period, unchanged from 0001327567-16-000048:notes:71]

[0001327567-16-000053:notes:72]
Refer to Note 4. Convertible Senior Notes for the carrying amount and estimated fair value of our convertible senior notes as of April 30, 2016.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001327567-16-000053:notes:73]
[same as prior period, unchanged from 0001327567-16-000048:notes:73]

[0001327567-16-000053:notes:74]
Our provision for income taxes for the three and nine months ended April 30, 2016 reflects an effective tax rate of (10.8)% and (9.6)%, respectively. Our effective tax rates for these periods were negative as we recorded a provision for income taxes on quarter and year to date losses. The key components of our income tax provision primarily consist of foreign income taxes, withholding taxes, U.S. federal and state income taxes, and amortization of our deferred tax charges. Our effective tax rate differs from the U.S. statutory tax rate primarily due to foreign tax losses which derive no benefit, non-deductible share-based compensation, and changes in our valuation allowance. As compared to the same periods last year, our effective tax rate changed primarily due to an increase in non-deductible share-based compensation, changes in our valuation allowance against deferred tax assets, and amortization of our deferred tax charges.

[0001327567-16-000053:notes:75]
Our provision for income taxes for the three and nine months ended April 30, 2015 reflects an effective tax rate of (8.3)% and (3.5)%, respectively. Our effective tax rates for these periods were negative as we recorded a provision for income taxes on year to date losses. The key components of our income tax provision consist of foreign income taxes, foreign withholding taxes, U.S. federal and state income taxes, and amortization of our deferred tax charge. Key components of our effective tax rate consist of foreign tax losses which derive no benefit, non-deductible share-based compensation, and changes in our valuation allowance.

[0001327567-16-000053:notes:76]
[same as prior period, unchanged from 0001327567-16-000048:notes:76]

[0001327567-16-000053:notes:77]
As of April 30, 2016, we had $109.8 million of unrecognized tax benefits, $19.2 million of which would affect income tax expense if recognized, after consideration of our valuation allowance in the United States and other assets. As of July 31, 2015, we had $67.2 million of unrecognized tax benefits, $10.8 million of which would affect income tax expense if recognized, after consideration of our valuation allowance in the United States and other assets. The increase in unrecognized tax benefits since July 31, 2015 relates to positions taken in the current year. As of April 30, 2016, our federal, state, and foreign returns for the tax years 2008 through the current period remain open to examination. Fiscal years outside the normal statute of limitation remain open to audit by tax authorities due to tax attributes generated in earlier years, which have been carried forward and may be audited in subsequent years when utilized. We do not expect the unrecognized tax benefits to change significantly over the next 12 months. We recognize both interest and penalties associated with uncertain tax positions as a component of income tax expense. The ultimate amount and timing of any future cash settlements cannot be predicted with reasonable certainty.


## us-gaap:InvestmentsClassifiedByContractualMaturityDateTableTextBlock

[0001327567-16-000053:notes:78]
The following table summarizes the amortized cost and fair value of our available-for-sale investments as of April 30, 2016, by contractual years-to-maturity (in millions):

[0001327567-16-000053:notes:79]
|  | Amortized Cost |  | Fair Value |
| Due within one year | $ | 537.4 |  |  | $ | 537.5 |  |
| Due between one and three years | 682.2 |  |  | 682.9 |  |
| Total | $ | 1,219.6 |  |  | $ | 1,220.4 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001327567-16-000053:notes:80]
Investments

[0001327567-16-000053:notes:81]
Unrealized losses related to these investments are due to interest rate fluctuations as opposed to credit quality. In addition, we do not intend to sell and it is not likely that we would be required to sell these investments before recovery of their amortized cost basis, which may be at maturity. As a result, there were no other-than-temporary impairments for these investments at April 30, 2016 and July 31, 2015.
