# PANW 8-K — 0001327567-16-000051 filed 2016-05-26

## item codes, every 8-K on or before 2016-05-27

- 2016-05-26 0001327567-16-000051 — 2.02, 9.01
- 2016-02-25 0001327567-16-000044 — 2.02, 5.02, 9.01
- 2015-12-14 0001327567-15-000038 — 5.07
- 2015-12-14 0001193125-15-402588 — 1.01, 9.01
- 2015-11-23 0001327567-15-000033 — 2.02, 9.01
- 2015-10-19 0001193125-15-347005 — 1.01, 9.01 — amendment, the index does not say of what
- 2015-09-09 0001327567-15-000022 — 2.02, 9.01
- 2015-08-19 0001193125-15-296115 — 1.01, 2.03
- 2015-06-01 0001193125-15-207786 — 1.01, 2.03
- 2015-05-27 0001327567-15-000015 — 2.02, 9.01
- 2015-03-02 0001327567-15-000006 — 2.02, 9.01
- 2014-12-15 0001327567-14-000046 — 5.07
- 2014-11-24 0001327567-14-000040 — 2.02, 9.01
- 2014-09-22 0001193125-14-348581 — 5.02, 9.01
- 2014-09-09 0001327567-14-000025 — 2.02, 9.01
- 2014-07-01 0001193125-14-257824 — 1.01, 2.03, 3.02, 9.01
- 2014-06-26 0001193125-14-249529 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2014-06-20 0001327567-14-000020 — 9.01 — amendment of 0001193125-14-140511
- 2014-06-04 0001327567-14-000016 — 3.02
- 2014-05-30 0001193125-14-218158 — 2.02 — amendment, the index does not say of what
- 2014-05-28 0001193125-14-215060 — 1.01, 2.02, 3.02, 9.01
- 2014-04-11 0001193125-14-140511 — 2.01, 3.02, 7.01, 9.01
- 2014-03-24 0001193125-14-111318 — 1.01, 3.02, 7.01, 9.01
- 2014-03-13 0001327567-14-000009 — 5.02
- 2014-02-24 0001193125-14-063754 — 2.02, 9.01
- 2013-12-12 0001327567-13-000040 — 5.07
- 2013-11-25 0001327567-13-000033 — 2.02, 9.01
- 2013-09-30 0001193125-13-384966 — 8.01
- 2013-09-09 0001193125-13-361421 — 2.02, 9.01
- 2013-05-30 0001193125-13-241542 — 2.02, 5.02, 9.01
- 2013-03-11 0001193125-13-101082 — 5.02, 9.01
- 2013-02-28 0001193125-13-084193 — 2.02, 9.01
- 2012-12-14 0001193125-12-503335 — 5.07
- 2012-12-06 0001193125-12-493700 — 2.02, 9.01
- 2012-09-24 0001193125-12-401534 — 1.01, 2.03
- 2012-09-20 0001193125-12-398433 — 5.02, 9.01
- 2012-09-10 0001193125-12-386605 — 2.02, 9.01

## late-filing notifications on or before 2016-05-27

- none on or before 2016-05-27

## item 2.02 — earnings release, exhibit 99.1

[0001327567-16-000051:8k_2_02:1]
EX-99.1
2
ex991q316earningsrelease.htm
EXHIBIT 99.1

[0001327567-16-000051:8k_2_02:2]
Exhibit

[0001327567-16-000051:8k_2_02:3]
Exhibit 99.1

[0001327567-16-000051:8k_2_02:4]
Palo Alto Networks Reports Fiscal Third Quarter 2016 Financial Results

[0001327567-16-000051:8k_2_02:5]
| • | Fiscal third quarter total revenue grows 48 percent year over year to $345.8 million |

[0001327567-16-000051:8k_2_02:6]
| • | Fiscal third quarter billings grow 61 percent year over year to $486.2 million |

[0001327567-16-000051:8k_2_02:7]
| • | Fiscal third quarter cash flow from operations grows 95 percent year over year to $170.1 million, and free cash flow grows 95 percent year over year to $150.8 million |

[0001327567-16-000051:8k_2_02:8]
SANTA CLARA, Calif. — May 26, 2016 — Palo Alto Networks® (NYSE: PANW), the next-generation security company, today announced financial results for its fiscal third quarter 2016 ended April 30, 2016.

[0001327567-16-000051:8k_2_02:9]
Total revenue for the fiscal third quarter 2016 grew 48 percent year over year to a record $345.8 million, compared with total revenue of $234.2 million for the fiscal third quarter 2015. GAAP net loss for the fiscal third quarter 2016 was $70.2 million, or $0.80 per diluted share, compared with GAAP net loss of $45.9 million, or $0.56 per diluted share, for the fiscal third quarter 2015.

[0001327567-16-000051:8k_2_02:10]
Non-GAAP net income for the fiscal third quarter 2016 was $38.5 million, or $0.42 per diluted share, compared with non-GAAP net income of $20.5 million, or $0.23 per diluted share, for the fiscal third quarter 2015. A reconciliation between GAAP and non-GAAP information is contained in the tables below.

[0001327567-16-000051:8k_2_02:11]
“Our record fiscal third quarter 2016 results continue to underscore the market demand for our unique Next-Generation Security Platform as more than 31,000 new and existing customers are working with Palo Alto Networks to solve their most difficult security needs,” said Mark McLaughlin, president and chief executive officer of Palo Alto Networks. “Security has never been more critical than it is today, and our platform delivers natively integrated and highly automated prevention outcomes, allowing us to continue to significantly outpace the competition as we further establish ourselves as the leader in cybersecurity.”

[0001327567-16-000051:8k_2_02:12]
“Robust new customer additions and expansion in existing accounts resulted in market-leading, year over year growth as customers increased their investments in our Next-Generation Security Platform, with particular strength in our subscription services,” said Steffan Tomlinson, chief financial officer of Palo Alto Networks. “We continue to balance growth and profitability and once again delivered record

[0001327567-16-000051:8k_2_02:13]
revenue, billings and cash flow, with cash flow from operations margin of 49 percent and free cash flow margin of 44 percent.”

[0001327567-16-000051:8k_2_02:14]
Recent Highlights

[0001327567-16-000051:8k_2_02:15]
| • | Received industry analyst recognition – Our WildFire™ cloud-based threat intelligence offering was recognized by Forrester Research as a leader among automated malware analysis providers in the “The Forrester Wave™: Automated Malware Analysis, Q2 2016.” |

[0001327567-16-000051:8k_2_02:16]
| • | Extended breach prevention to multi-cloud environments and SaaS applications – With the introduction of PAN-OS® 7.1 operating system, which included more than 50 feature enhancements, we extended our security capabilities for all major cloud environments, including Microsoft® Azure™, to provide visibility, control and threat prevention to protect customer data regardless of where it resides. |

[0001327567-16-000051:8k_2_02:17]
| • | Joined forces with PwC – Together with PwC’s Cybersecurity and Privacy practice, we will design a next-generation security framework to serve as a guide for customer organizations to establish a breach prevention-oriented security architecture. This framework incorporates the latest advances in security technology and addresses the modern threat landscape. |

[0001327567-16-000051:8k_2_02:18]
| • | Entered global agreement with BT – Our Next-Generation Security Platform will be integrated into BT’s global portfolio of security services, enabling BT customers worldwide to benefit from the combination of our breach prevention-focused platform and the global reach and scale of BT’s security services. |

[0001327567-16-000051:8k_2_02:19]
| • | Recognized as 2016 best place to work in the Bay Area – We were ranked first in the 2016 Bay Area Best Places to Work, an awards program presented by the San Francisco Business Times and the Silicon Valley Business Journal. |

[0001327567-16-000051:8k_2_02:20]
Financial Outlook

[0001327567-16-000051:8k_2_02:21]
Palo Alto Networks provides guidance based on current market conditions and expectations.

[0001327567-16-000051:8k_2_02:22]
For the fiscal fourth quarter 2016, we expect:

[0001327567-16-000051:8k_2_02:23]
| • | Total revenue in the range of $386 to $390 million, representing year over year growth between 36 percent and 37 percent. |

[0001327567-16-000051:8k_2_02:24]
2

[0001327567-16-000051:8k_2_02:25]
| • | Diluted non-GAAP net income per share in the range of $0.48 to $0.50 using 91 to 93 million shares. |

[0001327567-16-000051:8k_2_02:26]
Guidance for non-GAAP financial measures excludes share-based compensation and related payroll taxes, acquisition related costs, amortization expense of acquired intangible assets, litigation related charges including legal settlements, non-cash interest expense related to our convertible senior notes, the foreign currency gains (losses) and tax effects associated with these items, and certain non-recurring expenses. We have not reconciled diluted non-GAAP earnings per share guidance to GAAP net income (loss) per diluted share because we do not provide guidance on GAAP net income (loss) or the various reconciling cash and non-cash items between GAAP net income (loss) and non-GAAP net income (loss). Share-based compensation expense is impacted by the Company’s future hiring and retention needs, as well as the future fair market value of the Company’s common stock, all of which is difficult to predict and subject to constant change. The actual amount of share-based compensation in the fiscal fourth quarter of 2016 will have a significant impact on the Company’s GAAP net income (loss) per diluted share. Accordingly, a reconciliation of the non-GAAP financial measure guidance to the corresponding GAAP measure is not available without unreasonable effort.

[0001327567-16-000051:8k_2_02:27]
Conference Call Information

[0001327567-16-000051:8k_2_02:28]
Palo Alto Networks will host a conference call for analysts and investors to discuss its fiscal third quarter 2016 results and outlook for its fiscal fourth quarter 2016 today at 4:30 p.m. Eastern time/1:30 p.m. Pacific time. Open to the public, investors may access the call by dialing 1-877-879-6203 or 1-719-325-4813 and using conference ID 6954603. A live audio webcast of the conference call, along with supplemental financial information, will also be accessible from the “Investors” section of our website at investors.paloaltonetworks.com. Following the webcast, an archived version will be available on our website for one year. A telephonic replay of the call will be available three hours after the call, and will run for ten days, and may be accessed by dialing 1-888-203-1112 or 1-719-457-0820 and entering the passcode 6954603.

[0001327567-16-000051:8k_2_02:29]
Forward-Looking Statements

[0001327567-16-000051:8k_2_02:30]
This press release contains forward-looking statements that involve risks and uncertainties, including statements regarding our financial outlook for the fiscal fourth quarter of 2016, our ability to continue to outpace our competition and further establish ourselves as the leader in cybersecurity, and the integration of our products with third-party services. There are a significant number of factors that could cause actual results to differ materially from statements made in this press release, including: our limited operating

[0001327567-16-000051:8k_2_02:31]
history; risks associated with managing our rapid growth, particularly outside of the United States; our limited experience with new product introductions and the risks associated with new products, including software bugs; the failure to timely develop and achieve market acceptance of new products as well as existing products and services; rapidly evolving technological developments in the market for network security products; and general market, political, economic and business conditions.

[0001327567-16-000051:8k_2_02:32]
Additional risks and uncertainties that could affect our financial results are included under the captions “Risk Factors” and “Management’s Discussion and Analysis of Financial Condition and Results of Operations” in our Quarterly Report on Form 10-Q filed with the SEC on February 26, 2016, which is available on our website at investors.paloaltonetworks.com and on the SEC’s website at www.sec.gov. Additional information will also be set forth in other filings that we make with the SEC from time to time. All forward-looking statements in this press release are based on information available to us as of the date hereof, and we do not assume any obligation to update the forward-looking statements provided to reflect events that occur or circumstances that exist after the date on which they were made.

[0001327567-16-000051:8k_2_02:33]
Non-GAAP Financial Measures

[0001327567-16-000051:8k_2_02:34]
Palo Alto Networks has provided in this press release financial information that has not been prepared in accordance with generally accepted accounting principles in the United States (GAAP). The company uses these non-GAAP financial measures internally in analyzing its financial results and believes that the use of these non-GAAP financial measures is useful to investors as an additional tool to evaluate ongoing operating results and trends and in comparing the company’s financial results with other companies in its industry, many of which present similar non-GAAP financial measures.

[0001327567-16-000051:8k_2_02:35]
Non-GAAP financial measures are not meant to be considered in isolation or as a substitute for comparable GAAP financial measures, and should be read only in conjunction with the company’s consolidated financial statements prepared in accordance with GAAP. A reconciliation of the company’s historical non-GAAP financial measures to their most directly comparable GAAP measures has been provided in the financial statement tables included in this press release, and investors are encouraged to review the reconciliation.

[0001327567-16-000051:8k_2_02:36]
Non-GAAP net income and net income per share, diluted. Palo Alto Networks defines non-GAAP net income as net income (loss) plus share-based compensation related charges including share-based payroll tax expense, acquisition related costs, amortization expense of acquired intangible assets, litigation related charges including legal settlements, non-cash interest expense related to the company’s convertible senior

[0001327567-16-000051:8k_2_02:37]
4

[0001327567-16-000051:8k_2_02:38]
notes, and intellectual property restructuring related charges. The company also excludes from non-GAAP net income the foreign currency gains (losses) and tax effects associated with these items in order to provide a complete picture of the company’s recurring core business operating results. The company defines non-GAAP net income per share, diluted, as non-GAAP net income divided by the weighted average diluted shares outstanding after giving effect to the anti-dilutive impact of the company’s note hedge agreements, which reduces the potential economic dilution that otherwise would occur upon conversion of the company’s convertible senior notes. Under GAAP, the anti-dilutive impact of the note hedge is not reflected in diluted shares outstanding. Palo Alto Networks believes that excluding these items from non-GAAP net income and non-GAAP net income per share, diluted, provides management and investors with greater visibility into the underlying performance of the company’s core business operating results, meaning its operating performance excluding these items and, from time to time, other discrete charges that are infrequent in nature, over multiple periods.

[0001327567-16-000051:8k_2_02:39]
Billings. Palo Alto Networks defines billings as total revenue plus the change in deferred revenue during the period. The company considers billings to be a key measure used by management to manage the company’s business given the company’s hybrid SaaS revenue model, and believes billings provides investors with an important indicator of the health and visibility of the company’s business because it includes services revenue, which is recognized ratably over the subscription period or the period in which the services are expected to be performed, as the case may be, and product revenue, which is recognized at the time of shipment, provided that all other revenue recognition criteria have been met. The company considers billings to be a useful metric for management and investors, particularly if sales of subscriptions continue to increase and the company experiences strong renewal rates for subscriptions and support and maintenance.

[0001327567-16-000051:8k_2_02:40]
Free cash flow and free cash flow margin. Palo Alto Networks defines free cash flow as cash provided by operating activities less purchases of property, equipment, and other assets. Palo Alto Networks defines free cash flow margin as free cash flow as a percentage of total revenue. The company considers free cash flow and free cash flow margin to be profitability and liquidity measures that provide useful information to management and investors about the amount of cash generated by the business that, after the purchases of property, equipment, and other assets, can be used for operational expenses and strategic opportunities, including investing in our business, making strategic acquisitions, and strengthening the balance sheet.

[0001327567-16-000051:8k_2_02:41]
Investors are cautioned that there are a number of limitations associated with the use of non-GAAP financial measures as an analytical tool. In particular, the billings metric reported by the company includes

[0001327567-16-000051:8k_2_02:42]
amounts that have not yet been recognized as revenue and the free cash flow measure does not represent the total increase or decrease in our cash balance for the period. In addition, many of the adjustments to the company’s GAAP financial measures reflect the exclusion of items that are recurring and will be reflected in the company’s financial results for the foreseeable future, such as share-based compensation, which is an important part of Palo Alto Networks employees’ compensation and impacts their performance. Furthermore, the components that Palo Alto Networks excludes in its calculation of non-GAAP financial measures may differ from the components that its peer companies exclude when they report their non-GAAP results of operations. Palo Alto Networks compensates for these limitations by providing specific information regarding the GAAP amounts excluded from these non-GAAP financial measures. In the future, the company may also exclude non-recurring expenses and other expenses that do not reflect the company’s core business operating results.

[0001327567-16-000051:8k_2_02:43]
About Palo Alto Networks

[0001327567-16-000051:8k_2_02:44]
Palo Alto Networks is the next-generation security company, leading a new era in cybersecurity by safely enabling applications and preventing cyber breaches for tens of thousands of organizations worldwide. Built with an innovative approach and highly differentiated cyberthreat prevention capabilities, our game-changing security platform delivers security far superior to legacy or point products, safely enables daily business operations, and protects an organization’s most valuable assets. Find out more at www.paloaltonetworks.com.

[0001327567-16-000051:8k_2_02:45]
Palo Alto Networks and the Palo Alto Networks logo are trademarks of Palo Alto Networks, Inc. in the United States and in jurisdictions throughout the world. All other trademarks, trade names or service marks used or mentioned herein belong to their respective owners.

[0001327567-16-000051:8k_2_02:46]
Media Contact:

[0001327567-16-000051:8k_2_02:47]
Jennifer Jasper Smith

[0001327567-16-000051:8k_2_02:48]
Head of Corporate Communications

[0001327567-16-000051:8k_2_02:49]
Palo Alto Networks

[0001327567-16-000051:8k_2_02:50]
408-638-3280

[0001327567-16-000051:8k_2_02:51]
jjsmith@paloaltonetworks.com

[0001327567-16-000051:8k_2_02:52]
Investor Relations Contact:

[0001327567-16-000051:8k_2_02:53]
Kelsey Turcotte

[0001327567-16-000051:8k_2_02:54]
Vice President of Investor Relations

[0001327567-16-000051:8k_2_02:55]
Palo Alto Networks

[0001327567-16-000051:8k_2_02:56]
408-753-3872

[0001327567-16-000051:8k_2_02:57]
kturcotte@paloaltonetworks.com

[0001327567-16-000051:8k_2_02:58]
7

[0001327567-16-000051:8k_2_02:59]
| Palo Alto Networks, Inc. |
| Preliminary Condensed Consolidated Statements of Operations |
| (In millions, except per share data) |
| (Unaudited) |
|  | Three Months Ended April 30, |  | Nine Months Ended April 30, |
|  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Revenue: |  |  |  |  |  |  |  |
| Product | $ | 162.1 |  |  | $ | 121.5 |  |  | $ | 479.7 |  |  | $ | 338.6 |  |
| Services | 183.7 |  |  | 112.7 |  |  | 498.0 |  |  | 305.6 |  |
| Total revenue | 345.8 |  |  | 234.2 |  |  | 977.7 |  |  | 644.2 |  |
| Cost of revenue: |  |  |  |  |  |  |  |
| Product | 43.2 |  |  | 32.8 |  |  | 126.9 |  |  | 92.6 |  |
| Services | 51.7 |  |  | 31.6 |  |  | 141.4 |  |  | 84.6 |  |
| Total cost of revenue | 94.9 |  |  | 64.4 |  |  | 268.3 |  |  | 177.2 |  |
| Total gross profit | 250.9 |  |  | 169.8 |  |  | 709.4 |  |  | 467.0 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 74.0 |  |  | 48.4 |  |  | 207.7 |  |  | 132.7 |  |
| Sales and marketing | 202.0 |  |  | 131.1 |  |  | 547.9 |  |  | 360.3 |  |
| General and administrative | 33.5 |  |  | 27.0 |  |  | 98.5 |  |  | 73.0 |  |
| Total operating expenses | 309.5 |  |  | 206.5 |  |  | 854.1 |  |  | 566.0 |  |
| Operating loss | (58.6 | ) |  | (36.7 | ) |  | (144.7 | ) |  | (99.0 | ) |
| Interest expense | (5.8 | ) |  | (5.7 | ) |  | (17.4 | ) |  | (16.7 | ) |
| Other income, net | 1.0 |  |  | — |  |  | 5.7 |  |  | 0.7 |  |
| Loss before income taxes | (63.4 | ) |  | (42.4 | ) |  | (156.4 | ) |  | (115.0 | ) |
| Provision for income taxes | 6.8 |  |  | 3.5 |  |  | 15.0 |  |  | 4.0 |  |
| Net loss | $ | (70.2 | ) |  | $ | (45.9 | ) |  | $ | (171.4 | ) |  | $ | (119.0 | ) |
| Net loss per share, basic and diluted | $ | (0.80 | ) |  | $ | (0.56 | ) |  | $ | (1.98 | ) |  | $ | (1.47 | ) |
| Weighted-average shares used to compute net loss per share, basic and diluted | 87.8 |  |  | 82.3 |  |  | 86.5 |  |  | 80.8 |  |

[0001327567-16-000051:8k_2_02:60]
| Palo Alto Networks, Inc. |
| Reconciliation of GAAP to Non-GAAP Financial Measures |
| (In millions, except per share amounts) |
| (Unaudited) |
|  | Three Months Ended April 30, |  | Nine Months Ended April 30, |
|  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| GAAP net loss | $ | (70.2 | ) |  | $ | (45.9 | ) |  | $ | (171.4 | ) |  | $ | (119.0 | ) |
| Share-based compensation related charges | 112.7 |  |  | 64.1 |  |  | 294.8 |  |  | 164.3 |  |
| Acquisition related costs | — |  |  | 0.3 |  |  | — |  |  | 0.3 |  |
| Amortization expense of acquired intangible assets | 2.1 |  |  | 1.7 |  |  | 6.3 |  |  | 5.0 |  |
| Litigation related charges | 3.1 |  |  | 3.1 |  |  | 9.2 |  |  | 9.2 |  |
| Non-cash interest expense related to convertible notes | 5.9 |  |  | 5.6 |  |  | 17.4 |  |  | 16.6 |  |
| Foreign currency loss associated with non-GAAP adjustments | 1.8 |  |  | 0.6 |  |  | 0.3 |  |  | 0.5 |  |
| Income tax and other tax adjustments related to the above | (16.9 | ) |  | (9.0 | ) |  | (50.2 | ) |  | (26.7 | ) |
| Non-GAAP net income | $ | 38.5 |  |  | $ | 20.5 |  |  | $ | 106.4 |  |  | $ | 50.2 |  |
| GAAP net loss per share, diluted | $ | (0.80 | ) |  | $ | (0.56 | ) |  | $ | (1.98 | ) |  | $ | (1.47 | ) |
| Share-based compensation related charges | 1.27 |  |  | 0.76 |  |  | 3.35 |  |  | 1.99 |  |
| Acquisition related costs | 0.00 |  |  | 0.00 |  |  | 0.00 |  |  | 0.00 |  |
| Amortization expense of acquired intangible assets | 0.02 |  |  | 0.02 |  |  | 0.07 |  |  | 0.06 |  |
| Litigation related charges | 0.03 |  |  | 0.04 |  |  | 0.11 |  |  | 0.11 |  |
| Non-cash interest expense related to convertible notes | 0.07 |  |  | 0.07 |  |  | 0.20 |  |  | 0.21 |  |
| Foreign currency loss associated with non-GAAP adjustments | 0.02 |  |  | 0.01 |  |  | 0.00 |  |  | 0.01 |  |
| Income tax and other tax adjustments related to the above | (0.19 | ) |  | (0.11 | ) |  | (0.58 | ) |  | (0.33 | ) |
| Non-GAAP net income per share, diluted | $ | 0.42 |  |  | $ | 0.23 |  |  | $ | 1.17 |  |  | $ | 0.58 |  |
| GAAP weighted-average shares used to compute net loss per share, diluted | 87.8 |  |  | 82.3 |  |  | 86.5 |  |  | 80.8 |  |
| Weighted-average effect of potentially dilutive securities [a] | 3.5 |  |  | 5.7 |  |  | 4.7 |  |  | 5.6 |  |
| Non-GAAP weighted-average shares used to compute net income per share, diluted | 91.3 |  |  | 88.0 |  |  | 91.2 |  |  | 86.4 |  |
| Total revenue | $ | 345.8 |  |  | $ | 234.2 |  |  | $ | 977.7 |  |  | $ | 644.2 |  |
| Add: change in total deferred revenue | 140.4 |  |  | 68.0 |  |  | 355.5 |  |  | 181.3 |  |
| Billings | $ | 486.2 |  |  | $ | 302.2 |  |  | $ | 1,333.2 |  |  | $ | 825.5 |  |
| Net cash provided by operating activities | $ | 170.1 |  |  | $ | 87.2 |  |  | $ | 470.6 |  |  | $ | 239.0 |  |
| Less: purchases of property, equipment, and other assets | 19.3 |  |  | 9.8 |  |  | 56.2 |  |  | 21.9 |  |
| Free cash flow | $ | 150.8 |  |  | $ | 77.4 |  |  | $ | 414.4 |  |  | $ | 217.1 |  |
| Net cash provided by (used in) investing activities | $ | (54.6 | ) |  | $ | 6.8 |  |  | $ | (339.3 | ) |  | $ | (480.6 | ) |
| Net cash provided by financing activities | $ | 21.3 |  |  | $ | 17.1 |  |  | $ | 42.9 |  |  | $ | 41.9 |  |

[0001327567-16-000051:8k_2_02:61]
___________

[0001327567-16-000051:8k_2_02:62]
[a]    Non-GAAP net income per share, diluted, includes the potentially dilutive effect of employee equity incentive plan awards and convertible senior notes outstanding. In addition, non-GAAP net income per share, diluted, includes the anti-dilutive impact of the company’s note hedge agreements, which reduced the potentially dilutive effect of the convertible notes for the three and nine months ended April 30, 2016 by 1.4 million shares and 1.6 million shares, respectively, and 1.3 million shares and 0.6 million shares, for the three and nine months ended April 30, 2015, respectively.

[0001327567-16-000051:8k_2_02:63]
9

[0001327567-16-000051:8k_2_02:64]
| Palo Alto Networks, Inc. |
| Preliminary Condensed Consolidated Balance Sheets |
| (In millions) |
| (Unaudited) |
|  | April 30, 2016 |  | July 31, 2015 |
| Assets |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 550.0 |  |  | $ | 375.8 |  |
| Short-term investments | 537.5 |  |  | 413.2 |  |
| Accounts receivable, net | 267.6 |  |  | 212.4 |  |
| Prepaid expenses and other current assets | 91.1 |  |  | 72.6 |  |
| Total current assets | 1,446.2 |  |  | 1,074.0 |  |
| Property and equipment, net | 100.5 |  |  | 62.9 |  |
| Long-term investments | 682.9 |  |  | 538.8 |  |
| Goodwill | 163.5 |  |  | 163.5 |  |
| Intangible assets, net | 46.4 |  |  | 52.7 |  |
| Other assets | 67.5 |  |  | 73.3 |  |
| Total assets | $ | 2,507.0 |  |  | $ | 1,965.2 |  |
| Liabilities, temporary equity, and stockholders’ equity |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 24.3 |  |  | $ | 13.2 |  |
| Accrued compensation | 56.4 |  |  | 79.8 |  |
| Accrued and other liabilities | 45.1 |  |  | 28.2 |  |
| Deferred revenue | 610.4 |  |  | 423.9 |  |
| Convertible senior notes, net | 502.8 |  |  | 487.1 |  |
| Total current liabilities | 1,239.0 |  |  | 1,032.2 |  |
| Long-term deferred revenue | 458.8 |  |  | 289.8 |  |
| Other long-term liabilities | 78.0 |  |  | 67.4 |  |
| Temporary equity | 72.2 |  |  | 87.9 |  |
| Stockholders’ equity: |  |  |  |
| Preferred stock | — |  |  | — |  |
| Common stock and additional paid-in capital | 1,330.5 |  |  | 988.7 |  |
| Accumulated other comprehensive income (loss) | 0.6 |  |  | (0.1 | ) |
| Accumulated deficit | (672.1 | ) |  | (500.7 | ) |
| Total stockholders’ equity | 659.0 |  |  | 487.9 |  |
| Total liabilities, temporary equity, and stockholders’ equity | $ | 2,507.0 |  |  | $ | 1,965.2 |  |

[0001327567-16-000051:8k_2_02:65]
10

[0001327567-16-000051:8k_2_02:66]
| Palo Alto Networks, Inc. |
| Preliminary Condensed Consolidated Statements of Cash Flows |
| (In millions) |
| (Unaudited) |
|  | Nine Months Ended April 30, |
|  | 2016 |  | 2015 |
| Cash flows from operating activities |  |  |  |
| Net loss | $ | (171.4 | ) |  | $ | (119.0 | ) |
| Adjustments to reconcile net loss to net cash provided by operating activities: |  |  |  |
| Share-based compensation for equity based awards | 283.2 |  |  | 155.5 |  |
| Depreciation and amortization | 30.7 |  |  | 20.3 |  |
| Amortization of investment premiums, net of accretion of purchase discounts | 2.4 |  |  | 2.3 |  |
| Amortization of debt discount and debt issuance costs | 17.4 |  |  | 16.6 |  |
| Excess tax benefit from share-based compensation arrangements | (0.7 | ) |  | (0.5 | ) |
| Changes in operating assets and liabilities: |  |  |  |
| Accounts receivable, net | (55.3 | ) |  | (15.0 | ) |
| Prepaid expenses and other assets | (7.1 | ) |  | (30.9 | ) |
| Accounts payable | 11.7 |  |  | (3.9 | ) |
| Accrued compensation | (23.4 | ) |  | 4.8 |  |
| Accrued and other liabilities | 27.6 |  |  | 27.5 |  |
| Deferred revenue | 355.5 |  |  | 181.3 |  |
| Net cash provided by operating activities | 470.6 |  |  | 239.0 |  |
| Cash flows from investing activities |  |  |  |
| Purchases of investments | (830.1 | ) |  | (666.5 | ) |
| Proceeds from sales of investments | 137.4 |  |  | 7.0 |  |
| Proceeds from maturities of investments | 409.6 |  |  | 200.8 |  |
| Purchases of property, equipment, and other assets | (56.2 | ) |  | (21.9 | ) |
| Net cash used in investing activities | (339.3 | ) |  | (480.6 | ) |
| Cash flows from financing activities |  |  |  |
| Proceeds from sales of shares through employee equity incentive plans | 42.2 |  |  | 41.4 |  |
| Excess tax benefit from share-based compensation arrangements | 0.7 |  |  | 0.5 |  |
| Net cash provided by financing activities | 42.9 |  |  | 41.9 |  |
| Net increase (decrease) in cash and cash equivalents | 174.2 |  |  | (199.7 | ) |
| Cash and cash equivalents - beginning of period | 375.8 |  |  | 653.8 |  |
| Cash and cash equivalents - end of period | $ | 550.0 |  |  | $ | 454.1 |  |

[0001327567-16-000051:8k_2_02:67]
11
