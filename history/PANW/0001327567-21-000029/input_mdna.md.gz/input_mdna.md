# PANW MD&A — 0001327567-21-000029


## mdna

[0001327567-21-000029:mdna:1]
ITEM 7.     MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS

[0001327567-21-000029:mdna:2]
The following discussion and analysis of our financial condition and results of operations should be read in conjunction with our consolidated financial statements and related notes appearing elsewhere in this Annual Report on Form 10-K. The following discussion and analysis contains forward-looking statements based on current expectations and assumptions that are subject to risks and uncertainties, which could cause our actual results to differ materially from those anticipated or implied by any forward-looking statements. Factors that could cause or contribute to such differences include, but are not limited to, those discussed in this Annual Report on Form 10-K, and in particular, the risks discussed under the caption “Risk Factors” in Part I, Item 1A of this report.

[0001327567-21-000029:mdna:3]
Our Management’s Discussion and Analysis of Financial Condition and Results of Operations (“MD&A”) is organized as follows:

[0001327567-21-000029:mdna:4]
•Overview. A discussion of our business and overall analysis of financial and other highlights in order to provide context for the remainder of MD&A.

[0001327567-21-000029:mdna:5]
•Key Financial Metrics. A summary of our GAAP and non-GAAP key financial metrics, which management monitors to evaluate our performance.

[0001327567-21-000029:mdna:6]
•Results of Operations. A discussion of the nature and trends in our financial results and an analysis of our financial results comparing fiscal 2021 to fiscal 2020. For discussion and analysis related to our financial results comparing fiscal 2020 to 2019, refer to Part II, Item 7. Management’s Discussion and Analysis of Financial Condition and Results of Operations in our Annual Report on Form 10-K for fiscal 2020, which was filed with the Securities and Exchange Commission on September 4, 2020.

[0001327567-21-000029:mdna:7]
•Liquidity and Capital Resources. An analysis of changes in our balance sheets and cash flows, and a discussion of our financial condition and our ability to meet cash needs.

[0001327567-21-000029:mdna:8]
•Contractual Obligations and Commitments. An overview of our contractual obligations, contingent liabilities, commitments, and off-balance sheet arrangements outstanding as of July 31, 2021, including expected payment schedules.

[0001327567-21-000029:mdna:9]
•Critical Accounting Estimates. A discussion of our accounting policies that require critical estimates, assumptions, and judgments.

[0001327567-21-000029:mdna:10]
•Recent Accounting Pronouncements. A discussion of expected impacts of impending accounting changes on financial information to be reported in the future.

[0001327567-21-000029:mdna:11]
Overview

[0001327567-21-000029:mdna:12]
We empower enterprises, service providers, and government entities to secure all users, applications, data, networks, clouds and devices with comprehensive visibility and context continuously across all locations. We deliver cybersecurity products covering a broad range of use cases, enabling our end-customers to secure their networks, remote and hybrid workforces, branch locations, and public and private clouds, and to advance their Security Operations Centers (“SOC”). We believe our portfolio offers advanced prevention and security, while reducing the total cost of ownership for organizations by improving operational efficiency and eliminating the need for siloed point products. We do this with solutions focused on delivering value in five fundamental areas:

[0001327567-21-000029:mdna:13]
Zero Trust Network Security:

[0001327567-21-000029:mdna:14]
•Enabling zero trust network security through our ML-Powered Next-Generation Firewalls, available in a number of form factors, including physical, virtual, and containerized appliances, as well as a cloud-delivered service. This also includes our add-on Cloud-Delivered Security Services, such as Threat Prevention, WildFire, URL Filtering, Advanced URL Filtering, DNS Security, IoT Security, GlobalProtect, SD-WAN, Enterprise Data Loss Prevention (“Enterprise DLP”), SaaS Security API and SaaS Security Inline that secure content, applications, users, and devices across our ML-Powered Next-Generation Firewalls, Prisma, and Cortex product lines, to enable best-in-class security across a broad range of applications. Panorama, our network security management solution, available as hardware or virtual machine, can centrally manage all of our firewalls irrespective of their form factor, location, or scale.

[0001327567-21-000029:mdna:15]
Cloud Security:

[0001327567-21-000029:mdna:16]
•Enabling cloud security through our Prisma security offerings. Prisma Cloud, the industry’s most comprehensive Cloud Native Security Platform (“CNSP”), secures multi- and hybrid-cloud environments and cloud native applications, integrating security across the full deployment lifecycle. VM-Series and CN-Series enforce in-line network security in multi- and hybrid-cloud environments.

[0001327567-21-000029:mdna:17]
- 43 -

[0001327567-21-000029:mdna:18]
Secure Access Service Edge:

[0001327567-21-000029:mdna:19]
•Prisma Access, the industry’s most complete cloud-delivered security platform, together with Prisma SD-WAN, SaaS Security API and SaaS Security Inline, provide a comprehensive Secure Access Service Edge (“SASE”) offering that is used to secure remote workforces and enable the cloud-delivered branch.

[0001327567-21-000029:mdna:20]
Security Analytics and Automation:

[0001327567-21-000029:mdna:21]
•Delivering the next generation of endpoint security, security analytics and security automation solutions through our Cortex portfolio. These include our industry-leading extended detection and response platform Cortex XDR to prevent, detect, and respond to complex cybersecurity attacks, Cortex XSOAR for security orchestration, automation, and response (“SOAR”), Cortex Xpanse for attack surface management (“ASM”) and Cortex Data Lake allowing our customers to collect and analyze large amounts of context-rich data across endpoints, networks, and clouds. These products are delivered as software or SaaS subscriptions.

[0001327567-21-000029:mdna:22]
Threat Intelligence and Security Consulting (Unit 42):

[0001327567-21-000029:mdna:23]
•Enabling security teams with up-to-date threat intelligence and deep cybersecurity expertise before, during and after attacks through our Unit 42 threat research and security consulting team. Unit 42 offers incident response, risk management, board advisory and proactive cybersecurity assessment services.

[0001327567-21-000029:mdna:24]
For fiscal 2021 and 2020, total revenue was $4.3 billion and $3.4 billion, respectively, representing year-over-year growth of 24.9%. Our growth reflects the increased adoption of our portfolio, which consists of product, subscriptions, and support. We believe our portfolio will enable us to benefit from recurring revenues as we continue to grow our installed end-customer base. As of July 31, 2021, we had end-customers in over 170 countries. Our end-customers represent a broad range of industries including education, energy, financial services, government entities, healthcare, Internet and media, manufacturing, public sector, and telecommunications, and include some of the largest Fortune 100 and Global 2000 companies in the world. We maintain a field sales force that works closely with our channel partners in developing sales opportunities. We primarily use a two-tiered, indirect fulfillment model whereby we sell our products, subscriptions, and support to our distributors, which, in turn, sell to our resellers, which then sell to our end-customers.

[0001327567-21-000029:mdna:25]
Our product revenue was $1.1 billion or 26.3% of total revenue for fiscal 2021, representing year-over-year growth of 5.3%. Product revenue is generated from sales of our appliances, primarily our ML-Powered Next-Generation Firewall, which is available in a number of form factors, including as physical, virtual, and containerized appliances. Our ML-Powered Next-Generation Firewall incorporates our PAN-OS operating system, which provides a consistent set of capabilities across our entire network security product line. Our products are designed for different performance requirements throughout an organization, ranging from our PA-410, which is designed for small organizations and remote or branch offices, to our top-of-the-line PA-7080, which is designed for large-scale data centers and service provider use. The same firewall functionality that is delivered in our physical appliances is also available in our VM-Series virtual firewalls, which secure virtualized and cloud-based computing environments, and in our CN-Series container firewalls, which secure container environments and traffic.

[0001327567-21-000029:mdna:26]
Our subscription and support revenue grew to $3.1 billion or 73.7% of total revenue for fiscal 2021, representing year-over-year growth of 33.8%. Our subscriptions provide our end-customers with near real-time access to the latest antivirus, intrusion prevention, web filtering, modern malware prevention, data loss prevention, and cloud access security broker capabilities across the network, endpoints, and the cloud. When end-customers purchase our physical, virtual, or container firewall appliances, or certain cloud offerings, they typically purchase support in order to receive ongoing security updates, upgrades, bug fixes, and repairs. In addition to the subscriptions purchased with these appliances, end-customers may also purchase other subscriptions on a per-user, per-endpoint, or capacity-based basis. We also offer professional services, including incident response, risk management, and digital forensic services.

[0001327567-21-000029:mdna:27]
We continue to invest in innovation and acquire businesses as we evolve and further extend the capabilities of our portfolio, as we believe that innovation and timely development of new features and products is essential to meeting the needs of our end-customers and improving our competitive position. During fiscal 2021, we introduced several new offerings, including: Cortex XDR 2.5, Next Generation SD-WAN, Prisma Cloud 2.0, Enterprise DLP, 5G Security, IoT Healthcare Security, Prisma Access 2.0 and Complete Zero Trust Network Security. Additionally, we acquired productive investments that we believe fit well within our long-term strategy. For example, in September 2020, we acquired Crypsis, which we expect will expand our incident response capabilities and strengthen our Cortex strategy; in November 2020, we acquired Sinefa, which we expect will extend our Prisma Access offering; in December 2020, we acquired Expanse, which we expect will enrich our Cortex offerings and provide organizations an integrated view of the enterprise to combine external, internal, and threat data; and in March 2021, we acquired Bridgecrew, which we expect will expand our Prisma Cloud offering to deliver security across the full application lifecycle.

[0001327567-21-000029:mdna:28]
We believe that the growth of our business and our short-term and long-term success are dependent upon many factors, including our ability to extend our technology leadership, grow our base of end-customers, expand deployment of our portfolio and support offerings within existing end-customers, and focus on end-customer satisfaction. To manage any future growth effectively, we must continue to improve and expand our information technology and financial infrastructure, our operating and administrative

[0001327567-21-000029:mdna:29]
- 44 -

[0001327567-21-000029:mdna:30]
systems and controls, and our ability to manage headcount, capital, and processes in an efficient manner. While these areas present significant opportunities for us, they also pose challenges and risks that we must successfully address in order to sustain the growth of our business and improve our operating results. For additional information regarding the challenges and risks we face, see the “Risk Factors” section in Part I, Item 1A of this Annual Report on Form 10-K.

[0001327567-21-000029:mdna:31]
Impact of COVID-19 on Our Business

[0001327567-21-000029:mdna:32]
We are actively monitoring, evaluating, and responding to developments relating to COVID-19, which has resulted in and is expected to continue to result in continued significant global, social, and business disruption. As described in “Impacts of COVID-19 on our Business” included in Part I, Item 1 Business in this Annual Report, we have made some changes to our business including instituting a global work-from-home policy beginning in March 2020 and adopting our FLEXWORK initiative in fiscal 2021, which did not incur significant disruptions in our work operations during fiscal 2020 and fiscal 2021. We will continue to actively monitor the situation, including progress made through vaccinations, and we will make further changes to our business operations as may be required by federal, state, or local authorities or that we determine are in the best interests of our employees, end-customers, partners, suppliers, and stockholders. Our focus remains on the safety of our employees, and we strive to protect the health and well-being of the communities in which we operate, in part, by providing technology to our employees, end-customers, and partners to help them do their best work while remote.

[0001327567-21-000029:mdna:33]
Although some end-customers adopted Prisma Access as their secure work-from-home solution for the longer term, there continues to be uncertainty regarding the business outlook due to COVID-19, which may curtail our end-customers’ spending and could lead them to delay or defer purchasing decisions, and lengthen sales cycles and payment terms, which could materially adversely impact our business, results of operations, and overall financial performance. Also, certain of our end-customers or partners may be or may become credit or cash constrained, making it difficult for them to fulfill their payment obligations to us. The extent of the impact of COVID-19 on our operational and financial performance will depend on developments, including the duration and spread of the virus (including variants), impact on our end-customers’ spending, volume of sales and length of our sales cycles, impact on our partners, suppliers, and employees, actions that may be taken by governmental authorities, and other factors identified in Part I, Item 1A “Risk Factors” in this Form 10-K. Given the dynamic nature of these circumstances, the full impact of COVID-19 on our ongoing business, results of operations, and overall financial performance cannot be reasonably estimated at this time.

[0001327567-21-000029:mdna:34]
Key Financial Metrics

[0001327567-21-000029:mdna:35]
We monitor the key financial metrics set forth in the tables below to help us evaluate growth trends, establish budgets, measure the effectiveness of our sales and marketing efforts, and assess operational efficiencies. We discuss revenue, gross margin, and the components of operating loss and margin below under “Results of Operations.”

[0001327567-21-000029:mdna:36]
|  | July 31, |
|  | 2021 |  | 2020 |
|  | (in millions) |
| Total deferred revenue | $ | 5,024.0 |  |  | $ | 3,810.2 |  |
| Cash, cash equivalents, and investments | $ | 3,789.4 |  |  | $ | 4,302.2 |  |

[0001327567-21-000029:mdna:37]
|  | Year Ended July 31, |
|  | 2021 |  | 2020 |  | 2019 |
|  | (dollars in millions) |
| Total revenue | $ | 4,256.1 |  |  | $ | 3,408.4 |  |  | $ | 2,899.6 |  |
| Total revenue year-over-year percentage increase | 24.9 | % |  | 17.5 | % |  | 27.5 | % |
| Gross margin | 70.0 | % |  | 70.7 | % |  | 72.1 | % |
| Operating loss | $ | (304.1) |  |  | $ | (179.0) |  |  | $ | (54.1) |  |
| Operating margin | (7.1) | % |  | (5.3) | % |  | (1.9) | % |
| Billings | $ | 5,452.2 |  |  | $ | 4,301.7 |  |  | $ | 3,489.8 |  |
| Billings year-over-year percentage increase | 26.7 | % |  | 23.3 | % |  | 22.2 | % |
| Cash flow provided by operating activities | $ | 1,503.0 |  |  | $ | 1,035.7 |  |  | $ | 1,055.6 |  |
| Free cash flow (non-GAAP) | $ | 1,387.0 |  |  | $ | 821.3 |  |  | $ | 924.4 |  |

[0001327567-21-000029:mdna:38]
•Deferred Revenue. Our deferred revenue primarily consists of amounts that have been invoiced but have not been recognized as revenue as of the period end. The majority of our deferred revenue balance consists of subscription and support revenue that is recognized ratably over the contractual service period. We monitor our deferred revenue balance because it represents a significant portion of revenue to be recognized in future periods.

[0001327567-21-000029:mdna:39]
- 45 -

[0001327567-21-000029:mdna:40]
•Billings. We define billings as total revenue plus the change in total deferred revenue, net of acquired deferred revenue, during the period. We consider billings to be a key metric used by management to manage our business. We believe billings provides investors with an important indicator of the health and visibility of our business because it includes subscription and support revenue, which is recognized ratably over the contractual service period, and product revenue, which is recognized at the time of shipment, provided that all other conditions for revenue recognition have been met. We consider billings to be a useful metric for management and investors, particularly if we continue to experience increased sales of subscriptions and strong renewal rates for subscription and support offerings, and as we monitor our near-term cash flows. While we believe that billings provides useful information to investors and others in understanding and evaluating our operating results in the same manner as our management, it is important to note that other companies, including companies in our industry, may not use billings, may calculate billings differently, may have different billing frequencies, or may use other financial measures to evaluate their performance, all of which could reduce the usefulness of billings as a comparative measure. We calculate billings in the following manner:

[0001327567-21-000029:mdna:41]
|  | Year Ended July 31, |
|  | 2021 |  | 2020 |  | 2019 |
|  | (in millions) |
| Billings: |  |  |  |  |  |
| Total revenue | $ | 4,256.1 |  |  | $ | 3,408.4 |  |  | $ | 2,899.6 |  |
| Add: change in total deferred revenue, net of acquired deferred revenue | 1,196.1 |  |  | 893.3 |  |  | 590.2 |  |
| Billings | $ | 5,452.2 |  |  | $ | 4,301.7 |  |  | $ | 3,489.8 |  |

[0001327567-21-000029:mdna:42]
•    Cash Flow Provided by Operating Activities. We monitor cash flow provided by operating activities as a measure of our overall business performance. Our cash flow provided by operating activities is driven in large part by sales of our products and from up-front payments for subscription and support offerings. Monitoring cash flow provided by operating activities enables us to analyze our financial performance without the non-cash effects of certain items such as depreciation, amortization, and share-based compensation costs, thereby allowing us to better understand and manage the cash needs of our business.

[0001327567-21-000029:mdna:43]
•    Free Cash Flow (non-GAAP). We define free cash flow, a non-GAAP financial measure, as cash provided by operating activities less purchases of property, equipment, and other assets. We consider free cash flow to be a profitability and liquidity measure that provides useful information to management and investors about the amount of cash generated by the business after necessary capital expenditures. A limitation of the utility of free cash flow as a measure of our financial performance and liquidity is that it does not represent the total increase or decrease in our cash balance for the period. In addition, it is important to note that other companies, including companies in our industry, may not use free cash flow, may calculate free cash flow in a different manner than we do, or may use other financial measures to evaluate their performance, all of which could reduce the usefulness of free cash flow as a comparative measure. A reconciliation of free cash flow to cash flow provided by operating activities, the most directly comparable financial measure calculated and presented in accordance with GAAP, is provided below:

[0001327567-21-000029:mdna:44]
|  | Year Ended July 31, |
|  | 2021 |  | 2020 |  | 2019 |
|  | (in millions) |
| Free cash flow (non-GAAP): |  |  |  |  |  |
| Net cash provided by operating activities | $ | 1,503.0 |  |  | $ | 1,035.7 |  |  | $ | 1,055.6 |  |
| Less: purchases of property, equipment, and other assets | 116.0 |  |  | 214.4 |  |  | 131.2 |  |
| Free cash flow (non-GAAP) | $ | 1,387.0 |  |  | $ | 821.3 |  |  | $ | 924.4 |  |
| Net cash provided by (used in) investing activities | $ | (1,480.6) |  |  | $ | 288.0 |  |  | $ | (1,825.9) |  |
| Net cash provided by (used in) financing activities | $ | (1,104.0) |  |  | $ | 673.0 |  |  | $ | (773.9) |  |

[0001327567-21-000029:mdna:45]
- 46 -

[0001327567-21-000029:mdna:46]
Results of Operations

[0001327567-21-000029:mdna:47]
The following table summarizes our results of operations for the periods presented and as a percentage of our total revenue for those periods based on our consolidated statements of operations data. The period to period comparison of results is not necessarily indicative of results for future periods.

[0001327567-21-000029:mdna:48]
|  | Year Ended July 31, |
|  | 2021 |  | 2020 |  | 2019 |
|  | Amount |  | % of Revenue |  | Amount |  | % of Revenue |  | Amount |  | % of Revenue |
|  | (dollars in millions) |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 1,120.3 |  |  | 26.3 | % |  | $ | 1,064.2 |  |  | 31.2 | % |  | $ | 1,096.2 |  |  | 37.8 | % |
| Subscription and support | 3,135.8 |  |  | 73.7 | % |  | 2,344.2 |  |  | 68.8 | % |  | 1,803.4 |  |  | 62.2 | % |
| Total revenue | 4,256.1 |  |  | 100.0 | % |  | 3,408.4 |  |  | 100.0 | % |  | 2,899.6 |  |  | 100.0 | % |
| Cost of revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Product | 308.5 |  |  | 7.2 | % |  | 294.4 |  |  | 8.6 | % |  | 315.9 |  |  | 10.9 | % |
| Subscription and support | 966.4 |  |  | 22.8 | % |  | 705.1 |  |  | 20.7 | % |  | 492.5 |  |  | 17.0 | % |
| Total cost of revenue(1) | 1,274.9 |  |  | 30.0 | % |  | 999.5 |  |  | 29.3 | % |  | 808.4 |  |  | 27.9 | % |
| Total gross profit | 2,981.2 |  |  | 70.0 | % |  | 2,408.9 |  |  | 70.7 | % |  | 2,091.2 |  |  | 72.1 | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | 1,140.4 |  |  | 26.8 | % |  | 768.1 |  |  | 22.5 | % |  | 539.5 |  |  | 18.6 | % |
| Sales and marketing | 1,753.8 |  |  | 41.1 | % |  | 1,520.2 |  |  | 44.7 | % |  | 1,344.0 |  |  | 46.4 | % |
| General and administrative | 391.1 |  |  | 9.2 | % |  | 299.6 |  |  | 8.8 | % |  | 261.8 |  |  | 9.0 | % |
| Total operating expenses(1) | 3,285.3 |  |  | 77.1 | % |  | 2,587.9 |  |  | 76.0 | % |  | 2,145.3 |  |  | 74.0 | % |
| Operating loss | (304.1) |  |  | (7.1) | % |  | (179.0) |  |  | (5.3) | % |  | (54.1) |  |  | (1.9) | % |
| Interest expense | (163.3) |  |  | (3.8) | % |  | (88.7) |  |  | (2.6) | % |  | (83.9) |  |  | (2.9) | % |
| Other income, net | 2.4 |  |  | 0.0 | % |  | 35.9 |  |  | 1.1 | % |  | 63.4 |  |  | 2.2 | % |
| Loss before income taxes | (465.0) |  |  | (10.9) | % |  | (231.8) |  |  | (6.8) | % |  | (74.6) |  |  | (2.6) | % |
| Provision for income taxes | 33.9 |  |  | 0.8 | % |  | 35.2 |  |  | 1.0 | % |  | 7.3 |  |  | 0.2 | % |
| Net loss | $ | (498.9) |  |  | (11.7) | % |  | $ | (267.0) |  |  | (7.8) | % |  | $ | (81.9) |  |  | (2.8) | % |

[0001327567-21-000029:mdna:49]
______________

[0001327567-21-000029:mdna:50]
(1)Includes share-based compensation as follows:

[0001327567-21-000029:mdna:51]
|  | Year Ended July 31, |
|  | 2021 |  | 2020 |  | 2019 |
|  | (in millions) |
| Cost of product revenue | $ | 6.2 |  |  | $ | 5.7 |  |  | $ | 5.6 |  |
| Cost of subscription and support revenue | 93.0 |  |  | 77.7 |  |  | 71.3 |  |
| Research and development | 428.9 |  |  | 274.6 |  |  | 186.8 |  |
| Sales and marketing | 269.9 |  |  | 214.5 |  |  | 221.9 |  |
| General and administrative | 128.9 |  |  | 92.0 |  |  | 102.1 |  |
| Total share-based compensation | $ | 926.9 |  |  | $ | 664.5 |  |  | $ | 587.7 |  |

[0001327567-21-000029:mdna:52]
- 47 -

[0001327567-21-000029:mdna:53]
Revenue

[0001327567-21-000029:mdna:54]
Our revenue consists of product revenue and subscription and support revenue. Revenue is recognized upon transfer of control of the corresponding promised products and subscriptions and support to our customers in an amount that reflects the consideration we expect to be entitled in exchange for those products and subscriptions and support. We expect our revenue to vary from quarter to quarter based on seasonal and cyclical factors.

[0001327567-21-000029:mdna:55]
Product Revenue

[0001327567-21-000029:mdna:56]
Product revenue is derived primarily from sales of our appliances. Product revenue also includes revenue derived from software licenses of Panorama and the VM-Series. Our appliances and software licenses include a broad set of built-in networking and security features and functionalities. We recognize product revenue at the time of hardware shipment or delivery of software license.

[0001327567-21-000029:mdna:57]
|  | Year Ended July 31, |  |  |  | Year Ended July 31, |  |  |
|  | 2021 |  | 2020 |  | Change |  | 2020 |  | 2019 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Product | $ | 1,120.3 |  |  | $ | 1,064.2 |  |  | $ | 56.1 |  |  | 5.3 | % |  | $ | 1,064.2 |  |  | $ | 1,096.2 |  |  | $ | (32.0) |  |  | (2.9) | % |

[0001327567-21-000029:mdna:58]
Product revenue increased for fiscal 2021 compared to fiscal 2020, largely driven by increases in software sales, reflecting increased demand for our products.

[0001327567-21-000029:mdna:59]
Subscription and Support Revenue

[0001327567-21-000029:mdna:60]
Subscription and support revenue is derived primarily from sales of our subscription and support offerings. Our contractual subscription and support contracts are typically one to five years. We recognize revenue from subscriptions and support over time as the services are performed. As a percentage of total revenue, we expect our subscription and support revenue to vary from quarter to quarter and increase over the long term as we introduce new subscriptions, renew existing subscription and support contracts, and expand our installed end-customer base.

[0001327567-21-000029:mdna:61]
|  | Year Ended July 31, |  |  |  | Year Ended July 31, |  |  |
|  | 2021 |  | 2020 |  | Change |  | 2020 |  | 2019 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Subscription | $ | 1,898.8 |  |  | $ | 1,405.3 |  |  | $ | 493.5 |  |  | 35.1 | % |  | $ | 1,405.3 |  |  | $ | 1,032.7 |  |  | $ | 372.6 |  |  | 36.1 | % |
| Support | 1,237.0 |  |  | 938.9 |  |  | 298.1 |  |  | 31.7 | % |  | 938.9 |  |  | 770.7 |  | 168.2 |  |  | 21.8 | % |
| Total subscription and support | $ | 3,135.8 |  |  | $ | 2,344.2 |  |  | $ | 791.6 |  |  | 33.8 | % |  | $ | 2,344.2 |  |  | $ | 1,803.4 |  |  | $ | 540.8 |  |  | 30.0 | % |

[0001327567-21-000029:mdna:62]
Subscription and support revenue increased year-over-year for fiscal 2021 due to increased demand for our subscription and support offerings from both new and existing end-customers. The mix between subscription revenue and support revenue will vary over time, depending on the introduction of new subscription offerings, renewals of support services, and our ability to increase sales to new and existing end-customers.

[0001327567-21-000029:mdna:63]
Revenue by Geographic Theater

[0001327567-21-000029:mdna:64]
|  | Year Ended July 31, |  |  |  | Year Ended July 31, |  |  |
|  | 2021 |  | 2020 |  | Change |  | 2020 |  | 2019 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Americas | $ | 2,937.5 |  |  | $ | 2,318.0 |  |  | $ | 619.5 |  |  | 26.7 | % |  | $ | 2,318.0 |  |  | $ | 1,977.0 |  |  | $ | 341.0 |  |  | 17.2 | % |
| EMEA | 817.3 |  |  | 671.9 |  |  | 145.4 |  |  | 21.6 | % |  | 671.9 |  |  | 568.6 |  |  | 103.3 |  |  | 18.2 | % |
| APAC | 501.3 |  |  | 418.5 |  |  | 82.8 |  |  | 19.8 | % |  | 418.5 |  |  | 354.0 |  |  | 64.5 |  |  | 18.2 | % |
| Total revenue | $ | 4,256.1 |  |  | $ | 3,408.4 |  |  | $ | 847.7 |  |  | 24.9 | % |  | $ | 3,408.4 |  |  | $ | 2,899.6 |  |  | $ | 508.8 |  |  | 17.5 | % |

[0001327567-21-000029:mdna:65]
With respect to geographic theaters, the Americas contributed the largest portion of the year-over-year increases in revenue for fiscal 2021 due to its larger and more established sales force compared to our other theaters. Revenue from both Europe, the Middle East, and Africa (“EMEA”) and Asia Pacific and Japan (“APAC”) increased year-over-year for fiscal 2021 due to our increasing investment in global sales force in order to support our growth and innovation.

[0001327567-21-000029:mdna:66]
- 48 -

[0001327567-21-000029:mdna:67]
Cost of Revenue

[0001327567-21-000029:mdna:68]
Our cost of revenue consists of cost of product revenue and cost of subscription and support revenue.

[0001327567-21-000029:mdna:69]
Cost of Product Revenue

[0001327567-21-000029:mdna:70]
Cost of product revenue primarily includes costs paid to our manufacturing partners. Our cost of product revenue also includes personnel costs, which consist of salaries, benefits, bonuses, share-based compensation, and travel and entertainment associated with our operations organization, amortization of intellectual property licenses, product testing costs, shipping and tariff costs, and allocated costs. Allocated costs consist of certain facilities, depreciation, benefits, recruiting, and information technology costs that we allocate based on headcount. We expect our cost of product revenue to fluctuate with our product revenue.

[0001327567-21-000029:mdna:71]
|  | Year Ended July 31, |  |  |  | Year Ended July 31, |  |  |
|  | 2021 |  | 2020 |  | Change |  | 2020 |  | 2019 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Cost of product revenue | $ | 308.5 |  |  | $ | 294.4 |  |  | $ | 14.1 |  |  | 4.8 | % |  | $ | 294.4 |  |  | $ | 315.9 |  |  | $ | (21.5) |  |  | (6.8) | % |
| Number of employees at period end | 127 |  |  | 117 |  |  | 10 |  |  | 8.5 | % |  | 117 |  |  | 102 |  |  | 15 |  |  | 14.7 | % |

[0001327567-21-000029:mdna:72]
Cost of product revenue increased for fiscal 2021 compared to fiscal 2020 primarily due to an increase in the volume of product sold, partially offset by product mix. The remaining increase was largely due to increased overhead costs to support the growth of our product revenue.

[0001327567-21-000029:mdna:73]
Cost of Subscription and Support Revenue

[0001327567-21-000029:mdna:74]
Cost of subscription and support revenue includes personnel costs for our global customer support and technical operations organizations, customer support and repair costs, third-party professional services costs, data center and cloud hosting service costs, amortization of acquired intangible assets and capitalized software development costs, and allocated costs. We expect our cost of subscription and support revenue to increase as our installed end-customer base grows and adoption of our cloud-based subscription offerings increases.

[0001327567-21-000029:mdna:75]
|  | Year Ended July 31, |  |  |  | Year Ended July 31, |  |  |
|  | 2021 |  | 2020 |  | Change |  | 2020 |  | 2019 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Cost of subscription and support revenue | $ | 966.4 |  |  | $ | 705.1 |  |  | $ | 261.3 |  |  | 37.1 | % |  | $ | 705.1 |  |  | $ | 492.5 |  |  | $ | 212.6 |  |  | 43.2 | % |
| Number of employees at period end | 2,108 |  |  | 1,402 |  |  | 706 |  |  | 50.4 | % |  | 1,402 |  |  | 1,219 |  |  | 183 |  |  | 15.0 | % |

[0001327567-21-000029:mdna:76]
Cost of subscription and support revenue increased for fiscal 2021 compared to fiscal 2020 primarily due to increased costs to support the growth of our subscription and support offerings. Personnel costs grew $97.1 million to $412.4 million for fiscal 2021 compared to fiscal 2020 primarily due to headcount growth. Cloud hosting service costs, which support the adoption of our cloud-based subscription offerings increased $45.6 million for fiscal 2021 compared to fiscal 2020. The remaining increase was primarily due to increased outside service costs for global customer support resulting from the expansions of our customer base and product portfolio, as well as the amortization of intangible assets from our recent acquisitions.

[0001327567-21-000029:mdna:77]
Gross Margin

[0001327567-21-000029:mdna:78]
Gross margin, or gross profit as a percentage of revenue, has been and will continue to be affected by a variety of factors, including the introduction of new products, manufacturing costs, tariff costs, the average sales price of our products, cloud hosting service costs, personnel costs, the mix of products sold, and the mix of revenue between product and subscription and support offerings. For sales of our products, our higher-end firewall products generally have higher gross margins than our lower-end firewall products within each product series. We expect our gross margins to vary over time depending on the factors described above.

[0001327567-21-000029:mdna:79]
|  | Year Ended July 31, |
|  | 2021 |  | 2020 |  | 2019 |
|  | Amount |  | GrossMargin |  | Amount |  | GrossMargin |  | Amount |  | GrossMargin |
|  | (dollars in millions) |
| Product | $ | 811.8 |  |  | 72.5 | % |  | $ | 769.8 |  |  | 72.3 | % |  | $ | 780.3 |  |  | 71.2 | % |
| Subscription and support | 2,169.4 |  |  | 69.2 | % |  | 1,639.1 |  |  | 69.9 | % |  | 1,310.9 |  |  | 72.7 | % |
| Total gross profit | $ | 2,981.2 |  |  | 70.0 | % |  | $ | 2,408.9 |  |  | 70.7 | % |  | $ | 2,091.2 |  |  | 72.1 | % |

[0001327567-21-000029:mdna:80]
- 49 -

[0001327567-21-000029:mdna:81]
Product gross margin was relatively flat for fiscal 2021 compared to fiscal 2020.

[0001327567-21-000029:mdna:82]
Subscription and support gross margin decreased for fiscal 2021 compared to fiscal 2020, primarily due to increased costs to fulfill professional services arrangements.

[0001327567-21-000029:mdna:83]
Operating Expenses

[0001327567-21-000029:mdna:84]
Our operating expenses consist of research and development, sales and marketing, and general and administrative expenses. Personnel costs are the most significant component of operating expenses and consist of salaries, benefits, bonuses, share-based compensation, travel and entertainment, and with regard to sales and marketing expense, sales commissions. Our operating expenses also include allocated costs, which consist of certain facilities, depreciation, benefits, recruiting, and information technology costs that we allocate based on headcount. We expect operating expenses generally to increase in absolute dollars and decrease over the long term as a percentage of revenue as we continue to scale our business. In response to COVID-19, we instituted a global work-from-home policy, which has been modified to provide employees with the choice to work in certain of our offices when and as they feel comfortable, and limited employee travel beginning in March 2020. Further, we have canceled in-person events and either replaced them with virtual events or postponed them to future periods. As of July 31, 2021, we expect to recognize approximately $2.0 billion of share-based compensation expense over a weighted-average period of approximately 2.6 years, excluding additional share-based compensation expense related to any future grants of share-based awards. Share-based compensation expense is generally recognized on a straight-line basis over the requisite service periods of the awards.

[0001327567-21-000029:mdna:85]
Research and Development

[0001327567-21-000029:mdna:86]
Research and development expense consists primarily of personnel costs. Research and development expense also includes prototype related expenses and allocated costs. We expect research and development expense to increase in absolute dollars as we continue to invest in our future products and services, although our research and development expense may fluctuate as a percentage of total revenue.

[0001327567-21-000029:mdna:87]
|  | Year Ended July 31, |  |  |  | Year Ended July 31, |  |  |
|  | 2021 |  | 2020 |  | Change |  | 2020 |  | 2019 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Research and development | $ | 1,140.4 |  |  | $ | 768.1 |  |  | $ | 372.3 |  |  | 48.5 | % |  | $ | 768.1 |  |  | $ | 539.5 |  |  | $ | 228.6 |  |  | 42.4 | % |
| Number of employees at period end | 2,595 |  |  | 1,821 |  |  | 774 |  |  | 42.5 | % |  | 1,821 |  |  | 1,507 |  |  | 314 |  |  | 20.8 | % |

[0001327567-21-000029:mdna:88]
Research and development expense increased for fiscal 2021 compared to fiscal 2020 due to an increase in personnel costs, which grew $321.2 million to $911.0 million for fiscal 2021 compared to fiscal 2020. The increase in personnel costs was primarily due to headcount growth.

[0001327567-21-000029:mdna:89]
Sales and Marketing

[0001327567-21-000029:mdna:90]
Sales and marketing expense consists primarily of personnel costs, including commission expense. Sales and marketing expense also includes costs for market development programs, promotional and other marketing costs, professional services, and allocated costs. We continue to thoughtfully invest in headcount and have substantially grown our international sales presence. We expect sales and marketing expense to continue to increase in absolute dollars as we increase the size of our sales and marketing organizations to increase touch points with end-customers and to expand our global presence, although our sales and marketing expense may fluctuate as a percentage of total revenue.

[0001327567-21-000029:mdna:91]
|  | Year Ended July 31, |  |  |  | Year Ended July 31, |  |  |
|  | 2021 |  | 2020 |  | Change |  | 2020 |  | 2019 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Sales and marketing | $ | 1,753.8 |  |  | $ | 1,520.2 |  |  | $ | 233.6 |  |  | 15.4 | % |  | $ | 1,520.2 |  |  | $ | 1,344.0 |  |  | $ | 176.2 |  |  | 13.1 | % |
| Number of employees at period end | 4,493 |  |  | 3,800 |  |  | 693 |  |  | 18.2 | % |  | 3,800 |  |  | 3,382 |  |  | 418 |  |  | 12.4 | % |

[0001327567-21-000029:mdna:92]
Sales and marketing expense increased for fiscal 2021 compared to fiscal 2020 primarily due to an increase in personnel costs, which grew $186.9 million to $1.3 billion for fiscal 2021 compared to fiscal 2020. The increase in personnel costs was largely due to headcount growth, partially offset by decreased travel expenses due to COVID-19. In addition, expenses increased as a result of go-to-market initiatives, including advertising, which were partially offset by a decrease in trade shows and convention expenses as in-person events were replaced with virtual events due to COVID-19.

[0001327567-21-000029:mdna:93]
General and Administrative

[0001327567-21-000029:mdna:94]
General and administrative expense consists primarily of personnel costs for our executive, finance, human resources, legal, and information technology organizations, and professional services costs, which consist primarily of legal, auditing, accounting, and other

[0001327567-21-000029:mdna:95]
- 50 -

[0001327567-21-000029:mdna:96]
consulting costs. General and administrative expense also includes certain non-recurring general expenses and impairment losses. Certain facilities, depreciation, benefits, recruiting, and information technology costs are allocated to other organizations based on headcount. We expect general and administrative expense to increase in absolute dollars due to additional costs associated with accounting, compliance, and insurance, although our general and administrative expense may fluctuate as a percentage of total revenue.

[0001327567-21-000029:mdna:97]
|  | Year Ended July 31, |  |  |  | Year Ended July 31, |  |  |
|  | 2021 |  | 2020 |  | Change |  | 2020 |  | 2019 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| General and administrative | $ | 391.1 |  |  | $ | 299.6 |  |  | $ | 91.5 |  |  | 30.5 | % |  | $ | 299.6 |  |  | $ | 261.8 |  |  | $ | 37.8 |  |  | 14.4 | % |
| Number of employees at period end | 1,150 |  |  | 874 |  |  | 276 |  |  | 31.6 | % |  | 874 |  |  | 804 |  |  | 70 |  |  | 8.7 | % |

[0001327567-21-000029:mdna:98]
General and administrative expenses increased for fiscal 2021 compared to fiscal 2020 primarily due to personnel costs, which grew $48.9 million to $244.0 million for fiscal 2021 compared to fiscal 2020, due primarily to an increase in share-based compensation expense related to accelerated vesting of certain equity awards in connection with our acquisitions and headcount growth. Other increases included increased professional services expense to support our business growth.

[0001327567-21-000029:mdna:99]
Interest Expense

[0001327567-21-000029:mdna:100]
Interest expense primarily consists of non-cash interest expense from the amortization of the debt discount and debt issuance costs related to our 0.0% Convertible Senior Notes due 2019 (the “2019 Notes”), the 0.75% Convertible Senior Notes due 2023 (the “2023 Notes”) and the 0.375% Convertible Senior Notes due 2025 (the “2025 Notes”, and together with “2023 Notes”, the “Notes”), and also includes the contractual interest expense related to our Notes.

[0001327567-21-000029:mdna:101]
|  | Year Ended July 31, |  |  |  | Year Ended July 31, |  |  |
|  | 2021 |  | 2020 |  | Change |  | 2020 |  | 2019 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Interest expense | $ | 163.3 |  |  | $ | 88.7 |  |  | $ | 74.6 |  |  | 84.1 | % |  | $ | 88.7 |  |  | $ | 83.9 |  |  | $ | 4.8 |  |  | 5.7 | % |

[0001327567-21-000029:mdna:102]
Interest expense increased for fiscal 2021 compared to fiscal 2020 due to the issuance of our 2025 Notes in the fourth quarter of fiscal 2020. Refer to Note 10. Debt in Part II, Item 8 of this Annual Report on Form 10-K for more information on our series of convertible senior notes.

[0001327567-21-000029:mdna:103]
Other Income, Net

[0001327567-21-000029:mdna:104]
Other income, net includes interest income earned on our cash, cash equivalents, and investments, foreign currency remeasurement gains and losses, and foreign currency transaction gains and losses.

[0001327567-21-000029:mdna:105]
|  | Year Ended July 31, |  |  |  | Year Ended July 31, |  |  |
|  | 2021 |  | 2020 |  | Change |  | 2020 |  | 2019 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Other income, net | $ | 2.4 |  |  | $ | 35.9 |  |  | $ | (33.5) |  |  | (93.3) | % |  | $ | 35.9 |  |  | $ | 63.4 |  |  | $ | (27.5) |  |  | (43.4) | % |

[0001327567-21-000029:mdna:106]
Other income, net decreased for fiscal 2021 compared to fiscal 2020 primarily due to lower interest income earned on our cash, cash equivalent, and investment balances as a result of lower interest rates for fiscal 2021 compared to fiscal 2020.

[0001327567-21-000029:mdna:107]
Provision for Income Taxes

[0001327567-21-000029:mdna:108]
Provision for income taxes consists primarily of income taxes in foreign jurisdictions in which we conduct business and withholding taxes. We maintain a full valuation allowance for domestic and certain foreign deferred tax assets, including net operating loss carryforwards and certain domestic tax credits. In recent years, we reorganized our corporate structure and intercompany relationships to more closely align with the international nature of our business activities. Our corporate structure has caused, and may continue to cause, disproportionate relationships between our overall effective tax rate and other jurisdictional measures. To the extent

[0001327567-21-000029:mdna:109]
- 51 -

[0001327567-21-000029:mdna:110]
we revisit our corporate structure, it may have an impact on our tax provision.

[0001327567-21-000029:mdna:111]
|  | Year Ended July 31, |  |  |  |  |  | Year Ended July 31, |  |  |  |  |
|  | 2021 |  | 2020 |  | Change |  | 2020 |  | 2019 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Provision for income taxes | $ | 33.9 |  |  | $ | 35.2 |  |  | $ | (1.3) |  |  | (3.7) | % |  | $ | 35.2 |  |  | $ | 7.3 |  |  | $ | 27.9 |  |  | 382.2 | % |
| Effective tax rate | (7.3) | % |  | (15.2) | % |  |  |  |  |  | (15.2) | % |  | (9.8) | % |  |  |  |  |

[0001327567-21-000029:mdna:112]
We recorded an income tax provision for fiscal 2021. The provision for income taxes for fiscal 2021 was primarily due to income taxes in profitable foreign jurisdictions and withholding taxes. Our provision for income taxes slightly decreased for fiscal 2021 compared to fiscal 2020, primarily due to changes in our valuation allowances. Refer to Note 15. Income Taxes in Part II, Item 8 of this Annual Report on Form 10-K for more information.

[0001327567-21-000029:mdna:113]
- 52 -

[0001327567-21-000029:mdna:114]
Liquidity and Capital Resources

[0001327567-21-000029:mdna:115]
|  | July 31, |
|  | 2021 |  | 2020 |
|  | (in millions) |
| Working capital | $ | (469.4) |  |  | $ | 2,437.5 |  |
| Cash, cash equivalents, and investments: |  |  |  |
| Cash and cash equivalents | $ | 1,874.2 |  |  | $ | 2,958.0 |  |
| Investments | 1,915.2 |  |  | 1,344.2 |  |
| Total cash, cash equivalents, and investments | $ | 3,789.4 |  |  | $ | 4,302.2 |  |

[0001327567-21-000029:mdna:116]
As of July 31, 2021, our total cash, cash equivalents, and investments of $3.8 billion were held for general corporate purposes, of which approximately $942.3 million was held outside of the United States. As of July 31, 2021, we had no unremitted earnings when evaluating our outside basis difference relating to our U.S. investment in foreign subsidiaries. However, there could be local withholding taxes payable due to various foreign countries if certain lower tier earnings are distributed. Withholding taxes that would be payable upon remittance of these lower tier earnings are not expected to be material.

[0001327567-21-000029:mdna:117]
In June 2014, we issued the 2019 Notes with an aggregate principal amount of $575.0 million. The 2019 Notes were converted prior to or settled on the maturity date of July 1, 2019. During fiscal 2019, we repaid in cash $575.0 million in aggregate principal amount of the 2019 Notes and issued 2.5 million shares of common stock to the holders for the conversion value in excess of the principal amount of the 2019 Notes converted, which were fully offset by shares received from our exercise of the associated note hedges. In July 2018, we issued the 2023 Notes with an aggregate principal amount of $1.7 billion. In June 2020, we issued the 2025 Notes with an aggregate principal amount of $2.0 billion. The 2023 Notes mature on July 1, 2023 and the 2025 Notes mature on June 1, 2025; however, under certain circumstances, holders may surrender their Notes of a series for conversion prior to the applicable maturity date. Upon conversion of the Notes of a series, we will pay cash equal to the aggregate principal amount of the Notes of such series to be converted, and, at our election, will pay or deliver cash and/or shares of our common stock for the amount of our conversion obligation in excess of the aggregate principal amount of the Notes of such series being converted. The sale price condition was met for the 2023 Notes during the fiscal quarter ended July 31, 2021, and as a result, holders may convert their 2023 Notes at any time during the fiscal quarter ending October 31, 2021. We believe that our cash provided by operating activities, together with our existing cash, cash equivalents and investments will be sufficient to meet our anticipated cash needs should the holders choose to convert their 2023 Notes during the fiscal quarter ending October 31, 2021. As of July 31, 2021, substantially all of our 2023 Notes and 2025 Notes remained outstanding. Refer to Note 10. Debt in Part II, Item 8 of this Annual Report on Form 10-K for more information on the Notes.

[0001327567-21-000029:mdna:118]
In September 2018, we entered into a credit agreement (the “Credit Agreement”) that provides for a $400.0 million unsecured revolving credit facility (the “Credit Facility”), with an option to increase the amount of the credit facility by up to an additional $350.0 million, subject to certain conditions. As of July 31, 2021, there were no amounts outstanding, and we were in compliance with all covenants under the Credit Agreement. Refer to Note 10. Debt in Part II, Item 8 of this Annual Report on Form 10-K for more information on the Credit Agreement.

[0001327567-21-000029:mdna:119]
In February 2019, our board of directors authorized a $1.0 billion share repurchase program, and, in December 2020, our board of directors authorized a $700.0 million increase to our share repurchase program, bringing the total authorization to $1.7 billion (our “current authorization”). As of July 31, 2021, $323.9 million remained available for future share repurchases under this current authorization. On August 17, 2021, our board of directors authorized another $676.1 million increase to our current authorization, bringing the total remaining authorization for future share repurchases to $1.0 billion. Repurchases will be funded from available working capital and may be made at management’s discretion from time to time. The expiration date of our current authorization was extended to December 31, 2022, and this program may be suspended or discontinued at any time. In February 2020, our board of directors approved the repurchase of $1.0 billion of our common stock through an accelerated share repurchase (“ASR”) transaction, which was in addition to our current authorization. During fiscal 2020, we completed the ASR transaction with an aggregate of 5.2 million shares of our common stock repurchased and retired. Refer to Note 13. Stockholders’ Equity in Part II, Item 8 of this Annual Report on Form 10-K for information on these repurchase programs.

[0001327567-21-000029:mdna:120]
- 53 -

[0001327567-21-000029:mdna:121]
The following table summarizes our cash flows for the years ended July 31, 2021, 2020, and 2019:

[0001327567-21-000029:mdna:122]
|  | Year Ended July 31, |
| 2021 |  | 2020 |  | 2019 |
|  | (in millions) |
| Net cash provided by operating activities | $ | 1,503.0 |  |  | $ | 1,035.7 |  |  | $ | 1,055.6 |  |
| Net cash provided by (used in) investing activities | (1,480.6) |  |  | 288.0 |  |  | (1,825.9) |  |
| Net cash provided by (used in) financing activities | (1,104.0) |  |  | 673.0 |  |  | (773.9) |  |
| Net increase (decrease) in cash, cash equivalents, and restricted cash | $ | (1,081.6) |  |  | $ | 1,996.7 |  |  | $ | (1,544.2) |  |

[0001327567-21-000029:mdna:123]
Cash from operations could be affected by various risks and uncertainties, including, but not limited to, the effects of COVID-19 and other risks detailed in Part I, Item 1A “Risk Factors” in this Form 10-K. We believe that our cash flow from operations with existing cash and cash equivalents will be sufficient to meet our anticipated cash needs for at least the next 12 months and thereafter for the foreseeable future. Our future capital requirements will depend on many factors including our growth rate, the timing and extent of spending to support development efforts, the expansion of sales and marketing activities, the introduction of new and enhanced products and subscription and support offerings, the costs to acquire or invest in complementary businesses and technologies, the costs to ensure access to adequate manufacturing capacity, the investments in our infrastructure to support the adoption of our cloud-based subscription offerings, the investments in our new corporate headquarters, the continuing market acceptance of our products and subscription and support offerings and macroeconomic events such as COVID-19. In addition, from time to time we may incur additional tax liability in connection with certain corporate structuring decisions.

[0001327567-21-000029:mdna:124]
We may also choose to seek additional equity or debt financing. In the event that additional financing is required from outside sources, we may not be able to raise it on terms acceptable to us or at all. If we are unable to raise additional capital when desired, our business, operating results, and financial condition may be adversely affected.

[0001327567-21-000029:mdna:125]
Operating Activities

[0001327567-21-000029:mdna:126]
Our operating activities have consisted of net losses adjusted for certain non-cash items and changes in assets and liabilities.

[0001327567-21-000029:mdna:127]
Cash provided by operating activities during fiscal 2021 was $1.5 billion, an increase of $467.3 million compared to fiscal 2020. The increase was primarily due to growth of our business as reflected by an increase in billings, and an increase in collections during fiscal 2021, partially offset by higher cash expenditure to support our business growth.

[0001327567-21-000029:mdna:128]
Investing Activities

[0001327567-21-000029:mdna:129]
Our investing activities have consisted of capital expenditures, net investment purchases, sales, and maturities, and business acquisitions. We expect to continue such activities as our business grows.

[0001327567-21-000029:mdna:130]
Cash used in investing activities during fiscal 2021 was $1.5 billion, a net change of $1.8 billion compared to cash provided by investing activities of $288.0 million in fiscal 2020. The change was primarily due to a decrease in proceeds from maturities and sales of investments and higher purchases of investments during fiscal 2021.

[0001327567-21-000029:mdna:131]
Financing Activities

[0001327567-21-000029:mdna:132]
Our financing activities have consisted of proceeds from sales of shares through employee equity incentive plans, cash used to repurchase shares of our common stock, and payments for tax withholding obligations of certain employees related to the net share settlement of equity awards.

[0001327567-21-000029:mdna:133]
Cash used in financing activities during fiscal 2021 was $1.1 billion, a net change of $1.8 billion compared to cash provided by financing activities of 673.0 million in fiscal 2020. The change was primarily due to net proceeds of $1.8 billion from the issuance of our 2025 Notes, issuance of warrants, and purchase of note hedges during fiscal 2020.

[0001327567-21-000029:mdna:134]
- 54 -

[0001327567-21-000029:mdna:135]
Contractual Obligations and Commitments

[0001327567-21-000029:mdna:136]
The following summarizes our contractual obligations and commitments as of July 31, 2021:

[0001327567-21-000029:mdna:137]
|  | Payments Due by Period |
|  | Total |  | Less Than 1 Year |  | 1-3 Years |  | 3-5 Years |  | More Than 5 Years |
|  |  |  | (in millions) |  |  |
| 0.75% Convertible Senior Notes due 2023 | $ | 1,692.0 |  |  | $ | — |  |  | $ | 1,692.0 |  |  | $ | — |  |  | $ | — |  |
| 0.375% Convertible Senior Notes due 2025 | 2,000.0 |  |  | — |  |  | — |  |  | 2,000.0 |  |  | — |  |
| Operating lease obligations | 426.6 |  |  | 78.8 |  |  | 134.2 |  |  | 116.1 |  |  | 97.5 |  |
| Purchase obligations(1) | 1,831.7 |  |  | 251.3 |  |  | 609.0 |  | 971.4 |  | — |
| Total(2) | $ | 5,950.3 |  |  | $ | 330.1 |  |  | $ | 2,435.2 |  |  | $ | 3,087.5 |  |  | $ | 97.5 |  |

[0001327567-21-000029:mdna:138]
______________

[0001327567-21-000029:mdna:139]
(1)    Consists of minimum purchase commitments of products and components with our manufacturing partners and component suppliers, as well as minimum or fixed purchase commitments for our use of certain cloud and other services with third-party providers. Obligations under contracts that we can cancel without a significant penalty are not included in the table above.

[0001327567-21-000029:mdna:140]
(2)    No amounts related to income taxes are included. As of July 31, 2021, we had approximately $80.6 million of tax liabilities recorded related to uncertainty in income tax positions.

[0001327567-21-000029:mdna:141]
Off-Balance Sheet Arrangements

[0001327567-21-000029:mdna:142]
As of July 31, 2021, we did not have any relationships with unconsolidated organizations or financial partnerships, such as structured finance or special purpose entities that would have been established for the purpose of facilitating off-balance sheet arrangements or other contractually narrow or limited purposes.

[0001327567-21-000029:mdna:143]
Critical Accounting Estimates

[0001327567-21-000029:mdna:144]
Our consolidated financial statements have been prepared in accordance with GAAP. The preparation of these consolidated financial statements requires us to make estimates and assumptions that affect the reported amounts of assets, liabilities, revenue, expenses, and related disclosures. We base our estimates on historical experience and on various other assumptions that we believe are reasonable under the circumstances. We evaluate our estimates and assumptions on an ongoing basis. Actual results could differ materially from those estimates due to risks and uncertainties, including uncertainty in the current economic environment due to the global impact of COVID-19. To the extent that there are material differences between these estimates and our actual results, our future financial statements will be affected.

[0001327567-21-000029:mdna:145]
We believe that of our significant accounting policies described in Note 1. Description of Business and Summary of Significant Accounting Policies in Part II, Item 8 of this Annual Report on Form 10-K, the critical accounting policies requiring estimates, assumptions, and judgments that have the most significant impact on our consolidated financial statements are described below.

[0001327567-21-000029:mdna:146]
Revenue Recognition

[0001327567-21-000029:mdna:147]
The majority of our contracts with our customers include various combinations of our products and subscriptions and support. Our appliances and software licenses have significant standalone functionalities and capabilities and, accordingly, are distinct from our subscriptions and support services, as the customer can benefit from the product without these services and such services are separately identifiable within the contract. We account for multiple agreements with a single customer as a single contract if the contractual terms and/or substance of those agreements indicate that they may be so closely related that they are, in effect, parts of a single contract. The amount we are due in exchange for delivering on the contract is allocated to each performance obligation based on its relative standalone selling price.

[0001327567-21-000029:mdna:148]
We establish standalone selling price using the prices charged for a deliverable when sold separately. If not observable through past transactions, we estimate the standalone selling price based on our pricing model and our go-to-market strategy, which include factors such as type of sales channel (reseller, distributor, or end-customer), the geographies in which our offerings were sold (domestic or international) and offering type (products, subscriptions, or support). As our business offerings evolve over time, we may be required to modify our estimated standalone selling prices, and as a result the timing and classification of our revenue could be affected.

[0001327567-21-000029:mdna:149]
Deferred Contract Costs

[0001327567-21-000029:mdna:150]
We defer contract costs that are recoverable and incremental to obtaining customer sales contracts. Contract costs, which primarily consist of sales commissions, are amortized on a systematic basis that is consistent with the transfer to the customer of the goods or services to which the asset relates. Sales commissions for initial contracts that are not commensurate with renewal

[0001327567-21-000029:mdna:151]
- 55 -

[0001327567-21-000029:mdna:152]
commissions are amortized over a benefit period of five years, consistent with the revenue recognition pattern of the performance obligations in the related contracts including expected renewals. The benefit period is determined by taking into consideration contract length, technology life, and other quantitative and qualitative factors. The expected renewals are estimated based on historical renewal trends. Sales commissions for initial contracts that are commensurate and sales commissions for renewal contracts are amortized over the related contractual period in proportion to the revenue recognized.

[0001327567-21-000029:mdna:153]
Income Taxes

[0001327567-21-000029:mdna:154]
We account for income taxes using the asset and liability method, which requires the recognition of deferred tax assets and liabilities for the expected future tax consequences of events that have been recognized in our financial statements or tax returns. In addition, deferred tax assets are recorded for the future benefit of utilizing net operating losses and research and development credit carryforwards. Valuation allowances are provided when necessary to reduce deferred tax assets to the amount expected to be realized.

[0001327567-21-000029:mdna:155]
Significant judgment is required in determining any valuation allowance recorded against deferred tax assets. In assessing the need for a valuation allowance, we consider all available evidence, including past operating results, estimates of future taxable income, and the feasibility of tax planning strategies. In the event that we change our determination as to the amount of deferred tax assets that can be realized, we will adjust our valuation allowance with a corresponding impact to the provision for income taxes in the period in which such determination is made.

[0001327567-21-000029:mdna:156]
We apply the authoritative accounting guidance prescribing a threshold and measurement attribute for the financial recognition and measurement of a tax position taken or expected to be taken in a tax return. We recognize liabilities for uncertain tax positions based on a two-step process. The first step is to evaluate the tax position for recognition by determining if the weight of available evidence indicates that it is more likely than not that the position will be sustained on audit, including resolution of related appeals or litigation processes, if any. The second step requires us to estimate and measure the tax benefit as the largest amount that is more likely than not to be realized upon ultimate settlement.

[0001327567-21-000029:mdna:157]
Significant judgment is also required in evaluating our uncertain tax positions and determining our provision for income taxes. Although we believe our reserves are reasonable, no assurance can be given that the final tax outcome of these matters will not be different from that which is reflected in our historical income tax provisions and accruals. We adjust these reserves in light of changing facts and circumstances, such as the closing of a tax audit or the refinement of an estimate. To the extent that the final tax outcome of these matters is different than the amounts recorded, such differences may impact the provision for income taxes in the period in which such determination is made.

[0001327567-21-000029:mdna:158]
Manufacturing Partner and Supplier Liabilities

[0001327567-21-000029:mdna:159]
We outsource most of our manufacturing, repair, and supply chain management operations to our EMS provider, which procures components and assembles our products based on our demand forecasts. These forecasts of future demand are based upon historical trends and analysis from our sales and product management functions as adjusted for overall market conditions. We accrue for costs for manufacturing purchase commitments in excess of our forecasted demand, including costs for excess components or for carrying costs incurred by our manufacturing partners and component suppliers. Actual component usage and product demand may be materially different from our forecast and could be caused by factors outside of our control, which could have an adverse impact on our results of operations. To date, we have not accrued significant costs associated with this exposure.

[0001327567-21-000029:mdna:160]
Loss Contingencies

[0001327567-21-000029:mdna:161]
We are subject to the possibility of various loss contingencies arising in the ordinary course of business. We accrue for loss contingencies when it is probable that an asset has been impaired or a liability has been incurred and the amount of loss can be reasonably estimated. If we determine that a loss is possible and the range of the loss can be reasonably determined, then we disclose the range of the possible loss. We regularly evaluate current information available to us to determine whether an accrual is required, an accrual should be adjusted, or a range of possible loss should be disclosed.

[0001327567-21-000029:mdna:162]
From time to time, we are involved in disputes, litigation, and other legal actions. However, there are many uncertainties associated with any litigation, and these actions or other third-party claims against us may cause us to incur substantial settlement charges, which are inherently difficult to estimate and could adversely affect our results of operations. The actual liability in any such matters may be materially different from our estimates, which could result in the need to adjust our liability and record additional expenses.

[0001327567-21-000029:mdna:163]
Goodwill, Intangibles, and Other Long-Lived Assets

[0001327567-21-000029:mdna:164]
We make significant estimates, assumptions, and judgments when valuing goodwill and other purchased intangible assets in connection with the initial purchase price allocation of an acquired entity, as well as when evaluating impairment of goodwill and other purchased intangible assets on an ongoing basis. These estimates are based upon a number of factors, including historical experience, market conditions, and information obtained from the management of the acquired company. Critical estimates in valuing certain intangible assets include, but are not limited to, cash flows that an asset is expected to generate in the future, discount rates, the time and expense that would be necessary to recreate the assets, and the profit margin a market participant would receive. The amounts and useful lives assigned to identified intangible assets impacts the amount and timing of future amortization expense.

[0001327567-21-000029:mdna:165]
- 56 -

[0001327567-21-000029:mdna:166]
We evaluate goodwill for impairment on an annual basis in our fourth fiscal quarter or more frequently if we believe impairment indicators exist. We have elected to first assess qualitative factors to determine whether it is more likely than not that the fair value of our reporting unit is less than its carrying amount, including goodwill. The qualitative assessment includes our evaluation of relevant events and circumstances affecting our single reporting unit, including macroeconomic, industry, and market conditions, our overall financial performance, and trends in the market price of our common stock. If qualitative factors indicate that it is more likely than not that our reporting unit’s fair value is less than its carrying amount, then we will perform the quantitative impairment test by comparing our reporting unit’s carrying amount, including goodwill, to its fair value. If the carrying amount of our reporting unit exceeds its fair value, an impairment loss will be recognized in an amount equal to that excess. To date, the results of our qualitative assessment have indicated that the quantitative goodwill impairment test is not necessary.

[0001327567-21-000029:mdna:167]
We evaluate long-lived assets, such as property, equipment, and purchased intangible assets for impairment whenever events or changes in circumstances indicate that the carrying amount of the assets may not be recoverable. Such events or changes in circumstances include, but are not limited to, a significant decrease in the fair value of the underlying asset or asset group, a significant decrease in the benefits realized from the acquired assets, difficulty and delays in integrating the business, or a significant change in the operations of the acquired assets or use of an asset or asset group. A long-lived asset is considered impaired if its carrying amount exceeds the estimated future undiscounted cash flows the asset or asset group is expected to generate. Critical estimates in determining whether a long-lived asset is considered impaired include the amount and timing of future cash flows that the asset or asset group is expected to generate. If a long-lived asset is considered to be impaired, the impairment to be recognized is the amount by which the carrying amount of the asset exceeds the fair value of the asset or asset group, which is estimated using a present value technique. Critical estimates in determining the fair value of an asset or asset group and the amount of impairment to recognize include, but are not limited to, the amount and timing of future cash flows that the asset or asset group is expected to generate and the discount rate. Determining the fair value of an asset or asset group is highly judgmental in nature and involves the use of significant estimates and assumptions for market participants. We base our fair value estimates on assumptions we believe to be reasonable but that are unpredictable and inherently uncertain. Actual future results may differ from those estimates.

[0001327567-21-000029:mdna:168]
Convertible Senior Notes

[0001327567-21-000029:mdna:169]
In accounting for the issuance of our convertible senior notes, we separate the notes into liability and equity components. The carrying amount of the liability component is calculated by measuring the fair value of a similar liability that does not have an associated convertible feature, using a discounted cash flow model with a risk adjusted yield. The carrying amount of the equity component representing the conversion option is determined by deducting the fair value of the liability component from the par value of the notes as a whole. This difference represents a debt discount that is amortized to interest expense using the effective interest method over the term of the notes. The equity component is not remeasured as long as it continues to meet the conditions for equity classification. In accounting for the transaction costs related to the issuance of the notes, we allocate the total amount incurred to the liability and equity components using the same proportions as the proceeds from the notes. Transaction costs attributable to the liability component are netted with the liability component and amortized to interest expense using the effective interest method over the term of the notes. Transaction costs attributable to the equity component are netted with the equity component of the notes in additional paid-in capital in the consolidated balance sheets.

[0001327567-21-000029:mdna:170]
Recent Accounting Pronouncements

[0001327567-21-000029:mdna:171]
Refer to “Recently Issued Accounting Pronouncements” in Note 1. Description of Business and Summary of Significant Accounting Policies in Part II, Item 8 of this Annual Report on Form 10-K for a description of recent accounting pronouncements and our expectation of their impact, if any, on our results of operations and financial condition.
