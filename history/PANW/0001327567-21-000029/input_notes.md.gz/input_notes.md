# PANW notes — 0001327567-21-000029


## dei:DocumentsIncorporatedByReferenceTextBlock

[0001327567-21-000029:notes:1]
Portions of the information called for by Part III of this Annual Report on Form 10-K is hereby incorporated by reference from the definitive proxy statement for the registrant’s 2021 annual meeting of stockholders, which will be filed with the Securities and Exchange Commission not later than 120 days after the registrant’s fiscal year ended July 31, 2021.


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock

[0001327567-21-000029:notes:2]
Description of Business and Summary of Significant Accounting Policies 
Description of Business

[0001327567-21-000029:notes:3]
Palo Alto Networks, Inc. (the “Company,” “we,” “us,” or “our”), headquartered in Santa Clara, California, was incorporated in March 2005 under the laws of the State of Delaware and commenced operations in April 2005. We empower enterprises, service providers, and government entities to secure all users, applications, data, networks, clouds and devices with comprehensive visibility and context, continuously, across all locations.

[0001327567-21-000029:notes:4]
Basis of Presentation

[0001327567-21-000029:notes:5]
The accompanying consolidated financial statements have been prepared in conformity with U.S. generally accepted accounting principles (“GAAP”). The consolidated financial statements include all adjustments necessary for a fair presentation of our annual results. All adjustments are of a normal recurring nature.

[0001327567-21-000029:notes:6]
Principles of Consolidation

[0001327567-21-000029:notes:7]
The consolidated financial statements include our accounts and our wholly owned subsidiaries. All significant intercompany balances and transactions have been eliminated in consolidation.

[0001327567-21-000029:notes:8]
Use of Estimates

[0001327567-21-000029:notes:9]
The preparation of consolidated financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the consolidated financial statements and the reported amounts of revenues and expenses during the reporting period. Such management estimates include, but are not limited to, the standalone selling price for our products and services, share-based compensation, fair value of assets acquired and liabilities assumed in business combinations, identified intangibles and goodwill, valuation allowance against deferred tax assets, manufacturing partner and supplier liabilities, fair value of debt component of convertible notes, interest rate for operating lease liabilities, deferred contract cost benefit period, and loss contingencies. We base our estimates on historical experience and also on assumptions that we believe are reasonable. Actual results could differ materially from those estimates due to risks and uncertainties, including uncertainty in the current economic environment due to the global impact of COVID-19.

[0001327567-21-000029:notes:10]
Concentrations

[0001327567-21-000029:notes:11]
Financial instruments that subject us to concentrations of credit risk consist primarily of cash and cash equivalents, investments, derivative contracts, accounts receivable and financing receivables.

[0001327567-21-000029:notes:12]
We invest only in high-quality credit instruments and maintain our cash and cash equivalents and available-for-sale investments in fixed income securities. Management believes that the financial institutions that hold our investments are financially sound and, accordingly, are subject to minimal credit risk. Deposits held with banks may exceed the amount of insurance provided on such deposits.

[0001327567-21-000029:notes:13]
Our derivative contracts expose us to credit risk to the extent that the counterparties may be unable to meet the terms of the arrangement. We mitigate this credit risk by transacting with major financial institutions with high credit ratings and also enter into master netting arrangements, which permit net settlement of transactions with the same counterparty. We are not required to pledge, and are not entitled to receive, cash collateral related to these derivative instruments. We do not enter into derivative contracts for trading or speculative purposes.

[0001327567-21-000029:notes:14]
Our accounts receivable are primarily derived from our distributors in various geographical locations. Our financing receivables are with certain qualified end-customers. We perform ongoing credit evaluations and generally do not require collateral on accounts receivable or financing receivables.

[0001327567-21-000029:notes:15]
As of July 31, 2021, four distributors individually represented 10% or more of our gross accounts receivable, and in the aggregate represented 56.6% of our gross accounts receivable. As of July 31, 2021, four end-customers represented 10% or more of our gross financing receivables, and in aggregate represented 67.0% of our gross financing receivables.

[0001327567-21-000029:notes:16]
For fiscal 2021, three distributors represented 10% or more of our total revenue, representing 33.2%, 12.2%, and 10.6%, respectively. No single end-customer accounted for more than 10% of our total revenue in fiscal 2021, 2020, or 2019.

[0001327567-21-000029:notes:17]
We rely on an electronics manufacturing services provider (“EMS provider”) to assemble most of our products and sole source component suppliers for a certain number of our components.

[0001327567-21-000029:notes:18]
Comprehensive Loss

[0001327567-21-000029:notes:19]
Comprehensive loss is comprised of net loss and other comprehensive income (loss). Our other comprehensive income (loss) includes unrealized gains and losses on available-for-sale investments and unrealized gains and losses on cash flow hedges.

[0001327567-21-000029:notes:20]
Foreign Currency Transactions

[0001327567-21-000029:notes:21]
The functional currency of our foreign subsidiaries is the U.S. dollar. Monetary assets and liabilities denominated in foreign currencies have been remeasured into U.S. dollars using the exchange rates in effect at the balance sheet dates. Foreign currency remeasurement gains and losses and foreign currency transaction gains and losses are not significant to the financial statements.

[0001327567-21-000029:notes:22]
Fair Value

[0001327567-21-000029:notes:23]
We define fair value as the price that would be received from selling an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date. When determining the fair value measurements for assets and liabilities which are required to be recorded at fair value, we consider the principal or most advantageous market in which to transact and the market-based risk. We apply fair value accounting for all financial assets and liabilities that are recognized or disclosed at fair value in the financial statements on a recurring basis. Goodwill, intangible assets, and other long-lived assets are measured at fair value on a nonrecurring basis, only if impairment is indicated. The carrying amounts reported in the consolidated financial statements approximate the fair value for cash and cash equivalents, accounts receivable, accounts payable, and accrued liabilities, due to their short-term nature.

[0001327567-21-000029:notes:24]
Cash, Cash Equivalents, and Investments

[0001327567-21-000029:notes:25]
We consider all highly liquid investments with original maturities of three months or less at the date of purchase to be cash equivalents. Investments not considered cash equivalents, and with maturities of one year or less from the consolidated balance sheet date, are classified as short-term investments. Investments with maturities greater than one year from the consolidated balance sheet date are classified as long-term investments.

[0001327567-21-000029:notes:26]
We classify our investments in marketable debt securities as available-for-sale at the time of purchase. When the fair value of a security is below its amortized cost, the amortized cost will be reduced to its fair value if it is more likely than not that we are required to sell the impaired security before recovery of its amortized cost basis, or we have the intention to sell the security. If neither of these conditions are met, we determine whether the impairment is due to credit losses by comparing the present value of the expected cash flows of the security with its amortized cost basis. The amount of impairment recognized is limited to the excess of the amortized cost over the fair value of the security. An allowance for credit losses for the excess of amortized cost over the expected cash flows is recorded in other income, net in our consolidated statements of operations. Impairment losses that are not credit-related are included in accumulated other comprehensive income (loss) (“AOCI”) in stockholders’ equity.

[0001327567-21-000029:notes:27]
Accounts Receivable

[0001327567-21-000029:notes:28]
Trade accounts receivable are recorded at the invoiced amount, net of allowances for credit losses for any potential uncollectible amounts. The allowance for credit losses is based on our assessment of the collectability of accounts. Management regularly reviews the adequacy of the allowance for credit losses on a collective basis by considering the age of each outstanding invoice, each customer’s expected ability to pay and collection history, current market conditions, and reasonable and supportable forecasts of future economic conditions to determine whether the allowance is appropriate. Accounts receivable deemed uncollectible are charged against the allowance for credit losses when identified. For the years ended July 31, 2021 and 2020, the allowance for credit losses activity was not significant.

[0001327567-21-000029:notes:29]
Financing Receivables

[0001327567-21-000029:notes:30]
We provide financing arrangements, primarily loans, for certain qualified end-user customers to purchase our products and services. Payment terms on these financing arrangements are up to five years. We evaluate our allowance for credit losses by assessing the risks and losses inherent in our financing receivables on either an individual or a collective basis. Our assessment considers various factors, including lifetime expected losses determined using customer risk profile, current economic conditions that may affect a customer’s ability to pay, and forward-looking economic considerations. Financing receivables are written off when they are considered uncollectible, and related outstanding balances are reversed and charged against the allowance for credit losses. Short-term financing receivables are included in prepaid expenses and other current assets, and long-term financing receivables are included in other assets on our consolidated balance sheets. For the years ended July 31, 2021 and 2020, the allowance for credit losses activity was not significant. Refer to Note 5. Financing Receivables for additional information.

[0001327567-21-000029:notes:31]
Derivatives

[0001327567-21-000029:notes:32]
As a global business, we are exposed to currency exchange rate risk. Substantially all of our revenue is transacted in U.S. dollars, however, a portion of our operating expenditures are incurred outside of the United States and are denominated in foreign currencies, making them subject to fluctuations in foreign currency exchange rates. We enter into foreign currency derivative contracts with maturities of 16 months or less, which we designate as cash flow hedges, to manage the foreign currency exchange rate risk associated with these expenditures.

[0001327567-21-000029:notes:33]
Our derivative financial instruments are recorded at fair value, on a gross basis, as either assets or liabilities in our consolidated balance sheets. Gains or losses related to our cash flow hedges are recorded as a component of AOCI in our consolidated balance sheets and are reclassified into the financial statement line item associated with the underlying hedged transaction in our consolidated

[0001327567-21-000029:notes:34]
statements of operations when the underlying hedged transaction is recognized in earnings. If it becomes probable that the hedged transaction will not occur, the cumulative unrealized gain or loss is reclassified immediately from AOCI into the financial statement line item associated with the underlying hedged transaction in our consolidated statements of operations. Gains or losses related to non-designated derivative instruments are recognized in other income, net in our consolidated statements of operations for each period until the instrument matures, is terminated, is re-designated as a qualified cash flow hedge, or is sold. Derivatives designated as cash flow hedges are classified in our consolidated statements of cash flows in the same manner as the underlying hedged transaction, primarily within cash flows from operating activities.

[0001327567-21-000029:notes:35]
Property and Equipment

[0001327567-21-000029:notes:36]
Property and equipment are stated at cost, less accumulated depreciation. Depreciation is computed using the straight-line method over the estimated useful lives of the assets, generally three to ten years. Leasehold improvements are depreciated over the shorter of the estimated useful lives of the improvements or the remaining lease term. Land is not depreciated.

[0001327567-21-000029:notes:37]
Business Combinations

[0001327567-21-000029:notes:38]
We include the results of operations of the businesses that we acquire as of the respective dates of acquisition. We allocate the fair value of the purchase price of our acquisitions to the tangible assets acquired, liabilities assumed, and intangible assets acquired, based on their estimated fair values. The excess of the purchase price over the fair values of these identifiable assets and liabilities is recorded as goodwill. Additional information existing as of the acquisition date but unknown to us may become known during the remainder of the measurement period, not to exceed 12 months from the acquisition date, which may result in changes to the amounts and allocations recorded.

[0001327567-21-000029:notes:39]
Intangible Assets

[0001327567-21-000029:notes:40]
Purchased intangible assets with finite lives are carried at cost, less accumulated amortization. Amortization is computed over the estimated useful lives of the respective assets.

[0001327567-21-000029:notes:41]
Impairment of Goodwill, Intangible Assets, and Other Long-Lived Assets

[0001327567-21-000029:notes:42]
Goodwill is evaluated for impairment on an annual basis in the fourth quarter of our fiscal year, and whenever events or changes in circumstances indicate the carrying amount of goodwill may not be recoverable. We have elected to first assess qualitative factors to determine whether it is more likely than not that the fair value of our single reporting unit is less than its carrying amount, including goodwill. If we determine that it is more likely than not that the fair value of our single reporting unit is less than its carrying amount, then the quantitative impairment test will be performed. Under the quantitative impairment test, if the carrying amount of our single reporting unit exceeds its fair value, we will recognize an impairment loss in an amount equal to that excess but limited to the total amount of goodwill.

[0001327567-21-000029:notes:43]
We evaluate events and changes in circumstances that could indicate carrying amounts of purchased intangible assets and other long-lived assets may not be recoverable. When such events or changes in circumstances occur, we assess the recoverability of these assets by determining whether or not the carrying amount will be recovered through undiscounted expected future cash flows. If the total of the future undiscounted cash flows is less than the carrying amount of an asset, we record an impairment loss for the amount by which the carrying amount of the asset exceeds the fair value of the asset.

[0001327567-21-000029:notes:44]
We did not recognize any impairment losses on our goodwill, intangible assets, or other long-lived assets during the years ended July 31, 2021, 2020, and 2019.

[0001327567-21-000029:notes:45]
Manufacturing Partner and Supplier Liabilities

[0001327567-21-000029:notes:46]
We outsource most of our manufacturing, repair, and supply chain management operations to our EMS provider and payments to it are a significant portion of our cost of product revenue. Although we could be contractually obligated to purchase manufactured products and components, we generally do not own the manufactured products and components. Product title transfers from our EMS provider to us and immediately to our customers upon shipment. Our EMS provider assembles our products using design specifications, quality assurance programs, and standards that we establish, and it procures components and assembles our products based on our demand forecasts. These forecasts represent our estimates of future demand for our products based upon historical trends and analysis from our sales and product management functions as adjusted for overall market conditions. If the actual component usage and product demand are significantly lower than forecast, we record a liability for manufacturing purchase commitments in excess of our forecasted demand including costs for excess components or for carrying costs incurred by our manufacturing partners and component suppliers. Through July 31, 2021, we have not accrued any significant costs associated with this exposure.

[0001327567-21-000029:notes:47]
Convertible Senior Notes

[0001327567-21-000029:notes:48]
In accounting for the issuance of our convertible senior notes, we separate the notes into liability and equity components. The carrying amount of the liability component is calculated by measuring the fair value of a similar liability that does not have an associated convertible feature, using a discounted cash flow model with a risk adjusted yield. The carrying amount of the equity component representing the conversion option is determined by deducting the fair value of the liability component from the par value of the notes as a whole. This difference represents a debt discount that is amortized to interest expense using the effective interest

[0001327567-21-000029:notes:49]
method over the term of the notes. The equity component is not remeasured as long as it continues to meet the conditions for equity classification. In accounting for the transaction costs related to the issuance of the notes, we allocate the total amount incurred to the liability and equity components using the same proportions as the proceeds from the notes. Transaction costs attributable to the liability component are netted with the liability component and amortized to interest expense using the effective interest method over the term of the notes. Transaction costs attributable to the equity component are netted with the equity component of the notes in additional paid-in capital in the consolidated balance sheets. When the notes are convertible, the net carrying amount of the notes is classified as a current liability and a portion of the equity component representing the conversion option is reclassified to temporary equity in our consolidated balance sheets. The portion of the equity component classified as temporary equity is measured as the difference between the principal and net carrying amount of the notes, excluding debt issuance costs.

[0001327567-21-000029:notes:50]
Revenue Recognition

[0001327567-21-000029:notes:51]
Our revenue consists of product revenue and subscription and support revenue. Revenue is recognized when control of promised products, subscriptions and support services are transferred to customers, in an amount that reflects the expected consideration in exchange for those products and services.

[0001327567-21-000029:notes:52]
We determine revenue recognition through the following steps:

[0001327567-21-000029:notes:53]
•Identification of the contract, or contracts, with a customer.

[0001327567-21-000029:notes:54]
•Identification of the performance obligations in the contract.

[0001327567-21-000029:notes:55]
•Determination of the transaction price.

[0001327567-21-000029:notes:56]
•Allocation of the transaction price to the performance obligations in the contract.

[0001327567-21-000029:notes:57]
•Recognition of revenue when, or as, we satisfy a performance obligation.

[0001327567-21-000029:notes:58]
Revenues are reported net of sales taxes. Shipping charges billed to channel partners are included in revenues and related costs are included in cost of revenue.

[0001327567-21-000029:notes:59]
Product Revenue

[0001327567-21-000029:notes:60]
Product revenue is derived primarily from sales of our appliances. Product revenue also includes revenue derived from software licenses of Panorama and the VM-Series. Our appliances and software licenses include a broad set of built-in networking and security features and functionalities. We recognize product revenue at the time of hardware shipment or delivery of software license.

[0001327567-21-000029:notes:61]
Subscription and Support Revenue

[0001327567-21-000029:notes:62]
Subscription and support revenue is derived primarily from sales of our subscription and support offerings. We recognize subscription and support revenue over time as the services are performed. Our contractual subscription and support contracts are typically one to five years.

[0001327567-21-000029:notes:63]
Contracts with Multiple Performance Obligations

[0001327567-21-000029:notes:64]
The majority of our contracts with our customers include various combinations of our products and subscriptions and support. Our appliances and software licenses have significant standalone functionalities and capabilities. Accordingly, these appliances and software licenses are distinct from our subscriptions and support services as the customer can benefit from the product without these services and such services are separately identifiable within the contract. We account for multiple agreements with a single customer as a single contract if the contractual terms and/or substance of those agreements indicate that they may be so closely related that they are, in effect, parts of a single contract. The amount of consideration we expect to receive in exchange for delivering on the contract is allocated to each performance obligation based on its relative standalone selling price. If a contract contains a single performance obligation, no allocation is required.

[0001327567-21-000029:notes:65]
We establish standalone selling price using the prices charged for a deliverable when sold separately. If the standalone selling price is not observable through past transactions, we estimate the standalone selling price based on our pricing model and our go-to-market strategy, which include factors such as type of sales channel (reseller, distributor, or end-customer), the geographies in which our offerings were sold (domestic or international), and offering type (products, subscriptions, or support).

[0001327567-21-000029:notes:66]
Deferred Revenue

[0001327567-21-000029:notes:67]
We record deferred revenue when cash payments are received or due in advance of our performance. Our payment terms typically require payment within 30 to 45 days of the date we issue an invoice. The current portion of deferred revenue represents the amounts that are expected to be recognized as revenue within one year of the consolidated balance sheet date.

[0001327567-21-000029:notes:68]
Deferred Contract Costs

[0001327567-21-000029:notes:69]
We defer contract costs that are recoverable and incremental to obtaining customer sales contracts. Contract costs, which primarily consist of sales commissions, are amortized on a systematic basis that is consistent with the transfer to the customer of the goods or services to which the asset relates. Sales commissions paid for initial contracts are generally not commensurate with the

[0001327567-21-000029:notes:70]
commissions paid for renewal contracts, given the substantive difference in commission rates in proportion to their respective contract values. Sales commissions for initial contracts that are not commensurate are amortized over a benefit period of five years, consistent with the revenue recognition pattern of the performance obligations in the related contracts including expected renewals. The benefit period is determined by taking into consideration contract length, technology life, and other quantitative and qualitative factors. The expected renewals are estimated based on historical renewal trends. Sales commissions for initial contracts that are commensurate and sales commissions for renewal contracts are amortized over the related contractual period in proportion to the revenue recognized.

[0001327567-21-000029:notes:71]
We classify deferred contract costs as short-term or long-term based on when we expect to recognize the expense. The amortization of deferred contract costs is included in sales and marketing expense in our consolidated statements of operations. Deferred contract costs are periodically reviewed for impairment. We did not recognize any impairment losses on our deferred contract costs during the years ended July 31, 2021, 2020, or 2019.

[0001327567-21-000029:notes:72]
Software Development Costs

[0001327567-21-000029:notes:73]
Internally developed software includes security software developed to meet our internal needs to provide cloud-based subscription offerings to our end-customers and business software that we customize to meet our specific operational needs. These capitalized costs consist of internal compensation related costs and external direct costs incurred during the application development stage and will be amortized over a useful life of three to five years. As of July 31, 2021 and 2020, we capitalized as other assets on our consolidated balance sheets $114.8 million and $90.1 million in costs, respectively, net of accumulated amortization, for security software developed to meet our internal needs to provide our cloud-based subscription offerings. We recognized amortization expense of $47.8 million, $31.3 million, and $12.9 million related to these capitalized costs as cost of subscription and support revenue in our consolidated statements of operations during the years ended July 31, 2021, 2020, and 2019, respectively.

[0001327567-21-000029:notes:74]
The costs to develop software that is marketed externally have not been capitalized as we believe our current software development process is essentially completed concurrent with the establishment of technological feasibility. As such, all related software development costs are expensed as incurred and included in research and development expense in our consolidated statements of operations.

[0001327567-21-000029:notes:75]
Share-Based Compensation

[0001327567-21-000029:notes:76]
Compensation expense related to share-based transactions, including employee and non-employee director awards, is measured and recognized in the financial statements based on fair value on the grant date. We recognize share-based compensation expense for awards with only service conditions on a straight-line basis over the requisite service period of the related award. We recognize share-based compensation expense for awards with market conditions and awards with performance conditions on a straight-line basis over the requisite service period for each separately vesting portion of the award and, for awards with performance conditions, when it is probable that the performance condition will be achieved. We account for forfeitures of all share-based payment awards when they occur.

[0001327567-21-000029:notes:77]
Leases

[0001327567-21-000029:notes:78]
We determine if an arrangement is a lease at inception. We evaluate the classification of leases at commencement and, as necessary, at modification. Operating leases are included in operating lease right-of-use assets, accrued and other liabilities, and long-term operating lease liabilities on our consolidated balance sheets. We did not have any material finance leases in any of the periods presented.

[0001327567-21-000029:notes:79]
Operating lease right-of-use assets represent our right to use an underlying asset for the lease term. Operating lease liabilities represent our obligation to make payments arising from the lease. Operating lease right-of-use assets and liabilities are recognized at the present value of the future lease payments at the lease commencement date. The interest rate used to determine the present value of the future lease payments is our incremental borrowing rate, because the interest rates implicit in most of our leases are not readily determinable. Our incremental borrowing rate is estimated to approximate the interest rate on a collateralized basis with similar terms and payments, and in economic environments where the leased asset is located. Operating lease right-of-use assets also include adjustments related to lease incentives, prepaid or accrued rent and initial direct lease costs. Operating lease right-of-use assets are subject to evaluation for impairment or disposal on a basis consistent with other long-lived assets.

[0001327567-21-000029:notes:80]
Our lease terms may include periods under options to extend or terminate the lease when it is reasonably certain that we will exercise that option. We generally use the base, non-cancelable lease term when determining the lease assets and liabilities. Operating lease cost is recognized on a straight-line basis over the lease term.

[0001327567-21-000029:notes:81]
We account for lease and non-lease components as a single lease component and do not recognize right-of-use assets and lease liabilities for leases with a term of 12 months or less. Payments under our lease arrangements are primarily fixed, however, certain lease agreements contain variable payments, which are expensed as incurred and not included in the operating lease right-of-use assets and liabilities. Variable lease payments are primarily comprised of real estate taxes, common area maintenance, and insurance.

[0001327567-21-000029:notes:82]
Income Taxes

[0001327567-21-000029:notes:83]
We account for income taxes using the asset and liability method, which requires the recognition of deferred tax assets and liabilities for the expected future tax consequences of events that have been recognized in our financial statements or tax returns. In addition, deferred tax assets are recorded for the future benefit of utilizing net operating losses and research and development credit carryforwards. Valuation allowances are provided when necessary to reduce deferred tax assets to the amount expected to be realized.

[0001327567-21-000029:notes:84]
Significant judgment is required in determining any valuation allowance recorded against deferred tax assets. In assessing the need for a valuation allowance, we consider all available evidence, including past operating results, estimates of future taxable income, and the feasibility of tax planning strategies. In the event that we change our determination as to the amount of deferred tax assets that can be realized, we will adjust our valuation allowance with a corresponding impact to the provision for income taxes in the period in which such determination is made.

[0001327567-21-000029:notes:85]
We apply the authoritative accounting guidance prescribing a threshold and measurement attribute for the financial recognition and measurement of a tax position taken or expected to be taken in a tax return. We recognize liabilities for uncertain tax positions based on a two-step process. The first step is to evaluate the tax position for recognition by determining if the weight of available evidence indicates that it is more likely than not that the position will be sustained on audit, including resolution of related appeals or litigation processes, if any. The second step requires us to estimate and measure the tax benefit as the largest amount that is more likely than not to be realized upon ultimate settlement.

[0001327567-21-000029:notes:86]
Loss Contingencies

[0001327567-21-000029:notes:87]
We are subject to the possibility of various loss contingencies arising in the ordinary course of business. In determining loss contingencies, we consider the likelihood of loss or impairment of an asset, or the incurrence of a liability, as well as our ability to reasonably estimate the amount of loss. An estimated loss contingency is accrued when it is probable that an asset has been impaired, or a liability has been incurred and the amount of loss can be reasonably estimated. If we determine that a loss is possible and the range of the loss can be reasonably determined, then we disclose the range of the possible loss. We regularly evaluate current information available to us to determine whether an accrual is required, an accrual should be adjusted, or a range of possible loss should be disclosed.

[0001327567-21-000029:notes:88]
Recently Adopted Accounting Pronouncements

[0001327567-21-000029:notes:89]
Credit Losses

[0001327567-21-000029:notes:90]
In June 2016, the Financial Accounting Standards Board (“FASB”) issued new authoritative guidance on the accounting for credit losses on most financial assets and certain financial instruments. The standard replaces the incurred loss model with an expected credit loss model for off-balance sheet credit exposures and financial assets measured at amortized cost, including trade accounts receivables and financing receivables. Credit losses on available-for-sale debt securities are required to be recorded through an allowance rather than as a write-down.

[0001327567-21-000029:notes:91]
We adopted this standard in our first quarter of fiscal 2021 using the modified-retrospective approach. The adoption of this standard did not have a material impact on our consolidated financial statements.

[0001327567-21-000029:notes:92]
Recently Issued Accounting Pronouncements

[0001327567-21-000029:notes:93]
Debt with Conversion Options

[0001327567-21-000029:notes:94]
In August 2020, the FASB issued new authoritative guidance to simplify the accounting for certain financial instruments with characteristics of liabilities and equity, including convertible instruments and contracts on an entity’s own equity. The standard reduces the number of models used to account for convertible instruments and simplifies both the classification of debt on the balance sheet and the earnings per share calculation.

[0001327567-21-000029:notes:95]
We intend to early adopt this standard in our first quarter of fiscal 2022 using the modified-retrospective approach, under which, financial results reported in periods prior to fiscal 2022 will not be adjusted. We expect the adoption of this standard to result in a decrease to accumulated deficit of $266.6 million, a decrease to additional paid-in capital of $711.0 million, and an increase to convertible senior notes, net of $444.4 million. Interest expense recognized in future periods will be reduced as a result of accounting for our convertible debt instrument as a single liability measured at its amortized cost.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001327567-21-000029:notes:96]
Revenue 
Disaggregation of Revenue

[0001327567-21-000029:notes:97]
The following table presents revenue by geographic theater (in millions):

[0001327567-21-000029:notes:98]
|  | Year Ended July 31, |
|  | 2021 |  | 2020 |  | 2019 |
| Revenue: |  |  |  |  |  |
| Americas |  |  |  |  |  |
| United States | $ | 2,747.8 |  |  | $ | 2,157.6 |  |  | $ | 1,824.2 |  |
| Other Americas | 189.7 |  |  | 160.4 |  |  | 152.8 |  |
| Total Americas | 2,937.5 |  |  | 2,318.0 |  |  | 1,977.0 |  |
| Europe, the Middle East, and Africa (“EMEA”) | 817.3 |  |  | 671.9 |  |  | 568.6 |  |
| Asia Pacific and Japan (“APAC”) | 501.3 |  |  | 418.5 |  |  | 354.0 |  |
| Total revenue | $ | 4,256.1 |  |  | $ | 3,408.4 |  |  | $ | 2,899.6 |  |

[0001327567-21-000029:notes:99]
The following table presents revenue for groups of similar products and services (in millions):

[0001327567-21-000029:notes:100]
|  | Year Ended July 31, |
|  | 2021 |  | 2020 |  | 2019 |
| Revenue: |  |  |  |  |  |
| Product | $ | 1,120.3 |  |  | $ | 1,064.2 |  |  | $ | 1,096.2 |  |
| Subscription and support |  |  |  |  |  |
| Subscription | 1,898.8 |  |  | 1,405.3 |  |  | 1032.7 |
| Support | 1,237.0 |  |  | 938.9 |  |  | 770.7 |
| Total subscription and support | 3,135.8 |  |  | 2,344.2 |  |  | 1,803.4 |  |
| Total revenue | $ | 4,256.1 |  |  | $ | 3,408.4 |  |  | $ | 2,899.6 |  |

[0001327567-21-000029:notes:101]
During the years ended July 31, 2021 and July 31, 2020, we recognized approximately $2.0 billion and $1.5 billion of revenue pertaining to amounts that were deferred as of July 31, 2020 and July 31, 2019, respectively.

[0001327567-21-000029:notes:102]
Remaining Performance Obligations

[0001327567-21-000029:notes:103]
Revenue expected to be recognized from remaining performance obligations was $5.9 billion as of July 31, 2021, of which we expect to recognize approximately $3.1 billion over the next 12 months and the remainder thereafter.


## us-gaap:FairValueDisclosuresTextBlock

[0001327567-21-000029:notes:104]
Fair Value Measurements 
We categorize assets and liabilities recorded or disclosed at fair value on our consolidated balance sheets based upon the level of judgment associated with inputs used to measure their fair value. The categories are as follows:

[0001327567-21-000029:notes:105]
•Level 1—Inputs are unadjusted quoted prices in active markets for identical assets or liabilities.

[0001327567-21-000029:notes:106]
•Level 2—Inputs are quoted prices for similar assets and liabilities in active markets or inputs that are observable for the assets or liabilities, either directly or indirectly through market corroboration, for substantially the full term of the financial instruments.

[0001327567-21-000029:notes:107]
•Level 3—Inputs are unobservable inputs based on our own assumptions used to measure assets and liabilities at fair value. The inputs require significant management judgment or estimation.

[0001327567-21-000029:notes:108]
The following table presents the fair value of our financial assets and liabilities measured at fair value on a recurring basis using the above input categories as of July 31, 2021 and July 31, 2020 (in millions):

[0001327567-21-000029:notes:109]
|  |  | July 31, 2021 |  | July 31, 2020 |
|  |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Cash equivalents: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 124.2 |  |  | $ | — |  |  | $ | — |  |  | $ | 124.2 |  |  | $ | 1,589.5 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,589.5 |  |
| Certificates of deposit |  | — |  |  | 150.4 |  |  | — |  |  | 150.4 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Corporate debt securities |  | — |  |  | 1.0 |  |  | — |  |  | 1.0 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| U.S. government and agency securities |  | — |  |  | 116.3 |  |  | — |  |  | 116.3 |  |  | — |  |  | 342.0 |  |  | — |  |  | 342.0 |  |
| Total cash equivalents |  | 124.2 |  |  | 267.7 |  |  | — |  |  | 391.9 |  |  | 1,589.5 |  |  | 342.0 |  |  | — |  |  | 1,931.5 |  |
| Short-term investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Certificates of deposit |  | — |  |  | 12.4 |  |  | — |  |  | 12.4 |  |  | — |  |  | 26.9 |  |  | — |  |  | 26.9 |  |
| Corporate debt securities |  | — |  |  | 208.9 |  |  | — |  |  | 208.9 |  |  | — |  |  | 100.2 |  |  | — |  |  | 100.2 |  |
| U.S. government and agency securities |  | — |  |  | 762.1 |  |  | — |  |  | 762.1 |  |  | — |  |  | 645.6 |  |  | — |  |  | 645.6 |  |
| Non-U.S. government and agency securities |  | — |  |  | 43.5 |  |  | — |  |  | 43.5 |  |  | — |  |  | 17.1 |  |  | — |  |  | 17.1 |  |
| Total short-term investments |  | — |  |  | 1,026.9 |  |  | — |  |  | 1,026.9 |  |  | — |  |  | 789.8 |  |  | — |  |  | 789.8 |  |
| Long-term investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Certificates of deposit |  | — |  |  | 5.0 |  |  | — |  |  | 5.0 |  |  | — |  |  | 5.0 |  |  | — |  |  | 5.0 |  |
| Corporate debt securities |  | — |  |  | 180.7 |  |  | — |  |  | 180.7 |  |  | — |  |  | 91.7 |  |  | — |  |  | 91.7 |  |
| U.S. government and agency securities |  | — |  |  | 674.1 |  |  | — |  |  | 674.1 |  |  | — |  |  | 447.4 |  |  | — |  |  | 447.4 |  |
| Non-U.S. government and agency securities |  | — |  |  | 28.5 |  |  | — |  |  | 28.5 |  |  | — |  |  | 10.3 |  |  | — |  |  | 10.3 |  |
| Total long-term investments |  | — |  |  | 888.3 |  |  | — |  |  | 888.3 |  |  | — |  |  | 554.4 |  |  | — |  |  | 554.4 |  |
| Prepaid expenses and other current assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency forward contracts |  | — |  |  | 4.1 |  |  | — |  |  | 4.1 |  |  | — |  |  | 13.6 |  |  | — |  |  | 13.6 |  |
| Total prepaid expenses and other current assets |  | — |  |  | 4.1 |  |  | — |  |  | 4.1 |  |  | — |  |  | 13.6 |  |  | — |  |  | 13.6 |  |
| Other assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency forward contracts |  | — |  |  | 0.1 |  |  | — |  |  | 0.1 |  |  | — |  |  | 1.4 |  |  | — |  |  | 1.4 |  |
| Total other assets |  | — |  |  | 0.1 |  |  | — |  |  | 0.1 |  |  | — |  |  | 1.4 |  |  | — |  |  | 1.4 |  |
| Total assets measured at fair value |  | $ | 124.2 |  |  | $ | 2,187.1 |  |  | $ | — |  |  | $ | 2,311.3 |  |  | $ | 1,589.5 |  |  | $ | 1,701.2 |  |  | $ | — |  |  | $ | 3,290.7 |  |
| Accrued and other liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency forward contracts |  | $ | — |  |  | $ | 6.4 |  |  | $ | — |  |  | $ | 6.4 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Total accrued and other liabilities |  | — |  |  | 6.4 |  |  | — |  |  | 6.4 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Other long-term liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency forward contracts |  | — |  |  | 0.5 |  |  | — |  |  | 0.5 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Total other long-term liabilities |  | — |  |  | 0.5 |  |  | — |  |  | 0.5 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Total liabilities measured at fair value |  | $ | — |  |  | $ | 6.9 |  |  | $ | — |  |  | $ | 6.9 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |

[0001327567-21-000029:notes:110]
Refer to Note 10. Debt, for the carrying amount and estimated fair value of our convertible senior notes as of July 31, 2021 and July 31, 2020.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001327567-21-000029:notes:111]
Cash Equivalents and Investments
Available-for-sale Debt Securities

[0001327567-21-000029:notes:112]
The following tables summarize the amortized cost, unrealized gains and losses, and fair value of our available-for-sale debt securities as of July 31, 2021 and July 31, 2020 (in millions):

[0001327567-21-000029:notes:113]
|  | July 31, 2021 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 150.4 |  |  | $ | — |  |  | $ | — |  |  | $ | 150.4 |  |
| Corporate debt securities | 1.0 |  |  | — |  |  | — |  |  | 1.0 |  |
| U.S. government and agency securities | 116.3 |  |  | — |  |  | — |  |  | 116.3 |  |
| Total available-for-sale cash equivalents | $ | 267.7 |  |  | $ | — |  |  | $ | — |  |  | $ | 267.7 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 17.4 |  |  | $ | — |  |  | $ | — |  |  | $ | 17.4 |  |
| Corporate debt securities | 389.2 |  |  | 0.5 |  |  | (0.1) |  |  | 389.6 |  |
| U.S. government and agency securities | 1,435.1 |  |  | 1.1 |  |  | — |  |  | 1,436.2 |  |
| Non-U.S. government and agency securities | 72.0 |  |  | — |  |  | — |  |  | 72.0 |  |
| Total available-for-sale investments | $ | 1,913.7 |  |  | $ | 1.6 |  |  | $ | (0.1) |  |  | $ | 1,915.2 |  |

[0001327567-21-000029:notes:114]
|  | July 31, 2020 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| U.S. government and agency securities | $ | 342.0 |  |  | $ | — |  |  | $ | — |  |  | $ | 342.0 |  |
| Total available-for-sale cash equivalents | $ | 342.0 |  |  | $ | — |  |  | $ | — |  |  | $ | 342.0 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 31.9 |  |  | $ | — |  |  | $ | — |  |  | $ | 31.9 |  |
| Corporate debt securities | 190.1 |  |  | 1.8 |  |  | — |  |  | 191.9 |  |
| U.S. government and agency securities | 1,090.3 |  |  | 2.8 |  |  | (0.1) |  |  | 1,093.0 |  |
| Non-U.S. government and agent securities | 27.4 |  | — |  | — |  |  | 27.4 |
| Total available-for-sale investments | $ | 1,339.7 |  |  | $ | 4.6 |  |  | $ | (0.1) |  |  | $ | 1,344.2 |  |

[0001327567-21-000029:notes:115]
We do not intend to sell any of the securities in an unrealized loss position and it is not likely that we would be required to sell these securities before recovery of their amortized cost basis, which may be at maturity. We did not recognize any credit losses related to our available-for-sale debt securities during the year ended July 31, 2021, and there were no other-than-temporary impairments for these securities during the year ended July 31, 2020.

[0001327567-21-000029:notes:116]
The following table summarizes the amortized cost and fair value of our available-for-sale debt securities as of July 31, 2021, by contractual years-to-maturity (in millions):

[0001327567-21-000029:notes:117]
|  | Amortized Cost |  | Fair Value |
| Due within one year | $ | 1,293.3 |  |  | $ | 1,294.6 |  |
| Due between one and three years | 888.1 |  |  | 888.3 |  |
| Total | $ | 2,181.4 |  |  | $ | 2,182.9 |  |

[0001327567-21-000029:notes:118]
Marketable Equity Securities

[0001327567-21-000029:notes:119]
Marketable equity securities consist of money market funds and are included in cash and cash equivalents in our consolidated balance sheets. As of July 31, 2021 and 2020, the carrying value of our marketable equity securities were $124.2 million and $1.6 billion, respectively. There were no unrealized gains or losses recognized for these securities during the years ended July 31, 2021, 2020, and 2019.


## us-gaap:FinancingReceivablesTextBlock

[0001327567-21-000029:notes:120]
Financing Receivables
The following table summarizes our short-term and long-term financing receivables as of July 31, 2021 (in millions):

[0001327567-21-000029:notes:121]
|  |  | Amount |
| Short-term financing receivables, gross |  | $ | 80.0 |  |
| Allowance for credit losses |  | (1.0) |  |
| Short-term financing receivables, net |  | $ | 79.0 |  |
| Long-term financing receivables, gross |  | $ | 198.6 |  |
| Allowance for credit losses |  | (4.3) |  |
| Long-term financing receivables, net |  | $ | 194.3 |  |

[0001327567-21-000029:notes:122]
There was no significant activity in allowance for credit losses during the year ended July 31, 2021. Past due amounts on financing receivables were immaterial as of July 31, 2021. Through July 31, 2020, financing receivables were not significant to our consolidated balance sheet.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001327567-21-000029:notes:123]
Derivative Instruments 
As of July 31, 2021 and 2020, the total notional amount of our outstanding foreign currency forward contracts was $531.9 million and $443.6 million, respectively. Refer to Note 3. Fair Value Measurements for the fair value of our derivative instruments as reported on our consolidated balance sheets as of July 31, 2021.

[0001327567-21-000029:notes:124]
During the years ended July 31, 2021, 2020, and 2019, both unrealized gains and losses recognized in AOCI related to our cash flow hedges and amounts reclassified into earnings were not material. Unrealized gains and losses in AOCI related to our cash flow hedges as of July 31, 2021 and July 31, 2020 were not material.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001327567-21-000029:notes:125]
Acquisitions 
Fiscal 2021

[0001327567-21-000029:notes:126]
Bridgecrew Inc.

[0001327567-21-000029:notes:127]
On March 2, 2021, we completed our acquisition of Bridgecrew Inc. (“Bridgecrew”), a privately-held cloud security company. We expect the acquisition will expand our Prisma Cloud offering to deliver security across the full application lifecycle. The total purchase consideration for the acquisition of Bridgecrew was $156.9 million, which consisted of the following (in millions):

[0001327567-21-000029:notes:128]
|  | Amount |
| Cash | $ | 155.9 |  |
| Fair value of replacement awards | 1.0 |  |
| Total | $ | 156.9 |  |

[0001327567-21-000029:notes:129]
As part of the acquisition, we issued $42.5 million of replacement awards, of which the portion attributable to services performed prior to the acquisition date was allocated to purchase consideration. The remaining fair value was allocated to future services and will be expensed over the remaining service periods as share-based compensation.

[0001327567-21-000029:notes:130]
We have accounted for this transaction as a business combination and allocated the purchase consideration to assets acquired and liabilities assumed based on preliminary estimated fair values, as presented in the following table (in millions):

[0001327567-21-000029:notes:131]
|  | Amount |
| Goodwill | $ | 129.6 |  |
| Identified intangible assets | 21.6 |  |
| Cash | 9.0 |  |
| Net liabilities assumed | (3.3) |  |
| Total | $ | 156.9 |  |

[0001327567-21-000029:notes:132]
Goodwill generated from this business combination is primarily attributable to the assembled workforce and expected post-acquisition synergies from integrating Bridgecrew technology into our platforms. The goodwill is not deductible for income tax purposes.

[0001327567-21-000029:notes:133]
The following table presents details of the identified intangible asset acquired (in millions, except years):

[0001327567-21-000029:notes:134]
|  | Fair Value |  | Estimated Useful Life |
| Developed technology | $ | 21.6 |  |  | 6 years |

[0001327567-21-000029:notes:135]
Expanse Inc.

[0001327567-21-000029:notes:136]
On December 15, 2020, we completed our acquisition of Expanse Inc. (“Expanse”), a privately-held company specializing in attack surface management. We expect the acquisition will enrich our Cortex offerings and provide organizations an integrated view of the enterprise to combine external, internal, and threat data. The total purchase consideration for the acquisition of Expanse was $797.2 million, which consisted of the following (in millions):

[0001327567-21-000029:notes:137]
|  | Amount |
| Cash | $ | 434.9 |  |
| Common stock (1.1 million shares) | 340.7 |  |
| Fair value of replacement awards | 21.6 |  |
| Total | $ | 797.2 |  |

[0001327567-21-000029:notes:138]
As part of the acquisition, we issued replacement equity awards, which included 0.2 million shares of our restricted common stock. The total fair value of the replacement equity awards was $160.0 million, of which the portion attributable to services performed prior to the acquisition date was allocated to purchase consideration. The remaining fair value was allocated to future services and will be expensed over the remaining service periods as share-based compensation.

[0001327567-21-000029:notes:139]
|  | Amount |
| Goodwill | $ | 598.2 |  |
| Identified intangible assets | 160.3 |  |
| Cash | 51.1 |  |
| Net liabilities assumed | (12.4) |  |
| Total | $ | 797.2 |  |

[0001327567-21-000029:notes:140]
Goodwill generated from this business combination is primarily attributable to the assembled workforce and expected post-acquisition synergies from integrating Expanse technology into our platforms. The goodwill is not deductible for income tax purposes.

[0001327567-21-000029:notes:141]
The following table presents details of the identified intangible assets acquired (in millions, except years):

[0001327567-21-000029:notes:142]
|  | Fair Value |  | Estimated Useful Life |
| Developed technology | $ | 123.4 |  |  | 6 years |
| Customer relationships | 36.9 |  |  | 10 years |
| Total | $ | 160.3 |  |  |  |

[0001327567-21-000029:notes:143]
Sinefa Group, Inc.

[0001327567-21-000029:notes:144]
On November 24, 2020, we completed our acquisition of Sinefa Group, Inc. and its wholly owned subsidiaries (“Sinefa”), a privately-held digital experience monitoring company. We expect the acquisition will extend our Prisma Access offering. The total purchase consideration for the acquisition of Sinefa was $27.0 million, which consisted of the following (in millions):

[0001327567-21-000029:notes:145]
|  | Amount |
| Cash | $ | 26.9 |  |
| Fair value of replacement awards | 0.1 |  |
| Total | $ | 27.0 |  |

[0001327567-21-000029:notes:146]
As part of the acquisition, we issued $11.5 million of replacement equity awards, of which the portion attributable to services performed prior to the acquisition date was allocated to purchase consideration. The remaining fair value was allocated to future services and will be expensed over the remaining service periods as share-based compensation.

[0001327567-21-000029:notes:147]
|  | Amount |
| Goodwill | $ | 13.7 |  |
| Identified intangible assets | 20.4 |  |
| Net liabilities assumed | (7.1) |  |
| Total | $ | 27.0 |  |

[0001327567-21-000029:notes:148]
Goodwill generated from this business combination is primarily attributable to the assembled workforce and expected post-acquisition synergies from integrating Sinefa technology into our platforms. The goodwill is deductible for income tax purposes.

[0001327567-21-000029:notes:149]
|  | Fair Value |  | Estimated Useful Life |
| Developed technology | $ | 18.6 |  |  | 6 years |
| Customer relationships | 1.8 |  |  | 8 years |
| Total | $ | 20.4 |  |  |  |

[0001327567-21-000029:notes:150]
The Crypsis Group

[0001327567-21-000029:notes:151]
On September 17, 2020, we completed our acquisition of The Crypsis Group (“Crypsis”), an incident response, risk management, and digital forensics consulting firm. We expect the acquisition will expand our capabilities and strengthen our Cortex strategy. The total purchase consideration for the acquisition of Crypsis was $227.7 million, which consisted of the following (in millions):

[0001327567-21-000029:notes:152]
|  | Amount |
| Cash | $ | 225.7 |  |
| Fair value of replacement awards | 2.0 |  |
| Total | $ | 227.7 |  |

[0001327567-21-000029:notes:153]
As part of the acquisition, we issued $27.1 million of replacement awards, of which the portion attributable to services performed prior to the acquisition date was allocated to purchase consideration. The remaining fair value was allocated to future services and will be expensed over the remaining service periods as share-based compensation.

[0001327567-21-000029:notes:154]
|  | Amount |
| Goodwill | $ | 157.6 |  |
| Identified intangible assets | 54.4 |  |
| Net assets acquired | 15.7 |  |
| Total | $ | 227.7 |  |

[0001327567-21-000029:notes:155]
Goodwill generated from this business combination is primarily attributable to the assembled workforce and expected post-acquisition synergies from integrating Crypsis technology into our platforms. The goodwill is deductible for income tax purposes.

[0001327567-21-000029:notes:156]
|  | Fair Value |  | Estimated Useful Life |
| Developed technology | $ | 6.9 |  |  | 3 years |
| Customer relationships | 47.5 |  |  | 7 years |
| Total | $ | 54.4 |  |  |  |

[0001327567-21-000029:notes:157]
Fiscal 2020

[0001327567-21-000029:notes:158]
CloudGenix Inc.

[0001327567-21-000029:notes:159]
On April 21, 2020, we completed our acquisition of CloudGenix, Inc. (“CloudGenix”), a privately-held company. We believe the acquisition will strengthen our secure access service edge (“SASE”) offering. The total purchase consideration for the acquisition of CloudGenix was $402.7 million, which consisted of the following (in millions):

[0001327567-21-000029:notes:160]
|  | Amount |
| Cash | $ | 396.1 |  |
| Fair value of replacement awards | 6.6 |  |
| Total | $ | 402.7 |  |

[0001327567-21-000029:notes:161]
As part of the acquisition, we issued $30.3 million of replacement awards, of which the portion attributable to services performed prior to the acquisition date was allocated to purchase consideration. The remaining fair value was allocated to future services and will be expensed over the remaining service periods as share-based compensation.

[0001327567-21-000029:notes:162]
We have accounted for this transaction as a business combination and allocated the purchase consideration to assets acquired and liabilities assumed based on estimated fair values, as presented in the following table (in millions):

[0001327567-21-000029:notes:163]
|  | Amount |
| Goodwill | $ | 301.2 |  |
| Identified intangible assets | 109.9 |  |
| Cash | 8.3 |  |
| Net liabilities assumed | (16.7) |  |
| Total | $ | 402.7 |  |

[0001327567-21-000029:notes:164]
Goodwill generated from this business combination is primarily attributable to the assembled workforce and expected post-acquisition synergies from integrating CloudGenix technology into our portfolio. The goodwill is not deductible for income tax purposes.

[0001327567-21-000029:notes:165]
|  | Fair Value |  | Estimated Useful Life |
| Developed technology | $ | 67.2 |  |  | 5 years |
| Customer relationships | 42.7 |  |  | 10 years |
| Total | $ | 109.9 |  |  |  |

[0001327567-21-000029:notes:166]
Aporeto, Inc.

[0001327567-21-000029:notes:167]
On December 23, 2019, we completed our acquisition of Aporeto, Inc. (“Aporeto”), a privately-held machine identity-based microsegmentation company. We believe the acquisition will strengthen our cloud-native security platform capabilities delivered by Prisma Cloud. The total purchase consideration for the acquisition of Aporeto was $144.1 million, which consisted of the following (in millions):

[0001327567-21-000029:notes:168]
|  | Amount |
| Cash | $ | 139.8 |  |
| Fair value of replacement awards | 4.3 |  |
| Total | $ | 144.1 |  |

[0001327567-21-000029:notes:169]
As part of the acquisition, we issued $16.4 million of replacement awards, of which the portion attributable to services performed prior to the acquisition date was allocated to purchase consideration. The remaining fair value was allocated to future services and will be expensed over the remaining service periods as share-based compensation.

[0001327567-21-000029:notes:170]
|  | Amount |
| Goodwill | $ | 111.3 |  |
| Identified intangible assets | 23.8 |  |
| Cash | 10.5 |  |
| Net liabilities assumed | (1.5) |  |
| Total | $ | 144.1 |  |

[0001327567-21-000029:notes:171]
Goodwill generated from this business combination is primarily attributable to the assembled workforce and expected post-acquisition synergies from integrating Aporeto’s technology into our platform. The goodwill is not deductible for income tax purposes.

[0001327567-21-000029:notes:172]
|  | Fair Value |  | Estimated Useful Life |
| Developed technology | $ | 20.5 |  |  | 7 years |
| Customer relationships | 3.3 |  |  | 4 years |
| Total | $ | 23.8 |  |  |  |

[0001327567-21-000029:notes:173]
Zingbox, Inc.

[0001327567-21-000029:notes:174]
On September 20, 2019, we completed our acquisition of Zingbox, Inc. (“Zingbox”), a privately-held Internet of Things (“IoT”) security company. We believe the acquisition will accelerate our delivery of IoT security through our ML-Powered Next-Generation Firewall and Cortex offerings. The total purchase consideration for the acquisition of Zingbox was $66.4 million in cash.

[0001327567-21-000029:notes:175]
As part of the acquisition, we issued replacement equity awards with a total fair value of $5.7 million, which will be expensed over the remaining service periods as share-based compensation.

[0001327567-21-000029:notes:176]
|  | Amount |
| Goodwill | $ | 48.1 |  |
| Identified intangible assets | 20.4 |  |
| Net liabilities assumed | (2.1) |  |
| Total | $ | 66.4 |  |

[0001327567-21-000029:notes:177]
Goodwill generated from this business combination is primarily attributable to the assembled workforce and expected post-acquisition synergies from integrating Zingbox’s technology into our portfolio. The goodwill is not deductible for income tax purposes.

[0001327567-21-000029:notes:178]
|  | Fair Value |  | Estimated Useful Life |
| Developed technology | $ | 18.6 |  |  | 5 years |
| Customer relationships | 1.8 |  |  | 8 years |
| Total | $ | 20.4 |  |  |  |

[0001327567-21-000029:notes:179]
Fiscal 2019

[0001327567-21-000029:notes:180]
Twistlock Ltd.

[0001327567-21-000029:notes:181]
On July 9, 2019, we completed our acquisition of Twistlock Ltd. (“Twistlock”), a privately-held company specializing in container security. The acquisition extends our cloud security strategy with the addition of Twistlock to our Prisma cloud security offerings. The total purchase consideration for the acquisition of Twistlock was $378.1 million, which consisted of the following (in

[0001327567-21-000029:notes:182]
millions):

[0001327567-21-000029:notes:183]
|  | Amount |
| Cash | $ | 375.4 |  |
| Fair value of replacement equity awards | 2.7 |  |
| Total purchase consideration | $ | 378.1 |  |

[0001327567-21-000029:notes:184]
As part of the acquisition, we issued replacement equity awards, which included 0.1 million shares of our restricted common stock. The total fair value of the replacement equity awards was $51.8 million, of which the portion attributable to services performed prior to the acquisition date was allocated to the purchase consideration. The remaining fair value was allocated to future services and will be expensed over the remaining service periods as share-based compensation.

[0001327567-21-000029:notes:185]
|  | Amount |
| Goodwill | $ | 300.6 |  |
| Identified intangible assets | 54.1 |  |
| Cash and cash equivalents | 14.0 |  |
| Net assets acquired | 9.4 |  |
| Total | $ | 378.1 |  |

[0001327567-21-000029:notes:186]
Goodwill generated from this business combination is primarily attributable to the assembled workforce and expected post-acquisition synergies from integrating Twistlock’s product into our platform. The goodwill is deductible for U.S. income tax purposes.

[0001327567-21-000029:notes:187]
|  | Fair Value |  | Estimated Useful Life |
| Developed technology | $ | 51.5 |  |  | 7 years |
| Customer relationships | 2.6 |  |  | 8 years |
| Total | $ | 54.1 |  |  |  |

[0001327567-21-000029:notes:188]
PureSec Ltd.

[0001327567-21-000029:notes:189]
On June 12, 2019, we completed our acquisition of PureSec Ltd. (“PureSec”), a privately-held company specializing in cybersecurity solutions for serverless architectures. The acquisition extends our cloud security strategy with the addition of PureSec to our Prisma cloud security offerings. The total purchase consideration for the acquisition of PureSec was $36.8 million, which consisted of the following (in millions):

[0001327567-21-000029:notes:190]
|  | Amount |
| Cash | $ | 35.9 |  |
| Fair value of replacement equity awards | 0.9 |  |
| Total purchase consideration | $ | 36.8 |  |

[0001327567-21-000029:notes:191]
As part of the acquisition, we issued replacement equity awards. The total fair value of the replacement equity awards was $9.1 million, of which the portion attributable to services performed prior to the acquisition date was allocated to the purchase consideration. The remaining fair value was allocated to future services and will be expensed over the remaining service periods as share-based compensation.

[0001327567-21-000029:notes:192]
|  | Amount |
| Goodwill | $ | 24.4 |  |
| Identified intangible assets | 7.4 |  |
| Cash | 4.0 |  |
| Net assets acquired | 1.0 |  |
| Total | $ | 36.8 |  |

[0001327567-21-000029:notes:193]
Goodwill generated from this business combination is primarily attributable to the assembled workforce and expected post-

[0001327567-21-000029:notes:194]
acquisition synergies from integrating PureSec’s product into our platform. The goodwill is deductible for U.S. income tax purposes.

[0001327567-21-000029:notes:195]
|  | Fair Value |  | Estimated Useful Life |
| Developed technology | $ | 7.4 |  |  | 5 years |

[0001327567-21-000029:notes:196]
Demisto, Inc.

[0001327567-21-000029:notes:197]
On March 28, 2019, we completed our acquisition of Demisto, Inc. (“Demisto”), a privately-held security company specializing in security orchestration, automation and response (“SOAR”). The acquisition expands the functionality of our portfolio with the addition of Demisto’s SOAR product. The total purchase consideration for the acquisition of Demisto was $474.2 million, which consisted of the following (in millions):

[0001327567-21-000029:notes:198]
|  | Amount |
| Cash | $ | 250.0 |  |
| Common stock (0.9 million shares) | 214.7 |  |
| Fair value of replacement equity awards | 9.5 |  |
| Total purchase consideration | $ | 474.2 |  |

[0001327567-21-000029:notes:199]
As part of the acquisition, we issued replacement equity awards, which included 0.3 million shares of our restricted common stock. The total fair value of the replacement equity awards was $105.2 million, of which the portion attributable to services performed prior to the acquisition date was allocated to the purchase consideration. The remaining fair value was allocated to future services and will be expensed over the remaining service periods as share-based compensation.

[0001327567-21-000029:notes:200]
|  | Amount |
| Goodwill | $ | 387.8 |  |
| Identified intangible assets | 76.3 |  |
| Cash | 25.9 |  |
| Net liabilities assumed | (15.8) |  |
| Total | $ | 474.2 |  |

[0001327567-21-000029:notes:201]
Goodwill generated from this business combination is primarily attributable to the assembled workforce and expected post-acquisition synergies from integrating Demisto’s product into our portfolio. The goodwill is not deductible for income tax purposes.

[0001327567-21-000029:notes:202]
|  | Fair Value |  | Estimated Useful Life |
| Developed technology | $ | 56.6 |  |  | 6 years |
| Customer relationships | 19.7 |  |  | 6 years |
| Total | $ | 76.3 |  |  |  |

[0001327567-21-000029:notes:203]
RedLock Inc.

[0001327567-21-000029:notes:204]
On October 12, 2018, we completed our acquisition of RedLock Inc. (“RedLock”), a privately-held cloud security company. The acquisition expands our security capabilities for the public cloud with the addition of RedLock’s cloud security analytics technology. The total purchase consideration for the acquisition of RedLock was $158.2 million, which consisted of $155.0 million in cash paid upon closing and $3.2 million in fair value of unvested equity awards attributable to services performed prior to the acquisition date.

[0001327567-21-000029:notes:205]
As part of the acquisition, we assumed RedLock equity awards with a total fair value of $57.4 million. Of the total fair value, a portion was allocated to the purchase consideration and the remainder was allocated to future services and will be expensed over the remaining service periods as share-based compensation.

[0001327567-21-000029:notes:206]
|  | Amount |
| Goodwill | $ | 113.6 |  |
| Identified intangible assets | 54.8 |  |
| Net liabilities assumed | (10.2) |  |
| Total | $ | 158.2 |  |

[0001327567-21-000029:notes:207]
Goodwill generated from this business combination is primarily attributable to the assembled workforce and expected post-acquisition synergies from integrating RedLock’s technology into our platform. The goodwill is not deductible for income tax purposes.

[0001327567-21-000029:notes:208]
|  | Fair Value |  | Estimated Useful Life |
| Developed technology | $ | 48.6 |  |  | 4 years |
| Customer relationships | 5.3 |  |  | 8 years |
| Trade name and trademarks | 0.9 |  |  | 6 months |
| Total | $ | 54.8 |  |  |  |

[0001327567-21-000029:notes:209]
Additional Acquisition-Related Information

[0001327567-21-000029:notes:210]
The operating results of the acquired companies are included in our consolidated statements of operations from the respective dates of acquisition. Pro forma results of operations have not been presented because the effects of the acquisitions were not material to our consolidated statements of operations.

[0001327567-21-000029:notes:211]
Additional information related to our acquisitions completed in fiscal 2021, such as that related to income tax and other contingencies, existing as of the acquisition date but unknown to us may become known during the remainder of the measurement period, not to exceed 12 months from the respective acquisition date, which may result in changes to the amounts and allocations recorded.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001327567-21-000029:notes:212]
Goodwill and Intangible Assets
Goodwill

[0001327567-21-000029:notes:213]
The following table presents details of our goodwill during the year ended July 31, 2021 (in millions):

[0001327567-21-000029:notes:214]
|  | Amount |
| Balance as of July 31, 2020 | $ | 1,812.9 |  |
| Goodwill acquired | 899.1 |  |
| Measurement period adjustment | (1.9) |  |
| Balance as of July 31, 2021 | $ | 2,710.1 |  |

[0001327567-21-000029:notes:215]
Purchased Intangible Assets

[0001327567-21-000029:notes:216]
The following table presents details of our purchased intangible assets as of July 31, 2021 and July 31, 2020 (in millions):

[0001327567-21-000029:notes:217]
|  | July 31, |
|  | 2021 |  | 2020 |
|  | Gross Carrying Amount |  | Accumulated Amortization |  | Net Carrying Amount |  | Gross Carrying Amount |  | Accumulated Amortization |  | Net Carrying Amount |
| Intangible assets subject to amortization: |  |  |  |  |  |  |  |  |  |  |  |
| Developed technology | $ | 596.2 |  |  | $ | (243.8) |  |  | $ | 352.4 |  |  | $ | 425.9 |  |  | $ | (146.6) |  |  | $ | 279.3 |  |
| Customer relationships | 172.7 |  |  | (30.6) |  |  | 142.1 |  |  | 87.6 |  |  | (12.4) |  |  | 75.2 |  |
| Acquired intellectual property | 7.9 |  |  | (3.8) |  |  | 4.1 |  |  | 6.3 |  |  | (3.2) |  |  | 3.1 |  |
| Trade name and trademarks | 9.4 |  |  | (9.4) |  |  | — |  |  | 9.4 |  |  | (9.4) |  |  | — |  |
| Other | 1.8 |  |  | (1.8) |  |  | — |  |  | 3.1 |  |  | (2.5) |  |  | 0.6 |  |
| Total purchased intangible assets | $ | 788.0 |  |  | $ | (289.4) |  |  | $ | 498.6 |  |  | $ | 532.3 |  |  | $ | (174.1) |  |  | $ | 358.2 |  |

[0001327567-21-000029:notes:218]
We recognized amortization expense of $117.8 million, $77.3 million, and $53.6 million for the years ended July 31, 2021, 2020, and 2019, respectively.

[0001327567-21-000029:notes:219]
The following table summarizes estimated future amortization expense of our intangible assets as of July 31, 2021 (in millions):

[0001327567-21-000029:notes:220]
|  |  |  | Fiscal years ending July 31, |
|  | Total |  | 2022 |  | 2023 |  | 2024 |  | 2025 |  | 2026 |  | 2027 and Thereafter |
| Future amortization expense | $ | 498.6 |  |  | $ | 125.7 |  |  | $ | 99.6 |  |  | $ | 89.6 |  |  | $ | 75.9 |  |  | $ | 54.3 |  |  | $ | 53.5 |  |


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001327567-21-000029:notes:221]
Property and Equipment
The following table presents details of our property and equipment, net as of July 31, 2021 and July 31, 2020 (in millions):

[0001327567-21-000029:notes:222]
|  | July 31, |
|  | 2021 |  | 2020 |
| Computers, equipment, and software | $ | 352.1 |  |  | $ | 306.8 |  |
| Leasehold improvements | 231.6 |  |  | 229.5 |  |
| Land | 49.6 |  |  | 49.6 |  |
| Demonstration units | 43.8 |  |  | 43.3 |  |
| Furniture and fixtures | 40.3 |  |  | 39.9 |  |
| Total property and equipment, gross | 717.4 |  |  | 669.1 |  |
| Less: accumulated depreciation | (399.0) |  |  | (321.0) |  |
| Total property and equipment, net | $ | 318.4 |  |  | $ | 348.1 |  |

[0001327567-21-000029:notes:223]
We recognized depreciation expense of $94.2 million, $96.0 million, and $86.2 million related to property and equipment during the years ended July 31, 2021, 2020, and 2019, respectively.


## us-gaap:DebtDisclosureTextBlock

[0001327567-21-000029:notes:224]
Debt
Convertible Senior Notes

[0001327567-21-000029:notes:225]
In June 2014, we issued $575.0 million aggregate principal amount of 0.0% Convertible Senior Notes due 2019 (the “2019 Notes”), in July 2018, we issued $1.7 billion aggregate principal amount of 0.75% Convertible Senior Notes due 2023 (the “2023 Notes”) and, in June 2020, we issued $2.0 billion aggregate principal amount of 0.375% Convertible Senior Notes due 2025 (the “2025 Notes,” and together with the 2023 Notes, the “Notes”). The 2019 Notes were converted prior to or settled on the maturity date of July 1, 2019, in accordance with their terms. The 2023 Notes bear interest at a fixed rate of 0.75% per year, payable semi-annually in arrears on January 1 and July 1 of each year, beginning on January 1, 2019. The 2025 Notes bear interest at a fixed rate of 0.375% per year, payable semi-annually in arrears on June 1 and December 1 of each year, beginning on December 1, 2020. Each series of the convertible notes is governed by an indenture between us, as the issuer, and U.S. Bank National Association, as Trustee (individually, each an “Indenture,” and together, the “Indentures”). The Notes of each series are unsecured, unsubordinated obligations and the applicable Indenture governing each series of Notes does not contain any financial covenants or restrictions on the payments of dividends, the incurrence of indebtedness, or the issuance or repurchase of securities by us or any of our subsidiaries. The 2023 Notes and the 2025 Notes mature on July 1, 2023 and June 1, 2025, respectively. We cannot redeem the 2023 Notes prior to maturity. We may redeem for cash all or any portion of the 2025 Notes, at our option, on or after June 5, 2023, and prior to the 31st scheduled trading day immediately preceding the maturity date if the last reported sale price of our common stock has been at least 130% of the conversion price then in effect for at least 20 trading days during any 30 consecutive trading day period ending on and including the trading day preceding the date on which we provide notice of redemption. The redemption will be at a price equal to 100% of the principal amount of the 2025 Notes and adjusted for interest. If we call any or all of the 2025 Notes for redemption, holders may convert such 2025 Notes called for redemption at any time prior to the close of business on the second scheduled trading day immediately preceding the redemption date.

[0001327567-21-000029:notes:226]
The following table presents details of our Notes (number of shares in millions):

[0001327567-21-000029:notes:227]
|  | Conversion Rate per $1,000 Principal |  | Initial Conversion Price |  | Convertible Date |  | Initial Number of Shares |
| 2023 Notes | 3.7545 |  |  | $ | 266.35 |  |  | April 1, 2023 |  | 6.4 |  |
| 2025 Notes | 3.3602 |  |  | $ | 297.60 |  |  | March 1, 2025 |  | 6.7 |  |

[0001327567-21-000029:notes:228]
Holders of the Notes may surrender their Notes for conversion at their option at any time prior to the close of business on the business day immediately preceding their respective convertible dates only under the following circumstances:

[0001327567-21-000029:notes:229]
•during any fiscal quarter commencing after the fiscal quarters ending on October 31, 2018 and October 31, 2020 for the 2023 Notes and the 2025 Notes, respectively (and only during such fiscal quarter), if the last reported sale price of our common stock for at least 20 trading days (whether or not consecutive) during a period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the applicable conversion price for the respective Notes on each applicable trading day (the “sale price condition”);

[0001327567-21-000029:notes:230]
•during the five business day period after any five consecutive trading day period (the “measurement period”) in which the trading price per $1,000 principal amount of the applicable series of Notes for each trading day of the measurement period was less than 98% of the product of the last reported sale price of our common stock and the applicable conversion rate for the respective Notes on each such trading day; or

[0001327567-21-000029:notes:231]
•upon the occurrence of specified corporate events.

[0001327567-21-000029:notes:232]
On or after the respective convertible date, holders may surrender all or any portion of their Notes for conversion at any time prior to the close of business on the second scheduled trading day immediately preceding the applicable maturity date regardless of the foregoing conditions, and such conversions will be settled upon the applicable maturity date. Upon conversion, holders of the Notes of a series will receive cash equal to the aggregate principal amount of the Notes of such series to be converted, and, at our election, cash and/or shares of our common stock for any amounts in excess of the aggregate principal amount of the Notes of such series being converted.

[0001327567-21-000029:notes:233]
The conversion price will be subject to adjustment in some events. Holders of the Notes of a series who convert their Notes of such series in connection with certain corporate events that constitute a “make-whole fundamental change” under the applicable Indenture are, under certain circumstances, entitled to an increase in the conversion rate for such series of Notes. Additionally, upon the occurrence of a corporate event that constitutes a “fundamental change” under the applicable Indenture, holders of the Notes of such series may require us to repurchase for cash all or a portion of the Notes of such series at a repurchase price equal to 100% of the principal amount of the Notes of such series plus accrued and unpaid interest to, but excluding, the fundamental change repurchase date.

[0001327567-21-000029:notes:234]
The sale price condition was met for the 2023 Notes during the fiscal quarter ended July 31, 2021, and as a result, holders may convert their 2023 Notes at any time during the fiscal quarter ending October 31, 2021. Accordingly, the net carrying amount of the 2023 Notes was reclassified into current liabilities and the portion of the equity component representing the conversion option was reclassified into temporary equity in our consolidated balance sheet as of July 31, 2021.

[0001327567-21-000029:notes:235]
The sale price condition was not met for the 2025 Notes during the fiscal quarters ended July 31, 2021 or July 31, 2020, and was not met for the 2023 Notes during the fiscal quarter ended July 31, 2020. Since the 2025 Notes for both periods and the 2023 Notes as of July 31, 2020 were not convertible, the associated net carrying amount was classified as a long-term liability and the equity component was included in additional paid-in capital in our consolidated balance sheets.

[0001327567-21-000029:notes:236]
During the year ended July 31, 2019, we repaid $575.0 million in aggregate principal amount of the 2019 Notes and issued 2.5 million shares of common stock to the holders of the 2019 Notes for the conversion value in excess of the principal amount. These shares were fully offset by shares received from the corresponding exercise of the associated note hedges.

[0001327567-21-000029:notes:237]
The following table sets forth the components of the Notes as of July 31, 2021 and July 31, 2020 (in millions):

[0001327567-21-000029:notes:238]
|  |  |  | July 31, 2021 |  |  |  | July 31, 2020 |
|  |  |  | 2023 Notes |  | 2025 Notes |  | Total |  |  |  | 2023 Notes |  | 2025 Notes |  | Total |
| Liability component: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Principal |  |  | $ | 1,692.0 |  |  | $ | 2,000.0 |  |  | $ | 3,692.0 |  |  |  |  | $ | 1,693.0 |  |  | $ | 2,000.0 |  |  | $ | 3,693.0 |  |
| Less: debt discount and debt issuance costs, net of amortization |  |  | (134.1) |  |  | (331.9) |  |  | (466.0) |  |  |  |  | (200.0) |  |  | (408.9) |  |  | (608.9) |  |
| Net carrying amount |  |  | $ | 1,557.9 |  |  | $ | 1,668.1 |  |  | $ | 3,226.0 |  |  |  |  | $ | 1,493.0 |  |  | $ | 1,591.1 |  |  | $ | 3,084.1 |  |
| Equity component (including amounts classified as temporary equity) |  |  | $ | 315.0 |  |  | $ | 403.0 |  |  | $ | 718.0 |  |  |  |  | $ | 315.0 |  |  | $ | 403.0 |  |  | $ | 718.0 |  |

[0001327567-21-000029:notes:239]
The total estimated fair value of the Notes was $5.5 billion and $4.1 billion at July 31, 2021 and July 31, 2020, respectively. The fair value was determined based on the closing trading price per $100 of the Notes as of the last day of trading for the period. We consider the fair value of the Notes at July 31, 2021 and July 31, 2020 to be a Level 2 measurement. The fair value of the Notes is primarily affected by the trading price of our common stock and market interest rates. Based on the closing price of our common stock on July 31, 2021, the if-converted values of the 2023 Notes and 2025 Notes exceeded their principal amounts by $754.4 million and $587.8 million, respectively.

[0001327567-21-000029:notes:240]
The following table sets forth interest expense recognized related to our convertible senior notes (dollars in millions):

[0001327567-21-000029:notes:241]
|  |  |  | Year Ended July 31, 2021 |  | Year Ended July 31, 2020 |  | Year Ended July 31, 2019 |
|  |  |  | 2023 Notes |  | 2025 Notes |  | Total |  | 2023 Notes |  | 2025 Notes |  | Total |  | 2019 Notes |  | 2023 Notes |  | Total |
| Contractual interest expense |  |  | $ | 12.7 |  |  | $ | 7.5 |  |  | $ | 20.2 |  |  | $ | 12.7 |  |  | $ | 1.1 |  |  | $ | 13.8 |  |  | $ | — |  |  | $ | 12.7 |  |  | $ | 12.7 |  |
| Amortization of debt discount |  |  | 63.5 |  |  | 74.3 |  |  | 137.8 |  |  | 60.9 |  |  | 10.5 |  |  | 71.4 |  |  | 8.7 |  |  | 58.5 |  |  | 67.2 |  |
| Amortization of debt issuance costs |  |  | 2.3 |  |  | 2.8 |  |  | 5.1 |  |  | 2.1 |  |  | 0.4 |  |  | 2.5 |  |  | 1.1 |  |  | 1.9 |  |  | 3.0 |  |
| Total interest expense recognized |  |  | $ | 78.5 |  |  | $ | 84.6 |  |  | $ | 163.1 |  |  | $ | 75.7 |  |  | $ | 12.0 |  |  | $ | 87.7 |  |  | $ | 9.8 |  |  | $ | 73.1 |  |  | $ | 82.9 |  |
| Effective interest rate of the liability component |  |  | 5.2 | % |  | 5.4 | % |  |  |  | 5.2 | % |  | 5.4 | % |  |  |  | 4.8 | % |  | 5.2 | % |  |  |

[0001327567-21-000029:notes:242]
Note Hedges

[0001327567-21-000029:notes:243]
To minimize the impact of potential economic dilution upon conversion of our convertible senior notes, we entered into separate convertible note hedge transactions (the “2019 Note Hedges,” with respect to the 2019 Notes, the “2023 Note Hedges,” with respect to the 2023 Notes, the “2025 Note Hedges,” with respect to the 2025 Notes and the 2023 Notes Hedgers together with 2025 Note Hedges, the “Note Hedges”) with respect to our common stock concurrent with the issuance of each series of our convertible senior notes. Upon the settlement of the 2019 Notes, we exercised the corresponding portion of our 2019 Note Hedges during the year ended July 31, 2019 and received shares of our common stock that fully offset the shares issued in excess of the principal amount of the converted 2019 Notes. The 2019 Note Hedges expired upon maturity of the 2019 Notes.

[0001327567-21-000029:notes:244]
The following table presents details of our Note Hedges (in millions):

[0001327567-21-000029:notes:245]
|  | Initial Number of Shares |  | Aggregate Purchase |
| 2023 Note Hedges | 6.4 |  |  | $ | 332.0 |  |
| 2025 Note Hedges | 6.7 |  |  | $ | 370.8 |  |

[0001327567-21-000029:notes:246]
The Note Hedges cover shares of our common stock at a strike price per share that corresponds to the initial applicable conversion price of the applicable series of Notes, which are also subject to adjustment, and are exercisable upon conversion of the applicable series of the Notes. The Note Hedges will expire upon maturity of the applicable series of Notes. The Note Hedges are separate transactions and are not part of the terms of the applicable series of the Notes. Holders of the Notes of either series will not have any rights with respect to the Note Hedges. Any shares of our common stock receivable by us under the Note Hedges are

[0001327567-21-000029:notes:247]
excluded from the calculation of diluted earnings per share as they are antidilutive. The aggregate amounts paid for the Note Hedges are included in additional paid-in capital in our consolidated balance sheets.

[0001327567-21-000029:notes:248]
Warrants

[0001327567-21-000029:notes:249]
Separately, but concurrently with the issuance of each series of our convertible senior notes, we entered into transactions whereby we sold warrants (the “2019 Warrants,” with respect to the 2019 Notes, the “2023 Warrants,” with respect to the 2023 Notes, the “2025 Warrants,” with respect to the 2025 Notes, and the 2023 Warrants together with the 2025 Warrants, the “Warrants”) to acquire shares of our common stock, subject to anti-dilution adjustments. During the year ended July 31, 2020, we net settled all 2019 Warrants with 2.0 million shares or $462.0 million in fair value of our common stock. The 2023 Warrants and 2025 Warrants are exercisable beginning October 2023 and September 2025, respectively.

[0001327567-21-000029:notes:250]
The following table presents details of our Warrants (in millions, except per share data):

[0001327567-21-000029:notes:251]
|  | Initial Number of Shares |  | Strike Price per Share |  | Aggregate Proceeds |
| 2023 Warrants | 6.4 |  |  | $ | 417.80 |  |  | $ | 145.4 |  |
| 2025 Warrants | 6.7 |  |  | $ | 408.47 |  |  | $ | 202.8 |  |

[0001327567-21-000029:notes:252]
The shares issuable under the Warrants will be included in the calculation of diluted earnings per share when the average market value per share of our common stock for the reporting period exceeds the applicable strike price for such series of Warrants. The Warrants are separate transactions and are not part of either series of Notes or Note Hedges and are not remeasured through earnings each reporting period. Holders of the Notes of either series will not have any rights with respect to the Warrants. The aggregate proceeds received from the sale of the Warrants are included in additional paid-in capital in our consolidated balance sheets.

[0001327567-21-000029:notes:253]
Revolving Credit Facility

[0001327567-21-000029:notes:254]
On September 4, 2018, we entered into a credit agreement (the “Credit Agreement”) with certain institutional lenders that provides for a $400.0 million unsecured revolving credit facility (the “Credit Facility”), with an option to increase the amount of the Credit Facility by up to an additional $350.0 million, subject to certain conditions. The Credit Facility matures on the earlier of (i) September 4, 2023 and (ii) the date that is 91 days prior to the stated maturity of our 2023 Notes if (a) any of the 2023 Notes are still outstanding and (b) our unrestricted cash and cash equivalents are less than the then outstanding principal amount of our 2023 Notes plus $400.0 million.

[0001327567-21-000029:notes:255]
The borrowings under the Credit Facility currently bear interest, at our option, at a base rate plus a spread of 0.00% to 0.75%, or an adjusted LIBO Rate plus a spread of 1.00% to 1.75%, in each case with such spread being determined based on our leverage ratio. We are obligated to pay an ongoing commitment fee on undrawn amounts at a rate of 0.125% to 0.250%, depending on our leverage ratio. Regulatory authorities that oversee financial markets have announced that after the end of 2021, they would no longer compel banks currently reporting information used to set the LIBO Rate to continue to make rate submissions. As a result, it is possible that beginning in 2022, the LIBO Rate will no longer be available as a reference rate. Under the terms of our Credit Facility, in the event of the discontinuance of the LIBO Rate, a mutually agreed-upon alternative benchmark rate will be established to replace the LIBO Rate, which may include the Secured Overnight Financing Rate (“SOFR”). We do not anticipate that the discontinuance of the LIBO Rate will materially impact our liquidity or financial position.

[0001327567-21-000029:notes:256]
As of July 31, 2021, there were no amounts outstanding, and we were in compliance with all covenants under the Credit Agreement.


## us-gaap:LesseeOperatingLeasesTextBlock

[0001327567-21-000029:notes:257]
Leases
We have entered into various non-cancelable operating leases primarily for our facilities with original lease periods expiring through the year ending July 31, 2028, with the most significant leases relating to corporate headquarters in Santa Clara.

[0001327567-21-000029:notes:258]
In May 2015 and October 2015, we entered into a total of three lease agreements for approximately 941,000 square feet of corporate office space in Santa Clara, California, which serves as our current corporate headquarters. The leases contain rent holiday periods, scheduled rent increases, lease incentives, and renewal options which allow the lease terms to be extended beyond their expiration dates of July 2028 through July 2046. Rental payments under the three lease agreements are approximately $412.0 million over the lease term.

[0001327567-21-000029:notes:259]
In September 2012, we entered into two lease agreements for a total of approximately 300,000 square feet of space in Santa Clara, California, which served as our previous corporate headquarters through August 2017, when we relocated to our current corporate campus. The leases contain rent holiday periods and two separate five-year options to extend the lease term beyond their expiration dates of July 2023. Rental payments under these lease agreements are approximately $94.3 million over the lease term. In August 2017, we exited our previous corporate headquarter facilities and relocated to our new corporate campus, which resulted in the recognition of a cease-use loss of $39.2 million during the year ended July 31, 2018. Due to changes in market conditions, and the resulting changes to the amount and timing of estimated cash flows from sublease rentals that could be reasonably obtained, we recognized an additional cease-use loss of $7.0 million as general and administrative expense in our consolidated statements of operations during the year ended July 31, 2019. In December 2019, we terminated these leases prior to their expiration date. The early

[0001327567-21-000029:notes:260]
termination fee is $25.0 million, payable in equal quarterly installments from April 2020 through July 2023. Upon termination, we recorded a decrease of $13.6 million in operating lease liabilities based on the payment schedule of the early termination fee discounted by the incremental borrowing rate for the remaining payment term. We also decreased right-of-use assets by $8.7 million upon surrendering possession of the properties. As a result, during the year ended July 31, 2020, we recorded a gain of $3.1 million net of other related fees of $1.8 million in general and administrative expense in our consolidated statements of operations.

[0001327567-21-000029:notes:261]
During the years ended July 31, 2021 and July 31, 2020, our net cost for operating leases was $75.2 million and $80.4 million, respectively, primarily consisting of operating lease costs of $59.3 million and $63.5 million, respectively. Our net cost for operating leases also included variable lease costs, short-term lease costs and sublease income in both periods. We recognized rent expense of $43.0 million for the year ended July 31, 2019, prior to our adoption of the new lease guidance.

[0001327567-21-000029:notes:262]
The following tables present additional information for our operating leases (in millions, except for years and percentages):

[0001327567-21-000029:notes:263]
|  | Year Ended July 31, |  |  |  |  |  |  |
|  | 2021 |  | 2020 |  |  |  |  |  |  |
| Operating cash flows used in payments of operating lease liabilities | $ | 81.7 |  |  | $ | 78.3 |  |  |  |  |  |  |  |
| Right-of-use assets obtained in exchange for new operating lease liabilities | $ | 48.6 |  |  | $ | 28.4 |  |  |  |  |  |  |  |
|  | July 31, 2021 |  | July 31, 2020 |  |  |  |  |  |  |
| Weighted-average remaining lease term | 6.1 years |  | 7.0 years |  |  |  |  |  |  |
| Weighted-average discount rate | 3.8 | % |  | 3.9 | % |  |  |  |  |  |  |

[0001327567-21-000029:notes:264]
The following table presents maturities of operating lease liabilities as of July 31, 2021 (in millions):

[0001327567-21-000029:notes:265]
|  | Amount |
| Fiscal years ending July 31: |  |
| 2022 | $ | 78.8 |  |
| 2023 | 72.6 |  |
| 2024 | 61.6 |  |
| 2025 | 58.7 |  |
| 2026 | 57.4 |  |
| 2027 and thereafter | 97.5 |  |
| Total operating lease payments | 426.6 |  |
| Less: imputed interest | (47.4) |  |
| Present value of operating lease liabilities | $ | 379.2 |  |
| Current portion of operating lease liabilities(1) | $ | 65.8 |  |
| Long-term operating lease liabilities | $ | 313.4 |  |

[0001327567-21-000029:notes:266]
________________________

[0001327567-21-000029:notes:267]
(1)    Current portion of operating lease liabilities is included in accrued and other liabilities on our consolidated balance sheet.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001327567-21-000029:notes:268]
Commitments and Contingencies 
Manufacturing Purchase Commitments

[0001327567-21-000029:notes:269]
In order to reduce manufacturing lead times and plan for adequate supply, we enter into agreements with manufacturing partners and component suppliers to procure inventory based on our demand forecasts. We are committed to minimum or fixed purchases through the year ending July 31, 2026. The following table presents details of the aggregate future purchase commitments under these arrangements excluding obligations under contracts that we can cancel without a significant penalty as of July 31, 2021 (in millions):

[0001327567-21-000029:notes:270]
|  |  |  | Fiscal years ending July 31, |
|  | Total |  | 2022 |  | 2023 |  | 2024 |  | 2025 |  | 2026 |  |  |
| Manufacturing purchase commitments | $ | 359.9 |  |  | $ | 219.3 |  |  | $ | 35.6 |  |  | $ | 30.0 |  |  | $ | 35.0 |  |  | $ | 40.0 |  |  |  |

[0001327567-21-000029:notes:271]
Other Purchase Commitments

[0001327567-21-000029:notes:272]
We have entered into various non-cancelable agreements with certain service providers, under which we are committed to minimum or fixed purchases through the year ending July 31, 2026. The following table presents details of the aggregate future non-cancelable purchase commitments under these agreements as of July 31, 2021 (in millions):

[0001327567-21-000029:notes:273]
|  |  |  | Fiscal years ending July 31, |
|  | Total |  | 2022 |  | 2023 |  | 2024 |  | 2025 |  | 2026 |  |  |
| Other purchase commitments | $ | 1,471.8 |  |  | $ | 32.0 |  |  | $ | 241.3 |  |  | $ | 302.1 |  |  | $ | 345.3 |  |  | $ | 551.1 |  |  |  |

[0001327567-21-000029:notes:274]
Mutual Covenant Not to Sue and Release Agreement

[0001327567-21-000029:notes:275]
In January 2020, we executed a Mutual Covenant Not to Sue and Release Agreement for $50.0 million to extend an existing covenant not to sue for seven years. As the primary benefit of the arrangement was attributable to future use, the amount was recorded in other assets on our consolidated balance sheets and is amortized to cost of product revenue in our consolidated statements of operations over the estimated period of benefit of seven years.

[0001327567-21-000029:notes:276]
Litigation

[0001327567-21-000029:notes:277]
We are subject to legal proceedings, claims, and litigation arising in the ordinary course of business, including intellectual property litigation. Such matters are subject to many uncertainties and outcomes are not predictable with assurance. We accrue for contingencies when we believe that a loss is probable and that we can reasonably estimate the amount of any such loss.

[0001327567-21-000029:notes:278]
To the extent there is a reasonable possibility that a loss exceeding amounts already recognized may be incurred and the amount of such additional loss would be material, we will either disclose the estimated additional loss or state that such an estimate cannot be made. As of July 31, 2021, we have not recorded any significant accruals for loss contingencies associated with such legal proceedings, determined that an unfavorable outcome is probable or reasonably possible, or determined that the amount or range of any possible loss is reasonably estimable.

[0001327567-21-000029:notes:279]
Indemnification

[0001327567-21-000029:notes:280]
Under the indemnification provisions of our standard sales related contracts, we agree to defend our end-customers against third-party claims asserting infringement of certain intellectual property rights, which may include patents, copyrights, trademarks, or trade secrets, and to pay judgments entered on such claims. Our exposure under these indemnification provisions is generally limited to payments made to us for the alleged infringing products over the preceding twelve months under the agreement. However, certain agreements include indemnification provisions that could potentially expose us to losses in excess of these payments. In addition, we indemnify our officers, directors, and certain key employees while they are serving in good faith in their company capacities. To date, we have not recorded any accruals for loss contingencies associated with indemnification claims or determined that an unfavorable outcome is probable or reasonably possible.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001327567-21-000029:notes:281]
Stockholders’ Equity 
Share Repurchase Program

[0001327567-21-000029:notes:282]
In August 2016, our board of directors authorized a $500.0 million share repurchase program and in February 2017 authorized a $500.0 million increase to the repurchase program, bringing the total authorization to $1.0 billion (our “original authorization”). This repurchase program expired on December 31, 2018. In February 2019, our board of directors authorized a $1.0 billion share repurchase program and in December 2020 authorized a $700.0 million increase to this share repurchase program, bringing the total authorization to $1.7 billion (our “current authorization”). The expiration date of our current authorization was extended to December 31, 2021, and our repurchase program may be suspended or discontinued at any time. Repurchases may be made at management’s discretion from time to time on the open market, through privately negotiated transactions, transactions structured through investment banking institutions, block purchase techniques, 10b5-1 trading plans, or a combination of the foregoing.

[0001327567-21-000029:notes:283]
During the year ended July 31, 2019, we repurchased and retired 1.9 million shares of our common stock under our original authorization for an aggregate purchase price of $330.0 million and an average price per share of $177.64, including transaction costs.

[0001327567-21-000029:notes:284]
During the years ended July 31, 2021 and 2020, we repurchased and retired 4.0 million shares and 0.9 million shares of our common stock under our current authorization for an aggregate purchase price of $1.2 billion and $198.1 million, and an average price per share of $294.87 and $209.12, respectively, including transaction costs. As of July 31, 2021, we have $323.9 million remaining for future share repurchases under our current repurchase authorization. The total price of the shares repurchased and related transaction costs are reflected as a reduction to common stock and additional paid-in capital on our consolidated balance sheets.

[0001327567-21-000029:notes:285]
Accelerated Stock Repurchase

[0001327567-21-000029:notes:286]
In February 2020, our board of directors approved the repurchase of $1.0 billion of our common stock through an accelerated share repurchase (“ASR”) transaction with a financial institution. This ASR transaction was in addition to our share repurchase program. 
During the fiscal year ended July 31, 2020, we completed the ASR transaction with an aggregate of 5.2 million shares of our common stock repurchased and retired. The total price of the ASR transaction is reflected as a reduction to common stock and additional paid-in capital on our consolidated balance sheet.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001327567-21-000029:notes:287]
Equity Award Plans 
Share-Based Compensation Plans

[0001327567-21-000029:notes:288]
2012 Equity Incentive Plan

[0001327567-21-000029:notes:289]
Our 2012 Equity Incentive Plan (our “2012 Plan”) was adopted by our board of directors and approved by the stockholders on June 5, 2012 and was effective one business day prior to the effectiveness of our registration statement for our initial public offering (“IPO”). Our 2012 Plan replaced our 2005 Equity Incentive Plan (our “2005 Plan”), which terminated upon the completion of our IPO, however, awards that were outstanding upon termination remained outstanding pursuant to their original terms. Our 2012 Plan provides for the granting of stock options, restricted stock award (“RSA”), restricted stock unit (“RSU”), stock appreciation rights, performance shares (“PSAs”), performance-based stock units (“PSUs”) and performance stock options (“PSOs”) to our employees, directors, and consultants.

[0001327567-21-000029:notes:290]
Awards granted under our 2012 Plan vest over the periods determined by the board of directors, generally three to four years from the date of grant, and our options expire no more than ten years after the date of grant. Since our IPO in 2012, awards granted under our 2012 Plan consist primarily of RSUs. Until vested, RSUs do not have the voting and dividend participation rights of common stock and the shares underlying the awards are not considered issued and outstanding.

[0001327567-21-000029:notes:291]
We grant awards with performance conditions (PSAs and PSUs) to certain employees, which vest over a period of one to four years from the date of grant. The actual number of PSAs and PSUs earned and eligible to vest is determined based on the level of achievement against revenue growth, pre-established billings and operating margin goals, or pre-defined individual performance targets for the fiscal year.

[0001327567-21-000029:notes:292]
We have also granted PSOs with both a market condition and a service condition to certain executives. The market condition for PSOs granted in the fiscal years 2018 and 2019 requires the price of our common stock to equal or exceed $297.75, $397.00, $496.25, and $595.50 based on the average closing price for 30 consecutive trading days during the four-, five-, six-, and seven-and-a-half-year periods following the date of grant in fiscal year 2018 and 2019, respectively. The market condition for PSOs granted in the fiscal year 2021 requires the price of our common stock to equal or exceed $397.00, $496.25, $595.50 and $700.00 based on the average closing price for 30 consecutive trading days during the three-, four-, five-, and six-and-a-half-year periods following the date of grant. To the extent that the market condition has been met, one-fourth of the PSOs will vest on the anniversary date of the grant date for such PSOs, subject to continued service. Certain outstanding PSOs may be exercised prior to vesting (“early exercise”). Shares of common stock issued upon early exercise of the PSOs will be restricted and, at our option, subject to repurchase if the option holder ceases to be a service provider. The maximum contractual term of our PSOs ranged from six and a half years to seven and a half years from the date of grant, depending on vesting period. During the fiscal year ended July 31, 2021, 0.4 million shares of our PSOs vested as the first stock price target for our PSOs granted in fiscal years 2018 and 2019 was satisfied and the service condition was met.

[0001327567-21-000029:notes:293]
We net-share settle equity awards held by certain employees by withholding shares upon vesting to satisfy tax withholding obligations. The shares withheld to satisfy employee tax withholding obligations are returned to our 2012 Plan and will be available for future issuance. Payments for employees’ tax obligations to the tax authorities are recognized as a reduction to additional paid-in capital and reflected as financing activities in our consolidated statements of cash flows.

[0001327567-21-000029:notes:294]
A total of 21.9 million shares of our common stock are reserved for issuance pursuant to our 2012 Plan as of July 31, 2021. This includes shares that are (i) reserved but unissued under our 2005 Plan on the effective date of our 2012 Plan or (ii) returned to our 2005 Plan as a result of expiration or termination of options. On the first day of each fiscal year, the number of shares in the reserve may be increased by the lesser of (i) 8,000,000 shares, (ii) 4.5% of the outstanding shares of common stock on the last day of our immediately preceding fiscal year, or (iii) such other amount as determined by our board of directors.

[0001327567-21-000029:notes:295]
2012 Employee Stock Purchase Plan

[0001327567-21-000029:notes:296]
Our 2012 Employee Stock Purchase Plan was adopted by our board of directors and approved by the stockholders on June 5, 2012, and was effective upon completion of our IPO. On August 29, 2017, we amended and restated our 2012 Employee Stock Purchase Plan (our “2012 ESPP”) to extend the length of our offering periods from 6 to 24 months.

[0001327567-21-000029:notes:297]
Our 2012 ESPP permits eligible employees to acquire shares of our common stock at 85% of the lower of the fair market value of our common stock on the first trading day of each offering period or on the purchase date. If the fair market value of our common stock on the purchase date is lower than the first trading day of the offering period, the current offering period will be cancelled after purchase and a new 24-month offering period will begin. Under our 2012 ESPP, each 24-month offering period consists of four consecutive 6-month purchase periods, with purchase dates on the first trading day on or after February 28 and August 31 of each year. Participants may purchase shares of common stock through payroll deductions of up to 15% of their eligible compensation, subject to purchase limits of 625 shares per six-month purchase period and $25,000 worth of stock for each calendar year. Shares

[0001327567-21-000029:notes:298]
purchased under our 2012 ESPP during the fiscal years ended July 31, 2021, 2020 and 2019 were 0.6 million, 0.6 million and 0.5 million, at an average exercise price of $161.07 per share, $146.90 per share and $128.81 per share respectively.

[0001327567-21-000029:notes:299]
A total of 4.6 million shares of our common stock are available for sale under our 2012 ESPP as of July 31, 2021. On the first day of each fiscal year, the number of shares in the reserve may be increased by the lesser of (i) 2,000,000 shares, (ii) 1% of the outstanding shares of our common stock on the first day of the fiscal year, or (iii) such other amount as determined by our board of directors.

[0001327567-21-000029:notes:300]
Acquisition-related Activities

[0001327567-21-000029:notes:301]
Assumed Share-based Compensation Plans

[0001327567-21-000029:notes:302]
In connection with our acquisitions of Bridgecrew, Expanse, Sinefa and Crypsis during the year ended July 31, 2021, we assumed the Bridgecrew, Inc. 2019 Stock Incentive Plan, the Expanse Holding Company, Inc. Amended and Restated 2012 Stock Incentive Plan, the Sinefa Group, Inc. 2020 Stock Plan, and the Crypsis Group Holdings, LLC 2017 Equity Incentive Plan (together, the “2021 assumed Plans”). In connection with our acquisitions of CloudGenix, Aporeto, and Zingbox during the year ended July 31, 2020, we assumed CloudGenix’s 2013 Equity Incentive Plan, Aporeto’s Amended and Restated 2015 Stock Option and Grant Plan and Zingbox’s Stock Incentive Plan, as amended and restated (together, the “2020 assumed Plans”). In connection with our acquisitions of RedLock, Demisto, and Twistlock during the year ended July 31, 2019, we assumed RedLock’s 2015 Stock Plan, as amended, Demisto’s 2015 Stock Option Plan, as amended, and Twistlock’s 2015 Share Option Plan, as amended and restated (together, the “2019 assumed Plans”). In aggregate, the 2021 assumed Plans, the 2020 assumed Plans and the 2019 assumed plans are referenced as “the Assumed Plans.”

[0001327567-21-000029:notes:303]
The equity awards assumed in connection with each acquisition were granted from their respective assumed plans. The assumed equity awards will be settled in shares of our common stock and will retain the terms and conditions under which they were originally granted. No additional equity awards will be granted under and forfeited awards will not be returned to the Assumed Plans. Refer to Note 7. Acquisitions for more information on our acquisitions and the related equity awards assumed.

[0001327567-21-000029:notes:304]
Restricted Stock Issuances

[0001327567-21-000029:notes:305]
In connection with our acquisitions of Expanse and Sinefa during the year ended July 31, 2021, we issued a total of 0.3 million shares of restricted common stock as replacement equity awards which are subject to additional time-based vesting requirements and continued service by the award holder.

[0001327567-21-000029:notes:306]
In connection with our acquisition of Zingbox during the year ended July 31, 2020, we issued a total of 0.1 million shares of restricted common stock as replacement equity awards which are subject to additional time-based vesting requirements and continued service by the award holder.

[0001327567-21-000029:notes:307]
In connection with our acquisitions of RedLock, Demisto, PureSec, and Twistlock during the year ended July 31, 2019, we issued a total of 0.5 million shares of restricted common stock as replacement equity awards which are subject to additional time-based vesting requirements and continued service by the award holder.

[0001327567-21-000029:notes:308]
Stock Option Activities

[0001327567-21-000029:notes:309]
The following table summarizes the stock option and PSO activity under our stock plans during the years ended July 31, 2021, 2020, and 2019 (in millions, except per share amounts):

[0001327567-21-000029:notes:310]
|  | Stock Options Outstanding |  | PSOs Outstanding |
|  | Number of Shares |  | Weighted-Average Exercise Price Per Share |  | Weighted-Average Remaining Contractual Term(Years) |  | Aggregate Intrinsic Value |  | Number of Shares |  | Weighted-Average Exercise Price Per Share |  | Weighted-Average Remaining Contractual Term(Years) |  | Aggregate Intrinsic Value |
| Balance—July 31, 2018 | 1.0 |  |  | $ | 13.28 |  |  | 3.1 |  | $ | 199.8 |  |  | 1.2 |  |  | $ | 198.50 |  |  | 7.0 |  | $ | — |  |
| Granted | — |  |  | $ | — |  |  |  |  |  |  | 2.6 |  |  | $ | 191.97 |  |  |  |  |  |
| Exercised | (0.7) |  |  | $ | 12.61 |  |  |  |  |  |  | — |  |  | $ | — |  |  |  |  |  |
| Forfeited | 0.0 |  |  | $ | 1.24 |  |  |  |  |  |  | (0.1) |  |  | $ | 193.51 |  |  |  |  |  |
| Balance—July 31, 2019 | 0.3 |  |  | $ | 14.53 |  |  | 2.2 |  | $ | 81.4 |  |  | 3.7 |  |  | $ | 193.99 |  |  | 6.2 |  | $ | 120.1 |  |
| Exercised | (0.2) |  |  | $ | 11.46 |  |  |  |  |  |  | — |  |  | $ | — |  |  |  |  |  |
| Forfeited | — |  |  | $ | — |  |  |  |  |  |  | (0.9) |  |  | $ | 193.51 |  |  |  |  |  |
| Balance—July 31, 2020 | 0.1 |  |  | $ | 19.59 |  |  | 1.5 |  | $ | 34.2 |  |  | 2.8 |  |  | $ | 194.14 |  |  | 5.2 |  | $ | 170.9 |  |
| Granted | — |  |  | $ | — |  |  |  |  |  |  | 0.2 |  |  | $ | 304.29 |  |  |  |  |  |
| Exercised | 0.0 |  |  | $ | 12.82 |  |  |  |  |  |  | — |  |  | $ | — |  |  |  |  |  |
| Forfeited | 0.0 |  |  | $ | 7.84 |  |  |  |  |  |  | (0.2) |  |  | $ | 304.29 |  |  |  |  |  |
| Balance—July 31, 2021 | 0.1 |  |  | $ | 26.20 |  |  | 0.8 |  | $ | 27.4 |  |  | 2.8 |  |  | $ | 194.14 |  |  | 4.2 |  | $ | 566.8 |  |
| Exercisable—July 31, 2021 | 0.1 |  |  | $ | 26.20 |  |  | 0.8 |  | $ | 27.4 |  |  | 2.8 |  |  | $ | 194.14 |  |  | 4.2 |  | $ | 566.8 |  |

[0001327567-21-000029:notes:311]
The weighted-average grant-date fair value of PSOs granted during the years ended July 31, 2021 and 2019 was $82.12 and $59.11, per share, respectively. The intrinsic value of options exercised during the years ended July 31, 2021, 2020, and 2019 was $22.2 million, $50.2 million and $139.5 million, respectively.

[0001327567-21-000029:notes:312]
RSA and PSA Activities

[0001327567-21-000029:notes:313]
The following table summarizes the RSA and PSA activity under our stock plans during the years ended July 31, 2021, 2020, and 2019 (in millions, except per share amounts):

[0001327567-21-000029:notes:314]
|  | RSAs Outstanding |  | PSAs Outstanding |
|  | Number of Shares |  | Weighted- Average Grant-Date Fair Value Per Share |  | Number of Shares |  | Weighted- Average Grant-Date Fair Value Per Share |
| Balance—July 31, 2018 | 0.2 |  |  | $ | 163.14 |  |  | 0.1 |  |  | $ | 148.54 |  |
| Vested | (0.2) |  |  | $ | 166.83 |  |  | 0.0 |  |  | $ | 148.54 |  |
| Forfeited | 0.0 |  |  | $ | 152.09 |  |  | 0.0 |  |  | $ | 148.54 |  |
| Balance—July 31, 2019 | 0.0 |  |  | $ | 148.54 |  |  | 0.1 |  |  | $ | 148.54 |  |
| Vested | 0.0 |  |  | $ | 148.54 |  |  | 0.0 |  |  | $ | 148.54 |  |
| Forfeited | 0.0 |  |  | $ | 148.54 |  |  | 0.0 |  |  | $ | 148.54 |  |
| Balance—July 31, 2020 | 0.0 |  |  | $ | 148.54 |  |  | 0.1 |  |  | $ | 148.54 |  |
| Vested | 0.0 |  |  | $ | 148.54 |  |  | (0.1) |  |  | $ | 148.54 |  |
| Forfeited | 0.0 |  |  | $ | 148.54 |  |  | 0.0 |  |  | $ | 148.54 |  |
| Balance—July 31, 2021 | — |  |  | $ | — |  |  | — |  |  | $ | — |  |

[0001327567-21-000029:notes:315]
The aggregate fair value, as of respective vesting dates, of RSAs vested during the years ended July 31, 2021, 2020 and 2019, was $1.6 million, $7.0 million and $41.1 million, respectively. The aggregate fair value, as of the respective vesting dates, of PSAs vested during the years ended July 31, 2021, 2020, and 2019 was $0.8 million, $3.8 million and $4.5 million, respectively.

[0001327567-21-000029:notes:316]
RSU and PSU Activities

[0001327567-21-000029:notes:317]
The following table summarizes the RSU and PSU activity under our stock plans during the years ended July 31, 2021, 2020, and 2019 (in millions, except per share amounts):

[0001327567-21-000029:notes:318]
|  | RSUs Outstanding |  | PSUs Outstanding |
|  | Number of Shares |  | Weighted- Average Grant-Date Fair Value Per Share |  |  |  | Aggregate Intrinsic Value |  | Number of Shares |  | Weighted- Average Grant-Date Fair Value Per Share |  |  |  | Aggregate Intrinsic Value |
| Balance—July 31, 2018 | 6.5 |  |  | $ | 160.70 |  |  |  |  | $ | 1,291.4 |  |  | 0.2 |  |  | $ | 149.73 |  |  |  |  | $ | 43.7 |  |
| Granted(1)(2) | 3.9 |  |  | $ | 210.14 |  |  |  |  |  |  | 0.2 |  |  | $ | 215.64 |  |  |  |  |  |
| Vested(3) | (2.7) |  |  | $ | 160.87 |  |  |  |  |  |  | (0.1) |  |  | $ | 149.73 |  |  |  |  |  |
| Forfeited | (0.8) |  |  | $ | 162.73 |  |  |  |  |  |  | 0.0 |  |  | $ | 155.38 |  |  |  |  |  |
| Balance—July 31, 2019 | 6.9 |  |  | $ | 188.16 |  |  |  |  | $ | 1,554.0 |  |  | 0.3 |  |  | $ | 197.86 |  |  |  |  | $ | 67.0 |  |
| Granted(1)(2) | 3.5 |  |  | $ | 211.38 |  |  |  |  |  |  | 0.4 |  |  | $ | 248.55 |  |  |  |  |  |
| Vested(3) | (2.8) |  |  | $ | 181.19 |  |  |  |  |  |  | (0.1) |  |  | $ | 166.90 |  |  |  |  |  |
| Forfeited | (1.0) |  |  | $ | 188.18 |  |  |  |  |  |  | 0.0 |  |  | $ | 175.88 |  |  |  |  |  |
| Balance—July 31, 2020 | 6.6 |  |  | $ | 203.30 |  |  |  |  | $ | 1,688.1 |  |  | 0.6 |  |  | $ | 231.42 |  |  |  |  | $ | 147.2 |  |
| Granted(1)(2) | 4.1 |  |  | $ | 297.89 |  |  |  |  |  |  | 0.8 |  |  | $ | 321.45 |  |  |  |  |  |
| Vested(3) | (2.9) |  |  | $ | 200.91 |  |  |  |  |  |  | (0.1) |  |  | $ | 195.60 |  |  |  |  |  |
| Forfeited | (0.9) |  |  | $ | 226.79 |  |  |  |  |  |  | 0.0 |  |  | $ | 235.98 |  |  |  |  |  |
| Balance—July 31, 2021 | 6.9 |  |  | $ | 257.56 |  |  |  |  | $ | 2,760.2 |  |  | 1.3 |  |  | $ | 292.93 |  |  |  |  | $ | 498.4 |  |

[0001327567-21-000029:notes:319]
______________

[0001327567-21-000029:notes:320]
(1)    For PSUs, shares granted represent the aggregate maximum number of shares that may be earned and issued with respect to these awards over their full terms.

[0001327567-21-000029:notes:321]
(2)    Includes 0.4 million RSUs assumed in connection with the acquisitions of Crypsis, Sinefa, Expanse and Bridgecrew, with weighted-average grant-date fair value of $241.43, $297.17, $317.45, $354.66, respectively, for the year ended July 31, 2021 and 0.1 million RSUs assumed in connection with the acquisitions of Zingbox, Aporeto and CloudGenix, with weighted-average grant-date fair value of $208.25, $231.30 and $181.48, respectively, for the year ended July 31, 2020. It also

[0001327567-21-000029:notes:322]
includes 0.4 million RSUs assumed and 0.1 million replacement RSUs granted in connection with the acquisitions of RedLock, Demisto, PureSec, and Twistlock, with weighted-average grant-date fair values of $218.69 and $224.31 per share, respectively, for the year ended July 31, 2019.

[0001327567-21-000029:notes:323]
(3)    Includes time-based vesting for PSUs.

[0001327567-21-000029:notes:324]
The aggregate fair value, as of the respective vesting dates, of RSUs vested during the years ended July 31, 2021, 2020, and 2019 was $986.4 million, $615.7 million, and $566.4 million, respectively. The aggregate fair value, as of the respective vesting dates, of PSUs vested during the year ended July 31, 2021, 2020 and 2019 was $20.8 million, $11.9 million and $17.2 million, respectively.

[0001327567-21-000029:notes:325]
Shares Available for Grant

[0001327567-21-000029:notes:326]
The following table presents the stock activity and the total number of shares available for grant under our stock plans as of July 31, 2021 (in millions):

[0001327567-21-000029:notes:327]
|  | Number of shares |
| Balance—July 31, 2020 | 10.5 |  |
| Authorized | 4.7 |  |
| PSOs, RSUs, and PSUs granted | (5.1) |  |
| Options, PSOs, RSAs, PSAs, RSUs, and PSUs forfeited | 1.1 |  |
| Shares withheld for taxes | 0.1 |  |
| Balance—July 31, 2021 | 11.3 |  |

[0001327567-21-000029:notes:328]
We record share-based compensation awards based on estimated fair value as of the grant date. The fair value of RSUs, PSUs, RSAs, and PSAs is based on the closing market price of our common stock on the date of grant.

[0001327567-21-000029:notes:329]
The fair value of PSOs is estimated on the grant date using a Monte Carlo simulation model, which predicts settlement of the options midway between the vesting term and the contractual term. No PSOs were granted during the year ended July 31, 2020. The following table summarizes the assumptions used and the resulting grant-date fair values of our PSOs granted during the years ended July 31, 2021 and 2019:

[0001327567-21-000029:notes:330]
|  | Year Ended July 31, |
|  | 2021 |  |  |  | 2019 |
| Volatility | 35.9 | % |  |  |  | 35.6% - 36.5% |
| Dividend yield | —% |  |  |  | — | % |
| Risk-free interest rate | 0.6 | % |  |  |  | 3.1% - 3.2% |
| Weighted-average grant-date fair value per share | $ | 82.12 |  |  |  |  | $ | 59.11 |  |

[0001327567-21-000029:notes:331]
The expected volatility is based on a combination of implied volatility from traded options on our common stock and the historical volatility of our common stock. The dividend yield assumption is based on our current expectations about our anticipated dividend policy. The risk-free interest rate is based on the implied yield available on U.S. Treasury zero-coupon issues with terms equal to the contractual terms of each tranche.

[0001327567-21-000029:notes:332]
The fair value of shares issued under our 2012 ESPP are estimated on the grant date using the Black-Scholes option pricing model. The following table summarizes the assumptions used and the resulting grant-date fair values of our ESPP:

[0001327567-21-000029:notes:333]
|  | Year Ended July 31, |
|  | 2021 |  | 2020 |  | 2019 |
| Volatility | 34.9% - 42.6% |  | 31.0% - 35.7% |  | 30.0% - 34.5% |
| Expected term (in years) | 0.5 - 2.0 |  | 0.5 - 2.0 |  | 0.5 - 2.0 |
| Dividend yield | — | % |  | — | % |  | — | % |
| Risk-free interest rate | 0.1% |  | 0.9% - 1.9% |  | 2.3% - 2.6% |
| Grant-date fair value per share | $69.48 - $129.05 |  | $46.75 - $66.47 |  | $55.03 - $87.04 |

[0001327567-21-000029:notes:334]
The expected volatility is based on a combination of implied volatility from traded options on our common stock and the historical volatility of our common stock. The expected term represents the term from the first day of the offering period to the purchase dates within each offering period. The dividend yield assumption is based on our expectations about our anticipated dividend

[0001327567-21-000029:notes:335]
policy. The risk-free interest rate is based on the implied yield available on U.S. Treasury zero-coupon issues with maturities that approximate the expected term.

[0001327567-21-000029:notes:336]
The following table summarizes share-based compensation included in costs and expenses (in millions):

[0001327567-21-000029:notes:337]
|  | Year Ended July 31, |
|  | 2021 |  | 2020 |  | 2019 |
| Cost of product revenue | $ | 6.2 |  |  | $ | 5.7 |  |  | $ | 5.6 |  |
| Cost of subscription and support revenue | 93.0 |  |  | 77.7 |  |  | 71.3 |  |
| Research and development | 428.9 |  |  | 274.6 |  |  | 186.8 |  |
| Sales and marketing | 269.9 |  |  | 214.5 |  |  | 221.9 |  |
| General and administrative | 128.9 |  |  | 92.0 |  |  | 102.1 |  |
| Total share-based compensation | $ | 926.9 |  |  | $ | 664.5 |  |  | $ | 587.7 |

[0001327567-21-000029:notes:338]
During the year ended July 31, 2021, we accelerated the vesting of certain equity awards in connection with our acquisitions of Bridgecrew, Expanse, Sinefa and Crypsis and recorded $9.8 million, $5.7 million, $9.8 million and $7.1 million, respectively. During the year ended July 31, 2020, we accelerated the vesting of certain equity awards in connection with our acquisitions of Zingbox, Aporeto and CloudGenix and recorded $1.3 million, $4.4 million and $0.3 million, respectively, and during the year ended July 31, 2019, we accelerated the vesting of certain equity awards in connection with our acquisitions of RedLock and Twistlock and recorded $14.2 million and $5.8 million, respectively, of share-based compensation within general and administrative expense.

[0001327567-21-000029:notes:339]
As of July 31, 2021, total compensation cost related to unvested share-based awards not yet recognized was $2.0 billion. This cost is expected to be amortized over a weighted-average period of approximately 2.6 years. Future grants will increase the amount of compensation expense to be recorded in these periods.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001327567-21-000029:notes:340]
Income Taxes 
The following table presents the components of income (loss) before income taxes (in millions):

[0001327567-21-000029:notes:341]
|  | Year Ended July 31, |
|  | 2021 |  | 2020 |  | 2019 |
| United States | $ | (482.2) |  |  | $ | (56.1) |  |  | $ | (198.1) |  |
| Foreign | 17.2 |  |  | (175.7) |  |  | 123.5 |  |
| Total | $ | (465.0) |  |  | $ | (231.8) |  |  | $ | (74.6) |  |

[0001327567-21-000029:notes:342]
The following table summarizes our provision for income taxes (in millions):

[0001327567-21-000029:notes:343]
|  | Year Ended July 31, |
|  | 2021 |  | 2020 |  | 2019 |
| Federal: |  |  |  |  |  |
| Current | $ | 3.3 |  |  | $ | 3.8 |  |  | $ | (1.3) |  |
| Deferred | (5.9) |  |  | (1.3) |  |  | (11.3) |  |
| State: |  |  |  |  |  |
| Current | 1.7 |  |  | 1.3 |  |  | (0.9) |  |
| Deferred | 0.1 |  |  | 0.1 |  |  | (3.0) |  |
| Foreign: |  |  |  |  |  |
| Current | 41.3 |  |  | 39.2 |  |  | 27.5 |  |
| Deferred | (6.6) |  |  | (7.9) |  |  | (3.7) |  |
| Total | $ | 33.9 |  |  | $ | 35.2 |  |  | $ | 7.3 |  |

[0001327567-21-000029:notes:344]
For the year ended July 31, 2021, our provision for income taxes decreased slightly compared to the year ended July 31, 2020, primarily due to tax benefits from changes in our valuation allowances.

[0001327567-21-000029:notes:345]
For the year ended July 31, 2020, our provision for income taxes increased compared to the year ended July 31, 2019, primarily due to an increase in foreign income as a result of increased business operations and withholding taxes from an increase in billings in the relevant jurisdictions. We also had a change in our valuation allowance related to acquisitions completed during fiscal 2019.

[0001327567-21-000029:notes:346]
The following table presents the items accounting for the difference between income taxes computed at the federal statutory income tax rate and our provision for income taxes:

[0001327567-21-000029:notes:347]
|  | Year Ended July 31, |
|  | 2021 |  | 2020 |  | 2019 |
| Federal statutory rate | 21.0 | % |  | 21.0 | % |  | 21.0 | % |
| Effect of: |  |  |  |  |  |
| State taxes, net of federal tax benefit | 1.3 |  |  | 3.0 |  |  | 7.9 |  |
| Effects of non-U.S. operations | (3.1) |  |  | 667.5 |  |  | 89.3 |  |
| Change in valuation allowance | (40.7) |  |  | (714.1) |  |  | (196.9) |  |
| Effect of U.S. tax law change | — |  |  | — |  |  | 0.6 |  |
| Share-based compensation | 5.0 |  |  | (5.1) |  |  | 44.9 |  |
| Tax credits | 9.9 |  |  | 17.9 |  |  | 35.0 |  |
| Non-deductible expenses | (1.3) |  |  | (3.9) |  |  | (11.5) |  |
| Other, net | 0.6 |  |  | (1.5) |  |  | (0.1) |  |
| Total | (7.3) | % |  | (15.2) | % |  | (9.8) | % |

[0001327567-21-000029:notes:348]
In fiscal 2020, we transferred certain intellectual property rights to a wholly owned United Kingdom subsidiary, primarily to align our legal structure to our evolving operations. The tax benefit from an increase in the tax basis of intellectual property rights resulted in an increase in effects of non-U.S. operations and was fully offset by a full valuation.

[0001327567-21-000029:notes:349]
The following table presents the components of our deferred tax assets and liabilities as of July 31, 2021 and July 31, 2020 (in millions):

[0001327567-21-000029:notes:350]
|  | July 31, |
|  | 2021 |  | 2020 |
| Deferred tax assets: |  |  |  |
| Accruals and reserves | $ | 125.0 |  |  | $ | 116.5 |  |
| Deferred revenue | 364.9 |  |  | 272.5 |  |
| Net operating loss carryforwards | 575.9 |  |  | 348.0 |  |
| Tax credits | 230.8 |  |  | 179.6 |  |
| Share-based compensation | 53.9 |  |  | 33.7 |  |
| Fixed assets and intangible assets | 1,789.6 |  |  | 1,458.8 |  |
| Gross deferred tax assets | 3,140.1 |  |  | 2,409.1 |  |
| Valuation allowance | (2,933.3) |  |  | (2,240.4) |  |
| Total deferred tax assets | 206.8 |  |  | 168.7 |  |
| Deferred tax liabilities: |  |  |  |
| Deferred commissions | (165.4) |  |  | (130.8) |  |
| Other deferred tax liabilities | (32.3) |  |  | (28.9) |  |
| Total deferred tax liabilities | (197.7) |  |  | (159.7) |  |
| Net deferred tax assets | $ | 9.1 |  |  | $ | 9.0 |  |

[0001327567-21-000029:notes:351]
Our increase in deferred tax assets relating to net operating losses and fixed assets and intangible assets is largely due to an impact from the United Kingdom tax rate increase from 19% to 25% effective April 1, 2023. As of July 31, 2021, it is not more likely than not that our deferred tax assets will be realizable, and therefore, are offset by a full valuation allowance.

[0001327567-21-000029:notes:352]
A valuation allowance is provided when it is more likely than not that the deferred tax asset will not be realized. Realization of deferred tax assets is dependent upon future taxable income, if any, the amount and timing of which are uncertain. At such time, if it is determined that it is more likely than not that the deferred tax assets are realizable, the valuation allowance will be adjusted. As of July 31, 2021, we have provided a valuation allowance for our federal, state, United Kingdom and certain other foreign deferred tax assets that we believe will, more likely than not, be unrealizable. The net valuation allowance increased by $0.7 billion from the year

[0001327567-21-000029:notes:353]
ended July 31, 2020 to the year ended July 31, 2021, primarily due to a change in the United Kingdom tax rate as discussed above and an increase in our operations.

[0001327567-21-000029:notes:354]
As of July 31, 2021, we had federal, state, and foreign NOL carryforwards of approximately $1.8 billion, $0.9 billion, and $1.1 billion, respectively, as reported on our tax returns, available to reduce future taxable income, if any. If not utilized, our federal and state NOL carryforwards will expire in various amounts at various dates beginning in the years ending July 31, 2034 and July 31, 2022, respectively. Our foreign NOL will carry forward indefinitely.

[0001327567-21-000029:notes:355]
As of July 31, 2021, we had federal and state research and development tax credit carryforwards of approximately $172.8 million and $144.7 million, respectively, as reported on our tax returns. If not utilized, the federal credit carryforwards will expire in various amounts at various dates beginning in the year ending July 31, 2026. The state credit will carry forward indefinitely.

[0001327567-21-000029:notes:356]
As of July 31, 2021, we had foreign tax credit carryforwards of $3.6 million as reported on our tax returns. If not utilized, the foreign tax credit carryforwards will expire in various amounts at various dates beginning in the year ending July 31, 2022.

[0001327567-21-000029:notes:357]
Utilization of the NOL carryforwards and credits may be subject to a substantial annual limitation due to the ownership change limitations provided by the Internal Revenue Code of 1986, as amended, and similar state provisions. The annual limitation may result in the expiration of NOLs and credits before utilization.

[0001327567-21-000029:notes:358]
As of July 31, 2021, we had $372.9 million of unrecognized tax benefits, $68.7 million of which would affect income tax expense if recognized, after consideration of our valuation allowance in the United States and other assets. As of July 31, 2020, we had $326.4 million of unrecognized tax benefits, $63.9 million of which would affect income tax expense if recognized, after consideration of our valuation allowance in the United States and other assets. As of July 31, 2021, our federal, state, and foreign returns for the tax years 2009 through the current period remain subject to adjustment due to current and future examinations. Fiscal years outside the normal statute of limitation remain open to audit by tax authorities due to tax attributes generated in earlier years, which have been carried forward and may be audited in subsequent years when utilized. We do not expect the amount of unrecognized tax benefits as of July 31, 2021 to change significantly over the next 12 months. We recognize both interest and penalties associated with uncertain tax positions as a component of income tax expense. During the years ended July 31, 2021, 2020, and 2019, we recognized income tax expense related to interest and penalties of $3.5 million, $1.6 million, and $2.3 million, respectively. We had accrued interest and penalties on our consolidated balance sheets related to unrecognized tax benefits of $15.7 million and $12.2 million as of July 31, 2021 and 2020, respectively. The ultimate amount and timing of any future cash settlements cannot be predicted with reasonable certainty.

[0001327567-21-000029:notes:359]
The following table presents a reconciliation of the beginning and ending amount of our gross unrecognized tax benefits (in millions):

[0001327567-21-000029:notes:360]
|  | Year Ended July 31, |
|  | 2021 |  | 2020 |  | 2019 |
| Unrecognized tax benefits at the beginning of the period | $ | 326.4 |  |  | $ | 314.5 |  |  | $ | 337.7 |  |
| Additions for tax positions taken in prior years | 26.5 |  |  | 3.2 |  |  | 0.3 |  |
| Reductions for tax positions taken in prior years | (2.5) |  |  | (1.6) |  |  | (33.4) |  |
| Additions for tax positions taken in the current year | 22.5 |  |  | 10.3 |  |  | 9.9 |  |
| Unrecognized tax benefits at the end of the period | $ | 372.9 |  |  | $ | 326.4 |  |  | $ | 314.5 |  |

[0001327567-21-000029:notes:361]
During the year ended July 31, 2021, our additions for tax positions taken in the given year were primarily attributable to uncertain tax positions related to tax credits.

[0001327567-21-000029:notes:362]
During the year ended July 31, 2020 and July 31, 2019, our additions for tax positions taken in the given year were primarily attributable to intercompany transactions.
As of July 31, 2021, we had no unremitted earnings when evaluating our outside basis difference relating to our U.S. investment in foreign subsidiaries. However, there could be local withholding taxes payable due to various foreign countries if certain lower tier earnings are distributed. Withholding taxes that would be payable upon remittance of these lower tier earnings are not material.


## us-gaap:EarningsPerShareTextBlock

[0001327567-21-000029:notes:363]
Net Loss Per Share Basic net loss per share is computed by dividing net loss by basic weighted-average shares outstanding during the period. Diluted net loss per share is computed by dividing net loss by diluted weighted-average shares outstanding, including potentially dilutive securities.
The following table presents the computation of basic and diluted net loss per share of common stock (in millions, except per share data):

[0001327567-21-000029:notes:364]
|  | Year Ended July 31, |
|  | 2021 |  | 2020 |  | 2019 |
| Net loss | $ | (498.9) |  |  | $ | (267.0) |  |  | $ | (81.9) |  |
| Weighted-average shares used to compute net loss per share, basic and diluted | 96.4 |  |  | 96.9 |  |  | 94.5 |
| Net loss per share, basic and diluted | $ | (5.18) |  |  | $ | (2.76) |  |  | $ | (0.87) |  |

[0001327567-21-000029:notes:365]
The following securities were excluded from the computation of diluted net loss per share of common stock for the periods presented as their effect would have been antidilutive (in millions):

[0001327567-21-000029:notes:366]
|  | Year Ended July 31, |
|  | 2021 |  | 2020 |  | 2019 |
| Convertible senior notes | 13.1 |  |  | 13.1 |  |  | 6.4 |  |
| Warrants related to the issuance of convertible senior notes | 13.1 |  |  | 13.1 |  |  | 11.6 |  |
| RSUs and PSUs | 8.2 |  |  | 7.2 |  |  | 7.2 |  |
| Options to purchase common stock, including PSOs | 2.9 |  |  | 2.9 |  |  | 4.0 |  |
| RSAs and PSAs | 0.3 |  |  | 0.1 |  |  | 0.1 |  |
| ESPP shares | 0.3 |  |  | 0.3 |  |  | 0.2 |  |
| Total | 37.9 |  |  | 36.7 |  |  | 29.5 |  |


## us-gaap:OtherNonoperatingIncomeAndExpenseTextBlock

[0001327567-21-000029:notes:367]
Other Income, NetThe following table sets forth the components of other income, net (in millions):

[0001327567-21-000029:notes:368]
|  | Year Ended July 31, |
|  | 2021 |  | 2020 |  | 2019 |
| Interest income | $ | 8.5 |  |  | $ | 41.4 |  |  | $ | 69.8 |  |
| Foreign currency exchange gains (losses), net | (5.4) |  |  | (6.7) |  |  | (3.5) |  |
| Other | (0.7) |  |  | 1.2 |  |  | (2.9) |  |
| Total other income, net | $ | 2.4 |  |  | $ | 35.9 |  |  | $ | 63.4 |  |


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0001327567-21-000029:notes:369]
Employee Benefit PlanWe have established a 401(k) tax-deferred savings plan which permits participants to make contributions by salary deduction pursuant to Section 401(k) of the Internal Revenue Code. We make matching contributions based upon the amount of employees’ contributions, subject to certain limitations. Our matching contributions to the plan were immaterial for the years ended July 31, 2021, 2020, and 2019.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001327567-21-000029:notes:370]
Segment InformationWe conduct business globally and are primarily managed on a geographic theater basis. Our chief operating decision maker reviews financial information presented on a consolidated basis accompanied by information about revenue by geographic region for purposes of allocating resources and evaluating financial performance. We have one business activity and there are no segment managers who are held accountable for operations, operating results, and plans for levels, components, or types of products or services below the consolidated unit level. Accordingly, we are considered to be in a single reportable segment and operating unit structure.
The following table presents our long-lived assets, which consist of property and equipment, net and operating lease right-of-use assets, by geographic region (in millions):

[0001327567-21-000029:notes:371]
|  | Year Ended July 31, |
|  | 2021 |  | 2020 |
| Long-lived assets: |  |  |  |
| United States | $ | 461.1 |  |  | $ | 502.3 |  |
| Israel | 61.9 |  |  | 52.1 |  |
| Other countries | 58.3 |  |  | 52.4 |  |
| Total long-lived assets | $ | 581.3 |  |  | $ | 606.8 |  |

[0001327567-21-000029:notes:372]
Refer to Note 2. Revenue for revenue by geographic theater and revenue for groups of similar products and services for the years ended July 31, 2021, 2020, and 2019.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001327567-21-000029:notes:373]
Related Party TransactionsCertain members of our board of directors are affiliated with Greylock Partners (“Greylock”), a venture capital firm. Entities affiliated with Greylock owned a portion of the outstanding shares of Demisto immediately prior to completion of our acquisition of Demisto on March 28, 2019 and, as a result, received purchase consideration valued at $85.6 million during the year ended July 31, 2019. Refer to Note 7. Acquisitions for more information on our acquisition of Demisto.


## us-gaap:SubsequentEventsTextBlock

[0001327567-21-000029:notes:374]
Subsequent Events
Share Repurchase

[0001327567-21-000029:notes:375]
On August 17, 2021, our board of directors authorized a $676.1 million increase to our share repurchase program under the current authorization, bringing the total remaining authorization for future share repurchases to $1.0 billion. Repurchases may be made at management’s discretion from time to time on the open market, through privately negotiated transactions, transactions structured through investment banking institutions, block purchase techniques, 10b5-1 trading plans, or a combination of the foregoing. The repurchase authorization will expire on December 31, 2022, and may be suspended or discontinued at any time.

[0001327567-21-000029:notes:376]
Business Combination

[0001327567-21-000029:notes:377]
On August 11, 2021, we completed our acquisition of Gamma Networks, Inc. (“Gamma”), a privately-held AI powered company, for total consideration of approximately $36 million, subject to adjustment. We expect the acquisition will expand our data loss prevention offerings. We will complete the initial accounting for the acquisition of Gamma, including the allocation of purchase consideration, during our first quarter of fiscal 2022.
