# PANW 10-K controls and the auditor's report


## auditors_report

[0001327567-21-000029:auditors_report:1]
Report of Independent Registered Public Accounting Firm

[0001327567-21-000029:auditors_report:2]
To the Stockholders and the Board of Directors of Palo Alto Networks, Inc.

[0001327567-21-000029:auditors_report:3]
Opinion on the Financial Statements

[0001327567-21-000029:auditors_report:4]
We have audited the accompanying consolidated balance sheets of Palo Alto Networks, Inc. (the Company) as of July 31, 2021 and 2020, the related consolidated statements of operations, comprehensive loss, stockholders’ equity and cash flows for each of the three years in the period ended July 31, 2021, and the related notes (collectively referred to as the “consolidated financial statements”). In our opinion, the consolidated financial statements present fairly, in all material respects, the financial position of the Company at July 31, 2021 and 2020, and the results of its operations and its cash flows for each of the three years in the period ended July 31, 2021, in conformity with U.S. generally accepted accounting principles.

[0001327567-21-000029:auditors_report:5]
We also have audited, in accordance with the standards of the Public Company Accounting Oversight Board (United States) (PCAOB), the Company’s internal control over financial reporting as of July 31, 2021, based on criteria established in Internal Control-Integrated Framework issued by the Committee of Sponsoring Organizations of the Treadway Commission (2013 framework) and our report dated September 3, 2021 expressed an unqualified opinion thereon.

[0001327567-21-000029:auditors_report:6]
Basis for Opinion

[0001327567-21-000029:auditors_report:7]
These financial statements are the responsibility of the Company’s management. Our responsibility is to express an opinion on the Company’s financial statements based on our audits. We are a public accounting firm registered with the PCAOB and are required to be independent with respect to the Company in accordance with the U.S. federal securities laws and the applicable rules and regulations of the Securities and Exchange Commission and the PCAOB.

[0001327567-21-000029:auditors_report:8]
We conducted our audits in accordance with the standards of the PCAOB. Those standards require that we plan and perform the audit to obtain reasonable assurance about whether the financial statements are free of material misstatement, whether due to error or fraud. Our audits included performing procedures to assess the risks of material misstatement of the financial statements, whether due to error or fraud, and performing procedures that respond to those risks. Such procedures included examining, on a test basis, evidence regarding the amounts and disclosures in the financial statements. Our audits also included evaluating the accounting principles used and significant estimates made by management, as well as evaluating the overall presentation of the financial statements. We believe that our audits provide a reasonable basis for our opinion.

[0001327567-21-000029:auditors_report:9]
Critical Audit Matters

[0001327567-21-000029:auditors_report:10]
The critical audit matters communicated below are matters arising from the current period audit of the financial statements that were communicated or required to be communicated to the audit committee and that: (1) relate to accounts or disclosures that are material to the financial statements and (2) involved our especially challenging, subjective, or complex judgments. The communication of critical audit matters does not alter in any way our opinion on the consolidated financial statements, taken as a whole, and we are not, by communicating the critical audit matters below, providing separate opinions on the critical audit matters or on the accounts or disclosures to which they relate.

[0001327567-21-000029:auditors_report:11]
- 60 -

[0001327567-21-000029:auditors_report:12]
|  |  | Revenue Recognition |
| Description of the Matter |  | As described in Note 1 to the consolidated financial statements, the Company’s contracts with customers sometimes contain multiple performance obligations, which are accounted for separately if they are distinct. In such cases, the transaction price is then allocated to the distinct performance obligations on a relative standalone selling price basis, and revenue is recognized when control of the distinct performance obligation is transferred. For example, product revenue is recognized at the time of hardware shipment or delivery of software license, and subscription and support revenue is recognized over time as the services are performed.Auditing the Company’s revenue recognition was complex, including the identification and determination of distinct performance obligations and the timing of revenue recognition. For example, there were nonstandard terms and conditions that required judgment to determine the distinct performance obligations and the impact on the timing of revenue recognition. |
| How We Addressed the Matter in Our Audit |  | We obtained an understanding, evaluated the design and tested the operating effectiveness of the Company’s process and controls to identify and determine the distinct performance obligations and the timing of revenue recognition.To test the identification and determination of the distinct performance obligations and the timing of revenue recognition, our audit procedures included, among others, reading the executed contract and purchase order to understand the contract, identifying the performance obligation(s), determining the distinct performance obligations, and evaluating the timing of revenue recognition for a sample of individual sales transactions. We evaluated the accuracy of the Company’s contract summary documentation, specifically related to the identification and determination of distinct performance obligations and the timing of revenue recognition. |
|  |  | Business Combinations |
| Description of the Matter |  | As described in Note 7 to the consolidated financial statements, the Company completed an acquisition of Expanse Inc. for net consideration of $797.2 million in the year ended July 31, 2021. The Company accounted for this acquisition as a business combination.Auditing the accounting for the acquisition was complex due to the significant estimation uncertainty in determining the fair values of identified intangible assets, which consisted of developed technology of $123.4 million and customer relationships of $36.9 million. The significant estimation uncertainty was primarily due to the sensitivity of the respective fair values to underlying assumptions about future performance of the acquired business and due to the limited historical data on which to base these assumptions. The significant assumptions used to form the basis of the forecasted results included revenue growth rates and technology migration curves. These significant assumptions were forward-looking and could be affected by future economic and market conditions. |
| How We Addressed the Matter in Our Audit |  | We obtained an understanding, evaluated the design and tested the operating effectiveness of the Company’s controls over its accounting for the acquisition. This included testing controls over the estimation process supporting the recognition and measurement of identified intangible assets, and management’s judgment and evaluation of underlying assumptions and estimates with regards to the fair values of the identified intangible assets.To test the estimated fair values of the identified intangible assets, our audit procedures included, among others, reading the underlying agreements, testing management’s application of the relevant accounting guidance, and involving a specialist to assist us in the evaluation of the Company’s valuation methodology and testing of the significant assumptions. For example, we compared the revenue growth rates and technology migration curves to current industry, market and economic trends. Additionally, we tested the completeness and accuracy of the underlying data supporting the significant assumptions and estimates. |

[0001327567-21-000029:auditors_report:13]
/s/ Ernst & Young LLP

[0001327567-21-000029:auditors_report:14]
We have served as the Company’s auditor since 2009.

[0001327567-21-000029:auditors_report:15]
San Jose, California

[0001327567-21-000029:auditors_report:16]
September 3, 2021

[0001327567-21-000029:auditors_report:17]
- 61 -

[0001327567-21-000029:auditors_report:18]
Report of Independent Registered Public Accounting Firm

[0001327567-21-000029:auditors_report:19]
To the Stockholders and the Board of Directors of Palo Alto Networks, Inc.

[0001327567-21-000029:auditors_report:20]
Opinion on Internal Control Over Financial Reporting

[0001327567-21-000029:auditors_report:21]
We have audited Palo Alto Networks, Inc.’s internal control over financial reporting as of July 31, 2021, based on criteria established in Internal Control—Integrated Framework issued by the Committee of Sponsoring Organizations of the Treadway Commission (2013 framework) (the COSO criteria). In our opinion, Palo Alto Networks, Inc. (the Company) maintained, in all material respects, effective internal control over financial reporting as of July 31, 2021, based on the COSO criteria.

[0001327567-21-000029:auditors_report:22]
We also have audited, in accordance with the standards of the Public Company Accounting Oversight Board (United States) (PCAOB), the consolidated balance sheets of the Company as of July 31, 2021 and 2020, the related consolidated statements of operations, comprehensive loss, stockholders’ equity and cash flows for each of the three years in the period ended July 31, 2021, and the related notes and our report dated September 3, 2021 expressed an unqualified opinion thereon.

[0001327567-21-000029:auditors_report:23]
Basis for Opinion

[0001327567-21-000029:auditors_report:24]
The Company’s management is responsible for maintaining effective internal control over financial reporting and for its assessment of the effectiveness of internal control over financial reporting included in the accompanying Management’s Report on Internal Control over Financial Reporting. Our responsibility is to express an opinion on the Company’s internal control over financial reporting based on our audit. We are a public accounting firm registered with the PCAOB and are required to be independent with respect to the Company in accordance with the U.S. federal securities laws and the applicable rules and regulations of the Securities and Exchange Commission and the PCAOB.

[0001327567-21-000029:auditors_report:25]
We conducted our audit in accordance with the standards of the PCAOB. Those standards require that we plan and perform the audit to obtain reasonable assurance about whether effective internal control over financial reporting was maintained in all material respects.

[0001327567-21-000029:auditors_report:26]
Our audit included obtaining an understanding of internal control over financial reporting, assessing the risk that a material weakness exists, testing and evaluating the design and operating effectiveness of internal control based on the assessed risk, and performing such other procedures as we considered necessary in the circumstances. We believe that our audit provides a reasonable basis for our opinion.

[0001327567-21-000029:auditors_report:27]
Definition and Limitations of Internal Control Over Financial Reporting

[0001327567-21-000029:auditors_report:28]
A company’s internal control over financial reporting is a process designed to provide reasonable assurance regarding the reliability of financial reporting and the preparation of financial statements for external purposes in accordance with generally accepted accounting principles. A company’s internal control over financial reporting includes those policies and procedures that (1) pertain to the maintenance of records that, in reasonable detail, accurately and fairly reflect the transactions and dispositions of the assets of the company; (2) provide reasonable assurance that transactions are recorded as necessary to permit preparation of financial statements in accordance with generally accepted accounting principles, and that receipts and expenditures of the company are being made only in accordance with authorizations of management and directors of the company; and (3) provide reasonable assurance regarding prevention or timely detection of unauthorized acquisition, use, or disposition of the company’s assets that could have a material effect on the financial statements.

[0001327567-21-000029:auditors_report:29]
Because of its inherent limitations, internal control over financial reporting may not prevent or detect misstatements. Also, projections of any evaluation of effectiveness to future periods are subject to the risk that controls may become inadequate because of changes in conditions, or that the degree of compliance with the policies or procedures may deteriorate.

[0001327567-21-000029:auditors_report:30]
/s/ Ernst & Young LLP

[0001327567-21-000029:auditors_report:31]
San Jose, California

[0001327567-21-000029:auditors_report:32]
September 3, 2021

[0001327567-21-000029:auditors_report:33]
- 62 -


## item_9a

[0001327567-21-000029:item_9a:1]
ITEM 9A.    CONTROLS AND PROCEDURES

[0001327567-21-000029:item_9a:2]
Evaluation of Disclosure Controls and Procedures

[0001327567-21-000029:item_9a:3]
Our management, with the participation of our chief executive officer and chief financial officer, evaluated the effectiveness of our disclosure controls and procedures pursuant to Rule 13a-15 under the Securities Exchange Act of 1934, as amended (the “Exchange Act”). In designing and evaluating the disclosure controls and procedures, management recognizes that any controls and procedures, no matter how well designed and operated, can provide only reasonable assurance of achieving the desired control objectives. In addition, the design of disclosure controls and procedures must reflect the fact that there are resource constraints and that management is required to apply its judgment in evaluating the benefits of possible controls and procedures relative to their costs.

[0001327567-21-000029:item_9a:4]
Based on our evaluation, our chief executive officer and chief financial officer concluded that, as of July 31, 2021, our disclosure controls and procedures are designed at a reasonable assurance level and are effective to provide reasonable assurance that information we are required to disclose in reports that we file or submit under the Exchange Act is recorded, processed, summarized, and reported within the time periods specified in Securities and Exchange Commission (“SEC”) rules and forms, and that such information is accumulated and communicated to our management, including our chief executive officer and chief financial officer, as appropriate, to allow timely decisions regarding required disclosure.

[0001327567-21-000029:item_9a:5]
Management’s Annual Report on Internal Control over Financial Reporting

[0001327567-21-000029:item_9a:6]
For “Management’s Annual Report on Internal Control Over Financial Reporting” see the report under Part II, Item 8 of this Annual Report on Form 10-K, which report is incorporated herein by reference.

[0001327567-21-000029:item_9a:7]
For the “Report of Independent Registered Public Accounting Firm,” see the report under Part II, Item 8 of this Annual Report on Form 10-K, which report is incorporated herein by reference.

[0001327567-21-000029:item_9a:8]
Changes in Internal Control over Financial Reporting

[0001327567-21-000029:item_9a:9]
As a result of COVID-19, most of our workforce has been working from home since March 2020. However there were no changes in our internal control over financial reporting identified in connection with the evaluation required by Rule 13a-15(d) and 15d-15(d) of the Exchange Act that occurred during the quarter ended July 31, 2021 that have materially affected, or are reasonably likely to materially affect, our internal control over financial reporting.
