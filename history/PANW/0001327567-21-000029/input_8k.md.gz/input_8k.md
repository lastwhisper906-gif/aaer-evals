# PANW 8-K — 0001327567-21-000020 filed 2021-08-23

## item codes, every 8-K on or before 2021-09-03

- 2021-08-23 0001327567-21-000020 — 2.02, 9.01
- 2021-08-12 0001193125-21-244832 — 5.02, 9.01
- 2021-05-20 0001327567-21-000012 — 2.02, 9.01
- 2021-05-18 0001193125-21-164169 — 5.02 — amendment of 0001193125-21-162161
- 2021-05-14 0001193125-21-162161 — 5.02, 9.01
- 2021-03-19 0001193125-21-087516 — 5.02, 9.01
- 2021-02-22 0001628280-21-002659 — 2.02, 9.01
- 2021-02-22 0001193125-21-049293 — 5.02, 9.01
- 2020-12-18 0001193125-20-321568 — 8.01, 9.01
- 2020-12-16 0001193125-20-319091 — 3.02 — amendment of 0001193125-20-291707
- 2020-12-10 0001193125-20-314920 — 5.07
- 2020-12-08 0001193125-20-312056 — 5.02, 8.01, 9.01
- 2020-11-16 0001327567-20-000037 — 2.02, 9.01
- 2020-11-12 0001193125-20-291707 — 3.02
- 2020-10-19 0001193125-20-272060 — 5.02
- 2020-08-24 0001327567-20-000025 — 2.02, 9.01
- 2020-06-23 0001193125-20-176553 — 5.02, 9.01
- 2020-06-22 0001193125-20-175603 — 5.02, 9.01
- 2020-06-08 0001193125-20-163579 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2020-05-21 0001327567-20-000015 — 2.02, 9.01
- 2020-02-27 0001193125-20-050335 — 1.01, 2.03
- 2020-02-24 0001327567-20-000002 — 2.02, 9.01
- 2019-12-19 0001193125-19-319166 — 1.02, 9.01
- 2019-12-10 0001193125-19-310251 — 5.07
- 2019-11-25 0001327567-19-000036 — 2.02, 9.01
- 2019-11-25 0001193125-19-299886 — 5.02, 8.01 — amendment of 0001327567-19-000011
- 2019-10-22 0001193125-19-271660 — 5.02
- 2019-09-06 0001327567-19-000026 — 9.01 — amendment of 0001327567-19-000023
- 2019-09-04 0001327567-19-000023 — 2.02, 7.01, 9.01
- 2019-07-11 0001193125-19-192415 — 5.02, 9.01
- 2019-05-29 0001327567-19-000014 — 2.02, 9.01
- 2019-04-15 0001327567-19-000011 — 5.02, 9.01
- 2019-04-01 0001193125-19-094613 — 8.01, 9.01
- 2019-03-28 0001193125-19-090572 — 3.02 — amendment of 0001327567-19-000003
- 2019-02-26 0001327567-19-000006 — 2.02, 8.01, 9.01
- 2019-02-19 0001327567-19-000003 — 3.02
- 2018-12-11 0001327567-18-000033 — 5.07
- 2018-11-29 0001327567-18-000029 — 2.02, 9.01
- 2018-10-15 0001193125-18-299312 — 5.02, 9.01
- 2018-09-25 0001193125-18-282542 — 5.02
- 2018-09-14 0001193125-18-274239 — 5.03, 9.01
- 2018-09-06 0001327567-18-000018 — 1.01, 2.02, 2.03, 9.01
- 2018-07-13 0001193125-18-217281 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2018-06-04 0001327567-18-000011 — 2.02, 5.02, 9.01
- 2018-02-26 0001327567-18-000004 — 2.02, 5.02, 7.01, 9.01
- 2017-12-12 0001193125-17-367477 — 5.07
- 2017-11-20 0001327567-17-000032 — 2.02, 5.02, 9.01
- 2017-08-31 0001327567-17-000021 — 2.02, 5.02, 9.01
- 2017-05-31 0001327567-17-000016 — 2.02, 9.01
- 2017-02-28 0001327567-17-000005 — 2.02, 8.01, 9.01
- 2016-12-12 0001193125-16-790757 — 5.07
- 2016-11-21 0001327567-16-000071 — 2.02, 9.01
- 2016-10-24 0001193125-16-745121 — 5.02, 9.01
- 2016-08-30 0001327567-16-000057 — 2.02, 5.03, 8.01, 9.01
- 2016-08-22 0001193125-16-687588 — 5.02, 9.01
- 2016-05-26 0001327567-16-000051 — 2.02, 9.01
- 2016-02-25 0001327567-16-000044 — 2.02, 5.02, 9.01
- 2015-12-14 0001327567-15-000038 — 5.07
- 2015-12-14 0001193125-15-402588 — 1.01, 9.01
- 2015-11-23 0001327567-15-000033 — 2.02, 9.01
- 2015-10-19 0001193125-15-347005 — 1.01, 9.01 — amendment, the index does not say of what
- 2015-09-09 0001327567-15-000022 — 2.02, 9.01
- 2015-08-19 0001193125-15-296115 — 1.01, 2.03
- 2015-06-01 0001193125-15-207786 — 1.01, 2.03
- 2015-05-27 0001327567-15-000015 — 2.02, 9.01
- 2015-03-02 0001327567-15-000006 — 2.02, 9.01
- 2014-12-15 0001327567-14-000046 — 5.07
- 2014-11-24 0001327567-14-000040 — 2.02, 9.01
- 2014-09-22 0001193125-14-348581 — 5.02, 9.01
- 2014-09-09 0001327567-14-000025 — 2.02, 9.01
- 2014-07-01 0001193125-14-257824 — 1.01, 2.03, 3.02, 9.01
- 2014-06-26 0001193125-14-249529 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2014-06-20 0001327567-14-000020 — 9.01 — amendment of 0001193125-14-140511
- 2014-06-04 0001327567-14-000016 — 3.02
- 2014-05-30 0001193125-14-218158 — 2.02 — amendment, the index does not say of what
- 2014-05-28 0001193125-14-215060 — 1.01, 2.02, 3.02, 9.01
- 2014-04-11 0001193125-14-140511 — 2.01, 3.02, 7.01, 9.01
- 2014-03-24 0001193125-14-111318 — 1.01, 3.02, 7.01, 9.01
- 2014-03-13 0001327567-14-000009 — 5.02
- 2014-02-24 0001193125-14-063754 — 2.02, 9.01
- 2013-12-12 0001327567-13-000040 — 5.07
- 2013-11-25 0001327567-13-000033 — 2.02, 9.01
- 2013-09-30 0001193125-13-384966 — 8.01
- 2013-09-09 0001193125-13-361421 — 2.02, 9.01
- 2013-05-30 0001193125-13-241542 — 2.02, 5.02, 9.01
- 2013-03-11 0001193125-13-101082 — 5.02, 9.01
- 2013-02-28 0001193125-13-084193 — 2.02, 9.01
- 2012-12-14 0001193125-12-503335 — 5.07
- 2012-12-06 0001193125-12-493700 — 2.02, 9.01
- 2012-09-24 0001193125-12-401534 — 1.01, 2.03
- 2012-09-20 0001193125-12-398433 — 5.02, 9.01
- 2012-09-10 0001193125-12-386605 — 2.02, 9.01

## late-filing notifications on or before 2021-09-03

- none on or before 2021-09-03

## item 2.02 — earnings release, exhibit 99.1

[0001327567-21-000020:8k_2_02:1]
EX-99.1
2
ex991q421earningsrelease.htm
EX-99.1

[0001327567-21-000020:8k_2_02:2]
Document

[0001327567-21-000020:8k_2_02:3]
Exhibit 99.1

[0001327567-21-000020:8k_2_02:4]
Palo Alto Networks Reports Fiscal Fourth Quarter 2021 Financial Results

[0001327567-21-000020:8k_2_02:5]
•Fiscal fourth quarter revenue grew 28% year over year to $1.2 billion. Fiscal year 2021 revenue grew 25% to $4.3 billion.

[0001327567-21-000020:8k_2_02:6]
•Fiscal fourth quarter billings grew 34% year over year to $1.9 billion. Fiscal year 2021 billings grew 27% to $5.5 billion.

[0001327567-21-000020:8k_2_02:7]
•Deferred revenue grew 32% year over year to $5.0 billion, remaining performance obligation (RPO) grew 36% year over year to $5.9 billion.

[0001327567-21-000020:8k_2_02:8]
SANTA CLARA, Calif. — August 23, 2021 — Palo Alto Networks (NYSE: PANW), the global cybersecurity leader, announced today financial results for its fiscal fourth quarter 2021, ended July 31, 2021.

[0001327567-21-000020:8k_2_02:9]
Total revenue for the fiscal fourth quarter 2021 grew 28% year over year to $1.2 billion, compared with total revenue of $950.4 million for the fiscal fourth quarter 2020. GAAP net loss for the fiscal fourth quarter 2021 was $119.3 million, or $1.23 loss per diluted share, compared with GAAP net loss of $58.9 million, or $0.61 per diluted share, for the fiscal fourth quarter 2020.

[0001327567-21-000020:8k_2_02:10]
Non-GAAP net income for the fiscal fourth quarter 2021 was $161.9 million, or $1.60 per diluted share, compared with non-GAAP net income of $144.9 million, or $1.48 per diluted share, for the fiscal fourth quarter 2020. A reconciliation between GAAP and non-GAAP information is contained in the tables below.

[0001327567-21-000020:8k_2_02:11]
“Our strong Q4 performance was the culmination of executing on our strategy throughout the year, including product innovation, platform integration, business model transformation and investments in our go-to-market organization,” said Nikesh Arora, chairman and CEO of Palo Alto Networks. “In particular, we saw notable strength in large customer transactions with strategic commitments across our Strata, Prisma and Cortex platforms.”

[0001327567-21-000020:8k_2_02:12]
“We are pleased to deliver strength across all the key total shareholder return drivers — top line, operating margin and free cash flow conversion,” said Dipak Golechha, chief financial officer of

[0001327567-21-000020:8k_2_02:13]
Palo Alto Networks. “We look forward to updating investors on our long-term goals at our upcoming analyst day on September 13th”.

[0001327567-21-000020:8k_2_02:14]
Financial Outlook

[0001327567-21-000020:8k_2_02:15]
Palo Alto Networks provides guidance based on current market conditions and expectations.

[0001327567-21-000020:8k_2_02:16]
For the fiscal first quarter 2022, the company expects:

[0001327567-21-000020:8k_2_02:17]
•Total billings in the range of $1.29 billion to $1.31 billion, representing year-over-year growth of between 19% and 21%.

[0001327567-21-000020:8k_2_02:18]
•Total revenue in the range of $1.19 billion to $1.21 billion, representing year-over-year growth of between 26% and 28%.

[0001327567-21-000020:8k_2_02:19]
•Diluted non-GAAP net income per share in the range of $1.55 to $1.58, using 101 million to 103 million shares.

[0001327567-21-000020:8k_2_02:20]
For the fiscal year 2022, the company expects:

[0001327567-21-000020:8k_2_02:21]
•Total billings in the range of $6.60 billion to $6.65 billion, representing year-over-year growth of between 21% and 22%.

[0001327567-21-000020:8k_2_02:22]
•Total revenue in the range of $5.275 billion to $5.325 billion, representing year-over-year growth between 24% and 25%.

[0001327567-21-000020:8k_2_02:23]
•Diluted non-GAAP net income per share in the range of $7.15 to $7.25, using 104 million to 106 million shares.

[0001327567-21-000020:8k_2_02:24]
•Adjusted free cash flow margin of >30%.

[0001327567-21-000020:8k_2_02:25]
Subsequent to quarter end, the board of directors authorized an additional $676.1 million for share repurchase, increasing the remaining authorization for future share repurchases to $1.0 billion, expiring December 31, 2022.

[0001327567-21-000020:8k_2_02:26]
Guidance for non-GAAP financial measures excludes share-based compensation-related charges (including share-based payroll tax expense), acquisition-related costs, amortization expense of acquired intangible assets, litigation-related charges, including legal settlements, gains (losses) related to facility exit, non-cash charges related to convertible notes, foreign currency gains (losses), and income and other tax effects associated with these items, along with certain non-recurring expenses and certain non-recurring cash flows. We have not reconciled diluted non-GAAP net income per share guidance to GAAP net income (loss) per diluted share or adjusted

[0001327567-21-000020:8k_2_02:27]
free cash flow margin guidance to GAAP net cash from operating activities because we do not provide guidance on GAAP net income (loss) or net cash from operating activities and would not be able to present the various reconciling cash and non-cash items between GAAP and non-GAAP financial measures, including share-based compensation expense, without unreasonable effort. Share-based compensation expense is impacted by the company’s future hiring and retention needs and, to a lesser extent, the future fair market value of the company’s common stock, all of which is difficult to predict and subject to constant change. The actual amounts of such reconciling items will have a significant impact on the company’s GAAP net income (loss) per diluted share.

[0001327567-21-000020:8k_2_02:28]
Earnings Call Information

[0001327567-21-000020:8k_2_02:29]
Palo Alto Networks will host a video webcast for analysts and investors to discuss the company’s fiscal fourth quarter 2021 results as well as the outlook for its fiscal first quarter 2022 today at 4:30 p.m. Eastern time or 1:30 p.m. Pacific time. Open to the public, investors may access the webcast, supplemental financial information and earnings slides from the “Investors” section of the company’s website at investors.paloaltonetworks.com. A replay will be available three hours after the conclusion of the webcast and archived for one year.

[0001327567-21-000020:8k_2_02:30]
Forward-Looking Statements

[0001327567-21-000020:8k_2_02:31]
This press release contains forward-looking statements that involve risks, uncertainties, and assumptions including statements regarding our financial outlook for the fiscal first quarter 2022 and fiscal year 2022. There are a significant number of factors that could cause actual results to differ materially from statements made in this press release, including: developments and changes in general market, political, economic, and business conditions; the duration and global impact of COVID-19, including the impact of COVID-19 on our customers’ purchasing decisions; our ability as an organization to acquire and integrate other companies, products or technologies in a successful manner; risks associated with managing our growth; the risks associated with new products and subscription and support offerings, including the discovery of software bugs; our competitive position; our ability to attract and retain new customers; shift in priorities or delays in the development or release of new subscription offerings, or the failure to timely develop and achieve market acceptance of new products and subscriptions as well as existing products and subscription and support offerings; rapidly evolving technological developments in the market for security products and subscription and support offerings; our ability to obtain adequate supply of our products from our third-party manufacturing partners; and length of sales cycles.

[0001327567-21-000020:8k_2_02:32]
3

[0001327567-21-000020:8k_2_02:33]
Additional risks and uncertainties that could affect our financial results are included under the captions “Risk Factors” and “Management’s Discussion and Analysis of Financial Condition and Results of Operations” in our Quarterly Report on Form 10-Q filed with the SEC on May 21, 2021, which is available on our website at investors.paloaltonetworks.com and on the SEC’s website at www.sec.gov. Additional information will also be set forth in other filings that we make with the SEC from time to time. All forward-looking statements in this press release are based on information available to us as of the date hereof, and we do not assume any obligation to update the forward-looking statements provided to reflect events that occur or circumstances that exist after the date on which they were made.

[0001327567-21-000020:8k_2_02:34]
Non-GAAP Financial Measures and Other Key Metrics

[0001327567-21-000020:8k_2_02:35]
Palo Alto Networks has provided in this press release financial information that has not been prepared in accordance with generally accepted accounting principles in the United States (GAAP). The company uses these non-GAAP financial measures and other key metrics internally in analyzing its financial results and believes that the use of these non-GAAP financial measures and key metrics are useful to investors as an additional tool to evaluate ongoing operating results and trends, and in comparing the company’s financial results with other companies in its industry, many of which present similar non-GAAP financial measures or key metrics.

[0001327567-21-000020:8k_2_02:36]
The presentation of these non-GAAP financial measures and key metrics are not meant to be considered in isolation or as a substitute for comparable GAAP financial measures and should be read only in conjunction with the company’s consolidated financial statements prepared in accordance with GAAP. A reconciliation of the company’s historical non-GAAP financial measures to their most directly comparable GAAP measures has been provided in the financial statement tables included in this press release, and investors are encouraged to review these reconciliations.

[0001327567-21-000020:8k_2_02:37]
Non-GAAP net income and net income per share, diluted. Palo Alto Networks defines non-GAAP net income as net income (loss) plus share-based compensation-related charges, including share-based payroll tax expense, acquisition-related costs, amortization expense of acquired intangible assets, litigation-related charges, including legal settlements, gains (losses) related to facility exit, non-cash charges related to convertible notes, and intellectual property restructuring-related charges. The company also excludes from non-GAAP net income the foreign currency gains (losses) and tax effects associated with these items in order to provide a complete picture of the

[0001327567-21-000020:8k_2_02:38]
company’s recurring core business operating results. The company defines non-GAAP net income per share, diluted, as non-GAAP net income divided by the weighted-average diluted shares outstanding, which includes the potentially dilutive effect of the company’s employee equity incentive plan awards and the company’s convertible senior notes outstanding and related warrants, after giving effect to the anti-dilutive impact of the company’s note hedge agreements, which reduces the potential economic dilution that otherwise would occur upon conversion of the company’s convertible senior notes. Under GAAP, the anti-dilutive impact of the note hedge is not reflected in diluted shares outstanding. The company believes that excluding these items from non-GAAP net income and net income per share, diluted, provides management and investors with greater visibility into the underlying performance of the company’s core business operating results, meaning its operating performance excluding these items and, from time to time, other discrete charges that are infrequent in nature, over multiple periods.

[0001327567-21-000020:8k_2_02:39]
Billings. Palo Alto Networks defines billings as total revenue plus the change in total deferred revenue, net of acquired deferred revenue, during the period. The company considers billings to be a key metric used by management to manage the company’s business and believes billings provides investors with an important indicator of the health and visibility of the company’s business because it includes subscription and support revenue, which is recognized ratably over the contractual service period, and product revenue, which is recognized at the time of shipment, provided that all other conditions for revenue recognition have been met. The company considers billings to be a useful metric for management and investors, particularly if sales of subscriptions continue to increase and the company experiences strong renewal rates for subscriptions and support.

[0001327567-21-000020:8k_2_02:40]
Investors are cautioned that there are a number of limitations associated with the use of non-GAAP financial measures and key metrics as analytical tools. In particular, the billings metric reported by the company includes amounts that have not yet been recognized as revenue. Additionally, many of the adjustments to the company’s GAAP financial measures reflect the exclusion of items that are recurring and will be reflected in the company’s financial results for the foreseeable future, such as share-based compensation, which is an important part of Palo Alto Networks employees’ compensation and impacts their performance. Furthermore, these non-GAAP financial measures are not based on any standardized methodology prescribed by GAAP, and the components that Palo Alto Networks excludes in its calculation of non-GAAP financial measures may differ from the components that its peer companies exclude when they report their

[0001327567-21-000020:8k_2_02:41]
5

[0001327567-21-000020:8k_2_02:42]
non-GAAP results of operations. Palo Alto Networks compensates for these limitations by providing specific information regarding the GAAP amounts excluded from these non-GAAP financial measures. In the future, the company may also exclude non-recurring expenses and other expenses that do not reflect the company’s core business operating results.

[0001327567-21-000020:8k_2_02:43]
About Palo Alto Networks

[0001327567-21-000020:8k_2_02:44]
Palo Alto Networks, the global cybersecurity leader, is shaping the cloud-centric future with technology that is transforming the way people and organizations operate. Our mission is to be the cybersecurity partner of choice, protecting our digital way of life. We help address the world’s greatest security challenges with continuous innovation that seizes the latest breakthroughs in artificial intelligence, analytics, automation, and orchestration. By delivering an integrated platform and empowering a growing ecosystem of partners, we are at the forefront of protecting tens of thousands of organizations across clouds, networks, and mobile devices. Our vision is a world where each day is safer and more secure than the one before. For more information, visit www.paloaltonetworks.com.

[0001327567-21-000020:8k_2_02:45]
Palo Alto Networks, Cortex, Prisma, Strata, and the Palo Alto Networks logo are trademarks of Palo Alto Networks, Inc. in the United States and in jurisdictions throughout the world. All other trademarks, trade names, or service marks used or mentioned herein belong to their respective owners.

[0001327567-21-000020:8k_2_02:46]
Media Contact:

[0001327567-21-000020:8k_2_02:47]
Mara Mort

[0001327567-21-000020:8k_2_02:48]
Senior Director of Corporate Communications, Palo Alto Networks

[0001327567-21-000020:8k_2_02:49]
press@paloaltonetworks.com

[0001327567-21-000020:8k_2_02:50]
Investor Relations Contact:

[0001327567-21-000020:8k_2_02:51]
Clay Bilby

[0001327567-21-000020:8k_2_02:52]
Head of Investor Relations, Palo Alto Networks

[0001327567-21-000020:8k_2_02:53]
ir@paloaltonetworks.com

[0001327567-21-000020:8k_2_02:54]
6

[0001327567-21-000020:8k_2_02:55]
| Palo Alto Networks, Inc. |
| Preliminary Consolidated Statements of Operations |
| (In millions, except per share data) |
| (Unaudited) |
|  | Three Months Ended |  | Year Ended |
|  | July 31, |  | July 31, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Revenue: |  |  |  |  |  |  |  |
| Product | $ | 339.4 |  |  | $ | 305.6 |  |  | $ | 1,120.3 |  |  | $ | 1,064.2 |  |
| Subscription and support | 879.9 |  |  | 644.8 |  |  | 3,135.8 |  |  | 2,344.2 |  |
| Total revenue | 1,219.3 |  |  | 950.4 |  |  | 4,256.1 |  |  | 3,408.4 |  |
| Cost of revenue: |  |  |  |  |  |  |  |
| Product | 88.8 |  |  | 87.3 |  |  | 308.5 |  |  | 294.4 |  |
| Subscription and support | 270.1 |  |  | 203.1 |  |  | 966.4 |  |  | 705.1 |  |
| Total cost of revenue | 358.9 |  |  | 290.4 |  |  | 1,274.9 |  |  | 999.5 |  |
| Total gross profit | 860.4 |  |  | 660.0 |  |  | 2,981.2 |  |  | 2,408.9 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 325.3 |  |  | 215.9 |  |  | 1,140.4 |  |  | 768.1 |  |
| Sales and marketing | 489.8 |  |  | 391.2 |  |  | 1,753.8 |  |  | 1,520.2 |  |
| General and administrative | 105.7 |  |  | 70.7 |  |  | 391.1 |  |  | 299.6 |  |
| Total operating expenses | 920.8 |  |  | 677.8 |  |  | 3,285.3 |  |  | 2,587.9 |  |
| Operating loss | (60.4) |  |  | (17.8) |  |  | (304.1) |  |  | (179.0) |  |
| Interest expense | (41.4) |  |  | (31.4) |  |  | (163.3) |  |  | (88.7) |  |
| Other income (expense), net | (0.5) |  |  | 0.8 |  |  | 2.4 |  |  | 35.9 |  |
| Loss before income taxes | (102.3) |  |  | (48.4) |  |  | (465.0) |  |  | (231.8) |  |
| Provision for income taxes | 17.0 |  |  | 10.5 |  |  | 33.9 |  |  | 35.2 |  |
| Net loss | $ | (119.3) |  |  | $ | (58.9) |  |  | $ | (498.9) |  |  | $ | (267.0) |  |
| Net loss per share, basic and diluted | $ | (1.23) |  |  | $ | (0.61) |  |  | $ | (5.18) |  |  | $ | (2.76) |  |
| Weighted-average shares used to compute net loss per share, basic and diluted | 97.2 |  |  | 96.0 |  |  | 96.4 |  |  | 96.9 |  |

[0001327567-21-000020:8k_2_02:56]
| Palo Alto Networks, Inc. |
| Reconciliation of GAAP to Non-GAAP Financial Measures |
| (In millions, except per share amounts) |
| (Unaudited) |
|  | Three Months Ended |  | Year Ended |
|  | July 31, |  | July 31, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| GAAP net loss | $ | (119.3) |  |  | $ | (58.9) |  |  | $ | (498.9) |  |  | $ | (267.0) |  |
| Share-based compensation-related charges | 239.2 |  |  | 181.3 |  |  | 936.5 |  |  | 685.5 |  |
| Acquisition-related costs(1) | 0.7 |  |  | 0.4 |  |  | 46.1 |  |  | 15.7 |  |
| Amortization expense of acquired intangible assets | 31.6 |  |  | 22.7 |  |  | 116.7 |  |  | 76.4 |  |
| Litigation-related charges(2) | 1.7 |  |  | 1.8 |  |  | 7.1 |  |  | 3.6 |  |
| Gain related to facility exit(3) | — |  |  | — |  |  | — |  |  | (3.1) |  |
| Non-cash charges related to convertible notes(4) | 36.4 |  |  | 26.9 |  |  | 142.9 |  |  | 73.9 |  |
| Foreign currency loss associated with non-GAAP adjustments | 0.2 |  |  | 1.2 |  |  | 2.4 |  |  | 1.1 |  |
| Income tax and other tax adjustments related to the above | (28.6) |  |  | (30.5) |  |  | (139.1) |  |  | (101.5) |  |
| Non-GAAP net income | $ | 161.9 |  |  | $ | 144.9 |  |  | $ | 613.7 |  |  | $ | 484.6 |  |
| GAAP net loss per share, diluted | $ | (1.23) |  |  | $ | (0.61) |  |  | $ | (5.18) |  |  | $ | (2.76) |  |
| Share-based compensation-related charges | 2.39 |  |  | 1.86 |  |  | 9.50 |  |  | 6.96 |  |
| Acquisition-related costs(1) | 0.01 |  |  | 0.00 |  |  | 0.48 |  |  | 0.16 |  |
| Amortization expense of acquired intangible assets | 0.33 |  |  | 0.24 |  |  | 1.21 |  |  | 0.79 |  |
| Litigation-related charges(2) | 0.02 |  |  | 0.02 |  |  | 0.07 |  |  | 0.04 |  |
| Gain related to facility exit(3) | 0.00 |  |  | 0.00 |  |  | 0.00 |  |  | (0.03) |  |
| Non-cash charges related to convertible notes(4) | 0.37 |  |  | 0.28 |  |  | 1.48 |  |  | 0.76 |  |
| Foreign currency loss associated with non-GAAP adjustments | 0.00 |  |  | 0.01 |  |  | 0.02 |  |  | 0.01 |  |
| Income tax and other tax adjustments related to the above | (0.29) |  |  | (0.32) |  |  | (1.44) |  |  | (1.05) |  |
| Non-GAAP net income per share, diluted | $ | 1.60 |  |  | $ | 1.48 |  |  | $ | 6.14 |  |  | $ | 4.88 |  |
| GAAP weighted-average shares used to compute net loss per share, diluted | 97.2 |  |  | 96.0 |  |  | 96.4 |  |  | 96.9 |  |
| Weighted-average effect of potentially dilutive securities(5) | 4.2 |  |  | 2.2 |  |  | 3.5 |  |  | 2.4 |  |
| Non-GAAP weighted-average shares used to compute net income per share, diluted | 101.4 |  |  | 98.2 |  |  | 99.9 |  |  | 99.3 |  |

[0001327567-21-000020:8k_2_02:57]
(1)    Consists of acquisition transaction costs, share-based compensation related to the cash settlement of certain equity awards, and costs to terminate certain employment, operating lease, and other contracts of the acquired companies.

[0001327567-21-000020:8k_2_02:58]
(2)    Consists of the amortization of intellectual property licenses and covenant not to sue.

[0001327567-21-000020:8k_2_02:59]
(3)    Consists of a gain related to the early termination of our previous headquarters leases.

[0001327567-21-000020:8k_2_02:60]
(4)    Consists primarily of non-cash interest expense related to the company’s convertible senior notes.

[0001327567-21-000020:8k_2_02:61]
(5)    Non-GAAP net income per share, diluted, includes the potentially dilutive effect of employee equity incentive plan awards and convertible senior notes outstanding and related warrants. In addition, non-GAAP net income per share, diluted includes the anti-dilutive impact of the company’s note hedge agreements, which reduced the potentially dilutive effect of the convertible notes by 3.5 million and 2.1 million shares for the fiscal fourth quarter and fiscal year ended July 31, 2021, respectively.

[0001327567-21-000020:8k_2_02:62]
8

[0001327567-21-000020:8k_2_02:63]
| Palo Alto Networks, Inc. |
| Calculation of Billings |
| (In millions) |
| (Unaudited) |
|  | Three Months Ended |  | Year Ended |
|  | July 31, |  | July 31, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Total revenue | $ | 1,219.3 |  |  | $ | 950.4 |  |  | $ | 4,256.1 |  |  | $ | 3,408.4 |  |
| Add: change in total deferred revenue, net of acquired deferred revenue | 649.0 |  |  | 439.6 |  |  | 1,196.1 |  |  | 893.3 |  |
| Billings | $ | 1,868.3 |  |  | $ | 1,390.0 |  |  | $ | 5,452.2 |  |  | $ | 4,301.7 |  |

[0001327567-21-000020:8k_2_02:64]
9

[0001327567-21-000020:8k_2_02:65]
| Palo Alto Networks, Inc. |
| Preliminary Consolidated Balance Sheets |
| (In millions) |
| (Unaudited) |
|  | July 31, 2021 |  | July 31, 2020 |
| Assets |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 1,874.2 |  |  | $ | 2,958.0 |  |
| Short-term investments | 1,026.9 |  |  | 789.8 |  |
| Accounts receivable, net | 1,240.4 |  |  | 1,037.1 |  |
| Short-term deferred contract costs | 276.5 |  |  | 206.0 |  |
| Prepaid expenses and other current assets | 229.3 |  |  | 138.3 |  |
| Total current assets | 4,647.3 |  |  | 5,129.2 |  |
| Property and equipment, net | 318.4 |  |  | 348.1 |  |
| Operating lease right-of-use assets | 262.9 |  |  | 258.7 |  |
| Long-term investments | 888.3 |  |  | 554.4 |  |
| Long-term deferred contract costs | 494.6 |  |  | 422.3 |  |
| Goodwill | 2,710.1 |  |  | 1,812.9 |  |
| Intangible assets, net | 498.6 |  |  | 358.2 |  |
| Other assets | 421.4 |  |  | 181.6 |  |
| Total assets | $ | 10,241.6 |  |  | $ | 9,065.4 |  |
| Liabilities, temporary equity and stockholders’ equity |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 56.9 |  |  | $ | 63.6 |  |
| Accrued compensation | 430.6 |  |  | 322.2 |  |
| Accrued and other liabilities | 329.4 |  |  | 256.8 |  |
| Deferred revenue | 2,741.9 |  |  | 2,049.1 |  |
| Convertible senior notes, net | 1,557.9 |  |  | — |  |
| Total current liabilities | 5,116.7 |  |  | 2,691.7 |  |
| Convertible senior notes, net | 1,668.1 |  |  | 3,084.1 |  |
| Long-term deferred revenue | 2,282.1 |  |  | 1,761.1 |  |
| Long-term operating lease liabilities | 313.4 |  |  | 336.6 |  |
| Other long-term liabilities | 97.7 |  |  | 90.1 |  |
| Temporary equity | 129.1 |  |  | — |  |
| Stockholders’ equity: |  |  |  |
| Preferred stock | — |  |  | — |  |
| Common stock and additional paid-in capital | 2,311.2 |  |  | 2,259.2 |  |
| Accumulated other comprehensive income | (9.9) |  |  | 10.5 |  |
| Accumulated deficit | (1,666.8) |  |  | (1,167.9) |  |
| Total stockholders’ equity | 634.5 |  |  | 1,101.8 |  |
| Total liabilities, temporary equity and stockholders’ equity | $ | 10,241.6 |  |  | $ | 9,065.4 |  |
