# PANW notes — 0001327567-17-000027


## panw:ContractManufacturerLiabilitiesPolicyTextBlockPolicyTextBlock

[0001327567-17-000027:notes:1]
Manufacturing Partner and Supplier Liabilities

[0001327567-17-000027:notes:2]
We outsource most of our manufacturing, repair, and supply chain management operations to our EMS provider and payments to it are a significant portion of our cost of product revenue. Although we could be contractually obligated to purchase manufactured products and components, we generally do not own the manufactured products and components. Product title transfers from our EMS provider to us and immediately to our channel partners upon shipment. Our EMS provider assembles our products using design specifications, quality assurance programs, and standards that we establish and it procures components and assembles our products based on our demand forecasts. These forecasts represent our estimates of future demand for our products based upon historical trends and analysis from our sales and product management functions as adjusted for overall market conditions. If the actual component usage and product demand are significantly lower than forecast, we record a liability for manufacturing purchase commitments in excess of our forecasted demand including costs for excess components or for carrying costs incurred by our manufacturing partners and component suppliers. Through July 31, 2017, we have not accrued any significant costs associated with this exposure.


## panw:ScheduleofSharebasedCompensationSharesAvailableforGrantTableTextBlock

[0001327567-17-000027:notes:3]
The following table presents the stock activity and the total number of shares available for grant under our stock plans as of July 31, 2017 (in millions):

[0001327567-17-000027:notes:4]
|  | Number of shares |
| Balance—July 31, 2016 | 8.2 |  |
| Authorized | 4.1 |  |
| RSUs, RSAs, and PSAs granted | (4.2 | ) |
| RSUs and RSAs forfeited | 0.6 |  |
| Shares withheld for taxes | 0.1 |  |
| Balance—July 31, 2017 | 8.8 |  |


## us-gaap:AvailableForSaleSecuritiesTextBlock

[0001327567-17-000027:notes:5]
The following tables summarize the amortized cost, unrealized gains and losses, and fair value of our available-for-sale investments as of July 31, 2017 and July 31, 2016 (in millions):

[0001327567-17-000027:notes:6]
|  | July 31, 2017 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Estimated Fair Value |
| Certificates of deposit | $ | 5.4 |  |  | $ | — |  |  | $ | — |  |  | $ | 5.4 |  |
| Corporate debt securities | 346.1 |  |  | 0.3 |  |  | (0.5 | ) |  | 345.9 |  |
| U.S. government and agency securities | 1,071.2 |  |  | 0.1 |  |  | (2.6 | ) |  | 1,068.7 |  |
| Total | $ | 1,422.7 |  |  | $ | 0.4 |  |  | $ | (3.1 | ) |  | $ | 1,420.0 |  |

[0001327567-17-000027:notes:7]
|  | July 31, 2016 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Estimated Fair Value |
| Certificates of deposit | $ | 5.4 |  |  | $ | — |  |  | $ | — |  |  | $ | 5.4 |  |
| Commercial paper | 3.0 |  |  | — |  |  | — |  |  | 3.0 |  |
| Corporate debt securities | 286.7 |  |  | 0.8 |  |  | — |  |  | 287.5 |  |
| U.S. government and agency securities | 907.3 |  |  | 0.9 |  |  | (0.1 | ) |  | 908.1 |  |
| Total | $ | 1,202.4 |  |  | $ | 1.7 |  |  | $ | (0.1 | ) |  | $ | 1,204.0 |  |


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001327567-17-000027:notes:8]
Basis of Presentation

[0001327567-17-000027:notes:9]
The accompanying consolidated financial statements have been prepared in conformity with U.S. generally accepted accounting principles (“GAAP”). The consolidated financial statements include all adjustments necessary for a fair presentation of our annual results. All adjustments are of a normal recurring nature. Certain prior period amounts have been adjusted due to our voluntary change in accounting policy for sales commissions, our early adoption of new accounting guidance related to share-based payments, and our adoption of new accounting guidance related to debt issuance costs. Refer to “Change in Accounting Policy for Sales Commissions” and “Recently Adopted Accounting Pronouncements” below for more information.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001327567-17-000027:notes:10]
Acquisitions

[0001327567-17-000027:notes:11]
Fiscal 2017

[0001327567-17-000027:notes:12]
LightCyber Ltd.

[0001327567-17-000027:notes:13]
On February 27, 2017, we completed our acquisition of all outstanding shares of LightCyber Ltd. (“LightCyber”), a privately-held cybersecurity company, for total consideration of $103.1 million in cash. The acquisition expands the functionality of our next-generation security platform with the addition of LightCyber’s behavioral analytics technology.

[0001327567-17-000027:notes:14]
We have accounted for this transaction as a business combination and allocated the purchase consideration to assets acquired and liabilities assumed based on their preliminary estimated fair values, as presented in the following table (in millions):

[0001327567-17-000027:notes:15]
|  | Amount |
| Cash | $ | 12.4 |  |
| Goodwill | 75.3 |  |
| Identified intangible assets | 19.5 |  |
| Net liabilities assumed | (4.1 | ) |
| Total | $ | 103.1 |  |

[0001327567-17-000027:notes:16]
Additional information, such as that related to income tax and other contingencies, existing as of the acquisition date but unknown to us may become known during the remainder of the measurement period, not to exceed 12 months from the acquisition date, which may result in changes to the amounts and allocations recorded.

[0001327567-17-000027:notes:17]
The following table presents details of the identified intangible assets acquired (in millions, except years):

[0001327567-17-000027:notes:18]
|  | Fair Value |  | Estimated Useful Life |
| Developed technology | $ | 16.6 |  |  | 8 years |
| Customer relationships | 2.9 |  |  | 8 years |
| Total | $ | 19.5 |  |  |  |

[0001327567-17-000027:notes:19]
Goodwill generated from this business combination is primarily attributable to the assembled workforce and expected synergies from integrating the LightCyber technology into our platform. The goodwill is not deductible for income tax purposes.

[0001327567-17-000027:notes:20]
LightCyber’s operating results are included in our consolidated statements of operations from the date of acquisition. Pro forma results of operations have not been presented as the impact to our consolidated statements of operations is not material.

[0001327567-17-000027:notes:21]
Fiscal 2015

[0001327567-17-000027:notes:22]
CirroSecure, Inc.

[0001327567-17-000027:notes:23]
On May 22, 2015, we completed our acquisition of CirroSecure, Inc. (“CirroSecure”), a privately-held cybersecurity company. The acquisition expands the functionality of our next-generation security platform by providing additional security for SaaS applications. We accounted for this transaction as a business combination in exchange for total cash consideration of $15.3 million.

[0001327567-17-000027:notes:24]
We allocated the purchase consideration to the assets acquired and liabilities assumed based on their estimated fair values and as a result, recorded a developed technology intangible asset of $11.0 million, goodwill of $8.1 million, and net liabilities of $3.8 million in our consolidated balance sheets as of the acquisition date. The developed technology is being amortized over an estimated useful life of seven years. The goodwill is attributable to the assembled workforce and expected post-acquisition synergies and is not deductible for income tax purposes.


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock

[0001327567-17-000027:notes:25]
Description of Business and Summary of Significant Accounting Policies

[0001327567-17-000027:notes:26]
Description of Business

[0001327567-17-000027:notes:27]
Palo Alto Networks, Inc. (the “Company,” “we,” “us,” or “our”), located in Santa Clara, California, was incorporated in March 2005 under the laws of the State of Delaware and commenced operations in April 2005. We offer a next-generation security platform that empowers enterprises, service providers, and government entities to secure their organizations by safely enabling applications running on their networks and by preventing breaches that stem from targeted cyberattacks.

[0001327567-17-000027:notes:28]
Principles of Consolidation

[0001327567-17-000027:notes:29]
The consolidated financial statements include our accounts and our wholly owned subsidiaries. All significant intercompany balances and transactions have been eliminated in consolidation.

[0001327567-17-000027:notes:30]
Use of Estimates

[0001327567-17-000027:notes:31]
The preparation of consolidated financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the consolidated financial statements and the reported amounts of revenues and expenses during the reporting period. Such management estimates include, but are not limited to the best estimate of selling price for our products and services, share-based compensation, fair value of assets acquired and liabilities assumed in business combinations, the assessment of recoverability of our property and equipment, identified intangibles and goodwill, future taxable income, manufacturing partner and supplier liabilities, and loss contingencies. We base our estimates on historical experience and also on assumptions that we believe are reasonable. Actual results could differ materially from those estimates.

[0001327567-17-000027:notes:32]
Concentrations

[0001327567-17-000027:notes:33]
Financial instruments that subject us to concentrations of credit risk consist primarily of cash and cash equivalents, investments, accounts receivable, and derivative contracts.

[0001327567-17-000027:notes:34]
We invest only in high-quality credit instruments and maintain our cash and cash equivalents and available-for-sale investments in fixed income securities. Management believes that the financial institutions that hold our investments are financially sound and, accordingly, are subject to minimal credit risk. Deposits held with banks may exceed the amount of insurance provided on such deposits.

[0001327567-17-000027:notes:35]
Our derivative contracts expose us to credit risk to the extent that the counterparties may be unable to meet the terms of the arrangement. We mitigate this credit risk by transacting with major financial institutions with high credit ratings and also enter into master netting arrangements, which permit net settlement of transactions with the same counterparty. We are not required to pledge, and are not entitled to receive, cash collateral related to these derivative instruments. We do not enter into derivative contracts for trading or speculative purposes.

[0001327567-17-000027:notes:36]
Our accounts receivables are primarily derived from our distributors representing various geographical locations. We perform ongoing credit evaluations and generally do not require collateral on accounts receivable. We maintain an allowance for doubtful accounts for estimated potential credit losses. As of July 31, 2017, four distributors represented 28.5%, 21.2%, 15.0%, and 11.2% of our gross accounts receivable. For fiscal 2017, three distributors represented 32.4%, 23.3%, and 10.0% of our total revenue.

[0001327567-17-000027:notes:37]
We rely on an electronics manufacturing services provider (“EMS provider”) to assemble most of our products and sole source component suppliers for a certain number of our components.

[0001327567-17-000027:notes:38]
Comprehensive Loss

[0001327567-17-000027:notes:39]
Comprehensive loss is comprised of net loss and other comprehensive income (loss). Our other comprehensive income (loss) includes unrealized gains and losses on available-for-sale investments and unrealized gains and losses on cash flow hedges.

[0001327567-17-000027:notes:40]
Foreign Currency Transactions

[0001327567-17-000027:notes:41]
The functional currency of our foreign subsidiaries is the U.S. dollar. Monetary assets and liabilities denominated in foreign currencies have been remeasured into U.S. dollars using the exchange rates in effect at the balance sheet dates. Foreign currency denominated income and expenses have been remeasured using the average exchange rates in effect during each period. Foreign currency remeasurement gains and losses and foreign currency transaction gains and losses are not significant to the financial statements.

[0001327567-17-000027:notes:42]
Fair Value

[0001327567-17-000027:notes:43]
We define fair value as the price that would be received from selling an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date. When determining the fair value measurements for assets and liabilities which are required to be recorded at fair value, we consider the principal or most advantageous market in which to transact and the market-based risk. We apply fair value accounting for all financial assets and liabilities that are recognized or disclosed at fair value in the financial statements on a recurring basis. Goodwill, intangible assets, and other long-lived assets are measured at fair value on a nonrecurring basis, only if impairment is indicated. The carrying amounts reported in the consolidated financial statements approximate the fair value for cash and cash equivalents, accounts receivable, accounts payable, and accrued liabilities, due to their short-term nature.

[0001327567-17-000027:notes:44]
Cash, Cash Equivalents, and Investments

[0001327567-17-000027:notes:45]
We classify our investments as available-for-sale at the time of purchase since it is our intent that these investments are available for current operations, and include these investments on our consolidated balance sheets as cash equivalents, short-term investments, or long-term investments depending on their maturity.

[0001327567-17-000027:notes:46]
We consider all highly liquid investments with original maturities of three months or less at date of purchase to be cash equivalents. Investments not considered cash equivalents and with maturities one year or less from the consolidated balance sheet date are classified as short-term investments. Investments with maturities greater than one year from the consolidated balance sheet date are classified as long-term investments.

[0001327567-17-000027:notes:47]
Investments are considered impaired when a decline in fair value is judged to be other-than-temporary. We consult with our investment managers and consider available quantitative and qualitative evidence in evaluating potential impairment of our investments on a quarterly basis. If the cost of an individual investment exceeds its fair value, we evaluate, among other factors, general market conditions, the duration and extent to which the fair value is less than cost, and our intent and ability to hold the investment. Once a decline in fair value is determined to be other-than-temporary, an impairment charge is recorded and a new cost basis in the investment is established.

[0001327567-17-000027:notes:48]
Accounts Receivable

[0001327567-17-000027:notes:49]
Trade accounts receivable are recorded at the invoiced amount, net of allowances for doubtful accounts. The allowance for doubtful accounts is based on our assessment of the collectability of accounts. Management regularly reviews the adequacy of the allowance for doubtful accounts by considering the age of each outstanding invoice, each channel partner’s expected ability to pay, and the collection history with each channel partner, when applicable, to determine whether a specific allowance is appropriate. Accounts receivable deemed uncollectible are charged against the allowance for doubtful accounts when identified. As of July 31, 2017 and 2016, the allowance for doubtful accounts activity was not significant.

[0001327567-17-000027:notes:50]
Derivatives

[0001327567-17-000027:notes:51]
Our derivative financial instruments are recorded at fair value, on a gross basis, as either assets or liabilities in our consolidated balance sheets. Gains or losses related to the effective portion of our cash flow hedges are recorded as a component of accumulated other comprehensive income (“AOCI”) in our consolidated balance sheets and are reclassified into the financial statement line item associated with the underlying hedged transaction in our consolidated statements of operations when the underlying hedged transaction is recognized in earnings. Any gains or losses related to the ineffective portion of our cash flow hedges are recorded immediately in other income (expense), net in our consolidated statements of operations. If it becomes probable that the hedged transaction will not occur, the cumulative unrealized gain or loss is reclassified immediately from AOCI into other income (expense), net. Gains or losses related to non-designated derivative instruments are recognized in other income (expense), net each period until the instrument matures, is terminated, is re-designated as a qualified cash flow hedge, or is sold. Derivatives designated as cash flow hedges are classified in our consolidated statements of cash flows in the same manner as the underlying hedged transaction, primarily within cash flows from operating activities.

[0001327567-17-000027:notes:52]
Property and Equipment

[0001327567-17-000027:notes:53]
Property and equipment are stated at cost, less accumulated depreciation. Depreciation is computed using the straight-line method over the estimated useful lives of the assets, generally three to ten years. Leasehold improvements are depreciated over the shorter of the estimated useful lives of the improvements or the remaining lease term.

[0001327567-17-000027:notes:54]
Business Combinations

[0001327567-17-000027:notes:55]
We include the results of operations of the businesses that we acquire as of the respective dates of acquisition. We allocate the fair value of the purchase price of our acquisitions to the tangible assets acquired, liabilities assumed, and intangible assets acquired, based on their estimated fair values. The excess of the purchase price over the fair values of these identifiable assets and liabilities is recorded as goodwill. Additional information existing as of the acquisition date but unknown to us may become known during the remainder of the measurement period, not to exceed 12 months from the acquisition date, which may result in changes to the amounts and allocations recorded.

[0001327567-17-000027:notes:56]
Intangible Assets

[0001327567-17-000027:notes:57]
Purchased intangible assets with finite lives are carried at cost, less accumulated amortization. Amortization is computed over the estimated useful lives of the respective assets. Acquisition-related in-process research and development represents the fair value of incomplete research and development projects that have not reached technological feasibility as of the date of acquisition. Initially, these assets are not subject to amortization. Assets related to projects that have been completed are transferred to developed technology, which are subject to amortization.

[0001327567-17-000027:notes:58]
Impairment of Goodwill, Intangible Assets, and Other Long-Lived Assets

[0001327567-17-000027:notes:59]
Goodwill is evaluated for impairment on an annual basis in the fourth quarter of our fiscal year, and whenever events or changes in circumstances indicate the carrying amount of goodwill may not be recoverable. We have elected to first assess qualitative factors to determine whether it is more likely than not that the fair value of our single reporting unit is less than its carrying amount, including goodwill. If we determine that it is more likely than not that the fair value of our single reporting unit is less than its carrying amount, then the quantitative impairment test will be performed. Under the quantitative impairment test, if the carrying amount of our single reporting unit exceeds its fair value, we will recognize an impairment loss in an amount equal to that excess, but limited to the total amount of goodwill.

[0001327567-17-000027:notes:60]
We evaluate events and changes in circumstances that could indicate carrying amounts of purchased intangible assets and other long-lived assets may not be recoverable. When such events or changes in circumstances occur, we assess the recoverability of these assets by determining whether or not the carrying amount will be recovered through undiscounted expected future cash flows. If the total of the future undiscounted cash flows is less than the carrying amount of an asset, we record an impairment loss for the amount by which the carrying amount of the asset exceeds the fair value of the asset.

[0001327567-17-000027:notes:61]
Through July 31, 2017, we have not recognized any impairment losses on our goodwill and intangible assets. During the year ended July 31, 2017, we recognized an impairment loss of $20.9 million on property and equipment related to the relocation of our corporate headquarters. We did not recognize any impairment losses on our other long-lived assets prior to fiscal 2017.

[0001327567-17-000027:notes:62]
Convertible Senior Notes

[0001327567-17-000027:notes:63]
On June 30, 2014, we issued $575.0 million aggregate principal amount of 0.0% Convertible Senior Notes due 2019 (the “Notes”). In accounting for the issuance of the Notes, we separated the Notes into liability and equity components. The carrying amount of the liability component was calculated by measuring the fair value of a similar liability that does not have an associated convertible feature. The carrying amount of the equity component representing the conversion option was determined by deducting the fair value of the liability component from the par value of the Notes as a whole. This difference represents a debt discount that is amortized to interest expense using the effective interest method over the term of the Notes. The equity component is not remeasured as long as it continues to meet the conditions for equity classification. In accounting for the transaction costs related to the issuance of the Notes, we allocated the total amount incurred to the liability and equity components using the same proportions as the proceeds from the Notes. Transaction costs attributable to the liability component are netted with the liability component and are being amortized to interest expense using the effective interest method over the term of the Notes. Transaction costs attributable to the equity component are netted with the equity component of the Notes in additional paid-in capital in the consolidated balance sheets. When the Notes are convertible, the net carrying amount of the Notes will be classified as a current liability and a portion of the equity component representing the conversion option will be reclassified to temporary equity in our consolidated balance sheets.

[0001327567-17-000027:notes:64]
Revenue Recognition

[0001327567-17-000027:notes:65]
We generate revenue from the sales of hardware and software products, subscriptions, support, and other services primarily through a direct sales force and indirect relationships with channel partners, and, to a lesser extent, directly to end-customers.

[0001327567-17-000027:notes:66]
Revenue is recognized when all of the following criteria are met:

[0001327567-17-000027:notes:67]
| • | Persuasive Evidence of an Arrangement Exists. We rely upon non-cancelable sales agreements and purchase orders to determine the existence of an arrangement. |

[0001327567-17-000027:notes:68]
| • | Delivery has Occurred. We use shipping documents or transmissions of product or subscription and support contract registration codes to determine delivery. |

[0001327567-17-000027:notes:69]
| • | The Fee is Fixed or Determinable. We assess whether the fee is fixed or determinable based on the payment terms associated with the transaction. |

[0001327567-17-000027:notes:70]
| • | Collectability is Reasonably Assured. We assess collectability based on credit analysis and payment history. |

[0001327567-17-000027:notes:71]
We recognize product revenue at the time of shipment provided that all other revenue recognition criteria have been met. Our channel partners generally receive an order from an end-customer prior to placing an order with us. In addition, payment from our channel partners is not contingent on the partner’s success in sales to end-customers. Our channel partners generally do not stock appliances and only have limited stock rotation rights and no price protection rights. When necessary, we make certain estimates and maintain allowances for sales returns and other programs based on our historical experience. To date, these estimates have not been significant. We recognize subscription and support revenue ratably over the contractual service period, which is typically one to five years. Other services revenue is recognized as the services are rendered.

[0001327567-17-000027:notes:72]
Most of our arrangements, other than renewals of subscriptions and support contracts, are multiple-element arrangements with a combination of hardware, software, subscriptions, support, and other services. Products, subscriptions, support, and other services generally qualify as separate units of accounting. Our hardware deliverables typically include proprietary operating system software, which together deliver the essential functionality of our products. For multiple-element arrangements, we allocate revenue to each unit of accounting based on an estimated selling price at the arrangement inception. The estimated selling price for each element is based upon the following hierarchy: vendor-specific objective evidence (“VSOE”) of selling price, if available, third-party evidence (“TPE”) of selling price, if VSOE of selling price is not available, or best estimate of selling price (“BESP”), if neither VSOE of selling price nor TPE of selling price are available. The total arrangement consideration is allocated to each separate unit of accounting using the relative estimated selling prices of each unit based on the aforementioned selling price hierarchy. We limit the amount of revenue recognized for delivered elements to an amount that is not contingent upon future delivery of additional products or services or meeting of any specified performance conditions.

[0001327567-17-000027:notes:73]
In multiple-element arrangements where software deliverables are included, revenue is allocated to each separate unit of accounting for each of the non-software deliverables and to the software deliverables as a group using the relative estimated selling prices of each of the deliverables in the arrangement based on the aforementioned estimated selling price hierarchy. The arrangement consideration allocated to the software deliverables as a group is then allocated to each software deliverable using the residual method when VSOE of fair value of the undelivered items exists. Under the residual method, the amount of revenue allocated to delivered elements equals the total arrangement consideration less the aggregate fair value of any undelivered elements. In determining VSOE of fair value, we evaluate whether a substantial majority of the historical prices charged for a product or service sold on a standalone basis, as represented by a percentage of list price, fall within a reasonably narrow range. If VSOE of fair value of one or more undelivered items does not exist, revenue from the software portion of the arrangement is deferred and recognized at the earlier of: (i) delivery of those elements or (ii) when fair value can be established unless support is the only undelivered element, in which case, the entire software arrangement fee is recognized ratably over the contractual service period.

[0001327567-17-000027:notes:74]
We account for multiple agreements with a single partner as one arrangement if the contractual terms and/or substance of those agreements indicate that they may be so closely related that they are, in effect, parts of a single arrangement.

[0001327567-17-000027:notes:75]
Revenues are reported net of sales taxes. Shipping charges billed to channel partners are included in revenues and related costs are included in cost of revenue. After receipt of a partner order, any amounts billed in excess of revenue recognized are recorded as deferred revenue.

[0001327567-17-000027:notes:76]
Deferred Commissions

[0001327567-17-000027:notes:77]
Sales commissions that are incremental and directly related to non-cancelable customer sales contracts are deferred and amortized over the term of the related contract in proportion to the recognized revenue. Refer to “Change in Accounting Policy for Sales Commissions” below for more information.

[0001327567-17-000027:notes:78]
Advertising Costs

[0001327567-17-000027:notes:79]
Advertising costs, which are expensed and included in sales and marketing expense when incurred, were $13.7 million, $6.6 million, and $4.8 million, during the years ended July 31, 2017, 2016, and 2015, respectively.

[0001327567-17-000027:notes:80]
Software Development Costs

[0001327567-17-000027:notes:81]
Internally developed software includes security software developed to meet our internal needs to provide cloud-based subscription services to our end-customers and business software that we customize to meet our specific operational needs. These capitalized costs consist of internal compensation related costs and external direct costs incurred during the application development stage and will be amortized over a useful life of three to five years.

[0001327567-17-000027:notes:82]
The costs to develop software that is marketed externally have not been capitalized as we believe our current software development process is essentially completed concurrent with the establishment of technological feasibility. As such, all related software development costs are expensed as incurred and included in research and development expense in our consolidated statements of operations.

[0001327567-17-000027:notes:83]
Share-Based Compensation

[0001327567-17-000027:notes:84]
Compensation expense related to share-based transactions, including employee and non-employee director awards, is measured and recognized in the financial statements based on fair value on the grant date. We recognize share-based compensation expense for awards with only service conditions on a straight-line basis over the requisite service period of the related award and recognize share-based compensation expense for awards with performance conditions on a straight-line basis over the requisite service period for each separately vesting portion of the award when it is probable that the performance condition will be achieved. We account for forfeitures of all share-based payment awards when they occur.

[0001327567-17-000027:notes:85]
Leases

[0001327567-17-000027:notes:86]
We rent our facilities under operating lease agreements and recognize related rent expense on a straight-line basis over the term of the lease. Some of our lease agreements contain rent holidays, scheduled rent increases, lease incentives, and renewal options. Rent holidays and scheduled rent increases are included in the determination of rent expense to be recorded over the lease term. Lease incentives are recognized as a reduction of rent expense on a straight-line basis over the term of the lease. Renewals are not assumed in the determination of the lease term unless they are deemed to be reasonably assured at the inception of the lease. We begin recognizing rent expense on the date that we obtain the legal right to use and control the leased space.

[0001327567-17-000027:notes:87]
Income Taxes

[0001327567-17-000027:notes:88]
We account for income taxes using the asset and liability method, which requires the recognition of deferred tax assets and liabilities for the expected future tax consequences of events that have been recognized in our financial statements or tax returns. In addition, deferred tax assets are recorded for the future benefit of utilizing net operating losses and research and development credit carryforwards. Valuation allowances are provided when necessary to reduce deferred tax assets to the amount expected to be realized.

[0001327567-17-000027:notes:89]
Significant judgment is required in determining any valuation allowance recorded against deferred tax assets. In assessing the need for a valuation allowance, we consider all available evidence, including past operating results, estimates of future taxable income, and the feasibility of tax planning strategies. In the event that we change our determination as to the amount of deferred tax assets that can be realized, we will adjust our valuation allowance with a corresponding impact to the provision for income taxes in the period in which such determination is made.

[0001327567-17-000027:notes:90]
We apply the authoritative accounting guidance prescribing a threshold and measurement attribute for the financial recognition and measurement of a tax position taken or expected to be taken in a tax return. We recognize liabilities for uncertain tax positions based on a two-step process. The first step is to evaluate the tax position for recognition by determining if the weight of available evidence indicates that it is more likely than not that the position will be sustained on audit, including resolution of related appeals or litigation processes, if any. The second step requires us to estimate and measure the tax benefit as the largest amount that is more likely than not to be realized upon ultimate settlement.

[0001327567-17-000027:notes:91]
We record deferred tax charges in prepaid expenses and other current assets and other assets on our consolidated balance sheets. These deferred tax charges are amortized on a straight-line basis over the life of the associated assets as a component of provision for income taxes in our consolidated statements of operations.

[0001327567-17-000027:notes:92]
Loss Contingencies

[0001327567-17-000027:notes:93]
We are subject to the possibility of various loss contingencies arising in the ordinary course of business. In determining loss contingencies, we consider the likelihood of loss or impairment of an asset, or the incurrence of a liability, as well as our ability to reasonably estimate the amount of loss. An estimated loss contingency is accrued when it is probable that an asset has been impaired or a liability has been incurred and the amount of loss can be reasonably estimated. If we determine that a loss is possible and the range of the loss can be reasonably determined, then we disclose the range of the possible loss. We regularly evaluate current information available to us to determine whether an accrual is required, an accrual should be adjusted or a range of possible loss should be disclosed.

[0001327567-17-000027:notes:94]
Change in Accounting Policy for Sales Commissions

[0001327567-17-000027:notes:95]
Effective August 1, 2016, we voluntarily changed our accounting policy for sales commissions that are incremental and directly related to non-cancelable customer sales contracts from recording an expense when incurred to deferral and amortization of the sales commissions over the term of the related contract in proportion to the recognized revenue. We believe this change in accounting policy is preferable as the direct and incremental commission costs are closely related to the associated revenue, and therefore should be deferred and recognized as an expense over the same period that the related revenue is recognized.

[0001327567-17-000027:notes:96]
Short-term deferred commissions are included in prepaid expenses and other current assets, while long-term deferred commissions are included in other assets in our consolidated balance sheets. The amortization of deferred commissions is included in sales and marketing expense in our consolidated statements of operations.

[0001327567-17-000027:notes:97]
The adoption of this accounting policy change has been applied retrospectively to all prior periods presented in this Annual Report on Form 10-K, in which the cumulative effect of the change of $38.1 million has been reflected in accumulated deficit as of August 1, 2014, the beginning of the earliest period presented.

[0001327567-17-000027:notes:98]
The following tables present the changes to financial statement line items as a result of the accounting policy change for the periods presented in our consolidated financial statements (in millions, except per share data):

[0001327567-17-000027:notes:99]
|  | July 31, 2017 |  | July 31, 2016 |
|  | Computed under Prior Method |  | Impact of Commission Adjustment |  | As Reported |  | As Previously Reported |  | Impact of Commission Adjustment |  | As Adjusted |
| Consolidated Balance Sheets |  |  |  |  |  |  |  |  |  |  |  |
| Prepaid expenses and other current assets | $ | 95.8 |  |  | $ | 73.4 |  |  | $ | 169.2 |  |  | $ | 84.8 |  |  | $ | 54.9 |  |  | $ | 139.7 |  |
| Other assets | 97.8 |  |  | 71.3 |  |  | 169.1 |  |  | 64.6 |  |  | 50.1 |  |  | 114.7 |  |
| Accumulated deficit | $ | (981.4 | ) |  | $ | 144.7 |  |  | $ | (836.7 | ) |  | $ | (726.6 | ) |  | $ | 105.0 |  |  | $ | (621.6 | ) |

[0001327567-17-000027:notes:100]
|  | Year Ended July 31, 2017 |
|  | Computed under Prior Method |  | Impact of Commission Adjustment |  | As Reported |
| Consolidated Statements of Operations |  |  |  |  |  |
| Sales and marketing | $ | 958.4 |  |  | $ | (39.3 | ) |  | $ | 919.1 |  |
| Operating loss | (219.1 | ) |  | 39.3 |  |  | (179.8 | ) |
| Provision for income taxes | 22.9 |  |  | (0.4 | ) |  | 22.5 |  |
| Net loss | $ | (256.3 | ) |  | $ | 39.7 |  |  | $ | (216.6 | ) |
| Net loss per share, basic and diluted | $ | (2.83 | ) |  | $ | 0.44 |  |  | $ | (2.39 | ) |
| Weighted-average shares used to compute net loss per share, basic and diluted | 90.6 |  |  | — |  |  | 90.6 |  |
| Consolidated Statements of Comprehensive Loss |  |  |  |  |  |
| Net loss | $ | (256.3 | ) |  | $ | 39.7 |  |  | $ | (216.6 | ) |
| Comprehensive loss | $ | (260.7 | ) |  | $ | 39.7 |  |  | $ | (221.0 | ) |

[0001327567-17-000027:notes:101]
|  | Year Ended July 31, 2016 |
|  | As Previously Reported |  | Impact of Commission Adjustment |  | As Adjusted |
| Consolidated Statements of Operations |  |  |  |  |  |
| Sales and marketing | $ | 776.0 |  |  | $ | (32.8 | ) |  | $ | 743.2 |  |
| Operating loss | (190.1 | ) |  | 32.8 |  |  | (157.3 | ) |
| Provision for income taxes | 20.8 |  |  | (0.4 | ) |  | 20.4 |  |
| Net loss | $ | (225.9 | ) |  | $ | 33.2 |  |  | $ | (192.7 | ) |
| Net loss per share, basic and diluted | $ | (2.59 | ) |  | $ | 0.38 |  |  | $ | (2.21 | ) |
| Weighted-average shares used to compute net loss per share, basic and diluted | 87.1 |  |  | — |  |  | 87.1 |  |
| Consolidated Statements of Comprehensive Loss |  |  |  |  |  |
| Net loss | $ | (225.9 | ) |  | $ | 33.2 |  |  | $ | (192.7 | ) |
| Comprehensive loss | $ | (224.8 | ) |  | $ | 33.2 |  |  | $ | (191.6 | ) |

[0001327567-17-000027:notes:102]
|  | Year Ended July 31, 2015 |
|  | As Previously Reported |  | Impact of Commission Adjustment |  | As Adjusted |
| Consolidated Statements of Operations |  |  |  |  |  |
| Sales and marketing | $ | 522.7 |  |  | $ | (33.7 | ) |  | $ | 489.0 |  |
| Operating loss | (133.5 | ) |  | 33.7 |  |  | (99.8 | ) |
| Provision for income taxes | 9.4 |  |  | — |  |  | 9.4 |  |
| Net loss | $ | (165.0 | ) |  | $ | 33.7 |  |  | $ | (131.3 | ) |
| Net loss per share, basic and diluted | $ | (2.02 | ) |  | $ | 0.41 |  |  | $ | (1.61 | ) |
| Weighted-average shares used to compute net loss per share, basic and diluted | 81.6 |  |  | — |  |  | 81.6 |  |
| Consolidated Statements of Comprehensive Loss |  |  |  |  |  |
| Net loss | $ | (165.0 | ) |  | $ | 33.7 |  |  | $ | (131.3 | ) |
| Comprehensive loss | $ | (165.0 | ) |  | $ | 33.7 |  |  | $ | (131.3 | ) |

[0001327567-17-000027:notes:103]
This change in accounting policy does not affect our balance of cash and cash equivalents and, as a result, did not change net cash flows from operating, investing, or financing activities, or materially impact any individual line items presented in our consolidated statement of cash flows for the years ended July 31, 2016 and 2015.

[0001327567-17-000027:notes:104]
Recently Adopted Accounting Pronouncements

[0001327567-17-000027:notes:105]
Goodwill Impairment

[0001327567-17-000027:notes:106]
In January 2017, the Financial Accounting Standards Board (“FASB”) issued authoritative guidance simplifying the subsequent measurement of goodwill. The standard eliminates Step 2 of the current goodwill impairment test, which requires companies to determine the implied fair value of goodwill when measuring the amount of impairment loss. Under the new standard, goodwill impairment will be measured as the amount by which a reporting unit’s carrying value exceeds its fair value, with the loss limited to the total amount of goodwill allocated to that reporting unit. We elected to early adopt the standard in our fourth quarter of fiscal 2017 on a prospective basis. Our adoption of this standard did not have an impact on our consolidated financial statements.

[0001327567-17-000027:notes:107]
Share-Based Payment Accounting

[0001327567-17-000027:notes:108]
In March 2016, the FASB issued authoritative guidance simplifying several aspects of the accounting for employee share-based payment transactions. The new standard requires us to recognize excess tax benefits or deficiencies as income tax expense or benefit in the period in which they occur, rather than additional paid-in capital, and also requires us to recognize excess tax benefits regardless of whether the benefit reduces taxes payable in the current period. In addition, excess tax benefits should be classified as an operating activity, along with other income tax cash flows, instead of a financing activity in our consolidated statements of cash flows. The standard also allows us to make an accounting policy election to account for forfeitures of share-based payment awards when they occur, rather than estimate expected forfeitures.

[0001327567-17-000027:notes:109]
We elected to early adopt the standard in our second quarter of fiscal 2017, which required us to reflect any adjustments related to the adoption as of the beginning of the fiscal year. The impact of the adoption on our consolidated financial statements was as follows:

[0001327567-17-000027:notes:110]
| • | Income tax accounting - We adopted the guidance related to the timing of when excess tax benefits are recognized on a modified retrospective basis. As a result, we recorded the cumulative effect of the change as a $3.5 million reduction to accumulated deficit as of August 1, 2016, to reflect the recognition of excess tax benefits in prior years, with a corresponding adjustment to deferred tax assets and long-term tax liabilities. We adopted the guidance related to the recognition of excess tax benefits and deficiencies as income tax expense or benefit on a prospective basis. |

[0001327567-17-000027:notes:111]
| • | Cash flow presentation of excess tax benefits - We elected to adopt the guidance related to the presentation of excess tax benefits in our consolidated statements of cash flows on a retrospective basis, which increased net cash provided by operating activities by $0.5 million and $2.5 million for the years ended July 31, 2016 and 2015, respectively, with corresponding decreases to net cash provided by financing activities. |

[0001327567-17-000027:notes:112]
| • | Forfeitures - We elected to account for forfeitures when they occur and adopted this change on a modified retrospective basis. As a result, we recorded the cumulative effect of the change as a $2.0 million increase to accumulated deficit as of August 1, 2016. |

[0001327567-17-000027:notes:113]
The adoption of the standard also impacted our previously reported results for the three months ended October 31, 2016, as presented in the following tables (in millions, except per share data):

[0001327567-17-000027:notes:114]
|  | October 31, 2016 |
|  | As Previously Reported |  | Impact of Adoption |  | As Adjusted |
| Consolidated Balance Sheets |  |  |  |  |  |
| Other assets | $ | 102.0 |  |  | $ | 1.7 |  |  | $ | 103.7 |  |
| Other long-term liabilities | 85.8 |  |  | (5.6 | ) |  | 80.2 |  |
| Common stock and additional paid-in capital | 1,542.2 |  |  | 0.9 |  |  | 1,543.1 |  |
| Accumulated deficit | $ | (683.4 | ) |  | $ | 6.4 |  |  | $ | (677.0 | ) |

[0001327567-17-000027:notes:115]
|  | Three Months Ended October 31, 2016 |
|  | As Previously Reported |  | Impact of Adoption |  | As Adjusted |
| Consolidated Statements of Operations |  |  |  |  |  |
| Total cost of revenue(1) | $ | 101.3 |  |  | $ | (0.1 | ) |  | $ | 101.2 |  |
| Total operating expenses(1) | 346.7 |  |  | (0.8 | ) |  | 345.9 |  |
| Provision for income taxes | 8.4 |  |  | (4.0 | ) |  | 4.4 |  |
| Net loss | $ | (61.8 | ) |  | $ | 4.9 |  |  | $ | (56.9 | ) |
| Net loss per share, basic and diluted | $ | (0.69 | ) |  | $ | 0.06 |  |  | $ | (0.63 | ) |
| Weighted-average shares used to compute net loss per share, basic and diluted | 89.8 |  |  | — |  |  | 89.8 |  |
| Consolidated Statements of Comprehensive Loss |  |  |  |  |  |
| Net loss | $ | (61.8 | ) |  | $ | 4.9 |  |  | $ | (56.9 | ) |
| Comprehensive loss | $ | (64.7 | ) |  | $ | 4.9 |  |  | $ | (59.8 | ) |
| Consolidated Statements of Cash Flows |  |  |  |  |  |
| Net cash provided by operating activities | $ | 203.3 |  |  | $ | 0.2 |  |  | $ | 203.5 |  |
| Net cash used in financing activities | $ | (27.1 | ) |  | $ | (0.2 | ) |  | $ | (27.3 | ) |

[0001327567-17-000027:notes:116]
______________

[0001327567-17-000027:notes:117]
| (1) | Adjustments consist of share-based compensation, which was impacted by our policy election to account for forfeitures when they occur. The impact of adoption on each cost and expense line item within these subtotals was not significant. |

[0001327567-17-000027:notes:118]
Cloud Computing Arrangements

[0001327567-17-000027:notes:119]
In April 2015, the FASB issued new authoritative guidance on fees paid in a cloud computing arrangement. The standard requires customers in a cloud computing arrangement to evaluate whether the arrangement includes a software license. If the arrangement includes a software license, the customer should account for the software license element of the arrangement consistent with the acquisition of other software licenses. If the arrangement does not include a software license, the customer should account for the arrangement as a service contract. We adopted the standard in our first quarter of fiscal 2017 on a prospective basis. Our adoption of this standard did not have a material impact on our consolidated financial statements.

[0001327567-17-000027:notes:120]
Debt Issuance Costs

[0001327567-17-000027:notes:121]
In April 2015, the FASB issued updated authoritative guidance to simplify the presentation of debt issuance costs. The amended standard requires that debt issuance costs related to a recognized debt liability be presented in the balance sheet as a direct deduction from the carrying amount of the related debt liability, consistent with the presentation of debt discounts, instead of being presented as an asset. We adopted the standard in our first quarter of fiscal 2017 on a retrospective basis, and as a result, we reduced other assets and convertible senior notes, net by $8.0 million on our consolidated balance sheets as of July 31, 2016.

[0001327567-17-000027:notes:122]
Recently Issued Accounting Pronouncements

[0001327567-17-000027:notes:123]
Business Combinations - Definition of a Business

[0001327567-17-000027:notes:124]
In January 2017, the FASB issued authoritative guidance clarifying the definition of a business to assist companies with evaluating whether transactions should be accounted for as acquisitions (or disposals) of assets or businesses. The standard is effective for us for our first quarter of fiscal 2019 and will be applied on a prospective basis. Early adoption is permitted. We do not expect the adoption of the standard will have a material impact on our consolidated financial statements.

[0001327567-17-000027:notes:125]
Statement of Cash Flows - Restricted Cash

[0001327567-17-000027:notes:126]
In November 2016, the FASB issued authoritative guidance on the presentation of restricted cash or restricted cash equivalents in the statement of cash flows. Under the new standard, restricted cash or restricted cash equivalents should be included with cash and cash equivalents when reconciling the beginning-of-period and end-of-period total amounts shown on the statement of cash flows. The standard is effective for us for our first quarter of fiscal 2019 and will be applied on a retrospective basis. Early adoption is permitted. We do not expect the adoption of the standard will have a material impact on our consolidated financial statements because our restricted cash balance has not been material.

[0001327567-17-000027:notes:127]
Income Taxes - Intra-Entity Asset Transfers

[0001327567-17-000027:notes:128]
In October 2016, the FASB issued authoritative guidance requiring the recognition of income tax consequences of an intra-entity transfer of an asset, other than inventory, when the transfer occurs. The standard is effective for us for our first quarter of fiscal 2019 and will be applied on a modified retrospective basis. Early adoption is permitted. We plan to adopt the standard in our first quarter of fiscal 2019 and are currently evaluating whether this standard will have a material impact on our consolidated financial statements.

[0001327567-17-000027:notes:129]
Statement of Cash Flows - Classification of Certain Cash Receipts and Cash Payments

[0001327567-17-000027:notes:130]
In August 2016, the FASB issued new authoritative guidance addressing eight specific cash flow issues with the objective of reducing the existing diversity in practice in how certain transactions are presented and classified in the statement of cash flows. The standard is effective for us for our first quarter of fiscal 2019 and will be applied on a retrospective basis. Early adoption is permitted. We do not expect the adoption of the standard will have a material impact on our consolidated financial statements.

[0001327567-17-000027:notes:131]
Financial Instruments - Credit Losses

[0001327567-17-000027:notes:132]
In June 2016, the FASB issued new authoritative guidance on the accounting for credit losses on most financial assets and certain financial instruments. The standard replaces the existing incurred loss model with an expected credit loss model for financial assets measured at amortized cost, including trade receivables, and requires that credit losses on available-for-sale debt securities be presented as an allowance rather than as a write-down. The standard is effective for us for our first quarter of fiscal 2021 and will be applied on a modified retrospective basis. Early adoption is permitted beginning our first quarter of fiscal 2020. We are currently evaluating whether this standard will have a material impact on our consolidated financial statements.

[0001327567-17-000027:notes:133]
In February 2016, the FASB issued new authoritative guidance on lease accounting. Among its provisions, the standard requires lessees to recognize right-of-use assets and lease liabilities on the balance sheet for operating leases and also requires additional qualitative and quantitative disclosures about lease arrangements. The standard is effective for us for our first quarter of fiscal 2020 and will be applied on a modified retrospective basis, with the option to elect certain practical expedients. Early adoption is permitted. We are currently evaluating whether this standard will have a material impact on our consolidated financial statements.

[0001327567-17-000027:notes:134]
In May 2014, the FASB issued new authoritative guidance on revenue from contracts with customers. The new standard provides principles for recognizing revenue for the transfer of promised goods or services to customers with the consideration to which the entity expects to be entitled in exchange for those goods or services. The standard also requires significantly expanded disclosures about revenue recognition. The FASB subsequently delayed the effective date of the standard by one year and as a result, the standard is now effective for us for our first quarter of fiscal 2019 using either of two methods: (i) retrospective to each prior reporting period presented with the option to elect certain practical expedients as defined within the guidance (“full retrospective method”); or (ii) retrospective with the cumulative effect of initially applying the guidance recognized at the date of initial application and providing certain additional disclosures as defined per the guidance (“modified retrospective method”). Early adoption as of the original effective date is permitted.

[0001327567-17-000027:notes:135]
We do not plan to early adopt the new standard, and accordingly, we will adopt the standard in our first quarter of fiscal 2019. We currently plan to adopt using the full retrospective method, however, our ability to apply the full retrospective method is dependent on system readiness and the completion of our analysis of information necessary to restate prior period financial statements.

[0001327567-17-000027:notes:136]
We are continuing to evaluate the impact of the new standard on our accounting policies, processes, internal controls over financial reporting, and system requirements, and have assigned cross-functional internal resources and engaged third-party service providers to assist in our evaluation and system implementation. Furthermore, we have made and will continue to make investments in systems to enable timely and accurate reporting under the new standard.

[0001327567-17-000027:notes:137]
We are also continuing to evaluate the impact the standard will have on our consolidated financial statements, including reviewing the provisions of our customer contracts and identifying performance obligations under the requirements of the new standard and comparing to our current accounting policies and practices. Although we have not yet determined whether the effect will be material, we believe the new standard will impact our accounting for revenue arrangements in the following areas:

[0001327567-17-000027:notes:138]
| • | removal of the current limitation on contingent revenue may result in revenue being recognized earlier for certain contracts; |

[0001327567-17-000027:notes:139]
| • | term license revenue associated with our virtual firewalls will be recognized upfront; |

[0001327567-17-000027:notes:140]
| • | allocation of revenue related to software due to the removal of the residual method of revenue recognition; and |

[0001327567-17-000027:notes:141]
| • | amortization period for deferred commissions. |

[0001327567-17-000027:notes:142]
We will continue to assess the new standard along with industry trends and additional interpretive guidance, and may adjust our implementation plan accordingly.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001327567-17-000027:notes:143]
Commitments and Contingencies

[0001327567-17-000027:notes:144]
We lease our facilities under various non-cancelable operating leases, which expire through the year ending July 31, 2028.

[0001327567-17-000027:notes:145]
In May 2015, we entered into two lease agreements for a total of approximately 631,000 square feet of corporate office space in Santa Clara, California, which serves as our new corporate headquarters. The leases commenced in August 2017 and expire in July 2028. In October 2015, we entered into a third lease agreement for approximately 310,000 square feet of additional office space, which is also part of our new corporate headquarters. This lease will commence in April 2018 and expires in July 2028. The leases contain a rent holiday period, scheduled rent increases, lease incentives, and renewal options which allow the lease terms to be extended through July 2046. Rental payments under the three lease agreements are approximately $373.8 million over the lease term.

[0001327567-17-000027:notes:146]
In May 2015, we also entered into a lease agreement for approximately 122,000 square feet of space in Santa Clara, California to serve as an extension of our previous corporate headquarters. The lease commenced in February 2016 and expires in April 2021. The lease contains scheduled rent increases, lease incentives, and renewal options which allow the lease term to be extended through July 2046. Rental payments under the lease agreement is approximately $23.1 million over the lease term.

[0001327567-17-000027:notes:147]
In September 2012, we entered into two lease agreements for a total of approximately 300,000 square feet of space in Santa Clara, California, which served as our previous corporate headquarters through August 2017, when we relocated to our new corporate campus. The leases commenced in November 2012 and August 2013, expire in July 2023, and allow for two separate five-year options to extend the lease term. Payments under these leases are approximately $94.3 million over the lease term. Each lease has a rent holiday, which was included in the determination of rent expense.

[0001327567-17-000027:notes:148]
In July 2013, we entered into a 51-month sub-lease agreement for our prior corporate headquarters with a commencement date of January 2014. Net proceeds from this sub-lease are approximately $10.7 million over the lease term.

[0001327567-17-000027:notes:149]
We recognized rent expense of $35.9 million, $20.2 million, and $15.4 million for the years ended July 31, 2017, 2016, and 2015, respectively. Rent expense is recognized on a straight-line basis over the term of the lease.

[0001327567-17-000027:notes:150]
The following table presents details of the aggregate future non-cancelable minimum rental payments under our operating leases as of July 31, 2017 (in millions):

[0001327567-17-000027:notes:151]
|  | Amount |
| Years ending July 31: |  |
| 2018 | $ | 31.0 |  |
| 2019 | 50.7 |  |
| 2020 | 60.1 |  |
| 2021 | 57.3 |  |
| 2022 | 53.9 |  |
| 2023 and thereafter | 264.5 |  |
| Committed gross lease payments | 517.5 |  |
| Less: proceeds from sublease rental | 2.1 |  |
| Net operating lease obligation | $ | 515.4 |  |

[0001327567-17-000027:notes:152]
Facility Exit Costs

[0001327567-17-000027:notes:153]
To support the growth of our business, in the fourth quarter of fiscal 2017, we committed to plans to relocate our corporate headquarters and sublet our previous headquarter facilities. In connection with the planned relocation, we determined, as of July 31, 2017, that certain leasehold improvements and other long-lived assets associated with our previous facilities were impaired and recognized a loss of $20.9 million in general and administrative expense in our consolidated statements of operations during the year ended July 31, 2017. Refer to Note 2. Fair Value Measurements for more information on our impairment assessment.

[0001327567-17-000027:notes:154]
We exited our previous headquarter facilities and relocated to our new corporate campus in August 2017. Refer to Note 18. Subsequent Events for more information.

[0001327567-17-000027:notes:155]
Manufacturing Purchase Commitments

[0001327567-17-000027:notes:156]
Our EMS provider procures components and assembles our products based on our forecasts. These forecasts are based on estimates of demand for our products primarily for the next 12 months, which are in turn based on historical trends and an analysis from our sales and product management organizations, adjusted for overall market conditions. In order to reduce manufacturing lead times and plan for adequate supply, we may issue non-cancelable orders for products and components to our manufacturing partners or component suppliers. As of July 31, 2017, our purchase commitments under such orders were $104.1 million, of which $5.6 million represent long-term purchase commitments through the year ending July 31, 2019, excluding obligations under contracts that we can cancel without a significant penalty.

[0001327567-17-000027:notes:157]
Litigation

[0001327567-17-000027:notes:158]
We are subject to legal proceedings, claims, and litigation arising in the ordinary course of business, including intellectual property litigation. Such matters are subject to many uncertainties and outcomes are not predictable with assurance. We accrue for contingencies when we believe that a loss is probable and that we can reasonably estimate the amount of any such loss.

[0001327567-17-000027:notes:159]
To the extent there is a reasonable possibility that a loss exceeding amounts already recognized may be incurred and the amount of such additional loss would be material, we will either disclose the estimated additional loss or state that such an estimate cannot be made. As of July 31, 2017, we have not recorded any significant accruals for loss contingencies associated with such legal proceedings, determined that an unfavorable outcome is probable or reasonably possible, or determined that the amount or range of any possible loss is reasonably estimable.

[0001327567-17-000027:notes:160]
Indemnification

[0001327567-17-000027:notes:161]
Under the indemnification provisions of our standard sales related contracts, we agree to defend our end-customers against third-party claims asserting infringement of certain intellectual property rights, which may include patents, copyrights, trademarks, or trade secrets, and to pay judgments entered on such claims. Our exposure under these indemnification provisions is generally limited to payments made to us for the alleged infringing products over the preceding twelve months under the agreement. However, certain agreements include indemnification provisions that could potentially expose us to losses in excess of these payments. In addition, we indemnify our officers, directors, and certain key employees while they are serving in good faith in their company capacities. To date, we have not recorded any accruals for loss contingencies associated with indemnification claims or determined that an unfavorable outcome is probable or reasonably possible.


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0001327567-17-000027:notes:162]
Employee Benefit Plan

[0001327567-17-000027:notes:163]
We have established a 401(k) tax-deferred savings plan which permits participants to make contributions by salary deduction pursuant to Section 401(k) of the Internal Revenue Code. In fiscal 2016, we began to make matching contributions based upon the amount of employees’ contributions, subject to certain limitations. Our matching contributions to the plan were immaterial for the years ended July 31, 2017 and 2016.


## us-gaap:ConvertibleDebtTableTextBlock

[0001327567-17-000027:notes:164]
The following table sets forth the components of the Notes as of July 31, 2017 and July 31, 2016 (in millions):

[0001327567-17-000027:notes:165]
|  | July 31, |
|  | 2017 |  | 2016 |
| Liability: |  |  |  |
| Principal | $ | 575.0 |  |  | $ | 575.0 |  |
| Less: debt discount and debt issuance costs, net of amortization | 50.3 |  |  | 74.8 |  |
| Net carrying amount | $ | 524.7 |  |  | $ | 500.2 |  |
| Equity | $ | 109.8 |  |  | $ | 109.8 |  |


## us-gaap:DebtDisclosureTextBlock

[0001327567-17-000027:notes:166]
On June 30, 2014, we issued $575.0 million aggregate principal amount of 0.0% Convertible Senior Notes due 2019 (the “Notes”). The Notes are governed by an indenture between us, as the issuer, and U.S. Bank National Association, as Trustee (the “Indenture”). The Notes are unsecured, unsubordinated obligations that do not contain any financial covenants or restrictions on the payments of dividends, the incurrence of indebtedness, or the issuance or repurchase of securities by us or any of our subsidiaries. The Notes mature on July 1, 2019 unless converted or repurchased in accordance with their terms prior to such date. We cannot redeem the Notes prior to maturity.

[0001327567-17-000027:notes:167]
The Notes are convertible for up to 5.2 million shares of our common stock at an initial conversion rate of approximately 9.068 shares of common stock per $1,000 principal amount, which is equal to an initial conversion price of approximately $110.28 per share of common stock, subject to adjustment. Holders of the Notes may surrender their Notes for conversion at their option at any time prior to the close of business on the business day immediately preceding January 1, 2019, only under the following circumstances:

[0001327567-17-000027:notes:168]
| • | during any fiscal quarter commencing after the fiscal quarter ending on October 31, 2014 (and only during such fiscal quarter), if the last reported sale price of our common stock for at least 20 trading days (whether or not consecutive) during a period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the conversion price for the Notes on each applicable trading day (the “sale price condition”); |

[0001327567-17-000027:notes:169]
| • | during the five business day period after any five consecutive trading day period, in which the trading price per $1,000 principal amount of Notes for each trading day of the measurement period was less than 98% of the product of the last reported sale price of our common stock and the conversion rate for the Notes on each such trading day; or |

[0001327567-17-000027:notes:170]
| • | upon the occurrence of specified corporate events. |

[0001327567-17-000027:notes:171]
On or after January 1, 2019, holders may convert all or any portion of their Notes at any time prior to the close of business on the second scheduled trading day immediately preceding the maturity date regardless of the foregoing conditions. Upon conversion, holders will receive cash equal to the aggregate principal amount of the Notes to be converted, and, at our election, cash and/or shares of our common stock for any amounts in excess of the aggregate principal amount of the Notes being converted.

[0001327567-17-000027:notes:172]
The conversion price will be subject to adjustment in some events. Holders of the Notes who convert their Notes in connection with certain corporate events that constitute a “make-whole fundamental change” per the Indenture are, under certain circumstances, entitled to an increase in the conversion rate. Additionally, upon the occurrence of a corporate event that constitutes a “fundamental change” per the Indenture, holders of the Notes may require us to repurchase for cash all or a portion of the Notes at a purchase price equal to 100% of the principal amount of the Notes plus accrued and unpaid contingent interest.

[0001327567-17-000027:notes:173]
The sale price condition was not met during the fiscal quarters ended July 31, 2017 and July 31, 2016. Since the Notes were not convertible, the net carrying amount of the Notes was classified as a long-term liability and the equity component was included in additional paid-in capital in our consolidated balance sheets as of July 31, 2017 and July 31, 2016.

[0001327567-17-000027:notes:174]
The total estimated fair value of the Notes was $747.5 million and $761.9 million at July 31, 2017 and July 31, 2016, respectively. The fair value was determined based on the closing trading price per $100 of the Notes as of the last day of trading for the period. We consider the fair value of the Notes at July 31, 2017 and July 31, 2016 to be a Level 2 measurement. The fair value of the Notes is primarily affected by the trading price of our common stock and market interest rates. As of July 31, 2017, the if-converted value of the Notes exceeded its principal amount by $137.7 million.

[0001327567-17-000027:notes:175]
The following table sets forth interest expense recognized related to the Notes (dollars in millions):

[0001327567-17-000027:notes:176]
|  | Year Ended July 31, |
|  | 2017 |  | 2016 |  | 2015 |
| Amortization of debt discount | $ | 22.0 |  |  | $ | 21.1 |  |  | $ | 20.2 |  |
| Amortization of debt issuance costs | 2.5 |  |  | 2.3 |  |  | 2.1 |  |
| Total interest expense recognized | $ | 24.5 |  |  | $ | 23.4 |  |  | $ | 22.3 |  |
| Effective interest rate of the liability component | 4.8 | % |  | 4.8 | % |  | 4.8 | % |

[0001327567-17-000027:notes:177]
Note Hedges

[0001327567-17-000027:notes:178]
To minimize the impact of potential economic dilution upon conversion of the Notes, we entered into convertible note hedge transactions (the “Note Hedges”) with respect to our common stock concurrent with the issuance of the Notes. The Note Hedges cover up to 5.2 million shares of our common stock at a strike price per share that corresponds to the initial conversion price of the Notes, which are also subject to adjustment, and are exercisable upon conversion of the Notes. The Note Hedges will expire upon maturity of the Notes. The Note Hedges are separate transactions and are not part of the terms of the Notes. Holders of the Notes will not have any rights with respect to the Note Hedges. The shares receivable related to the Note Hedges are excluded from the calculation of diluted earnings per share as they are antidilutive. We paid an aggregate amount of $111.0 million for the Note Hedges, which is included in additional paid-in capital in our consolidated balance sheets.

[0001327567-17-000027:notes:179]
Warrants

[0001327567-17-000027:notes:180]
Separately, but concurrently with our issuance of the Notes, we entered into transactions whereby we sold warrants (the “Warrants”) to acquire up to 5.2 million shares of our common stock at a strike price of approximately $137.85 per share, subject to adjustments. The shares issuable under the Warrants will be included in the calculation of diluted earnings per share when the average market value per share of our common stock for the reporting period exceeds the strike price of the Warrants. The Warrants are separate transactions and are not part of the Notes or Note Hedges, and are not remeasured through earnings each reporting period. Holders of the Notes and Note Hedges will not have any rights with respect to the Warrants. We received aggregate proceeds of $78.3 million from the sale of the Warrants, which is included in additional paid-in capital in our consolidated balance sheets.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001327567-17-000027:notes:181]
Derivative Instruments

[0001327567-17-000027:notes:182]
As a global business, we are exposed to currency exchange rate risk. Substantially all of our revenue is transacted in U.S. dollars, however, a portion of our operating expenditures are incurred outside of the United States and are denominated in foreign currencies, making them subject to fluctuations in foreign currency exchange rates. We enter into foreign currency derivative contracts with maturities of 12 months or less which we designate as cash flow hedges to manage the foreign currency exchange rate risk associated with these expenditures.

[0001327567-17-000027:notes:183]
Beginning August 2016, we entered into forward contracts to hedge the foreign currency exchange rate risk arising from our foreign currency denominated expenditures to be incurred during the year ended July 31, 2017. All of these foreign currency forward contracts matured and were settled during the year ended July 31, 2017. Accordingly, we did not have any forward contracts outstanding as of July 31, 2017. During the year ended July 31, 2017, both unrealized losses recognized in AOCI related to the effective portion of our cash flow hedges and amounts reclassified into earnings were not material.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001327567-17-000027:notes:184]
Equity Award Plans

[0001327567-17-000027:notes:185]
Share-Based Compensation Plans

[0001327567-17-000027:notes:186]
2012 Equity Incentive Plan

[0001327567-17-000027:notes:187]
Our 2012 Equity Incentive Plan (our “2012 Plan”) was adopted by our board of directors and approved by the stockholders on June 5, 2012 and was effective one business day prior to the effectiveness of our registration statement for our initial public offering (“IPO”). Our 2012 Plan replaced our 2005 Equity Incentive Plan (our “2005 Plan”), which terminated upon the completion of our IPO, however, awards that were outstanding upon termination remained outstanding pursuant to their original terms. Our 2012 Plan provides for the granting of stock options, restricted stock awards (“RSAs”), restricted stock units (“RSUs”), stock appreciation rights, performance units, and performance shares (“PSAs”) to our employees, directors, and consultants.

[0001327567-17-000027:notes:188]
Awards granted under our 2012 Plan vest over the periods determined by the board of directors, generally three to four years from the date of grant, and our options expire no more than ten years after the date of grant. Since our IPO in 2012, awards granted under our 2012 Plan consist primarily of RSUs. Until vested, RSUs do not have the voting and dividend participation rights of common stock and the shares underlying the awards are not considered issued and outstanding.

[0001327567-17-000027:notes:189]
In October 2016, we granted PSAs to certain employees, which will vest over a period of four years from the date of grant. The actual number of PSAs earned and eligible to vest is determined based on level of achievement against a pre-established billings target for the fiscal year ending July 31, 2017.

[0001327567-17-000027:notes:190]
In February 2017, we began to net-share settle equity awards held by certain employees by withholding shares upon vesting to satisfy tax withholding obligations. The shares withheld to satisfy employee tax withholding obligations are returned to our 2012 Plan and will be available for future issuance. Payments for employees’ tax obligations to the tax authorities are recognized as a reduction to additional paid-in capital and reflected as financing activities in our consolidated statements of cash flows.

[0001327567-17-000027:notes:191]
A total of 16.9 million shares of our common stock are reserved for issuance pursuant to our 2012 Plan as of July 31, 2017. This includes shares that are (i) reserved but unissued under our 2005 Plan on the effective date of our 2012 Plan or (ii) returned to our 2005 Plan as a result of expiration or termination of options. On the first day of each fiscal year, the number of shares in the reserve may be increased by the lesser of (i) 8,000,000 shares, (ii) 4.5% of the outstanding shares of common stock on the last day of our immediately preceding fiscal year, or (iii) such other amount as determined by our board of directors.

[0001327567-17-000027:notes:192]
2012 Employee Stock Purchase Plan

[0001327567-17-000027:notes:193]
Our 2012 Employee Stock Purchase Plan (our “2012 ESPP”) was adopted by our board of directors and approved by the stockholders on June 5, 2012 and was effective upon completion of our IPO.

[0001327567-17-000027:notes:194]
Our 2012 ESPP permits eligible employees to acquire shares of our common stock at 85% of the lower of the fair market value of our common stock on the first trading day of each offering period or on the exercise date. Each offering period will be approximately six months starting on the first trading date after March 15 and September 15 of each year. Participants may purchase shares of common stock through payroll deductions of up to 15% of their eligible compensation, subject to purchase limits of 625 shares during a six-month period or $25,000 worth of stock for each calendar year. During the year ended July 31, 2017, employees purchased 0.4 million shares of common stock under our 2012 ESPP at an average exercise price of $110.13 per share.

[0001327567-17-000027:notes:195]
A total of 2.9 million shares of our common stock are available for sale under our 2012 ESPP as of July 31, 2017. On the first day of each fiscal year, the number of shares in the reserve may be increased by the lesser of (i) 2,000,000 shares, (ii) 1% of the outstanding shares of our common stock on the first day of the fiscal year, or (iii) such other amount as determined by our board of directors.

[0001327567-17-000027:notes:196]
Stock Option Activities

[0001327567-17-000027:notes:197]
The following table summarizes the stock option activity under our stock plans during the reporting period (in millions, except per share amounts):

[0001327567-17-000027:notes:198]
|  | Options Outstanding |
|  | Number ofShares |  | Weighted- Average Exercise Price Per Share |  | Weighted- Average Remaining Contractual Term (Years) |  | Aggregate Intrinsic Value |
| Balance—July 31, 2016 | 2.1 |  |  | $ | 13.42 |  |  | 5.2 |  | $ | 244.9 |  |
| Options granted | — |  |  | — |  |  |  |  |  |
| Options forfeited | — |  |  | — |  |  |  |  |  |
| Options exercised | (0.5 | ) |  | 14.44 |  |  |  |  |  |
| Balance—July 31, 2017 | 1.6 |  |  | $ | 13.11 |  |  | 4.2 |  | $ | 190.6 |  |
| Options exercisable—July 31, 2017 | 1.6 |  |  | $ | 13.11 |  |  | 4.2 |  | $ | 190.6 |  |

[0001327567-17-000027:notes:199]
The intrinsic value of options exercised during the years ended July 31, 2017, 2016, and 2015 was $61.2 million, $176.1 million, and $301.1 million, respectively. The grant-date fair value of options vested during the years ended July 31, 2016 and 2015 was $8.1 million and $14.6 million, respectively. All options were fully vested as of July 31, 2016.

[0001327567-17-000027:notes:200]
RSU, RSA, and PSA Activities

[0001327567-17-000027:notes:201]
The following table summarizes the RSU, RSA, and PSA activity under our stock plans during the reporting period (in millions, except per share amounts):

[0001327567-17-000027:notes:202]
|  | RSAs and PSAs Outstanding |  | RSUs Outstanding |
|  | Number of Shares |  | Weighted- Average Grant-Date Fair Value Per Share |  | Number of Shares |  | Weighted- Average Grant-Date Fair Value Per Share |  | Weighted- Average Remaining Contractual Term (Years) |  | Aggregate Intrinsic Value |
| Balance—July 31, 2016 | 1.1 |  |  | $ | 170.97 |  |  | 6.5 |  |  | $ | 130.14 |  |  | 1.1 |  | $ | 852.7 |  |
| Granted(1) | 0.3 |  |  | 148.54 |  |  | 3.9 |  |  | 141.35 |  |  |  |  |  |
| Vested | (0.4 | ) |  | 170.97 |  |  | (3.3 | ) |  | 119.88 |  |  |  |  |  |
| Forfeited | — |  |  | — |  |  | (0.6 | ) |  | 139.56 |  |  |  |  |  |
| Balance—July 31, 2017 | 1.0 |  |  | $ | 163.55 |  |  | 6.5 |  |  | $ | 141.16 |  |  | 1.3 |  | $ | 854.1 |  |

[0001327567-17-000027:notes:203]
(1)    The number of PSAs granted represents the aggregate maximum number of shares that may be earned and issued with

[0001327567-17-000027:notes:204]
respect to these awards over their full terms.

[0001327567-17-000027:notes:205]
The weighted-average grant-date fair value of RSAs and PSAs granted during the years ended July 31, 2017 and 2016 was $148.54 and $170.97 per share, respectively. There were no RSAs or PSAs granted during the year ended July 31, 2015. The aggregate fair value, as of the respective vesting dates, of RSAs vested during the year ended July 31, 2017 was $62.6 million. No RSAs vested during the years ended July 31, 2016 and 2015, and no PSAs vested during the three years ended July 31, 2017.

[0001327567-17-000027:notes:206]
The weighted-average grant-date fair value of RSUs granted during the years ended July 31, 2017, 2016, and 2015 was $141.35, $160.60, and $122.36 per share, respectively. The aggregate fair value, as of the respective vesting dates, of RSUs vested during the years ended July 31, 2017, 2016, and 2015 was $462.6 million, $513.0 million, and $350.4 million, respectively.

[0001327567-17-000027:notes:207]
Shares Available for Grant

[0001327567-17-000027:notes:208]
We record share-based compensation awards based on estimated fair value as of the grant date. The fair value of RSUs, RSAs, and PSAs is based on the closing market price of our common stock on the date of grant. The fair value of shares sold through our 2012 ESPP are estimated on the grant date using the Black-Scholes option pricing model.

[0001327567-17-000027:notes:209]
The following table summarizes share-based compensation included in costs and expenses (in millions):

[0001327567-17-000027:notes:210]
|  | Year Ended July 31, |
|  | 2017 |  | 2016 |  | 2015 |
| Cost of product revenue | $ | 7.3 |  |  | $ | 6.2 |  |  | $ | 3.9 |  |
| Cost of subscription and support revenue | 56.2 |  |  | 40.9 |  |  | 20.4 |  |
| Research and development | 152.6 |  |  | 132.9 |  |  | 74.8 |  |
| Sales and marketing | 186.5 |  |  | 152.4 |  |  | 84.1 |  |
| General and administrative | 73.1 |  |  | 60.5 |  |  | 38.2 |  |
| Total share-based compensation | $ | 475.7 |  |  | $ | 392.9 |  |  | $ | 221.4 |  |

[0001327567-17-000027:notes:211]
At July 31, 2017, total compensation cost related to unvested share-based awards not yet recognized was $906.8 million. This cost is expected to be amortized on a straight-line basis over a weighted-average period of approximately 2.6 years. Future grants will increase the amount of compensation expense to be recorded in these periods.


## us-gaap:EarningsPerShareTextBlock

[0001327567-17-000027:notes:212]
Net Loss Per Share

[0001327567-17-000027:notes:213]
Basic net loss per share is computed by dividing net loss by basic weighted-average shares outstanding during the period. Diluted net loss per share is computed by dividing net loss by diluted weighted-average shares outstanding, including potentially dilutive securities.

[0001327567-17-000027:notes:214]
The following table presents the computation of basic and diluted net loss per share of common stock (in millions, except per share data):

[0001327567-17-000027:notes:215]
|  | Year Ended July 31, |
|  | 2017 |  | 2016 |  | 2015 |
| Net loss | $ | (216.6 | ) |  | $ | (192.7 | ) |  | $ | (131.3 | ) |
| Weighted-average shares used to compute net loss per share, basic and diluted | 90.6 |  |  | 87.1 |  |  | 81.6 |  |
| Net loss per share, basic and diluted | $ | (2.39 | ) |  | $ | (2.21 | ) |  | $ | (1.61 | ) |

[0001327567-17-000027:notes:216]
The following securities were excluded from the computation of diluted net loss per share of common stock for the periods presented as their effect would have been antidilutive (in millions):

[0001327567-17-000027:notes:217]
|  | Year Ended July 31, |
|  | 2017 |  | 2016 |  | 2015 |
| RSUs | 6.5 |  |  | 6.5 |  |  | 7.2 |  |
| Convertible senior notes | 5.2 |  |  | 5.2 |  |  | 5.2 |  |
| Warrants related to the issuance of convertible senior notes | 5.2 |  |  | 5.2 |  |  | 5.2 |  |
| Options to purchase common stock | 1.6 |  |  | 2.1 |  |  | 3.3 |  |
| RSAs and PSAs | 1.0 |  |  | 1.1 |  |  | — |  |
| ESPP shares | 0.2 |  |  | 0.1 |  |  | 0.1 |  |
| Total | 19.7 |  |  | 20.2 |  |  | 21.0 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001327567-17-000027:notes:218]
Fair Value Measurements

[0001327567-17-000027:notes:219]
We categorize assets and liabilities recorded or disclosed at fair value on our consolidated balance sheets based upon the level of judgment associated with inputs used to measure their fair value. The categories are as follows:

[0001327567-17-000027:notes:220]
| • | Level 1—Inputs are unadjusted quoted prices in active markets for identical assets or liabilities. |

[0001327567-17-000027:notes:221]
| • | Level 2—Inputs are quoted prices for similar assets and liabilities in active markets or inputs that are observable for the assets or liabilities, either directly or indirectly through market corroboration, for substantially the full term of the financial instruments. |

[0001327567-17-000027:notes:222]
| • | Level 3—Inputs are unobservable inputs based on our own assumptions used to measure assets and liabilities at fair value. The inputs require significant management judgment or estimation. |

[0001327567-17-000027:notes:223]
The following table presents the fair value of our financial assets and liabilities measured at fair value on a recurring basis using the above input categories as of July 31, 2017 and July 31, 2016 (in millions):

[0001327567-17-000027:notes:224]
|  |  | July 31, 2017 |  | July 31, 2016 |
|  |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Short-term investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Commercial paper |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 3.0 |  |  | $ | — |  |  | $ | 3.0 |  |
| Corporate debt securities |  | — |  |  | 159.4 |  |  | — |  |  | 159.4 |  |  | — |  |  | 121.4 |  |  | — |  |  | 121.4 |  |
| U.S. government and agency securities |  | — |  |  | 471.3 |  |  | — |  |  | 471.3 |  |  | — |  |  | 426.8 |  |  | — |  |  | 426.8 |  |
| Total short-term investments |  | — |  |  | 630.7 |  |  | — |  |  | 630.7 |  |  | — |  |  | 551.2 |  |  | — |  |  | 551.2 |  |
| Long-term investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Certificates of deposit |  | — |  |  | 5.4 |  |  | — |  |  | 5.4 |  |  | — |  |  | 5.4 |  |  | — |  |  | 5.4 |  |
| Corporate debt securities |  | — |  |  | 186.5 |  |  | — |  |  | 186.5 |  |  | — |  |  | 166.1 |  |  | — |  |  | 166.1 |  |
| U.S. government and agency securities |  | — |  |  | 597.4 |  |  | — |  |  | 597.4 |  |  | — |  |  | 481.3 |  |  | — |  |  | 481.3 |  |
| Total long-term investments |  | — |  |  | 789.3 |  |  | — |  |  | 789.3 |  |  | — |  |  | 652.8 |  |  | — |  |  | 652.8 |  |
| Total assets measured at fair value |  | $ | — |  |  | $ | 1,420.0 |  |  | $ | — |  |  | $ | 1,420.0 |  |  | $ | — |  |  | $ | 1,204.0 |  |  | $ | — |  |  | $ | 1,204.0 |  |

[0001327567-17-000027:notes:225]
As of July 31, 2017, we determined that certain property and equipment related to our prior corporate headquarters were impaired. In connection with our planned relocation to our new corporate headquarters, we assessed the recoverability of certain leasehold improvements and other long-lived assets associated with our previous headquarter facilities and determined that the carrying amount of these assets exceeded their fair value of $4.2 million. The resulting impairment loss of $20.9 million was recorded as general and administrative expense in our consolidated statements of operations during the year ended July 31, 2017. We calculated the fair value of the leasehold improvements and other long-lived assets based on estimated future discounted cash flows and classified the fair value as a Level 3 measurement due to the significance of unobservable inputs, which included the amount and timing of estimated sublease rental receipts that we could reasonably obtain over the remaining lease term and the discount rate. Refer to Note 9. Commitments and Contingencies for more information on the relocation of our corporate headquarters.

[0001327567-17-000027:notes:226]
Refer to Note 8. Convertible Senior Notes for the carrying amount and estimated fair value of our convertible senior notes as of July 31, 2017 and July 31, 2016.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001327567-17-000027:notes:227]
Goodwill and Intangible Assets

[0001327567-17-000027:notes:228]
Goodwill

[0001327567-17-000027:notes:229]
The following table presents details of our goodwill during the year ended July 31, 2017 (in millions):

[0001327567-17-000027:notes:230]
|  | Amount |
| Balance as of July 31, 2016 | $ | 163.5 |  |
| Goodwill acquired | 75.3 |  |
| Balance as of July 31, 2017 | $ | 238.8 |  |

[0001327567-17-000027:notes:231]
Through July 31, 2017, we have not recognized any impairment losses on our goodwill.

[0001327567-17-000027:notes:232]
Purchased Intangible Assets

[0001327567-17-000027:notes:233]
The following table presents details of our purchased intangible assets as of July 31, 2017 and July 31, 2016 (in millions):

[0001327567-17-000027:notes:234]
|  | July 31, |
|  | 2017 |  | 2016 |
|  | Gross Carrying Amount |  | Accumulated Amortization |  | Net Carrying Amount |  | Gross Carrying Amount |  | Accumulated Amortization |  | Net Carrying Amount |
| Developed technology | $ | 69.7 |  |  | $ | (23.8 | ) |  | $ | 45.9 |  |  | $ | 53.1 |  |  | $ | (15.4 | ) |  | $ | 37.7 |  |
| Acquired intellectual property | 8.9 |  |  | (3.8 | ) |  | 5.1 |  |  | 8.9 |  |  | (2.9 | ) |  | 6.0 |  |
| Customer relationships | 2.9 |  |  | (0.2 | ) |  | 2.7 |  |  | — |  |  | — |  |  | — |  |
| Other | 2.4 |  |  | (2.4 | ) |  | — |  |  | 2.4 |  |  | (2.1 | ) |  | 0.3 |  |
| Total purchased intangible assets | $ | 83.9 |  |  | $ | (30.2 | ) |  | $ | 53.7 |  |  | $ | 64.4 |  |  | $ | (20.4 | ) |  | $ | 44.0 |  |

[0001327567-17-000027:notes:235]
We recognized amortization expense of $9.8 million, $9.4 million, and $7.9 million for the years ended July 31, 2017, 2016, and 2015, respectively.

[0001327567-17-000027:notes:236]
The following table summarizes our estimated future amortization expense of intangible assets as of July 31, 2017 (in millions):

[0001327567-17-000027:notes:237]
|  | Amount |
| Years ending July 31: |  |
| 2018 | $ | 10.7 |  |
| 2019 | 10.6 |  |
| 2020 | 10.6 |  |
| 2021 | 8.9 |  |
| 2022 | 4.4 |  |
| 2023 and thereafter | 8.5 |  |
| Total future amortization expense | $ | 53.7 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001327567-17-000027:notes:238]
The following table presents the components of income (loss) before income taxes (in millions):

[0001327567-17-000027:notes:239]
|  | Year Ended July 31, |
|  | 2017 |  | 2016(1) |  | 2015(1) |
| United States | $ | (210.0 | ) |  | $ | (195.3 | ) |  | $ | (21.3 | ) |
| Foreign | 15.9 |  |  | 23.0 |  |  | (100.6 | ) |
| Total | $ | (194.1 | ) |  | $ | (172.3 | ) |  | $ | (121.9 | ) |

[0001327567-17-000027:notes:240]
| (1) | Certain amounts have been adjusted due to our voluntary change in accounting policy for sales commissions. Refer to Note 1. Description of Business and Summary of Significant Accounting Policies for more information. |

[0001327567-17-000027:notes:241]
The following table summarizes our provision for income taxes (in millions):

[0001327567-17-000027:notes:242]
|  | Year Ended July 31, |
|  | 2017 |  | 2016(1) |  | 2015 |
| Federal: |  |  |  |  |  |
| Current | $ | 3.4 |  |  | $ | 1.9 |  |  | $ | 1.8 |  |
| Deferred | — |  |  | (0.6 | ) |  | (3.0 | ) |
| State: |  |  |  |  |  |
| Current | 0.9 |  |  | 1.1 |  |  | 0.7 |  |
| Deferred | — |  |  | (0.1 | ) |  | (0.4 | ) |
| Foreign: |  |  |  |  |  |
| Current | 19.7 |  |  | 19.1 |  |  | 10.7 |  |
| Deferred | (1.5 | ) |  | (1.0 | ) |  | (0.4 | ) |
| Total | $ | 22.5 |  |  | $ | 20.4 |  |  | $ | 9.4 |  |

[0001327567-17-000027:notes:243]
For the year ended July 31, 2017, our provision for income taxes increased compared to the year ended July 31, 2016 primarily due to increases in foreign withholding taxes and U.S. income taxes related to intercompany transactions, offset by tax benefits from our adoption of new share-based payment accounting guidance in fiscal 2017. Refer to Note 1. Description of Business and Summary of Significant Accounting Policies for more information on our adoption of the accounting guidance.

[0001327567-17-000027:notes:244]
For the year ended July 31, 2016, our provision for income taxes increased compared to the year ended July 31, 2015 primarily due to an increase in foreign taxes and amortization of our deferred tax charges.

[0001327567-17-000027:notes:245]
The following table presents the items accounting for the difference between income taxes computed at the federal statutory income tax rate and our provision for income taxes:

[0001327567-17-000027:notes:246]
|  | Year Ended July 31, |
|  | 2017 |  | 2016(1) |  | 2015(1) |
| Federal statutory rate | 35.0 | % |  | 35.0 | % |  | 35.0 | % |
| Effect of: |  |  |  |  |  |
| State taxes, net of federal tax benefit | 2.8 |  |  | (1.7 | ) |  | 4.6 |  |
| Foreign income at other than U.S. rates | (14.4 | ) |  | (7.8 | ) |  | (6.1 | ) |
| Change in valuation allowance | (39.4 | ) |  | (25.4 | ) |  | (28.8 | ) |
| Share-based compensation | 1.6 |  |  | (15.9 | ) |  | (13.0 | ) |
| Amortization of deferred tax charges | (3.6 | ) |  | (3.4 | ) |  | (2.8 | ) |
| Research credits | 10.1 |  |  | 11.3 |  |  | 8.6 |  |
| Other, net | (3.7 | ) |  | (3.9 | ) |  | (5.2 | ) |
| Total | (11.6 | )% |  | (11.8 | )% |  | (7.7 | )% |

[0001327567-17-000027:notes:247]
The change in foreign income at other than U.S. rates from the year ended July 31, 2016 to July 31, 2017 was due to current year intercompany transactions.

[0001327567-17-000027:notes:248]
During the year ended July 31, 2017, we adopted new share-based payment accounting guidance that requires us to recognize excess tax benefits or deficiencies as income tax expense or benefit in the period in which they occur, rather than additional paid-in capital. The effect of the change from this guidance is reflected in the share-based compensation line above.

[0001327567-17-000027:notes:249]
During the year ended July 31, 2016, we accounted for the outcome of The Gillette Company et al. v. California Franchise Tax Board which disallowed the election to use an evenly weighted, three factor apportionment formula utilized by us on our tax return for the year ended July 31, 2014. The impact for the change in apportionment is reflected in state taxes, net of federal tax benefit above and is fully offset by changes in our valuation allowance.

[0001327567-17-000027:notes:250]
The following table presents the components of our deferred tax assets and liabilities as of July 31, 2017 and July 31, 2016 (in millions):

[0001327567-17-000027:notes:251]
|  | July 31, |
|  | 2017 |  | 2016(1) |
| Deferred tax assets: |  |  |  |
| Accruals and reserves | $ | 35.9 |  |  | $ | 43.5 |  |
| Deferred revenue | 123.2 |  |  | 62.0 |  |
| Net operating loss carryforwards | 245.3 |  |  | 5.4 |  |
| Research and development and foreign tax credits | 69.3 |  |  | 41.4 |  |
| Share-based compensation | 45.4 |  |  | 55.2 |  |
| Gross deferred tax assets | 519.1 |  |  | 207.5 |  |
| Valuation allowance | (464.1 | ) |  | (161.3 | ) |
| Total deferred tax assets | 55.0 |  |  | 46.2 |  |
| Deferred tax liabilities: |  |  |  |
| Fixed assets and intangible assets | (9.1 | ) |  | (14.2 | ) |
| Deferred commissions | (36.8 | ) |  | (27.7 | ) |
| Other deferred tax liabilities | (4.0 | ) |  | (2.5 | ) |
| Total deferred tax liabilities | (49.9 | ) |  | (44.4 | ) |
| Total | $ | 5.1 |  |  | $ | 1.8 |  |

[0001327567-17-000027:notes:252]
During the year ended July 31, 2017, we adopted new share-based payment accounting guidance related to the timing of when excess tax benefits are recognized. We adopted the guidance on a modified retrospective basis and, as a result, our deferred tax assets for the year ended July 31, 2017 reflect additional net operating losses of $385.7 million and research and development credits of $5.3 million that were not included in the balances for the year ended July 31, 2016. In addition, our valuation allowance increased $389.2 million as a result of adopting the new guidance. The increase in net operating losses due to the adoption of the new guidance was partially offset by income in the U.S. due to intercompany transactions.

[0001327567-17-000027:notes:253]
A valuation allowance is provided when it is more likely than not that the deferred tax asset will not be realized. Realization of deferred tax assets is dependent upon future taxable income, if any, the amount and timing of which are uncertain. At such time, if it is determined that it is more likely than not that the deferred tax assets are realizable, the valuation allowance will be adjusted. As of July 31, 2017, we have provided a valuation allowance for our federal, state, and certain foreign deferred tax assets that we believe will, more likely than not, be unrealizable. The net valuation allowance increased by approximately $302.8 million from the year ended July 31, 2016 to the year ended July 31, 2017. The increase was primarily due to the adoption of new share-based payment accounting guidance and was partially offset by NOL utilization related to intercompany transactions.

[0001327567-17-000027:notes:254]
As of July 31, 2017, we had federal, state, and foreign NOL carryforwards of approximately $1.1 billion, $806.4 million, and $45.8 million, respectively, as reported on our tax returns, available to reduce future taxable income, if any. If not utilized, our federal and state NOL carryforwards will expire in various amounts at various dates beginning in the years ending July 31, 2027 and July 31, 2018, respectively. Our foreign NOL will carry forward indefinitely.

[0001327567-17-000027:notes:255]
As of July 31, 2017, we had federal and state research and development tax credit carryforwards of approximately $48.6 million and $49.7 million, respectively as reported on our tax returns. If not utilized, the federal credit carryforwards will expire in various amounts at various dates beginning in the year ending July 31, 2026. The state credit will carry forward indefinitely.

[0001327567-17-000027:notes:256]
As of July 31, 2017, we had foreign tax credit carryforwards of $2.5 million as reported on our tax returns. If not utilized, the foreign tax credit carryforwards will expire in various amounts at various dates beginning in the year ending July 31, 2021.

[0001327567-17-000027:notes:257]
Utilization of the NOL carryforwards and credits may be subject to a substantial annual limitation due to the ownership change limitations provided by the Internal Revenue Code of 1986, as amended, and similar state provisions. The annual limitation may result in the expiration of NOLs and credits before utilization.

[0001327567-17-000027:notes:258]
As a result of adopting the new share-based payment guidance, we did not reflect the impact of excess tax benefits in additional paid-in capital for the year ended July 31, 2017. Prior to adopting this guidance, we recorded excess tax benefits of $0.5 million and $2.5 million directly to additional paid-in capital for the years ended July 31, 2016 and 2015, respectively.

[0001327567-17-000027:notes:259]
During the year ended July 31, 2017, we were awarded a tax incentive by a foreign jurisdiction. The incentive is effective through September 30, 2031, and is conditional upon meeting certain investment and employment thresholds. The impact of this incentive on our provision for income taxes was not material for the year ended July 31, 2017.

[0001327567-17-000027:notes:260]
As of July 31, 2017, we had $301.3 million of unrecognized tax benefits, $34.0 million of which would affect income tax expense if recognized, after consideration of our valuation allowance in the United States and other assets. As of July 31, 2016, we had $127.7 million of unrecognized tax benefits, $21.9 million of which would affect income tax expense if recognized, after consideration of our valuation allowance in the United States. As of July 31, 2017, our federal, state, and foreign returns for the tax years 2008 through the current period remain subject to adjustment due to examination. Fiscal years outside the normal statute of limitation remain open to audit by tax authorities due to tax attributes generated in earlier years, which have been carried forward and may be audited in subsequent years when utilized. We do not expect the amount of unrecognized tax benefits as of July 31, 2017 to change significantly over the next 12 months. We recognize both interest and penalties associated with uncertain tax positions as a component of income tax expense. During the years ended July 31, 2017, 2016, and 2015, we recognized income tax expense related to interest and penalties of $2.1 million, $1.6 million, and $1.1 million, respectively. We had accrued interest and penalties on our consolidated balance sheets related to unrecognized tax benefits of $5.4 million and $3.3 million as of July 31, 2017 and 2016, respectively. The ultimate amount and timing of any future cash settlements cannot be predicted with reasonable certainty.

[0001327567-17-000027:notes:261]
The following table presents a reconciliation of the beginning and ending amount of our gross unrecognized tax benefits (in millions):

[0001327567-17-000027:notes:262]
|  | Year Ended July 31, |
|  | 2017 |  | 2016 |  | 2015 |
| Unrecognized tax benefits at the beginning of the period | $ | 127.7 |  |  | $ | 67.2 |  |  | $ | 10.4 |  |
| Additions for tax positions taken in prior years | 3.1 |  |  | 25.2 |  |  | 6.1 |  |
| Reductions for tax positions taken in prior years | — |  |  | — |  |  | (0.6 | ) |
| Additions for tax positions taken in the current year | 170.5 |  |  | 35.3 |  |  | 51.3 |  |
| Unrecognized tax benefits at the end of the period | $ | 301.3 |  |  | $ | 127.7 |  |  | $ | 67.2 |  |

[0001327567-17-000027:notes:263]
During the year ended July 31, 2017, our additions for tax positions taken in the current year were primarily attributable to uncertainties related to intercompany transactions.

[0001327567-17-000027:notes:264]
During the year ended July 31, 2016, our additions for tax positions taken in prior years and additions for tax positions taken in the current year were primarily attributable to uncertain tax positions relating to federal and state research and development credits, adjustments for California apportionment, and transfer pricing methodologies.

[0001327567-17-000027:notes:265]
As of July 31, 2017, we had no unremitted earnings when evaluating our outside basis differences relating to our investment in foreign subsidiaries. Accordingly, we have not provided a deferred tax liability for any potential U.S. income taxes or foreign withholding taxes.


## us-gaap:InvestmentsClassifiedByContractualMaturityDateTableTextBlock

[0001327567-17-000027:notes:266]
The following table summarizes the amortized cost and fair value of our available-for-sale investments as of July 31, 2017, by contractual years-to-maturity (in millions):

[0001327567-17-000027:notes:267]
|  | Amortized Cost |  | Fair Value |
| Due within one year | $ | 631.6 |  |  | $ | 630.7 |  |
| Due between one and three years | 791.1 |  |  | 789.3 |  |
| Total | $ | 1,422.7 |  |  | $ | 1,420.0 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001327567-17-000027:notes:268]
Investments

[0001327567-17-000027:notes:269]
Unrealized losses related to these investments are due to interest rate fluctuations as opposed to credit quality. In addition, we do not intend to sell and it is not likely that we would be required to sell these investments before recovery of their amortized cost basis, which may be at maturity. As a result, there were no other-than-temporary impairments for these investments at July 31, 2017 and 2016.

[0001327567-17-000027:notes:270]
We received proceeds of $141.9 million and $18.5 million from sales of investments during the years ended July 31, 2016 and 2015, respectively. We did not sell any investments during the year ended July 31, 2017. We use the specific identification method to determine the cost basis of investments sold.


## us-gaap:LongLivedAssetsByGeographicAreasTableTextBlock

[0001327567-17-000027:notes:271]
The following table presents our property and equipment, net by geographic region (in millions):

[0001327567-17-000027:notes:272]
|  | Year Ended July 31, |
|  | 2017 |  | 2016 |
| Property and equipment, net: |  |  |  |
| United States | $ | 178.4 |  |  | $ | 102.3 |  |
| International | 32.7 |  |  | 14.9 |  |
| Total property and equipment, net | $ | 211.1 |  |  | $ | 117.2 |  |


## us-gaap:OtherNonoperatingIncomeAndExpenseTextBlock

[0001327567-17-000027:notes:273]
Other Income, Net

[0001327567-17-000027:notes:274]
The following table sets forth the components of other income, net (in millions):

[0001327567-17-000027:notes:275]
|  | Year Ended July 31, |
|  | 2017 |  | 2016 |  | 2015 |
| Interest income | $ | 14.7 |  |  | $ | 8.8 |  |  | $ | 3.9 |  |
| Foreign currency exchange losses, net | (3.4 | ) |  | — |  |  | (3.0 | ) |
| Other | (1.1 | ) |  | (0.4 | ) |  | (0.7 | ) |
| Total other income, net | $ | 10.2 |  |  | $ | 8.4 |  |  | $ | 0.2 |  |


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001327567-17-000027:notes:276]
The following table presents details of our property and equipment, net as of July 31, 2017 and July 31, 2016 (in millions):

[0001327567-17-000027:notes:277]
|  | July 31, |
|  | 2017 |  | 2016 |
| Computers, equipment, and software | $ | 156.6 |  |  | $ | 102.7 |  |
| Leasehold improvements | 110.1 |  |  | 58.0 |  |
| Demonstration units | 26.3 |  |  | 20.1 |  |
| Furniture and fixtures | 20.4 |  |  | 14.6 |  |
| Total property and equipment | 313.4 |  |  | 195.4 |  |
| Less: accumulated depreciation | (102.3 | ) |  | (78.2 | ) |
| Total property and equipment, net | $ | 211.1 |  |  | $ | 117.2 |  |

[0001327567-17-000027:notes:278]
We recognized depreciation expense of $48.6 million, $33.1 million, and $20.3 million related to property and equipment during the years ended July 31, 2017, 2016, and 2015, respectively. During the year ended July 31, 2017, we impaired certain property and equipment related to the relocation of our corporate headquarters and recognized a loss of $20.9 million in general and administrative expense on our consolidated statements of operations. Refer to Note 9. Commitments and Contingencies for more information.


## us-gaap:QuarterlyFinancialInformationTextBlock

[0001327567-17-000027:notes:279]
Selected Quarterly Financial Data (Unaudited)

[0001327567-17-000027:notes:280]
The following tables set forth selected unaudited quarterly financial data for the years ended July 31, 2017 and 2016 (in millions, except per share amounts):

[0001327567-17-000027:notes:281]
|  | Three Months Ended |
|  | Oct. 31,2016(1) |  | Jan. 31,2017 |  | Apr. 30,2017 |  | Jul. 31,2017 |
| Revenue: |  |  |  |  |  |  |  |
| Product | $ | 163.8 |  |  | $ | 168.8 |  |  | $ | 164.2 |  |  | $ | 212.3 |  |
| Subscription and support | 234.3 |  |  | 253.8 |  |  | 267.6 |  |  | 296.8 |  |
| Total revenue | 398.1 |  |  | 422.6 |  |  | 431.8 |  |  | 509.1 |  |
| Cost of revenue: |  |  |  |  |  |  |  |
| Product | 42.2 |  |  | 45.8 |  |  | 49.7 |  |  | 63.7 |  |
| Subscription and support | 59.0 |  |  | 67.4 |  |  | 74.0 |  |  | 74.8 |  |
| Total cost of revenue | 101.2 |  |  | 113.2 |  |  | 123.7 |  |  | 138.5 |  |
| Total gross profit | 296.9 |  |  | 309.4 |  |  | 308.1 |  |  | 370.6 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 84.2 |  |  | 89.9 |  |  | 86.0 |  |  | 87.3 |  |
| Sales and marketing | 220.1 |  |  | 226.7 |  |  | 226.9 |  |  | 245.4 |  |
| General and administrative | 41.6 |  |  | 47.2 |  |  | 44.3 |  |  | 65.2 |  |
| Total operating expenses | 345.9 |  |  | 363.8 |  |  | 357.2 |  |  | 397.9 |  |
| Operating loss | (49.0 | ) |  | (54.4 | ) |  | (49.1 | ) |  | (27.3 | ) |
| Interest expense | (6.0 | ) |  | (6.1 | ) |  | (6.2 | ) |  | (6.2 | ) |
| Other income, net | 2.5 |  |  | 2.7 |  |  | 2.1 |  |  | 2.9 |  |
| Loss before income taxes | (52.5 | ) |  | (57.8 | ) |  | (53.2 | ) |  | (30.6 | ) |
| Provision for income taxes | 4.4 |  |  | 2.8 |  |  | 7.7 |  |  | 7.6 |  |
| Net loss | $ | (56.9 | ) |  | $ | (60.6 | ) |  | $ | (60.9 | ) |  | $ | (38.2 | ) |
| Net loss per share, basic and diluted | $ | (0.63 | ) |  | $ | (0.67 | ) |  | $ | (0.67 | ) |  | $ | (0.42 | ) |

[0001327567-17-000027:notes:282]
| (1) | Certain amounts have been adjusted due to our early adoption of new share-based payment accounting guidance. Refer to Note 1. Description of Business and Summary of Significant Accounting Policies for more information. |

[0001327567-17-000027:notes:283]
|  | Three Months Ended |
|  | Oct. 31,2015 |  | Jan. 31,2016 |  | Apr. 30,2016 |  | Jul. 31,2016 |
| Revenue: |  |  |  |  |  |  |  |
| Product | $ | 147.7 |  |  | $ | 169.9 |  |  | $ | 162.1 |  |  | $ | 191.1 |  |
| Subscription and support | 149.5 |  |  | 164.8 |  |  | 183.7 |  |  | 209.7 |  |
| Total revenue | 297.2 |  |  | 334.7 |  |  | 345.8 |  |  | 400.8 |  |
| Cost of revenue: |  |  |  |  |  |  |  |
| Product | 38.8 |  |  | 44.9 |  |  | 43.2 |  |  | 48.5 |  |
| Subscription and support | 40.4 |  |  | 49.3 |  |  | 51.7 |  |  | 53.2 |  |
| Total cost of revenue | 79.2 |  |  | 94.2 |  |  | 94.9 |  |  | 101.7 |  |
| Total gross profit | 218.0 |  |  | 240.5 |  |  | 250.9 |  |  | 299.1 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 59.7 |  |  | 74.0 |  |  | 74.0 |  |  | 76.5 |  |
| Sales and marketing(1) | 159.5 |  |  | 182.4 |  |  | 195.9 |  |  | 205.4 |  |
| General and administrative | 30.8 |  |  | 34.2 |  |  | 33.5 |  |  | 39.9 |  |
| Total operating expenses(1) | 250.0 |  |  | 290.6 |  |  | 303.4 |  |  | 321.8 |  |
| Operating loss(1) | (32.0 | ) |  | (50.1 | ) |  | (52.5 | ) |  | (22.7 | ) |
| Interest expense | (5.8 | ) |  | (5.8 | ) |  | (5.8 | ) |  | (6.0 | ) |
| Other income, net | 2.2 |  |  | 2.5 |  |  | 1.0 |  |  | 2.7 |  |
| Loss before income taxes(1) | (35.6 | ) |  | (53.4 | ) |  | (57.3 | ) |  | (26.0 | ) |
| Provision for income taxes(1) | 4.3 |  |  | 3.9 |  |  | 6.8 |  |  | 5.4 |  |
| Net loss(1) | $ | (39.9 | ) |  | $ | (57.3 | ) |  | $ | (64.1 | ) |  | $ | (31.4 | ) |
| Net loss per share, basic and diluted(1) | $ | (0.47 | ) |  | $ | (0.66 | ) |  | $ | (0.73 | ) |  | $ | (0.35 | ) |

[0001327567-17-000027:notes:284]
| (1) | Amounts have been adjusted due to our voluntary change in accounting policy for sales commissions. Refer to Note 1. Description of Business and Summary of Significant Accounting Policies for more information. |


## us-gaap:RevenueFromExternalCustomersByGeographicAreasTableTextBlock

[0001327567-17-000027:notes:285]
The following table presents revenue by geographic theater (in millions):

[0001327567-17-000027:notes:286]
|  | Year Ended July 31, |
|  | 2017 |  | 2016 |  | 2015 |
| Revenue: |  |  |  |  |  |
| Americas |  |  |  |  |  |
| United States | $ | 1,155.3 |  |  | $ | 901.8 |  |  | $ | 593.8 |  |
| Other Americas | 82.1 |  |  | 71.4 |  |  | 45.6 |  |
| Total Americas | 1,237.4 |  |  | 973.2 |  |  | 639.4 |  |
| Europe, the Middle East, and Africa (“EMEA”) | 320.1 |  |  | 247.1 |  |  | 178.7 |  |
| Asia Pacific and Japan (“APAC”) | 204.1 |  |  | 158.2 |  |  | 110.0 |  |
| Total revenue | $ | 1,761.6 |  |  | $ | 1,378.5 |  |  | $ | 928.1 |  |


## us-gaap:ScheduleOfEntityWideInformationRevenueFromExternalCustomersByProductsAndServicesTextBlock

[0001327567-17-000027:notes:287]
The following table presents revenue for groups of similar products and services (in millions):

[0001327567-17-000027:notes:288]
|  | Year Ended July 31, |
|  | 2017 |  | 2016 |  | 2015 |
| Revenue: |  |  |  |  |  |
| Product | $ | 709.1 |  |  | $ | 670.8 |  |  | $ | 492.7 |  |
| Subscription and support |  |  |  |  |  |
| Subscription | 550.8 |  |  | 357.0 |  |  | 212.7 |  |
| Support | 501.7 |  |  | 350.7 |  |  | 222.7 |  |
| Total subscription and support | 1,052.5 |  |  | 707.7 |  |  | 435.4 |  |
| Total revenue | $ | 1,761.6 |  |  | $ | 1,378.5 |  |  | $ | 928.1 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001327567-17-000027:notes:289]
Segment Information

[0001327567-17-000027:notes:290]
We conduct business globally and are primarily managed on a geographic theater basis. Our chief operating decision maker reviews financial information presented on a consolidated basis accompanied by information about revenue by geographic region for purposes of allocating resources and evaluating financial performance. We have one business activity and there are no segment managers who are held accountable for operations, operating results, and plans for levels, components, or types of products or services below the consolidated unit level. Accordingly, we are considered to be in a single reportable segment and operating unit structure.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001327567-17-000027:notes:291]
Stockholders’ Equity

[0001327567-17-000027:notes:292]
Share Repurchase

[0001327567-17-000027:notes:293]
On August 26, 2016, our board of directors authorized a $500.0 million share repurchase which is funded from available working capital. On February 24, 2017, our board of directors authorized a $500.0 million increase to our repurchase program, bringing the total authorization to $1.0 billion. Repurchases may be made at management’s discretion from time to time on the open market, through privately negotiated transactions, transactions structured through investment banking institutions, block purchase techniques, 10b5-1 trading plans, or a combination of the foregoing. The repurchase authorization will expire on December 31, 2018, and may be suspended or discontinued at any time.

[0001327567-17-000027:notes:294]
During the year ended July 31, 2017, we repurchased and retired 3.3 million shares of our common stock under the authorization for an aggregate purchase price of $420.1 million, including transaction costs. The total price of the shares repurchased and related transaction costs are reflected as a reduction to common stock and additional paid-in capital on our consolidated balance sheets. As of July, 31, 2017, $580.0 million remained available for future share repurchases under the repurchase authorization.


## us-gaap:SubsequentEventsTextBlock

[0001327567-17-000027:notes:295]
Subsequent Events

[0001327567-17-000027:notes:296]
Facility Exit

[0001327567-17-000027:notes:297]
In August 2017, we exited our previous headquarter facilities and relocated to our new corporate campus. As a result, we expect to recognize a cease-use loss of approximately $15.4 million during the first quarter of fiscal 2018. The cease-use loss is calculated based on the remaining lease obligation for the vacated facilities, adjusted for the effects of any deferred items recognized under the leases, estimated sublease rentals that could be reasonably obtained, and related costs. The amount of the cease-use loss may vary if the timing or amount of estimated cash flows change. Refer to Note 9. Commitments and Contingencies for more information on the relocation of our corporate headquarters.
