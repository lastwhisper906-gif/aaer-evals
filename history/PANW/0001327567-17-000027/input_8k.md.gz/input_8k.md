# PANW 8-K — 0001327567-17-000021 filed 2017-08-31

## item codes, every 8-K on or before 2017-09-07

- 2017-08-31 0001327567-17-000021 — 2.02, 5.02, 9.01
- 2017-05-31 0001327567-17-000016 — 2.02, 9.01
- 2017-02-28 0001327567-17-000005 — 2.02, 8.01, 9.01
- 2016-12-12 0001193125-16-790757 — 5.07
- 2016-11-21 0001327567-16-000071 — 2.02, 9.01
- 2016-10-24 0001193125-16-745121 — 5.02, 9.01
- 2016-08-30 0001327567-16-000057 — 2.02, 5.03, 8.01, 9.01
- 2016-08-22 0001193125-16-687588 — 5.02, 9.01
- 2016-05-26 0001327567-16-000051 — 2.02, 9.01
- 2016-02-25 0001327567-16-000044 — 2.02, 5.02, 9.01
- 2015-12-14 0001327567-15-000038 — 5.07
- 2015-12-14 0001193125-15-402588 — 1.01, 9.01
- 2015-11-23 0001327567-15-000033 — 2.02, 9.01
- 2015-10-19 0001193125-15-347005 — 1.01, 9.01 — amendment, the index does not say of what
- 2015-09-09 0001327567-15-000022 — 2.02, 9.01
- 2015-08-19 0001193125-15-296115 — 1.01, 2.03
- 2015-06-01 0001193125-15-207786 — 1.01, 2.03
- 2015-05-27 0001327567-15-000015 — 2.02, 9.01
- 2015-03-02 0001327567-15-000006 — 2.02, 9.01
- 2014-12-15 0001327567-14-000046 — 5.07
- 2014-11-24 0001327567-14-000040 — 2.02, 9.01
- 2014-09-22 0001193125-14-348581 — 5.02, 9.01
- 2014-09-09 0001327567-14-000025 — 2.02, 9.01
- 2014-07-01 0001193125-14-257824 — 1.01, 2.03, 3.02, 9.01
- 2014-06-26 0001193125-14-249529 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2014-06-20 0001327567-14-000020 — 9.01 — amendment of 0001193125-14-140511
- 2014-06-04 0001327567-14-000016 — 3.02
- 2014-05-30 0001193125-14-218158 — 2.02 — amendment, the index does not say of what
- 2014-05-28 0001193125-14-215060 — 1.01, 2.02, 3.02, 9.01
- 2014-04-11 0001193125-14-140511 — 2.01, 3.02, 7.01, 9.01
- 2014-03-24 0001193125-14-111318 — 1.01, 3.02, 7.01, 9.01
- 2014-03-13 0001327567-14-000009 — 5.02
- 2014-02-24 0001193125-14-063754 — 2.02, 9.01
- 2013-12-12 0001327567-13-000040 — 5.07
- 2013-11-25 0001327567-13-000033 — 2.02, 9.01
- 2013-09-30 0001193125-13-384966 — 8.01
- 2013-09-09 0001193125-13-361421 — 2.02, 9.01
- 2013-05-30 0001193125-13-241542 — 2.02, 5.02, 9.01
- 2013-03-11 0001193125-13-101082 — 5.02, 9.01
- 2013-02-28 0001193125-13-084193 — 2.02, 9.01
- 2012-12-14 0001193125-12-503335 — 5.07
- 2012-12-06 0001193125-12-493700 — 2.02, 9.01
- 2012-09-24 0001193125-12-401534 — 1.01, 2.03
- 2012-09-20 0001193125-12-398433 — 5.02, 9.01
- 2012-09-10 0001193125-12-386605 — 2.02, 9.01

## late-filing notifications on or before 2017-09-07

- none on or before 2017-09-07

## item 2.02 — earnings release, exhibit 99.1

[0001327567-17-000021:8k_2_02:1]
EX-99.1
3
ex991q417earningsrelease.htm
EXHIBIT 99.1

[0001327567-17-000021:8k_2_02:2]
Exhibit

[0001327567-17-000021:8k_2_02:3]
Exhibit 99.1

[0001327567-17-000021:8k_2_02:4]
Palo Alto Networks Reports Fiscal Fourth Quarter and Fiscal Year 2017 Financial Results

[0001327567-17-000021:8k_2_02:5]
| • | Fiscal fourth quarter revenue grows 27 percent year over year to $509.1 million; |

[0001327567-17-000021:8k_2_02:6]
fiscal year 2017 revenue grows 28 percent year over year to $1.8 billion

[0001327567-17-000021:8k_2_02:7]
| • | Fiscal fourth quarter billings grow 17 percent year over year to $670.8 million; |

[0001327567-17-000021:8k_2_02:8]
fiscal year 2017 billings grow 20 percent year over year to $2.3 billion

[0001327567-17-000021:8k_2_02:9]
| • | Deferred revenue grows 43 percent year over year to $1.8 billion |

[0001327567-17-000021:8k_2_02:10]
SANTA CLARA, Calif. —  August 31, 2017 — Palo Alto Networks® (NYSE: PANW), the next-generation security company, today announced financial results for its fiscal fourth quarter and fiscal year 2017 ended July 31, 2017.

[0001327567-17-000021:8k_2_02:11]
Total revenue for the fiscal fourth quarter 2017 grew 27 percent year over year to $509.1 million, compared with total revenue of $400.8 million for the fiscal fourth quarter 2016. GAAP net loss for the fiscal fourth quarter 2017 was $38.2 million, or $0.42 per diluted share, compared with GAAP net loss of $31.4 million, or $0.35 per diluted share, for the fiscal fourth quarter 2016.

[0001327567-17-000021:8k_2_02:12]
Non-GAAP net income for the fiscal fourth quarter 2017 was $85.5 million, or $0.92 per diluted share, compared with non-GAAP net income of $60.3 million, or $0.66 per diluted share, for the fiscal fourth quarter 2016. A reconciliation between GAAP and non-GAAP information is contained in the tables below.

[0001327567-17-000021:8k_2_02:13]
“We are pleased to have ended fiscal 2017 with a record fourth quarter, including market-leading revenue growth and the highest number of new customer additions recorded in a single quarter by the company.

[0001327567-17-000021:8k_2_02:14]
For the fiscal year, revenue was $1.8 billion, up 28 percent year over year; our customer base grew to more than 42,500; and we delivered the largest product and features launch in our history,” said Mark McLaughlin, chief executive officer of Palo Alto Networks. “Also, Steffan Tomlinson, our chief financial officer, has informed me of his intent to retire from his position. I would like to thank Steffan for his contributions to Palo Alto Networks and his leadership role in guiding the company through a period of tremendous growth and market share gains. We are initiating a search for his replacement, and Steffan will remain in his current position until the search is completed.”

[0001327567-17-000021:8k_2_02:15]
For fiscal year 2017, total revenue grew 28 percent to $1.8 billion, compared with $1.4 billion in fiscal year 2016. GAAP net loss was $216.6 million, or $2.39 per diluted share, in fiscal year 2017, compared with GAAP net loss of $192.7 million, or $2.21 per diluted share, in fiscal year 2016. Non-GAAP net income for fiscal year 2017 was $253.4 million, or $2.71 per diluted share, compared with non-GAAP net income of $172.9 million, or $1.89 per diluted share, in fiscal year 2016.

[0001327567-17-000021:8k_2_02:16]
Steffan Tomlinson, chief financial officer of Palo Alto Networks, commented, “During the quarter, we added approximately 3,000 new customers and reported record revenue of $509 million, an increase of 27 percent year over year. We also delivered record deferred revenue and billings, while generating cash flow from operations of $240 million and free cash flow of $190 million, ending the fiscal year with approximately $2.2 billion in cash, cash equivalents and investments.”

[0001327567-17-000021:8k_2_02:17]
Recent Highlights

[0001327567-17-000021:8k_2_02:18]
| • | Recognized as a Leader again – For the sixth consecutive time, we were recognized as a leader in the Gartner, Inc. Magic Quadrant for Enterprise Network Firewalls report.1 |

[0001327567-17-000021:8k_2_02:19]
__________

[0001327567-17-000021:8k_2_02:20]
1 Gartner, Inc. “Magic Quadrant for Enterprise Network Firewalls,” July 10, 2017.

[0001327567-17-000021:8k_2_02:21]
2

[0001327567-17-000021:8k_2_02:22]
| • | Announced GlobalProtect cloud service – GlobalProtect™ enables customers to extend the protections of our Next-Generation Security Platform to remote networks and mobile users. The new GlobalProtect cloud service offering operationalizes the deployment by using a cloud-based security infrastructure operated by Palo Alto Networks. General availability is planned for September 2017. |

[0001327567-17-000021:8k_2_02:23]
| • | Announced Palo Alto Networks Logging Service – This new subscription service is a cloud-based offering for context-rich, enhanced logs generated by our security offerings, initially for those of our next-generation firewalls and GlobalProtect cloud service. The Logging Service is operated by Palo Alto Networks and allows customers to collect ever-expanding rates of data without needing to plan for, deploy or operate local compute and storage. General availability is planned for September 2017. |

[0001327567-17-000021:8k_2_02:24]
| • | Announced Palo Alto Networks Application Framework – Continuing the evolution of our Next-Generation Security Platform, this new framework introduces a SaaS (software as a service) consumption model that reinvents how customers rapidly access, evaluate and adopt the most compelling new security technologies as an extension of the Next-Generation Security Platform they already own and operate. This new framework enables Palo Alto Networks, third-party developers, MSSPs and customers to rapidly build and deliver innovative cloud-based security services through a suite of cloud APIs, services, compute and native access to customer-specific data stores. The framework will feature apps developed by security providers of all sizes, including over 30 leading organizations that were part of the announcement. General availability is planned for early calendar 2018. |

[0001327567-17-000021:8k_2_02:25]
| • | Achieved maximum protection and performance scores by AV-TEST for Traps version 4.0 – AV-TEST, a third-party testing organization with extensive experience testing endpoint security software, tested Palo Alto Networks Traps™ advanced endpoint protection version 4.0 using its standard methodology. Traps achieved 100 percent detection of real-world attacks and a maximum performance score. These results, along with the AV-Comparatives “Approved Business Product” Award achieved in 2016, further validate Traps as a highly effective replacement for legacy antivirus products. |

[0001327567-17-000021:8k_2_02:26]
| • | Joined forces with Girl Scouts of the USA – Palo Alto Networks and Girl Scouts® of the USA joined forces to deliver the first-ever national Girl Scout Cybersecurity badges for girls in grades K-12, introducing cybersecurity education to millions of girls across the United States through compelling programs designed to increase their interest and instill in them a valuable 21st century skillset. |

[0001327567-17-000021:8k_2_02:27]
| • | Organizational update – The company announced that Lee Klarich, executive vice president of product management, has been named chief product officer with responsibility for engineering and product management. Mr. Klarich, who joined the company in May 2006, has been a long-time member of senior management and played a key role in leading the team that has delivered our Next-Generation Security Platform. In addition, Mr. Sridhar Ramaswamy was appointed to the board of directors and joined our Nominating and Corporate Governance Committee. Mr. Ramaswamy, currently senior vice president, Ads & Commerce at Google Inc., has held various leadership roles in Google’s engineering group since 2003, and brings deep technical engineering experience and extensive cloud, analytics and infrastructure expertise. |

[0001327567-17-000021:8k_2_02:28]
Financial Outlook

[0001327567-17-000021:8k_2_02:29]
Palo Alto Networks provides guidance based on current market conditions and expectations.

[0001327567-17-000021:8k_2_02:30]
4

[0001327567-17-000021:8k_2_02:31]
For the fiscal first quarter 2018, we expect:

[0001327567-17-000021:8k_2_02:32]
| • | Total revenue in the range of $482 to $492 million, representing year-over-year growth between 21 percent and 24 percent. Product revenue in the range of $170 to $173 million, representing year-over-year growth between 4 percent and 6 percent. |

[0001327567-17-000021:8k_2_02:33]
| • | Total billings in the range of $580 to $600 million, representing year-over-year growth between 12 percent and 16 percent. |

[0001327567-17-000021:8k_2_02:34]
| • | Diluted non-GAAP net income per share in the range of $0.67 to $0.69 using 93.5 to 95.5 million shares. |

[0001327567-17-000021:8k_2_02:35]
For the fiscal year 2018, we expect:

[0001327567-17-000021:8k_2_02:36]
| • | Total revenue in the range of $2.125 to $2.165 billion, representing year-over-year growth between 21 percent and 23 percent. Product revenue in the range of $735 to $750 million, representing year-over-year growth between 4 percent and 6 percent. |

[0001327567-17-000021:8k_2_02:37]
| • | Total billings in the range of $2.64 to $2.70 billion, representing year-over-year growth between 15 percent and 18 percent. |

[0001327567-17-000021:8k_2_02:38]
| • | Diluted non-GAAP net income per share in the range of $3.24 to $3.34 using 96 to 98 million shares. |

[0001327567-17-000021:8k_2_02:39]
Guidance for non-GAAP financial measures excludes share-based compensation related charges including share-based payroll tax expense, acquisition related costs, amortization expense of acquired intangible assets, litigation-related charges including legal settlements, facility exit costs, non-cash interest expense related to our convertible senior notes, foreign currency gains (losses) and income and other tax effects associated with these items, and certain non-recurring expenses. We have not reconciled diluted non-GAAP net income per share guidance to GAAP net income (loss) per diluted share because we do not

[0001327567-17-000021:8k_2_02:40]
5

[0001327567-17-000021:8k_2_02:41]
provide guidance on GAAP net income (loss) and would not be able to present the various reconciling cash and non-cash items between GAAP net income (loss) and non-GAAP net income, including share-based compensation expense, without unreasonable effort. Share-based compensation expense is impacted by the company’s future hiring and retention needs and, to a lesser extent, the future fair market value of the company’s common stock, all of which is difficult to predict and subject to constant change. The actual amounts of such reconciling items will have a significant impact on the company’s GAAP net income (loss) per diluted share.

[0001327567-17-000021:8k_2_02:42]
Conference Call Information

[0001327567-17-000021:8k_2_02:43]
Palo Alto Networks will host a conference call for analysts and investors to discuss its fiscal fourth quarter and fiscal year 2017 results and outlook for its fiscal first quarter and full fiscal year 2018 today at 4:30 p.m. Eastern time/1:30 p.m. Pacific time. Open to the public, investors may access the call by dialing 1-888-293-6979 or 1-719-325-4879 and using conference ID 8255664. A live audio webcast of the conference call, along with supplemental financial information, will also be accessible from the “Investors” section of our website at investors.paloaltonetworks.com. Following the webcast, an archived version will be available on our website for one year. A telephonic replay of the call will be available three hours after the call, will run for ten days, and may be accessed by dialing 1-888-203-1112 or 1-719-457-0820 and entering the passcode 8255664.

[0001327567-17-000021:8k_2_02:44]
Forward-Looking Statements

[0001327567-17-000021:8k_2_02:45]
This press release contains forward-looking statements that involve risks and uncertainties, including statements regarding our future financial and operating performance, including our financial outlook for the fiscal first quarter and full fiscal year 2018, our expectations regarding the benefits and timing of new subscription offerings, upcoming organizational changes, including the company’s transition to a new chief financial officer, and our expectation to recognize a cease-use loss in the first quarter of fiscal 2018

[0001327567-17-000021:8k_2_02:46]
related to our previous headquarter facilities. There are a significant number of factors that could cause actual results to differ materially from statements made in this press release, including: our limited operating history; our ability to identify and effectively implement the necessary changes to address execution challenges; risks associated with managing our rapid growth; organizational changes, including with regard to identifying a successor to our chief financial officer and the timing of these changes; the risks associated with new products and subscription and support offerings, including the discovery of software bugs; our ability to attract and retain new customers; delays in the development or release of new subscription offerings, or the failure to timely develop and achieve market acceptance of new products and subscriptions as well as existing products and subscription and support offerings; rapidly evolving technological developments in the market for network security products and subscription and support offerings; changes in the timing or the amount of estimated cash flow used to calculate the cease-use loss; length of sales cycles; and general market, political, economic and business conditions.

[0001327567-17-000021:8k_2_02:47]
Additional risks and uncertainties that could affect our financial results are included under the captions “Risk Factors” and “Management’s Discussion and Analysis of Financial Condition and Results of Operations” in our Quarterly Report on Form 10-Q filed with the SEC on June 1, 2017, which is available on our website at investors.paloaltonetworks.com and on the SEC’s website at www.sec.gov. Additional information will also be set forth in other filings that we make with the SEC from time to time. All forward-looking statements in this press release are based on information available to us as of the date hereof, and we do not assume any obligation to update the forward-looking statements provided to reflect events that occur or circumstances that exist after the date on which they were made.

[0001327567-17-000021:8k_2_02:48]
Non-GAAP Financial Measures and Other Key Metrics

[0001327567-17-000021:8k_2_02:49]
Palo Alto Networks has provided in this press release financial information that has not been prepared in accordance with generally accepted accounting principles in the United States (GAAP). The company

[0001327567-17-000021:8k_2_02:50]
7

[0001327567-17-000021:8k_2_02:51]
uses these non-GAAP financial measures and key metrics internally in analyzing its financial results and believes that the use of these non-GAAP financial measures and key metrics is useful to investors as an additional tool to evaluate ongoing operating results and trends, and in comparing the company’s financial results with other companies in its industry, many of which present similar non-GAAP financial measures or key metrics.

[0001327567-17-000021:8k_2_02:52]
The presentation of these non-GAAP financial measures and key metrics are not meant to be considered in isolation or as a substitute for comparable GAAP financial measures, and should be read only in conjunction with the company’s consolidated financial statements prepared in accordance with GAAP. A reconciliation of the company’s historical non-GAAP financial measures and key metrics to their most directly comparable GAAP measures has been provided in the financial statement tables included in this press release, and investors are encouraged to review these reconciliations.

[0001327567-17-000021:8k_2_02:53]
Non-GAAP net income and net income per share, diluted. Palo Alto Networks defines non-GAAP net income as net income (loss) plus share-based compensation related charges including share-based payroll tax expense, acquisition related costs, amortization expense of acquired intangible assets, litigation related charges including legal settlements, facility exit costs, non-cash interest expense related to the company’s convertible senior notes, and intellectual property restructuring related charges. The company also excludes from non-GAAP net income the foreign currency gains (losses) and tax effects associated with these items in order to provide a complete picture of the company’s recurring core business operating results. The company defines non-GAAP net income per share, diluted, as non-GAAP net income divided by the weighted average diluted shares outstanding, which includes the potentially dilutive effect of the company’s employee equity incentive plan awards and the company’s convertible senior notes outstanding, after giving effect to the anti-dilutive impact of the company’s note hedge agreements, which reduces the potential economic dilution that otherwise would occur upon conversion of the company’s

[0001327567-17-000021:8k_2_02:54]
convertible senior notes. Under GAAP, the anti-dilutive impact of the note hedge is not reflected in diluted shares outstanding. The company believes that excluding these items from non-GAAP net income and non-GAAP net income per share, diluted, provides management and investors with greater visibility into the underlying performance of the company’s core business operating results, meaning its operating performance excluding these items and, from time to time, other discrete charges that are infrequent in nature, over multiple periods.

[0001327567-17-000021:8k_2_02:55]
Billings. Palo Alto Networks defines billings as total revenue plus the change in total deferred revenue, net of acquired deferred revenue, during the period. The company considers billings to be a key metric used by management to manage the company’s business given the company’s hybrid-SaaS revenue model, and believes billings provides investors with an important indicator of the health and visibility of the company’s business because it includes subscription and support revenue, which is recognized ratably over the contractual service period, and product revenue, which is recognized at the time of shipment, provided that all other revenue recognition criteria have been met. The company considers billings to be a useful metric for management and investors, particularly if sales of subscriptions continue to increase and the company experiences strong renewal rates for subscriptions and support.

[0001327567-17-000021:8k_2_02:56]
Free cash flow. Palo Alto Networks defines free cash flow as cash provided by operating activities less purchases of property, equipment, and other assets. The company considers free cash flow to be a profitability and liquidity measure that provides useful information to management and investors about the amount of cash generated by the business after necessary capital expenditures.

[0001327567-17-000021:8k_2_02:57]
Investors are cautioned that there are a number of limitations associated with the use of non-GAAP financial measures and key metrics as analytical tools. In particular, the billings metric reported by the company includes amounts that have not yet been recognized as revenue and free cash flow does not

[0001327567-17-000021:8k_2_02:58]
9

[0001327567-17-000021:8k_2_02:59]
represent the total increase or decrease in our cash balance for the period. In addition, many of the adjustments to the company’s GAAP financial measures reflect the exclusion of items that are recurring and will be reflected in the company’s financial results for the foreseeable future, such as share-based compensation, which is an important part of Palo Alto Networks employees’ compensation and impacts their performance. Furthermore, these non-GAAP financial measures are not based on any standardized methodology prescribed by GAAP, and the components that Palo Alto Networks excludes in its calculation of non-GAAP financial measures may differ from the components that its peer companies exclude when they report their non-GAAP results of operations. Palo Alto Networks compensates for these limitations by providing specific information regarding the GAAP amounts excluded from these non-GAAP financial measures. In the future, the company may also exclude non-recurring expenses and other expenses that do not reflect the company’s core business operating results.

[0001327567-17-000021:8k_2_02:60]
About Palo Alto Networks

[0001327567-17-000021:8k_2_02:61]
Palo Alto Networks is the next-generation security company, leading a new era in cybersecurity by safely enabling applications and preventing cyber breaches for tens of thousands of organizations worldwide. Built with an innovative approach and highly differentiated cyberthreat prevention capabilities, our game-changing security platform delivers security far superior to legacy or point products, safely enables daily business operations, and protects an organization’s most valuable assets. Find out more at www.paloaltonetworks.com.

[0001327567-17-000021:8k_2_02:62]
Palo Alto Networks and the Palo Alto Networks logo are trademarks of Palo Alto Networks, Inc. in the United States and in jurisdictions throughout the world. All other trademarks, trade names or service marks used or mentioned herein belong to their respective owners.

[0001327567-17-000021:8k_2_02:63]
“Gartner does not endorse any vendor, product or service depicted in its research publications, and does not advise technology users to select only those vendors with the highest ratings or other designation. Gartner research publications consist of the opinions of Gartner's research organization and should not

[0001327567-17-000021:8k_2_02:64]
be construed as statements of fact. Gartner disclaims all warranties, expressed or implied, with respect to this research, including any warranties of merchantability or fitness for a particular purpose.”

[0001327567-17-000021:8k_2_02:65]
Media Contact:

[0001327567-17-000021:8k_2_02:66]
Jennifer Jasper Smith

[0001327567-17-000021:8k_2_02:67]
Head of Corporate Communications

[0001327567-17-000021:8k_2_02:68]
Palo Alto Networks

[0001327567-17-000021:8k_2_02:69]
408-638-3280

[0001327567-17-000021:8k_2_02:70]
jjsmith@paloaltonetworks.com

[0001327567-17-000021:8k_2_02:71]
Investor Relations Contact:

[0001327567-17-000021:8k_2_02:72]
Kelsey Turcotte

[0001327567-17-000021:8k_2_02:73]
Vice President of Investor Relations

[0001327567-17-000021:8k_2_02:74]
Palo Alto Networks

[0001327567-17-000021:8k_2_02:75]
408-753-3872

[0001327567-17-000021:8k_2_02:76]
kturcotte@paloaltonetworks.com

[0001327567-17-000021:8k_2_02:77]
| Palo Alto Networks, Inc. |
| Preliminary Consolidated Statements of Operations |
| (In millions, except per share data) |
| (Unaudited) |
|  | Three Months Ended July 31, |  | Year Ended July 31, |
|  | 2017(2) |  | 2016 |  | 2017(2) |  | 2016 |
|  |  |  | (As Adjusted)(1) |  |  |  | (As Adjusted)(1) |
| Revenue: |  |  |  |  |  |  |  |
| Product | $ | 212.3 |  |  | $ | 191.1 |  |  | $ | 709.1 |  |  | $ | 670.8 |  |
| Subscription and support | 296.8 |  |  | 209.7 |  |  | 1,052.5 |  |  | 707.7 |  |
| Total revenue | 509.1 |  |  | 400.8 |  |  | 1,761.6 |  |  | 1,378.5 |  |
| Cost of revenue: |  |  |  |  |  |  |  |
| Product | 63.7 |  |  | 48.5 |  |  | 201.4 |  |  | 175.4 |  |
| Subscription and support | 74.8 |  |  | 53.2 |  |  | 275.2 |  |  | 194.6 |  |
| Total cost of revenue | 138.5 |  |  | 101.7 |  |  | 476.6 |  |  | 370.0 |  |
| Total gross profit | 370.6 |  |  | 299.1 |  |  | 1,285.0 |  |  | 1,008.5 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 87.3 |  |  | 76.5 |  |  | 347.4 |  |  | 284.2 |  |
| Sales and marketing | 245.4 |  |  | 205.4 |  |  | 919.1 |  |  | 743.2 |  |
| General and administrative | 65.2 |  |  | 39.9 |  |  | 198.3 |  |  | 138.4 |  |
| Total operating expenses | 397.9 |  |  | 321.8 |  |  | 1,464.8 |  |  | 1,165.8 |  |
| Operating loss | (27.3 | ) |  | (22.7 | ) |  | (179.8 | ) |  | (157.3 | ) |
| Interest expense | (6.2 | ) |  | (6.0 | ) |  | (24.5 | ) |  | (23.4 | ) |
| Other income, net | 2.9 |  |  | 2.7 |  |  | 10.2 |  |  | 8.4 |  |
| Loss before income taxes | (30.6 | ) |  | (26.0 | ) |  | (194.1 | ) |  | (172.3 | ) |
| Provision for income taxes | 7.6 |  |  | 5.4 |  |  | 22.5 |  |  | 20.4 |  |
| Net loss | $ | (38.2 | ) |  | $ | (31.4 | ) |  | $ | (216.6 | ) |  | $ | (192.7 | ) |
| Net loss per share, basic and diluted | $ | (0.42 | ) |  | $ | (0.35 | ) |  | $ | (2.39 | ) |  | $ | (2.21 | ) |
| Weighted-average shares used to compute net loss per share, basic and diluted | 90.9 |  |  | 88.9 |  |  | 90.6 |  |  | 87.1 |  |

[0001327567-17-000021:8k_2_02:78]
___________

[0001327567-17-000021:8k_2_02:79]
| (1) | Certain amounts have been adjusted due to the Company’s change in accounting policy for sales commissions. Refer to Appendix A for more information. |

[0001327567-17-000021:8k_2_02:80]
| (2) | The Company early adopted new share-based payment accounting guidance in its second quarter of fiscal 2017, which simplified, among other things, the accounting for income tax consequences and the method of accounting for forfeitures of share-based payment awards. As a result of the early adoption, the Company’s share-based compensation and provision for income taxes decreased by $0.9 million and $4.0 million, respectively, for the three months ended October 31, 2016. These adjustments are reflected in the results for the fiscal year ended July 31, 2017. |

[0001327567-17-000021:8k_2_02:81]
12

[0001327567-17-000021:8k_2_02:82]
| Palo Alto Networks, Inc. |
| Reconciliation of GAAP to Non-GAAP Financial Measures |
| (In millions, except per share amounts) |
| (Unaudited) |
|  | Three Months Ended |  | Year Ended |
|  | July 31, |  | July 31, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
|  |  |  | (As Adjusted)(1) |  |  |  | (As Adjusted)(1) |
| GAAP net loss | $ | (38.2 | ) |  | $ | (31.4 | ) |  | $ | (216.6 | ) |  | $ | (192.7 | ) |
| Share-based compensation related charges | 120.9 |  |  | 112.7 |  |  | 488.9 |  |  | 407.5 |  |
| Acquisition related costs | — |  |  | — |  |  | 3.1 |  |  | — |  |
| Amortization expense of acquired intangible assets | 2.5 |  |  | 2.0 |  |  | 8.9 |  |  | 8.3 |  |
| Litigation related charges(2) | 3.1 |  |  | 3.1 |  |  | 12.3 |  |  | 12.3 |  |
| Facility exit costs(3) | 21.3 |  |  | — |  |  | 21.3 |  |  | — |  |
| Non-cash interest expense related to convertible notes | 6.2 |  |  | 6.0 |  |  | 24.5 |  |  | 23.4 |  |
| Foreign currency (gain) loss associated with non-GAAP adjustments | 0.6 |  |  | (0.6 | ) |  | 2.4 |  |  | (0.3 | ) |
| Income tax and other tax adjustments related to the above | (30.9 | ) |  | (31.5 | ) |  | (91.4 | ) |  | (85.6 | ) |
| Non-GAAP net income | $ | 85.5 |  |  | $ | 60.3 |  |  | $ | 253.4 |  |  | $ | 172.9 |  |
| GAAP net loss per share, diluted | $ | (0.42 | ) |  | $ | (0.35 | ) |  | $ | (2.39 | ) |  | $ | (2.21 | ) |
| Share-based compensation related charges | 1.31 |  |  | 1.25 |  |  | 5.30 |  |  | 4.58 |  |
| Acquisition related costs | 0.00 |  |  | 0.00 |  |  | 0.03 |  |  | 0.00 |  |
| Amortization expense of acquired intangible assets | 0.03 |  |  | 0.02 |  |  | 0.10 |  |  | 0.10 |  |
| Litigation related charges(2) | 0.03 |  |  | 0.03 |  |  | 0.14 |  |  | 0.14 |  |
| Facility exit costs(3) | 0.23 |  |  | 0.00 |  |  | 0.24 |  |  | 0.00 |  |
| Non-cash interest expense related to convertible notes | 0.07 |  |  | 0.07 |  |  | 0.27 |  |  | 0.27 |  |
| Foreign currency (gain) loss associated with non-GAAP adjustments | 0.01 |  |  | (0.01 | ) |  | 0.03 |  |  | 0.00 |  |
| Income tax and other tax adjustments related to the above | (0.34 | ) |  | (0.35 | ) |  | (1.01 | ) |  | (0.99 | ) |
| Non-GAAP net income per share, diluted | $ | 0.92 |  |  | $ | 0.66 |  |  | $ | 2.71 |  |  | $ | 1.89 |  |
| GAAP weighted-average shares used to compute net loss per share, diluted | 90.9 |  |  | 88.9 |  |  | 90.6 |  |  | 87.1 |  |
| Weighted-average effect of potentially dilutive securities(4) | 2.4 |  |  | 2.8 |  |  | 3.0 |  |  | 4.2 |  |
| Non-GAAP weighted-average shares used to compute net income per share, diluted | 93.3 |  |  | 91.7 |  |  | 93.6 |  |  | 91.3 |  |
| Net cash provided by operating activities | $ | 239.5 |  |  | $ | 187.3 |  |  | $ | 868.5 |  |  | $ | 658.6 |  |
| Less: purchases of property, equipment, and other assets | 49.2 |  |  | 16.3 |  |  | 163.4 |  |  | 72.5 |  |
| Free cash flow (non-GAAP) | $ | 190.3 |  |  | $ | 171.0 |  |  | $ | 705.1 |  |  | $ | 586.1 |  |
| Net cash provided by (used in) investing activities | $ | (61.5 | ) |  | $ | 0.4 |  |  | $ | (472.6 | ) |  | $ | (338.9 | ) |
| Net cash provided by (used in) financing activities | $ | (125.7 | ) |  | $ | (3.3 | ) |  | $ | (386.0 | ) |  | $ | 38.9 |  |

[0001327567-17-000021:8k_2_02:83]
___________

[0001327567-17-000021:8k_2_02:84]
| (1) | Certain amounts have been adjusted due to the Company’s change in accounting policy for sales commissions. Refer to Appendix A for more information. |

[0001327567-17-000021:8k_2_02:85]
| (2) | Consists of the amortization of intellectual property licenses. |

[0001327567-17-000021:8k_2_02:86]
| (3) | Consists of charges related to the relocation of the Company’s corporate headquarters, including an impairment loss of $20.9 million and accelerated depreciation. The Company expects to recognize a cease-use loss in the first quarter of fiscal 2018 of approximately $15.4 million related to its exit from its previous headquarter facilities. |

[0001327567-17-000021:8k_2_02:87]
| (4) | Non-GAAP net income per share, diluted, includes the potentially dilutive effect of employee equity incentive plan awards and convertible senior notes outstanding. In addition, non-GAAP net income per share, diluted, includes the anti-dilutive impact of the Company’s note hedge agreements, which reduced the potentially dilutive effect of the convertible notes by 1.0 million shares and 0.9 million shares for the fiscal fourth quarter and fiscal year ended July 31, 2017, respectively, and 0.6 million shares and 1.4 million shares for the fiscal fourth quarter and fiscal year ended July 31, 2016, respectively. |

[0001327567-17-000021:8k_2_02:88]
13

[0001327567-17-000021:8k_2_02:89]
| Palo Alto Networks, Inc. |
| Calculation of Billings |
| (In millions) |
| (Unaudited) |
|  | Three Months Ended |  | Year Ended |
|  | July 31, |  | July 31, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Total revenue | $ | 509.1 |  |  | $ | 400.8 |  |  | $ | 1,761.6 |  |  | $ | 1,378.5 |  |
| Add: change in total deferred revenue, net of acquired deferred revenue | 161.7 |  |  | 171.6 |  |  | 531.8 |  |  | 527.1 |  |
| Billings | $ | 670.8 |  |  | $ | 572.4 |  |  | $ | 2,293.4 |  |  | $ | 1,905.6 |  |

[0001327567-17-000021:8k_2_02:90]
14

[0001327567-17-000021:8k_2_02:91]
| Palo Alto Networks, Inc. |
| Preliminary Consolidated Balance Sheets |
| (In millions) |
| (Unaudited) |
|  | July 31, 2017 |  | July 31, 2016 |
|  |  |  | (As Adjusted)(1) |
| Assets |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 744.3 |  |  | $ | 734.4 |  |
| Short-term investments | 630.7 |  |  | 551.2 |  |
| Accounts receivable, net | 432.1 |  |  | 348.7 |  |
| Prepaid expenses and other current assets | 169.2 |  |  | 139.7 |  |
| Total current assets | 1,976.3 |  |  | 1,774.0 |  |
| Property and equipment, net | 211.1 |  |  | 117.2 |  |
| Long-term investments | 789.3 |  |  | 652.8 |  |
| Goodwill | 238.8 |  |  | 163.5 |  |
| Intangible assets, net | 53.7 |  |  | 44.0 |  |
| Other assets | 169.1 |  |  | 106.7 |  |
| Total assets | $ | 3,438.3 |  |  | $ | 2,858.2 |  |
| Liabilities and stockholders’ equity |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 35.5 |  |  | $ | 30.2 |  |
| Accrued compensation | 117.5 |  |  | 73.5 |  |
| Accrued and other liabilities | 79.9 |  |  | 39.2 |  |
| Deferred revenue | 968.4 |  |  | 703.9 |  |
| Total current liabilities | 1,201.3 |  |  | 846.8 |  |
| Convertible senior notes, net | 524.7 |  |  | 500.2 |  |
| Long-term deferred revenue | 805.1 |  |  | 536.9 |  |
| Other long-term liabilities | 147.6 |  |  | 79.4 |  |
| Stockholders’ equity: |  |  |  |
| Preferred stock | — |  |  | — |  |
| Common stock and additional paid-in capital | 1,599.7 |  |  | 1,515.5 |  |
| Accumulated other comprehensive income (loss) | (3.4 | ) |  | 1.0 |  |
| Accumulated deficit | (836.7 | ) |  | (621.6 | ) |
| Total stockholders’ equity | 759.6 |  |  | 894.9 |  |
| Total liabilities and stockholders’ equity | $ | 3,438.3 |  |  | $ | 2,858.2 |  |

[0001327567-17-000021:8k_2_02:92]
___________

[0001327567-17-000021:8k_2_02:93]
| (1) | Certain amounts have been adjusted due to the Company’s change in accounting policy for sales commissions. Refer to Appendix A for more information. |

[0001327567-17-000021:8k_2_02:94]
15

[0001327567-17-000021:8k_2_02:95]
| Palo Alto Networks, Inc. |
| Preliminary Consolidated Statements of Cash Flows |
| (In millions) |
| (Unaudited) |
|  | Year Ended July 31, |
|  | 2017 |  | 2016 |
|  |  |  | (As Adjusted)(1) |
| Cash flows from operating activities |  |  |  |
| Net loss | $ | (216.6 | ) |  | $ | (192.7 | ) |
| Adjustments to reconcile net loss to net cash provided by operating activities: |  |  |  |
| Share-based compensation for equity based awards | 474.5 |  |  | 392.8 |  |
| Depreciation and amortization | 59.8 |  |  | 42.8 |  |
| Asset impairment related to facility exit | 20.9 |  |  | — |  |
| Amortization of investment premiums, net of accretion of purchase discounts | 2.7 |  |  | 3.0 |  |
| Amortization of debt discount and debt issuance costs | 24.5 |  |  | 23.4 |  |
| Changes in operating assets and liabilities, net of effects of acquisitions: |  |  |  |
| Accounts receivable, net | (82.9 | ) |  | (136.4 | ) |
| Prepaid expenses and other assets | (48.1 | ) |  | (31.2 | ) |
| Accounts payable | 5.9 |  |  | 15.1 |  |
| Accrued compensation | 42.8 |  |  | (6.3 | ) |
| Accrued and other liabilities | 53.2 |  |  | 21.0 |  |
| Deferred revenue | 531.8 |  |  | 527.1 |  |
| Net cash provided by operating activities(2) | 868.5 |  |  | 658.6 |  |
| Cash flows from investing activities |  |  |  |
| Purchases of investments | (995.9 | ) |  | (1,037.0 | ) |
| Proceeds from sales of investments | — |  |  | 141.9 |  |
| Proceeds from maturities of investments | 777.4 |  |  | 628.7 |  |
| Business acquisitions, net of cash acquired | (90.7 | ) |  | — |  |
| Purchases of property, equipment, and other assets | (163.4 | ) |  | (72.5 | ) |
| Net cash used in investing activities | (472.6 | ) |  | (338.9 | ) |
| Cash flows from financing activities |  |  |  |
| Repurchases of common stock | (411.0 | ) |  | — |  |
| Proceeds from sales of shares through employee equity incentive plans | 46.4 |  |  | 45.3 |  |
| Payments for taxes related to net share settlement of equity awards | (21.4 | ) |  | — |  |
| Payment of deferred consideration related to prior year business acquisition | — |  |  | (6.4 | ) |
| Net cash provided by (used in) financing activities(2) | (386.0 | ) |  | 38.9 |  |
| Net increase in cash and cash equivalents | 9.9 |  |  | 358.6 |  |
| Cash and cash equivalents - beginning of period | 734.4 |  |  | 375.8 |  |
| Cash and cash equivalents - end of period | $ | 744.3 |  |  | $ | 734.4 |  |

[0001327567-17-000021:8k_2_02:96]
___________

[0001327567-17-000021:8k_2_02:97]
| (1) | Certain amounts have been adjusted due to the Company’s change in accounting policy for sales commissions. Refer to Appendix A for more information. |

[0001327567-17-000021:8k_2_02:98]
| (2) | The Company early adopted new share-based payment accounting guidance in its second quarter of fiscal 2017, which simplified, among other things, the presentation of excess tax benefits in the statement of cash flows. The Company adopted this portion of the guidance on a retrospective basis, which increased net cash provided by operating activities by $0.5 million for the fiscal year ended July 31, 2016, with a corresponding decrease to net cash provided by financing activities. |

[0001327567-17-000021:8k_2_02:99]
16

[0001327567-17-000021:8k_2_02:100]
Palo Alto Networks, Inc.

[0001327567-17-000021:8k_2_02:101]
Appendix A

[0001327567-17-000021:8k_2_02:102]
Change in Accounting Policy

[0001327567-17-000021:8k_2_02:103]
(Unaudited)

[0001327567-17-000021:8k_2_02:104]
Effective August 1, 2016, the Company voluntarily changed its accounting policy for sales commissions that are incremental and directly related to non-cancelable customer sales contracts from recording an expense when incurred to deferral and amortization of the sales commissions over the term of the related contract in proportion to the recognized revenue. The adoption of this accounting policy change has been applied retrospectively to all prior periods presented in this document, in which the cumulative effect of the change has been reflected as of the beginning of the earliest period presented.

[0001327567-17-000021:8k_2_02:105]
The following tables present the changes to financial statement line items as a result of the accounting change for the periods presented in the Company’s preliminary consolidated financial statements (in millions, except per share data):

[0001327567-17-000021:8k_2_02:106]
|  | July 31, 2017 |  | July 31, 2016 |
|  | Computed under Prior Method |  | Impact of Commission Adjustment |  | As Reported |  | As Previously Reported |  | Impact of Commission Adjustment |  | As Adjusted |
| Preliminary Consolidated Balance Sheets |  |  |  |  |  |  |  |  |  |  |  |
| Prepaid expenses and other current assets | $ | 95.8 |  |  | $ | 73.4 |  |  | $ | 169.2 |  |  | $ | 84.8 |  |  | $ | 54.9 |  |  | $ | 139.7 |  |
| Other assets | 97.8 |  |  | 71.3 |  |  | 169.1 |  |  | 64.6 |  |  | 50.1 |  |  | 114.7 |  |
| Accumulated deficit | $ | (981.4 | ) |  | $ | 144.7 |  |  | $ | (836.7 | ) |  | $ | (726.6 | ) |  | $ | 105.0 |  |  | $ | (621.6 | ) |

[0001327567-17-000021:8k_2_02:107]
|  | Three Months Ended July 31, 2017 |  | Three Months Ended July 31, 2016 |
|  | Computed under Prior Method |  | Impact of Commission Adjustment |  | As Reported |  | As Previously Reported |  | Impact of Commission Adjustment |  | As Adjusted |
| Preliminary Consolidated Statements of Operations |  |  |  |  |  |  |  |  |  |  |  |
| Sales and marketing | $ | 273.6 |  |  | $ | (28.2 | ) |  | $ | 245.4 |  |  | $ | 228.1 |  |  | $ | (22.7 | ) |  | $ | 205.4 |  |
| Operating loss | (55.5 | ) |  | 28.2 |  |  | (27.3 | ) |  | (45.4 | ) |  | 22.7 |  |  | (22.7 | ) |
| Provision for income taxes | 8.3 |  |  | (0.7 | ) |  | 7.6 |  |  | 5.8 |  |  | (0.4 | ) |  | 5.4 |  |
| Net loss | $ | (67.1 | ) |  | $ | 28.9 |  |  | $ | (38.2 | ) |  | $ | (54.5 | ) |  | $ | 23.1 |  |  | $ | (31.4 | ) |
| Net loss per share, basic and diluted | $ | (0.74 | ) |  | $ | 0.32 |  |  | $ | (0.42 | ) |  | $ | (0.61 | ) |  | $ | 0.26 |  |  | $ | (0.35 | ) |
| Weighted-average shares used to compute net loss per share, basic and diluted | 90.9 |  |  | — |  |  | 90.9 |  |  | 88.9 |  |  | — |  |  | 88.9 |  |

[0001327567-17-000021:8k_2_02:108]
|  | Year Ended July 31, 2017 |  | Year Ended July 31, 2016 |
|  | Computed under Prior Method |  | Impact of Commission Adjustment |  | As Reported |  | As Previously Reported |  | Impact of Commission Adjustment |  | As Adjusted |
| Preliminary Consolidated Statements of Operations |  |  |  |  |  |  |  |  |  |  |  |
| Sales and marketing | $ | 958.4 |  |  | $ | (39.3 | ) |  | $ | 919.1 |  |  | $ | 776.0 |  |  | $ | (32.8 | ) |  | $ | 743.2 |  |
| Operating loss | (219.1 | ) |  | 39.3 |  |  | (179.8 | ) |  | (190.1 | ) |  | 32.8 |  |  | (157.3 | ) |
| Provision for income taxes | 22.9 |  |  | (0.4 | ) |  | 22.5 |  |  | 20.8 |  |  | (0.4 | ) |  | 20.4 |  |
| Net loss | $ | (256.3 | ) |  | $ | 39.7 |  |  | $ | (216.6 | ) |  | $ | (225.9 | ) |  | $ | 33.2 |  |  | $ | (192.7 | ) |
| Net loss per share, basic and diluted | $ | (2.83 | ) |  | $ | 0.44 |  |  | $ | (2.39 | ) |  | $ | (2.59 | ) |  | $ | 0.38 |  |  | $ | (2.21 | ) |
| Weighted-average shares used to compute net loss per share, basic and diluted | 90.6 |  |  | — |  |  | 90.6 |  |  | 87.1 |  |  | — |  |  | 87.1 |  |

[0001327567-17-000021:8k_2_02:109]
This change in accounting policy does not affect the Company’s balance of cash and cash equivalents and, as a result, did not change net cash flows from operating, investing, or financing activities or materially impact any individual line items in the Company’s preliminary consolidated statement of cash flows for the fiscal fourth quarter and fiscal year ended July 31, 2016, respectively.

[0001327567-17-000021:8k_2_02:110]
17

## item 5.02 — body, verbatim

[0001327567-17-000021:8k_body:1]
Item 5.02  Departure of Directors or Certain Officers; Election of Directors; Appointment of Certain Officers; Compensatory Arrangements of Certain Officers.

[0001327567-17-000021:8k_body:2]
(b) Retirement of Chief Financial Officer

[0001327567-17-000021:8k_body:3]
On August 29, 2017, Steffan Tomlinson, the Company’s Executive Vice President, Chief Financial Officer, notified the Company of his intention to retire and resign from his position at the Company. Mr. Tomlinson has agreed to stay on as the Company’s Chief Financial Officer until his replacement has been found.

[0001327567-17-000021:8k_body:4]
(c) Appointment of Chief Product Officer

[0001327567-17-000021:8k_body:5]
On August 29, 2017, the Company’s Board of Directors (the “Board”) named Lee Klarich, 42, Executive Vice President, Chief Product Officer, effective as of August 29, 2017, with responsibility for engineering and product management.

[0001327567-17-000021:8k_body:6]
Prior to this appointment, Mr. Klarich served as the Company’s Executive Vice President of Product Management, a role he held since November 2015. From November 2012 to November 2015, Mr. Klarich served as the Company’s Senior Vice President, Product Management and the Company’s Vice President, Product Management from May 2006 to November 2012. Prior to joining the Company, Mr. Klarich held various positions at NetScreen Technologies, Excite@Home, and Packard Bell-NEC. Mr. Klarich holds a B.S. in Engineering from Cornell University.

[0001327567-17-000021:8k_body:7]
There are no arrangements or understandings between Mr. Klarich and any other persons pursuant to which he was selected as an executive officer. There are no family relationships between Mr. Klarich and any director or other executive officer. Mr. Klarich has not had an interest in any transaction since the beginning of the Company’s last fiscal year, or any currently proposed transaction, that requires disclosure pursuant to Item 404(a) of Regulation S-K.

[0001327567-17-000021:8k_body:8]
(d) Appointment of New Director

[0001327567-17-000021:8k_body:9]
On August 29, 2017, the Board increased the size of the Board from ten to eleven and appointed Sridhar Ramaswamy to the Board effective as of August 29, 2017, to serve as a Class II director whose term expires at the annual meeting of stockholders to be held in 2019. In addition, the Board appointed Mr. Ramaswamy to the Nominating and Corporate Governance Committee of the Board (the “Governance Committee”).

[0001327567-17-000021:8k_body:10]
Mr. Ramaswamy, age 50, currently serves as Google, Inc.’s Senior Vice President Ads & Commerce, a position he has held since March 2013. From 2003 to March 2013, Mr. Ramaswamy served in various leadership roles in Google’s engineering group, including as Senior Vice President Engineering. Prior to joining Google, Mr. Ramaswamy served in engineering and other technical roles at E.piphany Inc., Bell Laboratories, Inc., and Telcordia Technologies, Inc. Mr. Ramaswamy holds a B.S. in Computer Science from the India Institute of Technology, Madras India and a M.S. and PhD in Computer Science from Brown University. Mr. Ramaswamy was selected to serve on the Board due, in part, to the depth of his technical engineering background and his extensive cloud and

[0001327567-17-000021:8k_body:11]
infrastructure expertise.

[0001327567-17-000021:8k_body:12]
In connection with his appointment to the Board and in accordance with the Company’s Director Compensation Policy, the Board approved an initial award of restricted stock units for Mr. Ramaswamy having a value of approximately $1,000,000, which will be granted effective September 20, 2017 (the grant date). These restricted stock units will vest over three years, with one-third of the shares subject to the award vesting on the first anniversary of the grant date, and the remaining shares vesting equally over the next two years on a quarterly basis, subject to continued service on the Board on the applicable vesting date. In the event of a change of control, all shares subject to the award would become fully vested and immediately exercisable. The restricted stock units are subject to the terms and conditions of the Company’s 2012 Equity Incentive Plan and its related grant agreements. In addition, the Company expects to grant an annual award of restricted stock units having a value of approximately $310,000 to Mr. Ramaswamy on the date of each annual meeting of stockholders, beginning with the annual meeting of stockholders to be held in 2018, subject to continued service on the Board and the Governance Committee. Each annual award of restricted stock units is expected to vest over one year on a quarterly basis. The Company will also reimburse Mr. Ramaswamy for all reasonable expenses in connection with his service to the Company. A copy of the offer letter between Mr. Ramaswamy and the Company is filed as Exhibit 10.1 to this Current Report on Form 8-K.

[0001327567-17-000021:8k_body:13]
Mr. Ramaswamy executed the Company’s standard form of indemnification agreement, a copy of which has been filed as Exhibit 10.1 to the Company’s Registration Statement on Form S-1 (File No. 333-180620) filed with the Securities and Exchange Commission on July 9, 2012.

[0001327567-17-000021:8k_body:14]
There is no arrangement or understanding between Mr. Ramaswamy and any other persons pursuant to which Mr. Ramaswamy was elected as a director. There are no family relationships between Mr. Ramaswamy and any director or other executive officer. In addition, Mr. Ramaswamy is not a party to any transaction, or series of transactions, required to be disclosed pursuant to Item 404(a) of Regulation S-K.
