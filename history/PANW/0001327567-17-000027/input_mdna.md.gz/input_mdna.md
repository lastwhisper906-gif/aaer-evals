# PANW MD&A — 0001327567-17-000027


## mdna

[0001327567-17-000027:mdna:1]
| ITEM 7. | MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS |

[0001327567-17-000027:mdna:2]
The following discussion and analysis of our financial condition and results of operations should be read in conjunction with our consolidated financial statements and related notes appearing elsewhere in this Annual Report on Form 10-K. The following discussion and analysis contains forward-looking statements based on current expectations and assumptions that are subject to risks and uncertainties, which could cause our actual results to differ materially from those anticipated or implied by any forward-looking statements. Factors that could cause or contribute to such differences include, but are not limited to, those discussed in this Annual Report on Form 10-K, and in particular, the risks discussed under the caption “Risk Factors” in Part I, Item 1A of this report.

[0001327567-17-000027:mdna:3]
Our Management’s Discussion and Analysis of Financial Condition and Results of Operations (“MD&A”) is organized as follows:

[0001327567-17-000027:mdna:4]
| • | Overview. A discussion of our business and overall analysis of financial and other highlights in order to provide context for the remainder of MD&A. |

[0001327567-17-000027:mdna:5]
| • | Key Financial Metrics. A summary of our GAAP and non-GAAP key financial metrics, which management monitors to evaluate our performance. |

[0001327567-17-000027:mdna:6]
| • | Results of Operations. A discussion of the nature and trends in our financial results and an analysis of our financial results comparing fiscal 2017 to 2016 and fiscal 2016 to 2015. |

[0001327567-17-000027:mdna:7]
| • | Liquidity and Capital Resources. An analysis of changes in our balance sheets and cash flows, and a discussion of our financial condition and our ability to meet cash needs. |

[0001327567-17-000027:mdna:8]
| • | Contractual Obligations and Commitments. An overview of our contractual obligations, contingent liabilities, commitments, and off-balance sheet arrangements outstanding as of July 31, 2017, including expected payment schedules. |

[0001327567-17-000027:mdna:9]
| • | Critical Accounting Estimates. A discussion of our accounting policies that require critical estimates, assumptions, and judgments. |

[0001327567-17-000027:mdna:10]
| • | Recent Accounting Pronouncements. A discussion of expected impacts of impending accounting changes on financial information to be reported in the future. |

[0001327567-17-000027:mdna:11]
Overview

[0001327567-17-000027:mdna:12]
We have pioneered the next generation of security through our innovative platform that allows enterprises, service providers, and government entities to secure their organizations by safely enabling applications running on their networks and by preventing successful breaches that stem from targeted cyberattacks. Our platform uses an innovative traffic classification engine that identifies network traffic by application, user, and content and provides consistent security across the network, endpoint, and cloud. Accordingly, our platform enables our end-customers to maintain the visibility and control needed to protect their valued data and critical control systems while pursuing technology initiatives, like cloud and mobility, that grow their business. We believe our platform offers superior performance compared to legacy approaches and reduces the total cost of ownership for organizations by simplifying their security operations and infrastructure and eliminating the need for multiple, stand-alone security appliances and software products.

[0001327567-17-000027:mdna:13]
Our Next-Generation Security Platform consists of three major elements: our Next-Generation Firewall, our Advanced Endpoint Protection, and our Threat Intelligence Cloud. Our Next-Generation Firewall comes in several physical and cloud-based software form-factors and delivers application, user, and content visibility and control as well as protection against network-based cyberthreats integrated within the firewall through our proprietary hardware and software architecture. Our Advanced Endpoint Protection software prevents cyberattacks that aim to run malicious code or exploit software vulnerabilities on a broad variety of fixed, mobile, and virtual endpoints and servers. Our Threat Intelligence Cloud provides central intelligence capabilities, security for SaaS applications, and automated delivery of preventative measures against cyberattacks.

[0001327567-17-000027:mdna:14]
For fiscal 2017, 2016, and 2015, total revenue was $1.8 billion, $1.4 billion, and $928.1 million, respectively, representing year-over-year growth of 27.8% for fiscal 2017 and 48.5% for fiscal 2016. Our growth reflects the increased adoption of our hybrid SaaS revenue model, which consists of product, subscriptions, and support. We believe this model will enable us to benefit from recurring revenues as we continue to grow our installed end-customer base. As of July 31, 2017, we had more than 42,500 end-customers in over 150 countries. Our end-customers represent a broad range of industries including education, energy, financial services, government entities, healthcare, Internet and media, manufacturing, public sector, and telecommunications, and include some of the largest Fortune 100 and Global 2000 companies in the world. We maintain a field sales force that works

[0001327567-17-000027:mdna:15]
- 38 -

[0001327567-17-000027:mdna:16]
closely with our channel partners in developing sales opportunities. We use a two-tiered, indirect fulfillment model whereby we sell our products and services to our distributors, which, in turn, sell to our resellers, which then sell to our end-customers.

[0001327567-17-000027:mdna:17]
Our product revenue grew to $709.1 million or 40.3% of total revenue for fiscal 2017, representing year-over-year growth of 5.7%. Product revenue is generated from sales of our appliances, primarily our Next-Generation Firewall, which is available in physical and virtualized form. Our Next-Generation Firewall incorporates our proprietary PAN-OS operating system, which provides a consistent set of capabilities across our entire product line. Our products are designed for different performance requirements throughout an organization, ranging from our PA-200, which is designed for enterprise remote offices, to our top-of-the-line PA-7080, which is especially suited for very large enterprise deployments and service provider customers. The same firewall functionality that is delivered in our physical appliances is also available in our VM-Series virtual firewalls, which secure virtualized and cloud-based computing environments.

[0001327567-17-000027:mdna:18]
Our subscription and support revenue grew to $1.1 billion or 59.7% of total revenue for fiscal 2017, representing year-over-year growth of 48.7%. Our subscriptions provide our end-customers with real-time access to the latest antivirus, intrusion prevention, web filtering, and modern malware prevention capabilities across fixed and mobile devices. When end-customers purchase an appliance, they typically purchase one or more of our subscriptions for additional functionality, as well as support in order to receive ongoing security updates, upgrades, bug fixes, and repairs.

[0001327567-17-000027:mdna:19]
We continue to invest in and extend our platform, as we believe that innovation and timely development of new features and products is essential to meeting the needs of our end-customers and improving our competitive position. In February 2017, we expanded our family of firewalls with the launch of several new appliances: our PA-220, which is designed for small branch offices and remote locations; our PA-800 series, which are ideal for medium-sized networks and branch and remote office environments; our PA-5200 series, which deliver security for high throughput environments in a compact form factor; and three new VM-Series virtual firewall models, which support cloud and virtualization initiatives ranging from virtualized branch offices to data center and service provider deployments. We also delivered PAN-OS 8.0, an important software release that expands security for public and private clouds, provides new SaaS application security functionality, and also provides the capabilities to prevent the theft and abuse of stolen credentials. Additionally, in February 2017, we acquired LightCyber Ltd. (“LightCyber”), a privately-held cybersecurity company. LightCyber’s technology expands the functionality of our platform through the addition of behavioral analytics, and will be the foundation for a new future subscription offering. We also expect to release two new cloud-based subscription offerings in September 2017: our GlobalProtect cloud service subscription, which provides our Next Generation Security Platform as a cloud-based service for remote offices and mobile users; and our Logging Service subscription, which functions as the central cloud-based repository for all application data and logs, and allows end-customers to collect data without needing to plan for local processing power and storage.

[0001327567-17-000027:mdna:20]
We plan to continue our investment in innovation as we evolve and further extend the capabilities of our platform. For example, in June 2017, we announced the next phase in the evolution of our Next-Generation Security Platform: our Palo Alto Networks Application Framework. Our cloud-based Application Framework will introduce a new SaaS consumption model under which our end-customers will be able to rapidly implement cloud-based security applications developed by us, third-party developers, or other security vendors, without having to deploy or manage additional products. We expect our Application Framework to become generally available in the early 2018 calendar year, with continuous and ongoing introduction of new security applications.

[0001327567-17-000027:mdna:21]
We believe that the growth of our business and our short-term and long-term success are dependent upon many factors, including our ability to extend our technology leadership, grow our base of end-customers, expand deployment of our platform and support offerings within existing end-customers, and focus on end-customer satisfaction. To manage any future growth effectively, we must continue to improve and expand our information technology and financial infrastructure, our operating and administrative systems and controls, and our ability to manage headcount, capital, and processes in an efficient manner. While these areas present significant opportunities for us, they also pose challenges and risks that we must successfully address in order to sustain the growth of our business and improve our operating results. For additional information regarding the challenges and risks we face, see the “Risk Factors” section in Part I, Item 1A of this Annual Report on Form 10-K.

[0001327567-17-000027:mdna:22]
Key Financial Metrics

[0001327567-17-000027:mdna:23]
We monitor the key financial metrics set forth in the tables below to help us evaluate growth trends, establish budgets, measure the effectiveness of our sales and marketing efforts, and assess operational efficiencies. We discuss revenue, gross margin, and the components of operating loss and margin below under “—Results of Operations.”

[0001327567-17-000027:mdna:24]
- 39 -

[0001327567-17-000027:mdna:25]
|  | July 31, |
|  | 2017 |  | 2016 |
|  | (in millions) |
| Total deferred revenue | $ | 1,773.5 |  |  | $ | 1,240.8 |  |
| Cash, cash equivalents, and investments | $ | 2,164.3 |  |  | $ | 1,938.4 |  |

[0001327567-17-000027:mdna:26]
|  | Year Ended July 31, |
|  | 2017 |  | 2016 |  | 2015 |
|  | (dollars in millions) |
| Total revenue | $ | 1,761.6 |  |  | $ | 1,378.5 |  |  | $ | 928.1 |  |
| Total revenue year-over-year percentage increase | 27.8 | % |  | 48.5 | % |  | 55.1 | % |
| Gross margin | 72.9 | % |  | 73.2 | % |  | 72.9 | % |
| Operating loss(1) | $ | (179.8 | ) |  | $ | (157.3 | ) |  | $ | (99.8 | ) |
| Operating margin(1) | (10.2 | )% |  | (11.4 | )% |  | (10.8 | )% |
| Billings | $ | 2,293.4 |  |  | $ | 1,905.6 |  |  | $ | 1,219.1 |  |
| Billings year-over-year percentage increase | 20.4 | % |  | 56.3 | % |  | 58.0 | % |
| Cash flow provided by operating activities(2) | $ | 868.5 |  |  | $ | 658.6 |  |  | $ | 352.8 |  |
| Free cash flow (non-GAAP)(2) | $ | 705.1 |  |  | $ | 586.1 |  |  | $ | 319.0 |  |

[0001327567-17-000027:mdna:27]
______________

[0001327567-17-000027:mdna:28]
| (1) | Prior period amounts have been adjusted due to our voluntary change in accounting policy for sales commissions. Refer to Note 1. Description of Business and Summary of Significant Accounting Policies in Part II, Item 8 of this Annual Report on Form 10-K for more information. |

[0001327567-17-000027:mdna:29]
| (2) | Prior period amounts have been adjusted due to our early adoption of new share-based payment accounting guidance. Refer to Note 1. Description of Business and Summary of Significant Accounting Policies in Part II, Item 8 of this Annual Report on Form 10-K for more information. |

[0001327567-17-000027:mdna:30]
| • | Deferred Revenue. Our deferred revenue consists of amounts that have been invoiced but have not been recognized as revenue as of the period end. The majority of our deferred revenue balance consists of subscription and support revenue that is recognized ratably over the contractual service period. We monitor our deferred revenue balance because it represents a significant portion of revenue to be recognized in future periods. |

[0001327567-17-000027:mdna:31]
| • | Billings. We define billings as total revenue plus the change in total deferred revenue, net of acquired deferred revenue, during the period. We consider billings to be a key measure used by management to manage our business given our hybrid SaaS revenue model, and believe billings provides investors with an important indicator of the health and visibility of our business because it includes subscription and support revenue, which is recognized ratably over the contractual service period, and product revenue, which is recognized at the time of shipment, provided that all other revenue recognition criteria have been met. We consider billings to be a useful metric for management and investors, particularly if we continue to experience increased sales of subscriptions and strong renewal rates for subscription and support offerings, and as we monitor our near term cash flows. While we believe that billings provides useful information to investors and others in understanding and evaluating our operating results in the same manner as our management, it is important to note that other companies, including companies in our industry, may not use billings, may calculate billings differently, may have different billing frequencies, or may use other financial measures to evaluate their performance, all of which could reduce the usefulness of billings as a comparative measure. We calculate billings in the following manner: |

[0001327567-17-000027:mdna:32]
- 40 -

[0001327567-17-000027:mdna:33]
|  | Year Ended July 31, |
|  | 2017 |  | 2016 |  | 2015 |
|  | (in millions) |
| Billings: |  |  |  |  |  |
| Total revenue | $ | 1,761.6 |  |  | $ | 1,378.5 |  |  | $ | 928.1 |  |
| Add: change in total deferred revenue, net of acquired deferred revenue | 531.8 |  |  | 527.1 |  |  | 291.0 |  |
| Billings | $ | 2,293.4 |  |  | $ | 1,905.6 |  |  | $ | 1,219.1 |  |

[0001327567-17-000027:mdna:34]
| • | Cash Flow Provided by Operating Activities. We monitor cash flow provided by operating activities as a measure of our overall business performance. Our cash flow provided by operating activities is driven in large part by sales of our products and from up-front payments for subscription and support offerings. Monitoring cash flow provided by operating activities enables us to analyze our financial performance without the non-cash effects of certain items such as depreciation, amortization, and share-based compensation costs, thereby allowing us to better understand and manage the cash needs of our business. |

[0001327567-17-000027:mdna:35]
| • | Free Cash Flow (non-GAAP). We define free cash flow, a non-GAAP financial measure, as cash provided by operating activities less purchases of property, equipment, and other assets. We consider free cash flow to be a profitability and liquidity measure that provides useful information to management and investors about the amount of cash generated by the business after necessary capital expenditures. A limitation of the utility of free cash flow as a measure of our financial performance and liquidity is that it does not represent the total increase or decrease in our cash balance for the period. In addition, it is important to note that other companies, including companies in our industry, may not use free cash flow, may calculate free cash flow in a different manner than we do, or may use other financial measures to evaluate their performance, all of which could reduce the usefulness of free cash flow as a comparative measure. A reconciliation of free cash flow to cash flow provided by operating activities, the most directly comparable financial measure calculated and presented in accordance with GAAP, is provided below: |

[0001327567-17-000027:mdna:36]
|  | Year Ended July 31, |
|  | 2017 |  | 2016 |  | 2015 |
|  | (in millions) |
| Free cash flow (non-GAAP): |  |  |  |  |  |
| Net cash provided by operating activities(1) | $ | 868.5 |  |  | $ | 658.6 |  |  | $ | 352.8 |  |
| Less: purchases of property, equipment, and other assets | 163.4 |  |  | 72.5 |  |  | 33.8 |  |
| Free cash flow (non-GAAP)(1) | $ | 705.1 |  |  | $ | 586.1 |  |  | $ | 319.0 |  |
| Net cash used in investing activities | $ | (472.6 | ) |  | $ | (338.9 | ) |  | $ | (679.0 | ) |
| Net cash provided by (used in) financing activities(1) | $ | (386.0 | ) |  | $ | 38.9 |  |  | $ | 48.2 |  |

[0001327567-17-000027:mdna:37]
______________

[0001327567-17-000027:mdna:38]
| (1) | Prior period amounts have been adjusted due to our early adoption of new share-based payment accounting guidance. Refer to Note 1. Description of Business and Summary of Significant Accounting Policies in Part II, Item 8 of this Annual Report on Form 10-K for more information. |

[0001327567-17-000027:mdna:39]
- 41 -

[0001327567-17-000027:mdna:40]
Results of Operations

[0001327567-17-000027:mdna:41]
The following table summarizes our results of operations for the periods presented and as a percentage of our total revenue for those periods based on our consolidated statements of operations data. The period to period comparison of results is not necessarily indicative of results for future periods.

[0001327567-17-000027:mdna:42]
|  | Year Ended July 31, |
|  | 2017 |  | 2016 |  | 2015 |
|  | Amount |  | % of Revenue |  | Amount(1) |  | % of Revenue(1) |  | Amount(1) |  | % of Revenue(1) |
|  | (dollars in millions) |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 709.1 |  |  | 40.3 | % |  | $ | 670.8 |  |  | 48.7 | % |  | $ | 492.7 |  |  | 53.1 | % |
| Subscription and support | 1,052.5 |  |  | 59.7 | % |  | 707.7 |  |  | 51.3 | % |  | 435.4 |  |  | 46.9 | % |
| Total revenue | 1,761.6 |  |  | 100.0 | % |  | 1,378.5 |  |  | 100.0 | % |  | 928.1 |  |  | 100.0 | % |
| Cost of revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Product | 201.4 |  |  | 11.4 | % |  | 175.4 |  |  | 12.7 | % |  | 131.1 |  |  | 14.1 | % |
| Subscription and support | 275.2 |  |  | 15.7 | % |  | 194.6 |  |  | 14.1 | % |  | 120.4 |  |  | 13.0 | % |
| Total cost of revenue(2) | 476.6 |  |  | 27.1 | % |  | 370.0 |  |  | 26.8 | % |  | 251.5 |  |  | 27.1 | % |
| Total gross profit | 1,285.0 |  |  | 72.9 | % |  | 1,008.5 |  |  | 73.2 | % |  | 676.6 |  |  | 72.9 | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | 347.4 |  |  | 19.7 | % |  | 284.2 |  |  | 20.6 | % |  | 185.8 |  |  | 20.0 | % |
| Sales and marketing | 919.1 |  |  | 52.2 | % |  | 743.2 |  |  | 53.9 | % |  | 489.0 |  |  | 52.7 | % |
| General and administrative | 198.3 |  |  | 11.2 | % |  | 138.4 |  |  | 10.1 | % |  | 101.6 |  |  | 11.0 | % |
| Total operating expenses(2) | 1,464.8 |  |  | 83.1 | % |  | 1,165.8 |  |  | 84.6 | % |  | 776.4 |  |  | 83.7 | % |
| Operating loss | (179.8 | ) |  | (10.2 | )% |  | (157.3 | ) |  | (11.4 | )% |  | (99.8 | ) |  | (10.8 | )% |
| Interest expense | (24.5 | ) |  | (1.4 | )% |  | (23.4 | ) |  | (1.7 | )% |  | (22.3 | ) |  | (2.4 | )% |
| Other income, net | 10.2 |  |  | 0.6 | % |  | 8.4 |  |  | 0.6 | % |  | 0.2 |  |  | — | % |
| Loss before income taxes | (194.1 | ) |  | (11.0 | )% |  | (172.3 | ) |  | (12.5 | )% |  | (121.9 | ) |  | (13.2 | )% |
| Provision for income taxes | 22.5 |  |  | 1.3 | % |  | 20.4 |  |  | 1.5 | % |  | 9.4 |  |  | 1.0 | % |
| Net loss | $ | (216.6 | ) |  | (12.3 | )% |  | $ | (192.7 | ) |  | (14.0 | )% |  | $ | (131.3 | ) |  | (14.2 | )% |

[0001327567-17-000027:mdna:43]
______________

[0001327567-17-000027:mdna:44]
| (1) | Certain prior period amounts have been adjusted due to our voluntary change in accounting policy for sales commissions. Refer to Note 1. Description of Business and Summary of Significant Accounting Policies in Part II, Item 8 of this Annual Report on Form 10-K for more information. |

[0001327567-17-000027:mdna:45]
- 42 -

[0001327567-17-000027:mdna:46]
| (2) | Includes share-based compensation as follows: |

[0001327567-17-000027:mdna:47]
|  | Year Ended July 31, |
|  | 2017 |  | 2016 |  | 2015 |
|  | (in millions) |
| Cost of product revenue | $ | 7.3 |  |  | $ | 6.2 |  |  | $ | 3.9 |  |
| Cost of subscription and support revenue | 56.2 |  |  | 40.9 |  |  | 20.4 |  |
| Research and development | 152.6 |  |  | 132.9 |  |  | 74.8 |  |
| Sales and marketing | 186.5 |  |  | 152.4 |  |  | 84.1 |  |
| General and administrative | 73.1 |  |  | 60.5 |  |  | 38.2 |  |
| Total share-based compensation | $ | 475.7 |  |  | $ | 392.9 |  |  | $ | 221.4 |  |

[0001327567-17-000027:mdna:48]
Revenue

[0001327567-17-000027:mdna:49]
Our revenue consists of product revenue and subscription and support revenue. Revenue is recognized when persuasive evidence of an arrangement exists, delivery has occurred, the fee is fixed or determinable, and collectability is reasonably assured. We expect our revenue to vary from quarter to quarter based on seasonal and cyclical factors.

[0001327567-17-000027:mdna:50]
Product Revenue

[0001327567-17-000027:mdna:51]
Product revenue is derived primarily from sales of our appliances. Product revenue also includes revenue derived from software licenses of Panorama and the VM-Series. We recognize product revenue at the time of shipment, provided that all other revenue recognition criteria have been met.

[0001327567-17-000027:mdna:52]
|  | Year Ended July 31, |  |  |  | Year Ended July 31, |  |  |
|  | 2017 |  | 2016 |  | Change |  | 2016 |  | 2015 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Product | $ | 709.1 |  |  | $ | 670.8 |  |  | $ | 38.3 |  |  | 5.7 | % |  | $ | 670.8 |  |  | $ | 492.7 |  |  | $ | 178.1 |  |  | 36.2 | % |

[0001327567-17-000027:mdna:53]
Product revenue increased year-over-year for fiscal 2017 due to demand for our newly introduced appliances. Product revenue increased year-over-year for fiscal 2016 due to increased demand for our higher end appliances. The change in product revenue due to pricing was not significant for either period.

[0001327567-17-000027:mdna:54]
Subscription and Support Revenue

[0001327567-17-000027:mdna:55]
Subscription and support revenue is derived primarily from sales of our subscription and support offerings. Our contractual subscription and support terms are typically one to five years. We recognize revenue from subscriptions and support over the contractual service period. As a percentage of total revenue, we expect our subscription and support revenue to vary from quarter to quarter and increase over the long term as we introduce new subscriptions, renew existing subscription and support contracts, and expand our installed end-customer base. Prior to fiscal 2017, subscription and support revenue was referred to as services revenue. The composition of subscription and support revenue has not been modified.

[0001327567-17-000027:mdna:56]
|  | Year Ended July 31, |  |  |  | Year Ended July 31, |  |  |
|  | 2017 |  | 2016 |  | Change |  | 2016 |  | 2015 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Subscription | $ | 550.8 |  |  | $ | 357.0 |  |  | $ | 193.8 |  |  | 54.3 | % |  | $ | 357.0 |  |  | $ | 212.7 |  |  | $ | 144.3 |  |  | 67.8 | % |
| Support | 501.7 |  |  | 350.7 |  |  | 151.0 |  |  | 43.1 | % |  | 350.7 |  |  | 222.7 |  |  | 128.0 |  |  | 57.5 | % |
| Total subscription and support | $ | 1,052.5 |  |  | $ | 707.7 |  |  | $ | 344.8 |  |  | 48.7 | % |  | $ | 707.7 |  |  | $ | 435.4 |  |  | $ | 272.3 |  |  | 62.5 | % |

[0001327567-17-000027:mdna:57]
Subscription and support revenue increased year-over-year for both fiscal 2017 and fiscal 2016. The increases in both periods were due to increased demand for our subscription and support offerings from both new and existing end-customers. The mix between subscription revenue and support revenue will fluctuate over time, depending on the introduction of new subscription

[0001327567-17-000027:mdna:58]
- 43 -

[0001327567-17-000027:mdna:59]
offerings, renewals of support services, and our ability to increase sales to new and existing customers. The change in subscription and support revenue due to changes in pricing was not significant for either period.

[0001327567-17-000027:mdna:60]
Revenue by Geographic Theater

[0001327567-17-000027:mdna:61]
|  | Year Ended July 31, |  |  |  | Year Ended July 31, |  |  |
|  | 2017 |  | 2016 |  | Change |  | 2016 |  | 2015 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Americas | $ | 1,237.4 |  |  | $ | 973.2 |  |  | $ | 264.2 |  |  | 27.1 | % |  | $ | 973.2 |  |  | $ | 639.4 |  |  | $ | 333.8 |  |  | 52.2 | % |
| EMEA | 320.1 |  |  | 247.1 |  |  | 73.0 |  |  | 29.5 | % |  | 247.1 |  |  | 178.7 |  |  | 68.4 |  |  | 38.2 | % |
| APAC | 204.1 |  |  | 158.2 |  |  | 45.9 |  |  | 29.0 | % |  | 158.2 |  |  | 110.0 |  |  | 48.2 |  |  | 43.8 | % |
| Total revenue | $ | 1,761.6 |  |  | $ | 1,378.5 |  |  | $ | 383.1 |  |  | 27.8 | % |  | $ | 1,378.5 |  |  | $ | 928.1 |  |  | $ | 450.4 |  |  | 48.5 | % |

[0001327567-17-000027:mdna:62]
With respect to geographic theaters, the Americas contributed the largest portion of the year-over-year increases in revenue for both fiscal 2017 and fiscal 2016 due to its larger and more established sales force compared to our other theaters. Revenue from both EMEA and APAC increased year-over-year for both fiscal 2017 and fiscal 2016 due to our investment in increasing the size of our sales force and number of channel partners in these theaters.

[0001327567-17-000027:mdna:63]
Cost of Revenue

[0001327567-17-000027:mdna:64]
Our cost of revenue consists of cost of product revenue and cost of subscription and support revenue.

[0001327567-17-000027:mdna:65]
Cost of Product Revenue

[0001327567-17-000027:mdna:66]
Cost of product revenue primarily includes costs paid to our manufacturing partners. Our cost of product revenue also includes personnel costs, which consist of salaries, benefits, bonuses, share-based compensation, and travel and entertainment associated with our operations organization, amortization of intellectual property licenses, product testing costs, shipping costs, and allocated costs. Allocated costs consist of certain facilities, depreciation, benefits, recruiting, and information technology costs that we allocate based on headcount. We expect our cost of product revenue to increase as our product revenue increases.

[0001327567-17-000027:mdna:67]
|  | Year Ended July 31, |  |  |  | Year Ended July 31, |  |  |
|  | 2017 |  | 2016 |  | Change |  | 2016 |  | 2015 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Cost of product revenue | $ | 201.4 |  |  | $ | 175.4 |  |  | $ | 26.0 |  |  | 14.8 | % |  | $ | 175.4 |  |  | $ | 131.1 |  |  | $ | 44.3 |  |  | 33.8 | % |
| Number of employees at period end | 96 |  |  | 91 |  |  | 5 |  |  | 5.5 | % |  | 91 |  |  | 67 |  |  | 24 |  |  | 35.8 | % |

[0001327567-17-000027:mdna:68]
Cost of product revenue increased for fiscal 2017 compared to fiscal 2016 primarily due to higher product costs related to our newly introduced appliances.

[0001327567-17-000027:mdna:69]
Cost of product revenue increased for fiscal 2016 compared to fiscal 2015 primarily due to an increase in product unit volume for our higher end appliances.

[0001327567-17-000027:mdna:70]
- 44 -

[0001327567-17-000027:mdna:71]
Cost of Subscription and Support Revenue

[0001327567-17-000027:mdna:72]
Cost of subscription and support revenue includes personnel costs for our global customer support and technical operations organizations, customer support costs, third-party professional services costs, amortization of acquired intangible assets, and allocated costs. We expect our cost of subscription and support revenue to increase as our installed end-customer base grows. Prior to fiscal 2017, cost of subscription and support revenue was referred to as cost of services revenue. The composition of cost of subscription and support revenue has not been modified.

[0001327567-17-000027:mdna:73]
|  | Year Ended July 31, |  |  |  | Year Ended July 31, |  |  |
|  | 2017 |  | 2016 |  | Change |  | 2016 |  | 2015 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Cost of subscription and support revenue | $ | 275.2 |  |  | $ | 194.6 |  |  | $ | 80.6 |  |  | 41.4 | % |  | $ | 194.6 |  |  | $ | 120.4 |  |  | $ | 74.2 |  |  | 61.7 | % |
| Number of employees at period end | 725 |  |  | 539 |  |  | 186 |  |  | 34.5 | % |  | 539 |  |  | 357 |  |  | 182 |  |  | 51.0 | % |

[0001327567-17-000027:mdna:74]
Cost of subscription and support revenue increased for fiscal 2017 compared to fiscal 2016 primarily due to an increase in personnel costs, which grew $45.3 million to $155.4 million, largely due to headcount growth. The remaining increase was primarily driven by costs to expand our customer service capabilities and infrastructure, customer support costs, and allocated costs. The increase in allocated costs was primarily due to our expansion of facilities to support the growth of our business.

[0001327567-17-000027:mdna:75]
Cost of subscription and support revenue increased for fiscal 2016 compared to fiscal 2015 primarily due to an increase in personnel costs, which grew $42.1 million to $104.1 million, largely due to headcount growth. The remaining increase was due to expansion of our customer service capabilities and infrastructure to support our growing installed end-customer base.

[0001327567-17-000027:mdna:76]
Gross Margin

[0001327567-17-000027:mdna:77]
Gross margin, or gross profit as a percentage of revenue, has been and will continue to be affected by a variety of factors, including the average sales price of our products, manufacturing costs, the introduction of new products, the mix of products sold, and the mix of revenue between product and subscription and support offerings. For sales of our products, our higher end firewall products generally have higher gross margins than our lower end firewall products within each product series. For sales of our subscription and support offerings, our subscription offerings typically have higher gross margins than our support offerings. We expect our gross margins to fluctuate over time depending on the factors described above.

[0001327567-17-000027:mdna:78]
|  | Year Ended July 31, |
|  | 2017 |  | 2016 |  | 2015 |
|  | Amount |  | GrossMargin |  | Amount |  | GrossMargin |  | Amount |  | GrossMargin |
|  | (dollars in millions) |
| Product | $ | 507.7 |  |  | 71.6 | % |  | $ | 495.4 |  |  | 73.9 | % |  | $ | 361.6 |  |  | 73.4 | % |
| Subscription and support | 777.3 |  |  | 73.9 | % |  | 513.1 |  |  | 72.5 | % |  | 315.0 |  |  | 72.3 | % |
| Total gross profit | $ | 1,285.0 |  |  | 72.9 | % |  | $ | 1,008.5 |  |  | 73.2 | % |  | $ | 676.6 |  |  | 72.9 | % |

[0001327567-17-000027:mdna:79]
Product gross margin decreased for fiscal 2017 compared to fiscal 2016 due to higher product costs related to our newly introduced appliances, which will have lower product margins. Product gross margin increased for fiscal 2016 compared to fiscal 2015 due to our continued focus on material cost reductions.

[0001327567-17-000027:mdna:80]
Subscription and support gross margin increased for fiscal 2017 compared to fiscal 2016 due to contributions from our higher margin subscription offerings. Subscription and support gross margin was flat for fiscal 2016 compared to fiscal 2015.

[0001327567-17-000027:mdna:81]
Operating Expenses

[0001327567-17-000027:mdna:82]
Our operating expenses consist of research and development, sales and marketing, and general and administrative expense. Personnel costs are the most significant component of operating expenses and consist of salaries, benefits, bonuses, share-based compensation, travel and entertainment, and with regard to sales and marketing expense, sales commissions. Our operating expenses also include allocated costs, which consist of certain facilities, depreciation, benefits, recruiting, and information technology costs that we allocate based on headcount. We expect operating expenses to increase in absolute dollars and decrease over the long term as a percentage of revenue as we continue to scale our business. As of July 31, 2017, we expect to recognize approximately $906.8 million of share-based compensation expense over a weighted-average period of approximately 2.6 years,

[0001327567-17-000027:mdna:83]
- 45 -

[0001327567-17-000027:mdna:84]
excluding additional share-based compensation expense related to any future grants of share-based awards. Share-based compensation expense is generally recognized on a straight-line basis over the requisite service periods of the awards.

[0001327567-17-000027:mdna:85]
Research and Development

[0001327567-17-000027:mdna:86]
Research and development expense consists primarily of personnel costs. Research and development expense also includes prototype related expenses and allocated costs. We expect research and development expense to increase in absolute dollars as we continue to invest in our future products and services, although our research and development expense may fluctuate as a percentage of total revenue.

[0001327567-17-000027:mdna:87]
|  | Year Ended July 31, |  |  |  | Year Ended July 31, |  |  |
|  | 2017 |  | 2016 |  | Change |  | 2016 |  | 2015 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Research and development | $ | 347.4 |  |  | $ | 284.2 |  |  | $ | 63.2 |  |  | 22.2 | % |  | $ | 284.2 |  |  | $ | 185.8 |  |  | $ | 98.4 |  |  | 52.9 | % |
| Number of employees at period end | 766 |  |  | 637 |  |  | 129 |  |  | 20.3 | % |  | 637 |  |  | 475 |  |  | 162 |  |  | 34.1 | % |

[0001327567-17-000027:mdna:88]
Research and development expense increased year-over-year for both fiscal 2017 and fiscal 2016. The increases in both periods were driven by increases in personnel costs, which grew $46.4 million to $286.0 million for fiscal 2017 compared to fiscal 2016 and grew $86.8 million to $236.4 million for fiscal 2016 compared to fiscal 2015. The increases in personnel costs in both periods were primarily due to headcount growth. The remaining increase for fiscal 2017 was primarily driven by an increase in allocated costs, due to our expansion of facilities to support the growth of our business, and development costs related to investments in our new and future offerings.

[0001327567-17-000027:mdna:89]
Sales and Marketing

[0001327567-17-000027:mdna:90]
Sales and marketing expense consists primarily of personnel costs, including commission expense. Sales and marketing expense also includes costs for market development programs, promotional and other marketing costs, professional services, and allocated costs. We continue to thoughtfully invest in headcount and have substantially grown our sales presence internationally. We expect sales and marketing expense to continue to increase in absolute dollars as we increase the size of our sales and marketing organizations to increase touch points with end-customers and to expand our international presence, although our sales and marketing expense may fluctuate as a percentage of total revenue.

[0001327567-17-000027:mdna:91]
|  | Year Ended July 31, |  |  |  | Year Ended July 31, |  |  |
|  | 2017 |  | 2016 |  | Change |  | 2016 |  | 2015 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Sales and marketing(1) | $ | 919.1 |  |  | $ | 743.2 |  |  | $ | 175.9 |  |  | 23.7 | % |  | $ | 743.2 |  |  | $ | 489.0 |  |  | $ | 254.2 |  |  | 52.0 | % |
| Number of employees at period end | 2,418 |  |  | 2,092 |  |  | 326 |  |  | 15.6 | % |  | 2,092 |  |  | 1,443 |  |  | 649 |  |  | 45.0 | % |

[0001327567-17-000027:mdna:92]
______________

[0001327567-17-000027:mdna:93]
| (1) | Prior period amounts have been adjusted due to our voluntary change in accounting policy for sales commissions. Refer to Note 1. Description of Business and Summary of Significant Accounting Policies in Part II, Item 8 of this Annual Report on Form 10-K for more information. |

[0001327567-17-000027:mdna:94]
Sales and marketing expense increased year-over-year for both fiscal 2017 and fiscal 2016. The increases in both periods were driven by increases in personnel costs, which grew $145.0 million to $716.1 million for fiscal 2017 compared to fiscal 2016 and grew $186.1 million to $520.2 million for fiscal 2016 compared to fiscal 2015. The increases in personnel costs in both periods were primarily due to headcount growth. The remaining increase for fiscal 2017 was primarily driven by an increase in allocated costs, due to our expansion of facilities to support the growth of our business, and an increase in demand generation activities and sales related events to support our revenue growth.

[0001327567-17-000027:mdna:95]
General and Administrative

[0001327567-17-000027:mdna:96]
General and administrative expense consists primarily of personnel costs for our executive, finance, human resources, legal, and information technology organizations, and professional services costs, which consist primarily of legal, auditing, accounting, and other consulting costs. General and administrative expense also includes certain non-recurring general expenses and

[0001327567-17-000027:mdna:97]
- 46 -

[0001327567-17-000027:mdna:98]
impairment losses. Certain facilities, depreciation, benefits, recruiting, and information technology costs are allocated to other organizations based on headcount. We expect general and administrative expense to increase in absolute dollars due to additional costs associated with accounting, compliance, insurance, and investor relations, although our general and administrative expense may fluctuate as a percentage of total revenue.

[0001327567-17-000027:mdna:99]
|  | Year Ended July 31, |  |  |  | Year Ended July 31, |  |  |
|  | 2017 |  | 2016 |  | Change |  | 2016 |  | 2015 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| General and administrative | $ | 198.3 |  |  | $ | 138.4 |  |  | $ | 59.9 |  |  | 43.3 | % |  | $ | 138.4 |  |  | $ | 101.6 |  |  | $ | 36.8 |  |  | 36.2 | % |
| Number of employees at period end | 557 |  |  | 436 |  |  | 121 |  |  | 27.8 | % |  | 436 |  |  | 295 |  |  | 141 |  |  | 47.8 | % |

[0001327567-17-000027:mdna:100]
General and administrative expense increased for fiscal 2017 compared to fiscal 2016 primarily due to an increase in personnel costs, which grew $29.3 million to $128.1 million, largely due to headcount growth, and a fiscal 2017 impairment loss of $20.9 million on property and equipment related to the relocation of our corporate headquarters. We expect to recognize a loss of approximately $15.4 million on the lease of our previous headquarter facilities in the first quarter of fiscal 2018, when we officially cease use of such facilities. Refer to Note 9. Commitments and Contingencies and Note 18. Subsequent Events in Part II, Item 8 of this Annual Report on Form 10-K for more information. The remaining increase for fiscal 2017 was primarily driven by an increase in allocated costs due to our expansion of facilities to support the growth of our business.

[0001327567-17-000027:mdna:101]
General and administrative expense increased for fiscal 2016 compared to fiscal 2015 primarily due to an increase in personnel costs, which grew $32.9 million to $96.5 million, largely due to headcount growth.

[0001327567-17-000027:mdna:102]
Other Income, Net

[0001327567-17-000027:mdna:103]
Other income, net includes interest income earned on our cash, cash equivalents, and investments, foreign currency remeasurement gains and losses, and foreign currency transaction gains and losses.

[0001327567-17-000027:mdna:104]
|  | Year Ended July 31, |  |  |  | Year Ended July 31, |  |  |
|  | 2017 |  | 2016 |  | Change |  | 2016 |  | 2015 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Other income, net | $ | 10.2 |  |  | $ | 8.4 |  |  | $ | 1.8 |  |  | NM |  | $ | 8.4 |  |  | $ | 0.2 |  |  | $ | 8.2 |  |  | NM |

[0001327567-17-000027:mdna:105]
Other income, net increased for fiscal 2017 compared to fiscal 2016 due to an increase in interest income, partially offset by increased foreign currency remeasurement losses.

[0001327567-17-000027:mdna:106]
Other income, net increased for fiscal 2016 compared to fiscal 2015 due to an increase in interest income and higher foreign currency remeasurement gains.

[0001327567-17-000027:mdna:107]
Provision for Income Taxes

[0001327567-17-000027:mdna:108]
Provision for income taxes consists primarily of income taxes in foreign jurisdictions in which we conduct business, withholding taxes, federal and state income taxes in the United States, and amortization of our deferred tax charges. We maintain a full valuation allowance for domestic and certain foreign deferred tax assets, including net operating loss carryforwards and tax credits.

[0001327567-17-000027:mdna:109]
In recent years, we reorganized our corporate structure and intercompany relationships to more closely align with the international nature of our business activities. Our corporate structure has caused, and may continue to cause, disproportionate relationships between our overall effective tax rate and other jurisdictional measures.

[0001327567-17-000027:mdna:110]
- 47 -

[0001327567-17-000027:mdna:111]
|  | Year Ended July 31, |  |  |  |  |  | Year Ended July 31, |  |  |  |  |
|  | 2017 |  | 2016 |  | Change |  | 2016 |  | 2015 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Provision for income taxes(1) | $ | 22.5 |  |  | $ | 20.4 |  |  | $ | 2.1 |  |  | 10.3 | % |  | $ | 20.4 |  |  | $ | 9.4 |  |  | $ | 11.0 |  |  | 117.0 | % |
| Effective tax rate(1) | (11.6 | )% |  | (11.8 | )% |  |  |  |  |  | (11.8 | )% |  | (7.7 | )% |  |  |  |  |

[0001327567-17-000027:mdna:112]
______________

[0001327567-17-000027:mdna:113]
| (1) | Prior period amounts have been adjusted due to our voluntary change in accounting policy for sales commissions. Refer to Note 1. Description of Business and Summary of Significant Accounting Policies in Part II, Item 8 of this Annual Report on Form 10-K for more information. |

[0001327567-17-000027:mdna:114]
We recorded an income tax provision for fiscal 2017 due to foreign income taxes, withholding taxes, and amortization of our deferred tax charges. The provision for income taxes increased for fiscal 2017 compared to fiscal 2016 primarily due to increases in foreign withholding taxes and U.S. income taxes related to intercompany transactions, offset by tax benefits from our adoption of new share-based payment accounting guidance in fiscal 2017.

[0001327567-17-000027:mdna:115]
We recorded an income tax provision for fiscal 2016 due to federal, state, and foreign income taxes, withholding taxes, and amortization of our deferred tax charges. The provision for income taxes increased for fiscal 2016 compared to fiscal 2015 primarily due to an increase in foreign taxes and amortization of our deferred tax charges.

[0001327567-17-000027:mdna:116]
Liquidity and Capital Resources

[0001327567-17-000027:mdna:117]
|  | July 31, |
|  | 2017 |  | 2016 |
|  | (in millions) |
| Working capital(1) | $ | 775.0 |  |  | $ | 927.2 |  |
| Cash, cash equivalents, and investments: |  |  |  |
| Cash and cash equivalents | $ | 744.3 |  |  | $ | 734.4 |  |
| Investments | 1,420.0 |  |  | 1,204.0 |  |
| Total cash, cash equivalents, and investments | $ | 2,164.3 |  |  | $ | 1,938.4 |  |

[0001327567-17-000027:mdna:118]
______________

[0001327567-17-000027:mdna:119]
| (1) | Prior period amount has been adjusted due to our voluntary change in accounting policy for sales commissions. Refer to Note 1. Description of Business and Summary of Significant Accounting Policies in Part II, Item 8 of this Annual Report on Form 10-K for more information. |

[0001327567-17-000027:mdna:120]
At July 31, 2017, our total cash, cash equivalents, and investments of $2.2 billion were held for general corporate purposes, of which approximately $223.0 million was held outside of the United States. As of July 31, 2017, we had no unremitted earnings when evaluating our outside basis differences relating to our investment in foreign subsidiaries; accordingly, there is no restriction on the use of these funds.

[0001327567-17-000027:mdna:121]
As of July 31, 2017, all of the Notes remained outstanding. The Notes mature on July 1, 2019, however, prior to January 1, 2019, holders may surrender their Notes for early conversion under certain circumstances. Upon conversion, we will pay cash equal to the aggregate principal amount of the Notes to be converted, and, at our election, will pay or deliver cash and/or shares of our common stock for the amount of our conversion obligation in excess of the aggregate principal amount of the Notes being converted. Refer to Note 8. Convertible Senior Notes included in Part II, Item 8 of this Annual Report on Form 10-K for information on the Notes.

[0001327567-17-000027:mdna:122]
In August 2016, our board of directors authorized a $500.0 million share repurchase and, in February 2017, authorized a $500.0 million increase to our repurchase program, bringing the total authorization to $1.0 billion. Repurchases are funded from available working capital and may be made at management’s discretion from time to time. The repurchase authorization will expire on December 31, 2018, and may be suspended or discontinued at any time. As of July 31, 2017, $580.0 million was available for future share repurchases under the repurchase authorization. Refer to Note 10. Stockholders’ Equity in Part II, Item 8 of this Annual Report on Form 10-K for information on the repurchase authorization.

[0001327567-17-000027:mdna:123]
- 48 -

[0001327567-17-000027:mdna:124]
The following table summarizes our cash flows for the years ended July 31, 2017, 2016, and 2015:

[0001327567-17-000027:mdna:125]
|  | Year Ended July 31, |
| 2017 |  | 2016 |  | 2015 |
|  | (in millions) |
| Net cash provided by operating activities(1) | $ | 868.5 |  |  | $ | 658.6 |  |  | $ | 352.8 |  |
| Net cash used in investing activities | (472.6 | ) |  | (338.9 | ) |  | (679.0 | ) |
| Net cash provided by (used in) financing activities(1) | (386.0 | ) |  | 38.9 |  |  | 48.2 |  |
| Net increase (decrease) in cash and cash equivalents | $ | 9.9 |  |  | $ | 358.6 |  |  | $ | (278.0 | ) |

[0001327567-17-000027:mdna:126]
______________

[0001327567-17-000027:mdna:127]
| (1) | Prior period amounts have been adjusted due to our early adoption of new share-based payment accounting guidance. Refer to Note 1. Description of Business and Summary of Significant Accounting Policies in Part II, Item 8 of this Annual Report on Form 10-K for more information. |

[0001327567-17-000027:mdna:128]
We believe that our cash flow from operations with existing cash and cash equivalents will be sufficient to meet our anticipated cash needs for the foreseeable future. Our future capital requirements will depend on many factors including our growth rate, the timing and extent of spending to support development efforts, the expansion of sales and marketing activities, the introduction of new and enhanced products and subscription and support offerings, the costs to acquire or invest in complementary businesses and technologies, the costs to ensure access to adequate manufacturing capacity, the investments in our new corporate headquarters, and the continuing market acceptance of our products and subscription and support offerings. In addition, from time to time we may incur additional tax liability in connection with certain corporate structuring decisions.

[0001327567-17-000027:mdna:129]
We may also choose to seek additional equity or debt financing. In the event that additional financing is required from outside sources, we may not be able to raise it on terms acceptable to us or at all. If we are unable to raise additional capital when desired, our business, operating results, and financial condition may be adversely affected.

[0001327567-17-000027:mdna:130]
Operating Activities

[0001327567-17-000027:mdna:131]
Our operating activities have consisted of net losses adjusted for certain non-cash items and changes in assets and liabilities.

[0001327567-17-000027:mdna:132]
Cash provided by operating activities in fiscal 2017 was $868.5 million, an increase of $209.9 million compared to fiscal 2016. The increase was due to growth of our business, as reflected by an increase in billings, and an increase in collections on accounts receivable during fiscal 2017.

[0001327567-17-000027:mdna:133]
Cash provided by operating activities in fiscal 2016 was $658.6 million, an increase of $305.8 million compared to fiscal 2015. The increase was due to growth of our business and changes in our assets and liabilities during fiscal 2016, which included an increase in sales of subscription and support contracts to new and existing customers as reflected by an increase in deferred revenue, and was partially offset by an increase in accounts receivable due to an increase in sales near the end of the period.

[0001327567-17-000027:mdna:134]
Investing Activities

[0001327567-17-000027:mdna:135]
Our investing activities have consisted of capital expenditures, net investment purchases, sales, and maturities, and business acquisitions. We expect to continue such activities as our business grows.

[0001327567-17-000027:mdna:136]
Cash used in investing activities during fiscal 2017 was $472.6 million, an increase of $133.7 million compared to fiscal 2016, due to increased investment in facilities to support the growth of our business and a net cash payment of $90.7 million for our acquisition of LightCyber, partially offset by lower net purchases of available-for-sale investments during fiscal 2017.

[0001327567-17-000027:mdna:137]
Cash used in investing activities during fiscal 2016 was $338.9 million, a decrease of $340.1 million compared to fiscal 2015, due to lower net purchases of available-for-sale investments and a payment of $15.1 million related to our acquisition of CirroSecure in fiscal 2015, partially offset by increased investment in infrastructure and facilities to support the growth of our business.

[0001327567-17-000027:mdna:138]
Financing Activities

[0001327567-17-000027:mdna:139]
Our financing activities have consisted of proceeds from sales of shares through employee equity incentive plans, cash used to repurchase shares of our common stock, and payments for tax withholding obligations of certain employees related to the net share settlement of equity awards.

[0001327567-17-000027:mdna:140]
- 49 -

[0001327567-17-000027:mdna:141]
Cash used in financing activities during fiscal 2017 was $386.0 million, a change of $424.9 million compared to fiscal 2016, due to the repurchase of $411.0 million of our common stock and payments for tax withholding obligations of certain employees related to the net share settlement of equity awards of $21.4 million during fiscal 2017.

[0001327567-17-000027:mdna:142]
Cash provided by financing activities during fiscal 2016 was $38.9 million, a decrease of $9.3 million compared to fiscal 2015, due to a payment of deferred consideration related to our acquisition of Cyvera and lower proceeds from the sale of shares through employee equity incentive plans.

[0001327567-17-000027:mdna:143]
Contractual Obligations and Commitments

[0001327567-17-000027:mdna:144]
The following summarizes our contractual obligations and commitments as of July 31, 2017:

[0001327567-17-000027:mdna:145]
|  | Payments Due by Period |
|  | Total |  | Less Than 1 Year |  | 1-3 Years |  | 3-5 Years |  | More Than 5 Years |
|  |  |  | (in millions) |  |  |
| 0.0% Convertible Senior Notes due 2019 | $ | 575.0 |  |  | $ | — |  |  | $ | 575.0 |  |  | $ | — |  |  | $ | — |  |
| Operating lease obligations(1) | 517.5 |  |  | 31.0 |  |  | 110.8 |  |  | 111.2 |  |  | 264.5 |  |
| Purchase obligations(2) | 104.1 |  |  | 98.5 |  |  | 5.6 |  |  | — |  |  | — |  |
| Total(3) | $ | 1,196.6 |  |  | $ | 129.5 |  |  | $ | 691.4 |  |  | $ | 111.2 |  |  | $ | 264.5 |  |

[0001327567-17-000027:mdna:146]
______________

[0001327567-17-000027:mdna:147]
| (1) | Consists of contractual obligations from our non-cancelable operating leases. Excludes contractual sublease proceeds of $2.1 million, which will be received in less than one year. Refer to Note 9. Commitments and Contingencies of Notes to Consolidated Financial Statements included in Part II, Item 8 of this Annual Report on Form 10-K for more information on our operating leases. |

[0001327567-17-000027:mdna:148]
| (2) | Consists of minimum purchase commitments of products and components with our manufacturing partners and component suppliers. Obligations under contracts that we can cancel without a significant penalty are not included in the table above. |

[0001327567-17-000027:mdna:149]
| (3) | No amounts related to income taxes are included. As of July 31, 2017, we had approximately $62.2 million of tax liabilities recorded related to uncertainty in income tax positions. |

[0001327567-17-000027:mdna:150]
Off-Balance Sheet Arrangements

[0001327567-17-000027:mdna:151]
Through July 31, 2017, we did not have any relationships with unconsolidated organizations or financial partnerships, such as structured finance or special purpose entities that would have been established for the purpose of facilitating off-balance sheet arrangements or other contractually narrow or limited purposes.

[0001327567-17-000027:mdna:152]
Critical Accounting Estimates

[0001327567-17-000027:mdna:153]
Our consolidated financial statements have been prepared in accordance with U.S. GAAP. The preparation of these consolidated financial statements requires us to make estimates and assumptions that affect the reported amounts of assets, liabilities, revenue, expenses, and related disclosures. We base our estimates on historical experience and on various other assumptions that we believe are reasonable under the circumstances. We evaluate our estimates and assumptions on an ongoing basis. Actual results may differ from these estimates. To the extent that there are material differences between these estimates and our actual results, our future financial statements will be affected.

[0001327567-17-000027:mdna:154]
The critical accounting policies requiring estimates, assumptions, and judgments that we believe have the most significant impact on our consolidated financial statements are described below.

[0001327567-17-000027:mdna:155]
Revenue Recognition

[0001327567-17-000027:mdna:156]
We recognize revenue when persuasive evidence of an arrangement exists, delivery has occurred, the fee is fixed or determinable, and collectability is reasonably assured. Most of our arrangements, other than renewals of subscriptions and support contracts, are multiple-element arrangements with a combination of hardware, software, subscriptions, support, and other services. For multiple-element arrangements, we allocate revenue to each unit of accounting based on an estimated selling price at the arrangement inception. The estimated selling price for each element is based upon the following hierarchy:

[0001327567-17-000027:mdna:157]
| • | Vendor-specific objective evidence (“VSOE”) of selling price, if available, |

[0001327567-17-000027:mdna:158]
- 50 -

[0001327567-17-000027:mdna:159]
| • | Third-party evidence (“TPE”) of selling price, if VSOE of selling price is not available, or |

[0001327567-17-000027:mdna:160]
| • | Best estimate of selling price (“BESP”), if neither VSOE of selling price nor TPE of selling price are available. |

[0001327567-17-000027:mdna:161]
We establish VSOE of selling price using the prices charged for a deliverable when sold separately. We establish TPE of selling price by evaluating similar and interchangeable competitor products or services in standalone arrangements with similarly situated partners. We establish BESP primarily based on historical transaction pricing, whereby historical transactions are segregated based on our pricing model and our go-to-market strategy, which include factors such as type of sales channel (reseller, distributor, or end-customer), the geographies in which our products and services were sold (domestic or international), and offering type (products or services). To further support BESP as determined by the historical transaction pricing or when such information is unavailable, such as when there are limited sales of a new product or service, we consider the same factors we have established through our pricing model and go-to-market strategy. The determination of BESP is made through consultation with and approval by our management. In determining BESP, we rely on certain assumptions and apply significant judgment. As our business offerings evolve over time, we may be required to modify our estimated selling prices in subsequent periods, and the timing of our revenue recognition could be affected.

[0001327567-17-000027:mdna:162]
Income Taxes

[0001327567-17-000027:mdna:163]
We account for income taxes using the asset and liability method, which requires the recognition of deferred tax assets and liabilities for the expected future tax consequences of events that have been recognized in our financial statements or tax returns. In addition, deferred tax assets are recorded for the future benefit of utilizing net operating losses and research and development credit carryforwards. Valuation allowances are provided when necessary to reduce deferred tax assets to the amount expected to be realized.

[0001327567-17-000027:mdna:164]
Significant judgment is required in determining any valuation allowance recorded against deferred tax assets. In assessing the need for a valuation allowance, we consider all available evidence, including past operating results, estimates of future taxable income, and the feasibility of tax planning strategies. In the event that we change our determination as to the amount of deferred tax assets that can be realized, we will adjust our valuation allowance with a corresponding impact to the provision for income taxes in the period in which such determination is made.

[0001327567-17-000027:mdna:165]
We apply the authoritative accounting guidance prescribing a threshold and measurement attribute for the financial recognition and measurement of a tax position taken or expected to be taken in a tax return. We recognize liabilities for uncertain tax positions based on a two-step process. The first step is to evaluate the tax position for recognition by determining if the weight of available evidence indicates that it is more likely than not that the position will be sustained on audit, including resolution of related appeals or litigation processes, if any. The second step requires us to estimate and measure the tax benefit as the largest amount that is more likely than not to be realized upon ultimate settlement.

[0001327567-17-000027:mdna:166]
Significant judgment is also required in evaluating our uncertain tax positions and determining our provision for income taxes. Although we believe our reserves are reasonable, no assurance can be given that the final tax outcome of these matters will not be different from that which is reflected in our historical income tax provisions and accruals. We adjust these reserves in light of changing facts and circumstances, such as the closing of a tax audit or the refinement of an estimate. To the extent that the final tax outcome of these matters is different than the amounts recorded, such differences may impact the provision for income taxes in the period in which such determination is made.

[0001327567-17-000027:mdna:167]
Manufacturing Partner and Supplier Liabilities

[0001327567-17-000027:mdna:168]
We outsource most of our manufacturing, repair, and supply chain management operations to our EMS provider, which procures components and assembles our products based on our demand forecasts. These forecasts of future demand are based upon historical trends and analysis from our sales and product management functions as adjusted for overall market conditions. We accrue for costs for manufacturing purchase commitments in excess of our forecasted demand, including costs for excess components or for carrying costs incurred by our manufacturing partners and component suppliers. Actual component usage and product demand may be materially different from our forecast, and could be caused by factors outside of our control, which could have an adverse impact on our results of operations. To date, we have not accrued significant costs associated with this exposure.

[0001327567-17-000027:mdna:169]
Loss Contingencies

[0001327567-17-000027:mdna:170]
We are subject to the possibility of various loss contingencies arising in the ordinary course of business. We accrue for loss contingencies when it is probable that an asset has been impaired or a liability has been incurred and the amount of loss can be reasonably estimated. If we determine that a loss is possible and the range of the loss can be reasonably determined, then we disclose the range of the possible loss. We regularly evaluate current information available to us to determine whether an accrual is required, an accrual should be adjusted or a range of possible loss should be disclosed.

[0001327567-17-000027:mdna:171]
- 51 -

[0001327567-17-000027:mdna:172]
From time to time, we are involved in disputes, litigation, and other legal actions. However, there are many uncertainties associated with any litigation, and these actions or other third-party claims against us may cause us to incur substantial settlement charges, which are inherently difficult to estimate and could adversely affect our results of operations. The actual liability in any such matters may be materially different from our estimates, which could result in the need to adjust our liability and record additional expenses.

[0001327567-17-000027:mdna:173]
Goodwill, Intangibles, and Other Long-Lived Assets

[0001327567-17-000027:mdna:174]
We make significant estimates, assumptions, and judgments when valuing goodwill and other purchased intangible assets in connection with the initial purchase price allocation of an acquired entity, as well as when evaluating impairment of goodwill and other purchased intangible assets on an ongoing basis. These estimates are based upon a number of factors, including historical experience, market conditions, and information obtained from the management of the acquired company. Critical estimates in valuing certain intangible assets include, but are not limited to, cash flows that an asset is expected to generate in the future, discount rates, the time and expense that would be necessary to recreate the assets, and the profit margin a market participant would receive. The amounts and useful lives assigned to identified intangible assets impacts the amount and timing of future amortization expense.

[0001327567-17-000027:mdna:175]
We evaluate goodwill for impairment on an annual basis in our fourth fiscal quarter or more frequently if we believe impairment indicators exist. We have elected to first assess qualitative factors to determine whether it is more likely than not that the fair value of our reporting unit is less than its carrying amount, including goodwill. The qualitative assessment includes our evaluation of relevant events and circumstances affecting our single reporting unit, including macroeconomic, industry, and market conditions, our overall financial performance, and trends in the market price of our common stock. If qualitative factors indicate that it is more likely than not that our reporting unit’s fair value is less than its carrying amount, then we will perform the quantitative impairment test by comparing our reporting unit’s carrying amount, including goodwill, to its fair value. If the carrying amount of our reporting unit exceeds its fair value, an impairment loss will be recognized in an amount equal to that excess. To date, the results of our qualitative assessment have indicated that the quantitative goodwill impairment test is not necessary.

[0001327567-17-000027:mdna:176]
We evaluate long-lived assets, such as property, equipment, and purchased intangible assets for impairment whenever events or changes in circumstances indicate that the carrying amount of the assets may not be recoverable. Such events or changes in circumstances include, but are not limited to, a significant decrease in the fair value of the underlying asset or asset group, a significant decrease in the benefits realized from the acquired assets, difficulty and delays in integrating the business, or a significant change in the operations of the acquired assets or use of an asset or asset group. A long-lived asset is considered impaired if its carrying amount exceeds the estimated future undiscounted cash flows the asset or asset group is expected to generate. Critical estimates in determining whether a long-lived asset is considered impaired include the amount and timing of future cash flows that the asset or asset group is expected to generate. If a long-lived asset is considered to be impaired, the impairment to be recognized is the amount by which the carrying amount of the asset exceeds the fair value of the asset or asset group, which is estimated using a present value technique. Critical estimates in determining the fair value of an asset or asset group and the amount of impairment to recognize include, but are not limited to, the amount and timing of future cash flows that the asset or asset group is expected to generate and the discount rate. Determining the fair value of an asset or asset group is highly judgmental in nature and involves the use of significant estimates and assumptions for market participants. We base our fair value estimates on assumptions we believe to be reasonable but that are unpredictable and inherently uncertain. Actual future results may differ from those estimates.

[0001327567-17-000027:mdna:177]
To date, we have not recognized any impairment losses on our goodwill and intangible assets. In fiscal 2017, we recognized an impairment loss of $20.9 million on property and equipment related to the relocation of our corporate headquarters. We did not recognize any impairment losses on our other long-lived assets prior to fiscal 2017.

[0001327567-17-000027:mdna:178]
Recent Accounting Pronouncements

[0001327567-17-000027:mdna:179]
Refer to “Recently Issued Accounting Pronouncements” in Note 1. Description of Business and Summary of Significant Accounting Policies of Notes to Consolidated Financial Statements included in Part II, Item 8 of this Annual Report on Form 10-K.
