# PANW 10-K controls and the auditor's report


## auditors_report

10-K auditors_report: 2 candidate headings, none whose body matches 'critical audit matter'.


## item_9a

[0001327567-14-000028:item_9a:1]
| ITEM 9A. | CONTROLS AND PROCEDURES |

[0001327567-14-000028:item_9a:2]
Evaluation of Disclosure Controls and Procedures

[0001327567-14-000028:item_9a:3]
Our management, with the participation of our chief executive officer and chief financial officer, evaluated the effectiveness of our disclosure controls and procedures pursuant to Rule 13a-15 under the Securities Exchange Act of 1934, as amended (the “Exchange Act”). In designing and evaluating the disclosure controls and procedures, management recognizes that any controls and procedures, no matter how well designed and operated, can provide only reasonable assurance of achieving the desired control objectives. In addition, the design of disclosure controls and procedures must reflect the fact that there are resource constraints and that management is required to apply its judgment in evaluating the benefits of possible controls and procedures relative to their costs.

[0001327567-14-000028:item_9a:4]
Based on our evaluation, our chief executive officer and chief financial officer concluded that, as of July 31, 2014, our disclosure controls and procedures are designed at a reasonable assurance level and are effective to provide reasonable assurance that information we are required to disclose in reports that we file or submit under the Exchange Act is recorded, processed, summarized, and reported within the time periods specified in Securities and Exchange Commission (SEC) rules and forms, and that such information is accumulated and communicated to our management, including our chief executive officer and chief financial officer, as appropriate, to allow timely decisions regarding required disclosure.

[0001327567-14-000028:item_9a:5]
Management’s Annual Report on Internal Control Over Financial Reporting

[0001327567-14-000028:item_9a:6]
For “Management's Annual Report on Internal Control Over Financial Reporting” see the report under Part II, Item 8 of this Annual Report on Form 10-K, which report is incorporated herein by reference.

[0001327567-14-000028:item_9a:7]
- 94 -

[0001327567-14-000028:item_9a:8]
For the “Report of Independent Registered Public Accounting Firm,” see the report under Part II, Item 8 of this Annual Report on Form 10-K, which report is incorporated herein by reference.

[0001327567-14-000028:item_9a:9]
Changes in Internal Control Over Financial Reporting

[0001327567-14-000028:item_9a:10]
There were no changes in our internal control over financial reporting identified in connection with the evaluation required by Rule 13a-15(d) and 15d-15(d) of the Exchange Act that occurred during the quarter ended July 31, 2014 that have materially affected, or are reasonably likely to materially affect, our internal control over financial reporting.
