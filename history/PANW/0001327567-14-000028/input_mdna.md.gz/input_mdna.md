# PANW MD&A — 0001327567-14-000028


## mdna

[0001327567-14-000028:mdna:1]
| ITEM 7. | MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS |

[0001327567-14-000028:mdna:2]
The following discussion and analysis of our financial condition and results of operations should be read in conjunction with our consolidated financial statements and related notes appearing elsewhere in this Annual Report on Form 10-K. The following discussion and analysis contains forward-looking statements based on current expectations and assumptions that are subject to risks and uncertainties, which could cause our actual results to differ materially from those anticipated or implied by any forward-looking statements. Factors that could cause or contribute to such differences include, but are not limited to, those discussed in this Annual Report on Form 10-K, and in particular, the risks discussed under the caption “Risk Factors” in Part I, Item 1A of this report.

[0001327567-14-000028:mdna:3]
Our Management’s Discussion and Analysis of Financial Condition and Results of Operations (MD&A) is organized as follows:

[0001327567-14-000028:mdna:4]
| • | Overview. Discussion of our business and overall analysis of financial and other highlights in order to provide context for the remainder of MD&A. |

[0001327567-14-000028:mdna:5]
| • | Key Financial Metrics. An analysis of our generally accepted accounting principles (GAAP) and non-GAAP key financial metrics, which management monitors to evaluate our performance. |

[0001327567-14-000028:mdna:6]
| • | Financial Overview. Discussion of the nature and trends of components of our financial results. |

[0001327567-14-000028:mdna:7]
| • | Results of Operations. An analysis of our financial results comparing fiscal 2014 and 2013, and fiscal 2013 and 2012. |

[0001327567-14-000028:mdna:8]
| • | Liquidity and Capital Resources. An analysis of changes in our balance sheets and cash flows, and discussion of our financial condition and our ability to meet cash needs. |

[0001327567-14-000028:mdna:9]
| • | Contractual Obligations and Commitments. Overview of contractual obligations, contingent liabilities, commitments, and off-balance sheet arrangements outstanding as of July 31, 2014, including expected payment schedule. |

[0001327567-14-000028:mdna:10]
| • | Critical Accounting Policies and Estimates. A discussion of accounting policies that require critical estimates, assumptions, and judgments. |

[0001327567-14-000028:mdna:11]
| • | Recent Accounting Pronouncements. A discussion of expected impacts of impending accounting changes on financial information to be reported in the future. |

[0001327567-14-000028:mdna:12]
Overview

[0001327567-14-000028:mdna:13]
We have pioneered the next-generation of enterprise security with our innovative platform that allows enterprises, service providers, and government entities to simultaneously empower and secure their organizations by safely enabling the increasingly complex and rapidly growing number of applications running on their networks and by preventing breaches stemming from targeted cyber attacks. Our enterprise security platform consists of three major elements: our Next-Generation Firewall, our Advanced Endpoint Protection, and our Threat Intelligence Cloud. Our Next-Generation Firewall delivers application, user, and content visibility and control as well as protection against network based cyber threats integrated within the firewall through our proprietary hardware and software architecture. Our Advanced Endpoint Protection, which we expect to release in fiscal 2015, prevents cyber attacks that aim to exploit software vulnerabilities on a broad variety of fixed and virtual endpoints. Our Threat Intelligence Cloud provides central intelligence capabilities as well as automated delivery of preventative measures against cyber attacks. The cloud-based element of our platform is delivered in the form of a service that can be used either in the public cloud or in a private cloud using a dedicated appliance.

[0001327567-14-000028:mdna:14]
We derive revenue from sales of our products and services, which together comprise our platform. Product revenue is generated from sales of our Next-Generation Firewall, which is available in hardware and virtualized form factors. Our Next-Generation Firewall incorporates our proprietary PAN-OS operating system, which provides a consistent set of capabilities across our entire product line. These capabilities include: application visibility and control (App-ID), user identification (User-ID), site-to-site virtual private network (VPN), remote access Secure Sockets Layer (SSL) VPN, and Quality-of-Service (QoS). Our products are designed for different performance requirements throughout an organization, ranging from the PA-200, which is designed for enterprise remote offices, to the PA-7050, which is designed for data centers and high-speed networks. The same firewall functionality that is delivered in the hardware appliances is also available in the VM-Series virtual firewalls, which secure virtualized and cloud-based computing environments. Multiple firewalls can jointly use our WildFire appliance, WF-500, which identifies, analyzes, and blocks known and unknown malware in a private cloud-based environment. Our platform can be centrally managed in both virtualized and hardware appliances across an organization with our Panorama product. In addition, our GlobalProtect appliance, GP-100, provides mobile device management, malware detection, and shares device state information to safely enable mobile devices for business use.

[0001327567-14-000028:mdna:15]
- 40 -

[0001327567-14-000028:mdna:16]
Services revenue is generated from sales of subscriptions and support and maintenance. Our Threat Prevention, URL Filtering, GlobalProtect, and WildFire subscriptions provide our end-customers with real-time access to the latest antivirus, intrusion prevention, web filtering, and modern malware prevention capabilities across fixed and mobile devices. Our Advanced Endpoint Protection, which we expect to release in fiscal 2015, protects against cyber attacks that exploit software vulnerabilities in Windows-based fixed and virtual endpoints through the use of its unique capability of stopping the underlying exploit techniques, and can prevent cyber attacks without relying on prior knowledge of the attack. When end-customers purchase an appliance, they typically purchase one or more of our subscriptions for additional functionality, as well as support and maintenance in order to receive ongoing security updates, upgrades, bug fixes, and repairs. We leverage our appliances to sell software as a service (SaaS) subscription services to meet our customers’ evolving enterprise security requirements. Our hybrid SaaS revenue model consists of product, subscriptions, and support and maintenance, which will enable us to benefit from recurring revenues as we continue to grow our installed end-customer base. Sales of these services increase our deferred revenue balance and contribute significantly to our positive cash flow provided by operating activities.

[0001327567-14-000028:mdna:17]
We maintain a field sales force that works closely with our channel partners in developing sales opportunities. We use a two-tier, indirect fulfillment model whereby we sell our products and services to our global distributor channel partners, which, in turn, sell our products and services to our reseller network, which then sell to our end-customers. Our channel partners purchase our products and services at a discount to our list prices before reselling them to our end-customers. Our channel partners generally receive an order from an end-customer prior to placing an order with us and generally do not stock appliances.

[0001327567-14-000028:mdna:18]
We continue to invest in innovation and strengthening our product portfolio, which resulted in several new product offerings during fiscal 2014. These new product offerings include: the PA-7050 firewall with a throughput of 120Mbps; the GP-100 mobile security management appliance, which offers an easy to deploy, high-performance, dedicated management appliance for our GlobalProtect customers; and the VM-1000-HV virtual Next-Generation Firewall, which is fully integrated with VMware's NSX virtualization platform.

[0001327567-14-000028:mdna:19]
In addition, we extended our enterprise security platform and our technology leadership with the acquisitions of Cyvera Ltd. (“Cyvera”) and Morta Security, Inc. (“Morta”). Cyvera's endpoint software protects enterprises from cyber threats by using an innovative approach to block unknown, zero-day attacks on the endpoint. We intend to invest approximately $25.0 million in fiscal 2015 in research and development, customer support, and growing our Advanced Endpoint Protection sales force. We anticipate billings (non-GAAP) and revenue of our Advanced Endpoint Protection will begin ramping in the second half of fiscal 2015 with a more meaningful revenue contribution in fiscal 2016. Morta provides a team of cybersecurity experts that will enhance our WildFire threat prevention offering. These enhancements enable quick discovery and elimination of previously unknown malware, zero-day exploits, and advanced persistent threats.

[0001327567-14-000028:mdna:20]
In May 2014, we entered into a Settlement, Release and Cross-License Agreement (the “settlement agreement”) with Juniper Networks, Inc. (“Juniper”). Under the terms of the settlement agreement, we agreed to pay Juniper $75.0 million in cash, transfer 1.1 million shares of our common stock, and issue a warrant to purchase 0.5 million shares of our common stock. The terms of the settlement agreement provide for mutual dismissal with prejudice of all pending litigation between the parties, cross-license of the patents in suit for the life of the patents, and an eight-year mutual covenant not to sue for infringement of any other patents. The settlement with Juniper resolves all pending litigation matters between us and will allow us to further focus on innovating and strengthening our product portfolio, servicing our customers, and growing our business.

[0001327567-14-000028:mdna:21]
For fiscal 2014, we added more than 5,300 new customers, including some of the largest Fortune 100 and Global 2000 companies in the world. We had more than 19,000 end-customers in over 130 countries as of July 31, 2014. Our end-customers represent a broad range of industries including education, energy, financial services, government entities, healthcare, Internet and media, manufacturing, public sector, and telecommunications. As of July 31, 2014, we had 1,722 employees.

[0001327567-14-000028:mdna:22]
For fiscal 2014, 2013, and 2012, revenues were $598.2 million, $396.1 million, and $255.1 million, respectively, representing year over year growth of 51.0% for fiscal 2014 and 55.3% for fiscal 2013, despite continued uncertainty in the macroeconomic environment.

[0001327567-14-000028:mdna:23]
All three components of our hybrid SaaS revenue model experienced year over year growth, led by revenue from subscription services, which grew 73.1% to $123.2 million, followed by support and maintenance services, which grew 66.0% to $134.8 million, and product, which grew 39.6% to $340.1 million. The growth reflected increasing recurring revenue in our business model and rapid adoption of high margin subscription services in our base of end-customers.

[0001327567-14-000028:mdna:24]
In June 2014, we issued $575.0 million aggregate principal amount of 0.0% convertible senior notes due 2019 (the "Notes"). The net proceeds from the offering, after deducting fees and offering expenses of $15.4 million, were approximately $559.6 million. In connection with the offering of the Notes, we entered into convertible note hedge transactions whereby we have the option to purchase up to 5.2 million shares of our common stock at a price of approximately $110.28 per share. In addition, concurrent with entering into the convertible note hedge transactions, we entered into separate warrant transactions whereby we sold warrants to acquire approximately 5.2 million shares of our common stock at an initial strike price of approximately $137.85 per share. We used approximately $32.7 million of the net proceeds from the offering to pay the cost of the convertible note hedge

[0001327567-14-000028:mdna:25]
- 41 -

[0001327567-14-000028:mdna:26]
transactions (after such cost was partially offset by the proceeds from the warrant transactions). Refer to Note 7. Convertible Senior Notes of Notes to Consolidated Financial Statements included in Part II, Item 8 of this Annual Report on Form 10-K for information related to the Notes. Our cash, cash equivalents, and investments were $974.4 million as of July 31, 2014.

[0001327567-14-000028:mdna:27]
We believe that the growth of our business and our short-term and long-term success are dependent upon many factors, including our ability to extend our technology leadership, grow our base of end-customers, expand deployment of our platform and services within existing end-customers, extend the length of service terms within existing end-customers, and focus on end-customer satisfaction. While these areas present significant opportunities for us, they also pose challenges and risks that we must successfully address in order to sustain the growth of our business and improve our operating results.

[0001327567-14-000028:mdna:28]
To manage any future growth effectively, we must continue to improve and expand our information technology and financial infrastructure, our operating and administrative systems and controls, and our ability to manage headcount, capital, and processes in an efficient manner. Additionally, we face intense competition in our market, and to succeed, we need to innovate and offer products that are differentiated from existing infrastructure products, as well as effectively hire, retain, train, and motivate qualified personnel and senior management. If we are unable to successfully address these challenges, our business, operating results, and prospects could be adversely affected.

[0001327567-14-000028:mdna:29]
Key Financial Metrics

[0001327567-14-000028:mdna:30]
We monitor the key financial metrics set forth below to help us evaluate growth trends, establish budgets, measure the effectiveness of our sales and marketing efforts, and assess operational efficiencies. We discuss revenue, gross margin, and the components of operating loss and margin below under “—Financial Overview” and “—Results of Operations.” The following tables summarize deferred revenue, cash flow provided by operating activities, free cash flow (non-GAAP), and billings (non-GAAP).

[0001327567-14-000028:mdna:31]
|  | July 31, |
|  | 2014 |  | 2013 |
|  | (in thousands) |
| Total deferred revenue | $ | 422,578 |  |  | $ | 249,230 |  |
| Cash, cash equivalents, and investments | $ | 974,382 |  |  | $ | 436,935 |  |

[0001327567-14-000028:mdna:32]
|  | Year Ended July 31, |
|  | 2014 |  | 2013 |  | 2012 |
|  | (dollars in thousands) |
| Total revenue | $ | 598,179 |  |  | $ | 396,107 |  |  | $ | 255,138 |  |
| Year over year percentage increase | 51.0 | % |  | 55.3 | % |  | 115.1 | % |
| Gross margin percentage(5) | 73.3 | % |  | 72.3 | % |  | 72.3 | % |
| Operating income (loss)(1)(2)(3)(4)(5) | $ | (215,347 | ) |  | $ | (18,621 | ) |  | $ | 3,891 |  |
| Operating margin percentage | (36.0 | )% |  | (4.7 | )% |  | 1.5 | % |
| Billings (non-GAAP) | $ | 771,375 |  |  | $ | 509,529 |  |  | $ | 323,691 |  |
| Cash flow provided by operating activities | $ | 88,406 |  |  | $ | 114,519 |  |  | $ | 77,368 |  |
| Free cash flow (non-GAAP)(6) | $ | 52,299 |  |  | $ | 92,077 |  |  | $ | 62,803 |  |

[0001327567-14-000028:mdna:33]
______________

[0001327567-14-000028:mdna:34]
| (1) | Includes share-based compensation expense of $99.9 million, $43.9 million, and $13.9 million for fiscal 2014, 2013, and 2012, respectively. |

[0001327567-14-000028:mdna:35]
| (2) | Includes intellectual property litigation expense of $11.3 million, $3.6 million, and $0.7 million for fiscal 2014, 2013, and 2012, respectively. |

[0001327567-14-000028:mdna:36]
| (3) | Includes legal settlement expense of $141.2 million, nil, and nil for fiscal 2014, 2013, and 2012, respectively. |

[0001327567-14-000028:mdna:37]
| (4) | Includes acquisition transaction costs of $4.4 million, nil, and nil for fiscal 2014, 2013, and 2012, respectively. |

[0001327567-14-000028:mdna:38]
| (5) | Includes amortization of Juniper intellectual property licenses of $2.0 million, nil, and nil for fiscal 2014, 2013, and 2012, respectively. |

[0001327567-14-000028:mdna:39]
- 42 -

[0001327567-14-000028:mdna:40]
| (6) | Includes our cash payments of $75.0 million and $20.0 million in fiscal 2014 for the legal settlement with Juniper and the Mutual Covenant Not to Sue and Release Agreement with Fortinet, respectively. |

[0001327567-14-000028:mdna:41]
| • | Deferred Revenue. Our deferred revenue consists of amounts that have been invoiced but that have not yet been recognized as revenue as of the period end. The majority of our deferred revenue balance consists of subscription and support and maintenance revenue that is recognized ratably over the contractual service period. We monitor our deferred revenue balance because it represents a significant portion of revenue to be recognized in future periods. |

[0001327567-14-000028:mdna:42]
| • | Cash Flow Provided by Operating Activities. We monitor cash flow provided by operating activities as a measure of our overall business performance. Our cash flow provided by operating activities is driven in large part by sales of our products and from up-front payments for both subscriptions and support and maintenance services. Monitoring cash flow provided by operating activities enables us to analyze our financial performance without the non-cash effects of certain items such as depreciation, amortization, and share-based compensation costs, thereby allowing us to better understand and manage the cash needs of our business. |

[0001327567-14-000028:mdna:43]
| • | Free Cash Flow (non-GAAP). We define free cash flow, a non-GAAP financial measure, as cash provided by operating activities less purchases of property, equipment, and other assets. We consider free cash flow to be a liquidity measure that provides useful information to management and investors about the amount of cash generated by the business that, after the purchases of property, equipment, and other assets, can be used for strategic opportunities, including investing in our business, making strategic acquisitions, and strengthening the balance sheet. A limitation of the utility of free cash flow as a measure of our financial performance and liquidity is that it does not represent the total increase or decrease in our cash balance for the period. In addition, it is important to note that other companies, including companies in our industry, may not use free cash flow, may calculate free cash flow in a different manner than we do, or may use other financial measures to evaluate their performance, all of which could reduce the usefulness of free cash flow as a comparative measure. A reconciliation of free cash flow to cash flow provided by operating activities, the most directly comparable financial measure calculated and presented in accordance with GAAP, is provided below: |

[0001327567-14-000028:mdna:44]
|  | Year Ended July 31, |
|  | 2014 |  | 2013 |  | 2012 |
|  | (in thousands) |
| Cash Flow: |  |  |  |  |  |
| Cash flow provided by operating activities | $ | 88,406 |  |  | $ | 114,519 |  |  | $ | 77,368 |  |
| Less: purchase of property, equipment, and other assets | 36,107 |  |  | 22,442 |  |  | 14,565 |  |
| Free cash flow (non-GAAP)(1) | $ | 52,299 |  |  | $ | 92,077 |  |  | $ | 62,803 |  |
| Net cash used in investing activities | $ | (320,348 | ) |  | $ | (151,565 | ) |  | $ | (14,565 | ) |
| Net cash provided by financing activities | $ | 575,140 |  |  | $ | 25,018 |  |  | $ | 219,322 |  |

[0001327567-14-000028:mdna:45]
______________

[0001327567-14-000028:mdna:46]
| (1) | Includes our cash payments of $75.0 million and $20.0 million in fiscal 2014 for the legal settlement with Juniper and the Mutual Covenant Not to Sue and Release Agreement with Fortinet, respectively. |

[0001327567-14-000028:mdna:47]
| • | Billings (non-GAAP). We define billings, a non-GAAP financial measure, as total revenue plus the change in deferred revenue, net of acquired deferred revenue, during the period. Billings is a key measure used by our management to manage our business because billings drive deferred revenue, which is an important indicator of the health and visibility of our business. We consider billings to be a useful metric for management and investors, particularly as we experience increased sales of subscriptions and strong renewal rates for subscriptions and support and maintenance services, and monitor our near term cash flows. We believe that billings provides useful information to investors and others in understanding and evaluating our operating results in the same manner as our management. However, it is important to note that other companies, including companies in our industry, may not use billings, may calculate billings differently, may have different billing frequencies, or may use other financial measures to evaluate their performance, all of which could reduce the usefulness of billings as a comparative measure. A reconciliation of billings to revenue, the most directly comparable financial measure calculated and presented in accordance with GAAP, is provided below: |

[0001327567-14-000028:mdna:48]
- 43 -

[0001327567-14-000028:mdna:49]
|  | Year Ended July 31, |
|  | 2014 |  | 2013 |  | 2012 |
|  | (in thousands) |
| Billings (non-GAAP): |  |  |  |  |  |
| Total revenue | $ | 598,179 |  |  | $ | 396,107 |  |  | $ | 255,138 |  |
| Add: change in total deferred revenue, net of acquired deferred revenue | 173,196 |  |  | 113,422 |  |  | 68,553 |  |
| Billings (non-GAAP) | $ | 771,375 |  |  | $ | 509,529 |  |  | $ | 323,691 |  |

[0001327567-14-000028:mdna:50]
Financial Overview

[0001327567-14-000028:mdna:51]
Revenue

[0001327567-14-000028:mdna:52]
We derive revenue from sales of our products and services. Revenue is recognized when persuasive evidence of an arrangement exists, delivery has occurred, the fee is fixed or determinable, and collectability is reasonably assured.

[0001327567-14-000028:mdna:53]
Our total revenue is comprised of the following:

[0001327567-14-000028:mdna:54]
| • | Product Revenue. The substantial majority of our product revenue is derived from sales of our appliances. Product revenue also includes revenue derived from software licenses of Panorama, Virtual Systems Upgrades, and the VM-Series. We recognize product revenue at the time of shipment, provided that all other revenue recognition criteria have been met. As a percentage of total revenue, we expect our product revenue to vary from quarter to quarter based on seasonal and cyclical factors. |

[0001327567-14-000028:mdna:55]
| • | Services Revenue. Services revenue is derived primarily from Threat Prevention, URL Filtering, GlobalProtect, and WildFire subscriptions and support and maintenance. We expect to release our Advanced Endpoint Protection in fiscal 2015. We anticipate revenue from our Advanced Endpoint Protection will begin ramping in the second half of fiscal 2015 with a more meaningful revenue contribution in fiscal 2016. Threat Prevention, URL Filtering, GlobalProtect, and WildFire subscriptions are priced as a percentage of the appliance’s list price. Our contractual subscription and support and maintenance terms are typically one to five years. We recognize revenue from subscriptions and support and maintenance over the contractual service period. As a percentage of total revenue, we expect our services revenue to vary from quarter to quarter and increase over the long term as we introduce new subscriptions, renew existing services contracts, and expand our installed end-customer base. |

[0001327567-14-000028:mdna:56]
Cost of Revenue

[0001327567-14-000028:mdna:57]
Our total cost of revenue consists of cost of product revenue and cost of services revenue. Our cost of revenue includes costs paid to our third-party contract manufacturer and personnel costs, which consist of salaries, bonuses, and share-based compensation associated with our operations and global customer support organizations. Our cost of revenue also includes allocated costs, which consist of certain facilities, depreciation, benefits, recruiting, and information technology costs that we allocate based on headcount, and amortization of intangible assets.

[0001327567-14-000028:mdna:58]
| • | Cost of Product Revenue. Cost of product revenue primarily includes costs paid to our third-party contract manufacturer. Our cost of product revenue also includes amortization of intellectual property licenses, product testing costs, allocated costs, warranty costs, shipping costs, and personnel costs associated with logistics and quality control. We expect our cost of product revenue to increase as our product revenue increases. |

[0001327567-14-000028:mdna:59]
| • | Cost of Services Revenue. Cost of services revenue includes personnel costs for our global customer support organization, amortization of intangible assets acquired, allocated costs, and URL filtering database service fees. We expect our cost of services revenue to increase as our installed end-customer base grows. |

[0001327567-14-000028:mdna:60]
Gross Margin

[0001327567-14-000028:mdna:61]
Gross margin, or gross profit as a percentage of revenue, has been and will continue to be affected by a variety of factors, including the average sales price of our products, manufacturing costs, the mix of products sold, and the mix of revenue between products and services. For sales of our products, our higher throughput firewall products generally have higher gross margins than our lower throughput firewall products within each product series. For sales of our services, our subscriptions typically have higher gross margins than our support and maintenance. We expect our gross margins to fluctuate over time depending on the factors described above.

[0001327567-14-000028:mdna:62]
- 44 -

[0001327567-14-000028:mdna:63]
Operating Expenses

[0001327567-14-000028:mdna:64]
Our operating expenses consist of research and development, sales and marketing, general and administrative expense, and legal settlement expense. Personnel costs are the most significant component of operating expenses and consist of salaries, benefits, bonuses, share-based compensation, and with regard to sales and marketing expense, sales commissions. We expect operating expenses to increase in absolute dollars, and decrease over the long term as a percentage of revenue as we continue to scale our business. As of July 31, 2014, we expect to recognize approximately $320.8 million of share-based compensation expense over a weighted-average period of three years, excluding additional share-based compensation expense related to any future grants of share-based awards. Share-based compensation expense, net of forfeitures, is recognized on a straight-line basis over the requisite service periods of the awards.

[0001327567-14-000028:mdna:65]
| • | Research and Development. Research and development expense consists primarily of personnel costs. Research and development expense also includes prototype related expenses and allocated costs. We expect research and development expense to increase in absolute dollars as we continue to invest in our future products and services, although our research and development expense may fluctuate as a percentage of total revenue. |

[0001327567-14-000028:mdna:66]
| • | Sales and Marketing. Sales and marketing expense consists primarily of personnel costs including commission costs. We expense commission costs as incurred. Sales and marketing expense also includes costs for market development programs, promotional and other marketing costs, travel costs, professional services, and allocated costs. We continue to increase the size of our sales force and have also substantially grown our sales presence internationally. We expect sales and marketing expense to continue to increase in absolute dollars as we increase the size of our sales and marketing organizations to increase touch points with end-customers and to expand our international presence, although our sales and marketing expense may fluctuate as a percentage of total revenue. |

[0001327567-14-000028:mdna:67]
| • | General and Administrative. General and administrative expense consists of personnel costs, professional services, and certain non-recurring general expenses. General and administrative personnel include our executive, finance, human resources, legal, and IT organizations. Professional services consist primarily of legal, auditing, accounting, and other consulting costs. We expect general and administrative expense to increase in absolute dollars due to additional costs associated with accounting, compliance, insurance, and investor relations, although our general and administrative expense may fluctuate as a percentage of total revenue. |

[0001327567-14-000028:mdna:68]
| • | Legal Settlement. Legal settlement expense consists of charges related to the settlement agreement with Juniper and the Mutual Covenant Not to Sue and Release Agreement with Fortinet, Inc. (“Fortinet”). Refer to the discussion under Note 9. Legal Settlement of Notes to Consolidated Financial Statements in Part II, Item 8 of this Annual Report on Form 10-K for information related to these matters. |

[0001327567-14-000028:mdna:69]
Interest Expense

[0001327567-14-000028:mdna:70]
Interest expense consists of the amortization of the debt discount and debt issuance costs related to the Notes. We expect interest expense to increase over the term of the Notes.

[0001327567-14-000028:mdna:71]
Other Income (Expense), Net

[0001327567-14-000028:mdna:72]
Other income (expense), net consists primarily of the change in the fair value of the warrant issued to Juniper, which was classified as a liability on our consolidated balance sheets and remeasured to fair value from the date of issuance through the date of exercise with the corresponding change recorded as other expense. Other income (expense), net also includes interest income earned on our cash, cash equivalents, and investments, foreign currency re-measurement gains and losses, and foreign currency transaction gains and losses.

[0001327567-14-000028:mdna:73]
Provision for Income Taxes

[0001327567-14-000028:mdna:74]
Provision for income taxes consists primarily of income taxes in foreign jurisdictions in which we conduct business, withholding taxes, and federal and state income taxes in the United States. We maintain a full valuation allowance for domestic deferred tax assets, including net operating loss carryforwards and tax credits. We implemented our corporate structure and intercompany relationships to more closely align with the international nature of our business in the fourth quarter of fiscal 2013. Income in certain countries may be taxed at statutory tax rates that are lower than the U.S. statutory tax rate. As a result, our overall effective tax rate over the long term may be lower than the U.S. federal statutory tax rate on positive income through changes in international procurement and sales operations.

[0001327567-14-000028:mdna:75]
Results of Operations

[0001327567-14-000028:mdna:76]
The following tables summarize our results of operations for the periods presented and as a percentage of our total revenue for those periods. The period to period comparison of results is not necessarily indicative of results for future periods.

[0001327567-14-000028:mdna:77]
- 45 -

[0001327567-14-000028:mdna:78]
|  | Year Ended July 31, |
|  | 2014 |  | 2013 |  | 2012 |
|  | (in thousands) |
| Consolidated Statements of Operations Data: |  |  |  |  |  |
| Revenue: |  |  |  |  |  |
| Product | $ | 340,143 |  |  | $ | 243,707 |  |  | $ | 174,462 |  |
| Services | 258,036 |  |  | 152,400 |  |  | 80,676 |  |
| Total revenue | 598,179 |  |  | 396,107 |  |  | 255,138 |  |
| Cost of revenue: |  |  |  |  |  |
| Product | 85,503 |  |  | 63,412 |  |  | 44,615 |  |
| Services | 74,125 |  |  | 46,344 |  |  | 25,938 |  |
| Total cost of revenue | 159,628 |  |  | 109,756 |  |  | 70,553 |  |
| Total gross profit | 438,551 |  |  | 286,351 |  |  | 184,585 |  |
| Operating expenses: |  |  |  |  |  |
| Research and development | 104,813 |  |  | 62,482 |  |  | 38,570 |  |
| Sales and marketing | 334,763 |  |  | 199,771 |  |  | 115,917 |  |
| General and administrative | 73,149 |  |  | 42,719 |  |  | 26,207 |  |
| Legal settlement | 141,173 |  |  | — |  |  | — |  |
| Total operating expenses | 653,898 |  |  | 304,972 |  |  | 180,694 |  |
| Operating income (loss) | (215,347 | ) |  | (18,621 | ) |  | 3,891 |  |
| Interest expense | (1,883 | ) |  | (74 | ) |  | (36 | ) |
| Other income (expense), net | (4,930 | ) |  | 39 |  |  | (1,056 | ) |
| Income (loss) before income taxes | (222,160 | ) |  | (18,656 | ) |  | 2,799 |  |
| Provision for income taxes | 4,292 |  |  | 10,590 |  |  | 2,062 |  |
| Net income (loss) | $ | (226,452 | ) |  | $ | (29,246 | ) |  | $ | 737 |  |

[0001327567-14-000028:mdna:79]
- 46 -

[0001327567-14-000028:mdna:80]
|  | Year Ended July 31, |
|  | 2014 |  | 2013 |  | 2012 |
|  | (as a percentage of revenue) |
| Consolidated Statements of Operations Data: |  |  |  |  |  |
| Revenue: |  |  |  |  |  |
| Product | 56.9 | % |  | 61.5 | % |  | 68.4 | % |
| Services | 43.1 | % |  | 38.5 | % |  | 31.6 | % |
| Total revenue | 100.0 | % |  | 100.0 | % |  | 100.0 | % |
| Cost of revenue: |  |  |  |  |  |
| Product | 14.3 | % |  | 16.0 | % |  | 17.5 | % |
| Services | 12.4 | % |  | 11.7 | % |  | 10.2 | % |
| Total cost of revenue | 26.7 | % |  | 27.7 | % |  | 27.7 | % |
| Total gross profit | 73.3 | % |  | 72.3 | % |  | 72.3 | % |
| Operating expenses: |  |  |  |  |  |
| Research and development | 17.5 | % |  | 15.8 | % |  | 15.1 | % |
| Sales and marketing | 56.0 | % |  | 50.4 | % |  | 45.4 | % |
| General and administrative | 12.2 | % |  | 10.8 | % |  | 10.3 | % |
| Legal settlement | 23.6 | % |  | — | % |  | — | % |
| Total operating expenses | 109.3 | % |  | 77.0 | % |  | 70.8 | % |
| Operating income (loss) | (36.0 | )% |  | (4.7 | )% |  | 1.5 | % |
| Interest expense | (0.3 | )% |  | — | % |  | — | % |
| Other income (expense), net | (0.8 | )% |  | — | % |  | (0.4 | )% |
| Income (loss) before income taxes | (37.1 | )% |  | (4.7 | )% |  | 1.1 | % |
| Provision for income taxes | 0.8 | % |  | 2.7 | % |  | 0.8 | % |
| Net income (loss) | (37.9 | )% |  | (7.4 | )% |  | 0.3 | % |

[0001327567-14-000028:mdna:81]
- 47 -

[0001327567-14-000028:mdna:82]
Comparison of Fiscal 2014 and 2013

[0001327567-14-000028:mdna:83]
Revenue

[0001327567-14-000028:mdna:84]
|  | Year Ended July 31, |  |  |  |  |
|  | 2014 |  | 2013 |  | Change |
|  | Amount |  | % ofRevenue |  | Amount |  | % ofRevenue |  | Amount |  | % |
|  | (dollars in thousands) |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 340,143 |  |  | 56.9 | % |  | $ | 243,707 |  |  | 61.5 | % |  | $ | 96,436 |  |  | 39.6 | % |
| Services |  |  |  |  |  |  |  |  |  |  |  |
| Subscription | 123,236 |  |  | 20.6 | % |  | 71,203 |  |  | 18.0 | % |  | 52,033 |  |  | 73.1 | % |
| Support and maintenance | 134,800 |  |  | 22.5 | % |  | 81,197 |  |  | 20.5 | % |  | 53,603 |  |  | 66.0 | % |
| Total services | 258,036 |  |  | 43.1 | % |  | 152,400 |  |  | 38.5 | % |  | 105,636 |  |  | 69.3 | % |
| Total revenue | $ | 598,179 |  |  | 100.0 | % |  | $ | 396,107 |  |  | 100.0 | % |  | $ | 202,072 |  |  | 51.0 | % |
| Revenue by geographic theater: |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 396,626 |  |  | 66.3 | % |  | $ | 247,616 |  |  | 62.5 | % |  | $ | 149,010 |  |  | 60.2 | % |
| EMEA | 126,915 |  |  | 21.2 | % |  | 91,496 |  |  | 23.1 | % |  | 35,419 |  |  | 38.7 | % |
| APAC | 74,638 |  |  | 12.5 | % |  | 56,995 |  |  | 14.4 | % |  | 17,643 |  |  | 31.0 | % |
| Total revenue | $ | 598,179 |  |  | 100.0 | % |  | $ | 396,107 |  |  | 100.0 | % |  | $ | 202,072 |  |  | 51.0 | % |

[0001327567-14-000028:mdna:85]
Product revenue increased $96.4 million, or 39.6%, for fiscal 2014 compared to fiscal 2013. The increase was driven by increased demand for our higher end appliances. The impact of changes in pricing on our product revenue was insignificant.

[0001327567-14-000028:mdna:86]
Services revenue increased $105.6 million, or 69.3%, for fiscal 2014 compared to fiscal 2013. The increase was driven by a 73.1% increase in our subscription revenue and a 66.0% increase in our support and maintenance revenue due to increased sales to new and existing end-customers. The relative increases in subscriptions and support and maintenance revenue will fluctuate over time, depending on the mix of services revenue and the introduction of new subscription offerings. The impact of changes in pricing on our services revenue was insignificant.

[0001327567-14-000028:mdna:87]
With respect to geographic theaters, the Americas contributed the largest portion of the increase in revenue for fiscal 2014 compared to fiscal 2013 due to its larger and more established sales force compared to our other theaters. Revenue from both Europe, the Middle East, and Africa (EMEA) and Asia Pacific and Japan (APAC) increased during fiscal 2014 compared to fiscal 2013 due to our investment in increasing the size of our sales force and number of channel partners in these theaters.

[0001327567-14-000028:mdna:88]
Cost of Revenue and Gross Margin

[0001327567-14-000028:mdna:89]
|  | Year Ended July 31, |  |  |  |  |
|  | 2014 |  | 2013 |  | Change |
|  | Amount |  | GrossMargin |  | Amount |  | GrossMargin |  | Amount |  | GrossMargin |
|  | (dollars in thousands) |
| Cost of revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 85,503 |  |  |  |  | $ | 63,412 |  |  |  |  | $ | 22,091 |  |  |  |
| Services | 74,125 |  |  |  |  | 46,344 |  |  |  |  | 27,781 |  |  |  |
| Total cost of revenue | $ | 159,628 |  |  |  |  | $ | 109,756 |  |  |  |  | $ | 49,872 |  |  |  |
| Gross profit: |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 254,640 |  |  | 74.9 | % |  | $ | 180,295 |  |  | 74.0 | % |  | $ | 74,345 |  |  | 0.9 | % |
| Services | 183,911 |  |  | 71.3 | % |  | 106,056 |  |  | 69.6 | % |  | 77,855 |  |  | 1.7 | % |
| Total gross profit | $ | 438,551 |  |  | 73.3 | % |  | $ | 286,351 |  |  | 72.3 | % |  | $ | 152,200 |  |  | 1.0 | % |

[0001327567-14-000028:mdna:90]
- 48 -

[0001327567-14-000028:mdna:91]
Product cost increased $22.1 million, or 34.8%, for fiscal 2014 compared to fiscal 2013 due to an increase in product unit volume. Product cost for fiscal 2014 includes $2.0 million of amortization related to Juniper intellectual property licenses.

[0001327567-14-000028:mdna:92]
Service cost increased $27.8 million, or 59.9%, for fiscal 2014 compared to fiscal 2013 due to an increase in personnel costs of $14.8 million related to increasing our headcount, allocated costs of $5.5 million, professional services costs of $2.1 million, amortization of acquired intangible assets of $1.6 million, and other costs incurred to expand our customer service capabilities to support our growing installed end-customer base.

[0001327567-14-000028:mdna:93]
Gross margin increased 100 basis points for fiscal 2014 compared to fiscal 2013. The increase of 90 basis points in product margin was due to continued focus on material cost reductions, partially offset by $2.0 million of amortization related to Juniper intellectual property licenses. The increase of 170 basis points in services margin was due to contributions from our higher margin subscription services.

[0001327567-14-000028:mdna:94]
Operating Expenses

[0001327567-14-000028:mdna:95]
|  | Year Ended July 31, |  |  |  |  |
|  | 2014 |  | 2013 |  | Change |
|  | Amount |  | % ofRevenue |  | Amount |  | % ofRevenue |  | Amount |  | % |
|  | (dollars in thousands) |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | $ | 104,813 |  |  | 17.5 | % |  | $ | 62,482 |  |  | 15.8 | % |  | $ | 42,331 |  |  | 67.7 | % |
| Sales and marketing | 334,763 |  |  | 56.0 | % |  | 199,771 |  |  | 50.4 | % |  | 134,992 |  |  | 67.6 | % |
| General and administrative | 73,149 |  |  | 12.2 | % |  | 42,719 |  |  | 10.8 | % |  | 30,430 |  |  | 71.2 | % |
| Legal settlement | 141,173 |  |  | 23.6 | % |  | — |  |  | — | % |  | 141,173 |  |  | N/A |  |
| Total operating expenses | $ | 653,898 |  |  | 109.3 | % |  | $ | 304,972 |  |  | 77.0 | % |  | $ | 348,926 |  |  | 114.4 | % |
| Includes share-based compensation of: |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | $ | 29,524 |  |  |  |  | $ | 9,931 |  |  |  |  | $ | 19,593 |  |  | 197.3 | % |
| Sales and marketing | 42,647 |  |  |  |  | 20,493 |  |  |  |  | 22,154 |  |  | 108.1 | % |
| General and administrative | 16,668 |  |  |  |  | 9,101 |  |  |  |  | 7,567 |  |  | 83.1 | % |
| Total | $ | 88,839 |  |  |  |  | $ | 39,525 |  |  |  |  | $ | 49,314 |  |  | 124.8 | % |

[0001327567-14-000028:mdna:96]
Research and development expense increased $42.3 million, or 67.7%, for fiscal 2014 compared to fiscal 2013 due to an increase in personnel costs of $31.4 million largely due to an increase in headcount, an increase in allocated costs of $6.4 million, and an increase in development costs of $2.5 million to support continued investment in our future product and service offerings.

[0001327567-14-000028:mdna:97]
Sales and marketing expense increased $135.0 million, or 67.6%, for fiscal 2014 compared to fiscal 2013 due to an increase in personnel costs of $94.6 million largely due to an increase in sales commissions and headcount, an increase in allocated costs of $13.9 million, an increase in travel and entertainment costs of $8.9 million, an increase in professional services costs of $7.6 million, and an increase in demand generation activities, trade shows, and other marketing activities of $6.1 million.

[0001327567-14-000028:mdna:98]
General and administrative expense increased $30.4 million, or 71.2%, for fiscal 2014 compared to fiscal 2013 due to an increase in professional services costs of $12.5 million, including expenses related to the intellectual property litigation with Juniper of $7.7 million and expenses related to our acquisitions of Cyvera and Morta of $4.4 million, an increase in personnel costs of $12.3 million, largely due to an increase in headcount, and an increase of allocated costs of $2.4 million.

[0001327567-14-000028:mdna:99]
Legal settlement expense increased $141.2 million for fiscal 2014 compared to fiscal 2013 due to the recognition of an expense of $121.2 million and $20.0 million for the settlement agreement with Juniper and the Mutual Covenant Not to Sue and Release Agreement with Fortinet, respectively.

[0001327567-14-000028:mdna:100]
- 49 -

[0001327567-14-000028:mdna:101]
Interest Expense

[0001327567-14-000028:mdna:102]
|  | Year Ended July 31, |  |  |  |  |
|  | 2014 |  | 2013 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in thousands) |
| Interest expense | $ | 1,883 |  |  | $ | 74 |  |  | $ | 1,809 |  |  | 2,444.6 | % |

[0001327567-14-000028:mdna:103]
Interest expense increased $1.8 million for fiscal 2014 compared to fiscal 2013 due to the amortization of debt discount and debt issuance costs related to the Notes. Interest expense related to the amortization of debt discount and debt issuance costs will range from $22.3 million to $25.7 million per year over the next five fiscal years.

[0001327567-14-000028:mdna:104]
Other Income (Expense), Net

[0001327567-14-000028:mdna:105]
|  | Year Ended July 31, |  |  |  |  |
|  | 2014 |  | 2013 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in thousands) |
| Other income (expense), net | $ | (4,930 | ) |  | $ | 39 |  |  | $ | (4,969 | ) |  | NM |

[0001327567-14-000028:mdna:106]
Other income (expense), net decreased $5.0 million for fiscal 2014 compared to fiscal 2013 due to an expense of $5.9 million to record the change in the fair value of the warrant issued to Juniper from June 3, 2014, the issuance date of the warrant, through July 1, 2014, the date the warrant was exercised, partially offset by foreign currency remeasurement gains and an increase in interest income.

[0001327567-14-000028:mdna:107]
Provision for Income Taxes

[0001327567-14-000028:mdna:108]
|  | Year Ended July 31, |  |  |  |  |
|  | 2014 |  | 2013 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in thousands) |
| Provision for income taxes | $ | 4,292 |  |  | $ | 10,590 |  |  | $ | (6,298 | ) |  | (59.5 | )% |
| Effective tax rate | (1.9 | )% |  | (56.8 | )% |  |  |  |  |

[0001327567-14-000028:mdna:109]
We recorded an income tax provision for fiscal 2014 due to foreign income taxes and foreign withholding taxes. The provision for income taxes decreased $6.3 million for fiscal 2014 compared to fiscal 2013 due to decreased U.S. taxable income, primarily attributable to the legal settlement with Juniper and the Mutual Covenant Not to Sue and Release Agreement with Fortinet.

[0001327567-14-000028:mdna:110]
- 50 -

[0001327567-14-000028:mdna:111]
Comparison of Fiscal 2013 and 2012

[0001327567-14-000028:mdna:112]
Revenue

[0001327567-14-000028:mdna:113]
|  | Year Ended July 31, |  |  |  |  |
|  | 2013 |  | 2012 |  | Change |
|  | Amount |  | % ofRevenue |  | Amount |  | % ofRevenue |  | Amount |  | % |
|  | (dollars in thousands) |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 243,707 |  |  | 61.5 | % |  | $ | 174,462 |  |  | 68.4 | % |  | $ | 69,245 |  |  | 39.7 | % |
| Services |  |  |  |  |  |  |  |  |  |  |  |
| Subscription | 71,203 |  |  | 18.0 | % |  | 38,698 |  |  | 15.2 | % |  | 32,505 |  |  | 84.0 | % |
| Support and maintenance | 81,197 |  |  | 20.5 | % |  | 41,978 |  |  | 16.4 | % |  | 39,219 |  |  | 93.4 | % |
| Total services | 152,400 |  |  | 38.5 | % |  | 80,676 |  |  | 31.6 | % |  | 71,724 |  |  | 88.9 | % |
| Total revenue | $ | 396,107 |  |  | 100.0 | % |  | $ | 255,138 |  |  | 100.0 | % |  | $ | 140,969 |  |  | 55.3 | % |
| Revenue by geographic theater: |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 247,616 |  |  | 62.5 | % |  | $ | 161,873 |  |  | 63.4 | % |  | $ | 85,743 |  |  | 53.0 | % |
| EMEA | 91,496 |  |  | 23.1 | % |  | 61,994 |  |  | 24.3 | % |  | 29,502 |  |  | 47.6 | % |
| APAC | 56,995 |  |  | 14.4 | % |  | 31,271 |  |  | 12.3 | % |  | 25,724 |  |  | 82.3 | % |
| Total revenue | $ | 396,107 |  |  | 100.0 | % |  | $ | 255,138 |  |  | 100.0 | % |  | $ | 140,969 |  |  | 55.3 | % |

[0001327567-14-000028:mdna:114]
Product revenue increased $69.2 million, or 39.7%, for fiscal 2013 compared to fiscal 2012. Approximately two-thirds of the increase was driven by our newly introduced PA-3000 Series firewalls and M-100 management appliance. The remaining increase was driven by a greater than 50% increase in product unit volume attributable to sales of our PA-5000 Series and PA-200 firewalls.

[0001327567-14-000028:mdna:115]
Service revenue increased $71.7 million, or 88.9%, for fiscal 2013 compared to fiscal 2012. Approximately half of the increase was related to support and maintenance as a result of an increase in total end-customers to more than 13,500 at July 31, 2013 from more than 9,000 at July 31, 2012. The remaining increase was due to an increase in subscriptions from new and existing end-customers.

[0001327567-14-000028:mdna:116]
With respect to geographic theaters, the Americas contributed the largest portion of the increase in revenue for fiscal 2013 compared to fiscal 2012 due to its larger and more established sales force compared to our other theaters. Revenue from both EMEA and APAC increased during fiscal 2013 compared to fiscal 2012 due to our investment in increasing the size of our sales force and number of channel partners in these theaters.

[0001327567-14-000028:mdna:117]
Cost of Revenue and Gross Margin

[0001327567-14-000028:mdna:118]
|  | Year Ended July 31, |  |  |  |  |
|  | 2013 |  | 2012 |  | Change |
|  | Amount |  | GrossMargin |  | Amount |  | GrossMargin |  | Amount |  | GrossMargin |
|  | (dollars in thousands) |
| Cost of revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 63,412 |  |  |  |  | $ | 44,615 |  |  |  |  | $ | 18,797 |  |  |  |
| Services | 46,344 |  |  |  |  | 25,938 |  |  |  |  | 20,406 |  |  |  |
| Total cost of revenue | $ | 109,756 |  |  |  |  | $ | 70,553 |  |  |  |  | $ | 39,203 |  |  |  |
| Gross profit: |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 180,295 |  |  | 74.0 | % |  | $ | 129,847 |  |  | 74.4 | % |  | $ | 50,448 |  |  | (0.4 | )% |
| Services | 106,056 |  |  | 69.6 | % |  | 54,738 |  |  | 67.8 | % |  | 51,318 |  |  | 1.8 | % |
| Total gross profit | $ | 286,351 |  |  | 72.3 | % |  | $ | 184,585 |  |  | 72.3 | % |  | $ | 101,766 |  |  | — | % |

[0001327567-14-000028:mdna:119]
- 51 -

[0001327567-14-000028:mdna:120]
Product cost increased $18.8 million, or 42.1%, for fiscal 2013 compared to fiscal 2012 due to an increase in product unit volume, including sales of our newly introduced PA-3000 Series firewalls and M-100 management appliance.

[0001327567-14-000028:mdna:121]
Service cost increased $20.4 million, or 78.7%, for fiscal 2013 compared to fiscal 2012 due to an increase in personnel costs of $9.5 million, including share-based compensation of $2.9 million. The remaining increase was attributable to other costs incurred to expand our customer service capabilities to support our growing installed end-customer base.

[0001327567-14-000028:mdna:122]
Gross margin for fiscal 2013 remained consistent with fiscal 2012. The decrease of 40 basis points in product margin was due to an 80 basis point decrease as a result of the introduction of our PA-3000 Series firewalls, WF-500 appliance and our M-100 management appliance, which will have lower product margins until volume and related cost savings increase, partially offset by decreases in manufacturing costs for other appliances. The increase of 180 basis points in services margin was due to an increase in subscription, support and maintenance without a proportionate increase in our global customer service organization costs. The mix in services revenue was largely unchanged on a period over period basis.

[0001327567-14-000028:mdna:123]
Operating Expenses

[0001327567-14-000028:mdna:124]
|  | Year Ended July 31, |  |  |  |  |
|  | 2013 |  | 2012 |  | Change |
|  | Amount |  | % ofRevenue |  | Amount |  | % ofRevenue |  | Amount |  | % |
|  | (dollars in thousands) |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | $ | 62,482 |  |  | 15.8 | % |  | $ | 38,570 |  |  | 15.1 | % |  | $ | 23,912 |  |  | 62.0 | % |
| Sales and marketing | 199,771 |  |  | 50.4 | % |  | 115,917 |  |  | 45.4 | % |  | 83,854 |  |  | 72.3 | % |
| General and administrative | 42,719 |  |  | 10.8 | % |  | 26,207 |  |  | 10.3 | % |  | 16,512 |  |  | 63.0 | % |
| Total operating expenses | $ | 304,972 |  |  | 77.0 | % |  | $ | 180,694 |  |  | 70.8 | % |  | $ | 124,278 |  |  | 68.8 | % |
| Includes share-based compensation of: |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | $ | 9,931 |  |  |  |  | $ | 3,733 |  |  |  |  | $ | 6,198 |  |  | 166.0 | % |
| Sales and marketing | 20,493 |  |  |  |  | 4,267 |  |  |  |  | 16,226 |  |  | 380.3 | % |
| General and administrative | 9,101 |  |  |  |  | 5,151 |  |  |  |  | 3,950 |  |  | 76.7 | % |
| Total | $ | 39,525 |  |  |  |  | $ | 13,151 |  |  |  |  | $ | 26,374 |  |  | 200.5 | % |

[0001327567-14-000028:mdna:125]
Research and development expense increased $23.9 million, or 62.0%, for fiscal 2013 compared to fiscal 2012 due to an increase in personnel costs of $16.1 million related to increasing our headcount and share-based compensation, an increase in allocated costs of $3.7 million, and an increase in development costs of $2.8 million to support continued investment in our future product and service offerings.

[0001327567-14-000028:mdna:126]
Sales and marketing expense increased $83.9 million, or 72.3%, for fiscal 2013 compared to fiscal 2012 due to an increase in personnel costs of $58.0 million largely due to an increase in headcount, share-based compensation, and commission costs, an increase in allocated costs of $10.7 million, and an increase in marketing activity of $5.6 million related to demand generation activities, trade shows, and other marketing activities. The remaining increase was due to an increase in travel and entertainment costs of $5.6 million, professional service costs of $2.0 million, and office equipment and software costs of $1.9 million in support of our sales efforts.

[0001327567-14-000028:mdna:127]
General and administrative expense increased $16.5 million, or 63.0%, for fiscal 2013 compared to fiscal 2012 due to an increase in professional services costs of $6.9 million, including expenses related to IP litigation with Juniper of $3.6 million. The remaining increase was due to an increase in personnel costs of $6.6 million, and an increase in allocated costs of $2.3 million related to overall growth to support the business and building our infrastructure to meet the regulatory requirements of being a public company.

[0001327567-14-000028:mdna:128]
- 52 -

[0001327567-14-000028:mdna:129]
Other Income (Expense), Net

[0001327567-14-000028:mdna:130]
|  | Year Ended July 31, |  |  |  |  |
|  | 2013 |  | 2012 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in thousands) |
| Other income (expense), net | $ | 39 |  |  | $ | (1,056 | ) |  | $ | 1,095 |  |  | NM |

[0001327567-14-000028:mdna:131]
Other income (expense), net consisted primarily of foreign currency remeasurement losses for fiscal 2013 and the change in fair value of our preferred stock warrant liability for fiscal 2012. The increase in other income (expense), net was due to the elimination of the expense related to our preferred stock warrant liability as a result of exercise of these warrants by the holders in December 2011 and January 2012, partially offset by an increase in foreign currency remeasurement loss.

[0001327567-14-000028:mdna:132]
Provision for Income Taxes

[0001327567-14-000028:mdna:133]
|  | Year Ended July 31, |  |  |  |  |
|  | 2013 |  | 2012 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in thousands) |
| Provision for income taxes | $ | 10,590 |  |  | $ | 2,062 |  |  | $ | 8,528 |  |  | 413.6 | % |
| Effective tax rate | (56.8 | )% |  | 73.7 | % |  |  |  |  |

[0001327567-14-000028:mdna:134]
We recorded an income tax provision for fiscal 2013 due to U.S. federal income taxes, state income taxes, foreign income taxes, and foreign withholding taxes. We have a valuation allowance for our domestic deferred tax assets. The provision for income taxes increased for fiscal 2013 compared to fiscal 2012 due to a significant increase in domestic taxable income after full utilization of federal net operating loss carryforwards. In addition, our global operations and foreign presence expanded year over year giving rise to additional foreign income taxes and foreign withholding taxes.

[0001327567-14-000028:mdna:135]
Liquidity and Capital Resources

[0001327567-14-000028:mdna:136]
|  | July 31, |
|  | 2014 |  | 2013 |
|  | (in thousands) |
| Working capital | $ | 610,155 |  |  | $ | 323,597 |  |
| Cash, cash equivalents, and investments: |  |  |  |
| Cash and cash equivalents | $ | 653,812 |  |  | $ | 310,614 |  |
| Investments | 320,570 |  |  | 126,321 |  |
| Total cash, cash equivalents, and investments | $ | 974,382 |  |  | $ | 436,935 |  |

[0001327567-14-000028:mdna:137]
At July 31, 2014, our cash and cash equivalents and investments of $974.4 million were held for working capital purposes, of which approximately $101.5 million was held outside the United States. Our current plans do not include repatriating these funds. However, if these funds were needed for our domestic operations, we would be required to accrue and pay U.S. taxes on undistributed earnings of foreign subsidiaries. There are no other restrictions on the use of these funds. We do not provide for federal income taxes on the undistributed earnings of our foreign subsidiaries, all of which we expect to reinvest outside of the United States indefinitely. If we were to repatriate these earnings to the United States, any associated income tax liability would be insignificant.

[0001327567-14-000028:mdna:138]
In June 2014, we issued the Notes with an aggregate principal amount of $575.0 million. The Notes will mature on July 1, 2019. Prior to January 1, 2019, holders may surrender their Notes for early conversion under certain circumstances. Refer to Note 7. Convertible Senior Notes of Notes to Consolidated Financial Statements included in Part II, Item 8 of this Annual Report on Form 10-K for information on the specific circumstances. Upon conversion of the Notes, we will pay cash up to the aggregate principal amount of the Notes to be converted and we may choose to pay or deliver, as the case may be, cash, shares of our common stock or a combination of cash and shares of our common stock with respect to the remainder of our conversion obligation in excess of the aggregate principal amount of the Notes being converted. As of July 31, 2014, the Notes were not convertible.

[0001327567-14-000028:mdna:139]
- 53 -

[0001327567-14-000028:mdna:140]
The net proceeds from the offering, after deducting fees and offering expenses of $15.4 million, were approximately $559.6 million. In connection with the offering of the Notes, we entered into convertible note hedge transactions whereby we have the option to purchase up to 5.2 million shares of our common stock at a price of approximately $110.28 per share. In addition, concurrent with entering into the convertible note hedge transactions, we entered into separate warrant transactions whereby we sold warrants to acquire approximately 5.2 million shares of our common stock at an initial strike price of approximately $137.85 per share. We used approximately $32.7 million of the net proceeds from the offering to pay the cost of the convertible note hedge transactions (after such cost was partially offset by the proceeds from the warrant transactions). The remaining net proceeds will be used for general corporate purposes, including working capital, capital expenditures, potential acquisitions, and strategic transactions.

[0001327567-14-000028:mdna:141]
The following table summarizes cash flows for the years ended July 31, 2014, 2013, and 2012.

[0001327567-14-000028:mdna:142]
|  | Year Ended July 31, |
| 2014 |  | 2013 |  | 2012 |
|  | (in thousands) |
| Cash provided by operating activities | $ | 88,406 |  |  | $ | 114,519 |  |  | $ | 77,368 |  |
| Cash used in investing activities | (320,348 | ) |  | (151,565 | ) |  | (14,565 | ) |
| Cash provided by financing activities | 575,140 |  |  | 25,018 |  |  | 219,322 |  |
| Net increase (decrease) in cash and cash equivalents | $ | 343,198 |  |  | $ | (12,028 | ) |  | $ | 282,125 |  |

[0001327567-14-000028:mdna:143]
We believe that our cash flow from operations with existing cash and cash equivalents will be sufficient to meet our anticipated cash needs for the foreseeable future. Our future capital requirements will depend on many factors including our growth rate, the timing and extent of spending to support development efforts, the expansion of sales and marketing activities, the introduction of new and enhanced products and services offerings, the costs to acquire or invest in complementary businesses and technologies, the costs to ensure access to adequate manufacturing capacity, and the continuing market acceptance of our products. In addition, we may be required to pay additional taxes related to the acquisition of Cyvera if we transfer the acquired intellectual property out of Israel. We may also choose to seek additional equity or debt financing. In the event that additional financing is required from outside sources, we may not be able to raise it on terms acceptable to us or at all. If we are unable to raise additional capital when desired, our business, operating results, and financial condition may be adversely affected.

[0001327567-14-000028:mdna:144]
Operating Activities

[0001327567-14-000028:mdna:145]
Our operating activities have consisted of net loss adjusted for certain non-cash items and changes in assets and liabilities. Cash provided by operating activities for fiscal 2014, 2013, and 2012 was $88.4 million, $114.5 million, and $77.4 million, respectively.

[0001327567-14-000028:mdna:146]
Cash provided by operating activities in fiscal 2014 was $88.4 million, a decrease of $26.1 million compared to fiscal 2013 due to payments of $75.0 million and $20.0 million in fiscal 2014 for the legal settlement with Juniper and the Mutual Covenant Not to Sue and Release Agreement with Fortinet, respectively. The decrease was partially offset by an increase in sales of subscriptions and support and maintenance contracts to new and existing customers as reflected by an increase in deferred revenue.

[0001327567-14-000028:mdna:147]
Cash provided by operating activities in fiscal 2013 was $114.5 million, an increase of $37.2 million compared to fiscal 2012 due to changes in our assets and liabilities, partially offset by an increase in our net loss in fiscal 2013. Our net loss for fiscal 2013 increased due to an increase in share-based compensation expense. Changes in assets and liabilities in fiscal 2013 compared to fiscal 2012 include an increase in sales of subscriptions and support and maintenance contracts to new and existing customers as reflected by an increase in deferred revenue.

[0001327567-14-000028:mdna:148]
Investing Activities

[0001327567-14-000028:mdna:149]
Our investing activities have consisted of capital expenditures and net investment purchases, sales, and maturities. We expect to continue such activities as our business grows.

[0001327567-14-000028:mdna:150]
Cash used in investing activities during fiscal 2014 was $320.3 million, an increase of $168.8 million as compared to fiscal 2013. The increase was due to net cash payments of $85.7 million for business acquisitions, an increase of $69.4 million in net purchases of available-for-sale investments, and an increase of $13.7 million in purchases of property, equipment, and other assets.

[0001327567-14-000028:mdna:151]
Cash used in investing activities during fiscal 2013 was $151.6 million, an increase of $137.0 million as compared to fiscal 2012. The increase was primarily due to net purchases of short-term and long-term investments of $129.1 million and an increase of $7.9 million in purchases of property, equipment, and other assets.

[0001327567-14-000028:mdna:152]
- 54 -

[0001327567-14-000028:mdna:153]
Financing Activities

[0001327567-14-000028:mdna:154]
Our financing activities have consisted of proceeds from the issuance of the Notes, proceeds from sale of our common stock in our initial public offering, and proceeds from the exercises of stock options and the employee stock purchase plan.

[0001327567-14-000028:mdna:155]
Cash provided by financing activities during fiscal 2014 was $575.1 million, an increase of $550.1 million as compared to fiscal 2013. The increase was due to net proceeds from the issuance of the Notes of $527.7 million. The remaining increase was due to higher proceeds from the sale of shares through employee equity incentive plans during fiscal 2014 and the last payments of our initial public offering costs in fiscal 2013.

[0001327567-14-000028:mdna:156]
Cash provided by financing activities during fiscal 2013 was $25.0 million, a decrease of $194.3 million as compared to fiscal 2012. The decrease was due to proceeds of $215.4 million from our initial public offering during fiscal 2012. The decrease was partially offset by higher proceeds from exercise of stock options and employee stock purchase plan during fiscal 2013.

[0001327567-14-000028:mdna:157]
Contractual Obligations and Commitments

[0001327567-14-000028:mdna:158]
The following summarizes our contractual obligations and commitments as of July 31, 2014:

[0001327567-14-000028:mdna:159]
|  | Payments Due by Period |
|  | Total |  | Less Than 1 Year |  | 1 - 3 Years |  | 3- 5 Years |  | More Than 5 Years |
|  |  |  | (in thousands) |  |  |
| 0.0% convertible senior notes due 2019 | $ | 575,000 |  |  | $ | — |  |  | $ | — |  |  | $ | 575,000 |  |  | $ | — |  |
| Operating lease obligations(1) (2) | 105,710 |  |  | 14,170 |  |  | 27,466 |  |  | 21,471 |  |  | 42,603 |  |
| Purchase obligations(3) | 29,895 |  |  | 29,895 |  |  | — |  |  | — |  |  | — |  |
| Total(4) | $ | 710,605 |  |  | $ | 44,065 |  |  | $ | 27,466 |  |  | $ | 596,471 |  |  | $ | 42,603 |  |

[0001327567-14-000028:mdna:160]
______________

[0001327567-14-000028:mdna:161]
| (1) | Consists of contractual obligations from non-cancelable office space under operating leases. |

[0001327567-14-000028:mdna:162]
| (2) | Excludes proceeds from contractual sublease of $10.7 million, which consists of $2.6 million to be received in less than one year, $6.0 million to be received in one to three years, $2.1 million to be received in three to five years, and nil to be received in more than five years. |

[0001327567-14-000028:mdna:163]
| (3) | Consists of minimum purchase commitments of products and components with our independent contract manufacturer and original design manufacturers. Obligations under contracts that we can cancel without a significant penalty are not included in the table above. |

[0001327567-14-000028:mdna:164]
| (4) | No amounts related to Financial Accounting Standards Board (FASB) Accounting Standard Codification Topic 740-10, Income Taxes, are included. As of July 31, 2014, we had approximately $4.5 million of tax liabilities recorded related to uncertainty in income tax positions. |

[0001327567-14-000028:mdna:165]
Off-Balance Sheet Arrangements

[0001327567-14-000028:mdna:166]
Through July 31, 2014, we did not have any relationships with unconsolidated organizations or financial partnerships, such as structured finance or special purpose entities, that would have been established for the purpose of facilitating off-balance sheet arrangements or other contractually narrow or limited purposes.

[0001327567-14-000028:mdna:167]
Critical Accounting Policies and Estimates

[0001327567-14-000028:mdna:168]
Our consolidated financial statements have been prepared in accordance with U.S. generally accepted accounting principles. The preparation of these consolidated financial statements requires us to make estimates and assumptions that affect the reported amounts of assets, liabilities, revenue, expenses, and related disclosures. We base our estimates on historical experience and on various other assumptions that we believe are reasonable under the circumstances. We evaluate our estimates and assumptions on an ongoing basis. Actual results may differ from these estimates. To the extent that there are material differences between these estimates and our actual results, our future financial statements will be affected.

[0001327567-14-000028:mdna:169]
The critical accounting policies requiring estimates, assumptions, and judgments that we believe have the most significant impact on our consolidated financial statements are described below.

[0001327567-14-000028:mdna:170]
Revenue Recognition

[0001327567-14-000028:mdna:171]
- 55 -

[0001327567-14-000028:mdna:172]
We generate revenue from the sales of hardware and software products, subscriptions, support and maintenance, and other services primarily through a direct sales force and indirect relationships with channel partners, and, to a lesser extent, directly to end-customers.

[0001327567-14-000028:mdna:173]
Revenue is recognized when all of the following criteria are met:

[0001327567-14-000028:mdna:174]
| • | Persuasive Evidence of an Arrangement Exists. We rely upon non-cancelable sales agreements and purchase orders to determine the existence of an arrangement. |

[0001327567-14-000028:mdna:175]
| • | Delivery has Occurred. We use shipping documents or transmissions of product or service contract registration codes to determine delivery. |

[0001327567-14-000028:mdna:176]
| • | The Fee is Fixed or Determinable. We assess whether the fee is fixed or determinable based on the payment terms associated with the transaction. |

[0001327567-14-000028:mdna:177]
| • | Collectability is Reasonably Assured. We assess collectability based on credit analysis and payment history. |

[0001327567-14-000028:mdna:178]
We recognize product revenue at the time of shipment provided that all other revenue recognition criteria have been met. Our partners generally receive an order from an end-customer prior to placing an order with us. In addition, payment from our partners is not contingent on the partner’s success in sales to end-customers. Our partners generally do not stock appliances and only have limited stock rotation rights and no price protection rights. When necessary, we make certain estimates and maintain allowances for sales returns and other programs based on our historical experience. These estimates involve inherent uncertainties and management’s judgment. If actual results deviate significantly from our estimates, our revenue could be adversely affected. We recognize services revenue from subscriptions and support and maintenance ratably over the contractual service period, which is typically one to five years. Other services revenue is recognized as the services are rendered and has not been significant to date.

[0001327567-14-000028:mdna:179]
Most of our arrangements, other than renewals of subscriptions and support and maintenance, are multiple-element arrangements with a combination of hardware, software, subscriptions, support and maintenance, and other services. Products and services generally qualify as separate units of accounting. Our hardware deliverables typically include proprietary operating system software, which together deliver the essential functionality of our products. For multiple-element arrangements, we allocate revenue to each unit of accounting based on an estimated selling price at the arrangement inception. The estimated selling price for each element is based upon the following hierarchy: vendor-specific objective evidence (VSOE) of selling price, if available, third-party evidence (TPE) of selling price, if VSOE of selling price is not available, or best estimate of selling price (BESP), if neither VSOE of selling price nor TPE of selling price are available. The total arrangement consideration is allocated to each separate unit of accounting using the relative estimated selling prices of each unit based on the aforementioned selling price hierarchy. We limit the amount of revenue recognized for delivered elements to an amount that is not contingent upon future delivery of additional products or services or meeting any specified performance conditions.

[0001327567-14-000028:mdna:180]
To determine the estimated selling price in multiple-element arrangements, we establish VSOE of selling price using the prices charged for a deliverable when sold separately. If VSOE of selling price cannot be established for a deliverable, we establish TPE of selling price by evaluating similar and interchangeable competitor products or services in standalone arrangements with similarly situated partners. However, as our products contain a significant element of proprietary technology and offer substantially different features and functionality from our competitors, we are unable to obtain comparable pricing of our competitors’ products with similar functionality on a standalone basis. Therefore, we have not been able to obtain reliable evidence of TPE of selling price. If neither VSOE nor TPE of selling price can be established for a deliverable, we establish BESP primarily based on historical transaction pricing. Historical transactions are segregated based on our pricing model and our go-to-market strategy, which include factors such as type of sales channel (reseller, distributor, or end-customer), the geographies in which our products and services were sold (domestic or international), offering type (products or services), and whether or not the opportunity was identified by our sales force or by our partners. In analyzing historical transaction pricing, we evaluate whether a majority of the prices charged for a product or service, as represented by a percentage of list price, fall within a reasonable range. To further support the best estimate of selling price as determined by the historical transaction pricing or when such information is unavailable, such as when there are limited sales of a new product or service, we consider the same factors we have established through our pricing model and go-to-market strategy. The determination of BESP is made through consultation with and approval by our management. In determining BESP, we rely on certain assumptions and apply significant judgment. As our business offerings evolve over time, we may be required to modify our estimated selling prices in subsequent periods, and our revenue could be adversely affected.

[0001327567-14-000028:mdna:181]
In multiple-element arrangements where software deliverables are included, revenue is allocated to each separate unit of accounting for each of the non-software deliverables and to the software deliverables as a group using the relative estimated selling prices of each of the deliverables in the arrangement based on the aforementioned estimated selling price hierarchy. The arrangement consideration allocated to the software deliverables as a group is then allocated to each software deliverable using the residual method when VSOE of fair value of the undelivered items exists. Under the residual method, the amount of revenue allocated to delivered elements equals the total arrangement consideration less the aggregate fair value of any undelivered

[0001327567-14-000028:mdna:182]
- 56 -

[0001327567-14-000028:mdna:183]
elements. In determining VSOE of fair value, we evaluate whether a substantial majority of the historical prices charged for a product or service sold on a standalone basis, as represented by a percentage of list price, fall within a reasonably narrow range. If VSOE of fair value of one or more undelivered items does not exist, revenue from the entire arrangement is deferred and recognized at the earlier of: (i) delivery of those elements or (ii) when fair value can be established unless support and maintenance is the only undelivered element, in which case, the entire arrangement fee is recognized ratably over the contractual service period.

[0001327567-14-000028:mdna:184]
Share-Based Compensation

[0001327567-14-000028:mdna:185]
Compensation expense related to share-based transactions is measured and recognized in the financial statements based on fair value. The fair value of option awards and purchases under our 2012 Equity Incentive Plan (the “2012 Plan”) and 2012 Employee Stock Purchase Plan (the “2012 ESPP”) is estimated on the grant date. The fair value of restricted stock units (RSUs) is based on the closing market price of our common stock on the date of grant. The share-based compensation expense, net of forfeitures, is recognized using a straight-line basis over the requisite service periods of the awards. We estimate a forfeiture rate to calculate the share-based compensation expense for our awards. Our forfeiture rate is based on an analysis of our actual historical forfeitures.

[0001327567-14-000028:mdna:186]
The fair value of options and shares sold through our 2012 Plan and 2012 ESPP is determined using the Black-Scholes option-pricing model. Our option-pricing model requires the input of the fair value of our common stock and subjective assumptions, including the expected term of the award, the expected volatility of the price of our common stock, risk-free interest rates, and the expected dividend yield of our common stock. The assumptions used in our option-pricing model represent management’s best estimates. These estimates involve inherent uncertainties and the application of management’s judgment. If factors change and different assumptions are used, our share-based compensation expense could be materially different in the future.

[0001327567-14-000028:mdna:187]
In addition to assumptions used in the Black-Scholes option-pricing model, we must also estimate a forfeiture rate to calculate the share-based compensation expense for our awards. Quarterly changes in the estimated forfeiture rate can have a significant impact on our share-based compensation expense as the cumulative effect of adjusting the rate is recognized in the period the forfeiture estimate is changed. If a revised forfeiture rate is higher than the previously estimated forfeiture rate, an adjustment is made that will result in a decrease to the share-based compensation expense recognized in the financial statements. If a revised forfeiture rate is lower than the previously estimated forfeiture rate, an adjustment is made that will result in an increase to the share-based compensation expense recognized in the financial statements.

[0001327567-14-000028:mdna:188]
We will continue to use judgment in evaluating the assumptions related to our share-based compensation expense on a prospective basis. As we continue to accumulate additional data, we may have refinements to our estimates, which could materially impact our future share-based compensation expense.

[0001327567-14-000028:mdna:189]
Income Taxes

[0001327567-14-000028:mdna:190]
We account for income taxes using the asset and liability method, which requires the recognition of deferred tax assets and liabilities for the expected future tax consequences of events that have been recognized in our financial statements or tax returns. In addition, deferred tax assets are recorded for the future benefit of utilizing net operating losses and research and development credit carryforwards. Valuation allowances are provided when necessary to reduce deferred tax assets to the amount expected to be realized.

[0001327567-14-000028:mdna:191]
Significant judgment is required in determining any valuation allowance recorded against deferred tax assets. In assessing the need for a valuation allowance, we consider all available evidence, including past operating results, estimates of future taxable income, and the feasibility of tax planning strategies. In the event that we change our determination as to the amount of deferred tax assets that can be realized, we will adjust our valuation allowance with a corresponding impact to the provision for income taxes in the period in which such determination is made.

[0001327567-14-000028:mdna:192]
We apply the authoritative accounting guidance prescribing a threshold and measurement attribute for the financial recognition and measurement of a tax position taken or expected to be taken in a tax return. We recognize liabilities for uncertain tax positions based on a two-step process. The first step is to evaluate the tax position for recognition by determining if the weight of available evidence indicates that it is more likely than not that the position will be sustained on audit, including resolution of related appeals or litigation processes, if any. The second step requires us to estimate and measure the tax benefit as the largest amount that is more likely than not to be realized upon ultimate settlement.

[0001327567-14-000028:mdna:193]
Significant judgment is also required in evaluating our uncertain tax positions and determining our provision for income taxes. Although we believe our reserves are reasonable, no assurance can be given that the final tax outcome of these matters will not be different from that which is reflected in our historical income tax provisions and accruals. We adjust these reserves in light of changing facts and circumstances, such as the closing of a tax audit or the refinement of an estimate. To the extent that the final

[0001327567-14-000028:mdna:194]
- 57 -

[0001327567-14-000028:mdna:195]
tax outcome of these matters is different than the amounts recorded, such differences may impact the provision for income taxes in the period in which such determination is made.

[0001327567-14-000028:mdna:196]
Contract Manufacturer Liabilities

[0001327567-14-000028:mdna:197]
We outsource most of our manufacturing, repair, and supply chain management operations to our independent contract manufacturer and payments to it are a significant portion of our product cost of revenues. We have employees in our manufacturing and operations organization who manage our relationship with our independent contract manufacturer, manage our supply chain, and monitor product testing and quality. Although we could be contractually obligated to purchase manufactured products, we generally do not own the manufactured products. Product title transfers from our independent contract manufacturer to us and immediately to our partners upon shipment. Our independent contract manufacturer assembles our products using design specifications, quality assurance programs, and standards that we establish, and it procures components and assembles our products based on our demand forecasts. These forecasts represent our estimates of future demand for our products based upon historical trends and analysis from our sales and product management functions as adjusted for overall market conditions. If the actual component usage and product demand are significantly lower than forecast, which may be caused by factors outside of our control, we accrue for costs for manufacturing commitments in excess of our forecasted demand including costs for excess components or for carrying costs incurred by our contract manufacturer, which could have an adverse impact on our gross margins and profitability. To date, we have not accrued significant costs associated with this exposure.

[0001327567-14-000028:mdna:198]
Loss Contingencies

[0001327567-14-000028:mdna:199]
We are subject to the possibility of various loss contingencies arising in the ordinary course of business. We consider the likelihood of loss or impairment of an asset, or the incurrence of a liability, as well as our ability to reasonably estimate the amount of loss, in determining loss contingencies. An estimated loss contingency is accrued when it is probable that an asset has been impaired or a liability has been incurred and the amount of loss can be reasonably estimated. If we determine that a loss is possible and the range of the loss can be reasonably determined, then we disclose the range of the possible loss. We regularly evaluate current information available to us to determine whether an accrual is required, an accrual should be adjusted or a range of possible loss should be disclosed.

[0001327567-14-000028:mdna:200]
From time to time, we are involved in disputes, litigation, and other legal actions. We are vigorously defending our current litigation matters. However, there are many uncertainties associated with any litigation, and these actions or other third-party claims against us may cause us to incur substantial settlement charges, which are inherently difficult to estimate and could adversely affect our results of operations. The actual liability in any such matters may be materially different from our estimates, which could result in the need to adjust our liability and record additional expenses. Refer to the discussion under “Commitments and Contingencies—Litigation” in Note 8. Commitments and Contingencies of Notes to Consolidated Financial Statements included in Part II, Item 8 of this Annual Report on Form 10-K for information related to pending litigation.

[0001327567-14-000028:mdna:201]
Goodwill, Intangibles, and Other Long-Lived Assets

[0001327567-14-000028:mdna:202]
We make significant estimates, assumptions, and judgments when valuing goodwill and other purchased intangible assets in connection with the initial purchase price allocation of an acquired entity, as well as when evaluating impairment of goodwill and other purchased intangible assets on an ongoing basis. These estimates are based upon a number of factors, including historical experience, market conditions, and information obtained from the management of the acquired company. Critical estimates in valuing certain intangible assets include, but are not limited to, cash flows that an asset is expected to generate in the future, discount rates, the time and expense that would be necessary to recreate the assets, and the profit margin a market participant would receive. The amounts and useful lives assigned to identified intangible assets impacts the amount and timing of future amortization expense.

[0001327567-14-000028:mdna:203]
We evaluate goodwill for impairment on an annual basis in our fourth fiscal quarter or more frequently if we believe impairment indicators exist. We first analyze qualitative factors, which include industry and market considerations, overall financial performance, and other relevant events and factors affecting the reporting unit. If qualitative factors indicate that it is more likely than not that the reporting unit’s fair value is less than its carrying amount, then we will perform the quantitative analysis required under the two-step goodwill impairment test.

[0001327567-14-000028:mdna:204]
Under the two-step goodwill impairment test, we first compare the reporting unit's carrying amount, including goodwill, to the fair value of the reporting unit. The fair value of the reporting unit is estimated using significant judgment based on a combination of the income and the market approaches. If the fair value of the reporting unit does not exceed the carrying amount of the net assets assigned to the reporting unit, then we perform the second step of the impairment test in order to determine the implied fair value of the reporting unit's goodwill. When the carrying amount of a reporting unit's goodwill exceeds its implied fair value, we record an impairment loss equal to the difference. Determining the fair value of a reporting unit is highly judgmental in nature and involves the use of significant estimates and assumptions. These estimates and assumptions include revenue growth rates and operating margins used to calculate projected future cash flows, operating trends, risk-adjusted discount rates, future

[0001327567-14-000028:mdna:205]
- 58 -

[0001327567-14-000028:mdna:206]
economic and market conditions, and determination of appropriate market comparables. We base our fair value estimates on assumptions we believe to be reasonable but that are unpredictable and inherently uncertain. Actual future results may differ from those estimates.

[0001327567-14-000028:mdna:207]
We evaluate long-lived assets, such as property, equipment, and purchased intangible assets for impairment whenever events or changes in circumstances indicate that the carrying amount of the assets may not be recoverable. Such events or changes in circumstances include, but are not limited to, a significant decrease in the fair value of the underlying asset or asset group, a significant decrease in the benefits realized from the acquired assets, difficulty and delays in integrating the business, or a significant change in the operations of the acquired assets or use of an asset. A long-lived asset is considered impaired if its carrying amount exceeds the estimated future undiscounted cash flows the asset or asset group is expected to generate. If a long-lived asset is considered to be impaired, the impairment to be recognized is the amount by which the carrying amount of the asset exceeds the fair value of the asset or asset group.

[0001327567-14-000028:mdna:208]
To date, we have not recognized any impairment losses on our goodwill, intangible assets, and long-lived assets.

[0001327567-14-000028:mdna:209]
Recent Accounting Pronouncements

[0001327567-14-000028:mdna:210]
Refer to “Recent Accounting Pronouncements” in Note 1. Description of Business and Summary of Significant Accounting Policies of Notes to Consolidated Financial Statements included in Part II, Item 8 of this Annual Report on Form 10-K.

[0001327567-14-000028:mdna:211]
- 59 -
