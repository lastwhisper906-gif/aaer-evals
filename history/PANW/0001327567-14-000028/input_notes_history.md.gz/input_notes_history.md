# PANW note change history — 0001327567-14-000005 → 0001327567-14-000013


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2014-06-03):
[0001327567-14-000013:note_history:1]
The following table presents details of the aggregate future non-cancelable minimum rental payments on our operating leases as of April 30, 2014 (in thousands):
  (was, 2014-02-24, similarity 0.9744):
[0001327567-14-000005:note_history:1]
The following table presents details of the aggregate future non-cancelable minimum rental payments on our operating leases as of January 31, 2014 (in thousands):

- changed (2014-06-03):
[0001327567-14-000013:note_history:2]
Our independent contract manufacturer procures components and assembles our products based on our forecasts. These forecasts are based on estimates of future demand for our products, which are in turn based on historical trends and an analysis from our sales and product marketing organizations, adjusted for overall market conditions. In order to reduce manufacturing lead times and plan for adequate supply, we may issue forecasts and orders for components and products that are non-cancelable. Obligations under contracts that we can cancel without a significant penalty are not included. As of April 30, 2014, we had $29,407,000 of open orders.
  (was, 2014-02-24, similarity 0.9905):
[0001327567-14-000005:note_history:2]
Our independent contract manufacturer procures components and assembles our products based on our forecasts. These forecasts are based on estimates of future demand for our products, which are in turn based on historical trends and an analysis from our sales and product marketing organizations, adjusted for overall market conditions. In order to reduce manufacturing lead times and plan for adequate supply, we may issue forecasts and orders for components and products that are non-cancelable. Obligations under contracts that we can cancel without a significant penalty are not included. As of January 31, 2014, we had $32,150,000 of open orders.

- added (2014-06-03):
[0001327567-14-000013:note_history:3]
In December 2011, Juniper Networks, Inc. ("Juniper") filed a complaint against us in the United States District Court for the District of Delaware alleging patent infringement. The complaint sought preliminary and permanent injunctions against infringement, treble damages, and attorneys' fees. On September 4, 2012, Juniper filed a motion to amend its complaint to allege that our appliances infringe two additional U.S. patents but also to withdraw its allegations as to a previously-asserted patent. This amended complaint was officially filed on September 25, 2012, pursuant to a stipulation between the parties. On October 12, 2012, we filed an answer to Juniper’s amended complaint, which denied that we infringed Juniper’s patents and asserted that Juniper’s patents were invalid. The Court issued an order on February 6, 2014, in which the Court construed several disputed claim limitations, granted Juniper’s motion for summary judgment of assignor estoppel, precluding us from raising in the litigation challenges to the validity of Juniper’s patents, denied Juniper’s motion for summary judgment of infringement, and granted in part and denied in part our motion for summary judgment of non-infringement. A trial took place in February 2014. Following the trial, the jury was unable to reach a verdict and the Court declared a mistrial.

- added (2014-06-03):
[0001327567-14-000013:note_history:4]
On September 13, 2012, we filed with the U.S. Patent and Trademark Office requests for inter partes reexamination of five of the six patents asserted by Juniper in its original complaint. On October 19 and December 3, 2012, the U.S. Patent and Trademark Office granted our requests for reexamination for three patents, rejecting a number of the claims asserted in the litigation, and on November 15 and 26, 2012, the U.S. Patent and Trademark Office denied our requests for reexamination as to two other patents. On June 20, 2013 and July 23, 2013, we filed with the U.S. Patent and Trademark Office petitions for inter partes review for two other patents asserted by Juniper in the litigation. A hearing to resolve claim construction issues, as well as motions for summary judgment, was heard on November 15, 2013.

- changed (2014-06-03):
[0001327567-14-000013:note_history:5]
On September 30, 2013, we filed a lawsuit against Juniper in the United States District Court for the Northern District of California. The lawsuit alleged that Juniper’s products infringe three of our U.S. patents, and sought monetary damages and a permanent injunction. On November 21, 2013, Juniper filed an answer and counterclaims in a separate action in the United States District Court for the Northern District of California. In its counterclaims Juniper sought a declaration that the asserted patents owned by us are not infringed and are invalid. Juniper’s counterclaims also asserted that our products infringe three additional Juniper patents.
  (was, 2014-02-24, similarity 0.6242):
[0001327567-14-000005:note_history:5]
On September 30, 2013, we filed a lawsuit against Juniper in the United States District Court for the Northern District of California. The lawsuit alleges that Juniper’s products infringe three of our U.S. patents, and seeks monetary damages and a permanent injunction. On November 21, 2013, Juniper filed an answer and counterclaims in a separate action pending in the United States District Court for the Northern District of California. In its counterclaims Juniper seeks a declaration that the asserted patents owned by us are not infringed and are invalid. Juniper’s counterclaims also assert that our products infringe three additional Juniper patents.

- added (2014-06-03):
[0001327567-14-000013:note_history:6]
On May 27, 2014, we entered into a Settlement, Release and Cross-License Agreement (the “settlement agreement”) with Juniper to resolve all pending litigation between the parties, including those discussed above. Refer to Note 12 Subsequent Events for more information on the settlement agreement.

- removed (2014-06-03):
[0001327567-14-000005:note_history:7]
In December 2011, Juniper Networks, Inc. filed a complaint against us in the United States District Court for the District of Delaware alleging patent infringement. The complaint seeks preliminary and permanent injunctions against infringement, treble damages, and attorney’s fees. On February 9, 2012, we filed a response to the complaint, which denied all claims and asserted that the claimant’s patents were invalid. On February 28, 2012, Juniper filed a motion to strike our defense of invalidity based on the legal doctrine of “assignor estoppel.” On March 23, 2012, we filed a brief in opposition to that motion. Juniper filed a brief in response on April 2, 2012. On August 2, 2012, the District Court issued an order granting Juniper’s motion as to one of the patents in suit (the ’634 patent) but denying Juniper’s motion as to the five other patents in suit. On September 4, 2012, Juniper filed a motion to amend its complaint to allege that our appliances infringe two additional U.S. patents but also to withdraw its allegations as to a previously-asserted patent. This amended complaint was officially filed on September 25, 2012, pursuant to a stipulation between the parties. Juniper now alleges that our appliances infringe seven of its patents. On September 13, 2012, we filed with the U.S. Patent and Trademark Office requests for inter partes reexamination of five of the six patents asserted by Juniper in its original complaint. We did not file a request for reexamination on the withdrawn patent. On October 12, 2012, we filed an answer to Juniper’s amended complaint, which denied that we infringed Juniper’s patents and asserted that Juniper’s patents were invalid. On October 19 and December 3, 2012, the U.S. Patent and Trademark Office granted our requests for reexamination for three patents, rejecting a number of the claims asserted in the litigation, and on November 15 and 26, 2012, the U.S. Patent and Trademark Office denied our requests for reexamination as to two other patents. We have the opportunity to seek review of these denials within the U.S. Patent and Trademark Office. Each party served its opening expert report on April 12, 2013, and rebuttal expert report on May 13, 2013, and supplemental expert reports on June 11, 2013. The parties filed opening and responsive briefs regarding claim construction, filed their opening summary judgment briefs on August 20, 2013, and filed opposition briefs and additional summary judgment motions on September 12, 2013. On June 20, 2013 and July 23, 2013, we filed with the U.S. Patent and Trademark Office petitions for inter partes review for two other patents asserted by Juniper in the litigation. The Patent and Trademark Office granted both of those petitions and instituted trials to take place in August 2014 and September 2014. A hearing to resolve claim construction issues, as well as motions for summary judgment, was heard on November 15, 2013.

- removed (2014-06-03):
[0001327567-14-000005:note_history:8]
The Court issued an order on February 6, 2014, in which the Court construed several disputed claim limitations, granted Juniper’s motion for summary judgment of assignor estoppel, denied Juniper’s motion for summary judgment of infringement, and granted in part and denied in part our motion for summary judgment of non-infringement. A trial began on February 24, 2014, and we are vigorously defending ourselves from such claims. At this stage in the litigation we do not believe that a loss is probable and we are unable to estimate a possible loss or range of possible loss.


## us-gaap:LegalMattersAndContingenciesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2014-06-03):
[0001327567-14-000013:note_history:9]
On January 27, 2014, we executed a Mutual Covenant Not to Sue and Release Agreement with Fortinet, Inc., thereby extending an existing covenant for six more years. We evaluated the transaction as a multiple-element arrangement and allocated the one-time payment that we made in the amount of $20,000,000 to each identifiable element using its relative fair value. Based on our estimates of fair value, we determined that the primary benefit of the arrangement is avoided litigation cost and the release of any potential past claims, with no material value attributable to future use or benefit. Accordingly, we recorded a $20,000,000 settlement charge within operating expenses during the three months ended January 31, 2014.
  (was, 2014-02-24, similarity 0.9315):
[0001327567-14-000005:note_history:9]
On January 27, 2014, we executed a Mutual Covenant Not to Sue and Release agreement, thereby extending an existing covenant for six more years. We evaluated the transaction as a multiple-element arrangement and allocated the one-time payment that we made in the amount of $20,000,000 to each identifiable element using its relative fair value. Based on our estimates of fair value, we determined that the primary benefit of the arrangement is avoided litigation cost and the release of any potential past claims, with no material value attributable to future use or benefit. Accordingly, we recorded a $20,000,000 expense in general and administrative expense during the three months ended January 31, 2014.

- removed (2014-06-03):
[0001327567-14-000005:note_history:10]
Mutual Covenant Not to Sue and Release Agreement


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2014-06-03):
[0001327567-14-000013:note_history:11]
Palo Alto Networks, Inc. (the “Company,” “we,” “us,” or “our”), located in Santa Clara, California, was incorporated in March 2005 under the laws of the State of Delaware and commenced operations in April 2005. We offer a next-generation enterprise security platform that allows enterprises, service providers, and government entities to simultaneously empower and secure their organization by safely enabling the increasingly complex and rapidly growing number of applications running on their networks and preventing breaches stemming from targeted cyber attacks. Our enterprise security platform consists of three major elements: our Next-Generation Firewall, our Next-Generation Endpoint Protection, and our Next-Generation Threat Intelligence Cloud. Our Next-Generation Firewall delivers application, user, and content visibility and control as well as protection against network based cyber threats integrated within the firewall through our proprietary hardware and software architecture. Our Next-Generation Endpoint Protection protects against cyber attacks that aim to exploit software vulnerabilities on a broad variety of fixed and virtual endpoints. Our Next-Generation Threat Intelligence Cloud provides central intelligence capabilities as well as automation of delivery of preventative measures against cyber attacks. We primarily sell our products and services to end-customers through our channel partners and infrequently directly to end-customers. Our partners are supported by our sales and marketing organization in the Americas, in Europe, the Middle East, and Africa (EMEA), and in Asia Pacific and Japan (APAC).

- changed (2014-06-03):
[0001327567-14-000013:note_history:12]
The accompanying condensed consolidated financial statements have been prepared in conformity with U.S. generally accepted accounting principles, consistent in all material respects with those applied in our Annual Report on Form 10-K for the fiscal year ended July 31, 2013. The condensed consolidated financial statements include all adjustments necessary for a fair presentation of our quarterly results. All adjustments are of a normal recurring nature. We have made estimates and judgments affecting the amounts reported in our condensed consolidated financial statements and the accompanying notes. The actual results that we experience may differ materially from our estimates. Certain prior period amounts have been reclassified to conform with current period presentation.
  (was, 2014-02-24, similarity 0.9331):
[0001327567-14-000005:note_history:12]
The accompanying condensed consolidated financial statements have been prepared in conformity with U.S. generally accepted accounting principles, consistent in all material respects with those applied in our Annual Report on Form 10-K for the fiscal year ended July 31, 2013. The condensed consolidated financial statements include all adjustments necessary for a fair presentation of our quarterly results. All adjustments are of a normal recurring nature. We have made estimates and judgments affecting the amounts reported in our condensed consolidated financial statements and the accompanying notes. The actual results that we experience may differ materially from our estimates.

- changed (2014-06-03):
[0001327567-14-000013:note_history:13]
The condensed consolidated financial statements include our accounts and our wholly owned subsidiaries. All significant intercompany balances and transactions have been eliminated in consolidation.
  (was, 2014-02-24, similarity 0.8753):
[0001327567-14-000005:note_history:13]
The condensed consolidated financial statements include the accounts of the Company and its wholly owned subsidiaries. All significant intercompany balances and transactions have been eliminated in consolidation.

- changed (2014-06-03):
[0001327567-14-000013:note_history:14]
There have been no material changes to our significant accounting policies as of and for the three and nine months ended April 30, 2014, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended July 31, 2013, except for the inclusion of a policy related to business combinations, amortization of intangible assets, and broadening our policy on the Impairment of Long-Lived Assets to include policies related to goodwill and intangible assets.
  (was, 2014-02-24, similarity 0.9127):
[0001327567-14-000005:note_history:14]
There have been no material changes to our significant accounting policies as of and for the three and six months ended January 31, 2014, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended July 31, 2013, except for the inclusion of a policy related to business combinations and broadening our policy on the Impairment of Long-Lived Assets to include policies related to goodwill and intangible assets.

- added (2014-06-03):
[0001327567-14-000013:note_history:15]
Amortization of Intangible Assets

- added (2014-06-03):
[0001327567-14-000013:note_history:16]
Purchased intangible assets with finite lives are carried at cost, less accumulated amortization. Amortization is computed over the estimated useful lives of the respective assets. Acquisition-related in-process research and development represents the fair value of incomplete research and development projects that have not reached technological feasibility as of the date of acquisition. Initially, these assets are not subject to amortization. Assets related to projects that have been completed are transferred to developed technology, which are subject to amortization, while assets related to projects that have been abandoned are impaired and expensed to research and development.

- changed (2014-06-03):
[0001327567-14-000013:note_history:17]
Impairment of Goodwill, Intangible Assets, and Long-Lived Assets
  (was, 2014-02-24, similarity 0.7812):
[0001327567-14-000005:note_history:17]
Goodwill, Intangible Assets, and Impairment of Long-Lived Assets

- changed (2014-06-03):
[0001327567-14-000013:note_history:18]
Goodwill is evaluated for impairment on an annual basis in the fourth quarter of our fiscal year, and whenever events or changes in circumstances indicate the carrying amount of goodwill may not be recoverable. We have elected to first assess qualitative factors to determine whether it is more likely than not that the fair value of our single reporting unit is less than its carrying amount. If we determine that it is more likely than not that the fair value of our single reporting unit is less than its carrying amount, then the two-step goodwill impairment test will be performed. The first step, identifying a potential impairment, compares the fair value of our single reporting unit with its carrying amount. If the carrying amount exceeds its fair value, the second step will be performed; otherwise, no further step is required. The second step, measuring the impairment loss, compares the implied fair value of the goodwill with the carrying amount of the goodwill. Any excess of the goodwill carrying amount over the implied fair value is recognized as an impairment loss.
  (was, 2014-02-24, similarity 0.9949):
[0001327567-14-000005:note_history:18]
Goodwill is evaluated for impairment on an annual basis in the fourth quarter of our fiscal year, and whenever events or changes in circumstances indicate the carrying value of goodwill may not be recoverable. We have elected to first assess qualitative factors to determine whether it is more likely than not that the fair value of our single reporting unit is less than its carrying amount. If we determine that it is more likely than not that the fair value of our single reporting unit is less than its carrying amount, then the two-step goodwill impairment test will be performed. The first step, identifying a potential impairment, compares the fair value of our single reporting unit with its carrying amount. If the carrying amount exceeds its fair value, the second step will be performed; otherwise, no further step is required. The second step, measuring the impairment loss, compares the implied fair value of the goodwill with the carrying amount of the goodwill. Any excess of the goodwill carrying amount over the implied fair value is recognized as an impairment loss.

- changed (2014-06-03):
[0001327567-14-000013:note_history:19]
We evaluate events and changes in circumstances that could indicate carrying amounts of purchased intangible assets and long-lived assets may not be recoverable. When such events or changes in circumstances occur, we assess the recoverability of these assets by determining whether or not the carrying amount will be recovered through undiscounted expected future cash flows. If the total of the future undiscounted cash flows is less than the carrying amount of an asset, we record an impairment loss for the amount by which the carrying amount of the asset exceeds the fair value of the asset.
  (was, 2014-02-24, similarity 0.6225):
[0001327567-14-000005:note_history:19]
We evaluate events and changes in circumstances that could indicate carrying amounts of long-lived assets, including property and equipment and purchased intangible assets subject to amortization, may not be recoverable. When such events or changes in circumstances occur, we assess the recoverability of long-lived assets by determining whether or not the carrying amount of such assets will be recovered through undiscounted expected future cash flows. If the total of the future undiscounted cash flows is less than the carrying amount of an asset, we record an impairment loss for the amount by which the carrying amount of the asset exceeds the fair value of the asset.

- changed (2014-06-03):
[0001327567-14-000013:note_history:20]
In July 2013, the FASB issued ASU No. 2013-11, Income Taxes (Topic 740)-Presentation of an Unrecognized Tax Benefit When a Net Operating Loss Carryforward, a Similar Tax Loss, or a Tax Credit Carryforward Exists. The standard requires us to present an unrecognized tax benefit as a reduction of a deferred tax asset for a net operating loss (NOL) carryforward or other tax credit carryforward when settlement in this manner is available under applicable tax law. The guidance is effective for us in the first quarter of fiscal 2015 and will be applied prospectively. Early adoption is permitted. We do not believe the adoption of this guidance will have a material impact on our condensed consolidated financial statements.
  (was, 2014-02-24, similarity 0.774):
[0001327567-14-000005:note_history:20]
In July 2013, the FASB issued ASU No. 2013-11, Income Taxes (Topic 740)-Presentation of an Unrecognized Tax Benefit When a Net Operating Loss Carryforward, a Similar Tax Loss, or a Tax Credit Carryforward Exists. The standard requires us to present an unrecognized tax benefit as a reduction of a deferred tax asset for a net operating loss (NOL) carryforward or other tax credit carryforward when settlement in this manner is available under applicable tax law. The guidance is effective for us in the first quarter of fiscal 2015. We do not believe the adoption of this guidance will have a material impact on our condensed consolidated financial statements.

- removed (2014-06-03):
[0001327567-14-000005:note_history:21]
Palo Alto Networks, Inc. (the “Company,” “we,” “us,” or “our”), located in Santa Clara, California, was incorporated in March 2005 under the laws of the State of Delaware and commenced operations in April 2005. We offer a next-generation network security platform that allows enterprises, service providers, and government entities to secure their networks and safely enable the increasingly complex and rapidly growing number of applications running on their networks. The core of our platform is our Next-Generation Firewall that delivers application, user, and content visibility and control integrated within the firewall through our proprietary operating system, hardware, and software architecture. We primarily sell our products and services to end-customers through our channel partners and infrequently directly to end-customers. Our partners are supported by our sales and marketing organization in the Americas, in Europe, the Middle East, and Africa (EMEA), and in Asia Pacific and Japan (APAC).


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2014-06-03):
[0001327567-14-000013:note_history:22]
The following tables summarize our unrealized gains and losses and fair value of investments as of April 30, 2014 and July 31, 2013 (in thousands):
  (was, 2014-02-24, similarity 0.971):
[0001327567-14-000005:note_history:22]
The following tables summarize our unrealized gains and losses and fair value of investments as of January 31, 2014 and July 31, 2013 (in thousands):

- added (2014-06-03):
[0001327567-14-000013:note_history:23]
|  | April 30, 2014 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Estimated Fair Value |
| Certificates of deposit | $ | 3,000 |  |  | $ | 1 |  |  | $ | — |  |  | $ | 3,001 |  |
| Corporate debt securities | 45,957 |  |  | 22 |  |  | (6 | ) |  | 45,973 |  |
| U.S. government and agency securities | 192,064 |  |  | 68 |  |  | (24 | ) |  | 192,108 |  |
| Total | $ | 241,021 |  |  | $ | 91 |  |  | $ | (30 | ) |  | $ | 241,082 |  |

- changed (2014-06-03):
[0001327567-14-000013:note_history:24]
The following tables present our investments that were in an unrealized loss position as of April 30, 2014 and July 31, 2013 (in thousands):
  (was, 2014-02-24, similarity 0.9695):
[0001327567-14-000005:note_history:24]
The following tables present our investments that were in an unrealized loss position as of January 31, 2014 and July 31, 2013 (in thousands):

- added (2014-06-03):
[0001327567-14-000013:note_history:25]
|  | April 30, 2014 |
|  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
|  | Fair Value |  | Unrealized Loss |  | Fair Value |  | Unrealized Loss |  | Fair Value |  | Unrealized Loss |
| Corporate debt securities | 16,766 |  |  | (6 | ) |  | — |  |  | — |  |  | 16,766 |  |  | (6 | ) |
| U.S. government and agency securities | 33,601 |  |  | (24 | ) |  | — |  |  | — |  |  | 33,601 |  |  | (24 | ) |
| Total | $ | 50,367 |  |  | $ | (30 | ) |  | $ | — |  |  | $ | — |  |  | $ | 50,367 |  |  | $ | (30 | ) |

- changed (2014-06-03):
[0001327567-14-000013:note_history:26]
Unrealized losses related to these investments are due to interest rate fluctuations as opposed to credit quality. In addition, we do not intend to sell and it is not more likely than not that we would be required to sell these investments before recovery of their amortized cost basis, which may be at maturity. As a result, there is no other-than-temporary impairment for these investments at April 30, 2014.
  (was, 2014-02-24, similarity 0.9852):
[0001327567-14-000005:note_history:26]
Unrealized losses related to these investments are due to interest rate fluctuations as opposed to credit quality. In addition, we do not intend to sell and it is not more likely than not that we would be required to sell these investments before recovery of their amortized cost basis, which may be at maturity. As a result, there is no other-than-temporary impairment for these investments at January 31, 2014.

- changed (2014-06-03):
[0001327567-14-000013:note_history:27]
The following table summarizes the amortized cost and fair value of our investments as of April 30, 2014, by contractual years-to-maturity (in thousands):
  (was, 2014-02-24, similarity 0.9732):
[0001327567-14-000005:note_history:27]
The following table summarizes the amortized cost and fair value of our investments as of January 31, 2014, by contractual years-to-maturity (in thousands):

- removed (2014-06-03):
[0001327567-14-000005:note_history:28]
|  | January 31, 2014 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Estimated Fair Value |
| Certificates of deposit | $ | 3,000 |  |  | $ | — |  |  | $ | (1 | ) |  | $ | 2,999 |  |
| Corporate debt securities | 46,419 |  |  | 23 |  |  | (8 | ) |  | 46,434 |  |
| U.S. government and agency securities | 227,988 |  |  | 35 |  |  | (6 | ) |  | 228,017 |  |
| Total | $ | 277,407 |  |  | $ | 58 |  |  | $ | (15 | ) |  | $ | 277,450 |  |

- removed (2014-06-03):
[0001327567-14-000005:note_history:29]
|  | January 31, 2014 |
|  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
|  | Fair Value |  | Unrealized Loss |  | Fair Value |  | Unrealized Loss |  | Fair Value |  | Unrealized Loss |
| Certificates of deposit | $ | 2,999 |  |  | $ | (1 | ) |  | $ | — |  |  | $ | — |  |  | $ | 2,999 |  |  | $ | (1 | ) |
| Corporate debt securities | 16,834 |  |  | (8 | ) |  | — |  |  | — |  |  | 16,834 |  |  | (8 | ) |
| U.S. government and agency securities | 29,645 |  |  | (6 | ) |  | — |  |  | — |  |  | 29,645 |  |  | (6 | ) |
| Total | $ | 49,478 |  |  | $ | (15 | ) |  | $ | — |  |  | $ | — |  |  | $ | 49,478 |  |  | $ | (15 | ) |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: no_prior_note, score: 0.0

- added (2014-06-03):
[0001327567-14-000013:note_history:30]
Related Party Transactions

- added (2014-06-03):
[0001327567-14-000013:note_history:31]
Certain members of our board of directors serve as board members or executive officers of certain of our customers and in some cases are also investors of these customers. We believe these transactions with related party customers are carried out on terms that are consistent with similar transactions with our comparable customers. We had sales transactions with significant related party customers of $1,619,000 and $3,776,000 for the three and nine months ended April 30, 2014, respectively, and $903,000 and $2,381,000 for the three and nine months ended April 30, 2013, respectively. Amounts payable to and due from related party customers were not material at April 30, 2014.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_prior_note, score: 0.0

- added (2014-06-03):
[0001327567-14-000013:note_history:32]
Subsequent Events

- added (2014-06-03):
[0001327567-14-000013:note_history:33]
On May 27, 2014, we entered into a Settlement, Release and Cross-License Agreement with Juniper, whereby we resolved all pending litigation matters. Under the terms of the settlement agreement, we agreed to pay Juniper a one-time settlement amount of approximately $175,000,000, which was comprised of $75,000,000 in cash, 1,081,000 shares of our common stock with an approximate value of $70,000,000, and a warrant to purchase 463,000 shares of our common stock with an approximate value of $30,000,000, in exchange for the following:

- added (2014-06-03):
[0001327567-14-000013:note_history:34]
| • | Mutual dismissal with prejudice of all pending litigation between the parties and general release of all liability for Palo Alto Networks and Juniper, |

- added (2014-06-03):
[0001327567-14-000013:note_history:35]
| • | Cross-license between both parties for the patents-in-suit and associated family members and counterparts worldwide for the life of the patents, and |

- added (2014-06-03):
[0001327567-14-000013:note_history:36]
| • | Mutual covenant not to sue for infringement of any other patents for a period of eight years. |

- added (2014-06-03):
[0001327567-14-000013:note_history:37]
For accounting purposes, the fair value of the total consideration as of the settlement date was $182,473,000 . The fair values of the common stock and warrant were measured using the closing price of our common stock on the settlement date.

- added (2014-06-03):
[0001327567-14-000013:note_history:38]
We accounted for the settlement agreement as a multiple element arrangement and allocated the fair value of the consideration as of the settlement date to the identifiable elements based on their estimated fair values. Of the total settlement amount, $61,300,000 was allocated to the licensing of intellectual property, $54,300,000 was allocated to the mutual dismissal of claims, and the remaining amount was allocated to the mutual covenant not to sue. The mutual dismissal of claims and the covenant not to sue have no identifiable future benefit, and as a result we accrued a settlement charge within operating expenses as of and for the three and nine months ended April 30, 2014. The licensing of intellectual property will be recorded in our fiscal fourth quarter and will be amortized over the estimated period of benefit of five years.

- added (2014-06-03):
[0001327567-14-000013:note_history:39]
The warrant entitles Juniper to purchase up to 463,000 shares of common stock at an exercise price of $0.0001 per share and will expire seven months from the date of its issuance. Once issued, the liability-classified warrant will be remeasured through earnings at the end of each reporting period until exercised. The amount of future remeasurement is undeterminable and will be driven predominantly by increases or decreases in our stock price.
