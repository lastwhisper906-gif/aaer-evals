# PANW notes — 0001327567-14-000028


## us-gaap:AvailableForSaleSecuritiesContinuousUnrealizedLossPositionFairValueTableTextBlock

[0001327567-14-000028:notes:1]
The following table presents our investments that were in an unrealized loss position as of July 31, 2014 and July 31, 2013 (in thousands):

[0001327567-14-000028:notes:2]
|  | July 31, 2014 |
|  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
|  | Fair Value |  | Unrealized Loss |  | Fair Value |  | Unrealized Loss |  | Fair Value |  | Unrealized Loss |
| Corporate debt securities | $ | 43,868 |  |  | $ | (58 | ) |  | $ | — |  |  | $ | — |  |  | $ | 43,868 |  |  | $ | (58 | ) |
| U.S. government and agency securities | 142,490 |  |  | (108 | ) |  | — |  |  | — |  |  | 142,490 |  |  | (108 | ) |
| Total | $ | 186,358 |  |  | $ | (166 | ) |  | $ | — |  |  | $ | — |  |  | $ | 186,358 |  |  | $ | (166 | ) |

[0001327567-14-000028:notes:3]
|  | July 31, 2013 |
|  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
|  | Fair Value |  | Unrealized Loss |  | Fair Value |  | Unrealized Loss |  | Fair Value |  | Unrealized Loss |
| Corporate debt securities | $ | 31,429 |  |  | $ | (34 | ) |  | $ | — |  |  | $ | — |  |  | $ | 31,429 |  |  | $ | (34 | ) |
| U.S. government and agency securities | 15,926 |  |  | (2 | ) |  | — |  |  | — |  |  | 15,926 |  |  | (2 | ) |
| Total | $ | 47,355 |  |  | $ | (36 | ) |  | $ | — |  |  | $ | — |  |  | $ | 47,355 |  |  | $ | (36 | ) |


## us-gaap:AvailableForSaleSecuritiesTextBlock

[0001327567-14-000028:notes:4]
The following table summarizes the unrealized gains and losses and fair value of our investments as of July 31, 2014 and July 31, 2013 (in thousands):

[0001327567-14-000028:notes:5]
|  | July 31, 2014 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Estimated Fair Value |
| Certificates of deposit | $ | 1,000 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,000 |  |
| Corporate debt securities | 61,299 |  |  | 16 |  |  | (58 | ) |  | 61,257 |  |
| U.S. government and agency securities | 258,376 |  |  | 45 |  |  | (108 | ) |  | 258,313 |  |
| Total | $ | 320,675 |  |  | $ | 61 |  |  | $ | (166 | ) |  | $ | 320,570 |  |

[0001327567-14-000028:notes:6]
|  | July 31, 2013 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Estimated Fair Value |
| Certificates of deposit | $ | 1,822 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,822 |  |
| Corporate debt securities | 45,173 |  |  | 12 |  |  | (34 | ) |  | 45,151 |  |
| U.S. government and agency securities | 127,864 |  |  | 8 |  |  | (2 | ) |  | 127,870 |  |
| Money market funds | 131,845 |  |  | — |  |  | — |  |  | 131,845 |  |
| Total | $ | 306,704 |  |  | $ | 20 |  |  | $ | (36 | ) |  | $ | 306,688 |  |


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001327567-14-000028:notes:7]
Basis of Presentation

[0001327567-14-000028:notes:8]
The accompanying consolidated financial statements have been prepared in conformity with U.S. generally accepted accounting principles. The consolidated financial statements include all adjustments necessary for a fair presentation of our annual results. All adjustments are of a normal recurring nature. Certain prior period amounts have been reclassified to conform with current period presentation.


## us-gaap:BusinessAcquisitionProFormaInformationTextBlock

[0001327567-14-000028:notes:9]
The following table presents the unaudited pro forma financial information for the years ended July 31, 2014 and 2013, as though the companies were combined as of August 1, 2012 (in thousands):

[0001327567-14-000028:notes:10]
|  | Year Ended July 31, |
|  | 2014 |  | 2013 |
| Total revenue | $ | 598,254 |  |  | $ | 396,131 |  |
| Net loss | $ | (241,920 | ) |  | $ | (43,041 | ) |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001327567-14-000028:notes:11]
Acquisitions

[0001327567-14-000028:notes:12]
Business Combinations

[0001327567-14-000028:notes:13]
Cyvera Ltd.

[0001327567-14-000028:notes:14]
On April 9, 2014, we completed our acquisition of Cyvera Ltd. (“Cyvera”), a privately-held cybersecurity company located in Tel Aviv, Israel. The acquisition extends our next-generation security platform with an innovative approach to preventing attacks on the endpoint. We have accounted for this transaction as a business combination in exchange for total consideration of approximately $177,647,000, which consisted of the following (in thousands):

[0001327567-14-000028:notes:15]
|  | Amount |
| Cash | $ | 90,170 |  |
| Common stock (1,281,000 shares) | 87,477 |  |
| Total | $ | 177,647 |  |

[0001327567-14-000028:notes:16]
As part of the acquisition, we agreed to replace Cyvera's unvested options with our restricted stock units with an estimated fair value of $6,353,000. Of the total estimated fair value, a portion was allocated to the purchase consideration and the remainder was allocated to future services and will be expensed over the remaining service periods on a straight-line basis as share-based compensation.

[0001327567-14-000028:notes:17]
In addition, we issued 276,000 shares of restricted common stock with a total fair value of $17,612,000 to certain Cyvera employees. The restriction on these shares will be released over a period of three years from the acquisition date, subject to continued employment. These shares were excluded from the purchase consideration and are being expensed over the remaining service periods on a straight-line basis as share-based compensation. As of July 31, 2014, all of the restricted common stock issued in connection with the acquisition remained unvested.

[0001327567-14-000028:notes:18]
We expensed the related acquisition costs in the amount of $3,940,000 in general and administrative expenses for the year ended July 31, 2014.

[0001327567-14-000028:notes:19]
The following table summarizes our allocation of the purchase consideration based on the estimated fair value of assets acquired and liabilities assumed (in thousands):

[0001327567-14-000028:notes:20]
|  | Amount |
| Cash | $ | 6,930 |  |
| Goodwill | 144,906 |  |
| Identified intangible assets | 42,300 |  |
| Accrued and other liabilities, net | (6,950 | ) |
| Long-term deferred tax liability, net | (9,539 | ) |
| Total | $ | 177,647 |  |

[0001327567-14-000028:notes:21]
The estimated fair values of assets acquired and liabilities assumed in the table above have been adjusted to reflect a change in our estimated blended state tax rate during the measurement period. Additional adjustments to current and noncurrent income taxes payable and deferred taxes may be required as additional information is received and certain tax returns are finalized. We expect to finalize the allocation of the purchase consideration to the assets acquired and liabilities assumed as soon as practicable, but not later than 12 months from the acquisition date.

[0001327567-14-000028:notes:22]
The following table presents details of the identified intangible assets acquired (in thousands, except years):

[0001327567-14-000028:notes:23]
|  | Fair Value |  | Estimated Useful Life |
| Developed technology | $ | 34,500 |  |  | 7 years |
| In-process research and development | 7,600 |  |  | N/A |
| Other | 200 |  |  | 2 years |
| Total | $ | 42,300 |  |  |  |

[0001327567-14-000028:notes:24]
Goodwill generated from this business combination is primarily attributable to the assembled workforce and synergies from combined selling opportunities of both network security products and endpoint security products. The goodwill is not tax deductible for income tax purposes.

[0001327567-14-000028:notes:25]
Cyvera’s operating results are included in our consolidated statements of operations from the date of the acquisition and are considered immaterial for purposes of financial disclosures.

[0001327567-14-000028:notes:26]
The pro forma financial information for the years ended July 31, 2014 and 2013 has been calculated after adjusting our results and those of Cyvera to reflect the business combination accounting effects resulting from this acquisition as though the acquisition occurred as of August 1, 2012, including acquisition related transaction costs, the amortization expense from acquired intangible assets, and post-acquisition share-based compensation expense related to restricted common stock and the replacement of unvested Cyvera options. The pro forma financial information is for informational purposes only and is not indicative of the results of operations that would have been achieved if the acquisition had taken place at the beginning of our fiscal 2013.

[0001327567-14-000028:notes:27]
The pro forma financial information for the years ended July 31, 2014 and 2013 combines our historical results for the years ended July 31, 2014 and 2013 and the adjusted historical results of Cyvera for the twelve months ended June 30, 2014 and 2013, due to differences in reporting periods and considering the date we acquired Cyvera.

[0001327567-14-000028:notes:28]
Morta Security, Inc.

[0001327567-14-000028:notes:29]
On December 26, 2013, we completed our acquisition of Morta Security, Inc. (“Morta”), a privately-held cybersecurity company. We have accounted for this transaction as a business combination and exchanged total cash consideration of $10,345,000, of which $2,500,000 was withheld for Morta's indemnification obligations. Morta brings us a team of cybersecurity experts which will enhance the proven detection and prevention capabilities of our WildFire offering.

[0001327567-14-000028:notes:30]
|  | Amount |
| Goodwill | $ | 10,127 |  |
| Identified intangible assets | 2,200 |  |
| Net liabilities assumed | (1,982 | ) |
| Total | $ | 10,345 |  |

[0001327567-14-000028:notes:31]
The estimated fair values of assets acquired and liabilities assumed in the table above have been adjusted to reflect changes in our blended tax rate during the measurement period. Additional adjustments to current and noncurrent income taxes payable and deferred taxes may be required as additional information is received and certain tax returns are finalized. We expect to finalize the allocation of the purchase consideration to the assets acquired and liabilities assumed as soon as practicable, but not later than 12 months from the acquisition date.

[0001327567-14-000028:notes:32]
|  | Fair Value |  | Estimated Useful Life |
| In-process research and development held for defensive purposes | $ | 1,900 |  |  | 3 years |
| Other | 300 |  |  | 2 years |
| Total | $ | 2,200 |  |  |  |

[0001327567-14-000028:notes:33]
Morta’s operating results are included in our consolidated statements of operations from the date of the acquisition and are considered immaterial for purposes of pro forma financial disclosures. Goodwill generated from this business combination is primarily attributable to human capital with threat intelligence experience and capabilities, and is not tax deductible for income tax purposes.

[0001327567-14-000028:notes:34]
Other Purchased Intangible Assets

[0001327567-14-000028:notes:35]
On September 4, 2013 we entered into an agreement to purchase intellectual property for $5,000,000, which is being amortized over a weighted-average period of thirteen years.


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock

[0001327567-14-000028:notes:36]
Description of Business and Summary of Significant Accounting Policies

[0001327567-14-000028:notes:37]
Description of Business

[0001327567-14-000028:notes:38]
Palo Alto Networks, Inc. (the “Company,” “we,” “us,” or “our”), located in Santa Clara, California, was incorporated in March 2005 under the laws of the State of Delaware and commenced operations in April 2005. We offer a next-generation enterprise security platform that allows enterprises, service providers, and government entities to simultaneously empower and secure their organizations by safely enabling the increasingly complex and rapidly growing number of applications running on their networks and by preventing breaches stemming from targeted cyber attacks.

[0001327567-14-000028:notes:39]
Our enterprise security platform consists of three major elements: our Next-Generation Firewall, our Advanced Endpoint Protection, and our Threat Intelligence Cloud. Our Next-Generation Firewall delivers application, user, and content visibility and control as well as protection against network-based cyber threats integrated within the firewall through our proprietary hardware and software architecture. Our Advanced Endpoint Protection, which we expect to release in fiscal 2015, prevents cyber attacks that aim to exploit software vulnerabilities on a broad variety of fixed and virtual endpoints. Our Threat Intelligence Cloud provides central intelligence capabilities as well as automated delivery of preventative measures against cyber attacks. The cloud-based element of our platform is delivered in the form of a service that can be used either in the public cloud or in a private cloud using a dedicated appliance.

[0001327567-14-000028:notes:40]
We primarily sell our products and services to end-customers through our channel partners and infrequently directly to end-customers. Our partners are supported by our sales and marketing organization in the Americas, in Europe, the Middle East, and Africa (EMEA), and in Asia Pacific and Japan (APAC).

[0001327567-14-000028:notes:41]
Principles of Consolidation

[0001327567-14-000028:notes:42]
The consolidated financial statements include our accounts and our wholly owned subsidiaries. All significant intercompany balances and transactions have been eliminated in consolidation.

[0001327567-14-000028:notes:43]
Use of Estimates

[0001327567-14-000028:notes:44]
The preparation of consolidated financial statements in conformity with accounting principles generally accepted in the United States of America requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the consolidated financial statements and the reported amounts of revenues and expenses during the reporting period. Such management estimates include the best estimate of selling price for our products and services, share-based compensation, fair value of assets acquired and liabilities assumed in business combinations, the assessment of recoverability of our property and equipment, identified intangibles and goodwill, future taxable income, contract manufacturer liabilities, and loss contingencies. We base our estimates on historical experience and also on assumptions that we believe are reasonable. Actual results could differ materially from those estimates.

[0001327567-14-000028:notes:45]
Concentrations

[0001327567-14-000028:notes:46]
Financial instruments that subject us to concentrations of credit risk consist primarily of cash and cash equivalents, investments, and accounts receivable. We invest only in high-quality credit instruments and maintain our cash and cash equivalents and available-for-sale investments in fixed income securities. Management believes that the financial institutions that hold our investments are financially sound and, accordingly, are subject to minimal credit risk. Deposits held with banks may exceed the amount of insurance provided on such deposits.

[0001327567-14-000028:notes:47]
Our accounts receivables are primarily derived from our channel partners representing various geographical locations. We perform ongoing credit evaluations of our channel partners and generally do not require collateral on accounts receivable. We maintain an allowance for doubtful accounts for estimated potential credit losses. As of July 31, 2014, three partners represented 36%, 24%, and 13% of our gross accounts receivable. For fiscal 2014, three partners represented 32%, 25%, and 13% of our total revenue. We rely on an independent contract manufacturer to assemble most of our products and sole suppliers for a certain number of our components.

[0001327567-14-000028:notes:48]
Comprehensive Income (Loss)

[0001327567-14-000028:notes:49]
Comprehensive income (loss) is comprised of net income (loss) and other comprehensive income (loss). Unrealized gains and losses on available-for-sale investments are included in our other comprehensive income or loss.

[0001327567-14-000028:notes:50]
Foreign Currency Transactions

[0001327567-14-000028:notes:51]
The functional currency of our foreign subsidiaries is the U.S. dollar. Monetary assets and liabilities denominated in foreign currencies have been remeasured into U.S. dollars using the exchange rates in effect at the balance sheet dates. Foreign currency denominated income and expenses have been remeasured using the average exchange rates in effect during each period. Foreign currency remeasurement gains and losses and foreign currency transaction gains and losses are not significant to the financial statements.

[0001327567-14-000028:notes:52]
Cash and Cash Equivalents

[0001327567-14-000028:notes:53]
We consider all highly liquid investments held at financial institutions, such as commercial paper, money market funds, and other money market securities with original maturities of three months or less at date of purchase to be cash equivalents.

[0001327567-14-000028:notes:54]
Fair Value of Financial Instruments

[0001327567-14-000028:notes:55]
We define fair value as the price that would be received from selling an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date. When determining the fair value measurements for assets and liabilities which are required to be recorded at fair value, we consider the principal or most advantageous market in which to transact and the market-based risk. We apply fair value accounting for all financial assets and liabilities that are recognized or disclosed at fair value in the financial statements on a recurring basis. The carrying amounts reported in the consolidated financial statements approximate the fair value for cash and cash equivalents, accounts receivable, accounts payable, and accrued liabilities, due to their short-term nature.

[0001327567-14-000028:notes:56]
Investments

[0001327567-14-000028:notes:57]
We classify our investments as available-for-sale at the time of purchase since it is our intent that these investments are available for current operations, and include these investments on our balance sheet as either short-term or long-term investments depending on their maturity. Investments not considered cash equivalents and with maturities one year or less from the consolidated balance sheet date are classified as short-term investments. Investments with maturities greater than one year from the consolidated balance sheet date are classified as long-term investments.

[0001327567-14-000028:notes:58]
Investments are considered impaired when a decline in fair value is judged to be other-than-temporary. We consult with our investment managers and consider available quantitative and qualitative evidence in evaluating potential impairment of our investments on a quarterly basis. If the cost of an individual investment exceeds its fair value, we evaluate, among other factors, general market conditions, the duration and extent to which the fair value is less than cost, and our intent and ability to hold the investment. Once a decline in fair value is determined to be other-than-temporary, an impairment charge is recorded and a new cost basis in the investment is established.

[0001327567-14-000028:notes:59]
Accounts Receivable

[0001327567-14-000028:notes:60]
Trade accounts receivable are recorded at the invoiced amount, net of allowances for doubtful accounts. The allowance for doubtful accounts is based on our assessment of the collectability of accounts. Management regularly reviews the adequacy of the allowance for doubtful accounts by considering the age of each outstanding invoice, each partner’s expected ability to pay, and the collection history with each partner, when applicable, to determine whether a specific allowance is appropriate. Accounts receivable deemed uncollectible are charged against the allowance for doubtful accounts when identified. As of July 31, 2014 and 2013, the allowance for doubtful accounts activity was not significant.

[0001327567-14-000028:notes:61]
Property and Equipment

[0001327567-14-000028:notes:62]
Property and equipment are recorded at cost. Depreciation is computed using the straight-line method over the estimated useful lives of the assets, generally three to ten years. Leasehold improvements are depreciated over the shorter of the estimated useful lives of the improvements or the remaining lease term.

[0001327567-14-000028:notes:63]
We include the results of operations of the businesses that we acquire as of the respective dates of acquisition. We allocate the fair value of the purchase price of our acquisitions to the tangible assets acquired, liabilities assumed, and intangible assets acquired, based on their estimated fair values. The excess of the purchase price over the fair values of these identifiable assets and liabilities is recorded as goodwill. Additional information existing as of the acquisition date but unknown to us may become known during the remainder of the measurement period, not to exceed 12 months from the acquisition date, which may result in changes to the amounts and allocations recorded.

[0001327567-14-000028:notes:64]
Amortization of Intangible Assets

[0001327567-14-000028:notes:65]
Purchased intangible assets with finite lives are carried at cost, less accumulated amortization. Amortization is computed over the estimated useful lives of the respective assets. Acquisition-related in-process research and development represents the fair value of incomplete research and development projects that have not reached technological feasibility as of the date of acquisition. Initially, these assets are not subject to amortization. Assets related to projects that have been completed are transferred to developed technology, which are subject to amortization, while assets related to projects that have been abandoned are impaired and expensed to research and development.

[0001327567-14-000028:notes:66]
Impairment of Goodwill, Intangible Assets, and Long-Lived Assets

[0001327567-14-000028:notes:67]
Goodwill is evaluated for impairment on an annual basis in the fourth quarter of our fiscal year, and whenever events or changes in circumstances indicate the carrying amount of goodwill may not be recoverable. We have elected to first assess qualitative factors to determine whether it is more likely than not that the fair value of our single reporting unit is less than its carrying amount. If we determine that it is more likely than not that the fair value of our single reporting unit is less than its carrying amount, then the two-step goodwill impairment test will be performed. The first step, identifying a potential impairment, compares the fair value of our single reporting unit with its carrying amount. If the carrying amount exceeds its fair value, the second step will be performed; otherwise, no further step is required. The second step, measuring the impairment loss, compares the implied fair value of the goodwill with the carrying amount of the goodwill. Any excess of the goodwill carrying amount over the implied fair value is recognized as an impairment loss.

[0001327567-14-000028:notes:68]
We evaluate events and changes in circumstances that could indicate carrying amounts of purchased intangible assets and long-lived assets may not be recoverable. When such events or changes in circumstances occur, we assess the recoverability of these assets by determining whether or not the carrying amount will be recovered through undiscounted expected future cash flows. If the total of the future undiscounted cash flows is less than the carrying amount of an asset, we record an impairment loss for the amount by which the carrying amount of the asset exceeds the fair value of the asset.

[0001327567-14-000028:notes:69]
Through July 31, 2014, we have not recognized any impairment losses on our goodwill, intangible assets, and long-lived assets.

[0001327567-14-000028:notes:70]
Contract Manufacturer Liabilities

[0001327567-14-000028:notes:71]
We outsource most of our manufacturing, repair, and supply chain management operations to our independent contract manufacturer and payments to it are a significant portion of our product cost of revenues. Although we could be contractually obligated to purchase manufactured products, we generally do not own the manufactured products. Product title transfers from our independent contract manufacturer to us and immediately to our partners upon shipment. Our independent contract manufacturer assembles our products using design specifications, quality assurance programs, and standards that we establish and it procures components and assembles our products based on our demand forecasts. These forecasts represent our estimates of future demand for our products based upon historical trends and analysis from our sales and product management functions as adjusted for overall market conditions. If the actual component usage and product demand are significantly lower than forecast, we accrue for costs for contractual manufacturing commitments in excess of our forecasted demand including costs for excess components or for carrying costs incurred by our contract manufacturer. Through July 31, 2014, we have not accrued any significant costs associated with this exposure.

[0001327567-14-000028:notes:72]
Convertible Senior Notes

[0001327567-14-000028:notes:73]
On June 30, 2014, we issued $575,000,000 aggregate principal amount of 0.0% convertible senior notes due 2019 (the "Notes"). In accounting for the issuance of the Notes, we separated the Notes into liability and equity components. The carrying amount of the liability component was calculated by measuring the fair value of a similar liability that does not have an associated convertible feature. The carrying amount of the equity component representing the conversion option was determined by deducting the fair value of the liability component from the par value of the Notes as a whole. This difference represents a debt discount that is amortized to interest expense using the effective interest method over the term of the Notes. The equity component is not remeasured as long as it continues to meet the conditions for equity classification. In accounting for the transaction costs related to the issuance of the Notes, we allocated the total amount incurred to the liability and equity components using the same proportions as the proceeds from the Notes. Transaction costs attributable to the liability component are being amortized to interest expense using the effective interest method over the term of the Notes. Transaction costs attributable to the equity component were netted with the equity component of the Notes in additional paid-in capital in the consolidated balance sheets.

[0001327567-14-000028:notes:74]
Revenue Recognition

[0001327567-14-000028:notes:75]
We generate revenue from the sales of hardware and software products, subscriptions, support and maintenance, and other services primarily through a direct sales force and indirect relationships with our partners.

[0001327567-14-000028:notes:76]
Revenue is recognized when all of the following criteria are met:

[0001327567-14-000028:notes:77]
| • | Persuasive Evidence of an Arrangement Exists. We rely upon non-cancelable sales agreements and purchase orders to determine the existence of an arrangement. |

[0001327567-14-000028:notes:78]
| • | Delivery has Occurred. We use shipping documents or transmissions of product or service contract registration codes to determine delivery. |

[0001327567-14-000028:notes:79]
| • | The Fee is Fixed or Determinable. We assess whether the fee is fixed or determinable based on the payment terms associated with the transaction. |

[0001327567-14-000028:notes:80]
| • | Collectability is Reasonably Assured. We assess collectability based on credit analysis and payment history. |

[0001327567-14-000028:notes:81]
We recognize product revenue at the time of shipment provided that all other revenue recognition criteria have been met. Our partners generally receive an order from an end-customer prior to placing an order with us. In addition, payment from our partners is not contingent on the partner’s success in sales to end-customers. Our partners generally do not stock appliances and only have limited stock rotation rights and no price protection rights. When necessary, we make certain estimates and maintain allowances for sales returns and other programs based on our historical experience. To date, these estimates have not been significant. We recognize services revenue from subscriptions and support and maintenance ratably over the contractual service period, which is typically one to five years. Other services revenue is recognized as the services are rendered and has not been significant to date.

[0001327567-14-000028:notes:82]
Most of our arrangements, other than renewals of subscriptions and support and maintenance, are multiple-element arrangements with a combination of hardware, software, subscriptions, support and maintenance, and other services. Products and services generally qualify as separate units of accounting. Our hardware deliverables typically include proprietary operating system software, which together deliver the essential functionality of our products. For multiple-element arrangements, we allocate revenue to each unit of accounting based on an estimated selling price at the arrangement inception. The estimated selling price for each element is based upon the following hierarchy: vendor-specific objective evidence (VSOE) of selling price, if available, third-party evidence (TPE) of selling price, if VSOE of selling price is not available, or best estimate of selling price (BESP), if neither VSOE of selling price nor TPE of selling price are available. The total arrangement consideration is allocated to each separate unit of accounting using the relative estimated selling prices of each unit based on the aforementioned selling price hierarchy. We limit the amount of revenue recognized for delivered elements to an amount that is not contingent upon future delivery of additional products or services or meeting of any specified performance conditions.

[0001327567-14-000028:notes:83]
To determine the estimated selling price in multiple-element arrangements, we establish VSOE of selling price using the prices charged for a deliverable when sold separately. If VSOE of selling price cannot be established for a deliverable, we establish TPE of selling price by evaluating similar and interchangeable competitor products or services in standalone arrangements with similarly situated partners. However, as our products contain a significant element of proprietary technology and offer substantially different features and functionality from our competitors, we are unable to obtain comparable pricing of our competitors’ products with similar functionality on a standalone basis. Therefore, we have not been able to obtain reliable evidence of TPE of selling price. If neither VSOE nor TPE of selling price can be established for a deliverable, we establish BESP primarily based on historical transaction pricing. Historical transactions are segregated based on our pricing model and our go-to-market strategy, which include factors such as type of sales channel (reseller, distributor, or end-customer), the geographies in which our products and services were sold (domestic or international), offering type (products or services), and whether or not the opportunity was identified by our sales force or by our partners. In analyzing historical transaction pricing we evaluate whether a majority of the prices charged for a product or service, as represented by a percentage of list price, fall within a reasonable range. To further support the best estimate of selling price as determined by the historical transaction pricing or when such information is unavailable, such as when there are limited sales of a new product or service, we consider the same factors we have established through our pricing model and go-to-market strategy. The determination of BESP is made through consultation with and approval by our management.

[0001327567-14-000028:notes:84]
In multiple-element arrangements where software deliverables are included, revenue is allocated to each separate unit of accounting for each of the non-software deliverables and to the software deliverables as a group using the relative estimated selling prices of each of the deliverables in the arrangement based on the aforementioned estimated selling price hierarchy. The arrangement consideration allocated to the software deliverables as a group is then allocated to each software deliverable using the residual method when VSOE of fair value of the undelivered items exists. Under the residual method, the amount of revenue allocated to delivered elements equals the total arrangement consideration less the aggregate fair value of any undelivered elements. In determining VSOE of fair value, we evaluate whether a substantial majority of the historical prices charged for a product or service sold on a standalone basis, as represented by a percentage of list price, fall within a reasonably narrow range. If VSOE of fair value of one or more undelivered items does not exist, revenue from the entire arrangement is deferred and recognized at the earlier of: (i) delivery of those elements or (ii) when fair value can be established unless support and maintenance is the only undelivered element, in which case, the entire arrangement fee is recognized ratably over the contractual service period.

[0001327567-14-000028:notes:85]
We account for multiple agreements with a single partner as one arrangement if the contractual terms and/or substance of those agreements indicate that they may be so closely related that they are, in effect, parts of a single arrangement.

[0001327567-14-000028:notes:86]
Revenues are reported net of sales taxes. Shipping charges billed to partners are included in revenues and related costs are included in cost of revenue. Sales commissions and other incremental costs to acquire contracts are also expensed as incurred. After receipt of a partner order, any amounts billed in excess of revenue recognized are recorded as deferred revenue.

[0001327567-14-000028:notes:87]
Advertising Costs

[0001327567-14-000028:notes:88]
Advertising costs, which are expensed and included in sales and marketing expense when incurred, were $3,693,000, $1,808,000, and $1,604,000, during the years ended July 31, 2014, 2013, and 2012, respectively.

[0001327567-14-000028:notes:89]
Software Development Costs

[0001327567-14-000028:notes:90]
Internally developed software includes enterprise-level business software that we are customizing to meet our specific operational needs. These capitalized costs consisted of the external direct costs and the internal payroll and payroll related costs that are related to the implementation of our enterprise resource planning software system and will be amortized over a useful life of five years.

[0001327567-14-000028:notes:91]
The costs to develop software that is marketed externally have not been capitalized as we believe our current software development process is essentially completed concurrent with the establishment of technological feasibility. As such, all related software development costs are expensed as incurred and included in research and development expense in our consolidated statements of operations.

[0001327567-14-000028:notes:92]
Share-Based Compensation

[0001327567-14-000028:notes:93]
Compensation expense related to share-based transactions, including employee and non-employee director awards, is measured and recognized in the financial statements based on fair value on the grant date. The fair value of restricted stock units (RSUs) is based on the closing market price of our common stock on the date of grant. The fair value of option awards and purchases under our 2012 Equity Incentive Plan (the “2012 Plan”) and 2012 Employee Stock Purchase Plan (the “2012 ESPP”) is estimated using the Black-Scholes option-pricing model. This model requires the input of the fair value of our common stock and that at the date of grant we determine the expected term of the award, the expected volatility of the price of our common stock, risk-free interest rates, and expected dividend yield of our common stock. The share-based compensation expense, net of forfeitures, is recognized using a straight-line basis over the requisite service periods of the awards. We estimate a forfeiture rate to calculate the share-based compensation expense for our awards. Our forfeiture rate is based on an analysis of our actual historical forfeitures.

[0001327567-14-000028:notes:94]
Income Taxes

[0001327567-14-000028:notes:95]
We account for income taxes using the asset and liability method, which requires the recognition of deferred tax assets and liabilities for the expected future tax consequences of events that have been recognized in our financial statements or tax returns. In addition, deferred tax assets are recorded for the future benefit of utilizing net operating losses and research and development credit carryforwards. Valuation allowances are provided when necessary to reduce deferred tax assets to the amount expected to be realized.

[0001327567-14-000028:notes:96]
Significant judgment is required in determining any valuation allowance recorded against deferred tax assets. In assessing the need for a valuation allowance, we consider all available evidence, including past operating results, estimates of future taxable income, and the feasibility of tax planning strategies. In the event that we change our determination as to the amount of deferred tax assets that can be realized, we will adjust our valuation allowance with a corresponding impact to the provision for income taxes in the period in which such determination is made.

[0001327567-14-000028:notes:97]
We apply the authoritative accounting guidance prescribing a threshold and measurement attribute for the financial recognition and measurement of a tax position taken or expected to be taken in a tax return. We recognize liabilities for uncertain tax positions based on a two-step process. The first step is to evaluate the tax position for recognition by determining if the weight of available evidence indicates that it is more likely than not that the position will be sustained on audit, including resolution of related appeals or litigation processes, if any. The second step requires us to estimate and measure the tax benefit as the largest amount that is more likely than not to be realized upon ultimate settlement.

[0001327567-14-000028:notes:98]
Loss Contingencies

[0001327567-14-000028:notes:99]
We are subject to the possibility of various loss contingencies arising in the ordinary course of business. We consider the likelihood of loss or impairment of an asset, or the incurrence of a liability, as well as our ability to reasonably estimate the amount of loss, in determining loss contingencies. An estimated loss contingency is accrued when it is probable that an asset has been impaired or a liability has been incurred and the amount of loss can be reasonably estimated. If we determine that a loss is possible and the range of the loss can be reasonably determined, then we disclose the range of the possible loss. We regularly evaluate current information available to us to determine whether an accrual is required, an accrual should be adjusted or a range of possible loss should be disclosed.

[0001327567-14-000028:notes:100]
Recent Accounting Pronouncements

[0001327567-14-000028:notes:101]
In May 2014, the Financial Accounting Standards Board (FASB) issued Accounting Standards Update (ASU) No. 2014-09 regarding Accounting Standards Codification (ASC) Topic 606, Revenue from Contracts with Customers. The standard provides principles for recognizing revenue for the transfer of promised goods or services to customers with the consideration to which the entity expects to be entitled in exchange for those goods or services. The guidance is effective for us in the first quarter of fiscal 2018 using either of two methods: (i) retrospective to each prior reporting period presented with the option to elect certain practical expedients as defined within the guidance; or (ii) retrospective with the cumulative effect of initially applying the guidance recognized at the date of initial application and providing certain additional disclosures as defined per the guidance. Early adoption is not permitted. We are currently evaluating the accounting, transition and disclosure requirements of the standard and cannot currently estimate the financial statement impact of adoption.

[0001327567-14-000028:notes:102]
In July 2013, the FASB issued ASU No. 2013-11, Income Taxes (Topic 740)-Presentation of an Unrecognized Tax Benefit When a Net Operating Loss Carryforward, a Similar Tax Loss, or a Tax Credit Carryforward Exists. The standard requires us to present an unrecognized tax benefit as a reduction of a deferred tax asset for a net operating loss (NOL) carryforward or other tax credit carryforward when settlement in this manner is available under applicable tax law. The guidance is effective for us in the first quarter of fiscal 2015 and will be applied prospectively. Early adoption is permitted. We do not believe the adoption of this guidance will have a material impact on our consolidated financial statements.

[0001327567-14-000028:notes:103]
In February 2013, the FASB issued ASU No. 2013-02, Comprehensive Income (Topic 220)-Reporting of Amounts Reclassified Out of Accumulated Other Comprehensive Income. The standard requires entities to present (either on the face of the income statement or in the notes) the effects on the line items of the income statement for amounts reclassified out of accumulated other comprehensive income. The guidance was effective for us in the first quarter of fiscal 2014. Our adoption of this guidance did not impact our financial statements as the guidance is related to disclosure only and we did not have significant reclassifications out of accumulated other comprehensive income.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001327567-14-000028:notes:104]
Commitments and Contingencies

[0001327567-14-000028:notes:105]
Leases

[0001327567-14-000028:notes:106]
We lease our facilities under various non-cancelable operating leases, which expire through the year ending July 31, 2023.

[0001327567-14-000028:notes:107]
In September 2012, we entered into two lease agreements for an aggregate of approximately 300,000 square feet of space in Santa Clara, California to serve as our new corporate headquarters beginning in November 2013. The leases have inception dates of November 2012 and August 2013, expire in July 2023, and allow for two separate 5-year options to extend the lease term. Payments under these leases are approximately $94,321,000 over the lease term. Each lease has a rent holiday, which was included in the determination of rent expense.

[0001327567-14-000028:notes:108]
In July 2013, we entered into a 51-month sub-lease agreement for our current corporate headquarters with a lease inception date of January 2014. Net proceeds from this sub-lease is approximately $10,696,000 over the lease term. The sub-lease agreement contains a rent credit of $528,000, which was included in the determination of rental income.

[0001327567-14-000028:notes:109]
We recognized rent expense of $13,207,000, $4,356,000, and $2,258,000 for the years ended July 31, 2014, 2013, and 2012, respectively. Rent expense is recognized using the straight-line method over the term of the lease.

[0001327567-14-000028:notes:110]
The following table presents details of the aggregate future non-cancelable minimum rental payments on our operating leases as of July 31, 2014 (in thousands):

[0001327567-14-000028:notes:111]
|  | Amount |
| Years ending July 31: |  |
| 2015 | $ | 14,170 |  |
| 2016 | 14,279 |  |
| 2017 | 13,187 |  |
| 2018 | 11,774 |  |
| 2019 | 9,697 |  |
| 2020 and thereafter | 42,603 |  |
| Committed gross lease payments | 105,710 |  |
| Less: proceeds from sublease rental | 10,696 |  |
| Net operating lease obligation | $ | 95,014 |  |

[0001327567-14-000028:notes:112]
Contract Manufacturer Commitments

[0001327567-14-000028:notes:113]
Our independent contract manufacturer procures components and assembles our products based on our forecasts. These forecasts are based on estimates of demand for our products primarily for the next twelve months, which are in turn based on historical trends and an analysis from our sales and product marketing organizations, adjusted for overall market conditions. In order to reduce manufacturing lead times and plan for adequate supply, we may issue forecasts and orders for components and products that are non-cancelable. Obligations under contracts that we can cancel without a significant penalty are not included. As of July 31, 2014, we had $29,895,000 of open orders.

[0001327567-14-000028:notes:114]
Litigation

[0001327567-14-000028:notes:115]
In December 2011, Juniper Networks, Inc. (“Juniper”) filed a complaint against us in the United States District Court for the District of Delaware alleging patent infringement. The complaint sought preliminary and permanent injunctions against infringement, treble damages, and attorneys' fees. On September 4, 2012, Juniper filed a motion to amend its complaint to allege that our appliances infringe two additional U.S. patents but also to withdraw its allegations as to a previously-asserted patent. This amended complaint was officially filed on September 25, 2012, pursuant to a stipulation between the parties. On October 12, 2012, we filed an answer to Juniper’s amended complaint, which denied that we infringed Juniper’s patents and asserted that Juniper’s patents were invalid. The Court issued an order on February 6, 2014, in which the Court construed several disputed claim limitations, granted Juniper’s motion for summary judgment of assignor estoppel, precluding us from raising in the litigation challenges to the validity of Juniper’s patents, denied Juniper’s motion for summary judgment of infringement, and granted in part and denied in part our motion for summary judgment of non-infringement. A trial took place in February 2014. Following the trial, the jury was unable to reach a verdict and the Court declared a mistrial.

[0001327567-14-000028:notes:116]
On September 13, 2012, we filed with the U.S. Patent and Trademark Office requests for inter partes reexamination of five of the six patents asserted by Juniper in its original complaint. On October 19 and December 3, 2012, the U.S. Patent and Trademark Office granted our requests for reexamination for three patents, rejecting a number of the claims asserted in the litigation, and on November 15 and 26, 2012, the U.S. Patent and Trademark Office denied our requests for reexamination as to two other patents. On June 20, 2013 and July 23, 2013, we filed with the U.S. Patent and Trademark Office petitions for inter partes review for two other patents asserted by Juniper in the litigation. A hearing to resolve claim construction issues, as well as motions for summary judgment, was heard on November 15, 2013.

[0001327567-14-000028:notes:117]
On September 30, 2013, we filed a lawsuit against Juniper in the United States District Court for the Northern District of California. The lawsuit alleged that Juniper’s products infringe three of our U.S. patents, and sought monetary damages and a permanent injunction. On November 21, 2013, Juniper filed an answer and counterclaims in a separate action in the United States District Court for the Northern District of California. In its counterclaims Juniper sought a declaration that the asserted patents owned by us are not infringed and are invalid. Juniper’s counterclaims also asserted that our products infringe three additional Juniper patents.

[0001327567-14-000028:notes:118]
On May 27, 2014, we entered into a Settlement, Release and Cross-License Agreement (the “settlement agreement”) with Juniper to resolve all pending litigation between the parties, including those discussed above. Refer to Note 9. Legal Settlement for more information on the settlement agreement.

[0001327567-14-000028:notes:119]
In addition to the above matter, we are subject to legal proceedings, claims, and litigation arising in the ordinary course of business, including intellectual property litigation. Such matters are subject to many uncertainties and outcomes are not predictable with assurance. We accrue for contingencies when we believe that a loss is probable and that we can reasonably estimate the amount of any such loss. We have made an assessment of the probability of incurring any such losses and whether or not those losses are estimable.

[0001327567-14-000028:notes:120]
To the extent there is a reasonable possibility that a loss exceeding amounts already recognized may be incurred and the amount of such additional loss would be material, we will either disclose the estimated additional loss or state that such an estimate cannot be made.

[0001327567-14-000028:notes:121]
Indemnification

[0001327567-14-000028:notes:122]
Under the indemnification provisions of our standard sales related contracts, we agree to defend our end-customers against third-party claims asserting infringement of certain intellectual property rights, which may include patents, copyrights, trademarks, or trade secrets, and to pay judgments entered on such claims. Our exposure under these indemnification provisions is generally limited to the total amount paid by our end-customer under the agreement. However, certain agreements include indemnification provisions that could potentially expose us to losses in excess of the amount received under the agreement. In addition, we indemnify our officers, directors, and certain key employees while they are serving in good faith in their company capacities. To date, there have been no claims under any indemnification provisions.


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0001327567-14-000028:notes:123]
Employee Benefit Plan

[0001327567-14-000028:notes:124]
We have established a 401(k) tax-deferred savings plan which permits participants to make contributions by salary deduction pursuant to Section 401(k) of the Internal Revenue Code. We are responsible for administrative costs of the plan and have made no contributions to the plan since inception.


## us-gaap:ConvertibleDebtTableTextBlock

[0001327567-14-000028:notes:125]
The Notes consisted of the following as of July 31, 2014 (in thousands):

[0001327567-14-000028:notes:126]
|  | Amount |
| Liability: |  |
| Principal | $ | 575,000 |  |
| Less: debt discount, net of amortization | 108,125 |  |
| Net carrying amount | $ | 466,875 |  |
| Equity | $ | (109,785 | ) |


## us-gaap:DebtDisclosureTextBlock

[0001327567-14-000028:notes:127]
On June 30, 2014, we issued $575,000,000 aggregate principal amount of 0.0% convertible senior notes due 2019. The Notes are governed by an indenture between us, as the issuer, and U.S. Bank National Association, as Trustee. The Notes are unsecured, unsubordinated obligations that do not contain any financial covenants or restrictions on the payments of dividends, the incurrence of indebtedness, or the issuance or repurchase of securities by us or any of our subsidiaries. The Notes mature on July 1, 2019 unless converted or repurchased in accordance with their terms prior to such date. We cannot redeem the Notes prior to maturity.

[0001327567-14-000028:notes:128]
The Notes are convertible for up to 5,214,000 shares of our common stock at an initial conversion rate of approximately 9.068 shares of common stock per $1,000 principal amount, which is equal to an initial conversion price of approximately $110.28 per share of common stock, subject to adjustment. Holders of the Notes may surrender their Notes for conversion at their option at any time prior to the close of business on the business day immediately preceding January 1, 2019, only under the following circumstances:

[0001327567-14-000028:notes:129]
| • | during any fiscal quarter commencing after the fiscal quarter ending on October 31, 2014 (and only during such fiscal quarter), if the last reported sale price of our common stock for at least 20 trading days (whether or not consecutive) during a period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the conversion price for the Notes on each applicable trading day; |

[0001327567-14-000028:notes:130]
| • | during the five business day period after any five consecutive trading day period (the "measurement period"), in which the trading price per $1,000 principal amount of Notes for each trading day of the measurement period was less than 98% of the product of the last reported sale price of our common stock and the conversion rate for the Notes on each such trading day; or |

[0001327567-14-000028:notes:131]
| • | upon the occurrence of specified corporate events. |

[0001327567-14-000028:notes:132]
On or after January 1, 2019, holders may convert all or any portion of their Notes at any time prior to the close of business on the second scheduled trading day immediately preceding the maturity date regardless of the foregoing conditions. Upon conversion, holders will receive cash equal to the aggregate principal amount of the Notes to be converted, and, at our election, cash and/or shares of our common stock for any amounts in excess of the aggregate principal amount of the Notes being converted.

[0001327567-14-000028:notes:133]
The conversion price will be subject to adjustment in some events. Holders of the Notes who convert their Notes in connection with certain corporate events that constitute a “make-whole fundamental change” per the Indenture governing the Notes are, under certain circumstances, entitled to an increase in the conversion rate. Additionally, upon the occurrence of a corporate event that constitutes a “fundamental change” per the Indenture governing the Notes, holders of the Notes may require us to repurchase for cash all or a portion of the Notes at a purchase price equal to 100% of the principal amount of the Notes plus accrued and unpaid contingent interest.

[0001327567-14-000028:notes:134]
In accounting for the issuance of the Notes, we separated the Notes into liability and equity components. The carrying amount of the liability component was calculated by measuring the fair value of a similar liability that does not have an associated convertible feature. The carrying amount of the equity component representing the conversion option was determined by deducting the fair value of the liability component from the par value of the Notes as a whole. The difference between the principal amount of the Notes and the liability component (the "debt discount"), is amortized to interest expense using the effective interest method over the term of the Notes. The equity component of the Notes is included in additional paid-in capital in the consolidated balance sheets and is not remeasured as long as it continues to meet the conditions for equity classification.

[0001327567-14-000028:notes:135]
In accounting for the transaction costs related to the issuance of the Notes, we allocated the total amount incurred to the liability and equity components using the same proportions as the proceeds from the Notes. Transaction costs attributable to the liability component were recorded in other assets in the consolidated balance sheets and are being amortized to interest expense in the consolidated statements of operations using the effective interest method over the term of the Notes. Transaction costs attributable to the equity component were netted with the equity component of the Notes in additional paid-in capital in the consolidated balance sheets. We recorded liability issuance costs, or debt issuance costs, of $12,497,000 and equity issuance costs of $2,949,000.

[0001327567-14-000028:notes:136]
The total estimated fair value of the Notes at July 31, 2014 was $587,087,000. The fair value was determined based on the closing trading price per $100 of the Notes as of the last day of trading for the period. We consider the fair value of the Notes at July 31, 2014 to be a Level 2 measurement. The fair value of the Notes is primarily affected by the trading price of our common stock and market interest rates. Based on the closing price of our common stock of $80.86 on July 31, 2014, the if-converted value of the Notes was less than its principal amount.

[0001327567-14-000028:notes:137]
The following table sets forth total interest expense recognized related to the Notes for the year ended July 31, 2014 (in thousands, except for percentage):

[0001327567-14-000028:notes:138]
|  | Amount |
| Amortization of debt issuance costs | $ | 166 |  |
| Amortization of debt discount | 1,660 |  |
| Total | $ | 1,826 |  |
| Effective interest rate of the liability component | 4.8 | % |

[0001327567-14-000028:notes:139]
Note Hedges

[0001327567-14-000028:notes:140]
To minimize the impact of potential economic dilution upon conversion of the Notes, we entered into convertible note hedge transactions (the "Note Hedges") with respect to our common stock concurrent with the issuance of the Notes. The Note Hedges cover up to 5,214,000 shares of our common stock at a strike price per share that corresponds to the initial conversion price of the Notes, which are also subject to adjustment, and are exercisable upon conversion of the Notes. The Note Hedges will expire upon maturity of the Notes. The Note Hedges are separate transactions and are not part of the terms of the Notes. Holders of the Notes will not have any rights with respect to the Note Hedges. The shares receivable related to the Note Hedges are excluded from the calculation of diluted earnings per share as they are anti-dilutive.

[0001327567-14-000028:notes:141]
We paid an aggregate amount of $110,975,000 for the Note Hedges, which is included in additional paid-in capital in the consolidated balance sheets.

[0001327567-14-000028:notes:142]
Warrants

[0001327567-14-000028:notes:143]
Separately, but concurrently with our issuance of the Notes, we entered into warrant transactions (the “Warrants”) whereby we sold warrants to acquire up to 5,214,000 shares of our common stock at a strike price of approximately $137.85 per share, subject to adjustments. The shares issuable under the Warrants will be included in the calculation of diluted earnings per share when the average market value per share of our common stock for the reporting period exceeds the strike price of the Warrants. The Warrants are separate transactions and are not part of the Notes or Notes Hedges, and are not remeasured through earnings each reporting period. Holders of the Notes and Note Hedges will not have any rights with respect to the Warrants.

[0001327567-14-000028:notes:144]
We received aggregate proceeds of $78,258,000 from the sale of the Warrants, which is included in additional paid-in capital in the consolidated balance sheets.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001327567-14-000028:notes:145]
Equity Award Plans

[0001327567-14-000028:notes:146]
Share-Based Compensation Plans

[0001327567-14-000028:notes:147]
2012 Equity Incentive Plan

[0001327567-14-000028:notes:148]
Our 2012 Equity Incentive Plan (the "2012 Plan") was adopted by our board of directors and approved by the stockholders on June 5, 2012 and was effective one business day prior to the effectiveness of our registration statement for our initial public offering. The 2012 Plan replaced our 2005 Equity Incentive Plan (the “2005 Plan”). Our 2012 Plan provides for the granting of stock options, restricted stock awards, RSUs, stock appreciation rights, performance units, and performance shares to our employees, directors, and consultants.

[0001327567-14-000028:notes:149]
Awards granted under our 2012 Plan vest over the periods determined by the board of directors, generally four years, and expire no more than ten years after the date of grant. In the case of an incentive stock option granted to an employee, who at the time of grant, owns stock representing more than 10% of the total combined voting power of all classes of stock, the exercise price shall be no less than 110% of the fair value per share on the date of grant, and expire five years from the date of grant, and for options granted to any other employee, the per share exercise price shall be no less than 100% of the fair value per share on the date of grant. In the case of a non-statutory stock option and options granted to consultants, the per share exercise price shall be no less than 100% of the fair value per share on the date of grant. Stock that is purchased prior to vesting is subject to our right of repurchase at any time following termination of the participant.

[0001327567-14-000028:notes:150]
RSUs generally vest over a period of three to four years from the date of grant. Until vested, RSUs do not have the voting and dividend participation rights of common stock and the shares underlying the awards are not considered issued and outstanding.

[0001327567-14-000028:notes:151]
A total of 19,941,000 shares of our common stock are reserved for issuance pursuant to the 2012 Plan and includes shares that are (i) reserved but unissued under the 2005 Plan on the effective date of the 2012 Plan or (ii) returned to our 2005 Plan as a result of expiration or termination of options. On the first day of each fiscal year, starting with August 1, 2013, the number of shares in the reserve may be increased by the lesser of (i) 8,000,000 shares, (ii) 4.5% of the outstanding shares of common stock on the last day of our immediately preceding fiscal year, or (iii) such other amount as determined by our board of directors.

[0001327567-14-000028:notes:152]
2012 Employee Stock Purchase Plan

[0001327567-14-000028:notes:153]
Our 2012 Employee Stock Purchase Plan (the "2012 ESPP") was adopted by our board of directors and approved by the stockholders on June 5, 2012 and was effective upon completion of our initial public offering.

[0001327567-14-000028:notes:154]
The 2012 ESPP permits eligible employees to acquire shares of our common stock at 85% of the lower of the fair market value of our common stock on the first trading day of each offering period or on the exercise date. Each offering period will be approximately six months starting on the first trading date on or after March 15 and September 15 of each year, except for the first offering period, which commenced on July 19, 2012 and ended on March 15, 2013. Participants may purchase shares of common stock through payroll deductions of up to 15% of their eligible compensation, subject to purchase limits of 625 shares during a six month period or $25,000 worth of stock for each calendar year.

[0001327567-14-000028:notes:155]
A total of 1,227,000 shares of our common stock are available for sale under the 2012 ESPP as of July 31, 2014. On the first day of each fiscal year, starting with August 1, 2013, the number of shares in the reserve may be increased by the lesser of (i) 2,000,000 shares, (ii) 1% of the outstanding shares of our common stock on the first day of the fiscal year, or (iii) such other amount as determined by our board of directors.

[0001327567-14-000028:notes:156]
2005 Plan

[0001327567-14-000028:notes:157]
Our 2005 Plan was terminated upon the completion of our initial public offering. Awards that were outstanding upon termination remained outstanding pursuant to their original terms.

[0001327567-14-000028:notes:158]
Stock Option Activities

[0001327567-14-000028:notes:159]
A summary of the activity under our stock plans during the reporting period and a summary of information related to options exercisable, vested, and expected to vest are presented below (in thousands, except per share amounts):

[0001327567-14-000028:notes:160]
|  | Options Outstanding |
|  | Number ofShares |  | Weighted- Average Exercise Price |  | Weighted- Average Remaining Contractual Term (Years) |  | Aggregate Intrinsic Value |
| Balance—July 31, 2013 | 10,033 |  |  | $ | 11.74 |  |  | 7.8 |  | $ | 373,228 |  |
| Options granted | — |  |  | — |  |  |  |  |  |
| Options forfeited | (558 | ) |  | 14.62 |  |  |  |  |  |
| Options exercised | (3,645 | ) |  | 9.25 |  |  |  |  |  |
| Balance—July 31, 2014 | 5,830 |  |  | 13.02 |  |  | 7.0 |  | $ | 395,507 |  |
| Options vested and expected to vest—July 31, 2014 | 5,698 |  |  | $ | 12.92 |  |  | 7.0 |  | $ | 387,122 |  |
| Options exercisable—July 31, 2014 | 3,412 |  |  | $ | 10.51 |  |  | 6.8 |  | $ | 240,034 |  |

[0001327567-14-000028:notes:161]
The weighted-average grant-date fair value of employee options granted during the years ended July 31, 2014, 2013, and 2012 was nil, $26.09, and $8.17, respectively. The intrinsic value of employee options exercised during the years ended July 31, 2014, 2013, and 2012 was $198,828,000, $186,845,000, and $20,334,000, respectively. The grant-date fair value of employee options vested during the years ended July 31, 2014, 2013, and 2012 was $17,137,000, $21,351,000, and $6,960,000, respectively.

[0001327567-14-000028:notes:162]
RSU Activities

[0001327567-14-000028:notes:163]
A summary of the activity under our stock plans during the reporting period and a summary of information related to RSUs vested and expected to vest are presented below (in thousands, except per share amounts):

[0001327567-14-000028:notes:164]
|  | RSUs Outstanding |
|  | Number of Shares |  | Weighted- Average Grant-Date Fair Value Per Share |  | Weighted- Average Remaining Contractual Term (Years) |  | Aggregate Intrinsic Value |
| Balance—July 31, 2013 | 2,241 |  |  | $ | 54.36 |  |  | 1.5 |  | $ | 109,675 |  |
| RSUs granted | 5,154 |  |  | 61.00 |  |  |  |  |  |
| RSUs vested | (870 | ) |  | 55.03 |  |  |  |  |  |
| RSUs forfeited | (479 | ) |  | 55.42 |  |  |  |  |  |
| Balance—July 31, 2014 | 6,046 |  |  | $ | 59.84 |  |  | 1.4 |  | $ | 488,880 |  |
| RSUs vested and expected to vest—July 31, 2014 | 5,473 |  |  | $ | 59.65 |  |  | 1.3 |  | $ | 442,547 |  |

[0001327567-14-000028:notes:165]
The weighted-average grant-date fair value of employee RSUs granted during the years ended July 31, 2014, 2013, and 2012 was $61.00, $54.51, and nil, respectively. The aggregate fair value, as of the respective vesting dates, of RSUs vested during the years ended July 31, 2014, 2013, and 2012 was $57,431,000, $272,000, and nil, respectively.

[0001327567-14-000028:notes:166]
Shares Available for Grant

[0001327567-14-000028:notes:167]
The following table presents the stock activity and the total number of shares available for grant as of July 31, 2014 (in thousands):

[0001327567-14-000028:notes:168]
|  | Number of shares |
| Balance at beginning of fiscal year | 8,932 |  |
| Authorized | 3,223 |  |
| RSUs granted | (5,154 | ) |
| Repurchased | 28 |  |
| Options forfeited | 558 |  |
| RSUs forfeited | 479 |  |
| Balance at end of fiscal year | 8,066 |  |

[0001327567-14-000028:notes:169]
Employee Stock Purchase Plan

[0001327567-14-000028:notes:170]
We recognized compensation expense of $4,473,000, $5,263,000, and $172,000 in connection with the 2012 ESPP during the years ended July 31, 2014, 2013, and 2012, respectively. Employees purchased approximately 319,000 shares of common stock at an average exercise price of $40.36 per share during the year ended July 31, 2014.

[0001327567-14-000028:notes:171]
We record share-based compensation awards based on fair value as of the grant date. For option awards and Employee Stock Purchase Plan (ESPP) purchases we use the Black-Scholes option-pricing model to determine fair value. We recognize such costs as compensation expense on a straight-line basis over the employee’s requisite service period. The assumptions for our option-pricing model are determined as follows:

[0001327567-14-000028:notes:172]
Fair Value of Common Stock

[0001327567-14-000028:notes:173]
Prior to our initial public offering, our board of directors considered numerous objective and subjective factors to determine the fair value of our common stock at each meeting at which awards were approved. These factors included, but were not limited to (i) contemporaneous third-party valuations of common stock; (ii) the rights and preferences of convertible preferred stock relative to common stock; (iii) the lack of marketability of common stock; (iv) developments in the business; and (v) the likelihood of achieving a liquidity event, such as an initial public offering or sale of the Company, given prevailing market conditions.

[0001327567-14-000028:notes:174]
Risk-Free Interest Rate

[0001327567-14-000028:notes:175]
We base the risk-free interest rate used in the Black-Scholes valuation model on the implied yield available on U.S. Treasury zero-coupon issues with an equivalent remaining term of the options for each option group.

[0001327567-14-000028:notes:176]
Expected Term

[0001327567-14-000028:notes:177]
The expected term represents the period that our share-based awards are expected to be outstanding. We determined the expected term assumption based on the contractual term of the awards adjusted for estimates of our employees' expected exercise and expected post-vesting termination behavior.

[0001327567-14-000028:notes:178]
Volatility

[0001327567-14-000028:notes:179]
We determine the price volatility factor based on the historical volatilities of our peer group as we do not have sufficient trading history for our common stock.

[0001327567-14-000028:notes:180]
Dividend Yield

[0001327567-14-000028:notes:181]
The expected dividend assumption is based on our current expectations about our anticipated dividend policy.

[0001327567-14-000028:notes:182]
The following table summarizes the assumptions relating to our stock options:

[0001327567-14-000028:notes:183]
|  | Year Ended July 31, |
|  | 2013 |  | 2012 |
| Risk-free interest rate | 1.0% |  | 0.7% - 1.1% |
| Expected term | 6 years |  | 4 – 6 years |
| Volatility | 50% |  | 49% – 51% |
| Dividend yield | —% |  | —% |

[0001327567-14-000028:notes:184]
The following table summarizes the assumptions related to the 2012 ESPP:

[0001327567-14-000028:notes:185]
|  | Year Ended July 31, |
|  | 2014 |  | 2013 |  | 2012 |
| Risk-free interest rate | 0.1% |  | 0.1% |  | 0.1% |
| Expected term | < 1 year |  | < 1 year |  | < 1 year |
| Volatility | 40% |  | 42% |  | 46% |
| Dividend yield | —% |  | —% |  | —% |

[0001327567-14-000028:notes:186]
The following table summarizes share-based compensation included in costs and expenses (in thousands):

[0001327567-14-000028:notes:187]
|  | Year Ended July 31, |
|  | 2014 |  | 2013 |  | 2012 |
| Cost of revenue | $ | 11,070 |  |  | $ | 4,351 |  |  | $ | 774 |  |
| Research and development | 29,524 |  |  | 9,931 |  |  | 3,733 |  |
| Sales and marketing | 42,647 |  |  | 20,493 |  |  | 4,267 |  |
| General and administrative | 16,668 |  |  | 9,101 |  |  | 5,151 |  |
| Total | $ | 99,909 |  |  | $ | 43,876 |  |  | $ | 13,925 |  |

[0001327567-14-000028:notes:188]
At July 31, 2014, total compensation cost related to unvested share-based awards granted to employees but not yet recognized was $320,805,000, net of estimated forfeitures. This cost is expected to be amortized on a straight-line basis over a weighted-average period of three years. Future grants will increase the amount of compensation expense to be recorded in these periods.

[0001327567-14-000028:notes:189]
For fiscal 2014, we accelerated the vesting of certain share-based awards in connection with our acquisitions of Morta and Cyvera and as a result, we recorded $3,446,000 of compensation expense within general and administrative expense.

[0001327567-14-000028:notes:190]
For fiscal 2013, we modified the terms of certain share-based awards for a former employee and as a result, we recorded $1,861,000 of compensation expense within sales and marketing expense.

[0001327567-14-000028:notes:191]
For fiscal 2012, we modified the terms of certain share-based awards for a former employee and as a result, we recorded $854,000 of compensation expense within research and development expense.


## us-gaap:EarningsPerShareTextBlock

[0001327567-14-000028:notes:192]
Net Income (Loss) Per Share

[0001327567-14-000028:notes:193]
We compute net income (loss) per share of common stock using the two-class method required for participating securities. Immediately prior to the completion of our initial public offering on July 19, 2012, all shares of outstanding redeemable convertible preferred stock were automatically converted to common stock. Prior to their conversion, we considered all series of our redeemable convertible preferred stock to be participating securities as the holders were entitled to participate in common stock dividends with common stock on an as-converted basis. The holders of our redeemable convertible preferred stock were also entitled to non-cumulative dividends prior and in preference to common stock and did not have a contractual obligation to share in the losses of the Company. Additionally, we consider shares issued upon the early exercise of options subject to repurchase and unvested restricted shares to be participating securities because holders of such shares have non-forfeitable dividend rights in the event of our declaration of a dividend for common shares. In accordance with the two-class method, earnings allocated to these participating securities, which include participation rights in undistributed earnings with common stock, are subtracted from net income to determine net income (loss) attributable to common stockholders.

[0001327567-14-000028:notes:194]
Basic net income (loss) per common share is computed by dividing net income (loss) attributable to common stockholders by basic weighted-average shares outstanding during the period. All participating securities are excluded from basic weighted-average shares outstanding. In computing diluted net income (loss) attributable to common stockholders, undistributed earnings are re-allocated to reflect the potential impact of dilutive securities. Diluted net income (loss) per share attributable to common stockholders is computed by dividing net income (loss) attributable to common stockholders by diluted weighted-average shares outstanding, including potentially dilutive securities.

[0001327567-14-000028:notes:195]
The following table presents the computation of basic and diluted net income (loss) per share of common stock (in thousands, except per share data):

[0001327567-14-000028:notes:196]
|  | Year Ended July 31, |
|  | 2014 |  | 2013 |  | 2012 |
| Net income (loss) used to compute net income (loss) per share: |  |  |  |  |  |
| Net income (loss) | $ | (226,452 | ) |  | $ | (29,246 | ) |  | $ | 737 |  |
| Less: undistributed earnings allocated to participating securities | — |  |  | — |  |  | (737 | ) |
| Net income (loss) attributable to common stockholders, basic and diluted | $ | (226,452 | ) |  | $ | (29,246 | ) |  | $ | — |  |
| Weighted-average shares used to compute net income (loss) per share attributable to common stockholders: |  |  |  |  |  |
| Weighted-average shares used to compute net income (loss) per share attributable to common stockholders, basic and diluted | 74,291 |  |  | 68,682 |  |  | 19,569 |  |
| Net income (loss) per share attributable to common stockholders, basic and diluted | $ | (3.05 | ) |  | $ | (0.43 | ) |  | $ | 0.00 |  |

[0001327567-14-000028:notes:197]
The following securities were excluded from the computation of diluted net income (loss) per common share applicable to common stockholders for the periods presented as their effect would have been antidilutive (in thousands):

[0001327567-14-000028:notes:198]
|  | Year Ended July 31, |
|  | 2014 |  | 2013 |  | 2012 |
| Options | 5,830 |  |  | 10,033 |  |  | 4,116 |  |
| RSUs | 6,046 |  |  | 2,241 |  |  | — |  |
| ESPP shares | 95 |  |  | 114 |  |  | — |  |
| Convertible senior notes | 5,214 |  |  | — |  |  | — |  |
| Warrants related to the issuance of convertible senior notes | 5,214 |  |  | — |  |  | — |  |


## us-gaap:FairValueAssetsAndLiabilitiesMeasuredOnRecurringAndNonrecurringBasisTableTextBlock

[0001327567-14-000028:notes:199]
The following table presents the fair value of our financial assets and liabilities using the above input categories as of July 31, 2014 and July 31, 2013 (in thousands):

[0001327567-14-000028:notes:200]
|  |  | July 31, 2014 |  | July 31, 2013 |
|  |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Cash equivalents: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Certificates of deposit |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,822 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,822 |  |
| U.S. government and agency securities |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 46,700 |  |  | — |  |  | 46,700 |  |
| Money market funds |  | — |  |  | — |  |  | — |  |  | — |  |  | 131,845 |  |  | — |  |  | — |  |  | 131,845 |  |
| Total cash equivalents |  | — |  |  | — |  |  | — |  |  | — |  |  | 133,667 |  |  | 46,700 |  |  | — |  |  | 180,367 |  |
| Short-term investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate debt securities |  | — |  |  | 22,239 |  |  | — |  |  | 22,239 |  |  | — |  |  | 32,834 |  |  | — |  |  | 32,834 |  |
| U.S. government and agency securities |  | — |  |  | 96,451 |  |  | — |  |  | 96,451 |  |  | — |  |  | 76,173 |  |  | — |  |  | 76,173 |  |
| Total short-term investments |  | — |  |  | 118,690 |  |  | — |  |  | 118,690 |  |  | — |  |  | 109,007 |  |  | — |  |  | 109,007 |  |
| Long-term investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Certificates of deposit |  | — |  |  | 1,000 |  |  | — |  |  | 1,000 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Corporate debt securities |  | — |  |  | 39,018 |  |  | — |  |  | 39,018 |  |  | — |  |  | 12,317 |  |  | — |  |  | 12,317 |  |
| U.S. government and agency securities |  | — |  |  | 161,862 |  |  | — |  |  | 161,862 |  |  | — |  |  | 4,997 |  |  | — |  |  | 4,997 |  |
| Total long-term investments |  | — |  |  | 201,880 |  |  | — |  |  | 201,880 |  |  | — |  |  | 17,314 |  |  | — |  |  | 17,314 |  |
| Other assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Restricted cash |  | 1,220 |  |  | — |  |  | — |  |  | 1,220 |  |  | 1,221 |  |  | — |  |  | — |  |  | 1,221 |  |
| Total other assets |  | 1,220 |  |  | — |  |  | — |  |  | 1,220 |  |  | 1,221 |  |  | — |  |  | — |  |  | 1,221 |  |
| Total assets measured at fair value |  | $ | 1,220 |  |  | $ | 320,570 |  |  | $ | — |  |  | $ | 321,790 |  |  | $ | 134,888 |  |  | $ | 173,021 |  |  | $ | — |  |  | $ | 307,909 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001327567-14-000028:notes:201]
Fair Value Measurements

[0001327567-14-000028:notes:202]
We categorize assets and liabilities recorded at fair value on our consolidated balance sheets based upon the level of judgment associated with inputs used to measure their fair value. The categories are as follows:

[0001327567-14-000028:notes:203]
| • | Level 1—Inputs are unadjusted quoted prices in active markets for identical assets or liabilities. |

[0001327567-14-000028:notes:204]
| • | Level 2—Inputs are quoted prices for similar assets and liabilities in active markets or inputs that are observable for the assets or liabilities, either directly or indirectly through market corroboration, for substantially the full term of the financial instruments. |

[0001327567-14-000028:notes:205]
| • | Level 3—Inputs are unobservable inputs based on our own assumptions used to measure assets and liabilities at fair value. The inputs require significant management judgment or estimation. |

[0001327567-14-000028:notes:206]
Refer to Note 7. Convertible Senior Notes for the carrying amount and estimated fair value of the Notes, which were not recorded at fair value as of July 31, 2014.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001327567-14-000028:notes:207]
The following table presents the components of income (loss) before income taxes (in thousands):

[0001327567-14-000028:notes:208]
|  | Year Ended July 31, |
|  | 2014 |  | 2013 |  | 2012 |
| United States | $ | (149,243 | ) |  | $ | 5,198 |  |  | $ | 1,646 |  |
| Foreign | (72,917 | ) |  | (23,854 | ) |  | 1,153 |  |
| Total | $ | (222,160 | ) |  | $ | (18,656 | ) |  | $ | 2,799 |  |

[0001327567-14-000028:notes:209]
The following table summarizes the provision for income taxes (in thousands):

[0001327567-14-000028:notes:210]
|  | Year Ended July 31, |
|  | 2014 |  | 2013 |  | 2012 |
| Federal: |  |  |  |  |  |
| Current | $ | 795 |  |  | $ | 5,883 |  |  | $ | 525 |  |
| Deferred | — |  |  | — |  |  | — |  |
| State: |  |  |  |  |  |
| Current | 230 |  |  | 1,758 |  |  | 647 |  |
| Deferred | (324 | ) |  | — |  |  | — |  |
| Foreign: |  |  |  |  |  |
| Current | 4,679 |  |  | 3,296 |  |  | 861 |  |
| Deferred | (1,088 | ) |  | (347 | ) |  | 29 |  |
| Total | $ | 4,292 |  |  | $ | 10,590 |  |  | $ | 2,062 |  |

[0001327567-14-000028:notes:211]
The following table presents the items accounting for the difference between income taxes computed at the federal statutory income tax rate and the provision for income taxes:

[0001327567-14-000028:notes:212]
|  | Year Ended July 31, |
|  | 2014 |  | 2013 |  | 2012 |
| Federal statutory rate | 35.0 | % |  | 35.0 | % |  | 34.0 | % |
| Effect of: |  |  |  |  |  |
| State taxes, net of federal tax benefit | 1.3 |  |  | 1.0 |  |  | 9.7 |  |
| Change in valuation allowance | (20.0 | ) |  | (7.3 | ) |  | (85.4 | ) |
| Foreign income at other than U.S. rates | (12.1 | ) |  | (62.4 | ) |  | 17.2 |  |
| Share-based compensation | (3.2 | ) |  | (16.1 | ) |  | 66.6 |  |
| Preferred stock warrant liability | — |  |  | — |  |  | 12.3 |  |
| Meals and entertainment | (0.3 | ) |  | (2.0 | ) |  | 11.9 |  |
| Other, net | (2.6 | ) |  | (5.0 | ) |  | 7.4 |  |
| Total | (1.9 | )% |  | (56.8 | )% |  | 73.7 | % |

[0001327567-14-000028:notes:213]
The following table presents the components of our deferred tax assets and liabilities as of July 31, 2014 and July 31, 2013 (in thousands):

[0001327567-14-000028:notes:214]
|  | July 31, |
|  | 2014 |  | 2013 |
| Deferred tax assets: |  |  |  |
| Accruals and reserves | $ | 38,372 |  |  | $ | 23,461 |  |
| Research and development and foreign tax credits | 8,741 |  |  | 4,702 |  |
| Net operating loss carryforwards | 32,282 |  |  | 2,170 |  |
| Share-based compensation | 17,715 |  |  | 10,619 |  |
| Gross deferred tax assets | 97,110 |  |  | 40,952 |  |
| Valuation allowance | (89,309 | ) |  | (37,659 | ) |
| Total deferred tax assets | 7,801 |  |  | 3,293 |  |
| Deferred tax liabilities: |  |  |  |
| Fixed assets and intangible assets | (15,040 | ) |  | (2,937 | ) |
| Other deferred tax liabilities | (565 | ) |  | — |  |
| Total deferred tax liabilities | (15,605 | ) |  | (2,937 | ) |
| Total | $ | (7,804 | ) |  | $ | 356 |  |

[0001327567-14-000028:notes:215]
A valuation allowance is provided when it is more likely than not that the deferred tax asset will not be realized. Realization of deferred tax assets is dependent upon future taxable income, if any, the amount and timing of which are uncertain. At such time, if it is determined that it is more likely than not that the deferred tax assets are realizable, the valuation allowance will be adjusted. As of July 31, 2014, we have provided a valuation allowance for our federal, state, and certain foreign deferred tax assets that we believe will, more likely than not, be unrealizable. The net valuation allowance increased by approximately $51,650,000 during fiscal 2014, which was primarily attributable to taxable losses in our federal and state jurisdictions.

[0001327567-14-000028:notes:216]
As of July 31, 2014, we had federal, state, and foreign NOL carryforwards of approximately $330,428,000, $233,973,000, and $16,038,000, respectively as reported on our tax returns, available to reduce future taxable income, if any. If not utilized, our federal and state NOL carryforwards will expire in various amounts from the years ending July 31, 2027 through 2034 and July 31, 2017 through 2034, respectively. If not utilized, a portion of our foreign NOL carryforwards will expire in the year ending July 31, 2023. The remainder of our foreign NOL will carry forward indefinitely.

[0001327567-14-000028:notes:217]
As of July 31, 2014, we had federal and state research and development tax credit carryforwards of approximately $9,563,000 and $11,565,000, respectively as reported on our tax returns. If not utilized, the federal credit carryforwards will expire in various amounts from the years ending July 31, 2026 through 2034. The state credit will carry forward indefinitely.

[0001327567-14-000028:notes:218]
As of July 31, 2014, we had foreign tax credit carryforwards of $816,000 as reported on our tax returns.  If not utilized, the foreign tax credit carryforwards will expire in various amounts from the years ending July 31, 2020 through 2024.

[0001327567-14-000028:notes:219]
Utilization of the NOL carryforwards and credits may be subject to a substantial annual limitation due to the ownership change limitations provided by the Internal Revenue Code of 1986, as amended, and similar state provisions. The annual limitation may result in the expiration of NOLs and credits before utilization.

[0001327567-14-000028:notes:220]
We use the with-and-without approach to determine the recognition and measurement of excess tax benefits resulting from share-based awards. Accordingly, we have elected to recognize excess income tax benefits from share-based awards in additional paid-in capital only if an incremental income tax benefit would be realized after considering all other tax attributes presently available to us. As of July 31, 2014, we had excess tax benefits from share-based awards of $257,674,000, $149,759,000, and $5,786,000 included in federal, state, and foreign NOL, respectively. We also had $5,289,000 of excess tax benefits from share-based awards included in federal research and development tax credit. The impact of this excess tax benefit is recognized as additional paid-in capital when it reduces taxes payable. In addition, we have elected to account for the indirect effects of share-based awards on other tax attributes, such as the research, foreign and other tax credits, through the consolidated statements of operations.

[0001327567-14-000028:notes:221]
During the years ended July 31, 2014, 2013, and 2012, we recorded excess tax benefits that resulted from allocating certain tax effects related to exercises of stock options and vesting of RSUs directly to stockholders’ equity in the amount of $957,000, $6,762,000, and $215,000, respectively.

[0001327567-14-000028:notes:222]
As of July 31, 2014, we had $10,385,000 of unrecognized tax benefits, $3,878,000 of which would affect income tax expense if recognized, after consideration of our valuation allowance in the U.S. As of July 31, 2014, our federal, state, and foreign returns for the tax years 2008 through the current period remain open to examination by the major jurisdictions in which we are subject to tax. Fiscal years outside the normal statute of limitation remain open to audit by tax authorities due to tax attributes generated in earlier years which have been carried forward and may be audited in subsequent years when utilized. We do not expect the unrecognized tax benefits to change significantly over the next 12 months. We recognize both interest and penalties associated with uncertain tax positions as a component of income tax expense. During the years ended July 31, 2014, 2013, and 2012, we recognized interest and penalties of $336,000, $222,000, and $72,000, respectively. We had accrued interest and penalties related to unrecognized tax benefits of $630,000 and $294,000 as of July 31, 2014 and 2013, respectively. The ultimate amount and timing of any future cash settlements cannot be predicted with reasonable certainty.

[0001327567-14-000028:notes:223]
The following table presents a reconciliation of the beginning and ending amount of gross unrecognized tax benefits (in thousands):

[0001327567-14-000028:notes:224]
|  | Year Ended July 31, |
|  | 2014 |  | 2013 |  | 2012 |
| Unrecognized tax benefits at the beginning of the period | $ | 6,561 |  |  | $ | 2,630 |  |  | $ | 1,972 |  |
| Additions for tax positions taken in prior years | 428 |  |  | 585 |  |  | 9 |  |
| Reductions for tax positions taken in prior years | — |  |  | (3 | ) |  | — |  |
| Additions for tax positions related to the current year | 3,396 |  |  | 3,349 |  |  | 649 |  |
| Settlements | — |  |  | — |  |  | — |  |
| Lapse of statute of limitations | — |  |  | — |  |  | — |  |
| Unrecognized tax benefits at the end of the period | $ | 10,385 |  |  | $ | 6,561 |  |  | $ | 2,630 |  |

[0001327567-14-000028:notes:225]
As of July 31, 2014, we had approximately $3,810,000 of undistributed earnings in foreign subsidiaries. We expect to permanently reinvest these earnings outside of the U.S. to fund future foreign operations. We project that we will have sufficient cash flow in the U.S. and will not need to repatriate the foreign earnings to finance our domestic operations. If we were to distribute these earnings to the U.S., we would be subject to U.S. income taxes, an adjustment for foreign tax credits, and foreign withholding taxes. We have not recorded a deferred tax liability on any portion of our undistributed earnings in foreign subsidiaries. If we were to repatriate these earnings to the U.S., any associated income tax liability would be insignificant.


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001327567-14-000028:notes:226]
Goodwill and Intangible Assets

[0001327567-14-000028:notes:227]
Goodwill

[0001327567-14-000028:notes:228]
The following table presents details of our goodwill during the year ended July 31, 2014 (in thousands):

[0001327567-14-000028:notes:229]
|  | Gross Carrying Amount |  | Accumulated Impairment Loss |  | Net Carrying Amount |
| Balance as of July 31, 2013 | $ | — |  |  | $ | — |  |  | $ | — |  |
| Goodwill acquired | 155,033 |  |  | — |  |  | 155,033 |  |
| Balance as of July 31, 2014 | $ | 155,033 |  |  | $ | — |  |  | $ | 155,033 |  |

[0001327567-14-000028:notes:230]
Purchased Intangible Assets

[0001327567-14-000028:notes:231]
The following tables present details of our purchased intangible assets as of July 31, 2014 and July 31, 2013 (in thousands):

[0001327567-14-000028:notes:232]
|  | July 31, 2014 |
|  | Gross Carrying Amount |  | Accumulated Amortization |  | Net Carrying Amount |
| Intangible assets with finite lives: |  |  |  |  |  |
| Developed technology | $ | 34,500 |  |  | $ | (1,643 | ) |  | $ | 32,857 |  |
| Acquired intellectual property | 6,546 |  |  | (958 | ) |  | 5,588 |  |
| In-process research and development held for defensive purposes | 1,900 |  |  | (370 | ) |  | 1,530 |  |
| Other | 500 |  |  | (120 | ) |  | 380 |  |
| Total intangible assets with finite lives | 43,446 |  |  | (3,091 | ) |  | 40,355 |  |
| In-process research and development with indefinite lives | 7,600 |  |  | — |  |  | 7,600 |  |
| Total purchased intangible assets | $ | 51,046 |  |  | $ | (3,091 | ) |  | $ | 47,955 |  |

[0001327567-14-000028:notes:233]
|  | July 31, 2013 |
|  | Gross Carrying Amount |  | Accumulated Amortization |  | Net Carrying Amount |
| Acquired intellectual property | $ | 1,546 |  |  | $ | (188 | ) |  | $ | 1,358 |  |

[0001327567-14-000028:notes:234]
We recognized amortization expense of $2,903,000, $125,000, and $39,000 for the years ended July 31, 2014, 2013, and 2012, respectively.

[0001327567-14-000028:notes:235]
The following table summarizes our estimated future amortization expense of intangible assets with finite lives by type as of July 31, 2014 (in thousands):

[0001327567-14-000028:notes:236]
|  | Fiscal Years Ending July 31, |
|  | 2015 |  | 2016 |  | 2017 |  | 2018 |  | 2019 |  | 2020 and Thereafter |
| Developed technology | $ | 4,928 |  |  | $ | 4,928 |  |  | $ | 4,928 |  |  | $ | 4,928 |  |  | $ | 4,928 |  |  | $ | 8,217 |  |
| Acquired intellectual property | 761 |  |  | 704 |  |  | 611 |  |  | 484 |  |  | 399 |  |  | 2,629 |  |
| In-process research and development held for defensive purposes | 633 |  |  | 633 |  |  | 264 |  |  | — |  |  | — |  |  | — |  |
| Other | 250 |  |  | 130 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Total future amortization expense | $ | 6,572 |  |  | $ | 6,395 |  |  | $ | 5,803 |  |  | $ | 5,412 |  |  | $ | 5,327 |  |  | $ | 10,846 |  |


## us-gaap:InvestmentsClassifiedByContractualMaturityDateTableTextBlock

[0001327567-14-000028:notes:237]
The following table summarizes the amortized cost and fair value of our investments as of July 31, 2014, by contractual years-to-maturity (in thousands):

[0001327567-14-000028:notes:238]
|  | Amortized Cost |  | Fair Value |
| Due within one year | $ | 118,678 |  |  | $ | 118,690 |  |
| Due within one to two years | 193,952 |  |  | 193,853 |  |
| Due within two to three years | 8,045 |  |  | 8,027 |  |
| Total | $ | 320,675 |  |  | $ | 320,570 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001327567-14-000028:notes:239]
Unrealized losses related to these investments are due to interest rate fluctuations as opposed to credit quality. In addition, we do not intend to sell and it is not more likely than not that we would be required to sell these investments before recovery of their amortized cost basis, which may be at maturity. As a result, there is no other-than-temporary impairment for these investments at July 31, 2014.

[0001327567-14-000028:notes:240]
We received proceeds of $74,597,000, $13,491,000, and nil from sales of investments during the years ended July 31, 2014, 2013, and 2012, respectively.  We use the specific identification method to determine the cost basis of investments sold. Through July 31, 2014, our realized gains and losses on sales of investments were not material.


## us-gaap:LegalMattersAndContingenciesTextBlock

[0001327567-14-000028:notes:241]
Legal Settlement

[0001327567-14-000028:notes:242]
Settlement, Release and Cross-License Agreement with Juniper

[0001327567-14-000028:notes:243]
On May 27, 2014, we entered into a Settlement, Release and Cross-License Agreement (the "settlement agreement") with Juniper, whereby we resolved all pending litigation matters. Under the terms of the settlement agreement, we agreed to pay Juniper a one-time settlement amount of approximately $175,000,000, which was comprised of $75,000,000 in cash, 1,081,000 shares of our common stock with an approximate value of $70,000,000, and a warrant to purchase 463,000 shares of our common stock with an approximate value of $30,000,000, in exchange for the following:

[0001327567-14-000028:notes:244]
| • | Mutual dismissal with prejudice of all pending litigation between the parties and general release of all liability for Palo Alto Networks and Juniper, |

[0001327567-14-000028:notes:245]
| • | Cross-license between both parties for the patents-in-suit and associated family members and counterparts worldwide for the life of the patents, and |

[0001327567-14-000028:notes:246]
| • | Mutual covenant not to sue for infringement of any other patents for a period of eight years. |

[0001327567-14-000028:notes:247]
For accounting purposes, the fair value of the total consideration as of the settlement date was $182,473,000, which was comprised of $75,000,000 in cash, $75,231,000 in common stock, and $32,242,000 in warrant. The fair values of the common stock and warrant were measured using the closing price of our common stock on the settlement date.

[0001327567-14-000028:notes:248]
The warrant was issued on June 3, 2014 and entitled Juniper to purchase up to 463,000 shares of common stock at an exercise price of $0.0001 per share and was classified as a liability during the period it was outstanding. On July 1, 2014, Juniper exercised the warrant in full. Accordingly, we recorded the change in the fair value of the warrant liability through the exercise date of $5,859,000 within other income (expense), net in the consolidated statement of operations for the year ended July 31, 2014.

[0001327567-14-000028:notes:249]
We accounted for the settlement agreement as a multiple-element arrangement and allocated the fair value of the consideration as of the settlement date to the identifiable elements based on their estimated fair values. Of the total settlement amount, $61,300,000 was allocated to the licensing of intellectual property, $54,300,000 was allocated to the mutual dismissal of claims, and the remaining amount was allocated to the mutual covenant not to sue. The mutual dismissal of claims and the mutual covenant not to sue have no identifiable future benefit, and as a result we recorded a settlement charge within operating expenses in the consolidated statements of operations for the year ended July 31, 2014. The licensing of intellectual property is being amortized over the estimated period of benefit of five years.

[0001327567-14-000028:notes:250]
Mutual Covenant Not to Sue and Release Agreement

[0001327567-14-000028:notes:251]
On January 27, 2014, we executed a Mutual Covenant Not to Sue and Release Agreement with Fortinet, Inc. (“Fortinet”), thereby extending an existing covenant for six more years. We evaluated the transaction as a multiple-element arrangement and allocated the one-time payment that we made in the amount of $20,000,000 to each identifiable element using its relative fair value. Based on our estimates of fair value, we determined that the primary benefit of the arrangement is avoided litigation cost and the release of any potential past claims, with no material value attributable to future use or benefit. Accordingly, we recorded a $20,000,000 settlement charge within operating expenses in the consolidated statements of operatiions for the year ended July 31, 2014.


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0001327567-14-000028:notes:252]
The following table presents details of property and equipment, net as of July 31, 2014 and July 31, 2013 (in thousands):

[0001327567-14-000028:notes:253]
|  | July 31, |
|  | 2014 |  | 2013 |
| Computers, equipment, and software | $ | 38,147 |  |  | $ | 27,239 |  |
| Leasehold improvements | 21,258 |  |  | 10,176 |  |
| Demonstration units | 14,832 |  |  | 11,401 |  |
| Furniture and fixtures | 5,129 |  |  | 2,746 |  |
| Total property and equipment | 79,366 |  |  | 51,562 |  |
| Less: accumulated depreciation | (30,622 | ) |  | (19,476 | ) |
| Total property and equipment, net | $ | 48,744 |  |  | $ | 32,086 |  |


## us-gaap:QuarterlyFinancialInformationTextBlock

[0001327567-14-000028:notes:254]
Selected Quarterly Financial Data (Unaudited)

[0001327567-14-000028:notes:255]
The following tables set forth selected unaudited financial data for the years ended July 31, 2014 and 2013 (in thousands, except per share amounts):

[0001327567-14-000028:notes:256]
|  | Three Months Ended |
|  | Oct. 31,2013 |  | Jan. 31,2014 |  | Apr. 30,2014 |  | Jul. 31,2014 |
| Revenue: |  |  |  |  |  |  |  |
| Product | $ | 75,485 |  |  | $ | 80,823 |  |  | $ | 84,128 |  |  | $ | 99,707 |  |
| Services | 52,695 |  |  | 60,245 |  |  | 66,572 |  |  | 78,524 |  |
| Total revenue | 128,180 |  |  | 141,068 |  |  | 150,700 |  |  | 178,231 |  |
| Cost of revenue: |  |  |  |  |  |  |  |
| Product | 17,954 |  |  | 20,221 |  |  | 20,425 |  |  | 26,903 |  |
| Services | 15,853 |  |  | 17,283 |  |  | 19,285 |  |  | 21,704 |  |
| Total cost of revenue | 33,807 |  |  | 37,504 |  |  | 39,710 |  |  | 48,607 |  |
| Total gross profit | 94,373 |  |  | 103,564 |  |  | 110,990 |  |  | 129,624 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 19,893 |  |  | 24,253 |  |  | 27,837 |  |  | 32,830 |  |
| Sales and marketing | 67,366 |  |  | 76,734 |  |  | 83,995 |  |  | 106,668 |  |
| General and administrative | 14,125 |  |  | 19,733 |  |  | 23,717 |  |  | 15,574 |  |
| Legal settlement (Note 9) | — |  |  | 20,000 |  |  | 121,173 |  |  | — |  |
| Total operating expenses | 101,384 |  |  | 140,720 |  |  | 256,722 |  |  | 155,072 |  |
| Operating loss | (7,011 | ) |  | (37,156 | ) |  | (145,732 | ) |  | (25,448 | ) |
| Interest expense | (8 | ) |  | (14 | ) |  | (13 | ) |  | (1,848 | ) |
| Other income (expense), net | 405 |  |  | (170 | ) |  | 430 |  |  | (5,595 | ) |
| Loss before income taxes | (6,614 | ) |  | (37,340 | ) |  | (145,315 | ) |  | (32,891 | ) |
| Provision for (benefit from) income taxes | 1,247 |  |  | 2,606 |  |  | 1,272 |  |  | (833 | ) |
| Net loss | $ | (7,861 | ) |  | $ | (39,946 | ) |  | $ | (146,587 | ) |  | $ | (32,058 | ) |
| Net loss per share, basic and diluted | $ | (0.11 | ) |  | $ | (0.55 | ) |  | $ | (1.96 | ) |  | $ | (0.41 | ) |

[0001327567-14-000028:notes:257]
|  | Three Months Ended |
|  | Oct. 31,2012 |  | Jan. 31,2013 |  | Apr. 30,2013 |  | Jul. 31,2013 |
| Revenue: |  |  |  |  |  |  |  |
| Product | $ | 55,514 |  |  | $ | 61,944 |  |  | $ | 60,793 |  |  | $ | 65,456 |  |
| Services | 30,420 |  |  | 34,555 |  |  | 40,496 |  |  | 46,929 |  |
| Total revenue | 85,934 |  |  | 96,499 |  |  | 101,289 |  |  | 112,385 |  |
| Cost of revenue: |  |  |  |  |  |  |  |
| Product | 14,416 |  |  | 16,636 |  |  | 15,855 |  |  | 16,505 |  |
| Services | 9,774 |  |  | 10,982 |  |  | 11,835 |  |  | 13,753 |  |
| Total cost of revenue | 24,190 |  |  | 27,618 |  |  | 27,690 |  |  | 30,258 |  |
| Total gross profit | 61,744 |  |  | 68,881 |  |  | 73,599 |  |  | 82,127 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 13,312 |  |  | 15,495 |  |  | 16,048 |  |  | 17,627 |  |
| Sales and marketing | 42,607 |  |  | 45,796 |  |  | 51,733 |  |  | 59,635 |  |
| General and administrative | 8,956 |  |  | 9,747 |  |  | 12,268 |  |  | 11,748 |  |
| Total operating expenses | 64,875 |  |  | 71,038 |  |  | 80,049 |  |  | 89,010 |  |
| Operating loss | (3,131 | ) |  | (2,157 | ) |  | (6,450 | ) |  | (6,883 | ) |
| Interest expense | (40 | ) |  | (7 | ) |  | (18 | ) |  | (9 | ) |
| Other income (expense), net | (32 | ) |  | 63 |  |  | (6 | ) |  | 14 |  |
| Loss before income taxes | (3,203 | ) |  | (2,101 | ) |  | (6,474 | ) |  | (6,878 | ) |
| Provision for income taxes | 312 |  |  | 512 |  |  | 808 |  |  | 8,958 |  |
| Net loss | $ | (3,515 | ) |  | $ | (2,613 | ) |  | $ | (7,282 | ) |  | $ | (15,836 | ) |
| Net loss per share, basic and diluted | $ | (0.05 | ) |  | $ | (0.04 | ) |  | $ | (0.10 | ) |  | $ | (0.22 | ) |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001327567-14-000028:notes:258]
Related Party Transactions

[0001327567-14-000028:notes:259]
Certain members of our board of directors serve as board members or executive officers of certain of our customers and in some cases are also investors of these customers. We believe these transactions with related party customers are carried out on terms that are consistent with similar transactions with our comparable customers. We recognized revenue from sales transactions with significant related party customers of $6,173,000 and $2,623,000 for the years ended July 31, 2014 and 2013, respectively. We did not have any material sales transactions with related party customers in the year ended July 31, 2012. Amounts payable to and due from related party customers were not material at July 31, 2014.


## us-gaap:RevenueFromExternalCustomersByGeographicAreasTableTextBlock

[0001327567-14-000028:notes:260]
The following table presents revenue by geographic theater based on the billing address of the partner (in thousands):

[0001327567-14-000028:notes:261]
|  | Year Ended July 31, |
|  | 2014 |  | 2013 |  | 2012 |
| Revenue: |  |  |  |  |  |
| Americas |  |  |  |  |  |
| United States | $ | 363,174 |  |  | $ | 228,604 |  |  | $ | 151,435 |  |
| Other Americas | 33,452 |  |  | 19,012 |  |  | 10,438 |  |
| Total Americas | 396,626 |  |  | 247,616 |  |  | 161,873 |  |
| EMEA | 126,915 |  |  | 91,496 |  |  | 61,994 |  |
| APAC | 74,638 |  |  | 56,995 |  |  | 31,271 |  |
| Total revenue | $ | 598,179 |  |  | $ | 396,107 |  |  | $ | 255,138 |  |


## us-gaap:ScheduleOfAccruedLiabilitiesTableTextBlock

[0001327567-14-000028:notes:262]
The following table presents details of accrued and other liabilities as of July 31, 2014 and July 31, 2013 (in thousands):

[0001327567-14-000028:notes:263]
|  | July 31, |
|  | 2014 |  | 2013 |
| Accrued expenses payable | $ | 12,210 |  |  | $ | 11,144 |  |
| Other liabilities | 12,790 |  |  | 3,465 |  |
| Total accrued and other liabilities | $ | 25,000 |  |  | $ | 14,609 |  |


## us-gaap:ScheduleOfEntityWideInformationRevenueFromExternalCustomersByProductsAndServicesTextBlock

[0001327567-14-000028:notes:264]
The following table presents revenue for groups of similar product and services (in thousands):

[0001327567-14-000028:notes:265]
|  | Year Ended July 31, |
|  | 2014 |  | 2013 |  | 2012 |
| Revenue: |  |  |  |  |  |
| Product | $ | 340,143 |  |  | $ | 243,707 |  |  | $ | 174,462 |  |
| Services |  |  |  |  |  |
| Subscription | 123,236 |  |  | 71,203 |  |  | 38,698 |  |
| Support and maintenance | 134,800 |  |  | 81,197 |  |  | 41,978 |  |
| Total services | 258,036 |  |  | 152,400 |  |  | 80,676 |  |
| Total revenue | $ | 598,179 |  |  | $ | 396,107 |  |  | $ | 255,138 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001327567-14-000028:notes:266]
Segment Information

[0001327567-14-000028:notes:267]
We conduct business globally and are primarily managed on a geographic theater basis. Our chief operating decision maker reviews financial information presented on a consolidated basis accompanied by information about revenue by geographic region for purposes of allocating resources and evaluating financial performance. We have one business activity and there are no segment managers who are held accountable for operations, operating results, and plans for levels, components, or types of products or services below the consolidated unit level. Accordingly, we are considered to be in a single reportable segment and operating unit structure.

[0001327567-14-000028:notes:268]
Substantially all of our assets were attributable to the Americas operations as of July 31, 2014 and 2013.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001327567-14-000028:notes:269]
Stockholders’ Equity

[0001327567-14-000028:notes:270]
In July 2012, we completed our initial public offering (IPO) whereby 6,200,000 shares of common stock were sold to the public at a price of $42.00 per share. We sold 4,687,000 common shares and selling stockholders sold 1,513,000 common shares. In connection with the exercise of the underwriters’ over-allotment option, 930,000 additional shares of common stock were sold to the public at the initial offering price of $42.00 per share. We received aggregate proceeds of $219,400,000 from the initial public offering and the underwriters’ over-allotment option, net of underwriters’ discounts and commissions, but before deducting offering expenses of approximately $4,000,000. Proceeds from our initial public offering are presented net of offering costs in the consolidated financial statements. Upon the closing of the initial public offering, all shares of our outstanding redeemable convertible preferred stock automatically converted into 41,305,000 shares of common stock.

[0001327567-14-000028:notes:271]
In October 2012, we completed our secondary offering whereby certain stockholders of our company sold 4,800,000 shares of common stock to the public at a price of $63.00 per share. The aggregate offering price for shares sold in the offering was approximately $290,304,000, net of underwriting discounts and commissions. We did not receive any proceeds from the sale of shares in this offering. Offering expenses were paid by the stockholders who sold shares of common stock in the offering.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001327567-14-000028:notes:272]
Other Financial Information

[0001327567-14-000028:notes:273]
We recognized depreciation expense of $14,028,000, $9,786,000, and $6,057,000 related to property and equipment during the years ended July 31, 2014, 2013, and 2012, respectively.
