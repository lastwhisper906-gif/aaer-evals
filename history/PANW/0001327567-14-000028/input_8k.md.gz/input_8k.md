# PANW 8-K — 0001327567-14-000025 filed 2014-09-09

## item codes, every 8-K on or before 2014-09-18

- 2014-09-09 0001327567-14-000025 — 2.02, 9.01
- 2014-07-01 0001193125-14-257824 — 1.01, 2.03, 3.02, 9.01
- 2014-06-26 0001193125-14-249529 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2014-06-20 0001327567-14-000020 — 9.01 — amendment of 0001193125-14-140511
- 2014-06-04 0001327567-14-000016 — 3.02
- 2014-05-30 0001193125-14-218158 — 2.02 — amendment, the index does not say of what
- 2014-05-28 0001193125-14-215060 — 1.01, 2.02, 3.02, 9.01
- 2014-04-11 0001193125-14-140511 — 2.01, 3.02, 7.01, 9.01
- 2014-03-24 0001193125-14-111318 — 1.01, 3.02, 7.01, 9.01
- 2014-03-13 0001327567-14-000009 — 5.02
- 2014-02-24 0001193125-14-063754 — 2.02, 9.01
- 2013-12-12 0001327567-13-000040 — 5.07
- 2013-11-25 0001327567-13-000033 — 2.02, 9.01
- 2013-09-30 0001193125-13-384966 — 8.01
- 2013-09-09 0001193125-13-361421 — 2.02, 9.01
- 2013-05-30 0001193125-13-241542 — 2.02, 5.02, 9.01
- 2013-03-11 0001193125-13-101082 — 5.02, 9.01
- 2013-02-28 0001193125-13-084193 — 2.02, 9.01
- 2012-12-14 0001193125-12-503335 — 5.07
- 2012-12-06 0001193125-12-493700 — 2.02, 9.01
- 2012-09-24 0001193125-12-401534 — 1.01, 2.03
- 2012-09-20 0001193125-12-398433 — 5.02, 9.01
- 2012-09-10 0001193125-12-386605 — 2.02, 9.01

## late-filing notifications on or before 2014-09-18

- none on or before 2014-09-18

## item 2.02 — earnings release, exhibit 99.1

[0001327567-14-000025:8k_2_02:1]
EX-99.1
2
ex991q414earningsrelease.htm
EXHIBIT 99.1

[0001327567-14-000025:8k_2_02:2]
Ex 99.1 (Q4'14 Earnings Release)

[0001327567-14-000025:8k_2_02:3]
Exhibit 99.1

[0001327567-14-000025:8k_2_02:4]
Palo Alto Networks Reports Fiscal Fourth Quarter and Fiscal Year 2014

[0001327567-14-000025:8k_2_02:5]
Financial Results

[0001327567-14-000025:8k_2_02:6]
| • | Fiscal fourth quarter total revenue grows 59 percent year-over-year to a record $178.2 million |

[0001327567-14-000025:8k_2_02:7]
| • | Fiscal year 2014 revenue grows 51 percent year-over-year to $598.2 million |

[0001327567-14-000025:8k_2_02:8]
| • | Fiscal fourth quarter product revenue grows 52 percent year-over-year to $99.7 million; recurring subscription revenue grows 74 percent year-over-year to $37.6 million |

[0001327567-14-000025:8k_2_02:9]
| • | Fiscal fourth quarter billings grow 64 percent year-over-year to a record $232.9 million |

[0001327567-14-000025:8k_2_02:10]
SANTA CLARA, Calif., September 9, 2014 - Palo Alto Networks, Inc. (NYSE: PANW) today announced financial results for its fiscal fourth quarter and fiscal year 2014 ended July 31, 2014.

[0001327567-14-000025:8k_2_02:11]
Total revenue for the fiscal fourth quarter grew 59 percent year-over-year to a record $178.2 million, compared with $112.4 million in the fiscal fourth quarter of 2013. GAAP net loss for the fiscal fourth quarter was $32.1 million, or $0.41 per diluted share, compared with a net loss of $15.8 million, or $0.22 per diluted share, in the fiscal fourth quarter of 2013.

[0001327567-14-000025:8k_2_02:12]
Palo Alto Networks recorded fiscal fourth quarter non-GAAP net income of $9.1 million, or $0.11 per diluted share, compared with non-GAAP net income of $5.5 million, or $0.07 per diluted share, in the fiscal fourth quarter of 2013. A reconciliation between GAAP and non-GAAP information is contained in the tables below.

[0001327567-14-000025:8k_2_02:13]
“We delivered a record finish to fiscal year 2014 with fourth quarter revenue growth driven by continued rapid adoption of our unique enterprise security platform,” said Mark McLaughlin, president and chief executive officer of Palo Alto networks. “Our platform is built from the ground up to solve the most complex security issues and provides tightly integrated and automated detection and prevention capabilities at enterprise-class performance levels. Our results demonstrate that enterprises around the world are turning to Palo Alto Networks as their strategic partner in the cyber security battle.”

[0001327567-14-000025:8k_2_02:14]
For fiscal year 2014, total revenue grew 51 percent to $598.2 million, compared with $396.1 million in fiscal year 2013. GAAP net loss was $226.5 million, or $3.05 per diluted share, in fiscal year 2014, compared with net loss of $29.2 million, or $0.43 per diluted share, in fiscal year 2013. Non-GAAP net

[0001327567-14-000025:8k_2_02:15]
income for fiscal year 2014 was $31.8 million, or $0.40 per diluted share, compared with non-GAAP net income of $18.2 million, or $0.24 per diluted share, in fiscal year 2013.

[0001327567-14-000025:8k_2_02:16]
“We are pleased with our results for the fourth quarter and fiscal year 2014. In the fourth quarter, our land, expand, and retain strategy, combined with our hybrid SaaS revenue model, drove strong sales performance across product, subscription services, and support and maintenance. Our growth continues to substantially outpace that of our competitors and our addressable market - valued today at approximately $16 billion,” said Steffan Tomlinson, chief financial officer of Palo Alto Networks. “Increasing adoption of our subscription services in the quarter contributed to non-GAAP gross margin expansion, both sequentially and year-over-year, as well as adjusted free cash flow of $44.1 million, an increase of 23 percent year over year.”

[0001327567-14-000025:8k_2_02:17]
Recent Highlights

[0001327567-14-000025:8k_2_02:18]
| • | Completed a private placement of convertible senior notes - On June 30, 2014, we completed a private placement of $575 million aggregate principal amount of 0 percent Convertible Senior Notes due 2019. |

[0001327567-14-000025:8k_2_02:19]
| • | Unveiled our new “Unit 42” threat intelligence team - This dedicated team of highly qualified security experts is harnessing the collective expertise of our hundreds of engineers and the unique visibility provided by our enterprise security platform to identify new advanced threats and vulnerabilities and share the valuable intelligence to help our customers and the industry at large protect their computing environments. |

[0001327567-14-000025:8k_2_02:20]
| • | Established global distribution agreement with Westcon Group - Building on our previously established relationship with Westcon in 20 countries, this agreement includes plans to expand our relationship to more than 40 countries by the end of fiscal year 2016 and makes it even more efficient for our resellers to get access to our products, support and services. |

[0001327567-14-000025:8k_2_02:21]
Financial Outlook

[0001327567-14-000025:8k_2_02:22]
Palo Alto Networks provides guidance based on current market conditions and expectations.

[0001327567-14-000025:8k_2_02:23]
For the fiscal first quarter of 2015, Palo Alto Networks expects:

[0001327567-14-000025:8k_2_02:24]
| • | Total revenue in the range of $178 to $182 million, representing year-over-year growth between 39 percent and 42 percent. |

[0001327567-14-000025:8k_2_02:25]
| • | Diluted non-GAAP earnings per share of approximately $0.12 using 83 to 85 million shares. |

[0001327567-14-000025:8k_2_02:26]
2

[0001327567-14-000025:8k_2_02:27]
Guidance for non-GAAP financial measures excludes stock-based compensation, amortization of acquisition-related intangible assets, acquisition expenses, discrete tax benefits, and other non-recurring expenses.  The company has not reconciled diluted non-GAAP earnings per share guidance to net income (loss) per diluted share because the company does not provide guidance on net income (loss) or the various reconciling cash and non-cash items between GAAP net income (loss) and non-GAAP net income (loss).  As items that impact these measures are out of the company’s control and/or cannot be reasonably predicted, the company is unable to provide such guidance.  Accordingly, a reconciliation of the non-GAAP financial measure guidance to the corresponding GAAP measures is not available without unreasonable effort.

[0001327567-14-000025:8k_2_02:28]
Conference Call Information

[0001327567-14-000025:8k_2_02:29]
Palo Alto Networks will host a conference call for analysts and investors to discuss its fiscal fourth quarter and full year 2014 results and outlook for its fiscal first quarter of 2015 today at 4:30 PM Eastern time / 1:30 PM Pacific time. Open to the public, investors may access the call by dialing 1-866-515-2912 or 617-399-5126 and entering the passcode 85248539. A live audio webcast of the conference call along with supplemental financial information will also be accessible from the “Investors” section of the company’s website at investors.paloaltonetworks.com. Following the webcast, an archived version will be available on the website for one year. A telephonic replay of the call will be available two hours after the call and will run for five business days and may be accessed by dialing 1-888-286-8010 or 617-801-6888 and entering the passcode 78312357.

[0001327567-14-000025:8k_2_02:30]
Forward-Looking Statements

[0001327567-14-000025:8k_2_02:31]
This press release contains forward-looking statements that involve risks and uncertainties, including statements regarding the company’s financial outlook for the fiscal first quarter of 2015, growth trends, and continued momentum in the company’s business. There are a significant number of factors that could cause actual results to differ materially from statements made in this press release, including: Palo Alto Networks’ limited operating history; risks associated with Palo Alto Networks’ rapid growth, particularly outside of the United States.; rapidly evolving technological developments in the market for network security products; and general market, political, economic and business conditions.

[0001327567-14-000025:8k_2_02:32]
Additional risks and uncertainties that could affect Palo Alto Networks’ financial results are included under the captions “Risk Factors” and “Management’s Discussion and Analysis of Financial Condition and Results of Operations,” in the company’s quarterly report on Form 10-Q filed with the SEC on June 3,

[0001327567-14-000025:8k_2_02:33]
2014, which is available on the company’s website at investors.paloaltonetworks.com and on the SEC’s website at www.sec.gov. Additional information will also be set forth in other filings that the company makes with the SEC from time to time. All forward-looking statements in this press release are based on information available to the company as of the date hereof, and Palo Alto Networks does not assume any obligation to update the forward-looking statements provided to reflect events that occur or circumstances that exist after the date on which they were made.

[0001327567-14-000025:8k_2_02:34]
Non-GAAP Financial Measures

[0001327567-14-000025:8k_2_02:35]
Palo Alto Networks has provided in this release financial information that has not been prepared in accordance with generally accepted accounting principles in the United States (GAAP). The company uses these non-GAAP financial measures internally in analyzing its financial results and believes that the use of these non-GAAP financial measures is useful to investors as an additional tool to evaluate ongoing operating results and trends and in comparing the company’s financial results with other companies in its industry, many of which present similar non-GAAP financial measures.

[0001327567-14-000025:8k_2_02:36]
Non-GAAP financial measures are not meant to be considered in isolation or as a substitute for comparable GAAP financial measures, and should be read only in conjunction with the company’s consolidated financial statements prepared in accordance with GAAP. A reconciliation of the company’s non-GAAP financial measures to their most directly comparable GAAP measures has been provided in the financial statement tables included in this press release, and investors are encouraged to review the reconciliation.

[0001327567-14-000025:8k_2_02:37]
Non-GAAP net income and diluted net income per share. Palo Alto Networks defines non-GAAP net income as net income (loss) plus share-based compensation expense and related payroll taxes, acquisition related costs, litigation related charges including legal settlements, non-cash interest expense related to the company’s convertible senior notes, and tax adjustments related to the valuation allowance on deferred tax assets and interim tax cost associated with the implementation of the company’s international structure in fiscal fourth quarter of 2013. Palo Alto Networks believes that excluding these items provides management and investors with greater visibility into the underlying performance of the company’s core business operating results, meaning its operating performance excluding these items and, from time to time, other discrete charges that are infrequent in nature, over multiple periods. The company also excludes from non-GAAP net income and non-GAAP diluted net income per share the tax effects, including income tax associated with these items in order to provide a complete picture of the company’s

[0001327567-14-000025:8k_2_02:38]
4

[0001327567-14-000025:8k_2_02:39]
recurring core business operating results. Without excluding these tax effects, investors would only see the gross effect that excluding these expenses had on the company’s operating results.

[0001327567-14-000025:8k_2_02:40]
Billings. Palo Alto Networks defines billings as total revenue plus the change in deferred revenue, net of acquired deferred revenue, during the period. The company’s management monitors billings because billings drive deferred revenue, which is an important indicator of the health and visibility of the company’s business. The company considers billings to be a useful metric for management and investors, particularly as sales of subscriptions increase and the company experiences strong renewal rates for subscriptions and support and maintenance.

[0001327567-14-000025:8k_2_02:41]
Free Cash Flow. Palo Alto Networks defines free cash flow as cash provided by operating activities less purchases of property, equipment, and other assets.  Adjusted Free Cash Flow is defined as Free Cash Flow further adjusted by the one-time $75 million cash payment related to our legal settlement with Juniper. The company considers Free Cash Flow and Adjusted Free Cash Flow to be a liquidity measure that provides useful information to management and investors about the amount of cash generated by the business that, after the purchases of property, equipment, and other assets, can be used for strategic opportunities, including investing in our business, making strategic acquisitions, and strengthening the balance sheet.

[0001327567-14-000025:8k_2_02:42]
Investors are cautioned that there are a number of limitations associated with the use of non-GAAP financial measures as an analytical tool. In particular, many of the adjustments to the company’s GAAP financial measures reflect the exclusion of items that are recurring and will be reflected in the company’s financial results for the foreseeable future, such as share-based compensation.  Share-based compensation is an important part of Palo Alto Networks employees’ compensation and impacts their performance.  In addition, the billings metric reported by the company includes amounts that have not yet been recognized as revenue.  The components that Palo Alto Networks excludes in its calculation of non-GAAP financial measures may differ from the components that its peer companies exclude when they report their non-GAAP results of operations. Palo Alto Networks compensates for these limitations by providing specific information regarding the GAAP amounts excluded from these non-GAAP financial measures. In the future, the company may also exclude non-recurring expenses and other expenses that do not reflect the company’s core business operating results.

[0001327567-14-000025:8k_2_02:43]
ABOUT PALO ALTO NETWORKS

[0001327567-14-000025:8k_2_02:44]
Palo Alto Networks is leading a new era in cybersecurity by protecting thousands of enterprise, government, and service provider networks from cyber threats.  Unlike fragmented legacy products, our security platform safely enables business operations and delivers protection based on what matters most in today's dynamic computing environments: applications, users, and content.  Find out more at www.paloaltonetworks.com.

[0001327567-14-000025:8k_2_02:45]
Palo Alto Networks and the Palo Alto Networks Logo are trademarks of Palo Alto Networks, Inc. in the United States and in jurisdictions throughout the world. All other trademarks, trade names or service marks used or mentioned herein belong to their respective owners.

[0001327567-14-000025:8k_2_02:46]
Media Contact:

[0001327567-14-000025:8k_2_02:47]
Jennifer Jasper Smith

[0001327567-14-000025:8k_2_02:48]
Head of Corporate Communications

[0001327567-14-000025:8k_2_02:49]
Palo Alto Networks

[0001327567-14-000025:8k_2_02:50]
408-638-3280

[0001327567-14-000025:8k_2_02:51]
jjsmith@paloaltonetworks.com

[0001327567-14-000025:8k_2_02:52]
Investor Relations Contact:

[0001327567-14-000025:8k_2_02:53]
Kelsey Turcotte

[0001327567-14-000025:8k_2_02:54]
Vice President of Investor Relations

[0001327567-14-000025:8k_2_02:55]
408-753-3872

[0001327567-14-000025:8k_2_02:56]
kturcotte@paloaltonetworks.com

[0001327567-14-000025:8k_2_02:57]
Chris Danne/Maria Riley

[0001327567-14-000025:8k_2_02:58]
The Blueshirt Group

[0001327567-14-000025:8k_2_02:59]
415-217-7722

[0001327567-14-000025:8k_2_02:60]
ir@paloaltonetworks.com

[0001327567-14-000025:8k_2_02:61]
| Palo Alto Networks, Inc. |
| Preliminary Condensed Consolidated Statements of Operations |
| (In thousands, except per share data) |
| (Unaudited) |
|  | Three Months Ended July 31, |  | Year Ended July 31, |
|  | 2014 |  | 2013 |  | 2014 |  | 2013 |
| Revenue: |  |  |  |  |  |  |  |
| Product | $ | 99,707 |  |  | $ | 65,456 |  |  | $ | 340,143 |  |  | $ | 243,707 |  |
| Services | 78,524 |  |  | 46,929 |  |  | 258,036 |  |  | 152,400 |  |
| Total revenue | 178,231 |  |  | 112,385 |  |  | 598,179 |  |  | 396,107 |  |
| Cost of revenue: |  |  |  |  |  |  |  |
| Product | 26,903 |  |  | 16,505 |  |  | 85,503 |  |  | 63,412 |  |
| Services | 21,704 |  |  | 13,753 |  |  | 74,125 |  |  | 46,344 |  |
| Total cost of revenue | 48,607 |  |  | 30,258 |  |  | 159,628 |  |  | 109,756 |  |
| Total gross profit | 129,624 |  |  | 82,127 |  |  | 438,551 |  |  | 286,351 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 32,830 |  |  | 17,627 |  |  | 104,813 |  |  | 62,482 |  |
| Sales and marketing | 106,668 |  |  | 59,635 |  |  | 334,763 |  |  | 199,771 |  |
| General and administrative | 15,574 |  |  | 11,748 |  |  | 73,149 |  |  | 42,719 |  |
| Legal settlement | — |  |  | — |  |  | 141,173 |  |  | — |  |
| Total operating expenses | 155,072 |  |  | 89,010 |  |  | 653,898 |  |  | 304,972 |  |
| Operating loss | (25,448 | ) |  | (6,883 | ) |  | (215,347 | ) |  | (18,621 | ) |
| Interest expense | (1,848 | ) |  | (9 | ) |  | (1,883 | ) |  | (74 | ) |
| Other income (expense), net | (5,595 | ) |  | 14 |  |  | (4,930 | ) |  | 39 |  |
| Loss before income taxes | (32,891 | ) |  | (6,878 | ) |  | (222,160 | ) |  | (18,656 | ) |
| Provision for (benefit from) income taxes | (833 | ) |  | 8,958 |  |  | 4,292 |  |  | 10,590 |  |
| Net loss | $ | (32,058 | ) |  | $ | (15,836 | ) |  | $ | (226,452 | ) |  | $ | (29,246 | ) |
| Net loss per share, basic and diluted | $ | (0.41 | ) |  | $ | (0.22 | ) |  | $ | (3.05 | ) |  | $ | (0.43 | ) |
| Weighted-average shares used to compute net loss per share, basic and diluted | 77,859 |  |  | 70,936 |  |  | 74,291 |  |  | 68,682 |  |

[0001327567-14-000025:8k_2_02:62]
7

[0001327567-14-000025:8k_2_02:63]
| Palo Alto Networks, Inc. |
| Reconciliation of GAAP to Non-GAAP Financial Measures |
| (In thousands, except per share amounts) |
| (Unaudited) |
|  | Three Months Ended July 31, |  | Year Ended July 31, |
|  | 2014 |  | 2013 |  | 2014 |  | 2013 |
| GAAP net loss | $ | (32,058 | ) |  | $ | (15,836 | ) |  | $ | (226,452 | ) |  | $ | (29,246 | ) |
| Share-based compensation expense | 33,122 |  |  | 14,146 |  |  | 96,463 |  |  | 43,876 |  |
| Share-based payroll tax expense | 938 |  |  | 152 |  |  | 4,825 |  |  | 1,287 |  |
| Acquisition related costs | 329 |  |  | — |  |  | 7,809 |  |  | — |  |
| Amortization expense of acquired intangible assets | 1,453 |  |  | — |  |  | 2,132 |  |  | — |  |
| Litigation related charges [a] | 9,937 |  |  | 1,350 |  |  | 160,384 |  |  | 3,645 |  |
| Non-cash interest expense related to convertible notes | 1,826 |  |  | — |  |  | 1,826 |  |  | — |  |
| Loss on facility sublease | — |  |  | 262 |  |  | — |  |  | 262 |  |
| Income tax and other tax adjustments related to the above [b] | (6,424 | ) |  | 5,462 |  |  | (15,193 | ) |  | (1,592 | ) |
| Non-GAAP net income | $ | 9,123 |  |  | $ | 5,536 |  |  | $ | 31,794 |  |  | $ | 18,232 |  |
| GAAP net loss per share, diluted | $ | (0.41 | ) |  | $ | (0.22 | ) |  | $ | (3.05 | ) |  | $ | (0.43 | ) |
| Share-based compensation expense | 0.42 |  |  | 0.20 |  |  | 1.27 |  |  | 0.62 |  |
| Share-based payroll tax expense | 0.01 |  |  | 0.00 |  |  | 0.06 |  |  | 0.02 |  |
| Acquisition related costs | 0.00 |  |  | 0.00 |  |  | 0.11 |  |  | 0.00 |  |
| Amortization expense of acquired intangible assets | 0.02 |  |  | 0.00 |  |  | 0.03 |  |  | 0.00 |  |
| Litigation related charges [a] | 0.13 |  |  | 0.02 |  |  | 2.16 |  |  | 0.05 |  |
| Non-cash interest expense related to convertible notes | 0.02 |  |  | 0.00 |  |  | 0.02 |  |  | 0.00 |  |
| Loss on facility sublease | 0.00 |  |  | 0.00 |  |  | 0.00 |  |  | 0.00 |  |
| Income tax and other tax adjustments related to the above [b] | (0.08 | ) |  | 0.07 |  |  | (0.20 | ) |  | (0.02 | ) |
| Non-GAAP net income per share, diluted | $ | 0.11 |  |  | $ | 0.07 |  |  | $ | 0.40 |  |  | $ | 0.24 |  |
| GAAP weighted-average shares used to compute net loss per share, diluted | 77,859 |  |  | 70,936 |  |  | 74,291 |  |  | 68,682 |  |
| Weighted-average effect of potentially dilutive securities | 5,092 |  |  | 5,739 |  |  | 5,281 |  |  | 8,768 |  |
| Non-GAAP weighted-average shares used to compute net income per share, diluted | 82,951 |  |  | 76,675 |  |  | 79,572 |  |  | 77,450 |  |
| Revenue | $ | 178,231 |  |  | $ | 112,385 |  |  | $ | 598,179 |  |  | $ | 396,107 |  |
| Change in deferred revenue, net of acquired deferred revenue | 54,645 |  |  | 29,926 |  |  | 173,196 |  |  | 113,422 |  |
| Billings | $ | 232,876 |  |  | $ | 142,311 |  |  | $ | 771,375 |  |  | $ | 509,529 |  |
| Net cash provided by operating activities | $ | (26,150 | ) |  | $ | 41,730 |  |  | $ | 88,406 |  |  | $ | 114,519 |  |
| Less: purchases of property, equipment, and other assets | 4,728 |  |  | 5,847 |  |  | 36,107 |  |  | 22,442 |  |
| Free cash flow | $ | (30,878 | ) |  | $ | 35,883 |  |  | $ | 52,299 |  |  | $ | 92,077 |  |
| Add: cash paid for legal settlement | 75,000 |  |  | — |  |  | 75,000 |  |  | — |  |
| Adjusted free cash flow | $ | 44,122 |  |  | $ | 35,883 |  |  | $ | 127,299 |  |  | $ | 92,077 |  |

[0001327567-14-000025:8k_2_02:64]
___________

[0001327567-14-000025:8k_2_02:65]
[a]    Includes expenses for legal services and settlements, including the legal settlement with Fortinet of $20.0M in Q2’14, the legal settlement with Juniper of $121.2M in Q3’14, the mark-to-market for the warrants issued as part of the settlement with Juniper of $5.9M in Q4’14, and beginning in Q4’14, the amortization of intellectual property licenses entered into as part of the settlement with Juniper of $2.0M.

[0001327567-14-000025:8k_2_02:66]
[b]    Includes the tax effects of the exclusions listed above as well as the adjustment related to the valuation allowance on deferred tax assets and interim tax cost associated with the implementation of the international structure of $10.8M in Q4’13.

[0001327567-14-000025:8k_2_02:67]
8

[0001327567-14-000025:8k_2_02:68]
| Palo Alto Networks, Inc. |
| Preliminary Condensed Consolidated Balance Sheets |
| (In thousands) |
| (Unaudited) |
|  | July 31, 2014 |  | July 31, 2013 |
| Assets |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 653,812 |  |  | $ | 310,614 |  |
| Short-term investments | 118,690 |  |  | 109,007 |  |
| Accounts receivable, net | 135,518 |  |  | 87,461 |  |
| Prepaid expenses and other current assets | 50,306 |  |  | 22,617 |  |
| Total current assets | 958,326 |  |  | 529,699 |  |
| Property and equipment, net | 48,744 |  |  | 32,086 |  |
| Long-term investments | 201,880 |  |  | 17,314 |  |
| Goodwill | 155,033 |  |  | — |  |
| Intangible assets, net | 47,955 |  |  | 1,358 |  |
| Other assets | 66,528 |  |  | 5,149 |  |
| Total assets | $ | 1,478,466 |  |  | $ | 585,606 |  |
| Liabilities and stockholders’ equity |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 14,526 |  |  | $ | 15,544 |  |
| Accrued compensation | 48,727 |  |  | 22,004 |  |
| Accrued and other liabilities | 25,000 |  |  | 14,609 |  |
| Deferred revenue | 259,918 |  |  | 153,945 |  |
| Total current liabilities | 348,171 |  |  | 206,102 |  |
| Convertible senior notes, net | 466,875 |  |  | — |  |
| Long-term deferred revenue | 162,660 |  |  | 95,285 |  |
| Other long-term liabilities | 32,177 |  |  | 11,799 |  |
| Stockholders’ equity: |  |  |  |
| Preferred stock | — |  |  | — |  |
| Common stock | 8 |  |  | 7 |  |
| Additional paid-in capital | 804,406 |  |  | 381,703 |  |
| Accumulated other comprehensive loss | (105 | ) |  | (16 | ) |
| Accumulated deficit | (335,726 | ) |  | (109,274 | ) |
| Total stockholders’ equity | 468,583 |  |  | 272,420 |  |
| Total liabilities and stockholders’ equity | $ | 1,478,466 |  |  | $ | 585,606 |  |

[0001327567-14-000025:8k_2_02:69]
9

[0001327567-14-000025:8k_2_02:70]
| Palo Alto Networks, Inc. |
| Preliminary Condensed Consolidated Statements of Cash Flows |
| (In thousands) |
| (Unaudited) |
|  | Year Ended July 31, |
|  | 2014 |  | 2013 |
| Cash flows from operating activities |  |  |  |
| Net loss | $ | (226,452 | ) |  | $ | (29,246 | ) |
| Adjustments to reconcile net loss to net cash provided by operating activities: |  |  |  |
| Share-based compensation for equity based awards | 99,774 |  |  | 43,704 |  |
| Issuance of common stock for legal settlement | 46,173 |  |  | — |  |
| Depreciation and amortization | 19,419 |  |  | 9,892 |  |
| Amortization of investment premiums, net of accretion of purchase discounts | 1,518 |  |  | 1,943 |  |
| Amortization of debt discount and debt issuance costs | 1,826 |  |  | — |  |
| Change in fair value of common stock warrant | 5,859 |  |  | — |  |
| Excess tax benefit from share-based compensation | (957 | ) |  | (6,762 | ) |
| Loss on facility sublease | — |  |  | 262 |  |
| Changes in operating assets and liabilities, net of effects of acquisitions: |  |  |  |
| Accounts receivable, net | (47,949 | ) |  | (41,819 | ) |
| Prepaid expenses and other assets | (10,308 | ) |  | (8,865 | ) |
| Accounts payable | (1,100 | ) |  | 5,830 |  |
| Accrued compensation | 26,331 |  |  | 10,697 |  |
| Accrued and other liabilities | 1,076 |  |  | 15,461 |  |
| Deferred revenue | 173,196 |  |  | 113,422 |  |
| Net cash provided by operating activities | 88,406 |  |  | 114,519 |  |
| Cash flows from investing activities |  |  |  |
| Purchase of investments | (506,642 | ) |  | (345,324 | ) |
| Proceeds from sales of investments | 74,597 |  |  | 13,491 |  |
| Proceeds from maturities of investments | 233,530 |  |  | 202,710 |  |
| Acquisition of business, net of cash acquired | (85,726 | ) |  | — |  |
| Purchase of property, equipment, and other assets | (36,107 | ) |  | (22,442 | ) |
| Net cash used in investing activities | (320,348 | ) |  | (151,565 | ) |
| Cash flows from financing activities |  |  |  |
| Proceeds from borrowings on convertible senior notes, net | 560,433 |  |  | — |  |
| Proceeds from issuance of warrants | 78,258 |  |  | — |  |
| Purchase of convertible note hedges | (110,975 | ) |  | — |  |
| Proceeds from exercise of stock options | 33,730 |  |  | 14,765 |  |
| Proceeds from employee stock purchase plan | 12,869 |  |  | 6,267 |  |
| Excess tax benefit from share-based compensation | 957 |  |  | 6,762 |  |
| Payments of initial public offering costs | — |  |  | (2,698 | ) |
| Repurchase of restricted common stock from terminated employees | (132 | ) |  | (78 | ) |
| Net cash provided by financing activities | 575,140 |  |  | 25,018 |  |
| Net increase (decrease) in cash and cash equivalents | 343,198 |  |  | (12,028 | ) |
| Cash and cash equivalents - beginning of period | 310,614 |  |  | 322,642 |  |
| Cash and cash equivalents - end of period | $ | 653,812 |  |  | $ | 310,614 |  |

[0001327567-14-000025:8k_2_02:71]
10
