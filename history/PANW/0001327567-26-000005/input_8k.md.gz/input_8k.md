# PANW 8-K — 0001327567-26-000003 filed 2026-02-17

## item codes, every 8-K on or before 2026-02-18

- 2026-02-17 0001327567-26-000003 — 2.02, 9.01
- 2026-02-11 0001193125-26-045600 — 1.01, 2.03, 8.01, 9.01
- 2026-01-29 0001193125-26-029489 — 7.01, 9.01
- 2025-12-11 0001193125-25-315915 — 5.02, 5.07, 9.01
- 2025-11-21 0001193125-25-291350 — 8.01
- 2025-11-19 0001327567-25-000032 — 2.02, 7.01, 8.01, 9.01
- 2025-11-19 0001193125-25-288132 — 5.02, 9.01
- 2025-09-25 0001193125-25-217462 — 8.01
- 2025-08-18 0001327567-25-000024 — 2.02, 5.02, 5.03, 9.01
- 2025-07-31 0001193125-25-169870 — 1.01, 9.01
- 2025-07-30 0001193125-25-168821 — 7.01, 8.01, 9.01
- 2025-05-20 0001327567-25-000015 — 2.02, 9.01
- 2025-02-13 0001327567-25-000006 — 2.02, 9.01
- 2025-02-13 0001327567-25-000004 — 5.02, 9.01
- 2024-12-17 0001193125-24-280058 — 5.02, 9.01
- 2024-12-12 0001193125-24-277082 — 5.02, 5.03, 5.07, 9.01
- 2024-11-20 0001327567-24-000036 — 2.02, 8.01, 9.01
- 2024-11-15 0001193125-24-259308 — 8.01
- 2024-09-04 0001327567-24-000026 — 8.01, 9.01
- 2024-08-19 0001327567-24-000023 — 2.02, 8.01, 9.01
- 2024-05-20 0001327567-24-000015 — 2.02, 9.01
- 2024-05-16 0001327567-24-000010 — 8.01, 9.01
- 2024-02-20 0001327567-24-000003 — 2.02, 9.01
- 2023-12-14 0001193125-23-295527 — 5.02, 5.07, 9.01
- 2023-11-29 0001193125-23-285277 — 8.01, 9.01
- 2023-11-17 0001327567-23-000035 — 8.01, 9.01
- 2023-11-15 0001327567-23-000030 — 2.02, 9.01
- 2023-11-15 0001193125-23-277318 — 8.01
- 2023-08-18 0001327567-23-000020 — 2.02, 9.01
- 2023-06-08 0001193125-23-163506 — 7.01, 9.01
- 2023-06-05 0001193125-23-160228 — 7.01
- 2023-05-23 0001327567-23-000012 — 2.02, 9.01
- 2023-04-19 0001327567-23-000009 — 1.01, 2.03, 9.01
- 2023-02-21 0001327567-23-000005 — 2.02, 9.01
- 2022-12-16 0001193125-22-307346 — 5.02, 5.07
- 2022-11-17 0001327567-22-000035 — 2.02, 9.01
- 2022-11-15 0001193125-22-285017 — 8.01
- 2022-08-22 0001327567-22-000020 — 2.02, 8.01, 9.01
- 2022-05-23 0001193125-22-157474 — 5.02, 5.03, 9.01
- 2022-05-19 0001327567-22-000014 — 2.02, 9.01
- 2022-02-23 0001193125-22-049906 — 5.02
- 2022-02-22 0001327567-22-000006 — 2.02, 9.01
- 2021-12-15 0001193125-21-358074 — 5.02, 5.07
- 2021-11-18 0001327567-21-000037 — 2.02, 9.01
- 2021-10-12 0001193125-21-296438 — 3.01, 7.01, 9.01
- 2021-09-13 0001193125-21-270979 — 7.01, 9.01
- 2021-09-08 0001193125-21-267862 — 5.02, 9.01
- 2021-08-23 0001327567-21-000020 — 2.02, 9.01
- 2021-08-12 0001193125-21-244832 — 5.02, 9.01
- 2021-05-20 0001327567-21-000012 — 2.02, 9.01
- 2021-05-18 0001193125-21-164169 — 5.02 — amendment of 0001193125-21-162161
- 2021-05-14 0001193125-21-162161 — 5.02, 9.01
- 2021-03-19 0001193125-21-087516 — 5.02, 9.01
- 2021-02-22 0001628280-21-002659 — 2.02, 9.01
- 2021-02-22 0001193125-21-049293 — 5.02, 9.01
- 2020-12-18 0001193125-20-321568 — 8.01, 9.01
- 2020-12-16 0001193125-20-319091 — 3.02 — amendment of 0001193125-20-291707
- 2020-12-10 0001193125-20-314920 — 5.07
- 2020-12-08 0001193125-20-312056 — 5.02, 8.01, 9.01
- 2020-11-16 0001327567-20-000037 — 2.02, 9.01
- 2020-11-12 0001193125-20-291707 — 3.02
- 2020-10-19 0001193125-20-272060 — 5.02
- 2020-08-24 0001327567-20-000025 — 2.02, 9.01
- 2020-06-23 0001193125-20-176553 — 5.02, 9.01
- 2020-06-22 0001193125-20-175603 — 5.02, 9.01
- 2020-06-08 0001193125-20-163579 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2020-05-21 0001327567-20-000015 — 2.02, 9.01
- 2020-02-27 0001193125-20-050335 — 1.01, 2.03
- 2020-02-24 0001327567-20-000002 — 2.02, 9.01
- 2019-12-19 0001193125-19-319166 — 1.02, 9.01
- 2019-12-10 0001193125-19-310251 — 5.07
- 2019-11-25 0001327567-19-000036 — 2.02, 9.01
- 2019-11-25 0001193125-19-299886 — 5.02, 8.01 — amendment of 0001327567-19-000011
- 2019-10-22 0001193125-19-271660 — 5.02
- 2019-09-06 0001327567-19-000026 — 9.01 — amendment of 0001327567-19-000023
- 2019-09-04 0001327567-19-000023 — 2.02, 7.01, 9.01
- 2019-07-11 0001193125-19-192415 — 5.02, 9.01
- 2019-05-29 0001327567-19-000014 — 2.02, 9.01
- 2019-04-15 0001327567-19-000011 — 5.02, 9.01
- 2019-04-01 0001193125-19-094613 — 8.01, 9.01
- 2019-03-28 0001193125-19-090572 — 3.02 — amendment of 0001327567-19-000003
- 2019-02-26 0001327567-19-000006 — 2.02, 8.01, 9.01
- 2019-02-19 0001327567-19-000003 — 3.02
- 2018-12-11 0001327567-18-000033 — 5.07
- 2018-11-29 0001327567-18-000029 — 2.02, 9.01
- 2018-10-15 0001193125-18-299312 — 5.02, 9.01
- 2018-09-25 0001193125-18-282542 — 5.02
- 2018-09-14 0001193125-18-274239 — 5.03, 9.01
- 2018-09-06 0001327567-18-000018 — 1.01, 2.02, 2.03, 9.01
- 2018-07-13 0001193125-18-217281 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2018-06-04 0001327567-18-000011 — 2.02, 5.02, 9.01
- 2018-02-26 0001327567-18-000004 — 2.02, 5.02, 7.01, 9.01
- 2017-12-12 0001193125-17-367477 — 5.07
- 2017-11-20 0001327567-17-000032 — 2.02, 5.02, 9.01
- 2017-08-31 0001327567-17-000021 — 2.02, 5.02, 9.01
- 2017-05-31 0001327567-17-000016 — 2.02, 9.01
- 2017-02-28 0001327567-17-000005 — 2.02, 8.01, 9.01
- 2016-12-12 0001193125-16-790757 — 5.07
- 2016-11-21 0001327567-16-000071 — 2.02, 9.01
- 2016-10-24 0001193125-16-745121 — 5.02, 9.01
- 2016-08-30 0001327567-16-000057 — 2.02, 5.03, 8.01, 9.01
- 2016-08-22 0001193125-16-687588 — 5.02, 9.01
- 2016-05-26 0001327567-16-000051 — 2.02, 9.01
- 2016-02-25 0001327567-16-000044 — 2.02, 5.02, 9.01
- 2015-12-14 0001327567-15-000038 — 5.07
- 2015-12-14 0001193125-15-402588 — 1.01, 9.01
- 2015-11-23 0001327567-15-000033 — 2.02, 9.01
- 2015-10-19 0001193125-15-347005 — 1.01, 9.01 — amendment, the index does not say of what
- 2015-09-09 0001327567-15-000022 — 2.02, 9.01
- 2015-08-19 0001193125-15-296115 — 1.01, 2.03
- 2015-06-01 0001193125-15-207786 — 1.01, 2.03
- 2015-05-27 0001327567-15-000015 — 2.02, 9.01
- 2015-03-02 0001327567-15-000006 — 2.02, 9.01
- 2014-12-15 0001327567-14-000046 — 5.07
- 2014-11-24 0001327567-14-000040 — 2.02, 9.01
- 2014-09-22 0001193125-14-348581 — 5.02, 9.01
- 2014-09-09 0001327567-14-000025 — 2.02, 9.01
- 2014-07-01 0001193125-14-257824 — 1.01, 2.03, 3.02, 9.01
- 2014-06-26 0001193125-14-249529 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2014-06-20 0001327567-14-000020 — 9.01 — amendment of 0001193125-14-140511
- 2014-06-04 0001327567-14-000016 — 3.02
- 2014-05-30 0001193125-14-218158 — 2.02 — amendment, the index does not say of what
- 2014-05-28 0001193125-14-215060 — 1.01, 2.02, 3.02, 9.01
- 2014-04-11 0001193125-14-140511 — 2.01, 3.02, 7.01, 9.01
- 2014-03-24 0001193125-14-111318 — 1.01, 3.02, 7.01, 9.01
- 2014-03-13 0001327567-14-000009 — 5.02
- 2014-02-24 0001193125-14-063754 — 2.02, 9.01
- 2013-12-12 0001327567-13-000040 — 5.07
- 2013-11-25 0001327567-13-000033 — 2.02, 9.01
- 2013-09-30 0001193125-13-384966 — 8.01
- 2013-09-09 0001193125-13-361421 — 2.02, 9.01
- 2013-05-30 0001193125-13-241542 — 2.02, 5.02, 9.01
- 2013-03-11 0001193125-13-101082 — 5.02, 9.01
- 2013-02-28 0001193125-13-084193 — 2.02, 9.01
- 2012-12-14 0001193125-12-503335 — 5.07
- 2012-12-06 0001193125-12-493700 — 2.02, 9.01
- 2012-09-24 0001193125-12-401534 — 1.01, 2.03
- 2012-09-20 0001193125-12-398433 — 5.02, 9.01
- 2012-09-10 0001193125-12-386605 — 2.02, 9.01

## late-filing notifications on or before 2026-02-18

- none on or before 2026-02-18

## item 2.02 — earnings release, exhibit 99.1

[0001327567-26-000003:8k_2_02:1]
EX-99.1
2
ex991q226earningsrelease.htm
EX-99.1

[0001327567-26-000003:8k_2_02:2]
Document

[0001327567-26-000003:8k_2_02:3]
Exhibit 99.1

[0001327567-26-000003:8k_2_02:4]
Palo Alto Networks Reports Fiscal Second Quarter 2026 Financial Results

[0001327567-26-000003:8k_2_02:5]
•Fiscal second quarter revenue grew 15% year over year to $2.6 billion.

[0001327567-26-000003:8k_2_02:6]
•Next-Generation Security ARR grew 33% year over year to $6.3 billion.

[0001327567-26-000003:8k_2_02:7]
•Remaining performance obligation grew 23% year over year to $16.0 billion.

[0001327567-26-000003:8k_2_02:8]
SANTA CLARA, Calif., Feb. 17, 2026 — Palo Alto Networks (NASDAQ: PANW), the global cybersecurity leader, announced today financial results for its fiscal second quarter 2026, ended January 31, 2026.

[0001327567-26-000003:8k_2_02:9]
Total revenue for the fiscal second quarter 2026 grew 15% year over year to $2.6 billion, compared with total revenue of $2.3 billion for the fiscal second quarter 2025. GAAP net income for the fiscal second quarter 2026 was $432 million, or $0.61 per diluted share, compared with GAAP net income of $267 million, or $0.38 per diluted share, for the fiscal second quarter 2025.

[0001327567-26-000003:8k_2_02:10]
Non-GAAP net income for the fiscal second quarter 2026 was $732 million, or $1.03 per diluted share, compared with non-GAAP net income of $566 million, or $0.81 per diluted share, for the fiscal second quarter 2025. A reconciliation between GAAP and non-GAAP information is contained in the tables below.

[0001327567-26-000003:8k_2_02:11]
"We saw continued strength in platformizations, a trend that is accelerating due to AI - customers are keen to both modernize and normalize their cybersecurity stack, aligning them to our approach. We also saw steady and strong adoption of AI security, which we expect will be a long term trend," said Nikesh Arora, chairman and CEO of Palo Alto Networks. "We are excited to welcome the employees of Chronosphere and CyberArk to help us drive our growth in the future."

[0001327567-26-000003:8k_2_02:12]
"We once again delivered strong top-line growth, complimented by operating efficiency, with our third straight quarter of 30%-plus non-GAAP operating margins," said Dipak Golechha, chief financial officer of Palo Alto Networks. "We are deploying the same playbook of operational excellence that has guided Palo Alto Networks the last several years across CyberArk and Chronosphere, and look forward to driving significant integration value post-close."

[0001327567-26-000003:8k_2_02:13]
Financial Outlook

[0001327567-26-000003:8k_2_02:14]
Palo Alto Networks provides guidance based on current market conditions and expectations.

[0001327567-26-000003:8k_2_02:15]
For the fiscal third quarter 2026, we expect:

[0001327567-26-000003:8k_2_02:16]
•Next-Generation Security ARR of $7.94 billion to $7.96 billion, representing year-over-year growth of 56%.

[0001327567-26-000003:8k_2_02:17]
•Remaining performance obligation of $17.85 billion to $17.95 billion, representing year-over-year growth of between 32% and 33%.

[0001327567-26-000003:8k_2_02:18]
•Total revenue in the range of $2.941 billion to $2.945 billion, representing year-over-year growth of between 28% and 29%.

[0001327567-26-000003:8k_2_02:19]
•Diluted non-GAAP net income per share in the range of $0.78 to $0.80, using 812 million to 817 million shares outstanding.

[0001327567-26-000003:8k_2_02:20]
For the fiscal year 2026, we expect:

[0001327567-26-000003:8k_2_02:21]
•Next-Generation Security ARR of $8.52 billion to $8.62 billion, representing year-over-year growth of between 53% and 54%.

[0001327567-26-000003:8k_2_02:22]
•Remaining performance obligation of $20.2 billion to $20.3 billion, representing year-over-year growth of 28%.

[0001327567-26-000003:8k_2_02:23]
•Total revenue in the range of $11.28 billion to $11.31 billion, representing year-over-year growth of 22% to 23%.

[0001327567-26-000003:8k_2_02:24]
•Non-GAAP operating margin in the range of 28.5% to 29.0%.

[0001327567-26-000003:8k_2_02:25]
•Diluted non-GAAP net income per share in the range of $3.65 to $3.70, using 768 million to 773 million shares outstanding.

[0001327567-26-000003:8k_2_02:26]
•Adjusted free cash flow margin of 37%.

[0001327567-26-000003:8k_2_02:27]
Guidance for non-GAAP financial measures excludes share-based compensation-related charges, including share-based payroll tax expense, acquisition-related costs, including change in fair value of contingent consideration liability, amortization expense of acquired intangible assets, litigation-related charges, non-cash charges related to convertible notes, and income tax and other tax adjustments related to our long-term non-GAAP effective tax rate, along with certain non-recurring expenses and certain non-recurring cash flows. We have not reconciled non-GAAP operating margin guidance to GAAP operating margin, diluted non-GAAP net income per share guidance to GAAP net income per diluted share, or adjusted free cash flow margin guidance to GAAP net cash from operating activities because we do not provide guidance on GAAP operating margin, GAAP net income or net cash from operating activities and would not be able to present the various reconciling cash and non-cash items between GAAP and non-GAAP financial measures because certain items that impact these measures are uncertain or out of our control, or cannot be reasonably predicted, including share-based compensation expense, without unreasonable effort. The actual amounts of such reconciling items will have a significant impact on the company's GAAP net income per diluted share and GAAP net cash from operating activities.

[0001327567-26-000003:8k_2_02:28]
Earnings Call Information

[0001327567-26-000003:8k_2_02:29]
Palo Alto Networks will host a video webcast for analysts and investors to discuss the company’s fiscal second quarter 2026 results as well as the outlook for its fiscal second quarter and fiscal year 2026 today at 4:30 p.m. Eastern time/1:30 p.m. Pacific time. Open to the public, investors may access the webcast, supplemental financial information and earnings slides from the "Investors" section of the company’s website at investors.paloaltonetworks.com. A replay will be available three hours after the conclusion of the webcast and archived for one year.

[0001327567-26-000003:8k_2_02:30]
Forward-Looking Statements

[0001327567-26-000003:8k_2_02:31]
This press release contains forward-looking statements that involve risks, uncertainties and assumptions including statements regarding our platformization strategy and financial outlook for the fiscal third quarter 2026 and fiscal year 2026. There are a significant number of factors that could cause actual results to differ materially from forward-looking statements made or implied in this press release, including: developments and changes in general market, political, economic, and business conditions; failure of our platformization product offerings; failure to achieve the expected benefits of our strategic partnerships and acquisitions; changes in the fair value of our contingent consideration liability associated with acquisitions; our ability to successfully integrate the businesses, operations and technologies of companies and businesses that we acquire; the risk that the expected benefits and synergies of our acquisitions may not be fully achieved in a timely manner, or at all; the risk that we will be unable to retain and hire key personnel; significant and/or unanticipated difficulties, liabilities, or expenditures related to our acquisitions; the effect of the announcement, pendency or completion of acquisitions on our (including the companies that we acquire) business relationships and business operations generally; the effect of our acquisitions on our common share price and uncertainty as to the long-term value of our common stock; risks related to disruption of management time from ongoing business operations due to our acquisitions; risks associated with managing our growth; risks associated with new product, subscription and support offerings, including our product offerings that leverage AI and the expansion of our offerings into the identity security and observability spaces; shifts in priorities or delays in the development or release of new product or subscription or other offerings, or the failure to timely develop and achieve market acceptance of new products and subscriptions as well as existing products, subscriptions and support offerings; failure of our business strategies; rapidly evolving technological developments in the market for security products, subscriptions and support offerings; defects, errors, or vulnerabilities in our products, subscriptions or support offerings; our customers’ purchasing decisions and the length of sales cycles; our competition; our ability to attract and retain new customers; our ability to acquire and integrate other companies, products, or technologies in a successful manner; our debt repayment obligations; and our share repurchase program, which may not be fully consummated or enhance shareholder value, and any share repurchases which could affect the price of our common stock.

[0001327567-26-000003:8k_2_02:32]
For additional risks and uncertainties on these and other factors that could affect our financial results and cause actual results to differ materially from those described in the forward-looking statements we make in this press release are included under the captions "Risk Factors" and "Management's Discussion and Analysis of Financial Condition and Results of Operations" and elsewhere in our Quarterly Report on Form 10-Q filed with the U.S. Securities and Exchange Commission (SEC) on November 20, 2025, which is available on our website at investors.paloaltonetworks.com and on the SEC's website at www.sec.gov. Additional information will also be set forth in other documents that we file with or furnish to the SEC from time to time. All forward-looking statements in this press release are based on our current beliefs and information available to management as of the date hereof and are inherently uncertain, and we do not assume any obligation to update the forward-looking statements provided to reflect events that occur or circumstances that exist after the date on which they were made.

[0001327567-26-000003:8k_2_02:33]
Non-GAAP Financial Measures and Other Key Metrics

[0001327567-26-000003:8k_2_02:34]
Palo Alto Networks has provided in this press release financial information that has not been prepared in accordance with generally accepted accounting principles in the United States (GAAP). The company uses these non-GAAP financial measures and other key metrics internally in analyzing its financial results and believes that the use of these non-GAAP financial measures and key metrics are helpful to investors as an additional tool to evaluate ongoing operating results and trends, and in comparing the company’s financial results with other companies in its industry, many of which present similar non-GAAP financial measures or key metrics.

[0001327567-26-000003:8k_2_02:35]
The presentation of these non-GAAP financial measures and key metrics are not meant to be considered in isolation or as a substitute for comparable GAAP financial measures and should be read only in conjunction with the company’s consolidated financial statements prepared in accordance with GAAP. A reconciliation of the company’s historical non-GAAP financial measures to their most directly comparable GAAP measures has been provided in the financial statement tables included in this press release, and investors are encouraged to review these reconciliations.

[0001327567-26-000003:8k_2_02:36]
Non-GAAP operating margin. Palo Alto Networks defines non-GAAP operating margin as non-GAAP operating income divided by total revenue. The company defines non-GAAP operating income as operating income plus share-based compensation-related charges, including share-based payroll tax expense, acquisition-related costs, including change in fair value of contingent consideration liability, amortization expense of acquired intangible assets, and litigation-related charges. The company believes that non-GAAP operating margin provides management and investors with greater visibility into the underlying performance of the company’s core business operating results.

[0001327567-26-000003:8k_2_02:37]
Non-GAAP net income and net income per share, diluted. Palo Alto Networks defines non-GAAP net income as net income plus share-based compensation-related charges, including share-based payroll tax expense, acquisition-related costs, including change in fair value of contingent consideration liability, amortization expense of acquired intangible assets, litigation-related charges, and non-cash charges related to convertible notes. The company also excludes from non-GAAP net income tax adjustments related to our long-term non-GAAP effective tax rate in order to provide a complete picture of the company’s recurring core business operating results. The company defines non-GAAP net income per share, diluted, as non-GAAP net income divided by the weighted-average diluted shares outstanding, which includes the potentially dilutive effect of the company’s employee equity incentive plan awards and the company’s convertible senior notes and related warrants, after giving effect to the anti-dilutive impact of the company’s note hedge agreements, which reduced the potential economic dilution that otherwise would have occurred in connection with the conversion and settlement of the company’s convertible senior notes. Under GAAP, the anti-dilutive impact of the note hedge is not reflected in diluted shares outstanding. The company considers these non-GAAP financial measures to be useful metrics for management and investors for the same reasons that it uses non-GAAP operating margin.

[0001327567-26-000003:8k_2_02:38]
Next-Generation Security ARR. Palo Alto Networks defines Next-Generation Security ARR as the annualized allocated revenue of all active contracts as of the final day of the reporting period related to all product, subscription and support offerings, excluding revenue from hardware products, and legacy attached subscriptions, support offerings and professional services. The company considers Next-Generation Security ARR to be a useful operating metric for management and investors to assess the performance of the company because Next-Generation Security is where the company has focused its innovation and the company expects its overall revenue to be disproportionately driven by this Next-Generation Security portfolio. Because Next-Generation Security ARR does not have the effect of providing a numerical measure that is different from any comparable GAAP measure, the company does not consider it a non-GAAP measure.

[0001327567-26-000003:8k_2_02:39]
Investors are cautioned that there are a number of limitations associated with the use of non-GAAP financial measures and key metrics as analytical tools. Many of the adjustments to the company’s GAAP financial measures reflect the exclusion of items that are recurring and will be reflected in the company’s financial results for the foreseeable future, such as share-based compensation, which is an important part of Palo Alto Networks employees’ compensation and impacts their performance. Furthermore, these non-GAAP financial measures are not based on any standardized methodology prescribed by GAAP, and the components that Palo Alto Networks excludes in its calculation of non-GAAP financial measures may differ from the components that its peer companies exclude when they report their non-GAAP results of operations. Palo Alto Networks compensates for these limitations by providing specific information regarding the GAAP amounts excluded from these non-GAAP financial measures. In the future, the company may also exclude non-recurring expenses and other expenses that do not reflect the company’s core business operating results.

[0001327567-26-000003:8k_2_02:40]
About Palo Alto Networks

[0001327567-26-000003:8k_2_02:41]
Palo Alto Networks (NASDAQ: PANW), the global AI cybersecurity leader, protects our digital way of life with a comprehensive portfolio of cybersecurity solutions and platforms across Network, Cloud, Security Operations, AI and Identity. Trusted by over 70,000 customers and powered by Unit 42® threat intelligence, our AI-driven platforms eliminate complexity, empowering enterprises to modernize with confidence and securing the speed of innovation. Explore the future of security at www.paloaltonetworks.com.

[0001327567-26-000003:8k_2_02:42]
Palo Alto Networks and the Palo Alto Networks logo are trademarks of Palo Alto Networks, Inc. in the United States or in certain jurisdictions throughout the world. All other trademarks, trade names, or service marks used or mentioned herein belong to their respective owners. Any unreleased services or features (and any services or features not generally available to customers) referenced in this or other press releases or public statements are not currently available (or are not yet generally available to customers) and may not be delivered when expected or at all. Customers who purchase Palo Alto Networks applications should make their purchase decisions based on services and features currently generally available.

[0001327567-26-000003:8k_2_02:43]
Media Contact:

[0001327567-26-000003:8k_2_02:44]
Nicole Hockin

[0001327567-26-000003:8k_2_02:45]
VP, Global Communications, Palo Alto Networks

[0001327567-26-000003:8k_2_02:46]
press@paloaltonetworks.com

[0001327567-26-000003:8k_2_02:47]
Investor Relations Contact:

[0001327567-26-000003:8k_2_02:48]
Ryan Fenwick

[0001327567-26-000003:8k_2_02:49]
Director, Investor Relations, Palo Alto Networks

[0001327567-26-000003:8k_2_02:50]
ir@paloaltonetworks.com

[0001327567-26-000003:8k_2_02:51]
1

[0001327567-26-000003:8k_2_02:52]
| Palo Alto Networks, Inc. |
| Preliminary Condensed Consolidated Statements of Operations |
| (In millions, except per share data) |
| (Unaudited) |
|  | Three Months Ended |  | Six Months Ended |
|  | January 31, |  | January 31, |
|  | 2026 |  | 2025 |  | 2026 |  | 2025 |
| Revenue: |  |  |  |  |  |  |  |
| Product | $ | 514 |  |  | $ | 421 |  |  | $ | 948 |  |  | $ | 775 |  |
| Subscription and support | 2,080 |  |  | 1,836 |  |  | 4,120 |  |  | 3,621 |  |
| Total revenue | 2,594 |  |  | 2,257 |  |  | 5,068 |  |  | 4,396 |  |
| Cost of revenue: |  |  |  |  |  |  |  |
| Product | 115 |  |  | 101 |  |  | 204 |  |  | 176 |  |
| Subscription and support | 570 |  |  | 498 |  |  | 1,119 |  |  | 977 |  |
| Total cost of revenue | 685 |  |  | 599 |  |  | 1,323 |  |  | 1,153 |  |
| Total gross profit | 1,909 |  |  | 1,658 |  |  | 3,745 |  |  | 3,243 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 511 |  |  | 505 |  |  | 1,039 |  |  | 986 |  |
| Sales and marketing | 823 |  |  | 758 |  |  | 1,643 |  |  | 1,478 |  |
| General and administrative | 178 |  |  | 154 |  |  | 357 |  |  | 252 |  |
| Total operating expenses | 1,512 |  |  | 1,417 |  |  | 3,039 |  |  | 2,716 |  |
| Operating income | 397 |  |  | 241 |  |  | 706 |  |  | 527 |  |
| Interest expense | — |  |  | (1) |  |  | — |  |  | (2) |  |
| Other income, net | 152 |  |  | 85 |  |  | 255 |  |  | 168 |  |
| Income before income taxes | 549 |  |  | 325 |  |  | 961 |  |  | 693 |  |
| Provision for income taxes | 117 |  |  | 58 |  |  | 195 |  |  | 75 |  |
| Net income | $ | 432 |  |  | $ | 267 |  |  | $ | 766 |  |  | $ | 618 |  |
| Net income per share, basic | $ | 0.61 |  |  | $ | 0.41 |  |  | $ | 1.10 |  |  | $ | 0.94 |  |
| Net income per share, diluted | $ | 0.61 |  |  | $ | 0.38 |  |  | $ | 1.07 |  |  | $ | 0.87 |  |
| Weighted-average shares used to compute net income per share, basic | 704 |  |  | 659 |  |  | 695 |  |  | 657 |  |
| Weighted-average shares used to compute net income per share, diluted | 711 |  |  | 709 |  |  | 713 |  |  | 709 |  |

[0001327567-26-000003:8k_2_02:53]
2

[0001327567-26-000003:8k_2_02:54]
| Palo Alto Networks, Inc. |
| Reconciliation of GAAP to Non-GAAP Financial Measures |
| (In millions, except per share amounts) |
| (Unaudited) |
|  | Three Months Ended |  | Six Months Ended |
|  | January 31, |  | January 31, |
|  | 2026 |  | 2025 |  | 2026 |  | 2025 |
| GAAP operating income | $ | 397 |  |  | $ | 241 |  |  | $ | 706 |  |  | $ | 527 |  |
| Share-based compensation-related charges | 321 |  |  | 344 |  |  | 708 |  |  | 659 |  |
| Acquisition-related costs(1) | 24 |  |  | 10 |  |  | 29 |  |  | 25 |  |
| Amortization expense of acquired intangible assets | 38 |  |  | 43 |  |  | 77 |  |  | 84 |  |
| Litigation-related charges(2) | 5 |  |  | 3 |  |  | 11 |  |  | (38) |  |
| Non-GAAP operating income | $ | 785 |  |  | $ | 641 |  |  | $ | 1,531 |  |  | $ | 1,257 |  |
| Non-GAAP operating margin | 30.3 | % |  | 28.4 | % |  | 30.2 | % |  | 28.6 | % |
| GAAP net income | $ | 432 |  |  | $ | 267 |  |  | $ | 766 |  |  | $ | 618 |  |
| Share-based compensation-related charges | 321 |  |  | 344 |  |  | 708 |  |  | 659 |  |
| Acquisition-related costs(1) | 24 |  |  | 10 |  |  | 29 |  |  | 25 |  |
| Amortization expense of acquired intangible assets | 38 |  |  | 43 |  |  | 77 |  |  | 84 |  |
| Litigation-related charges(2) | 5 |  |  | 3 |  |  | 11 |  |  | (38) |  |
| Non-cash charges related to convertible notes(3) | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Income tax and other tax adjustments(4) | (88) |  |  | (102) |  |  | (197) |  |  | (238) |  |
| Non-GAAP net income | $ | 732 |  |  | $ | 566 |  |  | $ | 1,394 |  |  | $ | 1,111 |  |
| GAAP net income per share, diluted | $ | 0.61 |  |  | $ | 0.38 |  |  | $ | 1.07 |  |  | $ | 0.87 |  |
| Share-based compensation-related charges | 0.45 |  |  | 0.50 |  |  | 0.99 |  |  | 0.96 |  |
| Acquisition-related costs(1) | 0.03 |  |  | 0.01 |  |  | 0.04 |  |  | 0.03 |  |
| Amortization expense of acquired intangible assets | 0.05 |  |  | 0.06 |  |  | 0.11 |  |  | 0.12 |  |
| Litigation-related charges(2) | 0.01 |  |  | 0.00 |  |  | 0.02 |  |  | (0.05) |  |
| Non-cash charges related to convertible notes(3) | 0.00 |  |  | 0.00 |  |  | 0.00 |  |  | 0.00 |  |
| Income tax and other tax adjustments(4) | (0.12) |  |  | (0.14) |  |  | (0.28) |  |  | (0.34) |  |
| Non-GAAP net income per share, diluted | $ | 1.03 |  |  | $ | 0.81 |  |  | $ | 1.95 |  |  | $ | 1.59 |  |
| GAAP weighted-average shares used to compute net income per share, diluted | 711 |  |  | 709 |  |  | 713 |  |  | 709 |  |
| Weighted-average anti-dilutive impact of note hedge agreements | — |  |  | (9) |  |  | — |  |  | (10) |  |
| Non-GAAP weighted-average shares used to compute net income per share, diluted | 711 |  |  | 700 |  |  | 713 |  |  | 699 |  |

[0001327567-26-000003:8k_2_02:55]
(1)    Consists of acquisition transaction costs, share-based compensation related to the cash settlement of certain equity awards, change in fair value of contingent consideration liability, and costs to terminate certain employment, operating lease, and other contracts of the acquired companies. During the three and six months ended January 31, 2026, it also includes integration costs related to our acquisition of CyberArk Software Ltd.

[0001327567-26-000003:8k_2_02:56]
(2)    Consists of the amortization of intellectual property licenses and covenant not to sue, and legal contingency charges (credit). During the three and six months ended January 31, 2026, it also includes a litigation settlement charge.

[0001327567-26-000003:8k_2_02:57]
(3)    Consists of non-cash interest expense for amortization of debt issuance costs related to the company's convertible senior notes.

[0001327567-26-000003:8k_2_02:58]
(4)    Consists of income tax adjustments related to our long-term non-GAAP effective tax rate.

[0001327567-26-000003:8k_2_02:59]
3

[0001327567-26-000003:8k_2_02:60]
| Palo Alto Networks, Inc. |
| Preliminary Condensed Consolidated Balance Sheets |
| (In millions) |
|  | January 31, 2026 |  | July 31, 2025 |
|  | (unaudited) |  |  |
| Assets |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 4,158 |  |  | $ | 2,269 |  |
| Short-term investments | 378 |  |  | 635 |  |
| Accounts receivable, net | 2,116 |  |  | 2,965 |  |
| Short-term financing receivables, net | 672 |  |  | 715 |  |
| Short-term deferred contract costs | 424 |  |  | 419 |  |
| Prepaid expenses and other current assets | 621 |  |  | 520 |  |
| Total current assets | 8,369 |  |  | 7,523 |  |
| Property and equipment, net | 485 |  |  | 387 |  |
| Operating lease right-of-use assets | 368 |  |  | 347 |  |
| Long-term investments | 3,362 |  |  | 5,555 |  |
| Long-term financing receivables, net | 870 |  |  | 1,002 |  |
| Long-term deferred contract costs | 526 |  |  | 586 |  |
| Goodwill | 6,931 |  |  | 4,567 |  |
| Intangible assets, net | 1,249 |  |  | 763 |  |
| Deferred tax assets | 2,392 |  |  | 2,424 |  |
| Other assets | 427 |  |  | 422 |  |
| Total assets | $ | 24,979 |  |  | $ | 23,576 |  |
| Liabilities and stockholders’ equity |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 262 |  |  | $ | 232 |  |
| Accrued compensation | 562 |  |  | 608 |  |
| Accrued and other liabilities | 937 |  |  | 846 |  |
| Deferred revenue | 6,248 |  |  | 6,302 |  |
| Total current liabilities | 8,009 |  |  | 7,988 |  |
| Long-term deferred revenue | 6,181 |  |  | 6,450 |  |
| Deferred tax liabilities | 75 |  |  | 89 |  |
| Long-term operating lease liabilities | 372 |  |  | 338 |  |
| Other long-term liabilities | 949 |  |  | 887 |  |
| Total liabilities | 15,586 |  |  | 15,752 |  |
| Stockholders’ equity: |  |  |  |
| Preferred stock | — |  |  | — |  |
| Common stock and additional paid-in capital | 6,097 |  |  | 5,292 |  |
| Accumulated other comprehensive income | 46 |  |  | 48 |  |
| Retained earnings | 3,250 |  |  | 2,484 |  |
| Total stockholders’ equity | 9,393 |  |  | 7,824 |  |
| Total liabilities and stockholders’ equity | $ | 24,979 |  |  | $ | 23,576 |  |

[0001327567-26-000003:8k_2_02:61]
4
