# PANW MD&A — 0001327567-26-000005


## mdna

[0001327567-26-000005:mdna:1]
[same as prior period, unchanged from 0001327567-25-000035:mdna:1]

[0001327567-26-000005:mdna:2]
[same as prior period, unchanged from 0001327567-25-000035:mdna:2]

[0001327567-26-000005:mdna:3]
[same as prior period, unchanged from 0001327567-25-000035:mdna:3]

[0001327567-26-000005:mdna:4]
[same as prior period, unchanged from 0001327567-25-000035:mdna:4]

[0001327567-26-000005:mdna:5]
•Results of Operations. A discussion of the nature and trends in our financial results and an analysis of our financial results comparing the three and six months ended January 31, 2026 to the three and six months ended January 31, 2025.

[0001327567-26-000005:mdna:6]
[same as prior period, unchanged from 0001327567-25-000035:mdna:6]

[0001327567-26-000005:mdna:7]
[same as prior period, unchanged from 0001327567-25-000035:mdna:7]

[0001327567-26-000005:mdna:8]
[same as prior period, unchanged from 0001327567-25-000035:mdna:8]

[0001327567-26-000005:mdna:9]
[same as prior period, unchanged from 0001327567-25-000035:mdna:33]

[0001327567-26-000005:mdna:10]
[same as prior period, unchanged from 0001327567-25-000035:mdna:10]

[0001327567-26-000005:mdna:11]
[same as prior period, unchanged from 0001327567-25-000035:mdna:11]

[0001327567-26-000005:mdna:12]
[same as prior period, unchanged from 0001327567-25-000035:mdna:12]

[0001327567-26-000005:mdna:13]
[same as prior period, unchanged from 0001327567-25-000035:mdna:13]

[0001327567-26-000005:mdna:14]
[same as prior period, unchanged from 0001327567-25-000035:mdna:14]

[0001327567-26-000005:mdna:15]
[same as prior period, unchanged from 0001327567-25-000035:mdna:15]

[0001327567-26-000005:mdna:16]
[same as prior period, unchanged from 0001327567-25-000035:mdna:16]

[0001327567-26-000005:mdna:17]
[same as prior period, unchanged from 0001327567-25-000035:mdna:17]

[0001327567-26-000005:mdna:18]
[same as prior period, unchanged from 0001327567-25-000035:mdna:18]

[0001327567-26-000005:mdna:19]
[same as prior period, unchanged from 0001327567-25-000035:mdna:19]

[0001327567-26-000005:mdna:20]
[same as prior period, unchanged from 0001327567-25-000035:mdna:20]

[0001327567-26-000005:mdna:21]
•Security Operations. We deliver the next generation of security operations capabilities that unifies standalone Security Information and Event Management (“SIEM”) tools, endpoint security, security automation, cloud detection and response (“CDR”), as well as attack surface management (“ASM”) capabilities on our Cortex® platform. These include Cortex XSIAM®, for AI-powered security operations replacing traditional SIEM tools; Cortex XDR®, for the prevention, detection, and response to complex cybersecurity attacks; Cortex XSOAR®, for security orchestration, automation, and response (“SOAR”); and Cortex Xpanse®, for ASM. Additionally, Cortex XSIAM integrates with the Chronosphere Telemetry Pipeline to ingest and optimize massive data volumes, promoting cost-effective scaling of autonomous operations.

[0001327567-26-000005:mdna:22]
[same as prior period, unchanged from 0001327567-25-000035:mdna:22]

[0001327567-26-000005:mdna:23]
[same as prior period, unchanged from 0001327567-25-000035:mdna:42]

[0001327567-26-000005:mdna:24]
Observability

[0001327567-26-000005:mdna:25]
Chronosphere, our next-generation observability platform, delivers real-time visibility and monitoring across cloud-native infrastructure, applications, and AI workloads. Purpose-built to handle the massive data volumes of the AI era, Chronosphere enables organizations to maintain system resilience and uptime with high cost-efficiency and reliability.

[0001327567-26-000005:mdna:26]
•Chronosphere Platform. Our observability platform provides comprehensive visibility into complex digital environments and automated troubleshooting of issues. It allows customers to transition from passive monitoring to proactive management of their entire digital estate.

[0001327567-26-000005:mdna:27]
•Chronosphere Telemetry Pipeline. Our telemetry pipeline acts as an intelligent control layer that filters, transforms, and routes data. This helps reduce data volumes, enabling customers to cost-effectively scale their security and observability posture.

[0001327567-26-000005:mdna:28]
[same as prior period, unchanged from 0001327567-25-000035:mdna:23]

[0001327567-26-000005:mdna:29]
[same as prior period, unchanged from 0001327567-25-000035:mdna:24]

[0001327567-26-000005:mdna:30]
For the second quarter of fiscal 2026 and 2025, total revenue was $2.6 billion and $2.3 billion, respectively, representing year-over-year growth of 15%. Our growth reflects the increased adoption of our portfolio, which consists of product, subscriptions, and support. We believe our portfolio will enable us to benefit from recurring revenues and new revenues as we continue to grow our end-customer base. As of January 31, 2026, we had end-customers in over 180 countries. Our end-customers represent a broad range of industries, including education, energy, financial services, government entities, healthcare, Internet and media, manufacturing, public sector, and telecommunications, and include almost all of the Fortune 100 companies and a majority of the Global 2000 companies. We maintain a field sales force that works closely with our channel partners in developing sales opportunities. We primarily use a two-tiered, indirect fulfillment model whereby we sell our products, subscriptions, and support to our distributors, which, in turn, sell to our resellers, which then sell to our end-customers.

[0001327567-26-000005:mdna:31]
Our product revenue grew to $514 million, or 19.8% of total revenue, for the second quarter of fiscal 2026, representing year-over-year growth of 22%. Product revenue is derived from sales of hardware products, primarily our ML-Powered Next-Generation Firewall and software licenses, including SD-WAN, VM-Series, and Panorama®. Our ML-Powered Next-Generation Firewall incorporates our PAN-OS operating system, which provides a consistent set of capabilities across our entire network security product line. Our hardware products and software licenses include a broad set of built-in networking and security features and functionalities. Our products are designed for different performance requirements throughout an organization, ranging from our PA-400, which is designed for small organizations and remote or branch offices, to our top-of-the-line PA-7500, which is designed for large-scale data centers and service provider use. The same firewall functionality that is delivered in our hardware products is also available in our VM-Series virtual firewalls, which secure virtualized and cloud-based computing environments, and in our CN-Series container firewalls, which secure container environments and traffic.

[0001327567-26-000005:mdna:32]
Our subscription and support revenue grew to $2.1 billion, or 80.2% of total revenue, for the second quarter of fiscal 2026, representing year-over-year growth of 13%. Our subscriptions provide our end-customers with near real-time access to the latest intrusion prevention, web security, modern malware prevention, data loss prevention, cloud security access broker and AI security capabilities across the network, endpoints, and the cloud. Our subscriptions also include security operations, which enable customers to leverage the AI-powered Cortex platform for advanced capabilities such as security information and event management, next-generation antivirus, endpoint detection and response, extended detection and response, identity threat detection and response, cloud detection and response, SOAR, ASM, and CNAPP for comprehensive cloud security. In connection with our acquisition of Chronosphere, Inc. (“Chronosphere”) in January 2026, our subscriptions also include a next-generation observability platform for cloud-native infrastructure and applications as well as telemetry pipeline management that is designed to handle vast cloud data volumes with cost-efficiency and reliability. Additionally, we offer MDR for Cortex subscriptions, powered by Unit 42’s elite expertise. When customers purchase our physical, virtual, or container firewalls, or certain cloud offerings, they typically purchase support in order to receive ongoing security updates, upgrades, bug fixes, and repairs. In addition to the subscriptions purchased with these firewalls, customers may also purchase other subscriptions on a per-user, per-endpoint, or capacity-based basis. We also offer professional services, including incident response, risk management, and digital forensic services.

[0001327567-26-000005:mdna:33]
We continue to invest in innovation as we evolve and further extend the capabilities of our portfolio, as we believe that innovation and timely development of and investment in new features and products are essential to meeting the needs of our end-customers and improving our competitive position.  On February 11, 2026, we completed the acquisition of CyberArk Software Ltd. (“CyberArk”), forming our next-generation identity security platform. Additionally, on January 29, 2026, we completed the acquisition of Chronosphere, forming our next-generation observability platform.

[0001327567-26-000005:mdna:34]
[same as prior period, unchanged from 0001327567-25-000035:mdna:45]

[0001327567-26-000005:mdna:35]
[same as prior period, unchanged from 0001327567-25-000035:mdna:30]

[0001327567-26-000005:mdna:36]
[same as prior period, unchanged from 0001327567-25-000035:mdna:31]

[0001327567-26-000005:mdna:37]
Our overall performance depends in part on worldwide economic and geopolitical conditions and their impact on customer behavior. Changes in legislation or regulations and actions by regulators, including changes in enforcement and administration policies, may have an impact on our results of operations and financial condition. Significant changes in U.S. or global trade policy, including further expansion of U.S. export/imports controls and tariffs, as well as retaliatory actions by other countries, may materially and adversely affect our business. Further, economic conditions, including inflation, high interest rates, slow growth, fluctuations in foreign exchange rates, supply chain disruptions, such as a memory or other component shortage, impacts of trade regulations or international trade disputes, and other conditions, may adversely affect our results of operations and financial performance.

[0001327567-26-000005:mdna:38]
[same as prior period, unchanged from 0001327567-25-000035:mdna:34]

[0001327567-26-000005:mdna:39]
[same as prior period, unchanged from 0001327567-25-000035:mdna:35]

[0001327567-26-000005:mdna:40]
[same as prior period, unchanged from 0001327567-25-000035:mdna:36]

[0001327567-26-000005:mdna:41]
[same as prior period, unchanged from 0001327567-25-000035:mdna:37]

[0001327567-26-000005:mdna:42]
|  | January 31, 2026 |  | July 31, 2025 |
|  | (in billions) |
| Next-Generation Security Annualized Recurring Revenue | $ | 6.3 |  |  | $ | 5.6 |  |
| Remaining performance obligations | $ | 16.0 |  |  | $ | 15.8 |  |

[0001327567-26-000005:mdna:43]
|  | Three Months Ended January 31, |  | Six Months Ended January 31, |
|  | 2026 |  | 2025 |  | 2026 |  | 2025 |
|  | (dollars in millions) |
| Total revenue | $ | 2,594 |  |  | $ | 2,257 |  |  | $ | 5,068 |  |  | $ | 4,396 |  |
| Total revenue year-over-year percentage increase | 15 | % |  | 14 | % |  | 15 | % |  | 14 | % |
| Gross margin | 73.6 | % |  | 73.5 | % |  | 73.9 | % |  | 73.8 | % |
| Operating income | $ | 397 |  |  | $ | 241 |  |  | $ | 706 |  |  | $ | 527 |  |
| Operating margin | 15.3 | % |  | 10.6 | % |  | 13.9 | % |  | 12.0 | % |
| Cash flow provided by operating activities |  |  |  |  | $ | 2,325 |  |  | $ | 2,067 |  |
| Free cash flow (non-GAAP) |  |  |  |  | $ | 2,071 |  |  | $ | 1,975 |  |

[0001327567-26-000005:mdna:44]
[same as prior period, unchanged from 0001327567-25-000035:mdna:51]

[0001327567-26-000005:mdna:45]
[same as prior period, unchanged from 0001327567-25-000035:mdna:40]

[0001327567-26-000005:mdna:46]
[same as prior period, unchanged from 0001327567-25-000035:mdna:41]

[0001327567-26-000005:mdna:47]
•Free Cash Flow (non-GAAP). We define free cash flow, a non-GAAP financial measure, as cash provided by operating activities less purchases of property, equipment, and other assets. We consider free cash flow to be an operating metric as well as a profitability and liquidity measure that provides useful information to management and investors about the amount of cash generated by the business after necessary capital expenditures. A limitation of the utility of free cash flow as a measure of our financial performance and liquidity is that it does not represent the total increase or decrease in our cash balance for the period. In addition, it is important to note that other companies, including companies in our industry, may not use free cash flow, may calculate free cash flow in a different manner than we do, or may use other financial measures to evaluate their performance, all of which could reduce the usefulness of free cash flow as a comparative measure. A reconciliation of free cash flow to cash flow provided by operating activities, the most directly comparable financial measure calculated and presented in accordance with U.S. GAAP, is provided below:

[0001327567-26-000005:mdna:48]
|  | Six Months Ended January 31, |
|  | 2026 |  | 2025 |
|  | (in millions) |
| Free cash flow (non-GAAP): |  |  |  |
| Net cash provided by operating activities | $ | 2,325 |  |  | $ | 2,067 |  |
| Less: purchases of property, equipment, and other assets | 254 |  |  | 92 |  |
| Free cash flow (non-GAAP) | $ | 2,071 |  |  | $ | 1,975 |  |
| Net cash used in investing activities | $ | (332) |  |  | $ | (925) |  |
| Net cash used in financing activities | $ | (106) |  |  | $ | (452) |  |

[0001327567-26-000005:mdna:49]
[same as prior period, unchanged from 0001327567-25-000035:mdna:62]

[0001327567-26-000005:mdna:50]
[same as prior period, unchanged from 0001327567-25-000035:mdna:46]

[0001327567-26-000005:mdna:51]
[same as prior period, unchanged from 0001327567-25-000035:mdna:47]

[0001327567-26-000005:mdna:52]
|  | Three Months Ended January 31, |  | Six Months Ended January 31, |
|  | 2026 |  | 2025 |  | 2026 |  | 2025 |
|  | Amount |  | % of Revenue |  | Amount |  | % of Revenue |  | Amount |  | % of Revenue |  | Amount |  | % of Revenue |
|  | (dollars in millions) |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 514 |  |  | 19.8 | % |  | $ | 421 |  |  | 18.7 | % |  | $ | 948 |  |  | 18.7 | % |  | $ | 775 |  |  | 17.6 | % |
| Subscription and support | 2,080 |  |  | 80.2 | % |  | 1,836 |  |  | 81.3 | % |  | 4,120 |  |  | 81.3 | % |  | 3,621 |  |  | 82.4 | % |
| Total revenue | 2,594 |  |  | 100.0 | % |  | 2,257 |  |  | 100.0 | % |  | 5,068 |  |  | 100.0 | % |  | 4,396 |  |  | 100.0 | % |
| Cost of revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product | 115 |  |  | 4.4 | % |  | 101 |  |  | 4.5 | % |  | 204 |  |  | 4.0 | % |  | 176 |  |  | 4.0 | % |
| Subscription and support | 570 |  |  | 22.0 | % |  | 498 |  |  | 22.0 | % |  | 1,119 |  |  | 22.1 | % |  | 977 |  |  | 22.2 | % |
| Total cost of revenue(1) | 685 |  |  | 26.4 | % |  | 599 |  |  | 26.5 | % |  | 1,323 |  |  | 26.1 | % |  | 1,153 |  |  | 26.2 | % |
| Total gross profit | 1,909 |  |  | 73.6 | % |  | 1,658 |  |  | 73.5 | % |  | 3,745 |  |  | 73.9 | % |  | 3,243 |  |  | 73.8 | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | 511 |  |  | 19.7 | % |  | 505 |  |  | 22.4 | % |  | 1,039 |  |  | 20.5 | % |  | 986 |  |  | 22.4 | % |
| Sales and marketing | 823 |  |  | 31.7 | % |  | 758 |  |  | 33.7 | % |  | 1,643 |  |  | 32.5 | % |  | 1,478 |  |  | 33.7 | % |
| General and administrative | 178 |  |  | 6.9 | % |  | 154 |  |  | 6.8 | % |  | 357 |  |  | 7.0 | % |  | 252 |  |  | 5.7 | % |
| Total operating expenses(1) | 1,512 |  |  | 58.3 | % |  | 1,417 |  |  | 62.9 | % |  | 3,039 |  |  | 60.0 | % |  | 2,716 |  |  | 61.8 | % |
| Operating income | 397 |  |  | 15.3 | % |  | 241 |  |  | 10.6 | % |  | 706 |  |  | 13.9 | % |  | 527 |  |  | 12.0 | % |
| Interest expense | — |  |  | — | % |  | (1) |  |  | — | % |  | — |  |  | — | % |  | (2) |  |  | — | % |
| Other income, net | 152 |  |  | 5.9 | % |  | 85 |  |  | 3.8 | % |  | 255 |  |  | 5.1 | % |  | 168 |  |  | 3.8 | % |
| Income before income taxes | 549 |  |  | 21.2 | % |  | 325 |  |  | 14.4 | % |  | 961 |  |  | 19.0 | % |  | 693 |  |  | 15.8 | % |
| Provision for income taxes | 117 |  |  | 4.5 | % |  | 58 |  |  | 2.6 | % |  | 195 |  |  | 3.9 | % |  | 75 |  |  | 1.7 | % |
| Net income | $ | 432 |  |  | 16.7 | % |  | $ | 267 |  |  | 11.8 | % |  | $ | 766 |  |  | 15.1 | % |  | $ | 618 |  |  | 14.1 | % |

[0001327567-26-000005:mdna:53]
[same as prior period, unchanged from 0001327567-25-000035:mdna:49]

[0001327567-26-000005:mdna:54]
|  | Three Months Ended January 31, |  | Six Months Ended January 31, |
|  | 2026 |  | 2025 |  | 2026 |  | 2025 |
|  | (in millions) |
| Cost of product revenue | $ | 1 |  |  | $ | 2 |  |  | $ | 2 |  |  | $ | 3 |  |
| Cost of subscription and support revenue | 32 |  |  | 32 |  |  | 64 |  |  | 63 |  |
| Research and development | 116 |  |  | 139 |  |  | 271 |  |  | 277 |  |
| Sales and marketing | 98 |  |  | 90 |  |  | 200 |  |  | 166 |  |
| General and administrative | 54 |  |  | 57 |  |  | 134 |  |  | 106 |  |
| Total share-based compensation | $ | 301 |  |  | $ | 320 |  |  | $ | 671 |  |  | $ | 615 |  |

[0001327567-26-000005:mdna:55]
[same as prior period, unchanged from 0001327567-25-000035:mdna:72]

[0001327567-26-000005:mdna:56]
[same as prior period, unchanged from 0001327567-25-000035:mdna:52]

[0001327567-26-000005:mdna:57]
[same as prior period, unchanged from 0001327567-25-000035:mdna:53]

[0001327567-26-000005:mdna:58]
[same as prior period, unchanged from 0001327567-25-000035:mdna:54]

[0001327567-26-000005:mdna:59]
[same as prior period, unchanged from 0001327567-25-000035:mdna:55]

[0001327567-26-000005:mdna:60]
|  | Three Months Ended January 31, |  |  |  |  |  | Six Months Ended January 31, |  |  |  |  |
|  | 2026 |  | 2025 |  | Change |  | 2026 |  | 2025 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Product | $ | 514 |  |  | $ | 421 |  |  | $ | 93 |  |  | 22 | % |  | $ | 948 |  |  | $ | 775 |  |  | $ | 173 |  |  | 22 | % |

[0001327567-26-000005:mdna:61]
Product revenue increased for the three and six months ended January 31, 2026 compared to the same periods in 2025, driven by increased revenue from software licenses and increased demand for our new generation of hardware products.

[0001327567-26-000005:mdna:62]
[same as prior period, unchanged from 0001327567-25-000035:mdna:58]

[0001327567-26-000005:mdna:63]
[same as prior period, unchanged from 0001327567-25-000035:mdna:59]

[0001327567-26-000005:mdna:64]
|  | Three Months Ended January 31, |  |  |  |  |  | Six Months Ended January 31, |  |  |  |  |
|  | 2026 |  | 2025 |  | Change |  | 2026 |  | 2025 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Subscription | $ | 1,404 |  |  | $ | 1,233 |  |  | $ | 171 |  |  | 14 | % |  | $ | 2,768 |  |  | $ | 2,425 |  |  | $ | 343 |  |  | 14 | % |
| Support | 676 |  |  | 603 |  |  | 73 |  |  | 12 | % |  | 1,352 |  |  | 1,196 |  |  | 156 |  |  | 13 | % |
| Total subscription and support | $ | 2,080 |  |  | $ | 1,836 |  |  | $ | 244 |  |  | 13 | % |  | $ | 4,120 |  |  | $ | 3,621 |  |  | $ | 499 |  |  | 14 | % |

[0001327567-26-000005:mdna:65]
Subscription and support revenue increased for the three and six months ended January 31, 2026 compared to the same periods in 2025 due to increased demand for our subscription and support offerings from our end-customers. The mix between subscription revenue and support revenue will fluctuate over time, depending on the introduction of new subscription offerings, renewals of support services, and our ability to increase sales to new and existing end-customers.

[0001327567-26-000005:mdna:66]
[same as prior period, unchanged from 0001327567-25-000035:mdna:84]

[0001327567-26-000005:mdna:67]
[same as prior period, unchanged from 0001327567-25-000035:mdna:63]

[0001327567-26-000005:mdna:68]
|  | Three Months Ended January 31, |  |  |  |  |  | Six Months Ended January 31, |  |  |  |  |
|  | 2026 |  | 2025 |  | Change |  | 2026 |  | 2025 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Americas | $ | 1,712 |  |  | $ | 1,502 |  |  | $ | 210 |  |  | 14 | % |  | $ | 3,353 |  |  | $ | 2,944 |  |  | $ | 409 |  |  | 14 | % |
| Europe, the Middle East, and Africa (“EMEA”) | 560 |  |  | 480 |  |  | 80 |  |  | 17 | % |  | 1,081 |  |  | 922 |  |  | 159 |  |  | 17 | % |
| Asia Pacific and Japan (“APAC”) | 322 |  |  | 275 |  |  | 47 |  |  | 17 | % |  | 634 |  |  | 530 |  |  | 104 |  |  | 20 | % |
| Total revenue | $ | 2,594 |  |  | $ | 2,257 |  |  | $ | 337 |  |  | 15 | % |  | $ | 5,068 |  |  | $ | 4,396 |  |  | $ | 672 |  |  | 15 | % |

[0001327567-26-000005:mdna:69]
Revenue from the Americas, EMEA, and APAC increased for the three and six months ended January 31, 2026 compared to the same periods in 2025 as we continued to increase investment in our global sales force in order to support our growth and innovation, with the Americas contributing the highest increase in revenue due to its larger scale.

[0001327567-26-000005:mdna:70]
[same as prior period, unchanged from 0001327567-25-000035:mdna:66]

[0001327567-26-000005:mdna:71]
[same as prior period, unchanged from 0001327567-25-000035:mdna:67]

[0001327567-26-000005:mdna:72]
[same as prior period, unchanged from 0001327567-25-000035:mdna:68]

[0001327567-26-000005:mdna:73]
[same as prior period, unchanged from 0001327567-25-000035:mdna:69]

[0001327567-26-000005:mdna:74]
|  | Three Months Ended January 31, |  |  |  |  |  | Six Months Ended January 31, |  |  |  |  |
|  | 2026 |  | 2025 |  | Change |  | 2026 |  | 2025 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Cost of product revenue | $ | 115 |  |  | $ | 101 |  |  | $ | 14 |  |  | 14 | % |  | $ | 204 |  |  | $ | 176 |  |  | $ | 28 |  |  | 16 | % |

[0001327567-26-000005:mdna:75]
Cost of product revenue increased for the three and six months ended January 31, 2026 compared to the same periods in 2025 primarily due to increased demand for our hardware products and higher tariff costs, partially offset by a decrease in inventory excess and obsolete charges.

[0001327567-26-000005:mdna:76]
[same as prior period, unchanged from 0001327567-25-000035:mdna:97]

[0001327567-26-000005:mdna:77]
[same as prior period, unchanged from 0001327567-25-000035:mdna:73]

[0001327567-26-000005:mdna:78]
[same as prior period, unchanged from 0001327567-25-000035:mdna:74]

[0001327567-26-000005:mdna:79]
|  | Three Months Ended January 31, |  |  |  |  |  | Six Months Ended January 31, |  |  |  |  |
|  | 2026 |  | 2025 |  | Change |  | 2026 |  | 2025 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Cost of subscription and support revenue | $ | 570 |  |  | $ | 498 |  |  | $ | 72 |  |  | 14 | % |  | $ | 1,119 |  |  | $ | 977 |  |  | $ | 142 |  |  | 15 | % |

[0001327567-26-000005:mdna:80]
Cost of subscription and support revenue increased for the three and six months ended January 31, 2026 compared to the same periods in 2025 primarily due to increased costs to support the growth of our subscription and support offerings. Cloud hosting service costs, which support our cloud-based subscription offerings, increased $48 million and $97 million for the three and six months ended January 31, 2026, respectively, compared to the same periods in 2025. Personnel costs grew $11 million and $25 million for the three and six months ended January 31, 2026, respectively, compared to the same periods in 2025, primarily due to headcount growth.

[0001327567-26-000005:mdna:81]
[same as prior period, unchanged from 0001327567-25-000035:mdna:77]

[0001327567-26-000005:mdna:82]
[same as prior period, unchanged from 0001327567-25-000035:mdna:78]

[0001327567-26-000005:mdna:83]
|  | Three Months Ended January 31, |  | Six Months Ended January 31, |
|  | 2026 |  | 2025 |  | 2026 |  | 2025 |
|  | Amount |  | Gross Margin |  | Amount |  | Gross Margin |  | Amount |  | Gross Margin |  | Amount |  | Gross Margin |
|  | (dollars in millions) |
| Product | $ | 399 |  |  | 77.6 | % |  | $ | 320 |  |  | 76.0 | % |  | $ | 744 |  |  | 78.5 | % |  | $ | 599 |  |  | 77.3 | % |
| Subscription and support | 1,510 |  |  | 72.6 | % |  | 1,338 |  |  | 72.9 | % |  | 3,001 |  |  | 72.8 | % |  | 2,644 |  |  | 73.0 | % |
| Total gross profit | $ | 1,909 |  |  | 73.6 | % |  | $ | 1,658 |  |  | 73.5 | % |  | $ | 3,745 |  |  | 73.9 | % |  | $ | 3,243 |  |  | 73.8 | % |

[0001327567-26-000005:mdna:84]
Product gross margin increased for the three and six months ended January 31, 2026 compared to the same periods in 2025 primarily due to continued shift in our product revenue mix toward software, and a decrease in inventory excess and obsolete charges, partially offset by a decrease in gross margin on our hardware products.

[0001327567-26-000005:mdna:85]
Subscription and support gross margin were flat for the three and six months ended January 31, 2026 compared to the same periods in 2025.

[0001327567-26-000005:mdna:86]
[same as prior period, unchanged from 0001327567-25-000035:mdna:110]

[0001327567-26-000005:mdna:87]
[same as prior period, unchanged from 0001327567-25-000035:mdna:82]

[0001327567-26-000005:mdna:88]
Our operating expenses consist of research and development, sales and marketing, and general and administrative expenses. Personnel costs are the most significant component of operating expenses and consist of salaries, benefits, bonuses, share-based compensation, travel and entertainment, and with regard to sales and marketing expense, sales commissions. Our operating expenses also include shared costs, which consist of certain facilities, depreciation, benefits, recruiting, and information technology costs that we allocate based on headcount to each department. We expect operating expenses generally to increase in absolute dollars and to decrease over the long term as a percentage of revenue as we continue to scale our business. As of January 31, 2026, we expect to recognize approximately $2.9 billion of share-based compensation expense over a weighted-average period of approximately 2.6 years, excluding additional share-based compensation expense related to any future grants of share-based awards. Share-based compensation expense is generally recognized on a straight-line basis over the requisite service periods of the awards.

[0001327567-26-000005:mdna:89]
[same as prior period, unchanged from 0001327567-25-000035:mdna:85]

[0001327567-26-000005:mdna:90]
[same as prior period, unchanged from 0001327567-25-000035:mdna:86]

[0001327567-26-000005:mdna:91]
|  | Three Months Ended January 31, |  |  |  |  |  | Six Months Ended January 31, |  |  |  |  |
|  | 2026 |  | 2025 |  | Change |  | 2026 |  | 2025 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Research and development | $ | 511 |  |  | $ | 505 |  |  | $ | 6 |  |  | 1 | % |  | $ | 1,039 |  |  | $ | 986 |  |  | $ | 53 |  |  | 5 | % |

[0001327567-26-000005:mdna:92]
Research and development expense was relatively flat for the three months ended January 31, 2026 compared to the same period in 2025. Research and development expense increased for the six months ended January 31, 2026 compared to the same period in 2025 primarily due to increased personnel costs, which grew $41 million for the six months ended January 31, 2026 compared to the same period in 2025, largely due to headcount growth.

[0001327567-26-000005:mdna:93]
[same as prior period, unchanged from 0001327567-25-000035:mdna:89]

[0001327567-26-000005:mdna:94]
[same as prior period, unchanged from 0001327567-25-000035:mdna:90]

[0001327567-26-000005:mdna:95]
|  | Three Months Ended January 31, |  |  |  |  |  | Six Months Ended January 31, |  |  |  |  |
|  | 2026 |  | 2025 |  | Change |  | 2026 |  | 2025 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Sales and marketing | $ | 823 |  |  | $ | 758 |  |  | $ | 65 |  |  | 9 | % |  | $ | 1,643 |  |  | $ | 1,478 |  |  | $ | 165 |  |  | 11 | % |

[0001327567-26-000005:mdna:96]
Sales and marketing expense increased for the three and six months ended January 31, 2026 compared to the same periods in 2025 primarily due to increased personnel costs, which grew $69 million and $154 million for the three and six months ended January 31, 2026, respectively, compared to the same periods in 2025, largely due to headcount growth.

[0001327567-26-000005:mdna:97]
[same as prior period, unchanged from 0001327567-25-000035:mdna:123]

[0001327567-26-000005:mdna:98]
[same as prior period, unchanged from 0001327567-25-000035:mdna:93]

[0001327567-26-000005:mdna:99]
[same as prior period, unchanged from 0001327567-25-000035:mdna:94]

[0001327567-26-000005:mdna:100]
|  | Three Months Ended January 31, |  |  |  |  |  | Six Months Ended January 31, |  |  |  |  |
|  | 2026 |  | 2025 |  | Change |  | 2026 |  | 2025 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| General and administrative | $ | 178 |  |  | $ | 154 |  |  | $ | 24 |  |  | 16 | % |  | $ | 357 |  |  | $ | 252 |  |  | $ | 105 |  |  | 42 | % |

[0001327567-26-000005:mdna:101]
General and administrative expense increased for the three months ended January 31, 2026 compared to the same period in 2025 primarily due to an increase in acquisition-related costs. General and administrative expense increased for the six months ended January 31, 2026 compared to the same period in 2025 primarily due to the partial release of litigation-related accrual of $42 million during the six months ended January 31, 2025. The increase in general and administrative expense for the six months ended January 31, 2026 was further driven by increased personnel costs, which grew $43 million, largely due to increased share-based compensation and headcount growth.

[0001327567-26-000005:mdna:102]
[same as prior period, unchanged from 0001327567-25-000035:mdna:98]

[0001327567-26-000005:mdna:103]
Interest expense consists of interest expense related to our 0.375% Convertible Senior Notes due 2025 (the “2025 Notes”).

[0001327567-26-000005:mdna:104]
|  | Three Months Ended January 31, |  |  |  | Six Months Ended January 31, |  |  |
|  | 2026 |  | 2025 |  | Change |  | 2026 |  | 2025 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Interest expense | $ | — |  |  | $ | 1 |  |  | $ | (1) |  |  | (100) | % |  | $ | — |  |  | $ | 2 |  |  | $ | (2) |  |  | (100) | % |

[0001327567-26-000005:mdna:105]
Interest expense decreased for the three and six months ended January 31, 2026 compared to the same periods in 2025 due to the maturity of our 2025 Notes in June 2025. Refer to Note 9. Debt in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information on the Notes.

[0001327567-26-000005:mdna:106]
[same as prior period, unchanged from 0001327567-25-000035:mdna:102]

[0001327567-26-000005:mdna:107]
[same as prior period, unchanged from 0001327567-25-000035:mdna:103]

[0001327567-26-000005:mdna:108]
|  | Three Months Ended January 31, |  |  |  | Six Months Ended January 31, |  |  |
|  | 2026 |  | 2025 |  | Change |  | 2026 |  | 2025 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Other income, net | $ | 152 |  |  | $ | 85 |  |  | $ | 67 |  |  | 79 | % |  | $ | 255 |  |  | $ | 168 |  |  | $ | 87 |  |  | 52 | % |

[0001327567-26-000005:mdna:109]
Other income, net increased for the three and six months ended January 31, 2026 compared to the same periods in 2025 primarily due to higher interest income as a result of higher average cash, cash equivalents, and investment balances for the three and six months ended January 31, 2026 compared to the same periods in 2025. The increase was further driven by increased gains on sales of our investments to fund recent acquisitions.

[0001327567-26-000005:mdna:110]
[same as prior period, unchanged from 0001327567-25-000035:mdna:138]

[0001327567-26-000005:mdna:111]
[same as prior period, unchanged from 0001327567-25-000035:mdna:106]

[0001327567-26-000005:mdna:112]
Provision for income taxes consists primarily of U.S. and foreign income taxes. Our effective tax rate during the three and six months ended January 31, 2026 was lower than our statutory tax rate primarily due to excess tax benefits from share-based compensation. We continue to maintain a valuation allowance for our California deferred tax assets due to the uncertainty regarding realizability of these deferred tax assets as they have not met the “more likely than not” realization criterion. We expect future research and development tax credit generation in California to exceed our ability to use the existing tax credits.

[0001327567-26-000005:mdna:113]
|  | Three Months Ended January 31, |  |  |  |  |  | Six Months Ended January 31, |  |  |  |  |
|  | 2026 |  | 2025 |  | Change |  | 2026 |  | 2025 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in millions) |
| Provision for income taxes | $ | 117 |  |  | $ | 58 |  |  | $ | 59 |  |  | 102 | % |  | $ | 195 |  |  | $ | 75 |  |  | $ | 120 |  |  | 160 | % |
| Effective tax rate | 21.3 | % |  | 17.7 | % |  |  |  |  |  | 20.3 | % |  | 10.9 | % |  |  |  |  |

[0001327567-26-000005:mdna:114]
Our provision for income taxes for the three and six months ended January 31, 2026 was primarily due to U.S. and foreign income taxes. Our effective tax rate increased for the three and six months ended January 31, 2026 compared to the same periods in 2025 primarily due to decreased excess tax benefits from share-based compensation relative to our increased business profits. Refer to Note 13. Income Taxes in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information.

[0001327567-26-000005:mdna:115]
[same as prior period, unchanged from 0001327567-25-000035:mdna:111]

[0001327567-26-000005:mdna:116]
|  | January 31, 2026 |  | July 31, 2025 |
|  | (in millions) |
| Working capital (deficit) | $ | 360 |  |  | $ | (465) |  |
| Cash, cash equivalents, and investments: |  |  |  |
| Cash and cash equivalents | $ | 4,158 |  |  | $ | 2,269 |  |
| Investments | 3,740 |  |  | 6,190 |  |
| Total cash, cash equivalents, and investments | $ | 7,898 |  |  | $ | 8,459 |  |

[0001327567-26-000005:mdna:117]
As of January 31, 2026, our total cash, cash equivalents, and investments of $7.9 billion were held for general corporate purposes. As of January 31, 2026, we had no unremitted earnings when evaluating our outside basis difference relating to our U.S. investment in foreign subsidiaries. However, there could be local withholding taxes due to various foreign countries if certain lower tier earnings are distributed. Withholding taxes that would be payable upon remittance of these lower tier earnings are not material.

[0001327567-26-000005:mdna:118]
[same as prior period, unchanged from 0001327567-25-000035:mdna:114]

[0001327567-26-000005:mdna:119]
In April 2023, we entered into a credit agreement (the “Credit Agreement”) that provides for a $400 million unsecured revolving credit facility (the “Credit Facility”), with an option to increase the amount of the Credit Facility by up to an additional $350 million, subject to certain conditions. The interest rates and commitment fees are also subject to upward and downward adjustments based on our progress towards the achievement of certain sustainability goals. As of January 31, 2026, there were no amounts outstanding, and we were in compliance with all covenants under the Credit Agreement. Refer to Note 9. Debt in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information on the Credit Agreement.

[0001327567-26-000005:mdna:120]
[same as prior period, unchanged from 0001327567-25-000035:mdna:116]

[0001327567-26-000005:mdna:121]
In February 2019, our board of directors authorized a $1.0 billion share repurchase program. Our board of directors subsequently authorized additional increases to this share repurchase program, bringing the total authorization to $4.1 billion. Repurchases will be funded from available working capital and may be made at management’s discretion from time to time. As of January 31, 2026, $1.0 billion remained available for future share repurchases under this repurchase program. The repurchase authorization will expire on December 31, 2026, and may be suspended or discontinued at any time without prior notice. Refer to Note 11. Stockholders’ Equity in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information on this repurchase program.

[0001327567-26-000005:mdna:122]
- 33 -

[0001327567-26-000005:mdna:123]
[same as prior period, unchanged from 0001327567-25-000035:mdna:118]

[0001327567-26-000005:mdna:124]
We have entered into various non-cancelable operating leases, primarily for our offices and data centers, with lease terms expiring through fiscal 2036. As of January 31, 2026, we have total operating lease obligations of $459 million recorded on our condensed consolidated balance sheet.

[0001327567-26-000005:mdna:125]
As of January 31, 2026, our commitments to purchase products, components, cloud hosting and other services totaled $6.9 billion. Refer to Note 10. Commitments and Contingencies in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information on these commitments.

[0001327567-26-000005:mdna:126]
Our acquisition of certain QRadar assets from International Business Machines Corporation (“IBM”) on August 31, 2024 included contingent consideration that requires potential future payments through the fiscal quarter ending October 2028. As of January 31, 2026, we have total contingent consideration obligation of $369 million recorded on our condensed consolidated balance sheet. Refer to Note 3. Fair Value Measurements in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information on our contingent consideration obligation.

[0001327567-26-000005:mdna:127]
On July 30, 2025, we entered into a definitive agreement to acquire CyberArk. Under the terms of the definitive agreement, CyberArk shareholders were entitled to receive $45.00 in cash and 2.2005 shares of our common stock for each CyberArk share. On February 11, 2026, we completed the acquisition of CyberArk for $2.3 billion in cash and 112 million shares of our common stock. The cash portion of the consideration was funded with our cash on hand. Refer to Part II, Item 1A “Risk Factors” and Note 7. Acquisitions in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information on the acquisition.

[0001327567-26-000005:mdna:128]
[same as prior period, unchanged from 0001327567-25-000035:mdna:124]

[0001327567-26-000005:mdna:129]
The following table summarizes our cash flows for the six months ended January 31, 2026 and 2025:

[0001327567-26-000005:mdna:130]
|  | Six Months Ended January 31, |
|  | 2026 |  | 2025 |
|  | (in millions) |
| Net cash provided by operating activities | $ | 2,325 |  |  | $ | 2,067 |  |
| Net cash used in investing activities | (332) |  |  | (925) |  |
| Net cash used in financing activities | (106) |  |  | (452) |  |
| Net increase in cash, cash equivalents, and restricted cash | $ | 1,887 |  |  | $ | 690 |  |

[0001327567-26-000005:mdna:131]
[same as prior period, unchanged from 0001327567-25-000035:mdna:127]

[0001327567-26-000005:mdna:132]
[same as prior period, unchanged from 0001327567-25-000035:mdna:128]

[0001327567-26-000005:mdna:133]
[same as prior period, unchanged from 0001327567-25-000035:mdna:129]

[0001327567-26-000005:mdna:134]
[same as prior period, unchanged from 0001327567-25-000035:mdna:130]

[0001327567-26-000005:mdna:135]
Cash provided by operating activities during the six months ended January 31, 2026 was $2.3 billion, an increase of $258 million compared to the same period in 2025. The increase was primarily due to growth of our business as reflected by increases in collections during the six months ended January 31, 2026, partially offset by higher cash expenditure to support our business growth.

[0001327567-26-000005:mdna:136]
- 34 -

[0001327567-26-000005:mdna:137]
[same as prior period, unchanged from 0001327567-25-000035:mdna:132]

[0001327567-26-000005:mdna:138]
[same as prior period, unchanged from 0001327567-25-000035:mdna:133]

[0001327567-26-000005:mdna:139]
Cash used in investing activities during the six months ended January 31, 2026 was $332 million, a decrease of $593 million compared to the same period in 2025. The decrease was primarily due to higher proceeds from sales and maturities of investments, partially offset by an increase in net cash payments for business acquisitions during the six months ended January 31, 2026.

[0001327567-26-000005:mdna:140]
[same as prior period, unchanged from 0001327567-25-000035:mdna:135]

[0001327567-26-000005:mdna:141]
[same as prior period, unchanged from 0001327567-25-000035:mdna:136]

[0001327567-26-000005:mdna:142]
Cash used in financing activities during the six months ended January 31, 2026 was $106 million, a decrease of $346 million compared to the same period in 2025. The decrease was primarily due to a decrease in cash used for repayments of our 2025 Notes which did not recur during the six months ended January 31, 2026 as a result of its maturity, partially offset by payments of our contingent consideration liability during the six months ended January 31, 2026.

[0001327567-26-000005:mdna:143]
[same as prior period, unchanged from 0001327567-25-000035:mdna:139]

[0001327567-26-000005:mdna:144]
[same as prior period, unchanged from 0001327567-25-000035:mdna:140]

[0001327567-26-000005:mdna:145]
[same as prior period, unchanged from 0001327567-25-000035:mdna:141]

[0001327567-26-000005:mdna:146]
[same as prior period, unchanged from 0001327567-25-000035:mdna:142]

[0001327567-26-000005:mdna:147]
Refer to “Recently Issued Accounting Pronouncements” in Note 1. Description of Business and Summary of Significant Accounting Policies in Part I, Item 1 of this Quarterly Report on Form 10-Q for a description of recent accounting pronouncements and our expectation of their impact, if any, on our results of operations and financial condition.
