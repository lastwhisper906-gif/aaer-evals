# PANW notes — 0001327567-26-000005


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock

[0001327567-26-000005:notes:1]
[same as prior period, unchanged from 0001327567-25-000035:notes:1]

[0001327567-26-000005:notes:2]
[same as prior period, unchanged from 0001327567-25-000035:notes:2]

[0001327567-26-000005:notes:3]
[same as prior period, unchanged from 0001327567-25-000035:notes:3]

[0001327567-26-000005:notes:4]
[same as prior period, unchanged from 0001327567-25-000035:notes:4]

[0001327567-26-000005:notes:5]
[same as prior period, unchanged from 0001327567-25-000035:notes:5]

[0001327567-26-000005:notes:6]
[same as prior period, unchanged from 0001327567-25-000035:notes:6]

[0001327567-26-000005:notes:7]
The preparation of condensed consolidated financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the amounts reported and disclosed in the condensed consolidated financial statements and the accompanying notes. We evaluate our estimates on an ongoing basis. Management estimates include, but are not limited to, the standalone selling price for our products and services, share-based compensation, fair value of assets acquired and liabilities assumed in business combinations, fair value of contingent consideration liability, the assessment of recoverability of our intangibles and goodwill, valuation allowance against deferred tax assets, valuation of inventory and manufacturing partner and supplier liabilities, deferred contract cost benefit period, and loss contingencies. We base our estimates on assumptions, both historical and forward looking, that we believe are reasonable. Actual results could differ materially from those estimates due to risks and uncertainties.

[0001327567-26-000005:notes:8]
[same as prior period, unchanged from 0001327567-25-000035:notes:8]

[0001327567-26-000005:notes:9]
There have been no material changes to our significant accounting policies as of and for the six months ended January 31, 2026, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended July 31, 2025.

[0001327567-26-000005:notes:10]
Recently Issued Accounting Pronouncements

[0001327567-26-000005:notes:11]
[same as prior period, unchanged from 0001327567-25-000035:notes:11]

[0001327567-26-000005:notes:12]
[same as prior period, unchanged from 0001327567-25-000035:notes:12]

[0001327567-26-000005:notes:13]
[same as prior period, unchanged from 0001327567-25-000035:notes:13]

[0001327567-26-000005:notes:14]
[same as prior period, unchanged from 0001327567-25-000035:notes:14]

[0001327567-26-000005:notes:15]
[same as prior period, unchanged from 0001327567-25-000035:notes:15]

[0001327567-26-000005:notes:16]
[same as prior period, unchanged from 0001327567-25-000035:notes:16]

[0001327567-26-000005:notes:17]
[same as prior period, unchanged from 0001327567-25-000035:notes:17]

[0001327567-26-000005:notes:18]
[same as prior period, unchanged from 0001327567-25-000035:notes:18]

[0001327567-26-000005:notes:19]
Hedge Accounting Improvements

[0001327567-26-000005:notes:20]
In November 2025, the FASB issued authoritative guidance that clarifies and improves the existing hedge accounting guidance to better reflect the economics of an entity’s risk management activities. The standard is effective for our annual and interim periods beginning in the first quarter of fiscal 2028 and will be applied on a prospective basis. Early adoption is permitted. We are currently evaluating the impact of this standard on our consolidated financial statements.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001327567-26-000005:notes:21]
[same as prior period, unchanged from 0001327567-25-000035:notes:19]

[0001327567-26-000005:notes:22]
[same as prior period, unchanged from 0001327567-25-000035:notes:20]

[0001327567-26-000005:notes:23]
|  | Three Months Ended January 31, |  | Six Months Ended January 31, |
|  | 2026 |  | 2025 |  | 2026 |  | 2025 |
| Revenue: |  |  |  |  |  |  |  |
| Americas |  |  |  |  |  |  |  |
| United States | $ | 1,588 |  |  | $ | 1,400 |  |  | $ | 3,114 |  |  | $ | 2,744 |  |
| Other Americas | 124 |  |  | 102 |  |  | 239 |  |  | 200 |  |
| Total Americas | 1,712 |  |  | 1,502 |  |  | 3,353 |  |  | 2,944 |  |
| Europe, the Middle East, and Africa (“EMEA”) | 560 |  |  | 480 |  |  | 1,081 |  |  | 922 |  |
| Asia Pacific and Japan (“APAC”) | 322 |  |  | 275 |  |  | 634 |  |  | 530 |  |
| Total revenue | $ | 2,594 |  |  | $ | 2,257 |  |  | $ | 5,068 |  |  | $ | 4,396 |  |

[0001327567-26-000005:notes:24]
[same as prior period, unchanged from 0001327567-25-000035:notes:22]

[0001327567-26-000005:notes:25]
|  | Three Months Ended January 31, |  | Six Months Ended January 31, |
|  | 2026 |  | 2025 |  | 2026 |  | 2025 |
| Revenue: |  |  |  |  |  |  |  |
| Product | $ | 514 |  |  | $ | 421 |  |  | $ | 948 |  |  | $ | 775 |  |
| Subscription and support |  |  |  |  |  |  |  |
| Subscription | 1,404 |  |  | 1,233 |  |  | 2,768 |  |  | 2,425 |  |
| Support | 676 |  |  | 603 |  |  | 1,352 |  |  | 1,196 |  |
| Total subscription and support | 2,080 |  |  | 1,836 |  |  | 4,120 |  |  | 3,621 |  |
| Total revenue | $ | 2,594 |  |  | $ | 2,257 |  |  | $ | 5,068 |  |  | $ | 4,396 |  |

[0001327567-26-000005:notes:26]
[same as prior period, unchanged from 0001327567-25-000035:notes:24]

[0001327567-26-000005:notes:27]
During the six months ended January 31, 2026 and 2025, we recognized approximately $3.5 billion and $3.1 billion of revenue pertaining to amounts that were deferred as of July 31, 2025 and 2024, respectively.

[0001327567-26-000005:notes:28]
[same as prior period, unchanged from 0001327567-25-000035:notes:26]

[0001327567-26-000005:notes:29]
Remaining performance obligations were $16.0 billion as of January 31, 2026, of which we expect to recognize as revenue approximately $7.1 billion over the next 12 months and the remainder thereafter.


## us-gaap:FairValueDisclosuresTextBlock

[0001327567-26-000005:notes:30]
Fair Value Measurements
The following table presents our financial assets and liabilities measured at fair value on a recurring basis as of January 31, 2026 and July 31, 2025 (in millions):

[0001327567-26-000005:notes:31]
|  | January 31, 2026 |  | July 31, 2025 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Cash equivalents: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | $ | 1,395 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,395 |  |  | $ | 1,206 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,206 |  |
| Certificates of deposit | — |  |  | 14 |  |  | — |  |  | 14 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Commercial paper | — |  |  | 912 |  |  | — |  |  | 912 |  |  | — |  |  | 169 |  |  | — |  |  | 169 |  |
| Corporate debt securities | — |  |  | 17 |  |  | — |  |  | 17 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| U.S. government and agency securities | — |  |  | 885 |  |  | — |  |  | 885 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Total cash equivalents | 1,395 |  |  | 1,828 |  |  | — |  |  | 3,223 |  |  | 1,206 |  |  | 169 |  |  | — |  |  | 1,375 |  |
| Short-term investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Certificates of deposit | — |  |  | 3 |  |  | — |  |  | 3 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Commercial paper | — |  |  | 57 |  |  | — |  |  | 57 |  |  | — |  |  | 15 |  |  | — |  |  | 15 |  |
| Corporate debt securities | — |  |  | 280 |  |  | — |  |  | 280 |  |  | — |  |  | 584 |  |  | — |  |  | 584 |  |
| U.S. government and agency securities | — |  |  | 13 |  |  | — |  |  | 13 |  |  | — |  |  | 6 |  |  | — |  |  | 6 |  |
| Non-U.S. government and agency securities | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 3 |  |  | — |  |  | 3 |  |
| Asset-backed securities | — |  |  | 9 |  |  | — |  |  | 9 |  |  | — |  |  | 22 |  |  | — |  |  | 22 |  |
| Total short-term investments | — |  |  | 362 |  |  | — |  |  | 362 |  |  | — |  |  | 630 |  |  | — |  |  | 630 |  |
| Long-term investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | — |  |  | 2,583 |  |  | — |  |  | 2,583 |  |  | — |  |  | 4,050 |  |  | — |  |  | 4,050 |  |
| U.S. government and agency securities | — |  |  | 17 |  |  | — |  |  | 17 |  |  | — |  |  | 164 |  |  | — |  |  | 164 |  |
| Non-U.S. government and agency securities | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 26 |  |  | — |  |  | 26 |  |
| Asset-backed securities | — |  |  | 762 |  |  | — |  |  | 762 |  |  | — |  |  | 1,315 |  |  | — |  |  | 1,315 |  |
| Total long-term investments | — |  |  | 3,362 |  |  | — |  |  | 3,362 |  |  | — |  |  | 5,555 |  |  | — |  |  | 5,555 |  |
| Prepaid expenses and other current assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency forward contracts | — |  |  | 80 |  |  | — |  |  | 80 |  |  | — |  |  | 58 |  |  | — |  |  | 58 |  |
| Total prepaid expenses and other current assets | — |  |  | 80 |  |  | — |  |  | 80 |  |  | — |  |  | 58 |  |  | — |  |  | 58 |  |
| Other assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency forward contracts | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 3 |  |  | — |  |  | 3 |  |
| Total other assets | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 3 |  |  | — |  |  | 3 |  |
| Total assets measured at fair value | $ | 1,395 |  |  | $ | 5,632 |  |  | $ | — |  |  | $ | 7,027 |  |  | $ | 1,206 |  |  | $ | 6,415 |  |  | $ | — |  |  | $ | 7,621 |  |

[0001327567-26-000005:notes:32]
|  | January 31, 2026 |  | July 31, 2025 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Accrued and other liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency forward contracts | $ | — |  |  | $ | 4 |  |  | $ | — |  |  | $ | 4 |  |  | $ | — |  |  | $ | 4 |  |  | $ | — |  |  | $ | 4 |  |
| Contingent consideration | — |  |  | — |  |  | 157 |  |  | 157 |  |  | — |  |  | — |  |  | 276 |  |  | 276 |  |
| Total accrued and other liabilities | — |  |  | 4 |  |  | 157 |  |  | 161 |  |  | — |  |  | 4 |  |  | 276 |  |  | 280 |  |
| Other long-term liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Contingent consideration | — |  |  | — |  |  | 212 |  |  | 212 |  |  | — |  |  | — |  |  | 238 |  |  | 238 |  |
| Total other long-term liabilities | — |  |  | — |  |  | 212 |  |  | 212 |  |  | — |  |  | — |  |  | 238 |  |  | 238 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 4 |  |  | $ | 369 |  |  | $ | 373 |  |  | $ | — |  |  | $ | 4 |  |  | $ | 514 |  |  | $ | 518 |  |

[0001327567-26-000005:notes:33]
[same as prior period, unchanged from 0001327567-25-000035:notes:31]

[0001327567-26-000005:notes:34]
[same as prior period, unchanged from 0001327567-25-000035:notes:32]

[0001327567-26-000005:notes:35]
[same as prior period, unchanged from 0001327567-25-000035:notes:33]

[0001327567-26-000005:notes:36]
|  | Three Months Ended January 31, |  | Six Months Ended January 31, |
|  | 2026 |  | 2025 |  | 2026 |  | 2025 |
| Contingent consideration liability at the beginning of the period | $ | 380 |  |  | $ | 655 |  |  | $ | 514 |  |  | $ | — |  |
| Initial valuation on the acquisition date | — |  |  | — |  |  | — |  |  | 649 |  |
| Change in fair value | 3 |  |  | 10 |  |  | (10) |  |  | 16 |  |
| Payments | (14) |  |  | — |  |  | (135) |  |  | — |  |
| Contingent consideration liability at the end of the period | $ | 369 |  |  | $ | 665 |  |  | $ | 369 |  |  | $ | 665 |  |

[0001327567-26-000005:notes:37]
The total estimated fair value of our financing receivables approximates their carrying amounts as of January 31, 2026 and July 31, 2025. We consider the fair value of our financing receivables to be a Level 3 measurement as we use unobservable inputs in determining discounted cash flows to estimate the fair value.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001327567-26-000005:notes:38]
Cash Equivalents and Investments
Available-for-sale Debt Securities

[0001327567-26-000005:notes:39]
The following tables summarize the amortized cost, unrealized gains and losses, and fair value of our available-for-sale debt securities as of January 31, 2026 and July 31, 2025 (in millions):

[0001327567-26-000005:notes:40]
|  | January 31, 2026 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 14 |  |  | $ | — |  |  | $ | — |  |  | $ | 14 |  |
| Commercial paper | 912 |  |  | — |  |  | — |  |  | 912 |  |
| Corporate debt securities | 17 |  |  | — |  |  | — |  |  | 17 |  |
| U.S. government and agency securities | 885 |  |  | — |  |  | — |  |  | 885 |  |
| Total available-for-sale cash equivalents | $ | 1,828 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,828 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 3 |  |  | $ | — |  |  | $ | — |  |  | $ | 3 |  |
| Commercial paper | 57 |  |  | — |  |  | — |  |  | 57 |  |
| Corporate debt securities | 2,820 |  |  | 43 |  |  | — |  |  | 2,863 |  |
| U.S. government and agency securities | 30 |  |  | — |  |  | — |  |  | 30 |  |
| Asset-backed securities | 762 |  |  | 9 |  |  | — |  |  | 771 |  |
| Total available-for-sale investments | $ | 3,672 |  |  | $ | 52 |  |  | $ | — |  |  | $ | 3,724 |  |

[0001327567-26-000005:notes:41]
|  | July 31, 2025 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | $ | 169 |  |  | $ | — |  |  | $ | — |  |  | $ | 169 |  |
| Total available-for-sale cash equivalents | $ | 169 |  |  | $ | — |  |  | $ | — |  |  | $ | 169 |  |
| Investments: |  |  |  |  |  |  |  |
| Commercial paper | $ | 15 |  |  | $ | — |  |  | $ | — |  |  | $ | 15 |  |
| Corporate debt securities | 4,588 |  |  | 47 |  |  | (1) |  |  | 4,634 |  |
| U.S. government and agency securities | 170 |  |  | — |  |  | — |  |  | 170 |  |
| Non-U.S. government and agency securities | 29 |  |  | — |  |  | — |  |  | 29 |  |
| Asset-backed securities | 1,328 |  |  | 9 |  |  | — |  |  | 1,337 |  |
| Total available-for-sale investments | $ | 6,130 |  |  | $ | 56 |  |  | $ | (1) |  |  | $ | 6,185 |  |

[0001327567-26-000005:notes:42]
Unrealized losses related to our available-for-sale debt securities are primarily due to interest rate fluctuations as opposed to credit quality. We do not intend to sell any of the securities in an unrealized loss position and it is not likely that we would be required to sell these securities before recovery of their amortized cost basis, which may be at maturity. We did not recognize any credit losses related to our available-for-sale debt securities during the three and six months ended January 31, 2026 and 2025.

[0001327567-26-000005:notes:43]
The following table summarizes the amortized cost and fair value of our available-for-sale debt securities as of January 31, 2026, by contractual years-to-maturity (in millions):

[0001327567-26-000005:notes:44]
|  | Amortized Cost |  | Fair Value |
| Due within one year | $ | 2,189 |  |  | $ | 2,190 |  |
| Due between one and three years | 1,180 |  |  | 1,199 |  |
| Due between three and five years | 1,892 |  |  | 1,919 |  |
| Due between five and ten years | 110 |  |  | 111 |  |
| Due after ten years | 129 |  |  | 133 |  |
| Total | $ | 5,500 |  |  | $ | 5,552 |  |

[0001327567-26-000005:notes:45]
Marketable Equity Securities

[0001327567-26-000005:notes:46]
Marketable equity securities consist of money market funds and are included in cash and cash equivalents on our condensed consolidated balance sheets. As of January 31, 2026 and July 31, 2025, the carrying values of our marketable equity securities were $1.4 billion and $1.2 billion, respectively. There were no unrealized gains or losses recognized for these securities during the three and six months ended January 31, 2026 and 2025.


## us-gaap:FinancingReceivablesTextBlock

[0001327567-26-000005:notes:47]
Financing Receivables
The following table summarizes our short-term and long-term financing receivables as of January 31, 2026 and July 31, 2025 (in millions):

[0001327567-26-000005:notes:48]
|  | January 31, 2026 |  | July 31, 2025 |
| Short-term financing receivables, gross | $ | 754 |  |  | $ | 806 |  |
| Unearned income | (75) |  |  | (86) |  |
| Allowance for credit losses | (7) |  |  | (5) |  |
| Short-term financing receivables, net | $ | 672 |  |  | $ | 715 |  |
| Long-term financing receivables, gross | $ | 937 |  |  | $ | 1,079 |  |
| Unearned income | (58) |  |  | (69) |  |
| Allowance for credit losses | (9) |  |  | (8) |  |
| Long-term financing receivables, net | $ | 870 |  |  | $ | 1,002 |  |

[0001327567-26-000005:notes:49]
[same as prior period, unchanged from 0001327567-25-000035:notes:47]

[0001327567-26-000005:notes:50]
| Internal Risk Rating(1) |  | January 31, 2026 |  | July 31, 2025 |
|  | Fiscal Year of Origination |  |  |  | Fiscal Year of Origination |  |  |
|  | 2026 |  | 2025 |  | 2024 |  | 2023 |  | 2022 |  | Total |  | 2025 |  | 2024 |  | 2023 |  | 2022 |  | 2021 |  | Total |
| 1 to 4 |  | $ | 36 |  |  | $ | 257 |  |  | $ | 610 |  |  | $ | 156 |  |  | $ | 5 |  |  | $ | 1,064 |  |  | $ | 261 |  |  | $ | 732 |  |  | $ | 242 |  |  | $ | 9 |  |  | $ | 18 |  |  | $ | 1,262 |  |
| 5 to 6 |  | 129 |  |  | 172 |  |  | 169 |  |  | 14 |  |  | — |  |  | 484 |  |  | 174 |  |  | 226 |  |  | 50 |  |  | — |  |  | — |  |  | 450 |  |
| 7 to 10 |  | — |  |  | — |  |  | 3 |  |  | 7 |  |  | — |  |  | 10 |  |  | — |  |  | 4 |  |  | 14 |  |  | — |  |  | — |  |  | 18 |  |
| Amortized cost basis of financing receivables |  | $ | 165 |  |  | $ | 429 |  |  | $ | 782 |  |  | $ | 177 |  |  | $ | 5 |  |  | $ | 1,558 |  |  | $ | 435 |  |  | $ | 962 |  |  | $ | 306 |  |  | $ | 9 |  |  | $ | 18 |  |  | $ | 1,730 |  |

[0001327567-26-000005:notes:51]
[same as prior period, unchanged from 0001327567-25-000035:notes:49]

[0001327567-26-000005:notes:52]
There was no significant activity in allowance for credit losses during the three and six months ended January 31, 2026 and 2025. Past due amounts on financing receivables were not material as of January 31, 2026 and July 31, 2025.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001327567-26-000005:notes:53]
[same as prior period, unchanged from 0001327567-25-000035:notes:51]

[0001327567-26-000005:notes:54]
As of January 31, 2026 and July 31, 2025, the total notional amount of our outstanding foreign currency forward contracts designated as cash flow hedges was $523 million and $964 million, respectively. Refer to Note 3. Fair Value Measurements for the fair value of our derivative instruments as reported on our condensed consolidated balance sheets as of January 31, 2026 and July 31, 2025.

[0001327567-26-000005:notes:55]
As of January 31, 2026, unrealized gains and losses in accumulated other comprehensive income (“AOCI”) related to our cash flow hedges were a $39 million net gain, of which $40 million in gains are expected to be recognized into earnings within the next 12 months. As of July 31, 2025, unrealized gains and losses in AOCI related to our cash flow hedges were a $40 million net gain.

[0001327567-26-000005:notes:56]
As of January 31, 2026 and July 31, 2025, the notional amount of our outstanding foreign currency forward contracts not designated as hedging instruments was $557 million and $504 million, respectively.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001327567-26-000005:notes:57]
Acquisitions
Chronosphere, Inc.

[0001327567-26-000005:notes:58]
On January 29, 2026, we completed our acquisition of Chronosphere, Inc. (“Chronosphere”), a privately-held observability technology company. The acquisition resulted in forming our observability platform. The total purchase consideration for the acquisition of Chronosphere was $3.0 billion, which consisted of the following (in millions):

[0001327567-26-000005:notes:59]
|  | Amount |
| Cash | $ | 2,842 |  |
| Fair value of replacement awards | 109 |  |
| Total | $ | 2,951 |  |

[0001327567-26-000005:notes:60]
As part of the acquisition, we issued $525 million of replacement equity awards, of which the portion attributable to services performed prior to the acquisition date was allocated to purchase consideration. The remaining fair value was allocated to future services and will be expensed over the remaining service periods as share-based compensation. The replacement equity awards included 2 million shares of our restricted common stock. These restricted common stock vest over a period of two to three years from the date of issuance.

[0001327567-26-000005:notes:61]
We have accounted for this transaction as a business combination and allocated the purchase consideration to assets acquired and liabilities assumed based on preliminary estimated fair values, as presented in the following table (in millions):

[0001327567-26-000005:notes:62]
|  | Amount |
| Goodwill | $ | 2,364 |  |
| Identified intangible assets | 565 |  |
| Cash | 57 |  |
| Net liabilities assumed | (35) |  |
| Total | $ | 2,951 |  |

[0001327567-26-000005:notes:63]
Goodwill generated from this business combination is primarily attributable to the assembled workforce and expected post-acquisition synergies from integrating Chronosphere technology into our platforms. The goodwill is not deductible for U.S. income tax purposes.

[0001327567-26-000005:notes:64]
The following table presents details of the identified intangible asset acquired (in millions, except years):

[0001327567-26-000005:notes:65]
|  | Fair Value |  | Estimated Useful Life |
| Developed technology | $ | 300 |  |  | 5 years |
| Customer relationships | 255 |  |  | 6 years - 10 years |
| Trade name and trademarks | 10 |  |  | 1 year |
| Total | $ | 565 |  |  |  |

[0001327567-26-000005:notes:66]
We have included the financial results of Chronosphere in our consolidated financial statements from the date of acquisition. Post-acquisition revenue and earnings of Chronosphere were not material to our condensed consolidated statements of operations for the three and six months ended January 31, 2026.

[0001327567-26-000005:notes:67]
CyberArk Software Ltd.

[0001327567-26-000005:notes:68]
On July 30, 2025, we entered into a definitive agreement to acquire CyberArk Software Ltd., an identity security company (“CyberArk”). Under the terms of the agreement, CyberArk shareholders were entitled to receive $45.00 in cash and 2.2005 shares of our common stock for each CyberArk share.

[0001327567-26-000005:notes:69]
On February 11, 2026, we completed the acquisition of CyberArk. Refer to 16. Subsequent Events for additional information. This acquisition will be accounted for as a business combination in the third quarter of fiscal 2026.

[0001327567-26-000005:notes:70]
Additional Acquisition-Related Information

[0001327567-26-000005:notes:71]
The following unaudited pro forma financial information summarizes the combined results of operations for Palo Alto Networks and Chronosphere, as though the companies were combined as of the beginning of our fiscal 2025 (in millions):

[0001327567-26-000005:notes:72]
|  | Three Months Ended January 31, |  | Six Months Ended January 31, |
|  | 2026 |  | 2025 |  | 2026 |  | 2025 |
| Total revenue | $ | 2,643 |  |  | $ | 2,271 |  |  | $ | 5,158 |  |  | $ | 4,423 |  |
| Net income | $ | 286 |  |  | $ | 173 |  |  | $ | 535 |  |  | $ | 422 |  |

[0001327567-26-000005:notes:73]
The unaudited pro forma financial information include adjustments attributable to our acquisition of Chronosphere, including amortization for intangible assets acquired and stock-based compensation expense from assumed replacement equity awards. The unaudited pro forma financial information is for informational purposes only and is not necessarily indicative of the results of operations that would have been achieved if the acquisition had taken place at the beginning of our fiscal 2025 or of the results of our future operations of the combined business.

[0001327567-26-000005:notes:74]
Additional information related to our acquisitions, such as that related to income tax and other contingencies, existing as of the acquisition date may become known during the remainder of the measurement period, not to exceed 12 months from the acquisition date, which may result in changes to the amounts and allocations recorded.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001327567-26-000005:notes:75]
Goodwill, Intangible Assets and Other Long-Lived Assets
Goodwill

[0001327567-26-000005:notes:76]
The following table presents details of our goodwill during the six months ended January 31, 2026 (in millions):

[0001327567-26-000005:notes:77]
|  | Amount |
| Balance as of July 31, 2025 | $ | 4,567 |  |
| Goodwill acquired | 2,364 |  |
| Balance as of January 31, 2026 | $ | 6,931 |  |

[0001327567-26-000005:notes:78]
Purchased Intangible Assets

[0001327567-26-000005:notes:79]
The following table presents details of our purchased intangible assets as of January 31, 2026 and July 31, 2025 (in millions):

[0001327567-26-000005:notes:80]
|  | January 31, 2026 |  | July 31, 2025 |
|  | Gross Carrying Amount |  | Accumulated Amortization |  | Net Carrying Amount |  | Gross Carrying Amount |  | Accumulated Amortization |  | Net Carrying Amount |
| Intangible assets subject to amortization: |  |  |  |  |  |  |  |  |  |  |  |
| Developed technology | $ | 815 |  |  | $ | (303) |  |  | $ | 512 |  |  | $ | 536 |  |  | $ | (274) |  |  | $ | 262 |  |
| Customer relationships | 864 |  |  | (151) |  |  | 713 |  |  | 609 |  |  | (123) |  |  | 486 |  |
| Acquired intellectual property | 24 |  |  | (10) |  |  | 14 |  |  | 24 |  |  | (9) |  |  | 15 |  |
| Trade name and trademarks | 10 |  |  | — |  |  | 10 |  |  | — |  |  | — |  |  | — |  |
| Other | — |  |  | — |  |  | — |  |  | 1 |  |  | (1) |  |  | — |  |
| Total purchased intangible assets | $ | 1,713 |  |  | $ | (464) |  |  | $ | 1,249 |  |  | $ | 1,170 |  |  | $ | (407) |  |  | $ | 763 |  |

[0001327567-26-000005:notes:81]
We recognized amortization expense of $39 million and $79 million for the three and six months ended January 31, 2026, respectively, and $45 million and $86 million for the three and six months ended January 31, 2025, respectively.

[0001327567-26-000005:notes:82]
The following table summarizes estimated future amortization expense of our intangible assets subject to amortization as of January 31, 2026 (in millions):

[0001327567-26-000005:notes:83]
|  |  |  | Fiscal years ending July 31, |
|  | Total |  | Remaining 2026 |  | 2027 |  | 2028 |  | 2029 |  | 2030 |  | 2031 and Thereafter |
| Future amortization expense | $ | 1,249 |  |  | $ | 130 |  |  | $ | 224 |  |  | $ | 199 |  |  | $ | 173 |  |  | $ | 156 |  |  | $ | 367 |  |

[0001327567-26-000005:notes:84]
Other Long-lived assets

[0001327567-26-000005:notes:85]
During the six months ended January 31, 2026, we purchased 14.5 acres of land adjacent to our headquarters in Santa Clara, California, for $91 million to accommodate future expansion of our headquarters. This amount was recorded in property and equipment, net on our condensed consolidated balance sheet as of January 31, 2026.


## us-gaap:DebtDisclosureTextBlock

[0001327567-26-000005:notes:86]
Debt
Convertible Senior Notes, Note Hedges, and Warrants

[0001327567-26-000005:notes:87]
In June 2020, we issued $2.0 billion aggregate principal amount of 0.375% Convertible Senior Notes due 2025 (the “2025 Notes”). The 2025 Notes were converted prior to or settled on the maturity date of June 1, 2025 in accordance with their terms.

[0001327567-26-000005:notes:88]
Concurrent with the issuance of the 2025 Notes, we entered into separate convertible note hedge transactions (the “2025 Note Hedges”) with respect to our common stock for an aggregate payment of $371 million. The 2025 Note Hedges expired upon maturity of the 2025 Notes. Any shares of our common stock receivable by us under the 2025 Note Hedges are excluded from the calculation of diluted earnings per share as they are antidilutive.

[0001327567-26-000005:notes:89]
Separately, but concurrently with the issuance of our 2025 Notes, we entered into transactions whereby we sold warrants (the “2025 Warrants”) to acquire 40 million shares of our common stock with a strike price of $68.08 per share, subject to anti-dilution adjustments, for aggregate proceeds of $203 million. The 2025 Warrants are exercisable over 60 scheduled trading days beginning September 2025. The shares issuable under the 2025 Warrants are included in the calculation of diluted earnings per share when the average market value per share of our common stock for the reporting period exceeds the strike price of the 2025 Warrants.

[0001327567-26-000005:notes:90]
During the six months ended January 31, 2026, we net settled all of the 2025 Warrants with the issuance of 27 million shares of our common stock with a fair value of $5.6 billion, of which 7 million shares of our common stock with a fair value of $1.5 billion were issued during the three months ended January 31, 2026. The number of net shares issued was determined based on the number of 2025 Warrants exercised multiplied by the difference between the strike price of the 2025 Warrants and their daily volume-weighted-average stock price.

[0001327567-26-000005:notes:91]
Revolving Credit Facility

[0001327567-26-000005:notes:92]
On April 13, 2023, we entered into a credit agreement (the “Credit Agreement”) with certain institutional lenders that provides for a $400 million unsecured revolving credit facility (the “Credit Facility”), with an option to increase the amount of the Credit Facility by up to an additional $350 million, subject to certain conditions. The Credit Facility matures on April 13, 2028.

[0001327567-26-000005:notes:93]
The borrowings under the Credit Facility bear interest, at our option, at a base rate plus a spread of 0.000% to 0.375%, or an adjusted term Secured Overnight Financing Rate plus a spread of 1.000% to 1.375%, in each case with such spread being determined based on our leverage ratio. We are obligated to pay an ongoing commitment fee on undrawn amounts at a rate of 0.090% to 0.150%, depending on our leverage ratio. The interest rates and commitment fees are also subject to upward and downward adjustments based on our progress towards the achievement of certain sustainability goals.

[0001327567-26-000005:notes:94]
As of January 31, 2026, there were no amounts outstanding and we were in compliance with all covenants under the Credit Agreement.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001327567-26-000005:notes:95]
Commitments and Contingencies
Purchase Commitments

[0001327567-26-000005:notes:96]
We have entered into various non-cancelable agreements with cloud hosting service providers, under which we are committed to minimum or fixed purchases of certain cloud hosting services. In addition, in order to reduce manufacturing lead times and plan for adequate supply, we have entered into agreements with manufacturing partners and component suppliers to procure inventory based on our demand forecasts. Other purchase obligations include non-cancellable subscription agreements and other commitments in the normal course of business. The following table presents details of the aggregate future non-cancelable purchase commitments under these agreements as of January 31, 2026 (in millions):

[0001327567-26-000005:notes:97]
|  |  |  | Fiscal years ending July 31, |
|  | Total |  | Remaining 2026 |  | 2027 |  | 2028 |  | 2029 |  | 2030 |  | 2031 and Thereafter |
| Cloud | $ | 6,446 |  |  | $ | 65 |  |  | $ | 535 |  |  | $ | 1,078 |  |  | $ | 1,122 |  |  | $ | 1,148 |  |  | $ | 2,498 |  |
| Manufacturing | 198 |  |  | 176 |  |  | 22 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Other | 145 |  |  | 43 |  |  | 71 |  |  | 13 |  |  | 9 |  |  | 9 |  |  | — |  |
| Total | $ | 6,789 |  |  | $ | 284 |  |  | $ | 628 |  |  | $ | 1,091 |  |  | $ | 1,131 |  |  | $ | 1,157 |  |  | $ | 2,498 |  |

[0001327567-26-000005:notes:98]
Additionally, we have a $104 million minimum purchase commitment with a cloud hosting service provider through September 2027 with no specified annual commitments.

[0001327567-26-000005:notes:99]
Litigation

[0001327567-26-000005:notes:100]
We are subject to legal proceedings, claims, tax matters, and litigation arising in the ordinary course of business, including, for instance, intellectual property and patent litigation. We accrue for contingencies when we believe that a loss is probable and that we can reasonably estimate the amount of any such loss.

[0001327567-26-000005:notes:101]
Legal matters could include speculative, substantial, or indeterminate monetary amounts. Significant judgment is required to determine both the likelihood of there being a loss and the estimated amount of a loss related to such matters, and we may be unable to estimate the reasonably possible loss or range of loss. The outcomes of outstanding legal matters are inherently unpredictable, and could, either individually or in aggregate, have a material adverse effect on us and our results of operations. To the extent there is a reasonable possibility that a loss exceeding any amounts already recognized may be incurred, we will either disclose the estimated additional loss or state that such an estimate cannot be made.

[0001327567-26-000005:notes:102]
The following matters arose in the ordinary course of business.

[0001327567-26-000005:notes:103]
Centripetal Networks, Inc. v. Palo Alto Networks

[0001327567-26-000005:notes:104]
On March 12, 2021, Centripetal Networks, Inc., filed a lawsuit against us in the United States District Court for the Eastern District of Virginia. The lawsuit alleges that our products infringe multiple Centripetal patents. We successfully challenged certain of these patents, which were found unpatentable by the U.S. Patent and Trademark Office (“PTO”). The case went to jury trial on January 22, 2024, on four patents. On January 31, 2024, the jury returned a verdict of non-willful infringement with a lump sum amount of $152 million, plus statutory interest. After post-trial motions, a judgment was issued on October 3, 2024 affirming infringement on three patents, reversing infringement on the fourth patent, and subsequently, reducing the damages amount to $114 million. We posted a surety bond that was agreed upon by the parties and approved by the court. This bond prevents execution of the judgment while appeals are pending. In addition, Centripetal filed infringement contentions on certain of their patents in the European Patent Office and Unified Patent Court in Germany, to which we filed appropriate legal challenges. Those matters are still pending.

[0001327567-26-000005:notes:105]
As of January 31, 2026 and July 31, 2025, we accrued $149 million and $146 million based on the judgment and estimated interest, which is recorded in other long-term liabilities on our condensed consolidated balance sheets. The corresponding interest charge was $2 million and $3 million for the three and six months ended January 31, 2026, respectively. We recorded a charge of $1 million and a release of $42 million for the three and six months ended January 31, 2025, respectively. These amounts are included in general and administrative expense on our condensed consolidated statements of operations.

[0001327567-26-000005:notes:106]
Finjan, Inc. v. Palo Alto Networks

[0001327567-26-000005:notes:107]
On November 4, 2014, Finjan, Inc., filed a lawsuit against us in the United States District Court for the Northern District of California. The lawsuit alleges that our products infringe multiple Finjan patents. The complaint requests injunctive relief, monetary damages, and attorneys’ fees. On March 21, 2025, the judge issued an order granting summary judgment of non-infringement on all remaining patents at issue. Plaintiff filed a Notice of Appeal on April 21, 2025. We are unable, at this time, to reasonably estimate a possible loss or potential range of loss, if any.

[0001327567-26-000005:notes:108]
Eire OG Innovations. v. Palo Alto Networks

[0001327567-26-000005:notes:109]
On April 3, 2024, Eire OG Innovations filed a lawsuit against us in the United States District Court for the Eastern District of Texas asserting infringement of multiple patents, certain of which were subsequently dismissed. The parties have resolved all pending matters between them as of December 2025. The amount paid by us to resolve these matters was not material.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001327567-26-000005:notes:110]
[same as prior period, unchanged from 0001327567-25-000035:notes:88]

[0001327567-26-000005:notes:111]
In February 2019, our board of directors authorized a $1.0 billion share repurchase program, which is funded from available working capital. Our board of directors subsequently authorized additional increases to this share repurchase program, bringing the total authorization under this share repurchase program to $4.1 billion (our “current authorization”). The expiration date of our current authorization was extended to December 31, 2026, and our repurchase program may be suspended or discontinued at any time. Repurchases may be made at management’s discretion from time to time on the open market, through privately negotiated transactions, transactions structured through investment banking institutions, block purchase techniques, 10b5-1 trading plans, or a combination of the foregoing.

[0001327567-26-000005:notes:112]
We did not repurchase shares of our common stock during the three and six months ended January 31, 2026 and 2025.
As of January 31, 2026, $1.0 billion remained available for future share repurchases under our current repurchase authorization.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001327567-26-000005:notes:113]
[same as prior period, unchanged from 0001327567-25-000035:notes:91]

[0001327567-26-000005:notes:114]
The following table summarizes the RSU and PSU activity under our stock plans during the six months ended January 31, 2026 (in millions, except per share amounts):

[0001327567-26-000005:notes:115]
|  | Unvested RSUs |  | Unvested PSUs |
|  | Number of Shares |  | Weighted-Average Grant-Date Fair Value Per Share |  |  |  | Aggregate Intrinsic Value |  | Number of Shares |  | Weighted-Average Grant-Date Fair Value Per Share |  |  |  | Aggregate Intrinsic Value |
| Balance—July 31, 2025 | 13 |  |  | $ | 143.33 |  |  |  |  | $ | 2,285 |  |  | 9 |  |  | $ | 140.92 |  |  |  |  | $ | 1,635 |  |
| Granted(1)(2) | 5 |  |  | $ | 200.15 |  |  |  |  |  |  | 4 |  |  | $ | 186.49 |  |  |  |  |  |
| Vested(3) | (3) |  |  | $ | 126.28 |  |  |  |  |  |  | (3) |  |  | $ | 151.12 |  |  |  |  |  |
| Forfeited | (1) |  |  | $ | 146.80 |  |  |  |  |  |  | (2) |  |  | $ | 143.61 |  |  |  |  |  |
| Balance—January 31, 2026 | 14 |  |  | $ | 168.38 |  |  |  |  | $ | 2,533 |  |  | 8 |  |  | $ | 155.96 |  |  |  |  | $ | 1,464 |  |

[0001327567-26-000005:notes:116]
[same as prior period, unchanged from 0001327567-25-000035:notes:94]

[0001327567-26-000005:notes:117]
(2)Includes 1 million RSUs assumed in connection with the acquisition of Chronosphere, with a weighted-average grant-date fair value of $176.20 per share for the six months ended January 31, 2026.

[0001327567-26-000005:notes:118]
(3)Includes time-based vesting for PSUs.

[0001327567-26-000005:notes:119]
[same as prior period, unchanged from 0001327567-25-000035:notes:96]

[0001327567-26-000005:notes:120]
[same as prior period, unchanged from 0001327567-25-000035:notes:97]

[0001327567-26-000005:notes:121]
During the six months ended January 31, 2026, we granted 3 million shares of PSUs that contain service, performance, and market conditions. The service conditions are satisfied after a period of one to three years. The performance conditions are based on an average of next-generation security annualized recurring revenue and non-GAAP net income per diluted share. The market condition is measured based on our total shareholder return (“TSR”) relative to the TSR of the companies listed in the Standard & Poor’s 500 index. As of January 31, 2026, we have approved 3 million shares of PSUs, which will be granted upon the performance condition being established during the next two fiscal years.

[0001327567-26-000005:notes:122]
The fair value of the PSUs subject to market conditions is estimated on the grant date using a Monte Carlo simulation model. The following table summarizes the assumptions used and the resulting grant-date fair value of our PSUs subject to market conditions granted during the three and six months ended January 31, 2026 and 2025:

[0001327567-26-000005:notes:123]
|  |  |  | Three Months Ended January 31, |  | Six Months Ended January 31, |
|  |  |  | 2025 |  | 2026 |  | 2025 |
| Volatility |  |  | 43.5% - 43.9% |  | 36.6% - 42.6% |  | 43.5% - 47.6% |
| Expected term (in years) |  |  | 1.7 - 2.7 |  | 1.0 - 3.0 |  | 1.0 - 2.9 |
| Dividend yield |  |  | 0.0 | % |  | 0.0 | % |  | 0.0 | % |
| Risk-free interest rate |  |  | 4.2% - 4.2% |  | 3.6% - 3.9% |  | 3.7% - 4.5% |
| Grant-date fair value per share |  |  | $287.98 - $291.91 |  | $226.06 - $261.62 |  | $264.51 - $305.83 |

[0001327567-26-000005:notes:124]
[same as prior period, unchanged from 0001327567-25-000035:notes:101]

[0001327567-26-000005:notes:125]
We have granted PSOs with both service and market conditions. The market conditions were achieved when certain stock price targets were met. As of January 31, 2026 and July 31, 2025, all of our outstanding PSOs have been fully vested. The maximum contractual term of our outstanding PSOs is seven and a half years from the date of grant in fiscal year 2018 and 2019.

[0001327567-26-000005:notes:126]
The following table summarizes the PSO activity under our stock plans during the six months ended January 31, 2026 (in millions, except per share amounts):

[0001327567-26-000005:notes:127]
|  |  |  |  |  |  |  |  |  | Number of Shares |  | Weighted-Average Exercise Price Per Share |  | Weighted-Average Remaining Contractual Term (Years) |  | Aggregate Intrinsic Value |
| Balance—July 31, 2025 |  |  |  |  |  |  |  |  | 1 |  |  | $ | 32.76 |  |  | 0.5 |  | $ | 197 |  |
| Exercised |  |  |  |  |  |  |  |  | (1) |  |  | $ | 32.76 |  |  |  |  |  |
| Balance—January 31, 2026 |  |  |  |  |  |  |  |  | — |  |  | $ | — |  |  | 0.0 |  | $ | — |  |
| Exercisable—January 31, 2026 |  |  |  |  |  |  |  |  | — |  |  | $ | — |  |  | 0.0 |  | $ | — |  |

[0001327567-26-000005:notes:128]
[same as prior period, unchanged from 0001327567-25-000035:notes:105]

[0001327567-26-000005:notes:129]
[same as prior period, unchanged from 0001327567-25-000035:notes:106]

[0001327567-26-000005:notes:130]
|  | Three Months Ended January 31, |  | Six Months Ended January 31, |
|  | 2026 |  | 2025 |  | 2026 |  | 2025 |
| Cost of product revenue | $ | 1 |  |  | $ | 2 |  |  | $ | 2 |  |  | $ | 3 |  |
| Cost of subscription and support revenue | 32 |  |  | 32 |  |  | 64 |  |  | 63 |  |
| Research and development | 116 |  |  | 139 |  |  | 271 |  |  | 277 |  |
| Sales and marketing | 98 |  |  | 90 |  |  | 200 |  |  | 166 |  |
| General and administrative | 54 |  |  | 57 |  |  | 134 |  |  | 106 |  |
| Total share-based compensation | $ | 301 |  |  | $ | 320 |  |  | $ | 671 |  |  | $ | 615 |  |

[0001327567-26-000005:notes:131]
As of January 31, 2026, total compensation cost related to unvested share-based awards not yet recognized was $2.9 billion. This cost is expected to be amortized over a weighted-average period of approximately 2.6 years.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001327567-26-000005:notes:132]
Income Taxes
Our income taxes primarily consist of U.S. and foreign income taxes and our effective tax rates differ from the U.S. statutory tax rate primarily due to the excess tax benefits from share-based compensation.

[0001327567-26-000005:notes:133]
For the three and six months ended January 31, 2026, our provision for income taxes reflected effective tax rates of 21.3% and 20.3%, respectively. For the three and six months ended January 31, 2025, our provision for income taxes reflected effective tax rates of 17.7% and 10.9%, respectively. Our effective tax rates for the three and six months ended January 31, 2026 increased as compared to the same periods in 2025 primarily due to decreased excess tax benefits from share-based compensation relative to our increased business profits.


## us-gaap:EarningsPerShareTextBlock

[0001327567-26-000005:notes:134]
[same as prior period, unchanged from 0001327567-25-000035:notes:111]

[0001327567-26-000005:notes:135]
[same as prior period, unchanged from 0001327567-25-000035:notes:112]

[0001327567-26-000005:notes:136]
|  | Three Months Ended January 31, |  | Six Months Ended January 31, |
|  | 2026 |  | 2025 |  | 2026 |  | 2025 |
| Net income | $ | 432 |  |  | $ | 267 |  |  | $ | 766 |  |  | $ | 618 |  |
| Weighted-average shares used to compute net income per share, basic | 704 |  |  | 659 |  |  | 695 |  |  | 657 |  |
| Weighted-average effect of potentially dilutive securities: |  |  |  |  |  |  |  |
| Convertible senior notes | — |  |  | 9 |  |  | — |  |  | 10 |  |
| Warrants related to the issuance of convertible senior notes | 1 |  |  | 26 |  |  | 10 |  |  | 25 |  |
| Employee equity incentive plans | 6 |  |  | 15 |  |  | 8 |  |  | 17 |  |
| Weighted-average shares used to compute net income per share, diluted | 711 |  |  | 709 |  |  | 713 |  |  | 709 |  |
| Net income per share, basic | $ | 0.61 |  |  | $ | 0.41 |  |  | $ | 1.10 |  |  | $ | 0.94 |  |
| Net income per share, diluted | $ | 0.61 |  |  | $ | 0.38 |  |  | $ | 1.07 |  |  | $ | 0.87 |  |

[0001327567-26-000005:notes:137]
[same as prior period, unchanged from 0001327567-25-000035:notes:114]

[0001327567-26-000005:notes:138]
|  | Three Months Ended January 31, |  | Six Months Ended January 31, |
|  | 2026 |  | 2025 |  | 2026 |  | 2025 |
| Employee equity incentive plans | 6 |  |  | 6 |  |  | 4 |  |  | 5 |  |


## us-gaap:OtherNonoperatingIncomeAndExpenseTextBlock

[0001327567-26-000005:notes:139]
[same as prior period, unchanged from 0001327567-25-000035:notes:116]

[0001327567-26-000005:notes:140]
|  | Three Months Ended January 31, |  | Six Months Ended January 31, |
|  | 2026 |  | 2025 |  | 2026 |  | 2025 |
| Interest income | $ | 109 |  |  | $ | 87 |  |  | $ | 214 |  |  | $ | 173 |  |
| Foreign currency exchange gains (losses), net | (16) |  |  | 2 |  |  | (27) |  |  | (6) |  |
| Other, net | 59 |  |  | (4) |  |  | 68 |  |  | 1 |  |
| Total other income, net | $ | 152 |  |  | $ | 85 |  |  | $ | 255 |  |  | $ | 168 |  |


## us-gaap:SubsequentEventsTextBlock

[0001327567-26-000005:notes:141]
Subsequent Events
CyberArk Software Ltd.

[0001327567-26-000005:notes:142]
On February 11, 2026, we completed the acquisition of CyberArk for $2.3 billion in cash and 112 million shares of our common stock. The cash portion of the consideration was funded with our cash on hand. We also assumed certain unvested outstanding equity awards held by CyberArk employees under certain of CyberArk’s share incentive plans.

[0001327567-26-000005:notes:143]
Koi Security Ltd.

[0001327567-26-000005:notes:144]
On February 16, 2026, we entered into a definitive agreement to acquire Koi Security Ltd., a privately-held endpoint posture management company (“Koi Security”), in exchange for total consideration of $300 million in cash and replacement awards, subject to adjustments. We expect the acquisition to expand the capabilities of our security operations platform. The acquisition of Koi Security is expected to close during the second half of our fiscal 2026, subject to the satisfaction of closing conditions, including regulatory clearance.


## ecd:MtrlTermsOfTrdArrTextBlock

[0001327567-26-000005:notes:145]
Set forth below is certain information regarding Rule 10b5-1 trading plans adopted or terminated by our directors and officers (as defined in Rule 16a-1(f)) during the second quarter of fiscal 2026. The Rule 10b5-1 trading plans listed below are each intended to satisfy the affirmative defense of Rule 10b5-1(c).

[0001327567-26-000005:notes:146]
| Name |  | Title |  | Date Plan Was Adopted |  | Date Plan Was Terminated |  | Expiration Date |  | Total Amount of Common Stock to Be Sold Under the Plan |
| Joshua Paul |  | Chief Accounting Officer |  | September 17, 2025 |  | Not applicable |  | December 31, 2026 or, if earlier, when all shares have been sold |  | Up to 10,200 |
| Dipak Golechha |  | Chief Financial Officer |  | December 5, 2025 |  | Not applicable |  | March 31, 2027 or, if earlier, when all shares have been sold |  | 20,000 |
| Lee Klarich |  | Chief Product and Technology Officer |  | December 11, 2025 |  | Not applicable |  | October 30, 2026 or, if earlier, when all shares have been sold |  | 62,904 |

[0001327567-26-000005:notes:147]
No other officers or directors, as defined in Rule 16a-1(f), adopted, modified, and/or terminated a “Rule 10b5-1 trading arrangement” or a “non-Rule 10b5-1 trading arrangement,” as defined in Regulation S-K Item 408, during the second quarter of fiscal 2026.
