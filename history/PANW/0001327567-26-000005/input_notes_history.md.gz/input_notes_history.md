# PANW note change history — 0001327567-25-000035 → 0001327567-26-000005


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2026-02-18):
[0001327567-26-000005:note_history:1]
We have entered into various non-cancelable agreements with cloud hosting service providers, under which we are committed to minimum or fixed purchases of certain cloud hosting services. In addition, in order to reduce manufacturing lead times and plan for adequate supply, we have entered into agreements with manufacturing partners and component suppliers to procure inventory based on our demand forecasts. Other purchase obligations include non-cancellable subscription agreements and other commitments in the normal course of business. The following table presents details of the aggregate future non-cancelable purchase commitments under these agreements as of January 31, 2026 (in millions):
  (was, 2025-11-20, similarity 0.9899):
[0001327567-25-000035:note_history:1]
We have entered into various non-cancelable agreements with cloud hosting service providers, under which we are committed to minimum or fixed purchases of certain cloud hosting services. In addition, in order to reduce manufacturing lead times and plan for adequate supply, we have entered into agreements with manufacturing partners and component suppliers to procure inventory based on our demand forecasts. Other purchase obligations include non-cancellable subscription agreements and other commitments in the normal course of business. The following table presents details of the aggregate future non-cancelable purchase commitments under these agreements as of October 31, 2025 (in millions):

- changed (2026-02-18):
[0001327567-26-000005:note_history:2]
|  |  |  | Fiscal years ending July 31, |
|  | Total |  | Remaining 2026 |  | 2027 |  | 2028 |  | 2029 |  | 2030 |  | 2031 and Thereafter |
| Cloud | $ | 6,446 |  |  | $ | 65 |  |  | $ | 535 |  |  | $ | 1,078 |  |  | $ | 1,122 |  |  | $ | 1,148 |  |  | $ | 2,498 |  |
| Manufacturing | 198 |  |  | 176 |  |  | 22 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Other | 145 |  |  | 43 |  |  | 71 |  |  | 13 |  |  | 9 |  |  | 9 |  |  | — |  |
| Total | $ | 6,789 |  |  | $ | 284 |  |  | $ | 628 |  |  | $ | 1,091 |  |  | $ | 1,131 |  |  | $ | 1,157 |  |  | $ | 2,498 |  |
  (was, 2025-11-20, similarity 0.9977):
[0001327567-25-000035:note_history:2]
|  |  |  | Fiscal years ending July 31, |
|  | Total |  | Remaining 2026 |  | 2027 |  | 2028 |  | 2029 |  | 2030 |  | 2031 and Thereafter |
| Cloud | $ | 6,380 |  |  | $ | 60 |  |  | $ | 660 |  |  | $ | 998 |  |  | $ | 1,017 |  |  | $ | 1,148 |  |  | $ | 2,497 |  |
| Manufacturing | 185 |  |  | 185 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Other | 141 |  |  | 66 |  |  | 61 |  |  | 7 |  |  | 3 |  |  | 4 |  |  | — |  |
| Total | $ | 6,706 |  |  | $ | 311 |  |  | $ | 721 |  |  | $ | 1,005 |  |  | $ | 1,020 |  |  | $ | 1,152 |  |  | $ | 2,497 |  |

- changed (2026-02-18):
[0001327567-26-000005:note_history:3]
As of January 31, 2026 and July 31, 2025, we accrued $149 million and $146 million based on the judgment and estimated interest, which is recorded in other long-term liabilities on our condensed consolidated balance sheets. The corresponding interest charge was $2 million and $3 million for the three and six months ended January 31, 2026, respectively. We recorded a charge of $1 million and a release of $42 million for the three and six months ended January 31, 2025, respectively. These amounts are included in general and administrative expense on our condensed consolidated statements of operations.
  (was, 2025-11-20, similarity 0.7333):
[0001327567-25-000035:note_history:3]
As of October 31, 2025 and July 31, 2025, we accrued $147 million and $146 million based on the judgment and estimated interest, which is recorded in other long-term liabilities on our condensed consolidated balance sheets. The corresponding charge was $1 million for the three months ended October 31, 2025. We recorded a release of $43 million for the three months ended October 31, 2024. These amounts are included in general and administrative expense on our condensed consolidated statements of operations.

- changed (2026-02-18):
[0001327567-26-000005:note_history:4]
On April 3, 2024, Eire OG Innovations filed a lawsuit against us in the United States District Court for the Eastern District of Texas asserting infringement of multiple patents, certain of which were subsequently dismissed. The parties have resolved all pending matters between them as of December 2025. The amount paid by us to resolve these matters was not material.
  (was, 2025-11-20, similarity 0.6123):
[0001327567-25-000035:note_history:4]
On April 3, 2024, Eire OG Innovations filed a lawsuit against us in the United States District Court for the Eastern District of Texas asserting infringement of multiple patents, certain of which were subsequently dismissed. The complaint requests monetary damages and attorneys’ fees. Trial is set for February 17, 2026. As of October 31, 2025, we accrued for an immaterial amount related to this matter.


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2026-02-18):
[0001327567-26-000005:note_history:5]
There have been no material changes to our significant accounting policies as of and for the six months ended January 31, 2026, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended July 31, 2025.
  (was, 2025-11-20, similarity 0.9004):
[0001327567-25-000035:note_history:5]
There have been no material changes to our significant accounting policies as of and for the three months ended October 31, 2025, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended July 31, 2025.

- added (2026-02-18):
[0001327567-26-000005:note_history:6]
Hedge Accounting Improvements

- added (2026-02-18):
[0001327567-26-000005:note_history:7]
In November 2025, the FASB issued authoritative guidance that clarifies and improves the existing hedge accounting guidance to better reflect the economics of an entity’s risk management activities. The standard is effective for our annual and interim periods beginning in the first quarter of fiscal 2028 and will be applied on a prospective basis. Early adoption is permitted. We are currently evaluating the impact of this standard on our consolidated financial statements.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2026-02-18):
[0001327567-26-000005:note_history:8]
During the six months ended January 31, 2026, we net settled all of the 2025 Warrants with the issuance of 27 million shares of our common stock with a fair value of $5.6 billion, of which 7 million shares of our common stock with a fair value of $1.5 billion were issued during the three months ended January 31, 2026. The number of net shares issued was determined based on the number of 2025 Warrants exercised multiplied by the difference between the strike price of the 2025 Warrants and their daily volume-weighted-average stock price.

- changed (2026-02-18):
[0001327567-26-000005:note_history:9]
As of January 31, 2026, there were no amounts outstanding and we were in compliance with all covenants under the Credit Agreement.
  (was, 2025-11-20, similarity 0.9516):
[0001327567-25-000035:note_history:9]
As of October 31, 2025, there were no amounts outstanding and we were in compliance with all covenants under the Credit Agreement.

- removed (2026-02-18):
[0001327567-25-000035:note_history:10]
During the three months ended October 31, 2025, we net settled a portion of the 2025 Warrants with 20 million shares of our common stock with a fair value of $4.1 billion. The number of net shares issued was determined based on the number of 2025 Warrants exercised multiplied by the difference between the strike price of the 2025 Warrants and their daily volume-weighted-average stock price. As of October 31, 2025, up to 11 million shares of our common stock were issuable for gross settlement under the remaining outstanding 2025 Warrants, which will be net settled when exercised through the end of November 2025.


## us-gaap:DebtSecuritiesAvailableForSaleTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2026-02-18):
[0001327567-26-000005:note_history:11]
The following tables summarize the amortized cost, unrealized gains and losses, and fair value of our available-for-sale debt securities as of January 31, 2026 and July 31, 2025 (in millions):
  (was, 2025-11-20, similarity 0.967):
[0001327567-25-000035:note_history:11]
The following tables summarize the amortized cost, unrealized gains and losses, and fair value of our available-for-sale debt securities as of October 31, 2025 and July 31, 2025 (in millions):

- changed (2026-02-18):
[0001327567-26-000005:note_history:12]
|  | January 31, 2026 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 14 |  |  | $ | — |  |  | $ | — |  |  | $ | 14 |  |
| Commercial paper | 912 |  |  | — |  |  | — |  |  | 912 |  |
| Corporate debt securities | 17 |  |  | — |  |  | — |  |  | 17 |  |
| U.S. government and agency securities | 885 |  |  | — |  |  | — |  |  | 885 |  |
| Total available-for-sale cash equivalents | $ | 1,828 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,828 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 3 |  |  | $ | — |  |  | $ | — |  |  | $ | 3 |  |
| Commercial paper | 57 |  |  | — |  |  | — |  |  | 57 |  |
| Corporate debt securities | 2,820 |  |  | 43 |  |  | — |  |  | 2,863 |  |
| U.S. government and agency securities | 30 |  |  | — |  |  | — |  |  | 30 |  |
| Asset-backed securities | 762 |  |  | 9 |  |  | — |  |  | 771 |  |
| Total available-for-sale investments | $ | 3,672 |  |  | $ | 52 |  |  | $ | — |  |  | $ | 3,724 |  |
  (was, 2025-11-20, similarity 0.8422):
[0001327567-25-000035:note_history:12]
|  | October 31, 2025 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | $ | 755 |  |  | $ | — |  |  | $ | — |  |  | $ | 755 |  |
| Corporate debt securities | 157 |  |  | — |  |  | — |  |  | 157 |  |
| U.S. government and agency securities | 178 |  |  | — |  |  | — |  |  | 178 |  |
| Total available-for-sale cash equivalents | $ | 1,090 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,090 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 25 |  |  | $ | — |  |  | $ | — |  |  | $ | 25 |  |
| Commercial paper | 340 |  |  | — |  |  | — |  |  | 340 |  |
| Corporate debt securities | 5,120 |  |  | 73 |  |  | (1) |  |  | 5,192 |  |
| U.S. government and agency securities | 99 |  |  | — |  |  | — |  |  | 99 |  |
| Non-U.S. government and agency securities | 29 |  |  | — |  |  | — |  |  | 29 |  |
| Asset-backed securities | 1,421 |  |  | 15 |  |  | — |  |  | 1,436 |  |
| Total available-for-sale investments | $ | 7,034 |  |  | $ | 88 |  |  | $ | (1) |  |  | $ | 7,121 |  |

- changed (2026-02-18):
[0001327567-26-000005:note_history:13]
|  | July 31, 2025 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | $ | 169 |  |  | $ | — |  |  | $ | — |  |  | $ | 169 |  |
| Total available-for-sale cash equivalents | $ | 169 |  |  | $ | — |  |  | $ | — |  |  | $ | 169 |  |
| Investments: |  |  |  |  |  |  |  |
| Commercial paper | $ | 15 |  |  | $ | — |  |  | $ | — |  |  | $ | 15 |  |
| Corporate debt securities | 4,588 |  |  | 47 |  |  | (1) |  |  | 4,634 |  |
| U.S. government and agency securities | 170 |  |  | — |  |  | — |  |  | 170 |  |
| Non-U.S. government and agency securities | 29 |  |  | — |  |  | — |  |  | 29 |  |
| Asset-backed securities | 1,328 |  |  | 9 |  |  | — |  |  | 1,337 |  |
| Total available-for-sale investments | $ | 6,130 |  |  | $ | 56 |  |  | $ | (1) |  |  | $ | 6,185 |  |
  (was, 2025-11-20, similarity 0.9605):
[0001327567-25-000035:note_history:13]
|  | July 31, 2025 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | $ | 169 |  |  | $ | — |  |  | $ | — |  |  | $ | 169 |  |
| Total available-for-sale cash equivalents | $ | 169 |  |  | $ | — |  |  | $ | — |  |  | $ | 169 |  |
| Investments: |  |  |  |  |  |  |  |
| Commercial paper | 15 |  |  | — |  |  | — |  |  | 15 |  |
| Corporate debt securities | 4,588 |  |  | 47 |  |  | (1) |  |  | 4,634 |  |
| U.S. government and agency securities | 170 |  |  | — |  |  | — |  |  | 170 |  |
| Non-U.S. government and agency securities | 29 |  |  | — |  |  | — |  |  | 29 |  |
| Asset-backed securities | 1,328 |  |  | 9 |  |  | — |  |  | 1,337 |  |
| Total available-for-sale investments | $ | 6,130 |  |  | $ | 56 |  |  | $ | (1) |  |  | $ | 6,185 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2026-02-18):
[0001327567-26-000005:note_history:14]
The following tables summarize the amortized cost, unrealized gains and losses, and fair value of our available-for-sale debt securities as of January 31, 2026 and July 31, 2025 (in millions):
  (was, 2025-11-20, similarity 0.967):
[0001327567-25-000035:note_history:14]
The following tables summarize the amortized cost, unrealized gains and losses, and fair value of our available-for-sale debt securities as of October 31, 2025 and July 31, 2025 (in millions):

- changed (2026-02-18):
[0001327567-26-000005:note_history:15]
|  | January 31, 2026 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 14 |  |  | $ | — |  |  | $ | — |  |  | $ | 14 |  |
| Commercial paper | 912 |  |  | — |  |  | — |  |  | 912 |  |
| Corporate debt securities | 17 |  |  | — |  |  | — |  |  | 17 |  |
| U.S. government and agency securities | 885 |  |  | — |  |  | — |  |  | 885 |  |
| Total available-for-sale cash equivalents | $ | 1,828 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,828 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 3 |  |  | $ | — |  |  | $ | — |  |  | $ | 3 |  |
| Commercial paper | 57 |  |  | — |  |  | — |  |  | 57 |  |
| Corporate debt securities | 2,820 |  |  | 43 |  |  | — |  |  | 2,863 |  |
| U.S. government and agency securities | 30 |  |  | — |  |  | — |  |  | 30 |  |
| Asset-backed securities | 762 |  |  | 9 |  |  | — |  |  | 771 |  |
| Total available-for-sale investments | $ | 3,672 |  |  | $ | 52 |  |  | $ | — |  |  | $ | 3,724 |  |
  (was, 2025-11-20, similarity 0.8422):
[0001327567-25-000035:note_history:15]
|  | October 31, 2025 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | $ | 755 |  |  | $ | — |  |  | $ | — |  |  | $ | 755 |  |
| Corporate debt securities | 157 |  |  | — |  |  | — |  |  | 157 |  |
| U.S. government and agency securities | 178 |  |  | — |  |  | — |  |  | 178 |  |
| Total available-for-sale cash equivalents | $ | 1,090 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,090 |  |
| Investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 25 |  |  | $ | — |  |  | $ | — |  |  | $ | 25 |  |
| Commercial paper | 340 |  |  | — |  |  | — |  |  | 340 |  |
| Corporate debt securities | 5,120 |  |  | 73 |  |  | (1) |  |  | 5,192 |  |
| U.S. government and agency securities | 99 |  |  | — |  |  | — |  |  | 99 |  |
| Non-U.S. government and agency securities | 29 |  |  | — |  |  | — |  |  | 29 |  |
| Asset-backed securities | 1,421 |  |  | 15 |  |  | — |  |  | 1,436 |  |
| Total available-for-sale investments | $ | 7,034 |  |  | $ | 88 |  |  | $ | (1) |  |  | $ | 7,121 |  |

- changed (2026-02-18):
[0001327567-26-000005:note_history:16]
|  | July 31, 2025 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | $ | 169 |  |  | $ | — |  |  | $ | — |  |  | $ | 169 |  |
| Total available-for-sale cash equivalents | $ | 169 |  |  | $ | — |  |  | $ | — |  |  | $ | 169 |  |
| Investments: |  |  |  |  |  |  |  |
| Commercial paper | $ | 15 |  |  | $ | — |  |  | $ | — |  |  | $ | 15 |  |
| Corporate debt securities | 4,588 |  |  | 47 |  |  | (1) |  |  | 4,634 |  |
| U.S. government and agency securities | 170 |  |  | — |  |  | — |  |  | 170 |  |
| Non-U.S. government and agency securities | 29 |  |  | — |  |  | — |  |  | 29 |  |
| Asset-backed securities | 1,328 |  |  | 9 |  |  | — |  |  | 1,337 |  |
| Total available-for-sale investments | $ | 6,130 |  |  | $ | 56 |  |  | $ | (1) |  |  | $ | 6,185 |  |
  (was, 2025-11-20, similarity 0.9605):
[0001327567-25-000035:note_history:16]
|  | July 31, 2025 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | $ | 169 |  |  | $ | — |  |  | $ | — |  |  | $ | 169 |  |
| Total available-for-sale cash equivalents | $ | 169 |  |  | $ | — |  |  | $ | — |  |  | $ | 169 |  |
| Investments: |  |  |  |  |  |  |  |
| Commercial paper | 15 |  |  | — |  |  | — |  |  | 15 |  |
| Corporate debt securities | 4,588 |  |  | 47 |  |  | (1) |  |  | 4,634 |  |
| U.S. government and agency securities | 170 |  |  | — |  |  | — |  |  | 170 |  |
| Non-U.S. government and agency securities | 29 |  |  | — |  |  | — |  |  | 29 |  |
| Asset-backed securities | 1,328 |  |  | 9 |  |  | — |  |  | 1,337 |  |
| Total available-for-sale investments | $ | 6,130 |  |  | $ | 56 |  |  | $ | (1) |  |  | $ | 6,185 |  |

- changed (2026-02-18):
[0001327567-26-000005:note_history:17]
Unrealized losses related to our available-for-sale debt securities are primarily due to interest rate fluctuations as opposed to credit quality. We do not intend to sell any of the securities in an unrealized loss position and it is not likely that we would be required to sell these securities before recovery of their amortized cost basis, which may be at maturity. We did not recognize any credit losses related to our available-for-sale debt securities during the three and six months ended January 31, 2026 and 2025.
  (was, 2025-11-20, similarity 0.9784):
[0001327567-25-000035:note_history:17]
Unrealized losses related to our available-for-sale debt securities are primarily due to interest rate fluctuations as opposed to credit quality. We do not intend to sell any of the securities in an unrealized loss position and it is not likely that we would be required to sell these securities before recovery of their amortized cost basis, which may be at maturity. We did not recognize any credit losses related to our available-for-sale debt securities during the three months ended October 31, 2025 and 2024.

- changed (2026-02-18):
[0001327567-26-000005:note_history:18]
The following table summarizes the amortized cost and fair value of our available-for-sale debt securities as of January 31, 2026, by contractual years-to-maturity (in millions):
  (was, 2025-11-20, similarity 0.9651):
[0001327567-25-000035:note_history:18]
The following table summarizes the amortized cost and fair value of our available-for-sale debt securities as of October 31, 2025, by contractual years-to-maturity (in millions):

- changed (2026-02-18):
[0001327567-26-000005:note_history:19]
Marketable equity securities consist of money market funds and are included in cash and cash equivalents on our condensed consolidated balance sheets. As of January 31, 2026 and July 31, 2025, the carrying values of our marketable equity securities were $1.4 billion and $1.2 billion, respectively. There were no unrealized gains or losses recognized for these securities during the three and six months ended January 31, 2026 and 2025.
  (was, 2025-11-20, similarity 0.9093):
[0001327567-25-000035:note_history:19]
Marketable equity securities consist of money market funds and are included in cash and cash equivalents on our condensed consolidated balance sheets. As of October 31, 2025 and July 31, 2025, the carrying values of our marketable equity securities were $1.1 billion and $1.2 billion, respectively. There were no unrealized gains or losses recognized for these securities during the three months ended October 31, 2025 and 2024.


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2026-02-18):
[0001327567-26-000005:note_history:20]
|  | Three Months Ended January 31, |  | Six Months Ended January 31, |
|  | 2026 |  | 2025 |  | 2026 |  | 2025 |
| Revenue: |  |  |  |  |  |  |  |
| Americas |  |  |  |  |  |  |  |
| United States | $ | 1,588 |  |  | $ | 1,400 |  |  | $ | 3,114 |  |  | $ | 2,744 |  |
| Other Americas | 124 |  |  | 102 |  |  | 239 |  |  | 200 |  |
| Total Americas | 1,712 |  |  | 1,502 |  |  | 3,353 |  |  | 2,944 |  |
| Europe, the Middle East, and Africa (“EMEA”) | 560 |  |  | 480 |  |  | 1,081 |  |  | 922 |  |
| Asia Pacific and Japan (“APAC”) | 322 |  |  | 275 |  |  | 634 |  |  | 530 |  |
| Total revenue | $ | 2,594 |  |  | $ | 2,257 |  |  | $ | 5,068 |  |  | $ | 4,396 |  |

- added (2026-02-18):
[0001327567-26-000005:note_history:21]
|  | Three Months Ended January 31, |  | Six Months Ended January 31, |
|  | 2026 |  | 2025 |  | 2026 |  | 2025 |
| Revenue: |  |  |  |  |  |  |  |
| Product | $ | 514 |  |  | $ | 421 |  |  | $ | 948 |  |  | $ | 775 |  |
| Subscription and support |  |  |  |  |  |  |  |
| Subscription | 1,404 |  |  | 1,233 |  |  | 2,768 |  |  | 2,425 |  |
| Support | 676 |  |  | 603 |  |  | 1,352 |  |  | 1,196 |  |
| Total subscription and support | 2,080 |  |  | 1,836 |  |  | 4,120 |  |  | 3,621 |  |
| Total revenue | $ | 2,594 |  |  | $ | 2,257 |  |  | $ | 5,068 |  |  | $ | 4,396 |  |

- changed (2026-02-18):
[0001327567-26-000005:note_history:22]
During the six months ended January 31, 2026 and 2025, we recognized approximately $3.5 billion and $3.1 billion of revenue pertaining to amounts that were deferred as of July 31, 2025 and 2024, respectively.
  (was, 2025-11-20, similarity 0.9465):
[0001327567-25-000035:note_history:22]
During the three months ended October 31, 2025 and 2024, we recognized approximately $1.9 billion and $1.6 billion of revenue pertaining to amounts that were deferred as of July 31, 2025 and 2024, respectively.

- changed (2026-02-18):
[0001327567-26-000005:note_history:23]
Remaining performance obligations were $16.0 billion as of January 31, 2026, of which we expect to recognize as revenue approximately $7.1 billion over the next 12 months and the remainder thereafter.
  (was, 2025-11-20, similarity 0.9681):
[0001327567-25-000035:note_history:23]
Remaining performance obligations were $15.5 billion as of October 31, 2025, of which we expect to recognize as revenue approximately $6.9 billion over the next 12 months and the remainder thereafter.

- removed (2026-02-18):
[0001327567-25-000035:note_history:24]
|  |  |  | Three Months Ended October 31, |
|  |  |  |  |  | 2025 |  | 2024 |
| Revenue: |  |  |  |  |  |  |  |
| Americas |  |  |  |  |  |  |  |
| United States |  |  |  |  | $ | 1,526 |  |  | $ | 1,344 |  |
| Other Americas |  |  |  |  | 115 |  |  | 98 |  |
| Total Americas |  |  |  |  | 1,641 |  |  | 1,442 |  |
| Europe, the Middle East, and Africa (“EMEA”) |  |  |  |  | 521 |  |  | 442 |  |
| Asia Pacific and Japan (“APAC”) |  |  |  |  | 312 |  |  | 255 |  |
| Total revenue |  |  |  |  | $ | 2,474 |  |  | $ | 2,139 |  |

- removed (2026-02-18):
[0001327567-25-000035:note_history:25]
|  |  |  | Three Months Ended October 31, |
|  |  |  |  |  | 2025 |  | 2024 |
| Revenue: |  |  |  |  |  |  |  |
| Product |  |  |  |  | $ | 434 |  |  | $ | 354 |  |
| Subscription and support |  |  |  |  |  |  |  |
| Subscription |  |  |  |  | 1,364 |  |  | 1,192 |  |
| Support |  |  |  |  | 676 |  |  | 593 |  |
| Total subscription and support |  |  |  |  | 2,040 |  |  | 1,785 |  |
| Total revenue |  |  |  |  | $ | 2,474 |  |  | $ | 2,139 |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- changed (2026-02-18):
[0001327567-26-000005:note_history:26]
Subsequent Events
CyberArk Software Ltd.
  (was, 2025-11-20, similarity 0.6216):
[0001327567-25-000035:note_history:26]
Subsequent Events
Share Repurchase

- added (2026-02-18):
[0001327567-26-000005:note_history:27]
On February 11, 2026, we completed the acquisition of CyberArk for $2.3 billion in cash and 112 million shares of our common stock. The cash portion of the consideration was funded with our cash on hand. We also assumed certain unvested outstanding equity awards held by CyberArk employees under certain of CyberArk’s share incentive plans.

- added (2026-02-18):
[0001327567-26-000005:note_history:28]
Koi Security Ltd.

- added (2026-02-18):
[0001327567-26-000005:note_history:29]
On February 16, 2026, we entered into a definitive agreement to acquire Koi Security Ltd., a privately-held endpoint posture management company (“Koi Security”), in exchange for total consideration of $300 million in cash and replacement awards, subject to adjustments. We expect the acquisition to expand the capabilities of our security operations platform. The acquisition of Koi Security is expected to close during the second half of our fiscal 2026, subject to the satisfaction of closing conditions, including regulatory clearance.

- removed (2026-02-18):
[0001327567-25-000035:note_history:30]
On November 18, 2025, our board of directors authorized the extension of the expiration date of our current share repurchase authorization to December 31, 2026. Our repurchase program may be suspended or discontinued at any time without prior notice. Repurchases may be made at management’s discretion from time to time on the open market, through privately negotiated transactions, transactions structured through investment banking institutions, block purchase techniques, 10b5-1 trading plans, or a combination of the foregoing.

- removed (2026-02-18):
[0001327567-25-000035:note_history:31]
Chronosphere, Inc.

- removed (2026-02-18):
[0001327567-25-000035:note_history:32]
On November 19, 2025, we entered into a definitive agreement to acquire Chronosphere, Inc., a privately-held observability technology company (“Chronosphere”), in exchange for total consideration of $3.35 billion in cash and replacement awards, subject to adjustments. We expect the acquisition to be our entry into the observability space. The acquisition of Chronosphere is expected to close during the second half of our fiscal 2026, subject to the satisfaction of closing conditions, including regulatory clearance.
