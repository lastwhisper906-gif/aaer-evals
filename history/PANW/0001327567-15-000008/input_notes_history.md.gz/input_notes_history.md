# PANW note change history — 0001327567-14-000043 → 0001327567-15-000008


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2015-03-03):
[0001327567-15-000008:note_history:1]
The following table presents details of the aggregate future non-cancelable minimum rental payments under our operating leases as of January 31, 2015 (in thousands):
  (was, 2014-11-25, similarity 0.9464):
[0001327567-14-000043:note_history:1]
The following table presents details of the aggregate future non-cancelable minimum rental payments on our operating leases as of October 31, 2014 (in thousands):

- changed (2015-03-03):
[0001327567-15-000008:note_history:2]
Our independent contract manufacturer procures components and assembles our products based on our forecasts. These forecasts are based on estimates of demand for our products primarily for the next twelve months, which are in turn based on historical trends and an analysis from our sales and product marketing organizations, adjusted for overall market conditions. In order to reduce manufacturing lead times and plan for adequate supply, we may issue forecasts and orders for components and products that are non-cancelable. Obligations under contracts that we can cancel without a significant penalty are not included. As of January 31, 2015, we had $38,893,000 of open orders.
  (was, 2014-11-25, similarity 0.9895):
[0001327567-14-000043:note_history:2]
Our independent contract manufacturer procures components and assembles our products based on our forecasts. These forecasts are based on estimates of demand for our products primarily for the next twelve months, which are in turn based on historical trends and an analysis from our sales and product marketing organizations, adjusted for overall market conditions. In order to reduce manufacturing lead times and plan for adequate supply, we may issue forecasts and orders for components and products that are non-cancelable. Obligations under contracts that we can cancel without a significant penalty are not included. As of October 31, 2014, we had $39,018,000 of open orders.

- changed (2015-03-03):
[0001327567-15-000008:note_history:3]
In December 2011, Juniper Networks, Inc. (“Juniper”) filed a complaint against us in the United States District Court for the District of Delaware alleging patent infringement, which sought preliminary and permanent injunctions against infringement, treble damages, and attorneys' fees. On September 30, 2013, we filed a lawsuit against Juniper in the United States District Court for the Northern District of California alleging that Juniper’s products infringe three of our U.S. patents, and sought monetary damages and a permanent injunction. On May 27, 2014, we entered into a Settlement, Release and Cross-License Agreement (the “settlement agreement”) with Juniper to resolve all pending litigation between the parties, including those discussed above. Refer to Note 8. Legal Settlement for more information on the settlement agreement.
  (was, 2014-11-25, similarity 0.7868):
[0001327567-14-000043:note_history:3]
In December 2011, Juniper Networks, Inc. (“Juniper”) filed a complaint against us in the United States District Court for the District of Delaware alleging patent infringement, which sought preliminary and permanent injunctions against infringement, treble damages, and attorneys' fees. On September 30, 2013, we filed a lawsuit against Juniper in the United States District Court for the Northern District of California alleging that Juniper’s products infringe three of our U.S. patents, and sought monetary damages and a permanent injunction.

- changed (2015-03-03):
[0001327567-15-000008:note_history:4]
To the extent there is a reasonable possibility that a loss exceeding amounts already recognized may be incurred and the amount of such additional loss would be material, we will either disclose the estimated additional loss or state that such an estimate cannot be made. As of January 31, 2015, we have not recorded any accrual for loss contingencies associated with such legal proceedings, determined that an unfavorable outcome is probable or reasonably possible, or determined that the amount or range of any possible loss is reasonably estimable.
  (was, 2014-11-25, similarity 0.9872):
[0001327567-14-000043:note_history:4]
To the extent there is a reasonable possibility that a loss exceeding amounts already recognized may be incurred and the amount of such additional loss would be material, we will either disclose the estimated additional loss or state that such an estimate cannot be made. As of October 31, 2014, we have not recorded any accrual for loss contingencies associated with such legal proceedings, determined that an unfavorable outcome is probable or reasonably possible, or determined that the amount or range of any possible loss is reasonably estimable.

- removed (2015-03-03):
[0001327567-14-000043:note_history:5]
On May 27, 2014, we entered into a Settlement, Release and Cross-License Agreement (the “settlement agreement”) with Juniper to resolve all pending litigation between the parties, including those discussed above. Under the terms of the settlement agreement, we agreed to pay Juniper a one-time settlement amount of approximately $175,000,000, which was comprised of $75,000,000 in cash, 1,081,000 shares of our common stock with an approximate value of $70,000,000, and a warrant to purchase 463,000 shares of our common stock with an approximate value of $30,000,000, in exchange for the following:

- removed (2015-03-03):
[0001327567-14-000043:note_history:6]
| • | Mutual dismissal with prejudice of all pending litigation between the parties and general release of all liability for Palo Alto Networks and Juniper, |

- removed (2015-03-03):
[0001327567-14-000043:note_history:7]
| • | Cross-license between both parties for the patents-in-suit and associated family members and counterparts worldwide for the life of the patents, and |

- removed (2015-03-03):
[0001327567-14-000043:note_history:8]
| • | Mutual covenant not to sue for infringement of any other patents for a period of eight years. |

- removed (2015-03-03):
[0001327567-14-000043:note_history:9]
For accounting purposes, the fair value of the total consideration as of the settlement date was $182,473,000, which was comprised of $75,000,000 in cash, $75,231,000 in common stock, and $32,242,000 in warrant. The fair values of the common stock and warrant were measured using the closing price of our common stock on the settlement date.

- removed (2015-03-03):
[0001327567-14-000043:note_history:10]
The warrant was issued on June 3, 2014 and entitled Juniper to purchase up to 463,000 shares of common stock at an exercise price of $0.0001 per share and was classified as a liability during the period it was outstanding. On July 1, 2014, Juniper exercised the warrant in full. Accordingly, we recorded the change in the fair value of the warrant liability through the exercise date of $5,859,000 within other income (expense), net in the consolidated statement of operations for the year ended July 31, 2014.

- removed (2015-03-03):
[0001327567-14-000043:note_history:11]
We accounted for the settlement agreement as a multiple-element arrangement and allocated the fair value of the consideration as of the settlement date to the identifiable elements based on their estimated fair values. Of the total settlement amount, $61,300,000 was allocated to the licensing of intellectual property, $54,300,000 was allocated to the mutual dismissal of claims, and the remaining amount was allocated to the mutual covenant not to sue. The mutual dismissal of claims and the mutual covenant not to sue have no identifiable future benefit, and as a result we recorded a settlement charge within operating expenses in the consolidated statements of operations for the year ended July 31, 2014. The licensing of intellectual property is being amortized over the estimated period of benefit of five years.


## us-gaap:LegalMattersAndContingenciesTextBlock (contingencies) — matched_by: no_prior_note, score: 0.0

- added (2015-03-03):
[0001327567-15-000008:note_history:12]
Legal Settlement

- added (2015-03-03):
[0001327567-15-000008:note_history:13]
Mutual Covenant Not to Sue and Release Agreement

- added (2015-03-03):
[0001327567-15-000008:note_history:14]
On January 27, 2014, we executed a Mutual Covenant Not to Sue and Release Agreement with Fortinet, Inc., thereby extending an existing covenant for six more years. We evaluated the transaction as a multiple-element arrangement and allocated the one-time payment that we made in the amount of $20,000,000 to each identifiable element using its relative fair value. Based on our estimates of fair value, we determined that the primary benefit of the arrangement is avoided litigation cost and the release of any potential past claims, with no material value attributable to future use or benefit. Accordingly, we recorded a $20,000,000 settlement charge within legal settlement expense in our condensed consolidated statement of operations during the three months ended January 31, 2014.

- added (2015-03-03):
[0001327567-15-000008:note_history:15]
Settlement, Release and Cross-License Agreement with Juniper

- added (2015-03-03):
[0001327567-15-000008:note_history:16]
On May 27, 2014, we entered into the settlement agreement with Juniper, whereby we resolved all pending litigation matters. Under the terms of the settlement agreement, we agreed to pay Juniper a one-time settlement amount of approximately $175,000,000, which was comprised of $75,000,000 in cash, 1,081,000 shares of our common stock with an approximate value of $70,000,000, and a warrant to purchase 463,000 shares of our common stock with an approximate value of $30,000,000, in exchange for the following:

- added (2015-03-03):
[0001327567-15-000008:note_history:17]
| • | Mutual dismissal with prejudice of all pending litigation between the parties and general release of all liability for Palo Alto Networks and Juniper, |

- added (2015-03-03):
[0001327567-15-000008:note_history:18]
| • | Cross-license between both parties for the patents-in-suit and associated family members and counterparts worldwide for the life of the patents, and |

- added (2015-03-03):
[0001327567-15-000008:note_history:19]
| • | Mutual covenant not to sue for infringement of any other patents for a period of eight years. |

- added (2015-03-03):
[0001327567-15-000008:note_history:20]
For accounting purposes, the fair value of the total consideration as of the settlement date was $182,473,000, which was comprised of $75,000,000 in cash, $75,231,000 in common stock, and $32,242,000 in warrant. The fair values of the common stock and warrant were measured using the closing price of our common stock on the settlement date.

- added (2015-03-03):
[0001327567-15-000008:note_history:21]
The warrant was issued on June 3, 2014 and entitled Juniper to purchase up to 463,000 shares of common stock at an exercise price of $0.0001 per share and was classified as a liability during the period it was outstanding. On July 1, 2014, Juniper exercised the warrant in full. Accordingly, we recorded the change in the fair value of the warrant liability through the exercise date of $5,859,000 within other income (expense), net in our consolidated statement of operations during the three months ended July 31, 2014.

- added (2015-03-03):
[0001327567-15-000008:note_history:22]
We accounted for the settlement agreement as a multiple-element arrangement and allocated the fair value of the consideration as of the settlement date to the identifiable elements based on their estimated fair values. Of the total settlement amount, $61,300,000 was allocated to the licensing of intellectual property, $54,300,000 was allocated to the mutual dismissal of claims, and the remaining amount was allocated to the mutual covenant not to sue. The mutual dismissal of claims and the mutual covenant not to sue have no identifiable future benefit, and as a result we recorded a settlement charge within legal settlement expense in our condensed consolidated statement of operations during the three months ended April 30, 2014. The licensing of intellectual property is being amortized over the estimated period of benefit of five years.


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2015-03-03):
[0001327567-15-000008:note_history:23]
There have been no material changes to our significant accounting policies as of and for the six months ended January 31, 2015, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended July 31, 2014.
  (was, 2014-11-25, similarity 0.9004):
[0001327567-14-000043:note_history:23]
There have been no material changes to our significant accounting policies as of and for the three months ended October 31, 2014, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended July 31, 2014.

- added (2015-03-03):
[0001327567-15-000008:note_history:24]
In May 2014, the FASB issued ASU No. 2014-09 regarding Accounting Standards Codification (ASC) Topic 606-Revenue from Contracts with Customers. The standard provides principles for recognizing revenue for the transfer of promised goods or services to customers with the consideration to which the entity expects to be entitled in exchange for those goods or services. The standard also requires significantly expanded disclosures about revenue recognition. The guidance is effective for us in the first quarter of fiscal 2018 using either of two methods: (i) retrospective to each prior reporting period presented with the option to elect certain practical expedients as defined within the guidance; or (ii) retrospective with the cumulative effect of initially applying the guidance recognized at the date of initial application and providing certain additional disclosures as defined per the guidance. Early adoption is not permitted. We are currently evaluating adoption methods and whether this standard will have a material impact on our condensed consolidated financial statements.

- changed (2015-03-03):
[0001327567-15-000008:note_history:25]
In July 2013, the FASB issued ASU No. 2013-11, Income Taxes (Topic 740)-Presentation of an Unrecognized Tax Benefit When a Net Operating Loss Carryforward, a Similar Tax Loss, or a Tax Credit Carryforward Exists. The standard requires us to present an unrecognized tax benefit as a reduction of a deferred tax asset for a net operating loss (NOL) carryforward or other tax credit carryforward when settlement in this manner is available under applicable tax law. The guidance was effective for us in the first quarter of fiscal 2015. Our adoption of this guidance did not have an impact on our condensed consolidated financial statements.
  (was, 2014-11-25, similarity 0.9992):
[0001327567-14-000043:note_history:25]
In July 2013, the FASB issued ASU No. 2013-11, Income Taxes (Topic 740)-Presentation of an Unrecognized Tax Benefit When a Net Operating Loss Carryforward, a Similar Tax Loss, or a Tax Credit Carryforward Exists. The standard requires us to present an unrecognized tax benefit as a reduction of a deferred tax asset for a net operating loss (NOL) carryforward or other tax credit carryforward when settlement in this manner is available under applicable tax law. The guidance was effective for us in the first quarter of fiscal 2015. Our adoption of this guidance did not have any impact on our condensed consolidated financial statements.

- removed (2015-03-03):
[0001327567-14-000043:note_history:26]
Our enterprise security platform consists of three major elements: our Next-Generation Firewall, our Advanced Endpoint Protection, and our Threat Intelligence Cloud. Our Next-Generation Firewall delivers application, user, and content visibility and control as well as protection against network-based cyber threats integrated within the firewall through our proprietary hardware and software architecture. Our Advanced Endpoint Protection prevents cyber attacks that aim to exploit software vulnerabilities on a broad variety of fixed and virtual endpoints. Our Threat Intelligence Cloud provides central intelligence capabilities as well as automated delivery of preventative measures against cyber attacks. The cloud-based element of our platform is delivered in the form of a service that can be used either in the public cloud or in a private cloud using a dedicated appliance.

- removed (2015-03-03):
[0001327567-14-000043:note_history:27]
We primarily sell our products and services to end-customers through our channel partners and infrequently directly to end-customers. Our partners are supported by our sales and marketing organization in the Americas, in Europe, the Middle East, and Africa (EMEA), and in Asia Pacific and Japan (APAC).

- removed (2015-03-03):
[0001327567-14-000043:note_history:28]
In May 2014, the FASB issued ASU No. 2014-09 regarding Accounting Standards Codification (ASC) Topic 606-Revenue from Contracts with Customers. The standard provides principles for recognizing revenue for the transfer of promised goods or services to customers with the consideration to which the entity expects to be entitled in exchange for those goods or services. The guidance is effective for us in the first quarter of fiscal 2018 using either of two methods: (i) retrospective to each prior reporting period presented with the option to elect certain practical expedients as defined within the guidance; or (ii) retrospective with the cumulative effect of initially applying the guidance recognized at the date of initial application and providing certain additional disclosures as defined per the guidance. Early adoption is not permitted. We are currently evaluating adoption methods and whether this standard will have a material impact on our condensed consolidated financial statements.


## us-gaap:ConvertibleDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2015-03-03):
[0001327567-15-000008:note_history:29]
The following table sets forth the components of the Notes as of January 31, 2015 and July 31, 2014 (in thousands):
  (was, 2014-11-25, similarity 0.9429):
[0001327567-14-000043:note_history:29]
The following table sets forth the components of the Notes as of October 31, 2014 and July 31, 2014 (in thousands):

- changed (2015-03-03):
[0001327567-15-000008:note_history:30]
|  | January 31, 2015 |  | July 31, 2014 |
| Liability: |  |  |  |
| Principal | $ | 575,000 |  |  | $ | 575,000 |  |
| Less: debt discount, net of amortization | 98,128 |  |  | 108,125 |  |
| Net carrying amount | $ | 476,872 |  |  | $ | 466,875 |  |
| Equity | $ | (109,785 | ) |  | $ | (109,785 | ) |
  (was, 2014-11-25, similarity 0.9697):
[0001327567-14-000043:note_history:30]
|  | October 31, 2014 |  | July 31, 2014 |
| Liability: |  |  |  |
| Principal | $ | 575,000 |  |  | $ | 575,000 |  |
| Less: debt discount, net of amortization | 103,144 |  |  | 108,125 |  |
| Net carrying amount | $ | 471,856 |  |  | $ | 466,875 |  |
| Equity | $ | (109,785 | ) |  | $ | (109,785 | ) |


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2015-03-03):
[0001327567-15-000008:note_history:31]
On June 30, 2014, we issued $575,000,000 aggregate principal amount of 0.0% convertible senior notes due 2019 (the “Notes”). The Notes are governed by an indenture between us, as the issuer, and U.S. Bank National Association, as Trustee (the “Indenture”). The Notes are unsecured, unsubordinated obligations that do not contain any financial covenants or restrictions on the payments of dividends, the incurrence of indebtedness, or the issuance or repurchase of securities by us or any of our subsidiaries. The Notes mature on July 1, 2019 unless converted or repurchased in accordance with their terms prior to such date. We cannot redeem the Notes prior to maturity.
  (was, 2014-11-25, similarity 0.9858):
[0001327567-14-000043:note_history:31]
On June 30, 2014, we issued $575,000,000 aggregate principal amount of 0.0% convertible senior notes due 2019 (the “Notes”). The Notes are governed by an indenture between us, as the issuer, and U.S. Bank National Association, as Trustee. The Notes are unsecured, unsubordinated obligations that do not contain any financial covenants or restrictions on the payments of dividends, the incurrence of indebtedness, or the issuance or repurchase of securities by us or any of our subsidiaries. The Notes mature on July 1, 2019 unless converted or repurchased in accordance with their terms prior to such date. We cannot redeem the Notes prior to maturity.

- changed (2015-03-03):
[0001327567-15-000008:note_history:32]
The conversion price will be subject to adjustment in some events. Holders of the Notes who convert their Notes in connection with certain corporate events that constitute a “make-whole fundamental change” per the Indenture are, under certain circumstances, entitled to an increase in the conversion rate. Additionally, upon the occurrence of a corporate event that constitutes a “fundamental change” per the Indenture, holders of the Notes may require us to repurchase for cash all or a portion of the Notes at a purchase price equal to 100% of the principal amount of the Notes plus accrued and unpaid contingent interest.
  (was, 2014-11-25, similarity 0.9688):
[0001327567-14-000043:note_history:32]
The conversion price will be subject to adjustment in some events. Holders of the Notes who convert their Notes in connection with certain corporate events that constitute a “make-whole fundamental change” per the Indenture governing the Notes are, under certain circumstances, entitled to an increase in the conversion rate. Additionally, upon the occurrence of a corporate event that constitutes a “fundamental change” per the Indenture governing the Notes, holders of the Notes may require us to repurchase for cash all or a portion of the Notes at a purchase price equal to 100% of the principal amount of the Notes plus accrued and unpaid contingent interest.

- changed (2015-03-03):
[0001327567-15-000008:note_history:33]
In accounting for the issuance of the Notes, we separated the Notes into liability and equity components. The carrying amount of the liability component was calculated by measuring the fair value of a similar liability that does not have an associated convertible feature. The carrying amount of the equity component representing the conversion option was determined by deducting the fair value of the liability component from the par value of the Notes as a whole. The difference between the principal amount of the Notes and the liability component (the “debt discount”), is amortized to interest expense using the effective interest method over the term of the Notes. The equity component of the Notes is included in additional paid-in capital in our condensed consolidated balance sheets and is not remeasured as long as it continues to meet the conditions for equity classification.
  (was, 2014-11-25, similarity 0.9966):
[0001327567-14-000043:note_history:33]
In accounting for the issuance of the Notes, we separated the Notes into liability and equity components. The carrying amount of the liability component was calculated by measuring the fair value of a similar liability that does not have an associated convertible feature. The carrying amount of the equity component representing the conversion option was determined by deducting the fair value of the liability component from the par value of the Notes as a whole. The difference between the principal amount of the Notes and the liability component (the “debt discount”), is amortized to interest expense using the effective interest method over the term of the Notes. The equity component of the Notes is included in additional paid-in capital in the condensed consolidated balance sheets and is not remeasured as long as it continues to meet the conditions for equity classification.

- changed (2015-03-03):
[0001327567-15-000008:note_history:34]
In accounting for the transaction costs related to the issuance of the Notes, we allocated the total amount incurred to the liability and equity components using the same proportions as the proceeds from the Notes. Transaction costs attributable to the liability component were recorded in other assets in our condensed consolidated balance sheets and are being amortized to interest expense in our condensed consolidated statements of operations using the effective interest method over the term of the Notes. Transaction costs attributable to the equity component were netted with the equity component of the Notes in additional paid-in capital in our condensed consolidated balance sheets. We recorded liability issuance costs, or debt issuance costs, of $12,497,000 and equity issuance costs of $2,949,000.
  (was, 2014-11-25, similarity 0.9886):
[0001327567-14-000043:note_history:34]
In accounting for the transaction costs related to the issuance of the Notes, we allocated the total amount incurred to the liability and equity components using the same proportions as the proceeds from the Notes. Transaction costs attributable to the liability component were recorded in other assets in the condensed consolidated balance sheets and are being amortized to interest expense in the condensed consolidated statements of operations using the effective interest method over the term of the Notes. Transaction costs attributable to the equity component were netted with the equity component of the Notes in additional paid-in capital in the condensed consolidated balance sheets. We recorded liability issuance costs, or debt issuance costs, of $12,497,000 and equity issuance costs of $2,949,000.

- changed (2015-03-03):
[0001327567-15-000008:note_history:35]
The following table sets forth the components of the Notes as of January 31, 2015 and July 31, 2014 (in thousands):
  (was, 2014-11-25, similarity 0.9429):
[0001327567-14-000043:note_history:35]
The following table sets forth the components of the Notes as of October 31, 2014 and July 31, 2014 (in thousands):

- changed (2015-03-03):
[0001327567-15-000008:note_history:36]
|  | January 31, 2015 |  | July 31, 2014 |
| Liability: |  |  |  |
| Principal | $ | 575,000 |  |  | $ | 575,000 |  |
| Less: debt discount, net of amortization | 98,128 |  |  | 108,125 |  |
| Net carrying amount | $ | 476,872 |  |  | $ | 466,875 |  |
| Equity | $ | (109,785 | ) |  | $ | (109,785 | ) |
  (was, 2014-11-25, similarity 0.9697):
[0001327567-14-000043:note_history:36]
|  | October 31, 2014 |  | July 31, 2014 |
| Liability: |  |  |  |
| Principal | $ | 575,000 |  |  | $ | 575,000 |  |
| Less: debt discount, net of amortization | 103,144 |  |  | 108,125 |  |
| Net carrying amount | $ | 471,856 |  |  | $ | 466,875 |  |
| Equity | $ | (109,785 | ) |  | $ | (109,785 | ) |

- added (2015-03-03):
[0001327567-15-000008:note_history:37]
The total estimated fair value of the Notes was $751,813,000 and $587,087,000 at January 31, 2015 and July 31, 2014, respectively. The fair value was determined based on the closing trading price per $100 of the Notes as of the last day of trading for the period. We consider the fair value of the Notes at January 31, 2015 and July 31, 2014 to be a Level 2 measurement. The fair value of the Notes is primarily affected by the trading price of our common stock and market interest rates. As of January 31, 2015, the if-converted value of the Notes exceeded its principal amount by $74,929,000.

- changed (2015-03-03):
[0001327567-15-000008:note_history:38]
The following table sets forth interest expense recognized related to the Notes for the three and six months ended January 31, 2015 (dollars in thousands):
  (was, 2014-11-25, similarity 0.9315):
[0001327567-14-000043:note_history:38]
The following table sets forth interest expense recognized related to the Notes for the three months ended October 31, 2014 (dollars in thousands):

- changed (2015-03-03):
[0001327567-15-000008:note_history:39]
|  | Three Months Ended |  | Six Months Ended |
|  | January 31, 2015 |
| Amortization of debt issuance costs | $ | 505 |  |  | $ | 1,002 |  |
| Amortization of debt discount | 5,016 |  |  | 9,997 |  |
| Total interest expense recognized | $ | 5,521 |  |  | $ | 10,999 |  |
| Effective interest rate of the liability component | 4.8 | % |  | 4.8 | % |
  (was, 2014-11-25, similarity 0.8015):
[0001327567-14-000043:note_history:39]
|  | Amount |
| Amortization of debt issuance costs | $ | 497 |  |
| Amortization of debt discount | 4,981 |  |
| Total interest expense recognized | $ | 5,478 |  |
| Effective interest rate of the liability component | 4.8 | % |

- changed (2015-03-03):
[0001327567-15-000008:note_history:40]
We paid an aggregate amount of $110,975,000 for the Note Hedges, which is included in additional paid-in capital in our condensed consolidated balance sheets.
  (was, 2014-11-25, similarity 0.9797):
[0001327567-14-000043:note_history:40]
We paid an aggregate amount of $110,975,000 for the Note Hedges, which is included in additional paid-in capital in the condensed consolidated balance sheets.

- changed (2015-03-03):
[0001327567-15-000008:note_history:41]
We received aggregate proceeds of $78,258,000 from the sale of the Warrants, which is included in additional paid-in capital in our condensed consolidated balance sheets.
  (was, 2014-11-25, similarity 0.9814):
[0001327567-14-000043:note_history:41]
We received aggregate proceeds of $78,258,000 from the sale of the Warrants, which is included in additional paid-in capital in the condensed consolidated balance sheets.

- removed (2015-03-03):
[0001327567-14-000043:note_history:42]
The total estimated fair value of the Notes was $677,856,000 and $587,087,000 at October 31, 2014 and July 31, 2014, respectively. The fair value was determined based on the closing trading price per $100 of the Notes as of the last day of trading for the period. We consider the fair value of the Notes at October 31, 2014 and July 31, 2014 to be a Level 2 measurement. The fair value of the Notes is primarily affected by the trading price of our common stock and market interest rates. Based on the closing price of our common stock of $105.70 on October 31, 2014, the if-converted value of the Notes was less than its principal amount.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2015-03-03):
[0001327567-15-000008:note_history:43]
The following tables summarize the unrealized gains and losses and fair value of our investments as of January 31, 2015 and July 31, 2014 (in thousands):
  (was, 2014-11-25, similarity 0.958):
[0001327567-14-000043:note_history:43]
The following tables summarize the unrealized gains and losses and fair value of our investments as of October 31, 2014 and July 31, 2014 (in thousands):

- added (2015-03-03):
[0001327567-15-000008:note_history:44]
|  | January 31, 2015 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Estimated Fair Value |
| Certificates of deposit | $ | 1,000 |  |  | $ | 1 |  |  | $ | — |  |  | $ | 1,001 |  |
| Corporate debt securities | 158,933 |  |  | 60 |  |  | (62 | ) |  | 158,931 |  |
| U.S. government and agency securities | 635,702 |  |  | 423 |  |  | (75 | ) |  | 636,050 |  |
| Total | $ | 795,635 |  |  | $ | 484 |  |  | $ | (137 | ) |  | $ | 795,982 |  |

- changed (2015-03-03):
[0001327567-15-000008:note_history:45]
The following tables present our investments that were in an unrealized loss position as of January 31, 2015 and July 31, 2014 (in thousands):
  (was, 2014-11-25, similarity 0.9545):
[0001327567-14-000043:note_history:45]
The following tables present our investments that were in an unrealized loss position as of October 31, 2014 and July 31, 2014 (in thousands):

- changed (2015-03-03):
[0001327567-15-000008:note_history:46]
|  | January 31, 2015 |
|  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
|  | Fair Value |  | Unrealized Loss |  | Fair Value |  | Unrealized Loss |  | Fair Value |  | Unrealized Loss |
| Corporate debt securities | $ | 84,073 |  |  | $ | (62 | ) |  | $ | — |  |  | $ | — |  |  | $ | 84,073 |  |  | $ | (62 | ) |
| U.S. government and agency securities | 206,056 |  |  | (75 | ) |  | — |  |  | — |  |  | 206,056 |  |  | (75 | ) |
| Total | $ | 290,129 |  |  | $ | (137 | ) |  | $ | — |  |  | $ | — |  |  | $ | 290,129 |  |  | $ | (137 | ) |
  (was, 2014-11-25, similarity 0.9851):
[0001327567-14-000043:note_history:46]
|  | October 31, 2014 |
|  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
|  | Fair Value |  | Unrealized Loss |  | Fair Value |  | Unrealized Loss |  | Fair Value |  | Unrealized Loss |
| Corporate debt securities | $ | 72,352 |  |  | $ | (85 | ) |  | $ | — |  |  | $ | — |  |  | $ | 72,352 |  |  | $ | (85 | ) |
| U.S. government and agency securities | 185,151 |  |  | (119 | ) |  | — |  |  | — |  |  | 185,151 |  |  | (119 | ) |
| Total | $ | 257,503 |  |  | $ | (204 | ) |  | $ | — |  |  | $ | — |  |  | $ | 257,503 |  |  | $ | (204 | ) |

- changed (2015-03-03):
[0001327567-15-000008:note_history:47]
Unrealized losses related to these investments are due to interest rate fluctuations as opposed to credit quality. In addition, we do not intend to sell and it is not likely that we would be required to sell these investments before recovery of their amortized cost basis, which may be at maturity. As a result, there is no other-than-temporary impairment for these investments at January 31, 2015.
  (was, 2014-11-25, similarity 0.9649):
[0001327567-14-000043:note_history:47]
Unrealized losses related to these investments are due to interest rate fluctuations as opposed to credit quality. In addition, we do not intend to sell and it is not more likely than not that we would be required to sell these investments before recovery of their amortized cost basis, which may be at maturity. As a result, there is no other-than-temporary impairment for these investments at October 31, 2014.

- changed (2015-03-03):
[0001327567-15-000008:note_history:48]
The following table summarizes the amortized cost and fair value of our investments as of January 31, 2015, by contractual years-to-maturity (in thousands):
  (was, 2014-11-25, similarity 0.96):
[0001327567-14-000043:note_history:48]
The following table summarizes the amortized cost and fair value of our investments as of October 31, 2014, by contractual years-to-maturity (in thousands):

- removed (2015-03-03):
[0001327567-14-000043:note_history:49]
|  | October 31, 2014 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Estimated Fair Value |
| Certificates of deposit | $ | 1,000 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,000 |  |
| Corporate debt securities | 102,797 |  |  | 18 |  |  | (85 | ) |  | 102,730 |  |
| U.S. government and agency securities | 412,980 |  |  | 172 |  |  | (119 | ) |  | 413,033 |  |
| Total | $ | 516,777 |  |  | $ | 190 |  |  | $ | (204 | ) |  | $ | 516,763 |  |
