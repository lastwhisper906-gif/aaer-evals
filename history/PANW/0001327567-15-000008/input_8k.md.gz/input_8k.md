# PANW 8-K — 0001327567-15-000006 filed 2015-03-02

## item codes, every 8-K on or before 2015-03-03

- 2015-03-02 0001327567-15-000006 — 2.02, 9.01
- 2014-12-15 0001327567-14-000046 — 5.07
- 2014-11-24 0001327567-14-000040 — 2.02, 9.01
- 2014-09-22 0001193125-14-348581 — 5.02, 9.01
- 2014-09-09 0001327567-14-000025 — 2.02, 9.01
- 2014-07-01 0001193125-14-257824 — 1.01, 2.03, 3.02, 9.01
- 2014-06-26 0001193125-14-249529 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2014-06-20 0001327567-14-000020 — 9.01 — amendment of 0001193125-14-140511
- 2014-06-04 0001327567-14-000016 — 3.02
- 2014-05-30 0001193125-14-218158 — 2.02 — amendment, the index does not say of what
- 2014-05-28 0001193125-14-215060 — 1.01, 2.02, 3.02, 9.01
- 2014-04-11 0001193125-14-140511 — 2.01, 3.02, 7.01, 9.01
- 2014-03-24 0001193125-14-111318 — 1.01, 3.02, 7.01, 9.01
- 2014-03-13 0001327567-14-000009 — 5.02
- 2014-02-24 0001193125-14-063754 — 2.02, 9.01
- 2013-12-12 0001327567-13-000040 — 5.07
- 2013-11-25 0001327567-13-000033 — 2.02, 9.01
- 2013-09-30 0001193125-13-384966 — 8.01
- 2013-09-09 0001193125-13-361421 — 2.02, 9.01
- 2013-05-30 0001193125-13-241542 — 2.02, 5.02, 9.01
- 2013-03-11 0001193125-13-101082 — 5.02, 9.01
- 2013-02-28 0001193125-13-084193 — 2.02, 9.01
- 2012-12-14 0001193125-12-503335 — 5.07
- 2012-12-06 0001193125-12-493700 — 2.02, 9.01
- 2012-09-24 0001193125-12-401534 — 1.01, 2.03
- 2012-09-20 0001193125-12-398433 — 5.02, 9.01
- 2012-09-10 0001193125-12-386605 — 2.02, 9.01

## late-filing notifications on or before 2015-03-03

- none on or before 2015-03-03

## item 2.02 — earnings release, exhibit 99.1

[0001327567-15-000006:8k_2_02:1]
EX-99.1
2
ex991q215earningsrelease.htm
EXHIBIT 99.1

[0001327567-15-000006:8k_2_02:2]
Ex 99.1 (Q2'15 Earnings Release)

[0001327567-15-000006:8k_2_02:3]
Exhibit 99.1

[0001327567-15-000006:8k_2_02:4]
Palo Alto Networks Reports Fiscal Second Quarter 2015 Financial Results

[0001327567-15-000006:8k_2_02:5]
| • | Fiscal second quarter total revenue grows 54 percent year-over-year to $217.7 million |

[0001327567-15-000006:8k_2_02:6]
| • | Billings grow 51 percent year-over-year to $282.8 million |

[0001327567-15-000006:8k_2_02:7]
| • | Deferred revenue grows 65 percent year-over-year to $535.8 million |

[0001327567-15-000006:8k_2_02:8]
SANTA CLARA, Calif., March 2, 2015 - Palo Alto Networks, Inc. (NYSE: PANW) today announced financial results for its fiscal second quarter 2015 ended January 31, 2015.

[0001327567-15-000006:8k_2_02:9]
Total revenue for the fiscal second quarter grew 54 percent year-over-year to a record $217.7 million, compared with $141.1 million in the fiscal second quarter 2014. GAAP net loss for the fiscal second quarter was $43.0 million, or $0.53 per diluted share, compared with a net loss of $39.9 million, or $0.55 per diluted share, in the fiscal second quarter 2014.

[0001327567-15-000006:8k_2_02:10]
Palo Alto Networks recorded fiscal second quarter non-GAAP net income of $16.9 million, or $0.19 per diluted share, compared with non-GAAP net income of $7.8 million, or $0.10 per diluted share, in the fiscal second quarter 2014. A reconciliation between GAAP and non-GAAP information is contained in the tables below.

[0001327567-15-000006:8k_2_02:11]
“We delivered very strong second quarter results across all metrics, driven by continued high customer demand for our next-generation enterprise security platform that not only detects malicious activity, but also provides integrated and automated prevention capabilities. Given the increasing rate and severity of today’s highly sophisticated cyber attacks, enterprises worldwide are turning to us to help them solve their most complex security challenges,” said Mark McLaughlin, president and chief executive officer of Palo Alto Networks. “Our highly differentiated approach to enterprise security has resulted in growth that outpaces the security market as we continue to capture significant market share.”

[0001327567-15-000006:8k_2_02:12]
“New customer additions and expansion in existing customers resulted in record billings, revenue and deferred revenue in the second quarter,” said Steffan Tomlinson, chief financial officer of Palo Alto Networks. “With approximately 47 percent of total revenue coming from recurring services, our hybrid SaaS-revenue model and ramping economies of scale continue to drive leverage in the business, resulting

[0001327567-15-000006:8k_2_02:13]
in sequential and year-over-year expansion in non-GAAP gross margin, non-GAAP operating margin and cash flow from operations.”

[0001327567-15-000006:8k_2_02:14]
Recent Highlights

[0001327567-15-000006:8k_2_02:15]
| • | Introduced new hardware - We introduced the PA-3060, a new addition to the PA-3000 series, designed for mid-range data center environments. |

[0001327567-15-000006:8k_2_02:16]
| • | Continued threat research efforts - On the heels of finding the IOS-targeted WireLurker threat, our Unit 42 threat intelligence team revealed a “backdoor” contained in millions of Android mobile devices. |

[0001327567-15-000006:8k_2_02:17]
| • | Launched global user group - We launched Fuel, a global community established to drive knowledge and sharing of best practices among security professionals across industries. |

[0001327567-15-000006:8k_2_02:18]
| • | Participated in White House Cybersecurity Summit discussions - We engaged in dialogue on public/private sector threat information sharing practices, such as those already in process by the Cyber Threat Alliance that we co-founded with several other security industry leaders, to improve protection for consumers and companies against cyber threats. |

[0001327567-15-000006:8k_2_02:19]
Financial Outlook

[0001327567-15-000006:8k_2_02:20]
Palo Alto Networks provides guidance based on current market conditions and expectations.

[0001327567-15-000006:8k_2_02:21]
For the fiscal third quarter 2015, Palo Alto Networks expects:

[0001327567-15-000006:8k_2_02:22]
| • | Total revenue in the range of $219 to $223 million, representing year-over-year growth between 45 percent and 48 percent. |

[0001327567-15-000006:8k_2_02:23]
| • | Diluted non-GAAP earnings per share in the range of $0.19 to $0.20 using 87 to 89 million shares. |

[0001327567-15-000006:8k_2_02:24]
Guidance for non-GAAP financial measures excludes share-based compensation and related payroll taxes, amortization of acquired intangible assets, acquisition related expenses, discrete tax benefits, non-cash interest expense related to the company’s convertible senior notes, and certain non-recurring expenses. The company has not reconciled diluted non-GAAP earnings per share guidance to GAAP net income (loss) per diluted share because the company does not provide guidance on GAAP net income (loss) or the various reconciling cash and non-cash items between GAAP net income (loss) and non-GAAP net income (loss). Items that impact these measures are out of the company’s control and/or cannot be reasonably

[0001327567-15-000006:8k_2_02:25]
2

[0001327567-15-000006:8k_2_02:26]
predicted. Accordingly, a reconciliation of the non-GAAP financial measure guidance to the corresponding GAAP measures is not available without unreasonable effort.

[0001327567-15-000006:8k_2_02:27]
Conference Call Information

[0001327567-15-000006:8k_2_02:28]
Palo Alto Networks will host a conference call for analysts and investors to discuss its fiscal second quarter 2015 results and outlook for its fiscal third quarter 2015 today at 4:30 PM Eastern time/1:30 PM Pacific time. Open to the public, investors may access the call by dialing 1-877-627-6590 or 1-719-325-4772 and entering the passcode 2722533. A live audio webcast of the conference call along with supplemental financial information will also be accessible from the “Investors” section of the company’s website at investors.paloaltonetworks.com. Following the webcast, an archived version will be available on the website for one year. A telephonic replay of the call will be available two hours after the call and will run for five business days and may be accessed by dialing 1-888-203-1112 or 719-457-0820 and entering the passcode 2722533.

[0001327567-15-000006:8k_2_02:29]
Forward-Looking Statements

[0001327567-15-000006:8k_2_02:30]
This press release contains forward-looking statements that involve risks and uncertainties, including statements regarding the company’s financial outlook for the fiscal third quarter of 2015 and the company’s ability to continue to grow faster than the overall security market and capture significant market share. There are a significant number of factors that could cause actual results to differ materially from statements made in this press release, including: Palo Alto Networks’ limited operating history; risks associated with Palo Alto Networks’ rapid growth, particularly outside of the United States; Palo Alto Networks’ limited experience with new product introductions, including the introduction of the Advanced Endpoint Protection offering; risks associated with new product releases, including software bugs; the failure to timely develop and achieve market acceptance of new products as well as existing products and services; rapidly evolving technological developments in the market for network security products; and general market, political, economic and business conditions.

[0001327567-15-000006:8k_2_02:31]
Additional risks and uncertainties that could affect Palo Alto Networks’ financial results are included under the captions “Risk Factors” and “Management’s Discussion and Analysis of Financial Condition and Results of Operations,” in the company’s quarterly report on Form 10-Q filed with the SEC on November 25, 2014, which is available on the company’s website at investors.paloaltonetworks.com and on the SEC’s website at www.sec.gov. Additional information will also be set forth in other filings that the company makes with the SEC from time to time. All forward-looking statements in this press release are based on information available to the company as of the date hereof, and Palo Alto Networks does not

[0001327567-15-000006:8k_2_02:32]
assume any obligation to update the forward-looking statements provided to reflect events that occur or circumstances that exist after the date on which they were made.

[0001327567-15-000006:8k_2_02:33]
Non-GAAP Financial Measures

[0001327567-15-000006:8k_2_02:34]
Palo Alto Networks has provided in this release financial information that has not been prepared in accordance with generally accepted accounting principles in the United States (GAAP). The company uses these non-GAAP financial measures internally in analyzing its financial results and believes that the use of these non-GAAP financial measures is useful to investors as an additional tool to evaluate ongoing operating results and trends and in comparing the company’s financial results with other companies in its industry, many of which present similar non-GAAP financial measures.

[0001327567-15-000006:8k_2_02:35]
Non-GAAP financial measures are not meant to be considered in isolation or as a substitute for comparable GAAP financial measures, and should be read only in conjunction with the company’s consolidated financial statements prepared in accordance with GAAP. A reconciliation of the company’s non-GAAP financial measures to their most directly comparable GAAP measures has been provided in the financial statement tables included in this press release, and investors are encouraged to review the reconciliation.

[0001327567-15-000006:8k_2_02:36]
Non-GAAP net income and diluted net income per share. Palo Alto Networks defines non-GAAP net income as net income (loss) plus share-based compensation expense and related payroll taxes, acquisition related costs, amortization expense of acquired intangible assets, litigation related charges including legal settlements, and non-cash interest expense related to the company’s convertible senior notes. The company also excludes from non-GAAP net income and non-GAAP diluted net income per share the tax effects, including income tax associated with these items in order to provide a complete picture of the company’s recurring core business operating results. Without excluding these tax effects, investors would only see the gross effect that excluding these expenses had on the company’s operating results. In addition, the calculation of diluted shares within diluted net income per share gives effect to the anti-dilutive impact of the company’s note hedge agreements, which reduce the potential economic dilution that otherwise would occur upon conversion of the company’s convertible senior notes (under GAAP, the anti-dilutive impact of the note hedge is not reflected in diluted shares). Palo Alto Networks believes that excluding these items from non-GAAP net income and non-GAAP diluted net income per share provides management and investors with greater visibility into the underlying performance of the company’s core business operating results, meaning its operating performance excluding these items and, from time to time, other discrete charges that are infrequent in nature, over multiple periods.

[0001327567-15-000006:8k_2_02:37]
4

[0001327567-15-000006:8k_2_02:38]
Billings. Palo Alto Networks defines billings as total revenue plus the change in deferred revenue during the period. The company’s management monitors billings because billings drive deferred revenue, which is an important indicator of the health and visibility of the company’s business. The company considers billings to be a useful metric for management and investors, particularly as sales of subscriptions increase and the company experiences strong renewal rates for subscriptions and support and maintenance.

[0001327567-15-000006:8k_2_02:39]
Investors are cautioned that there are a number of limitations associated with the use of non-GAAP financial measures as an analytical tool. In particular, many of the adjustments to the company’s GAAP financial measures reflect the exclusion of items that are recurring and will be reflected in the company’s financial results for the foreseeable future, such as share-based compensation. Share-based compensation is an important part of Palo Alto Networks employees’ compensation and impacts their performance. In addition, the billings metric reported by the company includes amounts that have not yet been recognized as revenue. The components that Palo Alto Networks excludes in its calculation of non-GAAP financial measures may differ from the components that its peer companies exclude when they report their non-GAAP results of operations. Palo Alto Networks compensates for these limitations by providing specific information regarding the GAAP amounts excluded from these non-GAAP financial measures. In the future, the company may also exclude non-recurring expenses and other expenses that do not reflect the company’s core business operating results.

[0001327567-15-000006:8k_2_02:40]
About Palo Alto Networks

[0001327567-15-000006:8k_2_02:41]
Palo Alto Networks is leading a new era in cybersecurity by protecting thousands of enterprise, government, and service provider networks from cyber threats. Unlike fragmented legacy products, our security platform safely enables business operations and delivers protection based on what matters most in today's dynamic computing environments: applications, users, and content. Find out more at www.paloaltonetworks.com.

[0001327567-15-000006:8k_2_02:42]
Palo Alto Networks and the Palo Alto Networks Logo are trademarks of Palo Alto Networks, Inc. in the United States and in jurisdictions throughout the world. All other trademarks, trade names or service marks used or mentioned herein belong to their respective owners.

[0001327567-15-000006:8k_2_02:43]
Media Contact:

[0001327567-15-000006:8k_2_02:44]
Jennifer Jasper Smith

[0001327567-15-000006:8k_2_02:45]
Head of Corporate Communications

[0001327567-15-000006:8k_2_02:46]
Palo Alto Networks

[0001327567-15-000006:8k_2_02:47]
408-638-3280

[0001327567-15-000006:8k_2_02:48]
jjsmith@paloaltonetworks.com

[0001327567-15-000006:8k_2_02:49]
Investor Relations Contact:

[0001327567-15-000006:8k_2_02:50]
Kelsey Turcotte

[0001327567-15-000006:8k_2_02:51]
Vice President of Investor Relations

[0001327567-15-000006:8k_2_02:52]
408-753-3872

[0001327567-15-000006:8k_2_02:53]
kturcotte@paloaltonetworks.com

[0001327567-15-000006:8k_2_02:54]
Chris Danne/Maria Riley

[0001327567-15-000006:8k_2_02:55]
The Blueshirt Group

[0001327567-15-000006:8k_2_02:56]
415-217-7722

[0001327567-15-000006:8k_2_02:57]
ir@paloaltonetworks.com

[0001327567-15-000006:8k_2_02:58]
| Palo Alto Networks, Inc. |
| Preliminary Condensed Consolidated Statements of Operations |
| (In thousands, except per share data) |
| (Unaudited) |
|  | Three Months Ended January 31, |  | Six Months Ended January 31, |
|  | 2015 |  | 2014 |  | 2015 |  | 2014 |
| Revenue: |  |  |  |  |  |  |  |
| Product | $ | 115,621 |  |  | $ | 80,823 |  |  | $ | 217,097 |  |  | $ | 156,308 |  |
| Services | 102,034 |  |  | 60,245 |  |  | 192,904 |  |  | 112,940 |  |
| Total revenue | 217,655 |  |  | 141,068 |  |  | 410,001 |  |  | 269,248 |  |
| Cost of revenue: |  |  |  |  |  |  |  |
| Product | 30,640 |  |  | 20,221 |  |  | 59,781 |  |  | 38,175 |  |
| Services | 28,685 |  |  | 17,283 |  |  | 53,005 |  |  | 33,136 |  |
| Total cost of revenue | 59,325 |  |  | 37,504 |  |  | 112,786 |  |  | 71,311 |  |
| Total gross profit | 158,330 |  |  | 103,564 |  |  | 297,215 |  |  | 197,937 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 46,948 |  |  | 24,253 |  |  | 84,253 |  |  | 44,146 |  |
| Sales and marketing | 122,875 |  |  | 76,734 |  |  | 229,241 |  |  | 144,100 |  |
| General and administrative | 27,023 |  |  | 19,733 |  |  | 46,000 |  |  | 33,858 |  |
| Legal settlement | — |  |  | 20,000 |  |  | — |  |  | 20,000 |  |
| Total operating expenses | 196,846 |  |  | 140,720 |  |  | 359,494 |  |  | 242,104 |  |
| Operating loss | (38,516 | ) |  | (37,156 | ) |  | (62,279 | ) |  | (44,167 | ) |
| Interest expense | (5,539 | ) |  | (14 | ) |  | (11,028 | ) |  | (22 | ) |
| Other income (expense), net | 344 |  |  | (170 | ) |  | 685 |  |  | 235 |  |
| Loss before income taxes | (43,711 | ) |  | (37,340 | ) |  | (72,622 | ) |  | (43,954 | ) |
| Provision for (benefit from) income taxes | (703 | ) |  | 2,606 |  |  | 454 |  |  | 3,853 |  |
| Net loss | $ | (43,008 | ) |  | $ | (39,946 | ) |  | $ | (73,076 | ) |  | $ | (47,807 | ) |
| Net loss per share, basic and diluted | $ | (0.53 | ) |  | $ | (0.55 | ) |  | $ | (0.91 | ) |  | $ | (0.66 | ) |
| Weighted-average shares used to compute net loss per share, basic and diluted | 80,824 |  |  | 72,854 |  |  | 80,105 |  |  | 72,260 |  |

[0001327567-15-000006:8k_2_02:59]
7

[0001327567-15-000006:8k_2_02:60]
| Palo Alto Networks, Inc. |
| Reconciliation of GAAP to Non-GAAP Financial Measures |
| (In thousands, except per share amounts) |
| (Unaudited) |
|  | Three Months Ended January 31, |  | Six Months Ended January 31, |
|  | 2015 |  | 2014 |  | 2015 |  | 2014 |
| GAAP net loss | $ | (43,008 | ) |  | $ | (39,946 | ) |  | $ | (73,076 | ) |  | $ | (47,807 | ) |
| Share-based compensation expense | 56,881 |  |  | 21,000 |  |  | 95,356 |  |  | 35,411 |  |
| Share-based payroll tax expense | 3,727 |  |  | 2,355 |  |  | 4,781 |  |  | 2,620 |  |
| Acquisition related costs | — |  |  | 3,799 |  |  | — |  |  | 3,799 |  |
| Amortization expense of acquired intangible assets | 1,724 |  |  | 65 |  |  | 3,268 |  |  | 65 |  |
| Litigation related charges [a] | 3,065 |  |  | 22,653 |  |  | 6,130 |  |  | 24,542 |  |
| Non-cash interest expense related to convertible notes | 5,521 |  |  | — |  |  | 10,999 |  |  | — |  |
| Income tax and other tax adjustments related to the above | (11,042 | ) |  | (2,156 | ) |  | (17,753 | ) |  | (4,690 | ) |
| Non-GAAP net income | $ | 16,868 |  |  | $ | 7,770 |  |  | $ | 29,705 |  |  | $ | 13,940 |  |
| GAAP net loss per share, diluted | $ | (0.53 | ) |  | $ | (0.55 | ) |  | $ | (0.91 | ) |  | $ | (0.66 | ) |
| Share-based compensation expense | 0.68 |  |  | 0.29 |  |  | 1.16 |  |  | 0.47 |  |
| Share-based payroll tax expense | 0.05 |  |  | 0.03 |  |  | 0.06 |  |  | 0.04 |  |
| Acquisition related costs | 0.00 |  |  | 0.05 |  |  | 0.00 |  |  | 0.05 |  |
| Amortization expense of acquired intangible assets | 0.02 |  |  | 0.00 |  |  | 0.04 |  |  | 0.00 |  |
| Litigation related charges [a] | 0.04 |  |  | 0.31 |  |  | 0.08 |  |  | 0.34 |  |
| Non-cash interest expense related to convertible notes | 0.07 |  |  | 0.00 |  |  | 0.14 |  |  | 0.00 |  |
| Income tax and other tax adjustments related to the above | (0.14 | ) |  | (0.03 | ) |  | (0.22 | ) |  | (0.06 | ) |
| Non-GAAP net income per share, diluted | $ | 0.19 |  |  | $ | 0.10 |  |  | $ | 0.35 |  |  | $ | 0.18 |  |
| GAAP weighted-average shares used to compute net loss per share, diluted | 80,824 |  |  | 72,854 |  |  | 80,105 |  |  | 72,260 |  |
| Weighted-average effect of potentially dilutive securities [b] | 5,804 |  |  | 5,329 |  |  | 5,733 |  |  | 5,427 |  |
| Non-GAAP weighted-average shares used to compute net income per share, diluted | 86,628 |  |  | 78,183 |  |  | 85,838 |  |  | 77,687 |  |
| Revenue | $ | 217,655 |  |  | $ | 141,068 |  |  | $ | 410,001 |  |  | $ | 269,248 |  |
| Change in deferred revenue | 65,123 |  |  | 45,635 |  |  | 113,265 |  |  | 75,361 |  |
| Billings | $ | 282,778 |  |  | $ | 186,703 |  |  | $ | 523,266 |  |  | $ | 344,609 |  |

[0001327567-15-000006:8k_2_02:61]
___________

[0001327567-15-000006:8k_2_02:62]
[a]    Litigation related charges during the three and six months ended January 31, 2015 includes the amortization of intellectual property licenses entered into as part of the settlement with Juniper. Litigation related charges during the three and six months ended January 31, 2014 includes expenses for legal services and the legal settlement with Fortinet of $20.0 million.

[0001327567-15-000006:8k_2_02:63]
[b]    Non-GAAP net income per share, diluted, includes the potentially dilutive effect of our options, restricted stock units, and convertible senior notes outstanding. In addition, Non-GAAP net income per share, diluted, includes the anti-dilutive impact of the company’s note hedge agreements, which reduced the potentially dilutive effect of the convertible notes for the three and six months ended January 31, 2015 by 0.6 million shares and 0.3 million shares, respectively. The potentially dilutive effect of the convertible notes for the three and six months ended January 31, 2014 was nil.

[0001327567-15-000006:8k_2_02:64]
8

[0001327567-15-000006:8k_2_02:65]
| Palo Alto Networks, Inc. |
| Preliminary Condensed Consolidated Balance Sheets |
| (In thousands) |
| (Unaudited) |
|  | January 31, 2015 |  | July 31, 2014 |
| Assets |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 342,983 |  |  | $ | 653,812 |  |
| Short-term investments | 332,074 |  |  | 118,690 |  |
| Accounts receivable, net | 135,251 |  |  | 135,518 |  |
| Prepaid expenses and other current assets | 51,196 |  |  | 50,306 |  |
| Total current assets | 861,504 |  |  | 958,326 |  |
| Property and equipment, net | 52,639 |  |  | 48,744 |  |
| Long-term investments | 463,908 |  |  | 201,880 |  |
| Goodwill | 155,402 |  |  | 155,033 |  |
| Intangible assets, net | 45,856 |  |  | 47,955 |  |
| Other assets | 93,475 |  |  | 66,528 |  |
| Total assets | $ | 1,672,784 |  |  | $ | 1,478,466 |  |
| Liabilities and stockholders’ equity |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 14,001 |  |  | $ | 14,526 |  |
| Accrued compensation | 53,158 |  |  | 48,727 |  |
| Accrued and other liabilities | 23,436 |  |  | 25,000 |  |
| Deferred revenue | 324,479 |  |  | 259,918 |  |
| Total current liabilities | 415,074 |  |  | 348,171 |  |
| Convertible senior notes, net | 476,872 |  |  | 466,875 |  |
| Long-term deferred revenue | 211,364 |  |  | 162,660 |  |
| Other long-term liabilities | 53,413 |  |  | 32,177 |  |
| Stockholders’ equity: |  |  |  |
| Preferred stock | — |  |  | — |  |
| Common stock | 8 |  |  | 8 |  |
| Additional paid-in capital | 924,634 |  |  | 804,406 |  |
| Accumulated other comprehensive income (loss) | 221 |  |  | (105 | ) |
| Accumulated deficit | (408,802 | ) |  | (335,726 | ) |
| Total stockholders’ equity | 516,061 |  |  | 468,583 |  |
| Total liabilities and stockholders’ equity | $ | 1,672,784 |  |  | $ | 1,478,466 |  |

[0001327567-15-000006:8k_2_02:66]
9

[0001327567-15-000006:8k_2_02:67]
| Palo Alto Networks, Inc. |
| Preliminary Condensed Consolidated Statements of Cash Flows |
| (In thousands) |
| (Unaudited) |
|  | Six Months Ended January 31, |
|  | 2015 |  | 2014 |
| Cash flows from operating activities |  |  |  |
| Net loss | $ | (73,076 | ) |  | $ | (47,807 | ) |
| Adjustments to reconcile net loss to net cash provided by operating activities: |  |  |  |
| Share-based compensation for equity based awards | 95,291 |  |  | 38,729 |  |
| Depreciation and amortization | 12,917 |  |  | 7,082 |  |
| Amortization of investment premiums, net of accretion of purchase discounts | 1,510 |  |  | 747 |  |
| Amortization of debt discount and debt issuance costs | 10,999 |  |  | — |  |
| Excess tax benefit from share-based compensation arrangements | (1,271 | ) |  | (674 | ) |
| Changes in operating assets and liabilities |  |  |  |
| Accounts receivable, net | 267 |  |  | 1,371 |  |
| Prepaid expenses and other assets | (32,435 | ) |  | (6,207 | ) |
| Accounts payable | (1,897 | ) |  | (4,387 | ) |
| Accrued compensation | 4,431 |  |  | 7,709 |  |
| Accrued and other liabilities | 21,753 |  |  | 8,353 |  |
| Deferred revenue | 113,265 |  |  | 75,361 |  |
| Net cash provided by operating activities | 151,754 |  |  | 80,277 |  |
| Cash flows from investing activities |  |  |  |
| Purchases of investments | (587,273 | ) |  | (249,803 | ) |
| Proceeds from sales of investments | 1,999 |  |  | 6,630 |  |
| Proceeds from maturities of investments | 109,921 |  |  | 129,096 |  |
| Acquisition of business, net of cash acquired | — |  |  | (10,102 | ) |
| Purchases of property, equipment, and other assets | (12,035 | ) |  | (25,483 | ) |
| Net cash used in investing activities | (487,388 | ) |  | (149,662 | ) |
| Cash flows from financing activities |  |  |  |
| Proceeds from exercise of stock options | 15,743 |  |  | 14,085 |  |
| Proceeds from employee stock purchase plan | 7,791 |  |  | 5,988 |  |
| Excess tax benefit from share-based compensation arrangements | 1,271 |  |  | 674 |  |
| Repurchases of restricted common stock from terminated employees | — |  |  | (109 | ) |
| Net cash provided by financing activities | 24,805 |  |  | 20,638 |  |
| Net decrease in cash and cash equivalents | (310,829 | ) |  | (48,747 | ) |
| Cash and cash equivalents - beginning of period | 653,812 |  |  | 310,614 |  |
| Cash and cash equivalents - end of period | $ | 342,983 |  |  | $ | 261,867 |  |

[0001327567-15-000006:8k_2_02:68]
10
