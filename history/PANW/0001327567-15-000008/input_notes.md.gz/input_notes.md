# PANW notes — 0001327567-15-000008


## panw:ScheduleOfIntangibleAssetsByMajorClassTableTextBlock

[0001327567-15-000008:notes:1]
The following table presents details of our purchased intangible assets as of January 31, 2015 and July 31, 2014 (in thousands):

[0001327567-15-000008:notes:2]
|  |  | January 31, 2015 |  | July 31, 2014 |
|  |  | Gross Carrying Amount |  | Accumulated Amortization |  | Net Carrying Amount |  | Gross Carrying Amount |  | Accumulated Amortization |  | Net Carrying Amount |
| Intangible assets with finite lives: |  |  |  |  |  |  |  |  |  |  |  |  |
| Developed technology |  | $ | 42,100 |  |  | $ | (4,469 | ) |  | $ | 37,631 |  |  | $ | 34,500 |  |  | $ | (1,643 | ) |  | $ | 32,857 |  |
| Acquired intellectual property |  | 8,156 |  |  | (1,399 | ) |  | 6,757 |  |  | 6,546 |  |  | (958 | ) |  | 5,588 |  |
| In-process research and development held for defensive purposes |  | 1,900 |  |  | (686 | ) |  | 1,214 |  |  | 1,900 |  |  | (370 | ) |  | 1,530 |  |
| Other |  | 500 |  |  | (246 | ) |  | 254 |  |  | 500 |  |  | (120 | ) |  | 380 |  |
| Total intangible assets with finite lives |  | 52,656 |  |  | (6,800 | ) |  | 45,856 |  |  | 43,446 |  |  | (3,091 | ) |  | 40,355 |  |
| In-process research and development with indefinite lives |  | — |  |  | — |  |  | — |  |  | 7,600 |  |  | — |  |  | 7,600 |  |
| Total purchased intangible assets |  | $ | 52,656 |  |  | $ | (6,800 | ) |  | $ | 45,856 |  |  | $ | 51,046 |  |  | $ | (3,091 | ) |  | $ | 47,955 |  |


## us-gaap:AvailableForSaleSecuritiesContinuousUnrealizedLossPositionFairValueTableTextBlock

[0001327567-15-000008:notes:3]
The following tables present our investments that were in an unrealized loss position as of January 31, 2015 and July 31, 2014 (in thousands):

[0001327567-15-000008:notes:4]
|  | January 31, 2015 |
|  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
|  | Fair Value |  | Unrealized Loss |  | Fair Value |  | Unrealized Loss |  | Fair Value |  | Unrealized Loss |
| Corporate debt securities | $ | 84,073 |  |  | $ | (62 | ) |  | $ | — |  |  | $ | — |  |  | $ | 84,073 |  |  | $ | (62 | ) |
| U.S. government and agency securities | 206,056 |  |  | (75 | ) |  | — |  |  | — |  |  | 206,056 |  |  | (75 | ) |
| Total | $ | 290,129 |  |  | $ | (137 | ) |  | $ | — |  |  | $ | — |  |  | $ | 290,129 |  |  | $ | (137 | ) |

[0001327567-15-000008:notes:5]
[same as prior period, unchanged from 0001327567-14-000043:notes:3]


## us-gaap:AvailableForSaleSecuritiesTextBlock

[0001327567-15-000008:notes:6]
The following tables summarize the unrealized gains and losses and fair value of our investments as of January 31, 2015 and July 31, 2014 (in thousands):

[0001327567-15-000008:notes:7]
|  | January 31, 2015 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Estimated Fair Value |
| Certificates of deposit | $ | 1,000 |  |  | $ | 1 |  |  | $ | — |  |  | $ | 1,001 |  |
| Corporate debt securities | 158,933 |  |  | 60 |  |  | (62 | ) |  | 158,931 |  |
| U.S. government and agency securities | 635,702 |  |  | 423 |  |  | (75 | ) |  | 636,050 |  |
| Total | $ | 795,635 |  |  | $ | 484 |  |  | $ | (137 | ) |  | $ | 795,982 |  |

[0001327567-15-000008:notes:8]
[same as prior period, unchanged from 0001327567-14-000043:notes:6]


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001327567-15-000008:notes:9]
[same as prior period, unchanged from 0001327567-14-000043:notes:7]

[0001327567-15-000008:notes:10]
[same as prior period, unchanged from 0001327567-14-000043:notes:8]


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock

[0001327567-15-000008:notes:11]
[same as prior period, unchanged from 0001327567-14-000043:notes:9]

[0001327567-15-000008:notes:12]
[same as prior period, unchanged from 0001327567-14-000043:notes:10]

[0001327567-15-000008:notes:13]
[same as prior period, unchanged from 0001327567-14-000043:notes:11]

[0001327567-15-000008:notes:14]
[same as prior period, unchanged from 0001327567-14-000043:notes:14]

[0001327567-15-000008:notes:15]
[same as prior period, unchanged from 0001327567-14-000043:notes:15]

[0001327567-15-000008:notes:16]
[same as prior period, unchanged from 0001327567-14-000043:notes:16]

[0001327567-15-000008:notes:17]
There have been no material changes to our significant accounting policies as of and for the six months ended January 31, 2015, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended July 31, 2014.

[0001327567-15-000008:notes:18]
[same as prior period, unchanged from 0001327567-14-000043:notes:18]

[0001327567-15-000008:notes:19]
In August 2014, the Financial Accounting Standards Board (FASB) issued Accounting Standards Update (ASU) No. 2014-15, Presentation of Financial Statements-Going Concern (Subtopic 205-40)-Disclosure of Uncertainties about an Entity’s Ability to Continue as a Going Concern. The standard provides guidance about management's responsibility to evaluate whether there is substantial doubt about an entity's ability to continue as a going concern and to provide related footnote disclosures. The standard is effective for fiscal years ending after December 15, 2016, and for interim periods thereafter. Early adoption is permitted. We will adopt the new standard in our fiscal year ending 2017. The adoption of this standard is not expected to have a material impact on our condensed consolidated financial statements.

[0001327567-15-000008:notes:20]
In May 2014, the FASB issued ASU No. 2014-09 regarding Accounting Standards Codification (ASC) Topic 606-Revenue from Contracts with Customers. The standard provides principles for recognizing revenue for the transfer of promised goods or services to customers with the consideration to which the entity expects to be entitled in exchange for those goods or services. The standard also requires significantly expanded disclosures about revenue recognition. The guidance is effective for us in the first quarter of fiscal 2018 using either of two methods: (i) retrospective to each prior reporting period presented with the option to elect certain practical expedients as defined within the guidance; or (ii) retrospective with the cumulative effect of initially applying the guidance recognized at the date of initial application and providing certain additional disclosures as defined per the guidance. Early adoption is not permitted. We are currently evaluating adoption methods and whether this standard will have a material impact on our condensed consolidated financial statements.

[0001327567-15-000008:notes:21]
In July 2013, the FASB issued ASU No. 2013-11, Income Taxes (Topic 740)-Presentation of an Unrecognized Tax Benefit When a Net Operating Loss Carryforward, a Similar Tax Loss, or a Tax Credit Carryforward Exists. The standard requires us to present an unrecognized tax benefit as a reduction of a deferred tax asset for a net operating loss (NOL) carryforward or other tax credit carryforward when settlement in this manner is available under applicable tax law. The guidance was effective for us in the first quarter of fiscal 2015. Our adoption of this guidance did not have an impact on our condensed consolidated financial statements.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001327567-15-000008:notes:22]
Commitments and Contingencies

[0001327567-15-000008:notes:23]
Leases

[0001327567-15-000008:notes:24]
We lease our facilities under various non-cancelable operating leases, which expire through the year ending July 31, 2023.

[0001327567-15-000008:notes:25]
The following table presents details of the aggregate future non-cancelable minimum rental payments under our operating leases as of January 31, 2015 (in thousands):

[0001327567-15-000008:notes:26]
|  | Amount |
| Fiscal years ending July 31: |  |
| Remaining 2015 | $ | 8,479 |  |
| 2016 | 16,901 |  |
| 2017 | 15,919 |  |
| 2018 | 12,926 |  |
| 2019 | 10,620 |  |
| 2020 and thereafter | 42,833 |  |
| Committed gross lease payments | 107,678 |  |
| Less: proceeds from sublease rental | 9,703 |  |
| Net operating lease obligation | $ | 97,975 |  |

[0001327567-15-000008:notes:27]
Contract Manufacturer Commitments

[0001327567-15-000008:notes:28]
Our independent contract manufacturer procures components and assembles our products based on our forecasts. These forecasts are based on estimates of demand for our products primarily for the next twelve months, which are in turn based on historical trends and an analysis from our sales and product marketing organizations, adjusted for overall market conditions. In order to reduce manufacturing lead times and plan for adequate supply, we may issue forecasts and orders for components and products that are non-cancelable. Obligations under contracts that we can cancel without a significant penalty are not included. As of January 31, 2015, we had $38,893,000 of open orders.

[0001327567-15-000008:notes:29]
Litigation

[0001327567-15-000008:notes:30]
In December 2011, Juniper Networks, Inc. (“Juniper”) filed a complaint against us in the United States District Court for the District of Delaware alleging patent infringement, which sought preliminary and permanent injunctions against infringement, treble damages, and attorneys' fees. On September 30, 2013, we filed a lawsuit against Juniper in the United States District Court for the Northern District of California alleging that Juniper’s products infringe three of our U.S. patents, and sought monetary damages and a permanent injunction. On May 27, 2014, we entered into a Settlement, Release and Cross-License Agreement (the “settlement agreement”) with Juniper to resolve all pending litigation between the parties, including those discussed above. Refer to Note 8. Legal Settlement for more information on the settlement agreement.

[0001327567-15-000008:notes:31]
In addition to the above matter, we are subject to legal proceedings, claims, and litigation arising in the ordinary course of business, including intellectual property litigation. Such matters are subject to many uncertainties and outcomes are not predictable with assurance. We accrue for contingencies when we believe that a loss is probable and that we can reasonably estimate the amount of any such loss. We have made an assessment of the probability of incurring any such losses and whether or not those losses are estimable.

[0001327567-15-000008:notes:32]
To the extent there is a reasonable possibility that a loss exceeding amounts already recognized may be incurred and the amount of such additional loss would be material, we will either disclose the estimated additional loss or state that such an estimate cannot be made. As of January 31, 2015, we have not recorded any accrual for loss contingencies associated with such legal proceedings, determined that an unfavorable outcome is probable or reasonably possible, or determined that the amount or range of any possible loss is reasonably estimable.


## us-gaap:ConvertibleDebtTableTextBlock

[0001327567-15-000008:notes:33]
The following table sets forth the components of the Notes as of January 31, 2015 and July 31, 2014 (in thousands):

[0001327567-15-000008:notes:34]
|  | January 31, 2015 |  | July 31, 2014 |
| Liability: |  |  |  |
| Principal | $ | 575,000 |  |  | $ | 575,000 |  |
| Less: debt discount, net of amortization | 98,128 |  |  | 108,125 |  |
| Net carrying amount | $ | 476,872 |  |  | $ | 466,875 |  |
| Equity | $ | (109,785 | ) |  | $ | (109,785 | ) |


## us-gaap:DebtDisclosureTextBlock

[0001327567-15-000008:notes:35]
Convertible Senior Notes

[0001327567-15-000008:notes:36]
On June 30, 2014, we issued $575,000,000 aggregate principal amount of 0.0% convertible senior notes due 2019 (the “Notes”). The Notes are governed by an indenture between us, as the issuer, and U.S. Bank National Association, as Trustee (the “Indenture”). The Notes are unsecured, unsubordinated obligations that do not contain any financial covenants or restrictions on the payments of dividends, the incurrence of indebtedness, or the issuance or repurchase of securities by us or any of our subsidiaries. The Notes mature on July 1, 2019 unless converted or repurchased in accordance with their terms prior to such date. We cannot redeem the Notes prior to maturity.

[0001327567-15-000008:notes:37]
The Notes are convertible for up to 5,214,000 shares of our common stock at an initial conversion rate of approximately 9.068 shares of common stock per $1,000 principal amount, which is equal to an initial conversion price of approximately $110.28 per share of common stock, subject to adjustment. Holders of the Notes may surrender their Notes for conversion at their option at any time prior to the close of business on the business day immediately preceding January 1, 2019, only under the following circumstances, none of which have occurred to date:

[0001327567-15-000008:notes:38]
| • | during any fiscal quarter commencing after the fiscal quarter ending on October 31, 2014 (and only during such fiscal quarter), if the last reported sale price of our common stock for at least 20 trading days (whether or not consecutive) during a period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the conversion price for the Notes on each applicable trading day; |

[0001327567-15-000008:notes:39]
| • | during the five business day period after any five consecutive trading day period (the “measurement period”), in which the trading price per $1,000 principal amount of Notes for each trading day of the measurement period was less than 98% of the product of the last reported sale price of our common stock and the conversion rate for the Notes on each such trading day; or |

[0001327567-15-000008:notes:40]
| • | upon the occurrence of specified corporate events. |

[0001327567-15-000008:notes:41]
On or after January 1, 2019, holders may convert all or any portion of their Notes at any time prior to the close of business on the second scheduled trading day immediately preceding the maturity date regardless of the foregoing conditions. Upon conversion, holders will receive cash equal to the aggregate principal amount of the Notes to be converted, and, at our election, cash and/or shares of our common stock for any amounts in excess of the aggregate principal amount of the Notes being converted.

[0001327567-15-000008:notes:42]
The conversion price will be subject to adjustment in some events. Holders of the Notes who convert their Notes in connection with certain corporate events that constitute a “make-whole fundamental change” per the Indenture are, under certain circumstances, entitled to an increase in the conversion rate. Additionally, upon the occurrence of a corporate event that constitutes a “fundamental change” per the Indenture, holders of the Notes may require us to repurchase for cash all or a portion of the Notes at a purchase price equal to 100% of the principal amount of the Notes plus accrued and unpaid contingent interest.

[0001327567-15-000008:notes:43]
In accounting for the issuance of the Notes, we separated the Notes into liability and equity components. The carrying amount of the liability component was calculated by measuring the fair value of a similar liability that does not have an associated convertible feature. The carrying amount of the equity component representing the conversion option was determined by deducting the fair value of the liability component from the par value of the Notes as a whole. The difference between the principal amount of the Notes and the liability component (the “debt discount”), is amortized to interest expense using the effective interest method over the term of the Notes. The equity component of the Notes is included in additional paid-in capital in our condensed consolidated balance sheets and is not remeasured as long as it continues to meet the conditions for equity classification.

[0001327567-15-000008:notes:44]
In accounting for the transaction costs related to the issuance of the Notes, we allocated the total amount incurred to the liability and equity components using the same proportions as the proceeds from the Notes. Transaction costs attributable to the liability component were recorded in other assets in our condensed consolidated balance sheets and are being amortized to interest expense in our condensed consolidated statements of operations using the effective interest method over the term of the Notes. Transaction costs attributable to the equity component were netted with the equity component of the Notes in additional paid-in capital in our condensed consolidated balance sheets. We recorded liability issuance costs, or debt issuance costs, of $12,497,000 and equity issuance costs of $2,949,000.

[0001327567-15-000008:notes:45]
The total estimated fair value of the Notes was $751,813,000 and $587,087,000 at January 31, 2015 and July 31, 2014, respectively. The fair value was determined based on the closing trading price per $100 of the Notes as of the last day of trading for the period. We consider the fair value of the Notes at January 31, 2015 and July 31, 2014 to be a Level 2 measurement. The fair value of the Notes is primarily affected by the trading price of our common stock and market interest rates. As of January 31, 2015, the if-converted value of the Notes exceeded its principal amount by $74,929,000.

[0001327567-15-000008:notes:46]
The following table sets forth interest expense recognized related to the Notes for the three and six months ended January 31, 2015 (dollars in thousands):

[0001327567-15-000008:notes:47]
|  | Three Months Ended |  | Six Months Ended |
|  | January 31, 2015 |
| Amortization of debt issuance costs | $ | 505 |  |  | $ | 1,002 |  |
| Amortization of debt discount | 5,016 |  |  | 9,997 |  |
| Total interest expense recognized | $ | 5,521 |  |  | $ | 10,999 |  |
| Effective interest rate of the liability component | 4.8 | % |  | 4.8 | % |

[0001327567-15-000008:notes:48]
Note Hedges

[0001327567-15-000008:notes:49]
To minimize the impact of potential economic dilution upon conversion of the Notes, we entered into convertible note hedge transactions (the “Note Hedges”) with respect to our common stock concurrent with the issuance of the Notes. The Note Hedges cover up to 5,214,000 shares of our common stock at a strike price per share that corresponds to the initial conversion price of the Notes, which are also subject to adjustment, and are exercisable upon conversion of the Notes. The Note Hedges will expire upon maturity of the Notes. The Note Hedges are separate transactions and are not part of the terms of the Notes. Holders of the Notes will not have any rights with respect to the Note Hedges. The shares receivable related to the Note Hedges are excluded from the calculation of diluted earnings per share as they are antidilutive.

[0001327567-15-000008:notes:50]
We paid an aggregate amount of $110,975,000 for the Note Hedges, which is included in additional paid-in capital in our condensed consolidated balance sheets.

[0001327567-15-000008:notes:51]
Warrants

[0001327567-15-000008:notes:52]
Separately, but concurrently with our issuance of the Notes, we entered into warrant transactions (the “Warrants”) whereby we sold warrants to acquire up to 5,214,000 shares of our common stock at a strike price of approximately $137.85 per share, subject to adjustments. The shares issuable under the Warrants will be included in the calculation of diluted earnings per share when the average market value per share of our common stock for the reporting period exceeds the strike price of the Warrants. The Warrants are separate transactions and are not part of the Notes or Notes Hedges, and are not remeasured through earnings each reporting period. Holders of the Notes and Note Hedges will not have any rights with respect to the Warrants.

[0001327567-15-000008:notes:53]
We received aggregate proceeds of $78,258,000 from the sale of the Warrants, which is included in additional paid-in capital in our condensed consolidated balance sheets.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001327567-15-000008:notes:54]
[same as prior period, unchanged from 0001327567-14-000043:notes:61]

[0001327567-15-000008:notes:55]
[same as prior period, unchanged from 0001327567-14-000043:notes:62]

[0001327567-15-000008:notes:56]
[same as prior period, unchanged from 0001327567-14-000043:notes:63]

[0001327567-15-000008:notes:57]
|  | Options Outstanding |
|  | Number of Shares |  | Weighted- Average Exercise Price |  | Weighted- Average Remaining Contractual Term (Years) |  | Aggregate Intrinsic Value |
| Balance—July 31, 2014 | 5,830 |  |  | $ | 13.02 |  |  | 7.0 |  | $ | 395,507 |  |
| Options granted | — |  |  | — |  |  |  |  |  |
| Options forfeited | (38 | ) |  | 17.31 |  |  |  |  |  |
| Options exercised | (1,304 | ) |  | 12.09 |  |  |  |  |  |
| Balance—January 31, 2015 | 4,488 |  |  | $ | 13.26 |  |  | 6.6 |  | $ | 507,727 |  |
| Options vested and expected to vest—January 31, 2015 | 4,431 |  |  | $ | 13.18 |  |  | 6.5 |  | $ | 501,634 |  |
| Options exercisable—January 31, 2015 | 2,993 |  |  | $ | 11.07 |  |  | 6.3 |  | $ | 345,153 |  |

[0001327567-15-000008:notes:58]
[same as prior period, unchanged from 0001327567-14-000043:notes:65]

[0001327567-15-000008:notes:59]
[same as prior period, unchanged from 0001327567-14-000043:notes:66]

[0001327567-15-000008:notes:60]
|  | RSUs Outstanding |
|  | Number of Shares |  | Weighted- Average Grant-Date Fair Value Per Share |  | Weighted- Average Remaining Contractual Term (Years) |  | Aggregate Intrinsic Value |
| Balance—July 31, 2014 | 6,046 |  |  | $ | 59.84 |  |  | 1.4 |  | $ | 488,880 |  |
| RSUs granted | 3,150 |  |  | 107.24 |  |  |  |  |  |
| RSUs vested | (1,326 | ) |  | 54.68 |  |  |  |  |  |
| RSUs forfeited | (199 | ) |  | 62.32 |  |  |  |  |  |
| Balance—January 31, 2015 | 7,671 |  |  | $ | 80.13 |  |  | 1.4 |  | $ | 969,538 |  |
| RSUs vested and expected to vest—January 31, 2015 | 6,943 |  |  | $ | 79.68 |  |  | 1.4 |  | $ | 877,526 |  |

[0001327567-15-000008:notes:61]
[same as prior period, unchanged from 0001327567-14-000043:notes:68]

[0001327567-15-000008:notes:62]
[same as prior period, unchanged from 0001327567-14-000043:notes:69]

[0001327567-15-000008:notes:63]
|  | Three Months Ended January 31, |  | Six Months Ended January 31, |
|  | 2015 |  | 2014 |  | 2015 |  | 2014 |
| Cost of product revenue | $ | 955 |  |  | $ | 320 |  |  | $ | 1,704 |  |  | $ | 584 |  |
| Cost of services revenue | 5,140 |  |  | 2,085 |  |  | 8,635 |  |  | 3,571 |  |
| Research and development | 18,990 |  |  | 5,807 |  |  | 32,989 |  |  | 9,159 |  |
| Sales and marketing | 21,727 |  |  | 9,745 |  |  | 37,526 |  |  | 16,678 |  |
| General and administrative | 10,069 |  |  | 6,427 |  |  | 14,502 |  |  | 8,803 |  |
| Total | $ | 56,881 |  |  | $ | 24,384 |  |  | $ | 95,356 |  |  | $ | 38,795 |  |

[0001327567-15-000008:notes:64]
At January 31, 2015, total compensation cost related to unvested share-based awards not yet recognized was $528,930,000, net of estimated forfeitures. This cost is expected to be amortized on a straight-line basis over a weighted-average period of approximately three years. Future grants will increase the amount of compensation expense to be recorded in these periods.


## us-gaap:EarningsPerShareTextBlock

[0001327567-15-000008:notes:65]
[same as prior period, unchanged from 0001327567-14-000043:notes:72]

[0001327567-15-000008:notes:66]
Basic net income (loss) per share is computed by dividing net income (loss) by basic weighted-average shares outstanding during the period. Diluted net income (loss) per share is computed by dividing net income (loss) by diluted weighted-average shares outstanding, including potentially dilutive securities.

[0001327567-15-000008:notes:67]
[same as prior period, unchanged from 0001327567-14-000043:notes:74]

[0001327567-15-000008:notes:68]
|  | Three Months Ended |  | Six Months Ended |
|  | January 31, |  | January 31, |
|  | 2015 |  | 2014 |  | 2015 |  | 2014 |
| Net loss | $ | (43,008 | ) |  | $ | (39,946 | ) |  | $ | (73,076 | ) |  | $ | (47,807 | ) |
| Weighted-average shares used to compute net loss per share, basic and diluted | 80,824 |  |  | 72,854 |  |  | 80,105 |  |  | 72,260 |  |
| Net loss per share, basic and diluted | $ | (0.53 | ) |  | $ | (0.55 | ) |  | $ | (0.91 | ) |  | $ | (0.66 | ) |

[0001327567-15-000008:notes:69]
[same as prior period, unchanged from 0001327567-14-000043:notes:76]

[0001327567-15-000008:notes:70]
|  | January 31, |
|  | 2015 |  | 2014 |
| Options to purchase common stock | 4,488 |  |  | 7,807 |  |
| RSUs | 7,671 |  |  | 5,201 |  |
| ESPP shares | 98 |  |  | 132 |  |
| Convertible senior notes | 5,214 |  |  | — |  |
| Warrants related to the issuance of convertible senior notes | 5,214 |  |  | — |  |
| Total | 22,685 |  |  | 13,140 |  |


## us-gaap:FairValueAssetsAndLiabilitiesMeasuredOnRecurringAndNonrecurringBasisTableTextBlock

[0001327567-15-000008:notes:71]
The following table presents the fair value of our financial assets and liabilities using the above input categories as of January 31, 2015 and July 31, 2014 (in thousands):

[0001327567-15-000008:notes:72]
|  |  | January 31, 2015 |  | July 31, 2014 |
|  |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Short-term investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Certificates of deposit |  | $ | — |  |  | $ | 1,001 |  |  | $ | — |  |  | $ | 1,001 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Corporate debt securities |  | — |  |  | 51,352 |  |  | — |  |  | 51,352 |  |  | — |  |  | 22,239 |  |  | — |  |  | 22,239 |  |
| U.S. government and agency securities |  | — |  |  | 279,721 |  |  | — |  |  | 279,721 |  |  | — |  |  | 96,451 |  |  | — |  |  | 96,451 |  |
| Total short-term investments |  | — |  |  | 332,074 |  |  | — |  |  | 332,074 |  |  | — |  |  | 118,690 |  |  | — |  |  | 118,690 |  |
| Long-term investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Certificates of deposit |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 1,000 |  |  | — |  |  | 1,000 |  |
| Corporate debt securities |  | — |  |  | 107,579 |  |  | — |  |  | 107,579 |  |  | — |  |  | 39,018 |  |  | — |  |  | 39,018 |  |
| U.S. government and agency securities |  | — |  |  | 356,329 |  |  | — |  |  | 356,329 |  |  | — |  |  | 161,862 |  |  | — |  |  | 161,862 |  |
| Total long-term investments |  | — |  |  | 463,908 |  |  | — |  |  | 463,908 |  |  | — |  |  | 201,880 |  |  | — |  |  | 201,880 |  |
| Other assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Certificates of deposit |  | 1,220 |  |  | — |  |  | — |  |  | 1,220 |  |  | 1,220 |  |  | — |  |  | — |  |  | 1,220 |  |
| Total other assets |  | 1,220 |  |  | — |  |  | — |  |  | 1,220 |  |  | 1,220 |  |  | — |  |  | — |  |  | 1,220 |  |
| Total assets measured at fair value |  | $ | 1,220 |  |  | $ | 795,982 |  |  | $ | — |  |  | $ | 797,202 |  |  | $ | 1,220 |  |  | $ | 320,570 |  |  | $ | — |  |  | $ | 321,790 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001327567-15-000008:notes:73]
[same as prior period, unchanged from 0001327567-14-000043:notes:80]

[0001327567-15-000008:notes:74]
[same as prior period, unchanged from 0001327567-14-000043:notes:81]

[0001327567-15-000008:notes:75]
[same as prior period, unchanged from 0001327567-14-000043:notes:82]

[0001327567-15-000008:notes:76]
[same as prior period, unchanged from 0001327567-14-000043:notes:83]

[0001327567-15-000008:notes:77]
[same as prior period, unchanged from 0001327567-14-000043:notes:84]

[0001327567-15-000008:notes:78]
Refer to Note 6. Convertible Senior Notes for the carrying amount and estimated fair value of our convertible senior notes as of January 31, 2015.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001327567-15-000008:notes:79]
[same as prior period, unchanged from 0001327567-14-000043:notes:86]

[0001327567-15-000008:notes:80]
Our provision for (benefit from) income taxes for the three and six months ended January 31, 2015 reflects an effective tax rate of 1.6% and negative 0.6%, respectively. Our effective tax rate for the six months ended January 31, 2015 was negative as we recorded a provision for income taxes on year to date losses. The key components of our income tax provision consist of foreign income, foreign withholding taxes, and U.S. federal and state income taxes. Key components of our effective tax rate consist of foreign tax losses which derive no benefit, non-deductible share-based compensation, and changes in our valuation allowance. As compared to the same periods last year, our effective tax rate changed due to fluctuations in our overall loss before income taxes and the geographic mix of income due to global expansion.

[0001327567-15-000008:notes:81]
Our provision for income taxes for the three and six months ended January 31, 2014 reflects an effective tax rate of negative 7.0% and negative 8.8%, respectively. Our effective tax rates for these periods were negative due to the fact that we recorded a provision for income taxes on year to date losses. The key components of our income tax provision, and the related effective tax rate, consist of foreign tax losses which derive no benefit, non-deductible share-based compensation, and foreign income and withholding taxes.

[0001327567-15-000008:notes:82]
In December 2014, the Tax Increase Prevention Act of 2014 was signed into law, which retroactively extends the federal research and development credit, bonus depreciation, and other corporate tax incentives through December 31, 2014. The benefit from income tax derived from this for the fiscal year ending July 31, 2015 is dependent on actual results for the year.

[0001327567-15-000008:notes:83]
As of January 31, 2015, we had $44,583,000 of unrecognized tax benefits, $4,856,000 of which would affect income tax expense if recognized, after consideration of our valuation allowance in the U.S. and other assets. The increase in unrecognized tax benefits since July 31, 2014 relates to positions taken in the current year. As of January 31, 2015, our federal, state, and foreign returns for the tax years 2008 through the current period remain open to examination. Fiscal years outside the normal statute of limitation remain open to audit by tax authorities due to tax attributes generated in earlier years, which have been carried forward and may be audited in subsequent years when utilized. We do not expect the unrecognized tax benefits to change significantly over the next 12 months. We recognize both interest and penalties associated with uncertain tax positions as a component of income tax expense. The ultimate amount and timing of any future cash settlements cannot be predicted with reasonable certainty.


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001327567-15-000008:notes:84]
[same as prior period, unchanged from 0001327567-14-000043:notes:89]

[0001327567-15-000008:notes:85]
We recognized amortization expense of $1,955,000 and $3,709,000 for the three and six months ended January 31, 2015, respectively, and $270,000 and $425,000 for the three and six months ended January 31, 2014, respectively. Our in-process research and development acquired from Cyvera Ltd. (“Cyvera”) in April 2014 was transferred to developed technology during the three months ended October 31, 2014 and is being amortized over its estimated useful life of seven years.

[0001327567-15-000008:notes:86]
The following table summarizes our estimated future amortization expense of intangible assets with finite lives by type as of January 31, 2015 (in thousands):

[0001327567-15-000008:notes:87]
|  | Fiscal Years Ending July 31, |
|  | Remaining 2015 |  | 2016 |  | 2017 |  | 2018 |  | 2019 |  | 2020 and Thereafter |
| Developed technology | $ | 3,007 |  |  | $ | 6,014 |  |  | $ | 6,014 |  |  | $ | 6,014 |  |  | $ | 6,014 |  |  | $ | 10,568 |  |
| Acquired intellectual property | 491 |  |  | 947 |  |  | 853 |  |  | 617 |  |  | 511 |  |  | 3,338 |  |
| In-process research and development held for defensive purposes | 317 |  |  | 633 |  |  | 264 |  |  | — |  |  | — |  |  | — |  |
| Other | 124 |  |  | 130 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Total future amortization expense | $ | 3,939 |  |  | $ | 7,724 |  |  | $ | 7,131 |  |  | $ | 6,631 |  |  | $ | 6,525 |  |  | $ | 13,906 |  |


## us-gaap:InvestmentsClassifiedByContractualMaturityDateTableTextBlock

[0001327567-15-000008:notes:88]
The following table summarizes the amortized cost and fair value of our investments as of January 31, 2015, by contractual years-to-maturity (in thousands):

[0001327567-15-000008:notes:89]
|  | Amortized Cost |  | Fair Value |
| Due within one year | $ | 332,047 |  |  | $ | 332,074 |  |
| Due within one to two years | 462,498 |  |  | 462,819 |  |
| Due within two to three years | 1,090 |  |  | 1,089 |  |
| Total | $ | 795,635 |  |  | $ | 795,982 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001327567-15-000008:notes:90]
Investments

[0001327567-15-000008:notes:91]
Unrealized losses related to these investments are due to interest rate fluctuations as opposed to credit quality. In addition, we do not intend to sell and it is not likely that we would be required to sell these investments before recovery of their amortized cost basis, which may be at maturity. As a result, there is no other-than-temporary impairment for these investments at January 31, 2015.


## us-gaap:LegalMattersAndContingenciesTextBlock

[0001327567-15-000008:notes:92]
Legal Settlement

[0001327567-15-000008:notes:93]
Mutual Covenant Not to Sue and Release Agreement

[0001327567-15-000008:notes:94]
On January 27, 2014, we executed a Mutual Covenant Not to Sue and Release Agreement with Fortinet, Inc., thereby extending an existing covenant for six more years. We evaluated the transaction as a multiple-element arrangement and allocated the one-time payment that we made in the amount of $20,000,000 to each identifiable element using its relative fair value. Based on our estimates of fair value, we determined that the primary benefit of the arrangement is avoided litigation cost and the release of any potential past claims, with no material value attributable to future use or benefit. Accordingly, we recorded a $20,000,000 settlement charge within legal settlement expense in our condensed consolidated statement of operations during the three months ended January 31, 2014.

[0001327567-15-000008:notes:95]
Settlement, Release and Cross-License Agreement with Juniper

[0001327567-15-000008:notes:96]
On May 27, 2014, we entered into the settlement agreement with Juniper, whereby we resolved all pending litigation matters. Under the terms of the settlement agreement, we agreed to pay Juniper a one-time settlement amount of approximately $175,000,000, which was comprised of $75,000,000 in cash, 1,081,000 shares of our common stock with an approximate value of $70,000,000, and a warrant to purchase 463,000 shares of our common stock with an approximate value of $30,000,000, in exchange for the following:

[0001327567-15-000008:notes:97]
| • | Mutual dismissal with prejudice of all pending litigation between the parties and general release of all liability for Palo Alto Networks and Juniper, |

[0001327567-15-000008:notes:98]
| • | Cross-license between both parties for the patents-in-suit and associated family members and counterparts worldwide for the life of the patents, and |

[0001327567-15-000008:notes:99]
| • | Mutual covenant not to sue for infringement of any other patents for a period of eight years. |

[0001327567-15-000008:notes:100]
For accounting purposes, the fair value of the total consideration as of the settlement date was $182,473,000, which was comprised of $75,000,000 in cash, $75,231,000 in common stock, and $32,242,000 in warrant. The fair values of the common stock and warrant were measured using the closing price of our common stock on the settlement date.

[0001327567-15-000008:notes:101]
The warrant was issued on June 3, 2014 and entitled Juniper to purchase up to 463,000 shares of common stock at an exercise price of $0.0001 per share and was classified as a liability during the period it was outstanding. On July 1, 2014, Juniper exercised the warrant in full. Accordingly, we recorded the change in the fair value of the warrant liability through the exercise date of $5,859,000 within other income (expense), net in our consolidated statement of operations during the three months ended July 31, 2014.

[0001327567-15-000008:notes:102]
We accounted for the settlement agreement as a multiple-element arrangement and allocated the fair value of the consideration as of the settlement date to the identifiable elements based on their estimated fair values. Of the total settlement amount, $61,300,000 was allocated to the licensing of intellectual property, $54,300,000 was allocated to the mutual dismissal of claims, and the remaining amount was allocated to the mutual covenant not to sue. The mutual dismissal of claims and the mutual covenant not to sue have no identifiable future benefit, and as a result we recorded a settlement charge within legal settlement expense in our condensed consolidated statement of operations during the three months ended April 30, 2014. The licensing of intellectual property is being amortized over the estimated period of benefit of five years.


## us-gaap:OtherAssetsDisclosureTextBlock

[0001327567-15-000008:notes:103]
Other Financial Information

[0001327567-15-000008:notes:104]
The following table presents details of our other assets as of January 31, 2015 and July 31, 2014 (in thousands):

[0001327567-15-000008:notes:105]
|  | January 31, 2015 |  | July 31, 2014 |
| Intellectual property licenses | $ | 44,624 |  |  | $ | 46,997 |  |
| Deferred tax charge | 30,423 |  |  | — |  |
| Debt issuance costs | 11,330 |  |  | 12,332 |  |
| Other assets | 7,098 |  |  | 7,199 |  |
| Total other assets | $ | 93,475 |  |  | $ | 66,528 |  |

[0001327567-15-000008:notes:106]
In December 2014, we reorganized our corporate structure to more closely align with the global nature of our business. As a result, we recorded a deferred tax charge in other assets in our condensed consolidated balance sheets. This amount will be amortized on a straight-line basis over approximately six years as a component of provision for income taxes in our condensed consolidated statements of operations.
