# PANW MD&A — 0001327567-15-000008


## mdna

[0001327567-15-000008:mdna:1]
[same as prior period, unchanged from 0001327567-14-000043:mdna:1]

[0001327567-15-000008:mdna:2]
[same as prior period, unchanged from 0001327567-14-000043:mdna:2]

[0001327567-15-000008:mdna:3]
[same as prior period, unchanged from 0001327567-14-000043:mdna:3]

[0001327567-15-000008:mdna:4]
[same as prior period, unchanged from 0001327567-14-000043:mdna:4]

[0001327567-15-000008:mdna:5]
[same as prior period, unchanged from 0001327567-14-000043:mdna:5]

[0001327567-15-000008:mdna:6]
| • | Results of Operations. An analysis of our financial results comparing the three and six months ended January 31, 2015 to the three and six months ended January 31, 2014. |

[0001327567-15-000008:mdna:7]
[same as prior period, unchanged from 0001327567-14-000043:mdna:7]

[0001327567-15-000008:mdna:8]
| • | Contractual Obligations and Commitments. An overview of our contractual obligations, contingent liabilities, commitments, and off-balance sheet arrangements outstanding as of January 31, 2015, including expected payment schedule. |

[0001327567-15-000008:mdna:9]
[same as prior period, unchanged from 0001327567-14-000043:mdna:8]

[0001327567-15-000008:mdna:10]
[same as prior period, unchanged from 0001327567-14-000043:mdna:9]

[0001327567-15-000008:mdna:11]
[same as prior period, unchanged from 0001327567-14-000043:mdna:10]

[0001327567-15-000008:mdna:12]
[same as prior period, unchanged from 0001327567-14-000043:mdna:11]

[0001327567-15-000008:mdna:13]
[same as prior period, unchanged from 0001327567-14-000043:mdna:12]

[0001327567-15-000008:mdna:14]
[same as prior period, unchanged from 0001327567-14-000043:mdna:24]

[0001327567-15-000008:mdna:15]
We derive revenue from sales of our products and services, which together comprise our platform. Product revenue is generated from sales of our Next-Generation Firewall, which is available in hardware and virtualized form factors. Our Next-Generation Firewall incorporates our proprietary PAN-OS operating system, which provides a consistent set of capabilities across our entire product line. These capabilities include: application visibility and control (App-ID), user identification (User-ID), site-to-site virtual private network (VPN), remote access Secure Sockets Layer (SSL) VPN, and Quality-of-Service (QoS). Our products are designed for different performance requirements throughout an organization, ranging from the PA-200, which is designed for enterprise remote offices, to the PA-7050, which is designed for data centers and high-speed networks. The same firewall functionality that is delivered in our hardware appliances is also available in our VM-Series virtual firewalls, which secure virtualized and cloud-based computing environments. Multiple firewalls can jointly use our WildFire appliance, WF-500, which identifies, analyzes, and blocks known and unknown malware in a private cloud-based environment. Our platform can be centrally managed in both virtualized and hardware appliances across an organization with our Panorama product. In addition, our GlobalProtect appliance, GP-100, provides mobile device management, malware detection, and shares device state information to safely enable mobile devices for business use.

[0001327567-15-000008:mdna:16]
Services revenue is generated from sales of subscriptions and support and maintenance, which together provide us with a source of recurring services revenue. Our Threat Prevention, URL Filtering, GlobalProtect, and WildFire subscriptions provide our end-customers with real-time access to the latest antivirus, intrusion prevention, web filtering, and modern malware prevention capabilities across fixed and mobile devices. Our Advanced Endpoint Protection subscription protects against cyber attacks that exploit software vulnerabilities in Windows-based fixed and virtual endpoints through the use of its unique capability of stopping the underlying exploit techniques, and can prevent cyber attacks without relying on prior knowledge of the attack.

[0001327567-15-000008:mdna:17]
[same as prior period, unchanged from 0001327567-14-000043:mdna:17]

[0001327567-15-000008:mdna:18]
[same as prior period, unchanged from 0001327567-14-000043:mdna:18]

[0001327567-15-000008:mdna:19]
[same as prior period, unchanged from 0001327567-14-000043:mdna:19]

[0001327567-15-000008:mdna:20]
As of January 31, 2015, we had sold to more than 22,500 end-customers in over 130 countries. Our end-customers represent a broad range of industries including education, energy, financial services, government entities, healthcare, Internet and media, manufacturing, public sector, and telecommunications, and include some of the largest Fortune 100 and Global 2000 companies in the world. Also, during the six months ended January 31, 2015, our headcount increased by 361 to 2,083 employees.

[0001327567-15-000008:mdna:21]
For the second quarter of fiscal 2015 and 2014, revenues were $217.7 million and $141.1 million, respectively, representing year over year growth of 54.3%. All three components of our hybrid SaaS revenue model experienced year over year growth, led by revenue from subscription services, which grew 73.8% to $50.1 million, followed by support and maintenance services, which grew 65.3% to $52.0 million, and product, which grew 43.1% to $115.6 million. Revenue growth reflected rapid adoption of our Next-Generation Firewall and related support and maintenance, as well as increasing momentum in our subscription services business. We believe the growth was also driven by increased security spending by customers, as security continues to be a critical business imperative for every business in the world.

[0001327567-15-000008:mdna:22]
[same as prior period, unchanged from 0001327567-14-000043:mdna:22]

[0001327567-15-000008:mdna:23]
[same as prior period, unchanged from 0001327567-14-000043:mdna:23]

[0001327567-15-000008:mdna:24]
[same as prior period, unchanged from 0001327567-14-000043:mdna:32]

[0001327567-15-000008:mdna:25]
[same as prior period, unchanged from 0001327567-14-000043:mdna:25]

[0001327567-15-000008:mdna:26]
[same as prior period, unchanged from 0001327567-14-000043:mdna:26]

[0001327567-15-000008:mdna:27]
|  | January 31, 2015 |  | July 31, 2014 |
|  | (in thousands) |
| Total deferred revenue | $ | 535,843 |  |  | $ | 422,578 |  |
| Cash, cash equivalents, and investments | $ | 1,138,965 |  |  | $ | 974,382 |  |

[0001327567-15-000008:mdna:28]
|  | Three Months Ended January 31, |  | Six Months Ended January 31, |
|  | 2015 |  | 2014 |  | 2015 |  | 2014 |
|  | (dollars in thousands) |
| Total revenue | $ | 217,655 |  |  | $ | 141,068 |  |  | $ | 410,001 |  |  | $ | 269,248 |  |
| Year over year percentage increase | 54.3 | % |  | 46.2 | % |  | 52.3 | % |  | 47.6 | % |
| Gross margin percentage | 72.7 | % |  | 73.4 | % |  | 72.5 | % |  | 73.5 | % |
| Operating loss | $ | (38,516 | ) |  | $ | (37,156 | ) |  | $ | (62,279 | ) |  | $ | (44,167 | ) |
| Operating margin percentage | (17.7 | )% |  | (26.3 | )% |  | (15.2 | )% |  | (16.4 | )% |
| Billings (non-GAAP) | $ | 282,778 |  |  | $ | 186,703 |  |  | $ | 523,266 |  |  | $ | 344,609 |  |
| Cash flow provided by operating activities |  |  |  |  | $ | 151,754 |  |  | $ | 80,277 |  |
| Free cash flow (non-GAAP) |  |  |  |  | $ | 139,719 |  |  | $ | 54,794 |  |

[0001327567-15-000008:mdna:29]
[same as prior period, unchanged from 0001327567-14-000043:mdna:29]

[0001327567-15-000008:mdna:30]
[same as prior period, unchanged from 0001327567-14-000043:mdna:30]

[0001327567-15-000008:mdna:31]
[same as prior period, unchanged from 0001327567-14-000043:mdna:31]

[0001327567-15-000008:mdna:32]
[same as prior period, unchanged from 0001327567-14-000043:mdna:42]

[0001327567-15-000008:mdna:33]
|  | Six Months Ended January 31, |
|  | 2015 |  | 2014 |
|  | (in thousands) |
| Free cash flow (non-GAAP): |  |  |  |
| Cash flow provided by operating activities | $ | 151,754 |  |  | $ | 80,277 |  |
| Less: purchases of property, equipment, and other assets | 12,035 |  |  | 25,483 |  |
| Free cash flow (non-GAAP) | $ | 139,719 |  |  | $ | 54,794 |  |
| Net cash used in investing activities | $ | (487,388 | ) |  | $ | (149,662 | ) |
| Net cash provided by financing activities | $ | 24,805 |  |  | $ | 20,638 |  |

[0001327567-15-000008:mdna:34]
[same as prior period, unchanged from 0001327567-14-000043:mdna:34]

[0001327567-15-000008:mdna:35]
|  | Three Months Ended January 31, |  | Six Months Ended January 31, |
|  | 2015 |  | 2014 |  | 2015 |  | 2014 |
|  | (in thousands) |
| Billings (non-GAAP): |  |  |  |  |  |  |  |
| Total revenue | $ | 217,655 |  |  | $ | 141,068 |  |  | $ | 410,001 |  |  | $ | 269,248 |  |
| Add: change in total deferred revenue | 65,123 |  |  | 45,635 |  |  | 113,265 |  |  | 75,361 |  |
| Billings (non-GAAP) | $ | 282,778 |  |  | $ | 186,703 |  |  | $ | 523,266 |  |  | $ | 344,609 |  |

[0001327567-15-000008:mdna:36]
[same as prior period, unchanged from 0001327567-14-000043:mdna:36]

[0001327567-15-000008:mdna:37]
[same as prior period, unchanged from 0001327567-14-000043:mdna:37]

[0001327567-15-000008:mdna:38]
[same as prior period, unchanged from 0001327567-14-000043:mdna:38]

[0001327567-15-000008:mdna:39]
[same as prior period, unchanged from 0001327567-14-000043:mdna:39]

[0001327567-15-000008:mdna:40]
[same as prior period, unchanged from 0001327567-14-000043:mdna:40]

[0001327567-15-000008:mdna:41]
| • | Services Revenue. Services revenue is derived primarily from Threat Prevention, URL Filtering, WildFire, and GlobalProtect subscriptions and support and maintenance. In addition, in September 2014, we released Traps, our Advanced Endpoint Protection subscription. We anticipate billings (non-GAAP) from Traps will begin ramping in the second half of fiscal 2015 with a more meaningful revenue contribution in fiscal 2016. Our contractual subscription and support and maintenance terms are typically one year, with three to five year terms available. We recognize revenue from subscriptions and support and maintenance over the contractual service period. As a percentage of total revenue, we expect our services revenue to vary from quarter to quarter and increase over the long term as we introduce new subscriptions, renew existing services contracts, and expand our installed end-customer base. |

[0001327567-15-000008:mdna:42]
[same as prior period, unchanged from 0001327567-14-000043:mdna:54]

[0001327567-15-000008:mdna:43]
[same as prior period, unchanged from 0001327567-14-000043:mdna:43]

[0001327567-15-000008:mdna:44]
Our cost of revenue consists of cost of product revenue and cost of services revenue. Our cost of revenue includes costs paid to our third-party contract manufacturer and personnel costs, which consist of salaries, bonuses, and share-based compensation associated with our operations and global customer support organizations. Our cost of revenue also includes allocated costs, which consist of certain facilities, depreciation, benefits, recruiting, and information technology costs that we allocate based on headcount, and amortization of intangible assets.

[0001327567-15-000008:mdna:45]
[same as prior period, unchanged from 0001327567-14-000043:mdna:45]

[0001327567-15-000008:mdna:46]
| • | Cost of Services Revenue. Cost of services revenue includes personnel costs for our global customer support organization, amortization of acquired intangible assets, allocated costs, and URL filtering database service fees. We expect our cost of services revenue to increase as our installed end-customer base grows. |

[0001327567-15-000008:mdna:47]
[same as prior period, unchanged from 0001327567-14-000043:mdna:47]

[0001327567-15-000008:mdna:48]
[same as prior period, unchanged from 0001327567-14-000043:mdna:48]

[0001327567-15-000008:mdna:49]
[same as prior period, unchanged from 0001327567-14-000043:mdna:49]

[0001327567-15-000008:mdna:50]
Our operating expenses consist of research and development, sales and marketing, general and administrative, and legal settlement expense. Personnel costs are the most significant component of operating expenses and consist of salaries, benefits, bonuses, share-based compensation, and with regard to sales and marketing expense, sales commissions. We expect operating expenses to increase in absolute dollars, and decrease over the long term as a percentage of revenue as we continue to scale our business. As of January 31, 2015, we expect to recognize approximately $528.9 million of share-based compensation expense over a weighted-average period of approximately three years, excluding additional share-based compensation expense related to any future grants of share-based awards. Share-based compensation expense, net of forfeitures, is recognized on a straight-line basis over the requisite service periods of the awards.

[0001327567-15-000008:mdna:51]
[same as prior period, unchanged from 0001327567-14-000043:mdna:51]

[0001327567-15-000008:mdna:52]
[same as prior period, unchanged from 0001327567-14-000043:mdna:52]

[0001327567-15-000008:mdna:53]
[same as prior period, unchanged from 0001327567-14-000043:mdna:53]

[0001327567-15-000008:mdna:54]
| • | Legal Settlement. Legal settlement expense consists of the charge related to the Mutual Covenant Not to Sue and Release Agreement with Fortinet, Inc. (“Fortinet”) in the second quarter of fiscal 2014. |

[0001327567-15-000008:mdna:55]
[same as prior period, unchanged from 0001327567-14-000043:mdna:64]

[0001327567-15-000008:mdna:56]
[same as prior period, unchanged from 0001327567-14-000043:mdna:55]

[0001327567-15-000008:mdna:57]
Interest expense consists of the amortization of the debt discount and debt issuance costs related to our 0.0% convertible senior notes due 2019 (the “Notes”). This interest expense is non-cash and will range from $22.3 million to $25.7 million per year through fiscal 2019.

[0001327567-15-000008:mdna:58]
[same as prior period, unchanged from 0001327567-14-000043:mdna:57]

[0001327567-15-000008:mdna:59]
[same as prior period, unchanged from 0001327567-14-000043:mdna:58]

[0001327567-15-000008:mdna:60]
Provision for (Benefit from) Income Taxes

[0001327567-15-000008:mdna:61]
Provision for (benefit from) income taxes consists primarily of income taxes in foreign jurisdictions in which we conduct business, withholding taxes, and federal and state income taxes in the United States. We maintain a full valuation allowance for domestic deferred tax assets, including net operating loss carryforwards and tax credits.

[0001327567-15-000008:mdna:62]
During the second quarter of fiscal 2015, we recorded a deferred tax charge of $36.7 million. The current portion of the deferred tax charge is included in prepaid expenses and other current assets and the remainder in other assets in our condensed consolidated balance sheets. The deferred tax charge will be amortized on a straight-line basis over approximately six years as a component of provision for income taxes.

[0001327567-15-000008:mdna:63]
[same as prior period, unchanged from 0001327567-14-000043:mdna:61]

[0001327567-15-000008:mdna:64]
[same as prior period, unchanged from 0001327567-14-000043:mdna:62]

[0001327567-15-000008:mdna:65]
|  | Three Months Ended January 31, |  | Six Months Ended January 31, |
|  | 2015 |  | 2014 |  | 2015 |  | 2014 |
|  | (dollars in thousands) |
| Condensed Consolidated Statements of Operations Data: |  |  |  |  |  |  |  |
| Revenue: |  |  |  |  |  |  |  |
| Product | $ | 115,621 |  |  | $ | 80,823 |  |  | $ | 217,097 |  |  | $ | 156,308 |  |
| Services | 102,034 |  |  | 60,245 |  |  | 192,904 |  |  | 112,940 |  |
| Total revenue | 217,655 |  |  | 141,068 |  |  | 410,001 |  |  | 269,248 |  |
| Cost of revenue: |  |  |  |  |  |  |  |
| Product | 30,640 |  |  | 20,221 |  |  | 59,781 |  |  | 38,175 |  |
| Services | 28,685 |  |  | 17,283 |  |  | 53,005 |  |  | 33,136 |  |
| Total cost of revenue | 59,325 |  |  | 37,504 |  |  | 112,786 |  |  | 71,311 |  |
| Total gross profit | 158,330 |  |  | 103,564 |  |  | 297,215 |  |  | 197,937 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 46,948 |  |  | 24,253 |  |  | 84,253 |  |  | 44,146 |  |
| Sales and marketing | 122,875 |  |  | 76,734 |  |  | 229,241 |  |  | 144,100 |  |
| General and administrative | 27,023 |  |  | 19,733 |  |  | 46,000 |  |  | 33,858 |  |
| Legal settlement | — |  |  | 20,000 |  |  | — |  |  | 20,000 |  |
| Total operating expenses | 196,846 |  |  | 140,720 |  |  | 359,494 |  |  | 242,104 |  |
| Operating loss | (38,516 | ) |  | (37,156 | ) |  | (62,279 | ) |  | (44,167 | ) |
| Interest expense | (5,539 | ) |  | (14 | ) |  | (11,028 | ) |  | (22 | ) |
| Other income (expense), net | 344 |  |  | (170 | ) |  | 685 |  |  | 235 |  |
| Loss before income taxes | (43,711 | ) |  | (37,340 | ) |  | (72,622 | ) |  | (43,954 | ) |
| Provision for (benefit from) income taxes | (703 | ) |  | 2,606 |  |  | 454 |  |  | 3,853 |  |
| Net loss | $ | (43,008 | ) |  | $ | (39,946 | ) |  | $ | (73,076 | ) |  | $ | (47,807 | ) |
| Number of employees at period end | 2,083 |  |  | 1,375 |  |  | 2,083 |  |  | 1,375 |  |

[0001327567-15-000008:mdna:66]
[same as prior period, unchanged from 0001327567-14-000043:mdna:69]

[0001327567-15-000008:mdna:67]
|  | Three Months Ended January 31, |  | Six Months Ended January 31, |
|  | 2015 |  | 2014 |  | 2015 |  | 2014 |
|  | (as a percentage of revenue) |
| Condensed Consolidated Statements of Operations Data: |  |  |  |  |  |  |  |
| Revenue: |  |  |  |  |  |  |  |
| Product | 53.1 | % |  | 57.3 | % |  | 53.0 | % |  | 58.1 | % |
| Services | 46.9 | % |  | 42.7 | % |  | 47.0 | % |  | 41.9 | % |
| Total revenue | 100.0 | % |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |
| Cost of revenue: |  |  |  |  |  |  |  |
| Product | 14.1 | % |  | 14.3 | % |  | 14.6 | % |  | 14.2 | % |
| Services | 13.2 | % |  | 12.3 | % |  | 12.9 | % |  | 12.3 | % |
| Total cost of revenue | 27.3 | % |  | 26.6 | % |  | 27.5 | % |  | 26.5 | % |
| Total gross profit | 72.7 | % |  | 73.4 | % |  | 72.5 | % |  | 73.5 | % |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 21.6 | % |  | 17.2 | % |  | 20.5 | % |  | 16.4 | % |
| Sales and marketing | 56.5 | % |  | 54.4 | % |  | 55.9 | % |  | 53.5 | % |
| General and administrative | 12.3 | % |  | 13.9 | % |  | 11.3 | % |  | 12.6 | % |
| Legal settlement | — | % |  | 14.2 | % |  | — | % |  | 7.4 | % |
| Total operating expenses | 90.4 | % |  | 99.7 | % |  | 87.7 | % |  | 89.9 | % |
| Operating loss | (17.7 | )% |  | (26.3 | )% |  | (15.2 | )% |  | (16.4 | )% |
| Interest expense | (2.5 | )% |  | — | % |  | (2.7 | )% |  | — | % |
| Other income (expense), net | 0.1 | % |  | (0.2 | )% |  | 0.2 | % |  | 0.1 | % |
| Loss before income taxes | (20.1 | )% |  | (26.5 | )% |  | (17.7 | )% |  | (16.3 | )% |
| Provision for (benefit from) income taxes | (0.3 | )% |  | 1.8 | % |  | 0.1 | % |  | 1.4 | % |
| Net loss | (19.8 | )% |  | (28.3 | )% |  | (17.8 | )% |  | (17.7 | )% |

[0001327567-15-000008:mdna:68]
[same as prior period, unchanged from 0001327567-14-000043:mdna:78]

[0001327567-15-000008:mdna:69]
Comparison of the Three and Six Month Periods Ended January 31, 2015 and 2014

[0001327567-15-000008:mdna:70]
[same as prior period, unchanged from 0001327567-14-000043:mdna:67]

[0001327567-15-000008:mdna:71]
|  | Three Months Ended January 31, |  |  |  |  |  | Six Months Ended January 31, |  |  |  |  |
|  | 2015 |  | 2014 |  | Change |  | 2015 |  | 2014 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in thousands) |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 115,621 |  |  | $ | 80,823 |  |  | $ | 34,798 |  |  | 43.1 | % |  | $ | 217,097 |  |  | $ | 156,308 |  |  | $ | 60,789 |  |  | 38.9 | % |
| Services |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Subscription | 50,076 |  |  | 28,818 |  |  | 21,258 |  |  | 73.8 | % |  | 93,774 |  |  | 53,614 |  |  | 40,160 |  |  | 74.9 | % |
| Support and maintenance | 51,958 |  |  | 31,427 |  |  | 20,531 |  |  | 65.3 | % |  | 99,130 |  |  | 59,326 |  |  | 39,804 |  |  | 67.1 | % |
| Total services | 102,034 |  |  | 60,245 |  |  | 41,789 |  |  | 69.4 | % |  | 192,904 |  |  | 112,940 |  |  | 79,964 |  |  | 70.8 | % |
| Total revenue | $ | 217,655 |  |  | $ | 141,068 |  |  | $ | 76,587 |  |  | 54.3 | % |  | $ | 410,001 |  |  | $ | 269,248 |  |  | $ | 140,753 |  |  | 52.3 | % |
| Revenue by geographic theater: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 147,080 |  |  | $ | 90,869 |  |  | $ | 56,211 |  |  | 61.9 | % |  | $ | 278,935 |  |  | $ | 177,035 |  |  | $ | 101,900 |  |  | 57.6 | % |
| EMEA | 44,820 |  |  | 33,098 |  |  | 11,722 |  |  | 35.4 | % |  | 83,304 |  |  | 56,973 |  |  | 26,331 |  |  | 46.2 | % |
| APAC | 25,755 |  |  | 17,101 |  |  | 8,654 |  |  | 50.6 | % |  | 47,762 |  |  | 35,240 |  |  | 12,522 |  |  | 35.5 | % |
| Total revenue | $ | 217,655 |  |  | $ | 141,068 |  |  | $ | 76,587 |  |  | 54.3 | % |  | $ | 410,001 |  |  | $ | 269,248 |  |  | $ | 140,753 |  |  | 52.3 | % |

[0001327567-15-000008:mdna:72]
Product revenue increased $34.8 million, or 43.1%, for the three months ended January 31, 2015 compared to the three months ended January 31, 2014. Product revenue increased $60.8 million, or 38.9%, for the six months ended January 31, 2015 compared to the six months ended January 31, 2014. The increase in both periods was driven by increased demand, including broader adoption of our newly introduced PA-7050 firewall. The impact of changes in pricing on our product revenue was insignificant.

[0001327567-15-000008:mdna:73]
Services revenue increased $41.8 million, or 69.4%, for the three months ended January 31, 2015 compared to the three months ended January 31, 2014. The increase was driven by a 73.8% increase in our subscription revenue and a 65.3% increase in our support and maintenance revenue due to increased sales to new and existing end-customers. Services revenue increased $80.0 million, or 70.8%, for the six months ended January 31, 2015 compared to the six months ended January 31, 2014. The increase was driven by a 74.9% increase in our subscription revenue and a 67.1% increase in our support and maintenance revenue due to increased sales to new and existing end-customers. The relative increases in subscription and support and maintenance revenue will fluctuate over time, depending on the mix of services revenue and the introduction of new subscription offerings. The impact of changes in pricing on our services revenue was insignificant.

[0001327567-15-000008:mdna:74]
With respect to geographic theaters, the Americas contributed the largest portion of the increase in revenue for the three and six months ended January 31, 2015 compared to the three and six months ended January 31, 2014 due to its larger and more established sales force compared to our other theaters. Revenue from both EMEA and APAC increased for the three and six months ended January 31, 2015 compared to the three and six months ended January 31, 2014 due to our investment in increasing the size of our sales force and number of channel partners in these theaters.

[0001327567-15-000008:mdna:75]
[same as prior period, unchanged from 0001327567-14-000043:mdna:90]

[0001327567-15-000008:mdna:76]
[same as prior period, unchanged from 0001327567-14-000043:mdna:73]

[0001327567-15-000008:mdna:77]
|  | Three Months Ended January 31, |  | Six Months Ended January 31, |
|  | 2015 |  | 2014 |  | 2015 |  | 2014 |
|  | Amount |  | Gross Margin |  | Amount |  | Gross Margin |  | Amount |  | Gross Margin |  | Amount |  | Gross Margin |
|  | (dollars in thousands) |
| Cost of revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 30,640 |  |  |  |  | $ | 20,221 |  |  |  |  | $ | 59,781 |  |  |  |  | $ | 38,175 |  |  |  |
| Services | 28,685 |  |  |  |  | 17,283 |  |  |  |  | 53,005 |  |  |  |  | 33,136 |  |  |  |
| Total cost of revenue | $ | 59,325 |  |  |  |  | $ | 37,504 |  |  |  |  | $ | 112,786 |  |  |  |  | $ | 71,311 |  |  |  |
| Includes share-based compensation of: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 955 |  |  |  |  | $ | 320 |  |  |  |  | $ | 1,704 |  |  |  |  | $ | 584 |  |  |  |
| Services | 5,140 |  |  |  |  | 2,085 |  |  |  |  | 8,635 |  |  |  |  | 3,571 |  |  |  |
| Total | $ | 6,095 |  |  |  |  | $ | 2,405 |  |  |  |  | $ | 10,339 |  |  |  |  | $ | 4,155 |  |  |  |
| Gross profit: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 84,981 |  |  | 73.5 | % |  | $ | 60,602 |  |  | 75.0 | % |  | $ | 157,316 |  |  | 72.5 | % |  | $ | 118,133 |  |  | 75.6 | % |
| Services | 73,349 |  |  | 71.9 | % |  | 42,962 |  |  | 71.3 | % |  | 139,899 |  |  | 72.5 | % |  | 79,804 |  |  | 70.7 | % |
| Total gross profit | $ | 158,330 |  |  | 72.7 | % |  | $ | 103,564 |  |  | 73.4 | % |  | $ | 297,215 |  |  | 72.5 | % |  | $ | 197,937 |  |  | 73.5 | % |

[0001327567-15-000008:mdna:78]
Product cost increased $10.4 million, or 51.5%, for the three months ended January 31, 2015 compared to the three months ended January 31, 2014 due to an increase in product unit volume, as well as amortization of intellectual property licenses of $3.1 million.

[0001327567-15-000008:mdna:79]
Product cost increased $21.6 million, or 56.6%, for the six months ended January 31, 2015 compared to the six months ended January 31, 2014 due to an increase in product unit volume, as well as amortization of intellectual property licenses of $6.1 million.

[0001327567-15-000008:mdna:80]
Services cost increased $11.4 million, or 66.0%, for the three months ended January 31, 2015 compared to the three months ended January 31, 2014 due to an increase in personnel costs of $6.6 million related to increasing our headcount, amortization of acquired intangible assets of $1.5 million, allocated costs of $1.0 million, and other costs incurred to expand our customer service capabilities to support our growing installed end-customer base.

[0001327567-15-000008:mdna:81]
Services cost increased $19.9 million, or 60.0%, for the six months ended January 31, 2015 compared to the six months ended January 31, 2014 due to an increase in personnel costs of $10.8 million related to increasing our headcount, amortization of acquired intangible assets of $2.8 million, allocated costs of $2.1 million, and other costs incurred to expand our customer service capabilities to support our growing installed end-customer base.

[0001327567-15-000008:mdna:82]
Gross margin decreased 70 basis points for the three months ended January 31, 2015 compared to the three months ended January 31, 2014. The decrease of 150 basis points in product margin was driven by a decrease of 270 basis points due to amortization of intellectual property licenses of $3.1 million, partially offset by material cost reductions. The increase of 60 basis points in services margin was due to contributions from our higher margin subscription services, partially offset by a 150 basis points decrease due to amortization of purchased intangible assets.

[0001327567-15-000008:mdna:83]
Gross margin decreased 100 basis points for the six months ended January 31, 2015 compared to the six months ended January 31, 2014. The decrease of 310 basis points in product margin was due to amortization of intellectual property licenses of $6.1 million. The increase of 180 basis points in services margin was due to contributions from our higher margin subscription services, partially offset by a 150 basis points decrease due to amortization of purchased intangible assets.

[0001327567-15-000008:mdna:84]
[same as prior period, unchanged from 0001327567-14-000043:mdna:102]

[0001327567-15-000008:mdna:85]
[same as prior period, unchanged from 0001327567-14-000043:mdna:79]

[0001327567-15-000008:mdna:86]
|  | Three Months Ended January 31, |  |  |  |  |  | Six Months Ended January 31, |  |  |  |  |
|  | 2015 |  | 2014 |  | Change |  | 2015 |  | 2014 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in thousands) |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | $ | 46,948 |  |  | $ | 24,253 |  |  | $ | 22,695 |  |  | 93.6 | % |  | $ | 84,253 |  |  | $ | 44,146 |  |  | $ | 40,107 |  |  | 90.9 | % |
| Sales and marketing | 122,875 |  |  | 76,734 |  |  | 46,141 |  |  | 60.1 | % |  | 229,241 |  |  | 144,100 |  |  | 85,141 |  |  | 59.1 | % |
| General and administrative | 27,023 |  |  | 19,733 |  |  | 7,290 |  |  | 36.9 | % |  | 46,000 |  |  | 33,858 |  |  | 12,142 |  |  | 35.9 | % |
| Legal settlement | — |  |  | 20,000 |  |  | (20,000 | ) |  | (100.0 | )% |  | — |  |  | 20,000 |  |  | (20,000 | ) |  | (100.0 | )% |
| Total operating expenses | $ | 196,846 |  |  | $ | 140,720 |  |  | $ | 56,126 |  |  | 39.9 | % |  | $ | 359,494 |  |  | $ | 242,104 |  |  | $ | 117,390 |  |  | 48.5 | % |
| Includes share-based compensation of: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | $ | 18,990 |  |  | $ | 5,807 |  |  | $ | 13,183 |  |  | 227.0 | % |  | $ | 32,989 |  |  | $ | 9,159 |  |  | $ | 23,830 |  |  | 260.2 | % |
| Sales and marketing | 21,727 |  |  | 9,745 |  |  | 11,982 |  |  | 123.0 | % |  | 37,526 |  |  | 16,678 |  |  | 20,848 |  |  | 125.0 | % |
| General and administrative | 10,069 |  |  | 6,427 |  |  | 3,642 |  |  | 56.7 | % |  | 14,502 |  |  | 8,803 |  |  | 5,699 |  |  | 64.7 | % |
| Total | $ | 50,786 |  |  | $ | 21,979 |  |  | $ | 28,807 |  |  | 131.1 | % |  | $ | 85,017 |  |  | $ | 34,640 |  |  | $ | 50,377 |  |  | 145.4 | % |

[0001327567-15-000008:mdna:87]
Research and development expense increased $22.7 million, or 93.6%, for the three months ended January 31, 2015 compared to the three months ended January 31, 2014, due to an increase in personnel costs of $20.4 million, largely due to an increase in headcount, and an increase in allocated costs of $1.4 million.

[0001327567-15-000008:mdna:88]
Research and development expense increased $40.1 million, or 90.9%, for the six months ended January 31, 2015 compared to the six months ended January 31, 2014, due to an increase in personnel costs of $36.0 million, largely due to an increase in headcount, and an increase in allocated costs of $2.6 million.

[0001327567-15-000008:mdna:89]
Sales and marketing expense increased $46.1 million, or 60.1%, for the three months ended January 31, 2015 compared to the three months ended January 31, 2014, due to an increase in personnel costs of $35.4 million, largely due to an increase in headcount, an increase in demand generation activities, trade shows, and other marketing activities of $3.0 million, an increase in allocated costs of $3.0 million, and an increase in travel and entertainment costs of $2.0 million.

[0001327567-15-000008:mdna:90]
Sales and marketing expense increased $85.1 million, or 59.1%, for the six months ended January 31, 2015 compared to the six months ended January 31, 2014, due to an increase in personnel costs of $59.0 million, largely due to an increase in headcount, an increase in demand generation activities, trade shows, and other marketing activities of $7.8 million, an increase in allocated costs of $6.4 million, and an increase in travel and entertainment costs of $5.2 million.

[0001327567-15-000008:mdna:91]
General and administrative expense increased $7.3 million, or 36.9%, for the three months ended January 31, 2015 compared to the three months ended January 31, 2014, due to an increase in personnel costs of $6.6 million, largely due to an increase in headcount.

[0001327567-15-000008:mdna:92]
General and administrative expense increased $12.1 million, or 35.9%, for the six months ended January 31, 2015 compared to the six months ended January 31, 2014, due to an increase in personnel costs of $10.3 million, largely due to an increase in headcount.

[0001327567-15-000008:mdna:93]
Legal settlement expense decreased $20.0 million for the three and six months ended January 31, 2015 compared to the three and six months ended January 31, 2014, due to the recognition of an expense of $20.0 million for the Mutual Covenant Not to Sue and Release Agreement with Fortinet in the three months ended January 31, 2014.

[0001327567-15-000008:mdna:94]
[same as prior period, unchanged from 0001327567-14-000043:mdna:119]

[0001327567-15-000008:mdna:95]
[same as prior period, unchanged from 0001327567-14-000043:mdna:84]

[0001327567-15-000008:mdna:96]
|  | Three Months Ended January 31, |  |  |  |  |  | Six Months Ended January 31, |  |  |  |  |
|  | 2015 |  | 2014 |  | Change |  | 2015 |  | 2014 |  | Change |
|  | Amount |  | Amount |  | Amount |  | % |  | Amount |  | Amount |  | Amount |  | % |
|  | (dollars in thousands) |
| Interest expense | $ | 5,539 |  |  | $ | 14 |  |  | $ | 5,525 |  |  | NM |  | $ | 11,028 |  |  | $ | 22 |  |  | $ | 11,006 |  |  | NM |

[0001327567-15-000008:mdna:97]
Interest expense increased $5.5 million and $11.0 million for the three and six months ended January 31, 2015 compared to the three and six months ended January 31, 2014, respectively, due to the amortization of the debt discount and debt issuance costs related to the Notes. This interest expense is non-cash and will range from $22.3 million to $25.7 million per year through fiscal 2019.

[0001327567-15-000008:mdna:98]
Provision for (Benefit from) Income Taxes

[0001327567-15-000008:mdna:99]
|  | Three Months Ended January 31, |  | Six Months Ended January 31, |
|  | 2015 |  | 2014 |  | 2015 |  | 2014 |
|  | (dollars in thousands) |
| Provision for (benefit from) income taxes | $ | (703 | ) |  | $ | 2,606 |  |  | $ | 454 |  |  | $ | 3,853 |  |
| Effective tax rate | 1.6 | % |  | (7.0 | )% |  | (0.6 | )% |  | (8.8 | )% |

[0001327567-15-000008:mdna:100]
We recorded an income tax benefit and an income tax provision for the three and six months ended January 31, 2015, respectively, due to federal, state, and foreign income taxes and foreign withholding taxes. The provision for income taxes varied for the three and six months ended January 31, 2015 compared to the three and six months ended January 31, 2014 due to a shift in geographical mix of income due to global expansion and tax benefits on certain foreign income.

[0001327567-15-000008:mdna:101]
[same as prior period, unchanged from 0001327567-14-000043:mdna:92]

[0001327567-15-000008:mdna:102]
|  | January 31, 2015 |  | July 31, 2014 |
|  | (in thousands) |
| Working capital | $ | 446,430 |  |  | $ | 610,155 |  |
| Cash, cash equivalents, and investments: |  |  |  |
| Cash and cash equivalents | $ | 342,983 |  |  | $ | 653,812 |  |
| Investments | 795,982 |  |  | 320,570 |  |
| Total cash, cash equivalents, and investments | $ | 1,138,965 |  |  | $ | 974,382 |  |

[0001327567-15-000008:mdna:103]
At January 31, 2015, our cash, cash equivalents, and investments of $1.1 billion were held for general corporate purposes, of which approximately $177.5 million was held outside the United States. Our current plans do not include repatriating these funds. However, if these funds were needed for our domestic operations, we would be required to accrue and pay U.S. taxes on undistributed earnings of foreign subsidiaries. There are no other restrictions on the use of these funds. We do not provide for federal income taxes on the undistributed earnings of our foreign subsidiaries, all of which we expect to reinvest outside of the United States indefinitely. If we were to repatriate these earnings to the United States, any associated income tax liability would be insignificant.

[0001327567-15-000008:mdna:104]
In June 2014, we issued the Notes with an aggregate principal amount of $575.0 million. The Notes will mature on July 1, 2019. Prior to January 1, 2019, holders may surrender their Notes for early conversion under certain circumstances. Upon conversion of the Notes, we will pay cash up to the aggregate principal amount of the Notes to be converted and we may choose to pay or deliver, as the case may be, cash, shares of our common stock or a combination of cash and shares of our common stock with respect to the remainder of our conversion obligation in excess of the aggregate principal amount of the Notes being converted. As of January 31, 2015, the Notes were not convertible. Refer to Note 6. Convertible Senior Notes of Notes to Condensed Consolidated Financial Statements included in Part I, Item 1 of this Quarterly Report on Form 10-Q for information on the Notes.

[0001327567-15-000008:mdna:105]
The following table summarizes our cash flows for the six months ended January 31, 2015 and 2014.

[0001327567-15-000008:mdna:106]
- 27 -

[0001327567-15-000008:mdna:107]
|  | Six Months Ended January 31, |
| 2015 |  | 2014 |
|  | (in thousands) |
| Cash provided by operating activities | $ | 151,754 |  |  | $ | 80,277 |  |
| Cash used in investing activities | (487,388 | ) |  | (149,662 | ) |
| Cash provided by financing activities | 24,805 |  |  | 20,638 |  |
| Net decrease in cash and cash equivalents | $ | (310,829 | ) |  | $ | (48,747 | ) |

[0001327567-15-000008:mdna:108]
We believe that our cash flow from operations with existing cash and cash equivalents will be sufficient to meet our anticipated cash needs for the foreseeable future. Our future capital requirements will depend on many factors including our growth rate, the timing and extent of spending to support development efforts, the expansion of sales and marketing activities, the introduction of new and enhanced products and services offerings, the costs to acquire or invest in complementary businesses and technologies, the costs to ensure access to adequate manufacturing capacity, and the continuing market acceptance of our products. In addition, from time to time we may incur additional tax liability in connection with certain tax structuring decisions.

[0001327567-15-000008:mdna:109]
[same as prior period, unchanged from 0001327567-14-000043:mdna:99]

[0001327567-15-000008:mdna:110]
[same as prior period, unchanged from 0001327567-14-000043:mdna:100]

[0001327567-15-000008:mdna:111]
[same as prior period, unchanged from 0001327567-14-000043:mdna:101]

[0001327567-15-000008:mdna:112]
Cash provided by operating activities during the six months ended January 31, 2015 was $151.8 million, an increase of $71.5 million compared to the six months ended January 31, 2014. The increase was due to growth of our business and changes in our assets and liabilities during the six months ended January 31, 2015.

[0001327567-15-000008:mdna:113]
Changes in assets and liabilities during the six months ended January 31, 2015 compared to the six months ended January 31, 2014 include an increase in sales of subscriptions and support and maintenance contracts to new and existing customers as reflected by an increase in deferred revenue. In addition, during the second quarter of fiscal 2015, we made a tax payment of $12.8 million in connection with an intercompany transfer of intellectual property.

[0001327567-15-000008:mdna:114]
[same as prior period, unchanged from 0001327567-14-000043:mdna:104]

[0001327567-15-000008:mdna:115]
[same as prior period, unchanged from 0001327567-14-000043:mdna:105]

[0001327567-15-000008:mdna:116]
Cash used in investing activities during the six months ended January 31, 2015 was $487.4 million, an increase of $337.7 million as compared to the six months ended January 31, 2014. The increase was due to higher net purchases of available-for-sale investments during the six months ended January 31, 2015.

[0001327567-15-000008:mdna:117]
[same as prior period, unchanged from 0001327567-14-000043:mdna:107]

[0001327567-15-000008:mdna:118]
[same as prior period, unchanged from 0001327567-14-000043:mdna:108]

[0001327567-15-000008:mdna:119]
Cash provided by financing activities during the six months ended January 31, 2015 was $24.8 million, an increase of $4.2 million as compared to the six months ended January 31, 2014. The increase was due to higher proceeds from the sale of shares through employee equity incentive plans during the six months ended January 31, 2015.

[0001327567-15-000008:mdna:120]
- 28 -

[0001327567-15-000008:mdna:121]
Contractual Obligations and Commitments

[0001327567-15-000008:mdna:122]
The following summarizes our contractual obligations and commitments as of January 31, 2015:

[0001327567-15-000008:mdna:123]
|  | Payments Due by Period |
|  | Total |  | Less Than 1 Year |  | 1 - 3 Years |  | 3- 5 Years |  | More Than 5 Years |
|  |  |  | (in thousands) |  |  |
| 0.0% convertible senior notes due 2019 | $ | 575,000 |  |  | $ | — |  |  | $ | — |  |  | $ | 575,000 |  |  | $ | — |  |
| Operating lease obligations(1) (2) | 107,678 |  |  | 16,966 |  |  | 31,569 |  |  | 21,540 |  |  | 37,603 |  |
| Purchase obligations(3) | 38,893 |  |  | 38,893 |  |  | — |  |  | — |  |  | — |  |
| Total(4) | $ | 721,571 |  |  | $ | 55,859 |  |  | $ | 31,569 |  |  | $ | 596,540 |  |  | $ | 37,603 |  |

[0001327567-15-000008:mdna:124]
______________

[0001327567-15-000008:mdna:125]
| (1) | Consists of contractual obligations from non-cancelable office space under operating leases. |

[0001327567-15-000008:mdna:126]
| (2) | Excludes proceeds from contractual sublease of $9.7 million, which consists of $3.1 million to be received in less than one year, $6.1 million to be received in one to three years, $0.5 million to be received in three to five years, and nil to be received in more than five years. |

[0001327567-15-000008:mdna:127]
| (3) | Consists of minimum purchase commitments of products and components with our independent contract manufacturer and original design manufacturers. Obligations under contracts that we can cancel without a significant penalty are not included in the table above. |

[0001327567-15-000008:mdna:128]
| (4) | No amounts related to Financial Accounting Standards Board (FASB) Accounting Standard Codification Topic 740-10, Income Taxes, are included. As of January 31, 2015, we had approximately $36.4 million of tax liabilities recorded related to uncertainty in income tax positions. |

[0001327567-15-000008:mdna:129]
[same as prior period, unchanged from 0001327567-14-000043:mdna:110]

[0001327567-15-000008:mdna:130]
Through January 31, 2015, we did not have any relationships with unconsolidated organizations or financial partnerships, such as structured finance or special purpose entities, that would have been established for the purpose of facilitating off-balance sheet arrangements or other contractually narrow or limited purposes.

[0001327567-15-000008:mdna:131]
[same as prior period, unchanged from 0001327567-14-000043:mdna:112]

[0001327567-15-000008:mdna:132]
[same as prior period, unchanged from 0001327567-14-000043:mdna:113]

[0001327567-15-000008:mdna:133]
[same as prior period, unchanged from 0001327567-14-000043:mdna:114]

[0001327567-15-000008:mdna:134]
[same as prior period, unchanged from 0001327567-14-000043:mdna:115]

[0001327567-15-000008:mdna:135]
[same as prior period, unchanged from 0001327567-14-000043:mdna:116]

[0001327567-15-000008:mdna:136]
[same as prior period, unchanged from 0001327567-14-000043:mdna:117]

[0001327567-15-000008:mdna:137]
Our website is located at www.paloaltonetworks.com, and our investor relations website is located at http://investors.paloaltonetworks.com. Copies of Annual Reports on Form 10-K, Quarterly Reports on Form 10-Q, Current Reports on Form 8-K, and amendments to these reports filed or furnished pursuant to Section 13(a) or 15(d) of the Securities Exchange Act of

[0001327567-15-000008:mdna:138]
- 29 -

[0001327567-15-000008:mdna:139]
1934, as amended (the “Exchange Act”), are available, free of charge, on our investor relations website as soon as reasonably practicable after we file such material electronically with or furnish it to the SEC. The SEC also maintains a website that contains our SEC filings. The address of the site is www.sec.gov. Further, a copy of this Quarterly Report on Form 10-Q is located at the SEC's Public Reference Room at 100 F Street, NE, Washington, D.C. 20549. Information on the operation of the Public Reference Room can be obtained by calling the SEC at 1-800-SEC-0330.

[0001327567-15-000008:mdna:140]
[same as prior period, unchanged from 0001327567-14-000043:mdna:120]
