# UI 10-Q controls and the auditor's report


## item_4_controls

[0001628280-17-004928:item_4_controls:1]
Item 4. Controls and Procedures

[0001628280-17-004928:item_4_controls:2]
Evaluation of Disclosure Controls and Procedures

[0001628280-17-004928:item_4_controls:3]
Management, with the participation of the Company’s Chief Executive Officer and Chief Accounting Officer, evaluated the effectiveness of our disclosure controls and procedures as of March 31, 2017. The term “disclosure controls and procedures,” as defined in Rules 13a-15(e) and 15d-15(e) under the Securities Exchange Act of 1934, as amended (the “Exchange Act”), means controls and other procedures of a company that are designed to ensure that information required to be disclosed by a company in the reports that it files or submits under the Exchange Act is recorded, processed, summarized and reported, within the time periods specified in the SEC’s rules and forms. Disclosure controls and procedures include, without limitation, controls and procedures designed to ensure that information required to be disclosed by a company in the reports that it files or submits under the Exchange Act is accumulated and communicated to the company’s management, including its principal executive and principal financial officers, as appropriate to allow timely decisions regarding required disclosure. Management recognizes that any controls and procedures, no matter how well designed and operated, can provide only reasonable assurance of achieving their objectives. Based on the evaluation of our disclosure controls and procedures as of March 31, 2017, our Chief Executive Officer and Chief Accounting Officer concluded that, as of such date, our disclosure controls and procedures were not effective due to the fact that certain material weaknesses in our internal control over financial reporting previously identified and disclosed in our Item 9A of our Annual Report on Form 10-K, as filed with the SEC on August 22, 2016 (the “Annual Report”) continued to exist at March 31, 2017.

[0001628280-17-004928:item_4_controls:4]
Notwithstanding the ineffectiveness of the Company’s disclosure controls and procedures as of the end of the period covered by this Quarterly Report on Form 10-Q and the material weaknesses in our internal control over financial reporting that existed as of that date, management believes that (i) this Quarterly Report on Form 10-Q does not contain any untrue statement of a material fact or omit to state a material fact necessary to make the statements made, in light of the circumstances under which they were made, not misleading with respect to the period covered by this Quarterly Report on Form 10-Q and (ii) the unaudited Condensed consolidated financial statements, and other financial information, included in this Quarterly Report on Form 10-Q fairly present in all material respects in accordance with GAAP our financial condition, results of operations and cash flows as of, and for, the dates and periods presented.

[0001628280-17-004928:item_4_controls:5]
Remediation of Previously Disclosed Material Weakness

[0001628280-17-004928:item_4_controls:6]
We have taken actions to remediate the material weakness associated with the ineffectively designed and maintained controls over user access and transaction privileges to modify and post entries to the general ledger and subsidiary ledgers including (i) reviewed and updated user access and transaction privileges in the general ledger and interfacing subsidiary systems, (ii) implemented systematic and manual controls to monitor the effectiveness of user access and transaction privileges, (iii) enhanced the design of our periodic segregation of duties review, and (iv) developed and communicated policies designed to consider impacts to the general ledger when updating system configurations, including transaction privileges and segregation of duties. Based on these changes, in addition to testing performed, management believes that the material weakness related to user access and transaction privileges in the general ledger was remediated as of September 30, 2016, and as reported in our Form 10-Q for the quarterly period ended September 30, 2016.

[0001628280-17-004928:item_4_controls:7]
Status of Previously Disclosed Material Weaknesses

[0001628280-17-004928:item_4_controls:8]
We have taken certain remediation steps to address the material weaknesses referenced above that continue to remain as of March 31, 2017, including:

[0001628280-17-004928:item_4_controls:9]
27

[0001628280-17-004928:item_4_controls:10]
Regarding the lack of sufficient, competent personnel necessary for effective financial reporting, we recruited and transitioned the leadership team within the finance organization by adding additional qualified and experienced personnel. We have updated our accounting policies and procedures documentation together with key process level documents. In conjunction with the recruitment efforts, we have clarified roles and responsibilities within the finance organization.

[0001628280-17-004928:item_4_controls:11]
Regarding the ineffectively designed and maintained controls required for safeguarding of the Company’s funds and timely detection of improper transactions in the general ledger, we have implemented new policies and controls surrounding disbursement authorities and journal entry creation, including training on required supporting documentation.

[0001628280-17-004928:item_4_controls:12]
The above remediation efforts have been ongoing and were substantially completed as of March 31, 2017.  While we continue to progress with the testing of the newly implemented and redesigned controls, additional time is needed to support the operating effectiveness of such controls. Due to the nature of the remediation process and the need to allow adequate time after implementation to evaluate and test the effectiveness of the controls, no assurance can be given as to the timing of achievement of remediation.

[0001628280-17-004928:item_4_controls:13]
Changes in Internal Control over Financial Reporting

[0001628280-17-004928:item_4_controls:14]
During the first and second quarter of fiscal 2017 and continuing through the three months ended March 31, 2017, we have implemented (i) systematic and manual controls to monitor user access and transaction privileges and (ii) systematic controls over disbursements. There were no other changes in our internal control over financial reporting that occurred during the three months ended March 31, 2017 that materially affected, or that are reasonably likely to materially affect, our internal control over financial reporting.
