# UI MD&A — 0001628280-17-004928


## mdna

[0001628280-17-004928:mdna:1]
[same as prior period, unchanged from 0001511737-17-000003:mdna:1]

[0001628280-17-004928:mdna:2]
[same as prior period, unchanged from 0001511737-17-000003:mdna:2]

[0001628280-17-004928:mdna:3]
[same as prior period, unchanged from 0001511737-17-000003:mdna:3]

[0001628280-17-004928:mdna:4]
[same as prior period, unchanged from 0001511737-17-000003:mdna:4]

[0001628280-17-004928:mdna:5]
[same as prior period, unchanged from 0001511737-17-000003:mdna:5]

[0001628280-17-004928:mdna:6]
[same as prior period, unchanged from 0001511737-17-000003:mdna:6]

[0001628280-17-004928:mdna:7]
| • | Rapid customer and community driven product development. We have an active, loyal community built by our customers that we believe is a sustainable competitive advantage. Our solutions benefit from the active engagement |

[0001628280-17-004928:mdna:8]
between the Ubiquiti Community and our development engineers throughout the product development cycle, which eliminates long and expensive multistep internal processes and results in rapid introduction and adoption of our products. This approach significantly reduces our development costs and time to market.

[0001628280-17-004928:mdna:9]
[same as prior period, unchanged from 0001511737-17-000003:mdna:8]

[0001628280-17-004928:mdna:10]
[same as prior period, unchanged from 0001511737-17-000003:mdna:9]

[0001628280-17-004928:mdna:11]
[same as prior period, unchanged from 0001511737-17-000003:mdna:10]

[0001628280-17-004928:mdna:12]
[same as prior period, unchanged from 0001511737-17-000003:mdna:11]

[0001628280-17-004928:mdna:13]
[same as prior period, unchanged from 0001511737-17-000003:mdna:12]

[0001628280-17-004928:mdna:14]
[same as prior period, unchanged from 0001511737-17-000003:mdna:13]

[0001628280-17-004928:mdna:15]
[same as prior period, unchanged from 0001511737-17-000003:mdna:14]

[0001628280-17-004928:mdna:16]
[same as prior period, unchanged from 0001511737-17-000003:mdna:15]

[0001628280-17-004928:mdna:17]
[same as prior period, unchanged from 0001511737-17-000003:mdna:16]

[0001628280-17-004928:mdna:18]
We sell substantially all of our products through a limited number of distributors and other channel partners, such as resellers and Original Equipment Manufacturers (“OEMs”). Sales to distributors accounted for 99% of revenues during the three and nine months ended March 31, 2017.

[0001628280-17-004928:mdna:19]
[same as prior period, unchanged from 0001511737-17-000003:mdna:18]

[0001628280-17-004928:mdna:20]
[same as prior period, unchanged from 0001511737-17-000003:mdna:19]

[0001628280-17-004928:mdna:21]
In addition to utilizing contract manufacturers, we outsource most of our logistics warehousing and order fulfillment functions, which are located primarily in China, and to a lesser extent, Taiwan, Poland and the United States. We also evaluate and utilize other vendors for various portions of our supply chain from time to time. Our operations organization consists of employees and consultants engaged in the management of our contract manufacturers, new product introduction activities, logistical support and engineering.

[0001628280-17-004928:mdna:22]
[same as prior period, unchanged from 0001511737-17-000003:mdna:21]

[0001628280-17-004928:mdna:23]
[same as prior period, unchanged from 0001511737-17-000003:mdna:22]

[0001628280-17-004928:mdna:24]
[same as prior period, unchanged from 0001511737-17-000003:mdna:23]

[0001628280-17-004928:mdna:25]
[same as prior period, unchanged from 0001511737-17-000003:mdna:24]

[0001628280-17-004928:mdna:26]
| • | Research and development expenses consist primarily of salary and benefit expenses, including stock-based compensation, for employees and costs for contractors engaged in research, design and development activities, as well as costs for prototypes, purchased Intellectual Property (“IP”), non-recurring engineering milestones, facilities and travel. Over time, we expect our research and development costs to increase as we continue making significant investments in developing new products in addition to new versions of our existing products. |

[0001628280-17-004928:mdna:27]
[same as prior period, unchanged from 0001511737-17-000003:mdna:26]

[0001628280-17-004928:mdna:28]
[same as prior period, unchanged from 0001511737-17-000003:mdna:27]

[0001628280-17-004928:mdna:29]
[same as prior period, unchanged from 0001511737-17-000003:mdna:28]

[0001628280-17-004928:mdna:30]
Included in our deferred revenues is a portion related to PCS obligations that we estimate we will fulfill in the future. As of March 31, 2017 and June 30, 2016, we had deferred revenues of $7.3 million and $4.2 million, respectively, related to these obligations.

[0001628280-17-004928:mdna:31]
[same as prior period, unchanged from 0001511737-17-000003:mdna:30]

[0001628280-17-004928:mdna:32]
[same as prior period, unchanged from 0001511737-17-000003:mdna:31]

[0001628280-17-004928:mdna:33]
[same as prior period, unchanged from 0001511737-17-000003:mdna:33]

[0001628280-17-004928:mdna:34]
Comparison of Three and Nine Months Ended March 31, 2017 and 2016

[0001628280-17-004928:mdna:35]
|  | Three Months Ended March 31, |  | Nine Months Ended March 31, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
|  | (In thousands, except percentages) |
| Revenues | $ | 218,359 |  |  | 100 | % |  | $ | 167,433 |  |  | 100 | % |  | $ | 636,652 |  |  | 100 | % |  | $ | 480,719 |  |  | 100 | % |
| Cost of revenues(1) | 119,273 |  |  | 55 | % |  | 84,940 |  |  | 51 | % |  | 344,123 |  |  | 54 | % |  | 245,681 |  |  | 51 | % |
| Gross profit | 99,086 |  |  | 45 | % |  | 82,493 |  |  | 49 | % |  | 292,529 |  |  | 46 | % |  | 235,038 |  |  | 49 | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development(1) | 16,603 |  |  | 8 | % |  | 13,820 |  |  | 8 | % |  | 47,480 |  |  | 7 | % |  | 42,810 |  |  | 9 | % |
| Sales, general and administrative(1) | 9,074 |  |  | 4 | % |  | 8,538 |  |  | 5 | % |  | 26,938 |  |  | 4 | % |  | 24,113 |  |  | 5 | % |
| Business e-mail compromise (“BEC”) fraud loss/(recovery) | — |  |  | * |  |  | (3 | ) |  | * |  |  | — |  |  | * |  |  | (8,294 | ) |  | (2 | )% |
| Total operating expenses | 25,677 |  |  | 12 | % |  | 22,355 |  |  | 13 | % |  | 74,418 |  |  | 12 | % |  | 58,629 |  |  | 12 | % |
| Income from operations | 73,409 |  |  | 34 | % |  | 60,138 |  |  | 36 | % |  | 218,111 |  |  | 34 | % |  | 176,409 |  |  | 37 | % |
| Interest expense and other, net | (1,038 | ) |  | — | % |  | (510 | ) |  | * |  |  | (3,307 | ) |  | (1 | )% |  | (1,277 | ) |  | * |  |
| Income before provision for income taxes | 72,371 |  |  | 33 | % |  | 59,628 |  |  | 36 | % |  | 214,804 |  |  | 34 | % |  | 175,132 |  |  | 36 | % |
| Provision for income taxes (2) | 7,939 |  |  | 4 | % |  | 6,929 |  |  | 4 | % |  | 17,976 |  |  | 3 | % |  | 19,222 |  |  | 4 | % |
| Net income and comprehensive income | $ | 64,432 |  |  | 30 | % |  | $ | 52,699 |  |  | 31 | % |  | $ | 196,828 |  |  | 31 | % |  | $ | 155,910 |  |  | 32 | % |
| * Less than 1% |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| (1) Includes stock-based compensation as follows: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of revenues | $ | 39 |  |  |  |  | $ | 114 |  |  |  |  | $ | 213 |  |  |  |  | $ | 341 |  |  |  |
| Research and development | 421 |  |  |  |  | 566 |  |  |  |  | 1,362 |  |  |  |  | 1,770 |  |  |  |
| Sales, general and administrative | 141 |  |  |  |  | 202 |  |  |  |  | 519 |  |  |  |  | 755 |  |  |  |
| Total stock-based compensation | $ | 601 |  |  |  |  | $ | 882 |  |  |  |  | $ | 2,094 |  |  |  |  | $ | 2,866 |  |  |  |
| (2) Includes the excess tax benefits resulting from the adoption of ASU 2016-09 Stock Compensation | $ | (179 | ) |  |  |  | $ | — |  |  |  |  | $ | (7,859 | ) |  |  |  | $ | — |  |  |  |

[0001628280-17-004928:mdna:36]
[same as prior period, unchanged from 0001511737-17-000003:mdna:36]

[0001628280-17-004928:mdna:37]
Total revenues increased $51.0 million, or 30%, from $167.4 million in the three months ended March 31, 2016 to $218.4 million in the three months ended March 31, 2017. Total revenues increased $156.0 million, or 32% from $480.7 million in the nine months ended March 31, 2016 to $636.7 million in the nine months ended March 31, 2017.

[0001628280-17-004928:mdna:38]
The drivers of both increases are discussed in further detail below. During the three and nine months ended March 31, 2017, there were no material price changes in the Company's products sold.  During these periods there were changes in product mix, including a higher mix of Enterprise Technology products sold as compared to the three and nine months ended March 31, 2016.

[0001628280-17-004928:mdna:39]
[same as prior period, unchanged from 0001511737-17-000003:mdna:39]

[0001628280-17-004928:mdna:40]
|  | Three Months Ended March 31, |  | Nine Months Ended March 31, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
|  | (in thousands, except percentages) |
| Service provider Technology | $ | 104,724 |  |  | 48 | % |  | $ | 96,215 |  |  | 57 | % |  | $ | 340,936 |  |  | 54 | % |  | $ | 309,230 |  |  | 64 | % |
| Enterprise Technology | 113,635 |  |  | 52 | % |  | 71,218 |  |  | 43 | % |  | 295,716 |  |  | 46 | % |  | 171,489 |  |  | 36 | % |
| Total revenues | $ | 218,359 |  |  | 100 | % |  | $ | 167,433 |  |  | 100 | % |  | $ | 636,652 |  |  | 100 | % |  | $ | 480,719 |  |  | 100 | % |

[0001628280-17-004928:mdna:41]
Service Provider Technology revenue increased $8.5 million, or 9%, from $96.2 million in the three months ended March 31, 2016 to $104.7 million in the three months ended March 31, 2017. Service Provider Technology revenue

[0001628280-17-004928:mdna:42]
increased $31.7 million, or 10%, from $309.2 million in the nine months ended March 31, 2016 to $340.9 million in the nine months ended March 31, 2017.

[0001628280-17-004928:mdna:43]
The increase in Service Provider Technology revenue during the three months ended March 31, 2017 as compared to the same period in the prior year was primarily due to increased revenues in North America and South America and offset by a decline in Service Provider Technology revenues in Europe, the Middle East and Africa ("EMEA") and Asia Pacific. The increase in Service Provider Technology revenue during the nine months ended March 31, 2017 as compared to the same period in the prior year was primarily due to increased revenues for Service Provider Technology products in all regions except EMEA.

[0001628280-17-004928:mdna:44]
Enterprise Technology revenue increased $42.4 million, or 60%, from $71.2 million in the three months ended March 31, 2016 to $113.6 million in the three months ended March 31, 2017. Enterprise Technology revenue increased $124.2 million, or 72%, from $171.5 million in the nine months ended March 31, 2016 to $295.7 million in the nine months ended March 31, 2017. The increase in Enterprise Technology revenue during the three months ended March 31, 2017 as compared to the same period in the prior year was primarily due to product expansion and further adoption of our UniFi technology platform across all regions. Similarly, the increase in Enterprise Technology revenue during the nine months ended March 31, 2017 as compared to the same period in the prior year was primarily due to product expansion and further adoption of our UniFi technology platform across all regions.

[0001628280-17-004928:mdna:45]
[same as prior period, unchanged from 0001511737-17-000003:mdna:45]

[0001628280-17-004928:mdna:46]
We have determined the geographical distribution of our product revenues based on our customers’ ship-to destinations. A majority of our sales are to distributors who either sell to resellers or directly to end customers, who may be located in different countries than the initial ship-to destination.  The following are our revenues by geography for the three and nine months ended March 31, 2017 and 2016 (in thousands, except percentages):

[0001628280-17-004928:mdna:47]
|  | Three Months Ended March 31, |  | Nine Months Ended March 31, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| North America(1) | $ | 78,573 |  |  | 36 | % |  | $ | 57,791 |  |  | 35 | % |  | $ | 247,347 |  |  | 39 | % |  | $ | 168,428 |  |  | 35 | % |
| South America | 27,770 |  |  | 13 | % |  | 15,450 |  |  | 9 | % |  | 71,240 |  |  | 11 | % |  | 61,123 |  |  | 13 | % |
| Europe, the Middle East and Africa ("EMEA") | 87,780 |  |  | 40 | % |  | 73,269 |  |  | 44 | % |  | 246,536 |  |  | 39 | % |  | 194,745 |  |  | 40 | % |
| Asia Pacific | 24,236 |  |  | 11 | % |  | 20,923 |  |  | 12 | % |  | 71,529 |  |  | 11 | % |  | 56,423 |  |  | 12 | % |
| Total revenues | $ | 218,359 |  |  | 100 | % |  | $ | 167,433 |  |  | 100 | % |  | $ | 636,652 |  |  | 100 | % |  | $ | 480,719 |  |  | 100 | % |

[0001628280-17-004928:mdna:48]
| (1) | Revenue for the United States was $74.0 million and $54.6 million for the three months ended March 31, 2017 and 2016, respectively. Revenue for the United States was $234.8 million and $158.8 million for the nine months ended March 31, 2017 and 2016, respectively. |

[0001628280-17-004928:mdna:49]
[same as prior period, unchanged from 0001511737-17-000003:mdna:49]

[0001628280-17-004928:mdna:50]
Revenues in North America increased $20.8 million, or 36%, from $57.8 million in the three months ended March 31, 2016 to $78.6 million in the three months ended March 31, 2017.  Revenues increased $78.9 million, or 47%, from $168.4 million in the nine months ended March 31, 2016 to $247.3 million in the nine months ended March 31, 2017. The increase in North American revenues during both the three and nine months ended March 31, 2017 as compared to the same periods in the prior year was primarily due to increased revenue for both our Service Provider Technology products and Enterprise Technology products.

[0001628280-17-004928:mdna:51]
[same as prior period, unchanged from 0001511737-17-000003:mdna:51]

[0001628280-17-004928:mdna:52]
Revenues in South America increased $12.3 million, or 79%, from $15.5 million in the three months ended March 31, 2016 to $27.8 million in the three months ended March 31, 2017. Revenues increased $10.1 million, or 17%, from $61.1 million in the nine months ended March 31, 2016 to $71.2 million in the nine months ended March 31, 2017. The increase in South American revenues during the three and nine months ended March 31, 2017 as compared to the same periods in the prior year was primarily due to increased revenue for both our Service Provider Technology products and Enterprise Technology products.

[0001628280-17-004928:mdna:53]
[same as prior period, unchanged from 0001511737-17-000003:mdna:53]

[0001628280-17-004928:mdna:54]
Revenues in EMEA increased $14.5 million, or 20%, from $73.3 million in the three months ended March 31, 2016 to $87.8 million in the three months ended March 31, 2017. Revenues increased $51.8 million, or 27%, from $194.7 million in the nine months ended March 31, 2016 to $246.5 million in the nine months ended March 31, 2017. The increase in EMEA revenues during the three and nine months ended March 31, 2017 as compared to the same periods in the prior year was primarily due to increased revenues from Enterprise Technology products offset, in part, by a decline in revenues from Service Provider Technology products.

[0001628280-17-004928:mdna:55]
[same as prior period, unchanged from 0001511737-17-000003:mdna:55]

[0001628280-17-004928:mdna:56]
Revenues in the Asia Pacific region increased $3.3 million, or 16%, from $20.9 million in the three months ended March 31, 2016 to $24.2 million in the three months ended March 31, 2017. Revenues increased $15.1 million, or 27%, from $56.4 million in the nine months ended March 31, 2016 to $71.5 million in the nine months ended March 31, 2017. The increase in Asia Pacific revenues during the three and nine months ended March 31, 2017 as compared to the same periods in the prior year was primarily due to increased revenues from Enterprise Technology products offset, in part, by a decline in revenues from Service Provider Technology products.

[0001628280-17-004928:mdna:57]
[same as prior period, unchanged from 0001511737-17-000003:mdna:57]

[0001628280-17-004928:mdna:58]
Cost of revenues increased $34.4 million, or 41%, from $84.9 million in the three months ended March 31, 2016 to $119.3 million in the three months ended March 31, 2017.  Cost of revenues increased $98.4 million, or 40%, from $245.7 million in the nine months ended March 31, 2016 to $344.1 million in the nine months ended March 31, 2017. The increase during both the three and nine months ended March 31, 2017 was primarily due to our overall increase in revenues and to a lesser extent, an increased cost associated with fulfillment operations, warranty accruals and inventory reserves.

[0001628280-17-004928:mdna:59]
Gross profit margin decreased to 45% in the three months ended March 31, 2017 compared to 49% in the three months ended March 31, 2016 and decreased to 46% in the nine months ended March 31, 2017 compared to 49% in the nine months ended March 31, 2016. The decrease during both the three and nine months ended March 31, 2017 was primarily due to change in mix of products sold and to a lesser extent, an increase in shipping cost and warranty accruals.

[0001628280-17-004928:mdna:60]
[same as prior period, unchanged from 0001511737-17-000003:mdna:60]

[0001628280-17-004928:mdna:61]
[same as prior period, unchanged from 0001511737-17-000003:mdna:61]

[0001628280-17-004928:mdna:62]
Research and development (“R&D”) expenses increased $2.8 million, or 20%, from $13.8 million in the three months ended March 31, 2016 to $16.6 million in the three months ended March 31, 2017. As a percentage of revenues, research and development expenses remained flat at 8% for the three months ended March 31, 2016 and 2017. R&D expenses increased $4.7 million, or 11%, from $42.8 million in the nine months ended March 31, 2016 to $47.5 million in the nine months ended March 31, 2017. As a percentage of revenues, R&D expenses decreased from 9% in the nine months ended March 31, 2016 to 7% in the nine months ended March 31, 2017.

[0001628280-17-004928:mdna:63]
The increase in research and development expenses in absolute dollars during both the three and nine months ended March 31, 2017 was primarily due to increases in headcount and development activities and offset, in part, by the $2.5 million impairment charge for capitalized software development cost recognized in the nine months ended March 31, 2016. The increase in headcount and development cost reflects the increased efforts to broaden our research and development activities to introduce new products and new versions of existing products. As a percentage of revenues, R&D expenses decreased primarily due to our overall increase in revenues.

[0001628280-17-004928:mdna:64]
[same as prior period, unchanged from 0001511737-17-000003:mdna:64]

[0001628280-17-004928:mdna:65]
Sales, general and administrative expenses increased $0.6 million, or 7%, from $8.5 million in the three months ended March 31, 2016 to $9.1 million in the three months ended March 31, 2017.  As a percentage of revenues, sales, general and administrative expenses decreased from 5% in the three months ended March 31, 2016 to 4% in the three months ended March 31, 2017.  Sales, general and administrative expenses increased $2.8 million, or 12%, from $24.1 million in the nine months ended March 31, 2016 to $26.9 million in the nine months ended March 31, 2017. As a percentage of revenues, sales, general and administrative expenses decreased from 5% in the nine months ended March 31, 2016 to 4% in the nine months ended March 31, 2017.

[0001628280-17-004928:mdna:66]
Increases in sales, general and administrative expenses in absolute dollars during both the three and nine months ended March 31, 2017 as compared to the same period in the prior year are primarily due to an increase in headcount in the

[0001628280-17-004928:mdna:67]
[same as prior period, unchanged from 0001511737-17-000003:mdna:67]

[0001628280-17-004928:mdna:68]
[same as prior period, unchanged from 0001511737-17-000003:mdna:68]

[0001628280-17-004928:mdna:69]
Our provision for income taxes increased $1.0 million or 15%, from $6.9 million for the three months ended March 31, 2016 to $7.9 million for the three months ended March 31, 2017. Our effective tax rate decreased to 11.0% for the three months ended March 31, 2017 as compared to 11.6% for the three months ended March 31, 2016. The lower effective tax rate in the three months ended March 31, 2017 was primarily due to return-to-provision tax benefit, partially offset by taxes on increased sales in the U.S. Our provision for income taxes decreased $1.3 million, or 7%, from $19.2 million for the nine months ended March 31, 2016 to $17.9 million for the nine months ended March 31, 2017. Our effective tax rate decreased to 8.4% for the nine months ended March 31, 2017 as compared to 11.0% for the nine months ended March 31, 2016. The decrease in the nine months ended March 31, 2017 was primarily due to return-to-provision tax benefit of $0.7 million and the recognition of the excess tax benefits of $7.9 million as a result of the adoption of ASU 2016-09 partially offset by taxes on increased sales in the U.S. See Note 2 for information on the impact of the adoption of ASU 2016-09.

[0001628280-17-004928:mdna:70]
[same as prior period, unchanged from 0001511737-17-000003:mdna:70]

[0001628280-17-004928:mdna:71]
[same as prior period, unchanged from 0001511737-17-000003:mdna:71]

[0001628280-17-004928:mdna:72]
Since inception, our operations primarily have been funded through cash generated by operations and proceeds from our various debt agreements. Cash and cash equivalents decreased from $551.0 million at June 30, 2016 to $533.9 million at March 31, 2017.

[0001628280-17-004928:mdna:73]
[same as prior period, unchanged from 0001511737-17-000003:mdna:73]

[0001628280-17-004928:mdna:74]
[same as prior period, unchanged from 0001511737-17-000003:mdna:74]

[0001628280-17-004928:mdna:75]
|  | Nine Months Ended March 31, |
|  | 2017 |  | 2016 |
|  | (In thousands) |
| Net cash provided by operating activities | $ | 65,895 |  |  | $ | 151,944 |  |
| Net cash (used in) investing activities | (5,704 | ) |  | (4,820 | ) |
| Net cash (used in) provided by financing activities | (77,278 | ) |  | (90,976 | ) |
| Net increase (decrease) in cash and cash equivalents | $ | (17,087 | ) |  | $ | 56,148 |  |

[0001628280-17-004928:mdna:76]
[same as prior period, unchanged from 0001511737-17-000003:mdna:76]

[0001628280-17-004928:mdna:77]
Net cash provided by operating activities in the nine months ended March 31, 2017 of $65.9 million consisted primarily of net income of $196.8 million partially offset by changes in operating assets and liabilities that resulted in net cash outflows of $139.9 million. These changes consisted primarily of a $6.3 million increase in accounts payable and accrued liabilities due to the timing of payments, a $43.1 million increase in accounts receivable due to overall higher revenues for the period, a $18.4 million increase in vendor deposit and a $76.8 million increase in inventory due to increase in warehouse stock levels in order to better support customers and reduce lead times, a $3.8 million increase in prepaid expense and other assets primarily due to the increase of non-trade accounts receivable, a $10.6 million increase in prepaid income taxes and a $3.4 million increase in taxes payable due to the timing of federal tax payments. Overall, cash inflows from operating activities were driven by our net income for the period, which included non-cash adjustments primarily due to stock-based compensation, depreciation and amortization, increases to our provision for inventory obsolescence, and decreases to our provision for vendor deposits.  The net of these non-cash adjustments resulted in an increase to our net cash provided by operating activities of $9.0 million.

[0001628280-17-004928:mdna:78]
Net cash provided by operating activities in the nine months ended March 31, 2016 of $151.9 million consisted primarily of net income of $155.9 million and net changes in operating assets and liabilities that resulted in net cash outflows of $14.4 million. This net change was primarily driven by outflows arising from a $14.5 million decrease in accounts payable and accrued liabilities, a $9.2 million increase in accounts receivable due to overall higher revenues for the period, and a $5.9 million increase in inventory to fulfill expected future sales orders. These outflows were offset by changes in operating assets and liabilities resulting in cash inflows, including a $6.6 million decrease in vendor deposits due to consumption of raw material backed by vendor deposits, a $3.9 million increase in taxes payable due to increases in the income tax provision,

[0001628280-17-004928:mdna:79]
a $2.6 million decrease in prepaid taxes due to the timing of federal tax payments, a $374 thousand increase in deferred revenue due to additional PCS revenue deferrals during the period, and a $1.6 million decrease in prepaid expenses and other current assets. Overall, cash inflows from operating activities were driven by our net income for the period, which included non-cash adjustments primarily due to stock-based compensation (net of excess tax benefit), depreciation and amortization, write-off of previously capitalized software development costs, increases to our provision for inventory obsolescence due to consumption of inventory previously reserved, and increases to our provision for sales returns. The net of these non-cash adjustments resulted in an increase to our net cash provided by operating activities of $10.5 million.

[0001628280-17-004928:mdna:80]
[same as prior period, unchanged from 0001511737-17-000003:mdna:80]

[0001628280-17-004928:mdna:81]
We used $5.7 million of cash in investing activities during the nine months ended March 31, 2017.  Our investing activities consist of capital expenditures for machinery and equipment related to product development and prototyping activities in addition to purchases of intangible assets. Capital expenditures for the nine months ended March 31, 2017 and 2016 were $5.7 million and $4.8 million, respectively.

[0001628280-17-004928:mdna:82]
[same as prior period, unchanged from 0001511737-17-000003:mdna:82]

[0001628280-17-004928:mdna:83]
We used $77.3 million of cash in financing activities during the nine months ended March 31, 2017. During the nine months ended March 31, 2017, we paid $99.8 million for repurchases of our common stock. We also made repayments of $7.5 million on our outstanding term loan debt under the Term Facility. These cash outflows were offset by financing cash inflows of $30.0 million related to one draw made under the revolver facility of our Credit Agreement. Additionally, cash inflows from financing activities included $1.4 million of cash proceeds received from the exercise of stock options partially offset by tax withholdings related to net share settlements of restricted stock units totaling $1.4 million.

[0001628280-17-004928:mdna:84]
We used $91.0 million of cash in financing activities during the nine months ended March 31, 2016. During the nine months ended March 31, 2016 we paid $150.0 million for repurchases of our common stock. We also made repayments of $7.5 million on our outstanding term loan debt under the Credit Agreement. These cash outflows were offset by financing cash inflows, including four draws made under the Revolving Facility totaling $66.0 million that were used, in part, for the repurchases of our common stock discussed above. Additionally, cash inflows from financing activities included $778 thousand of cash proceeds received from the exercise of stock options in addition to $671 thousand of excess tax benefit from employee stock-based awards, partially offset by tax withholdings related to net share settlements of restricted stock units totaling $922 thousand.

[0001628280-17-004928:mdna:85]
[same as prior period, unchanged from 0001511737-17-000003:mdna:85]

[0001628280-17-004928:mdna:86]
We believe our existing cash and cash equivalents, cash provided by operations and the availability of additional funds under the Facilities will be sufficient to meet our working capital and capital expenditure needs for at least the next twelve months. Our future capital requirements may vary materially from those currently planned and will depend on many factors, including our rate of revenue growth, the timing and extent of spending to support development efforts, the timing of new product introductions, market acceptance of our products and overall economic conditions. As of March 31, 2017, we held $511.8 million of our $533.9 million of cash and cash equivalents in accounts of our subsidiaries outside of the United States and we could incur material tax liabilities if we decide to repatriate those amounts.

[0001628280-17-004928:mdna:87]
[same as prior period, unchanged from 0001511737-17-000003:mdna:87]

[0001628280-17-004928:mdna:88]
Our products are generally accompanied by a twelve-month warranty from date of purchase, which covers both parts and labor. Generally the distributor is responsible for the freight costs associated with warranty returns, and we absorb the freight costs of replacing items under warranty. In accordance with the Financial Accounting Standards Board’s (“FASB’s”), Accounting Standards Codification (“ASC”), 450-20, Loss Contingencies, we record an accrual when we believe it is reasonably estimable and probable based upon historical experience. We record a provision for estimated future warranty work in cost of goods sold upon recognition of revenues, and we review the resulting accrual regularly and periodically adjust it to reflect changes in warranty estimates.

[0001628280-17-004928:mdna:89]
[same as prior period, unchanged from 0001511737-17-000003:mdna:89]

[0001628280-17-004928:mdna:90]
We have agreed to indemnify our directors, officers and certain other employees for certain events or occurrences, subject to certain limits, while such persons are or were serving at our request in such capacity. We may terminate the indemnification agreements with these persons upon the termination of their services with us, but termination will not affect claims for indemnification related to events occurring prior to the effective date of termination. The maximum amount of potential future indemnification is unlimited. We have a Directors and Officers insurance policy that limits our potential exposure. We believe the fair value of these indemnification agreements is minimal.  We have not recorded any liabilities for these agreements as of March 31, 2017.

[0001628280-17-004928:mdna:91]
Based upon our historical experience and information known as of the date of this report, we do not believe it is likely that we have a material liability for the above indemnities at March 31, 2017.

[0001628280-17-004928:mdna:92]
[same as prior period, unchanged from 0001511737-17-000003:mdna:92]

[0001628280-17-004928:mdna:93]
The following table summarizes our contractual obligations as of March 31, 2017 for the remainder of fiscal 2017 and future fiscal years (in thousands):

[0001628280-17-004928:mdna:94]
|  | 2017 (remainder) |  | 2018 |  | 2019 |  | 2020 |  | 2021 |  | Thereafter |  | Total |
| Operating leases | $ | 1,851 |  |  | $ | 5,752 |  |  | $ | 3,120 |  |  | $ | 2,203 |  |  | $ | 1,356 |  |  | $ | 560 |  |  | $ | 14,842 |  |
| Debt payment obligations | 3,750 |  |  | 15,000 |  |  | 15,000 |  |  | 192,250 |  |  | — |  |  | — |  |  | 226,000 |  |
| Interest and other payments on debt payment obligations | 1,516 |  |  | 5,820 |  |  | 5,418 |  |  | 3,468 |  |  | — |  |  | — |  |  | 16,222 |  |
| Purchase obligations | 40,661 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 40,661 |  |
| Other obligations | 9,808 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 9,808 |  |
| Total | $ | 57,586 |  |  | $ | 26,572 |  |  | $ | 23,538 |  |  | $ | 197,921 |  |  | $ | 1,356 |  |  | $ | 560 |  |  | $ | 307,533 |  |

[0001628280-17-004928:mdna:95]
[same as prior period, unchanged from 0001511737-17-000003:mdna:95]

[0001628280-17-004928:mdna:96]
[same as prior period, unchanged from 0001511737-17-000003:mdna:96]

[0001628280-17-004928:mdna:97]
[same as prior period, unchanged from 0001511737-17-000003:mdna:97]

[0001628280-17-004928:mdna:98]
On March 3, 2015, we entered into the Credit Agreement, that provides for a $200.0 million senior secured revolving credit facility and a $100.0 million senior secured term loan facility, with an option to request increases in the amounts of such credit facilities by up to an additional $50.0 million in the aggregate (any such increase to be in each lender’s sole discretion).  Please see Note 7 of the notes to the consolidated financial statements for more information. Although interest rates on our debt obligations will likely vary over time, we have assumed our interest rates as of March 31, 2017 as the interest rates for all fiscal years presented.  Furthermore, the interest payment intervals on our revolving debt are determined at the Company's election pursuant to the Credit Agreement, and may change over time.  For purposes of the table above, we have assumed two to three-month payment intervals on our revolving debt, consistent with our elections to date.  Also included are estimated bank fees to be paid for unused portions of our Revolving Facility.

[0001628280-17-004928:mdna:99]
[same as prior period, unchanged from 0001511737-17-000003:mdna:99]

[0001628280-17-004928:mdna:100]
We subcontract with third parties to manufacture our products. During the normal course of business, our contract manufacturers procure components and manufacture product based upon orders placed by us.  Component and product inventory held by our contract manufacturers or our third-party logistics providers is not recorded on our balance sheet until legal title passes to the Company.  If we cancel all or part of the orders, we may still be liable to the contract manufacturers for the cost of the components they purchased and for manufacturing and other costs related to these components. We periodically review the potential liability, and no significant liabilities for cancellations have been recorded for the nine months ended March 31, 2017. Our consolidated financial position and results of operations could be negatively impacted if we were required to compensate the contract manufacturers for any unrecorded liabilities incurred. The Company had inventory purchase obligations of $40.7 million as of March 31, 2017.

[0001628280-17-004928:mdna:101]
[same as prior period, unchanged from 0001511737-17-000003:mdna:101]

[0001628280-17-004928:mdna:102]
We had other obligations of $9.8 million as of March 31, 2017, which consisted primarily of commitments related to research and development projects.

[0001628280-17-004928:mdna:103]
[same as prior period, unchanged from 0001511737-17-000003:mdna:103]

[0001628280-17-004928:mdna:104]
As of March 31, 2017, we had $26.9 million of unrecognized tax benefits. This amount has not been included in the above table as the settlement period for the unrecognized tax benefits, including related accrued interest and penalties, cannot be determined.

[0001628280-17-004928:mdna:105]
[same as prior period, unchanged from 0001511737-17-000003:mdna:105]

[0001628280-17-004928:mdna:106]
For a discussion of recent accounting pronouncements, refer to Note 2 to the consolidated financial statements.

[0001628280-17-004928:mdna:107]
[same as prior period, unchanged from 0001511737-17-000003:mdna:107]

[0001628280-17-004928:mdna:108]
When used in this Report, the words “anticipates,” “believes,” “could,” “seeks,” “estimates,” “expects,” “intends,” “may,” “plans” “potential,” “predicts,” “projects,” “should,” “will,” “would” or similar expressions and negatives of those terms are intended to identify forward-looking statements. These are statements that relate to future periods and include statements about our future results, sources of revenue, our continued growth, our gross margins, market trends, our product development, technological developments, the features, benefits and performance of our current and future products, the ability of our products to address a variety of markets, the anticipated growth of demand for connectivity worldwide, our growth strategies, future price reductions, our competitive status, our dependence on our senior management and our ability to attract and retain key personnel, dependency on and concentration of our distributors, our employee relations, current and potential litigation, the effects of government regulations, our compliance with laws and regulations, our expected future operating costs and expenses and expenditure levels for research and development, selling, general and administrative expenses, fluctuations in operating results, fluctuations in our stock price, our payment of dividends, our future liquidity and cash needs, our credit facility, future acquisitions of and investments in complimentary businesses and the expected impact of various accounting policies and rules adopted by the Financial Accounting Standards Board. Forward-looking statements are subject to risks and uncertainties that could cause actual results to differ materially from those projected. These risks and uncertainties include, but are not limited to, factors affecting our quarterly results, our ability to manage our growth, our ability to sustain or increase profitability, demand for our products, our ability to compete, our ability to rapidly develop new technology and introduce new products, our ability to safeguard our intellectual property, trends in the networking industry and fluctuations in general economic conditions, and the risks set forth throughout this Report, including under Part II “Other Information”, Item 1-Legal Proceedings and Item 1A- Risk Factors. These forward-looking statements speak only as of the date hereof. Except as required by law, we expressly disclaim any obligation or undertaking to release publicly any updates or revisions to any forward-looking statements contained herein to reflect any change in our expectations with regard thereto or any change in events, conditions or circumstances on which any such statement is based.
