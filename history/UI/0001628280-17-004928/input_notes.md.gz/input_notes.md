# UI notes — 0001628280-17-004928


## ubnt:ScheduleOfRevenueAndAccountsReceivableByMajorCustomersByReportingSegmentsTableTableTextBlock

[0001628280-17-004928:notes:1]
[same as prior period, unchanged from 0001511737-17-000003:notes:1]

[0001628280-17-004928:notes:2]
|  | Percentage of Revenues |  | Percentage of Accounts Receivable |
|  | Three Months Ended March 31, |  | Nine Months Ended March 31, |  | March 31, |  | June 30, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Customer A | * |  | * |  | * |  | * |  | 12% |  | 11% |
| Customer B | * |  | * |  | * |  | * |  | * |  | 13% |
| Customer C | 10% |  | * |  | 11% |  | * |  | 17% |  | 18% |
| Customer D | * |  | * |  | * |  | 10% |  | * |  | * |

[0001628280-17-004928:notes:3]
[same as prior period, unchanged from 0001511737-17-000003:notes:3]


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001628280-17-004928:notes:4]
[same as prior period, unchanged from 0001511737-17-000003:notes:4]

[0001628280-17-004928:notes:5]
These consolidated financial statements should be read in conjunction with the Company’s audited consolidated financial statements for the fiscal year ended June 30, 2016, included in its Annual Report on Form 10-K, as filed with the SEC on August 22, 2016 (the “Annual Report”). The results of operations for the three and nine months ended March 31, 2017 are not necessarily indicative of the results to be expected for any future periods.


## us-gaap:BusinessDescriptionAndBasisOfPresentationTextBlock

[0001628280-17-004928:notes:6]
[same as prior period, unchanged from 0001511737-17-000003:notes:6]

[0001628280-17-004928:notes:7]
[same as prior period, unchanged from 0001511737-17-000003:notes:7]

[0001628280-17-004928:notes:8]
[same as prior period, unchanged from 0001511737-17-000003:notes:8]

[0001628280-17-004928:notes:9]
[same as prior period, unchanged from 0001511737-17-000003:notes:9]


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001628280-17-004928:notes:10]
COMMITMENTS AND CONTINGENCIES

[0001628280-17-004928:notes:11]
Operating Leases

[0001628280-17-004928:notes:12]
Certain facilities and equipment are leased under non-cancelable operating leases. The Company generally pays taxes, insurance and maintenance costs on leased facilities and equipment. The Company leases its headquarters in San Jose, California and other locations under non-cancelable operating leases that expire at various dates through fiscal 2022.

[0001628280-17-004928:notes:13]
At March 31, 2017, future minimum annual payments under operating leases for the remainder of fiscal 2017 and future fiscal years are as follows (in thousands):

[0001628280-17-004928:notes:14]
|  | 2017 (remainder) |  | 2018 |  | 2019 |  | 2020 |  | 2021 |  | Thereafter |  | Total |
| Operating leases | $ | 1,851 |  |  | $ | 5,752 |  |  | $ | 3,120 |  |  | $ | 2,203 |  |  | $ | 1,356 |  |  | $ | 560 |  |  | $ | 14,842 |  |

[0001628280-17-004928:notes:15]
Purchase Obligations

[0001628280-17-004928:notes:16]
The Company primarily subcontracts with other companies to manufacture its products. During the normal course of business, the Company’s contract manufacturers procure components based upon orders placed by the Company. If the Company cancels all or part of the orders, it may still be liable to the contract manufacturers for the cost of the components purchased by them to manufacture the Company’s products. The Company periodically reviews the potential liability under its orders, and no significant accruals have been recorded as of March 31, 2017.  The Company had inventory purchase obligations of $40.7 million as of March 31, 2017.

[0001628280-17-004928:notes:17]
Other Obligations

[0001628280-17-004928:notes:18]
The Company had other obligations of $9.8 million as of March 31, 2017, which consisted primarily of commitments related to research and development projects.

[0001628280-17-004928:notes:19]
Indemnification Obligations

[0001628280-17-004928:notes:20]
The Company enters into standard indemnification agreements with many of its business partners in the ordinary course of business. These agreements include provisions for indemnifying the business partner against any claim brought by a third-party to the extent any such claim alleges that a Company product infringes a patent, copyright or trademark, or violates any other proprietary rights of that third-party. The maximum potential amount of future payments the Company could be required to make under these indemnification agreements is not estimable and the Company has not incurred any material costs to defend lawsuits or settle claims related to these indemnification agreements to date.

[0001628280-17-004928:notes:21]
Legal Matters

[0001628280-17-004928:notes:22]
The Company may be involved, from time to time, in a variety of claims, lawsuits, investigations, and proceedings relating to contractual disputes, intellectual property rights, employment matters, regulatory compliance matters and other litigation matters relating to various claims that arise in the normal course of business. The Company determines whether an estimated loss from a contingency should be accrued by assessing whether a loss is deemed probable and can be reasonably estimated. The Company assesses its potential liability by analyzing specific litigation and regulatory matters using available information. The Company develops its views on estimated losses in consultation with inside and outside counsel, which involves a subjective analysis of potential results and outcomes, assuming various combinations of appropriate litigation and settlement strategies. Taking all of the above factors into account, the Company records an amount where it is probable that the Company will incur a loss and where that loss can be reasonably estimated. However, the Company’s estimates may be incorrect and the Company could ultimately incur more or less than the amounts initially recorded.  The Company may also incur significant legal fees, which are expensed as incurred, in defending against these claims. The Company is not currently aware of any pending or threatened litigation that would have a material adverse effect on the Company's financial statements.

[0001628280-17-004928:notes:23]
Shareholder Class Action Lawsuits

[0001628280-17-004928:notes:24]
Beginning on September 7, 2012, two class action lawsuits were filed in the United States District Court for the Northern District of California against Ubiquiti Networks, Inc., certain of our current and former officers and directors, and the underwriters of its initial public offering, alleging claims under U.S. securities laws. On January 30, 2013, the plaintiffs filed an amended consolidated complaint. On March 26, 2014, the court issued an order granting a motion to dismiss the complaint with leave to amend. Following the plaintiffs’ decision not to file an amended complaint, on April 16, 2014, the court ordered the dismissal of the lawsuit with prejudice, and entered judgment in favor of the Company and the other defendants, and against the plaintiffs. On May 15, 2014, the plaintiffs filed a notice of appeal from the judgment of the court. The Ninth Circuit heard oral arguments on August 10, 2016.  On October 24, 2016, the Ninth Circuit issued an unpublished opinion, reaffirming the district court’s dismissal of the alleged violation of Sections 10(b) and 20(a) of the Securities Exchange Act of 1934 and reversing the district court’s dismissal of the alleged violations of Sections 11 and 15 of the Securities Act of 1933. The Company filed a petition for rehearing with the Ninth Circuit, which the Ninth Circuit denied. The Company plans to vigorously defend itself against these claims; however, there can be no assurance that the Company will prevail in the lawsuit. The Company cannot currently estimate the possible loss, if any, that it may experience in connection with this litigation.

[0001628280-17-004928:notes:25]
Synopsys

[0001628280-17-004928:notes:26]
On February 3, 2017, Synopsys, Inc. (“Synopsys”) filed a complaint against the Company, one of our subsidiaries and certain employees in the United States District Court for the Northern District of California, alleging claims under the Digital Millennium Copyright Act (“DMCA”). On March 28, 2017, Synopsys filed an amended complaint alleging claims under the trafficking provisions of the DMCA and claims for fraud, civil RICO and negligent misrepresentation. The Company plans to vigorously defend itself against these claims; however, there can be no assurance that the Company will prevail in the lawsuit. The Company cannot currently estimate the possible loss or range of losses, if any, that it may experience in connection with this litigation.


## us-gaap:DebtDisclosureTextBlock

[0001628280-17-004928:notes:27]
DEBT

[0001628280-17-004928:notes:28]
On March 3, 2015, Ubiquiti Networks, Inc. and Ubiquiti International Holding Company Limited (the “Cayman Borrower”) amended and restated its prior credit agreement (the “Credit Agreement”) with Wells Fargo Bank, National Association (“Wells Fargo”), the other financial institutions named as lenders therein, and Wells Fargo as administrative agent for the lenders.  The Credit Agreement provides for a $200.0 million senior secured revolving credit facility ("Revolving Facility") and a $100.0 million senior secured term loan facility ("Term Facility", together with the Revolving Facility, the “Facilities”), with an option to request increases in the amounts of such Facilities by up to an additional $50.0 million in the aggregate (any such increase to be in each lender’s sole discretion). The Credit Agreement, matures on March 3, 2020. The Facilities replaced the Company’s $150.0 million senior secured revolving credit facility under its prior credit agreement. The $100.0 million term loan facility of the Credit Agreement was fully drawn at closing of the Credit Agreement, and $72.3 million was used to repay the outstanding balance under its prior credit agreement. The Facilities are available for working capital and general corporate purposes that comply with the terms of the Credit Agreement.

[0001628280-17-004928:notes:29]
Our Debt consisted of the following (in thousands):

[0001628280-17-004928:notes:30]
|  | March 31, 2017 |  | June 30, 2016 |
| Term Loan - short term | $ | 15,000 |  |  | $ | 11,250 |  |
| Debt issuance costs, net (1) | (257 | ) |  | (257 | ) |
| Total Debt - short term | 14,743 |  |  | 10,993 |  |
| Term Loan - long term | 65,000 |  |  | 76,250 |  |
| Revolver - long term | 146,000 |  |  | 116,000 |  |
| Debt issuance costs, net (1) | (493 | ) |  | (686 | ) |
| Total Debt - long term | $ | 210,507 |  |  | $ | 191,564 |  |

[0001628280-17-004928:notes:31]
(1) On July 1 2016, the Company retrospectively adopted ASU 2015-03, which requires unamortized debt issuance costs to be included as a direct deduction from the related debt liability on the balance sheet. Under previous guidance, all unamortized debt issuance costs were reported as assets on the balance sheet. See Note 2 for information on the impact of the retrospective adoption of ASU 2015-03.

[0001628280-17-004928:notes:32]
As of March 31, 2017, the interest rate on the term loan was 2.65%. The table below shows the respective interest rates as of March 31, 2017 in addition to interest rate reset dates and rates as available for each revolver draw.

[0001628280-17-004928:notes:33]
|  |  | Interest Rate as of |  |  |  |  |
| Debt Payment Obligations |  | March 31, 2017 |  | Rate Reset Date |  | Reset Rate |
| $15 Million Revolver |  | 2.51% |  | 4/10/2017 |  | # |
| $18 Million Revolver |  | 2.52% |  | 7/18/2017 |  | 2.66% |
| $16 Million Revolver |  | 2.53% |  | 5/15/2017 |  | * |
| $19 Million Revolver |  | 2.50% |  | 4/3/2017 |  | # |
| $48 Million Revolver |  | 2.55% |  | 5/30/2017 |  | * |
| $30 Million Revolver |  | 2.93% |  | 9/15/2017 |  | * |

[0001628280-17-004928:notes:34]
* - Reset rate not available as of filing date.

[0001628280-17-004928:notes:35]
# - Revolver repaid subsequent to March 31, 2017

[0001628280-17-004928:notes:36]
The Revolving Facility includes a sub-limit of $10.0 million for letters of credit and a sub-limit of $25.0 million for swingline loans. Under the Credit Agreement, revolving loans and swingline loans may be borrowed, repaid and reborrowed until March 3, 2020, at which time all amounts borrowed must be repaid. The term loan is payable in quarterly installments of 2.50% of the original principal amount of the term loan until March 31, 2017, thereafter increasing to 3.75% of the original principal amount of the term loan, in each case plus accrued and unpaid interest. Revolving, swingline and term loans may be prepaid at any time without penalty.

[0001628280-17-004928:notes:37]
Revolving and term loans bear interest, at the Company’s option, at either (i) a floating rate per annum equal to the base rate plus a margin of between 0.50% and 1.25%, depending on the Company’s leverage ratio as of the most recently ended fiscal quarter or (ii) a floating per annum rate equal to the applicable LIBOR rate for a specified period, plus a margin of between 1.50% and 2.25%, depending on the Company’s leverage ratio as of the most recently ended fiscal quarter. Swingline loans bear interest at a floating rate per annum equal to the base rate plus a margin of between 0.50% and 1.25%, depending on the Company’s leverage ratio as of the most recently ended fiscal quarter.

[0001628280-17-004928:notes:38]
The Credit Agreement requires the Company to maintain during the term of the Facilities (i) a maximum leverage ratio of 2.50 to 1.00 and (ii) minimum liquidity of $225.0 million, increasing to $250.0 million in the event of an incremental increase in the size of the Facilities, which can be satisfied with unrestricted cash and cash equivalents and up to $50.0 million of availability under the Revolving Facility. In addition, the Credit Agreement contains customary affirmative and negative covenants and includes customary events of default. The occurrence of an event of default could result in the acceleration of the obligations under the Credit Agreement.

[0001628280-17-004928:notes:39]
The obligations of Ubiquiti Networks, Inc. and certain domestic subsidiaries, if any, under the Credit Agreement are required to be guaranteed by such domestic subsidiaries (the “Domestic Guarantors”) and are collateralized by substantially all assets (excluding intellectual property) of Ubiquiti Networks, Inc. and the Domestic Guarantors. The obligations of the Cayman Borrower and certain foreign subsidiaries under the Credit Agreement are required to be guaranteed by certain domestic and material foreign subsidiaries (the “Guarantors”) and are collateralized by substantially all assets (excluding intellectual property) of the Cayman Borrower and the Guarantors.

[0001628280-17-004928:notes:40]
During the three months ended March 31, 2017, the Company made a payment of $3.0 million against the balance under the Term Facility, of which $2.5 million was a repayment of principal and $0.5 million was payment of interest. During the nine months ended March 31, 2017, the Company made aggregate payments of $9.0 million against the balance under the Term Facility, of which $7.5 million was a repayment of principal and $1.5 million was payment of interest.

[0001628280-17-004928:notes:41]
During the three months ended March 31, 2017, the Company made a payment of $0.7 million of interest under the Revolving Facility. During the nine months ended March 31, 2017, the Company made aggregate payments of $2.2 million of interest under the Revolving Facility.

[0001628280-17-004928:notes:42]
On September 2, 2015, the Company accessed a letter of credit under its Revolving Facility in the amount of $0.2 million for the benefit of the landlord pursuant to a new lease of office space. The landlord can draw against the letter of credit in the event of a lease default by the Company. The letter of credit expires on September 2, 2017, subject to automatic renewal for additional one-year periods.

[0001628280-17-004928:notes:43]
The following table summarizes our estimated debt and interest payment obligations as of March 31, 2017, for the remainder of fiscal 2017 and future fiscal years (in thousands):

[0001628280-17-004928:notes:44]
|  | 2017 (remainder) |  | 2018 |  | 2019 |  | 2020 |  | 2021 |  | Thereafter |  | Total |
| Debt payment obligations | $ | 3,750 |  |  | $ | 15,000 |  |  | $ | 15,000 |  |  | $ | 192,250 |  |  | $ | — |  |  | $ | — |  |  | $ | 226,000 |  |
| Interest and other payments on debt payment obligations (1) | 1,516 |  |  | 5,820 |  |  | 5,418 |  |  | 3,468 |  |  | — |  |  | — |  |  | 16,222 |  |
| Total | $ | 5,266 |  |  | $ | 20,820 |  |  | $ | 20,418 |  |  | $ | 195,718 |  |  | $ | — |  |  | $ | — |  |  | $ | 242,222 |  |

[0001628280-17-004928:notes:45]
(1) - Interest payments are calculated based on the applicable rates and payment dates as of March 31, 2017. Furthermore, two to three-month payment intervals on the revolving debt have been assumed, consistent with the Company's elections to date.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001628280-17-004928:notes:46]
[same as prior period, unchanged from 0001511737-17-000003:notes:43]

[0001628280-17-004928:notes:47]
[same as prior period, unchanged from 0001511737-17-000003:notes:44]

[0001628280-17-004928:notes:48]
The Company’s 2010 Equity Incentive Plan and 2005 Equity Incentive Plan are described in its Annual Report. As of March 31, 2017, the Company had 10,021,856 authorized shares available for future issuance under all of its stock incentive plans.

[0001628280-17-004928:notes:49]
[same as prior period, unchanged from 0001511737-17-000003:notes:46]

[0001628280-17-004928:notes:50]
The following table shows total stock-based compensation expense included in the Consolidated Statements of Operations for the three and nine months ended March 31, 2017 and 2016 (in thousands):

[0001628280-17-004928:notes:51]
|  | Three Months Ended March 31, |  | Nine Months Ended March 31, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Cost of revenues | $ | 39 |  |  | $ | 114 |  |  | $ | 213 |  |  | $ | 341 |  |
| Research and development | 421 |  |  | 566 |  |  | 1,362 |  |  | 1,770 |  |
| Sales, general and administrative | 141 |  |  | 202 |  |  | 519 |  |  | 755 |  |
|  | $ | 601 |  |  | $ | 882 |  |  | $ | 2,094 |  |  | $ | 2,866 |  |

[0001628280-17-004928:notes:52]
[same as prior period, unchanged from 0001511737-17-000003:notes:49]

[0001628280-17-004928:notes:53]
The following is a summary of option activity for the Company’s stock incentive plans for the nine months ended March 31, 2017:

[0001628280-17-004928:notes:54]
|  | Common Stock Options Outstanding |
|  | Numberof Shares |  | WeightedAverageExercisePrice |  | WeightedAverageRemainingContractualLife (Years) |  | AggregateIntrinsicValue(In thousands) |
| Balance, June 30, 2016 | 2,125,307 |  |  | $ | 2.03 |  |  | 2.65 |  | $ | 77,850 |  |
| Exercised | (496,800 | ) |  | $ | 2.81 |  |  |  |  |  |
| Forfeitures and cancellations | (1,356 | ) |  | $ | 11.72 |  |  |  |  |  |
| Balance, March 31, 2017 | 1,627,151 |  |  | $ | 1.78 |  |  | 1.80 |  | $ | 78,878 |  |
| Vested and expected to vest as of March 31, 2017 | 1,627,150 |  |  | $ | 1.78 |  |  | 1.80 |  | $ | 78,878 |  |
| Vested and exercisable as of March 31, 2017 | 1,626,889 |  |  | $ | 1.78 |  |  | 1.80 |  | $ | 78,869 |  |

[0001628280-17-004928:notes:55]
During the three months ended March 31, 2017 and 2016, the aggregate intrinsic value of options exercised under the Company’s stock incentive plans was $0.4 million and $1.3 million, respectively, as determined as of the date of option exercise. During the nine months ended March 31, 2017 and 2016, the aggregate intrinsic value of options exercised under the Company’s stock incentive plans was $24.6 and $3.5 million, respectively, as determined as of the date of option exercise.

[0001628280-17-004928:notes:56]
As of March 31, 2017, the Company had unrecognized compensation costs of $1.3 thousand related to stock options which the Company expects to recognize over a weighted-average period of 0.2 years. Future option grants will increase the amount of compensation expense to be recorded in these periods.

[0001628280-17-004928:notes:57]
The Company estimates the fair value of employee stock options using the Black-Scholes option pricing model. The fair value of employee stock options is amortized on a straight-line basis over the requisite service period of the awards.  The Company did not grant any employee stock options during the three and nine months ended March 31, 2017 and 2016.

[0001628280-17-004928:notes:58]
[same as prior period, unchanged from 0001511737-17-000003:notes:55]

[0001628280-17-004928:notes:59]
[same as prior period, unchanged from 0001511737-17-000003:notes:56]

[0001628280-17-004928:notes:60]
|  | Number of Shares |  | Weighted Average Grant Date Fair Value Per Share |
| Non-vested RSUs, June 30, 2016 | 271,971 |  |  | $ | 28.72 |  |
| RSUs granted | 72,023 |  |  | $ | 55.33 |  |
| RSUs vested | (109,124 | ) |  | $ | 24.71 |  |
| RSUs canceled | (42,685 | ) |  | $ | 33.44 |  |
| Non-vested RSUs, March 31, 2017 | 192,185 |  |  | $ | 39.53 |  |

[0001628280-17-004928:notes:61]
The intrinsic value of RSUs vested in the three months ended March 31, 2017 and 2016 was $1.9 million and $0.9 million, respectively. The intrinsic value of RSUs vested in the nine months ended March 31, 2017 and 2016 was $5.6 million and $3.7 million, respectively.

[0001628280-17-004928:notes:62]
As of March 31, 2017, there were unrecognized compensation costs related to RSUs of $8.1 million which the Company expects to recognize over a weighted average period of 3.2 years.


## us-gaap:EarningsPerShareTextBlock

[0001628280-17-004928:notes:63]
[same as prior period, unchanged from 0001511737-17-000003:notes:60]

[0001628280-17-004928:notes:64]
[same as prior period, unchanged from 0001511737-17-000003:notes:61]

[0001628280-17-004928:notes:65]
|  | Three Months Ended March 31, |  | Nine Months Ended March 31, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Numerator: |  |  |  |
| Net income and comprehensive income | $ | 64,432 |  |  | $ | 52,699 |  |  | $ | 196,828 |  |  | $ | 155,910 |  |
| Denominator: |  |  |  |
| Weighted-average shares used in computing basic net income per share | 81,652 |  |  | 83,349 |  |  | 81,879 |  |  | 85,051 |  |
| Add—dilutive potential common shares: |  |  |  |  |  |  |  |
| Stock options(1) | 1,579 |  |  | 1,264 |  |  | 1,704 |  |  | 1,282 |  |
| Restricted stock units(1) | 86 |  |  | 72 |  |  | 111 |  |  | 100 |  |
| Weighted-average shares used in computing diluted net income per share | 83,317 |  |  | 84,685 |  |  | 83,694 |  |  | 86,433 |  |
| Net income per share of common stock: |  |  |  |
| Basic | $ | 0.79 |  |  | $ | 0.63 |  |  | $ | 2.40 |  |  | $ | 1.83 |  |
| Diluted | $ | 0.77 |  |  | $ | 0.62 |  |  | $ | 2.35 |  |  | $ | 1.80 |  |

[0001628280-17-004928:notes:66]
(1) Effective July 1, 2016, the Company early adopted ASU 2016-09 regarding the Improvements to Employee Share-Based Payment Accounting. During the three and nine months ended March 31, 2017, the adoption increased the number of diluted stock options and restricted stock units by 635 thousand and 689 thousand shares, respectively.

[0001628280-17-004928:notes:67]
[same as prior period, unchanged from 0001511737-17-000003:notes:64]

[0001628280-17-004928:notes:68]
|  | Three Months Ended March 31, |  | Nine Months Ended March 31, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Restricted stock units | 29 |  |  | 16 |  |  | 10 |  |  | — |  |
|  | 29 |  |  | 16 |  |  | 10 |  |  | — |  |


## us-gaap:FairValueAssetsAndLiabilitiesMeasuredOnRecurringAndNonrecurringBasisTableTextBlock

[0001628280-17-004928:notes:69]
As of March 31, 2017 and June 30, 2016, the fair value hierarchy of the Company’s debt carried at historical cost was as follows (in thousands):

[0001628280-17-004928:notes:70]
|  | March 31, 2017 |  | June 30, 2016 |
|  | Fair Value |  | Fair Value |
| Debt | $ | 226,000 |  |  | $ | 203,500 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001628280-17-004928:notes:71]
[same as prior period, unchanged from 0001511737-17-000003:notes:68]

[0001628280-17-004928:notes:72]
[same as prior period, unchanged from 0001511737-17-000003:notes:69]

[0001628280-17-004928:notes:73]
[same as prior period, unchanged from 0001511737-17-000003:notes:70]

[0001628280-17-004928:notes:74]
[same as prior period, unchanged from 0001511737-17-000003:notes:71]

[0001628280-17-004928:notes:75]
[same as prior period, unchanged from 0001511737-17-000003:notes:72]

[0001628280-17-004928:notes:76]
For certain of the Company’s financial instruments, including cash, accounts receivable, accounts payable and other current liabilities, the carrying amounts approximate fair value due to their short maturities.  Additionally, as of March 31, 2017, we held $511.8 million of our $533.9 million of cash and cash equivalents in accounts of our subsidiaries outside of the United States and we could incur material tax liabilities if we were to repatriate those amounts.

[0001628280-17-004928:notes:77]
As of March 31, 2017 and June 30, 2016 the Company had debt associated with its Credit Agreement with Wells Fargo Bank (See Note 7). The fair value of the Company’s debt was estimated based on the current rates offered to the Company for debt with similar terms and remaining maturities and was a Level 2 measurement.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001628280-17-004928:notes:78]
[same as prior period, unchanged from 0001511737-17-000003:notes:75]

[0001628280-17-004928:notes:79]
The Company recorded a tax provision of $7.9 million and $18.0 million for the three and nine months ended March 31, 2017.  The Company’s estimated fiscal year 2017 effective tax rate differs from the U.S. statutory rate primarily due to profits earned in jurisdictions where the tax rate is lower than the U.S. tax rate and in realization of share-based compensation excess tax benefit.

[0001628280-17-004928:notes:80]
Effective July 1, 2016, the Company early adopted ASU 2016-09 regarding the Improvements to Employee Share-Based Payment Accounting. In accordance with the new guidance, for the three and nine months ended March 31, 2017, the Company recognized excess tax benefits for share- based payments of $0.2 million and $7.9 million, respectively, as a discrete item within the provision for income taxes rather than additional paid-in capital. See Note 2 for information on the impact of the adoption of ASU 2016-09.

[0001628280-17-004928:notes:81]
As of March 31, 2017, the Company had approximately $26.9 million of unrecognized tax benefits, substantially all of which would, if recognized, affect its tax expense. The Company has elected to include interest and penalties related to uncertain tax positions as a component of tax expense. At March 31, 2017, an immaterial amount of interest and penalties are included in long-term income tax payable. The Company recorded a net increase of its unrecognized tax benefits of $2.0 million and $4.0 million, respectively, for the three and nine months ended March 31, 2017. The Company does not expect any significant increases or decreases to its unrecognized tax benefits in the next twelve months.

[0001628280-17-004928:notes:82]
[same as prior period, unchanged from 0001511737-17-000003:notes:79]

[0001628280-17-004928:notes:83]
[same as prior period, unchanged from 0001511737-17-000003:notes:80]


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001628280-17-004928:notes:84]
New Accounting Updates Recently Adopted

[0001628280-17-004928:notes:85]
Effective July 1, 2016, the Company adopted Accounting Standards Update (“ASU”) 2015-03 regarding simplifying the presentation of debt issuance costs. The guidance requires that debt issuance costs related to a recognized debt liability be presented in the balance sheet as a direct deduction from the carrying amount of that debt liability, consistent with debt discounts. Previously the Company reported these costs as assets on its balance sheet. The guidance is applied on a retrospective basis whereby prior-period financial statements must be adjusted to reflect the adoption of the new guidance.

[0001628280-17-004928:notes:86]
The Company has reclassified $0.3 million from "prepaid expenses and other current assets" to "Debt - short-term", and $0.7 million from "Other long-term assets" to "Debt - long-term" on the June 30, 2016 consolidated balance sheet.

[0001628280-17-004928:notes:87]
Effective July 1, 2016, the Company adopted ASU 2015-11 regarding simplifying the measurement of inventory. The guidance requires an entity to measure inventory at the lower of cost and net realizable value. Net realizable value is the estimated selling prices in the ordinary course of business, less reasonably predictable costs of completion, disposal, and transportation. The Company adopted this update prospectively, and it did not have a material impact on the Company's consolidated financial statements.

[0001628280-17-004928:notes:88]
Effective July 1, 2016, the Company early adopted ASU 2016-09,"Compensation-Stock Compensation (Topic 718), Improvements to Employee Share-Based Payment Accounting," regarding the Improvements to Employee Share-Based Payment Accounting. The Company applied the guidance relating to accounting for excess tax benefits and the presentation of excess tax benefits in the consolidated statement of cash flows on a prospective basis; accordingly, prior period amounts have not been adjusted. During the three and nine months ended March 31, 2017, the Company recognized the excess tax benefits of $0.2 million and $7.9 million, respectively, within the provision for income taxes rather than additional paid-in capital. The Company classified the excess tax benefits within cash flows from operating activities for the nine months ended March 31, 2017 rather than within cash flows from financing activities. In regards to the forfeiture policy election, we will continue to estimate the number of awards expected to be forfeited, rather than electing to account for forfeitures as they occur. No other terms of the adopted guidance resulted in an impact on the Company's consolidated financial statements.

[0001628280-17-004928:notes:89]
Recent Accounting Standards or Updates Not Yet Effective

[0001628280-17-004928:notes:90]
In May 2014, the FASB issued ASU 2014-09, Revenue from Contracts with Customers, with amendments in 2015 and 2016, which creates new ASC Topic 606 (Topic 606) that will replace most existing revenue recognition guidance in GAAP when it becomes effective. Topic 606 requires an entity to recognize the amount of revenue to which it expects to be entitled for the transfer of promised goods or services to customers. The new standard will be effective for the Company’s first quarter of fiscal year 2019 and early application for the Company's first quarter of fiscal year 2018 is permitted. Topic 606 may be applied retrospectively to each prior period presented or with the cumulative effect recognized as of the date of initial application. The Company is still evaluating the impact of adopting Topic 606 on its consolidated financial statements and related financial statement disclosures and has not yet selected a transition method or determined if it will adopt this standard in fiscal 2018 or 2019.

[0001628280-17-004928:notes:91]
In February 2016, the FASB issued ASU 2016-02, “Leases (Topic 842),” (“ASU 2016-02”). ASU 2016-02 requires lessees to recognize assets and liabilities on the balance sheet for leases with lease terms greater than twelve months and disclose key information about leasing arrangements. ASU 2016-02 is effective for annual periods beginning after December 15, 2018, including interim periods within those fiscal years, with early application permitted. The Company is evaluating the impact that adoption of this new standard will have on its consolidated financial statements.

[0001628280-17-004928:notes:92]
In June 2016, the FASB issued ASU 2016-13, “Financial Instruments – Credit Losses (Topic 326): Measurement of Credit Losses On Financial Instruments,” (“ASU 2016-13”). ASU 2016-13 implements a comprehensive change in estimating the allowances for loan losses from the current model of losses inherent in the loan portfolio to a current expected credit loss model that generally is expected to result in earlier recognition of allowances for losses. Additionally, purchase accounting rules have been modified as well as credit losses on held-to-maturity debt securities. ASU 2016-13 is effective for fiscal years beginning after December 15, 2019, and early adoption is permitted for annual and interim periods beginning after December 15, 2018. The Company is evaluating the impact that adoption of this new standard will have on its consolidated financial statements.

[0001628280-17-004928:notes:93]
In October 2016, the FASB issued ASU 2016-16, "Income Taxes (Topic 740): Accounting for Income Taxes: Intra-Entity Asset Transfers of Assets Other Than Inventory," (“ASU 2016-16”). ASU 2016-16 eliminates the exception for all intra-entity sales of assets other than inventory. As a result, a reporting entity would recognize the tax expense from the sale of the asset in the seller’s tax jurisdiction when the transfer occurs, even though the pre-tax effects of that transaction are eliminated in consolidation. Any deferred tax asset that arises in the buyer’s jurisdiction would also be recognized at the time of the transfer. ASU 2016-16 is effective for fiscal years beginning after December 15, 2017, and early adoption is permitted but can only be adopted in the first interim period of a fiscal year. The Company is evaluating the impact that adoption of this new standard will have on its consolidated financial statements.


## us-gaap:OtherCurrentLiabilitiesTableTextBlock

[0001628280-17-004928:notes:94]
[same as prior period, unchanged from 0001511737-17-000003:notes:91]

[0001628280-17-004928:notes:95]
|  | March 31, 2017 |  | June 30, 2016 |
| Accrued expenses | $ | 5,344 |  |  | $ | 5,749 |  |
| Accrued compensation and benefits | 1,707 |  |  | 1,589 |  |
| Warranty accrual | 4,212 |  |  | 2,236 |  |
| Deferred revenue - short term | 4,733 |  |  | 2,917 |  |
| Customer deposits | 330 |  |  | 856 |  |
| Reserve for sales returns | 3,479 |  |  | 2,820 |  |
| Other payables | 9,876 |  |  | 10,505 |  |
| Total | $ | 29,681 |  |  | $ | 26,672 |  |


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001628280-17-004928:notes:96]
[same as prior period, unchanged from 0001511737-17-000003:notes:93]

[0001628280-17-004928:notes:97]
[same as prior period, unchanged from 0001511737-17-000003:notes:94]

[0001628280-17-004928:notes:98]
[same as prior period, unchanged from 0001511737-17-000003:notes:95]

[0001628280-17-004928:notes:99]
|  | Nine Months Ended March 31, |
|  | 2017 |  | 2016 |
| Beginning balance | $ | 2,236 |  |  | $ | 2,750 |  |
| Accruals for warranties issued during the period | 6,555 |  |  | 1,574 |  |
| Settlements made during the period | (4,579 | ) |  | (2,155 | ) |
| Ending balance | $ | 4,212 |  |  | $ | 2,169 |  |


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0001628280-17-004928:notes:100]
[same as prior period, unchanged from 0001511737-17-000003:notes:97]

[0001628280-17-004928:notes:101]
|  | March 31, 2017 |  | June 30, 2016 |
| Testing equipment | $ | 7,579 |  |  | $ | 6,051 |  |
| Computer and other equipment | 5,399 |  |  | 4,857 |  |
| Tooling equipment | 7,442 |  |  | 5,801 |  |
| Furniture and fixtures | 1,525 |  |  | 1,325 |  |
| Leasehold improvements | 6,079 |  |  | 5,136 |  |
| Software | 5,687 |  |  | 2,488 |  |
| Software in development | — |  |  | 2,739 |  |
| Property and Equipment, Gross | 33,711 |  |  | 28,397 |  |
| Less: Accumulated depreciation and amortization | (20,366 | ) |  | (15,444 | ) |
| Property and Equipment, Net | $ | 13,345 |  |  | $ | 12,953 |  |


## us-gaap:ReconciliationOfRevenueFromSegmentsToConsolidatedTextBlock

[0001628280-17-004928:notes:102]
[same as prior period, unchanged from 0001511737-17-000003:notes:99]

[0001628280-17-004928:notes:103]
|  | Three Months Ended March 31, |  | Nine Months Ended March 31, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Service provider Technology | $ | 104,724 |  |  | 48 | % |  | $ | 96,215 |  |  | 57 | % |  | $ | 340,936 |  |  | 54 | % |  | $ | 309,230 |  |  | 64 | % |
| Enterprise Technology | 113,635 |  |  | 52 | % |  | 71,218 |  |  | 43 | % |  | 295,716 |  |  | 46 | % |  | 171,489 |  |  | 36 | % |
| Total revenues | $ | 218,359 |  |  | 100 | % |  | $ | 167,433 |  |  | 100 | % |  | $ | 636,652 |  |  | 100 | % |  | $ | 480,719 |  |  | 100 | % |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001628280-17-004928:notes:104]
RELATED PARTY TRANSACTIONS AND CERTAIN OTHER TRANSACTIONS

[0001628280-17-004928:notes:105]
Aircraft Lease Agreement

[0001628280-17-004928:notes:106]
On November 13, 2013, the Company entered into an aircraft lease agreement (the “Aircraft Lease Agreement”) with RJP Manageco LLC (the “Lessor”), a limited liability company owned by the Company’s CEO, Robert J. Pera. Pursuant to the Aircraft Lease Agreement, the Company may lease an aircraft owned by the Lessor for Company business purposes. Under the Aircraft Lease Agreement, the aircraft may be leased at a rate of $5,000 per flight hour. This hourly rate does not include the cost of flight crew or on-board services, which the Company purchases from a third-party provider. The Company recognized a total of approximately $0.5 million and $1.7 million in expenses pursuant to the Aircraft Lease Agreement during the three and nine months ended March 31, 2017, respectively.  The Company recognized a total of approximately $0.4 million and $1.0 million in expenses pursuant to the Aircraft Lease Agreement during the three and nine months ended March 31, 2016, respectively. All expenses pursuant to the Aircraft Lease Agreement have been included in the Company’s sales, general and administrative expenses in the Consolidated Statements of Operations.


## us-gaap:RevenueFromExternalCustomersByGeographicAreasTableTextBlock

[0001628280-17-004928:notes:107]
[same as prior period, unchanged from 0001511737-17-000003:notes:104]

[0001628280-17-004928:notes:108]
|  | Three Months Ended March 31, |  | Nine Months Ended March 31, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| North America(1) | $ | 78,573 |  |  | 36 | % |  | $ | 57,791 |  |  | 35 | % |  | $ | 247,347 |  |  | 39 | % |  | $ | 168,428 |  |  | 35 | % |
| South America | 27,770 |  |  | 13 | % |  | 15,450 |  |  | 9 | % |  | 71,240 |  |  | 11 | % |  | 61,123 |  |  | 13 | % |
| Europe, the Middle East and Africa ("EMEA") | 87,780 |  |  | 40 | % |  | 73,269 |  |  | 44 | % |  | 246,536 |  |  | 39 | % |  | 194,745 |  |  | 40 | % |
| Asia Pacific | 24,236 |  |  | 11 | % |  | 20,923 |  |  | 12 | % |  | 71,529 |  |  | 11 | % |  | 56,423 |  |  | 12 | % |
| Total revenues | $ | 218,359 |  |  | 100 | % |  | $ | 167,433 |  |  | 100 | % |  | $ | 636,652 |  |  | 100 | % |  | $ | 480,719 |  |  | 100 | % |

[0001628280-17-004928:notes:109]
| (1) | Revenue for the United States was $74.0 million and $54.6 million for the three months ended March 31, 2017 and 2016, respectively. Revenue for the United States was $234.8 million and $158.8 million for the nine months ended March 31, 2017 and 2016, respectively. |


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0001628280-17-004928:notes:110]
[same as prior period, unchanged from 0001511737-17-000003:notes:107]

[0001628280-17-004928:notes:111]
|  | March 31, 2017 |  | June 30, 2016 |
| Finished goods | $ | 122,809 |  |  | $ | 50,987 |  |
| Raw materials | 9,703 |  |  | 6,126 |  |
| Total | $ | 132,512 |  |  | $ | 57,113 |  |


## us-gaap:ScheduleOfOtherAssetsNoncurrentTextBlock

[0001628280-17-004928:notes:112]
[same as prior period, unchanged from 0001511737-17-000003:notes:109]

[0001628280-17-004928:notes:113]
|  | March 31, 2017 |  | June 30, 2016 |
| Intangible assets, net (1) | $ | 485 |  |  | $ | 616 |  |
| Other long-term assets | 1,452 |  |  | 960 |  |
| Total | $ | 1,937 |  |  | $ | 1,576 |  |

[0001628280-17-004928:notes:114]
(1) - Accumulated amortization was $1.2 million and $1.0 million as of March 31, 2017 and June 30, 2016, respectively.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001628280-17-004928:notes:115]
[same as prior period, unchanged from 0001511737-17-000003:notes:112]

[0001628280-17-004928:notes:116]
[same as prior period, unchanged from 0001511737-17-000003:notes:113]

[0001628280-17-004928:notes:117]
[same as prior period, unchanged from 0001511737-17-000003:notes:114]

[0001628280-17-004928:notes:118]
[same as prior period, unchanged from 0001511737-17-000003:notes:115]


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001628280-17-004928:notes:119]
[same as prior period, unchanged from 0001511737-17-000003:notes:116]

[0001628280-17-004928:notes:120]
[same as prior period, unchanged from 0001511737-17-000003:notes:117]


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001628280-17-004928:notes:121]
[same as prior period, unchanged from 0001511737-17-000003:notes:118]

[0001628280-17-004928:notes:122]
As of March 31, 2017 and June 30, 2016, the authorized capital of the Company included 500,000,000 shares of common stock.  As of March 31, 2017 and June 30, 2016, there were 80,313,029 and 81,667,129 shares of common stock outstanding, respectively.

[0001628280-17-004928:notes:123]
[same as prior period, unchanged from 0001511737-17-000003:notes:120]

[0001628280-17-004928:notes:124]
On May 4, 2016, the Board of Directors of the Company approved a $50 million stock repurchase program. Under the stock repurchase program, the Company was authorized to repurchase up to $50 million of its common stock. During the fourth quarter of fiscal 2016, the Company repurchased 1,309,606 shares of its common stock at an average price per share of $38.18 for an aggregate amount of $50 million. This included unpaid stock repurchases of $6.5 million relating to repurchases executed on or prior to June 30, 2016 for trades that settled in the first quarter of fiscal 2017.

[0001628280-17-004928:notes:125]
On August 3, 2016, the Board of Directors of the Company approved a $50 million stock repurchase program. Under the stock repurchase program, the Company was authorized to repurchase up to $50 million of its common stock. During the third quarter of fiscal 2017, the Company repurchased 1,014,956 shares of its common stock at an average price per share of $49.26 for an aggregate amount of $50 million.

[0001628280-17-004928:notes:126]
On March 3, 2017, the Board of Directors of the Company approved a $50 million stock repurchase program. Under the stock repurchase program, the Company may repurchase up to $50 million of its common stock.  The program expires on March 31, 2018.  During the third quarter of fiscal 2017, the Company repurchased 917,455 shares of its common stock at an average price per share of $50.43 for an aggregate amount of $46.3 million. This included unpaid stock repurchases of $3.0 million relating to repurchases executed on or prior to March 31, 2017 for trades that settled in the fourth quarter of fiscal 2017.  As of March 31, 2017, the Company has $3.7 million available under the stock repurchase program.


## us-gaap:SubsequentEventsTextBlock

[0001628280-17-004928:notes:127]
SUBSEQUENT EVENTS

[0001628280-17-004928:notes:128]
On April 14, 2017, the Company, the Cayman Borrower and certain of its subsidiaries entered in the First Amendment (the “First Amendment”) to the Credit Agreement (as amended by the First Amendment, the “Amended Credit Agreement”). The First Amendment increased the maximum aggregate amount of the Revolving Facility from $200.0 million to $300.0 million, but maintained the $100.0 million Term Facility under the Credit Agreement and the option to request increases in the amounts of such Facilities by up to an additional $50.0 million in the aggregate (any such increase to be in each lender’s sole discretion). The Amended Credit Agreement requires the Company to maintain during the term of the Facilities (i) a maximum leverage ratio of 2.50 to 1.00 and (ii) minimum liquidity of $250.0 million, which can be satisfied with unrestricted cash and cash equivalents and up to $50.0 million of availability under the Revolving Facility. All other material terms and provisions of the Amended Credit Agreement remain substantially identical to the terms and provisions in place immediately prior to the effectiveness of the First Amendment, other than the revision or inclusion of certain customary market provisions.

[0001628280-17-004928:notes:129]
Pursuant to the $50 million stock repurchase program approved by the Board of Directors of the Company on March 3, 2017, the Company repurchased $3.0 million of its common stock in the fourth quarter of fiscal 2017 that were trades executed on or prior to March 31, 2017. Please see Note 9 of the notes to the consolidated financial statements and Part II “Other Information” - Item 2 “Unregistered Sales of Equity Securities and Use of Proceeds” for more information.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001628280-17-004928:notes:130]
[same as prior period, unchanged from 0001511737-17-000003:notes:125]

[0001628280-17-004928:notes:131]
[same as prior period, unchanged from 0001511737-17-000003:notes:126]

[0001628280-17-004928:notes:132]
[same as prior period, unchanged from 0001511737-17-000003:notes:127]

[0001628280-17-004928:notes:133]
[same as prior period, unchanged from 0001511737-17-000003:notes:128]

[0001628280-17-004928:notes:134]
[same as prior period, unchanged from 0001511737-17-000003:notes:129]


## us-gaap:UnusualOrInfrequentItemsDisclosureTextBlock

[0001628280-17-004928:notes:135]
[same as prior period, unchanged from 0001511737-17-000003:notes:130]

[0001628280-17-004928:notes:136]
As disclosed in June 2015 and 2016, the Company determined that it was the victim of a criminal fraud known to law enforcement authorities as business e-mail compromise fraud which involved employee impersonation and fraudulent requests targeting our finance department.  The fraud resulted in transfers of funds aggregating $46.7 million held by a Company subsidiary incorporated in Hong Kong to other overseas accounts held by third parties.  To date, the Company has recovered $16.7 million. The Company recovered $8.1 million in fiscal 2015, resulting in a charge of $39.1 million in the fourth quarter of fiscal 2015, including additional expenses consisting of professional service fees associated with the fraud loss.  In fiscal 2016, the Company recorded a net recovery of an additional $8.3 million, comprised of the $8.6 million recovery less $0.3 million of professional service fees associated with the recovery. No additional recoveries were made during the three and nine months ended March 31, 2017.

[0001628280-17-004928:notes:137]
[same as prior period, unchanged from 0001511737-17-000003:notes:132]
