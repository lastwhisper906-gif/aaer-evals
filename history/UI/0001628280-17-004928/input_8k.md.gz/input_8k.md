# UI 8-K — 0001415889-17-000692 filed 2017-05-04

## item codes, every 8-K on or before 2017-05-04

- 2017-05-04 0001415889-17-000692 — 2.02, 9.01
- 2017-04-20 0001415889-17-000662 — 1.01, 2.03, 9.01
- 2017-03-03 0001415889-17-000354 — 8.01
- 2017-02-21 0001571049-17-001493 — 7.01, 9.01
- 2017-02-09 0001415889-17-000235 — 2.02, 9.01
- 2016-12-16 0001415889-16-007589 — 5.07
- 2016-12-08 0001415889-16-007559 — 4.01, 8.01, 9.01
- 2016-11-03 0001415889-16-007334 — 2.02, 9.01
- 2016-08-17 0001415889-16-006877 — 8.01
- 2016-08-10 0001415889-16-006753 — 5.02
- 2016-08-04 0001415889-16-006679 — 2.02, 8.01, 9.01
- 2016-05-05 0001415889-16-005749 — 2.02, 5.02, 8.01, 9.01
- 2016-02-04 0001415889-16-004613 — 2.02, 9.01
- 2015-12-18 0001415889-15-004120 — 3.01, 5.07
- 2015-11-05 0001415889-15-003599 — 2.02, 8.01, 9.01
- 2015-10-16 0001415889-15-003433 — 5.02
- 2015-08-06 0001571049-15-006288 — 2.02, 5.02, 8.01, 9.01
- 2015-05-07 0001511737-15-000016 — 2.02, 9.01
- 2015-04-23 0001415889-15-001433 — 2.02, 5.02, 9.01
- 2015-03-06 0001415889-15-000787 — 1.01, 1.02, 2.03, 9.01
- 2015-02-05 0001511737-15-000008 — 2.02, 9.01
- 2014-12-18 0001193125-14-446627 — 5.07
- 2014-11-06 0001511737-14-000029 — 2.02, 9.01
- 2014-09-30 0001193125-14-359060 — 7.01, 9.01
- 2014-08-07 0001511737-14-000021 — 2.02, 9.01
- 2014-05-08 0001511737-14-000016 — 2.02, 9.01
- 2014-04-17 0001193125-14-146710 — 7.01
- 2014-03-06 0001193125-14-084883 — 8.01
- 2014-02-06 0001511737-14-000005 — 2.02, 9.01
- 2013-12-16 0001193125-13-474388 — 5.07
- 2013-11-22 0001193125-13-451511 — 5.02
- 2013-11-07 0001511737-13-000018 — 2.02, 9.01
- 2013-10-28 0001193125-13-413414 — 5.02, 9.01
- 2013-10-18 0001193125-13-404111 — 5.02, 9.01
- 2013-08-08 0001511737-13-000009 — 2.02, 9.01
- 2013-05-09 0001511737-13-000004 — 2.02
- 2013-03-25 0001193125-13-124353 — 5.07
- 2013-03-08 0001193125-13-098334 — 5.02, 9.01
- 2013-02-07 0001193125-13-043701 — 2.02, 9.01
- 2012-12-28 0001193125-12-518487 — 1.01
- 2012-12-17 0001193125-12-503742 — 7.01, 9.01
- 2012-12-13 0001193125-12-501894 — 5.02
- 2012-11-16 0001193125-12-474083 — 5.02
- 2012-11-13 0001193125-12-467376 — 5.02
- 2012-11-08 0001193125-12-460665 — 2.02, 9.01
- 2012-10-10 0001193125-12-420015 — 5.02, 9.01
- 2012-08-13 0001193125-12-352624 — 1.01, 2.03, 9.01
- 2012-08-09 0001193125-12-347776 — 1.01, 9.01
- 2012-08-09 0001193125-12-347732 — 2.02, 9.01
- 2012-05-01 0001193125-12-201012 — 2.02, 9.01
- 2012-03-30 0001193125-12-144074 — 5.02
- 2012-03-27 0001193125-12-134395 — 5.02, 9.01
- 2012-03-22 0001193125-12-127536 — 5.02
- 2012-01-31 0001193125-12-032079 — 2.02, 9.01
- 2011-12-27 0001193125-11-353002 — 1.01, 9.01
- 2011-12-06 0001193125-11-332192 — 5.02
- 2011-11-10 0001193125-11-306969 — 2.02, 9.01

## late-filing notifications on or before 2017-05-04

- none on or before 2017-05-04

## item 2.02 — earnings release, exhibit 99.1

[0001415889-17-000692:8k_2_02:1]
EX-99
2
ex99-05042017_010521.htm

[0001415889-17-000692:8k_2_02:2]
Blueprint

[0001415889-17-000692:8k_2_02:3]
UBIQUITI NETWORKS REPORTS THIRD QUARTER FISCAL 2017 FINANCIAL
RESULTS

[0001415889-17-000692:8k_2_02:4]
~ Achieves Record Revenue and Seventh Consecutive Quarter of
Revenue Growth ~

[0001415889-17-000692:8k_2_02:5]
San
Jose, CA – May 4, 2017 - Ubiquiti Networks, Inc. (NASDAQ:
UBNT) (“Ubiquiti” or the “Company”) today
announced results for its fiscal 2017 third quarter ended March 31,
2017.

[0001415889-17-000692:8k_2_02:6]
Third Quarter Fiscal 2017 Financial Summary

[0001415889-17-000692:8k_2_02:7]
●

[0001415889-17-000692:8k_2_02:8]
Record quarterly revenues of $218.4 million, increasing 30%
year-over-year

[0001415889-17-000692:8k_2_02:9]
●

[0001415889-17-000692:8k_2_02:10]
GAAP gross profit and non-GAAP gross profit of $99.1
million

[0001415889-17-000692:8k_2_02:11]
●

[0001415889-17-000692:8k_2_02:12]
GAAP net income of $64.4 million and non-GAAP net income of $64.6
million, increasing 22% year-over-year

[0001415889-17-000692:8k_2_02:13]
●

[0001415889-17-000692:8k_2_02:14]
GAAP diluted EPS of $0.77 and non-GAAP diluted EPS of
$0.78

[0001415889-17-000692:8k_2_02:15]
Third Quarter Financial Highlights

[0001415889-17-000692:8k_2_02:16]
●

[0001415889-17-000692:8k_2_02:17]
Revenues increased 30% year-over-year and 2%
sequentially, primarily driven by continued
strong demand for the Company’s UniFi product family, new
AmpliFi consumer products, and solid demand for new AC technology
offerings for the Ubiquiti service provider community.

[0001415889-17-000692:8k_2_02:18]
●

[0001415889-17-000692:8k_2_02:19]
Enterprise Technology revenues surpassed
Service Provider Technology revenues for the first time in Company
history and increased 60% year-over-year and 16%
sequentially. Year-over-year growth was
primarily fueled by continued adoption of the Company’s UniFi
AC access points, UniFi Switch, UniFi Video and other
industry-leading products targeting the Enterprise market.
Enterprise revenues also benefitted from strong sales of the
Company’s new consumer products.

[0001415889-17-000692:8k_2_02:20]
●

[0001415889-17-000692:8k_2_02:21]
Service Provider Technology revenues increased
9% year-over-year, primarily driven by demand for new
offerings for the Ubiquiti service provider community.

[0001415889-17-000692:8k_2_02:22]
●

[0001415889-17-000692:8k_2_02:23]
Non-GAAP diluted EPS increased 24%
year-over-year, demonstrating the continued scalability of
Ubiquiti’s unique business model, and sustaining a 30% net
income margin trend, well above industry averages of less than
20%.

[0001415889-17-000692:8k_2_02:24]
●

[0001415889-17-000692:8k_2_02:25]
Gross margin of 45.4%, representing an increase
on a sequential basis and a decline of 4% on a
year-over-year basis. Third quarter gross margin was negatively
impacted by product mix, which was weighted toward newer products
that are early in the cost curve.

[0001415889-17-000692:8k_2_02:26]
●

[0001415889-17-000692:8k_2_02:27]
Repurchased $96.3 million of common
stock, repurchasing 1,932,411 shares at an average price of
$49.82 per share.

[0001415889-17-000692:8k_2_02:28]
●

[0001415889-17-000692:8k_2_02:29]
Amended the Company’s Credit
Agreement on April 14, 2017, providing an additional $100
million of availability under the Company’s revolving credit
facility.

[0001415889-17-000692:8k_2_02:30]
Recent Product Highlights

[0001415889-17-000692:8k_2_02:31]
●

[0001415889-17-000692:8k_2_02:32]
Began shipping UniFi AC HD access points in
volume, bringing the industry's highest performance 802.11ac
Wave 2 technology to the masses at a disruptive price point of only
$349 (MSRP).

[0001415889-17-000692:8k_2_02:33]
●

[0001415889-17-000692:8k_2_02:34]
Announced the UniFi AC In-Wall access
point, designed to convert an Ethernet wall connection into
a dual-band 802.11ac Wi-Fi access point with powerful 802.3at PoE+
functionality.  This product is ideal for several verticals in
the Enterprise segment including healthcare, education, hospitality
and others that want to introduce per-room Wi-Fi.

[0001415889-17-000692:8k_2_02:35]
●

[0001415889-17-000692:8k_2_02:36]
Launched airMAX AC GEN2, bringing
significant breakthroughs in network performance, usability and
backwards compatibility to Ubiquiti's service provider customers
and expanding Ubiquiti's strength in dense urban environments,
beyond its traditional strength in rural and remote
areas.

[0001415889-17-000692:8k_2_02:37]
●

[0001415889-17-000692:8k_2_02:38]
Announced the distribution of
AmpliFi products in the consumer
retail channel, including Best Buy, GameStop and Sam’s
Club, with an anticipated gradual roll-out beginning in the fourth
fiscal quarter of 2017 to hundreds of stores in the U.S. in
addition to existing availability on Amplifi.com and
Amazon.com.

[0001415889-17-000692:8k_2_02:39]
●

[0001415889-17-000692:8k_2_02:40]
Released significant updates to the UniFi
Mobile App, allowing Ubiquiti's Enterprise customers to
provision a UniFi access point without configuring a UniFi
controller, and the UMobile
App, a convenient client application allowing service
provider customers to install airMAX devices.

[0001415889-17-000692:8k_2_02:41]
Financial Highlights ($, in millions, except per share
data)

[0001415889-17-000692:8k_2_02:42]
| Income statement highlights |  | F3Q17 |  | F2Q17 |  | F3Q16 |
| Revenues |  | 218.4 |  | 213.5 |  | 167.4 |
| Service provider Technology |  | 104.7 |  | 115.6 |  | 96.2 |
| Enterprise Technology |  | 113.6 |  | 98.0 |  | 71.2 |
| Gross profit |  | 99.1 |  | 95.1 |  | 82.5 |
| Gross Profit (%) |  | 45.4% |  | 44.6% |  | 49.3% |
| Total Operating Expenses |  | 25.7 |  | 25.3 |  | 22.4 |
| Income from Operations |  | 73.4 |  | 69.8 |  | 60.1 |
| GAAP Net Income |  | 64.4 |  | 60.6 |  | 52.7 |
| GAAP EPS (diluted) |  | 0.77 |  | 0.72 |  | 0.62 |
| Non-GAAP Net Income |  | 64.6 |  | 60.1 |  | 53.0 |
| Non-GAAP EPS (diluted) |  | 0.78 |  | 0.72 |  | 0.63 |

[0001415889-17-000692:8k_2_02:43]
Balance Sheet Highlights

[0001415889-17-000692:8k_2_02:44]
Total
cash and cash equivalents as of March 31, 2017 were $533.9 million,
compared with $612.7 million as of December 31, 2016. The Company
held $511.8 million of cash and cash equivalents in accounts of the
Company’s subsidiaries outside of the United States. We
repurchased $96.3 million of common stock during the quarter,
repurchasing 1,932,411 shares at an average price of $49.82 per
share. Additionally, we amended the Company’s Credit
Agreement, providing an additional $100 million of availability
under our revolving credit facility, effective as of April 14,
2017.

[0001415889-17-000692:8k_2_02:45]
This
quarter the Company experienced an increase in days sales
outstanding in accounts receivable ("DSO") to 52 days, compared
with 50 days in the prior quarter. DSO’s have increased over
time and we expect this increase to continue as the mix of the
Company’s distributors evolves toward larger volumes of
products moving through large distributors who qualify for credit
terms. Enabling these distributors to purchase higher volumes of
products on credit terms allows them to shorten the cash conversion
cycle and has helped enable Ubiquiti to significantly expand its
market share while maintaining a conservative customer credit
profile.

[0001415889-17-000692:8k_2_02:46]
Ubiquiti
has invested in inventory to reduce lead times, meet increasing
demand and support the commensurate growth of the Company’s
customers. The Company is committed to
optimizing inventory to correspond with end-market demand. Finished
goods inventory at the end of the quarter increased $27.5 million
to $122.8 million, primarily driven by increased inventory of our
newer products. The Company expects to hold 8 to 12 weeks of
previously introduced product inventory in warehouses going
forward, in addition to new product inventory and selected raw
materials.

[0001415889-17-000692:8k_2_02:47]
Business Outlook

[0001415889-17-000692:8k_2_02:48]
Based
on recent business trends, the Company believes the demand
environment in its end markets supports the following forecast for
the Company's fiscal fourth quarter ending June 30,
2017:

[0001415889-17-000692:8k_2_02:49]
●

[0001415889-17-000692:8k_2_02:50]
Revenues of
$215-$225 million;

[0001415889-17-000692:8k_2_02:51]
●

[0001415889-17-000692:8k_2_02:52]
GAAP diluted EPS of
$0.69-$0.74 and non-GAAP diluted EPS of $0.70-$0.75;

[0001415889-17-000692:8k_2_02:53]
●

[0001415889-17-000692:8k_2_02:54]
Gross margins are
expected to remain consistent on a sequential basis;

[0001415889-17-000692:8k_2_02:55]
●

[0001415889-17-000692:8k_2_02:56]
Research and
Development costs are expected to range between 9% and 10% of
revenue during the fourth quarter, reflecting non-recurring
engineering milestone payments as well as increased R&D
staffing; and

[0001415889-17-000692:8k_2_02:57]
●

[0001415889-17-000692:8k_2_02:58]
An effective tax
rate of 10% including the expected benefit from discrete
items.

[0001415889-17-000692:8k_2_02:59]
Conference Call Information

[0001415889-17-000692:8k_2_02:60]
Ubiquiti
Networks will host a Q&A-only call to discuss the
Company’s financial results at 5:30 p.m. Eastern Time (2:30
p.m. Pacific Time) today. Management’s prepared remarks can
be found on the Investor Relations section of the Ubiquiti Networks
website, http://ir.ubnt.com/results.cfm.

[0001415889-17-000692:8k_2_02:61]
To
listen to the Q&A call via telephone, dial (877) 291-1296 (U.S.
toll-free) or (720) 259-9209 (International) Conference ID:
97551818. Participants should dial in at least 10 minutes prior to
the start of the call. Investors may also listen to a live webcast
of the Q&A conference call by visiting the Investor Relations
section of the Ubiquiti Networks website at http://ir.ubnt.com.

[0001415889-17-000692:8k_2_02:62]
A
recording of the Q&A call will be available approximately two
hours after the call concludes and will be accessible on the
Investor Relations section of the Ubiquiti Networks website,
http://ir.ubnt.com.

[0001415889-17-000692:8k_2_02:63]
About Ubiquiti Networks

[0001415889-17-000692:8k_2_02:64]
Ubiquiti
Networks, Inc. (Nasdaq: UBNT) eliminates barriers to connectivity
for under-networked enterprises, communities and consumers with its
leading-edge platforms that connect hundreds of millions of people
throughout the world.  With over 60 million devices sold
worldwide, through a network of over 100 distributors, to customers
in more than 180 countries and territories, Ubiquiti has maintained
an industry-leading financial profile by leveraging a unique
business model to develop products that combine innovative
technology with disruptive price-to-performance
characteristics.  Our growth is supported by the Ubiquiti
Community, a global grass-roots community of 4 million
entrepreneurial operators and systems integrators who engage in
thousands of forums.  For more information, join our community
at http://www.ubnt.com.

[0001415889-17-000692:8k_2_02:65]
Ubiquiti,
Ubiquiti Networks, the U logo, UBNT, airMAX, UniFi, airFiber, mFi,
EdgeMAX and AmpliFi are registered trademarks or trademarks of
Ubiquiti Networks, Inc. in the United States and other
countries.

[0001415889-17-000692:8k_2_02:66]
Investor Relations Contact

[0001415889-17-000692:8k_2_02:67]
Laura
Kiernan

[0001415889-17-000692:8k_2_02:68]
SVP
Investor Relations

[0001415889-17-000692:8k_2_02:69]
Ubiquiti
Networks

[0001415889-17-000692:8k_2_02:70]
laura.kiernan@ubnt.com

[0001415889-17-000692:8k_2_02:71]
Ph. 1-914-598-7733

[0001415889-17-000692:8k_2_02:72]
Forward-looking
statements are subject to certain risks and uncertainties that
could cause our actual future results to differ materially, or
cause a material adverse impact on our results. Potential risks and
uncertainties include, but are not limited to, fluctuations in our
operating results; varying demand for our products due to the
financial and operating condition of our distributors and their
customers, and distributors' inventory management practices;
political and economic conditions and volatility affecting the
stability of business environments, economic growth, currency
values, commodity prices and other factors that may influence the
ultimate demand for our products in particular geographies or
globally; impact of counterfeiting and our ability to contain such
impact; our reliance on a limited number of distributors; inability
of our contract manufacturers and suppliers to meet our demand; our
dependence on Qualcomm Atheros for chipsets without a short-term
alternative; as we move into new markets competition from certain
of our current or potential competitors who may be more established
in such markets; our ability to keep pace with technological and
market developments; success and timing of new product
introductions by us and the performance of our products generally;
our ability to effectively manage the significant increase in our
transactional sales volumes; we may become subject to warranty
claims, product liability and product recalls; that a substantial
majority of our sales are into countries outside the United States
and we are subject to numerous U.S. export control and economic
sanctions laws; costs related to responding to government inquiries
related to regulatory compliance; our reliance on the Ubiquiti
Community; our reliance on certain key members of our management
team, including our founder and chief executive officer, Robert J.
Pera; adverse tax-related matters such as tax audits, changes in
our effective tax rate or new tax legislative proposals; whether
the final determination of our income tax liability may be
materially different from our income tax provisions; the impact of
any intellectual property litigation and claims for
indemnification; litigation related to U.S. Securities laws; and
economic and political conditions in the United States and abroad.
We discuss these risks in greater detail under the heading
“Risk Factors” and elsewhere in our Annual Report on
Form 10-K for the year ended June 30, 2016, and subsequent
filings filed with the U.S. Securities and Exchange Commission (the
“SEC”), which are available at the SEC's website at
www.sec.gov. Copies may also be obtained by contacting the Ubiquiti
Networks Investor Relations Department, by email at IR@ubnt.com or
by visiting the Investor Relations section of the Ubiquiti Networks
website, http://ir.ubnt.com.

[0001415889-17-000692:8k_2_02:73]
Given
these uncertainties, you should not place undue reliance on these
forward-looking statements. Also, forward-looking statements
represent our management's beliefs and assumptions only as of the
date made. Except as required by law, Ubiquiti Networks undertakes
no obligation to update information contained herein. You should
review our SEC filings carefully and with the understanding that
our actual future results may be materially different from what we
expect.

[0001415889-17-000692:8k_2_02:74]
| Ubiquiti Networks Inc. Condensed Consolidated Statement of Operations (In thousands, except per share data) (Unaudited) |
|  |  | Three Months Ended March 31, |  | Nine Months Ended March 31, |
|  |  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Revenues |  | $ | 218,359 |  |  | $ | 167,433 |  |  | $ | 636,652 |  |  | $ | 480,719 |  |
| Cost of revenues |  | 119,273 |  |  | 84,940 |  |  | 344,123 |  |  | 245,681 |  |
| Gross profit |  | 99,086 |  |  | 82,493 |  |  | 292,529 |  |  | 235,038 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Research and development |  | 16,603 |  |  | 13,820 |  |  | 47,480 |  |  | 42,810 |  |
| Sales, general and administrative |  | 9,074 |  |  | 8,538 |  |  | 26,938 |  |  | 24,113 |  |
| Business e-mail compromise (“BEC”) fraud loss/(recovery) |  | — |  |  | (3 | ) |  | — |  |  | (8,294 | ) |
| Total operating expenses |  | 25,677 |  |  | 22,355 |  |  | 74,418 |  |  | 58,629 |  |
| Income from operations |  | 73,409 |  |  | 60,138 |  |  | 218,111 |  |  | 176,409 |  |
| Interest expense and other, net |  | (1,038 | ) |  | (510 | ) |  | (3,307 | ) |  | (1,277 | ) |
| Income before provision for income taxes |  | 72,371 |  |  | 59,628 |  |  | 214,804 |  |  | 175,132 |  |
| Provision for income taxes |  | 7,939 |  |  | 6,929 |  |  | 17,976 |  |  | 19,222 |  |
| Net income and comprehensive income |  | $ | 64,432 |  |  | $ | 52,699 |  |  | $ | 196,828 |  |  | $ | 155,910 |  |
| Net income per share of common stock: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.79 |  |  | $ | 0.63 |  |  | $ | 2.40 |  |  | $ | 1.83 |  |
| Diluted |  | $ | 0.77 |  |  | $ | 0.62 |  |  | $ | 2.35 |  |  | $ | 1.80 |  |
| Weighted average shares used in computing net income per share of common stock: |  |  |  |  |  |  |  |  |
| Basic |  | 81,652 |  |  | 83,349 |  |  | 81,879 |  |  | 85,051 |  |
| Diluted |  | 83,317 |  |  | 84,685 |  |  | 83,694 |  |  | 86,433 |  |

[0001415889-17-000692:8k_2_02:75]
Use of Non-GAAP Financial Information

[0001415889-17-000692:8k_2_02:76]
To
supplement our condensed consolidated financial results prepared
under generally accepted accounting principles, or GAAP, we use
non-GAAP measures of net income and earnings per diluted share that
are adjusted to exclude certain costs, expenses and gains such as
stock based compensation expense, Business e-mail compromise
("BEC") fraud loss/(recovery), implementation of overhead
capitalization, the adoption of ASU 2016-09 Improvements to
Employee Share-Based Payments Accounting and the tax effects of
these non-GAAP adjustments. Reconciliations of the adjustments to
GAAP results for the three and nine month periods ended March 31,
2017 and 2016 are provided below. In addition, an explanation of
the ways in which management uses non-GAAP financial information to
evaluate its business, the substance behind management's decision
to use this non-GAAP financial information, material limitations
associated with the use of non-GAAP financial information, the
manner in which management compensates for those limitations, and
the substantive reasons management believes that this non-GAAP
financial information provides useful information to investors is
included under "About our Non-GAAP Net Income and Adjustments"
after the tables below.

[0001415889-17-000692:8k_2_02:77]
| Ubiquiti Networks Inc. Reconciliation of GAAP Net Income to Non-GAAP Net Income (In thousands, except per share data) (Unaudited) |
|  |  | Three Months Ended March 31, |  | Nine Months Ended March 31, |
|  |  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Net income and comprehensive income |  | $ | 64,432 |  |  | $ | 52,699 |  |  | $ | 196,828 |  |  | $ | 155,910 |  |
| Stock-based compensation: |  |  |  |  |  |  |  |  |
| Cost of revenues |  | 39 |  |  | 114 |  |  | 213 |  |  | 341 |  |
| Research and development |  | 421 |  |  | 566 |  |  | 1,362 |  |  | 1,770 |  |
| Sales, general and administrative |  | 141 |  |  | 202 |  |  | 519 |  |  | 755 |  |
| Business e-mail compromise (“BEC”) fraud loss/(recovery) |  | — |  |  | (3 | ) |  | — |  |  | (8,294 | ) |
| Excess tax benefits resulting from the adoption of ASU 2016-09 Stock Compensation |  | (179 | ) |  | — |  |  | (7,859 | ) |  | — |  |
| Implementation of overhead capitalization |  | — |  |  | (219 | ) |  | — |  |  | (1,213 | ) |
| Tax effect of Non-GAAP adjustments |  | (240 | ) |  | (327 | ) |  | (837 | ) |  | (1,002 | ) |
| Non-GAAP net income |  | $ | 64,614 |  |  | $ | 53,032 |  |  | $ | 190,226 |  |  | $ | 148,267 |  |
| Non-GAAP diluted EPS |  | $ | 0.78 |  |  | $ | 0.63 |  |  | $ | 2.29 |  |  | $ | 1.72 |  |
| Shares outstanding (Diluted) |  | 83,317 |  |  | 84,685 |  |  | 83,694 |  |  | 86,433 |  |
| Share adjustment (ASU 2016-09 Adoption) |  | (635 | ) |  | — |  |  | (689 | ) |  | — |  |
| Weighted-average shares used in Non-GAAP diluted EPS |  | 82,682 |  |  | 84,685 |  |  | 83,005 |  |  | 86,433 |  |

[0001415889-17-000692:8k_2_02:78]
| Ubiquiti Networks Inc. Condensed Consolidated Balance Sheets (In thousands, except share amounts) (Unaudited) |
|  |  | March 31, 2017 |  | June 30, 2016 (1) |
| Assets |  |  |  |  |
| Current assets: |  |  |  |  |
| Cash and cash equivalents |  | $ | 533,944 |  |  | $ | 551,031 |  |
| Accounts receivable, net |  | 125,341 |  |  | 82,790 |  |
| Inventories |  | 132,512 |  |  | 57,113 |  |
| Vendor Deposits |  | 49,779 |  |  | 30,255 |  |
| Prepaid income taxes |  | 10,902 |  |  | 299 |  |
| Prepaid expenses and other current assets |  | 10,233 |  |  | 6,896 |  |
| Total current assets |  | 862,711 |  |  | 728,384 |  |
| Property and equipment, net |  | 13,345 |  |  | 12,953 |  |
| Long-term deferred tax assets |  | 4,038 |  |  | 4,195 |  |
| Other long-term assets |  | 1,937 |  |  | 1,576 |  |
| Total assets |  | $ | 882,031 |  |  | $ | 747,108 |  |
| Liabilities and Stockholders’ Equity |  |  |  |  |
| Current liabilities: |  |  |  |  |
| Accounts payable |  | $ | 53,411 |  |  | $ | 51,510 |  |
| Income taxes payable |  | 1,268 |  |  | 1,488 |  |
| Debt - short-term |  | 14,743 |  |  | 10,993 |  |
| Other current liabilities |  | 29,681 |  |  | 26,672 |  |
| Total current liabilities |  | 99,103 |  |  | 90,663 |  |
| Long-term taxes payable |  | 26,846 |  |  | 23,202 |  |
| Debt - long-term |  | 210,507 |  |  | 191,564 |  |
| Deferred revenues - long-term |  | 2,537 |  |  | 1,303 |  |
| Total liabilities |  | 338,993 |  |  | 306,732 |  |
| Stockholders’ equity: |  |  |  |  |
| Common stock |  | 80 |  |  | 82 |  |
| Additional paid–in capital |  | — |  |  | — |  |
| Retained earnings |  | 542,958 |  |  | 440,294 |  |
| Total stockholders’ equity |  | 543,038 |  |  | 440,376 |  |
| Total liabilities and stockholders’ equity |  | $ | 882,031 |  |  | $ | 747,108 |  |

[0001415889-17-000692:8k_2_02:79]
(1)
Derived from audited consolidated financial statements as of and
for the year ended June 30, 2016.

[0001415889-17-000692:8k_2_02:80]
| Ubiquiti Networks Inc. Revenues by Product Type (In thousands) (Unaudited) |
|  |  | Three Months Ended March 31, |  | Nine Months Ended March 31, |
|  |  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Service provider technology |  | $ | 104,724 |  |  | $ | 96,215 |  |  | $ | 340,936 |  |  | $ | 309,230 |  |
| Enterprise technology |  | 113,635 |  |  | 71,218 |  |  | 295,716 |  |  | 171,489 |  |
| Total revenues |  | $ | 218,359 |  |  | $ | 167,433 |  |  | $ | 636,652 |  |  | $ | 480,719 |  |

[0001415889-17-000692:8k_2_02:81]
| Ubiquiti Networks Inc. Revenues by Geographical Area (In thousands) (Unaudited) |
|  |  | Three Months Ended March 31, |  | Nine Months Ended March 31, |
|  |  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| North America |  | $ | 78,573 |  |  | $ | 57,791 |  |  | $ | 247,347 |  |  | $ | 168,428 |  |
| South America |  | 27,770 |  |  | 15,450 |  |  | 71,240 |  |  | 61,123 |  |
| Europe, the Middle East and Africa ("EMEA") |  | 87,780 |  |  | 73,269 |  |  | 246,536 |  |  | 194,745 |  |
| Asia Pacific |  | 24,236 |  |  | 20,923 |  |  | 71,529 |  |  | 56,423 |  |
| Total revenues |  | $ | 218,359 |  |  | $ | 167,433 |  |  | $ | 636,652 |  |  | $ | 480,719 |  |

[0001415889-17-000692:8k_2_02:82]
About our Non-GAAP
Net Income and Adjustments

[0001415889-17-000692:8k_2_02:83]
Use of Non-GAAP Financial Information

[0001415889-17-000692:8k_2_02:84]
To
supplement our condensed consolidated financial results prepared
under generally accepted accounting principles, or GAAP, we use
non-GAAP measures of net income and earnings per diluted share that
are GAAP net income and GAAP earnings per diluted share adjusted to
exclude certain costs, expenses and gains/losses.

[0001415889-17-000692:8k_2_02:85]
We
believe that the presentation of non-GAAP net income and non-GAAP
earnings per diluted share provides important supplemental
information regarding non-cash expenses, significant items that we
believe are important to understanding our financial, and business
trends relating to our financial condition and results of
operations. Non-GAAP net income and non-GAAP earnings per diluted
share are among the primary indicators used by management as a
basis for planning and forecasting future periods and by management
and our board of directors to determine whether our operating
performance has met specified targets and thresholds. Management
uses non-GAAP net income and non-GAAP earnings per diluted share
when evaluating operating performance because it believes that the
exclusion of the items described below, for which the amounts or
timing may vary significantly depending upon the Company's
activities and other factors, facilitates comparability of the
Company's operating performance from period to period. We have
chosen to provide this information to investors so they can analyze
our operating results in the same way that management does and use
this information in their assessment of our business and the
valuation of our Company.

[0001415889-17-000692:8k_2_02:86]
Use and Economic Substance of Non-GAAP Financial Measures used by
Ubiquiti Networks

[0001415889-17-000692:8k_2_02:87]
We
compute non-GAAP net income and non-GAAP earnings per diluted share
by adjusting GAAP net income and GAAP earnings per diluted share to
remove the impact of certain adjustments and the tax effect of
those adjustments. Items excluded from net income are:

[0001415889-17-000692:8k_2_02:88]
●

[0001415889-17-000692:8k_2_02:89]
Stock-based
compensation expense

[0001415889-17-000692:8k_2_02:90]
●

[0001415889-17-000692:8k_2_02:91]
Business e-mail
compromise ("BEC") fraud loss/(recovery)

[0001415889-17-000692:8k_2_02:92]
●

[0001415889-17-000692:8k_2_02:93]
Implementation of
overhead capitalization

[0001415889-17-000692:8k_2_02:94]
●

[0001415889-17-000692:8k_2_02:95]
Adoption of ASU
2016-09 Improvements to Employee Share-Base Payment
Accounting

[0001415889-17-000692:8k_2_02:96]
●

[0001415889-17-000692:8k_2_02:97]
Tax effect of
non-GAAP adjustments, applying the principles of ASC
740

[0001415889-17-000692:8k_2_02:98]
Usefulness of Non-GAAP Financial Information to
Investors

[0001415889-17-000692:8k_2_02:99]
These
non-GAAP measures are not in accordance with, or an alternative to,
GAAP and may be materially different from other non-GAAP measures,
including similarly titled non-GAAP measures used by other
companies. The presentation of this additional information should
not be considered in isolation from, as a substitute for, or
superior to, net income or earnings per diluted share prepared in
accordance with GAAP. Non-GAAP financial measures have limitations
in that they do not reflect certain items that may have a material
impact upon our reported financial results. We expect to continue
to incur expenses of a nature similar to the non-GAAP adjustments
described above, and exclusion of these items from our non-GAAP net
income and non-GAAP earnings per diluted share should not be
construed as an inference that these costs are unusual, infrequent
or non-recurring.

[0001415889-17-000692:8k_2_02:100]
For
more information on the non-GAAP adjustments, please see the table
captioned “Reconciliation of GAAP Net Income to Non-GAAP Net
Income” included in this press release.
