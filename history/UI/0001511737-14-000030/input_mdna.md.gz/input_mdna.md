# UI MD&A — 0001511737-14-000030


## mdna

[0001511737-14-000030:mdna:1]
[same as prior period, unchanged from 0001511737-14-000018:mdna:1]

[0001511737-14-000030:mdna:2]
Ubiquiti Networks develops high performance networking technology for service providers and enterprises. Our technology platforms focus on delivering highly-advanced and easily deployable solutions that appeal to a global customer base in underserved and underpenetrated markets. Our differentiated business model has enabled us to break down traditional barriers such as high product and network deployment costs and offer solutions with disruptive price-performance characteristics. This differentiated business model, combined with our innovative proprietary technologies, has resulted in an attractive alternative to traditional high touch, high cost providers, allowing us to advance the market adoption of our platforms for ubiquitous connectivity.

[0001511737-14-000030:mdna:3]
We offer a broad and expanding portfolio of networking products and solutions for service providers and enterprises. Our service provider product platforms provide carrier-class network infrastructure for fixed wireless broadband, wireless backhaul systems and routing. Our enterprise product platforms provide wireless LAN infrastructure, video surveillance products, and machine-to-machine communication components. We believe that our products are highly differentiated due to our proprietary software protocol innovation, firmware expertise, and hardware design capabilities. This differentiation allows our portfolio to meet the demanding performance requirements of video, voice and data applications at prices that are a fraction of those offered by our competitors.

[0001511737-14-000030:mdna:4]
As a core part of our strategy, we have developed a differentiated business model for marketing and selling high volumes of carrier and enterprise-class communications platforms. Our business model is driven by a large, growing and highly engaged community of service providers, distributors, value added resellers, systems integrators and corporate IT professionals, which we refer to as the Ubiquiti Community. The Ubiquiti Community is a critical element of our business strategy as it enables us to drive:

[0001511737-14-000030:mdna:5]
[same as prior period, unchanged from 0001511737-14-000018:mdna:8]

[0001511737-14-000030:mdna:6]
[same as prior period, unchanged from 0001511737-14-000018:mdna:9]

[0001511737-14-000030:mdna:7]
[same as prior period, unchanged from 0001511737-14-000018:mdna:10]

[0001511737-14-000030:mdna:8]
By reducing the cost of development, sales, marketing and support we are able to eliminate traditional business model inefficiencies and offer innovative solutions with disruptive price performance characteristics to our customers.

[0001511737-14-000030:mdna:9]
Our revenues increased 16% to $150.1 million in the three months ended September 30, 2014 from $129.7 million in the three months ended September 30, 2013.  We believe the overall increase in revenues during the three months ended September 30, 2014 was driven by increased adoption of our service provider and enterprise technologies.  We had net income of $37.7 million and $40.5 million in the three months ended September 30, 2014 and 2013, respectively.  The increase in net income in the three months ended September 30, 2014 as compared to the same period in the prior year was primarily due to the increase in revenues.

[0001511737-14-000030:mdna:10]
[same as prior period, unchanged from 0001511737-14-000018:mdna:13]

[0001511737-14-000030:mdna:11]
[same as prior period, unchanged from 0001511737-14-000018:mdna:14]

[0001511737-14-000030:mdna:12]
[same as prior period, unchanged from 0001511737-14-000018:mdna:15]

[0001511737-14-000030:mdna:13]
[same as prior period, unchanged from 0001511737-14-000018:mdna:16]

[0001511737-14-000030:mdna:14]
| • | Service Provider Technology includes our airMAX, EdgeMAX and airFiber platforms, as well as embedded radio products and other 802.11 standard products including base stations, radios, backhaul equipment and Customer Premise Equipment (“CPE”). Additionally, Service Provider Technology includes antennas and other products in the 2.0 to 6.0GHz spectrum and miscellaneous products such as mounting brackets, cables and power over Ethernet adapters. Service Provider Technology also includes revenues that are attributable to post contract support ("PCS"). |

[0001511737-14-000030:mdna:15]
| • | Enterprise Technology includes the Company's UniFi, mFi and UniFi Video platforms. |

[0001511737-14-000030:mdna:16]
We sell substantially all of our products through a limited number of distributors and other channel partners, such as resellers and OEMs. Sales to distributors accounted for 98% of our revenues in the three months ended September 30, 2014.  Other channel partners, such as resellers and OEMs, largely accounted for the balance of our revenues.

[0001511737-14-000030:mdna:17]
[same as prior period, unchanged from 0001511737-14-000018:mdna:21]

[0001511737-14-000030:mdna:18]
[same as prior period, unchanged from 0001511737-14-000018:mdna:22]

[0001511737-14-000030:mdna:19]
[same as prior period, unchanged from 0001511737-14-000018:mdna:23]

[0001511737-14-000030:mdna:20]
[same as prior period, unchanged from 0001511737-14-000018:mdna:24]

[0001511737-14-000030:mdna:21]
[same as prior period, unchanged from 0001511737-14-000018:mdna:25]

[0001511737-14-000030:mdna:22]
16

[0001511737-14-000030:mdna:23]
[same as prior period, unchanged from 0001511737-14-000018:mdna:26]

[0001511737-14-000030:mdna:24]
[same as prior period, unchanged from 0001511737-14-000018:mdna:27]

[0001511737-14-000030:mdna:25]
| • | Research and development expenses consist primarily of salary and benefit expenses, including stock-based compensation, for employees and costs for contractors engaged in research, design and development activities, as well as costs for prototypes, purchased Intellectual Property ("IP"), facilities and travel. Over time, we expect our research and development costs to increase as we continue making significant investments in developing new products and developing new versions of our existing products. |

[0001511737-14-000030:mdna:26]
[same as prior period, unchanged from 0001511737-14-000018:mdna:29]

[0001511737-14-000030:mdna:27]
[same as prior period, unchanged from 0001511737-14-000018:mdna:30]

[0001511737-14-000030:mdna:28]
We recognize revenues when persuasive evidence of an arrangement exists, delivery has occurred, the sales price is fixed or determinable and the collectability of the resulting receivable is reasonably assured. In cases where we lack evidence that all of these criteria have been met, we defer recognition of revenue.  We classify the cost of products associated with these deferred revenues as deferred costs of revenues.

[0001511737-14-000030:mdna:29]
Also included in our deferred revenues is a portion related to PCS obligations that we estimate we will perform in the future. As of September 30, 2014 and June 30, 2014, we had deferred revenues of $3.1 million and $2.8 million respectively, related to these obligations.

[0001511737-14-000030:mdna:30]
[same as prior period, unchanged from 0001511737-14-000018:mdna:33]

[0001511737-14-000030:mdna:31]
We prepare our condensed consolidated financial statements in accordance with accounting principles generally accepted in the United States of America (“GAAP”). In many cases, the accounting treatment of a particular transaction is specifically dictated by GAAP and does not require management’s judgment in its application. In other cases, management’s judgment is required in selecting among available alternative accounting standards that provide for different accounting treatment for similar transactions. The preparation of condensed consolidated financial statements also requires us to make estimates and assumptions that affect the amounts we report as assets, liabilities, revenues, costs and expenses and affect the related disclosures. We base our estimates on historical experience and other assumptions that we believe are reasonable under the circumstances. In many instances, we could reasonably use different accounting estimates, and in some instances changes in the accounting estimates are reasonably likely to occur from period to period. Accordingly, our actual results could differ significantly from the estimates made by our management. To the extent that there are differences between our estimates and actual results, our future financial statement presentation, financial condition, results of operations and cash flows will be affected. Our critical accounting policies are discussed in our Annual Report on Form 10-K for the fiscal year ended June 30, 2014, as filed on August 22, 2014 with the SEC, or the Annual Report, and there have been no material changes.

[0001511737-14-000030:mdna:32]
[same as prior period, unchanged from 0001511737-14-000018:mdna:38]

[0001511737-14-000030:mdna:33]
Comparison of Three Months Ended September 30, 2014 and 2013

[0001511737-14-000030:mdna:34]
|  | Three Months Ended September 30, |
|  | 2014 |  | 2013 |
|  | (In thousands, except percentages) |
| Revenues | $ | 150,087 |  |  | 100 | % |  | $ | 129,687 |  |  | 100 | % |
| Cost of revenues(1)(2) | 89,036 |  |  | 59 | % |  | 71,664 |  |  | 55 | % |
| Gross profit | 61,051 |  |  | 41 | % |  | 58,023 |  |  | 45 | % |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development(1) | 11,721 |  |  | 8 | % |  | 6,317 |  |  | 5 | % |
| Sales, general and administrative(1) | 5,696 |  |  | 4 | % |  | 5,810 |  |  | 4 | % |
| Total operating expenses | 17,417 |  |  | 12 | % |  | 12,127 |  |  | 9 | % |
| Income from operations | 43,634 |  |  | 29 | % |  | 45,896 |  |  | 36 | % |
| Interest expense and other, net | (58 | ) |  | * |  |  | (246 | ) |  | * |  |
| Income before provision for income taxes | 43,576 |  |  | 29 | % |  | 45,650 |  |  | 35 | % |
| Provision for income taxes | 5,833 |  |  | 4 | % |  | 5,122 |  |  | 4 | % |
| Net income and comprehensive income | $ | 37,743 |  |  | 25 | % |  | $ | 40,528 |  |  | 31 | % |
| * Less than 1% |  |  |  |  |  |  |  |
| (1) Includes stock-based compensation as follows: |  |  |  |  |  |  |  |
| Cost of revenues | $ | 149 |  |  |  |  | $ | 144 |  |  |  |
| Research and development | 825 |  |  |  |  | 496 |  |  |  |
| Sales, general and administrative | 398 |  |  |  |  | 527 |  |  |  |
| Total stock-based compensation | $ | 1,372 |  |  |  |  | $ | 1,167 |  |  |  |
| (2) Includes purchase commitment termination fee | $ | 5,500 |  |  |  |  | $ | — |  |  |  |

[0001511737-14-000030:mdna:35]
[same as prior period, unchanged from 0001511737-14-000018:mdna:41]

[0001511737-14-000030:mdna:36]
Revenues increased $20.4 million, or 16%, driven by increased adoption of our service provider and enterprise technologies.

[0001511737-14-000030:mdna:37]
[same as prior period, unchanged from 0001511737-14-000018:mdna:44]

[0001511737-14-000030:mdna:38]
|  | Three Months Ended September 30, |
|  | 2014 |  | 2013 |
|  | (in thousands, except percentages) |
| Service Provider Technology | $ | 107,271 |  |  | 71 | % |  | $ | 94,217 |  |  | 73 | % |
| Enterprise Technology | 42,816 |  |  | 29 | % |  | 35,470 |  |  | 27 | % |
| Total revenues | $ | 150,087 |  |  | 100 | % |  | $ | 129,687 |  |  | 100 | % |

[0001511737-14-000030:mdna:39]
Revenues from Service Provider Technologies increased $13.1 million, or 14%, primarily due to continued expansion of core infrastructure build-outs in our wireless markets.

[0001511737-14-000030:mdna:40]
Enterprise Technology revenues increased $7.3 million, or 21%, due primarily to product expansion and further adoption of our UniFi technology platform.

[0001511737-14-000030:mdna:41]
[same as prior period, unchanged from 0001511737-14-000018:mdna:49]

[0001511737-14-000030:mdna:42]
We have determined the geographical distribution of our product revenues based on our customers' ship-to destinations. A majority of our sales are to distributors who in turn sell to resellers or directly to end customers, which may be different countries than the initial ship-to destination.  The following are our revenues by geography for the three months ended September 30, 2014 and 2013 (in thousands, except percentages):

[0001511737-14-000030:mdna:43]
|  | Three Months Ended September 30, |
|  | 2014 |  | 2013 |
| North America(1) | $ | 53,582 |  |  | 35 | % |  | $ | 37,433 |  |  | 29 | % |
| South America | 31,134 |  |  | 21 | % |  | 20,776 |  |  | 16 | % |
| Europe, the Middle East and Africa | 50,607 |  |  | 34 | % |  | 52,866 |  |  | 41 | % |
| Asia Pacific | 14,764 |  |  | 10 | % |  | 18,612 |  |  | 14 | % |
| Total revenues | $ | 150,087 |  |  | 100 | % |  | $ | 129,687 |  |  | 100 | % |

[0001511737-14-000030:mdna:44]
| (1) | Revenue for the United States was $52.0 million and $36.3 million for the three months ended September 30, 2014 and 2013, respectively. |

[0001511737-14-000030:mdna:45]
[same as prior period, unchanged from 0001511737-14-000018:mdna:54]

[0001511737-14-000030:mdna:46]
Cost of revenues increased $17.4 million, or 24%, from $71.7 million in the three months ended September 30, 2013 to $89.0 million in the three months ended September 30, 2014.  The increase in cost of revenues in the three months ended September 30, 2014 was primarily due to a non-recurring charge associated with a termination fee of $5.5 million for the cancellation of a purchase commitment.

[0001511737-14-000030:mdna:47]
Gross profit decreased to 41% in the three months ended September 30, 2014 compared to 45% in the three months ended September 30, 2013, primarily due to a non-recurring charge associated with a termination fee of $5.5 million for the cancellation of a purchase commitment.

[0001511737-14-000030:mdna:48]
[same as prior period, unchanged from 0001511737-14-000018:mdna:58]

[0001511737-14-000030:mdna:49]
[same as prior period, unchanged from 0001511737-14-000018:mdna:59]

[0001511737-14-000030:mdna:50]
Research and development expenses increased $5.4 million, or 86%, from $6.3 million in the three months ended September 30, 2013 to $11.7 million in the three months ended September 30, 2014.  As a percentage of revenues, research and development expenses increased from 5% in the three months ended September 30, 2013 to 8% in the three months ended September 30, 2014.  The increase in research and development expenses in absolute dollars and as a percentage of revenues was due to increases in headcount to support our strategy as we broadened our research and development activities to new product areas and certain one-time costs incurred for IP purchased for use in our products. Over time, we expect our research and development costs to increase in absolute dollars as we continue making investments in developing new products and developing new versions of our existing products.

[0001511737-14-000030:mdna:51]
[same as prior period, unchanged from 0001511737-14-000018:mdna:61]

[0001511737-14-000030:mdna:52]
Sales, general and administrative expenses during the three months ended September 30, 2013 remained relatively flat compared to the same period in the prior year.  Over time, we expect our sales, general and administrative expenses to increase in absolute dollars due to continued efforts to protect our intellectual property and growth in headcount to support our business and operations.

[0001511737-14-000030:mdna:53]
[same as prior period, unchanged from 0001511737-14-000018:mdna:63]

[0001511737-14-000030:mdna:54]
Interest expense and other, net was $58,000 for the three months ended September 30, 2014, representing a decrease of $188,000 from $246,000 for the three months ended September 30, 2013.  The decrease in interest expense and other, net during the three months ended September 30, 2014 compared to the same period in the prior year was primarily due to more favorable interest rates during the three months ended September 30, 2013 compared to the same period in the prior year.

[0001511737-14-000030:mdna:55]
[same as prior period, unchanged from 0001511737-14-000018:mdna:65]

[0001511737-14-000030:mdna:56]
Our provision for income taxes increased $711,000, or 14%, from $5.1 million for the three months ended September 30, 2013 to $5.8 million for the three months ended September 30, 2014. Our effective tax rate increased to 13% for the three months ended September 30, 2014 as compared to 11% the three months ended September 30, 2013.   The higher effective tax rate was primarily due to a smaller percentage of our overall profitability occurring in foreign jurisdictions with lower income tax rates.

[0001511737-14-000030:mdna:57]
[same as prior period, unchanged from 0001511737-14-000018:mdna:67]

[0001511737-14-000030:mdna:58]
[same as prior period, unchanged from 0001511737-14-000018:mdna:68]

[0001511737-14-000030:mdna:59]
Since inception, our operations primarily have been funded through cash generated by operations. Cash and cash equivalents increased from $347.1 million at June 30, 2014 to $391.0 million at September 30, 2014.

[0001511737-14-000030:mdna:60]
[same as prior period, unchanged from 0001511737-14-000018:mdna:70]

[0001511737-14-000030:mdna:61]
[same as prior period, unchanged from 0001511737-14-000018:mdna:71]

[0001511737-14-000030:mdna:62]
|  | Three Months Ended September 30, |
|  | 2014 |  | 2013 |
|  | (In thousands) |
| Net cash provided by operating activities | $ | 46,942 |  |  | $ | 51,880 |  |
| Net cash used in investing activities | (3,461 | ) |  | (460 | ) |
| Net cash provided by financing activities | 438 |  |  | 483 |  |
| Net increase in cash and cash equivalents | $ | 43,919 |  |  | $ | 51,903 |  |

[0001511737-14-000030:mdna:63]
[same as prior period, unchanged from 0001511737-14-000018:mdna:73]

[0001511737-14-000030:mdna:64]
Net cash provided by operating activities in the three months ended September 30, 2014 of $46.9 million consisted primarily of net income of $37.7 million and net changes in operating assets and liabilities that resulted in net cash inflows of $1.4 million. These changes consisted primarily of a $13.4 million increase in prepaid expenses and other current assets due to the timing of our payments and additional deposits with our suppliers, a $12.4 million increase in accounts payable and accrued liabilities due primarily to our increase in cost of revenues, a $6.9 million decrease in inventory due to our efforts to maintain optimal inventory levels and a $2.6 million increase in taxes payable due to the timing of federal tax payments.  Additionally, our net income included non-cash adjustments due to stock-based compensation, depreciation and amortization, increases to our provision for inventory obsolescence, a write-off of our intangible assets and an excess tax benefit from stock-based awards. The net of these non-cash adjustments resulted in an increase of our net cash provided by operating activities of $7.8 million.

[0001511737-14-000030:mdna:65]
Net cash provided by operating activities in the three months ended September 30, 2013 of $51.9 million consisted primarily of net income of $40.5 million and net changes in operating assets and liabilities that resulted in net cash inflows of $10.4 million. These changes consisted primarily of an $8.3 million increase in accounts payable and accrued liabilities due primarily to our increase in cost of revenues, a $2.0 million increase in taxes payable due to the timing of federal tax payments, a $1.0 million increase in inventory due to increased product demand and a $897,000 decrease in prepaid expenses and other current assets due to timing of our payments with our suppliers. Additionally, our net income included non-cash adjustments due to stock-based compensation, depreciation and amortization, increases to our provision for inventory obsolescence, a write-off of our intangible assets and an excess tax benefit from stock-based awards. The net of these non-cash adjustments resulted in an increase of our net cash provided by operating activities of $1.0 million.

[0001511737-14-000030:mdna:66]
[same as prior period, unchanged from 0001511737-14-000018:mdna:76]

[0001511737-14-000030:mdna:67]
Our investing activities consist solely of capital expenditures and purchases of intangible assets. Capital expenditures for the three months ended September 30, 2014 and 2013 were $3.4 million and $402,000, respectively. Additionally, we had cash outflows related to the purchase of intangible assets of $30,000 and $58,000 during the three months ended September 30, 2014 and 2013, respectively.  The increase in capital expenditures during the three months ended September 30, 2014 was primarily related to our prototype manufacturing facility in Suzhou, China which supports our strategy of developing our new products more rapidly.

[0001511737-14-000030:mdna:68]
[same as prior period, unchanged from 0001511737-14-000018:mdna:78]

[0001511737-14-000030:mdna:69]
We had $438,000 of cash provided by financing activities during the three months ended September 30, 2014, which consisted of cash received for stock option exercises of $456,000 and an excess tax benefit from employee stock-based awards of $782,000, partially offset by tax withholdings related to net share settlements of restricted stock units of $800,000.

[0001511737-14-000030:mdna:70]
We had $483,000 of cash provided by financing activities during the three months ended September 30, 2013, which consisted of an excess tax benefit from employee stock-based awards of $1.5 million and cash received for stock option exercises of $631,000, partially offset by repayments on our term loan balance with East West Bank of $1.3 million and tax withholdings related to net share settlements of restricted stock units of $410,000.

[0001511737-14-000030:mdna:71]
[same as prior period, unchanged from 0001511737-14-000018:mdna:37]

[0001511737-14-000030:mdna:72]
[same as prior period, unchanged from 0001511737-14-000018:mdna:84]

[0001511737-14-000030:mdna:73]
We believe our existing cash and cash equivalents, cash provided by operations and the availability of additional funds under our loan agreements will be sufficient to meet our working capital and capital expenditure needs for at least the next twelve months. However, this estimate is based on a number of assumptions that may prove to be wrong and we could exhaust our available cash and cash equivalents earlier than presently anticipated.  Our future capital requirements may vary materially from those currently planned and will depend on many factors, including our rate of revenue growth, the timing and extent of spending to support development efforts, the timing of new product introductions, market acceptance of our products and overall economic conditions.  As of September 30, 2014, we held $330.8 million of our $391.0 million of cash and cash equivalents in accounts of our subsidiaries outside of the United States and we will incur significant tax liabilities if we decide to repatriate those amounts.

[0001511737-14-000030:mdna:74]
Commitments and Contingencies

[0001511737-14-000030:mdna:75]
[same as prior period, unchanged from 0001511737-14-000018:mdna:87]

[0001511737-14-000030:mdna:76]
[same as prior period, unchanged from 0001511737-14-000018:mdna:88]

[0001511737-14-000030:mdna:77]
Our products are generally accompanied by a 12 month warranty, which covers both parts and labor. Generally the distributor is responsible for the freight costs associated with warranty returns, and we absorb the freight costs of replacing items under warranty. In accordance with the Financial Accounting Standards Board’s (“FASB’s”), Accounting Standards Codification (“ASC”), 450-30, Loss Contingencies, we record an accrual when we believe it is estimable and probable based upon historical experience. We record a provision for estimated future warranty work in cost of goods sold upon recognition of revenues and we review the resulting accrual regularly and periodically adjust it to reflect changes in warranty estimates.

[0001511737-14-000030:mdna:78]
[same as prior period, unchanged from 0001511737-14-000018:mdna:90]

[0001511737-14-000030:mdna:79]
We have agreed to indemnify our directors, officers and certain other employees for certain events or occurrences, subject to certain limits, while such persons are or were serving at our request in such capacity. We may terminate the indemnification agreements with these persons upon the termination of their services with us but termination will not affect claims for indemnification related to events occurring prior to the effective date of termination. The maximum amount of potential future indemnification is unlimited. We have a Directors and Officers insurance policy that limits our potential exposure. We believe the fair value of these indemnification agreements is minimal.  We had not recorded any liabilities for these agreements as of September 30, 2014.

[0001511737-14-000030:mdna:80]
Based upon our historical experience and information known as of the date of this report, we do not believe it is likely that we will have significant liability for the above indemnities at September 30, 2014.

[0001511737-14-000030:mdna:81]
[same as prior period, unchanged from 0001511737-14-000018:mdna:46]

[0001511737-14-000030:mdna:82]
[same as prior period, unchanged from 0001511737-14-000018:mdna:95]

[0001511737-14-000030:mdna:83]
The following table summarizes our contractual obligations as of September 30, 2014:

[0001511737-14-000030:mdna:84]
|  | 2015(remainder) |  | 2016 |  | 2017 |  | 2018 |  | 2019 |  | Thereafter |  | Total |
| Operating leases | $ | 2,277 |  |  | $ | 2,986 |  |  | $ | 1,648 |  |  | $ | 358 |  |  | $ | 53 |  |  | $ | — |  |  | $ | 7,322 |  |
| Debt payment obligations | — |  |  | — |  |  | — |  |  | — |  |  | 72,254 |  |  | — |  |  | 72,254 |  |
| Interest payments on debt payment obligations | 761 |  |  | 1,014 |  |  | 1,014 |  |  | 1,014 |  |  | 858 |  |  | — |  |  | 4,661 |  |
| Purchase obligations | 222 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 222 |  |
| Other obligations | 1,109 |  |  | 20 |  |  | 20 |  |  | 3 |  |  | — |  |  | — |  |  | 1,152 |  |
| Total | $ | 4,369 |  |  | $ | 4,020 |  |  | $ | 2,682 |  |  | $ | 1,375 |  |  | $ | 73,165 |  |  | $ | — |  |  | $ | 85,611 |  |

[0001511737-14-000030:mdna:85]
Operating Leases

[0001511737-14-000030:mdna:86]
[same as prior period, unchanged from 0001511737-14-000018:mdna:96]

[0001511737-14-000030:mdna:87]
Debt and Interest Payment Obligations

[0001511737-14-000030:mdna:88]
On May 5, 2014, we entered into a credit agreement ("the Credit Agreement") with Wells Fargo Bank, National Association, or Wells Fargo, the financial institutions named as lenders therein, and Wells Fargo as administrative agent for the lenders, that provides for a $150 million senior secured revolving credit facility, with an option to request an increase in the amount of the credit facility by up to an additional $50 million (any such increase to be in each lender’s sole discretion).  We initially borrowed $72.3 million under the Credit Agreement, which was used to repay obligations under our Loan Agreement with East West Bank and to pay transaction fees and costs.

[0001511737-14-000030:mdna:89]
Purchase Obligations

[0001511737-14-000030:mdna:90]
We subcontract with other companies to manufacture our products. During the normal course of business, our contract manufacturers procure components based upon orders placed by us. If we cancel all or part of the orders, we may still be liable to the contract manufacturers for the cost of the components purchased by the subcontractors to manufacture our products. We periodically review the potential liability and to date no significant liabilities for cancellations have been recorded. Our consolidated financial position and results of operations could be negatively impacted if we were required to compensate the contract manufacturers for any unrecorded liabilities incurred.

[0001511737-14-000030:mdna:91]
Other Obligations

[0001511737-14-000030:mdna:92]
We had other obligations of $1.2 million as of September 30, 2014, which consisted primarily of commitments to acquire capital assets, including manufacturing equipment.

[0001511737-14-000030:mdna:93]
Unrecognized Tax Benefits

[0001511737-14-000030:mdna:94]
As of September 30, 2014, we had $15.7 million of unrecognized tax benefits, substantially all of which would, if recognized, affect our tax expense. We have elected to include interest and penalties related to uncertain tax positions as a component of tax expense. We do not expect any significant increases or decreases to our unrecognized tax benefits in the next twelve months.

[0001511737-14-000030:mdna:95]
[same as prior period, unchanged from 0001511737-14-000018:mdna:103]

[0001511737-14-000030:mdna:96]
[same as prior period, unchanged from 0001511737-14-000018:mdna:104]

[0001511737-14-000030:mdna:97]
[same as prior period, unchanged from 0001511737-14-000018:mdna:105]

[0001511737-14-000030:mdna:98]
Regulation G, conditions for use of Non-Generally Accepted Accounting Principles (“Non-GAAP”) financial measures, and other SEC regulations define and prescribe the conditions for use of certain Non-GAAP financial information. To supplement our condensed consolidated financial results presented in accordance with GAAP, we use Non-GAAP financial measures which are adjusted from the most directly comparable GAAP financial measures to exclude certain items, as described below. Management believes that these Non-GAAP financial measures reflect an additional and useful way of viewing aspects of our operations that, when viewed in conjunction with our GAAP results, provide a more comprehensive understanding of the various factors and trends affecting our business and operations. Non-GAAP financial measures used by us include net income or loss and diluted net income or loss per share.

[0001511737-14-000030:mdna:99]
Our Non-GAAP measures primarily exclude stock-based compensation, net of taxes and other special charges and credits.  Additionally, during the three months ended September 30, 2014 we recorded a one-time charge of $5.5 million due to a termination fee related to a purchase commitment entered into during fiscal 2014.  Management believes these Non-GAAP financial measures provide meaningful supplemental information regarding our strategic and business decision making, internal budgeting, forecasting and resource allocation processes. In addition, these Non-GAAP financial measures facilitate management’s internal comparisons to our historical operating results and comparisons to competitors’ operating results.

[0001511737-14-000030:mdna:100]
[same as prior period, unchanged from 0001511737-14-000018:mdna:109]

[0001511737-14-000030:mdna:101]
[same as prior period, unchanged from 0001511737-14-000018:mdna:110]

[0001511737-14-000030:mdna:102]
|  | Three Months Ended September 30, |
|  | 2014 |  | 2013 |
|  | (In thousands, except per share amounts) |
| Non-GAAP net income and comprehensive income | $ | 43,406 |  |  | $ | 41,228 |  |
| Non-GAAP diluted net income per share of common stock | $ | 0.48 |  |  | $ | 0.46 |  |

[0001511737-14-000030:mdna:103]
2014

[0001511737-14-000030:mdna:104]
We believe that providing these Non-GAAP financial measures, in addition to the GAAP financial results, are useful to investors because they allow investors to see our results “through the eyes” of management as these Non-GAAP financial measures reflect our internal measurement processes. Management believes that these Non-GAAP financial measures enable investors to better assess changes in each key element of our operating results across different reporting periods on a consistent basis and provides investors with another method for assessing our operating results in a manner that is focused on the performance of our ongoing operations.

[0001511737-14-000030:mdna:105]
The following table shows a reconciliation of GAAP net income and comprehensive income to non-GAAP net income and comprehensive income:

[0001511737-14-000030:mdna:106]
|  | Three Months Ended September 30, |
|  | 2014 |  | 2013 |
|  | (In thousands, except pershare amounts) |
| Net income and comprehensive income | $ | 37,743 |  |  | $ | 40,528 |  |
| Stock-based compensation: |  |  |  |
| Cost of revenues | 149 |  |  | 144 |  |
| Research and development | 825 |  |  | 496 |  |
| Sales, general and administrative | 398 |  |  | 527 |  |
| Purchase commitment termination fee | 5,500 |  |  | — |  |
| Tax effect of non-GAAP adjustments | (1,209 | ) |  | (467 | ) |
| Non-GAAP net income and comprehensive income | $ | 43,406 |  |  | $ | 41,228 |  |
| Non-GAAP diluted net income per share of common stock | $ | 0.48 |  |  | $ | 0.46 |  |
| Weighted-average shares used in computing non-GAAP diluted net income per share of common stock | 89,913 |  |  | 89,473 |  |
