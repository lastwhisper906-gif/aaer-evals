# UI notes — 0001511737-14-000030


## us-gaap:BusinessDescriptionAndBasisOfPresentationTextBlock

[0001511737-14-000030:notes:1]
[same as prior period, unchanged from 0001511737-14-000018:notes:1]

[0001511737-14-000030:notes:2]
[same as prior period, unchanged from 0001511737-14-000018:notes:2]

[0001511737-14-000030:notes:3]
Ubiquiti Networks, Inc. and its wholly owned subsidiaries (collectively, “Ubiquiti” or the “Company”) is a product driven company that leverages innovative proprietary technologies to deliver networking solutions to both startup and established network operators and service providers.

[0001511737-14-000030:notes:4]
The Company operates on a fiscal year ending June 30. In this Quarterly Report, the fiscal year ending June 30, 2015 is referred to as “fiscal 2015” and the fiscal year ended June 30, 2014 is referred to as “fiscal 2014.”

[0001511737-14-000030:notes:5]
Basis of Presentation— The accompanying condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP”) related to interim financial statements based on applicable Securities and Exchange Commission (“SEC”) rules and regulations. Accordingly, they do not include all the information and footnotes required by U.S. GAAP for complete financial statements. This information reflects all adjustments, which are, in the opinion of the Company, of a normal and recurring nature and necessary to state fairly the statements of financial position, results of operations and cash flows for the dates and periods presented. The June 30, 2014 balance sheet was derived from the audited financial statements as of that date. All significant intercompany transactions and balances have been eliminated.

[0001511737-14-000030:notes:6]
These condensed consolidated financial statements should be read in conjunction with the Company’s audited consolidated financial statements for the fiscal year ended June 30, 2014 included in its Annual Report on Form 10-K, as filed on August 22, 2014 with the SEC (the “Annual Report”). The results of operations for the three months ended September 30, 2014 are not necessarily indicative of the results to be expected for any future periods.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001511737-14-000030:notes:7]
COMMITMENTS AND CONTINGENCIES

[0001511737-14-000030:notes:8]
Operating Leases

[0001511737-14-000030:notes:9]
Certain facilities and equipment are leased under noncancelable operating leases. The Company generally pays taxes, insurance and maintenance costs on leased facilities and equipment. The Company leases office space in San Jose, California and other locations under various non-cancelable operating leases that expire at various dates through 2018.

[0001511737-14-000030:notes:10]
At September 30, 2014, future minimum annual payments under operating leases are as follows (in thousands):

[0001511737-14-000030:notes:11]
|  | 2015(remainder) |  | 2016 |  | 2017 |  | 2018 |  | 2019 |  | Thereafter |  | Total |
| Operating leases | $ | 2,277 |  |  | $ | 2,986 |  |  | $ | 1,648 |  |  | $ | 358 |  |  | $ | 53 |  |  | $ | — |  |  | $ | 7,322 |  |

[0001511737-14-000030:notes:12]
Purchase Commitments

[0001511737-14-000030:notes:13]
The Company primarily subcontracts with other companies to manufacture its products. During the normal course of business, the Company’s contract manufacturers procure components based upon orders placed by the Company. If the Company cancels all or part of the orders, it may still be liable to the contract manufacturers for the cost of the components purchased by them to manufacture the Company’s products. The Company periodically reviews the potential liability and to date no significant accruals have been recorded.

[0001511737-14-000030:notes:14]
Other Obligations

[0001511737-14-000030:notes:15]
The Company had other obligations of $1.2 million as of September 30, 2014, which consisted primarily of commitments to acquire capital assets, including manufacturing equipment.

[0001511737-14-000030:notes:16]
Indemnification Obligations

[0001511737-14-000030:notes:17]
The Company enters into standard indemnification agreements with many of its business partners in the ordinary course of business. These agreements include provisions for indemnifying the business partner against any claim brought by a third party to the extent any such claim alleges that a Company product infringes a patent, copyright or trademark, or violates any other proprietary rights of that third party. The maximum potential amount of future payments the Company could be required to make under these indemnification agreements is not estimable and the Company has not incurred any material costs to defend lawsuits or settle claims related to these indemnification agreements to date.

[0001511737-14-000030:notes:18]
Legal Matters

[0001511737-14-000030:notes:19]
The Company may be involved, from time to time, in a variety of claims, lawsuits, investigations, and proceedings relating to contractual disputes, intellectual property rights, employment matters, regulatory compliance matters and other litigation matters relating to various claims that arise in the normal course of business. The Company determines whether an estimated loss from a contingency should be accrued by assessing whether a loss is deemed probable and can be reasonably estimated. The Company assesses its potential liability by analyzing specific litigation and regulatory matters using available information. The Company develops its views on estimated losses in consultation with inside and outside counsel, which involves a subjective analysis of potential results and outcomes, assuming various combinations of appropriate litigation and settlement strategies. Taking all of the above factors into account, the Company records an amount where it is probable that the Company will incur a loss and where that loss can be reasonably estimated. However, the Company’s estimates may be incorrect and the Company could ultimately incur more or less than the amounts initially recorded.  The Company may also incur significant legal fees, which are expensed as incurred, in defending against these claims.

[0001511737-14-000030:notes:20]
Export Compliance Matters

[0001511737-14-000030:notes:21]
In May 2011, the Company filed a self-disclosure statement with the U.S. Commerce Department, Bureau of Industry and Security’s (“BIS”) Office of Export Enforcement (“OEE”) relating to a review conducted by the Company regarding certain export transactions from 2008 through March 2011 in which products may have been later resold into Iran by third parties. In June 2011, the Company also filed a self-disclosure statement with the U.S. Department of the Treasury’s Office of Foreign Asset Control (“OFAC”) regarding these compliance issues. In August 2011, the Company received a warning letter from OEE stating that OEE had not referred the findings of the Company’s review for criminal or administrative prosecution and closed the investigation of the Company without penalty. Based upon its review of the matter, OFAC identified certain apparent violations (“Apparent Violations”) of the Iranian Transactions and Sanctions Regulations by the Company during the period of in or about March 2008 through in or about February 2011. On March 4, 2014, the Company entered into a settlement agreement with OFAC resolving this administrative matter. Pursuant to the terms of the settlement agreement, the Company agreed to make a one-time payment to the U.S. Department of the Treasury in the amount of $504,000 in consideration of OFAC agreeing to release and forever discharge the Company from any and all civil liability in connection with the Apparent Violations. The Company previously accrued a reserve of $1.6 million relating to this matter in fiscal 2010 and, accordingly, reversed the excess of the accrual of $1.1 million as of the effective date of the settlement agreement.

[0001511737-14-000030:notes:22]
Shareholder Class Action Lawsuits

[0001511737-14-000030:notes:23]
Beginning on September 7, 2012, two class action lawsuits were filed in the United States District Court for the Northern District of California against Ubiquiti Networks, Inc., certain of its officers and directors, and the underwriters of its initial public offering, alleging claims under U.S. securities laws. On January 30, 2013, the plaintiffs filed an amended consolidated complaint. On March 26, 2014, the court issued an order granting a motion to dismiss the complaint with leave to amend. Following the plaintiffs’ decision not to file an amended complaint, on April 16, 2014, the court ordered the dismissal of the lawsuit with prejudice, and entered judgment in favor of the Company and the other defendants, and against the plaintiffs. On May 15, 2014, the plaintiffs filed a notice of appeal from the judgment of the court. The appeal is ongoing before the U.S. Court of Appeals for the Ninth Circuit. There can be no assurance that the Company will prevail in the appeal proceeding.  The Company cannot currently estimate the possible loss, if any, that it may experience in connection with this litigation.


## us-gaap:DebtDisclosureTextBlock

[0001511737-14-000030:notes:24]
DEBT

[0001511737-14-000030:notes:25]
On August 7, 2012, the Company entered into a Loan and Security Agreement (the “Loan Agreement”) with U.S. Bank, as syndication agent, and East West Bank, as administrative agent for the lenders party to the Loan Agreement.  The Loan Agreement provides for (i) a $50.0 million revolving credit facility, with a $5.0 million sublimit for the issuance of letters of credit and a $5.0 million sublimit for the making of swingline loan advances (the “Revolving Credit Facility”), and (ii) a $50.0 million term loan facility (the “Term Loan Facility”). The Company may request borrowings under the Revolving Credit Facility until August 7, 2015.  The Loan Agreement replaced a previous agreement whereby the Company had an existing term loan balance of $29.2 million as of the date the new Loan Agreement.  On August 7, 2012, the Company borrowed $20.8 million under the Term Loan Facility, and no borrowings remain available for borrowing thereunder.  On November 21, 2012, the Company borrowed $10.0 million under the Revolving Credit Facility. On December 20, 2012, the Company borrowed an additional $20.0 million under the Revolving Credit Facility, and $20.0 million remains available for borrowing thereunder.  During the three months ended September 30, 2013 the Company made aggregate payments of $1.3 million against the loan balance.

[0001511737-14-000030:notes:26]
On May 5, 2014, the Company and certain of its subsidiaries entered into a credit agreement (the “Credit Agreement”) with Wells Fargo Bank, National Association (“Wells Fargo”), the financial institutions named as lenders therein, and Wells Fargo as administrative agent for the lenders, that provides for a $150 million senior secured revolving credit facility, with an option to request an increase in the amount of the credit facility by up to an additional $50 million (any such increase to be in each lender’s sole discretion).  The Company may borrow up to $110 million of the facility as a U.S. sublimit.  The entire amount of the facility is available to Ubiquiti International Holding Company Limited, a wholly-owned subsidiary of the Company organized under the laws of the Cayman Islands.  The credit facility includes a sub-limit of $5 million for letters of credit and a sub-limit of $15 million for swingline loans.   In connection with the execution of the Credit Agreement, the Company terminated the $50 million line of credit facility under the Loan Agreement with East West Bank described above.  Under the Credit Agreement, revolving loans and swingline loans may be borrowed, repaid and reborrowed until May 5, 2019, at which time all amounts borrowed must be repaid.   Additionally, $72.3 million is currently outstanding under the Credit Agreement, which was borrowed by the Company to repay obligations under the Loan Agreement and to pay transaction fees and costs.  Revolving loans bear interest, at the Company’s option, at either (i) a floating rate per annum equal to the base rate plus a margin of between 0.250% and 1.000%, depending on the Company’s leverage ratio as of the most recently ended fiscal quarter or (ii) a per annum rate equal to the applicable LIBOR rate for a specified period, plus a margin of between 1.250% and 2.000%, depending on the Company’s leverage ratio as of the most recently ended fiscal quarter.  Swingline loans will bear interest at a floating rate per annum equal to the base rate plus a margin of between 0.250% and 1.000%, depending on the Company’s leverage ratio as of the most recently ended fiscal quarter.   Base rate is defined as the greatest of (A) Wells Fargo’s prime rate, (B) the federal funds rate plus 0.500% or (C) a per annum rate equal to the rate at which dollar deposits are offered in the London interbank market for a period of one month plus 1.000%.  A default interest rate shall apply on all obligations during a payment event of default under the Credit Agreement at a rate per annum equal to 2.000% above the applicable interest rate. The Company will pay to each lender a facility fee on a quarterly basis based on the unused amount of each lender’s commitment to make loans, of between 0.200% and 0.350%, depending on the Company’s leverage ratio as of the most recently ended fiscal quarter.  Revolving loans and swingline loans may be prepaid at any time without penalty.  The Company is also obligated to pay Wells Fargo, as agent, fees customary for a credit facility of this size and type.

[0001511737-14-000030:notes:27]
The Credit Agreement requires the Company to maintain a maximum leverage ratio and a minimum interest coverage ratio during the term of the credit facility.  In addition, the Credit Agreement contains customary affirmative and negative covenants, including covenants that limit or restrict the ability of the Company and its subsidiaries to, among other things, grant liens or enter into agreements restricting their ability to grant liens on property, enter into mergers, dispose of assets, change their accounting or reporting policies, change their business and incur subsidiary indebtedness, in each case subject to customary exceptions for a credit facility of this size and type.  The Credit Agreement includes customary events of default that, include among other things, non-payment of principal, interest or fees, inaccuracy of representations and warranties, violation of covenants, cross default to certain other indebtedness, bankruptcy and insolvency events, material judgments, change of control and certain ERISA events. The occurrence of an event of default could result in the acceleration of the obligations under the Credit Agreement.  The credit facility under the Credit Agreement expires May 5, 2019.

[0001511737-14-000030:notes:28]
The obligations of the Company and its subsidiaries under the Credit Agreement are collateralized by substantially all assets (excluding intellectual property) of the Company and its subsidiaries.

[0001511737-14-000030:notes:29]
Wells Fargo and the lenders party to the Credit Agreement, and certain of their respective affiliates, have provided, and in the future may provide, financial, banking and related services to the Company. These parties have received, and in the future may receive, compensation from the Company for these services.

[0001511737-14-000030:notes:30]
No payments were made for borrowings under the Credit Agreement with Wells Fargo in the three months ended September 30, 2014.  As of September 30, 2014, the Company has classified $72.3 million of long-term debt on its consolidated balance sheet related to the Credit Agreement.

[0001511737-14-000030:notes:31]
The following table summarizes our estimated debt and interest payment obligations as of September 30, 2014 (in thousands):

[0001511737-14-000030:notes:32]
|  | 2015(remainder) |  | 2016 |  | 2017 |  | 2018 |  | 2019 |  | Total |
| Debt payment obligations | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 72,254 |  |  | $ | 72,254 |  |
| Interest payments on debt payment obligations | 761 |  |  | 1,014 |  |  | 1,014 |  |  | 1,014 |  |  | 858 |  |  | 4,661 |  |
| Total | $ | 761 |  |  | $ | 1,014 |  |  | $ | 1,014 |  |  | $ | 1,014 |  |  | $ | 73,112 |  |  | $ | 76,915 |  |


## us-gaap:DeferredCostsCapitalizedPrepaidAndOtherAssetsDisclosureTextBlock

[0001511737-14-000030:notes:33]
[same as prior period, unchanged from 0001511737-14-000018:notes:36]

[0001511737-14-000030:notes:34]
|  | September 30, 2014 |  | June 30, 2014 |
| Vendor deposits | $ | 15,741 |  |  | $ | 8,043 |  |
| Non-trade receivables | 301 |  |  | 292 |  |
| Other current assets | 5,702 |  |  | 4,932 |  |
|  | $ | 21,744 |  |  | $ | 13,267 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001511737-14-000030:notes:35]
[same as prior period, unchanged from 0001511737-14-000018:notes:38]

[0001511737-14-000030:notes:36]
[same as prior period, unchanged from 0001511737-14-000018:notes:39]

[0001511737-14-000030:notes:37]
The Company’s 2010 Equity Incentive Plan and 2005 Equity Incentive Plan are described in its Annual Report. As of September 30, 2014, the Company had 9,894,037 authorized shares available for future issuance under all of its stock incentive plans.

[0001511737-14-000030:notes:38]
[same as prior period, unchanged from 0001511737-14-000018:notes:41]

[0001511737-14-000030:notes:39]
The following table shows total stock-based compensation expense included in the Condensed Consolidated Statements of Operations for the three months ended September 30, 2014 and 2013 (in thousands):

[0001511737-14-000030:notes:40]
|  | Three Months Ended September 30, |
|  | 2014 |  | 2013 |
| Cost of sales | $ | 149 |  |  | $ | 144 |  |
| Research and development | 825 |  |  | 496 |  |
| Sales, general and administrative | 398 |  |  | 527 |  |
|  | $ | 1,372 |  |  | $ | 1,167 |  |

[0001511737-14-000030:notes:41]
[same as prior period, unchanged from 0001511737-14-000018:notes:44]

[0001511737-14-000030:notes:42]
The following is a summary of option activity for the Company’s stock incentive plans for the three months ended September 30, 2014:

[0001511737-14-000030:notes:43]
|  | Common Stock Options Outstanding |
|  | Numberof Shares |  | WeightedAverageExercisePrice |  | WeightedAverageRemainingContractualLife (Years) |  | AggregateIntrinsicValue |
|  |  |  |  |  |  |  | (In thousands) |
| Balance, June 30, 2014 | 2,657,142 |  |  | $ | 2.96 |  |  |  |  |  |
| Exercised | (116,907 | ) |  | 3.90 |  |  |  |  |  |
| Forfeitures and cancellations | (503 | ) |  | 15.00 |  |  |  |  |  |
| Balance, September 30, 2014 | 2,539,732 |  |  | $ | 2.91 |  |  | 4.79 |  | $ | 87,918 |  |
| Vested and expected to vest as of September 30, 2014 | 2,521,480 |  |  | $ | 2.85 |  |  | 4.77 |  | $ | 87,442 |  |
| Vested and exercisable as of September 30, 2014 | 2,195,724 |  |  | $ | 1.70 |  |  | 4.31 |  | $ | 78,683 |  |

[0001511737-14-000030:notes:44]
During the three months ended September 30, 2014 and 2013, the aggregate intrinsic value of options exercised under the Company’s stock incentive plans was $4.9 million and $10.0 million, respectively, as determined as of the date of option exercise.

[0001511737-14-000030:notes:45]
As of September 30, 2014, the Company had unrecognized compensation costs of $1.7 million related to stock options which the Company expects to recognize over a weighted-average period of 2.0 years. Future option grants will increase the amount of compensation expense to be recorded in these periods.

[0001511737-14-000030:notes:46]
The Company estimates the fair value of employee stock options using the Black-Scholes option pricing model. The fair value of employee stock options is being amortized on a straight-line basis over the requisite service period of the awards.  The Company did not grant any employee stock options during the three months ended September 30, 2014 and 2013.

[0001511737-14-000030:notes:47]
[same as prior period, unchanged from 0001511737-14-000018:notes:51]

[0001511737-14-000030:notes:48]
[same as prior period, unchanged from 0001511737-14-000018:notes:52]

[0001511737-14-000030:notes:49]
|  | Number of Shares |  | Weighted Average Grant Date Fair Value |
| Non-vested RSUs, June 30, 2014 | 549,702 |  |  | $ | 22.65 |  |
| RSUs granted | 44,894 |  |  | 38.77 |  |
| RSUs vested | (66,969 | ) |  | 40.24 |  |
| RSUs canceled | (750 | ) |  | 15.06 |  |
| Non-vested RSUs, September 30, 2014 | 526,877 |  |  | $ | 21.80 |  |

[0001511737-14-000030:notes:50]
The intrinsic value of RSUs vested in the three months ended September 30, 2014 and 2013 was $2.7 million and $1.4 million, respectively.

[0001511737-14-000030:notes:51]
As of September 30, 2014, there was unrecognized compensation costs related to RSUs of $10.1 million which the Company expects to recognize over a weighted average period of 3.1 years.


## us-gaap:EarningsPerShareTextBlock

[0001511737-14-000030:notes:52]
[same as prior period, unchanged from 0001511737-14-000018:notes:56]

[0001511737-14-000030:notes:53]
[same as prior period, unchanged from 0001511737-14-000018:notes:57]

[0001511737-14-000030:notes:54]
|  | Three Months Ended September 30, |
|  | 2014 |  | 2013 |
| Numerator: |  |
| Net income attributable to common stockholders | $ | 37,743 |  |  | $ | 40,528 |  |
| Denominator: |  |
| Weighted-average shares used in computing basic net income per share | 88,240 |  |  | 87,411 |  |
| Add—dilutive potential common shares: |  |  |  |
| Stock options | 1,481 |  |  | 1,814 |  |
| Restricted stock units | 192 |  |  | 248 |  |
| Weighted-average shares used in computing diluted net income per share | 89,913 |  |  | 89,473 |  |
| Net income per share of common stock: |  |
| Basic | $ | 0.43 |  |  | $ | 0.46 |  |
| Diluted | $ | 0.42 |  |  | $ | 0.45 |  |

[0001511737-14-000030:notes:55]
The following table summarizes the total potential shares of common stock that were excluded from the diluted per share calculation, because to include them would have been anti-dilutive for the period (in thousands):

[0001511737-14-000030:notes:56]
|  | Three Months Ended September 30, |
|  | 2014 |  | 2013 |
| Stock options | — |  |  | 1 |  |
| Restricted stock units | 2 |  |  | 16 |  |
|  | 2 |  |  | 17 |  |


## us-gaap:FairValueAssetsAndLiabilitiesMeasuredOnRecurringAndNonrecurringBasisTableTextBlock

[0001511737-14-000030:notes:57]
As of September 30, 2014 and June 30, 2014, the fair value hierarchy of the Company’s debt carried at historical cost was as follows (in thousands):

[0001511737-14-000030:notes:58]
|  | September 30, 2014 |  | June 30, 2014 |
|  | FairValue |  | Level 1 |  | Level 2 |  | Level 3 |  | FairValue |  | Level 1 |  | Level 2 |  | Level 3 |
| Debt | $ | 72,254 |  |  | $ | — |  |  | $ | 72,254 |  |  | $ | — |  |  | $ | 72,254 |  |  | $ | — |  |  | $ | 72,254 |  |  | $ | — |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001511737-14-000030:notes:59]
[same as prior period, unchanged from 0001511737-14-000018:notes:63]

[0001511737-14-000030:notes:60]
[same as prior period, unchanged from 0001511737-14-000018:notes:64]

[0001511737-14-000030:notes:61]
[same as prior period, unchanged from 0001511737-14-000018:notes:65]

[0001511737-14-000030:notes:62]
[same as prior period, unchanged from 0001511737-14-000018:notes:66]

[0001511737-14-000030:notes:63]
[same as prior period, unchanged from 0001511737-14-000018:notes:67]

[0001511737-14-000030:notes:64]
For certain of the Company’s financial instruments, including cash, accounts receivable and accounts payable, the carrying amounts approximate fair value due to their short maturities, and are therefore excluded from the fair value tables below.  Additionally, as of September 30, 2014, we held $330.8 million of our $391.0 million of cash and cash equivalents in accounts of our subsidiaries outside of the United States and we would incur significant tax liabilities if we were to repatriate those amounts.

[0001511737-14-000030:notes:65]
At September 30, 2014 and June 30, 2014 the Company had debt associated with its Credit Agreement with Wells Fargo Bank(See Note 7). The fair value of the Company’s debt was estimated based on the current rates offered to the Company for debt with similar terms and remaining maturities and was Level 2 measurement.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001511737-14-000030:notes:66]
[same as prior period, unchanged from 0001511737-14-000018:notes:70]

[0001511737-14-000030:notes:67]
As of September 30, 2014, the Company had approximately $15.7 million of unrecognized tax benefits, substantially all of which would, if recognized, affect its tax expense. The Company has elected to include interest and penalties related to uncertain tax positions as a component of tax expense. At September 30, 2014, an insignificant amount of interest and penalties are included in long-term income tax payable. The Company recorded an increase of its unrecognized tax benefits of $824,000 for the three months ended September 30, 2014. The Company does not expect any significant increases or decreases to its unrecognized tax benefits in the next twelve months.

[0001511737-14-000030:notes:68]
The Company recorded an income tax provision of $5.8 million for the three months ended September 30, 2014. The Company’s estimated 2014 effective tax rate differs from the U.S. statutory rate primarily due to profits earned in jurisdictions where the tax rate is lower than the U.S. tax rate.

[0001511737-14-000030:notes:69]
The Company files U.S. federal income tax returns as well as income tax returns in various states and foreign jurisdictions. The Company’s tax years from 2010 and onwards could be subject to examinations by tax authorities.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001511737-14-000030:notes:70]
Recent Accounting Pronouncements

[0001511737-14-000030:notes:71]
In June 2014, the Financial Accounting Standards Board, or FASB, issued a new accounting standard update on revenue from contracts with customers.  The core principle of the guidance is that an entity should recognize revenue to depict the transfer of promised goods or services to customers in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services.  To achieve that core principle, an entity should apply the following steps:

[0001511737-14-000030:notes:72]
Step 1: Identify the contract(s) with a customer.

[0001511737-14-000030:notes:73]
Step 2: Identify the performance obligations in the contract.

[0001511737-14-000030:notes:74]
Step 3: Determine the transaction price.

[0001511737-14-000030:notes:75]
Step 4: Allocate the transaction price to the performance obligations in the contract.

[0001511737-14-000030:notes:76]
Step 5: Recognize revenue when (or as) the entity satisfies a performance obligation.

[0001511737-14-000030:notes:77]
An entity should disclose sufficient information to enable users of financial statements to understand the nature, amount, timing, and uncertainty of revenue and cash flows arising from contracts with customers. Qualitative and quantitative information is required about contracts with customers, significant judgments and any assets recognized from the costs to obtain or fulfill a contract.   The guidance will be effective for the Company beginning July 1, 2017.  The Company is currently assessing the impact of this new guidance.


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001511737-14-000030:notes:78]
[same as prior period, unchanged from 0001511737-14-000018:notes:76]

[0001511737-14-000030:notes:79]
[same as prior period, unchanged from 0001511737-14-000018:notes:77]

[0001511737-14-000030:notes:80]
[same as prior period, unchanged from 0001511737-14-000018:notes:78]

[0001511737-14-000030:notes:81]
|  | Three Months Ended September 30, |
|  | 2014 |  | 2013 |
| Beginning balance | $ | 2,850 |  |  | $ | 2,913 |  |
| Accruals for warranties issued during the period | 788 |  |  | 1,251 |  |
| Warranty costs incurred during the period | (788 | ) |  | (964 | ) |
|  | $ | 2,850 |  |  | $ | 3,200 |  |


## us-gaap:PropertyPlantAndEquipmentScheduleOfSignificantAcquisitionsAndDisposalsTextBlock

[0001511737-14-000030:notes:82]
[same as prior period, unchanged from 0001511737-14-000018:notes:80]

[0001511737-14-000030:notes:83]
|  | September 30, 2014 |  | June 30, 2014 |
| Testing equipment | $ | 4,155 |  |  | $ | 3,785 |  |
| Computer and other equipment | 1,271 |  |  | 1,019 |  |
| Tooling equipment | 3,308 |  |  | 2,898 |  |
| Furniture and fixtures | 1,127 |  |  | 973 |  |
| Leasehold improvements | 3,173 |  |  | 3,173 |  |
| Software | 530 |  |  | 521 |  |
| Construction in progress | 2,370 |  |  | — |  |
|  | 15,934 |  |  | 12,369 |  |
| Less: Accumulated depreciation and amortization | (5,939 | ) |  | (5,109 | ) |
|  | $ | 9,995 |  |  | $ | 7,260 |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001511737-14-000030:notes:84]
RELATED PARTY TRANSACTIONS AND CERTAIN OTHER TRANSACTIONS

[0001511737-14-000030:notes:85]
On November 13, 2013, the Company entered into an aircraft lease agreement (the "Aircraft Lease Agreement") with RJP Manageco LLC (the "Lessor"), a limited liability company owned by the Company’s CEO, Robert J. Pera. Pursuant to the Aircraft Lease Agreement, the Company may lease an aircraft owned by the Lessor for Company business purposes. Under the Aircraft Lease Agreement, the aircraft may be leased at a rate of $5,000 per flight hour. This hourly rate does not include the cost of flight crew or on-board services, which the Company purchases from a third-party provider. The Company recognized a total of approximately $151,000 in expenses pursuant to the Aircraft Lease Agreement during the three months ended September 30, 2014.  All expenses pursuant to the Aircraft Lease Agreement have been included in the Company's sales, general and administrative expenses in the Condensed Consolidated Statements of Operations.


## us-gaap:ScheduleOfAccruedLiabilitiesTableTextBlock

[0001511737-14-000030:notes:86]
[same as prior period, unchanged from 0001511737-14-000018:notes:84]

[0001511737-14-000030:notes:87]
|  | September 30, 2014 |  | June 30, 2014 |
| Accrued compensation and benefits | $ | 2,437 |  |  | $ | 3,432 |  |
| Accrued accounts payable | 7,651 |  |  | 10 |  |
| Warranty accrual | 2,850 |  |  | 2,850 |  |
| Other accruals | 5,676 |  |  | 3,538 |  |
|  | $ | 18,614 |  |  | $ | 9,830 |  |


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0001511737-14-000030:notes:88]
[same as prior period, unchanged from 0001511737-14-000018:notes:86]

[0001511737-14-000030:notes:89]
|  | September 30, 2014 |  | June 30, 2014 |
| Finished goods | $ | 37,945 |  |  | $ | 45,881 |  |
| Raw materials | 802 |  |  | 468 |  |
|  | $ | 38,747 |  |  | $ | 46,349 |  |


## us-gaap:ScheduleOfOtherAssetsNoncurrentTextBlock

[0001511737-14-000030:notes:90]
[same as prior period, unchanged from 0001511737-14-000018:notes:88]

[0001511737-14-000030:notes:91]
|  | September 30, 2014 |  | June 30, 2014 |
| Intangible assets, net | $ | 749 |  |  | $ | 799 |  |
| Other long-term assets | 1,055 |  |  | 1,113 |  |
|  | $ | 1,804 |  |  | $ | 1,912 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001511737-14-000030:notes:92]
[same as prior period, unchanged from 0001511737-14-000018:notes:90]

[0001511737-14-000030:notes:93]
Management has determined that the Company operates as one reportable and operating segment as it only reports financial information on an aggregate and consolidated basis to its chief executive officer, who is the Company’s chief operating decision maker.  The Company presents its revenues by product type in two primary categories, Service Provider Technology and Enterprise Technology.

[0001511737-14-000030:notes:94]
| • | Service Provider Technology includes the Company's airMAX, EdgeMAX and airFiber platforms, as well as embedded radio products and other 802.11 standard products including base stations, radios, backhaul equipment and Customer Premise Equipment (“CPE”). Additionally, Service Provider Technology includes antennas and other products in the 0.9 to 6.0GHz spectrum and miscellaneous products such as mounting brackets, cables and power over Ethernet adapters. Service Provider Technology also includes revenues that are attributable to post contract support ("PCS"). |

[0001511737-14-000030:notes:95]
| • | Enterprise Technology includes the Company's UniFi, mFi and UniFi Video platforms. |

[0001511737-14-000030:notes:96]
Revenues by product type are as follows (in thousands, except percentages):

[0001511737-14-000030:notes:97]
|  | Three Months Ended September 30, |
|  | 2014 |  | 2013 |
| Service Provider Technology | $ | 107,271 |  |  | 71 | % |  | $ | 94,217 |  |  | 73 | % |
| Enterprise Technology | 42,816 |  |  | 29 | % |  | 35,470 |  |  | 27 | % |
| Total revenues | $ | 150,087 |  |  | 100 | % |  | $ | 129,687 |  |  | 100 | % |

[0001511737-14-000030:notes:98]
Revenues by geography based on customer’s ship-to destinations were as follows (in thousands, except percentages):

[0001511737-14-000030:notes:99]
|  | Three Months Ended September 30, |
|  | 2014 |  | 2013 |
| North America(1) | $ | 53,582 |  |  | 35 | % |  | $ | 37,433 |  |  | 29 | % |
| South America | 31,134 |  |  | 21 | % |  | 20,776 |  |  | 16 | % |
| Europe, the Middle East and Africa | 50,607 |  |  | 34 | % |  | 52,866 |  |  | 41 | % |
| Asia Pacific | 14,764 |  |  | 10 | % |  | 18,612 |  |  | 14 | % |
| Total revenues | $ | 150,087 |  |  | 100 | % |  | $ | 129,687 |  |  | 100 | % |

[0001511737-14-000030:notes:100]
| (1) | Revenue for the United States was $52.0 million and $36.3 million for the three months ended September 30, 2014 and 2013, respectively. |

[0001511737-14-000030:notes:101]
[same as prior period, unchanged from 0001511737-14-000018:notes:100]

[0001511737-14-000030:notes:102]
|  | Percentage of Revenues |  | Percentage of Accounts Receivable |
|  | Three Months Ended September 30, |  | September 30, |  | June 30, |
|  | 2014 |  | 2013 |  | 2014 |  | 2014 |
| Customer A | 10 | % |  | 10 | % |  | * |  |  | 13 | % |
| Customer B | * |  |  | 10 | % |  | 10 | % |  | 12 | % |
| Customer C | * |  |  | * |  |  | 11 | % |  | 12 | % |
| Customer D | * |  |  | * |  |  | 17 | % |  | * |  |

[0001511737-14-000030:notes:103]
[same as prior period, unchanged from 0001511737-14-000018:notes:102]


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001511737-14-000030:notes:104]
[same as prior period, unchanged from 0001511737-14-000018:notes:103]

[0001511737-14-000030:notes:105]
The Company’s significant accounting policies are disclosed in its audited consolidated financial statements for the year ended June 30, 2014 included in the Annual Report.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001511737-14-000030:notes:106]
[same as prior period, unchanged from 0001511737-14-000018:notes:112]

[0001511737-14-000030:notes:107]
[same as prior period, unchanged from 0001511737-14-000018:notes:113]

[0001511737-14-000030:notes:108]
[same as prior period, unchanged from 0001511737-14-000018:notes:114]

[0001511737-14-000030:notes:109]
During the three months ended September 30, 2014, the Company recorded a reserve of $5.5 million against its vendor deposits balance to reflect the amount not recoverable due to a termination fee related to a purchase commitment entered into during fiscal 2014.

[0001511737-14-000030:notes:110]
[same as prior period, unchanged from 0001511737-14-000018:notes:115]

[0001511737-14-000030:notes:111]
[same as prior period, unchanged from 0001511737-14-000018:notes:116]

[0001511737-14-000030:notes:112]
The Company's intangible assets consist primarily of legal costs associated with the application for and registration of the Company’s trademarks.  The Company recorded $50,000 and $150,000 of amortization of intangible assets during the three months ended September 30, 2014 and 2013, respectively.  The balance of accumulated amortization was $500,000 and $450,000 at September 30, 2014 and June 30, 2014, respectively.   Estimated future amortization related to trademark registration fees is $187,000, $251,000, $229,000, $68,000 and $14,000 for the remainder of fiscal 2015 and fiscal years 2016, 2017, 2018 and 2019, respectively.

[0001511737-14-000030:notes:113]
[same as prior period, unchanged from 0001511737-14-000018:notes:118]


## ubnt:CommonStockAndTreasuryStockDiscloseTextBlock

[0001511737-14-000030:notes:114]
[same as prior period, unchanged from 0001511737-14-000018:notes:119]

[0001511737-14-000030:notes:115]
As of September 30, 2014 and June 30, 2014, the authorized capital of the Company included 500,000,000 shares of common stock.  As of September 30, 2014, 132,582,790 shares of common stock were issued and 88,343,830 were outstanding. As of June 30, 2014, 132,418,408 shares of common stock were issued and 88,179,448 were outstanding.

[0001511737-14-000030:notes:116]
Dividend Policy

[0001511737-14-000030:notes:117]
On September 30, 2014, the Company announced that its Board of Directors had approved a new annual dividend policy.   Pursuant to this dividend policy, the Company intends to pay an annual cash dividend to its shareholders of record on a record date and in an amount to be determined annually by the Board of Directors subject to the Company's financial position and other relevant factors.  As of September 30, 2014, the Company's first annual dividend of $0.17 per share was recorded as a dividend payable in its condensed consolidated balance sheet of $15.0 million, which was paid on October 28, 2014 to stockholders of record on October 17, 2014.
