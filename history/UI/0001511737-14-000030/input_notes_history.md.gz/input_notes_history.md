# UI note change history — 0001511737-14-000018 → 0001511737-14-000030


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2014-11-06):
[0001511737-14-000030:note_history:1]
Certain facilities and equipment are leased under noncancelable operating leases. The Company generally pays taxes, insurance and maintenance costs on leased facilities and equipment. The Company leases office space in San Jose, California and other locations under various non-cancelable operating leases that expire at various dates through 2018.
  (was, 2014-05-09, similarity 0.9885):
[0001511737-14-000018:note_history:1]
Certain facilities and equipment are leased under non-cancelable operating leases. The Company generally pays taxes, insurance and maintenance costs on leased facilities and equipment. The Company leases office space in San Jose, California and other locations under various non-cancelable operating leases that expire at various dates through fiscal 2019.

- changed (2014-11-06):
[0001511737-14-000030:note_history:2]
At September 30, 2014, future minimum annual payments under operating leases are as follows (in thousands):
  (was, 2014-05-09, similarity 0.746):
[0001511737-14-000018:note_history:2]
At March 31, 2014, future minimum annual payments under operating leases for the remainder of fiscal 2014 and future fiscal years are as follows (in thousands):

- changed (2014-11-06):
[0001511737-14-000030:note_history:3]
|  | 2015(remainder) |  | 2016 |  | 2017 |  | 2018 |  | 2019 |  | Thereafter |  | Total |
| Operating leases | $ | 2,277 |  |  | $ | 2,986 |  |  | $ | 1,648 |  |  | $ | 358 |  |  | $ | 53 |  |  | $ | — |  |  | $ | 7,322 |  |
  (was, 2014-05-09, similarity 0.9941):
[0001511737-14-000018:note_history:3]
|  | 2014(remainder) |  | 2015 |  | 2016 |  | 2017 |  | 2018 |  | Thereafter |  | Total |
| Operating leases | $ | 633 |  |  | $ | 2,503 |  |  | $ | 2,497 |  |  | $ | 1,537 |  |  | $ | 297 |  |  | $ | 53 |  |  | $ | 7,520 |  |

- changed (2014-11-06):
[0001511737-14-000030:note_history:4]
The Company primarily subcontracts with other companies to manufacture its products. During the normal course of business, the Company’s contract manufacturers procure components based upon orders placed by the Company. If the Company cancels all or part of the orders, it may still be liable to the contract manufacturers for the cost of the components purchased by them to manufacture the Company’s products. The Company periodically reviews the potential liability and to date no significant accruals have been recorded.
  (was, 2014-05-09, similarity 0.8047):
[0001511737-14-000018:note_history:4]
The Company subcontracts with other companies to manufacture its products. During the normal course of business, the Company’s contract manufacturers procure components based upon orders placed by the Company. If the Company cancels all or part of the orders, it may still be liable to the contract manufacturers for the cost of the components purchased by them to manufacture the Company’s products. The Company periodically reviews the potential liability and to date no significant accruals have been recorded.  The Company had $20.9 million in non-cancelable purchase commitments as of March 31, 2014, the related expenses of which are expected to be incurred in future periods.  The Company did not have any non-cancelable purchase commitments as of June 30, 2013.

- added (2014-11-06):
[0001511737-14-000030:note_history:5]
Other Obligations

- added (2014-11-06):
[0001511737-14-000030:note_history:6]
The Company had other obligations of $1.2 million as of September 30, 2014, which consisted primarily of commitments to acquire capital assets, including manufacturing equipment.

- changed (2014-11-06):
[0001511737-14-000030:note_history:7]
The Company enters into standard indemnification agreements with many of its business partners in the ordinary course of business. These agreements include provisions for indemnifying the business partner against any claim brought by a third party to the extent any such claim alleges that a Company product infringes a patent, copyright or trademark, or violates any other proprietary rights of that third party. The maximum potential amount of future payments the Company could be required to make under these indemnification agreements is not estimable and the Company has not incurred any material costs to defend lawsuits or settle claims related to these indemnification agreements to date.
  (was, 2014-05-09, similarity 0.9892):
[0001511737-14-000018:note_history:7]
The Company enters into standard indemnification agreements with many of its business partners in the ordinary course of business. These agreements include provisions for indemnifying the business partner against any claim brought by a third party to the extent any such claim alleges that a Ubiquiti product infringes a patent, copyright or trademark, or violates any other proprietary rights of that third party. The maximum potential amount of future payments the Company could be required to make under these indemnification agreements is not estimable and the Company has not incurred any material costs to defend lawsuits or settle claims related to these indemnification agreements to date.

- changed (2014-11-06):
[0001511737-14-000030:note_history:8]
Beginning on September 7, 2012, two class action lawsuits were filed in the United States District Court for the Northern District of California against Ubiquiti Networks, Inc., certain of its officers and directors, and the underwriters of its initial public offering, alleging claims under U.S. securities laws. On January 30, 2013, the plaintiffs filed an amended consolidated complaint. On March 26, 2014, the court issued an order granting a motion to dismiss the complaint with leave to amend. Following the plaintiffs’ decision not to file an amended complaint, on April 16, 2014, the court ordered the dismissal of the lawsuit with prejudice, and entered judgment in favor of the Company and the other defendants, and against the plaintiffs. On May 15, 2014, the plaintiffs filed a notice of appeal from the judgment of the court. The appeal is ongoing before the U.S. Court of Appeals for the Ninth Circuit. There can be no assurance that the Company will prevail in the appeal proceeding.  The Company cannot currently estimate the possible loss, if any, that it may experience in connection with this litigation.
  (was, 2014-05-09, similarity 0.7117):
[0001511737-14-000018:note_history:8]
Beginning on September 7, 2012, two class action lawsuits were filed in the United States District Court for the Northern District of California against Ubiquiti Networks, Inc. (the “Company”), certain of its officers and directors, and the underwriters of its initial public offering, alleging claims under U.S. securities laws. On January 30, 2013, the plaintiffs filed an amended consolidated complaint. The Company filed a motion to dismiss the complaint, and on March 26, 2014, the court issued an order granting the motion to dismiss with leave to amend the complaint. Following the plaintiffs’ decision not to file an amended complaint, on April 16, 2014 the court ordered the dismissal of the shareholder class action lawsuit with prejudice, and entered judgment in favor of the Company and the other defendants, and against the plaintiffs. The plaintiffs may appeal the court’s decision.


## us-gaap:BusinessDescriptionAndBasisOfPresentationTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2014-11-06):
[0001511737-14-000030:note_history:9]
Ubiquiti Networks, Inc. and its wholly owned subsidiaries (collectively, “Ubiquiti” or the “Company”) is a product driven company that leverages innovative proprietary technologies to deliver networking solutions to both startup and established network operators and service providers.
  (was, 2014-05-09, similarity 0.6342):
[0001511737-14-000018:note_history:9]
Ubiquiti Networks, Inc. and its wholly owned subsidiaries (collectively, “Ubiquiti” or the “Company”) develops high performance networking technology for service providers and enterprises.

- changed (2014-11-06):
[0001511737-14-000030:note_history:10]
These condensed consolidated financial statements should be read in conjunction with the Company’s audited consolidated financial statements for the fiscal year ended June 30, 2014 included in its Annual Report on Form 10-K, as filed on August 22, 2014 with the SEC (the “Annual Report”). The results of operations for the three months ended September 30, 2014 are not necessarily indicative of the results to be expected for any future periods.
  (was, 2014-05-09, similarity 0.7644):
[0001511737-14-000018:note_history:10]
These condensed consolidated financial statements should be read in conjunction with the Company’s audited consolidated financial statements for the fiscal year ended June 30, 2013 included in its Annual Report on Form 10-K, as filed on September 13, 2013 with the SEC (the “Annual Report”). The results of operations for the three and nine months ended March 31, 2014 are not necessarily indicative of the results to be expected for any future periods.

- removed (2014-11-06):
[0001511737-14-000018:note_history:11]
On October 13, 2011, the Company entered into an underwriting agreement for its initial public offering of 7,038,230 shares of its common stock at $15.00 per share.  The Company's initial public offering closed on October 19, 2011. Immediately prior to the closing of the initial public offering, all outstanding shares of the Company’s preferred stock converted to common stock on a one for one basis.

- removed (2014-11-06):
[0001511737-14-000018:note_history:12]
On June 18, 2013, the Company completed a secondary offering of 7,031,464 shares of common stock at an offering price of $16.00 per share, which included 531,464 shares sold in connection with the partial exercise of the option to purchase additional shares granted to the underwriters.  All of the shares sold in the offering were sold by existing stockholders of the Company, including entities affiliated with Summit Partners, L.P., and the Company's chief executive officer, Robert J. Pera.  No shares were sold by the Company in the offering, and as such, the Company did not receive any proceeds from the offering.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2014-11-06):
[0001511737-14-000030:note_history:13]
The Company’s significant accounting policies are disclosed in its audited consolidated financial statements for the year ended June 30, 2014 included in the Annual Report.
  (was, 2014-05-09, similarity 0.7557):
[0001511737-14-000018:note_history:13]
The Company’s significant accounting policies are disclosed in its audited consolidated financial statements for the year ended June 30, 2013 included in the Annual Report.  Unless otherwise noted below, the Company's significant accounting policies have not changed since June 30, 2013.

- added (2014-11-06):
[0001511737-14-000030:note_history:14]
In June 2014, the Financial Accounting Standards Board, or FASB, issued a new accounting standard update on revenue from contracts with customers.  The core principle of the guidance is that an entity should recognize revenue to depict the transfer of promised goods or services to customers in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services.  To achieve that core principle, an entity should apply the following steps:

- added (2014-11-06):
[0001511737-14-000030:note_history:15]
Step 1: Identify the contract(s) with a customer.

- added (2014-11-06):
[0001511737-14-000030:note_history:16]
Step 2: Identify the performance obligations in the contract.

- added (2014-11-06):
[0001511737-14-000030:note_history:17]
Step 3: Determine the transaction price.

- added (2014-11-06):
[0001511737-14-000030:note_history:18]
Step 4: Allocate the transaction price to the performance obligations in the contract.

- added (2014-11-06):
[0001511737-14-000030:note_history:19]
Step 5: Recognize revenue when (or as) the entity satisfies a performance obligation.

- added (2014-11-06):
[0001511737-14-000030:note_history:20]
An entity should disclose sufficient information to enable users of financial statements to understand the nature, amount, timing, and uncertainty of revenue and cash flows arising from contracts with customers. Qualitative and quantitative information is required about contracts with customers, significant judgments and any assets recognized from the costs to obtain or fulfill a contract.   The guidance will be effective for the Company beginning July 1, 2017.  The Company is currently assessing the impact of this new guidance.

- removed (2014-11-06):
[0001511737-14-000018:note_history:21]
Advertising Costs

- removed (2014-11-06):
[0001511737-14-000018:note_history:22]
The Company expenses all advertising costs as incurred. Advertising costs totaled $1.8 million and $2.4 million during the three and nine months ended March 31, 2014.  Advertising costs during the three and nine months ended March 31, 2013 were not significant.

- removed (2014-11-06):
[0001511737-14-000018:note_history:23]
In July 2013, the FASB issued a new accounting standard update on the financial statement presentation of unrecognized tax benefits.  The new guidance provides that a liability related to an unrecognized tax benefit would be presented as a reduction of a deferred tax asset for a new operating loss carryforward, a similar tax loss or a tax credit carryforward if such settlement is required or expected in the event the uncertain tax position is disallowed.  The new guidance will become effective for the Company on July 1, 2014 and it should be applied prospectively to unrecognized tax benefits that exist as of the effective date with retrospective application permitted.  The Company is currently assessing the impact of this new guidance.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2014-11-06):
[0001511737-14-000030:note_history:24]
On August 7, 2012, the Company entered into a Loan and Security Agreement (the “Loan Agreement”) with U.S. Bank, as syndication agent, and East West Bank, as administrative agent for the lenders party to the Loan Agreement.  The Loan Agreement provides for (i) a $50.0 million revolving credit facility, with a $5.0 million sublimit for the issuance of letters of credit and a $5.0 million sublimit for the making of swingline loan advances (the “Revolving Credit Facility”), and (ii) a $50.0 million term loan facility (the “Term Loan Facility”). The Company may request borrowings under the Revolving Credit Facility until August 7, 2015.  The Loan Agreement replaced a previous agreement whereby the Company had an existing term loan balance of $29.2 million as of the date the new Loan Agreement.  On August 7, 2012, the Company borrowed $20.8 million under the Term Loan Facility, and no borrowings remain available for borrowing thereunder.  On November 21, 2012, the Company borrowed $10.0 million under the Revolving Credit Facility. On December 20, 2012, the Company borrowed an additional $20.0 million under the Revolving Credit Facility, and $20.0 million remains available for borrowing thereunder.  During the three months ended September 30, 2013 the Company made aggregate payments of $1.3 million against the loan balance.
  (was, 2014-05-09, similarity 0.9506):
[0001511737-14-000018:note_history:24]
On August 7, 2012, the Company entered into a Loan and Security Agreement (the “Loan Agreement”) with U.S. Bank, as syndication agent, and East West Bank, as administrative agent for the lenders party to the Loan Agreement.  The Loan Agreement provides for (i) a $50.0 million revolving credit facility, with a $5.0 million sublimit for the issuance of letters of credit and a $5.0 million sublimit for the making of swingline loan advances (the “Revolving Credit Facility”), and (ii) a $50.0 million term loan facility (the “Term Loan Facility”). The Company may request borrowings under the Revolving Credit Facility until August 7, 2015.  The Loan Agreement replaced a previous agreement whereby the Company had an existing term loan balance of $29.2 million as of the date the new Loan Agreement.  On August 7, 2012, the Company borrowed $20.8 million under the Term Loan Facility, and no borrowings remain available for borrowing thereunder.  On November 21, 2012, the Company borrowed $10.0 million under the Revolving Credit Facility. On December 20, 2012, the Company borrowed an additional $20.0 million under the Revolving Credit Facility, and $20.0 million remains available for borrowing thereunder.

- added (2014-11-06):
[0001511737-14-000030:note_history:25]
On May 5, 2014, the Company and certain of its subsidiaries entered into a credit agreement (the “Credit Agreement”) with Wells Fargo Bank, National Association (“Wells Fargo”), the financial institutions named as lenders therein, and Wells Fargo as administrative agent for the lenders, that provides for a $150 million senior secured revolving credit facility, with an option to request an increase in the amount of the credit facility by up to an additional $50 million (any such increase to be in each lender’s sole discretion).  The Company may borrow up to $110 million of the facility as a U.S. sublimit.  The entire amount of the facility is available to Ubiquiti International Holding Company Limited, a wholly-owned subsidiary of the Company organized under the laws of the Cayman Islands.  The credit facility includes a sub-limit of $5 million for letters of credit and a sub-limit of $15 million for swingline loans.   In connection with the execution of the Credit Agreement, the Company terminated the $50 million line of credit facility under the Loan Agreement with East West Bank described above.  Under the Credit Agreement, revolving loans and swingline loans may be borrowed, repaid and reborrowed until May 5, 2019, at which time all amounts borrowed must be repaid.   Additionally, $72.3 million is currently outstanding under the Credit Agreement, which was borrowed by the Company to repay obligations under the Loan Agreement and to pay transaction fees and costs.  Revolving loans bear interest, at the Company’s option, at either (i) a floating rate per annum equal to the base rate plus a margin of between 0.250% and 1.000%, depending on the Company’s leverage ratio as of the most recently ended fiscal quarter or (ii) a per annum rate equal to the applicable LIBOR rate for a specified period, plus a margin of between 1.250% and 2.000%, depending on the Company’s leverage ratio as of the most recently ended fiscal quarter.  Swingline loans will bear interest at a floating rate per annum equal to the base rate plus a margin of between 0.250% and 1.000%, depending on the Company’s leverage ratio as of the most recently ended fiscal quarter.   Base rate is defined as the greatest of (A) Wells Fargo’s prime rate, (B) the federal funds rate plus 0.500% or (C) a per annum rate equal to the rate at which dollar deposits are offered in the London interbank market for a period of one month plus 1.000%.  A default interest rate shall apply on all obligations during a payment event of default under the Credit Agreement at a rate per annum equal to 2.000% above the applicable interest rate. The Company will pay to each lender a facility fee on a quarterly basis based on the unused amount of each lender’s commitment to make loans, of between 0.200% and 0.350%, depending on the Company’s leverage ratio as of the most recently ended fiscal quarter.  Revolving loans and swingline loans may be prepaid at any time without penalty.  The Company is also obligated to pay Wells Fargo, as agent, fees customary for a credit facility of this size and type.

- added (2014-11-06):
[0001511737-14-000030:note_history:26]
The Credit Agreement requires the Company to maintain a maximum leverage ratio and a minimum interest coverage ratio during the term of the credit facility.  In addition, the Credit Agreement contains customary affirmative and negative covenants, including covenants that limit or restrict the ability of the Company and its subsidiaries to, among other things, grant liens or enter into agreements restricting their ability to grant liens on property, enter into mergers, dispose of assets, change their accounting or reporting policies, change their business and incur subsidiary indebtedness, in each case subject to customary exceptions for a credit facility of this size and type.  The Credit Agreement includes customary events of default that, include among other things, non-payment of principal, interest or fees, inaccuracy of representations and warranties, violation of covenants, cross default to certain other indebtedness, bankruptcy and insolvency events, material judgments, change of control and certain ERISA events. The occurrence of an event of default could result in the acceleration of the obligations under the Credit Agreement.  The credit facility under the Credit Agreement expires May 5, 2019.

- added (2014-11-06):
[0001511737-14-000030:note_history:27]
The obligations of the Company and its subsidiaries under the Credit Agreement are collateralized by substantially all assets (excluding intellectual property) of the Company and its subsidiaries.

- added (2014-11-06):
[0001511737-14-000030:note_history:28]
Wells Fargo and the lenders party to the Credit Agreement, and certain of their respective affiliates, have provided, and in the future may provide, financial, banking and related services to the Company. These parties have received, and in the future may receive, compensation from the Company for these services.

- added (2014-11-06):
[0001511737-14-000030:note_history:29]
No payments were made for borrowings under the Credit Agreement with Wells Fargo in the three months ended September 30, 2014.  As of September 30, 2014, the Company has classified $72.3 million of long-term debt on its consolidated balance sheet related to the Credit Agreement.

- changed (2014-11-06):
[0001511737-14-000030:note_history:30]
The following table summarizes our estimated debt and interest payment obligations as of September 30, 2014 (in thousands):
  (was, 2014-05-09, similarity 0.7762):
[0001511737-14-000018:note_history:30]
The following table summarizes our estimated debt and interest payment obligations as of March 31, 2014 for the remainder of fiscal 2014 and future fiscal years (in thousands):

- changed (2014-11-06):
[0001511737-14-000030:note_history:31]
|  | 2015(remainder) |  | 2016 |  | 2017 |  | 2018 |  | 2019 |  | Total |
| Debt payment obligations | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 72,254 |  |  | $ | 72,254 |  |
| Interest payments on debt payment obligations | 761 |  |  | 1,014 |  |  | 1,014 |  |  | 1,014 |  |  | 858 |  |  | 4,661 |  |
| Total | $ | 761 |  |  | $ | 1,014 |  |  | $ | 1,014 |  |  | $ | 1,014 |  |  | $ | 73,112 |  |  | $ | 76,915 |  |
  (was, 2014-05-09, similarity 0.8855):
[0001511737-14-000018:note_history:31]
|  | 2014 (remainder) |  | 2015 |  | 2016 |  | 2017 |  | 2018 |  | Total |
| Debt payment obligations | $ | 1,250 |  |  | $ | 6,875 |  |  | $ | 39,375 |  |  | $ | 10,000 |  |  | $ | 15,000 |  |  | $ | 72,500 |  |
| Interest payments on debt payment obligations | 446 |  |  | 1,723 |  |  | 1,043 |  |  | 532 |  |  | 125 |  |  | 3,869 |  |
| Total | $ | 1,696 |  |  | $ | 8,598 |  |  | $ | 40,418 |  |  | $ | 10,532 |  |  | $ | 15,125 |  |  | $ | 76,369 |  |

- removed (2014-11-06):
[0001511737-14-000018:note_history:32]
The loans bear interest, at the Company’s option, at the base rate plus a spread of 1.25% to 1.75% or an adjusted LIBOR rate (at the Company’s election, for a period of 30, 60, or 90 days) plus a spread of 2.25% to 2.75%, in each case with such spread being determined based on the debt service coverage ratio for its most recently ended fiscal quarter. The base rate is the highest of (i) East West Bank’s prime rate, (ii) the federal funds rate plus a margin equal to 0.50%, or (iii) the LIBOR rate plus a margin equal to 1.00%. The Company is also obligated to pay other customary closing fees, arrangement fees, administration fees, commitment fees and letter of credit fees for a credit facility of this size and type.

- removed (2014-11-06):
[0001511737-14-000018:note_history:33]
Interest is due and payable monthly in arrears in the case of loans bearing interest at the base rate and at the end of an interest period in the case of loans bearing interest at the adjusted LIBOR rate. Principal payments under the Term Loan Facility will be made in quarterly installments on the first day of each calendar quarter, and each such quarterly installment shall be equal to $1.25 million through July 1, 2014, then equal to $1.875 million from October 1, 2014 through July 1, 2015, and then equal to $2.5 million from October 1, 2015 through July 1, 2017, with the remaining outstanding principal balance and all accrued and unpaid interest due on August 7, 2017. All outstanding loans under the Revolving Credit Facility, together with all accrued and unpaid interest, are due on August 7, 2015.

- removed (2014-11-06):
[0001511737-14-000018:note_history:34]
The Company may prepay the loans, in whole or in part, at any time without premium or penalty, subject to certain conditions including minimum amounts and reimbursement of certain costs in the case of prepayments of LIBOR loans. In addition, the Company is required to prepay the loan under the Term Loan Facility with (i) the proceeds from certain financing transactions or asset sales (subject, in the case of asset sales, to reinvestment rights) and (ii) 25.0% of the Company’s excess cash flow in the U.S., as determined after each fiscal year and in accordance with the Loan Agreement, provided that the Company shall not be required to prepay the loan out of its excess cash flow if its leverage ratio is greater than 1.50:1.00 on the last day of such fiscal year.

- removed (2014-11-06):
[0001511737-14-000018:note_history:35]
All of the obligations of the Company under the Loan Agreement are collateralized by substantially all of the Company’s assets, including all of the capital stock of the Company’s future domestic subsidiaries and 65% of the capital stock of the Company’s existing and future foreign subsidiaries, but excluding the Company’s intellectual property, which is subject to a negative pledge agreement. All of the Company’s future domestic subsidiaries are required to guaranty the obligations under the Loan Agreement. Such guarantees by future subsidiaries will be collateralized by substantially all of the property of such subsidiaries, excluding intellectual property.

- removed (2014-11-06):
[0001511737-14-000018:note_history:36]
The Loan Agreement contains customary affirmative and negative covenants, including covenants that limit or restrict the Company and its subsidiaries’ ability to, among other things, incur indebtedness, grant liens, merge or consolidate, dispose of assets, pay dividends or make distributions, make investments, make acquisitions, prepay certain indebtedness, change the nature of its business, enter into certain transactions with affiliates, enter into restrictive agreements, and make capital expenditures, in each case subject to customary exceptions for a credit facility of this size and type. The Company is also required to maintain a minimum debt service coverage ratio, a maximum leverage ratio, and a minimum liquidity ratio.  As of March 31, 2014, the Company was in compliance with all affirmative and negative covenants, debt service coverage ratio, leverage ratio and liquidity ratio requirements.

- removed (2014-11-06):
[0001511737-14-000018:note_history:37]
The Loan Agreement includes customary events of default that include, among other things, defaults for the failure to timely pay principal, interest, or other amounts due, defaults due to the inaccuracy of representations and warranties, covenant defaults, a cross default to material indebtedness, bankruptcy and insolvency defaults, material judgment defaults, defaults due to the unenforceability of a guaranty, and defaults due to circumstances that have or could reasonably be expected to have a material adverse effect on the Company's business, operations or financial condition, its ability to pay or perform under the Loan Agreement, or on the lenders' security interests. The occurrence of an event of default could result in the acceleration of the obligations under the Loan Agreement. During the existence of an event of default, interest on the obligations under the Loan Agreement could be increased by 2.00% above the otherwise applicable interest rate.

- removed (2014-11-06):
[0001511737-14-000018:note_history:38]
During the three and nine months ended March 31, 2014, the Company made aggregate payments of $1.3 million and $3.8 million, respectively, against the loan balance.  During the three and nine months ended March 31, 2013, the Company made aggregate payments of $1.3 million and $3.1 million, respectively, against the loan balance.  As of March 31, 2014, the Company has classified $6.3 million and $66.1 million in short-term and long-term debt, respectively, on its condensed consolidated balance sheet related to the Loan Agreement.

- removed (2014-11-06):
[0001511737-14-000018:note_history:39]
On May 5, 2014, the Company entered into a credit agreement with Wells Fargo Bank, National Association (“Wells Fargo”), the financial institutions named as lenders therein, and Wells Fargo as administrative agent for the lenders.  In connection with the execution of the credit agreement, the Company terminated and repaid all outstanding obligations under the Term Loan Facility and Revolving Credit Facility under the Loan Agreement described above.  Please see Part 1, Item 1, Note 14 below for a full description of the credit agreement.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2014-11-06):
[0001511737-14-000030:note_history:40]
The following table summarizes our estimated debt and interest payment obligations as of September 30, 2014 (in thousands):
  (was, 2014-05-09, similarity 0.7762):
[0001511737-14-000018:note_history:40]
The following table summarizes our estimated debt and interest payment obligations as of March 31, 2014 for the remainder of fiscal 2014 and future fiscal years (in thousands):

- changed (2014-11-06):
[0001511737-14-000030:note_history:41]
|  | 2015(remainder) |  | 2016 |  | 2017 |  | 2018 |  | 2019 |  | Total |
| Debt payment obligations | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 72,254 |  |  | $ | 72,254 |  |
| Interest payments on debt payment obligations | 761 |  |  | 1,014 |  |  | 1,014 |  |  | 1,014 |  |  | 858 |  |  | 4,661 |  |
| Total | $ | 761 |  |  | $ | 1,014 |  |  | $ | 1,014 |  |  | $ | 1,014 |  |  | $ | 73,112 |  |  | $ | 76,915 |  |
  (was, 2014-05-09, similarity 0.8855):
[0001511737-14-000018:note_history:41]
|  | 2014 (remainder) |  | 2015 |  | 2016 |  | 2017 |  | 2018 |  | Total |
| Debt payment obligations | $ | 1,250 |  |  | $ | 6,875 |  |  | $ | 39,375 |  |  | $ | 10,000 |  |  | $ | 15,000 |  |  | $ | 72,500 |  |
| Interest payments on debt payment obligations | 446 |  |  | 1,723 |  |  | 1,043 |  |  | 532 |  |  | 125 |  |  | 3,869 |  |
| Total | $ | 1,696 |  |  | $ | 8,598 |  |  | $ | 40,418 |  |  | $ | 10,532 |  |  | $ | 15,125 |  |  | $ | 76,369 |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2014-11-06):
[0001511737-14-000030:note_history:42]
On November 13, 2013, the Company entered into an aircraft lease agreement (the "Aircraft Lease Agreement") with RJP Manageco LLC (the "Lessor"), a limited liability company owned by the Company’s CEO, Robert J. Pera. Pursuant to the Aircraft Lease Agreement, the Company may lease an aircraft owned by the Lessor for Company business purposes. Under the Aircraft Lease Agreement, the aircraft may be leased at a rate of $5,000 per flight hour. This hourly rate does not include the cost of flight crew or on-board services, which the Company purchases from a third-party provider. The Company recognized a total of approximately $151,000 in expenses pursuant to the Aircraft Lease Agreement during the three months ended September 30, 2014.  All expenses pursuant to the Aircraft Lease Agreement have been included in the Company's sales, general and administrative expenses in the Condensed Consolidated Statements of Operations.
  (was, 2014-05-09, similarity 0.8414):
[0001511737-14-000018:note_history:42]
On November 13, 2013, the Company entered into an aircraft lease agreement (the "Aircraft Lease Agreement") with RJP Manageco LLC (the "Lessor"), a limited liability company owned by the Company’s CEO, Robert J. Pera. Pursuant to the Aircraft Lease Agreement, the Company may lease an aircraft owned by the Lessor for Company business purposes. Under the Aircraft Lease Agreement, the aircraft may be leased at a rate of $5,000 per flight hour. This hourly rate does not include the cost of flight crew or on-board services, which the Company will purchase from a third-party provider. The Company recognized a total of approximately $120,000 in expenses pursuant to the Aircraft Lease Agreement during the three months ended March 31, 2014.  All expenses pursuant to the Aircraft Lease Agreement have been included in the Company's sales, general and administrative expenses in the Condensed Consolidated Statements of Operations.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_current_note, score: 0.0

- removed (2014-11-06):
[0001511737-14-000018:note_history:43]
SUBSEQUENT EVENTS

- removed (2014-11-06):
[0001511737-14-000018:note_history:44]
On May 5, 2014, the Company and certain of its subsidiaries entered into a credit agreement (the “Credit Agreement”) with Wells Fargo Bank, National Association (“Wells Fargo”), the financial institutions named as lenders therein, and Wells Fargo as administrative agent for the lenders, that provides for a $150 million senior secured revolving credit facility, with an option to request an increase in the amount of the credit facility by up to an additional $50 million (any such increase to be in each lender’s sole discretion).  The Company may borrow up to $110 million of the facility as a U.S. sublimit.  The entire amount of the facility is available to Ubiquiti International Holding Company Limited, a wholly-owned subsidiary of the Company organized under the laws of the Cayman Islands.  The credit facility includes a sub-limit of $5 million for letters of credit and a sub-limit of $15 million for swingline loans.   In connection with the execution of the Credit Agreement, the Company terminated the $50 million line of credit facility under the Loan Agreement described in Note 7, “Debt”.  Under the Credit Agreement, revolving loans and swingline loans may be borrowed, repaid and reborrowed until May 5, 2019, at which time all amounts borrowed must be repaid.   Additionally, $72.3 million is currently outstanding under the Credit Agreement, which was borrowed by the Company to repay obligations under the Loan Agreement and to pay transaction fees and costs.  Revolving loans bear interest, at the Company’s option, at either (i) a floating rate per annum equal to the base rate plus a margin of between 0.250% and 1.000%, depending on the Company’s leverage ratio as of the most recently ended fiscal quarter or (ii) a per annum rate equal to the applicable LIBOR rate for a specified period, plus a margin of between 1.250% and 2.000%, depending on the Company’s leverage ratio as of the most recently ended fiscal quarter.  Swingline loans will bear interest at a floating rate per annum equal to the base rate plus a margin of between 0.250% and 1.000%, depending on the Company’s leverage ratio as of the most recently ended fiscal quarter.   Base rate is defined as the greatest of (A) Wells Fargo’s prime rate, (B) the federal funds rate plus 0.500% or (C) a per annum rate equal to the rate at which dollar deposits are offered in the London interbank market for a period of one month plus 1.000%.  A default interest rate shall apply on all obligations during a payment event of default under the Credit Agreement at a rate per annum equal to 2.000% above the applicable interest rate. The Company will pay to each lender a facility fee on a quarterly basis based on the unused amount of each lender’s commitment to make loans, of between 0.200% and 0.350%, depending on the Company’s leverage ratio as of the most recently ended fiscal quarter.  Revolving loans and swingline loans may be prepaid at any time without penalty.  The Company is also obligated to pay Wells Fargo, as agent, fees customary for a credit facility of this size and type.

- removed (2014-11-06):
[0001511737-14-000018:note_history:45]
The Credit Agreement requires the Company to maintain a maximum leverage ratio and a minimum interest coverage ratio during the term of the credit facility.  In addition, the Credit Agreement contains customary affirmative and negative covenants, including covenants that limit or restrict the ability of the Company and its subsidiaries to, among other things, grant liens or enter into agreements restricting their ability to grant liens on property, enter into mergers, dispose of assets, change their accounting or reporting policies, change their business and incur subsidiary indebtedness, in each case subject to customary exceptions for a credit facility of this size and type.  The Credit Agreement includes customary events of default that, include among other things, non-payment of principal, interest or fees, inaccuracy of representations and warranties, violation of covenants, cross default to certain other indebtedness, bankruptcy and insolvency events, material judgments, change of control and certain ERISA events. The occurrence of an event of default could result in the acceleration of the obligations under the Credit Agreement.  The credit facility under the Credit Agreement expires May 5, 2019.

- removed (2014-11-06):
[0001511737-14-000018:note_history:46]
The obligations of the Company and its subsidiaries under the Credit Agreement are collateralized by substantially all assets (excluding intellectual property) of the Company and its subsidiaries.

- removed (2014-11-06):
[0001511737-14-000018:note_history:47]
Wells Fargo and the lenders party to the Credit Agreement, and certain of their respective affiliates, have provided, and in the future may provide, financial, banking and related services to the Company. These parties have received, and in the future may receive, compensation from the Company for these services.
