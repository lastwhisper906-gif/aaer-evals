# UI 8-K — 0001511737-14-000029 filed 2014-11-06

## item codes, every 8-K on or before 2014-11-06

- 2014-11-06 0001511737-14-000029 — 2.02, 9.01
- 2014-09-30 0001193125-14-359060 — 7.01, 9.01
- 2014-08-07 0001511737-14-000021 — 2.02, 9.01
- 2014-05-08 0001511737-14-000016 — 2.02, 9.01
- 2014-04-17 0001193125-14-146710 — 7.01
- 2014-03-06 0001193125-14-084883 — 8.01
- 2014-02-06 0001511737-14-000005 — 2.02, 9.01
- 2013-12-16 0001193125-13-474388 — 5.07
- 2013-11-22 0001193125-13-451511 — 5.02
- 2013-11-07 0001511737-13-000018 — 2.02, 9.01
- 2013-10-28 0001193125-13-413414 — 5.02, 9.01
- 2013-10-18 0001193125-13-404111 — 5.02, 9.01
- 2013-08-08 0001511737-13-000009 — 2.02, 9.01
- 2013-05-09 0001511737-13-000004 — 2.02
- 2013-03-25 0001193125-13-124353 — 5.07
- 2013-03-08 0001193125-13-098334 — 5.02, 9.01
- 2013-02-07 0001193125-13-043701 — 2.02, 9.01
- 2012-12-28 0001193125-12-518487 — 1.01
- 2012-12-17 0001193125-12-503742 — 7.01, 9.01
- 2012-12-13 0001193125-12-501894 — 5.02
- 2012-11-16 0001193125-12-474083 — 5.02
- 2012-11-13 0001193125-12-467376 — 5.02
- 2012-11-08 0001193125-12-460665 — 2.02, 9.01
- 2012-10-10 0001193125-12-420015 — 5.02, 9.01
- 2012-08-13 0001193125-12-352624 — 1.01, 2.03, 9.01
- 2012-08-09 0001193125-12-347776 — 1.01, 9.01
- 2012-08-09 0001193125-12-347732 — 2.02, 9.01
- 2012-05-01 0001193125-12-201012 — 2.02, 9.01
- 2012-03-30 0001193125-12-144074 — 5.02
- 2012-03-27 0001193125-12-134395 — 5.02, 9.01
- 2012-03-22 0001193125-12-127536 — 5.02
- 2012-01-31 0001193125-12-032079 — 2.02, 9.01
- 2011-12-27 0001193125-11-353002 — 1.01, 9.01
- 2011-12-06 0001193125-11-332192 — 5.02
- 2011-11-10 0001193125-11-306969 — 2.02, 9.01

## late-filing notifications on or before 2014-11-06

- none on or before 2014-11-06

## item 2.02 — earnings release, exhibit 99.1

[0001511737-14-000029:8k_2_02:1]
EX-99.1
2
exhibit991q12015.htm
PRESS RELEASE OF UBIQUITI NETWORKS, INC.

[0001511737-14-000029:8k_2_02:2]
Exhibit 99.1 Q1 2015

[0001511737-14-000029:8k_2_02:3]
Exhibit 99.1

[0001511737-14-000029:8k_2_02:4]
UBIQUITI NETWORKS REPORTS FIRST QUARTER FISCAL 2015 FINANCIAL RESULTS

[0001511737-14-000029:8k_2_02:5]
San Jose, Calif. - November 6, 2014 - Ubiquiti Networks, Inc. (NASDAQ:UBNT) (“Ubiquiti”) today announced results for the first fiscal quarter of 2015 ended September 30, 2014.

[0001511737-14-000029:8k_2_02:6]
First Quarter Financial Summary

[0001511737-14-000029:8k_2_02:7]
| • | Revenues of $150.1 million, up 16% year-over-year. |

[0001511737-14-000029:8k_2_02:8]
| • | GAAP net income of $37.7 million and non-GAAP net income of $43.4 million. |

[0001511737-14-000029:8k_2_02:9]
| • | GAAP operating profit of $43.6 million and non-GAAP operating profit of $50.5 million. |

[0001511737-14-000029:8k_2_02:10]
| • | GAAP diluted EPS of $0.42 and non-GAAP diluted EPS of $0.48. |

[0001511737-14-000029:8k_2_02:11]
| • | Cash of $391.0 million, up 40% year-over-year and 13% sequentially. |

[0001511737-14-000029:8k_2_02:12]
| • | $46.9 million in net cash provided by operating activities. |

[0001511737-14-000029:8k_2_02:13]
Recent Business and Product Highlights

[0001511737-14-000029:8k_2_02:14]
| • | Record growth in Enterprise Technology, primarily due to further product expansion and momentum in our UniFi® technology platform. |

[0001511737-14-000029:8k_2_02:15]
| • | Strong demand for some key products within Service Provider Technology, including airFiber® 5, airMAX® ac and EdgeMAX®. |

[0001511737-14-000029:8k_2_02:16]
| • | Signed new distribution agreements with ECS and Redington, leading technology distributors in China and India, respectively, who we expect to accelerate our expansion into established and emerging markets. |

[0001511737-14-000029:8k_2_02:17]
| • | Announced annual dividend policy, as part of our long-term strategy to maximize shareholder value and broaden our shareholder base. |

[0001511737-14-000029:8k_2_02:18]
Financial Summary ($, in millions, except per share data)

[0001511737-14-000029:8k_2_02:19]
| Financials |  | F1Q15 |  | F4Q14 |  | F1Q14 |
| Revenues |  | 150.1 |  | 156.0 |  | 129.7 |
| Service Provider Technology |  | 107.3 |  | 124.0 |  | 94.2 |
| Enterprise Technology |  | 42.8 |  | 32.0 |  | 35.5 |
| Cost of Revenues |  | 89.0 |  | 87.1 |  | 71.7 |
| Gross Profit |  | 61.0 |  | 68.9 |  | 58.0 |
| Total Operating Expenses |  | 17.4 |  | 16.1 |  | 12.1 |
| Income from Operations |  | 43.6 |  | 52.8 |  | 45.9 |
| GAAP Net Income |  | 37.7 |  | 49.4 |  | 40.5 |
| GAAP EPS (diluted) |  | 0.42 |  | 0.55 |  | 0.45 |
| Non-GAAP Net Income |  | 43.4 |  | 50.2 |  | 41.2 |
| Non-GAAP EPS (diluted) |  | 0.48 |  | 0.56 |  | 0.46 |

[0001511737-14-000029:8k_2_02:20]
Balance Sheet Highlights

[0001511737-14-000029:8k_2_02:21]
Total cash and cash equivalents as of September 30, 2014 were $391.0 million, compared with $347.1 million as of June 30, 2014.  We believe that our cash position will allow us to make investments that will continue to enhance our competitive position and product portfolio.

[0001511737-14-000029:8k_2_02:22]
This quarter we saw Day Sales Outstanding in accounts receivable ("DSO") of 40 days, compared with 32 days in the prior quarter, and 25 days in the first quarter of fiscal 2014.  DSO for the quarter reflects our strategic addition of larger distributors worldwide to whom we extend longer credit terms.  This quarter’s DSO is at the low end of our long term target DSO range of approximately 40 to 45 days.

[0001511737-14-000029:8k_2_02:23]
“We continue to ramp our R&D investments to accelerate our long-term technology vision for our service provider and enterprise platforms and we expect to have several significant technology introductions in fiscal year 2015” said Robert J. Pera, Founder and Chief Executive Officer of Ubiquiti Networks.

[0001511737-14-000029:8k_2_02:24]
Business Outlook

[0001511737-14-000029:8k_2_02:25]
The following are Ubiquiti’s financial performance estimates for the second quarter of fiscal 2015:

[0001511737-14-000029:8k_2_02:26]
| • | Revenues of between $147 million and $153 million |

[0001511737-14-000029:8k_2_02:27]
| • | GAAP diluted EPS of between $0.45 and $0.48 |

[0001511737-14-000029:8k_2_02:28]
| • | Non-GAAP diluted EPS of between $0.46 and $0.49 |

[0001511737-14-000029:8k_2_02:29]
Conference Call Information

[0001511737-14-000029:8k_2_02:30]
Ubiquiti Networks will host a Q&A-only conference call to discuss the Company’s financial results at 2:00 p.m. Pacific Time today.  Management’s prepared remarks can be found on the Investor Relations section of the Ubiquiti Networks website, http://ir.ubnt.com.

[0001511737-14-000029:8k_2_02:31]
To listen to the Q&A-only conference call via telephone, dial (877) 291-1296 (U.S. toll-free) or (720) 259-9209 (International) to be connected to the call by an operator.  Participants should dial in at least 10 minutes prior to the start of the call.  Investors may also listen to a live webcast of the Q&A-only conference call by visiting the Investor Relations section of the Ubiquiti Networks website, http://ir.ubnt.com.

[0001511737-14-000029:8k_2_02:32]
A recording of the Q&A call will be available approximately two hours after the call concludes and will be accessible on the Investor Relations section of the Ubiquiti Networks website, http://ir.ubnt.com.

[0001511737-14-000029:8k_2_02:33]
About Ubiquiti Networks

[0001511737-14-000029:8k_2_02:34]
Ubiquiti Networks, Inc. (Nasdaq:UBNT) is closing the digital divide by building network communication platforms for everyone and everywhere. With over 20 million devices deployed in over 180 countries, Ubiquiti is transforming under-networked enterprises and communities. Our leading edge platforms, airMAX®, UniFi®, airFiber®, UniFi® Video, mFi® and EdgeMAX® combine innovative technology, disruptive price-to-performance and the support of a global user community to eliminate barriers to connectivity. For more information, join our community at http://www.ubnt.com.

[0001511737-14-000029:8k_2_02:35]
Ubiquiti, the Ubiquiti U logo, Ubiquiti Networks, airMAX, airFiber, UniFi, mFi, and EdgeMAX are registered trademarks or trademarks of Ubiquiti Networks, Inc. in the United States and other countries.

[0001511737-14-000029:8k_2_02:36]
Investor Relations Contact

[0001511737-14-000029:8k_2_02:37]
Anne Fazioli

[0001511737-14-000029:8k_2_02:38]
Ubiquiti Networks, Vice President of Investor Relations

[0001511737-14-000029:8k_2_02:39]
IR@ubnt.com

[0001511737-14-000029:8k_2_02:40]
Forward-looking statements are subject to certain risks and uncertainties that could cause our actual future results to differ materially, or cause a material adverse impact on our results.  Potential risks and uncertainties include, but are not limited to, fluctuations in our operating results; varying demand for our products due to the financial and operating condition of our distributors and their customers, distributors' inventory management practices and general economic conditions; impact of counterfeiting and our ability to contain such impact; our reliance on a limited number of distributors; inability of our contract manufacturers and suppliers to meet our demand; our dependence on Qualcomm Atheros for chipsets without a short-term alternative; as we move into new markets competition from certain of our current or potential competitors who may be more established in such markets; our ability to keep pace with technological and market developments; success and timing of new product introductions by us and the performance of our products generally; our ability to effectively manage the significant increase in our transactional sales volumes; we may become subject to warranty claims, product liability and product recalls; that a substantial majority of our sales are into countries outside the United States and we are subject to numerous U.S. export control and economic sanctions laws; costs related to responding to government inquiries related to regulatory compliance; our reliance on the Ubiquiti Community; our reliance on certain key members of our management team, including our founder and chief executive officer, Robert J. Pera; adverse tax-related matters such as tax audits, changes in our effective tax rate or new tax legislative proposals; whether the final determination of our income tax liability may be materially different from our income tax provisions; the impact of any intellectual property litigation and claims for indemnification and litigation related to U.S. Securities laws and economic and political conditions in the United States and abroad.  We discuss these risks in greater detail under the heading “Risk Factors” and elsewhere in our Annual Report on Form 10-K for the year ended June 30, 2014 and subsequent filings filed with the U.S. Securities and Exchange Commission (the SEC), which are available at the SEC's website at www.sec.gov.  Copies may also be obtained by contacting the Ubiquiti Networks Investor Relations Department, by email at IR@ubnt.com or by visiting the Investor Relations section of the Ubiquiti Networks website, http://ir.ubnt.com.

[0001511737-14-000029:8k_2_02:41]
Given these uncertainties, you should not place undue reliance on these forward-looking statements.  Also, forward-looking statements represent our management's beliefs and assumptions only as of the date made.  Ubiquiti Networks undertakes no obligation to update information contained herein.  You should review our SEC filings carefully and with the understanding that our actual future results may be materially different from what we expect.

[0001511737-14-000029:8k_2_02:42]
Use of Non-GAAP Financial Information

[0001511737-14-000029:8k_2_02:43]
To supplement our condensed consolidated financial results prepared under generally accepted accounting principles, or GAAP, we use non-GAAP measures of net income and earnings per diluted share that are adjusted to exclude certain costs, expenses and gains such as stock based compensation expense, purchase commitment termination fee and the tax effects of these non-GAAP adjustments.  Reconciliations of the adjustments to GAAP results for the three months ended September 30, 2014 and 2013 are provided below.  In addition, an explanation of the ways in which management uses non-GAAP financial information to evaluate its business, the substance behind management's decision to use this non-GAAP financial information, material limitations associated with the use of non-GAAP financial information, the manner in which management compensates for those limitations, and the substantive reasons management believes that this non-GAAP financial information provides useful information to investors is included under "About our Non-GAAP Net Income and Adjustments" after the tables below.

[0001511737-14-000029:8k_2_02:44]
| Ubiquiti Networks Inc.Condensed Consolidated Statement of Operations(In thousands, except per share data)(Unaudited) |
|  |  | Three Months Ended September 30, |
|  |  | 2014 |  | 2013 |
| Revenues |  | $ | 150,087 |  |  | $ | 129,687 |  |
| Cost of revenues |  | 89,036 |  |  | 71,664 |  |
| Gross profit |  | 61,051 |  |  | 58,023 |  |
| Operating expenses: |  |  |  |  |
| Research and development |  | 11,721 |  |  | 6,317 |  |
| Sales, general and administrative |  | 5,696 |  |  | 5,810 |  |
| Total operating expenses |  | 17,417 |  |  | 12,127 |  |
| Income from operations |  | 43,634 |  |  | 45,896 |  |
| Interest expense and other, net |  | (58 | ) |  | (246 | ) |
| Income before provision for income taxes |  | 43,576 |  |  | 45,650 |  |
| Provision for income taxes |  | 5,833 |  |  | 5,122 |  |
| Net income |  | $ | 37,743 |  |  | $ | 40,528 |  |
| Net income per share of common stock: |  |  |  |  |
| Basic |  | $ | 0.43 |  |  | $ | 0.46 |  |
| Diluted |  | $ | 0.42 |  |  | $ | 0.45 |  |
| Weighted average shares used in computing net income per share of common stock: |  |  |  |  |
| Basic |  | 88,240 |  |  | 87,411 |  |
| Diluted |  | 89,913 |  |  | 89,473 |  |

[0001511737-14-000029:8k_2_02:45]
| Ubiquiti Networks Inc.Reconciliation of GAAP Net Income to Non-GAAP Net Income(In thousands, except per share data)(Unaudited) |
|  |  | Three Months Ended September 30, |
|  |  | 2014 |  | 2013 |
| Net income |  | $ | 37,743 |  |  | $ | 40,528 |  |
| Stock-based compensation: |  |  |  |  |
| Cost of revenues |  | 149 |  |  | 144 |  |
| Research and development |  | 825 |  |  | 496 |  |
| Sales, general and administrative |  | 398 |  |  | 527 |  |
| Purchase commitment termination fee |  | 5,500 |  |  | — |  |
| Tax effect of non-GAAP adjustments |  | (1,209 | ) |  | (467 | ) |
| Non-GAAP net income |  | $ | 43,406 |  |  | $ | 41,228 |  |
| Non-GAAP diluted EPS |  | $ | 0.48 |  |  | $ | 0.46 |  |
| Weighted-average shares used in non-GAAP diluted EPS |  | 89,913 |  |  | 89,473 |  |

[0001511737-14-000029:8k_2_02:46]
| Ubiquiti Networks Inc.Condensed Consolidated Balance Sheets(In thousands, except share amounts)(Unaudited) |
|  |  | September 30, 2014 |  | June 30, 2014(1) |
| Assets |  |  |  |  |
| Current assets: |  |  |  |  |
| Cash and cash equivalents |  | $ | 391,016 |  |  | $ | 347,097 |  |
| Accounts receivable, net |  | 65,875 |  |  | 54,871 |  |
| Inventories |  | 38,747 |  |  | 46,349 |  |
| Current deferred tax asset |  | 884 |  |  | 884 |  |
| Prepaid income taxes |  | — |  |  | 3,256 |  |
| Prepaid expenses and other current assets |  | 21,744 |  |  | 13,267 |  |
| Total current assets |  | 518,266 |  |  | 465,724 |  |
| Property and equipment, net |  | 9,995 |  |  | 7,260 |  |
| Long-term deferred tax asset |  | 1,255 |  |  | 1,255 |  |
| Other long–term assets |  | 1,804 |  |  | 1,912 |  |
| Total assets |  | $ | 531,320 |  |  | $ | 476,151 |  |
| Liabilities and Stockholders’ Equity |  |  |  |  |
| Current liabilities: |  |  |  |  |
| Accounts payable |  | $ | 39,085 |  |  | $ | 33,933 |  |
| Customer deposits |  | 412 |  |  | 1,835 |  |
| Deferred revenues |  | 5,509 |  |  | 4,218 |  |
| Income taxes payable |  | 3,411 |  |  | 2,499 |  |
| Dividend payable |  | 15,000 |  |  | — |  |
| Other current liabilities |  | 18,614 |  |  | 9,830 |  |
| Total current liabilities |  | 82,031 |  |  | 52,315 |  |
| Long-term taxes payable |  | 16,226 |  |  | 15,346 |  |
| Debt - long-term |  | 72,254 |  |  | 72,254 |  |
| Deferred revenues - long-term |  | 992 |  |  | 972 |  |
| Total liabilities |  | 171,503 |  |  | 140,887 |  |
| Stockholders’ equity: |  |  |  |  |
| Common stock |  | 88 |  |  | 88 |  |
| Additional paid–in capital |  | 147,682 |  |  | 145,872 |  |
| Treasury stock |  | (123,864 | ) |  | (123,864 | ) |
| Retained earnings |  | 335,911 |  |  | 313,168 |  |
| Total stockholders’ equity |  | 359,817 |  |  | 335,264 |  |
| Total liabilities and stockholders’ equity |  | $ | 531,320 |  |  | $ | 476,151 |  |

[0001511737-14-000029:8k_2_02:47]
| (1) | Derived from audited consolidated statements as of and for the year ended June 30, 2014. |

[0001511737-14-000029:8k_2_02:48]
| Ubiquiti Networks Inc.Revenue by Product Category (In thousands)(Unaudited) |
|  | Three Months Ended September 30, |
|  | 2014 |  | 2013 |
| Service Provider Technology | $ | 107,271 |  |  | $ | 94,217 |  |
| Enterprise Technology | 42,816 |  |  | 35,470 |  |
| Total revenues | $ | 150,087 |  |  | $ | 129,687 |  |

[0001511737-14-000029:8k_2_02:49]
| Ubiquiti Networks Inc.Revenue by Geographical Area(In thousands)(Unaudited) |
|  |  | Three Months Ended September 30, |
|  |  | 2014 |  | 2013 |
| North America |  | $ | 53,582 |  |  | $ | 37,433 |  |
| South America |  | 31,134 |  |  | 20,776 |  |
| Europe, the Middle East and Africa |  | 50,607 |  |  | 52,866 |  |
| Asia Pacific |  | 14,764 |  |  | 18,612 |  |
| Total revenues |  | $ | 150,087 |  |  | $ | 129,687 |  |

[0001511737-14-000029:8k_2_02:50]
About our Non-GAAP Net Income and Adjustments

[0001511737-14-000029:8k_2_02:51]
Use of Non-GAAP Financial Information

[0001511737-14-000029:8k_2_02:52]
To supplement our condensed consolidated financial results prepared under generally accepted accounting principles, or GAAP, we use non-GAAP measures of net income and earnings per diluted share that are GAAP net income and GAAP earnings per diluted share adjusted to exclude certain costs, expenses and gains.

[0001511737-14-000029:8k_2_02:53]
We believe that the presentation of non-GAAP net income and non-GAAP earnings per diluted share provides important supplemental information regarding non-cash expenses, significant items that we believe are important to understanding our financial, and business trends relating to our financial condition and results of operations.  Non-GAAP net income and non-GAAP earnings per diluted share are among the primary indicators used by management as a basis for planning and forecasting future periods and by management and our board of directors to determine whether our operating performance has met specified targets and thresholds.  Management uses non-GAAP net income and non-GAAP earnings per diluted share when evaluating operating performance because it believes that the exclusion of the items described below, for which the amounts or timing may vary significantly depending upon the Company's activities and other factors, facilitates comparability of the Company's operating performance from period to period.  We have chosen to provide this information to investors so they can analyze our operating results in the same way that management does and use this information in their assessment of our business and the valuation of our Company.

[0001511737-14-000029:8k_2_02:54]
Use and Economic Substance of Non-GAAP Financial Measures used by Ubiquiti Networks

[0001511737-14-000029:8k_2_02:55]
We compute non-GAAP net income and non-GAAP diluted earnings per share by adjusting GAAP net income and GAAP earnings per diluted share to remove the impact of certain adjustments and the tax effect of those adjustments.  Items excluded from net income are:

[0001511737-14-000029:8k_2_02:56]
| • | Stock-based compensation expense |

[0001511737-14-000029:8k_2_02:57]
| • | Reserve against vendor deposits relating to a purchase commitment termination fee |

[0001511737-14-000029:8k_2_02:58]
| • | Tax effect of these non-GAAP adjustments. After adjusting to exclude the items described above, we apply the principles of ASC 740, Income Taxes, to estimate the non-GAAP income tax provision. |

[0001511737-14-000029:8k_2_02:59]
Usefulness of Non-GAAP Financial Information to Investors

[0001511737-14-000029:8k_2_02:60]
These non-GAAP measures are not in accordance with, or an alternative to, GAAP and may be materially different from other non-GAAP measures, including similarly titled non-GAAP measures used by other companies.  The presentation of this additional information should not be considered in isolation from, as a substitute for, or superior to, net income or earnings per diluted share prepared in accordance with GAAP.  Non-GAAP financial measures have limitations in that they do not reflect certain items that may have a material impact upon our reported financial results.  We expect to continue to incur expenses of a nature similar to the non-GAAP adjustments described above, and exclusion of these items from our non-GAAP net income and non-GAAP earnings per diluted share should not be construed as an inference that these costs are unusual, infrequent or non-recurring.

[0001511737-14-000029:8k_2_02:61]
For more information on the non-GAAP adjustments, please see the table captioned “Reconciliation of GAAP Net Income to Non-GAAP Net Income” included in this press release.
