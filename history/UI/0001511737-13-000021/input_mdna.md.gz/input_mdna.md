# UI MD&A — 0001511737-13-000021


## mdna

[0001511737-13-000021:mdna:1]
[same as prior period, unchanged from 0001511737-13-000006:mdna:1]

[0001511737-13-000021:mdna:2]
[same as prior period, unchanged from 0001511737-13-000006:mdna:2]

[0001511737-13-000021:mdna:3]
Ubiquiti Networks develops high performance networking technology for service providers and enterprises. Our technology platforms focus on delivering highly-advanced and easily deployable solutions that appeal to a global customer base in underserved and underpenetrated markets. Our differentiated business model has enabled us to break down traditional barriers such as high product and network deployment costs and offer solutions with disruptive price-performance characteristics. This differentiated business model, combined with our innovative proprietary technologies, has resulted in an attractive alternative to traditional high touch, high-cost providers, allowing us to advance the market adoption of our platforms for ubiquitous connectivity.

[0001511737-13-000021:mdna:4]
We offer a broad and expanding portfolio of networking products and solutions for service providers and enterprises. Our service provider product platforms provide carrier-class network infrastructure for fixed wireless broadband, wireless backhaul systems and routing. Our enterprise product platforms provide wireless LAN infrastructure, video surveillance products, and machine-to-machine communication components. We believe that our products are highly differentiated due to our proprietary software protocol innovation, firmware expertise, and hardware design capabilities. This differentiation allows our portfolio to meet the demanding performance requirements of video, voice and data applications at prices that are a fraction of those offered by our competitors.

[0001511737-13-000021:mdna:5]
As a core part of our strategy, we have developed a differentiated business model for marketing and selling high volumes of carrier and enterprise-class communications platforms. Our business model is driven by a large, growing and highly engaged community of service providers, distributors, value added resellers, systems integrators and corporate IT professionals, which we refer to as the Ubiquiti Community. The Ubiquiti Community is a critical element of our business strategy as it enables us to drive:

[0001511737-13-000021:mdna:6]
16

[0001511737-13-000021:mdna:7]
| • | Rapid customer and community driven product development. We have an active, loyal community built from our customers that we believe is a sustainable competitive advantage. Our solutions benefit from the active engagement between the Ubiquiti Community and our development engineers throughout the product development cycle, which eliminates long and expensive multistep internal processes and results in rapid introduction and adoption of our products. This approach significantly reduces our development costs and time to market. |

[0001511737-13-000021:mdna:8]
| • | Scalable sales and marketing model. We do not currently have, nor do we plan to hire, a direct sales force, but instead utilize the Ubiquiti Community to drive market awareness and demand for our products and solutions. This community-propagated viral marketing enables us to reach underserved and underpenetrated markets far more efficiently and cost-effectively than is possible through traditional sales models. Leveraging the information transparency of the Internet allows customers to research, evaluate and validate our solutions with the Ubiquiti Community and via third party web sites. This allows us to operate a scalable sales and marketing model and effectively create awareness of our brand and products. Word of mouth referrals from the Ubiquiti Community generate high quality leads for our distributors at relatively little cost. |

[0001511737-13-000021:mdna:9]
| • | Self-sustaining product support. The engaged members of the Ubiquiti Community have enabled us to foster a large, cost efficient, highly-scalable and, we believe, self-sustaining mechanism for rapid product support and dissemination of information. |

[0001511737-13-000021:mdna:10]
By reducing the cost of development, sales, marketing and support we are able to eliminate traditional business model inefficiencies and offer innovative solutions with disruptive price performance characteristics to our customers.

[0001511737-13-000021:mdna:11]
Our revenues increased 111% to $129.7 million in the three months ended September 30, 2013 from $61.5 million in the three months ended September 30, 2012.  We believe the overall increase in revenues during the three months ended September 30, 2013 was driven by increased adoption of our service provider and enterprise technologies.  Additionally, during three months ended September 30, 2012, we believe we experienced lost sales due to the proliferation of counterfeit versions of our products, which also created customer uncertainty regarding the authenticity of their potential purchases.  We believe these factors contributed to a buildup in channel inventory with our distributors, further impacting our revenues.  We had net income of $40.5 million and $13.2 million in the three months ended September 30, 2013 and 2012, respectively.  The increase in net income in the three months ended September 30, 2013 as compared to the same period in the prior year was primarily due to the increase in revenues.

[0001511737-13-000021:mdna:12]
[same as prior period, unchanged from 0001511737-13-000006:mdna:11]

[0001511737-13-000021:mdna:13]
[same as prior period, unchanged from 0001511737-13-000006:mdna:12]

[0001511737-13-000021:mdna:14]
[same as prior period, unchanged from 0001511737-13-000006:mdna:13]

[0001511737-13-000021:mdna:15]
We classify our revenues into two primary product categories, Service Provider Technology and Enterprise Technology.

[0001511737-13-000021:mdna:16]
| • | Service Provider Technology includes our airMAX, EdgeMAX and airFiber platforms, as well as embedded radio products and other 802.11 standard products including base stations, radios, backhaul equipment and Customer Premise Equipment (“CPE”). Additionally, Service Provider Technology includes antennas and other products in the 2.0 to 6.0GHz spectrum and miscellaneous products such as mounting brackets, cables and power over Ethernet adapters. Service Provider Technology also includes revenues that are attributable to post contract support ("PCS"). |

[0001511737-13-000021:mdna:17]
| • | Enterprise Technology includes the Company's UniFi, mFi and airVision platforms. |

[0001511737-13-000021:mdna:18]
We sell substantially all of our products through a limited number of distributors and other channel partners, such as resellers and OEMs. Sales to distributors accounted for 98% and 97% of our revenues in the three months ended September 30, 2013 and 2012, respectively.  Other channel partners, such as resellers and OEMs, largely accounted for the balance of our revenues. We sell our products without any right of return.

[0001511737-13-000021:mdna:19]
[same as prior period, unchanged from 0001511737-13-000006:mdna:22]

[0001511737-13-000021:mdna:20]
Our cost of revenues is comprised primarily of the costs of procuring finished goods from our contract manufacturers and chipsets that we consign to certain of our contract manufacturers. In addition, cost of revenues includes tooling, labor and other

[0001511737-13-000021:mdna:21]
17

[0001511737-13-000021:mdna:22]
costs associated with engineering, testing and quality assurance, warranty costs, stock-based compensation, logistics related fees and excess and obsolete inventory.

[0001511737-13-000021:mdna:23]
In addition to utilizing contract manufacturers, we outsource our logistics warehousing and order fulfillment functions, which are located primarily in China, and to a lesser extent, Taiwan. We also evaluate and utilize other vendors for various portions of our supply chain from time to time. Our operations organization consists of employees and consultants engaged in the management of our contract manufacturers, new product introduction activities, logistical support and engineering.

[0001511737-13-000021:mdna:24]
[same as prior period, unchanged from 0001511737-13-000006:mdna:25]

[0001511737-13-000021:mdna:25]
[same as prior period, unchanged from 0001511737-13-000006:mdna:26]

[0001511737-13-000021:mdna:26]
[same as prior period, unchanged from 0001511737-13-000006:mdna:27]

[0001511737-13-000021:mdna:27]
[same as prior period, unchanged from 0001511737-13-000006:mdna:28]

[0001511737-13-000021:mdna:28]
[same as prior period, unchanged from 0001511737-13-000006:mdna:29]

[0001511737-13-000021:mdna:29]
| • | Sales, general and administrative expenses include salary and benefit expenses, including stock-based compensation, for employees and costs for contractors engaged in sales, marketing and general and administrative activities, as well as the costs of legal expenses, trade shows, marketing programs, promotional materials, bad debt expense, professional services, facilities, general liability insurance and travel. As our product portfolio and targeted markets expand, we may need to employ different sales models, such as building a direct sales force. These sales models would likely increase our costs. Over time, we expect our sales, general and administrative expenses to increase in absolute dollars due to continued growth in headcount, expansion of our efforts to register and defend trademarks and patents and to support our business and operations. |

[0001511737-13-000021:mdna:30]
[same as prior period, unchanged from 0001511737-13-000006:mdna:33]

[0001511737-13-000021:mdna:31]
In the event that collectability of a receivable from products we have shipped is not probable, we classify those amounts as deferred revenues on our balance sheet until such time as we receive payment of the accounts receivable. We classify the cost of products associated with these deferred revenues as deferred costs of revenues.  At both September 30, 2013 and June 30, 2013, $2.2 million of revenue was deferred for transactions where we lacked evidence that collectability of the receivables recorded was reasonably assured.  The related deferred cost of revenues balance was $1.2 million at both September 30, 2013 and June 30, 2013.

[0001511737-13-000021:mdna:32]
Also included in our deferred revenues is a portion related to PCS obligations that we estimate we will perform in the future. As of September 30, 2013 and June 30, 2013, we had deferred revenues of $1.1 million and $1.0 million respectively, related to these obligations.

[0001511737-13-000021:mdna:33]
[same as prior period, unchanged from 0001511737-13-000006:mdna:36]

[0001511737-13-000021:mdna:34]
We prepare our condensed consolidated financial statements in accordance with accounting principles generally accepted in the United States of America (“GAAP”). In many cases, the accounting treatment of a particular transaction is specifically dictated by GAAP and does not require management’s judgment in its application. In other cases, management’s judgment is required in selecting among available alternative accounting standards that provide for different accounting treatment for similar transactions. The preparation of condensed consolidated financial statements also requires us to make estimates and assumptions that affect the amounts we report as assets, liabilities, revenues, costs and expenses and affect the related disclosures. We base our estimates on historical experience and other assumptions that we believe are reasonable under the circumstances. In many instances, we could reasonably use different accounting estimates, and in some instances changes in the accounting estimates are reasonably likely to occur from period to period. Accordingly, our actual results could differ

[0001511737-13-000021:mdna:35]
significantly from the estimates made by our management. To the extent that there are differences between our estimates and actual results, our future financial statement presentation, financial condition, results of operations and cash flows will be affected. Our critical accounting policies are discussed in our Annual Report on Form 10-K for the fiscal year ended June 30, 2013, as filed on September 13, 2013 with the SEC, or the Annual Report, and there have been no material changes.

[0001511737-13-000021:mdna:36]
[same as prior period, unchanged from 0001511737-13-000006:mdna:38]

[0001511737-13-000021:mdna:37]
Comparison of Three Months Ended September 30, 2013 and 2012

[0001511737-13-000021:mdna:38]
|  | Three Months Ended September 30, |
|  | 2013 |  | 2012 |
|  | (In thousands, except percentages) |
| Revenues | $ | 129,687 |  |  | 100 | % |  | $ | 61,535 |  |  | 100 | % |
| Cost of revenues | 71,664 |  |  | 55 | % |  | 36,515 |  |  | 59 | % |
| Gross profit | 58,023 |  |  | 45 | % |  | 25,020 |  |  | 41 | % |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 6,317 |  |  | 5 | % |  | 4,711 |  |  | 8 | % |
| Sales, general and administrative | 5,810 |  |  | 4 | % |  | 4,534 |  |  | 7 | % |
| Total operating expenses | 12,127 |  |  | 9 | % |  | 9,245 |  |  | 15 | % |
| Income from operations | 45,896 |  |  | 36 | % |  | 15,775 |  |  | 26 | % |
| Interest expense and other, net | (246 | ) |  | * |  |  | (86 | ) |  | * |  |
| Income before provision for income taxes | 45,650 |  |  | 35 | % |  | 15,689 |  |  | 25 | % |
| Provision for income taxes | 5,122 |  |  | 4 | % |  | 2,510 |  |  | 4 | % |
| Net income and comprehensive income | $ | 40,528 |  |  | 31 | % |  | $ | 13,179 |  |  | 21 | % |
| * Less than 1% |  |  |  |  |  |  |  |
| (1) Includes stock-based compensation as follows: |  |  |  |  |  |  |  |
| Cost of revenues | $ | 144 |  |  |  |  | $ | 81 |  |  |  |
| Research and development | 496 |  |  |  |  | 266 |  |  |  |
| Sales, general and administrative | 527 |  |  |  |  | 309 |  |  |  |
| Total stock-based compensation | $ | 1,167 |  |  |  |  | $ | 656 |  |  |  |

[0001511737-13-000021:mdna:39]
[same as prior period, unchanged from 0001511737-13-000006:mdna:41]

[0001511737-13-000021:mdna:40]
Revenues increased $68.2 million, or 111%, from $61.5 million in the three months ended September 30, 2012 to $129.7 million in the three months ended September 30, 2013.  We believe the overall increase in revenues during the three months ended September 30, 2013 was driven by increased adoption of our service provider and enterprise technologies.  Additionally, during three months ended September 30, 2012, we believe we experienced lost sales due to the proliferation of counterfeit versions of our products, which also created customer uncertainty regarding the authenticity of their potential purchases.  We believe these factors contributed to a buildup in channel inventory with our distributors, further impacting our revenues.

[0001511737-13-000021:mdna:41]
In the three months ended September 30, 2013, revenues from Customer A and Customer B each represented 10% of our revenues.  In the three months ended September 30, 2012, revenues from Customer B represented 15% of our revenues.

[0001511737-13-000021:mdna:42]
[same as prior period, unchanged from 0001511737-13-000006:mdna:45]

[0001511737-13-000021:mdna:43]
|  | Three Months Ended September 30, |
|  | 2013 |  | 2012 |
|  | (in thousands, except percentages) |
| Service Provider Technology | $ | 94,217 |  |  | 73 | % |  | $ | 51,617 |  |  | 84 | % |
| Enterprise Technology | 35,470 |  |  | 27 | % |  | 9,918 |  |  | 16 | % |
| Total revenues | $ | 129,687 |  |  | 100 | % |  | $ | 61,535 |  |  | 100 | % |

[0001511737-13-000021:mdna:44]
Revenues from Service Provider Technologies increased $42.6 million, or 83%, from $51.6 million in the three months ended September 30, 2012 to $94.2 million in the three months ended September 30, 2013.  The increase was due primarily to

[0001511737-13-000021:mdna:45]
continued expansion of core infrastructure build-outs in our wireless markets.  Additionally, we believe we experienced significant lost sales during the three months ended September 30, 2012 due to the proliferation of counterfeit versions of our products as discussed above.

[0001511737-13-000021:mdna:46]
Enterprise Technology revenues increased $25.6 million, or 258% from $9.9 million in the three months ended September 30, 2012 to $35.5 million in the three months ended September 30, 2013.  The increase in Enterprise Technology revenues during the three months ended September 30, 2013 was due primarily to product expansion and further adoption of our UniFi technology platform.

[0001511737-13-000021:mdna:47]
[same as prior period, unchanged from 0001511737-13-000006:mdna:51]

[0001511737-13-000021:mdna:48]
We generally forward products directly from our manufacturers to our customers via logistics distribution hubs in Asia.  Beginning in the quarter ended December 31, 2012, our products were predominantly routed through a third party logistics provider in China and prior to the quarter ended December 31, 2012, our products were predominantly delivered to our customers through distribution hubs in Hong Kong.  Our logistics provider, in turn, ships to other locations throughout the world. We have determined the geographical distribution of our product revenues based on our customers' ship-to destinations. A majority of our sales are to distributors who in turn sell to resellers or directly to end customers.  For the three months ended September 30, 2013, revenues in all regions increased due to increased adoption of our Service Provider and Enterprise Technologies.  Additionally, during the three months ended September 30, 2012, we believe we experienced lost sales due to the proliferation of counterfeit versions of our products, which also created customer uncertainty regarding the authenticity of their potential purchases.  The following are our revenues by geography for the three months ended September 30, 2013 and 2012 (in thousands, except percentages):

[0001511737-13-000021:mdna:49]
|  | Three Months Ended September 30, |
|  | 2013 |  | 2012 |
| North America(1) | $ | 37,433 |  |  | 29 | % |  | $ | 20,361 |  |  | 33 | % |
| South America | 20,776 |  |  | 16 | % |  | 10,243 |  |  | 17 | % |
| Europe, the Middle East and Africa | 52,866 |  |  | 41 | % |  | 23,144 |  |  | 37 | % |
| Asia Pacific | 18,612 |  |  | 14 | % |  | 7,787 |  |  | 13 | % |
| Total revenues | $ | 129,687 |  |  | 100 | % |  | $ | 61,535 |  |  | 100 | % |

[0001511737-13-000021:mdna:50]
| (1) | Revenue for the United States was $36.3 million and $19.3 million for the three months ended September 30, 2013 and 2012, respectively. |

[0001511737-13-000021:mdna:51]
[same as prior period, unchanged from 0001511737-13-000006:mdna:55]

[0001511737-13-000021:mdna:52]
Cost of revenues increased $35.1 million, or 96%, from $36.5 million in the three months ended September 30, 2012 to $71.7 million in the three months ended September 30, 2013.  The increase in cost of revenues in the three months ended September 30, 2013 was primarily due to increased revenues and to a lesser extent, changes in product mix.

[0001511737-13-000021:mdna:53]
Gross profit increased to 45% in the three months ended September 30, 2013 compared to 41% in the three months ended September 30, 2012, reflecting a high level of revenue growth, increasing economies of scale and changes in product mix.

[0001511737-13-000021:mdna:54]
[same as prior period, unchanged from 0001511737-13-000006:mdna:58]

[0001511737-13-000021:mdna:55]
[same as prior period, unchanged from 0001511737-13-000006:mdna:59]

[0001511737-13-000021:mdna:56]
Research and development expenses increased $1.6 million, or 34%, from $4.7 million in the three months ended September 30, 2012 to $6.3 million in the three months ended September 30, 2013. As a percentage of revenues, research and development expenses decreased from 8% in the three months ended September 30, 2012 to 5% in the three months ended September 30, 2013.  The increase in research and development expenses in absolute dollars was due to increases in headcount as we broadened our research and development activities to new product areas.  As a percentage of revenues, research and development expenses decreased primarily due to our overall increase in revenues. Over time, we expect our research and development costs to increase in absolute dollars as we continue making significant investments in developing new products and developing new versions of our existing products.

[0001511737-13-000021:mdna:57]
[same as prior period, unchanged from 0001511737-13-000006:mdna:62]

[0001511737-13-000021:mdna:58]
Sales, general and administrative expenses increased $1.3 million, or 28%, from $4.5 million in the three months ended September 30, 2012 to $5.8 million in the three months ended September 30, 2013.  As a percentage of revenues, sales, general

[0001511737-13-000021:mdna:59]
and administrative expenses decreased from 7% in the three months ended September 30, 2012 to 4% in the three months ended September 30, 2013.  Sales, general and administrative expenses increased due to increased professional fees, primarily related to the ancillary support of certain management functions, increased marketing activity and overall increases in headcount to further expand our marketing and administrative functions. As a percentage of revenues, sales, general and administrative expenses decreased primarily due to our overall revenue increase. Over time, we expect our sales, general and administrative expenses to increase in absolute dollars due to continued efforts to protect our intellectual property and growth in headcount to support our business and operations.

[0001511737-13-000021:mdna:60]
[same as prior period, unchanged from 0001511737-13-000006:mdna:64]

[0001511737-13-000021:mdna:61]
Interest expense and other, net was $246,000 for the three months ended September 30, 2013, representing an increase of $160,000 from $86,000 for the three months ended September 30, 2012.  The increase in interest expense and other, net during the three months ended September 30, 2013 compared to the same period in the prior year was primarily due to additional interest expense resulting from our increased borrowings from East West Bank during the three months ended September 30, 2012.

[0001511737-13-000021:mdna:62]
[same as prior period, unchanged from 0001511737-13-000006:mdna:66]

[0001511737-13-000021:mdna:63]
Our provision for income taxes increased $2.6 million, or 104%, from $2.5 million for the three months ended September 30, 2012 to $5.1 million for the three months ended September 30, 2013. Our effective tax rate decreased to 11% for the three months ended September 30, 2013 as compared to 16% the three months ended September 30, 2012.   The lower effective tax rate was primarily due to a larger percentage of our overall profitability occurring in foreign jurisdictions with lower income tax rates.

[0001511737-13-000021:mdna:64]
[same as prior period, unchanged from 0001511737-13-000006:mdna:68]

[0001511737-13-000021:mdna:65]
[same as prior period, unchanged from 0001511737-13-000006:mdna:69]

[0001511737-13-000021:mdna:66]
Since inception, our operations primarily have been funded through cash generated by operations. Cash and cash equivalents increased from $227.8 million at June 30, 2013 to $279.7 million at September 30, 2013.

[0001511737-13-000021:mdna:67]
[same as prior period, unchanged from 0001511737-13-000006:mdna:71]

[0001511737-13-000021:mdna:68]
[same as prior period, unchanged from 0001511737-13-000006:mdna:72]

[0001511737-13-000021:mdna:69]
|  | Three Months Ended September 30, |
|  | 2013 |  | 2012 |
|  | (In thousands) |
| Net cash provided by operating activities | $ | 51,880 |  |  | $ | 23,695 |  |
| Net cash used in investing activities | (460 | ) |  | (2,349 | ) |
| Net cash provided by (used in) financing activities | 483 |  |  | (10,920 | ) |
| Net increase in cash and cash equivalents | $ | 51,903 |  |  | $ | 10,426 |  |

[0001511737-13-000021:mdna:70]
[same as prior period, unchanged from 0001511737-13-000006:mdna:74]

[0001511737-13-000021:mdna:71]
Net cash provided by operating activities in the three months ended September 30, 2013 of $51.9 million consisted primarily of net income of $40.5 million and net changes in operating assets and liabilities that resulted in net cash inflows of $10.4 million. These changes consisted primarily of an $8.3 million increase in accounts payable and accrued liabilities due primarily to our increase in cost of revenues, a $2.0 million increase in taxes payable due to the timing of federal tax payments, a $1.0 million increase in inventory due to increased product demand and a $897,000 decrease in prepaid expenses and other current assets due to timing of our payments with our suppliers.  Additionally, our net income included non-cash adjustments due to stock-based compensation, depreciation and amortization, increases to our provision for inventory obsolescence, a write-off of our intangible assets and an excess tax benefit from stock-based awards. The net of these non-cash adjustments resulted in an increase of our net cash provided by operating activities of $1.0 million.

[0001511737-13-000021:mdna:72]
Net cash provided by operating activities in the three months ended September 30, 2012 of $23.7 million consisted primarily of net income of $13.2 million and by net increases in operating assets and liabilities of $9.0 million. These changes consisted primarily of a $14.3 million decrease in accounts receivable due to decreased revenues, a $6.4 million decrease in accounts payable and accrued liabilities due to decreased overall business activity, a $2.3 million increase in taxes payable due to the

[0001511737-13-000021:mdna:73]
[same as prior period, unchanged from 0001511737-13-000006:mdna:50]

[0001511737-13-000021:mdna:74]
timing of federal tax payments and a $1.3 million increase in prepaid expenses and other current assets due primarily to increased deposits with our vendors. Additionally, our net income included non-cash adjustments due to stock-based compensation, depreciation and amortization, adjustments to our provisions for doubtful accounts and inventory obsolescence and an excess tax benefit from stock-based awards. The net of these non-cash adjustments resulted in an increase of our net cash provided by operating activities of $1.5 million.

[0001511737-13-000021:mdna:75]
[same as prior period, unchanged from 0001511737-13-000006:mdna:77]

[0001511737-13-000021:mdna:76]
Our investing activities consist solely of capital expenditures and purchases of intangible assets. Capital expenditures for the three months ended September 30, 2013 and 2012 were $402,000 and $1.6 million, respectively. Additionally, we had cash outflows related to the purchase of intangible assets of $58,000 and $748,000 during the three months ended September 30, 2013 and 2012, respectively.

[0001511737-13-000021:mdna:77]
[same as prior period, unchanged from 0001511737-13-000006:mdna:79]

[0001511737-13-000021:mdna:78]
On August 7, 2012, we entered into a Loan and Security Agreement (the “Loan Agreement”) with U.S. Bank, as syndication agent, and East West Bank, as administrative agent for the lenders party to the Loan Agreement. The Loan Agreement replaced the EWB Loan Agreement discussed below. The Loan Agreement provides for (i) a $50.0 million revolving credit facility, with a $5.0 million sublimit for the issuance of letters of credit and a $5.0 million sublimit for the making of swingline loan advances (the “Revolving Credit Facility”), and (ii) a $50.0 million term loan facility (the “Term Loan Facility”). We may request borrowings under the Revolving Credit Facility until August 7, 2015. The Loan Agreement replaced a previous agreement whereby we had an existing term loan balance of $29.2 million as of the date of the new Loan Agreement.  On August 7, 2012, we borrowed $20.8 million of term loans under the Term Loan Facility, and no borrowings remain available thereunder.

[0001511737-13-000021:mdna:79]
On August 9, 2012, we announced that our Board of Directors authorized us to repurchase up to $100.0 million of our common stock. The share repurchase program commenced August 13, 2012 and expired on August 12, 2013. During the three months ended September 30, 2012, we repurchased 3,171,914 shares for a total cost of $31.3 million.  Additionally, we repurchased 1,987,136 shares for a total cost of $23.1 million from October 1, 2012 through December 31, 2012.  No shares were repurchased after December 31, 2012.

[0001511737-13-000021:mdna:80]
[same as prior period, unchanged from 0001511737-13-000006:mdna:94]

[0001511737-13-000021:mdna:81]
We believe our existing cash and cash equivalents, cash provided by operations and the availability of additional funds under our loan agreements will be sufficient to meet our working capital and capital expenditure needs for at least the next 12 months. Our future capital requirements may vary materially from those currently planned and will depend on many factors, including our rate of revenue growth, the timing and extent of spending to support development efforts, the timing of new product introductions, market acceptance of our products and overall economic conditions. As of September 30, 2013, we held $253.8 million of our $279.7 million of cash and cash equivalents in accounts of our subsidiaries outside of the United States and we will incur significant tax liabilities if we decide to repatriate those amounts.

[0001511737-13-000021:mdna:82]
Commitments and Contingencies

[0001511737-13-000021:mdna:83]
In January 2011, the U.S. Department of Commerce’s Bureau of Industry and Security’s Office of Export Enforcement (“OEE”) contacted us to request that we provide information related to our relationship with a logistics company in the United Arab Emirates (“UAE”) and with a company in Iran, as well as information on the export classification of our products. As a result of this inquiry we, assisted by outside counsel, conducted a review of our export transactions from 2008 through March 2011 to not only gather information responsive to the OEE’s request but also to review our overall compliance with export control and sanctions laws. We believe our products have been sold into Iran by third parties. We do not believe that we directly sold, exported or shipped our products into Iran or any other country subject to a U.S. embargo. However, until early 2010, we did not prohibit our distributors from selling our products into Iran or any other country subject to a U.S. embargo. In the course of this review we identified that two distributors may have sold Ubiquiti products into Iran. Our review also found that while we had obtained required Commodity Classification Rulings for our products in June 2010 and November 2010, we did not advise our shipping personnel to change the export authorizations used on our shipping documents until February 2011. During the course of our export control review, we also determined that we had failed to maintain adequate records for the five year period required by the EAR and the sanctions regulations due to our lack of infrastructure and because it was prior to our transition to our current system of record, NetSuite. See “Risk Factors—We are subject to numerous U.S. export control and economic sanctions laws and a substantial majority of our sales are into countries outside of the United States. Although we did not intend to do so, we have violated certain of these laws in the past, and we cannot currently assess the nature and extent of any fines or other penalties, if any, that U.S. governmental agencies may impose against us or our employees for any such

[0001511737-13-000021:mdna:84]
violations. Any fines, if materially different from our estimates, or other penalties, could have a material adverse effect on our business and financial results.”

[0001511737-13-000021:mdna:85]
In May 2011, we filed a self-disclosure statement with the BIS and the OEE and, in June 2011, we filed a self-disclosure  statement with the U.S. Department of the Treasury’s Office of Foreign Asset Control (“OFAC”), regarding the compliance issues noted above. The disclosures address the above described findings and the remedial actions we have taken to date. However, the findings also indicate that both distributors continued to sell, directly or indirectly, our products into Iran during the period from February 2010 through March 2011 and that we received various communications from them indicating that they were continuing to do so. Since January 2011, we have cooperated with OEE and, prior to our disclosure filing, we informally shared with the OEE the substance of our findings with respect to both distributors. From May 2011 to August 2011, we provided additional information regarding our review and our findings to OEE to facilitate its investigation and OEE advised us in August 2011 that it had completed its investigation of us. In August 2011, we received a warning letter from OEE stating that OEE had not referred the findings of our review for criminal or administrative prosecution of us and closed the investigation of us without penalty.

[0001511737-13-000021:mdna:86]
OFAC is still reviewing our voluntary disclosure. In our submission, we have provided OFAC with an explanation of the activities that led to the sales of our products in Iran and the failure to comply with the EAR and OFAC sanctions. Although our OFAC and OEE voluntary disclosures covered similar sets of facts, which led OEE to resolve the case with the issuance of a warning letter, OFAC may conclude that our actions resulted in violations of U.S. export control and economic sanctions laws and warrant the imposition of penalties that could include fines, termination of our ability to export our products and/or referral for criminal prosecution. The penalties may be imposed against us and/or our management. The maximum civil monetary penalty for the violations is up to $250,000 or twice the value of the transaction, whichever is greater, per violation. Any such fines or restrictions may be material to our financial results in the period in which they are imposed.  Also, disclosure of our conduct and any fines or other action relating to this conduct could harm our reputation and have a material adverse effect on our business. We cannot predict when OFAC will complete its review or decide upon the imposition of possible penalties.

[0001511737-13-000021:mdna:87]
While we have taken actions designed to ensure that export classification information is distributed to the appropriate personnel in a timely manner and have adopted policies and procedures to promote our compliance with applicable export laws and regulations, including obtaining written distribution agreements with substantially all of our distributors that contain covenants requiring compliance with U.S. export control and economic sanctions law; notifying all of our distributors of their obligations and obtaining updated distribution agreements from distributors that account for approximately 99% of our distributor revenue in fiscal 2013.  However we cannot be sure such actions will be effective.  Additionally, our failure to amend all our distribution agreements and to implement more robust compliance controls immediately after the discovery of Iran-related sales activity in early 2010 may be aggravating factors that could impact the imposition of penalties imposed on us or our management.  Based on the facts known to us to date, we recorded an expense of $1.6 million for this export compliance matter in fiscal 2010, which represents management’s estimated exposure for fines in accordance with applicable accounting literature.  This amount was calculated from information discovered through our internal review and we deem this loss to be probable and reasonably estimable. However, we believe that it is reasonably possible that the loss may be higher, but we cannot reasonably estimate the range of any further potential losses. Should additional facts be discovered in the future and/or should actual fines or other penalties substantially differ from our estimates, our business, financial condition, cash flows and results of operations may be materially negatively impacted.

[0001511737-13-000021:mdna:88]
[same as prior period, unchanged from 0001511737-13-000006:mdna:103]

[0001511737-13-000021:mdna:89]
Our products are generally accompanied by a 12 month warranty, which covers both parts and labor. Generally the distributor is responsible for the freight costs associated with warranty returns, and we absorb the freight costs of replacing items under warranty. In accordance with the Financial Accounting Standards Board’s (“FASB’s”), Accounting Standards Codification (“ASC”), 450-30, Loss Contingencies, we record an accrual when we believe it is estimable and probable based upon historical experience. We record a provision for estimated future warranty work in cost of goods sold upon recognition of revenues and we review the resulting accrual regularly and periodically adjust it to reflect changes in warranty estimates.

[0001511737-13-000021:mdna:90]
[same as prior period, unchanged from 0001511737-13-000006:mdna:105]

[0001511737-13-000021:mdna:91]
We have agreed to indemnify our directors, officers and certain other employees for certain events or occurrences, subject to certain limits, while such persons are or were serving at our request in such capacity. We may terminate the indemnification

[0001511737-13-000021:mdna:92]
agreements with these persons upon the termination of their services with us but termination will not affect claims for indemnification related to events occurring prior to the effective date of termination. The maximum amount of potential future indemnification is unlimited. We have a director and officer insurance policy that limits our potential exposure. We believe the fair value of these indemnification agreements is minimal. We had not recorded any liabilities for these agreements as of September 30, 2013 or June 30, 2013.

[0001511737-13-000021:mdna:93]
Based upon our historical experience and information known as of the date of this report, we do not believe it is likely that we will have significant liability for the above indemnities at September 30, 2013.

[0001511737-13-000021:mdna:94]
[same as prior period, unchanged from 0001511737-13-000006:mdna:108]

[0001511737-13-000021:mdna:95]
[same as prior period, unchanged from 0001511737-13-000006:mdna:109]

[0001511737-13-000021:mdna:96]
On August 7, 2012, we entered into the Loan Agreement with U.S. Bank, as syndication agent, and East West Bank, as administrative agent for the lenders party to the Loan Agreement.  The Loan Agreement provides for (i) a $50.0 million revolving credit facility, with a $5.0 million sublimit for the issuance of letters of credit and a $5.0 million sublimit for the making of swingline loan advances, and (ii) a $50.0 million Term Loan Facility. We may request borrowings under the Revolving Credit Facility until August 7, 2015. The Loan Agreement replaced a previous agreement whereby we had an existing term loan balance of $29.2 million as of the date of the new Loan Agreement.  On August 7, 2012, we borrowed $20.8 million of term loans under the Term Loan Facility bringing the total borrowed to $50.0 million, and no borrowings remain available thereunder.  On November 21, 2012, we borrowed $10.0 million under the Revolving Credit Facility.  On December 20, 2012 we borrowed an additional $20.0 million under the Revolving Credit Facility, and $20.0 million remains available for borrowing thereunder.

[0001511737-13-000021:mdna:97]
The following table summarizes our contractual obligations as of September 30, 2013:

[0001511737-13-000021:mdna:98]
|  | 2014(remainder) |  | 2015 |  | 2016 |  | 2017 |  | 2018 |  | Thereafter |  | Total |
| Operating leases | $ | 1,552 |  |  | $ | 2,061 |  |  | $ | 2,003 |  |  | $ | 1,302 |  |  | $ | 183 |  |  | $ | 53 |  |  | $ | 7,154 |  |
| Debt payment obligations | 3,750 |  |  | 6,875 |  |  | 39,375 |  |  | 10,000 |  |  | 15,000 |  |  | — |  |  | 75,000 |  |
| Interest payments on debt payment obligations | 1,383 |  |  | 1,723 |  |  | 1,043 |  |  | 532 |  |  | 125 |  |  | — |  |  | 4,806 |  |
| Total | $ | 6,685 |  |  | $ | 10,659 |  |  | $ | 42,421 |  |  | $ | 11,834 |  |  | $ | 15,308 |  |  | $ | 53 |  |  | $ | 86,960 |  |

[0001511737-13-000021:mdna:99]
[same as prior period, unchanged from 0001511737-13-000006:mdna:115]

[0001511737-13-000021:mdna:100]
As of September 30, 2013, we had $12.3 million of unrecognized tax benefits, substantially all of which would, if recognized, affect our tax expense. We have elected to include interest and penalties related to uncertain tax positions as a component of tax expense. We do not expect any significant increases or decreases to our unrecognized tax benefits in the next twelve months.

[0001511737-13-000021:mdna:101]
[same as prior period, unchanged from 0001511737-13-000006:mdna:117]

[0001511737-13-000021:mdna:102]
In July 2013, the FASB issued a new accounting standard update on the financial statement presentation of unrecognized tax benefits.  The new guidance provides that a liability related to an unrecognized tax benefit would be presented as a reduction of a deferred tax asset for a new operating loss carryforward, a similar tax loss or a tax credit carryforward if such settlement is required or expected in the event the uncertain tax position is disallowed.  The new guidance will become effective for the Company on July 1, 2014 and it should be applied prospectively to unrecognized tax benefits that exist as of the effective date with retrospective application permitted.  The Company is currently assessing the impact of this new guidance.

[0001511737-13-000021:mdna:103]
[same as prior period, unchanged from 0001511737-13-000006:mdna:119]

[0001511737-13-000021:mdna:104]
Regulation G, conditions for use of Non-Generally Accepted Accounting Principles (“Non-GAAP”) financial measures, and other SEC regulations define and prescribe the conditions for use of certain Non-GAAP financial information. To supplement our condensed consolidated financial results presented in accordance with GAAP, we use Non-GAAP financial measures which are adjusted from the most directly comparable GAAP financial measures to exclude certain items, as described below.

[0001511737-13-000021:mdna:105]
Management believes that these Non-GAAP financial measures reflect an additional and useful way of viewing aspects of our operations that, when viewed in conjunction with our GAAP results, provide a more comprehensive understanding of the various factors and trends affecting our business and operations. Non-GAAP financial measures used by us include net income or loss and diluted net income or loss per share.

[0001511737-13-000021:mdna:106]
[same as prior period, unchanged from 0001511737-13-000006:mdna:121]

[0001511737-13-000021:mdna:107]
[same as prior period, unchanged from 0001511737-13-000006:mdna:122]

[0001511737-13-000021:mdna:108]
[same as prior period, unchanged from 0001511737-13-000006:mdna:124]

[0001511737-13-000021:mdna:109]
|  | Three Months Ended September 30, |
|  | 2013 |  | 2012 |
|  | (In thousands, except per share amounts) |
| Non-GAAP net income and comprehensive income | $ | 41,228 |  |  | $ | 13,572 |  |
| Non-GAAP diluted net income per share of common stock | $ | 0.46 |  |  | $ | 0.15 |  |

[0001511737-13-000021:mdna:110]
[same as prior period, unchanged from 0001511737-13-000006:mdna:126]

[0001511737-13-000021:mdna:111]
The following table shows a reconciliation of GAAP net income and comprehensive income to non-GAAP net income and comprehensive income:

[0001511737-13-000021:mdna:112]
|  | Three Months Ended September 30, |
|  | 2013 |  | 2012 |
|  | (In thousands, except pershare amounts) |
| Net income and comprehensive income | $ | 40,528 |  |  | $ | 13,179 |  |
| Stock-based compensation: |  |  |  |
| Cost of revenues | 144 |  |  | 81 |  |
| Research and development | 496 |  |  | 266 |  |
| Sales, general and administrative | 527 |  |  | 309 |  |
| Tax effect of non-GAAP adjustments | (467 | ) |  | (263 | ) |
| Non-GAAP net income and comprehensive income | $ | 41,228 |  |  | $ | 13,572 |  |
| Non-GAAP diluted net income per share of common stock | $ | 0.46 |  |  | $ | 0.15 |  |
| Weighted-average shares used in computing non-GAAP diluted net income per share of common stock | 89,473 |  |  | 92,925 |  |
