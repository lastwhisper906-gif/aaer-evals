# UI 8-K — 0001511737-13-000018 filed 2013-11-07

## item codes, every 8-K on or before 2013-11-08

- 2013-11-07 0001511737-13-000018 — 2.02, 9.01
- 2013-10-28 0001193125-13-413414 — 5.02, 9.01
- 2013-10-18 0001193125-13-404111 — 5.02, 9.01
- 2013-08-08 0001511737-13-000009 — 2.02, 9.01
- 2013-05-09 0001511737-13-000004 — 2.02
- 2013-03-25 0001193125-13-124353 — 5.07
- 2013-03-08 0001193125-13-098334 — 5.02, 9.01
- 2013-02-07 0001193125-13-043701 — 2.02, 9.01
- 2012-12-28 0001193125-12-518487 — 1.01
- 2012-12-17 0001193125-12-503742 — 7.01, 9.01
- 2012-12-13 0001193125-12-501894 — 5.02
- 2012-11-16 0001193125-12-474083 — 5.02
- 2012-11-13 0001193125-12-467376 — 5.02
- 2012-11-08 0001193125-12-460665 — 2.02, 9.01
- 2012-10-10 0001193125-12-420015 — 5.02, 9.01
- 2012-08-13 0001193125-12-352624 — 1.01, 2.03, 9.01
- 2012-08-09 0001193125-12-347776 — 1.01, 9.01
- 2012-08-09 0001193125-12-347732 — 2.02, 9.01
- 2012-05-01 0001193125-12-201012 — 2.02, 9.01
- 2012-03-30 0001193125-12-144074 — 5.02
- 2012-03-27 0001193125-12-134395 — 5.02, 9.01
- 2012-03-22 0001193125-12-127536 — 5.02
- 2012-01-31 0001193125-12-032079 — 2.02, 9.01
- 2011-12-27 0001193125-11-353002 — 1.01, 9.01
- 2011-12-06 0001193125-11-332192 — 5.02
- 2011-11-10 0001193125-11-306969 — 2.02, 9.01

## late-filing notifications on or before 2013-11-08

- none on or before 2013-11-08

## item 2.02 — earnings release, exhibit 99.1

[0001511737-13-000018:8k_2_02:1]
EX-99.1
2
exhibit991q12014.htm
EXHIBIT 99.1

[0001511737-13-000018:8k_2_02:2]
Exhibit 99.1 Q1 2014

[0001511737-13-000018:8k_2_02:3]
Exhibit 99.1

[0001511737-13-000018:8k_2_02:4]
| Contact: |  |  |  |  |
| Mary Zimmerman - IR@ubnt.com |  |  |  |  |

[0001511737-13-000018:8k_2_02:5]
UBIQUITI NETWORKS REPORTS RECORD FIRST QUARTER FINANCIAL RESULTS

[0001511737-13-000018:8k_2_02:6]
~ Record for Revenue, Earnings, Cash Flow and DSOs ~

[0001511737-13-000018:8k_2_02:7]
San Jose, Calif. - November 7, 2013 - Ubiquiti Networks, Inc. (NASDAQ:UBNT) (“Ubiquiti”) today announced results for the first fiscal quarter of 2014 ending September 30, 2013.

[0001511737-13-000018:8k_2_02:8]
First Quarter Financial Highlights

[0001511737-13-000018:8k_2_02:9]
| • | Revenues of $129.7 million, up 111% year-over-year and an increase of 28% from the prior quarter, marking the fourth consecutive quarter of sequential double-digit revenue growth. |

[0001511737-13-000018:8k_2_02:10]
| • | GAAP net income was $40.5 million, up 208% year-over-year and an increase of 41% sequentially. |

[0001511737-13-000018:8k_2_02:11]
| • | Non-GAAP operating profitability of $47.1 million, up 186% year-over-year and an increase of 37% sequentially. |

[0001511737-13-000018:8k_2_02:12]
| • | GAAP Diluted EPS of $0.45, up 221% year-over-year and non-GAAP diluted EPS of $0.46. |

[0001511737-13-000018:8k_2_02:13]
| • | Average DSOs declined to 25 days, a record for the Company. |

[0001511737-13-000018:8k_2_02:14]
| • | $51.9 million in net cash provided by operating activities. |

[0001511737-13-000018:8k_2_02:15]
First Quarter Business Highlights

[0001511737-13-000018:8k_2_02:16]
Service Provider Technology:

[0001511737-13-000018:8k_2_02:17]
| • | Extended technology leadership in the fixed wireless broadband market through the introduction of next-generation airMAX®, airFiber™ and EdgeMAX™ products. |

[0001511737-13-000018:8k_2_02:18]
| • | Sponsored research conducted by IDC on the market opportunity for fixed wireless access that showed fixed wireless connections growing at a 21.8% CAGR through 2017 and a $10 billion revenue opportunity for wireless Internet service providers (WISPs) by 2017. |

[0001511737-13-000018:8k_2_02:19]
| • | Announced the Ubiquiti World Network (beta), a global alliance of WISPs to foster market awareness and market growth. Over 1000 WISPs have signed up since the announcement on October 16. |

[0001511737-13-000018:8k_2_02:20]
Enterprise Technology:

[0001511737-13-000018:8k_2_02:21]
| • | Announced that the Company shipped its one millionth UniFi™ access point since entering the enterprise WLAN market in 2011. |

[0001511737-13-000018:8k_2_02:22]
| • | Announced two additions to the UniFi product line, including the industry’s first 802.11ac outdoor AP. |

[0001511737-13-000018:8k_2_02:23]
| • | Achieved the highest market share gain in enterprise WLAN coordinated access points for calendar Q2 according to market research firm Gartner. |

[0001511737-13-000018:8k_2_02:24]
| • | Attained legal victory against counterfeiter of Ubiquiti products in China. |

[0001511737-13-000018:8k_2_02:25]
“Ubiquiti is continuing to demonstrate the financial leverage, scalability and disruptive power of our business model,” said Robert J. Pera, Founder, Chief Executive Officer and Executive Chairman of Ubiquiti Networks.  “With our strong pipeline of innovative products, growing traction in the enterprise business and improving execution we believe that we are well positioned for future growth.”

[0001511737-13-000018:8k_2_02:26]
Financial Summary ($, in millions, except per share data)

[0001511737-13-000018:8k_2_02:27]
| Financials | F1Q14 | F4Q13 | F1Q13 |
| Revenues | 129.7 | 101.2 | 61.5 |
| Cost of Revenues | 71.7 | 56.9 | 36.5 |
| Gross Profit | 58.0 | 44.4 | 25.0 |
| Total Operating Expenses | 12.1 | 11.2 | 9.2 |
| Income from Operations | 45.9 | 33.2 | 15.8 |
| Non-GAAP EPS (diluted) | 0.46 | 0.33 | 0.15 |

[0001511737-13-000018:8k_2_02:28]
Product Revenue

[0001511737-13-000018:8k_2_02:29]
Ubiquiti has simplified reporting of its product category revenue. Going forward, product revenue will be reported in two categories: Service Provider Technology and Enterprise Technology. Included below is a table that reconciles the Company’s former product presentation with its new format.

[0001511737-13-000018:8k_2_02:30]
|  | Three Months Ended September 30, |
|  | 2013 |  | 2012 |
|  | (in thousands) |
| Service Provider Technology: |  |  |  |  |
| airMAX | $ | 60,506 |  |  |  | $ | 32,057 |  |
| New platforms | 11,202 |  |  |  | 6,487 |  |
| Other systems | 6,885 |  |  |  | 3,151 |  |
| Embedded radio | 2,277 |  |  |  | 1,714 |  |
| Antennas/other | 13,347 |  |  |  | 8,208 |  |
| Total Service Provider Technology | 94,217 |  |  |  | 51,617 |  |
| Enterprise Technology: |  |  |  |  |
| New platforms | 34,358 |  |  |  | 9,141 |  |
| Other systems | 729 |  |  |  | 633 |  |
| Antennas/other | 383 |  |  |  | 144 |  |
| Total Enterprise Technology | 35,470 |  |  |  | 9,918 |  |
| Total revenues | $ | 129,687 |  |  |  | $ | 61,535 |  |

[0001511737-13-000018:8k_2_02:31]
Business Outlook

[0001511737-13-000018:8k_2_02:32]
Ubiquiti currently believes the demand environment in its end markets supports the following forecast for the Company's second fiscal quarter ending December 31, 2013:

[0001511737-13-000018:8k_2_02:33]
| • | Revenues of between $130 million and $136 million |

[0001511737-13-000018:8k_2_02:34]
| • | GAAP Diluted EPS of between $0.40 and $0.44 |

[0001511737-13-000018:8k_2_02:35]
| • | Non-GAAP Diluted EPS of between $0.42 and $0.46 |

[0001511737-13-000018:8k_2_02:36]
Conference Call

[0001511737-13-000018:8k_2_02:37]
Ubiquiti Networks will host a Q&A-only conference call to discuss the Company’s financial results at 2:00 p.m. PT today. A transcript of management’s prepared remarks can be found on the Investor Relations section of Ubiquiti Networks' website, http://www.ubnt.com/.

[0001511737-13-000018:8k_2_02:38]
To listen to the Q&A-only conference call via telephone, dial (877) 291-1296 (U.S. toll-free) or (720) 259-9209 (International) to be connected to the call by an operator. Participants should dial in at least 10 minutes prior to the start of the call. Investors may also listen to a live webcast of the Q&A-only conference call by visiting the Investor Relations section of Ubiquiti Networks' website.

[0001511737-13-000018:8k_2_02:39]
The playback of the Q&A call will be available approximately two hours after the call concludes and will be accessible on the Investor Relations section of Ubiquiti Networks' website.

[0001511737-13-000018:8k_2_02:40]
About Ubiquiti Networks

[0001511737-13-000018:8k_2_02:41]
Ubiquiti Networks (NASDAQ: UBNT) is closing the digital divide by building network communication platforms for everyone and everywhere.  With over 10 million devices deployed in over 180 countries, Ubiquiti is transforming under-networked businesses and communities.  Our leading edge platforms, airMAX™, UniFi™, airFiber™, airVision™, mFi™ and EdgeMAX™ combine innovative technology, disruptive price performance and the support of a global user community to eliminate barriers to connectivity.   For more information, join our community at http://www.ubnt.com

[0001511737-13-000018:8k_2_02:42]
Ubiquiti, the Ubiquiti logo, Ubiquiti Networks, airMAX, UniFi, airFiber, airVision, mFi and EdgeMAX are registered trademarks or trademarks of Ubiquiti Networks, Inc. and/or its affiliates in the United States and other countries.

[0001511737-13-000018:8k_2_02:43]
Use of Non-GAAP Financial Information

[0001511737-13-000018:8k_2_02:44]
To supplement our condensed consolidated financial results prepared under generally accepted accounting principles, or GAAP, we use non-GAAP measures of net income and earnings per diluted share that are adjusted to exclude certain recurring costs, expenses and gains such as stock based compensation expense and the tax effects of these non-GAAP adjustments.  Reconciliations of the adjustments to GAAP results for the three months ended September 30, 2013 and 2012 are provided below.  In addition, an explanation of the ways in which management uses non-GAAP financial information to evaluate its business, the substance behind management's decision to use this non-GAAP financial information, the material limitations associated with the use of non-GAAP financial information, the manner in which management compensates for those limitations, and the substantive reasons management believes that this non-GAAP financial information provides useful information to investors is included under "About our Non-GAAP Net Income and Adjustments" after the tables below.

[0001511737-13-000018:8k_2_02:45]
These non-GAAP measures are not in accordance with or an alternative to GAAP and may be materially different from other non-GAAP measures, including similarly titled non-GAAP measures, used by other companies.  The presentation of this additional information should not be considered in isolation from, as a substitute for, or superior to, net income or earnings per diluted share prepared in accordance with GAAP.

[0001511737-13-000018:8k_2_02:46]
Forward-looking statements are subject to certain risks and uncertainties that could cause our actual future results to differ materially, or cause a material adverse impact on our results.  Potential risks and uncertainties include, but are not limited to, fluctuations in our operating results; varying demand for our products due to the financial and operating condition of our distributors and their customers, distributors' inventory management practices and general economic conditions; impact of counterfeiting and our ability to contain such impact; our reliance on a limited number of distributors; inability of our contract manufacturers and suppliers to meet our demand; our dependence on Qualcomm Atheros for chipsets without a short-term alternative; as we move into new markets competition from certain of our current or potential competitors who may be more established in such markets; our ability to keep pace with technological and market developments; success and timing of new product introductions by us and the performance of our products generally; our ability to effectively manage the significant increase in our transactional sales volumes; we may become subject to warranty claims, product liability and product recalls; that a substantial majority of our sales are into countries outside the United States and we are subject to numerous U.S. export control and economic sanctions laws; costs related to responding to government inquiries related to regulatory compliance; our reliance on the Ubiquiti Community; our reliance on certain key members of our management team, including our founder and chief executive officer, Robert J.  Pera; adverse tax-related matters

[0001511737-13-000018:8k_2_02:47]
such as tax audits, changes in our effective tax rate or new tax legislative proposals; whether the final determination of our income tax liability may be materially different from our income tax provisions; the impact of any intellectual property litigation and claims for indemnification and litigation related to U.S. Securities laws and economic and political conditions in the United States and abroad.  We discuss these risks in greater detail under the heading “Risk Factors” and elsewhere in our Annual Report on Form 10-K for the year ended June 30, 2013 and other filings filed with the U.S. Securities and Exchange Commission (the SEC), which are available at the SEC's website at www.sec.gov.  Copies may also be obtained by contacting Ubiquiti Networks' Investor Relations Department, or by email at IR@ubnt.com or Ubiquiti Networks' Investor Relations website at www.ubnt.com.

[0001511737-13-000018:8k_2_02:48]
Given these uncertainties, you should not place undue reliance on these forward-looking statements.  Also, forward-looking statements represent our management's beliefs and assumptions only as of the date made.  Ubiquiti Networks undertakes no obligation to update information contained in this press release.  You should review our SEC filings carefully and with the understanding that our actual future results may be materially different from what we expect.

[0001511737-13-000018:8k_2_02:49]
| Ubiquiti Networks Inc.Condensed Consolidated Statement of Operations(In thousands, except per share data)(Unaudited) |
|  |  | Three Months Ended September 30, |
|  |  | 2013 |  | 2012 |
| Revenues |  | $ | 129,687 |  |  | $ | 61,535 |  |
| Cost of revenues |  | 71,664 |  |  | 36,515 |  |
| Gross profit |  | 58,023 |  |  | 25,020 |  |
| Operating expenses: |  |  |  |  |
| Research and development |  | 6,317 |  |  | 4,711 |  |
| Sales, general and administrative |  | 5,810 |  |  | 4,534 |  |
| Total operating expenses |  | 12,127 |  |  | 9,245 |  |
| Income from operations |  | 45,896 |  |  | 15,775 |  |
| Interest expense and other, net |  | (246 | ) |  | (86 | ) |
| Income before provision for income taxes |  | 45,650 |  |  | 15,689 |  |
| Provision for income taxes |  | 5,122 |  |  | 2,510 |  |
| Net income |  | $ | 40,528 |  |  | $ | 13,179 |  |
| Net income per share of common stock: |  |  |  |  |
| Basic |  | $ | 0.46 |  |  | $ | 0.14 |  |
| Diluted |  | $ | 0.45 |  |  | $ | 0.14 |  |
| Weighted average shares used in computing net income per share of common stock: |  |  |  |  |
| Basic |  | 87,411 |  |  | 90,970 |  |
| Diluted |  | 89,473 |  |  | 92,925 |  |

[0001511737-13-000018:8k_2_02:50]
| Ubiquiti Networks Inc.Reconciliation of GAAP Net Income to Non-GAAP Net Income(In thousands, except per share data)(Unaudited) |
|  |  | Three Months Ended September 30, |
|  |  | 2013 |  | 2012 |
| Net income |  | $ | 40,528 |  |  | $ | 13,179 |  |
| Stock-based compensation: |  |  |  |  |
| Cost of revenues |  | 144 |  |  | 81 |  |
| Research and development |  | 496 |  |  | 266 |  |
| Sales, general and administrative |  | 527 |  |  | 309 |  |
| Tax effect of non-GAAP adjustments |  | (467 | ) |  | (263 | ) |
| Non-GAAP net income |  | $ | 41,228 |  |  | $ | 13,572 |  |
| Non-GAAP diluted EPS |  | $ | 0.46 |  |  | $ | 0.15 |  |
| Weighted-average shares used in non-GAAP diluted EPS |  | 89,473 |  |  | 92,925 |  |

[0001511737-13-000018:8k_2_02:51]
| Ubiquiti Networks Inc.Condensed Consolidated Balance Sheets(In thousands, except share amounts)(Unaudited) |
|  |  | September 30, 2013 |  | June 30, 2013(1) |
| Assets |  |  |  |  |
| Current assets: |  |  |  |  |
| Cash and cash equivalents |  | $ | 279,729 |  |  | $ | 227,826 |  |
| Accounts receivable, net |  | 35,798 |  |  | 35,884 |  |
| Inventories |  | 16,375 |  |  | 15,880 |  |
| Current deferred tax asset |  | 733 |  |  | 733 |  |
| Prepaid expenses and other current assets |  | 2,273 |  |  | 3,151 |  |
| Total current assets |  | 334,908 |  |  | 283,474 |  |
| Property and equipment, net |  | 5,834 |  |  | 5,976 |  |
| Long-term deferred tax asset |  | 4 |  |  | 4 |  |
| Other long–term assets |  | 2,701 |  |  | 2,886 |  |
| Total assets |  | $ | 343,447 |  |  | $ | 292,340 |  |
| Liabilities and Stockholders’ Equity |  |  |  |  |
| Current liabilities: |  |  |  |  |
| Accounts payable |  | $ | 44,311 |  |  | $ | 36,187 |  |
| Customer deposits |  | 3,578 |  |  | 5,123 |  |
| Deferred revenues |  | 793 |  |  | 691 |  |
| Income taxes payable |  | 1,263 |  |  | 1,257 |  |
| Debt - short-term |  | 5,015 |  |  | 5,013 |  |
| Other current liabilities |  | 12,850 |  |  | 11,150 |  |
| Total current liabilities |  | 67,810 |  |  | 59,421 |  |
| Long-term taxes payable |  | 12,385 |  |  | 11,857 |  |
| Debt - long-term |  | 69,874 |  |  | 71,116 |  |
| Deferred revenues - long-term |  | 2,514 |  |  | 2,510 |  |
| Total liabilities |  | 152,583 |  |  | 144,904 |  |
| Stockholders’ equity: |  |  |  |  |
| Common stock |  | 88 |  |  | 87 |  |
| Additional paid–in capital |  | 137,881 |  |  | 134,982 |  |
| Treasury stock |  | (123,864 | ) |  | (123,864 | ) |
| Retained earnings |  | 176,759 |  |  | 136,231 |  |
| Total stockholders’ equity |  | 190,864 |  |  | 147,436 |  |
| Total liabilities and stockholders’ equity |  | $ | 343,447 |  |  | $ | 292,340 |  |

[0001511737-13-000018:8k_2_02:52]
| (1) | Derived from audited consolidated statements as of and for the year ended June 30, 2013. |

[0001511737-13-000018:8k_2_02:53]
| Ubiquiti Networks Inc.Revenues by Product Type - New Categories (In thousands)(Unaudited) |
|  | Three Months Ended September 30, |
|  | 2013 |  | 2012 |
| Service Provider Technology | $ | 94,217 |  |  | $ | 51,617 |  |
| Enterprise Technology | 35,470 |  |  | 9,918 |  |
| Total revenues | $ | 129,687 |  |  | $ | 61,535 |  |

[0001511737-13-000018:8k_2_02:54]
| Ubiquiti Networks Inc.Revenues by Product Type - Prior Categories (In thousands)(Unaudited) |
|  | Three Months Ended September 30, |
|  | 2013 |  | 2012 |
| airMAX | $ | 60,506 |  |  | $ | 32,057 |  |
| New platforms | 45,560 |  |  | 15,628 |  |
| Other systems | 7,615 |  |  | 3,784 |  |
| Systems | 113,681 |  |  | 51,469 |  |
| Embedded radio | 2,277 |  |  | 1,714 |  |
| Antennas/other | 13,729 |  |  | 8,352 |  |
| Total revenues | $ | 129,687 |  |  | $ | 61,535 |  |

[0001511737-13-000018:8k_2_02:55]
| Ubiquiti Networks Inc.Revenues by Geographical Area(In thousands)(Unaudited) |
|  |  | Three Months Ended September 30, |
|  |  | 2013 |  | 2012 |
| North America |  | $ | 37,433 |  |  | $ | 20,361 |  |
| South America |  | 20,776 |  |  | 10,243 |  |
| Europe, the Middle East and Africa |  | 52,866 |  |  | 23,144 |  |
| Asia Pacific |  | 18,612 |  |  | 7,787 |  |
| Total revenues |  | $ | 129,687 |  |  | $ | 61,535 |  |

[0001511737-13-000018:8k_2_02:56]
About our Non-GAAP Net Income and Adjustments

[0001511737-13-000018:8k_2_02:57]
Use of Non-GAAP Financial Information

[0001511737-13-000018:8k_2_02:58]
To supplement our condensed consolidated financial results prepared under generally accepted accounting principles, or GAAP, we use non-GAAP measures of net income and earnings per diluted share that are GAAP net income and GAAP earnings per diluted share adjusted to exclude certain recurring costs, expenses and gains.

[0001511737-13-000018:8k_2_02:59]
We believe that the presentation of non-GAAP net income and non-GAAP earnings per diluted share provides important supplemental information regarding non-cash expenses, significant recurring items that we believe are important to understanding our financial, and business trends relating to our financial condition and results of operations.  Non-GAAP net income and non-GAAP earnings per diluted share are among the primary indicators used by management as a basis for planning and forecasting future periods and by management and our board of directors to determine whether our operating performance has met specified targets and thresholds.  Management uses non-GAAP net income and non-GAAP earnings per diluted share when evaluating operating performance

[0001511737-13-000018:8k_2_02:60]
because it believes that the exclusion of the items described below, for which the amounts and/or timing may vary significantly depending upon the Company's activities and other factors, facilitates comparability of the Company's operating performance from period to period.  We have chosen to provide this information to investors so they can analyze our operating results in the same way that management does and use this information in their assessment of our business and the valuation of our Company.

[0001511737-13-000018:8k_2_02:61]
Use and Economic Substance of Non-GAAP Financial Measures used by Ubiquiti Networks

[0001511737-13-000018:8k_2_02:62]
We compute non-GAAP net income and non-GAAP diluted earnings per share by adjusting GAAP net income and GAAP earnings per diluted share to remove the impact of recurring stock-based compensation expense and the tax effect of these adjustments.  Examples of items excluded from net income are:

[0001511737-13-000018:8k_2_02:63]
| • | Recurring charges and gains, including: |

[0001511737-13-000018:8k_2_02:64]
| ◦ | Stock-based compensation expense is recognized in accordance with FASB Accounting Standards Codification, Topic 718, Stock Compensation. |

[0001511737-13-000018:8k_2_02:65]
| • | Tax effect of non-GAAP adjustments. After adjusting to exclude the items described above, we apply the principles of ASC 740, Income Taxes, to estimate the non-GAAP income tax provision. |

[0001511737-13-000018:8k_2_02:66]
Usefulness of Non-GAAP Financial Information to Investors

[0001511737-13-000018:8k_2_02:67]
These non-GAAP measures are not in accordance with or an alternative to GAAP and may be materially different from other non-GAAP measures, including similarly titled non-GAAP measures, used by other companies.  The presentation of this additional information should not be considered in isolation from, as a substitute for, or superior to, net income or earnings per diluted share prepared in accordance with GAAP.  Non-GAAP financial measures have limitations in that they do not reflect certain items that may have a material impact upon our reported financial results.  We expect to continue to incur expenses of a nature similar to the non-GAAP adjustments described above, and exclusion of these items from our non-GAAP net income and non-GAAP earnings per diluted share should not be construed as an inference that these costs are unusual, infrequent or non-recurring.

[0001511737-13-000018:8k_2_02:68]
For more information on the non-GAAP adjustments, please see the table captioned “Reconciliation of GAAP Net Income to non-GAAP Net Income” included in this press release.
