# UI note change history — 0001511737-13-000006 → 0001511737-13-000021


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2013-11-08):
[0001511737-13-000021:note_history:1]
At September 30, 2013, future minimum annual payments under operating leases are as follows (in thousands):
  (was, 2013-05-10, similarity 0.9495):
[0001511737-13-000006:note_history:1]
At March 31, 2013, future minimum annual payments under operating leases are as follows (in thousands):

- changed (2013-11-08):
[0001511737-13-000021:note_history:2]
The Company subcontracts with other companies to manufacture its products. During the normal course of business, the Company’s contract manufacturers procure components based upon orders placed by the Company. If the Company cancels all or part of the orders, it may still be liable to the contract manufacturers for the cost of the components purchased by them to manufacture the Company’s products. The Company periodically reviews the potential liability and to date no significant accruals have been recorded.
  (was, 2013-05-10, similarity 0.8424):
[0001511737-13-000006:note_history:2]
The Company subcontracts with other companies to manufacture its products. During the normal course of business, the Company’s contract manufacturers procure components based upon orders placed by the Company. If the Company cancels all or part of the orders, it may still be liable to the contract manufacturers for the cost of the components purchased by them to manufacture the Company’s products. The Company periodically reviews the potential liability and to date no significant accruals have been recorded. The Company’s consolidated financial position and results of operations could be negatively impacted if it were required to compensate the contract manufacturers for any liabilities incurred.

- changed (2013-11-08):
[0001511737-13-000021:note_history:3]
The Company may be involved, from time to time, in a variety of claims, lawsuits, investigations, and proceedings relating to contractual disputes, intellectual property rights, employment matters, regulatory compliance matters and other litigation matters relating to various claims that arise in the normal course of business. The Company determines whether an estimated loss from a contingency should be accrued by assessing whether a loss is deemed probable and can be reasonably estimated. The Company assesses its potential liability by analyzing specific litigation and regulatory matters using available information. The Company develops its views on estimated losses in consultation with inside and outside counsel, which involves a subjective analysis of potential results and outcomes, assuming various combinations of appropriate litigation and settlement strategies. Taking all of the above factors into account, the Company records an amount where it is probable that the Company will incur a loss and where that loss can be reasonably estimated. However, the Company’s estimates may be incorrect and the Company could ultimately incur more or less than the amounts initially recorded.  The Company may also incur significant legal fees, which are expensed as incurred, in defending against these claims.
  (was, 2013-05-10, similarity 0.8864):
[0001511737-13-000006:note_history:3]
The Company may be involved, from time to time, in a variety of claims, lawsuits, investigations, and proceedings relating to contractual disputes, intellectual property rights, employment matters, regulatory compliance matters and other litigation matters relating to various claims that arise in the normal course of business. The Company determines whether an estimated loss from a contingency should be accrued by assessing whether a loss is deemed probable and can be reasonably estimated. The Company assesses its potential liability by analyzing specific litigation and regulatory matters using available information. The Company develops its views on estimated losses in consultation with inside and outside counsel, which involves a subjective analysis of potential results and outcomes, assuming various combinations of appropriate litigation and settlement strategies. Taking all of the above factors into account, the Company records an amount where it is probable that the Company will incur a loss and where that loss can be reasonably estimated. However, the Company’s estimates may be incorrect and the Company could ultimately incur more or less than the amounts initially recorded. Litigation can be costly, diverting management’s attention and could, upon resolution, have a material adverse effect on the Company’s business, results of operations, financial condition, and cash flows.

- changed (2013-11-08):
[0001511737-13-000021:note_history:4]
In January 2011, the U.S. Commerce Department, Bureau of Industry and Security’s (“BIS”) Office of Export Enforcement (“OEE”) contacted the Company to request that the Company provide information related to its relationship with a logistics company in the United Arab Emirates (“UAE”) and with a company in Iran, as well as information on the export classification of its products. As a result of this inquiry the Company, assisted by outside counsel, conducted a review of the Company's export transactions from 2008 through March 2011 to not only gather information responsive to the OEE's request but also to review the Company's overall compliance with export control and sanctions laws.  The Company believes its products have been sold into Iran by third parties. The Company does not believe that it directly sold, exported or shipped its products into Iran or any other country subject to a U.S. embargo. However, until early 2010, the Company did not prohibit its distributors from selling its products into Iran or any other country subject to a U.S. embargo. In the course of this review the Company identified that two distributors may have sold the Company's products into Iran. The Company's review also found that while it had obtained required Commodity Classification Rulings for its products in June 2010 and November 2010, the Company did not advise its shipping personnel to change the export authorizations used on its shipping documents until February 2011. During the course of the Company's export control review, the Company also determined that it had failed to maintain adequate records for the five year period required by the Export Administration Regulations (the "EAR") and the sanctions regulations due to its lack of infrastructure and because it was prior to its transition to its current system of record, NetSuite.
  (was, 2013-05-10, similarity 0.9773):
[0001511737-13-000006:note_history:4]
In January 2011, the U.S. Commerce Department, Bureau of Industry and Security’s (“BIS”) Office of Export Enforcement (“OEE”) contacted the Company to request that the Company provide information related to its relationship with a logistics company in the United Arab Emirates (“UAE”) and with a company in Iran, as well as information on the export classification of its products. As a result of this inquiry the Company, assisted by outside counsel, conducted a review of the Company's export transactions from 2008 through March 2011 to not only gather information responsive to the OEE's request but also to review the Company's overall compliance with export control and sanctions laws.  The Company believes its products have been sold into Iran by third parties. The Company does not believe that it directly sold, exported or shipped its products into Iran or any other country subject to a U.S. embargo. However, until early 2010, the Company did not prohibit its distributors from selling its products into Iran or any other country subject to a U.S. embargo. In the course of this review the Company identified that two distributors may have sold the Company's products into Iran. The Company's review also found that while it had obtained required Commodity Classification Rulings for its products in June 2010 and November 2010, the Company did not advise its shipping personnel to change the export authorizations used on its shipping documents until February 2011. During the course of the Company's export control review, the Company also determined that it had failed to maintain adequate records for the five year period required by the EAR and the sanctions regulations due to its lack of infrastructure and because it was prior to its transition to its current system of record, NetSuite.

- changed (2013-11-08):
[0001511737-13-000021:note_history:5]
OFAC is still reviewing the Company’s voluntary disclosure. In the Company’s submission, the Company provided OFAC with an explanation of the activities that led to the sales of its products in Iran and the failure to comply with the EAR and OFAC sanctions. Although the Company’s OFAC and OEE voluntary disclosures covered similar sets of facts, which led the OEE to resolve the case with the issuance of a warning letter, OFAC may conclude that the Company’s actions resulted in violations of U.S. export control and economic sanctions laws and warrant the imposition of penalties that could include fines, termination of the Company’s ability to export its products, and/or referral for criminal prosecution. The penalties may be imposed against the Company and/or its management. The maximum civil monetary penalty for the violations is up to $250,000 or twice the value of the transaction, whichever is greater, per violation. Any such fines or restrictions may be material to the Company’s financial results in the period in which they are imposed.  The Company cannot predict when OFAC will complete its review or decide upon the imposition of possible penalties.
  (was, 2013-05-10, similarity 0.9806):
[0001511737-13-000006:note_history:5]
OFAC is still reviewing the Company’s voluntary disclosure. In the Company’s submission, the Company provided OFAC with an explanation of the activities that led to the sales of its products in Iran and the failure to comply with the Export Administration Regulations (the “EAR”) and OFAC sanctions. Although the Company’s OFAC and OEE voluntary disclosures covered similar sets of facts, which led the OEE to resolve the case with the issuance of a warning letter, OFAC may conclude that the Company’s actions resulted in violations of U.S. export control and economic sanctions laws and warrant the imposition of penalties that could include fines, termination of the Company’s ability to export its products, and/or referral for criminal prosecution. The penalties may be imposed against the Company and/or its management. The maximum civil monetary penalty for the violations is up to $250,000 or twice the value of the transaction, whichever is greater, per violation. Any such fines or restrictions may be material to the Company’s financial results in the period in which they are imposed.  The Company cannot predict when OFAC will complete its review or decide upon the imposition of possible penalties.

- changed (2013-11-08):
[0001511737-13-000021:note_history:6]
The Company has taken actions designed to ensure that export classification information is distributed to the appropriate personnel in a timely manner, and has adopted policies and procedures to promote its compliance with applicable export laws and regulations, including obtaining written distribution agreements with substantially all of its distributors that contain covenants requiring compliance with U.S. export control and economic sanctions law, notifying all of its distributors of their obligations and obtaining updated distribution agreements from distributors that accounted for approximately 99% of its revenue in fiscal 2013.  However the Company cannot be sure such actions will be effective.  Additionally, the Company's failure to amend all its distribution agreements and to implement more robust compliance controls immediately after the discovery of Iran-related sales activity in early 2010 may be aggravating factors that could impact the imposition of penalties imposed on the Company or its management.  Based on the facts known to the Company to date, the Company recorded an expense of $1.6 million for this export compliance matter in fiscal 2010, which represents management’s estimated exposure for fines in accordance with applicable accounting literature. This amount was calculated from information discovered through the Company’s internal review and this loss is deemed to be probable and reasonably estimable. However, the Company also believes that it is reasonably possible that the loss may be higher, but the Company cannot reasonably estimate the range of any further potential losses. Should additional facts be discovered in the future and/or should actual fines or other penalties substantially differ from the Company’s estimates, its business, financial condition, cash flows and results of operations may be materially negatively impacted.
  (was, 2013-05-10, similarity 0.8423):
[0001511737-13-000006:note_history:6]
While the Company has taken actions designed to ensure that export classification information is distributed to the appropriate personnel in a timely manner and has adopted policies and procedures to promote its compliance with applicable export laws and regulations, including obtaining written distribution agreements with substantially all of its distributors that contain covenants requiring compliance with U.S. export control and economic sanctions law; notifying all of its distributors of their obligations and obtaining updated distribution agreements from distributors that accounted for approximately 99% of its revenue in fiscal 2012.  However the Company cannot be sure such actions will be effective.  Additionally, the Company's failure to amend all its distribution agreements and to implement more robust compliance controls immediately after the discovery of Iran-related sales activity in early 2010 may be aggravating factors that could impact the imposition of penalties imposed on the Company or its management.  Based on the facts known to the Company to date, the Company recorded an expense of $1.6 million for this export compliance matter in fiscal 2010, which represents management’s estimated exposure for fines in accordance with applicable accounting literature. This amount was calculated from information discovered through the Company’s internal review and this loss is deemed to be probable and reasonably estimable. However, the Company also believes that it is reasonably possible that the loss may be higher, but the Company cannot reasonably estimate the range of any further potential losses. Should additional facts be discovered in the future and/or should actual fines or other penalties substantially differ from the Company’s estimates, its business, financial condition, cash flows and results of operations would be materially negatively impacted.

- changed (2013-11-08):
[0001511737-13-000021:note_history:7]
Beginning on September 7, 2012, two shareholder class action complaints were filed against the Company, certain of its officers and directors and the underwriters of the Company's initial public offering in the United States District Court for the Northern District of California. On January 30, 2013, the plaintiffs filed an Amended Consolidated Complaint, which alleges claims under the Securities Act of 1933, the Securities Exchange Act of 1934 and SEC Rule 10b-5 on behalf of a purported class of those who purchased the Company's common stock between October 14, 2011 and August 9, 2012 and/or acquired the Company's stock pursuant to or traceable to the registration statement for the initial public offering. The Amended Consolidated Complaint alleges that the defendants violated the federal securities laws by issuing false or misleading statements regarding the sale of counterfeit Company products.  The consolidated complaint seeks, among other things, damages and interest, rescission, and attorneys' fees and costs. On March 26, 2013, the Company filed a motion to dismiss the complaint.  On August 27, 2013, the court held a hearing on the motion to dismiss, and its decision is pending.
  (was, 2013-05-10, similarity 0.9282):
[0001511737-13-000006:note_history:7]
Beginning on September 7, 2012, two shareholder class action complaints were filed against the Company, certain of its officers and directors and the underwriters of the Company's initial public offering in the United States District Court for the Northern District of California. On January 30, 2013, the plaintiffs filed an Amended Consolidated Complaint, which alleges claims under the Securities Act of 1933, the Securities Exchange Act of 1934 and SEC Rule 10b-5 on behalf of a purported class of those who purchased the Company's common stock between October 14, 2011 and August 9, 2012 and/or acquired the Company's stock pursuant to or traceable to the registration statement for the initial public offering. The Amended Consolidated Complaint alleges that the defendants violated the federal securities laws by issuing false or misleading statements regarding the sale of counterfeit Company products.  The consolidated complaint seeks, among other things, damages and interest, rescission, and attorneys' fees and costs. On March 26, 2013, the Company filed a motion to dismiss the complaint.  On April 30, 2013, the plaintiffs filed an opposition to the Company's motion to dismiss.

- changed (2013-11-08):
[0001511737-13-000021:note_history:8]
The Company believes that the allegations in the consolidated complaint are without merit and intend to vigorously contest the litigation. However, there can be no assurance that the Company will be successful in its defense. Because the case is at a very early stage, the Company cannot say that a loss is probable and cannot currently reasonably estimate the loss or the range of possible losses that may be experienced in connection with this litigation.
  (was, 2013-05-10, similarity 0.7832):
[0001511737-13-000006:note_history:8]
The Company believes that the allegations in the consolidated complaint are without merit and intend to vigorously contest the litigation. However, there can be no assurance that the Company will be successful in its defense. Because the case is at a very early stage, the Company cannot currently estimate the loss or the range of possible losses we may experience in connection with this litigation.

- removed (2013-11-08):
[0001511737-13-000006:note_history:9]
In December 2011, the Company entered into an agreement to lease approximately 64,512 square feet of office and research and development space located in San Jose, California, which the Company uses as its corporate headquarters. The lease term is from April 1, 2012, through  July 31, 2017. The lease has been categorized as an operating lease, and the total estimated rent expense to be recognized is $4.9 million.


## us-gaap:BusinessDescriptionAndBasisOfPresentationTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2013-11-08):
[0001511737-13-000021:note_history:10]
On June 18, 2013, the Company completed a secondary offering of 7,031,464 shares of common stock at an offering price of $16.00 per share, which included 531,464 shares sold in connection with the partial exercise of the option to purchase additional shares granted to the underwriters.  All of the shares sold in the offering were sold by existing stockholders of the Company, including entities affiliated with Summit Partners, L.P., and the Company's chief executive officer, Robert J. Pera.  No shares were sold by the Company in the offering, and as such, the Company did not receive any proceeds from the offering.

- changed (2013-11-08):
[0001511737-13-000021:note_history:11]
The Company operates on a fiscal year ending June 30. In this Quarterly Report, the fiscal year ending June 30, 2014 is referred to as “fiscal 2014” and the fiscal year ended June 30, 2013 is referred to as “fiscal 2013.”
  (was, 2013-05-10, similarity 0.6832):
[0001511737-13-000006:note_history:11]
The Company operates on a fiscal year ending June 30. In this Quarterly Report, the fiscal year ended June 30, 2013 is referred to as “fiscal 2013” and the fiscal year ending June 30, 2012 is referred to as “fiscal 2012.”

- changed (2013-11-08):
[0001511737-13-000021:note_history:12]
These condensed consolidated financial statements should be read in conjunction with the Company’s audited consolidated financial statements for the fiscal year ended June 30, 2013 included in its Annual Report on Form 10-K, as filed on September 13, 2013 with the SEC (the “Annual Report”). The results of operations for the three months ended September 30, 2013 are not necessarily indicative of the results to be expected for any future periods.
  (was, 2013-05-10, similarity 0.7825):
[0001511737-13-000006:note_history:12]
These condensed consolidated financial statements should be read in conjunction with the Company’s audited consolidated financial statements for the fiscal year ended June 30, 2012 included in its Annual Report on Form 10-K, as filed on September 28, 2012 with the SEC (the “Annual Report”). The results of operations for the three and nine months ended March 31, 2013 are not necessarily indicative of the results to be expected for any future periods.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2013-11-08):
[0001511737-13-000021:note_history:13]
In July 2013, the FASB issued a new accounting standard update on the financial statement presentation of unrecognized tax benefits.  The new guidance provides that a liability related to an unrecognized tax benefit would be presented as a reduction of a deferred tax asset for a new operating loss carryforward, a similar tax loss or a tax credit carryforward if such settlement is required or expected in the event the uncertain tax position is disallowed.  The new guidance will become effective for the Company on July 1, 2014 and it should be applied prospectively to unrecognized tax benefits that exist as of the effective date with retrospective application permitted.  The Company is currently assessing the impact of this new guidance.

- removed (2013-11-08):
[0001511737-13-000006:note_history:14]
The Company does not believe there have been any recent accounting pronouncements that would have a significant impact on the Company’s financial statements.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2013-11-08):
[0001511737-13-000021:note_history:15]
On August 7, 2012, the Company entered into a Loan and Security Agreement (the “Loan Agreement”) with U.S. Bank, as syndication agent, and East West Bank, as administrative agent for the lenders party to the Loan Agreement.  The Loan Agreement provides for (i) a $50.0 million revolving credit facility, with a $5.0 million sublimit for the issuance of letters of credit and a $5.0 million sublimit for the making of swingline loan advances (the “Revolving Credit Facility”), and (ii) a $50.0 million term loan facility (the “Term Loan Facility”). The Company may request borrowings under the Revolving Credit Facility until August 7, 2015.  The Loan Agreement replaced a previous agreement whereby the Company had an existing term loan balance of $29.2 million as of the date the new Loan Agreement.  On August 7, 2012, the Company borrowed $20.8 million under the Term Loan Facility, and no borrowings remain available for borrowing thereunder.  On November 21, 2012, the Company borrowed $10.0 million under the Revolving Credit Facility. On December 20, 2012, the Company borrowed an additional $20.0 million under the Revolving Credit Facility, and $20.0 million remains available for borrowing thereunder.

- changed (2013-11-08):
[0001511737-13-000021:note_history:16]
The Loan Agreement contains customary affirmative and negative covenants, including covenants that limit or restrict the Company and its subsidiaries’ ability to, among other things, incur indebtedness, grant liens, merge or consolidate, dispose of assets, pay dividends or make distributions, make investments, make acquisitions, prepay certain indebtedness, change the nature of its business, enter into certain transactions with affiliates, enter into restrictive agreements, and make capital expenditures, in each case subject to customary exceptions for a credit facility of this size and type. The Company is also required to maintain a minimum debt service coverage ratio, a maximum leverage ratio, and a minimum liquidity ratio.  As of September 30, 2013, the Company was in compliance with all affirmative and negative covenants, debt service coverage ratio, leverage ratio and liquidity ratio requirements.
  (was, 2013-05-10, similarity 0.9019):
[0001511737-13-000006:note_history:16]
The Loan Agreement contains customary affirmative and negative covenants, including covenants that limit or restrict the Company and its subsidiaries’ ability to, among other things, incur indebtedness, grant liens, merge or consolidate, dispose of assets, pay dividends or make distributions, make investments, make acquisitions, prepay certain indebtedness, change the nature of its business, enter into certain transactions with affiliates, enter into restrictive agreements, and make capital expenditures, in each case subject to customary exceptions for a credit facility of this size and type. The Company is also required to maintain a minimum debt service coverage ratio, a maximum leverage ratio, and a minimum liquidity ratio.  As of March 31, 2013, the Company was in compliance with all affirmative and negative covenants, debt service coverage ratio, leverage ratio and liquidity ratio requirements.

- changed (2013-11-08):
[0001511737-13-000021:note_history:17]
The Loan Agreement includes customary events of default that include, among other things, defaults for the failure to timely pay principal, interest, or other amounts due, defaults due to the inaccuracy of representations and warranties, covenant defaults, a cross default to material indebtedness, bankruptcy and insolvency defaults, material judgment defaults, defaults due to the unenforceability of a guaranty, and defaults due to circumstances that have or could reasonably be expected to have a material adverse effect on the Company's business, operations or financial condition, its ability to pay or perform under the Loan Agreement, or on the lenders' security interests. The occurrence of an event of default could result in the acceleration of the obligations under the Loan Agreement. During the existence of an event of default, interest on the obligations under the Loan Agreement could be increased by 2.00% above the otherwise applicable interest rate.
  (was, 2013-05-10, similarity 0.9907):
[0001511737-13-000006:note_history:17]
The Loan Agreement includes customary events of default that, include among other things, defaults for the failure to timely pay principal, interest, or other amounts due, defaults due to the inaccuracy of representations and warranties, covenant defaults, a cross default to material indebtedness, bankruptcy and insolvency defaults, material judgment defaults, defaults due to the unenforceability of a guaranty, and defaults due to circumstances that have or could reasonably be expected to have a material adverse effect on the Company's business, operations or financial condition, its ability to pay or perform under the Loan Agreement, or on the lenders' security interests. The occurrence of an event of default could result in the acceleration of the obligations under the Loan Agreement. During the existence of an event of default, interest on the obligations under the Loan Agreement could be increased by 2.00% above the otherwise applicable interest rate.

- added (2013-11-08):
[0001511737-13-000021:note_history:18]
During the three months ended September 30, 2013 and 2012, the Company made aggregate payments of $1.3 million and $583,000, respectively, against the loan balance.  As of September 30, 2013, the Company has classified $5.0 million and $69.9 million in short-term and long-term debt, respectively, on its consolidated balance sheet related to the Loan Agreement.

- changed (2013-11-08):
[0001511737-13-000021:note_history:19]
The following table summarizes our estimated debt and interest payment obligations as of September 30, 2013 (in thousands):
  (was, 2013-05-10, similarity 0.9569):
[0001511737-13-000006:note_history:19]
The following table summarizes our estimated debt and interest payment obligations as of March 31, 2013 (in thousands):

- changed (2013-11-08):
[0001511737-13-000021:note_history:20]
|  | 2014(remainder) |  | 2015 |  | 2016 |  | 2017 |  | 2018 |  | Total |
| Debt payment obligations | $ | 3,750 |  |  | $ | 6,875 |  |  | $ | 39,375 |  |  | $ | 10,000 |  |  | $ | 15,000 |  |  | $ | 75,000 |  |
| Interest payments on debt payment obligations | 1,383 |  |  | 1,723 |  |  | 1,043 |  |  | 532 |  |  | 125 |  |  | 4,806 |  |
| Total | $ | 5,133 |  |  | $ | 8,598 |  |  | $ | 40,418 |  |  | $ | 10,532 |  |  | $ | 15,125 |  |  | $ | 79,806 |  |
  (was, 2013-05-10, similarity 0.933):
[0001511737-13-000006:note_history:20]
|  | 2013(remainder) |  | 2014 |  | 2015 |  | 2016 |  | 2017 |  | Thereafter |  | Total |
| Debt payment obligations | $ | 1,250 |  |  | $ | 5,000 |  |  | $ | 6,875 |  |  | $ | 39,375 |  |  | $ | 10,000 |  |  | $ | 15,000 |  |  | $ | 77,500 |  |
| Interest payments on debt payment obligations | 472 |  |  | 1,859 |  |  | 1,723 |  |  | 1,043 |  |  | 532 |  |  | 125 |  |  | 5,754 |  |
| Total | $ | 1,722 |  |  | $ | 6,859 |  |  | $ | 8,598 |  |  | $ | 40,418 |  |  | $ | 10,532 |  |  | $ | 15,125 |  |  | $ | 83,254 |  |

- removed (2013-11-08):
[0001511737-13-000006:note_history:21]
In July 2011, the Company repurchased an aggregate of 12,041,700 shares of the Company’s Series A convertible preferred stock from entities affiliated with Summit Partners, L.P., one of the Company’s major stockholders, at a price of $8.97 per share for an aggregate consideration of $108.0 million. Of the aggregate purchase price, $40.0 million was paid in cash at the time of closing and the balance of the shares were paid for through the issuance of convertible subordinated promissory notes in the aggregate principal amount of $68.0 million. On September 15, 2011, $34.0 million was paid against the notes and was financed through the Company's EWB Loan Agreement (as further described below) reducing the aggregate principal amount outstanding to $34.0 million. The remainder of the notes were retired in October 2011 with the proceeds of the Company’s initial public offering and existing cash balances. The interest rate on the notes started at 5% per annum and increased by two percentage points every three months until it would have reached 9% in January 2012. The notes were prepayable without penalty prior to April 21, 2012, and were required to be paid in the event of the Company’s initial public offering or third party financing prior to April 21, 2012. The notes matured on July 21, 2021. The unpaid principal on the notes was convertible into shares of Series A preferred stock at $8.97 per share at any point after July 21, 2012. The difference between the repurchase price and the carrying value of the repurchased preferred stock on June 30, 2011 was $59.0 million. The difference was debited to available retained earnings with the remaining amount debited to additional paid-in capital and reduced the net income attributable to common stock shareholders resulting in a reduction of basic and diluted net income per share.

- removed (2013-11-08):
[0001511737-13-000006:note_history:22]
On September 15, 2011, the Company entered into a Loan and Security Agreement with East West Bank, (the “EWB Loan Agreement”), which was replaced by the Loan Agreement as discussed below. The credit facilities available under the EWB Loan Agreement consist of a $35.0 million term loan facility and a $5.0 million revolving line of credit facility. The term loan matures on September 15, 2016 with principal and interest to be repaid in 60 monthly installments. The Company used $34.0 million of the term loan to repay a portion of the outstanding convertible subordinated promissory notes held by entities affiliated with Summit Partners, L.P leaving $1.0 million available for borrowing under the term loan facility.

- removed (2013-11-08):
[0001511737-13-000006:note_history:23]
On August 7, 2012, the Company entered into a Loan and Security Agreement (the “Loan Agreement”) with U.S. Bank, as syndication agent, and East West Bank, as administrative agent for the lenders party to the Loan Agreement. The Loan Agreement replaced the EWB Loan Agreement discussed above. The Loan Agreement provides for (i) a $50.0 million revolving credit facility, with a $5.0 million sublimit for the issuance of letters of credit and a $5.0 million sublimit for the making of swingline loan advances (the “Revolving Credit Facility”), and (ii) a $50.0 million term loan facility (the “Term Loan Facility”). The Company may request borrowings under the Revolving Credit Facility until August 7, 2015. On August 7, 2012, the Company borrowed $20.8 million under the Term Loan Facility, and no borrowings remain available for borrowing thereunder.  On November 21, 2012, the Company borrowed $10.0 million under the Revolving Credit Facility. On December 20, 2012, the Company borrowed an additional $20.0 million under the Revolving Credit Facility, and $20.0 million remains available for borrowing thereunder.

- removed (2013-11-08):
[0001511737-13-000006:note_history:24]
During the three and nine months ended March 31, 2013, the Company made aggregate payments of $1.3 million and $3.1 million, respectively, against the loan balance.  As of March 31, 2013, the Company has classified $5.0 million and $72.4 million in short-term and long-term debt, respectively, on its consolidated balance sheet related to the Loan Agreement.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2013-11-08):
[0001511737-13-000021:note_history:25]
The following table summarizes our estimated debt and interest payment obligations as of September 30, 2013 (in thousands):
  (was, 2013-05-10, similarity 0.9569):
[0001511737-13-000006:note_history:25]
The following table summarizes our estimated debt and interest payment obligations as of March 31, 2013 (in thousands):

- changed (2013-11-08):
[0001511737-13-000021:note_history:26]
|  | 2014(remainder) |  | 2015 |  | 2016 |  | 2017 |  | 2018 |  | Total |
| Debt payment obligations | $ | 3,750 |  |  | $ | 6,875 |  |  | $ | 39,375 |  |  | $ | 10,000 |  |  | $ | 15,000 |  |  | $ | 75,000 |  |
| Interest payments on debt payment obligations | 1,383 |  |  | 1,723 |  |  | 1,043 |  |  | 532 |  |  | 125 |  |  | 4,806 |  |
| Total | $ | 5,133 |  |  | $ | 8,598 |  |  | $ | 40,418 |  |  | $ | 10,532 |  |  | $ | 15,125 |  |  | $ | 79,806 |  |
  (was, 2013-05-10, similarity 0.933):
[0001511737-13-000006:note_history:26]
|  | 2013(remainder) |  | 2014 |  | 2015 |  | 2016 |  | 2017 |  | Thereafter |  | Total |
| Debt payment obligations | $ | 1,250 |  |  | $ | 5,000 |  |  | $ | 6,875 |  |  | $ | 39,375 |  |  | $ | 10,000 |  |  | $ | 15,000 |  |  | $ | 77,500 |  |
| Interest payments on debt payment obligations | 472 |  |  | 1,859 |  |  | 1,723 |  |  | 1,043 |  |  | 532 |  |  | 125 |  |  | 5,754 |  |
| Total | $ | 1,722 |  |  | $ | 6,859 |  |  | $ | 8,598 |  |  | $ | 40,418 |  |  | $ | 10,532 |  |  | $ | 15,125 |  |  | $ | 83,254 |  |
