# UI notes — 0001193125-12-463263


## us-gaap:EarningsPerShareTextBlock

[0001193125-12-463263:notes:1]
NOTE 4—EARNINGS
PER SHARE

[0001193125-12-463263:notes:2]
The following table sets
forth the computation of basic and diluted earnings per share for
the periods indicated (in thousands, except per share
data):

[0001193125-12-463263:notes:3]
|  |  | Three Months Ended September 30, |  |
|  |  | 2012 |  |  | 2011 |  |
| Numerator: |  |  |  |  |
| Net income (loss) attributable to common stockholders—basic |  | $ | 13,179 |  |  | $ | (81,234 | ) |
| Net income (loss) attributable to common stockholders—diluted |  | $ | 13,179 |  |  | $ | (81,234 | ) |
| Denominator: |  |  |  |  |
| Weighted-average shares used in computing basic net income (loss) per share |  |  | 90,970 |  |  |  | 62,717 |  |
| Add—dilutive potential common shares: |  |  |  |  |
| Stock options |  |  | 1,807 |  |  |  | — |  |
| Restricted stock units |  |  | 148 |  |  |  | — |  |
| Weighted-average shares used in computing diluted net income (loss) per share |  |  | 92,925 |  |  |  | 62,717 |  |
| Net income (loss) per share of common stock: |  |  |  |  |
| Basic |  | $ | 0.14 |  |  | $ | (1.30 | ) |
| Diluted |  | $ | 0.14 |  |  | $ | (1.30 | ) |

[0001193125-12-463263:notes:4]
The following table
summarizes the total potential shares of common stock that were
excluded from the diluted per share calculation, because to include
them would have been anti-dilutive for the period (in
thousands):

[0001193125-12-463263:notes:5]
|  |  | Three Months Ended September 30, |  |
|  |  | 2012 |  |  | 2011 |  |
| Stock options |  |  | 36 |  |  |  | 6,181 |  |
| Restricted stock units |  |  | 297 |  |  |  | 485 |  |
| Convertible preferred stock |  |  | — |  |  |  | 23,993 |  |
| Shares subject to conversion per convertible promissory note |  |  | — |  |  |  | 3,791 |  |
|  |  |  | 333 |  |  |  | 34,450 |  |


## us-gaap:PropertyPlantAndEquipmentScheduleOfSignificantAcquisitionsAndDisposalsTextBlock

[0001193125-12-463263:notes:6]
Property and equipment, net
consisted of the following (in thousands):

[0001193125-12-463263:notes:7]
|  |  | September 30, 2012 |  |  | June 30, 2012 |  |
| Testing equipment |  | $ | 2,815 |  |  | $ | 2,293 |  |
| Computer and other equipment |  |  | 648 |  |  |  | 578 |  |
| Tooling equipment |  |  | 842 |  |  |  | 532 |  |
| Furniture and fixtures |  |  | 608 |  |  |  | 595 |  |
| Leasehold improvements |  |  | 1,430 |  |  |  | 1,424 |  |
| Software |  |  | 77 |  |  |  | 77 |  |
|  |  |  | 6,420 |  |  |  | 5,499 |  |
| Less: Accumulated depreciation and amortization |  |  | (1,378 | ) |  |  | (1,028 | ) |
|  |  | $ | 5,042 |  |  | $ | 4,471 |  |


## us-gaap:BusinessDescriptionAndBasisOfPresentationTextBlock

[0001193125-12-463263:notes:8]
NOTE 1—BUSINESS
AND BASIS OF PRESENTATION

[0001193125-12-463263:notes:9]
Business—
Ubiquiti Networks, Inc. was incorporated in the State of California
in 2003 as Pera Networks, Inc. and commenced its current operations
in 2005 and changed its name to Ubiquiti Networks, Inc. at that
time. In June 2010, the Company changed its state of incorporation
to Delaware by merging with and into Ubiquiti Networks, Inc., a
Delaware corporation.

[0001193125-12-463263:notes:10]
Ubiquiti Networks, Inc. and
its wholly owned subsidiaries (collectively, “Ubiquiti”
or the “Company”) is a product driven company that
leverages innovative proprietary technologies to deliver networking
solutions to both startup and established network operators and
service providers.

[0001193125-12-463263:notes:11]
On October 13, 2011,
the Company entered into an underwriting agreement for its initial
public offering of its common stock at $15.00 per share, which
closed on October 19, 2011. Immediately prior to the closing
of the initial public offering, all outstanding shares of the
Company’s preferred stock converted to common stock on a one
for one basis.

[0001193125-12-463263:notes:12]
The Company operates on a
fiscal year ending June 30. In this Quarterly Report, the
fiscal year ended June 30, 2013 is referred to as
“fiscal 2013” and the fiscal year ending June 30,
2012 is referred to as “fiscal 2012.”

[0001193125-12-463263:notes:13]
Basis of
Presentation— The accompanying condensed consolidated
financial statements have been prepared in accordance with
accounting principles generally accepted in the United States of
America (“U.S. GAAP”) related to interim financial
statements based on applicable Securities and Exchange Commission
(“SEC”) rules and regulations. Accordingly, they do not
include all the information and footnotes required by U.S. GAAP for
complete financial statements. This information reflects all
adjustments, which are, in the opinion of the Company, of a normal
and recurring nature and necessary to state fairly the statements
of financial position, results of operations and cash flows for the
dates and periods presented. The June 30, 2012 balance sheet
was derived from the audited financial statements as of that date.
All significant intercompany transactions and balances have been
eliminated.

[0001193125-12-463263:notes:14]
These condensed
consolidated financial statements should be read in conjunction
with the Company’s audited consolidated financial statements
for the fiscal year ended June 30, 2012 included in its Annual
Report on Form 10-K, as filed on September 28, 2012 with the
SEC (the “Annual Report”). The results of operations
for the three months ended September 30, 2012 are not
necessarily indicative of the results to be expected for any future
periods.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001193125-12-463263:notes:15]
NOTE 13—INCOME
TAXES

[0001193125-12-463263:notes:16]
As of September 30,
2012, the Company had approximately $8.4 million of unrecognized
tax benefits, substantially all of which would, if recognized,
affect its tax expense. The Company has elected to include interest
and penalties related to uncertain tax positions as a component of
tax expense. At September 30, 2012, an insignificant amount of
interest and penalties are included in long-term income tax
payable. The Company recorded an increase of its unrecognized tax
benefits of $607,000 for the three months ended September 30,
2012. The Company does not expect any significant increases or
decreases to its unrecognized tax benefits in the next twelve
months.

[0001193125-12-463263:notes:17]
The Company recorded a tax
provision of $2.5 million for the three months ended
September 30, 2012. The Company’s estimated 2012
effective tax rate differs from the U.S. statutory rate primarily
due to profits earned in jurisdictions where the tax rate is lower
than the U.S. tax rate.

[0001193125-12-463263:notes:18]
The Company files U.S.
federal income tax returns as well as income tax returns in various
states and foreign jurisdictions. The Company’s tax years
from 2009 and onwards could be subject to examinations by tax
authorities.


## us-gaap:FairValueDisclosuresTextBlock

[0001193125-12-463263:notes:19]
NOTE 3—FAIR VALUE
OF FINANCIAL INSTRUMENTS

[0001193125-12-463263:notes:20]
Pursuant to the accounting
guidance for fair value measurements and its subsequent updates,
fair value is defined as the price that would be received from
selling an asset or paid to transfer a liability in an orderly
transaction between market participants at the measurement date. As
such, fair value is a market-based measurement that should be
determined based on assumptions that market participants would use
in pricing an asset or liability. The accounting guidance
establishes a three-tier fair value hierarchy that requires the
Company to use observable market data, when available, and to
minimize the use of unobservable inputs when determining fair
value. The fair value hierarchy prioritizes the inputs into three
levels that may be used in measuring fair value as
follows:

[0001193125-12-463263:notes:21]
Level
1—observable inputs which include quoted prices in active
markets for identical assets of liabilities.

[0001193125-12-463263:notes:22]
Level 2—inputs
which include observable inputs other than Level 1, such as quoted
prices for similar assets or liabilities, quoted prices for
identical or similar assets or liabilities in markets that are not
active, or other inputs that are observable or can be corroborated
by observable market data for substantially the full term of the
asset or liability.

[0001193125-12-463263:notes:23]
Level 3—inputs
which include unobservable inputs that are supported by little or
no market activity and that are significant to the fair value of
the underlying asset or liability. Level 3 assets and liabilities
include those whose fair value measurements are determined using
pricing models, discounted cash flow methodologies or similar
valuation techniques, as well as significant management judgment or
estimation.

[0001193125-12-463263:notes:24]
The Company’s
financial assets at September 30, 2012 and June 30, 2012
included money market funds which were valued based on quoted
prices in active markets for substantially similar assets and,
therefore, were Level 1 instruments. Additionally, at
September 30, 2012 the Company had debt associated with its
Loan and Security Agreement with East West Bank (See Note 8). The
fair value of the Company’s debt was estimated based on the
current rates offered to the Company for debt with the same
remaining maturities.

[0001193125-12-463263:notes:25]
As of September 30,
2012 and June 30, 2012, the fair value hierarchy for the
Company’s financial assets and financial liabilities was as
follows (in thousands):

[0001193125-12-463263:notes:26]
|  |  | September 30, 2012 |  |  | June 30, 2012 |  |
|  |  | Fair Value |  |  | Level 1 |  |  | Level 2 |  |  | Level 3 |  |  | Fair Value |  |  | Level 1 |  |  | Level 2 |  |  | Level 3 |  |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 118,306 |  |  | $ | 118,306 |  |  | $ | — |  |  | $ | — |  |  | $ | 108,228 |  |  | $ | 108,228 |  |  | $ | — |  |  | $ | — |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Debt |  | $ | 49,851 |  |  | $ | — |  |  | $ | 49,851 |  |  | $ | — |  |  | $ | 29,591 |  |  | $ | — |  |  | $ | 29,591 |  |  | $ | — |  |


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001193125-12-463263:notes:27]
NOTE 6—BALANCE
SHEET COMPONENTS

[0001193125-12-463263:notes:28]
[same as prior period, unchanged from 0001193125-12-201585:notes:153]

[0001193125-12-463263:notes:29]
Inventories consisted of
the following (in thousands):

[0001193125-12-463263:notes:30]
|  |  | September 30, 2012 |  |  | June 30, 2012 |  |
| Raw materials |  | $ | 5,026 |  |  | $ | 4,668 |  |
| Finished goods |  |  | 2,606 |  |  |  | 3,066 |  |
|  |  | $ | 7,632 |  |  | $ | 7,734 |  |

[0001193125-12-463263:notes:31]
Prepaid Expenses and
Other Current Assets

[0001193125-12-463263:notes:32]
Prepaid expenses and other
current assets consisted of the following (in
thousands):

[0001193125-12-463263:notes:33]
|  |  | September 30, 2012 |  |  | June 30, 2012 |  |
| Vendor deposits |  | $ | 875 |  |  | $ | 129 |  |
| Other current assets |  |  | 1,553 |  |  |  | 1,448 |  |
|  |  | $ | 2,428 |  |  | $ | 1,577 |  |

[0001193125-12-463263:notes:34]
Property and
Equipment, Net

[0001193125-12-463263:notes:35]
Other Long-term
Assets

[0001193125-12-463263:notes:36]
Other long-term assets
consisted of the following (in thousands):

[0001193125-12-463263:notes:37]
|  |  | September 30, 2012 |  |  | June 30, 2012 |  |
| Intangible assets, net |  | $ | 780 |  |  | $ | 748 |  |
| Other long-term assets |  |  | 797 |  |  |  | 388 |  |
|  |  | $ | 1,577 |  |  | $ | 1,136 |  |

[0001193125-12-463263:notes:38]
Other Current
Liabilities

[0001193125-12-463263:notes:39]
Accrued liabilities
consisted of the following (in thousands):

[0001193125-12-463263:notes:40]
|  |  | September 30, 2012 |  |  | June 30, 2012 |  |
| Accrued compensation and benefits |  | $ | 2,753 |  |  | $ | 2,657 |  |
| Accrued accounts payable |  |  | 265 |  |  |  | 6,636 |  |
| Accrual for an export compliance matter |  |  | 1,625 |  |  |  | 1,625 |  |
| Warranty accrual |  |  | 1,765 |  |  |  | 1,381 |  |
| Other accruals |  |  | 3,623 |  |  |  | 4,732 |  |
|  |  | $ | 10,031 |  |  | $ | 17,031 |  |


## us-gaap:ScheduleOfShareBasedPaymentAwardEmployeeStockPurchasePlanValuationAssumptionsTableTextBlock

[0001193125-12-463263:notes:41]
2011, the fair value of
employee stock options was estimated using the following weighted
average assumptions:

[0001193125-12-463263:notes:42]
|  |  | Three Months Ended September 30, 2011 |  |
| Expected term |  |  | 6.1 years |  |
| Expected volatility |  |  | 49 | % |
| Risk-free interest rate |  |  | 1.8 | % |
| Expected dividend yield |  |  | — |  |
| Weighted average grant date fair value |  | $ | 4.03 |  |


## us-gaap:PreferredStockTextBlock

[0001193125-12-463263:notes:43]
NOTE 10—PREFERRED
STOCK

[0001193125-12-463263:notes:44]
Preferred
Stock

[0001193125-12-463263:notes:45]
In July 2011, the Company
repurchased an aggregate of 12,041,700 shares of the
Company’s Series A convertible preferred stock from entities
affiliated with Summit Partners, L.P., one of the Company’s
major stockholders, at a price of $8.97 per share for an aggregate
consideration of $108.0 million. Of the aggregate purchase price,
$40.0 million was paid in cash at the time of closing and the
balance of the shares were paid for through the issuance of
convertible subordinated promissory notes in the aggregate
principal amount of $68.0 million. The $68.0 million was paid down
primarily using proceeds from the EWB Loan Agreement and the
remaining balance was subsequently paid down by funds raised upon
the completion of the Company’s initial public offering on
October 19, 2011 and the Company’s existing cash
balances.


## us-gaap:DebtDisclosureTextBlock

[0001193125-12-463263:notes:46]
NOTE
8—DEBT

[0001193125-12-463263:notes:47]
In July 2011, the Company
repurchased an aggregate of 12,041,700 shares of the
Company’s Series A convertible preferred stock from entities
affiliated with Summit Partners, L.P., one of the Company’s
major stockholders, at a price of $8.97 per share for an aggregate
consideration of $108.0 million. Of the aggregate purchase price,
$40.0 million was paid in cash at the time of closing and the
balance of the shares were paid for through the issuance of
convertible subordinated promissory notes in the aggregate
principal amount of $68.0 million. On September 15, 2011,
$34.0 million was paid against the notes reducing the aggregate
principal amount outstanding to $34.0 million. The remainder of the
notes were retired in October 2011 with the proceeds of the
Company’s initial public offering and existing cash balances.
The interest rate on the notes started at 5% per annum and
increased by two percentage points every three months until it
would have reached 9% in January 2012. The notes were prepayable
without penalty prior to April 21, 2012, and were required to
be paid in the event of the Company’s initial public offering
or third party financing prior to April 21, 2012. The notes
matured on July 21, 2021. The unpaid principal on the notes
was convertible into shares of Series A preferred stock at $8.97
per share at any point after July 21, 2012. The difference
between the repurchase price and the carrying value of the
repurchased preferred stock on June 30, 2011 was $59.0
million. The difference was debited to available retained earnings
with the remaining amount debited to additional paid-in capital and
reduced the net income attributable to common stock shareholders
resulting in a reduction of basic and diluted net income per
share.

[0001193125-12-463263:notes:48]
On September 15, 2011,
the Company entered into a Loan and Security Agreement with East
West Bank, (the “EWB Loan Agreement”). The credit
facilities available under the EWB Loan Agreement consist of a
$35.0 million term loan facility and a $5.0 million revolving line
of credit facility. The term loan matures on September 15,
2016 with principal and interest to be repaid in 60 monthly
installments. The Company used $34.0 million of the term loan to
repay a portion of the outstanding convertible subordinated
promissory notes held by entities affiliated with Summit Partners,
L.P. leaving an aggregate amount owed under the promissory note of
$34.0 million. The $5.0 million revolving line of credit may be
drawn at any time prior to September 15, 2013. The amounts
outstanding under both the term loan and the revolving line of
credit facility may be voluntarily prepaid at any time without
premium or penalty, subject to certain conditions. Interest will
accrue on the outstanding principal amount of the term loan at a
rate per annum equal to an adjusted LIBOR rate (based on one, two
or three month interest periods) plus a spread of either 2.50% or
3.00%, which spread shall be determined based on the debt service
ratio for the preceding four fiscal quarter period. Interest will
accrue on the drawn portion of the revolving credit facility at the
prime rate plus a spread of 0.25%, provided that such rate shall
not be less than the one-month adjusted LIBOR rate plus a spread of
1.00%, and will be paid monthly. The Company is required to pay a
commitment fee of 0.15% per annum on the undrawn portion of
the revolving credit facility on a quarterly basis. The EWB Loan
Agreement includes customary covenants, including financial
reporting requirements and compliance with a debt service coverage
ratio and a total leverage ratio, and customary events of default.
The Company’s obligations under the EWB Loan Agreement are
secured by a first priority security position on substantially all
of the Company’s current and future assets, subject to
certain exceptions (including a negative pledge on the
Company’s intellectual property) and permitted
liens.

[0001193125-12-463263:notes:49]
Additionally, on
August 7, 2012, the Company entered into a Loan and Security
Agreement (the “Loan Agreement”) with U.S. Bank, as
syndication agent, and East West Bank, as administrative agent. The
Loan Agreement replaces the EWB Loan Agreement as discussed above.
The Loan Agreement provides for (i) a $50.0 million revolving
credit facility, with a $5.0 million sublimit for the issuance of
letters of credit and a $5.0 million sublimit for the making of
swingline loan advances (the “Revolving Credit
Facility”), and (ii) a $50.0 million term loan facility
(the “Term Loan Facility”). The Company may request
borrowings under the Revolving Credit Facility until August 7,
2015. On August 7, 2012, the Company borrowed an additional
$20.8 million of term loans under the Term Loan
Facility.

[0001193125-12-463263:notes:50]
The loans bear interest, at
the Company’s option, at the base rate plus a spread of 1.25%
to 1.75% or an adjusted LIBOR rate (based, at the Company’s
election, on a period of 30, 60, or 90 days) plus a spread of 2.25%
to 2.75%, in each case with such spread being determined based on
the debt service coverage ratio for the last fiscal quarter. The
base rate means the highest of East West Bank’s prime rate,
the federal funds rate plus a margin equal to 0.50%, or the
adjusted LIBOR rate for a period of 30, 60, or 90 days plus a
margin equal to 1.00%. The Company is also obligated to pay other
customary closing fees, arrangement fees, administration fees,
commitment fees and letter of credit fees for a credit facility of
this size and type.

[0001193125-12-463263:notes:51]
Interest is due and payable
in arrears monthly in the case of loans bearing interest at the
base rate and at the end of an interest period (or quarterly in the
case of loans with interest periods greater than three months) in
the case of loans bearing interest at the adjusted LIBOR rate.
Principal payments under the Term Loan Facility will be made in
quarterly installments, each such quarterly installment shall be
equal to $1.25 million until August 7, 2014, then equal to
$1.875 million until August 7, 2015, and then equal to $2.5
million until August 7, 2017, subject to adjustment as a
result of any prepayments, with the remaining outstanding principal
balance and all accrued and unpaid interest due on August 7,
2017. All outstanding loans under the Revolving Credit Facility,
together with all accrued and unpaid interest, are due on
August 7, 2015.

[0001193125-12-463263:notes:52]
The Company may prepay the
loans, in whole or in part, at any time without premium or penalty,
subject to certain conditions including minimum amounts and
reimbursement of certain costs in the case of prepayments of LIBOR
loans. In addition, the Company is required to prepay the loan
under the Term Loan Facility with the proceeds from certain
financing transactions or asset sales (subject, in the case of
asset sales, to reinvestment rights) and with 25.0% of the
Company’s excess cash flow, as determined after each fiscal
year and in accordance with the Loan Agreement, provided that the
Company shall not be required to prepay the loan out of its excess
cash flow if its leverage ratio is greater than 1.50:1.00 on the
last day of such fiscal year.

[0001193125-12-463263:notes:53]
All of the obligations
under the Loan Agreement are secured by substantially all of the
Company’s assets, including all of the capital stock of the
Company’s future domestic subsidiaries and 65% of the capital
stock of the Company’s existing and future foreign
subsidiaries, but excluding the Company’s intellectual
property. All of the Company’s future domestic subsidiaries
are required to guaranty the obligations under the Loan Agreement.
Such guarantees by future subsidiaries will be secured by
substantially all of the property of such subsidiaries, excluding
intellectual property.

[0001193125-12-463263:notes:54]
The Loan Agreement contains
customary affirmative and negative covenants, including covenants
that limit or restrict the Company and its subsidiaries’
ability to, among other things, incur indebtedness, grant liens,
merge or consolidate, dispose of assets, pay dividends or make
distributions, make investments, make acquisitions, prepay certain
indebtedness, change the nature of its business, enter into certain
transactions with affiliates, enter into restrictive agreements,
and make capital expenditures, in each case subject to customary
exceptions for a credit facility of this size and type. The Company
is also required to maintain compliance with a debt service
coverage ratio, a leverage ratio, and a minimum level of
liquidity.

[0001193125-12-463263:notes:55]
The Loan Agreement includes
customary events of default that, include among other things,
non-payment defaults, defaults due to the inaccuracy of
representations and warranties, covenant defaults, cross default to
material indebtedness, bankruptcy and insolvency defaults, material
judgment defaults, defaults due to the unenforceability of a
guaranty, and defaults due to circumstances that have or could have
a material adverse effect. The occurrence of an event of default
could result in the acceleration of the obligations under the Loan
Agreement. During the existence of an event of default, interest on
the obligations under the Loan Agreement could be increased by
2.00% above the otherwise applicable interest rate.

[0001193125-12-463263:notes:56]
During the three months
ended September 30, 2012, the Company made aggregate payments
of $583,000 against the loan balance. As of September 30,
2012, the Company has classified $5.0 million and $44.8 million in
short-term and long-term debt, respectively, on its consolidated
balance sheet related to the Loan Agreement.

[0001193125-12-463263:notes:57]
The following table
summarizes our estimated debt and interest payment obligations as
of September 30, 2012 (in thousands):

[0001193125-12-463263:notes:58]
|  |  | 2013 (remainder) |  |  | 2014 |  |  | 2015 |  |  | 2016 |  |  | 2017 |  |  | Thereafter |  |  | Total |  |
| Debt payment obligations |  | $ | 3,750 |  |  | $ | 5,000 |  |  | $ | 6,875 |  |  | $ | 9,375 |  |  | $ | 10,000 |  |  | $ | 15,000 |  |  | $ | 50,000 |  |
| Interest payments on debt payment obligations |  |  | 914 |  |  |  | 1,110 |  |  |  | 973 |  |  |  | 777 |  |  |  | 531 |  |  |  | 172 |  |  |  | 4,477 |  |
| Total |  | $ | 4,664 |  |  | $ | 6,110 |  |  | $ | 7,848 |  |  | $ | 10,152 |  |  | $ | 10,531 |  |  | $ | 15,172 |  |  | $ | 54,477 |  |


## us-gaap:ScheduleOfFutureMinimumRentalPaymentsForOperatingLeasesTableTextBlock

[0001193125-12-463263:notes:59]
At September 30, 2012,
future minimum annual payments under operating leases are as
follows (in thousands):

[0001193125-12-463263:notes:60]
|  |  | 2013 (remainder) |  |  | 2014 |  |  | 2015 |  |  | 2016 |  |  | 2017 |  |  | Thereafter |  |  | Total |  |
| Operating leases |  | $ | 1,078 |  |  | $ | 1,384 |  |  | $ | 1,396 |  |  | $ | 1,428 |  |  | $ | 1,122 |  |  | $ | — |  |  | $ | 6,408 |  |


## us-gaap:ScheduleOfShareBasedCompensationStockOptionsActivityTableTextBlock

[0001193125-12-463263:notes:61]
The following is a summary
of option activity for the Company’s stock incentive plans
for the three months ended September 30, 2012:

[0001193125-12-463263:notes:62]
|  |  | Common Stock Options Outstanding |  |
|  |  | Number of Shares |  |  | Weighted Average Exercise Price |  |  | Weighted Average Remaining Contractual Life (Years) |  |  | Aggregate Intrinsic Value |  |
|  |  |  |  |  |  |  |  |  |  |  | (In thousands) |  |
| Balance, June 30, 2012 |  |  | 3,347,445 |  |  |  | 1.45 |  |  |  |  |  |  |  |  |  |
| Granted |  |  | — |  |  |  | — |  |  |  |  |  |  |  |  |  |
| Exercised |  |  | (29,705 | ) |  |  | 3.42 |  |  |  |  |  |  |  |  |  |
| Forfeitures and cancellations |  |  | (11,803 | ) |  |  | 5.53 |  |  |  |  |  |  |  |  |  |
| Balance, September 30, 2012 |  |  | 3,305,937 |  |  | $ | 1.42 |  |  |  | 6.34 |  |  | $ | 34,809 |  |
| Vested and expected to vest as of September 30, 2012 |  |  | 3,274,056 |  |  | $ | 1.39 |  |  |  | 6.32 |  |  | $ | 34,570 |  |
| Vested and exercisable as of September 30, 2012 |  |  | 2,563,713 |  |  | $ | 0.63 |  |  |  | 5.83 |  |  | $ | 28,903 |  |


## us-gaap:ScheduleOfCashAndCashEquivalentsTableTextBlock

[0001193125-12-463263:notes:63]
Cash and cash equivalents
consisted of the following (in thousands):

[0001193125-12-463263:notes:64]
|  |  | September 30, 2012 |  |  | June 30, 2012 |  |
| Cash |  | $ | 14,180 |  |  | $ | 13,832 |  |
| Money market funds |  |  | 118,306 |  |  |  | 108,228 |  |
|  |  | $ | 132,486 |  |  | $ | 122,060 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001193125-12-463263:notes:65]
NOTE 12—STOCK
BASED COMPENSATION

[0001193125-12-463263:notes:66]
Stock-Based
Compensation Plans

[0001193125-12-463263:notes:67]
The Company’s 2010
Equity Incentive Plan and 2005 Equity Incentive Plan are described
in its Annual Report. As of September 30, 2012, the Company
had 1,414,579 authorized shares available for future issuance under
all of its stock incentive plans.

[0001193125-12-463263:notes:68]
Employee Stock-based
Compensation

[0001193125-12-463263:notes:69]
The following table shows
total stock-based compensation expense included in the Condensed
Consolidated Statements of Operations for the months ended
September 30, 2012 and 2011 (in thousands):

[0001193125-12-463263:notes:70]
|  |  | Three Months Ended September 30, |  |
|  |  | 2012 |  |  | 2011 |  |
| Cost of sales |  | $ | 81 |  |  | $ | 6 |  |
| Research and development |  |  | 266 |  |  |  | 116 |  |
| Sales, general and administrative |  |  | 309 |  |  |  | 229 |  |
|  |  | $ | 656 |  |  | $ | 351 |  |

[0001193125-12-463263:notes:71]
Stock
Options

[0001193125-12-463263:notes:72]
During the three months
ended September 30, 2012 and 2011, the aggregate intrinsic
value of options exercised under the Company’s stock
incentive plans was $178,000 and $397,000, respectively, as
determined as of the date of option exercise.

[0001193125-12-463263:notes:73]
As of September 30,
2012, the Company had unrecognized compensation costs of
$1.6 million related to stock options which the Company
expects to recognize over a weighted-average period of 2.4 years.
Future option grants will increase the amount of compensation
expense to be recorded in these periods.

[0001193125-12-463263:notes:74]
The Company estimates the
fair value of employee stock options using the Black-Scholes option
pricing model. The fair value of employee stock options is being
amortized on a straight-line basis over the requisite service
period of the awards. The Company did not grant any employee stock
options during the three months ended September 30, 2012. For
the three months ended September 30, 2011, the fair value of
employee stock options was estimated using the following weighted
average assumptions:

[0001193125-12-463263:notes:75]
Restricted Stock Units
(“RSUs”)

[0001193125-12-463263:notes:76]
The following table
summarizes the activity of the RSUs made by the Company:

[0001193125-12-463263:notes:77]
|  |  | Number of Shares |  |  | Weighted Average Grant Date Fair Value |  |
| Non-vested RSUs, June 30, 2012 |  |  | 453,620 |  |  | $ | 9.42 |  |
| RSUs granted |  |  | 257,500 |  |  |  | 13.86 |  |
| RSUs vested |  |  | (7,290 | ) |  |  | 12.14 |  |
| RSUs cancelled |  |  | (10,000 | ) |  |  | 28.78 |  |
| Non-vested RSUs, September 30, 2012 |  |  | 693,830 |  |  | $ | 10.76 |  |

[0001193125-12-463263:notes:78]
The intrinsic value of RSUs
vested in the three months ended September 30, 2012 and 2011
was $91,000 and $25,000, respectively. The total intrinsic value of
all outstanding RSUs was $8.3 million as of September 30,
2012.

[0001193125-12-463263:notes:79]
As of September 30,
2012, there was unrecognized compensation costs related to RSUs of
$6.2 million which the Company expects to recognize over a weighted
average period of 3.8 years.


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001193125-12-463263:notes:80]
NOTE 7—ACCRUED
WARRANTY

[0001193125-12-463263:notes:81]
The Company offers
warranties on certain products, generally for a period of one year,
and records a liability for the estimated future costs associated
with potential warranty claims. The warranty costs are reflected in
the Company’s consolidated statement of operations within
cost of revenues. The warranties are typically in effect for 12
months from the distributor’s purchase date of the product.
The Company’s estimate of future warranty costs is largely
based on historical experience factors including product failure
rates, material usage, and service delivery cost incurred in
correcting product failures. In certain circumstances, the Company
may have recourse from its contract manufacturers for replacement
cost of defective products, which it also factors into its warranty
liability assessment.

[0001193125-12-463263:notes:82]
Warranty obligations,
included in other current liabilities, were as follows (in
thousands):

[0001193125-12-463263:notes:83]
|  |  | Three Months Ended September 30, |  |
|  |  | 2012 |  |  | 2011 |  |
| Beginning balance |  | $ | 1,381 |  |  | $ | 806 |  |
| Accruals for warranties issued during the period |  |  | 958 |  |  |  | 519 |  |
| Warranty costs incurred during the period |  |  | (574 | ) |  |  | (326 | ) |
|  |  | $ | 1,765 |  |  | $ | 999 |  |


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001193125-12-463263:notes:84]
Recent Accounting
Pronouncements

[0001193125-12-463263:notes:85]
The Company does not
believe there have been any recent accounting pronouncements that
would have a significant impact on the Company’s financial
statements.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001193125-12-463263:notes:86]
NOTE 9—COMMITMENTS
AND CONTINGENCIES

[0001193125-12-463263:notes:87]
Operating
Leases

[0001193125-12-463263:notes:88]
Certain facilities and
equipment are leased under noncancelable operating leases. The
Company generally pays taxes, insurance and maintenance costs on
leased facilities and equipment. The Company leases office space in
San Jose, California and other locations under various
non-cancelable operating leases that expire at various dates
through 2017.

[0001193125-12-463263:notes:89]
In December 2011, the
Company entered into an agreement to lease approximately 64,512
square feet of office and research and development space located in
San Jose, California, which will be used as the Company’s
corporate headquarters. The lease term is from April 1, 2012,
through June 30, 2017. The lease has been categorized as an
operating lease, and the total estimated rent expense to be
recognized is $4.9 million.

[0001193125-12-463263:notes:90]
Purchase
Commitments

[0001193125-12-463263:notes:91]
The Company subcontracts
with other companies to manufacture its products. During the normal
course of business, the Company’s contract manufacturers
procure components based upon orders placed by the Company. If the
Company cancels all or part of the orders, it may still be liable
to the contract manufacturers for the cost of the components
purchased by them to manufacture the Company’s products. The
Company periodically reviews the potential liability and to date no
accruals have been recorded. The Company’s consolidated
financial position and results of operations could be negatively
impacted if it were required to compensate the contract
manufacturers for any liabilities incurred.

[0001193125-12-463263:notes:92]
Indemnification
Obligations

[0001193125-12-463263:notes:93]
The Company enters into
standard indemnification agreements with many of its business
partners in the ordinary course of business. These agreements
include provisions for indemnifying the business partner against
any claim brought by a third party to the extent any such claim
alleges that a Ubiquiti product infringes a patent, copyright or
trademark, or violates any other proprietary rights of that third
party. The maximum potential amount of future payments the Company
could be required to make under these indemnification agreements is
not estimable and the Company has not incurred any material costs
to defend lawsuits or settle claims related to these
indemnification agreements to date.

[0001193125-12-463263:notes:94]
Legal
Matters

[0001193125-12-463263:notes:95]
The Company may be
involved, from time to time, in a variety of claims, lawsuits,
investigations, and proceedings relating to contractual disputes,
intellectual property rights, employment matters, regulatory
compliance matters and other litigation matters relating to various
claims that arise in the normal course of business. The Company
determines whether an estimated loss from a contingency should be
accrued by assessing whether a loss is deemed probable and can be
reasonably estimated. The Company assesses its potential liability
by analyzing specific litigation and regulatory matters using
available information. The Company develops its views on estimated
losses in consultation with inside and outside counsel, which
involves a subjective analysis of potential results and outcomes,
assuming various combinations of appropriate litigation and
settlement strategies. Because of the uncertainties related to both
the amount and ranges of possible loss from pending litigation
matters, the Company is unable to predict with certainty the
precise liability that could finally result from a range of
possible unfavorable outcomes. Taking all of the above factors into
account, the Company records an amount where it is probable that
the Company will incur a loss and where that loss can be reasonably
estimated. However, the Company’s estimates may be incorrect
and the Company could ultimately incur more or less than the
amounts initially recorded. Litigation can be costly, diverting
management’s attention and could, upon resolution, have a
material adverse effect on the Company’s business, results of
operations, financial condition, and cash flows.

[0001193125-12-463263:notes:96]
Export Compliance
Matters

[0001193125-12-463263:notes:97]
In January 2011, the U.S.
Commerce Department, Bureau of Industry and Security’s
(“BIS”) Office of Export Enforcement
(“OEE”) contacted the Company to request that the
Company provide information related to its relationship with a
logistics company in the UAE and with a company in Iran, as well as
information on the export classification of its products. As a
result of this inquiry the Company, assisted by outside counsel,
conducted a review of the Company’s export transactions from
2008 through March 2011 to not only gather information responsive
to the OEE’s request but also to review the Company’s
overall compliance with export control and sanctions laws. It was
in the course of this review that the Company identified the
Iranian sales of two of its distributors.

[0001193125-12-463263:notes:98]
In May 2011, the Company
filed a self-disclosure with the BIS and Security’s Office of
Export Enforcement OEE and in June 2011, filed one with U.S.
Department of the Treasury’s Office of Foreign Asset Control
(“OFAC”) regarding the compliance issues noted above.
The disclosures address the above described findings and the
remedial actions the Company had taken to date. However, the
findings also indicate that both distributors continued to sell,
directly or indirectly, the Company’s products into Iran
during the period from February 2010 through March 2011 and that
the Company received various communications from them indicating
that they were continuing to do so. Since January 2011, the Company
has cooperated with OEE and, prior to its disclosure filing, the
Company informally shared with the OEE the substance of its
findings with respect to both distributors. From May 2011 to August
2011, the Company provided additional information regarding its
review and its findings to OEE to facilitate its investigation and
OEE advised the Company in August 2011 that it had completed its
investigation of the Company. In August 2011, the Company received
a warning letter from OEE stating that OEE had not referred the
findings of the Company’s review for criminal or
administrative prosecution of us and closed the investigation of
the Company without penalty.

[0001193125-12-463263:notes:99]
OFAC is still reviewing the
Company’s voluntary disclosure. In the Company’s
submission, the Company provided OFAC with an explanation of the
activities that led to the sales of its products in Iran and the
failure to comply with the Export Administration Regulations (the
“EAR”) and OFAC sanctions. Although the Company’s
OFAC and OEE voluntary disclosures covered similar sets of facts,
which led the OEE to resolve the case with the issuance of a
warning letter, OFAC may conclude that the Company’s actions
resulted in violations of U.S. export control and economic
sanctions laws and warrant the imposition of penalties that could
include fines, termination of the Company’s ability to export
its products, and/or referral for criminal prosecution. Any such
fines may be material to the Company’s financial results in
the period in which they are imposed. The penalties may be imposed
against the Company and/or its management. The maximum civil
monetary penalty for the violations is up to $250,000 or twice the
value of the transaction, whichever is greater, per violation. The
Company cannot predict when OFAC will complete its review or decide
upon the imposition of possible penalties.

[0001193125-12-463263:notes:100]
Based on the facts known to
the Company to date, the Company recorded an expense of $1.6
million for this export compliance matter in fiscal 2010, which
represents management’s estimated exposure for fines in
accordance with applicable accounting literature. This amount was
calculated from information discovered through the Company’s
internal review and this loss is deemed to be probable and
reasonably estimable. However, the Company also believes that it is
reasonably possible that the loss may be higher, but the Company
cannot reasonably estimate the range of any further potential
losses. Specific information has come to management’s
attention and as such management cannot estimate any further range
of possible losses. Should additional facts be discovered in the
future and/or should actual fines or other penalties substantially
differ from the Company’s estimates, its business, financial
condition, cash flows and results of operations would be materially
negatively impacted.

[0001193125-12-463263:notes:101]
Shareholder Class
Action Lawsuits

[0001193125-12-463263:notes:102]
Beginning on
September 7, 2012, two shareholder class action complaints
were filed against the Company, certain of its officers and
directors and the underwriters of the Company’s initial
public offering in the United States District Court for the
Northern District of California. The complaints purport to
bring claims under the Securities Act of 1933, the Securities
Exchange Act of 1934 and SEC Rule 10b-5 on behalf a class of
purchasers of the Company’s common stock from
October 14, 2011 through August 9, 2012 and/or who
acquired the Company’s stock pursuant to or traceable to the
registration statement for the initial public offering. The
complaints seek, among other things, compensatory damages,
rescission, and attorneys’ fees and costs.

[0001193125-12-463263:notes:103]
The Company believes that
the allegations in the complaints are without merit and intend to
vigorously contest the litigation. However, there can be no
assurance that the Company will be successful in its defense. The
Company cannot currently estimate the loss or the range of possible
losses it may experience in connection with this
litigation.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001193125-12-463263:notes:104]
NOTE 14—SEGMENT
INFORMATION, REVENUES BY GEOGRAPHY AND SIGNIFICANT
CUSTOMERS

[0001193125-12-463263:notes:105]
Revenues by product type
were as follows (in thousands, except percentages):

[0001193125-12-463263:notes:106]
|  |  | Three Months Ended September 30, |  |
|  |  | 2012 |  |  | 2011 |  |
| airMAX |  | $ | 32,057 |  |  |  | 52 | % |  | $ | 49,835 |  |  |  | 63 | % |
| New platforms |  |  | 15,628 |  |  |  | 25 | % |  |  | 2,734 |  |  |  | 4 | % |
| Other systems |  |  | 3,784 |  |  |  | 6 | % |  |  | 12,765 |  |  |  | 16 | % |
| Systems |  |  | 51,469 |  |  |  | 83 | % |  |  | 65,334 |  |  |  | 83 | % |
| Embedded radio |  |  | 1,714 |  |  |  | 3 | % |  |  | 3,225 |  |  |  | 4 | % |
| Antennas/other |  |  | 8,352 |  |  |  | 14 | % |  |  | 10,608 |  |  |  | 13 | % |
| Total revenues |  | $ | 61,535 |  |  |  | 100 | % |  | $ | 79,167 |  |  |  | 100 | % |

[0001193125-12-463263:notes:107]
The Company generally
forwards products directly from its manufacturers to its
distributors in Hong Kong, who in turn ship to other locations
throughout the world. The Company has determined the geographical
distribution of product revenues based upon the ship-to
destinations.

[0001193125-12-463263:notes:108]
Revenues by geography were
as follows (in thousands, except percentages):

[0001193125-12-463263:notes:109]
|  |  | Three Months Ended September 30, |  |
|  |  | 2012 |  |  | 2011 |  |
| North America(1) |  | $ | 20,361 |  |  |  | 33 | % |  | $ | 24,941 |  |  |  | 32 | % |
| South America |  |  | 10,243 |  |  |  | 17 | % |  |  | 19,835 |  |  |  | 25 | % |
| Europe, the Middle East and Africa |  |  | 23,144 |  |  |  | 37 | % |  |  | 24,783 |  |  |  | 31 | % |
| Asia Pacific |  |  | 7,787 |  |  |  | 13 | % |  |  | 9,608 |  |  |  | 12 | % |
| Total revenues |  | $ | 61,535 |  |  |  | 100 | % |  | $ | 79,167 |  |  |  | 100 | % |

[0001193125-12-463263:notes:110]
| (1) | Revenue for the United States was $19.3 million and $24.4 million for the three months ended September 30, 2012 and 2011, respectively. |

[0001193125-12-463263:notes:111]
Customers with an accounts
receivable balance of 10% or greater of total accounts receivable
and customers with net revenues of 10% or greater of total revenues
are presented below for the periods indicated (in thousands, except
percentages):

[0001193125-12-463263:notes:112]
|  |  | Percentage of Revenues |  |  | Percentage of Accounts Receivable |  |
|  |  | Three Months Ended September 30, |  |  | September 30, |  |  | June 30, |  |
|  |  | 2012 |  |  | 2011 |  |  | 2012 |  |  | 2012 |  |
| Distributor A |  |  | 15 | % |  |  | 18 | % |  |  | 14 | % |  |  | 11 | % |
| Distributor B |  |  | * |  |  |  | 16 | % |  |  | 12 | % |  |  | 19 | % |
| Distributor C |  |  | * |  |  |  | * |  |  |  | 11 | % |  |  | 12 | % |

[0001193125-12-463263:notes:113]
[same as prior period, unchanged from 0001193125-12-201585:notes:84]


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001193125-12-463263:notes:114]
NOTE 2—SUMMARY OF
SIGNIFICANT ACCOUNTING POLICIES

[0001193125-12-463263:notes:115]
The Company’s
significant accounting policies are disclosed in its audited
consolidated financial statements for the year ended June 30,
2012 included in the Annual Report.


## us-gaap:CashAndCashEquivalentsDisclosureTextBlock

[0001193125-12-463263:notes:116]
NOTE 5—CASH AND
CASH EQUIVALENTS


## ubnt:ScheduleOfCommonStockRepurchaseActivityTableTextBlock

[0001193125-12-463263:notes:117]
Common stock repurchase
activity during the three months ended September 30, 2012 was
as follows (in thousands, except share and per share
amounts):

[0001193125-12-463263:notes:118]
| Period |  | Total Number of Shares Purchased |  |  | Average Price Paid per Share |  |  | Dollar Value of Shares that May Yet Be Purchased |  |
| August 13, 2012 – August 31, 2012 |  |  | 2,179,900 |  |  | $ | 8.88 |  |  | $ | 80,599 |  |
| September 1, 2012 – September 30, 2012 |  |  | 992,014 |  |  | $ | 11.93 |  |  | $ | 68,742 |  |
| Total |  |  | 3,171,914 |  |  | $ | 9.83 |  |  | $ | 68,742 |  |


## ubnt:CommonStockAndTreasuryStockDiscloseTextBlock

[0001193125-12-463263:notes:119]
NOTE 11—COMMON
STOCK AND TREASURY STOCK

[0001193125-12-463263:notes:120]
As of September 30,
2012 and June 30, 2012, the authorized capital of the Company
included 150,000,000 shares of common stock. As of
September 30, 2012, 131,165,901 shares of common stock were
issued and 88,914,077 were outstanding. As of June 30, 2012,
131,129,888 shares of common stock were issued and 92,049,978 were
outstanding.

[0001193125-12-463263:notes:121]
Common Stock
Repurchases

[0001193125-12-463263:notes:122]
On August 9, 2012, the
Company announced that its Board of Directors authorized the
Company to repurchase up to $100 million of its common stock. The
share repurchase program commenced Monday, August 13, 2012.
The share repurchase program will be funded from proceeds from the
Loan Agreement as discussed in Note 8 and from existing cash on
hand.
