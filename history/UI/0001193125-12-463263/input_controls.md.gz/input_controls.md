# UI 10-Q controls and the auditor's report


## item_4_controls

[0001193125-12-463263:item_4_controls:1]
Item 4. Controls and Procedures

[0001193125-12-463263:item_4_controls:2]
Evaluation of Disclosure Controls and Procedures

[0001193125-12-463263:item_4_controls:3]
Our management, with the participation of our Chief Executive Officer and our Chief Financial Officer, evaluated the effectiveness of our disclosure controls and procedures as of September 30, 2012.
The term “disclosure controls and procedures,” as defined in Rules 13a-15(e) and 15d-15(e) under the Securities Exchange Act of 1934, as amended (the “Exchange Act”), means controls and other procedures of a company that are
designed to ensure that information required to be disclosed by a company in the reports that it files or submits under the Exchange Act is recorded, processed, summarized and reported, within the time periods specified in the SEC’s rules and
forms. Disclosure controls and procedures include, without limitation, controls and procedures designed to ensure that information required to be disclosed by a company in the reports that it files or submits under the Exchange Act is accumulated
and communicated to the company’s management, including its principal executive and principal financial officers, as appropriate to allow timely decisions regarding required disclosure. Management recognizes that any controls and procedures, no
matter how well designed and operated, can provide only reasonable assurance of achieving their objectives and management necessarily applies its judgment in evaluating the cost-benefit relationship of possible controls and procedures. Based on the
evaluation of our disclosure controls and procedures as of September 30, 2012, our Chief Executive Officer and Chief Financial Officer concluded that, as of such date, our disclosure controls and procedures were effective at the reasonable
assurance level.

[0001193125-12-463263:item_4_controls:4]
Changes in Internal Control Over Financial Reporting

[0001193125-12-463263:item_4_controls:5]
There were no changes in our internal control over financial reporting that occurred during the quarter ended September 30, 2012 that have materially affected, or are reasonably likely to materially
affect, our internal control over financial reporting.

[0001193125-12-463263:item_4_controls:6]
Limitations on the Effectiveness of Controls

[0001193125-12-463263:item_4_controls:7]
Control systems, no matter how well conceived and operated, are designed to provide a reasonable, but not an absolute, level of assurance that the
objectives of the control system are met. Further, the design of a control system must reflect the fact that there are resource constraints, and the benefits of controls must be considered relative to their costs. Because of the inherent limitations
in all control systems, no evaluation of controls can provide absolute assurance that all control issues and instances of fraud, if any, have been detected. Because of the inherent limitations in any control system, misstatements due to error or
fraud may occur and not be detected.

[0001193125-12-463263:item_4_controls:8]
30
