# UI MD&A — 0001193125-12-463263


## mdna

[0001193125-12-463263:mdna:1]
[same as prior period, unchanged from 0001193125-12-201585:mdna:1]

[0001193125-12-463263:mdna:2]
[same as prior period, unchanged from 0001193125-12-201585:mdna:2]

[0001193125-12-463263:mdna:3]
We are a product driven company that leverages innovative proprietary technologies to deliver networking solutions with compelling price-performance
characteristics to both start-up and established network operators and service providers. Our products bridge the digital divide by fundamentally changing the economics of deploying high performance networking solutions in underserved and
underpenetrated wireless broadband access markets globally. These markets include emerging markets and other areas where individual users and small and medium sized enterprises do not have access to the benefits of carrier class broadband
networking. Our business model has enabled us to break down traditional barriers, such as high product and network deployment costs, which are driven by business model inefficiencies and achieve rapid market adoption of our products and solutions in
previously underserved and underpenetrated markets. Our business model and proprietary technologies provide us with a significant and sustainable competitive advantage over incumbents, who we believe are unable to respond effectively due to their
higher cost business models.

[0001193125-12-463263:mdna:4]
We offer a broad and expanding portfolio of networking products and solutions and in the outdoor wireless,
enterprise WLAN, video surveillance, wireless backhaul and machine-to-machine communications markets. We began shipping embedded radios in fiscal 2006. In fiscal 2008 we introduced a line of products based on 802.11 standard protocols and in early
fiscal 2010, we introduced a number of new products based on our proprietary airMAX protocol, which have been rapidly adopted by network operators and high-performance proprietary airMAX service providers. Since the beginning of fiscal 2011, we have
introduced UniFi, airVision, airFiber, mFi and EdgeMAX, which are collectively referred to in this report as our New Platforms. In both the three months ended September 30, 2012 and 2011, our systems revenue accounted for 83% of our revenues.
In the future, we expect sales of our airMAX platform and our new product platforms to continue to represent a growing portion of our revenues and the portion of our revenues derived from our 802.11 standard products to decline as a percentage of
total revenues.

[0001193125-12-463263:mdna:5]
Building on our leadership in the underserved and underpenetrated segments of the wireless broadband access market, we intend
to expand our product offerings in our existing market and enter adjacent markets by relying on the combination of our efficient business model and proprietary technologies. For example, we have introduced products and solutions for the enterprise
WLAN, video surveillance, and since late fiscal 2011 licensed microwave wireless backhaul, machine-to-machine communication and router markets. As we enter such new markets, we plan to leverage existing distributor relationships and establish
engaged communities similar to that of the Ubiquiti Community to keep our operating expenses in line with our current model and enable us to offer products in these new markets with compelling price-performance characteristics.

[0001193125-12-463263:mdna:6]
Our revenues decreased 22% to $61.5 million in the three months ended September 30, 2012 from $79.2 million in the three months ended
September 30, 2011. We believe the overall decrease in revenues during the three months ended September 30, 2012 was primarily driven by lost sales due to the proliferation of counterfeit versions of our products, which has also created
customer uncertainty regarding the authenticity of their potential purchases. We had net income of $13.2 million and $21.5 million in the three months ended September 30, 2012 and 2011, respectively.

[0001193125-12-463263:mdna:7]
[same as prior period, unchanged from 0001193125-12-201585:mdna:10]

[0001193125-12-463263:mdna:8]
[same as prior period, unchanged from 0001193125-12-201585:mdna:11]

[0001193125-12-463263:mdna:9]
[same as prior period, unchanged from 0001193125-12-201585:mdna:12]

[0001193125-12-463263:mdna:10]
[same as prior period, unchanged from 0001193125-12-201585:mdna:13]

[0001193125-12-463263:mdna:11]
|  | • |  | Systems consists of three product categories: |

[0001193125-12-463263:mdna:12]
|  | • |  | Our proprietary airMAX platform products for network operators and service providers; |

[0001193125-12-463263:mdna:13]
|  | • |  | Our new platform products which include significant platforms introduced in late fiscal 2011 and during 2012 which includes the UniFi, airVision and airFiber, mFi and EdgeMAX platforms; and |

[0001193125-12-463263:mdna:14]
|  | • |  | Other 802.11 standard products including base stations, radios, backhaul equipment and CPE. |

[0001193125-12-463263:mdna:15]
|  | • |  | Embedded radios consist of more than 25 radio products primarily for OEMs, including both point to point and point to multipoint radios in the 2.0 to 6.0GHz spectrum, that are offered with a variety of features. |

[0001193125-12-463263:mdna:16]
[same as prior period, unchanged from 0001193125-12-201585:mdna:18]

[0001193125-12-463263:mdna:17]
We sell substantially all of our products through a limited number of distributors and other channel partners, such as resellers and OEMs. Sales to distributors accounted for 97% and 98% of our revenues
in the three months ended September 30, 2012 and 2011, respectively. Other channel partners, such as resellers and OEMs, largely accounted for the balance of our revenues. We sell our products without any right of return.

[0001193125-12-463263:mdna:18]
[same as prior period, unchanged from 0001193125-12-201585:mdna:20]

[0001193125-12-463263:mdna:19]
[same as prior period, unchanged from 0001193125-12-201585:mdna:21]

[0001193125-12-463263:mdna:20]
[same as prior period, unchanged from 0001193125-12-201585:mdna:22]

[0001193125-12-463263:mdna:21]
[same as prior period, unchanged from 0001193125-12-201585:mdna:24]

[0001193125-12-463263:mdna:22]
Our gross profit
has been, and may in the future be, influenced by several factors including changes in product mix, target end markets for our products, pricing due to competitive pressure, production costs, foreign exchange rates and global demand for electronic
components. Although we procure and sell our products in U.S. dollars, our contract manufacturers incur many costs, including labor costs, in other currencies. To the extent that the exchange rates move unfavorably for our contract manufacturers,
they may try to pass these additional costs on to us, which could have a material impact on our future average selling prices and unit costs.

[0001193125-12-463263:mdna:23]
[same as prior period, unchanged from 0001193125-12-201585:mdna:26]

[0001193125-12-463263:mdna:24]
We classify our operating expenses as research and development and sales, general and administrative expenses.

[0001193125-12-463263:mdna:25]
[same as prior period, unchanged from 0001193125-12-201585:mdna:28]

[0001193125-12-463263:mdna:26]
|  | • |  | Sales, general and administrative expenses include salary and benefit expenses, including stock-based compensation, for employees and costs for contractors engaged in sales, marketing and general and administrative activities, as well as the costs of trade shows, marketing programs, promotional materials, bad debt expense, professional services, facilities, general liability insurance and travel. As our product portfolio and targeted markets expand, we may need to employ different sales models, such as building a direct sales force. These sales models would likely increase our costs. Over time, we expect our sales, general and administrative expenses to increase in absolute dollars due to continued growth in headcount, expand our registration and defense of trademarks and patents efforts and to support our business and operations as a public company. |

[0001193125-12-463263:mdna:27]
[same as prior period, unchanged from 0001193125-12-201585:mdna:32]

[0001193125-12-463263:mdna:28]
In the event that collectability of a receivable from products we have shipped is not probable, we classify those amounts as deferred revenues on our balance sheet until such time as we receive payment of
the accounts receivable. We classify the cost of products associated with these deferred revenues as deferred costs of revenues. At September 30, 2012 and June 30, 2012, we did not have any revenue deferred for transactions where we lacked
evidence that collectability of the receivables recorded was reasonably probable.

[0001193125-12-463263:mdna:29]
Also included in our deferred revenues is a portion related
to PCS obligations that we estimate we will perform in the future. As of September 30, 2012 and June 30, 2012, we had deferred revenues of $798,000 and $805,000 respectively, related to these obligations.

[0001193125-12-463263:mdna:30]
[same as prior period, unchanged from 0001193125-12-201585:mdna:35]

[0001193125-12-463263:mdna:31]
We have historical
agreements with certain contract manufacturers whereby we prepay for a portion of the product costs to assure the manufacture and timely delivery of our products. As of September 30, 2012 and June 30, 2012, we had prepayment balances of
$875,000 and $129,000, respectively.

[0001193125-12-463263:mdna:32]
[same as prior period, unchanged from 0001193125-12-201585:mdna:37]

[0001193125-12-463263:mdna:33]
We prepare our condensed consolidated financial statements in accordance with accounting principles generally accepted in the United States of America (“GAAP”). In many cases, the accounting
treatment of a particular transaction is specifically dictated by GAAP and does not require management’s judgment in its application. In other cases, management’s judgment is required in selecting among available alternative accounting
standards that provide for different accounting treatment for similar transactions. The preparation of condensed consolidated financial statements also requires us to make estimates and assumptions that affect the amounts we report as assets,
liabilities, revenues, costs and expenses and affect the related disclosures. We base our estimates on historical experience and other assumptions that we believe are reasonable under the circumstances. In many instances, we could reasonably use
different accounting estimates, and in some instances changes in the accounting estimates are reasonably likely to occur from period to period. Accordingly, our actual results could differ significantly from the estimates made by our management. To
the extent that there are differences between our estimates and actual results, our future financial statement presentation, financial condition, results of operations and cash flows will be affected. Our critical accounting policies are discussed
in our Annual Report on Form 10-K for the fiscal year ended June 30, 2012, as filed on September 28, 2012 with the SEC, or the Annual Report, and there have been no material changes.

[0001193125-12-463263:mdna:34]
[same as prior period, unchanged from 0001193125-12-201585:mdna:67]

[0001193125-12-463263:mdna:35]
Comparison of Three Months Ended September 30, 2012 and 2011

[0001193125-12-463263:mdna:36]
|  |  | Three Months Ended September 30, |  |
|  |  | 2012 |  |  | 2011 |  |
|  |  | (In thousands, except percentages) |  |
| Revenues |  | $ | 61,535 |  |  |  | 100 | % |  | $ | 79,167 |  |  |  | 100 | % |
| Cost of revenues(1) |  |  | 36,515 |  |  |  | 59 | % |  |  | 46,154 |  |  |  | 58 | % |
| Gross profit |  |  | 25,020 |  |  |  | 41 | % |  |  | 33,013 |  |  |  | 42 | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development(1) |  |  | 4,711 |  |  |  | 8 | % |  |  | 3,369 |  |  |  | 4 | % |
| Sales, general and administrative(1) |  |  | 4,534 |  |  |  | 7 | % |  |  | 2,144 |  |  |  | 3 | % |
| Total operating expenses |  |  | 9,245 |  |  |  | 15 | % |  |  | 5,513 |  |  |  | 7 | % |
| Income from operations |  |  | 15,775 |  |  |  | 26 | % |  |  | 27,500 |  |  |  | 35 | % |
| Interest expense and other, net |  |  | (86 | ) |  |  | * | % |  |  | (634 | ) |  |  | (1 | )% |
| Income before provision for income taxes |  |  | 15,689 |  |  |  | 25 | % |  |  | 26,866 |  |  |  | 34 | % |
| Provision for income taxes |  |  | 2,510 |  |  |  | 4 | % |  |  | 5,373 |  |  |  | 7 | % |
| Net income |  | $ | 13,179 |  |  |  | 21 | % |  | $ | 21,493 |  |  |  | 27 | % |
| * Less than 1% |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| (1) Includes stock-based compensation as follows: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of revenues |  | $ | 81 |  |  |  |  |  |  | $ | 6 |  |  |  |  |  |
| Research and development |  |  | 266 |  |  |  |  |  |  |  | 116 |  |  |  |  |  |
| Sales, general and administrative |  |  | 309 |  |  |  |  |  |  |  | 229 |  |  |  |  |  |
| Total stock-based compensation |  | $ | 656 |  |  |  |  |  |  | $ | 351 |  |  |  |  |  |

[0001193125-12-463263:mdna:37]
[same as prior period, unchanged from 0001193125-12-201585:mdna:70]

[0001193125-12-463263:mdna:38]
Revenues decreased $17.6 million, or 22%, from $79.2 million in the three months ended September 30, 2011 to $61.5 million in the three months ended September 30, 2012. We believe the overall
decrease in revenues during the three months ended September 30, 2012 was primarily driven by lost sales due to the proliferation of counterfeit versions of our products, which has also created customer uncertainty regarding the authenticity of
their potential purchases, and the effects of a buildup in channel inventory with our distributors. This has had the most significant impact on our airMAX platform which decreased $17.8 million.

[0001193125-12-463263:mdna:39]
In the three months ended September 30, 2012, revenues from Distributor A represented 15% of our revenues. In the three months ended
September 30, 2011, revenues from Distributor A and Distributor B represented 18% and 16% of our revenues, respectively. No other distributor or customer represented more than 10% of our revenues in the three months ended September 30,
2012 or 2011.

[0001193125-12-463263:mdna:40]
[same as prior period, unchanged from 0001193125-12-201585:mdna:74]

[0001193125-12-463263:mdna:41]
|  |  | Three Months Ended September 30, |  |
|  |  | 2012 |  |  | 2011 |  |
|  |  | (in thousands, except percentages) |  |
| airMAX |  | $ | 32,057 |  |  |  | 52 | % |  | $ | 49,835 |  |  |  | 63 | % |
| New platforms |  |  | 15,628 |  |  |  | 25 | % |  |  | 2,734 |  |  |  | 4 | % |
| Other systems |  |  | 3,784 |  |  |  | 6 | % |  |  | 12,765 |  |  |  | 16 | % |
| Systems |  |  | 51,469 |  |  |  | 83 | % |  |  | 65,334 |  |  |  | 83 | % |
| Embedded radio |  |  | 1,714 |  |  |  | 3 | % |  |  | 3,225 |  |  |  | 4 | % |
| Antennas/other |  |  | 8,352 |  |  |  | 14 | % |  |  | 10,608 |  |  |  | 13 | % |
| Total revenues |  | $ | 61,535 |  |  |  | 100 | % |  | $ | 79,167 |  |  |  | 100 | % |

[0001193125-12-463263:mdna:42]
21

[0001193125-12-463263:mdna:43]
Systems revenues decreased $13.9 million, or 21%, from $65.3 million in the three months ended
September 30, 2011 to $51.5 million in the three months ended September 30, 2012. As noted above, we believe the decrease in systems revenues was primarily driven by lost sales due to the proliferation of counterfeit versions of our
products, in particular our airMAX product line. The decrease in our airMAX product line was partially offset by increased sales in our new platforms category, which includes significant platforms introduced since late fiscal 2011. Our new platforms
contributed $15.6 million and $2.7 million of revenue the three months ended September 30, 2012 and 2011, respectively. Our other systems revenue decreased $9.0 million during the three months ended September 30, 2012 as compared to the
three months ended September 30, 2011 due primarily to our September 2011 quarter including a large order to a direct customer.

[0001193125-12-463263:mdna:44]
Embedded
radio revenues decreased $1.5 million from the three months ended September 30, 2011 to 2012. We anticipate that embedded radio products will decline as a percentage of revenues in future periods as sales of these products are outpaced by sales
of systems products.

[0001193125-12-463263:mdna:45]
Antennas/other revenues decreased $2.3 million, or 21% from $10.6 million in the three months ended
September 30, 2011 to $8.4 million in the three months ended September 30, 2012. The decline in antennas/other revenues was primarily due to the decreased sales of our systems platforms, which negatively impacted the demand for associated
antennas. Other revenues also include revenues that are attributable to PCS. Antenna/other revenues may continue to increase in absolute dollars in future periods but will decline as a percentage of total revenues due to more rapid growth of systems
revenues.

[0001193125-12-463263:mdna:46]
[same as prior period, unchanged from 0001193125-12-201585:mdna:80]

[0001193125-12-463263:mdna:47]
We generally forward products directly from our manufacturers to freight companies in Hong Kong, which have been retained by our distributors and who in turn ship to other locations throughout the world.
We have determined the geographical distribution of our product revenues based on ship-to destinations. A majority of our sales are to distributors who in turn sell to resellers or directly to end customers. As a result of these factors, we believe
that sales to certain geographic locations might be higher or lower, as the ultimate destinations are difficult to ascertain. Revenues in North Americas decreased primarily due to a significant decline in orders from one of our distributors. We
believe the decrease in revenues in South American and Europe, the Middle East and Africa was primarily driven by the proliferation of counterfeit versions of our products, which has also created customer uncertainty regarding the authenticity of
their potential purchases. Revenues in the Asia Pacific region tend to be volatile given the low levels of revenues. The following are our revenues by geography for the three months ended September 30, 2012 and 2011 (in thousands, except
percentages):

[0001193125-12-463263:mdna:48]
|  |  | Three Months Ended September 30, |  |
|  |  | 2012 |  |  | 2011 |  |
|  |  | (In thousands, except percentages) |  |
| North America(1) |  | $ | 20,361 |  |  |  | 33 | % |  | $ | 24,941 |  |  |  | 32 | % |
| South America |  |  | 10,243 |  |  |  | 17 | % |  |  | 19,835 |  |  |  | 25 | % |
| Europe, the Middle East and Africa |  |  | 23,144 |  |  |  | 37 | % |  |  | 24,783 |  |  |  | 31 | % |
| Asia Pacific |  |  | 7,787 |  |  |  | 13 | % |  |  | 9,608 |  |  |  | 12 | % |
| Total revenues |  | $ | 61,535 |  |  |  | 100 | % |  | $ | 79,167 |  |  |  | 100 | % |

[0001193125-12-463263:mdna:49]
| (1) | Revenue for the United States was $19.3 million and $24.4 million for the three months ended September 30, 2012 and 2011, respectively. |

[0001193125-12-463263:mdna:50]
Cost of Revenues and Gross Margin

[0001193125-12-463263:mdna:51]
Cost of revenues decreased $9.6 million, or 21%, from $46.2 million in the three months ended September 30, 2011 to $36.5 million in the three months ended September 30, 2012, primarily due to
decreased revenues and to a lesser extent, changes in product mix. Gross margin decreased from 42% in the three months ended September 30, 2011 to 41% in the three months ended September 30, 2012, reflecting an increase in variable
operating costs.

[0001193125-12-463263:mdna:52]
[same as prior period, unchanged from 0001193125-12-201585:mdna:86]

[0001193125-12-463263:mdna:53]
[same as prior period, unchanged from 0001193125-12-201585:mdna:87]

[0001193125-12-463263:mdna:54]
Research and development expenses increased $1.3 million, or 40%,
from $3.4 million in the three months ended September 30, 2011 to $4.7 million in the three months ended September 30, 2012. As a percentage of revenues, research and development expenses increased from 4% in the three months ended
September 30, 2011 to 8% in the three months ended September 30, 2012. The increase in research and development expenses in absolute dollars was due to increases in headcount as we broadened our research and development activities to new
product areas. As a percentage of revenues, research and development expenses increased primarily due to our overall decrease in revenues. Over time, we expect our research and development costs to increase in absolute dollars as we continue making
significant investments in developing new products and developing new versions of our existing products.

[0001193125-12-463263:mdna:55]
[same as prior period, unchanged from 0001193125-12-201585:mdna:89]

[0001193125-12-463263:mdna:56]
Sales, general and administrative expenses increased $2.4 million, or 111%, from $2.1 million in the three months ended September 30,
2011 to $4.5 million in the three months ended September 30, 2012. As a percentage of revenues, sales, general and administrative expenses increased from 3% in the three months ended September 30, 2011 to 7% in the three months ended
September 30, 2012. Sales, general and administrative expenses increased due largely to increased legal expenses associated with our anti-counterfeiting litigation, increased marketing and tradeshow activity and bad debt expense. As a
percentage of revenues sales, general and administrative expenses increased primarily due to our overall revenue decrease in revenues. Over time, we expect our sales, general and administrative expenses to increase in absolute dollars due to
continued efforts to protect our intellectual property and growth in headcount to support our business and operations.

[0001193125-12-463263:mdna:57]
Interest Expense
and Other, Net

[0001193125-12-463263:mdna:58]
Interest expense and other, net was $86,000 for the three months ended September 30, 2012, representing an
increase of $548,000 from $634,000 for the three months ended September 30, 2011. During the three months ended September 30, 2011, we incurred interest expense on our convertible subordinated promissory notes issued as part of the
repurchase of Series A convertible preferred stock from entities affiliated with Summit Partners, L.P. in July 2011. The convertible subordinated promissory notes were repaid in full in October 2011.

[0001193125-12-463263:mdna:59]
[same as prior period, unchanged from 0001193125-12-201585:mdna:95]

[0001193125-12-463263:mdna:60]
Our
provision for income taxes decreased $2.9 million, or 53%, from $5.4 million for the three months ended September 30, 2011 to $2.5 million for the three months ended September 30, 2012. Our effective tax rate decreased to 16% for the three
months ended September 30, 2012 as compared to the three months ended September 30, 2011 due to a larger percentage of our overall profitability occurring in foreign jurisdictions with lower income tax rates.

[0001193125-12-463263:mdna:61]
[same as prior period, unchanged from 0001193125-12-201585:mdna:97]

[0001193125-12-463263:mdna:62]
[same as prior period, unchanged from 0001193125-12-201585:mdna:98]

[0001193125-12-463263:mdna:63]
Since
inception, our operations primarily have been funded through cash generated by operations. Cash, cash equivalents and short-term marketable securities increased from $122.1 million at June 30, 2012 to $132.5 million at September 30, 2012.

[0001193125-12-463263:mdna:64]
[same as prior period, unchanged from 0001193125-12-201585:mdna:100]

[0001193125-12-463263:mdna:65]
[same as prior period, unchanged from 0001193125-12-201585:mdna:101]

[0001193125-12-463263:mdna:66]
|  |  | Three Months EndedSeptember 30, |  |
|  |  | 2012 |  |  | 2011 |  |
|  |  | (In thousands) |  |
| Net cash provided by operating activities |  | $ | 23,695 |  |  | $ | 15,719 |  |
| Net cash used in investing activities |  |  | (2,349 | ) |  |  | (205 | ) |
| Net cash used in financing activities |  |  | (10,920 | ) |  |  | (39,299 | ) |
| Net increase (decrease) in cash and cash equivalents |  | $ | 10,426 |  |  | $ | (23,785 | ) |

[0001193125-12-463263:mdna:67]
[same as prior period, unchanged from 0001193125-12-201585:mdna:104]

[0001193125-12-463263:mdna:68]
Net cash provided by operating activities in the three months ended September 30, 2012 of $23.7 million consisted primarily of net income of $13.2 million and by net increases in operating assets and
liabilities of 9.0 million. These changes consisted primarily of a $14.3 million decrease in accounts receivable due to decreased revenues, a $6.4 million decrease in accounts payable and accrued liabilities due to decreased overall business
activity, a $2.3 million increase in taxes payable due the timing of federal tax payments and a $1.3 million increase in prepaid expenses and other current assets due primarily to increased deposits with our vendors. Additionally, our net income
included non-cash adjustments due to stock-based compensation, depreciation and amortization, adjustments to our provisions for doubtful accounts and inventory obsolescence and an excess tax benefit from stock-based awards. The net of these non-cash
adjustments resulted in an increase of our net cash provided by operating activities of $1.5 million.

[0001193125-12-463263:mdna:69]
Net cash provided by operating
activities in the three months ended September 30, 2011 of $15.7 million consisted primarily of net income of $21.5 million offset by net decreases in operating assets and liabilities of $6.3 million. Changes in operating assets and liabilities
consisted primarily of an $8.3 million increase in accounts receivable due to our overall revenue growth, a $2.9 million increase in taxes payable, a $2.7 million increase in inventories, a $1.3 million increase in accounts payable and accrued
liabilities and an increase of $488,000 in deferred revenues and deferred cost of revenues.

[0001193125-12-463263:mdna:70]
[same as prior period, unchanged from 0001193125-12-201585:mdna:107]

[0001193125-12-463263:mdna:71]
Our investing activities consist solely of capital expenditures and purchases of intangible assets. Capital expenditures for the three
months ended September 30, 2012 and 2011 were $1.6 million and $205,000, respectively. Additionally, we had cash outflows related to the purchase of intangible assets of $748,000 during the three months ended September 30, 2012.

[0001193125-12-463263:mdna:72]
[same as prior period, unchanged from 0001193125-12-201585:mdna:109]

[0001193125-12-463263:mdna:73]
On August 7, 2012, we entered into a Loan and Security Agreement (the “Loan Agreement”) with U.S. Bank, as syndication agent, and East West Bank, as administrative agent. The Loan Agreement
replaces the EWB Loan Agreement as discussed below. The Loan Agreement provides for (i) a $50.0 million revolving credit facility, with a $5.0 million sublimit for the issuance of letters of credit and a $5.0 million sublimit for the making of
swingline loan advances (the “Revolving Credit Facility”), and (ii) a $50.0 million term loan facility (the “Term Loan Facility”). We may request borrowings under the Revolving Credit Facility until August 7, 2015. On
August 7, 2012, we borrowed an additional $20.8 million of term loans under the Term Loan Facility.

[0001193125-12-463263:mdna:74]
On August 9, 2012, we announced
that our Board of Directors authorized us to repurchase up to $100 million of our common stock. The share repurchase program commenced August 13, 2012. During the three months ended September 30, 2012 we repurchased 3,171,914 shares for a
total cost of $31.3 million.

[0001193125-12-463263:mdna:75]
In July 2011, we repurchased an aggregate of 12,041,700 shares of our Series A preferred stock from entities
affiliated with Summit Partners, L.P., one of our major stockholders, at a price of $8.97 per share for an aggregate consideration of $108.0 million. Of the aggregate purchase price, $40.0 million was paid in cash at the time of closing and the
balance of the shares were paid for through the issuance of convertible subordinated promissory notes in the aggregate principal amount of $68.0 million. On September 15, 2011, $34.0 million was paid against the notes reducing the aggregate
principal amount outstanding to $34.0 million.

[0001193125-12-463263:mdna:76]
On September 15, 2011, we entered into a Loan and Security Agreement with East West Bank,
(the “EWB Loan Agreement”). The EWB Loan Agreement consisted of a $35.0 million term loan facility and a $5.0 million revolving line of credit facility. The term loan was scheduled to mature on September 15, 2016 with principal and
interest to be repaid in 60 monthly installments. During the three months ended September 30, 2011, we used $34.0 million of the term loan to repay a portion of our outstanding convertible subordinated promissory notes held by entities
affiliated with Summit Partners, L.P. The EWB Agreement was replaced by the Loan Agreement on August 7, 2012 as discussed above.

[0001193125-12-463263:mdna:77]
[same as prior period, unchanged from 0001193125-12-201585:mdna:115]

[0001193125-12-463263:mdna:78]
We believe our existing cash
and cash equivalents will be sufficient to meet our working capital and capital expenditure needs for at least the next 12 months. Our future capital requirements may vary materially from those currently planned and will depend on many factors,
including our rate of revenue growth, the timing and extent of spending to support development efforts, the timing of new product introductions, market acceptance of our products and overall economic conditions. As of September 30, 2012, we
held $118.1 million of our $132.5 million of cash and cash equivalents in accounts of our subsidiaries outside of the United States and we will incur significant tax liabilities if we decide to repatriate those amounts.

[0001193125-12-463263:mdna:79]
Commitments and Contingencies

[0001193125-12-463263:mdna:80]
In
January 2011, the U.S. Department of Commerce’s Bureau of Industry and Security’s Office of Export Enforcement (“OEE”) contacted us to request that we provide information related to our relationship with a logistics company in
the United Arab Emirates (“UAE”) and with a company in Iran, as well as information on the export classification of our products. As a result of this inquiry we, assisted by outside counsel, conducted a review of our export transactions
from 2008 through March 2011 to not only gather information responsive to the OEE’s request but also to review our overall compliance with export control and sanctions laws. We believe our products have been sold into Iran by third parties. We
do not believe that we directly sold, exported or shipped our products into Iran or any other country subject to a U.S. embargo. However, until early 2010, we did not prohibit our distributors from selling our products into Iran or any other country
subject to a U.S. embargo. In the course of this review we identified that two distributors may have sold Ubiquiti products into Iran. Our review also found that while we had obtained required Commodity Classification Rulings for our products in
June 2010 and November 2010, we did not advise our shipping personnel to change the export authorizations used on our shipping documents until February 2011. During the course of our export control review, we also determined that we had failed to
maintain adequate records for the five year period required by the EAR and the sanctions regulations due to our lack of infrastructure and because it was prior to our transition to our system of record, NetSuite. See “Risk Factors—We
are subject to numerous U.S. export control and economic sanctions laws and a substantial majority of our sales are into countries outside of the United States. Although we did not intend to do so, we have violated certain of these laws in the past,
and we cannot currently assess the nature and extent of any fines or other penalties, if any, that U.S. governmental agencies may impose against us or our employees for any such violations. Any fines, if materially different from our estimates, or
other penalties, could have a material adverse effect on our business and financial results.”

[0001193125-12-463263:mdna:81]
In May 2011, we filed a
self-disclosure with OEE and, in June 2011 we filed one with U.S. Department of the Treasury’s Office of Foreign Asset Control (“OFAC”), regarding the compliance issues noted above. The disclosures address the above described findings
and the remedial actions we have taken to date. However, the findings also indicate that both distributors continued to sell, directly or indirectly, our products into Iran during the period from February 2010 through March 2011 and that we received
various communications from them indicating that they were continuing to do so. Since January 2011, we have cooperated with OEE and, prior to our disclosure filing, we informally shared with the OEE the substance of our findings with respect to both
distributors. From May

[0001193125-12-463263:mdna:82]
[same as prior period, unchanged from 0001193125-12-201585:mdna:23]

[0001193125-12-463263:mdna:83]
2011 to August 2011, we provided additional information regarding our review and our findings to OEE to facilitate its investigation and OEE advised us in August 2011 that it had completed
its investigation of us. In August 2011, we received a warning letter from OEE stating that OEE had not referred the findings of our review for criminal or administrative prosecution of us and closed the investigation of us without penalty.

[0001193125-12-463263:mdna:84]
OFAC is still reviewing our voluntary disclosure. In our submission, we have provided OFAC with an explanation of the activities that led to
the sales of our products in Iran and the failure to comply with the EAR and OFAC sanctions. Although our OFAC and OEE voluntary disclosures covered similar sets of facts, which led OEE to resolve the case with the issuance of a warning letter, OFAC
may conclude that our actions resulted in violations of U.S. export control and economic sanctions laws and warrant the imposition of penalties that could include fines, termination of our ability to export our products and/or referral for criminal
prosecution. Any such fines may be material to our financial results in the period in which they are imposed. The penalties may be imposed against us and/or our management. The maximum civil monetary penalty for the violations is up to $250,000 or
twice the value of the transaction, whichever is greater, per violation. Also, disclosure of our conduct and any fines or other action relating to this conduct could harm our reputation and indirectly have a material adverse effect on our business.
We cannot predict when OFAC will complete its review or decide upon the imposition of possible penalties.

[0001193125-12-463263:mdna:85]
Based on the facts known to us to
date, we recorded an expense of $1.6 million for this export compliance matter in fiscal 2010, which represents management’s estimated exposure for fines in accordance with applicable accounting literature. Should additional facts be discovered
in the future and/or should actual fines or other penalties substantially differ from our estimates, our business, financial condition, cash flows and results of operations would be materially negatively impacted.

[0001193125-12-463263:mdna:86]
[same as prior period, unchanged from 0001193125-12-201585:mdna:124]

[0001193125-12-463263:mdna:87]
Our
products are generally accompanied by a 12 month warranty, which covers both parts and labor. Generally the distributor is responsible for the freight costs associated with warranty returns, and we absorb the freight costs of replacing items under
warranty. In accordance with the Financial Accounting Standards Board’s (“FASB’s”), Accounting Standards Codification (“ASC”), 450-30, Loss Contingencies, we record an accrual when we believe it is estimable and
probable based upon historical experience. We record a provision for estimated future warranty work in cost of goods sold upon recognition of revenues and we review the resulting accrual regularly and periodically adjust it to reflect changes in
warranty estimates.

[0001193125-12-463263:mdna:88]
We may in the future enter into standard indemnification agreements with many of our distributors and OEMs, as well as
certain other business partners in the ordinary course of business. These agreements may include provisions for indemnifying the distributor, OEM or other business partner against any claim brought by a third party to the extent any such claim
alleges that a Ubiquiti product infringes a patent, copyright or trademark or violates any other proprietary rights of that third party. The maximum amount of potential future indemnification is unlimited. The maximum potential amount of future
payments we could be required to make under these indemnification agreements is not estimable.

[0001193125-12-463263:mdna:89]
We have agreed to indemnify our directors,
officers and certain other employees for certain events or occurrences, subject to certain limits, while such persons are or were serving at our request in such capacity. We may terminate the indemnification agreements with these persons upon the
termination of their services with us but termination will not affect claims for indemnification related to events occurring prior to the effective date of termination. The maximum amount of potential future indemnification is unlimited. We have a
director and officer insurance policy that limits our potential exposure. We believe the fair value of these indemnification agreements is minimal. We had not recorded any liabilities for these agreements as of September 30, 2012 or 2011.

[0001193125-12-463263:mdna:90]
Based upon our historical experience and information known as of the date of this report, we do not believe it is likely that we will have
significant liability for the above indemnities at September 30, 2012.

[0001193125-12-463263:mdna:91]
[same as prior period, unchanged from 0001193125-12-201585:mdna:129]

[0001193125-12-463263:mdna:92]
We lease our headquarters in San Jose, California and other locations worldwide under noncancelable operating leases that expire at
various dates through fiscal 2017.

[0001193125-12-463263:mdna:93]
26

[0001193125-12-463263:mdna:94]
In December 2011, we entered into an agreement to lease approximately 64,512 square feet of office and
research and development space located in San Jose, California, which will be used as our corporate headquarters. The lease term is from April 1, 2012, though June 30, 2017. The lease has been categorized as an operating lease, and the
total estimated lease obligation is approximately $4.9 million.

[0001193125-12-463263:mdna:95]
On August 7, 2012, we entered into the Loan Agreement with U.S. Bank, as
syndication agent, and East West Bank, as administrative agent. The Loan Agreement provides for (i) a $50.0 million revolving credit facility, with a $5.0 million sublimit for the issuance of letters of credit and a $5.0 million sublimit for
the making of swingline loan advances, and (ii) a $50.0 million Term Loan Facility. We may request borrowings under the Revolving Credit Facility until August 7, 2015. On August 7, 2012, we borrowed an additional $20.8 million of term
loans under the Term Loan Facility.

[0001193125-12-463263:mdna:96]
The following table summarizes our contractual obligations as of September 30, 2012:

[0001193125-12-463263:mdna:97]
|  |  | 2013(remainder) |  |  | 2014 |  |  | 2015 |  |  | 2016 |  |  | 2017 |  |  | Thereafter |  |  | Total |  |
| Operating leases |  | $ | 1,078 |  |  | $ | 1,384 |  |  | $ | 1,396 |  |  | $ | 1,428 |  |  | $ | 1,122 |  |  | $ | — |  |  | $ | 6,408 |  |
| Debt payment obligations |  |  | 3,750 |  |  |  | 5,000 |  |  |  | 6,875 |  |  |  | 9,375 |  |  |  | 10,000 |  |  |  | 15,000 |  |  |  | 50,000 |  |
| Interest payments on debt payment obligations |  |  | 914 |  |  |  | 1,110 |  |  |  | 973 |  |  |  | 777 |  |  |  | 531 |  |  |  | 172 |  |  |  | 4,477 |  |
| Total |  | $ | 5,742 |  |  | $ | 7,494 |  |  | $ | 9,244 |  |  | $ | 11,580 |  |  | $ | 11,653 |  |  | $ | 15,172 |  |  | $ | 60,885 |  |

[0001193125-12-463263:mdna:98]
We subcontract with other companies to manufacture our products. During the normal course of business, our contract
manufacturers procure components based upon orders placed by us. If we cancel all or part of the orders, we may still be liable to the contract manufacturers for the cost of the components purchased by the subcontractors to manufacture our products.
We periodically review the potential liability and to date no significant accruals have been recorded. Our consolidated financial position and results of operations could be negatively impacted if we were required to compensate the contract
manufacturers for any unrecorded liabilities incurred.

[0001193125-12-463263:mdna:99]
As of September 30, 2012, we had $8.4 million of unrecognized tax benefits,
substantially all of which would, if recognized, affect our tax expense. We have elected to include interest and penalties related to uncertain tax positions as a component of tax expense. We do not expect any significant increases or decreases to
our unrecognized tax benefits in the next twelve months.

[0001193125-12-463263:mdna:100]
[same as prior period, unchanged from 0001193125-12-201585:mdna:139]

[0001193125-12-463263:mdna:101]
We do not believe there have been any recent accounting pronouncements that would have a significant impact on our financial statements.

[0001193125-12-463263:mdna:102]
[same as prior period, unchanged from 0001193125-12-201585:mdna:144]

[0001193125-12-463263:mdna:103]
Regulation G, conditions for use of Non-Generally Accepted Accounting Principles (“Non-GAAP”) financial measures, and other SEC regulations
define and prescribe the conditions for use of certain Non-GAAP financial information. To supplement our condensed consolidated financial results presented in accordance with GAAP, we use Non-GAAP financial measures which are adjusted from the most
directly comparable GAAP financial measures to exclude certain items, as described below. Management believes that these Non-GAAP financial measures reflect an additional and useful way of viewing aspects of our operations that, when viewed in
conjunction with our GAAP results, provide a more comprehensive understanding of the various factors and trends affecting our business and operations. Non-GAAP financial measures used by us include net income or loss and diluted net income or loss
per share.

[0001193125-12-463263:mdna:104]
Our Non-GAAP measures primarily exclude stock-based compensation, net of taxes and other special charges and credits. Management
believes these Non-GAAP financial measures provide meaningful supplemental information regarding our strategic and business decision making, internal budgeting, forecasting and resource allocation processes. In addition, these Non-GAAP financial
measures facilitate management’s internal comparisons to our historical operating results and comparisons to competitors’ operating results.

[0001193125-12-463263:mdna:105]
[same as prior period, unchanged from 0001193125-12-201585:mdna:47]

[0001193125-12-463263:mdna:106]
We use each of these Non-GAAP financial measures for internal managerial purposes, when providing our
financial results and business outlook to the public and to facilitate period-to-period comparisons. Management believes that these Non-GAAP measures provide meaningful supplemental information regarding our operational and financial performance of
current and historical results. Management uses these Non-GAAP measures for strategic and business decision making, internal budgeting, forecasting and resource allocation processes. In addition, these Non-GAAP financial measures facilitate
management’s internal comparisons to our historical operating results and comparisons to competitors’ operating results.

[0001193125-12-463263:mdna:107]
The
following table shows our Non-GAAP financial measures:

[0001193125-12-463263:mdna:108]
|  |  | Three Months EndedSeptember 30, |  |
|  |  | 2012 |  |  | 2011 |  |
|  |  | (In thousands, except per share amounts) |  |
| Non-GAAP net income |  | $ | 13,572 |  |  | $ | 21,704 |  |
| Non-GAAP diluted net income per share of common stock |  | $ | 0.15 |  |  | $ | 0.23 |  |

[0001193125-12-463263:mdna:109]
[same as prior period, unchanged from 0001193125-12-201585:mdna:150]

[0001193125-12-463263:mdna:110]
The following table shows a reconciliation of GAAP net income to non-GAAP net income:

[0001193125-12-463263:mdna:111]
|  |  | Three Months EndedSeptember 30, |  |
|  |  | 2012 |  |  | 2011 |  |
|  |  | (In thousands, except per share amounts) |  |
| Net Income |  | $ | 13,179 |  |  | $ | 21,493 |  |
| Stock-based compensation: |  |  |  |  |  |  |  |  |
| Cost of revenues |  |  | 81 |  |  |  | 6 |  |
| Research and development |  |  | 266 |  |  |  | 116 |  |
| Sales, general and administrative |  |  | 309 |  |  |  | 229 |  |
| Tax effect of non-GAAP adjustments |  |  | (263 | ) |  |  | (140 | ) |
| Non-GAAP net income |  | $ | 13,572 |  |  | $ | 21,704 |  |
| Non-GAAP diluted net income per share of common stock (1) |  | $ | 0.15 |  |  | $ | 0.23 |  |
| Weighted-average shares used in computing non-GAAP diluted net income per share of common stock (1) |  |  | 92,925 |  |  |  | 93,467 |  |

[0001193125-12-463263:mdna:112]
[same as prior period, unchanged from 0001193125-12-201585:mdna:153]

[0001193125-12-463263:mdna:113]
[same as prior period, unchanged from 0001193125-12-201585:mdna:59]

[0001193125-12-463263:mdna:114]
The following table shows a reconciliation of weighted-average shares used in computing net loss per share
of common stock-diluted to weighted-average shares used in computing non-GAAP diluted net income per share of common stock:

[0001193125-12-463263:mdna:115]
|  |  | Three Months EndedSeptember 30, |  |
|  |  | 2012 |  |  | 2011 |  |
|  |  | (In thousands) |  |
| Weighted average shares used in computing net loss per share of common stock- diluted |  |  | 92,925 |  |  |  | 62,717 |  |
| Weighted average dilutive effect of stock options and restricted stock units |  |  | — |  |  |  | 3,877 |  |
| Weighted average shares of Series A preferred stock outstanding |  |  | — |  |  |  | 26,873 |  |
| Weighted-average shares used in computing non-GAAP diluted income per share of common stock |  |  | 92,925 |  |  |  | 93,467 |  |
