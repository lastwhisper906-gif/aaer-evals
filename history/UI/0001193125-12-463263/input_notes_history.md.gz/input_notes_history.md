# UI note change history — 0001193125-12-201585 → 0001193125-12-463263


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2012-11-09):
[0001193125-12-463263:note_history:1]
In December 2011, the
Company entered into an agreement to lease approximately 64,512
square feet of office and research and development space located in
San Jose, California, which will be used as the Company’s
corporate headquarters. The lease term is from April 1, 2012,
through June 30, 2017. The lease has been categorized as an
operating lease, and the total estimated rent expense to be
recognized is $4.9 million.
  (was, 2012-05-02, similarity 0.9962):
[0001193125-12-201585:note_history:1]
In December 2011, the Company entered into an agreement to lease approximately 64,512 square feet of office and research and development space located in San Jose, California, which will be used as the Company's corporate headquarters. The lease term is from April 1, 2012, though June 30, 2017. The lease has been categorized as an operating lease, and the total estimated rent expense to be recognized is $4.9 million.

- added (2012-11-09):
[0001193125-12-463263:note_history:2]
At September 30, 2012,
future minimum annual payments under operating leases are as
follows (in thousands):

- changed (2012-11-09):
[0001193125-12-463263:note_history:3]
|  |  | 2013 (remainder) |  |  | 2014 |  |  | 2015 |  |  | 2016 |  |  | 2017 |  |  | Thereafter |  |  | Total |  |
| Operating leases |  | $ | 1,078 |  |  | $ | 1,384 |  |  | $ | 1,396 |  |  | $ | 1,428 |  |  | $ | 1,122 |  |  | $ | — |  |  | $ | 6,408 |  |
  (was, 2012-05-02, similarity 0.992):
[0001193125-12-201585:note_history:3]
|  |  | 2012(remainder) |  |  | 2013 |  |  | 2014 |  |  | 2015 |  |  | 2016 |  |  | Thereafter |  |  | Total |  |
| Operating leases |  | $ | 446 |  |  | $ | 1,474 |  |  | $ | 1,227 |  |  | $ | 1,203 |  |  | $ | 1,203 |  |  | $ | 896 |  |  | $ | 6,449 |  |

- changed (2012-11-09):
[0001193125-12-463263:note_history:4]
The Company subcontracts
with other companies to manufacture its products. During the normal
course of business, the Company’s contract manufacturers
procure components based upon orders placed by the Company. If the
Company cancels all or part of the orders, it may still be liable
to the contract manufacturers for the cost of the components
purchased by them to manufacture the Company’s products. The
Company periodically reviews the potential liability and to date no
accruals have been recorded. The Company’s consolidated
financial position and results of operations could be negatively
impacted if it were required to compensate the contract
manufacturers for any liabilities incurred.
  (was, 2012-05-02, similarity 0.9957):
[0001193125-12-201585:note_history:4]
The Company subcontracts with other companies to manufacture its products. During the normal course of business, the Company's contract manufacturers procure components based upon orders placed by the Company. If the Company cancels all or part of the orders, it may still be liable to the contract manufacturers for the cost of the components purchased by them to manufacture the Company's products. The Company periodically reviews the potential liability and to date no accruals have been recorded. The Company's consolidated financial position and results of operations could be negatively impacted if it were required to compensate the contract manufacturers for any liabilities incurred.

- added (2012-11-09):
[0001193125-12-463263:note_history:5]
The Company may be
involved, from time to time, in a variety of claims, lawsuits,
investigations, and proceedings relating to contractual disputes,
intellectual property rights, employment matters, regulatory
compliance matters and other litigation matters relating to various
claims that arise in the normal course of business. The Company
determines whether an estimated loss from a contingency should be
accrued by assessing whether a loss is deemed probable and can be
reasonably estimated. The Company assesses its potential liability
by analyzing specific litigation and regulatory matters using
available information. The Company develops its views on estimated
losses in consultation with inside and outside counsel, which
involves a subjective analysis of potential results and outcomes,
assuming various combinations of appropriate litigation and
settlement strategies. Because of the uncertainties related to both
the amount and ranges of possible loss from pending litigation
matters, the Company is unable to predict with certainty the
precise liability that could finally result from a range of
possible unfavorable outcomes. Taking all of the above factors into
account, the Company records an amount where it is probable that
the Company will incur a loss and where that loss can be reasonably
estimated. However, the Company’s estimates may be incorrect
and the Company could ultimately incur more or less than the
amounts initially recorded. Litigation can be costly, diverting
management’s attention and could, upon resolution, have a
material adverse effect on the Company’s business, results of
operations, financial condition, and cash flows.

- changed (2012-11-09):
[0001193125-12-463263:note_history:6]
In January 2011, the U.S.
Commerce Department, Bureau of Industry and Security’s
(“BIS”) Office of Export Enforcement
(“OEE”) contacted the Company to request that the
Company provide information related to its relationship with a
logistics company in the UAE and with a company in Iran, as well as
information on the export classification of its products. As a
result of this inquiry the Company, assisted by outside counsel,
conducted a review of the Company’s export transactions from
2008 through March 2011 to not only gather information responsive
to the OEE’s request but also to review the Company’s
overall compliance with export control and sanctions laws. It was
in the course of this review that the Company identified the
Iranian sales of two of its distributors.
  (was, 2012-05-02, similarity 0.9856):
[0001193125-12-201585:note_history:6]
In January 2011, the U.S. Commerce Department, Bureau of Industry and Security's ("BIS") Office of Export Enforcement ("OEE") contacted the Company to request that the Company provide information related to its relationship with a logistics company in the UAE and with a company in Iran, as well as information on the export classification of its products. As a result of this inquiry the Company, assisted by outside counsel, conducted a review of the Company's export transactions from 2008 through March 2011 to not only gather information responsive to the OEE's request but also to review the Company's overall compliance with export control and sanctions laws. It was in the course of this review that the Company identified the Iranian sales of two of its distributors.

- changed (2012-11-09):
[0001193125-12-463263:note_history:7]
In May 2011, the Company
filed a self-disclosure with the BIS and Security’s Office of
Export Enforcement OEE and in June 2011, filed one with U.S.
Department of the Treasury’s Office of Foreign Asset Control
(“OFAC”) regarding the compliance issues noted above.
The disclosures address the above described findings and the
remedial actions the Company had taken to date. However, the
findings also indicate that both distributors continued to sell,
directly or indirectly, the Company’s products into Iran
during the period from February 2010 through March 2011 and that
the Company received various communications from them indicating
that they were continuing to do so. Since January 2011, the Company
has cooperated with OEE and, prior to its disclosure filing, the
Company informally shared with the OEE the substance of its
findings with respect to both distributors. From May 2011 to August
2011, the Company provided additional information regarding its
review and its findings to OEE to facilitate its investigation and
OEE advised the Company in August 2011 that it had completed its
investigation of the Company. In August 2011, the Company received
a warning letter from OEE stating that OEE had not referred the
findings of the Company’s review for criminal or
administrative prosecution of us and closed the investigation of
the Company without penalty.
  (was, 2012-05-02, similarity 0.9902):
[0001193125-12-201585:note_history:7]
In May 2011, the Company filed a self-disclosure with the BIS and Security's Office of Export Enforcement OEE and in June 2011, filed one with U.S. Department of the Treasury's Office of Foreign Asset Control ("OFAC") regarding the compliance issues noted above. The disclosures address the above described findings and the remedial actions the Company had taken to date. However, the findings also indicate that both distributors continued to sell, directly or indirectly, the Company's products into Iran during the period from February 2010 through March 2011 and that the Company received various communications from them indicating that they were continuing to do so. Since January 2011, the Company has cooperated with OEE and, prior to its disclosure filing, the Company informally shared with the OEE the substance of its findings with respect to both distributors. From May 2011 to August 2011, the Company provided additional information regarding its review and its findings to OEE to facilitate its investigation and OEE advised the Company in August 2011 that it had completed its investigation of the Company. In August 2011, the Company received a warning letter from OEE stating that OEE had not referred the findings of the Company's review for criminal or administrative prosecution and closed the investigation of the Company without penalty.

- changed (2012-11-09):
[0001193125-12-463263:note_history:8]
OFAC is still reviewing the
Company’s voluntary disclosure. In the Company’s
submission, the Company provided OFAC with an explanation of the
activities that led to the sales of its products in Iran and the
failure to comply with the Export Administration Regulations (the
“EAR”) and OFAC sanctions. Although the Company’s
OFAC and OEE voluntary disclosures covered similar sets of facts,
which led the OEE to resolve the case with the issuance of a
warning letter, OFAC may conclude that the Company’s actions
resulted in violations of U.S. export control and economic
sanctions laws and warrant the imposition of penalties that could
include fines, termination of the Company’s ability to export
its products, and/or referral for criminal prosecution. Any such
fines may be material to the Company’s financial results in
the period in which they are imposed. The penalties may be imposed
against the Company and/or its management. The maximum civil
monetary penalty for the violations is up to $250,000 or twice the
value of the transaction, whichever is greater, per violation. The
Company cannot predict when OFAC will complete its review or decide
upon the imposition of possible penalties.
  (was, 2012-05-02, similarity 0.9646):
[0001193125-12-201585:note_history:8]
OFAC is still in the early stages of reviewing the Company's voluntary disclosure. In the Company's submission, the Company provided OFAC with an explanation of the activities that led to the sales of its products in Iran and the failure to comply with the Export Administration Regulations (the "EAR") and OFAC sanctions. Although the Company's OFAC and OEE voluntary disclosures covered similar sets of facts, which led the OEE to resolve the case with the issuance of a warning letter, OFAC may conclude that the Company's actions resulted in violations of U.S. export control and economic sanctions laws and warrant the imposition of penalties that could include fines, termination of the Company's ability to export its products, and/or referral for criminal prosecution. Any such fines may be material to the Company's financial results in the period in which they are imposed. The penalties may be imposed against the Company and/or its management. The maximum civil monetary penalty for the violations is up to $250,000 or twice the value of the transaction, whichever is greater, per violation. The Company cannot predict when OFAC will complete its review or decide upon the imposition of possible penalties.

- changed (2012-11-09):
[0001193125-12-463263:note_history:9]
Based on the facts known to
the Company to date, the Company recorded an expense of $1.6
million for this export compliance matter in fiscal 2010, which
represents management’s estimated exposure for fines in
accordance with applicable accounting literature. This amount was
calculated from information discovered through the Company’s
internal review and this loss is deemed to be probable and
reasonably estimable. However, the Company also believes that it is
reasonably possible that the loss may be higher, but the Company
cannot reasonably estimate the range of any further potential
losses. Specific information has come to management’s
attention and as such management cannot estimate any further range
of possible losses. Should additional facts be discovered in the
future and/or should actual fines or other penalties substantially
differ from the Company’s estimates, its business, financial
condition, cash flows and results of operations would be materially
negatively impacted.
  (was, 2012-05-02, similarity 0.9706):
[0001193125-12-201585:note_history:9]
Based on the facts known to the Company to date, the Company recorded an expense of $1.6 million for this export compliance matter in fiscal 2010, which represents management's estimated exposure for fines in accordance with applicable accounting literature. This amount was calculated from information discovered through the Company's internal review and this loss is deemed to be probable and reasonably estimable. However, the Company also believes that it is reasonably possible that the loss may be higher, but the Company cannot reasonably estimate the range of any further potential losses. Specific information has come to management's attention based on which, management cannot estimate any further range of possible losses. Should additional facts be discovered in the future and/or should actual fines or other penalties substantially differ from the Company's estimates, its business, financial condition, cash flows and results of operations would be materially negatively impacted.

- added (2012-11-09):
[0001193125-12-463263:note_history:10]
Shareholder Class
Action Lawsuits

- added (2012-11-09):
[0001193125-12-463263:note_history:11]
Beginning on
September 7, 2012, two shareholder class action complaints
were filed against the Company, certain of its officers and
directors and the underwriters of the Company’s initial
public offering in the United States District Court for the
Northern District of California. The complaints purport to
bring claims under the Securities Act of 1933, the Securities
Exchange Act of 1934 and SEC Rule 10b-5 on behalf a class of
purchasers of the Company’s common stock from
October 14, 2011 through August 9, 2012 and/or who
acquired the Company’s stock pursuant to or traceable to the
registration statement for the initial public offering. The
complaints seek, among other things, compensatory damages,
rescission, and attorneys’ fees and costs.

- added (2012-11-09):
[0001193125-12-463263:note_history:12]
The Company believes that
the allegations in the complaints are without merit and intend to
vigorously contest the litigation. However, there can be no
assurance that the Company will be successful in its defense. The
Company cannot currently estimate the loss or the range of possible
losses it may experience in connection with this
litigation.

- removed (2012-11-09):
[0001193125-12-201585:note_history:13]
In July 2011, the Company entered into an agreement to lease additional office space for its research and development offices in Taiwan. The lease term is from July 14, 2011 through July 15, 2016. The premises consist of approximately 10,000 rentable square feet of space. The lease has been categorized as an operating lease, and the total estimated rent expense to be recognized is $1.6 million.

- removed (2012-11-09):
[0001193125-12-201585:note_history:14]
Estimated rent expense to be recorded for the remainder of fiscal 2012 through fiscal 2016 and thereafter is as follows (in thousands):

- removed (2012-11-09):
[0001193125-12-201585:note_history:15]
The Company may be involved, from time to time, in a variety of claims, lawsuits, investigations and proceedings relating to contractual disputes, intellectual property rights, employment matters, regulatory compliance matters and other litigation matters relating to various claims that arise in the normal course of business. The Company determines whether an estimated loss from a contingency should be accrued by assessing whether a loss is deemed probable and can be reasonably estimated. The Company assesses its potential liability by analyzing specific litigation and regulatory matters using available information. The Company develops its views on estimated losses in consultation with inside and outside counsel, which involves a subjective analysis of potential results and outcomes, assuming various combinations of appropriate litigation and settlement strategies. Because of the uncertainties related to both the amount and ranges of possible loss from pending litigation matters, the Company is unable to predict with certainty the precise liability that could finally result from a range of possible unfavorable outcomes. Taking all of the above factors into account, the Company records an amount when it is probable that the Company will incur a loss and when that loss can be reasonably estimated. However, the Company's estimates may be incorrect and the Company could ultimately incur more or less than the amounts initially recorded. Litigation can be costly, diverting management's attention and could, upon resolution, have a material adverse effect on the Company's business, results of operations, financial condition and cash flows.


## us-gaap:BusinessDescriptionAndBasisOfPresentationTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2012-11-09):
[0001193125-12-463263:note_history:16]
Business—
Ubiquiti Networks, Inc. was incorporated in the State of California
in 2003 as Pera Networks, Inc. and commenced its current operations
in 2005 and changed its name to Ubiquiti Networks, Inc. at that
time. In June 2010, the Company changed its state of incorporation
to Delaware by merging with and into Ubiquiti Networks, Inc., a
Delaware corporation.

- changed (2012-11-09):
[0001193125-12-463263:note_history:17]
Ubiquiti Networks, Inc. and
its wholly owned subsidiaries (collectively, “Ubiquiti”
or the “Company”) is a product driven company that
leverages innovative proprietary technologies to deliver networking
solutions to both startup and established network operators and
service providers.
  (was, 2012-05-02, similarity 0.9579):
[0001193125-12-201585:note_history:17]
Ubiquiti Networks, Inc. and its wholly owned subsidiaries (collectively, "Ubiquiti" or the "Company") is a product driven company that leverages innovative proprietary technologies to deliver networking solutions to both startup and established network operators and service providers.

- changed (2012-11-09):
[0001193125-12-463263:note_history:18]
On October 13, 2011,
the Company entered into an underwriting agreement for its initial
public offering of its common stock at $15.00 per share, which
closed on October 19, 2011. Immediately prior to the closing
of the initial public offering, all outstanding shares of the
Company’s preferred stock converted to common stock on a one
for one basis.
  (was, 2012-05-02, similarity 0.997):
[0001193125-12-201585:note_history:18]
On October 13, 2011, the Company entered into an underwriting agreement for its initial public offering of its common stock at $15.00 per share, which closed on October 19, 2011. Immediately prior to the closing of the initial public offering, all outstanding shares of the Company's preferred stock converted to common stock on a one for one basis.

- changed (2012-11-09):
[0001193125-12-463263:note_history:19]
The Company operates on a
fiscal year ending June 30. In this Quarterly Report, the
fiscal year ended June 30, 2013 is referred to as
“fiscal 2013” and the fiscal year ending June 30,
2012 is referred to as “fiscal 2012.”
  (was, 2012-05-02, similarity 0.901):
[0001193125-12-201585:note_history:19]
The Company operates on a fiscal year ending June 30. In this Quarterly Report, the fiscal year ended June 30, 2011 is referred to as "fiscal 2011" and the fiscal year ending June 30, 2012 is referred to as "fiscal 2012."

- changed (2012-11-09):
[0001193125-12-463263:note_history:20]
Basis of
Presentation— The accompanying condensed consolidated
financial statements have been prepared in accordance with
accounting principles generally accepted in the United States of
America (“U.S. GAAP”) related to interim financial
statements based on applicable Securities and Exchange Commission
(“SEC”) rules and regulations. Accordingly, they do not
include all the information and footnotes required by U.S. GAAP for
complete financial statements. This information reflects all
adjustments, which are, in the opinion of the Company, of a normal
and recurring nature and necessary to state fairly the statements
of financial position, results of operations and cash flows for the
dates and periods presented. The June 30, 2012 balance sheet
was derived from the audited financial statements as of that date.
All significant intercompany transactions and balances have been
eliminated.
  (was, 2012-05-02, similarity 0.9294):
[0001193125-12-201585:note_history:20]
Basis of Presentation— The accompanying condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America ("U.S. GAAP") related to interim financial statements based on applicable Securities and Exchange Commission ("SEC") rules and regulations. Accordingly, they do not include all the information and footnotes required by U.S. GAAP for complete financial statements. This information reflects all adjustments, which are, in the opinion of the Company, of a normal and recurring nature and necessary to state fairly the statements of financial position, results of operations and cash flows for the dates and periods presented. The June 30, 2011 balance sheet was derived from the audited financial statements as of that date. All significant intercompany transactions and balances have been eliminated. The Company reclassified certain amounts reported in the previous period to conform to the current period presentation.

- added (2012-11-09):
[0001193125-12-463263:note_history:21]
These condensed
consolidated financial statements should be read in conjunction
with the Company’s audited consolidated financial statements
for the fiscal year ended June 30, 2012 included in its Annual
Report on Form 10-K, as filed on September 28, 2012 with the
SEC (the “Annual Report”). The results of operations
for the three months ended September 30, 2012 are not
necessarily indicative of the results to be expected for any future
periods.

- removed (2012-11-09):
[0001193125-12-201585:note_history:22]
Business—Ubiquiti Networks, Inc. was incorporated in the State of California in 2003 as Pera Networks, Inc. and commenced its current operations in 2005 and changed its name to Ubiquiti Networks, Inc. at that time. In June 2010, the Company changed its state of incorporation to Delaware by merging with and into Ubiquiti Networks, Inc., a Delaware corporation. At the same time the Company completed a four-for-one forward stock split of its outstanding common stock, and a proportional adjustment to the existing conversion ratio for preferred stock Series A. On October 3, 2011, the Company completed a 2.5-for-one forward stock split to its common and preferred stock for all stockholders of record as of October 3, 2011. Accordingly, all share and per share amounts for all periods presented in these condensed consolidated financial statements and notes thereto have been adjusted retroactively, where applicable, to reflect these forward stock splits and adjustment of the preferred stock conversion ratio.

- removed (2012-11-09):
[0001193125-12-201585:note_history:23]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets, liabilities and disclosures of contingent assets and liabilities at the date of the financial statements and the reported amounts of expenses during the reporting period. Actual results may differ from these estimates.

- removed (2012-11-09):
[0001193125-12-201585:note_history:24]
These condensed consolidated financial statements should be read in conjunction with the Company's audited consolidated financial statements for the fiscal year ended June 30, 2011 included in its Prospectus filed pursuant to Rule 424(b)(4), as filed on October 14, 2011 with the SEC. The results of operations for the three and nine months ended March 31, 2012 are not necessarily indicative of the results to be expected for any future periods.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2012-11-09):
[0001193125-12-463263:note_history:25]
The Company’s
significant accounting policies are disclosed in its audited
consolidated financial statements for the year ended June 30,
2012 included in the Annual Report.

- added (2012-11-09):
[0001193125-12-463263:note_history:26]
The Company does not
believe there have been any recent accounting pronouncements that
would have a significant impact on the Company’s financial
statements.

- removed (2012-11-09):
[0001193125-12-201585:note_history:27]
Use of Accounting Estimates

- removed (2012-11-09):
[0001193125-12-201585:note_history:28]
The preparation of financial statements in conformity with GAAP requires management to make estimates and judgments that affect the reported amounts of assets and liabilities and the disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenues and expenses during the reporting period. On an ongoing basis, the Company evaluates these estimates, including those related to allowance for doubtful accounts, inventory valuation, warranty costs, stock-based compensation, income taxes, the valuation of equity instruments, and commitments and contingencies, among others. The Company bases estimates on historical experience and on various other assumptions that are believed to be reasonable under the circumstances. Actual results may differ from these estimates.

- removed (2012-11-09):
[0001193125-12-201585:note_history:29]
Segments

- removed (2012-11-09):
[0001193125-12-201585:note_history:30]
Management has determined that it operates as one reportable and operating segment as it only reports financial information on an aggregate and consolidated basis to its chief executive officer, who is the Company's chief operating decision maker. See Note 13.

- removed (2012-11-09):
[0001193125-12-201585:note_history:31]
Recognition of Revenues

- removed (2012-11-09):
[0001193125-12-201585:note_history:32]
Revenues consist primarily of revenues from the sale of hardware and management tools, as well as the related implied post contract customer support ("PCS"). The Company recognizes revenues when persuasive evidence of an arrangement exists, delivery has occurred, the sales price is fixed or determinable and the collectability of the resulting receivable is reasonably assured. In cases where the Company lacks evidence that collectability of the resulting receivable is reasonably assured, it defers recognition of revenue until the receipt of cash. At March 31, 2012 and June 30, 2011, $2.5 million and $1.7 million, respectively, of revenues were deferred.

- removed (2012-11-09):
[0001193125-12-201585:note_history:33]
For substantially all of the Company's sales, evidence of the arrangement consists of an order from a distributor or customer. The Company considers delivery to have occurred once its products have been shipped and title and risk of loss have been transferred. For most of the Company's sales, these criteria are met at the time the products are transferred to the distributor. The Company's arrangements with distributors do not include provisions for cancellation, returns, inventory swaps or refunds that would significantly impact recognized revenues.

- removed (2012-11-09):
[0001193125-12-201585:note_history:34]
The Company records amounts billed to distributors for shipping and handling costs as revenues. The Company classifies shipping and handling costs incurred by it as cost of revenues.

- removed (2012-11-09):
[0001193125-12-201585:note_history:35]
Deposit payments received from distributors in advance of recognition of revenues are included in current liabilities on the Company's balance sheet and are recognized as revenues when all the criteria for recognition of revenues are met.

- removed (2012-11-09):
[0001193125-12-201585:note_history:36]
The Company's multi-element arrangements generally include two deliverables. The first deliverable is the hardware and software essential to the functionality of the hardware device delivered at the time of sale. The second deliverable is the implied right to PCS included with the purchase of certain products. PCS is this right to receive, on a when and if available basis, future unspecified software upgrades and features relating to the product's essential software as well as bug fixes, email and telephone support.

- removed (2012-11-09):
[0001193125-12-201585:note_history:37]
The Company uses a hierarchy to determine the allocation of revenues to the deliverables. The hierarchy is as follows: (i) vendor-specific objective evidence of fair value ("VSOE"), (ii) third-party evidence of selling price ("TPE"), and (iii) best estimate of the selling price ("BESP").

- removed (2012-11-09):
[0001193125-12-201585:note_history:38]
| (i) | VSOE generally exists only when a company sells the deliverable separately and is the price actually charged by the company for that deliverable. Generally the Company does not sell the deliverables separately and, as such, does not have VSOE. |

- removed (2012-11-09):
[0001193125-12-201585:note_history:39]
| (ii) | TPE can be substantiated by determining the price that other parties sell similar or substantially similar offerings. The Company does not believe that there is accessible TPE evidence for similar deliverables. |

- removed (2012-11-09):
[0001193125-12-201585:note_history:40]
| (iii) | BESP reflects the Company's best estimates of what the selling prices of elements would be if they were sold regularly on a stand-alone basis. The Company believes that BESP is the most appropriate methodology for determining the allocation of revenue among the multiple elements. |

- removed (2012-11-09):
[0001193125-12-201585:note_history:41]
The Company has allocated revenues between these two deliverables using the relative selling price method which is based on the estimated selling price for all deliverables. Revenues allocated to the delivered hardware and the related essential software are recognized at the time of sale provided the other conditions for recognition of revenues have been met. Revenues allocated to the PCS are deferred and recognized on a straight-line basis over the estimated life of each of these devices, which currently is two years. At March 31, 2012 and June 30, 2011, $780,000 and $497,000 of revenue was deferred in this way. All cost of revenues, including estimated warranty costs, are recognized at the time of sale. Costs for research and development and sales and marketing are expensed as incurred. If the estimated life of the hardware product should change, the future rate of amortization of the revenues allocated to PCS would also change.

- removed (2012-11-09):
[0001193125-12-201585:note_history:42]
The Company's process for determining BESP for deliverables involves multiple factors that may vary depending upon the unique facts and circumstances related to each deliverable. For PCS, the Company believes its network operators and service providers would be reluctant to pay for such services separately. This view is primarily based on the fact that unspecified upgrade rights do not obligate the Company to provide upgrades at a particular time or at all, and do not specify to network operators and service providers which upgrades or features will be delivered. The Company believes that the relatively low prices of its products and its network operators' and service providers' price sensitivity would add to their reluctance to pay for PCS. Therefore, the Company has concluded that if it were to sell PCS on a standalone basis, the selling price would be relatively low.

- removed (2012-11-09):
[0001193125-12-201585:note_history:43]
Key factors considered by the Company in developing the BESP for PCS include reviewing the activities of specific employees engaged in support and software development to determine the amount of time that is allocated to the development of the undelivered elements, determining the cost of this development effort, and then adding an appropriate level of gross profit to these costs.

- removed (2012-11-09):
[0001193125-12-201585:note_history:44]
Cash and Cash Equivalents

- removed (2012-11-09):
[0001193125-12-201585:note_history:45]
The Company considers investments purchased with a maturity period of three months or less at the date of purchase to be cash equivalents. At March 31, 2012 and June 30, 2011, the Company had cash and cash equivalents of $94.2 million and $76.4 million, respectively. Cash and cash equivalents are stated at cost which approximates fair value. The Company deposits cash and cash equivalents with financial institutions that management believes are of high credit quality. The Company's cash and cash equivalents consist primarily of U.S. dollar denominated money market funds and cash deposited in demand accounts.

- removed (2012-11-09):
[0001193125-12-201585:note_history:46]
Concentration of Risk

- removed (2012-11-09):
[0001193125-12-201585:note_history:47]
Financial instruments that potentially subject the Company to concentrations of credit risk consist of cash and cash equivalents and accounts receivable. The Company primarily places its temporary cash investments with high credit quality financial institutions which invest predominantly in U.S. money market funds. Deposits of cash outside the United States totaled $84.4 million and $29.6 million at March 31, 2012 and June 30, 2011, respectively. The Company would incur significant tax liabilities if it were to repatriate its non-U.S. deposits.

- removed (2012-11-09):
[0001193125-12-201585:note_history:48]
The Company derives its accounts receivable from revenues earned from customers located worldwide. The Company bases credit decisions primarily upon a customer's past credit history. The Company's standard credit terms are net 30 to 60 days.

- removed (2012-11-09):
[0001193125-12-201585:note_history:49]
The Company subcontracts with other companies to manufacture most of its products. The Company relies on the ability of these contract manufacturers to produce the products sold to its distributors and original equipment manufacturers ("OEMs"). A significant portion of the Company's products are manufactured by a single contract manufacturer at one location. If the Company's contract manufacturer were to lose production capabilities at this facility, the Company would experience delays in delivering products to its distributors and OEMs. The Company does not maintain long-term agreements with its contract manufacturers, which could lead to an inability of the Company to obtain its products in a timely fashion at prices consistent with those previously charged.

- removed (2012-11-09):
[0001193125-12-201585:note_history:50]
Inventory

- removed (2012-11-09):
[0001193125-12-201585:note_history:51]
Inventories consist primarily of raw materials that the Company consigns to its contract manufactures and, to a lesser extent, finished goods. Inventories are stated at the lower of cost or market value on a first-in, first-out basis. The Company reduces the value of its inventory for estimated obsolescence or lack of marketability by the difference between the cost of the affected inventory and the estimated market value and establishes a new cost basis.

- removed (2012-11-09):
[0001193125-12-201585:note_history:52]
Deferred Cost of Revenues

- removed (2012-11-09):
[0001193125-12-201585:note_history:53]
Deferred cost of revenues consist of the cost of product shipped to distributors for which the rights and obligations of ownership have passed to the distributor but revenues have not yet been recognized primarily because the collectability criterion for revenue recognition has not been fulfilled. The Company classifies those amounts as deferred cost of revenues. All deferred costs of revenues are stated at cost. The Company periodically assesses the recoverability of deferred cost of revenues and writes down the deferred cost of revenues balances to establish a new cost basis when recovery of deferred cost of revenues is not probable. The Company evaluates recoverability based on various factors including the length of time the product has been held at the distributor's site and the financial viability of the distributor.

- removed (2012-11-09):
[0001193125-12-201585:note_history:54]
Product Warranties

- removed (2012-11-09):
[0001193125-12-201585:note_history:55]
The Company offers warranties on certain products, generally for a period of one year, and records a liability for the estimated future costs associated with potential warranty claims. The warranty costs are reflected in the Company's consolidated statement of operations within cost of revenues. The warranties are typically in effect for 12 months from the distributor's purchase date of the product. The Company's estimate of future warranty costs is largely based on historical experience factors including product failure rates, material usage, and service delivery cost incurred in correcting product failures. In certain circumstances, the Company may have recourse from its contract manufacturers for replacement cost of defective products, which it also factors into its warranty liability assessment.

- removed (2012-11-09):
[0001193125-12-201585:note_history:56]
Redeemable Convertible Preferred Stock

- removed (2012-11-09):
[0001193125-12-201585:note_history:57]
On October 19, 2011, the Company's outstanding Series A preferred stock converted to common stock immediately prior to the closing of the Company's initial public offering. Prior to the conversion, upon the sixth anniversary of the issuance of Series A preferred stock, the holders of Series A preferred stock could require the Company to redeem such preferred stock out of legally available funds at the greater of (i) the Liquidation Value of $2.95 per share plus all accrued and unpaid dividends or (ii) the market price of the common stock issuable upon conversion of each share of Series A preferred stock into common stock, plus all accrued and unpaid dividends. Since the maximum redemption amount was contingent on the fair value of the equity security at the redemption date, the Company calculated accretion based on the fair value as of the balance sheet date prorated over the contractual life. The Company recorded $7.1 million of accretion in the three months ended March 31, 2011. The Company recorded $111.5 million and $11.1 million of accretion in the nine months ended March 31, 2012 and 2011, respectively. Due to the conversion immediately prior to the closing of the Company's initial public offering, no additional accretion will be recorded in future periods.

- removed (2012-11-09):
[0001193125-12-201585:note_history:58]
Allowance for Doubtful Accounts

- removed (2012-11-09):
[0001193125-12-201585:note_history:59]
The Company records an allowance for doubtful accounts for estimated probable losses on uncollectible accounts receivable. In estimating the allowance, management considers, among other factors, (i) the aging of the accounts receivable, including trends within the ratios involving the age of the accounts receivable, (ii) the Company's historical write-offs, (iii) the credit worthiness of each distributor based on payment history and (iv) general economic conditions. In cases where the Company is aware of circumstances that may impair a specific distributor's ability to meet its obligations to the Company, the Company records a specific allowance against amounts due from the distributor, and thereby reduces the net recognized receivable to the amounts it reasonably believes will be collected.

- removed (2012-11-09):
[0001193125-12-201585:note_history:60]
The allowance for doubtful accounts activity was as follows (in thousands):

- removed (2012-11-09):
[0001193125-12-201585:note_history:61]
|  |  | Nine months ended March 31, |  |
|  |  | 2012 |  |  | 2011 |  |
| Beginning balance |  | $ | 596 |  |  | $ | 800 |  |
| Charged to (released from) expenses |  |  | 815 |  |  |  | (200 | ) |
| Bad debt write-offs |  |  | (145 | ) |  |  | (4 | ) |
| Ending Balance |  | $ | 1,266 |  |  | $ | 596 |  |

- removed (2012-11-09):
[0001193125-12-201585:note_history:62]
Fair Value of Financial Instruments

- removed (2012-11-09):
[0001193125-12-201585:note_history:63]
The carrying value of the Company's cash equivalents, accounts receivable, accounts payable, debt and other current liabilities approximates fair value due to their short maturities. See Note 3.

- removed (2012-11-09):
[0001193125-12-201585:note_history:64]
Long Lived Assets

- removed (2012-11-09):
[0001193125-12-201585:note_history:65]
The Company evaluates its long lived assets including property and equipment for impairment whenever events or changes in circumstances indicate that the carrying value of these assets may not be recoverable. An impairment loss is recognized when the net book value of such assets exceeds the estimated future undiscounted cash flows attributable to the assets or asset group. If impairment is indicated, the asset is written down to its estimated fair value. The Company did not recognize any impairment losses for the three or nine month periods ended March 31, 2012 or 2011.

- removed (2012-11-09):
[0001193125-12-201585:note_history:66]
Property and Equipment

- removed (2012-11-09):
[0001193125-12-201585:note_history:67]
Furniture, fixtures and equipment are recorded at cost. The Company computes depreciation or amortization using the straight-line method over estimated useful lives, as follows:

- removed (2012-11-09):
[0001193125-12-201585:note_history:68]
|  |  | EstimatedUseful Life |
| Testing equipment |  | 3 to 5 years |
| Computer and other equipment |  | 3 to 5 years |
| Furniture and fixtures |  | 3 years |
| Leasehold improvements |  | shorter oflease term oruseful life |

- removed (2012-11-09):
[0001193125-12-201585:note_history:69]
Upon retirement or disposition, the asset cost and related accumulated depreciation are removed with any gain or loss recognized in the statement of operations. Expenditures for maintenance and repairs are charged to operations as incurred.

- removed (2012-11-09):
[0001193125-12-201585:note_history:70]
Depreciation expense was $167,000 and $54,000 for the three months ended March 31, 2012 and 2011, respectively. Depreciation expense was $394,000 and $135,000 for the nine months ended March 31, 2012 and 2011, respectively.

- removed (2012-11-09):
[0001193125-12-201585:note_history:71]
Leases

- removed (2012-11-09):
[0001193125-12-201585:note_history:72]
The Company leases its facilities under cancelable and noncancelable operating leases. For leases that contain rent escalation or rent concessions provisions, the Company records the total rent expense during the lease term on a straight-line basis over the term of the lease. The Company records the difference between the rent paid and the straight-line rent as a deferred rent liability in the accompanying consolidated balance sheets.

- removed (2012-11-09):
[0001193125-12-201585:note_history:73]
Income Taxes

- removed (2012-11-09):
[0001193125-12-201585:note_history:74]
The Company accounts for income taxes in accordance with accounting guidance which requires recognition of deferred tax assets and liabilities for the expected future tax consequences of events that have been included in its financial statements or tax returns. Deferred tax assets and liabilities are determined based on the temporary difference between the financial statement carrying amounts of existing assets and liabilities and their respective tax bases. Deferred tax assets and liabilities are measured using enacted tax rates expected to apply to taxable income in the years in which those temporary differences are expected to be recovered or settled. The Company establishes valuation allowances when necessary to reduce deferred tax assets to the amount it expects to realize. The assessment of whether or not a valuation allowance is required often requires significant judgment including current operating results, the forecast of future taxable income and ongoing prudent and feasible tax planning initiatives.

- removed (2012-11-09):
[0001193125-12-201585:note_history:75]
In addition, the Company's calculation of its tax liabilities involves dealing with uncertainties in the application of complex tax regulations. The Company may be subject to income tax audits in all of the jurisdictions in which it operates and, as a result, must also assess exposures to any potential issues arising from current or future audits of current and prior years' tax returns. Accordingly, the Company must assess such potential exposures and, where necessary, provide a reserve to cover any expected loss. To the extent that the Company establishes a reserve, its provision for income taxes would be increased. If the Company ultimately determines that payment of these amounts is unnecessary, it reverses the liability and recognizes a tax benefit during the period in which it determines that the liability is no longer necessary. The Company records an additional charge in its provision for taxes in the period in which it determines that tax liability is greater than its original estimate.

- removed (2012-11-09):
[0001193125-12-201585:note_history:76]
Stock-based Compensation

- removed (2012-11-09):
[0001193125-12-201585:note_history:77]
The Company records stock-based awards at fair value as of the grant date and recognizes expense ratably on a straight-line basis over the requisite service period, which is generally the vesting term of the awards. The Company estimates the fair value of stock option awards on the grant date using the Black-Scholes option pricing model. Restricted stock units ("RSUs") are valued based on the fair value of the Company's common stock on the date of grant. The Company adopted the above guidance using the modified prospective transition method. Under this transition method, the new fair value recognition provisions are applied to option grants on and after July 1, 2005. The Company expenses the fair value of all stock-based awards granted or modified after July 1, 2005 on a straight-line basis.

- removed (2012-11-09):
[0001193125-12-201585:note_history:78]
The Black-Scholes option pricing model used to determine the fair value of the Company's stock option awards requires a number of estimates and assumptions. In valuing share-based awards under the fair value accounting method, significant judgment is required in determining the expected volatility of the Company's common stock and the expected term individuals will hold their share-based awards prior to exercising. The expected volatility of the Company's common stock is based on the volatility of a group of comparable companies, as the Company does not have sufficient historical data with regards to the volatility of its stock. The expected term of options granted represents the period of time that the Company expects the options granted to be outstanding. The Company calculates the expected term as the average of the option vesting and contractual terms. In the future, as the Company gains sufficient historical data for volatility in its common stock and the actual term for which its options are held, the expected volatility and expected term may change, which could substantially change the grant date fair value of future awards of stock options and ultimately the expense it records. In addition, the estimation of stock-based awards that will ultimately vest requires judgment and to the extent actual results differ from the Company's estimates, these amounts will be recorded as an adjustment in the period estimates are revised.

- removed (2012-11-09):
[0001193125-12-201585:note_history:79]
Commitments and Contingencies

- removed (2012-11-09):
[0001193125-12-201585:note_history:80]
The Company periodically evaluates all pending or threatened contingencies and any commitments, if any, that are reasonably likely to have a material adverse effect on its results of operations, financial position or cash flows. The Company assesses the probability of an adverse outcome and determines if it is remote, reasonably possible or probable. If information available prior to the issuance of the Company's financial statements indicates that it is probable that an asset had been impaired or a liability had been incurred at the date of the Company's financial statements, and the amount of the loss, or the range of probable loss can be reasonably estimated, then such loss is accrued and charged to operations. If no accrual is made for a loss contingency because one or both of the conditions pursuant to the accounting guidance are not met, but the probability of an adverse outcome is at least reasonably possible, the Company will disclose the nature of the contingency and provide an estimate of the possible loss or range of loss, or state that such an estimate cannot be made.

- removed (2012-11-09):
[0001193125-12-201585:note_history:81]
Foreign Currency Translation

- removed (2012-11-09):
[0001193125-12-201585:note_history:82]
The functional currency of the Company and its subsidiaries is the U.S. dollar. For foreign operations, local currency denominated assets and liabilities are remeasured at the period end exchange rates, and revenues, costs and expenses are remeasured at the average exchange rates during the fiscal year. Foreign exchange gains and losses have been immaterial to the Company's results of operations to date.

- removed (2012-11-09):
[0001193125-12-201585:note_history:83]
Deferred Offering Costs

- removed (2012-11-09):
[0001193125-12-201585:note_history:84]
Deferred offering costs, consisting of legal, accounting and other fees and costs relating to the initial public offering were capitalized. Deferred offering costs of $3.1 million were offset against initial public offering proceeds upon the closing of the offering in October 2011. There were $2.1 million of deferred offering costs capitalized as of June 30, 2011.

- removed (2012-11-09):
[0001193125-12-201585:note_history:85]
Research and Development Costs and Capitalized Software Development Costs

- removed (2012-11-09):
[0001193125-12-201585:note_history:86]
Research and development expenses consist primarily of salary and benefit expenses, including stock-based compensation, for employees and contractors engaged in research, design and development activities, as well as costs for prototypes, facilities and travel costs.

- removed (2012-11-09):
[0001193125-12-201585:note_history:87]
Software development costs, including costs incurred to purchase third party software, begin to be capitalized when the Company has determined that certain factors are present, including among others, that technology exists to achieve the performance requirements. The accumulation of software costs to be capitalized ceases when the software is substantially developed and is ready for its intended use. Capitalized costs are amortized on a straight-line basis over the estimated useful life of the software once it is available for use. To date, the Company has not capitalized research and development costs associated with software development as products and enhancements have reached technological feasibility and have been released to customers at substantially the same time.

- removed (2012-11-09):
[0001193125-12-201585:note_history:88]
Earnings Per Share

- removed (2012-11-09):
[0001193125-12-201585:note_history:89]
Basic earnings per share ("EPS") is computed using the weighted-average number of common shares outstanding during the period. Diluted EPS is computed using the weighted-average number of common shares and dilutive potential common shares outstanding during the period under the treasury stock method. For the three months ended March 31, 2012, the Company applied the treasury stock method for calculating and presenting diluted EPS as there were no participating securities outstanding during the period. The treasury stock method assumes that the proceeds that the Company receives from an in-the-money option exercise are used to repurchase common shares in the market. For the three months ended March 31, 2011 and the nine months ended March 31, 2012 and 2011, the Company applied the two-class method for calculating and presenting EPS. Under the two-class method, net income is allocated between shares of common stock and other participating securities based on their participating rights. Participating securities are defined as securities that participate in dividends with common stock according to a pre-determined formula or a contractual obligation to share in the income of the entity. Basic EPS is computed by dividing net income available to common stockholders by the weighted average number of shares of common stock outstanding during the period. Diluted EPS is computed by dividing the amount of net income available to common stockholders outstanding plus income allocable to participating securities, to the extent they are dilutive, by the weighted average number of shares of common stock and potential dilutive shares outstanding during the period if the effect is dilutive. The Company's potentially dilutive common shares include outstanding stock options, restricted stock units and preferred stock.

- removed (2012-11-09):
[0001193125-12-201585:note_history:90]
Effective January 1, 2010, the Company adopted the Financial Accounting Standards Board's ("FASB's") updated authoritative guidance on fair value measurements and disclosures. The updated guidance requires additional disclosures regarding fair value measurements, amends disclosures about postretirement benefits plan assets and provides clarification regarding the level of disaggregation of fair value disclosures by investment class. This guidance became effective for interim and annual reporting periods beginning after December 15, 2009, except for certain Level 3 activity disclosure requirements that became effective for reporting periods beginning after December 15, 2010. Accordingly, the Company adopted the updated guidance beginning January 1, 2010, except for the additional Level 3 requirements, which the Company adopted beginning January 1, 2011. Level 3 assets and liabilities are those whose fair value inputs are unobservable and reflect management's best estimate of what market participants would use in pricing the asset or liability at the measurement date. The adoption of this guidance did not have a material impact on the Company's consolidated financial statements.

- removed (2012-11-09):
[0001193125-12-201585:note_history:91]
Additionally, in May 2011 the FASB further amended its guidance related to fair value measurements in order to achieve common fair value measurements between U.S. GAAP and International Financial Reporting Standards. The amendments in the updated guidance explain how to measure fair value. They do not require additional fair value measurements and are not intended to establish valuation standards or affect valuation practices outside of financial reporting. The amendments change the wording used to describe many of the requirements in U.S. GAAP for measuring fair value and for disclosing information about fair value measurements. For many of the requirements, the updated guidance should not result in a change in the application of previous fair value measurement guidance. The updated guidance is effective during interim and annual periods beginning after December 15, 2011. The adoption of the amended guidance on January 1, 2012 did not have an impact on the Company's consolidated financial statements.

- removed (2012-11-09):
[0001193125-12-201585:note_history:92]
In June 2011, the FASB updated its guidance related to the presentation of comprehensive income. Under the updated guidance, an entity has the option to present the total of comprehensive income, the components of net income, and the components of other comprehensive income either in a single continuous statement of comprehensive income or in two separate but consecutive statements. In both choices, an entity is required to present each component of net income along with total net income, each component of other comprehensive income along with a total for other comprehensive income, and a total amount for comprehensive income. The updated guidance eliminates the option to present the components of other comprehensive income as part of the statement of changes in stockholders' equity. The amendments in the updated guidance do not change the items that must be reported in other comprehensive income or when an item of other comprehensive income must be reclassified to net income. In December 2011, the FASB further amended its guidance to defer changes related to the presentation of reclassification adjustments indefinitely as a result of concerns raised by stakeholders that the new presentation requirements would be difficult for preparers and add unnecessary complexity to financial statements. The updated guidance, other than the portion related to the presentation of reclassification adjustments, will be effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2011, with early adoption permitted. The updated guidance must be applied retrospectively. The Company does not expect the adoption of the guidance on July 1, 2012 to have an impact on its consolidated financial statements.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2012-11-09):
[0001193125-12-463263:note_history:93]
In July 2011, the Company
repurchased an aggregate of 12,041,700 shares of the
Company’s Series A convertible preferred stock from entities
affiliated with Summit Partners, L.P., one of the Company’s
major stockholders, at a price of $8.97 per share for an aggregate
consideration of $108.0 million. Of the aggregate purchase price,
$40.0 million was paid in cash at the time of closing and the
balance of the shares were paid for through the issuance of
convertible subordinated promissory notes in the aggregate
principal amount of $68.0 million. On September 15, 2011,
$34.0 million was paid against the notes reducing the aggregate
principal amount outstanding to $34.0 million. The remainder of the
notes were retired in October 2011 with the proceeds of the
Company’s initial public offering and existing cash balances.
The interest rate on the notes started at 5% per annum and
increased by two percentage points every three months until it
would have reached 9% in January 2012. The notes were prepayable
without penalty prior to April 21, 2012, and were required to
be paid in the event of the Company’s initial public offering
or third party financing prior to April 21, 2012. The notes
matured on July 21, 2021. The unpaid principal on the notes
was convertible into shares of Series A preferred stock at $8.97
per share at any point after July 21, 2012. The difference
between the repurchase price and the carrying value of the
repurchased preferred stock on June 30, 2011 was $59.0
million. The difference was debited to available retained earnings
with the remaining amount debited to additional paid-in capital and
reduced the net income attributable to common stock shareholders
resulting in a reduction of basic and diluted net income per
share.
  (was, 2012-05-02, similarity 0.9976):
[0001193125-12-201585:note_history:93]
In July 2011, the Company repurchased an aggregate of 12,041,700 shares of the Company's Series A convertible preferred stock from entities affiliated with Summit Partners, L.P., one of the Company's major stockholders, at a price of $8.97 per share for an aggregate consideration of $108.0 million. Of the aggregate purchase price, $40.0 million was paid in cash at the time of closing and the balance of the shares were paid for through the issuance of convertible subordinated promissory notes in the aggregate principal amount of $68.0 million. On September 15, 2011, $34.0 million was paid against the notes reducing the aggregate principal amount outstanding to $34.0 million. The remainder of the notes were retired in October 2011 with the proceeds of the Company's initial public offering and existing cash balances. The interest rate on the notes started at 5% per annum and increased by two percentage points every three months until it would have reached 9% in January 2012. The notes were prepayable without penalty prior to April 21, 2012, and were required to be paid in the event of the Company's initial public offering or third party financing prior to April 21, 2012. The notes matured on July 21, 2021. The unpaid principal on the notes was convertible into shares of Series A preferred stock at $8.97 per share at any point after July 21, 2012. The difference between the repurchase price and the carrying value of the repurchased preferred stock on June 30, 2011 was $59.0 million. The difference was debited to available retained earnings with the remaining amount debited to additional paid-in capital and reduced the net income attributable to common stock shareholders resulting in a reduction of basic and diluted net income per share.

- changed (2012-11-09):
[0001193125-12-463263:note_history:94]
On September 15, 2011,
the Company entered into a Loan and Security Agreement with East
West Bank, (the “EWB Loan Agreement”). The credit
facilities available under the EWB Loan Agreement consist of a
$35.0 million term loan facility and a $5.0 million revolving line
of credit facility. The term loan matures on September 15,
2016 with principal and interest to be repaid in 60 monthly
installments. The Company used $34.0 million of the term loan to
repay a portion of the outstanding convertible subordinated
promissory notes held by entities affiliated with Summit Partners,
L.P. leaving an aggregate amount owed under the promissory note of
$34.0 million. The $5.0 million revolving line of credit may be
drawn at any time prior to September 15, 2013. The amounts
outstanding under both the term loan and the revolving line of
credit facility may be voluntarily prepaid at any time without
premium or penalty, subject to certain conditions. Interest will
accrue on the outstanding principal amount of the term loan at a
rate per annum equal to an adjusted LIBOR rate (based on one, two
or three month interest periods) plus a spread of either 2.50% or
3.00%, which spread shall be determined based on the debt service
ratio for the preceding four fiscal quarter period. Interest will
accrue on the drawn portion of the revolving credit facility at the
prime rate plus a spread of 0.25%, provided that such rate shall
not be less than the one-month adjusted LIBOR rate plus a spread of
1.00%, and will be paid monthly. The Company is required to pay a
commitment fee of 0.15% per annum on the undrawn portion of
the revolving credit facility on a quarterly basis. The EWB Loan
Agreement includes customary covenants, including financial
reporting requirements and compliance with a debt service coverage
ratio and a total leverage ratio, and customary events of default.
The Company’s obligations under the EWB Loan Agreement are
secured by a first priority security position on substantially all
of the Company’s current and future assets, subject to
certain exceptions (including a negative pledge on the
Company’s intellectual property) and permitted
liens.
  (was, 2012-05-02, similarity 0.9056):
[0001193125-12-201585:note_history:94]
On September 15, 2011, the Company entered into a Loan and Security Agreement with East West Bank, (the "EWB Loan Agreement"). The credit facilities available under the EWB Loan Agreement consist of a $35.0 million term loan facility and a $5.0 million revolving line of credit facility. The term loan matures on September 15, 2016 with principal and interest to be repaid in 60 monthly installments. The Company used $34.0 million of the term loan to repay a portion of the outstanding convertible subordinated promissory notes held by entities affiliated with Summit Partners, L.P. The $5.0 million revolving line of credit may be drawn at any time prior to September 15, 2013. The amounts outstanding under both the term loan and the revolving line of credit facility may be voluntarily prepaid at any time without premium or penalty, subject to certain conditions. Interest will accrue on the outstanding principal amount of the term loan at a rate per annum equal to an adjusted LIBOR rate (based on one, two or three month interest periods) plus a spread of either 2.50% or 3.00%, which spread shall be determined based on the debt service ratio for the preceding four fiscal quarter period. Interest will accrue on the drawn portion of the revolving credit facility at the prime rate plus a spread of 0.25%, provided that such rate shall not be less than the one-month adjusted LIBOR rate plus a spread of 1.00%, and will be paid monthly. The Company is required to pay a commitment fee of 0.15% per annum on the undrawn portion of the revolving credit facility on a quarterly basis. The EWB Loan Agreement includes customary covenants, including financial reporting requirements and compliance with a debt service coverage ratio and a total leverage ratio, and customary events of default. The Company's obligations under the EWB Loan Agreement are secured by a first priority security position on substantially all of the Company's current and future assets, subject to certain exceptions (including a negative pledge on the Company's intellectual property) and permitted liens. During the three and nine months ended March 31, 2012, the Company made aggregate payments of $1.7 million and $3.5 million, respectively, against the loan balance. As of March 31, 2012, the Company has classified $7.0 million and $24.4 million in short-term and long-term debt, respectively, on its consolidated balance sheet related to the EWB Loan Agreement.

- added (2012-11-09):
[0001193125-12-463263:note_history:95]
Additionally, on
August 7, 2012, the Company entered into a Loan and Security
Agreement (the “Loan Agreement”) with U.S. Bank, as
syndication agent, and East West Bank, as administrative agent. The
Loan Agreement replaces the EWB Loan Agreement as discussed above.
The Loan Agreement provides for (i) a $50.0 million revolving
credit facility, with a $5.0 million sublimit for the issuance of
letters of credit and a $5.0 million sublimit for the making of
swingline loan advances (the “Revolving Credit
Facility”), and (ii) a $50.0 million term loan facility
(the “Term Loan Facility”). The Company may request
borrowings under the Revolving Credit Facility until August 7,
2015. On August 7, 2012, the Company borrowed an additional
$20.8 million of term loans under the Term Loan
Facility.

- added (2012-11-09):
[0001193125-12-463263:note_history:96]
The loans bear interest, at
the Company’s option, at the base rate plus a spread of 1.25%
to 1.75% or an adjusted LIBOR rate (based, at the Company’s
election, on a period of 30, 60, or 90 days) plus a spread of 2.25%
to 2.75%, in each case with such spread being determined based on
the debt service coverage ratio for the last fiscal quarter. The
base rate means the highest of East West Bank’s prime rate,
the federal funds rate plus a margin equal to 0.50%, or the
adjusted LIBOR rate for a period of 30, 60, or 90 days plus a
margin equal to 1.00%. The Company is also obligated to pay other
customary closing fees, arrangement fees, administration fees,
commitment fees and letter of credit fees for a credit facility of
this size and type.

- added (2012-11-09):
[0001193125-12-463263:note_history:97]
Interest is due and payable
in arrears monthly in the case of loans bearing interest at the
base rate and at the end of an interest period (or quarterly in the
case of loans with interest periods greater than three months) in
the case of loans bearing interest at the adjusted LIBOR rate.
Principal payments under the Term Loan Facility will be made in
quarterly installments, each such quarterly installment shall be
equal to $1.25 million until August 7, 2014, then equal to
$1.875 million until August 7, 2015, and then equal to $2.5
million until August 7, 2017, subject to adjustment as a
result of any prepayments, with the remaining outstanding principal
balance and all accrued and unpaid interest due on August 7,
2017. All outstanding loans under the Revolving Credit Facility,
together with all accrued and unpaid interest, are due on
August 7, 2015.

- added (2012-11-09):
[0001193125-12-463263:note_history:98]
The Company may prepay the
loans, in whole or in part, at any time without premium or penalty,
subject to certain conditions including minimum amounts and
reimbursement of certain costs in the case of prepayments of LIBOR
loans. In addition, the Company is required to prepay the loan
under the Term Loan Facility with the proceeds from certain
financing transactions or asset sales (subject, in the case of
asset sales, to reinvestment rights) and with 25.0% of the
Company’s excess cash flow, as determined after each fiscal
year and in accordance with the Loan Agreement, provided that the
Company shall not be required to prepay the loan out of its excess
cash flow if its leverage ratio is greater than 1.50:1.00 on the
last day of such fiscal year.

- added (2012-11-09):
[0001193125-12-463263:note_history:99]
All of the obligations
under the Loan Agreement are secured by substantially all of the
Company’s assets, including all of the capital stock of the
Company’s future domestic subsidiaries and 65% of the capital
stock of the Company’s existing and future foreign
subsidiaries, but excluding the Company’s intellectual
property. All of the Company’s future domestic subsidiaries
are required to guaranty the obligations under the Loan Agreement.
Such guarantees by future subsidiaries will be secured by
substantially all of the property of such subsidiaries, excluding
intellectual property.

- added (2012-11-09):
[0001193125-12-463263:note_history:100]
The Loan Agreement contains
customary affirmative and negative covenants, including covenants
that limit or restrict the Company and its subsidiaries’
ability to, among other things, incur indebtedness, grant liens,
merge or consolidate, dispose of assets, pay dividends or make
distributions, make investments, make acquisitions, prepay certain
indebtedness, change the nature of its business, enter into certain
transactions with affiliates, enter into restrictive agreements,
and make capital expenditures, in each case subject to customary
exceptions for a credit facility of this size and type. The Company
is also required to maintain compliance with a debt service
coverage ratio, a leverage ratio, and a minimum level of
liquidity.

- added (2012-11-09):
[0001193125-12-463263:note_history:101]
The Loan Agreement includes
customary events of default that, include among other things,
non-payment defaults, defaults due to the inaccuracy of
representations and warranties, covenant defaults, cross default to
material indebtedness, bankruptcy and insolvency defaults, material
judgment defaults, defaults due to the unenforceability of a
guaranty, and defaults due to circumstances that have or could have
a material adverse effect. The occurrence of an event of default
could result in the acceleration of the obligations under the Loan
Agreement. During the existence of an event of default, interest on
the obligations under the Loan Agreement could be increased by
2.00% above the otherwise applicable interest rate.

- added (2012-11-09):
[0001193125-12-463263:note_history:102]
During the three months
ended September 30, 2012, the Company made aggregate payments
of $583,000 against the loan balance. As of September 30,
2012, the Company has classified $5.0 million and $44.8 million in
short-term and long-term debt, respectively, on its consolidated
balance sheet related to the Loan Agreement.

- added (2012-11-09):
[0001193125-12-463263:note_history:103]
The following table
summarizes our estimated debt and interest payment obligations as
of September 30, 2012 (in thousands):

- added (2012-11-09):
[0001193125-12-463263:note_history:104]
|  |  | 2013 (remainder) |  |  | 2014 |  |  | 2015 |  |  | 2016 |  |  | 2017 |  |  | Thereafter |  |  | Total |  |
| Debt payment obligations |  | $ | 3,750 |  |  | $ | 5,000 |  |  | $ | 6,875 |  |  | $ | 9,375 |  |  | $ | 10,000 |  |  | $ | 15,000 |  |  | $ | 50,000 |  |
| Interest payments on debt payment obligations |  |  | 914 |  |  |  | 1,110 |  |  |  | 973 |  |  |  | 777 |  |  |  | 531 |  |  |  | 172 |  |  |  | 4,477 |  |
| Total |  | $ | 4,664 |  |  | $ | 6,110 |  |  | $ | 7,848 |  |  | $ | 10,152 |  |  | $ | 10,531 |  |  | $ | 15,172 |  |  | $ | 54,477 |  |


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: no_prior_note, score: 0.0

- added (2012-11-09):
[0001193125-12-463263:note_history:105]
The following table
summarizes our estimated debt and interest payment obligations as
of September 30, 2012 (in thousands):

- added (2012-11-09):
[0001193125-12-463263:note_history:106]
|  |  | 2013 (remainder) |  |  | 2014 |  |  | 2015 |  |  | 2016 |  |  | 2017 |  |  | Thereafter |  |  | Total |  |
| Debt payment obligations |  | $ | 3,750 |  |  | $ | 5,000 |  |  | $ | 6,875 |  |  | $ | 9,375 |  |  | $ | 10,000 |  |  | $ | 15,000 |  |  | $ | 50,000 |  |
| Interest payments on debt payment obligations |  |  | 914 |  |  |  | 1,110 |  |  |  | 973 |  |  |  | 777 |  |  |  | 531 |  |  |  | 172 |  |  |  | 4,477 |  |
| Total |  | $ | 4,664 |  |  | $ | 6,110 |  |  | $ | 7,848 |  |  | $ | 10,152 |  |  | $ | 10,531 |  |  | $ | 15,172 |  |  | $ | 54,477 |  |
