# UI 8-K — 0001193125-12-460665 filed 2012-11-08

## item codes, every 8-K on or before 2012-11-09

- 2012-11-08 0001193125-12-460665 — 2.02, 9.01
- 2012-10-10 0001193125-12-420015 — 5.02, 9.01
- 2012-08-13 0001193125-12-352624 — 1.01, 2.03, 9.01
- 2012-08-09 0001193125-12-347776 — 1.01, 9.01
- 2012-08-09 0001193125-12-347732 — 2.02, 9.01
- 2012-05-01 0001193125-12-201012 — 2.02, 9.01
- 2012-03-30 0001193125-12-144074 — 5.02
- 2012-03-27 0001193125-12-134395 — 5.02, 9.01
- 2012-03-22 0001193125-12-127536 — 5.02
- 2012-01-31 0001193125-12-032079 — 2.02, 9.01
- 2011-12-27 0001193125-11-353002 — 1.01, 9.01
- 2011-12-06 0001193125-11-332192 — 5.02
- 2011-11-10 0001193125-11-306969 — 2.02, 9.01

## late-filing notifications on or before 2012-11-09

- none on or before 2012-11-09

## item 2.02 — earnings release, exhibit 99.1

[0001193125-12-460665:8k_2_02:1]
EX-99.1
2
d436192dex991.htm
PRESS RELEASE OF UBIQUITI NETWORKS, INC.

[0001193125-12-460665:8k_2_02:2]
Press Release of Ubiquiti Networks, Inc.

[0001193125-12-460665:8k_2_02:3]
Exhibit 99.1

[0001193125-12-460665:8k_2_02:4]
Contact:

[0001193125-12-460665:8k_2_02:5]
The Abernathy MacGregor Group

[0001193125-12-460665:8k_2_02:6]
Ian Campbell / idc@abmac.com / 213-630-6550

[0001193125-12-460665:8k_2_02:7]
Amy Feng / asf@abmac.com / 213-630-6550

[0001193125-12-460665:8k_2_02:8]
UBIQUITI NETWORKS REPORTS Q1 FISCAL 2013 RESULTS

[0001193125-12-460665:8k_2_02:9]
|  | • |  | New product category revenues up over 24% sequentially |

[0001193125-12-460665:8k_2_02:10]
|  | • |  | $23.7 million in net cash provided by operating activities |

[0001193125-12-460665:8k_2_02:11]
|  | • |  | Quarterly GAAP Diluted EPS of $0.14 and Non-GAAP Diluted EPS of $0.15 |

[0001193125-12-460665:8k_2_02:12]
|  | • |  | Improved outlook due to expected revenue recovery of airMAX |

[0001193125-12-460665:8k_2_02:13]
San Jose, Calif. — November 8, 2012 — Ubiquiti Networks, Inc. (NASDAQ:UBNT), a next-generation communications technology company, today announced results for the first quarter of fiscal
2013, ended September 30, 2012.

[0001193125-12-460665:8k_2_02:14]
For the first quarter of fiscal 2013, Ubiquiti reported revenues of $61.5 million, a decrease of 22%
compared to revenues of $79.2 million for the same period the prior year.

[0001193125-12-460665:8k_2_02:15]
For the first quarter of fiscal 2013, GAAP net income was $13.2
million, a decrease of 39% compared to GAAP net income of $21.5 million for the same period the prior year. Non-GAAP net income was $13.6 million, a decrease of 37% compared to $21.7 million for the same period last year.

[0001193125-12-460665:8k_2_02:16]
The following table reconciles GAAP net income to non-GAAP net income and weighted-average shares used in computing net income per share of common
stock-diluted to weighted-average shares used in computing non-GAAP Diluted EPS:

[0001193125-12-460665:8k_2_02:17]
|  |  | Three Months Ended September 30, |  |
|  |  | 2012 |  |  | 2011 |  |
|  |  | (in thousands, except per share data)(unaudited) |  |
| Net income |  | $ | 13,179 |  |  | $ | 21,493 |  |
| Stock-based compensation, net of taxes |  |  | 393 |  |  |  | 211 |  |
| Non-GAAP net income |  | $ | 13,572 |  |  | $ | 21,704 |  |
| Weighted-average shares used in computing net income per share of common stock- diluted |  |  | 92,925 |  |  |  | 62,717 |  |
| Weighted-average dilutive effect of stock options and restricted stock units |  |  | — |  |  |  | 3,877 |  |
| Weighted-average shares of Series A preferred shares outstanding |  |  | — |  |  |  | 26,873 |  |
| Weighted-average shares used in computing non-GAAP diluted EPS (1) |  |  | 92,925 |  |  |  | 93,467 |  |
| Non-GAAP diluted EPS (1) |  | $ | 0.15 |  |  | $ | 0.23 |  |

[0001193125-12-460665:8k_2_02:18]
| (1) | Non-GAAP Diluted EPS is calculated using non-GAAP net income excluding stock-based compensation, net of taxes and weighted-average shares outstanding as if Series A preferred stock is treated as common stock for the periods presented. |

[0001193125-12-460665:8k_2_02:19]
“Profitability, although down, has still remained
strong with a 27% operating margin, $0.15 earnings per share, and approximately $14 million of non-GAAP net-income, reflecting the robust fundamentals of our strong business model. We have made significant legal and operational infrastructure
improvements that

[0001193125-12-460665:8k_2_02:20]
have resulted in a series of anti-counterfeit success, decreased lead times, and a return of stronger order flow,” said Robert J. Pera, Founder and Chief Executive Officer of Ubiquiti
Networks. “Ubiquiti is not just about our AirMax wireless Internet distribution system. With our new product categories now accounting for 25% of our business, and up approximately 500% year over year, we are a fully diversified Internet
Protocol technology platforms company with exciting solutions for Wireless LAN (UniFi), Video Surveillance (AirVision), AirFiber (microwave backhaul), mFi (machine to machine communications), and EdgeMax (advanced routing). This company has a
history of demonstrating an extraordinary ability to dynamically evolve and conquer challenges. And to this end, we have made fundamental changes to our infrastructure to ensure our long-term success.”

[0001193125-12-460665:8k_2_02:21]
The Company also announced that its Chief Financial Officer, John Ritchie, plans to leave the Company to pursue other opportunities. The Company has
initiated a search for a new CFO. Mr. Ritchie plans to remain with the Company through December 31, 2012 to ensure a seamless transition.

[0001193125-12-460665:8k_2_02:22]
“I would like to extend my sincere thanks to John for his contributions to Ubiquiti and we wish him all the best in the future,” said Pera.

[0001193125-12-460665:8k_2_02:23]
Recent Highlights

[0001193125-12-460665:8k_2_02:24]
|  | • |  | In September, the Company released EdgeMax, a price/performance disruptive software and systems routing platform, offering what the company believes to be the world’s first sub-$100 router technology with greater than 1 million packet-per-second processing performance packed with powerful routing features. |

[0001193125-12-460665:8k_2_02:25]
|  | • |  | In October, AirFiber, the Company’s microwave backhaul solution, won the 2012 Wireless Internet Provider Association product of the year award. |

[0001193125-12-460665:8k_2_02:26]
|  | • |  | AirVision, the Company’s IP video surveillance platform has been re-architected and vastly upgraded with the release of the Company’s AirVision 2.0 NVR and management software. |

[0001193125-12-460665:8k_2_02:27]
Business Outlook

[0001193125-12-460665:8k_2_02:28]
Ubiquiti currently believes the demand environment in its end markets supports the following forecast for the Company’s fiscal second quarter ending December 31, 2012:

[0001193125-12-460665:8k_2_02:29]
|  | • |  | Revenues of $70 million to $78 million |

[0001193125-12-460665:8k_2_02:30]
|  | • |  | GAAP Diluted EPS of $0.18 to $0.21 |

[0001193125-12-460665:8k_2_02:31]
|  | • |  | Non-GAAP Diluted EPS of $0.17 to $0.20 |

[0001193125-12-460665:8k_2_02:32]
Conference Call

[0001193125-12-460665:8k_2_02:33]
Ubiquiti Networks will discuss the Company’s financial results by
conference call at 2:00 p.m. PDT today. Instructions for listening to the conference call over the Web are available on the investor relations portion of UBIQUITI NETWORKS’s website at www.ubnt.com.

[0001193125-12-460665:8k_2_02:34]
About Ubiquiti Networks

[0001193125-12-460665:8k_2_02:35]
Ubiquiti
Networks is a next-generation communications technology company bridging the digital divide between emerging and developed markets by fundamentally changing the economics and complexity of deploying high performance networking solutions in
underserved and underpenetrated markets globally. Our

[0001193125-12-460665:8k_2_02:36]
technology platforms focus on delivering industry-leading performance, compelling price-performing characteristics and an unparalleled user experience. For more information visit
http://www.ubnt.com/.

[0001193125-12-460665:8k_2_02:37]
Use of Non-GAAP Financial Information

[0001193125-12-460665:8k_2_02:38]
To supplement our condensed consolidated financial results prepared under generally accepted accounting principles, or GAAP, we use non-GAAP measures of net income and earnings per diluted share that are
adjusted to exclude certain recurring costs, expenses and gains such as stock based compensation expense and the tax effects of these non-GAAP adjustments. In addition, our non-GAAP adjustments present shares of Series A preferred stock as if these
shares had been converted to common stock throughout the periods presented. Reconciliations of the adjustments to GAAP results for the three months ended September 30, 2012 and 2011 are provided below. In addition, an explanation of the ways in
which management uses non-GAAP financial information to evaluate its business, the substance behind management’s decision to use this non-GAAP financial information, the material limitations associated with the use of non-GAAP financial
information, the manner in which management compensates for those limitations, and the substantive reasons management believes that this non-GAAP financial information provides useful information to investors is included under “About our
Non-GAAP Net Income and Adjustments” after the tables below.

[0001193125-12-460665:8k_2_02:39]
These non-GAAP measures are not in accordance with or an alternative to
GAAP and may be materially different from other non-GAAP measures, including similarly titled non-GAAP measures, used by other companies. The presentation of this additional information should not be considered in isolation from, as a substitute
for, or superior to, net income or earnings per diluted share prepared in accordance with GAAP.

[0001193125-12-460665:8k_2_02:40]
Forward-looking statements are subject to certain risks and uncertainties that could cause our actual future results to differ
materially, or cause a material adverse impact on our results. Potential risks and uncertainties include, but are not limited to, fluctuations in our operating results; varying demand for our products due to the financial and operating condition of
our distributors and their customers, distributors inventory management practices and general economic conditions; impact of counterfeiting and our ability to contain that; our reliance on a limited number of distributors; inability of our contract
manufacturers and suppliers to meet our demand; our dependence on Qualcomm Atheros for chipsets without a short-term alternative; as we move into new markets competition from certain of our current or potential competitors who may be more
established in such markets; our ability to keep pace with technological and market developments; success and timing of new product introductions by us and the performance of our products generally; if we fail to effectively manage the significant
increase in our transactional sales volumes; we may become subject to warranty claims, product liability and product recalls; that a substantial majority of our sales are into countries outside the United States and we are subject to numerous U.S.
export control and economic sanctions laws; costs related to responding to government inquiries related to regulatory compliance; our reliance on the Ubiquiti Community; our reliance on certain key members of our management team, including our
founder and chief executive officer, Robert J. Pera; adverse tax-related matters such as tax audits, changes in our effective tax rate or new tax legislative proposals; whether the final determination of our income tax liability may be materially
different from our income tax provisions; the impact of any intellectual property litigation and claims for indemnification and litigation related to U.S. Securities laws and economic and political conditions in the United States and abroad. We
discuss these risks in greater detail under the heading “Risk Factors” and elsewhere in our Annual Report on Form 10-K for the year ended June 30, 2012 and other filings filed with the U.S. Securities and Exchange Commission (the
SEC), which are available at the SEC’s website at www.sec.gov. Copies may also be obtained by contacting Ubiquiti Networks’ Investor Relations Department, or by email at investor.relations@ubnt.com or Ubiquiti Networks’ Investor
Relations website at www.ubnt.com.

[0001193125-12-460665:8k_2_02:41]
Given these uncertainties, you should not place undue reliance on these forward-looking statements. Also,
forward-looking statements represent our management’s beliefs and assumptions only as of the date made. Ubiquiti Networks undertakes no obligation to update information contained in this press release. You should review our SEC filings
carefully and with the understanding that our actual future results may be materially different from what we expect.

[0001193125-12-460665:8k_2_02:42]
4

[0001193125-12-460665:8k_2_02:43]
Ubiquiti Networks Inc.

[0001193125-12-460665:8k_2_02:44]
Condensed Consolidated Statement of Operations

[0001193125-12-460665:8k_2_02:45]
(In thousands, except per share data)

[0001193125-12-460665:8k_2_02:46]
(Unaudited)

[0001193125-12-460665:8k_2_02:47]
|  |  | Three Months Ended September 30, |  |
|  |  | 2012 |  |  | 2011 |  |
| Revenues |  | $ | 61,535 |  |  | $ | 79,167 |  |
| Cost of revenues |  |  | 36,515 |  |  |  | 46,154 |  |
| Gross profit |  |  | 25,020 |  |  |  | 33,013 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Research and development |  |  | 4,711 |  |  |  | 3,369 |  |
| Sales, general and administrative |  |  | 4,534 |  |  |  | 2,144 |  |
| Total operating expenses |  |  | 9,245 |  |  |  | 5,513 |  |
| Income from operations |  |  | 15,775 |  |  |  | 27,500 |  |
| Interest expense and other, net |  |  | (86 | ) |  |  | (634 | ) |
| Income before provision for income taxes |  |  | 15,689 |  |  |  | 26,866 |  |
| Provision for income taxes |  |  | 2,510 |  |  |  | 5,373 |  |
| Net income |  | $ | 13,179 |  |  | $ | 21,493 |  |
| Preferred stock cumulative dividend and accretion of cost of preferred stock |  |  | — |  |  |  | (102,727 | ) |
| Net income (loss) attributable to common stockholders—diluted |  | $ | 13,179 |  |  | $ | (81,234 | ) |
| Net income (loss) per share of common stock: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.14 |  |  | $ | (1.30 | ) |
| Diluted |  | $ | 0.14 |  |  | $ | (1.30 | ) |
| Weighted average shares used in computing net income (loss) per share of common stock: |  |  |  |  |  |  |  |  |
| Basic |  |  | 90,970 |  |  |  | 62,717 |  |
| Diluted |  |  | 92,925 |  |  |  | 62,717 |  |

[0001193125-12-460665:8k_2_02:48]
5

[0001193125-12-460665:8k_2_02:49]
Ubiquiti Networks Inc.

[0001193125-12-460665:8k_2_02:50]
Reconciliation of GAAP Net Income to Non-GAAP Net Income

[0001193125-12-460665:8k_2_02:51]
(In thousands, except per
share data)

[0001193125-12-460665:8k_2_02:52]
(Unaudited)

[0001193125-12-460665:8k_2_02:53]
|  |  | Three Months Ended September 30, |  |
|  |  | 2012 |  |  | 2011 |  |
| Net income |  | $ | 13,179 |  |  | $ | 21,493 |  |
| Stock-based compensation: |  |  |  |  |  |  |  |  |
| Cost of revenues |  |  | 81 |  |  |  | 6 |  |
| Research and development |  |  | 266 |  |  |  | 116 |  |
| Sales, general and administrative |  |  | 309 |  |  |  | 229 |  |
| Tax effect of stock-based compensation |  |  | (263 | ) |  |  | (140 | ) |
| Non-GAAP net income |  | $ | 13,572 |  |  | $ | 21,704 |  |
| Non-GAAP diluted EPS (1) |  | $ | 0.15 |  |  | $ | 0.23 |  |
| Weighted-average shares used in non-GAAP diluted EPS (1) |  |  | 92,925 |  |  |  | 93,467 |  |

[0001193125-12-460665:8k_2_02:54]
| (1) | Non-GAAP Diluted EPS is calculated using non-GAAP net income excluding stock-based compensation, net of taxes and weighted-average shares outstanding as if Series A preferred stock is treated as common stock for the periods presented. |

[0001193125-12-460665:8k_2_02:55]
Ubiquiti Networks, Inc.

[0001193125-12-460665:8k_2_02:56]
Reconciliation of Weighted-Average Shares Used in Computing Net Income (Loss) Per Share of Common Stock-Diluted to Weighted-Average Shares Used In
Computing Non-GAAP Diluted EPS

[0001193125-12-460665:8k_2_02:57]
(In thousands, except per share data)

[0001193125-12-460665:8k_2_02:58]
(Unaudited)

[0001193125-12-460665:8k_2_02:59]
|  |  | Three Months Ended September 30, |  |
|  |  | 2012 |  |  | 2011 |  |
| Weighted-average shares used in computing net income(loss) per share of common stock- diluted |  |  | 92,925 |  |  |  | 62,717 |  |
| Add back: |  |  |  |  |  |  |  |  |
| Weighted-average dilutive effect of stock options and restricted stock units |  |  | — |  |  |  | 3,877 |  |
| Weighted-average shares of Series A preferred shares outstanding |  |  | — |  |  |  | 26,873 |  |
| Weighted-average shares used in computing non-GAAP diluted EPS |  |  | 92,925 |  |  |  | 93,467 |  |

[0001193125-12-460665:8k_2_02:60]
6

[0001193125-12-460665:8k_2_02:61]
Ubiquiti Networks Inc.

[0001193125-12-460665:8k_2_02:62]
Condensed Consolidated Balance Sheets

[0001193125-12-460665:8k_2_02:63]
(In thousands, except share amounts)

[0001193125-12-460665:8k_2_02:64]
(Unaudited)

[0001193125-12-460665:8k_2_02:65]
|  |  | September 30,2012 |  |  | June 30,2012(1) |  |
| Assets |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 132,486 |  |  | $ | 122,060 |  |
| Accounts receivable, net |  |  | 60,877 |  |  |  | 75,644 |  |
| Inventories |  |  | 7,632 |  |  |  | 7,734 |  |
| Current deferred tax asset |  |  | 882 |  |  |  | 882 |  |
| Prepaid expenses and other current assets |  |  | 2,428 |  |  |  | 1,577 |  |
| Total current assets |  |  | 204,305 |  |  |  | 207,897 |  |
| Property and equipment, net |  |  | 5,042 |  |  |  | 4,471 |  |
| Long-term deferred tax asset |  |  | 232 |  |  |  | 232 |  |
| Other long–term assets |  |  | 1,577 |  |  |  | 1,136 |  |
| Total assets |  | $ | 211,156 |  |  | $ | 213,736 |  |
| Liabilities, Convertible Preferred Stock and Stockholders’ Deficit |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Accounts payable |  | $ | 25,465 |  |  | $ | 26,450 |  |
| Customer deposits |  |  | 384 |  |  |  | 235 |  |
| Deferred revenues |  |  | 798 |  |  |  | 805 |  |
| Income taxes payable |  |  | 3,284 |  |  |  | 946 |  |
| Debt – short-term |  |  | 5,008 |  |  |  | 6,968 |  |
| Other current liabilities |  |  | 10,031 |  |  |  | 17,031 |  |
| Total current liabilities |  |  | 44,970 |  |  |  | 52,435 |  |
| Long–term taxes payable |  |  | 7,727 |  |  |  | 7,727 |  |
| Debt – long-term |  |  | 44,843 |  |  |  | 22,623 |  |
| Total liabilities |  |  | 97,540 |  |  |  | 82,785 |  |
| Stockholders’ deficit: |  |  |  |  |  |  |  |  |
| Common stock |  |  | 89 |  |  |  | 92 |  |
| Additional paid–in capital |  |  | 129,725 |  |  |  | 128,981 |  |
| Treasury stock |  |  | (100,770 | ) |  |  | (69,515 | ) |
| Retained earnings |  |  | 84,572 |  |  |  | 71,393 |  |
| Total stockholders’ deficit |  |  | 113,616 |  |  |  | 130,951 |  |
| Total liabilities, convertible preferred stock and stockholders’ deficit |  | $ | 211,156 |  |  | $ | 213,736 |  |

[0001193125-12-460665:8k_2_02:66]
| (1) | Derived from audited consolidated statements as of and for the year ended June 30, 2012. |

[0001193125-12-460665:8k_2_02:67]
7

[0001193125-12-460665:8k_2_02:68]
Ubiquiti Networks Inc.

[0001193125-12-460665:8k_2_02:69]
Revenue by Product Category and Geographical Area

[0001193125-12-460665:8k_2_02:70]
(In thousands)

[0001193125-12-460665:8k_2_02:71]
(Unaudited)

[0001193125-12-460665:8k_2_02:72]
|  |  | Three Months Ended September 30, |  |
|  |  | 2012 |  |  | 2011 |  |
| Revenue by Product Category |  |  |  |  |  |  |  |  |
| AirMax |  | $ | 32,057 |  |  | $ | 49,835 |  |
| New platforms |  |  | 15,628 |  |  |  | 2,734 |  |
| Other systems |  |  | 3,784 |  |  |  | 12,765 |  |
| Total systems |  |  | 51,469 |  |  |  | 65,334 |  |
| Embedded radio |  |  | 1,714 |  |  |  | 3,225 |  |
| Antennas/other |  |  | 8,352 |  |  |  | 10,608 |  |
| Total revenues |  | $ | 61,535 |  |  | $ | 79,167 |  |
| Revenue by Geographical Area |  |  |  |  |  |  |  |  |
| North America |  | $ | 20,361 |  |  | $ | 24,941 |  |
| South America |  |  | 10,243 |  |  |  | 19,835 |  |
| Europe, the Middle East and Africa |  |  | 23,144 |  |  |  | 24,783 |  |
| Asia Pacific |  |  | 7,787 |  |  |  | 9,608 |  |
| Total revenues |  | $ | 61,535 |  |  | $ | 79,167 |  |

[0001193125-12-460665:8k_2_02:73]
About our Non-GAAP Net Income and Adjustments

[0001193125-12-460665:8k_2_02:74]
Use of Non-GAAP Financial Information

[0001193125-12-460665:8k_2_02:75]
To
supplement our condensed consolidated financial results prepared under generally accepted accounting principles, or GAAP, we use non-GAAP measures of net income and earnings per diluted share that are GAAP net income and GAAP earnings per diluted
share adjusted to exclude certain recurring costs, expenses and gains.

[0001193125-12-460665:8k_2_02:76]
We believe that the presentation of non-GAAP net income and non-GAAP
earnings per diluted share provides important supplemental information regarding non-cash expenses, significant recurring items that we believe are important to understanding our financial, and business trends relating to our financial condition and
results of operations. Non-GAAP net income and non-GAAP earnings per diluted share are among the primary indicators used by management as a basis for planning and forecasting future periods and by management and our board of directors to determine
whether our operating performance has met specified targets and thresholds. Management uses non-GAAP net income and non-GAAP earnings per diluted share when evaluating operating performance because it believes that the exclusion of the items
described below, for which the amounts and/or timing may vary significantly depending upon the Company’s activities and other factors, facilitates comparability of the Company’s operating performance from period to period. We have chosen
to provide this information to investors so they can analyze our operating results in the same way that management does and use this information in their assessment of our business and the valuation of our Company.

[0001193125-12-460665:8k_2_02:77]
Use and Economic Substance of Non-GAAP Financial Measures used by Ubiquiti Networks

[0001193125-12-460665:8k_2_02:78]
We compute non-GAAP net income and non-GAAP diluted earnings per share by adjusting GAAP net income and GAAP earnings per diluted share to remove the impact of recurring stock-based compensation expense
and the tax effect of these adjustments. In addition, our non-GAAP diluted earnings per share is calculated using weighted-average shares outstanding as if Series A preferred stock outstanding had been converted to common stock throughout the
periods presented. Examples of items excluded from net income are:

[0001193125-12-460665:8k_2_02:79]
|  | • |  | Recurring charges and gains, including: |

[0001193125-12-460665:8k_2_02:80]
|  | • |  | Stock-based compensation expense is recognized in accordance with FASB Accounting Standards Codification, Topic 718, Stock Compensation. |

[0001193125-12-460665:8k_2_02:81]
|  | • |  | Tax effect of non-GAAP adjustments. After adjusting to exclude the items described above, we apply the principles of ASC 740, Income Taxes, to estimate the non-GAAP income tax provision. |

[0001193125-12-460665:8k_2_02:82]
Usefulness of Non-GAAP Financial Information to Investors

[0001193125-12-460665:8k_2_02:83]
These non-GAAP measures are not in accordance with or an alternative to GAAP and may be materially different from other non-GAAP measures, including
similarly titled non-GAAP measures, used by other companies. The presentation of this additional information should not be considered in isolation from, as a substitute for, or superior to, net income or earnings per diluted share prepared in
accordance with GAAP. Non-GAAP financial measures have limitations in that they do not reflect certain items that may have a material impact upon our reported financial results. We expect to continue to incur expenses of a nature similar to the
non-GAAP adjustments described above, and exclusion of these items from our non-GAAP net income and non-GAAP earnings per diluted share should not be construed as an inference that these costs are unusual, infrequent or non-recurring.

[0001193125-12-460665:8k_2_02:84]
For more information on the non-GAAP adjustments, please see the tables captioned “Reconciliation of GAAP Net Income to non-GAAP Net Income”
and “Reconciliation of Weighted-Average Shares Used in Computing Net Income (Loss) Per Share of Common Stock-Diluted to Weighted-Average Shares Used In Computing Non-GAAP Diluted EPS” included in this press release.
