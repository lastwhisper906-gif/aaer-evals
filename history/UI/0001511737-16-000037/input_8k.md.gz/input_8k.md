# UI 8-K — 0001415889-16-005749 filed 2016-05-05

## item codes, every 8-K on or before 2016-05-05

- 2016-05-05 0001415889-16-005749 — 2.02, 5.02, 8.01, 9.01
- 2016-02-04 0001415889-16-004613 — 2.02, 9.01
- 2015-12-18 0001415889-15-004120 — 3.01, 5.07
- 2015-11-05 0001415889-15-003599 — 2.02, 8.01, 9.01
- 2015-10-16 0001415889-15-003433 — 5.02
- 2015-08-06 0001571049-15-006288 — 2.02, 5.02, 8.01, 9.01
- 2015-05-07 0001511737-15-000016 — 2.02, 9.01
- 2015-04-23 0001415889-15-001433 — 2.02, 5.02, 9.01
- 2015-03-06 0001415889-15-000787 — 1.01, 1.02, 2.03, 9.01
- 2015-02-05 0001511737-15-000008 — 2.02, 9.01
- 2014-12-18 0001193125-14-446627 — 5.07
- 2014-11-06 0001511737-14-000029 — 2.02, 9.01
- 2014-09-30 0001193125-14-359060 — 7.01, 9.01
- 2014-08-07 0001511737-14-000021 — 2.02, 9.01
- 2014-05-08 0001511737-14-000016 — 2.02, 9.01
- 2014-04-17 0001193125-14-146710 — 7.01
- 2014-03-06 0001193125-14-084883 — 8.01
- 2014-02-06 0001511737-14-000005 — 2.02, 9.01
- 2013-12-16 0001193125-13-474388 — 5.07
- 2013-11-22 0001193125-13-451511 — 5.02
- 2013-11-07 0001511737-13-000018 — 2.02, 9.01
- 2013-10-28 0001193125-13-413414 — 5.02, 9.01
- 2013-10-18 0001193125-13-404111 — 5.02, 9.01
- 2013-08-08 0001511737-13-000009 — 2.02, 9.01
- 2013-05-09 0001511737-13-000004 — 2.02
- 2013-03-25 0001193125-13-124353 — 5.07
- 2013-03-08 0001193125-13-098334 — 5.02, 9.01
- 2013-02-07 0001193125-13-043701 — 2.02, 9.01
- 2012-12-28 0001193125-12-518487 — 1.01
- 2012-12-17 0001193125-12-503742 — 7.01, 9.01
- 2012-12-13 0001193125-12-501894 — 5.02
- 2012-11-16 0001193125-12-474083 — 5.02
- 2012-11-13 0001193125-12-467376 — 5.02
- 2012-11-08 0001193125-12-460665 — 2.02, 9.01
- 2012-10-10 0001193125-12-420015 — 5.02, 9.01
- 2012-08-13 0001193125-12-352624 — 1.01, 2.03, 9.01
- 2012-08-09 0001193125-12-347776 — 1.01, 9.01
- 2012-08-09 0001193125-12-347732 — 2.02, 9.01
- 2012-05-01 0001193125-12-201012 — 2.02, 9.01
- 2012-03-30 0001193125-12-144074 — 5.02
- 2012-03-27 0001193125-12-134395 — 5.02, 9.01
- 2012-03-22 0001193125-12-127536 — 5.02
- 2012-01-31 0001193125-12-032079 — 2.02, 9.01
- 2011-12-27 0001193125-11-353002 — 1.01, 9.01
- 2011-12-06 0001193125-11-332192 — 5.02
- 2011-11-10 0001193125-11-306969 — 2.02, 9.01

## late-filing notifications on or before 2016-05-05

- none on or before 2016-05-05

## item 2.02 — earnings release, exhibit 99.1

[0001415889-16-005749:8k_2_02:1]
EX-99
2
ex99-05052016_010540.htm

[0001415889-16-005749:8k_2_02:2]
ubiquity8kmay52016pr.htm

[0001415889-16-005749:8k_2_02:3]
UBIQUITI NETWORKS REPORTS THIRD QUARTER FISCAL 2016 FINANCIAL RESULTS

[0001415889-16-005749:8k_2_02:4]
~ Achieves Record Revenue and Earnings ~

[0001415889-16-005749:8k_2_02:5]
~ Non-GAAP Diluted EPS of $0.63 Per Share ~

[0001415889-16-005749:8k_2_02:6]
SAN JOSE, Calif. – May 5, 2016 - Ubiquiti Networks, Inc. (NASDAQ:UBNT) (“Ubiquiti” or the “Company”) today announced results for the third fiscal quarter of 2016, ended March 31, 2016.

[0001415889-16-005749:8k_2_02:7]
Third Quarter Fiscal 2016 Financial Summary

[0001415889-16-005749:8k_2_02:8]
| • | Revenues of $167.4 million |

[0001415889-16-005749:8k_2_02:9]
| • | GAAP gross profit of $82.5 million and non-GAAP gross profit of $82.4 million |

[0001415889-16-005749:8k_2_02:10]
| • | GAAP net income of $52.7 million and non-GAAP net income of $53.0 million |

[0001415889-16-005749:8k_2_02:11]
| • | GAAP diluted EPS of $0.62 and non-GAAP diluted EPS of $0.63 |

[0001415889-16-005749:8k_2_02:12]
| • | Cash of $502.5 million, up 11% year-over-year |

[0001415889-16-005749:8k_2_02:13]
Recent Financial Highlights

[0001415889-16-005749:8k_2_02:14]
| • | Enterprise Technology revenues increased 73% year-over-year and 36% sequentially, fueled by new UniFi® AC access points, UniFi Switch and other industry-leading products targeting the Enterprise market. |

[0001415889-16-005749:8k_2_02:15]
| • | Gross Margins increased 10% year-over-year, fueled by product mix, cost-reduction strategies and stable pricing. |

[0001415889-16-005749:8k_2_02:16]
| • | GAAP and Non-GAAP diluted EPS increased 35% and 34% year-over-year, respectively, demonstrating the scalability of Ubiquiti’s unique business model. |

[0001415889-16-005749:8k_2_02:17]
| • | Initiated a new stock repurchase program, authorizing the Company to repurchase up to $50 million of its common stock as disclosed in the Form 8-K filed on May 5, 2016. |

[0001415889-16-005749:8k_2_02:18]
Recent Product Highlights

[0001415889-16-005749:8k_2_02:19]
| • | Continued strong demand for our new UniFi AC access points which feature Wi-Fi 802.11ac technology in a refined industrial design and are ideal for cost-effective deployment of high-performance wireless networks. |

[0001415889-16-005749:8k_2_02:20]
| • | Introduced the UniFi 8- and 16-Port Gigabit Switches, devices that deliver powerful performance with their independent switching ports. Sharing a total of 150W PoE, these Ethernet ports offer 802.3af/at PoE+ or 24V passive PoE, and two SFP ports offer optical connectivity. |

[0001415889-16-005749:8k_2_02:21]
| • | Announced MPLS (Multi-Protocol Label Switching) for the EdgeRouter™ and EdgePoint™ Router series with a software release (v1.8.0). |

[0001415889-16-005749:8k_2_02:22]
| • | Released Next Gen HD UniFi Video Cameras. The UniFi® Video Camera G3 and G3 Dome cameras represent the next generation of the UniFi Video surveillance management system. They both record 1080p HD video, day or night, indoors or outdoors. |

[0001415889-16-005749:8k_2_02:23]
| • | Shipped the Scalable airFiber® X with the airFiber NxN, a thoughtfully engineered MIMO multiplexer designed for the global last-mile wireless industry. With expected range exceeding 200km+ and increased throughput of up to 2Gbps+, airFiber NxN is a technological leap in true long-range, carrier-class, backhaul technology for the world. |

[0001415889-16-005749:8k_2_02:24]
| • | Introduced the airFiber® AF 4X and AF-11X, full-duplex licensed spectrum backhaul radios with industry-leading spectral efficiency and TDD throughput. |

[0001415889-16-005749:8k_2_02:25]
-1-

[0001415889-16-005749:8k_2_02:26]
Financial Results Summary ($, in millions, except per share data)

[0001415889-16-005749:8k_2_02:27]
| Income statement highlights |  |  | F3Q16 |  |  |  | F2Q16 |  |  |  | F3Q15 |  |
| Revenues |  |  | 167.4 |  |  |  | 161.9 |  |  |  | 147.5 |  |
| Service Provider Technology |  |  | 96.3 |  |  |  | 109.6 |  |  |  | 106.3 |  |
| Enterprise Technology |  |  | 71.1 |  |  |  | 52.3 |  |  |  | 41.2 |  |
| Gross Profit |  |  | 82.5 |  |  |  | 79.0 |  |  |  | 66.0 |  |
| Gross Profit (%) |  |  | 49.3 | % |  |  | 48.8 | % |  |  | 44.7 | % |
| Total Operating Expenses |  |  | 22.4 |  |  |  | 22.6 |  |  |  | 20.7 |  |
| Income from Operations |  |  | 60.1 |  |  |  | 56.4 |  |  |  | 45.2 |  |
| GAAP Net Income |  |  | 52.7 |  |  |  | 49.5 |  |  |  | 41.1 |  |
| GAAP EPS (diluted) |  |  | 0.62 |  |  |  | 0.57 |  |  |  | 0.46 |  |
| Non-GAAP Net Income |  |  | 53.0 |  |  |  | 49.7 |  |  |  | 42.0 |  |
| Non-GAAP EPS (diluted) |  |  | 0.63 |  |  |  | 0.58 |  |  |  | 0.47 |  |

[0001415889-16-005749:8k_2_02:28]
Balance Sheet Highlights

[0001415889-16-005749:8k_2_02:29]
Total cash and cash equivalents as of March 31, 2016 were $502.5 million, compared with $496.7 million as of December 31, 2015.  We held $489.0 million of our $502.5 million of cash and cash equivalents in accounts of our subsidiaries outside of the United States.

[0001415889-16-005749:8k_2_02:30]
On February 3, 2016, the Company extinguished the full $50.0 million available of a stock repurchase program approved by the Board of Directors of the Company on November 6, 2015. The sequential increase in cash and cash equivalents during the third quarter of fiscal 2016 is net of $50 million in share repurchases as part of this share repurchase program, partially offset by draws of $33 million on our revolver.

[0001415889-16-005749:8k_2_02:31]
This quarter we saw days sales outstanding in accounts receivable ("DSO") of 41 days, compared with 37 days in the prior quarter, and 43 days in the third quarter of fiscal 2015.

[0001415889-16-005749:8k_2_02:32]
Appointment of CAO

[0001415889-16-005749:8k_2_02:33]
As disclosed in the Form 8-K filed on May 5, 2016, the Company appointed Kevin Radigan as Chief Accounting Officer effective May 3, 2016.  Mr. Radigan will perform the Company’s principal financial officer and principal accounting officer duties.

[0001415889-16-005749:8k_2_02:34]
Business Outlook

[0001415889-16-005749:8k_2_02:35]
Based on recent business trends, Ubiquiti currently believes the demand environment in its end markets supports the following forecast for the Company's fourth fiscal quarter ending June 30, 2016.  The following are Ubiquiti’s financial performance estimates for the fourth quarter of fiscal 2016:

[0001415889-16-005749:8k_2_02:36]
| • | Revenues between $170 million and $180 million |

[0001415889-16-005749:8k_2_02:37]
| • | GAAP diluted EPS of $0.60 - $0.66 |

[0001415889-16-005749:8k_2_02:38]
| • | Non-GAAP diluted EPS of $0.61 - $0.67 |

[0001415889-16-005749:8k_2_02:39]
-2-

[0001415889-16-005749:8k_2_02:40]
Conference Call Information

[0001415889-16-005749:8k_2_02:41]
Ubiquiti Networks will host a Q&A-only call to discuss the Company’s financial results at 2:00 p.m. Pacific Time today.  Management’s prepared remarks can be found on the Investor Relations section of the Ubiquiti Networks website, http://ir.ubnt.com/results.cfm.

[0001415889-16-005749:8k_2_02:42]
To listen to the Q&A call via telephone, dial (877) 291-1296 (U.S. toll-free) or (720) 259-9209 (International) to be connected to the call by an operator.  Participants should dial in at least 10 minutes prior to the start of the call.  Investors may also listen to a live webcast of the Q&A conference call by visiting the Investor Relations section of the Ubiquiti Networks website at http://ir.ubnt.com.

[0001415889-16-005749:8k_2_02:43]
A recording of the Q&A call will be available approximately two hours after the call concludes and will be accessible on the Investor Relations section of the Ubiquiti Networks website, http://ir.ubnt.com.

[0001415889-16-005749:8k_2_02:44]
About Ubiquiti Networks

[0001415889-16-005749:8k_2_02:45]
Ubiquiti Networks (Nasdaq:UBNT) is closing the digital divide by building network communication platforms for everyone and everywhere. With over 38 million devices sold worldwide, Ubiquiti is transforming under-networked enterprises and communities. Our leading edge platforms, airMAX®, UniFi®, airFiber®, UniFi® Video, mFi® and EdgeMAX®, combine innovative technology, disruptive price-to-performance and the support of a global user community to eliminate barriers to connectivity. For more information, join our community at http://www.ubnt.com.

[0001415889-16-005749:8k_2_02:46]
Ubiquiti, Ubiquiti Networks, the U logo, UBNT, airMAX, UniFi, airFiber, mFi, EdgeMAX and sunMAX are registered trademarks or trademarks of Ubiquiti Networks, Inc. in the United States and other countries.

[0001415889-16-005749:8k_2_02:47]
Investor Relations Contact

[0001415889-16-005749:8k_2_02:48]
Anne Fazioli

[0001415889-16-005749:8k_2_02:49]
Ubiquiti Networks, Vice President of Investor Relations

[0001415889-16-005749:8k_2_02:50]
IR@ubnt.com

[0001415889-16-005749:8k_2_02:51]
-3-

[0001415889-16-005749:8k_2_02:52]
Forward-looking statements are subject to certain risks and uncertainties that could cause our actual future results to differ materially, or cause a material adverse impact on our results.  Potential risks and uncertainties include, but are not limited to, fluctuations in our operating results; varying demand for our products due to the financial and operating condition of our distributors and their customers, and distributors' inventory management practices; political and economic conditions and volatility affecting the stability of business environments, economic growth, currency values, commodity prices and other factors that may influence the ultimate demand for our products in particular geographies or globally; impact of counterfeiting and our ability to contain such impact; our reliance on a limited number of distributors; inability of our contract manufacturers and suppliers to meet our demand; our dependence on Qualcomm Atheros for chipsets without a short-term alternative; as we move into new markets competition from certain of our current or potential competitors who may be more established in such markets; our ability to keep pace with technological and market developments; success and timing of new product introductions by us and the performance of our products generally; our ability to effectively manage the significant increase in our transactional sales volumes; we may become subject to warranty claims, product liability and product recalls; that a substantial majority of our sales are into countries outside the United States and we are subject to numerous U.S. export control and economic sanctions laws; costs related to responding to government inquiries related to regulatory compliance; our reliance on the Ubiquiti Community; our reliance on certain key members of our management team, including our founder and chief executive officer, Robert J. Pera; adverse tax-related matters such as tax audits, changes in our effective tax rate or new tax legislative proposals; whether the final determination of our income tax liability may be materially different from our income tax provisions; the impact of any intellectual property litigation and claims for indemnification; litigation related to U.S. Securities laws; and economic and political conditions in the United States and abroad.  We discuss these risks in greater detail under the heading “Risk Factors” and elsewhere in our Annual Report on Form 10-K for the year ended June 30, 2015, and subsequent filings filed with the U.S. Securities and Exchange Commission (the SEC), which are available at the SEC's website at www.sec.gov.  Copies may also be obtained by contacting the Ubiquiti Networks Investor Relations Department, by email at IR@ubnt.com or by visiting the Investor Relations section of the Ubiquiti Networks website, http://ir.ubnt.com.

[0001415889-16-005749:8k_2_02:53]
Given these uncertainties, you should not place undue reliance on these forward-looking statements.  Also, forward-looking statements represent our management's beliefs and assumptions only as of the date made.  Except as required by law, Ubiquiti Networks undertakes no obligation to update information contained herein.  You should review our SEC filings carefully and with the understanding that our actual future results may be materially different from what we expect.

[0001415889-16-005749:8k_2_02:54]
Use of Non-GAAP Financial Information

[0001415889-16-005749:8k_2_02:55]
To supplement our condensed consolidated financial results prepared under generally accepted accounting principles, or GAAP, we use non-GAAP measures of net income and earnings per diluted share that are adjusted to exclude certain costs, expenses and gains such as stock based compensation expense, Business e-mail compromise ("BEC") fraud loss/(recovery), implementation of overhead capitalization, reserve against vendor deposits relating to a purchase commitment termination fee and the tax effects of these non-GAAP adjustments.  Reconciliations of the adjustments to GAAP results for the three and nine months ended March 31, 2016 and 2015 are provided below.  In addition, an explanation of the ways in which management uses non-GAAP financial information to evaluate its business, the substance behind management's decision to use this non-GAAP financial information, material limitations associated with the use of non-GAAP financial information, the manner in which management compensates for those limitations, and the substantive reasons management believes that this non-GAAP financial information provides useful information to investors is included under "About our Non-GAAP Net Income and Adjustments" after the tables below.

[0001415889-16-005749:8k_2_02:56]
-4-

[0001415889-16-005749:8k_2_02:57]
| Ubiquiti Networks Inc. Condensed Consolidated Statement of Operations (In thousands, except per share data) (Unaudited) |
|  |  | Three Months Ended March 31, |  | Nine Months Ended March 31, |
|  |  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Revenues |  | $ | 167,433 |  |  | $ | 147,456 |  |  | $ | 480,719 |  |  | $ | 450,680 |  |
| Cost of revenues |  | 84,940 |  |  | 81,479 |  |  | 245,681 |  |  | 254,631 |  |
| Gross profit |  | 82,493 |  |  | 65,977 |  |  | 235,038 |  |  | 196,049 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Research and development |  | 13,820 |  |  | 15,236 |  |  | 42,810 |  |  | 39,893 |  |
| Sales, general and administrative |  | 8,538 |  |  | 5,510 |  |  | 24,113 |  |  | 16,568 |  |
| Business e-mail compromise (“BEC”) fraud loss/(recovery) |  | (3 | ) |  | — |  |  | (8,294 | ) |  | — |  |
| Total operating expenses |  | 22,355 |  |  | 20,746 |  |  | 58,629 |  |  | 56,461 |  |
| Income from operations |  | 60,138 |  |  | 45,231 |  |  | 176,409 |  |  | 139,588 |  |
| Interest expense and other, net |  | (510 | ) |  | (763 | ) |  | (1,277 | ) |  | (804 | ) |
| Income before provision for income taxes |  | 59,628 |  |  | 44,468 |  |  | 175,132 |  |  | 138,784 |  |
| Provision for income taxes |  | 6,929 |  |  | 3,331 |  |  | 19,222 |  |  | 13,639 |  |
| Net income and comprehensive income |  | $ | 52,699 |  |  | $ | 41,137 |  |  | $ | 155,910 |  |  | $ | 125,145 |  |
| Net income per share of common stock: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.63 |  |  | $ | 0.47 |  |  | $ | 1.83 |  |  | $ | 1.42 |  |
| Diluted |  | $ | 0.62 |  |  | $ | 0.46 |  |  | $ | 1.80 |  |  | $ | 1.40 |  |
| Weighted average shares used in computing net income per share of common stock: |  |  |  |  |  |  |  |  |
| Basic |  | 83,349 |  |  | 87,904 |  |  | 85,051 |  |  | 88,115 |  |
| Diluted |  | 84,685 |  |  | 89,400 |  |  | 86,433 |  |  | 89,707 |  |

[0001415889-16-005749:8k_2_02:58]
| Ubiquiti Networks Inc. Reconciliation of GAAP Net Income to Non-GAAP Net Income (In thousands, except per share data) (Unaudited) |
|  |  | Three Months Ended March 31, |  | Nine Months Ended March 31, |
|  |  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Net income and comprehensive income |  | $ | 52,699 |  |  | $ | 41,137 |  |  | $ | 155,910 |  |  | $ | 125,145 |  |
| Stock-based compensation: |  |  |  |  |  |  |  |  |
| Cost of revenues |  | 114 |  |  | 141 |  |  | 341 |  |  | 440 |  |
| Research and development |  | 566 |  |  | 810 |  |  | 1,770 |  |  | 2,499 |  |
| Sales, general and administrative |  | 202 |  |  | 425 |  |  | 755 |  |  | 1,240 |  |
| Purchase commitment termination fee |  | — |  |  | — |  |  | — |  |  | 5,500 |  |
| Business e-mail compromise (“BEC”) fraud loss/(recovery) |  | (3 | ) |  | — |  |  | (8,294 | ) |  | — |  |
| Implementation of overhead capitalization |  | (219 | ) |  | — |  |  | (1,213 | ) |  | — |  |
| Tax effect of Non-GAAP adjustments |  | (327 | ) |  | (550 | ) |  | (1,002 | ) |  | (2,331 | ) |
| Total Non-GAAP adjustments |  | 333 |  |  | 826 |  |  | (7,643 | ) |  | 7,348 |  |
| Non-GAAP net income |  | $ | 53,032 |  |  | $ | 41,963 |  |  | $ | 148,267 |  |  | $ | 132,493 |  |
| Non-GAAP diluted EPS |  | $ | 0.63 |  |  | $ | 0.47 |  |  | $ | 1.72 |  |  | $ | 1.48 |  |
| Weighted-average shares used in Non-GAAP diluted EPS |  | 84,685 |  |  | 89,400 |  |  | 86,433 |  |  | 89,707 |  |

[0001415889-16-005749:8k_2_02:59]
-5-

[0001415889-16-005749:8k_2_02:60]
| Ubiquiti Networks Inc. Condensed Consolidated Balance Sheets (In thousands, except share amounts) (Unaudited) |
|  |  | March 31, 2016 |  | June 30, 2015(1) |
| Assets |  |  |  |  |
| Current assets: |  |  |  |  |
| Cash and cash equivalents |  | $ | 502,549 |  |  | $ | 446,401 |  |
| Accounts receivable, net |  | 75,245 |  |  | 66,104 |  |
| Inventories |  | 42,776 |  |  | 37,031 |  |
| Vendor Deposits |  | 13,459 |  |  | 19,998 |  |
| Current deferred tax asset |  | 1,551 |  |  | 1,535 |  |
| Prepaid income taxes |  | — |  |  | 2,566 |  |
| Prepaid expenses and other current assets |  | 5,848 |  |  | 7,711 |  |
| Total current assets |  | 641,428 |  |  | 581,346 |  |
| Property and equipment, net |  | 13,127 |  |  | 15,602 |  |
| Long-term deferred tax asset |  | 1,538 |  |  | 1,515 |  |
| Other long-term assets |  | 2,261 |  |  | 2,109 |  |
| Total assets |  | $ | 658,354 |  |  | $ | 600,572 |  |
| Liabilities and Stockholders’ Equity |  |  |  |  |
| Current liabilities: |  |  |  |  |
| Accounts payable |  | $ | 29,696 |  |  | $ | 43,856 |  |
| Income taxes payable |  | 1,746 |  |  | 1,108 |  |
| Debt - short-term |  | 10,000 |  |  | 10,000 |  |
| Other current liabilities |  | 15,873 |  |  | 15,170 |  |
| Total current liabilities |  | 57,315 |  |  | 70,134 |  |
| Long-term taxes payable |  | 22,433 |  |  | 19,810 |  |
| Debt - long-term |  | 146,000 |  |  | 87,500 |  |
| Deferred revenues - long-term |  | 1,153 |  |  | 974 |  |
| Total liabilities |  | 226,901 |  |  | 178,418 |  |
| Stockholders’ equity: |  |  |  |  |
| Common stock |  | 83 |  |  | 87 |  |
| Additional paid–in capital |  | — |  |  | — |  |
| Treasury stock |  | — |  |  | — |  |
| Retained earnings |  | 431,370 |  |  | 422,067 |  |
| Total stockholders’ equity |  | 431,453 |  |  | 422,154 |  |
| Total liabilities and stockholders’ equity |  | $ | 658,354 |  |  | $ | 600,572 |  |

[0001415889-16-005749:8k_2_02:61]
(1) Derived from audited consolidated financial statements as of and for the year ended June 30, 2015.

[0001415889-16-005749:8k_2_02:62]
-6-

[0001415889-16-005749:8k_2_02:63]
| Ubiquiti Networks Inc. Revenues by Product Type (In thousands) (Unaudited) |
|  |  | Three Months Ended March 31, |  | Nine Months Ended March 31, |
|  |  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Service provider technology |  | $ | 96,326 |  |  | $ | 106,242 |  |  | $ | 309,341 |  |  | $ | 313,233 |  |
| Enterprise technology |  | 71,107 |  |  | 41,214 |  |  | 171,378 |  |  | 137,447 |  |
| Total revenues |  | $ | 167,433 |  |  | $ | 147,456 |  |  | $ | 480,719 |  |  | $ | 450,680 |  |

[0001415889-16-005749:8k_2_02:64]
| Ubiquiti Networks Inc. Revenues by Geographical Area (In thousands) (Unaudited) |
|  |  | Three Months Ended March 31, |  | Nine Months Ended March 31, |
|  |  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| North America |  | $ | 57,791 |  |  | $ | 45,692 |  |  | $ | 168,158 |  |  | $ | 153,400 |  |
| South America |  | 15,450 |  |  | 17,866 |  |  | 61,393 |  |  | 71,242 |  |
| Europe, the Middle East and Africa |  | 73,269 |  |  | 66,770 |  |  | 194,745 |  |  | 177,474 |  |
| Asia Pacific |  | 20,923 |  |  | 17,128 |  |  | 56,423 |  |  | 48,564 |  |
| Total revenues |  | $ | 167,433 |  |  | $ | 147,456 |  |  | $ | 480,719 |  |  | $ | 450,680 |  |

[0001415889-16-005749:8k_2_02:65]
About our Non-GAAP Net Income and Adjustments

[0001415889-16-005749:8k_2_02:66]
Use of Non-GAAP Financial Information

[0001415889-16-005749:8k_2_02:67]
To supplement our condensed consolidated financial results prepared under generally accepted accounting principles, or GAAP, we use non-GAAP measures of net income and earnings per diluted share that are GAAP net income and GAAP earnings per diluted share adjusted to exclude certain costs, expenses and gains/losses.

[0001415889-16-005749:8k_2_02:68]
We believe that the presentation of non-GAAP net income and non-GAAP earnings per diluted share provides important supplemental information regarding non-cash expenses, significant items that we believe are important to understanding our financial, and business trends relating to our financial condition and results of operations.  Non-GAAP net income and non-GAAP earnings per diluted share are among the primary indicators used by management as a basis for planning and forecasting future periods and by management and our board of directors to determine whether our operating performance has met specified targets and thresholds.  Management uses non-GAAP net income and non-GAAP earnings per diluted share when evaluating operating performance because it believes that the exclusion of the items described below, for which the amounts or timing may vary significantly depending upon the Company's activities and other factors, facilitates comparability of the Company's operating performance from period to period.  We have chosen to provide this information to investors so they can analyze our operating results in the same way that management does and use this information in their assessment of our business and the valuation of our Company.

[0001415889-16-005749:8k_2_02:69]
-7-

[0001415889-16-005749:8k_2_02:70]
Use and Economic Substance of Non-GAAP Financial Measures used by Ubiquiti Networks

[0001415889-16-005749:8k_2_02:71]
We compute non-GAAP net income and non-GAAP diluted earnings per share by adjusting GAAP net income and GAAP earnings per diluted share to remove the impact of certain adjustments and the tax effect of those adjustments.  Items excluded from net income are:

[0001415889-16-005749:8k_2_02:72]
| • | Stock-based compensation expense |

[0001415889-16-005749:8k_2_02:73]
| • | Business e-mail compromise ("BEC") fraud loss/(recovery) |

[0001415889-16-005749:8k_2_02:74]
| • | Implementation of overhead capitalization |

[0001415889-16-005749:8k_2_02:75]
| • | Reserve against vendor deposits relating to a purchase commitment termination fee |

[0001415889-16-005749:8k_2_02:76]
| • | Tax effect of non-GAAP adjustments, applying the principles of ASC 740 |

[0001415889-16-005749:8k_2_02:77]
Usefulness of Non-GAAP Financial Information to Investors

[0001415889-16-005749:8k_2_02:78]
These non-GAAP measures are not in accordance with, or an alternative to, GAAP and may be materially different from other non-GAAP measures, including similarly titled non-GAAP measures used by other companies.  The presentation of this additional information should not be considered in isolation from, as a substitute for, or superior to, net income or earnings per diluted share prepared in accordance with GAAP.  Non-GAAP financial measures have limitations in that they do not reflect certain items that may have a material impact upon our reported financial results.

[0001415889-16-005749:8k_2_02:79]
For more information on the non-GAAP adjustments, please see the table captioned “Reconciliation of GAAP Net Income to Non-GAAP Net Income” included in this press release.

[0001415889-16-005749:8k_2_02:80]
-8-

## item 5.02 — body, verbatim

[0001415889-16-005749:8k_body:1]
Item 5.02

[0001415889-16-005749:8k_body:2]
Departure of Directors or Certain Officers; Election of Directors; Appointment of Certain Officers; Compensatory Arrangements of Certain Officers.

[0001415889-16-005749:8k_body:3]
On May 3, 2016, the Company appointed Kevin Radigan as Chief Accounting Officer effective May 3, 2016. Effective as of such date, Mr. Radigan will also assume the roles of principal financial officer and principal accounting officer.

[0001415889-16-005749:8k_body:4]
Effective May 3, 2016 and in connection with the appointment of Mr. Radigan, Mark C. Spragg resigned from his position as Interim Chief Accounting Officer of the Company. Mr. Spragg will continue to provide accounting and advisory services to the Company pursuant to an agreement for advisory and interim management services between the Company and FTI Consulting, Inc., effective June 29, 2015. Mr. Spragg’s resignation was not due to any disagreement with the Company regarding its operations, financial reporting, policies or procedures.

[0001415889-16-005749:8k_body:5]
From January 2012 to March 2016, Mr. Radigan, 57, served as Chief Financial Officer at American Medical Alert Corp. (dba Tunstall Americas), a supplier of connected healthcare products and services, where he was responsible for the finance and accounting department.  Previously, Mr. Radigan served in various finance and accounting positions in the pharmaceutical and electronics industries. Mr. Radigan has a Bachelor of Science in Accountancy degree from Long Island University.

[0001415889-16-005749:8k_body:6]
Mr. Radigan will receive an annual base salary of $350,000 with a bonus opportunity up to $100,000. Mr. Radigan does not have any material interest in any transaction that would require disclosure pursuant to Item 404(a) of Regulation S-K. There is no understanding or arrangement between Mr. Radigan and any other person or persons with respect to his appointment and there are no family relationships between Mr. Radigan and any other director or executive officer or person nominated or chosen by the Company to become a director or executive officer.
