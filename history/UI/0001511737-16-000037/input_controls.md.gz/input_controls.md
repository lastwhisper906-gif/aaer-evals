# UI 10-Q controls and the auditor's report


## item_4_controls

[0001511737-16-000037:item_4_controls:1]
Item 4. Controls and Procedures

[0001511737-16-000037:item_4_controls:2]
Evaluation of Disclosure Controls and Procedures

[0001511737-16-000037:item_4_controls:3]
Management, with the participation of the Company’s Chief Executive Officer and Chief Accounting Officer, evaluated the effectiveness of our disclosure controls and procedures as of March 31, 2016. The term “disclosure controls and procedures,” as defined in Rules 13a-15(e) and 15d-15(e) under the Securities Exchange Act of 1934, as amended (the “Exchange Act”), means controls and other procedures of a company that are designed to ensure that information required to be disclosed by a company in the reports that it files or submits under the Exchange Act is recorded, processed, summarized and reported, within the time periods specified in the SEC’s rules and forms. Disclosure controls and procedures include, without limitation, controls and procedures designed to ensure that information required to be disclosed by a company in the reports that it files or submits under the Exchange Act is accumulated and communicated to the company’s management, including its principal executive and principal financial officers, as appropriate to allow timely decisions regarding required disclosure. Management recognizes that any controls and procedures, no matter how well designed and operated, can provide only reasonable assurance of achieving their objectives. Based on the evaluation of our disclosure controls and procedures as of March 31, 2016, our Chief Executive Officer and Chief Accounting Officer concluded that, as of such date, due to the identification of material weaknesses in our internal control over financial reporting, as further described in Item 9A of our Annual Report, our disclosure controls and procedures were not effective.

[0001511737-16-000037:item_4_controls:4]
Changes in Internal Control over Financial Reporting

[0001511737-16-000037:item_4_controls:5]
The material weaknesses in our internal control over financial reporting, which are described more fully in our Annual Report, continued to exist as of the end of the period covered by this Quarterly Report on Form 10-Q.  Our remediation efforts were ongoing during the three months ended March 31, 2016, and significant progress towards the ongoing remediation of the material weaknesses has been made, wherein management has implemented the following measures:

[0001511737-16-000037:item_4_controls:6]
Regarding the lack of sufficient, competent personnel necessary for effective financial reporting, we recruited and transitioned the leadership team within the finance organization by adding additional qualified and experienced personnel. In conjunction with the recruitment efforts, we have updated our accounting policies and procedures documentation together with key process level documents, including clarification of roles and responsibilities within the finance organization.

[0001511737-16-000037:item_4_controls:7]
Regarding the ineffectively designed and maintained controls required for safeguarding of the Company’s funds and timely detection of improper transactions in the general ledger, we have implemented new policies and controls surrounding disbursement authorities and journal entry creation, including training on required supporting documentation.

[0001511737-16-000037:item_4_controls:8]
28

[0001511737-16-000037:item_4_controls:9]
Regarding the ineffectively designed and maintained controls over user access and transaction privileges to modify and post entries to the general ledger and subsidiary ledgers, the Company has reviewed and updated user access and transaction privileges to the general ledger and interfacing subsidiary systems through the implementation of appropriate system and manual controls. Additionally, we have performed a segregation of duties analysis over general ledger access. Management has also developed policies to ensure that future system changes consider impacts to the general ledger, including transaction privileges and segregation of duties.

[0001511737-16-000037:item_4_controls:10]
The above remediation efforts have been substantially completed during the three months ended March 31, 2016 and management believes that the processes and controls discussed above will remediate the material weaknesses in our internal controls over financial reporting.  However, management has not yet completed testing of these internal controls.  Due to the nature of the remediation process and the need to allow adequate time after implementation to evaluate and test the effectiveness of the controls, no assurance can be given as to the timing of achievement of remediation. The material weaknesses will be fully remediated when, in the opinion of management, the revised control processes have been operating effectively for a sufficient period of time and independently validated by our auditors.

[0001511737-16-000037:item_4_controls:11]
Other than those remediation efforts described above, there were no other changes in our internal control over financial reporting that occurred during the three months ended March 31, 2016 that materially affected, or that are reasonably likely to materially affect, our internal control over financial reporting.

[0001511737-16-000037:item_4_controls:12]
Notwithstanding the ineffectiveness of the Company’s disclosure controls and procedures as of the end of the period covered by this Quarterly Report on Form 10-Q and the material weakness in our internal control over financial reporting that existed as of that date, management believes that (i) this Quarterly Report on Form 10-Q does not contain any untrue statement of a material fact or omit to state a material fact necessary to make the statements made, in light of the circumstances under which they were made, not misleading with respect to the period covered by this Quarterly Report on Form 10-Q and (ii) the unaudited Condensed Consolidated Financial Statements, and other financial information, included in this Quarterly Report on Form 10-Q fairly present in all material respects in accordance with GAAP our financial condition, results of operations and cash flows as of, and for, the dates and periods presented.

[0001511737-16-000037:item_4_controls:13]
Limitations on the Effectiveness of Controls

[0001511737-16-000037:item_4_controls:14]
Control systems, no matter how well conceived and operated, are designed to provide a reasonable, but not an absolute, level of assurance that the objectives of the control system are met. Further, the design of a control system must reflect the fact that there are resource constraints, and the benefits of controls must be considered relative to their costs. Because of the inherent limitations in all control systems, no evaluation of controls can provide absolute assurance that all control issues and instances of fraud, if any, have been detected. Because of the inherent limitations in any control system, misstatements due to error or fraud may occur and not be detected.
