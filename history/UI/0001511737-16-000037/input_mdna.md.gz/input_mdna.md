# UI MD&A — 0001511737-16-000037


## mdna

[0001511737-16-000037:mdna:1]
[same as prior period, unchanged from 0001511737-16-000032:mdna:1]

[0001511737-16-000037:mdna:2]
[same as prior period, unchanged from 0001511737-16-000032:mdna:2]

[0001511737-16-000037:mdna:3]
[same as prior period, unchanged from 0001511737-16-000032:mdna:3]

[0001511737-16-000037:mdna:4]
[same as prior period, unchanged from 0001511737-16-000032:mdna:4]

[0001511737-16-000037:mdna:5]
[same as prior period, unchanged from 0001511737-16-000032:mdna:5]

[0001511737-16-000037:mdna:6]
[same as prior period, unchanged from 0001511737-16-000032:mdna:6]

[0001511737-16-000037:mdna:7]
[same as prior period, unchanged from 0001511737-16-000032:mdna:7]

[0001511737-16-000037:mdna:8]
[same as prior period, unchanged from 0001511737-16-000032:mdna:8]

[0001511737-16-000037:mdna:9]
[same as prior period, unchanged from 0001511737-16-000032:mdna:9]

[0001511737-16-000037:mdna:10]
[same as prior period, unchanged from 0001511737-16-000032:mdna:11]

[0001511737-16-000037:mdna:11]
[same as prior period, unchanged from 0001511737-16-000032:mdna:12]

[0001511737-16-000037:mdna:12]
[same as prior period, unchanged from 0001511737-16-000032:mdna:13]

[0001511737-16-000037:mdna:13]
[same as prior period, unchanged from 0001511737-16-000032:mdna:14]

[0001511737-16-000037:mdna:14]
[same as prior period, unchanged from 0001511737-16-000032:mdna:15]

[0001511737-16-000037:mdna:15]
[same as prior period, unchanged from 0001511737-16-000032:mdna:16]

[0001511737-16-000037:mdna:16]
We sell substantially all of our products through a limited number of distributors and other channel partners, such as resellers and Original Equipment Manufacturers (“OEMs”). Sales to distributors accounted for 99% of our revenues in the three and nine months ended March 31, 2016.

[0001511737-16-000037:mdna:17]
[same as prior period, unchanged from 0001511737-16-000032:mdna:18]

[0001511737-16-000037:mdna:18]
[same as prior period, unchanged from 0001511737-16-000032:mdna:19]

[0001511737-16-000037:mdna:19]
[same as prior period, unchanged from 0001511737-16-000032:mdna:20]

[0001511737-16-000037:mdna:20]
[same as prior period, unchanged from 0001511737-16-000032:mdna:21]

[0001511737-16-000037:mdna:21]
[same as prior period, unchanged from 0001511737-16-000032:mdna:22]

[0001511737-16-000037:mdna:22]
[same as prior period, unchanged from 0001511737-16-000032:mdna:23]

[0001511737-16-000037:mdna:23]
[same as prior period, unchanged from 0001511737-16-000032:mdna:24]

[0001511737-16-000037:mdna:24]
[same as prior period, unchanged from 0001511737-16-000032:mdna:25]

[0001511737-16-000037:mdna:25]
[same as prior period, unchanged from 0001511737-16-000032:mdna:26]

[0001511737-16-000037:mdna:26]
[same as prior period, unchanged from 0001511737-16-000032:mdna:28]

[0001511737-16-000037:mdna:27]
[same as prior period, unchanged from 0001511737-16-000032:mdna:29]

[0001511737-16-000037:mdna:28]
[same as prior period, unchanged from 0001511737-16-000032:mdna:30]

[0001511737-16-000037:mdna:29]
Included in our deferred revenues is a portion related to PCS obligations that we estimate we will fulfill in the future. As of March 31, 2016 and June 30, 2015, we had deferred revenues of $3.9 million and $3.5 million, respectively, related to these obligations.

[0001511737-16-000037:mdna:30]
[same as prior period, unchanged from 0001511737-16-000032:mdna:32]

[0001511737-16-000037:mdna:31]
[same as prior period, unchanged from 0001511737-16-000032:mdna:33]

[0001511737-16-000037:mdna:32]
[same as prior period, unchanged from 0001511737-16-000032:mdna:34]

[0001511737-16-000037:mdna:33]
Comparison of Three and Nine Months Ended March 31, 2016 and 2015

[0001511737-16-000037:mdna:34]
|  | Three Months Ended March 31, |  | Nine Months Ended March 31, |
|  | 2016 |  | 2015 |  | 2016 |  | 2015 |
|  | (In thousands, except percentages) |
| Revenues | $ | 167,433 |  |  | 100 | % |  | $ | 147,456 |  |  | 100 | % |  | $ | 480,719 |  |  | 100 | % |  | $ | 450,680 |  |  | 100 | % |
| Cost of revenues (1)(2)(3) | 84,940 |  |  | 51 | % |  | 81,479 |  |  | 55 | % |  | 245,681 |  |  | 51 | % |  | 254,631 |  |  | 56 | % |
| Gross profit | 82,493 |  |  | 49 | % |  | 65,977 |  |  | 45 | % |  | 235,038 |  |  | 49 | % |  | 196,049 |  |  | 44 | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development (1) | 13,820 |  |  | 8 | % |  | 15,236 |  |  | 10 | % |  | 42,810 |  |  | 9 | % |  | 39,893 |  |  | 9 | % |
| Sales, general and administrative (1) | 8,538 |  |  | 5 | % |  | 5,510 |  |  | 4 | % |  | 24,113 |  |  | 5 | % |  | 16,568 |  |  | 4 | % |
| Business e-mail compromise (“BEC”) fraud loss/(recovery) | (3 | ) |  | * |  |  | — |  |  | * |  |  | (8,294 | ) |  | (2 | )% |  | — |  |  | * |  |
| Total operating expenses | 22,355 |  |  | 13 | % |  | 20,746 |  |  | 14 | % |  | 58,629 |  |  | 12 | % |  | 56,461 |  |  | 13 | % |
| Income from operations | 60,138 |  |  | 36 | % |  | 45,231 |  |  | 31 | % |  | 176,409 |  |  | 37 | % |  | 139,588 |  |  | 31 | % |
| Interest expense and other, net | (510 | ) |  | * |  |  | (763 | ) |  | * |  |  | (1,277 | ) |  | * |  |  | (804 | ) |  | * |  |
| Income before provision for income taxes | 59,628 |  |  | 36 | % |  | 44,468 |  |  | 30 | % |  | 175,132 |  |  | 36 | % |  | 138,784 |  |  | 31 | % |
| Provision for income taxes | 6,929 |  |  | 4 | % |  | 3,331 |  |  | 2 | % |  | 19,222 |  |  | 4 | % |  | 13,639 |  |  | 3 | % |
| Net income and comprehensive income | $ | 52,699 |  |  | 31 | % |  | $ | 41,137 |  |  | 28 | % |  | $ | 155,910 |  |  | 32 | % |  | $ | 125,145 |  |  | 28 | % |
| * Less than 1% |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| (1) Includes stock-based compensation as follows: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of revenues | $ | 114 |  |  |  |  | $ | 141 |  |  |  |  | $ | 341 |  |  |  |  | $ | 440 |  |  |  |
| Research and development | 566 |  |  |  |  | 810 |  |  |  |  | 1,770 |  |  |  |  | 2,499 |  |  |  |
| Sales, general and administrative | 202 |  |  |  |  | 425 |  |  |  |  | 755 |  |  |  |  | 1,240 |  |  |  |
| Total stock-based compensation | $ | 882 |  |  |  |  | $ | 1,376 |  |  |  |  | $ | 2,866 |  |  |  |  | $ | 4,179 |  |  |  |
| (2) Includes purchase commitment termination fee | $ | — |  |  |  |  | $ | — |  |  |  |  | $ | — |  |  |  |  | $ | 5,500 |  |  |  |
| (3) Includes benefit of implementing overhead capitalization | $ | (219 | ) |  |  |  | $ | — |  |  |  |  | $ | (1,213 | ) |  |  |  | $ | — |  |  |  |

[0001511737-16-000037:mdna:35]
[same as prior period, unchanged from 0001511737-16-000032:mdna:37]

[0001511737-16-000037:mdna:36]
Total revenues increased $19.9 million, or 13%, from $147.5 million in the three months ended March 31, 2015 to $167.4 million in the three months ended March 31, 2016.   Revenues increased $30.0 million, or 7% from $450.7 million in the nine months ended March 31, 2015 to $480.7 million in the nine months ended March 31, 2016.  The drivers of both increases are discussed in further detail below. During the three and nine months ended March 31, 2016, there were no material price changes in the Company's products sold.  During these periods there were changes in product mix, including a higher mix of Enterprise Technology products sold as compared to the three and nine months ended March 31, 2015.

[0001511737-16-000037:mdna:37]
[same as prior period, unchanged from 0001511737-16-000032:mdna:39]

[0001511737-16-000037:mdna:38]
|  | Three Months Ended March 31, |  | Nine Months Ended March 31, |
|  | 2016 |  | 2015 |  | 2016 |  | 2015 |
|  | (in thousands, except percentages) |
| Service Provider Technology | $ | 96,326 |  |  | 58 | % |  | $ | 106,242 |  |  | 72 | % |  | $ | 309,341 |  |  | 64 | % |  | $ | 313,233 |  |  | 70 | % |
| Enterprise Technology | 71,107 |  |  | 42 | % |  | 41,214 |  |  | 28 | % |  | 171,378 |  |  | 36 | % |  | 137,447 |  |  | 30 | % |
| Total revenues | $ | 167,433 |  |  | 100 | % |  | $ | 147,456 |  |  | 100 | % |  | $ | 480,719 |  |  | 100 | % |  | $ | 450,680 |  |  | 100 | % |

[0001511737-16-000037:mdna:39]
Service Provider Technology revenue decreased $9.9 million, or 9%, from $106.2 million in the three months ended March 31, 2015 to $96.3 million in the three months ended March 31, 2016.  Revenues decreased $3.9 million, or 1%, from $313.2 million in the nine months ended March 31, 2015 to $309.3 million in the nine months ended March 31, 2016.  The decrease in

[0001511737-16-000037:mdna:40]
Service Provider Technology revenue during the three months ended March 31, 2016 as compared to the same period in the prior year was primarily due to decreased revenues for Service Provider Technology products outside of the Asia Pacific region.  The decrease in Service Provider Technology revenue during the nine months ended March 31, 2016, as compared to the same period in the prior year, was primarily due to decreased revenues from Service Provider Technology products in South America partially offset by increased revenues in Asia Pacific.

[0001511737-16-000037:mdna:41]
Enterprise Technology revenue increased $29.9 million, or 73%, from $41.2 million in the three months ended March 31, 2015 to $71.1 million in the three months ended March 31, 2016.  Revenues increased $34.0 million, or 25%, from $137.4 million in the nine months ended March 31, 2015 to $171.4 million in the nine months ended March 31, 2016. The increase in Enterprise Technology revenue during the three months ended March 31, 2016 as compared to the same period in the prior year was primarily due to increased Enterprise Technology revenues in North America, Europe, the Middle East and Africa ("EMEA") and Asia Pacific with flat growth in revenues in South America.  The increase in Enterprise Technology revenue during the nine months ended March 31, 2016 as compared to the same period in the prior year was, similarly, due to increased revenues in North America, EMEA and Asia Pacific partially offset by decreased revenues in South America.  For both the three and nine month periods ended March 31, 2016, the increase in revenues was largely driven by new Enterprise Technology products.

[0001511737-16-000037:mdna:42]
[same as prior period, unchanged from 0001511737-16-000032:mdna:44]

[0001511737-16-000037:mdna:43]
We have determined the geographical distribution of our product revenues based on our customers’ ship-to destinations. A majority of our sales are to distributors who either sell to resellers or directly to end customers, who may be located in different countries than the initial ship-to destination.  The following are our revenues by geography for the three and nine months ended March 31, 2016 and 2015 (in thousands, except percentages):

[0001511737-16-000037:mdna:44]
|  | Three Months Ended March 31, |  | Nine Months Ended March 31, |
|  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| North America (1) | $ | 57,791 |  |  | 35 | % |  | $ | 45,692 |  |  | 31 | % |  | $ | 168,158 |  |  | 35 | % |  | $ | 153,400 |  |  | 34 | % |
| South America | 15,450 |  |  | 9 | % |  | 17,866 |  |  | 12 | % |  | 61,393 |  |  | 13 | % |  | 71,242 |  |  | 16 | % |
| Europe, the Middle East and Africa | 73,269 |  |  | 44 | % |  | 66,770 |  |  | 45 | % |  | 194,745 |  |  | 40 | % |  | 177,474 |  |  | 39 | % |
| Asia Pacific | 20,923 |  |  | 12 | % |  | 17,128 |  |  | 12 | % |  | 56,423 |  |  | 12 | % |  | 48,564 |  |  | 11 | % |
| Total revenues | $ | 167,433 |  |  | 100 | % |  | $ | 147,456 |  |  | 100 | % |  | $ | 480,719 |  |  | 100 | % |  | $ | 450,680 |  |  | 100 | % |

[0001511737-16-000037:mdna:45]
| (1) | Revenue for the United States was $54.6 million and $43.9 million for the three months ended March 31, 2016 and 2015, respectively. Revenue for the United States was $158.8 million and $146.1 million for the nine months ended March 31, 2016 and 2015, respectively. |

[0001511737-16-000037:mdna:46]
[same as prior period, unchanged from 0001511737-16-000032:mdna:48]

[0001511737-16-000037:mdna:47]
Revenues in North America increased $12.1 million, or 26%, from $45.7 million in the three months ended March 31, 2015 to $57.8 million in the three months ended March 31, 2016.  Revenues increased $14.8 million, or 10%, from $153.4 million in the nine months ended March 31, 2015 to $168.2 million in the nine months ended March 31, 2016.  The increase in North American revenues during the three and nine months ended March 31, 2016 as compared to the same periods in the prior year was primarily due to increased Enterprise Technology revenue.

[0001511737-16-000037:mdna:48]
[same as prior period, unchanged from 0001511737-16-000032:mdna:50]

[0001511737-16-000037:mdna:49]
Revenues in South America decreased $2.4 million, or 13%, from $17.9 million in the three months ended March 31, 2015 to $15.5 million in the three months ended March 31, 2016.  Revenues decreased $9.8 million, or 14%, from $71.2 million in the nine months ended March 31, 2015 to $61.4 million in the nine months ended March 31, 2016.  The decrease in South American revenues during the three months ended March 31, 2016 as compared to the same period in the prior year was primarily due to decreased revenues from Service Provider Technology products.  Similarly, the decrease in South American revenues during the nine months ended March 31, 2016, as compared to the same period in the prior year was primarily due to decreased revenues from Service Provider Technology products, however, also included decreased revenues from Enterprise Technology products.  We believe that recent declines in South American revenues continue to be substantially driven by a strong U.S. dollar and by general economic instability in the region.

[0001511737-16-000037:mdna:50]
[same as prior period, unchanged from 0001511737-16-000032:mdna:52]

[0001511737-16-000037:mdna:51]
Revenues in EMEA increased $6.5 million, or 10%, from $66.8 million in the three months ended March 31, 2015 to $73.3 million in the three months ended March 31, 2016.  Revenues increased $17.2 million, or 10%, from $177.5 million in the nine months ended March 31, 2015 to $194.7 million in the nine months ended March 31, 2016. The increase in EMEA revenues during the three months ended March 31, 2016 as compared to the same period in the prior year was primarily due to increased revenues from Enterprise Technology products offset by slightly decreased revenues from Service Provider Technology products.  The increase in EMEA revenues during the nine months ended March 31, 2016 as compared to the same period in the prior year was primarily driven by increased revenues from Enterprise Technology products.

[0001511737-16-000037:mdna:52]
[same as prior period, unchanged from 0001511737-16-000032:mdna:54]

[0001511737-16-000037:mdna:53]
Revenues in the Asia Pacific region increased $3.8 million, or 22%, from $17.1 million in the three months ended March 31, 2015 to $20.9 million in the three months ended March 31, 2016.  Revenues increased $7.8 million, or 16%, from $48.6 million in the nine months ended March 31, 2015 to $56.4 million in the nine months ended March 31, 2016.  The increase in Asia Pacific revenues during both the three and nine months ended March 31, 2016, as compared to the same periods in the prior year, was primarily due to increases in both Enterprise Technology and Service Provider Technology revenues.

[0001511737-16-000037:mdna:54]
[same as prior period, unchanged from 0001511737-16-000032:mdna:56]

[0001511737-16-000037:mdna:55]
Cost of revenues increased $3.4 million, or 4%, from $81.5 million in the three months ended March 31, 2015 to $84.9 million in the three months ended March 31, 2016.  This increase was primarily due to our overall increase in revenues partially offset by lower product costs associated with the mix of products sold during the three months ended March 31, 2016 as compared to the same period in the prior year.

[0001511737-16-000037:mdna:56]
Cost of revenues decreased $8.9 million, or 3%, from $254.6 million in the nine months ended March 31, 2015 to $245.7 million in the nine months ended March 31, 2016.  This reduction reflects a non-recurring termination fee of $5.5 million recognized in the prior nine months ended March 31, 2015 related to the cancellation of a purchase commitment.  Additionally, as discussed further in Note 2, in the nine months ended March 31, 2016, the Company began capitalizing manufacturing overhead related to inventory produced but not sold during the period.   Specifically, in the nine months ended March 31, 2016, the impact of capitalization of manufacturing overhead was a net reduction of $1.2 million to cost of revenues.  The remaining decrease in costs of revenues is attributable to improved margins for both Service Provider and Enterprise Technologies  coupled with changes in mix of products sold during the nine months ended March 31, 2016.

[0001511737-16-000037:mdna:57]
Gross profit margin increased to 49% in the three months ended March 31, 2016 compared to 45% in the three months ended March 31, 2015, and also increased to 49% in the nine months ended March 31, 2016, compared to 44% in the nine months ended March 31, 2015.  The increases for both periods are consistent with change in mix of products sold during the three and nine months ended March 31, 2016, as compared to the three and nine months ended March 31, 2015.

[0001511737-16-000037:mdna:58]
[same as prior period, unchanged from 0001511737-16-000032:mdna:60]

[0001511737-16-000037:mdna:59]
[same as prior period, unchanged from 0001511737-16-000032:mdna:61]

[0001511737-16-000037:mdna:60]
Research and development (“R&D”) expenses decreased $1.4 million, or 9%, from $15.2 million in the three months ended March 31, 2015 to $13.8 million in the three months ended March 31, 2016. As a percentage of revenues, research and development expenses decreased from 10% in the three months ended March 31, 2015 to 8% in the three months ended March 31, 2016.  This decrease is primarily due to decreases in certain one-time costs incurred for IP purchased for use in our products in the three months ended March 31, 2016 as compared to the similar period in 2015.

[0001511737-16-000037:mdna:61]
Research and development costs increased $2.9 million, or 7% from $39.9 million in the nine months ended March 31, 2015 to $42.8 million in the nine months ended March 31, 2016.  As a percentage of revenues, research and development expenses remained flat at 9% for both the nine months ended March 31, 2015 and March 31, 2016.  This increase in absolute dollar expenditures is primarily driven by a $2.5 million impairment charge for capitalized software and software in development costs recognized in the nine months ended March 31, 2016 due to the cancellation of the commercial launch of certain software in development. Over time, we expect our research and development costs to increase in absolute dollars as we continue making investments in developing new products and developing new versions of our existing products.

[0001511737-16-000037:mdna:62]
[same as prior period, unchanged from 0001511737-16-000032:mdna:63]

[0001511737-16-000037:mdna:63]
Sales, general and administrative expenses increased $3.0 million, or 55%, from $5.5 million in the three months ended March 31, 2015 to $8.5 million in the three months ended March 31, 2016.  As a percentage of revenues, sales, general and administrative expenses increased from 4% in the three months ended March 31, 2015 to 5% in the three months ended March 31, 2016.  Sales, general and administrative expenses increased $7.5 million, or 45%, from $16.6 million in the nine months ended March 31, 2015 to $24.1 million in the nine months ended March 31, 2016. As a percentage of revenues, sales, general

[0001511737-16-000037:mdna:64]
and administrative expenses increased from 4% in the nine months ended March 31, 2015 to 5% in the nine months ended March 31, 2016.  Increases for both the three and nine months ended March 31, 2016 as compared to the same periods in the prior year are primarily attributable to general and administrative costs incurred for interim management and advisory services to remediate internal control weaknesses as disclosed in the Annual Report.  Additionally, increases were driven by higher sales and marketing expenses incurred related to increased hiring of business development personnel and overall increases in business development initiatives for the three and nine months ended March 31, 2016 as compared to the same periods in the prior year.

[0001511737-16-000037:mdna:65]
[same as prior period, unchanged from 0001511737-16-000032:mdna:66]

[0001511737-16-000037:mdna:66]
Our provision for income taxes increased $3.6 million or 109%, from $3.3 million for the three months ended March 31, 2015 to $6.9 million for the three months ended March 31, 2016. Our effective tax rate increased to 12% for the three months ended March 31, 2016 as compared to 7% for the three months ended March 31, 2015 .  The higher effective tax rate in the three months ended March 31, 2016 was primarily due to a discrete one-time tax expense recorded in the U.S. as compared to the three months ended March 31, 2015, as well as a discrete one-time tax benefit recorded in the U.S. jurisdiction in the three months ended March 31, 2015.  Our provision for income taxes increased $5.6 million, or 41%, from $13.6 million for the nine months ended March 31, 2015 to $19.2 million for the nine months ended March 31, 2016. Our effective tax rate increased from 9.8% for the nine months ended March 31, 2015 to 11.0% for the nine months ended March 31, 2016. The higher effective tax rate for the nine months ended March 31, 2016 as compared to the similar period in the prior year was primarily due to a reduced tax benefit from federal research credits and other discrete items.

[0001511737-16-000037:mdna:67]
[same as prior period, unchanged from 0001511737-16-000032:mdna:68]

[0001511737-16-000037:mdna:68]
[same as prior period, unchanged from 0001511737-16-000032:mdna:69]

[0001511737-16-000037:mdna:69]
Since inception, our operations primarily have been funded through cash generated by operations and proceeds from our various debt agreements. Cash and cash equivalents increased from $446.4 million at June 30, 2015 to $502.5 million at March 31, 2016.

[0001511737-16-000037:mdna:70]
[same as prior period, unchanged from 0001511737-16-000032:mdna:71]

[0001511737-16-000037:mdna:71]
[same as prior period, unchanged from 0001511737-16-000032:mdna:72]

[0001511737-16-000037:mdna:72]
|  | Nine Months Ended March 31, |
|  | 2016 |  | 2015 |
|  | (In thousands) |
| Net cash provided by operating activities | $ | 151,944 |  |  | $ | 116,344 |  |
| Net cash used in investing activities | (4,820 | ) |  | (10,817 | ) |
| Net cash used in financing activities | (90,976 | ) |  | (1,465 | ) |
| Net increase in cash and cash equivalents | $ | 56,148 |  |  | $ | 104,062 |  |

[0001511737-16-000037:mdna:73]
[same as prior period, unchanged from 0001511737-16-000032:mdna:74]

[0001511737-16-000037:mdna:74]
Net cash provided by operating activities in the nine months ended March 31, 2016 of $151.9 million consisted primarily of net income of $155.9 million and net changes in operating assets and liabilities that resulted in net cash outflows of $14.4 million. This net change was primarily driven by outflows arising from a $14.5 million decrease in accounts payable and accrued liabilities, a $9.2 million increase in accounts receivable due to overall higher revenues for the period, and a $5.9 million increase in inventory to fulfill expected future sales orders. These outflows were offset by changes in operating assets and liabilities resulting in cash inflows, including a $6.6 million  decrease in vendor deposits due to consumption of raw material backed by vendor deposits, a $3.9 million increase in taxes payable due to increases in the income tax provision, a $2.6 million  decrease in prepaid taxes due to the timing of federal tax payments, a $374 thousand increase in deferred revenue due to additional PCS revenue deferrals during the period, and a $1.6 million  decrease in prepaid expenses and other current assets.  Overall, cash inflows from operating activities were driven by our net income for the period, which included non-cash adjustments primarily due to stock-based compensation (net of excess tax benefit), depreciation and amortization, write-off of previously capitalized software development costs, increases to our provision for inventory obsolescence due to consumption of inventory previously reserved, and increases to our provision for sales returns.  The net of these non-cash adjustments resulted in an increase to our net cash provided by operating activities of $10.5 million.

[0001511737-16-000037:mdna:75]
Net cash provided by operating activities in the nine months ended March 31, 2015 of $116.3 million consisted primarily of net income of $125.1 million partially offset by net changes in operating assets and liabilities that resulted in net cash outflows of $19.1 million. These changes consisted primarily of a $14.8 million increase in accounts payable and accrued liabilities due primarily to our increase in cost of revenues, a $20.7 million increase in prepaid expenses and other current assets due to the timing of deposit payments with our suppliers, an $3.5 million decrease in inventory due to our efforts to build warehouse stock levels and ultimately decrease lead times, a $3.1 million increase in taxes payable and a $4.1 million increase in prepaid taxes due to the timing of federal tax payments. Additionally, our net income included non-cash adjustments due to stock-based compensation, depreciation and amortization, increases to our provision for inventory obsolescence, decreases in our allowance for doubtful accounts, a write-off of our intangible assets and taxes. The net of these non-cash adjustments resulted in an increase of our net cash provided by operating activities of $10.3 million.

[0001511737-16-000037:mdna:76]
[same as prior period, unchanged from 0001511737-16-000032:mdna:78]

[0001511737-16-000037:mdna:77]
We used $4.8 million of cash in investing activities during the nine months ended March 31, 2016.  Our investing activities consist of capital expenditures for machinery and equipment related to product development and prototyping activities in addition to purchases of intangible assets. Capital expenditures for the nine months ended March 31, 2016 and 2015 were $4.5 million and $10.8 million, respectively.  Additionally, we had cash outflows related to the purchase of intangible assets of $288 thousand and $38 thousand during the nine months ended March 31, 2016 and 2015, respectively, consisting primarily of legal costs associated with trademark applications and acquisition of domain names.

[0001511737-16-000037:mdna:78]
[same as prior period, unchanged from 0001511737-16-000032:mdna:80]

[0001511737-16-000037:mdna:79]
We used $91.0 million of cash in financing activities during the nine months ended March 31, 2016.  During the nine months ended March 31, 2016 we paid $150.0 million for repurchases of our common stock.  We also made repayments of $7.5 million on our outstanding term loan debt under the Amended Credit Agreement.  These cash outflows were offset by financing cash inflows, including four draws made under the revolver facility of our Amended Credit Agreement totaling $66.0 million that were used, in part, for the repurchases of our common stock discussed above.  Additionally, cash inflows from financing activities included $778 thousand of cash proceeds received from the exercise of stock options in addition to $671 thousand of excess tax benefit from employee stock-based awards, partially offset by tax withholdings related to net share settlements of restricted stock units totaling $922 thousand.

[0001511737-16-000037:mdna:80]
We had $1.5 million of cash used in financing activities during the nine months ended March 31, 2015, primarily from cash received from our term loan with Wells Fargo Bank of $100.0 million, offset by repayments of our prior original credit agreement with Wells Fargo Bank of $72.3 million.  Additionally, during the nine months ended March 31, 2015, we paid $15.0 million for dividends on our common stock and paid $15.0 million for repurchases of our common stock and had tax withholdings related to net share settlements of restricted stock units of $1.6 million.  Other cash inflows from financing activities included cash received for stock option exercises of $850 thousand and an excess tax benefit from employee stock-based awards of $1.6 million.

[0001511737-16-000037:mdna:81]
[same as prior period, unchanged from 0001511737-16-000032:mdna:83]

[0001511737-16-000037:mdna:82]
We believe our existing cash and cash equivalents, cash provided by operations and the availability of additional funds under our Amended Credit Agreement will be sufficient to meet our working capital and capital expenditure needs for at least the next twelve months. Our future capital requirements may vary materially from those currently planned and will depend on many factors, including our rate of revenue growth, the timing and extent of spending to support development efforts, the timing of new product introductions, market acceptance of our products and overall economic conditions. As of March 31, 2016, we held $489.0 million of our $502.5 million of cash and cash equivalents in accounts of our subsidiaries outside of the United States and we could incur significant tax liabilities if we decide to repatriate those amounts.

[0001511737-16-000037:mdna:83]
[same as prior period, unchanged from 0001511737-16-000032:mdna:85]

[0001511737-16-000037:mdna:84]
Our products are generally accompanied by a twelve month warranty from date of purchase, which covers both parts and labor. Generally the distributor is responsible for the freight costs associated with warranty returns, and we absorb the freight costs of replacing items under warranty. In accordance with the Financial Accounting Standards Board’s (“FASB’s”), Accounting Standards Codification (“ASC”), 450-20, Loss Contingencies, we record an accrual when we believe it is reasonably estimable and probable based upon historical experience. We record a provision for estimated future warranty work in cost of goods sold upon recognition of revenues, and we review the resulting accrual regularly and periodically adjust it to reflect changes in warranty estimates.

[0001511737-16-000037:mdna:85]
We may in the future enter into standard indemnification agreements with many of our distributors and OEMs, as well as certain other business partners in the ordinary course of business. These agreements may include provisions for indemnifying

[0001511737-16-000037:mdna:86]
the distributor, OEM or other business partner against any claim brought by a third-party to the extent any such claim alleges that a Ubiquiti product infringes a patent, copyright or trademark or violates any other proprietary rights of that third-party. The maximum amount of potential future indemnification is unlimited. The maximum potential amount of future payments we could be required to make under these indemnification agreements is not estimable.

[0001511737-16-000037:mdna:87]
We have agreed to indemnify our directors, officers and certain other employees for certain events or occurrences, subject to certain limits, while such persons are or were serving at our request in such capacity. We may terminate the indemnification agreements with these persons upon the termination of their services with us, but termination will not affect claims for indemnification related to events occurring prior to the effective date of termination. The maximum amount of potential future indemnification is unlimited. We have a Directors and Officers insurance policy that limits our potential exposure. We believe the fair value of these indemnification agreements is minimal.  We have not recorded any liabilities for these agreements as of March 31, 2016.

[0001511737-16-000037:mdna:88]
Based upon our historical experience and information known as of the date of this report, we do not believe it is likely that we have a significant liability for the above indemnities at March 31, 2016.

[0001511737-16-000037:mdna:89]
[same as prior period, unchanged from 0001511737-16-000032:mdna:91]

[0001511737-16-000037:mdna:90]
The following table summarizes our contractual obligations as of March 31, 2016 for the remainder of fiscal 2016 and future fiscal years (in thousands):

[0001511737-16-000037:mdna:91]
|  | 2016 (remainder) |  | 2017 |  | 2018 |  | 2019 |  | 2020 |  | Thereafter |  | Total |
| Operating leases | $ | 1,245 |  |  | $ | 4,118 |  |  | $ | 2,279 |  |  | $ | 1,190 |  |  | $ | 817 |  |  | $ | 399 |  |  | $ | 10,048 |  |
| Debt payment obligations | 2,500 |  |  | 11,250 |  |  | 15,000 |  |  | 15,000 |  |  | 112,250 |  |  | — |  |  | 156,000 |  |
| Interest and other payments on debt | 888 |  |  | 3,422 |  |  | 3,142 |  |  | 2,822 |  |  | 1,746 |  |  | — |  |  | 12,020 |  |
| Purchase obligations | 21,965 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 21,965 |  |
| Other obligations | 6,258 |  |  | 65 |  |  | 3 |  |  | — |  |  | — |  |  | — |  |  | 6,326 |  |
| Total | $ | 32,856 |  |  | $ | 18,855 |  |  | $ | 20,424 |  |  | $ | 19,012 |  |  | $ | 114,813 |  |  | $ | 399 |  |  | $ | 206,359 |  |

[0001511737-16-000037:mdna:92]
[same as prior period, unchanged from 0001511737-16-000032:mdna:94]

[0001511737-16-000037:mdna:93]
We lease our headquarters in San Jose, California in addition to other locations worldwide under non-cancelable operating leases that expire at various dates through fiscal 2021.

[0001511737-16-000037:mdna:94]
[same as prior period, unchanged from 0001511737-16-000032:mdna:96]

[0001511737-16-000037:mdna:95]
On March 3, 2015, we entered into the Amended Credit Agreement, that provides for a $200.0 million senior secured revolving credit facility and a $100.0 million senior secured term loan facility, with an option to request increases in the amounts of such credit facilities by up to an additional $50.0 million in the aggregate (any such increase to be in each lender’s sole discretion).  Please see Note 7 of the Notes to the Condensed Consolidated Financial Statements for more information. Although interest rates on our debt obligations will likely vary over time, we have assumed our interest rates as of March 31, 2016 as the interest rates for all fiscal years presented.  Furthermore, the interest payment intervals on our revolving debt are determined at the Company's election pursuant to the Amended Credit Agreement, and may change over time.  For purposes of the table above, we have assumed two to three month payment intervals on our revolving debt, consistent with our elections to date.  Also included are estimated bank fees to be paid for unused portions of our revolving credit facility.

[0001511737-16-000037:mdna:96]
[same as prior period, unchanged from 0001511737-16-000032:mdna:98]

[0001511737-16-000037:mdna:97]
We subcontract with third parties to manufacture our products. During the normal course of business, our contract manufacturers procure components and manufacture product based upon orders placed by us.  Component and product inventory held by our manufacturers or our third-party logistics providers is not recorded on our balance sheet until legal title passes to the Company.  If we cancel all or part of the orders, we may still be liable to the contract manufacturers for the cost of the components they purchased and for manufacturing and other costs related to these components.  We periodically review the potential liability, and no significant liabilities for cancellations have been recorded for the nine months ended March 31, 2016. Our consolidated financial position and results of operations could be negatively impacted if we were required to compensate the contract manufacturers for any unrecorded liabilities incurred.  The Company had inventory purchase obligations of $22.0 million as of March 31, 2016.

[0001511737-16-000037:mdna:98]
[same as prior period, unchanged from 0001511737-16-000032:mdna:100]

[0001511737-16-000037:mdna:99]
We had other obligations of $6.3 million as of March 31, 2016, which consisted primarily of commitments related to research and development projects.

[0001511737-16-000037:mdna:100]
[same as prior period, unchanged from 0001511737-16-000032:mdna:102]

[0001511737-16-000037:mdna:101]
As of March 31, 2016, we had $22.2 million of unrecognized tax benefits, substantially all of which would, if recognized, affect our tax expense. We have elected to include interest and penalties related to uncertain tax positions as a component of tax expense. We do not expect any significant increases or decreases to our unrecognized tax benefits in the next twelve months.

[0001511737-16-000037:mdna:102]
[same as prior period, unchanged from 0001511737-16-000032:mdna:104]

[0001511737-16-000037:mdna:103]
[same as prior period, unchanged from 0001511737-16-000032:mdna:105]

[0001511737-16-000037:mdna:104]
[same as prior period, unchanged from 0001511737-16-000032:mdna:106]

[0001511737-16-000037:mdna:105]
Regulation G, conditions for use of Non-Generally Accepted Accounting Principles (“Non-GAAP”) financial measures, and other SEC regulations define and prescribe the conditions for use of certain Non-GAAP financial information. To supplement our Condensed Consolidated Financial Statements presented in accordance with GAAP, we use Non-GAAP financial measures which are adjusted from the most directly comparable GAAP financial measures to exclude certain items, as described below. Management believes that these Non-GAAP financial measures reflect an additional and useful way of viewing aspects of our operations that, when viewed in conjunction with our GAAP results, provide a more comprehensive understanding of the various factors and trends affecting our business and operations. Non-GAAP financial measures used by us include net income or loss and diluted net income or loss per share.  Other companies may calculate these measures differently than we do, limiting the usefulness of these items as comparative measures.

[0001511737-16-000037:mdna:106]
[same as prior period, unchanged from 0001511737-16-000032:mdna:108]

[0001511737-16-000037:mdna:107]
[same as prior period, unchanged from 0001511737-16-000032:mdna:109]

[0001511737-16-000037:mdna:108]
|  | Three Months Ended March 31, |  | Nine Months Ended March 31, |
|  | 2016 |  | 2015 |  | 2016 |  | 2015 |
|  | (In thousands, except per share amounts) |
| Non-GAAP net income and comprehensive income | $ | 53,032 |  |  | $ | 41,963 |  |  | $ | 148,267 |  |  | $ | 132,493 |  |
| Non-GAAP diluted net income per share of common stock | $ | 0.63 |  |  | $ | 0.47 |  |  | $ | 1.72 |  |  | $ | 1.48 |  |

[0001511737-16-000037:mdna:109]
[same as prior period, unchanged from 0001511737-16-000032:mdna:111]

[0001511737-16-000037:mdna:110]
[same as prior period, unchanged from 0001511737-16-000032:mdna:112]

[0001511737-16-000037:mdna:111]
|  | Three Months Ended March 31, |  | Nine Months Ended March 31, |
|  | 2016 |  | 2015 |  | 2016 |  | 2015 |
|  | (In thousands, except per share amounts) |
| Net income and comprehensive income | $ | 52,699 |  |  | $ | 41,137 |  |  | $ | 155,910 |  |  | $ | 125,145 |  |
| Stock-based compensation: |  |  |  |  |  |  |  |
| Cost of revenues | 114 |  |  | 141 |  |  | 341 |  |  | 440 |  |
| Research and development | 566 |  |  | 810 |  |  | 1,770 |  |  | 2,499 |  |
| Sales, general and administrative | 202 |  |  | 425 |  |  | 755 |  |  | 1,240 |  |
| Purchase commitment termination fee | — |  |  | — |  |  | — |  |  | 5,500 |  |
| Business e-mail compromise (“BEC”) fraud loss/(recovery) | (3 | ) |  | — |  |  | (8,294 | ) |  | — |  |
| Implementation of overhead capitalization (1) | (219 | ) |  | — |  |  | (1,213 | ) |  | — |  |
| Tax effect of non-GAAP adjustments | (327 | ) |  | (550 | ) |  | (1,002 | ) |  | (2,331 | ) |
| Non-GAAP net income and comprehensive income | $ | 53,032 |  |  | $ | 41,963 |  |  | $ | 148,267 |  |  | $ | 132,493 |  |
| Non-GAAP diluted net income per share of common stock | $ | 0.63 |  |  | $ | 0.47 |  |  | $ | 1.72 |  |  | $ | 1.48 |  |
| Weighted-average shares used in computing non-GAAP diluted net income per share of common stock | 84,685 |  |  | 89,400 |  |  | 86,433 |  |  | 89,707 |  |

[0001511737-16-000037:mdna:112]
(1) - Overhead capitalization was implemented in the first quarter of fiscal 2016.  As a result of implementing the policy, we recognized a benefit in the first quarter of fiscal 2016.

[0001511737-16-000037:mdna:113]
[same as prior period, unchanged from 0001511737-16-000032:mdna:115]

[0001511737-16-000037:mdna:114]
When used in this Report, the words “anticipates,” “believes,” “could,” “seeks,” “estimates,” “expects,” “intends,” “may,” “plans” “potential,” “predicts,” “projects,” “should,” “will,” “would” or similar expressions and negatives of those terms are intended to identify forward-looking statements. These are statements that relate to future periods and include statements about our future results, sources of revenue, our continued growth, our gross margins, market trends, our product development, technological developments, the features, benefits and performance of our current and future products, the ability of our products to address a variety of markets, the anticipated growth of demand for connectivity worldwide, our growth strategies, future price reductions, our competitive status, our dependence on our senior management and our ability to attract and retain key personnel, dependency on and concentration of our distributors, our employee relations, current and potential litigation, the effects of government regulations, our compliance with laws and regulations, our expected future operating costs and expenses and expenditure levels for research and development, selling, general and administrative expenses, fluctuations in operating results, fluctuations in our stock price, our payment of dividends, our future liquidity and cash needs, our credit facility, future acquisitions of and investments in complimentary businesses and the expected impact of various accounting policies and rules adopted by the Financial Accounting Standards Board. Forward-looking statements are subject to risks and uncertainties that could cause actual results to differ materially from those projected. These risks and uncertainties include, but are not limited to, factors affecting our quarterly results, our ability to manage our growth, our ability to sustain or increase profitability, demand for our products, our ability to compete, our ability to rapidly develop new technology and introduce new products, our ability to safeguard our intellectual property, trends in the networking industry and fluctuations in general economic conditions, and the risks set forth throughout this Report, including under Item 1, “Business” and under Item 1A, “Risk Factors.” These forward-looking statements speak only as of the date hereof. Except as required by law, we expressly disclaim any obligation or undertaking to release publicly any updates or revisions to any forward-looking statements contained herein to reflect any change in our expectations with regard thereto or any change in events, conditions or circumstances on which any such statement is based.
