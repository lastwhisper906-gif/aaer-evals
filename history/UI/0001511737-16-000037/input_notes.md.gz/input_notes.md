# UI notes — 0001511737-16-000037


## ubnt:CapitalizedManufacturingOverheadCostsPolicyPolicyTextBlock

[0001511737-16-000037:notes:1]
[same as prior period, unchanged from 0001511737-16-000032:notes:2]

[0001511737-16-000037:notes:2]
In fiscal 2016, the Company began capitalizing manufacturing overhead expenditures as part of inventory costs.  Capitalized costs primarily include management’s best estimate of the direct labor and materials costs related to inventory produced but not sold during the period.  As of March 31, 2016, the Company capitalized $1.2 million of manufacturing overhead costs.  Manufacturing overhead costs are capitalized to inventory and are recognized as cost of revenues in the following quarter, consistent with the Company's historical inventory turnover.


## ubnt:ScheduleOfRevenueAndAccountsReceivableByMajorCustomersByReportingSegmentsTableTableTextBlock

[0001511737-16-000037:notes:3]
[same as prior period, unchanged from 0001511737-16-000032:notes:4]

[0001511737-16-000037:notes:4]
|  | Percentage of Revenues |  | Percentage of Accounts Receivable |
|  | Three Months Ended March 31, |  | Nine Months Ended March 31, |  | March 31, |  | June 30, |
|  | 2016 |  | 2015 |  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Customer A | * |  | * |  | 10% |  | 10% |  | * |  | * |
| Customer B | * |  | * |  | * |  | 10% |  | * |  | 13% |
| Customer C | * |  | * |  | * |  | * |  | 11% |  | 12% |
| Customer D | * |  | * |  | * |  | * |  | 14% |  | * |

[0001511737-16-000037:notes:5]
* denotes less than 10%


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001511737-16-000037:notes:6]
Basis of Presentation— The accompanying condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP”) related to interim financial statements based on applicable Securities and Exchange Commission (“SEC”) rules and regulations. Accordingly, they do not include all the information and footnotes required by U.S. GAAP for complete financial statements. These condensed and consolidated financial statements reflect all adjustments, which are, in the opinion of the Company, of a normal and recurring nature and those necessary to state fairly the statements of financial position, results of operations and cash flows for the dates and periods presented. The June 30, 2015 balance sheet was derived from the audited financial statements as of that date. All significant intercompany transactions and balances have been eliminated.  The Company has reclassified certain amounts reported in the previous period to conform to the current period presentation.

[0001511737-16-000037:notes:7]
These condensed consolidated financial statements should be read in conjunction with the Company’s audited consolidated financial statements for the fiscal year ended June 30, 2015, included in its Annual Report on Form 10-K, as filed with the SEC on August 21, 2015 (the “Annual Report”). The results of operations for the three and nine months ended March 31, 2016 are not necessarily indicative of the results to be expected for any future periods.


## us-gaap:BusinessDescriptionAndBasisOfPresentationTextBlock

[0001511737-16-000037:notes:8]
[same as prior period, unchanged from 0001511737-16-000032:notes:9]

[0001511737-16-000037:notes:9]
[same as prior period, unchanged from 0001511737-16-000032:notes:10]

[0001511737-16-000037:notes:10]
[same as prior period, unchanged from 0001511737-16-000032:notes:11]

[0001511737-16-000037:notes:11]
[same as prior period, unchanged from 0001511737-16-000032:notes:12]


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001511737-16-000037:notes:12]
COMMITMENTS AND CONTINGENCIES

[0001511737-16-000037:notes:13]
Operating Leases

[0001511737-16-000037:notes:14]
Certain facilities and equipment are leased under non-cancelable operating leases. The Company generally pays taxes, insurance and maintenance costs on leased facilities and equipment. The Company leases office space in San Jose, California and other locations under various non-cancelable operating leases that expire at various dates through fiscal 2021.

[0001511737-16-000037:notes:15]
At March 31, 2016, future minimum annual payments under operating leases for the remainder of fiscal 2016 and future fiscal years are as follows (in thousands):

[0001511737-16-000037:notes:16]
|  | 2016 (remainder) |  | 2017 |  | 2018 |  | 2019 |  | 2020 |  | Thereafter |  | Total |
| Operating leases | $ | 1,245 |  |  | $ | 4,118 |  |  | $ | 2,279 |  |  | $ | 1,190 |  |  | $ | 817 |  |  | $ | 399 |  |  | $ | 10,048 |  |

[0001511737-16-000037:notes:17]
Purchase Obligations

[0001511737-16-000037:notes:18]
The Company primarily subcontracts with other companies to manufacture its products. During the normal course of business, the Company’s contract manufacturers procure components based upon orders placed by the Company. If the Company cancels all or part of the orders, it may still be liable to the contract manufacturers for the cost of the components purchased by them to manufacture the Company’s products. The Company periodically reviews the potential liability, and no significant accruals have been recorded for the nine months ended March 31, 2016.  The Company had inventory purchase obligations of $22.0 million as of March 31, 2016.

[0001511737-16-000037:notes:19]
Other Obligations

[0001511737-16-000037:notes:20]
The Company had other obligations of $6.3 million as of March 31, 2016, which consisted primarily of commitments related to research and development projects.

[0001511737-16-000037:notes:21]
Indemnification Obligations

[0001511737-16-000037:notes:22]
The Company enters into standard indemnification agreements with many of its business partners in the ordinary course of business. These agreements include provisions for indemnifying the business partner against any claim brought by a third-party to the extent any such claim alleges that a Company product infringes a patent, copyright or trademark, or violates any other proprietary rights of that third-party. The maximum potential amount of future payments the Company could be required to make under these indemnification agreements is not estimable and the Company has not incurred any material costs to defend lawsuits or settle claims related to these indemnification agreements to date.

[0001511737-16-000037:notes:23]
Legal Matters

[0001511737-16-000037:notes:24]
The Company may be involved, from time to time, in a variety of claims, lawsuits, investigations, and proceedings relating to contractual disputes, intellectual property rights, employment matters, regulatory compliance matters and other litigation matters relating to various claims that arise in the normal course of business. The Company determines whether an estimated loss from a contingency should be accrued by assessing whether a loss is deemed probable and can be reasonably estimated. The Company assesses its potential liability by analyzing specific litigation and regulatory matters using available information. The Company develops its views on estimated losses in consultation with inside and outside counsel, which involves a subjective analysis of potential results and outcomes, assuming various combinations of appropriate litigation and settlement strategies. Taking all of the above factors into account, the Company records an amount where it is probable that the Company will incur a loss and where that loss can be reasonably estimated. However, the Company’s estimates may be incorrect and the Company could ultimately incur more or less than the amounts initially recorded.  The Company may also incur significant legal fees, which are expensed as incurred, in defending against these claims.

[0001511737-16-000037:notes:25]
Shareholder Class Action Lawsuits

[0001511737-16-000037:notes:26]
Beginning on September 7, 2012, two class action lawsuits were filed in the United States District Court for the Northern District of California against Ubiquiti Networks, Inc., certain of its officers and directors, and the underwriters of its initial public offering, alleging claims under U.S. securities laws. On January 30, 2013, the plaintiffs filed an amended consolidated complaint. On March 26, 2014, the court issued an order granting a motion to dismiss the complaint with leave to amend. Following the plaintiffs’ decision not to file an amended complaint, on April 16, 2014, the court ordered the dismissal of the lawsuit with prejudice, and entered judgment in favor of the Company and the other defendants, and against the plaintiffs. On May 15, 2014, the plaintiffs filed a notice of appeal from the judgment of the court. The appeal is ongoing before the U.S. Court of Appeals for the Ninth Circuit. There can be no assurance that the Company will prevail in the appeal proceeding.  The Company cannot currently estimate the possible loss, if any, that it may experience in connection with this litigation.


## us-gaap:DebtDisclosureTextBlock

[0001511737-16-000037:notes:27]
DEBT

[0001511737-16-000037:notes:28]
On March 3, 2015, Ubiquiti Networks, Inc. and Ubiquiti International Holding Company Limited (the “Cayman Borrower”) amended and restated its original credit agreement (the “Amended Credit Agreement”) with Wells Fargo Bank, National Association (“Wells Fargo”), the other financial institutions named as lenders therein, and Wells Fargo as administrative agent for the lenders.  The Amended Credit Agreement provides for a $200.0 million senior secured revolving credit facility and a $100.0 million senior secured term loan facility (collectively, the “Facilities”), with an option to request increases in the amounts of such credit facilities by up to an additional $50.0 million in the aggregate (any such increase to be in each lender’s sole discretion), and matures on March 3, 2020.  The $100.0 million term loan facility of the Amended Credit Agreement was fully drawn at closing, and $72.3 million was used to repay the outstanding balance under its original credit agreement.  During the nine months ended March 31, 2016, the Company drew $66 million against the revolving credit facility.  Draws of $15 million and $18 million were made in the second fiscal quarter and draws of $14 million and $19 million were made in the third fiscal quarter.  These balances are not due until March 2020, and accordingly are classified as long-term debt.  As of March 31, 2016, $90 million was outstanding on the term loan and $66 million on the revolver, leaving $134 million available on the revolver.  As of March 31, 2016, the interest rate on the term loan was 2.13%.  The table below shows the respective interest rates as of March 31, 2016 in addition to interest rate reset dates and rates as available for each revolver draw.

[0001511737-16-000037:notes:29]
|  |  | Interest Rate as of |  |  |  |  |
| Debt Payment Obligations |  | March 31, 2016 |  | Rate Reset Date |  | Reset Rate |
| $15 Million Revolver |  | 2.02% |  | April 8, 2016 |  | 2.13% |
| $18 Million Revolver |  | 2.01% |  | April 18, 2016 |  | 2.13% |
| $14 Million Revolver |  | 2.02% |  | May 31, 2016 |  | * |
| $19 Million Revolver |  | 2.02% |  | April 1, 2016 |  | 2.13% |

[0001511737-16-000037:notes:30]
* - Reset rate not available as of filing date.

[0001511737-16-000037:notes:31]
The revolving credit facility includes a sub-limit of $10.0 million for letters of credit and a sub-limit of $25.0 million for swingline loans. The Facilities replaced the Company’s $150.0 million senior secured revolving credit facility under its original credit agreement. The Facilities are available for working capital and general corporate purposes that comply with the terms of the Amended Credit Agreement. Under the Amended Credit Agreement, revolving loans and swingline loans may be borrowed, repaid and reborrowed until March 3, 2020, at which time all amounts borrowed must be repaid. The term loan is payable in quarterly installments of 2.50% of the original principal amount of the term loan until March 31, 2017, thereafter increasing to 3.75% of the original principal amount of the term loan, in each case plus accrued and unpaid interest. Revolving, swingline and term loans may be prepaid at any time without penalty.

[0001511737-16-000037:notes:32]
Revolving and term loans bear interest, at the Company’s option, at either (i) a floating rate per annum equal to the base rate plus a margin of between 0.50% and 1.25%, depending on the Company’s leverage ratio as of the most recently ended fiscal quarter or (ii) a floating per annum rate equal to the applicable LIBOR rate for a specified period, plus a margin of between 1.50% and 2.25%, depending on the Company’s leverage ratio as of the most recently ended fiscal quarter. Swingline loans bear interest at a floating rate per annum equal to the base rate plus a margin of between 0.50% and 1.25%, depending on the Company’s leverage ratio as of the most recently ended fiscal quarter.

[0001511737-16-000037:notes:33]
The Amended Credit Agreement requires the Company to maintain during the term of the Facilities (i) a maximum leverage ratio of 2.50 to 1.00 and (ii) minimum liquidity of $225.0 million, increasing to $250.0 million in the event of an incremental increase in the size of the Facilities, which can be satisfied with unrestricted cash and cash equivalents and up to $50.0 million of availability under the revolving credit facility. In addition, the Amended Credit Agreement contains customary affirmative and negative covenants and includes customary events of default. The occurrence of an event of default could result in the acceleration of the obligations under the Amended Credit Agreement.

[0001511737-16-000037:notes:34]
The obligations of Ubiquiti Networks, Inc. and certain domestic subsidiaries, if any, under the Amended Credit Agreement are required to be guaranteed by such domestic subsidiaries (the “Domestic Guarantors”) and are collateralized by substantially all assets (excluding intellectual property) of Ubiquiti Networks, Inc. and the Domestic Guarantors. The obligations of the Cayman Borrower and certain foreign subsidiaries under the Amended Credit Agreement are required to be guaranteed by certain domestic and material foreign subsidiaries (the “Guarantors”) and are collateralized by substantially all assets (excluding intellectual property) of the Cayman Borrower and the Guarantors.

[0001511737-16-000037:notes:35]
The revolving and term loans contain other customary terms and conditions which are more fully explained in Note 7 of the audited consolidated financial statements included in the Annual Report for the year ended June 30, 2015.

[0001511737-16-000037:notes:36]
During the three months ended March 31, 2016, the Company made a payment of $3.0 million against the term loan facility balance under the Amended Credit Agreement, of which $2.5 million was a repayment of principal and $500 thousand was payment of interest. During the nine months ended March 31, 2016, the Company made aggregate payments of $8.9 million against the term loan facility balance under the Amended Credit Agreement, of which $7.5 million was for repayments of principal and $1.4 million was for payments of interest.  During the three and nine months ended March 31, 2016, the Company made aggregate payments of $160 thousand and $260 thousand, respectively, against the revolving loan facility under the Amended Credit Agreement.  As of March 31, 2016, the Company classified $10.0 million as short-term and $146.0 million as long-term debt on its consolidated balance sheet related to the Facilities under the Amended Credit Agreement.

[0001511737-16-000037:notes:37]
On September 2, 2015, the Company accessed a letter of credit under its revolving credit facility in the amount of $237 thousand for the benefit of the landlord pursuant to a new lease of office space. The landlord can draw against the letter of credit in the event of default by the Company. The letter of credit expires on September 2, 2016, subject to automatic renewal for additional one-year periods.

[0001511737-16-000037:notes:38]
The following table summarizes our estimated debt and interest payment obligations as of March 31, 2016, for the remainder of fiscal 2016 and future fiscal years (in thousands):

[0001511737-16-000037:notes:39]
|  | 2016 (remainder) |  | 2017 |  | 2018 |  | 2019 |  | 2020 |  | Thereafter |  | Total |
| Debt payment obligations | $ | 2,500 |  |  | $ | 11,250 |  |  | $ | 15,000 |  |  | $ | 15,000 |  |  | $ | 112,250 |  |  | $ | — |  |  | $ | 156,000 |  |
| Interest and other payments on debt (1) | 888 |  |  | 3,422 |  |  | 3,142 |  |  | 2,822 |  |  | 1,746 |  |  | — |  |  | 12,020 |  |
| Total | $ | 3,388 |  |  | $ | 14,672 |  |  | $ | 18,142 |  |  | $ | 17,822 |  |  | $ | 113,996 |  |  | $ | — |  |  | $ | 168,020 |  |

[0001511737-16-000037:notes:40]
(1) - Interest payments are calculated based on the applicable rates and payment dates as of March 31, 2016. Furthermore, two to three month payment intervals on the revolving debt have been assumed, consistent with the Company's elections to date.


## us-gaap:DeferredCostsCapitalizedPrepaidAndOtherAssetsDisclosureTextBlock

[0001511737-16-000037:notes:41]
[same as prior period, unchanged from 0001511737-16-000032:notes:40]

[0001511737-16-000037:notes:42]
|  | March 31, 2016 |  | June 30, 2015 |
| BEC recovery receivable | $ | — |  |  | $ | 1,376 |  |
| Other current assets | 5,848 |  |  | 6,335 |  |
|  | $ | 5,848 |  |  | $ | 7,711 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001511737-16-000037:notes:43]
[same as prior period, unchanged from 0001511737-16-000032:notes:42]

[0001511737-16-000037:notes:44]
[same as prior period, unchanged from 0001511737-16-000032:notes:43]

[0001511737-16-000037:notes:45]
The Company’s 2010 Equity Incentive Plan and 2005 Equity Incentive Plan are described in its Annual Report. As of March 31, 2016, the Company had 9,995,328 authorized shares available for future issuance under all of its stock incentive plans.

[0001511737-16-000037:notes:46]
[same as prior period, unchanged from 0001511737-16-000032:notes:45]

[0001511737-16-000037:notes:47]
The following table shows total stock-based compensation expense included in the Condensed Consolidated Statements of Operations for the three and nine months ended March 31, 2016 and 2015 (in thousands):

[0001511737-16-000037:notes:48]
|  | Three Months Ended March 31, |  | Nine Months Ended March 31, |
|  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Cost of sales | $ | 114 |  |  | $ | 141 |  |  | $ | 341 |  |  | $ | 440 |  |
| Research and development | 566 |  |  | 810 |  |  | 1,770 |  |  | 2,499 |  |
| Sales, general and administrative | 202 |  |  | 425 |  |  | 755 |  |  | 1,240 |  |
|  | $ | 882 |  |  | $ | 1,376 |  |  | $ | 2,866 |  |  | $ | 4,179 |  |

[0001511737-16-000037:notes:49]
[same as prior period, unchanged from 0001511737-16-000032:notes:48]

[0001511737-16-000037:notes:50]
The following is a summary of option activity for the Company’s stock incentive plans for the nine months ended March 31, 2016:

[0001511737-16-000037:notes:51]
|  | Common Stock Options Outstanding |
|  | Numberof Shares |  | WeightedAverageExercisePrice |  | WeightedAverageRemainingContractualLife (Years) |  | AggregateIntrinsicValue(In thousands) |
| Balance, June 30, 2015 | 2,301,144 |  |  | $ | 2.38 |  |  |  |  |  |
| Exercised | (127,397 | ) |  | 6.10 |  |  |  |  |  |
| Forfeitures and cancellations | (4,324 | ) |  | 13.75 |  |  |  |  |  |
| Balance, March 31, 2016 | 2,169,423 |  |  | 2.14 |  |  | 2.94 |  | $ | 67,531 |  |
| Vested and expected to vest as of March 31, 2016 | 2,168,114 |  |  | $ | 2.14 |  |  | 2.94 |  | $ | 67,502 |  |
| Vested and exercisable as of March 31, 2016 | 2,112,635 |  |  | $ | 1.89 |  |  | 2.84 |  | $ | 66,286 |  |

[0001511737-16-000037:notes:52]
During the three months ended March 31, 2016 and 2015, the aggregate intrinsic value of options exercised under the Company’s stock incentive plans was $1.3 million and $2.1 million, respectively, as determined as of the date of option exercise.  During the nine months ended March 31, 2016 and 2015, the aggregate intrinsic value of options exercised under the Company’s stock incentive plans was $3.5 million and $7.1 million, respectively, as determined as of the date of option exercise.

[0001511737-16-000037:notes:53]
As of March 31, 2016, the Company had unrecognized compensation costs of $0.3 million related to stock options which the Company expects to recognize over a weighted-average period of 0.7 years. Future option grants will increase the amount of compensation expense to be recorded in these periods.

[0001511737-16-000037:notes:54]
The Company estimates the fair value of employee stock options using the Black-Scholes option pricing model. The fair value of employee stock options is amortized on a straight-line basis over the requisite service period of the awards.  The Company did not grant any employee stock options during the three and nine months ended March 31, 2016 and 2015.

[0001511737-16-000037:notes:55]
[same as prior period, unchanged from 0001511737-16-000032:notes:54]

[0001511737-16-000037:notes:56]
[same as prior period, unchanged from 0001511737-16-000032:notes:55]

[0001511737-16-000037:notes:57]
|  | Number of Shares |  | Weighted Average Grant Date Fair Value Per Share |
| Non-vested RSUs, June 30, 2015 | 400,635 |  |  | $ | 26.95 |  |
| RSUs granted | 125,032 |  |  | 30.89 |  |
| RSUs vested | (116,561 | ) |  | 24.28 |  |
| RSUs cancelled | (93,926 | ) |  | 31.68 |  |
| Non-vested RSUs, March 31, 2016 | 315,180 |  |  | $ | 28.09 |  |

[0001511737-16-000037:notes:58]
The intrinsic value of RSUs vested in the three months ended March 31, 2016 and 2015 was $0.9 million and $1.9 million, respectively.  The intrinsic value of RSUs vested in the nine months ended March 31, 2016 and 2015 was $3.7 million and $5.7 million, respectively.

[0001511737-16-000037:notes:59]
As of March 31, 2016, there were unrecognized compensation costs related to RSUs of $6.4 million which the Company expects to recognize over a weighted average period of 3.2 years.


## us-gaap:EarningsPerShareTextBlock

[0001511737-16-000037:notes:60]
[same as prior period, unchanged from 0001511737-16-000032:notes:59]

[0001511737-16-000037:notes:61]
[same as prior period, unchanged from 0001511737-16-000032:notes:60]

[0001511737-16-000037:notes:62]
|  | Three Months Ended March 31, |  | Nine Months Ended March 31, |
|  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Numerator: |  |  |  |
| Net income and comprehensive income | $ | 52,699 |  |  | $ | 41,137 |  |  | $ | 155,910 |  |  | $ | 125,145 |  |
| Denominator: |  |  |  |
| Weighted-average shares used in computing basic net income per share | 83,349 |  |  | 87,904 |  |  | 85,051 |  |  | 88,115 |  |
| Add—dilutive potential common shares: |  |  |  |  |  |  |  |
| Stock options | 1,264 |  |  | 1,367 |  |  | 1,282 |  |  | 1,417 |  |
| Restricted stock units | 72 |  |  | 129 |  |  | 100 |  |  | 175 |  |
| Weighted-average shares used in computing diluted net income per share | 84,685 |  |  | 89,400 |  |  | 86,433 |  |  | 89,707 |  |
| Net income per share of common stock: |  |  |  |
| Basic | $ | 0.63 |  |  | $ | 0.47 |  |  | $ | 1.83 |  |  | $ | 1.42 |  |
| Diluted | $ | 0.62 |  |  | $ | 0.46 |  |  | $ | 1.80 |  |  | $ | 1.40 |  |

[0001511737-16-000037:notes:63]
The Company excludes potentially dilutive securities from its diluted net income per share calculation when their effect would be anti-dilutive to net income per share amounts.  The following table summarizes the total potential shares of common stock that were excluded from the diluted per share calculation as including them would have been anti-dilutive for the period (in thousands):

[0001511737-16-000037:notes:64]
|  | Three Months Ended March 31, |  | Nine Months Ended March 31, |
|  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Stock Options | — |  |  | 1 |  |  | — |  |  | — |  |
| Restricted stock units | 16 |  |  | 101 |  |  | — |  |  | 5 |  |
|  | 16 |  |  | 102 |  |  | — |  |  | 5 |  |


## us-gaap:FairValueAssetsAndLiabilitiesMeasuredOnRecurringAndNonrecurringBasisTableTextBlock

[0001511737-16-000037:notes:65]
As of March 31, 2016 and June 30, 2015, the fair value hierarchy of the Company’s debt carried at historical cost was as follows (in thousands):

[0001511737-16-000037:notes:66]
|  | March 31, 2016 |  | June 30, 2015 |
|  | FairValue |  | Level 1 |  | Level 2 |  | Level 3 |  | FairValue |  | Level 1 |  | Level 2 |  | Level 3 |
| Debt | $ | 156,000 |  |  | $ | — |  |  | $ | 156,000 |  |  | $ | — |  |  | $ | 97,500 |  |  | $ | — |  |  | $ | 97,500 |  |  | $ | — |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001511737-16-000037:notes:67]
[same as prior period, unchanged from 0001511737-16-000032:notes:66]

[0001511737-16-000037:notes:68]
[same as prior period, unchanged from 0001511737-16-000032:notes:67]

[0001511737-16-000037:notes:69]
[same as prior period, unchanged from 0001511737-16-000032:notes:68]

[0001511737-16-000037:notes:70]
[same as prior period, unchanged from 0001511737-16-000032:notes:69]

[0001511737-16-000037:notes:71]
[same as prior period, unchanged from 0001511737-16-000032:notes:70]

[0001511737-16-000037:notes:72]
For certain of the Company’s financial instruments, including accounts receivable and accounts payable, the carrying amounts approximate fair value due to their short maturities.  Additionally, as of March 31, 2016, we held $489.0 million of our $502.5 million of cash and cash equivalents in accounts of our subsidiaries outside of the United States and we could incur significant tax liabilities if we were to repatriate those amounts.

[0001511737-16-000037:notes:73]
At March 31, 2016 and June 30, 2015 the Company had debt associated with its Amended Credit Agreement with Wells Fargo Bank (See Note 7). The fair value of the Company’s debt was estimated based on the current rates offered to the Company for debt with similar terms and remaining maturities and was Level 2 measurement.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001511737-16-000037:notes:74]
[same as prior period, unchanged from 0001511737-16-000032:notes:73]

[0001511737-16-000037:notes:75]
As of March 31, 2016, the Company had approximately $22.2 million of unrecognized tax benefits, substantially all of which would, if recognized, affect its tax expense. The Company has elected to include interest and penalties related to uncertain tax positions as a component of tax expense. At March 31, 2016, an insignificant amount of interest and penalties are included in long-term income tax payable. The Company recorded a net increase of its unrecognized tax benefits of $0.3 million for the three months ended March 31, 2016. The Company does not expect any significant increases or decreases to its unrecognized tax benefits in the next twelve months.

[0001511737-16-000037:notes:76]
The Company recorded a tax provision of $6.9 million and $19.2 million for the three and nine months ended March 31, 2016, respectively.  The Company’s estimated fiscal year 2016 effective tax rate differs from the U.S. statutory rate primarily due to profits earned in jurisdictions where the tax rate is lower than the U.S. tax rate.

[0001511737-16-000037:notes:77]
The Company files U.S. federal income tax returns as well as income tax returns in various states and foreign jurisdictions. The Company’s tax filings from fiscal year 2010 and onwards could be subject to examinations by tax authorities.

[0001511737-16-000037:notes:78]
On July 27, 2015, in Altera Corp. v. Commissioner, the U.S. Tax Court issued an opinion related to the treatment of stock-based compensation expense in an intercompany cost-sharing arrangement.  On February 19, 2016, the U.S. Department of the Treasury filed a notice of appeal and has not withdrawn the requirement to include stock-based compensation from its regulations. We have reviewed this case and its potential impact on Ubiquiti and concluded that no adjustment to the condensed consolidated financial statements is appropriate at this time. We will continue to monitor ongoing developments and potential impacts to our consolidated financial statements.

[0001511737-16-000037:notes:79]
As discussed in Note 2, in November 2015, the FASB issued ASU No. 2015-17, Balance Sheet Classification of Deferred Taxes. We are currently evaluating ASU 2015-17 to determine if this guidance will have a material impact on our consolidated financial statements.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001511737-16-000037:notes:80]
Recent Accounting Pronouncements

[0001511737-16-000037:notes:81]
In June 2014, the Financial Accounting Standards Board, or FASB, issued a new accounting standard update on revenue from contracts with customers.  The core principle of the guidance is that an entity should recognize revenue to depict the transfer of promised goods or services to customers in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services.  To achieve that core principle, an entity should apply the following steps:

[0001511737-16-000037:notes:82]
Step 1: Identify the contract(s) with a customer.

[0001511737-16-000037:notes:83]
Step 2: Identify the performance obligations in the contract.

[0001511737-16-000037:notes:84]
Step 3: Determine the transaction price.

[0001511737-16-000037:notes:85]
Step 4: Allocate the transaction price to the performance obligations in the contract.

[0001511737-16-000037:notes:86]
Step 5: Recognize revenue when (or as) the entity satisfies a performance obligation.

[0001511737-16-000037:notes:87]
An entity should disclose sufficient information to enable users of financial statements to understand the nature, amount, timing, and uncertainty of revenue and cash flows arising from contracts with customers. Qualitative and quantitative information is required about contracts with customers, significant judgments and any assets recognized from the costs to obtain or fulfill a contract.   The guidance was initially effective for annual and interim reporting periods beginning after December 15, 2016.  However, in July 2015, the FASB voted to defer the effective date by one year, to December 15, 2017, to provide adequate time to effectively implement the new standard.  The Company does not anticipate that the new guidance will have a material impact on its consolidated financial statements.

[0001511737-16-000037:notes:88]
In April 2015, the FASB issued Accounting Standards Update (“ASU”) 2015-03 to simplify the presentation of debt issuance costs.  The updated guidance requires that debt issuance costs related to a recognized debt liability be presented in the balance sheet as a direct deduction from the carrying amount of that debt liability, consistent with debt discounts. The recognition and measurement guidance for debt issuance costs are not affected by the updated guidance.  The guidance will be effective for the Company beginning July 1, 2016.  The guidance will result only in a reclassification on the Company’s balance sheet and will not have any effect on the Company’s results of operations or cash flows.

[0001511737-16-000037:notes:89]
In July 2015, the FASB issued ASU 2015-11 which explains how the Accounting Standards Codification will be updated to simplify the measurement of inventory costs.  The updated guidance requires that inventory be valued at the lower of cost or net realizable value.  This differs from current guidance which requires that inventory be valued at the lower of cost or market, where market can be replacement cost, net realizable value or net realizable value less an approximately normal profit margin.  The guidance will be effective for the Company beginning July 1, 2017.  The Company does not anticipate that this guidance will have a material impact on the Company’s consolidated financial statements.

[0001511737-16-000037:notes:90]
In November 2015, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update No. 2015-17, Balance Sheet Classification of Deferred Taxes. ASU 2015-17 simplifies the presentation of deferred taxes by requiring deferred tax assets and liabilities be classified as non-current on the balance sheet. ASU 2015-17 is effective for public companies for annual reporting periods beginning after December 15, 2016, and interim periods within those fiscal years. The guidance may be adopted prospectively or retrospectively, and early adoption is permitted.  The Company is currently evaluating ASU 2015-17 but does not anticipate that this guidance will have a material impact on the presentation of the Company's consolidated financial statements.

[0001511737-16-000037:notes:91]
In February 2016, the FASB issued ASU 2016-02, “Leases (Topic 842),” (“ASU 2016-02”). ASU 2016-02 requires lessees to recognize assets and liabilities on the balance sheet for leases with lease terms greater than twelve months and disclose key information about leasing arrangements. ASU 2016-02 is effective for annual periods beginning after December 15, 2018, including interim periods within those fiscal years, with early application permitted. The Company is evaluating the impact that adoption of this new standard will have on its consolidated financial statements.

[0001511737-16-000037:notes:92]
In March 2016, the FASB issued ASU 2016-08, “Revenue from Contracts with Customers (Topic 606) Principal versus Agent Considerations (Reporting Revenue Gross versus Net),” (“ASU 2016-08”). ASU 2016-08 further clarifies principal and agent relationships within ASU 2014-09. The amendment is effective beginning after December 14, 2017, including interim reporting periods within that reporting year. The Company is evaluating the impact that adoption of this new standard will have on its consolidated financial statements.

[0001511737-16-000037:notes:93]
In March 2016, the FASB issued ASU 2016-09, “Compensation-Stock Compensation (Topic 718), Improvements to Employee Share-Based Payment Accounting,” (“ASU 2016-09”). ASU 2016-09 is intended to simplify several aspects of accounting for share-based payment awards. The amendment is effective for annual periods beginning after December 15, 2016, and interim periods within those annual periods. The Company is evaluating the impact that adoption of this new standard will have on its consolidated financial statements.


## us-gaap:OtherCurrentLiabilitiesTableTextBlock

[0001511737-16-000037:notes:94]
[same as prior period, unchanged from 0001511737-16-000032:notes:90]

[0001511737-16-000037:notes:95]
|  | March 31, 2016 |  | June 30, 2015 |
| Accrued expenses | $ | 4,160 |  |  | $ | 5,540 |  |
| Accrued compensation and benefits | 1,397 |  |  | 2,142 |  |
| Warranty accrual | 2,169 |  |  | 2,750 |  |
| Deferred revenue - short term | 2,732 |  |  | 2,538 |  |
| Customer deposits | 2,009 |  |  | 63 |  |
| Reserve for sales returns | 2,249 |  |  | 1,227 |  |
| Other payables | 1,157 |  |  | 910 |  |
|  | $ | 15,873 |  |  | $ | 15,170 |  |


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001511737-16-000037:notes:96]
[same as prior period, unchanged from 0001511737-16-000032:notes:92]

[0001511737-16-000037:notes:97]
The Company offers warranties on certain products and records a liability for the estimated future costs associated with potential warranty claims. The warranty costs are reflected in the Company’s consolidated statement of operations and comprehensive income within cost of revenues. The warranties are typically in effect for twelve months from the distributor’s purchase date of the product. The Company’s estimate of future warranty costs is largely based on historical factors including product failure rates, material usage, and service delivery cost incurred in replacing products. In certain circumstances, the Company may have recourse from its contract manufacturers for replacement cost of defective products, which it also factors into its warranty liability assessment.

[0001511737-16-000037:notes:98]
[same as prior period, unchanged from 0001511737-16-000032:notes:94]

[0001511737-16-000037:notes:99]
|  | Nine Months Ended March 31, |
|  | 2016 |  | 2015 |
| Beginning balance | $ | 2,750 |  |  | $ | 2,850 |  |
| Accruals for warranties issued during the period | 1,574 |  |  | 3,253 |  |
| Settlements made during the period | (2,155 | ) |  | (2,953 | ) |
|  | $ | 2,169 |  |  | $ | 3,150 |  |


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0001511737-16-000037:notes:100]
[same as prior period, unchanged from 0001511737-16-000032:notes:96]

[0001511737-16-000037:notes:101]
|  | March 31, 2016 |  | June 30, 2015 |
| Testing equipment | $ | 5,482 |  |  | $ | 4,816 |  |
| Computer and other equipment | 4,785 |  |  | 4,458 |  |
| Tooling equipment | 5,429 |  |  | 4,073 |  |
| Furniture and fixtures | 1,326 |  |  | 1,239 |  |
| Leasehold improvements | 5,078 |  |  | 4,789 |  |
| Software (1) | 2,398 |  |  | 3,268 |  |
| Software in development (1),(2) | 2,669 |  |  | 2,700 |  |
|  | 27,167 |  |  | 25,343 |  |
| Less: Accumulated depreciation and amortization (3) | (14,040 | ) |  | (9,741 | ) |
|  | $ | 13,127 |  |  | $ | 15,602 |  |

[0001511737-16-000037:notes:102]
(1) - In the nine months ended March 31, 2016, the Company recorded a $2.5 million impairment charge for capitalized software development costs due to the cancellation of the commercial launch of certain software and software in development.  No new impairment charges were recorded for the three months ended March 31, 2016.

[0001511737-16-000037:notes:103]
(2) - We capitalized $100 thousand and $1.3 million for software development for the three and nine months ended March 31, 2016, respectively.

[0001511737-16-000037:notes:104]
(3) - Depreciation expense was $1.4 million and $4.3 million for the three and nine months ended March 31, 2016, respectively.


## us-gaap:ReconciliationOfRevenueFromSegmentsToConsolidatedTextBlock

[0001511737-16-000037:notes:105]
[same as prior period, unchanged from 0001511737-16-000032:notes:101]

[0001511737-16-000037:notes:106]
|  | Three Months Ended March 31, |  | Nine Months Ended March 31, |
|  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Service Provider Technology | $ | 96,326 |  |  | 58 | % |  | $ | 106,242 |  |  | 72 | % |  | $ | 309,341 |  |  | 64 | % |  | $ | 313,233 |  |  | 70 | % |
| Enterprise Technology | 71,107 |  |  | 42 | % |  | 41,214 |  |  | 28 | % |  | 171,378 |  |  | 36 | % |  | 137,447 |  |  | 30 | % |
| Total revenues | $ | 167,433 |  |  | 100 | % |  | $ | 147,456 |  |  | 100 | % |  | $ | 480,719 |  |  | 100 | % |  | $ | 450,680 |  |  | 100 | % |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001511737-16-000037:notes:107]
RELATED PARTY TRANSACTIONS AND CERTAIN OTHER TRANSACTIONS

[0001511737-16-000037:notes:108]
Aircraft Lease Agreement

[0001511737-16-000037:notes:109]
On November 13, 2013, the Company entered into an aircraft lease agreement (the “Aircraft Lease Agreement”) with RJP Manageco LLC (the “Lessor”), a limited liability company owned by the Company’s CEO, Robert J. Pera. Pursuant to the Aircraft Lease Agreement, the Company may lease an aircraft owned by the Lessor for Company business purposes. Under the Aircraft Lease Agreement, the aircraft may be leased at a rate of $5,000 per flight hour. This hourly rate does not include the cost of flight crew or on-board services, which the Company purchases from a third-party provider. The Company recognized a total of approximately $373 thousand and $980 thousand in expenses pursuant to the Aircraft Lease Agreement during the three and nine months ended March 31, 2016, respectively.  In comparison, the Company recognized a total of approximately $150 thousand and $330 thousand in expenses pursuant to the Aircraft Lease Agreement during the three and nine months ended March 31, 2015, respectively. All expenses pursuant to the Aircraft Lease Agreement have been included in the Company’s sales, general and administrative expenses in the Condensed Consolidated Statements of Operations.


## us-gaap:RevenueFromExternalCustomersByGeographicAreasTableTextBlock

[0001511737-16-000037:notes:110]
[same as prior period, unchanged from 0001511737-16-000032:notes:106]

[0001511737-16-000037:notes:111]
|  | Three Months Ended March 31, |  | Nine Months Ended March 31, |
|  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| North America (1) | $ | 57,791 |  |  | 35 | % |  | $ | 45,692 |  |  | 31 | % |  | $ | 168,158 |  |  | 35 | % |  | $ | 153,400 |  |  | 34 | % |
| South America | 15,450 |  |  | 9 | % |  | 17,866 |  |  | 12 | % |  | 61,393 |  |  | 13 | % |  | 71,242 |  |  | 16 | % |
| Europe, the Middle East and Africa | 73,269 |  |  | 44 | % |  | 66,770 |  |  | 45 | % |  | 194,745 |  |  | 40 | % |  | 177,474 |  |  | 39 | % |
| Asia Pacific | 20,923 |  |  | 12 | % |  | 17,128 |  |  | 12 | % |  | 56,423 |  |  | 12 | % |  | 48,564 |  |  | 11 | % |
| Total revenues | $ | 167,433 |  |  | 100 | % |  | $ | 147,456 |  |  | 100 | % |  | $ | 480,719 |  |  | 100 | % |  | $ | 450,680 |  |  | 100 | % |

[0001511737-16-000037:notes:112]
| (1) | Revenue for the United States was $54.6 million and $43.9 million for the three months ended March 31, 2016 and 2015, respectively. Revenue for the United States was $158.8 million and $146.1 million for the nine months ended March 31, 2016 and 2015, respectively. |


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0001511737-16-000037:notes:113]
[same as prior period, unchanged from 0001511737-16-000032:notes:109]

[0001511737-16-000037:notes:114]
|  | March 31, 2016 |  | June 30, 2015 |
| Finished goods | $ | 40,897 |  |  | $ | 35,848 |  |
| Raw materials | 1,879 |  |  | 1,183 |  |
|  | $ | 42,776 |  |  | $ | 37,031 |  |


## us-gaap:ScheduleOfOtherAssetsNoncurrentTextBlock

[0001511737-16-000037:notes:115]
[same as prior period, unchanged from 0001511737-16-000032:notes:111]

[0001511737-16-000037:notes:116]
|  | March 31, 2016 |  | June 30, 2015 |
| Intangible assets, net (1) | $ | 669 |  |  | $ | 575 |  |
| Debt issuance costs, net (2) | 750 |  |  | 943 |  |
| Other long-term assets | 842 |  |  | 591 |  |
|  | $ | 2,261 |  |  | $ | 2,109 |  |

[0001511737-16-000037:notes:117]
(1) - Accumulated amortization was $885 thousand and $690 thousand as of March 31, 2016 and June 30, 2015, respectively.

[0001511737-16-000037:notes:118]
(2) - Accumulated amortization was $274 thousand and $84 thousand as of March 31, 2016 and June 30, 2015, respectively.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001511737-16-000037:notes:119]
[same as prior period, unchanged from 0001511737-16-000032:notes:115]

[0001511737-16-000037:notes:120]
[same as prior period, unchanged from 0001511737-16-000032:notes:116]

[0001511737-16-000037:notes:121]
[same as prior period, unchanged from 0001511737-16-000032:notes:117]

[0001511737-16-000037:notes:122]
[same as prior period, unchanged from 0001511737-16-000032:notes:118]


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001511737-16-000037:notes:123]
[same as prior period, unchanged from 0001511737-16-000032:notes:120]

[0001511737-16-000037:notes:124]
[same as prior period, unchanged from 0001511737-16-000032:notes:121]

[0001511737-16-000037:notes:125]
In April 2016, the FASB issued ASU 2016-10, “Revenue from Contracts with Customers (Topic 606): Identifying Performance Obligations and Licensing." This ASU addresses certain implementation issues that have surfaced since the issuance of ASU 2014-09 in May 2014. The ASU provides guidance in identifying performance obligations and determining the appropriate accounting for licensing arrangements. The amendments in this ASU are effective for fiscal years beginning after December 15, 2017, and for interim periods therein. The Company is in the process of assessing the impact that adoption of this new standard will have on its consolidated financial statements.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001511737-16-000037:notes:126]
[same as prior period, unchanged from 0001511737-16-000032:notes:123]

[0001511737-16-000037:notes:127]
As of March 31, 2016 and June 30, 2015, the authorized capital of the Company included 500,000,000 shares of common stock.  As of March 31, 2016 and June 30, 2015, there were 82,916,307 and 87,413,777 shares of common stock outstanding, respectively.

[0001511737-16-000037:notes:128]
[same as prior period, unchanged from 0001511737-16-000032:notes:125]

[0001511737-16-000037:notes:129]
Effective August 7, 2015, the Board of Directors approved a $100 million stock repurchase program. Under the stock repurchase program, the Company was authorized to repurchase up to $100 million of its common stock.  All common stock repurchased by the Company is immediately retired.  Upon retirement, the excess over par value is recorded as a reduction in Additional Paid-in Capital until the balance is reduced to zero, with any additional excess recorded to Retained Earnings.  The share repurchase program is funded from existing domestic cash on hand in addition to draws on the revolving credit facility of the Amended Credit Agreement.  In the first quarter of fiscal 2016, the Company repurchased 1,872,469 shares of its common stock at an average price per share of $33.79 for an aggregate amount of $63.3 million.  Of the $63.3 million of repurchases and retirements, $1.1 million was recorded against Additional Paid-in Capital and $62.2 million against Retained Earnings.  In the second quarter of fiscal 2016, the Company repurchased 1,074,749 shares of its common stock at an average price per share of $34.12 for an aggregate amount of $36.7 million, extinguishing the full $100 million of availability under this stock repurchase program.  Of the $36.7 million of repurchases and retirements, $1.1 million was recorded against Additional Paid-in Capital and $35.6 million against Retained Earnings.

[0001511737-16-000037:notes:130]
Effective November 6, 2015, the Board of Directors of the Company approved a stock repurchase program where the Company may repurchase up to $50 million of its common stock.  During the third quarter of fiscal 2016, the Company repurchased  1,765,523 shares of its common stock at an average price per share of $28.30 for an aggregate amount of $50.0 million, extinguishing the full $50.0 million available under this stock repurchase program. Of the $50.0 million of repurchases, $1.2 million was recorded against Additional Paid-in Capital and $48.8 million against Retained Earnings.

[0001511737-16-000037:notes:131]
Effective May 4, 2016, the Board of Directors of the Company approved a new $50 million stock repurchase program. Under the new stock repurchase program, the Company may repurchase up to $50 million of its common stock. The program expires on March 31, 2017.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001511737-16-000037:notes:132]
[same as prior period, unchanged from 0001511737-16-000032:notes:128]

[0001511737-16-000037:notes:133]
[same as prior period, unchanged from 0001511737-16-000032:notes:129]

[0001511737-16-000037:notes:134]
[same as prior period, unchanged from 0001511737-16-000032:notes:130]

[0001511737-16-000037:notes:135]
[same as prior period, unchanged from 0001511737-16-000032:notes:131]

[0001511737-16-000037:notes:136]
[same as prior period, unchanged from 0001511737-16-000032:notes:132]

[0001511737-16-000037:notes:137]
[same as prior period, unchanged from 0001511737-16-000032:notes:133]


## us-gaap:UnusualOrInfrequentItemsDisclosureTextBlock

[0001511737-16-000037:notes:138]
[same as prior period, unchanged from 0001511737-16-000032:notes:134]

[0001511737-16-000037:notes:139]
As disclosed in Note 14 of the Annual Report, in June 2015 the Company determined that it was the victim of a criminal fraud known to law enforcement authorities as business e-mail compromise fraud which involved employee impersonation and fraudulent requests targeting our finance department.  The fraud resulted in transfers of funds aggregating $46.7 million held by a Company subsidiary incorporated in Hong Kong to other overseas accounts held by third parties.  As of June 30, 2015, the Company recovered $8.1 million.  As a result, the Company recorded a charge of $39.1 million in the fourth quarter of fiscal 2015, including additional expenses consisting of professional service fees associated with the fraud loss.  During the first fiscal quarter of 2016, the Company secured a court order for an additional recovery of $8.6 million.  As a result, the Company recorded a net recovery of $8.0 million for the three months ended September 31, 2015, comprised of the $8.6 million recovery less $564 thousand of professional service fees associated with the recovery.  As of September 30, 2015, $6.0 million of the $8.6 million was recorded as receivable.  During the second fiscal quarter of 2016, the Company collected the $6.0 million, receiving $5.6 million in cash net of $400 thousand in foreign exchange loss and transaction fees. Additionally, the Company recorded a net recovery of $257 thousand as a result of incurring $344 thousand less in BEC legal expenses than previously accrued at September 30, 2015 offset by $87 thousand in transaction fees.  No additional recoveries were made during the three months ended March 31, 2016.

[0001511737-16-000037:notes:140]
[same as prior period, unchanged from 0001511737-16-000032:notes:136]
