# UI MD&A — 0001511737-17-000011


## mdna

[0001511737-17-000011:mdna:1]
[same as prior period, unchanged from 0001628280-17-004928:mdna:1]

[0001511737-17-000011:mdna:2]
[same as prior period, unchanged from 0001628280-17-004928:mdna:2]

[0001511737-17-000011:mdna:3]
Ubiquiti Networks develops high performance networking technology for service providers, enterprises and consumers globally. Our technology platforms focus on delivering highly-advanced and easily deployable solutions that appeal to a global customer base in underserved and underpenetrated markets. Our differentiated business model has enabled us to break down traditional barriers such as high product and network deployment costs and offer solutions with disruptive price-performance characteristics. The Company maintains an industry leading financial profile by leveraging a unique business model. This differentiated business model, combined with our innovative proprietary technologies, has resulted in an attractive alternative to traditional high touch, high cost providers, allowing us to advance the market adoption of our platforms for ubiquitous connectivity. Since our founding, more than 70 million devices have been sold worldwide through a network of over 100 distributors and on-line retailers, to customers in more than 200 countries and territories. As a result, our technology has enabled hundreds of millions of people throughout the world to stay connected.

[0001511737-17-000011:mdna:4]
We offer a broad and expanding portfolio of networking products and solutions for service providers and enterprises. Our service provider product platforms provide carrier-class network infrastructure for fixed wireless broadband, wireless backhaul systems and routing and the related software for entrepreneurs to easily control, track and bill their customers. Our enterprise product platforms provide wireless LAN (WLAN) infrastructure, video surveillance products, switching and routing solutions, security gateways, and other complimentary WLAN products along with a unique software platform, which enables users to control their network from one simple, easy to use interface. Our consumer products, sold under the Ubiquiti Labs brand name, are targeted to the smart home and highly connected consumers. We believe that our products are highly differentiated due to our proprietary software protocol innovation, firmware expertise, and hardware design capabilities. This differentiation allows our portfolio to meet the demanding performance requirements of video, voice and data applications at prices that are a fraction of those offered by our competitors.

[0001511737-17-000011:mdna:5]
In fiscal 2017, we announced Ubiquiti Labs, a division focusing on research and development of consumer electronics and introduced a new consumer product platform, called AmpliFi, which is a Wi-Fi system solution designed to serve the demands of the modern connected home. AmpliFi is distributed through a network of retailers including Sam’s Club, Best Buy and Game Stop, as well as on-line retailers Amazon.com and Bestbuy.com among others. This division is focused on delivery of direct to consumer based solutions in an array of high technology products. FrontRow, a new platform for consumers, was launched in August 2017.

[0001511737-17-000011:mdna:6]
As a core part of our strategy, we have developed a differentiated business model for marketing and selling high volumes of carrier and enterprise-class communications platforms. Our business model is driven by a large, growing and highly engaged community of service providers, distributors, value added resellers, systems integrators and corporate IT professionals, which we refer to as the Ubiquiti Community. The Ubiquiti Community is an important element of our business strategy as it enables us to drive:

[0001511737-17-000011:mdna:7]
| • | Rapid customer and community driven product development. We have an active, loyal community built by our customers, service providers, IT professionals, distributors and others that we believe is a sustainable competitive advantage. Our solutions benefit from the active engagement between the Ubiquiti Community and our development engineers throughout the product development cycle, which eliminates long and expensive multistep internal processes and results in rapid introduction and adoption of our products. This approach significantly reduces our development costs and time to market. |

[0001511737-17-000011:mdna:8]
| • | Scalable sales and marketing model. We do not currently have, nor do we plan to hire, a direct sales force, but instead utilize the Ubiquiti Community to drive market awareness and demand for our products and solutions. This community- |

[0001511737-17-000011:mdna:9]
propagated, viral marketing enables us to reach underserved and underpenetrated markets far more efficiently and cost-effectively than is possible through a traditional direct sales force model. Leveraging the information transparency of the Internet allows customers to research, evaluate and validate our solutions with the Ubiquiti Community and via third-party web sites. This allows us to operate a scalable sales and marketing model and effectively create awareness for our brand and products. Word-of-mouth referrals from the Ubiquiti Community generate high quality leads for our distributors at relatively little cost.

[0001511737-17-000011:mdna:10]
[same as prior period, unchanged from 0001628280-17-004928:mdna:10]

[0001511737-17-000011:mdna:11]
[same as prior period, unchanged from 0001628280-17-004928:mdna:11]

[0001511737-17-000011:mdna:12]
[same as prior period, unchanged from 0001628280-17-004928:mdna:12]

[0001511737-17-000011:mdna:13]
[same as prior period, unchanged from 0001628280-17-004928:mdna:13]

[0001511737-17-000011:mdna:14]
[same as prior period, unchanged from 0001628280-17-004928:mdna:14]

[0001511737-17-000011:mdna:15]
[same as prior period, unchanged from 0001628280-17-004928:mdna:15]

[0001511737-17-000011:mdna:16]
| • | Service Provider Technology includes our airMAX, EdgeMAX, UFiber, and airFiber platforms, as well as embedded radio products and other 802.11 standard products including base stations, radios, backhaul equipment and CPE. Additionally, Service Provider Technology includes antennas and other products primarily in the 0.9 to 6.0 GHz spectrum and miscellaneous products such as mounting brackets, cables and power over Ethernet adapters. |

[0001511737-17-000011:mdna:17]
| • | Enterprise Technology includes our UniFi and mFi platforms, including UniFi enterprise Wi-Fi, UniFi Video Products, UniFi switching and routing solutions. Enterprise Technology also includes FrontRow, AmpliFi products and revenues that are attributable to PCS. |

[0001511737-17-000011:mdna:18]
We sell our products and solutions globally to service providers and enterprises primarily through our extensive network of

[0001511737-17-000011:mdna:19]
distributors, and, to a lesser extent, direct customers. Sales to distributors accounted for 99% of revenues during the three months ended September 30, 2017.

[0001511737-17-000011:mdna:20]
[same as prior period, unchanged from 0001628280-17-004928:mdna:19]

[0001511737-17-000011:mdna:21]
Our cost of revenues is comprised primarily of the costs of procuring finished goods from our contract manufacturers and chipsets that we consign to certain of our contract manufacturers. In addition, cost of revenues includes labor and other costs associated with engineering, including salary, benefits and stock-based compensation in addition to costs associated with tooling, testing and quality assurance, warranty fees, logistics fees and excess and obsolete inventory reserves.

[0001511737-17-000011:mdna:22]
We operate a warehouse located in Utah and outsource other logistics warehousing and order fulfillment functions located primarily in China, and to a lesser extent, Poland. We also evaluate and utilize other vendors for various portions of our supply chain from time to time. Our operations organization consists of employees and consultants engaged in the management of our contract manufacturers, new product introduction activities, logistical support and engineering.

[0001511737-17-000011:mdna:23]
[same as prior period, unchanged from 0001628280-17-004928:mdna:22]

[0001511737-17-000011:mdna:24]
[same as prior period, unchanged from 0001628280-17-004928:mdna:23]

[0001511737-17-000011:mdna:25]
[same as prior period, unchanged from 0001628280-17-004928:mdna:24]

[0001511737-17-000011:mdna:26]
[same as prior period, unchanged from 0001628280-17-004928:mdna:25]

[0001511737-17-000011:mdna:27]
[same as prior period, unchanged from 0001628280-17-004928:mdna:26]

[0001511737-17-000011:mdna:28]
| • | Sales, general and administrative expenses include salary and benefit expenses, including stock-based compensation, for employees and costs for contractors engaged in customer support, marketing and general and administrative activities, as well as the costs of legal expenses, trade shows, marketing programs, promotional materials, bad debt expense, professional services, facilities, general liability insurance and travel. As our product portfolio and targeted markets expand, we may need to employ different sales models, such as building a direct sales force. These sales models would likely increase our costs. Over time, we expect our sales, general and administrative expenses to increase in absolute dollars due to continued growth in headcount, expansion of our efforts to register and defend trademarks and patents and to support our business and operations. |

[0001511737-17-000011:mdna:29]
[same as prior period, unchanged from 0001628280-17-004928:mdna:28]

[0001511737-17-000011:mdna:30]
We recognize revenues when persuasive evidence of an arrangement exists, delivery has occurred, the sales price is fixed or determinable and the collectability of the resulting receivable is reasonably assured. In cases where we lack evidence that all of these criteria have been met, we defer recognition of revenue.  We defer the cost of products associated with these deferred revenues until we recognize revenue based on revenue recognition guidance under U.S. GAAP.

[0001511737-17-000011:mdna:31]
Included in our deferred revenues is a portion related to PCS obligations that we estimate we will fulfill in the future. As of September 30, 2017 and June 30, 2017, we had deferred revenues of $8.5 million and $7.9 million, respectively, related to these obligations.

[0001511737-17-000011:mdna:32]
[same as prior period, unchanged from 0001628280-17-004928:mdna:31]

[0001511737-17-000011:mdna:33]
[same as prior period, unchanged from 0001628280-17-004928:mdna:32]

[0001511737-17-000011:mdna:34]
[same as prior period, unchanged from 0001628280-17-004928:mdna:33]

[0001511737-17-000011:mdna:35]
Comparison of Three Months Ended September 30, 2017 and 2016

[0001511737-17-000011:mdna:36]
|  | Three Months Ended September 30, |
|  | 2017 |  | 2016 |
|  | (In thousands, except percentages) |
| Revenues | $ | 245,868 |  |  | 100 | % |  | $ | 204,757 |  |  | 100 | % |
| Cost of revenues (1) | 134,212 |  |  | 55 | % |  | 106,453 |  |  | 52 | % |
| Gross profit | 111,656 |  |  | 45 | % |  | 98,304 |  |  | 48 | % |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development (1) | 16,928 |  |  | 7 | % |  | 14,539 |  |  | 7 | % |
| Sales, general and administrative (1) | 7,665 |  |  | 3 | % |  | 8,863 |  |  | 4 | % |
| Total operating expenses | 24,593 |  |  | 10 | % |  | 23,402 |  |  | 11 | % |
| Income from operations | 87,063 |  |  | 35 | % |  | 74,902 |  |  | 37 | % |
| Interest expense and other, net | (1,361 | ) |  | (1 | )% |  | (1,099 | ) |  | (1 | )% |
| Income before provision for income taxes | 85,702 |  |  | 35 | % |  | 73,803 |  |  | 36 | % |
| Provision for income taxes (2) | 10,777 |  |  | 4 | % |  | 2,015 |  |  | 1 | % |
| Net income and comprehensive income | $ | 74,925 |  |  | 30 | % |  | $ | 71,788 |  |  | 35 | % |
| * Less than 1% |  |  |  |  |  |  |  |
| (1) Includes stock-based compensation as follows: |  |  |  |  |  |  |  |
| Cost of revenues | $ | 245 |  |  |  |  | $ | 144 |  |  |  |
| Research and development | 456 |  |  |  |  | 560 |  |  |  |
| Sales, general and administrative | 211 |  |  |  |  | 223 |  |  |  |
| Total stock-based compensation | $ | 912 |  |  |  |  | $ | 927 |  |  |  |
| (2) Includes the excess tax benefits resulting from the adoption of ASU 2016-09 Stock Compensation | $ | (575 | ) |  |  |  | $ | (6,820 | ) |  |  |

[0001511737-17-000011:mdna:37]
[same as prior period, unchanged from 0001628280-17-004928:mdna:36]

[0001511737-17-000011:mdna:38]
Total revenues increased $41.1 million, or 20%, from $204.8 million in the three months ended September 30, 2016 to $245.9 million in the three months ended September 30, 2017. During the three months ended September 30, 2017, there were no material price changes in the Company's products sold.  During these periods there were changes in product mix, including a higher mix of Enterprise Technology products sold as compared to the three months ended September 30, 2016.

[0001511737-17-000011:mdna:39]
[same as prior period, unchanged from 0001628280-17-004928:mdna:39]

[0001511737-17-000011:mdna:40]
|  | Three Months Ended September 30, |
|  | 2017 |  | 2016 |
|  | (in thousands, except percentages) |
| Service Provider Technology | $ | 119,915 |  |  | 49 | % |  | $ | 120,632 |  |  | 59 | % |
| Enterprise Technology | 125,953 |  |  | 51 | % |  | 84,125 |  |  | 41 | % |
| Total revenues | $ | 245,868 |  |  | 100 | % |  | $ | 204,757 |  |  | 100 | % |

[0001511737-17-000011:mdna:41]
Service Provider Technology revenue decreased $0.7 million, or 1%, from $120.6 million in the three months ended September 30, 2016 to $119.9 million in the three months ended September 30, 2017.

[0001511737-17-000011:mdna:42]
The slight decrease in Service Provider Technology revenue during the three months ended September 30, 2017 as compared to the same period in the prior year was primarily due to decreased revenue in Europe, the Middle East and Africa ("EMEA") and Asia Pacific, partially offset by an increase in revenue in South America and North America.

[0001511737-17-000011:mdna:43]
Enterprise Technology revenue increased $41.9 million, or 50%, from $84.1 million in the three months ended September 30, 2016 to $126.0 million in the three months ended September 30, 2017.  The increase in Enterprise Technology revenue during

[0001511737-17-000011:mdna:44]
the three months ended September 30, 2017 as compared to the same period in the prior year was primarily due to product expansion and further adoption of our UniFi technology platform across all regions.

[0001511737-17-000011:mdna:45]
[same as prior period, unchanged from 0001628280-17-004928:mdna:45]

[0001511737-17-000011:mdna:46]
We have determined the geographical distribution of our product revenues based on our customers’ ship-to destinations. A majority of our sales are to distributors who either sell to resellers or directly to end customers, who may be located in different countries than the initial ship-to destination.  The following are our revenues by geography for the three months ended September 30, 2017 and 2016 (in thousands, except percentages):

[0001511737-17-000011:mdna:47]
|  | Three Months Ended September 30, |
|  | 2017 |  | 2016 |
| North America(1) | $ | 96,170 |  |  | 39 | % |  | $ | 74,165 |  |  | 36 | % |
| South America | 31,053 |  |  | 13 | % |  | 24,184 |  |  | 12 | % |
| Europe, the Middle East and Africa ("EMEA") | 93,314 |  |  | 38 | % |  | 81,375 |  |  | 40 | % |
| Asia Pacific | 25,331 |  |  | 10 | % |  | 25,033 |  |  | 12 | % |
| Total revenues | $ | 245,868 |  |  | 100 | % |  | $ | 204,757 |  |  | 100 | % |

[0001511737-17-000011:mdna:48]
| (1) | Revenue for the United States was $91.8 million and $70.6 million for the three months ended September 30, 2017 and 2016, respectively. |

[0001511737-17-000011:mdna:49]
[same as prior period, unchanged from 0001628280-17-004928:mdna:49]

[0001511737-17-000011:mdna:50]
Revenues in North America increased $22.0 million, or 30%, from $74.2 million in the three months ended September 30, 2016 to $96.2 million in the three months ended September 30, 2017. The increase in North American revenues during the three months ended September 30, 2017 as compared to the same period in the prior year was primarily due to increased revenue for both our Enterprise Technology products and Service Provider Technology products.

[0001511737-17-000011:mdna:51]
[same as prior period, unchanged from 0001628280-17-004928:mdna:51]

[0001511737-17-000011:mdna:52]
Revenues in South America increased $6.9 million, or 29%, from $24.2 million in the three months ended September 30, 2016 to $31.1 million in the three months ended September 30, 2017. The increase in South American revenues during the three months ended September 30, 2017 as compared to the same period in the prior year was primarily due to increased revenue for both our Service Provider Technology products and Enterprise Technology products.

[0001511737-17-000011:mdna:53]
[same as prior period, unchanged from 0001628280-17-004928:mdna:53]

[0001511737-17-000011:mdna:54]
Revenues in EMEA increased $11.9 million, or 15%, from $81.4 million in the three months ended September 30, 2016 to $93.3 million in the three months ended September 30, 2017. The increase in EMEA revenues during the three months ended September 30, 2017 as compared to the same period in the prior year was primarily due to increased revenues from Enterprise Technology products, partially offset by a decline in revenues from Service Provider Technology products.

[0001511737-17-000011:mdna:55]
[same as prior period, unchanged from 0001628280-17-004928:mdna:55]

[0001511737-17-000011:mdna:56]
Revenues in the Asia Pacific region increased $0.3 million, or 1%, from $25.0 million in the three months ended September 30, 2016 to $25.3 million in the three months ended September 30, 2017. The slight increase in Asia Pacific revenues during the three months ended September 30, 2017 as compared to the same period in the prior year was primarily due to increased revenues from Enterprise Technology products offset, in part, by a decline in revenues from Service Provider Technology products.

[0001511737-17-000011:mdna:57]
[same as prior period, unchanged from 0001628280-17-004928:mdna:57]

[0001511737-17-000011:mdna:58]
Cost of revenues increased $27.7 million, or 26%, from $106.5 million in the three months ended September 30, 2016 to $134.2 million in the three months ended September 30, 2017.  The increase was primarily due to our overall increase in revenues and to a lesser extent, an increase in shipping cost, overhead and direct labor costs.

[0001511737-17-000011:mdna:59]
Gross profit margin decreased to 45% in the three months ended September 30, 2017 compared to 48% in the three months ended September 30, 2016. The decrease was primarily due to change in mix of products sold and to a lesser extent, an increase in shipping cost, overhead and direct labor costs.

[0001511737-17-000011:mdna:60]
[same as prior period, unchanged from 0001628280-17-004928:mdna:60]

[0001511737-17-000011:mdna:61]
[same as prior period, unchanged from 0001628280-17-004928:mdna:61]

[0001511737-17-000011:mdna:62]
Research and development (“R&D”) expenses increased $2.4 million, or 16%, from $14.5 million in the three months ended September 30, 2016 to $16.9 million in the three months ended September 30, 2017. As a percentage of revenues, research and development expenses remained flat at 7% for the three months ended September 30, 2017 and 2016.

[0001511737-17-000011:mdna:63]
The increase in research and development expenses in absolute dollars during the three months ended September 30, 2017 was primarily due to increases in headcount and development activities. The increase in headcount and development cost reflects the increased efforts to broaden our research and development activities to introduce new products and new versions of existing products.

[0001511737-17-000011:mdna:64]
[same as prior period, unchanged from 0001628280-17-004928:mdna:64]

[0001511737-17-000011:mdna:65]
Sales, general and administrative expenses decreased $1.2 million, or 14%, from $8.9 million in the three months ended September 30, 2016 to $7.7 million in the three months ended September 30, 2017.  As a percentage of revenues, sales, general and administrative expenses decreased from 4% in the three months ended September 30, 2016 to 3% in the three months ended September 30, 2017.

[0001511737-17-000011:mdna:66]
Decrease in sales, general and administrative expenses in absolute dollars during both the three months ended September 30, 2017 as compared to the same period in the prior year are primarily due lower advisory services costs, partially offset by costs associated to increase in headcount. As a percentage of revenues, sales, general and administrative expenses decreased primarily due to our overall increase in revenues.

[0001511737-17-000011:mdna:67]
[same as prior period, unchanged from 0001628280-17-004928:mdna:68]

[0001511737-17-000011:mdna:68]
Our provision for income taxes increased $8.8 million or 440%, from $2.0 million for the three months ended September 30, 2016 to $10.8 million for the three months ended September 30, 2017. Our effective tax rate increased to 12.6% for the three months ended September 30, 2017 as compared to 2.7% for the three months ended September 30, 2016, primarily due to lower discrete tax benefit of $0.6 million in the three months ended September 30, 2017 as compared to $6.8 million in the three months ended September 30, 2016 associated with the timing of excess tax benefits being realized from share based payment arrangements.

[0001511737-17-000011:mdna:69]
[same as prior period, unchanged from 0001628280-17-004928:mdna:70]

[0001511737-17-000011:mdna:70]
[same as prior period, unchanged from 0001628280-17-004928:mdna:71]

[0001511737-17-000011:mdna:71]
Since inception, our operations primarily have been funded through cash generated by operations and proceeds from our various debt agreements. Cash and cash equivalents increased from $604.2 million at June 30, 2017 to $631.8 million at September 30, 2017.

[0001511737-17-000011:mdna:72]
[same as prior period, unchanged from 0001628280-17-004928:mdna:73]

[0001511737-17-000011:mdna:73]
[same as prior period, unchanged from 0001628280-17-004928:mdna:74]

[0001511737-17-000011:mdna:74]
|  | Three Months Ended September 30, |
|  | 2017 |  | 2016 |
|  | (In thousands) |
| Net cash provided by operating activities | $ | 96,920 |  |  | $ | 32,769 |  |
| Net cash (used in) investing activities | (2,932 | ) |  | (1,064 | ) |
| Net cash (used in) provided by financing activities | (66,376 | ) |  | (9,092 | ) |
| Net increase in cash and cash equivalents | $ | 27,612 |  |  | $ | 22,613 |  |

[0001511737-17-000011:mdna:75]
[same as prior period, unchanged from 0001628280-17-004928:mdna:76]

[0001511737-17-000011:mdna:76]
Net cash provided by operating activities in the three months ended September 30, 2017 of $96.9 million consisted primarily of net income of $74.9 million, in addition to the changes in operating assets and liabilities that resulted in net cash inflows of $18.6 million. These changes consisted primarily of a $19.4 million decrease in inventory partially offset with $15.8 million

[0001511737-17-000011:mdna:77]
increase in vendor deposit due to strategically reducing the purchase of inventory to optimize current warehouse stock levels, $12.0 million decrease in accounts receivable due to increased cash receipts in the period, a $6.7 million decrease in accounts payable and accrued liabilities, a $7.1 million increase in taxes payable due to the timing of federal tax payments, a $1.4 million increase in deferred revenue due to additional deferred revenue transaction including PCS revenue deferrals during the first quarter of fiscal year 2018, and a $1.3 million decrease in prepaid expense and other assets. Overall, cash inflows from operating activities were driven by our net income for the period, which included non-cash adjustments primarily due to stock-based compensation, depreciation and amortization, increases to our provision for inventory obsolescence, and increases to our provision for loss on vendor deposits.  The net of these non-cash adjustments resulted in an increase to our net cash provided by operating activities of $3.4 million.

[0001511737-17-000011:mdna:78]
Net cash provided by operating activities in the three months ended September 30, 2016 of $32.8 million consisted primarily of net income of $71.8 million partially offset by changes in operating assets and liabilities that resulted in net cash outflows of $41.0 million. These changes consisted primarily of a $9.6 million decrease in accounts payable and accrued liabilities, a $12.9 million increase in accounts receivable due to overall higher revenues for the period, and a $22.4 million increase in inventory due to build warehouse stock levels in order to decrease lead times, a $1.8 million increase in taxes payable due to the timing of federal tax payments. Overall, cash inflows from operating activities were driven by our net income for the period, which included non-cash adjustments primarily due to stock-based compensation (net of excess tax benefit), depreciation and amortization, decreases to our provision for inventory obsolescence, and decreases to our provision for vendor deposits. The net of these non-cash adjustments resulted in an increase to our net cash provided by operating activities of $2.0 million.

[0001511737-17-000011:mdna:79]
[same as prior period, unchanged from 0001628280-17-004928:mdna:80]

[0001511737-17-000011:mdna:80]
We used $2.9 million of cash in investing activities during the three months ended September 30, 2017.  Our investing activities consist of capital expenditures and purchase of intangible assets. Capital expenditures for the three months ended September 30, 2017 and 2016 were $2.9 million and $1.0 million, respectively. Additionally, we had cash outflows related to the purchase of intangible assets of $19 thousand and $49 thousand during the three months ended September 30, 2017 and 2016, respectively, consisting primarily of legal costs associated with trademark applications and acquisitions of domain names.

[0001511737-17-000011:mdna:81]
[same as prior period, unchanged from 0001628280-17-004928:mdna:82]

[0001511737-17-000011:mdna:82]
We used $66.4 million of cash in financing activities during the three months ended September 30, 2017. During the three months ended September 30, 2017, we paid $108.0 million for repurchases of our common stock. We also made principal repayments of $3.8 million on our outstanding Term Facility. These cash outflows were partially offset by financing cash inflows of $45.0 million related to draws under our Revolving Facility. Additionally, cash inflows from financing activities included $0.7 million of cash proceeds received from the exercise of stock options partially offset by tax withholdings related to net share settlements of restricted stock units totaling $0.4 million.

[0001511737-17-000011:mdna:83]
We used $9.1 million of cash in financing activities during the three months ended September 30, 2016. During the three months ended September 30, 2016 we paid $6.5 million for repurchases of our common stock. We also made repayments of $2.5 million on our outstanding Term Facility. Additionally, cash inflows from financing activities included $0.7 million of cash proceeds received from the exercise of stock options partially offset by tax withholdings related to net share settlements of restricted stock units totaling $0.8 million.

[0001511737-17-000011:mdna:84]
[same as prior period, unchanged from 0001628280-17-004928:mdna:85]

[0001511737-17-000011:mdna:85]
We believe our existing cash and cash equivalents, cash provided by operations and the availability of additional funds, under the Facilities, will be sufficient to meet our working capital and capital expenditure needs for at least the next twelve months. Our future capital requirements may vary materially from those currently planned and will depend on many factors, including our rate of revenue growth, the timing and extent of spending to support development efforts, the timing of new product introductions, market acceptance of our products and overall economic conditions. As of September 30, 2017, we held $597.3 million of our $631.8 million of cash and cash equivalents in accounts of our subsidiaries outside of the United States and we could incur material tax liabilities if we decide to repatriate those amounts.

[0001511737-17-000011:mdna:86]
On October 31, 2017, the Company, the Cayman Borrower and certain of its subsidiaries entered in the Second Amendment (the “Second Amendment”) to the Amended Credit Agreement. See Note 14 for further discussion.

[0001511737-17-000011:mdna:87]
[same as prior period, unchanged from 0001628280-17-004928:mdna:87]

[0001511737-17-000011:mdna:88]
Our products are generally accompanied by a twelve-month warranty from date of purchase, which covers both parts and labor. Generally, the distributor is responsible for the freight costs associated with warranty returns, and we absorb the freight costs of replacing items under warranty. In accordance with the Financial Accounting Standards Board’s (“FASB’s”), Accounting Standards Codification (“ASC”), 450-20, Loss Contingencies, we record an accrual when we believe it is reasonably estimable and probable based upon historical experience. We record a provision for estimated future warranty work in cost of goods sold upon recognition of revenues, and we review the resulting accrual regularly and periodically adjust it to reflect changes in warranty estimates.

[0001511737-17-000011:mdna:89]
We have entered and may in the future enter into standard indemnification agreements with certain distributors as well as other business partners in the ordinary course of business. These agreements may include provisions for indemnifying the distributor, OEM or other business partner against any claim brought by a third-party to the extent any such claim alleges that a Ubiquiti product infringes a patent, copyright or trademark or violates any other proprietary rights of that third-party. The maximum amount of potential future indemnification is unlimited. The maximum potential amount of future payments we could be required to make under these indemnification agreements is not estimable.

[0001511737-17-000011:mdna:90]
We have agreed to indemnify our directors, officers and certain other employees for certain events or occurrences, subject to certain limits, while such persons are or were serving at our request in such capacity. We may terminate the indemnification agreements with these persons upon the termination of their services with us, but termination will not affect claims for indemnification related to events occurring prior to the effective date of termination. The maximum amount of potential future indemnification is unlimited. We have a Directors and Officers insurance policy that limits our potential exposure. We believe the fair value of these indemnification agreements is minimal. We have not recorded any liabilities for these agreements as of September 30, 2017.

[0001511737-17-000011:mdna:91]
Based upon our historical experience and information known as of the date of this report, we do not believe it is likely that we have a material liability for the above indemnities at September 30, 2017.

[0001511737-17-000011:mdna:92]
[same as prior period, unchanged from 0001628280-17-004928:mdna:92]

[0001511737-17-000011:mdna:93]
The following table summarizes our contractual obligations as of September 30, 2017 for the remainder of fiscal 2018 and future fiscal years (in thousands):

[0001511737-17-000011:mdna:94]
|  | 2018 (remainder) |  | 2019 |  | 2020 |  | 2021 |  | 2022 |  | Thereafter |  | Total |
| Operating leases | $ | 4,497 |  |  | $ | 3,656 |  |  | $ | 2,822 |  |  | $ | 1,701 |  |  | $ | 1,047 |  |  | $ | 604 |  |  | $ | 14,327 |  |
| Debt payment obligations | 11,250 |  |  | 15,000 |  |  | 272,250 |  |  | — |  |  | — |  |  | — |  |  | 298,500 |  |
| Interest and other payments on debt payment obligations | 6,395 |  |  | 8,101 |  |  | 5,288 |  |  | — |  |  | — |  |  | — |  |  | 19,784 |  |
| Purchase obligations | 24,944 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 24,944 |  |
| Other obligations | 4,023 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 4,023 |  |
| Total | $ | 51,109 |  |  | $ | 26,757 |  |  | $ | 280,360 |  |  | $ | 1,701 |  |  | $ | 1,047 |  |  | $ | 604 |  |  | $ | 361,578 |  |

[0001511737-17-000011:mdna:95]
[same as prior period, unchanged from 0001628280-17-004928:mdna:95]

[0001511737-17-000011:mdna:96]
The Company lease its headquarters in New York, NY and other locations worldwide under non cancelable operating leases that expire at various dates through 2023.

[0001511737-17-000011:mdna:97]
Debt and Interest Payment Obligations

[0001511737-17-000011:mdna:98]
On April 14, 2017, the Company, the Cayman Borrower and certain of its subsidiaries entered in the First Amendment (the “First Amendment”) to the Credit Agreement (as amended by the First Amendment, the “Amended Credit Agreement”). The First Amendment increased the maximum aggregate amount of the Revolving Facility from $200.0 million to $300.0 million, but maintained the $100.0 million Term Facility under the Credit Agreement and the option to request increases in the amounts of such Facilities by up to an additional $50.0 million in the aggregate (any such increase to be in each lender’s sole discretion). The Amended Credit Agreement requires the Company to maintain during the term of the Facilities (i) a maximum leverage ratio of 2.50 to 1.00 and (ii) minimum liquidity of $250.0 million, which can be satisfied with unrestricted cash and cash equivalents and up to $50.0 million of availability under the Revolving Facility. All other material terms and provisions of the Amended Credit Agreement remain substantially identical to the terms and provisions in place immediately prior to the effectiveness of the First Amendment, other than the revision or inclusion of certain customary market provisions.  Please see Note 7 of the Notes to the Consolidated Financial Statements for more information. We have calculated estimated interest

[0001511737-17-000011:mdna:99]
payments for our debt based on the applicable rates and payments dates. Although our interest rates on our debt obligations may vary, we have assumed the most recent available interest rates for all years presented. Also included are estimated bank fees to be paid for unused portions of our revolving credit facility.

[0001511737-17-000011:mdna:100]
On October 31, 2017, the Company, the Cayman Borrower and certain of its subsidiaries entered in the Second Amendment (the “Second Amendment”) to the Amended Credit Agreement. Please see Note 14 for further information.

[0001511737-17-000011:mdna:101]
[same as prior period, unchanged from 0001628280-17-004928:mdna:99]

[0001511737-17-000011:mdna:102]
We subcontract with third parties to manufacture our products. During the normal course of business, our contract manufacturers procure components and manufacture product based upon orders placed by us.  If we cancel all or part of the orders, we may still be liable to the contract manufacturers for the cost of the components purchased by the subcontractors to manufacture our products. We periodically review the potential liability, and no significant liabilities for cancellations have been recorded for the three months ended September 30, 2017. Our consolidated financial position and results of operations could be negatively impacted if we were required to compensate the contract manufacturers for any unrecorded liabilities incurred. The Company had inventory purchase obligations for finished goods of $24.9 million as of September 30, 2017.

[0001511737-17-000011:mdna:103]
[same as prior period, unchanged from 0001628280-17-004928:mdna:101]

[0001511737-17-000011:mdna:104]
We had other obligations of $4.0 million as of September 30, 2017, which consisted primarily of commitments related to leasehold improvements and research and development projects.

[0001511737-17-000011:mdna:105]
[same as prior period, unchanged from 0001628280-17-004928:mdna:103]

[0001511737-17-000011:mdna:106]
As of September 30, 2017, we had $28.8 million and an additional $2.1 million for accrued interest, classified as non-current liabilities. At this time, we are unable to make a reasonably reliable estimate of timing of payments in individual years in connection with these tax liabilities; therefore, such amounts are not included in the above contractual obligation table.

[0001511737-17-000011:mdna:107]
[same as prior period, unchanged from 0001628280-17-004928:mdna:105]

[0001511737-17-000011:mdna:108]
[same as prior period, unchanged from 0001628280-17-004928:mdna:106]

[0001511737-17-000011:mdna:109]
[same as prior period, unchanged from 0001628280-17-004928:mdna:107]

[0001511737-17-000011:mdna:110]
When used in this Report, the words “anticipates,” “believes,” “could,” “seeks,” “estimates,” “expects,” “intends,” “may,” “plans” “potential,” “predicts,” “projects,” “should,” “will,” “would” or similar expressions and negatives of those terms are intended to identify forward-looking statements. These are statements that relate to future periods and include statements about our future results, sources of revenue, our continued growth, our gross margins, market trends, our product development, technological developments, the features, benefits and performance of our current and future products, the ability of our products to address a variety of markets, the anticipated growth of demand for connectivity worldwide, our growth strategies, future price reductions, our competitive status, our dependence on our senior management and our ability to attract and retain key personnel, dependency on and concentration of our distributors, our employee relations, current and potential litigation, the effects of government regulations, our compliance with laws and regulations, our expected future operating costs and expenses and expenditure levels for research and development, selling, general and administrative expenses, fluctuations in operating results, fluctuations in our stock price, our payment of dividends, our future liquidity and cash needs, our credit facility, future acquisitions of and investments in complimentary businesses and the expected impact of various accounting policies and rules adopted by the Financial Accounting Standards Board. Forward-looking statements are subject to risks and uncertainties that could cause actual results to differ materially from those projected. These risks and uncertainties include, but are not limited to, factors affecting our quarterly results, our ability to manage our growth, our ability to sustain or increase profitability, demand for our products, our ability to compete, our ability to rapidly develop new technology and introduce new products, our ability to safeguard our intellectual property, trends in the networking industry and fluctuations in general economic conditions, and the risks set forth throughout this Report, including under Part II “Other Information”, Item 1-Legal Proceedings and Item 1A- Risk Factors. These forward-looking statements speak only as of the date hereof. Except as required by law, we expressly disclaim any obligation or undertaking to release publicly any updates or revisions to any forward-looking statements contained herein to reflect any change in our expectations with regard thereto or any change in events, conditions or circumstances on which any such statement is based.
