# UI notes — 0001511737-17-000011


## ubnt:ScheduleOfRevenueAndAccountsReceivableByMajorCustomersByReportingSegmentsTableTableTextBlock

[0001511737-17-000011:notes:1]
[same as prior period, unchanged from 0001628280-17-004928:notes:1]

[0001511737-17-000011:notes:2]
|  | Percentage of Revenues | Percentage of Accounts Receivable |
|  | Three Months Ended September 30, |  | September 30, |  | June 30, |
|  | 2017 |  | 2016 |  | 2017 |  | 2017 |
| Customer A | * |  | * |  | 11% |  | * |
| Customer B | * |  | * |  | 11% |  | 12% |
| Customer C | 12% |  | 10% |  | 17% |  | 18% |

[0001511737-17-000011:notes:3]
[same as prior period, unchanged from 0001628280-17-004928:notes:3]


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001511737-17-000011:notes:4]
Basis of Presentation— The Company's consolidated financial statements and accompanying notes have been prepared in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP”) related to interim financial statements based on applicable Securities and Exchange Commission (“SEC”) rules and regulations. Accordingly, they do not include all the information and footnotes required by U.S. GAAP for complete financial statements. These consolidated financial statements reflect all adjustments, which are, in the opinion of the Company, of a normal and recurring nature and those necessary to state fairly the statements of financial position, results of operations and cash flows for the dates and periods presented. The June 30, 2017 balance sheet was derived from the audited financial statements as of that date. All significant intercompany transactions and balances have been eliminated.

[0001511737-17-000011:notes:5]
These consolidated financial statements should be read in conjunction with the Company’s audited consolidated financial statements for the fiscal year ended June 30, 2017, included in its Annual Report on Form 10-K, as filed with the SEC on August 25, 2017 (the “Annual Report”). The results of operations for the three months ended September 30, 2017 are not necessarily indicative of the results to be expected for any future periods.


## us-gaap:BusinessDescriptionAndBasisOfPresentationTextBlock

[0001511737-17-000011:notes:6]
[same as prior period, unchanged from 0001628280-17-004928:notes:6]

[0001511737-17-000011:notes:7]
Business— Ubiquiti Networks, Inc. and its wholly owned subsidiaries (collectively, “Ubiquiti” or the “Company”) develop high performance networking technology for service providers, enterprises, and consumers globally.

[0001511737-17-000011:notes:8]
The Company operates on a fiscal year ending June 30. In this Quarterly Report, the fiscal year ending June 30, 2018 is referred to as “fiscal 2018” and the fiscal year ended June 30, 2017 is referred to as “fiscal 2017”.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001511737-17-000011:notes:9]
COMMITMENTS AND CONTINGENCIES

[0001511737-17-000011:notes:10]
Operating Leases

[0001511737-17-000011:notes:11]
Certain facilities and equipment are leased under non-cancelable operating leases. The Company generally pays taxes, insurance and maintenance costs on leased facilities and equipment. The Company leases its headquarters in New York, New York and other locations under non-cancelable operating leases that expire at various dates through fiscal 2023.

[0001511737-17-000011:notes:12]
At September 30, 2017, future minimum annual payments under operating leases for the remainder of fiscal 2018 and future fiscal years are as follows (in thousands):

[0001511737-17-000011:notes:13]
|  | 2018 (remainder) |  | 2019 |  | 2020 |  | 2021 |  | 2022 |  | Thereafter |  | Total |
| Operating leases | $ | 4,497 |  |  | $ | 3,656 |  |  | $ | 2,822 |  |  | $ | 1,701 |  |  | $ | 1,047 |  |  | $ | 604 |  |  | $ | 14,327 |  |

[0001511737-17-000011:notes:14]
Purchase Obligations

[0001511737-17-000011:notes:15]
The Company subcontracts with other companies to manufacture our products. During the normal course of business, our contract manufacturers procure components based upon orders placed by us. If we cancel all or part of the orders, we may still be liable to the contract manufacturers for the cost of the components purchased by them to manufacture our products. We periodically review the potential liability under the orders, and to date, no significant liabilities for cancellations have been recorded. Our consolidated financial position and results of operations could be negatively impacted if we were required to compensate the contract manufacturers for unrecorded liabilities incurred. We had inventory purchase obligations for finished goods of $24.9 million as of September 30, 2017.

[0001511737-17-000011:notes:16]
Other Obligations

[0001511737-17-000011:notes:17]
The Company had other obligations of $4.0 million as of September 30, 2017, which consisted primarily of commitments related to leasehold improvements and research and development projects.

[0001511737-17-000011:notes:18]
Indemnification Obligations

[0001511737-17-000011:notes:19]
The Company enters into standard indemnification agreements with many of its business partners in the ordinary course of business. These agreements include provisions for indemnifying the business partner against any claim brought by a third-party to the extent any such claim alleges that a Company product infringes a patent, copyright or trademark, or violates any other proprietary rights of that third-party. The maximum potential amount of future payments the Company could be required to make under these indemnification agreements is not estimable and the Company has not incurred any material costs to defend lawsuits or settle claims related to these indemnification agreements to date.

[0001511737-17-000011:notes:20]
Legal Matters

[0001511737-17-000011:notes:21]
The Company may be involved, from time to time, in a variety of claims, lawsuits, investigations, and proceedings relating to contractual disputes, intellectual property rights, employment matters, regulatory compliance matters and other litigation matters relating to various claims that arise in the normal course of business. The Company determines whether an estimated loss from a contingency should be accrued by assessing whether a loss is deemed probable and can be reasonably estimated. The Company assesses its potential liability by analyzing specific litigation and regulatory matters using available information. The Company develops its views on estimated losses in consultation with inside and outside counsel, which involves a subjective analysis of potential results and outcomes, assuming various combinations of appropriate litigation and settlement strategies. Taking all of the above factors into account, the Company records an amount where it is probable that the Company will incur a loss and where that loss can be reasonably estimated. However, the Company’s estimates may be incorrect and the Company could ultimately incur more or less than the amounts initially recorded.  The Company may also incur significant legal fees, which are expensed as incurred, in defending against these claims. The Company is not currently aware of any pending or threatened litigation that would have a material adverse effect on the Company's financial statements.

[0001511737-17-000011:notes:22]
Shareholder Class Action Lawsuits

[0001511737-17-000011:notes:23]
Beginning on September 7, 2012, two class action lawsuits were filed in the United States District Court for the Northern District of California (the “Court”) against Ubiquiti Networks, Inc., certain of its officers and directors, and the underwriters of its initial public offering, alleging claims under U.S. securities laws (collectively, the “Shareholder Lawsuit”). On January 30, 2013, the plaintiffs filed an amended consolidated complaint. On March 26, 2014, the court issued an order granting a motion to dismiss the complaint with leave to amend. Following the plaintiffs’ decision not to file an amended complaint, on April 16, 2014, the court ordered the dismissal of the lawsuit with prejudice, and entered judgment in favor of the Company and the other defendants, and against the plaintiffs. On May 15, 2014, the plaintiffs filed a notice of appeal from the judgment of the court. The Ninth Circuit heard oral arguments on August 10, 2015. On October 24, 2016, the Ninth Circuit issued an unpublished memorandum opinion, reaffirming the district court’s dismissal of the alleged violations of Section10(b) and 20(a) of the Securities Exchange Act of 1934 and reversing the district court’s dismissal of the alleged violations of Section 11 and 15 of the Securities Act of 1933.

[0001511737-17-000011:notes:24]
On August 4, 2017, the parties to the Shareholder Lawsuit filed with the Court a settlement that they reached to resolve the Shareholder Lawsuit against the defendants. Pursuant to the settlement stipulation and subject to certain conditions therein, the settlement class will receive $6.8 million, funded largely by the Company’s insurance carriers. The settlement is subject to the Court’s approval and its terms may change as a result of the settlement approval process. The final settlement approval hearing is scheduled for December 19, 2017. If the Court approves the settlement and enters a judgment substantially in the form requested by the parties, the settlement will become effective when certain conditions specified in the settlement stipulation are satisfied, including the expiration of any right to appeal the judgment.

[0001511737-17-000011:notes:25]
Synopsys

[0001511737-17-000011:notes:26]
On February 3, 2017, Synopsys, Inc. (“Synopsys”) filed a complaint against the Company, one of our subsidiaries and an employee in the United States District Court for the Northern District of California, alleging claims under the Digital Millennium Copyright Act (“DMCA”). On March 28, 2017, Synopsys filed an amended complaint alleging (i) additional claims under the DMCA, (ii) claims under the Anti-Counterfeiting Act, and (iii) claims for label trafficking, fraud, civil RICO and negligent misrepresentation. On April 11, 2017, the Company moved to dismiss all but the initial DMCA claim in the amended complaint and its subsidiary moved to dismiss for lack of personal jurisdiction and joined the Company’s motion to dismiss certain claims. On August 15, 2017, the court issued an order granting the Company’s motion to dismiss the Anti- Counterfeiting Act claim and certain of the predicate acts alleged under the civil RICO claim. The court denied the motion to dismiss the remaining claims, and denied the subsidiary’s motion to dismiss for lack of jurisdiction. On September 5, 2017, Synopsys filed a Second Amended Complaint.  On September 19, 2017, the defendants answered, and Ubiquiti Networks International Limited (“UNIL”) filed counterclaims for (1) declaratory judgment under 17 U.S.C. § 1201, (2) violation of 18 U.S.C. § 1030, the Computer Fraud and Abuse Act, (3) violation of California Penal Code § 502, the Computer Data Access Fraud Act, (4) trespass to personal property and chattels, (5) conversion, (6) civil RICO pursuant to 18 U.S.C. § 1962(c), (7) RICO conspiracy pursuant to 18 U.S.C. § 1962(d), and (8) common law fraud. Ubiquiti also moved for leave to amend its existing counterclaims against Synopsys, for breach of contract and declaratory judgment under 17 U.S.C. § 1201, to include the counterclaims filed by UNIL.  On October 3, 2017, Synopsys filed its opposition to the Company’s motion for leave to amend its counterclaims, as well as a motion to dismiss UNIL’s counterclaims and an anti-SLAPP motion to strike state law claims by both the Company and UNIL. The Company plans to vigorously defend itself against these claims; however, there can be no assurance that the Company will prevail in the lawsuit. The Company cannot currently estimate the possible loss or range of losses, if any, that it may experience in connection with this litigation.

[0001511737-17-000011:notes:27]
Vivato/XR

[0001511737-17-000011:notes:28]
On April 19, 2017, XR Communications, LLC, d/b/a Vivato Technologies (“Vivato”), filed a complaint against the Company in the United States District Court for the Central District of California, alleging that at least one of the Company’s products infringes United States Patent Numbers 7,062,296 (the “’296 Patent”), 7,729,728 (the “’728 Patent”), and 6,611,231 (the “’231 Patent and, collectively, the “Patents-in-Suit”). The ‘296 and ‘728 Patents are entitled “Forced Beam Switching in Wireless Communication Systems Having Smart Antennas.” The ‘231 Patent is entitled “Wireless Packet Switched Communications Systems and Networks Using Adaptively Steered Antenna Arrays.” Vivato amended its complaint on June 23, 2017 and again on July 6, 2017. According to the complaint, the products accused of infringing the Patents-in-Suit include Wi-Fi access points and routers supporting MU-MIMO, including without limitation access points and routers utilizing the IEEE 802.11ac-2013 standard. Vivato has also recently filed nine other lawsuits asserting the same patents against other defendants in the Central District of California.

[0001511737-17-000011:notes:29]
The Company plans to vigorously defend itself against these claims; however, there can be no assurance that the Company will prevail in the lawsuit. The Company cannot currently estimate the possible loss or range of losses, if any, that it may experience in connection with this litigation.

[0001511737-17-000011:notes:30]
Gericke Shareholder Action

[0001511737-17-000011:notes:31]
On September 25, 2017, a purported class action, captioned Richard Gericke v. Ubiquiti Networks, Inc. et al., No. 17-cv-7279 (the "Gericke Action"), was filed in the United States District Court for the Southern District of New York against the Company and certain of its current and former officers and directors.  The Gericke Action complaint alleges that the defendants made misrepresentations in violation of Sections 10(b) and 20(a) of the Securities Exchange Act of 1934 and Rule 10b-5 promulgated thereunder by making false and/or misleading statements and failing to disclose material adverse facts about the Company's business, operations, and prospects.  A court conference has been scheduled for January 10, 2018 to address any motions to consolidate the Gericke Action and the Klein Action (as discussed further in Note 14) and to appoint lead plaintiff and lead counsel.

[0001511737-17-000011:notes:32]
The Company has retained counsel and plans to vigorously defend itself against these claims.  However, there can be no assurance that the Company will prevail in the lawsuit.  The Company cannot currently estimate the possible loss or range of losses, if any, that it may experience in connection with this litigation.


## us-gaap:DebtDisclosureTextBlock

[0001511737-17-000011:notes:33]
DEBT

[0001511737-17-000011:notes:34]
On March 3, 2015, Ubiquiti Networks, Inc. and Ubiquiti International Holding Company Limited (the “Cayman Borrower”) amended and restated its 2014 Credit Agreement (as defined below) with Wells Fargo Bank, National Association ("Wells Fargo"), the other financial institutions named as lenders therein, and Wells Fargo as administrative agent for the lenders (the "Credit Agreement").  The Credit Agreement replaced the Company's $150.0 million senior secured revolving credit facility under its prior credit agreement dated May 5, 2014 (the "2014 Credit Agreement").

[0001511737-17-000011:notes:35]
On April 14, 2017, the Company, the Cayman Borrower and certain of its subsidiaries entered in the First Amendment (the “First Amendment”) to the Credit Agreement (as amended by the First Amendment, the “Amended Credit Agreement”). The First Amendment increased the maximum aggregate amount of the senior secured credit revolving facility from $200.0 million  to $300.0 million ("Revolving Facility"), but maintained the $100.0 million senior secured term facility ("Term Facility", together with the Revolving Facility, the "Facilities") under the Credit Agreement and the option to request increases in the amounts of such Facilities by up to an additional $50.0 million in the aggregate (any such increase to be in each lender’s sole discretion).

[0001511737-17-000011:notes:36]
The Amended Credit Agreement matures on March 3, 2020. The $100.0 million term loan facility of the Amended Credit Agreement was fully drawn at closing of the original Credit Agreement, and $72.3 million was used to repay the outstanding balance under its prior credit agreement. The Facilities are available for working capital and general corporate purposes that comply with the terms of the Amended Credit Agreement.

[0001511737-17-000011:notes:37]
On October 31, 2017, the Company, the Cayman Borrower and certain of its subsidiaries entered in the Second Amendment (the “Second Amendment”) to the Amended Credit Agreement as further described in Note 14.

[0001511737-17-000011:notes:38]
Our Debt consisted of the following (in thousands):

[0001511737-17-000011:notes:39]
|  | September 30, 2017 |  | June 30, 2017 |
| Term Loan - short term | $ | 15,000 |  |  | $ | 15,000 |  |
| Debt issuance costs, net | (257 | ) |  | (257 | ) |
| Total Debt - short term | 14,743 |  |  | 14,743 |  |
| Term Loan - long term | 57,500 |  |  | 61,250 |  |
| Revolver - long term | 226,000 |  |  | 181,000 |  |
| Debt issuance costs, net | (365 | ) |  | (429 | ) |
| Total Debt - long term | $ | 283,135 |  |  | $ | 241,821 |  |

[0001511737-17-000011:notes:40]
As of September 30, 2017, the interest rate on the term loan was 2.83%. The table below shows the respective interest rates as of September 30, 2017 in addition to interest rate reset dates and rates as available for each revolver draw.

[0001511737-17-000011:notes:41]
|  |  | Interest Rate as of |  |  |  |  |
| Debt Payment Obligations |  | September 30, 2017 |  | Rate Reset Date |  | Reset Rate |
| $69 Million Revolver |  | 2.80% |  | 10/3/2017 |  | 2.77% |
| $18 Million Revolver |  | 2.80% |  | 10/18/2017 |  | 2.78% |
| $16 Million Revolver |  | 2.82% |  | 11/15/2017 |  | * |
| $48 Million Revolver |  | 2.82% |  | 11/30/2017 |  | * |
| $30 Million Revolver |  | 2.82% |  | 12/15/2017 |  | * |
| $45 Million Revolver |  | 2.82% |  | 12/22/2017 |  | * |

[0001511737-17-000011:notes:42]
* - Reset rate not available as of filing date.

[0001511737-17-000011:notes:43]
The Revolving Facility includes a sub-limit of $10.0 million for letters of credit and a sub-limit of $25.0 million for swingline loans.  The Facilities are available for working capital and general corporate purposes that comply with the terms of the Amended Credit Agreement. Under the Amended Credit Agreement, revolving loans and swingline loans may be borrowed, repaid and reborrowed until March 3, 2020, at which time all amounts borrowed must be repaid. The term loan is payable in quarterly installments of 3.75% of the original principal amount of the term loan, in each case plus accrued and unpaid interest. Revolving, swingline and term loans may be prepaid at any time without penalty.

[0001511737-17-000011:notes:44]
Revolving and term loans bear interest, at the Company’s option, at either (i) a floating rate per annum equal to the base rate plus a margin of between 0.50% and 1.25%, depending on the Company’s leverage ratio as of the most recently ended fiscal quarter or (ii) a floating per annum rate equal to the applicable LIBOR rate for a specified period, plus a margin of between 1.50% and 2.25%, depending on the Company’s leverage ratio as of the most recently ended fiscal quarter. Swingline loans bear interest at a floating rate per annum equal to the base rate plus a margin of between 0.50% and 1.25%, depending on the Company’s leverage ratio as of the most recently ended fiscal quarter. Base rate is defined as the greatest of (A) Wells Fargo's prime rate, (B) the federal funds rate plus 0.50% or (C) the applicable LIBOR rate for a period of one month plus 1.00%. A default interest rate shall apply on all obligations during certain events of default under the Amended Credit Agreement at a rate per annum equal to 2.00% above the applicable interest rate. The Company will pay to each lender a facility fee on a quarterly basis based on the unused amount of each lender's commitment to make revolving loans, of between 0.20% and 0.35%, depending on the Company's leverage ratio as of the most recently ended fiscal quarter. The Company will also pay to the applicable lenders on a quarterly basis certain fees based on the daily amount available to be drawn under each outstanding letter of credit, including aggregate letter of credit commissions of between 1.50% and 2.25%, depending on the Company's leverage ratio as of the most recently ended fiscal quarter, and issuance fees of 0.125% per annum. The Company is also obligated to pay Wells Fargo, as agent, fees customary for a credit facility of this size and type.

[0001511737-17-000011:notes:45]
The Amended Credit Agreement requires the Company to maintain during the term of the Facilities (i) a maximum leverage ratio of 2.50 to 1.00 and (ii) minimum liquidity of $250.0 million, which can be satisfied with unrestricted cash and cash equivalents and up to $50.0 million of availability under the Revolving Facility. All other material terms and provisions of the Amended Credit Agreement remain substantially identical to the terms and provisions in place immediately prior to the effectiveness of the First Amendment, other than the revision or inclusion of certain customary market provisions. In addition, the Amended Credit Agreement contains customary affirmative and negative covenants, including covenants that limit or restrict the ability of the Company and its subsidiaries to, among other things, grant liens or enter into agreements restricting their ability to grant liens on property, enter into mergers, dispose of assets, change their accounting or reporting policies,change their business and incur indebtedness, in each case subject to customary exceptions for a credit facility of this size and type. The Amended Credit Agreement includes customary events of default that include, among other things, non-payment of principal, interest or fees, inaccuracy of representations and warranties, violation of covenants, cross default to certain other indebtedness, bankruptcy and insolvency events, material judgments, change of control and certain ERISA events. The occurrence of an event of default could result in the acceleration of the obligations under the Amended Credit Agreement. The obligations of the Company and certain domestic subsidiaries, if any, under the Amended Credit Agreement are required to be guaranteed by such domestic subsidiaries (the "Domestic Guarantors") and are collateralized by substantially all assets (excluding intellectual property) of the Company and the Domestic Guarantors. The obligations of the Cayman Borrower and certain foreign subsidiaries under the Amended Credit Agreement are required to be guaranteed by certain domestic and material foreign subsidiaries (the "Guarantors") and are collateralized by substantially all assets (excluding intellectual property) of the Company and the Guarantors.

[0001511737-17-000011:notes:46]
During the three months ended September 30, 2017, the Company made a payment of $4.3 million against the balance under the Term Facility, of which $3.8 million was a repayment of principal and $0.5 million was payment of interest. During the three months ended September 30, 2017, the Company made a $1.3 million payment of interest under the Revolving Facility.

[0001511737-17-000011:notes:47]
The following table summarizes our estimated debt and interest payment obligations as of September 30, 2017, for the remainder of fiscal 2018 and future fiscal years (in thousands):

[0001511737-17-000011:notes:48]
|  | 2018 (remainder) |  | 2019 |  | 2020 |  | 2021 |  | 2022 |  | Thereafter |  | Total |
| Debt payment obligations | $ | 11,250 |  |  | $ | 15,000 |  |  | $ | 272,250 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 298,500 |  |
| Interest and other payments on debt payment obligations (1) | 6,395 |  |  | 8,101 |  |  | 5,288 |  |  | — |  |  | — |  |  | — |  |  | 19,784 |  |
| Total | $ | 17,645 |  |  | $ | 23,101 |  |  | $ | 277,538 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 318,284 |  |

[0001511737-17-000011:notes:49]
(1) - Interest payments are calculated based on the applicable rates and payment dates as of September 30, 2017. Furthermore, one to three-month payment intervals on the revolving debt have been assumed, consistent with the Company's elections to date.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001511737-17-000011:notes:50]
[same as prior period, unchanged from 0001628280-17-004928:notes:46]

[0001511737-17-000011:notes:51]
[same as prior period, unchanged from 0001628280-17-004928:notes:47]

[0001511737-17-000011:notes:52]
The Company’s 2010 Equity Incentive Plan and 2005 Equity Incentive Plan are described in its Annual Report. As of September 30, 2017, the Company had 10,016,704 authorized shares available for future issuance under all of its stock incentive plans.

[0001511737-17-000011:notes:53]
[same as prior period, unchanged from 0001628280-17-004928:notes:49]

[0001511737-17-000011:notes:54]
The following table shows total stock-based compensation expense included in the Consolidated Statements of Operations for the three months ended September 30, 2017 and 2016 (in thousands):

[0001511737-17-000011:notes:55]
|  | Three Months Ended September 30, |
|  | 2017 |  | 2016 |
| Cost of revenues | $ | 245 |  |  | $ | 144 |  |
| Research and development | 456 |  |  | 560 |  |
| Sales, general and administrative | 211 |  |  | 223 |  |
|  | $ | 912 |  |  | $ | 927 |  |

[0001511737-17-000011:notes:56]
[same as prior period, unchanged from 0001628280-17-004928:notes:52]

[0001511737-17-000011:notes:57]
The following is a summary of option activity for the Company’s stock incentive plans for the three months ended September 30, 2017:

[0001511737-17-000011:notes:58]
|  | Common Stock Options Outstanding |
|  | Numberof Shares |  | WeightedAverageExercisePrice |  | WeightedAverageRemainingContractualLife (Years) |  | AggregateIntrinsicValue(In thousands) |
| Balance, June 30, 2017 | 1,621,601 |  |  | $ | 1.76 |  |  | 1.55 |  | $ | 81,413 |  |
| Exercised | (70,299 | ) |  | $ | 10.27 |  |  |  |  |  |
| Balance, September 30, 2017 | 1,551,302 |  |  | $ | 1.38 |  |  | 1.11 |  | $ | 84,764 |  |
| Vested as of September 30, 2017 | 1,551,302 |  |  | $ | 1.38 |  |  | 1.11 |  | $ | 84,764 |  |
| Vested and exercisable as of September 30, 2017 | 1,551,302 |  |  | $ | 1.38 |  |  | 1.11 |  | $ | 84,764 |  |

[0001511737-17-000011:notes:59]
During the three months ended September 30, 2017 and 2016, the aggregate intrinsic value of options exercised under the Company’s stock incentive plans was $3.9 million and $20.7 million, respectively, as determined as of the date of option exercise.

[0001511737-17-000011:notes:60]
As of September 30, 2017, the Company had no unrecognized compensation costs related to stock options.

[0001511737-17-000011:notes:61]
The Company estimates the fair value of employee stock options using the Black-Scholes option pricing model. The fair value of employee stock options is amortized on a straight-line basis over the requisite service period of the awards. The Company did not grant any employee stock options during the three months ended September 30, 2017 and 2016.

[0001511737-17-000011:notes:62]
[same as prior period, unchanged from 0001628280-17-004928:notes:58]

[0001511737-17-000011:notes:63]
[same as prior period, unchanged from 0001628280-17-004928:notes:59]

[0001511737-17-000011:notes:64]
|  | Number of Shares |  | Weighted Average Grant Date Fair Value Per Share |
| Non-vested RSUs, June 30, 2017 | 180,373 |  |  | $ | 40.51 |  |
| RSUs granted | 20,026 |  |  | $ | 52.77 |  |
| RSUs vested | (23,460 | ) |  | $ | 36.44 |  |
| RSUs canceled | (3,988 | ) |  | $ | 33.45 |  |
| Non-vested RSUs, September 30, 2017 | 172,951 |  |  | $ | 42.64 |  |

[0001511737-17-000011:notes:65]
The intrinsic value of RSUs vested in the three months ended September 30, 2017 and 2016 was $1.3 million and $2.9 million, respectively. The total intrinsic value of all outstanding RSUs was $9.7 million as of September 30, 2017.

[0001511737-17-000011:notes:66]
As of September 30, 2017, there were unrecognized compensation costs related to RSUs of $5.3 million which the Company expects to recognize over a weighted average period of 3.2 years.


## us-gaap:EarningsPerShareTextBlock

[0001511737-17-000011:notes:67]
[same as prior period, unchanged from 0001628280-17-004928:notes:63]

[0001511737-17-000011:notes:68]
[same as prior period, unchanged from 0001628280-17-004928:notes:64]

[0001511737-17-000011:notes:69]
|  | Three Months Ended September 30, |
|  | 2017 |  | 2016 |
| Numerator: |  |
| Net income and comprehensive income | $ | 74,925 |  |  | $ | 71,788 |  |
| Denominator: |  |
| Weighted-average shares used in computing basic net income per share | 80,135 |  |  | 81,812 |  |
| Add—dilutive potential common shares: |  |  |  |
| Stock options | 1,538 |  |  | 1,920 |  |
| Restricted stock units | 75 |  |  | 122 |  |
| Weighted-average shares used in computing diluted net income per share | 81,748 |  |  | 83,854 |  |
| Net income per share of common stock: |  |
| Basic | $ | 0.93 |  |  | $ | 0.88 |  |
| Diluted | $ | 0.92 |  |  | $ | 0.86 |  |

[0001511737-17-000011:notes:70]
The Company excludes potentially dilutive securities from its diluted net income per share calculation when their effect would be anti-dilutive to net income per share amounts. The following table summarizes the total potential shares of common stock that were excluded from the diluted per share calculation as including them would have been anti-dilutive for the period (in thousands):

[0001511737-17-000011:notes:71]
|  | Three Months Ended September 30, |
|  | 2017 |  | 2016 |
| Restricted stock units | 51 |  |  | 4 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001511737-17-000011:notes:72]
[same as prior period, unchanged from 0001628280-17-004928:notes:71]

[0001511737-17-000011:notes:73]
[same as prior period, unchanged from 0001628280-17-004928:notes:72]

[0001511737-17-000011:notes:74]
[same as prior period, unchanged from 0001628280-17-004928:notes:73]

[0001511737-17-000011:notes:75]
[same as prior period, unchanged from 0001628280-17-004928:notes:74]

[0001511737-17-000011:notes:76]
[same as prior period, unchanged from 0001628280-17-004928:notes:75]

[0001511737-17-000011:notes:77]
For certain of the Company’s financial instruments, including cash, accounts receivable, accounts payable and other current liabilities, the carrying amounts approximate fair value due to their short maturities.  Additionally, as of September 30, 2017, we held $597.3 million of our $631.8 million of cash and cash equivalents in accounts of our subsidiaries outside of the United States, and we would incur material tax liabilities if we were to repatriate those amounts.

[0001511737-17-000011:notes:78]
As of September 30, 2017 and June 30, 2017 the Company had debt associated with its Amended Credit Agreement with Wells Fargo Bank (See Note 7), which are carried at historical cost. The fair value of the Company’s debt was estimated based on the current rates offered to the Company for debt with similar terms and remaining maturities and was a Level 2 measurement. As of September 30, 2017 and June 30, 2017, the fair value of the Company's debt carried at historical cost was $298.5 million and $257.3 million, respectively.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001511737-17-000011:notes:79]
[same as prior period, unchanged from 0001628280-17-004928:notes:78]

[0001511737-17-000011:notes:80]
The Company recorded a tax provision of $10.8 million for the three months ended September 30, 2017 as compared to $2.0 million for the three months ended September 30, 2016.  The increase is primarily related to $0.6 million of recognized excess tax benefits for share-based payments as a discrete item within the provisions for income taxes for the three month ended September 30, 2017 as compared to $6.8 million recorded as a discrete item in the three months ended September 30, 2016.

[0001511737-17-000011:notes:81]
The Company’s estimated fiscal year 2018 effective tax rate differs from the U.S. statutory rate primarily due to profits earned in jurisdictions where the tax rate is lower than the U.S. tax rate.

[0001511737-17-000011:notes:82]
As of September 30, 2017, the Company had approximately $28.8 million of unrecognized tax benefits, substantially all of which would, if recognized, affect its tax expense. The Company recorded a net increase of its unrecognized tax benefits of $1.4 million for the three months ended September 30, 2017. The Company recognizes interest and penalties related to unrecognized tax benefits within the income tax expense line in the accompanying Consolidated Statement of Operations and Comprehensive Income.  Accrued interest and penalties are included within the related tax liability line in the Consolidated Balance Sheet. As of September 30, 2017, the Company had $2.1 million accrued interest related to uncertain tax matters.

[0001511737-17-000011:notes:83]
The Company files income tax returns in United States, various states and certain foreign jurisdictions. Tax years 2011 through 2017 are subject to examination by the U.S. federal tax authorities and by certain foreign tax authorities. Tax years 2012 and 2017 are subject to examinations by the state tax authorities.

[0001511737-17-000011:notes:84]
On July 27, 2015, in Altera Corp. v. Commissioner, the U.S. Tax Court issued an opinion related to the treatment of stock-based compensation expense in an intercompany cost-sharing arrangement. On June 27, 2016, the Internal Revenue Service appealed the court's decision to the Ninth Circuit Court of Appeals. On November 10, 2016, the Internal Revenue Service filed its reply brief.

[0001511737-17-000011:notes:85]
We have reviewed this case and its potential impact on Ubiquiti and concluded that no adjustment to the consolidated financial statements is appropriate at this time. We will continue to monitor ongoing developments and potential impacts to our consolidated financial statements.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001511737-17-000011:notes:86]
Recent Accounting Standards or Updates Not Yet Effective

[0001511737-17-000011:notes:87]
In May 2014, the FASB issued ASU 2014-09, Revenue from Contracts with Customers, with amendments in 2015 and 2016, which creates new ASC Topic 606 ("Topic 606") that will replace most existing revenue recognition guidance in GAAP when it becomes effective. Topic 606 requires an entity to recognize the amount of revenue to which it expects to be entitled for the transfer of promised goods or services to customers. The new standard will be effective for the Company’s first quarter of fiscal year 2019. Topic 606 may be applied retrospectively to each prior period presented or with the cumulative effect recognized as of the date of initial application. The Company is still evaluating the impact of adopting Topic 606 on its consolidated financial statements and related financial statement disclosures, and it has not yet selected a transition method for its adoption of this standard in fiscal 2019.

[0001511737-17-000011:notes:88]
In February 2016, the FASB issued ASU 2016-02, “Leases (Topic 842),” (“ASU 2016-02”). ASU 2016-02 requires lessees to recognize assets and liabilities on the balance sheet for leases with lease terms greater than twelve months and disclose key information about leasing arrangements. ASU 2016-02 is effective for annual periods beginning after December 15, 2018, including interim periods within those fiscal years, with early application permitted. The Company is evaluating the impact that adoption of this new standard will have on its consolidated financial statements.


## us-gaap:OtherCurrentLiabilitiesTableTextBlock

[0001511737-17-000011:notes:89]
[same as prior period, unchanged from 0001628280-17-004928:notes:94]

[0001511737-17-000011:notes:90]
|  | September 30, 2017 |  | June 30, 2017 |
| Accrued expenses | $ | 11,283 |  |  | $ | 9,826 |  |
| Accrued compensation and benefits | 2,269 |  |  | 2,467 |  |
| Warranty accrual | 4,095 |  |  | 3,601 |  |
| Deferred revenue - short term | 6,559 |  |  | 5,254 |  |
| Customer deposits | 252 |  |  | 1,905 |  |
| Reserve for sales returns | 3,708 |  |  | 3,600 |  |
| Other payables | 30,691 |  |  | 6,377 |  |
| Total | $ | 58,857 |  |  | $ | 33,030 |  |


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001511737-17-000011:notes:91]
[same as prior period, unchanged from 0001628280-17-004928:notes:96]

[0001511737-17-000011:notes:92]
The Company offers warranties on certain products and records a liability for the estimated future costs associated with potential warranty claims. The warranty costs are reflected in the Company’s consolidated statements of operations and comprehensive income within cost of revenues. The warranties are typically in effect for twelve months from the distributor’s purchase date of the product. The Company’s estimate of future warranty costs is largely based on historical factors including product failure rates, material usage, and service delivery cost incurred in correcting product failures. In certain circumstances, the Company may have recourse from its contract manufacturers for replacement cost of defective products, which it also factors into its warranty liability assessment.

[0001511737-17-000011:notes:93]
[same as prior period, unchanged from 0001628280-17-004928:notes:98]

[0001511737-17-000011:notes:94]
|  | Three Months Ended September 30, |
|  | 2017 |  | 2016 |
| Beginning balance | $ | 3,601 |  |  | $ | 2,236 |  |
| Accruals for warranties issued during the period | 1,912 |  |  | 1,390 |  |
| Changes in liability for pre-existing warranties during the period | (100 | ) |  | 641 |  |
| Settlements made during the period | (1,318 | ) |  | (1,239 | ) |
| Ending balance | $ | 4,095 |  |  | $ | 3,028 |  |


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0001511737-17-000011:notes:95]
[same as prior period, unchanged from 0001628280-17-004928:notes:100]

[0001511737-17-000011:notes:96]
|  | September 30, 2017 |  | June 30, 2017 |
| Testing equipment | $ | 7,900 |  |  | $ | 7,587 |  |
| Computer and other equipment | 5,877 |  |  | 5,740 |  |
| Tooling equipment | 8,249 |  |  | 7,828 |  |
| Furniture and fixtures | 1,634 |  |  | 1,528 |  |
| Leasehold improvements | 7,878 |  |  | 6,424 |  |
| Software | 5,752 |  |  | 5,601 |  |
| Property and Equipment, Gross | 37,290 |  |  | 34,708 |  |
| Less: Accumulated depreciation | (23,344 | ) |  | (21,792 | ) |
| Property and Equipment, Net | $ | 13,946 |  |  | $ | 12,916 |  |


## us-gaap:ReconciliationOfRevenueFromSegmentsToConsolidatedTextBlock

[0001511737-17-000011:notes:97]
[same as prior period, unchanged from 0001628280-17-004928:notes:102]

[0001511737-17-000011:notes:98]
|  | Three Months Ended September 30, |
|  | 2017 |  | 2016 |
| Service Provider Technology | $ | 119,915 |  |  | 49 | % |  | $ | 120,632 |  |  | 59 | % |
| Enterprise Technology | 125,953 |  |  | 51 | % |  | 84,125 |  |  | 41 | % |
| Total revenues | $ | 245,868 |  |  | 100 | % |  | $ | 204,757 |  |  | 100 | % |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001511737-17-000011:notes:99]
RELATED PARTY TRANSACTIONS AND CERTAIN OTHER TRANSACTIONS

[0001511737-17-000011:notes:100]
Aircraft Lease Agreement

[0001511737-17-000011:notes:101]
On November 13, 2013, the Company entered into an aircraft lease agreement (the “Aircraft Lease Agreement”) with RJP Manageco LLC (the “Lessor”), a limited liability company owned by the Company’s CEO, Robert J. Pera. Pursuant to the Aircraft Lease Agreement, the Company may lease an aircraft owned by the Lessor for Company business purposes. Under the Aircraft Lease Agreement, the aircraft may be leased at a rate of $5,000 per flight hour. This hourly rate does not include the cost of flight crew or on-board services, which the Company purchases from a third-party provider. The Company recognized a total of approximately $0.4 million and $0.7 million in expenses pursuant to the Aircraft Lease Agreement during the three months ended September 30, 2017 and 2016, respectively. All expenses pursuant to the Aircraft Lease Agreement have been included in the Company’s sales, general and administrative expenses in the Consolidated Statements of Operations and Comprehensive Income.


## us-gaap:RevenueFromExternalCustomersByGeographicAreasTableTextBlock

[0001511737-17-000011:notes:102]
[same as prior period, unchanged from 0001628280-17-004928:notes:107]

[0001511737-17-000011:notes:103]
|  | Three Months Ended September 30, |
|  | 2017 |  | 2016 |
| North America(1) | $ | 96,170 |  |  | 39 | % |  | $ | 74,165 |  |  | 36 | % |
| South America | 31,053 |  |  | 13 | % |  | 24,184 |  |  | 12 | % |
| Europe, the Middle East and Africa ("EMEA") | 93,314 |  |  | 38 | % |  | 81,375 |  |  | 40 | % |
| Asia Pacific | 25,331 |  |  | 10 | % |  | 25,033 |  |  | 12 | % |
| Total revenues | $ | 245,868 |  |  | 100 | % |  | $ | 204,757 |  |  | 100 | % |

[0001511737-17-000011:notes:104]
| (1) | Revenue for the United States was $91.8 million and $70.6 million for the three months ended September 30, 2017 and 2016, respectively. |


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0001511737-17-000011:notes:105]
[same as prior period, unchanged from 0001628280-17-004928:notes:110]

[0001511737-17-000011:notes:106]
|  | September 30, 2017 |  | June 30, 2017 |
| Finished goods | $ | 121,567 |  |  | $ | 141,247 |  |
| Raw materials | 10,580 |  |  | 10,361 |  |
| Provision for inventory obsolescence | (9,884 | ) |  | (9,560 | ) |
| Total | $ | 122,263 |  |  | $ | 142,048 |  |


## us-gaap:ScheduleOfOtherAssetsNoncurrentTextBlock

[0001511737-17-000011:notes:107]
[same as prior period, unchanged from 0001628280-17-004928:notes:112]

[0001511737-17-000011:notes:108]
|  | September 30, 2017 |  | June 30, 2017 |
| Intangible assets, net (1) | $ | 416 |  |  | $ | 437 |  |
| Other long-term assets | 1,590 |  |  | 1,891 |  |
| Total | $ | 2,006 |  |  | $ | 2,328 |  |

[0001511737-17-000011:notes:109]
(1) - Accumulated amortization was $1.3 million and $1.2 million as of September 30, 2017 and June 30, 2017, respectively.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001511737-17-000011:notes:110]
[same as prior period, unchanged from 0001628280-17-004928:notes:115]

[0001511737-17-000011:notes:111]
[same as prior period, unchanged from 0001628280-17-004928:notes:116]

[0001511737-17-000011:notes:112]
| • | Service Provider Technology includes our airMAX, EdgeMAX, UFiber and airFiber platforms, as well as embedded radio products and other 802.11 standard products including base stations, radios, backhaul equipment and Customer Premise Equipment (“CPE”). Additionally, Service Provider Technology includes antennas and other products in the 0.9 to 6.0GHz spectrum and miscellaneous products such as mounting brackets, cables and power over Ethernet adapters. |

[0001511737-17-000011:notes:113]
| • | Enterprise Technology includes our UniFi and mFi platforms, including UniFi enterprise Wi-Fi products, Unifi Video products, Unifi switching and routing solutions. Enterprise Technology also includes FrontRow and AmpliFi products and revenues that are attributable to PCS. |


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001511737-17-000011:notes:114]
[same as prior period, unchanged from 0001628280-17-004928:notes:119]

[0001511737-17-000011:notes:115]
The Company’s significant accounting policies are disclosed in its audited consolidated financial statements for the year ended June 30, 2017, included in the Annual Report. Except as noted below, there have been no changes to the Company’s significant accounting policies as discussed in the Annual Report.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001511737-17-000011:notes:116]
[same as prior period, unchanged from 0001628280-17-004928:notes:121]

[0001511737-17-000011:notes:117]
As of September 30, 2017 and June 30, 2017, the authorized capital of the Company included 500,000,000 shares of common stock.  As of September 30, 2017 and June 30, 2017, there were 78,210,182 and 80,275,965 shares of common stock outstanding, respectively.

[0001511737-17-000011:notes:118]
[same as prior period, unchanged from 0001628280-17-004928:notes:123]

[0001511737-17-000011:notes:119]
On May 4, 2016, the Board of Directors of the Company approved a $50 million stock repurchase program. Under the stock repurchase program, the Company was authorized to repurchase up to $50 million of its common stock. During the fourth quarter of fiscal 2016, the Company repurchased and retired 1,309,606 shares of its common stock at an average price per share of $38.18 for an aggregate amount of $50 million. This included unpaid stock repurchases of $6.5 million relating to repurchases executed on or prior to June 30, 2016 for trades that settled in the first quarter of fiscal 2017.

[0001511737-17-000011:notes:120]
On August 3, 2016, the Board of Directors of the Company approved a $50 million stock repurchase program. Under the stock repurchase program, the Company was authorized to repurchase up to $50 million of its common stock. During the third quarter of fiscal 2017, the Company repurchased and retired 1,014,956 shares of its common stock at an average price per share of $49.26 for an aggregate amount of $50 million.

[0001511737-17-000011:notes:121]
On March 3, 2017, the Board of Directors of the Company approved a $50 million stock repurchase program. Under the stock repurchase program, the Company may repurchase up to $50 million of its common stock. The program expires on March 31, 2018. During the third quarter of fiscal 2017, the Company repurchased and retired 917,455 shares of its common stock at an average price per share of $50.43 for an aggregate amount of $46.3 million. This included unpaid stock repurchases of $3.0 million relating to repurchases executed on or prior to March 31, 2017 for trades that settled in the fourth quarter of fiscal 2017. During the fourth quarter of fiscal 2017, the Company repurchased and retired 50,000 shares of its common stock at an average price per share of $49.55 for an aggregate amount of $2.5 million. As of June 30, 2017, the Company had $1.3 million available under the stock repurchase program.

[0001511737-17-000011:notes:122]
During the first quarter of fiscal 2018, the Board of Directors of the Company approved a $50 million stock repurchase program on September 5, 2017 and an additional $100 million stock repurchase program on September 18, 2017. Both programs expire on September 30, 2018. Under these authorizations, in addition to the $1.3 million available under the March 3, 2017 stock repurchase plan, the Company repurchased and retired 2,148,832 shares of common stock at an average price per share of $54.34 for an aggregate amount of $116.8 million. This included unpaid stock repurchases of $8.8 million relating to repurchases executed on or prior to September 30, 2017 for trades settled in the second quarter of fiscal 2018. As of September 30, 2017, the Company had $34.5 million available under the stock repurchase program.


## us-gaap:SubsequentEventsTextBlock

[0001511737-17-000011:notes:123]
SUBSEQUENT EVENTS

[0001511737-17-000011:notes:124]
Second Amendment to Credit Agreement

[0001511737-17-000011:notes:125]
On October 31, 2017, the Company, the Cayman Borrower and certain of its subsidiaries entered in the Second Amendment (the “Second Amendment”) to the Amended Credit Agreement. The Second Amendment increased the maximum aggregate amount of the Revolving Facility from $300.0 million to $425.0 million, but maintained the $100.0 million Term Facility under the Amended Credit Agreement and the option to request increases in the amounts of such Facilities by up to an additional $50.0 million in the aggregate (any such increase to be in each lender’s sole discretion). All other material terms and provisions of the Amended Credit Agreement remain substantially identical to the terms and provisions in place immediately prior to the effectiveness of the Second Amendment, other than the revision or inclusion of certain customary market provisions.

[0001511737-17-000011:notes:126]
Repurchase Program

[0001511737-17-000011:notes:127]
During the second quarter of fiscal 2018, the Company repurchased and retired 602,192 shares of its common stock at an average price per share of $57.28 for an aggregate amount of $34.5 million. As of October 6, 2017, there is no remaining balance available for share repurchases under the share repurchase programs approved by the Board of Directors in the first quarter of fiscal 2018. On November 8, 2017, the Board of Directors of the Company approved a $50 million stock repurchase program (the "New Program"). Under the New Program, the Company was authorized to repurchase up to $50 million of its common stock. The New Program expires on December 31, 2018.

[0001511737-17-000011:notes:128]
Klein Shareholder Action

[0001511737-17-000011:notes:129]
On October 2, 2017, a purported class action, captioned Gabby Klein v. Ubiquiti Networks, Inc. et al., No. 17-cv-7524 (the "Klein Action"), was filed in the Southern District of New York that contains substantially similar claims and causes of action as the Gericke Action.  A court conference has been scheduled for January 10, 2018 to address any motions to consolidate the Gericke Action (as discussed further in Note 8) and the Klein Action and to appoint lead plaintiff and lead counsel.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001511737-17-000011:notes:130]
[same as prior period, unchanged from 0001628280-17-004928:notes:130]

[0001511737-17-000011:notes:131]
[same as prior period, unchanged from 0001628280-17-004928:notes:131]

[0001511737-17-000011:notes:132]
[same as prior period, unchanged from 0001628280-17-004928:notes:132]

[0001511737-17-000011:notes:133]
[same as prior period, unchanged from 0001628280-17-004928:notes:133]

[0001511737-17-000011:notes:134]
[same as prior period, unchanged from 0001628280-17-004928:notes:134]
