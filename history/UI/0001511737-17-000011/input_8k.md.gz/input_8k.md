# UI 8-K — 0001511737-17-000009 filed 2017-11-09

## item codes, every 8-K on or before 2017-11-09

- 2017-11-09 0001511737-17-000009 — 2.02, 7.01, 8.01, 9.01
- 2017-11-01 0001654954-17-009914 — 1.01, 2.03, 9.01
- 2017-09-19 0001654954-17-008548 — 2.02, 8.01
- 2017-09-05 0001654954-17-008135 — 8.01
- 2017-08-10 0001654954-17-007226 — 7.01, 9.01
- 2017-08-03 0001654954-17-006902 — 2.02, 9.01
- 2017-05-04 0001415889-17-000692 — 2.02, 9.01
- 2017-04-20 0001415889-17-000662 — 1.01, 2.03, 9.01
- 2017-03-03 0001415889-17-000354 — 8.01
- 2017-02-21 0001571049-17-001493 — 7.01, 9.01
- 2017-02-09 0001415889-17-000235 — 2.02, 9.01
- 2016-12-16 0001415889-16-007589 — 5.07
- 2016-12-08 0001415889-16-007559 — 4.01, 8.01, 9.01
- 2016-11-03 0001415889-16-007334 — 2.02, 9.01
- 2016-08-17 0001415889-16-006877 — 8.01
- 2016-08-10 0001415889-16-006753 — 5.02
- 2016-08-04 0001415889-16-006679 — 2.02, 8.01, 9.01
- 2016-05-05 0001415889-16-005749 — 2.02, 5.02, 8.01, 9.01
- 2016-02-04 0001415889-16-004613 — 2.02, 9.01
- 2015-12-18 0001415889-15-004120 — 3.01, 5.07
- 2015-11-05 0001415889-15-003599 — 2.02, 8.01, 9.01
- 2015-10-16 0001415889-15-003433 — 5.02
- 2015-08-06 0001571049-15-006288 — 2.02, 5.02, 8.01, 9.01
- 2015-05-07 0001511737-15-000016 — 2.02, 9.01
- 2015-04-23 0001415889-15-001433 — 2.02, 5.02, 9.01
- 2015-03-06 0001415889-15-000787 — 1.01, 1.02, 2.03, 9.01
- 2015-02-05 0001511737-15-000008 — 2.02, 9.01
- 2014-12-18 0001193125-14-446627 — 5.07
- 2014-11-06 0001511737-14-000029 — 2.02, 9.01
- 2014-09-30 0001193125-14-359060 — 7.01, 9.01
- 2014-08-07 0001511737-14-000021 — 2.02, 9.01
- 2014-05-08 0001511737-14-000016 — 2.02, 9.01
- 2014-04-17 0001193125-14-146710 — 7.01
- 2014-03-06 0001193125-14-084883 — 8.01
- 2014-02-06 0001511737-14-000005 — 2.02, 9.01
- 2013-12-16 0001193125-13-474388 — 5.07
- 2013-11-22 0001193125-13-451511 — 5.02
- 2013-11-07 0001511737-13-000018 — 2.02, 9.01
- 2013-10-28 0001193125-13-413414 — 5.02, 9.01
- 2013-10-18 0001193125-13-404111 — 5.02, 9.01
- 2013-08-08 0001511737-13-000009 — 2.02, 9.01
- 2013-05-09 0001511737-13-000004 — 2.02
- 2013-03-25 0001193125-13-124353 — 5.07
- 2013-03-08 0001193125-13-098334 — 5.02, 9.01
- 2013-02-07 0001193125-13-043701 — 2.02, 9.01
- 2012-12-28 0001193125-12-518487 — 1.01
- 2012-12-17 0001193125-12-503742 — 7.01, 9.01
- 2012-12-13 0001193125-12-501894 — 5.02
- 2012-11-16 0001193125-12-474083 — 5.02
- 2012-11-13 0001193125-12-467376 — 5.02
- 2012-11-08 0001193125-12-460665 — 2.02, 9.01
- 2012-10-10 0001193125-12-420015 — 5.02, 9.01
- 2012-08-13 0001193125-12-352624 — 1.01, 2.03, 9.01
- 2012-08-09 0001193125-12-347776 — 1.01, 9.01
- 2012-08-09 0001193125-12-347732 — 2.02, 9.01
- 2012-05-01 0001193125-12-201012 — 2.02, 9.01
- 2012-03-30 0001193125-12-144074 — 5.02
- 2012-03-27 0001193125-12-134395 — 5.02, 9.01
- 2012-03-22 0001193125-12-127536 — 5.02
- 2012-01-31 0001193125-12-032079 — 2.02, 9.01
- 2011-12-27 0001193125-11-353002 — 1.01, 9.01
- 2011-12-06 0001193125-11-332192 — 5.02
- 2011-11-10 0001193125-11-306969 — 2.02, 9.01

## late-filing notifications on or before 2017-11-09

- none on or before 2017-11-09

## item 2.02 — earnings release, exhibit 99.1

[0001511737-17-000009:8k_2_02:1]
EX-99.1
2
exhibit991-9302017.htm
EXHIBIT 99.1

[0001511737-17-000009:8k_2_02:2]
Exhibit

[0001511737-17-000009:8k_2_02:3]
Exhibit 99.1

[0001511737-17-000009:8k_2_02:4]
UBIQUITI NETWORKS REPORTS FIRST QUARTER FISCAL 2018 FINANCIAL RESULTS

[0001511737-17-000009:8k_2_02:5]
~ Achieves Record Revenue and Ninth Consecutive Quarter of Revenue Growth ~

[0001511737-17-000009:8k_2_02:6]
~ Diluted EPS of $0.92 Per Share ~

[0001511737-17-000009:8k_2_02:7]
New York, NY - November 9, 2017 - Ubiquiti Networks, Inc. (NASDAQ:UBNT) (“Ubiquiti" or the "Company”) today announced results for the first fiscal quarter of 2018, ended September 30, 2017.

[0001511737-17-000009:8k_2_02:8]
First Quarter Fiscal 2018 Financial Summary

[0001511737-17-000009:8k_2_02:9]
| • | Revenues of $245.9 million, increased 20.1% year-over-year |

[0001511737-17-000009:8k_2_02:10]
| • | GAAP gross profit of $111.7 million, representing 45.4% of revenues |

[0001511737-17-000009:8k_2_02:11]
| • | GAAP and non-GAAP net income of $74.9 million |

[0001511737-17-000009:8k_2_02:12]
| • | GAAP and non-GAAP diluted EPS of $0.92 |

[0001511737-17-000009:8k_2_02:13]
First Quarter Financial Highlights

[0001511737-17-000009:8k_2_02:14]
| • | Revenues increased 20.1% year-over-year and 7.6% sequentially. Year-over-year growth was primarily driven by the UniFi-AC, UniFi-Switch, airMAX-AC, airFiber and AmpliFi platforms. |

[0001511737-17-000009:8k_2_02:15]
| • | Enterprise Technology revenues increased over 49.8% year-over-year and 11% sequentially. Year-over-year growth was driven by the evolution toward AC technology products, growth in switching and higher average selling prices. |

[0001511737-17-000009:8k_2_02:16]
| • | GAAP gross margin was 45.4%, consistent with the prior quarter but down versus the prior year primarily due to product mix. |

[0001511737-17-000009:8k_2_02:17]
| • | Days sales outstanding in accounts receivable ("DSO") decreased by 7 days to 48 days, compared with 55 days in the prior quarter driven by higher collections. |

[0001511737-17-000009:8k_2_02:18]
| • | Repurchased 2,751,024 shares of common stock at an average price per share of $54.98, between July 1 and October 6, 2017. |

[0001511737-17-000009:8k_2_02:19]
| • | Increased the maximum amount of availability under our revolving loan facility to $425 million from $300 million, representing an increase of $125 million, as disclosed in the Form 8-K filed on November 1, 2017. |

[0001511737-17-000009:8k_2_02:20]
| • | Initiated a new stock repurchase program, authorizing the Company to repurchase up to $50 million of its common stock, as disclosed in the Form 8-K filed on November 9, 2017. |

[0001511737-17-000009:8k_2_02:21]
Recent Product Highlights

[0001511737-17-000009:8k_2_02:22]
| • | Launched UniFi AC SHD access points, an 802.11AC Wave 2 MU-MIMO access point with a dedicated security radio, providing persistent threat management combined with the latest Wave 2 technology. |

[0001511737-17-000009:8k_2_02:23]
| • | Released GPS Sync for airMAX AC, providing for GPS synchronization between airMAX AC and airMAX M series equipment. |

[0001511737-17-000009:8k_2_02:24]
| • | Launched the airCube, a Wi-Fi access points for use by wireless internet service providers in residential customer deployments, featuring a sleek design, a mobile app and 24V PoE passthrough. |

[0001511737-17-000009:8k_2_02:25]
| • | Introduced FrontRow, featuring a new camera technology that enables effortless capture and sharing of life’s experiences. The product was launched in mid-August and is available through on-line retail including FrontRow.com, Amazon.com, BestBuy.com and through traditional retail channels such as BestBuy and Sam’s Club. |

[0001511737-17-000009:8k_2_02:26]
| • | Announced significant updates to Ubiquiti’s proprietary UCRM software, a customer management platform for wireless internet service providers, including enhanced billing features and multi-language support. |

[0001511737-17-000009:8k_2_02:27]
Financial Highlights ($, in millions, except per share data)

[0001511737-17-000009:8k_2_02:28]
| Income statement highlights |  | F1Q18 |  | F4Q17 |  | F1Q17 |
| Revenues |  | 245.9 |  | 228.6 |  | 204.8 |
| Service Provider Technology |  | 119.9 |  | 114.7 |  | 120.6 |
| Enterprise Technology |  | 126.0 |  | 114.0 |  | 84.1 |
| Gross profit |  | 111.7 |  | 103.2 |  | 98.3 |
| Gross Profit (%) |  | 45.4% |  | 45.1% |  | 48.0% |
| Total Operating Expenses |  | 24.6 |  | 31.5 |  | 23.4 |
| Income from Operations |  | 87.1 |  | 71.7 |  | 74.9 |
| GAAP Net Income |  | 74.9 |  | 60.7 |  | 71.8 |
| GAAP EPS (diluted) |  | 0.92 |  | 0.74 |  | 0.86 |
| Non-GAAP Net Income |  | 74.9 |  | 61.0 |  | 65.5 |
| Non-GAAP EPS (diluted) |  | 0.92 |  | 0.75 |  | 0.79 |

[0001511737-17-000009:8k_2_02:29]
Balance Sheet Highlights

[0001511737-17-000009:8k_2_02:30]
Total cash and cash equivalents as of September 30, 2017 were $631.8 million, compared with $604.2 million as of June 30, 2017.  The Company held $597 million of cash and cash equivalents in accounts of the Company’s subsidiaries outside of the United States.  Cash and cash equivalents, less debt (net cash) of $333.9 million decreased $13.7 million sequentially.  The sequential decrease in net cash during the first quarter of fiscal 2018 was primarily driven by the repurchase of common stock, partially offset by operating earnings.

[0001511737-17-000009:8k_2_02:31]
First quarter fiscal 2018 days sales outstanding in accounts receivable ("DSO") were 48 days, compared with 55 days in the prior quarter, and 43 days in the first quarter of fiscal 2017. DSO's in the current period declined approximately one week versus the prior quarter, driven primarily by higher collections.

[0001511737-17-000009:8k_2_02:32]
Ubiquiti continues to invest in inventory to reduce lead times, meet increasing demand and support the commensurate growth of the Company’s customers.  At the same time, the Company is committed to optimizing inventory to correspond with end-market demand.  Inventory at the end of the quarter decreased $19.8 million to $122.2 million.  Consequently, inventory weeks on hand decreased on a sequential basis to 13 weeks in the current quarter versus 14 weeks the prior quarter.  The Company expects to hold 8 to 12 weeks of previously introduced product inventory in warehouses going forward, in addition to new product inventory and selected raw materials.

[0001511737-17-000009:8k_2_02:33]
Business Outlook

[0001511737-17-000009:8k_2_02:34]
Based on recent business trends, Ubiquiti currently believes the demand environment in its end markets supports the following forecast for the Company's second fiscal quarter ending December 31, 2017:

[0001511737-17-000009:8k_2_02:35]
| • | Revenues of between $240 million and $250 million; |

[0001511737-17-000009:8k_2_02:36]
| • | GAAP diluted EPS of $0.85 - $0.92; |

[0001511737-17-000009:8k_2_02:37]
| • | Gross margins are expected to remain consistent on a sequential basis; and |

[0001511737-17-000009:8k_2_02:38]
| • | An effective tax rate of 13.5%. |

[0001511737-17-000009:8k_2_02:39]
Conference Call Information

[0001511737-17-000009:8k_2_02:40]
Ubiquiti Networks will host a Q&A-only call to discuss the Company’s financial results at 11:00 a.m. Eastern Time (8:00 a.m. Pacific Time) today.  Management’s prepared remarks can be found on the Investor Relations section of the Ubiquiti Networks website, http://ir.ubnt.com/financial/quarterly-results.

[0001511737-17-000009:8k_2_02:41]
To listen to the Q&A call via telephone, dial (866) 807-9684 (U.S. toll-free) or (412) 317-5415 (International) to be connected to the call by an operator. Participants should dial in at least 10 minutes prior to the start of the call.  Investors may also listen to a live webcast of the Q&A conference call by visiting the Investor Relations section of the Ubiquiti Networks website at http://ir.ubnt.com.  A recording of the Q&A call will be available for replay at http://ir.ubnt.com.

[0001511737-17-000009:8k_2_02:42]
A recording of the Q&A call will be available approximately two hours after the call concludes and will be accessible on the Investor Relations section of the Ubiquiti Networks website, http://ir.ubnt.com.

[0001511737-17-000009:8k_2_02:43]
About Ubiquiti Networks

[0001511737-17-000009:8k_2_02:44]
Ubiquiti Networks, Inc. currently focuses on 3 main technologies: high-capacity distributed Internet access, unified information technology, and next-gen consumer electronics for home and personal use. The majority of the company’s resources consist of entrepreneurial and de-centralized R&D teams. Ubiquiti does not employ a traditional direct sales force, but instead drives brand awareness largely through the company’s user community where customers can interface directly with R&D, marketing, and support. With over 70 million devices shipped in over 200 countries and territories in the world, Ubiquiti aims to connect everyone to everything, everywhere. Ubiquiti was founded by former Apple engineer Robert Pera in 2005. More insight about the company management can be found at www.rjpblog.com.

[0001511737-17-000009:8k_2_02:45]
Ubiquiti, Ubiquiti Networks, the U logo, UBNT, airMAX, airFiber, mFi, EdgeMAX, UniFi, AmpliFi and UFiber are registered trademarks or trademarks of Ubiquiti Networks, Inc. in the United States and other countries.

[0001511737-17-000009:8k_2_02:46]
Investor Relations Contact

[0001511737-17-000009:8k_2_02:47]
Laura Kiernan

[0001511737-17-000009:8k_2_02:48]
SVP, Investor Relations

[0001511737-17-000009:8k_2_02:49]
Ubiquiti Networks, Inc.

[0001511737-17-000009:8k_2_02:50]
laura.kiernan@ubnt.com

[0001511737-17-000009:8k_2_02:51]
Ph. 1-914-598-773

[0001511737-17-000009:8k_2_02:52]
Forward-looking statements are subject to certain risks and uncertainties that could cause our actual future results to differ materially, or cause a material adverse impact on our results. Potential risks and uncertainties include, but are not limited to, fluctuations in our operating results; varying demand for our products due to the financial and operating condition of our distributors and their customers, and distributors' inventory management practices; political and economic conditions and volatility affecting the stability of business environments, economic growth, currency values, commodity prices and other factors that may influence the ultimate demand for our products in particular geographies or globally; impact of counterfeiting and our ability to contain such impact; our reliance on a limited number of distributors; inability of our contract manufacturers and suppliers to meet our demand; our dependence on Qualcomm Atheros for chipsets without a short-term alternative; as we move into new markets competition from certain of our current or

[0001511737-17-000009:8k_2_02:53]
potential competitors who may be more established in such markets; our ability to keep pace with technological and market developments; success and timing of new product introductions by us and the performance of our products generally; our ability to effectively manage the significant increase in our transactional sales volumes; we may become subject to warranty claims, product liability and product recalls; that a substantial majority of our sales are into countries outside the United States and we are subject to numerous U.S. export control and economic sanctions laws; costs related to responding to government inquiries related to regulatory compliance; our reliance on the Ubiquiti Community; our reliance on certain key members of our management team, including our founder and chief executive officer, Robert J. Pera; adverse tax-related matters such as tax audits, changes in our effective tax rate or new tax legislative proposals; whether the final determination of our income tax liability may be materially different from our income tax provisions; the impact of any intellectual property litigation and claims for indemnification; litigation related to U.S. Securities laws; and economic and political conditions in the United States and abroad. We discuss these risks in greater detail under the heading “Risk Factors” and elsewhere in our Annual Report on Form 10-K for the year ended June 30, 2017, and subsequent filings filed with the U.S. Securities and Exchange Commission (the “SEC”), which are available at the SEC's website at www.sec.gov. Copies may also be obtained by contacting the Ubiquiti Networks Investor Relations Department, by email at IR@ubnt.com or by visiting the Investor Relations section of the Ubiquiti Networks website, http://ir.ubnt.com.

[0001511737-17-000009:8k_2_02:54]
Given these uncertainties, you should not place undue reliance on these forward-looking statements. Also, forward-looking statements represent our management's beliefs and assumptions only as of the date made. Except as required by law, Ubiquiti Networks undertakes no obligation to update information contained herein. You should review our SEC filings carefully and with the understanding that our actual future results may be materially different from what we expect.

[0001511737-17-000009:8k_2_02:55]
| Ubiquiti Networks, Inc.Condensed Consolidated Statement of Operations(In thousands, except per share data)(Unaudited) |
|  |  | Three Months Ended September 30, |
|  |  | 2017 |  | 2016 |
| Revenues |  | $ | 245,868 |  |  | $ | 204,757 |  |
| Cost of revenues |  | 134,212 |  |  | 106,453 |  |
| Gross profit |  | 111,656 |  |  | 98,304 |  |
| Operating expenses: |  |  |  |  |
| Research and development |  | 16,928 |  |  | 14,539 |  |
| Sales, general and administrative |  | 7,665 |  |  | 8,863 |  |
| Total operating expenses |  | 24,593 |  |  | 23,402 |  |
| Income from operations |  | 87,063 |  |  | 74,902 |  |
| Interest expense and other, net |  | (1,361 | ) |  | (1,099 | ) |
| Income before provision for income taxes |  | 85,702 |  |  | 73,803 |  |
| Provision for income taxes |  | 10,777 |  |  | 2,015 |  |
| Net income and comprehensive income |  | $ | 74,925 |  |  | $ | 71,788 |  |
| Net income per share of common stock: |  |  |  |  |
| Basic |  | $ | 0.93 |  |  | $ | 0.88 |  |
| Diluted |  | $ | 0.92 |  |  | $ | 0.86 |  |
| Weighted average shares used in computing net income per share of common stock: |  |  |  |  |
| Basic |  | 80,135 |  |  | 81,812 |  |
| Diluted |  | 81,748 |  |  | 83,854 |  |

[0001511737-17-000009:8k_2_02:56]
| Ubiquiti Networks, Inc.Reconciliation of GAAP Net Income to Non-GAAP Net Income(In thousands, except per share data)(Unaudited) |  |  |  |  |
|  |  | Three Months Ended September 30, |
|  |  | 2017 |  | 2016 |
| Net income and comprehensive income |  | $ | 74,925 |  |  | $ | 71,788 |  |
| Stock-based compensation: |  |  |  |  |
| Cost of revenues |  | 245 |  |  | 144 |  |
| Research and development |  | 456 |  |  | 560 |  |
| Sales, general and administrative |  | 211 |  |  | 223 |  |
| Excess tax benefits resulting from the adoption of ASU 2016-09 Stock Compensation |  | (575 | ) |  | (6,820 | ) |
| Tax effect of Non-GAAP adjustments |  | (365 | ) |  | (371 | ) |
| Non-GAAP net income |  | $ | 74,897 |  |  | $ | 65,524 |  |
| Non-GAAP diluted EPS |  | $ | 0.92 |  |  | $ | 0.79 |  |
| Shares outstanding (Diluted) |  | 81,748 |  |  | 83,854 |  |
| Share adjustment (ASU 2016-09 Adoption) |  | (616 | ) |  | (774 | ) |
| Weighted-average shares used in Non-GAAP diluted EPS |  | 81,132 |  |  | 83,080 |  |

[0001511737-17-000009:8k_2_02:57]
Use of Non-GAAP Financial Information

[0001511737-17-000009:8k_2_02:58]
To supplement our condensed consolidated financial results prepared under generally accepted accounting principles, or GAAP, we use non-GAAP measures of net income and earnings per diluted share that are adjusted to exclude certain costs, expenses and gains such as stock based compensation expense, the adoption of ASU 2016-09 Improvements to Employee Share-Based Payments Accounting, and the tax effects of these non-GAAP adjustments. Reconciliations of the adjustments to GAAP results for the three months ended September 30, 2017 and 2016 are provided above.  In addition, an explanation of the ways in which management uses non-GAAP financial information to evaluate its business, the substance behind management's decision to use this non-GAAP financial information, material limitations associated with the use of non-GAAP financial information, the manner in which management compensates for those limitations, and the substantive reasons management believes that this non-GAAP financial information provides useful information to investors is included under "About our Non-GAAP Net Income and Adjustments" after the tables below.

[0001511737-17-000009:8k_2_02:59]
| Ubiquiti Networks, Inc.Condensed Consolidated Balance Sheets(In thousands, except share amounts)(Unaudited) |
|  |  | September 30, 2017 |  | June 30, 2017 (1) |
| Assets |  |  |  |  |
| Current assets: |  |  |  |  |
| Cash and cash equivalents |  | $ | 631,810 |  |  | $ | 604,198 |  |
| Accounts receivable, net |  | 128,589 |  |  | 140,561 |  |
| Inventories |  | 122,263 |  |  | 142,048 |  |
| Vendor Deposits |  | 69,542 |  |  | 54,082 |  |
| Prepaid income taxes |  | 2,415 |  |  | 2,419 |  |
| Prepaid expenses and other current assets |  | 8,039 |  |  | 9,026 |  |
| Total current assets |  | 962,658 |  |  | 952,334 |  |
| Property and equipment, net |  | 13,946 |  |  | 12,916 |  |
| Long-term deferred tax assets |  | 5,133 |  |  | 5,133 |  |
| Other long-term assets |  | 2,006 |  |  | 2,328 |  |
| Total assets |  | $ | 983,743 |  |  | $ | 972,711 |  |
| Liabilities and Stockholders’ Equity |  |  |  |  |
| Current liabilities: |  |  |  |  |
| Accounts payable |  | $ | 26,319 |  |  | $ | 49,008 |  |
| Income taxes payable |  | 7,008 |  |  | 1,707 |  |
| Debt - short-term |  | 14,743 |  |  | 14,743 |  |
| Other current liabilities |  | 58,857 |  |  | 33,030 |  |
| Total current liabilities |  | 106,927 |  |  | 98,488 |  |
| Long-term taxes payable |  | 29,783 |  |  | 28,023 |  |
| Debt - long-term |  | 283,135 |  |  | 241,821 |  |
| Deferred revenues - long-term |  | 2,687 |  |  | 2,615 |  |
| Total liabilities |  | 422,532 |  |  | 370,947 |  |
| Stockholders’ equity: |  |  |  |  |
| Common stock |  | 78 |  |  | 80 |  |
| Additional paid–in capital |  | — |  |  | 525 |  |
| Retained earnings |  | 561,133 |  |  | 601,159 |  |
| Total stockholders’ equity |  | 561,211 |  |  | 601,764 |  |
| Total liabilities and stockholders’ equity |  | $ | 983,743 |  |  | $ | 972,711 |  |

[0001511737-17-000009:8k_2_02:60]
(1) Derived from audited consolidated financial statements as of and for the year ended June 30, 2017.

[0001511737-17-000009:8k_2_02:61]
| Ubiquiti Networks, Inc.Revenues by Product Type (In thousands)(Unaudited) |
|  |  | Three Months Ended September 30, |
|  |  | 2017 |  | 2016 |
| Service Provider Technology |  | $ | 119,915 |  |  | $ | 120,632 |  |
| Enterprise Technology |  | 125,953 |  |  | 84,125 |  |
| Total revenues |  | $ | 245,868 |  |  | $ | 204,757 |  |

[0001511737-17-000009:8k_2_02:62]
| Ubiquiti Networks, Inc.Revenues by Geographical Area(In thousands)(Unaudited) |
|  |  | Three Months Ended September 30, |
|  |  | 2017 |  | 2016 |
| North America |  | $ | 96,170 |  |  | $ | 74,165 |  |
| South America |  | 31,053 |  |  | 24,184 |  |
| Europe, the Middle East and Africa ("EMEA") |  | 93,314 |  |  | 81,375 |  |
| Asia Pacific |  | 25,331 |  |  | 25,033 |  |
| Total revenues |  | $ | 245,868 |  |  | $ | 204,757 |  |

[0001511737-17-000009:8k_2_02:63]
| Ubiquiti Networks, Inc.Condensed Consolidated Cash Flows(In thousands)(Unaudited) |
|  | Three Months Ended September 30, |
|  | 2017 |  | 2016 |
| Cash Flows from Operating Activities: |  |  |  |
| Net income | $ | 74,925 |  |  | $ | 71,788 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |
| Depreciation and amortization | 1,655 |  |  | 1,541 |  |
| Provision for inventory obsolescence | 324 |  |  | 80 |  |
| (Recovery)/Provision for loss on vendor deposits | 376 |  |  | (676 | ) |
| Stock-based compensation | 912 |  |  | 927 |  |
| Other, net | 103 |  |  | 135 |  |
| Changes in operating assets and liabilities: |  |  |  |
| Accounts receivable | 12,017 |  |  | (12,925 | ) |
| Inventories | 19,421 |  |  | (22,442 | ) |
| Vendor deposits | (15,836 | ) |  | 843 |  |
| Prepaid income taxes | 4 |  |  | (15 | ) |
| Prepaid expenses and other assets | 1,288 |  |  | 807 |  |
| Accounts payable | (22,408 | ) |  | (9,026 | ) |
| Income taxes payable | 7,061 |  |  | 1,842 |  |
| Deferred revenues | 1,376 |  |  | 466 |  |
| Accrued liabilities and other current liabilities | 15,702 |  |  | (576 | ) |
| Net cash provided by operating activities | 96,920 |  |  | 32,769 |  |
| Cash Flows from Investing Activities: |  |  |  |
| Purchase of property and equipment and other long-term assets | (2,932 | ) |  | (1,064 | ) |
| Net cash (used in) investing activities | (2,932 | ) |  | (1,064 | ) |
| Cash Flows from Financing Activities: |  |  |  |
| Proceeds from revolver loan | 45,000 |  |  | — |  |
| Repayments of term loan | (3,750 | ) |  | (2,500 | ) |
| Repurchases of common stock | (107,997 | ) |  | (6,483 | ) |
| Proceeds from exercise of stock options | 722 |  |  | 682 |  |
| Tax withholdings related to net share settlements of restricted stock units | (351 | ) |  | (791 | ) |
| Net cash (used in) provided by financing activities | (66,376 | ) |  | (9,092 | ) |
| Net increase in cash and cash equivalents | 27,612 |  |  | 22,613 |  |
| Cash and cash equivalents at beginning of period | 604,198 |  |  | 551,031 |  |
| Cash and cash equivalents at end of period | $ | 631,810 |  |  | $ | 573,644 |  |
| Non-Cash Investing and Financing Activities: |  |  |  |
| Unpaid stock repurchases | $ | 8,765 |  |  | $ | — |  |
| Unpaid property and equipment and other long-term assets | $ | 178 |  |  | $ | 413 |  |

[0001511737-17-000009:8k_2_02:64]
About our Non-GAAP Net Income and Adjustments

[0001511737-17-000009:8k_2_02:65]
Use of Non-GAAP Financial Information

[0001511737-17-000009:8k_2_02:66]
To supplement our condensed consolidated financial results prepared under generally accepted accounting principles, or GAAP, we use non-GAAP measures of net income and earnings per diluted share that are GAAP net income and GAAP earnings per diluted share adjusted to exclude certain costs, expenses and gains/losses.

[0001511737-17-000009:8k_2_02:67]
We believe that the presentation of non-GAAP net income and non-GAAP earnings per diluted share provides important supplemental information regarding non-cash expenses, significant items that we believe are important to understanding our financial, and business trends relating to our financial condition and results of operations.  Non-GAAP net income and non-GAAP earnings per diluted share are among the primary indicators used by management as a basis for planning and forecasting future periods and by management and our board of directors to determine whether our operating performance has met specified targets and thresholds.  Management uses non-GAAP net income and non-GAAP earnings per diluted share when evaluating operating performance because it believes that the exclusion of the items described below, for which the amounts or timing may vary significantly depending upon the Company's activities and other factors, facilitates comparability of the Company's operating performance from period to period.  We have chosen to provide this information to investors so they can analyze our operating results in the same way that management does and use this information in their assessment of our business and the valuation of our Company.

[0001511737-17-000009:8k_2_02:68]
Use and Economic Substance of Non-GAAP Financial Measures used by Ubiquiti Networks

[0001511737-17-000009:8k_2_02:69]
We compute non-GAAP net income and non-GAAP diluted earnings per share by adjusting GAAP net income and GAAP earnings per diluted share to remove the impact of certain adjustments and the tax effect of those adjustments.  Items excluded from net income are:

[0001511737-17-000009:8k_2_02:70]
| • | Stock-based compensation expense |

[0001511737-17-000009:8k_2_02:71]
| • | Adoption of ASU 2016-09 Improvements to Employee Share-Based Payment Accounting |

[0001511737-17-000009:8k_2_02:72]
| • | Tax effect of non-GAAP adjustments, applying the principles of ASC 740 |

[0001511737-17-000009:8k_2_02:73]
Usefulness of Non-GAAP Financial Information to Investors

[0001511737-17-000009:8k_2_02:74]
These non-GAAP measures are not in accordance with, or an alternative to, GAAP and may be materially different from other non-GAAP measures, including similarly titled non-GAAP measures used by other companies.  The presentation of this additional information should not be considered in isolation from, as a substitute for, or superior to, net income or earnings per diluted share prepared in accordance with GAAP.  Non-GAAP financial measures have limitations in that they do not reflect certain items that may have a material impact upon our reported financial results.

[0001511737-17-000009:8k_2_02:75]
For more information on the non-GAAP adjustments, please see the table captioned “Reconciliation of GAAP Net Income to Non-GAAP Net Income” included in this press release.
