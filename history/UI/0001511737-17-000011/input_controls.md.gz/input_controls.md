# UI 10-Q controls and the auditor's report


## item_4_controls

[0001511737-17-000011:item_4_controls:1]
Item 4. Controls and Procedures

[0001511737-17-000011:item_4_controls:2]
Evaluation of Disclosure Controls and Procedures

[0001511737-17-000011:item_4_controls:3]
Management, with the participation of the Company’s Chief Executive Officer and Chief Accounting Officer, evaluated the effectiveness of our disclosure controls and procedures as of September 30, 2017. The term “disclosure controls and procedures,” as defined in Rules 13a-15(e) and 15d-15(e) under the Securities Exchange Act of 1934, as amended (the “Exchange Act”), means controls and other procedures of a company that are designed to ensure that information required to be disclosed by a company in the reports that it files or submits under the Exchange Act is recorded, processed, summarized and reported, within the time periods specified in the SEC’s rules and forms. Disclosure controls and procedures include, without limitation, controls and procedures designed to ensure that information required to be disclosed by a company in the reports that it files or submits under the Exchange Act is accumulated and communicated to the company’s management, including its principal executive and principal financial officers, as appropriate to allow timely decisions regarding required disclosure. Management recognizes that any controls and procedures, no matter how well designed and operated, can provide only reasonable assurance of achieving their objectives. Based on the evaluation of our disclosure controls and procedures as of September 30, 2017, our Chief Executive Officer and Chief Accounting Officer concluded that, as of such date, our disclosure controls and procedures were effective.

[0001511737-17-000011:item_4_controls:4]
Changes in Internal Control over Financial Reporting

[0001511737-17-000011:item_4_controls:5]
There have been no changes in our internal control over financial reporting that occurred during the three months ended September 30, 2017, that materially affected, or that are reasonably likely to materially affect, our internal control over financial reporting.
