# UI note change history — 0001628280-17-004928 → 0001511737-17-000011


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2017-11-09):
[0001511737-17-000011:note_history:1]
Certain facilities and equipment are leased under non-cancelable operating leases. The Company generally pays taxes, insurance and maintenance costs on leased facilities and equipment. The Company leases its headquarters in New York, New York and other locations under non-cancelable operating leases that expire at various dates through fiscal 2023.
  (was, 2017-05-04, similarity 0.951):
[0001628280-17-004928:note_history:1]
Certain facilities and equipment are leased under non-cancelable operating leases. The Company generally pays taxes, insurance and maintenance costs on leased facilities and equipment. The Company leases its headquarters in San Jose, California and other locations under non-cancelable operating leases that expire at various dates through fiscal 2022.

- changed (2017-11-09):
[0001511737-17-000011:note_history:2]
At September 30, 2017, future minimum annual payments under operating leases for the remainder of fiscal 2018 and future fiscal years are as follows (in thousands):
  (was, 2017-05-04, similarity 0.9673):
[0001628280-17-004928:note_history:2]
At March 31, 2017, future minimum annual payments under operating leases for the remainder of fiscal 2017 and future fiscal years are as follows (in thousands):

- added (2017-11-09):
[0001511737-17-000011:note_history:3]
The Company subcontracts with other companies to manufacture our products. During the normal course of business, our contract manufacturers procure components based upon orders placed by us. If we cancel all or part of the orders, we may still be liable to the contract manufacturers for the cost of the components purchased by them to manufacture our products. We periodically review the potential liability under the orders, and to date, no significant liabilities for cancellations have been recorded. Our consolidated financial position and results of operations could be negatively impacted if we were required to compensate the contract manufacturers for unrecorded liabilities incurred. We had inventory purchase obligations for finished goods of $24.9 million as of September 30, 2017.

- changed (2017-11-09):
[0001511737-17-000011:note_history:4]
The Company had other obligations of $4.0 million as of September 30, 2017, which consisted primarily of commitments related to leasehold improvements and research and development projects.
  (was, 2017-05-04, similarity 0.8882):
[0001628280-17-004928:note_history:4]
The Company had other obligations of $9.8 million as of March 31, 2017, which consisted primarily of commitments related to research and development projects.

- added (2017-11-09):
[0001511737-17-000011:note_history:5]
Beginning on September 7, 2012, two class action lawsuits were filed in the United States District Court for the Northern District of California (the “Court”) against Ubiquiti Networks, Inc., certain of its officers and directors, and the underwriters of its initial public offering, alleging claims under U.S. securities laws (collectively, the “Shareholder Lawsuit”). On January 30, 2013, the plaintiffs filed an amended consolidated complaint. On March 26, 2014, the court issued an order granting a motion to dismiss the complaint with leave to amend. Following the plaintiffs’ decision not to file an amended complaint, on April 16, 2014, the court ordered the dismissal of the lawsuit with prejudice, and entered judgment in favor of the Company and the other defendants, and against the plaintiffs. On May 15, 2014, the plaintiffs filed a notice of appeal from the judgment of the court. The Ninth Circuit heard oral arguments on August 10, 2015. On October 24, 2016, the Ninth Circuit issued an unpublished memorandum opinion, reaffirming the district court’s dismissal of the alleged violations of Section10(b) and 20(a) of the Securities Exchange Act of 1934 and reversing the district court’s dismissal of the alleged violations of Section 11 and 15 of the Securities Act of 1933.

- added (2017-11-09):
[0001511737-17-000011:note_history:6]
On August 4, 2017, the parties to the Shareholder Lawsuit filed with the Court a settlement that they reached to resolve the Shareholder Lawsuit against the defendants. Pursuant to the settlement stipulation and subject to certain conditions therein, the settlement class will receive $6.8 million, funded largely by the Company’s insurance carriers. The settlement is subject to the Court’s approval and its terms may change as a result of the settlement approval process. The final settlement approval hearing is scheduled for December 19, 2017. If the Court approves the settlement and enters a judgment substantially in the form requested by the parties, the settlement will become effective when certain conditions specified in the settlement stipulation are satisfied, including the expiration of any right to appeal the judgment.

- added (2017-11-09):
[0001511737-17-000011:note_history:7]
On February 3, 2017, Synopsys, Inc. (“Synopsys”) filed a complaint against the Company, one of our subsidiaries and an employee in the United States District Court for the Northern District of California, alleging claims under the Digital Millennium Copyright Act (“DMCA”). On March 28, 2017, Synopsys filed an amended complaint alleging (i) additional claims under the DMCA, (ii) claims under the Anti-Counterfeiting Act, and (iii) claims for label trafficking, fraud, civil RICO and negligent misrepresentation. On April 11, 2017, the Company moved to dismiss all but the initial DMCA claim in the amended complaint and its subsidiary moved to dismiss for lack of personal jurisdiction and joined the Company’s motion to dismiss certain claims. On August 15, 2017, the court issued an order granting the Company’s motion to dismiss the Anti- Counterfeiting Act claim and certain of the predicate acts alleged under the civil RICO claim. The court denied the motion to dismiss the remaining claims, and denied the subsidiary’s motion to dismiss for lack of jurisdiction. On September 5, 2017, Synopsys filed a Second Amended Complaint.  On September 19, 2017, the defendants answered, and Ubiquiti Networks International Limited (“UNIL”) filed counterclaims for (1) declaratory judgment under 17 U.S.C. § 1201, (2) violation of 18 U.S.C. § 1030, the Computer Fraud and Abuse Act, (3) violation of California Penal Code § 502, the Computer Data Access Fraud Act, (4) trespass to personal property and chattels, (5) conversion, (6) civil RICO pursuant to 18 U.S.C. § 1962(c), (7) RICO conspiracy pursuant to 18 U.S.C. § 1962(d), and (8) common law fraud. Ubiquiti also moved for leave to amend its existing counterclaims against Synopsys, for breach of contract and declaratory judgment under 17 U.S.C. § 1201, to include the counterclaims filed by UNIL.  On October 3, 2017, Synopsys filed its opposition to the Company’s motion for leave to amend its counterclaims, as well as a motion to dismiss UNIL’s counterclaims and an anti-SLAPP motion to strike state law claims by both the Company and UNIL. The Company plans to vigorously defend itself against these claims; however, there can be no assurance that the Company will prevail in the lawsuit. The Company cannot currently estimate the possible loss or range of losses, if any, that it may experience in connection with this litigation.

- added (2017-11-09):
[0001511737-17-000011:note_history:8]
Vivato/XR

- added (2017-11-09):
[0001511737-17-000011:note_history:9]
On April 19, 2017, XR Communications, LLC, d/b/a Vivato Technologies (“Vivato”), filed a complaint against the Company in the United States District Court for the Central District of California, alleging that at least one of the Company’s products infringes United States Patent Numbers 7,062,296 (the “’296 Patent”), 7,729,728 (the “’728 Patent”), and 6,611,231 (the “’231 Patent and, collectively, the “Patents-in-Suit”). The ‘296 and ‘728 Patents are entitled “Forced Beam Switching in Wireless Communication Systems Having Smart Antennas.” The ‘231 Patent is entitled “Wireless Packet Switched Communications Systems and Networks Using Adaptively Steered Antenna Arrays.” Vivato amended its complaint on June 23, 2017 and again on July 6, 2017. According to the complaint, the products accused of infringing the Patents-in-Suit include Wi-Fi access points and routers supporting MU-MIMO, including without limitation access points and routers utilizing the IEEE 802.11ac-2013 standard. Vivato has also recently filed nine other lawsuits asserting the same patents against other defendants in the Central District of California.

- added (2017-11-09):
[0001511737-17-000011:note_history:10]
The Company plans to vigorously defend itself against these claims; however, there can be no assurance that the Company will prevail in the lawsuit. The Company cannot currently estimate the possible loss or range of losses, if any, that it may experience in connection with this litigation.

- added (2017-11-09):
[0001511737-17-000011:note_history:11]
Gericke Shareholder Action

- added (2017-11-09):
[0001511737-17-000011:note_history:12]
On September 25, 2017, a purported class action, captioned Richard Gericke v. Ubiquiti Networks, Inc. et al., No. 17-cv-7279 (the "Gericke Action"), was filed in the United States District Court for the Southern District of New York against the Company and certain of its current and former officers and directors.  The Gericke Action complaint alleges that the defendants made misrepresentations in violation of Sections 10(b) and 20(a) of the Securities Exchange Act of 1934 and Rule 10b-5 promulgated thereunder by making false and/or misleading statements and failing to disclose material adverse facts about the Company's business, operations, and prospects.  A court conference has been scheduled for January 10, 2018 to address any motions to consolidate the Gericke Action and the Klein Action (as discussed further in Note 14) and to appoint lead plaintiff and lead counsel.

- added (2017-11-09):
[0001511737-17-000011:note_history:13]
The Company has retained counsel and plans to vigorously defend itself against these claims.  However, there can be no assurance that the Company will prevail in the lawsuit.  The Company cannot currently estimate the possible loss or range of losses, if any, that it may experience in connection with this litigation.

- removed (2017-11-09):
[0001628280-17-004928:note_history:14]
The Company primarily subcontracts with other companies to manufacture its products. During the normal course of business, the Company’s contract manufacturers procure components based upon orders placed by the Company. If the Company cancels all or part of the orders, it may still be liable to the contract manufacturers for the cost of the components purchased by them to manufacture the Company’s products. The Company periodically reviews the potential liability under its orders, and no significant accruals have been recorded as of March 31, 2017.  The Company had inventory purchase obligations of $40.7 million as of March 31, 2017.

- removed (2017-11-09):
[0001628280-17-004928:note_history:15]
Beginning on September 7, 2012, two class action lawsuits were filed in the United States District Court for the Northern District of California against Ubiquiti Networks, Inc., certain of our current and former officers and directors, and the underwriters of its initial public offering, alleging claims under U.S. securities laws. On January 30, 2013, the plaintiffs filed an amended consolidated complaint. On March 26, 2014, the court issued an order granting a motion to dismiss the complaint with leave to amend. Following the plaintiffs’ decision not to file an amended complaint, on April 16, 2014, the court ordered the dismissal of the lawsuit with prejudice, and entered judgment in favor of the Company and the other defendants, and against the plaintiffs. On May 15, 2014, the plaintiffs filed a notice of appeal from the judgment of the court. The Ninth Circuit heard oral arguments on August 10, 2016.  On October 24, 2016, the Ninth Circuit issued an unpublished opinion, reaffirming the district court’s dismissal of the alleged violation of Sections 10(b) and 20(a) of the Securities Exchange Act of 1934 and reversing the district court’s dismissal of the alleged violations of Sections 11 and 15 of the Securities Act of 1933. The Company filed a petition for rehearing with the Ninth Circuit, which the Ninth Circuit denied. The Company plans to vigorously defend itself against these claims; however, there can be no assurance that the Company will prevail in the lawsuit. The Company cannot currently estimate the possible loss, if any, that it may experience in connection with this litigation.

- removed (2017-11-09):
[0001628280-17-004928:note_history:16]
On February 3, 2017, Synopsys, Inc. (“Synopsys”) filed a complaint against the Company, one of our subsidiaries and certain employees in the United States District Court for the Northern District of California, alleging claims under the Digital Millennium Copyright Act (“DMCA”). On March 28, 2017, Synopsys filed an amended complaint alleging claims under the trafficking provisions of the DMCA and claims for fraud, civil RICO and negligent misrepresentation. The Company plans to vigorously defend itself against these claims; however, there can be no assurance that the Company will prevail in the lawsuit. The Company cannot currently estimate the possible loss or range of losses, if any, that it may experience in connection with this litigation.


## us-gaap:BusinessDescriptionAndBasisOfPresentationTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2017-11-09):
[0001511737-17-000011:note_history:17]
Business— Ubiquiti Networks, Inc. and its wholly owned subsidiaries (collectively, “Ubiquiti” or the “Company”) develop high performance networking technology for service providers, enterprises, and consumers globally.
  (was, 2017-05-04, similarity 0.9037):
[0001628280-17-004928:note_history:17]
Ubiquiti Networks, Inc. and its wholly owned subsidiaries (collectively, “Ubiquiti” or the “Company”) develop high performance networking technology for service providers and enterprises.

- changed (2017-11-09):
[0001511737-17-000011:note_history:18]
The Company operates on a fiscal year ending June 30. In this Quarterly Report, the fiscal year ending June 30, 2018 is referred to as “fiscal 2018” and the fiscal year ended June 30, 2017 is referred to as “fiscal 2017”.
  (was, 2017-05-04, similarity 0.9975):
[0001628280-17-004928:note_history:18]
The Company operates on a fiscal year ending June 30. In this Quarterly Report, the fiscal year ending June 30, 2017 is referred to as “fiscal 2017” and the fiscal year ended June 30, 2016 is referred to as “fiscal 2016.”

- changed (2017-11-09):
[0001511737-17-000011:note_history:19]
Basis of Presentation— The Company's consolidated financial statements and accompanying notes have been prepared in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP”) related to interim financial statements based on applicable Securities and Exchange Commission (“SEC”) rules and regulations. Accordingly, they do not include all the information and footnotes required by U.S. GAAP for complete financial statements. These consolidated financial statements reflect all adjustments, which are, in the opinion of the Company, of a normal and recurring nature and those necessary to state fairly the statements of financial position, results of operations and cash flows for the dates and periods presented. The June 30, 2017 balance sheet was derived from the audited financial statements as of that date. All significant intercompany transactions and balances have been eliminated.
  (was, 2017-05-04, similarity 0.8917):
[0001628280-17-004928:note_history:19]
Basis of Presentation— The accompanying consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP”) related to interim financial statements based on applicable Securities and Exchange Commission (“SEC”) rules and regulations. Accordingly, they do not include all the information and footnotes required by U.S. GAAP for complete financial statements. These consolidated financial statements reflect all adjustments, which are, in the opinion of the Company, of a normal and recurring nature and those necessary to state fairly the statements of financial position, results of operations and cash flows for the dates and periods presented. The June 30, 2016 balance sheet was derived from the audited financial statements as of that date. All significant intercompany transactions and balances have been eliminated.  The Company has reclassified certain amounts reported in the previous period to conform to the current period presentation.

- changed (2017-11-09):
[0001511737-17-000011:note_history:20]
These consolidated financial statements should be read in conjunction with the Company’s audited consolidated financial statements for the fiscal year ended June 30, 2017, included in its Annual Report on Form 10-K, as filed with the SEC on August 25, 2017 (the “Annual Report”). The results of operations for the three months ended September 30, 2017 are not necessarily indicative of the results to be expected for any future periods.
  (was, 2017-05-04, similarity 0.7758):
[0001628280-17-004928:note_history:20]
These consolidated financial statements should be read in conjunction with the Company’s audited consolidated financial statements for the fiscal year ended June 30, 2016, included in its Annual Report on Form 10-K, as filed with the SEC on August 22, 2016 (the “Annual Report”). The results of operations for the three and nine months ended March 31, 2017 are not necessarily indicative of the results to be expected for any future periods.

- removed (2017-11-09):
[0001628280-17-004928:note_history:21]
Business— Ubiquiti Networks, Inc. was incorporated in the State of California in 2003 as Pera Networks, Inc.  In 2005, Pera Networks, Inc. changed its name to Ubiquiti Networks, Inc. and commenced its current operations. In June 2010, Ubiquiti Networks, Inc. was re-incorporated in Delaware.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2017-11-09):
[0001511737-17-000011:note_history:22]
In May 2014, the FASB issued ASU 2014-09, Revenue from Contracts with Customers, with amendments in 2015 and 2016, which creates new ASC Topic 606 ("Topic 606") that will replace most existing revenue recognition guidance in GAAP when it becomes effective. Topic 606 requires an entity to recognize the amount of revenue to which it expects to be entitled for the transfer of promised goods or services to customers. The new standard will be effective for the Company’s first quarter of fiscal year 2019. Topic 606 may be applied retrospectively to each prior period presented or with the cumulative effect recognized as of the date of initial application. The Company is still evaluating the impact of adopting Topic 606 on its consolidated financial statements and related financial statement disclosures, and it has not yet selected a transition method for its adoption of this standard in fiscal 2019.
  (was, 2017-05-04, similarity 0.8351):
[0001628280-17-004928:note_history:22]
In May 2014, the FASB issued ASU 2014-09, Revenue from Contracts with Customers, with amendments in 2015 and 2016, which creates new ASC Topic 606 (Topic 606) that will replace most existing revenue recognition guidance in GAAP when it becomes effective. Topic 606 requires an entity to recognize the amount of revenue to which it expects to be entitled for the transfer of promised goods or services to customers. The new standard will be effective for the Company’s first quarter of fiscal year 2019 and early application for the Company's first quarter of fiscal year 2018 is permitted. Topic 606 may be applied retrospectively to each prior period presented or with the cumulative effect recognized as of the date of initial application. The Company is still evaluating the impact of adopting Topic 606 on its consolidated financial statements and related financial statement disclosures and has not yet selected a transition method or determined if it will adopt this standard in fiscal 2018 or 2019.

- removed (2017-11-09):
[0001628280-17-004928:note_history:23]
New Accounting Updates Recently Adopted

- removed (2017-11-09):
[0001628280-17-004928:note_history:24]
Effective July 1, 2016, the Company adopted Accounting Standards Update (“ASU”) 2015-03 regarding simplifying the presentation of debt issuance costs. The guidance requires that debt issuance costs related to a recognized debt liability be presented in the balance sheet as a direct deduction from the carrying amount of that debt liability, consistent with debt discounts. Previously the Company reported these costs as assets on its balance sheet. The guidance is applied on a retrospective basis whereby prior-period financial statements must be adjusted to reflect the adoption of the new guidance.

- removed (2017-11-09):
[0001628280-17-004928:note_history:25]
The Company has reclassified $0.3 million from "prepaid expenses and other current assets" to "Debt - short-term", and $0.7 million from "Other long-term assets" to "Debt - long-term" on the June 30, 2016 consolidated balance sheet.

- removed (2017-11-09):
[0001628280-17-004928:note_history:26]
Effective July 1, 2016, the Company adopted ASU 2015-11 regarding simplifying the measurement of inventory. The guidance requires an entity to measure inventory at the lower of cost and net realizable value. Net realizable value is the estimated selling prices in the ordinary course of business, less reasonably predictable costs of completion, disposal, and transportation. The Company adopted this update prospectively, and it did not have a material impact on the Company's consolidated financial statements.

- removed (2017-11-09):
[0001628280-17-004928:note_history:27]
Effective July 1, 2016, the Company early adopted ASU 2016-09,"Compensation-Stock Compensation (Topic 718), Improvements to Employee Share-Based Payment Accounting," regarding the Improvements to Employee Share-Based Payment Accounting. The Company applied the guidance relating to accounting for excess tax benefits and the presentation of excess tax benefits in the consolidated statement of cash flows on a prospective basis; accordingly, prior period amounts have not been adjusted. During the three and nine months ended March 31, 2017, the Company recognized the excess tax benefits of $0.2 million and $7.9 million, respectively, within the provision for income taxes rather than additional paid-in capital. The Company classified the excess tax benefits within cash flows from operating activities for the nine months ended March 31, 2017 rather than within cash flows from financing activities. In regards to the forfeiture policy election, we will continue to estimate the number of awards expected to be forfeited, rather than electing to account for forfeitures as they occur. No other terms of the adopted guidance resulted in an impact on the Company's consolidated financial statements.

- removed (2017-11-09):
[0001628280-17-004928:note_history:28]
In June 2016, the FASB issued ASU 2016-13, “Financial Instruments – Credit Losses (Topic 326): Measurement of Credit Losses On Financial Instruments,” (“ASU 2016-13”). ASU 2016-13 implements a comprehensive change in estimating the allowances for loan losses from the current model of losses inherent in the loan portfolio to a current expected credit loss model that generally is expected to result in earlier recognition of allowances for losses. Additionally, purchase accounting rules have been modified as well as credit losses on held-to-maturity debt securities. ASU 2016-13 is effective for fiscal years beginning after December 15, 2019, and early adoption is permitted for annual and interim periods beginning after December 15, 2018. The Company is evaluating the impact that adoption of this new standard will have on its consolidated financial statements.

- removed (2017-11-09):
[0001628280-17-004928:note_history:29]
In October 2016, the FASB issued ASU 2016-16, "Income Taxes (Topic 740): Accounting for Income Taxes: Intra-Entity Asset Transfers of Assets Other Than Inventory," (“ASU 2016-16”). ASU 2016-16 eliminates the exception for all intra-entity sales of assets other than inventory. As a result, a reporting entity would recognize the tax expense from the sale of the asset in the seller’s tax jurisdiction when the transfer occurs, even though the pre-tax effects of that transaction are eliminated in consolidation. Any deferred tax asset that arises in the buyer’s jurisdiction would also be recognized at the time of the transfer. ASU 2016-16 is effective for fiscal years beginning after December 15, 2017, and early adoption is permitted but can only be adopted in the first interim period of a fiscal year. The Company is evaluating the impact that adoption of this new standard will have on its consolidated financial statements.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2017-11-09):
[0001511737-17-000011:note_history:30]
On March 3, 2015, Ubiquiti Networks, Inc. and Ubiquiti International Holding Company Limited (the “Cayman Borrower”) amended and restated its 2014 Credit Agreement (as defined below) with Wells Fargo Bank, National Association ("Wells Fargo"), the other financial institutions named as lenders therein, and Wells Fargo as administrative agent for the lenders (the "Credit Agreement").  The Credit Agreement replaced the Company's $150.0 million senior secured revolving credit facility under its prior credit agreement dated May 5, 2014 (the "2014 Credit Agreement").

- added (2017-11-09):
[0001511737-17-000011:note_history:31]
On April 14, 2017, the Company, the Cayman Borrower and certain of its subsidiaries entered in the First Amendment (the “First Amendment”) to the Credit Agreement (as amended by the First Amendment, the “Amended Credit Agreement”). The First Amendment increased the maximum aggregate amount of the senior secured credit revolving facility from $200.0 million  to $300.0 million ("Revolving Facility"), but maintained the $100.0 million senior secured term facility ("Term Facility", together with the Revolving Facility, the "Facilities") under the Credit Agreement and the option to request increases in the amounts of such Facilities by up to an additional $50.0 million in the aggregate (any such increase to be in each lender’s sole discretion).

- added (2017-11-09):
[0001511737-17-000011:note_history:32]
The Amended Credit Agreement matures on March 3, 2020. The $100.0 million term loan facility of the Amended Credit Agreement was fully drawn at closing of the original Credit Agreement, and $72.3 million was used to repay the outstanding balance under its prior credit agreement. The Facilities are available for working capital and general corporate purposes that comply with the terms of the Amended Credit Agreement.

- added (2017-11-09):
[0001511737-17-000011:note_history:33]
On October 31, 2017, the Company, the Cayman Borrower and certain of its subsidiaries entered in the Second Amendment (the “Second Amendment”) to the Amended Credit Agreement as further described in Note 14.

- changed (2017-11-09):
[0001511737-17-000011:note_history:34]
|  | September 30, 2017 |  | June 30, 2017 |
| Term Loan - short term | $ | 15,000 |  |  | $ | 15,000 |  |
| Debt issuance costs, net | (257 | ) |  | (257 | ) |
| Total Debt - short term | 14,743 |  |  | 14,743 |  |
| Term Loan - long term | 57,500 |  |  | 61,250 |  |
| Revolver - long term | 226,000 |  |  | 181,000 |  |
| Debt issuance costs, net | (365 | ) |  | (429 | ) |
| Total Debt - long term | $ | 283,135 |  |  | $ | 241,821 |  |
  (was, 2017-05-04, similarity 0.9687):
[0001628280-17-004928:note_history:34]
|  | March 31, 2017 |  | June 30, 2016 |
| Term Loan - short term | $ | 15,000 |  |  | $ | 11,250 |  |
| Debt issuance costs, net (1) | (257 | ) |  | (257 | ) |
| Total Debt - short term | 14,743 |  |  | 10,993 |  |
| Term Loan - long term | 65,000 |  |  | 76,250 |  |
| Revolver - long term | 146,000 |  |  | 116,000 |  |
| Debt issuance costs, net (1) | (493 | ) |  | (686 | ) |
| Total Debt - long term | $ | 210,507 |  |  | $ | 191,564 |  |

- changed (2017-11-09):
[0001511737-17-000011:note_history:35]
As of September 30, 2017, the interest rate on the term loan was 2.83%. The table below shows the respective interest rates as of September 30, 2017 in addition to interest rate reset dates and rates as available for each revolver draw.
  (was, 2017-05-04, similarity 0.6468):
[0001628280-17-004928:note_history:35]
As of March 31, 2017, the interest rate on the term loan was 2.65%. The table below shows the respective interest rates as of March 31, 2017 in addition to interest rate reset dates and rates as available for each revolver draw.

- changed (2017-11-09):
[0001511737-17-000011:note_history:36]
|  |  | Interest Rate as of |  |  |  |  |
| Debt Payment Obligations |  | September 30, 2017 |  | Rate Reset Date |  | Reset Rate |
| $69 Million Revolver |  | 2.80% |  | 10/3/2017 |  | 2.77% |
| $18 Million Revolver |  | 2.80% |  | 10/18/2017 |  | 2.78% |
| $16 Million Revolver |  | 2.82% |  | 11/15/2017 |  | * |
| $48 Million Revolver |  | 2.82% |  | 11/30/2017 |  | * |
| $30 Million Revolver |  | 2.82% |  | 12/15/2017 |  | * |
| $45 Million Revolver |  | 2.82% |  | 12/22/2017 |  | * |
  (was, 2017-05-04, similarity 0.8632):
[0001628280-17-004928:note_history:36]
|  |  | Interest Rate as of |  |  |  |  |
| Debt Payment Obligations |  | March 31, 2017 |  | Rate Reset Date |  | Reset Rate |
| $15 Million Revolver |  | 2.51% |  | 4/10/2017 |  | # |
| $18 Million Revolver |  | 2.52% |  | 7/18/2017 |  | 2.66% |
| $16 Million Revolver |  | 2.53% |  | 5/15/2017 |  | * |
| $19 Million Revolver |  | 2.50% |  | 4/3/2017 |  | # |
| $48 Million Revolver |  | 2.55% |  | 5/30/2017 |  | * |
| $30 Million Revolver |  | 2.93% |  | 9/15/2017 |  | * |

- added (2017-11-09):
[0001511737-17-000011:note_history:37]
The Revolving Facility includes a sub-limit of $10.0 million for letters of credit and a sub-limit of $25.0 million for swingline loans.  The Facilities are available for working capital and general corporate purposes that comply with the terms of the Amended Credit Agreement. Under the Amended Credit Agreement, revolving loans and swingline loans may be borrowed, repaid and reborrowed until March 3, 2020, at which time all amounts borrowed must be repaid. The term loan is payable in quarterly installments of 3.75% of the original principal amount of the term loan, in each case plus accrued and unpaid interest. Revolving, swingline and term loans may be prepaid at any time without penalty.

- added (2017-11-09):
[0001511737-17-000011:note_history:38]
Revolving and term loans bear interest, at the Company’s option, at either (i) a floating rate per annum equal to the base rate plus a margin of between 0.50% and 1.25%, depending on the Company’s leverage ratio as of the most recently ended fiscal quarter or (ii) a floating per annum rate equal to the applicable LIBOR rate for a specified period, plus a margin of between 1.50% and 2.25%, depending on the Company’s leverage ratio as of the most recently ended fiscal quarter. Swingline loans bear interest at a floating rate per annum equal to the base rate plus a margin of between 0.50% and 1.25%, depending on the Company’s leverage ratio as of the most recently ended fiscal quarter. Base rate is defined as the greatest of (A) Wells Fargo's prime rate, (B) the federal funds rate plus 0.50% or (C) the applicable LIBOR rate for a period of one month plus 1.00%. A default interest rate shall apply on all obligations during certain events of default under the Amended Credit Agreement at a rate per annum equal to 2.00% above the applicable interest rate. The Company will pay to each lender a facility fee on a quarterly basis based on the unused amount of each lender's commitment to make revolving loans, of between 0.20% and 0.35%, depending on the Company's leverage ratio as of the most recently ended fiscal quarter. The Company will also pay to the applicable lenders on a quarterly basis certain fees based on the daily amount available to be drawn under each outstanding letter of credit, including aggregate letter of credit commissions of between 1.50% and 2.25%, depending on the Company's leverage ratio as of the most recently ended fiscal quarter, and issuance fees of 0.125% per annum. The Company is also obligated to pay Wells Fargo, as agent, fees customary for a credit facility of this size and type.

- added (2017-11-09):
[0001511737-17-000011:note_history:39]
The Amended Credit Agreement requires the Company to maintain during the term of the Facilities (i) a maximum leverage ratio of 2.50 to 1.00 and (ii) minimum liquidity of $250.0 million, which can be satisfied with unrestricted cash and cash equivalents and up to $50.0 million of availability under the Revolving Facility. All other material terms and provisions of the Amended Credit Agreement remain substantially identical to the terms and provisions in place immediately prior to the effectiveness of the First Amendment, other than the revision or inclusion of certain customary market provisions. In addition, the Amended Credit Agreement contains customary affirmative and negative covenants, including covenants that limit or restrict the ability of the Company and its subsidiaries to, among other things, grant liens or enter into agreements restricting their ability to grant liens on property, enter into mergers, dispose of assets, change their accounting or reporting policies,change their business and incur indebtedness, in each case subject to customary exceptions for a credit facility of this size and type. The Amended Credit Agreement includes customary events of default that include, among other things, non-payment of principal, interest or fees, inaccuracy of representations and warranties, violation of covenants, cross default to certain other indebtedness, bankruptcy and insolvency events, material judgments, change of control and certain ERISA events. The occurrence of an event of default could result in the acceleration of the obligations under the Amended Credit Agreement. The obligations of the Company and certain domestic subsidiaries, if any, under the Amended Credit Agreement are required to be guaranteed by such domestic subsidiaries (the "Domestic Guarantors") and are collateralized by substantially all assets (excluding intellectual property) of the Company and the Domestic Guarantors. The obligations of the Cayman Borrower and certain foreign subsidiaries under the Amended Credit Agreement are required to be guaranteed by certain domestic and material foreign subsidiaries (the "Guarantors") and are collateralized by substantially all assets (excluding intellectual property) of the Company and the Guarantors.

- added (2017-11-09):
[0001511737-17-000011:note_history:40]
During the three months ended September 30, 2017, the Company made a payment of $4.3 million against the balance under the Term Facility, of which $3.8 million was a repayment of principal and $0.5 million was payment of interest. During the three months ended September 30, 2017, the Company made a $1.3 million payment of interest under the Revolving Facility.

- changed (2017-11-09):
[0001511737-17-000011:note_history:41]
The following table summarizes our estimated debt and interest payment obligations as of September 30, 2017, for the remainder of fiscal 2018 and future fiscal years (in thousands):
  (was, 2017-05-04, similarity 0.9706):
[0001628280-17-004928:note_history:41]
The following table summarizes our estimated debt and interest payment obligations as of March 31, 2017, for the remainder of fiscal 2017 and future fiscal years (in thousands):

- changed (2017-11-09):
[0001511737-17-000011:note_history:42]
|  | 2018 (remainder) |  | 2019 |  | 2020 |  | 2021 |  | 2022 |  | Thereafter |  | Total |
| Debt payment obligations | $ | 11,250 |  |  | $ | 15,000 |  |  | $ | 272,250 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 298,500 |  |
| Interest and other payments on debt payment obligations (1) | 6,395 |  |  | 8,101 |  |  | 5,288 |  |  | — |  |  | — |  |  | — |  |  | 19,784 |  |
| Total | $ | 17,645 |  |  | $ | 23,101 |  |  | $ | 277,538 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 318,284 |  |
  (was, 2017-05-04, similarity 0.8895):
[0001628280-17-004928:note_history:42]
|  | 2017 (remainder) |  | 2018 |  | 2019 |  | 2020 |  | 2021 |  | Thereafter |  | Total |
| Debt payment obligations | $ | 3,750 |  |  | $ | 15,000 |  |  | $ | 15,000 |  |  | $ | 192,250 |  |  | $ | — |  |  | $ | — |  |  | $ | 226,000 |  |
| Interest and other payments on debt payment obligations (1) | 1,516 |  |  | 5,820 |  |  | 5,418 |  |  | 3,468 |  |  | — |  |  | — |  |  | 16,222 |  |
| Total | $ | 5,266 |  |  | $ | 20,820 |  |  | $ | 20,418 |  |  | $ | 195,718 |  |  | $ | — |  |  | $ | — |  |  | $ | 242,222 |  |

- changed (2017-11-09):
[0001511737-17-000011:note_history:43]
(1) - Interest payments are calculated based on the applicable rates and payment dates as of September 30, 2017. Furthermore, one to three-month payment intervals on the revolving debt have been assumed, consistent with the Company's elections to date.
  (was, 2017-05-04, similarity 0.959):
[0001628280-17-004928:note_history:43]
(1) - Interest payments are calculated based on the applicable rates and payment dates as of March 31, 2017. Furthermore, two to three-month payment intervals on the revolving debt have been assumed, consistent with the Company's elections to date.

- removed (2017-11-09):
[0001628280-17-004928:note_history:44]
On March 3, 2015, Ubiquiti Networks, Inc. and Ubiquiti International Holding Company Limited (the “Cayman Borrower”) amended and restated its prior credit agreement (the “Credit Agreement”) with Wells Fargo Bank, National Association (“Wells Fargo”), the other financial institutions named as lenders therein, and Wells Fargo as administrative agent for the lenders.  The Credit Agreement provides for a $200.0 million senior secured revolving credit facility ("Revolving Facility") and a $100.0 million senior secured term loan facility ("Term Facility", together with the Revolving Facility, the “Facilities”), with an option to request increases in the amounts of such Facilities by up to an additional $50.0 million in the aggregate (any such increase to be in each lender’s sole discretion). The Credit Agreement, matures on March 3, 2020. The Facilities replaced the Company’s $150.0 million senior secured revolving credit facility under its prior credit agreement. The $100.0 million term loan facility of the Credit Agreement was fully drawn at closing of the Credit Agreement, and $72.3 million was used to repay the outstanding balance under its prior credit agreement. The Facilities are available for working capital and general corporate purposes that comply with the terms of the Credit Agreement.

- removed (2017-11-09):
[0001628280-17-004928:note_history:45]
(1) On July 1 2016, the Company retrospectively adopted ASU 2015-03, which requires unamortized debt issuance costs to be included as a direct deduction from the related debt liability on the balance sheet. Under previous guidance, all unamortized debt issuance costs were reported as assets on the balance sheet. See Note 2 for information on the impact of the retrospective adoption of ASU 2015-03.

- removed (2017-11-09):
[0001628280-17-004928:note_history:46]
# - Revolver repaid subsequent to March 31, 2017

- removed (2017-11-09):
[0001628280-17-004928:note_history:47]
The Revolving Facility includes a sub-limit of $10.0 million for letters of credit and a sub-limit of $25.0 million for swingline loans. Under the Credit Agreement, revolving loans and swingline loans may be borrowed, repaid and reborrowed until March 3, 2020, at which time all amounts borrowed must be repaid. The term loan is payable in quarterly installments of 2.50% of the original principal amount of the term loan until March 31, 2017, thereafter increasing to 3.75% of the original principal amount of the term loan, in each case plus accrued and unpaid interest. Revolving, swingline and term loans may be prepaid at any time without penalty.

- removed (2017-11-09):
[0001628280-17-004928:note_history:48]
Revolving and term loans bear interest, at the Company’s option, at either (i) a floating rate per annum equal to the base rate plus a margin of between 0.50% and 1.25%, depending on the Company’s leverage ratio as of the most recently ended fiscal quarter or (ii) a floating per annum rate equal to the applicable LIBOR rate for a specified period, plus a margin of between 1.50% and 2.25%, depending on the Company’s leverage ratio as of the most recently ended fiscal quarter. Swingline loans bear interest at a floating rate per annum equal to the base rate plus a margin of between 0.50% and 1.25%, depending on the Company’s leverage ratio as of the most recently ended fiscal quarter.

- removed (2017-11-09):
[0001628280-17-004928:note_history:49]
The Credit Agreement requires the Company to maintain during the term of the Facilities (i) a maximum leverage ratio of 2.50 to 1.00 and (ii) minimum liquidity of $225.0 million, increasing to $250.0 million in the event of an incremental increase in the size of the Facilities, which can be satisfied with unrestricted cash and cash equivalents and up to $50.0 million of availability under the Revolving Facility. In addition, the Credit Agreement contains customary affirmative and negative covenants and includes customary events of default. The occurrence of an event of default could result in the acceleration of the obligations under the Credit Agreement.

- removed (2017-11-09):
[0001628280-17-004928:note_history:50]
The obligations of Ubiquiti Networks, Inc. and certain domestic subsidiaries, if any, under the Credit Agreement are required to be guaranteed by such domestic subsidiaries (the “Domestic Guarantors”) and are collateralized by substantially all assets (excluding intellectual property) of Ubiquiti Networks, Inc. and the Domestic Guarantors. The obligations of the Cayman Borrower and certain foreign subsidiaries under the Credit Agreement are required to be guaranteed by certain domestic and material foreign subsidiaries (the “Guarantors”) and are collateralized by substantially all assets (excluding intellectual property) of the Cayman Borrower and the Guarantors.

- removed (2017-11-09):
[0001628280-17-004928:note_history:51]
During the three months ended March 31, 2017, the Company made a payment of $3.0 million against the balance under the Term Facility, of which $2.5 million was a repayment of principal and $0.5 million was payment of interest. During the nine months ended March 31, 2017, the Company made aggregate payments of $9.0 million against the balance under the Term Facility, of which $7.5 million was a repayment of principal and $1.5 million was payment of interest.

- removed (2017-11-09):
[0001628280-17-004928:note_history:52]
During the three months ended March 31, 2017, the Company made a payment of $0.7 million of interest under the Revolving Facility. During the nine months ended March 31, 2017, the Company made aggregate payments of $2.2 million of interest under the Revolving Facility.

- removed (2017-11-09):
[0001628280-17-004928:note_history:53]
On September 2, 2015, the Company accessed a letter of credit under its Revolving Facility in the amount of $0.2 million for the benefit of the landlord pursuant to a new lease of office space. The landlord can draw against the letter of credit in the event of a lease default by the Company. The letter of credit expires on September 2, 2017, subject to automatic renewal for additional one-year periods.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-11-09):
[0001511737-17-000011:note_history:54]
The table below shows the respective interest rates as of September 30, 2017 in addition to interest rate reset dates and rates as available for each revolver draw.
  (was, 2017-05-04, similarity 0.9682):
[0001628280-17-004928:note_history:54]
The table below shows the respective interest rates as of March 31, 2017 in addition to interest rate reset dates and rates as available for each revolver draw.

- changed (2017-11-09):
[0001511737-17-000011:note_history:55]
|  |  | Interest Rate as of |  |  |  |  |
| Debt Payment Obligations |  | September 30, 2017 |  | Rate Reset Date |  | Reset Rate |
| $69 Million Revolver |  | 2.80% |  | 10/3/2017 |  | 2.77% |
| $18 Million Revolver |  | 2.80% |  | 10/18/2017 |  | 2.78% |
| $16 Million Revolver |  | 2.82% |  | 11/15/2017 |  | * |
| $48 Million Revolver |  | 2.82% |  | 11/30/2017 |  | * |
| $30 Million Revolver |  | 2.82% |  | 12/15/2017 |  | * |
| $45 Million Revolver |  | 2.82% |  | 12/22/2017 |  | * |
  (was, 2017-05-04, similarity 0.8632):
[0001628280-17-004928:note_history:55]
|  |  | Interest Rate as of |  |  |  |  |
| Debt Payment Obligations |  | March 31, 2017 |  | Rate Reset Date |  | Reset Rate |
| $15 Million Revolver |  | 2.51% |  | 4/10/2017 |  | # |
| $18 Million Revolver |  | 2.52% |  | 7/18/2017 |  | 2.66% |
| $16 Million Revolver |  | 2.53% |  | 5/15/2017 |  | * |
| $19 Million Revolver |  | 2.50% |  | 4/3/2017 |  | # |
| $48 Million Revolver |  | 2.55% |  | 5/30/2017 |  | * |
| $30 Million Revolver |  | 2.93% |  | 9/15/2017 |  | * |

- removed (2017-11-09):
[0001628280-17-004928:note_history:56]
# - Revolver repaid subsequent to March 31, 2017


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-11-09):
[0001511737-17-000011:note_history:57]
|  | September 30, 2017 |  | June 30, 2017 |
| Term Loan - short term | $ | 15,000 |  |  | $ | 15,000 |  |
| Debt issuance costs, net | (257 | ) |  | (257 | ) |
| Total Debt - short term | 14,743 |  |  | 14,743 |  |
| Term Loan - long term | 57,500 |  |  | 61,250 |  |
| Revolver - long term | 226,000 |  |  | 181,000 |  |
| Debt issuance costs, net | (365 | ) |  | (429 | ) |
| Total Debt - long term | $ | 283,135 |  |  | $ | 241,821 |  |
  (was, 2017-05-04, similarity 0.9687):
[0001628280-17-004928:note_history:57]
|  | March 31, 2017 |  | June 30, 2016 |
| Term Loan - short term | $ | 15,000 |  |  | $ | 11,250 |  |
| Debt issuance costs, net (1) | (257 | ) |  | (257 | ) |
| Total Debt - short term | 14,743 |  |  | 10,993 |  |
| Term Loan - long term | 65,000 |  |  | 76,250 |  |
| Revolver - long term | 146,000 |  |  | 116,000 |  |
| Debt issuance costs, net (1) | (493 | ) |  | (686 | ) |
| Total Debt - long term | $ | 210,507 |  |  | $ | 191,564 |  |

- changed (2017-11-09):
[0001511737-17-000011:note_history:58]
The following table summarizes our estimated debt and interest payment obligations as of September 30, 2017, for the remainder of fiscal 2018 and future fiscal years (in thousands):
  (was, 2017-05-04, similarity 0.9706):
[0001628280-17-004928:note_history:58]
The following table summarizes our estimated debt and interest payment obligations as of March 31, 2017, for the remainder of fiscal 2017 and future fiscal years (in thousands):

- changed (2017-11-09):
[0001511737-17-000011:note_history:59]
|  | 2018 (remainder) |  | 2019 |  | 2020 |  | 2021 |  | 2022 |  | Thereafter |  | Total |
| Debt payment obligations | $ | 11,250 |  |  | $ | 15,000 |  |  | $ | 272,250 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 298,500 |  |
| Interest and other payments on debt payment obligations (1) | 6,395 |  |  | 8,101 |  |  | 5,288 |  |  | — |  |  | — |  |  | — |  |  | 19,784 |  |
| Total | $ | 17,645 |  |  | $ | 23,101 |  |  | $ | 277,538 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 318,284 |  |
  (was, 2017-05-04, similarity 0.8895):
[0001628280-17-004928:note_history:59]
|  | 2017 (remainder) |  | 2018 |  | 2019 |  | 2020 |  | 2021 |  | Thereafter |  | Total |
| Debt payment obligations | $ | 3,750 |  |  | $ | 15,000 |  |  | $ | 15,000 |  |  | $ | 192,250 |  |  | $ | — |  |  | $ | — |  |  | $ | 226,000 |  |
| Interest and other payments on debt payment obligations (1) | 1,516 |  |  | 5,820 |  |  | 5,418 |  |  | 3,468 |  |  | — |  |  | — |  |  | 16,222 |  |
| Total | $ | 5,266 |  |  | $ | 20,820 |  |  | $ | 20,418 |  |  | $ | 195,718 |  |  | $ | — |  |  | $ | — |  |  | $ | 242,222 |  |

- changed (2017-11-09):
[0001511737-17-000011:note_history:60]
(1) - Interest payments are calculated based on the applicable rates and payment dates as of September 30, 2017. Furthermore, one to three-month payment intervals on the revolving debt have been assumed, consistent with the Company's elections to date.
  (was, 2017-05-04, similarity 0.959):
[0001628280-17-004928:note_history:60]
(1) - Interest payments are calculated based on the applicable rates and payment dates as of March 31, 2017. Furthermore, two to three-month payment intervals on the revolving debt have been assumed, consistent with the Company's elections to date.

- removed (2017-11-09):
[0001628280-17-004928:note_history:61]
(1) On July 1 2016, the Company retrospectively adopted ASU 2015-03, which requires unamortized debt issuance costs to be included as a direct deduction from the related debt liability on the balance sheet. Under previous guidance, all unamortized debt issuance costs were reported as assets on the balance sheet. See Note 2 for information on the impact of the retrospective adoption of ASU 2015-03.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2017-11-09):
[0001511737-17-000011:note_history:62]
On November 13, 2013, the Company entered into an aircraft lease agreement (the “Aircraft Lease Agreement”) with RJP Manageco LLC (the “Lessor”), a limited liability company owned by the Company’s CEO, Robert J. Pera. Pursuant to the Aircraft Lease Agreement, the Company may lease an aircraft owned by the Lessor for Company business purposes. Under the Aircraft Lease Agreement, the aircraft may be leased at a rate of $5,000 per flight hour. This hourly rate does not include the cost of flight crew or on-board services, which the Company purchases from a third-party provider. The Company recognized a total of approximately $0.4 million and $0.7 million in expenses pursuant to the Aircraft Lease Agreement during the three months ended September 30, 2017 and 2016, respectively. All expenses pursuant to the Aircraft Lease Agreement have been included in the Company’s sales, general and administrative expenses in the Consolidated Statements of Operations and Comprehensive Income.
  (was, 2017-05-04, similarity 0.6899):
[0001628280-17-004928:note_history:62]
On November 13, 2013, the Company entered into an aircraft lease agreement (the “Aircraft Lease Agreement”) with RJP Manageco LLC (the “Lessor”), a limited liability company owned by the Company’s CEO, Robert J. Pera. Pursuant to the Aircraft Lease Agreement, the Company may lease an aircraft owned by the Lessor for Company business purposes. Under the Aircraft Lease Agreement, the aircraft may be leased at a rate of $5,000 per flight hour. This hourly rate does not include the cost of flight crew or on-board services, which the Company purchases from a third-party provider. The Company recognized a total of approximately $0.5 million and $1.7 million in expenses pursuant to the Aircraft Lease Agreement during the three and nine months ended March 31, 2017, respectively.  The Company recognized a total of approximately $0.4 million and $1.0 million in expenses pursuant to the Aircraft Lease Agreement during the three and nine months ended March 31, 2016, respectively. All expenses pursuant to the Aircraft Lease Agreement have been included in the Company’s sales, general and administrative expenses in the Consolidated Statements of Operations.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- added (2017-11-09):
[0001511737-17-000011:note_history:63]
Second Amendment to Credit Agreement

- added (2017-11-09):
[0001511737-17-000011:note_history:64]
On October 31, 2017, the Company, the Cayman Borrower and certain of its subsidiaries entered in the Second Amendment (the “Second Amendment”) to the Amended Credit Agreement. The Second Amendment increased the maximum aggregate amount of the Revolving Facility from $300.0 million to $425.0 million, but maintained the $100.0 million Term Facility under the Amended Credit Agreement and the option to request increases in the amounts of such Facilities by up to an additional $50.0 million in the aggregate (any such increase to be in each lender’s sole discretion). All other material terms and provisions of the Amended Credit Agreement remain substantially identical to the terms and provisions in place immediately prior to the effectiveness of the Second Amendment, other than the revision or inclusion of certain customary market provisions.

- added (2017-11-09):
[0001511737-17-000011:note_history:65]
Repurchase Program

- added (2017-11-09):
[0001511737-17-000011:note_history:66]
During the second quarter of fiscal 2018, the Company repurchased and retired 602,192 shares of its common stock at an average price per share of $57.28 for an aggregate amount of $34.5 million. As of October 6, 2017, there is no remaining balance available for share repurchases under the share repurchase programs approved by the Board of Directors in the first quarter of fiscal 2018. On November 8, 2017, the Board of Directors of the Company approved a $50 million stock repurchase program (the "New Program"). Under the New Program, the Company was authorized to repurchase up to $50 million of its common stock. The New Program expires on December 31, 2018.

- added (2017-11-09):
[0001511737-17-000011:note_history:67]
Klein Shareholder Action

- added (2017-11-09):
[0001511737-17-000011:note_history:68]
On October 2, 2017, a purported class action, captioned Gabby Klein v. Ubiquiti Networks, Inc. et al., No. 17-cv-7524 (the "Klein Action"), was filed in the Southern District of New York that contains substantially similar claims and causes of action as the Gericke Action.  A court conference has been scheduled for January 10, 2018 to address any motions to consolidate the Gericke Action (as discussed further in Note 8) and the Klein Action and to appoint lead plaintiff and lead counsel.

- added (2017-11-09):
[0001511737-17-000011:note_history:69]
The Company has retained counsel and plans to vigorously defend itself against these claims.  However, there can be no assurance that the Company will prevail in the lawsuit.  The Company cannot currently estimate the possible loss or range of losses, if any, that it may experience in connection with this litigation.

- removed (2017-11-09):
[0001628280-17-004928:note_history:70]
On April 14, 2017, the Company, the Cayman Borrower and certain of its subsidiaries entered in the First Amendment (the “First Amendment”) to the Credit Agreement (as amended by the First Amendment, the “Amended Credit Agreement”). The First Amendment increased the maximum aggregate amount of the Revolving Facility from $200.0 million to $300.0 million, but maintained the $100.0 million Term Facility under the Credit Agreement and the option to request increases in the amounts of such Facilities by up to an additional $50.0 million in the aggregate (any such increase to be in each lender’s sole discretion). The Amended Credit Agreement requires the Company to maintain during the term of the Facilities (i) a maximum leverage ratio of 2.50 to 1.00 and (ii) minimum liquidity of $250.0 million, which can be satisfied with unrestricted cash and cash equivalents and up to $50.0 million of availability under the Revolving Facility. All other material terms and provisions of the Amended Credit Agreement remain substantially identical to the terms and provisions in place immediately prior to the effectiveness of the First Amendment, other than the revision or inclusion of certain customary market provisions.

- removed (2017-11-09):
[0001628280-17-004928:note_history:71]
Pursuant to the $50 million stock repurchase program approved by the Board of Directors of the Company on March 3, 2017, the Company repurchased $3.0 million of its common stock in the fourth quarter of fiscal 2017 that were trades executed on or prior to March 31, 2017. Please see Note 9 of the notes to the consolidated financial statements and Part II “Other Information” - Item 2 “Unregistered Sales of Equity Securities and Use of Proceeds” for more information.
