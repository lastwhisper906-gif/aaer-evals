# UI notes — 0001511737-15-000022


## ubnt:ScheduleOfRevenueAndAccountsReceivableByMajorCustomersByReportingSegmentsTableTableTextBlock

[0001511737-15-000022:notes:1]
Customers with an accounts receivable balance of 10% or greater of total accounts receivable and customers with net revenues of 10% or greater of total revenues are presented below for the periods indicated:

[0001511737-15-000022:notes:2]
|  | Percentage of Revenues |  | Percentage of Accounts Receivable |
|  | Years Ended June 30, |  | June 30, |
|  | 2015 |  | 2014 |  | 2013 |  | 2015 |  | 2014 |
| Flytec Computers, Inc. | * |  | 13 | % |  | 13 | % |  | * |  |  | 13 | % |
| Streakwave Wireless, Inc. | * |  | * |  |  | * |  |  | 13 | % |  | 12 | % |
| P.W. Batna Magdalena Mucha | * |  | * |  |  | * |  |  | 12 | % |  | 12 | % |

[0001511737-15-000022:notes:3]
*  denotes less than 10%


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0001511737-15-000022:notes:4]
SUPPLEMENTARY DATA (UNAUDITED)

[0001511737-15-000022:notes:5]
The following table presents the Company’s unaudited consolidated statements of operations data for each of the eight quarters during fiscal 2015 and 2014. In management’s opinion, this information has been presented on the same basis as the audited consolidated financial statements included in a separate section of this report, and all necessary adjustments, consisting only of normal recurring adjustments, have been included in the amounts below to state fairly the unaudited quarterly results when read in conjunction with the audited consolidated financial statements and related notes. The operating results for any quarter should not be relied upon as necessarily indicative of results for any future period.

[0001511737-15-000022:notes:6]
|  |  | Fiscal 2015 |
| In thousands, except per share data |  | FirstQuarter |  | SecondQuarter |  | ThirdQuarter |  | FourthQuarter |
| Net revenue |  | $ | 150,087 |  |  | $ | 153,137 |  |  | $ | 147,456 |  |  | $ | 145,267 |  |
| Gross profit |  | 61,051 |  |  | 69,021 |  |  | 65,977 |  |  | 66,138 |  |
| Income from operations(1) |  | 43,634 |  |  | 50,723 |  |  | 45,231 |  |  | 7,290 |  |
| Net income and comprehensive income |  | 37,743 |  |  | 46,265 |  |  | 41,137 |  |  | 4,518 |  |
| Net income per share of common stock: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.43 |  |  | $ | 0.52 |  |  | $ | 0.47 |  |  | $ | 0.05 |  |
| Diluted |  | $ | 0.42 |  |  | $ | 0.52 |  |  | $ | 0.46 |  |  | $ | 0.05 |  |
|  |  | Fiscal 2014 |
|  |  | FirstQuarter |  | SecondQuarter |  | ThirdQuarter |  | FourthQuarter |
| Net revenue |  | $ | 129,687 |  |  | $ | 138,439 |  |  | $ | 148,331 |  |  | $ | 156,007 |  |
| Gross profit |  | 58,023 |  |  | 60,971 |  |  | 65,612 |  |  | 68,861 |  |
| Income from operations |  | 45,896 |  |  | 47,120 |  |  | 50,135 |  |  | 52,794 |  |
| Net income and comprehensive income |  | 40,528 |  |  | 41,792 |  |  | 45,199 |  |  | 49,418 |  |
| Net income per share of common stock: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.46 |  |  | $ | 0.48 |  |  | $ | 0.51 |  |  | $ | 0.56 |  |
| Diluted |  | $ | 0.45 |  |  | $ | 0.47 |  |  | $ | 0.50 |  |  | $ | 0.55 |  |

[0001511737-15-000022:notes:7]
(1) During the fourth quarter of fiscal 2015, the Company experienced a BEC fraud loss.  For further details, see Note 14.


## us-gaap:BusinessDescriptionAndBasisOfPresentationTextBlock

[0001511737-15-000022:notes:8]
BUSINESS AND BASIS OF PRESENTATION

[0001511737-15-000022:notes:9]
Business— Ubiquiti Networks, Inc. was incorporated in the State of California in 2003 as Pera Networks, Inc.  In 2005 the Company changed its name to Ubiquiti Networks, Inc. and commenced its current operations. In June 2010, the Company was re-incorporated in Delaware.

[0001511737-15-000022:notes:10]
Ubiquiti Networks, Inc. and its wholly owned subsidiaries (collectively, “Ubiquiti” or the “Company”) is a product driven company that leverages innovative proprietary technologies to deliver networking solutions to both startup and established network operators and service providers.

[0001511737-15-000022:notes:11]
On October 13, 2011, the Company entered into an underwriting agreement for its initial public offering of common stock at $15.00 per share.  The Company's initial public offering closed on October 19, 2011. Immediately prior to the closing of the initial public offering, all outstanding shares of the Company’s preferred stock converted to common stock on a one for one basis.

[0001511737-15-000022:notes:12]
On June 18, 2013, the Company completed a secondary offering of 7,031,464 shares of common stock at an offering price of $16.00 per share, which included 531,464 shares sold in connection with the partial exercise of the option to purchase additional shares granted to the underwriters.  All of the shares sold in the offering were sold by existing stockholders of the Company, including entities affiliated with Summit Partners, L.P., and the Company's Chief Executive Officer, Robert J. Pera.  No shares were sold by the Company in the offering, and as such, the Company did not receive any proceeds from the offering.

[0001511737-15-000022:notes:13]
The Company operates on a fiscal year ending June 30. In these notes, Ubiquiti refers to the fiscal years ended June 30, 2015, 2014 and 2013 as fiscal 2015, fiscal 2014 and fiscal 2013, respectively.

[0001511737-15-000022:notes:14]
Basis of Presentation— The Company’s consolidated financial statements and accompanying notes are prepared in accordance with accounting principles generally accepted in the United States of America (“GAAP”) and include the accounts of Ubiquiti and its wholly owned subsidiaries. The Company has wholly owned subsidiaries in Lithuania, Hong Kong, China, Latvia, Poland, India and the Cayman Islands. The Company’s Hong Kong subsidiary also operates a branch office in Taiwan. All intercompany transactions and balances have been eliminated.  The Company has reclassified certain amounts reported in the previous period to conform to the current period presentation.


## us-gaap:CashAndCashEquivalentsPolicyTextBlock

[0001511737-15-000022:notes:15]
Cash and Cash Equivalents

[0001511737-15-000022:notes:16]
The Company considers investments purchased with a maturity period of three months or less at the date of purchase to be cash equivalents.  Cash and cash equivalents are stated at cost which approximates fair value. The Company deposits cash and cash equivalents with financial institutions that management believes are of high credit quality. The Company’s cash and cash equivalents consist primarily of cash deposited in U.S. dollar denominated interest-bearing deposit accounts.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001511737-15-000022:notes:17]
COMMITMENTS AND CONTINGENCIES

[0001511737-15-000022:notes:18]
Operating Leases

[0001511737-15-000022:notes:19]
The Company leases its headquarters in San Jose, California and other locations worldwide under non-cancelable operating leases that expire at various dates through 2019.

[0001511737-15-000022:notes:20]
At June 30, 2015, future minimum annual payments under operating leases are as follows (in thousands):

[0001511737-15-000022:notes:21]
|  | 2016 |  | 2017 |  | 2018 |  | 2019 |  | 2020 |  | Thereafter |  | Total |
| Operating leases | $ | 4,035 |  |  | $ | 2,851 |  |  | $ | 1,311 |  |  | $ | 244 |  |  | $ | 169 |  |  | $ | — |  |  | $ | 8,610 |  |

[0001511737-15-000022:notes:22]
Rent expense under operating leases was $3.6 million, $2.3 million and $1.7 million for fiscal 2015, fiscal 2014 and fiscal 2013, respectively.

[0001511737-15-000022:notes:23]
Purchase Obligations

[0001511737-15-000022:notes:24]
The Company primarily subcontracts with other companies to manufacture its products. During the normal course of business, the Company’s contract manufacturers procure components based upon orders placed by the Company. If the Company cancels all or part of the orders, it may still be liable to the contract manufacturers for the cost of the components purchased by them to manufacture the Company’s products. The Company periodically reviews the potential liability and to date no significant accruals have been recorded.  The Company had inventory purchase obligations of $10.0 million as of June 30, 2015.  Additionally, the Company has advanced outstanding payments to our contract manufacturers as of June 30, 2015 of $2.0 million.

[0001511737-15-000022:notes:25]
Indemnification Obligations

[0001511737-15-000022:notes:26]
The Company enters into standard indemnification agreements with many of its business partners in the ordinary course of business. These agreements include provisions for indemnifying the business partner against any claim brought by a third party to the extent any such claim alleges that a Company product infringes a patent, copyright or trademark, or violates any other proprietary rights of that third party. The maximum potential amount of future payments the Company could be required to make under these indemnification agreements is not estimable and the Company has not incurred any material costs to defend lawsuits or settle claims related to these indemnification agreements to date.

[0001511737-15-000022:notes:27]
Legal Matters

[0001511737-15-000022:notes:28]
The Company may be involved, from time to time, in a variety of claims, lawsuits, investigations, and proceedings relating to contractual disputes, intellectual property rights, employment matters, regulatory compliance matters and other litigation matters relating to various claims that arise in the normal course of business. The Company determines whether an estimated loss from a contingency should be accrued by assessing whether a loss is deemed probable and can be reasonably estimated. The Company assesses its potential liability by analyzing specific litigation and regulatory matters using available information. The Company develops its views on estimated losses in consultation with inside and outside counsel, which involves a subjective analysis of potential results and outcomes, assuming various combinations of appropriate litigation and settlement strategies. Taking all of the above factors into account, the Company records an amount where it is probable that the Company will incur a loss and where that loss can be reasonably estimated. However, the Company’s estimates may be incorrect and the Company could ultimately incur more or less than the amounts initially recorded.  The Company may also incur significant legal fees, which are expensed as incurred, in defending against these claims.  The Company is not currently aware of any pending or threatened litigation that would have a material adverse effect on the Company's financial statements.

[0001511737-15-000022:notes:29]
Shareholder Class Action Lawsuits

[0001511737-15-000022:notes:30]
Beginning on September 7, 2012, two class action lawsuits were filed in the United States District Court for the Northern District of California against Ubiquiti Networks, Inc., certain of its officers and directors, and the underwriters of its initial public offering, alleging claims under U.S. securities laws. On January 30, 2013, the plaintiffs filed an amended consolidated complaint. On March 26, 2014, the court issued an order granting a motion to dismiss the complaint with leave to amend. Following the plaintiffs’ decision not to file an amended complaint, on April 16, 2014, the court ordered the dismissal of the lawsuit with prejudice, and entered judgment in favor of the Company and the other defendants, and against the plaintiffs. On May 15, 2014, the plaintiffs filed a notice of appeal from the judgment of the court. The appeal is ongoing before the U.S. Court of Appeals for the Ninth Circuit. There can be no assurance that the Company will prevail in the appeal proceeding.  The Company cannot currently estimate the possible loss or range of possible loss, if any, that it may experience in connection with this litigation.

[0001511737-15-000022:notes:31]
Export Compliance Matters

[0001511737-15-000022:notes:32]
In May 2011, the Company filed a self-disclosure statement with the U.S. Commerce Department, Bureau of Industry and Security’s (“BIS”) Office of Export Enforcement (“OEE”) relating to a review conducted by the Company regarding certain export transactions from 2008 through March 2011 in which products may have been later resold into Iran by third parties. In June 2011, the Company also filed a self-disclosure statement with the U.S. Department of the Treasury’s Office of Foreign Asset Control (“OFAC”) regarding these compliance issues. In August 2011, the Company received a warning letter from OEE stating that OEE had not referred the findings of the Company’s review for criminal or administrative prosecution and closed the investigation of the Company without penalty. Based upon its review of the matter, OFAC identified certain apparent violations (“Apparent Violations”) of the Iranian Transactions and Sanctions Regulations by the Company during the period of in or about March 2008 through in or about February 2011. On March 4, 2014, the Company entered into a settlement agreement with OFAC resolving this administrative matter. Pursuant to the terms of the settlement agreement, the Company agreed to make a one-time payment to the U.S. Department of the Treasury in the amount of $504,000 in consideration of OFAC agreeing to release and forever discharge the Company from any and all civil liability in connection with the Apparent Violations. The Company previously accrued a reserve of $1.6 million relating to this matter in fiscal 2010 and, accordingly, reversed the excess of the accrual of $1.1 million as of the effective date of the settlement agreement.


## us-gaap:CommitmentsAndContingenciesPolicyTextBlock

[0001511737-15-000022:notes:33]
Commitments and Contingencies

[0001511737-15-000022:notes:34]
The Company periodically evaluates all pending or threatened contingencies and any commitments, if any, that are reasonably likely to have a material adverse effect on its results of operations, financial position or cash flows. The Company assesses the probability of an adverse outcome and determines if it is remote, reasonably possible or probable. If information available prior to the issuance of the Company’s financial statements indicates that it is probable that an asset had been impaired or a liability had been incurred at the date of the Company’s financial statements, and the amount of the loss, or the range of probable loss can be reasonably estimated, then such loss is accrued and charged to operating expenses. If no accrual is made for a loss contingency because one or both of the conditions pursuant to the accounting guidance are not met, but the probability of an adverse outcome is at least reasonably possible, the Company discloses the nature of the contingency and provides an estimate of the possible loss or range of loss, or states that such an estimate cannot be made.


## us-gaap:CompensationRelatedCostsPolicyTextBlock

[0001511737-15-000022:notes:35]
Stock-based Compensation

[0001511737-15-000022:notes:36]
The Company records stock-based awards at fair value as of the grant date and recognize expense, net of forfeitures, ratably on a straight-line basis over the requisite service period, which is generally the vesting term of the awards. The Company estimates the fair value of stock option awards on the grant date using the Black-Scholes option pricing model. The determination of the fair value of a stock-based award on the date of grant using the Black-Scholes option-pricing model is affected by the Company's stock price on the date of grant as well as assumptions regarding a number of complex and subjective variables. These variables include the Company's expected stock price volatility over the expected term of the award, actual and projected employee stock option exercise behaviors, the risk-free interest rate for the expected term of the award and expected dividends. Restricted stock units are valued based on the fair value of the Company's common stock on the date of grant.  Since the Company's initial public offering on October 14, 2011, the fair value of our common stock is determined using the closing market price of the Company's common stock as of the date of grant.


## us-gaap:DebtDisclosureTextBlock

[0001511737-15-000022:notes:37]
DEBT

[0001511737-15-000022:notes:38]
On August 7, 2012, the Company entered into a Loan and Security Agreement (the “Loan Agreement”) with U.S. Bank, as syndication agent, and East West Bank, as administrative agent for the lenders party to the Loan Agreement.  The Loan Agreement provided for (i) a $50.0 million revolving credit facility, with a $5.0 million sublimit for the issuance of letters of credit and a $5.0 million sublimit for the making of swingline loan advances, and (ii) a $50.0 million term loan facility.

[0001511737-15-000022:notes:39]
On May 5, 2014, the Company and certain of its subsidiaries entered into a credit agreement (the “Original Credit Agreement”) with Wells Fargo Bank, National Association (“Wells Fargo”), the financial institutions named as lenders therein, and Wells Fargo as administrative agent for the lenders, that provided for a $150.0 million senior secured revolving credit facility, with an option to request an increase in the amount of the credit facility by up to an additional $50.0 million (any such increase to be in each lender’s sole discretion).

[0001511737-15-000022:notes:40]
During fiscal 2014, the Company made aggregate payments of $5.0 million against the Loan Agreement.  At the time the Loan Agreement was retired in May 2014, the Company paid the remaining principal balance of $71.3 million.

[0001511737-15-000022:notes:41]
On March 3, 2015, the Company and Ubiquiti International Holding Company Limited (the “Cayman Borrower”) amended and restated the Original Credit Agreement (the "Amended Credit Agreement") with Wells Fargo, the other financial institutions named as lenders therein, and Wells Fargo as administrative agent for the lenders.  The Amended Credit Agreement provides for a $200.0 million senior secured revolving credit facility and a $100.0 million senior secured term loan facility (collectively, the "Facilities"), with an option to request increases in the amounts of such credit facilities by up to an additional $50.0 million in the aggregate (any such increase to be in each lender's sole discretion), and matures on March 3, 2020.  The term loan facility was fully drawn at closing,  $72.3 million of which was used to repay the outstanding balance under the Original Credit Agreement.

[0001511737-15-000022:notes:42]
The revolving credit facility includes a sub-limit of $10.0 million for letters of credit and a sub-limit of $25.0 million for swingline loans. The Facilities replaced the Company's $150.0 million senior secured revolving credit facility under the Original Credit Agreement. The Facilities are available for working capital and general corporate purposes that comply with the terms of the Amended Credit Agreement. Under the Amended Credit Agreement, revolving loans and swingline loans may be borrowed, repaid and reborrowed until March 3, 2020, at which time all amounts borrowed must be repaid. The term loan is payable in quarterly installments of 2.50% of the original principal amount of the term loan until March 31, 2017, thereafter increasing to 3.75% of the original principal amount of the term loan, in each case plus accrued and unpaid interest. Revolving, swingline and term loans may be prepaid at any time without penalty. Revolving and term loans bear interest, at the Company's option, at either (i) a floating rate per annum equal to the base rate plus a margin of between 0.50% and 1.25%, depending on the Company's leverage ratio as of the most recently ended fiscal quarter or (ii) a floating per annum rate equal to the applicable LIBOR rate for a specified period, plus a margin of between 1.50% and 2.25%, depending on the Company's leverage ratio as of the most recently ended fiscal quarter. Swingline loans bear interest at a floating rate per annum equal to the base rate plus a margin of between 0.50% and 1.25%, depending on the Company's leverage ratio as of the most recently ended fiscal quarter. Base rate is defined as the greatest of (A) Wells Fargo's prime rate, (B) the federal funds rate plus 0.50% or (C) the applicable LIBOR rate for a period of one month plus 1.00%. A default interest rate shall apply on all obligations during certain events of default under the Amended Credit Agreement at a rate per annum equal to 2.00% above the applicable interest rate. The Company will pay to each lender a facility fee on a quarterly basis based on the unused amount of each lender's commitment to make revolving loans, of between 0.20% and 0.35%, depending on the Company's leverage ratio as of the most recently ended fiscal quarter. The Company will also pay to the applicable lenders on a quarterly basis certain fees based on the daily amount available to be drawn under each outstanding letter of credit, including aggregate letter of credit commissions of between 1.50% and 2.25%, depending on the Company's leverage ratio as of the most recently ended fiscal quarter, and issuance fees of 0.125% per annum. The Company is also obligated to pay Wells Fargo, as agent, fees customary for a credit facility of this size and type.

[0001511737-15-000022:notes:43]
The Amended Credit Agreement requires the Company to maintain during the term of the Facilities (i) a maximum leverage ratio of 2.50 to 1.00 and (ii) minimum liquidity of $225.0 million, increasing to $250.0 million in the event of an incremental increase in the size of the Facilities, which can be satisfied with unrestricted cash and cash equivalents and up to $50.0 million of availability under the revolving credit facility. In addition, the Amended Credit Agreement contains customary affirmative and negative covenants, including covenants that limit or restrict the ability of the Company and its subsidiaries to, among other things, grant liens or enter into agreements restricting their ability to grant liens on property, enter into mergers, dispose of assets, change their accounting or reporting policies, change their business and incur indebtedness, in each case subject to customary exceptions for a credit facility of this size and type. The Amended Credit Agreement includes customary events of default that include, among other things, non-payment of principal, interest or fees, inaccuracy of representations and warranties, violation of covenants, cross default to certain other indebtedness, bankruptcy and insolvency events, material judgments, change of control and certain ERISA events. The occurrence of an event of default could result in the acceleration of the obligations under the Amended Credit Agreement.

[0001511737-15-000022:notes:44]
The obligations of the Company and certain domestic subsidiaries, if any, under the Amended Credit Agreement are required to be guaranteed by such domestic subsidiaries (the "Domestic Guarantors") and are collateralized by substantially all assets (excluding intellectual property) of the Company and the Domestic Guarantors. The obligations of the Cayman Borrower and certain foreign subsidiaries under the Amended Credit Agreement are required to be guaranteed by certain domestic and material foreign subsidiaries (the "Guarantors") and are collateralized by substantially all assets (excluding intellectual property) of the Company and the Guarantors.

[0001511737-15-000022:notes:45]
During fiscal 2015, the Company made aggregate payments of $2.5 million against the Amended Credit Agreement.  As of June 30, 2015, the Company has classified $10.0 million and $87.5 million of short term and long-term debt, respectively, on its consolidated balance sheet related to the Amended Credit Agreement.

[0001511737-15-000022:notes:46]
The following table summarizes our estimated debt and interest payment obligations as of June 30, 2015 (in thousands):

[0001511737-15-000022:notes:47]
|  | 2016 |  | 2017 |  | 2018 |  | 2019 |  | 2020 |  | Thereafter |  | Total |
| Debt payment obligations | $ | 10,000 |  |  | $ | 11,250 |  |  | $ | 15,000 |  |  | $ | 15,000 |  |  | $ | 46,250 |  |  | $ | — |  |  | $ | 97,500 |  |
| Interest payments on debt payment obligations | 1,982 |  |  | 1,810 |  |  | 1,589 |  |  | 1,337 |  |  | 789 |  |  | — |  |  | 7,507 |  |
| Total | $ | 11,982 |  |  | $ | 13,060 |  |  | $ | 16,589 |  |  | $ | 16,337 |  |  | $ | 47,039 |  |  | $ | — |  |  | $ | 105,007 |  |


## us-gaap:DeferredCostsCapitalizedPrepaidAndOtherAssetsDisclosureTextBlock

[0001511737-15-000022:notes:48]
Prepaid expenses and other current assets consisted of the following (in thousands):

[0001511737-15-000022:notes:49]
|  | June 30, |
|  | 2015 |  | 2014 |
| Vendor deposits, net of reserves of $5,827 and $0, for fiscal 2015 and fiscal 2014, respectively | $ | 19,998 |  |  | $ | 8,043 |  |
| Other current assets | 7,711 |  |  | 5,224 |  |
|  | $ | 27,709 |  |  | $ | 13,267 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001511737-15-000022:notes:50]
STOCK BASED COMPENSATION

[0001511737-15-000022:notes:51]
Stock-Based Compensation Plans

[0001511737-15-000022:notes:52]
2010 Equity Incentive Plan

[0001511737-15-000022:notes:53]
In March 2010, the Company’s Board of Directors and stockholders approved the 2010 Equity Incentive Plan (the “2010 Plan”). The 2010 Plan replaced the 2005 Equity Incentive Plan (the “2005 Plan”), and no further awards will be granted pursuant to the 2005 Plan. Under the terms of the 2010 Plan, nonstatutory stock options, stock appreciation rights, restricted stock, and restricted stock units (“RSUs”) may be granted to employees or non-employee service providers. Incentive stock options may be granted only to employees.

[0001511737-15-000022:notes:54]
The maximum aggregate number of shares that may be awarded under the 2010 Plan as of June 30, 2015 was 8,000,000 shares, plus any shares subject to stock options or similar awards granted under the 2005 Plan that expire or otherwise terminate without having been exercised in full and shares issued pursuant to awards granted under the 2005 Plan that are forfeited to (but not repurchased by) the Company.

[0001511737-15-000022:notes:55]
The 2010 Plan is administered by the Company's Board of Directors or a committee of the Company’s Board of Directors. Subject to the terms and conditions of the 2010 Plan, the administrator has the authority to select the persons to whom awards are to be made, to determine the number of shares to be subject to awards and the terms and conditions of awards, and to make all other determinations and to take all other actions necessary or advisable for the administration of the 2010 Plan. The administrator is also authorized to adopt, amend or rescind rules relating to administration of the 2010 Plan. Options and RSUs generally vest over a four year period from the date of grant and generally expire five to ten years from the date of grant. The terms of the 2010 Plan provide that an option price shall not be less than 100% of fair market value on the date of grant.

[0001511737-15-000022:notes:56]
2005 Equity Incentive Plan

[0001511737-15-000022:notes:57]
With the adoption of the 2010 Plan, no additional awards may be granted under the 2005 Plan. In February 2005, the Company’s Board of Directors and the stockholders approved the 2005 Plan, which was amended and restated in March 2006. The 2005 Plan provided for the issuance of stock options, restricted stock and stock bonuses to employees, consultants, advisors, directors and officers of the Company. The terms of the options granted under the 2005 Plan were determined at the time of grant. The Company made use of different vesting schedules through fiscal 2009, but subsequent new grants generally vested as to 25% on the first anniversary of the date of grant and monthly thereafter over the next three years and generally have a term of 10 years from the date of grant.

[0001511737-15-000022:notes:58]
As of June 30, 2015, the Company had 9,993,423 authorized shares available for future issuance under all of its stock incentive plans.

[0001511737-15-000022:notes:59]
The following table shows total stock-based compensation expense included in the Consolidated Statements of Operations and Comprehensive Income for fiscal 2015, 2014 and 2013 (in thousands):

[0001511737-15-000022:notes:60]
|  | Years Ended Years Ended June 30, |
|  | 2015 |  | 2014 |  | 2013 |
| Cost of sales | $ | 601 |  |  | $ | 590 |  |  | $ | 446 |  |
| Research and development | 2,854 |  |  | 2,423 |  |  | 1,433 |  |
| Sales, general and administrative | 1,537 |  |  | 1,893 |  |  | 1,497 |  |
|  | $ | 4,992 |  |  | $ | 4,906 |  |  | $ | 3,376 |  |

[0001511737-15-000022:notes:61]
Stock Options

[0001511737-15-000022:notes:62]
The following is a summary of option activity for the Company’s stock incentive plans for fiscal 2015, 2014 and 2013:

[0001511737-15-000022:notes:63]
|  | Common Stock Options Outstanding |
|  | Numberof Shares |  | WeightedAverageExercisePrice |  | WeightedAverageRemainingContractualLife (Years) |  | AggregateIntrinsicValue |
|  |  |  |  |  |  |  | (In thousands) |
| Balance, June 30, 2012 | 3,347,445 |  |  | $ | 1.45 |  |  | 6.62 |  | $ | 42,920 |  |
| Granted | 683,500 |  |  | 11.29 |  |  |  |  |  |
| Exercised | (266,558 | ) |  | 2.39 |  |  |  |  |  |
| Forfeitures and cancellations | (150,125 | ) |  | 5.68 |  |  |  |  |  |
| Balance, June 30, 2013 | 3,614,262 |  |  | $ | 3.07 |  |  | 6.17 |  | $ | 52,330 |  |
| Exercised | (849,635 | ) |  | 2.46 |  |  |  |  |  |
| Forfeitures and cancellations | (107,485 | ) |  | 10.55 |  |  |  |  |  |
| Balance, June 30, 2014 | 2,657,142 |  |  | $ | 2.96 |  |  | 5.11 |  | $ | 112,215 |  |
| Exercised | (299,034 | ) |  | $ | 5.64 |  |  |  |  |  |
| Forfeitures and cancellations | (56,964 | ) |  | $ | 12.14 |  |  |  |  |  |
| Balance, June 30, 2015 | 2,301,144 |  |  | $ | 2.38 |  |  | 3.82 |  | $ | 67,969 |  |
| Vested and expected to vest as of June 30, 2015 | 2,295,811 |  |  | $ | 2.36 |  |  | 3.81 |  | $ | 67,860 |  |
| Vested and exercisable as of June 30, 2015 | 2,167,482 |  |  | $ | 1.83 |  |  | 3.60 |  | $ | 65,224 |  |

[0001511737-15-000022:notes:64]
Additional information regarding options outstanding as of June 30, 2015 is as follows (in thousands, except weighted average exercise price amounts and contractual life):

[0001511737-15-000022:notes:65]
|  |  | Options Outstanding |  |  |  | Options Exercisable |
| Range of Exercise Prices |  | Number ofOptions |  | WeightedAverageRemainingContractualLife (Years) |  | WeightedAverageExercisePrice |  | Number ofOptions |  | WeightedAverageExercisePrice |
| $0.01 - $1.91 |  | 1,654,160 |  |  | 2.76 |  | $ | 0.05 |  |  | 1,654,160 |  |  | $ | 0.05 |  |
| $1.92 - $10.76 |  | 292,352 |  |  | 5.53 |  | 4.49 |  |  | 291,828 |  |  | 4.49 |  |
| $10.77 - $11.74 |  | 260,250 |  |  | 7.37 |  | 10.77 |  |  | 161,496 |  |  | 10.77 |  |
| $11.75 - $18.48 |  | 87,788 |  |  | 7.32 |  | 13.17 |  |  | 54,377 |  |  | 13.29 |  |
| $18.49 - $19.98 |  | 3,907 |  |  | 6.47 |  | 18.55 |  |  | 3,301 |  |  | 18.55 |  |
| $19.99 - $26.28 |  | 2,687 |  |  | 5.48 |  | 21.55 |  |  | 2,320 |  |  | 21.55 |  |
| $0.01 – $26.28 |  | 2,301,144 |  |  | 3.82 |  | $ | 2.38 |  |  | 2,167,482 |  |  | $ | 1.83 |  |

[0001511737-15-000022:notes:66]
During fiscal 2015 and 2014 and 2013, the aggregate intrinsic value of options exercised under the Company’s stock incentive plans was $9.2 million,  $30.5 million, and $3.4 million, respectively, as determined as of the date of option exercise.

[0001511737-15-000022:notes:67]
As of June 30, 2015, the Company had unrecognized compensation cost of $695,000 related to stock options which the Company expects to recognize over a weighted-average period of 1.4 years. Future option grants will increase the amount of compensation expense to be recorded in these periods.

[0001511737-15-000022:notes:68]
The Company estimates the fair value of employee stock options using the Black-Scholes option pricing model. The fair value of employee stock options is being amortized on a straight-line basis over the requisite service period of the awards. The Company did not grant any stock options during fiscal 2015 or fiscal 2014.  For fiscal 2013 the fair value of employee stock options was estimated using the following weighted average assumptions:

[0001511737-15-000022:notes:69]
|  |  | Year Ended June 30, 2013 |
| Expected term |  | 6.1 years |  |
| Expected volatility |  | 52 | % |
| Risk-free interest rate |  | 0.9 | % |
| Expected dividend yield |  | — |  |
| Weighted average grant date fair value |  | $ | 5.57 |  |

[0001511737-15-000022:notes:70]
Expected term. Expected term represents the period that the Company’s stock-based awards are expected to be outstanding. As the Company has limited historical option exercise data, the expected term of the stock options granted to employees was calculated based on the simplified method. Under the simplified method, the expected term is equal to the average of an option’s weighted-average vesting period and its contractual term. The Company is permitted to continue using the simplified method until sufficient information regarding exercise behavior, such as historical exercise data or exercise information from external sources, becomes available.

[0001511737-15-000022:notes:71]
Expected volatility. The expected volatility was based on the historical stock volatilities of a group of publicly listed comparable companies over a period equal to the expected terms of the options, as the Company does not have any trading history to use the volatility of its common stock.

[0001511737-15-000022:notes:72]
Expected dividend yield. Although the Company paid a special cash dividend during fiscal 2013, the Company does not currently plan to pay dividends on its common stock.

[0001511737-15-000022:notes:73]
Risk-free interest rate. The risk-free interest rate is based on the U.S. Treasury yield curve in effect at the time of grant for zero coupon U.S. Treasury notes with maturities approximately equal to the option’s expected term.

[0001511737-15-000022:notes:74]
Fair value of common stock. The Company’s common stock began trading on the NASDAQ Global Select Market on October 14, 2011, upon its initial public offering. The fair value of the Company’s common stock is determined using the market price of the Company’s common stock as of the date of grant. Prior to October 14, 2011, the fair value of the shares of common stock underlying the stock options has historically been the responsibility of and determined by the Company’s Board of Directors. Because there had been no public market for the Company’s common stock, its Board of Directors has determined fair value of the common stock at the time of grant of the option by considering a number of objective and subjective factors including independent third-party valuations of its common stock, operating and financial performance, the lack of liquidity of capital stock and general and industry specific economic outlook, amongst other factors.

[0001511737-15-000022:notes:75]
Forfeiture rate. The Company estimates its forfeiture rate based on an analysis of its actual forfeitures and will continue to evaluate the adequacy of the forfeiture rate based on actual forfeiture experience, analysis of employee turnover behavior and other factors. The impact from a forfeiture rate adjustment will be recognized in full in the period of adjustment, and if the actual number of future forfeitures differs from that estimated, the Company may be required to record adjustments to stock-based compensation expense in future periods.

[0001511737-15-000022:notes:76]
Cash received from stock option exercises during the fiscal 2015, 2014 and 2013 was $1.7 million, $2.1 million and $635,000, respectively.

[0001511737-15-000022:notes:77]
Restricted Stock Units (“RSUs”)

[0001511737-15-000022:notes:78]
The following table summarizes the activity of the RSUs made by the Company:

[0001511737-15-000022:notes:79]
|  | Number of Shares |  | Weighted Average Grant Date Fair Value |
| Non-vested RSUs, June 30, 2012 | 453,620 |  |  | $ | 9.42 |  |
| RSUs granted | 656,500 |  |  | 14.11 |  |
| RSUs vested | (70,512 | ) |  | 14.14 |  |
| RSUs canceled | (294,702 | ) |  | 5.29 |  |
| Non-vested RSUs, June 30, 2013 | 744,906 |  |  | $ | 14.74 |  |
| RSUs granted | 209,032 |  |  | 37.87 |  |
| RSUs vested | (170,197 | ) |  | 15.59 |  |
| RSUs canceled | (234,039 | ) |  | 16.18 |  |
| Non-vested RSUs, June 30, 2014 | 549,702 |  |  | $ | 22.65 |  |
| RSUs granted | 182,865 |  |  | 32.47 |  |
| RSUs vested | (182,507 | ) |  | 21.27 |  |
| RSUs canceled | (149,425 | ) |  | 24.84 |  |
| Non-vested RSUs, June 30, 2015 | 400,635 |  |  | 26.95 |  |

[0001511737-15-000022:notes:80]
The intrinsic value of RSUs vested in fiscal 2015, 2014 and 2013 was $6.4 million, $6.1 million and $1.0 million, respectively.  The total intrinsic value of all outstanding RSUs was $12.8 million as of June 30, 2015.

[0001511737-15-000022:notes:81]
As of June 30, 2015, there was unrecognized compensation costs related to RSUs of $8.0 million which the Company expects to recognize over a weighted average period of 2.9 years.


## us-gaap:EarningsPerSharePolicyTextBlock

[0001511737-15-000022:notes:82]
Earnings Per Share

[0001511737-15-000022:notes:83]
The Company applies the two-class method for calculating and presenting earnings per share (“EPS”). Under the two-class method, net income is allocated between shares of common stock and other participating securities based on their participating rights. Participating securities are defined as securities that participate in dividends with common stock according to a pre-determined formula or a contractual obligation to share in the income of the entity. Basic EPS is computed by dividing net income available to common stockholders by the weighted average number of shares of common stock outstanding during the period. Diluted EPS is computed by dividing the amount of net income available to common stockholders outstanding plus income allocable to participating securities, to the extent they are dilutive, by the weighted average number of shares of common stock and potential dilutive shares outstanding during the period if the effect is dilutive. The Company’s potentially dilutive common securities include outstanding stock options and restricted stock units.


## us-gaap:EarningsPerShareTextBlock

[0001511737-15-000022:notes:84]
EARNINGS PER SHARE

[0001511737-15-000022:notes:85]
The following table sets forth the computation of basic and diluted earnings per share for the periods indicated (in thousands, except per share data):

[0001511737-15-000022:notes:86]
|  | Years Ended June 30, |
|  | 2015 |  | 2014 |  | 2013 |
| Numerator: |  |  |  |  |  |
| Net income and comprehensive income | $ | 129,663 |  |  | $ | 176,937 |  |  | $ | 80,490 |  |
| Denominator: |  |  |  |
| Weighted-average shares used in computing basic net income per share | 88,008 |  |  | 87,772 |  |  | 88,314 |  |
| Add—dilutive potential common shares: |  |  |  |  |  |
| Stock options | 1,392 |  |  | 1,696 |  |  | 1,803 |  |
| Restricted stock units | 169 |  |  | 247 |  |  | 142 |  |
| Weighted-average shares used in computing diluted net income per share | 89,569 |  |  | 89,715 |  |  | 90,259 |  |
| Net income per share of common stock: |  |  |  |
| Basic | $ | 1.47 |  |  | $ | 2.02 |  |  | $ | 0.91 |  |
| Diluted | $ | 1.45 |  |  | $ | 1.97 |  |  | $ | 0.89 |  |

[0001511737-15-000022:notes:87]
The Company excludes potentially dilutive securities from its diluted net income per share calculation when their effect would be antidilutive to net income per share amounts.  The following table summarizes the total potential shares of common stock that were excluded from the diluted per share calculation, because to include them would have been anti-dilutive for the period (in thousands):

[0001511737-15-000022:notes:88]
|  | Years Ended June 30, |
|  | 2015 |  | 2014 |  | 2013 |
| Stock options | — |  |  | — |  |  | 658 |  |
| Restricted stock units | 2 |  |  | 36 |  |  | 364 |  |
|  | 2 |  |  | 36 |  |  | 1,022 |  |


## us-gaap:FairValueAssetsAndLiabilitiesMeasuredOnRecurringAndNonrecurringBasisTableTextBlock

[0001511737-15-000022:notes:89]
As of June 30, 2015 and 2014, the fair value hierarchy for the Company’s financial liabilities was as follows (in thousands):

[0001511737-15-000022:notes:90]
|  | June 30, 2015 |  | June 30, 2014 |
|  | FairValue |  | Level 1 |  | Level 2 |  | Level 3 |  | FairValue |  | Level 1 |  | Level 2 |  | Level 3 |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Debt(1) | $ | 97,500 |  |  | $ | — |  |  | $ | 97,500 |  |  | $ | — |  |  | $ | 72,254 |  |  | $ | — |  |  | $ | 72,254 |  |  | $ | — |  |

[0001511737-15-000022:notes:91]
(1) Debt is carried at historical cost on the Company's consolidated balance sheet.


## us-gaap:FairValueDisclosuresTextBlock

[0001511737-15-000022:notes:92]
FAIR VALUE OF FINANCIAL INSTRUMENTS

[0001511737-15-000022:notes:93]
For certain of the Company’s financial instruments, including cash, accounts receivable and accounts payable, the carrying amounts approximate fair value due to their short maturities, and are therefore excluded from the fair value tables below.   Additionally, as of June 30, 2015, we held $397.0 million of our $446.4 million of cash and cash equivalents in accounts of our subsidiaries outside of the United States and we will incur significant tax liabilities if we were to repatriate those amounts.

[0001511737-15-000022:notes:94]
At June 30, 2015 and 2014 the Company had debt associated with Amended Credit Agreement and Original Credit Agreement, respectively, with Wells Fargo Bank (See Note 7). The fair value of the Company’s debt was estimated based on the current rates offered to the Company for debt with similar terms and remaining maturities and was Level 2 measurement.


## us-gaap:ForeignCurrencyTransactionsAndTranslationsPolicyTextBlock

[0001511737-15-000022:notes:95]
Foreign Currency Remeasurement

[0001511737-15-000022:notes:96]
The functional currency of the Company and its subsidiaries is the U.S. dollar. For foreign operations, local currency denominated monetary assets and liabilities are remeasured at the period end exchange rates, and revenues, costs and expenses are remeasured at the average exchange rates during the fiscal year. Foreign exchange gains and losses have been immaterial to the Company’s results of operations to date.


## us-gaap:ImpairmentOrDisposalOfLongLivedAssetsPolicyTextBlock

[0001511737-15-000022:notes:97]
Long Lived Assets

[0001511737-15-000022:notes:98]
The Company evaluates its long lived assets including property and equipment for impairment whenever events or changes in circumstances indicate that the carrying value of these assets may not be recoverable. An impairment loss is recognized when the net book value of such assets exceeds the estimated future undiscounted cash flows attributable to the assets or asset group. If impairment is indicated, the asset is written down to its estimated fair value.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001511737-15-000022:notes:99]
INCOME TAXES

[0001511737-15-000022:notes:100]
For financial reporting purposes, the components of income before provision for income taxes were as follows (in thousands):

[0001511737-15-000022:notes:101]
|  |  | Years Ended June 30, |
|  |  | 2015 |  | 2014 |  | 2013 |
| Domestic |  | $ | 44,743 |  |  | $ | 44,551 |  |  | $ | 17,860 |  |
| Foreign |  | 101,005 |  |  | 150,060 |  |  | 73,893 |  |
|  |  | $ | 145,748 |  |  | $ | 194,611 |  |  | $ | 91,753 |  |

[0001511737-15-000022:notes:102]
The components of the Company’s provision for income taxes consisted of the following (in thousands):

[0001511737-15-000022:notes:103]
|  |  | Years Ended June 30, |
|  |  | 2015 |  | 2014 |  | 2013 |
| Current |  |  |  |  |  |  |
| Foreign |  | $ | 909 |  |  | $ | 2,451 |  |  | $ | 1,790 |  |
| Federal |  | 15,786 |  |  | 16,516 |  |  | 8,515 |  |
| State |  | 299 |  |  | 109 |  |  | 581 |  |
| Current tax expense |  | 16,994 |  |  | 19,076 |  |  | 10,886 |  |
| Deferred |  |  |  |  |  |  |
| Foreign |  | — |  |  | — |  |  | — |  |
| Federal |  | (856 | ) |  | (1,507 | ) |  | (130 | ) |
| State |  | (53 | ) |  | 105 |  |  | 507 |  |
| Deferred tax expense |  | (909 | ) |  | (1,402 | ) |  | 377 |  |
| Provision for income taxes |  | $ | 16,085 |  |  | $ | 17,674 |  |  | $ | 11,263 |  |

[0001511737-15-000022:notes:104]
Significant components of the Company’s deferred tax assets and liabilities consisted of the following (in thousands):

[0001511737-15-000022:notes:105]
|  |  | June 30, |
|  |  | 2015 |  | 2014 |
| Deferred tax assets |  |  |  |  |
| Reserves and Allowances |  | $ | 836 |  |  | $ | 200 |  |
| Stock-based compensation |  | 1,168 |  |  | 1,038 |  |
| Accrued expenses |  | 446 |  |  | 455 |  |
| Research and development credits |  | 595 |  |  | 345 |  |
| State tax |  | 824 |  |  | 570 |  |
| Other |  | 399 |  |  | 353 |  |
| Total deferred tax assets |  | 4,268 |  |  | 2,961 |  |
| Deferred tax liabilities |  |  |  |  |
| Basis difference for fixed assets |  | (623 | ) |  | (477 | ) |
| Other |  | — |  |  | — |  |
| Total deferred tax liabilities |  | (623 | ) |  | (477 | ) |
| Valuation allowance |  | (595 | ) |  | (345 | ) |
| Net deferred tax assets |  | $ | 3,050 |  |  | $ | 2,139 |  |

[0001511737-15-000022:notes:106]
As of June 30, 2015, the Company had California research tax credit carry-forwards, net of ASC 740-10 unrecognized tax benefits, of approximately $1.4 million. The California research credits can be carried forward indefinitely.

[0001511737-15-000022:notes:107]
Management assesses the available positive and negative evidence to estimate if sufficient future taxable income will be generated to use the existing deferred tax assets.  In the fourth quarter of fiscal 2014, the Company determined that it is more likely than not that our deferred tax asset for California research credits will not be realized as for the foreseeable future the Company is expecting to generate credits in excess of its ability to use such attributes. As a result, the Company has provided a valuation allowance of $595,000 for the amount of California deferred tax assets that may not be realized as of June 30, 2015.

[0001511737-15-000022:notes:108]
As a result of certain realization requirements of ASC 718, Compensation - Stock Compensation, the table of deferred tax assets and liabilities shown above does not include certain deferred tax assets as of June 30, 2015, that arose directly from (or the use of which was postponed by) tax deductions related to equity compensation that are greater than the compensation recognized for financial reporting. Equity will be increased by approximately $495,000 if and when such deferred tax assets are ultimately realized. The Company uses ASC 740 ordering when determining when excess tax benefits have been realized.

[0001511737-15-000022:notes:109]
The effective tax rate differs from the applicable U.S. statutory federal income tax rate as follows:

[0001511737-15-000022:notes:110]
|  |  | Years Ended June 30, |
|  |  | 2015 |  | 2014 |  | 2013 |
| Statutory rate |  | 35.0 | % |  | 35.0 | % |  | 35.0 | % |
| Stock-based compensation |  | 0.6 |  |  | 0.4 |  |  | 0.8 |  |
| State tax expense |  | 0.1 |  |  | — |  |  | 0.7 |  |
| Tax rate differential, foreign income |  | (23.2 | ) |  | (25.3 | ) |  | (24.2 | ) |
| Federal research and development credits |  | (1.1 | ) |  | (0.3 | ) |  | (0.4 | ) |
| Other permanent items |  | (0.4 | ) |  | (0.7 | ) |  | 0.4 |  |
| Effective tax rate |  | 11.0 | % |  | 9.1 | % |  | 12.3 | % |

[0001511737-15-000022:notes:111]
The Company’s effective tax rate increased to 11.0% for fiscal 2015 as compared to 9.1% for fiscal 2014.   The higher effective tax rate in fiscal 2015 was primarily attributable to increased sales in the United States and the decreased profit before taxes of Hong Kong due to the $39.1 million BEC fraud loss, which decreased the tax benefit from foreign tax rate differential.  The Company had increased foreign operations in fiscal 2014 as compared to fiscal 2013, which resulted in the generation more income on a comparative year over year basis in foreign jurisdictions that have lower tax rates than the U.S.

[0001511737-15-000022:notes:112]
It is the practice and intention of the Company to reinvest the earnings of its non-U.S. subsidiaries in those operations.  As of June 30, 2015, the Company has not made a provision for U.S. or additional foreign withholding taxes on approximately $443.0 million of the excess of the amount for financial reporting over the tax basis of investments in foreign subsidiaries that are essentially permanent in duration. Generally, such amounts become subject to U.S. taxation upon the remittance of dividends and under certain other circumstances. It is not practicable to estimate the amount of deferred tax liability related to investments in these foreign subsidiaries.

[0001511737-15-000022:notes:113]
While management believes that the Company has adequately provided for all tax positions, amounts asserted by tax authorities could be greater or less than the recorded position. Accordingly, the Company's provisions on federal, state and foreign tax-related matters to be recorded in the future may change as revised estimates are made or the underlying matters are settled or otherwise resolved.

[0001511737-15-000022:notes:114]
A reconciliation of the beginning and ending balances of the unrecognized tax benefits during the years ended June 30, 2015 2014 and 2013 consists of the following (in thousands):

[0001511737-15-000022:notes:115]
|  |  | Years Ended June 30, |
|  |  | 2015 |  | 2014 |  | 2013 |
|  |  | (In thousands) |
| Unrecognized benefit—beginning of period |  | $ | 14,914 |  |  | $ | 11,455 |  |  | $ | 7,825 |  |
| Gross increases—current year tax positions |  | 4,960 |  |  | 3,871 |  |  | 3,806 |  |
| Gross increases (decreases)—prior year tax positions |  | — |  |  | (213 | ) |  | (176 | ) |
| Gross decreases - prior year tax positions due to statue lapse |  | (284 | ) |  | (199 | ) |  | — |  |
| Unrecognized benefit—end of period |  | $ | 19,590 |  |  | $ | 14,914 |  |  | $ | 11,455 |  |

[0001511737-15-000022:notes:116]
Included in the gross unrecognized tax benefits balance as of June 30, 2015 are $18.6 million of tax positions which would affect income tax expense if recognized.  The Company recognizes interest and penalties related to unrecognized tax benefits within the income tax expense line in the accompanying Consolidated Statement of Operations and Comprehensive Income.  Accrued interest and penalties are included within the related tax liability line in the Consolidated Balance Sheet.  As of June 30, 2015, the Company had $1.2 million accrued interest related to uncertain tax matters. The Company does not expect its unrecognized tax benefits as of June 30, 2015 will materially change within the next 12 months.  The Company files income tax returns in the United States, various states and certain foreign jurisdictions.  Tax years 2012 through 2015 are subject to examination by the U.S. federal tax authorities. Tax years 2010 through 2014 are subject to examination by the state tax authorities. Tax years 2010 through 2015 are generally subject to examination by certain foreign tax authorities.  There are no income tax examinations currently in process.


## us-gaap:IncomeTaxPolicyTextBlock

[0001511737-15-000022:notes:117]
Income Taxes

[0001511737-15-000022:notes:118]
The Company accounts for income taxes in accordance with accounting guidance which requires recognition of deferred tax assets and liabilities for the expected future tax consequences of events that have been included in its financial statements or tax returns. Deferred tax assets and liabilities are determined based on the temporary difference between the financial statement carrying amounts of existing assets and liabilities and their respective tax bases. Deferred tax assets and liabilities are measured using enacted tax rates expected to apply to taxable income in the years in which those temporary differences are expected to be recovered or settled. The Company establishes valuation allowances when necessary to reduce deferred tax assets to the amount it expects to realize. The assessment of whether or not a valuation allowance is required often requires significant judgment including current operating results, the forecast of future taxable income and ongoing prudent and feasible tax planning initiatives. In addition, the Company’s calculation of its tax liabilities involves dealing with uncertainties in the application of complex tax regulations. The Company may be subject to income tax audits in all of the jurisdictions in which it operates and, as a result, must also assess exposures to any potential issues arising from current or future audits of current and prior years’ tax returns. Accordingly, the Company must assess such potential exposures and, where necessary, provide a reserve to cover any expected loss. To the extent that the Company establishes a reserve, its provision for income taxes would be increased. If the Company ultimately determines that payment of these amounts is unnecessary, it reverses the liability and recognizes a tax benefit during the period in which it determines that the liability is no longer necessary. The Company records an additional charge in its provision for taxes in the period in which it determines that tax liability is greater than its original estimate.  The Company recognizes interest and penalties related to unrecognized tax benefits on the income tax expense line in the accompanying consolidated statement of operations. Accrued interest and penalties are included on the related tax liability line in the consolidated balance sheet.


## us-gaap:InventoryPolicyTextBlock

[0001511737-15-000022:notes:119]
Inventory and Inventory Valuation

[0001511737-15-000022:notes:120]
The Company's inventories are primarily finished goods and, to a lesser extent, raw materials, which have been either consigned to the Company's contract manufacturers or are held by the Company.  Inventories are stated at the lower of actual cost (computed on a first-in, first-out basis), or market value. Market value is based upon an estimated average selling price reduced by the estimated costs of disposal. The determination of market value involves numerous judgments including estimating average selling prices based up recent sales, industry trends, existing customer orders, and seasonal factors. Should actual market conditions differ from the Company's estimates, future results of operations could be materially affected. The Company reduces the value of its inventory for estimated obsolescence or lack of marketability by the difference between the cost of the affected inventory and the estimated market value. Write-downs are not reversed until the related inventory has been subsequently sold or scrapped.

[0001511737-15-000022:notes:121]
The valuation of inventory also requires the Company to estimate excess and obsolete inventory. The determination of excess or obsolete inventory is estimated based on a comparison of the quantity and cost of inventory on hand to the Company's forecast of customer demand. Customer demand is dependent on many factors and requires the Company to use significant judgment in our forecasting process. The Company also makes assumptions regarding the rate at which new products will be accepted in the marketplace and at which customers will transition from older products to newer products. If actual market conditions are less favorable than those projected by management, additional inventory write-downs may be required, which would have a negative impact on the Company's gross margin. If the Company ultimately sells inventory that has been previously written down, the Company's gross margins in future periods will be positively impacted.


## us-gaap:LeasePolicyTextBlock

[0001511737-15-000022:notes:122]
Leases

[0001511737-15-000022:notes:123]
The Company leases its facilities under cancelable and noncancelable operating leases. For leases that contain rent escalation or rent concessions provisions, the Company records the total rent expense during the lease term on a straight line basis over the term of the lease. The Company records the difference between the rent paid and the straight line rent as a deferred rent liability on the consolidated balance sheets.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001511737-15-000022:notes:124]
Recent Accounting Pronouncements

[0001511737-15-000022:notes:125]
In June 2014, the Financial Accounting Standards Board, or FASB, issued a new accounting standard update on revenue from contracts with customers.  The core principle of the guidance is that an entity should recognize revenue to depict the transfer of promised goods or services to customers in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services.  To achieve that core principle, an entity should apply the following steps:

[0001511737-15-000022:notes:126]
Step 1: Identify the contract(s) with a customer.

[0001511737-15-000022:notes:127]
Step 2: Identify the performance obligations in the contract.

[0001511737-15-000022:notes:128]
Step 3: Determine the transaction price.

[0001511737-15-000022:notes:129]
Step 4: Allocate the transaction price to the performance obligations in the contract.

[0001511737-15-000022:notes:130]
Step 5: Recognize revenue when (or as) the entity satisfies a performance obligation.

[0001511737-15-000022:notes:131]
An entity should disclose sufficient information to enable users of financial statements to understand the nature, amount, timing, and uncertainty of revenue and cash flows arising from contracts with customers. Qualitative and quantitative information is required about contracts with customers, significant judgments and any assets recognized from the costs to obtain or fulfill a contract.   The guidance was to be effective for annual and interim reporting periods beginning after December 15, 2016.  However, in July 2015, the FASB deferred the effective date by one year, to December 15, 2017,  to provide adequate time to effectively implement the new standard, though the early adoption as of the original effective date is allowed.  The Company does not expect a material impact on revenue recognition as a result of implementing  this new guidance.

[0001511737-15-000022:notes:132]
In April 2015, the FASB issued an accounting standard update on simplifying the presentation of debt issuance costs.  The updated guidance requires that debt issuance costs related to a recognized debt liability be presented in the balance sheet as a direct deduction from the carrying amount of that debt liability, consistent with debt discounts. The recognition and measurement guidance for debt issuance costs are not affected by the updated guidance.  The guidance will be effective for the Company beginning July 1, 2016.  The guidance will result only in a reclassification on the Company's balance sheet and is not expected to have any effect on the Company's operating results.

[0001511737-15-000022:notes:133]
In July 2015, the FASB issued an accounting standards update on simplifying the measurement of inventory.  The updated guidance requires an entity to measure inventory at the lower of cost and net realizable value.  Net realizable value is the estimated selling prices in the ordinary course of business, less reasonably predictable costs of completion, disposal, and transportation. Subsequent measurement is unchanged for inventory measured using LIFO or the retail inventory method.

[0001511737-15-000022:notes:134]
The guidance will be effective for the Company beginning July 1, 2017.  The Company is currently assessing the impact of this new guidance.


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001511737-15-000022:notes:135]
ACCRUED WARRANTY

[0001511737-15-000022:notes:136]
Warranty obligations, included in other current liabilities, were as follows (in thousands):

[0001511737-15-000022:notes:137]
| Balance at June 30, 2013 | $ | 2,913 |  |
| Accruals for warranties issued during the period | 4,157 |  |
| Settlements made during the period | (4,220 | ) |
| Balance at June 30, 2014 | 2,850 |  |
| Accruals for warranties issued during the period | 3,643 |  |
| Settlements made during the period | (3,743 | ) |
| Balance at June 30, 2015 | $ | 2,750 |  |


## us-gaap:PropertyPlantAndEquipmentPolicyTextBlock

[0001511737-15-000022:notes:138]
Property and Equipment

[0001511737-15-000022:notes:139]
Furniture, fixtures and equipment are recorded at cost. The Company also capitalizes certain costs of software developed for internal use.  Capitalized costs primarily include payroll and payroll-related costs and facilities costs. During fiscal 2015, the Company capitalized $4.2 million of software development costs, respectively, which is included as property and equipment on the Company's consolidated balance sheet as of June 30, 2015.

[0001511737-15-000022:notes:140]
The Company computes depreciation or amortization using the straight line method over estimated useful lives, as follows:

[0001511737-15-000022:notes:141]
|  |  | Estimated Useful Life |
| Testing equipment |  | 3 to 5 years |
| Computer and other equipment |  | 3 to 5 years |
| Furniture and fixtures |  | 3 to 5 years |
| Software |  | up to 3 years |
| Leasehold improvements |  | shorter of lease term or useful life |

[0001511737-15-000022:notes:142]
Upon retirement or disposition, the asset cost and related accumulated depreciation are removed with any gain or loss recognized in the statement of operations. Expenditures for maintenance and repairs are charged to operations as incurred.


## us-gaap:PropertyPlantAndEquipmentScheduleOfSignificantAcquisitionsAndDisposalsTextBlock

[0001511737-15-000022:notes:143]
Property and equipment, net consisted of the following (in thousands):

[0001511737-15-000022:notes:144]
|  | June 30, |
|  | 2015 |  | 2014 |
| Testing equipment | $ | 4,816 |  |  | $ | 3,785 |  |
| Computer and other equipment | 4,458 |  |  | 1,019 |  |
| Tooling equipment | 4,073 |  |  | 2,898 |  |
| Furniture and fixtures | 1,239 |  |  | 973 |  |
| Leasehold improvements | 4,789 |  |  | 3,173 |  |
| Software | 3,268 |  |  | 521 |  |
| Software in development | 2,700 |  |  | — |  |
|  | 25,343 |  |  | 12,369 |  |
| Less: Accumulated depreciation | (9,741 | ) |  | (5,109 | ) |
|  | $ | 15,602 |  |  | $ | 7,260 |  |


## us-gaap:ReceivablesPolicyTextBlock

[0001511737-15-000022:notes:145]
Allowance for Doubtful Accounts

[0001511737-15-000022:notes:146]
The Company records an allowance for doubtful accounts for estimated probable losses on uncollectible accounts receivable. In estimating the allowance, management considers, among other factors, (i) the aging of the accounts receivable, (ii) the Company’s historical write offs, (iii) the credit worthiness of each distributor based on payment history and (iv) general economic conditions. In cases where the Company is aware of circumstances that may impair a specific distributor’s ability to meet its obligations to the Company, the Company records a specific allowance against amounts due from the distributor, and thereby reduces the net recognized receivable to the amounts it reasonably believes will be collected.


## us-gaap:ReconciliationOfRevenueFromSegmentsToConsolidatedTextBlock

[0001511737-15-000022:notes:147]
Revenues by product type were as follows (in thousands, except percentages):

[0001511737-15-000022:notes:148]
|  | Years Ended June 30, |
|  | 2015 |  | 2014 |  | 2013 |
| Service Provider Technology | $ | 418,021 |  |  | 70 | % |  | $ | 450,663 |  |  | 79 | % |  | $ | 285,390 |  |  | 89 | % |
| Enterprise Technology | 177,926 |  |  | 30 | % |  | 121,801 |  |  | 21 | % |  | 35,433 |  |  | 11 | % |
| Total revenues | $ | 595,947 |  |  | 100 | % |  | $ | 572,464 |  |  | 100 | % |  | $ | 320,823 |  |  | 100 | % |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001511737-15-000022:notes:149]
RELATED PARTY TRANSACTIONS AND CERTAIN OTHER TRANSACTIONS

[0001511737-15-000022:notes:150]
Aircraft Lease Agreement

[0001511737-15-000022:notes:151]
On November 13, 2013, the Company entered into an aircraft lease agreement (the "Aircraft Lease Agreement") with RJP Manageco LLC (the "Lessor"), a limited liability company owned by the Company’s Chief Executive Officer, Robert J. Pera. Pursuant to the Aircraft Lease Agreement, the Company may lease an aircraft owned by the Lessor for Company business purposes. Under the Aircraft Lease Agreement, the aircraft may be leased at a rate of $5,000 per flight hour. This hourly rate does not include the cost of flight crew or on-board services, which the Company will purchase from a third-party provider. The Company recognized a total of approximately $434,000 and $258,000 in expenses pursuant to the Aircraft Lease Agreement during fiscal 2015 and fiscal 2014, respectively. All expenses pursuant to the Aircraft Lease Agreement have been included in the Company's sales, general and administrative expenses in the Condensed Consolidated Statements of Operations.


## us-gaap:ResearchDevelopmentAndComputerSoftwarePolicyTextBlock

[0001511737-15-000022:notes:152]
Research and Development Costs

[0001511737-15-000022:notes:153]
Research and development expenses are expensed as incurred and consist primarily of payroll and payroll-related costs and facilities costs.  Research and development expenses associated with software development are expensed as incurred as our software is typically released to end customers immediately after technological feasibility has been established.


## us-gaap:RevenueFromExternalCustomersByGeographicAreasTableTextBlock

[0001511737-15-000022:notes:154]
|  | Years Ended June 30, |
|  | 2015 |  | 2014 |  | 2013 |
| North America(1) | $ | 197,693 |  |  | 33 | % |  | $ | 142,438 |  |  | 25 | % |  | $ | 84,820 |  |  | 26 | % |
| South America | 97,118 |  |  | 16 | % |  | 109,584 |  |  | 19 | % |  | 65,764 |  |  | 21 | % |
| Europe, the Middle East and Africa | 234,383 |  |  | 40 | % |  | 247,009 |  |  | 43 | % |  | 127,860 |  |  | 40 | % |
| Asia Pacific | 66,753 |  |  | 11 | % |  | 73,433 |  |  | 13 | % |  | 42,379 |  |  | 13 | % |
| Total revenues | $ | 595,947 |  |  | 100 | % |  | $ | 572,464 |  |  | 100 | % |  | $ | 320,823 |  |  | 100 | % |

[0001511737-15-000022:notes:155]
| (1) | Revenue for the United States was $187.3 million, $136.6 million and $80.6 million for fiscal 2015, 2014 and 2013, respectively. |


## us-gaap:RevenueRecognitionPolicyTextBlock

[0001511737-15-000022:notes:156]
Recognition of Revenues

[0001511737-15-000022:notes:157]
Revenues consist primarily of revenues from the sale of hardware and management tools, as well as the related implied post contract customer support (“PCS”). The Company recognizes revenues when persuasive evidence of an arrangement exists, delivery has occurred, the sales price is fixed or determinable and the collectability of the resulting receivable is reasonably assured. In cases where the Company lacks evidence that collectability of the resulting receivable is reasonably assured, it defers recognition of revenue until the receipt of cash.

[0001511737-15-000022:notes:158]
For the Company’s sales, evidence of the arrangement consists of an order from a customer. The Company considers delivery to have occurred once its products have been shipped and title and risk of loss have been transferred. For the Company’s sales, these criteria are met at the time the products are transferred to the customer. The Company’s arrangements with customers do not, in most cases, include provisions for cancellation, returns, inventory swaps or refunds that would significantly impact recognized revenues.

[0001511737-15-000022:notes:159]
The Company records amounts billed to distributors for shipping and handling costs as revenues. The Company classifies shipping and handling costs incurred by it as cost of revenues.

[0001511737-15-000022:notes:160]
Deposit payments received from distributors in advance of recognition of revenues are included in current liabilities on the Company’s balance sheet and are recognized as revenues when all the criteria for recognition of revenues are met.

[0001511737-15-000022:notes:161]
A portion of the Company's revenues related to PCS are deferred.  This relates to the Company’s multi-element arrangements, which generally include two deliverables. The first deliverable is the hardware and software essential to the functionality of the hardware device delivered at the time of sale. The second deliverable is the implied right to PCS included with the purchase of certain products. PCS is this right to receive, on a when and if available basis, future unspecified software upgrades and features relating to the product’s essential software as well as bug fixes, email and telephone support.

[0001511737-15-000022:notes:162]
The Company uses a hierarchy to determine the allocation of revenues to the deliverables. The hierarchy is as follows: (i) vendor-specific objective evidence of fair value (“VSOE”), (ii) third-party evidence of selling price (“TPE”), and (iii) best estimate of the selling price (“BESP”).

[0001511737-15-000022:notes:163]
| (i) | VSOE generally exists only when a company sells the deliverable separately and is the price actually charged by the company for that deliverable. Generally the Company does not sell the deliverables separately and, as such, does not have VSOE. |

[0001511737-15-000022:notes:164]
| (ii) | TPE can be substantiated by determining the price that other parties sell similar or substantially similar offerings. The Company does not believe that there is accessible TPE evidence for similar deliverables. |

[0001511737-15-000022:notes:165]
| (iii) | BESP reflects the Company’s best estimates of what the selling prices of elements would be if they were sold regularly on a stand-alone basis. The Company believes that BESP is the most appropriate methodology for determining the allocation of revenue among the multiple elements. |

[0001511737-15-000022:notes:166]
The Company allocates revenues between these two deliverables using the relative selling price method which is based on the estimated selling price for all deliverables. Revenues allocated to the delivered hardware and the related essential software are recognized at the time of sale provided the other conditions for recognition of revenues have been met. Revenues allocated to the PCS are deferred and recognized on a straight-line basis over the estimated life of each of these devices, which currently is two years.  If the estimated life of the hardware product should change, the future rate of amortization of the revenues allocated to PCS would also change.  All cost of revenues for the delivered hardware and the related essential software, including estimated warranty costs, are recognized at the time of sale. Costs for research and development and sales and marketing are expensed as incurred. Costs for PCS are recognized as they are incurred.

[0001511737-15-000022:notes:167]
The Company’s process for determining BESP for deliverables involves multiple factors that may vary depending upon the unique facts and circumstances related to each deliverable. For PCS, the Company believes its network operators and service providers would be reluctant to pay for such services separately. This view is primarily based on the fact that unspecified upgrade rights do not obligate the Company to provide upgrades at a particular time or at all, and do not specify to network operators and service providers which upgrades or features will be delivered. The Company believes that the relatively low prices of its products and its network operators’ and service providers’ price sensitivity would add to their reluctance to pay for PCS. Therefore, the Company has concluded that if it were to sell PCS on a standalone basis, the selling price would be relatively low.

[0001511737-15-000022:notes:168]
Key factors considered by the Company in developing the BESP for PCS include reviewing the activities of specific employees engaged in support and software development to determine the amount of time that is allocated to the development of the undelivered elements, determining the cost of this development effort, and then adding an appropriate level of gross profit to these costs.


## us-gaap:ScheduleOfAccruedLiabilitiesTableTextBlock

[0001511737-15-000022:notes:169]
Accrued liabilities consisted of the following (in thousands):

[0001511737-15-000022:notes:170]
|  | June 30, |
|  | 2015 |  | 2014 |
| Accrued compensation and benefits | $ | 2,142 |  |  | $ | 3,432 |  |
| Warranty accrual | 2,750 |  |  | 2,850 |  |
| Deferred revenue - short term | 2,538 |  |  | 4,218 |  |
| Customer deposits | 63 |  |  | 1,835 |  |
| Reserve for sales returns | 1,227 |  |  | — |  |
| Other accruals | 6,450 |  |  | 3,548 |  |
|  | $ | 15,170 |  |  | $ | 15,883 |  |


## us-gaap:ScheduleOfCreditLossesForFinancingReceivablesCurrentTableTextBlock

[0001511737-15-000022:notes:171]
The allowance for doubtful accounts activity was as follows (in thousands):

[0001511737-15-000022:notes:172]
|  |  | Years Ended June 30, |
|  |  | 2015 |  | 2014 |  | 2013 |
| Beginning balance |  | $ | 1,395 |  |  | $ | 2,200 |  |  | $ | 1,266 |  |
| Charged to (released from) expenses |  | 106 |  |  | (658 | ) |  | 1,096 |  |
| Bad debt write-offs |  | (430 | ) |  | (147 | ) |  | (162 | ) |
| Ending Balance |  | $ | 1,071 |  |  | $ | 1,395 |  |  | $ | 2,200 |  |


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0001511737-15-000022:notes:173]
Inventories consisted of the following (in thousands):

[0001511737-15-000022:notes:174]
|  | June 30, |
|  | 2015 |  | 2014 |
| Finished goods | $ | 39,986 |  |  | $ | 49,901 |  |
| Raw materials | 3,445 |  |  | 1,168 |  |
| Provision for inventory obsolescence | (6,400 | ) |  | (4,720 | ) |
|  | $ | 37,031 |  |  | $ | 46,349 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001511737-15-000022:notes:175]
SEGMENT INFORMATION, REVENUES BY GEOGRAPHY AND SIGNIFICANT CUSTOMERS

[0001511737-15-000022:notes:176]
Management has determined that the Company operates as one reportable and operating segment as the Company's Chief Executive Officer, who is the Company's chief operating decision maker, does not make decisions about resources to be allocated or assess performance on a segment basis.  Furthermore, the Company does not organize or report its costs on a segment basis.

[0001511737-15-000022:notes:177]
Revenue

[0001511737-15-000022:notes:178]
Revenues by geography based on customer's ship-to destinations were as follows (in thousands, except percentages):


## us-gaap:SegmentReportingPolicyPolicyTextBlock

[0001511737-15-000022:notes:179]
Segments

[0001511737-15-000022:notes:180]
Management has determined that it operates as one reportable and operating segment as the Company's Chief Executive Officer, who is the Company's chief operating decision maker, does not make decisions about resources to be allocated or assess performance on a segment basis.  Furthermore, the Company does not organize or report its costs on a segment basis.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001511737-15-000022:notes:181]
SUMMARY OF SIGNIFICANT ACCOUNTING POLICIES

[0001511737-15-000022:notes:182]
Use of Accounting Estimates

[0001511737-15-000022:notes:183]
The preparation of financial statements in conformity with GAAP requires management to make estimates and judgments that affect the reported amounts of assets and liabilities and the disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenues and expenses during the reporting period. On an ongoing basis, the Company evaluates these estimates, including those related to allowance for doubtful accounts, inventory valuation, vendor deposits, warranty costs, stock-based compensation and income taxes, among others. The Company bases estimates on historical experience and on various other assumptions that are believed to be reasonable under the circumstances. Actual results may differ materially from these estimates.

[0001511737-15-000022:notes:184]
Management has determined that it operates as one reportable and operating segment as the Company's Chief Executive Officer, who is the Company's chief operating decision maker, does not make decisions about resources to be allocated or assess performance on a segment basis.  Furthermore, the Company does not organize or report its costs on a segment basis. See Note 12.

[0001511737-15-000022:notes:185]
Key factors considered by the Company in developing the BESP for PCS include reviewing the activities of specific employees engaged in support and software development to determine the amount of time that is allocated to the development of the undelivered elements, determining the cost of this development effort, and then adding an appropriate level of gross profit to these costs.  As of June 30, 2015 and 2014, the Company had deferred revenues of $3.5 million and $2.8 million, respectively, related to these obligations.

[0001511737-15-000022:notes:186]
Concentration of Risk

[0001511737-15-000022:notes:187]
Financial instruments that potentially subject the Company to concentrations of credit risk consist of cash and cash equivalents and accounts receivable. The Company limits its exposure by primarily placing its cash in interest-bearing deposit accounts with high credit quality financial institutions.

[0001511737-15-000022:notes:188]
The Company derives its accounts receivable from revenues earned from customers located worldwide. The Company bases credit decisions primarily upon a customer’s past credit history. The Company’s standard credit terms are net 30 to 60 days.

[0001511737-15-000022:notes:189]
The Company subcontracts with other companies to manufacture most of its products. The Company relies on the ability of these contract manufacturers to produce the products sold to its distributors.  A significant portion of the Company’s products are manufactured by a few contract manufacturers.

[0001511737-15-000022:notes:190]
Deferred Cost of Revenues

[0001511737-15-000022:notes:191]
Deferred cost of revenues consist of the cost of product shipped to distributors for which the rights and obligations of ownership have passed to the distributor but revenues have not yet been recognized primarily because the collectability criterion for revenue recognition has not been fulfilled. The Company classifies these amounts as deferred cost of revenues. All deferred costs of revenues are stated at cost. The Company periodically assesses the recoverability of deferred cost of revenues and writes down the deferred cost of revenues balances to establish a new cost basis when recovery of deferred cost of revenues is not reasonably assured. The Company evaluates recoverability based on various factors including the length of time the product has been held at the distributor’s site and the financial viability of the distributor.

[0001511737-15-000022:notes:192]
Product Warranties

[0001511737-15-000022:notes:193]
The Company offers warranties on certain products, generally for a period of one year, and records a liability for the estimated future costs associated with potential warranty claims. The warranty costs are reflected in the Company’s consolidated statement of operations and comprehensive income within cost of revenues. The warranties are typically in effect for 12 months from the distributor’s purchase date of the product. The Company’s estimate of future warranty costs is largely based on historical experience factors including product failure rates, material usage, and service delivery cost incurred in correcting product failures. In certain circumstances, the Company may have recourse from its contract manufacturers for replacement cost of defective products, which it also factors into its warranty liability assessment.

[0001511737-15-000022:notes:194]
Fair Value of Financial Instruments

[0001511737-15-000022:notes:195]
The carrying value of the Company’s cash equivalents, accounts receivable, accounts payable and other current liabilities approximate fair value due to their short maturities.

[0001511737-15-000022:notes:196]
Pursuant to the accounting guidance for fair value measurements and its subsequent updates, fair value is defined as the price that would be received from selling an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date. As such, fair value is a market-based measurement that should be determined based on assumptions that market participants would use in pricing an asset or liability. The accounting guidance establishes a three-tier fair value hierarchy that requires the Company to use observable market data, when available, and to minimize the use of unobservable inputs when determining fair value. The fair value hierarchy prioritizes the inputs into three levels that may be used in measuring fair value as follows:

[0001511737-15-000022:notes:197]
Level 1—observable inputs which include quoted prices in active markets for identical assets of liabilities.

[0001511737-15-000022:notes:198]
Level 2—inputs which include observable inputs other than Level 1, such as quoted prices for similar assets or liabilities, quoted prices for identical or similar assets or liabilities in markets that are not active, or other inputs that are observable or can be corroborated by observable market data for substantially the full term of the asset or liability.

[0001511737-15-000022:notes:199]
Level 3—inputs which include unobservable inputs that are supported by little or no market activity and that are significant to the fair value of the underlying asset or liability. Level 3 assets and liabilities include those whose fair value measurements are determined using pricing models, discounted cash flow methodologies or similar valuation techniques, as well as significant management judgment or estimation.

[0001511737-15-000022:notes:200]
The Company evaluates its long lived assets including property and equipment for impairment whenever events or changes in circumstances indicate that the carrying value of these assets may not be recoverable. An impairment loss is recognized when the net book value of such assets exceeds the estimated future undiscounted cash flows attributable to the assets or asset group. If impairment is indicated, the asset is written down to its estimated fair value. The Company did not recognize any significant impairment losses for fiscal 2015, 2014 and 2013.

[0001511737-15-000022:notes:201]
Intangible Assets

[0001511737-15-000022:notes:202]
The Company’s intangible assets consist primarily of legal costs associated with application for and registration of the Company’s trademarks. The Company amortizes all definite-lived intangible assets that are subject to amortization over the estimated useful life based on economic benefit, which is generally 5 years.  All patent filing and defense costs are expensed as incurred, however to date these costs have not been significant.

[0001511737-15-000022:notes:203]
Advertising Costs

[0001511737-15-000022:notes:204]
The Company expenses all advertising costs as incurred.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001511737-15-000022:notes:205]
COMMON STOCK AND TREASURY STOCK

[0001511737-15-000022:notes:206]
As of June 30, 2015 and 2014, the authorized capital of the Company included 500,000,000 shares of common stock. As of June 30, 2015 and 2014, 87,413,777  and 88,179,448 shares of common stock were outstanding, respectively.

[0001511737-15-000022:notes:207]
Treasury Stock Retirement

[0001511737-15-000022:notes:208]
In February 2015, we retired 44,768,739 shares of the Company's treasury stock.  These retired shares are now included in the Company’s pool of authorized but unissued shares. The retired stock had a carrying value of $138.9 million. The Company’s policy upon the formal retirement of treasury stock is to reflect the excess over par value as a deduction from Additional Paid-in Capital until the balance is reduced to zero, then the Company records any additional excess directly to retained earnings.

[0001511737-15-000022:notes:209]
Common Stock Repurchases

[0001511737-15-000022:notes:210]
On May 29, 2014, the Board of Directors authorized the Company to repurchase up to an additional $75.0 million of its common stock. All common stock repurchased by the Company is immediately retired, and is recorded consistent with the treasury stock policy discussed above.  The share repurchase program commenced on June 2, 2014. The share repurchase program has been funded from existing cash on hand.  During fiscal 2015, the company repurchased 1,195,497 shares of its common stock at an average price per share of $29.02 for an aggregate amount of $34.7 million.  In December 2014, the Company repurchased 529,779 shares of its common stock at an average price per share of $28.29 for an aggregate amount of $15.0 million.  During May 2015, the Company repurchased 665,718 shares of its common stock at an average price per share of $29.59 for an aggregate amount of $19.7 million.  The share repurchase program was terminated on June 8, 2015.

[0001511737-15-000022:notes:211]
Effective August 7, 2015, the Board of Directors of the Company approved a $100 million stock repurchase program. Under the new stock repurchase program, the Company may repurchase up to $100 million of its common stock. The plan expires on June 30, 2016.

[0001511737-15-000022:notes:212]
Dividend Distribution

[0001511737-15-000022:notes:213]
On September 30, 2014, the Company announced that its Board of Directors had approved an annual dividend.  The Company declared the dividend of $0.17 per share on September 30, 2014.  The aggregate amount of $15.0 million was paid on October 28, 2014 to stockholders of record on October 17, 2014.  The Company currently has no plans to pay a cash dividend at this time or at any time in the foreseeable future.

[0001511737-15-000022:notes:214]
Special Dividend

[0001511737-15-000022:notes:215]
On December 14, 2012, the Board of Directors authorized a special cash dividend of $0.18 per share for each share of common stock outstanding on December 24, 2012.  The aggregate dividend payment of $15.7 million was paid on December 28, 2012 to stockholders of record on December 24, 2012.  The dividend payment was funded using proceeds from the Loan Agreement as discussed in Note 7.

[0001511737-15-000022:notes:216]
Common Stock Offering


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001511737-15-000022:notes:217]
BALANCE SHEET COMPONENTS

[0001511737-15-000022:notes:218]
Inventories

[0001511737-15-000022:notes:219]
Prepaid Expenses and Other Current Assets

[0001511737-15-000022:notes:220]
Property and Equipment, Net

[0001511737-15-000022:notes:221]
Depreciation expense was $4.7 million, $2.6 million and $1.8 million in fiscal 2015, 2014 and 2013, respectively.

[0001511737-15-000022:notes:222]
Other Current Liabilities


## us-gaap:UnusualOrInfrequentItemsDisclosureTextBlock

[0001511737-15-000022:notes:223]
BUSINESS EMAIL COMPROMISE FRAUD LOSS

[0001511737-15-000022:notes:224]
In June 2015, the Company determined that it was the victim of criminal fraud known to law enforcement authorities as business e-mail compromise fraud which involved employee impersonation and fraudulent requests targeting our finance department.  The fraud resulted in transfers of funds aggregating $46.7 million held by a Company subsidiary incorporated in Hong Kong to other overseas accounts held by third parties.  To date, the Company has recovered $8.1 million.  As a result, the Company recorded a charge of $39.1 million in the fourth quarter of 2015, including additional expenses consisting of professional service fees associated with the fraud loss.

[0001511737-15-000022:notes:225]
An additional $6.8 million of the amounts transferred are currently subject to legal injunction and reasonably expected to be recovered by the Company in due course. The Company is continuing to pursue the recovery of the remaining $31.8 million and is cooperating with U.S. federal and numerous overseas law enforcement authorities who are actively pursuing a multi-agency criminal investigation.
