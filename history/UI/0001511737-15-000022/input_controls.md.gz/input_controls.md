# UI 10-K controls and the auditor's report


## auditors_report

10-K auditors_report: 2 candidate headings, none whose body matches 'critical audit matter'.


## item_9a

[0001511737-15-000022:item_9a:1]
Item 9A. Controls and Procedures

[0001511737-15-000022:item_9a:2]
Evaluation of Disclosure Controls and Procedures

[0001511737-15-000022:item_9a:3]
Management, with the participation of the Company’s Chief Executive Officer and Interim Chief Accounting Officer, evaluated the effectiveness of our disclosure controls and procedures as of June 30, 2015. The term “disclosure controls and procedures,” as defined in Rules 13a-15(e) and 15d-15(e) under the Securities Exchange Act of 1934, as amended (the “Exchange Act”), means controls and other procedures of a company that are designed to ensure that information required to be disclosed by a company in the reports that it files or submits under the Exchange Act is recorded, processed, summarized and reported, within the time periods specified in the SEC’s rules and forms.  Disclosure controls and procedures include, without limitation, controls and procedures designed to ensure that information required to be disclosed by a company in the reports that it files or submits under the Exchange Act is accumulated and communicated to the company’s management, including its principal executive and principal financial officers, as appropriate to allow timely decisions regarding required disclosure. Management recognizes that any controls and procedures, no matter how well designed and operated, can provide only reasonable assurance of achieving their objectives.  Based on the evaluation of our disclosure controls and procedures as of June 30, 2015, our Chief Executive Officer and Interim Chief Accounting Officer concluded that, as of such date, as a result of the material weaknesses in internal control over financial reporting that are described below in Management's Report on Internal Control Over Financial Reporting, our disclosure controls and procedures were not effective.

[0001511737-15-000022:item_9a:4]
Management’s Report on Internal Control over Financial Reporting

[0001511737-15-000022:item_9a:5]
Management is responsible for establishing and maintaining adequate internal control over financial reporting, as such term is defined in Exchange Act Rules 13a-15(f) and 15d-15(f). A company’s internal control over financial reporting is a process designed by, or under the supervision of, its Chief Executive Officer and Chief Accounting Officer, and effected by such company's board of directors, management and other personnel to provide reasonable assurance regarding the reliability of financial reporting and the preparation of financial statements for external purposes in accordance with generally accepted accounting principles and includes those policies and procedures that:

[0001511737-15-000022:item_9a:6]
| (i) | pertain to the maintenance of records that, in reasonable detail, accurately and fairly reflect the transactions and dispositions of the assets of the company; |

[0001511737-15-000022:item_9a:7]
| (ii) | provide reasonable assurance that transactions are recorded as necessary to permit preparation of financial statements in accordance with generally accepted accounting principles, and that receipts and expenditures of the company are being made only in accordance with authorizations of management and directors of the company; and |

[0001511737-15-000022:item_9a:8]
| (iii) | provide reasonable assurance regarding prevention or timely detection of unauthorized acquisition, use, or disposition of the company’s assets that could have a material effect on the financial statements. |

[0001511737-15-000022:item_9a:9]
Because of its inherent limitations, internal control over financial reporting may not prevent or detect misstatements. Also, projections of any evaluation of effectiveness to future periods are subject to the risk that controls may become inadequate because of changes in conditions, or that the degree of compliance with the policies or procedures may deteriorate. A material weakness is a deficiency, or a combination of deficiencies, in internal control over financial reporting, such that there is a reasonable possibility that a material misstatement of a company's annual or interim financial statements will not be prevented or detected on a timely basis.

[0001511737-15-000022:item_9a:10]
Management, with the participation of our Chief Executive Officer and Interim Chief Accounting Officer, has conducted an evaluation of the effectiveness of our internal control over financial reporting as of June 30, 2015, based on the framework set forth in Internal Control-Integrated Framework (2013) issued by the Committee of Sponsoring Organizations of the Treadway Commission (COSO).  Based on this assessment, management has concluded that the Company did not maintain effective internal control over financial reporting as of June 30, 2015 due to the material weaknesses described below.

[0001511737-15-000022:item_9a:11]
Material Weaknesses in Internal Control over Financial Reporting

[0001511737-15-000022:item_9a:12]
Management has determined that the Company did not maintain an effective control environment, attributable to a lack of sufficient, competent personnel necessary for effective financial reporting.  This resulted in the lack of comprehensive and up-to-date accounting policies and procedures, skepticism on the part of key accounting personnel, internal control training, leadership and adequate communication of roles and responsibilities.  Growth in the complexity of the business in fiscal year

[0001511737-15-000022:item_9a:13]
48

[0001511737-15-000022:item_9a:14]
2015 without commensurate growth in the capabilities of the finance and accounting organization contributed to this deficiency.

[0001511737-15-000022:item_9a:15]
The Company’s failure to maintain an effective control environment contributed to a second deficiency in the form of ineffectively designed and maintained controls required for safeguarding of the Company’s funds and timely detection of improper transactions in the general ledger.  Specifically, the Company’s disbursement authorization policies were not updated timely for changes in personnel and positions, nor were authorization requirements clearly stated, including those for non-routine transactions.

[0001511737-15-000022:item_9a:16]
The Company’s failure to maintain an effective control environment also contributed to a third deficiency in the form of ineffectively designed and maintained controls over user access and transaction privileges to modify and post entries to the general ledger and subsidiary ledgers.  In particular, the scope of user access and transaction privileges to the general ledger and subsidiary ledgers is not sufficiently restricted to provide reasonable assurance of effective process and review controls over postings to the general ledger. Additionally, recent general ledger changes were completed without due consideration of collateral impacts on segregation of duties controls.

[0001511737-15-000022:item_9a:17]
These control deficiencies could result in misstatements of accounts or disclosures that would each result in a material misstatement of the interim or consolidated financial statements that would not be prevented or detected and, therefore, management has determined that these control deficiencies constitute material weaknesses. However, management has determined that the foregoing material weaknesses did not result in a material misstatement in the consolidated financial statements as of June 30, 2015.  Management has determined that the first two material weaknesses resulted in the Company’s inability to prevent and timely detect the business e-mail compromise fraud discussed in Note 14 that caused a material misappropriation of Company assets. In light of these material weaknesses, the Company’s Chief Executive Officer and Interim Chief Accounting Officer concluded that the Company did not maintain effective internal control over financial reporting as of June 30, 2015.

[0001511737-15-000022:item_9a:18]
The effectiveness of our internal control over financial reporting as of June 30, 2015 has been audited by PricewaterhouseCoopers LLP, an independent registered public accounting firm, as stated in their report which appears herein.

[0001511737-15-000022:item_9a:19]
Changes in Internal Control Over Financial Reporting

[0001511737-15-000022:item_9a:20]
Since June 30, 2015, we have begun the implementation of the remedial measures described below. However, there were no changes in our internal control over financial reporting that occurred during the quarter ended June 30, 2015 that have materially affected, or are reasonably likely to materially affect, our internal control over financial reporting.

[0001511737-15-000022:item_9a:21]
Remediation Plans and Other Information

[0001511737-15-000022:item_9a:22]
Management has taken immediate action to begin remediating the material weaknesses identified. While certain remedial actions have been completed, we continue to actively plan for and implement additional control procedures. These remediation efforts, outlined below, are intended to further address the identified material weaknesses.

[0001511737-15-000022:item_9a:23]
Since identifying the material weaknesses in internal control over financial reporting, the Company has made changes to management and engaged an outside firm to perform an investigation of the business e-mail compromise fraud that the material weaknesses in internal control over financial reporting failed to prevent or detect.

[0001511737-15-000022:item_9a:24]
To remediate the material weaknesses, management has or intends to implement the following measures:

[0001511737-15-000022:item_9a:25]
| • | The Company entered into an agreement for advisory and interim management services with FTI Consulting, Inc., to provide an Interim Chief Accounting Officer and other resources; |

[0001511737-15-000022:item_9a:26]
| • | The Company has accepted the resignation of the employee serving as Chief Accounting Officer at the time of the BEC fraud loss; |

[0001511737-15-000022:item_9a:27]
| • | The Company is in the process of further strengthening the finance organization by adding additional qualified and experienced personnel; |

[0001511737-15-000022:item_9a:28]
| • | The Company is in the process of improving existing controls and implementing additional procedures and controls including, but not limited to, updating its accounting policies and procedures, clarifying roles and responsibilities, updating and clarifying disbursement authorities, and providing training on required supporting documentation; and |

[0001511737-15-000022:item_9a:29]
| • | The Company is reviewing user access and transaction privileges to general ledger and interfaced systems and will make changes as appropriate and will also improve controls to provide reasonable assurance future system changes consider impacts to segregation of duties. |

[0001511737-15-000022:item_9a:30]
Remediation of the material weaknesses in internal controls is among management’s highest priorities. Management will periodically assess the progress and sufficiency of the ongoing initiatives and make adjustments as and when necessary. Management understands that improvement and maintenance of internal controls is a continuing responsibility.

[0001511737-15-000022:item_9a:31]
49
