# UI 8-K — 0001571049-15-006288 filed 2015-08-06

## item codes, every 8-K on or before 2015-08-21

- 2015-08-06 0001571049-15-006288 — 2.02, 5.02, 8.01, 9.01
- 2015-05-07 0001511737-15-000016 — 2.02, 9.01
- 2015-04-23 0001415889-15-001433 — 2.02, 5.02, 9.01
- 2015-03-06 0001415889-15-000787 — 1.01, 1.02, 2.03, 9.01
- 2015-02-05 0001511737-15-000008 — 2.02, 9.01
- 2014-12-18 0001193125-14-446627 — 5.07
- 2014-11-06 0001511737-14-000029 — 2.02, 9.01
- 2014-09-30 0001193125-14-359060 — 7.01, 9.01
- 2014-08-07 0001511737-14-000021 — 2.02, 9.01
- 2014-05-08 0001511737-14-000016 — 2.02, 9.01
- 2014-04-17 0001193125-14-146710 — 7.01
- 2014-03-06 0001193125-14-084883 — 8.01
- 2014-02-06 0001511737-14-000005 — 2.02, 9.01
- 2013-12-16 0001193125-13-474388 — 5.07
- 2013-11-22 0001193125-13-451511 — 5.02
- 2013-11-07 0001511737-13-000018 — 2.02, 9.01
- 2013-10-28 0001193125-13-413414 — 5.02, 9.01
- 2013-10-18 0001193125-13-404111 — 5.02, 9.01
- 2013-08-08 0001511737-13-000009 — 2.02, 9.01
- 2013-05-09 0001511737-13-000004 — 2.02
- 2013-03-25 0001193125-13-124353 — 5.07
- 2013-03-08 0001193125-13-098334 — 5.02, 9.01
- 2013-02-07 0001193125-13-043701 — 2.02, 9.01
- 2012-12-28 0001193125-12-518487 — 1.01
- 2012-12-17 0001193125-12-503742 — 7.01, 9.01
- 2012-12-13 0001193125-12-501894 — 5.02
- 2012-11-16 0001193125-12-474083 — 5.02
- 2012-11-13 0001193125-12-467376 — 5.02
- 2012-11-08 0001193125-12-460665 — 2.02, 9.01
- 2012-10-10 0001193125-12-420015 — 5.02, 9.01
- 2012-08-13 0001193125-12-352624 — 1.01, 2.03, 9.01
- 2012-08-09 0001193125-12-347776 — 1.01, 9.01
- 2012-08-09 0001193125-12-347732 — 2.02, 9.01
- 2012-05-01 0001193125-12-201012 — 2.02, 9.01
- 2012-03-30 0001193125-12-144074 — 5.02
- 2012-03-27 0001193125-12-134395 — 5.02, 9.01
- 2012-03-22 0001193125-12-127536 — 5.02
- 2012-01-31 0001193125-12-032079 — 2.02, 9.01
- 2011-12-27 0001193125-11-353002 — 1.01, 9.01
- 2011-12-06 0001193125-11-332192 — 5.02
- 2011-11-10 0001193125-11-306969 — 2.02, 9.01

## late-filing notifications on or before 2015-08-21

- none on or before 2015-08-21

## item 2.02 — earnings release, exhibit 99.1

[0001571049-15-006288:8k_2_02:1]
EX-99.1
2
t1501817_ex99-1.htm
EXHIBIT 99.1

[0001571049-15-006288:8k_2_02:2]
Exhibit 99.1

[0001571049-15-006288:8k_2_02:3]
UBIQUITI NETWORKS REPORTS FOURTH QUARTER
FISCAL 2015 FINANCIAL RESULTS

[0001571049-15-006288:8k_2_02:4]
~ Achieves Solid
Revenue and Earnings ~

[0001571049-15-006288:8k_2_02:5]
~ Non-GAAP Diluted EPS of $0.50 Per
Share ~

[0001571049-15-006288:8k_2_02:6]
SAN JOSE, Calif. – Aug. 6, 2015 - Ubiquiti Networks,
Inc. (NASDAQ:UBNT) (“Ubiquiti”) today announced results for the fourth fiscal quarter of 2015, ended June 30,
2015.

[0001571049-15-006288:8k_2_02:7]
Fourth Quarter Financial Summary

[0001571049-15-006288:8k_2_02:8]
|  | • | Revenues of $145.3 million |

[0001571049-15-006288:8k_2_02:9]
|  | • | GAAP gross profit of $66.1 million and non-GAAP gross profit of $66.3 million |

[0001571049-15-006288:8k_2_02:10]
|  | • | GAAP net income of $4.5 million and non-GAAP net income of $44.1 million |

[0001571049-15-006288:8k_2_02:11]
|  | • | GAAP diluted EPS of $0.05 and non-GAAP diluted EPS of $0.50 |

[0001571049-15-006288:8k_2_02:12]
|  | • | GAAP net income and diluted EPS include a $39.1 million business e-mail compromise ("BEC") fraud loss as disclosed in the Form 8-K filed on August 6, 2015 |

[0001571049-15-006288:8k_2_02:13]
Recent Financial Highlights

[0001571049-15-006288:8k_2_02:14]
|  | • | Enterprise Technology revenues increased over 26% year-over-year, fueled by UniFi® access points and other industry-leading products targeting the Enterprise market |

[0001571049-15-006288:8k_2_02:15]
|  | • | Initiated a new stock repurchase program, authorizing the Company to repurchase up to $100 million of its common stock as disclosed in the Form 8-K filed on August 6, 2015 |

[0001571049-15-006288:8k_2_02:16]
|  | • | Shipped in volume our new Enterprise products, including UniFi Video products, the UniFi Switch and our newly released EdgeRouterTM X and EdgeRouterTM X SFP |

[0001571049-15-006288:8k_2_02:17]
|  | • | Announced Ubiquiti NEXT Event to be held on October 12, 2015 at the Wynn, Las Vegas. At this event, Ubiquiti’s founder and Chief Executive Officer, Robert J. Pera, will discuss future of WISP products as well as some of Ubiquiti’s newer products |

[0001571049-15-006288:8k_2_02:18]
Recent Product Highlights

[0001571049-15-006288:8k_2_02:19]
|  | • | Announced Deep Packet Inspection technology for the mainstream market with the latest software release (v1.7.0) for our EdgeRouter™ Lite, EdgeRouter PoE, EdgeRouter, and EdgeRouter PRO routers |

[0001571049-15-006288:8k_2_02:20]
|  | • | Set a new world distance record for wireless broadband with our airFiber® 5X, a ruggedized outdoor Point-to-Point radio designed for the global unlicensed frequency bands |

[0001571049-15-006288:8k_2_02:21]
|  | • | Released airOS® 5.6.1, a new operating system for our airMAX® ac products that provides powerful features, including full Simple Network Management Protocol (SNMP) |

[0001571049-15-006288:8k_2_02:22]
|  | • | Announced the LiteBeam™ M5, a long-range, disruptively-priced, lightweight airMAX® CPE |

[0001571049-15-006288:8k_2_02:23]
|  | • | Announced an ISO series of our ac PowerBeam® series, an ideal solution for deployments requiring maximum performance and RF isolation. We expect the PowerBeam® ac ISO to expand deployments of our airMAX ac products |

[0001571049-15-006288:8k_2_02:24]
Financial Highlights ($, in millions, except per share data)

[0001571049-15-006288:8k_2_02:25]
| Income statement highlights |  | F4Q15 |  |  | F3Q15 |  |  | F4Q14 |  |
| Revenues |  |  | 145.3 |  |  |  | 147.5 |  |  |  | 156.0 |  |
| Service Provider Technology |  |  | 104.8 |  |  |  | 106.3 |  |  |  | 124.0 |  |
| Enterprise Technology |  |  | 40.5 |  |  |  | 41.2 |  |  |  | 32.0 |  |
| Cost of Revenues |  |  | 79.1 |  |  |  | 81.5 |  |  |  | 87.1 |  |
| Gross Profit |  |  | 66.1 |  |  |  | 66.0 |  |  |  | 68.9 |  |
| Gross Profit (%) |  |  | 45.5 | % |  |  | 44.7 | % |  |  | 44.1 | % |
| Total Operating Expenses |  |  | 58.8 |  |  |  | 20.7 |  |  |  | 16.1 |  |
| Income from Operations |  |  | 7.3 |  |  |  | 45.2 |  |  |  | 52.8 |  |
| GAAP Net Income |  |  | 4.5 |  |  |  | 41.1 |  |  |  | 49.4 |  |
| GAAP EPS (diluted) |  |  | 0.05 |  |  |  | 0.46 |  |  |  | 0.55 |  |
| Non-GAAP Net Income |  |  | 44.1 |  |  |  | 42.0 |  |  |  | 50.2 |  |
| Non-GAAP EPS (diluted) |  |  | 0.50 |  |  |  | 0.47 |  |  |  | 0.56 |  |

[0001571049-15-006288:8k_2_02:26]
Balance Sheet Highlights

[0001571049-15-006288:8k_2_02:27]
Total cash and cash equivalents as of June 30, 2015 were
$446.4 million, compared with $451.2 million as of March 31, 2015. The sequential decrease in cash and cash equivalents during
the fourth quarter of fiscal 2015 is primarily due to the following factors:

[0001571049-15-006288:8k_2_02:28]
|  | • | We repurchased $19.7 million of our common stock |

[0001571049-15-006288:8k_2_02:29]
|  | • | As disclosed in the Form 8-K filed on August 6, 2015, we lost $39.1 million in connection with a business e-mail compromise (“BEC”) fraud involving employee impersonation |

[0001571049-15-006288:8k_2_02:30]
Excluding the impact of the BEC fraud loss and related expenses,
our cash from operating activities for the fiscal fourth quarter would have been $57.3 million, a 56% increase sequentially. We
generated $18.2 million of cash from operating activities, which is net of the BEC fraud loss and related expenses.

[0001571049-15-006288:8k_2_02:31]
This quarter we saw days sales outstanding in accounts receivable
("DSO") of 41 days, compared with 43 days in the prior quarter, and 32 days in the fourth quarter of fiscal 2014.

[0001571049-15-006288:8k_2_02:32]
Business Outlook

[0001571049-15-006288:8k_2_02:33]
Based on recent business trends, Ubiquiti currently believes
the demand environment in its end markets supports the following forecast for the Company's first fiscal quarter ending September
30, 2015. The following are Ubiquiti’s financial performance estimates for the first quarter of fiscal 2016:

[0001571049-15-006288:8k_2_02:34]
|  | • | Revenues of between $145 million and $155 million |

[0001571049-15-006288:8k_2_02:35]
|  | • | GAAP diluted EPS of $0.46 - $0.51 |

[0001571049-15-006288:8k_2_02:36]
|  | • | Non-GAAP diluted EPS of $0.47 - $0.52 |

[0001571049-15-006288:8k_2_02:37]
Conference Call Information

[0001571049-15-006288:8k_2_02:38]
Ubiquiti Networks will host a Q&A-only call to discuss the
Company’s financial results at 2:00 p.m. Pacific Time today. Management’s prepared remarks can be found on the Investor
Relations section of the Ubiquiti Networks website, http://ir.ubnt.com/results.cfm.

[0001571049-15-006288:8k_2_02:39]
To listen to the Q&A call via telephone, dial (877) 291-1296
(U.S. toll-free) or (720) 259-9209 (International) to be connected to the call by an operator. Participants should dial in at least
10 minutes prior to the start of the call. Investors may also listen to a live webcast of the Q&A conference call by visiting
the Investor Relations section of the Ubiquiti Networks website at http://ir.ubnt.com.

[0001571049-15-006288:8k_2_02:40]
A recording of the Q&A call will be available approximately
two hours after the call concludes and will be accessible on the Investor Relations section of the Ubiquiti Networks website, http://ir.ubnt.com.

[0001571049-15-006288:8k_2_02:41]
About Ubiquiti Networks

[0001571049-15-006288:8k_2_02:42]
Ubiquiti Networks (NASDAQ: UBNT) is closing the digital divide
by building network communication platforms for everyone and everywhere. With over 28 million devices sold worldwide, Ubiquiti
is transforming under-networked enterprises and communities. Our leading edge platforms, airMAX®, UniFi®,
airFiber®, UniFi® Video, UniFi® VoIP, UniFi® Switch, mFi®
and EdgeMAX®, combine innovative technology, disruptive price-to-performance and the support of a global user community
to eliminate barriers to connectivity. For more information, join our community at http://www.ubnt.com.

[0001571049-15-006288:8k_2_02:43]
Ubiquiti, the Ubiquiti U logo, Ubiquiti Networks, UBNT, airMAX,
airFiber, airCRM, airOS, UniFi, mFi, EdgeMAX, EdgeRouter, LightBeam and PowerBeam are registered trademarks or trademarks of Ubiquiti
Networks, Inc. in the United States and other countries.

[0001571049-15-006288:8k_2_02:44]
The Ubiquiti Networks, Inc. logo is available at http://www.globenewswire.com/newsroom/prs/?pkgid=24865.

[0001571049-15-006288:8k_2_02:45]
Investor Relations Contact

[0001571049-15-006288:8k_2_02:46]
Anne Fazioli

[0001571049-15-006288:8k_2_02:47]
Ubiquiti Networks, Vice President of Investor Relations

[0001571049-15-006288:8k_2_02:48]
IR@ubnt.com

[0001571049-15-006288:8k_2_02:49]
Forward-looking statements are subject to certain risks and
uncertainties that could cause our actual future results to differ materially, or cause a material adverse impact on our results.
Potential risks and uncertainties include, but are not limited to, fluctuations in our operating results; varying demand for our
products due to the financial and

[0001571049-15-006288:8k_2_02:50]
operating condition of our distributors and their customers,
and distributors' inventory management practices; political and economic conditions and volatility affecting the stability of business
environments, economic growth, currency values, commodity prices and other factors that may influence the ultimate demand for our
products in particular geographies or globally; impact of counterfeiting and our ability to contain such impact; our reliance on
a limited number of distributors; inability of our contract manufacturers and suppliers to meet our demand; our dependence on Qualcomm
Atheros for chipsets without a short-term alternative; as we move into new markets competition from certain of our current or potential
competitors who may be more established in such markets; our ability to keep pace with technological and market developments; success
and timing of new product introductions by us and the performance of our products generally; our ability to effectively manage
the significant increase in our transactional sales volumes; we may become subject to warranty claims, product liability and product
recalls; that a substantial majority of our sales are into countries outside the United States and we are subject to numerous U.S.
export control and economic sanctions laws; costs related to responding to government inquiries related to regulatory compliance;
our reliance on the Ubiquiti Community; our reliance on certain key members of our management team, including our founder and chief
executive officer, Robert J. Pera; adverse tax-related matters such as tax audits, changes in our effective tax rate or new tax
legislative proposals; whether the final determination of our income tax liability may be materially different from our income
tax provisions; the impact of any intellectual property litigation and claims for indemnification; litigation related to U.S. Securities
laws; and economic and political conditions in the United States and abroad. We discuss these risks in greater detail under the
heading “Risk Factors” and elsewhere in our Annual Report on Form 10-K for the year ended June 30, 2014, and subsequent
filings filed with the U.S. Securities and Exchange Commission (the SEC), which are available at the SEC's website at www.sec.gov.
Copies may also be obtained by contacting the Ubiquiti Networks Investor Relations Department, by email at IR@ubnt.com or by visiting
the Investor Relations section of the Ubiquiti Networks website, http://ir.ubnt.com.

[0001571049-15-006288:8k_2_02:51]
Given these uncertainties, you should not place undue reliance
on these forward-looking statements. Also, forward-looking statements represent our management's beliefs and assumptions only as
of the date made. Except as required by law, Ubiquiti Networks undertakes no obligation to update information contained herein.
You should review our SEC filings carefully and with the understanding that our actual future results may be materially different
from what we expect.

[0001571049-15-006288:8k_2_02:52]
Use of Non-GAAP Financial Information

[0001571049-15-006288:8k_2_02:53]
To supplement our condensed consolidated financial results prepared
under generally accepted accounting principles, or GAAP, we use non-GAAP measures of net income and earnings per diluted share
that are adjusted to exclude certain costs, expenses and gains such as stock based compensation expense, purchase commitment termination
fee, loss as a result of a BEC fraud and the tax effects of these non-GAAP adjustments. Reconciliations of the adjustments to GAAP
results for the three and twelve months ended June 30, 2015 and 2014 are provided below. In addition, an explanation of the
ways in which management uses non-GAAP financial information to evaluate its business, the substance behind management's decision
to use this non-GAAP financial information, material limitations associated with the use of non-GAAP financial information, the
manner in which management compensates for those limitations, and the substantive reasons management believes that this non-GAAP
financial information provides useful information to investors is included under "About our Non-GAAP Net Income and Adjustments"
after the tables below.

[0001571049-15-006288:8k_2_02:54]
Ubiquiti Networks Inc.

[0001571049-15-006288:8k_2_02:55]
Condensed Consolidated Statement of Operations

[0001571049-15-006288:8k_2_02:56]
(In thousands, except per share data)

[0001571049-15-006288:8k_2_02:57]
(Unaudited)

[0001571049-15-006288:8k_2_02:58]
|  |  | Three Months Ended June 30, |  |  | Years Ended June 30, |  |
|  |  | 2015 |  |  | 2014 |  |  | 2015 |  |  | 2014(1) |  |
| Revenues |  | $ | 145,267 |  |  | $ | 156,007 |  |  | $ | 595,947 |  |  | $ | 572,464 |  |
| Cost of revenues |  |  | 79,129 |  |  |  | 87,146 |  |  |  | 333,760 |  |  |  | 318,997 |  |
| Gross profit |  |  | 66,138 |  |  |  | 68,861 |  |  |  | 262,187 |  |  |  | 253,467 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development |  |  | 14,672 |  |  |  | 10,155 |  |  |  | 54,565 |  |  |  | 33,962 |  |
| Sales, general and administrative |  |  | 5,039 |  |  |  | 5,912 |  |  |  | 21,607 |  |  |  | 23,560 |  |
| Business e-mail compromise ("BEC") fraud loss |  |  | 39,137 |  |  |  | — |  |  |  | 39,137 |  |  |  | — |  |
| Total operating expenses |  |  | 58,848 |  |  |  | 16,067 |  |  |  | 115,309 |  |  |  | 57,522 |  |
| Income from operations |  |  | 7,290 |  |  |  | 52,794 |  |  |  | 146,878 |  |  |  | 195,945 |  |
| Interest expense and other, net |  |  | (326 | ) |  |  | (556 | ) |  |  | (1,130 | ) |  |  | (1,334 | ) |
| Income before provision for income taxes |  |  | 6,964 |  |  |  | 52,238 |  |  |  | 145,748 |  |  |  | 194,611 |  |
| Provision for income taxes |  |  | 2,446 |  |  |  | 2,820 |  |  |  | 16,085 |  |  |  | 17,674 |  |
| Net income and comprehensive income |  | $ | 4,518 |  |  | $ | 49,418 |  |  | $ | 129,663 |  |  | $ | 176,937 |  |
| Net income per share of common stock: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.05 |  |  | $ | 0.56 |  |  | $ | 1.47 |  |  | $ | 2.02 |  |
| Diluted |  | $ | 0.05 |  |  | $ | 0.55 |  |  | $ | 1.45 |  |  | $ | 1.97 |  |
| Weighted average shares used in computing net income per share of common stock: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 87,685 |  |  |  | 88,122 |  |  |  | 88,008 |  |  |  | 87,772 |  |
| Diluted |  |  | 89,110 |  |  |  | 89,821 |  |  |  | 89,569 |  |  |  | 89,715 |  |

[0001571049-15-006288:8k_2_02:59]
Ubiquiti Networks Inc.

[0001571049-15-006288:8k_2_02:60]
Reconciliation of GAAP Net Income to Non-GAAP Net Income

[0001571049-15-006288:8k_2_02:61]
(In thousands, except per share data)

[0001571049-15-006288:8k_2_02:62]
(Unaudited)

[0001571049-15-006288:8k_2_02:63]
|  |  | Three Months Ended June 30, |  |  | Years Ended June 30, |  |
|  |  | 2015 |  |  | 2014 |  |  | 2015 |  |  | 2014 |  |
| Net income |  | $ | 4,518 |  |  | $ | 49,418 |  |  | $ | 129,663 |  |  | $ | 176,937 |  |
| Stock-based compensation: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of revenues |  |  | 161 |  |  |  | 145 |  |  |  | 601 |  |  |  | 590 |  |
| Research and development |  |  | 355 |  |  |  | 744 |  |  |  | 2,854 |  |  |  | 2,423 |  |
| Sales, general and administrative |  |  | 297 |  |  |  | 387 |  |  |  | 1,537 |  |  |  | 1,893 |  |
| Business e-mail compromise ("BEC") fraud loss |  |  | 39,137 |  |  |  | — |  |  |  | 39,137 |  |  |  | — |  |
| Purchase commitment termination fee |  |  | — |  |  |  | — |  |  |  | 5,500 |  |  |  | — |  |
| Gain on reversal of charge for an export compliance matter |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (1,121 | ) |
| Tax effect of non-GAAP adjustments |  |  | (325 | ) |  |  | (510 | ) |  |  | (2,656 | ) |  |  | (1,514 | ) |
| Non-GAAP net income |  | $ | 44,143 |  |  | $ | 50,184 |  |  | $ | 176,636 |  |  | $ | 179,208 |  |
| Non-GAAP diluted EPS |  | $ | 0.50 |  |  | $ | 0.56 |  |  | $ | 1.97 |  |  | $ | 2.00 |  |
| Weighted-average shares used in non-GAAP diluted EPS |  |  | 89,110 |  |  |  | 89,821 |  |  |  | 89,569 |  |  |  | 89,715 |  |

[0001571049-15-006288:8k_2_02:64]
|  | (1) | Derived from audited consolidated statements as of and for the year ended June 30, 2014. |

[0001571049-15-006288:8k_2_02:65]
Ubiquiti Networks Inc.

[0001571049-15-006288:8k_2_02:66]
Condensed Consolidated Balance Sheets

[0001571049-15-006288:8k_2_02:67]
(In thousands, except share amounts)

[0001571049-15-006288:8k_2_02:68]
(Unaudited)

[0001571049-15-006288:8k_2_02:69]
|  |  | June 30, |  |
|  |  | 2015 |  |  | 2014(1) |  |
| Assets |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 446,401 |  |  | $ | 347,097 |  |
| Accounts receivable, net |  |  | 66,104 |  |  |  | 54,871 |  |
| Inventories |  |  | 37,031 |  |  |  | 46,349 |  |
| Current deferred tax asset |  |  | 1,535 |  |  |  | 884 |  |
| Prepaid income taxes |  |  | 2,566 |  |  |  | 3,256 |  |
| Prepaid expenses and other current assets |  |  | 27,709 |  |  |  | 13,267 |  |
| Total current assets |  |  | 581,346 |  |  |  | 465,724 |  |
| Property and equipment, net |  |  | 15,602 |  |  |  | 7,260 |  |
| Long-term deferred tax asset |  |  | 1,515 |  |  |  | 1,255 |  |
| Other long–term assets |  |  | 2,109 |  |  |  | 1,912 |  |
| Total assets |  | $ | 600,572 |  |  | $ | 476,151 |  |
| Liabilities and Stockholders’ Equity |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Accounts payable |  | $ | 43,856 |  |  | $ | 33,933 |  |
| Income taxes payable |  |  | 1,108 |  |  |  | 2,499 |  |
| Debt - short-term |  |  | 10,000 |  |  |  | — |  |
| Other current liabilities |  |  | 15,170 |  |  |  | 15,883 |  |
| Total current liabilities |  |  | 70,134 |  |  |  | 52,315 |  |
| Long-term taxes payable |  |  | 19,810 |  |  |  | 15,346 |  |
| Debt - long-term |  |  | 87,500 |  |  |  | 72,254 |  |
| Deferred revenues - long-term |  |  | 974 |  |  |  | 972 |  |
| Total liabilities |  |  | 178,418 |  |  |  | 140,887 |  |
| Stockholders’ equity: |  |  |  |  |  |  |  |  |
| Common stock |  |  | 87 |  |  |  | 88 |  |
| Additional paid–in capital |  |  | — |  |  |  | 145,872 |  |
| Treasury stock |  |  | — |  |  |  | (123,864 | ) |
| Retained earnings |  |  | 422,067 |  |  |  | 313,168 |  |
| Total stockholders’ equity |  |  | 422,154 |  |  |  | 335,264 |  |
| Total liabilities and stockholders’ equity |  | $ | 600,572 |  |  | $ | 476,151 |  |

[0001571049-15-006288:8k_2_02:70]
|  | (1) | Derived from audited consolidated statements as of and for the year ended June 30, 2014. |

[0001571049-15-006288:8k_2_02:71]
Ubiquiti Networks Inc.

[0001571049-15-006288:8k_2_02:72]
Revenues by Product Type

[0001571049-15-006288:8k_2_02:73]
(In thousands)

[0001571049-15-006288:8k_2_02:74]
(Unaudited)

[0001571049-15-006288:8k_2_02:75]
|  |  | Three Months Ended June 30, |  |  | Years Ended June 30, |  |
|  |  | 2015 |  |  | 2014 |  |  | 2015 |  |  | 2014 |  |
| Service provider technology |  | $ | 104,788 |  |  | $ | 124,005 |  |  | $ | 418,021 |  |  | $ | 450,663 |  |
| Enterprise technology |  |  | 40,479 |  |  |  | 32,002 |  |  |  | 177,926 |  |  |  | 121,801 |  |
| Total revenues |  | $ | 145,267 |  |  | $ | 156,007 |  |  | $ | 595,947 |  |  | $ | 572,464 |  |

[0001571049-15-006288:8k_2_02:76]
Ubiquiti Networks Inc.

[0001571049-15-006288:8k_2_02:77]
Revenues by Geographical Area

[0001571049-15-006288:8k_2_02:78]
(In thousands)

[0001571049-15-006288:8k_2_02:79]
(Unaudited)

[0001571049-15-006288:8k_2_02:80]
|  |  | Three Months Ended June 30, |  |  | Years Ended June 30, |  |
|  |  | 2015 |  |  | 2014 |  |  | 2015 |  |  | 2014 |  |
| North America |  | $ | 44,293 |  |  | $ | 43,260 |  |  | $ | 197,693 |  |  | $ | 142,438 |  |
| South America |  |  | 25,876 |  |  |  | 35,757 |  |  |  | 97,118 |  |  |  | 109,584 |  |
| Europe, the Middle East and Africa |  |  | 56,909 |  |  |  | 57,418 |  |  |  | 234,383 |  |  |  | 247,009 |  |
| Asia Pacific |  |  | 18,189 |  |  |  | 19,572 |  |  |  | 66,753 |  |  |  | 73,433 |  |
| Total revenues |  | $ | 145,267 |  |  | $ | 156,007 |  |  | $ | 595,947 |  |  | $ | 572,464 |  |

[0001571049-15-006288:8k_2_02:81]
About our Non-GAAP Net Income and Adjustments

[0001571049-15-006288:8k_2_02:82]
Use of Non-GAAP Financial Information

[0001571049-15-006288:8k_2_02:83]
To supplement our condensed consolidated financial results prepared
under generally accepted accounting principles, or GAAP, we use non-GAAP measures of net income and earnings per diluted share
that are GAAP net income and GAAP earnings per diluted share adjusted to exclude certain costs, expenses and gains/losses.

[0001571049-15-006288:8k_2_02:84]
We believe that the presentation of non-GAAP net income and
non-GAAP earnings per diluted share provides important supplemental information regarding non-cash expenses, significant items
that we believe are important to understanding our financial, and business trends relating to our financial condition and results
of operations. Non-GAAP net income and non-GAAP earnings per diluted share are among the primary indicators used by management
as a basis for planning and forecasting future periods and by management and our board of directors to determine whether our operating
performance has met specified targets and thresholds. Management uses non-GAAP net income and non-GAAP earnings per diluted share
when evaluating operating performance because it believes that the exclusion of the items described below, for which the amounts
or timing may vary significantly depending upon the Company's activities and other factors, facilitates comparability of the Company's
operating performance from period to period. We have chosen to provide this information to investors so they can analyze our operating
results in the same way that management does and use this information in their assessment of our business and the valuation of
our Company.

[0001571049-15-006288:8k_2_02:85]
Use and Economic Substance of Non-GAAP Financial Measures
used by Ubiquiti Networks

[0001571049-15-006288:8k_2_02:86]
We compute non-GAAP net income and non-GAAP diluted earnings
per share by adjusting GAAP net income and GAAP earnings per diluted share to remove the impact of certain adjustments and the
tax effect of those adjustments. Items excluded from net income are:

[0001571049-15-006288:8k_2_02:87]
|  | • | Stock-based compensation expense |

[0001571049-15-006288:8k_2_02:88]
|  | • | Amounts relating to a purchase commitment termination fee |

[0001571049-15-006288:8k_2_02:89]
|  | • | Gain on reversal of charge for an export compliance matter |

[0001571049-15-006288:8k_2_02:90]
|  | • | Loss as a result of a BEC fraud |

[0001571049-15-006288:8k_2_02:91]
|  | • | Tax effect of non-GAAP adjustments, applying the principles of ASC 740 |

[0001571049-15-006288:8k_2_02:92]
Usefulness of Non-GAAP Financial Information to Investors

[0001571049-15-006288:8k_2_02:93]
These non-GAAP measures are not in accordance with, or an alternative
to, GAAP and may be materially different from other non-GAAP measures, including similarly titled non-GAAP measures used by other
companies. The presentation of this additional information should not be considered in isolation from, as a substitute for, or
superior to, net income or earnings per diluted share prepared in accordance with GAAP. Non-GAAP financial measures have limitations
in that they do not reflect certain items that may have a material impact upon our reported financial results.

[0001571049-15-006288:8k_2_02:94]
For more information on the non-GAAP adjustments, please see
the table captioned “Reconciliation of GAAP Net Income to Non-GAAP Net Income” included in this press release.

## item 5.02 — body, verbatim

[0001571049-15-006288:8k_body:1]
Item 5.02

[0001571049-15-006288:8k_body:2]
Departure of Directors or Certain Officers; Election
of Directors; Appointment of Certain Officers; Compensatory Arrangements of Certain Officers.

[0001571049-15-006288:8k_body:3]
On June 29, 2015, the Company entered into
an agreement for advisory and interim management services with FTI Consulting, Inc. (“FTI Consulting” or “FTI”).
In connection with this agreement, the Company appointed Mark C. Spragg as Interim Chief Accounting Officer effective August 4,
2015. FTI Consulting will receive a monthly fee of $185,000 for the advisory and interim management services provided by Mr. Spragg
and one additional consultant to the Company.

[0001571049-15-006288:8k_body:4]
Effective August 4, 2015 and in connection
with the appointment of Mr. Spragg, Mr. Rohit Chakravarthy will no longer serve as Chief Accounting Officer of the Company. Mr.
Chakravarthy’s duties as principal financial officer and principal accounting officer will be performed on an interim basis
by Mr. Spragg. On August 4, 2015, Mr. Chakravarthy informed the Company of his intention to resign from the Company effective August
14, 2015 and he will remain available to the Company in an advisory capacity to assist with the transition of his responsibilities
and other related matters. Mr. Chakravarthy’s resignation was not due to any disagreement with the Company regarding its
operations, financial reporting, policies or procedures.

[0001571049-15-006288:8k_body:5]
Mark C. Spragg, 54, has been a senior managing
director in the Telecommunications, Media & Technology practice of FTI Consulting since joining FTI in 2002. Prior to joining
FTI Mr. Spragg was a partner with a globally-recognized public accounting firm in their financial advisory services practice. Mr.
Spragg has more than 30 years of experience in the public accounting, private industry and consulting sectors, and is a certified
public accountant. He specializes in the telecommunications industry, including mobile wireless, satellite, subsea cable, and broadband.
Mr. Spragg’s services to the Company are billed by FTI Consulting. He will not be separately compensated by the Company for
his services as Interim Chief Accounting Officer.
