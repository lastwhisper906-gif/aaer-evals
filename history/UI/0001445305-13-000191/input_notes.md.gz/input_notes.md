# UI notes — 0001445305-13-000191


## us-gaap:BusinessDescriptionAndBasisOfPresentationTextBlock

[0001445305-13-000191:notes:1]
BUSINESS AND BASIS OF PRESENTATION

[0001445305-13-000191:notes:2]
Business— Ubiquiti Networks, Inc. was incorporated in the State of California in 2003 as Pera Networks, Inc.  In 2005 the Company changed its name to Ubiquiti Networks, Inc. and commenced its current operations. In June 2010, the Company was re-incorporated in Delaware.

[0001445305-13-000191:notes:3]
Ubiquiti Networks, Inc. and its wholly owned subsidiaries (collectively, “Ubiquiti” or the “Company”) is a product driven company that leverages innovative proprietary technologies to deliver networking solutions to both startup and established network operators and service providers.

[0001445305-13-000191:notes:4]
On October 13, 2011, the Company entered into an underwriting agreement for its initial public offering of common stock at $15.00 per share.  The Company's initial public offering closed on October 19, 2011. Immediately prior to the closing of the initial public offering, all outstanding shares of the Company’s preferred stock converted to common stock on a one for one basis.

[0001445305-13-000191:notes:5]
The Company operates on a fiscal year ending June 30. In this Quarterly Report, the fiscal year ended June 30, 2013 is referred to as “fiscal 2013” and the fiscal year ending June 30, 2012 is referred to as “fiscal 2012.”

[0001445305-13-000191:notes:6]
Basis of Presentation— The accompanying condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP”) related to interim financial statements based on applicable Securities and Exchange Commission (“SEC”) rules and regulations. Accordingly, they do not include all the information and footnotes required by U.S. GAAP for complete financial statements. This information reflects all adjustments, which are, in the opinion of the Company, of a normal and recurring nature and necessary to state fairly the statements of financial position, results of operations and cash flows for the dates and periods presented. The June 30, 2012 balance sheet was derived from the audited financial statements as of that date. All significant intercompany transactions and balances have been eliminated.

[0001445305-13-000191:notes:7]
These condensed consolidated financial statements should be read in conjunction with the Company’s audited consolidated financial statements for the fiscal year ended June 30, 2012 included in its Annual Report on Form 10-K, as filed on September 28, 2012 with the SEC (the “Annual Report”). The results of operations for the three and six months ended December 31, 2012 are not necessarily indicative of the results to be expected for any future periods.


## us-gaap:CashAndCashEquivalentsDisclosureTextBlock

[0001445305-13-000191:notes:8]
CASH AND CASH EQUIVALENTS

[0001445305-13-000191:notes:9]
Cash and cash equivalents consisted of the following (in thousands):

[0001445305-13-000191:notes:10]
|  | December 31, 2012 |  | June 30, 2012 |
| Cash | $ | 13,301 |  |  | $ | 13,832 |  |
| Money market funds | 135,000 |  |  | 108,228 |  |
|  | $ | 148,301 |  |  | $ | 122,060 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001445305-13-000191:notes:11]
COMMITMENTS AND CONTINGENCIES

[0001445305-13-000191:notes:12]
Operating Leases

[0001445305-13-000191:notes:13]
Certain facilities and equipment are leased under noncancelable operating leases. The Company generally pays taxes, insurance and maintenance costs on leased facilities and equipment. The Company leases office space in San Jose, California and other locations under various non-cancelable operating leases that expire at various dates through 2017.

[0001445305-13-000191:notes:14]
In December 2011, the Company entered into an agreement to lease approximately 64,512 square feet of office and research and development space located in San Jose, California, which the Company uses as its corporate headquarters. The lease term is from April 1, 2012, through  June 30, 2017. The lease has been categorized as an operating lease, and the total estimated rent expense to be recognized is $4.9 million.

[0001445305-13-000191:notes:15]
At December 31, 2012, future minimum annual payments under operating leases are as follows (in thousands):

[0001445305-13-000191:notes:16]
|  | 2013(remainder) |  | 2014 |  | 2015 |  | 2016 |  | 2017 |  | Thereafter |  | Total |
| Operating leases | $ | 750 |  |  | $ | 1,505 |  |  | $ | 1,465 |  |  | $ | 1,423 |  |  | $ | 1,117 |  |  | $ | 188 |  |  | $ | 6,448 |  |

[0001445305-13-000191:notes:17]
Purchase Commitments

[0001445305-13-000191:notes:18]
The Company subcontracts with other companies to manufacture its products. During the normal course of business, the Company’s contract manufacturers procure components based upon orders placed by the Company. If the Company cancels all or part of the orders, it may still be liable to the contract manufacturers for the cost of the components purchased by them to manufacture the Company’s products. The Company periodically reviews the potential liability and to date no significant accruals have been recorded. The Company’s consolidated financial position and results of operations could be negatively impacted if it were required to compensate the contract manufacturers for any liabilities incurred.

[0001445305-13-000191:notes:19]
Indemnification Obligations

[0001445305-13-000191:notes:20]
The Company enters into standard indemnification agreements with many of its business partners in the ordinary course of business. These agreements include provisions for indemnifying the business partner against any claim brought by a third party to the extent any such claim alleges that a Ubiquiti product infringes a patent, copyright or trademark, or violates any other proprietary rights of that third party. The maximum potential amount of future payments the Company could be required to make under these indemnification agreements is not estimable and the Company has not incurred any material costs to defend lawsuits or settle claims related to these indemnification agreements to date.

[0001445305-13-000191:notes:21]
Legal Matters

[0001445305-13-000191:notes:22]
The Company may be involved, from time to time, in a variety of claims, lawsuits, investigations, and proceedings relating to contractual disputes, intellectual property rights, employment matters, regulatory compliance matters and other litigation matters relating to various claims that arise in the normal course of business. The Company determines whether an estimated loss from a contingency should be accrued by assessing whether a loss is deemed probable and can be reasonably estimated. The Company assesses its potential liability by analyzing specific litigation and regulatory matters using available information. The Company develops its views on estimated losses in consultation with inside and outside counsel, which involves a subjective analysis of potential results and outcomes, assuming various combinations of appropriate litigation and settlement strategies. Taking all of the above factors into account, the Company records an amount where it is probable that the Company will incur a loss and where that loss can be reasonably estimated. However, the Company’s estimates may be incorrect and the Company could ultimately incur more or less than the amounts initially recorded. Litigation can be costly, diverting management’s attention and could, upon resolution, have a material adverse effect on the Company’s business, results of operations, financial condition, and cash flows.

[0001445305-13-000191:notes:23]
Export Compliance Matters

[0001445305-13-000191:notes:24]
In January 2011, the U.S. Commerce Department, Bureau of Industry and Security’s (“BIS”) Office of Export Enforcement (“OEE”) contacted the Company to request that the Company provide information related to its relationship with a logistics company in the United Arab Emirates (“UAE”) and with a company in Iran, as well as information on the export classification of its products. As a result of this inquiry the Company, assisted by outside counsel, conducted a review of the Company's export transactions from 2008 through March 2011 to not only gather information responsive to the OEE's request but also to review the Company's overall compliance with export control and sanctions laws.  The Company believes its products have been sold into Iran by third parties. The Company does not believe that it directly sold, exported or shipped its products into Iran or any other country subject to a U.S. embargo. However, until early 2010, the Company did not prohibit its distributors from selling its products into Iran or any other country subject to a U.S. embargo. In the course of this review the Company identified that two distributors may have sold the Company's products into Iran. The Company's review also found that while it had obtained required Commodity Classification Rulings for its products in June 2010 and November 2010, the Company did not advise its shipping personnel to change the export authorizations used on its shipping documents until February 2011. During the course of the Company's export control review, the Company also determined that it had failed to maintain adequate records for the five year period required by the EAR and the sanctions regulations due to its lack of infrastructure and because it was prior to its transition to its current system of record, NetSuite.

[0001445305-13-000191:notes:25]
In May 2011, the Company filed a self-disclosure statement with the BIS and OEE.  In June 2011, the Company filed a self-disclosure statement with the U.S. Department of the Treasury’s Office of Foreign Asset Control (“OFAC”) regarding the compliance issues noted above. The disclosures address the above described findings and the remedial actions the Company had taken to date. However, the findings also indicate that both distributors continued to sell, directly or indirectly, the Company’s products into Iran during the period from February 2010 through March 2011 and that the Company received various communications from them indicating that they were continuing to do so. Since January 2011, the Company has cooperated with OEE and, prior to its disclosure filing, the Company informally shared with the OEE the substance of its findings with respect to both distributors. From May 2011 to August 2011, the Company provided additional information regarding its review and its findings to OEE to facilitate its investigation and OEE advised the Company in August 2011 that it had completed its investigation of the Company. In August 2011, the Company received a warning letter from OEE stating that OEE had not referred the findings of the Company’s review for criminal or administrative prosecution and closed the investigation of the Company without penalty.

[0001445305-13-000191:notes:26]
OFAC is still reviewing the Company’s voluntary disclosure. In the Company’s submission, the Company provided OFAC with an explanation of the activities that led to the sales of its products in Iran and the failure to comply with the Export Administration Regulations (the “EAR”) and OFAC sanctions. Although the Company’s OFAC and OEE voluntary disclosures covered similar sets of facts, which led the OEE to resolve the case with the issuance of a warning letter, OFAC may conclude that the Company’s actions resulted in violations of U.S. export control and economic sanctions laws and warrant the imposition of penalties that could include fines, termination of the Company’s ability to export its products, and/or referral for criminal prosecution. Any such fines may be material to the Company’s financial results in the period in which they are imposed. The penalties may be imposed against the Company and/or its management. The maximum civil monetary penalty for the violations is up to $250,000 or twice the value of the transaction, whichever is greater, per violation. The Company cannot predict when OFAC will complete its review or decide upon the imposition of possible penalties.

[0001445305-13-000191:notes:27]
While the Company has now taken actions to ensure that export classification information is distributed to the appropriate personnel in a timely manner and has adopted policies and procedures to promote its compliance with these laws and regulations, including obtaining written distribution agreements with substantially all of its distributors that contain covenants requiring compliance with U.S. export control and economic sanctions law; notifying all of its distributors of their obligations and obtaining updated distribution agreements from distributors that accounted for approximately 99% of its revenue in fiscal 2012.  The Company's failure to amend all its distribution agreements and to implement more robust compliance controls immediately after the discovery of Iran-related sales activity in early 2010 may be aggravating factors that could impact the imposition of penalties imposed on the Company or its management.  Based on the facts known to the Company to date, the Company recorded an expense of $1.6 million for this export compliance matter in fiscal 2010, which represents management’s estimated exposure for fines in accordance with applicable accounting literature. This amount was calculated from information discovered through the Company’s internal review and this loss is deemed to be probable and reasonably estimable. However, the Company also believes that it is reasonably possible that the loss may be higher, but the Company cannot reasonably estimate the range of any further potential losses. Specific information has come to management’s attention and as such management cannot estimate any further range of possible losses. Should additional facts be discovered in the future and/or should actual fines or other penalties substantially differ from the Company’s estimates, its business, financial condition, cash flows and results of operations would be materially negatively impacted.

[0001445305-13-000191:notes:28]
Shareholder Class Action Lawsuits

[0001445305-13-000191:notes:29]
Beginning on September 7, 2012, two shareholder class action complaints were filed against the Company, certain of its officers and directors and the underwriters of the Company's initial public offering in the United States District Court for the Northern District of California. On January 30, 2013, the plaintiffs filed an Amended Consolidated Complaint, which alleges claims under the Securities Act of 1933, the Securities Exchange Act of 1934 and SEC Rule 10b-5 on behalf of a purported class of those who purchased the Company's common stock between October 14, 2011 and August 9, 2012 and/or acquired the Company's stock pursuant to or traceable to the registration statement for the initial public offering. The Amended Consolidated Complaint alleges that the defendants violated the federal securities laws by issuing false or misleading statements regarding the sale of counterfeit Company products.  The consolidated complaint seeks, among other things, damages and interest, rescission, and attorneys' fees and costs.

[0001445305-13-000191:notes:30]
The Company believes that the allegations in the consolidated complaint are without merit and intend to vigorously contest the litigation. However, there can be no assurance that the Company will be successful in its defense. Because the case is at a very early stage, the Company cannot currently estimate the loss or the range of possible losses we may experience in connection with this litigation.


## us-gaap:DebtDisclosureTextBlock

[0001445305-13-000191:notes:31]
DEBT

[0001445305-13-000191:notes:32]
In July 2011, the Company repurchased an aggregate of 12,041,700 shares of the Company’s Series A convertible preferred stock from entities affiliated with Summit Partners, L.P., one of the Company’s major stockholders, at a price of $8.97 per share for an aggregate consideration of $108.0 million. Of the aggregate purchase price, $40.0 million was paid in cash at the time of closing and the balance of the shares were paid for through the issuance of convertible subordinated promissory notes in the aggregate principal amount of $68.0 million. On September 15, 2011, $34.0 million was paid against the notes and was financed through the Company's EWB Loan Agreement (as further described below) reducing the aggregate principal amount outstanding to $34.0 million. The remainder of the notes were retired in October 2011 with the proceeds of the Company’s initial public offering and existing cash balances. The interest rate on the notes started at 5% per annum and increased by two percentage points every three months until it would have reached 9% in January 2012. The notes were prepayable without penalty prior to April 21, 2012, and were required to be paid in the event of the Company’s initial public offering or third party financing prior to April 21, 2012. The notes matured on July 21, 2021. The unpaid principal on the notes was convertible into shares of Series A preferred stock at $8.97 per share at any point after July 21, 2012. The difference between the repurchase price and the carrying value of the repurchased preferred stock on June 30, 2011 was $59.0 million. The difference was debited to available retained earnings with the remaining amount debited to additional paid-in capital and reduced the net income attributable to common stock shareholders resulting in a reduction of basic and diluted net income per share.

[0001445305-13-000191:notes:33]
On September 15, 2011, the Company entered into a Loan and Security Agreement with East West Bank, (the “EWB Loan Agreement”), which was replaced by the Loan Agreement as discussed below. The credit facilities available under the EWB Loan Agreement consist of a $35.0 million term loan facility and a $5.0 million revolving line of credit facility. The term loan matures on September 15, 2016 with principal and interest to be repaid in 60 monthly installments. The Company used $34.0 million of the term loan to repay a portion of the outstanding convertible subordinated promissory notes held by entities affiliated with Summit Partners, L.P leaving $1.0 million available for borrowing under the term loan facility.

[0001445305-13-000191:notes:34]
On August 7, 2012, the Company entered into a Loan and Security Agreement (the “Loan Agreement”) with U.S. Bank, as syndication agent, and East West Bank, as administrative agent for the lenders party to the Loan Agreement. The Loan Agreement replaced the EWB Loan Agreement discussed above. The Loan Agreement provides for (i) a $50.0 million revolving credit facility, with a $5.0 million sublimit for the issuance of letters of credit and a $5.0 million sublimit for the making of swingline loan advances (the “Revolving Credit Facility”), and (ii) a $50.0 million term loan facility (the “Term Loan Facility”). The Company may request borrowings under the Revolving Credit Facility until August 7, 2015. On August 7, 2012, the Company borrowed $20.8 million under the Term Loan Facility, and no borrowings remain available for borrowing thereunder.  On November 21, 2012, the Company borrowed $10.0 million under the Revolving Credit Facility. On December 20, 2012, the Company borrowed an additional $20.0 million under the Revolving Credit Facility, and $20.0 million remains available for borrowing thereunder.

[0001445305-13-000191:notes:35]
The loans bear interest, at the Company’s option, at the base rate plus a spread of 1.25% to 1.75% or an adjusted LIBOR rate (at the Company’s election, for a period of 30, 60, or 90 days) plus a spread of 2.25% to 2.75%, in each case with such spread being determined based on the debt service coverage ratio for its most recently ended fiscal quarter. The base rate is the highest of (i) East West Bank’s prime rate, (ii) the federal funds rate plus a margin equal to 0.50%, or (iii) the LIBOR rate plus a margin equal to 1.00%. The Company is also obligated to pay other customary closing fees, arrangement fees, administration fees, commitment fees and letter of credit fees for a credit facility of this size and type.

[0001445305-13-000191:notes:36]
Interest is due and payable monthly in arrears in the case of loans bearing interest at the base rate and at the end of an interest period in the case of loans bearing interest at the adjusted LIBOR rate. Principal payments under the Term Loan Facility will be made in quarterly installments on the first day of each calendar quarter, and each such quarterly installment shall be equal to $1.25 million through July 1, 2014, then equal to $1.875 million from October 1, 2014 through July 1 2015, and then equal to $2.5 million from October 1, 2015 through July 1, 2017, with the remaining outstanding principal balance and all accrued and unpaid interest due on August 7, 2017. All outstanding loans under the Revolving Credit Facility, together with all accrued and unpaid interest, are due on August 7, 2015.

[0001445305-13-000191:notes:37]
The Company may prepay the loans, in whole or in part, at any time without premium or penalty, subject to certain conditions including minimum amounts and reimbursement of certain costs in the case of prepayments of LIBOR loans. In addition, the Company is required to prepay the loan under the Term Loan Facility with (i) the proceeds from certain financing transactions or asset sales (subject, in the case of asset sales, to reinvestment rights) and (ii) 25.0% of the Company’s excess cash flow in the U.S., as determined after each fiscal year and in accordance with the Loan Agreement, provided that the Company shall not be required to prepay the loan out of its excess cash flow if its leverage ratio is greater than 1.50:1.00 on the last day of such fiscal year.

[0001445305-13-000191:notes:38]
All of the obligations of the Company under the Loan Agreement are collateralized by substantially all of the Company’s assets, including all of the capital stock of the Company’s future domestic subsidiaries and 65% of the capital stock of the Company’s existing and future foreign subsidiaries, but excluding the Company’s intellectual property, which is subject to a negative pledge agreement. All of the Company’s future domestic subsidiaries are required to guaranty the obligations under the Loan Agreement. Such guarantees by future subsidiaries will be collateralized by substantially all of the property of such subsidiaries, excluding intellectual property.

[0001445305-13-000191:notes:39]
The Loan Agreement contains customary affirmative and negative covenants, including covenants that limit or restrict the Company and its subsidiaries’ ability to, among other things, incur indebtedness, grant liens, merge or consolidate, dispose of assets, pay dividends or make distributions, make investments, make acquisitions, prepay certain indebtedness, change the nature of its business, enter into certain transactions with affiliates, enter into restrictive agreements, and make capital expenditures, in each case subject to customary exceptions for a credit facility of this size and type. The Company is also required to maintain a minimum debt service coverage ratio, a maximum leverage ratio, and a minimum liquidity ratio.  As of December 31, 2012, the Company was in compliance with all affirmative and negative covenants, debt service coverage ratio, leverage ratio and liquidity ratio requirements.

[0001445305-13-000191:notes:40]
The Loan Agreement includes customary events of default that, include among other things, defaults for the failure to timely pay principal, interest, or other amounts due, defaults due to the inaccuracy of representations and warranties, covenant defaults, a cross default to material indebtedness, bankruptcy and insolvency defaults, material judgment defaults, defaults due to the unenforceability of a guaranty, and defaults due to circumstances that have or could reasonably be expected to have a material adverse effect on the Company's business, operations or financial condition, its ability to pay or perform under the Loan Agreement, or on the lenders' security interests. The occurrence of an event of default could result in the acceleration of the obligations under the Loan Agreement. During the existence of an event of default, interest on the obligations under the Loan Agreement could be increased by 2.00% above the otherwise applicable interest rate.

[0001445305-13-000191:notes:41]
During the three and six months ended December 31, 2012, the Company made aggregate payments of $1.3 million and $1.8 million, respectively, against the loan balance.  As of December 31, 2012, the Company has classified $5.0 million and $73.6 million in short-term and long-term debt, respectively, on its consolidated balance sheet related to the Loan Agreement.

[0001445305-13-000191:notes:42]
The following table summarizes our estimated debt and interest payment obligations as of December 31, 2012 (in thousands):

[0001445305-13-000191:notes:43]
|  | 2013(remainder) |  | 2014 |  | 2015 |  | 2016 |  | 2017 |  | Thereafter |  | Total |
| Debt payment obligations | $ | 2,500 |  |  | $ | 5,000 |  |  | $ | 6,875 |  |  | $ | 39,375 |  |  | $ | 10,000 |  |  | $ | 15,000 |  |  | $ | 78,750 |  |
| Interest payments on debt payment obligations | 542 |  |  | 1,859 |  |  | 1,723 |  |  | 1,043 |  |  | 532 |  |  | 125 |  |  | 5,824 |  |
| Total | $ | 3,042 |  |  | $ | 6,859 |  |  | $ | 8,598 |  |  | $ | 40,418 |  |  | $ | 10,532 |  |  | $ | 15,125 |  |  | $ | 84,574 |  |


## us-gaap:DeferredCostsCapitalizedPrepaidAndOtherAssetsDisclosureTextBlock

[0001445305-13-000191:notes:44]
Prepaid expenses and other current assets consisted of the following (in thousands):

[0001445305-13-000191:notes:45]
|  | December 31, 2012 |  | June 30, 2012 |
| Vendor deposits | $ | — |  |  | $ | 129 |  |
| Other current assets | 2,771 |  |  | 1,448 |  |
|  | $ | 2,771 |  |  | $ | 1,577 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001445305-13-000191:notes:46]
STOCK BASED COMPENSATION

[0001445305-13-000191:notes:47]
Stock-Based Compensation Plans

[0001445305-13-000191:notes:48]
The Company’s 2010 Equity Incentive Plan and 2005 Equity Incentive Plan are described in its Annual Report. As of December 31, 2012, the Company had 5,381,713 authorized shares available for future issuance under all of its stock incentive plans.

[0001445305-13-000191:notes:49]
Stock-based Compensation

[0001445305-13-000191:notes:50]
The following table shows total stock-based compensation expense included in the Condensed Consolidated Statements of Operations for the three and six months ended December 31, 2012 and 2011 (in thousands):

[0001445305-13-000191:notes:51]
|  | Three Months Ended December 31, |  | Six Months Ended December 31, |
|  | 2012 |  | 2011 |  | 2012 |  | 2011 |
| Cost of sales | $ | 104 |  |  | $ | 27 |  |  | $ | 185 |  |  | $ | 33 |  |
| Research and development | 401 |  |  | 116 |  |  | 667 |  |  | 232 |  |
| Sales, general and administrative | 388 |  |  | 208 |  |  | 697 |  |  | 437 |  |
|  | $ | 893 |  |  | $ | 351 |  |  | $ | 1,549 |  |  | $ | 702 |  |

[0001445305-13-000191:notes:52]
Stock Options

[0001445305-13-000191:notes:53]
The following is a summary of option activity for the Company’s stock incentive plans for the six months ended December 31, 2012:

[0001445305-13-000191:notes:54]
|  | Common Stock Options Outstanding |
|  | Numberof Shares |  | WeightedAverageExercisePrice |  | WeightedAverageRemainingContractualLife (Years) |  | AggregateIntrinsicValue |
|  |  |  |  |  |  |  | (In thousands) |
| Balance, June 30, 2012 | 3,347,445 |  |  | $ | 1.45 |  |  |  |  |  |
| Granted | 600,000 |  |  | 10.93 |  |  |  |  |  |
| Exercised | (50,205 | ) |  | 3.21 |  |  |  |  |  |
| Forfeitures and cancellations | (17,366 | ) |  | 6.22 |  |  |  |  |  |
| Balance, December 31, 2012 | 3,879,874 |  |  | $ | 2.87 |  |  | 6.66 |  | $ | 36,110 |  |
| Vested and expected to vest as of December 31, 2012 | 3,806,169 |  |  | $ | 2.76 |  |  | 6.66 |  | $ | 35,867 |  |
| Vested and exercisable as of December 31, 2012 | 2,662,106 |  |  | $ | 0.76 |  |  | 5.66 |  | $ | 30,324 |  |

[0001445305-13-000191:notes:55]
During the three months ended December 31, 2012 and 2011, the aggregate intrinsic value of options exercised under the Company’s stock incentive plans was $185,000 and $46.2 million, respectively, as determined as of the date of option exercise. During the six months ended December 31, 2012 and 2011, the aggregate intrinsic value of options exercised under the Company’s stock incentive plans was $363,000 and $46.6 million respectively.

[0001445305-13-000191:notes:56]
As of December 31, 2012, the Company had unrecognized compensation costs of $4.2 million related to stock options which the Company expects to recognize over a weighted-average period of 3.5 years. Future option grants will increase the amount of compensation expense to be recorded in these periods.

[0001445305-13-000191:notes:57]
The Company estimates the fair value of employee stock options using the Black-Scholes option pricing model. The fair value of employee stock options is being amortized on a straight-line basis over the requisite service period of the awards. For the three and six months ended December 31, 2012 and 2011, the fair value of employee stock options was estimated using the following weighted average assumptions:

[0001445305-13-000191:notes:58]
|  | Three Months Ended December 31, |  | Six Months Ended December 31, |
|  | 2012 |  | 2011 |  | 2012 |  | 2011 |
| Expected term | 6.1 years |  |  | 6.1 years |  |  | 6.1 years |  |  | 6.1 years |  |
| Expected volatility | 52 | % |  | 51 | % |  | 52 | % |  | 49 | % |
| Risk-free interest rate | 0.8 | % |  | 1.1 | % |  | 0.8 | % |  | 1.6 | % |
| Expected dividend yield | — |  |  | — |  |  | — |  |  | — |  |
| Weighted average grant date fair value | $ | 5.37 |  |  | $ | 7.79 |  |  | $ | 5.37 |  |  | $ | 4.90 |  |

[0001445305-13-000191:notes:59]
Restricted Stock Units (“RSUs”)

[0001445305-13-000191:notes:60]
The following table summarizes the activity of the RSUs made by the Company:

[0001445305-13-000191:notes:61]
|  | Number ofShares |  | WeightedAverage GrantDate Fair Value |
| Non-vested RSUs, June 30, 2012 | 453,620 |  |  | $ | 9.42 |  |
| RSUs granted | 300,500 |  |  | 13.63 |  |
| RSUs vested | (19,207 | ) |  | 12.65 |  |
| RSUs cancelled | (10,500 | ) |  | 28.78 |  |
| Non-vested RSUs, December 31, 2012 | 724,413 |  |  | $ | 10.80 |  |

[0001445305-13-000191:notes:62]
The intrinsic value of RSUs vested in the three months ended December 31, 2012 and 2011 was $142,000 and $25,000, respectively. The intrinsic value of RSUs vested in the six months ended December 31, 2012 and 2011 was $233,000 and $25,000, respectively. The total intrinsic value of all outstanding RSUs was $8.8 million as of December 31, 2012.

[0001445305-13-000191:notes:63]
As of December 31, 2012, there was unrecognized compensation costs related to RSUs of $6.2 million which the Company expects to recognize over a weighted average period of 3.5 years.


## us-gaap:EarningsPerShareTextBlock

[0001445305-13-000191:notes:64]
EARNINGS PER SHARE

[0001445305-13-000191:notes:65]
The following table sets forth the computation of basic and diluted earnings per share for the periods indicated (in thousands, except per share data):

[0001445305-13-000191:notes:66]
|  | Three Months Ended December 31, |  | Six Months Ended December 31, |
|  | 2012 |  | 2011 |  | 2012 |  | 2011 |
| Numerator: |  |  |  |
| Net income (loss) attributable to common stockholders—basic | $ | 17,803 |  |  | $ | 14,428 |  |  | $ | 30,982 |  |  | $ | (66,247 | ) |
| Net income (loss) attributable to common stockholders—diluted | $ | 17,803 |  |  | $ | 14,443 |  |  | $ | 30,982 |  |  | $ | (66,247 | ) |
| Denominator: |  |  |  |
| Weighted-average shares used in computing basic net income (loss) per share | 88,094 |  |  | 87,487 |  |  | 89,532 |  |  | 75,102 |  |
| Add—dilutive potential common shares: |  |  |  |  |  |  |  |
| Stock options | 1,806 |  |  | 2,309 |  |  | 1,808 |  |  | — |  |
| Restricted stock units | 156 |  |  | 260 |  |  | 153 |  |  | — |  |
| Weighted-average shares used in computing diluted net income (loss) per share | 90,056 |  |  | 90,056 |  |  | 91,493 |  |  | 75,102 |  |
| Net income (loss) per share of common stock: |  |  |  |
| Basic | $ | 0.20 |  |  | $ | 0.16 |  |  | $ | 0.35 |  |  | $ | (0.88 | ) |
| Diluted | $ | 0.20 |  |  | $ | 0.16 |  |  | $ | 0.34 |  |  | $ | (0.88 | ) |

[0001445305-13-000191:notes:67]
The following table summarizes the total potential shares of common stock that were excluded from the diluted per share calculation, because to include them would have been anti-dilutive for the period (in thousands):

[0001445305-13-000191:notes:68]
|  | Three Months Ended December 31, |  | Six Months Ended December 31, |
|  | 2012 |  | 2011 |  | 2012 |  | 2011 |
| Stock options | 355 |  |  | 34 |  |  | 196 |  |  | 3,458 |  |
| Restricted stock units | 367 |  |  | 11 |  |  | 340 |  |  | 496 |  |
|  | 722 |  |  | 45 |  |  | 536 |  |  | 3,954 |  |


## us-gaap:FairValueAssetsAndLiabilitiesMeasuredOnRecurringAndNonrecurringBasisTableTextBlock

[0001445305-13-000191:notes:69]
As of December 31, 2012 and June 30, 2012, the fair value hierarchy for the Company’s financial assets and financial liabilities was as follows (in thousands):

[0001445305-13-000191:notes:70]
|  | December 31, 2012 |  | June 30, 2012 |
|  | FairValue |  | Level 1 |  | Level 2 |  | Level 3 |  | FairValue |  | Level 1 |  | Level 2 |  | Level 3 |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | $ | 135,000 |  |  | $ | 135,000 |  |  | $ | — |  |  | $ | — |  |  | $ | 108,228 |  |  | $ | 108,228 |  |  | $ | — |  |  | $ | — |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Debt | $ | 78,610 |  |  | $ | — |  |  | $ | 78,610 |  |  | $ | — |  |  | $ | 29,591 |  |  | $ | — |  |  | $ | 29,591 |  |  | $ | — |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001445305-13-000191:notes:71]
FAIR VALUE OF FINANCIAL INSTRUMENTS

[0001445305-13-000191:notes:72]
Pursuant to the accounting guidance for fair value measurements and its subsequent updates, fair value is defined as the price that would be received from selling an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date. As such, fair value is a market-based measurement that should be determined based on assumptions that market participants would use in pricing an asset or liability. The accounting guidance establishes a three-tier fair value hierarchy that requires the Company to use observable market data, when available, and to minimize the use of unobservable inputs when determining fair value. The fair value hierarchy prioritizes the inputs into three levels that may be used in measuring fair value as follows:

[0001445305-13-000191:notes:73]
Level 1—observable inputs which include quoted prices in active markets for identical assets of liabilities.

[0001445305-13-000191:notes:74]
Level 2—inputs which include observable inputs other than Level 1, such as quoted prices for similar assets or liabilities, quoted prices for identical or similar assets or liabilities in markets that are not active, or other inputs that are observable or can be corroborated by observable market data for substantially the full term of the asset or liability.

[0001445305-13-000191:notes:75]
Level 3—inputs which include unobservable inputs that are supported by little or no market activity and that are significant to the fair value of the underlying asset or liability. Level 3 assets and liabilities include those whose fair value measurements are determined using pricing models, discounted cash flow methodologies or similar valuation techniques, as well as significant management judgment or estimation.

[0001445305-13-000191:notes:76]
The Company’s financial assets at December 31, 2012 and June 30, 2012 included money market funds which were valued based on quoted prices in active markets for substantially similar assets and, therefore, were Level 1 instruments. Additionally, at December 31, 2012 and June 30, 2012 the Company had debt associated with its Loan and Security Agreement with East West Bank (See Note 8). The fair value of the Company’s debt was estimated based on the current rates offered to the Company for debt with similar terms and remaining maturities and were therefore Level 2 instruments.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001445305-13-000191:notes:77]
INCOME TAXES

[0001445305-13-000191:notes:78]
As of December 31, 2012, the Company had approximately $9.3 million of unrecognized tax benefits, substantially all of which would, if recognized, affect its tax expense. The Company has elected to include interest and penalties related to uncertain tax positions as a component of tax expense. At December 31, 2012, an insignificant amount of interest and penalties are included in long-term income tax payable. The Company recorded an increase of its unrecognized tax benefits of $896,000 for the three months ended December 31, 2012. The Company does not expect any significant increases or decreases to its unrecognized tax benefits in the next twelve months.

[0001445305-13-000191:notes:79]
The Company recorded a tax provision of $2.1 million for the three months ended December 31, 2012. The Company’s estimated 2012 effective tax rate differs from the U.S. statutory rate primarily due to profits earned in jurisdictions where the tax rate is lower than the U.S. tax rate.

[0001445305-13-000191:notes:80]
The Company files U.S. federal income tax returns as well as income tax returns in various states and foreign jurisdictions. The Company’s tax years from 2009 and onwards could be subject to examinations by tax authorities.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001445305-13-000191:notes:81]
The Company does not believe there have been any recent accounting pronouncements that would have a significant impact on the Company’s financial statements.


## us-gaap:PreferredStockTextBlock

[0001445305-13-000191:notes:82]
PREFERRED STOCK

[0001445305-13-000191:notes:83]
Preferred Stock

[0001445305-13-000191:notes:84]
In July 2011, the Company repurchased an aggregate of 12,041,700 shares of the Company’s Series A convertible preferred stock from entities affiliated with Summit Partners, L.P., one of the Company’s major stockholders, at a price of $8.97 per share for an aggregate consideration of $108.0 million. Of the aggregate purchase price, $40.0 million was paid in cash at the time of closing and the balance of the shares were paid for through the issuance of convertible subordinated promissory notes in the aggregate principal amount of $68.0 million. The $68.0 million was paid down primarily using proceeds from the EWB Loan Agreement and the remaining balance was subsequently paid down by funds raised upon the completion of the Company’s initial public offering on October 19, 2011 and the Company’s existing cash balances as discussed in Note 8.


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001445305-13-000191:notes:85]
ACCRUED WARRANTY

[0001445305-13-000191:notes:86]
The Company offers warranties on certain products, generally for a period of one year, and records a liability for the estimated future costs associated with potential warranty claims. The warranty costs are reflected in the Company’s consolidated statement of operations within cost of revenues. The warranties are typically in effect for 12 months from the distributor’s purchase date of the product. The Company’s estimate of future warranty costs is largely based on historical experience factors including product failure rates, material usage, and service delivery cost incurred in correcting product failures. In certain circumstances, the Company may have recourse from its contract manufacturers for replacement cost of defective products, which it also factors into its warranty liability assessment.

[0001445305-13-000191:notes:87]
Warranty obligations, included in other current liabilities, were as follows (in thousands):

[0001445305-13-000191:notes:88]
|  | Six Months Ended December 31, |
|  | 2012 |  | 2011 |
| Beginning balance | $ | 1,381 |  |  | $ | 806 |  |
| Accruals for warranties issued during the period | 1,684 |  |  | 1,229 |  |
| Warranty costs incurred during the period | (1,115 | ) |  | (668 | ) |
|  | $ | 1,950 |  |  | $ | 1,367 |  |


## us-gaap:PropertyPlantAndEquipmentScheduleOfSignificantAcquisitionsAndDisposalsTextBlock

[0001445305-13-000191:notes:89]
Property and equipment, net consisted of the following (in thousands):

[0001445305-13-000191:notes:90]
|  | December 31, 2012 |  | June 30, 2012 |
| Testing equipment | $ | 2,883 |  |  | $ | 2,293 |  |
| Computer and other equipment | 663 |  |  | 578 |  |
| Tooling equipment | 1,391 |  |  | 532 |  |
| Furniture and fixtures | 607 |  |  | 595 |  |
| Leasehold improvements | 1,808 |  |  | 1,424 |  |
| Software | 92 |  |  | 77 |  |
|  | 7,444 |  |  | 5,499 |  |
| Less: Accumulated depreciation and amortization | (1,780 | ) |  | (1,028 | ) |
|  | $ | 5,664 |  |  | $ | 4,471 |  |


## us-gaap:ScheduleOfAccruedLiabilitiesTableTextBlock

[0001445305-13-000191:notes:91]
Accrued liabilities consisted of the following (in thousands):

[0001445305-13-000191:notes:92]
|  | December 31, 2012 |  | June 30, 2012 |
| Accrued compensation and benefits | $ | 2,498 |  |  | $ | 2,657 |  |
| Accrued accounts payable | 4,932 |  |  | 6,636 |  |
| Accrual for an export compliance matter | 1,625 |  |  | 1,625 |  |
| Warranty accrual | 1,950 |  |  | 1,381 |  |
| Other accruals | 3,926 |  |  | 4,732 |  |
|  | $ | 14,931 |  |  | $ | 17,031 |  |


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0001445305-13-000191:notes:93]
Inventories consisted of the following (in thousands):

[0001445305-13-000191:notes:94]
|  | December 31, 2012 |  | June 30, 2012 |
| Raw materials | $ | 2,928 |  |  | $ | 4,668 |  |
| Finished goods | 11,695 |  |  | 3,066 |  |
|  | $ | 14,623 |  |  | $ | 7,734 |  |


## us-gaap:ScheduleOfOtherAssetsNoncurrentTextBlock

[0001445305-13-000191:notes:95]
Other long-term assets consisted of the following (in thousands):

[0001445305-13-000191:notes:96]
|  | December 31, 2012 |  | June 30, 2012 |
| Intangible assets, net | $ | 989 |  |  | $ | 748 |  |
| Other long-term assets | 815 |  |  | 388 |  |
|  | $ | 1,804 |  |  | $ | 1,136 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001445305-13-000191:notes:97]
SEGMENT INFORMATION, REVENUES BY GEOGRAPHY AND SIGNIFICANT CUSTOMERS

[0001445305-13-000191:notes:98]
Revenues by product type were as follows (in thousands, except percentages):

[0001445305-13-000191:notes:99]
|  | Three Months Ended December 31, |  | Six Months Ended December 31, |
|  | 2012 |  | 2011 |  | 2012 |  | 2011 |
| airMAX | $ | 48,752 |  |  | 65 | % |  | $ | 52,939 |  |  | 60 | % |  | $ | 80,809 |  |  | 59 | % |  | $ | 102,774 |  |  | 62 | % |
| New platforms | 11,905 |  |  | 16 | % |  | 4,226 |  |  | 5 | % |  | 27,533 |  |  | 20 | % |  | 6,960 |  |  | 4 | % |
| Other systems | 4,835 |  |  | 6 | % |  | 18,254 |  |  | 21 | % |  | 8,619 |  |  | 7 | % |  | 31,019 |  |  | 19 | % |
| Systems | 65,492 |  |  | 87 | % |  | 75,419 |  |  | 86 | % |  | 116,961 |  |  | 86 | % |  | 140,753 |  |  | 85 | % |
| Embedded radio | 1,519 |  |  | 2 | % |  | 2,567 |  |  | 3 | % |  | 3,233 |  |  | 2 | % |  | 5,792 |  |  | 3 | % |
| Antennas/other | 7,890 |  |  | 11 | % |  | 9,831 |  |  | 11 | % |  | 16,242 |  |  | 12 | % |  | 20,439 |  |  | 12 | % |
| Total revenues | $ | 74,901 |  |  | 100 | % |  | $ | 87,817 |  |  | 100 | % |  | $ | 136,436 |  |  | 100 | % |  | $ | 166,984 |  |  | 100 | % |

[0001445305-13-000191:notes:100]
The Company generally forwards products directly from its manufacturers to its customers via a logistics distribution hub in China. The Company's customers in turn ship to other locations throughout the world. The Company has determined the geographical distribution of product revenues based upon the customer's ship-to destinations.

[0001445305-13-000191:notes:101]
Revenues by geography were as follows (in thousands, except percentages):

[0001445305-13-000191:notes:102]
|  | Three Months Ended December 31, |  | Six Months Ended December 31, |
|  | 2012 |  | 2011 |  | 2012 |  | 2011 |
| North America(1) | $ | 12,106 |  |  | 16 | % |  | $ | 21,440 |  |  | 24 | % |  | $ | 32,467 |  |  | 24 | % |  | $ | 46,381 |  |  | 28 | % |
| South America | 17,081 |  |  | 23 | % |  | 24,250 |  |  | 28 | % |  | 27,324 |  |  | 20 | % |  | 44,085 |  |  | 26 | % |
| Europe, the Middle East and Africa | 35,929 |  |  | 48 | % |  | 30,356 |  |  | 35 | % |  | 59,073 |  |  | 43 | % |  | 55,139 |  |  | 33 | % |
| Asia Pacific | 9,785 |  |  | 13 | % |  | 11,771 |  |  | 13 | % |  | 17,572 |  |  | 13 | % |  | 21,379 |  |  | 13 | % |
| Total revenues | $ | 74,901 |  |  | 100 | % |  | $ | 87,817 |  |  | 100 | % |  | $ | 136,436 |  |  | 100 | % |  | $ | 166,984 |  |  | 100 | % |

[0001445305-13-000191:notes:103]
| (1) | Revenue for the United States was $11.4 million and $20.7 million for the three months ended December 31, 2012 and 2011, respectively. Revenue for the United States was $30.7 million and $45.1 million for the six months ended December 31, 2012 and 2011, respectively. |

[0001445305-13-000191:notes:104]
Customers with an accounts receivable balance of 10% or greater of total accounts receivable and customers with net revenues of 10% or greater of total revenues are presented below for the periods indicated:

[0001445305-13-000191:notes:105]
|  | Percentage of Revenues |  | Percentage of Accounts Receivable |
|  | Three Months Ended December 31, |  | Six Months Ended December 31, |  | December 31, |  | June 30, |
|  | 2012 |  | 2011 |  | 2012 |  | 2011 |  | 2012 |  | 2012 |
| Customer A | 15 | % |  | 21 | % |  | 12 | % |  | 19 | % |  | 17 | % |  | 19 | % |
| Customer B | 14 | % |  | * |  |  | * |  |  | * |  |  | 13 | % |  | * |  |
| Customer C | * |  |  | * |  |  | * |  |  | 12 | % |  | * |  |  | 11 | % |
| Customer D | * |  |  | * |  |  | * |  |  | * |  |  | * |  |  | 12 | % |

[0001445305-13-000191:notes:106]
*  denotes less than 10%


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001445305-13-000191:notes:107]
SUMMARY OF SIGNIFICANT ACCOUNTING POLICIES

[0001445305-13-000191:notes:108]
The Company’s significant accounting policies are disclosed in its audited consolidated financial statements for the year ended June 30, 2012 included in the Annual Report.

[0001445305-13-000191:notes:109]
Recent Accounting Pronouncements


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001445305-13-000191:notes:110]
BALANCE SHEET COMPONENTS

[0001445305-13-000191:notes:111]
[same as prior period, unchanged from 0001193125-12-463263:notes:28]

[0001445305-13-000191:notes:112]
Prepaid Expenses and Other Current Assets

[0001445305-13-000191:notes:113]
Property and Equipment, Net

[0001445305-13-000191:notes:114]
Other Long-term Assets

[0001445305-13-000191:notes:115]
Other Current Liabilities


## ubnt:CommonStockAndTreasuryStockDiscloseTextBlock

[0001445305-13-000191:notes:116]
COMMON STOCK AND TREASURY STOCK

[0001445305-13-000191:notes:117]
As of December 31, 2012 and June 30, 2012, the authorized capital of the Company included 500,000,000 shares of common stock. As of December 31, 2012, 131,196,746 shares of common stock were issued and 86,957,786 were outstanding. As of June 30, 2012, 131,129,888 shares of common stock were issued and 92,049,978 were outstanding.

[0001445305-13-000191:notes:118]
Common Stock Repurchases

[0001445305-13-000191:notes:119]
On August 9, 2012, the Company announced that its Board of Directors authorized the Company to repurchase up to $100 million of its common stock. The share repurchase program commenced Monday, August 13, 2012. The share repurchase program has been funded from proceeds from the Loan Agreement as discussed in Note 8 and from existing cash on hand.

[0001445305-13-000191:notes:120]
Common stock repurchase activity during the six months ended December 31, 2012 was as follows (in thousands, except share and per share amounts):

[0001445305-13-000191:notes:121]
| Period | Total Numberof SharesPurchased |  | Average PricePaid per Share |  | Dollar Value ofShares that MayYet Be Purchased |
| August 13, 2012 – August 31, 2012 | 2,179,900 |  |  | $ | 8.88 |  |  | $ | 80,599 |  |
| September 1, 2012 – September 30, 2012 | 992,014 |  |  | $ | 11.93 |  |  | $ | 68,742 |  |
| October 1, 2012 - October 31, 2012 | 371,665 |  |  | $ | 11.72 |  |  | $ | 64,377 |  |
| November 1, 2012 - November 30, 2012 | 657,700 |  |  | $ | 11.16 |  |  | $ | 57,024 |  |
| December 1, 2012 - December 31, 2012 | 957,771 |  |  | $ | 11.86 |  |  | $ | 45,646 |  |
| Total | 5,159,050 |  |  | $ | 10.52 |  |  | $ | 45,646 |  |

[0001445305-13-000191:notes:122]
Special Dividend

[0001445305-13-000191:notes:123]
On December 14, 2012, the Company announced that its Board of Directors had authorized a special cash dividend of $0.18 per share for each share of common stock outstanding on December 24, 2012.  The aggregate dividend payment of $15.7 million was paid on December 28, 2012 to stockholders of record on December 24, 2012.
