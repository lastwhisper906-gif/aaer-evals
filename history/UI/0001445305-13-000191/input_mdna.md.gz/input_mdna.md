# UI MD&A — 0001445305-13-000191


## mdna

[0001445305-13-000191:mdna:1]
Item 2. Management’s Discussion and Analysis of Financial Condition and Results of Operations

[0001445305-13-000191:mdna:2]
[same as prior period, unchanged from 0001193125-12-463263:mdna:2]

[0001445305-13-000191:mdna:3]
We are a product driven company that leverages innovative proprietary technologies to deliver networking solutions with compelling price-performance characteristics to both start-up and established network operators and service providers. Our products bridge the digital divide by fundamentally changing the economics of deploying high performance networking solutions in underserved and underpenetrated wireless broadband access markets globally. These markets include emerging markets and other areas where individual users and small and medium sized enterprises do not have access to the benefits of carrier class broadband networking. Our business model has enabled us to break down traditional barriers, such as high product and network deployment costs, which are driven by business model inefficiencies and achieve rapid market adoption of our products and solutions in previously underserved and underpenetrated markets. Our business model and proprietary technologies provide us with a significant and sustainable competitive advantage over incumbents, who we believe are unable to respond effectively due to their higher cost business models.

[0001445305-13-000191:mdna:4]
We offer a broad and expanding portfolio of networking products and solutions in the outdoor wireless, enterprise WLAN, video surveillance, wireless backhaul and machine-to-machine communications markets. We began shipping embedded radios in fiscal 2006. In fiscal 2008 we introduced a line of products based on 802.11 standard protocols and in early fiscal 2010, we introduced a number of new products based on our proprietary airMAX protocol, which have been rapidly adopted by network operators and high-performance proprietary airMAX service providers. Since the beginning of fiscal 2011, we have introduced UniFi, airVision, airFiber, mFi and EdgeMAX, which are collectively referred to in this report as our New Platforms. In the three and six months ended December 31, 2012, our systems revenue accounted for 87% and 86% of our revenues, respectively. In the future, we expect sales of our airMAX platform and our new product platforms to continue to represent a growing portion of our revenues and the portion of our revenues derived from our 802.11 standard products to decline as a percentage of total revenues.

[0001445305-13-000191:mdna:5]
Building on our leadership in the underserved and underpenetrated segments of the wireless broadband access market, we intend to expand our product offerings in our existing market and enter adjacent markets by relying on the combination of our efficient business model and proprietary technologies. For example, we have introduced products and solutions for the enterprise WLAN and video surveillance markets, and since late fiscal 2011 licensed microwave wireless backhaul, machine-to-machine communication and router markets. As we enter such new markets, we plan to leverage existing distributor relationships and established engaged communities similar to the Ubiquiti Community, our growing and engaged community of network operators, service providers, distributors, value added resellers and system integrators, to keep our operating expenses in line with our current model and enable us to offer products in these new markets with compelling price-performance characteristics.

[0001445305-13-000191:mdna:6]
to keep our operating expenses in line with our current model and enable us to offer products in these new markets with compelling price-performance characteristics.

[0001445305-13-000191:mdna:7]
Our revenues decreased 15% to $74.9 million in the three months ended December 31, 2012 from $87.8 million in the three months ended December 31, 2011.  Our revenues decreased 18% to $136.4 million in the six months ended December 31, 2012 from $167.0 million in the six months ended December 31, 2011. We believe the overall decrease in revenues during both the three and six months ended December 31, 2012 was primarily driven by lost sales due to the proliferation of counterfeit versions of our products, which has also created customer uncertainty regarding the authenticity of their potential purchases.  We believe these factors contributed to a buildup in channel inventory with our distributors, further impacting our revenues.  We had net income of $17.8 million and $24.7 million in the three months ended December 31, 2012 and 2011, respectively.  We had net income of $31.0 million and $46.2 million in the six months ended December 31, 2012 and 2011, respectively.  The declines in net income in both the three and six months ended December 31, 2012 as compared to the same periods in the prior year were primarily due to the decline in revenues and increased operating expenses.

[0001445305-13-000191:mdna:8]
[same as prior period, unchanged from 0001193125-12-463263:mdna:7]

[0001445305-13-000191:mdna:9]
[same as prior period, unchanged from 0001193125-12-463263:mdna:8]

[0001445305-13-000191:mdna:10]
Our revenues are derived principally from the sale of networking hardware and management tools. In addition, while we do not sell maintenance and support separately, because we have historically included it free of charge in many of our arrangements, we attribute a portion of our systems revenues to this implied post-contract customer support (“PCS”).

[0001445305-13-000191:mdna:11]
We classify our revenues into three product categories: systems, embedded radios and antennas/other.

[0001445305-13-000191:mdna:12]
| • | Systems consists of three product categories: |

[0001445305-13-000191:mdna:13]
| ▪ | Our proprietary airMAX platform products for network operators and service providers; |

[0001445305-13-000191:mdna:14]
| ▪ | Our new platform products which include significant platforms introduced in late fiscal 2011 and during 2012 which includes the UniFi, airVision and airFiber, mFi and EdgeMAX platforms; and |

[0001445305-13-000191:mdna:15]
| ▪ | Other 802.11 standard products including base stations, radios, backhaul equipment and Customer Premise Equipment ("CPE"). |

[0001445305-13-000191:mdna:16]
| • | Embedded radios consist of more than 25 radio products primarily for OEMs, including both point to point and point to multipoint radios in the 2.0 to 6.0GHz spectrum, that are offered with a variety of features. |

[0001445305-13-000191:mdna:17]
| • | Antennas/other consist of antenna products in the 2.0 to 6.0GHz spectrum, as well as miscellaneous products such as mounting brackets, cables and power over Ethernet adapters. These products include both high performance sector and directional antennas. This category also includes our allocation of revenues to PCS. |

[0001445305-13-000191:mdna:18]
We sell substantially all of our products through a limited number of distributors and other channel partners, such as resellers and OEMs. Sales to distributors accounted for 97% and 96% of our revenues in the three months ended December 31, 2012 and 2011, respectively. Sales to distributors accounted for 97% of our revenues in both the six months ended December 31, 2012 and 2011. Other channel partners, such as resellers and OEMs, largely accounted for the balance of our revenues. We sell our products without any right of return.

[0001445305-13-000191:mdna:19]
[same as prior period, unchanged from 0001193125-12-463263:mdna:18]

[0001445305-13-000191:mdna:20]
Our cost of revenues is comprised primarily of the costs of procuring finished goods from our contract manufacturers and chipsets that we consign to certain of our contract manufacturers. In addition, cost of revenues includes tooling, labor and other costs associated with engineering, testing and quality assurance, warranty costs, stock-based compensation and excess and obsolete inventory.

[0001445305-13-000191:mdna:21]
We outsource our manufacturing and order fulfillment and utilize contract manufacturers located primarily in China and, to a lesser extent, Taiwan. We also evaluate and utilize other vendors for various portions of our supply chain from time to time. Our manufacturing organization consists of employees and consultants engaged in the management of our contract manufacturers, new product introduction activities, logistical support and engineering.

[0001445305-13-000191:mdna:22]
[same as prior period, unchanged from 0001193125-12-463263:mdna:21]

[0001445305-13-000191:mdna:23]
Our gross profit has been, and may in the future be, influenced by several factors including changes in product mix, target end markets for our products, pricing due to competitive pressure, production costs, foreign exchange rates and global demand for electronic components. Although we procure and sell our products in U.S. dollars, our contract manufacturers incur many costs, including labor costs, in other currencies. To the extent that the exchange rates move unfavorably for our contract manufacturers, they may try to pass these additional costs on to us, which could have a material impact on our future average selling prices and unit costs.

[0001445305-13-000191:mdna:24]
[same as prior period, unchanged from 0001193125-12-463263:mdna:23]

[0001445305-13-000191:mdna:25]
[same as prior period, unchanged from 0001193125-12-463263:mdna:24]

[0001445305-13-000191:mdna:26]
| • | Research and development expenses consist primarily of salary and benefit expenses, including stock-based compensation, for employees and costs for contractors engaged in research, design and development activities, as well as costs for prototypes, facilities and travel. Over time, we expect our research and development costs to increase as we continue making significant investments in developing new products and developing new versions of our existing products. |

[0001445305-13-000191:mdna:27]
| • | Sales, general and administrative expenses include salary and benefit expenses, including stock-based compensation, for employees and costs for contractors engaged in sales, marketing and general and administrative activities, as well as the costs of outside legal expenses, trade shows, marketing programs, promotional materials, bad debt expense, professional services, facilities, general liability insurance and travel. As our product portfolio and targeted markets expand, we may need to employ different sales models, such as building a direct sales force. These sales models would likely increase our costs. Over time, we expect our sales, general and administrative expenses to increase in absolute |

[0001445305-13-000191:mdna:28]
dollars due to continued growth in headcount, expand our registration and defense of trademarks and patents efforts and to support our business and operations as a public company.

[0001445305-13-000191:mdna:29]
[same as prior period, unchanged from 0001193125-12-463263:mdna:27]

[0001445305-13-000191:mdna:30]
In the event that collectability of a receivable from products we have shipped is not probable, we classify those amounts as deferred revenues on our balance sheet until such time as we receive payment of the accounts receivable. We classify the cost of products associated with these deferred revenues as deferred costs of revenues. At December 31, 2012 and June 30, 2012, we did not have any revenue deferred for transactions where we lacked evidence that collectability of the receivables recorded was reasonably probable.

[0001445305-13-000191:mdna:31]
Also included in our deferred revenues is a portion related to PCS obligations that we estimate we will perform in the future. As of December 31, 2012 and June 30, 2012, we had deferred revenues of $815,000 and $805,000 respectively, related to these obligations.

[0001445305-13-000191:mdna:32]
[same as prior period, unchanged from 0001193125-12-463263:mdna:30]

[0001445305-13-000191:mdna:33]
We have historical agreements with certain contract manufacturers whereby we prepay for a portion of the product costs to assure the manufacture and timely delivery of our products.  However, as of December 31, 2012 we did not have any prepayment balances with our contract manufacturers.  As of June 30, 2012, we had a prepayment balance of $129,000.

[0001445305-13-000191:mdna:34]
[same as prior period, unchanged from 0001193125-12-463263:mdna:32]

[0001445305-13-000191:mdna:35]
We prepare our condensed consolidated financial statements in accordance with accounting principles generally accepted in the United States of America (“GAAP”). In many cases, the accounting treatment of a particular transaction is specifically dictated by GAAP and does not require management’s judgment in its application. In other cases, management’s judgment is required in selecting among available alternative accounting standards that provide for different accounting treatment for similar transactions. The preparation of condensed consolidated financial statements also requires us to make estimates and assumptions that affect the amounts we report as assets, liabilities, revenues, costs and expenses and affect the related disclosures. We base our estimates on historical experience and other assumptions that we believe are reasonable under the circumstances. In many instances, we could reasonably use different accounting estimates, and in some instances changes in the accounting estimates are reasonably likely to occur from period to period. Accordingly, our actual results could differ significantly from the estimates made by our management. To the extent that there are differences between our estimates and actual results, our future financial statement presentation, financial condition, results of operations and cash flows will be affected. Our critical accounting policies are discussed in our Annual Report on Form 10-K for the fiscal year ended June 30, 2012, as filed on September 28, 2012 with the SEC, or the Annual Report, and there have been no material changes.

[0001445305-13-000191:mdna:36]
19

[0001445305-13-000191:mdna:37]
[same as prior period, unchanged from 0001193125-12-463263:mdna:34]

[0001445305-13-000191:mdna:38]
Comparison of Three and Six Months Ended December 31, 2012 and 2011

[0001445305-13-000191:mdna:39]
|  | Three Months Ended December 31, |  | Six Months Ended December 31, |
|  | 2012 |  | 2011 |  | 2012 |  | 2011 |
|  | (In thousands, except percentages) |
| Revenues | $ | 74,901 |  |  | 100 | % |  | $ | 87,817 |  |  | 100 | % |  | $ | 136,436 |  |  | 100 | % |  | $ | 166,984 |  |  | 100 | % |
| Cost of revenues | 44,416 |  |  | 59 | % |  | 50,527 |  |  | 58 | % |  | 80,931 |  |  | 59 | % |  | 96,681 |  |  | 58 | % |
| Gross profit | 30,485 |  |  | 41 | % |  | 37,290 |  |  | 42 | % |  | 55,505 |  |  | 41 | % |  | 70,303 |  |  | 42 | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | 5,052 |  |  | 7 | % |  | 3,683 |  |  | 4 | % |  | 9,763 |  |  | 7 | % |  | 7,052 |  |  | 4 | % |
| Sales, general and administrative | 5,314 |  |  | 7 | % |  | 2,431 |  |  | 3 | % |  | 9,848 |  |  | 7 | % |  | 4,575 |  |  | 3 | % |
| Total operating expenses | 10,366 |  |  | 14 | % |  | 6,114 |  |  | 7 | % |  | 19,611 |  |  | 14 | % |  | 11,627 |  |  | 7 | % |
| Income from operations | 20,119 |  |  | 27 | % |  | 31,176 |  |  | 35 | % |  | 35,894 |  |  | 27 | % |  | 58,676 |  |  | 35 | % |
| Interest expense and other, net | (197 | ) |  | * |  |  | (312 | ) |  | * |  |  | (283 | ) |  | * |  |  | (946 | ) |  | * |  |
| Income before provision for income taxes | 19,922 |  |  | 27 | % |  | 30,864 |  |  | 35 | % |  | 35,611 |  |  | 26 | % |  | 57,730 |  |  | 35 | % |
| Provision for income taxes | 2,119 |  |  | 3 | % |  | 6,173 |  |  | 7 | % |  | 4,629 |  |  | 3 | % |  | 11,546 |  |  | 7 | % |
| Net income | $ | 17,803 |  |  | 24 | % |  | $ | 24,691 |  |  | 28 | % |  | $ | 30,982 |  |  | 23 | % |  | $ | 46,184 |  |  | 28 | % |
| * Less than 1% |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| (1) Includes stock-based compensation as follows: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of revenues | $ | 104 |  |  |  |  | $ | 27 |  |  |  |  | $ | 185 |  |  |  |  | $ | 33 |  |  |  |
| Research and development | 401 |  |  |  |  | 116 |  |  |  |  | 667 |  |  |  |  | 232 |  |  |  |
| Sales, general and administrative | 388 |  |  |  |  | 208 |  |  |  |  | 697 |  |  |  |  | 437 |  |  |  |
| Total stock-based compensation | $ | 893 |  |  |  |  | $ | 351 |  |  |  |  | $ | 1,549 |  |  |  |  | $ | 702 |  |  |  |

[0001445305-13-000191:mdna:40]
[same as prior period, unchanged from 0001193125-12-463263:mdna:37]

[0001445305-13-000191:mdna:41]
Revenues decreased $12.9 million, or 15%, from $87.8 million in the three months ended December 31, 2011 to $74.9 million in the three months ended December 31, 2012.  Revenues decreased $30.5 million, or 18%, from $167.0 million in the six months ended December 31, 2011 to $136.4 million in the six months ended December 31, 2012.  We believe the overall decrease in revenues during the three and six months ended December 31, 2012 was primarily driven by lost sales due to the proliferation of counterfeit versions of our products, which has also created customer uncertainty regarding the authenticity of their potential purchases.  We believe these factors contributed to a buildup in channel inventory with our distributors, further impacting our revenues.  This has had the most significant impact on our airMAX platform which decreased $4.2 million and $22.0 million, respectively, in the three and six months ended December 31, 2012 compared to the same periods in the prior year.

[0001445305-13-000191:mdna:42]
In the three months ended December 31, 2012, revenues from Customer A and Customer B represented 15% and 14% of our revenues, respectively. In the three months ended December 31, 2011, revenues from Customer A represented 21% of our revenues.  In the six months ended December 31, 2012, revenues from Customer A represented 12% of our revenues. In the six months ended December 31, 2011, revenues from Customer A and Customer C represented 19% and 12% of our revenues, respectively. No other customer represented more than 10% of our revenues in the three or six months ended December 31, 2012 or 2011.

[0001445305-13-000191:mdna:43]
20

[0001445305-13-000191:mdna:44]
[same as prior period, unchanged from 0001193125-12-463263:mdna:40]

[0001445305-13-000191:mdna:45]
|  | Three Months Ended December 31, |  | Six Months Ended December 31, |
|  | 2012 |  | 2011 |  | 2012 |  | 2011 |
|  | (in thousands, except percentages) |
| airMAX | $ | 48,752 |  |  | 65 | % |  | $ | 52,939 |  |  | 60 | % |  | $ | 80,809 |  |  | 59 | % |  | $ | 102,774 |  |  | 62 | % |
| New platforms | 11,905 |  |  | 16 | % |  | 4,226 |  |  | 5 | % |  | 27,533 |  |  | 20 | % |  | 6,960 |  |  | 4 | % |
| Other systems | 4,835 |  |  | 6 | % |  | 18,254 |  |  | 21 | % |  | 8,619 |  |  | 7 | % |  | 31,019 |  |  | 19 | % |
| Systems | 65,492 |  |  | 87 | % |  | 75,419 |  |  | 86 | % |  | 116,961 |  |  | 86 | % |  | 140,753 |  |  | 85 | % |
| Embedded radio | 1,519 |  |  | 2 | % |  | 2,567 |  |  | 3 | % |  | 3,233 |  |  | 2 | % |  | 5,792 |  |  | 3 | % |
| Antennas/other | 7,890 |  |  | 11 | % |  | 9,831 |  |  | 11 | % |  | 16,242 |  |  | 12 | % |  | 20,439 |  |  | 12 | % |
| Total revenues | $ | 74,901 |  |  | 100 | % |  | $ | 87,817 |  |  | 100 | % |  | $ | 136,436 |  |  | 100 | % |  | $ | 166,984 |  |  | 100 | % |

[0001445305-13-000191:mdna:46]
Systems revenues decreased $9.9 million, or 13%, from $75.4 million in the three months ended December 31, 2011 to $65.5 million in the three months ended December 31, 2012.  Systems revenues decreased $23.8 million, or 17%, from $140.8 million in the six months ended December 31, 2011 to $117.0 million in the three months ended December 31, 2012.  As noted above, we believe the decrease in systems revenues was primarily driven by lost sales due to the proliferation of counterfeit versions of our products, in particular our airMAX product line. The decrease in our airMAX product line was partially offset by increased sales in our new platforms category, which includes significant platforms introduced since late fiscal 2011. Our new platforms contributed $11.9 million and $4.2 million of revenue during the three months ended December 31, 2012 and 2011, respectively, and $27.5 million and $7.0 million of revenue during the six months ended December 31, 2012 and 2011, respectively. Our other systems revenue decreased $13.4 million during the three months ended December 31, 2012 as compared to the three months ended December 31, 2011 due primarily to our December 2011 quarter including a large order to a customer. Our other systems revenue decreased $22.4 million during the six months ended December 31, 2012 as compared to the six months ended December 31, 2011 due primarily to our December 2011 quarter including a large order to a customer.

[0001445305-13-000191:mdna:47]
Embedded radio revenues decreased $1.0 million, or 41%, from $2.6 million in the three months ended December 31, 2011 to $1.5 million in the three months ended December 31, 2012, and decreased $2.6 million, or 44%, from $5.8 million in the six months ended December 31, 2011 to $3.2 million in the six months ended December 31, 2012. We anticipate that embedded radio products will decline as a percentage of revenues in future periods as sales of these products are outpaced by sales of systems products.

[0001445305-13-000191:mdna:48]
Antennas/other revenues decreased $1.9 million, or 20% from $9.8 million in the three months ended December 31, 2011 to $7.9 million in the three months ended December 31, 2012.  Antennas/other revenues decreased $4.2 million, or 21% from $20.4 million in the six months ended December 31, 2011 to $16.2 million in the six months ended December 31, 2012. The decline in antennas/other revenues was primarily due to the decreased sales of our systems platforms, which negatively impacted the demand for associated antennas. Other revenues also include revenues that are attributable to PCS. Antenna/other revenues will decline as a percentage of total revenues due to more rapid growth of systems revenues.

[0001445305-13-000191:mdna:49]
[same as prior period, unchanged from 0001193125-12-463263:mdna:42]

[0001445305-13-000191:mdna:50]
[same as prior period, unchanged from 0001193125-12-463263:mdna:46]

[0001445305-13-000191:mdna:51]
We generally forward products directly from our manufacturers to our customers via logistics distribution hubs in Asia.  Beginning in the quarter ended December 31, 2012, our products were predominantly routed through a third party logistics provider in China and prior to the quarter ended December 31, 2012, our products were mainly delivered to our customers through distribution hubs in Hong Kong.  Our customers in turn ship to other locations throughout the world. We have determined the geographical distribution of our product revenues based on our customer's ship-to destinations. A majority of our sales are to distributors who in turn sell to resellers or directly to end customers. As a result of these factors, we believe that sales to certain geographic locations might be higher or lower, as the ultimate destinations are difficult to ascertain.  Revenues in North America decreased primarily due to a significant decline in orders from one of our customers.  We believe the decrease in revenues in South America and Europe, the Middle East and Africa was primarily driven by the proliferation of counterfeit versions of our products, which has also created customer uncertainty regarding the authenticity of their potential purchases. Revenues in the Asia Pacific region tend to be volatile given the low levels of revenues. The following are our revenues by geography for the three and six months ended December 31, 2012 and 2011 (in thousands, except percentages):

[0001445305-13-000191:mdna:52]
|  | Three Months Ended December 31, |  | Six Months Ended December 31, |
|  | 2012 |  | 2011 |  | 2012 |  | 2011 |
| North America(1) | $ | 12,106 |  |  | 16 | % |  | $ | 21,440 |  |  | 24 | % |  | $ | 32,467 |  |  | 24 | % |  | $ | 46,381 |  |  | 28 | % |
| South America | 17,081 |  |  | 23 | % |  | 24,250 |  |  | 28 | % |  | 27,324 |  |  | 20 | % |  | 44,085 |  |  | 26 | % |
| Europe, the Middle East and Africa | 35,929 |  |  | 48 | % |  | 30,356 |  |  | 35 | % |  | 59,073 |  |  | 43 | % |  | 55,139 |  |  | 33 | % |
| Asia Pacific | 9,785 |  |  | 13 | % |  | 11,771 |  |  | 13 | % |  | 17,572 |  |  | 13 | % |  | 21,379 |  |  | 13 | % |
| Total revenues | $ | 74,901 |  |  | 100 | % |  | $ | 87,817 |  |  | 100 | % |  | $ | 136,436 |  |  | 100 | % |  | $ | 166,984 |  |  | 100 | % |

[0001445305-13-000191:mdna:53]
| (1) | Revenue for the United States was $11.4 million and $20.7 million for the three months ended December 31, 2012 and 2011, respectively. Revenue for the United States was $30.7 million and $45.1 million for the six months ended December 31, 2012 and 2011, respectively. |

[0001445305-13-000191:mdna:54]
Cost of Revenues and Gross Profit

[0001445305-13-000191:mdna:55]
Cost of revenues decreased $6.1 million, or 12%, from $50.5 million in the three months ended December 31, 2011 to $44.4 million in the three months ended December 31, 2012.  Cost of revenues decreased $15.8 million, or 16%, from $96.7 million in the six months ended December 31, 2011 to $80.9 million in the six months ended December 31, 2012.  The decreases in cost of revenues in both the three and six months ended December 31, 2012 was primarily due to decreased revenues and to a lesser extent, changes in product mix.

[0001445305-13-000191:mdna:56]
Gross profit decreased from 42% in the three months ended December 31, 2011 to 41% in the three months ended December 31, 2012. Gross profit decreased from 42% in the six months ended December 31, 2011 to 41% in the six months ended December 31, 2012. The decrease in gross profit in both periods reflects increases in variable operating costs.

[0001445305-13-000191:mdna:57]
[same as prior period, unchanged from 0001193125-12-463263:mdna:52]

[0001445305-13-000191:mdna:58]
[same as prior period, unchanged from 0001193125-12-463263:mdna:53]

[0001445305-13-000191:mdna:59]
Research and development expenses increased $1.4 million, or 37%, from $3.7 million in the three months ended December 31, 2011 to $5.1 million in the three months ended December 31, 2012. As a percentage of revenues, research and development expenses increased from 4% in the three months ended December 31, 2011 to 7% in the three months ended December 31, 2012. Research and development expenses increased $2.7 million, or 38%, from $7.1 million in the six months ended December 31, 2011 to $9.8 million in the six months ended December 31, 2012. As a percentage of revenues, research and development expenses increased from 4% in the six months ended December 31, 2011 to 7% in the six months ended December 31, 2012. The increase in research and development expenses in absolute dollars in both periods was due to increases in headcount as we broadened our research and development activities to new product areas. As a percentage of revenues, research and development expenses increased in both periods primarily due to our overall decrease in revenues. Over time, we expect our research and development costs to increase in absolute dollars as we continue making significant investments in developing new products and developing new versions of our existing products.

[0001445305-13-000191:mdna:60]
[same as prior period, unchanged from 0001193125-12-463263:mdna:55]

[0001445305-13-000191:mdna:61]
Sales, general and administrative expenses increased $2.9 million, or 119%, from $2.4 million in the three months ended December 31, 2011 to $5.3 million in the three months ended December 31, 2012. As a percentage of revenues, sales, general

[0001445305-13-000191:mdna:62]
and administrative expenses increased from 3% in the three months ended December 31, 2011 to 7% in the three months ended December 31, 2012. Sales, general and administrative expenses increased $5.3 million, or 115%, from $4.6 million in the six months ended December 31, 2011 to $9.8 million in the six months ended December 31, 2012. As a percentage of revenues, sales, general and administrative expenses increased from 3% in the six months ended December 31, 2011 to 7% in the six months ended December 31, 2012. Sales, general and administrative expenses increased in both periods due largely to increased legal expenses associated with our anti-counterfeiting litigation, increased marketing and tradeshow activity and increases in our bad debt allowance. As a percentage of revenues sales, general and administrative expenses increased in both periods primarily due to our overall revenue decrease in revenues. Over time, we expect our sales, general and administrative expenses to increase in absolute dollars due to continued efforts to protect our intellectual property and growth in headcount to support our business and operations.

[0001445305-13-000191:mdna:63]
Interest Expense and Other, Net

[0001445305-13-000191:mdna:64]
Interest expense and other, net was $197,000 for the three months ended December 31, 2012, representing a decrease of $115,000 from $312,000 for the three months ended December 31, 2011. Interest expense and other, net was $283,000 for the six months ended December 31, 2012, representing a decrease of $663,000 from $946,000 for the six months ended December 31, 2011. During the three months ended September 30, 2011, we incurred interest expense on our convertible subordinated promissory notes issued as part of the repurchase of Series A convertible preferred stock from entities affiliated with Summit Partners, L.P. in July 2011. The convertible subordinated promissory notes were repaid in full in October 2011.

[0001445305-13-000191:mdna:65]
[same as prior period, unchanged from 0001193125-12-463263:mdna:59]

[0001445305-13-000191:mdna:66]
Our provision for income taxes decreased $4.1 million, or 66%, from $6.2 million for the three months ended December 31, 2011 to $2.1 million for the three months ended December 31, 2012. Our provision for income taxes decreased $6.9 million, or 60%, from $11.5 million for the six months ended December 31, 2011 to $4.6 million for the six months ended December 31, 2012. Our effective tax rate decreased to 11% for the three months ended December 31, 2012 as compared to 20% the three months ended December 31, 2011.   Our effective tax rate decreased to 13% for the six months ended December 31, 2012 as compared to 20% the six months ended December 31, 2011.   The decrease in the effective tax rates during both periods was primarily due to a larger percentage of our overall profitability occurring in foreign jurisdictions with lower income tax rates.

[0001445305-13-000191:mdna:67]
[same as prior period, unchanged from 0001193125-12-463263:mdna:61]

[0001445305-13-000191:mdna:68]
[same as prior period, unchanged from 0001193125-12-463263:mdna:62]

[0001445305-13-000191:mdna:69]
Since inception, our operations primarily have been funded through cash generated by operations. Cash, cash equivalents and short-term marketable securities increased from $122.1 million at June 30, 2012 to $148.3 million at December 31, 2012.

[0001445305-13-000191:mdna:70]
[same as prior period, unchanged from 0001193125-12-463263:mdna:64]

[0001445305-13-000191:mdna:71]
[same as prior period, unchanged from 0001193125-12-463263:mdna:65]

[0001445305-13-000191:mdna:72]
|  | Six Months Ended December 31, |
|  | 2012 |  | 2011 |
|  | (In thousands) |
| Net cash provided by operating activities | $ | 50,525 |  |  | $ | 19,970 |  |
| Net cash used in investing activities | (3,467 | ) |  | (1,110 | ) |
| Net cash used in financing activities | (20,817 | ) |  | (30,377 | ) |
| Net increase (decrease) in cash and cash equivalents | $ | 26,241 |  |  | $ | (11,517 | ) |

[0001445305-13-000191:mdna:73]
[same as prior period, unchanged from 0001193125-12-463263:mdna:67]

[0001445305-13-000191:mdna:74]
Net cash provided by operating activities in the six months ended December 31, 2012 of $50.5 million consisted primarily of net income of $31.0 million and net changes in operating assets and liabilities that resulted in net cash inflows of $15.2 million. These changes consisted primarily of a $18.5 million decrease in accounts receivable due to decreased revenues and improved cash collections, a $1.7 million increase in accounts payable and accrued liabilities due to decreased overall business activity, a $4.4 million increase in taxes payable due the timing of federal tax payments and a $1.6 million increase in prepaid expenses and other current assets due to an increase in overall business activity. Additionally, our net income included non-cash adjustments due to stock-based compensation, depreciation and amortization, increases to our provision for doubtful accounts

[0001445305-13-000191:mdna:75]
23

[0001445305-13-000191:mdna:76]
and write-downs for inventory obsolescence and an excess tax benefit from stock-based awards. The net of these non-cash adjustments resulted in an increase of our net cash provided by operating activities of $4.3 million.

[0001445305-13-000191:mdna:77]
Net cash provided by operating activities in the six months ended December 31, 2011 of $20.0 million consisted primarily of net income of $46.2 million partially offset by changes in operating assets and liabilities.  These changes consisted primarily of a $22.2 million increase in accounts receivable due to our overall revenue growth, a $9.1 million increase in taxes payable, a $3.8 million increase in inventories, a $1.5 million decrease in accounts payable and accrued liabilities, a $1.0 million decrease in prepaid expenses and other current assets and an increase of $608,000 in deferred revenues and deferred cost of revenues.  Additionally, our net income included non-cash adjustments due to stock-based compensation, depreciation and amortization, adjustments to our provisions for doubtful accounts and inventory obsolescence and an excess tax benefit from stock-based awards. The net of these non-cash adjustments resulted in a reduction of our net cash provided by operating activities of $9.4 million.

[0001445305-13-000191:mdna:78]
[same as prior period, unchanged from 0001193125-12-463263:mdna:70]

[0001445305-13-000191:mdna:79]
Our investing activities consist solely of capital expenditures and purchases of intangible assets. Capital expenditures for the six months ended December 31, 2012 and 2011 were $2.6 million and $1.1 million, respectively. Additionally, we had cash outflows related to the purchase of intangible assets of $814,000 during the six months ended December 31, 2012.

[0001445305-13-000191:mdna:80]
[same as prior period, unchanged from 0001193125-12-463263:mdna:72]

[0001445305-13-000191:mdna:81]
On August 7, 2012, we entered into a Loan and Security Agreement (the “Loan Agreement”) with U.S. Bank, as syndication agent, and East West Bank, as administrative agent for the lenders party to the Loan Agreement. The Loan Agreement replaced the EWB Loan Agreement discussed below. The Loan Agreement provides for (i) a $50.0 million revolving credit facility, with a $5.0 million sublimit for the issuance of letters of credit and a $5.0 million sublimit for the making of swingline loan advances (the “Revolving Credit Facility”), and (ii) a $50.0 million term loan facility (the “Term Loan Facility”). We may request borrowings under the Revolving Credit Facility until August 7, 2015. On August 7, 2012, we borrowed $20.8 million of term loans under the Term Loan Facility, and no borrowings remain available thereunder.  On November 21, 2012, we borrowed $10.0 million under the Revolving Credit Facility.  On December 20, 2012, we borrowed an additional $20.0 million under the Revolving Credit Facility, and $20.0 million remains available for borrowing thereunder.

[0001445305-13-000191:mdna:82]
The Loan Agreement contains customary affirmative and negative covenants, including covenants that limit or restrict our and

[0001445305-13-000191:mdna:83]
our subsidiaries’ ability to, among other things, incur indebtedness, grant liens, merge or consolidate, dispose of assets, pay

[0001445305-13-000191:mdna:84]
dividends or make distributions, make investments, make acquisitions, prepay certain indebtedness, change the nature of our or

[0001445305-13-000191:mdna:85]
its business, enter into certain transactions with affiliates, enter into restrictive agreements, and make capital expenditures, in

[0001445305-13-000191:mdna:86]
each case subject to customary exceptions for a credit facility of this size and type. We are also required to maintain a

[0001445305-13-000191:mdna:87]
minimum debt service coverage ratio, a maximum leverage ratio, and a minimum liquidity ratio. As of December 31, 2012, we

[0001445305-13-000191:mdna:88]
were in compliance with all affirmative and negative covenants, debt service coverage ratio, leverage ratio and minimum level

[0001445305-13-000191:mdna:89]
of liquidity requirements.

[0001445305-13-000191:mdna:90]
On August 9, 2012, we announced that our Board of Directors authorized us to repurchase up to $100.0 million of our common stock. The share repurchase program commenced August 13, 2012. During the six months ended December 31, 2012 we repurchased 5,159,050 shares for a total cost of $54.4 million.

[0001445305-13-000191:mdna:91]
On December 14, 2012, we announced that our Board of Directors had authorized a special cash dividend of $0.18 per share for each share of common stock outstanding on December 24, 2012.  The aggregate dividend payment of $15.7 million was paid on December 28, 2012 to stockholders of record on December 24, 2012.

[0001445305-13-000191:mdna:92]
In July 2011, we repurchased an aggregate of 12,041,700 shares of our Series A preferred stock from entities affiliated with Summit Partners, L.P., one of our major stockholders, at a price of $8.97 per share for an aggregate consideration of $108.0 million. Of the aggregate purchase price, $40.0 million was paid in cash at the time of closing and the balance of the shares were paid for through the issuance of convertible subordinated promissory notes in the aggregate principal amount of $68.0 million. On September 15, 2011, $34.0 million was paid against the notes reducing the aggregate principal amount outstanding to $34.0 million.

[0001445305-13-000191:mdna:93]
On September 15, 2011, we entered into a Loan and Security Agreement with East West Bank, (the “EWB Loan Agreement”). The EWB Loan Agreement consisted of a $35.0 million term loan facility and a $5.0 million revolving line of credit facility. The term loan was scheduled to mature on September 15, 2016 with principal and interest to be repaid in 60 monthly installments. During the three months ended September 30, 2011, we used $34.0 million of the term loan to repay a portion of

[0001445305-13-000191:mdna:94]
24

[0001445305-13-000191:mdna:95]
our outstanding convertible subordinated promissory notes held by entities affiliated with Summit Partners, L.P. The EWB Agreement was replaced by the Loan Agreement on August 7, 2012 as discussed above.

[0001445305-13-000191:mdna:96]
[same as prior period, unchanged from 0001193125-12-463263:mdna:77]

[0001445305-13-000191:mdna:97]
We believe our existing cash and cash equivalents, cash provided by operations and the availability of additional funds under our loan agreements will be sufficient to meet our working capital and capital expenditure needs for at least the next 12 months. Our future capital requirements may vary materially from those currently planned and will depend on many factors, including our rate of revenue growth, the timing and extent of spending to support development efforts, the timing of new product introductions, market acceptance of our products and overall economic conditions. As of December 31, 2012, we held $141.1 million of our $148.3 million of cash and cash equivalents in accounts of our subsidiaries outside of the United States and we will incur significant tax liabilities if we decide to repatriate those amounts.

[0001445305-13-000191:mdna:98]
Commitments and Contingencies

[0001445305-13-000191:mdna:99]
In January 2011, the U.S. Department of Commerce’s Bureau of Industry and Security’s Office of Export Enforcement (“OEE”) contacted us to request that we provide information related to our relationship with a logistics company in the United Arab Emirates (“UAE”) and with a company in Iran, as well as information on the export classification of our products. As a result of this inquiry we, assisted by outside counsel, conducted a review of our export transactions from 2008 through March 2011 to not only gather information responsive to the OEE’s request but also to review our overall compliance with export control and sanctions laws. We believe our products have been sold into Iran by third parties. We do not believe that we directly sold, exported or shipped our products into Iran or any other country subject to a U.S. embargo. However, until early 2010, we did not prohibit our distributors from selling our products into Iran or any other country subject to a U.S. embargo. In the course of this review we identified that two distributors may have sold Ubiquiti products into Iran. Our review also found that while we had obtained required Commodity Classification Rulings for our products in June 2010 and November 2010, we did not advise our shipping personnel to change the export authorizations used on our shipping documents until February 2011. During the course of our export control review, we also determined that we had failed to maintain adequate records for the five year period required by the EAR and the sanctions regulations due to our lack of infrastructure and because it was prior to our transition to our current system of record, NetSuite. See “Risk Factors—We are subject to numerous U.S. export control and economic sanctions laws and a substantial majority of our sales are into countries outside of the United States. Although we did not intend to do so, we have violated certain of these laws in the past, and we cannot currently assess the nature and extent of any fines or other penalties, if any, that U.S. governmental agencies may impose against us or our employees for any such violations. Any fines, if materially different from our estimates, or other penalties, could have a material adverse effect on our business and financial results.”

[0001445305-13-000191:mdna:100]
In May 2011, we filed a self-disclosure statement with the BIS and the OEE and, in June 2011 we filed a self-disclosure  statement with the U.S. Department of the Treasury’s Office of Foreign Asset Control (“OFAC”), regarding the compliance issues noted above. The disclosures address the above described findings and the remedial actions we have taken to date. However, the findings also indicate that both distributors continued to sell, directly or indirectly, our products into Iran during the period from February 2010 through March 2011 and that we received various communications from them indicating that they were continuing to do so. Since January 2011, we have cooperated with OEE and, prior to our disclosure filing, we informally shared with the OEE the substance of our findings with respect to both distributors. From May 2011 to August 2011, we provided additional information regarding our review and our findings to OEE to facilitate its investigation and OEE advised us in August 2011 that it had completed its investigation of us. In August 2011, we received a warning letter from OEE stating that OEE had not referred the findings of our review for criminal or administrative prosecution of us and closed the investigation of us without penalty.

[0001445305-13-000191:mdna:101]
OFAC is still reviewing our voluntary disclosure. In our submission, we have provided OFAC with an explanation of the activities that led to the sales of our products in Iran and the failure to comply with the EAR and OFAC sanctions. Although our OFAC and OEE voluntary disclosures covered similar sets of facts, which led OEE to resolve the case with the issuance of a warning letter, OFAC may conclude that our actions resulted in violations of U.S. export control and economic sanctions laws and warrant the imposition of penalties that could include fines, termination of our ability to export our products and/or referral for criminal prosecution. Any such fines may be material to our financial results in the period in which they are imposed. The penalties may be imposed against us and/or our management. The maximum civil monetary penalty for the violations is up to $250,000 or twice the value of the transaction, whichever is greater, per violation. Also, disclosure of our conduct and any fines or other action relating to this conduct could harm our reputation and indirectly have a material adverse effect on our business. We cannot predict when OFAC will complete its review or decide upon the imposition of possible penalties.

[0001445305-13-000191:mdna:102]
While we have now taken actions to ensure that export classification information is distributed to the appropriate personnel in a timely manner and have adopted policies and procedures to promote our compliance with these laws and regulations, including

[0001445305-13-000191:mdna:103]
obtaining written distribution agreements with substantially all of our distributors that contain covenants requiring compliance with U.S. export control and economic sanctions law; notifying all of our distributors of their obligations and obtaining updated distribution agreements from distributors that account for over 99% of our revenue in fiscal 2012.  Our failure to amend all our distribution agreements and to implement more robust compliance controls immediately after the discovery of Iran-related sales activity in early 2010 may be aggravating factors that could impact the imposition of penalties imposed on us or our management.  Based on the facts known to us to date, we recorded an expense of $1.6 million for this export compliance matter in fiscal 2010, which represents management’s estimated exposure for fines in accordance with applicable accounting literature.  This amount was calculated from information discovered through our internal review and we deem this loss to be probable and reasonably estimable. However, we believe that it is reasonably possible that the loss may be higher, but we cannot reasonably estimate the range of any further potential losses. Specific information has come to our attention and as we cannot estimate any further range of possible losses.  Should additional facts be discovered in the future and/or should actual fines or other penalties substantially differ from our estimates, our business, financial condition, cash flows and results of operations would be materially negatively impacted.

[0001445305-13-000191:mdna:104]
[same as prior period, unchanged from 0001193125-12-463263:mdna:86]

[0001445305-13-000191:mdna:105]
Our products are generally accompanied by a 12 month warranty, which covers both parts and labor. Generally the distributor is responsible for the freight costs associated with warranty returns, and we absorb the freight costs of replacing items under warranty. In accordance with the Financial Accounting Standards Board’s (“FASB’s”), Accounting Standards Codification (“ASC”), 450-30, Loss Contingencies, we record an accrual when we believe it is estimable and probable based upon historical experience. We record a provision for estimated future warranty work in cost of goods sold upon recognition of revenues and we review the resulting accrual regularly and periodically adjust it to reflect changes in warranty estimates.

[0001445305-13-000191:mdna:106]
We may in the future enter into standard indemnification agreements with many of our distributors and OEMs, as well as certain other business partners in the ordinary course of business. These agreements may include provisions for indemnifying the distributor, OEM or other business partner against any claim brought by a third party to the extent any such claim alleges that a Ubiquiti product infringes a patent, copyright or trademark or violates any other proprietary rights of that third party. The maximum amount of potential future indemnification is unlimited. The maximum potential amount of future payments we could be required to make under these indemnification agreements is not estimable.

[0001445305-13-000191:mdna:107]
We have agreed to indemnify our directors, officers and certain other employees for certain events or occurrences, subject to certain limits, while such persons are or were serving at our request in such capacity. We may terminate the indemnification agreements with these persons upon the termination of their services with us but termination will not affect claims for indemnification related to events occurring prior to the effective date of termination. The maximum amount of potential future indemnification is unlimited. We have a director and officer insurance policy that limits our potential exposure. We believe the fair value of these indemnification agreements is minimal. We had not recorded any liabilities for these agreements as of December 31, 2012 or 2011.

[0001445305-13-000191:mdna:108]
Based upon our historical experience and information known as of the date of this report, we do not believe it is likely that we will have significant liability for the above indemnities at December 31, 2012.

[0001445305-13-000191:mdna:109]
[same as prior period, unchanged from 0001193125-12-463263:mdna:91]

[0001445305-13-000191:mdna:110]
We lease our headquarters in San Jose, California and other locations worldwide under noncancelable operating leases that expire at various dates through fiscal 2017.

[0001445305-13-000191:mdna:111]
In December 2011, we entered into an agreement to lease approximately 64,512 square feet of office and research and development space located in San Jose, California, which we use as our corporate headquarters. The lease term is from April 1, 2012, though June 30, 2017. The lease has been categorized as an operating lease, and the total estimated lease obligation is approximately $4.9 million.

[0001445305-13-000191:mdna:112]
On August 7, 2012, we entered into the Loan Agreement with U.S. Bank, as syndication agent, and East West Bank, as administrative agent for the lenders party to the Loan Agreement.  The Loan Agreement provides for (i) a $50.0 million revolving credit facility, with a $5.0 million sublimit for the issuance of letters of credit and a $5.0 million sublimit for the making of swingline loan advances, and (ii) a $50.0 million Term Loan Facility. We may request borrowings under the Revolving Credit Facility until August 7, 2015. On August 7, 2012, we borrowed $20.8 million of term loans under the Term Loan Facility and no borrowings remain available thereunder.  On November 21, 2012, we borrowed $10.0 million under the Revolving Credit Facility.  On December 20, 2012 we borrowed an additional $20.0 million under the Revolving Credit Facility, and $20.0 million remains available for borrowing thereunder.

[0001445305-13-000191:mdna:113]
[same as prior period, unchanged from 0001193125-12-463263:mdna:93]

[0001445305-13-000191:mdna:114]
The following table summarizes our contractual obligations as of December 31, 2012:

[0001445305-13-000191:mdna:115]
|  | 2013(remainder) |  | 2014 |  | 2015 |  | 2016 |  | 2017 |  | Thereafter |  | Total |
| Operating leases | $ | 750 |  |  | $ | 1,505 |  |  | $ | 1,465 |  |  | $ | 1,423 |  |  | $ | 1,117 |  |  | $ | 188 |  |  | $ | 6,448 |  |
| Debt payment obligations | 2,500 |  |  | 5,000 |  |  | 6,875 |  |  | 39,375 |  |  | 10,000 |  |  | 15,000 |  |  | 78,750 |  |
| Interest payments on debt payment obligations | 542 |  |  | 1,859 |  |  | 1,723 |  |  | 1,043 |  |  | 532 |  |  | 125 |  |  | 5,824 |  |
| Total | $ | 3,792 |  |  | $ | 8,364 |  |  | $ | 10,063 |  |  | $ | 41,841 |  |  | $ | 11,649 |  |  | $ | 15,313 |  |  | $ | 91,022 |  |

[0001445305-13-000191:mdna:116]
We subcontract with other companies to manufacture our products. During the normal course of business, our contract manufacturers procure components based upon orders placed by us. If we cancel all or part of the orders, we may still be liable to the contract manufacturers for the cost of the components purchased by the subcontractors to manufacture our products. We periodically review the potential liability and to date no significant accruals have been recorded. Our consolidated financial position and results of operations could be negatively impacted if we were required to compensate the contract manufacturers for any unrecorded liabilities incurred.

[0001445305-13-000191:mdna:117]
As of December 31, 2012, we had $9.3 million of unrecognized tax benefits, substantially all of which would, if recognized, affect our tax expense. We have elected to include interest and penalties related to uncertain tax positions as a component of tax expense. We do not expect any significant increases or decreases to our unrecognized tax benefits in the next twelve months.

[0001445305-13-000191:mdna:118]
[same as prior period, unchanged from 0001193125-12-463263:mdna:100]

[0001445305-13-000191:mdna:119]
[same as prior period, unchanged from 0001193125-12-463263:mdna:101]

[0001445305-13-000191:mdna:120]
[same as prior period, unchanged from 0001193125-12-463263:mdna:102]

[0001445305-13-000191:mdna:121]
Regulation G, conditions for use of Non-Generally Accepted Accounting Principles (“Non-GAAP”) financial measures, and other SEC regulations define and prescribe the conditions for use of certain Non-GAAP financial information. To supplement our condensed consolidated financial results presented in accordance with GAAP, we use Non-GAAP financial measures which are adjusted from the most directly comparable GAAP financial measures to exclude certain items, as described below. Management believes that these Non-GAAP financial measures reflect an additional and useful way of viewing aspects of our operations that, when viewed in conjunction with our GAAP results, provide a more comprehensive understanding of the various factors and trends affecting our business and operations. Non-GAAP financial measures used by us include net income or loss and diluted net income or loss per share.

[0001445305-13-000191:mdna:122]
Our Non-GAAP measures primarily exclude stock-based compensation, net of taxes and other special charges and credits. Management believes these Non-GAAP financial measures provide meaningful supplemental information regarding our strategic and business decision making, internal budgeting, forecasting and resource allocation processes. In addition, these Non-GAAP financial measures facilitate management’s internal comparisons to our historical operating results and comparisons to competitors’ operating results.

[0001445305-13-000191:mdna:123]
We use each of these Non-GAAP financial measures for internal managerial purposes, when providing our financial results and business outlook to the public and to facilitate period-to-period comparisons. Management believes that these Non-GAAP measures provide meaningful supplemental information regarding our operational and financial performance of current and historical results. Management uses these Non-GAAP measures for strategic and business decision making, internal budgeting, forecasting and resource allocation processes. In addition, these Non-GAAP financial measures facilitate management’s internal comparisons to our historical operating results and comparisons to competitors’ operating results.

[0001445305-13-000191:mdna:124]
The following table shows our Non-GAAP financial measures:

[0001445305-13-000191:mdna:125]
|  | Three Months Ended December 31, |  | Six Months Ended December 31, |
|  | 2012 |  | 2011 |  | 2012 |  | 2011 |
|  | (In thousands, except per share amounts) |
| Non-GAAP net income | $ | 18,339 |  |  | $ | 24,902 |  |  | $ | 31,911 |  |  | $ | 46,605 |  |
| Non-GAAP diluted net income per share of common stock | $ | 0.20 |  |  | $ | 0.27 |  |  | $ | 0.35 |  |  | $ | 0.50 |  |

[0001445305-13-000191:mdna:126]
[same as prior period, unchanged from 0001193125-12-463263:mdna:105]

[0001445305-13-000191:mdna:127]
We believe that providing these Non-GAAP financial measures, in addition to the GAAP financial results, are useful to investors because they allow investors to see our results “through the eyes” of management as these Non-GAAP financial measures reflect our internal measurement processes. Management believes that these Non-GAAP financial measures enable investors to better assess changes in each key element of our operating results across different reporting periods on a consistent basis and provides investors with another method for assessing our operating results in a manner that is focused on the performance of our ongoing operations.

[0001445305-13-000191:mdna:128]
[same as prior period, unchanged from 0001193125-12-463263:mdna:110]

[0001445305-13-000191:mdna:129]
|  | Three Months Ended December 31, |  | Six Months Ended December 31, |
|  | 2012 |  | 2011 |  | 2012 |  | 2011 |
|  | (In thousands, except pershare amounts) |
| Net Income | $ | 17,803 |  |  | $ | 24,691 |  |  | $ | 30,982 |  |  | $ | 46,184 |  |
| Stock-based compensation: |  |  |  |  |  |  |  |
| Cost of revenues | 104 |  |  | 27 |  |  | 185 |  |  | 33 |  |
| Research and development | 401 |  |  | 116 |  |  | 667 |  |  | 232 |  |
| Sales, general and administrative | 388 |  |  | 208 |  |  | 697 |  |  | 437 |  |
| Tax effect of non-GAAP adjustments | (357 | ) |  | (140 | ) |  | (620 | ) |  | (281 | ) |
| Non-GAAP net income | $ | 18,339 |  |  | $ | 24,902 |  |  | $ | 31,911 |  |  | $ | 46,605 |  |
| Non-GAAP diluted net income per share of common stock (1) | $ | 0.20 |  |  | $ | 0.27 |  |  | $ | 0.35 |  |  | $ | 0.50 |  |
| Weighted-average shares used in computing non-GAAP diluted net income per share of common stock (1) | 90,056 |  |  | 93,446 |  |  | 91,493 |  |  | 93,480 |  |

[0001445305-13-000191:mdna:130]
[same as prior period, unchanged from 0001193125-12-463263:mdna:112]

[0001445305-13-000191:mdna:131]
The following table shows a reconciliation of weighted-average shares used in computing net loss per share of common stock-diluted to weighted-average shares used in computing non-GAAP diluted net income per share of common stock:

[0001445305-13-000191:mdna:132]
|  | Three Months Ended December 31, |  | Six Months Ended December 31, |
|  | 2012 |  | 2011 |  | 2012 |  | 2011 |
|  | (In thousands) |  | (In thousands) |
| Weighted average shares used in computing net loss per share of common stock- diluted | 90,056 |  |  | 90,056 |  |  | 91,493 |  |  | 75,102 |  |
| Weighted average dilutive effect of stock options and restricted stock units | — |  |  | — |  |  | — |  |  | 3,247 |  |
| Weighted average shares of Series A preferred stock outstanding | — |  |  | 3,390 |  |  | — |  |  | 15,131 |  |
| Weighted-average shares used in computing non-GAAP diluted income per share of common stock | 90,056 |  |  | 93,446 |  |  | 91,493 |  |  | 93,480 |  |
