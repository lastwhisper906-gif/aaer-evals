# UI note change history — 0001193125-12-463263 → 0001445305-13-000191


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2013-02-08):
[0001445305-13-000191:note_history:1]
COMMITMENTS AND CONTINGENCIES
  (was, 2012-11-09, similarity 0.8923):
[0001193125-12-463263:note_history:1]
NOTE 9—COMMITMENTS
AND CONTINGENCIES

- changed (2013-02-08):
[0001445305-13-000191:note_history:2]
In December 2011, the Company entered into an agreement to lease approximately 64,512 square feet of office and research and development space located in San Jose, California, which the Company uses as its corporate headquarters. The lease term is from April 1, 2012, through  June 30, 2017. The lease has been categorized as an operating lease, and the total estimated rent expense to be recognized is $4.9 million.
  (was, 2012-11-09, similarity 0.9646):
[0001193125-12-463263:note_history:2]
In December 2011, the
Company entered into an agreement to lease approximately 64,512
square feet of office and research and development space located in
San Jose, California, which will be used as the Company’s
corporate headquarters. The lease term is from April 1, 2012,
through June 30, 2017. The lease has been categorized as an
operating lease, and the total estimated rent expense to be
recognized is $4.9 million.

- changed (2013-02-08):
[0001445305-13-000191:note_history:3]
At December 31, 2012, future minimum annual payments under operating leases are as follows (in thousands):
  (was, 2012-11-09, similarity 0.9751):
[0001193125-12-463263:note_history:3]
At September 30, 2012,
future minimum annual payments under operating leases are as
follows (in thousands):

- changed (2013-02-08):
[0001445305-13-000191:note_history:4]
|  | 2013(remainder) |  | 2014 |  | 2015 |  | 2016 |  | 2017 |  | Thereafter |  | Total |
| Operating leases | $ | 750 |  |  | $ | 1,505 |  |  | $ | 1,465 |  |  | $ | 1,423 |  |  | $ | 1,117 |  |  | $ | 188 |  |  | $ | 6,448 |  |
  (was, 2012-11-09, similarity 0.8914):
[0001193125-12-463263:note_history:4]
|  |  | 2013 (remainder) |  |  | 2014 |  |  | 2015 |  |  | 2016 |  |  | 2017 |  |  | Thereafter |  |  | Total |  |
| Operating leases |  | $ | 1,078 |  |  | $ | 1,384 |  |  | $ | 1,396 |  |  | $ | 1,428 |  |  | $ | 1,122 |  |  | $ | — |  |  | $ | 6,408 |  |

- changed (2013-02-08):
[0001445305-13-000191:note_history:5]
The Company subcontracts with other companies to manufacture its products. During the normal course of business, the Company’s contract manufacturers procure components based upon orders placed by the Company. If the Company cancels all or part of the orders, it may still be liable to the contract manufacturers for the cost of the components purchased by them to manufacture the Company’s products. The Company periodically reviews the potential liability and to date no significant accruals have been recorded. The Company’s consolidated financial position and results of operations could be negatively impacted if it were required to compensate the contract manufacturers for any liabilities incurred.
  (was, 2012-11-09, similarity 0.6853):
[0001193125-12-463263:note_history:5]
The Company subcontracts
with other companies to manufacture its products. During the normal
course of business, the Company’s contract manufacturers
procure components based upon orders placed by the Company. If the
Company cancels all or part of the orders, it may still be liable
to the contract manufacturers for the cost of the components
purchased by them to manufacture the Company’s products. The
Company periodically reviews the potential liability and to date no
accruals have been recorded. The Company’s consolidated
financial position and results of operations could be negatively
impacted if it were required to compensate the contract
manufacturers for any liabilities incurred.

- changed (2013-02-08):
[0001445305-13-000191:note_history:6]
The Company may be involved, from time to time, in a variety of claims, lawsuits, investigations, and proceedings relating to contractual disputes, intellectual property rights, employment matters, regulatory compliance matters and other litigation matters relating to various claims that arise in the normal course of business. The Company determines whether an estimated loss from a contingency should be accrued by assessing whether a loss is deemed probable and can be reasonably estimated. The Company assesses its potential liability by analyzing specific litigation and regulatory matters using available information. The Company develops its views on estimated losses in consultation with inside and outside counsel, which involves a subjective analysis of potential results and outcomes, assuming various combinations of appropriate litigation and settlement strategies. Taking all of the above factors into account, the Company records an amount where it is probable that the Company will incur a loss and where that loss can be reasonably estimated. However, the Company’s estimates may be incorrect and the Company could ultimately incur more or less than the amounts initially recorded. Litigation can be costly, diverting management’s attention and could, upon resolution, have a material adverse effect on the Company’s business, results of operations, financial condition, and cash flows.
  (was, 2012-11-09, similarity 0.9153):
[0001193125-12-463263:note_history:6]
The Company may be
involved, from time to time, in a variety of claims, lawsuits,
investigations, and proceedings relating to contractual disputes,
intellectual property rights, employment matters, regulatory
compliance matters and other litigation matters relating to various
claims that arise in the normal course of business. The Company
determines whether an estimated loss from a contingency should be
accrued by assessing whether a loss is deemed probable and can be
reasonably estimated. The Company assesses its potential liability
by analyzing specific litigation and regulatory matters using
available information. The Company develops its views on estimated
losses in consultation with inside and outside counsel, which
involves a subjective analysis of potential results and outcomes,
assuming various combinations of appropriate litigation and
settlement strategies. Because of the uncertainties related to both
the amount and ranges of possible loss from pending litigation
matters, the Company is unable to predict with certainty the
precise liability that could finally result from a range of
possible unfavorable outcomes. Taking all of the above factors into
account, the Company records an amount where it is probable that
the Company will incur a loss and where that loss can be reasonably
estimated. However, the Company’s estimates may be incorrect
and the Company could ultimately incur more or less than the
amounts initially recorded. Litigation can be costly, diverting
management’s attention and could, upon resolution, have a
material adverse effect on the Company’s business, results of
operations, financial condition, and cash flows.

- added (2013-02-08):
[0001445305-13-000191:note_history:7]
In January 2011, the U.S. Commerce Department, Bureau of Industry and Security’s (“BIS”) Office of Export Enforcement (“OEE”) contacted the Company to request that the Company provide information related to its relationship with a logistics company in the United Arab Emirates (“UAE”) and with a company in Iran, as well as information on the export classification of its products. As a result of this inquiry the Company, assisted by outside counsel, conducted a review of the Company's export transactions from 2008 through March 2011 to not only gather information responsive to the OEE's request but also to review the Company's overall compliance with export control and sanctions laws.  The Company believes its products have been sold into Iran by third parties. The Company does not believe that it directly sold, exported or shipped its products into Iran or any other country subject to a U.S. embargo. However, until early 2010, the Company did not prohibit its distributors from selling its products into Iran or any other country subject to a U.S. embargo. In the course of this review the Company identified that two distributors may have sold the Company's products into Iran. The Company's review also found that while it had obtained required Commodity Classification Rulings for its products in June 2010 and November 2010, the Company did not advise its shipping personnel to change the export authorizations used on its shipping documents until February 2011. During the course of the Company's export control review, the Company also determined that it had failed to maintain adequate records for the five year period required by the EAR and the sanctions regulations due to its lack of infrastructure and because it was prior to its transition to its current system of record, NetSuite.

- changed (2013-02-08):
[0001445305-13-000191:note_history:8]
In May 2011, the Company filed a self-disclosure statement with the BIS and OEE.  In June 2011, the Company filed a self-disclosure statement with the U.S. Department of the Treasury’s Office of Foreign Asset Control (“OFAC”) regarding the compliance issues noted above. The disclosures address the above described findings and the remedial actions the Company had taken to date. However, the findings also indicate that both distributors continued to sell, directly or indirectly, the Company’s products into Iran during the period from February 2010 through March 2011 and that the Company received various communications from them indicating that they were continuing to do so. Since January 2011, the Company has cooperated with OEE and, prior to its disclosure filing, the Company informally shared with the OEE the substance of its findings with respect to both distributors. From May 2011 to August 2011, the Company provided additional information regarding its review and its findings to OEE to facilitate its investigation and OEE advised the Company in August 2011 that it had completed its investigation of the Company. In August 2011, the Company received a warning letter from OEE stating that OEE had not referred the findings of the Company’s review for criminal or administrative prosecution and closed the investigation of the Company without penalty.
  (was, 2012-11-09, similarity 0.9532):
[0001193125-12-463263:note_history:8]
In May 2011, the Company
filed a self-disclosure with the BIS and Security’s Office of
Export Enforcement OEE and in June 2011, filed one with U.S.
Department of the Treasury’s Office of Foreign Asset Control
(“OFAC”) regarding the compliance issues noted above.
The disclosures address the above described findings and the
remedial actions the Company had taken to date. However, the
findings also indicate that both distributors continued to sell,
directly or indirectly, the Company’s products into Iran
during the period from February 2010 through March 2011 and that
the Company received various communications from them indicating
that they were continuing to do so. Since January 2011, the Company
has cooperated with OEE and, prior to its disclosure filing, the
Company informally shared with the OEE the substance of its
findings with respect to both distributors. From May 2011 to August
2011, the Company provided additional information regarding its
review and its findings to OEE to facilitate its investigation and
OEE advised the Company in August 2011 that it had completed its
investigation of the Company. In August 2011, the Company received
a warning letter from OEE stating that OEE had not referred the
findings of the Company’s review for criminal or
administrative prosecution of us and closed the investigation of
the Company without penalty.

- changed (2013-02-08):
[0001445305-13-000191:note_history:9]
While the Company has now taken actions to ensure that export classification information is distributed to the appropriate personnel in a timely manner and has adopted policies and procedures to promote its compliance with these laws and regulations, including obtaining written distribution agreements with substantially all of its distributors that contain covenants requiring compliance with U.S. export control and economic sanctions law; notifying all of its distributors of their obligations and obtaining updated distribution agreements from distributors that accounted for approximately 99% of its revenue in fiscal 2012.  The Company's failure to amend all its distribution agreements and to implement more robust compliance controls immediately after the discovery of Iran-related sales activity in early 2010 may be aggravating factors that could impact the imposition of penalties imposed on the Company or its management.  Based on the facts known to the Company to date, the Company recorded an expense of $1.6 million for this export compliance matter in fiscal 2010, which represents management’s estimated exposure for fines in accordance with applicable accounting literature. This amount was calculated from information discovered through the Company’s internal review and this loss is deemed to be probable and reasonably estimable. However, the Company also believes that it is reasonably possible that the loss may be higher, but the Company cannot reasonably estimate the range of any further potential losses. Specific information has come to management’s attention and as such management cannot estimate any further range of possible losses. Should additional facts be discovered in the future and/or should actual fines or other penalties substantially differ from the Company’s estimates, its business, financial condition, cash flows and results of operations would be materially negatively impacted.
  (was, 2012-11-09, similarity 0.6805):
[0001193125-12-463263:note_history:9]
Based on the facts known to
the Company to date, the Company recorded an expense of $1.6
million for this export compliance matter in fiscal 2010, which
represents management’s estimated exposure for fines in
accordance with applicable accounting literature. This amount was
calculated from information discovered through the Company’s
internal review and this loss is deemed to be probable and
reasonably estimable. However, the Company also believes that it is
reasonably possible that the loss may be higher, but the Company
cannot reasonably estimate the range of any further potential
losses. Specific information has come to management’s
attention and as such management cannot estimate any further range
of possible losses. Should additional facts be discovered in the
future and/or should actual fines or other penalties substantially
differ from the Company’s estimates, its business, financial
condition, cash flows and results of operations would be materially
negatively impacted.

- added (2013-02-08):
[0001445305-13-000191:note_history:10]
Beginning on September 7, 2012, two shareholder class action complaints were filed against the Company, certain of its officers and directors and the underwriters of the Company's initial public offering in the United States District Court for the Northern District of California. On January 30, 2013, the plaintiffs filed an Amended Consolidated Complaint, which alleges claims under the Securities Act of 1933, the Securities Exchange Act of 1934 and SEC Rule 10b-5 on behalf of a purported class of those who purchased the Company's common stock between October 14, 2011 and August 9, 2012 and/or acquired the Company's stock pursuant to or traceable to the registration statement for the initial public offering. The Amended Consolidated Complaint alleges that the defendants violated the federal securities laws by issuing false or misleading statements regarding the sale of counterfeit Company products.  The consolidated complaint seeks, among other things, damages and interest, rescission, and attorneys' fees and costs.

- added (2013-02-08):
[0001445305-13-000191:note_history:11]
The Company believes that the allegations in the consolidated complaint are without merit and intend to vigorously contest the litigation. However, there can be no assurance that the Company will be successful in its defense. Because the case is at a very early stage, the Company cannot currently estimate the loss or the range of possible losses we may experience in connection with this litigation.

- removed (2013-02-08):
[0001193125-12-463263:note_history:12]
In January 2011, the U.S.
Commerce Department, Bureau of Industry and Security’s
(“BIS”) Office of Export Enforcement
(“OEE”) contacted the Company to request that the
Company provide information related to its relationship with a
logistics company in the UAE and with a company in Iran, as well as
information on the export classification of its products. As a
result of this inquiry the Company, assisted by outside counsel,
conducted a review of the Company’s export transactions from
2008 through March 2011 to not only gather information responsive
to the OEE’s request but also to review the Company’s
overall compliance with export control and sanctions laws. It was
in the course of this review that the Company identified the
Iranian sales of two of its distributors.

- removed (2013-02-08):
[0001193125-12-463263:note_history:13]
Beginning on
September 7, 2012, two shareholder class action complaints
were filed against the Company, certain of its officers and
directors and the underwriters of the Company’s initial
public offering in the United States District Court for the
Northern District of California. The complaints purport to
bring claims under the Securities Act of 1933, the Securities
Exchange Act of 1934 and SEC Rule 10b-5 on behalf a class of
purchasers of the Company’s common stock from
October 14, 2011 through August 9, 2012 and/or who
acquired the Company’s stock pursuant to or traceable to the
registration statement for the initial public offering. The
complaints seek, among other things, compensatory damages,
rescission, and attorneys’ fees and costs.

- removed (2013-02-08):
[0001193125-12-463263:note_history:14]
The Company believes that
the allegations in the complaints are without merit and intend to
vigorously contest the litigation. However, there can be no
assurance that the Company will be successful in its defense. The
Company cannot currently estimate the loss or the range of possible
losses it may experience in connection with this
litigation.


## us-gaap:BusinessDescriptionAndBasisOfPresentationTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2013-02-08):
[0001445305-13-000191:note_history:15]
BUSINESS AND BASIS OF PRESENTATION
  (was, 2012-11-09, similarity 0.9067):
[0001193125-12-463263:note_history:15]
NOTE 1—BUSINESS
AND BASIS OF PRESENTATION

- added (2013-02-08):
[0001445305-13-000191:note_history:16]
Business— Ubiquiti Networks, Inc. was incorporated in the State of California in 2003 as Pera Networks, Inc.  In 2005 the Company changed its name to Ubiquiti Networks, Inc. and commenced its current operations. In June 2010, the Company was re-incorporated in Delaware.

- changed (2013-02-08):
[0001445305-13-000191:note_history:17]
On October 13, 2011, the Company entered into an underwriting agreement for its initial public offering of common stock at $15.00 per share.  The Company's initial public offering closed on October 19, 2011. Immediately prior to the closing of the initial public offering, all outstanding shares of the Company’s preferred stock converted to common stock on a one for one basis.
  (was, 2012-11-09, similarity 0.928):
[0001193125-12-463263:note_history:17]
On October 13, 2011,
the Company entered into an underwriting agreement for its initial
public offering of its common stock at $15.00 per share, which
closed on October 19, 2011. Immediately prior to the closing
of the initial public offering, all outstanding shares of the
Company’s preferred stock converted to common stock on a one
for one basis.

- changed (2013-02-08):
[0001445305-13-000191:note_history:18]
These condensed consolidated financial statements should be read in conjunction with the Company’s audited consolidated financial statements for the fiscal year ended June 30, 2012 included in its Annual Report on Form 10-K, as filed on September 28, 2012 with the SEC (the “Annual Report”). The results of operations for the three and six months ended December 31, 2012 are not necessarily indicative of the results to be expected for any future periods.
  (was, 2012-11-09, similarity 0.7784):
[0001193125-12-463263:note_history:18]
These condensed
consolidated financial statements should be read in conjunction
with the Company’s audited consolidated financial statements
for the fiscal year ended June 30, 2012 included in its Annual
Report on Form 10-K, as filed on September 28, 2012 with the
SEC (the “Annual Report”). The results of operations
for the three months ended September 30, 2012 are not
necessarily indicative of the results to be expected for any future
periods.

- removed (2013-02-08):
[0001193125-12-463263:note_history:19]
Business—
Ubiquiti Networks, Inc. was incorporated in the State of California
in 2003 as Pera Networks, Inc. and commenced its current operations
in 2005 and changed its name to Ubiquiti Networks, Inc. at that
time. In June 2010, the Company changed its state of incorporation
to Delaware by merging with and into Ubiquiti Networks, Inc., a
Delaware corporation.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2013-02-08):
[0001445305-13-000191:note_history:20]
SUMMARY OF SIGNIFICANT ACCOUNTING POLICIES
  (was, 2012-11-09, similarity 0.9231):
[0001193125-12-463263:note_history:20]
NOTE 2—SUMMARY OF
SIGNIFICANT ACCOUNTING POLICIES


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2013-02-08):
[0001445305-13-000191:note_history:21]
DEBT

- changed (2013-02-08):
[0001445305-13-000191:note_history:22]
In July 2011, the Company repurchased an aggregate of 12,041,700 shares of the Company’s Series A convertible preferred stock from entities affiliated with Summit Partners, L.P., one of the Company’s major stockholders, at a price of $8.97 per share for an aggregate consideration of $108.0 million. Of the aggregate purchase price, $40.0 million was paid in cash at the time of closing and the balance of the shares were paid for through the issuance of convertible subordinated promissory notes in the aggregate principal amount of $68.0 million. On September 15, 2011, $34.0 million was paid against the notes and was financed through the Company's EWB Loan Agreement (as further described below) reducing the aggregate principal amount outstanding to $34.0 million. The remainder of the notes were retired in October 2011 with the proceeds of the Company’s initial public offering and existing cash balances. The interest rate on the notes started at 5% per annum and increased by two percentage points every three months until it would have reached 9% in January 2012. The notes were prepayable without penalty prior to April 21, 2012, and were required to be paid in the event of the Company’s initial public offering or third party financing prior to April 21, 2012. The notes matured on July 21, 2021. The unpaid principal on the notes was convertible into shares of Series A preferred stock at $8.97 per share at any point after July 21, 2012. The difference between the repurchase price and the carrying value of the repurchased preferred stock on June 30, 2011 was $59.0 million. The difference was debited to available retained earnings with the remaining amount debited to additional paid-in capital and reduced the net income attributable to common stock shareholders resulting in a reduction of basic and diluted net income per share.
  (was, 2012-11-09, similarity 0.9748):
[0001193125-12-463263:note_history:22]
In July 2011, the Company
repurchased an aggregate of 12,041,700 shares of the
Company’s Series A convertible preferred stock from entities
affiliated with Summit Partners, L.P., one of the Company’s
major stockholders, at a price of $8.97 per share for an aggregate
consideration of $108.0 million. Of the aggregate purchase price,
$40.0 million was paid in cash at the time of closing and the
balance of the shares were paid for through the issuance of
convertible subordinated promissory notes in the aggregate
principal amount of $68.0 million. On September 15, 2011,
$34.0 million was paid against the notes reducing the aggregate
principal amount outstanding to $34.0 million. The remainder of the
notes were retired in October 2011 with the proceeds of the
Company’s initial public offering and existing cash balances.
The interest rate on the notes started at 5% per annum and
increased by two percentage points every three months until it
would have reached 9% in January 2012. The notes were prepayable
without penalty prior to April 21, 2012, and were required to
be paid in the event of the Company’s initial public offering
or third party financing prior to April 21, 2012. The notes
matured on July 21, 2021. The unpaid principal on the notes
was convertible into shares of Series A preferred stock at $8.97
per share at any point after July 21, 2012. The difference
between the repurchase price and the carrying value of the
repurchased preferred stock on June 30, 2011 was $59.0
million. The difference was debited to available retained earnings
with the remaining amount debited to additional paid-in capital and
reduced the net income attributable to common stock shareholders
resulting in a reduction of basic and diluted net income per
share.

- added (2013-02-08):
[0001445305-13-000191:note_history:23]
On September 15, 2011, the Company entered into a Loan and Security Agreement with East West Bank, (the “EWB Loan Agreement”), which was replaced by the Loan Agreement as discussed below. The credit facilities available under the EWB Loan Agreement consist of a $35.0 million term loan facility and a $5.0 million revolving line of credit facility. The term loan matures on September 15, 2016 with principal and interest to be repaid in 60 monthly installments. The Company used $34.0 million of the term loan to repay a portion of the outstanding convertible subordinated promissory notes held by entities affiliated with Summit Partners, L.P leaving $1.0 million available for borrowing under the term loan facility.

- changed (2013-02-08):
[0001445305-13-000191:note_history:24]
On August 7, 2012, the Company entered into a Loan and Security Agreement (the “Loan Agreement”) with U.S. Bank, as syndication agent, and East West Bank, as administrative agent for the lenders party to the Loan Agreement. The Loan Agreement replaced the EWB Loan Agreement discussed above. The Loan Agreement provides for (i) a $50.0 million revolving credit facility, with a $5.0 million sublimit for the issuance of letters of credit and a $5.0 million sublimit for the making of swingline loan advances (the “Revolving Credit Facility”), and (ii) a $50.0 million term loan facility (the “Term Loan Facility”). The Company may request borrowings under the Revolving Credit Facility until August 7, 2015. On August 7, 2012, the Company borrowed $20.8 million under the Term Loan Facility, and no borrowings remain available for borrowing thereunder.  On November 21, 2012, the Company borrowed $10.0 million under the Revolving Credit Facility. On December 20, 2012, the Company borrowed an additional $20.0 million under the Revolving Credit Facility, and $20.0 million remains available for borrowing thereunder.
  (was, 2012-11-09, similarity 0.7242):
[0001193125-12-463263:note_history:24]
Additionally, on
August 7, 2012, the Company entered into a Loan and Security
Agreement (the “Loan Agreement”) with U.S. Bank, as
syndication agent, and East West Bank, as administrative agent. The
Loan Agreement replaces the EWB Loan Agreement as discussed above.
The Loan Agreement provides for (i) a $50.0 million revolving
credit facility, with a $5.0 million sublimit for the issuance of
letters of credit and a $5.0 million sublimit for the making of
swingline loan advances (the “Revolving Credit
Facility”), and (ii) a $50.0 million term loan facility
(the “Term Loan Facility”). The Company may request
borrowings under the Revolving Credit Facility until August 7,
2015. On August 7, 2012, the Company borrowed an additional
$20.8 million of term loans under the Term Loan
Facility.

- changed (2013-02-08):
[0001445305-13-000191:note_history:25]
The loans bear interest, at the Company’s option, at the base rate plus a spread of 1.25% to 1.75% or an adjusted LIBOR rate (at the Company’s election, for a period of 30, 60, or 90 days) plus a spread of 2.25% to 2.75%, in each case with such spread being determined based on the debt service coverage ratio for its most recently ended fiscal quarter. The base rate is the highest of (i) East West Bank’s prime rate, (ii) the federal funds rate plus a margin equal to 0.50%, or (iii) the LIBOR rate plus a margin equal to 1.00%. The Company is also obligated to pay other customary closing fees, arrangement fees, administration fees, commitment fees and letter of credit fees for a credit facility of this size and type.
  (was, 2012-11-09, similarity 0.9083):
[0001193125-12-463263:note_history:25]
The loans bear interest, at
the Company’s option, at the base rate plus a spread of 1.25%
to 1.75% or an adjusted LIBOR rate (based, at the Company’s
election, on a period of 30, 60, or 90 days) plus a spread of 2.25%
to 2.75%, in each case with such spread being determined based on
the debt service coverage ratio for the last fiscal quarter. The
base rate means the highest of East West Bank’s prime rate,
the federal funds rate plus a margin equal to 0.50%, or the
adjusted LIBOR rate for a period of 30, 60, or 90 days plus a
margin equal to 1.00%. The Company is also obligated to pay other
customary closing fees, arrangement fees, administration fees,
commitment fees and letter of credit fees for a credit facility of
this size and type.

- added (2013-02-08):
[0001445305-13-000191:note_history:26]
Interest is due and payable monthly in arrears in the case of loans bearing interest at the base rate and at the end of an interest period in the case of loans bearing interest at the adjusted LIBOR rate. Principal payments under the Term Loan Facility will be made in quarterly installments on the first day of each calendar quarter, and each such quarterly installment shall be equal to $1.25 million through July 1, 2014, then equal to $1.875 million from October 1, 2014 through July 1 2015, and then equal to $2.5 million from October 1, 2015 through July 1, 2017, with the remaining outstanding principal balance and all accrued and unpaid interest due on August 7, 2017. All outstanding loans under the Revolving Credit Facility, together with all accrued and unpaid interest, are due on August 7, 2015.

- changed (2013-02-08):
[0001445305-13-000191:note_history:27]
The Company may prepay the loans, in whole or in part, at any time without premium or penalty, subject to certain conditions including minimum amounts and reimbursement of certain costs in the case of prepayments of LIBOR loans. In addition, the Company is required to prepay the loan under the Term Loan Facility with (i) the proceeds from certain financing transactions or asset sales (subject, in the case of asset sales, to reinvestment rights) and (ii) 25.0% of the Company’s excess cash flow in the U.S., as determined after each fiscal year and in accordance with the Loan Agreement, provided that the Company shall not be required to prepay the loan out of its excess cash flow if its leverage ratio is greater than 1.50:1.00 on the last day of such fiscal year.
  (was, 2012-11-09, similarity 0.9841):
[0001193125-12-463263:note_history:27]
The Company may prepay the
loans, in whole or in part, at any time without premium or penalty,
subject to certain conditions including minimum amounts and
reimbursement of certain costs in the case of prepayments of LIBOR
loans. In addition, the Company is required to prepay the loan
under the Term Loan Facility with the proceeds from certain
financing transactions or asset sales (subject, in the case of
asset sales, to reinvestment rights) and with 25.0% of the
Company’s excess cash flow, as determined after each fiscal
year and in accordance with the Loan Agreement, provided that the
Company shall not be required to prepay the loan out of its excess
cash flow if its leverage ratio is greater than 1.50:1.00 on the
last day of such fiscal year.

- added (2013-02-08):
[0001445305-13-000191:note_history:28]
All of the obligations of the Company under the Loan Agreement are collateralized by substantially all of the Company’s assets, including all of the capital stock of the Company’s future domestic subsidiaries and 65% of the capital stock of the Company’s existing and future foreign subsidiaries, but excluding the Company’s intellectual property, which is subject to a negative pledge agreement. All of the Company’s future domestic subsidiaries are required to guaranty the obligations under the Loan Agreement. Such guarantees by future subsidiaries will be collateralized by substantially all of the property of such subsidiaries, excluding intellectual property.

- changed (2013-02-08):
[0001445305-13-000191:note_history:29]
The Loan Agreement contains customary affirmative and negative covenants, including covenants that limit or restrict the Company and its subsidiaries’ ability to, among other things, incur indebtedness, grant liens, merge or consolidate, dispose of assets, pay dividends or make distributions, make investments, make acquisitions, prepay certain indebtedness, change the nature of its business, enter into certain transactions with affiliates, enter into restrictive agreements, and make capital expenditures, in each case subject to customary exceptions for a credit facility of this size and type. The Company is also required to maintain a minimum debt service coverage ratio, a maximum leverage ratio, and a minimum liquidity ratio.  As of December 31, 2012, the Company was in compliance with all affirmative and negative covenants, debt service coverage ratio, leverage ratio and liquidity ratio requirements.
  (was, 2012-11-09, similarity 0.8306):
[0001193125-12-463263:note_history:29]
The Loan Agreement contains
customary affirmative and negative covenants, including covenants
that limit or restrict the Company and its subsidiaries’
ability to, among other things, incur indebtedness, grant liens,
merge or consolidate, dispose of assets, pay dividends or make
distributions, make investments, make acquisitions, prepay certain
indebtedness, change the nature of its business, enter into certain
transactions with affiliates, enter into restrictive agreements,
and make capital expenditures, in each case subject to customary
exceptions for a credit facility of this size and type. The Company
is also required to maintain compliance with a debt service
coverage ratio, a leverage ratio, and a minimum level of
liquidity.

- added (2013-02-08):
[0001445305-13-000191:note_history:30]
The Loan Agreement includes customary events of default that, include among other things, defaults for the failure to timely pay principal, interest, or other amounts due, defaults due to the inaccuracy of representations and warranties, covenant defaults, a cross default to material indebtedness, bankruptcy and insolvency defaults, material judgment defaults, defaults due to the unenforceability of a guaranty, and defaults due to circumstances that have or could reasonably be expected to have a material adverse effect on the Company's business, operations or financial condition, its ability to pay or perform under the Loan Agreement, or on the lenders' security interests. The occurrence of an event of default could result in the acceleration of the obligations under the Loan Agreement. During the existence of an event of default, interest on the obligations under the Loan Agreement could be increased by 2.00% above the otherwise applicable interest rate.

- added (2013-02-08):
[0001445305-13-000191:note_history:31]
During the three and six months ended December 31, 2012, the Company made aggregate payments of $1.3 million and $1.8 million, respectively, against the loan balance.  As of December 31, 2012, the Company has classified $5.0 million and $73.6 million in short-term and long-term debt, respectively, on its consolidated balance sheet related to the Loan Agreement.

- changed (2013-02-08):
[0001445305-13-000191:note_history:32]
The following table summarizes our estimated debt and interest payment obligations as of December 31, 2012 (in thousands):
  (was, 2012-11-09, similarity 0.9787):
[0001193125-12-463263:note_history:32]
The following table
summarizes our estimated debt and interest payment obligations as
of September 30, 2012 (in thousands):

- added (2013-02-08):
[0001445305-13-000191:note_history:33]
|  | 2013(remainder) |  | 2014 |  | 2015 |  | 2016 |  | 2017 |  | Thereafter |  | Total |
| Debt payment obligations | $ | 2,500 |  |  | $ | 5,000 |  |  | $ | 6,875 |  |  | $ | 39,375 |  |  | $ | 10,000 |  |  | $ | 15,000 |  |  | $ | 78,750 |  |
| Interest payments on debt payment obligations | 542 |  |  | 1,859 |  |  | 1,723 |  |  | 1,043 |  |  | 532 |  |  | 125 |  |  | 5,824 |  |
| Total | $ | 3,042 |  |  | $ | 6,859 |  |  | $ | 8,598 |  |  | $ | 40,418 |  |  | $ | 10,532 |  |  | $ | 15,125 |  |  | $ | 84,574 |  |

- removed (2013-02-08):
[0001193125-12-463263:note_history:34]
NOTE
8—DEBT

- removed (2013-02-08):
[0001193125-12-463263:note_history:35]
On September 15, 2011,
the Company entered into a Loan and Security Agreement with East
West Bank, (the “EWB Loan Agreement”). The credit
facilities available under the EWB Loan Agreement consist of a
$35.0 million term loan facility and a $5.0 million revolving line
of credit facility. The term loan matures on September 15,
2016 with principal and interest to be repaid in 60 monthly
installments. The Company used $34.0 million of the term loan to
repay a portion of the outstanding convertible subordinated
promissory notes held by entities affiliated with Summit Partners,
L.P. leaving an aggregate amount owed under the promissory note of
$34.0 million. The $5.0 million revolving line of credit may be
drawn at any time prior to September 15, 2013. The amounts
outstanding under both the term loan and the revolving line of
credit facility may be voluntarily prepaid at any time without
premium or penalty, subject to certain conditions. Interest will
accrue on the outstanding principal amount of the term loan at a
rate per annum equal to an adjusted LIBOR rate (based on one, two
or three month interest periods) plus a spread of either 2.50% or
3.00%, which spread shall be determined based on the debt service
ratio for the preceding four fiscal quarter period. Interest will
accrue on the drawn portion of the revolving credit facility at the
prime rate plus a spread of 0.25%, provided that such rate shall
not be less than the one-month adjusted LIBOR rate plus a spread of
1.00%, and will be paid monthly. The Company is required to pay a
commitment fee of 0.15% per annum on the undrawn portion of
the revolving credit facility on a quarterly basis. The EWB Loan
Agreement includes customary covenants, including financial
reporting requirements and compliance with a debt service coverage
ratio and a total leverage ratio, and customary events of default.
The Company’s obligations under the EWB Loan Agreement are
secured by a first priority security position on substantially all
of the Company’s current and future assets, subject to
certain exceptions (including a negative pledge on the
Company’s intellectual property) and permitted
liens.

- removed (2013-02-08):
[0001193125-12-463263:note_history:36]
Interest is due and payable
in arrears monthly in the case of loans bearing interest at the
base rate and at the end of an interest period (or quarterly in the
case of loans with interest periods greater than three months) in
the case of loans bearing interest at the adjusted LIBOR rate.
Principal payments under the Term Loan Facility will be made in
quarterly installments, each such quarterly installment shall be
equal to $1.25 million until August 7, 2014, then equal to
$1.875 million until August 7, 2015, and then equal to $2.5
million until August 7, 2017, subject to adjustment as a
result of any prepayments, with the remaining outstanding principal
balance and all accrued and unpaid interest due on August 7,
2017. All outstanding loans under the Revolving Credit Facility,
together with all accrued and unpaid interest, are due on
August 7, 2015.

- removed (2013-02-08):
[0001193125-12-463263:note_history:37]
All of the obligations
under the Loan Agreement are secured by substantially all of the
Company’s assets, including all of the capital stock of the
Company’s future domestic subsidiaries and 65% of the capital
stock of the Company’s existing and future foreign
subsidiaries, but excluding the Company’s intellectual
property. All of the Company’s future domestic subsidiaries
are required to guaranty the obligations under the Loan Agreement.
Such guarantees by future subsidiaries will be secured by
substantially all of the property of such subsidiaries, excluding
intellectual property.

- removed (2013-02-08):
[0001193125-12-463263:note_history:38]
The Loan Agreement includes
customary events of default that, include among other things,
non-payment defaults, defaults due to the inaccuracy of
representations and warranties, covenant defaults, cross default to
material indebtedness, bankruptcy and insolvency defaults, material
judgment defaults, defaults due to the unenforceability of a
guaranty, and defaults due to circumstances that have or could have
a material adverse effect. The occurrence of an event of default
could result in the acceleration of the obligations under the Loan
Agreement. During the existence of an event of default, interest on
the obligations under the Loan Agreement could be increased by
2.00% above the otherwise applicable interest rate.

- removed (2013-02-08):
[0001193125-12-463263:note_history:39]
During the three months
ended September 30, 2012, the Company made aggregate payments
of $583,000 against the loan balance. As of September 30,
2012, the Company has classified $5.0 million and $44.8 million in
short-term and long-term debt, respectively, on its consolidated
balance sheet related to the Loan Agreement.

- removed (2013-02-08):
[0001193125-12-463263:note_history:40]
|  |  | 2013 (remainder) |  |  | 2014 |  |  | 2015 |  |  | 2016 |  |  | 2017 |  |  | Thereafter |  |  | Total |  |
| Debt payment obligations |  | $ | 3,750 |  |  | $ | 5,000 |  |  | $ | 6,875 |  |  | $ | 9,375 |  |  | $ | 10,000 |  |  | $ | 15,000 |  |  | $ | 50,000 |  |
| Interest payments on debt payment obligations |  |  | 914 |  |  |  | 1,110 |  |  |  | 973 |  |  |  | 777 |  |  |  | 531 |  |  |  | 172 |  |  |  | 4,477 |  |
| Total |  | $ | 4,664 |  |  | $ | 6,110 |  |  | $ | 7,848 |  |  | $ | 10,152 |  |  | $ | 10,531 |  |  | $ | 15,172 |  |  | $ | 54,477 |  |


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2013-02-08):
[0001445305-13-000191:note_history:41]
The following table summarizes our estimated debt and interest payment obligations as of December 31, 2012 (in thousands):
  (was, 2012-11-09, similarity 0.9787):
[0001193125-12-463263:note_history:41]
The following table
summarizes our estimated debt and interest payment obligations as
of September 30, 2012 (in thousands):

- added (2013-02-08):
[0001445305-13-000191:note_history:42]
|  | 2013(remainder) |  | 2014 |  | 2015 |  | 2016 |  | 2017 |  | Thereafter |  | Total |
| Debt payment obligations | $ | 2,500 |  |  | $ | 5,000 |  |  | $ | 6,875 |  |  | $ | 39,375 |  |  | $ | 10,000 |  |  | $ | 15,000 |  |  | $ | 78,750 |  |
| Interest payments on debt payment obligations | 542 |  |  | 1,859 |  |  | 1,723 |  |  | 1,043 |  |  | 532 |  |  | 125 |  |  | 5,824 |  |
| Total | $ | 3,042 |  |  | $ | 6,859 |  |  | $ | 8,598 |  |  | $ | 40,418 |  |  | $ | 10,532 |  |  | $ | 15,125 |  |  | $ | 84,574 |  |

- removed (2013-02-08):
[0001193125-12-463263:note_history:43]
|  |  | 2013 (remainder) |  |  | 2014 |  |  | 2015 |  |  | 2016 |  |  | 2017 |  |  | Thereafter |  |  | Total |  |
| Debt payment obligations |  | $ | 3,750 |  |  | $ | 5,000 |  |  | $ | 6,875 |  |  | $ | 9,375 |  |  | $ | 10,000 |  |  | $ | 15,000 |  |  | $ | 50,000 |  |
| Interest payments on debt payment obligations |  |  | 914 |  |  |  | 1,110 |  |  |  | 973 |  |  |  | 777 |  |  |  | 531 |  |  |  | 172 |  |  |  | 4,477 |  |
| Total |  | $ | 4,664 |  |  | $ | 6,110 |  |  | $ | 7,848 |  |  | $ | 10,152 |  |  | $ | 10,531 |  |  | $ | 15,172 |  |  | $ | 54,477 |  |
