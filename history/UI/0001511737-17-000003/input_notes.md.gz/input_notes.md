# UI notes — 0001511737-17-000003


## ubnt:ScheduleOfRevenueAndAccountsReceivableByMajorCustomersByReportingSegmentsTableTableTextBlock

[0001511737-17-000003:notes:1]
[same as prior period, unchanged from 0001511737-16-000045:notes:1]

[0001511737-17-000003:notes:2]
|  | Percentage of Revenues |  | Percentage of Accounts Receivable |
|  | Three Months Ended December 31, |  | Six Months Ended December 31, |  | December 31, |  | June 30, |
|  | 2016 |  | 2015 |  | 2016 |  | 2015 |  | 2016 |  | 2016 |
| Customer A | * |  | * |  | * |  | * |  | 11% |  | 11% |
| Customer B | * |  | * |  | * |  | * |  | * |  | 13% |
| Customer C | 12% |  | * |  | 11% |  | * |  | 20% |  | 18% |
| Customer D | * |  | 13% |  | * |  | 11% |  | * |  | * |

[0001511737-17-000003:notes:3]
[same as prior period, unchanged from 0001511737-16-000045:notes:3]


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001511737-17-000003:notes:4]
[same as prior period, unchanged from 0001511737-16-000045:notes:4]

[0001511737-17-000003:notes:5]
These consolidated financial statements should be read in conjunction with the Company’s audited consolidated financial statements for the fiscal year ended June 30, 2016, included in its Annual Report on Form 10-K, as filed with the SEC on August 22, 2016 (the “Annual Report”). The results of operations for the three and six months ended December 31, 2016 are not necessarily indicative of the results to be expected for any future periods.


## us-gaap:BusinessDescriptionAndBasisOfPresentationTextBlock

[0001511737-17-000003:notes:6]
[same as prior period, unchanged from 0001511737-16-000045:notes:6]

[0001511737-17-000003:notes:7]
Business— Ubiquiti Networks, Inc. was incorporated in the State of California in 2003 as Pera Networks, Inc.  In 2005, Pera Networks, Inc. changed its name to Ubiquiti Networks, Inc. and commenced its current operations. In June 2010, Ubiquiti Networks, Inc. was re-incorporated in Delaware.

[0001511737-17-000003:notes:8]
[same as prior period, unchanged from 0001511737-16-000045:notes:8]

[0001511737-17-000003:notes:9]
[same as prior period, unchanged from 0001511737-16-000045:notes:9]


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001511737-17-000003:notes:10]
COMMITMENTS AND CONTINGENCIES

[0001511737-17-000003:notes:11]
Operating Leases

[0001511737-17-000003:notes:12]
Certain facilities and equipment are leased under non-cancelable operating leases. The Company generally pays taxes, insurance and maintenance costs on leased facilities and equipment. The Company leases its headquarters in San Jose, California and other locations under non-cancelable operating leases that expire at various dates through fiscal 2022.

[0001511737-17-000003:notes:13]
At December 31, 2016, future minimum annual payments under operating leases for the remainder of fiscal 2017 and future fiscal years are as follows (in thousands):

[0001511737-17-000003:notes:14]
|  | 2017 (remainder) |  | 2018 |  | 2019 |  | 2020 |  | 2021 |  | Thereafter |  | Total |
| Operating leases | $ | 3,678 |  |  | $ | 5,153 |  |  | $ | 2,576 |  |  | $ | 1,744 |  |  | $ | 1,085 |  |  | $ | 375 |  |  | $ | 14,611 |  |

[0001511737-17-000003:notes:15]
Purchase Obligations

[0001511737-17-000003:notes:16]
The Company primarily subcontracts with other companies to manufacture its products. During the normal course of business, the Company’s contract manufacturers procure components based upon orders placed by the Company. If the Company cancels all or part of the orders, it may still be liable to the contract manufacturers for the cost of the components purchased by them to manufacture the Company’s products. The Company periodically reviews the potential liability under its orders, and no significant accruals have been recorded as of December 31, 2016.  The Company had inventory purchase obligations of $34.7 million as of December 31, 2016.

[0001511737-17-000003:notes:17]
Other Obligations

[0001511737-17-000003:notes:18]
The Company had other obligations of $9.9 million as of December 31, 2016, which consisted primarily of commitments related to research and development projects.

[0001511737-17-000003:notes:19]
Indemnification Obligations

[0001511737-17-000003:notes:20]
The Company enters into standard indemnification agreements with many of its business partners in the ordinary course of business. These agreements include provisions for indemnifying the business partner against any claim brought by a third-party to the extent any such claim alleges that a Company product infringes a patent, copyright or trademark, or violates any other proprietary rights of that third-party. The maximum potential amount of future payments the Company could be required to make under these indemnification agreements is not estimable and the Company has not incurred any material costs to defend lawsuits or settle claims related to these indemnification agreements to date.

[0001511737-17-000003:notes:21]
Legal Matters

[0001511737-17-000003:notes:22]
The Company may be involved, from time to time, in a variety of claims, lawsuits, investigations, and proceedings relating to contractual disputes, intellectual property rights, employment matters, regulatory compliance matters and other litigation matters relating to various claims that arise in the normal course of business. The Company determines whether an estimated loss from a contingency should be accrued by assessing whether a loss is deemed probable and can be reasonably estimated. The Company assesses its potential liability by analyzing specific litigation and regulatory matters using available information. The Company develops its views on estimated losses in consultation with inside and outside counsel, which involves a subjective analysis of potential results and outcomes, assuming various combinations of appropriate litigation and settlement strategies. Taking all of the above factors into account, the Company records an amount where it is probable that the Company will incur a loss and where that loss can be reasonably estimated. However, the Company’s estimates may be incorrect and the Company could ultimately incur more or less than the amounts initially recorded.  The Company may also incur significant legal fees, which are expensed as incurred, in defending against these claims. The Company is not currently aware of any pending or threatened litigation that would have a material adverse effect on the Company's financial statements.

[0001511737-17-000003:notes:23]
Shareholder Class Action Lawsuits

[0001511737-17-000003:notes:24]
Beginning on September 7, 2012, two class action lawsuits were filed in the United States District Court for the Northern District of California against Ubiquiti Networks, Inc., certain of our current and former officers and directors, and the underwriters of its initial public offering, alleging claims under U.S. securities laws. On January 30, 2013, the plaintiffs filed an amended consolidated complaint. On March 26, 2014, the court issued an order granting a motion to dismiss the complaint with leave to amend. Following the plaintiffs’ decision not to file an amended complaint, on April 16, 2014, the court ordered the dismissal of the lawsuit with prejudice, and entered judgment in favor of the Company and the other defendants, and against the plaintiffs. On May 15, 2014, the plaintiffs filed a notice of appeal from the judgment of the court. The Ninth Circuit heard oral arguments on August 10, 2016.  On October 24, 2016, the Ninth Circuit issued an unpublished opinion, reaffirming the district court’s dismissal of the alleged violation of Sections 10(b) and 20(a) of the Securities Exchange Act of 1934 and reversing the district court’s dismissal of the alleged violations of Sections 11 and 15 of the Securities Act of 1933. The Company filed a petition for rehearing with the Ninth Circuit, which the Ninth Circuit denied. The Company plans to vigorously defend itself against these claims; however, there can be no assurance that the Company will prevail in the lawsuit. The Company cannot currently estimate the possible loss, if any, that it may experience in connection with this litigation.


## us-gaap:DebtDisclosureTextBlock

[0001511737-17-000003:notes:25]
DEBT

[0001511737-17-000003:notes:26]
On March 3, 2015, Ubiquiti Networks, Inc. and Ubiquiti International Holding Company Limited (the “Cayman Borrower”) amended and restated its original credit agreement (the “Amended Credit Agreement”) with Wells Fargo Bank, National Association (“Wells Fargo”), the other financial institutions named as lenders therein, and Wells Fargo as administrative agent for the lenders.  The Amended Credit Agreement provides for a $200.0 million senior secured revolving credit facility ("Revolving Facility") and a $100.0 million senior secured term loan facility ("Term Facility", together with the Revolving Facility, the “Facilities”), with an option to request increases in the amounts of such credit facilities by up to an additional $50.0 million in the aggregate (any such increase to be in each lender’s sole discretion), and matures on March 3, 2020. The Facilities replaced the Company’s $150.0 million senior secured revolving credit facility under its original credit agreement. The $100.0 million term loan facility of the Amended Credit Agreement was fully drawn at closing, and $72.3 million was used to repay the outstanding balance under its original credit agreement. The Facilities are available for working capital and general corporate purposes that comply with the terms of the Amended Credit Agreement.

[0001511737-17-000003:notes:27]
Our Debt consisted of the following (in thousands):

[0001511737-17-000003:notes:28]
|  | December 31, 2016 |  | June 30, 2016 |
| Term Loan - short term | $ | 13,750 |  |  | $ | 11,250 |  |
| Debt issuance costs, net (1) | (257 | ) |  | (257 | ) |
| Total Debt - short term | 13,493 |  |  | 10,993 |  |
| Term Loan - long term | 68,750 |  |  | 76,250 |  |
| Revolver - long term | 116,000 |  |  | 116,000 |  |
| Debt issuance costs, net (1) | (556 | ) |  | (686 | ) |
| Total Debt - long term | $ | 184,194 |  |  | $ | 191,564 |  |

[0001511737-17-000003:notes:29]
(1) On July 1 2016, the Company retrospectively adopted ASU 2015-03, which requires unamortized debt issuance costs to be included as a direct deduction from the related debt liability on the balance sheet. Under previous guidance, all unamortized debt issuance costs were reported as assets on the balance sheet. See Note 2 for information on the impact of the retrospective adoption of ASU 2015-03.

[0001511737-17-000003:notes:30]
As of December 31, 2016, the interest rate on the term loan was 2.50%. The table below shows the respective interest rates as of December 31, 2016 in addition to interest rate reset dates and rates as available for each revolver draw.

[0001511737-17-000003:notes:31]
|  |  | Interest Rate as of |  |  |  |  |
| Debt Payment Obligations |  | December 31, 2016 |  | Rate Reset Date |  | Reset Rate |
| $15 Million Revolver |  | 2.42% |  | 1/9/2017 |  | 2.51% |
| $18 Million Revolver |  | 2.48% |  | 1/18/2017 |  | 2.52% |
| $16 Million Revolver |  | 2.70% |  | 2/13/2017 |  | * |
| $19 Million Revolver |  | 2.41% |  | 1/3/2017 |  | 2.50% |
| $48 Million Revolver |  | 2.44% |  | 2/28/2017 |  | * |

[0001511737-17-000003:notes:32]
* - Reset rate not available as of filing date.

[0001511737-17-000003:notes:33]
The Revolving Facility includes a sub-limit of $10.0 million for letters of credit and a sub-limit of $25.0 million for swingline loans. Under the Amended Credit Agreement, revolving loans and swingline loans may be borrowed, repaid and reborrowed until March 3, 2020, at which time all amounts borrowed must be repaid. The term loan is payable in quarterly installments of 2.50% of the original principal amount of the term loan until March 31, 2017, thereafter increasing to 3.75% of the original principal amount of the term loan, in each case plus accrued and unpaid interest. Revolving, swingline and term loans may be prepaid at any time without penalty.

[0001511737-17-000003:notes:34]
Revolving and term loans bear interest, at the Company’s option, at either (i) a floating rate per annum equal to the base rate plus a margin of between 0.50% and 1.25%, depending on the Company’s leverage ratio as of the most recently ended fiscal quarter or (ii) a floating per annum rate equal to the applicable LIBOR rate for a specified period, plus a margin of between 1.50% and 2.25%, depending on the Company’s leverage ratio as of the most recently ended fiscal quarter. Swingline loans bear interest at a floating rate per annum equal to the base rate plus a margin of between 0.50% and 1.25%, depending on the Company’s leverage ratio as of the most recently ended fiscal quarter.

[0001511737-17-000003:notes:35]
The Amended Credit Agreement requires the Company to maintain during the term of the Facilities (i) a maximum leverage ratio of 2.50 to 1.00 and (ii) minimum liquidity of $225.0 million, increasing to $250.0 million in the event of an incremental increase in the size of the Facilities, which can be satisfied with unrestricted cash and cash equivalents and up to $50.0 million of availability under the revolving credit facility. In addition, the Amended Credit Agreement contains customary affirmative and negative covenants and includes customary events of default. The occurrence of an event of default could result in the acceleration of the obligations under the Amended Credit Agreement.

[0001511737-17-000003:notes:36]
The obligations of Ubiquiti Networks, Inc. and certain domestic subsidiaries, if any, under the Amended Credit Agreement are required to be guaranteed by such domestic subsidiaries (the “Domestic Guarantors”) and are collateralized by substantially all assets (excluding intellectual property) of Ubiquiti Networks, Inc. and the Domestic Guarantors. The obligations of the Cayman Borrower and certain foreign subsidiaries under the Amended Credit Agreement are required to be guaranteed by certain domestic and material foreign subsidiaries (the “Guarantors”) and are collateralized by substantially all assets (excluding intellectual property) of the Cayman Borrower and the Guarantors.

[0001511737-17-000003:notes:37]
During the three months ended December 31, 2016, the Company made a payment of $3.0 million against the balance under the Term Facility, of which $2.5 million was a repayment of principal and $0.5 million was payment of interest. During the six months ended December 31, 2016, the Company made aggregate payments of $6.0 million against the balance under the Term Facility, of which $5.0 million was a repayment of principal and $1.0 million was payment of interest.

[0001511737-17-000003:notes:38]
During the three months ended December 31, 2016, the Company made a payment of $1.1 million of interest under the Revolving Facility. During the six months ended December 31, 2016, the Company made aggregate payments of $1.5 million of interest under the Revolving Facility.

[0001511737-17-000003:notes:39]
On September 2, 2015, the Company accessed a letter of credit under its Revolving Facility in the amount of $0.2 million for the benefit of the landlord pursuant to a new lease of office space. The landlord can draw against the letter of credit in the event of a lease default by the Company. The letter of credit expires on September 2, 2017, subject to automatic renewal for additional one-year periods.

[0001511737-17-000003:notes:40]
The following table summarizes our estimated debt and interest payment obligations as of December 31, 2016, for the remainder of fiscal 2017 and future fiscal years (in thousands):

[0001511737-17-000003:notes:41]
|  | 2017 (remainder) |  | 2018 |  | 2019 |  | 2020 |  | 2021 |  | Thereafter |  | Total |
| Debt payment obligations | $ | 6,250 |  |  | $ | 15,000 |  |  | $ | 15,000 |  |  | $ | 162,250 |  |  | $ | — |  |  | $ | — |  |  | $ | 198,500 |  |
| Interest and other payments on debt payment obligations (1) | 2,526 |  |  | 4,803 |  |  | 4,429 |  |  | 2,814 |  |  | — |  |  | — |  |  | 14,572 |  |
| Total | $ | 8,776 |  |  | $ | 19,803 |  |  | $ | 19,429 |  |  | $ | 165,064 |  |  | $ | — |  |  | $ | — |  |  | $ | 213,072 |  |

[0001511737-17-000003:notes:42]
(1) - Interest payments are calculated based on the applicable rates and payment dates as of December 31, 2016. Furthermore, two to three-month payment intervals on the revolving debt have been assumed, consistent with the Company's elections to date.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001511737-17-000003:notes:43]
[same as prior period, unchanged from 0001511737-16-000045:notes:42]

[0001511737-17-000003:notes:44]
[same as prior period, unchanged from 0001511737-16-000045:notes:43]

[0001511737-17-000003:notes:45]
The Company’s 2010 Equity Incentive Plan and 2005 Equity Incentive Plan are described in its Annual Report. As of December 31, 2016, the Company had 10,057,276 authorized shares available for future issuance under all of its stock incentive plans.

[0001511737-17-000003:notes:46]
[same as prior period, unchanged from 0001511737-16-000045:notes:45]

[0001511737-17-000003:notes:47]
The following table shows total stock-based compensation expense included in the Consolidated Statements of Operations for the three and six months ended December 31, 2016 and 2015 (in thousands):

[0001511737-17-000003:notes:48]
|  | Three Months Ended December 31, |  | Six Months Ended December 31, |
|  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Cost of revenues | $ | 30 |  |  | $ | 114 |  |  | $ | 174 |  |  | $ | 227 |  |
| Research and development | 381 |  |  | 580 |  |  | 941 |  |  | 1,204 |  |
| Sales, general and administrative | 155 |  |  | 263 |  |  | 378 |  |  | 553 |  |
|  | $ | 566 |  |  | $ | 957 |  |  | $ | 1,493 |  |  | $ | 1,984 |  |

[0001511737-17-000003:notes:49]
[same as prior period, unchanged from 0001511737-16-000045:notes:48]

[0001511737-17-000003:notes:50]
The following is a summary of option activity for the Company’s stock incentive plans for the six months ended December 31, 2016:

[0001511737-17-000003:notes:51]
|  | Common Stock Options Outstanding |
|  | Numberof Shares |  | WeightedAverageExercisePrice |  | WeightedAverageRemainingContractualLife (Years) |  | AggregateIntrinsicValue(In thousands) |
| Balance, June 30, 2016 | 2,125,307 |  |  | $ | 2.03 |  |  | 2.65 |  | $ | 77,850 |  |
| Exercised | (487,166 | ) |  | $ | 2.64 |  |  |  |  |  |
| Forfeitures and cancellations | (1,356 | ) |  | $ | 11.72 |  |  |  |  |  |
| Balance, December 31, 2016 | 1,636,785 |  |  | $ | 1.84 |  |  | 2.06 |  | $ | 91,595 |  |
| Vested and expected to vest as of December 31, 2016 | 1,636,773 |  |  | $ | 1.84 |  |  | 2.06 |  | $ | 91,595 |  |
| Vested and exercisable as of December 31, 2016 | 1,635,405 |  |  | $ | 1.83 |  |  | 2.06 |  | $ | 91,536 |  |

[0001511737-17-000003:notes:52]
During the three months ended December 31, 2016 and 2015, the aggregate intrinsic value of options exercised under the Company’s stock incentive plans was $3.5 million and $738 thousand, respectively, as determined as of the date of option exercise. During the six months ended December 31, 2016 and 2015, the aggregate intrinsic value of options exercised under the Company’s stock incentive plans was $24.2 million and $2.2 million, respectively, as determined as of the date of option exercise.

[0001511737-17-000003:notes:53]
As of December 31, 2016, the Company had unrecognized compensation costs of $8.8 thousand related to stock options which the Company expects to recognize over a weighted-average period of 0.3 years. Future option grants will increase the amount of compensation expense to be recorded in these periods.

[0001511737-17-000003:notes:54]
The Company estimates the fair value of employee stock options using the Black-Scholes option pricing model. The fair value of employee stock options is amortized on a straight-line basis over the requisite service period of the awards.  The Company did not grant any employee stock options during the three and six months ended December 31, 2016 and 2015.

[0001511737-17-000003:notes:55]
[same as prior period, unchanged from 0001511737-16-000045:notes:54]

[0001511737-17-000003:notes:56]
[same as prior period, unchanged from 0001511737-16-000045:notes:55]

[0001511737-17-000003:notes:57]
|  | Number of Shares |  | Weighted Average Grant Date Fair Value Per Share |
| Non-vested RSUs, June 30, 2016 | 271,971 |  |  | $ | 28.72 |  |
| RSUs granted | 24,330 |  |  | $ | 45.83 |  |
| RSUs vested | (76,427 | ) |  | $ | 23.36 |  |
| RSUs canceled | (38,290 | ) |  | $ | 33.81 |  |
| Non-vested RSUs, December 31, 2016 | 181,584 |  |  | $ | 32.20 |  |

[0001511737-17-000003:notes:58]
The intrinsic value of RSUs vested in the three months ended December 31, 2016 and 2015 was $0.9 million and $0.9 million, respectively. The intrinsic value of RSUs vested in the six months ended December 31, 2016 and 2015 was $3.7 million and $2.8 million, respectively.

[0001511737-17-000003:notes:59]
As of December 31, 2016, there were unrecognized compensation costs related to RSUs of $4.0 million which the Company expects to recognize over a weighted average period of 2.8 years.


## us-gaap:EarningsPerShareTextBlock

[0001511737-17-000003:notes:60]
[same as prior period, unchanged from 0001511737-16-000045:notes:59]

[0001511737-17-000003:notes:61]
[same as prior period, unchanged from 0001511737-16-000045:notes:60]

[0001511737-17-000003:notes:62]
|  | Three Months Ended December 31, |  | Six Months Ended December 31, |
|  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Numerator: |  |  |  |
| Net income and comprehensive income | $ | 60,608 |  |  | $ | 49,452 |  |  | $ | 132,396 |  |  | $ | 103,211 |  |
| Denominator: |  |  |  |
| Weighted-average shares used in computing basic net income per share | 82,169 |  |  | 84,724 |  |  | 81,990 |  |  | 85,893 |  |
| Add—dilutive potential common shares: |  |  |  |  |  |  |  |
| Stock options(1) | 1,611 |  |  | 1,281 |  |  | 1,766 |  |  | 1,291 |  |
| Restricted stock units(1) | 108 |  |  | 86 |  |  | 119 |  |  | 101 |  |
| Weighted-average shares used in computing diluted net income per share | 83,888 |  |  | 86,091 |  |  | 83,875 |  |  | 87,285 |  |
| Net income per share of common stock: |  |  |  |
| Basic | $ | 0.74 |  |  | $ | 0.58 |  |  | $ | 1.61 |  |  | $ | 1.20 |  |
| Diluted | $ | 0.72 |  |  | $ | 0.57 |  |  | $ | 1.58 |  |  | $ | 1.18 |  |

[0001511737-17-000003:notes:63]
(1) Effective July 1, 2016, the Company early adopted ASU 2016-09 regarding the Improvements to Employee Share-Based Payment Accounting. During the three and six months ended December 31, 2016, the adoption increased the number of diluted stock options and restricted stock units by 654 thousand and 715 thousand shares, respectively.

[0001511737-17-000003:notes:64]
[same as prior period, unchanged from 0001511737-16-000045:notes:63]

[0001511737-17-000003:notes:65]
|  | Three Months Ended December 31, |  | Six Months Ended December 31, |
|  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Restricted stock units | — |  |  | 22 |  |  | — |  |  | 1 |  |
|  | — |  |  | 22 |  |  | — |  |  | 1 |  |


## us-gaap:FairValueAssetsAndLiabilitiesMeasuredOnRecurringAndNonrecurringBasisTableTextBlock

[0001511737-17-000003:notes:66]
As of December 31, 2016 and June 30, 2016, the fair value hierarchy of the Company’s debt carried at historical cost was as follows (in thousands):

[0001511737-17-000003:notes:67]
|  | December 31, 2016 |  | June 30, 2016 |
|  | Fair Value |  | Fair Value |
| Debt | $ | 198,500 |  |  | $ | 203,500 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001511737-17-000003:notes:68]
[same as prior period, unchanged from 0001511737-16-000045:notes:67]

[0001511737-17-000003:notes:69]
[same as prior period, unchanged from 0001511737-16-000045:notes:68]

[0001511737-17-000003:notes:70]
[same as prior period, unchanged from 0001511737-16-000045:notes:69]

[0001511737-17-000003:notes:71]
[same as prior period, unchanged from 0001511737-16-000045:notes:70]

[0001511737-17-000003:notes:72]
[same as prior period, unchanged from 0001511737-16-000045:notes:71]

[0001511737-17-000003:notes:73]
For certain of the Company’s financial instruments, including cash, accounts receivable, accounts payable and other current liabilities, the carrying amounts approximate fair value due to their short maturities.  Additionally, as of December 31, 2016, we held $572.7 million of our $612.7 million of cash and cash equivalents in accounts of our subsidiaries outside of the United States and we could incur material tax liabilities if we were to repatriate those amounts.

[0001511737-17-000003:notes:74]
As of December 31, 2016 and June 30, 2016 the Company had debt associated with its Amended Credit Agreement with Wells Fargo Bank (See Note 7). The fair value of the Company’s debt was estimated based on the current rates offered to the Company for debt with similar terms and remaining maturities and was a Level 2 measurement.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001511737-17-000003:notes:75]
[same as prior period, unchanged from 0001511737-16-000045:notes:74]

[0001511737-17-000003:notes:76]
The Company recorded a tax provision of $8.0 million and $10.0 million for the three and six months ended December 31, 2016.  The Company’s estimated fiscal year 2017 effective tax rate differs from the U.S. statutory rate primarily due to profits earned in jurisdictions where the tax rate is lower than the U.S. tax rate and in realization of share-based compensation excess tax benefit.

[0001511737-17-000003:notes:77]
Effective July 1, 2016, the Company early adopted ASU 2016-09 regarding the Improvements to Employee Share-Based Payment Accounting. In accordance with the new guidance, for the three and six months ended December 31, 2016, the Company recognized excess tax benefits of $0.9 million and $7.7 million, respectively, as a discrete item within the provision for income taxes rather than additional paid-in capital. See Note 2 for information on the impact of the adoption of ASU 2016-09.

[0001511737-17-000003:notes:78]
As of December 31, 2016, the Company had approximately $24.8 million of unrecognized tax benefits, substantially all of which would, if recognized, affect its tax expense. The Company has elected to include interest and penalties related to uncertain tax positions as a component of tax expense. At December 31, 2016, an immaterial amount of interest and penalties are included in long-term income tax payable. The Company recorded a net increase of its unrecognized tax benefits of $0.8 million and 2.0 million, respectively, for the three and six months ended December 31, 2016. The Company does not expect any significant increases or decreases to its unrecognized tax benefits in the next twelve months.

[0001511737-17-000003:notes:79]
The Company files U.S. federal income tax returns as well as income tax returns in various states and foreign jurisdictions. The Company’s tax filings from fiscal year 2011 and onwards could be subject to examinations by tax authorities.

[0001511737-17-000003:notes:80]
On July 27, 2015, in Altera Corp. v. Commissioner, the U.S. Tax Court issued an opinion related to the treatment of stock-based compensation expense in an intercompany cost-sharing arrangement.  On February 19, 2016, the U.S. Department of the Treasury filed a notice of appeal and has not withdrawn the requirement to include stock-based compensation from its regulations. On June 27, 2016, the U.S. Department of Treasury appealed the holding by filing its opening brief to the Ninth Circuit Court of Appeals. We have reviewed this case and its potential impact on Ubiquiti and concluded that no adjustment to the consolidated financial statements is appropriate at this time. We will continue to monitor ongoing developments and potential impacts to our consolidated financial statements.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001511737-17-000003:notes:81]
New Accounting Updates Recently Adopted

[0001511737-17-000003:notes:82]
Effective July 1, 2016, the Company adopted Accounting Standards Update (“ASU”) 2015-03 regarding simplifying the presentation of debt issuance costs. The guidance requires that debt issuance costs related to a recognized debt liability be presented in the balance sheet as a direct deduction from the carrying amount of that debt liability, consistent with debt discounts. Previously the Company reported these costs as assets on its balance sheet. The guidance is applied on a retrospective basis whereby prior-period financial statements must be adjusted to reflect the adoption of the new guidance.

[0001511737-17-000003:notes:83]
The Company has reclassified $0.3 million from "prepaid expenses and other current assets" to "Debt - short-term", and $0.7 million from "Other long-term assets" to "Debt - long-term" on the June 30, 2016 consolidated balance sheet.

[0001511737-17-000003:notes:84]
Effective July 1, 2016, the Company adopted ASU 2015-11 regarding simplifying the measurement of inventory. The guidance requires an entity to measure inventory at the lower of cost and net realizable value. Net realizable value is the estimated selling prices in the ordinary course of business, less reasonably predictable costs of completion, disposal, and transportation. The Company adopted this update prospectively, and it did not have a material impact on the Company's Consolidated Financial Statements.

[0001511737-17-000003:notes:85]
Effective July 1, 2016, the Company early adopted ASU 2016-09 regarding the Improvements to Employee Share-Based Payment Accounting. The Company applied the guidance relating to accounting for excess tax benefits and the presentation of excess tax benefits in the consolidated statement of cash flows on a prospective basis; accordingly, prior period amounts have not been adjusted. During the three and six months ended December 31, 2016, the Company recognized the excess tax benefits of $0.9 million and $7.7 million, respectively, within the provision for income taxes rather than additional paid-in capital. The Company classified the excess tax benefits within cash flows from operating activities for the six months ended December 31, 2016 rather than within cash flows from financing activities. In regards to the forfeiture policy election, we will continue to estimate the number of awards expected to be forfeited, rather than electing to account for forfeitures as they occur. No other terms of the adopted guidance resulted in an impact on the Company's Consolidated Financial Statements.

[0001511737-17-000003:notes:86]
Recent Accounting Standards or Updates Not Yet Effective

[0001511737-17-000003:notes:87]
In May 2014, the FASB issued ASU 2014-09, Revenue from Contracts with Customers, with amendments in 2015 and 2016, which creates new ASC Topic 606 (Topic 606) that will replace most existing revenue recognition guidance in GAAP when it becomes effective. Topic 606 requires an entity to recognize the amount of revenue to which it expects to be entitled for the transfer of promised goods or services to customers. The new standard will be effective for the Company’s first quarter of fiscal year 2019 and early application for in the first quarter of fiscal year 2018 is permitted. Topic 606 may be applied retrospectively to each prior period presented or with the cumulative effect recognized as of the date of initial application. The Company is still evaluating the impact of adopting Topic 606 on its consolidated financial statements and related financial statement disclosures and has not yet selected a transition method or determined if it will adopt this standard in fiscal 2018 or 2019.

[0001511737-17-000003:notes:88]
In February 2016, the FASB issued ASU 2016-02, “Leases (Topic 842),” (“ASU 2016-02”). ASU 2016-02 requires lessees to recognize assets and liabilities on the balance sheet for leases with lease terms greater than twelve months and disclose key information about leasing arrangements. ASU 2016-02 is effective for annual periods beginning after December 15, 2018, including interim periods within those fiscal years, with early application permitted. The Company is evaluating the impact that adoption of this new standard will have on its consolidated financial statements.

[0001511737-17-000003:notes:89]
In June 2016, the FASB issued ASU 2016-13, “Financial Instruments – Credit Losses (Topic 326): Measurement of Credit Losses On Financial Instruments,” (“ASU 2016-13”). ASU 2016-13 implements a comprehensive change in estimating the allowances for loan losses from the current model of losses inherent in the loan portfolio to a current expected credit loss model that generally is expected to result in earlier recognition of allowances for losses. Additionally, purchase accounting rules have been modified as well as credit losses on held-to-maturity debt securities. ASU 2016-13 is effective for fiscal years beginning after December 15, 2019, and early adoption is permitted for annual and interim periods beginning after December 15, 2018. The Company is evaluating the impact that adoption of this new standard will have on its consolidated financial statements.

[0001511737-17-000003:notes:90]
In October 2016, the FASB issued ASU 2016-16, "Income Taxes (Topic 740): Accounting for Income Taxes: Intra-Entity Asset Transfers of Assets Other Than Inventory," (“ASU 2016-16”). ASU 2016-16 eliminates the exception for all intra-entity sales of assets other than inventory. As a result, a reporting entity would recognize the tax expense from the sale of the asset in the seller’s tax jurisdiction when the transfer occurs, even though the pre-tax effects of that transaction are eliminated in consolidation. Any deferred tax asset that arises in the buyer’s jurisdiction would also be recognized at the time of the transfer. ASU 2016-16 is effective for fiscal years beginning after December 15, 2017, and early adoption is permitted but can only be adopted in the first interim period of a fiscal year. The Company is evaluating the impact that adoption of this new standard will have on its consolidated financial statements.


## us-gaap:OtherCurrentLiabilitiesTableTextBlock

[0001511737-17-000003:notes:91]
[same as prior period, unchanged from 0001511737-16-000045:notes:99]

[0001511737-17-000003:notes:92]
|  | December 31, 2016 |  | June 30, 2016 |
| Accrued expenses | $ | 7,051 |  |  | $ | 5,749 |  |
| Accrued compensation and benefits | 2,384 |  |  | 1,589 |  |
| Warranty accrual | 3,876 |  |  | 2,236 |  |
| Deferred revenue - short term | 3,936 |  |  | 2,917 |  |
| Customer deposits | 580 |  |  | 856 |  |
| Reserve for sales returns | 4,146 |  |  | 2,820 |  |
| Other payables | 4,665 |  |  | 10,505 |  |
| Total | $ | 26,638 |  |  | $ | 26,672 |  |


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001511737-17-000003:notes:93]
[same as prior period, unchanged from 0001511737-16-000045:notes:101]

[0001511737-17-000003:notes:94]
[same as prior period, unchanged from 0001511737-16-000045:notes:102]

[0001511737-17-000003:notes:95]
[same as prior period, unchanged from 0001511737-16-000045:notes:103]

[0001511737-17-000003:notes:96]
|  | Six Months Ended December 31, |
|  | 2016 |  | 2015 |
| Beginning balance | $ | 2,236 |  |  | $ | 2,750 |  |
| Accruals for warranties issued during the period | 4,475 |  |  | 1,027 |  |
| Settlements made during the period | (2,835 | ) |  | (1,572 | ) |
| Ending balance | $ | 3,876 |  |  | $ | 2,205 |  |


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0001511737-17-000003:notes:97]
[same as prior period, unchanged from 0001511737-16-000045:notes:105]

[0001511737-17-000003:notes:98]
|  | December 31, 2016 |  | June 30, 2016 |
| Testing equipment | $ | 6,963 |  |  | $ | 6,051 |  |
| Computer and other equipment | 5,025 |  |  | 4,857 |  |
| Tooling equipment | 6,667 |  |  | 5,801 |  |
| Furniture and fixtures | 1,474 |  |  | 1,325 |  |
| Leasehold improvements | 5,429 |  |  | 5,136 |  |
| Software | 5,469 |  |  | 2,488 |  |
| Software in development | 129 |  |  | 2,739 |  |
| Property and Equipment, Gross | 31,156 |  |  | 28,397 |  |
| Less: Accumulated depreciation and amortization | (18,534 | ) |  | (15,444 | ) |
| Property and Equipment, Net | $ | 12,622 |  |  | $ | 12,953 |  |


## us-gaap:ReconciliationOfRevenueFromSegmentsToConsolidatedTextBlock

[0001511737-17-000003:notes:99]
[same as prior period, unchanged from 0001511737-16-000045:notes:107]

[0001511737-17-000003:notes:100]
|  | Three Months Ended December 31, |  | Six Months Ended December 31, |
|  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Service provider Technology | $ | 115,580 |  |  | 54 | % |  | $ | 109,616 |  |  | 68 | % |  | $ | 236,212 |  |  | 56 | % |  | $ | 213,015 |  |  | 68 | % |
| Enterprise Technology | 97,956 |  |  | 46 | % |  | 52,255 |  |  | 32 | % |  | 182,081 |  |  | 44 | % |  | 100,271 |  |  | 32 | % |
| Total revenues | $ | 213,536 |  |  | 100 | % |  | $ | 161,871 |  |  | 100 | % |  | $ | 418,293 |  |  | 100 | % |  | $ | 313,286 |  |  | 100 | % |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001511737-17-000003:notes:101]
RELATED PARTY TRANSACTIONS AND CERTAIN OTHER TRANSACTIONS

[0001511737-17-000003:notes:102]
Aircraft Lease Agreement

[0001511737-17-000003:notes:103]
On November 13, 2013, the Company entered into an aircraft lease agreement (the “Aircraft Lease Agreement”) with RJP Manageco LLC (the “Lessor”), a limited liability company owned by the Company’s CEO, Robert J. Pera. Pursuant to the Aircraft Lease Agreement, the Company may lease an aircraft owned by the Lessor for Company business purposes. Under the Aircraft Lease Agreement, the aircraft may be leased at a rate of $5,000 per flight hour. This hourly rate does not include the cost of flight crew or on-board services, which the Company purchases from a third-party provider. The Company recognized a total of approximately $0.5 million and $1.2 million in expenses pursuant to the Aircraft Lease Agreement during the three and six months ended December 31, 2016, respectively.  The Company recognized a total of approximately $0.4 million and $0.6 million in expenses pursuant to the Aircraft Lease Agreement during the three and six months ended December 31, 2015, respectively. All expenses pursuant to the Aircraft Lease Agreement have been included in the Company’s sales, general and administrative expenses in the Consolidated Statements of Operations.


## us-gaap:RevenueFromExternalCustomersByGeographicAreasTableTextBlock

[0001511737-17-000003:notes:104]
[same as prior period, unchanged from 0001511737-16-000045:notes:112]

[0001511737-17-000003:notes:105]
|  | Three Months Ended December 31, |  | Six Months Ended December 31, |
|  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| North America(1) | $ | 94,609 |  |  | 44 | % |  | $ | 57,402 |  |  | 35 | % |  | $ | 168,774 |  |  | 40 | % |  | $ | 110,636 |  |  | 35 | % |
| South America | 19,285 |  |  | 9 | % |  | 23,526 |  |  | 15 | % |  | 43,469 |  |  | 10 | % |  | 45,674 |  |  | 15 | % |
| Europe, the Middle East and Africa ("EMEA") | 77,381 |  |  | 36 | % |  | 60,973 |  |  | 38 | % |  | 158,756 |  |  | 38 | % |  | 121,476 |  |  | 39 | % |
| Asia Pacific | 22,261 |  |  | 11 | % |  | 19,970 |  |  | 12 | % |  | 47,294 |  |  | 12 | % |  | 35,500 |  |  | 11 | % |
| Total revenues | $ | 213,536 |  |  | 100 | % |  | $ | 161,871 |  |  | 100 | % |  | $ | 418,293 |  |  | 100 | % |  | $ | 313,286 |  |  | 100 | % |

[0001511737-17-000003:notes:106]
| (1) | Revenue for the United States was $90.2 million and $53.9 million for the three months ended December 31, 2016 and 2015, respectively. Revenue for the United States was $160.8 million and $104.5 million for the six months ended December 31, 2016 and December 31, 2015, respectively. |


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0001511737-17-000003:notes:107]
[same as prior period, unchanged from 0001511737-16-000045:notes:115]

[0001511737-17-000003:notes:108]
|  | December 31, 2016 |  | June 30, 2016 |
| Finished goods | $ | 95,312 |  |  | $ | 50,987 |  |
| Raw materials | 9,105 |  |  | 6,126 |  |
| Total | $ | 104,417 |  |  | $ | 57,113 |  |


## us-gaap:ScheduleOfOtherAssetsNoncurrentTextBlock

[0001511737-17-000003:notes:109]
[same as prior period, unchanged from 0001511737-16-000045:notes:117]

[0001511737-17-000003:notes:110]
|  | December 31, 2016 |  | June 30, 2016 |
| Intangible assets, net (1) | $ | 541 |  |  | $ | 616 |  |
| Other long-term assets | 1,488 |  |  | 960 |  |
| Total | $ | 2,029 |  |  | $ | 1,576 |  |

[0001511737-17-000003:notes:111]
(1) - Accumulated amortization was $1.1 million and $1.0 million as of December 31, 2016 and June 30, 2016, respectively.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001511737-17-000003:notes:112]
[same as prior period, unchanged from 0001511737-16-000045:notes:120]

[0001511737-17-000003:notes:113]
Management has determined that the Company operates as one reportable and operating segment as it only reports financial information on an aggregate and consolidated basis to its Chief Executive Officer, who is the Company’s Chief Operating Decision Maker.  Furthermore, the Company does not organize or report its costs on a segment basis.  The Company presents its revenues by product type in two primary categories, including Service Provider Technology and Enterprise Technology.

[0001511737-17-000003:notes:114]
| • | Service Provider Technology includes the Company’s airMAX, EdgeMAX and airFiber platforms, as well as embedded radio products and other 802.11 standard products including base stations, radios, backhaul equipment and Customer Premise Equipment (“CPE”). Additionally, Service Provider Technology includes antennas and other products primarily in the 0.9 to 6.0 GHz spectrum and miscellaneous products such as mounting brackets, cables and power over Ethernet adapters. Service Provider Technology also includes solar products (sales of which have not been material to date) and revenues that are attributable to post-contract customer support (“PCS”). |

[0001511737-17-000003:notes:115]
| • | Enterprise Technology includes the Company’s UniFi and mFi platforms, including UniFi Access Point (“UAP”) products, UniFi Video products, UniFi Voice Over IP (“VOIP”) phones and UniFi switch products. Enterprise Technology also includes AmpliFi products and revenues that are attributable to PCS. |


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001511737-17-000003:notes:116]
[same as prior period, unchanged from 0001511737-16-000045:notes:124]

[0001511737-17-000003:notes:117]
[same as prior period, unchanged from 0001511737-16-000045:notes:125]


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001511737-17-000003:notes:118]
[same as prior period, unchanged from 0001511737-16-000045:notes:126]

[0001511737-17-000003:notes:119]
As of December 31, 2016 and June 30, 2016, the authorized capital of the Company included 500,000,000 shares of common stock.  As of December 31, 2016 and June 30, 2016, there were 82,210,987 and 81,667,129 shares of common stock outstanding, respectively.

[0001511737-17-000003:notes:120]
[same as prior period, unchanged from 0001511737-16-000045:notes:128]

[0001511737-17-000003:notes:121]
[same as prior period, unchanged from 0001511737-16-000045:notes:129]

[0001511737-17-000003:notes:122]
On August 3, 2016, the Board of Directors of the Company approved a $50 million stock repurchase program. Under the new stock repurchase program, the Company may repurchase up to $50 million of its common stock. The program expires on September 30, 2017. As of December 31, 2016, the Company has not repurchased any of its common stock under this plan.


## us-gaap:SubsequentEventsTextBlock

[0001511737-17-000003:notes:123]
SUBSEQUENT EVENTS

[0001511737-17-000003:notes:124]
On February 3, 2017, Synopsys, Inc. (“Synopsys”) filed a complaint against the Company, one of our subsidiaries and certain employees in the United States District Court for the Northern District of California, alleging claims under the Digital Millennium Copyright Act. The Company plans to vigorously defend itself against these claims; however, there can be no assurance that the Company will prevail in the lawsuit. The Company cannot currently estimate the possible loss or range of losses, if any, that it may experience in connection with this litigation.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001511737-17-000003:notes:125]
[same as prior period, unchanged from 0001511737-16-000045:notes:131]

[0001511737-17-000003:notes:126]
[same as prior period, unchanged from 0001511737-16-000045:notes:132]

[0001511737-17-000003:notes:127]
[same as prior period, unchanged from 0001511737-16-000045:notes:133]

[0001511737-17-000003:notes:128]
[same as prior period, unchanged from 0001511737-16-000045:notes:134]

[0001511737-17-000003:notes:129]
[same as prior period, unchanged from 0001511737-16-000045:notes:135]


## us-gaap:UnusualOrInfrequentItemsDisclosureTextBlock

[0001511737-17-000003:notes:130]
[same as prior period, unchanged from 0001511737-16-000045:notes:136]

[0001511737-17-000003:notes:131]
As disclosed in June 2015 and 2016, the Company determined that it was the victim of a criminal fraud known to law enforcement authorities as business e-mail compromise fraud which involved employee impersonation and fraudulent requests targeting our finance department.  The fraud resulted in transfers of funds aggregating $46.7 million held by a Company subsidiary incorporated in Hong Kong to other overseas accounts held by third parties.  To date, the Company has recovered $16.7 million. The Company recovered $8.1 million in fiscal 2015, resulting in a charge of $39.1 million in the fourth quarter of fiscal 2015, including additional expenses consisting of professional service fees associated with the fraud loss.  In fiscal 2016, the Company recorded a net recovery of an additional $8.3 million, comprised of the $8.6 million recovery less $0.3 million of professional service fees associated with the recovery. No additional recoveries were made during the three and six months ended December 31, 2016.

[0001511737-17-000003:notes:132]
The Company intends to continue to pursue the recovery of the remaining $30.0 million. The Company is also continuing to cooperate with U.S. federal and numerous overseas law enforcement authorities, who are actively pursuing a multi-agency criminal investigation.  Any additional recoveries of funds are likely remote and therefore cannot be assured.
