# UI note change history — 0001511737-16-000045 → 0001511737-17-000003


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2017-02-09):
[0001511737-17-000003:note_history:1]
At December 31, 2016, future minimum annual payments under operating leases for the remainder of fiscal 2017 and future fiscal years are as follows (in thousands):
  (was, 2016-11-07, similarity 0.9838):
[0001511737-16-000045:note_history:1]
At September 30, 2016, future minimum annual payments under operating leases for the remainder of fiscal 2017 and future fiscal years are as follows (in thousands):

- changed (2017-02-09):
[0001511737-17-000003:note_history:2]
The Company primarily subcontracts with other companies to manufacture its products. During the normal course of business, the Company’s contract manufacturers procure components based upon orders placed by the Company. If the Company cancels all or part of the orders, it may still be liable to the contract manufacturers for the cost of the components purchased by them to manufacture the Company’s products. The Company periodically reviews the potential liability under its orders, and no significant accruals have been recorded as of December 31, 2016.  The Company had inventory purchase obligations of $34.7 million as of December 31, 2016.
  (was, 2016-11-07, similarity 0.9889):
[0001511737-16-000045:note_history:2]
The Company primarily subcontracts with other companies to manufacture its products. During the normal course of business, the Company’s contract manufacturers procure components based upon orders placed by the Company. If the Company cancels all or part of the orders, it may still be liable to the contract manufacturers for the cost of the components purchased by them to manufacture the Company’s products. The Company periodically reviews the potential liability under its orders, and no significant accruals have been recorded as of September 30, 2016.  The Company had inventory purchase obligations of $25.8 million as of September 30, 2016.

- changed (2017-02-09):
[0001511737-17-000003:note_history:3]
The Company had other obligations of $9.9 million as of December 31, 2016, which consisted primarily of commitments related to research and development projects.
  (was, 2016-11-07, similarity 0.9837):
[0001511737-16-000045:note_history:3]
The Company had other obligations of $10.0 million as of September 30, 2016, which consisted primarily of commitments related to research and development projects.

- changed (2017-02-09):
[0001511737-17-000003:note_history:4]
Beginning on September 7, 2012, two class action lawsuits were filed in the United States District Court for the Northern District of California against Ubiquiti Networks, Inc., certain of our current and former officers and directors, and the underwriters of its initial public offering, alleging claims under U.S. securities laws. On January 30, 2013, the plaintiffs filed an amended consolidated complaint. On March 26, 2014, the court issued an order granting a motion to dismiss the complaint with leave to amend. Following the plaintiffs’ decision not to file an amended complaint, on April 16, 2014, the court ordered the dismissal of the lawsuit with prejudice, and entered judgment in favor of the Company and the other defendants, and against the plaintiffs. On May 15, 2014, the plaintiffs filed a notice of appeal from the judgment of the court. The Ninth Circuit heard oral arguments on August 10, 2016.  On October 24, 2016, the Ninth Circuit issued an unpublished opinion, reaffirming the district court’s dismissal of the alleged violation of Sections 10(b) and 20(a) of the Securities Exchange Act of 1934 and reversing the district court’s dismissal of the alleged violations of Sections 11 and 15 of the Securities Act of 1933. The Company filed a petition for rehearing with the Ninth Circuit, which the Ninth Circuit denied. The Company plans to vigorously defend itself against these claims; however, there can be no assurance that the Company will prevail in the lawsuit. The Company cannot currently estimate the possible loss, if any, that it may experience in connection with this litigation.
  (was, 2016-11-07, similarity 0.8924):
[0001511737-16-000045:note_history:4]
Beginning on September 7, 2012, two class action lawsuits were filed in the United States District Court for the Northern District of California against Ubiquiti Networks, Inc., certain of its officers and directors, and the underwriters of its initial public offering, alleging claims under U.S. securities laws. On January 30, 2013, the plaintiffs filed an amended consolidated complaint. On March 26, 2014, the court issued an order granting a motion to dismiss the complaint with leave to amend. Following the plaintiffs’ decision not to file an amended complaint, on April 16, 2014, the court ordered the dismissal of the lawsuit with prejudice, and entered judgment in favor of the Company and the other defendants, and against the plaintiffs. On May 15, 2014, the plaintiffs filed a notice of appeal from the judgment of the court. The Ninth Circuit heard oral arguments on August 10, 2016.  On October 24, 2016, the Ninth Circuit issued an unpublished opinion, reaffirming the district court’s dismissal of the alleged violation of Sections 10(b) and 20(a) of the Securities Exchange Act of 1934 and reversing the district court’s dismissal of the alleged violations of Sections 11 and 15 of the Securities Act of 1933. The Company plans to file a petition for rehearing with the Ninth Circuit and to vigorously defend itself against these claims. There can be no assurance that the Company will prevail. The Company cannot currently estimate the possible loss, if any, that it may experience in connection with this litigation.


## us-gaap:BusinessDescriptionAndBasisOfPresentationTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2017-02-09):
[0001511737-17-000003:note_history:5]
These consolidated financial statements should be read in conjunction with the Company’s audited consolidated financial statements for the fiscal year ended June 30, 2016, included in its Annual Report on Form 10-K, as filed with the SEC on August 22, 2016 (the “Annual Report”). The results of operations for the three and six months ended December 31, 2016 are not necessarily indicative of the results to be expected for any future periods.
  (was, 2016-11-07, similarity 0.7716):
[0001511737-16-000045:note_history:5]
These consolidated financial statements should be read in conjunction with the Company’s audited consolidated financial statements for the fiscal year ended June 30, 2016, included in its Annual Report on Form 10-K, as filed with the SEC on August 22, 2016 (the “Annual Report”). The results of operations for the three months ended September 30, 2016 are not necessarily indicative of the results to be expected for any future periods.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2017-02-09):
[0001511737-17-000003:note_history:6]
Effective July 1, 2016, the Company early adopted ASU 2016-09 regarding the Improvements to Employee Share-Based Payment Accounting. The Company applied the guidance relating to accounting for excess tax benefits and the presentation of excess tax benefits in the consolidated statement of cash flows on a prospective basis; accordingly, prior period amounts have not been adjusted. During the three and six months ended December 31, 2016, the Company recognized the excess tax benefits of $0.9 million and $7.7 million, respectively, within the provision for income taxes rather than additional paid-in capital. The Company classified the excess tax benefits within cash flows from operating activities for the six months ended December 31, 2016 rather than within cash flows from financing activities. In regards to the forfeiture policy election, we will continue to estimate the number of awards expected to be forfeited, rather than electing to account for forfeitures as they occur. No other terms of the adopted guidance resulted in an impact on the Company's Consolidated Financial Statements.

- added (2017-02-09):
[0001511737-17-000003:note_history:7]
In May 2014, the FASB issued ASU 2014-09, Revenue from Contracts with Customers, with amendments in 2015 and 2016, which creates new ASC Topic 606 (Topic 606) that will replace most existing revenue recognition guidance in GAAP when it becomes effective. Topic 606 requires an entity to recognize the amount of revenue to which it expects to be entitled for the transfer of promised goods or services to customers. The new standard will be effective for the Company’s first quarter of fiscal year 2019 and early application for in the first quarter of fiscal year 2018 is permitted. Topic 606 may be applied retrospectively to each prior period presented or with the cumulative effect recognized as of the date of initial application. The Company is still evaluating the impact of adopting Topic 606 on its consolidated financial statements and related financial statement disclosures and has not yet selected a transition method or determined if it will adopt this standard in fiscal 2018 or 2019.

- changed (2017-02-09):
[0001511737-17-000003:note_history:8]
In June 2016, the FASB issued ASU 2016-13, “Financial Instruments – Credit Losses (Topic 326): Measurement of Credit Losses On Financial Instruments,” (“ASU 2016-13”). ASU 2016-13 implements a comprehensive change in estimating the allowances for loan losses from the current model of losses inherent in the loan portfolio to a current expected credit loss model that generally is expected to result in earlier recognition of allowances for losses. Additionally, purchase accounting rules have been modified as well as credit losses on held-to-maturity debt securities. ASU 2016-13 is effective for fiscal years beginning after December 15, 2019, and early adoption is permitted for annual and interim periods beginning after December 15, 2018. The Company is evaluating the impact that adoption of this new standard will have on its consolidated financial statements.
  (was, 2016-11-07, similarity 0.9127):
[0001511737-16-000045:note_history:8]
In June 2016, the FASB issued ASU 2016-13, “Financial Instruments – Credit Losses (Topic 326): Measurement of Credit Losses On Financial Instruments”. (“ASU 2016-13”). ASU 2016-13 implements a comprehensive change in estimating the allowances for loan losses from the current model of losses inherent in the loan portfolio to a current expected credit loss model that generally is expected to result in earlier recognition of allowances for losses. Additionally, purchase accounting rules have been modified as well as credit losses on held-to-maturity debt securities. ASU 2016-13 is effective for fiscal years beginning after December 15, 2019, and early adoption is permitted for annual and interim periods beginning after December 15, 2018. The Company is in the process of assessing the impact that adoption of this new standard will have on its consolidated financial statements.

- changed (2017-02-09):
[0001511737-17-000003:note_history:9]
In October 2016, the FASB issued ASU 2016-16, "Income Taxes (Topic 740): Accounting for Income Taxes: Intra-Entity Asset Transfers of Assets Other Than Inventory," (“ASU 2016-16”). ASU 2016-16 eliminates the exception for all intra-entity sales of assets other than inventory. As a result, a reporting entity would recognize the tax expense from the sale of the asset in the seller’s tax jurisdiction when the transfer occurs, even though the pre-tax effects of that transaction are eliminated in consolidation. Any deferred tax asset that arises in the buyer’s jurisdiction would also be recognized at the time of the transfer. ASU 2016-16 is effective for fiscal years beginning after December 15, 2017, and early adoption is permitted but can only be adopted in the first interim period of a fiscal year. The Company is evaluating the impact that adoption of this new standard will have on its consolidated financial statements.
  (was, 2016-11-07, similarity 0.9073):
[0001511737-16-000045:note_history:9]
In October 2016, the FASB issued ASU 2016-16, the FASB issued ASU 2016-16, "Income Taxes (Topic 740): Accounting for Income Taxes: Intra-Entity Asset Transfers of Assets Other Than Inventory". (“ASU 2016-16”). ASU 2016-16 eliminates the exception for all intra-entity sales of assets other than inventory. As a result, a reporting entity would recognize the tax expense from the sale of the asset in the seller’s tax jurisdiction when the transfer occurs, even though the pre-tax effects of that transaction are eliminated in consolidation. Any deferred tax asset that arises in the buyer’s jurisdiction would also be recognized at the time of the transfer. ASU 2016-16 is effective for fiscal years beginning after December 15, 2017, and early adoption is permitted but can only be adopted in the first interim period of a fiscal year. The Company is in the process of assessing the impact that adoption of this new standard will have on its consolidated financial statements.

- removed (2017-02-09):
[0001511737-16-000045:note_history:10]
Effective July 1, 2016, the Company early adopted ASU 2016-09 regarding the Improvements to Employee Share-Based Payment Accounting. The Company applied the guidance relating to accounting for excess tax benefits and the presentation of excess tax benefits for share-based payments in the consolidated statement of cash flows on a prospective basis; according prior period amounts have not been adjusted. The Company recognized the excess tax benefits of $6.8 million within the provision for income taxes rather than additional paid-in capital during the three months ended September 30, 2016. The Company classified the excess tax benefits for share-based payments within cash flows from operating activities for the three months ended September 30, 2016 rather than within cash flows from financing activities. In regards to the forfeiture policy election, we will continue to estimate the number of awards expected to be forfeited, rather than electing to account for forfeitures as they occur. No other terms of the adopted guidance resulted in an impact on the Company's Consolidated Financial Statements.

- removed (2017-02-09):
[0001511737-16-000045:note_history:11]
In June 2014, the FASB issued a new accounting standard update on revenue from contracts with customers.  The core principle of the guidance is that an entity should recognize revenue to depict the transfer of promised goods or services to customers in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services.  To achieve that core principle, an entity should apply the following steps:

- removed (2017-02-09):
[0001511737-16-000045:note_history:12]
Step 1: Identify the contract(s) with a customer.

- removed (2017-02-09):
[0001511737-16-000045:note_history:13]
Step 2: Identify the performance obligations in the contract.

- removed (2017-02-09):
[0001511737-16-000045:note_history:14]
Step 3: Determine the transaction price.

- removed (2017-02-09):
[0001511737-16-000045:note_history:15]
Step 4: Allocate the transaction price to the performance obligations in the contract.

- removed (2017-02-09):
[0001511737-16-000045:note_history:16]
Step 5: Recognize revenue when (or as) the entity satisfies a performance obligation.

- removed (2017-02-09):
[0001511737-16-000045:note_history:17]
An entity should disclose sufficient information to enable users of financial statements to understand the nature, amount, timing, and uncertainty of revenue and cash flows arising from contracts with customers. Qualitative and quantitative information is required about contracts with customers, significant judgments and any assets recognized from the costs to obtain or fulfill a contract.   The guidance was to be effective for annual and interim reporting periods beginning after December 15, 2016.  However, in July 2015, the FASB deferred the effective date by one year, to December 15, 2017, to provide adequate time to effectively implement the new standard, though the early adoption as of the original effective date is allowed. The Company is currently assessing the impact of this new guidance and has not selected the transition method.

- removed (2017-02-09):
[0001511737-16-000045:note_history:18]
In March 2016, the FASB issued ASU 2016-08, “Revenue from Contracts with Customers (Topic 606) Principal versus Agent Considerations (Reporting Revenue Gross versus Net),” (“ASU 2016-08”). ASU 2016-08 further clarifies principal and agent relationships within ASU 2014-09. The amendment is effective beginning after December 14, 2017, including interim reporting periods within that reporting year. The Company is evaluating the impact that adoption of this new standard will have on its consolidated financial statements.

- removed (2017-02-09):
[0001511737-16-000045:note_history:19]
In April 2016, the FASB issued ASU 2016-10, “Revenue from Contracts with Customers (Topic 606): Identifying Performance Obligations and Licensing." This ASU addresses certain implementation issues that have surfaced since the issuance of ASU 2014-09 in May 2014. The ASU provides guidance in identifying performance obligations and determining the appropriate accounting for licensing arrangements.  The effective date and transition requirements for the amendments in this update are the same as the effective date and transition requirements for ASU 2014-09. The Company is in the process of assessing the impact that adoption of this new standard will have on its consolidated financial statements.

- removed (2017-02-09):
[0001511737-16-000045:note_history:20]
In May 2016, the FASB issued ASU No. 2016-12, “Revenue from Contracts with Customers (Topic 606): Narrow-Scope Improvements and Practical Expedients”. (“ASU 2016-12”). ASU 2016-12 will affect all entities that enter into contracts with customers to transfer goods or services (that are an output of the entity’s ordinary activities) in exchange for consideration. The amendments in this update affect the guidance in ASU 2014-09 which is not yet effective. The amendments in this update also affect narrow aspects of Topic 606 including among others: assessing collectability criterion, noncash consideration, and presentation of sales taxes and other similar taxes collected from customers. The effective date and transition requirements for the amendments in this update are the same as the effective date and transition requirements for ASU 2014-09. The Company is evaluating the impact that adoption of this new standard will have on its consolidated financial statements.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-02-09):
[0001511737-17-000003:note_history:21]
On March 3, 2015, Ubiquiti Networks, Inc. and Ubiquiti International Holding Company Limited (the “Cayman Borrower”) amended and restated its original credit agreement (the “Amended Credit Agreement”) with Wells Fargo Bank, National Association (“Wells Fargo”), the other financial institutions named as lenders therein, and Wells Fargo as administrative agent for the lenders.  The Amended Credit Agreement provides for a $200.0 million senior secured revolving credit facility ("Revolving Facility") and a $100.0 million senior secured term loan facility ("Term Facility", together with the Revolving Facility, the “Facilities”), with an option to request increases in the amounts of such credit facilities by up to an additional $50.0 million in the aggregate (any such increase to be in each lender’s sole discretion), and matures on March 3, 2020. The Facilities replaced the Company’s $150.0 million senior secured revolving credit facility under its original credit agreement. The $100.0 million term loan facility of the Amended Credit Agreement was fully drawn at closing, and $72.3 million was used to repay the outstanding balance under its original credit agreement. The Facilities are available for working capital and general corporate purposes that comply with the terms of the Amended Credit Agreement.
  (was, 2016-11-07, similarity 0.7646):
[0001511737-16-000045:note_history:21]
On March 3, 2015, Ubiquiti Networks, Inc. and Ubiquiti International Holding Company Limited (the “Cayman Borrower”) amended and restated its original credit agreement (the “Amended Credit Agreement”) with Wells Fargo Bank, National Association (“Wells Fargo”), the other financial institutions named as lenders therein, and Wells Fargo as administrative agent for the lenders.  The Amended Credit Agreement provides for a $200.0 million senior secured revolving credit facility and a $100.0 million senior secured term loan facility (collectively, the “Facilities”), with an option to request increases in the amounts of such credit facilities by up to an additional $50.0 million in the aggregate (any such increase to be in each lender’s sole discretion), and matures on March 3, 2020.  The $100.0 million term loan facility of the Amended Credit Agreement was fully drawn at closing, and $72.3 million was used to repay the outstanding balance under its original credit agreement.

- changed (2017-02-09):
[0001511737-17-000003:note_history:22]
|  | December 31, 2016 |  | June 30, 2016 |
| Term Loan - short term | $ | 13,750 |  |  | $ | 11,250 |  |
| Debt issuance costs, net (1) | (257 | ) |  | (257 | ) |
| Total Debt - short term | 13,493 |  |  | 10,993 |  |
| Term Loan - long term | 68,750 |  |  | 76,250 |  |
| Revolver - long term | 116,000 |  |  | 116,000 |  |
| Debt issuance costs, net (1) | (556 | ) |  | (686 | ) |
| Total Debt - long term | $ | 184,194 |  |  | $ | 191,564 |  |
  (was, 2016-11-07, similarity 0.9902):
[0001511737-16-000045:note_history:22]
|  | September 30, 2016 |  | June 30, 2016 |
| Term Loan - short term | $ | 12,500 |  |  | $ | 11,250 |  |
| Debt Issuance costs, net (1) | (257 | ) |  | (257 | ) |
| Total Debt - short term | 12,243 |  |  | 10,993 |  |
| Term Loan - long term | 72,500 |  |  | 76,250 |  |
| Revolver - long term | 116,000 |  |  | 116,000 |  |
| Debt issuance costs, net (1) | (621 | ) |  | (686 | ) |
| Total Debt - long term | $ | 187,879 |  |  | $ | 191,564 |  |

- changed (2017-02-09):
[0001511737-17-000003:note_history:23]
As of December 31, 2016, the interest rate on the term loan was 2.50%. The table below shows the respective interest rates as of December 31, 2016 in addition to interest rate reset dates and rates as available for each revolver draw.
  (was, 2016-11-07, similarity 0.6063):
[0001511737-16-000045:note_history:23]
As of September 30, 2016, the interest rate on the term loan was 2.34%.  The table below shows the respective interest rates as of September 30, 2016 in addition to interest rate reset dates and rates as available for each revolver draw.

- added (2017-02-09):
[0001511737-17-000003:note_history:24]
|  |  | Interest Rate as of |  |  |  |  |
| Debt Payment Obligations |  | December 31, 2016 |  | Rate Reset Date |  | Reset Rate |
| $15 Million Revolver |  | 2.42% |  | 1/9/2017 |  | 2.51% |
| $18 Million Revolver |  | 2.48% |  | 1/18/2017 |  | 2.52% |
| $16 Million Revolver |  | 2.70% |  | 2/13/2017 |  | * |
| $19 Million Revolver |  | 2.41% |  | 1/3/2017 |  | 2.50% |
| $48 Million Revolver |  | 2.44% |  | 2/28/2017 |  | * |

- changed (2017-02-09):
[0001511737-17-000003:note_history:25]
The Revolving Facility includes a sub-limit of $10.0 million for letters of credit and a sub-limit of $25.0 million for swingline loans. Under the Amended Credit Agreement, revolving loans and swingline loans may be borrowed, repaid and reborrowed until March 3, 2020, at which time all amounts borrowed must be repaid. The term loan is payable in quarterly installments of 2.50% of the original principal amount of the term loan until March 31, 2017, thereafter increasing to 3.75% of the original principal amount of the term loan, in each case plus accrued and unpaid interest. Revolving, swingline and term loans may be prepaid at any time without penalty.
  (was, 2016-11-07, similarity 0.823):
[0001511737-16-000045:note_history:25]
The revolving credit facility includes a sub-limit of $10.0 million for letters of credit and a sub-limit of $25.0 million for swingline loans. The Facilities replaced the Company’s $150.0 million senior secured revolving credit facility under its original credit agreement. The Facilities are available for working capital and general corporate purposes that comply with the terms of the Amended Credit Agreement. Under the Amended Credit Agreement, revolving loans and swingline loans may be borrowed, repaid and reborrowed until March 3, 2020, at which time all amounts borrowed must be repaid. The term loan is payable in quarterly installments of 2.50% of the original principal amount of the term loan until March 31, 2017, thereafter increasing to 3.75% of the original principal amount of the term loan, in each case plus accrued and unpaid interest. Revolving, swingline and term loans may be prepaid at any time without penalty.

- added (2017-02-09):
[0001511737-17-000003:note_history:26]
During the three months ended December 31, 2016, the Company made a payment of $3.0 million against the balance under the Term Facility, of which $2.5 million was a repayment of principal and $0.5 million was payment of interest. During the six months ended December 31, 2016, the Company made aggregate payments of $6.0 million against the balance under the Term Facility, of which $5.0 million was a repayment of principal and $1.0 million was payment of interest.

- added (2017-02-09):
[0001511737-17-000003:note_history:27]
During the three months ended December 31, 2016, the Company made a payment of $1.1 million of interest under the Revolving Facility. During the six months ended December 31, 2016, the Company made aggregate payments of $1.5 million of interest under the Revolving Facility.

- changed (2017-02-09):
[0001511737-17-000003:note_history:28]
On September 2, 2015, the Company accessed a letter of credit under its Revolving Facility in the amount of $0.2 million for the benefit of the landlord pursuant to a new lease of office space. The landlord can draw against the letter of credit in the event of a lease default by the Company. The letter of credit expires on September 2, 2017, subject to automatic renewal for additional one-year periods.
  (was, 2016-11-07, similarity 0.9618):
[0001511737-16-000045:note_history:28]
On September 2, 2015, the Company accessed a letter of credit under its revolving credit facility in the amount of $237 thousand for the benefit of the landlord pursuant to a new lease of office space. The landlord can draw against the letter of credit in the event of default by the Company. The letter of credit expires on September 2, 2017, subject to automatic renewal for additional one-year periods.

- changed (2017-02-09):
[0001511737-17-000003:note_history:29]
The following table summarizes our estimated debt and interest payment obligations as of December 31, 2016, for the remainder of fiscal 2017 and future fiscal years (in thousands):
  (was, 2016-11-07, similarity 0.9854):
[0001511737-16-000045:note_history:29]
The following table summarizes our estimated debt and interest payment obligations as of September 30, 2016, for the remainder of fiscal 2017 and future fiscal years (in thousands):

- changed (2017-02-09):
[0001511737-17-000003:note_history:30]
|  | 2017 (remainder) |  | 2018 |  | 2019 |  | 2020 |  | 2021 |  | Thereafter |  | Total |
| Debt payment obligations | $ | 6,250 |  |  | $ | 15,000 |  |  | $ | 15,000 |  |  | $ | 162,250 |  |  | $ | — |  |  | $ | — |  |  | $ | 198,500 |  |
| Interest and other payments on debt payment obligations (1) | 2,526 |  |  | 4,803 |  |  | 4,429 |  |  | 2,814 |  |  | — |  |  | — |  |  | 14,572 |  |
| Total | $ | 8,776 |  |  | $ | 19,803 |  |  | $ | 19,429 |  |  | $ | 165,064 |  |  | $ | — |  |  | $ | — |  |  | $ | 213,072 |  |
  (was, 2016-11-07, similarity 0.7405):
[0001511737-16-000045:note_history:30]
|  | 2017 (remainder) |  | 2018 |  | 2019 |  | 2020 |  | Thereafter |  | Total |
| Debt payment obligations | $ | 8,750 |  |  | $ | 15,000 |  |  | $ | 15,000 |  |  | $ | 162,250 |  |  | $ | — |  |  | $ | 201,000 |  |
| Interest and other payments on debt payment obligations (1) | 3,754 |  |  | 4,712 |  |  | 4,361 |  |  | 2,781 |  |  | — |  |  | 15,608 |  |
| Total | $ | 12,504 |  |  | $ | 19,712 |  |  | $ | 19,361 |  |  | $ | 165,031 |  |  | $ | — |  |  | $ | 216,608 |  |

- changed (2017-02-09):
[0001511737-17-000003:note_history:31]
(1) - Interest payments are calculated based on the applicable rates and payment dates as of December 31, 2016. Furthermore, two to three-month payment intervals on the revolving debt have been assumed, consistent with the Company's elections to date.
  (was, 2016-11-07, similarity 0.9857):
[0001511737-16-000045:note_history:31]
(1) - Interest payments are calculated based on the applicable rates and payment dates as of September 30, 2016. Furthermore, two to three-month payment intervals on the revolving debt have been assumed, consistent with the Company's elections to date.

- removed (2017-02-09):
[0001511737-16-000045:note_history:32]
|  |  | Interest Rate as of |  |  |  |  |
| Debt Payment Obligations |  | September 30, 2016 |  | Rate Reset Date |  | Reset Rate |
| $15 Million Revolver |  | 2.42% |  | 01/09/2017 |  | * |
| $18 Million Revolver |  | 2.48% |  | 01/18/2017 |  | * |
| $16 Million Revolver |  | 2.70% |  | 02/13/2017 |  | * |
| $19 Million Revolver |  | 2.41% |  | 01/03/2017 |  | * |
| $48 Million Revolver |  | 2.48% |  | 11/30/2016 |  | * |

- removed (2017-02-09):
[0001511737-16-000045:note_history:33]
During the three months ended September 30, 2016, the Company made a payment of $3.0 million against the term loan facility under the Amended Credit Agreement, of which $2.5 million was a repayment of principal and $0.5 million was payment of interest. During the three months ended September 30, 2016, the Company made a payment of $0.4 million interest against the revolver loan facility under the Amended Credit Agreement. As of September 30, 2016, excluding debt issuance costs, the Company classified $12.5 million and $188.5 million as short-term and as long-term debt, respectively, on its consolidated balance sheet.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-02-09):
[0001511737-17-000003:note_history:34]
The table below shows the respective interest rates as of December 31, 2016 in addition to interest rate reset dates and rates as available for each revolver draw.
  (was, 2016-11-07, similarity 0.9842):
[0001511737-16-000045:note_history:34]
The table below shows the respective interest rates as of September 30, 2016 in addition to interest rate reset dates and rates as available for each revolver draw.

- added (2017-02-09):
[0001511737-17-000003:note_history:35]
|  |  | Interest Rate as of |  |  |  |  |
| Debt Payment Obligations |  | December 31, 2016 |  | Rate Reset Date |  | Reset Rate |
| $15 Million Revolver |  | 2.42% |  | 1/9/2017 |  | 2.51% |
| $18 Million Revolver |  | 2.48% |  | 1/18/2017 |  | 2.52% |
| $16 Million Revolver |  | 2.70% |  | 2/13/2017 |  | * |
| $19 Million Revolver |  | 2.41% |  | 1/3/2017 |  | 2.50% |
| $48 Million Revolver |  | 2.44% |  | 2/28/2017 |  | * |

- removed (2017-02-09):
[0001511737-16-000045:note_history:36]
|  |  | Interest Rate as of |  |  |  |  |
| Debt Payment Obligations |  | September 30, 2016 |  | Rate Reset Date |  | Reset Rate |
| $15 Million Revolver |  | 2.42% |  | 01/09/2017 |  | * |
| $18 Million Revolver |  | 2.48% |  | 01/18/2017 |  | * |
| $16 Million Revolver |  | 2.70% |  | 02/13/2017 |  | * |
| $19 Million Revolver |  | 2.41% |  | 01/03/2017 |  | * |
| $48 Million Revolver |  | 2.48% |  | 11/30/2016 |  | * |


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-02-09):
[0001511737-17-000003:note_history:37]
The following table summarizes our estimated debt and interest payment obligations as of December 31, 2016, for the remainder of fiscal 2017 and future fiscal years (in thousands):
  (was, 2016-11-07, similarity 0.9854):
[0001511737-16-000045:note_history:37]
The following table summarizes our estimated debt and interest payment obligations as of September 30, 2016, for the remainder of fiscal 2017 and future fiscal years (in thousands):

- changed (2017-02-09):
[0001511737-17-000003:note_history:38]
|  | 2017 (remainder) |  | 2018 |  | 2019 |  | 2020 |  | 2021 |  | Thereafter |  | Total |
| Debt payment obligations | $ | 6,250 |  |  | $ | 15,000 |  |  | $ | 15,000 |  |  | $ | 162,250 |  |  | $ | — |  |  | $ | — |  |  | $ | 198,500 |  |
| Interest and other payments on debt payment obligations (1) | 2,526 |  |  | 4,803 |  |  | 4,429 |  |  | 2,814 |  |  | — |  |  | — |  |  | 14,572 |  |
| Total | $ | 8,776 |  |  | $ | 19,803 |  |  | $ | 19,429 |  |  | $ | 165,064 |  |  | $ | — |  |  | $ | — |  |  | $ | 213,072 |  |
  (was, 2016-11-07, similarity 0.7405):
[0001511737-16-000045:note_history:38]
|  | 2017 (remainder) |  | 2018 |  | 2019 |  | 2020 |  | Thereafter |  | Total |
| Debt payment obligations | $ | 8,750 |  |  | $ | 15,000 |  |  | $ | 15,000 |  |  | $ | 162,250 |  |  | $ | — |  |  | $ | 201,000 |  |
| Interest and other payments on debt payment obligations (1) | 3,754 |  |  | 4,712 |  |  | 4,361 |  |  | 2,781 |  |  | — |  |  | 15,608 |  |
| Total | $ | 12,504 |  |  | $ | 19,712 |  |  | $ | 19,361 |  |  | $ | 165,031 |  |  | $ | — |  |  | $ | 216,608 |  |

- changed (2017-02-09):
[0001511737-17-000003:note_history:39]
(1) - Interest payments are calculated based on the applicable rates and payment dates as of December 31, 2016. Furthermore, two to three-month payment intervals on the revolving debt have been assumed, consistent with the Company's elections to date.
  (was, 2016-11-07, similarity 0.9857):
[0001511737-16-000045:note_history:39]
(1) - Interest payments are calculated based on the applicable rates and payment dates as of September 30, 2016. Furthermore, two to three-month payment intervals on the revolving debt have been assumed, consistent with the Company's elections to date.

- changed (2017-02-09):
[0001511737-17-000003:note_history:40]
|  | December 31, 2016 |  | June 30, 2016 |
| Term Loan - short term | $ | 13,750 |  |  | $ | 11,250 |  |
| Debt issuance costs, net (1) | (257 | ) |  | (257 | ) |
| Total Debt - short term | 13,493 |  |  | 10,993 |  |
| Term Loan - long term | 68,750 |  |  | 76,250 |  |
| Revolver - long term | 116,000 |  |  | 116,000 |  |
| Debt issuance costs, net (1) | (556 | ) |  | (686 | ) |
| Total Debt - long term | $ | 184,194 |  |  | $ | 191,564 |  |
  (was, 2016-11-07, similarity 0.9902):
[0001511737-16-000045:note_history:40]
|  | September 30, 2016 |  | June 30, 2016 |
| Term Loan - short term | $ | 12,500 |  |  | $ | 11,250 |  |
| Debt Issuance costs, net (1) | (257 | ) |  | (257 | ) |
| Total Debt - short term | 12,243 |  |  | 10,993 |  |
| Term Loan - long term | 72,500 |  |  | 76,250 |  |
| Revolver - long term | 116,000 |  |  | 116,000 |  |
| Debt issuance costs, net (1) | (621 | ) |  | (686 | ) |
| Total Debt - long term | $ | 187,879 |  |  | $ | 191,564 |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2017-02-09):
[0001511737-17-000003:note_history:41]
On November 13, 2013, the Company entered into an aircraft lease agreement (the “Aircraft Lease Agreement”) with RJP Manageco LLC (the “Lessor”), a limited liability company owned by the Company’s CEO, Robert J. Pera. Pursuant to the Aircraft Lease Agreement, the Company may lease an aircraft owned by the Lessor for Company business purposes. Under the Aircraft Lease Agreement, the aircraft may be leased at a rate of $5,000 per flight hour. This hourly rate does not include the cost of flight crew or on-board services, which the Company purchases from a third-party provider. The Company recognized a total of approximately $0.5 million and $1.2 million in expenses pursuant to the Aircraft Lease Agreement during the three and six months ended December 31, 2016, respectively.  The Company recognized a total of approximately $0.4 million and $0.6 million in expenses pursuant to the Aircraft Lease Agreement during the three and six months ended December 31, 2015, respectively. All expenses pursuant to the Aircraft Lease Agreement have been included in the Company’s sales, general and administrative expenses in the Consolidated Statements of Operations.
  (was, 2016-11-07, similarity 0.6837):
[0001511737-16-000045:note_history:41]
On November 13, 2013, the Company entered into an aircraft lease agreement (the “Aircraft Lease Agreement”) with RJP Manageco LLC (the “Lessor”), a limited liability company owned by the Company’s CEO, Robert J. Pera. Pursuant to the Aircraft Lease Agreement, the Company may lease an aircraft owned by the Lessor for Company business purposes. Under the Aircraft Lease Agreement, the aircraft may be leased at a rate of $5,000 per flight hour. This hourly rate does not include the cost of flight crew or on-board services, which the Company purchases from a third-party provider. The Company recognized a total of approximately $650 thousand and $213 thousand in expenses pursuant to the Aircraft Lease Agreement during the three months ended September 30, 2016 and 2015, respectively.  All expenses pursuant to the Aircraft Lease Agreement have been included in the Company’s sales, general and administrative expenses in the Consolidated Statements of Operations.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_prior_note, score: 0.0

- added (2017-02-09):
[0001511737-17-000003:note_history:42]
SUBSEQUENT EVENTS

- added (2017-02-09):
[0001511737-17-000003:note_history:43]
On February 3, 2017, Synopsys, Inc. (“Synopsys”) filed a complaint against the Company, one of our subsidiaries and certain employees in the United States District Court for the Northern District of California, alleging claims under the Digital Millennium Copyright Act. The Company plans to vigorously defend itself against these claims; however, there can be no assurance that the Company will prevail in the lawsuit. The Company cannot currently estimate the possible loss or range of losses, if any, that it may experience in connection with this litigation.
