# UI MD&A — 0001511737-17-000003


## mdna

[0001511737-17-000003:mdna:1]
[same as prior period, unchanged from 0001511737-16-000045:mdna:1]

[0001511737-17-000003:mdna:2]
[same as prior period, unchanged from 0001511737-16-000045:mdna:2]

[0001511737-17-000003:mdna:3]
[same as prior period, unchanged from 0001511737-16-000045:mdna:3]

[0001511737-17-000003:mdna:4]
[same as prior period, unchanged from 0001511737-16-000045:mdna:4]

[0001511737-17-000003:mdna:5]
In May 2016, we announced the creation of Ubiquiti Labs, a division focusing on research and development of consumer electronics. At the same time, we announced a new consumer product platform, called AmpliFi, which is a Wi-Fi system solution designed to serve the demands of the modern connected home.

[0001511737-17-000003:mdna:6]
[same as prior period, unchanged from 0001511737-16-000045:mdna:6]

[0001511737-17-000003:mdna:7]
| • | Rapid customer and community driven product development. We have an active, loyal community built by our customers that we believe is a sustainable competitive advantage. Our solutions benefit from the active engagement between the Ubiquiti Community and our development engineers throughout the product development cycle, which eliminates long and expensive multistep internal processes and results in rapid introduction and adoption of our products. This approach significantly reduces our development costs and time to market. |

[0001511737-17-000003:mdna:8]
[same as prior period, unchanged from 0001511737-16-000045:mdna:9]

[0001511737-17-000003:mdna:9]
[same as prior period, unchanged from 0001511737-16-000045:mdna:10]

[0001511737-17-000003:mdna:10]
By reducing the cost of development, sales, marketing and support, we are able to eliminate traditional business model inefficiencies and offer innovative solutions with disruptive price performance characteristics to our customers.

[0001511737-17-000003:mdna:11]
[same as prior period, unchanged from 0001511737-16-000045:mdna:12]

[0001511737-17-000003:mdna:12]
[same as prior period, unchanged from 0001511737-16-000045:mdna:13]

[0001511737-17-000003:mdna:13]
[same as prior period, unchanged from 0001511737-16-000045:mdna:14]

[0001511737-17-000003:mdna:14]
[same as prior period, unchanged from 0001511737-16-000045:mdna:15]

[0001511737-17-000003:mdna:15]
| • | Service Provider Technology includes our airMAX, EdgeMAX and airFiber platforms, as well as embedded radio products and other 802.11 standard products including base stations, radios, backhaul equipment and CPE. Additionally, Service Provider Technology includes antennas and other products primarily in the 0.9 to 6.0 GHz spectrum and miscellaneous products such as mounting brackets, cables and power over Ethernet adapters. Service Provider Technology also includes solar products (sales of which have not been material to date) and revenues that are attributable to PCS. |

[0001511737-17-000003:mdna:16]
| • | Enterprise Technology includes our UniFi and mFi platforms, including UniFi enterprise Wi-Fi, UniFi Video Products, UniFi switching and routing solutions. Enterprise Technology also includes AmpliFi products and revenues that are attributable to PCS. |

[0001511737-17-000003:mdna:17]
We sell substantially all of our products through a limited number of distributors and other channel partners, such as resellers and Original Equipment Manufacturers (“OEMs”). Sales to distributors accounted for 99% and 98% of revenues respectively, during the three and six months ended December 31, 2016.

[0001511737-17-000003:mdna:18]
[same as prior period, unchanged from 0001511737-16-000045:mdna:19]

[0001511737-17-000003:mdna:19]
[same as prior period, unchanged from 0001511737-16-000045:mdna:20]

[0001511737-17-000003:mdna:20]
[same as prior period, unchanged from 0001511737-16-000045:mdna:21]

[0001511737-17-000003:mdna:21]
[same as prior period, unchanged from 0001511737-16-000045:mdna:22]

[0001511737-17-000003:mdna:22]
[same as prior period, unchanged from 0001511737-16-000045:mdna:23]

[0001511737-17-000003:mdna:23]
[same as prior period, unchanged from 0001511737-16-000045:mdna:24]

[0001511737-17-000003:mdna:24]
[same as prior period, unchanged from 0001511737-16-000045:mdna:25]

[0001511737-17-000003:mdna:25]
[same as prior period, unchanged from 0001511737-16-000045:mdna:26]

[0001511737-17-000003:mdna:26]
[same as prior period, unchanged from 0001511737-16-000045:mdna:27]

[0001511737-17-000003:mdna:27]
[same as prior period, unchanged from 0001511737-16-000045:mdna:28]

[0001511737-17-000003:mdna:28]
[same as prior period, unchanged from 0001511737-16-000045:mdna:29]

[0001511737-17-000003:mdna:29]
Included in our deferred revenues is a portion related to PCS obligations that we estimate we will fulfill in the future. As of December 31, 2016 and June 30, 2016, we had deferred revenues of $6.0 million and $4.2 million, respectively, related to these obligations.

[0001511737-17-000003:mdna:30]
[same as prior period, unchanged from 0001511737-16-000045:mdna:31]

[0001511737-17-000003:mdna:31]
[same as prior period, unchanged from 0001511737-16-000045:mdna:32]

[0001511737-17-000003:mdna:32]
19

[0001511737-17-000003:mdna:33]
[same as prior period, unchanged from 0001511737-16-000045:mdna:33]

[0001511737-17-000003:mdna:34]
Comparison of Three and Six Months Ended December 31, 2016 and 2015

[0001511737-17-000003:mdna:35]
|  | Three Months Ended December 31, |  | Six Months Ended December 31, |
|  | 2016 |  | 2015 |  | 2016 |  | 2015 |
|  | (In thousands, except percentages) |
| Revenues | $ | 213,536 |  |  | 100 | % |  | $ | 161,871 |  |  | 100 | % |  | $ | 418,293 |  |  | 100 | % |  | $ | 313,286 |  |  | 100 | % |
| Cost of revenues(1) | 118,397 |  |  | 55 | % |  | 82,830 |  |  | 51 | % |  | 224,850 |  |  | 54 | % |  | 160,741 |  |  | 51 | % |
| Gross profit | 95,139 |  |  | 45 | % |  | 79,041 |  |  | 49 | % |  | 193,443 |  |  | 46 | % |  | 152,545 |  |  | 49 | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development(1) | 16,338 |  |  | 8 | % |  | 15,429 |  |  | 10 | % |  | 30,877 |  |  | 7 | % |  | 28,990 |  |  | 9 | % |
| Sales, general and administrative(1) | 9,001 |  |  | 4 | % |  | 7,433 |  |  | 5 | % |  | 17,864 |  |  | 4 | % |  | 15,575 |  |  | 5 | % |
| Business e-mail compromise (“BEC”) fraud loss/(recovery) | — |  |  | * |  |  | (257 | ) |  | * |  |  | — |  |  | * |  |  | (8,291 | ) |  | (3 | )% |
| Total operating expenses | 25,339 |  |  | 12 | % |  | 22,605 |  |  | 14 | % |  | 48,741 |  |  | 12 | % |  | 36,274 |  |  | 12 | % |
| Income from operations | 69,800 |  |  | 33 | % |  | 56,436 |  |  | 35 | % |  | 144,702 |  |  | 35 | % |  | 116,271 |  |  | 37 | % |
| Interest expense and other, net | (1,170 | ) |  | (1 | )% |  | (651 | ) |  | * |  |  | (2,269 | ) |  | (1 | )% |  | (767 | ) |  | * |  |
| Income before provision for income taxes | 68,630 |  |  | 32 | % |  | 55,785 |  |  | 34 | % |  | 142,433 |  |  | 34 | % |  | 115,504 |  |  | 37 | % |
| Provision for income taxes (2) | 8,022 |  |  | 4 | % |  | 6,333 |  |  | 4 | % |  | 10,037 |  |  | 2 | % |  | 12,293 |  |  | 4 | % |
| Net income and comprehensive income | $ | 60,608 |  |  | 28 | % |  | $ | 49,452 |  |  | 31 | % |  | $ | 132,396 |  |  | 32 | % |  | $ | 103,211 |  |  | 33 | % |
| * Less than 1% |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| (1) Includes stock-based compensation as follows: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of revenues | $ | 30 |  |  |  |  | $ | 114 |  |  |  |  | $ | 174 |  |  |  |  | $ | 227 |  |  |  |
| Research and development | 381 |  |  |  |  | 580 |  |  |  |  | 941 |  |  |  |  | 1,204 |  |  |  |
| Sales, general and administrative | 155 |  |  |  |  | 263 |  |  |  |  | 378 |  |  |  |  | 553 |  |  |  |
| Total stock-based compensation | $ | 566 |  |  |  |  | $ | 957 |  |  |  |  | $ | 1,493 |  |  |  |  | $ | 1,984 |  |  |  |
| (2) Includes the excess tax benefits resulting from the adoption of ASU 2016-09 Stock Compensation | $ | (860 | ) |  |  |  | $ | — |  |  |  |  | $ | (7,680 | ) |  |  |  | $ | — |  |  |  |

[0001511737-17-000003:mdna:36]
[same as prior period, unchanged from 0001511737-16-000045:mdna:36]

[0001511737-17-000003:mdna:37]
Total revenues increased $51.6 million, or 32%, from $161.9 million in the three months ended December 31, 2015 to $213.5 million in the three months ended December 31, 2016. Total revenues increased $105.0 million, or 34% from $313.3 million in the six months ended December 31, 2015 to $418.3 million in the six months ended December 31, 2016.

[0001511737-17-000003:mdna:38]
The drivers of both increases are discussed in further detail below. During the three and six months ended December 31, 2016, there were no material price changes in the Company's products sold.  During these periods there were changes in product mix, including a higher mix of Enterprise Technology products sold as compared to the three and six months ended December 31, 2015.

[0001511737-17-000003:mdna:39]
[same as prior period, unchanged from 0001511737-16-000045:mdna:38]

[0001511737-17-000003:mdna:40]
|  | Three Months Ended December 31, |  | Six Months Ended December 31, |
|  | 2016 |  | 2015 |  | 2016 |  | 2015 |
|  | (in thousands, except percentages) |
| Service provider Technology | $ | 115,580 |  |  | 54 | % |  | $ | 109,616 |  |  | 68 | % |  | $ | 236,212 |  |  | 56 | % |  | $ | 213,015 |  |  | 68 | % |
| Enterprise Technology | 97,956 |  |  | 46 | % |  | 52,255 |  |  | 32 | % |  | 182,081 |  |  | 44 | % |  | 100,271 |  |  | 32 | % |
| Total revenues | $ | 213,536 |  |  | 100 | % |  | $ | 161,871 |  |  | 100 | % |  | $ | 418,293 |  |  | 100 | % |  | $ | 313,286 |  |  | 100 | % |

[0001511737-17-000003:mdna:41]
Service Provider Technology revenue increased $6.0 million, or 5%, from $109.6 million in the three months ended December 31, 2015 to $115.6 million in the three months ended December 31, 2016. Service Provider Technology revenue

[0001511737-17-000003:mdna:42]
increased $23.2 million, or 11%, from $213.0 million in the six months ended December 31, 2015 to $236.2 million in the six months ended December 31, 2016.

[0001511737-17-000003:mdna:43]
The increase in Service Provider Technology revenue during the three months ended December 31, 2016 as compared to the same period in the prior year was primarily due to increased revenues in North America and offset by a decrease in Service Provider Technology revenues in Europe, the Middle East and Africa ("EMEA") and South America. The increase in Service Provider Technology revenue during the six months ended December 31, 2016 as compared to the same period in the prior year was primarily due to increased revenues for Service Provider Technology products in all regions except South America.

[0001511737-17-000003:mdna:44]
Enterprise Technology revenue increased $45.7 million, or 87%, from $52.3 million in the three months ended December 31, 2015 to $98.0 million in the three months ended December 31, 2016. Enterprise Technology revenue increased $81.8 million, or 82%, from $100.3 million in the six months ended December 31, 2015 to $182.1 million in the six months ended December 31, 2016. The increase in Enterprise Technology revenue during the three months ended December 31, 2016 as compared to the same period in the prior year was primarily due to product expansion and further adoption of our UniFi technology platform across all regions. Similarly, the increase in Enterprise Technology revenue during the six months ended December 31, 2016 as compared to the same period in the prior year was primarily due to product expansion and further adoption of our UniFi technology platform across all regions.

[0001511737-17-000003:mdna:45]
[same as prior period, unchanged from 0001511737-16-000045:mdna:42]

[0001511737-17-000003:mdna:46]
We have determined the geographical distribution of our product revenues based on our customers’ ship-to destinations. A majority of our sales are to distributors who either sell to resellers or directly to end customers, who may be located in different countries than the initial ship-to destination.  The following are our revenues by geography for the three and six months ended December 31, 2016 and 2015 (in thousands, except percentages):

[0001511737-17-000003:mdna:47]
|  | Three Months Ended December 31, |  | Six Months Ended December 31, |
|  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| North America(1) | $ | 94,609 |  |  | 44 | % |  | $ | 57,402 |  |  | 35 | % |  | $ | 168,774 |  |  | 40 | % |  | $ | 110,636 |  |  | 35 | % |
| South America | 19,285 |  |  | 9 | % |  | 23,526 |  |  | 15 | % |  | 43,469 |  |  | 10 | % |  | 45,674 |  |  | 15 | % |
| Europe, the Middle East and Africa ("EMEA") | 77,381 |  |  | 36 | % |  | 60,973 |  |  | 38 | % |  | 158,756 |  |  | 38 | % |  | 121,476 |  |  | 39 | % |
| Asia Pacific | 22,261 |  |  | 11 | % |  | 19,970 |  |  | 12 | % |  | 47,294 |  |  | 12 | % |  | 35,500 |  |  | 11 | % |
| Total revenues | $ | 213,536 |  |  | 100 | % |  | $ | 161,871 |  |  | 100 | % |  | $ | 418,293 |  |  | 100 | % |  | $ | 313,286 |  |  | 100 | % |

[0001511737-17-000003:mdna:48]
| (1) | Revenue for the United States was $90.2 million and $53.9 million for the three months ended December 31, 2016 and 2015, respectively. Revenue for the United States was $160.8 million and $104.5 million for the six months ended December 31, 2016 and 2015 respectively. |

[0001511737-17-000003:mdna:49]
[same as prior period, unchanged from 0001511737-16-000045:mdna:46]

[0001511737-17-000003:mdna:50]
Revenues in North America increased $37.2 million, or 65%, from $57.4 million in the three months ended December 31, 2015 to $94.6 million in the three months ended December 31, 2016.  Revenues increased $58.2 million, or 53%, from $110.6 million in the six months ended December 31, 2015 to $168.8 million in the six months ended December 31, 2016. The increase in North American revenues during both the three and six months ended December 31, 2016 as compared to the same periods in the prior year was primarily due to increased sales for both our Service Provider Technology products and Enterprise Technology products.

[0001511737-17-000003:mdna:51]
[same as prior period, unchanged from 0001511737-16-000045:mdna:48]

[0001511737-17-000003:mdna:52]
Revenues in South America decreased $4.2 million, or 18%, from $23.5 million in the three months ended December 31, 2015 to $19.3 million in the three months ended December 31, 2016. Revenues decreased $2.2 million, or 5%, from $45.7 million in the six months ended December 31, 2015 to $43.5 million in the six months ended December 31, 2016. The decrease in South American revenues during the three months ended December 31, 2016 as compared to the same period in the prior year was primarily due to decreased revenue from Service Provider Technology products. The decrease in South American revenues during the six months ended December 31, 2016 as compared to the same period in the prior year was primarily due to decreased revenues from Service Provider Technology products and offset by increased revenues from Enterprise Technology products.

[0001511737-17-000003:mdna:53]
[same as prior period, unchanged from 0001511737-16-000045:mdna:50]

[0001511737-17-000003:mdna:54]
Revenues in EMEA increased $16.4 million, or 27%, from $61.0 million in the three months ended December 31, 2015 to $77.4 million in the three months ended December 31, 2016. Revenues increased $37.3 million, or 31%, from $121.5 million in the six months ended December 31, 2015 to $158.8 million in the six months ended December 31, 2016. The increase in EMEA revenues during the three months ended December 31, 2016 as compared to the same period in the prior year was primarily due to increased revenues from Enterprise Technology products and offset by decreased revenues from Service Provider Technology products. The increase during the six months ended December 31, 2016 as compared to the same period in the prior year was primarily due to increased revenues from both our Service Provider Technology products and Enterprise Technology products.

[0001511737-17-000003:mdna:55]
[same as prior period, unchanged from 0001511737-16-000045:mdna:52]

[0001511737-17-000003:mdna:56]
Revenues in the Asia Pacific region increased $2.3 million, or 12%, from $20.0 million in the three months ended December 31, 2015 to $22.3 million in the three months ended December 31, 2016. Revenues increased $11.8 million, or 33%, from $35.5 million in the six months ended December 31, 2015 to $47.3 million in the six months ended December 31, 2016. The increase in Asia Pacific revenues during the three months ended December 31, 2016 as compared to the same periods in the prior year was primarily due to increased revenues from Enterprise Technology products and offset by decreased revenues from Service Provider Technology products. The increase during the six months ended December 31, 2016 as compared to the same period in the prior year was primarily due to increased revenues from both our Service Provider Technology products and Enterprise Technology products.

[0001511737-17-000003:mdna:57]
[same as prior period, unchanged from 0001511737-16-000045:mdna:54]

[0001511737-17-000003:mdna:58]
Cost of revenues increased $35.6 million, or 43%, from $82.8 million in the three months ended December 31, 2015 to $118.4 million in the three months ended December 31, 2016.  Cost of revenues increased $64.2 million, or 40%, from $160.7 million in the six months ended December 31, 2015 to $224.9 million in the six months ended December 31, 2016. The increase during both the three and six months ended December 31, 2016 was primarily due to our overall increase in revenues and to a lesser extent, an increase in shipping cost, warranty and inventory reserves.

[0001511737-17-000003:mdna:59]
Gross profit margin decreased to 45% in the three months ended December 31, 2016 compared to 49% in the three months ended December 31, 2015 and decreased to 46% in the six months ended December 31, 2016 compared to 49% in the six months ended December 31, 2015. The decrease during both the three and six months ended December 31, 2016 was primarily due to change in mix of products sold and to a lesser extent, an increase in shipping cost, warranty and inventory reserves.

[0001511737-17-000003:mdna:60]
[same as prior period, unchanged from 0001511737-16-000045:mdna:57]

[0001511737-17-000003:mdna:61]
[same as prior period, unchanged from 0001511737-16-000045:mdna:58]

[0001511737-17-000003:mdna:62]
Research and development (“R&D”) expenses increased $0.9 million, or 6%, from $15.4 million in the three months ended December 31, 2015 to $16.3 million in the three months ended December 31, 2016. As a percentage of revenues, research and development expenses decreased from 10% in the three months ended December 31, 2015 to 8% in the three months ended December 31, 2016. R&D expenses increased $1.9 million, or 7%, from $29.0 million in the six months ended December 31, 2015 to $30.9 million in the six months ended December 31, 2016. As a percentage of revenues, R&D expenses decreased from 9% in the six months ended December 31, 2015 to 7% in the six months ended December 31, 2016.

[0001511737-17-000003:mdna:63]
The increase in research and development expenses in absolute dollars during both the three and six months ended December 31, 2016 was primarily due to increases in headcount and development activities and offset, in part, by the $2.5 million impairment charge for capitalized software development cost recognized in the three and six months ended December 31, 2015. The increase in headcount and development cost reflects the increased efforts to broaden our research and development activities to introduce new products and new versions of existing products. As a percentage of revenues, R&D expenses decreased primarily due to our overall increase in revenues.

[0001511737-17-000003:mdna:64]
[same as prior period, unchanged from 0001511737-16-000045:mdna:60]

[0001511737-17-000003:mdna:65]
Sales, general and administrative expenses increased $1.6 million, or 22%, from $7.4 million in the three months ended December 31, 2015 to $9.0 million in the three months ended December 31, 2016.  As a percentage of revenues, sales, general and administrative expenses decreased from 5% in the three months ended December 31, 2015 to 4% in the three months ended December 31, 2016.  Sales, general and administrative expenses increased $2.3 million, or 15%, from $15.6 million in the six months ended December 31, 2015 to $17.9 million in the six months ended December 31, 2016. As a percentage of revenues, sales, general and administrative expenses decreased from 5% in the six months ended December 31, 2015 to 4% in the six months ended December 31, 2016.

[0001511737-17-000003:mdna:66]
Increases in sales, general and administrative expenses in absolute dollars during both the three and six months ended December 31, 2016 as compared to the same period in the prior year are primarily due to an increase in headcount in the

[0001511737-17-000003:mdna:67]
business development organization and the overall increases in business development initiatives and offset, in part, by lower cost for interim management and advisory services to remediate internal control weaknesses. As a percentage of revenues, sales, general and administrative expenses decreased primarily due to our overall increase in revenues.

[0001511737-17-000003:mdna:68]
[same as prior period, unchanged from 0001511737-16-000045:mdna:62]

[0001511737-17-000003:mdna:69]
Our provision for income taxes increased $1.7 million or 27%, from $6.3 million for the three months ended December 31, 2015 to $8.0 million for the three months ended December 31, 2016. Our effective tax rate increased to 12% for the three months ended December 31, 2016 as compared to 11% for the three months ended December 31, 2015. The higher effective tax rate in the three months ended December 31, 2016 was primarily due to taxes on increased sales in the U.S., partially offset by the recognition of excess tax benefits of $0.9 million. Such excess tax benefits were recorded as a reduction of the provision for income taxes for the three months ended December 31, 2016. The benefit resulted from the adoption of ASU 2016-09. See Note 2 for information on the impact of the adoption of ASU 2016-09. Our provision for income taxes decreased $2.3 million, or 18%, from $12.3 million for the six months ended December 31, 2015 to $10.0 million for the six months ended December 31, 2016. Our effective tax rate decreased to 7% for the six months ended December 31, 2016 as compared to 11% for the six months ended December 31, 2015. The decrease in the six months ended December 31, 2016 was primarily due to the recognition of the excess tax benefits of $7.7 million as a result of the adoption of ASU 2016-09.

[0001511737-17-000003:mdna:70]
[same as prior period, unchanged from 0001511737-16-000045:mdna:64]

[0001511737-17-000003:mdna:71]
[same as prior period, unchanged from 0001511737-16-000045:mdna:65]

[0001511737-17-000003:mdna:72]
Since inception, our operations primarily have been funded through cash generated by operations and proceeds from our various debt agreements. Cash and cash equivalents increased from $551.0 million at June 30, 2016 to $612.7 million at December 31, 2016.

[0001511737-17-000003:mdna:73]
[same as prior period, unchanged from 0001511737-16-000045:mdna:67]

[0001511737-17-000003:mdna:74]
[same as prior period, unchanged from 0001511737-16-000045:mdna:68]

[0001511737-17-000003:mdna:75]
|  | Six Months Ended December 31, |
|  | 2016 |  | 2015 |
|  | (In thousands) |
| Net cash provided by operating activities | $ | 75,671 |  |  | $ | 125,074 |  |
| Net cash used in investing activities | (2,836 | ) |  | (3,022 | ) |
| Net cash (used in) provided by financing activities | (11,141 | ) |  | (71,781 | ) |
| Net increase (decrease) in cash and cash equivalents | $ | 61,694 |  |  | $ | 50,271 |  |

[0001511737-17-000003:mdna:76]
[same as prior period, unchanged from 0001511737-16-000045:mdna:70]

[0001511737-17-000003:mdna:77]
Net cash provided by operating activities in the six months ended December 31, 2016 of $75.7 million consisted primarily of net income of $132.4 million partially offset by changes in operating assets and liabilities that resulted in net cash outflows of $63.0 million. These changes consisted primarily of a $30.2 million increase in accounts payable and accrued liabilities due to the timing of payments, a $33.3 million increase in accounts receivable due to overall higher revenues for the period, a $5.8 million increase in vendor deposit and a $48.2 million increase in inventory due to increase in warehouse stock levels in order to better support customers and reduce lead times, a $4.8 million increase in prepaid expense and other assets primarily due to the increase of non-trade accounts receivable, a $5.1 million increase in prepaid income taxes and a $2.2 million increase in taxes payable due to the timing of federal tax payments. Overall, cash inflows from operating activities were driven by our net income for the period, which included non-cash adjustments primarily due to stock-based compensation (net of excess tax benefit), depreciation and amortization, decreases to our provision for inventory obsolescence, and decreases to our provision for vendor deposits.  The net of these non-cash adjustments resulted in an increase to our net cash provided by operating activities of $6.3 million.

[0001511737-17-000003:mdna:78]
Net cash provided by operating activities in the six months ended December 31, 2015 of $125.1 million consisted primarily of net income of $103.2 million and net changes in operating assets and liabilities that resulted in net cash inflows of $13.8 million. These changes consisted primarily of a $4.4 million decrease in vendor deposits due to timing of deposit payments with our suppliers, a $0.8 million increase in prepaid expenses and other current assets, a $1.3 million decrease in accounts

[0001511737-17-000003:mdna:79]
receivable due to increased collections during the period, a $0.7 million decrease in accounts payable and accrued liabilities, a $0.2 million increase in deferred revenue due to additional PCS revenue deferrals during the period, a $2.6 million decrease in prepaid taxes due to the timing of federal tax payments, a $3.4 million decrease in inventory due to increased sales during the period and a $3.4 million increase in taxes payable. Additionally, our net income included non-cash adjustments due to stock-based compensation, depreciation and amortization, increases to our provision for inventory obsolescence, increases to our provision for sales returns, increases in deferred taxes, and a write off of software development costs. The net of these non-cash adjustments resulted in an increase of our net cash provided by operating activities of $8.1 million.

[0001511737-17-000003:mdna:80]
[same as prior period, unchanged from 0001511737-16-000045:mdna:74]

[0001511737-17-000003:mdna:81]
We used $2.8 million of cash in investing activities during the six months ended December 31, 2016.  Our investing activities consist of capital expenditures for machinery and equipment related to product development and prototyping activities in addition to purchases of intangible assets. Capital expenditures for the six months ended December 31, 2016 and 2015 were $2.7 million and $3.0 million, respectively.  Additionally, we had cash outflows related to the purchase of intangible assets of $69 thousand and $20 thousand during the six months ended December 31, 2016 and 2015, respectively, consisting primarily of legal costs associated with trademark applications and acquisition of domain names.

[0001511737-17-000003:mdna:82]
[same as prior period, unchanged from 0001511737-16-000045:mdna:76]

[0001511737-17-000003:mdna:83]
We used $11.1 million of cash in financing activities during the six months ended December 31, 2016. During the six months ended December 31, 2016, we paid $6.5 million for repurchases of our common stock. We also made repayments of $5.0 million on our outstanding term loan debt under the Term Facility. Additionally, cash inflows from financing activities included $1.3 million of cash proceeds received from the exercise of stock options partially offset by tax withholdings related to net share settlements of restricted stock units totaling $0.9 million.

[0001511737-17-000003:mdna:84]
We used $71.8 million of cash in financing activities during the six months ended December 31, 2015. During the six months ended December 31, 2015, we paid $100.0 million for repurchases of our common stock. We also made a $5.0 million repayment on our outstanding term loan debt under the Term Facility. Additionally, we drew $33.0 million under the Revolving Facility that was used for the repurchases of our common stock. Cash inflows from financing activities included $0.5 million of cash proceeds received from the exercise of stock options in addition to $0.4 million of excess tax benefit from employee stock-based awards, partially offset by tax withholdings related to net share settlements of restricted stock units of $0.7 million.

[0001511737-17-000003:mdna:85]
[same as prior period, unchanged from 0001511737-16-000045:mdna:79]

[0001511737-17-000003:mdna:86]
We believe our existing cash and cash equivalents, cash provided by operations and the availability of additional funds under the Facilities will be sufficient to meet our working capital and capital expenditure needs for at least the next twelve months. Our future capital requirements may vary materially from those currently planned and will depend on many factors, including our rate of revenue growth, the timing and extent of spending to support development efforts, the timing of new product introductions, market acceptance of our products and overall economic conditions. As of December 31, 2016, we held $572.7 million of our $612.7 million of cash and cash equivalents in accounts of our subsidiaries outside of the United States and we could incur material tax liabilities if we decide to repatriate those amounts.

[0001511737-17-000003:mdna:87]
[same as prior period, unchanged from 0001511737-16-000045:mdna:81]

[0001511737-17-000003:mdna:88]
Our products are generally accompanied by a twelve-month warranty from date of purchase, which covers both parts and labor. Generally the distributor is responsible for the freight costs associated with warranty returns, and we absorb the freight costs of replacing items under warranty. In accordance with the Financial Accounting Standards Board’s (“FASB’s”), Accounting Standards Codification (“ASC”), 450-20, Loss Contingencies, we record an accrual when we believe it is reasonably estimable and probable based upon historical experience. We record a provision for estimated future warranty work in cost of goods sold upon recognition of revenues, and we review the resulting accrual regularly and periodically adjust it to reflect changes in warranty estimates.

[0001511737-17-000003:mdna:89]
We have, and may in the future enter into standard indemnification agreements with many of our distributors and OEMs, as well as certain other business partners in the ordinary course of business. These agreements do, and may in the future include provisions for indemnifying the distributor, OEM or other business partner against any claim brought by a third-party to the extent any such claim alleges that a Ubiquiti product infringes a patent, copyright or trademark or violates any other proprietary rights of that third-party. The maximum amount of potential future indemnification is unlimited. The maximum potential amount of future payments we could be required to make under these indemnification agreements is not estimable.

[0001511737-17-000003:mdna:90]
We have agreed to indemnify our directors, officers and certain other employees for certain events or occurrences, subject to certain limits, while such persons are or were serving at our request in such capacity. We may terminate the indemnification agreements with these persons upon the termination of their services with us, but termination will not affect claims for indemnification related to events occurring prior to the effective date of termination. The maximum amount of potential future indemnification is unlimited. We have a Directors and Officers insurance policy that limits our potential exposure. We believe the fair value of these indemnification agreements is minimal.  We have not recorded any liabilities for these agreements as of December 31, 2016.

[0001511737-17-000003:mdna:91]
Based upon our historical experience and information known as of the date of this report, we do not believe it is likely that we have a material liability for the above indemnities at December 31, 2016.

[0001511737-17-000003:mdna:92]
[same as prior period, unchanged from 0001511737-16-000045:mdna:87]

[0001511737-17-000003:mdna:93]
The following table summarizes our contractual obligations as of December 31, 2016 for the remainder of fiscal 2017 and future fiscal years (in thousands):

[0001511737-17-000003:mdna:94]
|  | 2017 (remainder) |  | 2018 |  | 2019 |  | 2020 |  | 2021 |  | Thereafter |  | Total |
| Operating leases | $ | 3,678 |  |  | $ | 5,153 |  |  | $ | 2,576 |  |  | $ | 1,744 |  |  | $ | 1,085 |  |  | $ | 375 |  |  | $ | 14,611 |  |
| Debt payment obligations | 6,250 |  |  | 15,000 |  |  | 15,000 |  |  | 162,250 |  |  | — |  |  | — |  |  | 198,500 |  |
| Interest and other payments on debt payment obligations | 2,526 |  |  | 4,803 |  |  | 4,429 |  |  | 2,814 |  |  | — |  |  | — |  |  | 14,572 |  |
| Purchase obligations | 34,670 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 34,670 |  |
| Other obligations | 9,896 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 9,896 |  |
| Total | $ | 57,020 |  |  | $ | 24,956 |  |  | $ | 22,005 |  |  | $ | 166,808 |  |  | $ | 1,085 |  |  | $ | 375 |  |  | $ | 272,249 |  |

[0001511737-17-000003:mdna:95]
[same as prior period, unchanged from 0001511737-16-000045:mdna:90]

[0001511737-17-000003:mdna:96]
[same as prior period, unchanged from 0001511737-16-000045:mdna:91]

[0001511737-17-000003:mdna:97]
[same as prior period, unchanged from 0001511737-16-000045:mdna:92]

[0001511737-17-000003:mdna:98]
On March 3, 2015, we entered into the Amended Credit Agreement, that provides for a $200.0 million senior secured revolving credit facility and a $100.0 million senior secured term loan facility, with an option to request increases in the amounts of such credit facilities by up to an additional $50.0 million in the aggregate (any such increase to be in each lender’s sole discretion).  Please see Note 7 of the Notes to the Consolidated Financial Statements for more information. Although interest rates on our debt obligations will likely vary over time, we have assumed our interest rates as of December 31, 2016 as the interest rates for all fiscal years presented.  Furthermore, the interest payment intervals on our revolving debt are determined at the Company's election pursuant to the Amended Credit Agreement, and may change over time.  For purposes of the table above, we have assumed two to three-month payment intervals on our revolving debt, consistent with our elections to date.  Also included are estimated bank fees to be paid for unused portions of our Revolving Facility.

[0001511737-17-000003:mdna:99]
[same as prior period, unchanged from 0001511737-16-000045:mdna:94]

[0001511737-17-000003:mdna:100]
We subcontract with third parties to manufacture our products. During the normal course of business, our contract manufacturers procure components and manufacture product based upon orders placed by us.  Component and product inventory held by our contract manufacturers or our third-party logistics providers is not recorded on our balance sheet until legal title passes to the Company.  If we cancel all or part of the orders, we may still be liable to the contract manufacturers for the cost of the components they purchased and for manufacturing and other costs related to these components. We periodically review the potential liability, and no significant liabilities for cancellations have been recorded for the six months ended December 31, 2016. Our consolidated financial position and results of operations could be negatively impacted if we were required to compensate the contract manufacturers for any unrecorded liabilities incurred. The Company had inventory purchase obligations of $34.7 million as of December 31, 2016.

[0001511737-17-000003:mdna:101]
[same as prior period, unchanged from 0001511737-16-000045:mdna:96]

[0001511737-17-000003:mdna:102]
We had other obligations of $9.9 million as of December 31, 2016, which consisted primarily of commitments related to research and development projects.

[0001511737-17-000003:mdna:103]
[same as prior period, unchanged from 0001511737-16-000045:mdna:98]

[0001511737-17-000003:mdna:104]
As of December 31, 2016, we had $24.8 million of unrecognized tax benefits. This amount has not been included in the above table as the settlement period for the unrecognized tax benefits, including related accrued interest and penalties, cannot be determined.

[0001511737-17-000003:mdna:105]
[same as prior period, unchanged from 0001511737-16-000045:mdna:100]

[0001511737-17-000003:mdna:106]
[same as prior period, unchanged from 0001511737-16-000045:mdna:101]

[0001511737-17-000003:mdna:107]
[same as prior period, unchanged from 0001511737-16-000045:mdna:102]

[0001511737-17-000003:mdna:108]
When used in this Report, the words “anticipates,” “believes,” “could,” “seeks,” “estimates,” “expects,” “intends,” “may,” “plans” “potential,” “predicts,” “projects,” “should,” “will,” “would” or similar expressions and negatives of those terms are intended to identify forward-looking statements. These are statements that relate to future periods and include statements about our future results, sources of revenue, our continued growth, our gross margins, market trends, our product development, technological developments, the features, benefits and performance of our current and future products, the ability of our products to address a variety of markets, the anticipated growth of demand for connectivity worldwide, our growth strategies, future price reductions, our competitive status, our dependence on our senior management and our ability to attract and retain key personnel, dependency on and concentration of our distributors, our employee relations, current and potential litigation, the effects of government regulations, our compliance with laws and regulations, our expected future operating costs and expenses and expenditure levels for research and development, selling, general and administrative expenses, fluctuations in operating results, fluctuations in our stock price, our payment of dividends, our future liquidity and cash needs, our credit facility, future acquisitions of and investments in complimentary businesses and the expected impact of various accounting policies and rules adopted by the Financial Accounting Standards Board. Forward-looking statements are subject to risks and uncertainties that could cause actual results to differ materially from those projected. These risks and uncertainties include, but are not limited to, factors affecting our quarterly results, our ability to manage our growth, our ability to sustain or increase profitability, demand for our products, our ability to compete, our ability to rapidly develop new technology and introduce new products, our ability to safeguard our intellectual property, trends in the networking industry and fluctuations in general economic conditions, and the risks set forth throughout this Report, including under Part II “Other Information”, Item 1-Legal Proceedings and Item 1A- Risk Factors. These forward-looking statements speak only as of the date hereof. Except as required by law, we expressly disclaim any obligation or undertaking to release publicly any updates or revisions to any forward-looking statements contained herein to reflect any change in our expectations with regard thereto or any change in events, conditions or circumstances on which any such statement is based.
