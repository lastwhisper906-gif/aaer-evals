# UI 8-K — 0001415889-17-000235 filed 2017-02-09

## item codes, every 8-K on or before 2017-02-09

- 2017-02-09 0001415889-17-000235 — 2.02, 9.01
- 2016-12-16 0001415889-16-007589 — 5.07
- 2016-12-08 0001415889-16-007559 — 4.01, 8.01, 9.01
- 2016-11-03 0001415889-16-007334 — 2.02, 9.01
- 2016-08-17 0001415889-16-006877 — 8.01
- 2016-08-10 0001415889-16-006753 — 5.02
- 2016-08-04 0001415889-16-006679 — 2.02, 8.01, 9.01
- 2016-05-05 0001415889-16-005749 — 2.02, 5.02, 8.01, 9.01
- 2016-02-04 0001415889-16-004613 — 2.02, 9.01
- 2015-12-18 0001415889-15-004120 — 3.01, 5.07
- 2015-11-05 0001415889-15-003599 — 2.02, 8.01, 9.01
- 2015-10-16 0001415889-15-003433 — 5.02
- 2015-08-06 0001571049-15-006288 — 2.02, 5.02, 8.01, 9.01
- 2015-05-07 0001511737-15-000016 — 2.02, 9.01
- 2015-04-23 0001415889-15-001433 — 2.02, 5.02, 9.01
- 2015-03-06 0001415889-15-000787 — 1.01, 1.02, 2.03, 9.01
- 2015-02-05 0001511737-15-000008 — 2.02, 9.01
- 2014-12-18 0001193125-14-446627 — 5.07
- 2014-11-06 0001511737-14-000029 — 2.02, 9.01
- 2014-09-30 0001193125-14-359060 — 7.01, 9.01
- 2014-08-07 0001511737-14-000021 — 2.02, 9.01
- 2014-05-08 0001511737-14-000016 — 2.02, 9.01
- 2014-04-17 0001193125-14-146710 — 7.01
- 2014-03-06 0001193125-14-084883 — 8.01
- 2014-02-06 0001511737-14-000005 — 2.02, 9.01
- 2013-12-16 0001193125-13-474388 — 5.07
- 2013-11-22 0001193125-13-451511 — 5.02
- 2013-11-07 0001511737-13-000018 — 2.02, 9.01
- 2013-10-28 0001193125-13-413414 — 5.02, 9.01
- 2013-10-18 0001193125-13-404111 — 5.02, 9.01
- 2013-08-08 0001511737-13-000009 — 2.02, 9.01
- 2013-05-09 0001511737-13-000004 — 2.02
- 2013-03-25 0001193125-13-124353 — 5.07
- 2013-03-08 0001193125-13-098334 — 5.02, 9.01
- 2013-02-07 0001193125-13-043701 — 2.02, 9.01
- 2012-12-28 0001193125-12-518487 — 1.01
- 2012-12-17 0001193125-12-503742 — 7.01, 9.01
- 2012-12-13 0001193125-12-501894 — 5.02
- 2012-11-16 0001193125-12-474083 — 5.02
- 2012-11-13 0001193125-12-467376 — 5.02
- 2012-11-08 0001193125-12-460665 — 2.02, 9.01
- 2012-10-10 0001193125-12-420015 — 5.02, 9.01
- 2012-08-13 0001193125-12-352624 — 1.01, 2.03, 9.01
- 2012-08-09 0001193125-12-347776 — 1.01, 9.01
- 2012-08-09 0001193125-12-347732 — 2.02, 9.01
- 2012-05-01 0001193125-12-201012 — 2.02, 9.01
- 2012-03-30 0001193125-12-144074 — 5.02
- 2012-03-27 0001193125-12-134395 — 5.02, 9.01
- 2012-03-22 0001193125-12-127536 — 5.02
- 2012-01-31 0001193125-12-032079 — 2.02, 9.01
- 2011-12-27 0001193125-11-353002 — 1.01, 9.01
- 2011-12-06 0001193125-11-332192 — 5.02
- 2011-11-10 0001193125-11-306969 — 2.02, 9.01

## late-filing notifications on or before 2017-02-09

- none on or before 2017-02-09

## item 2.02 — earnings release, exhibit 99.1

[0001415889-17-000235:8k_2_02:1]
EX-99
2
ex99-02092017_010231.htm

[0001415889-17-000235:8k_2_02:2]
Blueprint

[0001415889-17-000235:8k_2_02:3]
UBIQUITI
NETWORKS REPORTS SECOND QUARTER FISCAL 2017 FINANCIAL
RESULTS

[0001415889-17-000235:8k_2_02:4]
~
Achieves Record Revenue ~

[0001415889-17-000235:8k_2_02:5]
~ Sixth Consecutive Quarter of Revenue Growth
~

[0001415889-17-000235:8k_2_02:6]
SAN
JOSE, Calif. – February 9, 2017 - Ubiquiti Networks, Inc.
(NASDAQ: UBNT) (“Ubiquiti” or the
“Company”) today announced results for the second
fiscal quarter of 2017 ended December 31, 2016.

[0001415889-17-000235:8k_2_02:7]
Second Quarter Fiscal 2017 Financial Summary

[0001415889-17-000235:8k_2_02:8]
●

[0001415889-17-000235:8k_2_02:9]
Revenues of $213.5 million, increasing 32%
year-over-year

[0001415889-17-000235:8k_2_02:10]
●

[0001415889-17-000235:8k_2_02:11]
GAAP gross profit of $95.1 million and non-GAAP gross profit of
$95.2 million

[0001415889-17-000235:8k_2_02:12]
●

[0001415889-17-000235:8k_2_02:13]
GAAP net income of $60.6 million and non-GAAP
net income of $60.1 million

[0001415889-17-000235:8k_2_02:14]
●

[0001415889-17-000235:8k_2_02:15]
GAAP and non-GAAP diluted EPS of
$0.72

[0001415889-17-000235:8k_2_02:16]
●

[0001415889-17-000235:8k_2_02:17]
Cash of $612.7
million

[0001415889-17-000235:8k_2_02:18]
Recent
Financial Highlights

[0001415889-17-000235:8k_2_02:19]
●

[0001415889-17-000235:8k_2_02:20]
Revenues increased 32% year-over-year and 4%
sequentially, primarily driven by robust demand for the
Company’s UniFi product family and increasing demand for new
offerings for the Ubiquiti service provider community.

[0001415889-17-000235:8k_2_02:21]
●

[0001415889-17-000235:8k_2_02:22]
Enterprise Technology revenues increased 87%
year-over-year and 16% sequentially, primarily fueled by the
continued adoption of the Company’s UniFi AC access points,
UniFi Switch, UniFi Video and other industry-leading products
targeting the Enterprise market. Enterprise revenues also
benefitted from strong initial sales of the Company’s new
consumer products, including the AmpliFi HD Mesh Router and AmpliFi
HD MeshPoints.

[0001415889-17-000235:8k_2_02:23]
●

[0001415889-17-000235:8k_2_02:24]
Service Provider Technology revenues increased
5% year-over-year, primarily driven by demand for new
offerings for the Ubiquiti service provider community.

[0001415889-17-000235:8k_2_02:25]
●

[0001415889-17-000235:8k_2_02:26]
Gross margin of 45% was negatively
impacted by product mix and discrete expedited shipping charges to
provide U.S. availability of the Company’s AmpliFi products
during the 2016 holiday season.

[0001415889-17-000235:8k_2_02:27]
●

[0001415889-17-000235:8k_2_02:28]
Non-GAAP diluted EPS increased 24%
year-over-year, demonstrating the continued scalability of
Ubiquiti’s unique business model, while
Ubiquiti’s 28%
net income margin continues to trend well above industry averages
of less than 20%.

[0001415889-17-000235:8k_2_02:29]
Recent
Product Highlights

[0001415889-17-000235:8k_2_02:30]
●

[0001415889-17-000235:8k_2_02:31]
Launched UniFi AC HD,
the highest performance access
point in the industry at the best value.

[0001415889-17-000235:8k_2_02:32]
●

[0001415889-17-000235:8k_2_02:33]
Expanded the UniFi Switch Portfolio,
introducing the US-16-XG, US-8-60W and US-8 and enabling
Ubiquiti’s rapidly growing base of enterprise customers to
manage the core to the edge of their wired networks.

[0001415889-17-000235:8k_2_02:34]
●

[0001415889-17-000235:8k_2_02:35]
Released AirOS 8.0, providing complete
compatibility between airMAX ac and airMAX devices.

[0001415889-17-000235:8k_2_02:36]
●

[0001415889-17-000235:8k_2_02:37]
Expanded the AmpliFi product family with
the introduction of AmpliFi HD MeshPoint from Ubiquiti
Labs.

[0001415889-17-000235:8k_2_02:38]
●

[0001415889-17-000235:8k_2_02:39]
Introduced UCRM, free software for
Ubiquiti’s service provider customers that streamlines
billing and customer management.

[0001415889-17-000235:8k_2_02:40]
Financial Results Summary ($, in millions, except per share
data)

[0001415889-17-000235:8k_2_02:41]
| Income statement highlights |  | F2Q17 |  | F1Q17 |  | F2Q16 |
| Revenues |  | 213.5 |  | 204.8 |  | 161.9 |
| Service Provider Technology |  | 115.6 |  | 120.6 |  | 109.6 |
| Enterprise Technology |  | 98.0 |  | 84.1 |  | 52.3 |
| Gross Profit |  | 95.1 |  | 98.3 |  | 79.0 |
| Gross Profit (%) |  | 44.6% |  | 48.0% |  | 48.8% |
| Total Operating Expenses |  | 25.3 |  | 23.4 |  | 22.6 |
| Income from Operations |  | 69.8 |  | 74.9 |  | 56.4 |
| GAAP Net Income |  | 60.6 |  | 71.8 |  | 49.5 |
| GAAP EPS (diluted) |  | 0.72 |  | 0.86 |  | 0.57 |
| Non-GAAP Net Income |  | 60.1 |  | 65.5 |  | 49.7 |
| Non-GAAP EPS (diluted) |  | 0.72 |  | 0.79 |  | 0.58 |

[0001415889-17-000235:8k_2_02:42]
Balance Sheet Highlights

[0001415889-17-000235:8k_2_02:43]
Total
cash and cash equivalents as of December 31, 2016 were $612.7
million, compared with $573.6 million as of September 30, 2016. We
held $572.7 million of cash and cash equivalents in accounts of the
Company’s subsidiaries outside of the United
States.

[0001415889-17-000235:8k_2_02:44]
This
quarter we experienced an increase in days sales outstanding in
accounts receivable ("DSO") to 50 days, compared with 43 days in
the prior quarter. DSO’s have increased over time and we
expect this increase to continue as the mix of the Company’s
distributors evolves toward larger volumes of products moving
through large distributors who qualify for credit terms. Enabling
these customers to purchase higher volumes of products on credit
terms allows them to shorten the cash conversion cycle and has
helped enable the Company to significantly expand its market share
while maintaining a conservative customer credit
profile.

[0001415889-17-000235:8k_2_02:45]
The
Company has invested in inventory to reduce customer lead times,
meet increasing demand and support the commensurate growth of the
Company’s customers. The Company is committed to optimizing inventory to correspond
with end-market demand. During F2Q17, the Company continued to
invest in inventory. Inventory at the end of the quarter was $104.4
million, up $24.6 million from F1Q17. The Company expects to hold 8
to 12 weeks of previously introduced product inventory in
warehouses going forward.

[0001415889-17-000235:8k_2_02:46]
Business Outlook

[0001415889-17-000235:8k_2_02:47]
Based
on recent business trends, the Company believes the demand
environment in its end markets supports the following forecast for
the Company's third fiscal quarter ending March 31, 2017. The
following are the Company’s financial performance estimates
for the third quarter of fiscal 2017:

[0001415889-17-000235:8k_2_02:48]
●

[0001415889-17-000235:8k_2_02:49]
Revenues between
$210 million and $220 million

[0001415889-17-000235:8k_2_02:50]
●

[0001415889-17-000235:8k_2_02:51]
GAAP diluted EPS of
$0.72 - $0.78

[0001415889-17-000235:8k_2_02:52]
●

[0001415889-17-000235:8k_2_02:53]
Non-GAAP diluted
EPS of $0.73 - $0.79

[0001415889-17-000235:8k_2_02:54]
Conference Call Information

[0001415889-17-000235:8k_2_02:55]
Ubiquiti
Networks will host a Q&A-only call to discuss the
Company’s financial results at 5:00 p.m. Eastern Time (2:00
p.m. Pacific Time) today. Management’s prepared remarks can
be found on the Investor Relations section of the Ubiquiti Networks
website, http://ir.ubnt.com/results.cfm.

[0001415889-17-000235:8k_2_02:56]
To
listen to the Q&A call via telephone, dial (877) 291-1296 (U.S.
toll-free) or (720) 259-9209 (International) Conference ID:
52655989. Participants should dial in at least 10 minutes prior to
the start of the call. Investors may also listen to a live webcast
of the Q&A conference call by visiting the Investor Relations
section of the Ubiquiti Networks website at http://ir.ubnt.com.

[0001415889-17-000235:8k_2_02:57]
A
recording of the Q&A call will be available approximately two
hours after the call concludes and will be accessible on the
Investor Relations section of the Ubiquiti Networks website,
http://ir.ubnt.com.

[0001415889-17-000235:8k_2_02:58]
About Ubiquiti Networks

[0001415889-17-000235:8k_2_02:59]
Ubiquiti Networks,
Inc. (Nasdaq: UBNT) eliminates barriers to connectivity for
under-networked enterprises, communities and consumers with its
leading-edge platforms that connect hundreds of millions of people
throughout the world.  With over 60 million devices sold
worldwide, through a network of over 100 distributors, to customers
in more than 180 countries and territories, Ubiquiti has maintained
an industry-leading financial profile by leveraging a unique
business model to develop products that combine innovative
technology with disruptive price-to-performance
characteristics.  Our growth is supported by the Ubiquiti
Community, a global grass-roots community of 4 million
entrepreneurial operators and systems integrators who engage in
thousands of forums.  For more information, join our community
at http://www.ubnt.com.

[0001415889-17-000235:8k_2_02:60]
Ubiquiti,
Ubiquiti Networks, the U logo, UBNT, airMAX, UniFi, airFiber, mFi,
EdgeMAX and AmpliFi are registered trademarks or trademarks of
Ubiquiti Networks, Inc. in the United States and other
countries.

[0001415889-17-000235:8k_2_02:61]
Investor Relations Contact

[0001415889-17-000235:8k_2_02:62]
Laura
Kiernan

[0001415889-17-000235:8k_2_02:63]
SVP
Investor Relations

[0001415889-17-000235:8k_2_02:64]
Ubiquiti
Networks

[0001415889-17-000235:8k_2_02:65]
laura.kiernan@ubnt.com

[0001415889-17-000235:8k_2_02:66]
Ph. 1-646-461-2769
x2016

[0001415889-17-000235:8k_2_02:67]
Forward-looking
statements are subject to certain risks and uncertainties that
could cause our actual future results to differ materially, or
cause a material adverse impact on our results. Potential risks and
uncertainties include, but are not limited to, fluctuations in our
operating results; varying demand for our products due to the
financial and operating condition of our distributors and their
customers, and distributors' inventory management practices;
political and economic conditions and volatility affecting the
stability of business environments, economic growth, currency
values, commodity prices and other factors that may influence the
ultimate demand for our products in particular geographies or
globally; impact of counterfeiting and our ability to contain such
impact; our reliance on a limited number of distributors; inability
of our contract manufacturers and suppliers to meet our demand; our
dependence on Qualcomm Atheros for chipsets without a short-term
alternative; as we move into new markets competition from certain
of our current or potential competitors who may be more established
in such markets; our ability to keep pace with technological and
market developments; success and timing of new product
introductions by us and the performance of our products generally;
our ability to effectively manage the significant increase in our
transactional sales volumes; we may become subject to warranty
claims, product liability and product recalls; that a substantial
majority of our sales are into countries outside the United States
and we are subject to numerous U.S. export control and economic
sanctions laws; costs related to responding to government inquiries
related to regulatory compliance; our reliance on the Ubiquiti
Community; our reliance on certain key members of our management
team, including our founder and chief executive officer, Robert J.
Pera; adverse tax-related matters such as tax audits, changes in
our effective tax rate or new tax legislative proposals; whether
the final determination of our income tax liability may be
materially different from our income tax provisions; the impact of
any intellectual property litigation and claims for
indemnification; litigation related to U.S. Securities laws; and
economic and political conditions in the United States and abroad.
We discuss these risks in greater detail under the heading
“Risk Factors” and elsewhere in our Annual Report on
Form 10-K for the year ended June 30, 2016, and subsequent
filings filed with the U.S. Securities and Exchange Commission (the
“SEC”), which are available at the SEC's website at
www.sec.gov. Copies may also be obtained by contacting the Ubiquiti
Networks Investor Relations Department, by email at IR@ubnt.com or
by visiting the Investor Relations section of the Ubiquiti Networks
website, http://ir.ubnt.com.

[0001415889-17-000235:8k_2_02:68]
Given
these uncertainties, you should not place undue reliance on these
forward-looking statements. Also, forward-looking statements
represent our management's beliefs and assumptions only as of the
date made. Except as required by law, Ubiquiti Networks undertakes
no obligation to update information contained herein. You should
review our SEC filings carefully and with the understanding that
our actual future results may be materially different from what we
expect.

[0001415889-17-000235:8k_2_02:69]
Use of Non-GAAP Financial Information

[0001415889-17-000235:8k_2_02:70]
To
supplement our condensed consolidated financial results prepared
under generally accepted accounting principles, or GAAP, we use
non-GAAP measures of net income and earnings per diluted share that
are adjusted to exclude certain costs, expenses and gains such as
stock based compensation expense, Business e-mail compromise
("BEC") fraud loss/(recovery), implementation of overhead
capitalization, the adoption of ASU 2016-09 Improvements to
Employee Share-Based Payments Accounting and the tax effects of
these non-GAAP adjustments. Reconciliations of the adjustments to
GAAP results for the three and six month periods ended December 31,
2016 and 2015 are provided below. In addition, an explanation of
the ways in which management uses non-GAAP financial information to
evaluate its business, the substance behind management's decision
to use this non-GAAP financial information, material limitations
associated with the use of non-GAAP financial information, the
manner in which management compensates for those limitations, and
the substantive reasons management believes that this non-GAAP
financial information provides useful information to investors is
included under "About our Non-GAAP Net Income and Adjustments"
after the tables below.

[0001415889-17-000235:8k_2_02:71]
Ubiquiti
Networks, Inc.

[0001415889-17-000235:8k_2_02:72]
Consolidated Statement of Operations

[0001415889-17-000235:8k_2_02:73]
(In thousands, except per share data)

[0001415889-17-000235:8k_2_02:74]
(Unaudited)

[0001415889-17-000235:8k_2_02:75]
|  | Three Months Ended December 31, | Six Months Ended December 31, |
|  | 2016 | 2015 | 2016 | 2015 |
| Revenues | $213,536 | $161,871 | $418,293 | $313,286 |
| Cost of revenues | 118,397 | 82,830 | 224,850 | 160,741 |
| Gross profit | 95,139 | 79,041 | 193,443 | 152,545 |
| Operating expenses: |  |  |  |  |
| Research and development | 16,338 | 15,429 | 30,877 | 28,990 |
| Sales, general and administrative | 9,001 | 7,433 | 17,864 | 15,575 |
| Business e-mail compromise (“BEC”) fraud loss/(recovery) | — | (257) | — | (8,291) |
| Total operating expenses | 25,339 | 22,605 | 48,741 | 36,274 |
| Income from operations | 69,800 | 56,436 | 144,702 | 116,271 |
| Interest expense and other, net | (1,170) | (651) | (2,269) | (767) |
| Income before provision for income taxes | 68,630 | 55,785 | 142,433 | 115,504 |
| Provision for income taxes | 8,022 | 6,333 | 10,037 | 12,293 |
| Net income and comprehensive income | $60,608 | $49,452 | $132,396 | $103,211 |
| Net income per share of common stock: |  |  |  |  |
| Basic | $0.74 | $0.58 | $1.61 | $1.20 |
| Diluted | $0.72 | $0.57 | $1.58 | $1.18 |
| Weighted average shares used in computing net income per share of common stock: |  |  |  |  |
| Basic | 82,169 | 84,724 | 81,990 | 85,893 |
| Diluted | 83,888 | 86,091 | 83,875 | 87,285 |

[0001415889-17-000235:8k_2_02:76]
Ubiquiti
Networks, Inc.

[0001415889-17-000235:8k_2_02:77]
Reconciliation of GAAP Net Income to Non-GAAP Net
Income

[0001415889-17-000235:8k_2_02:78]
(In thousands, except per share data)

[0001415889-17-000235:8k_2_02:79]
|  | Three Months Ended December 31, | Six Months Ended December 31, |
|  | 2016 | 2015 | 2016 | 2015 |
| Net income and comprehensive income | $60,608 | $49,452 | $132,396 | $103,211 |
| Stock-based compensation: |  |  |  |  |
| Cost of revenues | 30 | 114 | 174 | 227 |
| Research and development | 381 | 580 | 941 | 1,204 |
| Sales, general and administrative | 155 | 263 | 378 | 553 |
| Business e-mail compromise (“BEC”) fraud loss/(recovery) | — | (257) | — | (8,291) |
| Excess tax benefits resulting from the adoption of ASU 2016-09 Stock Compensation | (860) | — | (7,680) | — |
| Implementation of overhead capitalization | — | (50) | — | (994) |
| Tax effect of Non-GAAP adjustments | (227) | (377) | (598) | (674) |
| Non-GAAP net income | $60,087 | $49,725 | $125,611 | $95,236 |
| Non-GAAP diluted EPS | $0.72 | $0.58 | $1.51 | $1.09 |
| Shares outstanding (Diluted) | 83,888 | 86,091 | 83,875 | 87,285 |
| Share adjustment (ASU 2016-09 Adoption) | (654) | — | (715) | — |
| Weighted-average shares used in Non-GAAP diluted EPS | 83,234 | 86,091 | 83,160 | 87,285 |

[0001415889-17-000235:8k_2_02:80]
| Ubiquiti Networks, Inc. Consolidated Balance Sheets (In thousands) (Unaudited) |  |  |

[0001415889-17-000235:8k_2_02:81]
|  | December 31, 2016 | June 30, 2016(1) |
| Assets |  |  |
| Current assets: |  |  |
| Cash and cash equivalents | $612,725 | $551,031 |
| Accounts receivable, net | 115,816 | 82,790 |
| Inventories | 104,417 | 57,113 |
| Vendor Deposits | 37,068 | 30,255 |
| Prepaid income taxes | 5,378 | 299 |
| Prepaid expenses and other current assets | 11,188 | 6,896 |
| Total current assets | 886,592 | 728,384 |
| Property and equipment, net | 12,622 | 12,953 |
| Long-term deferred tax assets | 4,195 | 4,195 |
| Other long-term assets | 2,029 | 1,576 |
| Total assets | $905,438 | $747,108 |
| Liabilities and Stockholders’ Equity |  |  |
| Current liabilities: |  |  |
| Accounts payable | $77,571 | $51,510 |
| Income taxes payable | 1,576 | 1,488 |
| Debt - short-term | 13,493 | 10,993 |
| Other current liabilities | 26,638 | 26,672 |
| Total current liabilities | 119,278 | 90,663 |
| Long-term taxes payable | 25,289 | 23,202 |
| Debt - long-term | 184,194 | 191,564 |
| Deferred revenues - long-term | 2,071 | 1,303 |
| Total liabilities | 330,832 | 306,732 |
| Stockholders’ equity: |  |  |
| Common stock | 82 | 82 |
| Additional paid–in capital | 1,834 | — |
| Retained earnings | 572,690 | 440,294 |
| Total stockholders’ equity | 574,606 | 440,376 |
| Total liabilities and stockholders’ equity | $905,438 | $747,108 |

[0001415889-17-000235:8k_2_02:82]
(1)

[0001415889-17-000235:8k_2_02:83]
Derived from
audited consolidated statements as of June 30,
2016.

[0001415889-17-000235:8k_2_02:84]
Ubiquiti Networks, Inc.

[0001415889-17-000235:8k_2_02:85]
Revenues by Technology Platform (In thousands)

[0001415889-17-000235:8k_2_02:86]
(Unaudited)

[0001415889-17-000235:8k_2_02:87]
|  | Three Months Ended December 31, | Six Months Ended December 31, |
|  | 2016 | 2015 | 2016 | 2015 |
| Service provider technology | $115,580 | $109,616 | $236,212 | $213,015 |
| Enterprise technology | 97,956 | 52,255 | 182,081 | 100,271 |
| Total revenues | $213,536 | $161,871 | $418,293 | $313,286 |

[0001415889-17-000235:8k_2_02:88]
Ubiquiti
Networks, Inc.Revenues by Region (In thousands)
(Unaudited)

[0001415889-17-000235:8k_2_02:89]
|  | Three Months Ended December 31, | Six Months Ended December 31, |
|  | 2016 | 2015 | 2016 | 2015 |
| North America | $94,609 | $57,402 | $168,774 | $110,636 |
| South America | 19,285 | 23,526 | 43,469 | 45,674 |
| Europe, the Middle East and Africa (EMEA) | 77,381 | 60,973 | 158,756 | 121,476 |
| Asia Pacific | 22,261 | 19,970 | 47,294 | 35,500 |
| Total revenues | $213,536 | $161,871 | $418,293 | $313,286 |

[0001415889-17-000235:8k_2_02:90]
About our Non-GAAP Net Income and Adjustments

[0001415889-17-000235:8k_2_02:91]
Use of Non-GAAP Financial Information

[0001415889-17-000235:8k_2_02:92]
To
supplement our condensed consolidated financial results prepared
under generally accepted accounting principles, or GAAP, we use
non-GAAP measures of net income and earnings per diluted share that
are GAAP net income and GAAP earnings per diluted share adjusted to
exclude certain costs, expenses and gains/losses.

[0001415889-17-000235:8k_2_02:93]
We
believe that the presentation of non-GAAP net income and non-GAAP
earnings per diluted share provides important supplemental
information regarding non-cash expenses, significant items that we
believe are important to understanding our financial, and business
trends relating to our financial condition and results of
operations. Non-GAAP net income and non-GAAP earnings per diluted
share are among the primary indicators used by management as a
basis for planning and forecasting future periods and by management
and our board of directors to determine whether our operating
performance has met specified targets and thresholds. Management
uses non-GAAP net income and non-GAAP earnings per diluted share
when evaluating operating performance because it believes that the
exclusion of the items described below, for which the amounts or
timing may vary significantly depending upon the Company's
activities and other factors, facilitates comparability of the
Company's operating performance from period to period. We have
chosen to provide this information to investors so they can analyze
our operating results in the same way that management does and use
this information in their assessment of our business and the
valuation of our Company.

[0001415889-17-000235:8k_2_02:94]
Use and Economic Substance of Non-GAAP Financial Measures used by
Ubiquiti Networks

[0001415889-17-000235:8k_2_02:95]
We
compute non-GAAP net income and non-GAAP earnings per diluted share
by adjusting GAAP net income and GAAP earnings per diluted share to
remove the impact of certain adjustments and the tax effect of
those adjustments. Items excluded from net income are:

[0001415889-17-000235:8k_2_02:96]
●

[0001415889-17-000235:8k_2_02:97]
Stock-based
compensation expense

[0001415889-17-000235:8k_2_02:98]
●

[0001415889-17-000235:8k_2_02:99]
Business e-mail
compromise ("BEC") fraud loss/(recovery)

[0001415889-17-000235:8k_2_02:100]
●

[0001415889-17-000235:8k_2_02:101]
Implementation of
overhead capitalization

[0001415889-17-000235:8k_2_02:102]
●

[0001415889-17-000235:8k_2_02:103]
Adoption of ASU
2016-09 Improvements to Employee Share-Base Payment
Accounting

[0001415889-17-000235:8k_2_02:104]
●

[0001415889-17-000235:8k_2_02:105]
Tax effect of
non-GAAP adjustments, applying the principles of ASC
740

[0001415889-17-000235:8k_2_02:106]
Usefulness of Non-GAAP Financial Information to
Investors

[0001415889-17-000235:8k_2_02:107]
These
non-GAAP measures are not in accordance with, or an alternative to,
GAAP and may be materially different from other non-GAAP measures,
including similarly titled non-GAAP measures used by other
companies. The presentation of this additional information should
not be considered in isolation from, as a substitute for, or
superior to, net income or earnings per diluted share prepared in
accordance with GAAP. Non-GAAP financial measures have limitations
in that they do not reflect certain items that may have a material
impact upon our reported financial results. We expect to continue
to incur expenses of a nature similar to the non-GAAP adjustments
described above, and exclusion of these items from our non-GAAP net
income and non-GAAP earnings per diluted share should not be
construed as an inference that these costs are unusual, infrequent
or non-recurring.

[0001415889-17-000235:8k_2_02:108]
For
more information on the non-GAAP adjustments, please see the table
captioned “Reconciliation of GAAP Net Income to Non-GAAP Net
Income” included in this press release.
