# UI 8-K — 0001415889-16-006679 filed 2016-08-04

## item codes, every 8-K on or before 2016-08-22

- 2016-08-17 0001415889-16-006877 — 8.01
- 2016-08-10 0001415889-16-006753 — 5.02
- 2016-08-04 0001415889-16-006679 — 2.02, 8.01, 9.01
- 2016-05-05 0001415889-16-005749 — 2.02, 5.02, 8.01, 9.01
- 2016-02-04 0001415889-16-004613 — 2.02, 9.01
- 2015-12-18 0001415889-15-004120 — 3.01, 5.07
- 2015-11-05 0001415889-15-003599 — 2.02, 8.01, 9.01
- 2015-10-16 0001415889-15-003433 — 5.02
- 2015-08-06 0001571049-15-006288 — 2.02, 5.02, 8.01, 9.01
- 2015-05-07 0001511737-15-000016 — 2.02, 9.01
- 2015-04-23 0001415889-15-001433 — 2.02, 5.02, 9.01
- 2015-03-06 0001415889-15-000787 — 1.01, 1.02, 2.03, 9.01
- 2015-02-05 0001511737-15-000008 — 2.02, 9.01
- 2014-12-18 0001193125-14-446627 — 5.07
- 2014-11-06 0001511737-14-000029 — 2.02, 9.01
- 2014-09-30 0001193125-14-359060 — 7.01, 9.01
- 2014-08-07 0001511737-14-000021 — 2.02, 9.01
- 2014-05-08 0001511737-14-000016 — 2.02, 9.01
- 2014-04-17 0001193125-14-146710 — 7.01
- 2014-03-06 0001193125-14-084883 — 8.01
- 2014-02-06 0001511737-14-000005 — 2.02, 9.01
- 2013-12-16 0001193125-13-474388 — 5.07
- 2013-11-22 0001193125-13-451511 — 5.02
- 2013-11-07 0001511737-13-000018 — 2.02, 9.01
- 2013-10-28 0001193125-13-413414 — 5.02, 9.01
- 2013-10-18 0001193125-13-404111 — 5.02, 9.01
- 2013-08-08 0001511737-13-000009 — 2.02, 9.01
- 2013-05-09 0001511737-13-000004 — 2.02
- 2013-03-25 0001193125-13-124353 — 5.07
- 2013-03-08 0001193125-13-098334 — 5.02, 9.01
- 2013-02-07 0001193125-13-043701 — 2.02, 9.01
- 2012-12-28 0001193125-12-518487 — 1.01
- 2012-12-17 0001193125-12-503742 — 7.01, 9.01
- 2012-12-13 0001193125-12-501894 — 5.02
- 2012-11-16 0001193125-12-474083 — 5.02
- 2012-11-13 0001193125-12-467376 — 5.02
- 2012-11-08 0001193125-12-460665 — 2.02, 9.01
- 2012-10-10 0001193125-12-420015 — 5.02, 9.01
- 2012-08-13 0001193125-12-352624 — 1.01, 2.03, 9.01
- 2012-08-09 0001193125-12-347776 — 1.01, 9.01
- 2012-08-09 0001193125-12-347732 — 2.02, 9.01
- 2012-05-01 0001193125-12-201012 — 2.02, 9.01
- 2012-03-30 0001193125-12-144074 — 5.02
- 2012-03-27 0001193125-12-134395 — 5.02, 9.01
- 2012-03-22 0001193125-12-127536 — 5.02
- 2012-01-31 0001193125-12-032079 — 2.02, 9.01
- 2011-12-27 0001193125-11-353002 — 1.01, 9.01
- 2011-12-06 0001193125-11-332192 — 5.02
- 2011-11-10 0001193125-11-306969 — 2.02, 9.01

## late-filing notifications on or before 2016-08-22

- none on or before 2016-08-22

## item 2.02 — earnings release, exhibit 99.1

[0001415889-16-006679:8k_2_02:1]
EX-99
2
ex99-08042016_010832.htm

[0001415889-16-006679:8k_2_02:2]
ubiquityex99-1.htm

[0001415889-16-006679:8k_2_02:3]
Exhibit 99.1

[0001415889-16-006679:8k_2_02:4]
UBIQUITI NETWORKS REPORTS PRELIMINARY FOURTH QUARTER FISCAL 2016 FINANCIAL RESULTS

[0001415889-16-006679:8k_2_02:5]
~ Achieves Record Revenue and Earnings ~

[0001415889-16-006679:8k_2_02:6]
~ Non-GAAP Diluted EPS of $0.69 Per Share ~

[0001415889-16-006679:8k_2_02:7]
SAN JOSE, Calif. – August 4, 2016 - Ubiquiti Networks, Inc. (NASDAQ:UBNT) (“Ubiquiti” or the “Company”) today announced results for the fourth fiscal quarter of 2016, ended June 30, 2016.

[0001415889-16-006679:8k_2_02:8]
Fourth Quarter Fiscal 2016 Financial Summary

[0001415889-16-006679:8k_2_02:9]
| • | Revenues of $185.7 million |

[0001415889-16-006679:8k_2_02:10]
| • | GAAP gross profit of $89.8 million and non-GAAP gross profit of $89.9 million |

[0001415889-16-006679:8k_2_02:11]
| • | GAAP net income of $57.7 million and non-GAAP net income of $58.2 million |

[0001415889-16-006679:8k_2_02:12]
| • | GAAP diluted EPS and non-GAAP diluted EPS of $0.69 |

[0001415889-16-006679:8k_2_02:13]
| • | Cash of $551.0 million, up 23% year-over-year |

[0001415889-16-006679:8k_2_02:14]
Recent Financial Highlights

[0001415889-16-006679:8k_2_02:15]
| • | Enterprise Technology revenues increased 89% year-over-year and 8% sequentially, fueled by new UniFi AC access points, UniFi Switch, UniFi Video and other industry-leading products targeting the Enterprise market. |

[0001415889-16-006679:8k_2_02:16]
| • | Non-GAAP Gross Margins increased 2.8% year-over-year to 48.3%, fueled by product mix, cost-reduction strategies and stable pricing. |

[0001415889-16-006679:8k_2_02:17]
| • | Non-GAAP diluted EPS increased 38% year-over-year and 10% sequentially, demonstrating the scalability of Ubiquiti’s unique business model. |

[0001415889-16-006679:8k_2_02:18]
| • | Completed $50 million stock repurchase plan as of June 30, 2016. |

[0001415889-16-006679:8k_2_02:19]
| • | Initiated a new stock repurchase program, authorizing the Company to repurchase up to $50 million of its common stock, as disclosed in the Form 8-K filed on August 4, 2016. |

[0001415889-16-006679:8k_2_02:20]
Recent Product Highlights

[0001415889-16-006679:8k_2_02:21]
| • | Continued strong demand for our new UniFi AC access points which feature Wi-Fi 802.11ac technology in a refined industrial design and are ideal for cost-effective deployment of high-performance wireless networks. |

[0001415889-16-006679:8k_2_02:22]
| • | Introduced AmpliFi™ from Ubiquiti Labs, the new Consumer Division of Ubiquiti Networks. With turbocharged 802.11AC Wi-Fi, AmpliFi utilizes multiple self-configuring radios and advanced antenna technology to bring ubiquitous Wi-Fi coverage to any home. |

[0001415889-16-006679:8k_2_02:23]
| • | Shipped in volume our UniFi Video products, plug and play, high-performance IP surveillance devices that scale easily across multiple locations. |

[0001415889-16-006679:8k_2_02:24]
-1-

[0001415889-16-006679:8k_2_02:25]
| • | Shipped the airFiber® AF 4X, a licensed spectrum backhaul radio with industry-leading spectral efficiency and TDD throughput. |

[0001415889-16-006679:8k_2_02:26]
| • | Expanded the UniFi Switch line. Now available with 16, 24 or 48 RJ45 Gigabit ports, the UniFi Switch delivers robust performance, PoE+ support, and intelligent switching for growing networks. |

[0001415889-16-006679:8k_2_02:27]
Financial Results Summary ($, in millions, except per share data)

[0001415889-16-006679:8k_2_02:28]
| Income statement highlights |  | F4Q16 |  | F3Q16 |  | F4Q15 |
| Revenues |  | 185.7 |  | 167.4 |  | 145.3 |
| Service Provider Technology |  | 109.0 |  | 96.3 |  | 104.8 |
| Enterprise Technology |  | 76.7 |  | 71.1 |  | 40.5 |
| Gross Profit |  | 89.8 |  | 82.5 |  | 66.1 |
| Gross Profit (%) |  | 48.3% |  | 49.3% |  | 45.5% |
| Total Operating Expenses (1) |  | 24.1 |  | 22.4 |  | 58.8 |
| Income from Operations |  | 65.6 |  | 60.1 |  | 7.3 |
| GAAP Net Income |  | 57.7 |  | 52.7 |  | 4.5 |
| GAAP EPS (diluted) |  | 0.69 |  | 0.62 |  | 0.05 |
| Non-GAAP Net Income |  | 58.2 |  | 53.0 |  | 44.1 |
| Non-GAAP EPS (diluted) |  | 0.69 |  | 0.63 |  | 0.50 |

[0001415889-16-006679:8k_2_02:29]
(1) Includes business e-mail compromise (“BEC”) fraud loss of $39.1 million in F4Q15.

[0001415889-16-006679:8k_2_02:30]
Balance Sheet Highlights

[0001415889-16-006679:8k_2_02:31]
Total cash and cash equivalents as of June 30, 2016 were $551.0 million, compared with $446.4 million as of June 30, 2015.  We held $524.3 million of our $551.0 million of cash and cash equivalents in accounts of our subsidiaries outside of the United States.

[0001415889-16-006679:8k_2_02:32]
On June 30, 2016, the Company extinguished the full $50.0 million available of a stock repurchase program approved by the Board of Directors of the Company on May 4, 2016.

[0001415889-16-006679:8k_2_02:33]
This quarter we saw days sales outstanding in accounts receivable ("DSO") of 41 days, compared with 41 days in the prior quarter and 41 days in the fourth quarter of fiscal 2015.

[0001415889-16-006679:8k_2_02:34]
Business Outlook

[0001415889-16-006679:8k_2_02:35]
Based on recent business trends, Ubiquiti currently believes the demand environment in its end markets supports the following forecast for the Company's first fiscal quarter ending September 30, 2016.  The following are Ubiquiti’s financial performance estimates for the first quarter of fiscal 2017:

[0001415889-16-006679:8k_2_02:36]
| • | Revenues between $180 million and $190 million |

[0001415889-16-006679:8k_2_02:37]
| • | GAAP diluted EPS of $0.67 - $0.73 |

[0001415889-16-006679:8k_2_02:38]
| • | Non-GAAP diluted EPS of $0.68 - $0.74 |

[0001415889-16-006679:8k_2_02:39]
Conference Call Information

[0001415889-16-006679:8k_2_02:40]
Ubiquiti Networks will host a Q&A-only call to discuss the Company’s financial results at 2:00 p.m. Pacific Time today.  Management’s prepared remarks can be found on the Investor Relations section of the Ubiquiti Networks website, http://ir.ubnt.com/results.cfm.

[0001415889-16-006679:8k_2_02:41]
To listen to the Q&A call via telephone, dial (877) 291-1296 (U.S. toll-free) or (720) 259-9209 (International) to be connected to the call by an operator.  Participants should dial in at least 10 minutes prior to the start of the call.  Investors may also listen to a live webcast of the Q&A conference call by visiting the Investor Relations section of the Ubiquiti Networks website at http://ir.ubnt.com.

[0001415889-16-006679:8k_2_02:42]
-2-

[0001415889-16-006679:8k_2_02:43]
A recording of the Q&A call will be available approximately two hours after the call concludes and will be accessible on the Investor Relations section of the Ubiquiti Networks website, http://ir.ubnt.com.

[0001415889-16-006679:8k_2_02:44]
About Ubiquiti Networks

[0001415889-16-006679:8k_2_02:45]
Ubiquiti Networks (Nasdaq:UBNT) is closing the digital divide by building network communication platforms for everyone and everywhere. With over 38 million devices sold worldwide, Ubiquiti is transforming under-networked enterprises and communities. Our leading edge platforms, airMAX®, UniFi®, airFiber®, UniFi® Video, mFi® and EdgeMAX®, combine innovative technology, disruptive price-to-performance and the support of a global user community to eliminate barriers to connectivity. For more information, join our community at http://www.ubnt.com.

[0001415889-16-006679:8k_2_02:46]
Ubiquiti, Ubiquiti Networks, the U logo, UBNT, airMAX, UniFi, airFiber, mFi, EdgeMAX and sunMAX are registered trademarks or trademarks of Ubiquiti Networks, Inc. in the United States and other countries.

[0001415889-16-006679:8k_2_02:47]
Investor Relations Contact

[0001415889-16-006679:8k_2_02:48]
Anne Fazioli

[0001415889-16-006679:8k_2_02:49]
Ubiquiti Networks, Vice President of Investor Relations

[0001415889-16-006679:8k_2_02:50]
IR@ubnt.com

[0001415889-16-006679:8k_2_02:51]
Forward-looking statements are subject to certain risks and uncertainties that could cause our actual future results to differ materially, or cause a material adverse impact on our results.  Potential risks and uncertainties include, but are not limited to, fluctuations in our operating results; varying demand for our products due to the financial and operating condition of our distributors and their customers, and distributors' inventory management practices; political and economic conditions and volatility affecting the stability of business environments, economic growth, currency values, commodity prices and other factors that may influence the ultimate demand for our products in particular geographies or globally; impact of counterfeiting and our ability to contain such impact; our reliance on a limited number of distributors; inability of our contract manufacturers and suppliers to meet our demand; our dependence on Qualcomm Atheros for chipsets without a short-term alternative; as we move into new markets competition from certain of our current or potential competitors who may be more established in such markets; our ability to keep pace with technological and market developments; success and timing of new product introductions by us and the performance of our products generally; our ability to effectively manage the significant increase in our transactional sales volumes; we may become subject to warranty claims, product liability and product recalls; that a substantial majority of our sales are into countries outside the United States and we are subject to numerous U.S. export control and economic sanctions laws; costs related to responding to government inquiries related to regulatory compliance; our reliance on the Ubiquiti Community; our reliance on certain key members of our management team, including our founder and chief executive officer, Robert J. Pera; adverse tax-related matters such as tax audits, changes in our effective tax rate or new tax legislative proposals; whether the final determination of our income tax liability may be materially different from our income tax provisions; the impact of any intellectual property litigation and claims for indemnification; litigation related to U.S. Securities laws; and economic and political conditions in the United States and abroad.  We discuss these risks in greater detail under the heading “Risk Factors” and elsewhere in our Annual Report on Form 10-K for the year ended June 30, 2015, and subsequent filings filed with the U.S. Securities and Exchange Commission (the SEC), which are available at the SEC's website at www.sec.gov.  Copies may also be obtained by contacting the Ubiquiti Networks Investor Relations Department, by email at IR@ubnt.com or by visiting the Investor Relations section of the Ubiquiti Networks website, http://ir.ubnt.com.

[0001415889-16-006679:8k_2_02:52]
-3-

[0001415889-16-006679:8k_2_02:53]
Given these uncertainties, you should not place undue reliance on these forward-looking statements.  Also, forward-looking statements represent our management's beliefs and assumptions only as of the date made.  Except as required by law, Ubiquiti Networks undertakes no obligation to update information contained herein.  You should review our SEC filings carefully and with the understanding that our actual future results may be materially different from what we expect.

[0001415889-16-006679:8k_2_02:54]
Use of Non-GAAP Financial Information

[0001415889-16-006679:8k_2_02:55]
To supplement our condensed consolidated financial results prepared under generally accepted accounting principles, or GAAP, we use non-GAAP measures of net income and earnings per diluted share that are adjusted to exclude certain costs, expenses and gains such as stock based compensation expense, Business e-mail compromise ("BEC") fraud loss/(recovery), implementation of overhead capitalization, reserve against vendor deposits relating to a purchase commitment termination fee and the tax effects of these non-GAAP adjustments.  Reconciliations of the adjustments to GAAP results for the three and twelve months ended June 30, 2016 and 2015 are provided below.  In addition, an explanation of the ways in which management uses non-GAAP financial information to evaluate its business, the substance behind management's decision to use this non-GAAP financial information, material limitations associated with the use of non-GAAP financial information, the manner in which management compensates for those limitations, and the substantive reasons management believes that this non-GAAP financial information provides useful information to investors is included under "About our Non-GAAP Net Income and Adjustments" after the tables below.

[0001415889-16-006679:8k_2_02:56]
| Ubiquiti Networks Inc. Condensed Consolidated Statement of Operations (In thousands, except per share data) (Unaudited) |
|  |  | Three Months Ended June 30, |  | Years Ended June 30, |
|  |  | 2016 |  | 2015 |  | 2016 |  | 2015(1) |
| Revenues |  | $ | 185,676 |  |  | $ | 145,267 |  |  | $ | 666,395 |  |  | $ | 595,947 |  |
| Cost of revenues |  | 95,919 |  |  | 79,129 |  |  | 341,600 |  |  | 333,760 |  |
| Gross profit |  | 89,757 |  |  | 66,138 |  |  | 324,795 |  |  | 262,187 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Research and development |  | 14,955 |  |  | 14,672 |  |  | 57,765 |  |  | 54,565 |  |
| Sales, general and administrative |  | 9,156 |  |  | 5,039 |  |  | 33,269 |  |  | 21,607 |  |
| Business e-mail compromise ("BEC") fraud loss |  | — |  |  | 39,137 |  |  | (8,294 | ) |  | 39,137 |  |
| Total operating expenses |  | 24,111 |  |  | 58,848 |  |  | 82,740 |  |  | 115,309 |  |
| Income from operations |  | 65,646 |  |  | 7,290 |  |  | 242,055 |  |  | 146,878 |  |
| Interest expense and other, net |  | (838 | ) |  | (326 | ) |  | (2,115 | ) |  | (1,130 | ) |
| Income before provision for income taxes |  | 64,808 |  |  | 6,964 |  |  | 239,940 |  |  | 145,748 |  |
| Provision for income taxes |  | 7,102 |  |  | 2,446 |  |  | 26,324 |  |  | 16,085 |  |
| Net income and comprehensive income |  | $ | 57,706 |  |  | $ | 4,518 |  |  | $ | 213,616 |  |  | $ | 129,663 |  |
| Net income per share of common stock: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.70 |  |  | $ | 0.05 |  |  | $ | 2.53 |  |  | $ | 1.47 |  |
| Diluted |  | $ | 0.69 |  |  | $ | 0.05 |  |  | $ | 2.49 |  |  | $ | 1.45 |  |
| Weighted average shares used in computing net income per share of common stock: |  |  |  |  |  |  |  |  |
| Basic |  | 82,494 |  |  | 87,685 |  |  | 84,402 |  |  | 88,008 |  |
| Diluted |  | 83,836 |  |  | 89,110 |  |  | 85,784 |  |  | 89,569 |  |

[0001415889-16-006679:8k_2_02:57]
| (1) | Derived from audited consolidated statements as of and for the year ended June 30, 2015. |

[0001415889-16-006679:8k_2_02:58]
-4-

[0001415889-16-006679:8k_2_02:59]
| Ubiquiti Networks Inc. Reconciliation of GAAP Net Income to Non-GAAP Net Income (In thousands, except per share data) (Unaudited) |
|  |  | Three Months Ended June 30, |  | Years Ended June 30, |
|  |  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Net income |  | $ | 57,706 |  |  | $ | 4,518 |  |  | $ | 213,616 |  |  | $ | 129,663 |  |
| Stock-based compensation: |  |  |  |  |  |  |  |  |
| Cost of revenues |  | 107 |  |  | 161 |  |  | 448 |  |  | 601 |  |
| Research and development |  | 526 |  |  | 355 |  |  | 2,296 |  |  | 2,854 |  |
| Sales, general and administrative |  | 220 |  |  | 297 |  |  | 975 |  |  | 1,537 |  |
| Business e-mail compromise ("BEC") fraud loss |  | — |  |  | 39,137 |  |  | (8,294 | ) |  | 39,137 |  |
| Purchase commitment termination fee |  | — |  |  | — |  |  | — |  |  | 5,500 |  |
| Implementation of overhead capitalization |  | (8 | ) |  | — |  |  | (1,221 | ) |  | — |  |
| Tax effect of non-GAAP adjustments |  | (341 | ) |  | (325 | ) |  | (1,342 | ) |  | (2,656 | ) |
| Non-GAAP net income |  | $ | 58,210 |  |  | $ | 44,143 |  |  | $ | 206,478 |  |  | $ | 176,636 |  |
| Non-GAAP diluted EPS |  | $ | 0.69 |  |  | $ | 0.50 |  |  | $ | 2.41 |  |  | $ | 1.97 |  |
| Weighted-average shares used in non-GAAP diluted EPS |  | 83,836 |  |  | 89,110 |  |  | 85,784 |  |  | 89,569 |  |

[0001415889-16-006679:8k_2_02:60]
-5-

[0001415889-16-006679:8k_2_02:61]
| Ubiquiti Networks Inc. Condensed Consolidated Balance Sheets (In thousands, except share amounts) (Unaudited) |
|  |  | June 30, |
|  |  | 2016 |  | 2015(1) |
| Assets |  |  |  |  |
| Current assets: |  |  |  |  |
| Cash and cash equivalents |  | $ | 551,031 |  |  | $ | 446,401 |  |
| Accounts receivable, net |  | 82,790 |  |  | 66,104 |  |
| Inventories |  | 57,113 |  |  | 37,031 |  |
| Vendor Deposit |  | 30,255 |  |  | 19,998 |  |
| Current deferred tax asset |  | — |  |  | 1,535 |  |
| Prepaid income taxes |  | 299 |  |  | 2,566 |  |
| Prepaid expenses and other current assets |  | 7,153 |  |  | 7,711 |  |
| Total current assets |  | 728,641 |  |  | 581,346 |  |
| Property and equipment, net |  | 12,953 |  |  | 15,602 |  |
| Long-term deferred tax asset |  | 4,195 |  |  | 1,515 |  |
| Other long–term assets |  | 2,262 |  |  | 2,109 |  |
| Total assets |  | $ | 748,051 |  |  | $ | 600,572 |  |
| Liabilities and Stockholders’ Equity |  |  |  |  |
| Current liabilities: |  |  |  |  |
| Accounts payable |  | $ | 51,510 |  |  | $ | 43,856 |  |
| Income taxes payable |  | 1,488 |  |  | 1,108 |  |
| Debt - short-term |  | 11,250 |  |  | 10,000 |  |
| Other current liabilities |  | 26,672 |  |  | 15,170 |  |
| Total current liabilities |  | 90,920 |  |  | 70,134 |  |
| Long-term taxes payable |  | 23,202 |  |  | 19,810 |  |
| Debt - long-term |  | 192,250 |  |  | 87,500 |  |
| Deferred revenues - long-term |  | 1,303 |  |  | 974 |  |
| Total liabilities |  | 307,675 |  |  | 178,418 |  |
| Stockholders’ equity: |  |  |  |  |
| Common stock |  | 82 |  |  | 87 |  |
| Additional paid–in capital |  | — |  |  | — |  |
| Retained earnings |  | 440,294 |  |  | 422,067 |  |
| Total stockholders’ equity |  | 440,376 |  |  | 422,154 |  |
| Total liabilities and stockholders’ equity |  | $ | 748,051 |  |  | $ | 600,572 |  |

[0001415889-16-006679:8k_2_02:62]
| (1) | Derived from audited consolidated statements as of and for the year ended June 30, 2015. |

[0001415889-16-006679:8k_2_02:63]
-6-

[0001415889-16-006679:8k_2_02:64]
| Ubiquiti Networks Inc. Revenues by Product Type (In thousands) (Unaudited) |
|  |  | Three Months Ended June 30, |  | Years Ended June 30, |
|  |  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Service provider technology |  | $ | 109,004 |  |  | $ | 104,788 |  |  | $ | 418,346 |  |  | $ | 418,021 |  |
| Enterprise technology |  | 76,672 |  |  | 40,479 |  |  | 248,049 |  |  | 177,926 |  |
| Total revenues |  | $ | 185,676 |  |  | $ | 145,267 |  |  | $ | 666,395 |  |  | $ | 595,947 |  |

[0001415889-16-006679:8k_2_02:65]
-7-

[0001415889-16-006679:8k_2_02:66]
| Ubiquiti Networks Inc. Revenues by Geographical Area (In thousands) (Unaudited) |
|  |  | Three Months Ended June 30, |  | Years Ended June 30, |
|  |  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| North America |  | $ | 71,087 |  |  | $ | 44,293 |  |  | $ | 239,245 |  |  | $ | 197,693 |  |
| South America |  | 23,925 |  |  | 25,876 |  |  | 85,318 |  |  | 97,118 |  |
| Europe, the Middle East and Africa |  | 69,658 |  |  | 56,909 |  |  | 264,403 |  |  | 234,383 |  |
| Asia Pacific |  | 21,006 |  |  | 18,189 |  |  | 77,429 |  |  | 66,753 |  |
| Total revenues |  | $ | 185,676 |  |  | $ | 145,267 |  |  | $ | 666,395 |  |  | $ | 595,947 |  |

[0001415889-16-006679:8k_2_02:67]
-8-

[0001415889-16-006679:8k_2_02:68]
About our Non-GAAP Net Income and Adjustments

[0001415889-16-006679:8k_2_02:69]
Use of Non-GAAP Financial Information

[0001415889-16-006679:8k_2_02:70]
To supplement our condensed consolidated financial results prepared under generally accepted accounting principles, or GAAP, we use non-GAAP measures of net income and earnings per diluted share that are GAAP net income and GAAP earnings per diluted share adjusted to exclude certain costs, expenses and gains/losses.

[0001415889-16-006679:8k_2_02:71]
We believe that the presentation of non-GAAP net income and non-GAAP earnings per diluted share provides important supplemental information regarding non-cash expenses, significant items that we believe are important to understanding our financial, and business trends relating to our financial condition and results of operations.  Non-GAAP net income and non-GAAP earnings per diluted share are among the primary indicators used by management as a basis for planning and forecasting future periods and by management and our board of directors to determine whether our operating performance has met specified targets and thresholds.  Management uses non-GAAP net income and non-GAAP earnings per diluted share when evaluating operating performance because it believes that the exclusion of the items described below, for which the amounts or timing may vary significantly depending upon the Company's activities and other factors, facilitates comparability of the Company's operating performance from period to period.  We have chosen to provide this information to investors so they can analyze our operating results in the same way that management does and use this information in their assessment of our business and the valuation of our Company.

[0001415889-16-006679:8k_2_02:72]
Use and Economic Substance of Non-GAAP Financial Measures used by Ubiquiti Networks

[0001415889-16-006679:8k_2_02:73]
We compute non-GAAP net income and non-GAAP diluted earnings per share by adjusting GAAP net income and GAAP earnings per diluted share to remove the impact of certain adjustments and the tax effect of those adjustments.  Items excluded from net income are:

[0001415889-16-006679:8k_2_02:74]
| • | Stock-based compensation expense |

[0001415889-16-006679:8k_2_02:75]
| • | Business e-mail compromise ("BEC") fraud loss/(recovery) |

[0001415889-16-006679:8k_2_02:76]
| • | Implementation of overhead capitalization |

[0001415889-16-006679:8k_2_02:77]
| • | Reserve against vendor deposits relating to a purchase commitment termination fee |

[0001415889-16-006679:8k_2_02:78]
| • | Tax effect of non-GAAP adjustments, applying the principles of ASC 740 |

[0001415889-16-006679:8k_2_02:79]
Usefulness of Non-GAAP Financial Information to Investors

[0001415889-16-006679:8k_2_02:80]
These non-GAAP measures are not in accordance with, or an alternative to, GAAP and may be materially different from other non-GAAP measures, including similarly titled non-GAAP measures used by other companies.  The presentation of this additional information should not be considered in isolation from, as a substitute for, or superior to, net income or earnings per diluted share prepared in accordance with GAAP.  Non-GAAP financial measures have limitations in that they do not reflect certain items that may have a material impact upon our reported financial results.

[0001415889-16-006679:8k_2_02:81]
For more information on the non-GAAP adjustments, please see the table captioned “Reconciliation of GAAP Net Income to Non-GAAP Net Income” included in this press release.

[0001415889-16-006679:8k_2_02:82]
-9-
