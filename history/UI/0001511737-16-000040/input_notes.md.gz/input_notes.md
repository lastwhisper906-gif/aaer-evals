# UI notes — 0001511737-16-000040


## ubnt:ScheduleOfRevenueAndAccountsReceivableByMajorCustomersByReportingSegmentsTableTableTextBlock

[0001511737-16-000040:notes:1]
Customers with an accounts receivable balance of 10% or greater of total accounts receivable and customers with net revenues of 10% or greater of total revenues are presented below for the periods indicated:

[0001511737-16-000040:notes:2]
|  | Percentage of Revenues |  | Percentage of Accounts Receivable |
|  | Years Ended June 30, |  | June 30, |
|  | 2016 |  | 2015 |  | 2014 |  | 2016 |  | 2015 |
| Customer A | * |  | * |  | 13 | % |  | * |  |  | 13 | % |
| Customer B | * |  | * |  | * |  |  | 11 | % |  | 12 | % |
| Customer C | * |  | * |  | * |  |  | 13 | % |  | 12 | % |
| Customer D | * |  | * |  | * |  |  | 18 | % |  | * |  |

[0001511737-16-000040:notes:3]
*  denotes less than 10%


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0001511737-16-000040:notes:4]
SUPPLEMENTARY DATA (UNAUDITED)

[0001511737-16-000040:notes:5]
The following table presents the Company’s unaudited consolidated statements of operations data for each of the eight quarters during fiscal 2016 and 2015. In management’s opinion, this information has been presented on the same basis as the audited consolidated financial statements included in a separate section of this report, and all necessary adjustments, consisting only of normal recurring adjustments, have been included in the amounts below to state fairly the unaudited quarterly results when read in conjunction with the audited consolidated financial statements and related notes. The operating results for any quarter should not be relied upon as necessarily indicative of results for any future period.

[0001511737-16-000040:notes:6]
|  |  | Fiscal 2016 |
| In thousands, except per share data |  | FirstQuarter |  | SecondQuarter |  | ThirdQuarter |  | FourthQuarter |
| Net revenue |  | $ | 151,415 |  |  | $ | 161,871 |  |  | $ | 167,433 |  |  | $ | 185,676 |  |
| Gross profit |  | 73,504 |  |  | 79,041 |  |  | 82,493 |  |  | 89,757 |  |
| Income from operations |  | 59,835 |  |  | 56,436 |  |  | 60,138 |  |  | 65,646 |  |
| Net income and comprehensive income |  | 53,759 |  |  | 49,452 |  |  | 52,699 |  |  | 57,706 |  |
| Net income per share of common stock: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.62 |  |  | $ | 0.58 |  |  | $ | 0.63 |  |  | $ | 0.70 |  |
| Diluted |  | $ | 0.61 |  |  | $ | 0.57 |  |  | $ | 0.62 |  |  | $ | 0.69 |  |
|  |  | Fiscal 2015 |
|  |  | FirstQuarter |  | SecondQuarter |  | ThirdQuarter |  | FourthQuarter |
| Net revenue |  | $ | 150,087 |  |  | $ | 153,137 |  |  | $ | 147,456 |  |  | $ | 145,267 |  |
| Gross profit |  | 61,051 |  |  | 69,021 |  |  | 65,977 |  |  | 66,138 |  |
| Income from operations(1) |  | 43,634 |  |  | 50,723 |  |  | 45,231 |  |  | 7,290 |  |
| Net income and comprehensive income |  | 37,743 |  |  | 46,265 |  |  | 41,137 |  |  | 4,518 |  |
| Net income per share of common stock: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.43 |  |  | $ | 0.52 |  |  | $ | 0.47 |  |  | $ | 0.05 |  |
| Diluted |  | $ | 0.42 |  |  | $ | 0.52 |  |  | $ | 0.46 |  |  | $ | 0.05 |  |

[0001511737-16-000040:notes:7]
(1) During the fourth quarter of fiscal 2015, the Company experienced a BEC fraud loss.  For further details, see Note 14.


## us-gaap:BusinessDescriptionAndBasisOfPresentationTextBlock

[0001511737-16-000040:notes:8]
BUSINESS AND BASIS OF PRESENTATION

[0001511737-16-000040:notes:9]
Business— Ubiquiti Networks, Inc. was incorporated in the State of California in 2003 as Pera Networks, Inc.  In 2005 the Company changed its name to Ubiquiti Networks, Inc. and commenced its current operations. In June 2010, the Company was re-incorporated in Delaware.

[0001511737-16-000040:notes:10]
Ubiquiti Networks, Inc. and its wholly owned subsidiaries (collectively, “Ubiquiti” or the “Company”) is a product driven company that leverages innovative proprietary technologies to deliver networking solutions to both startup and established network operators and service providers.

[0001511737-16-000040:notes:11]
The Company operates on a fiscal year ending June 30. In these notes, Ubiquiti refers to the fiscal years ended June 30, 2016, 2015 and 2014 as fiscal 2016, fiscal 2015 and fiscal 2014, respectively.

[0001511737-16-000040:notes:12]
Basis of Presentation— The Company’s consolidated financial statements and accompanying notes are prepared in accordance with accounting principles generally accepted in the United States of America (“GAAP”) and include the accounts of Ubiquiti and its wholly owned subsidiaries. The Company has wholly owned subsidiaries in Lithuania, Hong Kong, China, Latvia, Poland, India and the Cayman Islands. The Company’s Hong Kong subsidiary also operates a branch office in Taiwan. All intercompany transactions and balances have been eliminated.  The Company has reclassified certain amounts reported in the previous period to conform to the current period presentation.


## us-gaap:CashAndCashEquivalentsPolicyTextBlock

[0001511737-16-000040:notes:13]
Cash and Cash Equivalents

[0001511737-16-000040:notes:14]
The Company considers investments purchased with a maturity period of three months or less at the date of purchase to be cash equivalents.  Cash and cash equivalents are stated at cost which approximates fair value. The Company deposits cash and cash equivalents with financial institutions that management believes are of high credit quality. The Company’s cash and cash equivalents consist primarily of cash deposited in U.S. dollar denominated interest-bearing deposit accounts.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001511737-16-000040:notes:15]
COMMITMENTS AND CONTINGENCIES

[0001511737-16-000040:notes:16]
Operating Leases

[0001511737-16-000040:notes:17]
The Company leases its headquarters in San Jose, California and other locations worldwide under non-cancelable operating leases that expire at various dates through 2022.

[0001511737-16-000040:notes:18]
At June 30, 2016, future minimum annual payments under operating leases are as follows (in thousands):

[0001511737-16-000040:notes:19]
| Fiscal Year | 2017 |  | 2018 |  | 2019 |  | 2020 |  | 2021 |  | Thereafter |  | Total |
| Operating leases | $ | 4,883 |  |  | $ | 3,539 |  |  | $ | 2,478 |  |  | $ | 1,729 |  |  | $ | 1,085 |  |  | $ | 375 |  |  | $ | 14,089 |  |

[0001511737-16-000040:notes:20]
Rent expense under operating leases was $5.0 million, $3.6 million and $2.3 million for fiscal 2016, fiscal 2015 and fiscal 2014, respectively.

[0001511737-16-000040:notes:21]
Purchase Obligations

[0001511737-16-000040:notes:22]
The Company primarily subcontracts with other companies to manufacture its products. During the normal course of business, the Company’s contract manufacturers procure components based upon orders placed by the Company. If the Company cancels all or part of the orders, it may still be liable to the contract manufacturers for the cost of the components purchased by them to manufacture the Company’s products. The Company periodically reviews the potential liability and to date no significant accruals have been recorded.  The Company had inventory purchase obligations of $27.4 million as of June 30, 2016.

[0001511737-16-000040:notes:23]
Indemnification Obligations

[0001511737-16-000040:notes:24]
The Company enters into standard indemnification agreements with many of its business partners in the ordinary course of business. These agreements include provisions for indemnifying the business partner against any claim brought by a third party to the extent any such claim alleges that a Company product infringes a patent, copyright or trademark, or violates any other proprietary rights of that third party. The maximum potential amount of future payments the Company could be required to make under these indemnification agreements is not estimable and the Company has not incurred any material costs to defend lawsuits or settle claims related to these indemnification agreements to date.

[0001511737-16-000040:notes:25]
Legal Matters

[0001511737-16-000040:notes:26]
The Company may be involved, from time to time, in a variety of claims, lawsuits, investigations, and proceedings relating to contractual disputes, intellectual property rights, employment matters, regulatory compliance matters and other litigation matters relating to various claims that arise in the normal course of business. The Company determines whether an estimated loss from a contingency should be accrued by assessing whether a loss is deemed probable and can be reasonably estimated. The Company assesses its potential liability by analyzing specific litigation and regulatory matters using available information. The Company develops its views on estimated losses in consultation with inside and outside counsel, which involves a subjective analysis of potential results and outcomes, assuming various combinations of appropriate litigation and settlement strategies. Taking all of the above factors into account, the Company records an amount where it is probable that the Company will incur a loss and where that loss can be reasonably estimated. However, the Company’s estimates may be incorrect and the Company could ultimately incur more or less than the amounts initially recorded.  The Company may also incur significant legal fees, which are expensed as incurred, in defending against these claims.  The Company is not currently aware of any pending or threatened litigation that would have a material adverse effect on the Company's financial statements.

[0001511737-16-000040:notes:27]
Shareholder Class Action Lawsuits

[0001511737-16-000040:notes:28]
Beginning on September 7, 2012, two class action lawsuits were filed in the United States District Court for the Northern District of California against Ubiquiti Networks, Inc., certain of its officers and directors, and the underwriters of its initial public offering, alleging claims under U.S. securities laws. On January 30, 2013, the plaintiffs filed an amended consolidated complaint. On March 26, 2014, the court issued an order granting a motion to dismiss the complaint with leave to amend. Following the plaintiffs’ decision not to file an amended complaint, on April 16, 2014, the court ordered the dismissal of the lawsuit with prejudice, and entered judgment in favor of the Company and the other defendants, and against the plaintiffs. On May 15, 2014, the plaintiffs filed a notice of appeal from the judgment of the court. The appeal is ongoing before the U.S. Court of Appeals for the Ninth Circuit. There can be no assurance that the Company will prevail in the appeal proceeding.  The Company cannot currently estimate the possible loss or range of possible loss, if any, that it may experience in connection with this litigation.

[0001511737-16-000040:notes:29]
Export Compliance Matters

[0001511737-16-000040:notes:30]
In May 2011, the Company filed a self-disclosure statement with the U.S. Commerce Department, Bureau of Industry and Security’s (“BIS”) Office of Export Enforcement (“OEE”) relating to a review conducted by the Company regarding certain export transactions from 2008 through March 2011 in which products may have been later resold into Iran by third parties. In June 2011, the Company also filed a self-disclosure statement with the U.S. Department of the Treasury’s Office of Foreign Asset Control (“OFAC”) regarding these compliance issues. In August 2011, the Company received a warning letter from OEE stating that OEE had not referred the findings of the Company’s review for criminal or administrative prosecution and closed the investigation of the Company without penalty. Based upon its review of the matter, OFAC identified certain apparent violations (“Apparent Violations”) of the Iranian Transactions and Sanctions Regulations by the Company during the period of on or about March 2008 through on or about February 2011. On March 4, 2014, the Company entered into a settlement agreement with OFAC resolving this administrative matter. Pursuant to the terms of the settlement agreement, the Company agreed to make a one-time payment to the U.S. Department of the Treasury in the amount of $504,000 in consideration of OFAC agreeing to release and forever discharge the Company from any and all civil liability in connection with the Apparent Violations. The Company previously accrued a reserve of $1.6 million relating to this matter in fiscal 2010 and, accordingly, reversed the excess of the accrual of $1.1 million as of the effective date of the settlement agreement.


## us-gaap:CommitmentsAndContingenciesPolicyTextBlock

[0001511737-16-000040:notes:31]
Commitments and Contingencies

[0001511737-16-000040:notes:32]
The Company periodically evaluates all pending or threatened contingencies and any commitments, if any, that are reasonably likely to have a material adverse effect on its results of operations, financial position or cash flows. The Company assesses the probability of an adverse outcome and determines if it is remote, reasonably possible or probable. If information available prior to the issuance of the Company’s financial statements indicates that it is probable that an asset had been impaired or a liability had been incurred at the date of the Company’s financial statements, and the amount of the loss, or the range of probable loss can be reasonably estimated, then such loss is accrued and charged to operating expenses. If no accrual is made for a loss contingency because one or both of the conditions pursuant to the accounting guidance are not met, but the probability of an adverse outcome is at least reasonably possible, the Company discloses the nature of the contingency and provides an estimate of the possible loss or range of loss, or states that such an estimate cannot be made.


## us-gaap:CompensationRelatedCostsPolicyTextBlock

[0001511737-16-000040:notes:33]
Stock-based Compensation

[0001511737-16-000040:notes:34]
The Company records stock-based awards at fair value as of the grant date and recognize expense, net of forfeitures, ratably on a straight-line basis over the requisite service period, which is generally the vesting term of the awards. The Company estimates the fair value of stock option awards on the grant date using the Black-Scholes option pricing model. The determination of the fair value of a stock-based award on the date of grant using the Black-Scholes option-pricing model is affected by the Company's stock price on the date of grant as well as assumptions regarding a number of complex and subjective variables. These variables include the Company's expected stock price volatility over the expected term of the award, actual and projected employee stock option exercise behaviors, the risk-free interest rate for the expected term of the award and expected dividends. Restricted stock units are valued based on the fair value of the Company's common stock on the date of grant.  Since the Company's initial public offering on October 14, 2011, the fair value of our common stock is determined using the closing market price of the Company's common stock as of the date of grant.


## us-gaap:DebtDisclosureTextBlock

[0001511737-16-000040:notes:35]
DEBT

[0001511737-16-000040:notes:36]
On May 5, 2014, the Company and certain of its subsidiaries entered into a credit agreement (the “Original Credit Agreement”) with Wells Fargo Bank, National Association (“Wells Fargo”), the financial institutions named as lenders therein, and Wells Fargo as administrative agent for the lenders, that provided for a $150.0 million senior secured revolving credit facility, with an option to request an increase in the amount of the credit facility by up to an additional $50.0 million (any such increase to be in each lender’s sole discretion).

[0001511737-16-000040:notes:37]
On March 3, 2015, the Company and Ubiquiti International Holding Company Limited (the “Cayman Borrower”) amended and restated the Original Credit Agreement (the "Amended Credit Agreement") with Wells Fargo, the other financial institutions named as lenders therein, and Wells Fargo as administrative agent for the lenders.  The Amended Credit Agreement provides for a $200.0 million senior secured revolving credit facility and a $100.0 million senior secured term loan facility (collectively, the "Facilities"), with an option to request increases in the amounts of such credit facilities by up to an additional $50.0 million in the aggregate (any such increase to be in each lender's sole discretion), and matures on March 3, 2020.  The term loan facility was fully drawn at closing, $72.3 million of which was used to repay the outstanding balance under the Original Credit Agreement.  During fiscal 2016, the Company drew $130 million against the revolving credit facility. As of June 30, 2016, $87.5 million was outstanding on the term loan and $116 million on the revolver, leaving $84 million available on the revolver. As of June 30, 2016, the interest rate on the term loan was 2.13%. The table below shows the respective interest rates as of June 30, 2016 in addition to interest rate reset dates and rates (as available) for each revolver draw.

[0001511737-16-000040:notes:38]
|  |  | Interest Rate as of |  |  |  |  |
| Debt Payment Obligations |  | June 30, 2016 |  | Rate Reset Date |  | Reset Rate |
| $15 Million Revolver |  | 2.13% |  | July 8, 2016 |  | 2.42% |
| $18 Million Revolver |  | 2.13% |  | July 18, 2016 |  | 2.48% |
| $16 Million Revolver |  | 2.13% |  | August 12, 2016 |  | 2.71% |
| $19 Million Revolver |  | 2.13% |  | July 1, 2016 |  | 2.41% |
| $48 Million Revolver |  | 2.48% |  | November 30, 2016 |  | * |

[0001511737-16-000040:notes:39]
* - Reset rate not available as of filing date.

[0001511737-16-000040:notes:40]
The revolving credit facility includes a sub-limit of $10.0 million for letters of credit and a sub-limit of $25.0 million for swingline loans. The Facilities replaced the Company's $150.0 million senior secured revolving credit facility under the Original Credit Agreement. The Facilities are available for working capital and general corporate purposes that comply with the terms of the Amended Credit Agreement. Under the Amended Credit Agreement, revolving loans and swingline loans may be borrowed, repaid and reborrowed until March 3, 2020, at which time all amounts borrowed must be repaid. The term loan is payable in quarterly installments of 2.50% of the original principal amount of the term loan until March 31, 2017, thereafter increasing to 3.75% of the original principal amount of the term loan, in each case plus accrued and unpaid interest. Revolving, swingline and term loans may be prepaid at any time without penalty. Revolving and term loans bear interest, at the Company's option, at either (i) a floating rate per annum equal to the base rate plus a margin of between 0.50% and 1.25%, depending on the Company's leverage ratio as of the most recently ended fiscal quarter or (ii) a floating per annum rate equal to the applicable LIBOR rate for a specified period, plus a margin of between 1.50% and 2.25%, depending on the Company's leverage ratio as of the most recently ended fiscal quarter. Swingline loans bear interest at a floating rate per annum equal to the base rate plus a margin of between 0.50% and 1.25%, depending on the Company's leverage ratio as of the most recently ended fiscal quarter. Base rate is defined as the greatest of (A) Wells Fargo's prime rate, (B) the federal funds rate plus 0.50% or (C) the applicable LIBOR rate for a period of one month plus 1.00%. A default interest rate shall apply on all obligations during certain events of default under the Amended Credit Agreement at a rate per annum equal to 2.00% above the applicable interest rate. The Company will pay to each lender a facility fee on a quarterly basis based on the unused amount of each lender's commitment to make revolving loans, of between 0.20% and 0.35%, depending on the Company's leverage ratio as of the most recently ended fiscal quarter. The Company will also pay to the applicable lenders on a quarterly basis certain fees based on the daily amount available to be drawn under each outstanding letter of credit, including aggregate letter of credit commissions of between 1.50% and 2.25%, depending on the Company's leverage ratio as of the most recently ended fiscal quarter, and issuance fees of 0.125% per annum. The Company is also obligated to pay Wells Fargo, as agent, fees customary for a credit facility of this size and type.

[0001511737-16-000040:notes:41]
The Amended Credit Agreement requires the Company to maintain during the term of the Facilities (i) a maximum leverage ratio of 2.50 to 1.00 and (ii) minimum liquidity of $225.0 million, increasing to $250.0 million in the event of an incremental increase in the size of the Facilities, which can be satisfied with unrestricted cash and cash equivalents and up to $50.0 million of availability under the revolving credit facility. In addition, the Amended Credit Agreement contains customary affirmative and negative covenants, including covenants that limit or restrict the ability of the Company and its subsidiaries to, among other things, grant liens or enter into agreements restricting their ability to grant liens on property, enter into mergers, dispose of assets, change their accounting or reporting policies, change their business and incur indebtedness, in each case subject to customary exceptions for a credit facility of this size and type. The Amended Credit Agreement includes customary events of default that include, among other things, non-payment of principal, interest or fees, inaccuracy of representations and warranties, violation of covenants, cross default to certain other indebtedness, bankruptcy and insolvency events, material judgments, change of control and certain ERISA events. The occurrence of an event of default could result in the acceleration of the obligations under the Amended Credit Agreement.

[0001511737-16-000040:notes:42]
The obligations of the Company and certain domestic subsidiaries, if any, under the Amended Credit Agreement are required to be guaranteed by such domestic subsidiaries (the "Domestic Guarantors") and are collateralized by substantially all assets (excluding intellectual property) of the Company and the Domestic Guarantors. The obligations of the Cayman Borrower and certain foreign subsidiaries under the Amended Credit Agreement are required to be guaranteed by certain domestic and material foreign subsidiaries (the "Guarantors") and are collateralized by substantially all assets (excluding intellectual property) of the Company and the Guarantors.

[0001511737-16-000040:notes:43]
During fiscal 2016, the Company made aggregate payments of $11.9 million against the term loan facility balance under the Amended Credit Agreement, of which $10.0 million was for repayments of principal and $1.9 million was for payments of interest. During fiscal 2016, the Company made aggregate payments of $14.5 million against the revolving loan facility under the Amended Credit Agreement, of which $14.0 million was for repayments of principal and $0.5 million was for payments of interest. As of June 30, 2016, the Company has classified $11.3 million and $192.3 million of short term and long-term debt, respectively, on its consolidated balance sheet related to the Amended Credit Agreement.

[0001511737-16-000040:notes:44]
On September 2, 2015, the Company accessed a letter of credit under its revolving credit facility in the amount of $237 thousand for the benefit of the landlord pursuant to a new lease of office space. The landlord can draw against the letter of credit in the event of default by the Company. The letter of credit expires on September 2, 2016, subject to automatic renewal

[0001511737-16-000040:notes:45]
for additional one-year periods.

[0001511737-16-000040:notes:46]
The following table summarizes our debt payment obligations as of June 30, 2016 (in thousands):

[0001511737-16-000040:notes:47]
| Fiscal Year | 2017 |  | 2018 |  | 2019 |  | 2020 |  | Thereafter |  | Total |
| Debt payment obligations | $ | 11,250 |  |  | $ | 15,000 |  |  | $ | 15,000 |  |  | $ | 162,250 |  |  | $ | — |  |  | $ | 203,500 |  |
| Interest payments on debt payment obligations | 4,802 |  |  | 4,564 |  |  | 4,245 |  |  | 2,701 |  |  | — |  |  | 16,312 |  |
| Total | $ | 16,052 |  |  | $ | 19,564 |  |  | $ | 19,245 |  |  | $ | 164,951 |  |  | $ | — |  |  | $ | 219,812 |  |


## us-gaap:DeferredCostsCapitalizedPrepaidAndOtherAssetsDisclosureTextBlock

[0001511737-16-000040:notes:48]
Prepaid expenses and other current assets consisted of the following (in thousands):

[0001511737-16-000040:notes:49]
|  | June 30, |
|  | 2016 |  | 2015 |
| BEC Recovery receivable | $ | — |  |  | $ | 1,376 |  |
| Other current assets | 7,153 |  |  | 6,335 |  |
|  | $ | 7,153 |  |  | $ | 7,711 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001511737-16-000040:notes:50]
STOCK BASED COMPENSATION

[0001511737-16-000040:notes:51]
Stock-Based Compensation Plans

[0001511737-16-000040:notes:52]
2010 Equity Incentive Plan

[0001511737-16-000040:notes:53]
In March 2010, the Company’s Board of Directors and stockholders approved the 2010 Equity Incentive Plan (the “2010 Plan”). The 2010 Plan replaced the 2005 Equity Incentive Plan (the “2005 Plan”), and no further awards will be granted pursuant to the 2005 Plan. Under the terms of the 2010 Plan, nonstatutory stock options, stock appreciation rights, restricted stock, and restricted stock units (“RSUs”) may be granted to employees or non-employee service providers. Incentive stock options may be granted only to employees.

[0001511737-16-000040:notes:54]
The maximum aggregate number of shares that may be awarded under the 2010 Plan as of June 30, 2016 was 8,000,000 shares, plus any shares subject to stock options or similar awards granted under the 2005 Plan that expire or otherwise terminate without having been exercised in full and shares issued pursuant to awards granted under the 2005 Plan that are forfeited to (but not repurchased by) the Company.

[0001511737-16-000040:notes:55]
The 2010 Plan is administered by the Company's Board of Directors or a committee of the Company’s Board of Directors. Subject to the terms and conditions of the 2010 Plan, the administrator has the authority to select the persons to whom awards are to be made, to determine the number of shares to be subject to awards and the terms and conditions of awards, and to make all other determinations and to take all other actions necessary or advisable for the administration of the 2010 Plan. The administrator is also authorized to adopt, amend or rescind rules relating to administration of the 2010 Plan. Options and RSUs generally vest over a four year period from the date of grant and generally expire five to ten years from the date of grant. The terms of the 2010 Plan provide that an option price shall not be less than 100% of fair market value on the date of grant.

[0001511737-16-000040:notes:56]
2005 Equity Incentive Plan

[0001511737-16-000040:notes:57]
With the adoption of the 2010 Plan, no additional awards may be granted under the 2005 Plan. In February 2005, the Company’s Board of Directors and the stockholders approved the 2005 Plan, which was amended and restated in March 2006. The 2005 Plan provided for the issuance of stock options, restricted stock and stock bonuses to employees, consultants, advisors, directors and officers of the Company. The terms of the options granted under the 2005 Plan were determined at the time of grant. The Company made use of different vesting schedules through fiscal 2009, but subsequent new grants generally vested as to 25% on the first anniversary of the date of grant and monthly thereafter over the next three years and generally have a term of 10 years from the date of grant.

[0001511737-16-000040:notes:58]
As of June 30, 2016, the Company had 10,022,225 authorized shares available for future issuance under all of its stock incentive plans.

[0001511737-16-000040:notes:59]
The following table shows total stock-based compensation expense included in the Consolidated Statements of Operations and Comprehensive Income for fiscal 2016, 2015 and 2014 (in thousands):

[0001511737-16-000040:notes:60]
|  | Years Ended June 30, |
|  | 2016 |  | 2015 |  | 2014 |
| Cost of sales | $ | 448 |  |  | $ | 601 |  |  | $ | 590 |  |
| Research and development | 2,296 |  |  | 2,854 |  |  | 2,423 |  |
| Sales, general and administrative | 975 |  |  | 1,537 |  |  | 1,893 |  |
|  | $ | 3,719 |  |  | $ | 4,992 |  |  | $ | 4,906 |  |

[0001511737-16-000040:notes:61]
Stock Options

[0001511737-16-000040:notes:62]
The following is a summary of option activity for the Company’s stock incentive plans for fiscal 2016, 2015 and 2014:

[0001511737-16-000040:notes:63]
|  | Common Stock Options Outstanding |
|  | Numberof Shares |  | WeightedAverageExercisePrice |  | WeightedAverageRemainingContractualLife (Years) |  | AggregateIntrinsicValue |
|  |  |  |  |  |  |  | (In thousands) |
| Balance, June 30, 2013 | 3,614,262 |  |  | $ | 3.07 |  |  | 6.17 |  | $ | 52,330 |  |
| Exercised | (849,635 | ) |  | $ | 2.46 |  |  |  |  |  |
| Forfeitures and cancellations | (107,485 | ) |  | $ | 10.55 |  |  |  |  |  |
| Balance, June 30, 2014 | 2,657,142 |  |  | $ | 2.96 |  |  | 5.11 |  | $ | 112,215 |  |
| Exercised | (299,034 | ) |  | $ | 5.64 |  |  |  |  |  |
| Forfeitures and cancellations | (56,964 | ) |  | $ | 12.14 |  |  |  |  |  |
| Balance, June 30, 2015 | 2,301,144 |  |  | $ | 2.38 |  |  | 3.82 |  | $ | 67,969 |  |
| Exercised | (171,263 | ) |  | $ | 6.46 |  |  |  |  |  |
| Forfeitures and cancellations | (4,574 | ) |  | $ | 13.82 |  |  |  |  |  |
| Balance, June 30, 2016 | 2,125,307 |  |  | $ | 2.03 |  |  | 2.65 |  | $ | 77,850 |  |
| Vested and expected to vest as of June 30, 2016 | 2,124,757 |  |  | $ | 2.03 |  |  | 2.65 |  | $ | 77,836 |  |
| Vested and exercisable as of June 30, 2016 | 2,088,860 |  |  | $ | 1.87 |  |  | 2.59 |  | $ | 76,858 |  |

[0001511737-16-000040:notes:64]
Additional information regarding options outstanding as of June 30, 2016 is as follows :

[0001511737-16-000040:notes:65]
|  |  | Options Outstanding |  |  |  | Options Exercisable |
| Range of Exercise Prices |  | Number ofOptions |  | WeightedAverageRemainingContractualLife (Years) |  | WeightedAverageExercisePrice |  | Number ofOptions |  | WeightedAverageExercisePrice |
| $0.01 - $1.91 |  | 1,637,160 |  |  | 1.76 |  | $ | 0.05 |  |  | 1,637,160 |  |  | $ | 0.05 |  |
| $1.92 - $11.74 |  | 424,998 |  |  | 5.53 |  | $ | 7.90 |  |  | 397,911 |  |  | $ | 7.70 |  |
| $11.75 - $18.48 |  | 59,190 |  |  | 6.31 |  | $ | 13.55 |  |  | 49,830 |  |  | $ | 13.59 |  |
| $18.49 - $19.98 |  | 3,209 |  |  | 5.46 |  | $ | 18.56 |  |  | 3,209 |  |  | $ | 18.56 |  |
| $19.99 - $26.28 |  | 750 |  |  | 5.50 |  | $ | 22.09 |  |  | 750 |  |  | $ | 22.09 |  |
|  |  | 2,125,307 |  |  |  |  |  |  |  | 2,088,860 |  |  |  |  |

[0001511737-16-000040:notes:66]
During fiscal 2016, 2015 and 2014, the aggregate intrinsic value of options exercised under the Company’s stock incentive plans was $4.9 million, $9.2 million, and $30.5 million, respectively, as determined as of the date of option exercise.

[0001511737-16-000040:notes:67]
As of June 30, 2016, the Company had unrecognized compensation cost of $290,000 related to stock options which the Company expects to recognize over a weighted-average period of 0.6 years. Future option grants will increase the amount of compensation expense to be recorded in these periods.

[0001511737-16-000040:notes:68]
The Company estimates the fair value of employee stock options using the Black-Scholes option pricing model. The fair value of employee stock options is being amortized on a straight-line basis over the requisite service period of the awards. The Company did not grant any stock options during fiscal 2016, fiscal 2015, or fiscal 2014.

[0001511737-16-000040:notes:69]
Forfeiture rate. The Company estimates its forfeiture rate based on an analysis of its actual forfeitures and will continue to evaluate the adequacy of the forfeiture rate based on actual forfeiture experience, analysis of employee turnover behavior and other factors. The impact from a forfeiture rate adjustment will be recognized in full in the period of adjustment, and if the actual number of future forfeitures differs from that estimated, the Company may be required to record adjustments to stock-based compensation expense in future periods.

[0001511737-16-000040:notes:70]
Cash received from stock option exercises during fiscal 2016, 2015 and 2014 was $1.1 million, $1.7 million and $2.1 million, respectively.

[0001511737-16-000040:notes:71]
Restricted Stock Units (“RSUs”)

[0001511737-16-000040:notes:72]
The following table summarizes the activity of the RSUs made by the Company:

[0001511737-16-000040:notes:73]
|  | Number of Shares |  | Weighted Average Grant Date Fair Value |
| Non-vested RSUs, June 30, 2013 | 744,906 |  |  | $ | 14.74 |  |
| RSUs granted | 209,032 |  |  | $ | 37.87 |  |
| RSUs vested | (170,197 | ) |  | $ | 15.59 |  |
| RSUs canceled | (234,039 | ) |  | $ | 16.18 |  |
| Non-vested RSUs, June 30, 2014 | 549,702 |  |  | $ | 22.65 |  |
| RSUs granted | 182,865 |  |  | $ | 32.47 |  |
| RSUs vested | (182,507 | ) |  | $ | 21.27 |  |
| RSUs canceled | (149,425 | ) |  | $ | 24.84 |  |
| Non-vested RSUs, June 30, 2015 | 400,635 |  |  | $ | 26.95 |  |
| RSUs granted | 132,746 |  |  | $ | 31.38 |  |
| RSUs vested | (141,159 | ) |  | $ | 23.54 |  |
| RSUs canceled | (120,251 | ) |  | $ | 31.84 |  |
| Non-vested RSUs, June 30, 2016 | 271,971 |  |  | $ | 28.72 |  |

[0001511737-16-000040:notes:74]
The intrinsic value of RSUs vested in fiscal 2016, 2015 and 2014 was $4.6 million, $6.4 million and $6.1 million, respectively.  The total intrinsic value of all outstanding RSUs was $10.5 million as of June 30, 2016.

[0001511737-16-000040:notes:75]
As of June 30, 2016, there was unrecognized compensation costs related to RSUs of $8.5 million which the Company expects to recognize over a weighted average period of 2.9 years.


## us-gaap:EarningsPerSharePolicyTextBlock

[0001511737-16-000040:notes:76]
Earnings Per Share

[0001511737-16-000040:notes:77]
The Company applies the two-class method for calculating and presenting earnings per share (“EPS”). Under the two-class method, net income is allocated between shares of common stock and other participating securities based on their participating rights. Participating securities are defined as securities that participate in dividends with common stock according to a pre-determined formula or a contractual obligation to share in the income of the entity. Basic EPS is computed by dividing net income available to common stockholders by the weighted average number of shares of common stock outstanding during the period. Diluted EPS is computed by dividing the amount of net income available to common stockholders outstanding plus income allocable to participating securities, to the extent they are dilutive, by the weighted average number of shares of common stock and potential dilutive shares outstanding during the period if the effect is dilutive. The Company’s potentially dilutive common securities include outstanding stock options and restricted stock units.


## us-gaap:EarningsPerShareTextBlock

[0001511737-16-000040:notes:78]
EARNINGS PER SHARE

[0001511737-16-000040:notes:79]
The following table sets forth the computation of basic and diluted earnings per share for the periods indicated (in thousands, except per share data):

[0001511737-16-000040:notes:80]
|  | Years Ended June 30, |
|  | 2016 |  | 2015 |  | 2014 |
| Numerator: |  |  |  |  |  |
| Net income and comprehensive income | $ | 213,616 |  |  | $ | 129,663 |  |  | $ | 176,937 |  |
| Denominator: |  |  |  |
| Weighted-average shares used in computing basic net income per share | 84,402 |  |  | 88,008 |  |  | 87,772 |  |
| Add—dilutive potential common shares: |  |  |  |  |  |
| Stock options | 1,275 |  |  | 1,392 |  |  | 1,696 |  |
| Restricted stock units | 107 |  |  | 169 |  |  | 247 |  |
| Weighted-average shares used in computing diluted net income per share | 85,784 |  |  | 89,569 |  |  | 89,715 |  |
| Net income per share of common stock: |  |  |  |
| Basic | $ | 2.53 |  |  | $ | 1.47 |  |  | $ | 2.02 |  |
| Diluted | $ | 2.49 |  |  | $ | 1.45 |  |  | $ | 1.97 |  |

[0001511737-16-000040:notes:81]
The Company excludes potentially dilutive securities from its diluted net income per share calculation when their effect would be antidilutive to net income per share amounts.  The following table summarizes the total potential shares of common stock that were excluded from the diluted per share calculation, because to include them would have been anti-dilutive for the period (in thousands):

[0001511737-16-000040:notes:82]
|  | Years Ended June 30, |
|  | 2016 |  | 2015 |  | 2014 |
| Restricted stock units | 8 |  |  | 2 |  |  | 36 |  |


## us-gaap:FairValueAssetsAndLiabilitiesMeasuredOnRecurringAndNonrecurringBasisTableTextBlock

[0001511737-16-000040:notes:83]
As of June 30, 2016 and 2015, the fair value hierarchy for the Company’s financial liabilities was as follows (in thousands):

[0001511737-16-000040:notes:84]
|  | June 30, 2016 |  | June 30, 2015 |
|  | FairValue |  | Level 1 |  | Level 2 |  | Level 3 |  | FairValue |  | Level 1 |  | Level 2 |  | Level 3 |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Debt(1) | $ | 203,500 |  |  | $ | — |  |  | $ | 203,500 |  |  | $ | — |  |  | $ | 97,500 |  |  | $ | — |  |  | $ | 97,500 |  |  | $ | — |  |

[0001511737-16-000040:notes:85]
(1) Debt is carried at historical cost on the Company's consolidated balance sheet.


## us-gaap:FairValueDisclosuresTextBlock

[0001511737-16-000040:notes:86]
FAIR VALUE OF FINANCIAL INSTRUMENTS

[0001511737-16-000040:notes:87]
For certain of the Company’s financial instruments, including cash, accounts receivable, accounts payable, and other current liabilities, the carrying amounts approximate fair value due to their short maturities, and are therefore excluded from the fair value tables below.   Additionally, as of June 30, 2016, we held $524.3 million of our $551.0 million of cash and cash equivalents in accounts of our subsidiaries outside of the United States, and we would incur significant tax liabilities if we were to repatriate those amounts.

[0001511737-16-000040:notes:88]
As of June 30, 2016 and 2015, the Company had outstanding debt associated with its Amended Credit Agreement with Wells Fargo Bank (See Note 7). The fair value of the Company’s debt was estimated based on the current rates offered to the Company for debt with similar terms and remaining maturities and was classified as Level 2 measurement.


## us-gaap:ForeignCurrencyTransactionsAndTranslationsPolicyTextBlock

[0001511737-16-000040:notes:89]
Foreign Currency Remeasurement

[0001511737-16-000040:notes:90]
The functional currency of the Company and its subsidiaries is the U.S. dollar. For foreign operations, local currency denominated monetary assets and liabilities are remeasured at the period end exchange rates, and revenues, costs and expenses are remeasured at the average exchange rates during the fiscal year. Foreign exchange gains and losses have been immaterial to the Company’s results of operations to date.


## us-gaap:ImpairmentOrDisposalOfLongLivedAssetsPolicyTextBlock

[0001511737-16-000040:notes:91]
Long Lived Assets

[0001511737-16-000040:notes:92]
The Company evaluates its long lived assets including property and equipment for impairment whenever events or changes in circumstances indicate that the carrying value of these assets may not be recoverable. An impairment loss is recognized when the net book value of such assets exceeds the estimated future undiscounted cash flows attributable to the assets or asset group. If impairment is indicated, the asset is written down to its estimated fair value.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001511737-16-000040:notes:93]
INCOME TAXES

[0001511737-16-000040:notes:94]
For financial reporting purposes, the components of income before provision for income taxes were as follows (in thousands):

[0001511737-16-000040:notes:95]
|  |  | Years Ended June 30, |
|  |  | 2016 |  | 2015 |  | 2014 |
| Domestic |  | $ | 60,073 |  |  | $ | 44,743 |  |  | $ | 44,551 |  |
| Foreign |  | 179,867 |  |  | 101,005 |  |  | 150,060 |  |
|  |  | $ | 239,940 |  |  | $ | 145,748 |  |  | $ | 194,611 |  |

[0001511737-16-000040:notes:96]
The components of the Company’s provision for income taxes consisted of the following (in thousands):

[0001511737-16-000040:notes:97]
|  |  | Years Ended June 30, |
|  |  | 2016 |  | 2015 |  | 2014 |
| Current |  |  |  |  |  |  |
| Foreign |  | $ | 1,983 |  |  | $ | 909 |  |  | $ | 2,451 |  |
| Federal |  | 25,635 |  |  | 15,786 |  |  | 16,516 |  |
| State |  | (149 | ) |  | 299 |  |  | 109 |  |
| Current tax expense |  | 27,469 |  |  | 16,994 |  |  | 19,076 |  |
| Deferred |  |  |  |  |  |  |
| Foreign |  | — |  |  | — |  |  | — |  |
| Federal |  | (1,116 | ) |  | (856 | ) |  | (1,507 | ) |
| State |  | (29 | ) |  | (53 | ) |  | 105 |  |
| Deferred tax expense |  | (1,145 | ) |  | (909 | ) |  | (1,402 | ) |
| Provision for income taxes |  | $ | 26,324 |  |  | $ | 16,085 |  |  | $ | 17,674 |  |

[0001511737-16-000040:notes:98]
Significant components of the Company’s deferred tax assets and liabilities consisted of the following (in thousands):

[0001511737-16-000040:notes:99]
|  |  | June 30, |
|  |  | 2016 |  | 2015 |
| Deferred tax assets |  |  |  |  |
| Reserves and Allowances |  | $ | 1,539 |  |  | $ | 836 |  |
| Stock-based compensation |  | 998 |  |  | 1,168 |  |
| Accrued expenses |  | 363 |  |  | 446 |  |
| Research and development credits |  | 146 |  |  | 595 |  |
| State tax |  | 925 |  |  | 824 |  |
| Other |  | 482 |  |  | 399 |  |
| Total deferred tax assets |  | 4,453 |  |  | 4,268 |  |
| Deferred tax liabilities |  |  |  |  |
| Basis difference for fixed assets |  | (112 | ) |  | (623 | ) |
| Total deferred tax liabilities |  | (112 | ) |  | (623 | ) |
| Valuation allowance |  | (146 | ) |  | (595 | ) |
| Net deferred tax assets |  | $ | 4,195 |  |  | $ | 3,050 |  |

[0001511737-16-000040:notes:100]
As of June 30, 2016, the Company had California research tax credit carry-forwards, net of ASC 740-10 unrecognized tax benefits, of approximately $693 thousand. The California research credits can be carried forward indefinitely.

[0001511737-16-000040:notes:101]
Management assesses the available positive and negative evidence to estimate if sufficient future taxable income will be generated to use the existing deferred tax assets. In the fourth quarter of fiscal 2016, the Company determined that it is more likely than not that our deferred tax asset for California research credits will not be realized as for the foreseeable future the Company is expecting to generate credits in excess of its ability to use such attributes. As a result, the Company has provided a valuation allowance of $146 thousand for the amount of California deferred tax assets that may not be realized as of  June 30, 2016.

[0001511737-16-000040:notes:102]
As a result of certain realization requirements of ASC 718, Compensation - Stock Compensation, the table of deferred tax assets and liabilities shown above does not include certain deferred tax assets as of June 30, 2016, that arose directly from (or the use of which was postponed by) tax deductions related to equity compensation that are greater than the compensation recognized for financial reporting. Stockholders equity will be increased by approximately $468 thousand if and when such deferred tax assets are ultimately realized.

[0001511737-16-000040:notes:103]
The effective tax rate differs from the applicable U.S. statutory federal income tax rate as follows:

[0001511737-16-000040:notes:104]
|  |  | Years Ended June 30, |
|  |  | 2016 |  | 2015 |  | 2014 |
| Statutory rate |  | 35.0 | % |  | 35.0 | % |  | 35.0 | % |
| Stock-based compensation |  | 0.3 |  |  | 0.6 |  |  | 0.4 |  |
| State tax expense |  | (0.1 | ) |  | 0.1 |  |  | — |  |
| Tax rate differential, foreign income |  | (24.4 | ) |  | (23.2 | ) |  | (25.3 | ) |
| Federal research and development credits |  | (0.6 | ) |  | (1.1 | ) |  | (0.3 | ) |
| Other permanent items |  | 0.8 |  |  | (0.4 | ) |  | (0.7 | ) |
| Effective tax rate |  | 11.0 | % |  | 11.0 | % |  | 9.1 | % |

[0001511737-16-000040:notes:105]
The Company’s effective tax rate remained flat at 11.0% in both fiscal 2016 and fiscal 2015, because the Company's ratio of domestic and foreign income remained relatively constant for fiscal 2016 and fiscal 2015. Overall, the rate benefit is due to income in foreign jurisdictions that have lower tax rates than the U.S.

[0001511737-16-000040:notes:106]
It is the intention of the Company to indefinitely reinvest the earnings of its foreign subsidiaries in non-U.S. operations.  As of June 30, 2016, the Company has not made a provision for U.S. or additional foreign withholding taxes on approximately $616.2 million of the excess of the amount for the financial reporting over the tax basis of its investments in foreign subsidiaries that is indefinitely reinvested outside of U.S. This amount would become subject to U.S. tax upon repatriation or other circumstances. It is not practicable to estimate the amount of deferred tax liability related to investments in these foreign subsidiaries.

[0001511737-16-000040:notes:107]
While management believes that the Company has adequately provided for all tax positions, amounts asserted by tax authorities could be greater or less than the recorded position. Accordingly, the Company's provisions on federal, state and foreign tax-related matters to be recorded in the future may change as revised estimates are made or the underlying matters are settled or otherwise resolved.

[0001511737-16-000040:notes:108]
A reconciliation of the beginning and ending balances of the unrecognized tax benefits during the years ended June 30, 2016 2015 and 2014 consists of the following (in thousands):

[0001511737-16-000040:notes:109]
|  |  | Years Ended June 30, |
|  |  | 2016 |  | 2015 |  | 2014 |
|  |  | (In thousands) |
| Unrecognized benefit—beginning of year |  | $ | 19,590 |  |  | $ | 14,914 |  |  | $ | 11,455 |  |
| Gross increases—current year tax positions |  | 3,879 |  |  | 4,960 |  |  | 3,871 |  |
| Gross decreases—prior year tax positions |  | — |  |  | — |  |  | (213 | ) |
| Gross decreases - prior year tax positions due to statute lapse |  | (618 | ) |  | (284 | ) |  | (199 | ) |
| Unrecognized benefit—end of year |  | $ | 22,851 |  |  | $ | 19,590 |  |  | $ | 14,914 |  |

[0001511737-16-000040:notes:110]
Included in the gross unrecognized tax benefits balance as of June 30, 2016 are $21.5 million of tax positions which would affect income tax expense if recognized.  The Company recognizes interest and penalties related to unrecognized tax benefits within the income tax expense line in the accompanying Consolidated Statement of Operations and Comprehensive Income.  Accrued interest and penalties are included within the related tax liability line in the Consolidated Balance Sheet.  As of June 30, 2016, the Company had $1.7 million accrued interest related to uncertain tax matters. The Company believes that it is reasonably possible that a decrease of up to $1.7 million in unrecognized tax benefits may occur due to settlements with tax authorities or statute lapses.The Company files income tax returns in the United States, various states and certain foreign jurisdictions. Tax years 2013 through 2016 are subject to examination by the U.S. federal tax authorities. Tax years 2012 through 2016 are subject to examination by the state tax authorities. Tax years 2010 through 2016 are generally subject to examination by certain foreign tax authorities.  There are no income tax examinations currently in process.

[0001511737-16-000040:notes:111]
On July 27, 2015, in Altera Corp. vs. Commissioner, the U.S. Tax Court issued an opinion related to the treatment of stock-based compensation expense in an intercompany cost-sharing arrangement. On February 19, 2016, the Internal Revenue Service filed a notice of appeal and has not withdrawn the requirement to include stock-based compensation from its regulations; and on June 27, 2016, the Internal Revenue Service appealed the court's decision to the Ninth Circuit Court of Appeals. We have reviewed this case and its potential impact on Ubiquiti and concluded that no adjustment to the consolidated financial statements is appropriate at this time. We will continue to monitor ongoing developments and potential impacts to our consolidated financial statements.

[0001511737-16-000040:notes:112]
As discussed in Note 2, in November 2015, the FASB issued ASU No. 2015-17, Balance Sheet Classification of Deferred Taxes. We early adopted ASU 2015-17 during the fourth quarter of fiscal 2016 on a prospective basis; no prior reporting period was retrospectively adjusted.


## us-gaap:IncomeTaxPolicyTextBlock

[0001511737-16-000040:notes:113]
Income Taxes

[0001511737-16-000040:notes:114]
The Company accounts for income taxes in accordance with accounting guidance which requires recognition of deferred tax assets and liabilities for the expected future tax consequences of events that have been included in its financial statements or tax returns. Deferred tax assets and liabilities are determined based on the temporary difference between the financial statement carrying amounts of existing assets and liabilities and their respective tax bases. Deferred tax assets and liabilities are measured using enacted tax rates expected to apply to taxable income in the years in which those temporary differences are expected to be recovered or settled. The Company establishes valuation allowances when necessary to reduce deferred tax assets to the amount it expects to realize. The assessment of whether or not a valuation allowance is required often requires significant judgment including current operating results, the forecast of future taxable income and ongoing prudent and feasible tax planning initiatives. In addition, the Company’s calculation of its tax liabilities involves dealing with uncertainties in the application of complex tax regulations. The Company may be subject to income tax audits in all of the jurisdictions in which it operates and, as a result, must also assess exposures to any potential issues arising from current or future audits of current and prior years’ tax returns. Accordingly, the Company must assess such potential exposures and, where necessary, provide a reserve to cover any expected loss. To the extent that the Company establishes a reserve, its provision for income taxes would be increased. If the Company ultimately determines that payment of these amounts is unnecessary, it reverses the liability and recognizes a tax benefit during the period in which it determines that the liability is no longer necessary. The Company records an additional charge in its provision for taxes in the period in which it determines that tax liability is greater than its original estimate.  The Company recognizes interest and penalties related to unrecognized tax benefits on the income tax expense line in the accompanying consolidated statement of operations. Accrued interest and penalties are included on the related tax liability line in the consolidated balance sheet.


## us-gaap:InventoryPolicyTextBlock

[0001511737-16-000040:notes:115]
Inventory and Inventory Valuation

[0001511737-16-000040:notes:116]
The Company's inventories are primarily finished goods and, to a lesser extent, raw materials, which have been either consigned to the Company's contract manufacturers or are held by the Company.  Inventories are stated at the lower of actual cost (computed on a first-in, first-out basis), or market value. Market value is based upon an estimated average selling price reduced by the estimated costs of disposal. The determination of market value involves numerous judgments including estimating average selling prices based up recent sales, industry trends, existing customer orders, and seasonal factors. Should actual market conditions differ from the Company's estimates, future results of operations could be materially affected. The Company reduces the value of its inventory for estimated obsolescence or lack of marketability by the difference between the cost of the affected inventory and the estimated market value. Write-downs are not reversed until the related inventory has been subsequently sold or scrapped.

[0001511737-16-000040:notes:117]
The valuation of inventory also requires the Company to estimate excess and obsolete inventory. The determination of excess or obsolete inventory is estimated based on a comparison of the quantity and cost of inventory on hand to the Company's forecast of customer demand. Customer demand is dependent on many factors and requires the Company to use significant judgment in our forecasting process. The Company also makes assumptions regarding the rate at which new products will be accepted in the marketplace and at which customers will transition from older products to newer products. If actual market conditions are less favorable than those projected by management, additional inventory write-downs may be required, which would have a negative impact on the Company's gross margin. If the Company ultimately sells inventory that has been previously written down, the Company's gross margins in future periods would be positively impacted.

[0001511737-16-000040:notes:118]
In fiscal 2016, the Company began capitalizing manufacturing overhead expenditures as part of inventory costs. Capitalized

[0001511737-16-000040:notes:119]
costs primarily include management’s best estimate of the direct labor and materials costs related to inventory produced but not

[0001511737-16-000040:notes:120]
sold during the period.


## us-gaap:LeasePolicyTextBlock

[0001511737-16-000040:notes:121]
Leases

[0001511737-16-000040:notes:122]
The Company leases its facilities under cancelable and noncancelable operating leases. For leases that contain rent escalation or rent concessions provisions, the Company records the total rent expense during the lease term on a straight line basis over the term of the lease. The Company records the difference between the rent paid and the straight line rent as a deferred rent liability on the consolidated balance sheets.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001511737-16-000040:notes:123]
Recent Accounting Pronouncements

[0001511737-16-000040:notes:124]
In June 2014, the Financial Accounting Standards Board, or FASB, issued a new accounting standard update on revenue from contracts with customers.  The core principle of the guidance is that an entity should recognize revenue to depict the transfer of promised goods or services to customers in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services.  To achieve that core principle, an entity should apply the following steps:

[0001511737-16-000040:notes:125]
Step 1: Identify the contract(s) with a customer.

[0001511737-16-000040:notes:126]
Step 2: Identify the performance obligations in the contract.

[0001511737-16-000040:notes:127]
Step 3: Determine the transaction price.

[0001511737-16-000040:notes:128]
Step 4: Allocate the transaction price to the performance obligations in the contract.

[0001511737-16-000040:notes:129]
Step 5: Recognize revenue when (or as) the entity satisfies a performance obligation.

[0001511737-16-000040:notes:130]
An entity should disclose sufficient information to enable users of financial statements to understand the nature, amount, timing, and uncertainty of revenue and cash flows arising from contracts with customers. Qualitative and quantitative information is required about contracts with customers, significant judgments and any assets recognized from the costs to obtain or fulfill a contract.   The guidance was to be effective for annual and interim reporting periods beginning after December 15, 2016.  However, in July 2015, the FASB deferred the effective date by one year, to December 15, 2017, to provide adequate time to effectively implement the new standard, though the early adoption as of the original effective date is allowed.  The Company is currently assessing the impact of this new guidance.

[0001511737-16-000040:notes:131]
In April 2015, the FASB issued an accounting standard update on simplifying the presentation of debt issuance costs.  The updated guidance requires that debt issuance costs related to a recognized debt liability be presented in the balance sheet as a direct deduction from the carrying amount of that debt liability, consistent with debt discounts. The recognition and measurement guidance for debt issuance costs are not affected by the updated guidance.  The guidance will be effective for the Company beginning July 1, 2016.  The guidance will result only in a reclassification on the Company's balance sheet.

[0001511737-16-000040:notes:132]
In July 2015, the FASB issued an accounting standards update on simplifying the measurement of inventory.  The updated guidance requires an entity to measure inventory at the lower of cost and net realizable value.  Net realizable value is the estimated selling prices in the ordinary course of business, less reasonably predictable costs of completion, disposal, and transportation. Subsequent measurement is unchanged for inventory measured using LIFO or the retail inventory method.

[0001511737-16-000040:notes:133]
The guidance will be effective for the Company beginning July 1, 2017.  The Company is currently assessing the impact of this new guidance.

[0001511737-16-000040:notes:134]
In November 2015, the FASB issued Accounting Standards Update (“ASU”) No. 2015-17, Balance Sheet Classification of Deferred Taxes. ASU 2015-17 simplifies the presentation of deferred taxes by requiring deferred tax assets and liabilities be classified as noncurrent on the balance sheet. ASU 2015-17 is effective for public companies for annual reporting periods beginning after December 15, 2016, and interim periods within those fiscal years. We early adopted ASU 2015-17 during the fourth quarter of fiscal 2016 on a prospective basis. The adoption did not have a material impact on the consolidated financial statements. No prior reporting period was retrospectively adjusted.

[0001511737-16-000040:notes:135]
In February 2016, the FASB issued ASU 2016-02, “Leases (Topic 842),” (“ASU 2016-02”). ASU 2016-02 requires lessees to recognize assets and liabilities on the balance sheet for leases with lease terms greater than twelve months and disclose key information about leasing arrangements. ASU 2016-02 is effective for annual periods beginning after December 15, 2018, including interim periods within those fiscal years, with early application permitted. The Company is evaluating the impact that adoption of this new standard will have on its consolidated financial statements.

[0001511737-16-000040:notes:136]
In March 2016, the FASB issued ASU 2016-08, “Revenue from Contracts with Customers (Topic 606) Principal versus Agent Considerations (Reporting Revenue Gross versus Net),” (“ASU 2016-08”). ASU 2016-08 further clarifies principal and agent relationships within ASU 2014-09. The amendment is effective beginning after December 14, 2017, including interim reporting periods within that reporting year. The Company is evaluating the impact that adoption of this new standard will have on its consolidated financial statements.

[0001511737-16-000040:notes:137]
In March 2016, the FASB issued ASU 2016-09, “Compensation-Stock Compensation (Topic 718), Improvements to Employee Share-Based Payment Accounting,” (“ASU 2016-09”). ASU 2016-09 is intended to simplify several aspects of accounting for share-based payment awards. The guidance will be effective for the Company beginning July 1, 2017. The Company is evaluating the impact that adoption of this new standard will have on its consolidated financial statements.

[0001511737-16-000040:notes:138]
In April 2016, the FASB issued ASU 2016-10, “Revenue from Contracts with Customers (Topic 606): Identifying Performance Obligations and Licensing." This ASU addresses certain implementation issues that have surfaced since the issuance of ASU 2014-09 in May 2014. The ASU provides guidance in identifying performance obligations and determining the appropriate accounting for licensing arrangements. The effective date and transition requirements for the amendments in this update are the same as the effective date and transition requirements for ASU 2014-09. The Company is in the process of assessing the impact that adoption of this new standard will have on its consolidated financial statements.

[0001511737-16-000040:notes:139]
In May 2016, the FASB issued ASU No. 2016-12 (“ASU 2016-12”), “Revenue from Contracts with Customers (Topic 606): Narrow-Scope Improvements and Practical Expedients”. ASU 2016-12 will affect all entities that enter into contracts with customers to transfer goods or services (that are an output of the entity’s ordinary activities) in exchange for consideration. The amendments in this update affect the guidance in ASU 2014-09 which is not yet effective. The amendments in this update also affect narrow aspects of Topic 606 including among others: assessing collectability criterion, noncash consideration, and presentation of sales taxes and other similar taxes collected from customers. The effective date and transition requirements for the amendments in this update are the same as the effective date and transition requirements for ASU 2014-09. The Company is evaluating the impact that adoption of this new standard will have on its consolidated financial statements.

[0001511737-16-000040:notes:140]
In June 2016, the FASB issued ASU 2016-13, “Financial Instruments – Credit Losses (TOPIC 326): Measurement of Credit  Losses On Financial Instruments”. ASU 2016-13 implements a comprehensive change in estimating the allowances for loan losses from the current model of losses inherent in the loan portfolio to a current expected credit loss model that generally is expected to result in earlier recognition of allowances for losses. Additionally, purchase accounting rules have been modified as well as credit losses on held-to-maturity debt securities. ASU 2016-13 is effective for fiscal years beginning after December 15, 2019, and early adoption is permitted for annual and interim periods beginning after December 15, 2018. The Company is in the process of assessing the impact that adoption of this new standard will have on its consolidated financial statements.


## us-gaap:OtherCurrentLiabilitiesTableTextBlock

[0001511737-16-000040:notes:141]
Other long-term assets consisted of the following (in thousands):

[0001511737-16-000040:notes:142]
|  | June 30, |
|  | 2016 |  | 2015 |
| Intangible assets, net (1) | $ | 616 |  |  | $ | 575 |  |
| Debt issuance costs, net (2) | 686 |  |  | 943 |  |
| Other long-term assets | 960 |  |  | 591 |  |
|  | $ | 2,262 |  |  | $ | 2,109 |  |

[0001511737-16-000040:notes:143]
(1) - Accumulated amortization was $955 thousand and $690 thousand as of June 30, 2016 and June 30, 2015 , respectively.

[0001511737-16-000040:notes:144]
(2) - Accumulated amortization was $341 thousand and $84 thousand as of  June 30, 2016 and  June 30, 2015, respectively.


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001511737-16-000040:notes:145]
ACCRUED WARRANTY

[0001511737-16-000040:notes:146]
Warranty obligations, included in other current liabilities, were as follows (in thousands):

[0001511737-16-000040:notes:147]
| Balance at June 30, 2014 | $ | 2,850 |  |
| Accruals for warranties issued during the period | 3,643 |  |
| Settlements made during the period | (3,743 | ) |
| Balance at June 30, 2015 | 2,750 |  |
| Accruals for warranties issued during the period | 2,597 |  |
| Settlements made during the period | (3,111 | ) |
| Balance at June 30, 2016 | $ | 2,236 |  |


## us-gaap:PropertyPlantAndEquipmentPolicyTextBlock

[0001511737-16-000040:notes:148]
Property and Equipment

[0001511737-16-000040:notes:149]
Furniture, fixtures and equipment are recorded at cost. The Company also capitalizes certain costs of software developed for internal use.  Capitalized costs primarily include payroll and payroll-related costs and facilities costs. During fiscal 2016, the Company capitalized $1.3 million of software development costs, respectively, which is included as property and equipment on the Company's consolidated balance sheet as of June 30, 2016.

[0001511737-16-000040:notes:150]
The Company computes depreciation or amortization using the straight line method over estimated useful lives, as follows:

[0001511737-16-000040:notes:151]
|  |  | Estimated Useful Life |
| Testing equipment |  | 3 to 5 years |
| Computer and other equipment |  | 3 to 5 years |
| Furniture and fixtures |  | 3 to 5 years |
| Software |  | up to 3 years |
| Leasehold improvements |  | shorter of lease term or useful life |

[0001511737-16-000040:notes:152]
Upon retirement or disposition, the asset cost and related accumulated depreciation are removed with any gain or loss recognized in the statement of operations. Expenditures for maintenance and repairs are charged to operations as incurred.


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0001511737-16-000040:notes:153]
Property and equipment, net consisted of the following (in thousands):

[0001511737-16-000040:notes:154]
|  | June 30, |
|  | 2016 |  | 2015 |
| Testing equipment | $ | 6,051 |  |  | $ | 4,816 |  |
| Computer and other equipment | 4,857 |  |  | 4,458 |  |
| Tooling equipment | 5,801 |  |  | 4,073 |  |
| Furniture and fixtures | 1,325 |  |  | 1,239 |  |
| Leasehold improvements | 5,136 |  |  | 4,789 |  |
| Software (1) (2) | 2,488 |  |  | 3,268 |  |
| Software in development (1) (2) | 2,739 |  |  | 2,700 |  |
|  | 28,397 |  |  | 25,343 |  |
| Less: Accumulated depreciation (3) | (15,444 | ) |  | (9,741 | ) |
|  | $ | 12,953 |  |  | $ | 15,602 |  |

[0001511737-16-000040:notes:155]
(1) - In the year ended June 30, 2016, the Company recorded a $2.5 million impairment charge in research and development

[0001511737-16-000040:notes:156]
expense for capitalized software development costs due to the cancellation of the commercial launch of certain software in development. No impairment charges were recorded for the year ended June 30, 2015.

[0001511737-16-000040:notes:157]
(2) -  We capitalized $1.3 million and $4.0 million for software development in fiscal 2016 and 2015, respectively.

[0001511737-16-000040:notes:158]
(3)- Depreciation expense was $5.7 million, $4.7 million and $2.6 million in fiscal 2016, 2015 and 2014, respectively.


## us-gaap:ReceivablesPolicyTextBlock

[0001511737-16-000040:notes:159]
Allowance for Doubtful Accounts

[0001511737-16-000040:notes:160]
The Company records an allowance for doubtful accounts for estimated probable losses on uncollectible accounts receivable. In estimating the allowance, management considers, among other factors, (i) the aging of the accounts receivable, (ii) the Company’s historical write offs, (iii) the credit worthiness of each distributor based on payment history and (iv) general economic conditions. In cases where the Company is aware of circumstances that may impair a specific distributor’s ability to meet its obligations to the Company, the Company records a specific allowance against amounts due from the distributor, and thereby reduces the net recognized receivable to the amounts it reasonably believes will be collected.


## us-gaap:ReconciliationOfRevenueFromSegmentsToConsolidatedTextBlock

[0001511737-16-000040:notes:161]
Revenues by product type were as follows (in thousands, except percentages):

[0001511737-16-000040:notes:162]
|  | Years Ended June 30, |
|  | 2016 |  | 2015 |  | 2014 |
| Service Provider Technology | $ | 418,346 |  |  | 63 | % |  | $ | 418,021 |  |  | 70 | % |  | $ | 450,663 |  |  | 79 | % |
| Enterprise Technology | 248,049 |  |  | 37 | % |  | 177,926 |  |  | 30 | % |  | 121,801 |  |  | 21 | % |
| Total revenues | $ | 666,395 |  |  | 100 | % |  | $ | 595,947 |  |  | 100 | % |  | $ | 572,464 |  |  | 100 | % |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001511737-16-000040:notes:163]
RELATED PARTY TRANSACTIONS AND CERTAIN OTHER TRANSACTIONS

[0001511737-16-000040:notes:164]
Aircraft Lease Agreement

[0001511737-16-000040:notes:165]
On November 13, 2013, the Company entered into an aircraft lease agreement (the "Aircraft Lease Agreement") with RJP Manageco LLC (the "Lessor"), a limited liability company owned by the Company’s Chief Executive Officer, Robert J. Pera. Pursuant to the Aircraft Lease Agreement, the Company may lease an aircraft owned by the Lessor for Company business purposes. Under the Aircraft Lease Agreement, the aircraft may be leased at a rate of $5,000 per flight hour. This hourly rate does not include the cost of flight crew or on-board services, which the Company will purchase from a third-party provider. The Company recognized a total of approximately $1,305,000, $434,000 and $258,000 in expenses pursuant to the Aircraft Lease Agreement during fiscal 2016, fiscal 2015 and fiscal 2014, respectively. All expenses pursuant to the Aircraft Lease Agreement have been included in the Company's sales, general and administrative expenses in the Condensed Consolidated Statements of Operations.


## us-gaap:ResearchDevelopmentAndComputerSoftwarePolicyTextBlock

[0001511737-16-000040:notes:166]
Research and Development Costs

[0001511737-16-000040:notes:167]
Research and development expenses are expensed as incurred and consist primarily of payroll and payroll-related costs and facilities costs.  Research and development expenses associated with software development are typically expensed as incurred as our software is usually released to end customers immediately after technological feasibility has been established.  However, the Company capitalizes development costs when material costs are incurred subsequent to technological feasibility but prior to commercial release.


## us-gaap:RevenueFromExternalCustomersByGeographicAreasTableTextBlock

[0001511737-16-000040:notes:168]
Revenues by geography based on customer's ship-to destinations were as follows (in thousands, except percentages):

[0001511737-16-000040:notes:169]
|  | Years Ended June 30, |
|  | 2016 |  | 2015 |  | 2014 |
| North America(1) | $ | 239,526 |  |  | 36 | % |  | $ | 197,693 |  |  | 33 | % |  | $ | 142,438 |  |  | 25 | % |
| South America | 85,036 |  |  | 13 | % |  | 97,118 |  |  | 16 | % |  | 109,584 |  |  | 19 | % |
| Europe, the Middle East and Africa | 264,404 |  |  | 39 | % |  | 234,383 |  |  | 40 | % |  | 247,009 |  |  | 43 | % |
| Asia Pacific | 77,429 |  |  | 12 | % |  | 66,753 |  |  | 11 | % |  | 73,433 |  |  | 13 | % |
| Total revenues | $ | 666,395 |  |  | 100 | % |  | $ | 595,947 |  |  | 100 | % |  | $ | 572,464 |  |  | 100 | % |

[0001511737-16-000040:notes:170]
| (1) | Revenue for the United States was $225.6 million, $187.3 million and $136.6 million for fiscal 2016, 2015 and 2014, respectively. |


## us-gaap:RevenueRecognitionPolicyTextBlock

[0001511737-16-000040:notes:171]
Recognition of Revenues

[0001511737-16-000040:notes:172]
Revenues consist primarily of revenues from the sale of hardware and management tools, as well as the related implied post contract customer support (“PCS”). The Company recognizes revenues when persuasive evidence of an arrangement exists, delivery has occurred, the sales price is fixed or determinable and the collectability of the resulting receivable is reasonably assured. In cases where the Company lacks evidence that collectability of the resulting receivable is reasonably assured, it defers recognition of revenue until the receipt of cash.

[0001511737-16-000040:notes:173]
For the Company’s sales, evidence of the arrangement consists of an order from a customer. The Company considers delivery to have occurred once its products have been shipped and title and risk of loss have been transferred. For the Company’s sales, these criteria are met at the time the products are transferred to the customer. The Company’s arrangements with customers do not, in most cases, include provisions for cancellation, returns, inventory swaps or refunds that would materially impact recognized revenues.

[0001511737-16-000040:notes:174]
The Company records amounts billed to distributors for shipping and handling costs as revenues. The Company classifies shipping and handling costs incurred by it as cost of revenues.

[0001511737-16-000040:notes:175]
Deposit payments received from distributors in advance of recognition of revenues are included in current liabilities on the Company’s balance sheet and are recognized as revenues when all the criteria for recognition of revenues are met.

[0001511737-16-000040:notes:176]
A portion of the Company's revenues related to PCS are deferred.  This relates to the Company’s multi-element arrangements, which generally include two deliverables. The first deliverable is the hardware and software essential to the functionality of the hardware device delivered at the time of sale. The second deliverable is the implied right to PCS included with the purchase of certain products. PCS is this right to receive, on a when and if available basis, future unspecified software upgrades and features relating to the product’s essential software as well as bug fixes, email and telephone support.

[0001511737-16-000040:notes:177]
The Company uses a hierarchy to determine the allocation of revenues to the deliverables. The hierarchy is as follows: (i) vendor-specific objective evidence of fair value (“VSOE”), (ii) third-party evidence of selling price (“TPE”), and (iii) best estimate of the selling price (“BESP”).

[0001511737-16-000040:notes:178]
| (i) | VSOE generally exists only when a company sells the deliverable separately and is the price actually charged by the company for that deliverable. Generally the Company does not sell the deliverables separately and, as such, does not have VSOE. |

[0001511737-16-000040:notes:179]
| (ii) | TPE can be substantiated by determining the price that other parties sell similar or substantially similar offerings. The Company does not believe that there is accessible TPE evidence for similar deliverables. |

[0001511737-16-000040:notes:180]
| (iii) | BESP reflects the Company’s best estimates of what the selling prices of elements would be if they were sold regularly on a stand-alone basis. The Company believes that BESP is the most appropriate methodology for determining the allocation of revenue among the multiple elements. |

[0001511737-16-000040:notes:181]
The Company allocates revenues between these two deliverables using the relative selling price method which is based on the estimated selling price for all deliverables. Revenues allocated to the delivered hardware and the related essential software are recognized at the time of sale provided the other conditions for recognition of revenues have been met. Revenues allocated to the PCS are deferred and recognized on a straight-line basis over the estimated period for which services will be delivered to support each of these devices which, currently, is two years.  If the estimated life of the hardware product should change, the future rate of amortization of the revenues allocated to PCS would also change.  All cost of revenues for the delivered hardware and the related essential software, including estimated warranty costs, are recognized at the time of sale. Costs for research and development and sales and marketing are expensed as incurred. Costs for PCS are recognized as they are incurred.

[0001511737-16-000040:notes:182]
The Company’s process for determining BESP for deliverables involves multiple factors that may vary depending upon the unique facts and circumstances related to each deliverable. For PCS, the Company believes its network operators and service providers would be reluctant to pay for such services separately. This view is primarily based on the fact that unspecified upgrade rights do not obligate the Company to provide upgrades at a particular time or at all, and do not specify to network operators and service providers which upgrades or features will be delivered. The Company believes that the relatively low prices of its products and its network operators’ and service providers’ price sensitivity would add to their reluctance to pay for PCS. Therefore, the Company has concluded that if it were to sell PCS on a standalone basis, the selling price would be relatively low.

[0001511737-16-000040:notes:183]
Key factors considered by the Company in developing the BESP for PCS include reviewing the activities of specific employees engaged in support and software development to determine the amount of time that is allocated to the development of the undelivered elements, determining the cost of this development effort, and then adding an appropriate level of gross profit to these costs.


## us-gaap:ScheduleOfAccruedLiabilitiesTableTextBlock

[0001511737-16-000040:notes:184]
Accrued liabilities consisted of the following (in thousands):

[0001511737-16-000040:notes:185]
|  | June 30, |
|  | 2016 |  | 2015 |
| Accrued compensation and benefits | $ | 1,589 |  |  | $ | 2,142 |  |
| Accrued expense | 5,749 |  |  | 5,540 |  |
| Warranty accrual | 2,236 |  |  | 2,750 |  |
| Deferred revenue - short term | 2,917 |  |  | 2,538 |  |
| Customer deposits | 856 |  |  | 63 |  |
| Reserve for sales returns | 2,820 |  |  | 1,227 |  |
| Other payables | 10,505 |  |  | 910 |  |
|  | $ | 26,672 |  |  | $ | 15,170 |  |


## us-gaap:ScheduleOfCreditLossesForFinancingReceivablesCurrentTableTextBlock

[0001511737-16-000040:notes:186]
The allowance for doubtful accounts activity was as follows (in thousands):

[0001511737-16-000040:notes:187]
|  |  | Years Ended June 30, |
|  |  | 2016 |  | 2015 |  | 2014 |
| Beginning balance |  | $ | 1,071 |  |  | $ | 1,395 |  |  | $ | 2,200 |  |
| Charged to (released from) expenses |  | (1 | ) |  | 106 |  |  | (658 | ) |
| Bad debt write-offs |  | (1,022 | ) |  | (430 | ) |  | (147 | ) |
| Ending Balance |  | $ | 48 |  |  | $ | 1,071 |  |  | $ | 1,395 |  |


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0001511737-16-000040:notes:188]
Inventories consisted of the following (in thousands):

[0001511737-16-000040:notes:189]
|  | June 30, |
|  | 2016 |  | 2015 |
| Finished goods | $ | 55,694 |  |  | $ | 39,986 |  |
| Raw materials | 8,500 |  |  | 3,445 |  |
| Provision for inventory obsolescence | (7,081 | ) |  | (6,400 | ) |
|  | $ | 57,113 |  |  | $ | 37,031 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001511737-16-000040:notes:190]
SEGMENT INFORMATION, REVENUES BY GEOGRAPHY AND SIGNIFICANT CUSTOMERS

[0001511737-16-000040:notes:191]
Management has determined that the Company operates as one reportable and operating segment as the Company's Chief Executive Officer, who is the Company's chief operating decision maker, does not make decisions about resources to be allocated or assess performance on a segment basis.  Furthermore, the Company does not organize or report its costs on a segment basis.

[0001511737-16-000040:notes:192]
Revenue


## us-gaap:SegmentReportingPolicyPolicyTextBlock

[0001511737-16-000040:notes:193]
Segments

[0001511737-16-000040:notes:194]
Management has determined that it operates as one reportable and operating segment as the Company's Chief Executive Officer, who is the Company's chief operating decision maker, does not make decisions about resources to be allocated or assess performance on a segment basis.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001511737-16-000040:notes:195]
SUMMARY OF SIGNIFICANT ACCOUNTING POLICIES

[0001511737-16-000040:notes:196]
Use of Accounting Estimates

[0001511737-16-000040:notes:197]
The preparation of financial statements in conformity with GAAP requires management to make estimates and judgments that affect the reported amounts of assets and liabilities and the disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenues and expenses during the reporting period. On an ongoing basis, the Company evaluates these estimates, including those related to allowance for doubtful accounts, inventory valuation, vendor deposits, warranty costs, stock-based compensation and income taxes, among others. The Company bases estimates on historical experience and on various other assumptions that are believed to be reasonable under the circumstances. Actual results may differ materially from these estimates.

[0001511737-16-000040:notes:198]
Management has determined that it operates as one reportable and operating segment as the Company's Chief Executive Officer, who is the Company's chief operating decision maker, does not make decisions about resources to be allocated or assess performance on a segment basis. See Note 12.

[0001511737-16-000040:notes:199]
Key factors considered by the Company in developing the BESP for PCS include reviewing the activities of specific employees engaged in support and software development to determine the amount of time that is allocated to the development of the undelivered elements, determining the cost of this development effort, and then adding an appropriate level of gross profit to these costs.  As of June 30, 2016 and 2015, the Company had deferred revenues of $4.2 million and $3.5 million, respectively, related to these obligations.

[0001511737-16-000040:notes:200]
Concentration of Risk

[0001511737-16-000040:notes:201]
Financial instruments that potentially subject the Company to concentrations of credit risk consist of cash and cash equivalents and accounts receivable. The Company limits its exposure by primarily placing its cash in interest-bearing deposit accounts with high credit quality financial institutions.

[0001511737-16-000040:notes:202]
The Company derives its accounts receivable from revenues earned from customers located worldwide. The Company bases credit decisions primarily upon a customer’s past credit history. The Company’s standard credit terms are net 30 to 60 days, and up to 120 days for solar customers.

[0001511737-16-000040:notes:203]
The Company subcontracts with other companies to manufacture most of its products. The Company relies on the ability of these contract manufacturers to produce the products sold to its distributors.  A significant portion of the Company’s products are manufactured by a few contract manufacturers.

[0001511737-16-000040:notes:204]
sold during the period. As of June 30, 2016, the Company capitalized $1.2 million of manufacturing overhead costs.

[0001511737-16-000040:notes:205]
Manufacturing overhead costs are capitalized to inventory and are recognized as cost of revenues in the following quarter,

[0001511737-16-000040:notes:206]
consistent with the Company's historical inventory turnover.

[0001511737-16-000040:notes:207]
Deferred Cost of Revenues

[0001511737-16-000040:notes:208]
Deferred cost of revenues consist of the cost of product shipped to distributors for which the rights and obligations of ownership have passed to the distributor but revenues have not yet been recognized primarily because the collectability criterion for revenue recognition has not been fulfilled. The Company classifies these amounts as deferred cost of revenues. All deferred costs of revenues are stated at cost. The Company periodically assesses the recoverability of deferred cost of revenues and writes down the deferred cost of revenues balances to establish a new cost basis when recovery of deferred cost of revenues is not reasonably assured. The Company evaluates recoverability based on various factors including the length of time the product has been held at the distributor’s site and the financial viability of the distributor.

[0001511737-16-000040:notes:209]
Product Warranties

[0001511737-16-000040:notes:210]
The Company offers warranties on certain products, generally for a period of one year, and records a liability for the estimated future costs associated with potential warranty claims. The warranty costs are reflected in the Company’s consolidated statement of operations and comprehensive income within cost of revenues. The warranties are typically in effect for 12 months from the distributor’s purchase date of the product. The Company’s estimate of future warranty costs is largely based on historical experience factors including product failure rates, material usage, and service delivery cost incurred in correcting product failures. In certain circumstances, the Company may have recourse from its contract manufacturers for replacement cost of defective products, which it also factors into its warranty liability assessment.

[0001511737-16-000040:notes:211]
Fair Value of Financial Instruments

[0001511737-16-000040:notes:212]
Pursuant to the accounting guidance for fair value measurements and its subsequent updates, fair value is defined as the price that would be received from selling an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date. As such, fair value is a market-based measurement that should be determined based on assumptions that market participants would use in pricing an asset or liability. The accounting guidance establishes a three-tier fair value hierarchy that requires the Company to use observable market data, when available, and to minimize the use of unobservable inputs when determining fair value. The fair value hierarchy prioritizes the inputs into three levels that may be used in measuring fair value as follows:

[0001511737-16-000040:notes:213]
Level 1—observable inputs which include quoted prices in active markets for identical assets of liabilities.

[0001511737-16-000040:notes:214]
Level 2—inputs which include observable inputs other than Level 1, such as quoted prices for similar assets or liabilities, quoted prices for identical or similar assets or liabilities in markets that are not active, or other inputs that are observable or can be corroborated by observable market data for substantially the full term of the asset or liability.

[0001511737-16-000040:notes:215]
Level 3—inputs which include unobservable inputs that are supported by little or no market activity and that are significant to the fair value of the underlying asset or liability. Level 3 assets and liabilities include those whose fair value measurements are determined using pricing models, discounted cash flow methodologies or similar valuation techniques, as well as significant management judgment or estimation.

[0001511737-16-000040:notes:216]
The Company evaluates its long lived assets including property and equipment for impairment whenever events or changes in circumstances indicate that the carrying value of these assets may not be recoverable. An impairment loss is recognized when the net book value of such assets exceeds the estimated future undiscounted cash flows attributable to the assets or asset group. If impairment is indicated, the asset is written down to its estimated fair value. The Company recorded a $2.5 million impairment charge for capitalized software development costs due to the cancellation of the commercial launch of certain software in development during fiscal 2016. The Company did not recognize any significant impairment losses for fiscal 2015 and 2014.

[0001511737-16-000040:notes:217]
Intangible Assets

[0001511737-16-000040:notes:218]
The Company’s intangible assets consist primarily of legal costs associated with application for and registration of the Company’s trademarks. The Company amortizes all definite-lived intangible assets that are subject to amortization over the estimated useful life based on economic benefit, which is generally 5 years.  All patent filing and defense costs are expensed as incurred, however to date these costs have not been significant.

[0001511737-16-000040:notes:219]
Advertising Costs

[0001511737-16-000040:notes:220]
The Company expenses all advertising costs as incurred.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001511737-16-000040:notes:221]
COMMON STOCK AND TREASURY STOCK

[0001511737-16-000040:notes:222]
As of June 30, 2016 and 2015, the authorized capital of the Company included 500,000,000 shares of common stock. As of June 30, 2016 and 2015, 81,667,129  and 87,413,777 shares of common stock were outstanding, respectively.

[0001511737-16-000040:notes:223]
Treasury Stock Retirement

[0001511737-16-000040:notes:224]
In February 2015, we retired 44,768,739 shares of the Company's treasury stock.  These retired shares are now included in the Company’s pool of authorized but unissued shares. The retired stock had a carrying value of $138.9 million. The Company’s policy upon the formal retirement of treasury stock is to reflect the excess over par value as a deduction from Additional Paid-in Capital until the balance is reduced to zero, then the Company records any additional excess directly to retained earnings.

[0001511737-16-000040:notes:225]
Common Stock Repurchases

[0001511737-16-000040:notes:226]
On August 4, 2015, the Board of Directors authorized the Company to repurchase up to $100.0 million of its common stock. All common stock repurchased by the Company is immediately retired, and is recorded consistent with the treasury stock policy discussed above.  The share repurchase program has been funded from existing cash on hand in addition to draws on the revolving credit facility of the Amended Credit Agreement.  In the first quarter of fiscal 2016, the company repurchased 1,872,469 shares of its common stock at an average price per share of $33.79 for an aggregate amount of $63.3 million.  In the second quarter of fiscal 2016, the Company repurchased 1,074,749 shares of its common stock at an average price per share of $34.12 for an aggregate amount of $36.7 million.

[0001511737-16-000040:notes:227]
On November 3, 2015, the Board of Directors of the Company approved a $50 million stock repurchase program where the Company was authorized to $50 million of its common stock. During the third quarter of fiscal 2016, the Company repurchased 1,765,523 shares of its common stock at an average price per share of $28.30 for an aggregate amount of $50.0 million.

[0001511737-16-000040:notes:228]
On May 4, 2016, the Board of Directors of the Company approved a $50 million stock repurchase program.  Under the stock repurchase program, the Company was authorized to repurchase up to $50 million of its common stock. During the fourth quarter of fiscal 2016, the Company repurchased 1,309,606 shares of its common stock at an average price per share of $38.18 for an aggregate amount of $50 million.  This included unpaid stock repurchases of $6.5 million relating to repurchases executed on or prior to June 30, 2016 for trades that settled after June 30, 2016.

[0001511737-16-000040:notes:229]
On August 3, 2016, the Board of Directors of the Company approved a $50 million stock repurchase program. Under the new stock repurchase program, the Company may repurchase up to $50 million of its common stock. The program expires on September 30, 2017.

[0001511737-16-000040:notes:230]
Dividend Distribution

[0001511737-16-000040:notes:231]
On September 30, 2014, the Company announced that its Board of Directors had approved an annual dividend.  The Company declared the dividend of $0.17 per share on September 30, 2014.  The aggregate amount of $15.0 million was paid on October 28, 2014 to stockholders of record on October 17, 2014.  The Company currently has no plans to pay a cash dividend at this time or at any time in the foreseeable future.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001511737-16-000040:notes:232]
BALANCE SHEET COMPONENTS

[0001511737-16-000040:notes:233]
Inventories

[0001511737-16-000040:notes:234]
Prepaid Expenses and Other Current Assets

[0001511737-16-000040:notes:235]
Property and Equipment, Net

[0001511737-16-000040:notes:236]
Other Long-term Assets

[0001511737-16-000040:notes:237]
Other Current Liabilities


## us-gaap:UnusualOrInfrequentItemsDisclosureTextBlock

[0001511737-16-000040:notes:238]
BUSINESS EMAIL COMPROMISE FRAUD LOSS

[0001511737-16-000040:notes:239]
As disclosed in June 2015, the Company determined that it was the victim of criminal fraud known to law enforcement authorities as business e-mail compromise fraud which involved employee impersonation and fraudulent requests targeting our finance department.  The fraud resulted in transfers of funds aggregating $46.7 million held by a Company subsidiary incorporated in Hong Kong to other overseas accounts held by third parties. As of June 30, 2015, the Company recovered $8.1 million.  As a result, the Company recorded a charge of $39.1 million in the fourth quarter of fiscal 2015, including additional expenses consisting of professional service fees associated with the fraud loss.  In fiscal 2016, the Company recorded a net recovery of $8.3 million, comprised of the $8.6 million recovery less $0.3 million of professional service fees associated with the recovery.

[0001511737-16-000040:notes:240]
The Company is continuing to pursue the recovery of the remaining $30.0 million and is cooperating with U.S. federal and numerous overseas law enforcement authorities who are actively pursuing a multi-agency criminal investigation.  Any additional recoveries are likely remote and therefore cannot be assured.
