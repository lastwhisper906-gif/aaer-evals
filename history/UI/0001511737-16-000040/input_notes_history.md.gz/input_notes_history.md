# UI note change history — 0001511737-16-000032 → 0001511737-16-000037


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2016-05-05):
[0001511737-16-000037:note_history:1]
Certain facilities and equipment are leased under non-cancelable operating leases. The Company generally pays taxes, insurance and maintenance costs on leased facilities and equipment. The Company leases office space in San Jose, California and other locations under various non-cancelable operating leases that expire at various dates through fiscal 2021.
  (was, 2016-02-04, similarity 0.99):
[0001511737-16-000032:note_history:1]
Certain facilities and equipment are leased under non-cancelable operating leases. The Company generally pays taxes, insurance and maintenance costs on leased facilities and equipment. The Company leases office space in San Jose, California and other locations under various non-cancelable operating leases that expire at various dates through 2021.

- changed (2016-05-05):
[0001511737-16-000037:note_history:2]
At March 31, 2016, future minimum annual payments under operating leases for the remainder of fiscal 2016 and future fiscal years are as follows (in thousands):
  (was, 2016-02-04, similarity 0.9705):
[0001511737-16-000032:note_history:2]
At December 31, 2015, future minimum annual payments under operating leases for the remainder of fiscal 2016 and future fiscal years are as follows (in thousands):

- changed (2016-05-05):
[0001511737-16-000037:note_history:3]
The Company primarily subcontracts with other companies to manufacture its products. During the normal course of business, the Company’s contract manufacturers procure components based upon orders placed by the Company. If the Company cancels all or part of the orders, it may still be liable to the contract manufacturers for the cost of the components purchased by them to manufacture the Company’s products. The Company periodically reviews the potential liability, and no significant accruals have been recorded for the nine months ended March 31, 2016.  The Company had inventory purchase obligations of $22.0 million as of March 31, 2016.
  (was, 2016-02-04, similarity 0.9521):
[0001511737-16-000032:note_history:3]
The Company primarily subcontracts with other companies to manufacture its products. During the normal course of business, the Company’s contract manufacturers procure components based upon orders placed by the Company. If the Company cancels all or part of the orders, it may still be liable to the contract manufacturers for the cost of the components purchased by them to manufacture the Company’s products. The Company periodically reviews the potential liability, and to date, no significant accruals have been recorded.  The Company had inventory purchase obligations of $21.6 million as of December 31, 2015.

- changed (2016-05-05):
[0001511737-16-000037:note_history:4]
The Company had other obligations of $6.3 million as of March 31, 2016, which consisted primarily of commitments related to research and development projects.
  (was, 2016-02-04, similarity 0.9703):
[0001511737-16-000032:note_history:4]
The Company had other obligations of $6.2 million as of December 31, 2015, which consisted primarily of commitments related to research and development projects.


## us-gaap:BusinessDescriptionAndBasisOfPresentationTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2016-05-05):
[0001511737-16-000037:note_history:5]
Basis of Presentation— The accompanying condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP”) related to interim financial statements based on applicable Securities and Exchange Commission (“SEC”) rules and regulations. Accordingly, they do not include all the information and footnotes required by U.S. GAAP for complete financial statements. These condensed and consolidated financial statements reflect all adjustments, which are, in the opinion of the Company, of a normal and recurring nature and those necessary to state fairly the statements of financial position, results of operations and cash flows for the dates and periods presented. The June 30, 2015 balance sheet was derived from the audited financial statements as of that date. All significant intercompany transactions and balances have been eliminated.  The Company has reclassified certain amounts reported in the previous period to conform to the current period presentation.
  (was, 2016-02-04, similarity 0.9574):
[0001511737-16-000032:note_history:5]
Basis of Presentation— The accompanying condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP”) related to interim financial statements based on applicable Securities and Exchange Commission (“SEC”) rules and regulations. Accordingly, they do not include all the information and footnotes required by U.S. GAAP for complete financial statements. This information reflects all adjustments, which are, in the opinion of the Company, of a normal and recurring nature and necessary to state fairly the statements of financial position, results of operations and cash flows for the dates and periods presented. The June 30, 2015 balance sheet was derived from the audited financial statements as of that date. All significant intercompany transactions and balances have been eliminated.  The Company has reclassified certain amounts reported in the previous period to conform to the current period presentation.

- changed (2016-05-05):
[0001511737-16-000037:note_history:6]
These condensed consolidated financial statements should be read in conjunction with the Company’s audited consolidated financial statements for the fiscal year ended June 30, 2015, included in its Annual Report on Form 10-K, as filed with the SEC on August 21, 2015 (the “Annual Report”). The results of operations for the three and nine months ended March 31, 2016 are not necessarily indicative of the results to be expected for any future periods.
  (was, 2016-02-04, similarity 0.9448):
[0001511737-16-000032:note_history:6]
These condensed consolidated financial statements should be read in conjunction with the Company’s audited consolidated financial statements for the fiscal year ended June 30, 2015, included in its Annual Report on Form 10-K, as filed with the SEC on August 21, 2015 (the “Annual Report”). The results of operations for the three and six months ended December 31, 2015 are not necessarily indicative of the results to be expected for any future periods.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2016-05-05):
[0001511737-16-000037:note_history:7]
In fiscal 2016, the Company began capitalizing manufacturing overhead expenditures as part of inventory costs.  Capitalized costs primarily include management’s best estimate of the direct labor and materials costs related to inventory produced but not sold during the period.  As of March 31, 2016, the Company capitalized $1.2 million of manufacturing overhead costs.  Manufacturing overhead costs are capitalized to inventory and are recognized as cost of revenues in the following quarter, consistent with the Company's historical inventory turnover.

- added (2016-05-05):
[0001511737-16-000037:note_history:8]
In April 2015, the FASB issued Accounting Standards Update (“ASU”) 2015-03 to simplify the presentation of debt issuance costs.  The updated guidance requires that debt issuance costs related to a recognized debt liability be presented in the balance sheet as a direct deduction from the carrying amount of that debt liability, consistent with debt discounts. The recognition and measurement guidance for debt issuance costs are not affected by the updated guidance.  The guidance will be effective for the Company beginning July 1, 2016.  The guidance will result only in a reclassification on the Company’s balance sheet and will not have any effect on the Company’s results of operations or cash flows.

- changed (2016-05-05):
[0001511737-16-000037:note_history:9]
In July 2015, the FASB issued ASU 2015-11 which explains how the Accounting Standards Codification will be updated to simplify the measurement of inventory costs.  The updated guidance requires that inventory be valued at the lower of cost or net realizable value.  This differs from current guidance which requires that inventory be valued at the lower of cost or market, where market can be replacement cost, net realizable value or net realizable value less an approximately normal profit margin.  The guidance will be effective for the Company beginning July 1, 2017.  The Company does not anticipate that this guidance will have a material impact on the Company’s consolidated financial statements.
  (was, 2016-02-04, similarity 0.8547):
[0001511737-16-000032:note_history:9]
In July 2015, the FASB issued Accounting Standards Update (ASU) 2015-11 which explains how the Accounting Standards Codification will be updated to simplify the measurement of inventory costs.  The updated guidance requires that inventory be valued at the lower of cost or net realizable value.  This differs from current guidance which requires that inventory be valued at the lower of cost or market, where market can be replacement cost, net realizable value or net realizable value less an approximately normal profit margin.  The guidance will be effective for the Company beginning July 1, 2017.  We do not anticipate that this guidance will have a material impact on the presentation of the Company’s consolidated financial statements.

- added (2016-05-05):
[0001511737-16-000037:note_history:10]
In November 2015, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update No. 2015-17, Balance Sheet Classification of Deferred Taxes. ASU 2015-17 simplifies the presentation of deferred taxes by requiring deferred tax assets and liabilities be classified as non-current on the balance sheet. ASU 2015-17 is effective for public companies for annual reporting periods beginning after December 15, 2016, and interim periods within those fiscal years. The guidance may be adopted prospectively or retrospectively, and early adoption is permitted.  The Company is currently evaluating ASU 2015-17 but does not anticipate that this guidance will have a material impact on the presentation of the Company's consolidated financial statements.

- added (2016-05-05):
[0001511737-16-000037:note_history:11]
In February 2016, the FASB issued ASU 2016-02, “Leases (Topic 842),” (“ASU 2016-02”). ASU 2016-02 requires lessees to recognize assets and liabilities on the balance sheet for leases with lease terms greater than twelve months and disclose key information about leasing arrangements. ASU 2016-02 is effective for annual periods beginning after December 15, 2018, including interim periods within those fiscal years, with early application permitted. The Company is evaluating the impact that adoption of this new standard will have on its consolidated financial statements.

- added (2016-05-05):
[0001511737-16-000037:note_history:12]
In March 2016, the FASB issued ASU 2016-08, “Revenue from Contracts with Customers (Topic 606) Principal versus Agent Considerations (Reporting Revenue Gross versus Net),” (“ASU 2016-08”). ASU 2016-08 further clarifies principal and agent relationships within ASU 2014-09. The amendment is effective beginning after December 14, 2017, including interim reporting periods within that reporting year. The Company is evaluating the impact that adoption of this new standard will have on its consolidated financial statements.

- added (2016-05-05):
[0001511737-16-000037:note_history:13]
In March 2016, the FASB issued ASU 2016-09, “Compensation-Stock Compensation (Topic 718), Improvements to Employee Share-Based Payment Accounting,” (“ASU 2016-09”). ASU 2016-09 is intended to simplify several aspects of accounting for share-based payment awards. The amendment is effective for annual periods beginning after December 15, 2016, and interim periods within those annual periods. The Company is evaluating the impact that adoption of this new standard will have on its consolidated financial statements.

- added (2016-05-05):
[0001511737-16-000037:note_history:14]
In April 2016, the FASB issued ASU 2016-10, “Revenue from Contracts with Customers (Topic 606): Identifying Performance Obligations and Licensing." This ASU addresses certain implementation issues that have surfaced since the issuance of ASU 2014-09 in May 2014. The ASU provides guidance in identifying performance obligations and determining the appropriate accounting for licensing arrangements. The amendments in this ASU are effective for fiscal years beginning after December 15, 2017, and for interim periods therein. The Company is in the process of assessing the impact that adoption of this new standard will have on its consolidated financial statements.

- removed (2016-05-05):
[0001511737-16-000032:note_history:15]
In fiscal 2016, the Company began capitalizing manufacturing overhead expenditures as part of inventory costs.  Capitalized costs primarily include management’s best estimate of the direct labor and materials costs related to inventory produced but not sold during the period.  As of December 31, 2015, the Company capitalized $994 thousand of manufacturing overhead costs, which are included in inventory on the Company’s condensed consolidated balance sheet as of December 31, 2015.  These capitalized amounts are recognized as cost of revenues in the following quarter, consistent with the Company's historical inventory turnover.

- removed (2016-05-05):
[0001511737-16-000032:note_history:16]
In April 2015, the FASB issued an accounting standard update on simplifying the presentation of debt issuance costs.  The updated guidance requires that debt issuance costs related to a recognized debt liability be presented in the balance sheet as a direct deduction from the carrying amount of that debt liability, consistent with debt discounts. The recognition and measurement guidance for debt issuance costs are not affected by the updated guidance.  The guidance will be effective for the Company beginning July 1, 2016.  The guidance will result only in a reclassification on the Company’s balance sheet and will not have any effect on the Company’s results of operations or cash flows.

- removed (2016-05-05):
[0001511737-16-000032:note_history:17]
In November 2015, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) No. 2015-17, Balance Sheet Classification of Deferred Taxes. ASU 2015-17 simplifies the presentation of deferred taxes by requiring deferred tax assets and liabilities be classified as noncurrent on the balance sheet. ASU 2015-17 is effective for public companies for annual reporting periods beginning after December 15, 2016, and interim periods within those fiscal years. The guidance may be adopted prospectively or retrospectively and early adoption is permitted. We are currently evaluating ASU 2015-17 to determine if this guidance will have a material impact on our consolidated financial statements.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2016-05-05):
[0001511737-16-000037:note_history:18]
On March 3, 2015, Ubiquiti Networks, Inc. and Ubiquiti International Holding Company Limited (the “Cayman Borrower”) amended and restated its original credit agreement (the “Amended Credit Agreement”) with Wells Fargo Bank, National Association (“Wells Fargo”), the other financial institutions named as lenders therein, and Wells Fargo as administrative agent for the lenders.  The Amended Credit Agreement provides for a $200.0 million senior secured revolving credit facility and a $100.0 million senior secured term loan facility (collectively, the “Facilities”), with an option to request increases in the amounts of such credit facilities by up to an additional $50.0 million in the aggregate (any such increase to be in each lender’s sole discretion), and matures on March 3, 2020.  The $100.0 million term loan facility of the Amended Credit Agreement was fully drawn at closing, and $72.3 million was used to repay the outstanding balance under its original credit agreement.  During the nine months ended March 31, 2016, the Company drew $66 million against the revolving credit facility.  Draws of $15 million and $18 million were made in the second fiscal quarter and draws of $14 million and $19 million were made in the third fiscal quarter.  These balances are not due until March 2020, and accordingly are classified as long-term debt.  As of March 31, 2016, $90 million was outstanding on the term loan and $66 million on the revolver, leaving $134 million available on the revolver.  As of March 31, 2016, the interest rate on the term loan was 2.13%.  The table below shows the respective interest rates as of March 31, 2016 in addition to interest rate reset dates and rates as available for each revolver draw.

- added (2016-05-05):
[0001511737-16-000037:note_history:19]
|  |  | Interest Rate as of |  |  |  |  |
| Debt Payment Obligations |  | March 31, 2016 |  | Rate Reset Date |  | Reset Rate |
| $15 Million Revolver |  | 2.02% |  | April 8, 2016 |  | 2.13% |
| $18 Million Revolver |  | 2.01% |  | April 18, 2016 |  | 2.13% |
| $14 Million Revolver |  | 2.02% |  | May 31, 2016 |  | * |
| $19 Million Revolver |  | 2.02% |  | April 1, 2016 |  | 2.13% |

- added (2016-05-05):
[0001511737-16-000037:note_history:20]
* - Reset rate not available as of filing date.

- changed (2016-05-05):
[0001511737-16-000037:note_history:21]
The revolving credit facility includes a sub-limit of $10.0 million for letters of credit and a sub-limit of $25.0 million for swingline loans. The Facilities replaced the Company’s $150.0 million senior secured revolving credit facility under its original credit agreement. The Facilities are available for working capital and general corporate purposes that comply with the terms of the Amended Credit Agreement. Under the Amended Credit Agreement, revolving loans and swingline loans may be borrowed, repaid and reborrowed until March 3, 2020, at which time all amounts borrowed must be repaid. The term loan is payable in quarterly installments of 2.50% of the original principal amount of the term loan until March 31, 2017, thereafter increasing to 3.75% of the original principal amount of the term loan, in each case plus accrued and unpaid interest. Revolving, swingline and term loans may be prepaid at any time without penalty.
  (was, 2016-02-04, similarity 0.9967):
[0001511737-16-000032:note_history:21]
The revolving credit facility includes a sub-limit of $10.0 million for letters of credit and a sub-limit of $25.0 million for swingline loans. The Facilities replaced the Company’s $150.0 million senior secured revolving credit facility under the Original Credit Agreement. The Facilities are available for working capital and general corporate purposes that comply with the terms of the Amended Credit Agreement. Under the Amended Credit Agreement, revolving loans and swingline loans may be borrowed, repaid and reborrowed until March 3, 2020, at which time all amounts borrowed must be repaid. The term loan is payable in quarterly installments of 2.50% of the original principal amount of the term loan until March 31, 2017, thereafter increasing to 3.75% of the original principal amount of the term loan, in each case plus accrued and unpaid interest. Revolving, swingline and term loans may be prepaid at any time without penalty.

- added (2016-05-05):
[0001511737-16-000037:note_history:22]
Revolving and term loans bear interest, at the Company’s option, at either (i) a floating rate per annum equal to the base rate plus a margin of between 0.50% and 1.25%, depending on the Company’s leverage ratio as of the most recently ended fiscal quarter or (ii) a floating per annum rate equal to the applicable LIBOR rate for a specified period, plus a margin of between 1.50% and 2.25%, depending on the Company’s leverage ratio as of the most recently ended fiscal quarter. Swingline loans bear interest at a floating rate per annum equal to the base rate plus a margin of between 0.50% and 1.25%, depending on the Company’s leverage ratio as of the most recently ended fiscal quarter.

- added (2016-05-05):
[0001511737-16-000037:note_history:23]
The Amended Credit Agreement requires the Company to maintain during the term of the Facilities (i) a maximum leverage ratio of 2.50 to 1.00 and (ii) minimum liquidity of $225.0 million, increasing to $250.0 million in the event of an incremental increase in the size of the Facilities, which can be satisfied with unrestricted cash and cash equivalents and up to $50.0 million of availability under the revolving credit facility. In addition, the Amended Credit Agreement contains customary affirmative and negative covenants and includes customary events of default. The occurrence of an event of default could result in the acceleration of the obligations under the Amended Credit Agreement.

- added (2016-05-05):
[0001511737-16-000037:note_history:24]
The revolving and term loans contain other customary terms and conditions which are more fully explained in Note 7 of the audited consolidated financial statements included in the Annual Report for the year ended June 30, 2015.

- changed (2016-05-05):
[0001511737-16-000037:note_history:25]
During the three months ended March 31, 2016, the Company made a payment of $3.0 million against the term loan facility balance under the Amended Credit Agreement, of which $2.5 million was a repayment of principal and $500 thousand was payment of interest. During the nine months ended March 31, 2016, the Company made aggregate payments of $8.9 million against the term loan facility balance under the Amended Credit Agreement, of which $7.5 million was for repayments of principal and $1.4 million was for payments of interest.  During the three and nine months ended March 31, 2016, the Company made aggregate payments of $160 thousand and $260 thousand, respectively, against the revolving loan facility under the Amended Credit Agreement.  As of March 31, 2016, the Company classified $10.0 million as short-term and $146.0 million as long-term debt on its consolidated balance sheet related to the Facilities under the Amended Credit Agreement.
  (was, 2016-02-04, similarity 0.6363):
[0001511737-16-000032:note_history:25]
During the three months ended December 31, 2015, the Company made a payment of $2.9 million against the term loan facility balance under the Amended Credit Agreement, of which $2.5 million was a repayment of principal and $439 thousand was payment of interest. During the six months ended December 31, 2015, the Company made aggregate payments of $5.9 million against the term loan facility balance under the Amended Credit Agreement, of which $5.0 million was a repayment of principal and $883 thousand was payment of interest.  During the three and six months ended December 31, 2015, the Company made aggregate payments of $99 thousand against the revolving loan facility under the Amended Credit Agreement.  As of December 31, 2015, the Company classified $10.0 million as short-term and $115.5 million as long-term debt on its consolidated balance sheet related to the Facilities under the Amended Credit Agreement.

- changed (2016-05-05):
[0001511737-16-000037:note_history:26]
The following table summarizes our estimated debt and interest payment obligations as of March 31, 2016, for the remainder of fiscal 2016 and future fiscal years (in thousands):
  (was, 2016-02-04, similarity 0.9735):
[0001511737-16-000032:note_history:26]
The following table summarizes our estimated debt and interest payment obligations as of December 31, 2015, for the remainder of fiscal 2016 and future fiscal years (in thousands):

- changed (2016-05-05):
[0001511737-16-000037:note_history:27]
|  | 2016 (remainder) |  | 2017 |  | 2018 |  | 2019 |  | 2020 |  | Thereafter |  | Total |
| Debt payment obligations | $ | 2,500 |  |  | $ | 11,250 |  |  | $ | 15,000 |  |  | $ | 15,000 |  |  | $ | 112,250 |  |  | $ | — |  |  | $ | 156,000 |  |
| Interest and other payments on debt (1) | 888 |  |  | 3,422 |  |  | 3,142 |  |  | 2,822 |  |  | 1,746 |  |  | — |  |  | 12,020 |  |
| Total | $ | 3,388 |  |  | $ | 14,672 |  |  | $ | 18,142 |  |  | $ | 17,822 |  |  | $ | 113,996 |  |  | $ | — |  |  | $ | 168,020 |  |
  (was, 2016-02-04, similarity 0.9946):
[0001511737-16-000032:note_history:27]
|  | 2016 (remainder) |  | 2017 |  | 2018 |  | 2019 |  | 2020 |  | Thereafter |  | Total |
| Debt payment obligations | $ | 5,000 |  |  | $ | 11,250 |  |  | $ | 15,000 |  |  | $ | 15,000 |  |  | $ | 79,250 |  |  | $ | — |  |  | $ | 125,500 |  |
| Interest and other payments on debt | 1,439 |  |  | 2,718 |  |  | 2,442 |  |  | 2,127 |  |  | 1,313 |  |  | — |  |  | 10,039 |  |
| Total | $ | 6,439 |  |  | $ | 13,968 |  |  | $ | 17,442 |  |  | $ | 17,127 |  |  | $ | 80,563 |  |  | $ | — |  |  | $ | 135,539 |  |

- added (2016-05-05):
[0001511737-16-000037:note_history:28]
(1) - Interest payments are calculated based on the applicable rates and payment dates as of March 31, 2016. Furthermore, two to three month payment intervals on the revolving debt have been assumed, consistent with the Company's elections to date.

- removed (2016-05-05):
[0001511737-16-000032:note_history:29]
On August 7, 2012, the Company entered into a Loan and Security Agreement (the “Loan Agreement”) with U.S. Bank, as syndication agent, and East West Bank, as administrative agent for the lenders party to the Loan Agreement.  The Loan Agreement provided for (i) a $50.0 million revolving credit facility, with a $5.0 million sublimit for the issuance of letters of credit and a $5.0 million sublimit for the making of swingline loan advances, and (ii) a $50.0 million term loan facility.

- removed (2016-05-05):
[0001511737-16-000032:note_history:30]
On May 5, 2014, Ubiquiti Networks, Inc. and certain of its subsidiaries entered into a credit agreement (the “Original Credit Agreement”) with Wells Fargo Bank, National Association (“Wells Fargo”), the financial institutions named as lenders therein, and Wells Fargo as administrative agent for the lenders, that provided for a $150.0 million senior secured revolving credit facility, with an option to request an increase in the amount of the credit facility by up to an additional $50.0 million (any such increase to be in each lender’s sole discretion).  Proceeds from borrowings under the Original Credit Agreement were used to repay the Loan Agreement in full.

- removed (2016-05-05):
[0001511737-16-000032:note_history:31]
On March 3, 2015, Ubiquiti Networks, Inc. and Ubiquiti International Holding Company Limited (the “Cayman Borrower”) amended and restated the Original Credit Agreement (the “Amended Credit Agreement”) with Wells Fargo, the other financial institutions named as lenders therein, and Wells Fargo as administrative agent for the lenders.  The Amended Credit Agreement provides for a $200.0 million senior secured revolving credit facility and a $100.0 million senior secured term loan facility (collectively, the “Facilities”), with an option to request increases in the amounts of such credit facilities by up to an additional $50.0 million in the aggregate (any such increase to be in each lender’s sole discretion), and matures on March 3, 2020.  The $100.0 million term loan facility of the Amended Credit Agreement was fully drawn at closing, and $72.3 million was used to repay the outstanding balance under the Original Credit Agreement.  During the three months ended December 31, 2015, the Company drew $15 million and $18 million against the revolving credit facility.  These balances are not due until March 2020, and accordingly are classified as long-term debt.  As of December 31, 2015, $92.5 million was outstanding on the term loan and $33 million on the revolver.  As of December 31, 2015, the interest rate on the term loan was 2.10%.  As of December 31, 2015, the interest rate for the $15 million revolver draw was 1.85% and will reset on February 8, 2016.  Additionally, the interest rate for the $18 million revolver draw was 1.91% and will reset on February 16, 2016.  The interest rates on the revolving and term loans fluctuate as described below.  Subsequent to December 31, 2015, the Company drew an additional $33 million on the revolver.

- removed (2016-05-05):
[0001511737-16-000032:note_history:32]
Revolving and term loans bear interest, at the Company’s option, at either (i) a floating rate per annum equal to the base rate plus a margin of between 0.50% and 1.25%, depending on the Company’s leverage ratio as of the most recently ended fiscal quarter or (ii) a floating per annum rate equal to the applicable LIBOR rate for a specified period, plus a margin of between 1.50% and 2.25%, depending on the Company’s leverage ratio as of the most recently ended fiscal quarter. Swingline loans bear interest at a floating rate per annum equal to the base rate plus a margin of between 0.50% and 1.25%, depending on the Company’s leverage ratio as of the most recently ended fiscal quarter. Base rate is defined as the greatest of (A) Wells Fargo’s prime rate, (B) the federal funds rate plus 0.50% or (C) the applicable LIBOR rate for a period of one month plus 1.00%. A default interest rate shall apply on all obligations during certain events of default under the Amended Credit Agreement at a rate per annum equal to 2.00% above the applicable interest rate. The Company will pay to each lender a facility fee on a quarterly basis based on the unused amount of each lender’s commitment to make revolving loans, of between 0.20% and 0.35%, depending on the Company’s leverage ratio as of the most recently ended fiscal quarter. The Company will also pay to the applicable lenders on a quarterly basis certain fees based on the daily amount available to be drawn under each outstanding letter of credit, including aggregate letter of credit commissions of the LIBOR rate plus a margin of between 1.50% and 2.25%, depending on the Company’s leverage ratio as of the most recently ended fiscal quarter, and issuance fees of 0.125% per annum. The Company is also obligated to pay Wells Fargo, as agent, fees customary for a credit facility of this size and type.

- removed (2016-05-05):
[0001511737-16-000032:note_history:33]
The Amended Credit Agreement requires the Company to maintain during the term of the Facilities (i) a maximum leverage ratio of 2.50 to 1.00 and (ii) minimum liquidity of $225.0 million, increasing to $250.0 million in the event of an incremental increase in the size of the Facilities, which can be satisfied with unrestricted cash and cash equivalents and up to $50.0 million of availability under the revolving credit facility. In addition, the Amended Credit Agreement contains customary affirmative and negative covenants, including covenants that limit or restrict the ability of the Company and its subsidiaries to, among other things, grant liens or enter into agreements restricting their ability to grant liens on property, enter into mergers, dispose of assets, change their accounting or reporting policies, change their business and incur indebtedness, in each case subject to customary exceptions for a credit facility of this size and type. The Amended Credit Agreement includes customary events of default that include, among other things, non-payment of principal, interest or fees, inaccuracy of representations and warranties, violation of covenants, cross default to certain other indebtedness, bankruptcy and insolvency events, material judgments, change of control and certain ERISA events. The occurrence of an event of default could result in the acceleration of the obligations under the Amended Credit Agreement.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: no_prior_note, score: 0.0

- added (2016-05-05):
[0001511737-16-000037:note_history:34]
The table below shows the respective interest rates as of March 31, 2016 in addition to interest rate reset dates and rates as available for each revolver draw.

- added (2016-05-05):
[0001511737-16-000037:note_history:35]
|  |  | Interest Rate as of |  |  |  |  |
| Debt Payment Obligations |  | March 31, 2016 |  | Rate Reset Date |  | Reset Rate |
| $15 Million Revolver |  | 2.02% |  | April 8, 2016 |  | 2.13% |
| $18 Million Revolver |  | 2.01% |  | April 18, 2016 |  | 2.13% |
| $14 Million Revolver |  | 2.02% |  | May 31, 2016 |  | * |
| $19 Million Revolver |  | 2.02% |  | April 1, 2016 |  | 2.13% |

- added (2016-05-05):
[0001511737-16-000037:note_history:36]
* - Reset rate not available as of filing date.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2016-05-05):
[0001511737-16-000037:note_history:37]
The following table summarizes our estimated debt and interest payment obligations as of March 31, 2016, for the remainder of fiscal 2016 and future fiscal years (in thousands):
  (was, 2016-02-04, similarity 0.9735):
[0001511737-16-000032:note_history:37]
The following table summarizes our estimated debt and interest payment obligations as of December 31, 2015, for the remainder of fiscal 2016 and future fiscal years (in thousands):

- changed (2016-05-05):
[0001511737-16-000037:note_history:38]
|  | 2016 (remainder) |  | 2017 |  | 2018 |  | 2019 |  | 2020 |  | Thereafter |  | Total |
| Debt payment obligations | $ | 2,500 |  |  | $ | 11,250 |  |  | $ | 15,000 |  |  | $ | 15,000 |  |  | $ | 112,250 |  |  | $ | — |  |  | $ | 156,000 |  |
| Interest and other payments on debt (1) | 888 |  |  | 3,422 |  |  | 3,142 |  |  | 2,822 |  |  | 1,746 |  |  | — |  |  | 12,020 |  |
| Total | $ | 3,388 |  |  | $ | 14,672 |  |  | $ | 18,142 |  |  | $ | 17,822 |  |  | $ | 113,996 |  |  | $ | — |  |  | $ | 168,020 |  |
  (was, 2016-02-04, similarity 0.9946):
[0001511737-16-000032:note_history:38]
|  | 2016 (remainder) |  | 2017 |  | 2018 |  | 2019 |  | 2020 |  | Thereafter |  | Total |
| Debt payment obligations | $ | 5,000 |  |  | $ | 11,250 |  |  | $ | 15,000 |  |  | $ | 15,000 |  |  | $ | 79,250 |  |  | $ | — |  |  | $ | 125,500 |  |
| Interest and other payments on debt | 1,439 |  |  | 2,718 |  |  | 2,442 |  |  | 2,127 |  |  | 1,313 |  |  | — |  |  | 10,039 |  |
| Total | $ | 6,439 |  |  | $ | 13,968 |  |  | $ | 17,442 |  |  | $ | 17,127 |  |  | $ | 80,563 |  |  | $ | — |  |  | $ | 135,539 |  |

- added (2016-05-05):
[0001511737-16-000037:note_history:39]
(1) - Interest payments are calculated based on the applicable rates and payment dates as of March 31, 2016. Furthermore, two to three month payment intervals on the revolving debt have been assumed, consistent with the Company's elections to date.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2016-05-05):
[0001511737-16-000037:note_history:40]
On November 13, 2013, the Company entered into an aircraft lease agreement (the “Aircraft Lease Agreement”) with RJP Manageco LLC (the “Lessor”), a limited liability company owned by the Company’s CEO, Robert J. Pera. Pursuant to the Aircraft Lease Agreement, the Company may lease an aircraft owned by the Lessor for Company business purposes. Under the Aircraft Lease Agreement, the aircraft may be leased at a rate of $5,000 per flight hour. This hourly rate does not include the cost of flight crew or on-board services, which the Company purchases from a third-party provider. The Company recognized a total of approximately $373 thousand and $980 thousand in expenses pursuant to the Aircraft Lease Agreement during the three and nine months ended March 31, 2016, respectively.  In comparison, the Company recognized a total of approximately $150 thousand and $330 thousand in expenses pursuant to the Aircraft Lease Agreement during the three and nine months ended March 31, 2015, respectively. All expenses pursuant to the Aircraft Lease Agreement have been included in the Company’s sales, general and administrative expenses in the Condensed Consolidated Statements of Operations.
  (was, 2016-02-04, similarity 0.9587):
[0001511737-16-000032:note_history:40]
On November 13, 2013, the Company entered into an aircraft lease agreement (the “Aircraft Lease Agreement”) with RJP Manageco LLC (the “Lessor”), a limited liability company owned by the Company’s CEO, Robert J. Pera. Pursuant to the Aircraft Lease Agreement, the Company may lease an aircraft owned by the Lessor for Company business purposes. Under the Aircraft Lease Agreement, the aircraft may be leased at a rate of $5,000 per flight hour. This hourly rate does not include the cost of flight crew or on-board services, which the Company purchases from a third-party provider. The Company recognized a total of approximately $394 thousand and $607 thousand in expenses pursuant to the Aircraft Lease Agreement during the three and six months ended December 31, 2015, respectively.  In comparison, the Company recognized a total of approximately $29 thousand and $180 thousand in expenses pursuant to the Aircraft Lease Agreement during the three and six months ended December 31, 2014, respectively. All expenses pursuant to the Aircraft Lease Agreement have been included in the Company’s sales, general and administrative expenses in the Condensed Consolidated Statements of Operations.
