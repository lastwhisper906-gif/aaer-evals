# UI note change history — 0001511737-14-000009 → 0001511737-14-000018


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2014-05-09):
[0001511737-14-000018:note_history:1]
At March 31, 2014, future minimum annual payments under operating leases for the remainder of fiscal 2014 and future fiscal years are as follows (in thousands):
  (was, 2014-02-07, similarity 0.9705):
[0001511737-14-000009:note_history:1]
At December 31, 2013, future minimum annual payments under operating leases for the remainder of fiscal 2014 and future fiscal years are as follows (in thousands):

- changed (2014-05-09):
[0001511737-14-000018:note_history:2]
The Company subcontracts with other companies to manufacture its products. During the normal course of business, the Company’s contract manufacturers procure components based upon orders placed by the Company. If the Company cancels all or part of the orders, it may still be liable to the contract manufacturers for the cost of the components purchased by them to manufacture the Company’s products. The Company periodically reviews the potential liability and to date no significant accruals have been recorded.  The Company had $20.9 million in non-cancelable purchase commitments as of March 31, 2014, the related expenses of which are expected to be incurred in future periods.  The Company did not have any non-cancelable purchase commitments as of June 30, 2013.
  (was, 2014-02-07, similarity 0.8111):
[0001511737-14-000009:note_history:2]
The Company subcontracts with other companies to manufacture its products. During the normal course of business, the Company’s contract manufacturers procure components based upon orders placed by the Company. If the Company cancels all or part of the orders, it may still be liable to the contract manufacturers for the cost of the components purchased by them to manufacture the Company’s products. The Company periodically reviews the potential liability and to date no significant accruals have been recorded.

- added (2014-05-09):
[0001511737-14-000018:note_history:3]
In May 2011, the Company filed a self-disclosure statement with the U.S. Commerce Department, Bureau of Industry and Security’s (“BIS”) Office of Export Enforcement (“OEE”) relating to a review conducted by the Company regarding certain export transactions from 2008 through March 2011 in which products may have been later resold into Iran by third parties. In June 2011, the Company also filed a self-disclosure statement with the U.S. Department of the Treasury’s Office of Foreign Asset Control (“OFAC”) regarding these compliance issues. In August 2011, the Company received a warning letter from OEE stating that OEE had not referred the findings of the Company’s review for criminal or administrative prosecution and closed the investigation of the Company without penalty. Based upon its review of the matter, OFAC identified certain apparent violations (“Apparent Violations”) of the Iranian Transactions and Sanctions Regulations by the Company during the period of in or about March 2008 through in or about February 2011. On March 4, 2014, the Company entered into a settlement agreement with OFAC resolving this administrative matter. Pursuant to the terms of the settlement agreement, the Company agreed to make a one-time payment to the U.S. Department of the Treasury in the amount of $504,000 in consideration of OFAC agreeing to release and forever discharge the Company from any and all civil liability in connection with the Apparent Violations. The Company previously accrued a reserve of $1.6 million relating to this matter in fiscal 2010 and, accordingly, reversed the excess of the accrual of $1.1 million as of the effective date of the settlement agreement.

- added (2014-05-09):
[0001511737-14-000018:note_history:4]
Beginning on September 7, 2012, two class action lawsuits were filed in the United States District Court for the Northern District of California against Ubiquiti Networks, Inc. (the “Company”), certain of its officers and directors, and the underwriters of its initial public offering, alleging claims under U.S. securities laws. On January 30, 2013, the plaintiffs filed an amended consolidated complaint. The Company filed a motion to dismiss the complaint, and on March 26, 2014, the court issued an order granting the motion to dismiss with leave to amend the complaint. Following the plaintiffs’ decision not to file an amended complaint, on April 16, 2014 the court ordered the dismissal of the shareholder class action lawsuit with prejudice, and entered judgment in favor of the Company and the other defendants, and against the plaintiffs. The plaintiffs may appeal the court’s decision.

- removed (2014-05-09):
[0001511737-14-000009:note_history:5]
In January 2011, the U.S. Commerce Department, Bureau of Industry and Security’s (“BIS”) Office of Export Enforcement (“OEE”) contacted the Company to request that the Company provide information related to its relationship with a logistics company in the United Arab Emirates (“UAE”) and with a company in Iran, as well as information on the export classification of its products. As a result of this inquiry the Company, assisted by outside counsel, conducted a review of the Company's export transactions from 2008 through March 2011 to not only gather information responsive to the OEE's request but also to review the Company's overall compliance with export control and sanctions laws.  The Company believes its products have been sold into Iran by third parties. The Company does not believe that it directly sold, exported or shipped its products into Iran or any other country subject to a U.S. embargo. However, until early 2010, the Company did not prohibit its distributors from selling its products into Iran or any other country subject to a U.S. embargo. In the course of this review the Company identified that two distributors may have sold the Company's products into Iran. The Company's review also found that while it had obtained required Commodity Classification Rulings for its products in June 2010 and November 2010, the Company did not advise its shipping personnel to change the export authorizations used on its shipping documents until February 2011. During the course of the Company's export control review, the Company also determined that it had failed to maintain adequate records for the five year period required by the Export Administration Regulations (the "EAR") and the sanctions regulations due to its lack of infrastructure and because it was prior to its transition to its current system of record, NetSuite.

- removed (2014-05-09):
[0001511737-14-000009:note_history:6]
In May 2011, the Company filed a self-disclosure statement with the BIS and OEE.  In June 2011, the Company filed a self-disclosure statement with the U.S. Department of the Treasury’s Office of Foreign Asset Control (“OFAC”) regarding the compliance issues noted above. The disclosures address the above described findings and the remedial actions the Company had taken to date. However, the findings also indicate that both distributors continued to sell, directly or indirectly, the Company’s products into Iran during the period from February 2010 through March 2011 and that the Company received various communications from them indicating that they were continuing to do so. Since January 2011, the Company has cooperated with OEE and, prior to its disclosure filing, the Company informally shared with the OEE the substance of its findings with respect to both distributors. From May 2011 to August 2011, the Company provided additional information regarding its review and its findings to OEE to facilitate its investigation and OEE advised the Company in August 2011 that it had completed its investigation of the Company. In August 2011, the Company received a warning letter from OEE stating that OEE had not referred the findings of the Company’s review for criminal or administrative prosecution and closed the investigation of the Company without penalty.

- removed (2014-05-09):
[0001511737-14-000009:note_history:7]
OFAC is still reviewing the Company’s disclosure. In the Company’s submission, the Company provided OFAC with an explanation of the activities that led to the sales of its products in Iran and the failure to comply with the EAR and OFAC sanctions. Although the Company’s OFAC and OEE disclosures covered similar sets of facts, which led the OEE to resolve the case with the issuance of a warning letter, OFAC may conclude that the Company’s actions resulted in violations of U.S. export control and economic sanctions laws and warrant the imposition of penalties that could include fines, termination of the Company’s ability to export its products, and/or referral for criminal prosecution. The penalties may be imposed against the Company and/or its management. The maximum civil monetary penalty for the violations is up to $250,000 or twice the value of the transaction, whichever is greater, per violation. Any such fines or restrictions may be material to the Company’s financial results in the period in which they are imposed.  The Company cannot predict when OFAC will complete its review or decide upon the imposition of possible penalties.

- removed (2014-05-09):
[0001511737-14-000009:note_history:8]
The Company has taken actions designed to ensure that export classification information is distributed to the appropriate personnel in a timely manner, and has adopted policies and procedures to promote its compliance with applicable export laws and regulations, including obtaining written distribution agreements with substantially all of its distributors that contain covenants requiring compliance with U.S. export control and economic sanctions law, notifying all of its distributors of their obligations and obtaining updated distribution agreements from distributors that accounted for approximately 99% of its revenue in fiscal 2013.  However the Company cannot be sure such actions will be effective.  Additionally, the Company's failure to amend all its distribution agreements and to implement more robust compliance controls immediately after the discovery of Iran-related sales activity in early 2010 may be aggravating factors that could impact the imposition of penalties imposed on the Company or its management.  Based on the facts known to the Company to date, the Company recorded an expense of $1.6 million for this export compliance matter in fiscal 2010, which represents management’s estimated exposure for fines in accordance with applicable accounting literature. This amount was calculated from information discovered through the Company’s internal review and this loss is deemed to be probable and reasonably estimable. However, the Company also believes that it is reasonably possible that the loss may be higher, but the Company cannot reasonably estimate the range of any further potential losses. Should additional facts be discovered in the future and/or should actual fines or other penalties substantially differ from the Company’s estimates, its business, financial condition, cash flows and results of operations may be materially negatively impacted.

- removed (2014-05-09):
[0001511737-14-000009:note_history:9]
Beginning on September 7, 2012, two shareholder class action complaints were filed against the Company, certain of its officers and directors and the underwriters of the Company's initial public offering in the United States District Court for the Northern District of California. On January 30, 2013, the plaintiffs filed an Amended Consolidated Complaint, which alleges claims under the Securities Act of 1933, the Securities Exchange Act of 1934 and SEC Rule 10b-5 on behalf of a purported class of those who purchased the Company's common stock between October 14, 2011 and August 9, 2012 and/or acquired the Company's stock pursuant to or traceable to the registration statement for the initial public offering. The Amended Consolidated Complaint alleges that the defendants violated the federal securities laws by issuing false or misleading statements regarding the sale of counterfeit Company products.  The consolidated complaint seeks, among other things, damages and interest, rescission, and attorneys' fees and costs. On March 26, 2013, the Company filed a motion to dismiss the complaint.  On August 27, 2013, the court held a hearing on the motion to dismiss, and its decision is pending.

- removed (2014-05-09):
[0001511737-14-000009:note_history:10]
The Company believes that the allegations in the consolidated complaint are without merit and intend to vigorously contest the litigation. However, there can be no assurance that the Company will be successful in its defense. Because the case is at a very early stage, the Company cannot say that a loss is probable and cannot currently reasonably estimate the loss or the range of possible losses that may be experienced in connection with this litigation.


## us-gaap:BusinessDescriptionAndBasisOfPresentationTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2014-05-09):
[0001511737-14-000018:note_history:11]
On October 13, 2011, the Company entered into an underwriting agreement for its initial public offering of 7,038,230 shares of its common stock at $15.00 per share.  The Company's initial public offering closed on October 19, 2011. Immediately prior to the closing of the initial public offering, all outstanding shares of the Company’s preferred stock converted to common stock on a one for one basis.
  (was, 2014-02-07, similarity 0.9783):
[0001511737-14-000009:note_history:11]
On October 13, 2011, the Company entered into an underwriting agreement for its initial public offering of common stock at $15.00 per share.  The Company's initial public offering closed on October 19, 2011. Immediately prior to the closing of the initial public offering, all outstanding shares of the Company’s preferred stock converted to common stock on a one for one basis.

- changed (2014-05-09):
[0001511737-14-000018:note_history:12]
These condensed consolidated financial statements should be read in conjunction with the Company’s audited consolidated financial statements for the fiscal year ended June 30, 2013 included in its Annual Report on Form 10-K, as filed on September 13, 2013 with the SEC (the “Annual Report”). The results of operations for the three and nine months ended March 31, 2014 are not necessarily indicative of the results to be expected for any future periods.
  (was, 2014-02-07, similarity 0.9452):
[0001511737-14-000009:note_history:12]
These condensed consolidated financial statements should be read in conjunction with the Company’s audited consolidated financial statements for the fiscal year ended June 30, 2013 included in its Annual Report on Form 10-K, as filed on September 13, 2013 with the SEC (the “Annual Report”). The results of operations for the three and six months ended December 31, 2013 are not necessarily indicative of the results to be expected for any future periods.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2014-05-09):
[0001511737-14-000018:note_history:13]
The Company’s significant accounting policies are disclosed in its audited consolidated financial statements for the year ended June 30, 2013 included in the Annual Report.  Unless otherwise noted below, the Company's significant accounting policies have not changed since June 30, 2013.
  (was, 2014-02-07, similarity 0.7557):
[0001511737-14-000009:note_history:13]
The Company’s significant accounting policies are disclosed in its audited consolidated financial statements for the year ended June 30, 2013 included in the Annual Report.

- added (2014-05-09):
[0001511737-14-000018:note_history:14]
Advertising Costs

- added (2014-05-09):
[0001511737-14-000018:note_history:15]
The Company expenses all advertising costs as incurred. Advertising costs totaled $1.8 million and $2.4 million during the three and nine months ended March 31, 2014.  Advertising costs during the three and nine months ended March 31, 2013 were not significant.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2014-05-09):
[0001511737-14-000018:note_history:16]
The Loan Agreement contains customary affirmative and negative covenants, including covenants that limit or restrict the Company and its subsidiaries’ ability to, among other things, incur indebtedness, grant liens, merge or consolidate, dispose of assets, pay dividends or make distributions, make investments, make acquisitions, prepay certain indebtedness, change the nature of its business, enter into certain transactions with affiliates, enter into restrictive agreements, and make capital expenditures, in each case subject to customary exceptions for a credit facility of this size and type. The Company is also required to maintain a minimum debt service coverage ratio, a maximum leverage ratio, and a minimum liquidity ratio.  As of March 31, 2014, the Company was in compliance with all affirmative and negative covenants, debt service coverage ratio, leverage ratio and liquidity ratio requirements.
  (was, 2014-02-07, similarity 0.9928):
[0001511737-14-000009:note_history:16]
The Loan Agreement contains customary affirmative and negative covenants, including covenants that limit or restrict the Company and its subsidiaries’ ability to, among other things, incur indebtedness, grant liens, merge or consolidate, dispose of assets, pay dividends or make distributions, make investments, make acquisitions, prepay certain indebtedness, change the nature of its business, enter into certain transactions with affiliates, enter into restrictive agreements, and make capital expenditures, in each case subject to customary exceptions for a credit facility of this size and type. The Company is also required to maintain a minimum debt service coverage ratio, a maximum leverage ratio, and a minimum liquidity ratio.  As of December 31, 2013, the Company was in compliance with all affirmative and negative covenants, debt service coverage ratio, leverage ratio and liquidity ratio requirements.

- changed (2014-05-09):
[0001511737-14-000018:note_history:17]
During the three and nine months ended March 31, 2014, the Company made aggregate payments of $1.3 million and $3.8 million, respectively, against the loan balance.  During the three and nine months ended March 31, 2013, the Company made aggregate payments of $1.3 million and $3.1 million, respectively, against the loan balance.  As of March 31, 2014, the Company has classified $6.3 million and $66.1 million in short-term and long-term debt, respectively, on its condensed consolidated balance sheet related to the Loan Agreement.
  (was, 2014-02-07, similarity 0.892):
[0001511737-14-000009:note_history:17]
During the three and six months ended December 31, 2013, the Company made aggregate payments of $1.3 million and $2.5 million, respectively, against the loan balance.  During the three and six months ended December 31, 2012, the Company made aggregate payments of $1.3 million and $1.8 million, respectively, against the loan balance.  As of December 31, 2013, the Company has classified $5.6 million and $68.0 million in short-term and long-term debt, respectively, on its condensed consolidated balance sheet related to the Loan Agreement.

- changed (2014-05-09):
[0001511737-14-000018:note_history:18]
The following table summarizes our estimated debt and interest payment obligations as of March 31, 2014 for the remainder of fiscal 2014 and future fiscal years (in thousands):
  (was, 2014-02-07, similarity 0.9735):
[0001511737-14-000009:note_history:18]
The following table summarizes our estimated debt and interest payment obligations as of December 31, 2013 for the remainder of fiscal 2014 and future fiscal years (in thousands):

- added (2014-05-09):
[0001511737-14-000018:note_history:19]
On May 5, 2014, the Company entered into a credit agreement with Wells Fargo Bank, National Association (“Wells Fargo”), the financial institutions named as lenders therein, and Wells Fargo as administrative agent for the lenders.  In connection with the execution of the credit agreement, the Company terminated and repaid all outstanding obligations under the Term Loan Facility and Revolving Credit Facility under the Loan Agreement described above.  Please see Part 1, Item 1, Note 14 below for a full description of the credit agreement.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2014-05-09):
[0001511737-14-000018:note_history:20]
The following table summarizes our estimated debt and interest payment obligations as of March 31, 2014 for the remainder of fiscal 2014 and future fiscal years (in thousands):
  (was, 2014-02-07, similarity 0.9735):
[0001511737-14-000009:note_history:20]
The following table summarizes our estimated debt and interest payment obligations as of December 31, 2013 for the remainder of fiscal 2014 and future fiscal years (in thousands):


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2014-05-09):
[0001511737-14-000018:note_history:21]
On November 13, 2013, the Company entered into an aircraft lease agreement (the "Aircraft Lease Agreement") with RJP Manageco LLC (the "Lessor"), a limited liability company owned by the Company’s CEO, Robert J. Pera. Pursuant to the Aircraft Lease Agreement, the Company may lease an aircraft owned by the Lessor for Company business purposes. Under the Aircraft Lease Agreement, the aircraft may be leased at a rate of $5,000 per flight hour. This hourly rate does not include the cost of flight crew or on-board services, which the Company will purchase from a third-party provider. The Company recognized a total of approximately $120,000 in expenses pursuant to the Aircraft Lease Agreement during the three months ended March 31, 2014.  All expenses pursuant to the Aircraft Lease Agreement have been included in the Company's sales, general and administrative expenses in the Condensed Consolidated Statements of Operations.
  (was, 2014-02-07, similarity 0.7585):
[0001511737-14-000009:note_history:21]
On November 13, 2013, the Company entered into an aircraft lease agreement (the "Aircraft Lease Agreement") with RJP Manageco LLC (the "Lessor"), a limited liability company owned by the Company’s CEO, Robert J. Pera. Pursuant to the Aircraft Lease Agreement, the Company may lease an aircraft owned by the Lessor for Company business purposes. Under the Aircraft Lease Agreement, the aircraft may be leased at a rate of $5,000 per flight hour. This hourly rate does not include the cost of flight crew or on-board services, which the Company will purchase from a third-party provider. Expenses incurred will be included in the Company's sales, general and administrative expenses under its Consolidated Statements of Operations.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_prior_note, score: 0.0

- added (2014-05-09):
[0001511737-14-000018:note_history:22]
SUBSEQUENT EVENTS

- added (2014-05-09):
[0001511737-14-000018:note_history:23]
On May 5, 2014, the Company and certain of its subsidiaries entered into a credit agreement (the “Credit Agreement”) with Wells Fargo Bank, National Association (“Wells Fargo”), the financial institutions named as lenders therein, and Wells Fargo as administrative agent for the lenders, that provides for a $150 million senior secured revolving credit facility, with an option to request an increase in the amount of the credit facility by up to an additional $50 million (any such increase to be in each lender’s sole discretion).  The Company may borrow up to $110 million of the facility as a U.S. sublimit.  The entire amount of the facility is available to Ubiquiti International Holding Company Limited, a wholly-owned subsidiary of the Company organized under the laws of the Cayman Islands.  The credit facility includes a sub-limit of $5 million for letters of credit and a sub-limit of $15 million for swingline loans.   In connection with the execution of the Credit Agreement, the Company terminated the $50 million line of credit facility under the Loan Agreement described in Note 7, “Debt”.  Under the Credit Agreement, revolving loans and swingline loans may be borrowed, repaid and reborrowed until May 5, 2019, at which time all amounts borrowed must be repaid.   Additionally, $72.3 million is currently outstanding under the Credit Agreement, which was borrowed by the Company to repay obligations under the Loan Agreement and to pay transaction fees and costs.  Revolving loans bear interest, at the Company’s option, at either (i) a floating rate per annum equal to the base rate plus a margin of between 0.250% and 1.000%, depending on the Company’s leverage ratio as of the most recently ended fiscal quarter or (ii) a per annum rate equal to the applicable LIBOR rate for a specified period, plus a margin of between 1.250% and 2.000%, depending on the Company’s leverage ratio as of the most recently ended fiscal quarter.  Swingline loans will bear interest at a floating rate per annum equal to the base rate plus a margin of between 0.250% and 1.000%, depending on the Company’s leverage ratio as of the most recently ended fiscal quarter.   Base rate is defined as the greatest of (A) Wells Fargo’s prime rate, (B) the federal funds rate plus 0.500% or (C) a per annum rate equal to the rate at which dollar deposits are offered in the London interbank market for a period of one month plus 1.000%.  A default interest rate shall apply on all obligations during a payment event of default under the Credit Agreement at a rate per annum equal to 2.000% above the applicable interest rate. The Company will pay to each lender a facility fee on a quarterly basis based on the unused amount of each lender’s commitment to make loans, of between 0.200% and 0.350%, depending on the Company’s leverage ratio as of the most recently ended fiscal quarter.  Revolving loans and swingline loans may be prepaid at any time without penalty.  The Company is also obligated to pay Wells Fargo, as agent, fees customary for a credit facility of this size and type.

- added (2014-05-09):
[0001511737-14-000018:note_history:24]
The Credit Agreement requires the Company to maintain a maximum leverage ratio and a minimum interest coverage ratio during the term of the credit facility.  In addition, the Credit Agreement contains customary affirmative and negative covenants, including covenants that limit or restrict the ability of the Company and its subsidiaries to, among other things, grant liens or enter into agreements restricting their ability to grant liens on property, enter into mergers, dispose of assets, change their accounting or reporting policies, change their business and incur subsidiary indebtedness, in each case subject to customary exceptions for a credit facility of this size and type.  The Credit Agreement includes customary events of default that, include among other things, non-payment of principal, interest or fees, inaccuracy of representations and warranties, violation of covenants, cross default to certain other indebtedness, bankruptcy and insolvency events, material judgments, change of control and certain ERISA events. The occurrence of an event of default could result in the acceleration of the obligations under the Credit Agreement.  The credit facility under the Credit Agreement expires May 5, 2019.

- added (2014-05-09):
[0001511737-14-000018:note_history:25]
The obligations of the Company and its subsidiaries under the Credit Agreement are collateralized by substantially all assets (excluding intellectual property) of the Company and its subsidiaries.

- added (2014-05-09):
[0001511737-14-000018:note_history:26]
Wells Fargo and the lenders party to the Credit Agreement, and certain of their respective affiliates, have provided, and in the future may provide, financial, banking and related services to the Company. These parties have received, and in the future may receive, compensation from the Company for these services.
