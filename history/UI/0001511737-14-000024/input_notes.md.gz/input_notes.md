# UI notes — 0001511737-14-000024


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0001511737-14-000024:notes:1]
SUPPLEMENTARY DATA (UNAUDITED)

[0001511737-14-000024:notes:2]
The following table presents the Company’s unaudited consolidated statements of operations data for each of the eight quarters during fiscal 2014 and 2013. In management’s opinion, this information has been presented on the same basis as the audited consolidated financial statements included in a separate section of this report, and all necessary adjustments, consisting only of normal recurring adjustments, have been included in the amounts below to state fairly the unaudited quarterly results when read in conjunction with the audited consolidated financial statements and related notes. The operating results for any quarter should not be relied upon as necessarily indicative of results for any future period.

[0001511737-14-000024:notes:3]
|  |  | Fiscal 2014 |
| In thousands, except per share data |  | FirstQuarter |  | SecondQuarter |  | ThirdQuarter |  | FourthQuarter |
| Net revenue |  | $ | 129,687 |  |  | $ | 138,439 |  |  | $ | 148,331 |  |  | $ | 156,007 |  |
| Gross profit |  | 58,023 |  |  | 60,971 |  |  | 65,612 |  |  | 68,861 |  |
| Income from operations |  | 45,896 |  |  | 47,120 |  |  | 50,135 |  |  | 52,794 |  |
| Net income and comprehensive income |  | 40,528 |  |  | 41,792 |  |  | 45,199 |  |  | 49,418 |  |
| Net income per share of common stock: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.46 |  |  | $ | 0.48 |  |  | $ | 0.51 |  |  | $ | 0.56 |  |
| Diluted |  | $ | 0.45 |  |  | $ | 0.47 |  |  | $ | 0.50 |  |  | $ | 0.55 |  |
|  |  | Fiscal 2013 |
|  |  | FirstQuarter |  | SecondQuarter |  | ThirdQuarter |  | FourthQuarter |
| Net revenue |  | $ | 61,535 |  |  | $ | 74,901 |  |  | $ | 83,155 |  |  | $ | 101,232 |  |
| Gross profit |  | 25,020 |  |  | 30,485 |  |  | 35,465 |  |  | 44,364 |  |
| Income from operations |  | 15,775 |  |  | 20,119 |  |  | 23,503 |  |  | 33,207 |  |
| Net income and comprehensive income |  | 13,179 |  |  | 17,803 |  |  | 20,667 |  |  | 28,841 |  |
| Net income per share of common stock: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.14 |  |  | $ | 0.20 |  |  | $ | 0.24 |  |  | $ | 0.33 |  |
| Diluted |  | $ | 0.14 |  |  | $ | 0.20 |  |  | $ | 0.23 |  |  | $ | 0.32 |  |


## us-gaap:BusinessDescriptionAndBasisOfPresentationTextBlock

[0001511737-14-000024:notes:4]
BUSINESS AND BASIS OF PRESENTATION

[0001511737-14-000024:notes:5]
Business— Ubiquiti Networks, Inc. was incorporated in the State of California in 2003 as Pera Networks, Inc.  In 2005 the Company changed its name to Ubiquiti Networks, Inc. and commenced its current operations. In June 2010, the Company was re-incorporated in Delaware.

[0001511737-14-000024:notes:6]
Ubiquiti Networks, Inc. and its wholly owned subsidiaries (collectively, “Ubiquiti” or the “Company”) is a product driven company that leverages innovative proprietary technologies to deliver networking solutions to both startup and established network operators and service providers.

[0001511737-14-000024:notes:7]
On October 13, 2011, the Company entered into an underwriting agreement for its initial public offering of common stock at $15.00 per share.  The Company's initial public offering closed on October 19, 2011. Immediately prior to the closing of the initial public offering, all outstanding shares of the Company’s preferred stock converted to common stock on a one for one basis.

[0001511737-14-000024:notes:8]
On June 18, 2013, the Company completed a secondary offering of 7,031,464 shares of common stock at an offering price of $16.00 per share, which included 531,464 shares sold in connection with the partial exercise of the option to purchase additional shares granted to the underwriters.  All of the shares sold in the offering were sold by existing stockholders of the Company, including entities affiliated with Summit Partners, L.P., and the Company's chief executive officer, Robert J. Pera.  No shares were sold by the Company in the offering, and as such, the Company did not receive any proceeds from the offering.

[0001511737-14-000024:notes:9]
The Company operates on a fiscal year ending June 30. In these notes, Ubiquiti refers to the fiscal years ended June 30, 2014, 2013 and 2012 as fiscal 2014, fiscal 2013 and fiscal 2012, respectively.

[0001511737-14-000024:notes:10]
Basis of Presentation— The Company’s consolidated financial statements and accompanying notes are prepared in accordance with accounting principles generally accepted in the United States of America (“GAAP”) and include the accounts of Ubiquiti and its wholly owned subsidiaries. The Company has wholly owned subsidiaries in Lithuania, Hong Kong, China and Poland. The Company’s Hong Kong subsidiary also operates a branch office in Taiwan. All intercompany transactions and balances have been eliminated.


## us-gaap:CashAndCashEquivalentsPolicyTextBlock

[0001511737-14-000024:notes:11]
Cash and Cash Equivalents

[0001511737-14-000024:notes:12]
The Company considers investments purchased with a maturity period of three months or less at the date of purchase to be cash equivalents.  Cash and cash equivalents are stated at cost which approximates fair value. The Company deposits cash and cash equivalents with financial institutions that management believes are of high credit quality. The Company’s cash and cash equivalents consist primarily of cash deposited in U.S. dollar denominated interest-bearing deposit accounts.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001511737-14-000024:notes:13]
COMMITMENTS AND CONTINGENCIES

[0001511737-14-000024:notes:14]
Operating Leases

[0001511737-14-000024:notes:15]
The Company leases its headquarters in San Jose, California and other locations worldwide under non-cancelable operating leases that expire at various dates through 2019.

[0001511737-14-000024:notes:16]
At June 30, 2014, future minimum annual payments under operating leases are as follows (in thousands):

[0001511737-14-000024:notes:17]
|  | 2015 |  | 2016 |  | 2017 |  | 2018 |  | 2019 |  | Thereafter |  | Total |
| Operating leases | $ | 2,947 |  |  | $ | 2,950 |  |  | $ | 1,611 |  |  | $ | 342 |  |  | $ | 53 |  |  | $ | — |  |  | $ | 7,903 |  |

[0001511737-14-000024:notes:18]
Rent expense under operating leases was $2.3 million, $1.7 million and $1.6 million for fiscal 2014, fiscal 2013 and fiscal 2012, respectively.

[0001511737-14-000024:notes:19]
Purchase Commitments

[0001511737-14-000024:notes:20]
The Company subcontracts with other companies to manufacture its products. During the normal course of business, the Company’s contract manufacturers procure components based upon orders placed by the Company. If the Company cancels all or part of the orders, it may still be liable to the contract manufacturers for the cost of the components purchased by them to manufacture the Company’s products. The Company periodically reviews the potential liability and to date no significant accruals have been recorded.  The Company had $20.9 million in non-cancelable purchase commitments as of June 30, 2014, the related expenses of which are expected to be incurred in future periods.

[0001511737-14-000024:notes:21]
Indemnification Obligations

[0001511737-14-000024:notes:22]
The Company enters into standard indemnification agreements with many of its business partners in the ordinary course of business. These agreements include provisions for indemnifying the business partner against any claim brought by a third party to the extent any such claim alleges that a Company product infringes a patent, copyright or trademark, or violates any other proprietary rights of that third party. The maximum potential amount of future payments the Company could be required to make under these indemnification agreements is not estimable and the Company has not incurred any material costs to defend lawsuits or settle claims related to these indemnification agreements to date.

[0001511737-14-000024:notes:23]
Legal Matters

[0001511737-14-000024:notes:24]
The Company may be involved, from time to time, in a variety of claims, lawsuits, investigations, and proceedings relating to contractual disputes, intellectual property rights, employment matters, regulatory compliance matters and other litigation matters relating to various claims that arise in the normal course of business. The Company determines whether an estimated loss from a contingency should be accrued by assessing whether a loss is deemed probable and can be reasonably estimated. The Company assesses its potential liability by analyzing specific litigation and regulatory matters using available information. The Company develops its views on estimated losses in consultation with inside and outside counsel, which involves a subjective analysis of potential results and outcomes, assuming various combinations of appropriate litigation and settlement strategies. Taking all of the above factors into account, the Company records an amount where it is probable that the Company will incur a loss and where that loss can be reasonably estimated. However, the Company’s estimates may be incorrect and the Company could ultimately incur more or less than the amounts initially recorded.  The Company may also incur significant legal fees, which are expensed as incurred, in defending against these claims.

[0001511737-14-000024:notes:25]
Export Compliance Matters

[0001511737-14-000024:notes:26]
In May 2011, the Company filed a self-disclosure statement with the U.S. Commerce Department, Bureau of Industry and Security’s (“BIS”) Office of Export Enforcement (“OEE”) relating to a review conducted by the Company regarding certain export transactions from 2008 through March 2011 in which products may have been later resold into Iran by third parties. In June 2011, the Company also filed a self-disclosure statement with the U.S. Department of the Treasury’s Office of Foreign Asset Control (“OFAC”) regarding these compliance issues. In August 2011, the Company received a warning letter from OEE stating that OEE had not referred the findings of the Company’s review for criminal or administrative prosecution and closed the investigation of the Company without penalty. Based upon its review of the matter, OFAC identified certain apparent violations (“Apparent Violations”) of the Iranian Transactions and Sanctions Regulations by the Company during the period of in or about March 2008 through in or about February 2011. On March 4, 2014, the Company entered into a settlement agreement with OFAC resolving this administrative matter. Pursuant to the terms of the settlement agreement, the Company agreed to make a one-time payment to the U.S. Department of the Treasury in the amount of $504,000 in consideration of OFAC agreeing to release and forever discharge the Company from any and all civil liability in connection with the Apparent Violations. The Company previously accrued a reserve of $1.6 million relating to this matter in fiscal 2010 and, accordingly, reversed the excess of the accrual of $1.1 million as of the effective date of the settlement agreement.

[0001511737-14-000024:notes:27]
Shareholder Class Action Lawsuits

[0001511737-14-000024:notes:28]
Beginning on September 7, 2012, two class action lawsuits were filed in the United States District Court for the Northern District of California against Ubiquiti Networks, Inc. (the “Company”), certain of its officers and directors, and the underwriters of its initial public offering, alleging claims under U.S. securities laws. On January 30, 2013, the plaintiffs filed an amended consolidated complaint. The Company filed a motion to dismiss the complaint, and on March 26, 2014, the court issued an order granting the motion to dismiss with leave to amend the complaint. Following the plaintiffs’ decision not to file an amended complaint, on April 16, 2014 the court ordered the dismissal of the shareholder class action lawsuit with prejudice, and entered judgment in favor of the Company and the other defendants, and against the plaintiffs. On May 15, 2014, the plaintiffs filed a notice of appeal from the judgment of the court.   There can be no assurance that the Company will prevail in the appeal proceeding.  The Company cannot currently estimate the possible loss it may experience in connection with this litigation.


## us-gaap:CommitmentsAndContingenciesPolicyTextBlock

[0001511737-14-000024:notes:29]
Commitments and Contingencies

[0001511737-14-000024:notes:30]
The Company periodically evaluates all pending or threatened contingencies and any commitments, if any, that are reasonably likely to have a material adverse effect on its results of operations, financial position or cash flows. The Company assesses the probability of an adverse outcome and determines if it is remote, reasonably possible or probable. If information available prior to the issuance of the Company’s financial statements indicates that it is probable that an asset had been impaired or a liability had been incurred at the date of the Company’s financial statements, and the amount of the loss, or the range of probable loss can be reasonably estimated, then such loss is accrued and charged to operating expenses. If no accrual is made for a loss contingency because one or both of the conditions pursuant to the accounting guidance are not met, but the probability of an adverse outcome is at least reasonably possible, the Company discloses the nature of the contingency and provides an estimate of the possible loss or range of loss, or states that such an estimate cannot be made.


## us-gaap:CompensationRelatedCostsPolicyTextBlock

[0001511737-14-000024:notes:31]
Stock-based Compensation

[0001511737-14-000024:notes:32]
The Company records stock-based awards at fair value as of the grant date and recognize expense, net of forfeitures, ratably on a straight-line basis over the requisite service period, which is generally the vesting term of the awards. The Company estimates the fair value of stock option awards on the grant date using the Black-Scholes option pricing model. The determination of the fair value of a stock-based award on the date of grant using the Black-Scholes option-pricing model is affected by the Company's stock price on the date of grant as well as assumptions regarding a number of complex and subjective variables. These variables include the Company's expected stock price volatility over the expected term of the award, actual and projected employee stock option exercise behaviors, the risk-free interest rate for the expected term of the award and expected dividends. Restricted stock units are valued based on the fair value of the Company's common stock on the date of grant.  Since the Company's initial public offering on October 14, 2011, the fair value of our common stock is determined using the closing market price of the Company's common stock as of the date of grant.


## us-gaap:DebtDisclosureTextBlock

[0001511737-14-000024:notes:33]
DEBT

[0001511737-14-000024:notes:34]
In July 2011, the Company repurchased an aggregate of 12,041,700 shares of the Company’s Series A convertible preferred stock from entities affiliated with Summit Partners, L.P., one of the Company’s major stockholders, at a price of $8.97 per share for an aggregate consideration of $108.0 million. Of the aggregate purchase price, $40.0 million was paid in cash at the time of closing and the balance of the shares were paid for through the issuance of convertible subordinated promissory notes in the aggregate principal amount of $68.0 million. On September 15, 2011, $34.0 million was paid against the notes and was financed through the Company's EWB Loan Agreement (as further described below) reducing the aggregate principal amount outstanding to $34.0 million. The remainder of the notes were retired in October 2011 with the proceeds of the Company’s initial public offering and existing cash balances. The interest rate on the notes started at 5% per annum and increased by two percentage points every three months until it would have reached 9% in January 2012. The notes were prepayable without penalty prior to April 21, 2012, and were required to be paid in the event of the Company’s initial public offering or third party financing prior to April 21, 2012. The notes mature on July 21, 2021. The unpaid principal on the notes was convertible into shares of Series A preferred stock at $8.97 per share at any point after July 21, 2012. The difference between the repurchase price and the carrying value of the repurchased preferred stock on June 30, 2011 was $59.0 million. The difference was debited to available retained earnings with the remaining amount debited to additional paid-in capital and reduced the net income attributable to common stock shareholders resulting in a reduction of basic and diluted net income per share.

[0001511737-14-000024:notes:35]
On September 15, 2011, the Company entered into a Loan and Security Agreement with East West Bank, (the “EWB Loan Agreement”), which was replaced by the Loan Agreement as discussed below. The credit facilities available under the EWB Loan Agreement consisted of a $35.0 million term loan facility and a $5.0 million revolving line of credit facility. The term loan would have matured on September 15, 2016 with principal and interest to be repaid in 60 monthly installments. The Company used $34.0 million of the term loan to repay a portion of the outstanding convertible subordinated promissory notes held by entities affiliated with Summit Partners, L.P leaving $1.0 million available for borrowing under the term loan facility.

[0001511737-14-000024:notes:36]
On August 7, 2012, the Company entered into a Loan and Security Agreement (the “Loan Agreement”) with U.S. Bank, as syndication agent, and East West Bank, as administrative agent for the lenders party to the Loan Agreement. The Loan Agreement replaced the EWB Loan Agreement discussed above. The Loan Agreement provided for (i) a $50.0 million revolving credit facility, with a $5.0 million sublimit for the issuance of letters of credit and a $5.0 million sublimit for the making of swingline loan advances (the “Revolving Credit Facility”), and (ii) a $50.0 million term loan facility (the “Term Loan Facility”). The Company could request borrowings under the Revolving Credit Facility until August 7, 2015. On August 7, 2012, the Company borrowed $20.8 million under the Term Loan Facility, and no borrowings remained available for borrowing thereunder.  On November 21, 2012, the Company borrowed $10.0 million under the Revolving Credit Facility. On December 20, 2012, the Company borrowed an additional $20.0 million under the Revolving Credit Facility, and $20.0 million remained available for borrowing thereunder.

[0001511737-14-000024:notes:37]
On May 5, 2014, the Company and certain of its subsidiaries entered into a credit agreement (the “Credit Agreement”) with Wells Fargo Bank, National Association (“Wells Fargo”), the financial institutions named as lenders therein, and Wells Fargo as administrative agent for the lenders, that provides for a $150 million senior secured revolving credit facility, with an option to request an increase in the amount of the credit facility by up to an additional $50 million (any such increase to be in each lender’s sole discretion).  The Company may borrow up to $110 million of the facility as a U.S. sublimit.  The entire amount of the facility is available to Ubiquiti International Holding Company Limited, a wholly-owned subsidiary of the Company organized under the laws of the Cayman Islands.  The credit facility includes a sub-limit of $5 million for letters of credit and a sub-limit of $15 million for swingline loans.   In connection with the execution of the Credit Agreement, the Company terminated the $50 million line of credit facility under the Loan Agreement with East West Bank described above.  Under the Credit Agreement, revolving loans and swingline loans may be borrowed, repaid and reborrowed until May 5, 2019, at which time all amounts borrowed must be repaid.   Additionally, $72.3 million is currently outstanding under the Credit Agreement, which was borrowed by the Company to repay obligations under the Loan Agreement and to pay transaction fees and costs.  Revolving loans bear interest, at the Company’s option, at either (i) a floating rate per annum equal to the base rate plus a margin of between 0.250% and 1.000%, depending on the Company’s leverage ratio as of the most recently ended fiscal quarter or (ii) a per annum rate equal to the applicable LIBOR rate for a specified period, plus a margin of between 1.250% and 2.000%, depending on the Company’s leverage ratio as of the most recently ended fiscal quarter.  Swingline loans will bear interest at a floating rate per annum equal to the base rate plus a margin of between 0.250% and 1.000%, depending on the Company’s leverage ratio as of the most recently ended fiscal quarter.   Base rate is defined as the greatest of (A) Wells Fargo’s prime rate, (B) the federal funds rate plus 0.500% or (C) a per annum rate equal to the rate at which dollar deposits are offered in the London interbank market for a period of one month plus 1.000%.  A default interest rate shall apply on all obligations during a payment event of default under the Credit Agreement at a rate per annum equal to 2.000% above the applicable interest rate. The Company will pay to each lender a facility fee on a quarterly basis based on the unused amount of each lender’s commitment to make loans, of between 0.200% and 0.350%, depending on the Company’s leverage ratio as of the most recently ended fiscal quarter.  Revolving loans and swingline loans may be prepaid at any time without penalty.  The Company is also obligated to pay Wells Fargo, as agent, fees customary for a credit facility of this size and type.

[0001511737-14-000024:notes:38]
The Credit Agreement requires the Company to maintain a maximum leverage ratio and a minimum interest coverage ratio during the term of the credit facility.  In addition, the Credit Agreement contains customary affirmative and negative covenants, including covenants that limit or restrict the ability of the Company and its subsidiaries to, among other things, grant liens or enter into agreements restricting their ability to grant liens on property, enter into mergers, dispose of assets, change their accounting or reporting policies, change their business and incur subsidiary indebtedness, in each case subject to customary exceptions for a credit facility of this size and type.  The Credit Agreement includes customary events of default that, include among other things, non-payment of principal, interest or fees, inaccuracy of representations and warranties, violation of covenants, cross default to certain other indebtedness, bankruptcy and insolvency events, material judgments, change of control and certain ERISA events. The occurrence of an event of default could result in the acceleration of the obligations under the Credit Agreement.  The credit facility under the Credit Agreement expires May 5, 2019.

[0001511737-14-000024:notes:39]
The obligations of the Company and its subsidiaries under the Credit Agreement are collateralized by substantially all assets (excluding intellectual property) of the Company and its subsidiaries.

[0001511737-14-000024:notes:40]
Wells Fargo and the lenders party to the Credit Agreement, and certain of their respective affiliates, have provided, and in the future may provide, financial, banking and related services to the Company. These parties have received, and in the future may receive, compensation from the Company for these services.

[0001511737-14-000024:notes:41]
During the fiscal years 2014 and 2013, the Company made aggregate payments of $5.0 million and $4.3 million, respectively, against the Loan Agreement.  At the time the Loan Agreement was retired in May 2014, the Company paid the remaining principal balance of $71.3 million.  No payments were made for borrowings under the Credit Agreement with Wells Fargo in fiscal 2014.  As of June 30, 2014, the Company has classified $72.3 million as long-term debt on its consolidated balance sheet related to the Credit Agreement.

[0001511737-14-000024:notes:42]
The following table summarizes our estimated debt and interest payment obligations as of June 30, 2014 (in thousands):

[0001511737-14-000024:notes:43]
|  | 2015 |  | 2016 |  | 2017 |  | 2018 |  | 2019 |  | Thereafter |  | Total |
| Debt payment obligations | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 72,254 |  |  | $ | — |  |  | $ | 72,254 |  |
| Interest payments on debt payment obligations | 1,012 |  |  | 1,013 |  |  | 1,012 |  |  | 1,012 |  |  | 857 |  |  | — |  |  | 4,906 |  |
| Total | $ | 1,012 |  |  | $ | 1,013 |  |  | $ | 1,012 |  |  | $ | 1,012 |  |  | $ | 73,111 |  |  | $ | — |  |  | $ | 77,160 |  |


## us-gaap:DeferredChargesPolicyTextBlock

[0001511737-14-000024:notes:44]
Deferred Cost of Revenues

[0001511737-14-000024:notes:45]
Deferred cost of revenues consist of the cost of product shipped to distributors for which the rights and obligations of ownership have passed to the distributor but revenues have not yet been recognized primarily because the collectability criterion for revenue recognition has not been fulfilled.  The Company classifies these amounts as deferred cost of revenues. All deferred costs of revenues are stated at cost. The Company periodically assesses the recoverability of deferred cost of revenues and writes down the deferred cost of revenues balances to establish a new cost basis when recovery of deferred cost of revenues is not reasonably assured. The Company evaluates recoverability based on various factors including the length of time the product has been held at the distributor’s site and the financial viability of the distributor.


## us-gaap:DeferredCostsCapitalizedPrepaidAndOtherAssetsDisclosureTextBlock

[0001511737-14-000024:notes:46]
Prepaid expenses and other current assets consisted of the following (in thousands):

[0001511737-14-000024:notes:47]
|  | June 30, |
|  | 2014 |  | 2013 |
| Vendor deposits | $ | 8,043 |  |  | $ | — |  |
| Non-trade receivables | 292 |  |  | 2,203 |  |
| Other current assets | 4,932 |  |  | 948 |  |
|  | $ | 13,267 |  |  | $ | 3,151 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001511737-14-000024:notes:48]
STOCK BASED COMPENSATION

[0001511737-14-000024:notes:49]
Stock-Based Compensation Plans

[0001511737-14-000024:notes:50]
2010 Equity Incentive Plan

[0001511737-14-000024:notes:51]
In March 2010, the Company’s board of directors and stockholders approved the 2010 Equity Incentive Plan (the “2010 Plan”). The 2010 Plan replaced the 2005 Equity Incentive Plan (the “2005 Plan”), and no further awards will be granted pursuant to the 2005 Plan. Under the terms of the 2010 Plan, nonstatutory stock options, stock appreciation rights, restricted stock, and restricted stock units (“RSUs”) may be granted to employees or non-employee service providers. Incentive stock options may be granted only to employees.

[0001511737-14-000024:notes:52]
The maximum aggregate number of shares that may be awarded under the 2010 Plan as of June 30, 2014 was 8,000,000 shares, plus any shares subject to stock options or similar awards granted under the 2005 Plan that expire or otherwise terminate without having been exercised in full and shares issued pursuant to awards granted under the 2005 Plan that are forfeited to (but not repurchased by) the Company.

[0001511737-14-000024:notes:53]
The 2010 Plan is administered by the board of directors or a committee of the Company’s board of directors. Subject to the terms and conditions of the 2010 Plan, the administrator has the authority to select the persons to whom awards are to be made, to determine the number of shares to be subject to awards and the terms and conditions of awards, and to make all other determinations and to take all other actions necessary or advisable for the administration of the 2010 Plan. The administrator is also authorized to adopt, amend or rescind rules relating to administration of the 2010 Plan. Options and RSUs generally vest over a four year period from the date of grant and generally expire five to ten years from the date of grant. The terms of the 2010 Plan provide that an option price shall not be less than 100% of fair market value on the date of grant.

[0001511737-14-000024:notes:54]
2005 Equity Incentive Plan

[0001511737-14-000024:notes:55]
With the adoption of the 2010 Plan, no additional awards may be granted under the 2005 Plan. In February 2005, the Company’s board of directors and the stockholders approved the 2005 Plan, which was amended and restated in March 2006. The 2005 Plan provided for the issuance of stock options, restricted stock and stock bonuses to employees, consultants, advisors, directors and officers of the Company. The terms of the options granted under the 2005 Plan were determined at the time of grant. The Company made use of different vesting schedules through fiscal 2009, but subsequent new grants generally vested as to 25% on the first anniversary of the date of grant and monthly thereafter over the next three years and generally have a term of 10 years from the date of grant.

[0001511737-14-000024:notes:56]
As of June 30, 2014, the Company had 9,918,184 authorized shares available for future issuance under all of its stock incentive plans.

[0001511737-14-000024:notes:57]
The following table shows total stock-based compensation expense included in the Consolidated Statements of Operations and Comprehensive Income for fiscal 2014, 2013 and 2012 (in thousands):

[0001511737-14-000024:notes:58]
|  | Years Ended Years Ended June 30, |
|  | 2014 |  | 2013 |  | 2012 |
| Cost of sales | $ | 590 |  |  | $ | 446 |  |  | $ | 117 |  |
| Research and development | 2,423 |  |  | 1,433 |  |  | 542 |  |
| Sales, general and administrative | 1,893 |  |  | 1,497 |  |  | 834 |  |
|  | $ | 4,906 |  |  | $ | 3,376 |  |  | $ | 1,493 |  |

[0001511737-14-000024:notes:59]
Stock Options

[0001511737-14-000024:notes:60]
The following is a summary of option activity for the Company’s stock incentive plans for fiscal 2014, 2013 and 2012:

[0001511737-14-000024:notes:61]
|  | Common Stock Options Outstanding |
|  | Numberof Shares |  | WeightedAverageExercisePrice |  | WeightedAverageRemainingContractualLife (Years) |  | AggregateIntrinsicValue |
|  |  |  |  |  |  |  | (In thousands) |
| Balance, June 30, 2011 | 6,171,707 |  |  | $ | 0.72 |  |  | 6.44 |  | $ | 43,135 |  |
| Granted | 161,000 |  |  | 10.44 |  |  |  |  |  |
| Exercised | (2,885,470 | ) |  | 0.28 |  |  |  |  |  |
| Forfeitures and cancellations | (99,792 | ) |  | 4.71 |  |  |  |  |  |
| Balance, June 30, 2012 | 3,347,445 |  |  | $ | 1.45 |  |  | 6.62 |  | $ | 42,920 |  |
| Granted | 683,500 |  |  | 11.29 |  |  |  |  |  |
| Exercised | (266,558 | ) |  | 2.39 |  |  |  |  |  |
| Forfeitures and cancellations | (150,125 | ) |  | 5.68 |  |  |  |  |  |
| Balance, June 30, 2013 | 3,614,262 |  |  | $ | 3.07 |  |  | 6.17 |  | $ | 52,330 |  |
| Exercised | (849,635 | ) |  | 2.46 |  |  |  |  |  |
| Forfeitures and cancellations | (107,485 | ) |  | 10.55 |  |  |  |  |  |
| Balance, June 30, 2014 | 2,657,142 |  |  | $ | 2.96 |  |  | 5.11 |  | $ | 112,215 |  |
| Vested and expected to vest as of June 30, 2014 | 2,635,599 |  |  | $ | 2.89 |  |  | 5.09 |  | $ | 111,482 |  |
| Vested and exercisable as of June 30, 2014 | 2,233,533 |  |  | $ | 1.60 |  |  | 4.56 |  | $ | 97,363 |  |

[0001511737-14-000024:notes:62]
Additional information regarding options outstanding as of June 30, 2014 is as follows (in thousands, except weighted average exercise price amounts and contractual life):

[0001511737-14-000024:notes:63]
|  |  | Options Outstanding |  |  |  | Options Exercisable |
| Range of Exercise Prices |  | Number ofOptions |  | WeightedAverageRemainingContractualLife (Years) |  | WeightedAverageExercisePrice |  | Number ofOptions |  | WeightedAverageExercisePrice |
| $0.01 - $0.04 |  | 75,270 |  |  | 3.17 |  | $ | 0.01 |  |  | 75,270 |  |  | $ | 0.01 |  |
| $0.05 - $0.39 |  | 1,594,890 |  |  | 3.78 |  | 0.05 |  |  | 1,594,890 |  |  | 0.05 |  |
| $0.40 - $5.11 |  | 370,220 |  |  | 6.28 |  | 3.07 |  |  | 319,027 |  |  | 2.99 |  |
| $5.12 - $10.76 |  | 124,817 |  |  | 6.98 |  | 6.95 |  |  | 74,886 |  |  | 7.00 |  |
| $10.77 - $11.74 |  | 321,500 |  |  | 8.37 |  | 10.77 |  |  | 107,537 |  |  | 10.77 |  |
| $11.75 - $18.48 |  | 163,267 |  |  | 8.41 |  | 13.30 |  |  | 58,105 |  |  | 13.36 |  |
| $18.49 - $18.70 |  | 2,907 |  |  | 7.51 |  | 18.49 |  |  | 1,406 |  |  | 18.49 |  |
| $18.71 - $19.98 |  | 1,000 |  |  | 7.36 |  | 18.71 |  |  | 645 |  |  | 18.71 |  |
| $19.99 - $26.28 |  | 3,271 |  |  | 7.48 |  | 21.43 |  |  | 1,767 |  |  | 21.17 |  |
| $0.01 – $26.28 |  | 2,657,142 |  |  | 5.11 |  | $ | 2.96 |  |  | 2,233,533 |  |  | $ | 1.60 |  |

[0001511737-14-000024:notes:64]
During fiscal 2014 and 2013 and 2012, the aggregate intrinsic value of options exercised under the Company’s stock incentive plans was $30.5 million,  $3.4 million, and $48.6 million, respectively, as determined as of the date of option exercise.

[0001511737-14-000024:notes:65]
As of June 30, 2014, the Company had unrecognized compensation cost of $2.0 million related to stock options which the Company expects to recognize over a weighted-average period of 2.2 years. Future option grants will increase the amount of compensation expense to be recorded in these periods.

[0001511737-14-000024:notes:66]
The Company estimates the fair value of employee stock options using the Black-Scholes option pricing model. The fair value of employee stock options is being amortized on a straight-line basis over the requisite service period of the awards. The Company did not grant any stock options during fiscal 2014.  For fiscal 2013 and 2012 the fair value of employee stock options was estimated using the following weighted average assumptions:

[0001511737-14-000024:notes:67]
|  | Years Ended Years Ended June 30, |
|  | 2013 |  | 2012 |
| Expected term | 6.1 years |  |  | 6.1 years |  |
| Expected volatility | 52 | % |  | 49 | % |
| Risk-free interest rate | 0.9 | % |  | 1.6 | % |
| Expected dividend yield | — |  |  | — |  |
| Weighted average grant date fair value | $ | 5.57 |  |  | $ | 5.05 |  |

[0001511737-14-000024:notes:68]
Expected term. Expected term represents the period that the Company’s stock-based awards are expected to be outstanding. As the Company has limited historical option exercise data, the expected term of the stock options granted to employees was calculated based on the simplified method. Under the simplified method, the expected term is equal to the average of an option’s weighted-average vesting period and its contractual term. The Company is permitted to continue using the simplified method until sufficient information regarding exercise behavior, such as historical exercise data or exercise information from external sources, becomes available.

[0001511737-14-000024:notes:69]
Expected volatility. The expected volatility was based on the historical stock volatilities of a group of publicly listed comparable companies over a period equal to the expected terms of the options, as the Company does not have any trading history to use the volatility of its common stock.

[0001511737-14-000024:notes:70]
Expected dividend yield. Although the Company paid a special cash dividend during fiscal 2013, the Company does not currently plan to pay dividends on its common stock.

[0001511737-14-000024:notes:71]
Risk-free interest rate. The risk-free interest rate is based on the U.S. Treasury yield curve in effect at the time of grant for zero coupon U.S. Treasury notes with maturities approximately equal to the option’s expected term.

[0001511737-14-000024:notes:72]
Fair value of common stock. The Company’s common stock began trading on the NASDAQ Global Select Market on October 14, 2011, upon its initial public offering. The fair value of the Company’s common stock is determined using the market price of the Company’s common stock as of the date of grant. Prior to October 14, 2011, the fair value of the shares of common stock underlying the stock options has historically been the responsibility of and determined by the Company’s board of directors. Because there had been no public market for the Company’s common stock, its board of directors has determined fair value of the common stock at the time of grant of the option by considering a number of objective and subjective factors including independent third-party valuations of its common stock, operating and financial performance, the lack of liquidity of capital stock and general and industry specific economic outlook, amongst other factors.

[0001511737-14-000024:notes:73]
Forfeiture rate. The Company estimates its forfeiture rate based on an analysis of its actual forfeitures and will continue to evaluate the adequacy of the forfeiture rate based on actual forfeiture experience, analysis of employee turnover behavior and other factors. The impact from a forfeiture rate adjustment will be recognized in full in the period of adjustment, and if the actual number of future forfeitures differs from that estimated, the Company may be required to record adjustments to stock-based compensation expense in future periods.

[0001511737-14-000024:notes:74]
Cash received from stock option exercises during the fiscal 2014, 2013 and 2012 was $2.1 million, $635,000 and $811,000, respectively.

[0001511737-14-000024:notes:75]
Restricted Stock Units (“RSUs”)

[0001511737-14-000024:notes:76]
The following table summarizes the activity of the RSUs made by the Company:

[0001511737-14-000024:notes:77]
|  | Number of Shares |  | Weighted Average Grant Date Fair Value |
| Non-vested RSUs, June 30, 2011 | 488,385 |  |  | $ | 2.66 |  |
| RSUs granted | 169,710 |  |  | 22.33 |  |
| RSUs vested | (146,475 | ) |  | 2.37 |  |
| RSUs canceled | (58,000 | ) |  | 8.04 |  |
| Non-vested RSUs, June 30, 2012 | 453,620 |  |  | $ | 9.42 |  |
| RSUs granted | 656,500 |  |  | 14.11 |  |
| RSUs vested | (70,512 | ) |  | 14.14 |  |
| RSUs canceled | (294,702 | ) |  | 5.29 |  |
| Non-vested RSUs, June 30, 2013 | 744,906 |  |  | $ | 14.74 |  |
| RSUs granted | 209,032 |  |  | 37.87 |  |
| RSUs vested | (170,197 | ) |  | 15.59 |  |
| RSUs canceled | (234,039 | ) |  | 16.18 |  |
| Non-vested RSUs, June 30, 2014 | 549,702 |  |  | $ | 22.65 |  |

[0001511737-14-000024:notes:78]
The intrinsic value of RSUs vested in fiscal 2014, 2013 and 2012 was $6.1 million, $1.0 million and $3.5 million, respectively.  The total intrinsic value of all outstanding RSUs was $24.8 million as of June 30, 2014.

[0001511737-14-000024:notes:79]
As of June 30, 2014, there was unrecognized compensation costs related to RSUs of $9.6 million which the Company expects to recognize over a weighted average period of 3.2 years.


## us-gaap:EarningsPerSharePolicyTextBlock

[0001511737-14-000024:notes:80]
Earnings Per Share

[0001511737-14-000024:notes:81]
The Company applies the two-class method for calculating and presenting earnings per share (“EPS”). Under the two-class method, net income is allocated between shares of common stock and other participating securities based on their participating rights. Participating securities are defined as securities that participate in dividends with common stock according to a pre-determined formula or a contractual obligation to share in the income of the entity. Basic EPS is computed by dividing net income available to common stockholders by the weighted average number of shares of common stock outstanding during the period. Diluted EPS is computed by dividing the amount of net income available to common stockholders outstanding plus income allocable to participating securities, to the extent they are dilutive, by the weighted average number of shares of common stock and potential dilutive shares outstanding during the period if the effect is dilutive. The Company’s potentially dilutive common securities include outstanding stock options, restricted stock units and preferred stock.


## us-gaap:EarningsPerShareTextBlock

[0001511737-14-000024:notes:82]
EARNINGS PER SHARE

[0001511737-14-000024:notes:83]
The following table sets forth the computation of basic and diluted earnings per share for the periods indicated (in thousands, except per share data):

[0001511737-14-000024:notes:84]
|  | Years Ended June 30, |  |
|  | 2014 |  | 2013 |  | 2012 |  |
| Numerator: |  |  |  |  |  |  |
| Net income (loss) attributable to common stockholders | $ | 176,937 |  |  | $ | 80,490 |  |  | $ | (9,842 | ) |  |
| Denominator: |  |  |  |  |
| Weighted-average shares used in computing basic net income (loss) per share | 87,772 |  |  | 88,314 |  |  | 83,460 |  |  |
| Add—dilutive potential common shares: |  |  |  |  |  |  |
| Stock options | 1,696 |  |  | 1,803 |  |  | — |  |  |
| Restricted stock units | 247 |  |  | 142 |  |  | — |  |  |
| Weighted-average shares used in computing diluted net income (loss) per share | 89,715 |  |  | 90,259 |  |  | 83,460 |  |  |
| Net income (loss) per share of common stock: |  |  |  |  |
| Basic | $ | 2.02 |  |  | $ | 0.91 |  |  | $ | (0.12 | ) |  |
| Diluted | $ | 1.97 |  |  | $ | 0.89 |  |  | $ | (0.12 | ) |  |

[0001511737-14-000024:notes:85]
The following table summarizes the total potential shares of common stock that were excluded from the diluted per share calculation, because to include them would have been anti-dilutive for the period (in thousands):

[0001511737-14-000024:notes:86]
|  | Years Ended June 30, |
|  | 2014 |  | 2013 |  | 2012 |
| Stock options | — |  |  | 658 |  |  | 3,348 |  |
| Restricted stock units | 36 |  |  | 364 |  |  | 454 |  |
|  | 36 |  |  | 1,022 |  |  | 3,802 |  |


## us-gaap:FairValueAssetsAndLiabilitiesMeasuredOnRecurringAndNonrecurringBasisTableTextBlock

[0001511737-14-000024:notes:87]
As of June 30, 2014 and 2013, the fair value hierarchy for the Company’s financial liabilities was as follows (in thousands):

[0001511737-14-000024:notes:88]
|  | June 30, 2014 |  | June 30, 2013 |
|  | FairValue |  | Level 1 |  | Level 2 |  | Level 3 |  | FairValue |  | Level 1 |  | Level 2 |  | Level 3 |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Debt(1) | $ | 72,254 |  |  | $ | — |  |  | $ | 72,254 |  |  | $ | — |  |  | $ | 76,129 |  |  | $ | — |  |  | $ | 76,129 |  |  | $ | — |  |

[0001511737-14-000024:notes:89]
(1) Debt is carried at historical cost on the Company's consolidated balance sheet.


## us-gaap:FairValueDisclosuresTextBlock

[0001511737-14-000024:notes:90]
FAIR VALUE OF FINANCIAL INSTRUMENTS

[0001511737-14-000024:notes:91]
Pursuant to the accounting guidance for fair value measurements and its subsequent updates, fair value is defined as the price that would be received from selling an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date. As such, fair value is a market-based measurement that should be determined based on assumptions that market participants would use in pricing an asset or liability. The accounting guidance establishes a three-tier fair value hierarchy that requires the Company to use observable market data, when available, and to minimize the use of unobservable inputs when determining fair value. The fair value hierarchy prioritizes the inputs into three levels that may be used in measuring fair value as follows:

[0001511737-14-000024:notes:92]
Level 1—observable inputs which include quoted prices in active markets for identical assets of liabilities.

[0001511737-14-000024:notes:93]
Level 2—inputs which include observable inputs other than Level 1, such as quoted prices for similar assets or liabilities, quoted prices for identical or similar assets or liabilities in markets that are not active, or other inputs that are observable or can be corroborated by observable market data for substantially the full term of the asset or liability.

[0001511737-14-000024:notes:94]
Level 3—inputs which include unobservable inputs that are supported by little or no market activity and that are significant to the fair value of the underlying asset or liability. Level 3 assets and liabilities include those whose fair value measurements are determined using pricing models, discounted cash flow methodologies or similar valuation techniques, as well as significant management judgment or estimation.

[0001511737-14-000024:notes:95]
For certain of the Company’s financial instruments, including cash, accounts receivable and accounts payable, the carrying amounts approximate fair value due to their short maturities, and are therefore excluded from the fair value tables below.   Additionally, as of June 30, 2014, we held $307.6 million of our $347.1 million of cash and cash equivalents in accounts of our subsidiaries outside of the United States and we will incur significant tax liabilities if we were to repatriate those amounts.

[0001511737-14-000024:notes:96]
At June 30, 2014 and 2013 the Company had debt associated with its Loan and Security Agreements with Wells Fargo Bank and East West Bank, respectively (See Note 7). The fair value of the Company’s debt was estimated based on the current rates offered to the Company for debt with similar terms and remaining maturities and was Level 2 measurement.


## us-gaap:ForeignCurrencyTransactionsAndTranslationsPolicyTextBlock

[0001511737-14-000024:notes:97]
Foreign Currency Translation

[0001511737-14-000024:notes:98]
The functional currency of the Company and its subsidiaries is the U.S. dollar. For foreign operations, local currency denominated assets and liabilities are remeasured at the period end exchange rates, and revenues, costs and expenses are remeasured at the average exchange rates during the fiscal year. Foreign exchange gains and losses have been immaterial to the Company’s results of operations to date.


## us-gaap:ImpairmentOrDisposalOfLongLivedAssetsPolicyTextBlock

[0001511737-14-000024:notes:99]
Long Lived Assets

[0001511737-14-000024:notes:100]
The Company evaluates its long lived assets including property and equipment for impairment whenever events or changes in circumstances indicate that the carrying value of these assets may not be recoverable. An impairment loss is recognized when the net book value of such assets exceeds the estimated future undiscounted cash flows attributable to the assets or asset group. If impairment is indicated, the asset is written down to its estimated fair value.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001511737-14-000024:notes:101]
INCOME TAXES

[0001511737-14-000024:notes:102]
For financial reporting purposes, the components of income before provision for income taxes were as follows (in thousands):

[0001511737-14-000024:notes:103]
|  |  | Years Ended June 30, |
|  |  | 2014 |  | 2013 |  | 2012 |
| Domestic |  | $ | 44,551 |  |  | $ | 17,860 |  |  | $ | 41,490 |  |
| Foreign |  | 150,060 |  |  | 73,893 |  |  | 82,533 |  |
|  |  | $ | 194,611 |  |  | $ | 91,753 |  |  | $ | 124,023 |  |

[0001511737-14-000024:notes:104]
The components of the Company’s provision for income taxes consisted of the following (in thousands):

[0001511737-14-000024:notes:105]
|  |  | Years Ended June 30, |
|  |  | 2014 |  | 2013 |  | 2012 |
| Current |  |  |  |  |  |  |
| Foreign |  | $ | 2,451 |  |  | $ | 1,790 |  |  | $ | 2,040 |  |
| Federal |  | 16,516 |  |  | 8,515 |  |  | 17,437 |  |
| State |  | 109 |  |  | 581 |  |  | 2,854 |  |
| Current tax expense |  | 19,076 |  |  | 10,886 |  |  | 22,331 |  |
| Deferred |  |  |  |  |  |  |
| Foreign |  | — |  |  | — |  |  | — |  |
| Federal |  | (1,507 | ) |  | (130 | ) |  | (217 | ) |
| State |  | 105 |  |  | 507 |  |  | (680 | ) |
| Deferred tax expense |  | (1,402 | ) |  | 377 |  |  | (897 | ) |
| Provision for income taxes |  | $ | 17,674 |  |  | $ | 11,263 |  |  | $ | 21,434 |  |

[0001511737-14-000024:notes:106]
Significant components of the Company’s deferred tax assets and liabilities consisted of the following (in thousands):

[0001511737-14-000024:notes:107]
|  |  | June 30, |
|  |  | 2014 |  | 2013 |
| Deferred tax assets |  |  |  |  |
| Allowance for doubtful accounts |  | $ | 200 |  |  | $ | 337 |  |
| Stock-based compensation |  | 1,038 |  |  | 833 |  |
| Accrued expenses |  | 455 |  |  | 191 |  |
| Research and development credits |  | 345 |  |  | — |  |
| State tax |  | 570 |  |  | — |  |
| Other |  | 353 |  |  | 323 |  |
| Total deferred tax assets |  | 2,961 |  |  | 1,684 |  |
| Deferred tax liabilities |  |  |  |  |
| Basis difference for fixed assets |  | (477 | ) |  | (829 | ) |
| Other |  | — |  |  | (118 | ) |
| Total deferred tax liabilities |  | (477 | ) |  | (947 | ) |
| Valuation allowance |  | (345 | ) |  | — |  |
| Net deferred tax assets |  | $ | 2,139 |  |  | $ | 737 |  |

[0001511737-14-000024:notes:108]
As of June 30, 2014, the Company had California research tax credit carry-forwards, net of ASC 740-10 unrecognized tax benefits, of approximately $1.1 million. The California research credits can be carried forward indefinitely.

[0001511737-14-000024:notes:109]
Management assesses the available positive and negative evidence to estimate if sufficient future taxable income will be generated to use the existing deferred tax assets.  In the fourth quarter of fiscal 2014, the Company determined that it is more likely than not that our deferred tax asset for California research credits will not be realized as for the foreseeable future the Company is expecting to generate credits in excess of its ability to use such attributes. As a result, the Company established a valuation allowance of $345,000 for the amount of California deferred tax assets that may not be realized as of June 30, 2014.

[0001511737-14-000024:notes:110]
As a result of certain realization requirements of ASC 718, Compensation - Stock Compensation, the table of deferred tax assets and liabilities shown above does not include certain deferred tax assets as of June 30, 2014, that arose directly from (or the use of which was postponed by) tax deductions related to equity compensation that are greater than the compensation recognized for financial reporting. Equity will be increased by approximately $541,000 if and when such deferred tax assets are ultimately realized. The Company uses ASC 740 ordering when determining when excess tax benefits have been realized.

[0001511737-14-000024:notes:111]
The effective tax rate differs from the applicable U.S. statutory federal income tax rate as follows:

[0001511737-14-000024:notes:112]
|  |  | Years Ended June 30, |
|  |  | 2014 |  | 2013 |  | 2012 |
| Statutory rate |  | 35.0 | % |  | 35.0 | % |  | 35.0 | % |
| Stock-based compensation |  | 0.4 |  |  | 0.8 |  |  | — |  |
| State tax expense |  | — |  |  | 0.7 |  |  | 1.0 |  |
| Tax rate differential, foreign income |  | (25.3 | ) |  | (24.2 | ) |  | (23.0 | ) |
| Federal research and development credits |  | (0.3 | ) |  | (0.4 | ) |  | — |  |
| Other permanent items |  | (0.7 | ) |  | 0.4 |  |  | 4.3 |  |
| Effective tax rate |  | 9.1 | % |  | 12.3 | % |  | 17.3 | % |

[0001511737-14-000024:notes:113]
The Company had increased foreign operations in fiscal 2014 as compared to fiscal 2013 and in fiscal 2013 as compared to fiscal 2012, which resulted in the generation more income on a comparative year over year basis in foreign jurisdictions that have lower tax rates than the U.S.

[0001511737-14-000024:notes:114]
It is the practice and intention of the Company to reinvest the earnings of its non-U.S. subsidiaries in those operations.  As of June 30, 2014, the Company has not made a provision for U.S. or additional foreign withholding taxes on approximately $347.0 million of the excess of the amount for financial reporting over the tax basis of investments in foreign subsidiaries that are essentially permanent in duration. Generally, such amounts become subject to U.S. taxation upon the remittance of dividends and under certain other circumstances. It is not practicable to estimate the amount of deferred tax liability related to investments in these foreign subsidiaries.

[0001511737-14-000024:notes:115]
While management believes that the Company has adequately provided for all tax positions, amounts asserted by tax authorities could be greater or less than the recorded position. Accordingly, the Company's provisions on federal, state and foreign tax-related matters to be recorded in the future may change as revised estimates are made or the underlying matters are settled or otherwise resolved.

[0001511737-14-000024:notes:116]
A reconciliation of the beginning and ending balances of the unrecognized tax benefits during the years ended June 30, 2014 2013 and 2012 consists of the following (in thousands):

[0001511737-14-000024:notes:117]
|  |  | Years Ended June 30, |
|  |  | 2014 |  | 2013 |  | 2012 |
|  |  | (In thousands) |
| Unrecognized benefit—beginning of period |  | $ | 11,455 |  |  | $ | 7,825 |  |  | $ | 2,020 |  |
| Gross increases—current year tax positions |  | 3,871 |  |  | 3,806 |  |  | 4,697 |  |
| Gross increases (decreases)—prior year tax positions |  | (213 | ) |  | (176 | ) |  | 1,108 |  |
| Gross Decreases - prior year tax positions due to statue lapse |  | $ | (199 | ) |  |  |  |  |
| Unrecognized benefit—end of period |  | $ | 14,914 |  |  | $ | 11,455 |  |  | $ | 7,825 |  |

[0001511737-14-000024:notes:118]
Included in the gross unrecognized tax benefits balance as of June 30, 2014 are $14.5 million of tax positions which would affect income tax expense if recognized.  The Company recognizes interest and penalties related to unrecognized tax benefits within the income tax expense line in the accompanying Consolidated Statement of Operations and Comprehensive Income.  Accrued interest and penalties are included within the related tax liability line in the Consolidated Balance Sheet.  As of June 30, 2014, the Company had $695,000 accrued interest related to uncertain tax matters. The Company does not expect its unrecognized tax benefits as of June 30, 2014 will materially change within the next 12 months.  The Company files income tax returns in the United States, various states and certain foreign jurisdictions.  Tax years 2011 through 2014 are subject to examination by the U.S. federal tax authorities. Tax years 2010 through 2014 are subject to examination by the state tax authorities. Tax year 2014 is subject to examination by the foreign tax authorities.  There are no income tax examinations currently in process.


## us-gaap:IncomeTaxPolicyTextBlock

[0001511737-14-000024:notes:119]
Income Taxes

[0001511737-14-000024:notes:120]
The Company accounts for income taxes in accordance with accounting guidance which requires recognition of deferred tax assets and liabilities for the expected future tax consequences of events that have been included in its financial statements or tax returns. Deferred tax assets and liabilities are determined based on the temporary difference between the financial statement carrying amounts of existing assets and liabilities and their respective tax bases. Deferred tax assets and liabilities are measured using enacted tax rates expected to apply to taxable income in the years in which those temporary differences are expected to be recovered or settled. The Company establishes valuation allowances when necessary to reduce deferred tax assets to the amount it expects to realize. The assessment of whether or not a valuation allowance is required often requires significant judgment including current operating results, the forecast of future taxable income and ongoing prudent and feasible tax planning initiatives. In addition, the Company’s calculation of its tax liabilities involves dealing with uncertainties in the application of complex tax regulations. The Company may be subject to income tax audits in all of the jurisdictions in which it operates and, as a result, must also assess exposures to any potential issues arising from current or future audits of current and prior years’ tax returns. Accordingly, the Company must assess such potential exposures and, where necessary, provide a reserve to cover any expected loss. To the extent that the Company establishes a reserve, its provision for income taxes would be increased. If the Company ultimately determines that payment of these amounts is unnecessary, it reverses the liability and recognizes a tax benefit during the period in which it determines that the liability is no longer necessary. The Company records an additional charge in its provision for taxes in the period in which it determines that tax liability is greater than its original estimate.


## us-gaap:InventoryPolicyTextBlock

[0001511737-14-000024:notes:121]
Inventory and Inventory Valuation

[0001511737-14-000024:notes:122]
The Company's inventories are primarily finished goods and, to a lesser extent, raw materials, which have been consigned to the Company's contract manufacturers.  Inventories are stated at the lower of actual cost (computed on a first-in, first-out basis), or market value. Market value is based upon an estimated average selling price reduced by the estimated costs of disposal. The determination of market value involves numerous judgments including estimating average selling prices based up recent sales, industry trends, existing customer orders, and seasonal factors. Should actual market conditions differ from the Company's estimates, future results of operations could be materially affected. The Company reduces the value of its inventory for estimated obsolescence or lack of marketability by the difference between the cost of the affected inventory and the estimated market value. Write-downs are not reversed until the related inventory has been subsequently sold or scrapped.

[0001511737-14-000024:notes:123]
The valuation of inventory also requires the Company to estimate excess and obsolete inventory. The determination of excess or obsolete inventory is estimated based on a comparison of the quantity and cost of inventory on hand to the Company's forecast of customer demand. Customer demand is dependent on many factors and requires the Company to use significant judgment in our forecasting process. The Company also makes assumptions regarding the rate at which new products will be accepted in the marketplace and at which customers will transition from older products to newer products. If actual market conditions are less favorable than those projected by management, additional inventory write-downs may be required, which would have a negative impact on the Company's gross margin. If the Company ultimately sells inventory that has been previously written down, the Company's gross margins in future periods will be positively impacted.


## us-gaap:LeasePolicyTextBlock

[0001511737-14-000024:notes:124]
Leases

[0001511737-14-000024:notes:125]
The Company leases its facilities under cancelable and noncancelable operating leases. For leases that contain rent escalation or rent concessions provisions, the Company records the total rent expense during the lease term on a straight line basis over the term of the lease. The Company records the difference between the rent paid and the straight line rent as a deferred rent liability in the accompanying consolidated balance sheets.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001511737-14-000024:notes:126]
Recent Accounting Pronouncements

[0001511737-14-000024:notes:127]
In June 2014, the Financial Accounting Standards Board, or FASB, issued a new accounting standard update on revenue from contracts with customers.  The core principle of the guidance is that an entity should recognize revenue to depict the transfer of promised goods or services to customers in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services.  To achieve that core principle, an entity should apply the following steps:

[0001511737-14-000024:notes:128]
Step 1: Identify the contract(s) with a customer.

[0001511737-14-000024:notes:129]
Step 2: Identify the performance obligations in the contract.

[0001511737-14-000024:notes:130]
Step 3: Determine the transaction price.

[0001511737-14-000024:notes:131]
Step 4: Allocate the transaction price to the performance obligations in the contract.

[0001511737-14-000024:notes:132]
Step 5: Recognize revenue when (or as) the entity satisfies a performance obligation.

[0001511737-14-000024:notes:133]
An entity should disclose sufficient information to enable users of financial statements to understand the nature, amount, timing, and uncertainty of revenue and cash flows arising from contracts with customers. Qualitative and quantitative information is required about contracts with customers, significant judgments and any assets recognized from the costs to obtain or fulfill a contract.   The guidance will be effective for the Company beginning July 1, 2017.  The Company is currently assessing the impact of this new guidance.

[0001511737-14-000024:notes:134]
In July 2013, the FASB issued a new accounting standard update on the financial statement presentation of unrecognized tax benefits.  The new guidance provides that a liability related to an unrecognized tax benefit would be presented as a reduction of a deferred tax asset for a new operating loss carryforward, a similar tax loss or a tax credit carryforward if such settlement is required or expected in the event the uncertain tax position is disallowed.  The new guidance will become effective for the Company on July 1, 2014 and it should be applied prospectively to unrecognized tax benefits that exist as of the effective date with retrospective application permitted.


## us-gaap:PreferredStockTextBlock

[0001511737-14-000024:notes:135]
PREFERRED STOCK

[0001511737-14-000024:notes:136]
In July 2011, the Company repurchased an aggregate of 12,041,700 shares of the Company’s Series A convertible preferred stock from entities affiliated with Summit Partners, L.P., one of the Company’s major stockholders, at a price of $8.97 per share for an aggregate consideration of $108.0 million. Of the aggregate purchase price, $40.0 million was paid in cash at the time of closing and the balance of the shares were paid for through the issuance of convertible subordinated promissory notes in the aggregate principal amount of $68.0 million. The $68.0 million was paid down primarily using proceeds from the EWB Loan Agreement and the remaining balance was subsequently paid down by funds raised upon the completion of the Company’s initial public offering on October 19, 2011 and the Company’s existing cash balances as discussed in Note 7.


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001511737-14-000024:notes:137]
ACCRUED WARRANTY

[0001511737-14-000024:notes:138]
Warranty obligations, included in other current liabilities, were as follows (in thousands):

[0001511737-14-000024:notes:139]
| Balance at June 30, 2012 | $ | 1,381 |  |
| Accruals for warranties issued during the period | 4,079 |  |
| Settlements made during the period | (2,547 | ) |
| Balance at June 30, 2013 | 2,913 |  |
| Accruals for warranties issued during the period | 4,157 |  |
| Settlements made during the period | (4,220 | ) |
| Balance at June 30, 2014 | $ | 2,850 |  |


## us-gaap:PropertyPlantAndEquipmentPolicyTextBlock

[0001511737-14-000024:notes:140]
Property and Equipment

[0001511737-14-000024:notes:141]
Furniture, fixtures and equipment are recorded at cost. The Company computes depreciation or amortization using the straight line method over estimated useful lives, as follows:

[0001511737-14-000024:notes:142]
|  |  | Estimated Useful Life |
| Testing equipment |  | 3 to 5 years |
| Computer and other equipment |  | 3 to 5 years |
| Furniture and fixtures |  | 3 years |
| Leasehold improvements |  | shorter of lease term or useful life |

[0001511737-14-000024:notes:143]
Upon retirement or disposition, the asset cost and related accumulated depreciation are removed with any gain or loss recognized in the statement of operations. Expenditures for maintenance and repairs are charged to operations as incurred.


## us-gaap:PropertyPlantAndEquipmentScheduleOfSignificantAcquisitionsAndDisposalsTextBlock

[0001511737-14-000024:notes:144]
Property and equipment, net consisted of the following (in thousands):

[0001511737-14-000024:notes:145]
|  | June 30, |
|  | 2014 |  | 2013 |
| Testing equipment | $ | 3,785 |  |  | $ | 3,309 |  |
| Computer and other equipment | 1,019 |  |  | 841 |  |
| Tooling equipment | 2,898 |  |  | 1,737 |  |
| Furniture and fixtures | 973 |  |  | 652 |  |
| Leasehold improvements | 3,173 |  |  | 1,858 |  |
| Software | 521 |  |  | 245 |  |
|  | 12,369 |  |  | 8,642 |  |
| Less: Accumulated depreciation and amortization | (5,109 | ) |  | (2,666 | ) |
|  | $ | 7,260 |  |  | $ | 5,976 |  |


## us-gaap:ReceivablesPolicyTextBlock

[0001511737-14-000024:notes:146]
Allowance for Doubtful Accounts

[0001511737-14-000024:notes:147]
The Company records an allowance for doubtful accounts for estimated probable losses on uncollectible accounts receivable. In estimating the allowance, management considers, among other factors, (i) the aging of the accounts receivable, (ii) the Company’s historical write offs, (iii) the credit worthiness of each distributor based on payment history and (iv) general economic conditions. In cases where the Company is aware of circumstances that may impair a specific distributor’s ability to meet its obligations to the Company, the Company records a specific allowance against amounts due from the distributor, and thereby reduces the net recognized receivable to the amounts it reasonably believes will be collected.


## us-gaap:ResearchDevelopmentAndComputerSoftwarePolicyTextBlock

[0001511737-14-000024:notes:148]
Research and Development Costs and Capitalized Software Development Costs

[0001511737-14-000024:notes:149]
Research and development expenses are expensed as incurred.  Research and development expenses associated with software development are expensed as incurred as our software is typically released to end customers immediately after technological feasibility has been established.


## us-gaap:RevenueRecognitionPolicyTextBlock

[0001511737-14-000024:notes:150]
Recognition of Revenues

[0001511737-14-000024:notes:151]
Revenues consist primarily of revenues from the sale of hardware and management tools, as well as the related implied post contract customer support (“PCS”). The Company recognizes revenues when persuasive evidence of an arrangement exists, delivery has occurred, the sales price is fixed or determinable and the collectability of the resulting receivable is reasonably assured. In cases where the Company lacks evidence that collectability of the resulting receivable is reasonably assured, it defers recognition of revenue until the receipt of cash.

[0001511737-14-000024:notes:152]
For the Company’s sales, evidence of the arrangement consists of an order from a customer. The Company considers delivery to have occurred once its products have been shipped and title and risk of loss have been transferred. For the Company’s sales, these criteria are met at the time the products are transferred to the customer. The Company’s arrangements with customers do not, in most cases, include provisions for cancellation, returns, inventory swaps or refunds that would significantly impact recognized revenues.

[0001511737-14-000024:notes:153]
The Company records amounts billed to distributors for shipping and handling costs as revenues. The Company classifies shipping and handling costs incurred by it as cost of revenues.

[0001511737-14-000024:notes:154]
Deposit payments received from distributors in advance of recognition of revenues are included in current liabilities on the Company’s balance sheet and are recognized as revenues when all the criteria for recognition of revenues are met.

[0001511737-14-000024:notes:155]
The Company’s multi-element arrangements generally include two deliverables. The first deliverable is the hardware and software essential to the functionality of the hardware device delivered at the time of sale. The second deliverable is the implied right to PCS included with the purchase of certain products. PCS is this right to receive, on a when and if available basis, future unspecified software upgrades and features relating to the product’s essential software as well as bug fixes, email and telephone support.

[0001511737-14-000024:notes:156]
The Company uses a hierarchy to determine the allocation of revenues to the deliverables. The hierarchy is as follows: (i) vendor-specific objective evidence of fair value (“VSOE”), (ii) third-party evidence of selling price (“TPE”), and (iii) best estimate of the selling price (“BESP”).

[0001511737-14-000024:notes:157]
| (i) | VSOE generally exists only when a company sells the deliverable separately and is the price actually charged by the company for that deliverable. Generally the Company does not sell the deliverables separately and, as such, does not have VSOE. |

[0001511737-14-000024:notes:158]
| (ii) | TPE can be substantiated by determining the price that other parties sell similar or substantially similar offerings. The Company does not believe that there is accessible TPE evidence for similar deliverables. |

[0001511737-14-000024:notes:159]
| (iii) | BESP reflects the Company’s best estimates of what the selling prices of elements would be if they were sold regularly on a stand-alone basis. The Company believes that BESP is the most appropriate methodology for determining the allocation of revenue among the multiple elements. |

[0001511737-14-000024:notes:160]
The Company allocates revenues between these two deliverables using the relative selling price method which is based on the estimated selling price for all deliverables. Revenues allocated to the delivered hardware and the related essential software are recognized at the time of sale provided the other conditions for recognition of revenues have been met. Revenues allocated to the PCS are deferred and recognized on a straight-line basis over the estimated life of each of these devices, which currently is two years.  All cost of revenues, including estimated warranty costs, are recognized at the time of sale. Costs for research and development and sales and marketing are expensed as incurred. If the estimated life of the hardware product should change, the future rate of amortization of the revenues allocated to PCS would also change.

[0001511737-14-000024:notes:161]
The Company’s process for determining BESP for deliverables involves multiple factors that may vary depending upon the unique facts and circumstances related to each deliverable. For PCS, the Company believes its network operators and service providers would be reluctant to pay for such services separately. This view is primarily based on the fact that unspecified upgrade rights do not obligate the Company to provide upgrades at a particular time or at all, and do not specify to network operators and service providers which upgrades or features will be delivered. The Company believes that the relatively low prices of its products and its network operators’ and service providers’ price sensitivity would add to their reluctance to pay for PCS. Therefore, the Company has concluded that if it were to sell PCS on a standalone basis, the selling price would be relatively low.

[0001511737-14-000024:notes:162]
Key factors considered by the Company in developing the BESP for PCS include reviewing the activities of specific employees engaged in support and software development to determine the amount of time that is allocated to the development of the undelivered elements, determining the cost of this development effort, and then adding an appropriate level of gross profit to these costs.


## us-gaap:ScheduleOfAccruedLiabilitiesTableTextBlock

[0001511737-14-000024:notes:163]
Accrued liabilities consisted of the following (in thousands):

[0001511737-14-000024:notes:164]
|  | June 30, |
|  | 2014 |  | 2013 |
| Accrued compensation and benefits | $ | 3,432 |  |  | $ | 2,712 |  |
| Accrued accounts payable | 10 |  |  | 323 |  |
| Accrual for an export compliance matter | — |  |  | 1,625 |  |
| Warranty accrual | 2,850 |  |  | 2,913 |  |
| Other accruals | 3,538 |  |  | 3,577 |  |
|  | $ | 9,830 |  |  | $ | 11,150 |  |


## us-gaap:ScheduleOfCreditLossesForFinancingReceivablesCurrentTableTextBlock

[0001511737-14-000024:notes:165]
The allowance for doubtful accounts activity was as follows (in thousands):

[0001511737-14-000024:notes:166]
|  |  | Years Ended June 30, |
|  |  | 2014 |  | 2013 |  | 2012 |
| Beginning balance |  | $ | 2,200 |  |  | $ | 1,266 |  |  | $ | 596 |  |
| Charged to (released from) expenses |  | (658 | ) |  | 1,096 |  |  | 815 |  |
| Bad debt write-offs |  | (147 | ) |  | (162 | ) |  | (145 | ) |
| Ending Balance |  | $ | 1,395 |  |  | $ | 2,200 |  |  | $ | 1,266 |  |


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0001511737-14-000024:notes:167]
Inventories consisted of the following (in thousands):

[0001511737-14-000024:notes:168]
|  | June 30, |
|  | 2014 |  | 2013 |
| Finished goods | $ | 45,881 |  |  | $ | 15,618 |  |
| Raw materials | 468 |  |  | 262 |  |
|  | $ | 46,349 |  |  | $ | 15,880 |  |


## us-gaap:ScheduleOfOtherAssetsNoncurrentTextBlock

[0001511737-14-000024:notes:169]
Other long-term assets consisted of the following (in thousands):

[0001511737-14-000024:notes:170]
|  | June 30, |
|  | 2014 |  | 2013 |
| Intangible assets, net | $ | 799 |  |  | $ | 1,029 |  |
| Long-term deferred cost of revenues | — |  |  | 1,185 |  |
| Other long-term assets | 1,113 |  |  | 672 |  |
|  | $ | 1,912 |  |  | $ | 2,886 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001511737-14-000024:notes:171]
SEGMENT INFORMATION, REVENUES BY GEOGRAPHY AND SIGNIFICANT CUSTOMERS

[0001511737-14-000024:notes:172]
Management has determined that the Company operates as one reportable and operating segment as it only reports financial information on an aggregate and consolidated basis to its chief executive officer, who is the Company’s chief operating decision maker.

[0001511737-14-000024:notes:173]
Revenue

[0001511737-14-000024:notes:174]
Revenues by product type were as follows (in thousands, except percentages):

[0001511737-14-000024:notes:175]
|  | Years Ended June 30, |
|  | 2014 |  | 2013 |  | 2012 |
| Service provider technology | $ | 450,663 |  |  | 79 | % |  | $ | 285,390 |  |  | 89 | % |  | $ | 321,648 |  |  | 91 | % |
| Enterprise technology | 121,801 |  |  | 21 | % |  | 35,433 |  |  | 11 | % |  | 31,869 |  |  | 9 | % |
| Total revenues | $ | 572,464 |  |  | 100 | % |  | $ | 320,823 |  |  | 100 | % |  | $ | 353,517 |  |  | 100 | % |

[0001511737-14-000024:notes:176]
Revenues by geography based on customer’s ship-to destinations were as follows (in thousands, except percentages):

[0001511737-14-000024:notes:177]
|  | Years Ended June 30, |
|  | 2014 |  | 2013 |  | 2012 |
| North America(1) | $ | 142,438 |  |  | 25 | % |  | $ | 84,820 |  |  | 26 | % |  | $ | 88,309 |  |  | 25 | % |
| South America | 109,584 |  |  | 19 | % |  | 65,764 |  |  | 21 | % |  | 88,325 |  |  | 25 | % |
| Europe, the Middle East and Africa | 247,009 |  |  | 43 | % |  | 127,860 |  |  | 40 | % |  | 130,494 |  |  | 37 | % |
| Asia Pacific | 73,433 |  |  | 13 | % |  | 42,379 |  |  | 13 | % |  | 46,389 |  |  | 13 | % |
| Total revenues | $ | 572,464 |  |  | 100 | % |  | $ | 320,823 |  |  | 100 | % |  | $ | 353,517 |  |  | 100 | % |

[0001511737-14-000024:notes:178]
| (1) | Revenue for the United States was $136.6 million, $80.6 million and $84.3 million for fiscal 2014, 2013 and 2012, respectively. |

[0001511737-14-000024:notes:179]
Customers with an accounts receivable balance of 10% or greater of total accounts receivable and customers with net revenues of 10% or greater of total revenues are presented below for the periods indicated:

[0001511737-14-000024:notes:180]
|  | Percentage of Revenues |  | Percentage of Accounts Receivable |
|  | Years Ended June 30, |  | June 30, |
|  | 2014 |  | 2013 |  | 2012 |  | 2014 |  | 2013 |
| Flytec Computers, Inc. | 13 | % |  | 13 | % |  | 16 | % |  | 13 | % |  | 12 | % |
| Streakwave Wireless, Inc. | * |  |  | * |  |  | 10 | % |  | 12 | % |  | 15 | % |
| P.W. Batna Magdalena Mucha | * |  |  | * |  |  | * |  |  | 12 | % |  | 11 | % |

[0001511737-14-000024:notes:181]
*  denotes less than 10%


## us-gaap:SegmentReportingPolicyPolicyTextBlock

[0001511737-14-000024:notes:182]
Segments

[0001511737-14-000024:notes:183]
Management has determined that it operates as one reportable and operating segment as it only reports financial information on an aggregate and consolidated basis to its chief executive officer, who is the Company’s chief operating decision maker.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001511737-14-000024:notes:184]
SUMMARY OF SIGNIFICANT ACCOUNTING POLICIES

[0001511737-14-000024:notes:185]
Use of Accounting Estimates

[0001511737-14-000024:notes:186]
The preparation of financial statements in conformity with GAAP requires management to make estimates and judgments that affect the reported amounts of assets and liabilities and the disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenues and expenses during the reporting period. On an ongoing basis, the Company evaluates these estimates, including those related to allowance for doubtful accounts, inventory valuation, warranty costs, stock-based compensation and income taxes, among others. The Company bases estimates on historical experience and on various other assumptions that are believed to be reasonable under the circumstances. Actual results may differ materially from these estimates.

[0001511737-14-000024:notes:187]
Management has determined that it operates as one reportable and operating segment as it only reports financial information on an aggregate and consolidated basis to its chief executive officer, who is the Company’s chief operating decision maker. See Note 13.

[0001511737-14-000024:notes:188]
Concentration of Risk

[0001511737-14-000024:notes:189]
Financial instruments that potentially subject the Company to concentrations of credit risk consist of cash and cash equivalents and accounts receivable. The Company limits its exposure by primarily placing its cash in interest-bearing deposit accounts with high credit quality financial institutions.

[0001511737-14-000024:notes:190]
The Company derives its accounts receivable from revenues earned from customers located worldwide. The Company bases credit decisions primarily upon a customer’s past credit history. The Company’s standard credit terms are net 30 to 60 days.

[0001511737-14-000024:notes:191]
The Company subcontracts with other companies to manufacture most of its products. The Company relies on the ability of these contract manufacturers to produce the products sold to its distributors and original equipment manufacturers (“OEMs”). A significant portion of the Company’s products are manufactured by a few contract manufacturers.

[0001511737-14-000024:notes:192]
Product Warranties

[0001511737-14-000024:notes:193]
The Company offers warranties on certain products, generally for a period of one year, and records a liability for the estimated future costs associated with potential warranty claims. The warranty costs are reflected in the Company’s consolidated statement of operations and comprehensive income within cost of revenues. The warranties are typically in effect for 12 months from the distributor’s purchase date of the product. The Company’s estimate of future warranty costs is largely based on historical experience factors including product failure rates, material usage, and service delivery cost incurred in correcting product failures. In certain circumstances, the Company may have recourse from its contract manufacturers for replacement cost of defective products, which it also factors into its warranty liability assessment.

[0001511737-14-000024:notes:194]
Fair Value of Financial Instruments

[0001511737-14-000024:notes:195]
The carrying value of the Company’s cash equivalents, accounts receivable, accounts payable and other current liabilities approximate fair value due to their short maturities. The fair value of the Company's cash equivalents and debt are disclosed in  Note 3.

[0001511737-14-000024:notes:196]
The Company evaluates its long lived assets including property and equipment for impairment whenever events or changes in circumstances indicate that the carrying value of these assets may not be recoverable. An impairment loss is recognized when the net book value of such assets exceeds the estimated future undiscounted cash flows attributable to the assets or asset group. If impairment is indicated, the asset is written down to its estimated fair value. The Company did not recognize any impairment losses for fiscal 2014, 2013 and 2012.

[0001511737-14-000024:notes:197]
Intangible Assets

[0001511737-14-000024:notes:198]
The Company’s intangible assets consist primarily of legal costs associated with application for and registration of the Company’s trademarks. The Company amortizes all acquisition-related intangible assets that are subject to amortization over the estimated useful life based on economic benefit, which is generally 5 years.

[0001511737-14-000024:notes:199]
Advertising Costs

[0001511737-14-000024:notes:200]
The Company expenses all advertising costs as incurred.

[0001511737-14-000024:notes:201]
Deferred Offering Costs

[0001511737-14-000024:notes:202]
Deferred offering costs, consisting of legal, accounting and other fees and costs relating to the Company’s initial public offering were capitalized. Deferred offering costs of $3.1 million were offset against initial public offering proceeds upon the closing of the offering in October 2011.

[0001511737-14-000024:notes:203]
In July 2013, the FASB issued a new accounting standard update on the financial statement presentation of unrecognized tax benefits.  The new guidance provides that a liability related to an unrecognized tax benefit would be presented as a reduction of a deferred tax asset for a new operating loss carryforward, a similar tax loss or a tax credit carryforward if such settlement is required or expected in the event the uncertain tax position is disallowed.  The new guidance will become effective for the Company on July 1, 2014 and it should be applied prospectively to unrecognized tax benefits that exist as of the effective date with retrospective application permitted.  The Company has assessed the impact of this new guidance, however the Company does not expect adoption to have a significant impact on its consolidated financial statements.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001511737-14-000024:notes:204]
BALANCE SHEET COMPONENTS

[0001511737-14-000024:notes:205]
Inventories

[0001511737-14-000024:notes:206]
Prepaid Expenses and Other Current Assets

[0001511737-14-000024:notes:207]
Property and Equipment, Net

[0001511737-14-000024:notes:208]
Depreciation expense was $2.6 million and $1.8 million in fiscal 2014 and 2013, respectively.

[0001511737-14-000024:notes:209]
Other Long-term Assets

[0001511737-14-000024:notes:210]
The Company's intangible assets consist primarily of legal costs associated with the application for and registration of the Company’s trademarks.  The Company recorded $270,000 and $200,000 of amortization of intangible assets during fiscal 2014 and 2013, respectively.  During fiscal 2014, the Company wrote off $229,000 of intangible assets.  The balance of accumulated amortization was $450,000 and $200,000 at June 30, 2014 and 2013, respectively.  Estimated future amortization related to trademark registration fees is $237,000, $251,000, $229,000, $68,000 and $14,000 for fiscal years 2015, 2016, 2017, 2018, and thereafter, respectively.

[0001511737-14-000024:notes:211]
Other Current Liabilities


## ubnt:CommonStockAndTreasuryStockDiscloseTextBlock

[0001511737-14-000024:notes:212]
COMMON STOCK AND TREASURY STOCK

[0001511737-14-000024:notes:213]
As of June 30, 2014 and 2013, the authorized capital of the Company included 500,000,000 shares of common stock. As of June 30, 2014, 132,418,408 shares of common stock were issued and 88,179,448 were outstanding. As of June 30, 2013, 131,452,763 shares of common stock were issued and 87,213,803 were outstanding.

[0001511737-14-000024:notes:214]
Common Stock Repurchases

[0001511737-14-000024:notes:215]
On August 9, 2012, the Board of Directors authorized the Company to repurchase up to $100 million of its common stock. The share repurchase program commenced on August 13, 2012 and expired on August 12, 2013. The share repurchase program was been funded from proceeds from the Loan Agreement as discussed in Note 7 and from existing cash on hand.  The Company repurchased 5,159,050 shares at an average share price of $10.52 per share under this plan.   All repurchased shares are recorded as treasury stock at cost.

[0001511737-14-000024:notes:216]
On May 29, 2014, the Board of Directors authorized the Company to repurchase up to an additional $75 million of its common stock. The share repurchase program commenced on June 2, 2014 and will expire on May 10, 2015. The share repurchase program was been funded from proceeds from the Credit Agreement as discussed in Note 8 and from existing cash on hand.  As of June 30, 2014 the Company has not repurchased any of its common stock under this plan.

[0001511737-14-000024:notes:217]
Special Dividend

[0001511737-14-000024:notes:218]
On December 14, 2012, the Board of Directors authorized a special cash dividend of $0.18 per share for each share of common stock outstanding on December 24, 2012.  The aggregate dividend payment of $15.7 million was paid on December 28, 2012 to stockholders of record on December 24, 2012.  The dividend payment was funded using proceeds from the Loan Agreement as discussed in Note 8.

[0001511737-14-000024:notes:219]
Common Stock Offering
