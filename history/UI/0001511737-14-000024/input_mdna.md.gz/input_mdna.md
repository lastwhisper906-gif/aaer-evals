# UI MD&A — 0001511737-14-000024


## mdna

[0001511737-14-000024:mdna:1]
Item 7.  Management’s Discussion and Analysis of Financial Condition and Results of Operations

[0001511737-14-000024:mdna:2]
Overview

[0001511737-14-000024:mdna:3]
Ubiquiti Networks develops high performance networking technology for service providers and enterprises. Our technology platforms focus on delivering highly-advanced and easily deployable solutions that appeal to a global customer base in underserved and underpenetrated markets. Our differentiated business model has enabled us to break down traditional barriers such as high product and network deployment costs and offer solutions with disruptive price-performance characteristics. This differentiated business model, combined with our innovative proprietary technologies, has resulted in an attractive alternative to traditional high touch, high-cost providers, allowing us to advance the market adoption of our platforms for ubiquitous connectivity.

[0001511737-14-000024:mdna:4]
We offer a broad and expanding portfolio of networking products and solutions for service providers and enterprises. Our service provider product platforms provide carrier-class network infrastructure for fixed wireless broadband, wireless backhaul systems and routing. Our enterprise product platforms provide wireless LAN infrastructure, video surveillance products, and machine-to-machine communication components. We believe that our products are highly differentiated due to our proprietary software protocol innovation, firmware expertise, and hardware design capabilities. This differentiation allows our portfolio to meet the demanding performance requirements of video, voice and data applications at prices that are a fraction of those offered by our competitors.

[0001511737-14-000024:mdna:5]
As a core part of our strategy, we have developed a differentiated business model for marketing and selling high volumes of carrier and enterprise-class communications platforms. Our business model is driven by a large, growing and highly engaged community of service providers, distributors, value added resellers, systems integrators and corporate IT professionals, which we refer to as the Ubiquiti Community. The Ubiquiti Community is a critical element of our business strategy as it enables us to drive:

[0001511737-14-000024:mdna:6]
| • | Rapid customer and community driven product development. We have an active, loyal community built from our customers that we believe is a sustainable competitive advantage. Our solutions benefit from the active engagement between the Ubiquiti Community and our development engineers throughout the product development cycle, which eliminates long and expensive multistep internal processes and results in rapid introduction and adoption of our products. This approach significantly reduces our development costs and time to market. |

[0001511737-14-000024:mdna:7]
| • | Scalable sales and marketing model. We do not currently have, nor do we plan to hire, a direct sales force, but instead utilize the Ubiquiti Community to drive market awareness and demand for our products and solutions. This community-propagated viral marketing enables us to reach underserved and underpenetrated markets far more efficiently and cost-effectively than is possible through traditional sales models. Leveraging the information transparency of the Internet allows customers to research, evaluate and validate our solutions with the Ubiquiti Community and via third party web sites. This allows us to operate a scalable sales and marketing model and effectively create awareness of our brand and products. Word of mouth referrals from the Ubiquiti Community generate high quality leads for our distributors at relatively little cost. |

[0001511737-14-000024:mdna:8]
| • | Self-sustaining product support. The engaged members of the Ubiquiti Community have enabled us to foster a large, cost efficient, highly-scalable and, we believe, self-sustaining mechanism for rapid product support and dissemination of information. |

[0001511737-14-000024:mdna:9]
By reducing the cost of development, sales, marketing and support we are able to eliminate traditional business model inefficiencies and offer innovative solutions with disruptive price performance characteristics to our customers.

[0001511737-14-000024:mdna:10]
For the years ended June 30, 2014, 2013 and 2012, our revenue was $572.5 million, $320.8 million and $353.5 million, respectively. In the same periods, we generated a net income of $176.9 million, $80.5 million and $102.6 million, respectively. In this Annual Report on Form 10-K we refer to the fiscal years ended June 30, 2014, 2013 and 2012 as fiscal 2014, fiscal 2013 and fiscal 2012, respectively.

[0001511737-14-000024:mdna:11]
Key Components of Our Results of Operations and Financial Condition

[0001511737-14-000024:mdna:12]
Revenues

[0001511737-14-000024:mdna:13]
Our revenues are derived principally from the sale of networking hardware and management tools. In addition, while we do not sell maintenance and support separately, because we have historically included it free of charge in many of our arrangements, we attribute a portion of our systems revenues to this implied post-contract customer support (“PCS”).

[0001511737-14-000024:mdna:14]
We classify our revenues into two primary product categories, Service Provider Technology and Enterprise Technology.

[0001511737-14-000024:mdna:15]
| • | Service Provider Technology includes our airMAX, EdgeMAX and airFiber platforms, as well as embedded radio products and other 802.11 standard products including base stations, radios, backhaul equipment and Customer Premise Equipment (“CPE”). Additionally, Service Provider Technology includes antennas and other products in the 2.0 to 6.0GHz spectrum and miscellaneous products such as mounting brackets, cables and power over Ethernet adapters. |

[0001511737-14-000024:mdna:16]
| • | Enterprise Technology includes the Company's UniFi, mFi and UniFi Video platforms. |

[0001511737-14-000024:mdna:17]
We sell our products and solutions globally to service providers and enterprises primarily through our extensive network of distributors, and, to a lesser extent, original equipment manufacturers, or OEMs, and direct customers.  Sales to distributors accounted for 99%, 98% and 98% of our revenues in the years ended June 30, 2014, 2013 and 2012, respectively.  Other channel partners, such as resellers and OEMs, largely accounted for the balance of our revenues. We sell our products without any right of return.

[0001511737-14-000024:mdna:18]
Cost of Revenues

[0001511737-14-000024:mdna:19]
Our cost of revenues is comprised primarily of the costs of procuring finished goods from our contract manufacturers and chipsets that we consign to certain of our contract manufacturers. In addition, cost of revenues includes tooling, labor and other costs associated with engineering, testing and quality assurance, warranty costs, stock-based compensation, logistics related fees and excess and obsolete inventory.

[0001511737-14-000024:mdna:20]
In addition to utilizing contract manufacturers, we outsource our logistics warehousing and order fulfillment functions, which are located primarily in China, and to a lesser extent, Taiwan. We also evaluate and utilize other vendors for various portions of our supply chain from time to time. Our operations organization consists of employees and consultants engaged in the management of our contract manufacturers, new product introduction activities, logistical support and engineering.

[0001511737-14-000024:mdna:21]
Gross Profit

[0001511737-14-000024:mdna:22]
Our gross profit has been, and may in the future be, influenced by several factors including changes in product mix, target end markets for our products, pricing due to competitive pressure, production costs, foreign exchange rates and global demand for electronic components. Although we procure and sell our products in U.S. dollars, our contract manufacturers incur many costs, including labor costs, in other currencies. To the extent that the exchange rates move unfavorably for our contract manufacturers, they may try to pass these additional costs on to us, which could have a material impact on our future average selling prices and unit costs.

[0001511737-14-000024:mdna:23]
Operating Expenses

[0001511737-14-000024:mdna:24]
We classify our operating expenses as research and development and sales, general and administrative expenses.

[0001511737-14-000024:mdna:25]
| • | Research and development expenses consist primarily of salary and benefit expenses, including stock-based compensation, for employees and costs for contractors engaged in research, design and development activities, as well as costs for prototypes, facilities and travel. Over time, we expect our research and development costs to increase as we continue making significant investments in developing new products and developing new versions of our existing products. |

[0001511737-14-000024:mdna:26]
31

[0001511737-14-000024:mdna:27]
| • | Sales, general and administrative expenses include salary and benefit expenses, including stock-based compensation, for employees and costs for contractors engaged in sales, marketing and general and administrative activities, as well as the costs of legal expenses, trade shows, marketing programs, promotional materials, bad debt expense, professional services, facilities, general liability insurance and travel. As our product portfolio and targeted markets expand, we may need to employ different sales models, such as building a direct sales force. These sales models would likely increase our costs. Over time, we expect our sales, general and administrative expenses to increase in absolute dollars due to continued growth in headcount, expansion of our efforts to register and defend trademarks and patents and to support our business and operations. |

[0001511737-14-000024:mdna:28]
Deferred Revenues and Costs

[0001511737-14-000024:mdna:29]
In the event that collectability of a receivable from products we have shipped is not probable, we classify those amounts as deferred revenues on our balance sheet until such time as we receive payment of the accounts receivable. We classify the cost of products associated with these deferred revenues as deferred costs of revenues. As of June 30, 2014 and 2013, $2.1 million and $2.2 million of revenue was deferred for transactions where we lacked evidence that collectability of the receivables recorded was reasonably assured, respectively. The related deferred cost of revenues balance was $1.3 million and $1.2 million as of June 30, 2014 and 2013, respectively.

[0001511737-14-000024:mdna:30]
Also included in our deferred revenues is a portion related to PCS obligations that we estimate we will perform in the future. As of June 30, 2014 and 2013, we had deferred revenues of $2.8 million and $1.0 million, respectively, related to these obligations.

[0001511737-14-000024:mdna:31]
Critical Accounting Policies

[0001511737-14-000024:mdna:32]
We prepare our consolidated financial statements in accordance with accounting principles generally accepted in the United States of America (“GAAP”). In many cases, the accounting treatment of a particular transaction is specifically dictated by GAAP and does not require management’s judgment in its application. In other cases, management’s judgment is required in selecting among available alternative accounting standards that provide for different accounting treatment for similar transactions. The preparation of consolidated financial statements also requires us to make estimates and assumptions that affect the amounts we report as assets, liabilities, revenues, costs and expenses and affect the related disclosures. We base our estimates on historical experience and other assumptions that we believe are reasonable under the circumstances. In many instances, we could reasonably use different accounting estimates, and in some instances changes in the accounting estimates are reasonably likely to occur from period to period. Accordingly, our actual results could differ significantly from the estimates made by our management. To the extent that there are differences between our estimates and actual results, our future financial statement presentation, financial condition, results of operations and cash flows will be affected. We believe that the accounting policies discussed below are critical to understanding our historical and future performance, as these policies relate to the more significant areas involving management’s judgments and estimates.

[0001511737-14-000024:mdna:33]
Recognition of Revenues

[0001511737-14-000024:mdna:34]
Revenues consist primarily of revenues from the sale of hardware and management tools, as well as the related implied PCS. We recognize revenues when persuasive evidence of an arrangement exists, delivery has occurred, the sales price is fixed or determinable and the collectability of the resulting receivable is reasonably assured. In cases where we lack evidence that collectability of the resulting receivable is reasonably assured, we defer recognition of revenue until the receipt of cash.

[0001511737-14-000024:mdna:35]
For our sales, evidence of the arrangement consists of an order from a customer. We consider delivery to have occurred once our products have been shipped and title and risk of loss have been transferred. For our sales, these criteria are met at the time the products are transferred to the customer's shipping agent. Our arrangements with customers do not include provisions for cancellation, returns, inventory swaps or refunds that would significantly impact recognized revenues.

[0001511737-14-000024:mdna:36]
We record amounts billed to distributors for shipping and handling costs as revenues. We classify shipping and handling costs incurred by us as cost of revenues.  Deposit payments received from distributors in advance of recognition of revenues are included in current liabilities on our balance sheet and are recognized as revenues when all the criteria for recognition of revenues are met.

[0001511737-14-000024:mdna:37]
Our multi-element arrangements generally include two deliverables. The first deliverable is the hardware and software essential to the functionality of the hardware device delivered at the time of sale. The second deliverable is the implied right to PCS included with the purchase of certain products. PCS is the right to receive, on a when and if available basis, future unspecified software upgrades and features relating to the product’s essential software as well as bug fixes, email and telephone support.

[0001511737-14-000024:mdna:38]
We use a hierarchy to determine the allocation of revenues to the deliverables. The hierarchy is as follows: (i) vendor-specific objective evidence of fair value (“VSOE”), (ii) third-party evidence of selling price (“TPE”), and (iii) best estimate of the selling price (“BESP”).

[0001511737-14-000024:mdna:39]
| (i) | VSOE generally exists only when a company sells the deliverable separately and is the price actually charged by the company for that deliverable. Generally we do not sell the deliverables separately and, as such, do not have VSOE. |

[0001511737-14-000024:mdna:40]
| (ii) | TPE can be substantiated by determining the price that other parties sell similar or substantially similar offerings. We do not believe that there is accessible TPE evidence for similar deliverables. |

[0001511737-14-000024:mdna:41]
| (iii) | BESP reflects our best estimates of what the selling prices of elements would be if they were sold regularly on a stand-alone basis. We believe that BESP is the most appropriate methodology for determining the allocation of revenues among the multiple elements. |

[0001511737-14-000024:mdna:42]
We have allocated revenues between these two deliverables using the relative selling price method which is based on the BESP for all deliverables. Revenues allocated to the delivered hardware and the related essential software are recognized at the time of sale provided the other conditions for recognition of revenues have been met. Revenues allocated to the PCS are deferred and recognized on a straight-line basis over the estimated life of each of these devices which currently is two years. All costs of revenues, including estimated warranty costs, are recognized at the time of sale. Costs for research and development and sales and marketing are expensed as incurred. If the estimated life of the hardware product should change, the future rate of amortization of the revenues allocated to PCS would also change.

[0001511737-14-000024:mdna:43]
Our process for determining BESP for deliverables involves multiple factors that may vary depending upon the unique facts and circumstances related to each deliverable. For PCS, we believe our network operators and service providers would be reluctant to pay for such services separately. This view is primarily based on the fact that unspecified upgrade rights do not obligate us to provide upgrades at a particular time or at all, and do not specify to network operators and service providers which upgrades or features will be delivered. We believe that the relatively low prices of our products and our network operators, and service providers’ price sensitivity would add to their reluctance to pay for PCS. Therefore, we have concluded that if we were to sell PCS on a stand-alone basis, the selling price would be relatively low.

[0001511737-14-000024:mdna:44]
Key factors considered by us in developing the BESP for PCS include reviewing the activities of specific employees engaged in support and software development to determine the amount of time that is allocated to the development of the undelivered elements, determining the cost of this development effort, and then adding an appropriate level of gross profit to these costs.

[0001511737-14-000024:mdna:45]
Inventory and Inventory Valuation

[0001511737-14-000024:mdna:46]
Our inventories are primarily finished goods and, to a lesser extent, raw materials, which we have consigned to our contract manufacturers. Our inventories are stated at the lower of actual cost (computed on a first-in, first-out basis), or market value. Market value is based upon an estimated average selling price reduced by the estimated costs of disposal. The determination of market value involves numerous judgments including estimating average selling prices based upon recent sales, industry trends, existing customer orders, and seasonal factors. Should actual market conditions differ from our estimates, our future results of operations could be materially affected. We reduce the value of our inventory for estimated obsolescence or lack of marketability by the difference between the cost of the affected inventory and the estimated market value. Write-downs are not reversed until the related inventory has been subsequently sold or scrapped.

[0001511737-14-000024:mdna:47]
The valuation of inventory also requires us to estimate excess and obsolete inventory. The determination of excess or obsolete inventory is estimated based on a comparison of the quantity and cost of inventory on hand to our forecast of customer demand. Customer demand is dependent on many factors and requires us to use significant judgment in our forecasting process. We also make assumptions regarding the rate at which new products will be accepted in the marketplace and at which customers will transition from older products to newer products. If actual market conditions are less favorable than those projected by management, additional inventory write-downs may be required, which would have a negative impact on our gross margin. If we ultimately sell inventory that we have previously written down, our gross margins in future periods will be positively impacted.

[0001511737-14-000024:mdna:48]
Product Warranties

[0001511737-14-000024:mdna:49]
We offer warranties on certain products and record a liability for the estimated future costs associated with potential warranty claims. These warranty costs are reflected in our consolidated statement of operations and comprehensive income within cost of revenues. Our warranties are in effect for 12 months from the distributors’ purchase date of the product. Our estimates of future warranty costs are largely based on historical experience of product failure rates, material usage and service delivery costs

[0001511737-14-000024:mdna:50]
incurred in correcting product failures. Our operating results could be materially and adversely affected if future warranty claims exceed historical experiences and we are not able to recover costs from our contract manufacturers.

[0001511737-14-000024:mdna:51]
Allowance for Doubtful Accounts

[0001511737-14-000024:mdna:52]
We record an allowance for doubtful accounts for estimated probable losses on uncollectible accounts receivable. In estimating the allowance, management considers, among other factors, the aging of the accounts receivable, our historical write offs, the credit worthiness of each distributor based on payment history and general economic conditions.

[0001511737-14-000024:mdna:53]
Income Taxes

[0001511737-14-000024:mdna:54]
We account for income taxes by recognizing deferred tax assets and liabilities for the expected future tax consequences of events that have been included in our financial statements or tax returns. Deferred tax assets and liabilities are determined based on the temporary difference between the financial statement carrying amounts of existing assets and liabilities and their respective tax bases. Deferred tax assets and liabilities are measured using enacted tax rates expected to apply to taxable income in the years in which those temporary differences are expected to be recovered or settled. We establish valuation allowances when necessary to reduce deferred tax assets to the amount we expect to realize. The assessment of whether or not a valuation allowance is required often requires significant judgment including current operating results, the forecast of future taxable income and ongoing prudent and feasible tax planning initiatives.

[0001511737-14-000024:mdna:55]
In addition, our calculation of our tax liabilities involves dealing with uncertainties in the application of complex tax regulations. We may be subject to income tax audits in each of the jurisdictions in which we operate and, as a result, must also assess exposures to any potential issues arising from current or future audits of current and prior years’ tax returns. Accordingly, we must assess such potential exposures and, where necessary, provide a reserve to cover any expected loss. To the extent that we establish a reserve, our provision for income taxes would be increased. We review our potential liabilities periodically and, if necessary, record an additional charge in our provision for taxes in the period in which we determine that tax liability is greater than our original estimate. If we ultimately determine that payment of these amounts is unnecessary, we reverse the liability and recognize a tax benefit during the period in which we determine that the liability is no longer necessary.

[0001511737-14-000024:mdna:56]
Stock-based Compensation

[0001511737-14-000024:mdna:57]
We record stock-based awards at fair value as of the grant date and recognize expense, net of forfeitures, ratably on a straight-line basis over the requisite service period, which is generally the vesting term of the awards. We estimate the fair value of stock option awards on the grant date using the Black-Scholes option pricing model. The determination of the fair value of a stock-based award on the date of grant using the Black-Scholes option-pricing model is affected by our stock price on the date of grant as well as assumptions regarding a number of complex and subjective variables. These variables include our expected stock price volatility over the expected term of the award, actual and projected employee stock option exercise behaviors, the risk-free interest rate for the expected term of the award and expected dividends. Restricted stock units are valued based on the fair value of our common stock on the date of grant.  Since our initial public offering on October 14, 2011, the fair value of our common stock is determined using the closing market price of our common stock as of the date of grant.

[0001511737-14-000024:mdna:58]
34

[0001511737-14-000024:mdna:59]
Results of Operations

[0001511737-14-000024:mdna:60]
Comparison of Years Ended June 30, 2014 and 2013

[0001511737-14-000024:mdna:61]
|  | Years Ended June 30, |
|  | 2014 |  | 2013 |
|  | (In thousands, except percentages) |
| Revenues | $ | 572,464 |  |  | 100 | % |  | $ | 320,823 |  |  | 100 | % |
| Cost of revenues(1) | 318,997 |  |  | 56 | % |  | 185,489 |  |  | 58 | % |
| Gross profit | 253,467 |  |  | 44 | % |  | 135,334 |  |  | 42 | % |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development(1) | 33,962 |  |  | 6 | % |  | 20,955 |  |  | 6 | % |
| Sales, general and administrative(1)(2) | 23,560 |  |  | 4 | % |  | 21,775 |  |  | 7 | % |
| Total operating expenses | 57,522 |  |  | 10 | % |  | 42,730 |  |  | 13 | % |
| Income from operations | 195,945 |  |  | 34 | % |  | 92,604 |  |  | 29 | % |
| Interest expense and other, net | (1,334 | ) |  | * |  |  | (851 | ) |  | * |  |
| Income before provision for income taxes | 194,611 |  |  | 34 | % |  | 91,753 |  |  | 29 | % |
| Provision for income taxes | 17,674 |  |  | 3 | % |  | 11,263 |  |  | 4 | % |
| Net income and comprehensive income | $ | 176,937 |  |  | 31 | % |  | $ | 80,490 |  |  | 25 | % |
| * Less than 1% |  |  |  |  |  |  |  |
| (1) Includes stock-based compensation as follows: |  |  |  |  |  |  |  |
| Cost of revenues | $ | 590 |  |  |  |  | $ | 446 |  |  |  |
| Research and development | 2,423 |  |  |  |  | 1,433 |  |  |  |
| Sales, general and administrative | 1,893 |  |  |  |  | 1,497 |  |  |  |
| Total stock-based compensation | $ | 4,906 |  |  |  |  | $ | 3,376 |  |  |  |
| (2) Includes gain on reversal of charge for an export compliance matter | $ | (1,121 | ) |  |  |  | $ | — |  |  |  |

[0001511737-14-000024:mdna:62]
Revenues

[0001511737-14-000024:mdna:63]
Revenues increased $251.6 million, or 78%, from $320.8 million in fiscal 2013 to $572.5 million in fiscal 2014.  We believe the overall increase in revenues in fiscal 2014 was primarily driven by increased adoption of our service provider and enterprise technologies.  Additionally, during fiscal 2013 we believe we experienced lost sales due to the proliferation of counterfeit versions of our products, which also created customer uncertainty regarding the authenticity of their potential purchases.  We believe these factors contributed to a buildup in channel inventory with our distributors, further impacting our revenues during our fiscal 2013.

[0001511737-14-000024:mdna:64]
In both fiscal 2014 and fiscal 2013, Flytec Computers Inc. represented 13% of our revenues.  No other distributor or customer represented more than 10% of our revenues in fiscal 2014 or fiscal 2013.

[0001511737-14-000024:mdna:65]
Revenues by Product Type

[0001511737-14-000024:mdna:66]
|  | Years Ended June 30, |
|  | 2014 |  | 2013 |
|  | (in thousands, except percentages) |
| Service provider technology | $ | 450,663 |  |  | 79 | % |  | $ | 285,390 |  |  | 89 | % |
| Enterprise technology | 121,801 |  |  | 21 | % |  | 35,433 |  |  | 11 | % |
| Total revenues | $ | 572,464 |  |  | 100 | % |  | $ | 320,823 |  |  | 100 | % |

[0001511737-14-000024:mdna:67]
Service Provider Technology revenues increased $165.3 million, or 58%, primarily due to continued expansion of core infrastructure build-outs in our wireless markets.  Additionally, we believe we experienced significant lost sales during fiscal 2013 due to the proliferation of counterfeit versions of our products as discussed above, which also created customer uncertainty regarding the authenticity of their potential purchases.

[0001511737-14-000024:mdna:68]
35

[0001511737-14-000024:mdna:69]
Enterprise Technology revenues increased $86.4 million, primarily due to product expansion and further adoption of our UniFi technology platform.

[0001511737-14-000024:mdna:70]
Revenues by Geography

[0001511737-14-000024:mdna:71]
We have determined the geographical distribution of our product revenues based on our customers' ship-to destinations. A majority of our sales are to distributors who in turn sell to resellers or directly to end customers, which may be different countries than the initial ship-to destination.  Additionally, during fiscal 2013, we believe we experienced lost sales due to the proliferation of counterfeit versions of our products, which also created customer uncertainty regarding the authenticity of their potential purchases.  The following are our revenues by geography for fiscal 2014 and fiscal 2013 (in thousands, except percentages):

[0001511737-14-000024:mdna:72]
|  | Years Ended June 30, |
|  | 2014 |  | 2013 |
| North America(1) | $ | 142,438 |  |  | 25 | % |  | $ | 84,820 |  |  | 26 | % |
| South America | 109,584 |  |  | 19 | % |  | 65,764 |  |  | 21 | % |
| Europe, the Middle East and Africa | 247,009 |  |  | 43 | % |  | 127,860 |  |  | 40 | % |
| Asia Pacific | 73,433 |  |  | 13 | % |  | 42,379 |  |  | 13 | % |
| Total revenues | $ | 572,464 |  |  | 100 | % |  | $ | 320,823 |  |  | 100 | % |

[0001511737-14-000024:mdna:73]
| (1) | Revenue for the United States was $136.6 million and $80.6 million in fiscal 2014 and fiscal 2013, respectively. |

[0001511737-14-000024:mdna:74]
Cost of Revenues and Gross Profit

[0001511737-14-000024:mdna:75]
Cost of revenues increased $133.5 million, or 72%, from $185.5 million in fiscal 2013 to $319.0 million in fiscal 2014.  The increase in cost of revenues in fiscal 2014 was primarily due to increased revenues and to a lesser extent, changes in product mix.

[0001511737-14-000024:mdna:76]
Gross profit as a percentage of revenue increased to 44% in fiscal 2014 compared to 42% in fiscal 2013, reflecting increasing economies of scale, a one-time benefit from a rebate program with one of our vendors, and changes in product mix, partially offset by an increase in our provision for inventory obsolescence.

[0001511737-14-000024:mdna:77]
Operating Expenses

[0001511737-14-000024:mdna:78]
Research and Development

[0001511737-14-000024:mdna:79]
Research and development expenses increased $13.0 million, or 62%, from $21.0 million in fiscal 2013 to $34.0 million in fiscal 2014. As a percentage of revenues, research and development expenses remained flat at 6% in both fiscal 2014 and 2013. The increase in research and development expenses in absolute dollars was primarily due to increases in headcount as we broadened our research and development activities to introduce new products and new versions of existing products.  Over time, we expect our research and development costs to increase in absolute dollars as we continue making significant investments in developing new products and developing new versions of our existing products.

[0001511737-14-000024:mdna:80]
Sales, General and Administrative

[0001511737-14-000024:mdna:81]
Sales, general and administrative expenses increased $1.8 million, or 8%, from $21.8 million in fiscal 2013 to $23.6 million in fiscal 2014. As a percentage of revenues, sales, general and administrative expenses decreased from 7% in fiscal 2013 to 4% in fiscal 2014.  Sales, general and administrative expenses increased in fiscal 2014 compared to fiscal 2013 primarily due to increased marketing activity, increased professional fees, primarily related to the ancillary support of certain management functions, and overall increases in headcount to further expand our marketing and administrative functions to support our revenue growth, partially offset by decreases in legal fees from reduced spending on anti-counterfeiting efforts, decreases to our allowance for doubtful accounts and the partial reversal of our accrual relating to the settlement agreement with OFAC in March 2014.  As a percentage of revenues, sales, general and administrative expenses decreased primarily due to our overall revenue increase. Over time, we expect our sales, general and administrative expenses to increase in absolute dollars due to continued efforts to protect our intellectual property and growth in headcount to support the growth in business and operations.

[0001511737-14-000024:mdna:82]
Interest Expense and Other, Net

[0001511737-14-000024:mdna:83]
Interest expense and other, net was $1.3 million for fiscal 2014, representing an increase of $483,000 from $851,000 for fiscal 2013.  The increase in fiscal 2014 as compared to fiscal 2013 was primarily due a loss on extinguishment of debt of $458,000 associated with the retirement of our debt with East West Bank.

[0001511737-14-000024:mdna:84]
Provision for Income Taxes

[0001511737-14-000024:mdna:85]
Our provision for income taxes increased $6.4 million, or 57%, from $11.3 million for fiscal 2013 to $17.7 million for fiscal 2014.  Our effective tax rate decreased to 9% for fiscal 2014 as compared to 12% fiscal 2013.   The lower effective tax rate in fiscal 2014 was primarily due to a larger percentage of our overall profitability occurring in foreign jurisdictions with lower income tax rates.

[0001511737-14-000024:mdna:86]
Comparison of Years Ended June 30, 2013 and 2012

[0001511737-14-000024:mdna:87]
|  | Years Ended June 30, |
|  | 2013 |  | 2012 |
|  | (In thousands, except percentages) |
| Revenues | $ | 320,823 |  |  | 100 | % |  | $ | 353,517 |  |  | 100 | % |
| Cost of revenues(1) | 185,489 |  |  | 58 | % |  | 202,514 |  |  | 57 | % |
| Gross profit | 135,334 |  |  | 42 | % |  | 151,003 |  |  | 43 | % |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development(1) | 20,955 |  |  | 6 | % |  | 16,699 |  |  | 5 | % |
| Sales, general and administrative(1)(2) | 21,775 |  |  | 7 | % |  | 9,012 |  |  | 3 | % |
| Total operating expenses | 42,730 |  |  | 13 | % |  | 25,711 |  |  | 8 | % |
| Income from operations | 92,604 |  |  | 29 | % |  | 125,292 |  |  | 35 | % |
| Interest expense and other, net | (851 | ) |  | * |  |  | (1,269 | ) |  | * |  |
| Income before provision for income taxes | 91,753 |  |  | 29 | % |  | 124,023 |  |  | 35 | % |
| Provision for income taxes | 11,263 |  |  | 4 | % |  | 21,434 |  |  | 6 | % |
| Net income and comprehensive income | $ | 80,490 |  |  | 25 | % |  | $ | 102,589 |  |  | 29 | % |
| * Less than 1% |  |  |  |  |  |  |  |
| (1) Includes stock-based compensation as follows: |  |  |  |  |  |  |  |
| Cost of revenues | $ | 446 |  |  |  |  | $ | 117 |  |  |  |
| Research and development | 1,433 |  |  |  |  | 542 |  |  |  |
| Sales, general and administrative | 1,497 |  |  |  |  | 834 |  |  |  |
| Total stock-based compensation | $ | 3,376 |  |  |  |  | $ | 1,493 |  |  |  |
| (2) Includes a gain from a trademark coexistence agreement as follows: | $ | — |  |  |  |  | $ | (1,500 | ) |  |  |

[0001511737-14-000024:mdna:88]
Revenues

[0001511737-14-000024:mdna:89]
Revenues decreased $32.7 million, or 9%, from $353.5 million in fiscal 2012 to $320.8 million in fiscal 2013. We believe the overall decrease in revenues in fiscal 2013 was primarily driven by lost sales, predominantly during the first nine months of fiscal 2013 due to the proliferation of counterfeit versions of our products, which also created customer uncertainty regarding the authenticity of their potential purchases. We believe these factors contributed to a buildup in channel inventory with our distributors, further impacting our revenues during the first nine months of fiscal 2013. This has had the most significant impact on our airMAX platform which decreased $21.1 million in fiscal 2013 compared to fiscal 2012.

[0001511737-14-000024:mdna:90]
In fiscal 2013, revenues from Flytec represented 13% of our revenues. In fiscal 2012, revenues from Flytec and Streakwave represented 16% and 10% of our revenues, respectively. No other distributor or customer represented more than 10% of our revenues in fiscal 2013 or fiscal 2012.

[0001511737-14-000024:mdna:91]
37

[0001511737-14-000024:mdna:92]
Revenues by Product Type

[0001511737-14-000024:mdna:93]
|  | Years Ended June 30, |
|  | 2013 |  | 2012 |
|  | (in thousands, except percentages) |
| Service provider technology | $ | 285,390 |  |  | 89 | % |  | $ | 321,648 |  |  | 91 | % |
| Enterprise technology | 35,433 |  |  | 11 | % |  | 31,869 |  |  | 9 | % |
| Total revenues | $ | 320,823 |  |  | 100 | % |  | $ | 353,517 |  |  | 100 | % |

[0001511737-14-000024:mdna:94]
Service Provider Technology revenues decreased $36.3 million, or 11%, from $321.6 million in fiscal 2012 to $285.4 million in fiscal 2013.  We believe we experienced significant lost sales during fiscal 2013 due to the proliferation of counterfeit versions of our products as discussed above, which also created customer uncertainty regarding the authenticity of their potential purchases.

[0001511737-14-000024:mdna:95]
Enterprise Technology revenues increased $3.6 million, or 11%, from $31.9 million in fiscal 2012 to $35.4 million in fiscal 2013.  The increase in Enterprise Technology revenues in fiscal 2013 was primarily due to further adoption of our UniFi technology platform.

[0001511737-14-000024:mdna:96]
Revenues by Geography

[0001511737-14-000024:mdna:97]
We generally forward products directly from our manufacturers to our customers via logistics distribution hubs in Asia.  Beginning in the quarter ended December 31, 2012, our products were predominantly routed through a third party logistics provider in China and prior to the quarter ended December 31, 2012, our products were predominantly delivered to our customers through distribution hubs in Hong Kong.  Our logistics provider, in turn, ships to other locations throughout the world. We have determined the geographical distribution of our product revenues based on our customers' ship-to destinations. A majority of our sales are to distributors who in turn sell to resellers or directly to end customers.  We believe the decline in revenues in all regions, and most significantly in South America, during the fiscal year ended June 30, 2013 as compared to June 30, 2012 was primarily driven by the proliferation of counterfeit versions of our products, which has also created customer uncertainty regarding the authenticity of their potential purchases. The following are our revenues by geography for fiscal 2013 and fiscal 2012 (in thousands, except percentages):

[0001511737-14-000024:mdna:98]
|  | Years Ended June 30, |
|  | 2013 |  | 2012 |
| North America(1) | $ | 84,820 |  |  | 26 | % |  | $ | 88,309 |  |  | 25 | % |
| South America | 65,764 |  |  | 21 | % |  | 88,325 |  |  | 25 | % |
| Europe, the Middle East and Africa | 127,860 |  |  | 40 | % |  | 130,494 |  |  | 37 | % |
| Asia Pacific | 42,379 |  |  | 13 | % |  | 46,389 |  |  | 13 | % |
| Total revenues | $ | 320,823 |  |  | 100 | % |  | $ | 353,517 |  |  | 100 | % |

[0001511737-14-000024:mdna:99]
(1) Revenue for the United States was $80.6 million and $84.3 million in fiscal 2013 and fiscal 2012, respectively.

[0001511737-14-000024:mdna:100]
Cost of Revenues and Gross Profit

[0001511737-14-000024:mdna:101]
Cost of revenues decreased $17.0 million, or 8%, from $202.5 million in fiscal 2012 to $185.5 million in fiscal 2013.  The decreases in cost of revenues in fiscal 2013 was primarily due to decreased revenues and to a lesser extent, changes in product mix.

[0001511737-14-000024:mdna:102]
Gross profit as a percentage of revenue decreased to 42% in fiscal 2013 compared to 43% in fiscal 2012. The decrease in gross profit percentage in the fiscal  2013  reflects increases in variable operating costs and changes in product mix.

[0001511737-14-000024:mdna:103]
Operating Expenses

[0001511737-14-000024:mdna:104]
Research and Development

[0001511737-14-000024:mdna:105]
Research and development expenses increased $4.3 million, or 25%, from $16.7 million in fiscal 2012 to $21.0 million in fiscal 2013. As a percentage of revenues, research and development expenses increased from 5% in fiscal 2012 to 6% in fiscal 2013. The increase in research and development expenses in absolute dollars was largely due to increases in headcount and facilities

[0001511737-14-000024:mdna:106]
related costs as we broadened our research and development activities to new product areas. As a percentage of revenues, research and development expenses increased in both periods primarily due to our overall decrease in revenues.

[0001511737-14-000024:mdna:107]
Sales, General and Administrative

[0001511737-14-000024:mdna:108]
Sales, general and administrative expenses increased $12.8 million, or 142%, from $9.0 million in fiscal 2012 to $21.8 million in fiscal 2013. As a percentage of revenues, sales, general and administrative expenses increased from 3% in fiscal 2012 to 7% in fiscal 2013.  Sales, general and administrative expenses increased in absolute dollars and as a percentage of revenue due largely to increased legal expenses of $4.3 million, primarily associated with our anti-counterfeiting litigation, increased professional fees of $2.0 million, primarily related to the ancillary support of certain management functions,  increases in headcount and related salaries of $1.0 million.  Additionally, in fiscal 2012 we recorded a gain of $1.5 million from a trademark coexistence agreement within sales, general and administrative expenses.

[0001511737-14-000024:mdna:109]
Interest Expense and Other, Net

[0001511737-14-000024:mdna:110]
Interest expense and other, net was $851,000 for fiscal 2013, representing a decrease of $418,000 from $1.3 million for fiscal 2012.  The decrease in fiscal 2013 as compared to fiscal 2012 was primarily due to the additional interest coupon on our convertible subordinated promissory notes issued as part of the repurchase of Series A convertible preferred stock from entities affiliated with Summit Partners, L.P. in July 2011.  The convertible subordinated promissory notes were repaid in full in October 2011.  Interest expense during fiscal 2013 consisted primarily of interest related to our term loan and credit facility borrowings with East West Bank.

[0001511737-14-000024:mdna:111]
Provision for Income Taxes

[0001511737-14-000024:mdna:112]
Our provision for income taxes decreased $10.2 million, or 47%, from $21.4 million for fiscal 2012 to $11.3 million for fiscal 2013.  Our effective tax rate decreased to 12% for fiscal 2013 as compared to 17% fiscal 2012.   The decrease in our effective tax rate was primarily due to a larger percentage of our overall profitability occurring in foreign jurisdictions with lower income tax rates.  Additionally, on January 2, 2013, the American Taxpayer Relief Act of 2012 ("the Act") was signed into law. One of the provisions of the Act provides a retroactive extension of the research and experimentation tax credit ("R&D credit") through December 31, 2013, which had expired on December 31, 2011.  We recognized a tax benefit of $539,000 during the third quarter of fiscal 2013 as a result of the retroactive extension of the R&D credit.

[0001511737-14-000024:mdna:113]
Liquidity and Capital Resources

[0001511737-14-000024:mdna:114]
Sources and Uses of Cash

[0001511737-14-000024:mdna:115]
Since inception, our operations primarily have been funded through cash generated by operations.  We had cash and cash equivalents of $347.1 million, $227.8 million and $122.1 million at June 30, 2014, 2013 and 2012, respectively.

[0001511737-14-000024:mdna:116]
Consolidated Cash Flow Data

[0001511737-14-000024:mdna:117]
The following table sets forth the major components of our consolidated statements of cash flows data for the periods presented:

[0001511737-14-000024:mdna:118]
|  | Years Ended June 30, |
|  | 2014 |  | 2013 |  | 2012 |
|  | (In thousands) |
| Net cash provided by operating activities | $ | 121,327 |  |  | $ | 131,891 |  |  | $ | 81,788 |  |
| Net cash used in investing activities | (4,045 | ) |  | (5,363 | ) |  | (3,310 | ) |
| Net cash provided by (used in) financing activities | 1,989 |  |  | (20,762 | ) |  | (32,779 | ) |
| Net increase in cash and cash equivalents | $ | 119,271 |  |  | $ | 105,766 |  |  | $ | 45,699 |  |

[0001511737-14-000024:mdna:119]
Cash Flows from Operating Activities

[0001511737-14-000024:mdna:120]
Net cash provided by operating activities in the fiscal 2014 consisted primarily of net income of $176.9 million partially offset by net changes in operating assets and liabilities that resulted in net cash outflows of $62.9 million. These changes consisted primarily of a $33.8 million increase in inventory due to our efforts to build warehouse stock levels and ultimately decrease lead times, an $18.3 million increase in accounts receivable due to our overall increase in revenue, a $9.6 million increase in prepaid expenses and other current assets due to timing of deposit payments with our suppliers, a $6.9 million decrease in accounts payable and accrued liabilities due to the timing of payments with our vendors, a $3.9 million net increase in taxes

[0001511737-14-000024:mdna:121]
payable and prepaid income taxes due the timing of federal tax payments, and a $1.9 million increase in deferred revenues and related costs. Additionally, our net income included non-cash adjustments due to stock-based compensation, depreciation and amortization, increases to our provision for doubtful accounts and write-downs for inventory obsolescence and an excess tax benefit from stock-based awards. The net of these non-cash adjustments resulted in an increase of our net cash provided by operating activities of $7.3 million.

[0001511737-14-000024:mdna:122]
Net cash provided by operating activities in the fiscal 2013 consisted primarily of net income of $80.5 million and net changes in operating assets and liabilities that resulted in net cash inflows of $45.9 million. These changes consisted primarily of a $38.7 million decrease in accounts receivable due to improved cash collections, a $10.2 million increase in accounts payable and accrued liabilities due to the timing of payments with our vendors, a $9.0 million increase in inventory due to increased inventory on hand as a result of a transition to a third-party logistics provider during December 2012, a $6.6 million increase in taxes payable due the timing of federal tax payments, a $1.9 million increase in prepaid expenses and other current assets due to an increase in overall business activity and a $1.2 million increase in deferred revenues and related costs. Additionally, our net income included non-cash adjustments due to stock-based compensation, depreciation and amortization, increases to our provision for doubtful accounts and write-downs for inventory obsolescence and an excess tax benefit from stock-based awards. The net of these non-cash adjustments resulted in an increase of our net cash provided by operating activities of $5.5 million.

[0001511737-14-000024:mdna:123]
Net cash provided by operating activities in fiscal 2012 consisted primarily of net income of $102.6 million offset by changes in operating assets and liabilities. These changes consisted primarily of a $36.6 million increase in accounts receivable due to our overall revenue growth and slower payment patterns from our customers, a $16.5 million increase in accounts payable and accrued liabilities due to increased overall business activity, a $9.5 million increase in taxes payable due to our higher profitability, a $3.7 million decrease in prepaid expenses and other current assets due primarily to decreased deposits with our vendors and a $2.3 million increase in inventories related to increases in our overall business activity. Additionally, our net income included non-cash adjustments due to stock-based compensation, depreciation and amortization, adjustments to our provisions for doubtful accounts and inventory obsolescence and an excess tax benefit from stock-based awards. The net of these non-cash adjustments resulted in a reduction of our net cash provided by operating activities of $11.6 million.

[0001511737-14-000024:mdna:124]
Cash Flows from Investing Activities

[0001511737-14-000024:mdna:125]
Our investing activities consist solely of capital expenditures and purchases of intangible assets. Capital expenditures for fiscal 2014, fiscal 2013 and fiscal 2012 were $3.8 million, $4.1 million and $3.3 million, respectively. Additionally, we had cash outflows related to intangible assets of $219,000 and $1.2 million during fiscal 2014 and fiscal 2013, respectively, consisting primarily of legal costs associated with the trademark applications.

[0001511737-14-000024:mdna:126]
Cash Flows from Financing Activities

[0001511737-14-000024:mdna:127]
We had $2.0 million of cash provided by financing activities during fiscal 2014.  On May 5, 2014, we entered into a credit agreement, or the Credit Agreement, with Wells Fargo Bank, National Association, or Wells Fargo, the financial institutions named as lenders therein, and Wells Fargo as administrative agent for the lenders, that provides for a $150 million senior secured revolving credit facility, with an option to request an increase in the amount of the credit facility by up to an additional $50 million (any such increase to be in each lender’s sole discretion).  We initially borrowed $72.3 million under the Credit Agreement, which was used to repay obligations under our Loan Agreement with East West Bank and to pay transaction fees and costs.

[0001511737-14-000024:mdna:128]
On May 29, 2014, we announced that our Board of Directors had authorized us to repurchase up to $75 million of our common stock. The share repurchase program commenced on June 2, 2014.  To date no shares have been repurchased under the program.

[0001511737-14-000024:mdna:129]
We used $20.8 million of cash in financing activities during fiscal 2013.  On August 7, 2012, we entered into a Loan and Security Agreement, or Loan Agreement, with U.S. Bank, as syndication agent, and East West Bank, as administrative agent for the lenders party to the Loan Agreement. The Loan Agreement replaced the EWB Loan Agreement discussed below. The Loan Agreement provided for (i) a $50.0 million revolving credit facility, with a $5.0 million sublimit for the issuance of letters of credit and a $5.0 million sublimit for the making of swingline loan advances, or the Revolving Credit Facility, and (ii) a $50.0 million term loan facility, or the Term Loan Facility.  We borrowed $20.8 million of term loans under the Term Loan Facility, bringing the total borrowed to $50.0 million, to partially fund our common stock repurchase program.  No borrowings remain available under the Term Loan Facility.  On November 21, 2012, we borrowed $10.0 million under the Revolving Credit Facility.  On December 20, 2012, we borrowed an additional $20.0 million under the Revolving Credit Facility to fund our special cash dividend.

[0001511737-14-000024:mdna:130]
40

[0001511737-14-000024:mdna:131]
On August 9, 2012, we announced that our Board of Directors authorized us to repurchase up to $100.0 million of our common stock. The share repurchase program commenced August 13, 2012 and expired one year later. During fiscal 2013 we repurchased 5,159,050 shares for a total cost of $54.4 million.

[0001511737-14-000024:mdna:132]
On December 14, 2012, we announced that our Board of Directors had authorized a special cash dividend of $0.18 per share for each share of common stock outstanding on December 24, 2012.  The aggregate dividend payment of $15.7 million was paid on December 28, 2012 to stockholders of record on December 24, 2012.  We do not anticipate paying any cash dividends in the foreseeable future.

[0001511737-14-000024:mdna:133]
We used $32.8 million of cash in financing activities during fiscal 2012.  In July 2011, we repurchased an aggregate of 12,041,700 shares of our Series A preferred stock from entities affiliated with Summit Partners, L.P., one of our major stockholders, at a price of $8.97 per share for an aggregate consideration of $108.0 million. Of the aggregate purchase price, $40.0 million was paid in cash at the time of closing and the balance of the shares were paid for through the issuance of convertible subordinated promissory notes in the aggregate principal amount of $68.0 million. On September 15, 2011, $34.0 million was paid against the notes reducing the aggregate principal amount outstanding to $34.0 million.

[0001511737-14-000024:mdna:134]
On September 15, 2011, we entered into a Loan and Security Agreement with East West Bank, or the EWB Loan Agreement. The EWB Loan Agreement consisted of a $35.0 million term loan facility and a $5.0 million revolving line of credit facility. The term loan was scheduled to mature on September 15, 2016 with principal and interest to be repaid in 60 monthly installments. During the three months ended September 30, 2011, we used $34.0 million of the term loan to repay a portion of our outstanding convertible subordinated promissory notes held by entities affiliated with Summit Partners, L.P. The EWB Agreement was replaced by the Loan Agreement on August 7, 2012 as discussed above.

[0001511737-14-000024:mdna:135]
Liquidity

[0001511737-14-000024:mdna:136]
We believe our existing cash and cash equivalents, cash provided by operations and the availability of additional funds under our loan agreements will be sufficient to meet our working capital and capital expenditure needs for at least the next twelve months. However, this estimate is based on a number of assumptions that may prove to be wrong and we could exhaust our available cash and cash equivalents earlier than presently anticipated.  Our future capital requirements may vary materially from those currently planned and will depend on many factors, including our rate of revenue growth, the timing and extent of spending to support development efforts, the timing of new product introductions, market acceptance of our products and overall economic conditions. As of June 30, 2014, we held $307.6 million of our $347.1 million of cash and cash equivalents in accounts of our subsidiaries outside of the United States and we will incur significant tax liabilities if we decide to repatriate those amounts.

[0001511737-14-000024:mdna:137]
On June 18, 2013, we completed a secondary offering of 7,031,464 shares of common stock at an offering price of $16.00 per share, which included 531,464 shares sold in connection with the partial exercise of the option to purchase additional shares granted to the underwriters.  All of the shares sold in the offering were sold by our existing stockholders, including entities affiliated with Summit Partners, L.P., and our chief executive officer, Robert J. Pera.  We did not sell any shares in the offering, and as such, we did not receive any proceeds from the offering.

[0001511737-14-000024:mdna:138]
We believe that the combination of our existing United States cash and cash equivalent balances and future United States operating cash flows are sufficient to meet our ongoing United States operating expenses and debt repayment obligations for at least the next twelve months.

[0001511737-14-000024:mdna:139]
We earn a significant amount of our operating income outside the United States, which is deemed to be indefinitely reinvested in foreign jurisdictions. As a result, a significant portion of our cash and short-term investments are held by foreign subsidiaries. We currently do not intend nor foresee a need to repatriate these funds. We expect existing domestic cash and short-term investments and cash flows from operations to continue to be sufficient to fund our domestic operating activities and cash commitments for investing and financing activities, such as regular quarterly dividends, debt repayment, and capital expenditures, for at least the next 12 months and thereafter for the foreseeable future.

[0001511737-14-000024:mdna:140]
If we should require more capital in the United States than is generated by our domestic operations, for example to fund significant discretionary activities such as business acquisitions and share repurchases, we could elect to repatriate future earnings from foreign jurisdictions or raise capital in the United States through debt or equity issuances. These alternatives could result in higher effective tax rates, increased interest expense, or dilution of our earnings. We have borrowed funds domestically and continue to believe we have the ability to do so at reasonable interest rates.

[0001511737-14-000024:mdna:141]
Contractual Obligations and Off-Balance Sheet Arrangements

[0001511737-14-000024:mdna:142]
The following table summarizes our contractual obligations as of June 30, 2014:

[0001511737-14-000024:mdna:143]
|  |  | Payments Due by Period |  |  |
|  |  | Less Than 1 Year |  | 1-3 Years |  | 4-5 years |  | Over 5 years |  | Total |
|  |  | (In thousands) |  |  |
| Operating leases |  | $ | 2,947 |  |  | $ | 4,561 |  |  | $ | 395 |  |  | $ | — |  |  | $ | 7,903 |  |
| Debt payment obligations |  | — |  |  | — |  |  | 72,254 |  |  | — |  |  | 72,254 |  |
| Interest payments on debt payment obligations |  | 1,012 |  |  | 2,025 |  |  | 1,869 |  |  | — |  |  | 4,906 |  |
| Total |  | $ | 3,959 |  |  | $ | 6,586 |  |  | $ | 74,518 |  |  | $ | — |  |  | $ | 85,063 |  |

[0001511737-14-000024:mdna:144]
We lease our headquarters in San Jose, California and other locations worldwide under non-cancelable operating leases that expire at various dates through fiscal 2019.

[0001511737-14-000024:mdna:145]
On May 5, 2014, we entered into a credit agreement ("the Credit Agreement") with Wells Fargo Bank, National Association, or Wells Fargo, the financial institutions named as lenders therein, and Wells Fargo as administrative agent for the lenders, that provides for a $150 million senior secured revolving credit facility, with an option to request an increase in the amount of the credit facility by up to an additional $50 million (any such increase to be in each lender’s sole discretion).  We initially borrowed $72.3 million under the Credit Agreement, which was used to repay obligations under our Loan Agreement with East West Bank and to pay transaction fees and costs.

[0001511737-14-000024:mdna:146]
We subcontract with other companies to manufacture our products. During the normal course of business, our contract manufacturers procure components based upon orders placed by us. If we cancel all or part of the orders, we may still be liable to the contract manufacturers for the cost of the components purchased by the subcontractors to manufacture our products. We periodically review the potential liability and to date no significant liabilities for cancellations have been recorded. Our consolidated financial position and results of operations could be negatively impacted if we were required to compensate the contract manufacturers for any unrecorded liabilities incurred. We had $20.9 million in non-cancelable purchase commitments as of June 30, 2014, the related expenses of which are expected to be incurred in future periods.

[0001511737-14-000024:mdna:147]
As of June 30, 2014, we had gross unrecognized tax benefits of $14.5 million and an additional $695,000 for gross interest classified as noncurrent liabilities. At this time, we are unable to make a reasonably reliable estimate of the timing of payments in individual years in connection with these tax liabilities; therefore, such amounts are not included in the above contractual obligation table.

[0001511737-14-000024:mdna:148]
Commitments and Contingencies

[0001511737-14-000024:mdna:149]
In May 2011, we filed a self-disclosure statement with the U.S. Commerce Department, Bureau of Industry and Security’s (“BIS”) Office of Export Enforcement (“OEE”) relating a review conducted by us regarding certain export transactions from 2008 through March 2011 in which products may have been later resold into Iran by third parties. In June 2011, we also filed a self-disclosure statement with the U.S. Department of the Treasury’s Office of Foreign Asset Control (“OFAC”) regarding these compliance issues. In August 2011, we received a warning letter from OEE stating that OEE had not referred the findings of our review for criminal or administrative prosecution and closed the investigation of us without penalty. Based upon its review of the matter, OFAC identified certain apparent violations (“Apparent Violations”) of the Iranian Transactions and Sanctions Regulations by us during the period of in or about March 2008 through in or about February 2011. On March 4, 2014, we entered into a settlement agreement with OFAC resolving this administrative matter. Pursuant to the terms of the settlement agreement, we agreed to make a one-time payment to the U.S. Department of the Treasury in the amount of $504,000 in consideration of OFAC agreeing to release and forever discharge us from any and all civil liability in connection with the Apparent Violations.  We previously accrued a reserve of $1.6 million relating to this matter in fiscal 2010 and, accordingly, reversed the excess of the accrual of $1.1 million as of the effective date of the settlement agreement.

[0001511737-14-000024:mdna:150]
Warranties and Indemnifications

[0001511737-14-000024:mdna:151]
Our products are generally accompanied by a 12 month warranty, which covers both parts and labor. Generally the distributor is responsible for the freight costs associated with warranty returns, and we absorb the freight costs of replacing items under warranty. In accordance with the Financial Accounting Standards Board’s (“FASB’s”), Accounting Standards Codification (“ASC”), 450-30, Loss Contingencies, we record an accrual when we believe it is estimable and probable based upon historical experience. We record a provision for estimated future warranty work in cost of goods sold upon recognition of revenues and we review the resulting accrual regularly and periodically adjust it to reflect changes in warranty estimates.

[0001511737-14-000024:mdna:152]
42

[0001511737-14-000024:mdna:153]
We may in the future enter into standard indemnification agreements with many of our distributors and OEMs, as well as certain other business partners in the ordinary course of business. These agreements may include provisions for indemnifying the distributor, OEM or other business partner against any claim brought by a third party to the extent any such claim alleges that a Ubiquiti product infringes a patent, copyright or trademark or violates any other proprietary rights of that third party. The maximum amount of potential future indemnification is unlimited. The maximum potential amount of future payments we could be required to make under these indemnification agreements is not estimable.

[0001511737-14-000024:mdna:154]
We have agreed to indemnify our directors, officers and certain other employees for certain events or occurrences, subject to certain limits, while such persons are or were serving at our request in such capacity. We may terminate the indemnification agreements with these persons upon the termination of their services with us but termination will not affect claims for indemnification related to events occurring prior to the effective date of termination. The maximum amount of potential future indemnification is unlimited. We have a Directors and Officers insurance policy that limits our potential exposure. We believe the fair value of these indemnification agreements is minimal.  We had not recorded any liabilities for these agreements as of June 30, 2014 or 2013.

[0001511737-14-000024:mdna:155]
Based upon our historical experience and information known as of the date of this report, we do not believe it is likely that we will have significant liability for the above indemnities at June 30, 2014.

[0001511737-14-000024:mdna:156]
Off-Balance Sheet Arrangements

[0001511737-14-000024:mdna:157]
As of June 30, 2014 and 2013, we had no off-balance sheet arrangements other than those indemnification agreements described above.

[0001511737-14-000024:mdna:158]
Recent Accounting Pronouncements

[0001511737-14-000024:mdna:159]
In June 2014, the Financial Accounting Standards Board, or FASB, issued a new accounting standard update on revenue from contracts with customers.  The core principle of the guidance is that an entity should recognize revenue to depict the transfer of promised goods or services to customers in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services.  To achieve that core principle, an entity should apply the following steps:

[0001511737-14-000024:mdna:160]
Step 1: Identify the contract(s) with a customer.

[0001511737-14-000024:mdna:161]
Step 2: Identify the performance obligations in the contract.

[0001511737-14-000024:mdna:162]
Step 3: Determine the transaction price.

[0001511737-14-000024:mdna:163]
Step 4: Allocate the transaction price to the performance obligations in the contract.

[0001511737-14-000024:mdna:164]
Step 5: Recognize revenue when (or as) the entity satisfies a performance obligation.

[0001511737-14-000024:mdna:165]
An entity should disclose sufficient information to enable users of financial statements to understand the nature, amount, timing, and uncertainty of revenue and cash flows arising from contracts with customers. Qualitative and quantitative information is required about contracts with customers, significant judgments and any assets recognized from the costs to obtain or fulfill a contract.   The guidance will be effective for us beginning July 1, 2017.  We are currently assessing the impact of this new guidance.

[0001511737-14-000024:mdna:166]
In July 2013, the FASB issued a new accounting standard update on the financial statement presentation of unrecognized tax benefits.  The new guidance provides that a liability related to an unrecognized tax benefit would be presented as a reduction of a deferred tax asset for a new operating loss carryforward, a similar tax loss or a tax credit carryforward if such settlement is required or expected in the event the uncertain tax position is disallowed.  The new guidance will became effective for us on July 1, 2014 and it should be applied prospectively to unrecognized tax benefits that exist as of the effective date with retrospective application permitted.  We have assessed the impact of this new guidance, however we do not expect adoption to have a significant impact on our consolidated financial statements.

[0001511737-14-000024:mdna:167]
Non-GAAP Financial Measures

[0001511737-14-000024:mdna:168]
Regulation G, conditions for use of Non-Generally Accepted Accounting Principles (“Non-GAAP”) financial measures, and other SEC regulations define and prescribe the conditions for use of certain Non-GAAP financial information. To supplement our consolidated financial results presented in accordance with GAAP, we use Non-GAAP financial measures which are adjusted from the most directly comparable GAAP financial measures to exclude certain items, as described below. Management believes that these Non-GAAP financial measures reflect an additional and useful way of viewing aspects of our operations that, when viewed in conjunction with our GAAP results, provide a more comprehensive understanding of the various factors and trends affecting our business and operations. Non-GAAP financial measures used by us include net income or loss and diluted net income or loss per share.

[0001511737-14-000024:mdna:169]
43

[0001511737-14-000024:mdna:170]
Our Non-GAAP measures primarily exclude stock-based compensation, net of taxes and other special charges and credits. Additionally, in fiscal 2014 we had a gain on the reversal of a charge for an export compliance matter and in fiscal 2012 we had a gain of $1.5 million from a trademark coexistence agreement.  Management believes these Non-GAAP financial measures provide meaningful supplemental information regarding our strategic and business decision making, internal budgeting, forecasting and resource allocation processes. In addition, these Non-GAAP financial measures facilitate management’s internal comparisons to our historical operating results and comparisons to competitors’ operating results.

[0001511737-14-000024:mdna:171]
We use each of these Non-GAAP financial measures for internal managerial purposes, when providing our financial results and business outlook to the public and to facilitate period-to-period comparisons. Management believes that these Non-GAAP measures provide meaningful supplemental information regarding our operational and financial performance of current and historical results. Management uses these Non-GAAP measures for strategic and business decision making, internal budgeting, forecasting and resource allocation processes. In addition, these Non-GAAP financial measures facilitate management’s internal comparisons to our historical operating results and comparisons to competitors’ operating results.

[0001511737-14-000024:mdna:172]
The following table shows our Non-GAAP financial measures:

[0001511737-14-000024:mdna:173]
|  | Years Ended June 30, |
|  | 2014 |  | 2013 |  | 2012 |
|  | (In thousands, except per share amounts) |
| Non-GAAP net income and comprehensive income | $ | 179,208 |  |  | $ | 82,515 |  |  | $ | 102,585 |  |
| Non-GAAP diluted net income per share of common stock | $ | 2.00 |  |  | $ | 0.91 |  |  | $ | 1.09 |  |

[0001511737-14-000024:mdna:174]
We believe that providing these Non-GAAP financial measures, in addition to the GAAP financial results, are useful to investors because they allow investors to see our results “through the eyes” of management as these Non-GAAP financial measures reflect our internal measurement processes. Management believes that these Non-GAAP financial measures enable investors to better assess changes in each key element of our operating results across different reporting periods on a consistent basis and provides investors with another method for assessing our operating results in a manner that is focused on the performance of our ongoing operations.

[0001511737-14-000024:mdna:175]
The following table shows a reconciliation of GAAP net income and comprehensive income to non-GAAP net income and comprehensive income:

[0001511737-14-000024:mdna:176]
|  | Years Ended June 30, |
|  | 2014 |  | 2013 |  | 2012 |
|  | (In thousands, except pershare amounts) |
| Net income and comprehensive income | $ | 176,937 |  |  | $ | 80,490 |  |  | $ | 102,589 |  |
| Stock-based compensation: |  |  |  |  |  |
| Cost of revenues | 590 |  |  | 446 |  |  | 117 |  |
| Research and development | 2,423 |  |  | 1,433 |  |  | 542 |  |
| Sales, general and administrative | 1,893 |  |  | 1,497 |  |  | 834 |  |
| Gain from a trademark coexistence agreement | — |  |  | — |  |  | (1,500 | ) |
| Gain on reversal of charge for an export compliance matter | (1,121 | ) |  | — |  |  | — |  |
| Tax effect of non-GAAP adjustments | (1,514 | ) |  | (1,351 | ) |  | 3 |  |
| Non-GAAP net income and comprehensive income | $ | 179,208 |  |  | $ | 82,515 |  |  | $ | 102,585 |  |
| Non-GAAP diluted net income per share of common stock (1) | $ | 2.00 |  |  | $ | 0.91 |  |  | $ | 1.09 |  |
| Weighted-average shares used in computing non-GAAP diluted net income per share of common stock (1) | 89,715 |  |  | 90,259 |  |  | 93,762 |  |

[0001511737-14-000024:mdna:177]
| (1) | Non-GAAP diluted net income per share of common stock is calculated using non-GAAP net income and comprehensive income excluding stock-based compensation and a gain from a trademark coexistence agreement, net of taxes and weighted-average shares outstanding as if Series A preferred stock is treated as common stock for the periods presented. |

[0001511737-14-000024:mdna:178]
44

[0001511737-14-000024:mdna:179]
The following table shows a reconciliation of weighted-average shares used in computing net income (loss) per share of common stock-diluted to weighted-average shares used in computing non-GAAP diluted net income per share of common stock:

[0001511737-14-000024:mdna:180]
|  | Years Ended June 30, |
|  | 2014 |  | 2013 |  | 2012 |
|  | (In thousands) |
| Weighted average shares used in computing net loss per share of common stock- diluted | 89,715 |  |  | 90,259 |  |  | 83,460 |  |
| Weighted average dilutive effect of stock options and restricted stock units | — |  |  | — |  |  | 2,695 |  |
| Weighted average shares of Series A preferred stock outstanding | — |  |  | — |  |  | 7,607 |  |
| Weighted-average shares used in computing non-GAAP diluted income per share of common stock | 89,715 |  |  | 90,259 |  |  | 93,762 |  |
