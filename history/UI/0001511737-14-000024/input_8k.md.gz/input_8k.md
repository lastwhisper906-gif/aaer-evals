# UI 8-K — 0001511737-14-000021 filed 2014-08-07

## item codes, every 8-K on or before 2014-08-22

- 2014-08-07 0001511737-14-000021 — 2.02, 9.01
- 2014-05-08 0001511737-14-000016 — 2.02, 9.01
- 2014-04-17 0001193125-14-146710 — 7.01
- 2014-03-06 0001193125-14-084883 — 8.01
- 2014-02-06 0001511737-14-000005 — 2.02, 9.01
- 2013-12-16 0001193125-13-474388 — 5.07
- 2013-11-22 0001193125-13-451511 — 5.02
- 2013-11-07 0001511737-13-000018 — 2.02, 9.01
- 2013-10-28 0001193125-13-413414 — 5.02, 9.01
- 2013-10-18 0001193125-13-404111 — 5.02, 9.01
- 2013-08-08 0001511737-13-000009 — 2.02, 9.01
- 2013-05-09 0001511737-13-000004 — 2.02
- 2013-03-25 0001193125-13-124353 — 5.07
- 2013-03-08 0001193125-13-098334 — 5.02, 9.01
- 2013-02-07 0001193125-13-043701 — 2.02, 9.01
- 2012-12-28 0001193125-12-518487 — 1.01
- 2012-12-17 0001193125-12-503742 — 7.01, 9.01
- 2012-12-13 0001193125-12-501894 — 5.02
- 2012-11-16 0001193125-12-474083 — 5.02
- 2012-11-13 0001193125-12-467376 — 5.02
- 2012-11-08 0001193125-12-460665 — 2.02, 9.01
- 2012-10-10 0001193125-12-420015 — 5.02, 9.01
- 2012-08-13 0001193125-12-352624 — 1.01, 2.03, 9.01
- 2012-08-09 0001193125-12-347776 — 1.01, 9.01
- 2012-08-09 0001193125-12-347732 — 2.02, 9.01
- 2012-05-01 0001193125-12-201012 — 2.02, 9.01
- 2012-03-30 0001193125-12-144074 — 5.02
- 2012-03-27 0001193125-12-134395 — 5.02, 9.01
- 2012-03-22 0001193125-12-127536 — 5.02
- 2012-01-31 0001193125-12-032079 — 2.02, 9.01
- 2011-12-27 0001193125-11-353002 — 1.01, 9.01
- 2011-12-06 0001193125-11-332192 — 5.02
- 2011-11-10 0001193125-11-306969 — 2.02, 9.01

## late-filing notifications on or before 2014-08-22

- none on or before 2014-08-22

## item 2.02 — earnings release, exhibit 99.1

[0001511737-14-000021:8k_2_02:1]
EX-99.1
2
exhibit991q42014.htm
PRESS RELEASE OF UBIQUITI NETWORKS, INC.

[0001511737-14-000021:8k_2_02:2]
Exhibit 99.1 Q4 2014

[0001511737-14-000021:8k_2_02:3]
Exhibit 99.1

[0001511737-14-000021:8k_2_02:4]
UBIQUITI NETWORKS REPORTS RECORD FOURTH QUARTER FISCAL 2014 FINANCIAL RESULTS

[0001511737-14-000021:8k_2_02:5]
~ Achieves Record Revenue and Earnings ~

[0001511737-14-000021:8k_2_02:6]
~ Posts Non-GAAP EPS of $0.56 Per Diluted Share ~

[0001511737-14-000021:8k_2_02:7]
San Jose, Calif. - August 7, 2014 - Ubiquiti Networks, Inc. (NASDAQ: UBNT) (“Ubiquiti”), a next-generation communications technology company, today announced results for its fourth quarter of fiscal 2014 ended June 30, 2014.

[0001511737-14-000021:8k_2_02:8]
Fourth Quarter Fiscal 2014 Financial Highlights

[0001511737-14-000021:8k_2_02:9]
| • | Revenues of $156.0 million, up 54% year-over-year |

[0001511737-14-000021:8k_2_02:10]
| • | GAAP operating profit of $52.8 million, up 59% year-over-year |

[0001511737-14-000021:8k_2_02:11]
| • | GAAP net income of $49.4 million, up 71% year-over-year |

[0001511737-14-000021:8k_2_02:12]
| • | GAAP diluted EPS of $0.55 and non-GAAP diluted EPS of $0.56, with non-GAAP up 70% year-over-year |

[0001511737-14-000021:8k_2_02:13]
| • | Average days sales outstanding ("DSO") of 32 days |

[0001511737-14-000021:8k_2_02:14]
Recent Business and Product Highlights

[0001511737-14-000021:8k_2_02:15]
| • | Sustained growth in Service Provider Technology, mainly driven by demand for our airFiber® 5 and airMAX® ac products. |

[0001511737-14-000021:8k_2_02:16]
| • | Strong momentum in Enterprise Technology, primarily due to product expansion and further adoption of our UniFi® technology platform. |

[0001511737-14-000021:8k_2_02:17]
| • | Launched EdgeSwitch, the first switch of its price/performance class, designed to offer superior performance and capability for a fraction of the cost of a traditional enterprise switch. |

[0001511737-14-000021:8k_2_02:18]
| • | Launched UniFi Video, a new line of video surveillance camera control software and a new generation of cameras - the UVC, UVC-Dome, and UVC-Pro models - to join the UniFi family of products |

[0001511737-14-000021:8k_2_02:19]
| • | Launched UniFi VoIP, a new scalable VoIP enterprise smart phone technology to provide price/performance disruptive telephony solutions for business, schools, hotels, and more. |

[0001511737-14-000021:8k_2_02:20]
Financial Results Summary ($, in millions, except per share data)

[0001511737-14-000021:8k_2_02:21]
| Financials |  | F4Q14 |  | F3Q14 |  | F4Q13 |
| Revenues |  | 156.0 |  | 148.3 |  | 101.2 |
| Service Provider Technology |  | 124.0 |  | 121.0 |  | 90.1 |
| Enterprise Technology |  | 32.0 |  | 27.3 |  | 11.1 |
| Cost of Revenues |  | 87.1 |  | 82.7 |  | 56.9 |
| Gross Profit |  | 68.9 |  | 65.6 |  | 44.4 |
| Total Operating Expenses |  | 16.1 |  | 15.5 |  | 11.2 |
| Income from Operations |  | 52.8 |  | 50.1 |  | 33.2 |
| Net Income |  | 49.4 |  | 45.2 |  | 28.8 |
| Non-GAAP EPS (diluted) |  | 0.56 |  | 0.50 |  | 0.33 |

[0001511737-14-000021:8k_2_02:22]
Fourth Quarter 2014 Financial Highlights

[0001511737-14-000021:8k_2_02:23]
Total revenue for the fourth quarter of fiscal 2014 increased 54% to a record $156.0 million, compared with $101.2 million in the fourth quarter of fiscal 2013.  Service Provider Technology revenues increased $33.9 million, or 38%, to $124.0 million in the fourth quarter of fiscal 2014, compared with $90.1 million in the fourth quarter of fiscal 2013.  Enterprise Technology revenues increased $20.9 million, or 188%, to $32.0 million in the fourth quarter of fiscal 2014, compared with $11.1 million in the fourth quarter of fiscal 2013.

[0001511737-14-000021:8k_2_02:24]
GAAP net income for the fourth quarter of fiscal 2014 was $49.4 million, or $0.55 per diluted share, compared with GAAP net income of $28.8 million, or $0.32 per diluted share, in the fourth quarter of fiscal 2013.  Ubiquiti recorded fourth quarter fiscal 2014 non-GAAP net income of $50.2 million, or $0.56 per diluted share, compared with non-GAAP net income of $29.5 million, or $0.33 per diluted share, in the fourth quarter of fiscal 2013.

[0001511737-14-000021:8k_2_02:25]
Ubiquiti’s net cash inflow from operations for the fourth quarter of fiscal 2014 was $55.8 million, compared with a net cash inflow of $46.2 million in the fourth quarter of fiscal 2013.  The key driver for the increase in net cash from operations in the fourth quarter of fiscal 2014 was due to an improvement in our lead times to customers and a reduction in inventory related to new products launched and sold at scale.  Total cash and cash equivalents as of June 30, 2014 were $347.1 million, compared with $291.7 million as of March 31, 2014, and $227.8 million as of June 30, 2013.

[0001511737-14-000021:8k_2_02:26]
Average days sales outstanding ("DSO") was 32 days in the fourth quarter of fiscal 2014, compared with 30 days in the prior quarter, and 32 days in the fourth quarter of fiscal 2013.

[0001511737-14-000021:8k_2_02:27]
“We continue to ramp our R&D resources in an effort to accelerate the next phase of our long-term vision of democratizing end to end communications technology infrastructure for the unconnected” said Robert J. Pera, Founder and Chief Executive Officer of Ubiquiti Networks.

[0001511737-14-000021:8k_2_02:28]
Craig L. Foster, Ubiquiti’s Chief Financial Officer, added, “We are very focused on execution which is demonstrated in another quarter of strong financial results.  Several new product launches are driving revenue growth and we continue to make the strategic investments that we believe will help us not only expand our addressable market but also preserve our company’s vision.”

[0001511737-14-000021:8k_2_02:29]
Business Outlook

[0001511737-14-000021:8k_2_02:30]
Based on current business trends, Ubiquiti currently believes the demand environment in its end markets supports the following forecast for the Company's first fiscal quarter 2015 ending September 30, 2014:

[0001511737-14-000021:8k_2_02:31]
| • | Revenues of between $156 million and $161 million |

[0001511737-14-000021:8k_2_02:32]
| • | GAAP Diluted EPS of between $0.51 and $0.53 |

[0001511737-14-000021:8k_2_02:33]
| • | Non-GAAP Diluted EPS of between $0.52 and $0.54 |

[0001511737-14-000021:8k_2_02:34]
Conference Call Information

[0001511737-14-000021:8k_2_02:35]
Ubiquiti Networks will host a Q&A-only conference call to discuss the Company’s financial results at 2:00 p.m. Pacific Time today.  Management’s prepared remarks can be found on the Investor Relations section of the Ubiquiti Networks website, http://ir.ubnt.com.

[0001511737-14-000021:8k_2_02:36]
To listen to the Q&A-only conference call via telephone, dial (877) 291-1296 (U.S. toll-free) or (720) 259-9209 (International) to be connected to the call by an operator.  Participants should dial in at least 10 minutes prior to the start of the call.  Investors may also listen to a live webcast of the Q&A-only conference call by visiting the Investor Relations section of the Ubiquiti Networks website, http://ir.ubnt.com.

[0001511737-14-000021:8k_2_02:37]
A recording of the Q&A call will be available approximately two hours after the call concludes and will be accessible on the Investor Relations section of the Ubiquiti Networks website, http://ir.ubnt.com.

[0001511737-14-000021:8k_2_02:38]
About Ubiquiti Networks

[0001511737-14-000021:8k_2_02:39]
Ubiquiti Networks (NASDAQ: UBNT) is closing the digital divide by building network communication platforms for everyone and everywhere.  With over 20 million devices deployed in over 180 countries, Ubiquiti is transforming under-networked businesses and communities.  Our leading edge platforms, airMAX®, airFiber®, UniFi®, UniFi® Video, UniFi® VoIP, mFi® and EdgeMAX®, combine innovative technology, disruptive price-performance and the support of a global user community to eliminate barriers to connectivity.  For more information, join our community at http://www.ubnt.com.

[0001511737-14-000021:8k_2_02:40]
Ubiquiti, the Ubiquiti logo, Ubiquiti Networks, airMAX, airFiber, UniFi, mFi, EdgeMAX, EdgeSwitch and Ubiquiti World Network are registered trademarks or trademarks of Ubiquiti Networks, Inc. and/or its affiliates in the United States and other countries.

[0001511737-14-000021:8k_2_02:41]
Investor Relations Contact

[0001511737-14-000021:8k_2_02:42]
Anne Fazioli

[0001511737-14-000021:8k_2_02:43]
Ubiquiti Networks, Vice President of Investor Relations

[0001511737-14-000021:8k_2_02:44]
IR@ubnt.com

[0001511737-14-000021:8k_2_02:45]
Forward-looking statements are subject to certain risks and uncertainties that could cause our actual future results to differ materially, or cause a material adverse impact on our results.  Potential risks and uncertainties include, but are not limited to, fluctuations in our operating results; varying demand for our products due to the financial and operating condition of our distributors and their customers, distributors' inventory management practices and general economic conditions; impact of counterfeiting and our ability to contain such impact; our reliance on a limited number of distributors; inability of our contract manufacturers and suppliers to meet our demand; our dependence on Qualcomm Atheros for chipsets without a short-term alternative; as we move into new markets competition from certain of our current or potential competitors who may be more established in such markets; our ability to keep pace with technological and market developments; success and timing of new product introductions by us and the performance of our products generally; our ability to effectively manage the significant increase in our transactional sales volumes; we may become subject to warranty claims, product liability and product recalls; that a substantial majority of our sales are into countries outside the United States and we are subject to numerous U.S. export control and economic sanctions laws; costs related to responding to government inquiries related to regulatory compliance; our reliance on the Ubiquiti Community; our reliance on certain key members of our management team, including our founder and chief executive officer, Robert J. Pera; adverse tax-related matters such as tax audits, changes in our effective tax rate or new tax legislative proposals; whether the final determination of our income tax liability may be materially different from our income tax provisions; the impact of any intellectual property litigation and claims for indemnification and litigation related to U.S. Securities laws and economic and political conditions in the United States and abroad.  We discuss these risks in greater detail under the heading “Risk Factors” and elsewhere in our Annual Report on Form 10-K for the year ended June 30, 2013, subsequent Quarterly Reports on Form 10-Q and other filings filed with the U.S. Securities and Exchange Commission (the SEC), which are available at the SEC's website at www.sec.gov.  Copies may also be obtained by contacting the Ubiquiti Networks Investor Relations Department, or by email at IR@ubnt.com or by visiting the Investor Relations section of the Ubiquiti Networks website, http://ir.ubnt.com.

[0001511737-14-000021:8k_2_02:46]
Given these uncertainties, you should not place undue reliance on these forward-looking statements.  Also, forward-looking statements represent our management's beliefs and assumptions only as of the date made.  Ubiquiti

[0001511737-14-000021:8k_2_02:47]
Networks undertakes no obligation to update information contained herein.  You should review our SEC filings carefully and with the understanding that our actual future results may be materially different from what we expect.

[0001511737-14-000021:8k_2_02:48]
Use of Non-GAAP Financial Information

[0001511737-14-000021:8k_2_02:49]
To supplement our condensed consolidated financial results prepared under generally accepted accounting principles, or GAAP, we use non-GAAP measures of net income and earnings per diluted share that are adjusted to exclude certain recurring costs, expenses and gains such as stock based compensation expense, the gain on the reversal of a charge for an export compliance matter and the tax effects of these non-GAAP adjustments.  Reconciliations of the adjustments to GAAP results for the three and twelve months ended June 30, 2014 and 2013 are provided below.  In addition, an explanation of the ways in which management uses non-GAAP financial information to evaluate its business, the substance behind management's decision to use this non-GAAP financial information, material limitations associated with the use of non-GAAP financial information, the manner in which management compensates for those limitations, and the substantive reasons management believes that this non-GAAP financial information provides useful information to investors is included under "About our Non-GAAP Net Income and Adjustments" after the tables below.

[0001511737-14-000021:8k_2_02:50]
| Ubiquiti Networks Inc.Condensed Consolidated Statement of Operations(In thousands, except per share data)(Unaudited) |
|  |  | Three Months Ended June 30, |  | Years Ended June 30, |
|  |  | 2014 |  | 2013 |  | 2014 |  | 2013 |
| Revenues |  | $ | 156,007 |  |  | $ | 101,232 |  |  | $ | 572,464 |  |  | $ | 320,823 |  |
| Cost of revenues |  | 87,146 |  |  | 56,868 |  |  | 318,997 |  |  | 185,489 |  |
| Gross profit |  | 68,861 |  |  | 44,364 |  |  | 253,467 |  |  | 135,334 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Research and development |  | 10,155 |  |  | 5,515 |  |  | 33,962 |  |  | 20,955 |  |
| Sales, general and administrative |  | 5,912 |  |  | 5,642 |  |  | 23,560 |  |  | 21,775 |  |
| Total operating expenses |  | 16,067 |  |  | 11,157 |  |  | 57,522 |  |  | 42,730 |  |
| Income from operations |  | 52,794 |  |  | 33,207 |  |  | 195,945 |  |  | 92,604 |  |
| Interest expense and other, net |  | (556 | ) |  | (281 | ) |  | (1,334 | ) |  | (851 | ) |
| Income before provision for income taxes |  | 52,238 |  |  | 32,926 |  |  | 194,611 |  |  | 91,753 |  |
| Provision for income taxes |  | 2,820 |  |  | 4,085 |  |  | 17,674 |  |  | 11,263 |  |
| Net income and comprehensive income |  | $ | 49,418 |  |  | $ | 28,841 |  |  | $ | 176,937 |  |  | $ | 80,490 |  |
| Net income per share of common stock: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.56 |  |  | $ | 0.33 |  |  | $ | 2.02 |  |  | $ | 0.91 |  |
| Diluted |  | $ | 0.55 |  |  | $ | 0.32 |  |  | $ | 1.97 |  |  | $ | 0.89 |  |
| Weighted average shares used in computing net income per share of common stock: |  |  |  |  |  |  |  |  |
| Basic |  | 88,122 |  |  | 87,148 |  |  | 87,772 |  |  | 88,314 |  |
| Diluted |  | 89,821 |  |  | 89,064 |  |  | 89,715 |  |  | 90,259 |  |

[0001511737-14-000021:8k_2_02:51]
| Ubiquiti Networks Inc.Reconciliation of GAAP Net Income to Non-GAAP Net Income(In thousands, except per share data)(Unaudited) |
|  |  | Three Months Ended June 30, |  | Years Ended June 30, |
|  |  | 2014 |  | 2013 |  | 2014 |  | 2013 |
| Net income |  | $ | 49,418 |  |  | $ | 28,841 |  |  | $ | 176,937 |  |  | $ | 80,490 |  |
| Stock-based compensation: |  |  |  |  |  |  |  |  |
| Cost of revenues |  | 145 |  |  | 137 |  |  | 590 |  |  | 446 |  |
| Research and development |  | 744 |  |  | 442 |  |  | 2,423 |  |  | 1,433 |  |
| Sales, general and administrative |  | 387 |  |  | 548 |  |  | 1,893 |  |  | 1,497 |  |
| Gain on reversal of charge for an export compliance matter |  | — |  |  | — |  |  | (1,121 | ) |  | — |  |
| Tax effect of non-GAAP adjustments |  | (510 | ) |  | (451 | ) |  | (1,514 | ) |  | (1,351 | ) |
| Non-GAAP net income |  | $ | 50,184 |  |  | $ | 29,517 |  |  | $ | 179,208 |  |  | $ | 82,515 |  |
| Non-GAAP diluted EPS |  | $ | 0.56 |  |  | $ | 0.33 |  |  | $ | 2.00 |  |  | $ | 0.91 |  |
| Weighted-average shares used in non-GAAP diluted EPS |  | 89,821 |  |  | 89,064 |  |  | 89,715 |  |  | 90,259 |  |

[0001511737-14-000021:8k_2_02:52]
| Ubiquiti Networks Inc.Condensed Consolidated Balance Sheets(In thousands, except share amounts)(Unaudited) |
|  |  | June 30, |
|  |  | 2014 |  | 2013(1) |
| Assets |  |  |  |  |
| Current assets: |  |  |  |  |
| Cash and cash equivalents |  | $ | 347,097 |  |  | $ | 227,826 |  |
| Accounts receivable, net |  | 54,871 |  |  | 35,884 |  |
| Inventories |  | 46,349 |  |  | 15,880 |  |
| Current deferred tax asset |  | 884 |  |  | 733 |  |
| Prepaid income taxes |  | 3,256 |  |  | — |  |
| Prepaid expenses and other current assets |  | 13,267 |  |  | 3,151 |  |
| Total current assets |  | 465,724 |  |  | 283,474 |  |
| Property and equipment, net |  | 7,260 |  |  | 5,976 |  |
| Long-term deferred tax asset |  | 1,255 |  |  | 4 |  |
| Other long–term assets |  | 1,912 |  |  | 2,886 |  |
| Total assets |  | $ | 476,151 |  |  | $ | 292,340 |  |
| Liabilities and Stockholders’ Equity |  |  |  |  |
| Current liabilities: |  |  |  |  |
| Accounts payable |  | $ | 33,933 |  |  | $ | 36,187 |  |
| Customer deposits |  | 1,835 |  |  | 5,123 |  |
| Deferred revenues |  | 4,218 |  |  | 691 |  |
| Income taxes payable |  | 2,499 |  |  | 1,257 |  |
| Debt - short-term |  | — |  |  | 5,013 |  |
| Other current liabilities |  | 9,830 |  |  | 11,150 |  |
| Total current liabilities |  | 52,315 |  |  | 59,421 |  |
| Long-term taxes payable |  | 15,346 |  |  | 11,857 |  |
| Debt - long-term |  | 72,254 |  |  | 71,116 |  |
| Deferred revenues - long-term |  | 972 |  |  | 2,510 |  |
| Total liabilities |  | 140,887 |  |  | 144,904 |  |
| Stockholders’ equity: |  |  |  |  |
| Common stock |  | 88 |  |  | 87 |  |
| Additional paid–in capital |  | 145,872 |  |  | 134,982 |  |
| Treasury stock |  | (123,864 | ) |  | (123,864 | ) |
| Retained earnings |  | 313,168 |  |  | 136,231 |  |
| Total stockholders’ equity |  | 335,264 |  |  | 147,436 |  |
| Total liabilities and stockholders’ equity |  | $ | 476,151 |  |  | $ | 292,340 |  |

[0001511737-14-000021:8k_2_02:53]
| (1) | Derived from audited consolidated statements as of and for the year ended June 30, 2013. |

[0001511737-14-000021:8k_2_02:54]
| Ubiquiti Networks Inc.Revenues by Product Type (In thousands)(Unaudited) |
|  |  | Three Months Ended June 30, |  | Years Ended June 30, |
|  |  | 2014 |  | 2013 |  | 2014 |  | 2013 |
| Service provider technology |  | $ | 124,005 |  |  | $ | 90,128 |  |  | $ | 450,663 |  |  | $ | 285,390 |  |
| Enterprise technology |  | 32,002 |  |  | 11,104 |  |  | 121,801 |  |  | 35,433 |  |
| Total revenues |  | $ | 156,007 |  |  | $ | 101,232 |  |  | $ | 572,464 |  |  | $ | 320,823 |  |

[0001511737-14-000021:8k_2_02:55]
| Ubiquiti Networks Inc.Revenues by Geographical Area(In thousands)(Unaudited) |
|  |  | Three Months Ended June 30, |  | Years Ended June 30, |
|  |  | 2014 |  | 2013 |  | 2014 |  | 2013 |
| North America |  | $ | 43,260 |  |  | $ | 31,301 |  |  | $ | 142,438 |  |  | $ | 84,820 |  |
| South America |  | 35,757 |  |  | 19,944 |  |  | 109,584 |  |  | 65,764 |  |
| Europe, the Middle East and Africa |  | 57,418 |  |  | 37,170 |  |  | 247,009 |  |  | 127,860 |  |
| Asia Pacific |  | 19,572 |  |  | 12,817 |  |  | 73,433 |  |  | 42,379 |  |
| Total revenues |  | $ | 156,007 |  |  | $ | 101,232 |  |  | $ | 572,464 |  |  | $ | 320,823 |  |

[0001511737-14-000021:8k_2_02:56]
About our Non-GAAP Net Income and Adjustments

[0001511737-14-000021:8k_2_02:57]
Use of Non-GAAP Financial Information

[0001511737-14-000021:8k_2_02:58]
To supplement our condensed consolidated financial results prepared under generally accepted accounting principles, or GAAP, we use non-GAAP measures of net income and earnings per diluted share that are GAAP net income and GAAP earnings per diluted share adjusted to exclude certain recurring costs and non-recurring expenses and gains.

[0001511737-14-000021:8k_2_02:59]
We believe that the presentation of non-GAAP net income and non-GAAP earnings per diluted share provides important supplemental information regarding non-cash expenses, significant recurring items that we believe are important to understanding our financial, and business trends relating to our financial condition and results of operations.  Non-GAAP net income and non-GAAP earnings per diluted share are among the primary indicators used by management as a basis for planning and forecasting future periods and by management and our board of directors to determine whether our operating performance has met specified targets and thresholds.  Management uses non-GAAP net income and non-GAAP earnings per diluted share when evaluating operating performance because it believes that the exclusion of the items described below, for which the amounts and/or timing may vary significantly depending upon the Company's activities and other factors, facilitates comparability of the Company's operating performance from period to period.  We have chosen to provide this information to investors so they can analyze our operating results in the same way that management does and use this information in their assessment of our business and the valuation of our Company.

[0001511737-14-000021:8k_2_02:60]
Use and Economic Substance of Non-GAAP Financial Measures used by Ubiquiti Networks

[0001511737-14-000021:8k_2_02:61]
We compute non-GAAP net income and non-GAAP diluted earnings per share by adjusting GAAP net income and GAAP earnings per diluted share to remove the impact of recurring stock-based compensation expense, the gain on the reversal of a charge for an export compliance matter and the tax effect of these adjustments.  Items excluded from net income are:

[0001511737-14-000021:8k_2_02:62]
| • | Recurring charges and gains, including: |

[0001511737-14-000021:8k_2_02:63]
| ◦ | Stock-based compensation expense is recognized in accordance with FASB Accounting Standards Codification, Topic 718, Stock Compensation. |

[0001511737-14-000021:8k_2_02:64]
| • | Gain on reversal of charge for an export compliance matter |

[0001511737-14-000021:8k_2_02:65]
| • | Tax effect of non-GAAP adjustments. After adjusting to exclude the items described above, we apply the principles of ASC 740, Income Taxes, to estimate the non-GAAP income tax provision. |

[0001511737-14-000021:8k_2_02:66]
Usefulness of Non-GAAP Financial Information to Investors

[0001511737-14-000021:8k_2_02:67]
These non-GAAP measures are not in accordance with, or an alternative to, GAAP and may be materially different from other non-GAAP measures, including similarly titled non-GAAP measures used by other companies.  The presentation of this additional information should not be considered in isolation from, as a substitute for, or superior to, net income or earnings per diluted share prepared in accordance with GAAP.  Non-GAAP financial measures have limitations in that they do not reflect certain items that may have a material impact upon our reported financial results.  We expect to continue to incur expenses of a nature similar to the non-GAAP adjustments described above, and exclusion of these items from our non-GAAP net income and non-GAAP earnings per diluted share should not be construed as an inference that these costs are unusual, infrequent or non-recurring.

[0001511737-14-000021:8k_2_02:68]
For more information on the non-GAAP adjustments, please see the table captioned “Reconciliation of GAAP Net Income to Non-GAAP Net Income” included in this press release.
