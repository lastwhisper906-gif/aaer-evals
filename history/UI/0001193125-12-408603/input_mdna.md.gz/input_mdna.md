# UI MD&A — 0001193125-12-408603


## mdna

[0001193125-12-408603:mdna:1]
| Item 7. | Management’s Discussion and Analysis of Financial Condition and Results of Operations |

[0001193125-12-408603:mdna:2]
Overview

[0001193125-12-408603:mdna:3]
We are a product driven company
that leverages innovative proprietary technologies to deliver networking solutions with compelling price-performance characteristics to both start-up and established network operators and service providers. Our products bridge the digital divide by
fundamentally changing the economics of deploying high performance networking solutions in underserved and underpenetrated wireless broadband access markets globally. These markets include emerging markets and other areas where individual users and
small and medium sized enterprises do not have access to the benefits of carrier class broadband networking. Our business model has enabled us to break down traditional barriers, such as high product and network deployment costs, which are driven by
business model inefficiencies and achieve rapid market adoption of our products and solutions in previously underserved and underpenetrated markets. Our business model and proprietary technologies provide us with a significant and sustainable
competitive advantage over incumbents, who we believe are unable to respond effectively due to their higher cost business models.

[0001193125-12-408603:mdna:4]
We offer a
broad and expanding portfolio of networking products and solutions and we recently introduced products in the enterprise WLAN, video surveillance, wireless backhaul and machine-to-machine communications markets. Our solutions include systems, high
performance radios, antennas and management tools that have been designed to deliver carrier class performance for networking and other applications in the unlicensed RF spectrum. We began shipping embedded radios in fiscal 2006. In fiscal 2008 we
introduced a line of products based on 802.11 standard protocols and in early fiscal 2010, we introduced a number of new products based on our proprietary airTechnologies, including our high-performance airMAX platform, which have been rapidly
adopted by network operators and high-performance proprietary airMAX service providers. In fiscal 2012 and fiscal 2011, our systems revenue, which primarily consists of our airMAX platform, and to a lesser extent 802.11 standard based systems,
accounted for 86% and 81% of our revenues, respectively. Although our airMAX platform has supplanted the demand for some of our 802.11 standard products, we have not experienced a decline in gross margin as we transition from 802.11 standard
products to our airMAX platform as they have similar margin profiles. In the future, we expect sales of our airMAX platform products based on our other airTechnologies to continue to represent a growing portion of our revenues and the portion of our
revenues derived from our 802.11 standard products to decline as a percentage of total revenues. Our embedded radios bear higher margins than our systems, but we believe that systems present a larger market opportunity.

[0001193125-12-408603:mdna:5]
Building on our leadership in the underserved and underpenetrated segments of the wireless broadband access market, we intend to expand our product
offerings in our existing market and enter adjacent markets by relying on the combination of our efficient business model and proprietary technologies. For example, we have introduced products and solutions for the enterprise WLAN, video
surveillance, and since late fiscal 2011 licensed microwave wireless backhaul and machine-to-machine communication markets. As we enter such new markets, we plan to leverage existing distributor relationships and establish engaged communities
similar to that of the Ubiquiti Community to keep our operating expenses in line with our current model and enable us to offer products in these new markets with compelling price-performance characteristics.

[0001193125-12-408603:mdna:6]
Our revenues increased 79% to $353.5 million in fiscal 2012 from $197.9 million in fiscal 2011. Our revenues increased 44% to $197.9 million in fiscal
2011 from $137.0 million in fiscal 2010.

[0001193125-12-408603:mdna:7]
We had net income (loss) of $102.6 million, $49.7 million and $(5.5) million in fiscal 2012, fiscal
2011 and fiscal 2010, respectively. Our net loss in fiscal 2010 reflected a one-time stock-based compensation charge of $35.9 million related to a repurchase of our common stock and options in connection with the sale of our Series A preferred
stock and a $1.6 million charge related to a regulatory export compliance issue.

[0001193125-12-408603:mdna:8]
The Summit Transaction

[0001193125-12-408603:mdna:9]
In March 2010, we sold 33,898,990 shares of our Series A preferred stock and also issued warrants to purchase 2,135,640 shares of our Series A preferred
stock to funds affiliated with Summit Partners, L.P. for net proceeds

[0001193125-12-408603:mdna:10]
43

[0001193125-12-408603:mdna:11]
of $99.5 million. Simultaneously with the issuance of preferred stock and warrants, we repurchased 33,104,320 shares of common stock and canceled and repurchased 794,660 options to purchase
common stock from our employees and consultants for aggregate consideration of $100.0 million. In June 2010, the funds affiliated with Summit Partners, L.P., exercised their warrants in full for consideration of $6.3 million. For a more
complete description of these transactions see “—Repurchase of Common Stock and Sale of Series A Preferred Stock.”

[0001193125-12-408603:mdna:12]
We
determined that the per share repurchase price of the common stock and options in March 2010 was above the fair value for shares of our common stock at the time of the repurchase. The fair value was determined to be $1.89, while the repurchase price
was $2.95. Therefore, we recognized $35.9 million of the $100.0 million repurchase price as stock-based compensation expense in fiscal 2010. This stock-based compensation was allocated among the various categories of expense in our
consolidated statements of operations as follows:

[0001193125-12-408603:mdna:13]
|  |  | Year Ended June 30, 2010 |  |
|  |  | (In thousands) |  |
| Cost of revenues |  | $ | 99 |  |
| Research and development |  |  | 26,194 |  |
| Sales, general and administrative |  |  | 9,585 |  |
| Total stock-based compensation related to the Summit transaction |  | $ | 35,878 |  |

[0001193125-12-408603:mdna:14]
Repurchase of Series A Convertible Preferred Stock

[0001193125-12-408603:mdna:15]
In July 2011, we repurchased an aggregate of 12,041,700 shares of our Series A convertible preferred stock from entities affiliated with Summit Partners, L.P. at a price of $8.97 per share for an
aggregate consideration of $108.0 million. Of the aggregate purchase price, $40.0 million was paid in cash at the time of closing and the balance of the shares were paid for through the issuance of convertible subordinated promissory notes in the
aggregate principal amount of $68.0 million. The $68.0 million was paid down primarily using proceeds from the term loan we executed with East West Bank on September 15, 2011 and funds raised upon the completion of our initial public offering
on October 19, 2011.

[0001193125-12-408603:mdna:16]
Initial Public Offering

[0001193125-12-408603:mdna:17]
On October 19, 2011, we completed our initial public offering whereby we sold 2,395,328 shares and selling stockholders sold 4,642,902 shares of our common stock. We received net proceeds of $30.5
million after deducting the underwriting fees and commissions and estimated offering expenses payable by us. Immediately prior to the closing of the initial public offering, all outstanding shares of our Series A convertible preferred stock
converted into 23,992,929 shares of our common stock.

[0001193125-12-408603:mdna:18]
Key Components of Our Results of Operations and Financial Condition

[0001193125-12-408603:mdna:19]
Revenues

[0001193125-12-408603:mdna:20]
Our revenues are derived
principally from the sale of networking hardware and management tools. In addition, while we do not sell maintenance and support separately, because we have historically included it free of charge in many of our arrangements, we attribute a portion
of our systems revenues to this implied post-contract customer support (“PCS”).

[0001193125-12-408603:mdna:21]
We classify our revenues into three product
categories: systems, embedded radios and antennas/other.

[0001193125-12-408603:mdna:22]
|  | • |  | Systems consists of three product categories: |

[0001193125-12-408603:mdna:23]
|  | • |  | Our proprietary airMAX platform products for network operators and service providers; |

[0001193125-12-408603:mdna:24]
|  | • |  | Our new platform products which include significant platforms introduced in late fiscal 2011 and during 2012 which includes the UniFi, airVision and airFiber platforms; and |

[0001193125-12-408603:mdna:25]
|  | • |  | Other 802.11 standard products including base stations, radios, backhaul equipment and CPE. |

[0001193125-12-408603:mdna:26]
|  | • |  | Embedded radios consist of more than 25 radio products primarily for OEMs, including both point to point and point to multipoint radios in the 2.0 to 6.0GHz spectrum, that are offered with a variety of features. |

[0001193125-12-408603:mdna:27]
|  | • |  | Antennas/other consist of antenna products in the 2.0 to 6.0GHz spectrum, as well as miscellaneous products such as mounting brackets, cables and power over Ethernet adapters. These products include both high performance sector and directional antennas. This category also includes our allocation of revenues to PCS. |

[0001193125-12-408603:mdna:28]
We sell substantially all of our products through a limited number of distributors and other channel partners, such as resellers and OEMs. Sales to distributors accounted for 98%, 97% and 93% of our
revenues in fiscal 2012, fiscal 2011 and fiscal 2010, respectively. Other channel partners, such as resellers and OEMs, largely accounted for the balance of our revenues. We sell our products without any right of return outside of standard warranty
rights.

[0001193125-12-408603:mdna:29]
Cost of Revenues

[0001193125-12-408603:mdna:30]
Our cost of revenues is comprised primarily of the costs of procuring finished goods from our contract manufacturers and chipsets that we consign to certain of our contract manufacturers. In addition,
cost of revenues includes tooling, labor and other costs associated with engineering, testing and quality assurance, warranty costs, stock-based compensation and excess and obsolete inventory.

[0001193125-12-408603:mdna:31]
We outsource our manufacturing and order fulfillment and utilize contract manufacturers located primarily in China and, to a lesser extent, Taiwan. We
also evaluate and utilize other vendors for various portions of our supply chain from time to time. Our manufacturing organization consists of employees and consultants engaged in the management of our contract manufacturers, new product
introduction activities, logistical support and engineering.

[0001193125-12-408603:mdna:32]
Gross Profit

[0001193125-12-408603:mdna:33]
Our gross profit has been, and may in the future be, influenced by several factors including changes in product mix, target end markets for our products,
pricing due to competitive pressure, production costs, foreign exchange rates and global demand for electronic components. Although we procure and sell our products in U.S. dollars, our contract manufacturers incur many costs, including labor costs,
in other currencies. To the extent that the exchange rates move unfavorably for our contract manufacturers, they may try to pass these additional costs on to us, which could have a material impact on our future average selling prices and unit costs.

[0001193125-12-408603:mdna:34]
Operating Expenses

[0001193125-12-408603:mdna:35]
We classify our operating expenses as research and development and sales, general and administrative expenses.

[0001193125-12-408603:mdna:36]
|  | • |  | Research and development expenses consist primarily of salary and benefit expenses, including stock-based compensation, for employees and costs for contractors engaged in research, design and development activities, as well as costs for prototypes, facilities and travel. Over time, we expect our research and development costs to increase as we continue making significant investments in developing new products and developing new versions of our existing products. |

[0001193125-12-408603:mdna:37]
|  | • |  | Sales, general and administrative expenses include salary and benefit expenses, including stock-based compensation, for employees and costs for contractors engaged in sales, marketing and general and administrative activities, as well as the costs of trade shows, marketing programs, promotional materials, bad debt expense, professional services, facilities, general liability insurance and travel. As our product portfolio and targeted markets expand, we may need to employ different sales models, such as building a direct sales force. These sales models would likely increase our costs. Over time, we expect our sales, general and administrative expenses to increase in absolute dollars due to continued growth in headcount, expansion of our registration and defense of trademarks, patents and shareholder litigation efforts and increased support for our business and operations as a public company. |

[0001193125-12-408603:mdna:38]
Deferred Revenues and Costs

[0001193125-12-408603:mdna:39]
In the event that collectability of a receivable from products we have shipped is not reasonably assured, we classify those amounts as deferred revenues on our balance sheet until such time as we receive
payment of the accounts receivable. We classify the cost of products associated with these deferred revenues as deferred costs of revenues. At June 30, 2012, we did not have any revenue deferred for transactions where we lacked evidence that
collectability of the receivables recorded was reasonably assured. At June 30, 2011, $1.2 million of revenue was deferred with a related deferred cost of revenues balance of $881,000.

[0001193125-12-408603:mdna:40]
Also included in our deferred revenues is a portion related to PCS obligations that we estimate we will perform in the future. As of June 30, 2012 and 2011, we had deferred revenues of $805,000 and
$497,000 respectively, related to these obligations.

[0001193125-12-408603:mdna:41]
Prepayments

[0001193125-12-408603:mdna:42]
We have historical agreements with certain contract manufacturers whereby we prepay for a portion of the product costs to assure the manufacture and timely delivery of our products. As of June 30,
2012 and 2011, we had prepayment balances of $129,000 and $5.3 million, respectively.

[0001193125-12-408603:mdna:43]
Critical Accounting Policies

[0001193125-12-408603:mdna:44]
We prepare our consolidated financial statements in accordance with accounting principles generally accepted in the United States of
America (“GAAP”). In many cases, the accounting treatment of a particular transaction is specifically dictated by GAAP and does not require management’s judgment in its application. In other cases, management’s judgment is
required in selecting among available alternative accounting standards that provide for different accounting treatment for similar transactions. The preparation of consolidated financial statements also requires us to make estimates and assumptions
that affect the amounts we report as assets, liabilities, revenues, costs and expenses and affect the related disclosures. We base our estimates on historical experience and other assumptions that we believe are reasonable under the circumstances.
In many instances, we could reasonably use different accounting estimates, and in some instances changes in the accounting estimates are reasonably likely to occur from period to period. Accordingly, our actual results could differ significantly
from the estimates made by our management. To the extent that there are differences between our estimates and actual results, our future financial statement presentation, financial condition, results of operations and cash flows will be affected. We
believe that the accounting policies discussed below are critical to understanding our historical and future performance, as these policies relate to the more significant areas involving management’s judgments and estimates.

[0001193125-12-408603:mdna:45]
Recognition of Revenues

[0001193125-12-408603:mdna:46]
Revenues
consist primarily of revenues from the sale of hardware and management tools, as well as the related implied PCS. We recognize revenues when persuasive evidence of an arrangement exists, delivery has occurred, the sales price is fixed or
determinable and the collectability of the resulting receivable is reasonably assured. In cases where we lack evidence that collectability of the resulting receivable is reasonably assured, we defer recognition of revenue until the receipt of cash.

[0001193125-12-408603:mdna:47]
For our sales, evidence of the arrangement consists of an order from a customer. We consider delivery to have occurred once our products have
been shipped and title and risk of loss have been transferred. For our sales, these criteria are met at the time the products are transferred to the customer. Our arrangements with customers do not include provisions for cancellation, returns,
inventory swaps or refunds that would significantly impact recognized revenues.

[0001193125-12-408603:mdna:48]
We record amounts billed to distributors for shipping and
handling costs as revenues. We classify shipping and handling costs incurred by us as cost of revenues.

[0001193125-12-408603:mdna:49]
Deposit payments received from distributors in advance of recognition of revenues are included in current
liabilities on our balance sheet and are recognized as revenues when all the criteria for recognition of revenues are met.

[0001193125-12-408603:mdna:50]
Our multi-element
arrangements generally include two deliverables. The first deliverable is the hardware and software essential to the functionality of the hardware device delivered at the time of sale. The second deliverable is the implied right to PCS included with
the purchase of certain products. PCS is the right to receive, on a when and if available basis, future unspecified software upgrades and features relating to the product’s essential software as well as bug fixes, email and telephone support.

[0001193125-12-408603:mdna:51]
We use a hierarchy to determine the allocation of revenues to the deliverables. The hierarchy is as follows: (i) vendor-specific
objective evidence of fair value (“VSOE”), (ii) third-party evidence of selling price (“TPE”), and (iii) best estimate of the selling price (“BESP”).

[0001193125-12-408603:mdna:52]
|  | (i) | VSOE generally exists only when a company sells the deliverable separately and is the price actually charged by the company for that deliverable. Generally we do not sell the deliverables separately and, as such, do not have VSOE. |

[0001193125-12-408603:mdna:53]
|  | (ii) | TPE can be substantiated by determining the price that other parties sell similar or substantially similar offerings. We do not believe that there is accessible TPE evidence for similar deliverables. |

[0001193125-12-408603:mdna:54]
|  | (iii) | BESP reflects our best estimates of what the selling prices of elements would be if they were sold regularly on a stand-alone basis. We believe that BESP is the most appropriate methodology for determining the allocation of revenues among the multiple elements. |

[0001193125-12-408603:mdna:55]
We have allocated revenues
between these two deliverables using the relative selling price method which is based on the BESP for all deliverables. Revenues allocated to the delivered hardware and the related essential software are recognized at the time of sale provided the
other conditions for recognition of revenues have been met. Revenues allocated to the PCS are deferred and recognized on a straight-line basis over the estimated life of each of these devices which currently is two years. All costs of revenues,
including estimated warranty costs, are recognized at the time of sale. Costs for research and development and sales and marketing are expensed as incurred. If the estimated life of the hardware product should change, the future rate of amortization
of the revenues allocated to PCS would also change.

[0001193125-12-408603:mdna:56]
Our process for determining BESP for deliverables involves multiple factors that may vary
depending upon the unique facts and circumstances related to each deliverable. For PCS, we believe our network operators and service providers would be reluctant to pay for such services separately. This view is primarily based on the fact that
unspecified upgrade rights do not obligate us to provide upgrades at a particular time or at all, and do not specify to network operators and service providers which upgrades or features will be delivered. We believe that the relatively low prices
of our products and our network operators, and service providers’ price sensitivity would add to their reluctance to pay for PCS. Therefore, we have concluded that if we were to sell PCS on a stand-alone basis, the selling price would be
relatively low.

[0001193125-12-408603:mdna:57]
Key factors considered by us in developing the BESP for PCS include reviewing the activities of specific employees engaged in
support and software development to determine the amount of time that is allocated to the development of the undelivered elements, determining the cost of this development effort, and then adding an appropriate level of gross profit to these costs.

[0001193125-12-408603:mdna:58]
Inventory

[0001193125-12-408603:mdna:59]
Our
inventories are primarily raw materials, which we have consigned to our contract manufacturers, and to a lesser extent, finished goods. Our inventories are stated at the lower of cost or market value on a first-in, first-out basis. We reduce the
value of our inventory for estimated obsolescence or lack of marketability by the difference between the cost of the affected inventory and the estimated market value. Allowances, once established, are not reversed until the related inventory has
been subsequently sold or scrapped.

[0001193125-12-408603:mdna:60]
Product Warranties

[0001193125-12-408603:mdna:61]
We offer warranties on certain products and record a liability for the estimated future costs associated with potential warranty claims. These warranty costs are reflected in our consolidated statement of
operations within cost of revenues. Our warranties are in effect for 12 months from the distributors’ purchase date of the product. Our estimates of future warranty costs are largely based on historical experience of product failure rates,
material usage and service delivery costs incurred in correcting product failures. Our operating results could be materially and adversely affected if future warranty claims exceed historical experiences and we are not able to recover costs from our
contract manufacturers.

[0001193125-12-408603:mdna:62]
Allowance for Doubtful Accounts

[0001193125-12-408603:mdna:63]
We record an allowance for doubtful accounts for estimated probable losses on uncollectible accounts receivable. In estimating the allowance, management considers, among other factors, the aging of the
accounts receivable, our historical write offs, the credit worthiness of each distributor based on payment history and general economic conditions.

[0001193125-12-408603:mdna:64]
Income Taxes

[0001193125-12-408603:mdna:65]
We account for income taxes in accordance with accounting guidance
which requires recognition of deferred tax assets and liabilities for the expected future tax consequences of events that have been included in our financial statements or tax returns. Deferred tax assets and liabilities are determined based on the
temporary difference between the financial statement carrying amounts of existing assets and liabilities and their respective tax bases. Deferred tax assets and liabilities are measured using enacted tax rates expected to apply to taxable income in
the years in which those temporary differences are expected to be recovered or settled. We establish valuation allowances when necessary to reduce deferred tax assets to the amount we expect to realize. The assessment of whether or not a valuation
allowance is required often requires significant judgment including current operating results, the forecast of future taxable income and ongoing prudent and feasible tax planning initiatives.

[0001193125-12-408603:mdna:66]
In addition, our calculation of our tax liabilities involves dealing with uncertainties in the application of complex tax regulations. We may be subject to income tax audits in each of the jurisdictions
in which we operate and, as a result, must also assess exposures to any potential issues arising from current or future audits of current and prior years’ tax returns. Accordingly, we must assess such potential exposures and, where necessary,
provide a reserve to cover any expected loss. To the extent that we establish a reserve, our provision for income taxes would be increased. We review our potential liabilities periodically and, if necessary, record an additional charge in our
provision for taxes in the period in which we determine that tax liability is greater than our original estimate. If we ultimately determine that payment of these amounts is unnecessary, we reverse the liability and recognize a tax benefit during
the period in which we determine that the liability is no longer necessary.

[0001193125-12-408603:mdna:67]
Stock-based Compensation

[0001193125-12-408603:mdna:68]
We record stock-based awards at fair value as of the grant date and recognize expense ratably on a straight-line basis over the requisite service period,
which is generally the vesting term of the awards. We estimate the fair value of stock option awards on the grant date using the Black-Scholes option pricing model. Restricted stock units are valued based on the fair value of our common stock on the
date of grant. We adopted the above guidance using the modified prospective transition method. Under this transition method, the new fair value recognition provisions are applied to option grants on and after July 1, 2005. We expense all
stock-based awards granted or modified after July 1, 2005 on a straight-line basis.

[0001193125-12-408603:mdna:69]
For grants made since January 1, 2010, we
obtained contemporaneous valuation analyses prepared by an unrelated third party valuation firm in order to assist us in determining the fair value of our common stock. The initial contemporaneous valuation report valued our common stock as of
April 30, 2010 and we received the most recent contemporaneous valuation report as of July 31, 2011. Prior to January 1, 2010, we obtained retrospective analyses prepared by the same valuation firm in order to assist us in determining
the fair value of

[0001193125-12-408603:mdna:70]
our common stock as of June 30, 2009. After January 1, 2010, our board of directors has considered these reports when determining the fair value of our common stock and related exercise
prices of option awards on the date such awards were granted.

[0001193125-12-408603:mdna:71]
These third party valuations were also used for purposes of determining the
Black-Scholes fair value of our stock option awards and related stock-based compensation expense. Beginning with our initial public offering on October 14, 2011, the fair value of our common stock is determined using the market price of our common
stock as of the date of grant.

[0001193125-12-408603:mdna:72]
Repurchase of Common Stock and Options and Sale of Series A Preferred Stock

[0001193125-12-408603:mdna:73]
In March 2010, we entered into a Stock Purchase and Recapitalization Agreement with entities affiliated with Summit Partners, L.P., certain of our
stockholders and certain of our optionees pursuant to which we repurchased shares of our common stock and vested options to acquire shares of our common stock from our stockholders and optionees and issued shares of our Series A convertible
preferred stock, or the Series A shares, to entities affiliated with Summit Partners, L.P. Upon the closing of the transactions contemplated by the Stock Purchase and Recapitalization Agreement, we simultaneously repurchased an aggregate of
33,104,320 shares of our common stock at $2.95 per share from certain of our employees and consultants and repurchased and subsequently cancelled options to purchase an aggregate of 794,660 shares of our common stock for $2.95 per share from our
employees and we issued an aggregate of 33,898,990 Series A shares and warrants to purchase an additional 2,135,640 Series A shares.

[0001193125-12-408603:mdna:74]
We determined by way of historical valuation that the fair market value of each share of our common stock outstanding and subject to outstanding options
that we repurchased was $1.89, or $1.06 per share less than the per share repurchase price. As each person from whom we repurchased common stock or options was our employee or consultant, at the time of the repurchase or prior to that time, we
recorded approximately $35.9 million as compensation expense, which represented the excess of the aggregate repurchase price over the aggregate fair value per share.

[0001193125-12-408603:mdna:75]
Each Series A share was convertible, at the option of the holder, into shares of our common stock on a one for one basis, subject to adjustment for future dilutive issuances, splits, consolidations
and the like. From the initial date of issuance of our Series A preferred stock in March 2010, the holders of our Series A shares were entitled to receive cumulative dividends at an annual rate of 4% of the original purchase price per
share, plus all accumulated and unpaid dividends. On January 10, 2011 we amended our certificate of incorporation. At such time, we paid a onetime dividend of (i) $0.08 per share issued on March 2, 2010 to holders of our Series A
shares and (ii) $0.05 per share for each other share of our Series A preferred stock as consideration for all cumulative dividends from the initial date of issuance until November 19, 2010. After January 10, 2011, the holder of
each Series A share is entitled to receive cumulative dividends of 4% of the original purchase price per share from January 10, 2011 through the payment date only upon the redemption of the Series A shares, the liquidation of our
company for less than $2.95 per share or upon our default of certain contractual agreements with the holders of the Series A shares.

[0001193125-12-408603:mdna:76]
We
accounted for the deemed dividends using the two class method and, as a result, our net income available to common stockholders was reduced by approximately $896,000, $4.3 million and $1.3 million for fiscal 2012, fiscal 2011 and fiscal 2010,
respectively.

[0001193125-12-408603:mdna:77]
The Series A shares were redeemable under certain circumstances, at the option of the holders. The redemption features of
our Series A shares required us to classify the Series A shares as a security outside stockholders’ equity and to record accretion related to the redemption rights until such time as the Series A shares were converted to common
stock or redeemed. Upon the conversion of the Series A shares to common stock, the aggregate accretion was reclassified in stockholders’ equity as common stock and additional paid-in capital. All outstanding Series A shares were converted
into shares of common stock in connection with our initial public offering in October 2011.

[0001193125-12-408603:mdna:78]
Results of Operations

[0001193125-12-408603:mdna:79]
Comparison of Years Ended June 30, 2012 and 2011

[0001193125-12-408603:mdna:80]
|  |  | Years Ended June 30, |  |
|  |  | 2012 |  |  | 2011 |  |
|  |  | (In thousands, except percentages) |  |
| Revenues |  | $ | 353,517 |  |  |  | 100 | % |  | $ | 197,874 |  |  |  | 100 | % |
| Cost of revenues(1) |  |  | 202,514 |  |  |  | 57 | % |  |  | 117,062 |  |  |  | 59 | % |
| Gross profit |  |  | 151,003 |  |  |  | 43 | % |  |  | 80,812 |  |  |  | 41 | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development(1) |  |  | 16,699 |  |  |  | 5 | % |  |  | 11,374 |  |  |  | 6 | % |
| Sales, general and administrative(1)(2) |  |  | 9,012 |  |  |  | 3 | % |  |  | 7,358 |  |  |  | 4 | % |
| Total operating expenses |  |  | 25,711 |  |  |  | 8 | % |  |  | 18,732 |  |  |  | 10 | % |
| Income from operations |  |  | 125,292 |  |  |  | 35 | % |  |  | 62,080 |  |  |  | 31 | % |
| Interest income (expense) and other, net |  |  | (1,269 | ) |  |  | * |  |  |  | 79 |  |  |  | * |  |
| Income before provision for income taxes |  |  | 124,023 |  |  |  | 35 | % |  |  | 62,159 |  |  |  | 31 | % |
| Provision for income taxes |  |  | 21,434 |  |  |  | 6 | % |  |  | 12,432 |  |  |  | 6 | % |
| Net income |  | $ | 102,589 |  |  |  | 29 | % |  | $ | 49,727 |  |  |  | 25 | % |
| * Less than 1% |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| (1) Includes stock-based compensation as follows: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of revenues |  | $ | 117 |  |  |  |  |  |  | $ | 30 |  |  |  |  |  |
| Research and development |  |  | 542 |  |  |  |  |  |  |  | 285 |  |  |  |  |  |
| Sales, general and administrative |  |  | 834 |  |  |  |  |  |  |  | 637 |  |  |  |  |  |
| Total stock-based compensation |  | $ | 1,493 |  |  |  |  |  |  | $ | 952 |  |  |  |  |  |
| (2) Includes a gain from a trademark coexistence agreement as follows: |  | $ | (1,500 | ) |  |  |  |  |  | $ | — |  |  |  |  |  |

[0001193125-12-408603:mdna:81]
Revenues

[0001193125-12-408603:mdna:82]
Revenues increased $155.6 million, or 79%, from $197.9 million in fiscal 2011 to $353.5 million in fiscal 2012. During fiscal 2012, the increase in revenues was due to higher unit volumes shipped,
primarily attributable to the success of our systems products, most notably our airMAX platform. Although we cannot quantify the impact with any certainty, during fiscal 2012 we believe we experienced lost sales due to counterfeit goods. Although we
have taken comprehensive legal actions to stop counterfeiters and minimize the impact of their activities, we believe that the amount of counterfeited goods, combined with the impact it has on our distributor’s inventory and the purchasing
patterns of our customers, will negatively impact our revenues during fiscal 2013. Should we be unsuccessful in stopping the counterfeiting efforts or if new counterfeited products are introduced, our sales in the longer term will also be negatively
impacted.

[0001193125-12-408603:mdna:83]
In fiscal 2012, revenues from Flytec and Streakwave represented 16% and 10%, respectively, of our revenues. In fiscal 2011, Flytec
and Streakwave represented 20% and 15% of our revenues, respectively. No other distributor or customer represented more than 10% of our revenues in fiscal 2012 or fiscal 2011.

[0001193125-12-408603:mdna:84]
50

[0001193125-12-408603:mdna:85]
Revenues by Product Type

[0001193125-12-408603:mdna:86]
|  |  | Years Ended June 30, |  |
|  |  | 2012 |  |  | 2011 |  |
|  |  | (In thousands, except percentages) |  |
| airMAX |  | $ | 223,743 |  |  |  | 63 | % |  | $ | 113,001 |  |  |  | 57 | % |
| New platforms |  |  | 29,465 |  |  |  | 8 | % |  |  | 2,513 |  |  |  | 1 | % |
| Other systems |  |  | 52,086 |  |  |  | 15 | % |  |  | 44,884 |  |  |  | 23 | % |
| Systems |  |  | 305,294 |  |  |  | 86 | % |  |  | 160,398 |  |  |  | 81 | % |
| Embedded radio |  |  | 10,056 |  |  |  | 3 | % |  |  | 14,762 |  |  |  | 7 | % |
| Antennas/other |  |  | 38,167 |  |  |  | 11 | % |  |  | 22,714 |  |  |  | 12 | % |
| Total revenues |  | $ | 353,517 |  |  |  | 100 | % |  | $ | 197,874 |  |  |  | 100 | % |

[0001193125-12-408603:mdna:87]
Systems revenues increased $144.9 million, or 90%, from $160.4 million fiscal 2011 to $305.3 million in fiscal 2012. The
increase in systems revenues was primarily driven by rapid adoption of our airMAX platform, which we introduced in early fiscal 2010. Our new platforms category, which includes significant platforms introduced in late fiscal 2011 and during 2012,
contributed $29.5 million and $2.5 million of revenue in fiscal 2012 and 2011, respectively. Our other systems revenue increased $7.2 million during fiscal 2012 as compared to fiscal 2011, primarily due to a specific customer network expansion
during the quarter ending December 31, 2011.

[0001193125-12-408603:mdna:88]
Embedded radio revenues decreased by $4.7 million from fiscal 2011 to fiscal 2012. We
anticipate that embedded radio products will decline in future periods as sales of these products are outpaced by sales of systems products.

[0001193125-12-408603:mdna:89]
Antennas/other revenues increased $15.5 million, or 68%, from $22.7 million in fiscal 2011 to $38.2 million in fiscal 2012. A primary driver of
growth in antennas/other revenues was the broadening of our systems platforms, which drove demand for associated antennas. Antennas/other revenues also increased due to the growing sales of accessories purchased in connection with deployment of new
systems, such as cables. Other revenues also include revenues that are attributable to PCS. We anticipate that antenna/other revenues will continue to increase in absolute dollars in future periods but will decline as a percentage of total revenues
due to more rapid growth of systems revenues.

[0001193125-12-408603:mdna:90]
Revenues by Geography

[0001193125-12-408603:mdna:91]
We generally deliver product directly from our manufacturers to freight companies in Hong Kong, which have been retained by our customers and who in turn ship to other locations throughout the world. We
have determined the geographical distribution of our product revenues based on ship-to destinations. A majority of our sales are to distributors who in turn sell to resellers or directly to end customers. As a result of these factors, we believe
that sales to certain geographic locations might be higher or lower, as the ultimate destinations are difficult to ascertain. The increase in revenues in absolute dollars across all regions was primarily driven by the success of our systems
products, most notably our airMAX product line.

[0001193125-12-408603:mdna:92]
The following are our revenues by geography for fiscal 2012 and fiscal 2011.

[0001193125-12-408603:mdna:93]
|  |  | Years Ended June 30, |  |
|  |  | 2012 |  |  | 2011 |  |
|  |  | (In thousands, except percentages) |  |
| North America |  | $ | 88,309 |  |  |  | 25 | % |  | $ | 61,920 |  |  |  | 31 | % |
| South America |  |  | 88,325 |  |  |  | 25 | % |  |  | 50,824 |  |  |  | 26 | % |
| Europe, the Middle East and Africa |  |  | 130,494 |  |  |  | 37 | % |  |  | 68,297 |  |  |  | 35 | % |
| Asia Pacific |  |  | 46,389 |  |  |  | 13 | % |  |  | 16,833 |  |  |  | 8 | % |
| Total revenues |  | $ | 353,517 |  |  |  | 100 | % |  | $ | 197,874 |  |  |  | 100 | % |

[0001193125-12-408603:mdna:94]
Cost of Revenues and Gross Margin

[0001193125-12-408603:mdna:95]
Cost of revenues increased $85.5 million, or 73%, from $117.1 million in fiscal 2011 to $202.5 million in fiscal 2012. Gross margin increased from 41% in fiscal 2011 to 43% in fiscal 2012. The increase in
gross margins reflected a high level of revenue growth across a non-inventory cost of sales base that only saw a slight increase, and an increased focus on managing supply chain costs.

[0001193125-12-408603:mdna:96]
Operating Expenses

[0001193125-12-408603:mdna:97]
Research and Development

[0001193125-12-408603:mdna:98]
Research and development expenses increased $5.3 million, or 47%, from $11.4 million in fiscal 2011 to $16.7 million in fiscal 2012. However, as a
percentage of revenues, research and development expenses decreased from 6% in fiscal 2011 to 5% in fiscal 2012. The increase in research and development expenses in absolute dollars in was due to increases in headcount and related expenses as we
broadened our research and development activities to new product areas. As a percentage of revenues research and development expenses decreased due to our overall revenue growth. Over time, we expect our research and development costs to increase in
absolute dollars as we continue making significant investments in developing new products and developing new versions of our existing products.

[0001193125-12-408603:mdna:99]
Sales, General and Administrative

[0001193125-12-408603:mdna:100]
Sales, general and administrative expenses increased $1.7 million, or 22%, from $7.4 million in fiscal 2011 to $9.0 million in fiscal 2012. As a
percentage of revenues, sales, general and administrative expenses decreased from 4% in fiscal 2011 to 3% in fiscal 2012. Sales, general and administrative expenses increased slightly due to increased personnel costs and increased costs associated
with our being and the preparation to be a public company. However, as a percentage of revenues sales, general and administrative expenses decreased slightly due to our overall revenue growth. Additionally, during fiscal 2012 we had a gain of $1.5
million related to a trademark coexistence agreement which the Company included as a reduction to its general and administrative expenses. Over time, we expect our sales, general and administrative expenses to increase in absolute dollars due to
continued growth in headcount to support our business and operations as a public company.

[0001193125-12-408603:mdna:101]
Interest Income (Expense) and Other, Net

[0001193125-12-408603:mdna:102]
Interest income (expense) and other, net was ($1.3) million for fiscal 2012, representing a decrease of $1.3 million from
interest income (expense) and other, net of $79,000 for fiscal 2011. The decrease was primarily due to interest expense accrued on our convertible subordinated promissory notes issued as part of the repurchase of Series A convertible preferred stock
from entities affiliated with Summit Partners, L.P. in July 2011 and interest expense accrued on our term loan agreement with East West Bank which we entered into in September 2011.

[0001193125-12-408603:mdna:103]
Provision for Income Taxes

[0001193125-12-408603:mdna:104]
Our provision for income taxes increased $9.0 million,
or 72%, from $12.4 million for fiscal 2011 to $21.4 million for fiscal 2012 related to increased levels of profitability. Our effective tax rate decreased to 17% for fiscal 2012 as compared to 20% for fiscal 2011 primarily due to increased
sales in foreign tax jurisdictions with lower income tax rates. We do not expect any significant increases or decreases to our unrecognized tax benefits in the next twelve months.

[0001193125-12-408603:mdna:105]
Comparison of Years Ended June 30, 2011 and 2010

[0001193125-12-408603:mdna:106]
|  |  | Years Ended June 30, |  |
|  |  | 2011 |  |  |  |  |  | 2010 |  |  |  |  |
|  |  | (In thousands, except percentages) |  |
| Revenues |  | $ | 197,874 |  |  |  | 100 | % |  | $ | 136,952 |  |  |  | 100 | % |
| Cost of revenues(1) |  |  | 117,062 |  |  |  | 59 | % |  |  | 82,404 |  |  |  | 60 | % |
| Gross profit |  |  | 80,812 |  |  |  | 41 | % |  |  | 54,548 |  |  |  | 40 | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development(1) |  |  | 11,374 |  |  |  | 6 | % |  |  | 31,704 |  |  |  | 23 | % |
| Sales, general and administrative(1)(2) |  |  | 7,358 |  |  |  | 4 | % |  |  | 18,162 |  |  |  | 13 | % |
| Total operating expenses |  |  | 18,732 |  |  |  | 10 | % |  |  | 49,866 |  |  |  | 36 | % |
| Income from operations |  |  | 62,080 |  |  |  | 31 | % |  |  | 4,682 |  |  |  | 4 | % |
| Interest income and other, net |  |  | 79 |  |  |  | * |  |  |  | 581 |  |  |  | * |  |
| Income before provision for income taxes |  |  | 62,159 |  |  |  | 31 | % |  |  | 5,263 |  |  |  | 4 | % |
| Provision for income taxes |  |  | 12,432 |  |  |  | 6 | % |  |  | 10,719 |  |  |  | 8 | % |
| Net income (loss) |  | $ | 49,727 |  |  |  | 25 | % |  | $ | (5,456 | ) |  |  | (4 | )% |

[0001193125-12-408603:mdna:107]
| * | Less than 1% |

[0001193125-12-408603:mdna:108]
| (1) Includes stock-based compensation as follows: |  |  |  |  |  |  |  |  |
| Cost of revenues |  | $ | 30 |  |  | $ | 124 |  |
| Research and development |  |  | 285 |  |  |  | 26,221 |  |
| Sales, general and administrative |  |  | 637 |  |  |  | 9,814 |  |
| Total stock-based compensation |  | $ | 952 |  |  | $ | 36,159 |  |
| (2) Includes a charge for an export compliance matter as follows: |  | $ | — |  |  | $ | 1,625 |  |

[0001193125-12-408603:mdna:109]
Revenues

[0001193125-12-408603:mdna:110]
Revenues increased $60.9 million, or 44%, from $137.0 million in fiscal 2010 to $197.9 million in fiscal 2011. During fiscal 2011, the increase in revenues was primarily attributable to the success of our
systems products, most notably our airMAX product line. Increases in revenues from fiscal 2010 to fiscal 2011 were also attributable to higher unit volume.

[0001193125-12-408603:mdna:111]
In fiscal 2010, revenues from Flytec and Streakwave represented 17% and 13%, respectively, of our revenues. In fiscal 2011, Flytec and Streakwave represented 20% and 15% of our revenues, respectively. No
other distributor or customer represented more than 10% of our revenues in fiscal 2010 or fiscal 2011.

[0001193125-12-408603:mdna:112]
53

[0001193125-12-408603:mdna:113]
Revenues by Product Type

[0001193125-12-408603:mdna:114]
|  |  | Years Ended June 30, |  |
|  |  | 2011 |  |  |  |  |  | 2010 |  |  |  |  |
|  |  | (In thousands, except percentages) |  |
| airMAX |  | $ | 113,001 |  |  |  | 57 | % |  | $ | 37,525 |  |  |  | 27 | % |
| New platforms |  |  | 2,513 |  |  |  | 1 | % |  |  | — |  |  |  | — | % |
| Other systems |  |  | 44,884 |  |  |  | 23 | % |  |  | 75,368 |  |  |  | 55 | % |
| Systems |  |  | 160,398 |  |  |  | 81 | % |  |  | 112,893 |  |  |  | 82 | % |
| Embedded radio |  |  | 14,762 |  |  |  | 7 | % |  |  | 14,047 |  |  |  | 10 | % |
| Antennas/other |  |  | 22,714 |  |  |  | 12 | % |  |  | 10,012 |  |  |  | 8 | % |
| Total revenues |  | $ | 197,874 |  |  |  | 100 | % |  | $ | 136,952 |  |  |  | 100 | % |

[0001193125-12-408603:mdna:115]
Systems revenues increased $47.5 million, or 42%, from $112.9 million in fiscal 2010 to $160.4 million in fiscal 2011. The
increase in systems revenues was driven by rapid adoption of our airMAX product line, which we introduced in early fiscal 2010, partially offset by a decline in our other systems revenues. Our new platforms category, which includes significant
platforms introduced in late fiscal 2011, contributed $2.5 million of revenue in fiscal 2011.

[0001193125-12-408603:mdna:116]
Antennas/other revenues increased
$12.7 million, or 127%, from $10.0 million in fiscal 2010 to $22.7 million in fiscal 2011. A primary driver of growth in antennas/other revenues was the broadening of our systems product lines, which drove demand for associated antennas.
Antennas/other revenues also increased due to the growing sales of accessories purchased in connection with deployment of new systems, such as cables. Other revenues also include revenues that are attributable to PCS.

[0001193125-12-408603:mdna:117]
Revenues by Geography

[0001193125-12-408603:mdna:118]
The increase in
revenues in absolute dollars across all regions was primarily driven by the success of our systems products, most notably our airMAX product line. The following are our revenues by geography for fiscal 2011 and fiscal 2010.

[0001193125-12-408603:mdna:119]
|  |  | Years Ended June 30, |  |
|  |  | 2011 |  |  |  |  |  | 2010 |  |  |  |  |
|  |  | (In thousands, except percentages) |  |
| North America |  | $ | 61,920 |  |  |  | 31 | % |  | $ | 56,995 |  |  |  | 42 | % |
| South America |  |  | 50,824 |  |  |  | 26 | % |  |  | 13,520 |  |  |  | 10 | % |
| Europe, the Middle East and Africa |  |  | 68,297 |  |  |  | 35 | % |  |  | 55,089 |  |  |  | 40 | % |
| Asia Pacific |  |  | 16,833 |  |  |  | 8 | % |  |  | 11,348 |  |  |  | 8 | % |
| Total revenues |  | $ | 197,874 |  |  |  | 100 | % |  | $ | 136,952 |  |  |  | 100 | % |

[0001193125-12-408603:mdna:120]
Cost of Revenues and Gross Margin

[0001193125-12-408603:mdna:121]
Cost of revenues increased $34.7 million, or 42%, from $82.4 million in fiscal 2010 to $117.1 million in fiscal 2011, primarily due to growth in revenues and changes in product mix from embedded radios to
our systems products. Gross margin remained relatively stable and was 40% and 41% in fiscal 2010 and 2011, respectively, reflecting the fact that a substantial majority of our revenues was from systems products. We believe that our gross margins
have largely stabilized and do not expect substantial additional fluctuations in gross margins in the near term.

[0001193125-12-408603:mdna:122]
Operating Expenses

[0001193125-12-408603:mdna:123]
Research and Development

[0001193125-12-408603:mdna:124]
Research and development expenses decreased $20.3 million, or
64%, from $31.7 million in fiscal 2010 to $11.4 million in fiscal 2011. Research and development expense in fiscal 2010 included $26.2 million of stock-based compensation resulting from the Summit transaction in March 2010. Excluding the effect
of the Summit transaction, research and development costs increased $5.9 million, or 106%, from $5.5 million in fiscal 2010 to $11.4 million in the fiscal 2011. Excluding the compensation expense related to the Summit transaction, as a percentage of
revenues, research and development expenses increased from 4% in fiscal 2010 to 6% in fiscal 2011. These increases in research and development expenses were due to increases in headcount as we broadened our research and development activities to new
product areas. Over time, we expect our research and development costs to increase as we continue making significant investments in developing new products and developing new versions of our existing products.

[0001193125-12-408603:mdna:125]
Sales, General and Administrative

[0001193125-12-408603:mdna:126]
Sales, general and administrative expenses decreased $10.8 million, or 59%, from $18.2 million in fiscal 2010 to $7.4 million in fiscal 2011. Sales,
general and administrative expense in fiscal 2010 included $9.6 million of stock-based compensation resulting from the Summit transaction in March 2010 and a $1.6 million charge related to an export compliance matter. Excluding the effect of the
Summit transaction and the export compliance matter, sales, general and administrative costs increased $406,000, or 6%, from $7.0 million in fiscal 2010 to $7.4 million in fiscal 2011. Excluding the stock-based compensation expense related to the
Summit transaction and the charge related to an export compliance matter, as a percentage of revenues, sales, general and administrative expenses decreased from 5% in fiscal 2010 to 4% in fiscal 2011. Excluding the effects of the Summit transaction
and the export compliance matter, sales, general and administrative expenses increased slightly due to increased personnel costs and increased costs associated with our preparation to be a public company. However, as a percentage of revenues sales,
general and administrative expenses decreased slightly due to our overall revenue growth. Over time, we expect our sales, general and administrative expenses increase in absolute dollars due to continued growth in headcount to support our business
and operations as a public company.

[0001193125-12-408603:mdna:127]
Provision for Income Taxes

[0001193125-12-408603:mdna:128]
Our provision for income taxes increased $1.7 million, or 16%, from $10.7 million for fiscal 2010 to $12.4 million for fiscal 2011. Our effective tax rate for fiscal 2010 was 204% as compared to
20% for fiscal 2011. Our effective tax rate for fiscal 2010 was largely impacted by non-deductible stock-based compensation expense incurred pursuant to the Summit transaction in March 2010. Exclusive of the impact of the Summit transaction and a
charge for an export compliance matter, our effective tax rate declined from 25% for fiscal 2010 to 20% for fiscal 2011 due to more taxable income being generated in foreign jurisdictions that have lower tax rates than the U.S.

[0001193125-12-408603:mdna:129]
Liquidity and Capital Resources

[0001193125-12-408603:mdna:130]
Since
inception, our operations primarily have been funded through cash generated by operations, the sale of redeemable convertible preferred stock and the sale of common stock in our initial public offering. We had cash and cash equivalents of $122.1
million, $76.4 million and $28.4 million at June 30, 2012, 2011 and 2010, respectively.

[0001193125-12-408603:mdna:131]
We believe our existing cash and cash
equivalents will be sufficient to meet our working capital and capital expenditure needs for at least the next 12 months. Our future capital requirements may vary materially from those currently planned and will depend on many factors, including our
rate of revenue growth, the timing and extent of spending to support development efforts, the timing of new product introductions, market acceptance of

[0001193125-12-408603:mdna:132]
55

[0001193125-12-408603:mdna:133]
our products and overall economic conditions. As of June 30, 2012, we held $102.8 million of our $122.1 million of cash and cash equivalents in accounts of our subsidiaries outside of the
United States and we will incur significant tax liabilities if we decide to repatriate those amounts.

[0001193125-12-408603:mdna:134]
On September 15, 2011, we entered
into a Loan and Security Agreement with East West Bank, (the “EWB Loan Agreement”). The EWB Loan Agreement consists of a $35.0 million term loan facility and a $5.0 million revolving line of credit facility. The term loan matures on
September 15, 2016 with principal and interest to be repaid in 60 monthly installments.

[0001193125-12-408603:mdna:135]
Additionally, on August 7, 2012, we entered
into a Loan and Security Agreement (the “Loan Agreement”) with U.S. Bank, as syndication agent, and East West Bank, as administrative agent, which replaced the EWB Loan Agreement discussed above. The Loan Agreement provides for (i) a
$50.0 million revolving credit facility, with a $5.0 million sublimit for the issuance of letters of credit and a $5.0 million sublimit for the making of swingline loan advances (the “Revolving Credit Facility”), and (ii) a $50.0
million term loan facility (the “Term Loan Facility”). We may request borrowings under the Revolving Credit Facility until August 7, 2015. On August 7, 2012, we borrowed an additional $20.8 million of term loans under the Term
Loan Facility.

[0001193125-12-408603:mdna:136]
On August 9, 2012, we announced that our Board of Directors authorized us to repurchase up to $100 million of our common
stock. The share repurchase program commenced Monday, August 13, 2012. The share repurchase program will be funded from existing cash on hand and from the proceeds from the Loan Agreement as discussed above.

[0001193125-12-408603:mdna:137]
The following table sets forth the major components of our consolidated statements of cash flows data for the periods presented:

[0001193125-12-408603:mdna:138]
|  |  | Years Ended June 30, |  |
|  |  | 2012 |  |  | 2011 |  |  | 2010 |  |
|  |  | (In thousands) |  |
| Net cash provided by (used in) operating activities |  | $ | 81,788 |  |  | $ | 62,842 |  |  | $ | (25,985 | ) |
| Net cash used in investing activities |  |  | (3,310 | ) |  |  | (479 | ) |  |  | (615 | ) |
| Net cash (used in) provided by financing activities |  |  | (32,779 | ) |  |  | (14,417 | ) |  |  | 41,341 |  |
| Net increase in cash and cash equivalents |  | $ | 45,699 |  |  | $ | 47,946 |  |  | $ | 14,741 |  |

[0001193125-12-408603:mdna:139]
Cash Flows from Operating Activities

[0001193125-12-408603:mdna:140]
Net cash provided by operating activities in fiscal 2012 of $81.8 million consisted primarily of net income of $102.6 million offset by changes in operating assets and liabilities. These changes
consisted primarily of a $36.6 million increase in accounts receivable due to our overall revenue growth and slower payment patterns from our customers, a $16.5 million increase in accounts payable and accrued liabilities due to increased
overall business activity, a $9.5 million increase in taxes payable due to our higher profitability, a $3.7 million decrease in prepaid expenses and other current assets due primarily to decreased deposits with our vendors and a
$2.3 million increase in inventories related to increases in our overall business activity. Additionally, our net income included non-cash adjustments due to stock-based compensation, depreciation and amortization, adjustments to our provisions
for doubtful accounts and inventory obsolescence and an excess tax benefit from stock-based awards. The net of these non-cash adjustments resulted in a reduction of our net cash provided by operating activities of $11.6 million.

[0001193125-12-408603:mdna:141]
Net cash provided by operating activities in fiscal 2011 of $63.0 million increased from cash used in operating activities of $26.0 million in fiscal
2010. The increase in net cash provided by operating activities resulted from net income of $49.7 million and increases in operating assets and liabilities of $13.2 million in fiscal 2011. Changes in operating assets and liabilities consisted
primarily of a $20.3 million increase in accounts payable and accrued liabilities, a $5.9 million increase in accounts receivable, a $1.3 million increase in taxes payable, a

[0001193125-12-408603:mdna:142]
$1.1 million increase in inventories, a $715,000 increase in prepaid expenses and other current assets and a net decrease of $810,000 in deferred revenues and deferred cost of revenues.

[0001193125-12-408603:mdna:143]
Cash used in operating activities of $26.0 million in fiscal 2010 declined substantially from cash provided by operating activities of
$7.3 million in fiscal 2009. The decline in cash used in operating activities resulted from our net loss of $5.5 million, net noncash charges and credits of $453,000 and a net increase in operating assets and liabilities of $21.0 million.
Noncash charges and credits primarily consisted of an $800,000 charge for bad debt expense, offset by a $645,000 credit for deferred taxes. Excluding the $35.9 million charge related to the Summit transaction, we would have generated
$9.9 million of cash from operating activities in fiscal 2010. Changes in operating assets and liabilities primarily consisted of $29.5 million increase in accounts receivable, a $10.1 million increase in deferred revenues offset by an increase
in deferred cost of revenues of $5.9 million, a $7.9 million increase in accounts payable and accrued liabilities, a $4.1 million increase in inventories, a $1.6 million increase in income taxes payable and a $1.0 million increase in prepaid
expenses and other current assets.

[0001193125-12-408603:mdna:144]
Cash Flows from Investing Activities

[0001193125-12-408603:mdna:145]
Our investing activities consist solely of capital expenditures. Capital expenditures for fiscal 2012, 2011 and 2010 were $3.3 million, $479,000 and
$615,000, respectively.

[0001193125-12-408603:mdna:146]
Cash Flows from Financing Activities

[0001193125-12-408603:mdna:147]
We used $32.8 million of cash in financing activities during fiscal 2012. In July 2011, we repurchased an aggregate of 12,041,700 shares of our Series A preferred stock from entities affiliated with
Summit Partners, L.P., one of our major stockholders, at a price of $8.97 per share for an aggregate consideration of $108.0 million. Of the aggregate purchase price, $40.0 million was paid in cash at the time of closing and the balance of the
shares were paid for through the issuance of convertible subordinated promissory notes in the aggregate principal amount of $68.0 million. The $68.0 million was paid down primarily using proceeds from the term loan we executed with East West Bank on
September 15, 2011 and funds raised upon the completion of our initial public offering on October 19, 2011.

[0001193125-12-408603:mdna:148]
On September 15,
2011, we entered into the EWB Loan Agreement, which consists of a $35.0 million term loan facility and a $5.0 million revolving line of credit facility. We used $34.0 million of the term loan to repay a portion of our outstanding convertible
subordinated promissory notes held by entities affiliated with Summit Partners, L.P. During fiscal 2012, we paid down the loan balance by $5.3 million.

[0001193125-12-408603:mdna:149]
On October 19, 2011, we completed an initial public offering whereby we sold 2,395,328 shares and selling stockholders sold 4,642,902 shares of our common stock. During the six months ended
December 31, 2011, we received net proceeds of $32.6 million after deducting the underwriting fees and commissions and other offering expenses.

[0001193125-12-408603:mdna:150]
During fiscal 2012, we received $811,000 in cash from stock option exercises, paid $1.4 million related to employee tax withholdings on net share settlements of restricted stock units and had an excess
tax benefit from stock-based awards of $13.8 million.

[0001193125-12-408603:mdna:151]
We used $14.4 million of cash in financing activities during fiscal 2011. During
fiscal 2011, we entered into a stock purchase agreement to repurchase 2,975,590 shares of common stock from three stockholders for total consideration of $7.3 million. In fiscal 2011, we also repurchased and subsequently cancelled options to
purchase 420,400 shares of our common stock from two of our option holders for aggregate consideration of $2.2 million. Additionally, we paid a dividend on our Series A convertible preferred stock of $3.0 million and paid $1.8 million in costs
related to third party consulting services associated with the offering.

[0001193125-12-408603:mdna:152]
Our financing activities provided net cash of $41.3 million
during fiscal 2010. Net financing activities consisted primarily of proceeds from the issuance of Series A preferred stock for $100.0 million from Summit Partners, $500,000 paid for legal and other administrative costs related to the
closing of the transaction with entities affiliated with Summit Partners, offset by $64.1 million of repurchases of common stock and cancellation of

[0001193125-12-408603:mdna:153]
57

[0001193125-12-408603:mdna:154]
options in connection with the issuance of Series A preferred stock. Additionally, proceeds of $6.3 million were provided from the exercise of Series A preferred stock warrants issued to
entities affiliated with Summit Partners, L.P. and $512,000 was used for the repurchase of common stock unrelated to the Summit transaction.

[0001193125-12-408603:mdna:155]
Stock Split

[0001193125-12-408603:mdna:156]
In October 2011 we
completed a 2.5 for one forward stock split of our common and preferred stock. All share and per share information set forth herein has been retroactively adjusted to reflect the split.

[0001193125-12-408603:mdna:157]
Contractual Obligations and Off-Balance Sheet Arrangements

[0001193125-12-408603:mdna:158]
We lease our headquarters in
San Jose, California and other locations worldwide under noncancelable operating leases that expire at various dates through fiscal 2017.

[0001193125-12-408603:mdna:159]
In
July 2011, we entered into an agreement to lease additional office space for our research and development offices in Taiwan. The lease term is from July 14, 2011 through July 15, 2016. The premises consist of approximately 10,000 rentable
square feet of space. The lease has been categorized as an operating lease, and the total lease obligation is approximately $1.6 million.

[0001193125-12-408603:mdna:160]
In
December 2011, we entered into an agreement to lease approximately 64,512 square feet of office and research and development space located in San Jose, California, which will be used as our corporate headquarters. The lease term is from
April 1, 2012, though June 30, 2017. The lease has been categorized as an operating lease, and the total estimated lease obligation is approximately $4.9 million.

[0001193125-12-408603:mdna:161]
The following table summarizes our contractual obligations as of June 30, 2012:

[0001193125-12-408603:mdna:162]
|  |  | Payments Due by Period |  |  |  |  |
|  |  | Less Than 1 Year |  |  | 1-3 Years |  |  | 4-5 years |  |  | Over 5 years |  |  | Total |  |
|  |  | (In thousands) |  |  |  |  |
| Operating leases |  | $ | 1,240 |  |  | $ | 2,759 |  |  | $ | 2,540 |  |  | $ | — |  |  | $ | 6,539 |  |
| Debt payment obligations |  |  | 7,000 |  |  |  | 14,000 |  |  |  | 8,750 |  |  |  | — |  |  |  | 29,750 |  |
| Interest payments on debt payment obligations |  |  | 730 |  |  |  | 882 |  |  |  | 160 |  |  |  | — |  |  |  | 1,772 |  |
| Total |  | $ | 8,970 |  |  | $ | 17,641 |  |  | $ | 11,450 |  |  | $ | — |  |  | $ | 38,061 |  |

[0001193125-12-408603:mdna:163]
We subcontract with other companies to manufacture our products. During the normal course of business, our contract
manufacturers procure components based upon orders placed by us. If we cancel all or part of the orders, we may still be liable to the contract manufacturers for the cost of the components purchased by the subcontractors to manufacture our products.
We periodically review the potential liability and to date no accruals have been recorded. Our consolidated financial position and results of operations could be negatively impacted if we were required to compensate the contract manufacturers for
any unrecorded liabilities incurred.

[0001193125-12-408603:mdna:164]
As of June 30, 2012, we had $8.0 million of unrecognized tax benefits, substantially all of which
would, if recognized, affect our tax expense. We have elected to include interest and penalties related to uncertain tax positions as a component of tax expense. We do not expect any significant increases or decreases to our unrecognized tax
benefits in the next twelve months.

[0001193125-12-408603:mdna:165]
Commitments and Contingencies

[0001193125-12-408603:mdna:166]
In January 2011, the U.S. Department of Commerce’s Bureau of Industry (“BIS”) and Security’s Office of Export Enforcement (“OEE”) contacted us to request that we provide
information related to our relationship with a logistics company in the United Arab Emirates (“UAE”) and with a company in Iran, as well as information on the export classification of our products. As a result of this inquiry we, assisted
by outside counsel, conducted a review of our export transactions from 2008 through March 2011 to not only gather information responsive to the

[0001193125-12-408603:mdna:167]
OEE’s request but also to review our overall compliance with export control and sanctions laws. We believe our products have been sold into Iran by third parties. We do not believe that we
directly sold, exported or shipped our products into Iran or any other country subject to a U.S. embargo. However, until early 2010, we did not prohibit our distributors from selling our products into Iran or any other country subject to a U.S.
embargo. In the course of this review we identified that two distributors may have sold Ubiquiti products into Iran. Our review also found that while we had obtained required Commodity Classification Rulings for our products in June 2010 and
November 2010, we did not advise our shipping personnel to change the export authorizations used on our shipping documents until February 2011. During the course of our export control review, we also determined that we had failed to maintain
adequate records for the five year period required by the EAR and the sanctions regulations due to our lack of infrastructure and because it was prior to our transition to our system of record, NetSuite. See “Risk Factors—We are subject
to numerous U.S. export control and economic sanctions laws and a substantial majority of our sales are into countries outside of the United States. Although we did not intend to do so, we have violated certain of these laws in the past, and we
cannot currently assess the nature and extent of any fines or other penalties, if any, that U.S. governmental agencies may impose against us or our employees for any such violations. Any fines, if materially different from our estimates, or other
penalties, could have a material adverse effect on our business and financial results.”

[0001193125-12-408603:mdna:168]
In May 2011, we filed a self-disclosure with
OEE and, in June 2011 we filed one with U.S. Department of the Treasury’s Office of Foreign Asset Control (“OFAC”), regarding the compliance issues noted above. The disclosures address the above described findings and the remedial
actions we have taken to date. However, the findings also indicate that both distributors continued to sell, directly or indirectly, our products into Iran during the period from February 2010 through March 2011 and that we received various
communications from them indicating that they were continuing to do so. Since January 2011, we have cooperated with OEE and, prior to our disclosure filing, we informally shared with the OEE the substance of our findings with respect to both
distributors. From May 2011 to August 2011, we provided additional information regarding our review and our findings to OEE to facilitate its investigation and OEE advised us in August 2011 that it had completed its investigation of us. In
August 2011, we received a warning letter from OEE stating that OEE had not referred the findings of our review for criminal or administrative prosecution of us and closed the investigation of us without penalty.

[0001193125-12-408603:mdna:169]
OFAC is still reviewing our voluntary disclosure. In our submission, we have provided OFAC with an explanation of the activities that led to the sales of
our products in Iran and the failure to comply with the EAR and OFAC sanctions. Although our OFAC and OEE voluntary disclosures covered similar sets of facts, which led OEE to resolve the case with the issuance of a warning letter, OFAC may conclude
that our actions resulted in violations of U.S. export control and economic sanctions laws and warrant the imposition of penalties that could include fines, termination of our ability to export our products and/or referral for criminal prosecution.
Any such fines may be material to our financial results in the period in which they are imposed. The penalties may be imposed against us and/or our management. The maximum civil monetary penalty for the violations is up to $250,000 or twice the
value of the transaction, whichever is greater, per violation. Also, disclosure of our conduct and any fines or other action relating to this conduct could harm our reputation and indirectly have a material adverse effect on our business. We cannot
predict when OFAC will complete its review or decide upon the imposition of possible penalties.

[0001193125-12-408603:mdna:170]
Based on the facts known to us to date, we
recorded an expense of $1.6 million for this export compliance matter in fiscal 2010, which represents management’s estimated exposure for fines in accordance with applicable accounting literature. Should additional facts be discovered in the
future and/or should actual fines or other penalties substantially differ from our estimates, our business, financial condition, cash flows and results of operations would be materially negatively impacted.

[0001193125-12-408603:mdna:171]
Warranties and Indemnifications

[0001193125-12-408603:mdna:172]
Our
products are generally accompanied by a 12 month warranty, which covers both parts and labor. Generally the distributor is responsible for the freight costs associated with warranty returns, and we absorb the freight costs of replacing items under
warranty. In accordance with the Financial Accounting Standards Board’s

[0001193125-12-408603:mdna:173]
59

[0001193125-12-408603:mdna:174]
(“FASB’s”), Accounting Standards Codification (“ASC”), 450-30, Loss Contingencies, we record an accrual when we believe it is estimable and probable based upon historical
experience. We record a provision for estimated future warranty work in cost of goods sold upon recognition of revenues and we review the resulting accrual regularly and periodically adjust it to reflect changes in warranty estimates.

[0001193125-12-408603:mdna:175]
We may in the future enter into standard indemnification agreements with many of our distributors and OEMs, as well as certain other business partners in
the ordinary course of business. These agreements may include provisions for indemnifying the distributor, OEM or other business partner against any claim brought by a third party to the extent any such claim alleges that a Ubiquiti product
infringes a patent, copyright or trademark or violates any other proprietary rights of that third party. The maximum amount of potential future indemnification is unlimited. The maximum potential amount of future payments we could be required to
make under these indemnification agreements is not estimable.

[0001193125-12-408603:mdna:176]
We have agreed to indemnify our directors, officers and certain other employees
for certain events or occurrences, subject to certain limits, while such persons are or were serving at our request in such capacity. We may terminate the indemnification agreements with these persons upon the termination of their services with us
but termination will not affect claims for indemnification related to events occurring prior to the effective date of termination. The maximum amount of potential future indemnification is unlimited. We have a director and officer insurance policy
that limits our potential exposure. We believe the fair value of these indemnification agreements is minimal. We had not recorded any liabilities for these agreements as of June 30, 2012 or 2011.

[0001193125-12-408603:mdna:177]
Based upon our historical experience and information known as of the date of this report, we do not believe it is likely that we will have significant
liability for the above indemnities at June 30, 2012.

[0001193125-12-408603:mdna:178]
Based upon our historical experience and information known as of June 30,
2012, we do not believe it is likely that we will have significant liability for the above indemnities at June 30, 2012.

[0001193125-12-408603:mdna:179]
Off-Balance
Sheet Arrangements

[0001193125-12-408603:mdna:180]
As of June 30, 2012 and 2011, we had no off-balance sheet arrangements other than those indemnification agreements
described above.

[0001193125-12-408603:mdna:181]
Recent Accounting Pronouncements

[0001193125-12-408603:mdna:182]
In May 2011 the FASB further amended its guidance related to fair value measurements in order to achieve common fair value measurements between U.S. GAAP and International Financial Reporting Standards.
The amendments in the updated guidance explain how to measure fair value. They do not require additional fair value measurements and are not intended to establish valuation standards or affect valuation practices outside of financial reporting. The
amendments change the wording used to describe many of the requirements in U.S. GAAP for measuring fair value and for disclosing information about fair value measurements. For many of the requirements, the updated guidance should not result in a
change in the application of previous fair value measurement guidance. The updated guidance is effective during interim and annual periods beginning after December 15, 2011. The adoption of the amended guidance on January 1, 2012 did not
have an impact on our consolidated financial statements.

[0001193125-12-408603:mdna:183]
In June 2011, the FASB updated its guidance related to the presentation of
comprehensive income. Under the updated guidance, an entity has the option to present the total of comprehensive income, the components of net income, and the components of other comprehensive income either in a single continuous statement of
comprehensive income or in two separate but consecutive statements. In both choices, an entity is required to present each component of net income along with total net income, each component of other comprehensive income along with a total for other
comprehensive income, and a total amount for comprehensive income. The updated guidance eliminates the option to present the components of other comprehensive income as part of the statement of changes in stockholders’ equity. The amendments in
the updated guidance do not change the items

[0001193125-12-408603:mdna:184]
60

[0001193125-12-408603:mdna:185]
that must be reported in other comprehensive income or when an item of other comprehensive income must be reclassified to net income. In December 2011, the FASB further amended its guidance to
defer charges related to the presentation of reclassification adjustments indefinitely as a result of concerns raised by stakeholders that the new presentation requirements would be difficult for preparers and add unnecessary complexity to financial
statements. The updated guidance, other than the portion related to the presentation of reclassification adjustments, will be effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2011, with
early adoption permitted. The updated guidance must be applied retrospectively. We do not expect the adoption of the guidance on July 1, 2012 to have an impact on our consolidated financial statements.

[0001193125-12-408603:mdna:186]
Non-GAAP Financial Measures

[0001193125-12-408603:mdna:187]
Regulation G, conditions for use of Non-Generally Accepted Accounting Principles (“Non-GAAP”) financial measures, and other SEC regulations
define and prescribe the conditions for use of certain Non-GAAP financial information. To supplement our consolidated financial results presented in accordance with GAAP, we use Non-GAAP financial measures which are adjusted from the most directly
comparable GAAP financial measures to exclude certain items, as described below. Management believes that these Non-GAAP financial measures reflect an additional and useful way of viewing aspects of our operations that, when viewed in conjunction
with our GAAP results, provide a more comprehensive understanding of the various factors and trends affecting our business and operations. Non-GAAP financial measures used by us include net income or loss and diluted net income or loss per share.

[0001193125-12-408603:mdna:188]
Our Non-GAAP measures primarily exclude stock-based compensation, net of taxes and other special charges and credits. Management believes
these Non-GAAP financial measures provide meaningful supplemental information regarding our strategic and business decision making, internal budgeting, forecasting and resource allocation processes. In addition, these Non-GAAP financial measures
facilitate management’s internal comparisons to our historical operating results and comparisons to competitors’ operating results.

[0001193125-12-408603:mdna:189]
We use each of these Non-GAAP financial measures for internal managerial purposes, when providing our financial results and business outlook to the
public and to facilitate period-to-period comparisons. Management believes that these Non-GAAP measures provide meaningful supplemental information regarding our operational and financial performance of current and historical results. Management
uses these Non-GAAP measures for strategic and business decision making, internal budgeting, forecasting and resource allocation processes. In addition, these Non-GAAP financial measures facilitate management’s internal comparisons to our
historical operating results and comparisons to competitors’ operating results.

[0001193125-12-408603:mdna:190]
The following table shows our Non-GAAP financial
measures:

[0001193125-12-408603:mdna:191]
|  |  | Years Ended June 30, |  |
|  |  | 2012 |  |  | 2011 |  |  | 2010 |  |
|  |  | (In thousands, except per share amounts) |  |
| Non-GAAP net income |  | $ | 102,585 |  |  | $ | 50,298 |  |  | $ | 32,023 |  |
| Non-GAAP diluted net income per share of common stock |  | $ | 1.09 |  |  | $ | 0.49 |  |  | $ | 0.30 |  |

[0001193125-12-408603:mdna:192]
We believe that providing these Non-GAAP financial measures, in addition to the GAAP financial results, are useful to
investors because they allow investors to see our results “through the eyes” of management as these Non-GAAP financial measures reflect our internal measurement processes. Management believes that these Non-GAAP financial measures enable
investors to better assess changes in each key element of our operating results across different reporting periods on a consistent basis and provides investors with another method for assessing our operating results in a manner that is focused on
the performance of our ongoing operations.

[0001193125-12-408603:mdna:193]
The following table shows a reconciliation of GAAP net income to non-GAAP net income:

[0001193125-12-408603:mdna:194]
|  |  | Years Ended June 30, |  |
|  |  | 2012 |  |  | 2011 |  |  | 2010 |  |
|  |  | (In thousands, except per share amounts) |  |
| GAAP net income (loss) |  | $ | 102,589 |  |  | $ | 49,727 |  |  | $ | (5,456 | ) |
| Ordinary course stock-based compensation expense: |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of revenues |  |  | 117 |  |  |  | 30 |  |  |  | 25 |  |
| Research and development |  |  | 542 |  |  |  | 285 |  |  |  | 27 |  |
| Sales, general and administrative |  |  | 834 |  |  |  | 637 |  |  |  | 229 |  |
| Total ordinary course stock-based compensation expense |  |  | 1,493 |  |  |  | 952 |  |  |  | 281 |  |
| Stock-based compensation expense related to the Summit transaction: |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of revenues |  |  | — |  |  |  | — |  |  |  | 99 |  |
| Research and development |  |  | — |  |  |  | — |  |  |  | 26,194 |  |
| Sales, general and administrative |  |  | — |  |  |  | — |  |  |  | 9,585 |  |
| Total stock-based compensation expense related to the Summit transaction |  |  | — |  |  |  | — |  |  |  | 35,878 |  |
| Charge for a regulatory export compliance issue |  |  | — |  |  |  | — |  |  |  | 1,625 |  |
| Gain from a trademark coexistence agreement |  |  | (1,500 | ) |  |  | — |  |  |  | — |  |
| Tax effect of non-GAAP adjustments |  |  | 3 |  |  |  | (381 | ) |  |  | (305 | ) |
| Non-GAAP net income |  | $ | 102,585 |  |  | $ | 50,298 |  |  | $ | 32,023 |  |
| Non-GAAP diluted income per share(1) |  | $ | 1.09 |  |  | $ | 0.49 |  |  | $ | 0.30 |  |
| Weighted-average shares used in non-GAAP diluted income per share(1) |  |  | 93,762 |  |  |  | 102,942 |  |  |  | 105,109 |  |

[0001193125-12-408603:mdna:195]
| (1) | Non-GAAP diluted net income per share of common stock is calculated using non-GAAP net income excluding stock-based compensation and a gain from a trademark coexistence agreement, net of taxes and weighted-average shares outstanding as if Series A preferred stock is treated as common stock for the periods presented. |

[0001193125-12-408603:mdna:196]
The following table shows a reconciliation of weighted-average shares used in computing net income (loss) per share of common stock-diluted to weighted-average shares used in computing non-GAAP diluted
net income per share of common stock:

[0001193125-12-408603:mdna:197]
|  |  | Years Ended June 30, |  |
|  |  | 2012 |  |  | 2011 |  |  | 2010 |  |
|  |  | (In thousands) |  |
| Weighted average shares used in computing net income (loss) per share of common stock- diluted |  |  | 83,460 |  |  |  | 66,907 |  |  |  | 88,972 |  |
| Weighted average dilutive effect of stock options and restricted stock units |  |  | 2,695 |  |  |  | — |  |  |  | 4,125 |  |
| Weighted average shares of Series A preferred stock outstanding |  |  | 7,607 |  |  |  | 36,035 |  |  |  | 12,012 |  |
| Weighted-average shares used in computing non-GAAP diluted income per share of common stock |  |  | 93,762 |  |  |  | 102,942 |  |  |  | 105,109 |  |
