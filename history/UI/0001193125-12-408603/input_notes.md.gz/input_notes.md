# UI notes — 0001193125-12-408603


## us-gaap:BusinessDescriptionAndBasisOfPresentationTextBlock

[0001193125-12-408603:notes:1]
NOTE 1—BUSINESS AND BASIS OF PRESENTATION

[0001193125-12-408603:notes:2]
Business—Ubiquiti Networks, Inc. was incorporated in the State of California in 2003 as Pera Networks, Inc. and commenced
   its current operations in 2005 and changed its name to Ubiquiti Networks, Inc. at that time. In June 2010, the Company changed its state of incorporation to Delaware by merging with and into Ubiquiti Networks, Inc., a Delaware corporation. At the
   same time the Company completed a four-for-one forward stock split of its outstanding common stock, and a proportional adjustment to the existing conversion ratio for preferred stock Series A. On October 3, 2011, the Company completed a
   2.5-for-one forward stock split to its common and preferred stock for all stockholders of record as of October 3, 2011. Accordingly, all share and per share amounts for all periods presented in these consolidated financial statements and notes
   thereto have been adjusted retroactively, where applicable, to reflect these forward stock splits and adjustment of the preferred stock conversion ratio.

[0001193125-12-408603:notes:3]
Ubiquiti Networks, Inc. and its wholly owned subsidiaries (collectively, “Ubiquiti” or the “Company”) is a product driven company that leverages innovative proprietary technologies to
   deliver networking solutions to both startup and established network operators and service providers.

[0001193125-12-408603:notes:4]
On October 13, 2011, the Company
   entered into an underwriting agreement for its initial public offering of its common stock at $15.00 per share, which closed on October 19, 2011. Immediately prior to the closing of the initial public offering, all outstanding shares of the
   Company’s preferred stock converted to common stock on a one for one basis.

[0001193125-12-408603:notes:5]
The Company operates on a fiscal year ending June 30.
   In these notes, Ubiquiti refers to the fiscal years ended June 30, 2012, 2011 and 2010 as fiscal 2012, fiscal 2011 and fiscal 2010, respectively.

[0001193125-12-408603:notes:6]
Basis of Presentation— The Company’s consolidated financial statements and accompanying notes are prepared in accordance with accounting principles generally accepted in the United States
   of America (“GAAP”) and include the accounts of Ubiquiti and its wholly owned subsidiaries. The Company has wholly owned subsidiaries in Lithuania and Hong Kong. The Company’s Hong Kong subsidiary also operates a branch office in
   Taiwan. All material intercompany transactions and balances have been eliminated.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001193125-12-408603:notes:7]
NOTE 2—SUMMARY OF SIGNIFICANT ACCOUNTING POLICIES

[0001193125-12-408603:notes:8]
Use of Accounting Estimates

[0001193125-12-408603:notes:9]
The preparation of financial statements in conformity with GAAP requires management to make estimates and judgments that affect the reported amounts of assets and liabilities and the disclosure of
   contingent assets and liabilities at the date of the financial statements and the reported amounts of revenues and expenses during the reporting period. On an ongoing basis, the Company evaluates these estimates, including those related to allowance
   for doubtful accounts, inventory valuation, warranty costs, stock-based compensation, income taxes, the valuation of equity instruments, and commitments and contingencies, among others. The Company bases estimates on historical experience and on
   various other assumptions that are believed to be reasonable under the circumstances. Actual results may differ from these estimates.

[0001193125-12-408603:notes:10]
Segments

[0001193125-12-408603:notes:11]
Management has determined that it operates as one reportable and operating segment as it only reports financial information on an aggregate and consolidated basis to its chief executive officer, who is
   the Company’s chief operating decision maker. See Note 13.

[0001193125-12-408603:notes:12]
Recognition of Revenues

[0001193125-12-408603:notes:13]
Revenues consist primarily of revenues from the sale of hardware and management tools, as well as the related implied post contract customer support (“PCS”). The Company recognizes revenues when
   persuasive evidence of an arrangement exists, delivery has occurred, the sales price is fixed or determinable and the collectability of the resulting receivable is reasonably assured. In cases where the Company lacks evidence that collectability of
   the resulting receivable is reasonably assured, it defers recognition of revenue until the receipt of cash. At June 30, 2012 and 2011 $805,000 and $1.7 million, respectively, of revenues were deferred.

[0001193125-12-408603:notes:14]
For the Company’s sales, evidence of the arrangement consists of an order from a customer. The Company considers delivery to have occurred once its
   products have been shipped and title and risk of loss have been transferred. For the Company’s sales, these criteria are met at the time the products are transferred to the customer. The Company’s arrangements with customers do not include
   provisions for cancellation, returns, inventory swaps or refunds that would significantly impact recognized revenues.

[0001193125-12-408603:notes:15]
The Company records
   amounts billed to distributors for shipping and handling costs as revenues. The Company classifies shipping and handling costs incurred by it as cost of revenues.

[0001193125-12-408603:notes:16]
Deposit payments received from distributors in advance of recognition of revenues are included in current liabilities on the Company’s balance sheet and are recognized as revenues when all the
   criteria for recognition of revenues are met.

[0001193125-12-408603:notes:17]
The Company’s multi-element arrangements generally include two deliverables. The first
   deliverable is the hardware and software essential to the functionality of the hardware device delivered at the time of sale. The second deliverable is the implied right to PCS included with the purchase of certain products. PCS is this right to
   receive, on a when and if available basis, future unspecified software upgrades and features relating to the product’s essential software as well as bug fixes, email and telephone support.

[0001193125-12-408603:notes:18]
The Company uses a hierarchy to determine the allocation of revenues to the deliverables. The hierarchy is as follows: (i) vendor-specific objective
   evidence of fair value (“VSOE”), (ii) third-party evidence of selling price (“TPE”), and (iii) best estimate of the selling price (“BESP”).

[0001193125-12-408603:notes:19]
| (i) | VSOE generally exists only when a company sells the deliverable separately and is the price actually charged by the company for that deliverable. Generally the Company does not sell the deliverables separately and, as such, does not have VSOE. |

[0001193125-12-408603:notes:20]
| (ii) | TPE can be substantiated by determining the price that other parties sell similar or substantially similar offerings. The Company does not believe that there is accessible TPE evidence for similar deliverables. |

[0001193125-12-408603:notes:21]
| (iii) | BESP reflects the Company’s best estimates of what the selling prices of elements would be if they were sold regularly on a stand-alone basis. The Company believes that BESP is the most appropriate methodology for determining the allocation of revenue among the multiple elements. |

[0001193125-12-408603:notes:22]
The
   Company has allocated revenues between these two deliverables using the relative selling price method which is based on the estimated selling price for all deliverables. Revenues allocated to the delivered hardware and the related essential software
   are recognized at the time of sale provided the other conditions for recognition of revenues have been met. Revenues allocated to the PCS are deferred and recognized on a straight-line basis over the estimated life of each of these devices, which
   currently is two years. At June 30, 2012 and 2011, $805,000 and $497,000 of revenue was deferred in this way. All cost of revenues, including estimated warranty costs, are recognized at the time of sale. Costs for research and development and
   sales and marketing are expensed as incurred. If the estimated life of the hardware product should change, the future rate of amortization of the revenues allocated to PCS would also change.

[0001193125-12-408603:notes:23]
The Company’s process for determining BESP for deliverables involves multiple factors that may vary depending upon the unique facts and circumstances related to each deliverable. For PCS, the Company
   believes its network operators and service providers would be reluctant to pay for such services separately. This view is primarily based on the fact that unspecified upgrade rights do not obligate the Company to provide upgrades at a particular time or at all, and do not specify to network operators and service
   providers which upgrades or features will be delivered. The Company believes that the relatively low prices of its products and its network operators’ and service providers’ price sensitivity would add to their reluctance to pay for PCS.
   Therefore, the Company has concluded that if it were to sell PCS on a standalone basis, the selling price would be relatively low.

[0001193125-12-408603:notes:24]
Key
   factors considered by the Company in developing the BESP for PCS include reviewing the activities of specific employees engaged in support and software development to determine the amount of time that is allocated to the development of the
   undelivered elements, determining the cost of this development effort, and then adding an appropriate level of gross profit to these costs.

[0001193125-12-408603:notes:25]
Cash and Cash Equivalents

[0001193125-12-408603:notes:26]
The Company considers investments purchased with a maturity period of three months or less at the date of purchase to be cash equivalents. At June 30, 2012 and 2011, the Company had cash and cash
   equivalents of $122.1 million and $76.4 million, respectively. Cash and cash equivalents are stated at cost which approximates fair value. The Company deposits cash and cash equivalents with financial institutions that management believes are of
   high credit quality. The Company’s cash and cash equivalents consist primarily of U.S. dollar denominated money market funds and cash deposited in demand accounts.

[0001193125-12-408603:notes:27]
Concentration of Risk

[0001193125-12-408603:notes:28]
Financial instruments that potentially subject the Company to concentrations of credit risk consist of cash and cash equivalents and accounts receivable. The Company primarily places its temporary cash
   investments with high credit quality financial institutions which invest predominantly in U.S. money market funds. Deposits of cash outside the United States totaled $102.8 million and $29.6 million at June 30, 2012 and 2011, respectively. The
   Company would incur significant tax liabilities if it were to repatriate its non-U.S. deposits.

[0001193125-12-408603:notes:29]
The Company derives its accounts receivable
   from revenues earned from customers located worldwide. The Company bases credit decisions primarily upon a customer’s past credit history. The Company’s standard credit terms are net 30 to 60 days.

[0001193125-12-408603:notes:30]
The Company subcontracts with other companies to manufacture most of its products. The Company relies on the ability of these contract manufacturers to
   produce the products sold to its distributors and original equipment manufacturers (“OEMs”). A significant portion of the Company’s products are manufactured by a few contract manufacturers. If the Company’s contract
   manufacturers were to lose production capabilities, the Company would experience delays in delivering products to its distributors and OEMs. The Company does not maintain long-term agreements with its contract manufacturers, which could lead to an
   inability of the Company to obtain its products in a timely fashion at prices consistent with those previously charged.

[0001193125-12-408603:notes:31]
Inventory

[0001193125-12-408603:notes:32]
Inventories consist primarily of raw materials that the Company consigns to its contract manufactures and, to a lesser extent, finished goods. Inventories are stated at the lower of cost or market value
   on a first-in, first-out basis. The Company reduces the value of its inventory for estimated obsolescence or lack of marketability by the difference between the cost of the affected inventory and the estimated market value and establishes a new cost
   basis.

[0001193125-12-408603:notes:33]
Deferred Cost of Revenues

[0001193125-12-408603:notes:34]
Deferred cost of revenues consist of the cost of product shipped to distributors for which the rights and obligations of ownership have passed to the distributor but revenues have not yet been recognized
   primarily because the collectability criterion for revenue recognition has not been fulfilled. The Company classifies those amounts as deferred cost of revenues. All deferred costs of revenues are stated at cost. The Company periodically assesses
   the recoverability of deferred cost of revenues and writes down the deferred cost of revenues balances to establish a new cost basis when recovery of deferred cost of revenues is not reasonably assured. The Company evaluates recoverability based on
   various factors including the length of time the product has been held at the distributor’s site and the financial viability of the distributor.

[0001193125-12-408603:notes:35]
Product Warranties

[0001193125-12-408603:notes:36]
The Company offers warranties on certain products, generally for a period of one year, and records a liability for the estimated future costs associated with potential warranty claims. The warranty costs
   are reflected in the Company’s consolidated statement of operations within cost of revenues. The warranties are typically in effect for 12 months from the distributor’s purchase date of the product. The Company’s estimate of future
   warranty costs is largely based on historical experience factors including product failure rates, material usage, and service delivery cost incurred in correcting product failures. In certain circumstances, the Company may have recourse from its
   contract manufacturers for replacement cost of defective products, which it also factors into its warranty liability assessment.

[0001193125-12-408603:notes:37]
Redeemable Convertible Preferred Stock

[0001193125-12-408603:notes:38]
On October 19, 2011, the Company’s outstanding Series A preferred stock converted to common stock immediately prior to the closing of the
   Company’s initial public offering and no additional accretion was recorded. Prior to the conversion, upon the sixth anniversary of the issuance of Series A preferred stock, the holders of Series A preferred stock could require the Company to
   redeem such preferred stock out of legally available funds at the greater of (i) the Liquidation Value of $2.95 per share plus all accrued and unpaid dividends or (ii) the market price of the common stock issuable upon conversion of each
   share of Series A preferred stock into common stock, plus all accrued and unpaid dividends. Since the maximum redemption amount was contingent on the fair value of the equity security at the redemption date, the Company calculated the accretion
   based on the fair value as of the balance sheet date prorated over the contractual life. The Company recorded $111.5 million, $37.7 million and $100,000 of accretion in fiscal 2012, 2011 and 2010, respectively. Due to the conversion immediately
   prior to the closing of the Company’s initial public offering, no additional accretion will be recorded in future periods.

[0001193125-12-408603:notes:39]
Allowance for Doubtful Accounts

[0001193125-12-408603:notes:40]
The Company records an allowance for doubtful accounts for estimated probable losses on uncollectible accounts receivable. In estimating the allowance, management considers, among other factors,
   (i) the aging of the accounts receivable, (ii) the Company’s historical write offs, (iii) the credit worthiness of each distributor based on payment history and (iv) general economic conditions. In cases where the Company is
   aware of circumstances that may impair a specific distributor’s ability to meet its obligations to the Company, the Company records a specific allowance against amounts due from the distributor, and thereby reduces the net recognized receivable
   to the amounts it reasonably believes will be collected.

[0001193125-12-408603:notes:41]
The allowance for doubtful accounts activity was as follows (in thousands):

[0001193125-12-408603:notes:42]
|  |  | Years Ended June 30, |  |
|  |  | 2012 |  |  | 2011 |  |  | 2010 |  |
| Beginning balance |  | $ | 596 |  |  | $ | 800 |  |  | $ | — |  |
| Charged to or released from expenses |  |  | 815 |  |  |  | (200 | ) |  |  | 800 |  |
| Bad debt write-offs |  |  | (145 | ) |  |  | (4 | ) |  |  | — |  |
| Ending Balance |  | $ | 1,266 |  |  | $ | 596 |  |  | $ | 800 |  |

[0001193125-12-408603:notes:43]
Fair Value of Financial Instruments

[0001193125-12-408603:notes:44]
The carrying value of the Company’s cash equivalents, accounts receivable, accounts payable, debt and other current liabilities approximate fair
   value due to their short maturities. See Note 3.

[0001193125-12-408603:notes:45]
Long Lived Assets

[0001193125-12-408603:notes:46]
The Company evaluates its long lived assets including property and equipment for impairment whenever events or changes in circumstances indicate that the
   carrying value of these assets may not be recoverable. An impairment loss is recognized when the net book value of such assets exceeds the estimated future undiscounted cash flows attributable to the assets or asset group. If impairment is
   indicated, the asset is written down to its estimated fair value. The Company did not recognize any impairment losses for fiscal 2012, 2011 and 2010.

[0001193125-12-408603:notes:47]
Property and Equipment

[0001193125-12-408603:notes:48]
Furniture, fixtures and equipment are recorded at cost. The Company computes depreciation or amortization using the straight line method over estimated useful lives, as follows:

[0001193125-12-408603:notes:49]
|  |  | Estimated Useful Life |
| Testing equipment |  | 3 to 5 years |
| Computer and other equipment |  | 3 to 5 years |
| Furniture and fixtures |  | 3 years |
| Leasehold improvements |  | shorter of lease term or useful life |

[0001193125-12-408603:notes:50]
Upon retirement or disposition, the asset cost and related accumulated depreciation are removed with any gain or loss recognized in the
   statement of operations. Expenditures for maintenance and repairs are charged to operations as incurred.

[0001193125-12-408603:notes:51]
Depreciation expense was $602,000,
   $213,000 and $144,000 for fiscal 2012, 2011 and 2010, respectively.

[0001193125-12-408603:notes:52]
Intangible Assets

[0001193125-12-408603:notes:53]
The Company’s intangible assets consist primarily of legal costs associated with application and registration of the Company’s patents and trademarks. The Company amortizes all
   acquisition-related intangible assets that are subject to amortization over the estimated useful life based on economic benefit, which ranges from 5 to 10 years.

[0001193125-12-408603:notes:54]
Leases

[0001193125-12-408603:notes:55]
The Company leases its facilities under cancelable and noncancelable operating leases. For leases that contain rent escalation or rent concessions provisions, the Company records the total rent expense
   during the lease term on a straight line basis over the term of the lease. The Company records the difference between the rent paid and the straight line rent as a deferred rent liability in the accompanying consolidated balance sheets.

[0001193125-12-408603:notes:56]
Income Taxes

[0001193125-12-408603:notes:57]
The Company accounts for income taxes in accordance with accounting guidance which requires recognition of deferred tax assets and liabilities for the expected future tax consequences of events that have
   been included in its financial statements or tax returns. Deferred tax assets and liabilities are determined based on the temporary difference between the financial statement carrying amounts of existing assets and liabilities and their respective
   tax bases. Deferred tax assets and liabilities are measured using enacted tax rates expected to apply to taxable income in the years in which those temporary differences are expected to be recovered or settled. The Company establishes valuation
   allowances when necessary to reduce deferred tax assets to the amount it expects to realize. The assessment of whether or not a valuation allowance is required often requires significant judgment including current operating results, the forecast of
   future taxable income and ongoing prudent and feasible tax planning initiatives. In addition, the Company’s calculation of its tax liabilities involves dealing with uncertainties in the application of complex tax regulations. The Company may be
   subject to income tax audits in all of the jurisdictions in which it operates and, as a result, must also assess exposures to any potential issues arising from current or future audits of current and prior years’ tax returns. Accordingly, the
   Company must assess such potential exposures and, where necessary, provide a reserve to cover any expected loss. To the extent that the Company establishes a reserve, its provision for income taxes would be increased. If the Company ultimately
   determines that payment of these amounts is unnecessary, it reverses the liability and recognizes a tax benefit during the period in which it determines that the liability is no longer necessary. The Company records an additional charge in its
   provision for taxes in the period in which it determines that tax liability is greater than its original estimate.

[0001193125-12-408603:notes:58]
Stock-based Compensation

[0001193125-12-408603:notes:59]
The Company records stock-based awards at fair value as of the grant date and recognizes expense ratably on a straight-line basis over the requisite service period, which is generally the vesting term of
   the awards. The Company estimates the fair value of stock option awards on the grant date using the Black-Scholes option pricing model. Restricted stock units (“RSUs”) are valued based on the fair value of the Company’s common stock
   on the date of grant. The Company adopted the above guidance using the modified prospective transition method. Under this transition method, the new fair value recognition provisions are applied to option grants on and after July 1, 2005. The
   Company expenses the fair value of all stock-based awards granted or modified after July 1, 2005 on a straight line basis.

[0001193125-12-408603:notes:60]
The
   Black-Scholes option pricing model used to determine the fair value of the Company’s stock option awards requires a number of estimates and assumptions. In valuing share-based awards under the fair value accounting method, significant judgment
   is required in determining the expected volatility of the Company’s common stock and the expected term individuals will hold their share-based awards prior to exercising. The expected volatility of the Company’s common stock is based on
   the volatility of a group of comparable companies, as the Company does not have sufficient historical data with regards to the volatility of its stock. The expected term of options granted represents the period of time that the Company expects the
   options granted to be outstanding. The Company calculates the expected term as the average of the option vesting and contractual terms. In the future, as the Company gains sufficient historical data for volatility in its common stock and the actual
   term for which its options are held, the expected volatility and expected term may change, which could substantially change the grant date fair value of future awards of stock options and ultimately the expense it records. In addition, the
   estimation of stock awards that will ultimately vest requires judgment and to the extent actual results differ from the Company’s estimates, these amounts will be recorded as an adjustment in the period estimates are revised.

[0001193125-12-408603:notes:61]
For stock option awards granted to nonemployees and nonemployee directors, the fair value of the stock option awards is estimated using the Black-Scholes
   option pricing model. This model utilizes the estimated fair value of the Company’s underlying common stock at each measurement date, the contractual term of the option, the expected volatility of the price of the Company’s common stock,
   risk free interest rates and expected dividend yields of the Company’s common stock.

[0001193125-12-408603:notes:62]
Commitments and Contingencies

[0001193125-12-408603:notes:63]
The Company periodically evaluates all pending or threatened contingencies and any commitments, if any, that are reasonably likely to have a material
   adverse effect on its results of operations, financial position or cash flows. The Company assesses the probability of an adverse outcome and determines if it is remote, reasonably possible or probable. If information available prior to the issuance
   of the Company’s financial statements indicates that it is probable that an asset had been impaired or a liability had been incurred at the date of the Company’s financial statements, and the amount of the loss, or the range of probable
   loss can be reasonably estimated, then such loss is accrued and charged to operations. If no accrual is made for a loss contingency because one or both of the conditions pursuant to the accounting guidance are not met, but the probability of an
   adverse outcome is at least reasonably possible, the Company will disclose the nature of the contingency and provide an estimate of the possible loss or range of loss, or state that such an estimate cannot be made.

[0001193125-12-408603:notes:64]
Foreign Currency Translation

[0001193125-12-408603:notes:65]
The functional currency of the Company and its subsidiaries is the U.S. dollar. For foreign operations, local currency denominated assets and liabilities
   are remeasured at the period end exchange rates, and revenues, costs and expenses are remeasured at the average exchange rates during the fiscal year. Foreign exchange gains and losses have been immaterial to the Company’s results of operations
   to date.

[0001193125-12-408603:notes:66]
Deferred Offering Costs

[0001193125-12-408603:notes:67]
Deferred offering costs, consisting of legal, accounting and other fees and costs relating to the Company’s initial public offering were capitalized. Deferred offering costs of $3.1 million were
   offset against initial public offering proceeds upon the closing of the offering in October 2011. There were $2.1 million of deferred offering costs capitalized as of June 30, 2011.

[0001193125-12-408603:notes:68]
Research and Development Costs and Capitalized Software Development Costs

[0001193125-12-408603:notes:69]
Research and development expenses consist primarily of salary and benefit expenses, including stock-based compensation, for employees
   and contractors engaged in research, design and development activities, as well as costs for prototypes, facilities and travel costs.

[0001193125-12-408603:notes:70]
Software development costs, including costs incurred to purchase third party software, begin to be capitalized when the Company has determined that
   certain factors are present, including among others, that technology exists to achieve the performance requirements. The accumulation of software costs to be capitalized ceases when the software is substantially developed and is ready for its
   intended use. Capitalized costs are amortized on a straight line basis over the estimated useful life of the software once it is available for use. To date, the Company has not capitalized research and development costs associated with software
   development as products and enhancements have reached technological feasibility and have been released to customers at substantially the same time.

[0001193125-12-408603:notes:71]
Earnings Per Share

[0001193125-12-408603:notes:72]
The Company applies the two-class method for calculating and presenting earnings per share (“EPS”). Under the two-class method, net income is allocated between shares of common stock and other
   participating securities based on their participating rights. Participating securities are defined as securities that participate in dividends with common stock according to a pre-determined formula or a contractual obligation to share in the income
   of the entity. Basic EPS is computed by dividing net income available to common stockholders by the weighted average number of shares of common stock outstanding during the period. Diluted EPS is computed by dividing the amount of net income
   available to common stockholders outstanding plus income allocable to participating securities, to the extent they are dilutive, by the weighted average number of shares of common stock and potential dilutive shares outstanding during the period if
   the effect is dilutive. The Company’s potentially dilutive common shares include outstanding stock options, restricted stock units and preferred stock.

[0001193125-12-408603:notes:73]
Recent Accounting Pronouncements

[0001193125-12-408603:notes:74]
In May 2011 the FASB further amended its guidance related to fair value measurements in order to achieve common fair value measurements between U.S. GAAP
   and International Financial Reporting Standards. The amendments in the updated guidance explain how to measure fair value. They do not require additional fair value measurements and are not intended to establish valuation standards or affect
   valuation practices outside of financial reporting. The amendments change the wording used to describe many of the requirements in U.S. GAAP for measuring fair value and for disclosing information about fair value measurements. For many of the
   requirements, the updated guidance should not result in a change in the application of previous fair value measurement guidance. The updated guidance is effective during interim and annual periods beginning after December 15, 2011. The adoption
   of the amended guidance on January 1, 2012 did not have an impact on the Company’s consolidated financial statements.

[0001193125-12-408603:notes:75]
In June 2011,
   the FASB updated its guidance related to the presentation of comprehensive income. Under the updated guidance, an entity has the option to present the total of comprehensive income, the components of net income, and the components of other
   comprehensive income either in a single continuous statement of comprehensive income or in two separate but consecutive statements. In both choices, an entity is required to present each component of net income along with total net income, each
   component of other comprehensive income along with a total for other comprehensive income, and a total amount for comprehensive income. The updated guidance eliminates the option to present the components of other comprehensive
   income as part of the statement of changes in stockholders’ equity. The amendments in the updated guidance do not change the items that must be reported in other comprehensive income or when an item of other comprehensive income must be
   reclassified to net income. In December 2011, the FASB further amended its guidance to defer changes related to the presentation of reclassification adjustments indefinitely as a result of concerns raised by stakeholders that the new presentation
   requirements would be difficult for preparers and add unnecessary complexity to financial statements. The updated guidance, other than the portion related to the presentation of reclassification adjustments, will be effective for fiscal years, and
   interim periods within those fiscal years, beginning after December 15, 2011, with early adoption permitted. The updated guidance must be applied retrospectively. The Company does not expect the adoption of the guidance on July 1, 2012 to
   have an impact on its consolidated financial statements.


## us-gaap:FairValueDisclosuresTextBlock

[0001193125-12-408603:notes:76]
NOTE 3—FAIR VALUE OF FINANCIAL INSTRUMENTS

[0001193125-12-408603:notes:77]
Pursuant to the accounting guidance for fair value measurements and its subsequent updates, fair value is defined as the price that
   would be received from selling an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date. As such, fair value is a market-based measurement that should be determined based on assumptions
   that market participants would use in pricing an asset or liability. The accounting guidance establishes a three-tier fair value hierarchy that requires the Company to use observable market data, when available, and to minimize the use of
   unobservable inputs when determining fair value. The fair value hierarchy prioritizes the inputs into three levels that may be used in measuring fair value as follows:

[0001193125-12-408603:notes:78]
Level 1—observable inputs which include quoted prices in active markets for identical assets or liabilities.

[0001193125-12-408603:notes:79]
Level 2—inputs which include observable inputs other than Level 1, such as quoted prices for similar assets or liabilities, quoted prices for identical or similar assets or liabilities in
   markets that are not active, or other inputs that are observable or can be corroborated by observable market data for substantially the full term of the asset or liability.

[0001193125-12-408603:notes:80]
Level 3—inputs which include unobservable inputs that are supported by little or no market activity and that are significant to the fair value of the underlying asset or liability. Level 3
   assets and liabilities include those whose fair value measurements are determined using pricing models, discounted cash flow methodologies or similar valuation techniques, as well as significant management judgment or estimation.

[0001193125-12-408603:notes:81]
The Company’s financial assets at June 30, 2012 and 2011 included money market funds which were valued based on quoted prices in active markets
   for substantially similar assets and, therefore, were Level 1 instruments. Additionally, at June 30, 2012 the Company had debt associated with its Loan and Security Agreement with East West Bank (See Note 8). The fair value of the Company’s
   debt was estimated based on the current rates offered to the Company for debt with the same remaining maturities.

[0001193125-12-408603:notes:82]
As of June 30, 2012 and 2011, the
   fair value hierarchy for the Company’s financial assets and financial liabilities was as follows (in thousands):

[0001193125-12-408603:notes:83]
|  |  | June 30, 2012 |  |  | June 30, 2011 |  |
|  |  | Fair Value |  |  | Level 1 |  |  | Level 2 |  |  | Level 3 |  |  | Fair Value |  |  | Level 1 |  |  | Level 2 |  |  | Level 3 |  |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 108,228 |  |  | $ | 108,228 |  |  | $ | — |  |  | $ | — |  |  | $ | 43,572 |  |  | $ | 43,572 |  |  | $ | — |  |  | $ | — |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Debt |  | $ | 29,591 |  |  | $ | — |  |  | $ | 29,591 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |


## us-gaap:EarningsPerShareTextBlock

[0001193125-12-408603:notes:84]
NOTE 4—EARNINGS PER SHARE

[0001193125-12-408603:notes:85]
The following table sets forth the computation of basic and diluted earnings per share for the periods indicated (in thousands, except
   per share data):

[0001193125-12-408603:notes:86]
|  |  | Years Ended June 30, |  |
|  |  | 2012 |  |  | 2011 |  |  | 2010 |  |
| Numerator: |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income (loss) attributable to common stockholders—basic |  | $ | (9,842 | ) |  | $ | 4,875 |  |  | $ | (6,892 | ) |
| Net income (loss) attributable to common stockholders—diluted |  | $ | (9,842 | ) |  | $ | 4,978 |  |  | $ | (6,892 | ) |
| Denominator: |  |  |  |  |  |  |  |  |  |  |  |  |
| Weighted-average common shares outstanding used in basic EPS calculation |  |  | 83,460 |  |  |  | 63,092 |  |  |  | 88,972 |  |
| Add—dilutive potential common shares: |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock options |  |  | — |  |  |  | 3,680 |  |  |  | — |  |
| Restricted stock units |  |  | — |  |  |  | 135 |  |  |  | — |  |
| Weighted-average shares used to compute diluted EPS |  |  | 83,460 |  |  |  | 66,907 |  |  |  | 88,972 |  |
| Net income (loss) per share of common stock: |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | (0.12 | ) |  | $ | 0.08 |  |  | $ | (0.08 | ) |
| Diluted |  | $ | (0.12 | ) |  | $ | 0.07 |  |  | $ | (0.08 | ) |

[0001193125-12-408603:notes:87]
The following table summarizes the total potential shares of common stock that were excluded from the diluted per share calculation,
   because to include them would have been anti-dilutive for the period (in thousands):

[0001193125-12-408603:notes:88]
|  |  | Years Ended June 30, |  |
|  |  | 2012 |  |  | 2011 |  |  | 2010 |  |
| Stock options |  |  | 3,348 |  |  |  | 360 |  |  |  | 5,795 |  |
| Restricted stock units |  |  | 454 |  |  |  | 100 |  |  |  | 500 |  |
| Convertible preferred stock |  |  | — |  |  |  | 36,035 |  |  |  | 36,035 |  |
|  |  |  | 3,802 |  |  |  | 36,495 |  |  |  | 42,330 |  |


## us-gaap:CashAndCashEquivalentsDisclosureTextBlock

[0001193125-12-408603:notes:89]
NOTE 5—CASH AND CASH EQUIVALENTS

[0001193125-12-408603:notes:90]
Cash and cash equivalents consisted of the following (in thousands):

[0001193125-12-408603:notes:91]
|  |  | June 30, |  |
|  |  | 2012 |  |  | 2011 |  |
| Cash |  | $ | 13,832 |  |  | $ | 32,789 |  |
| Money market funds |  |  | 108,228 |  |  |  | 43,572 |  |
|  |  | $ | 122,060 |  |  | $ | 76,361 |  |


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001193125-12-408603:notes:92]
NOTE 6—BALANCE SHEET COMPONENTS

[0001193125-12-408603:notes:93]
Inventories

[0001193125-12-408603:notes:94]
Inventories consisted of the following (in thousands):

[0001193125-12-408603:notes:95]
|  |  | June 30, |  |
|  |  | 2012 |  |  | 2011 |  |
| Raw materials |  | $ | 4,668 |  |  | $ | 4,305 |  |
| Finished goods |  |  | 3,066 |  |  |  | 1,358 |  |
|  |  | $ | 7,734 |  |  | $ | 5,663 |  |

[0001193125-12-408603:notes:96]
Prepaid Expenses and Other Current Assets

[0001193125-12-408603:notes:97]
Prepaid expenses and other current assets consisted of the following (in thousands):

[0001193125-12-408603:notes:98]
|  |  | June 30, |  |
|  |  | 2012 |  |  | 2011 |  |
| Vendor deposits |  | $ | 129 |  |  | $ | 5,312 |  |
| Other current assets |  |  | 1,448 |  |  |  | 74 |  |
|  |  | $ | 1,577 |  |  | $ | 5,386 |  |

[0001193125-12-408603:notes:99]
Property and Equipment, Net

[0001193125-12-408603:notes:100]
Property and equipment, net consisted of the following (in thousands):

[0001193125-12-408603:notes:101]
|  |  | June 30, |  |
|  |  | 2012 |  |  | 2011 |  |
| Testing equipment |  | $ | 2,293 |  |  | $ | 1,086 |  |
| Computer and other equipment |  |  | 578 |  |  |  | 182 |  |
| Tooling equipment |  |  | 532 |  |  |  | — |  |
| Furniture and fixtures |  |  | 595 |  |  |  | 18 |  |
| Leasehold improvements |  |  | 1,424 |  |  |  | 112 |  |
| Software |  |  | 77 |  |  |  | 57 |  |
|  |  |  | 5,499 |  |  |  | 1,455 |  |
| Less: Accumulated depreciation and amortization |  |  | (1,028 | ) |  |  | (433 | ) |
|  |  | $ | 4,471 |  |  | $ | 1,022 |  |

[0001193125-12-408603:notes:102]
Other Long-term Assets

[0001193125-12-408603:notes:103]
Other long-term assets consisted of the following (in thousands):

[0001193125-12-408603:notes:104]
|  |  | June 30, |  |
|  |  | 2012 |  |  | 2011 |  |
| Deferred offering costs |  | $ | — |  |  | $ | 2,141 |  |
| Intangible assets, net |  |  | 748 |  |  |  | — |  |
| Other long-term assets |  |  | 388 |  |  |  | 89 |  |
|  |  | $ | 1,136 |  |  | $ | 2,230 |  |

[0001193125-12-408603:notes:105]
Other Current Liabilities

[0001193125-12-408603:notes:106]
Accrued liabilities consisted of the following (in thousands):

[0001193125-12-408603:notes:107]
|  |  | June 30, |  |
|  |  | 2012 |  |  | 2011 |  |
| Accrued compensation and benefits |  | $ | 2,657 |  |  | $ | 2,280 |  |
| Accrued accounts payable |  |  | 6,636 |  |  |  | 7,414 |  |
| Accrual for an export compliance matter |  |  | 1,625 |  |  |  | 1,625 |  |
| Warranty accrual |  |  | 1,381 |  |  |  | 806 |  |
| Other accruals |  |  | 4,732 |  |  |  | 3,081 |  |
|  |  | $ | 17,031 |  |  | $ | 15,206 |  |


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001193125-12-408603:notes:108]
NOTE 7—ACCRUED WARRANTY

[0001193125-12-408603:notes:109]
The Company offers warranties on certain products, generally for a period of one year, and records a liability for the estimated future
   costs associated with potential warranty claims. The warranty costs are reflected in the Company’s consolidated statement of operations within cost of revenues. The warranties are typically in effect for 12 months from the distributor’s
   purchase date of the product. The Company’s estimate of future warranty costs is largely based on historical experience factors including product failure rates, material usage, and service delivery cost incurred in correcting product failures.
   In certain circumstances, the Company may have recourse from its contract manufacturers for replacement cost of defective products, which it also factors into its warranty liability assessment.

[0001193125-12-408603:notes:110]
Warranty obligations, included in other current liabilities, were as follows (in thousands):

[0001193125-12-408603:notes:111]
| Balance at June 30, 2009 |  | $ | 126 |  |
| Accruals for warranties issued during the period |  |  | 827 |  |
| Settlements made during the period |  |  | (256 | ) |
| Balance at June 30, 2010 |  |  | 697 |  |
| Accruals for warranties issued during the period |  |  | 847 |  |
| Settlements made during the period |  |  | (738 | ) |
| Balance at June 30, 2011 |  |  | 806 |  |
| Accruals for warranties issued during the period |  |  | 1,895 |  |
| Settlements made during the period |  |  | (1,320 | ) |
| Balance at June 30, 2012 |  | $ | 1,381 |  |


## us-gaap:DebtDisclosureTextBlock

[0001193125-12-408603:notes:112]
NOTE 8—DEBT

[0001193125-12-408603:notes:113]
In July 2011, the Company repurchased an aggregate of 12,041,700 shares of the Company’s Series A convertible preferred stock from
   entities affiliated with Summit Partners, L.P., one of the Company’s major stockholders, at a price of $8.97 per share for an aggregate consideration of $108.0 million. Of the aggregate purchase price, $40.0 million was paid in cash at the time
   of closing and the balance of the shares were paid for through the issuance of convertible subordinated promissory notes in the aggregate principal amount of $68.0 million. On September 15, 2011, $34.0 million was paid against the notes
   reducing the aggregate principal amount outstanding to $34.0 million. The remainder of the notes were retired in October 2011 with the proceeds of the Company’s initial public offering and existing cash balances. The interest rate on the
   notes started at 5% per annum and increased by two percentage points every three months until it would have reached 9% in January 2012. The notes were prepayable without penalty prior to April 21, 2012, and were required to be paid in the
   event of the Company’s initial public offering or third party financing prior to April 21, 2012. The notes matured on July 21, 2021. The unpaid principal on the notes was convertible into shares of Series A preferred stock at $8.97
   per share at any point after July 21, 2012. The difference between the repurchase price and the carrying value of the repurchased preferred stock on June 30, 2011 was $59.0 million. The difference was debited to available retained earnings
   with the remaining amount debited to additional paid-in capital and reduced the net income attributable to common stock shareholders resulting in a reduction of basic and diluted net income per share.

[0001193125-12-408603:notes:114]
On September 15, 2011, the Company entered into a Loan and Security Agreement with East West Bank, (the “EWB Loan Agreement”). The credit
   facilities available under the EWB Loan Agreement consist of a $35.0 million term loan facility and a $5.0 million revolving line of credit facility. The term loan matures on September 15, 2016 with principal and interest to be repaid in
   60 monthly installments. The Company used $34.0 million of the term loan to repay a portion of the outstanding convertible subordinated promissory notes held by entities affiliated with Summit Partners, L.P. The $5.0 million revolving line of
   credit may be drawn at any time prior to September 15, 2013. The amounts outstanding under both the term loan and the revolving line of credit facility may be voluntarily prepaid at any time without premium or penalty, subject to certain
   conditions. Interest will accrue on the outstanding principal amount of the term loan at a rate per annum equal to an adjusted LIBOR rate (based on one, two or three month interest periods) plus a spread of either 2.50% or 3.00%, which spread shall
   be determined based on the debt service ratio for the preceding four fiscal quarter period. Interest will accrue on the drawn portion of the revolving credit facility at the prime rate plus a spread of 0.25%, provided that such rate shall not be
   less than the one-month adjusted LIBOR rate plus a spread of 1.00%, and will be paid monthly. The Company is required to pay a commitment fee of 0.15% per annum on the undrawn portion of the revolving credit facility on a quarterly basis. The
   EWB Loan Agreement includes customary covenants, including financial reporting requirements and compliance with a debt service coverage ratio and a total leverage ratio, and customary events of default. The Company’s obligations under the EWB
   Loan Agreement are secured by a first priority security position on substantially all of the Company’s current and future assets, subject to certain exceptions (including a negative pledge on the Company’s intellectual property) and
   permitted liens. During fiscal 2012, the Company made aggregate payments of $5.2 million against the loan balance. As of June 30, 2012, the Company has classified $7.0 million and $22.6 million in short-term and long-term debt, respectively, on
   its consolidated balance sheet related to the EWB Loan Agreement.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001193125-12-408603:notes:115]
NOTE 9—COMMITMENTS AND CONTINGENCIES

[0001193125-12-408603:notes:116]
Operating Leases

[0001193125-12-408603:notes:117]
Certain facilities and equipment are leased under noncancelable operating leases. The Company generally pays taxes, insurance and maintenance costs on
   leased facilities and equipment. The Company leases office space in San Jose, California and other locations under various non-cancelable operating leases that expire at various dates through 2017.

[0001193125-12-408603:notes:118]
In July 2011, the Company entered into
   an agreement to lease additional office space for its research and development offices in Taiwan. The lease term is from July 14, 2011 through July 15, 2016. The premises consist of approximately 10,000 rentable square feet of space. The
   lease has been categorized as an operating lease, and the total estimated rent expense to be recognized is $1.6 million.

[0001193125-12-408603:notes:119]
In December 2011,
   the Company entered into an agreement to lease approximately 64,512 square feet of office and research and development space located in San Jose, California, which will be used as the Company’s corporate headquarters. The lease term is from
   April 1, 2012, though June 30, 2017. The lease has been categorized as an operating lease, and the total estimated rent expense to be recognized is $4.9 million.

[0001193125-12-408603:notes:120]
At June 30, 2012, future minimum annual payments under operating leases are as follows (in thousands): (in thousands):

[0001193125-12-408603:notes:121]
|  |  | 2013 |  |  | 2014 |  |  | 2015 |  |  | 2016 |  |  | 2017 |  |  | Thereafter |  |  | Total |  |
| Operating leases |  | $ | 1,240 |  |  | $ | 1,373 |  |  | $ | 1,386 |  |  | $ | 1,418 |  |  | $ | 1,122 |  |  | $ | — |  |  | $ | 6,539 |  |

[0001193125-12-408603:notes:122]
Rent expense under operating leases was $1.6 million, $751,000 and $392,000 for fiscal 2012, fiscal 2011 and fiscal 2010, respectively.

[0001193125-12-408603:notes:123]
Purchase Commitments

[0001193125-12-408603:notes:124]
The Company subcontracts with other companies to manufacture its products. During the normal course of business, the Company’s contract manufacturers
   procure components based upon orders placed by the Company. If the Company cancels all or part of the orders, it may still be liable to the contract manufacturers for the cost of the components purchased by them to manufacture the Company’s
   products. The Company periodically reviews the potential liability and to date no accruals have been recorded. The Company’s consolidated financial position and results of operations could be negatively impacted if it were required to
   compensate the contract manufacturers for any liabilities incurred.

[0001193125-12-408603:notes:125]
Indemnification Obligations

[0001193125-12-408603:notes:126]
The Company enters into standard indemnification agreements with many of its business partners in the ordinary course of business. These agreements
   include provisions for indemnifying the business partner against any claim brought by a third party to the extent any such claim alleges that a Ubiquiti product infringes a patent, copyright or trademark, or violates any other proprietary rights of
   that third party. The maximum potential amount of future payments the Company could be required to make under these indemnification agreements is not estimable and the Company has not incurred any material costs to defend lawsuits or settle claims
   related to these indemnification agreements to date.

[0001193125-12-408603:notes:127]
Legal Matters

[0001193125-12-408603:notes:128]
The Company may be involved, from time to time, in a variety of claims, lawsuits, investigations, and proceedings relating to contractual disputes, intellectual property rights, employment matters,
   regulatory compliance matters and other litigation matters relating to various claims that arise in the normal course of business. The Company determines whether an estimated loss from a contingency should be accrued by assessing whether a loss is
   deemed probable and can be reasonably estimated. The Company assesses its potential liability by analyzing specific litigation and regulatory matters using available information. The Company develops its views on estimated losses in consultation
   with inside and outside counsel, which involves a subjective analysis of potential results and outcomes, assuming various combinations of appropriate litigation and settlement strategies. Because of the uncertainties related to both the amount and
   ranges of possible loss from pending litigation matters, the Company is unable to predict with certainty the precise liability that could finally result from a range of possible unfavorable outcomes. Taking all of the above factors into account, the
   Company records an amount where it is probable that the Company will incur a loss and where that loss can be reasonably estimated. However, the Company’s estimates may be incorrect and the Company could ultimately incur more or less than the amounts initially recorded. Litigation can be costly, diverting
   management’s attention and could, upon resolution, have a material adverse effect on the Company’s business, results of operations, financial condition, and cash flows.

[0001193125-12-408603:notes:129]
Export Compliance Matters

[0001193125-12-408603:notes:130]
In January 2011, the U.S. Commerce Department, Bureau of
   Industry and Security’s (“BIS”) Office of Export Enforcement (“OEE”) contacted the Company to request that the Company provide information related to its relationship with a logistics company in the UAE and with a company in
   Iran, as well as information on the export classification of its products. As a result of this inquiry the Company, assisted by outside counsel, conducted a review of the Company’s export transactions from 2008 through March 2011 to not only
   gather information responsive to the OEE’s request but also to review the Company’s overall compliance with export control and sanctions laws. It was in the course of this review that the Company identified the Iranian sales of two of its
   distributors.

[0001193125-12-408603:notes:131]
In May 2011, the Company filed a self-disclosure with the BIS and Security’s Office of Export Enforcement OEE and in June
   2011, filed one with U.S. Department of the Treasury’s Office of Foreign Asset Control (“OFAC”) regarding the compliance issues noted above. The disclosures address the above described findings and the remedial actions the Company had
   taken to date. However, the findings also indicate that both distributors continued to sell, directly or indirectly, the Company’s products into Iran during the period from February 2010 through March 2011 and that the Company received various
   communications from them indicating that they were continuing to do so. Since January 2011, the Company has cooperated with OEE and, prior to its disclosure filing, the Company informally shared with the OEE the substance of its findings with
   respect to both distributors. From May 2011 to August 2011, the Company provided additional information regarding its review and its findings to OEE to facilitate its investigation and OEE advised the Company in August 2011 that it had completed its
   investigation of the Company. In August 2011, the Company received a warning letter from OEE stating that OEE had not referred the findings of the Company’s review for criminal or administrative prosecution and closed the investigation of the
   Company without penalty.

[0001193125-12-408603:notes:132]
OFAC is still reviewing the Company’s voluntary disclosure. In the Company’s submission, the Company
   provided OFAC with an explanation of the activities that led to the sales of its products in Iran and the failure to comply with the Export Administration Regulations (the “EAR”) and OFAC sanctions. Although the Company’s OFAC and OEE
   voluntary disclosures covered similar sets of facts, which led the OEE to resolve the case with the issuance of a warning letter, OFAC may conclude that the Company’s actions resulted in violations of U.S. export control and economic sanctions
   laws and warrant the imposition of penalties that could include fines, termination of the Company’s ability to export its products, and/or referral for criminal prosecution. Any such fines may be material to the Company’s financial results
   in the period in which they are imposed. The penalties may be imposed against the Company and/or its management. The maximum civil monetary penalty for the violations is up to $250,000 or twice the value of the transaction, whichever is greater, per
   violation. The Company cannot predict when OFAC will complete its review or decide upon the imposition of possible penalties.

[0001193125-12-408603:notes:133]
Based on the
   facts known to the Company to date, the Company recorded an expense of $1.6 million for this export compliance matter in fiscal 2010, which represents management’s estimated exposure for fines in accordance with applicable accounting
   literature. This amount was calculated from information discovered through the Company’s internal review and this loss is deemed to be probable and reasonably estimable. However, the Company also believes that it is reasonably possible that the
   loss may be higher, but the Company cannot reasonably estimate the range of any further potential losses. Specific information has come to management’s attention based on which, management cannot estimate any further range of possible losses.
   Should additional facts be discovered in the future and/or should actual fines or other penalties substantially differ from the Company’s estimates, its business, financial condition, cash flows and results of operations would be materially
   negatively impacted.


## us-gaap:PreferredStockTextBlock

[0001193125-12-408603:notes:134]
NOTE 10—PREFERRED STOCK

[0001193125-12-408603:notes:135]
Preferred Stock

[0001193125-12-408603:notes:136]
On March 2, 2010, the Company amended its certificate of incorporation to authorize the issuance of 36,034,630 shares of Series A convertible
   preferred stock. On March 2, 2010, the Company also entered into a Stock Purchase Agreement and issued 33,898,990 Series A shares and warrants to purchase an additional 2,135,640 Series A shares to a third party investor at $2.95 per share. The
   total proceeds of $99.5 million, net of $500,000 of issuance costs, $1.3 million out of the total proceeds was allocated to the Series A warrants based on the fair value on the issuance date, and the remaining amount of $98.2 million was allocated
   to Series A Preferred Stock using the residual method. The proceeds from the issuance of the Series A shares were used to repurchase common stock and fully vested stock options from employees and others.

[0001193125-12-408603:notes:137]
The fair value of the warrant to purchase the additional 2,135,640 Series A shares was estimated to be $1.3 million at the date of issuance based on
   the Black-Scholes option pricing model using a risk-free interest rate of 0.14%, volatility of approximately 53%, the contractual life of 0.3 years and 4% dividend rate. In accordance with applicable accounting guidance, the warrant liability was
   remeasured at fair value at each balance sheet date prior to exercise. The $207,000 decrease in fair value of the warrant liability as measured at March 31, 2010 compared to the initial fair value at issuance was recorded as other income
   (expense), net in the Company’s statement of operations in the third quarter of fiscal 2010. On June 29, 2010, holders of the warrants exercised their option to purchase 2,135,640 shares of Series A convertible preferred stock at $2.95 per
   share for total proceeds of $6.3 million, resulting in the reclassification of the warrant liability balance to Series A preferred stock on the Company’s consolidated balance sheet.

[0001193125-12-408603:notes:138]
In July 2011, the Company repurchased an aggregate of 12,041,700 shares of the Company’s Series A convertible preferred stock from entities affiliated with Summit Partners, L.P., one of the
   Company’s major stockholders, at a price of $8.97 per share for an aggregate consideration of $108.0 million. Of the aggregate purchase price, $40.0 million was paid in cash at the time of closing and the balance of the shares were paid for
   through the issuance of convertible subordinated promissory notes in the aggregate principal amount of $68.0 million. The $68.0 million was paid down primarily using proceeds from the term loan the Company executed with East West Bank on
   September 15, 2011 and funds raised upon the completion of the Company’s initial public offering on October 19, 2011.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001193125-12-408603:notes:139]
NOTE 11—STOCK BASED COMPENSATION

[0001193125-12-408603:notes:140]
Stock-Based Compensation Plans

[0001193125-12-408603:notes:141]
2010 Equity Incentive Plan

[0001193125-12-408603:notes:142]
In March 2010, the Company’s board of directors and
   stockholders approved the 2010 Equity Incentive Plan (the “2010 Plan”). The 2010 Plan replaced the 2005 Equity Incentive Plan (the “2005 Plan”), and no further awards will be granted pursuant to the 2005 Plan. Under the terms of
   the 2010 Plan, nonstatutory stock options, stock appreciation rights, restricted stock, and restricted stock units (“RSUs”) may be granted to employees or non-employee service providers. Incentive stock options may be granted only to
   employees.

[0001193125-12-408603:notes:143]
The maximum aggregate number of shares that may be awarded under the 2010 Plan as of June 30, 2012 was 8,000,000 shares, plus
   any shares subject to stock options or similar awards granted under the 2005 Plan that expire or otherwise terminate without having been exercised in full and shares issued pursuant to awards granted under the 2005 Plan that are forfeited to (but
   not repurchased by) the Company. As of June 30, 2012, the Company had 1,649,294 authorized shares available for issuance under the 2010 Plan.

[0001193125-12-408603:notes:144]
The 2010 Plan is administered by the board of directors or a committee of the Company’s board of directors. Subject to the terms and conditions of the 2010 Plan, the administrator has the authority
   to select the persons to whom awards are to be made, to determine the number of shares to be subject to awards and the terms and conditions of awards, and to make all other determinations and to take all other actions necessary or advisable for
   the administration of the 2010 Plan. The administrator is also authorized to adopt, amend or rescind rules relating to administration of the 2010 Plan. Options and RSUs generally vest over a four
   year period from the date of grant and generally expire five to ten years from the date of grant. The terms of the 2010 Plan provide that an option price shall not be less than 100% of fair market value on the date of grant.

[0001193125-12-408603:notes:145]
2005 Equity Incentive Plan

[0001193125-12-408603:notes:146]
With the
   adoption of the 2010 Plan, no additional awards may be granted under the 2005 Plan. In February 2005, the Company’s board of directors and the stockholders approved the 2005 Plan, which was amended and restated in March 2006. The 2005 Plan
   provided for the issuance of stock options, restricted stock and stock bonuses to employees, consultants, advisors, directors and officers of the Company. The 2005 Plan was administered by the Company’s board of directors, who determined the
   terms and conditions for each grant. The terms of the options granted under the 2005 Plan were determined at the time of grant. The Company made use of different vesting schedules through fiscal 2009, but subsequent new grants generally vested as to
   25% on the first anniversary of the date of grant and monthly thereafter over the next three years and generally have a term of 10 years from the date of grant. The option prices were determined by the Company’s board of directors.

[0001193125-12-408603:notes:147]
Employee Stock-based Compensation

[0001193125-12-408603:notes:148]
The following table shows total stock-based compensation expense included in the Consolidated Statements of Operations for fiscal 2012, 2011 and 2010 (in
   thousands):

[0001193125-12-408603:notes:149]
|  |  | Years Ended June 30, |  |
|  |  | 2012 |  |  | 2011 |  |  | 2010 |  |
| Cost of revenues |  | $ | 117 |  |  | $ | 30 |  |  | $ | 124 |  |
| Research and development |  |  | 542 |  |  |  | 285 |  |  |  | 26,221 |  |
| Sales, general and administrative |  |  | 834 |  |  |  | 637 |  |  |  | 9,814 |  |
|  |  |  | 1,493 |  |  |  | 952 |  |  |  | 36,159 |  |

[0001193125-12-408603:notes:150]
Stock Options

[0001193125-12-408603:notes:151]
The
   following is a summary of option activity for the Company’s stock incentive plans for fiscal 2012, 2011 and 2010:

[0001193125-12-408603:notes:152]
|  |  | Common Stock Options Outstanding |  |
|  |  | Numberof Options |  |  | WeightedAverageExercisePrice |  |  | WeightedAverageRemainingContractualLife (Years) |  |  | AggregateIntrinsicValue |  |
|  |  |  |  |  |  |  |  |  |  |  | (In thousands) |  |
| Balance, June 30, 2009 |  |  | 7,180,000 |  |  | $ | 0.04 |  |  |  | 7.64 |  |  | $ | 5,516 |  |
| Granted |  |  | 594,340 |  |  |  | 1.87 |  |  |  |  |  |  |  |  |  |
| Options repurchased and cancelled |  |  | (794,660 | ) |  |  | 0.04 |  |  |  |  |  |  |  |  |  |
| Forfeitures and cancellations |  |  | (1,183,510 | ) |  |  | 0.07 |  |  |  |  |  |  |  |  |  |
| Balance, June 30, 2010 |  |  | 5,796,170 |  |  | $ | 0.23 |  |  |  | 6.92 |  |  | $ | 12,642 |  |
| Granted |  |  | 1,149,062 |  |  |  | 3.42 |  |  |  |  |  |  |  |  |  |
| Forfeitures and cancellations |  |  | (773,525 | ) |  |  | 1.03 |  |  |  |  |  |  |  |  |  |
| Balance, June 30, 2011 |  |  | 6,171,707 |  |  | $ | 0.72 |  |  |  | 6.44 |  |  | $ | 43,135 |  |
| Granted |  |  | 161,000 |  |  |  | 10.44 |  |  |  |  |  |  |  |  |  |
| Exercised |  |  | (2,885,470 | ) |  |  | 0.28 |  |  |  |  |  |  |  |  |  |
| Forfeitures and cancellations |  |  | (99,792 | ) |  |  | 4.71 |  |  |  |  |  |  |  |  |  |
| Balance, June 30, 2012 |  |  | 3,347,445 |  |  | $ | 1.45 |  |  |  | 6.62 |  |  | $ | 42,920 |  |
| Vested and expected to vest as of June 30, 2012 |  |  | 3,306,522 |  |  | $ | 1.41 |  |  |  | 6.60 |  |  | $ | 42,518 |  |
| Vested and exercisable as of June 30, 2012 |  |  | 2,496,755 |  |  | $ | 0.55 |  |  |  | 6.03 |  |  | $ | 34,197 |  |

[0001193125-12-408603:notes:153]
Additional information regarding
   options outstanding as of June 30, 2012 is as follows (in thousands, except weighted average exercise price amounts and contractual life):

[0001193125-12-408603:notes:154]
|  |  | Options Outstanding |  |  |  |  |  | Options Exercisable |  |
| Range of Exercise Prices |  | Number ofOptions |  |  | WeightedAverageRemainingContractualLife (Years) |  |  | WeightedAverageExercisePrice |  |  | Number ofOptions |  |  | WeightedAverageExercisePrice |  |
| $0.01 – $0.04 |  |  | 303,680 |  |  |  | 4.53 |  |  | $ | 0.01 |  |  |  | 303,680 |  |  | $ | 0.01 |  |
| $0.05 – $0.39 |  |  | 1,764,890 |  |  |  | 5.78 |  |  |  | 0.05 |  |  |  | 1,764,890 |  |  |  | 0.05 |  |
| $0.40 – $2.89 |  |  | 404,840 |  |  |  | 7.68 |  |  |  | 1.65 |  |  |  | 142,575 |  |  |  | 1.41 |  |
| $2.90 – $4.07 |  |  | 438,132 |  |  |  | 8.25 |  |  |  | 2.90 |  |  |  | 183,872 |  |  |  | 2.90 |  |
| $4.08 – $8.64 |  |  | 389,903 |  |  |  | 8.81 |  |  |  | 5.51 |  |  |  | 101,738 |  |  |  | 5.42 |  |
| $8.65 – $26.28 |  |  | 46,000 |  |  |  | 9.30 |  |  |  | 14.82 |  |  |  | — |  |  |  | — |  |
| $0.01 – $26.28 |  |  | 3,347,445 |  |  |  | 6.62 |  |  | $ | 1.45 |  |  |  | 2,496,755 |  |  | $ | 0.55 |  |

[0001193125-12-408603:notes:155]
During fiscal 2012, the aggregate intrinsic value of options exercised under the Company’s stock incentive plans was $48.6 million
   as determined as of the date of option exercise. The Company had no option exercises during fiscal 2011 or 2010.

[0001193125-12-408603:notes:156]
As of June 30, 2012,
   the Company had unrecognized compensation costs of $1.8 million related to stock options which the Company expects to recognize over a weighted-average period 2.7 years. Future option grants will increase the amount of compensation expense to be
   recorded in these periods.

[0001193125-12-408603:notes:157]
The Company estimates the fair value of employee stock options using the Black-Scholes option pricing model. The
   fair value of employee stock options is being amortized on a straight-line basis over the requisite service period of the awards. The fair value of employee stock options was estimated using the following weighted average assumptions:

[0001193125-12-408603:notes:158]
|  |  | Years Ended June 30, |  |
|  |  | 2012 |  |  | 2011 |  |  | 2010 |  |
| Expected term |  |  | 6.1 years |  |  |  | 6.1 years |  |  |  | 6.1 years |  |
| Expected volatility |  |  | 49 | % |  |  | 65 | % |  |  | 65 | % |
| Risk-free interest rate |  |  | 1.6 | % |  |  | 4.2 | % |  |  | 4.5 | % |
| Expected dividend yield |  |  | — |  |  |  | — |  |  |  | — |  |
| Weighted average grant date fair value |  | $ | 5.05 |  |  | $ | 2.10 |  |  | $ | 1.14 |  |

[0001193125-12-408603:notes:159]
Expected term. Expected term represents the period that the Company’s stock-based awards are expected to be
   outstanding. As the Company has limited historical option exercise data, the expected term of the stock options granted to employees was calculated based on the simplified method. Under the simplified method, the expected term is equal to the
   average of an option’s weighted-average vesting period and its contractual term. The Company is permitted to continue using the simplified method until sufficient information regarding exercise behavior, such as historical exercise data or
   exercise information from external sources, becomes available.

[0001193125-12-408603:notes:160]
Expected volatility. The expected volatility was based on the
   historical stock volatilities of a group of publicly listed comparable companies over a period equal to the expected terms of the options, as the Company does not have any trading history to use the volatility of the Company’s common stock.

[0001193125-12-408603:notes:161]
Expected dividend yield. The Company has never paid dividends on the Company’s common stock and does not expect to pay
   dividends on its common stock.

[0001193125-12-408603:notes:162]
Risk-free interest
   rate. The risk-free interest rate is based on the U.S. Treasury yield curve in effect at the time of grant for zero coupon U.S. Treasury notes with maturities approximately equal to the option’s expected term.

[0001193125-12-408603:notes:163]
Fair value of common stock. The Company’s common stock began trading on the NASDAQ Global Select Market on October 14, 2011, upon
   its initial public offering. The fair value of the Company’s common stock is determined using the market price of the Company’s common stock as of the date of grant. Prior to October 14, 2011, the fair value of the shares of
   common stock underlying the stock options has historically been the responsibility of and determined by the Company’s board of directors. Because there had been no public market for the Company’s common stock, its board of directors has
   determined fair value of the common stock at the time of grant of the option by considering a number of objective and subjective factors including independent third-party valuations of its common stock, operating and financial performance, the lack
   of liquidity of capital stock and general and industry specific economic outlook, amongst other factors.

[0001193125-12-408603:notes:164]
Forfeiture rate. The
   Company estimates its forfeiture rate based on an analysis of its actual forfeitures and will continue to evaluate the adequacy of the forfeiture rate based on actual forfeiture experience, analysis of employee turnover behavior and other factors.
   The impact from a forfeiture rate adjustment will be recognized in full in the period of adjustment, and if the actual number of future forfeitures differs from that estimated, the Company may be required to record adjustments to stock-based
   compensation expense in future periods.

[0001193125-12-408603:notes:165]
Cash received from stock option exercises during the fiscal 2012, 2011 and 2010 were $811,000, zero
   and zero, respectively.

[0001193125-12-408603:notes:166]
Restricted Stock Units (“RSUs”)

[0001193125-12-408603:notes:167]
The following table summarizes the activity of the RSUs made by the Company:

[0001193125-12-408603:notes:168]
|  |  | Numberof Shares |  |  | WeightedAverage GrantDate Fair Value |  |
| RSUs granted |  |  | 501,180 |  |  | $ | 1.92 |  |
| RSUs vested |  |  | — |  |  |  | — |  |
| Non-vested RSUs, June 30, 2010 |  |  | 501,180 |  |  | $ | 1.92 |  |
| RSUs granted |  |  | 112,500 |  |  |  | 5.14 |  |
| RSUs vested |  |  | (125,295 | ) |  |  | 1.92 |  |
| Non-vested RSUs, June 30, 2011 |  |  | 488,385 |  |  | $ | 2.66 |  |
| RSUs granted |  |  | 169,710 |  |  |  | 22.33 |  |
| RSUs vested |  |  | (146,475 | ) |  |  | 2.37 |  |
| RSUs cancelled |  |  | (58,000 | ) |  |  | 8.04 |  |
| Non-vested RSUs, June 30, 2012 |  |  | 453,620 |  |  | $ | 9.42 |  |

[0001193125-12-408603:notes:169]
The intrinsic value of RSUs vested in fiscal 2012 and 2011 was $3.5 million and $640,000, respectively. No RSUs vested during fiscal
   2010. The total intrinsic value of all outstanding restricted stock units was $6.5 million as of June 30, 2012.

[0001193125-12-408603:notes:170]
As of June 30,
   2012, there was unrecognized compensation costs related to RSUs of $3.7 million which the Company expects to recognize over a weighted average period of 3.7 years.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001193125-12-408603:notes:171]
NOTE 12—INCOME TAXES

[0001193125-12-408603:notes:172]
The components of income before provision for income taxes were as follows (in thousands):

[0001193125-12-408603:notes:173]
|  |  | Years Ended June 30, |  |
|  |  | 2012 |  |  | 2011 |  |  | 2010 |  |
| Domestic |  | $ | 41,490 |  |  | $ | 24,484 |  |  | $ | (14,731 | ) |
| Foreign |  |  | 82,533 |  |  |  | 37,675 |  |  |  | 19,994 |  |
|  |  | $ | 124,023 |  |  | $ | 62,159 |  |  | $ | 5,263 |  |

[0001193125-12-408603:notes:174]
The components of the Company’s provision for income taxes consisted of the following:

[0001193125-12-408603:notes:175]
|  |  | Years Ended June 30, |  |
|  |  | 2012 |  |  | 2011 |  |  | 2010 |  |
| Current |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign |  | $ | 2,040 |  |  | $ | 978 |  |  | $ | 716 |  |
| Federal |  |  | 17,437 |  |  |  | 11,005 |  |  |  | 9,530 |  |
| State |  |  | 2,854 |  |  |  | 1,612 |  |  |  | 2,263 |  |
| Current tax expense |  |  | 22,331 |  |  |  | 13,595 |  |  |  | 12,509 |  |
| Deferred |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign |  |  | — |  |  |  | — |  |  |  | — |  |
| Federal |  |  | (217 | ) |  |  | (912 | ) |  |  | (1,392 | ) |
| State |  |  | (680 | ) |  |  | (251 | ) |  |  | (398 | ) |
| Deferred tax expense |  |  | (897 | ) |  |  | (1,163 | ) |  |  | (1,790 | ) |
| Provision for income taxes |  | $ | 21,434 |  |  | $ | 12,432 |  |  | $ | 10,719 |  |

[0001193125-12-408603:notes:176]
Significant components of the Company’s deferred tax assets and liabilities consisted of the following:

[0001193125-12-408603:notes:177]
|  |  | June 30, |  |
|  |  | 2012 |  |  | 2011 |  |
| Deferred tax assets |  |  |  |  |  |  |  |  |
| Deferred revenue |  | $ | — |  |  | $ | 525 |  |
| Allowance for doubtful accounts |  |  | 238 |  |  |  | 253 |  |
| Stock-based compensation |  |  | 1,016 |  |  |  | 529 |  |
| Warranty |  |  | — |  |  |  | 89 |  |
| Accrued expenses |  |  | 256 |  |  |  | 364 |  |
| Research and development credits |  |  | 468 |  |  |  | — |  |
| Other |  |  | 186 |  |  |  | 25 |  |
| Total deferred tax assets |  |  | 2,164 |  |  |  | 1,785 |  |
| Deferred tax liabilities |  |  |  |  |  |  |  |  |
| Cumulative change in accounting method |  |  | — |  |  |  | (1,020 | ) |
| Other |  |  | (1,050 | ) |  |  | (548 | ) |
| Total deferred tax liabilities |  |  | (1,050 | ) |  |  | (1,568 | ) |
| Net deferred tax assets (liabilities) |  | $ | 1,114 |  |  | $ | 217 |  |

[0001193125-12-408603:notes:178]
The effective tax rate differs from
   the applicable U.S. statutory federal income tax rate as follows:

[0001193125-12-408603:notes:179]
|  |  | June 30, |  |
|  |  | 2012 |  |  | 2011 |  |  | 2010 |  |
| Statutory rate |  |  | 35.0 | % |  |  | 35.0 | % |  |  | 35.0 | % |
| Stock-based compensation |  |  | — |  |  |  | — |  |  |  | 233.0 |  |
| State tax expense |  |  | 1.0 |  |  |  | 1.0 |  |  |  | 23.0 |  |
| Tax rate differential, foreign income |  |  | (23.0 | ) |  |  | (20.0 | ) |  |  | (120.0 | ) |
| Foreign credits |  |  | — |  |  |  | — |  |  |  | (8.0 | ) |
| Federal research and development credits |  |  | — |  |  |  | (1.0 | ) |  |  | (6.0 | ) |
| Other permanent items |  |  | 4.3 |  |  |  | 5.0 |  |  |  | 35.7 |  |
| Non-deductible penalties |  |  | — |  |  |  | — |  |  |  | 11.0 |  |
| Effective tax rate |  |  | 17.3 | % |  |  | 20.0 | % |  |  | 203.7 | % |

[0001193125-12-408603:notes:180]
In fiscal 2010, stock-based compensation incurred from common stock repurchased in connection with the Summit transaction in March 2010
   was not tax deductible, resulting in a decrease in domestic income but no tax benefit. The Company had increased foreign operations in fiscal 2012 as compared to fiscal 2011 and in fiscal 2011 as compared to fiscal 2010 and in fiscal 2010 as
   compared to fiscal 2009, generating more income on a comparative year over year basis in foreign jurisdictions that have lower tax rates than the U.S.

[0001193125-12-408603:notes:181]
The Company adopted FASB Accounting Standards Codification 740-10-25 on July 1, 2008. As a result of the implementation, the Company did not recognize any adjustments to the liability for uncertain
   tax position and therefore did not record any adjustment to the beginning balance of retained earnings on the balance sheet. As of the date of the adoption, the Company had no accrued interest and/or penalties. The Company does not anticipate a
   significant change to its unrecognized tax benefits over the next twelve months. The unrecognized tax benefits may change during the next year for items that arise in the ordinary course of business.

[0001193125-12-408603:notes:182]
U.S. income and foreign withholding taxes associated with the repatriation of earnings of foreign subsidiaries have not been provided on $138.0 million
   of undistributed earnings for certain foreign subsidiaries. The Company intends to reinvest these earnings indefinitely outside of the United States. If these earnings were distributed to the U.S. in the form of dividends or otherwise, or if the
   shares of the relevant foreign subsidiaries were sold or otherwise transferred, the Company may be subject to additional U.S. income taxes and foreign withholding taxes. Determination of the amount of unrecognized deferred tax liability related to
   these earnings is not practicable.

[0001193125-12-408603:notes:183]
The Company has California research and development tax credit carryovers of approximately $468,000, which
   do not expire.

[0001193125-12-408603:notes:184]
Tax years 2009 through 2012 are subject to examination by the federal tax authorities. There are no income tax examinations
   currently in process.

[0001193125-12-408603:notes:185]
Tax years 2008 through 2012 are subject to examination by the state tax authorities. There are no income tax
   examinations currently in process.

[0001193125-12-408603:notes:186]
Uncertain Tax Positions

[0001193125-12-408603:notes:187]
Effective July 1, 2008, the Company adopted a new accounting standard that provides guidance on accounting for uncertainty in income taxes. The adoption had no effect on the Company’s
   consolidated financial statements. A reconciliation of the beginning and ending balances of the unrecognized tax benefits during the years ended June 30, 2012, 2011 and 2010 consist of the following:

[0001193125-12-408603:notes:188]
|  |  | Years Ended June 30, |  |
|  |  | 2012 |  |  | 2011 |  |  | 2010 |  |
|  |  | (In thousands) |  |
| Unrecognized benefit—beginning of period |  | $ | 2,020 |  |  | $ | 762 |  |  | $ | 264 |  |
| Gross increases—current year tax positions |  |  | 4,697 |  |  |  | 1,258 |  |  |  | 498 |  |
| Gross increases—prior year tax positions |  |  | 1,108 |  |  |  | — |  |  |  | — |  |
| Unrecognized benefit—end of period |  | $ | 7,825 |  |  | $ | 2,020 |  |  | $ | 762 |  |

[0001193125-12-408603:notes:189]
The total amount of unrecognized tax benefits that would affect the Company’s effective tax rate if recognized is
   $7.1 million.

[0001193125-12-408603:notes:190]
Accrued interest and penalties related to unrecognized tax benefits are classified as income tax expense and were
   immaterial. The Company files income tax returns in the United States, various states and certain foreign jurisdictions.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001193125-12-408603:notes:191]
NOTE 13— SEGMENT INFORMATION, REVENUES BY GEOGRAPHY AND SIGNIFICANT CUSTOMERS

[0001193125-12-408603:notes:192]
Revenues by product type were as follows (in thousands, except percentages):

[0001193125-12-408603:notes:193]
|  |  | Years Ended June 30, |  |
|  |  | 2012 |  |  | 2011 |  |  | 2010 |  |
| airMAX |  | $ | 223,743 |  |  |  | 63 | % |  | $ | 113,001 |  |  |  | 57 | % |  | $ | 37,525 |  |  |  | 27 | % |
| New platforms |  |  | 29,465 |  |  |  | 8 | % |  |  | 2,513 |  |  |  | 1 | % |  |  | — |  |  |  | — | % |
| Other systems |  |  | 52,086 |  |  |  | 15 | % |  |  | 44,884 |  |  |  | 23 | % |  |  | 75,368 |  |  |  | 55 | % |
| Systems |  |  | 305,294 |  |  |  | 86 | % |  |  | 160,398 |  |  |  | 81 | % |  |  | 112,893 |  |  |  | 82 | % |
| Embedded radio |  |  | 10,056 |  |  |  | 3 | % |  |  | 14,762 |  |  |  | 7 | % |  |  | 14,047 |  |  |  | 10 | % |
| Antennas/other |  |  | 38,167 |  |  |  | 11 | % |  |  | 22,714 |  |  |  | 12 | % |  |  | 10,012 |  |  |  | 8 | % |
| Total revenues |  | $ | 353,517 |  |  |  | 100 | % |  | $ | 197,874 |  |  |  | 100 | % |  | $ | 136,952 |  |  |  | 100 | % |

[0001193125-12-408603:notes:194]
The Company generally forwards products directly from its manufacturers to its distributors in Hong Kong, who in turn ship to other
   locations throughout the world. The Company has determined the geographical distribution of product revenues based upon the ship-to destinations.

[0001193125-12-408603:notes:195]
Revenues by geography were as follows (in thousands, except percentages):

[0001193125-12-408603:notes:196]
|  |  | Years Ended June 30, |  |
|  |  | 2012 |  |  | 2011 |  |  | 2010 |  |
| North America (1) |  | $ | 88,309 |  |  |  | 25 | % |  | $ | 61,920 |  |  |  | 31 | % |  | $ | 56,995 |  |  |  | 42 | % |
| South America |  |  | 88,325 |  |  |  | 25 | % |  |  | 50,824 |  |  |  | 26 | % |  |  | 13,520 |  |  |  | 10 | % |
| Europe, the Middle East and Africa |  |  | 130,494 |  |  |  | 37 | % |  |  | 68,297 |  |  |  | 35 | % |  |  | 55,089 |  |  |  | 40 | % |
| Asia Pacific |  |  | 46,389 |  |  |  | 13 | % |  |  | 16,833 |  |  |  | 8 | % |  |  | 11,348 |  |  |  | 8 | % |
| Total revenues |  | $ | 353,517 |  |  |  | 100 | % |  | $ | 197,874 |  |  |  | 100 | % |  | $ | 136,952 |  |  |  | 100 | % |

[0001193125-12-408603:notes:197]
| (1) | Revenue for the United States was $84.3 million, $60.0 million and $56.2 million for fiscal 2012, 2011 and 2010, respectively. |

[0001193125-12-408603:notes:198]
Customers with an accounts receivable
   balance of 10% or greater of total accounts receivable and customers with net revenues of 10% or greater of total revenues are presented below for the periods indicated:

[0001193125-12-408603:notes:199]
|  |  | Percentage of Revenues |  |  | Percentage of Accounts Receivable |  |
|  |  | Years Ended June 30, |  |  | June 30, |  |
|  |  | 2012 |  |  | 2011 |  |  | 2010 |  |  | 2012 |  |  | 2011 |  |
| Flytec Computers Inc. |  |  | 16 | % |  |  | 20 | % |  |  | 17 | % |  |  | 19 | % |  |  | 21 | % |
| Streakwave Wireless Inc. |  |  | 10 | % |  |  | 15 | % |  |  | 13 | % |  |  | 11 | % |  |  | 25 | % |
| Discomp |  |  | * |  |  |  | * |  |  |  | * |  |  |  | 12 | % |  |  | * |  |

[0001193125-12-408603:notes:200]
| * | denotes less than 10% |


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0001193125-12-408603:notes:201]
NOTE 14—401(k) BENEFIT PLAN

[0001193125-12-408603:notes:202]
The Company sponsors a 401(k) defined contribution plan. It matches 1% of the first 4% of an employee’s compensation contributed
   to the plan. The Company’s contributions to the plan were $47,000, $28,000 and $20,000 for fiscal 2012, 2011 and 2010, respectively.


## us-gaap:SubsequentEventsTextBlock

[0001193125-12-408603:notes:203]
NOTE 15—SUBSEQUENT EVENTS

[0001193125-12-408603:notes:204]
Loan and Security Agreement

[0001193125-12-408603:notes:205]
On August 7, 2012, the Company entered into a Loan and Security Agreement (the “Loan Agreement”) with U.S. Bank, as syndication agent, and East West Bank, as administrative agent. The Loan
   Agreement replaces the EWB Loan Agreement as discussed in Note 8. The Loan Agreement provides for (i) a $50.0 million revolving credit facility, with a $5.0 million sublimit for the issuance of letters of credit and a $5.0 million sublimit for
   the making of swingline loan advances (the “Revolving Credit Facility”), and (ii) a $50.0 million term loan facility (the “Term Loan Facility”). The Company may request borrowings under the Revolving Credit Facility until
   August 7, 2015. On August 7, 2012, the Company borrowed an additional $20.8 million of term loans under the Term Loan Facility.

[0001193125-12-408603:notes:206]
The
   loans bear interest, at the Company’s option, at the base rate plus a spread of 1.25% to 1.75% or an adjusted LIBOR rate (based, at the Company’s election, on a period of 30, 60, or 90 days) plus a spread of 2.25% to 2.75%, in each case
   with such spread being determined based on the debt service coverage ratio for the last fiscal quarter. The base rate means the highest of East West Bank’s prime rate, the federal funds rate plus a margin equal to 0.50%, or the adjusted LIBOR
   rate for a period of 30, 60, or 90 days plus a margin equal to 1.00%. The Company is also obligated to pay other customary closing fees, arrangement fees, administration fees, commitment fees and letter of credit fees for a credit facility of this
   size and type.

[0001193125-12-408603:notes:207]
Interest is due and payable in arrears monthly in the case of loans bearing interest at the base rate and at the end of an
   interest period (or quarterly in the case of loans with interest periods greater than three months) in the case of loans bearing interest at the adjusted LIBOR rate. Principal payments under the Term Loan Facility will be made in quarterly
   installments, each such quarterly installment shall be equal to $1.25 million until August 7, 2014, then equal to $1.875 million until August 7, 2015, and then equal to $2.5 million until August 7, 2017, subject to adjustment as a
   result of any prepayments, with the remaining outstanding principal balance and all accrued and unpaid interest due on August 7, 2017. All outstanding loans under the Revolving Credit Facility, together with all accrued and unpaid interest, are
   due on August 7, 2015.

[0001193125-12-408603:notes:208]
The Company may prepay the loans, in whole or in part, at any time without premium or penalty, subject to certain
   conditions including minimum amounts and reimbursement of certain costs in the case of prepayments of LIBOR loans. In addition, the Company is required to prepay the loan under the Term Loan Facility with the proceeds from certain financing
   transactions or asset sales (subject, in the case of asset sales, to reinvestment rights) and with 25.0% of the Company’s excess cash flow, as determined after each fiscal year and in accordance with the Loan Agreement, provided that the
   Company shall not be required to prepay the loan out of its excess cash flow if its leverage ratio is greater than 1.50:1.00 on the last day of such fiscal year.

[0001193125-12-408603:notes:209]
All of the obligations under the Loan
   Agreement are secured by substantially all of the Company’s assets, including all of the capital stock of the Company’s future domestic subsidiaries and 65% of the capital stock of the Company’s existing and future foreign
   subsidiaries, but excluding the Company’s intellectual property. All of the Company’s future domestic subsidiaries are required to guaranty the obligations under the Loan Agreement. Such guarantees by future subsidiaries will be secured by
   substantially all of the property of such subsidiaries, excluding intellectual property.

[0001193125-12-408603:notes:210]
The Loan Agreement contains customary affirmative
   and negative covenants, including covenants that limit or restrict the Company and its subsidiaries’ ability to, among other things, incur indebtedness, grant liens, merge or consolidate, dispose of assets, pay dividends or make distributions,
   make investments, make acquisitions, prepay certain indebtedness, change the nature of its business, enter into certain transactions with affiliates, enter into restrictive agreements, and make capital expenditures, in each case subject to customary
   exceptions for a credit facility of this size and type. The Company is also required to maintain compliance with a debt service coverage ratio, a leverage ratio, and a minimum level of liquidity.

[0001193125-12-408603:notes:211]
The Loan Agreement includes customary events of default that, include among other things, non-payment defaults, defaults due to the inaccuracy of
   representations and warranties, covenant defaults, cross default to material indebtedness, bankruptcy and insolvency defaults, material judgment defaults, defaults due to the unenforceability of a guaranty, and defaults due to circumstances that
   have or could have a material adverse effect. The occurrence of an event of default could result in the acceleration of the obligations under the Loan Agreement. During the existence of an event of default, interest on the obligations under the Loan
   Agreement could be increased by 2.00% above the otherwise applicable interest rate.

[0001193125-12-408603:notes:212]
Common Stock Repurchase

[0001193125-12-408603:notes:213]
On August 9, 2012, the Company announced that its Board of Directors authorized the Company to repurchase up to $100 million of its common stock. The
   share repurchase program commenced Monday, August 13, 2012. The share repurchase program will be funded from existing cash on hand and from the proceeds from the Loan Agreement as discussed above. Through September 21, 2012, the Company
   had repurchased 3,101,214 shares of its outstanding common stock at an average price of $9.79 per share for a total cost of $30.4 million.

[0001193125-12-408603:notes:214]
Shareholder Class Action Lawsuits

[0001193125-12-408603:notes:215]
Beginning on September 7, 2012, two purported
   shareholder class action complaints were filed against the Company, certain of its officers and directors and the underwriters of the Company’s initial public offering in the United States District Court for the Northern District of
   California. The complaints purport to bring claims under the Securities Act of 1933, the Securities Exchange Act of 1934 and SEC Rule 10b-5 on behalf a class of purchasers of the Company’s common stock from October 14, 2011 through
   August 9, 2012 and/or who acquired the Company’s stock pursuant to or traceable to the registration statement for the IPO. The complaints seek, among other things, compensatory damages, rescission, and attorneys’ fees and costs.

[0001193125-12-408603:notes:216]
The Company believes that the allegations in the complaints are without merit and intend to vigorously contest the litigation. However,
   there can be no assurance that the Company will be successful in its defense and the Company cannot currently estimate a range of possible losses it may experience in connection with this litigation.


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0001193125-12-408603:notes:217]
NOTE 16—SUPPLEMENTARY DATA (UNAUDITED)

[0001193125-12-408603:notes:218]
The following table presents the Company’s unaudited consolidated statements of operations data for each of the eight quarters
   during fiscal 2012 and 2011. In management’s opinion, this information has been presented on the same basis as the audited consolidated financial statements included in a separate section of this report, and all necessary adjustments,
   consisting only of normal recurring adjustments, have been included in the amounts below to state fairly the unaudited quarterly results when read in conjunction with the audited consolidated financial statements and related notes. The operating
   results for any quarter should not be relied upon as necessarily indicative of results for any future period.

[0001193125-12-408603:notes:219]
|  |  | Fiscal 2012 |  |
|  |  | FirstQuarter |  |  | SecondQuarter |  |  | ThirdQuarter |  |  | FourthQuarter |  |
| Net revenue |  | $ | 79,167 |  |  | $ | 87,817 |  |  | $ | 91,665 |  |  | $ | 94,868 |  |
| Gross profit |  |  | 33,013 |  |  |  | 37,290 |  |  |  | 39,659 |  |  |  | 41,041 |  |
| Income from operations |  |  | 27,500 |  |  |  | 31,176 |  |  |  | 32,556 |  |  |  | 34,060 |  |
| Net income |  |  | 21,493 |  |  |  | 24,691 |  |  |  | 27,920 |  |  |  | 28,485 |  |
| Net income (loss) attributable to common stockholders—basic |  |  | (81,234 | ) |  |  | 14,428 |  |  |  | 27,920 |  |  |  | 28,485 |  |
| Net income (loss) attributable to common stockholders—diluted |  |  | (81,234 | ) |  |  | 14,443 |  |  |  | 27,920 |  |  |  | 28,485 |  |
| Net income (loss) per share of common stock: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | (1.30 | ) |  | $ | 0.16 |  |  | $ | 0.30 |  |  | $ | 0.31 |  |
| Diluted |  | $ | (1.30 | ) |  | $ | 0.16 |  |  | $ | 0.30 |  |  | $ | 0.30 |  |
|  |  | Fiscal 2011 |  |
|  |  | FirstQuarter |  |  | SecondQuarter |  |  | ThirdQuarter |  |  | FourthQuarter |  |
| Net revenue |  | $ | 34,082 |  |  | $ | 45,087 |  |  | $ | 51,151 |  |  | $ | 67,554 |  |
| Gross profit |  |  | 13,629 |  |  |  | 18,042 |  |  |  | 21,104 |  |  |  | 28,037 |  |
| Income from operations |  |  | 9,468 |  |  |  | 13,680 |  |  |  | 16,282 |  |  |  | 22,650 |  |
| Net income |  |  | 7,581 |  |  |  | 10,978 |  |  |  | 13,033 |  |  |  | 18,135 |  |
| Net income (loss) attributable to common stockholders—basic |  |  | 3,722 |  |  |  | 4,037 |  |  |  | 3,097 |  |  |  | (9,383 | ) |
| Net income (loss) attributable to common stockholders—diluted |  |  | 3,793 |  |  |  | 4,122 |  |  |  | 3,168 |  |  |  | (9,383 | ) |
| Net income (loss) per share of common stock: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.06 |  |  | $ | 0.06 |  |  | $ | 0.05 |  |  | $ | (0.15 | ) |
| Diluted |  | $ | 0.06 |  |  | $ | 0.06 |  |  | $ | 0.05 |  |  | $ | (0.15 | ) |
