# UI 8-K — 0001193125-12-347732 filed 2012-08-09

## item codes, every 8-K on or before 2012-09-28

- 2012-08-13 0001193125-12-352624 — 1.01, 2.03, 9.01
- 2012-08-09 0001193125-12-347776 — 1.01, 9.01
- 2012-08-09 0001193125-12-347732 — 2.02, 9.01
- 2012-05-01 0001193125-12-201012 — 2.02, 9.01
- 2012-03-30 0001193125-12-144074 — 5.02
- 2012-03-27 0001193125-12-134395 — 5.02, 9.01
- 2012-03-22 0001193125-12-127536 — 5.02
- 2012-01-31 0001193125-12-032079 — 2.02, 9.01
- 2011-12-27 0001193125-11-353002 — 1.01, 9.01
- 2011-12-06 0001193125-11-332192 — 5.02
- 2011-11-10 0001193125-11-306969 — 2.02, 9.01

## late-filing notifications on or before 2012-09-28

- none on or before 2012-09-28

## item 2.02 — earnings release, exhibit 99.1

[0001193125-12-347732:8k_2_02:1]
EX-99.1
2
d394690dex991.htm
PRESS RELEASE

[0001193125-12-347732:8k_2_02:2]
Press Release

[0001193125-12-347732:8k_2_02:3]
Exhibit 99.1

[0001193125-12-347732:8k_2_02:4]
For more information:

[0001193125-12-347732:8k_2_02:5]
John Ritchie

[0001193125-12-347732:8k_2_02:6]
Chief Financial Officer

[0001193125-12-347732:8k_2_02:7]
Ubiquiti Networks

[0001193125-12-347732:8k_2_02:8]
408.942.3085 ext 329

[0001193125-12-347732:8k_2_02:9]
UBIQUITI NETWORKS REPORTS Q4 FISCAL 2012 RESULTS

[0001193125-12-347732:8k_2_02:10]
|  | • |  | Quarterly Revenues Increase by 40% Year-over-Year |

[0001193125-12-347732:8k_2_02:11]
|  | • |  | Quarterly Non-GAAP Net Income Grows by 52% Year-over-Year |

[0001193125-12-347732:8k_2_02:12]
|  | • |  | Quarterly Non-GAAP Diluted EPS of $0.30 |

[0001193125-12-347732:8k_2_02:13]
|  | • |  | Cash Increases by $27.9 Million |

[0001193125-12-347732:8k_2_02:14]
|  | • |  | $100 Million Share Repurchase Program Announced |

[0001193125-12-347732:8k_2_02:15]
San Jose, Calif. — August 9, 2012 — Ubiquiti Networks, Inc. (NASDAQ:UBNT), a next-generation communications technology company, today announced results for the fourth quarter of fiscal
2012, ended June 30, 2012.

[0001193125-12-347732:8k_2_02:16]
For the fourth quarter of fiscal 2012, Ubiquiti reported revenues of $94.9 million, an increase of 40%
compared to revenues of $67.6 million for the same period the prior year. For the year ended June 30, 2012 Ubiquiti reported revenues of $353.5 million, an increase of 79% compared to revenues of $197.9 million in fiscal 2011.

[0001193125-12-347732:8k_2_02:17]
For the fourth quarter of fiscal 2012, GAAP net income was $28.5 million, an increase of 57% compared to GAAP net income of $18.1 million for the same
period the prior year. Non-GAAP net income was $27.9 million, an increase of 52% compared to $18.3 million for the same period last year.

[0001193125-12-347732:8k_2_02:18]
For
the year ended June 30, 2012, GAAP net income was $102.6 million, an increase of 106% compared to GAAP net income of $49.7 million for the same period the prior year. Non-GAAP net income was $102.6 million, an increase of 104% compared to $50.3
million for the same period last year.

[0001193125-12-347732:8k_2_02:19]
The following table reconciles GAAP net income to non-GAAP net income and weighted-average shares used in
computing net income (loss)per share of common stock-diluted to weighted-average shares used in computing non-GAAP Diluted EPS:

[0001193125-12-347732:8k_2_02:20]
|  |  | Three Months Ended June 30, |  |  | Years Ended June 30, |  |
|  |  | 2012 |  |  | 2011 |  |  | 2012 |  |  | 2011 |  |
|  |  | (in thousands, except per share data) (unaudited) |  |
| Net income |  | $ | 28,485 |  |  | $ | 18,135 |  |  | $ | 102,589 |  |  | $ | 49,727 |  |
| Stock-based compensation |  |  | 461 |  |  |  | 276 |  |  |  | 1,493 |  |  |  | 952 |  |
| Income from a coexistence licensing agreement |  |  | (1,500 | ) |  |  | — |  |  |  | (1,500 | ) |  |  | — |  |
| Tax effect of stock-based compensation and income from a coexistence licensing agreement |  |  | 416 |  |  |  | (111 | ) |  |  | 3 |  |  |  | (381 | ) |
| Non-GAAP net income |  | $ | 27,862 |  |  | $ | 18,300 |  |  | $ | 102,585 |  |  | $ | 50,298 |  |
| Weighted-average shares used in computing net income (loss) per share of common stock- diluted |  |  | 94,168 |  |  |  | 62,652 |  |  |  | 83,460 |  |  |  | 66,907 |  |
| Weighted-average dilutive effect of stock options and restricted stock units |  |  | — |  |  |  | 3,905 |  |  |  | 2,695 |  |  |  | — |  |
| Weighted-average shares of Series A preferred shares outstanding |  |  | — |  |  |  | 36,035 |  |  |  | 7,607 |  |  |  | 36,035 |  |
| Weighted-average shares used in computing non-GAAP diluted EPS (1) |  |  | 94,168 |  |  |  | 102,592 |  |  |  | 93,762 |  |  |  | 102,942 |  |
| Non-GAAP diluted EPS (1) |  | $ | 0.30 |  |  | $ | 0.18 |  |  | $ | 1.09 |  |  | $ | 0.49 |  |

[0001193125-12-347732:8k_2_02:21]
| (1) | Non-GAAP Diluted EPS is calculated using non-GAAP net income excluding stock-based compensation, net of taxes and income from a coexistence licensing agreement and weighted-average shares outstanding as if Series A preferred stock is treated as common stock for the periods presented. |

[0001193125-12-347732:8k_2_02:22]
“Ubiquiti’s business model has translated into a unique combination of exceptional growth and industry-leading profitability
fundamentals,” said Robert J. Pera, Founder and Chief Executive Officer of Ubiquiti Networks. “Our innovative research and development strategy, and the early success of our technology diversification into new platforms and markets, shows
that we are only scratching the surface of the leverage and scalability inherent in our model. This past quarter our new platform growth continued, lead by Unifi, and momentum was further strengthened by the introduction of mFi, a revolutionary
machine-to-machine communications technology platform.”

[0001193125-12-347732:8k_2_02:23]
Added Mr. Pera: “The Ubiquiti brand is dominant in our markets and
demand for our technology is stronger than ever. This dominance has led to an unfortunate side effect whereby a few previously terminated distributors setup counterfeit AirMax manufacturing operations. Although they have impacted our sales channel
and caused some marketplace confusion, we have made substantial and tangible progress in diminishing their activities through a comprehensive legal strategy that has resulted in imprisonment, injunctions, and asset freezes of the counterfeiters. In
addition, Ubiquiti has implemented sophisticated anti-counterfeit manufacturing processes to substantially protect all of our new platforms and new AirMax products against any future counterfeit attempts.”

[0001193125-12-347732:8k_2_02:24]
Share Repurchase Program

[0001193125-12-347732:8k_2_02:25]
Ubiquiti today
announced that its Board of Directors has authorized the company to repurchase as much as $100 million of Company common stock. The Company is authorized to repurchase shares of its outstanding common stock on the open market or in privately
negotiated transactions. The share repurchase program will be funded from existing cash on hand and from the proceeds related to amended term loan and revolving credit line agreements. We expect the share repurchase program will commence Monday,
August 13, 2012.

[0001193125-12-347732:8k_2_02:26]
Business Outlook

[0001193125-12-347732:8k_2_02:27]
Ubiquiti currently believes the demand environment in its end markets supports the following forecast for the Company’s fiscal first quarter ending September 30, 2012:

[0001193125-12-347732:8k_2_02:28]
|  | • |  | Revenues of $62 million to $70 million |

[0001193125-12-347732:8k_2_02:29]
|  | • |  | GAAP Diluted EPS of $0.14 to $0.17 |

[0001193125-12-347732:8k_2_02:30]
|  | • |  | Non-GAAP Diluted EPS of $0.14 to $0.17 |

[0001193125-12-347732:8k_2_02:31]
|  | • |  | We believe that the amount of counterfeited goods, combined with the impact it has on our distributor’s inventory and the purchasing patterns of our customers, will impact our business outlook for the next two fiscal quarters. |

[0001193125-12-347732:8k_2_02:32]
|  | • |  | Ubiquiti has taken comprehensive legal actions to stop the counterfeiters and minimize the impact of their activities. |

[0001193125-12-347732:8k_2_02:33]
Conference Call

[0001193125-12-347732:8k_2_02:34]
Ubiquiti Networks will
discuss the Company’s financial results by conference call at 2:00 p.m. PDT today. Instructions for listening to the conference call over the Web are available on the investor relations portion of UBIQUITI NETWORKS’s website at
www.ubnt.com.

[0001193125-12-347732:8k_2_02:35]
About Ubiquiti Networks

[0001193125-12-347732:8k_2_02:36]
Ubiquiti Networks is a next-generation communications technology company bridging the digital divide between emerging and developed markets by fundamentally changing the economics and complexity of
deploying high performance networking solutions in underserved and underpenetrated markets globally. Our technology platforms focus on delivering industry-leading performance, compelling price-performing characteristics and an unparalleled user
experience. For more information visit http://www.ubnt.com/.

[0001193125-12-347732:8k_2_02:37]
Use of Non-GAAP Financial Information

[0001193125-12-347732:8k_2_02:38]
To supplement our condensed consolidated financial results prepared under generally accepted accounting principles, or GAAP, we use non-GAAP measures of
net income and earnings per diluted share that are adjusted to exclude certain recurring costs, expenses and gains such as stock based compensation expense, income from a coexistence licensing agreement and the tax effects of these non-GAAP
adjustments. In addition, our non-GAAP adjustments present shares of Series A preferred stock as if these shares had been converted to common stock throughout the periods presented. Reconciliations of the adjustments to GAAP results for the three
and twelve months ended June 30, 2012 and 2011 are provided below. In addition, an explanation of the ways in which management uses non-GAAP financial information to evaluate its business, the substance behind management’s decision to use
this non-GAAP financial information, the material limitations associated with the use of non-GAAP financial information, the manner in which management compensates for those limitations, and the substantive reasons management believes that this
non-GAAP financial information provides useful information to investors is included under “About our Non-GAAP Net Income and Adjustments” after the tables below.

[0001193125-12-347732:8k_2_02:39]
These non-GAAP measures are not in accordance with or an alternative to GAAP and may be materially different from other non-GAAP measures, including similarly titled non-GAAP measures, used by other
companies. The presentation of this additional information should not be considered in isolation from, as a substitute for, or superior to, net income or earnings per diluted share prepared in accordance with GAAP.

[0001193125-12-347732:8k_2_02:40]
Forward-looking statements are subject to certain risks and uncertainties that could cause our actual future results to differ materially, or cause a material adverse impact on our results. Potential
risks and uncertainties

[0001193125-12-347732:8k_2_02:41]
3

[0001193125-12-347732:8k_2_02:42]
include, but are not necessarily limited to, fluctuations in our operating results; varying demand for our products due to the financial and operating condition of our distributors and their
customers, distributors inventory management practices and general economic conditions; our reliance on a limited number of distributors; inability of our contract manufacturers and suppliers to meet our demand; our dependence on Qualcomm Atheros
for chipsets without a short-term alternative; as we move into new markets competition from certain of our current or potential competitors who may be more established in such markets; our ability to keep pace with technological and market
developments; success and timing of new product introductions by us and the performance of our products generally; if we fail to effectively manage the significant increase in our transactional sales volumes; we may become subject to warranty
claims, product liability and product recalls; that a substantial majority of our sales are into countries outside the United States and we are subject to numerous U.S. export control and economic sanctions laws; costs related to responding to
government inquiries related to regulatory compliance; our reliance on the Ubiquiti Community; our reliance on certain key members of our management team, including our founder and chief executive officer, Robert J. Pera; adverse tax-related matters
such as tax audits, changes in our effective tax rate or new tax legislative proposals; if the final determination of our income tax liability may be materially different from our income tax provisions; the impact of any intellectual property
litigation and claims for indemnification and litigation related to U.S. Securities laws and economic and political conditions in the United States and abroad. We discuss these risks in greater detail under the heading “Risk Factors” and
elsewhere in our Quarterly Report on Form 10-Q for the period ended March 31, 2012 and other filings filed with the U.S. Securities and Exchange Commission (SEC), which are available at the SEC’s website at www.sec.gov. Copies may also be
obtained by contacting Ubiquiti Networks’ Investor Relations Department, attn: John Ritchie by phone at 408.942.3085 ext. 329 or by email at investor.relations@ubnt.com or Ubiquiti Networks’ Investor Relations website at www.ubnt.com.

[0001193125-12-347732:8k_2_02:43]
Given these uncertainties, you should not place undue reliance on these forward-looking statements. Also, forward-looking statements
represent our management’s beliefs and assumptions only as of the date made. Ubiquiti Networks undertakes no obligation to update information contained in this press release. You should review our SEC filings carefully and with the
understanding that our actual future results may be materially different from what we expect.

[0001193125-12-347732:8k_2_02:44]
4

[0001193125-12-347732:8k_2_02:45]
Ubiquiti Networks Inc.

[0001193125-12-347732:8k_2_02:46]
Condensed Consolidated Statement of Operations

[0001193125-12-347732:8k_2_02:47]
(In thousands, except per share data)

[0001193125-12-347732:8k_2_02:48]
(Unaudited)

[0001193125-12-347732:8k_2_02:49]
|  |  | Three Months Ended June 30, |  |  | Years Ended June 30, |  |
|  |  | 2012 |  |  | 2011 |  |  | 2012 |  |  | 2011 |  |
| Revenues |  | $ | 94,868 |  |  | $ | 67,554 |  |  | $ | 353,517 |  |  | $ | 197,874 |  |
| Cost of revenues |  |  | 53,827 |  |  |  | 39,517 |  |  |  | 202,514 |  |  |  | 117,062 |  |
| Gross profit |  |  | 41,041 |  |  |  | 28,037 |  |  |  | 151,003 |  |  |  | 80,812 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development |  |  | 5,028 |  |  |  | 3,336 |  |  |  | 16,699 |  |  |  | 11,374 |  |
| Sales, general and administrative |  |  | 1,953 |  |  |  | 2,051 |  |  |  | 9,012 |  |  |  | 7,358 |  |
| Total operating expenses |  |  | 6,981 |  |  |  | 5,387 |  |  |  | 25,711 |  |  |  | 18,732 |  |
| Income from operations |  |  | 34,060 |  |  |  | 22,650 |  |  |  | 125,292 |  |  |  | 62,080 |  |
| Interest income (expense) and other, net |  |  | (133 | ) |  |  | 29 |  |  |  | (1,269 | ) |  |  | 79 |  |
| Income before provision for income taxes |  |  | 33,927 |  |  |  | 22,679 |  |  |  | 124,023 |  |  |  | 62,159 |  |
| Provision for income taxes |  |  | 5,442 |  |  |  | 4,544 |  |  |  | 21,434 |  |  |  | 12,432 |  |
| Net income |  | $ | 28,485 |  |  | $ | 18,135 |  |  | $ | 102,589 |  |  | $ | 49,727 |  |
| Preferred stock cumulative dividend and accretion of cost of preferred stock |  |  | — |  |  |  | (27,518 | ) |  |  | (112,431 | ) |  |  | (42,068 | ) |
| Less allocation of net income to participating preferred stockholders |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (2,784 | ) |
| Net income (loss) attributable to common stockholders—basic |  | $ | 28,485 |  |  | $ | (9,383 | ) |  | $ | (9,842 | ) |  | $ | 4,875 |  |
| Undistributed earnings re-allocated to common stockholders |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 103 |  |
| Net income (loss) attributable to common stockholders—diluted |  | $ | 28,485 |  |  | $ | (9,383 | ) |  | $ | (9,842 | ) |  | $ | 4,978 |  |
| Net income (loss) per share of common stock: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.31 |  |  | $ | (0.15 | ) |  | $ | (0.12 | ) |  | $ | 0.08 |  |
| Diluted |  | $ | 0.30 |  |  | $ | (0.15 | ) |  | $ | (0.12 | ) |  | $ | 0.07 |  |
| Weighted average shares used in computing net income (loss) per share of common stock: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 91,958 |  |  |  | 62,652 |  |  |  | 83,460 |  |  |  | 63,092 |  |
| Diluted |  |  | 94,168 |  |  |  | 62,652 |  |  |  | 83,460 |  |  |  | 66,907 |  |

[0001193125-12-347732:8k_2_02:50]
Ubiquiti Networks Inc.

[0001193125-12-347732:8k_2_02:51]
Reconciliation of GAAP Net Income to Non-GAAP Net Income

[0001193125-12-347732:8k_2_02:52]
(In thousands, except per
share data)

[0001193125-12-347732:8k_2_02:53]
(Unaudited)

[0001193125-12-347732:8k_2_02:54]
|  |  | Three Months Ended June 30, |  |  | Years Ended June 30, |  |
|  |  | 2012 |  |  | 2011 |  |  | 2012 |  |  | 2011 |  |
| Net income |  | $ | 28,485 |  |  | $ | 18,135 |  |  | $ | 102,589 |  |  | $ | 49,727 |  |
| Stock-based compensation: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of revenues |  |  | 43 |  |  |  | 10 |  |  |  | 117 |  |  |  | 30 |  |
| Research and development |  |  | 177 |  |  |  | 94 |  |  |  | 542 |  |  |  | 285 |  |
| Sales, general and administrative |  |  | 241 |  |  |  | 172 |  |  |  | 834 |  |  |  | 637 |  |
| Income from a coexistence licensing agreement |  |  | (1,500 | ) |  |  | — |  |  |  | (1,500 | ) |  |  | — |  |
| Tax effect of stock-based compensation and income from a coexistence licensing agreement |  |  | 416 |  |  |  | (111 | ) |  |  | 3 |  |  |  | (381 | ) |
| Non-GAAP net income |  | $ | 27,862 |  |  | $ | 18,300 |  |  | $ | 102,585 |  |  | $ | 50,298 |  |
| Non-GAAP diluted EPS (1) |  | $ | 0.30 |  |  | $ | 0.18 |  |  | $ | 1.09 |  |  | $ | 0.49 |  |
| Weighted-average shares used in non-GAAP diluted EPS (1) |  |  | 94,168 |  |  |  | 102,592 |  |  |  | 93,762 |  |  |  | 102,942 |  |

[0001193125-12-347732:8k_2_02:55]
| (1) | Non-GAAP Diluted EPS is calculated using non-GAAP net income excluding stock-based compensation and income from a coexistence licensing agreement, net of taxes and weighted-average shares outstanding as if Series A preferred stock is treated as common stock for the periods presented. |

[0001193125-12-347732:8k_2_02:56]
Ubiquiti Networks, Inc.

[0001193125-12-347732:8k_2_02:57]
Reconciliation of Weighted-Average Shares Used in Computing Net Income (Loss) Per Share of Common Stock-Diluted to Weighted-Average Shares Used In
Computing Non-GAAP Diluted EPS

[0001193125-12-347732:8k_2_02:58]
(In thousands, except per share data)

[0001193125-12-347732:8k_2_02:59]
(Unaudited)

[0001193125-12-347732:8k_2_02:60]
|  |  | Three Months Ended June 30, |  |  | Years Ended June 30, |  |
|  |  | 2012 |  |  | 2011 |  |  | 2012 |  |  | 2011 |  |
| Weighted-average shares used in computing net income(loss) per share of common stock- diluted |  |  | 94,168 |  |  |  | 62,652 |  |  |  | 83,460 |  |  |  | 66,907 |  |
| Add back: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Weighted-average dilutive effect of stock options and restricted stock units |  |  | — |  |  |  | 3,905 |  |  |  | 2,695 |  |  |  | — |  |
| Weighted-average shares of Series A preferred shares outstanding |  |  | — |  |  |  | 36,035 |  |  |  | 7,607 |  |  |  | 36,035 |  |
| Weighted-average shares used in computing non-GAAP diluted EPS |  |  | 94,168 |  |  |  | 102,592 |  |  |  | 93,762 |  |  |  | 102,942 |  |

[0001193125-12-347732:8k_2_02:61]
Ubiquiti Networks Inc.

[0001193125-12-347732:8k_2_02:62]
Condensed Consolidated Balance Sheets

[0001193125-12-347732:8k_2_02:63]
(In thousands, except share amounts)

[0001193125-12-347732:8k_2_02:64]
(Unaudited)

[0001193125-12-347732:8k_2_02:65]
|  |  | June 30, |  |
|  |  | 2012 |  |  | 2011(1) |  |
| Assets |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 122,060 |  |  | $ | 76,361 |  |
| Accounts receivable, net |  |  | 75,644 |  |  |  | 39,811 |  |
| Inventories |  |  | 7,734 |  |  |  | 5,663 |  |
| Deferred costs |  |  | — |  |  |  | 881 |  |
| Prepaid expenses and other current assets |  |  | 1,577 |  |  |  | 5,386 |  |
| Total current assets |  |  | 207,015 |  |  |  | 128,102 |  |
| Property and equipment, net |  |  | 4,471 |  |  |  | 1,022 |  |
| Intangible assets |  |  | 748 |  |  |  | — |  |
| Long-term deferred tax asset |  |  | 1,114 |  |  |  | 324 |  |
| Other long–term assets |  |  | 388 |  |  |  | 2,230 |  |
| Total assets |  | $ | 213,736 |  |  | $ | 131,678 |  |
| Liabilities, Convertible Preferred Stock and Stockholders’ Deficit |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Accounts payable |  | $ | 26,450 |  |  | $ | 14,758 |  |
| Customer deposits |  |  | 235 |  |  |  | 1,675 |  |
| Deferred revenues |  |  | 805 |  |  |  | 1,734 |  |
| Income taxes payable |  |  | 8,673 |  |  |  | 4,428 |  |
| Debt – short-term |  |  | 6,968 |  |  |  | — |  |
| Other current liabilities |  |  | 17,031 |  |  |  | 15,206 |  |
| Total current liabilities |  |  | 60,162 |  |  |  | 37,801 |  |
| Long–term deferred tax liabilities |  |  | — |  |  |  | 1,870 |  |
| Debt – long-term |  |  | 22,623 |  |  |  | — |  |
| Other long–term liabilities |  |  | — |  |  |  | 32 |  |
| Total liabilities |  |  | 82,785 |  |  |  | 39,703 |  |
| Redeemable convertible preferred stock |  |  | — |  |  |  | 145,847 |  |
| Stockholders’ deficit: |  |  |  |  |  |  |  |  |
| Common stock |  |  | 92 |  |  |  | 63 |  |
| Additional paid–in capital |  |  | 128,981 |  |  |  | 545 |  |
| Treasury stock |  |  | (69,515 | ) |  |  | (69,515 | ) |
| Retained earnings |  |  | 71,393 |  |  |  | 15,035 |  |
| Total stockholders’ deficit |  |  | 130,951 |  |  |  | (53,872 | ) |
| Total liabilities, convertible preferred stock and stockholders’ deficit |  | $ | 213,736 |  |  | $ | 131,678 |  |

[0001193125-12-347732:8k_2_02:66]
| (1) | Derived from audited consolidated statements as of and for the year ended June 30, 2011. |

[0001193125-12-347732:8k_2_02:67]
7

[0001193125-12-347732:8k_2_02:68]
Ubiquiti Networks Inc.

[0001193125-12-347732:8k_2_02:69]
Revenue by Product Category and Geographical Area

[0001193125-12-347732:8k_2_02:70]
(In thousands)

[0001193125-12-347732:8k_2_02:71]
(Unaudited)

[0001193125-12-347732:8k_2_02:72]
|  |  | Three Months Ended June 30, |  |  | Years Ended June 30, |  |
|  |  | 2012 |  |  | 2011 |  |  | 2012 |  |  | 2011 |  |
| Revenue by Product Category |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| AirMax |  | $ | 58,991 |  |  | $ | 41,960 |  |  | $ | 223,743 |  |  | $ | 113,001 |  |
| New platforms |  |  | 12,591 |  |  |  | 1,583 |  |  |  | 29,465 |  |  |  | 2,513 |  |
| Other systems |  |  | 10,759 |  |  |  | 11,339 |  |  |  | 52,086 |  |  |  | 44,884 |  |
| Systems |  |  | 82,341 |  |  |  | 54,882 |  |  |  | 305,294 |  |  |  | 160,398 |  |
| Embedded radio |  |  | 2,032 |  |  |  | 4,093 |  |  |  | 10,056 |  |  |  | 14,762 |  |
| Antennas/other |  |  | 10,495 |  |  |  | 8,579 |  |  |  | 38,167 |  |  |  | 22,714 |  |
| Total revenues |  | $ | 94,868 |  |  | $ | 67,554 |  |  | $ | 353,517 |  |  | $ | 197,874 |  |
| Revenue by Geographical Area |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| North America |  | $ | 25,281 |  |  | $ | 22,010 |  |  | $ | 88,309 |  |  | $ | 61,920 |  |
| South America |  |  | 16,574 |  |  |  | 18,278 |  |  |  | 88,325 |  |  |  | 50,824 |  |
| Europe, the Middle East and Africa |  |  | 38,957 |  |  |  | 21,866 |  |  |  | 130,494 |  |  |  | 68,297 |  |
| Asia Pacific |  |  | 14,056 |  |  |  | 5,400 |  |  |  | 46,389 |  |  |  | 16,833 |  |
| Total revenues |  | $ | 94,868 |  |  | $ | 67,554 |  |  | $ | 353,517 |  |  | $ | 197,874 |  |

[0001193125-12-347732:8k_2_02:73]
About our Non-GAAP Net Income and Adjustments

[0001193125-12-347732:8k_2_02:74]
Use of Non-GAAP Financial Information

[0001193125-12-347732:8k_2_02:75]
To supplement our condensed consolidated financial results prepared under generally accepted accounting principles, or GAAP, we use non-GAAP measures of
net income and earnings per diluted share that are GAAP net income and GAAP earnings per diluted share adjusted to exclude certain recurring costs, expenses and gains.

[0001193125-12-347732:8k_2_02:76]
We believe that the presentation of non-GAAP net income and non-GAAP earnings per diluted share provides important supplemental information regarding non-cash expenses, significant recurring items that we
believe are important to understanding our financial, and business trends relating to our financial condition and results of operations. Non-GAAP net income and non-GAAP earnings per diluted share are among the primary indicators used by management
as a basis for planning and forecasting future periods and by management and our board of directors to determine whether our operating performance has met specified targets and thresholds. Management uses non-GAAP net income and non-GAAP earnings
per diluted share when evaluating operating performance because it believes that the exclusion of the items described below, for which the amounts and/or timing may vary significantly depending upon the Company’s activities and other factors,
facilitates comparability of the Company’s operating performance from period to period. We have chosen to provide this information to investors so they can analyze our operating results in the same way that management does and use this
information in their assessment of our business and the valuation of our Company.

[0001193125-12-347732:8k_2_02:77]
Use and Economic Substance of Non-GAAP Financial
Measures used by Ubiquiti Networks

[0001193125-12-347732:8k_2_02:78]
We compute non-GAAP net income and non-GAAP dilutedearnings per share by adjusting GAAP net income and
GAAP earnings per diluted share to remove the impact of recurring stock-based compensation expense, income from a coexistence licensing agreement and the tax effect of these adjustments. In addition, our non-GAAP diluted earnings per share is
calculated using weighted-average shares outstanding as if Series A preferred stock outstanding had been converted to common stock throughout the periods presented. Examples of items excluded from net income are:

[0001193125-12-347732:8k_2_02:79]
|  | • |  | Recurring charges and gains, including: |

[0001193125-12-347732:8k_2_02:80]
|  | • |  | Stock-based compensation expense is recognized in accordance with FASB Accounting Standards Codification, Topic 718, Stock Compensation. |

[0001193125-12-347732:8k_2_02:81]
|  | • |  | Income from a coexistence licensing agreement |

[0001193125-12-347732:8k_2_02:82]
|  | • |  | Tax effect of non-GAAP adjustments. After adjusting to exclude the items described above, we apply the principles of ASC 740, Income Taxes, to estimate the non-GAAP income tax provision. |

[0001193125-12-347732:8k_2_02:83]
Usefulness of Non-GAAP Financial Information to Investors

[0001193125-12-347732:8k_2_02:84]
These non-GAAP measures are not in accordance with or an alternative to GAAP and may be materially different from other non-GAAP measures, including
similarly titled non-GAAP measures, used by other companies. The presentation of this additional information should not be considered in isolation from, as a substitute for, or superior to, net income or earnings per diluted share prepared in
accordance with GAAP. Non-GAAP financial measures have limitations in that they do not reflect certain items that may have a material impact upon our reported financial results. We expect to continue to incur expenses of a nature similar to the
non-GAAP adjustments described above, and exclusion of these items from our non-GAAP net income and non-GAAP earnings per diluted share should not be construed as an inference that these costs are unusual, infrequent or non-recurring.

[0001193125-12-347732:8k_2_02:85]
For more information on the non-GAAP adjustments, please see the tables captioned “Reconciliation of GAAP Net Income to non-GAAP Net Income”
and “Reconciliation of Weighted-Average Shares Used in Computing Net Income (Loss) Per Share of Common Stock-Diluted to Weighted-Average Shares Used In Computing Non-GAAP Diluted EPS”included in this press release.
