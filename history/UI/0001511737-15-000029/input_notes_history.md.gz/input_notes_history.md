# UI note change history — 0001511737-15-000018 → 0001511737-15-000029


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2015-11-05):
[0001511737-15-000029:note_history:1]
At September 30, 2015, future minimum annual payments under operating leases for the remainder of fiscal 2016 and future fiscal years are as follows (in thousands):
  (was, 2015-05-07, similarity 0.746):
[0001511737-15-000018:note_history:1]
At March 31, 2015, future minimum annual payments under operating leases are as follows (in thousands):

- changed (2015-11-05):
[0001511737-15-000029:note_history:2]
The Company primarily subcontracts with other companies to manufacture its products. During the normal course of business, the Company’s contract manufacturers procure components based upon orders placed by the Company. If the Company cancels all or part of the orders, it may still be liable to the contract manufacturers for the cost of the components purchased by them to manufacture the Company’s products. The Company periodically reviews the potential liability, and to date, no significant accruals have been recorded.  The Company had inventory purchase obligations of $11.6 million as of September 30, 2015.
  (was, 2015-05-07, similarity 0.9668):
[0001511737-15-000018:note_history:2]
The Company primarily subcontracts with other companies to manufacture its products. During the normal course of business, the Company’s contract manufacturers procure components based upon orders placed by the Company. If the Company cancels all or part of the orders, it may still be liable to the contract manufacturers for the cost of the components purchased by them to manufacture the Company’s products. The Company periodically reviews the potential liability and to date no significant accruals have been recorded.  The Company had inventory purchase obligations of $12.8 million as of March 31, 2015.

- changed (2015-11-05):
[0001511737-15-000029:note_history:3]
The Company had other obligations of $6.1 million as of September 30, 2015, which consisted primarily of commitments related to research and development projects.
  (was, 2015-05-07, similarity 0.9671):
[0001511737-15-000018:note_history:3]
The Company had other obligations of $4.6 million as of March 31, 2015, which consisted primarily of commitments related to research and development projects.


## us-gaap:BusinessDescriptionAndBasisOfPresentationTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2015-11-05):
[0001511737-15-000029:note_history:4]
Business— Ubiquiti Networks, Inc. was incorporated in the State of California in 2003 as Pera Networks, Inc.  In 2005 Pera Networks, Inc. changed its name to Ubiquiti Networks, Inc. and commenced its current operations. In June 2010, Ubiquiti Networks, Inc. was re-incorporated in Delaware.
  (was, 2015-05-07, similarity 0.7732):
[0001511737-15-000018:note_history:4]
Business— Ubiquiti Networks, Inc. was incorporated in the State of California in 2003 as Pera Networks, Inc.  In 2005 the Company changed its name to Ubiquiti Networks, Inc. and commenced its current operations. In June 2010, the Company was re-incorporated in Delaware.

- changed (2015-11-05):
[0001511737-15-000029:note_history:5]
These condensed consolidated financial statements should be read in conjunction with the Company’s audited consolidated financial statements for the fiscal year ended June 30, 2015, included in its Annual Report on Form 10-K, as filed with the SEC on August 21, 2015 (the “Annual Report”). The results of operations for the three months ended September 30, 2015 are not necessarily indicative of the results to be expected for any future periods.
  (was, 2015-05-07, similarity 0.7486):
[0001511737-15-000018:note_history:5]
These condensed consolidated financial statements should be read in conjunction with the Company’s audited consolidated financial statements for the fiscal year ended June 30, 2014, included in its Annual Report on Form 10-K, as filed on August 22, 2014, with the SEC (the “Annual Report”). The results of operations for the three and nine months ended March 31, 2015, are not necessarily indicative of the results to be expected for any future periods.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2015-11-05):
[0001511737-15-000029:note_history:6]
The Company’s significant accounting policies are disclosed in its audited consolidated financial statements for the year ended June 30, 2015 included in the Annual Report.   Except as noted below, there have been no changes to the Company’s significant accounting policies as discussed in the Annual Report.
  (was, 2015-05-07, similarity 0.9967):
[0001511737-15-000018:note_history:6]
The Company’s significant accounting policies are disclosed in its audited consolidated financial statements for the year ended June 30, 2014 included in the Annual Report.   Except as noted below, there have been no changes to the Company's significant accounting policies as discussed in the Annual Report.

- changed (2015-11-05):
[0001511737-15-000029:note_history:7]
Capitalized Manufacturing Overhead Costs
  (was, 2015-05-07, similarity 0.6154):
[0001511737-15-000018:note_history:7]
Capitalized Software Development Costs

- added (2015-11-05):
[0001511737-15-000029:note_history:8]
In fiscal 2016, the Company began capitalizing manufacturing overhead expenditures as part of inventory costs.  Capitalized costs primarily include management’s best estimate of the direct labor and materials costs related to inventory produced but not sold during the period.  During the three months ended September 30, 2015, the Company capitalized $944 thousand of manufacturing overhead costs, which are included in inventory on the Company’s condensed consolidated balance sheet as of September 30, 2015.

- added (2015-11-05):
[0001511737-15-000029:note_history:9]
An entity should disclose sufficient information to enable users of financial statements to understand the nature, amount, timing, and uncertainty of revenue and cash flows arising from contracts with customers. Qualitative and quantitative information is required about contracts with customers, significant judgments and any assets recognized from the costs to obtain or fulfill a contract.   The guidance was initially effective for annual and interim reporting periods beginning after December 15, 2016.  However, in April 2015, the FASB issued a proposal to defer the effective date by one year, to December 15, 2017, to provide adequate time to effectively implement the new standard.  The Company does not anticipate that the new guidance will have a material impact on its consolidated financial statements.

- changed (2015-11-05):
[0001511737-15-000029:note_history:10]
In April 2015, the FASB issued an accounting standard update on simplifying the presentation of debt issuance costs.  The updated guidance requires that debt issuance costs related to a recognized debt liability be presented in the balance sheet as a direct deduction from the carrying amount of that debt liability, consistent with debt discounts. The recognition and measurement guidance for debt issuance costs are not affected by the updated guidance.  The guidance will be effective for the Company beginning July 1, 2016.  The guidance will result only in a reclassification on the Company’s balance sheet and is not expected to have any effect on the Company’s operating results.
  (was, 2015-05-07, similarity 0.997):
[0001511737-15-000018:note_history:10]
In April 2015, the FASB issued an accounting standard update on simplifying the presentation of debt issuance costs.  The updated guidance requires that debt issuance costs related to a recognized debt liability be presented in the balance sheet as a direct deduction from the carrying amount of that debt liability, consistent with debt discounts. The recognition and measurement guidance for debt issuance costs are not affected by the updated guidance.  The guidance will be effective for the Company beginning July 1, 2016.  The guidance will result only in a reclassification on the Company's balance sheet and is not expected to have any effect on the Company's operating results.

- added (2015-11-05):
[0001511737-15-000029:note_history:11]
Additionally, in July 2015, the FASB issued Accounting Standards Update (ASU) 2015-11 which explains how the Accounting Standards Codification will be updated to simplify the measurement of inventory costs.  The updated guidance requires that inventory be valued at the lower of cost or net realizable value.  This differs from current guidance which requires that inventory be valued at the lower of cost or market, where market can be replacement cost, net realizable value or net realizable value less an approximately normal profit margin.  The guidance will be effective for the Company beginning July 1, 2016.  We do not anticipate that this guidance will have a material impact on the presentation of the Company’s consolidated financial statements.

- removed (2015-11-05):
[0001511737-15-000018:note_history:12]
The Company capitalizes certain costs of software developed for internal use.  Capitalized costs primarily include payroll and payroll-related costs and facilities costs. The cost of internally developed software is amortized on a straight-line basis over its estimated useful life, typically three (3) to five (5) years.  During the three and nine months ended March 31, 2015, the Company capitalized $1.5 million and $3.0 million of software development costs, respectively, which is included as property and equipment in the Company's balance sheet as of  March 31, 2015.

- removed (2015-11-05):
[0001511737-15-000018:note_history:13]
An entity should disclose sufficient information to enable users of financial statements to understand the nature, amount, timing, and uncertainty of revenue and cash flows arising from contracts with customers. Qualitative and quantitative information is required about contracts with customers, significant judgments and any assets recognized from the costs to obtain or fulfill a contract.   The guidance will be effective for annual and interim reporting periods beginning after December 15, 2016.  However, in April 2015, the FASB issued a proposal to defer the effective date by one year, to December 15, 2017,  to provide adequate time to effectively implement the new standard.  The Company is currently assessing the impact of this new guidance.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2015-11-05):
[0001511737-15-000029:note_history:14]
On May 5, 2014, Ubiquiti Networks, Inc. and certain of its subsidiaries entered into a credit agreement (the “Original Credit Agreement”) with Wells Fargo Bank, National Association (“Wells Fargo”), the financial institutions named as lenders therein, and Wells Fargo as administrative agent for the lenders, that provided for a $150.0 million senior secured revolving credit facility, with an option to request an increase in the amount of the credit facility by up to an additional $50.0 million (any such increase to be in each lender’s sole discretion).  Proceeds from borrowings under the Original Credit Agreement were used to repay the Loan Agreement in full.
  (was, 2015-05-07, similarity 0.8803):
[0001511737-15-000018:note_history:14]
On May 5, 2014, the Company and certain of its subsidiaries entered into a credit agreement (the “Original Credit Agreement”) with Wells Fargo Bank, National Association (“Wells Fargo”), the financial institutions named as lenders therein, and Wells Fargo as administrative agent for the lenders, that provided for a $150.0 million senior secured revolving credit facility, with an option to request an increase in the amount of the credit facility by up to an additional $50.0 million (any such increase to be in each lender’s sole discretion).

- changed (2015-11-05):
[0001511737-15-000029:note_history:15]
On March 3, 2015, Ubiquiti Networks, Inc. and Ubiquiti International Holding Company Limited (the “Cayman Borrower”) amended and restated the Original Credit Agreement (the "Amended Credit Agreement") with Wells Fargo, the other financial institutions named as lenders therein, and Wells Fargo as administrative agent for the lenders.  The Amended Credit Agreement provides for a $200.0 million senior secured revolving credit facility and a $100.0 million senior secured term loan facility (collectively, the "Facilities"), with an option to request increases in the amounts of such credit facilities by up to an additional $50.0 million in the aggregate (any such increase to be in each lender’s sole discretion), and matures on March 3, 2020.  The $100.0 million term loan facility of the Amended Credit Agreement was fully drawn at closing, and $72.3 million was used to repay the outstanding balance under the Original Credit Agreement.  As of September 30, 2015, $95 million was outstanding on the term loan and $0 on the revolver.  Subsequent to September 30, 2015, the Company drew $33 million on the revolver.
  (was, 2015-05-07, similarity 0.8226):
[0001511737-15-000018:note_history:15]
On March 3, 2015, the Company and Ubiquiti International Holding Company Limited (the “Cayman Borrower”) amended and restated the Original Credit Agreement (the "Amended Credit Agreement") with Wells Fargo, the other financial institutions named as lenders therein, and Wells Fargo as administrative agent for the lenders.  The Amended Credit Agreement provides for a $200.0 million senior secured revolving credit facility and a $100.0 million senior secured term loan facility (collectively, the "Facilities"), with an option to request increases in the amounts of such credit facilities by up to an additional $50.0 million in the aggregate (any such increase to be in each lender's sole discretion), and matures on March 3, 2020.  The term loan facility was fully drawn at closing,  $72.3 million of which was used to repay the outstanding balance under the Original Credit Agreement.

- changed (2015-11-05):
[0001511737-15-000029:note_history:16]
The revolving credit facility includes a sub-limit of $10.0 million for letters of credit and a sub-limit of $25.0 million for swingline loans. The Facilities replaced the Company’s $150.0 million senior secured revolving credit facility under the Original Credit Agreement. The Facilities are available for working capital and general corporate purposes that comply with the terms of the Amended Credit Agreement. Under the Amended Credit Agreement, revolving loans and swingline loans may be borrowed, repaid and reborrowed until March 3, 2020, at which time all amounts borrowed must be repaid. The term loan is payable in quarterly installments of 2.50% of the original principal amount of the term loan until March 31, 2017, thereafter increasing to 3.75% of the original principal amount of the term loan, in each case plus accrued and unpaid interest. Revolving, swingline and term loans may be prepaid at any time without penalty. Revolving and term loans bear interest, at the Company’s option, at either (i) a floating rate per annum equal to the base rate plus a margin of between 0.50% and 1.25%, depending on the Company’s leverage ratio as of the most recently ended fiscal quarter or (ii) a floating per annum rate equal to the applicable LIBOR rate for a specified period, plus a margin of between 1.50% and 2.25%, depending on the Company’s leverage ratio as of the most recently ended fiscal quarter. Swingline loans bear interest at a floating rate per annum equal to the base rate plus a margin of between 0.50% and 1.25%, depending on the Company’s leverage ratio as of the most recently ended fiscal quarter. Base rate is defined as the greatest of (A) Wells Fargo’s prime rate, (B) the federal funds rate plus 0.50% or (C) the applicable LIBOR rate for a period of one month plus 1.00%. A default interest rate shall apply on all obligations during certain events of default under the Amended Credit Agreement at a rate per annum equal to 2.00% above the applicable interest rate. The Company will pay to each lender a facility fee on a quarterly basis based on the unused amount of each lender’s commitment to make revolving loans, of between 0.20% and 0.35%, depending on the Company’s leverage ratio as of the most recently ended fiscal quarter. The Company will also pay to the applicable lenders on a quarterly basis certain fees based on the daily amount available to be drawn under each outstanding letter of credit, including aggregate letter of credit commissions of the LIBOR rate plus a margin of between 1.50% and 2.25%, depending on the Company’s leverage ratio as of the most recently ended fiscal quarter, and issuance fees of 0.125% per annum. The Company is also obligated to pay Wells Fargo, as agent, fees customary for a credit facility of this size and type.
  (was, 2015-05-07, similarity 0.9908):
[0001511737-15-000018:note_history:16]
The revolving credit facility includes a sub-limit of $10.0 million for letters of credit and a sub-limit of $25.0 million for swingline loans. The Facilities replaced the Company's $150.0 million senior secured revolving credit facility under the Original Credit Agreement. The Facilities are available for working capital and general corporate purposes that comply with the terms of the Amended Credit Agreement. Under the Amended Credit Agreement, revolving loans and swingline loans may be borrowed, repaid and reborrowed until March 3, 2020, at which time all amounts borrowed must be repaid. The term loan is payable in quarterly installments of 2.50% of the original principal amount of the term loan until March 31, 2017, thereafter increasing to 3.75% of the original principal amount of the term loan, in each case plus accrued and unpaid interest. Revolving, swingline and term loans may be prepaid at any time without penalty. Revolving and term loans bear interest, at the Company's option, at either (i) a floating rate per annum equal to the base rate plus a margin of between 0.50% and 1.25%, depending on the Company's leverage ratio as of the most recently ended fiscal quarter or (ii) a floating per annum rate equal to the applicable LIBOR rate for a specified period, plus a margin of between 1.50% and 2.25%, depending on the Company's leverage ratio as of the most recently ended fiscal quarter. Swingline loans bear interest at a floating rate per annum equal to the base rate plus a margin of between 0.50% and 1.25%, depending on the Company's leverage ratio as of the most recently ended fiscal quarter. Base rate is defined as the greatest of (A) Wells Fargo's prime rate, (B) the federal funds rate plus 0.50% or (C) the applicable LIBOR rate for a period of one month plus 1.00%. A default interest rate shall apply on all obligations during certain events of default under the Amended Credit Agreement at a rate per annum equal to 2.00% above the applicable interest rate. The Company will pay to each lender a facility fee on a quarterly basis based on the unused amount of each lender's commitment to make revolving loans, of between 0.20% and 0.35%, depending on the Company's leverage ratio as of the most recently ended fiscal quarter. The Company will also pay to the applicable lenders on a quarterly basis certain fees based on the daily amount available to be drawn under each outstanding letter of credit, including aggregate letter of credit commissions of between 1.50% and 2.25%, depending on the Company's leverage ratio as of the most recently ended fiscal quarter, and issuance fees of 0.125% per annum. The Company is also obligated to pay Wells Fargo, as agent, fees customary for a credit facility of this size and type.

- changed (2015-11-05):
[0001511737-15-000029:note_history:17]
The obligations of Ubiquiti Networks, Inc. and certain domestic subsidiaries, if any, under the Amended Credit Agreement are required to be guaranteed by such domestic subsidiaries (the "Domestic Guarantors") and are collateralized by substantially all assets (excluding intellectual property) of Ubiquiti Networks, Inc. and the Domestic Guarantors. The obligations of the Cayman Borrower and certain foreign subsidiaries under the Amended Credit Agreement are required to be guaranteed by certain domestic and material foreign subsidiaries (the "Guarantors") and are collateralized by substantially all assets (excluding intellectual property) of the Cayman Borrower and the Guarantors.
  (was, 2015-05-07, similarity 0.9344):
[0001511737-15-000018:note_history:17]
The obligations of the Company and certain domestic subsidiaries, if any, under the Amended Credit Agreement are required to be guaranteed by such domestic subsidiaries (the "Domestic Guarantors") and are collateralized by substantially all assets (excluding intellectual property) of the Company and the Domestic Guarantors. The obligations of the Cayman Borrower and certain foreign subsidiaries under the Amended Credit Agreement are required to be guaranteed by certain domestic and material foreign subsidiaries (the "Guarantors") and are collateralized by substantially all assets (excluding intellectual property) of the Company and the Guarantors.

- added (2015-11-05):
[0001511737-15-000029:note_history:18]
During the three months ended September 30, 2015, the Company made a payment of $2.9 million against the term loan facility balance under the Amended Credit Agreement, of which $2.5 million was a repayment of principal and $444 thousand was payment of interest.  As of September 30, 2015, the Company has classified $10.0 million and $85.0 million as short-term and long-term debt, respectively, on its consolidated balance sheet related to the term loan facility under the Amended Credit Agreement.

- added (2015-11-05):
[0001511737-15-000029:note_history:19]
On September 2, 2015, the Company accessed a letter of credit under its revolving credit facility in the amount of $237 thousand for the benefit of the landlord pursuant to a new lease of office space. The landlord can draw against the letter of credit in the event of default by the Company. The letter of credit expires on September 2, 2016, subject to automatic renewal for additional one-year periods.

- changed (2015-11-05):
[0001511737-15-000029:note_history:20]
The following table summarizes our estimated debt and interest payment obligations as of September 30, 2015 for the remainder of fiscal 2016 and future fiscal years (in thousands):
  (was, 2015-05-07, similarity 0.7762):
[0001511737-15-000018:note_history:20]
The following table summarizes our estimated debt and interest payment obligations as of March 31, 2015 (in thousands):

- changed (2015-11-05):
[0001511737-15-000029:note_history:21]
|  | 2016 (remainder) |  | 2017 |  | 2018 |  | 2019 |  | 2020 |  | Thereafter |  | Total |
| Debt payment obligations | $ | 7,500 |  |  | $ | 11,250 |  |  | $ | 15,000 |  |  | $ | 15,000 |  |  | $ | 46,250 |  |  | $ | — |  |  | $ | 95,000 |  |
| Interest and other payments on debt payment obligations | 1,521 |  |  | 1,893 |  |  | 1,659 |  |  | 1,392 |  |  | 818 |  |  | — |  |  | 7,283 |  |
| Total | $ | 9,021 |  |  | $ | 13,143 |  |  | $ | 16,659 |  |  | $ | 16,392 |  |  | $ | 47,068 |  |  | $ | — |  |  | $ | 102,283 |  |
  (was, 2015-05-07, similarity 0.9506):
[0001511737-15-000018:note_history:21]
|  | 2015 (remainder) |  | 2016 |  | 2017 |  | 2018 |  | 2019 |  | Thereafter |  | Total |
| Debt payment obligations | $ | 2,500 |  |  | $ | 10,000 |  |  | $ | 11,250 |  |  | $ | 15,000 |  |  | $ | 15,000 |  |  | $ | 46,250 |  |  | $ | 100,000 |  |
| Interest and other payments on debt payment obligations | 674 |  |  | 2,057 |  |  | 1,876 |  |  | 1,645 |  |  | 1,380 |  |  | 812 |  |  | 8,444 |  |
| Total | $ | 3,174 |  |  | $ | 12,057 |  |  | $ | 13,126 |  |  | $ | 16,645 |  |  | $ | 16,380 |  |  | $ | 47,062 |  |  | $ | 108,444 |  |

- removed (2015-11-05):
[0001511737-15-000018:note_history:22]
No payments were made during the three or nine months ended March 31, 2015 against the term loan balance under the Amended Credit Agreement.  During the three and nine months ended March 31, 2014, the Company made aggregate payments of $1.3 million and $3.8 million, respectively, against the loan balance under the Original Credit Agreement.  As of March 31, 2015, the Company has classified $10.0 million and $90.0 million of short term and long-term debt, respectively, on its consolidated balance sheet related to the Amended Credit Agreement.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2015-11-05):
[0001511737-15-000029:note_history:23]
The following table summarizes our estimated debt and interest payment obligations as of September 30, 2015 for the remainder of fiscal 2016 and future fiscal years (in thousands):
  (was, 2015-05-07, similarity 0.7762):
[0001511737-15-000018:note_history:23]
The following table summarizes our estimated debt and interest payment obligations as of March 31, 2015 (in thousands):

- changed (2015-11-05):
[0001511737-15-000029:note_history:24]
|  | 2016 (remainder) |  | 2017 |  | 2018 |  | 2019 |  | 2020 |  | Thereafter |  | Total |
| Debt payment obligations | $ | 7,500 |  |  | $ | 11,250 |  |  | $ | 15,000 |  |  | $ | 15,000 |  |  | $ | 46,250 |  |  | $ | — |  |  | $ | 95,000 |  |
| Interest and other payments on debt payment obligations | 1,521 |  |  | 1,893 |  |  | 1,659 |  |  | 1,392 |  |  | 818 |  |  | — |  |  | 7,283 |  |
| Total | $ | 9,021 |  |  | $ | 13,143 |  |  | $ | 16,659 |  |  | $ | 16,392 |  |  | $ | 47,068 |  |  | $ | — |  |  | $ | 102,283 |  |
  (was, 2015-05-07, similarity 0.9506):
[0001511737-15-000018:note_history:24]
|  | 2015 (remainder) |  | 2016 |  | 2017 |  | 2018 |  | 2019 |  | Thereafter |  | Total |
| Debt payment obligations | $ | 2,500 |  |  | $ | 10,000 |  |  | $ | 11,250 |  |  | $ | 15,000 |  |  | $ | 15,000 |  |  | $ | 46,250 |  |  | $ | 100,000 |  |
| Interest and other payments on debt payment obligations | 674 |  |  | 2,057 |  |  | 1,876 |  |  | 1,645 |  |  | 1,380 |  |  | 812 |  |  | 8,444 |  |
| Total | $ | 3,174 |  |  | $ | 12,057 |  |  | $ | 13,126 |  |  | $ | 16,645 |  |  | $ | 16,380 |  |  | $ | 47,062 |  |  | $ | 108,444 |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- added (2015-11-05):
[0001511737-15-000029:note_history:25]
Aircraft Lease Agreement

- changed (2015-11-05):
[0001511737-15-000029:note_history:26]
On November 13, 2013, the Company entered into an aircraft lease agreement (the "Aircraft Lease Agreement") with RJP Manageco LLC (the "Lessor"), a limited liability company owned by the Company’s CEO, Robert J. Pera. Pursuant to the Aircraft Lease Agreement, the Company may lease an aircraft owned by the Lessor for Company business purposes. Under the Aircraft Lease Agreement, the aircraft may be leased at a rate of $5,000 per flight hour. This hourly rate does not include the cost of flight crew or on-board services, which the Company purchases from a third-party provider. The Company recognized a total of approximately $213 thousand in expenses pursuant to the Aircraft Lease Agreement during the three months ended September 30, 2015.  All expenses pursuant to the Aircraft Lease Agreement have been included in the Company’s sales, general and administrative expenses in the Condensed Consolidated Statements of Operations.
  (was, 2015-05-07, similarity 0.7468):
[0001511737-15-000018:note_history:26]
On November 13, 2013, the Company entered into an aircraft lease agreement (the "Aircraft Lease Agreement") with RJP Manageco LLC (the "Lessor"), a limited liability company owned by the Company’s CEO, Robert J. Pera. Pursuant to the Aircraft Lease Agreement, the Company may lease an aircraft owned by the Lessor for Company business purposes. Under the Aircraft Lease Agreement, the aircraft may be leased at a rate of $5,000 per flight hour. This hourly rate does not include the cost of flight crew or on-board services, which the Company will purchase from a third-party provider. The Company recognized a total of approximately $150,000 and $330,000 in expenses pursuant to the Aircraft Lease Agreement during the three and nine months ended March 31, 2015, respectively.  In comparison, the Company recognized a total of approximately $120,000 in expenses pursuant to the Aircraft Lease Agreement during the three months ended March 31, 2014.  All expenses pursuant to the Aircraft Lease Agreement have been included in the Company's sales, general and administrative expenses in the Condensed Consolidated Statements of Operations.
