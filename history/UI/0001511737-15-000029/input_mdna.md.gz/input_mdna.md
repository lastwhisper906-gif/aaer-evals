# UI MD&A — 0001511737-15-000029


## mdna

[0001511737-15-000029:mdna:1]
[same as prior period, unchanged from 0001511737-15-000018:mdna:1]

[0001511737-15-000029:mdna:2]
[same as prior period, unchanged from 0001511737-15-000018:mdna:2]

[0001511737-15-000029:mdna:3]
Ubiquiti Networks, Inc. develops high performance networking technology for service providers and enterprises. Our technology platforms focus on delivering highly-advanced and easily deployable solutions that appeal to a global customer base in underserved and underpenetrated markets. Our differentiated business model has enabled us to break down traditional barriers, such as high product and network deployment costs, and offer solutions with disruptive price-performance characteristics. This differentiated business model, combined with our innovative proprietary technologies, has resulted in an attractive alternative to traditional high touch, high cost providers, allowing us to advance the market adoption of our platforms for ubiquitous connectivity.

[0001511737-15-000029:mdna:4]
[same as prior period, unchanged from 0001511737-15-000018:mdna:4]

[0001511737-15-000029:mdna:5]
[same as prior period, unchanged from 0001511737-15-000018:mdna:5]

[0001511737-15-000029:mdna:6]
[same as prior period, unchanged from 0001511737-15-000018:mdna:6]

[0001511737-15-000029:mdna:7]
| • | Scalable sales and marketing model. We do not currently have, nor do we plan to hire, a direct sales force, but instead utilize the Ubiquiti Community to drive market awareness and demand for our products and solutions. This community-propagated, viral marketing enables us to reach underserved and underpenetrated markets far more efficiently and cost-effectively than is possible through traditional sales models. Leveraging the information transparency of the Internet allows customers to research, evaluate and validate our solutions with the Ubiquiti Community and via third party web sites. This allows us to operate a scalable sales and marketing model and effectively create awareness for our brand and products. Word of mouth referrals from the Ubiquiti Community generate high quality leads for our distributors at relatively little cost. |

[0001511737-15-000029:mdna:8]
[same as prior period, unchanged from 0001511737-15-000018:mdna:8]

[0001511737-15-000029:mdna:9]
[same as prior period, unchanged from 0001511737-15-000018:mdna:9]

[0001511737-15-000029:mdna:10]
[same as prior period, unchanged from 0001511737-15-000018:mdna:10]

[0001511737-15-000029:mdna:11]
[same as prior period, unchanged from 0001511737-15-000018:mdna:11]

[0001511737-15-000029:mdna:12]
[same as prior period, unchanged from 0001511737-15-000018:mdna:12]

[0001511737-15-000029:mdna:13]
[same as prior period, unchanged from 0001511737-15-000018:mdna:13]

[0001511737-15-000029:mdna:14]
| • | Service Provider Technology includes our airMAX, EdgeMAX and airFiber platforms, as well as embedded radio products and other 802.11 standard products including base stations, radios, backhaul equipment and CPE. Additionally, Service Provider Technology includes antennas and other products in the 0.9 to 6.0GHz spectrum and miscellaneous products such as mounting brackets, cables and power over Ethernet adapters. Service Provider Technology also includes revenues that are attributable to PCS. |

[0001511737-15-000029:mdna:15]
[same as prior period, unchanged from 0001511737-15-000018:mdna:15]

[0001511737-15-000029:mdna:16]
We sell substantially all of our products through a limited number of distributors and other channel partners, such as resellers and Original Equipment Manufacturers ("OEMs"). Sales to distributors accounted for 98% of our revenues in the three months ended September 30, 2015.

[0001511737-15-000029:mdna:17]
[same as prior period, unchanged from 0001511737-15-000018:mdna:17]

[0001511737-15-000029:mdna:18]
Our cost of revenues is comprised primarily of the costs of procuring finished goods from our contract manufacturers and chipsets that we consign to certain of our contract manufacturers. In addition, cost of revenues includes labor and other costs associated with engineering, including salary, benefits and stock-based compensation in addition to costs associated with tooling, testing and quality assurance, warranty fees, logistics fees and excess and obsolete inventory.

[0001511737-15-000029:mdna:19]
[same as prior period, unchanged from 0001511737-15-000018:mdna:19]

[0001511737-15-000029:mdna:20]
[same as prior period, unchanged from 0001511737-15-000018:mdna:21]

[0001511737-15-000029:mdna:21]
Our gross profit has been, and may in the future be, influenced by several factors, including changes in product mix, target end markets for our products, pricing due to competitive pressure, production costs and global demand for electronic components. Although we procure and sell our products in U.S. dollars, our contract manufacturers incur many costs, including labor costs, in other currencies. To the extent that the exchange rates move unfavorably for our contract manufacturers, they may try to pass these additional costs to us, which could have a material impact on our future average selling prices and unit costs.

[0001511737-15-000029:mdna:22]
[same as prior period, unchanged from 0001511737-15-000018:mdna:23]

[0001511737-15-000029:mdna:23]
[same as prior period, unchanged from 0001511737-15-000018:mdna:24]

[0001511737-15-000029:mdna:24]
[same as prior period, unchanged from 0001511737-15-000018:mdna:25]

[0001511737-15-000029:mdna:25]
| • | Sales, general and administrative expenses include salary and benefit expenses, including stock-based compensation, for employees and costs for contractors engaged in sales, marketing and general and administrative activities, as well as the costs of legal expenses, trade shows, marketing programs, promotional materials, bad debt expense, professional services, facilities, general liability insurance and travel. As our product portfolio and targeted markets expand, we may |

[0001511737-15-000029:mdna:26]
need to employ different sales models, such as building a direct sales force. These sales models would likely increase our costs. Over time, we expect our sales, general and administrative expenses to increase in absolute dollars due to continued growth in headcount, expansion of our efforts to register and defend trademarks and patents and to support our business and operations.

[0001511737-15-000029:mdna:27]
[same as prior period, unchanged from 0001511737-15-000018:mdna:27]

[0001511737-15-000029:mdna:28]
[same as prior period, unchanged from 0001511737-15-000018:mdna:28]

[0001511737-15-000029:mdna:29]
Included in our deferred revenues is a portion related to PCS obligations that we estimate we will fulfill in the future. As of September 30, 2015 and June 30, 2015, we had deferred revenues of $3.6 million and $3.5 million, respectively, related to these obligations.

[0001511737-15-000029:mdna:30]
[same as prior period, unchanged from 0001511737-15-000018:mdna:30]

[0001511737-15-000029:mdna:31]
We prepare our condensed consolidated financial statements in accordance with accounting principles generally accepted in the United States of America (“GAAP”). In many cases, the accounting treatment of a particular transaction is specifically dictated by GAAP and does not require management’s judgment in its application. In other cases, management’s judgment is required in selecting among available alternative accounting standards that provide for different accounting treatment for similar transactions. The preparation of condensed consolidated financial statements also requires us to make estimates and assumptions that affect the amounts we report as assets, liabilities, revenues, costs and expenses and affect the related disclosures. We base our estimates on historical experience and other assumptions that we believe are reasonable under the circumstances. In many instances, we could reasonably use different accounting estimates, and in some instances changes in the accounting estimates are reasonably likely to occur from period to period. Accordingly, our actual results could differ significantly from the estimates made by our management. To the extent that there are differences between our estimates and actual results, our future financial statement presentation, financial condition, results of operations and cash flows will be affected. Our critical accounting policies are discussed in our Annual Report, and there have been no material changes that have not been disclosed in Note 2 herein.

[0001511737-15-000029:mdna:32]
[same as prior period, unchanged from 0001511737-15-000018:mdna:33]

[0001511737-15-000029:mdna:33]
Comparison of Three Months Ended September 30, 2015 and 2014

[0001511737-15-000029:mdna:34]
|  | Three Months Ended September 30, |
|  | 2015 |  | 2014 |
|  | (In thousands, except percentages) |
| Revenues | $ | 151,415 |  |  | 100 | % |  | $ | 150,087 |  |  | 100 | % |
| Cost of revenues (1)(2)(3) | 77,911 |  |  | 51 | % |  | 89,036 |  |  | 59 | % |
| Gross profit | 73,504 |  |  | 49 | % |  | 61,051 |  |  | 41 | % |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development (1) | 13,561 |  |  | 9 | % |  | 11,721 |  |  | 8 | % |
| Sales, general and administrative (1) | 8,142 |  |  | 5 | % |  | 5,696 |  |  | 4 | % |
| Business e-mail compromise ("BEC") fraud loss/(recovery) | (8,034 | ) |  | (5 | )% |  | — |  |  | * |  |
| Total operating expenses | 13,669 |  |  | 9 | % |  | 17,417 |  |  | 12 | % |
| Income from operations | 59,835 |  |  | 40 | % |  | 43,634 |  |  | 29 | % |
| Interest expense and other, net | (116 | ) |  | * |  |  | (58 | ) |  | * |  |
| Income before provision for income taxes | 59,719 |  |  | 39 | % |  | 43,576 |  |  | 29 | % |
| Provision for income taxes | 5,960 |  |  | 4 | % |  | 5,833 |  |  | 4 | % |
| Net income and comprehensive income | $ | 53,759 |  |  | 36 | % |  | $ | 37,743 |  |  | 25 | % |
| * Less than 1% |  |  |  |  |  |  |  |
| (1) Includes stock-based compensation as follows: |  |  |  |  |  |  |  |
| Cost of revenues | $ | 113 |  |  |  |  | $ | 149 |  |  |  |
| Research and development | 624 |  |  |  |  | 825 |  |  |  |
| Sales, general and administrative | 290 |  |  |  |  | 398 |  |  |  |
| Total stock-based compensation | $ | 1,027 |  |  |  |  | $ | 1,372 |  |  |  |
| (2) Includes purchase commitment termination fee | $ | — |  |  |  |  | $ | 5,500 |  |  |  |
| (3) Includes benefit of implementing overhead capitalization | $ | (944 | ) |  |  |  | $ | — |  |  |  |

[0001511737-15-000029:mdna:35]
[same as prior period, unchanged from 0001511737-15-000018:mdna:36]

[0001511737-15-000029:mdna:36]
Total revenues increased $1.3 million, or 1%, from $150.1 million in the three months ended September 30, 2014 to $151.4 million in the three months ended September 30, 2015.   We believe the overall increase in revenues during the three months ended September 30, 2015 was driven by increased adoption of our enterprise technologies, partially offset by a decrease in sales of our service provider technologies due to lower demand in South America as a result of the strength of the U.S. Dollar during the fiscal quarter as compared to some of the currencies in this region.  Our average selling prices across all our product platforms remained relatively stable, decreasing by less than 5% year-over-year.

[0001511737-15-000029:mdna:37]
[same as prior period, unchanged from 0001511737-15-000018:mdna:38]

[0001511737-15-000029:mdna:38]
|  | Three Months Ended September 30, |
|  | 2015 |  | 2014 |
|  | (in thousands, except percentages) |
| Service Provider Technology | $ | 103,399 |  |  | 68 | % |  | $ | 107,271 |  |  | 71 | % |
| Enterprise Technology | 48,016 |  |  | 32 | % |  | 42,816 |  |  | 29 | % |
| Total revenues | $ | 151,415 |  |  | 100 | % |  | $ | 150,087 |  |  | 100 | % |

[0001511737-15-000029:mdna:39]
Revenues from Service Provider Technologies decreased $3.9 million, or 4%, from $107.3 million in the three months ended September 30, 2014 to $103.4 million in the three months ended September 30, 2015. Decreases in South America revenues drove the overall decrease in revenue for Service Provider Technologies.

[0001511737-15-000029:mdna:40]
Enterprise Technology revenues increased $5.2 million, or 12% from $42.8 million in the three months ended September 30, 2014 to $48.0 million in the three months ended September 30, 2015.  The increase in Enterprise Technology revenues during

[0001511737-15-000029:mdna:41]
the three months ended September 30, 2015 was due primarily to continued product expansion and further adoption of our UniFi technology platform in the EMEA region.

[0001511737-15-000029:mdna:42]
[same as prior period, unchanged from 0001511737-15-000018:mdna:43]

[0001511737-15-000029:mdna:43]
We have determined the geographical distribution of our product revenues based on our customers’ ship-to destinations. A majority of our sales are to distributors who in turn sell to resellers or directly to end customers, which may be different countries than the initial ship-to destination.  The following are our revenues by geography for the three months ended September 30, 2015 and 2014 (in thousands, except percentages):

[0001511737-15-000029:mdna:44]
|  | Three Months Ended September 30, |
|  | 2015 |  | 2014 |
| North America (1) | $ | 53,234 |  |  | 35 | % |  | $ | 53,582 |  |  | 35 | % |
| South America | 22,148 |  |  | 15 | % |  | 31,134 |  |  | 21 | % |
| Europe, the Middle East and Africa | 60,503 |  |  | 40 | % |  | 50,607 |  |  | 34 | % |
| Asia Pacific | 15,530 |  |  | 10 | % |  | 14,764 |  |  | 10 | % |
| Total revenues | $ | 151,415 |  |  | 100 | % |  | $ | 150,087 |  |  | 100 | % |

[0001511737-15-000029:mdna:45]
| (1) | Revenue for the United States was $50.6 million and $52.0 million for the three months ended September 30, 2015 and 2014, respectively. |

[0001511737-15-000029:mdna:46]
[same as prior period, unchanged from 0001511737-15-000018:mdna:47]

[0001511737-15-000029:mdna:47]
Revenues in North America remained relatively flat overall, decreasing $0.4 million, or 1%, from $53.6 million in the three months ended September 30, 2014 to $53.2 million in the three months ended September 30, 2015.

[0001511737-15-000029:mdna:48]
[same as prior period, unchanged from 0001511737-15-000018:mdna:49]

[0001511737-15-000029:mdna:49]
Revenues in South America decreased $9.0 million, or 29%, from $31.1 million in the three months ended September 30, 2014 to $22.1 million in the three months ended September 30, 2015.  We believe the decrease in revenues in South America in the  three months ended September 30, 2015 as compared to the same period in the prior year was primarily due to decreased demand for our Service Provider Technologies due in part to economic instability and partially as a result of a strong U.S. Dollar.

[0001511737-15-000029:mdna:50]
Europe, the Middle East, and Africa (EMEA)

[0001511737-15-000029:mdna:51]
Revenues in EMEA increased $9.9 million, or 20%, from $50.6 million in the three months ended September 30, 2014 to $60.5 million in the three months ended September 30, 2015. The increase in revenues in EMEA in the three months ended September 30, 2015 as compared to the same period in the prior year was primarily due to increased demand for both our Service Provider and Enterprise Technologies.

[0001511737-15-000029:mdna:52]
[same as prior period, unchanged from 0001511737-15-000018:mdna:53]

[0001511737-15-000029:mdna:53]
Revenues in the Asia Pacific region remained relatively flat overall, increasing $0.7 million, or 5%, from $14.8 million for the three months ended September 30, 2014 to $15.5 million for the three months ended September 30, 2015.

[0001511737-15-000029:mdna:54]
[same as prior period, unchanged from 0001511737-15-000018:mdna:55]

[0001511737-15-000029:mdna:55]
Cost of revenues decreased $11.1 million, or 12%, from $89.0 million in the three months ended September 30, 2014 to $77.9 million in the three months ended September 30, 2015. The primary driver of the decrease in cost of revenues for the three months ended September 30, 2015 was due to overall product mix. The decrease in cost of revenues for the current period compared to the three month period ended September 30, 2014 was also driven by a non-recurring charge associated with a termination fee of $5.5 million for the cancellation of a purchase commitment during the prior three months ended September 30, 2014.  Additionally, as discussed further in Note 2, the Company capitalized approximately $944 thousand for manufacturing overhead related to inventory produced but not sold during the three months ended September 30, 2015, which had the effect of reducing costs of revenues for the quarter.

[0001511737-15-000029:mdna:56]
Gross profit increased to 49% in the three months ended September 30, 2015 compared to 41% in the three months ended September 30, 2014. The increase in gross profit during the three months ended September 30, 2015 was primarily due to changes in product mix in addition to the adjustments discussed above.

[0001511737-15-000029:mdna:57]
[same as prior period, unchanged from 0001511737-15-000018:mdna:58]

[0001511737-15-000029:mdna:58]
[same as prior period, unchanged from 0001511737-15-000018:mdna:59]

[0001511737-15-000029:mdna:59]
Research and development ("R&D") expenses increased $1.9 million, or 16%, from $11.7 million in the three months ended September 30, 2014 to $13.6 million in the three months ended September 30, 2015. As a percentage of revenues, research and development expenses increased from 8% in the three months ended September 30, 2014 to 9% in the three months ended September 30, 2015. The increase in research and development expenses in absolute dollars and as a percentage of revenues was due to increases in headcount to support our strategy as we broadened our research and development activities to new product areas and certain one-time costs incurred for IP purchased for use in our products. Over time, we expect our research and development costs to increase in absolute dollars as we continue making investments in developing new products and developing new versions of our existing products.

[0001511737-15-000029:mdna:60]
[same as prior period, unchanged from 0001511737-15-000018:mdna:61]

[0001511737-15-000029:mdna:61]
Sales, general and administrative expenses increased $2.4 million, or 42%, from $5.7 million in the three months ended September 30, 2014 to $8.1 million in the three months ended September 30, 2015.  As a percentage of revenues, sales, general and administrative expenses increased from 4% in the three months ended September 30, 2014 to 5% in the three months ended September 30, 2015.  The increase primarily relates to interim management and advisory services to remediate internal control weaknesses as disclosed in the Annual Report.

[0001511737-15-000029:mdna:62]
[same as prior period, unchanged from 0001511737-15-000018:mdna:63]

[0001511737-15-000029:mdna:63]
Our provision for income taxes increased $0.2 million, or 3%, from $5.8 million for the three months ended September 30, 2014 to $6.0 million for the three months ended September 30, 2015. Our effective tax rate decreased to 10% for the three months ended September 30, 2015 as compared to 13% for the three months ended September 30, 2014.  The lower effective tax rate in the three months ended September 30, 2015 was primarily due to an increased percentage of our overall profitability occurring in foreign jurisdictions, which have lower income tax rates.  This increase in the percentage of profits in foreign jurisdictions was driven in part by product mix and in part by the BEC recovery (See Note 14).

[0001511737-15-000029:mdna:64]
[same as prior period, unchanged from 0001511737-15-000018:mdna:65]

[0001511737-15-000029:mdna:65]
[same as prior period, unchanged from 0001511737-15-000018:mdna:66]

[0001511737-15-000029:mdna:66]
Since inception, our operations primarily have been funded through cash generated by operations and proceeds from our various debt agreements. Cash and cash equivalents decreased from $446.4 million at June 30, 2015 to $436.1 million at September 30, 2015.

[0001511737-15-000029:mdna:67]
[same as prior period, unchanged from 0001511737-15-000018:mdna:69]

[0001511737-15-000029:mdna:68]
[same as prior period, unchanged from 0001511737-15-000018:mdna:70]

[0001511737-15-000029:mdna:69]
|  | Three Months Ended September 30, |
|  | 2015 |  | 2014 |
|  | (In thousands) |
| Net cash provided by operating activities | $ | 47,727 |  |  | $ | 46,942 |  |
| Net cash used in investing activities | (1,830 | ) |  | (3,461 | ) |
| Net cash provided by (used in) financing activities | (56,218 | ) |  | 438 |  |
| Net increase (decrease) in cash and cash equivalents | $ | (10,321 | ) |  | $ | 43,919 |  |

[0001511737-15-000029:mdna:70]
[same as prior period, unchanged from 0001511737-15-000018:mdna:72]

[0001511737-15-000029:mdna:71]
Net cash provided by operating activities in the three months ended September 30, 2015 of $47.7 million consisted primarily of net income of $53.8 million partially offset by net changes in operating assets and liabilities that resulted in net cash outflows of $9.6 million. These changes consisted primarily of a $5.0 million increase in prepaid expenses and other current assets due to timing of deposit payments with our suppliers, a $2.5 million decrease in accounts receivable due to increased collections during the period, a $17.3 million decrease in accounts payable and accrued liabilities due primarily to an acceleration of payments in advance of a major holiday, a $0.1 million increase in deferred revenue due to additional PCS revenue deferrals during the period, a $2.6 million decrease in prepaid taxes due to the timing of federal tax payments, a $5.2 million decrease in inventory due to increased sales during the period and a $2.3 million increase in taxes payable.  Additionally, our net income included non-cash adjustments due to stock-based compensation, depreciation and amortization, increases to our provision for

[0001511737-15-000029:mdna:72]
21

[0001511737-15-000029:mdna:73]
inventory obsolescence, increases to our provision for sales returns, and increases in deferred taxes. The net of these non-cash adjustments resulted in an increase of our net cash provided by operating activities of $3.5 million.

[0001511737-15-000029:mdna:74]
Net cash provided by operating activities in the three months ended September 30, 2014 of $46.9 million consisted primarily of net income of $37.7 million and net changes in operating assets and liabilities that resulted in net cash inflows of $1.4 million. These changes consisted primarily of a $13.4 million increase in prepaid expenses and other current assets due to the timing of our payments and additional deposits with our suppliers, a $12.4 million increase in accounts payable and accrued liabilities are due primarily to our increase in cost of revenues, an $11.1 million increase in accounts receivable, a $6.9 million decrease in inventory due to our efforts to maintain optimal inventory levels and a $2.6 million increase in taxes payable due to the timing of federal tax payments.  Additionally, our net income included non-cash adjustments due to stock-based compensation, depreciation and amortization, increases to our provision for inventory obsolescence, a write-off of our intangible assets and an excess tax benefit from stock-based awards. The net of these non-cash adjustments resulted in an increase of our net cash provided by operating activities of $7.8 million.

[0001511737-15-000029:mdna:75]
[same as prior period, unchanged from 0001511737-15-000018:mdna:75]

[0001511737-15-000029:mdna:76]
We used $1.8 million of cash in investing activities during the three months ended September 30, 2015.  Our investing activities consist solely of capital expenditures and purchases of intangible assets. Capital expenditures for the three months ended September 30, 2015 and 2014 were $1.8 million and $3.4 million, respectively.  Capital expenditures during the three months ended September 30, 2015 included machinery and equipment purchases for our product development and prototyping facility in China in addition to internal-use software development costs. Additionally, we had cash outflows related to the purchase of intangible assets of $7 thousand and $30 thousand during the three months ended September 30, 2015 and 2014, respectively, consisting primarily of legal costs associated with trademark applications.

[0001511737-15-000029:mdna:77]
[same as prior period, unchanged from 0001511737-15-000018:mdna:77]

[0001511737-15-000029:mdna:78]
We used $56.2 million of cash in financing activities during the three months ended September 30, 2015.  During the three months ended September 30, 2015 we paid $53.8 million for repurchases of our common stock.  Additionally, we made a $2.5 million repayment on our outstanding debt under the term loan portion of our Amended Credit Agreement.  Cash inflows from financing activities included $0.3 million of cash proceeds received from the exercise of stock options in addition to $0.3 million of excess tax benefit from employee stock-based awards, partially offset by tax withholdings related to net share settlements of restricted stock units of $0.5 million.

[0001511737-15-000029:mdna:79]
We had $438 thousand of cash provided by financing activities during the three months ended September 30, 2014, which consisted of cash received for stock option exercises of $456 thousand and an excess tax benefit from employee stock-based awards of $782 thousand, partially offset by tax withholdings related to net share settlements of restricted stock units of $800 thousand.

[0001511737-15-000029:mdna:80]
[same as prior period, unchanged from 0001511737-15-000018:mdna:80]

[0001511737-15-000029:mdna:81]
We believe our existing cash and cash equivalents, cash provided by operations and the availability of additional funds under our Amended Credit Agreement will be sufficient to meet our working capital and capital expenditure needs for at least the next twelve months. Our future capital requirements may vary materially from those currently planned and will depend on many factors, including our rate of revenue growth, the timing and extent of spending to support development efforts, the timing of new product introductions, market acceptance of our products and overall economic conditions. As of September 30, 2015, we held $410.1 million of our $436.1 million of cash and cash equivalents in accounts of our subsidiaries outside of the United States and we will incur significant tax liabilities if we decide to repatriate those amounts.

[0001511737-15-000029:mdna:82]
[same as prior period, unchanged from 0001511737-15-000018:mdna:82]

[0001511737-15-000029:mdna:83]
Our products are generally accompanied by a twelve month warranty from date of purchase, which covers both parts and labor. Generally the distributor is responsible for the freight costs associated with warranty returns, and we absorb the freight costs of replacing items under warranty. In accordance with the Financial Accounting Standards Board’s (“FASB’s”), Accounting Standards Codification (“ASC”), 450-20, Loss Contingencies, we record an accrual when we believe it is reasonably estimable and probable based upon historical experience. We record a provision for estimated future warranty work in cost of goods sold upon recognition of revenues, and we review the resulting accrual regularly and periodically adjust it to reflect changes in warranty estimates.

[0001511737-15-000029:mdna:84]
We may in the future enter into standard indemnification agreements with many of our distributors and OEMs, as well as certain other business partners in the ordinary course of business. These agreements may include provisions for indemnifying the distributor, OEM or other business partner against any claim brought by a third party to the extent any such claim alleges

[0001511737-15-000029:mdna:85]
that a Ubiquiti product infringes a patent, copyright or trademark or violates any other proprietary rights of that third party. The maximum amount of potential future indemnification is unlimited. The maximum potential amount of future payments we could be required to make under these indemnification agreements is not estimable.

[0001511737-15-000029:mdna:86]
We have agreed to indemnify our directors, officers and certain other employees for certain events or occurrences, subject to certain limits, while such persons are or were serving at our request in such capacity. We may terminate the indemnification agreements with these persons upon the termination of their services with us, but termination will not affect claims for indemnification related to events occurring prior to the effective date of termination. The maximum amount of potential future indemnification is unlimited. We have a Directors and Officers insurance policy that limits our potential exposure. We believe the fair value of these indemnification agreements is minimal.  We have not recorded any liabilities for these agreements as of September 30, 2015.

[0001511737-15-000029:mdna:87]
Based upon our historical experience and information known as of the date of this report, we do not believe it is likely that we will have significant liability for the above indemnities at September 30, 2015.

[0001511737-15-000029:mdna:88]
[same as prior period, unchanged from 0001511737-15-000018:mdna:87]

[0001511737-15-000029:mdna:89]
The following table summarizes our contractual obligations as of September 30, 2015 for the remainder of fiscal 2016 and future fiscal years (in thousands):

[0001511737-15-000029:mdna:90]
|  | 2016 (remainder) |  | 2017 |  | 2018 |  | 2019 |  | 2020 |  | Thereafter |  | Total |
| Operating leases | $ | 3,309 |  |  | $ | 3,349 |  |  | $ | 1,792 |  |  | $ | 718 |  |  | $ | 642 |  |  | $ | 79 |  |  | $ | 9,889 |  |
| Debt payment obligations | 7,500 |  |  | 11,250 |  |  | 15,000 |  |  | 15,000 |  |  | 46,250 |  |  | — |  |  | 95,000 |  |
| Interest and other payments on debt payment obligations | 1,521 |  |  | 1,893 |  |  | 1,659 |  |  | 1,392 |  |  | 818 |  |  | — |  |  | 7,283 |  |
| Purchase obligations | 11,614 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 11,614 |  |
| Other obligations | 6,106 |  |  | 32 |  |  | 3 |  |  | — |  |  | — |  |  | — |  |  | 6,141 |  |
| Total | $ | 30,050 |  |  | $ | 16,524 |  |  | $ | 18,454 |  |  | $ | 17,110 |  |  | $ | 47,710 |  |  | $ | 79 |  |  | $ | 129,927 |  |

[0001511737-15-000029:mdna:91]
[same as prior period, unchanged from 0001511737-15-000018:mdna:90]

[0001511737-15-000029:mdna:92]
We lease our headquarters in San Jose, California in addition to other locations worldwide under non-cancelable operating leases that expire at various dates through 2021.

[0001511737-15-000029:mdna:93]
[same as prior period, unchanged from 0001511737-15-000018:mdna:92]

[0001511737-15-000029:mdna:94]
On March 3, 2015, we entered into the Amended Credit Agreement, that provides for a $200.0 million senior secured revolving credit facility and a $100.0 million senior secured term loan facility, with an option to request increases in the amounts of such credit facilities by up to an additional $50.0 million in the aggregate (any such increase to be in each lender’s sole discretion).  Please see Note 7 of the Notes to the Consolidated Financial Statements for more information. We have calculated estimated interest payments for our debt based on the applicable rates and payment dates. Although our interest rates on our debt obligations may vary, we have assumed our interest rate as of September 30, 2015 as the rate for all years presented.   Also included are estimated bank fees to be paid for unused portions of our revolving credit facility.

[0001511737-15-000029:mdna:95]
[same as prior period, unchanged from 0001511737-15-000018:mdna:95]

[0001511737-15-000029:mdna:96]
We subcontract with other companies to manufacture our products. During the normal course of business, our contract manufacturers procure components based upon orders placed by us. If we cancel all or part of the orders, we may still be liable to the contract manufacturers for the cost of the components purchased by the subcontractors to manufacture our products. We periodically review the potential liability and to date no significant liabilities for cancellations have been recorded. Our consolidated financial position and results of operations could be negatively impacted if we were required to compensate the contract manufacturers for any unrecorded liabilities incurred.  The Company had inventory purchase obligations of $11.6 million as of September 30, 2015.

[0001511737-15-000029:mdna:97]
[same as prior period, unchanged from 0001511737-15-000018:mdna:97]

[0001511737-15-000029:mdna:98]
We had other obligations of $6.1 million as of September 30, 2015, which consisted primarily of commitments related to research and development projects.

[0001511737-15-000029:mdna:99]
[same as prior period, unchanged from 0001511737-15-000018:mdna:99]

[0001511737-15-000029:mdna:100]
As of September 30, 2015, we had $20.6 million of unrecognized tax benefits, substantially all of which would, if recognized, affect our tax expense. We have elected to include interest and penalties related to uncertain tax positions as a component of tax expense. We do not expect any significant increases or decreases to our unrecognized tax benefits in the next twelve months.

[0001511737-15-000029:mdna:101]
[same as prior period, unchanged from 0001511737-15-000018:mdna:101]

[0001511737-15-000029:mdna:102]
[same as prior period, unchanged from 0001511737-15-000018:mdna:102]

[0001511737-15-000029:mdna:103]
[same as prior period, unchanged from 0001511737-15-000018:mdna:103]

[0001511737-15-000029:mdna:104]
[same as prior period, unchanged from 0001511737-15-000018:mdna:104]

[0001511737-15-000029:mdna:105]
Our Non-GAAP measures primarily exclude stock-based compensation, net of taxes, and other special charges and credits.  Additionally, in fiscal 2016 we recognized a recovery of $8.0 million related to the BEC fraud loss, as described at Note 14.  We use each of these Non-GAAP financial measures for internal managerial purposes when providing our financial results and business outlook to the public. Management believes that these Non-GAAP measures provide meaningful supplemental information regarding our operational and financial performance of current and historical results, facilitating period-to-period comparisons.  Additionally, we believe these Non-GAAP financial measures provide meaningful information regarding our strategic and business decision making, internal budgeting, forecasting and resource allocation processes as well as supplement management’s internal comparisons to our historical operating results and to our competitors’ operating results.

[0001511737-15-000029:mdna:106]
[same as prior period, unchanged from 0001511737-15-000018:mdna:107]

[0001511737-15-000029:mdna:107]
|  | Three Months Ended September 30, |
|  | 2015 |  | 2014 |
|  | (In thousands, except per share amounts) |
| Non-GAAP net income and comprehensive income | $ | 45,511 |  |  | $ | 43,406 |  |
| Non-GAAP diluted net income per share of common stock | $ | 0.51 |  |  | $ | 0.48 |  |

[0001511737-15-000029:mdna:108]
[same as prior period, unchanged from 0001511737-15-000018:mdna:109]

[0001511737-15-000029:mdna:109]
[same as prior period, unchanged from 0001511737-15-000018:mdna:110]

[0001511737-15-000029:mdna:110]
|  | Three Months Ended September 30, |
|  | 2015 |  | 2014 |
|  | (In thousands, except per share amounts) |
| Net income and comprehensive income | $ | 53,759 |  |  | $ | 37,743 |  |
| Stock-based compensation: |  |  |  |
| Cost of revenues | 113 |  |  | 149 |  |
| Research and development | 624 |  |  | 825 |  |
| Sales, general and administrative | 290 |  |  | 398 |  |
| Purchase commitment termination fee | — |  |  | 5,500 |  |
| Business e-mail compromise ("BEC") fraud loss/(recovery) | (8,034 | ) |  | — |  |
| Implementation of overhead capitalization | (944 | ) |  |  |
| Tax effect of non-GAAP adjustments | (297 | ) |  | (1,209 | ) |
| Non-GAAP net income and comprehensive income | $ | 45,511 |  |  | $ | 43,406 |  |
| Non-GAAP diluted net income per share of common stock | $ | 0.51 |  |  | $ | 0.48 |  |
| Weighted-average shares used in computing non-GAAP diluted net income per share of common stock | 88,465 |  |  | 89,913 |  |

[0001511737-15-000029:mdna:111]
Note About Forward-Looking Statements

[0001511737-15-000029:mdna:112]
When used in this Report, the words “anticipates,” “believes,” “could,” “seeks,” “estimates,” “expects,” “intends,” “may,” “plans” “potential,” “predicts,” “projects,” “should,” “will,” “would” or similar expressions and negatives of those terms are intended to identify forward-looking statements. These are statements that relate to future periods and include statements about our future results, sources of revenue, our continued growth, our gross margins, market trends, our product development, technological developments, the features, benefits and performance of our current and future products, the ability of our products to address a variety of markets, the anticipated growth of demand for connectivity worldwide, our growth strategies, future price reductions, our competitive status, our dependence on our senior management and our ability to attract and retain key personnel, dependency on and concentration of our distributors, our employee relations, current and potential litigation, the effects of government regulations, our compliance with laws and regulations, our expected future operating costs and expenses and expenditure levels for research and development, selling, general and administrative expenses, fluctuations in operating results, fluctuations in our stock price, our payment of dividends, our future liquidity and cash needs, our credit facility, future acquisitions of and investments in complimentary businesses and the expected impact of various accounting policies and rules adopted by the Financial Accounting Standards Board. Forward-looking statements are subject to risks and uncertainties that could cause actual results to differ materially from those projected. These risks and uncertainties include, but are not limited to, factors affecting our quarterly results, our ability to manage our growth, our ability to sustain or increase profitability, demand for our products, our ability to compete, our ability to rapidly develop new technology and introduce new products, our ability to safeguard our intellectual property, trends in the networking industry and fluctuations in general economic conditions, and the risks set forth throughout this Report, including under Item 1, “Business” and under Item 1A, “Risk Factors.” These forward-looking statements speak only as of the date hereof. Except as required by law, we expressly disclaim any obligation or undertaking to release publicly any updates or revisions to any forward-looking statements contained herein to reflect any change in our expectations with regard thereto or any change in events, conditions or circumstances on which any such statement is based.
