# UI 8-K — 0001415889-15-003599 filed 2015-11-05

## item codes, every 8-K on or before 2015-11-05

- 2015-11-05 0001415889-15-003599 — 2.02, 8.01, 9.01
- 2015-10-16 0001415889-15-003433 — 5.02
- 2015-08-06 0001571049-15-006288 — 2.02, 5.02, 8.01, 9.01
- 2015-05-07 0001511737-15-000016 — 2.02, 9.01
- 2015-04-23 0001415889-15-001433 — 2.02, 5.02, 9.01
- 2015-03-06 0001415889-15-000787 — 1.01, 1.02, 2.03, 9.01
- 2015-02-05 0001511737-15-000008 — 2.02, 9.01
- 2014-12-18 0001193125-14-446627 — 5.07
- 2014-11-06 0001511737-14-000029 — 2.02, 9.01
- 2014-09-30 0001193125-14-359060 — 7.01, 9.01
- 2014-08-07 0001511737-14-000021 — 2.02, 9.01
- 2014-05-08 0001511737-14-000016 — 2.02, 9.01
- 2014-04-17 0001193125-14-146710 — 7.01
- 2014-03-06 0001193125-14-084883 — 8.01
- 2014-02-06 0001511737-14-000005 — 2.02, 9.01
- 2013-12-16 0001193125-13-474388 — 5.07
- 2013-11-22 0001193125-13-451511 — 5.02
- 2013-11-07 0001511737-13-000018 — 2.02, 9.01
- 2013-10-28 0001193125-13-413414 — 5.02, 9.01
- 2013-10-18 0001193125-13-404111 — 5.02, 9.01
- 2013-08-08 0001511737-13-000009 — 2.02, 9.01
- 2013-05-09 0001511737-13-000004 — 2.02
- 2013-03-25 0001193125-13-124353 — 5.07
- 2013-03-08 0001193125-13-098334 — 5.02, 9.01
- 2013-02-07 0001193125-13-043701 — 2.02, 9.01
- 2012-12-28 0001193125-12-518487 — 1.01
- 2012-12-17 0001193125-12-503742 — 7.01, 9.01
- 2012-12-13 0001193125-12-501894 — 5.02
- 2012-11-16 0001193125-12-474083 — 5.02
- 2012-11-13 0001193125-12-467376 — 5.02
- 2012-11-08 0001193125-12-460665 — 2.02, 9.01
- 2012-10-10 0001193125-12-420015 — 5.02, 9.01
- 2012-08-13 0001193125-12-352624 — 1.01, 2.03, 9.01
- 2012-08-09 0001193125-12-347776 — 1.01, 9.01
- 2012-08-09 0001193125-12-347732 — 2.02, 9.01
- 2012-05-01 0001193125-12-201012 — 2.02, 9.01
- 2012-03-30 0001193125-12-144074 — 5.02
- 2012-03-27 0001193125-12-134395 — 5.02, 9.01
- 2012-03-22 0001193125-12-127536 — 5.02
- 2012-01-31 0001193125-12-032079 — 2.02, 9.01
- 2011-12-27 0001193125-11-353002 — 1.01, 9.01
- 2011-12-06 0001193125-11-332192 — 5.02
- 2011-11-10 0001193125-11-306969 — 2.02, 9.01

## late-filing notifications on or before 2015-11-05

- none on or before 2015-11-05

## item 2.02 — earnings release, exhibit 99.1

[0001415889-15-003599:8k_2_02:1]
EX-99
2
ex99-11052015_011100.htm

[0001415889-15-003599:8k_2_02:2]
Secconnect.com

[0001415889-15-003599:8k_2_02:3]
UBIQUITI NETWORKS REPORTS FIRST QUARTER FISCAL 2016 FINANCIAL RESULTS

[0001415889-15-003599:8k_2_02:4]
~ Achieves Strong Revenue and Earnings ~

[0001415889-15-003599:8k_2_02:5]
~ Non-GAAP Diluted EPS of $0.51 Per Share ~

[0001415889-15-003599:8k_2_02:6]
SAN JOSE, Calif. – Nov. 5, 2015 - Ubiquiti Networks, Inc. (NASDAQ:UBNT) (“Ubiquiti”) today announced results for the first fiscal quarter of 2016, ended September 30, 2015.

[0001415889-15-003599:8k_2_02:7]
First Quarter Financial Summary

[0001415889-15-003599:8k_2_02:8]
•

[0001415889-15-003599:8k_2_02:9]
Revenues of $151.4 million

[0001415889-15-003599:8k_2_02:10]
•

[0001415889-15-003599:8k_2_02:11]
GAAP gross profit of $73.5 million and non-GAAP gross profit of $72.7 million

[0001415889-15-003599:8k_2_02:12]
•

[0001415889-15-003599:8k_2_02:13]
GAAP net income of $53.8 million and non-GAAP net income of $45.5 million

[0001415889-15-003599:8k_2_02:14]
•

[0001415889-15-003599:8k_2_02:15]
GAAP diluted EPS of $0.61 and non-GAAP diluted EPS of $0.51

[0001415889-15-003599:8k_2_02:16]
•

[0001415889-15-003599:8k_2_02:17]
$47.7 million in net cash provided by operating activities

[0001415889-15-003599:8k_2_02:18]
Recent Financial Highlights

[0001415889-15-003599:8k_2_02:19]
•

[0001415889-15-003599:8k_2_02:20]
Enterprise Technology revenues increased 19% quarter-over-quarter, fueled by UniFi® access points and other industry-leading products targeting the Enterprise market

[0001415889-15-003599:8k_2_02:21]
•

[0001415889-15-003599:8k_2_02:22]
Completed $100 million stock repurchase plan as of October 20, 2015, repurchasing $63.3 million of common stock during the quarter ended September 30, 2015

[0001415889-15-003599:8k_2_02:23]
•

[0001415889-15-003599:8k_2_02:24]
Initiated a new stock repurchase program, authorizing the Company to repurchase up to $50 million of its common stock as disclosed in the Form 8-K filed on November 5, 2015

[0001415889-15-003599:8k_2_02:25]
Recent Product Highlights

[0001415889-15-003599:8k_2_02:26]
•

[0001415889-15-003599:8k_2_02:27]
Released the new UniFi AC, four new access points and a redesigned UniFi Controller featuring advanced technology for enterprise, hospitality, and education markets.  In conjunction with this release, we launched an Easy App for UniFi setup

[0001415889-15-003599:8k_2_02:28]
•

[0001415889-15-003599:8k_2_02:29]
Achieved backwards compatibility for airMAX® AC products through release of beta version of airOS® 8

[0001415889-15-003599:8k_2_02:30]
•

[0001415889-15-003599:8k_2_02:31]
Obtained DFS certifications for our remaining 802.11n and 802.11ac products, unlocking the full spectrum available to our U.S. WISP operators

[0001415889-15-003599:8k_2_02:32]
•

[0001415889-15-003599:8k_2_02:33]
Launched UniFi Cloud Key, hybrid cloud device management that securely runs a local instance of the UniFi Controller software and features cloud Single Sign-On for remote access

[0001415889-15-003599:8k_2_02:34]
•

[0001415889-15-003599:8k_2_02:35]
Announced sunMAX®, a solar solution designed to address the obstacles preventing solar deployment on a global scale

[0001415889-15-003599:8k_2_02:36]
•

[0001415889-15-003599:8k_2_02:37]
Introduced enhancements to our recently introduced airFiber® X with the airFiber NxN, a thoughtfully engineered MIMO multiplexer designed for the global last-mile wireless industry. With expected range exceeding 200km+ and increased throughput of up to 2Gbps+, airFiber NxN is a technological leap in true long-range, carrier-class, backhaul technology for the world

[0001415889-15-003599:8k_2_02:38]
Financial Results Summary ($, in millions, except per share data)

[0001415889-15-003599:8k_2_02:39]
| Income statement highlights |  | F1Q16 |  | F4Q15 |  | F1Q15 |
| Revenues |  | 151.4 |  | 145.3 |  | 150.1 |
| Service Provider Technology |  | 103.4 |  | 104.8 |  | 107.3 |
| Enterprise Technology |  | 48.0 |  | 40.5 |  | 42.8 |
| Cost of Revenues |  | 77.9 |  | 79.1 |  | 89.0 |
| Gross Profit |  | 73.5 |  | 66.1 |  | 61.0 |
| Gross Profit (%) |  | 48.5% |  | 45.5% |  | 40.7% |
| Total Operating Expenses(1) |  | 13.7 |  | 58.8 |  | 17.4 |
| Income from Operations |  | 59.8 |  | 7.3 |  | 43.6 |
| GAAP Net Income |  | 53.8 |  | 4.5 |  | 37.7 |
| GAAP EPS (diluted) |  | 0.61 |  | 0.05 |  | 0.42 |
| Non-GAAP Net Income |  | 45.5 |  | 44.1 |  | 43.4 |
| Non-GAAP EPS (diluted) |  | 0.51 |  | 0.50 |  | 0.48 |

[0001415889-15-003599:8k_2_02:40]
(1)

[0001415889-15-003599:8k_2_02:41]
Includes business e-mail compromise (“BEC”) fraud loss of $39.1 million in F4Q15 and recovery of $8.0 million in F1Q16.

[0001415889-15-003599:8k_2_02:42]
Balance Sheet Highlights

[0001415889-15-003599:8k_2_02:43]
Total cash and cash equivalents as of September 30, 2015 were $436.1 million, compared with $446.4 million as of June 30, 2015.  The slight sequential decrease in cash and cash equivalents during the first quarter of fiscal 2016 is net of $63.3 million in share repurchases as part of our share repurchase program.

[0001415889-15-003599:8k_2_02:44]
This quarter we saw days sales outstanding in accounts receivable ("DSO") of 39 days, compared with 41 days in the prior quarter, and 40 days in the first quarter of fiscal 2015.

[0001415889-15-003599:8k_2_02:45]
Business Outlook

[0001415889-15-003599:8k_2_02:46]
Based on recent business trends, Ubiquiti currently believes the demand environment in its end markets supports the following forecast for the Company's second fiscal quarter ending December 31, 2015.  The following are Ubiquiti’s financial performance estimates for the second quarter of fiscal 2016:

[0001415889-15-003599:8k_2_02:47]
•

[0001415889-15-003599:8k_2_02:48]
Revenues of between $150 million and $160 million

[0001415889-15-003599:8k_2_02:49]
•

[0001415889-15-003599:8k_2_02:50]
GAAP diluted EPS of $0.48 - $0.55

[0001415889-15-003599:8k_2_02:51]
•

[0001415889-15-003599:8k_2_02:52]
Non-GAAP diluted EPS of $0.49 - $0.56

[0001415889-15-003599:8k_2_02:53]
Conference Call Information

[0001415889-15-003599:8k_2_02:54]
Ubiquiti Networks will host a Q&A-only call to discuss the Company’s financial results at 2:00 p.m. Pacific Time today.  Management’s prepared remarks can be found on the Investor Relations section of the Ubiquiti Networks website, http://ir.ubnt.com/results.cfm.

[0001415889-15-003599:8k_2_02:55]
To listen to the Q&A call via telephone, dial (877) 291-1296 (U.S. toll-free) or (720) 259-9209 (International) to be connected to the call by an operator.  Participants should dial in at least 10 minutes prior to the start of the call.  Investors may also listen to a live webcast of the Q&A conference call by visiting the Investor Relations section of the Ubiquiti Networks website at http://ir.ubnt.com.

[0001415889-15-003599:8k_2_02:56]
A recording of the Q&A call will be available approximately two hours after the call concludes and will be accessible on the Investor Relations section of the Ubiquiti Networks website, http://ir.ubnt.com.

[0001415889-15-003599:8k_2_02:57]
About Ubiquiti Networks

[0001415889-15-003599:8k_2_02:58]
Ubiquiti Networks (Nasdaq:UBNT) is closing the digital divide by building network communication platforms for everyone and everywhere. With over 28 million devices sold worldwide, Ubiquiti is transforming under-networked enterprises and communities. Our leading edge platforms, airMAX®, UniFi®, airFiber®, UniFi® Video, mFi® and EdgeMAX®, combine innovative technology, disruptive price-to-performance and the support of a global user community to eliminate barriers to connectivity. For more information, join our community at http://www.ubnt.com.

[0001415889-15-003599:8k_2_02:59]
Ubiquiti, Ubiquiti Networks, the U logo, UBNT, airMAX, UniFi, airFiber, mFi, EdgeMAX and sunMAX are registered trademarks or trademarks of Ubiquiti Networks, Inc. in the United States and other countries.

[0001415889-15-003599:8k_2_02:60]
The Ubiquiti Networks, Inc. logo is available at http://www.globenewswire.com/newsroom/prs/?pkgid=24865

[0001415889-15-003599:8k_2_02:61]
Investor Relations Contact

[0001415889-15-003599:8k_2_02:62]
Anne Fazioli

[0001415889-15-003599:8k_2_02:63]
Ubiquiti Networks, Vice President of Investor Relations

[0001415889-15-003599:8k_2_02:64]
IR@ubnt.com

[0001415889-15-003599:8k_2_02:65]
Forward-looking statements are subject to certain risks and uncertainties that could cause our actual future results to differ materially, or cause a material adverse impact on our results.  Potential risks and uncertainties include, but are not limited to, fluctuations in our operating results; varying demand for our products due to the financial and operating condition of our distributors and their customers, and distributors' inventory management practices; political and economic conditions and volatility affecting the stability of business environments, economic growth, currency values, commodity prices and other factors that may influence the ultimate demand for our products in particular geographies or globally; impact of counterfeiting and our ability to contain such impact; our reliance on a limited number of distributors; inability of our contract manufacturers and suppliers to meet our demand; our dependence on Qualcomm Atheros for chipsets without a short-term alternative; as we move into new markets competition from certain of our current or potential competitors who may be more established in such markets; our ability to keep pace with technological and market developments; success and timing of new product introductions by us and the performance of our products generally; our ability to effectively manage the significant increase in our transactional sales volumes; we may become subject to warranty claims, product liability and product recalls; that a substantial majority of our sales are into countries outside the United States and we are subject to numerous U.S. export control and economic sanctions laws; costs related to responding to government inquiries related to regulatory compliance; our reliance on the Ubiquiti Community; our reliance on certain key members of our management team, including our founder and chief executive officer, Robert J. Pera; adverse tax-related matters such as tax audits, changes in our effective tax rate or new tax legislative proposals; whether the final determination of our income tax liability may be materially different from our income tax provisions; the impact of any intellectual property litigation and claims for indemnification; litigation related to U.S. Securities laws; and economic and political conditions in the United States and abroad.  We discuss these risks in greater detail under the heading “Risk Factors” and elsewhere in our Annual Report on Form 10-K for the year ended June 30, 2015, and subsequent filings filed with the U.S. Securities and Exchange Commission (the SEC), which are available at the SEC's website at www.sec.gov.  Copies may also be obtained by contacting the Ubiquiti Networks Investor Relations Department, by email at IR@ubnt.com or by visiting the Investor Relations section of the Ubiquiti Networks website, http://ir.ubnt.com.

[0001415889-15-003599:8k_2_02:66]
Given these uncertainties, you should not place undue reliance on these forward-looking statements.  Also, forward-looking statements represent our management's beliefs and assumptions only as of the date made.  Except as required by law, Ubiquiti Networks undertakes no obligation to update information contained herein.  You should review our SEC filings carefully and with the understanding that our actual future results may be materially different from what we expect.

[0001415889-15-003599:8k_2_02:67]
Use of Non-GAAP Financial Information

[0001415889-15-003599:8k_2_02:68]
To supplement our condensed consolidated financial results prepared under generally accepted accounting principles, or GAAP, we use non-GAAP measures of net income and earnings per diluted share that are adjusted to exclude certain costs, expenses and gains such as stock based compensation expense, Business e-mail compromise (“BEC”) fraud loss/(recovery), implementation of overhead capitalization, reserve against vendor deposits relating to a purchase commitment termination fee and the tax effects of these non-GAAP adjustments.  Reconciliations of the adjustments to GAAP results for the three months ended September 30, 2015 and 2014 are provided below.  In addition, an explanation of the ways in which management uses non-GAAP financial information to evaluate its business, the substance behind management's decision to use this non-GAAP financial information, material limitations associated with the use of non-GAAP financial information, the manner in which management compensates for those limitations, and the substantive reasons management believes that this non-GAAP financial information provides useful information to investors is included under "About our Non-GAAP Net Income and Adjustments" after the tables below.

[0001415889-15-003599:8k_2_02:69]
| Ubiquiti Networks Inc. Condensed Consolidated Statement of Operations (In thousands, except per share data) (Unaudited) |
|  |  | Three Months Ended September 30, |  |
|  |  | 2015 |  |  | 2014 |  |
| Revenues |  | $ | 151,415 |  |  | $ | 150,087 |  |
| Cost of revenues |  | 77,911 |  |  | 89,036 |  |
| Gross profit |  | 73,504 |  |  | 61,051 |  |
| Operating expenses: |  |  |  |  |  |  |
| Research and development |  | 13,561 |  |  | 11,721 |  |
| Sales, general and administrative |  | 8,142 |  |  | 5,696 |  |
| Business e-mail compromise ("BEC") fraud loss/(recovery) |  | (8,034) |  |  | — |  |
| Total operating expenses |  | 13,669 |  |  | 17,417 |  |
| Income from operations |  | 59,835 |  |  | 43,634 |  |
| Interest expense and other, net |  | (116) |  |  | (58) |  |
| \Income before provision for income taxes |  | 59,719 |  |  | 43,576 |  |
| Provision for income taxes |  | 5,960 |  |  | 5,833 |  |
| Net income |  | $ | 53,759 |  |  | $ | 37,743 |  |
| Net income per share of common stock: |  |  |  |  |  |  |
| Basic |  | $ | 0.62 |  |  | $ | 0.43 |  |
| Diluted |  | $ | 0.61 |  |  | $ | 0.42 |  |
| Weighted average shares used in computing net income per share of common stock: |  |  |  |  |  |  |
| Basic |  | 87,062 |  |  | 88,240 |  |
| Diluted |  | 88,465 |  |  | 89,913 |  |

[0001415889-15-003599:8k_2_02:70]
| Ubiquiti Networks Inc. Reconciliation of GAAP Net Income to Non-GAAP Net Income (In thousands, except per share data) (Unaudited) |
|  |  | Three Months Ended September 30, |  |
|  |  | 2015 |  |  | 2014 |  |
| Net income |  | $ | 53,759 |  |  | $ | 37,743 |  |
| Stock-based compensation: |  |  |  |  |  |  |  |  |
| Cost of revenues |  |  | 113 |  |  |  | 149 |  |
| Research and development |  |  | 624 |  |  |  | 825 |  |
| Sales, general and administrative |  |  | 290 |  |  |  | 398 |  |
| Purchase commitment termination fee |  |  | — |  |  |  | 5,500 |  |
| Business e-mail compromise ("BEC") fraud loss/(recovery) |  |  | (8,034) |  |  |  | — |  |
| Implementation of overhead capitalization |  |  | (944) |  |  |  | — |  |
| Tax effect of non-GAAP adjustments |  |  | (297) |  |  |  | (1,209) |  |
| Non-GAAP net income |  | $ | 45,511 |  |  | $ | 43,406 |  |
| Non-GAAP diluted EPS |  | $ | 0.51 |  |  | $ | 0.48 |  |
| Weighted-average shares used in non-GAAP diluted EPS |  |  | 88,465 |  |  |  | 89,913 |  |

[0001415889-15-003599:8k_2_02:71]
| Ubiquiti Networks Inc. Condensed Consolidated Balance Sheets (In thousands, except share amounts) (Unaudited) |
|  |  | September 30, 2015 |  |  | June 30, 2015 |  |
| Assets |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 436,080 |  |  | $ | 446,401 |  |
| Accounts receivable, net |  | 63,585 |  |  | 66,104 |  |
| Inventories |  | 30,694 |  |  | 37,031 |  |
| Vendor deposits |  | 19,052 |  |  | 19,998 |  |
| Current deferred tax asset |  | 1,535 |  |  | 1,535 |  |
| Prepaid income taxes |  | — |  |  | 2,566 |  |
| Prepaid expenses and other current assets |  | 13,641 |  |  | 7,711 |  |
| Total current assets |  | 564,587 |  |  | 581,346 |  |
| Property and equipment, net |  | 15,755 |  |  | 15,602 |  |
| Long-term deferred tax asset |  | 1,538 |  |  | 1,515 |  |
| Other long–term assets |  | 2,020 |  |  | 2,109 |  |
| Total assets |  | $ | 583,900 |  |  | $ | 600,572 |  |
| Liabilities and Stockholders’ Equity |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |
| Accounts payable |  | $ | 23,129 |  |  | $ | 43,856 |  |
| Income taxes payable |  |  | 2,065 |  |  |  | 1,108 |  |
| Debt - short-term |  |  | 10,000 |  |  |  | 10,000 |  |
| Other current liabilities |  | 28,101 |  |  | 15,170 |  |
| Total current liabilities |  | 63,295 |  |  | 70,134 |  |
| Long-term taxes payable |  | 20,867 |  |  | 19,810 |  |
| Debt - long-term |  | 85,000 |  |  | 87,500 |  |
| Deferred revenues - long-term |  | 1,005 |  |  | 974 |  |
| Total liabilities |  | 170,167 |  |  | 178,418 |  |
| Stockholders’ equity: |  |  |  |  |  |  |
| Common stock |  | 82 |  |  | 87 |  |
| Additional paid–in capital |  | — |  |  | — |  |
| Treasury stock |  | — |  |  | — |  |
| Retained earnings |  | 413,651 |  |  | 422,067 |  |
| Total stockholders’ equity |  | 413,733 |  |  | 422,154 |  |
| Total liabilities and stockholders’ equity |  | $ | 583,900 |  |  | $ | 600,572 |  |

[0001415889-15-003599:8k_2_02:72]
| Ubiquiti Networks Inc. Revenue by Product Category (In thousands) (Unaudited) |
|  |  | Three Months Ended September 30, |  |
|  |  | 2015 |  |  | 2014 |  |
| Service Provider Technology |  | $ | 103,399 |  |  | $ | 107,271 |  |
| Enterprise Technology |  |  | 48,016 |  |  |  | 42,816 |  |
| Total revenues |  | $ | 151,415 |  |  | $ | 150,087 |  |

[0001415889-15-003599:8k_2_02:73]
| Ubiquiti Networks Inc. Revenue by Geographical Area (In thousands) (Unaudited) |
|  |  | Three Months Ended September 30, |  |
|  |  | 2015 |  |  | 2014 |  |
| North America |  | $ | 53,234 |  |  | $ | 53,582 |  |
| South America |  |  | 22,148 |  |  |  | 31,134 |  |
| Europe, the Middle East and Africa |  |  | 60,503 |  |  |  | 50,607 |  |
| Asia Pacific |  |  | 15,530 |  |  |  | 14,764 |  |
| Total revenues |  | $ | 151,415 |  |  | $ | 150,087 |  |

[0001415889-15-003599:8k_2_02:74]
About our Non-GAAP Net Income and Adjustments

[0001415889-15-003599:8k_2_02:75]
Use of Non-GAAP Financial Information

[0001415889-15-003599:8k_2_02:76]
To supplement our condensed consolidated financial results prepared under generally accepted accounting principles, or GAAP, we use non-GAAP measures of net income and earnings per diluted share that are GAAP net income and GAAP earnings per diluted share adjusted to exclude certain costs, expenses and gains/losses.

[0001415889-15-003599:8k_2_02:77]
We believe that the presentation of non-GAAP net income and non-GAAP earnings per diluted share provides important supplemental information regarding non-cash expenses, significant items that we believe are important to understanding our financial, and business trends relating to our financial condition and results of operations.  Non-GAAP net income and non-GAAP earnings per diluted share are among the primary indicators used by management as a basis for planning and forecasting future periods and by management and our board of directors to determine whether our operating performance has met specified targets and thresholds.  Management uses non-GAAP net income and non-GAAP earnings per diluted share when evaluating operating performance because it believes that the exclusion of the items described below, for which the amounts or timing may vary significantly depending upon the Company's activities and other factors, facilitates comparability of the Company's operating performance from period to period.  We have chosen to provide this information to investors so they can analyze our operating results in the same way that management does and use this information in their assessment of our business and the valuation of our Company.

[0001415889-15-003599:8k_2_02:78]
Use and Economic Substance of Non-GAAP Financial Measures used by Ubiquiti Networks

[0001415889-15-003599:8k_2_02:79]
We compute non-GAAP net income and non-GAAP earnings per diluted share by adjusting GAAP net income and GAAP earnings per diluted share to remove the impact of certain adjustments and the tax effect of those adjustments.  Items excluded from net income are:

[0001415889-15-003599:8k_2_02:80]
•

[0001415889-15-003599:8k_2_02:81]
Stock-based compensation expense

[0001415889-15-003599:8k_2_02:82]
•

[0001415889-15-003599:8k_2_02:83]
Business e-mail compromise ("BEC") fraud loss/(recovery)

[0001415889-15-003599:8k_2_02:84]
•

[0001415889-15-003599:8k_2_02:85]
Implementation of overhead capitalization

[0001415889-15-003599:8k_2_02:86]
•

[0001415889-15-003599:8k_2_02:87]
Reserve against vendor deposits relating to a purchase commitment termination fee

[0001415889-15-003599:8k_2_02:88]
•

[0001415889-15-003599:8k_2_02:89]
Tax effect of non-GAAP adjustments, applying the principles of ASC 740

[0001415889-15-003599:8k_2_02:90]
Usefulness of Non-GAAP Financial Information to Investors

[0001415889-15-003599:8k_2_02:91]
These non-GAAP measures are not in accordance with, or an alternative to, GAAP and may be materially different from other non-GAAP measures, including similarly titled non-GAAP measures used by other companies.  The presentation of this additional information should not be considered in isolation from, as a substitute for, or superior to, net income or earnings per diluted share prepared in accordance with GAAP.  Non-GAAP financial measures have limitations in that they do not reflect certain items that may have a material impact upon our reported financial results.

[0001415889-15-003599:8k_2_02:92]
For more information on the non-GAAP adjustments, please see the table captioned “Reconciliation of GAAP Net Income to Non-GAAP Net Income” included in this press release.
