# UI notes — 0001511737-15-000029


## ubnt:CapitalizedManufacturingOverheadCostsPolicyPolicyTextBlock

[0001511737-15-000029:notes:1]
Capitalized Manufacturing Overhead Costs

[0001511737-15-000029:notes:2]
In fiscal 2016, the Company began capitalizing manufacturing overhead expenditures as part of inventory costs.  Capitalized costs primarily include management’s best estimate of the direct labor and materials costs related to inventory produced but not sold during the period.  During the three months ended September 30, 2015, the Company capitalized $944 thousand of manufacturing overhead costs, which are included in inventory on the Company’s condensed consolidated balance sheet as of September 30, 2015.


## ubnt:ScheduleOfRevenueAndAccountsReceivableByMajorCustomersByReportingSegmentsTableTableTextBlock

[0001511737-15-000029:notes:3]
[same as prior period, unchanged from 0001511737-15-000018:notes:1]

[0001511737-15-000029:notes:4]
|  | Percentage of Revenues |  | Percentage of Accounts Receivable |
|  | Three Months Ended September 30, |  | September 30, |  | June 30, |
|  | 2015 |  | 2014 |  | 2015 |  | 2015 |
| Customer A | * |  | 10% |  | * |  | * |
| Customer B | * |  | * |  | 12% |  | 13% |
| Customer C | * |  | * |  | 10% |  | 12% |

[0001511737-15-000029:notes:5]
*  denotes less than


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001511737-15-000029:notes:6]
Basis of Presentation— The accompanying condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP”) related to interim financial statements based on applicable Securities and Exchange Commission (“SEC”) rules and regulations. Accordingly, they do not include all the information and footnotes required by U.S. GAAP for complete financial statements. This information reflects all adjustments, which are, in the opinion of the Company, of a normal and recurring nature and necessary to state fairly the statements of financial position, results of operations and cash flows for the dates and periods presented. The June 30, 2015 balance sheet was derived from the audited financial statements as of that date. All significant intercompany transactions and balances have been eliminated.  The Company has reclassified certain amounts reported in the previous period to conform to the current period presentation.

[0001511737-15-000029:notes:7]
These condensed consolidated financial statements should be read in conjunction with the Company’s audited consolidated financial statements for the fiscal year ended June 30, 2015, included in its Annual Report on Form 10-K, as filed with the SEC on August 21, 2015 (the “Annual Report”). The results of operations for the three months ended September 30, 2015 are not necessarily indicative of the results to be expected for any future periods.


## us-gaap:BusinessDescriptionAndBasisOfPresentationTextBlock

[0001511737-15-000029:notes:8]
[same as prior period, unchanged from 0001511737-15-000018:notes:4]

[0001511737-15-000029:notes:9]
Business— Ubiquiti Networks, Inc. was incorporated in the State of California in 2003 as Pera Networks, Inc.  In 2005 Pera Networks, Inc. changed its name to Ubiquiti Networks, Inc. and commenced its current operations. In June 2010, Ubiquiti Networks, Inc. was re-incorporated in Delaware.

[0001511737-15-000029:notes:10]
[same as prior period, unchanged from 0001511737-15-000018:notes:6]

[0001511737-15-000029:notes:11]
The Company operates on a fiscal year ending June 30. In this Quarterly Report, the fiscal year ending June 30, 2016 is referred to as “fiscal 2016” and the fiscal year ended June 30, 2015 is referred to as “fiscal 2015.”


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001511737-15-000029:notes:12]
COMMITMENTS AND CONTINGENCIES

[0001511737-15-000029:notes:13]
Operating Leases

[0001511737-15-000029:notes:14]
Certain facilities and equipment are leased under non-cancelable operating leases. The Company generally pays taxes, insurance and maintenance costs on leased facilities and equipment. The Company leases office space in San Jose, California and other locations under various non-cancelable operating leases that expire at various dates through 2021.

[0001511737-15-000029:notes:15]
At September 30, 2015, future minimum annual payments under operating leases for the remainder of fiscal 2016 and future fiscal years are as follows (in thousands):

[0001511737-15-000029:notes:16]
|  | 2016 (remainder) |  | 2017 |  | 2018 |  | 2019 |  | 2020 |  | Thereafter |  | Total |
| Operating leases | $ | 3,309 |  |  | $ | 3,349 |  |  | $ | 1,792 |  |  | $ | 718 |  |  | $ | 642 |  |  | $ | 79 |  |  | $ | 9,889 |  |

[0001511737-15-000029:notes:17]
Purchase Obligations

[0001511737-15-000029:notes:18]
The Company primarily subcontracts with other companies to manufacture its products. During the normal course of business, the Company’s contract manufacturers procure components based upon orders placed by the Company. If the Company cancels all or part of the orders, it may still be liable to the contract manufacturers for the cost of the components purchased by them to manufacture the Company’s products. The Company periodically reviews the potential liability, and to date, no significant accruals have been recorded.  The Company had inventory purchase obligations of $11.6 million as of September 30, 2015.

[0001511737-15-000029:notes:19]
Other Obligations

[0001511737-15-000029:notes:20]
The Company had other obligations of $6.1 million as of September 30, 2015, which consisted primarily of commitments related to research and development projects.

[0001511737-15-000029:notes:21]
Indemnification Obligations

[0001511737-15-000029:notes:22]
The Company enters into standard indemnification agreements with many of its business partners in the ordinary course of business. These agreements include provisions for indemnifying the business partner against any claim brought by a third party to the extent any such claim alleges that a Company product infringes a patent, copyright or trademark, or violates any other proprietary rights of that third party. The maximum potential amount of future payments the Company could be required to make under these indemnification agreements is not estimable and the Company has not incurred any material costs to defend lawsuits or settle claims related to these indemnification agreements to date.

[0001511737-15-000029:notes:23]
Legal Matters

[0001511737-15-000029:notes:24]
The Company may be involved, from time to time, in a variety of claims, lawsuits, investigations, and proceedings relating to contractual disputes, intellectual property rights, employment matters, regulatory compliance matters and other litigation matters relating to various claims that arise in the normal course of business. The Company determines whether an estimated loss from a contingency should be accrued by assessing whether a loss is deemed probable and can be reasonably estimated. The Company assesses its potential liability by analyzing specific litigation and regulatory matters using available information. The Company develops its views on estimated losses in consultation with inside and outside counsel, which involves a subjective analysis of potential results and outcomes, assuming various combinations of appropriate litigation and settlement strategies. Taking all of the above factors into account, the Company records an amount where it is probable that the Company will incur a loss and where that loss can be reasonably estimated. However, the Company’s estimates may be incorrect and the Company could ultimately incur more or less than the amounts initially recorded.  The Company may also incur significant legal fees, which are expensed as incurred, in defending against these claims.

[0001511737-15-000029:notes:25]
Shareholder Class Action Lawsuits

[0001511737-15-000029:notes:26]
Beginning on September 7, 2012, two class action lawsuits were filed in the United States District Court for the Northern District of California against Ubiquiti Networks, Inc., certain of its officers and directors, and the underwriters of its initial public offering, alleging claims under U.S. securities laws. On January 30, 2013, the plaintiffs filed an amended consolidated complaint. On March 26, 2014, the court issued an order granting a motion to dismiss the complaint with leave to amend. Following the plaintiffs’ decision not to file an amended complaint, on April 16, 2014, the court ordered the dismissal of the lawsuit with prejudice, and entered judgment in favor of the Company and the other defendants, and against the plaintiffs. On May 15, 2014, the plaintiffs filed a notice of appeal from the judgment of the court. The appeal is ongoing before the U.S. Court of Appeals for the Ninth Circuit. There can be no assurance that the Company will prevail in the appeal proceeding.  The Company cannot currently estimate the possible loss, if any, that it may experience in connection with this litigation.


## us-gaap:DebtDisclosureTextBlock

[0001511737-15-000029:notes:27]
DEBT

[0001511737-15-000029:notes:28]
On August 7, 2012, the Company entered into a Loan and Security Agreement (the “Loan Agreement”) with U.S. Bank, as syndication agent, and East West Bank, as administrative agent for the lenders party to the Loan Agreement.  The Loan Agreement provided for (i) a $50.0 million revolving credit facility, with a $5.0 million sublimit for the issuance of letters of credit and a $5.0 million sublimit for the making of swingline loan advances, and (ii) a $50.0 million term loan facility.

[0001511737-15-000029:notes:29]
On May 5, 2014, Ubiquiti Networks, Inc. and certain of its subsidiaries entered into a credit agreement (the “Original Credit Agreement”) with Wells Fargo Bank, National Association (“Wells Fargo”), the financial institutions named as lenders therein, and Wells Fargo as administrative agent for the lenders, that provided for a $150.0 million senior secured revolving credit facility, with an option to request an increase in the amount of the credit facility by up to an additional $50.0 million (any such increase to be in each lender’s sole discretion).  Proceeds from borrowings under the Original Credit Agreement were used to repay the Loan Agreement in full.

[0001511737-15-000029:notes:30]
On March 3, 2015, Ubiquiti Networks, Inc. and Ubiquiti International Holding Company Limited (the “Cayman Borrower”) amended and restated the Original Credit Agreement (the "Amended Credit Agreement") with Wells Fargo, the other financial institutions named as lenders therein, and Wells Fargo as administrative agent for the lenders.  The Amended Credit Agreement provides for a $200.0 million senior secured revolving credit facility and a $100.0 million senior secured term loan facility (collectively, the "Facilities"), with an option to request increases in the amounts of such credit facilities by up to an additional $50.0 million in the aggregate (any such increase to be in each lender’s sole discretion), and matures on March 3, 2020.  The $100.0 million term loan facility of the Amended Credit Agreement was fully drawn at closing, and $72.3 million was used to repay the outstanding balance under the Original Credit Agreement.  As of September 30, 2015, $95 million was outstanding on the term loan and $0 on the revolver.  Subsequent to September 30, 2015, the Company drew $33 million on the revolver.

[0001511737-15-000029:notes:31]
The revolving credit facility includes a sub-limit of $10.0 million for letters of credit and a sub-limit of $25.0 million for swingline loans. The Facilities replaced the Company’s $150.0 million senior secured revolving credit facility under the Original Credit Agreement. The Facilities are available for working capital and general corporate purposes that comply with the terms of the Amended Credit Agreement. Under the Amended Credit Agreement, revolving loans and swingline loans may be borrowed, repaid and reborrowed until March 3, 2020, at which time all amounts borrowed must be repaid. The term loan is payable in quarterly installments of 2.50% of the original principal amount of the term loan until March 31, 2017, thereafter increasing to 3.75% of the original principal amount of the term loan, in each case plus accrued and unpaid interest. Revolving, swingline and term loans may be prepaid at any time without penalty. Revolving and term loans bear interest, at the Company’s option, at either (i) a floating rate per annum equal to the base rate plus a margin of between 0.50% and 1.25%, depending on the Company’s leverage ratio as of the most recently ended fiscal quarter or (ii) a floating per annum rate equal to the applicable LIBOR rate for a specified period, plus a margin of between 1.50% and 2.25%, depending on the Company’s leverage ratio as of the most recently ended fiscal quarter. Swingline loans bear interest at a floating rate per annum equal to the base rate plus a margin of between 0.50% and 1.25%, depending on the Company’s leverage ratio as of the most recently ended fiscal quarter. Base rate is defined as the greatest of (A) Wells Fargo’s prime rate, (B) the federal funds rate plus 0.50% or (C) the applicable LIBOR rate for a period of one month plus 1.00%. A default interest rate shall apply on all obligations during certain events of default under the Amended Credit Agreement at a rate per annum equal to 2.00% above the applicable interest rate. The Company will pay to each lender a facility fee on a quarterly basis based on the unused amount of each lender’s commitment to make revolving loans, of between 0.20% and 0.35%, depending on the Company’s leverage ratio as of the most recently ended fiscal quarter. The Company will also pay to the applicable lenders on a quarterly basis certain fees based on the daily amount available to be drawn under each outstanding letter of credit, including aggregate letter of credit commissions of the LIBOR rate plus a margin of between 1.50% and 2.25%, depending on the Company’s leverage ratio as of the most recently ended fiscal quarter, and issuance fees of 0.125% per annum. The Company is also obligated to pay Wells Fargo, as agent, fees customary for a credit facility of this size and type.

[0001511737-15-000029:notes:32]
The Amended Credit Agreement requires the Company to maintain during the term of the Facilities (i) a maximum leverage ratio of 2.50 to 1.00 and (ii) minimum liquidity of $225.0 million, increasing to $250.0 million in the event of an incremental increase in the size of the Facilities, which can be satisfied with unrestricted cash and cash equivalents and up to $50.0 million of availability under the revolving credit facility. In addition, the Amended Credit Agreement contains customary affirmative and negative covenants, including covenants that limit or restrict the ability of the Company and its subsidiaries to, among other things, grant liens or enter into agreements restricting their ability to grant liens on property, enter into mergers, dispose of assets, change their accounting or reporting policies, change their business and incur indebtedness, in each case subject to customary exceptions for a credit facility of this size and type. The Amended Credit Agreement includes customary events of default that include, among other things, non-payment of principal, interest or fees, inaccuracy of representations and warranties, violation of covenants, cross default to certain other indebtedness, bankruptcy and insolvency events, material judgments, change of control and certain ERISA events. The occurrence of an event of default could result in the acceleration of the obligations under the Amended Credit Agreement.

[0001511737-15-000029:notes:33]
The obligations of Ubiquiti Networks, Inc. and certain domestic subsidiaries, if any, under the Amended Credit Agreement are required to be guaranteed by such domestic subsidiaries (the "Domestic Guarantors") and are collateralized by substantially all assets (excluding intellectual property) of Ubiquiti Networks, Inc. and the Domestic Guarantors. The obligations of the Cayman Borrower and certain foreign subsidiaries under the Amended Credit Agreement are required to be guaranteed by certain domestic and material foreign subsidiaries (the "Guarantors") and are collateralized by substantially all assets (excluding intellectual property) of the Cayman Borrower and the Guarantors.

[0001511737-15-000029:notes:34]
During the three months ended September 30, 2015, the Company made a payment of $2.9 million against the term loan facility balance under the Amended Credit Agreement, of which $2.5 million was a repayment of principal and $444 thousand was payment of interest.  As of September 30, 2015, the Company has classified $10.0 million and $85.0 million as short-term and long-term debt, respectively, on its consolidated balance sheet related to the term loan facility under the Amended Credit Agreement.

[0001511737-15-000029:notes:35]
On September 2, 2015, the Company accessed a letter of credit under its revolving credit facility in the amount of $237 thousand for the benefit of the landlord pursuant to a new lease of office space. The landlord can draw against the letter of credit in the event of default by the Company. The letter of credit expires on September 2, 2016, subject to automatic renewal for additional one-year periods.

[0001511737-15-000029:notes:36]
The following table summarizes our estimated debt and interest payment obligations as of September 30, 2015 for the remainder of fiscal 2016 and future fiscal years (in thousands):

[0001511737-15-000029:notes:37]
|  | 2016 (remainder) |  | 2017 |  | 2018 |  | 2019 |  | 2020 |  | Thereafter |  | Total |
| Debt payment obligations | $ | 7,500 |  |  | $ | 11,250 |  |  | $ | 15,000 |  |  | $ | 15,000 |  |  | $ | 46,250 |  |  | $ | — |  |  | $ | 95,000 |  |
| Interest and other payments on debt payment obligations | 1,521 |  |  | 1,893 |  |  | 1,659 |  |  | 1,392 |  |  | 818 |  |  | — |  |  | 7,283 |  |
| Total | $ | 9,021 |  |  | $ | 13,143 |  |  | $ | 16,659 |  |  | $ | 16,392 |  |  | $ | 47,068 |  |  | $ | — |  |  | $ | 102,283 |  |


## us-gaap:DeferredCostsCapitalizedPrepaidAndOtherAssetsDisclosureTextBlock

[0001511737-15-000029:notes:38]
[same as prior period, unchanged from 0001511737-15-000018:notes:35]

[0001511737-15-000029:notes:39]
|  | September 30, 2015 |  | June 30, 2015 |
| BEC recovery receivable | $ | 5,981 |  |  | $ | 1,376 |  |
| Other current assets | 7,660 |  |  | 6,335 |  |
|  | $ | 13,641 |  |  | $ | 7,711 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001511737-15-000029:notes:40]
[same as prior period, unchanged from 0001511737-15-000018:notes:37]

[0001511737-15-000029:notes:41]
[same as prior period, unchanged from 0001511737-15-000018:notes:38]

[0001511737-15-000029:notes:42]
The Company’s 2010 Equity Incentive Plan and 2005 Equity Incentive Plan are described in its Annual Report. As of September 30, 2015, the Company had 10,010,302 authorized shares available for future issuance under all of its stock incentive plans.

[0001511737-15-000029:notes:43]
Stock-Based Compensation

[0001511737-15-000029:notes:44]
The following table shows total stock-based compensation expense included in the Condensed Consolidated Statements of Operations for the three months ended September 30, 2015 and 2014 (in thousands):

[0001511737-15-000029:notes:45]
|  | Three Months Ended September 30, |
|  | 2015 |  | 2014 |
| Cost of sales | $ | 113 |  |  | $ | 149 |  |
| Research and development | 624 |  |  | 825 |  |
| Sales, general and administrative | 290 |  |  | 398 |  |
|  | $ | 1,027 |  |  | $ | 1,372 |  |

[0001511737-15-000029:notes:46]
[same as prior period, unchanged from 0001511737-15-000018:notes:43]

[0001511737-15-000029:notes:47]
The following is a summary of option activity for the Company’s stock incentive plans for the three months ended September 30, 2015:

[0001511737-15-000029:notes:48]
|  | Common Stock Options Outstanding |
|  | Numberof Shares |  | WeightedAverageExercisePrice |  | WeightedAverageRemainingContractualLife (Years) |  | AggregateIntrinsicValue(In thousands) |
| Balance, June 30, 2015 | 2,301,144 |  |  | $ | 2.38 |  |  |  |  |  |
| Exercised | (52,452 | ) |  | 5.84 |  |  |  |  |  |
| Forfeitures and cancellations | (448 | ) |  | 25.47 |  |  |  |  |  |
| Balance, September 30, 2015 | 2,248,244 |  |  | 2.30 |  |  | 3.49 |  | $ | 71,027 |  |
| Vested and expected to vest as of September 30, 2015 | 2,244,333 |  |  | $ | 2.28 |  |  | 3.49 |  | $ | 70,940 |  |
| Vested and exercisable as of September 30, 2015 | 2,143,271 |  |  | $ | 1.85 |  |  | 3.32 |  | $ | 68,663 |  |

[0001511737-15-000029:notes:49]
During the three months ended September 30, 2015 and 2014, the aggregate intrinsic value of options exercised under the Company’s stock incentive plans was $1.5 million and $4.9 million, respectively, as determined as of the date of option exercise.

[0001511737-15-000029:notes:50]
As of September 30, 2015, the Company had unrecognized compensation costs of $0.5 million related to stock options which the Company expects to recognize over a weighted-average period of 1.2 years. Future option grants will increase the amount of compensation expense to be recorded in these periods.

[0001511737-15-000029:notes:51]
The Company estimates the fair value of employee stock options using the Black-Scholes option pricing model. The fair value of employee stock options is amortized on a straight-line basis over the requisite service period of the awards.  The Company did not grant any employee stock options during the three months ended September 30, 2015 and 2014.

[0001511737-15-000029:notes:52]
[same as prior period, unchanged from 0001511737-15-000018:notes:49]

[0001511737-15-000029:notes:53]
[same as prior period, unchanged from 0001511737-15-000018:notes:50]

[0001511737-15-000029:notes:54]
|  | Number of Shares |  | Weighted Average Grant Date Fair Value Per Share |
| Non-vested RSUs, June 30, 2015 | 400,635 |  |  | $ | 26.95 |  |
| RSUs granted | 43,650 |  |  | 32.92 |  |
| RSUs vested | (57,542 | ) |  | 19.43 |  |
| RSUs canceled | (43,876 | ) |  | 31.37 |  |
| Non-vested RSUs, September 30, 2015 | 342,867 |  |  | $ | 28.41 |  |

[0001511737-15-000029:notes:55]
The intrinsic value of RSUs vested in the three months ended September 30, 2015 and 2014 was $1.9 million and $2.7 million, respectively.

[0001511737-15-000029:notes:56]
As of September 30, 2015, there were unrecognized compensation costs related to RSUs of $7.2 million which the Company expects to recognize over a weighted average period of three years.


## us-gaap:EarningsPerShareTextBlock

[0001511737-15-000029:notes:57]
[same as prior period, unchanged from 0001511737-15-000018:notes:54]

[0001511737-15-000029:notes:58]
[same as prior period, unchanged from 0001511737-15-000018:notes:55]

[0001511737-15-000029:notes:59]
|  | Three Months Ended September 30, |
|  | 2015 |  | 2014 |
| Numerator: |  |
| Net income and comprehensive income | $ | 53,759 |  |  | $ | 37,743 |  |
| Denominator: |  |
| Weighted-average shares used in computing basic net income per share | 87,062 |  |  | 88,240 |  |
| Add—dilutive potential common shares: |  |  |  |
| Stock options | 1,302 |  |  | 1,481 |  |
| Restricted stock units | 101 |  |  | 192 |  |
| Weighted-average shares used in computing diluted net income per share | 88,465 |  |  | 89,913 |  |
| Net income per share of common stock: |  |
| Basic | $ | 0.62 |  |  | $ | 0.43 |  |
| Diluted | $ | 0.61 |  |  | $ | 0.42 |  |

[0001511737-15-000029:notes:60]
The Company excludes potentially dilutive securities from its diluted net income per share calculation when their effect would be antidilutive to net income per share amounts.  The following table summarizes the total potential shares of common stock that were excluded from the diluted per share calculation as including them would have been antidilutive for the period (in thousands):

[0001511737-15-000029:notes:61]
|  | Three Months Ended September 30, |
|  | 2015 |  | 2014 |
| Restricted stock units | 39 |  |  | 2 |  |


## us-gaap:FairValueAssetsAndLiabilitiesMeasuredOnRecurringAndNonrecurringBasisTableTextBlock

[0001511737-15-000029:notes:62]
As of September 30, 2015 and June 30, 2015, the fair value hierarchy of the Company’s debt carried at historical cost was as follows (in thousands):

[0001511737-15-000029:notes:63]
|  | September 30, 2015 |  | June 30, 2015 |
|  | FairValue |  | Level 1 |  | Level 2 |  | Level 3 |  | FairValue |  | Level 1 |  | Level 2 |  | Level 3 |
| Debt | $ | 95,000 |  |  | $ | — |  |  | $ | 95,000 |  |  | $ | — |  |  | $ | 97,500 |  |  | $ | — |  |  | $ | 97,500 |  |  | $ | — |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001511737-15-000029:notes:64]
[same as prior period, unchanged from 0001511737-15-000018:notes:61]

[0001511737-15-000029:notes:65]
[same as prior period, unchanged from 0001511737-15-000018:notes:62]

[0001511737-15-000029:notes:66]
[same as prior period, unchanged from 0001511737-15-000018:notes:63]

[0001511737-15-000029:notes:67]
[same as prior period, unchanged from 0001511737-15-000018:notes:64]

[0001511737-15-000029:notes:68]
[same as prior period, unchanged from 0001511737-15-000018:notes:65]

[0001511737-15-000029:notes:69]
For certain of the Company’s financial instruments, including accounts receivable and accounts payable, the carrying amounts approximate fair value due to their short maturities.  Additionally, as of September 30, 2015, we held $410.1 million of our $436.1 million of cash and cash equivalents in accounts of our subsidiaries outside of the United States and we would incur significant tax liabilities if we were to repatriate those amounts.

[0001511737-15-000029:notes:70]
At September 30, 2015 and June 30, 2015 the Company had debt associated with its Amended Credit Agreement with Wells Fargo Bank (See Note 7). The fair value of the Company’s debt was estimated based on the current rates offered to the Company for debt with similar terms and remaining maturities and was Level 2 measurement.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001511737-15-000029:notes:71]
[same as prior period, unchanged from 0001511737-15-000018:notes:68]

[0001511737-15-000029:notes:72]
As of September 30, 2015, the Company had approximately $20.6 million of unrecognized tax benefits, substantially all of which would, if recognized, affect its tax expense. The Company has elected to include interest and penalties related to uncertain tax positions as a component of tax expense. At September 30, 2015, an insignificant amount of interest and penalties are included in long-term income tax payable. The Company recorded a net increase of its unrecognized tax benefits of $1.0 million for the three months ended September 30, 2015. The Company does not expect any significant increases or decreases to its unrecognized tax benefits in the next twelve months.

[0001511737-15-000029:notes:73]
The Company recorded a tax provision of $6.0 million  for the three months ended September 30, 2015. The Company’s estimated fiscal 2016 effective tax rate differs from the U.S. statutory rate primarily due to profits earned in jurisdictions where the tax rate is lower than the U.S. tax rate.

[0001511737-15-000029:notes:74]
The Company files U.S. federal income tax returns as well as income tax returns in various states and foreign jurisdictions. The Company’s tax filings from fiscal 2010 and onwards could be subject to examinations by tax authorities.

[0001511737-15-000029:notes:75]
On July 27, 2015, in Altera Corp. v. Commissioner, the U.S. Tax Court issued an opinion related to the treatment of stock-based compensation expense in an intercompany cost-sharing arrangement. A final decision has yet to be issued by the Tax Court due to other outstanding issues related to the case. At this time, the U.S. Department of the Treasury has not withdrawn the requirement to include stock-based compensation from its regulations. We have reviewed this case and its potential impact on Ubiquiti and concluded that no adjustment to the condensed consolidated financial statements is appropriate at this time. We will continue to monitor ongoing developments and potential impacts to our consolidated financial statements.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001511737-15-000029:notes:76]
Recent Accounting Pronouncements

[0001511737-15-000029:notes:77]
In June 2014, the Financial Accounting Standards Board, or FASB, issued a new accounting standard update on revenue from contracts with customers.  The core principle of the guidance is that an entity should recognize revenue to depict the transfer of promised goods or services to customers in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services.  To achieve that core principle, an entity should apply the following steps:

[0001511737-15-000029:notes:78]
Step 1: Identify the contract(s) with a customer.

[0001511737-15-000029:notes:79]
Step 2: Identify the performance obligations in the contract.

[0001511737-15-000029:notes:80]
Step 3: Determine the transaction price.

[0001511737-15-000029:notes:81]
Step 4: Allocate the transaction price to the performance obligations in the contract.

[0001511737-15-000029:notes:82]
Step 5: Recognize revenue when (or as) the entity satisfies a performance obligation.

[0001511737-15-000029:notes:83]
An entity should disclose sufficient information to enable users of financial statements to understand the nature, amount, timing, and uncertainty of revenue and cash flows arising from contracts with customers. Qualitative and quantitative information is required about contracts with customers, significant judgments and any assets recognized from the costs to obtain or fulfill a contract.   The guidance was initially effective for annual and interim reporting periods beginning after December 15, 2016.  However, in April 2015, the FASB issued a proposal to defer the effective date by one year, to December 15, 2017, to provide adequate time to effectively implement the new standard.  The Company does not anticipate that the new guidance will have a material impact on its consolidated financial statements.

[0001511737-15-000029:notes:84]
In April 2015, the FASB issued an accounting standard update on simplifying the presentation of debt issuance costs.  The updated guidance requires that debt issuance costs related to a recognized debt liability be presented in the balance sheet as a direct deduction from the carrying amount of that debt liability, consistent with debt discounts. The recognition and measurement guidance for debt issuance costs are not affected by the updated guidance.  The guidance will be effective for the Company beginning July 1, 2016.  The guidance will result only in a reclassification on the Company’s balance sheet and is not expected to have any effect on the Company’s operating results.

[0001511737-15-000029:notes:85]
Additionally, in July 2015, the FASB issued Accounting Standards Update (ASU) 2015-11 which explains how the Accounting Standards Codification will be updated to simplify the measurement of inventory costs.  The updated guidance requires that inventory be valued at the lower of cost or net realizable value.  This differs from current guidance which requires that inventory be valued at the lower of cost or market, where market can be replacement cost, net realizable value or net realizable value less an approximately normal profit margin.  The guidance will be effective for the Company beginning July 1, 2016.  We do not anticipate that this guidance will have a material impact on the presentation of the Company’s consolidated financial statements.


## us-gaap:OtherCurrentLiabilitiesTableTextBlock

[0001511737-15-000029:notes:86]
Other current liabilities consisted of the following (in thousands):

[0001511737-15-000029:notes:87]
|  | September 30, 2015 |  | June 30, 2015 |
| Accrued expenses | $ | 7,862 |  |  | $ | 5,540 |  |
| Accrued compensation and benefits | 2,308 |  |  | 2,142 |  |
| Warranty accrual | 2,155 |  |  | 2,750 |  |
| Deferred revenue - short term | 2,617 |  |  | 2,538 |  |
| Customer deposits | 1,121 |  |  | 63 |  |
| Reserve for sales returns | 1,355 |  |  | 1,227 |  |
| Other payables | 10,683 |  |  | 910 |  |
|  | $ | 28,101 |  |  | $ | 15,170 |  |


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001511737-15-000029:notes:88]
[same as prior period, unchanged from 0001511737-15-000018:notes:81]

[0001511737-15-000029:notes:89]
The Company offers warranties on certain products, generally for a period of one year, and records a liability for the estimated future costs associated with potential warranty claims. The warranty costs are reflected in the Company’s consolidated statement of operations within cost of revenues. The warranties are typically in effect for twelve months from the distributor’s purchase date of the product. The Company’s estimate of future warranty costs is largely based on historical factors including product failure rates, material usage, and service delivery cost incurred in replacing products. In certain circumstances, the Company may have recourse from its contract manufacturers for replacement cost of defective products, which it also factors into its warranty liability assessment.

[0001511737-15-000029:notes:90]
[same as prior period, unchanged from 0001511737-15-000018:notes:83]

[0001511737-15-000029:notes:91]
|  | Three Months Ended September 30, |
|  | 2015 |  | 2014 |
| Beginning balance | $ | 2,750 |  |  | $ | 2,850 |  |
| Accruals for warranties issued during the period | 120 |  |  | 788 |  |
| Settlements made during the period | (715 | ) |  | (788 | ) |
|  | $ | 2,155 |  |  | $ | 2,850 |  |


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0001511737-15-000029:notes:92]
Property and equipment, net consisted of the following (in thousands):

[0001511737-15-000029:notes:93]
|  | September 30, 2015 |  | June 30, 2015 |
| Testing equipment | $ | 5,156 |  |  | $ | 4,816 |  |
| Computer and other equipment | 4,523 |  |  | 4,458 |  |
| Tooling equipment | 4,273 |  |  | 4,073 |  |
| Furniture and fixtures | 1,263 |  |  | 1,239 |  |
| Leasehold improvements | 4,836 |  |  | 4,789 |  |
| Software | 3,268 |  |  | 3,268 |  |
| Internal-use software in development (1) | 3,624 |  |  | 2,700 |  |
| Construction in progress | 40 |  |  | — |  |
|  | 26,983 |  |  | 25,343 |  |
| Less: Accumulated depreciation and amortization (2) | (11,228 | ) |  | (9,741 | ) |
|  | $ | 15,755 |  |  | $ | 15,602 |  |

[0001511737-15-000029:notes:94]
(1) - $924 thousand was capitalized in the first quarter of fiscal 2016 for internal-use software development.

[0001511737-15-000029:notes:95]
(2) - Depreciation expense was $1.49 million in the first quarter of fiscal 2016.


## us-gaap:ReconciliationOfRevenueFromSegmentsToConsolidatedTextBlock

[0001511737-15-000029:notes:96]
[same as prior period, unchanged from 0001511737-15-000018:notes:87]

[0001511737-15-000029:notes:97]
|  | Three Months Ended September 30, |
|  | 2015 |  | 2014 |
| Service Provider Technology | $ | 103,399 |  |  | 68 | % |  | $ | 107,271 |  |  | 71 | % |
| Enterprise Technology | 48,016 |  |  | 32 | % |  | 42,816 |  |  | 29 | % |
| Total revenues | $ | 151,415 |  |  | 100 | % |  | $ | 150,087 |  |  | 100 | % |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001511737-15-000029:notes:98]
RELATED PARTY TRANSACTIONS AND CERTAIN OTHER TRANSACTIONS

[0001511737-15-000029:notes:99]
Aircraft Lease Agreement

[0001511737-15-000029:notes:100]
On November 13, 2013, the Company entered into an aircraft lease agreement (the "Aircraft Lease Agreement") with RJP Manageco LLC (the "Lessor"), a limited liability company owned by the Company’s CEO, Robert J. Pera. Pursuant to the Aircraft Lease Agreement, the Company may lease an aircraft owned by the Lessor for Company business purposes. Under the Aircraft Lease Agreement, the aircraft may be leased at a rate of $5,000 per flight hour. This hourly rate does not include the cost of flight crew or on-board services, which the Company purchases from a third-party provider. The Company recognized a total of approximately $213 thousand in expenses pursuant to the Aircraft Lease Agreement during the three months ended September 30, 2015.  All expenses pursuant to the Aircraft Lease Agreement have been included in the Company’s sales, general and administrative expenses in the Condensed Consolidated Statements of Operations.


## us-gaap:RevenueFromExternalCustomersByGeographicAreasTableTextBlock

[0001511737-15-000029:notes:101]
[same as prior period, unchanged from 0001511737-15-000018:notes:91]

[0001511737-15-000029:notes:102]
|  | Three Months Ended September 30, |
|  | 2015 |  | 2014 |
| North America (1) | $ | 53,234 |  |  | 35 | % |  | $ | 53,582 |  |  | 35 | % |
| South America | 22,148 |  |  | 15 | % |  | 31,134 |  |  | 21 | % |
| Europe, the Middle East and Africa | 60,503 |  |  | 40 | % |  | 50,607 |  |  | 34 | % |
| Asia Pacific | 15,530 |  |  | 10 | % |  | 14,764 |  |  | 10 | % |
| Total revenues | $ | 151,415 |  |  | 100 | % |  | $ | 150,087 |  |  | 100 | % |

[0001511737-15-000029:notes:103]
| (1) | Revenue for the United States was $50.6 million and $52.0 million for the three months ended September 30, 2015 and 2014, respectively. |


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0001511737-15-000029:notes:104]
[same as prior period, unchanged from 0001511737-15-000018:notes:96]

[0001511737-15-000029:notes:105]
|  | September 30, 2015 |  | June 30, 2015 |
| Finished goods | $ | 29,702 |  |  | $ | 35,848 |  |
| Raw materials | 992 |  |  | 1,183 |  |
|  | $ | 30,694 |  |  | $ | 37,031 |  |


## us-gaap:ScheduleOfOtherAssetsNoncurrentTextBlock

[0001511737-15-000029:notes:106]
Other long-term assets consisted of the following (in thousands):

[0001511737-15-000029:notes:107]
|  | September 30, 2015 |  | June 30, 2015 |
| Intangible assets, net (1) | $ | 518 |  |  | $ | 575 |  |
| Debt issuance costs, net (2) | 878 |  |  | 943 |  |
| Other long-term assets | 624 |  |  | 591 |  |
|  | $ | 2,020 |  |  | $ | 2,109 |  |

[0001511737-15-000029:notes:108]
(1) - Accumulated amortization was $755 thousand and $690 thousand as of September 30, 2015 and June 30, 2015, respectively.

[0001511737-15-000029:notes:109]
(2) - Accumulated amortization was $148 thousand and $84 thousand as of September 30, 2015 and June 30, 2015, respectively.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001511737-15-000029:notes:110]
[same as prior period, unchanged from 0001511737-15-000018:notes:98]

[0001511737-15-000029:notes:111]
Management has determined that the Company operates as one reportable and operating segment as it only reports financial information on an aggregate and consolidated basis to its chief executive officer, who is the Company’s chief operating decision maker.  Furthermore, the Company does not organize or report its costs on a segment basis.  The Company presents its revenues by product type in two primary categories, including Service Provider Technology and Enterprise Technology.

[0001511737-15-000029:notes:112]
| • | Service Provider Technology includes the Company’s airMAX, EdgeMAX and airFiber platforms, as well as embedded radio products and other 802.11 standard products including base stations, radios, backhaul equipment and Customer Premise Equipment (“CPE”). Additionally, Service Provider Technology includes antennas and other products in the 0.9 to 6.0GHz spectrum and miscellaneous products such as mounting brackets, cables and power over Ethernet adapters. Service Provider Technology also includes revenues that are attributable to post contract support ("PCS"). |

[0001511737-15-000029:notes:113]
| • | Enterprise Technology includes the Company’s UniFi and mFi platforms, including Unifi Access Point ("UAP") products, Unifi Video products, Unifi Voice Over IP ("VOIP") phones and Unifi switch products. |

[0001511737-15-000029:notes:114]
*  denotes less than 10%


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001511737-15-000029:notes:115]
[same as prior period, unchanged from 0001511737-15-000018:notes:102]

[0001511737-15-000029:notes:116]
The Company’s significant accounting policies are disclosed in its audited consolidated financial statements for the year ended June 30, 2015 included in the Annual Report.   Except as noted below, there have been no changes to the Company’s significant accounting policies as discussed in the Annual Report.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001511737-15-000029:notes:117]
[same as prior period, unchanged from 0001511737-15-000018:notes:106]

[0001511737-15-000029:notes:118]
As of September 30, 2015 and June 30, 2015, the authorized capital of the Company included 500,000,000 shares of common stock.  As of September 30, 2015 and June 30, 2015, there were 85,635,097 and 87,413,777 shares of common stock outstanding, respectively.

[0001511737-15-000029:notes:119]
[same as prior period, unchanged from 0001511737-15-000018:notes:110]

[0001511737-15-000029:notes:120]
Effective August 7, 2015, the Board of Directors approved a $100 million stock repurchase program. Under the stock repurchase program, the Company was authorized to repurchase up to $100 million of its common stock.  All common stock repurchased by the Company is immediately retired.  Upon retirement, the excess over par value is recorded as a reduction in Additional Paid-in Capital until the balance is reduced to zero, with any additional excess recorded to Retained Earnings.  Through September 30, 2015, the share repurchase program was funded from existing cash on hand.  Subsequent to the first quarter of fiscal 2016, the program was also funded in part with draws on the revolving credit facility of the Amended Credit Agreement.  In the first quarter of fiscal 2016, the Company repurchased 1,872,469 shares of its common stock at an average price per share of $33.79 for an aggregate amount of $63.3 million. This included unpaid stock repurchases of $9.5 million relating to repurchases executed on or prior to September 30, 2015 for trades that settled after September 30, 2015.  Of the $63.3 million of repurchases and retirements, $1.1 million was recorded against Additional Paid-in Capital and $62.2 million to Retained Earnings.  Subsequent to September 30, 2015, the Company repurchased an additional 1,074,749 shares, extinguishing the full $100 million of availability under this stock repurchase program.

[0001511737-15-000029:notes:121]
Effective November 6, 2015, the Board of Directors of the Company approved a $50 million stock repurchase program.  Under the new stock repurchase program, the Company may repurchase up to $50 million of its common stock.  The plan expires on September 30, 2016.

[0001511737-15-000029:notes:122]
Dividend Distribution

[0001511737-15-000029:notes:123]
On September 30, 2014, the Company announced that its Board of Directors had approved an annual dividend. The Company declared a dividend of $0.17 per share on September 30, 2014.  The aggregate amount of $15.0 million was paid on October 28, 2014 to stockholders of record on October 17, 2014. The Company currently has no plans to pay a cash dividend at this time or at any time in the foreseeable future.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001511737-15-000029:notes:124]
[same as prior period, unchanged from 0001511737-15-000018:notes:114]

[0001511737-15-000029:notes:125]
[same as prior period, unchanged from 0001511737-15-000018:notes:115]

[0001511737-15-000029:notes:126]
[same as prior period, unchanged from 0001511737-15-000018:notes:116]

[0001511737-15-000029:notes:127]
[same as prior period, unchanged from 0001511737-15-000018:notes:117]

[0001511737-15-000029:notes:128]
Other Long-term Assets

[0001511737-15-000029:notes:129]
[same as prior period, unchanged from 0001511737-15-000018:notes:118]


## us-gaap:UnusualOrInfrequentItemsDisclosureTextBlock

[0001511737-15-000029:notes:130]
BUSINESS EMAIL COMPROMISE FRAUD LOSS

[0001511737-15-000029:notes:131]
As disclosed in Note 14 of the Annual Report, in June 2015 the Company determined that it was the victim of criminal fraud known to law enforcement authorities as business e-mail compromise fraud which involved employee impersonation and fraudulent requests targeting our finance department.  The fraud resulted in transfers of funds aggregating $46.7 million held by a Company subsidiary incorporated in Hong Kong to other overseas accounts held by third parties.  As of June 30, 2015, the Company had recovered $8.1 million.  As a result, the Company recorded a charge of $39.1 million in the fourth quarter of fiscal 2015, including additional expenses consisting of professional service fees associated with the fraud loss.  During the three months ended September 30, 2015, the Company secured a court order for an additional recovery of $8.6 million.  As a result, the Company recorded a net recovery of $8.0 million in the first quarter of fiscal 2016, comprised of the $8.6 million recovery less $564 thousand of professional service fees associated with the recovery.  As of September 30, 2015, $6.0 million of the $8.6 million recovery was recorded as receivable.

[0001511737-15-000029:notes:132]
The Company is continuing to pursue the recovery of the remaining $30.0 million and is cooperating with U.S. federal and numerous overseas law enforcement authorities who are actively pursuing a multi-agency criminal investigation.  Any additional recoveries cannot be assured.
