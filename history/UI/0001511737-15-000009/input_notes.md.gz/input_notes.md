# UI notes — 0001511737-15-000009


## ubnt:ScheduleOfRevenueAndAccountsReceivableByMajorCustomersByReportingSegmentsTableTableTextBlock

[0001511737-15-000009:notes:1]
Customers with an accounts receivable balance of 10% or greater of total accounts receivable and customers with net revenues of 10% or greater of total revenues are presented below for the periods indicated:

[0001511737-15-000009:notes:2]
|  | Percentage of Revenues |  | Percentage of Accounts Receivable |
|  | Three Months Ended December 31, |  | Six Months Ended December 31, |  | December 31, |  | June 30, |
|  | 2014 |  | 2013 |  | 2014 |  | 2013 |  | 2014 |  | 2014 |
| Customer A | 13 | % |  | * |  |  | 11 | % |  | * |  |  | 20 | % |  | 12 | % |
| Customer B | 12 | % |  | 17 | % |  | 11 | % |  | 14 | % |  | 13 | % |  | 13 | % |
| Customer C | * |  |  | * |  |  | * |  |  | * |  |  | * |  |  | 12 | % |

[0001511737-15-000009:notes:3]
*  denotes less than 10%


## us-gaap:BusinessDescriptionAndBasisOfPresentationTextBlock

[0001511737-15-000009:notes:4]
[same as prior period, unchanged from 0001511737-14-000030:notes:1]

[0001511737-15-000009:notes:5]
[same as prior period, unchanged from 0001511737-14-000030:notes:2]

[0001511737-15-000009:notes:6]
Ubiquiti Networks, Inc. and its wholly owned subsidiaries (collectively, “Ubiquiti” or the “Company”) develops high performance networking technology for service providers and enterprises.

[0001511737-15-000009:notes:7]
[same as prior period, unchanged from 0001511737-14-000030:notes:4]

[0001511737-15-000009:notes:8]
[same as prior period, unchanged from 0001511737-14-000030:notes:5]

[0001511737-15-000009:notes:9]
These condensed consolidated financial statements should be read in conjunction with the Company’s audited consolidated financial statements for the fiscal year ended June 30, 2014 included in its Annual Report on Form 10-K, as filed on August 22, 2014 with the SEC (the “Annual Report”). The results of operations for the three and six months ended December 31, 2014 are not necessarily indicative of the results to be expected for any future periods.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001511737-15-000009:notes:10]
COMMITMENTS AND CONTINGENCIES

[0001511737-15-000009:notes:11]
Operating Leases

[0001511737-15-000009:notes:12]
Certain facilities and equipment are leased under noncancelable operating leases. The Company generally pays taxes, insurance and maintenance costs on leased facilities and equipment. The Company leases office space in San Jose, California and other locations under various non-cancelable operating leases that expire at various dates through 2019.

[0001511737-15-000009:notes:13]
At December 31, 2014, future minimum annual payments under operating leases are as follows (in thousands):

[0001511737-15-000009:notes:14]
|  | 2015 (remainder) |  | 2016 |  | 2017 |  | 2018 |  | 2019 |  | Thereafter |  | Total |
| Operating leases | $ | 1,690 |  |  | $ | 3,270 |  |  | $ | 1,903 |  |  | $ | 506 |  |  | $ | 53 |  |  | $ | — |  |  | $ | 7,422 |  |

[0001511737-15-000009:notes:15]
Purchase Obligations

[0001511737-15-000009:notes:16]
The Company primarily subcontracts with other companies to manufacture its products. During the normal course of business, the Company’s contract manufacturers procure components based upon orders placed by the Company. If the Company cancels all or part of the orders, it may still be liable to the contract manufacturers for the cost of the components purchased by them to manufacture the Company’s products. The Company periodically reviews the potential liability and to date no significant accruals have been recorded.

[0001511737-15-000009:notes:17]
Other Obligations

[0001511737-15-000009:notes:18]
The Company had other obligations of $487,000 as of December 31, 2014, which consisted primarily of commitments to acquire capital assets, including manufacturing equipment.

[0001511737-15-000009:notes:19]
Indemnification Obligations

[0001511737-15-000009:notes:20]
The Company enters into standard indemnification agreements with many of its business partners in the ordinary course of business. These agreements include provisions for indemnifying the business partner against any claim brought by a third party to the extent any such claim alleges that a Company product infringes a patent, copyright or trademark, or violates any other proprietary rights of that third party. The maximum potential amount of future payments the Company could be required to make under these indemnification agreements is not estimable and the Company has not incurred any material costs to defend lawsuits or settle claims related to these indemnification agreements to date.

[0001511737-15-000009:notes:21]
Legal Matters

[0001511737-15-000009:notes:22]
The Company may be involved, from time to time, in a variety of claims, lawsuits, investigations, and proceedings relating to contractual disputes, intellectual property rights, employment matters, regulatory compliance matters and other litigation matters relating to various claims that arise in the normal course of business. The Company determines whether an estimated loss from a contingency should be accrued by assessing whether a loss is deemed probable and can be reasonably estimated. The Company assesses its potential liability by analyzing specific litigation and regulatory matters using available information. The Company develops its views on estimated losses in consultation with inside and outside counsel, which involves a subjective analysis of potential results and outcomes, assuming various combinations of appropriate litigation and settlement strategies. Taking all of the above factors into account, the Company records an amount where it is probable that the Company will incur a loss and where that loss can be reasonably estimated. However, the Company’s estimates may be incorrect and the Company could ultimately incur more or less than the amounts initially recorded.  The Company may also incur significant legal fees, which are expensed as incurred, in defending against these claims.

[0001511737-15-000009:notes:23]
Shareholder Class Action Lawsuits

[0001511737-15-000009:notes:24]
Beginning on September 7, 2012, two class action lawsuits were filed in the United States District Court for the Northern District of California against Ubiquiti Networks, Inc., certain of its officers and directors, and the underwriters of its initial public offering, alleging claims under U.S. securities laws. On January 30, 2013, the plaintiffs filed an amended consolidated complaint. On March 26, 2014, the court issued an order granting a motion to dismiss the complaint with leave to amend. Following the plaintiffs’ decision not to file an amended complaint, on April 16, 2014, the court ordered the dismissal of the lawsuit with prejudice, and entered judgment in favor of the Company and the other defendants, and against the plaintiffs. On May 15, 2014, the plaintiffs filed a notice of appeal from the judgment of the court. The appeal is ongoing before the U.S. Court of Appeals for the Ninth Circuit. There can be no assurance that the Company will prevail in the appeal proceeding.  The Company cannot currently estimate the possible loss, if any, that it may experience in connection with this litigation.


## us-gaap:DebtDisclosureTextBlock

[0001511737-15-000009:notes:25]
DEBT

[0001511737-15-000009:notes:26]
On August 7, 2012, the Company entered into a Loan and Security Agreement (the “Loan Agreement”) with U.S. Bank, as syndication agent, and East West Bank, as administrative agent for the lenders party to the Loan Agreement.  The Loan Agreement provides for (i) a $50.0 million revolving credit facility, with a $5.0 million sublimit for the issuance of letters of credit and a $5.0 million sublimit for the making of swingline loan advances (the “Revolving Credit Facility”), and (ii) a $50.0 million term loan facility (the “Term Loan Facility”).  The Loan Agreement replaced a previous agreement whereby the Company had an existing term loan balance of $29.2 million as of the date the new Loan Agreement.  On August 7, 2012, the Company borrowed $20.8 million under the Term Loan Facility, and no borrowings remain available for borrowing thereunder.  On November 21, 2012, the Company borrowed $10.0 million under the Revolving Credit Facility. On December 20, 2012, the Company borrowed an additional $20.0 million under the Revolving Credit Facility, and $20.0 million remained available for borrowing thereunder.  During the three and six months ended December 31, 2013 the Company made aggregate payments of $1.3 million and $2.5 million against the loan balance, respectively.

[0001511737-15-000009:notes:27]
On May 5, 2014, the Company and certain of its subsidiaries entered into a credit agreement (the “Credit Agreement”) with Wells Fargo Bank, National Association (“Wells Fargo”), the financial institutions named as lenders therein, and Wells Fargo as administrative agent for the lenders, that provides for a $150 million senior secured revolving credit facility, with an option to request an increase in the amount of the credit facility by up to an additional $50 million (any such increase to be in each lender’s sole discretion).  The Company may borrow up to $110 million of the facility as a U.S. sublimit.  The entire amount of the facility is available to Ubiquiti International Holding Company Limited, a wholly-owned subsidiary of the Company organized under the laws of the Cayman Islands.  The credit facility includes a sub-limit of $5 million for letters of credit and a sub-limit of $15 million for swingline loans.   In connection with the execution of the Credit Agreement, the Company terminated the $50 million line of credit facility under the Loan Agreement with East West Bank described above.  Under the Credit Agreement, revolving loans and swingline loans may be borrowed, repaid and reborrowed until May 5, 2019, at which time all amounts borrowed must be repaid.   Additionally, as of December 31, 2014, $72.3 million is outstanding under the Credit Agreement, which was borrowed by the Company to repay obligations under the Loan Agreement and to pay transaction fees and costs.  Revolving loans bear interest, at the Company’s option, at either (i) a floating rate per annum equal to the base rate plus a margin of between 0.250% and 1.000%, depending on the Company’s leverage ratio as of the most recently ended fiscal quarter or (ii) a per annum rate equal to the applicable LIBOR rate for a specified period, plus a margin of between 1.250% and 2.000%, depending on the Company’s leverage ratio as of the most recently ended fiscal quarter.  Swingline loans will bear interest at a floating rate per annum equal to the base rate plus a margin of between 0.250% and 1.000%, depending on the Company’s leverage ratio as of the most recently ended fiscal quarter.   Base rate is defined as the greatest of (A) Wells Fargo’s prime rate, (B) the federal funds rate plus 0.500% or (C) a per annum rate equal to the rate at which dollar deposits are offered in the London interbank market for a period of one month plus 1.000%.  A default interest rate shall apply on all obligations during a payment event of default under the Credit Agreement at a rate per annum equal to 2.000% above the applicable interest rate. The Company will pay to each lender a facility fee on a quarterly basis based on the unused amount of each lender’s commitment to make loans, of between 0.200% and 0.350%, depending on the Company’s leverage ratio as of the most recently ended fiscal quarter.  Revolving loans and swingline loans may be prepaid at any time without penalty.  The Company is also obligated to pay Wells Fargo, as agent, fees customary for a credit facility of this size and type.

[0001511737-15-000009:notes:28]
The Credit Agreement requires the Company to maintain a maximum leverage ratio and a minimum interest coverage ratio during the term of the credit facility.  In addition, the Credit Agreement contains customary affirmative and negative covenants, including covenants that limit or restrict the ability of the Company and its subsidiaries to, among other things, grant liens or enter into agreements restricting their ability to grant liens on property, enter into mergers, dispose of assets, change their accounting or reporting policies, change their business and incur subsidiary indebtedness, in each case subject to customary exceptions for a credit facility of this size and type.  The Credit Agreement includes customary events of default that, include among other things, non-payment of principal, interest or fees, inaccuracy of representations and warranties, violation of covenants, cross default to certain other indebtedness, bankruptcy and insolvency events, material judgments, change of control and certain ERISA events. The occurrence of an event of default could result in the acceleration of the obligations under the Credit Agreement.  The credit facility under the Credit Agreement expires May 5, 2019.

[0001511737-15-000009:notes:29]
The obligations of the Company and its subsidiaries under the Credit Agreement are collateralized by substantially all assets (excluding intellectual property) of the Company and its subsidiaries.

[0001511737-15-000009:notes:30]
Wells Fargo and the lenders party to the Credit Agreement, and certain of their respective affiliates, have provided, and in the future may provide, financial, banking and related services to the Company. These parties have received, and in the future may receive, compensation from the Company for these services.

[0001511737-15-000009:notes:31]
No payments were made for borrowings under the Credit Agreement with Wells Fargo during the three and six months ended December 31, 2014.  As of December 31, 2014, the Company has classified $72.3 million of long-term debt on its consolidated balance sheet related to the Credit Agreement.

[0001511737-15-000009:notes:32]
The following table summarizes our estimated debt and interest payment obligations as of December 31, 2014 (in thousands):

[0001511737-15-000009:notes:33]
|  | 2015 (remainder) |  | 2016 |  | 2017 |  | 2018 |  | 2019 |  | Total |
| Debt payment obligations | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 72,254 |  |  | $ | 72,254 |  |
| Interest payments on debt payment obligations | 510 |  |  | 1,019 |  |  | 1,019 |  |  | 1,019 |  |  | 863 |  |  | 4,430 |  |
| Total | $ | 510 |  |  | $ | 1,019 |  |  | $ | 1,019 |  |  | $ | 1,019 |  |  | $ | 73,117 |  |  | $ | 76,684 |  |


## us-gaap:DeferredCostsCapitalizedPrepaidAndOtherAssetsDisclosureTextBlock

[0001511737-15-000009:notes:34]
[same as prior period, unchanged from 0001511737-14-000030:notes:33]

[0001511737-15-000009:notes:35]
|  | December 31, 2014 |  | June 30, 2014 |
| Vendor deposits | $ | 25,719 |  |  | $ | 8,043 |  |
| Non-trade receivables | 1,255 |  |  | 292 |  |
| Other current assets | 5,543 |  |  | 4,932 |  |
|  | $ | 32,517 |  |  | $ | 13,267 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001511737-15-000009:notes:36]
[same as prior period, unchanged from 0001511737-14-000030:notes:35]

[0001511737-15-000009:notes:37]
[same as prior period, unchanged from 0001511737-14-000030:notes:36]

[0001511737-15-000009:notes:38]
The Company’s 2010 Equity Incentive Plan and 2005 Equity Incentive Plan are described in its Annual Report. As of December 31, 2014, the Company had 9,834,899 authorized shares available for future issuance under all of its stock incentive plans.

[0001511737-15-000009:notes:39]
[same as prior period, unchanged from 0001511737-14-000030:notes:38]

[0001511737-15-000009:notes:40]
The following table shows total stock-based compensation expense included in the Condensed Consolidated Statements of Operations for the three and six months ended December 31, 2014 and 2013 (in thousands):

[0001511737-15-000009:notes:41]
|  | Three Months Ended December 31, |  | Six Months Ended December 31, |
|  | 2014 |  | 2013 |  | 2014 |  | 2013 |
| Cost of sales | $ | 150 |  |  | $ | 148 |  |  | $ | 299 |  |  | $ | 292 |  |
| Research and development | 864 |  |  | 553 |  |  | 1,689 |  |  | 1,049 |  |
| Sales, general and administrative | 417 |  |  | 721 |  |  | 815 |  |  | 1,248 |  |
|  | $ | 1,431 |  |  | $ | 1,422 |  |  | $ | 2,803 |  |  | $ | 2,589 |  |

[0001511737-15-000009:notes:42]
[same as prior period, unchanged from 0001511737-14-000030:notes:41]

[0001511737-15-000009:notes:43]
The following is a summary of option activity for the Company’s stock incentive plans for the six months ended December 31, 2014:

[0001511737-15-000009:notes:44]
|  | Common Stock Options Outstanding |
|  | Numberof Shares |  | WeightedAverageExercisePrice |  | WeightedAverageRemainingContractualLife (Years) |  | AggregateIntrinsicValue |
|  |  |  |  |  |  |  | (In thousands) |
| Balance, June 30, 2014 | 2,657,142 |  |  | $ | 2.96 |  |  |  |  |  |
| Exercised | (122,973 | ) |  | 4.04 |  |  |  |  |  |
| Forfeitures and cancellations | (503 | ) |  | 15.00 |  |  |  |  |  |
| Balance, December 31, 2014 | 2,533,666 |  |  | $ | 2.90 |  |  | 4.54 |  | $ | 67,740 |  |
| Vested and expected to vest as of December 31, 2014 | 2,519,861 |  |  | $ | 2.86 |  |  | 4.52 |  | $ | 67,491 |  |
| Vested and exercisable as of December 31, 2014 | 2,254,737 |  |  | $ | 1.88 |  |  | 4.14 |  | $ | 62,581 |  |

[0001511737-15-000009:notes:45]
During the three months ended December 31, 2014 and 2013, the aggregate intrinsic value of options exercised under the Company’s stock incentive plans was $140,000 and $3.8 million, respectively, as determined as of the date of option exercise. During the six months ended December 31, 2014 and 2013, the aggregate intrinsic value of options exercised under the Company’s stock incentive plans was $5.0 million and $13.7 million, respectively, as determined as of the date of option exercise.

[0001511737-15-000009:notes:46]
As of December 31, 2014, the Company had unrecognized compensation costs of $1.4 million related to stock options which the Company expects to recognize over a weighted-average period of 1.8 years. Future option grants will increase the amount of compensation expense to be recorded in these periods.

[0001511737-15-000009:notes:47]
The Company estimates the fair value of employee stock options using the Black-Scholes option pricing model. The fair value of employee stock options is being amortized on a straight-line basis over the requisite service period of the awards.  The Company did not grant any employee stock options during the three and six months ended December 31, 2014 and 2013.

[0001511737-15-000009:notes:48]
[same as prior period, unchanged from 0001511737-14-000030:notes:47]

[0001511737-15-000009:notes:49]
[same as prior period, unchanged from 0001511737-14-000030:notes:48]

[0001511737-15-000009:notes:50]
|  | Number of Shares |  | Weighted Average Grant Date Fair Value |
| Non-vested RSUs, June 30, 2014 | 549,702 |  |  | $ | 22.65 |  |
| RSUs granted | 111,006 |  |  | 35.10 |  |
| RSUs vested | (99,019 | ) |  | 21.77 |  |
| RSUs canceled | (2,068 | ) |  | 29.38 |  |
| Non-vested RSUs, December 31, 2014 | 559,621 |  |  | $ | 25.25 |  |

[0001511737-15-000009:notes:51]
The intrinsic value of RSUs vested in the three months ended December 31, 2014 and 2013 was $1.1 million and $1.5 million, respectively.  The intrinsic value of RSUs vested in the six months ended December 31, 2014 and 2013 was $3.8 million and $2.9 million, respectively.

[0001511737-15-000009:notes:52]
As of December 31, 2014, there was unrecognized compensation costs related to RSUs of $11.0 million which the Company expects to recognize over a weighted average period of 3.1 years.


## us-gaap:EarningsPerShareTextBlock

[0001511737-15-000009:notes:53]
[same as prior period, unchanged from 0001511737-14-000030:notes:52]

[0001511737-15-000009:notes:54]
[same as prior period, unchanged from 0001511737-14-000030:notes:53]

[0001511737-15-000009:notes:55]
|  | Three Months Ended December 31, |  | Six Months Ended December 31, |
|  | 2014 |  | 2013 |  | 2014 |  | 2013 |
| Numerator: |  |  |  |
| Net income and comprehensive income | $ | 46,265 |  |  | $ | 41,792 |  |  | $ | 84,008 |  |  | $ | 82,320 |  |
| Denominator: |  |  |  |
| Weighted-average shares used in computing basic net income per share | 88,196 |  |  | 87,661 |  |  | 88,218 |  |  | 87,536 |  |
| Add—dilutive potential common shares: |  |  |  |  |  |  |  |
| Stock options | 1,398 |  |  | 1,747 |  |  | 1,442 |  |  | 1,795 |  |
| Restricted stock units | 143 |  |  | 245 |  |  | 178 |  |  | 262 |  |
| Weighted-average shares used in computing diluted net income per share | 89,737 |  |  | 89,653 |  |  | 89,838 |  |  | 89,593 |  |
| Net income per share of common stock: |  |  |  |
| Basic | $ | 0.52 |  |  | $ | 0.48 |  |  | $ | 0.95 |  |  | $ | 0.94 |  |
| Diluted | $ | 0.52 |  |  | $ | 0.47 |  |  | $ | 0.94 |  |  | $ | 0.92 |  |

[0001511737-15-000009:notes:56]
The Company excludes potentially dilutive securities from its diluted net income per share calculation when their effect would be antidilutive to net income per share amounts.  The following table summarizes the total potential shares of common stock that were excluded from the diluted per share calculation, because to include them would have been anti-dilutive for the period (in thousands):

[0001511737-15-000009:notes:57]
|  | Three Months Ended December 31, |  | Six Months Ended December 31, |
|  | 2014 |  | 2013 |  | 2014 |  | 2013 |
| Stock options | — |  |  | — |  |  | — |  |  | 1 |  |
| Restricted stock units | 117 |  |  | 9 |  |  | 6 |  |  | 32 |  |
|  | 117 |  |  | 9 |  |  | 6 |  |  | 33 |  |


## us-gaap:FairValueAssetsAndLiabilitiesMeasuredOnRecurringAndNonrecurringBasisTableTextBlock

[0001511737-15-000009:notes:58]
As of December 31, 2014 and June 30, 2014, the fair value hierarchy of the Company’s debt carried at historical cost was as follows (in thousands):

[0001511737-15-000009:notes:59]
|  | December 31, 2014 |  | June 30, 2014 |
|  | FairValue |  | Level 1 |  | Level 2 |  | Level 3 |  | FairValue |  | Level 1 |  | Level 2 |  | Level 3 |
| Debt | $ | 72,254 |  |  | $ | — |  |  | $ | 72,254 |  |  | $ | — |  |  | $ | 72,254 |  |  | $ | — |  |  | $ | 72,254 |  |  | $ | — |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001511737-15-000009:notes:60]
[same as prior period, unchanged from 0001511737-14-000030:notes:59]

[0001511737-15-000009:notes:61]
[same as prior period, unchanged from 0001511737-14-000030:notes:60]

[0001511737-15-000009:notes:62]
[same as prior period, unchanged from 0001511737-14-000030:notes:61]

[0001511737-15-000009:notes:63]
[same as prior period, unchanged from 0001511737-14-000030:notes:62]

[0001511737-15-000009:notes:64]
[same as prior period, unchanged from 0001511737-14-000030:notes:63]

[0001511737-15-000009:notes:65]
For certain of the Company’s financial instruments, including accounts receivable and accounts payable, the carrying amounts approximate fair value due to their short maturities.  Additionally, as of December 31, 2014, we held $361.6 million of our $388.6 million of cash and cash equivalents in accounts of our subsidiaries outside of the United States and we would incur significant tax liabilities if we were to repatriate those amounts.

[0001511737-15-000009:notes:66]
At December 31, 2014 and June 30, 2014 the Company had debt associated with its Credit Agreement with Wells Fargo Bank (See Note 7). The fair value of the Company’s debt was estimated based on the current rates offered to the Company for debt with similar terms and remaining maturities and was Level 2 measurement.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001511737-15-000009:notes:67]
[same as prior period, unchanged from 0001511737-14-000030:notes:66]

[0001511737-15-000009:notes:68]
As of December 31, 2014, the Company had approximately $17.0 million of unrecognized tax benefits, substantially all of which would, if recognized, affect its tax expense. The Company has elected to include interest and penalties related to uncertain tax positions as a component of tax expense. At December 31, 2014, an insignificant amount of interest and penalties are included in long-term income tax payable. The Company recorded an increase of its unrecognized tax benefits of $1.2 million for the three months ended December 31, 2014. The Company does not expect any significant increases or decreases to its unrecognized tax benefits in the next twelve months.

[0001511737-15-000009:notes:69]
The Company recorded income tax provisions of $4.5 million and $10.3 million for the three and six months ended December 31, 2014, respectively. The Company’s estimated 2015 effective tax rate differs from the U.S. statutory rate primarily due to profits earned in jurisdictions where the tax rate is lower than the U.S. tax rate.

[0001511737-15-000009:notes:70]
[same as prior period, unchanged from 0001511737-14-000030:notes:69]


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001511737-15-000009:notes:71]
Recent Accounting Pronouncements

[0001511737-15-000009:notes:72]
In June 2014, the Financial Accounting Standards Board, or FASB, issued a new accounting standard update on revenue from contracts with customers.  The core principle of the guidance is that an entity should recognize revenue to depict the transfer of promised goods or services to customers in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services.  To achieve that core principle, an entity should apply the following steps:

[0001511737-15-000009:notes:73]
Step 1: Identify the contract(s) with a customer.

[0001511737-15-000009:notes:74]
Step 2: Identify the performance obligations in the contract.

[0001511737-15-000009:notes:75]
Step 3: Determine the transaction price.

[0001511737-15-000009:notes:76]
Step 4: Allocate the transaction price to the performance obligations in the contract.

[0001511737-15-000009:notes:77]
Step 5: Recognize revenue when (or as) the entity satisfies a performance obligation.

[0001511737-15-000009:notes:78]
An entity should disclose sufficient information to enable users of financial statements to understand the nature, amount, timing, and uncertainty of revenue and cash flows arising from contracts with customers. Qualitative and quantitative information is required about contracts with customers, significant judgments and any assets recognized from the costs to obtain or fulfill a contract.   The guidance will be effective for the Company beginning July 1, 2017.  The Company is currently assessing the impact of this new guidance.


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001511737-15-000009:notes:79]
[same as prior period, unchanged from 0001511737-14-000030:notes:78]

[0001511737-15-000009:notes:80]
[same as prior period, unchanged from 0001511737-14-000030:notes:79]

[0001511737-15-000009:notes:81]
[same as prior period, unchanged from 0001511737-14-000030:notes:80]

[0001511737-15-000009:notes:82]
|  | Six Months Ended December 31, |
|  | 2014 |  | 2013 |
| Beginning balance | $ | 2,850 |  |  | $ | 2,913 |  |
| Accruals for warranties issued during the period | 1,718 |  |  | 2,698 |  |
| Warranty costs incurred during the period | (1,818 | ) |  | (2,036 | ) |
|  | $ | 2,750 |  |  | $ | 3,575 |  |


## us-gaap:PropertyPlantAndEquipmentScheduleOfSignificantAcquisitionsAndDisposalsTextBlock

[0001511737-15-000009:notes:83]
[same as prior period, unchanged from 0001511737-14-000030:notes:82]

[0001511737-15-000009:notes:84]
|  | December 31, 2014 |  | June 30, 2014 |
| Testing equipment | $ | 4,619 |  |  | $ | 3,785 |  |
| Computer and other equipment | 4,011 |  |  | 1,019 |  |
| Tooling equipment | 3,460 |  |  | 2,898 |  |
| Furniture and fixtures | 1,127 |  |  | 973 |  |
| Leasehold improvements | 4,728 |  |  | 3,173 |  |
| Software | 2,679 |  |  | 521 |  |
| Construction in progress | 46 |  |  | — |  |
|  | 20,670 |  |  | 12,369 |  |
| Less: Accumulated depreciation and amortization | (6,911 | ) |  | (5,109 | ) |
|  | $ | 13,759 |  |  | $ | 7,260 |  |


## us-gaap:ReconciliationOfRevenueFromSegmentsToConsolidatedTextBlock

[0001511737-15-000009:notes:85]
Revenues by product type are as follows (in thousands, except percentages):

[0001511737-15-000009:notes:86]
|  | Three Months Ended December 31, |  | Six Months Ended December 31, |
|  | 2014 |  | 2013 |  | 2014 |  | 2013 |
| Service Provider Technology | $ | 99,720 |  |  | 65 | % |  | $ | 111,454 |  |  | 81 | % |  | $ | 206,991 |  |  | 68 | % |  | $ | 205,671 |  |  | 77 | % |
| Enterprise Technology | 53,417 |  |  | 35 | % |  | 26,985 |  |  | 19 | % |  | 96,233 |  |  | 32 | % |  | 62,455 |  |  | 23 | % |
| Total revenues | $ | 153,137 |  |  | 100 | % |  | $ | 138,439 |  |  | 100 | % |  | $ | 303,224 |  |  | 100 | % |  | $ | 268,126 |  |  | 100 | % |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001511737-15-000009:notes:87]
RELATED PARTY TRANSACTIONS AND CERTAIN OTHER TRANSACTIONS

[0001511737-15-000009:notes:88]
On November 13, 2013, the Company entered into an aircraft lease agreement (the "Aircraft Lease Agreement") with RJP Manageco LLC (the "Lessor"), a limited liability company owned by the Company’s CEO, Robert J. Pera. Pursuant to the Aircraft Lease Agreement, the Company may lease an aircraft owned by the Lessor for Company business purposes. Under the Aircraft Lease Agreement, the aircraft may be leased at a rate of $5,000 per flight hour. This hourly rate does not include the cost of flight crew or on-board services, which the Company will purchase from a third-party provider. The Company recognized a total of approximately $29,000 and $180,000 in expenses pursuant to the Aircraft Lease Agreement during the three and six months ended December 31, 2014, respectively.  All expenses pursuant to the Aircraft Lease Agreement have been included in the Company's sales, general and administrative expenses in the Condensed Consolidated Statements of Operations.


## us-gaap:RevenueFromExternalCustomersByGeographicAreasTableTextBlock

[0001511737-15-000009:notes:89]
Revenues by geography based on customer’s ship-to destinations were as follows (in thousands, except percentages):

[0001511737-15-000009:notes:90]
|  | Three Months Ended December 31, |  | Six Months Ended December 31, |
|  | 2014 |  | 2013 |  | 2014 |  | 2013 |
| North America(1) | $ | 54,127 |  |  | 35 | % |  | $ | 32,567 |  |  | 24 | % |  | $ | 107,708 |  |  | 36 | % |  | $ | 70,000 |  |  | 26 | % |
| South America | 22,241 |  |  | 15 | % |  | 27,992 |  |  | 20 | % |  | 53,376 |  |  | 18 | % |  | 48,768 |  |  | 18 | % |
| Europe, the Middle East and Africa | 60,097 |  |  | 39 | % |  | 58,842 |  |  | 42 | % |  | 110,704 |  |  | 36 | % |  | 111,708 |  |  | 42 | % |
| Asia Pacific | 16,672 |  |  | 11 | % |  | 19,038 |  |  | 14 | % |  | 31,436 |  |  | 10 | % |  | 37,650 |  |  | 14 | % |
| Total revenues | $ | 153,137 |  |  | 100 | % |  | $ | 138,439 |  |  | 100 | % |  | $ | 303,224 |  |  | 100 | % |  | $ | 268,126 |  |  | 100 | % |

[0001511737-15-000009:notes:91]
| (1) | Revenue for the United States was $50.5 million and $31.1 million for the three months ended December 31, 2014 and 2013, respectively. Revenue for the United States was $102.2 million and $67.3 million for the six months ended December 31, 2014 and 2013, respectively. |


## us-gaap:ScheduleOfAccruedLiabilitiesTableTextBlock

[0001511737-15-000009:notes:92]
[same as prior period, unchanged from 0001511737-14-000030:notes:86]

[0001511737-15-000009:notes:93]
|  | December 31, 2014 |  | June 30, 2014 |
| Accrued compensation and benefits | $ | 2,011 |  |  | $ | 3,432 |  |
| Warranty accrual | 2,750 |  |  | 2,850 |  |
| Other accruals | 5,956 |  |  | 3,548 |  |
|  | $ | 10,717 |  |  | $ | 9,830 |  |


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0001511737-15-000009:notes:94]
[same as prior period, unchanged from 0001511737-14-000030:notes:88]

[0001511737-15-000009:notes:95]
|  | December 31, 2014 |  | June 30, 2014 |
| Finished goods | $ | 35,318 |  |  | $ | 45,881 |  |
| Raw materials | 2,191 |  |  | 468 |  |
|  | $ | 37,509 |  |  | $ | 46,349 |  |


## us-gaap:ScheduleOfOtherAssetsNoncurrentTextBlock

[0001511737-15-000009:notes:96]
[same as prior period, unchanged from 0001511737-14-000030:notes:90]

[0001511737-15-000009:notes:97]
|  | December 31, 2014 |  | June 30, 2014 |
| Intangible assets, net | $ | 689 |  |  | $ | 799 |  |
| Other long-term assets | 1,076 |  |  | 1,113 |  |
|  | $ | 1,765 |  |  | $ | 1,912 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001511737-15-000009:notes:98]
[same as prior period, unchanged from 0001511737-14-000030:notes:92]

[0001511737-15-000009:notes:99]
[same as prior period, unchanged from 0001511737-14-000030:notes:93]

[0001511737-15-000009:notes:100]
[same as prior period, unchanged from 0001511737-14-000030:notes:94]

[0001511737-15-000009:notes:101]
| • | Enterprise Technology includes the Company's UniFi and mFi platforms. |


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001511737-15-000009:notes:102]
[same as prior period, unchanged from 0001511737-14-000030:notes:104]

[0001511737-15-000009:notes:103]
The Company’s significant accounting policies are disclosed in its audited consolidated financial statements for the year ended June 30, 2014 included in the Annual Report.   Except as noted below, there have been no changes to the Company's significant accounting policies as discussed in the Annual Report.

[0001511737-15-000009:notes:104]
Capitalized Software Development Costs

[0001511737-15-000009:notes:105]
The Company capitalizes certain costs of software developed for internal use.  Capitalized costs primarily include payroll and payroll-related costs and facilities costs. The cost of internally developed software is amortized on a straight-line basis over its estimated useful life, typically 3 to 5 years.  During the three and six months ended December 31, 2014, the Company capitalized $1.5 million of software development costs, which is included as property and equipment in the Company's balance sheet as of  December 31, 2014.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001511737-15-000009:notes:106]
COMMON STOCK AND TREASURY STOCK

[0001511737-15-000009:notes:107]
As of December 31, 2014 and June 30, 2014, the authorized capital of the Company included 500,000,000 shares of common stock.  As of December 31, 2014 and June 30, 2014, 87,846,511 and 88,179,448 shares of common stock were outstanding.

[0001511737-15-000009:notes:108]
Common Stock Repurchases

[0001511737-15-000009:notes:109]
On May 29, 2014, the Company announced that its Board of Directors authorized the Company to repurchase up to $75 million of its common stock. The share repurchase program commenced June 2, 2014 and will expire after one year.  During the three months ended December 31, 2014, the company repurchased 529,779 shares of its common stock at an average price per share of  $28.29 for an aggregate amount of $15.0 million.  As of December 31, 2014, the share repurchases under the repurchase program were funded from cash on hand.  The Company has approximately $60.0 million remaining for common stock repurchases under the repurchase plan.

[0001511737-15-000009:notes:110]
Dividend Policy

[0001511737-15-000009:notes:111]
On September 30, 2014, the Company announced that its Board of Directors had approved an annual dividend policy.  Pursuant to this dividend policy, the Company intends to pay an annual cash dividend to its shareholders of record on a record date and in an amount to be determined annually by the Board of Directors subject to the Company's financial position and other relevant factors. The Company declared its first annual dividend of $0.17 per share on September 30, 2014.  The aggregate amount of $15.0 million was paid on October 28, 2014 to stockholders of record on October 17, 2014.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001511737-15-000009:notes:112]
[same as prior period, unchanged from 0001511737-14-000030:notes:106]

[0001511737-15-000009:notes:113]
[same as prior period, unchanged from 0001511737-14-000030:notes:107]

[0001511737-15-000009:notes:114]
[same as prior period, unchanged from 0001511737-14-000030:notes:108]

[0001511737-15-000009:notes:115]
[same as prior period, unchanged from 0001511737-14-000030:notes:110]

[0001511737-15-000009:notes:116]
[same as prior period, unchanged from 0001511737-14-000030:notes:111]

[0001511737-15-000009:notes:117]
The Company's intangible assets consist primarily of legal costs associated with the application for and registration of the Company’s trademarks.  The Company recorded $60,000 and $110,000 of amortization of intangible assets during the three and six months ended December 31, 2014, respectively.  The Company recorded $25,000 and $175,000 of amortization of intangible assets during the three and six months ended December 31, 2013, respectively.  The balance of accumulated amortization was $560,000 and $450,000 at December 31, 2014 and June 30, 2014, respectively.  Estimated future amortization related to trademark registration fees is $127,000, $251,000, $229,000, $68,000, and $14,000 for the remainder of fiscal 2015 and fiscal years 2016, 2017, 2018 and 2019, respectively.

[0001511737-15-000009:notes:118]
[same as prior period, unchanged from 0001511737-14-000030:notes:113]
