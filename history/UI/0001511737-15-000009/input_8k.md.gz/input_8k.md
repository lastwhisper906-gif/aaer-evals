# UI 8-K — 0001511737-15-000008 filed 2015-02-05

## item codes, every 8-K on or before 2015-02-05

- 2015-02-05 0001511737-15-000008 — 2.02, 9.01
- 2014-12-18 0001193125-14-446627 — 5.07
- 2014-11-06 0001511737-14-000029 — 2.02, 9.01
- 2014-09-30 0001193125-14-359060 — 7.01, 9.01
- 2014-08-07 0001511737-14-000021 — 2.02, 9.01
- 2014-05-08 0001511737-14-000016 — 2.02, 9.01
- 2014-04-17 0001193125-14-146710 — 7.01
- 2014-03-06 0001193125-14-084883 — 8.01
- 2014-02-06 0001511737-14-000005 — 2.02, 9.01
- 2013-12-16 0001193125-13-474388 — 5.07
- 2013-11-22 0001193125-13-451511 — 5.02
- 2013-11-07 0001511737-13-000018 — 2.02, 9.01
- 2013-10-28 0001193125-13-413414 — 5.02, 9.01
- 2013-10-18 0001193125-13-404111 — 5.02, 9.01
- 2013-08-08 0001511737-13-000009 — 2.02, 9.01
- 2013-05-09 0001511737-13-000004 — 2.02
- 2013-03-25 0001193125-13-124353 — 5.07
- 2013-03-08 0001193125-13-098334 — 5.02, 9.01
- 2013-02-07 0001193125-13-043701 — 2.02, 9.01
- 2012-12-28 0001193125-12-518487 — 1.01
- 2012-12-17 0001193125-12-503742 — 7.01, 9.01
- 2012-12-13 0001193125-12-501894 — 5.02
- 2012-11-16 0001193125-12-474083 — 5.02
- 2012-11-13 0001193125-12-467376 — 5.02
- 2012-11-08 0001193125-12-460665 — 2.02, 9.01
- 2012-10-10 0001193125-12-420015 — 5.02, 9.01
- 2012-08-13 0001193125-12-352624 — 1.01, 2.03, 9.01
- 2012-08-09 0001193125-12-347776 — 1.01, 9.01
- 2012-08-09 0001193125-12-347732 — 2.02, 9.01
- 2012-05-01 0001193125-12-201012 — 2.02, 9.01
- 2012-03-30 0001193125-12-144074 — 5.02
- 2012-03-27 0001193125-12-134395 — 5.02, 9.01
- 2012-03-22 0001193125-12-127536 — 5.02
- 2012-01-31 0001193125-12-032079 — 2.02, 9.01
- 2011-12-27 0001193125-11-353002 — 1.01, 9.01
- 2011-12-06 0001193125-11-332192 — 5.02
- 2011-11-10 0001193125-11-306969 — 2.02, 9.01

## late-filing notifications on or before 2015-02-05

- none on or before 2015-02-05

## item 2.02 — earnings release, exhibit 99.1

[0001511737-15-000008:8k_2_02:1]
EX-99.1
2
exhibit991q22015.htm
PRESS RELEASE OF UBIQUITI NETWORKS, INC.

[0001511737-15-000008:8k_2_02:2]
Exhibit 99.1 Q2 2015

[0001511737-15-000008:8k_2_02:3]
Exhibit 99.1

[0001511737-15-000008:8k_2_02:4]
UBIQUITI NETWORKS REPORTS SECOND QUARTER FISCAL 2015 FINANCIAL RESULTS

[0001511737-15-000008:8k_2_02:5]
~ Achieves Solid Revenue and Earnings ~

[0001511737-15-000008:8k_2_02:6]
~ Posts Non-GAAP EPS of $0.53 Per Diluted Share ~

[0001511737-15-000008:8k_2_02:7]
San Jose, Calif. - February 5, 2015 - Ubiquiti Networks, Inc. (NASDAQ:UBNT) (“Ubiquiti”) today announced results for the second fiscal quarter of 2015, ended December 31, 2014.

[0001511737-15-000008:8k_2_02:8]
Second Quarter Financial Summary

[0001511737-15-000008:8k_2_02:9]
| • | Revenues of $153.1 million, up 11% year-over-year |

[0001511737-15-000008:8k_2_02:10]
| • | GAAP operating profit of $50.7 million, up 8% year-over-year |

[0001511737-15-000008:8k_2_02:11]
| • | GAAP net income of $46.3 million, up 11% year-over-year |

[0001511737-15-000008:8k_2_02:12]
| • | Non-GAAP operating profit of $52.2 million, up 7% year-over-year |

[0001511737-15-000008:8k_2_02:13]
| • | GAAP diluted EPS of $0.52 and non-GAAP diluted EPS of $0.53, up 11% and 10% year-over-year, respectively |

[0001511737-15-000008:8k_2_02:14]
| • | $32.7 million in net cash provided by operating activities |

[0001511737-15-000008:8k_2_02:15]
Recent Business and Product Highlights

[0001511737-15-000008:8k_2_02:16]
| • | Record revenues in Enterprise Technology, primarily due to further product expansion and momentum in our UniFi® technology platform. |

[0001511737-15-000008:8k_2_02:17]
| • | Released Point-to-Multi-Point (PtMP) software for airMAX® AC, and shipped volume customer-premises equipment (CPE). |

[0001511737-15-000008:8k_2_02:18]
| • | Shipped first UniFi® Switch and UniFi® VoIP units to select distributors. |

[0001511737-15-000008:8k_2_02:19]
| • | Launched airFiber® X, a revolutionary new platform for the global last-mile wireless industry. |

[0001511737-15-000008:8k_2_02:20]
“We are excited about the opportunities ahead for our new Enterprise Technology products and the new airFiber platform, airFiber X,” said Robert J. Pera, Founder and Chief Executive Officer of Ubiquiti Networks, Inc.  “We are also enthusiastic about the early results of airMAX AC and the growth of our EdgeMAX routing and switching technologies.”

[0001511737-15-000008:8k_2_02:21]
Financial Highlights ($, in millions, except per share data)

[0001511737-15-000008:8k_2_02:22]
| Income statement highlights |  | F2Q15 |  | F1Q15 |  | F2Q14 |
| Revenues |  | 153.1 |  | 150.1 |  | 138.4 |
| Service Provider Technology |  | 99.7 |  | 107.3 |  | 111.4 |
| Enterprise Technology |  | 53.4 |  | 42.8 |  | 27.0 |
| Cost of Revenues |  | 84.1 |  | 89.0 |  | 77.5 |
| Gross Profit |  | 69.0 |  | 61.0 |  | 61.0 |
| Total Operating Expenses |  | 18.3 |  | 17.4 |  | 13.9 |
| Income from Operations |  | 50.7 |  | 43.6 |  | 47.1 |
| GAAP Net Income |  | 46.3 |  | 37.7 |  | 41.8 |
| GAAP EPS (diluted) |  | 0.52 |  | 0.42 |  | 0.47 |
| Non-GAAP Net Income |  | 47.1 |  | 43.4 |  | 42.6 |
| Non-GAAP EPS (diluted) |  | 0.53 |  | 0.48 |  | 0.48 |

[0001511737-15-000008:8k_2_02:23]
Balance Sheet Highlights

[0001511737-15-000008:8k_2_02:24]
Total cash and cash equivalents as of December 31, 2014 were $388.6 million, compared with $391.0 million as of September 30, 2014.  The cash balance is net of a $15 million dividend paid on October 28, 2014 that was part of our new annual dividend policy we announced on September 30, 2014, and $15 million in share repurchases during the quarter as part of our share repurchase program.  We believe that our cash position will allow us to make investments that will continue to enhance our competitive position and product portfolio.

[0001511737-15-000008:8k_2_02:25]
This quarter we saw days sales outstanding in accounts receivable ("DSO") of 44 days, compared with 40 days in the prior quarter, and 24 days in the second quarter of fiscal 2014.  The increase in DSO for the quarter was primarily the result of our strategic decision to add larger distributors worldwide that received longer credit terms, as well as extending more favorable credit terms to other distributors who have built up a credit history with us.

[0001511737-15-000008:8k_2_02:26]
Business Outlook

[0001511737-15-000008:8k_2_02:27]
The following are Ubiquiti’s financial performance estimates for the third quarter of fiscal 2015:

[0001511737-15-000008:8k_2_02:28]
| • | Revenues of between $146 million and $158 million |

[0001511737-15-000008:8k_2_02:29]
| • | GAAP diluted EPS of between $0.44 and $0.49 |

[0001511737-15-000008:8k_2_02:30]
| • | Non-GAAP diluted EPS of between $0.45 and $0.50 |

[0001511737-15-000008:8k_2_02:31]
Conference Call Information

[0001511737-15-000008:8k_2_02:32]
Ubiquiti Networks will host a Q&A-only call to discuss the Company’s financial results at 2:00 p.m. Pacific Time today.  Management’s prepared remarks can be found on the Investor Relations section of the Ubiquiti Networks website, http://ir.ubnt.com/results.cfm.

[0001511737-15-000008:8k_2_02:33]
To listen to the Q&A call via telephone, dial (877) 291-1296 (U.S. toll-free) or (720) 259-9209 (International) to be connected to the call by an operator.  Participants should dial in at least 10 minutes prior to the start of the call.  Investors may also listen to a live webcast of the Q&A conference call by visiting the Investor Relations section of the Ubiquiti Networks website at http://ir.ubnt.com.

[0001511737-15-000008:8k_2_02:34]
A recording of the Q&A call will be available approximately two hours after the call concludes and will be accessible on the Investor Relations section of the Ubiquiti Networks website, http://ir.ubnt.com.

[0001511737-15-000008:8k_2_02:35]
About Ubiquiti Networks

[0001511737-15-000008:8k_2_02:36]
Ubiquiti Networks (NASDAQ: UBNT) is closing the digital divide by building network communication platforms for everyone and everywhere. With over 28 million devices sold worldwide, Ubiquiti is transforming under-networked enterprises and communities. Our leading edge platforms, airMAX®, UniFi®, airFiber®, UniFi® Video, UniFi® VoIP, UniFi® Switch, mFi® and EdgeMAX®, combine innovative technology, disruptive price-to-performance and the support of a global user community to eliminate barriers to connectivity. For more information, join our community at http://www.ubnt.com.

[0001511737-15-000008:8k_2_02:37]
Ubiquiti, the Ubiquiti logo, Ubiquiti Networks, airMAX, airFiber, airCRM, UniFi, mFi, and EdgeMAX are registered trademarks or trademarks of Ubiquiti Networks, Inc. in the United States and other countries.

[0001511737-15-000008:8k_2_02:38]
The Ubiquiti Networks, Inc. logo is available at http://www.globenewswire.com/newsroom/prs/?pkgid=24865.

[0001511737-15-000008:8k_2_02:39]
Investor Relations Contact

[0001511737-15-000008:8k_2_02:40]
Anne Fazioli

[0001511737-15-000008:8k_2_02:41]
Ubiquiti Networks, Vice President of Investor Relations

[0001511737-15-000008:8k_2_02:42]
IR@ubnt.com

[0001511737-15-000008:8k_2_02:43]
Forward-looking statements are subject to certain risks and uncertainties that could cause our actual future results to differ materially, or cause a material adverse impact on our results.  Potential risks and uncertainties include, but are not limited to, fluctuations in our operating results; varying demand for our products due to the financial and operating condition of our distributors and their customers, and distributors' inventory management practices; political and economic conditions and volatility affecting the stability of business environments, economic growth, currency values, commodity prices and other factors that may influence the ultimate demand for our products in particular geographies or globally; impact of counterfeiting and our ability to contain such impact; our reliance on a limited number of distributors; inability of our contract manufacturers and suppliers to meet our demand; our dependence on Qualcomm Atheros for chipsets without a short-term alternative; as we move into new markets competition from certain of our current or potential competitors who may be more established in such markets; our ability to keep pace with technological and market developments; success and timing of new product introductions by us and the performance of our products generally; our ability to effectively manage the significant increase in our transactional sales volumes; we may become subject to warranty claims, product liability and product recalls; that a substantial majority of our sales are into countries outside the United States and we are subject to numerous U.S. export control and economic sanctions laws; costs related to responding to government inquiries related to regulatory compliance; our reliance on the Ubiquiti Community; our reliance on certain key members of our management team, including our founder and chief executive officer, Robert J. Pera; adverse tax-related matters such as tax audits, changes in our effective tax rate or new tax legislative proposals; whether the final determination of our income tax liability may be materially different from our income tax provisions; the impact of any intellectual property litigation and claims for indemnification and litigation related to U.S. Securities laws and economic and political conditions in the United States and abroad.  We discuss these risks in greater detail under the heading “Risk Factors” and elsewhere in our Annual Report on Form 10-K for the year ended June 30, 2014, and subsequent filings filed with the U.S. Securities and Exchange Commission (the SEC), which are available at the SEC's website at www.sec.gov.  Copies may also be obtained by contacting the Ubiquiti Networks Investor Relations Department, by email at IR@ubnt.com or by visiting the Investor Relations section of the Ubiquiti Networks website, http://ir.ubnt.com.

[0001511737-15-000008:8k_2_02:44]
Given these uncertainties, you should not place undue reliance on these forward-looking statements.  Also, forward-looking statements represent our management's beliefs and assumptions only as of the date made.  Ubiquiti Networks undertakes no obligation to update information contained herein.  You should review our SEC filings carefully and with the understanding that our actual future results may be materially different from what we expect.

[0001511737-15-000008:8k_2_02:45]
Use of Non-GAAP Financial Information

[0001511737-15-000008:8k_2_02:46]
To supplement our condensed consolidated financial results prepared under generally accepted accounting principles, or GAAP, we use non-GAAP measures of net income and earnings per diluted share that are adjusted to exclude certain costs, expenses and gains such as stock based compensation expense, purchase commitment termination fee and the tax effects of these non-GAAP adjustments.  Reconciliations of the adjustments to GAAP results for the three and six months ended December 31, 2014 and 2013 are provided below.  In addition, an explanation of the ways in which management uses non-GAAP financial information to evaluate its business, the substance behind management's decision to use this non-GAAP financial information, material limitations associated with the use of non-GAAP financial information, the manner in which management compensates for those limitations, and the substantive reasons management believes that this non-GAAP financial information provides useful information to investors is included under "About our Non-GAAP Net Income and Adjustments" after the tables below.

[0001511737-15-000008:8k_2_02:47]
| Ubiquiti Networks Inc.Condensed Consolidated Statement of Operations(In thousands, except per share data)(Unaudited) |
|  |  | Three Months Ended December 31, |  | Six Months Ended December 31, |
|  |  | 2014 |  | 2013 |  | 2014 |  | 2013 |
| Revenues |  | $ | 153,137 |  |  | $ | 138,439 |  |  | $ | 303,224 |  |  | $ | 268,126 |  |
| Cost of revenues |  | 84,116 |  |  | 77,468 |  |  | 173,152 |  |  | 149,132 |  |
| Gross profit |  | 69,021 |  |  | 60,971 |  |  | 130,072 |  |  | 118,994 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Research and development |  | 12,936 |  |  | 8,077 |  |  | 24,657 |  |  | 14,394 |  |
| Sales, general and administrative |  | 5,362 |  |  | 5,774 |  |  | 11,058 |  |  | 11,584 |  |
| Total operating expenses |  | 18,298 |  |  | 13,851 |  |  | 35,715 |  |  | 25,978 |  |
| Income from operations |  | 50,723 |  |  | 47,120 |  |  | 94,357 |  |  | 93,016 |  |
| Interest expense and other, net |  | 17 |  |  | (249 | ) |  | (41 | ) |  | (495 | ) |
| Income before provision for income taxes |  | 50,740 |  |  | 46,871 |  |  | 94,316 |  |  | 92,521 |  |
| Provision for income taxes |  | 4,475 |  |  | 5,079 |  |  | 10,308 |  |  | 10,201 |  |
| Net income |  | $ | 46,265 |  |  | $ | 41,792 |  |  | $ | 84,008 |  |  | $ | 82,320 |  |
| Net income per share of common stock: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.52 |  |  | $ | 0.48 |  |  | $ | 0.95 |  |  | $ | 0.94 |  |
| Diluted |  | $ | 0.52 |  |  | $ | 0.47 |  |  | $ | 0.94 |  |  | $ | 0.92 |  |
| Weighted average shares used in computing net income per share of common stock: |  |  |  |  |  |  |  |  |
| Basic |  | 88,196 |  |  | 87,661 |  |  | 88,218 |  |  | 87,536 |  |
| Diluted |  | 89,737 |  |  | 89,653 |  |  | 89,838 |  |  | 89,593 |  |
| Cash dividends declared per common share |  | $ | — |  |  | $ | — |  |  | $ | 0.17 |  |  | $ | — |  |

[0001511737-15-000008:8k_2_02:48]
| Ubiquiti Networks Inc.Reconciliation of GAAP Net Income to Non-GAAP Net Income(In thousands, except per share data)(Unaudited) |
|  |  | Three Months Ended December 31, |  | Six Months Ended December 31, |
|  |  | 2014 |  | 2013 |  | 2014 |  | 2013 |
| Net income |  | $ | 46,265 |  |  | $ | 41,792 |  |  | $ | 84,008 |  |  | $ | 82,320 |  |
| Stock-based compensation: |  |  |  |  |  |  |  |  |
| Cost of revenues |  | 150 |  |  | 148 |  |  | 299 |  |  | 292 |  |
| Research and development |  | 864 |  |  | 553 |  |  | 1,689 |  |  | 1,049 |  |
| Sales, general and administrative |  | 417 |  |  | 721 |  |  | 815 |  |  | 1,248 |  |
| Purchase commitment termination fee |  | — |  |  | — |  |  | 5,500 |  |  | — |  |
| Tax effect of non-GAAP adjustments |  | (572 | ) |  | (569 | ) |  | (1,781 | ) |  | (1,036 | ) |
| Non-GAAP net income |  | $ | 47,124 |  |  | $ | 42,645 |  |  | $ | 90,530 |  |  | $ | 83,873 |  |
| Non-GAAP diluted EPS |  | $ | 0.53 |  |  | $ | 0.48 |  |  | $ | 1.01 |  |  | $ | 0.94 |  |
| Weighted-average shares used in non-GAAP diluted EPS |  | 89,737 |  |  | 89,653 |  |  | 89,838 |  |  | 89,593 |  |

[0001511737-15-000008:8k_2_02:49]
| Ubiquiti Networks Inc.Condensed Consolidated Balance Sheets(In thousands)(Unaudited) |
|  |  | December 31, 2014 |  | June 30, 2014(1) |
| Assets |  |  |  |  |
| Current assets: |  |  |  |  |
| Cash and cash equivalents |  | $ | 388,603 |  |  | $ | 347,097 |  |
| Accounts receivable, net |  | 72,569 |  |  | 54,871 |  |
| Inventories |  | 37,509 |  |  | 46,349 |  |
| Current deferred tax asset |  | 884 |  |  | 884 |  |
| Prepaid income taxes |  | 4,512 |  |  | 3,256 |  |
| Prepaid expenses and other current assets |  | 32,517 |  |  | 13,267 |  |
| Total current assets |  | 536,594 |  |  | 465,724 |  |
| Property and equipment, net |  | 13,759 |  |  | 7,260 |  |
| Long-term deferred tax asset |  | 1,255 |  |  | 1,255 |  |
| Other long–term assets |  | 1,765 |  |  | 1,912 |  |
| Total assets |  | $ | 553,373 |  |  | $ | 476,151 |  |
| Liabilities and Stockholders’ Equity |  |  |  |  |
| Current liabilities: |  |  |  |  |
| Accounts payable |  | $ | 54,941 |  |  | $ | 33,933 |  |
| Customer deposits |  | 712 |  |  | 1,835 |  |
| Deferred revenues |  | 2,948 |  |  | 4,218 |  |
| Income taxes payable |  | 972 |  |  | 2,499 |  |
| Other current liabilities |  | 10,717 |  |  | 9,830 |  |
| Total current liabilities |  | 70,290 |  |  | 52,315 |  |
| Long-term taxes payable |  | 17,467 |  |  | 15,346 |  |
| Debt - long-term |  | 72,254 |  |  | 72,254 |  |
| Deferred revenues - long-term |  | 1,008 |  |  | 972 |  |
| Total liabilities |  | 161,019 |  |  | 140,887 |  |
| Stockholders’ equity: |  |  |  |  |
| Common stock |  | 88 |  |  | 88 |  |
| Additional paid–in capital |  | 148,974 |  |  | 145,872 |  |
| Treasury stock |  | (138,864 | ) |  | (123,864 | ) |
| Retained earnings |  | 382,156 |  |  | 313,168 |  |
| Total stockholders’ equity |  | 392,354 |  |  | 335,264 |  |
| Total liabilities and stockholders’ equity |  | $ | 553,373 |  |  | $ | 476,151 |  |

[0001511737-15-000008:8k_2_02:50]
| (1) | Derived from audited consolidated statements as of and for the year ended June 30, 2014. |

[0001511737-15-000008:8k_2_02:51]
| Ubiquiti Networks Inc.Revenues by Product Type (In thousands)(Unaudited) |
|  |  | Three Months Ended December 31, |  | Six Months Ended December 31, |
|  |  | 2014 |  | 2013 |  | 2014 |  | 2013 |
| Service provider technology |  | $ | 99,720 |  |  | $ | 111,454 |  |  | $ | 206,991 |  |  | $ | 205,671 |  |
| Enterprise technology |  | 53,417 |  |  | 26,985 |  |  | 96,233 |  |  | 62,455 |  |
| Total revenues |  | $ | 153,137 |  |  | $ | 138,439 |  |  | $ | 303,224 |  |  | $ | 268,126 |  |

[0001511737-15-000008:8k_2_02:52]
| Ubiquiti Networks Inc.Revenues by Geographical Area(In thousands)(Unaudited) |
|  |  | Three Months Ended December 31, |  | Six Months Ended December 31, |
|  |  | 2014 |  | 2013 |  | 2014 |  | 2013 |
| North America |  | $ | 54,127 |  |  | $ | 32,567 |  |  | $ | 107,708 |  |  | $ | 70,000 |  |
| South America |  | 22,241 |  |  | 27,992 |  |  | 53,376 |  |  | 48,768 |  |
| Europe, the Middle East and Africa |  | 60,097 |  |  | 58,842 |  |  | 110,704 |  |  | 111,708 |  |
| Asia Pacific |  | 16,672 |  |  | 19,038 |  |  | 31,436 |  |  | 37,650 |  |
| Total revenues |  | $ | 153,137 |  |  | $ | 138,439 |  |  | $ | 303,224 |  |  | $ | 268,126 |  |

[0001511737-15-000008:8k_2_02:53]
About our Non-GAAP Net Income and Adjustments

[0001511737-15-000008:8k_2_02:54]
Use of Non-GAAP Financial Information

[0001511737-15-000008:8k_2_02:55]
To supplement our condensed consolidated financial results prepared under generally accepted accounting principles, or GAAP, we use non-GAAP measures of net income and earnings per diluted share that are GAAP net income and GAAP earnings per diluted share adjusted to exclude certain costs, expenses and gains.

[0001511737-15-000008:8k_2_02:56]
We believe that the presentation of non-GAAP net income and non-GAAP earnings per diluted share provides important supplemental information regarding non-cash expenses, significant items that we believe are important to understanding our financial, and business trends relating to our financial condition and results of operations.  Non-GAAP net income and non-GAAP earnings per diluted share are among the primary indicators used by management as a basis for planning and forecasting future periods and by management and our board of directors to determine whether our operating performance has met specified targets and thresholds.  Management uses non-GAAP net income and non-GAAP earnings per diluted share when evaluating operating performance because it believes that the exclusion of the items described below, for which the amounts or timing may vary significantly depending upon the Company's activities and other factors, facilitates comparability of the Company's operating performance from period to period.  We have chosen to provide this information to investors so they can analyze our operating results in the same way that management does and use this information in their assessment of our business and the valuation of our Company.

[0001511737-15-000008:8k_2_02:57]
Use and Economic Substance of Non-GAAP Financial Measures used by Ubiquiti Networks

[0001511737-15-000008:8k_2_02:58]
We compute non-GAAP net income and non-GAAP diluted earnings per share by adjusting GAAP net income and GAAP earnings per diluted share to remove the impact of certain adjustments and the tax effect of those adjustments.  Items excluded from net income are:

[0001511737-15-000008:8k_2_02:59]
| • | Stock-based compensation expense |

[0001511737-15-000008:8k_2_02:60]
| • | Reserve against vendor deposits relating to a purchase commitment termination fee |

[0001511737-15-000008:8k_2_02:61]
| • | Tax effect of non-GAAP adjustments, applying the principles of ASC 740 |

[0001511737-15-000008:8k_2_02:62]
Usefulness of Non-GAAP Financial Information to Investors

[0001511737-15-000008:8k_2_02:63]
These non-GAAP measures are not in accordance with, or an alternative to, GAAP and may be materially different from other non-GAAP measures, including similarly titled non-GAAP measures used by other companies.  The presentation of this additional information should not be considered in isolation from, as a substitute for, or superior to, net income or earnings per diluted share prepared in accordance with GAAP.  Non-GAAP financial measures have limitations in that they do not reflect certain items that may have a material impact upon our reported financial results.  We expect to continue to incur expenses of a nature similar to the non-GAAP adjustments described above, and exclusion of these items from our non-GAAP net income and non-GAAP earnings per diluted share should not be construed as an inference that these costs are unusual, infrequent or non-recurring.

[0001511737-15-000008:8k_2_02:64]
For more information on the non-GAAP adjustments, please see the table captioned “Reconciliation of GAAP Net Income to Non-GAAP Net Income” included in this press release.
