# UI MD&A — 0001511737-15-000009


## mdna

[0001511737-15-000009:mdna:1]
[same as prior period, unchanged from 0001511737-14-000030:mdna:1]

[0001511737-15-000009:mdna:2]
14

[0001511737-15-000009:mdna:3]
Overview

[0001511737-15-000009:mdna:4]
[same as prior period, unchanged from 0001511737-14-000030:mdna:2]

[0001511737-15-000009:mdna:5]
[same as prior period, unchanged from 0001511737-14-000030:mdna:3]

[0001511737-15-000009:mdna:6]
[same as prior period, unchanged from 0001511737-14-000030:mdna:4]

[0001511737-15-000009:mdna:7]
[same as prior period, unchanged from 0001511737-14-000030:mdna:5]

[0001511737-15-000009:mdna:8]
[same as prior period, unchanged from 0001511737-14-000030:mdna:6]

[0001511737-15-000009:mdna:9]
[same as prior period, unchanged from 0001511737-14-000030:mdna:7]

[0001511737-15-000009:mdna:10]
[same as prior period, unchanged from 0001511737-14-000030:mdna:8]

[0001511737-15-000009:mdna:11]
Our revenues increased 11% to $153.1 million in the three months ended December 31, 2014 from $138.4 million in the three months ended December 31, 2013.  Our revenues increased 13% to $303.2 million in the six months ended December 31, 2014 from $268.1 million in the six months ended December 31, 2013.  We believe the overall increase in revenues during the three and six months ended December 31, 2014 was driven by increased adoption of our service provider and enterprise technologies.  We had net income of $46.3 million and $41.8 million in the three months ended December 31, 2014 and 2013, respectively.  We had net income of $84.0 million and $82.3 million in the six months ended December 31, 2014 and 2013, respectively.  The increase in net income in both the three and six months ended December 31, 2014 as compared to the same periods in the prior year was primarily due to the increase in revenues.

[0001511737-15-000009:mdna:12]
15

[0001511737-15-000009:mdna:13]
[same as prior period, unchanged from 0001511737-14-000030:mdna:10]

[0001511737-15-000009:mdna:14]
[same as prior period, unchanged from 0001511737-14-000030:mdna:11]

[0001511737-15-000009:mdna:15]
[same as prior period, unchanged from 0001511737-14-000030:mdna:12]

[0001511737-15-000009:mdna:16]
[same as prior period, unchanged from 0001511737-14-000030:mdna:13]

[0001511737-15-000009:mdna:17]
[same as prior period, unchanged from 0001511737-14-000030:mdna:14]

[0001511737-15-000009:mdna:18]
| • | Enterprise Technology includes our UniFi and mFi platforms. |

[0001511737-15-000009:mdna:19]
We sell substantially all of our products through a limited number of distributors and other channel partners, such as resellers and OEMs. Sales to distributors accounted for 99% and 98% of our revenues in the three and six months ended December 31, 2014 and 2013, respectively.

[0001511737-15-000009:mdna:20]
[same as prior period, unchanged from 0001511737-14-000030:mdna:17]

[0001511737-15-000009:mdna:21]
[same as prior period, unchanged from 0001511737-14-000030:mdna:18]

[0001511737-15-000009:mdna:22]
[same as prior period, unchanged from 0001511737-14-000030:mdna:19]

[0001511737-15-000009:mdna:23]
[same as prior period, unchanged from 0001511737-14-000030:mdna:20]

[0001511737-15-000009:mdna:24]
[same as prior period, unchanged from 0001511737-14-000030:mdna:21]

[0001511737-15-000009:mdna:25]
[same as prior period, unchanged from 0001511737-14-000030:mdna:23]

[0001511737-15-000009:mdna:26]
[same as prior period, unchanged from 0001511737-14-000030:mdna:24]

[0001511737-15-000009:mdna:27]
[same as prior period, unchanged from 0001511737-14-000030:mdna:25]

[0001511737-15-000009:mdna:28]
| • | Sales, general and administrative expenses include salary and benefit expenses, including stock-based compensation, for employees and costs for contractors engaged in sales, marketing and general and administrative activities, as well as the costs of legal expenses, trade shows, marketing programs, promotional materials, bad debt expense, professional services, facilities, general liability insurance and travel. As our product portfolio and targeted markets expand, we may need to employ different sales models, such as building a direct sales force. These sales models would likely increase our costs. Over time, we expect our sales, general and administrative expenses to increase in absolute dollars due to |

[0001511737-15-000009:mdna:29]
continued growth in headcount, expansion of our efforts to register and defend trademarks and patents and to support our business and operations.

[0001511737-15-000009:mdna:30]
[same as prior period, unchanged from 0001511737-14-000030:mdna:27]

[0001511737-15-000009:mdna:31]
[same as prior period, unchanged from 0001511737-14-000030:mdna:28]

[0001511737-15-000009:mdna:32]
Also included in our deferred revenues is a portion related to PCS obligations that we estimate we will perform in the future. As of December 31, 2014 and June 30, 2014, we had deferred revenues of $3.3 million and $2.8 million respectively, related to these obligations.

[0001511737-15-000009:mdna:33]
[same as prior period, unchanged from 0001511737-14-000030:mdna:30]

[0001511737-15-000009:mdna:34]
[same as prior period, unchanged from 0001511737-14-000030:mdna:31]

[0001511737-15-000009:mdna:35]
17

[0001511737-15-000009:mdna:36]
[same as prior period, unchanged from 0001511737-14-000030:mdna:32]

[0001511737-15-000009:mdna:37]
Comparison of Three and Six Months Ended December 31, 2014 and 2013

[0001511737-15-000009:mdna:38]
|  | Three Months Ended December 31, |  | Six Months Ended December 31, |
|  | 2014 |  | 2013 |  | 2014 |  | 2013 |
|  | (In thousands, except percentages) |
| Revenues | $ | 153,137 |  |  | 100 | % |  | $ | 138,439 |  |  | 100 | % |  | $ | 303,224 |  |  | 100 | % |  | $ | 268,126 |  |  | 100 | % |
| Cost of revenues | 84,116 |  |  | 55 | % |  | 77,468 |  |  | 56 | % |  | 173,152 |  |  | 57 | % |  | 149,132 |  |  | 56 | % |
| Gross profit | 69,021 |  |  | 45 | % |  | 60,971 |  |  | 44 | % |  | 130,072 |  |  | 43 | % |  | 118,994 |  |  | 44 | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | 12,936 |  |  | 8 | % |  | 8,077 |  |  | 6 | % |  | 24,657 |  |  | 8 | % |  | 14,394 |  |  | 5 | % |
| Sales, general and administrative | 5,362 |  |  | 4 | % |  | 5,774 |  |  | 4 | % |  | 11,058 |  |  | 4 | % |  | 11,584 |  |  | 4 | % |
| Total operating expenses | 18,298 |  |  | 12 | % |  | 13,851 |  |  | 10 | % |  | 35,715 |  |  | 12 | % |  | 25,978 |  |  | 9 | % |
| Income from operations | 50,723 |  |  | 33 | % |  | 47,120 |  |  | 34 | % |  | 94,357 |  |  | 31 | % |  | 93,016 |  |  | 35 | % |
| Interest expense and other, net | 17 |  |  | * |  |  | (249 | ) |  | * |  |  | (41 | ) |  | * |  |  | (495 | ) |  | * |  |
| Income before provision for income taxes | 50,740 |  |  | 33 | % |  | 46,871 |  |  | 34 | % |  | 94,316 |  |  | 31 | % |  | 92,521 |  |  | 35 | % |
| Provision for income taxes | 4,475 |  |  | 3 | % |  | 5,079 |  |  | 4 | % |  | 10,308 |  |  | 3 | % |  | 10,201 |  |  | 4 | % |
| Net income and comprehensive income | $ | 46,265 |  |  | 30 | % |  | $ | 41,792 |  |  | 30 | % |  | $ | 84,008 |  |  | 28 | % |  | $ | 82,320 |  |  | 31 | % |
| * Less than 1% |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| (1) Includes stock-based compensation as follows: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of revenues | $ | 150 |  |  |  |  | $ | 148 |  |  |  |  | $ | 299 |  |  |  |  | $ | 292 |  |  |  |
| Research and development | 864 |  |  |  |  | 553 |  |  |  |  | 1,689 |  |  |  |  | 1,049 |  |  |  |
| Sales, general and administrative | 417 |  |  |  |  | 721 |  |  |  |  | 815 |  |  |  |  | 1,248 |  |  |  |
| Total stock-based compensation | $ | 1,431 |  |  |  |  | $ | 1,422 |  |  |  |  | $ | 2,803 |  |  |  |  | $ | 2,589 |  |  |  |

[0001511737-15-000009:mdna:39]
[same as prior period, unchanged from 0001511737-14-000030:mdna:35]

[0001511737-15-000009:mdna:40]
Revenues increased $14.7 million, or 11%, from $138.4 million in the three months ended December 31, 2013 to $153.1 million in the three months ended December 31, 2014.  Revenues increased $35.1 million, or 13%, from $268.1 million in the six months ended December 31, 2013 to $303.2 million in the six months ended December 31, 2014.  We believe the overall increase in revenues during both the three and six months ended December 31, 2014 was driven by increased adoption of our enterprise technologies, partially offset by lower demand from our service provider customers outside of North America as a result of political and economic instability in some of those regions.

[0001511737-15-000009:mdna:41]
[same as prior period, unchanged from 0001511737-14-000030:mdna:37]

[0001511737-15-000009:mdna:42]
|  | Three Months Ended December 31, |  | Six Months Ended December 31, |
|  | 2014 |  | 2013 |  | 2014 |  | 2013 |
|  | (in thousands, except percentages) |
| Service Provider Technology | $ | 99,720 |  |  | 65 | % |  | $ | 111,454 |  |  | 81 | % |  | $ | 206,991 |  |  | 68 | % |  | $ | 205,671 |  |  | 77 | % |
| Enterprise Technology | 53,417 |  |  | 35 | % |  | 26,985 |  |  | 19 | % |  | 96,233 |  |  | 32 | % |  | 62,455 |  |  | 23 | % |
| Total revenues | $ | 153,137 |  |  | 100 | % |  | $ | 138,439 |  |  | 100 | % |  | $ | 303,224 |  |  | 100 | % |  | $ | 268,126 |  |  | 100 | % |

[0001511737-15-000009:mdna:43]
Revenues from Service Provider Technologies decreased $11.7 million, or 11%, from $111.5 million in the three months ended December 31, 2013 to $99.7 million in the three months ended December 31, 2014, primarily due to lower demand from our service provider customers outside of North America as a result of political and economic instability in some of those regions.  Revenues from Service Provider Technologies remained relatively flat during  six months ended December 31, 2014 compared to the same period in the prior year.

[0001511737-15-000009:mdna:44]
Enterprise Technology revenues increased $26.4 million, or 98% from $27.0 million in the three months ended December 31, 2013 to $53.4 million in the three months ended December 31, 2014.  Enterprise Technology revenues increased $33.8 million,

[0001511737-15-000009:mdna:45]
18

[0001511737-15-000009:mdna:46]
or 54% from $62.5 million in the six months ended December 31, 2013 to $96.2 million in the six months ended December 31, 2014.  The increase in Enterprise Technology revenues during both the three and six months ended December 31, 2014 was due primarily to product expansion and further adoption of our UniFi technology platform.

[0001511737-15-000009:mdna:47]
[same as prior period, unchanged from 0001511737-14-000030:mdna:41]

[0001511737-15-000009:mdna:48]
We have determined the geographical distribution of our product revenues based on our customers' ship-to destinations. A majority of our sales are to distributors who in turn sell to resellers or directly to end customers, which may be different countries than the initial ship-to destination.  The following are our revenues by geography for the three and six months ended December 31, 2014 and 2013 (in thousands, except percentages):

[0001511737-15-000009:mdna:49]
|  | Three Months Ended December 31, |  | Six Months Ended December 31, |
|  | 2014 |  | 2013 |  | 2014 |  | 2013 |
| North America(1) | $ | 54,127 |  |  | 35 | % |  | $ | 32,567 |  |  | 24 | % |  | $ | 107,708 |  |  | 36 | % |  | $ | 70,000 |  |  | 26 | % |
| South America | 22,241 |  |  | 15 | % |  | 27,992 |  |  | 20 | % |  | 53,376 |  |  | 18 | % |  | 48,768 |  |  | 18 | % |
| Europe, the Middle East and Africa | 60,097 |  |  | 39 | % |  | 58,842 |  |  | 42 | % |  | 110,704 |  |  | 36 | % |  | 111,708 |  |  | 42 | % |
| Asia Pacific | 16,672 |  |  | 11 | % |  | 19,038 |  |  | 14 | % |  | 31,436 |  |  | 10 | % |  | 37,650 |  |  | 14 | % |
| Total revenues | $ | 153,137 |  |  | 100 | % |  | $ | 138,439 |  |  | 100 | % |  | $ | 303,224 |  |  | 100 | % |  | $ | 268,126 |  |  | 100 | % |

[0001511737-15-000009:mdna:50]
| (1) | Revenue for the United States was $50.5 million and $31.1 million for the three months ended December 31, 2014 and 2013, respectively. Revenue for the United States was $102.2 million and $67.3 million for the six months ended December 31, 2014 and 2013, respectively. |

[0001511737-15-000009:mdna:51]
[same as prior period, unchanged from 0001511737-14-000030:mdna:45]

[0001511737-15-000009:mdna:52]
Cost of revenues increased $6.6 million, or 9%, from $77.5 million in the three months ended December 31, 2013 to $84.1 million in the three months ended December 31, 2014.  Cost of revenues increased $24.0 million, or 16%, from $149.1 million in the six months ended December 31, 2013 to $173.2 million in the three months ended December 31, 2014.  The increase in cost of revenues in the three months ended December 31, 2014 was primarily due to our overall increase in revenues.  The increase in cost of revenues in the six months ended December 31, 2014 was primarily due to our overall increase in revenues and a non-recurring charge associated with a termination fee of $5.5 million for the cancellation of a purchase commitment during the three months ended September 30, 2014.

[0001511737-15-000009:mdna:53]
Gross profit increased to 45% in the three months ended December 31, 2014 compared to 44% in the three months ended December 31, 2013, and decreased to 43% in the six months ended December 31, 2014 compared to 44% in the six months ended December 31, 2013.  The increase in gross profit during the three months ended December 31, 2014 was primarily due to changes in product mix.  The decrease during the six months ended December 31, 2014 was  primarily due to a non-recurring charge associated with a termination fee of $5.5 million for the cancellation of a purchase commitment during the three months ended September 30, 2014.

[0001511737-15-000009:mdna:54]
[same as prior period, unchanged from 0001511737-14-000030:mdna:48]

[0001511737-15-000009:mdna:55]
[same as prior period, unchanged from 0001511737-14-000030:mdna:49]

[0001511737-15-000009:mdna:56]
Research and development expenses increased $4.9 million, or 60%, from $8.1 million in the three months ended December 31, 2013 to $12.9 million in the three months ended December 31, 2014. As a percentage of revenues, research and development expenses increased from 6% in the three months ended December 31, 2013 to 8% in the three months ended December 31, 2014.  Research and development expenses increased $10.3 million, or 71%, from $14.4 million in the six months ended December 31, 2013 to $24.7 million in the six months ended December 31, 2014. As a percentage of revenues, research and development expenses increased from 5% in the six months ended December 31, 2013 to 8% in the six months ended December 31, 2014.  The increase in research and development expenses in absolute dollars and as a percentage of revenues was due to increases in headcount to support our strategy as we broadened our research and development activities to new product areas and certain one-time costs incurred for IP purchased for use in our products. Over time, we expect our research and development costs to increase in absolute dollars as we continue making investments in developing new products and developing new versions of our existing products.

[0001511737-15-000009:mdna:57]
[same as prior period, unchanged from 0001511737-14-000030:mdna:51]

[0001511737-15-000009:mdna:58]
Sales, general and administrative expenses decreased slightly, from $5.8 million in the three months ended December 31, 2013 to $5.4 million in the three months ended December 31, 2014.  As a percentage of revenues, sales, general and administrative expenses remained flat at 4% in both the three months ended December 31, 2013 and December 31, 2014.  Sales, general and

[0001511737-15-000009:mdna:59]
19

[0001511737-15-000009:mdna:60]
administrative expenses decreased slightly, from $11.6 million in the six months ended December 31, 2013 to $11.1 million in the six months ended December 31, 2014.  As a percentage of revenues, sales, general and administrative expenses remained flat at 4% in the six months ended December 31, 2014 and 2013.

[0001511737-15-000009:mdna:61]
[same as prior period, unchanged from 0001511737-14-000030:mdna:55]

[0001511737-15-000009:mdna:62]
Our provision for income taxes decreased $604,000, or 12%, from $5.1 million for the three months ended December 31, 2013 to $4.5 million for the three months ended December 31, 2014. Our effective tax rate decreased to 9% for the three months ended December 31, 2014 as compared to 11% the three months ended December 31, 2013.  The lower effective tax rate in the three months ended December 31, 2014 was primarily due to the tax benefit of the retroactive extension of the U.S. federal research tax credit through December 31, 2014, by legislation signed into law on December 19, 2014.  Our provision for income taxes increased $107,000, or 1%, from $10.2 million for the six months ended December 31, 2013 to $10.3 million for the six months ended December 31, 2014. Our effective tax rate remained flat at 11% for the six months ended December 31, 2014 as compared to the six months ended December 31, 2013.

[0001511737-15-000009:mdna:63]
[same as prior period, unchanged from 0001511737-14-000030:mdna:57]

[0001511737-15-000009:mdna:64]
[same as prior period, unchanged from 0001511737-14-000030:mdna:58]

[0001511737-15-000009:mdna:65]
Since inception, our operations primarily have been funded through cash generated by operations. Cash and cash equivalents increased from $347.1 million at June 30, 2014 to $388.6 million at December 31, 2014.

[0001511737-15-000009:mdna:66]
[same as prior period, unchanged from 0001511737-14-000030:mdna:60]

[0001511737-15-000009:mdna:67]
[same as prior period, unchanged from 0001511737-14-000030:mdna:61]

[0001511737-15-000009:mdna:68]
|  | Six Months Ended December 31, |
|  | 2014 |  | 2013 |
|  | (In thousands) |
| Net cash provided by operating activities | $ | 79,618 |  |  | $ | 79,504 |  |
| Net cash used in investing activities | (8,391 | ) |  | (1,962 | ) |
| Net cash provided by (used in) financing activities | (29,721 | ) |  | 185 |  |
| Net increase in cash and cash equivalents | $ | 41,506 |  |  | $ | 77,727 |  |

[0001511737-15-000009:mdna:69]
[same as prior period, unchanged from 0001511737-14-000030:mdna:63]

[0001511737-15-000009:mdna:70]
Net cash provided by operating activities in the six months ended December 31, 2014 of $79.6 million consisted primarily of net income of $84.0 million partially offset by net changes in operating assets and liabilities that resulted in net cash outflows of $9.1 million. These changes consisted primarily of a $20.9 million increase in accounts payable and accrued liabilities due primarily to our increase in cost of revenues, a $20.2 million increase in prepaid expenses and other current assets due to timing of deposit payments with our suppliers, an $8.1 million increase in inventory due to our efforts to build warehouse stock levels and ultimately decrease lead times, a $1.4 million increase in taxes payable and a $1.3 million increase in prepaid taxes due to the timing of federal tax payments.  Additionally, our net income included non-cash adjustments due to stock-based compensation, depreciation and amortization, increases to our provision for inventory obsolescence, decreases in our allowance for doubtful accounts, a write-off of our intangible assets and taxes. The net of these non-cash adjustments resulted in an increase of our net cash provided by operating activities of $4.7 million.

[0001511737-15-000009:mdna:71]
Net cash provided by operating activities in the six months ended December 31, 2013 of $79.5 million consisted primarily of net income of $82.3 million partially offset by net changes in operating assets and liabilities that resulted in net cash outflows of $6.4 million. These changes consisted primarily of a $17.4 million increase in inventory due to our efforts to build warehouse stock levels and ultimately decrease lead times, a $13.9 million increase in accounts payable and accrued liabilities due primarily to our increase in cost of revenues, a $2.8 million increase in prepaid taxes due to the timing of federal tax payments, a $1.3 million increase in taxes payable and a $1.3 million increase in prepaid expenses and other current assets due to timing of deposit payments with our suppliers. Additionally, our net income included non-cash adjustments due to stock-based compensation, depreciation and amortization, increases to our provision for inventory obsolescence, decreases in our allowance for doubtful accounts, a write-off of our intangible assets and taxes. The net of these non-cash adjustments resulted in an increase of our net cash provided by operating activities of $3.5 million.

[0001511737-15-000009:mdna:72]
[same as prior period, unchanged from 0001511737-14-000030:mdna:71]

[0001511737-15-000009:mdna:73]
[same as prior period, unchanged from 0001511737-14-000030:mdna:66]

[0001511737-15-000009:mdna:74]
Our investing activities consist solely of capital expenditures and purchases of intangible assets. Capital expenditures for the six months ended December 31, 2014 and 2013 were $8.4 million and $1.8 million, respectively.  Capital expenditures during the six months ended December 31, 2014 included machinery and equipment purchases for our product development and prototyping facility in China.  Additionally, we had cash outflows related to the purchase of intangible assets of $30,000 and $153,000 during the six months ended December 31, 2014 and 2013, respectively.

[0001511737-15-000009:mdna:75]
[same as prior period, unchanged from 0001511737-14-000030:mdna:68]

[0001511737-15-000009:mdna:76]
We had $29.7 million of cash used in financing activities during the six months ended December 31, 2014, which consisted of cash paid for dividends on our common stock of $15.0 million, cash paid for repurchases of our common stock of $15.0 million and tax withholdings related to net share settlements of restricted stock units of $1.0 million, partially offset by cash received for stock option exercises of $497,000 and an excess tax benefit from employee stock-based awards of $787,000.

[0001511737-15-000009:mdna:77]
We had $185,000 of cash provided by financing activities during the six months ended December 31, 2013, which consisted of an excess tax benefit from employee stock-based awards of $2.6 million and cash received for stock option exercises of $1.0 million, partially offset by repayments on our term loan balance with East West Bank of $2.5 million and tax withholdings related to net share settlements of restricted stock units of $908,000.

[0001511737-15-000009:mdna:78]
[same as prior period, unchanged from 0001511737-14-000030:mdna:72]

[0001511737-15-000009:mdna:79]
We believe our existing cash and cash equivalents, cash provided by operations and the availability of additional funds under our loan agreements will be sufficient to meet our working capital and capital expenditure needs for at least the next 12 months. Our future capital requirements may vary materially from those currently planned and will depend on many factors, including our rate of revenue growth, the timing and extent of spending to support development efforts, the timing of new product introductions, market acceptance of our products and overall economic conditions. As of December 31, 2014, we held $361.6 million of our $388.6 million of cash and cash equivalents in accounts of our subsidiaries outside of the United States and we will incur significant tax liabilities if we decide to repatriate those amounts.

[0001511737-15-000009:mdna:80]
[same as prior period, unchanged from 0001511737-14-000030:mdna:76]

[0001511737-15-000009:mdna:81]
Our products are generally accompanied by a 12 month warranty, which covers both parts and labor. Generally the distributor is responsible for the freight costs associated with warranty returns, and we absorb the freight costs of replacing items under warranty. In accordance with the Financial Accounting Standards Board’s (“FASB’s”), Accounting Standards Codification (“ASC”), 450-30, Loss Contingencies, we record an accrual when we believe it is estimable and probable based upon historical experience. We record a provision for estimated future warranty work in cost of goods sold upon recognition of revenues and we review the resulting accrual regularly and periodically adjust it to reflect changes in warranty estimates.

[0001511737-15-000009:mdna:82]
[same as prior period, unchanged from 0001511737-14-000030:mdna:78]

[0001511737-15-000009:mdna:83]
We have agreed to indemnify our directors, officers and certain other employees for certain events or occurrences, subject to certain limits, while such persons are or were serving at our request in such capacity. We may terminate the indemnification agreements with these persons upon the termination of their services with us but termination will not affect claims for indemnification related to events occurring prior to the effective date of termination. The maximum amount of potential future indemnification is unlimited. We have a Directors and Officers insurance policy that limits our potential exposure. We believe the fair value of these indemnification agreements is minimal.  We had not recorded any liabilities for these agreements as of December 31, 2014.

[0001511737-15-000009:mdna:84]
Based upon our historical experience and information known as of the date of this report, we do not believe it is likely that we will have significant liability for the above indemnities at December 31, 2014.

[0001511737-15-000009:mdna:85]
[same as prior period, unchanged from 0001511737-14-000030:mdna:82]

[0001511737-15-000009:mdna:86]
The following table summarizes our contractual obligations as of December 31, 2014 for the remainder of fiscal 2014 and future fiscal years:

[0001511737-15-000009:mdna:87]
|  | 2015 (remainder) |  | 2016 |  | 2017 |  | 2018 |  | 2019 |  | Thereafter |  | Total |
| Operating leases | $ | 1,690 |  |  | $ | 3,270 |  |  | $ | 1,903 |  |  | $ | 506 |  |  | $ | 53 |  |  | $ | — |  |  | $ | 7,422 |  |
| Debt payment obligations | — |  |  | — |  |  | — |  |  | — |  |  | 72,254 |  |  | — |  |  | 72,254 |  |
| Interest payments on debt payment obligations | 510 |  |  | 1,019 |  |  | 1,019 |  |  | 1,019 |  |  | 863 |  |  | — |  |  | 4,430 |  |
| Purchase obligations | 185 |  |  |  |  |  |  |  |  |  |  |  |  | 185 |  |
| Other obligations | 487 |  |  | 62 |  |  | 27 |  |  | 3 |  |  |  |  |  |  | 579 |  |
| Total | $ | 2,872 |  |  | $ | 4,351 |  |  | $ | 2,949 |  |  | $ | 1,528 |  |  | $ | 73,170 |  |  | $ | — |  |  | $ | 84,870 |  |

[0001511737-15-000009:mdna:88]
[same as prior period, unchanged from 0001511737-14-000030:mdna:85]

[0001511737-15-000009:mdna:89]
We lease our headquarters in San Jose, California and other locations worldwide under non-cancelable operating leases that expire at various dates through 2019.

[0001511737-15-000009:mdna:90]
[same as prior period, unchanged from 0001511737-14-000030:mdna:87]

[0001511737-15-000009:mdna:91]
On May 5, 2014, we entered into a credit agreement ("the Credit Agreement") with Wells Fargo Bank, National Association, or Wells Fargo, the financial institutions named as lenders therein, and Wells Fargo as administrative agent for the lenders, that provides for a $150 million senior secured revolving credit facility, with an option to request an increase in the amount of the credit facility by up to an additional $50 million (any such increase to be in each lender’s sole discretion).  We initially borrowed $72.3 million under the Credit Agreement, which was used to repay obligations under our Loan Agreement with East West Bank and to pay transaction fees and costs.

[0001511737-15-000009:mdna:92]
[same as prior period, unchanged from 0001511737-14-000030:mdna:89]

[0001511737-15-000009:mdna:93]
[same as prior period, unchanged from 0001511737-14-000030:mdna:90]

[0001511737-15-000009:mdna:94]
[same as prior period, unchanged from 0001511737-14-000030:mdna:91]

[0001511737-15-000009:mdna:95]
We had other obligations of $487,000 as of December 31, 2014, which consisted primarily of commitments to acquire capital assets, including manufacturing equipment.

[0001511737-15-000009:mdna:96]
[same as prior period, unchanged from 0001511737-14-000030:mdna:93]

[0001511737-15-000009:mdna:97]
As of December 31, 2014, we had $17.0 million of unrecognized tax benefits, substantially all of which would, if recognized, affect our tax expense. We have elected to include interest and penalties related to uncertain tax positions as a component of tax expense. We do not expect any significant increases or decreases to our unrecognized tax benefits in the next twelve months.

[0001511737-15-000009:mdna:98]
[same as prior period, unchanged from 0001511737-14-000030:mdna:95]

[0001511737-15-000009:mdna:99]
[same as prior period, unchanged from 0001511737-14-000030:mdna:96]

[0001511737-15-000009:mdna:100]
[same as prior period, unchanged from 0001511737-14-000030:mdna:97]

[0001511737-15-000009:mdna:101]
Regulation G, conditions for use of Non-Generally Accepted Accounting Principles (“Non-GAAP”) financial measures, and other SEC regulations define and prescribe the conditions for use of certain Non-GAAP financial information. To supplement our condensed consolidated financial results presented in accordance with GAAP, we use Non-GAAP financial measures which are adjusted from the most directly comparable GAAP financial measures to exclude certain items, as described below. Management believes that these Non-GAAP financial measures reflect an additional and useful way of viewing aspects of our operations that, when viewed in conjunction with our GAAP results, provide a more comprehensive understanding of the

[0001511737-15-000009:mdna:102]
various factors and trends affecting our business and operations. Non-GAAP financial measures used by us include net income or loss and diluted net income or loss per share.

[0001511737-15-000009:mdna:103]
Our Non-GAAP measures primarily exclude stock-based compensation, net of taxes and other special charges and credits.  Additionally, during the six months ended December 31, 2014 we recorded a one-time charge of $5.5 million due to a termination fee related to a purchase commitment entered into during fiscal 2014.  Management believes these Non-GAAP financial measures provide meaningful supplemental information regarding our strategic and business decision making, internal budgeting, forecasting and resource allocation processes. In addition, these Non-GAAP financial measures facilitate management’s internal comparisons to our historical operating results and comparisons to competitors’ operating results.

[0001511737-15-000009:mdna:104]
[same as prior period, unchanged from 0001511737-14-000030:mdna:100]

[0001511737-15-000009:mdna:105]
[same as prior period, unchanged from 0001511737-14-000030:mdna:101]

[0001511737-15-000009:mdna:106]
|  | Three Months Ended December 31, |  | Six Months Ended December 31, |
|  | 2014 |  | 2013 |  | 2014 |  | 2013 |
|  | (In thousands, except per share amounts) |
| Non-GAAP net income and comprehensive income | $ | 47,124 |  |  | $ | 42,645 |  |  | $ | 90,530 |  |  | $ | 83,873 |  |
| Non-GAAP diluted net income per share of common stock | $ | 0.53 |  |  | $ | 0.48 |  |  | $ | 1.01 |  |  | $ | 0.94 |  |

[0001511737-15-000009:mdna:107]
[same as prior period, unchanged from 0001511737-14-000030:mdna:104]

[0001511737-15-000009:mdna:108]
[same as prior period, unchanged from 0001511737-14-000030:mdna:105]

[0001511737-15-000009:mdna:109]
|  | Three Months Ended December 31, |  | Six Months Ended December 31, |
|  | 2014 |  | 2013 |  | 2014 |  | 2013 |
|  | (In thousands, except pershare amounts) |
| Net income and comprehensive income | $ | 46,265 |  |  | $ | 41,792 |  |  | $ | 84,008 |  |  | $ | 82,320 |  |
| Stock-based compensation: |  |  |  |  |  |  |  |
| Cost of revenues | 150 |  |  | 148 |  |  | 299 |  |  | 292 |  |
| Research and development | 864 |  |  | 553 |  |  | 1,689 |  |  | 1,049 |  |
| Sales, general and administrative | 417 |  |  | 721 |  |  | 815 |  |  | 1,248 |  |
| Purchase commitment termination fee | — |  |  | — |  |  | 5,500 |  |  | — |  |
| Tax effect of non-GAAP adjustments | (572 | ) |  | (569 | ) |  | (1,781 | ) |  | (1,036 | ) |
| Non-GAAP net income and comprehensive income | $ | 47,124 |  |  | $ | 42,645 |  |  | $ | 90,530 |  |  | $ | 83,873 |  |
| Non-GAAP diluted net income per share of common stock | $ | 0.53 |  |  | $ | 0.48 |  |  | $ | 1.01 |  |  | $ | 0.94 |  |
| Weighted-average shares used in computing non-GAAP diluted net income per share of common stock | 89,737 |  |  | 89,653 |  |  | 89,838 |  |  | 89,593 |  |

[0001511737-15-000009:mdna:110]
23
