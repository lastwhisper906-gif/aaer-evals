# UI note change history — 0001511737-14-000030 → 0001511737-15-000009


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2015-02-05):
[0001511737-15-000009:note_history:1]
At December 31, 2014, future minimum annual payments under operating leases are as follows (in thousands):
  (was, 2014-11-06, similarity 0.9751):
[0001511737-14-000030:note_history:1]
At September 30, 2014, future minimum annual payments under operating leases are as follows (in thousands):

- changed (2015-02-05):
[0001511737-15-000009:note_history:2]
|  | 2015 (remainder) |  | 2016 |  | 2017 |  | 2018 |  | 2019 |  | Thereafter |  | Total |
| Operating leases | $ | 1,690 |  |  | $ | 3,270 |  |  | $ | 1,903 |  |  | $ | 506 |  |  | $ | 53 |  |  | $ | — |  |  | $ | 7,422 |  |
  (was, 2014-11-06, similarity 0.9971):
[0001511737-14-000030:note_history:2]
|  | 2015(remainder) |  | 2016 |  | 2017 |  | 2018 |  | 2019 |  | Thereafter |  | Total |
| Operating leases | $ | 2,277 |  |  | $ | 2,986 |  |  | $ | 1,648 |  |  | $ | 358 |  |  | $ | 53 |  |  | $ | — |  |  | $ | 7,322 |  |

- changed (2015-02-05):
[0001511737-15-000009:note_history:3]
Purchase Obligations
  (was, 2014-11-06, similarity 0.7):
[0001511737-14-000030:note_history:3]
Purchase Commitments

- changed (2015-02-05):
[0001511737-15-000009:note_history:4]
The Company had other obligations of $487,000 as of December 31, 2014, which consisted primarily of commitments to acquire capital assets, including manufacturing equipment.
  (was, 2014-11-06, similarity 0.9607):
[0001511737-14-000030:note_history:4]
The Company had other obligations of $1.2 million as of September 30, 2014, which consisted primarily of commitments to acquire capital assets, including manufacturing equipment.

- removed (2015-02-05):
[0001511737-14-000030:note_history:5]
Export Compliance Matters

- removed (2015-02-05):
[0001511737-14-000030:note_history:6]
In May 2011, the Company filed a self-disclosure statement with the U.S. Commerce Department, Bureau of Industry and Security’s (“BIS”) Office of Export Enforcement (“OEE”) relating to a review conducted by the Company regarding certain export transactions from 2008 through March 2011 in which products may have been later resold into Iran by third parties. In June 2011, the Company also filed a self-disclosure statement with the U.S. Department of the Treasury’s Office of Foreign Asset Control (“OFAC”) regarding these compliance issues. In August 2011, the Company received a warning letter from OEE stating that OEE had not referred the findings of the Company’s review for criminal or administrative prosecution and closed the investigation of the Company without penalty. Based upon its review of the matter, OFAC identified certain apparent violations (“Apparent Violations”) of the Iranian Transactions and Sanctions Regulations by the Company during the period of in or about March 2008 through in or about February 2011. On March 4, 2014, the Company entered into a settlement agreement with OFAC resolving this administrative matter. Pursuant to the terms of the settlement agreement, the Company agreed to make a one-time payment to the U.S. Department of the Treasury in the amount of $504,000 in consideration of OFAC agreeing to release and forever discharge the Company from any and all civil liability in connection with the Apparent Violations. The Company previously accrued a reserve of $1.6 million relating to this matter in fiscal 2010 and, accordingly, reversed the excess of the accrual of $1.1 million as of the effective date of the settlement agreement.


## us-gaap:BusinessDescriptionAndBasisOfPresentationTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2015-02-05):
[0001511737-15-000009:note_history:7]
Ubiquiti Networks, Inc. and its wholly owned subsidiaries (collectively, “Ubiquiti” or the “Company”) develops high performance networking technology for service providers and enterprises.

- changed (2015-02-05):
[0001511737-15-000009:note_history:8]
These condensed consolidated financial statements should be read in conjunction with the Company’s audited consolidated financial statements for the fiscal year ended June 30, 2014 included in its Annual Report on Form 10-K, as filed on August 22, 2014 with the SEC (the “Annual Report”). The results of operations for the three and six months ended December 31, 2014 are not necessarily indicative of the results to be expected for any future periods.
  (was, 2014-11-06, similarity 0.7769):
[0001511737-14-000030:note_history:8]
These condensed consolidated financial statements should be read in conjunction with the Company’s audited consolidated financial statements for the fiscal year ended June 30, 2014 included in its Annual Report on Form 10-K, as filed on August 22, 2014 with the SEC (the “Annual Report”). The results of operations for the three months ended September 30, 2014 are not necessarily indicative of the results to be expected for any future periods.

- removed (2015-02-05):
[0001511737-14-000030:note_history:9]
Ubiquiti Networks, Inc. and its wholly owned subsidiaries (collectively, “Ubiquiti” or the “Company”) is a product driven company that leverages innovative proprietary technologies to deliver networking solutions to both startup and established network operators and service providers.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2015-02-05):
[0001511737-15-000009:note_history:10]
The Company’s significant accounting policies are disclosed in its audited consolidated financial statements for the year ended June 30, 2014 included in the Annual Report.   Except as noted below, there have been no changes to the Company's significant accounting policies as discussed in the Annual Report.
  (was, 2014-11-06, similarity 0.7137):
[0001511737-14-000030:note_history:10]
The Company’s significant accounting policies are disclosed in its audited consolidated financial statements for the year ended June 30, 2014 included in the Annual Report.

- added (2015-02-05):
[0001511737-15-000009:note_history:11]
Capitalized Software Development Costs

- added (2015-02-05):
[0001511737-15-000009:note_history:12]
The Company capitalizes certain costs of software developed for internal use.  Capitalized costs primarily include payroll and payroll-related costs and facilities costs. The cost of internally developed software is amortized on a straight-line basis over its estimated useful life, typically 3 to 5 years.  During the three and six months ended December 31, 2014, the Company capitalized $1.5 million of software development costs, which is included as property and equipment in the Company's balance sheet as of  December 31, 2014.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2015-02-05):
[0001511737-15-000009:note_history:13]
On August 7, 2012, the Company entered into a Loan and Security Agreement (the “Loan Agreement”) with U.S. Bank, as syndication agent, and East West Bank, as administrative agent for the lenders party to the Loan Agreement.  The Loan Agreement provides for (i) a $50.0 million revolving credit facility, with a $5.0 million sublimit for the issuance of letters of credit and a $5.0 million sublimit for the making of swingline loan advances (the “Revolving Credit Facility”), and (ii) a $50.0 million term loan facility (the “Term Loan Facility”).  The Loan Agreement replaced a previous agreement whereby the Company had an existing term loan balance of $29.2 million as of the date the new Loan Agreement.  On August 7, 2012, the Company borrowed $20.8 million under the Term Loan Facility, and no borrowings remain available for borrowing thereunder.  On November 21, 2012, the Company borrowed $10.0 million under the Revolving Credit Facility. On December 20, 2012, the Company borrowed an additional $20.0 million under the Revolving Credit Facility, and $20.0 million remained available for borrowing thereunder.  During the three and six months ended December 31, 2013 the Company made aggregate payments of $1.3 million and $2.5 million against the loan balance, respectively.
  (was, 2014-11-06, similarity 0.8683):
[0001511737-14-000030:note_history:13]
On August 7, 2012, the Company entered into a Loan and Security Agreement (the “Loan Agreement”) with U.S. Bank, as syndication agent, and East West Bank, as administrative agent for the lenders party to the Loan Agreement.  The Loan Agreement provides for (i) a $50.0 million revolving credit facility, with a $5.0 million sublimit for the issuance of letters of credit and a $5.0 million sublimit for the making of swingline loan advances (the “Revolving Credit Facility”), and (ii) a $50.0 million term loan facility (the “Term Loan Facility”). The Company may request borrowings under the Revolving Credit Facility until August 7, 2015.  The Loan Agreement replaced a previous agreement whereby the Company had an existing term loan balance of $29.2 million as of the date the new Loan Agreement.  On August 7, 2012, the Company borrowed $20.8 million under the Term Loan Facility, and no borrowings remain available for borrowing thereunder.  On November 21, 2012, the Company borrowed $10.0 million under the Revolving Credit Facility. On December 20, 2012, the Company borrowed an additional $20.0 million under the Revolving Credit Facility, and $20.0 million remains available for borrowing thereunder.  During the three months ended September 30, 2013 the Company made aggregate payments of $1.3 million against the loan balance.

- changed (2015-02-05):
[0001511737-15-000009:note_history:14]
On May 5, 2014, the Company and certain of its subsidiaries entered into a credit agreement (the “Credit Agreement”) with Wells Fargo Bank, National Association (“Wells Fargo”), the financial institutions named as lenders therein, and Wells Fargo as administrative agent for the lenders, that provides for a $150 million senior secured revolving credit facility, with an option to request an increase in the amount of the credit facility by up to an additional $50 million (any such increase to be in each lender’s sole discretion).  The Company may borrow up to $110 million of the facility as a U.S. sublimit.  The entire amount of the facility is available to Ubiquiti International Holding Company Limited, a wholly-owned subsidiary of the Company organized under the laws of the Cayman Islands.  The credit facility includes a sub-limit of $5 million for letters of credit and a sub-limit of $15 million for swingline loans.   In connection with the execution of the Credit Agreement, the Company terminated the $50 million line of credit facility under the Loan Agreement with East West Bank described above.  Under the Credit Agreement, revolving loans and swingline loans may be borrowed, repaid and reborrowed until May 5, 2019, at which time all amounts borrowed must be repaid.   Additionally, as of December 31, 2014, $72.3 million is outstanding under the Credit Agreement, which was borrowed by the Company to repay obligations under the Loan Agreement and to pay transaction fees and costs.  Revolving loans bear interest, at the Company’s option, at either (i) a floating rate per annum equal to the base rate plus a margin of between 0.250% and 1.000%, depending on the Company’s leverage ratio as of the most recently ended fiscal quarter or (ii) a per annum rate equal to the applicable LIBOR rate for a specified period, plus a margin of between 1.250% and 2.000%, depending on the Company’s leverage ratio as of the most recently ended fiscal quarter.  Swingline loans will bear interest at a floating rate per annum equal to the base rate plus a margin of between 0.250% and 1.000%, depending on the Company’s leverage ratio as of the most recently ended fiscal quarter.   Base rate is defined as the greatest of (A) Wells Fargo’s prime rate, (B) the federal funds rate plus 0.500% or (C) a per annum rate equal to the rate at which dollar deposits are offered in the London interbank market for a period of one month plus 1.000%.  A default interest rate shall apply on all obligations during a payment event of default under the Credit Agreement at a rate per annum equal to 2.000% above the applicable interest rate. The Company will pay to each lender a facility fee on a quarterly basis based on the unused amount of each lender’s commitment to make loans, of between 0.200% and 0.350%, depending on the Company’s leverage ratio as of the most recently ended fiscal quarter.  Revolving loans and swingline loans may be prepaid at any time without penalty.  The Company is also obligated to pay Wells Fargo, as agent, fees customary for a credit facility of this size and type.
  (was, 2014-11-06, similarity 0.9952):
[0001511737-14-000030:note_history:14]
On May 5, 2014, the Company and certain of its subsidiaries entered into a credit agreement (the “Credit Agreement”) with Wells Fargo Bank, National Association (“Wells Fargo”), the financial institutions named as lenders therein, and Wells Fargo as administrative agent for the lenders, that provides for a $150 million senior secured revolving credit facility, with an option to request an increase in the amount of the credit facility by up to an additional $50 million (any such increase to be in each lender’s sole discretion).  The Company may borrow up to $110 million of the facility as a U.S. sublimit.  The entire amount of the facility is available to Ubiquiti International Holding Company Limited, a wholly-owned subsidiary of the Company organized under the laws of the Cayman Islands.  The credit facility includes a sub-limit of $5 million for letters of credit and a sub-limit of $15 million for swingline loans.   In connection with the execution of the Credit Agreement, the Company terminated the $50 million line of credit facility under the Loan Agreement with East West Bank described above.  Under the Credit Agreement, revolving loans and swingline loans may be borrowed, repaid and reborrowed until May 5, 2019, at which time all amounts borrowed must be repaid.   Additionally, $72.3 million is currently outstanding under the Credit Agreement, which was borrowed by the Company to repay obligations under the Loan Agreement and to pay transaction fees and costs.  Revolving loans bear interest, at the Company’s option, at either (i) a floating rate per annum equal to the base rate plus a margin of between 0.250% and 1.000%, depending on the Company’s leverage ratio as of the most recently ended fiscal quarter or (ii) a per annum rate equal to the applicable LIBOR rate for a specified period, plus a margin of between 1.250% and 2.000%, depending on the Company’s leverage ratio as of the most recently ended fiscal quarter.  Swingline loans will bear interest at a floating rate per annum equal to the base rate plus a margin of between 0.250% and 1.000%, depending on the Company’s leverage ratio as of the most recently ended fiscal quarter.   Base rate is defined as the greatest of (A) Wells Fargo’s prime rate, (B) the federal funds rate plus 0.500% or (C) a per annum rate equal to the rate at which dollar deposits are offered in the London interbank market for a period of one month plus 1.000%.  A default interest rate shall apply on all obligations during a payment event of default under the Credit Agreement at a rate per annum equal to 2.000% above the applicable interest rate. The Company will pay to each lender a facility fee on a quarterly basis based on the unused amount of each lender’s commitment to make loans, of between 0.200% and 0.350%, depending on the Company’s leverage ratio as of the most recently ended fiscal quarter.  Revolving loans and swingline loans may be prepaid at any time without penalty.  The Company is also obligated to pay Wells Fargo, as agent, fees customary for a credit facility of this size and type.

- changed (2015-02-05):
[0001511737-15-000009:note_history:15]
No payments were made for borrowings under the Credit Agreement with Wells Fargo during the three and six months ended December 31, 2014.  As of December 31, 2014, the Company has classified $72.3 million of long-term debt on its consolidated balance sheet related to the Credit Agreement.
  (was, 2014-11-06, similarity 0.7948):
[0001511737-14-000030:note_history:15]
No payments were made for borrowings under the Credit Agreement with Wells Fargo in the three months ended September 30, 2014.  As of September 30, 2014, the Company has classified $72.3 million of long-term debt on its consolidated balance sheet related to the Credit Agreement.

- changed (2015-02-05):
[0001511737-15-000009:note_history:16]
The following table summarizes our estimated debt and interest payment obligations as of December 31, 2014 (in thousands):
  (was, 2014-11-06, similarity 0.9787):
[0001511737-14-000030:note_history:16]
The following table summarizes our estimated debt and interest payment obligations as of September 30, 2014 (in thousands):

- changed (2015-02-05):
[0001511737-15-000009:note_history:17]
|  | 2015 (remainder) |  | 2016 |  | 2017 |  | 2018 |  | 2019 |  | Total |
| Debt payment obligations | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 72,254 |  |  | $ | 72,254 |  |
| Interest payments on debt payment obligations | 510 |  |  | 1,019 |  |  | 1,019 |  |  | 1,019 |  |  | 863 |  |  | 4,430 |  |
| Total | $ | 510 |  |  | $ | 1,019 |  |  | $ | 1,019 |  |  | $ | 1,019 |  |  | $ | 73,117 |  |  | $ | 76,684 |  |
  (was, 2014-11-06, similarity 0.9985):
[0001511737-14-000030:note_history:17]
|  | 2015(remainder) |  | 2016 |  | 2017 |  | 2018 |  | 2019 |  | Total |
| Debt payment obligations | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 72,254 |  |  | $ | 72,254 |  |
| Interest payments on debt payment obligations | 761 |  |  | 1,014 |  |  | 1,014 |  |  | 1,014 |  |  | 858 |  |  | 4,661 |  |
| Total | $ | 761 |  |  | $ | 1,014 |  |  | $ | 1,014 |  |  | $ | 1,014 |  |  | $ | 73,112 |  |  | $ | 76,915 |  |


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2015-02-05):
[0001511737-15-000009:note_history:18]
The following table summarizes our estimated debt and interest payment obligations as of December 31, 2014 (in thousands):
  (was, 2014-11-06, similarity 0.9787):
[0001511737-14-000030:note_history:18]
The following table summarizes our estimated debt and interest payment obligations as of September 30, 2014 (in thousands):

- changed (2015-02-05):
[0001511737-15-000009:note_history:19]
|  | 2015 (remainder) |  | 2016 |  | 2017 |  | 2018 |  | 2019 |  | Total |
| Debt payment obligations | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 72,254 |  |  | $ | 72,254 |  |
| Interest payments on debt payment obligations | 510 |  |  | 1,019 |  |  | 1,019 |  |  | 1,019 |  |  | 863 |  |  | 4,430 |  |
| Total | $ | 510 |  |  | $ | 1,019 |  |  | $ | 1,019 |  |  | $ | 1,019 |  |  | $ | 73,117 |  |  | $ | 76,684 |  |
  (was, 2014-11-06, similarity 0.9985):
[0001511737-14-000030:note_history:19]
|  | 2015(remainder) |  | 2016 |  | 2017 |  | 2018 |  | 2019 |  | Total |
| Debt payment obligations | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 72,254 |  |  | $ | 72,254 |  |
| Interest payments on debt payment obligations | 761 |  |  | 1,014 |  |  | 1,014 |  |  | 1,014 |  |  | 858 |  |  | 4,661 |  |
| Total | $ | 761 |  |  | $ | 1,014 |  |  | $ | 1,014 |  |  | $ | 1,014 |  |  | $ | 73,112 |  |  | $ | 76,915 |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2015-02-05):
[0001511737-15-000009:note_history:20]
On November 13, 2013, the Company entered into an aircraft lease agreement (the "Aircraft Lease Agreement") with RJP Manageco LLC (the "Lessor"), a limited liability company owned by the Company’s CEO, Robert J. Pera. Pursuant to the Aircraft Lease Agreement, the Company may lease an aircraft owned by the Lessor for Company business purposes. Under the Aircraft Lease Agreement, the aircraft may be leased at a rate of $5,000 per flight hour. This hourly rate does not include the cost of flight crew or on-board services, which the Company will purchase from a third-party provider. The Company recognized a total of approximately $29,000 and $180,000 in expenses pursuant to the Aircraft Lease Agreement during the three and six months ended December 31, 2014, respectively.  All expenses pursuant to the Aircraft Lease Agreement have been included in the Company's sales, general and administrative expenses in the Condensed Consolidated Statements of Operations.
  (was, 2014-11-06, similarity 0.724):
[0001511737-14-000030:note_history:20]
On November 13, 2013, the Company entered into an aircraft lease agreement (the "Aircraft Lease Agreement") with RJP Manageco LLC (the "Lessor"), a limited liability company owned by the Company’s CEO, Robert J. Pera. Pursuant to the Aircraft Lease Agreement, the Company may lease an aircraft owned by the Lessor for Company business purposes. Under the Aircraft Lease Agreement, the aircraft may be leased at a rate of $5,000 per flight hour. This hourly rate does not include the cost of flight crew or on-board services, which the Company purchases from a third-party provider. The Company recognized a total of approximately $151,000 in expenses pursuant to the Aircraft Lease Agreement during the three months ended September 30, 2014.  All expenses pursuant to the Aircraft Lease Agreement have been included in the Company's sales, general and administrative expenses in the Condensed Consolidated Statements of Operations.
