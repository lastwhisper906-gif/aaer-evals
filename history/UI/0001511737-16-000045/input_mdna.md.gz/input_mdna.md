# UI MD&A — 0001511737-16-000045


## mdna

[0001511737-16-000045:mdna:1]
[same as prior period, unchanged from 0001511737-16-000037:mdna:1]

[0001511737-16-000045:mdna:2]
[same as prior period, unchanged from 0001511737-16-000037:mdna:2]

[0001511737-16-000045:mdna:3]
[same as prior period, unchanged from 0001511737-16-000037:mdna:3]

[0001511737-16-000045:mdna:4]
We offer a broad and expanding portfolio of networking products and solutions for service providers and enterprises. Our service provider product platforms provide carrier-class network infrastructure for fixed wireless broadband, wireless backhaul systems and routing. Our enterprise product platforms provide wireless LAN infrastructure, video surveillance products, switching and routing solutions and machine-to-machine communication components. We believe that our products are highly differentiated due to our proprietary software protocol innovation, firmware expertise, and hardware design capabilities. This differentiation allows our portfolio to meet the demanding performance requirements of video, voice and data applications at prices that are a fraction of those offered by our competitors.

[0001511737-16-000045:mdna:5]
In May 2016, we announced Ubiquiti Labs, a division focusing on research and development of consumer electronics. At the same time, we announced a new consumer product platform, called AmpliFi, which is a Wi-Fi system solution designed to serve the demands of the modern connected home.

[0001511737-16-000045:mdna:6]
[same as prior period, unchanged from 0001511737-16-000037:mdna:5]

[0001511737-16-000045:mdna:7]
| • | Rapid customer and community driven product development. We have an active, loyal community built by our customers that we believe is a sustainable competitive advantage. Our solutions benefit from the active engagement between the Ubiquiti Community and our development engineers throughout the product development cycle, which |

[0001511737-16-000045:mdna:8]
eliminates long and expensive multistep internal processes and results in rapid introduction and adoption of our products. This approach significantly reduces our development costs and time to market.

[0001511737-16-000045:mdna:9]
[same as prior period, unchanged from 0001511737-16-000037:mdna:7]

[0001511737-16-000045:mdna:10]
[same as prior period, unchanged from 0001511737-16-000037:mdna:8]

[0001511737-16-000045:mdna:11]
[same as prior period, unchanged from 0001511737-16-000037:mdna:9]

[0001511737-16-000045:mdna:12]
[same as prior period, unchanged from 0001511737-16-000037:mdna:10]

[0001511737-16-000045:mdna:13]
[same as prior period, unchanged from 0001511737-16-000037:mdna:11]

[0001511737-16-000045:mdna:14]
[same as prior period, unchanged from 0001511737-16-000037:mdna:12]

[0001511737-16-000045:mdna:15]
[same as prior period, unchanged from 0001511737-16-000037:mdna:13]

[0001511737-16-000045:mdna:16]
[same as prior period, unchanged from 0001511737-16-000037:mdna:14]

[0001511737-16-000045:mdna:17]
| • | Enterprise Technology includes our UniFi and mFi platforms, including UniFi enterprise Wi-Fi, UniFi Video Products, AmpliFi, UniFi switching and routing solutions. Enterprise Technology also includes revenues that are attributable to PCS. Enterprise Technology also includes revenues that are attributable to PCS. |

[0001511737-16-000045:mdna:18]
We sell substantially all of our products through a limited number of distributors and other channel partners, such as resellers and Original Equipment Manufacturers (“OEMs”). Sales to distributors accounted for 99% of our revenues in the three months ended September 30, 2016.

[0001511737-16-000045:mdna:19]
[same as prior period, unchanged from 0001511737-16-000037:mdna:17]

[0001511737-16-000045:mdna:20]
[same as prior period, unchanged from 0001511737-16-000037:mdna:18]

[0001511737-16-000045:mdna:21]
In addition to utilizing contract manufacturers, we outsource most of our logistics warehousing and order fulfillment functions, which are located primarily in China, and to a lesser extent, Taiwan and the United States. We also evaluate and utilize other vendors for various portions of our supply chain from time to time. Our operations organization consists of employees and consultants engaged in the management of our contract manufacturers, new product introduction activities, logistical support and engineering.

[0001511737-16-000045:mdna:22]
[same as prior period, unchanged from 0001511737-16-000037:mdna:20]

[0001511737-16-000045:mdna:23]
[same as prior period, unchanged from 0001511737-16-000037:mdna:21]

[0001511737-16-000045:mdna:24]
[same as prior period, unchanged from 0001511737-16-000037:mdna:22]

[0001511737-16-000045:mdna:25]
[same as prior period, unchanged from 0001511737-16-000037:mdna:23]

[0001511737-16-000045:mdna:26]
| • | Research and development expenses consist primarily of salary and benefit expenses, including stock-based compensation, for employees and costs for contractors engaged in research, design and development activities, as well as costs for prototypes, purchased Intellectual Property (“IP”), facilities and travel. Over time, we expect our research and development costs to increase as we continue making significant investments in developing new products in addition to new versions of our existing products. |

[0001511737-16-000045:mdna:27]
| • | Sales, general and administrative expenses include salary and benefit expenses, including stock-based compensation, for employees and costs for contractors engaged in sales, marketing and general and administrative activities, as well as the costs of legal expenses, trade shows, marketing programs, promotional materials, bad debt expense, professional services, facilities, general liability insurance and travel. As our product portfolio and targeted markets expand, we may need to employ different sales models, such as building a direct sales force. These sales models would likely increase our costs. Over time, we expect our sales, general and administrative expenses to increase in absolute dollars due to continued growth in headcount, expansion of our efforts to register and defend trademarks and patents and to support our business and operations. |

[0001511737-16-000045:mdna:28]
Deferred Revenues

[0001511737-16-000045:mdna:29]
[same as prior period, unchanged from 0001511737-16-000037:mdna:28]

[0001511737-16-000045:mdna:30]
Included in our deferred revenues is a portion related to PCS obligations that we estimate we will fulfill in the future. As of September 30, 2016 and June 30, 2016, we had deferred revenues of $4.7 million and $4.2 million, respectively, related to these obligations.

[0001511737-16-000045:mdna:31]
[same as prior period, unchanged from 0001511737-16-000037:mdna:30]

[0001511737-16-000045:mdna:32]
We prepare our consolidated financial statements in accordance with accounting principles generally accepted in the United States of America (“GAAP”). In many cases, the accounting treatment of a particular transaction is specifically dictated by GAAP and does not require management’s judgment in its application. In other cases, management’s judgment is required in selecting among available alternative accounting standards that provide for different accounting treatment for similar transactions. The preparation of consolidated financial statements also requires us to make estimates and assumptions that affect the amounts we report as assets, liabilities, revenues, costs and expenses and affect the related disclosures. We base our estimates on historical experience and other assumptions that we believe are reasonable under the circumstances. In many instances, we could reasonably use different accounting estimates, and in some instances changes in the accounting estimates are reasonably likely to occur from period to period. Accordingly, our actual results could differ significantly from the estimates made by our management. To the extent that there are differences between our estimates and actual results, our future financial statement presentation, financial condition, results of operations and cash flows will be affected. Our critical accounting policies are discussed in our Annual Report, and there have been no material changes that have not been disclosed in Note 2 herein.

[0001511737-16-000045:mdna:33]
[same as prior period, unchanged from 0001511737-16-000037:mdna:32]

[0001511737-16-000045:mdna:34]
Comparison of Three Months Ended September 30, 2016 and 2015

[0001511737-16-000045:mdna:35]
|  | Three Months Ended September 30, |
|  | 2016 |  | 2015 |
|  | (In thousands, except percentages) |
| Revenues | $ | 204,757 |  |  | 100 | % |  | $ | 151,415 |  |  | 100 | % |
| Cost of revenues(1) | 106,453 |  |  | 52 | % |  | 77,911 |  |  | 51 | % |
| Gross profit | 98,304 |  |  | 48 | % |  | 73,504 |  |  | 49 | % |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development(1) | 14,539 |  |  | 7 | % |  | 13,561 |  |  | 9 | % |
| Sales, general and administrative(1) | 8,863 |  |  | 4 | % |  | 8,142 |  |  | 5 | % |
| Business e-mail compromise (“BEC”) fraud loss/(recovery) | — |  |  | * |  |  | (8,034 | ) |  | (5 | )% |
| Total operating expenses | 23,402 |  |  | 11 | % |  | 13,669 |  |  | 9 | % |
| Income from operations | 74,902 |  |  | 37 | % |  | 59,835 |  |  | 40 | % |
| Interest expense and other, net | (1,099 | ) |  | (1 | )% |  | (116 | ) |  | * |  |
| Income before provision for income taxes | 73,803 |  |  | 36 | % |  | 59,719 |  |  | 39 | % |
| Provision for income taxes (2) | 2,015 |  |  | 1 | % |  | 5,960 |  |  | 4 | % |
| Net income and comprehensive income | $ | 71,788 |  |  | 35 | % |  | $ | 53,759 |  |  | 35 | % |
| * Less than 1% |  |  |  |  |  |  |  |
| (1) Includes stock-based compensation as follows: |  |  |  |  |  |  |  |
| Cost of revenues | $ | 144 |  |  |  |  | $ | 113 |  |  |  |
| Research and development | 560 |  |  |  |  | 624 |  |  |  |
| Sales, general and administrative | 223 |  |  |  |  | 290 |  |  |  |
| Total stock-based compensation | $ | 927 |  |  |  |  | $ | 1,027 |  |  |  |
| (2) Includes the excess tax benefits resulting from the adoption of ASU 2016-09 Stock Compensation | $ | (6,820 | ) |  |  |  | $ | — |  |  |  |

[0001511737-16-000045:mdna:36]
[same as prior period, unchanged from 0001511737-16-000037:mdna:35]

[0001511737-16-000045:mdna:37]
Total revenues increased $53.4 million, or 35%, from $151.4 million in the three months ended September 30, 2015 to $204.8 million in the three months ended September 30, 2016. The drivers of the increase are discussed in further detail below. During the three months ended September 30, 2016, there were no material price changes in the Company's products sold.  During these periods there were changes in product mix, including a higher mix of Enterprise Technology products sold as compared to the three months ended September 30, 2015.

[0001511737-16-000045:mdna:38]
[same as prior period, unchanged from 0001511737-16-000037:mdna:37]

[0001511737-16-000045:mdna:39]
|  | Three Months Ended September 30, |
|  | 2016 |  | 2015 |
|  | (in thousands, except percentages) |
| Service provider technology | $ | 120,632 |  |  | 59 | % |  | $ | 103,399 |  |  | 68 | % |
| Enterprise technology | 84,125 |  |  | 41 | % |  | 48,016 |  |  | 32 | % |
| Total revenues | $ | 204,757 |  |  | 100 | % |  | $ | 151,415 |  |  | 100 | % |

[0001511737-16-000045:mdna:40]
Service Provider Technology revenue increased $17.2 million, or 17%, from $103.4 million in the three months ended September 30, 2015 to $120.6 million in the three months ended September 30, 2016. The increase in Service Provider Technology revenue during the three months ended September 30, 2016 as compared to the same period in the prior year was primarily due to increased Service Provider Technology revenues in North America, Europe, the Middle East and Africa ("EMEA") and Asia Pacific and offset by a slight decrease in revenues in South America.

[0001511737-16-000045:mdna:41]
Enterprise Technology revenue increased $36.1 million, or 75%, from $48.0 million in the three months ended September 30, 2015 to $84.1 million in the three months ended September 30, 2016. The increase in Enterprise Technology revenue during the three months ended September 30, 2016 as compared to the same period in the prior year was primarily due to product expansion and further adoption of our UniFi technology platform across all regions.

[0001511737-16-000045:mdna:42]
[same as prior period, unchanged from 0001511737-16-000037:mdna:42]

[0001511737-16-000045:mdna:43]
We have determined the geographical distribution of our product revenues based on our customers’ ship-to destinations. A majority of our sales are to distributors who either sell to resellers or directly to end customers, who may be located in different countries than the initial ship-to destination.  The following are our revenues by geography for the three months ended September 30, 2016 and 2015 (in thousands, except percentages):

[0001511737-16-000045:mdna:44]
|  | Three Months Ended September 30, |
|  | 2016 |  | 2015 |
| North America(1) | $ | 74,165 |  |  | 36 | % |  | $ | 53,234 |  |  | 35 | % |
| South America | 24,184 |  |  | 12 | % |  | 22,148 |  |  | 15 | % |
| Europe, the Middle East and Africa ("EMEA") | 81,375 |  |  | 40 | % |  | 60,503 |  |  | 40 | % |
| Asia Pacific | 25,033 |  |  | 12 | % |  | 15,530 |  |  | 10 | % |
| Total revenues | $ | 204,757 |  |  | 100 | % |  | $ | 151,415 |  |  | 100 | % |

[0001511737-16-000045:mdna:45]
| (1) | Revenue for the United States was $70.6 million and $50.6 million for the three months ended September 30, 2016 and 2015, respectively. |

[0001511737-16-000045:mdna:46]
[same as prior period, unchanged from 0001511737-16-000037:mdna:46]

[0001511737-16-000045:mdna:47]
Revenues in North America increased $21.0 million, or 39%, from $53.2 million in the three months ended September 30, 2015 to $74.2 million in the three months ended September 30, 2016.  The increase in North American revenues during the three months ended September 30, 2016 as compared to the same periods in the prior year was primarily due to increased demand for both our Service Provider Technology products and Enterprise Technology products.

[0001511737-16-000045:mdna:48]
[same as prior period, unchanged from 0001511737-16-000037:mdna:48]

[0001511737-16-000045:mdna:49]
Revenues in South America increased $2.1 million, or 10%, from $22.1 million in the three months ended September 30, 2015 to $24.2 million in the three months ended September 30, 2016.  The increase in South American revenues during the three months ended September 30, 2016 as compared to the same period in the prior year was primarily due to increased revenues from Enterprise Technology products and offset by the slightly decreased revenues from Service Provider Technology products.

[0001511737-16-000045:mdna:50]
[same as prior period, unchanged from 0001511737-16-000037:mdna:50]

[0001511737-16-000045:mdna:51]
Revenues in EMEA increased $20.9 million, or 35%, from $60.5 million in the three months ended September 30, 2015 to $81.4 million in the three months ended September 30, 2016. The increase in EMEA revenues during the three months ended September 30, 2016 as compared to the same period in the prior year was primarily due to increased demand for both our Service Provider Technology products and Enterprise Technology products.

[0001511737-16-000045:mdna:52]
[same as prior period, unchanged from 0001511737-16-000037:mdna:52]

[0001511737-16-000045:mdna:53]
Revenues in the Asia Pacific region increased $9.5 million, or 61%, from $15.5 million in the three months ended September 30, 2015 to $25.0 million in the three months ended September 30, 2016. The increase in Asia Pacific revenues during the three months ended September 30, 2016, as compared to the same periods in the prior year was primarily due to increased demand for both our Service Provider Technology products and Enterprise Technology products.

[0001511737-16-000045:mdna:54]
[same as prior period, unchanged from 0001511737-16-000037:mdna:54]

[0001511737-16-000045:mdna:55]
Cost of revenues increased $28.6 million, or 37%, from $77.9 million in the three months ended September 30, 2015 to $106.5 million in the three months ended September 30, 2016.  This increase was primarily due to our overall increase in revenues.

[0001511737-16-000045:mdna:56]
Gross profit margin slightly decreased to 48% in the three months ended September 30, 2016 compared to 49% in the three months ended September 30, 2015. The decrease was primarily due to change in mix of products sold during the three months ended September 30, 2016, as compared to the three months ended September 30, 2015.

[0001511737-16-000045:mdna:57]
[same as prior period, unchanged from 0001511737-16-000037:mdna:58]

[0001511737-16-000045:mdna:58]
[same as prior period, unchanged from 0001511737-16-000037:mdna:59]

[0001511737-16-000045:mdna:59]
Research and development (“R&D”) expenses increased $0.9 million, or 7%, from $13.6 million in the three months ended September 30, 2015 to $14.5 million in the three months ended September 30, 2016. As a percentage of revenues, research and development expenses decreased from 9% in the three months ended September 30, 2015 to 7% in the three months ended September 30, 2016.  The increase in research and development expenses in absolute dollars was primarily due to increases in headcount as we broadened our research and development activities to introduce new products and new versions of existing products. As a percentage of revenues, research and development expenses decreased primarily due to our overall increase in revenues.

[0001511737-16-000045:mdna:60]
[same as prior period, unchanged from 0001511737-16-000037:mdna:62]

[0001511737-16-000045:mdna:61]
Sales, general and administrative expenses increased $0.8 million, or 10%, from $8.1 million in the three months ended September 30, 2015 to $8.9 million in the three months ended September 30, 2016.  As a percentage of revenues, sales, general and administrative expenses decreased from 5% in the three months ended September 30, 2015 to 4% in the three months ended September 30, 2016.  Increases in sales, general and administrative expenses in absolute dollars for the three months ended September 30, 2016 as compared to the same period in the prior year are primarily due to an increase in headcount in the business development organization and overall increases in business development initiatives offset, in part, by lower cost for interim management and advisory services to remediate internal control weaknesses. As a percentage of revenues, sales, general and administrative expenses decreased primarily due to our overall increase in revenues.

[0001511737-16-000045:mdna:62]
[same as prior period, unchanged from 0001511737-16-000037:mdna:65]

[0001511737-16-000045:mdna:63]
Our provision for income taxes decreased $4.0 million or 67%, from $6.0 million for the three months ended September 30, 2015 to $2.0 million for the three months ended September 30, 2016. Our effective tax rate decreased to 3% for the three months ended September 30, 2016 as compared to 10% for the three months ended September 30, 2015. The lower effective tax rate in the three months ended September 30, 2016 was primarily due to the recognition of the excess tax benefits for share-based payments of $6.8 million as a reduction of the provision for income taxes rather than additional paid-in capital for the three months ended September 30, 2016 as a result of the adoption of ASU 2016-09. See Note 2 for information on the impact of the adoption of ASU 2016-09.

[0001511737-16-000045:mdna:64]
[same as prior period, unchanged from 0001511737-16-000037:mdna:67]

[0001511737-16-000045:mdna:65]
[same as prior period, unchanged from 0001511737-16-000037:mdna:68]

[0001511737-16-000045:mdna:66]
Since inception, our operations primarily have been funded through cash generated by operations and proceeds from our various debt agreements. Cash and cash equivalents increased from $551.0 million at June 30, 2016 to $573.6 million at September 30, 2016.

[0001511737-16-000045:mdna:67]
[same as prior period, unchanged from 0001511737-16-000037:mdna:70]

[0001511737-16-000045:mdna:68]
The following table sets forth the major components of our consolidated statements of cash flows data for the periods presented:

[0001511737-16-000045:mdna:69]
|  | Three Months Ended September 30, |
|  | 2016 |  | 2015 |
|  | (In thousands) |
| Net cash provided by operating activities | $ | 32,769 |  |  | $ | 47,727 |  |
| Net cash used in investing activities | (1,064 | ) |  | (1,830 | ) |
| Net cash (used in) provided by financing activities | (9,092 | ) |  | (56,218 | ) |
| Net increase (decrease) in cash and cash equivalents | $ | 22,613 |  |  | $ | (10,321 | ) |

[0001511737-16-000045:mdna:70]
[same as prior period, unchanged from 0001511737-16-000037:mdna:73]

[0001511737-16-000045:mdna:71]
Net cash provided by operating activities in the three months ended September 30, 2016 of $32.8 million consisted primarily of net income of $71.8 million partially offset by changes in operating assets and liabilities that resulted in net cash outflows of $41.0 million. These changes consisted primarily of a $9.6 million decrease in accounts payable and accrued liabilities, a $12.9 million increase in accounts receivable due to overall higher revenues for the period, and a $22.4 million increase in inventory due to build warehouse stock levels in order to decrease lead times, a $1.8 million increase in taxes payable due to the timing of federal tax payments. Overall, cash inflows from operating activities were driven by our net income for the period, which included non-cash adjustments primarily due to stock-based compensation (net of excess tax benefit), depreciation and

[0001511737-16-000045:mdna:72]
amortization, decreases to our provision for inventory obsolescence, and decreases to our provision for vendor deposits.  The net of these non-cash adjustments resulted in an increase to our net cash provided by operating activities of $2.0 million.

[0001511737-16-000045:mdna:73]
Net cash provided by operating activities in the three months ended September 30, 2015 of $47.7 million consisted primarily of net income of $53.8 million partially offset by net changes in operating assets and liabilities that resulted in net cash outflows of $9.6 million. These changes consisted primarily of a $5.0 million increase in prepaid expenses and other current assets due to timing of deposit payments with our suppliers, a $2.5 million decrease in accounts receivable due to increased collections during the period, a $17.3 million decrease in accounts payable and accrued liabilities due primarily to an acceleration of payments in advance of a major holiday, a $0.1 million increase in deferred revenue due to additional PCS revenue deferrals during the period, a $2.6 million decrease in prepaid taxes due to the timing of federal tax payments, a $5.2 million decrease in inventory due to increased sales during the period and a $2.3 million increase in taxes payable. Additionally, our net income included non-cash adjustments due to stock-based compensation, depreciation and amortization, increases to our provision for inventory obsolescence, increases to our provision for sales returns, and increases in deferred taxes. The net of these non-cash adjustments resulted in an increase of our net cash provided by operating activities of $3.5 million.

[0001511737-16-000045:mdna:74]
[same as prior period, unchanged from 0001511737-16-000037:mdna:76]

[0001511737-16-000045:mdna:75]
We used $1.1 million of cash in investing activities during the three months ended September 30, 2016.  Our investing activities consist of capital expenditures for machinery and equipment related to product development and prototyping activities in addition to purchases of intangible assets. Capital expenditures for the three months ended September 30, 2016 and 2015 were $1.0 million and $1.8 million, respectively.  Additionally, we had cash outflows related to the purchase of intangible assets of $49 thousand and $7 thousand during the three months ended September 30, 2016 and 2015, respectively, consisting primarily of legal costs associated with trademark applications and acquisition of domain names.

[0001511737-16-000045:mdna:76]
[same as prior period, unchanged from 0001511737-16-000037:mdna:78]

[0001511737-16-000045:mdna:77]
We used $9.1 million of cash in financing activities during the three months ended September 30, 2016.  During the three months ended September 30, 2016 we paid $6.5 million for repurchases of our common stock.  We also made repayments of $2.5 million on our outstanding term loan debt under the Facilities. Additionally, cash inflows from financing activities included $682 thousand of cash proceeds received from the exercise of stock options partially offset by tax withholdings related to net share settlements of restricted stock units totaling $791 thousand.

[0001511737-16-000045:mdna:78]
We had $56.2 million of cash used in financing activities during the three months ended September 30, 2015. We paid $53.8 million for repurchases of our common stock. Additionally, we made a $2.5 million repayment on our outstanding debt under the term loan portion of the Facilities. Cash inflows from financing activities included $0.3 million of cash proceeds received from the exercise of stock options in addition to $0.3 million of excess tax benefit from employee stock-based awards, partially offset by tax withholdings related to net share settlements of restricted stock units of $0.5 million.

[0001511737-16-000045:mdna:79]
[same as prior period, unchanged from 0001511737-16-000037:mdna:81]

[0001511737-16-000045:mdna:80]
We believe our existing cash and cash equivalents, cash provided by operations and the availability of additional funds under the Facilities will be sufficient to meet our working capital and capital expenditure needs for at least the next twelve months. Our future capital requirements may vary materially from those currently planned and will depend on many factors, including our rate of revenue growth, the timing and extent of spending to support development efforts, the timing of new product introductions, market acceptance of our products and overall economic conditions. As of September 30, 2016, we held $530.2 million of our $573.6 million of cash and cash equivalents in accounts of our subsidiaries outside of the United States and we could incur material tax liabilities if we decide to repatriate those amounts.

[0001511737-16-000045:mdna:81]
[same as prior period, unchanged from 0001511737-16-000037:mdna:83]

[0001511737-16-000045:mdna:82]
Our products are generally accompanied by a twelve-month warranty from date of purchase, which covers both parts and labor. Generally the distributor is responsible for the freight costs associated with warranty returns, and we absorb the freight costs of replacing items under warranty. In accordance with the Financial Accounting Standards Board’s (“FASB’s”), Accounting Standards Codification (“ASC”), 450-20, Loss Contingencies, we record an accrual when we believe it is reasonably estimable and probable based upon historical experience. We record a provision for estimated future warranty work in cost of goods sold upon recognition of revenues, and we review the resulting accrual regularly and periodically adjust it to reflect changes in warranty estimates.

[0001511737-16-000045:mdna:83]
We have, and may in the future enter into standard indemnification agreements with many of our distributors and OEMs, as well as certain other business partners in the ordinary course of business. These agreements do, and may in the future include

[0001511737-16-000045:mdna:84]
provisions for indemnifying the distributor, OEM or other business partner against any claim brought by a third-party to the extent any such claim alleges that a Ubiquiti product infringes a patent, copyright or trademark or violates any other proprietary rights of that third-party. The maximum amount of potential future indemnification is unlimited. The maximum potential amount of future payments we could be required to make under these indemnification agreements is not estimable.

[0001511737-16-000045:mdna:85]
We have agreed to indemnify our directors, officers and certain other employees for certain events or occurrences, subject to certain limits, while such persons are or were serving at our request in such capacity. We may terminate the indemnification agreements with these persons upon the termination of their services with us, but termination will not affect claims for indemnification related to events occurring prior to the effective date of termination. The maximum amount of potential future indemnification is unlimited. We have a Directors and Officers insurance policy that limits our potential exposure. We believe the fair value of these indemnification agreements is minimal.  We have not recorded any liabilities for these agreements as of September 30, 2016.

[0001511737-16-000045:mdna:86]
Based upon our historical experience and information known as of the date of this report, we do not believe it is likely that we have a material liability for the above indemnities at September 30, 2016.

[0001511737-16-000045:mdna:87]
[same as prior period, unchanged from 0001511737-16-000037:mdna:89]

[0001511737-16-000045:mdna:88]
The following table summarizes our contractual obligations as of September 30, 2016 for the remainder of fiscal 2017 and future fiscal years (in thousands):

[0001511737-16-000045:mdna:89]
|  | 2017 (remainder) |  | 2018 |  | 2019 |  | 2020 |  | 2021 |  | Thereafter |  | Total |
| Operating leases | $ | 5,340 |  |  | $ | 5,153 |  |  | $ | 2,576 |  |  | $ | 1,744 |  |  | $ | 1,085 |  |  | $ | 375 |  |  | $ | 16,273 |  |
| Debt payment obligations | 8,750 |  |  | 15,000 |  |  | 15,000 |  |  | 162,250 |  |  | — |  |  | — |  |  | 201,000 |  |
| Interest and other payments on debt payment obligations | 3,754 |  |  | 4,712 |  |  | 4,361 |  |  | 2,781 |  |  | — |  |  | — |  |  | 15,608 |  |
| Purchase obligations | 25,796 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 25,796 |  |
| Other obligations | 10,025 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 10,025 |  |
| Total | $ | 53,665 |  |  | $ | 24,865 |  |  | $ | 21,937 |  |  | $ | 166,775 |  |  | $ | 1,085 |  |  | $ | 375 |  |  | $ | 268,702 |  |

[0001511737-16-000045:mdna:90]
[same as prior period, unchanged from 0001511737-16-000037:mdna:92]

[0001511737-16-000045:mdna:91]
We lease our headquarters in San Jose, California in addition to other locations worldwide under non-cancelable operating leases that expire at various dates through fiscal 2022.

[0001511737-16-000045:mdna:92]
[same as prior period, unchanged from 0001511737-16-000037:mdna:94]

[0001511737-16-000045:mdna:93]
On March 3, 2015, we entered into the Amended Credit Agreement, that provides for a $200.0 million senior secured revolving credit facility and a $100.0 million senior secured term loan facility, with an option to request increases in the amounts of such credit facilities by up to an additional $50.0 million in the aggregate (any such increase to be in each lender’s sole discretion).  Please see Note 7 of the Notes to the Consolidated Financial Statements for more information. Although interest rates on our debt obligations will likely vary over time, we have assumed our interest rates as of September 30, 2016 as the interest rates for all fiscal years presented.  Furthermore, the interest payment intervals on our revolving debt are determined at the Company's election pursuant to the Amended Credit Agreement, and may change over time.  For purposes of the table above, we have assumed two to three-month payment intervals on our revolving debt, consistent with our elections to date.  Also included are estimated bank fees to be paid for unused portions of our revolving credit facility.

[0001511737-16-000045:mdna:94]
[same as prior period, unchanged from 0001511737-16-000037:mdna:96]

[0001511737-16-000045:mdna:95]
We subcontract with third parties to manufacture our products. During the normal course of business, our contract manufacturers procure components and manufacture product based upon orders placed by us.  Component and product inventory held by our manufacturers or our third-party logistics providers is not recorded on our balance sheet until legal title passes to the Company.  If we cancel all or part of the orders, we may still be liable to the contract manufacturers for the cost of the components they purchased and for manufacturing and other costs related to these components.  We periodically review the potential liability, and no significant liabilities for cancellations have been recorded for the three months ended September 30, 2016. Our consolidated financial position and results of operations could be negatively impacted if we were required to compensate the contract manufacturers for any unrecorded liabilities incurred.  The Company had inventory purchase obligations of $25.8 million as of September 30, 2016.

[0001511737-16-000045:mdna:96]
[same as prior period, unchanged from 0001511737-16-000037:mdna:98]

[0001511737-16-000045:mdna:97]
We had other obligations of $10.0 million as of September 30, 2016, which consisted primarily of commitments related to research and development projects.

[0001511737-16-000045:mdna:98]
[same as prior period, unchanged from 0001511737-16-000037:mdna:100]

[0001511737-16-000045:mdna:99]
As of September 30, 2016, we had $24.0 million of unrecognized tax benefits, substantially all of which would, if recognized, affect our tax expense. We have elected to include interest and penalties related to uncertain tax positions as a component of tax expense. We do not expect any significant increases or decreases to our unrecognized tax benefits in the next twelve months.

[0001511737-16-000045:mdna:100]
[same as prior period, unchanged from 0001511737-16-000037:mdna:102]

[0001511737-16-000045:mdna:101]
For a discussion of recent accounting pronouncements, refer to Note 2 to the Consolidated Financial Statements.

[0001511737-16-000045:mdna:102]
[same as prior period, unchanged from 0001511737-16-000037:mdna:113]

[0001511737-16-000045:mdna:103]
When used in this Report, the words “anticipates,” “believes,” “could,” “seeks,” “estimates,” “expects,” “intends,” “may,” “plans” “potential,” “predicts,” “projects,” “should,” “will,” “would” or similar expressions and negatives of those terms are intended to identify forward-looking statements. These are statements that relate to future periods and include statements about our future results, sources of revenue, our continued growth, our gross margins, market trends, our product development, technological developments, the features, benefits and performance of our current and future products, the ability of our products to address a variety of markets, the anticipated growth of demand for connectivity worldwide, our growth strategies, future price reductions, our competitive status, our dependence on our senior management and our ability to attract and retain key personnel, dependency on and concentration of our distributors, our employee relations, current and potential litigation, the effects of government regulations, our compliance with laws and regulations, our expected future operating costs and expenses and expenditure levels for research and development, selling, general and administrative expenses, fluctuations in operating results, fluctuations in our stock price, our payment of dividends, our future liquidity and cash needs, our credit facility, future acquisitions of and investments in complimentary businesses and the expected impact of various accounting policies and rules adopted by the Financial Accounting Standards Board. Forward-looking statements are subject to risks and uncertainties that could cause actual results to differ materially from those projected. These risks and uncertainties include, but are not limited to, factors affecting our quarterly results, our ability to manage our growth, our ability to sustain or increase profitability, demand for our products, our ability to compete, our ability to rapidly develop new technology and introduce new products, our ability to safeguard our intellectual property, trends in the networking industry and fluctuations in general economic conditions, and the risks set forth throughout this Report, including under Part II “Other Information”, Item 1-Legal Proceedings and Item 1A- Risk Factors. These forward-looking statements speak only as of the date hereof. Except as required by law, we expressly disclaim any obligation or undertaking to release publicly any updates or revisions to any forward-looking statements contained herein to reflect any change in our expectations with regard thereto or any change in events, conditions or circumstances on which any such statement is based.
