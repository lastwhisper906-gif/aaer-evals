# UI notes — 0001511737-16-000045


## ubnt:ScheduleOfRevenueAndAccountsReceivableByMajorCustomersByReportingSegmentsTableTableTextBlock

[0001511737-16-000045:notes:1]
[same as prior period, unchanged from 0001511737-16-000037:notes:3]

[0001511737-16-000045:notes:2]
|  | Percentage of Revenues |  | Percentage of Accounts Receivable |
|  | Three Months Ended September 30, |  | September 30, |  | June 30, |
|  | 2016 |  | 2015 |  | 2016 |  | 2016 |
| Customer A | * |  | * |  | * |  | 11% |
| Customer B | * |  | * |  | * |  | 13% |
| Customer C | 10% |  | * |  | 16% |  | 18% |

[0001511737-16-000045:notes:3]
[same as prior period, unchanged from 0001511737-16-000037:notes:5]


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001511737-16-000045:notes:4]
Basis of Presentation— The accompanying consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP”) related to interim financial statements based on applicable Securities and Exchange Commission (“SEC”) rules and regulations. Accordingly, they do not include all the information and footnotes required by U.S. GAAP for complete financial statements. These consolidated financial statements reflect all adjustments, which are, in the opinion of the Company, of a normal and recurring nature and those necessary to state fairly the statements of financial position, results of operations and cash flows for the dates and periods presented. The June 30, 2016 balance sheet was derived from the audited financial statements as of that date. All significant intercompany transactions and balances have been eliminated.  The Company has reclassified certain amounts reported in the previous period to conform to the current period presentation.

[0001511737-16-000045:notes:5]
These consolidated financial statements should be read in conjunction with the Company’s audited consolidated financial statements for the fiscal year ended June 30, 2016, included in its Annual Report on Form 10-K, as filed with the SEC on August 22, 2016 (the “Annual Report”). The results of operations for the three months ended September 30, 2016 are not necessarily indicative of the results to be expected for any future periods.


## us-gaap:BusinessDescriptionAndBasisOfPresentationTextBlock

[0001511737-16-000045:notes:6]
[same as prior period, unchanged from 0001511737-16-000037:notes:8]

[0001511737-16-000045:notes:7]
[same as prior period, unchanged from 0001511737-16-000037:notes:9]

[0001511737-16-000045:notes:8]
[same as prior period, unchanged from 0001511737-16-000037:notes:10]

[0001511737-16-000045:notes:9]
The Company operates on a fiscal year ending June 30. In this Quarterly Report, the fiscal year ending June 30, 2017 is referred to as “fiscal 2017” and the fiscal year ended June 30, 2016 is referred to as “fiscal 2016.”


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001511737-16-000045:notes:10]
COMMITMENTS AND CONTINGENCIES

[0001511737-16-000045:notes:11]
Operating Leases

[0001511737-16-000045:notes:12]
Certain facilities and equipment are leased under non-cancelable operating leases. The Company generally pays taxes, insurance and maintenance costs on leased facilities and equipment. The Company leases its headquarters in San Jose, California and other locations under non-cancelable operating leases that expire at various dates through fiscal 2022.

[0001511737-16-000045:notes:13]
At September 30, 2016, future minimum annual payments under operating leases for the remainder of fiscal 2017 and future fiscal years are as follows (in thousands):

[0001511737-16-000045:notes:14]
|  | 2017 (remainder) |  | 2018 |  | 2019 |  | 2020 |  | 2021 |  | Thereafter |  | Total |
| Operating leases | $ | 5,340 |  |  | $ | 5,153 |  |  | $ | 2,576 |  |  | $ | 1,744 |  |  | $ | 1,085 |  |  | $ | 375 |  |  | $ | 16,273 |  |

[0001511737-16-000045:notes:15]
Purchase Obligations

[0001511737-16-000045:notes:16]
The Company primarily subcontracts with other companies to manufacture its products. During the normal course of business, the Company’s contract manufacturers procure components based upon orders placed by the Company. If the Company cancels all or part of the orders, it may still be liable to the contract manufacturers for the cost of the components purchased by them to manufacture the Company’s products. The Company periodically reviews the potential liability under its orders, and no significant accruals have been recorded as of September 30, 2016.  The Company had inventory purchase obligations of $25.8 million as of September 30, 2016.

[0001511737-16-000045:notes:17]
Other Obligations

[0001511737-16-000045:notes:18]
The Company had other obligations of $10.0 million as of September 30, 2016, which consisted primarily of commitments related to research and development projects.

[0001511737-16-000045:notes:19]
Indemnification Obligations

[0001511737-16-000045:notes:20]
The Company enters into standard indemnification agreements with many of its business partners in the ordinary course of business. These agreements include provisions for indemnifying the business partner against any claim brought by a third-party to the extent any such claim alleges that a Company product infringes a patent, copyright or trademark, or violates any other proprietary rights of that third-party. The maximum potential amount of future payments the Company could be required to make under these indemnification agreements is not estimable and the Company has not incurred any material costs to defend lawsuits or settle claims related to these indemnification agreements to date.

[0001511737-16-000045:notes:21]
Legal Matters

[0001511737-16-000045:notes:22]
The Company may be involved, from time to time, in a variety of claims, lawsuits, investigations, and proceedings relating to contractual disputes, intellectual property rights, employment matters, regulatory compliance matters and other litigation matters relating to various claims that arise in the normal course of business. The Company determines whether an estimated loss from a contingency should be accrued by assessing whether a loss is deemed probable and can be reasonably estimated. The Company assesses its potential liability by analyzing specific litigation and regulatory matters using available information. The Company develops its views on estimated losses in consultation with inside and outside counsel, which involves a subjective analysis of potential results and outcomes, assuming various combinations of appropriate litigation and settlement strategies. Taking all of the above factors into account, the Company records an amount where it is probable that the Company will incur a loss and where that loss can be reasonably estimated. However, the Company’s estimates may be incorrect and the Company could ultimately incur more or less than the amounts initially recorded.  The Company may also incur significant legal fees, which are expensed as incurred, in defending against these claims. The Company is not currently aware of any pending or threatened litigation that would have a material adverse effect on the Company's financial statements.

[0001511737-16-000045:notes:23]
Shareholder Class Action Lawsuits

[0001511737-16-000045:notes:24]
Beginning on September 7, 2012, two class action lawsuits were filed in the United States District Court for the Northern District of California against Ubiquiti Networks, Inc., certain of its officers and directors, and the underwriters of its initial public offering, alleging claims under U.S. securities laws. On January 30, 2013, the plaintiffs filed an amended consolidated complaint. On March 26, 2014, the court issued an order granting a motion to dismiss the complaint with leave to amend. Following the plaintiffs’ decision not to file an amended complaint, on April 16, 2014, the court ordered the dismissal of the lawsuit with prejudice, and entered judgment in favor of the Company and the other defendants, and against the plaintiffs. On May 15, 2014, the plaintiffs filed a notice of appeal from the judgment of the court. The Ninth Circuit heard oral arguments on August 10, 2016.  On October 24, 2016, the Ninth Circuit issued an unpublished opinion, reaffirming the district court’s dismissal of the alleged violation of Sections 10(b) and 20(a) of the Securities Exchange Act of 1934 and reversing the district court’s dismissal of the alleged violations of Sections 11 and 15 of the Securities Act of 1933. The Company plans to file a petition for rehearing with the Ninth Circuit and to vigorously defend itself against these claims. There can be no assurance that the Company will prevail. The Company cannot currently estimate the possible loss, if any, that it may experience in connection with this litigation.


## us-gaap:DebtDisclosureTextBlock

[0001511737-16-000045:notes:25]
DEBT

[0001511737-16-000045:notes:26]
On March 3, 2015, Ubiquiti Networks, Inc. and Ubiquiti International Holding Company Limited (the “Cayman Borrower”) amended and restated its original credit agreement (the “Amended Credit Agreement”) with Wells Fargo Bank, National Association (“Wells Fargo”), the other financial institutions named as lenders therein, and Wells Fargo as administrative agent for the lenders.  The Amended Credit Agreement provides for a $200.0 million senior secured revolving credit facility and a $100.0 million senior secured term loan facility (collectively, the “Facilities”), with an option to request increases in the amounts of such credit facilities by up to an additional $50.0 million in the aggregate (any such increase to be in each lender’s sole discretion), and matures on March 3, 2020.  The $100.0 million term loan facility of the Amended Credit Agreement was fully drawn at closing, and $72.3 million was used to repay the outstanding balance under its original credit agreement.

[0001511737-16-000045:notes:27]
Our Debt consisted of the following (in thousands):

[0001511737-16-000045:notes:28]
|  | September 30, 2016 |  | June 30, 2016 |
| Term Loan - short term | $ | 12,500 |  |  | $ | 11,250 |  |
| Debt Issuance costs, net (1) | (257 | ) |  | (257 | ) |
| Total Debt - short term | 12,243 |  |  | 10,993 |  |
| Term Loan - long term | 72,500 |  |  | 76,250 |  |
| Revolver - long term | 116,000 |  |  | 116,000 |  |
| Debt issuance costs, net (1) | (621 | ) |  | (686 | ) |
| Total Debt - long term | $ | 187,879 |  |  | $ | 191,564 |  |

[0001511737-16-000045:notes:29]
(1) On July 1 2016, the Company retrospectively adopted ASU 2015-03, which requires unamortized debt issuance costs to be included as a direct deduction from the related debt liability on the balance sheet. Under previous guidance, all unamortized debt issuance costs were reported as assets on the balance sheet. See Note 2 for information on the impact of the retrospective adoption of ASU 2015-03.

[0001511737-16-000045:notes:30]
As of September 30, 2016, the interest rate on the term loan was 2.34%.  The table below shows the respective interest rates as of September 30, 2016 in addition to interest rate reset dates and rates as available for each revolver draw.

[0001511737-16-000045:notes:31]
|  |  | Interest Rate as of |  |  |  |  |
| Debt Payment Obligations |  | September 30, 2016 |  | Rate Reset Date |  | Reset Rate |
| $15 Million Revolver |  | 2.42% |  | 01/09/2017 |  | * |
| $18 Million Revolver |  | 2.48% |  | 01/18/2017 |  | * |
| $16 Million Revolver |  | 2.70% |  | 02/13/2017 |  | * |
| $19 Million Revolver |  | 2.41% |  | 01/03/2017 |  | * |
| $48 Million Revolver |  | 2.48% |  | 11/30/2016 |  | * |

[0001511737-16-000045:notes:32]
* - Reset rate not available as of filing date.

[0001511737-16-000045:notes:33]
The revolving credit facility includes a sub-limit of $10.0 million for letters of credit and a sub-limit of $25.0 million for swingline loans. The Facilities replaced the Company’s $150.0 million senior secured revolving credit facility under its original credit agreement. The Facilities are available for working capital and general corporate purposes that comply with the terms of the Amended Credit Agreement. Under the Amended Credit Agreement, revolving loans and swingline loans may be borrowed, repaid and reborrowed until March 3, 2020, at which time all amounts borrowed must be repaid. The term loan is payable in quarterly installments of 2.50% of the original principal amount of the term loan until March 31, 2017, thereafter increasing to 3.75% of the original principal amount of the term loan, in each case plus accrued and unpaid interest. Revolving, swingline and term loans may be prepaid at any time without penalty.

[0001511737-16-000045:notes:34]
Revolving and term loans bear interest, at the Company’s option, at either (i) a floating rate per annum equal to the base rate plus a margin of between 0.50% and 1.25%, depending on the Company’s leverage ratio as of the most recently ended fiscal quarter or (ii) a floating per annum rate equal to the applicable LIBOR rate for a specified period, plus a margin of between 1.50% and 2.25%, depending on the Company’s leverage ratio as of the most recently ended fiscal quarter. Swingline loans bear interest at a floating rate per annum equal to the base rate plus a margin of between 0.50% and 1.25%, depending on the Company’s leverage ratio as of the most recently ended fiscal quarter.

[0001511737-16-000045:notes:35]
The Amended Credit Agreement requires the Company to maintain during the term of the Facilities (i) a maximum leverage ratio of 2.50 to 1.00 and (ii) minimum liquidity of $225.0 million, increasing to $250.0 million in the event of an incremental increase in the size of the Facilities, which can be satisfied with unrestricted cash and cash equivalents and up to $50.0 million of availability under the revolving credit facility. In addition, the Amended Credit Agreement contains customary affirmative and negative covenants and includes customary events of default. The occurrence of an event of default could result in the acceleration of the obligations under the Amended Credit Agreement.

[0001511737-16-000045:notes:36]
The obligations of Ubiquiti Networks, Inc. and certain domestic subsidiaries, if any, under the Amended Credit Agreement are required to be guaranteed by such domestic subsidiaries (the “Domestic Guarantors”) and are collateralized by substantially all assets (excluding intellectual property) of Ubiquiti Networks, Inc. and the Domestic Guarantors. The obligations of the Cayman Borrower and certain foreign subsidiaries under the Amended Credit Agreement are required to be guaranteed by certain domestic and material foreign subsidiaries (the “Guarantors”) and are collateralized by substantially all assets (excluding intellectual property) of the Cayman Borrower and the Guarantors.

[0001511737-16-000045:notes:37]
During the three months ended September 30, 2016, the Company made a payment of $3.0 million against the term loan facility under the Amended Credit Agreement, of which $2.5 million was a repayment of principal and $0.5 million was payment of interest. During the three months ended September 30, 2016, the Company made a payment of $0.4 million interest against the revolver loan facility under the Amended Credit Agreement. As of September 30, 2016, excluding debt issuance costs, the Company classified $12.5 million and $188.5 million as short-term and as long-term debt, respectively, on its consolidated balance sheet.

[0001511737-16-000045:notes:38]
On September 2, 2015, the Company accessed a letter of credit under its revolving credit facility in the amount of $237 thousand for the benefit of the landlord pursuant to a new lease of office space. The landlord can draw against the letter of credit in the event of default by the Company. The letter of credit expires on September 2, 2017, subject to automatic renewal for additional one-year periods.

[0001511737-16-000045:notes:39]
The following table summarizes our estimated debt and interest payment obligations as of September 30, 2016, for the remainder of fiscal 2017 and future fiscal years (in thousands):

[0001511737-16-000045:notes:40]
|  | 2017 (remainder) |  | 2018 |  | 2019 |  | 2020 |  | Thereafter |  | Total |
| Debt payment obligations | $ | 8,750 |  |  | $ | 15,000 |  |  | $ | 15,000 |  |  | $ | 162,250 |  |  | $ | — |  |  | $ | 201,000 |  |
| Interest and other payments on debt payment obligations (1) | 3,754 |  |  | 4,712 |  |  | 4,361 |  |  | 2,781 |  |  | — |  |  | 15,608 |  |
| Total | $ | 12,504 |  |  | $ | 19,712 |  |  | $ | 19,361 |  |  | $ | 165,031 |  |  | $ | — |  |  | $ | 216,608 |  |

[0001511737-16-000045:notes:41]
(1) - Interest payments are calculated based on the applicable rates and payment dates as of September 30, 2016. Furthermore, two to three-month payment intervals on the revolving debt have been assumed, consistent with the Company's elections to date.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001511737-16-000045:notes:42]
[same as prior period, unchanged from 0001511737-16-000037:notes:43]

[0001511737-16-000045:notes:43]
[same as prior period, unchanged from 0001511737-16-000037:notes:44]

[0001511737-16-000045:notes:44]
The Company’s 2010 Equity Incentive Plan and 2005 Equity Incentive Plan are described in its Annual Report. As of September 30, 2016, the Company had 10,022,225 authorized shares available for future issuance under all of its stock incentive plans.

[0001511737-16-000045:notes:45]
[same as prior period, unchanged from 0001511737-16-000037:notes:46]

[0001511737-16-000045:notes:46]
The following table shows total stock-based compensation expense included in the Consolidated Statements of Operations for the three months ended September 30, 2016 and 2015 (in thousands):

[0001511737-16-000045:notes:47]
|  | Three Months Ended September 30, |  |
|  | 2016 |  | 2015 |  |
| Cost of revenues | $ | 144 |  |  | $ | 113 |  |  |
| Research and development | 560 |  |  | 624 |  |  |
| Sales, general and administrative | 223 |  |  | 290 |  |  |
|  | $ | 927 |  |  | $ | 1,027 |  |  |

[0001511737-16-000045:notes:48]
[same as prior period, unchanged from 0001511737-16-000037:notes:49]

[0001511737-16-000045:notes:49]
The following is a summary of option activity for the Company’s stock incentive plans for the three months ended September 30, 2016:

[0001511737-16-000045:notes:50]
|  | Common Stock Options Outstanding |
|  | Numberof Shares |  | WeightedAverageExercisePrice |  | WeightedAverageRemainingContractualLife (Years) |  | AggregateIntrinsicValue(In thousands) |
| Balance, June 30, 2016 | 2,125,307 |  |  | $ | 2.03 |  |  | 2.65 |  | $ | 77,850 |  |
| Exercised | (412,202 | ) |  | $ | 1.65 |  |  |  |  |  |
| Forfeitures and cancellations | (417 | ) |  | $ | 12.14 |  |  |  |  |  |
| Balance, September 30, 2016 | 1,712,688 |  |  | $ | 2.12 |  |  | 2.37 |  | $ | 88,002 |  |
| Vested and expected to vest as of September 30, 2016 | 1,712,569 |  |  | $ | 2.12 |  |  | 2.37 |  | $ | 87,997 |  |
| Vested and exercisable as of September 30, 2016 | 1,696,901 |  |  | $ | 2.03 |  |  | 2.34 |  | $ | 87,342 |  |

[0001511737-16-000045:notes:51]
During the three months ended September 30, 2016 and 2015, the aggregate intrinsic value of options exercised under the Company’s stock incentive plans was $20.7 million and $1.5 million, respectively, as determined as of the date of option exercise.

[0001511737-16-000045:notes:52]
As of September 30, 2016, the Company had unrecognized compensation costs of $0.1 million related to stock options which the Company expects to recognize over a weighted-average period of 0.3 years. Future option grants will increase the amount of compensation expense to be recorded in these periods.

[0001511737-16-000045:notes:53]
The Company estimates the fair value of employee stock options using the Black-Scholes option pricing model. The fair value of employee stock options is amortized on a straight-line basis over the requisite service period of the awards.  The Company did not grant any employee stock options during the three months ended September 30, 2016 and 2015.

[0001511737-16-000045:notes:54]
[same as prior period, unchanged from 0001511737-16-000037:notes:55]

[0001511737-16-000045:notes:55]
[same as prior period, unchanged from 0001511737-16-000037:notes:56]

[0001511737-16-000045:notes:56]
|  | Number of Shares |  | Weighted Average Grant Date Fair Value Per Share |
| Non-vested RSUs, June 30, 2016 | 271,971 |  |  | $ | 28.72 |  |
| RSUs granted | 24,330 |  |  | $ | 45.83 |  |
| RSUs vested | (60,728 | ) |  | $ | 20.36 |  |
| RSUs canceled | (10,928 | ) |  | $ | 32.60 |  |
| Non-vested RSUs, September 30,2016 | 224,645 |  |  | $ | 32.64 |  |

[0001511737-16-000045:notes:57]
The intrinsic value of RSUs vested in the three months ended September 30, 2016 and 2015 was $2.9 million and $1.9 million, respectively.

[0001511737-16-000045:notes:58]
As of September 30, 2016, there were unrecognized compensation costs related to RSUs of $8.0 million which the Company expects to recognize over a weighted average period of 2.9 years.


## us-gaap:EarningsPerShareTextBlock

[0001511737-16-000045:notes:59]
[same as prior period, unchanged from 0001511737-16-000037:notes:60]

[0001511737-16-000045:notes:60]
[same as prior period, unchanged from 0001511737-16-000037:notes:61]

[0001511737-16-000045:notes:61]
|  | Three Months Ended September 30, |
|  | 2016 |  | 2015 |
| Numerator: |  |
| Net income and comprehensive income | $ | 71,788 |  |  | $ | 53,759 |  |
| Denominator: |  |
| Weighted-average shares used in computing basic net income per share | 81,812 |  |  | 87,062 |  |
| Add—dilutive potential common shares: |  |  |  |
| Stock options(1) | 1,920 |  |  | 1,302 |  |
| Restricted stock units(1) | 122 |  |  | 101 |  |
| Weighted-average shares used in computing diluted net income per share | 83,854 |  |  | 88,465 |  |
| Net income per share of common stock: |  |
| Basic | $ | 0.88 |  |  | $ | 0.62 |  |
| Diluted | $ | 0.86 |  |  | $ | 0.61 |  |

[0001511737-16-000045:notes:62]
(1) Effective July 1, 2016, the Company early adopted ASU 2016-09 regarding the Improvements to Employee Share-Based Payment Accounting, the adoption increased the number of diluted stock options and restricted stock units by 774 thousand shares.

[0001511737-16-000045:notes:63]
[same as prior period, unchanged from 0001511737-16-000037:notes:63]

[0001511737-16-000045:notes:64]
|  | Three Months Ended September 30, |
|  | 2016 |  | 2015 |
| Restricted stock units | 4 |  |  | 39 |  |
|  | 4 |  |  | 39 |  |


## us-gaap:FairValueAssetsAndLiabilitiesMeasuredOnRecurringAndNonrecurringBasisTableTextBlock

[0001511737-16-000045:notes:65]
As of September 30, 2016 and June 30, 2016, the fair value hierarchy of the Company’s debt carried at historical cost was as follows (in thousands):

[0001511737-16-000045:notes:66]
|  | September 30, 2016 |  | June 30, 2016 |
|  | FairValue |  | Level 1 |  | Level 2 |  | Level 3 |  | FairValue |  | Level 1 |  | Level 2 |  | Level 3 |
| Debt | $ | 201,000 |  |  | $ | — |  |  | $ | 201,000 |  |  | $ | — |  |  | $ | 203,500 |  |  | $ | — |  |  | $ | 203,500 |  |  | $ | — |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001511737-16-000045:notes:67]
[same as prior period, unchanged from 0001511737-16-000037:notes:67]

[0001511737-16-000045:notes:68]
[same as prior period, unchanged from 0001511737-16-000037:notes:68]

[0001511737-16-000045:notes:69]
[same as prior period, unchanged from 0001511737-16-000037:notes:69]

[0001511737-16-000045:notes:70]
[same as prior period, unchanged from 0001511737-16-000037:notes:70]

[0001511737-16-000045:notes:71]
[same as prior period, unchanged from 0001511737-16-000037:notes:71]

[0001511737-16-000045:notes:72]
For certain of the Company’s financial instruments, including cash, accounts receivable, accounts payable and other current liabilities, the carrying amounts approximate fair value due to their short maturities.  Additionally, as of September 30, 2016, we held $530.2 million of our $573.6 million of cash and cash equivalents in accounts of our subsidiaries outside of the United States and we could incur material tax liabilities if we were to repatriate those amounts.

[0001511737-16-000045:notes:73]
As of September 30, 2016 and June 30, 2016 the Company had debt associated with its Amended Credit Agreement with Wells Fargo Bank (See Note 7). The fair value of the Company’s debt was estimated based on the current rates offered to the Company for debt with similar terms and remaining maturities and was a Level 2 measurement.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001511737-16-000045:notes:74]
[same as prior period, unchanged from 0001511737-16-000037:notes:74]

[0001511737-16-000045:notes:75]
The Company recorded a tax provision of $2.0 million for the three months ended September 30, 2016.  The Company’s estimated fiscal year 2017 effective tax rate differs from the U.S. statutory rate primarily due to profits earned in jurisdictions where the tax rate is lower than the U.S. tax rate and share-based compensation excess tax benefit.

[0001511737-16-000045:notes:76]
Effective July 1, 2016, the Company early adopted ASU 2016-09 regarding the Improvements to Employee Share-Based Payment Accounting. In accordance with the new guidance, the Company recognized excess tax benefits for share-based payments of $6.8 million as a discrete item within the provision for income taxes rather than additional paid-in capital for the three months ended September 30, 2016. See Note 2 for information on the impact of the adoption of ASU 2016-09.

[0001511737-16-000045:notes:77]
As of September 30, 2016, the Company had approximately $24.0 million of unrecognized tax benefits, substantially all of which would, if recognized, affect its tax expense. The Company has elected to include interest and penalties related to uncertain tax positions as a component of tax expense. At September 30, 2016, an immaterial amount of interest and penalties are included in long-term income tax payable. The Company recorded a net increase of its unrecognized tax benefits of $1.2 million for the three months ended September 30, 2016. The Company does not expect any significant increases or decreases to its unrecognized tax benefits in the next twelve months.

[0001511737-16-000045:notes:78]
[same as prior period, unchanged from 0001511737-16-000037:notes:77]

[0001511737-16-000045:notes:79]
On July 27, 2015, in Altera Corp. v. Commissioner, the U.S. Tax Court issued an opinion related to the treatment of stock-based compensation expense in an intercompany cost-sharing arrangement.  On February 19, 2016, the U.S. Department of the Treasury filed a notice of appeal and has not withdrawn the requirement to include stock-based compensation from its regulations. We have reviewed this case and its potential impact on Ubiquiti and concluded that no adjustment to the consolidated financial statements is appropriate at this time. We will continue to monitor ongoing developments and potential impacts to our consolidated financial statements.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001511737-16-000045:notes:80]
New Accounting Updates Recently Adopted

[0001511737-16-000045:notes:81]
Effective July 1, 2016, the Company adopted Accounting Standards Update (“ASU”) 2015-03 regarding simplifying the presentation of debt issuance costs. The guidance requires that debt issuance costs related to a recognized debt liability be presented in the balance sheet as a direct deduction from the carrying amount of that debt liability, consistent with debt discounts. Previously the Company reported these costs as assets on its balance sheet. The guidance is applied on a retrospective basis whereby prior-period financial statements must be adjusted to reflect the adoption of the new guidance.

[0001511737-16-000045:notes:82]
The Company has reclassified $0.3 million from "prepaid expenses and other current assets" to "Debt - short-term", and $0.7 million from "Other long-term assets" to "Debt - long-term" on the June 30, 2016 consolidated balance sheet.

[0001511737-16-000045:notes:83]
Effective July 1, 2016, the Company adopted ASU 2015-11 regarding simplifying the measurement of inventory. The guidance requires an entity to measure inventory at the lower of cost and net realizable value. Net realizable value is the estimated selling prices in the ordinary course of business, less reasonably predictable costs of completion, disposal, and transportation. The Company adopted this update prospectively, and it did not have a material impact on the Company's Consolidated Financial Statements.

[0001511737-16-000045:notes:84]
Effective July 1, 2016, the Company early adopted ASU 2016-09 regarding the Improvements to Employee Share-Based Payment Accounting. The Company applied the guidance relating to accounting for excess tax benefits and the presentation of excess tax benefits for share-based payments in the consolidated statement of cash flows on a prospective basis; according prior period amounts have not been adjusted. The Company recognized the excess tax benefits of $6.8 million within the provision for income taxes rather than additional paid-in capital during the three months ended September 30, 2016. The Company classified the excess tax benefits for share-based payments within cash flows from operating activities for the three months ended September 30, 2016 rather than within cash flows from financing activities. In regards to the forfeiture policy election, we will continue to estimate the number of awards expected to be forfeited, rather than electing to account for forfeitures as they occur. No other terms of the adopted guidance resulted in an impact on the Company's Consolidated Financial Statements.

[0001511737-16-000045:notes:85]
Recent Accounting Standards or Updates Not Yet Effective

[0001511737-16-000045:notes:86]
In June 2014, the FASB issued a new accounting standard update on revenue from contracts with customers.  The core principle of the guidance is that an entity should recognize revenue to depict the transfer of promised goods or services to customers in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services.  To achieve that core principle, an entity should apply the following steps:

[0001511737-16-000045:notes:87]
Step 1: Identify the contract(s) with a customer.

[0001511737-16-000045:notes:88]
Step 2: Identify the performance obligations in the contract.

[0001511737-16-000045:notes:89]
Step 3: Determine the transaction price.

[0001511737-16-000045:notes:90]
Step 4: Allocate the transaction price to the performance obligations in the contract.

[0001511737-16-000045:notes:91]
Step 5: Recognize revenue when (or as) the entity satisfies a performance obligation.

[0001511737-16-000045:notes:92]
An entity should disclose sufficient information to enable users of financial statements to understand the nature, amount, timing, and uncertainty of revenue and cash flows arising from contracts with customers. Qualitative and quantitative information is required about contracts with customers, significant judgments and any assets recognized from the costs to obtain or fulfill a contract.   The guidance was to be effective for annual and interim reporting periods beginning after December 15, 2016.  However, in July 2015, the FASB deferred the effective date by one year, to December 15, 2017, to provide adequate time to effectively implement the new standard, though the early adoption as of the original effective date is allowed. The Company is currently assessing the impact of this new guidance and has not selected the transition method.

[0001511737-16-000045:notes:93]
In February 2016, the FASB issued ASU 2016-02, “Leases (Topic 842),” (“ASU 2016-02”). ASU 2016-02 requires lessees to recognize assets and liabilities on the balance sheet for leases with lease terms greater than twelve months and disclose key information about leasing arrangements. ASU 2016-02 is effective for annual periods beginning after December 15, 2018, including interim periods within those fiscal years, with early application permitted. The Company is evaluating the impact that adoption of this new standard will have on its consolidated financial statements.

[0001511737-16-000045:notes:94]
In March 2016, the FASB issued ASU 2016-08, “Revenue from Contracts with Customers (Topic 606) Principal versus Agent Considerations (Reporting Revenue Gross versus Net),” (“ASU 2016-08”). ASU 2016-08 further clarifies principal and agent relationships within ASU 2014-09. The amendment is effective beginning after December 14, 2017, including interim reporting periods within that reporting year. The Company is evaluating the impact that adoption of this new standard will have on its consolidated financial statements.

[0001511737-16-000045:notes:95]
In April 2016, the FASB issued ASU 2016-10, “Revenue from Contracts with Customers (Topic 606): Identifying Performance Obligations and Licensing." This ASU addresses certain implementation issues that have surfaced since the issuance of ASU 2014-09 in May 2014. The ASU provides guidance in identifying performance obligations and determining the appropriate accounting for licensing arrangements.  The effective date and transition requirements for the amendments in this update are the same as the effective date and transition requirements for ASU 2014-09. The Company is in the process of assessing the impact that adoption of this new standard will have on its consolidated financial statements.

[0001511737-16-000045:notes:96]
In May 2016, the FASB issued ASU No. 2016-12, “Revenue from Contracts with Customers (Topic 606): Narrow-Scope Improvements and Practical Expedients”. (“ASU 2016-12”). ASU 2016-12 will affect all entities that enter into contracts with customers to transfer goods or services (that are an output of the entity’s ordinary activities) in exchange for consideration. The amendments in this update affect the guidance in ASU 2014-09 which is not yet effective. The amendments in this update also affect narrow aspects of Topic 606 including among others: assessing collectability criterion, noncash consideration, and presentation of sales taxes and other similar taxes collected from customers. The effective date and transition requirements for the amendments in this update are the same as the effective date and transition requirements for ASU 2014-09. The Company is evaluating the impact that adoption of this new standard will have on its consolidated financial statements.

[0001511737-16-000045:notes:97]
In June 2016, the FASB issued ASU 2016-13, “Financial Instruments – Credit Losses (Topic 326): Measurement of Credit Losses On Financial Instruments”. (“ASU 2016-13”). ASU 2016-13 implements a comprehensive change in estimating the allowances for loan losses from the current model of losses inherent in the loan portfolio to a current expected credit loss model that generally is expected to result in earlier recognition of allowances for losses. Additionally, purchase accounting rules have been modified as well as credit losses on held-to-maturity debt securities. ASU 2016-13 is effective for fiscal years beginning after December 15, 2019, and early adoption is permitted for annual and interim periods beginning after December 15, 2018. The Company is in the process of assessing the impact that adoption of this new standard will have on its consolidated financial statements.

[0001511737-16-000045:notes:98]
In October 2016, the FASB issued ASU 2016-16, the FASB issued ASU 2016-16, "Income Taxes (Topic 740): Accounting for Income Taxes: Intra-Entity Asset Transfers of Assets Other Than Inventory". (“ASU 2016-16”). ASU 2016-16 eliminates the exception for all intra-entity sales of assets other than inventory. As a result, a reporting entity would recognize the tax expense from the sale of the asset in the seller’s tax jurisdiction when the transfer occurs, even though the pre-tax effects of that transaction are eliminated in consolidation. Any deferred tax asset that arises in the buyer’s jurisdiction would also be recognized at the time of the transfer. ASU 2016-16 is effective for fiscal years beginning after December 15, 2017, and early adoption is permitted but can only be adopted in the first interim period of a fiscal year. The Company is in the process of assessing the impact that adoption of this new standard will have on its consolidated financial statements.


## us-gaap:OtherCurrentLiabilitiesTableTextBlock

[0001511737-16-000045:notes:99]
[same as prior period, unchanged from 0001511737-16-000037:notes:94]

[0001511737-16-000045:notes:100]
|  | September 30, 2016 |  | June 30, 2016 |
| Accrued expenses | $ | 6,948 |  |  | $ | 5,749 |  |
| Accrued compensation and benefits | 2,048 |  |  | 1,589 |  |
| Warranty accrual | 3,028 |  |  | 2,236 |  |
| Deferred revenue - short term | 3,188 |  |  | 2,917 |  |
| Customer deposits | 684 |  |  | 856 |  |
| Reserve for sales returns | 3,334 |  |  | 2,820 |  |
| Other payables | 1,070 |  |  | 10,505 |  |
| Total | $ | 20,300 |  |  | $ | 26,672 |  |


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001511737-16-000045:notes:101]
[same as prior period, unchanged from 0001511737-16-000037:notes:96]

[0001511737-16-000045:notes:102]
[same as prior period, unchanged from 0001511737-16-000037:notes:97]

[0001511737-16-000045:notes:103]
[same as prior period, unchanged from 0001511737-16-000037:notes:98]

[0001511737-16-000045:notes:104]
|  | Three Months Ended September 30, |
|  | 2016 |  | 2015 |
| Beginning balance | $ | 2,236 |  |  | $ | 2,750 |  |
| Accruals for warranties issued during the period | 2,031 |  |  | 120 |  |
| Settlements made during the period | (1,239 | ) |  | (715 | ) |
| Ending balance | $ | 3,028 |  |  | $ | 2,155 |  |


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0001511737-16-000045:notes:105]
[same as prior period, unchanged from 0001511737-16-000037:notes:100]

[0001511737-16-000045:notes:106]
|  | September 30, 2016 |  | June 30, 2016 |
| Testing equipment | $ | 6,481 |  |  | $ | 6,051 |  |
| Computer and other equipment | 5,013 |  |  | 4,857 |  |
| Tooling equipment | 6,036 |  |  | 5,801 |  |
| Furniture and fixtures | 1,325 |  |  | 1,325 |  |
| Leasehold improvements | 5,164 |  |  | 5,136 |  |
| Software | 2,540 |  |  | 2,488 |  |
| Software in development | 2,811 |  |  | 2,739 |  |
| Property and Equipment, Gross | 29,370 |  |  | 28,397 |  |
| Less: Accumulated depreciation and amortization | (16,850 | ) |  | (15,444 | ) |
| Property and Equipment, Net | $ | 12,520 |  |  | $ | 12,953 |  |


## us-gaap:ReconciliationOfRevenueFromSegmentsToConsolidatedTextBlock

[0001511737-16-000045:notes:107]
[same as prior period, unchanged from 0001511737-16-000037:notes:105]

[0001511737-16-000045:notes:108]
|  | Three Months Ended September 30, |  |
|  | 2016 |  | 2015 |  |
| Service provider technology | $ | 120,632 |  |  | 59 | % |  | $ | 103,399 |  |  | 68 | % |  |
| Enterprise technology | 84,125 |  |  | 41 | % |  | 48,016 |  |  | 32 | % |  |
| Total revenues | $ | 204,757 |  |  | 100 | % |  | $ | 151,415 |  |  | 100 | % |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001511737-16-000045:notes:109]
RELATED PARTY TRANSACTIONS AND CERTAIN OTHER TRANSACTIONS

[0001511737-16-000045:notes:110]
Aircraft Lease Agreement

[0001511737-16-000045:notes:111]
On November 13, 2013, the Company entered into an aircraft lease agreement (the “Aircraft Lease Agreement”) with RJP Manageco LLC (the “Lessor”), a limited liability company owned by the Company’s CEO, Robert J. Pera. Pursuant to the Aircraft Lease Agreement, the Company may lease an aircraft owned by the Lessor for Company business purposes. Under the Aircraft Lease Agreement, the aircraft may be leased at a rate of $5,000 per flight hour. This hourly rate does not include the cost of flight crew or on-board services, which the Company purchases from a third-party provider. The Company recognized a total of approximately $650 thousand and $213 thousand in expenses pursuant to the Aircraft Lease Agreement during the three months ended September 30, 2016 and 2015, respectively.  All expenses pursuant to the Aircraft Lease Agreement have been included in the Company’s sales, general and administrative expenses in the Consolidated Statements of Operations.


## us-gaap:RevenueFromExternalCustomersByGeographicAreasTableTextBlock

[0001511737-16-000045:notes:112]
[same as prior period, unchanged from 0001511737-16-000037:notes:110]

[0001511737-16-000045:notes:113]
|  | Three Months Ended September 30, |  |
|  | 2016 |  | 2015 |  |
| North America(1) | $ | 74,165 |  |  | 36 | % |  | $ | 53,234 |  |  | 35 | % |  |
| South America | 24,184 |  |  | 12 | % |  | 22,148 |  |  | 15 | % |  |
| Europe, the Middle East and Africa ("EMEA") | 81,375 |  |  | 40 | % |  | 60,503 |  |  | 40 | % |  |
| Asia Pacific | 25,033 |  |  | 12 | % |  | 15,530 |  |  | 10 | % |  |
| Total revenues | $ | 204,757 |  |  | 100 | % |  | $ | 151,415 |  |  | 100 | % |  |

[0001511737-16-000045:notes:114]
| (1) | Revenue for the United States was $70.6 million and $50.6 million for the three months ended September 30, 2016 and 2015, respectively. |


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0001511737-16-000045:notes:115]
[same as prior period, unchanged from 0001511737-16-000037:notes:113]

[0001511737-16-000045:notes:116]
|  | September 30, 2016 |  | June 30, 2016 |
| Finished goods | $ | 71,040 |  |  | $ | 50,987 |  |
| Raw materials | 8,801 |  |  | 6,126 |  |
| Total | $ | 79,841 |  |  | $ | 57,113 |  |


## us-gaap:ScheduleOfOtherAssetsNoncurrentTextBlock

[0001511737-16-000045:notes:117]
[same as prior period, unchanged from 0001511737-16-000037:notes:115]

[0001511737-16-000045:notes:118]
|  | September 30, 2016 |  | June 30, 2016 |
| Intangible assets, net (1) | $ | 594 |  |  | $ | 616 |  |
| Other long-term assets | 1,062 |  |  | 960 |  |
| Total | $ | 1,656 |  |  | $ | 1,576 |  |

[0001511737-16-000045:notes:119]
(1) - Accumulated amortization was $1,025 thousand and $955 thousand as of September 30, 2016 and June 30, 2016, respectively.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001511737-16-000045:notes:120]
[same as prior period, unchanged from 0001511737-16-000037:notes:119]

[0001511737-16-000045:notes:121]
[same as prior period, unchanged from 0001511737-16-000037:notes:120]

[0001511737-16-000045:notes:122]
[same as prior period, unchanged from 0001511737-16-000037:notes:121]

[0001511737-16-000045:notes:123]
| • | Enterprise Technology includes the Company’s UniFi and mFi platforms, including UniFi Access Point (“UAP”) products, AmpliFi, UniFi Video products, UniFi Voice Over IP (“VOIP”) phones and UniFi switch products. Enterprise Technology also includes revenues that are attributable to PCS. |


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001511737-16-000045:notes:124]
[same as prior period, unchanged from 0001511737-16-000037:notes:123]

[0001511737-16-000045:notes:125]
The Company’s significant accounting policies are disclosed in its audited consolidated financial statements for the year ended June 30, 2016 included in the Annual Report. Except as noted below, there have been no changes to the Company’s significant accounting policies as discussed in the Annual Report.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001511737-16-000045:notes:126]
[same as prior period, unchanged from 0001511737-16-000037:notes:126]

[0001511737-16-000045:notes:127]
As of September 30, 2016 and June 30, 2016, the authorized capital of the Company included 500,000,000 shares of common stock.  As of September 30, 2016 and June 30, 2016, there were 82,123,043 and 81,667,129 shares of common stock outstanding, respectively.

[0001511737-16-000045:notes:128]
[same as prior period, unchanged from 0001511737-16-000037:notes:128]

[0001511737-16-000045:notes:129]
On May 4, 2016, the Board of Directors of the Company approved a $50 million stock repurchase program. Under the stock repurchase program, the Company was authorized to repurchase up to $50 million of its common stock. During the fourth quarter of fiscal 2016, the Company repurchased 1,309,606 shares of its common stock at an average price per share of $38.18 for an aggregate amount of $50 million. This included unpaid stock repurchases of $6.5 million relating to repurchases executed on or prior to June 30, 2016 for trades that settled in the first quarter of fiscal 2017.

[0001511737-16-000045:notes:130]
On August 3, 2016, the Board of Directors of the Company approved a $50 million stock repurchase program. Under the new stock repurchase program, the Company may repurchase up to $50 million of its common stock. The program expires on September 30, 2017. As of September 30, 2016, the Company has not repurchased any of its common stock under this plan.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001511737-16-000045:notes:131]
[same as prior period, unchanged from 0001511737-16-000037:notes:132]

[0001511737-16-000045:notes:132]
[same as prior period, unchanged from 0001511737-16-000037:notes:133]

[0001511737-16-000045:notes:133]
[same as prior period, unchanged from 0001511737-16-000037:notes:135]

[0001511737-16-000045:notes:134]
[same as prior period, unchanged from 0001511737-16-000037:notes:136]

[0001511737-16-000045:notes:135]
[same as prior period, unchanged from 0001511737-16-000037:notes:137]


## us-gaap:UnusualOrInfrequentItemsDisclosureTextBlock

[0001511737-16-000045:notes:136]
[same as prior period, unchanged from 0001511737-16-000037:notes:138]

[0001511737-16-000045:notes:137]
As disclosed in June 2015 and 2016, the Company determined that it was the victim of a criminal fraud known to law enforcement authorities as business e-mail compromise fraud which involved employee impersonation and fraudulent requests targeting our finance department.  The fraud resulted in transfers of funds aggregating $46.7 million held by a Company subsidiary incorporated in Hong Kong to other overseas accounts held by third parties.  To date, the Company has recovered $16.7 million. The Company recovered $8.1 million in fiscal 2015, resulting in a charge of $39.1 million in the fourth quarter of fiscal 2015, including additional expenses consisting of professional service fees associated with the fraud loss.  In fiscal 2016, the Company recorded a net recovery of an additional $8.3 million, comprised of the $8.6 million recovery less $0.3 million of professional service fees associated with the recovery. No additional recoveries were made during the three months ended September 30, 2016.

[0001511737-16-000045:notes:138]
[same as prior period, unchanged from 0001511737-16-000037:notes:140]
