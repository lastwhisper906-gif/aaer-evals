# UI note change history — 0001511737-16-000037 → 0001511737-16-000045


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2016-11-07):
[0001511737-16-000045:note_history:1]
Certain facilities and equipment are leased under non-cancelable operating leases. The Company generally pays taxes, insurance and maintenance costs on leased facilities and equipment. The Company leases its headquarters in San Jose, California and other locations under non-cancelable operating leases that expire at various dates through fiscal 2022.
  (was, 2016-05-05, similarity 0.9486):
[0001511737-16-000037:note_history:1]
Certain facilities and equipment are leased under non-cancelable operating leases. The Company generally pays taxes, insurance and maintenance costs on leased facilities and equipment. The Company leases office space in San Jose, California and other locations under various non-cancelable operating leases that expire at various dates through fiscal 2021.

- changed (2016-11-07):
[0001511737-16-000045:note_history:2]
At September 30, 2016, future minimum annual payments under operating leases for the remainder of fiscal 2017 and future fiscal years are as follows (in thousands):
  (was, 2016-05-05, similarity 0.9673):
[0001511737-16-000037:note_history:2]
At March 31, 2016, future minimum annual payments under operating leases for the remainder of fiscal 2016 and future fiscal years are as follows (in thousands):

- changed (2016-11-07):
[0001511737-16-000045:note_history:3]
The Company primarily subcontracts with other companies to manufacture its products. During the normal course of business, the Company’s contract manufacturers procure components based upon orders placed by the Company. If the Company cancels all or part of the orders, it may still be liable to the contract manufacturers for the cost of the components purchased by them to manufacture the Company’s products. The Company periodically reviews the potential liability under its orders, and no significant accruals have been recorded as of September 30, 2016.  The Company had inventory purchase obligations of $25.8 million as of September 30, 2016.
  (was, 2016-05-05, similarity 0.9389):
[0001511737-16-000037:note_history:3]
The Company primarily subcontracts with other companies to manufacture its products. During the normal course of business, the Company’s contract manufacturers procure components based upon orders placed by the Company. If the Company cancels all or part of the orders, it may still be liable to the contract manufacturers for the cost of the components purchased by them to manufacture the Company’s products. The Company periodically reviews the potential liability, and no significant accruals have been recorded for the nine months ended March 31, 2016.  The Company had inventory purchase obligations of $22.0 million as of March 31, 2016.

- changed (2016-11-07):
[0001511737-16-000045:note_history:4]
The Company had other obligations of $10.0 million as of September 30, 2016, which consisted primarily of commitments related to research and development projects.
  (was, 2016-05-05, similarity 0.9671):
[0001511737-16-000037:note_history:4]
The Company had other obligations of $6.3 million as of March 31, 2016, which consisted primarily of commitments related to research and development projects.

- changed (2016-11-07):
[0001511737-16-000045:note_history:5]
The Company may be involved, from time to time, in a variety of claims, lawsuits, investigations, and proceedings relating to contractual disputes, intellectual property rights, employment matters, regulatory compliance matters and other litigation matters relating to various claims that arise in the normal course of business. The Company determines whether an estimated loss from a contingency should be accrued by assessing whether a loss is deemed probable and can be reasonably estimated. The Company assesses its potential liability by analyzing specific litigation and regulatory matters using available information. The Company develops its views on estimated losses in consultation with inside and outside counsel, which involves a subjective analysis of potential results and outcomes, assuming various combinations of appropriate litigation and settlement strategies. Taking all of the above factors into account, the Company records an amount where it is probable that the Company will incur a loss and where that loss can be reasonably estimated. However, the Company’s estimates may be incorrect and the Company could ultimately incur more or less than the amounts initially recorded.  The Company may also incur significant legal fees, which are expensed as incurred, in defending against these claims. The Company is not currently aware of any pending or threatened litigation that would have a material adverse effect on the Company's financial statements.
  (was, 2016-05-05, similarity 0.9441):
[0001511737-16-000037:note_history:5]
The Company may be involved, from time to time, in a variety of claims, lawsuits, investigations, and proceedings relating to contractual disputes, intellectual property rights, employment matters, regulatory compliance matters and other litigation matters relating to various claims that arise in the normal course of business. The Company determines whether an estimated loss from a contingency should be accrued by assessing whether a loss is deemed probable and can be reasonably estimated. The Company assesses its potential liability by analyzing specific litigation and regulatory matters using available information. The Company develops its views on estimated losses in consultation with inside and outside counsel, which involves a subjective analysis of potential results and outcomes, assuming various combinations of appropriate litigation and settlement strategies. Taking all of the above factors into account, the Company records an amount where it is probable that the Company will incur a loss and where that loss can be reasonably estimated. However, the Company’s estimates may be incorrect and the Company could ultimately incur more or less than the amounts initially recorded.  The Company may also incur significant legal fees, which are expensed as incurred, in defending against these claims.

- changed (2016-11-07):
[0001511737-16-000045:note_history:6]
Beginning on September 7, 2012, two class action lawsuits were filed in the United States District Court for the Northern District of California against Ubiquiti Networks, Inc., certain of its officers and directors, and the underwriters of its initial public offering, alleging claims under U.S. securities laws. On January 30, 2013, the plaintiffs filed an amended consolidated complaint. On March 26, 2014, the court issued an order granting a motion to dismiss the complaint with leave to amend. Following the plaintiffs’ decision not to file an amended complaint, on April 16, 2014, the court ordered the dismissal of the lawsuit with prejudice, and entered judgment in favor of the Company and the other defendants, and against the plaintiffs. On May 15, 2014, the plaintiffs filed a notice of appeal from the judgment of the court. The Ninth Circuit heard oral arguments on August 10, 2016.  On October 24, 2016, the Ninth Circuit issued an unpublished opinion, reaffirming the district court’s dismissal of the alleged violation of Sections 10(b) and 20(a) of the Securities Exchange Act of 1934 and reversing the district court’s dismissal of the alleged violations of Sections 11 and 15 of the Securities Act of 1933. The Company plans to file a petition for rehearing with the Ninth Circuit and to vigorously defend itself against these claims. There can be no assurance that the Company will prevail. The Company cannot currently estimate the possible loss, if any, that it may experience in connection with this litigation.
  (was, 2016-05-05, similarity 0.7321):
[0001511737-16-000037:note_history:6]
Beginning on September 7, 2012, two class action lawsuits were filed in the United States District Court for the Northern District of California against Ubiquiti Networks, Inc., certain of its officers and directors, and the underwriters of its initial public offering, alleging claims under U.S. securities laws. On January 30, 2013, the plaintiffs filed an amended consolidated complaint. On March 26, 2014, the court issued an order granting a motion to dismiss the complaint with leave to amend. Following the plaintiffs’ decision not to file an amended complaint, on April 16, 2014, the court ordered the dismissal of the lawsuit with prejudice, and entered judgment in favor of the Company and the other defendants, and against the plaintiffs. On May 15, 2014, the plaintiffs filed a notice of appeal from the judgment of the court. The appeal is ongoing before the U.S. Court of Appeals for the Ninth Circuit. There can be no assurance that the Company will prevail in the appeal proceeding.  The Company cannot currently estimate the possible loss, if any, that it may experience in connection with this litigation.


## us-gaap:BusinessDescriptionAndBasisOfPresentationTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2016-11-07):
[0001511737-16-000045:note_history:7]
Basis of Presentation— The accompanying consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP”) related to interim financial statements based on applicable Securities and Exchange Commission (“SEC”) rules and regulations. Accordingly, they do not include all the information and footnotes required by U.S. GAAP for complete financial statements. These consolidated financial statements reflect all adjustments, which are, in the opinion of the Company, of a normal and recurring nature and those necessary to state fairly the statements of financial position, results of operations and cash flows for the dates and periods presented. The June 30, 2016 balance sheet was derived from the audited financial statements as of that date. All significant intercompany transactions and balances have been eliminated.  The Company has reclassified certain amounts reported in the previous period to conform to the current period presentation.
  (was, 2016-05-05, similarity 0.9885):
[0001511737-16-000037:note_history:7]
Basis of Presentation— The accompanying condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP”) related to interim financial statements based on applicable Securities and Exchange Commission (“SEC”) rules and regulations. Accordingly, they do not include all the information and footnotes required by U.S. GAAP for complete financial statements. These condensed and consolidated financial statements reflect all adjustments, which are, in the opinion of the Company, of a normal and recurring nature and those necessary to state fairly the statements of financial position, results of operations and cash flows for the dates and periods presented. The June 30, 2015 balance sheet was derived from the audited financial statements as of that date. All significant intercompany transactions and balances have been eliminated.  The Company has reclassified certain amounts reported in the previous period to conform to the current period presentation.

- changed (2016-11-07):
[0001511737-16-000045:note_history:8]
These consolidated financial statements should be read in conjunction with the Company’s audited consolidated financial statements for the fiscal year ended June 30, 2016, included in its Annual Report on Form 10-K, as filed with the SEC on August 22, 2016 (the “Annual Report”). The results of operations for the three months ended September 30, 2016 are not necessarily indicative of the results to be expected for any future periods.
  (was, 2016-05-05, similarity 0.7667):
[0001511737-16-000037:note_history:8]
These condensed consolidated financial statements should be read in conjunction with the Company’s audited consolidated financial statements for the fiscal year ended June 30, 2015, included in its Annual Report on Form 10-K, as filed with the SEC on August 21, 2015 (the “Annual Report”). The results of operations for the three and nine months ended March 31, 2016 are not necessarily indicative of the results to be expected for any future periods.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2016-11-07):
[0001511737-16-000045:note_history:9]
New Accounting Updates Recently Adopted

- added (2016-11-07):
[0001511737-16-000045:note_history:10]
Effective July 1, 2016, the Company adopted Accounting Standards Update (“ASU”) 2015-03 regarding simplifying the presentation of debt issuance costs. The guidance requires that debt issuance costs related to a recognized debt liability be presented in the balance sheet as a direct deduction from the carrying amount of that debt liability, consistent with debt discounts. Previously the Company reported these costs as assets on its balance sheet. The guidance is applied on a retrospective basis whereby prior-period financial statements must be adjusted to reflect the adoption of the new guidance.

- added (2016-11-07):
[0001511737-16-000045:note_history:11]
The Company has reclassified $0.3 million from "prepaid expenses and other current assets" to "Debt - short-term", and $0.7 million from "Other long-term assets" to "Debt - long-term" on the June 30, 2016 consolidated balance sheet.

- added (2016-11-07):
[0001511737-16-000045:note_history:12]
Effective July 1, 2016, the Company adopted ASU 2015-11 regarding simplifying the measurement of inventory. The guidance requires an entity to measure inventory at the lower of cost and net realizable value. Net realizable value is the estimated selling prices in the ordinary course of business, less reasonably predictable costs of completion, disposal, and transportation. The Company adopted this update prospectively, and it did not have a material impact on the Company's Consolidated Financial Statements.

- added (2016-11-07):
[0001511737-16-000045:note_history:13]
Effective July 1, 2016, the Company early adopted ASU 2016-09 regarding the Improvements to Employee Share-Based Payment Accounting. The Company applied the guidance relating to accounting for excess tax benefits and the presentation of excess tax benefits for share-based payments in the consolidated statement of cash flows on a prospective basis; according prior period amounts have not been adjusted. The Company recognized the excess tax benefits of $6.8 million within the provision for income taxes rather than additional paid-in capital during the three months ended September 30, 2016. The Company classified the excess tax benefits for share-based payments within cash flows from operating activities for the three months ended September 30, 2016 rather than within cash flows from financing activities. In regards to the forfeiture policy election, we will continue to estimate the number of awards expected to be forfeited, rather than electing to account for forfeitures as they occur. No other terms of the adopted guidance resulted in an impact on the Company's Consolidated Financial Statements.

- added (2016-11-07):
[0001511737-16-000045:note_history:14]
Recent Accounting Standards or Updates Not Yet Effective

- changed (2016-11-07):
[0001511737-16-000045:note_history:15]
In June 2014, the FASB issued a new accounting standard update on revenue from contracts with customers.  The core principle of the guidance is that an entity should recognize revenue to depict the transfer of promised goods or services to customers in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services.  To achieve that core principle, an entity should apply the following steps:
  (was, 2016-05-05, similarity 0.9511):
[0001511737-16-000037:note_history:15]
In June 2014, the Financial Accounting Standards Board, or FASB, issued a new accounting standard update on revenue from contracts with customers.  The core principle of the guidance is that an entity should recognize revenue to depict the transfer of promised goods or services to customers in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services.  To achieve that core principle, an entity should apply the following steps:

- added (2016-11-07):
[0001511737-16-000045:note_history:16]
An entity should disclose sufficient information to enable users of financial statements to understand the nature, amount, timing, and uncertainty of revenue and cash flows arising from contracts with customers. Qualitative and quantitative information is required about contracts with customers, significant judgments and any assets recognized from the costs to obtain or fulfill a contract.   The guidance was to be effective for annual and interim reporting periods beginning after December 15, 2016.  However, in July 2015, the FASB deferred the effective date by one year, to December 15, 2017, to provide adequate time to effectively implement the new standard, though the early adoption as of the original effective date is allowed. The Company is currently assessing the impact of this new guidance and has not selected the transition method.

- changed (2016-11-07):
[0001511737-16-000045:note_history:17]
In April 2016, the FASB issued ASU 2016-10, “Revenue from Contracts with Customers (Topic 606): Identifying Performance Obligations and Licensing." This ASU addresses certain implementation issues that have surfaced since the issuance of ASU 2014-09 in May 2014. The ASU provides guidance in identifying performance obligations and determining the appropriate accounting for licensing arrangements.  The effective date and transition requirements for the amendments in this update are the same as the effective date and transition requirements for ASU 2014-09. The Company is in the process of assessing the impact that adoption of this new standard will have on its consolidated financial statements.
  (was, 2016-05-05, similarity 0.6657):
[0001511737-16-000037:note_history:17]
In April 2016, the FASB issued ASU 2016-10, “Revenue from Contracts with Customers (Topic 606): Identifying Performance Obligations and Licensing." This ASU addresses certain implementation issues that have surfaced since the issuance of ASU 2014-09 in May 2014. The ASU provides guidance in identifying performance obligations and determining the appropriate accounting for licensing arrangements. The amendments in this ASU are effective for fiscal years beginning after December 15, 2017, and for interim periods therein. The Company is in the process of assessing the impact that adoption of this new standard will have on its consolidated financial statements.

- added (2016-11-07):
[0001511737-16-000045:note_history:18]
In May 2016, the FASB issued ASU No. 2016-12, “Revenue from Contracts with Customers (Topic 606): Narrow-Scope Improvements and Practical Expedients”. (“ASU 2016-12”). ASU 2016-12 will affect all entities that enter into contracts with customers to transfer goods or services (that are an output of the entity’s ordinary activities) in exchange for consideration. The amendments in this update affect the guidance in ASU 2014-09 which is not yet effective. The amendments in this update also affect narrow aspects of Topic 606 including among others: assessing collectability criterion, noncash consideration, and presentation of sales taxes and other similar taxes collected from customers. The effective date and transition requirements for the amendments in this update are the same as the effective date and transition requirements for ASU 2014-09. The Company is evaluating the impact that adoption of this new standard will have on its consolidated financial statements.

- added (2016-11-07):
[0001511737-16-000045:note_history:19]
In June 2016, the FASB issued ASU 2016-13, “Financial Instruments – Credit Losses (Topic 326): Measurement of Credit Losses On Financial Instruments”. (“ASU 2016-13”). ASU 2016-13 implements a comprehensive change in estimating the allowances for loan losses from the current model of losses inherent in the loan portfolio to a current expected credit loss model that generally is expected to result in earlier recognition of allowances for losses. Additionally, purchase accounting rules have been modified as well as credit losses on held-to-maturity debt securities. ASU 2016-13 is effective for fiscal years beginning after December 15, 2019, and early adoption is permitted for annual and interim periods beginning after December 15, 2018. The Company is in the process of assessing the impact that adoption of this new standard will have on its consolidated financial statements.

- added (2016-11-07):
[0001511737-16-000045:note_history:20]
In October 2016, the FASB issued ASU 2016-16, the FASB issued ASU 2016-16, "Income Taxes (Topic 740): Accounting for Income Taxes: Intra-Entity Asset Transfers of Assets Other Than Inventory". (“ASU 2016-16”). ASU 2016-16 eliminates the exception for all intra-entity sales of assets other than inventory. As a result, a reporting entity would recognize the tax expense from the sale of the asset in the seller’s tax jurisdiction when the transfer occurs, even though the pre-tax effects of that transaction are eliminated in consolidation. Any deferred tax asset that arises in the buyer’s jurisdiction would also be recognized at the time of the transfer. ASU 2016-16 is effective for fiscal years beginning after December 15, 2017, and early adoption is permitted but can only be adopted in the first interim period of a fiscal year. The Company is in the process of assessing the impact that adoption of this new standard will have on its consolidated financial statements.

- removed (2016-11-07):
[0001511737-16-000037:note_history:21]
Capitalized Manufacturing Overhead Costs

- removed (2016-11-07):
[0001511737-16-000037:note_history:22]
In fiscal 2016, the Company began capitalizing manufacturing overhead expenditures as part of inventory costs.  Capitalized costs primarily include management’s best estimate of the direct labor and materials costs related to inventory produced but not sold during the period.  As of March 31, 2016, the Company capitalized $1.2 million of manufacturing overhead costs.  Manufacturing overhead costs are capitalized to inventory and are recognized as cost of revenues in the following quarter, consistent with the Company's historical inventory turnover.

- removed (2016-11-07):
[0001511737-16-000037:note_history:23]
Recent Accounting Pronouncements

- removed (2016-11-07):
[0001511737-16-000037:note_history:24]
An entity should disclose sufficient information to enable users of financial statements to understand the nature, amount, timing, and uncertainty of revenue and cash flows arising from contracts with customers. Qualitative and quantitative information is required about contracts with customers, significant judgments and any assets recognized from the costs to obtain or fulfill a contract.   The guidance was initially effective for annual and interim reporting periods beginning after December 15, 2016.  However, in July 2015, the FASB voted to defer the effective date by one year, to December 15, 2017, to provide adequate time to effectively implement the new standard.  The Company does not anticipate that the new guidance will have a material impact on its consolidated financial statements.

- removed (2016-11-07):
[0001511737-16-000037:note_history:25]
In April 2015, the FASB issued Accounting Standards Update (“ASU”) 2015-03 to simplify the presentation of debt issuance costs.  The updated guidance requires that debt issuance costs related to a recognized debt liability be presented in the balance sheet as a direct deduction from the carrying amount of that debt liability, consistent with debt discounts. The recognition and measurement guidance for debt issuance costs are not affected by the updated guidance.  The guidance will be effective for the Company beginning July 1, 2016.  The guidance will result only in a reclassification on the Company’s balance sheet and will not have any effect on the Company’s results of operations or cash flows.

- removed (2016-11-07):
[0001511737-16-000037:note_history:26]
In July 2015, the FASB issued ASU 2015-11 which explains how the Accounting Standards Codification will be updated to simplify the measurement of inventory costs.  The updated guidance requires that inventory be valued at the lower of cost or net realizable value.  This differs from current guidance which requires that inventory be valued at the lower of cost or market, where market can be replacement cost, net realizable value or net realizable value less an approximately normal profit margin.  The guidance will be effective for the Company beginning July 1, 2017.  The Company does not anticipate that this guidance will have a material impact on the Company’s consolidated financial statements.

- removed (2016-11-07):
[0001511737-16-000037:note_history:27]
In November 2015, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update No. 2015-17, Balance Sheet Classification of Deferred Taxes. ASU 2015-17 simplifies the presentation of deferred taxes by requiring deferred tax assets and liabilities be classified as non-current on the balance sheet. ASU 2015-17 is effective for public companies for annual reporting periods beginning after December 15, 2016, and interim periods within those fiscal years. The guidance may be adopted prospectively or retrospectively, and early adoption is permitted.  The Company is currently evaluating ASU 2015-17 but does not anticipate that this guidance will have a material impact on the presentation of the Company's consolidated financial statements.

- removed (2016-11-07):
[0001511737-16-000037:note_history:28]
In March 2016, the FASB issued ASU 2016-09, “Compensation-Stock Compensation (Topic 718), Improvements to Employee Share-Based Payment Accounting,” (“ASU 2016-09”). ASU 2016-09 is intended to simplify several aspects of accounting for share-based payment awards. The amendment is effective for annual periods beginning after December 15, 2016, and interim periods within those annual periods. The Company is evaluating the impact that adoption of this new standard will have on its consolidated financial statements.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2016-11-07):
[0001511737-16-000045:note_history:29]
On March 3, 2015, Ubiquiti Networks, Inc. and Ubiquiti International Holding Company Limited (the “Cayman Borrower”) amended and restated its original credit agreement (the “Amended Credit Agreement”) with Wells Fargo Bank, National Association (“Wells Fargo”), the other financial institutions named as lenders therein, and Wells Fargo as administrative agent for the lenders.  The Amended Credit Agreement provides for a $200.0 million senior secured revolving credit facility and a $100.0 million senior secured term loan facility (collectively, the “Facilities”), with an option to request increases in the amounts of such credit facilities by up to an additional $50.0 million in the aggregate (any such increase to be in each lender’s sole discretion), and matures on March 3, 2020.  The $100.0 million term loan facility of the Amended Credit Agreement was fully drawn at closing, and $72.3 million was used to repay the outstanding balance under its original credit agreement.
  (was, 2016-05-05, similarity 0.731):
[0001511737-16-000037:note_history:29]
On March 3, 2015, Ubiquiti Networks, Inc. and Ubiquiti International Holding Company Limited (the “Cayman Borrower”) amended and restated its original credit agreement (the “Amended Credit Agreement”) with Wells Fargo Bank, National Association (“Wells Fargo”), the other financial institutions named as lenders therein, and Wells Fargo as administrative agent for the lenders.  The Amended Credit Agreement provides for a $200.0 million senior secured revolving credit facility and a $100.0 million senior secured term loan facility (collectively, the “Facilities”), with an option to request increases in the amounts of such credit facilities by up to an additional $50.0 million in the aggregate (any such increase to be in each lender’s sole discretion), and matures on March 3, 2020.  The $100.0 million term loan facility of the Amended Credit Agreement was fully drawn at closing, and $72.3 million was used to repay the outstanding balance under its original credit agreement.  During the nine months ended March 31, 2016, the Company drew $66 million against the revolving credit facility.  Draws of $15 million and $18 million were made in the second fiscal quarter and draws of $14 million and $19 million were made in the third fiscal quarter.  These balances are not due until March 2020, and accordingly are classified as long-term debt.  As of March 31, 2016, $90 million was outstanding on the term loan and $66 million on the revolver, leaving $134 million available on the revolver.  As of March 31, 2016, the interest rate on the term loan was 2.13%.  The table below shows the respective interest rates as of March 31, 2016 in addition to interest rate reset dates and rates as available for each revolver draw.

- added (2016-11-07):
[0001511737-16-000045:note_history:30]
Our Debt consisted of the following (in thousands):

- added (2016-11-07):
[0001511737-16-000045:note_history:31]
|  | September 30, 2016 |  | June 30, 2016 |
| Term Loan - short term | $ | 12,500 |  |  | $ | 11,250 |  |
| Debt Issuance costs, net (1) | (257 | ) |  | (257 | ) |
| Total Debt - short term | 12,243 |  |  | 10,993 |  |
| Term Loan - long term | 72,500 |  |  | 76,250 |  |
| Revolver - long term | 116,000 |  |  | 116,000 |  |
| Debt issuance costs, net (1) | (621 | ) |  | (686 | ) |
| Total Debt - long term | $ | 187,879 |  |  | $ | 191,564 |  |

- added (2016-11-07):
[0001511737-16-000045:note_history:32]
(1) On July 1 2016, the Company retrospectively adopted ASU 2015-03, which requires unamortized debt issuance costs to be included as a direct deduction from the related debt liability on the balance sheet. Under previous guidance, all unamortized debt issuance costs were reported as assets on the balance sheet. See Note 2 for information on the impact of the retrospective adoption of ASU 2015-03.

- added (2016-11-07):
[0001511737-16-000045:note_history:33]
As of September 30, 2016, the interest rate on the term loan was 2.34%.  The table below shows the respective interest rates as of September 30, 2016 in addition to interest rate reset dates and rates as available for each revolver draw.

- added (2016-11-07):
[0001511737-16-000045:note_history:34]
|  |  | Interest Rate as of |  |  |  |  |
| Debt Payment Obligations |  | September 30, 2016 |  | Rate Reset Date |  | Reset Rate |
| $15 Million Revolver |  | 2.42% |  | 01/09/2017 |  | * |
| $18 Million Revolver |  | 2.48% |  | 01/18/2017 |  | * |
| $16 Million Revolver |  | 2.70% |  | 02/13/2017 |  | * |
| $19 Million Revolver |  | 2.41% |  | 01/03/2017 |  | * |
| $48 Million Revolver |  | 2.48% |  | 11/30/2016 |  | * |

- added (2016-11-07):
[0001511737-16-000045:note_history:35]
During the three months ended September 30, 2016, the Company made a payment of $3.0 million against the term loan facility under the Amended Credit Agreement, of which $2.5 million was a repayment of principal and $0.5 million was payment of interest. During the three months ended September 30, 2016, the Company made a payment of $0.4 million interest against the revolver loan facility under the Amended Credit Agreement. As of September 30, 2016, excluding debt issuance costs, the Company classified $12.5 million and $188.5 million as short-term and as long-term debt, respectively, on its consolidated balance sheet.

- changed (2016-11-07):
[0001511737-16-000045:note_history:36]
The following table summarizes our estimated debt and interest payment obligations as of September 30, 2016, for the remainder of fiscal 2017 and future fiscal years (in thousands):
  (was, 2016-05-05, similarity 0.9706):
[0001511737-16-000037:note_history:36]
The following table summarizes our estimated debt and interest payment obligations as of March 31, 2016, for the remainder of fiscal 2016 and future fiscal years (in thousands):

- added (2016-11-07):
[0001511737-16-000045:note_history:37]
|  | 2017 (remainder) |  | 2018 |  | 2019 |  | 2020 |  | Thereafter |  | Total |
| Debt payment obligations | $ | 8,750 |  |  | $ | 15,000 |  |  | $ | 15,000 |  |  | $ | 162,250 |  |  | $ | — |  |  | $ | 201,000 |  |
| Interest and other payments on debt payment obligations (1) | 3,754 |  |  | 4,712 |  |  | 4,361 |  |  | 2,781 |  |  | — |  |  | 15,608 |  |
| Total | $ | 12,504 |  |  | $ | 19,712 |  |  | $ | 19,361 |  |  | $ | 165,031 |  |  | $ | — |  |  | $ | 216,608 |  |

- changed (2016-11-07):
[0001511737-16-000045:note_history:38]
(1) - Interest payments are calculated based on the applicable rates and payment dates as of September 30, 2016. Furthermore, two to three-month payment intervals on the revolving debt have been assumed, consistent with the Company's elections to date.
  (was, 2016-05-05, similarity 0.9672):
[0001511737-16-000037:note_history:38]
(1) - Interest payments are calculated based on the applicable rates and payment dates as of March 31, 2016. Furthermore, two to three month payment intervals on the revolving debt have been assumed, consistent with the Company's elections to date.

- removed (2016-11-07):
[0001511737-16-000037:note_history:39]
|  |  | Interest Rate as of |  |  |  |  |
| Debt Payment Obligations |  | March 31, 2016 |  | Rate Reset Date |  | Reset Rate |
| $15 Million Revolver |  | 2.02% |  | April 8, 2016 |  | 2.13% |
| $18 Million Revolver |  | 2.01% |  | April 18, 2016 |  | 2.13% |
| $14 Million Revolver |  | 2.02% |  | May 31, 2016 |  | * |
| $19 Million Revolver |  | 2.02% |  | April 1, 2016 |  | 2.13% |

- removed (2016-11-07):
[0001511737-16-000037:note_history:40]
The revolving and term loans contain other customary terms and conditions which are more fully explained in Note 7 of the audited consolidated financial statements included in the Annual Report for the year ended June 30, 2015.

- removed (2016-11-07):
[0001511737-16-000037:note_history:41]
During the three months ended March 31, 2016, the Company made a payment of $3.0 million against the term loan facility balance under the Amended Credit Agreement, of which $2.5 million was a repayment of principal and $500 thousand was payment of interest. During the nine months ended March 31, 2016, the Company made aggregate payments of $8.9 million against the term loan facility balance under the Amended Credit Agreement, of which $7.5 million was for repayments of principal and $1.4 million was for payments of interest.  During the three and nine months ended March 31, 2016, the Company made aggregate payments of $160 thousand and $260 thousand, respectively, against the revolving loan facility under the Amended Credit Agreement.  As of March 31, 2016, the Company classified $10.0 million as short-term and $146.0 million as long-term debt on its consolidated balance sheet related to the Facilities under the Amended Credit Agreement.

- removed (2016-11-07):
[0001511737-16-000037:note_history:42]
|  | 2016 (remainder) |  | 2017 |  | 2018 |  | 2019 |  | 2020 |  | Thereafter |  | Total |
| Debt payment obligations | $ | 2,500 |  |  | $ | 11,250 |  |  | $ | 15,000 |  |  | $ | 15,000 |  |  | $ | 112,250 |  |  | $ | — |  |  | $ | 156,000 |  |
| Interest and other payments on debt (1) | 888 |  |  | 3,422 |  |  | 3,142 |  |  | 2,822 |  |  | 1,746 |  |  | — |  |  | 12,020 |  |
| Total | $ | 3,388 |  |  | $ | 14,672 |  |  | $ | 18,142 |  |  | $ | 17,822 |  |  | $ | 113,996 |  |  | $ | — |  |  | $ | 168,020 |  |


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2016-11-07):
[0001511737-16-000045:note_history:43]
The table below shows the respective interest rates as of September 30, 2016 in addition to interest rate reset dates and rates as available for each revolver draw.
  (was, 2016-05-05, similarity 0.9682):
[0001511737-16-000037:note_history:43]
The table below shows the respective interest rates as of March 31, 2016 in addition to interest rate reset dates and rates as available for each revolver draw.

- added (2016-11-07):
[0001511737-16-000045:note_history:44]
|  |  | Interest Rate as of |  |  |  |  |
| Debt Payment Obligations |  | September 30, 2016 |  | Rate Reset Date |  | Reset Rate |
| $15 Million Revolver |  | 2.42% |  | 01/09/2017 |  | * |
| $18 Million Revolver |  | 2.48% |  | 01/18/2017 |  | * |
| $16 Million Revolver |  | 2.70% |  | 02/13/2017 |  | * |
| $19 Million Revolver |  | 2.41% |  | 01/03/2017 |  | * |
| $48 Million Revolver |  | 2.48% |  | 11/30/2016 |  | * |

- removed (2016-11-07):
[0001511737-16-000037:note_history:45]
|  |  | Interest Rate as of |  |  |  |  |
| Debt Payment Obligations |  | March 31, 2016 |  | Rate Reset Date |  | Reset Rate |
| $15 Million Revolver |  | 2.02% |  | April 8, 2016 |  | 2.13% |
| $18 Million Revolver |  | 2.01% |  | April 18, 2016 |  | 2.13% |
| $14 Million Revolver |  | 2.02% |  | May 31, 2016 |  | * |
| $19 Million Revolver |  | 2.02% |  | April 1, 2016 |  | 2.13% |


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2016-11-07):
[0001511737-16-000045:note_history:46]
The following table summarizes our estimated debt and interest payment obligations as of September 30, 2016, for the remainder of fiscal 2017 and future fiscal years (in thousands):
  (was, 2016-05-05, similarity 0.9706):
[0001511737-16-000037:note_history:46]
The following table summarizes our estimated debt and interest payment obligations as of March 31, 2016, for the remainder of fiscal 2016 and future fiscal years (in thousands):

- added (2016-11-07):
[0001511737-16-000045:note_history:47]
|  | 2017 (remainder) |  | 2018 |  | 2019 |  | 2020 |  | Thereafter |  | Total |
| Debt payment obligations | $ | 8,750 |  |  | $ | 15,000 |  |  | $ | 15,000 |  |  | $ | 162,250 |  |  | $ | — |  |  | $ | 201,000 |  |
| Interest and other payments on debt payment obligations (1) | 3,754 |  |  | 4,712 |  |  | 4,361 |  |  | 2,781 |  |  | — |  |  | 15,608 |  |
| Total | $ | 12,504 |  |  | $ | 19,712 |  |  | $ | 19,361 |  |  | $ | 165,031 |  |  | $ | — |  |  | $ | 216,608 |  |

- changed (2016-11-07):
[0001511737-16-000045:note_history:48]
(1) - Interest payments are calculated based on the applicable rates and payment dates as of September 30, 2016. Furthermore, two to three-month payment intervals on the revolving debt have been assumed, consistent with the Company's elections to date.
  (was, 2016-05-05, similarity 0.9672):
[0001511737-16-000037:note_history:48]
(1) - Interest payments are calculated based on the applicable rates and payment dates as of March 31, 2016. Furthermore, two to three month payment intervals on the revolving debt have been assumed, consistent with the Company's elections to date.

- added (2016-11-07):
[0001511737-16-000045:note_history:49]
Our Debt consisted of the following (in thousands):

- added (2016-11-07):
[0001511737-16-000045:note_history:50]
|  | September 30, 2016 |  | June 30, 2016 |
| Term Loan - short term | $ | 12,500 |  |  | $ | 11,250 |  |
| Debt Issuance costs, net (1) | (257 | ) |  | (257 | ) |
| Total Debt - short term | 12,243 |  |  | 10,993 |  |
| Term Loan - long term | 72,500 |  |  | 76,250 |  |
| Revolver - long term | 116,000 |  |  | 116,000 |  |
| Debt issuance costs, net (1) | (621 | ) |  | (686 | ) |
| Total Debt - long term | $ | 187,879 |  |  | $ | 191,564 |  |

- added (2016-11-07):
[0001511737-16-000045:note_history:51]
(1) On July 1 2016, the Company retrospectively adopted ASU 2015-03, which requires unamortized debt issuance costs to be included as a direct deduction from the related debt liability on the balance sheet. Under previous guidance, all unamortized debt issuance costs were reported as assets on the balance sheet. See Note 2 for information on the impact of the retrospective adoption of ASU 2015-03.

- removed (2016-11-07):
[0001511737-16-000037:note_history:52]
|  | 2016 (remainder) |  | 2017 |  | 2018 |  | 2019 |  | 2020 |  | Thereafter |  | Total |
| Debt payment obligations | $ | 2,500 |  |  | $ | 11,250 |  |  | $ | 15,000 |  |  | $ | 15,000 |  |  | $ | 112,250 |  |  | $ | — |  |  | $ | 156,000 |  |
| Interest and other payments on debt (1) | 888 |  |  | 3,422 |  |  | 3,142 |  |  | 2,822 |  |  | 1,746 |  |  | — |  |  | 12,020 |  |
| Total | $ | 3,388 |  |  | $ | 14,672 |  |  | $ | 18,142 |  |  | $ | 17,822 |  |  | $ | 113,996 |  |  | $ | — |  |  | $ | 168,020 |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2016-11-07):
[0001511737-16-000045:note_history:53]
On November 13, 2013, the Company entered into an aircraft lease agreement (the “Aircraft Lease Agreement”) with RJP Manageco LLC (the “Lessor”), a limited liability company owned by the Company’s CEO, Robert J. Pera. Pursuant to the Aircraft Lease Agreement, the Company may lease an aircraft owned by the Lessor for Company business purposes. Under the Aircraft Lease Agreement, the aircraft may be leased at a rate of $5,000 per flight hour. This hourly rate does not include the cost of flight crew or on-board services, which the Company purchases from a third-party provider. The Company recognized a total of approximately $650 thousand and $213 thousand in expenses pursuant to the Aircraft Lease Agreement during the three months ended September 30, 2016 and 2015, respectively.  All expenses pursuant to the Aircraft Lease Agreement have been included in the Company’s sales, general and administrative expenses in the Consolidated Statements of Operations.
  (was, 2016-05-05, similarity 0.6898):
[0001511737-16-000037:note_history:53]
On November 13, 2013, the Company entered into an aircraft lease agreement (the “Aircraft Lease Agreement”) with RJP Manageco LLC (the “Lessor”), a limited liability company owned by the Company’s CEO, Robert J. Pera. Pursuant to the Aircraft Lease Agreement, the Company may lease an aircraft owned by the Lessor for Company business purposes. Under the Aircraft Lease Agreement, the aircraft may be leased at a rate of $5,000 per flight hour. This hourly rate does not include the cost of flight crew or on-board services, which the Company purchases from a third-party provider. The Company recognized a total of approximately $373 thousand and $980 thousand in expenses pursuant to the Aircraft Lease Agreement during the three and nine months ended March 31, 2016, respectively.  In comparison, the Company recognized a total of approximately $150 thousand and $330 thousand in expenses pursuant to the Aircraft Lease Agreement during the three and nine months ended March 31, 2015, respectively. All expenses pursuant to the Aircraft Lease Agreement have been included in the Company’s sales, general and administrative expenses in the Condensed Consolidated Statements of Operations.
