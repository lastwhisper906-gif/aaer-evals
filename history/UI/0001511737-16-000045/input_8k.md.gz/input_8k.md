# UI 8-K — 0001415889-16-007334 filed 2016-11-03

## item codes, every 8-K on or before 2016-11-07

- 2016-11-03 0001415889-16-007334 — 2.02, 9.01
- 2016-08-17 0001415889-16-006877 — 8.01
- 2016-08-10 0001415889-16-006753 — 5.02
- 2016-08-04 0001415889-16-006679 — 2.02, 8.01, 9.01
- 2016-05-05 0001415889-16-005749 — 2.02, 5.02, 8.01, 9.01
- 2016-02-04 0001415889-16-004613 — 2.02, 9.01
- 2015-12-18 0001415889-15-004120 — 3.01, 5.07
- 2015-11-05 0001415889-15-003599 — 2.02, 8.01, 9.01
- 2015-10-16 0001415889-15-003433 — 5.02
- 2015-08-06 0001571049-15-006288 — 2.02, 5.02, 8.01, 9.01
- 2015-05-07 0001511737-15-000016 — 2.02, 9.01
- 2015-04-23 0001415889-15-001433 — 2.02, 5.02, 9.01
- 2015-03-06 0001415889-15-000787 — 1.01, 1.02, 2.03, 9.01
- 2015-02-05 0001511737-15-000008 — 2.02, 9.01
- 2014-12-18 0001193125-14-446627 — 5.07
- 2014-11-06 0001511737-14-000029 — 2.02, 9.01
- 2014-09-30 0001193125-14-359060 — 7.01, 9.01
- 2014-08-07 0001511737-14-000021 — 2.02, 9.01
- 2014-05-08 0001511737-14-000016 — 2.02, 9.01
- 2014-04-17 0001193125-14-146710 — 7.01
- 2014-03-06 0001193125-14-084883 — 8.01
- 2014-02-06 0001511737-14-000005 — 2.02, 9.01
- 2013-12-16 0001193125-13-474388 — 5.07
- 2013-11-22 0001193125-13-451511 — 5.02
- 2013-11-07 0001511737-13-000018 — 2.02, 9.01
- 2013-10-28 0001193125-13-413414 — 5.02, 9.01
- 2013-10-18 0001193125-13-404111 — 5.02, 9.01
- 2013-08-08 0001511737-13-000009 — 2.02, 9.01
- 2013-05-09 0001511737-13-000004 — 2.02
- 2013-03-25 0001193125-13-124353 — 5.07
- 2013-03-08 0001193125-13-098334 — 5.02, 9.01
- 2013-02-07 0001193125-13-043701 — 2.02, 9.01
- 2012-12-28 0001193125-12-518487 — 1.01
- 2012-12-17 0001193125-12-503742 — 7.01, 9.01
- 2012-12-13 0001193125-12-501894 — 5.02
- 2012-11-16 0001193125-12-474083 — 5.02
- 2012-11-13 0001193125-12-467376 — 5.02
- 2012-11-08 0001193125-12-460665 — 2.02, 9.01
- 2012-10-10 0001193125-12-420015 — 5.02, 9.01
- 2012-08-13 0001193125-12-352624 — 1.01, 2.03, 9.01
- 2012-08-09 0001193125-12-347776 — 1.01, 9.01
- 2012-08-09 0001193125-12-347732 — 2.02, 9.01
- 2012-05-01 0001193125-12-201012 — 2.02, 9.01
- 2012-03-30 0001193125-12-144074 — 5.02
- 2012-03-27 0001193125-12-134395 — 5.02, 9.01
- 2012-03-22 0001193125-12-127536 — 5.02
- 2012-01-31 0001193125-12-032079 — 2.02, 9.01
- 2011-12-27 0001193125-11-353002 — 1.01, 9.01
- 2011-12-06 0001193125-11-332192 — 5.02
- 2011-11-10 0001193125-11-306969 — 2.02, 9.01

## late-filing notifications on or before 2016-11-07

- none on or before 2016-11-07

## item 2.02 — earnings release, exhibit 99.1

[0001415889-16-007334:8k_2_02:1]
EX-99
2
ex99-11032016_011105.htm

[0001415889-16-007334:8k_2_02:2]
ubnt991.htm

[0001415889-16-007334:8k_2_02:3]
Exhibit 99.1

[0001415889-16-007334:8k_2_02:4]
UBIQUITI NETWORKS REPORTS PRELIMINARY FIRST QUARTER FISCAL 2017 FINANCIAL RESULTS

[0001415889-16-007334:8k_2_02:5]
~ Achieves Record Revenue and Earnings ~

[0001415889-16-007334:8k_2_02:6]
SAN JOSE, Calif. – November 3, 2016 - Ubiquiti Networks, Inc. (NASDAQ:UBNT) (“Ubiquiti” or the “Company”) today announced results for the first fiscal quarter of 2017, ended September 30, 2016.

[0001415889-16-007334:8k_2_02:7]
First Quarter Fiscal 2017 Financial Summary

[0001415889-16-007334:8k_2_02:8]
|  | • | Revenues of $204.8 million |

[0001415889-16-007334:8k_2_02:9]
|  | • | GAAP gross profit of $98.3 million and non-GAAP gross profit of $98.4 million |

[0001415889-16-007334:8k_2_02:10]
|  | • | GAAP net income of $71.8 million and non-GAAP net income of $65.5 million |

[0001415889-16-007334:8k_2_02:11]
|  | • | GAAP diluted EPS of $0.86 and non-GAAP diluted EPS of $0.79 |

[0001415889-16-007334:8k_2_02:12]
|  | • | Cash of $573.6 million, up 32% year-over-year |

[0001415889-16-007334:8k_2_02:13]
Recent Financial Highlights

[0001415889-16-007334:8k_2_02:14]
|  | • | Revenues increased 35% year-over-year and 10% sequentially, as a result of strong demand worldwide across all of our product lines. |

[0001415889-16-007334:8k_2_02:15]
|  | • | Enterprise Technology revenues increased 75% year-over-year and 10% sequentially, fueled by the UniFi product family and other industry-leading products targeting the Enterprise market. |

[0001415889-16-007334:8k_2_02:16]
|  | • | Service Provider Technology revenues increased 17% year-over-year and 11% sequentially, fueled by the airMAX product family and EdgeMAX product lines. |

[0001415889-16-007334:8k_2_02:17]
|  | • | Non-GAAP diluted EPS increased 55% year-over-year and 14% sequentially, demonstrating the continued scalability of Ubiquiti’s unique business model. |

[0001415889-16-007334:8k_2_02:18]
Recent Product Highlights

[0001415889-16-007334:8k_2_02:19]
|  | • | Announced a retail partnership with Amazon, focusing on our popular AmpliFi HD router and AmpliFi Mesh Points from Ubiquiti Labs. |

[0001415889-16-007334:8k_2_02:20]
|  | • | Experienced strong demand for our UniFi Switch products, and an expansion of this product line to include new UniFi Switch 24-Port and 48-Port models. |

[0001415889-16-007334:8k_2_02:21]
|  | • | Launched UniFi Mesh technology, a powerful multi-hop, self-healing mesh product line that expands the application of UniFi's industry leading software-defined-networking platform into wide-area Wi-Fi deployments. |

[0001415889-16-007334:8k_2_02:22]
|  | • | Announced EdgePower, which provides reliable DC power to the EdgePoint EP-R8 and EP-S16 devices and their attached PoE devices. |

[0001415889-16-007334:8k_2_02:23]
|  | • | Experienced strong demand for our UniFi Video products, our plug and play, high-performance IP surveillance devices that scale easily across multiple locations. |

[0001415889-16-007334:8k_2_02:24]
Financial Results Summary ($, in millions, except per share data)

[0001415889-16-007334:8k_2_02:25]
| Income statement highlights |  | F1Q17 |  |  | F4Q16 |  |  | F1Q16 |  |
| Revenues |  | 204.8 |  |  | 185.7 |  |  | 151.4 |  |
| Service Provider Technology |  | 120.6 |  |  | 109.0 |  |  | 103.4 |  |
| Enterprise Technology |  | 84.1 |  |  | 76.7 |  |  | 48.0 |  |
| Gross Profit |  | 98.3 |  |  | 89.8 |  |  | 73.5 |  |
| Gross Profit (%) |  | 48.0% |  |  | 48.3% |  |  | 48.5% |  |
| Total Operating Expenses |  | 23.4 |  |  | 24.1 |  |  | 13.7 |  |
| Income from Operations |  | 74.9 |  |  | 65.6 |  |  | 59.8 |  |
| GAAP Net Income |  | 71.8 |  |  | 57.7 |  |  | 53.8 |  |
| GAAP EPS (diluted) |  | 0.86 |  |  | 0.69 |  |  | 0.61 |  |
| Non-GAAP Net Income |  | 65.5 |  |  | 58.2 |  |  | 45.5 |  |
| Non-GAAP EPS (diluted) |  | 0.79 |  |  | 0.69 |  |  | 0.51 |  |

[0001415889-16-007334:8k_2_02:26]
Balance Sheet Highlights

[0001415889-16-007334:8k_2_02:27]
Total cash and cash equivalents as of September 30, 2016 were $573.6 million, compared with $551.0 million as of June 30, 2016.  We held $530.2 million of our $573.6 million of cash and cash equivalents in accounts of our subsidiaries outside of the United States.

[0001415889-16-007334:8k_2_02:28]
This quarter we saw days sales outstanding in accounts receivable ("DSO") of 43 days, compared with 41 days in the prior quarter and 39 days in the first quarter of fiscal 2016.

[0001415889-16-007334:8k_2_02:29]
We are committed to keeping our inventory optimized and in-line with end market demand.  During the first quarter of fiscal 2017 we invested heavily in inventory.  Our inventory balance at the end of the quarter was $79.8 million, up from $57.1 million in the prior quarter.  We have increased our inventory balance to compensate for reduced inventory in our distribution channel and to reduce our lead times.  We expect to hold 7 to 9 weeks of previously introduced product inventory in our warehouses going forward.

[0001415889-16-007334:8k_2_02:30]
Business Outlook

[0001415889-16-007334:8k_2_02:31]
Based on recent business trends, Ubiquiti currently believes the demand environment in its end markets supports the following forecast for the Company's second fiscal quarter ending December 31, 2016.  The following are Ubiquiti’s financial performance estimates for the second quarter of fiscal 2017:

[0001415889-16-007334:8k_2_02:32]
|  | • | Revenues between $200 million and $210 million |

[0001415889-16-007334:8k_2_02:33]
|  | • | GAAP diluted EPS of $0.72 - $0.78 |

[0001415889-16-007334:8k_2_02:34]
|  | • | Non-GAAP diluted EPS of $0.73 - $0.79 |

[0001415889-16-007334:8k_2_02:35]
Conference Call Information

[0001415889-16-007334:8k_2_02:36]
Ubiquiti Networks will host a Q&A-only call to discuss the Company’s financial results at 2:00 p.m. Pacific Time today.  Management’s prepared remarks can be found on the Investor Relations section of the Ubiquiti Networks website, http://ir.ubnt.com/results.cfm.

[0001415889-16-007334:8k_2_02:37]
To listen to the Q&A call via telephone, dial (877) 291-1296 (U.S. toll-free) or (720) 259-9209 (International) to be connected to the call by an operator.  The conference ID number is 91377240.  Participants should dial in at least 10 minutes prior to the start of the call.  Investors may also listen to a live webcast of the Q&A conference call by visiting the Investor Relations section of the Ubiquiti Networks website at http://ir.ubnt.com.

[0001415889-16-007334:8k_2_02:38]
A recording of the Q&A call will be available approximately two hours after the call concludes and will be accessible on the Investor Relations section of the Ubiquiti Networks website, http://ir.ubnt.com.

[0001415889-16-007334:8k_2_02:39]
About Ubiquiti Networks

[0001415889-16-007334:8k_2_02:40]
Ubiquiti Networks (Nasdaq:UBNT) is closing the digital divide by building network communication platforms for everyone and everywhere.  With over 38 million devices sold worldwide, Ubiquiti is transforming under-networked enterprises and communities.  Our leading edge platforms, airMAX®, UniFi®, airFiber®, UniFi® Video, mFi® and EdgeMAX®, combine innovative technology, disruptive price-to-performance and the support of a global user community to eliminate barriers to connectivity.  For more information, join our community at http://www.ubnt.com.

[0001415889-16-007334:8k_2_02:41]
Ubiquiti, Ubiquiti Networks, the U logo, UBNT, airMAX, UniFi, airFiber, mFi, EdgeMAX and sunMAX are registered trademarks or trademarks of Ubiquiti Networks, Inc. in the United States and other countries.

[0001415889-16-007334:8k_2_02:42]
Investor Relations Contact

[0001415889-16-007334:8k_2_02:43]
Anne Fazioli

[0001415889-16-007334:8k_2_02:44]
Ubiquiti Networks, Vice President of Investor Relations

[0001415889-16-007334:8k_2_02:45]
IR@ubnt.com

[0001415889-16-007334:8k_2_02:46]
Forward-looking statements are subject to certain risks and uncertainties that could cause our actual future results to differ materially, or cause a material adverse impact on our results.  Potential risks and uncertainties include, but are not limited to, fluctuations in our operating results; varying demand for our products due to the financial and operating condition of our distributors and their customers, and distributors' inventory management practices; political and economic conditions and volatility affecting the stability of business environments, economic growth, currency values, commodity prices and other factors that may influence the ultimate demand for our products in particular geographies or globally; impact of counterfeiting and our ability to contain such impact; our reliance on a limited number of distributors; inability of our contract manufacturers and suppliers to meet our demand; our dependence on Qualcomm Atheros for chipsets without a short-term alternative; as we move into new markets competition from certain of our current or potential competitors who may be more established in such markets; our ability to keep pace with technological and market developments; success and timing of new product introductions by us and the performance of our products generally; our ability to effectively manage the significant increase in our transactional sales volumes; we may become subject to warranty claims, product liability and product recalls; that a substantial majority of our sales are into countries outside the United States and we are subject to numerous U.S. export control and economic sanctions laws; costs related to responding to government inquiries related to regulatory compliance; our reliance on the Ubiquiti Community; our reliance on certain key members of our management team, including our founder and chief executive officer, Robert J. Pera; adverse tax-related matters such as tax audits, changes in our effective tax rate or new tax legislative proposals; whether the final determination of our income tax liability may be materially different from our income tax provisions; the impact of any intellectual property litigation and claims for indemnification; litigation related to U.S. Securities laws; and economic and political conditions in the United States and abroad.  We discuss these risks in greater detail under the heading “Risk Factors” and elsewhere in our Annual Report on Form 10-K for the year ended June 30, 2016, and subsequent filings filed with the U.S. Securities and Exchange Commission (the “SEC”), which are available at the SEC's website at www.sec.gov.  Copies may also be obtained by contacting the Ubiquiti Networks Investor Relations Department, by email at IR@ubnt.com or by visiting the Investor Relations section of the Ubiquiti Networks website, http://ir.ubnt.com.

[0001415889-16-007334:8k_2_02:47]
Given these uncertainties, you should not place undue reliance on these forward-looking statements.  Also, forward-looking statements represent our management's beliefs and assumptions only as of the date made.  Except as required by law, Ubiquiti Networks undertakes no obligation to update information contained herein.  You should review our SEC filings carefully and with the understanding that our actual future results may be materially different from what we expect.

[0001415889-16-007334:8k_2_02:48]
Use of Non-GAAP Financial Information

[0001415889-16-007334:8k_2_02:49]
To supplement our condensed consolidated financial results prepared under generally accepted accounting principles, or GAAP, we use non-GAAP measures of net income and earnings per diluted share that are adjusted to exclude certain costs, expenses and gains such as stock based compensation expense, Business e-mail compromise ("BEC") fraud loss/(recovery), implementation of overhead capitalization, the adoption of ASU 2016-09 Improvements to Employee Share-Based Payments Accounting and the tax effects of these non-GAAP adjustments.  Reconciliations of the adjustments to GAAP results for the three months ended September 30, 2016 and 2015 are provided below.  In addition, an explanation of the ways in which management uses non-GAAP financial information to evaluate its business, the substance behind management's decision to use this non-GAAP financial information, material limitations associated with the use of non-GAAP financial information, the manner in which management compensates for those limitations, and the substantive reasons management believes that this non-GAAP financial information provides useful information to investors is included under "About our Non-GAAP Net Income and Adjustments" after the tables below.

[0001415889-16-007334:8k_2_02:50]
Ubiquiti Networks Inc.

[0001415889-16-007334:8k_2_02:51]
Consolidated Statement of Operations

[0001415889-16-007334:8k_2_02:52]
(In thousands, except per share data)

[0001415889-16-007334:8k_2_02:53]
(Unaudited)

[0001415889-16-007334:8k_2_02:54]
|  |  | Three Months Ended September 30, |
|  |  | 2016 |  | 2015 |
| Revenues |  | $ | 204,757 |  |  | $ | 151,415 |  |
| Cost of revenues |  | 106,453 |  |  | 77,911 |  |
| Gross profit |  | 98,304 |  |  | 73,504 |  |
| Operating expenses: |  |  |  |  |
| Research and development |  | 14,539 |  |  | 13,561 |  |
| Sales, general and administrative |  | 8,863 |  |  | 8,142 |  |
| Business e-mail compromise ("BEC") fraud loss/(recovery) |  | — |  |  | (8,034 | ) |
| Total operating expenses |  | 23,402 |  |  | 13,669 |  |
| Income from operations |  | 74,902 |  |  | 59,835 |  |
| Interest expense and other, net |  | (1,099 | ) |  | (116 | ) |
| Income before provision for income taxes |  | 73,803 |  |  | 59,719 |  |
| Provision for income taxes |  | 2,015 |  |  | 5,960 |  |
| Net income and comprehensive income |  | $ | 71,788 |  |  | $ | 53,759 |  |
| Net income per share of common stock: |  |  |  |  |
| Basic |  | $ | 0.88 |  |  | $ | 0.62 |  |
| Diluted |  | $ | 0.86 |  |  | $ | 0.61 |  |
| Weighted average shares used in computing net income per share of common stock: |  |  |  |  |
| Basic |  | 81,812 |  |  | 87,062 |  |
| Diluted |  | 83,854 |  |  | 88,465 |  |

[0001415889-16-007334:8k_2_02:55]
Ubiquiti Networks Inc.

[0001415889-16-007334:8k_2_02:56]
Reconciliation of GAAP Net Income to Non-GAAP Net Income

[0001415889-16-007334:8k_2_02:57]
(In thousands, except per share data)

[0001415889-16-007334:8k_2_02:58]
(Unaudited)

[0001415889-16-007334:8k_2_02:59]
|  |  | Three Months Ended September 30, |
|  |  | 2016 |  |  | 2015 |
| Net income |  | $ | 71,788 |  |  | $ | 53,759 |  |
| Stock-based compensation: |  |  |  |  |  |
| Cost of revenues |  |  | 144 |  |  |  | 113 |  |
| Research and development |  |  | 560 |  |  |  | 624 |  |
| Sales, general and administrative |  |  | 223 |  |  |  | 290 |  |
| Business e-mail compromise ("BEC") fraud loss/(recovery) |  |  | — |  |  |  | (8,034 | ) |
| Excess tax benefits resulting from the adoption of ASU 2016-09 Stock Compensation |  |  | (6,820 | ) |  |  | — |  |
| Implementation of overhead capitalization |  |  | — |  |  |  | (944 | ) |
| Tax effect of non-GAAP adjustments |  |  | (371 | ) |  |  | (297 | ) |
| Non-GAAP net income |  | $ | 65,524 |  |  | $ | 45,511 |  |
| Non-GAAP diluted EPS |  | $ | 0.79 |  |  | $ | 0.51 |  |
| Shares outstanding (Diluted) |  |  | 83,854 |  |  |  | 88,465 |  |
| Share adjustment (ASU 2016-09 Adoption) |  |  | (774 | ) |  |  | — |  |
| Weighted-average shares used in non-GAAP diluted EPS |  |  | 83,080 |  |  |  | 88,465 |  |

[0001415889-16-007334:8k_2_02:60]
Ubiquiti Networks Inc.

[0001415889-16-007334:8k_2_02:61]
Consolidated Balance Sheets

[0001415889-16-007334:8k_2_02:62]
(In thousands, except share amounts)

[0001415889-16-007334:8k_2_02:63]
(Unaudited)

[0001415889-16-007334:8k_2_02:64]
|  |  | September 30, |  |  | June 30, (1) |  |
| Assets |  | 2016 |  |  | 2016 |  |
| Current assets: |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 573,644 |  |  | $ | 551,031 |  |
| Accounts receivable, net |  |  | 95,728 |  |  |  | 82,790 |  |
| Inventories |  |  | 79,841 |  |  |  | 57,113 |  |
| Vendor Deposits |  |  | 30,088 |  |  |  | 30,255 |  |
| Prepaid income taxes |  |  | 314 |  |  |  | 299 |  |
| Prepaid expenses and other current assets |  |  | 5,987 |  |  |  | 6,896 |  |
| Total current assets |  |  | 785,602 |  |  |  | 728,384 |  |
| Property and equipment, net |  |  | 12,520 |  |  |  | 12,953 |  |
| Long-term deferred tax assets |  |  | 4,195 |  |  |  | 4,195 |  |
| Other long–term assets |  |  | 1,656 |  |  |  | 1,576 |  |
| Total assets |  | $ | 803,973 |  |  | $ | 747,108 |  |
| Liabilities and Stockholders’ Equity |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Accounts payable |  | $ | 42,540 |  |  | $ | 51,510 |  |
| Income taxes payable |  |  | 2,038 |  |  |  | 1,488 |  |
| Debt - short-term |  |  | 12,243 |  |  |  | 10,993 |  |
| Other current liabilities |  |  | 20,300 |  |  |  | 26,672 |  |
| Total current liabilities |  |  | 77,121 |  |  |  | 90,663 |  |
| Long-term taxes payable |  |  | 24,494 |  |  |  | 23,202 |  |
| Debt - long-term |  |  | 187,879 |  |  |  | 191,564 |  |
| Deferred revenues - long-term |  |  | 1,498 |  |  |  | 1,303 |  |
| Total liabilities |  |  | 290,992 |  |  |  | 306,732 |  |

[0001415889-16-007334:8k_2_02:65]
Stockholders’ equity:

[0001415889-16-007334:8k_2_02:66]
| Common stock |  | 82 |  |  | 82 |  |
| Additional paid–in capital |  | 817 |  |  | — |  |
| Retained earnings |  | 512,082 |  |  | 440,294 |  |
| Total stockholders’ equity |  | 512,981 |  |  | 440,376 |  |
| Total liabilities and stockholders’ equity |  | $ | 803,973 |  |  | $ | 747,108 |  |

[0001415889-16-007334:8k_2_02:67]
|  | (1) | Derived from audited consolidated statements as of June 30, 2016. |

[0001415889-16-007334:8k_2_02:68]
Ubiquiti Networks Inc.

[0001415889-16-007334:8k_2_02:69]
Revenues by Product Type (In thousands)

[0001415889-16-007334:8k_2_02:70]
(Unaudited)

[0001415889-16-007334:8k_2_02:71]
|  |  | Three Months Ended September 30, |
|  |  | 2016 |  |  | 2015 |
| Service provider technology |  | $ | 120,632 |  |  | $ | 103,399 |  |
| Enterprise technology |  |  | 84,125 |  |  |  | 48,016 |  |
| Total revenues |  | $ | 204,757 |  |  | $ | 151,415 |  |

[0001415889-16-007334:8k_2_02:72]
Ubiquiti Networks Inc.

[0001415889-16-007334:8k_2_02:73]
Revenues by Region (In thousands)

[0001415889-16-007334:8k_2_02:74]
(Unaudited)

[0001415889-16-007334:8k_2_02:75]
|  |  | Three Months Ended September 30, |  |
|  |  | 2016 |  |  | 2015 |  |
| North America |  | $ | 74,165 |  |  | $ | 53,234 |  |
| South America |  |  | 24,184 |  |  |  | 22,148 |  |
| Europe, the Middle East and Africa (EMEA) |  |  | 81,375 |  |  |  | 60,503 |  |
| Asia Pacific |  |  | 25,033 |  |  |  | 15,530 |  |
| Total revenues |  | $ | 204,757 |  |  | $ | 151,415 |  |

[0001415889-16-007334:8k_2_02:76]
About our Non-GAAP Net Income and Adjustments

[0001415889-16-007334:8k_2_02:77]
Use of Non-GAAP Financial Information

[0001415889-16-007334:8k_2_02:78]
To supplement our condensed consolidated financial results prepared under generally accepted accounting principles, or GAAP, we use non-GAAP measures of net income and earnings per diluted share that are GAAP net income and GAAP earnings per diluted share adjusted to exclude certain costs, expenses and gains/losses.

[0001415889-16-007334:8k_2_02:79]
We believe that the presentation of non-GAAP net income and non-GAAP earnings per diluted share provides important supplemental information regarding non-cash expenses, significant items that we believe are important to understanding our financial, and business trends relating to our financial condition and results of operations.  Non-GAAP net income and non-GAAP earnings per diluted share are among the primary indicators used by management as a basis for planning and forecasting future periods and by management and our board of directors to determine whether our operating performance has met specified targets and thresholds.  Management uses non-GAAP net income and non-GAAP earnings per diluted share when evaluating operating performance because it believes that the exclusion of the items described below, for which the amounts or timing may vary significantly depending upon the Company's activities and other factors, facilitates comparability of the Company's operating performance from period to period.  We have chosen to provide this information to investors so they can analyze our operating results in the same way that management does and use this information in their assessment of our business and the valuation of our Company.

[0001415889-16-007334:8k_2_02:80]
Use and Economic Substance of Non-GAAP Financial Measures used by Ubiquiti Networks

[0001415889-16-007334:8k_2_02:81]
We compute non-GAAP net income and non-GAAP diluted earnings per share by adjusting GAAP net income and GAAP earnings per diluted share to remove the impact of certain adjustments and the tax effect of those adjustments.  Items excluded from net income are:

[0001415889-16-007334:8k_2_02:82]
|  | • | Stock-based compensation expense |

[0001415889-16-007334:8k_2_02:83]
|  | • | Business e-mail compromise ("BEC") fraud loss/(recovery) |

[0001415889-16-007334:8k_2_02:84]
|  | • | Implementation of overhead capitalization |

[0001415889-16-007334:8k_2_02:85]
|  | • | Adoption of ASU 2016-09 Improvements to Employee Share-Base Payment Accounting |

[0001415889-16-007334:8k_2_02:86]
|  | • | Tax effect of non-GAAP adjustments, applying the principles of ASC 740 |

[0001415889-16-007334:8k_2_02:87]
Usefulness of Non-GAAP Financial Information to Investors

[0001415889-16-007334:8k_2_02:88]
These non-GAAP measures are not in accordance with, or an alternative to, GAAP and may be materially different from other non-GAAP measures, including similarly titled non-GAAP measures used by other companies.  The presentation of this additional information should not be considered in isolation from, as a substitute for, or superior to, net income or earnings per diluted share prepared in accordance with GAAP.  Non-GAAP financial measures have limitations in that they do not reflect certain items that may have a material impact upon our reported financial results.  We expect to continue to incur expenses of a nature similar to the non-GAAP adjustments described above, and exclusion of these items from our non-GAAP net income and non-GAAP earnings per diluted share should not be construed as an inference that these costs are unusual, infrequent or non-recurring.

[0001415889-16-007334:8k_2_02:89]
For more information on the non-GAAP adjustments, please see the table captioned “Reconciliation of GAAP Net Income to Non-GAAP Net Income” included in this press release.
