# UI notes — 0001511737-14-000018


## us-gaap:BusinessDescriptionAndBasisOfPresentationTextBlock

[0001511737-14-000018:notes:1]
[same as prior period, unchanged from 0001511737-14-000009:notes:1]

[0001511737-14-000018:notes:2]
[same as prior period, unchanged from 0001511737-14-000009:notes:2]

[0001511737-14-000018:notes:3]
[same as prior period, unchanged from 0001511737-14-000009:notes:3]

[0001511737-14-000018:notes:4]
On October 13, 2011, the Company entered into an underwriting agreement for its initial public offering of 7,038,230 shares of its common stock at $15.00 per share.  The Company's initial public offering closed on October 19, 2011. Immediately prior to the closing of the initial public offering, all outstanding shares of the Company’s preferred stock converted to common stock on a one for one basis.

[0001511737-14-000018:notes:5]
[same as prior period, unchanged from 0001511737-14-000009:notes:5]

[0001511737-14-000018:notes:6]
[same as prior period, unchanged from 0001511737-14-000009:notes:6]

[0001511737-14-000018:notes:7]
[same as prior period, unchanged from 0001511737-14-000009:notes:7]

[0001511737-14-000018:notes:8]
These condensed consolidated financial statements should be read in conjunction with the Company’s audited consolidated financial statements for the fiscal year ended June 30, 2013 included in its Annual Report on Form 10-K, as filed on September 13, 2013 with the SEC (the “Annual Report”). The results of operations for the three and nine months ended March 31, 2014 are not necessarily indicative of the results to be expected for any future periods.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001511737-14-000018:notes:9]
COMMITMENTS AND CONTINGENCIES

[0001511737-14-000018:notes:10]
Operating Leases

[0001511737-14-000018:notes:11]
Certain facilities and equipment are leased under non-cancelable operating leases. The Company generally pays taxes, insurance and maintenance costs on leased facilities and equipment. The Company leases office space in San Jose, California and other locations under various non-cancelable operating leases that expire at various dates through fiscal 2019.

[0001511737-14-000018:notes:12]
At March 31, 2014, future minimum annual payments under operating leases for the remainder of fiscal 2014 and future fiscal years are as follows (in thousands):

[0001511737-14-000018:notes:13]
|  | 2014(remainder) |  | 2015 |  | 2016 |  | 2017 |  | 2018 |  | Thereafter |  | Total |
| Operating leases | $ | 633 |  |  | $ | 2,503 |  |  | $ | 2,497 |  |  | $ | 1,537 |  |  | $ | 297 |  |  | $ | 53 |  |  | $ | 7,520 |  |

[0001511737-14-000018:notes:14]
Purchase Commitments

[0001511737-14-000018:notes:15]
The Company subcontracts with other companies to manufacture its products. During the normal course of business, the Company’s contract manufacturers procure components based upon orders placed by the Company. If the Company cancels all or part of the orders, it may still be liable to the contract manufacturers for the cost of the components purchased by them to manufacture the Company’s products. The Company periodically reviews the potential liability and to date no significant accruals have been recorded.  The Company had $20.9 million in non-cancelable purchase commitments as of March 31, 2014, the related expenses of which are expected to be incurred in future periods.  The Company did not have any non-cancelable purchase commitments as of June 30, 2013.

[0001511737-14-000018:notes:16]
Indemnification Obligations

[0001511737-14-000018:notes:17]
The Company enters into standard indemnification agreements with many of its business partners in the ordinary course of business. These agreements include provisions for indemnifying the business partner against any claim brought by a third party to the extent any such claim alleges that a Ubiquiti product infringes a patent, copyright or trademark, or violates any other proprietary rights of that third party. The maximum potential amount of future payments the Company could be required to make under these indemnification agreements is not estimable and the Company has not incurred any material costs to defend lawsuits or settle claims related to these indemnification agreements to date.

[0001511737-14-000018:notes:18]
Legal Matters

[0001511737-14-000018:notes:19]
The Company may be involved, from time to time, in a variety of claims, lawsuits, investigations, and proceedings relating to contractual disputes, intellectual property rights, employment matters, regulatory compliance matters and other litigation matters relating to various claims that arise in the normal course of business. The Company determines whether an estimated loss from a contingency should be accrued by assessing whether a loss is deemed probable and can be reasonably estimated. The Company assesses its potential liability by analyzing specific litigation and regulatory matters using available information. The Company develops its views on estimated losses in consultation with inside and outside counsel, which involves a subjective analysis of potential results and outcomes, assuming various combinations of appropriate litigation and settlement strategies. Taking all of the above factors into account, the Company records an amount where it is probable that the Company will incur a loss and where that loss can be reasonably estimated. However, the Company’s estimates may be incorrect and the Company could ultimately incur more or less than the amounts initially recorded.  The Company may also incur significant legal fees, which are expensed as incurred, in defending against these claims.

[0001511737-14-000018:notes:20]
Export Compliance Matters

[0001511737-14-000018:notes:21]
In May 2011, the Company filed a self-disclosure statement with the U.S. Commerce Department, Bureau of Industry and Security’s (“BIS”) Office of Export Enforcement (“OEE”) relating to a review conducted by the Company regarding certain export transactions from 2008 through March 2011 in which products may have been later resold into Iran by third parties. In June 2011, the Company also filed a self-disclosure statement with the U.S. Department of the Treasury’s Office of Foreign Asset Control (“OFAC”) regarding these compliance issues. In August 2011, the Company received a warning letter from OEE stating that OEE had not referred the findings of the Company’s review for criminal or administrative prosecution and closed the investigation of the Company without penalty. Based upon its review of the matter, OFAC identified certain apparent violations (“Apparent Violations”) of the Iranian Transactions and Sanctions Regulations by the Company during the period of in or about March 2008 through in or about February 2011. On March 4, 2014, the Company entered into a settlement agreement with OFAC resolving this administrative matter. Pursuant to the terms of the settlement agreement, the Company agreed to make a one-time payment to the U.S. Department of the Treasury in the amount of $504,000 in consideration of OFAC agreeing to release and forever discharge the Company from any and all civil liability in connection with the Apparent Violations. The Company previously accrued a reserve of $1.6 million relating to this matter in fiscal 2010 and, accordingly, reversed the excess of the accrual of $1.1 million as of the effective date of the settlement agreement.

[0001511737-14-000018:notes:22]
Shareholder Class Action Lawsuits

[0001511737-14-000018:notes:23]
Beginning on September 7, 2012, two class action lawsuits were filed in the United States District Court for the Northern District of California against Ubiquiti Networks, Inc. (the “Company”), certain of its officers and directors, and the underwriters of its initial public offering, alleging claims under U.S. securities laws. On January 30, 2013, the plaintiffs filed an amended consolidated complaint. The Company filed a motion to dismiss the complaint, and on March 26, 2014, the court issued an order granting the motion to dismiss with leave to amend the complaint. Following the plaintiffs’ decision not to file an amended complaint, on April 16, 2014 the court ordered the dismissal of the shareholder class action lawsuit with prejudice, and entered judgment in favor of the Company and the other defendants, and against the plaintiffs. The plaintiffs may appeal the court’s decision.


## us-gaap:DebtDisclosureTextBlock

[0001511737-14-000018:notes:24]
DEBT

[0001511737-14-000018:notes:25]
On August 7, 2012, the Company entered into a Loan and Security Agreement (the “Loan Agreement”) with U.S. Bank, as syndication agent, and East West Bank, as administrative agent for the lenders party to the Loan Agreement.  The Loan Agreement provides for (i) a $50.0 million revolving credit facility, with a $5.0 million sublimit for the issuance of letters of credit and a $5.0 million sublimit for the making of swingline loan advances (the “Revolving Credit Facility”), and (ii) a $50.0 million term loan facility (the “Term Loan Facility”). The Company may request borrowings under the Revolving Credit Facility until August 7, 2015.  The Loan Agreement replaced a previous agreement whereby the Company had an existing term loan balance of $29.2 million as of the date the new Loan Agreement.  On August 7, 2012, the Company borrowed $20.8 million under the Term Loan Facility, and no borrowings remain available for borrowing thereunder.  On November 21, 2012, the Company borrowed $10.0 million under the Revolving Credit Facility. On December 20, 2012, the Company borrowed an additional $20.0 million under the Revolving Credit Facility, and $20.0 million remains available for borrowing thereunder.

[0001511737-14-000018:notes:26]
The loans bear interest, at the Company’s option, at the base rate plus a spread of 1.25% to 1.75% or an adjusted LIBOR rate (at the Company’s election, for a period of 30, 60, or 90 days) plus a spread of 2.25% to 2.75%, in each case with such spread being determined based on the debt service coverage ratio for its most recently ended fiscal quarter. The base rate is the highest of (i) East West Bank’s prime rate, (ii) the federal funds rate plus a margin equal to 0.50%, or (iii) the LIBOR rate plus a margin equal to 1.00%. The Company is also obligated to pay other customary closing fees, arrangement fees, administration fees, commitment fees and letter of credit fees for a credit facility of this size and type.

[0001511737-14-000018:notes:27]
Interest is due and payable monthly in arrears in the case of loans bearing interest at the base rate and at the end of an interest period in the case of loans bearing interest at the adjusted LIBOR rate. Principal payments under the Term Loan Facility will be made in quarterly installments on the first day of each calendar quarter, and each such quarterly installment shall be equal to $1.25 million through July 1, 2014, then equal to $1.875 million from October 1, 2014 through July 1, 2015, and then equal to $2.5 million from October 1, 2015 through July 1, 2017, with the remaining outstanding principal balance and all accrued and unpaid interest due on August 7, 2017. All outstanding loans under the Revolving Credit Facility, together with all accrued and unpaid interest, are due on August 7, 2015.

[0001511737-14-000018:notes:28]
The Company may prepay the loans, in whole or in part, at any time without premium or penalty, subject to certain conditions including minimum amounts and reimbursement of certain costs in the case of prepayments of LIBOR loans. In addition, the Company is required to prepay the loan under the Term Loan Facility with (i) the proceeds from certain financing transactions or asset sales (subject, in the case of asset sales, to reinvestment rights) and (ii) 25.0% of the Company’s excess cash flow in the U.S., as determined after each fiscal year and in accordance with the Loan Agreement, provided that the Company shall not be required to prepay the loan out of its excess cash flow if its leverage ratio is greater than 1.50:1.00 on the last day of such fiscal year.

[0001511737-14-000018:notes:29]
All of the obligations of the Company under the Loan Agreement are collateralized by substantially all of the Company’s assets, including all of the capital stock of the Company’s future domestic subsidiaries and 65% of the capital stock of the Company’s existing and future foreign subsidiaries, but excluding the Company’s intellectual property, which is subject to a negative pledge agreement. All of the Company’s future domestic subsidiaries are required to guaranty the obligations under the Loan Agreement. Such guarantees by future subsidiaries will be collateralized by substantially all of the property of such subsidiaries, excluding intellectual property.

[0001511737-14-000018:notes:30]
The Loan Agreement contains customary affirmative and negative covenants, including covenants that limit or restrict the Company and its subsidiaries’ ability to, among other things, incur indebtedness, grant liens, merge or consolidate, dispose of assets, pay dividends or make distributions, make investments, make acquisitions, prepay certain indebtedness, change the nature of its business, enter into certain transactions with affiliates, enter into restrictive agreements, and make capital expenditures, in each case subject to customary exceptions for a credit facility of this size and type. The Company is also required to maintain a minimum debt service coverage ratio, a maximum leverage ratio, and a minimum liquidity ratio.  As of March 31, 2014, the Company was in compliance with all affirmative and negative covenants, debt service coverage ratio, leverage ratio and liquidity ratio requirements.

[0001511737-14-000018:notes:31]
The Loan Agreement includes customary events of default that include, among other things, defaults for the failure to timely pay principal, interest, or other amounts due, defaults due to the inaccuracy of representations and warranties, covenant defaults, a cross default to material indebtedness, bankruptcy and insolvency defaults, material judgment defaults, defaults due to the unenforceability of a guaranty, and defaults due to circumstances that have or could reasonably be expected to have a material adverse effect on the Company's business, operations or financial condition, its ability to pay or perform under the Loan Agreement, or on the lenders' security interests. The occurrence of an event of default could result in the acceleration of the obligations under the Loan Agreement. During the existence of an event of default, interest on the obligations under the Loan Agreement could be increased by 2.00% above the otherwise applicable interest rate.

[0001511737-14-000018:notes:32]
During the three and nine months ended March 31, 2014, the Company made aggregate payments of $1.3 million and $3.8 million, respectively, against the loan balance.  During the three and nine months ended March 31, 2013, the Company made aggregate payments of $1.3 million and $3.1 million, respectively, against the loan balance.  As of March 31, 2014, the Company has classified $6.3 million and $66.1 million in short-term and long-term debt, respectively, on its condensed consolidated balance sheet related to the Loan Agreement.

[0001511737-14-000018:notes:33]
The following table summarizes our estimated debt and interest payment obligations as of March 31, 2014 for the remainder of fiscal 2014 and future fiscal years (in thousands):

[0001511737-14-000018:notes:34]
|  | 2014 (remainder) |  | 2015 |  | 2016 |  | 2017 |  | 2018 |  | Total |
| Debt payment obligations | $ | 1,250 |  |  | $ | 6,875 |  |  | $ | 39,375 |  |  | $ | 10,000 |  |  | $ | 15,000 |  |  | $ | 72,500 |  |
| Interest payments on debt payment obligations | 446 |  |  | 1,723 |  |  | 1,043 |  |  | 532 |  |  | 125 |  |  | 3,869 |  |
| Total | $ | 1,696 |  |  | $ | 8,598 |  |  | $ | 40,418 |  |  | $ | 10,532 |  |  | $ | 15,125 |  |  | $ | 76,369 |  |

[0001511737-14-000018:notes:35]
On May 5, 2014, the Company entered into a credit agreement with Wells Fargo Bank, National Association (“Wells Fargo”), the financial institutions named as lenders therein, and Wells Fargo as administrative agent for the lenders.  In connection with the execution of the credit agreement, the Company terminated and repaid all outstanding obligations under the Term Loan Facility and Revolving Credit Facility under the Loan Agreement described above.  Please see Part 1, Item 1, Note 14 below for a full description of the credit agreement.


## us-gaap:DeferredCostsCapitalizedPrepaidAndOtherAssetsDisclosureTextBlock

[0001511737-14-000018:notes:36]
[same as prior period, unchanged from 0001511737-14-000009:notes:39]

[0001511737-14-000018:notes:37]
|  | March 31, 2014 |  | June 30, 2013 |
| Vendor deposits | $ | 8,043 |  |  | $ | — |  |
| Non-trade receivables | 1,727 |  |  | 2,203 |  |
| Other current assets | 1,808 |  |  | 948 |  |
|  | $ | 11,578 |  |  | $ | 3,151 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001511737-14-000018:notes:38]
[same as prior period, unchanged from 0001511737-14-000009:notes:41]

[0001511737-14-000018:notes:39]
[same as prior period, unchanged from 0001511737-14-000009:notes:42]

[0001511737-14-000018:notes:40]
The Company’s 2010 Equity Incentive Plan and 2005 Equity Incentive Plan are described in its Annual Report. As of March 31, 2014, the Company had 9,916,169 authorized shares available for future issuance under all of its stock incentive plans.

[0001511737-14-000018:notes:41]
[same as prior period, unchanged from 0001511737-14-000009:notes:44]

[0001511737-14-000018:notes:42]
The following table shows total stock-based compensation expense included in the Condensed Consolidated Statements of Operations for the three and nine months ended March 31, 2014 and 2013 (in thousands):

[0001511737-14-000018:notes:43]
|  | Three Months Ended March 31, |  | Nine Months Ended March 31, |
|  | 2014 |  | 2013 |  | 2014 |  | 2013 |
| Cost of revenues | $ | 153 |  |  | $ | 124 |  |  | $ | 445 |  |  | $ | 309 |  |
| Research and development | 630 |  |  | 324 |  |  | 1,679 |  |  | 991 |  |
| Sales, general and administrative | 258 |  |  | 252 |  |  | 1,506 |  |  | 949 |  |
|  | $ | 1,041 |  |  | $ | 700 |  |  | $ | 3,630 |  |  | $ | 2,249 |  |

[0001511737-14-000018:notes:44]
[same as prior period, unchanged from 0001511737-14-000009:notes:47]

[0001511737-14-000018:notes:45]
The following is a summary of option activity for the Company’s stock incentive plans for the nine months ended March 31, 2014:

[0001511737-14-000018:notes:46]
|  | Common Stock Options Outstanding |
|  | Numberof Shares |  | WeightedAverageExercisePrice |  | WeightedAverageRemainingContractualLife (Years) |  | AggregateIntrinsicValue |
|  |  |  |  |  |  |  | (In thousands) |
| Balance, June 30, 2013 | 3,614,262 |  |  | $ | 3.07 |  |  |  |  |  |
| Exercised | (749,237 | ) |  | 2.38 |  |  |  |  |  |
| Forfeitures and cancellations | (107,318 | ) |  | 10.55 |  |  |  |  |  |
| Balance, March 31, 2014 | 2,757,707 |  |  | $ | 2.96 |  |  | 5.36 |  | $ | 117,166 |  |
| Vested and expected to vest as of March 31, 2014 | 2,730,108 |  |  | $ | 2.88 |  |  | 5.33 |  | $ | 116,212 |  |
| Vested and exercisable as of March 31, 2014 | 2,240,079 |  |  | $ | 1.44 |  |  | 4.73 |  | $ | 98,595 |  |

[0001511737-14-000018:notes:47]
During the three months ended March 31, 2014 and 2013, the aggregate intrinsic value of options exercised under the Company’s stock incentive plans was $13.2 million and $1.1 million, respectively, as determined as of the date of option exercise. During the nine months ended March 31, 2014 and 2013, the aggregate intrinsic value of options exercised under the Company’s stock incentive plans was $26.9 million and $1.5 million, respectively, as determined as of the date of option exercise.

[0001511737-14-000018:notes:48]
As of March 31, 2014, the Company had unrecognized compensation costs of $2.3 million related to stock options which the Company expects to recognize over a weighted-average period of 2.4 years. Future option grants will increase the amount of compensation expense to be recorded in these periods.

[0001511737-14-000018:notes:49]
The Company estimates the fair value of employee stock options using the Black-Scholes option pricing model. The fair value of employee stock options is being amortized on a straight-line basis over the requisite service period of the awards.  The Company did not grant any employee stock options during the three and nine months ended March 31, 2014.   For the three and nine months ended March 31, 2013, the fair value of employee stock options was estimated using the following weighted average assumptions:

[0001511737-14-000018:notes:50]
|  | Three Months Ended March 31, 2013 |  | Nine Months Ended March 31, 2013 |
| Expected term | 6.1 years |  |  | 6.1 years |  |
| Expected volatility | 52 | % |  | 52 | % |
| Risk-free interest rate | 1.0 | % |  | 0.8 | % |
| Expected dividend yield | — |  |  | — |  |
| Weighted average grant date fair value | $ | 6.69 |  |  | $ | 5.51 |  |

[0001511737-14-000018:notes:51]
[same as prior period, unchanged from 0001511737-14-000009:notes:54]

[0001511737-14-000018:notes:52]
[same as prior period, unchanged from 0001511737-14-000009:notes:55]

[0001511737-14-000018:notes:53]
|  | Number of Shares |  | Weighted Average Grant Date Fair Value |
| Non-vested RSUs, June 30, 2013 | 744,906 |  |  | $ | 14.74 |  |
| RSUs granted | 193,528 |  |  | 37.72 |  |
| RSUs vested | (149,697 | ) |  | 15.28 |  |
| RSUs canceled | (223,124 | ) |  | 22.01 |  |
| Non-vested RSUs, March 31, 2014 | 565,613 |  |  | $ | 19.59 |  |

[0001511737-14-000018:notes:54]
The intrinsic value of RSUs vested in the three months ended March 31, 2014 and 2013 was $2.4 million and $389,000, respectively.  The intrinsic value of RSUs vested in the nine months ended March 31, 2014 and 2013 was $5.3 million and $622,000, respectively.

[0001511737-14-000018:notes:55]
As of March 31, 2014, there was unrecognized compensation costs related to RSUs of $10.1 million which the Company expects to recognize over a weighted average period of 3.4 years.


## us-gaap:EarningsPerShareTextBlock

[0001511737-14-000018:notes:56]
[same as prior period, unchanged from 0001511737-14-000009:notes:59]

[0001511737-14-000018:notes:57]
[same as prior period, unchanged from 0001511737-14-000009:notes:60]

[0001511737-14-000018:notes:58]
|  | Three Months Ended March 31, |  | Nine Months Ended March 31, |
|  | 2014 |  | 2013 |  | 2014 |  | 2013 |
| Numerator: |  |  |  |
| Net income attributable to common stockholders | $ | 45,199 |  |  | $ | 20,667 |  |  | $ | 127,519 |  |  | $ | 51,649 |  |
| Denominator: |  |  |  |
| Weighted-average shares used in computing basic net income per share | 87,901 |  |  | 87,004 |  |  | 87,656 |  |  | 88,702 |  |
| Add—dilutive potential common shares: |  |  |  |  |  |  |  |
| Stock options | 1,646 |  |  | 1,803 |  |  | 1,754 |  |  | 1,808 |  |
| Restricted stock units | 228 |  |  | 146 |  |  | 257 |  |  | 146 |  |
| Weighted-average shares used in computing diluted net income per share | 89,775 |  |  | 88,953 |  |  | 89,667 |  |  | 90,656 |  |
| Net income per share of common stock: |  |  |  |
| Basic | $ | 0.51 |  |  | $ | 0.24 |  |  | $ | 1.45 |  |  | $ | 0.58 |  |
| Diluted | $ | 0.50 |  |  | $ | 0.23 |  |  | $ | 1.42 |  |  | $ | 0.57 |  |

[0001511737-14-000018:notes:59]
The Company excludes certain securities from its diluted net income per share calculation when their effect would be antidilutive to net income per share amounts.  The following table summarizes the total potential shares of common stock that were excluded from the diluted per share calculation, because to include them would have been anti-dilutive for the period (in thousands):

[0001511737-14-000018:notes:60]
|  | Three Months Ended March 31, |  | Nine Months Ended March 31, |
|  | 2014 |  | 2013 |  | 2014 |  | 2013 |
| Stock options | — |  |  | 655 |  |  | — |  |  | 356 |  |
| Restricted stock units | 6 |  |  | 205 |  |  | 85 |  |  | 129 |  |
|  | 6 |  |  | 860 |  |  | 85 |  |  | 485 |  |


## us-gaap:FairValueAssetsAndLiabilitiesMeasuredOnRecurringAndNonrecurringBasisTableTextBlock

[0001511737-14-000018:notes:61]
As of March 31, 2014 and June 30, 2013, the fair value hierarchy for the Company’s financial liabilities was as follows (in thousands):

[0001511737-14-000018:notes:62]
|  | March 31, 2014 |  | June 30, 2013 |
|  | FairValue |  | Level 1 |  | Level 2 |  | Level 3 |  | FairValue |  | Level 1 |  | Level 2 |  | Level 3 |
| Debt | $ | 72,408 |  |  | $ | — |  |  | $ | 72,408 |  |  | $ | — |  |  | $ | 76,129 |  |  | $ | — |  |  | $ | 76,129 |  |  | $ | — |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001511737-14-000018:notes:63]
[same as prior period, unchanged from 0001511737-14-000009:notes:66]

[0001511737-14-000018:notes:64]
[same as prior period, unchanged from 0001511737-14-000009:notes:67]

[0001511737-14-000018:notes:65]
[same as prior period, unchanged from 0001511737-14-000009:notes:68]

[0001511737-14-000018:notes:66]
[same as prior period, unchanged from 0001511737-14-000009:notes:69]

[0001511737-14-000018:notes:67]
[same as prior period, unchanged from 0001511737-14-000009:notes:70]

[0001511737-14-000018:notes:68]
For certain of the Company’s financial instruments, including cash, accounts receivable and accounts payable, the carrying amounts approximate fair value due to their short maturities, and are therefore excluded from the fair value tables below.   Additionally, as of March 31, 2014, we held $274.9 million of our $291.7 million of cash and cash equivalents in accounts of our subsidiaries outside of the United States and we will incur significant tax liabilities if we were to repatriate those amounts.

[0001511737-14-000018:notes:69]
At March 31, 2014 and June 30, 2013 the Company had debt associated with its Loan and Security Agreement with East West Bank (see Note 7). The fair value of the Company’s debt was estimated based on the current rates offered to the Company for debt with similar terms and remaining maturities and was determined to be a Level 2 measurement.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001511737-14-000018:notes:70]
[same as prior period, unchanged from 0001511737-14-000009:notes:72]

[0001511737-14-000018:notes:71]
As of March 31, 2014, the Company had approximately $13.8 million of unrecognized tax benefits, substantially all of which would, if recognized, affect its tax expense. The Company has elected to include interest and penalties related to uncertain tax positions as a component of tax expense. At March 31, 2014, an insignificant amount of interest and penalties are included in long-term income tax payable. The Company recorded an increase of its unrecognized tax benefits of $535,000 for the three months ended March 31, 2014. The Company does not expect any significant increases or decreases to its unrecognized tax benefits in the next twelve months.

[0001511737-14-000018:notes:72]
The Company recorded income tax provisions of $4.7 million and $14.9 million for the three and nine months ended March 31, 2014, respectively. The Company’s estimated 2014 effective tax rate differs from the U.S. statutory rate primarily due to profits earned in jurisdictions where the tax rate is lower than the U.S. tax rate.

[0001511737-14-000018:notes:73]
[same as prior period, unchanged from 0001511737-14-000009:notes:75]


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001511737-14-000018:notes:74]
Recent Accounting Pronouncements

[0001511737-14-000018:notes:75]
In July 2013, the FASB issued a new accounting standard update on the financial statement presentation of unrecognized tax benefits.  The new guidance provides that a liability related to an unrecognized tax benefit would be presented as a reduction of a deferred tax asset for a new operating loss carryforward, a similar tax loss or a tax credit carryforward if such settlement is required or expected in the event the uncertain tax position is disallowed.  The new guidance will become effective for the Company on July 1, 2014 and it should be applied prospectively to unrecognized tax benefits that exist as of the effective date with retrospective application permitted.  The Company is currently assessing the impact of this new guidance.


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001511737-14-000018:notes:76]
[same as prior period, unchanged from 0001511737-14-000009:notes:78]

[0001511737-14-000018:notes:77]
[same as prior period, unchanged from 0001511737-14-000009:notes:79]

[0001511737-14-000018:notes:78]
[same as prior period, unchanged from 0001511737-14-000009:notes:80]

[0001511737-14-000018:notes:79]
|  | Nine Months Ended March 31, |
|  | 2014 |  | 2013 |
| Beginning balance | $ | 2,913 |  |  | $ | 1,381 |  |
| Accruals for warranties issued during the period | 3,287 |  |  | 1,684 |  |
| Warranty costs incurred during the period | (3,250 | ) |  | (1,115 | ) |
|  | $ | 2,950 |  |  | $ | 1,950 |  |


## us-gaap:PropertyPlantAndEquipmentScheduleOfSignificantAcquisitionsAndDisposalsTextBlock

[0001511737-14-000018:notes:80]
[same as prior period, unchanged from 0001511737-14-000009:notes:82]

[0001511737-14-000018:notes:81]
|  | March 31, 2014 |  | June 30, 2013 |
| Testing equipment | $ | 3,677 |  |  | $ | 3,309 |  |
| Computer and other equipment | 1,009 |  |  | 841 |  |
| Tooling equipment | 2,854 |  |  | 1,737 |  |
| Furniture and fixtures | 768 |  |  | 652 |  |
| Leasehold improvements | 2,902 |  |  | 1,858 |  |
| Software | 343 |  |  | 245 |  |
|  | 11,553 |  |  | 8,642 |  |
| Less: Accumulated depreciation and amortization | (4,379 | ) |  | (2,666 | ) |
|  | $ | 7,174 |  |  | $ | 5,976 |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001511737-14-000018:notes:82]
RELATED PARTY TRANSACTIONS AND CERTAIN OTHER TRANSACTIONS

[0001511737-14-000018:notes:83]
On November 13, 2013, the Company entered into an aircraft lease agreement (the "Aircraft Lease Agreement") with RJP Manageco LLC (the "Lessor"), a limited liability company owned by the Company’s CEO, Robert J. Pera. Pursuant to the Aircraft Lease Agreement, the Company may lease an aircraft owned by the Lessor for Company business purposes. Under the Aircraft Lease Agreement, the aircraft may be leased at a rate of $5,000 per flight hour. This hourly rate does not include the cost of flight crew or on-board services, which the Company will purchase from a third-party provider. The Company recognized a total of approximately $120,000 in expenses pursuant to the Aircraft Lease Agreement during the three months ended March 31, 2014.  All expenses pursuant to the Aircraft Lease Agreement have been included in the Company's sales, general and administrative expenses in the Condensed Consolidated Statements of Operations.


## us-gaap:ScheduleOfAccruedLiabilitiesTableTextBlock

[0001511737-14-000018:notes:84]
[same as prior period, unchanged from 0001511737-14-000009:notes:86]

[0001511737-14-000018:notes:85]
|  | March 31, 2014 |  | June 30, 2013 |
| Warranty accrual | $ | 2,950 |  |  | $ | 2,913 |  |
| Accrued compensation and benefits | 2,724 |  |  | 2,712 |  |
| Accrual for an export compliance matter | — |  |  | 1,625 |  |
| Other accruals | 4,072 |  |  | 3,900 |  |
|  | $ | 9,746 |  |  | $ | 11,150 |  |


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0001511737-14-000018:notes:86]
[same as prior period, unchanged from 0001511737-14-000009:notes:88]

[0001511737-14-000018:notes:87]
|  | March 31, 2014 |  | June 30, 2013 |
| Finished goods | $ | 65,622 |  |  | $ | 15,618 |  |
| Raw materials | 382 |  |  | 262 |  |
|  | $ | 66,004 |  |  | $ | 15,880 |  |


## us-gaap:ScheduleOfOtherAssetsNoncurrentTextBlock

[0001511737-14-000018:notes:88]
[same as prior period, unchanged from 0001511737-14-000009:notes:90]

[0001511737-14-000018:notes:89]
|  | March 31, 2014 |  | June 30, 2013 |
| Long-term deferred cost of revenues | $ | 1,218 |  |  | $ | 1,185 |  |
| Intangible assets, net | 815 |  |  | 1,029 |  |
| Other long-term assets | 629 |  |  | 672 |  |
|  | $ | 2,662 |  |  | $ | 2,886 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001511737-14-000018:notes:90]
[same as prior period, unchanged from 0001511737-14-000009:notes:92]

[0001511737-14-000018:notes:91]
[same as prior period, unchanged from 0001511737-14-000009:notes:93]

[0001511737-14-000018:notes:92]
[same as prior period, unchanged from 0001511737-14-000009:notes:94]

[0001511737-14-000018:notes:93]
[same as prior period, unchanged from 0001511737-14-000009:notes:95]

[0001511737-14-000018:notes:94]
Revenues by product type for the three and nine months ended March 31, 2014 and 2013 were as follows (in thousands, except percentages):

[0001511737-14-000018:notes:95]
|  | Three Months Ended March 31, |  | Nine Months Ended March 31, |
|  | 2014 |  | 2013 |  | 2014 |  | 2013 |
| Service Provider Technology | $ | 120,987 |  |  | 82 | % |  | $ | 75,475 |  |  | 91 | % |  | $ | 326,658 |  |  | 78 | % |  | $ | 195,262 |  |  | 89 | % |
| Enterprise Technology | 27,344 |  |  | 18 | % |  | 7,680 |  |  | 9 | % |  | 89,799 |  |  | 22 | % |  | 24,329 |  |  | 11 | % |
| Total revenues | $ | 148,331 |  |  | 100 | % |  | $ | 83,155 |  |  | 100 | % |  | $ | 416,457 |  |  | 100 | % |  | $ | 219,591 |  |  | 100 | % |

[0001511737-14-000018:notes:96]
[same as prior period, unchanged from 0001511737-14-000009:notes:98]

[0001511737-14-000018:notes:97]
[same as prior period, unchanged from 0001511737-14-000009:notes:99]

[0001511737-14-000018:notes:98]
|  | Three Months Ended March 31, |  | Nine Months Ended March 31, |
|  | 2014 |  | 2013 |  | 2014 |  | 2013 |
| North America(1) | $ | 29,178 |  |  | 20 | % |  | $ | 21,052 |  |  | 25 | % |  | $ | 99,178 |  |  | 24 | % |  | $ | 53,519 |  |  | 24 | % |
| South America | 25,059 |  |  | 17 | % |  | 18,496 |  |  | 22 | % |  | 73,827 |  |  | 18 | % |  | 45,820 |  |  | 21 | % |
| Europe, the Middle East and Africa | 77,883 |  |  | 52 | % |  | 31,617 |  |  | 38 | % |  | 189,591 |  |  | 45 | % |  | 90,690 |  |  | 41 | % |
| Asia Pacific | 16,211 |  |  | 11 | % |  | 11,990 |  |  | 15 | % |  | 53,861 |  |  | 13 | % |  | 29,562 |  |  | 14 | % |
| Total revenues | $ | 148,331 |  |  | 100 | % |  | $ | 83,155 |  |  | 100 | % |  | $ | 416,457 |  |  | 100 | % |  | $ | 219,591 |  |  | 100 | % |

[0001511737-14-000018:notes:99]
| (1) | Revenue for the United States was $27.7 million and $19.7 million for the three months ended March 31, 2014 and 2013, respectively. Revenue for the United States was $95.0 million and $50.5 million for the nine months ended March 31, 2014 and 2013, respectively. |

[0001511737-14-000018:notes:100]
[same as prior period, unchanged from 0001511737-14-000009:notes:102]

[0001511737-14-000018:notes:101]
|  | Percentage of Revenues |  | Percentage of Accounts Receivable |
|  | Three Months Ended March 31, |  | Nine Months Ended March 31, |  | March 31, |  | June 30, |
|  | 2014 |  | 2013 |  | 2014 |  | 2013 |  | 2014 |  | 2013 |
| Customer A | 11 | % |  | 15 | % |  | 13 | % |  | 13 | % |  | 12 | % |  | 12 | % |
| Customer B | 10 | % |  | * |  |  | * |  |  | * |  |  | 15 | % |  | * |  |
| Customer C | * |  |  | * |  |  | * |  |  | * |  |  | 14 | % |  | 11 | % |
| Customer D | * |  |  | * |  |  | * |  |  | * |  |  | * |  |  | 15 | % |

[0001511737-14-000018:notes:102]
[same as prior period, unchanged from 0001511737-14-000009:notes:104]


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001511737-14-000018:notes:103]
[same as prior period, unchanged from 0001511737-14-000009:notes:105]

[0001511737-14-000018:notes:104]
The Company’s significant accounting policies are disclosed in its audited consolidated financial statements for the year ended June 30, 2013 included in the Annual Report.  Unless otherwise noted below, the Company's significant accounting policies have not changed since June 30, 2013.

[0001511737-14-000018:notes:105]
Advertising Costs

[0001511737-14-000018:notes:106]
The Company expenses all advertising costs as incurred. Advertising costs totaled $1.8 million and $2.4 million during the three and nine months ended March 31, 2014.  Advertising costs during the three and nine months ended March 31, 2013 were not significant.


## us-gaap:SubsequentEventsTextBlock

[0001511737-14-000018:notes:107]
SUBSEQUENT EVENTS

[0001511737-14-000018:notes:108]
On May 5, 2014, the Company and certain of its subsidiaries entered into a credit agreement (the “Credit Agreement”) with Wells Fargo Bank, National Association (“Wells Fargo”), the financial institutions named as lenders therein, and Wells Fargo as administrative agent for the lenders, that provides for a $150 million senior secured revolving credit facility, with an option to request an increase in the amount of the credit facility by up to an additional $50 million (any such increase to be in each lender’s sole discretion).  The Company may borrow up to $110 million of the facility as a U.S. sublimit.  The entire amount of the facility is available to Ubiquiti International Holding Company Limited, a wholly-owned subsidiary of the Company organized under the laws of the Cayman Islands.  The credit facility includes a sub-limit of $5 million for letters of credit and a sub-limit of $15 million for swingline loans.   In connection with the execution of the Credit Agreement, the Company terminated the $50 million line of credit facility under the Loan Agreement described in Note 7, “Debt”.  Under the Credit Agreement, revolving loans and swingline loans may be borrowed, repaid and reborrowed until May 5, 2019, at which time all amounts borrowed must be repaid.   Additionally, $72.3 million is currently outstanding under the Credit Agreement, which was borrowed by the Company to repay obligations under the Loan Agreement and to pay transaction fees and costs.  Revolving loans bear interest, at the Company’s option, at either (i) a floating rate per annum equal to the base rate plus a margin of between 0.250% and 1.000%, depending on the Company’s leverage ratio as of the most recently ended fiscal quarter or (ii) a per annum rate equal to the applicable LIBOR rate for a specified period, plus a margin of between 1.250% and 2.000%, depending on the Company’s leverage ratio as of the most recently ended fiscal quarter.  Swingline loans will bear interest at a floating rate per annum equal to the base rate plus a margin of between 0.250% and 1.000%, depending on the Company’s leverage ratio as of the most recently ended fiscal quarter.   Base rate is defined as the greatest of (A) Wells Fargo’s prime rate, (B) the federal funds rate plus 0.500% or (C) a per annum rate equal to the rate at which dollar deposits are offered in the London interbank market for a period of one month plus 1.000%.  A default interest rate shall apply on all obligations during a payment event of default under the Credit Agreement at a rate per annum equal to 2.000% above the applicable interest rate. The Company will pay to each lender a facility fee on a quarterly basis based on the unused amount of each lender’s commitment to make loans, of between 0.200% and 0.350%, depending on the Company’s leverage ratio as of the most recently ended fiscal quarter.  Revolving loans and swingline loans may be prepaid at any time without penalty.  The Company is also obligated to pay Wells Fargo, as agent, fees customary for a credit facility of this size and type.

[0001511737-14-000018:notes:109]
The Credit Agreement requires the Company to maintain a maximum leverage ratio and a minimum interest coverage ratio during the term of the credit facility.  In addition, the Credit Agreement contains customary affirmative and negative covenants, including covenants that limit or restrict the ability of the Company and its subsidiaries to, among other things, grant liens or enter into agreements restricting their ability to grant liens on property, enter into mergers, dispose of assets, change their accounting or reporting policies, change their business and incur subsidiary indebtedness, in each case subject to customary exceptions for a credit facility of this size and type.  The Credit Agreement includes customary events of default that, include among other things, non-payment of principal, interest or fees, inaccuracy of representations and warranties, violation of covenants, cross default to certain other indebtedness, bankruptcy and insolvency events, material judgments, change of control and certain ERISA events. The occurrence of an event of default could result in the acceleration of the obligations under the Credit Agreement.  The credit facility under the Credit Agreement expires May 5, 2019.

[0001511737-14-000018:notes:110]
The obligations of the Company and its subsidiaries under the Credit Agreement are collateralized by substantially all assets (excluding intellectual property) of the Company and its subsidiaries.

[0001511737-14-000018:notes:111]
Wells Fargo and the lenders party to the Credit Agreement, and certain of their respective affiliates, have provided, and in the future may provide, financial, banking and related services to the Company. These parties have received, and in the future may receive, compensation from the Company for these services.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001511737-14-000018:notes:112]
[same as prior period, unchanged from 0001511737-14-000009:notes:107]

[0001511737-14-000018:notes:113]
[same as prior period, unchanged from 0001511737-14-000009:notes:108]

[0001511737-14-000018:notes:114]
[same as prior period, unchanged from 0001511737-14-000009:notes:109]

[0001511737-14-000018:notes:115]
[same as prior period, unchanged from 0001511737-14-000009:notes:110]

[0001511737-14-000018:notes:116]
[same as prior period, unchanged from 0001511737-14-000009:notes:111]

[0001511737-14-000018:notes:117]
The Company's intangible assets consist primarily of legal costs associated with the application for and registration of the Company’s trademarks.  The Company recorded $25,000 and $200,000 of amortization of intangible assets during the three and nine months ended March 31, 2014, respectively.  The Company did not record any amortization of intangible assets during the three and nine months ended March 31, 2013.   The balance of accumulated amortization was $400,000 and $200,000 at March 31, 2014 and June 30, 2013, respectively.  Estimated future amortization related to trademark registration fees is $37,000, $244,000, $244,000, $222,000, $61,000 and $7,000 for the remainder of fiscal 2014 and fiscal years 2015, 2016, 2017, 2018, and thereafter, respectively.

[0001511737-14-000018:notes:118]
[same as prior period, unchanged from 0001511737-14-000009:notes:113]


## ubnt:CommonStockAndTreasuryStockDiscloseTextBlock

[0001511737-14-000018:notes:119]
[same as prior period, unchanged from 0001511737-14-000009:notes:114]

[0001511737-14-000018:notes:120]
As of March 31, 2014 and June 30, 2013, the authorized capital of the Company included 500,000,000 shares of common stock.  As of March 31, 2014, 132,303,947 shares of common stock were issued and 88,064,987 were outstanding. As of June 30, 2013, 131,452,763 shares of common stock were issued and 87,213,803 were outstanding.

[0001511737-14-000018:notes:121]
[same as prior period, unchanged from 0001511737-14-000009:notes:116]

[0001511737-14-000018:notes:122]
[same as prior period, unchanged from 0001511737-14-000009:notes:117]

[0001511737-14-000018:notes:123]
[same as prior period, unchanged from 0001511737-14-000009:notes:118]

[0001511737-14-000018:notes:124]
[same as prior period, unchanged from 0001511737-14-000009:notes:119]

[0001511737-14-000018:notes:125]
[same as prior period, unchanged from 0001511737-14-000009:notes:120]

[0001511737-14-000018:notes:126]
[same as prior period, unchanged from 0001511737-14-000009:notes:121]

[0001511737-14-000018:notes:127]
[same as prior period, unchanged from 0001511737-14-000009:notes:122]
