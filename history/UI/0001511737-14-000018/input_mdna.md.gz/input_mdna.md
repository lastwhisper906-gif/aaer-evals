# UI MD&A — 0001511737-14-000018


## mdna

[0001511737-14-000018:mdna:1]
[same as prior period, unchanged from 0001511737-14-000009:mdna:1]

[0001511737-14-000018:mdna:2]
[same as prior period, unchanged from 0001511737-14-000009:mdna:2]

[0001511737-14-000018:mdna:3]
[same as prior period, unchanged from 0001511737-14-000009:mdna:3]

[0001511737-14-000018:mdna:4]
We offer a broad and expanding portfolio of networking products and solutions for service providers and enterprises. Our service provider product platforms provide carrier-class network infrastructure for fixed wireless broadband, wireless backhaul systems and routing. Our enterprise product platforms provide wireless LAN infrastructure, video surveillance products, and machine-to-machine communication components. We believe that our products are highly differentiated due to our proprietary

[0001511737-14-000018:mdna:5]
17

[0001511737-14-000018:mdna:6]
software protocol innovation, firmware expertise, and hardware design capabilities. This differentiation allows our portfolio to meet the demanding performance requirements of video, voice and data applications at prices that are a fraction of those offered by our competitors.

[0001511737-14-000018:mdna:7]
As a core part of our strategy, we have developed a differentiated business model for marketing and selling high volumes of carrier and enterprise-class communications platforms. Our business model is driven by a large, growing and highly engaged community of service providers, distributors, value added resellers ("VARs"), systems integrators and corporate IT professionals, which we refer to as the Ubiquiti Community. The Ubiquiti Community is a critical element of our business strategy as it enables us to drive:

[0001511737-14-000018:mdna:8]
[same as prior period, unchanged from 0001511737-14-000009:mdna:8]

[0001511737-14-000018:mdna:9]
[same as prior period, unchanged from 0001511737-14-000009:mdna:9]

[0001511737-14-000018:mdna:10]
[same as prior period, unchanged from 0001511737-14-000009:mdna:10]

[0001511737-14-000018:mdna:11]
By optimizing the cost of development, sales, marketing and support we are able to eliminate traditional business model inefficiencies and offer innovative solutions with disruptive price performance characteristics to our customers.

[0001511737-14-000018:mdna:12]
Our revenues increased 78% to $148.3 million in the three months ended March 31, 2014 from $83.2 million in the three months ended March 31, 2013.  Our revenues increased 90% to $416.5 million in the nine months ended March 31, 2014 from $219.6 million in the nine months ended March 31, 2013.  We believe the overall increase in revenues during the three and nine months ended March 31, 2014 was driven by increased adoption of our service provider and enterprise technologies.  Additionally, during three and nine months ended March 31, 2013, we believe we experienced lost sales due to the proliferation of counterfeit versions of our products.  We believe these factors contributed to a buildup in channel inventory with our distributors, further impacting our revenues.  We had net income of $45.2 million and $20.7 million in the three months ended March 31, 2014 and 2013, respectively.  We had net income of $127.5 million and $51.6 million in the nine months ended March 31, 2014 and 2013, respectively.  The increase in net income in both the three and nine months ended March 31, 2014 as compared to the same periods in the prior year was primarily due to the increase in revenues.

[0001511737-14-000018:mdna:13]
[same as prior period, unchanged from 0001511737-14-000009:mdna:13]

[0001511737-14-000018:mdna:14]
[same as prior period, unchanged from 0001511737-14-000009:mdna:14]

[0001511737-14-000018:mdna:15]
[same as prior period, unchanged from 0001511737-14-000009:mdna:15]

[0001511737-14-000018:mdna:16]
[same as prior period, unchanged from 0001511737-14-000009:mdna:16]

[0001511737-14-000018:mdna:17]
| • | Service Provider Technology includes our airMAX, EdgeMAX and airFiber platforms, as well as embedded radio products and other 802.11 standard products including base stations, radios, backhaul equipment and Customer Premise Equipment (“CPE”). Additionally, Service Provider Technology includes antennas and other products in the 2.0 to 6.0GHz spectrum and miscellaneous products such as mounting brackets, cables and power over Ethernet adapters. |

[0001511737-14-000018:mdna:18]
[same as prior period, unchanged from 0001511737-14-000009:mdna:19]

[0001511737-14-000018:mdna:19]
[same as prior period, unchanged from 0001511737-14-000009:mdna:32]

[0001511737-14-000018:mdna:20]
We sell substantially all of our products through a limited number of distributors and other channel partners, such as resellers and OEMs. Sales to distributors accounted for 99% and 98% of our revenues in the three months ended March 31, 2014 and 2013, respectively.  Sales to distributors accounted for 99% and 97% of our revenues in the nine months ended March 31, 2014 and 2013, respectively.  Other channel partners, such as resellers and OEMs, largely accounted for the balance of our revenues. We sell our products without any right of return.

[0001511737-14-000018:mdna:21]
[same as prior period, unchanged from 0001511737-14-000009:mdna:21]

[0001511737-14-000018:mdna:22]
[same as prior period, unchanged from 0001511737-14-000009:mdna:22]

[0001511737-14-000018:mdna:23]
[same as prior period, unchanged from 0001511737-14-000009:mdna:23]

[0001511737-14-000018:mdna:24]
[same as prior period, unchanged from 0001511737-14-000009:mdna:24]

[0001511737-14-000018:mdna:25]
[same as prior period, unchanged from 0001511737-14-000009:mdna:25]

[0001511737-14-000018:mdna:26]
[same as prior period, unchanged from 0001511737-14-000009:mdna:26]

[0001511737-14-000018:mdna:27]
[same as prior period, unchanged from 0001511737-14-000009:mdna:27]

[0001511737-14-000018:mdna:28]
[same as prior period, unchanged from 0001511737-14-000009:mdna:28]

[0001511737-14-000018:mdna:29]
[same as prior period, unchanged from 0001511737-14-000009:mdna:29]

[0001511737-14-000018:mdna:30]
[same as prior period, unchanged from 0001511737-14-000009:mdna:30]

[0001511737-14-000018:mdna:31]
In the event that collectability of a receivable from products we have shipped is not probable, we classify those amounts as deferred revenues on our balance sheet until such time as we receive payment of the accounts receivable. We classify the cost of products associated with these deferred revenues as deferred costs of revenues.  At March 31, 2014, $2.3 million of revenue was deferred for transactions where we lacked evidence that collectability of the receivables recorded was reasonably assured. At June 30, 2013, $2.2 million of revenue was deferred for transactions where we lacked evidence that collectability of the receivables recorded was reasonably assured.  The related deferred cost of revenues balance was $1.2 million at both March 31, 2014 and June 30, 2013.

[0001511737-14-000018:mdna:32]
Also included in our deferred revenues is a portion related to PCS obligations that we estimate we will perform in the future. As of March 31, 2014 and June 30, 2013, we had deferred revenues of $1.4 million and $1.0 million respectively, related to these obligations.

[0001511737-14-000018:mdna:33]
[same as prior period, unchanged from 0001511737-14-000009:mdna:35]

[0001511737-14-000018:mdna:34]
We prepare our condensed consolidated financial statements in accordance with accounting principles generally accepted in the United States of America (“GAAP”). In many cases, the accounting treatment of a particular transaction is specifically dictated by GAAP and does not require management’s judgment in its application. In other cases, management’s judgment is required in selecting among available alternative accounting standards that provide for different accounting treatment for similar transactions. The preparation of condensed consolidated financial statements also requires us to make estimates and assumptions that affect the amounts we report as assets, liabilities, revenues, costs and expenses and affect the related disclosures. We base our estimates on historical experience and other assumptions that we believe are reasonable under the circumstances. In many instances, we could reasonably use different accounting estimates, and in some instances changes in the accounting estimates are reasonably likely to occur from period to period. Accordingly, our actual results could differ significantly from the estimates made by our management. To the extent that there are differences between our estimates and actual results, our future financial statement presentation, financial condition, results of operations and cash flows will be affected. Our critical accounting policies are discussed in our Annual Report on Form 10-K for the fiscal year ended June 30, 2013, as filed on September 13, 2013 with the SEC, or the Annual Report, and there have been no material changes except as noted below.

[0001511737-14-000018:mdna:35]
Recognition of Revenues

[0001511737-14-000018:mdna:36]
Revenues consist primarily of revenues from the sale of hardware and management tools, as well as the related implied PCS. We recognize revenues when persuasive evidence of an arrangement exists, delivery has occurred, the sales price is fixed or determinable and the collectability of the resulting receivable is reasonably assured. In cases where we lack evidence that collectability of the resulting receivable is reasonably assured, we defer recognition of revenue until the receipt of cash.  For our sales, evidence of the arrangement consists of an order from a customer. We consider delivery to have occurred once our products have been shipped and title and risk of loss have been transferred.  For our sales, these criteria are met at the time the products are transferred to the customer's shipping agent.  Our arrangements with customers typically do not include provisions for cancellation, returns, inventory swaps or refunds that would significantly impact recognized revenues.

[0001511737-14-000018:mdna:37]
[same as prior period, unchanged from 0001511737-14-000009:mdna:51]

[0001511737-14-000018:mdna:38]
[same as prior period, unchanged from 0001511737-14-000009:mdna:37]

[0001511737-14-000018:mdna:39]
Comparison of Three and Nine Months Ended March 31, 2014 and 2013

[0001511737-14-000018:mdna:40]
|  | Three Months Ended March 31, |  | Nine Months Ended March 31, |
|  | 2014 |  | 2013 |  | 2014 |  | 2013 |
|  | (In thousands, except percentages) |
| Revenues | $ | 148,331 |  |  | 100 | % |  | $ | 83,155 |  |  | 100 | % |  | $ | 416,457 |  |  | 100 | % |  | $ | 219,591 |  |  | 100 | % |
| Cost of revenues(1) | 82,719 |  |  | 56 | % |  | 47,690 |  |  | 57 | % |  | 231,851 |  |  | 56 | % |  | 128,621 |  |  | 59 | % |
| Gross profit | 65,612 |  |  | 44 | % |  | 35,465 |  |  | 43 | % |  | 184,606 |  |  | 44 | % |  | 90,970 |  |  | 41 | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development(1) | 9,413 |  |  | 6 | % |  | 5,677 |  |  | 7 | % |  | 23,807 |  |  | 6 | % |  | 15,440 |  |  | 7 | % |
| Sales, general and administrative(1)(2) | 6,064 |  |  | 4 | % |  | 6,285 |  |  | 8 | % |  | 17,648 |  |  | 4 | % |  | 16,133 |  |  | 7 | % |
| Total operating expenses | 15,477 |  |  | 10 | % |  | 11,962 |  |  | 15 | % |  | 41,455 |  |  | 10 | % |  | 31,573 |  |  | 14 | % |
| Income from operations | 50,135 |  |  | 34 | % |  | 23,503 |  |  | 28 | % |  | 143,151 |  |  | 34 | % |  | 59,397 |  |  | 27 | % |
| Interest expense and other, net | (283 | ) |  | * |  |  | (287 | ) |  | * |  |  | (778 | ) |  | * |  |  | (570 | ) |  | * |  |
| Income before provision for income taxes | 49,852 |  |  | 34 | % |  | 23,216 |  |  | 28 | % |  | 142,373 |  |  | 34 | % |  | 58,827 |  |  | 27 | % |
| Provision for income taxes | 4,653 |  |  | 3 | % |  | 2,549 |  |  | 3 | % |  | 14,854 |  |  | 4 | % |  | 7,178 |  |  | 3 | % |
| Net income and comprehensive income | $ | 45,199 |  |  | 31 | % |  | $ | 20,667 |  |  | 25 | % |  | $ | 127,519 |  |  | 30 | % |  | $ | 51,649 |  |  | 24 | % |
| * Less than 1% |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| (1) Includes stock-based compensation as follows: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of revenues | $ | 153 |  |  |  |  | $ | 124 |  |  |  |  | $ | 445 |  |  |  |  | $ | 309 |  |  |  |
| Research and development | 630 |  |  |  |  | 324 |  |  |  |  | 1,679 |  |  |  |  | 991 |  |  |  |
| Sales, general and administrative | 258 |  |  |  |  | 252 |  |  |  |  | 1,506 |  |  |  |  | 949 |  |  |  |
| Total stock-based compensation | $ | 1,041 |  |  |  |  | $ | 700 |  |  |  |  | $ | 3,630 |  |  |  |  | $ | 2,249 |  |  |  |
| (2) Includes gain on reversal of charge for an export compliance matter as follows: | $ | (1,121 | ) |  |  |  | $ | — |  |  |  |  | $ | (1,121 | ) |  |  |  | $ | — |  |  |  |

[0001511737-14-000018:mdna:41]
[same as prior period, unchanged from 0001511737-14-000009:mdna:40]

[0001511737-14-000018:mdna:42]
Revenues increased $65.2 million, or 78%, from $83.2 million in the three months ended March 31, 2013 to $148.3 million in the three months ended March 31, 2014.  Revenues increased $196.9 million, or 90%, from $219.6 million in the nine months ended March 31, 2013 to $416.5 million in the nine months ended March 31, 2014.  We believe the overall increase in revenues during both the three and nine months ended March 31, 2014 was driven by increased adoption of our service provider and enterprise technologies.  Additionally, during the three and nine months ended March 31, 2013, we believe we experienced lost sales due to the proliferation of counterfeit versions of our products, which also created customer uncertainty regarding the authenticity of their potential purchases.

[0001511737-14-000018:mdna:43]
In the three months ended March 31, 2014, revenues from Customer A and Customer B represented 11% and 10% of our revenues, respectively.  In the nine months ended months ended March 31, 2014, revenues from Customer A represented 13% of our revenues.  In the three and nine months ended March 31, 2013, revenues from Customer A represented 15% and 13%, respectively.

[0001511737-14-000018:mdna:44]
[same as prior period, unchanged from 0001511737-14-000009:mdna:45]

[0001511737-14-000018:mdna:45]
|  | Three Months Ended March 31, |  | Nine Months Ended March 31, |
|  | 2014 |  | 2013 |  | 2014 |  | 2013 |
|  | (in thousands, except percentages) |
| Service Provider Technology | $ | 120,987 |  |  | 82 | % |  | $ | 75,475 |  |  | 91 | % |  | $ | 326,658 |  |  | 78 | % |  | $ | 195,262 |  |  | 89 | % |
| Enterprise Technology | 27,344 |  |  | 18 | % |  | 7,680 |  |  | 9 | % |  | 89,799 |  |  | 22 | % |  | 24,329 |  |  | 11 | % |
| Total revenues | $ | 148,331 |  |  | 100 | % |  | $ | 83,155 |  |  | 100 | % |  | $ | 416,457 |  |  | 100 | % |  | $ | 219,591 |  |  | 100 | % |

[0001511737-14-000018:mdna:46]
21

[0001511737-14-000018:mdna:47]
Service Provider Technology revenues increased $45.5 million, or 60%, from $75.5 million in the three months ended March 31, 2013 to $121.0 million in the three months ended March 31, 2014.  Revenues from Service Provider Technologies increased $131.4 million, or 67%, from $195.3 million in the nine months ended March 31, 2013 to $326.7 million in the nine months ended March 31, 2014.  The increases in both periods were primarily due to continued expansion of core infrastructure build-outs in our wireless markets.  Additionally, we believe we experienced significant lost sales during the three and nine months ended March 31, 2013 due to the proliferation of counterfeit versions of our products as discussed above, which also created customer uncertainty regarding the authenticity of their potential purchases.

[0001511737-14-000018:mdna:48]
Enterprise Technology revenues increased $19.7 million, or 256% from $7.7 million in the three months ended March 31, 2013 to $27.3 million in the three months ended March 31, 2014.  Enterprise Technology revenues increased $65.5 million, or 269% from $24.3 million in the nine months ended March 31, 2013 to $89.8 million in the nine months ended March 31, 2014.  The increase in Enterprise Technology revenues during both the three and nine months ended March 31, 2014 was due primarily to product expansion and further adoption of our UniFi technology platform.

[0001511737-14-000018:mdna:49]
[same as prior period, unchanged from 0001511737-14-000009:mdna:49]

[0001511737-14-000018:mdna:50]
We generally forward products directly from our contract manufacturers to our customers via logistics distribution hubs in China.  Beginning in the quarter ended December 31, 2012, our products were predominantly routed through a third party logistics provider in China and prior to the quarter ended December 31, 2012, our products were predominantly delivered to our customers through distribution hubs in Hong Kong.  Our logistics provider, in turn, ships to other locations throughout the world. We have determined the geographical distribution of our product revenues based on our customers' ship-to destinations. A majority of our sales are to distributors who in turn sell to resellers or directly to end customers, which may be different countries than the initial ship-to destination.  For the three and nine months ended March 31, 2014, revenues in all regions increased due to increased adoption of our Service Provider and Enterprise Technologies.  Additionally, during the three and nine months ended March 31, 2013, we believe we experienced lost sales due to the proliferation of counterfeit versions of our products, which also created customer uncertainty regarding the authenticity of their potential purchases.

[0001511737-14-000018:mdna:51]
The following are our revenues by geography for the three and nine months ended March 31, 2014 and 2013 (in thousands, except percentages):

[0001511737-14-000018:mdna:52]
|  | Three Months Ended March 31, |  | Nine Months Ended March 31, |
|  | 2014 |  | 2013 |  | 2014 |  | 2013 |
| North America(1) | $ | 29,178 |  |  | 20 | % |  | $ | 21,052 |  |  | 25 | % |  | $ | 99,178 |  |  | 24 | % |  | $ | 53,519 |  |  | 24 | % |
| South America | 25,059 |  |  | 17 | % |  | 18,496 |  |  | 22 | % |  | 73,827 |  |  | 18 | % |  | 45,820 |  |  | 21 | % |
| Europe, the Middle East and Africa | 77,883 |  |  | 52 | % |  | 31,617 |  |  | 38 | % |  | 189,591 |  |  | 45 | % |  | 90,690 |  |  | 41 | % |
| Asia Pacific | 16,211 |  |  | 11 | % |  | 11,990 |  |  | 15 | % |  | 53,861 |  |  | 13 | % |  | 29,562 |  |  | 14 | % |
| Total revenues | $ | 148,331 |  |  | 100 | % |  | $ | 83,155 |  |  | 100 | % |  | $ | 416,457 |  |  | 100 | % |  | $ | 219,591 |  |  | 100 | % |

[0001511737-14-000018:mdna:53]
| (1) | Revenue for the United States was $27.7 million and $19.7 million for the three months ended March 31, 2014 and 2013, respectively. Revenue for the United States was $95.0 million and $50.5 million for the nine months ended March 31, 2014 and 2013, respectively. |

[0001511737-14-000018:mdna:54]
[same as prior period, unchanged from 0001511737-14-000009:mdna:55]

[0001511737-14-000018:mdna:55]
Cost of revenues increased $35.0 million, or 73%, from $47.7 million in the three months ended March 31, 2013 to $82.7 million in the three months ended March 31, 2014.  Cost of revenues increased $103.2 million, or 80%, from $128.6 million in the nine months ended March 31, 2013 to $231.9 million in the three months ended March 31, 2014.  The increase in cost of revenues in both the three and nine months ended March 31, 2014 was primarily due to increased revenues and to a lesser extent, changes in product mix.

[0001511737-14-000018:mdna:56]
Gross profit increased to 44% in the three months ended March 31, 2014 compared to 43% in the three months ended March 31, 2013, and increased to 44% in the nine months ended March 31, 2014 compared to 41% in the nine months ended March 31, 2013, reflecting a high level of revenue growth, increasing economies of scale, a reduction in warranty expense, a one-time benefit from a rebate program with one of our vendors, and changes in product mix.

[0001511737-14-000018:mdna:57]
22

[0001511737-14-000018:mdna:58]
[same as prior period, unchanged from 0001511737-14-000009:mdna:58]

[0001511737-14-000018:mdna:59]
[same as prior period, unchanged from 0001511737-14-000009:mdna:59]

[0001511737-14-000018:mdna:60]
Research and development expenses increased $3.7 million, or 66%, from $5.7 million in the three months ended March 31, 2013 to $9.4 million in the three months ended March 31, 2014. As a percentage of revenues, research and development expenses decreased from 7% in the three months ended March 31, 2013 to 6% in the three months ended March 31, 2014.  Research and development expenses increased $8.4 million, or 54%, from $15.4 million in the nine months ended March 31, 2013 to $23.8 million in the nine months ended March 31, 2014. As a percentage of revenues, research and development expenses decreased from 7% in the nine months ended March 31, 2013 to 6% in the nine months ended March 31, 2014.  The increase in research and development expenses in absolute dollars in both periods was primarily due to increases in headcount as we broadened our research and development activities to introduce new products and new versions of existing products.  As a percentage of revenues, research and development expenses decreased primarily due to our overall increase in revenues. Over time, we expect our research and development costs to increase in absolute dollars as we continue making significant investments in developing new products and developing new versions of our existing products.

[0001511737-14-000018:mdna:61]
[same as prior period, unchanged from 0001511737-14-000009:mdna:61]

[0001511737-14-000018:mdna:62]
Sales, general and administrative expenses decreased $221,000, or 4%, from $6.3 million in the three months ended March 31, 2013 to $6.1 million in the three months ended March 31, 2014.  As a percentage of revenues, sales, general and administrative expenses decreased from 8% in the three months ended March 31, 2013 to 4% in the three months ended March 31, 2014.  Sales, general and administrative expenses increased $1.5 million, or 9%, from $16.1 million in the nine months ended March 31, 2013 to $17.6 million in the nine months ended March 31, 2014.  As a percentage of revenues, sales, general and administrative expenses decreased from 7% in the nine months ended March 31, 2013 to 4% in the nine months ended March 31, 2014.  The slight decrease in sales, general and administrative expenses in the three months ended March 31, 2014 compared to the same period in the prior year was primarily due to the partial reversal of our accrual relating to the settlement agreement with OFAC in March 2014 and decreases in legal fees from reduced spending on anti-counterfeiting efforts and decreases to our allowance for doubtful accounts, partially offset by increased marketing activity.  Sales, general and administrative expenses increased in the nine months ended March 31, 2014 compared to the same period in the prior year, primarily due to increased marketing activity, increased professional fees, primarily related to the ancillary support of certain management functions, and overall increases in headcount to further expand our marketing and administrative functions to support our revenue growth, partially offset by decreases in legal fees from reduced spending on anti-counterfeiting efforts, decreases to our allowance for doubtful accounts and the partial reversal of our accrual relating to the settlement agreement with OFAC in March 2014.  As a percentage of revenues, sales, general and administrative expenses decreased in both periods primarily due to our overall revenue increase. Over time, we expect our sales, general and administrative expenses to increase in absolute dollars due to continued efforts to protect our intellectual property and growth in headcount to support the growth in business and operations.

[0001511737-14-000018:mdna:63]
[same as prior period, unchanged from 0001511737-14-000009:mdna:64]

[0001511737-14-000018:mdna:64]
Interest expense and other, net was $283,000 for the three months ended March 31, 2014, representing a slight decrease from $287,000 for the three months ended March 31, 2013.  Interest expense and other, net was $778,000 for the nine months ended March 31, 2014, representing an increase of $208,000 from $570,000 for the nine months ended March 31, 2013.  The increase in interest expense and other, net during the nine months ended March 31, 2014 compared to the same period in the prior year was primarily due to additional interest expense resulting from our increased borrowings from East West Bank during the nine months ended March 31, 2013.

[0001511737-14-000018:mdna:65]
[same as prior period, unchanged from 0001511737-14-000009:mdna:66]

[0001511737-14-000018:mdna:66]
Our provision for income taxes increased $2.1 million, or 83%, from $2.5 million for the three months ended March 31, 2013 to $4.7 million for the three months ended March 31, 2014. Our effective tax rate decreased to 9% for the three months ended March 31, 2014 as compared to 11% the three months ended March 31, 2013.   Our provision for income taxes increased $7.7 million, or 107%, from $7.2 million for the nine months ended March 31, 2013 to $14.9 million for the nine months ended March 31, 2014. Our effective tax rate decreased to 10% for the nine months ended March 31, 2014 as compared to 12% in the nine months ended March 31, 2013.   The lower effective tax rate in the nine months ended March 31, 2014 was primarily due to a larger percentage of our overall profitability occurring in foreign jurisdictions with lower income tax rates.

[0001511737-14-000018:mdna:67]
[same as prior period, unchanged from 0001511737-14-000009:mdna:68]

[0001511737-14-000018:mdna:68]
[same as prior period, unchanged from 0001511737-14-000009:mdna:69]

[0001511737-14-000018:mdna:69]
Since inception, our operations primarily have been funded through cash generated by operations. Cash and cash equivalents increased from $227.8 million at June 30, 2013 to $291.7 million at March 31, 2014.

[0001511737-14-000018:mdna:70]
[same as prior period, unchanged from 0001511737-14-000009:mdna:71]

[0001511737-14-000018:mdna:71]
[same as prior period, unchanged from 0001511737-14-000009:mdna:72]

[0001511737-14-000018:mdna:72]
|  | Nine Months Ended March 31, |
|  | 2014 |  | 2013 |
|  | (In thousands) |
| Net cash provided by operating activities | $ | 65,534 |  |  | $ | 85,684 |  |
| Net cash used in investing activities | (3,244 | ) |  | (4,408 | ) |
| Net cash provided by (used in) financing activities | 1,554 |  |  | (21,647 | ) |
| Net increase in cash and cash equivalents | $ | 63,844 |  |  | $ | 59,629 |  |

[0001511737-14-000018:mdna:73]
[same as prior period, unchanged from 0001511737-14-000009:mdna:74]

[0001511737-14-000018:mdna:74]
Net cash provided by operating activities in the nine months ended March 31, 2014 of $65.5 million consisted primarily of net income of $127.5 million partially offset by net changes in operating assets and liabilities that resulted in net cash outflows of $66.0 million. These changes consisted primarily of a $52.2 million increase in inventory due to our efforts to build warehouse stock levels and ultimately decrease lead times, an $8.3 million increase in prepaid expenses and other current assets due to timing of deposit payments with our suppliers, an $8.0 million increase in accounts payable and accrued liabilities due primarily to our increase in cost of revenues, a $5.1 million increase in prepaid taxes due to the timing of federal tax payments and a $4.0 million increase in taxes payable.  Additionally, our net income included non-cash adjustments due to stock-based compensation, depreciation and amortization, increases to our provision for inventory obsolescence, decreases in our allowance for doubtful accounts, a write-off of our intangible assets and taxes. The net of these non-cash adjustments resulted in an increase of our net cash provided by operating activities of $4.0 million.

[0001511737-14-000018:mdna:75]
Net cash provided by operating activities in the nine months ended March 31, 2013 of $85.7 million consisted primarily of net income of $51.6 million and net changes in operating assets and liabilities that resulted in net cash inflows of $28.1 million. These changes consisted primarily of a $35.6 million decrease in accounts receivable due to decreased revenues and improved cash collections, a $12.7 million increase in inventory due to increased inventory on hand as a result of a transition to a third-party logistics provider during December 2012, a $3.7 million increase in taxes payable due the timing of federal tax payments, a $2.5 million increase in accounts payable and accrued liabilities due to the timing of payments with our vendors and a $1.5 million increase in prepaid expenses and other current assets due to an increase in overall business activity. Additionally, our net income included non-cash adjustments due to stock-based compensation, depreciation and amortization, increases to our provision for doubtful accounts and write-downs for inventory obsolescence and an excess tax benefit from stock-based awards. The net of these non-cash adjustments resulted in an increase of our net cash provided by operating activities of $5.9 million.

[0001511737-14-000018:mdna:76]
[same as prior period, unchanged from 0001511737-14-000009:mdna:77]

[0001511737-14-000018:mdna:77]
Our investing activities consist solely of capital expenditures and purchases of intangible assets. Capital expenditures for the nine months ended March 31, 2014 and 2013 were $3.0 million and $3.3 million, respectively. Additionally, we had cash outflows related to the purchase of intangible assets of $207,000 and $1.1 million during the nine months ended March 31, 2014 and 2013, respectively.

[0001511737-14-000018:mdna:78]
[same as prior period, unchanged from 0001511737-14-000009:mdna:79]

[0001511737-14-000018:mdna:79]
On August 7, 2012, we entered into a Loan and Security Agreement (the “Loan Agreement”) with U.S. Bank, as syndication agent, and East West Bank, as administrative agent for the lenders party to the Loan Agreement. The Loan Agreement replaced the East West Bank Loan Agreement discussed below. The Loan Agreement provides for (i) a $50.0 million revolving credit facility, with a $5.0 million sublimit for the issuance of letters of credit and a $5.0 million sublimit for the making of swingline loan advances (the “Revolving Credit Facility”), and (ii) a $50.0 million term loan facility (the “Term Loan Facility”). We may request borrowings under the Revolving Credit Facility until August 7, 2015. The Loan Agreement replaced a previous

[0001511737-14-000018:mdna:80]
[same as prior period, unchanged from 0001511737-14-000009:mdna:94]

[0001511737-14-000018:mdna:81]
agreement whereby we had an existing term loan balance of $29.2 million as of the date of the new Loan Agreement.  On August 7, 2012, we borrowed $20.8 million of term loans under the Term Loan Facility, and no borrowings remain available thereunder. On November 21, 2012, the Company borrowed $10.0 million under the Revolving Credit Facility. On December 20, 2012, the Company borrowed an additional $20.0 million under the Revolving Credit Facility, and $20.0 million remains available for borrowing thereunder.

[0001511737-14-000018:mdna:82]
On August 9, 2012, we announced that our Board of Directors authorized us to repurchase up to $100.0 million of our common stock. The share repurchase program commenced August 13, 2012 and expired on August 12, 2013. During the nine months ended March 31, 2013, we repurchased 5,159,050 shares for a total cost of $54.4 million.

[0001511737-14-000018:mdna:83]
On December 14, 2012, we announced that our Board of Directors had authorized a special cash dividend of $0.18 per share for each share of common stock outstanding on December 24, 2012. The aggregate dividend payment of $15.7 million was paid on December 28, 2012 to stockholders of record on December 24, 2012.

[0001511737-14-000018:mdna:84]
[same as prior period, unchanged from 0001511737-14-000009:mdna:83]

[0001511737-14-000018:mdna:85]
We believe our existing cash and cash equivalents, cash provided by operations and the availability of additional funds under our loan agreements will be sufficient to meet our working capital and capital expenditure needs for at least the next 12 months. Our future capital requirements may vary materially from those currently planned and will depend on many factors, including our rate of revenue growth, the timing and extent of spending to support development efforts, the timing of new product introductions, market acceptance of our products and overall economic conditions. As of March 31, 2014, we held $274.9 million of our $291.7 million of cash and cash equivalents in accounts of our subsidiaries outside of the United States and we will incur significant tax liabilities if we decide to repatriate those amounts.   We do not presently intend to repatriate those funds.

[0001511737-14-000018:mdna:86]
Commitments and Contingencies

[0001511737-14-000018:mdna:87]
In May 2011, we filed a self-disclosure statement with the U.S. Commerce Department, Bureau of Industry and Security’s (“BIS”) Office of Export Enforcement (“OEE”) relating a review conducted by us regarding certain export transactions from 2008 through March 2011 in which products may have been later resold into Iran by third parties. In June 2011, we also filed a self-disclosure statement with the U.S. Department of the Treasury’s Office of Foreign Asset Control (“OFAC”) regarding these compliance issues. In August 2011, we received a warning letter from OEE stating that OEE had not referred the findings of our review for criminal or administrative prosecution and closed the investigation of us without penalty. Based upon its review of the matter, OFAC identified certain apparent violations (“Apparent Violations”) of the Iranian Transactions and Sanctions Regulations by us during the period of in or about March 2008 through in or about February 2011. On March 4, 2014, we entered into a settlement agreement with OFAC resolving this administrative matter. Pursuant to the terms of the settlement agreement, we agreed to make a one-time payment to the U.S. Department of the Treasury in the amount of $504,000 in consideration of OFAC agreeing to release and forever discharge us from any and all civil liability in connection with the Apparent Violations.  We previously accrued a reserve of $1.6 million relating to this matter in fiscal 2010 and, accordingly, reversed the excess of the accrual of $1.1 million as of the effective date of the settlement agreement.

[0001511737-14-000018:mdna:88]
[same as prior period, unchanged from 0001511737-14-000009:mdna:92]

[0001511737-14-000018:mdna:89]
Our products are generally accompanied by a 12 month warranty, which covers both parts and labor. Generally the distributor is responsible for the freight costs associated with warranty returns, and we absorb the freight costs of replacing items under warranty. In accordance with the Financial Accounting Standards Board’s (“FASB’s”), Accounting Standards Codification (“ASC”), 450-30, Loss Contingencies, we record an accrual when we believe it is estimable and probable based upon historical experience. We record a provision for estimated future warranty work in cost of goods sold upon recognition of revenues and we review the resulting accrual regularly and periodically adjust it to reflect changes in warranty estimates.

[0001511737-14-000018:mdna:90]
[same as prior period, unchanged from 0001511737-14-000009:mdna:95]

[0001511737-14-000018:mdna:91]
We have agreed to indemnify our directors, officers and certain other employees for certain events or occurrences, subject to certain limits, while such persons are or were serving at our request in such capacity. We may terminate the indemnification agreements with these persons upon the termination of their services with us but termination will not affect claims for

[0001511737-14-000018:mdna:92]
25

[0001511737-14-000018:mdna:93]
indemnification related to events occurring prior to the effective date of termination. The maximum amount of potential future indemnification is unlimited. We have a Directors and Officers insurance policy that limits our potential exposure. We believe the fair value of these indemnification agreements is minimal. We had not recorded any liabilities for these agreements as of March 31, 2014 or June 30, 2013.

[0001511737-14-000018:mdna:94]
Based upon our historical experience and information known as of the date of this report, we do not believe it is likely that we will have significant liability for the above indemnities at March 31, 2014.

[0001511737-14-000018:mdna:95]
[same as prior period, unchanged from 0001511737-14-000009:mdna:98]

[0001511737-14-000018:mdna:96]
[same as prior period, unchanged from 0001511737-14-000009:mdna:99]

[0001511737-14-000018:mdna:97]
On August 7, 2012, we entered into the Loan Agreement with U.S. Bank, as syndication agent, and East West Bank, as administrative agent for the lenders party to the Loan Agreement.  The Loan Agreement provides for (i) a $50.0 million revolving credit facility, with a $5.0 million sublimit for the issuance of letters of credit and a $5.0 million sublimit for the making of swingline loan advances, and (ii) a $50.0 million Term Loan Facility.  The Loan Agreement replaced a previous agreement whereby we had an existing term loan balance of $29.2 million as of the date of the new Loan Agreement.  On August 7, 2012, we borrowed $20.8 million of term loans under the Term Loan Facility bringing the total borrowed to $50.0 million, and no borrowings remain available thereunder.  On November 21, 2012, we borrowed $10.0 million under the Revolving Credit Facility.  On December 20, 2012 we borrowed an additional $20.0 million under the Revolving Credit Facility, and $20.0 million remained available for borrowing thereunder.  As of March 31, 2014 we made aggregate payments of $7.5 million against the Term Loan Facility.

[0001511737-14-000018:mdna:98]
The following table summarizes our contractual obligations as of March 31, 2014 for the remainder of fiscal 2014 and future fiscal years:

[0001511737-14-000018:mdna:99]
|  | 2014(remainder) |  | 2015 |  | 2016 |  | 2017 |  | 2018 |  | Thereafter |  | Total |
| Operating leases | $ | 633 |  |  | $ | 2,503 |  |  | $ | 2,497 |  |  | $ | 1,537 |  |  | $ | 297 |  |  | $ | 53 |  |  | $ | 7,520 |  |
| Debt payment obligations | 1,250 |  |  | 6,875 |  |  | 39,375 |  |  | 10,000 |  |  | 15,000 |  |  | — |  |  | 72,500 |  |
| Interest payments on debt payment obligations | 446 |  |  | 1,723 |  |  | 1,043 |  |  | 532 |  |  | 125 |  |  | — |  |  | 3,869 |  |
| Total | $ | 2,329 |  |  | $ | 11,101 |  |  | $ | 42,915 |  |  | $ | 12,069 |  |  | $ | 15,422 |  |  | $ | 53 |  |  | $ | 83,889 |  |

[0001511737-14-000018:mdna:100]
On May 5, 2014, we entered into a Credit Agreement with Wells Fargo, the financial institutions named as lenders party therein, and Wells Fargo as administrative agent for the lenders.  In connection with the execution of the Credit Agreement, we terminated and repaid all outstanding obligations under the Term Loan Facility and Revolving Credit Facility under the Loan Agreement described above.  Please see Part 1, Item 1, Note 14 of the Notes to Condensed Consolidated Financial Statements for a full description of the Credit Agreement.

[0001511737-14-000018:mdna:101]
We subcontract with other companies to manufacture our products. During the normal course of business, our contract manufacturers procure components based upon orders placed by us. If we cancel all or part of the orders, we may still be liable to the contract manufacturers for the cost of the components purchased by the subcontractors to manufacture our products. We periodically review the potential liability and to date no significant liabilities for cancellations have been recorded. Our consolidated financial position and results of operations could be negatively impacted if we were required to compensate the contract manufacturers for any unrecorded liabilities incurred.  We had $20.9 million in non-cancelable purchase commitments as of March 31, 2014, the related expenses of which are expected to be incurred in future periods.

[0001511737-14-000018:mdna:102]
As of March 31, 2014, we had $13.8 million of unrecognized tax benefits, substantially all of which would, if recognized, affect our tax expense. We have elected to include interest and penalties related to uncertain tax positions as a component of tax expense. We do not expect any significant increases or decreases to our unrecognized tax benefits in the next twelve months.

[0001511737-14-000018:mdna:103]
[same as prior period, unchanged from 0001511737-14-000009:mdna:105]

[0001511737-14-000018:mdna:104]
For a discussion of recent accounting pronouncements, refer to Note 2 to the Condensed Consolidated Financial Statements.

[0001511737-14-000018:mdna:105]
[same as prior period, unchanged from 0001511737-14-000009:mdna:108]

[0001511737-14-000018:mdna:106]
Regulation G, conditions for use of Non-Generally Accepted Accounting Principles (“Non-GAAP”) financial measures, and other SEC regulations define and prescribe the conditions for use of certain Non-GAAP financial information. To supplement

[0001511737-14-000018:mdna:107]
our condensed consolidated financial results presented in accordance with GAAP, we use Non-GAAP financial measures which are adjusted from the most directly comparable GAAP financial measures to exclude certain items, as described below. Management believes that these Non-GAAP financial measures reflect an additional and useful way of viewing aspects of our operations that, when viewed in conjunction with our GAAP results, provide a more comprehensive understanding of the various factors and trends affecting our business and operations. Non-GAAP financial measures used by us include net income and diluted net income per share.

[0001511737-14-000018:mdna:108]
[same as prior period, unchanged from 0001511737-14-000009:mdna:110]

[0001511737-14-000018:mdna:109]
[same as prior period, unchanged from 0001511737-14-000009:mdna:111]

[0001511737-14-000018:mdna:110]
[same as prior period, unchanged from 0001511737-14-000009:mdna:112]

[0001511737-14-000018:mdna:111]
|  | Three Months Ended March 31, |  | Nine Months Ended March 31, |
|  | 2014 |  | 2013 |  | 2014 |  | 2013 |
|  | (In thousands, except per share amounts) |
| Non-GAAP net income and comprehensive income | $ | 45,151 |  |  | $ | 21,087 |  |  | $ | 129,024 |  |  | $ | 52,998 |  |
| Non-GAAP diluted net income per share of common stock | $ | 0.50 |  |  | $ | 0.24 |  |  | $ | 1.44 |  |  | $ | 0.58 |  |

[0001511737-14-000018:mdna:112]
We believe that providing these Non-GAAP financial measures, in addition to the GAAP financial results, are useful to investors because they allow investors to see our results “through the eyes” of management as these Non-GAAP financial measures reflect our internal measurement processes. Management believes that these Non-GAAP financial measures enable investors to better assess changes in each key element of our operating results across different reporting periods on a consistent basis and provides investors with another method for assessing our operating results in a manner that is focused on the performance of our ongoing operations.The following table shows a reconciliation of GAAP net income and comprehensive income to non-GAAP net income and comprehensive income:

[0001511737-14-000018:mdna:113]
|  | Three Months Ended March 31, |  | Nine Months Ended March 31, |
|  | 2014 |  | 2013 |  | 2014 |  | 2013 |
|  | (In thousands, except pershare amounts) |
| Net income and comprehensive income | $ | 45,199 |  |  | $ | 20,667 |  |  | $ | 127,519 |  |  | $ | 51,649 |  |
| Stock-based compensation: |  |  |  |  |  |  |  |
| Cost of revenues | 153 |  |  | 124 |  |  | 445 |  |  | 309 |  |
| Research and development | 630 |  |  | 324 |  |  | 1,679 |  |  | 991 |  |
| Sales, general and administrative | 258 |  |  | 252 |  |  | 1,506 |  |  | 949 |  |
| Gain on reversal of charge for an export compliance matter | (1,121 | ) |  | — |  |  | (1,121 | ) |  | — |  |
| Tax effect of non-GAAP adjustments | 32 |  |  | (280 | ) |  | (1,004 | ) |  | (900 | ) |
| Non-GAAP net income and comprehensive income | $ | 45,151 |  |  | $ | 21,087 |  |  | $ | 129,024 |  |  | $ | 52,998 |  |
| Non-GAAP diluted net income per share of common stock | $ | 0.50 |  |  | $ | 0.24 |  |  | $ | 1.44 |  |  | $ | 0.58 |  |
| Weighted-average shares used in computing non-GAAP diluted net income per share of common stock | 89,775 |  |  | 88,953 |  |  | 89,667 |  |  | 90,656 |  |

[0001511737-14-000018:mdna:114]
27
