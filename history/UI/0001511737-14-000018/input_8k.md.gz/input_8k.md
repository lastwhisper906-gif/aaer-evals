# UI 8-K — 0001511737-14-000016 filed 2014-05-08

## item codes, every 8-K on or before 2014-05-09

- 2014-05-08 0001511737-14-000016 — 2.02, 9.01
- 2014-04-17 0001193125-14-146710 — 7.01
- 2014-03-06 0001193125-14-084883 — 8.01
- 2014-02-06 0001511737-14-000005 — 2.02, 9.01
- 2013-12-16 0001193125-13-474388 — 5.07
- 2013-11-22 0001193125-13-451511 — 5.02
- 2013-11-07 0001511737-13-000018 — 2.02, 9.01
- 2013-10-28 0001193125-13-413414 — 5.02, 9.01
- 2013-10-18 0001193125-13-404111 — 5.02, 9.01
- 2013-08-08 0001511737-13-000009 — 2.02, 9.01
- 2013-05-09 0001511737-13-000004 — 2.02
- 2013-03-25 0001193125-13-124353 — 5.07
- 2013-03-08 0001193125-13-098334 — 5.02, 9.01
- 2013-02-07 0001193125-13-043701 — 2.02, 9.01
- 2012-12-28 0001193125-12-518487 — 1.01
- 2012-12-17 0001193125-12-503742 — 7.01, 9.01
- 2012-12-13 0001193125-12-501894 — 5.02
- 2012-11-16 0001193125-12-474083 — 5.02
- 2012-11-13 0001193125-12-467376 — 5.02
- 2012-11-08 0001193125-12-460665 — 2.02, 9.01
- 2012-10-10 0001193125-12-420015 — 5.02, 9.01
- 2012-08-13 0001193125-12-352624 — 1.01, 2.03, 9.01
- 2012-08-09 0001193125-12-347776 — 1.01, 9.01
- 2012-08-09 0001193125-12-347732 — 2.02, 9.01
- 2012-05-01 0001193125-12-201012 — 2.02, 9.01
- 2012-03-30 0001193125-12-144074 — 5.02
- 2012-03-27 0001193125-12-134395 — 5.02, 9.01
- 2012-03-22 0001193125-12-127536 — 5.02
- 2012-01-31 0001193125-12-032079 — 2.02, 9.01
- 2011-12-27 0001193125-11-353002 — 1.01, 9.01
- 2011-12-06 0001193125-11-332192 — 5.02
- 2011-11-10 0001193125-11-306969 — 2.02, 9.01

## late-filing notifications on or before 2014-05-09

- none on or before 2014-05-09

## item 2.02 — earnings release, exhibit 99.1

[0001511737-14-000016:8k_2_02:1]
EX-99.1
2
exhibit991q32014.htm
PRESS RELEASE OF UBIQUITI NETWORKS, INC.

[0001511737-14-000016:8k_2_02:2]
Exhibit 99.1 Q3 2014

[0001511737-14-000016:8k_2_02:3]
Exhibit 99.1

[0001511737-14-000016:8k_2_02:4]
UBIQUITI NETWORKS REPORTS RECORD THIRD QUARTER FISCAL 2014 FINANCIAL RESULTS

[0001511737-14-000016:8k_2_02:5]
~ Achieves Record Revenue and Earnings ~

[0001511737-14-000016:8k_2_02:6]
~ Posts Non-GAAP EPS of $0.50 Per Diluted Share ~

[0001511737-14-000016:8k_2_02:7]
San Jose, Calif. - May 8, 2014 - Ubiquiti Networks, Inc. (NASDAQ: UBNT) (“Ubiquiti”), a next-generation communications technology company, today announced results for its third quarter of fiscal 2014 ended March 31, 2014.

[0001511737-14-000016:8k_2_02:8]
Third Quarter Fiscal 2014 Financial Highlights

[0001511737-14-000016:8k_2_02:9]
| • | Revenues of $148.3 million, up 78% year-over-year |

[0001511737-14-000016:8k_2_02:10]
| • | GAAP operating expenses of 10.4% compared to 14.4% in third quarter fiscal 2013 |

[0001511737-14-000016:8k_2_02:11]
| • | GAAP net income of $45.2 million, up 119% year-over-year |

[0001511737-14-000016:8k_2_02:12]
| • | GAAP operating profitability of $50.1 million, up 113% year-over-year |

[0001511737-14-000016:8k_2_02:13]
| • | GAAP and non-GAAP diluted EPS of $0.50, with non-GAAP up 108% year-over-year |

[0001511737-14-000016:8k_2_02:14]
| • | Average days sales outstanding in accounts receivable ("DSO") of 30 days |

[0001511737-14-000016:8k_2_02:15]
Recent Business and Product Highlights

[0001511737-14-000016:8k_2_02:16]
| • | Sustained growth in Service Provider Technology, mainly driven by expansion of core infrastructure build-outs in our wireless markets. |

[0001511737-14-000016:8k_2_02:17]
| • | Strong momentum in Enterprise Technology, primarily due to product expansion and further adoption of our UniFi® technology platform. |

[0001511737-14-000016:8k_2_02:18]
| • | Signed new distribution agreements with Ingram Micro and ScanSource Security, leading technology distributors who will accelerate our expansion into established and emerging markets. |

[0001511737-14-000016:8k_2_02:19]
| • | Launched Ubiquiti World NetworkTM, an alliance of independent Internet Service Providers and supporting U.S. advertising and marketing campaign. Visit www.ubnt.com/uwn to watch success stories of Ubiquiti World NetworkTM early adopters. |

[0001511737-14-000016:8k_2_02:20]
| • | Major extensions of airMAX® and airFiber® product lines, solutions that offer intelligent design and outstanding price performance for fixed wireless deployments worldwide. |

[0001511737-14-000016:8k_2_02:21]
| • | More examples of satisfied Ubiquiti users, such as the Ubiquiti customer stories that can be viewed at www.ubnt.com/customers. |

[0001511737-14-000016:8k_2_02:22]
| • | Refinancing of outstanding credit facility, increasing financial flexibility while substantially lowering our cost of capital. |

[0001511737-14-000016:8k_2_02:23]
Financial Results Summary ($, in millions, except per share data)

[0001511737-14-000016:8k_2_02:24]
| Financials |  | F3Q14 |  | F2Q14 |  | F3Q13 |
| Revenues |  | 148.3 |  | 138.4 |  | 83.2 |
| Service Provider Technology |  | 121.0 |  | 111.4 |  | 75.5 |
| Enterprise Technology |  | 27.3 |  | 27.0 |  | 7.7 |
| Cost of Revenues |  | 82.7 |  | 77.5 |  | 47.7 |
| Gross Profit |  | 65.6 |  | 61.0 |  | 35.5 |
| Total Operating Expenses |  | 15.5 |  | 13.9 |  | 12.0 |
| Income from Operations |  | 50.1 |  | 47.1 |  | 23.5 |
| Net Income |  | 45.2 |  | 41.8 |  | 20.7 |
| Non-GAAP EPS (diluted) |  | 0.50 |  | 0.48 |  | 0.24 |

[0001511737-14-000016:8k_2_02:25]
Third Quarter 2014 Financial Highlights

[0001511737-14-000016:8k_2_02:26]
Total revenue for the third quarter of fiscal 2014 increased 78% to a record $148.3 million, compared with $83.2 million in the third quarter of fiscal 2013.  Service Provider Technology revenues increased $45.5 million, or 60%, from $75.5 million in third quarter of fiscal 2013 to $121.0 million in the third quarter of fiscal 2014.  Enterprise Technology revenues increased $19.7 million, or 256% from $7.7 million in the third quarter of fiscal 2013 to $27.3 million in the third quarter of fiscal 2014.

[0001511737-14-000016:8k_2_02:27]
GAAP net income for the third quarter of fiscal 2014 was $45.2 million, or $0.50 per diluted share, compared with a net income of $20.7 million, or $0.23 per diluted share, in the third quarter of fiscal 2013.  Ubiquiti recorded third quarter fiscal 2014 non-GAAP net income of $45.2 million, or $0.50 per diluted share, compared with non-GAAP net income of $21.1 million, or $0.24 per diluted share, in the third quarter of fiscal 2013.

[0001511737-14-000016:8k_2_02:28]
Ubiquiti’s net cash outflow from operations for the third quarter of fiscal 2014 was $14.0 million, compared to an inflow of $27.6 million in the second quarter of fiscal 2014, and net cash inflow of $35.2 million in the third quarter of fiscal 2013.  The key driver in the change in net cash from operations in the third quarter of fiscal 2014 was our investment in increasing our inventories.  This planned increase in inventory was done to improve lead times for our products to be delivered to our customers.  Total cash and cash equivalents as of March 31, 2014 were $291.7 million, compared to $305.6 million as of December 31, 2013, and $181.7 million as of March 31, 2013.

[0001511737-14-000016:8k_2_02:29]
Average days sales outstanding in accounts receivable ("DSO") was 30 days in the third quarter of fiscal 2014, compared to 24 days in the prior quarter, and 42 days in the third quarter of fiscal 2013.

[0001511737-14-000016:8k_2_02:30]
“We continue to focus investment into R&D to accelerate the vision for our worldwide network of operators and systems integrators,” said Robert J. Pera, Founder and Chief Executive Officer of Ubiquiti Networks.  “We will introduce significant new technology critical to this long-term vision in the second half of this calendar year.”

[0001511737-14-000016:8k_2_02:31]
Commenting on the company’s strong financial results, Craig L. Foster, Ubiquiti’s Chief Financial Officer, added, “The third quarter was another record quarter for Ubiquiti.  We executed on accelerating our R&D and marketing efforts, while maintaining record growth and profitability.  Ubiquiti is highly proficient at translating R&D into future revenue and we will continue to make investments that will grow and diversify our platform offerings.  We continue to quickly evolve and execute on our strategic plans and believe that we are building a dominant platform with a bright future.”

[0001511737-14-000016:8k_2_02:32]
Business Outlook

[0001511737-14-000016:8k_2_02:33]
Based on current business trends, Ubiquiti currently believes the demand environment in its end markets supports the following forecast for the Company's fourth fiscal quarter ending June 30, 2014:

[0001511737-14-000016:8k_2_02:34]
| • | Revenues of between $147 million and $153 million |

[0001511737-14-000016:8k_2_02:35]
| • | GAAP Diluted EPS of between $0.47 and $0.51 |

[0001511737-14-000016:8k_2_02:36]
| • | Non-GAAP Diluted EPS of between $0.48 and $0.52 |

[0001511737-14-000016:8k_2_02:37]
Conference Call Information

[0001511737-14-000016:8k_2_02:38]
Ubiquiti Networks will host a Q&A-only conference call to discuss the Company’s financial results at 2:00 p.m. Pacific Time today.  A transcript of Management’s prepared remarks can be found on the Investor Relations section of the Ubiquiti Networks website, http://ir.ubnt.com.

[0001511737-14-000016:8k_2_02:39]
To listen to the Q&A-only conference call via telephone, dial (877) 291-1296 (U.S. toll-free) or (720) 259-9209 (International) to be connected to the call by an operator. Participants should dial in at least 10 minutes prior to the start of the call.  Investors may also listen to a live webcast of the Q&A-only conference call by visiting the Investor Relations section of the Ubiquiti Networks website, http://ir.ubnt.com.

[0001511737-14-000016:8k_2_02:40]
The recording of the Q&A call will be available approximately two hours after the call concludes and will be accessible on the Investor Relations section of the Ubiquiti Networks website, http://ir.ubnt.com.

[0001511737-14-000016:8k_2_02:41]
About Ubiquiti Networks

[0001511737-14-000016:8k_2_02:42]
Ubiquiti Networks (NASDAQ: UBNT) is closing the digital divide by building network communication platforms for everyone and everywhere.  With over 20 million devices deployed in over 180 countries, Ubiquiti is transforming under-networked businesses and communities. Our leading edge platforms, airMAX®, UniFi®, airFiber®, airVision®, mFi® and EdgeMAX® combine innovative technology, disruptive price performance and the support of a global user community to eliminate barriers to connectivity. For more information, join our community at http://www.ubnt.com.

[0001511737-14-000016:8k_2_02:43]
Ubiquiti, the Ubiquiti logo, Ubiquiti Networks, airMAX, airFiber, airVision, UniFi, mFi, EdgeMAX, and Ubiquiti World Network are registered trademarks or trademarks of Ubiquiti Networks, Inc. and/or its affiliates in the United States and other countries.

[0001511737-14-000016:8k_2_02:44]
Investor Relations Contact

[0001511737-14-000016:8k_2_02:45]
Anne Fazioli

[0001511737-14-000016:8k_2_02:46]
Ubiquiti Networks, Vice President of Investor Relations

[0001511737-14-000016:8k_2_02:47]
IR@ubnt.com

[0001511737-14-000016:8k_2_02:48]
Forward-looking statements are subject to certain risks and uncertainties that could cause our actual future results to differ materially, or cause a material adverse impact on our results.  Potential risks and uncertainties include, but are not limited to, fluctuations in our operating results; varying demand for our products due to the financial and operating condition of our distributors and their customers, distributors' inventory management practices and general economic conditions; impact of counterfeiting and our ability to contain such impact; our reliance on a limited number of distributors; inability of our contract manufacturers and suppliers to meet our demand; our dependence on Qualcomm Atheros for chipsets without a short-term alternative; as we move into new markets competition from certain of our current or potential competitors who may be more established in such markets; our ability to keep pace with technological and market developments; success and timing of new product introductions by us and the performance of our products generally; our ability to effectively manage the significant increase in our transactional sales volumes; we may become subject to warranty claims, product liability and product recalls; that a

[0001511737-14-000016:8k_2_02:49]
substantial majority of our sales are into countries outside the United States and we are subject to numerous U.S. export control and economic sanctions laws; costs related to responding to government inquiries related to regulatory compliance; our reliance on the Ubiquiti Community; our reliance on certain key members of our management team, including our founder and chief executive officer, Robert J. Pera; adverse tax-related matters such as tax audits, changes in our effective tax rate or new tax legislative proposals; whether the final determination of our income tax liability may be materially different from our income tax provisions; the impact of any intellectual property litigation and claims for indemnification and litigation related to U.S. Securities laws and economic and political conditions in the United States and abroad.  We discuss these risks in greater detail under the heading “Risk Factors” and elsewhere in our Annual Report on Form 10-K for the year ended June 30, 2013, subsequent Quarterly Reports on Form 10-Q and other filings filed with the U.S. Securities and Exchange Commission (the SEC), which are available at the SEC's website at www.sec.gov.  Copies may also be obtained by contacting the Ubiquiti Networks Investor Relations Department by email at IR@ubnt.com or by visiting the Investor Relations section of the Ubiquiti Networks website, http://ir.ubnt.com.

[0001511737-14-000016:8k_2_02:50]
Given these uncertainties, you should not place undue reliance on these forward-looking statements.  Also, forward-looking statements represent our management's beliefs and assumptions only as of the date made.  Ubiquiti Networks undertakes no obligation to update information contained in this press release.  You should review our SEC filings carefully and with the understanding that our actual future results may be materially different from what we expect.

[0001511737-14-000016:8k_2_02:51]
Use of Non-GAAP Financial Information

[0001511737-14-000016:8k_2_02:52]
To supplement our condensed consolidated financial results prepared under generally accepted accounting principles, or GAAP, we use non-GAAP measures of net income and earnings per diluted share that are adjusted to exclude certain recurring costs, expenses and gains such as stock based compensation expense, the gain on the reversal of a charge for an export compliance matter and the tax effects of these non-GAAP adjustments.  Reconciliations of the adjustments to GAAP results for the three and nine months ended March 31, 2014 and 2013 are provided below.  In addition, an explanation of the ways in which management uses non-GAAP financial information to evaluate its business, the substance behind management's decision to use this non-GAAP financial information, the material limitations associated with the use of non-GAAP financial information, the manner in which management compensates for those limitations, and the substantive reasons management believes that this non-GAAP financial information provides useful information to investors is included under "About our Non-GAAP Net Income and Adjustments" after the tables below.

[0001511737-14-000016:8k_2_02:53]
These non-GAAP measures are not in accordance with or an alternative to GAAP and may be materially different from other non-GAAP measures, including similarly titled non-GAAP measures, used by other companies.  The presentation of this additional information should not be considered in isolation from, as a substitute for, or superior to, net income or earnings per diluted share prepared in accordance with GAAP.

[0001511737-14-000016:8k_2_02:54]
| Ubiquiti Networks Inc.Condensed Consolidated Statement of Operations(In thousands, except per share data)(Unaudited) |
|  |  | Three Months Ended March 31, |  | Nine Months Ended March 31, |
|  |  | 2014 |  | 2013 |  | 2014 |  | 2013 |
| Revenues |  | $ | 148,331 |  |  | $ | 83,155 |  |  | $ | 416,457 |  |  | $ | 219,591 |  |
| Cost of revenues |  | 82,719 |  |  | 47,690 |  |  | 231,851 |  |  | 128,621 |  |
| Gross profit |  | 65,612 |  |  | 35,465 |  |  | 184,606 |  |  | 90,970 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Research and development |  | 9,413 |  |  | 5,677 |  |  | 23,807 |  |  | 15,440 |  |
| Sales, general and administrative |  | 6,064 |  |  | 6,285 |  |  | 17,648 |  |  | 16,133 |  |
| Total operating expenses |  | 15,477 |  |  | 11,962 |  |  | 41,455 |  |  | 31,573 |  |
| Income from operations |  | 50,135 |  |  | 23,503 |  |  | 143,151 |  |  | 59,397 |  |
| Interest expense and other, net |  | (283 | ) |  | (287 | ) |  | (778 | ) |  | (570 | ) |
| Income before provision for income taxes |  | 49,852 |  |  | 23,216 |  |  | 142,373 |  |  | 58,827 |  |
| Provision for income taxes |  | 4,653 |  |  | 2,549 |  |  | 14,854 |  |  | 7,178 |  |
| Net income |  | $ | 45,199 |  |  | $ | 20,667 |  |  | $ | 127,519 |  |  | $ | 51,649 |  |
| Net income per share of common stock: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.51 |  |  | $ | 0.24 |  |  | $ | 1.45 |  |  | $ | 0.58 |  |
| Diluted |  | $ | 0.50 |  |  | $ | 0.23 |  |  | $ | 1.42 |  |  | $ | 0.57 |  |
| Weighted average shares used in computing net income per share of common stock: |  |  |  |  |  |  |  |  |
| Basic |  | 87,901 |  |  | 87,004 |  |  | 87,656 |  |  | 88,702 |  |
| Diluted |  | 89,775 |  |  | 88,953 |  |  | 89,667 |  |  | 90,656 |  |
| Cash dividends declared per common share |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 0.18 |  |

[0001511737-14-000016:8k_2_02:55]
| Ubiquiti Networks Inc.Reconciliation of GAAP Net Income to Non-GAAP Net Income(In thousands, except per share data)(Unaudited) |
|  |  | Three Months Ended March 31, |  | Nine Months Ended March 31, |
|  |  | 2014 |  | 2013 |  | 2014 |  | 2013 |
| Net income |  | $ | 45,199 |  |  | $ | 20,667 |  |  | $ | 127,519 |  |  | $ | 51,649 |  |
| Stock-based compensation: |  |  |  |  |  |  |  |  |
| Cost of revenues |  | 153 |  |  | 124 |  |  | 445 |  |  | 309 |  |
| Research and development |  | 630 |  |  | 324 |  |  | 1,679 |  |  | 991 |  |
| Sales, general and administrative |  | 258 |  |  | 252 |  |  | 1,506 |  |  | 949 |  |
| Gain on reversal of charge for an export compliance matter |  | (1,121 | ) |  | — |  |  | (1,121 | ) |  | — |  |
| Tax effect of non-GAAP adjustments |  | 32 |  |  | (280 | ) |  | (1,004 | ) |  | (900 | ) |
| Non-GAAP net income |  | $ | 45,151 |  |  | $ | 21,087 |  |  | $ | 129,024 |  |  | $ | 52,998 |  |
| Non-GAAP diluted EPS |  | $ | 0.50 |  |  | $ | 0.24 |  |  | $ | 1.44 |  |  | $ | 0.58 |  |
| Weighted-average shares used in non-GAAP diluted EPS |  | 89,775 |  |  | 88,953 |  |  | 89,667 |  |  | 90,656 |  |

[0001511737-14-000016:8k_2_02:56]
| Ubiquiti Networks Inc.Condensed Consolidated Balance Sheets(In thousands)(Unaudited) |
|  |  | March 31, 2014 |  | June 30, 2013(1) |
| Assets |  |  |  |  |
| Current assets: |  |  |  |  |
| Cash and cash equivalents |  | $ | 291,670 |  |  | $ | 227,826 |  |
| Accounts receivable, net |  | 49,530 |  |  | 35,884 |  |
| Inventories |  | 66,004 |  |  | 15,880 |  |
| Current deferred tax asset |  | 903 |  |  | 733 |  |
| Prepaid income taxes |  | 5,052 |  |  | — |  |
| Prepaid expenses and other current assets |  | 11,578 |  |  | 3,151 |  |
| Total current assets |  | 424,737 |  |  | 283,474 |  |
| Property and equipment, net |  | 7,174 |  |  | 5,976 |  |
| Long-term deferred tax asset |  | — |  |  | 4 |  |
| Other long–term assets |  | 2,662 |  |  | 2,886 |  |
| Total assets |  | $ | 434,573 |  |  | $ | 292,340 |  |
| Liabilities and Stockholders’ Equity |  |  |  |  |
| Current liabilities: |  |  |  |  |
| Accounts payable |  | $ | 46,375 |  |  | $ | 36,187 |  |
| Customer deposits |  | 4,347 |  |  | 5,123 |  |
| Deferred revenues |  | 1,126 |  |  | 691 |  |
| Income taxes payable |  | — |  |  | 1,257 |  |
| Debt - short-term |  | 6,269 |  |  | 5,013 |  |
| Other current liabilities |  | 9,746 |  |  | 11,150 |  |
| Total current liabilities |  | 67,863 |  |  | 59,421 |  |
| Long-term taxes payable |  | 14,012 |  |  | 11,857 |  |
| Debt - long-term |  | 66,139 |  |  | 71,116 |  |
| Deferred revenues - long-term |  | 2,670 |  |  | 2,510 |  |
| Total liabilities |  | 150,684 |  |  | 144,904 |  |
| Stockholders’ equity: |  |  |  |  |
| Common stock |  | 88 |  |  | 87 |  |
| Additional paid–in capital |  | 143,915 |  |  | 134,982 |  |
| Treasury stock |  | (123,864 | ) |  | (123,864 | ) |
| Retained earnings |  | 263,750 |  |  | 136,231 |  |
| Total stockholders’ equity |  | 283,889 |  |  | 147,436 |  |
| Total liabilities and stockholders’ equity |  | $ | 434,573 |  |  | $ | 292,340 |  |

[0001511737-14-000016:8k_2_02:57]
| (1) | Derived from audited consolidated statements as of and for the year ended June 30, 2013. |

[0001511737-14-000016:8k_2_02:58]
| Ubiquiti Networks Inc.Revenues by Product Type (In thousands)(Unaudited) |
|  |  | Three Months Ended March 31, |  | Nine Months Ended March 31, |
|  |  | 2014 |  | 2013 |  | 2014 |  | 2013 |
| Service provider technology |  | $ | 120,987 |  |  | $ | 75,475 |  |  | $ | 326,658 |  |  | $ | 195,262 |  |
| Enterprise technology |  | 27,344 |  |  | 7,680 |  |  | 89,799 |  |  | 24,329 |  |
| Total revenues |  | $ | 148,331 |  |  | $ | 83,155 |  |  | $ | 416,457 |  |  | $ | 219,591 |  |

[0001511737-14-000016:8k_2_02:59]
| Ubiquiti Networks Inc.Revenues by Geographical Area(In thousands)(Unaudited) |
|  |  | Three Months Ended March 31, |  | Nine Months Ended March 31, |
|  |  | 2014 |  | 2013 |  | 2014 |  | 2013 |
| North America |  | $ | 29,178 |  |  | $ | 21,052 |  |  | $ | 99,178 |  |  | $ | 53,519 |  |
| South America |  | 25,059 |  |  | 18,496 |  |  | 73,827 |  |  | 45,820 |  |
| Europe, the Middle East and Africa |  | 77,883 |  |  | 31,617 |  |  | 189,591 |  |  | 90,690 |  |
| Asia Pacific |  | 16,211 |  |  | 11,990 |  |  | 53,861 |  |  | 29,562 |  |
| Total revenues |  | $ | 148,331 |  |  | $ | 83,155 |  |  | $ | 416,457 |  |  | $ | 219,591 |  |

[0001511737-14-000016:8k_2_02:60]
About our Non-GAAP Net Income and Adjustments

[0001511737-14-000016:8k_2_02:61]
Use of Non-GAAP Financial Information

[0001511737-14-000016:8k_2_02:62]
To supplement our condensed consolidated financial results prepared under generally accepted accounting principles, or GAAP, we use non-GAAP measures of net income and earnings per diluted share that are GAAP net income and GAAP earnings per diluted share adjusted to exclude certain recurring costs and non-recurring expenses and gains.

[0001511737-14-000016:8k_2_02:63]
We believe that the presentation of non-GAAP net income and non-GAAP earnings per diluted share provides important supplemental information regarding non-cash expenses, significant recurring items that we believe are important to understanding our financial, and business trends relating to our financial condition and results of operations.  Non-GAAP net income and non-GAAP earnings per diluted share are among the primary indicators used by management as a basis for planning and forecasting future periods and by management and our board of directors to determine whether our operating performance has met specified targets and thresholds.  Management uses non-GAAP net income and non-GAAP earnings per diluted share when evaluating operating performance because it believes that the exclusion of the items described below, for which the amounts and/or timing may vary significantly depending upon the Company's activities and other factors, facilitates comparability of the Company's operating performance from period to period.  We have chosen to provide this information to investors so they can analyze our operating results in the same way that management does and use this information in their assessment of our business and the valuation of our Company.

[0001511737-14-000016:8k_2_02:64]
Use and Economic Substance of Non-GAAP Financial Measures used by Ubiquiti Networks

[0001511737-14-000016:8k_2_02:65]
We compute non-GAAP net income and non-GAAP diluted earnings per share by adjusting GAAP net income and GAAP earnings per diluted share to remove the impact of recurring stock-based compensation expense, the gain on the reversal of a charge for an export compliance matter and the tax effect of these adjustments.  Items excluded from net income are:

[0001511737-14-000016:8k_2_02:66]
| • | Recurring charges and gains, including: |

[0001511737-14-000016:8k_2_02:67]
| ◦ | Stock-based compensation expense is recognized in accordance with FASB Accounting Standards Codification, Topic 718, Stock Compensation. |

[0001511737-14-000016:8k_2_02:68]
| • | Gain on reversal of charge for an export compliance matter |

[0001511737-14-000016:8k_2_02:69]
| • | Tax effect of non-GAAP adjustments. After adjusting to exclude the items described above, we apply the principles of ASC 740, Income Taxes, to estimate the non-GAAP income tax provision. |

[0001511737-14-000016:8k_2_02:70]
Usefulness of Non-GAAP Financial Information to Investors

[0001511737-14-000016:8k_2_02:71]
These non-GAAP measures are not in accordance with, or an alternative to, GAAP and may be materially different from other non-GAAP measures, including similarly titled non-GAAP measures used by other companies.  The presentation of this additional information should not be considered in isolation from, as a substitute for, or superior to, net income or earnings per diluted share prepared in accordance with GAAP.  Non-GAAP financial measures have limitations in that they do not reflect certain items that may have a material impact upon our reported financial results.  We expect to continue to incur expenses of a nature similar to the non-GAAP adjustments described above, and exclusion of these items from our non-GAAP net income and non-GAAP earnings per diluted share should not be construed as an inference that these costs are unusual, infrequent or non-recurring.

[0001511737-14-000016:8k_2_02:72]
For more information on the non-GAAP adjustments, please see the table captioned “Reconciliation of GAAP Net Income to Non-GAAP Net Income” included in this press release.
