# UI MD&A — 0001511737-14-000009


## mdna

[0001511737-14-000009:mdna:1]
[same as prior period, unchanged from 0001511737-13-000021:mdna:1]

[0001511737-14-000009:mdna:2]
[same as prior period, unchanged from 0001511737-13-000021:mdna:2]

[0001511737-14-000009:mdna:3]
[same as prior period, unchanged from 0001511737-13-000021:mdna:3]

[0001511737-14-000009:mdna:4]
We offer a broad and expanding portfolio of networking products and solutions for service providers and enterprises. Our service provider product platforms provide carrier-class network infrastructure for fixed wireless broadband, wireless backhaul

[0001511737-14-000009:mdna:5]
[same as prior period, unchanged from 0001511737-13-000021:mdna:6]

[0001511737-14-000009:mdna:6]
systems and routing. Our enterprise product platforms provide wireless LAN infrastructure, video surveillance products, and machine-to-machine communication components. We believe that our products are highly differentiated due to our proprietary software protocol innovation, firmware expertise, and hardware design capabilities. This differentiation allows our portfolio to meet the demanding performance requirements of video, voice and data applications at prices that are a fraction of those offered by our competitors.

[0001511737-14-000009:mdna:7]
[same as prior period, unchanged from 0001511737-13-000021:mdna:5]

[0001511737-14-000009:mdna:8]
[same as prior period, unchanged from 0001511737-13-000021:mdna:7]

[0001511737-14-000009:mdna:9]
[same as prior period, unchanged from 0001511737-13-000021:mdna:8]

[0001511737-14-000009:mdna:10]
[same as prior period, unchanged from 0001511737-13-000021:mdna:9]

[0001511737-14-000009:mdna:11]
[same as prior period, unchanged from 0001511737-13-000021:mdna:10]

[0001511737-14-000009:mdna:12]
Our revenues increased 85% to $138.4 million in the three months ended December 31, 2013 from $74.9 million in the three months ended December 31, 2012.  Our revenues increased 97% to $268.1 million in the six months ended December 31, 2013 from $136.4 million in the six months ended December 31, 2012.  We believe the overall increase in revenues during the three and six months ended December 31, 2013 was driven by increased adoption of our service provider and enterprise technologies.  Additionally, during three and six months ended December 31, 2012, we believe we experienced lost sales due to the proliferation of counterfeit versions of our products, which also created customer uncertainty regarding the authenticity of their potential purchases.  We believe these factors contributed to a buildup in channel inventory with our distributors, further impacting our revenues.  We had net income of $41.8 million and $17.8 million in the three months ended December 31, 2013 and 2012, respectively.  We had net income of $82.3 million and $31.0 million in the six months ended December 31, 2013 and 2012, respectively.  The increase in net income in both the three and six months ended December 31, 2013 as compared to the same periods in the prior year was primarily due to the increase in revenues.

[0001511737-14-000009:mdna:13]
[same as prior period, unchanged from 0001511737-13-000021:mdna:12]

[0001511737-14-000009:mdna:14]
[same as prior period, unchanged from 0001511737-13-000021:mdna:13]

[0001511737-14-000009:mdna:15]
[same as prior period, unchanged from 0001511737-13-000021:mdna:14]

[0001511737-14-000009:mdna:16]
[same as prior period, unchanged from 0001511737-13-000021:mdna:15]

[0001511737-14-000009:mdna:17]
| • | Service Provider Technology includes our airMAX, EdgeMAX and airFiber platforms, as well as embedded radio products and other 802.11 standard products including base stations, radios, backhaul equipment and Customer Premise Equipment (“CPE”). Additionally, Service Provider Technology includes antennas and other products in the |

[0001511737-14-000009:mdna:18]
2.0 to 6.0GHz spectrum and miscellaneous products such as mounting brackets, cables and power over Ethernet adapters.

[0001511737-14-000009:mdna:19]
[same as prior period, unchanged from 0001511737-13-000021:mdna:17]

[0001511737-14-000009:mdna:20]
We sell substantially all of our products through a limited number of distributors and other channel partners, such as resellers and OEMs. Sales to distributors accounted for 98% and 97% of our revenues in the three months ended December 31, 2013 and 2012, respectively.  Sales to distributors accounted for 98% and 97% of our revenues in the six months ended December 31, 2013 and 2012, respectively.  Other channel partners, such as resellers and OEMs, largely accounted for the balance of our revenues. We sell our products without any right of return.

[0001511737-14-000009:mdna:21]
[same as prior period, unchanged from 0001511737-13-000021:mdna:19]

[0001511737-14-000009:mdna:22]
Our cost of revenues is comprised primarily of the costs of procuring finished goods from our contract manufacturers and chipsets that we consign to certain of our contract manufacturers. In addition, cost of revenues includes tooling, labor and other costs associated with engineering, testing and quality assurance, warranty costs, stock-based compensation, logistics related fees and excess and obsolete inventory.

[0001511737-14-000009:mdna:23]
[same as prior period, unchanged from 0001511737-13-000021:mdna:23]

[0001511737-14-000009:mdna:24]
[same as prior period, unchanged from 0001511737-13-000021:mdna:24]

[0001511737-14-000009:mdna:25]
[same as prior period, unchanged from 0001511737-13-000021:mdna:25]

[0001511737-14-000009:mdna:26]
[same as prior period, unchanged from 0001511737-13-000021:mdna:26]

[0001511737-14-000009:mdna:27]
[same as prior period, unchanged from 0001511737-13-000021:mdna:27]

[0001511737-14-000009:mdna:28]
[same as prior period, unchanged from 0001511737-13-000021:mdna:28]

[0001511737-14-000009:mdna:29]
[same as prior period, unchanged from 0001511737-13-000021:mdna:29]

[0001511737-14-000009:mdna:30]
[same as prior period, unchanged from 0001511737-13-000021:mdna:30]

[0001511737-14-000009:mdna:31]
In the event that collectability of a receivable from products we have shipped is not probable, we classify those amounts as deferred revenues on our balance sheet until such time as we receive payment of the accounts receivable. We classify the cost of products associated with these deferred revenues as deferred costs of revenues.  At December 31, 2013, $2.7 million of revenue was deferred for transactions where we lacked evidence that collectability of the receivables recorded was reasonably assured.  At June 30, 2013, $2.2 million of revenue was deferred for transactions where we lacked evidence that

[0001511737-14-000009:mdna:32]
18

[0001511737-14-000009:mdna:33]
collectability of the receivables recorded was reasonably assured.  The related deferred cost of revenues balance was $1.4 million and $1.2 million at December 31, 2013 and June 30, 2013, respectively.

[0001511737-14-000009:mdna:34]
Also included in our deferred revenues is a portion related to PCS obligations that we estimate we will perform in the future. As of December 31, 2013 and June 30, 2013, we had deferred revenues of $1.3 million and $1.0 million respectively, related to these obligations.

[0001511737-14-000009:mdna:35]
[same as prior period, unchanged from 0001511737-13-000021:mdna:33]

[0001511737-14-000009:mdna:36]
We prepare our condensed consolidated financial statements in accordance with accounting principles generally accepted in the United States of America (“GAAP”). In many cases, the accounting treatment of a particular transaction is specifically dictated by GAAP and does not require management’s judgment in its application. In other cases, management’s judgment is required in selecting among available alternative accounting standards that provide for different accounting treatment for similar transactions. The preparation of condensed consolidated financial statements also requires us to make estimates and assumptions that affect the amounts we report as assets, liabilities, revenues, costs and expenses and affect the related disclosures. We base our estimates on historical experience and other assumptions that we believe are reasonable under the circumstances. In many instances, we could reasonably use different accounting estimates, and in some instances changes in the accounting estimates are reasonably likely to occur from period to period. Accordingly, our actual results could differ significantly from the estimates made by our management. To the extent that there are differences between our estimates and actual results, our future financial statement presentation, financial condition, results of operations and cash flows will be affected. Our critical accounting policies are discussed in our Annual Report on Form 10-K for the fiscal year ended June 30, 2013, as filed on September 13, 2013 with the SEC, or the Annual Report, and there have been no material changes.

[0001511737-14-000009:mdna:37]
[same as prior period, unchanged from 0001511737-13-000021:mdna:36]

[0001511737-14-000009:mdna:38]
Comparison of Three and Six Months Ended December 31, 2013 and 2012

[0001511737-14-000009:mdna:39]
|  | Three Months Ended December 31, |  | Six Months Ended December 31, |
|  | 2013 |  | 2012 |  | 2013 |  | 2012 |
|  | (In thousands, except percentages) |
| Revenues | $ | 138,439 |  |  | 100 | % |  | $ | 74,901 |  |  | 100 | % |  | $ | 268,126 |  |  | 100 | % |  | $ | 136,436 |  |  | 100 | % |
| Cost of revenues | 77,468 |  |  | 56 | % |  | 44,416 |  |  | 59 | % |  | 149,132 |  |  | 56 | % |  | 80,931 |  |  | 59 | % |
| Gross profit | 60,971 |  |  | 44 | % |  | 30,485 |  |  | 41 | % |  | 118,994 |  |  | 44 | % |  | 55,505 |  |  | 41 | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | 8,077 |  |  | 6 | % |  | 5,052 |  |  | 7 | % |  | 14,394 |  |  | 5 | % |  | 9,763 |  |  | 7 | % |
| Sales, general and administrative | 5,774 |  |  | 4 | % |  | 5,314 |  |  | 7 | % |  | 11,584 |  |  | 4 | % |  | 9,848 |  |  | 7 | % |
| Total operating expenses | 13,851 |  |  | 10 | % |  | 10,366 |  |  | 14 | % |  | 25,978 |  |  | 9 | % |  | 19,611 |  |  | 14 | % |
| Income from operations | 47,120 |  |  | 34 | % |  | 20,119 |  |  | 27 | % |  | 93,016 |  |  | 35 | % |  | 35,894 |  |  | 27 | % |
| Interest expense and other, net | (249 | ) |  | * |  |  | (197 | ) |  | * |  |  | (495 | ) |  | * |  |  | (283 | ) |  | * |  |
| Income before provision for income taxes | 46,871 |  |  | 34 | % |  | 19,922 |  |  | 27 | % |  | 92,521 |  |  | 35 | % |  | 35,611 |  |  | 26 | % |
| Provision for income taxes | 5,079 |  |  | 4 | % |  | 2,119 |  |  | 3 | % |  | 10,201 |  |  | 4 | % |  | 4,629 |  |  | 3 | % |
| Net income and comprehensive income | $ | 41,792 |  |  | 30 | % |  | $ | 17,803 |  |  | 24 | % |  | $ | 82,320 |  |  | 31 | % |  | $ | 30,982 |  |  | 23 | % |
| * Less than 1% |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| (1) Includes stock-based compensation as follows: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of revenues | $ | 148 |  |  |  |  | $ | 104 |  |  |  |  | $ | 292 |  |  |  |  | $ | 185 |  |  |  |
| Research and development | 553 |  |  |  |  | 401 |  |  |  |  | 1,049 |  |  |  |  | 667 |  |  |  |
| Sales, general and administrative | 721 |  |  |  |  | 388 |  |  |  |  | 1,248 |  |  |  |  | 697 |  |  |  |
| Total stock-based compensation | $ | 1,422 |  |  |  |  | $ | 893 |  |  |  |  | $ | 2,589 |  |  |  |  | $ | 1,549 |  |  |  |

[0001511737-14-000009:mdna:40]
[same as prior period, unchanged from 0001511737-13-000021:mdna:39]

[0001511737-14-000009:mdna:41]
Revenues increased $63.5 million, or 85%, from $74.9 million in the three months ended December 31, 2012 to $138.4 million in the three months ended December 31, 2013.  Revenues increased $131.7 million, or 97%, from $136.4 million in the six months ended December 31, 2012 to $268.1 million in the six months ended December 31, 2013.  We believe the overall

[0001511737-14-000009:mdna:42]
19

[0001511737-14-000009:mdna:43]
increase in revenues during both the three and six months ended December 31, 2013 was driven by increased adoption of our service provider and enterprise technologies.  Additionally, during the three and six months ended December 31, 2012, we believe we experienced lost sales due to the proliferation of counterfeit versions of our products, which also created customer uncertainty regarding the authenticity of their potential purchases.  We believe these factors contributed to a buildup in channel inventory with our distributors, further impacting our revenues.

[0001511737-14-000009:mdna:44]
In the three and six months ended months ended December 31, 2013, revenues from Customer A represented 17% and 14% of our revenues, respectively.  In the three months ended December 31, 2012, revenues from Customer A and Customer B represented 15% and 14%, respectively.  In the six months ended December 31, 2012, revenues from Customer A represented 12% of our revenues.

[0001511737-14-000009:mdna:45]
[same as prior period, unchanged from 0001511737-13-000021:mdna:42]

[0001511737-14-000009:mdna:46]
|  | Three Months Ended December 31, |  | Six Months Ended December 31, |
|  | 2013 |  | 2012 |  | 2013 |  | 2012 |
|  | (in thousands, except percentages) |
| Service Provider Technology | $ | 111,454 |  |  | 81 | % |  | $ | 68,170 |  |  | 91 | % |  | $ | 205,671 |  |  | 77 | % |  | $ | 119,787 |  |  | 88 | % |
| Enterprise Technology | 26,985 |  |  | 19 | % |  | 6,731 |  |  | 9 | % |  | 62,455 |  |  | 23 | % |  | 16,649 |  |  | 12 | % |
| Total revenues | $ | 138,439 |  |  | 100 | % |  | $ | 74,901 |  |  | 100 | % |  | $ | 268,126 |  |  | 100 | % |  | $ | 136,436 |  |  | 100 | % |

[0001511737-14-000009:mdna:47]
Revenues from Service Provider Technologies increased $43.3 million, or 63%, from $68.2 million in the three months ended December 31, 2012 to $111.5 million in the three months ended December 31, 2013.  Revenues from Service Provider Technologies increased $85.9 million, or 72%, from $119.8 million in the six months ended December 31, 2012 to $205.7 million in the six months ended December 31, 2013.  The increases in both periods were primarily due to continued expansion of core infrastructure build-outs in our wireless markets.  Additionally, we believe we experienced significant lost sales during the three and six months ended December 31, 2012 due to the proliferation of counterfeit versions of our products as discussed above.

[0001511737-14-000009:mdna:48]
Enterprise Technology revenues increased $20.3 million, or 301% from $6.7 million in the three months ended December 31, 2012 to $27.0 million in the three months ended December 31, 2013.  Enterprise Technology revenues increased $45.8 million, or 275% from $16.6 million in the six months ended December 31, 2012 to $62.5 million in the six months ended December 31, 2013.  The increase in Enterprise Technology revenues during both the three and six months ended December 31, 2013 was due primarily to product expansion and further adoption of our UniFi technology platform.

[0001511737-14-000009:mdna:49]
[same as prior period, unchanged from 0001511737-13-000021:mdna:47]

[0001511737-14-000009:mdna:50]
We generally forward products directly from our contract manufacturers to our customers via logistics distribution hubs in Asia.  Beginning in the quarter ended December 31, 2012, our products were predominantly routed through a third party logistics provider in China and prior to the quarter ended December 31, 2012, our products were predominantly delivered to our customers through distribution hubs in Hong Kong.  Our logistics provider, in turn, ships to other locations throughout the world. We have determined the geographical distribution of our product revenues based on our customers' ship-to destinations. A majority of our sales are to distributors who in turn sell to resellers or directly to end customers.  For the three and six months ended December 31, 2013, revenues in all regions increased due to increased adoption of our Service Provider and Enterprise Technologies.  Additionally, during the three and six months ended December 31, 2012, we believe we experienced lost sales due to the proliferation of counterfeit versions of our products, which also created customer uncertainty regarding the authenticity of their potential purchases.

[0001511737-14-000009:mdna:51]
20

[0001511737-14-000009:mdna:52]
The following are our revenues by geography for the three and six months ended December 31, 2013 and 2012 (in thousands, except percentages):

[0001511737-14-000009:mdna:53]
|  | Three Months Ended December 31, |  | Six Months Ended December 31, |
|  | 2013 |  | 2012 |  | 2013 |  | 2012 |
| North America(1) | $ | 32,567 |  |  | 24 | % |  | $ | 12,106 |  |  | 16 | % |  | $ | 70,000 |  |  | 26 | % |  | $ | 32,467 |  |  | 24 | % |
| South America | 27,992 |  |  | 20 | % |  | 17,081 |  |  | 23 | % |  | 48,768 |  |  | 18 | % |  | 27,324 |  |  | 20 | % |
| Europe, the Middle East and Africa | 58,842 |  |  | 42 | % |  | 35,929 |  |  | 48 | % |  | 111,708 |  |  | 42 | % |  | 59,073 |  |  | 43 | % |
| Asia Pacific | 19,038 |  |  | 14 | % |  | 9,785 |  |  | 13 | % |  | 37,650 |  |  | 14 | % |  | 17,572 |  |  | 13 | % |
| Total revenues | $ | 138,439 |  |  | 100 | % |  | $ | 74,901 |  |  | 100 | % |  | $ | 268,126 |  |  | 100 | % |  | $ | 136,436 |  |  | 100 | % |

[0001511737-14-000009:mdna:54]
| (1) | Revenue for the United States was $31.1 million and $11.4 million for the three months ended December 31, 2013 and 2012, respectively. Revenue for the United States was $67.3 million and $30.7 million for the six months ended December 31, 2013 and 2012, respectively. |

[0001511737-14-000009:mdna:55]
[same as prior period, unchanged from 0001511737-13-000021:mdna:51]

[0001511737-14-000009:mdna:56]
Cost of revenues increased $33.1 million, or 74%, from $44.4 million in the three months ended December 31, 2012 to $77.5 million in the three months ended December 31, 2013.  Cost of revenues increased $68.2 million, or 84%, from $80.9 million in the six months ended December 31, 2012 to $149.1 million in the three months ended December 31, 2013.  The increase in cost of revenues in both the three and six months ended December 31, 2013 was primarily due to increased revenues and to a lesser extent, changes in product mix.

[0001511737-14-000009:mdna:57]
Gross profit increased to 44% in the three months ended December 31, 2013 compared to 41% in the three months ended December 31, 2012, and increased to 44% in the six months ended December 31, 2013 compared to 41% in the six months ended December 31, 2012, reflecting a high level of revenue growth, increasing economies of scale and changes in product mix.

[0001511737-14-000009:mdna:58]
[same as prior period, unchanged from 0001511737-13-000021:mdna:54]

[0001511737-14-000009:mdna:59]
[same as prior period, unchanged from 0001511737-13-000021:mdna:55]

[0001511737-14-000009:mdna:60]
Research and development expenses increased $3.0 million, or 60%, from $5.1 million in the three months ended December 31, 2012 to $8.1 million in the three months ended December 31, 2013. As a percentage of revenues, research and development expenses decreased from 7% in the three months ended December 31, 2012 to 6% in the three months ended December 31, 2013.  Research and development expenses increased $4.6 million, or 47%, from $9.8 million in the six months ended December 31, 2012 to $14.4 million in the six months ended December 31, 2013. As a percentage of revenues, research and development expenses decreased from 7% in the six months ended December 31, 2012 to 5% in the six months ended December 31, 2013.  The increase in research and development expenses in absolute dollars in both periods was primarily due to increases in headcount as we broadened our research and development activities to new product areas.  As a percentage of revenues, research and development expenses decreased primarily due to our overall increase in revenues. Over time, we expect our research and development costs to increase in absolute dollars as we continue making significant investments in developing new products and developing new versions of our existing products.

[0001511737-14-000009:mdna:61]
[same as prior period, unchanged from 0001511737-13-000021:mdna:57]

[0001511737-14-000009:mdna:62]
Sales, general and administrative expenses increased $460,000, or 9%, from $5.3 million in the three months ended December 31, 2012 to $5.8 million in the three months ended December 31, 2013.  As a percentage of revenues, sales, general and administrative expenses decreased from 7% in the three months ended December 31, 2012 to 4% in the three months ended December 31, 2013.  Sales, general and administrative expenses increased $1.7 million, or 18%, from $9.8 million in the six months ended December 31, 2012 to $11.6 million in the six months ended December 31, 2013.  As a percentage of revenues, sales, general and administrative expenses decreased from 7% in the six months ended December 31, 2012 to 4% in the six months ended December 31, 2013.  The slight increase in sales, general and administrative expenses in the three months ended December 31, 2013 compared to the same period in the prior year was primarily due to increased marketing activity and headcount to further expand our marketing and administrative functions and increased professional fees to support our revenue growth, partially offset by decreases in legal fees from reduced spending on anti-counterfeiting efforts and decreases to our allowance for doubtful accounts. Sales, general and administrative expenses increased in the six months ended December 31, 2013 compared to the same period in the prior year, primarily due to increased professional fees, primarily related to the ancillary support of certain management functions, increased marketing activity and overall increases in headcount to further

[0001511737-14-000009:mdna:63]
expand our marketing and administrative functions to support our revenue growth, partially offset by decreases in legal fees from reduced spending on anti-counterfeiting efforts and decreases to our allowance for doubtful accounts.  As a percentage of revenues, sales, general and administrative expenses decreased in both periods primarily due to our overall revenue increase. Over time, we expect our sales, general and administrative expenses to increase in absolute dollars due to continued efforts to protect our intellectual property and growth in headcount to support our business and operations.

[0001511737-14-000009:mdna:64]
[same as prior period, unchanged from 0001511737-13-000021:mdna:60]

[0001511737-14-000009:mdna:65]
Interest expense and other, net was $249,000 for the three months ended December 31, 2013, representing an increase of $52,000 from $197,000 for the three months ended December 31, 2012.  Interest expense and other, net was $495,000 for the six months ended December 31, 2013, representing an increase of $212,000 from $283,000 for the six months ended December 31, 2012.  The increase in interest expense and other, net during the three and six months ended December 31, 2013 compared to the same period in the prior year was primarily due to additional interest expense resulting from our increased borrowings from East West Bank during both the three and six months ended December 31, 2012.

[0001511737-14-000009:mdna:66]
[same as prior period, unchanged from 0001511737-13-000021:mdna:62]

[0001511737-14-000009:mdna:67]
Our provision for income taxes increased $3.0 million, or 140%, from $2.1 million for the three months ended December 31, 2012 to $5.1 million for the three months ended December 31, 2013. Our effective tax rate remained flat at 11% for the three months ended December 31, 2013 as compared to the three months ended December 31, 2012.   Our provision for income taxes increased $5.6 million, or 120%, from $4.6 million for the six months ended December 31, 2012 to $10.2 million for the six months ended December 31, 2013. Our effective tax rate decreased to 11% for the six months ended ended December 31, 2013 as compared to 13% in the six months ended December 31, 2012.   The lower effective tax rate in the six months ended December 31, 2013 was primarily due to a larger percentage of our overall profitability occurring in foreign jurisdictions with lower income tax rates.

[0001511737-14-000009:mdna:68]
[same as prior period, unchanged from 0001511737-13-000021:mdna:64]

[0001511737-14-000009:mdna:69]
[same as prior period, unchanged from 0001511737-13-000021:mdna:65]

[0001511737-14-000009:mdna:70]
Since inception, our operations primarily have been funded through cash generated by operations. Cash and cash equivalents increased from $227.8 million at June 30, 2013 to $305.6 million at December 31, 2013.

[0001511737-14-000009:mdna:71]
[same as prior period, unchanged from 0001511737-13-000021:mdna:67]

[0001511737-14-000009:mdna:72]
[same as prior period, unchanged from 0001511737-13-000021:mdna:68]

[0001511737-14-000009:mdna:73]
|  | Six Months Ended December 31, |
|  | 2013 |  | 2012 |
|  | (In thousands) |
| Net cash provided by operating activities | $ | 79,504 |  |  | $ | 50,525 |  |
| Net cash used in investing activities | (1,962 | ) |  | (3,467 | ) |
| Net cash provided by (used in) financing activities | 185 |  |  | (20,817 | ) |
| Net increase in cash and cash equivalents | $ | 77,727 |  |  | $ | 26,241 |  |

[0001511737-14-000009:mdna:74]
[same as prior period, unchanged from 0001511737-13-000021:mdna:70]

[0001511737-14-000009:mdna:75]
Net cash provided by operating activities in the six months ended December 31, 2013 of $79.5 million consisted primarily of net income of $82.3 million partially offset by net changes in operating assets and liabilities that resulted in net cash outflows of $6.4 million. These changes consisted primarily of a $17.4 million increase in inventory due to our efforts to build warehouse stock levels and ultimately decrease lead times, a $13.9 million increase in accounts payable and accrued liabilities due primarily to our increase in cost of revenues, a $2.8 million increase in prepaid taxes due to the timing of federal tax payments, a $1.3 million increase in taxes payable and a and a $1.3 million increase in prepaid expenses and other current assets due to timing of deposit payments with our suppliers.  Additionally, our net income included non-cash adjustments due to stock-based compensation, depreciation and amortization, increases to our provision for inventory obsolescence, decreases in our allowance for doubtful accounts, a write-off of our intangible assets and taxes. The net of these non-cash adjustments resulted in an increase of our net cash provided by operating activities of $3.5 million.

[0001511737-14-000009:mdna:76]
Net cash provided by operating activities in the six months ended December 31, 2012 of $50.5 million consisted primarily of net income of $31.0 million and net changes in operating assets and liabilities that resulted in net cash inflows of $15.2 million. These changes consisted primarily of a $18.5 million decrease in accounts receivable due to decreased revenues and improved cash collections, a $1.7 million increase in accounts payable and accrued liabilities due to the timing of payments with our vendors, a $4.4 million increase in taxes payable due the timing of federal tax payments and a $1.6 million increase in prepaid expenses and other current assets due to an increase in overall business activity. Additionally, our net income included non-cash adjustments due to stock-based compensation, depreciation and amortization, increases to our provision for doubtful accounts and write-downs for inventory obsolescence and an excess tax benefit from stock-based awards. The net of these non-cash adjustments resulted in an increase of our net cash provided by operating activities of $4.3 million.

[0001511737-14-000009:mdna:77]
[same as prior period, unchanged from 0001511737-13-000021:mdna:75]

[0001511737-14-000009:mdna:78]
Our investing activities consist solely of capital expenditures and purchases of intangible assets. Capital expenditures for the six months ended December 31, 2013 and 2012 were $1.8 million and $2.6 million, respectively. Additionally, we had cash outflows related to the purchase of intangible assets of $153,000 and $814,000 during the six months ended December 31, 2013 and 2012, respectively.

[0001511737-14-000009:mdna:79]
[same as prior period, unchanged from 0001511737-13-000021:mdna:77]

[0001511737-14-000009:mdna:80]
On August 7, 2012, we entered into a Loan and Security Agreement (the “Loan Agreement”) with U.S. Bank, as syndication agent, and East West Bank, as administrative agent for the lenders party to the Loan Agreement. The Loan Agreement replaced the EWB Loan Agreement discussed below. The Loan Agreement provides for (i) a $50.0 million revolving credit facility, with a $5.0 million sublimit for the issuance of letters of credit and a $5.0 million sublimit for the making of swingline loan advances (the “Revolving Credit Facility”), and (ii) a $50.0 million term loan facility (the “Term Loan Facility”). We may request borrowings under the Revolving Credit Facility until August 7, 2015. The Loan Agreement replaced a previous agreement whereby we had an existing term loan balance of $29.2 million as of the date of the new Loan Agreement.  On August 7, 2012, we borrowed $20.8 million of term loans under the Term Loan Facility, and no borrowings remain available thereunder. On November 21, 2012, the Company borrowed $10.0 million under the Revolving Credit Facility. On December 20, 2012, the Company borrowed an additional $20.0 million under the Revolving Credit Facility, and $20.0 million remains available for borrowing thereunder.

[0001511737-14-000009:mdna:81]
On August 9, 2012, we announced that our Board of Directors authorized us to repurchase up to $100.0 million of our common stock. The share repurchase program commenced August 13, 2012 and expired on August 12, 2013. During the six months ended December 31, 2012, we repurchased 5,159,050 shares for a total cost of $54.4 million.

[0001511737-14-000009:mdna:82]
On December 14, 2012, we announced that our Board of Directors had authorized a special cash dividend of $0.18 per share for each share of common stock outstanding on December 24, 2012. The aggregate dividend payment of $15.7 million was paid on December 28, 2012 to stockholders of record on December 24, 2012. We do not anticipate paying any cash dividends in the foreseeable future.

[0001511737-14-000009:mdna:83]
[same as prior period, unchanged from 0001511737-13-000021:mdna:80]

[0001511737-14-000009:mdna:84]
We believe our existing cash and cash equivalents, cash provided by operations and the availability of additional funds under our loan agreements will be sufficient to meet our working capital and capital expenditure needs for at least the next 12 months. Our future capital requirements may vary materially from those currently planned and will depend on many factors, including our rate of revenue growth, the timing and extent of spending to support development efforts, the timing of new product introductions, market acceptance of our products and overall economic conditions. As of December 31, 2013, we held $285.9 million of our $305.6 million of cash and cash equivalents in accounts of our subsidiaries outside of the United States and we will incur significant tax liabilities if we decide to repatriate those amounts.

[0001511737-14-000009:mdna:85]
Commitments and Contingencies

[0001511737-14-000009:mdna:86]
In January 2011, the U.S. Department of Commerce’s Bureau of Industry and Security’s Office of Export Enforcement (“OEE”) contacted us to request that we provide information related to our relationship with a logistics company in the United Arab Emirates (“UAE”) and with a company in Iran, as well as information on the export classification of our products. As a result of this inquiry we, assisted by outside counsel, conducted a review of our export transactions from 2008 through March 2011 to not only gather information responsive to the OEE’s request but also to review our overall compliance with export control and sanctions laws. We believe our products have been sold into Iran by third parties. We do not believe that we directly sold, exported or shipped our products into Iran or any other country subject to a U.S. embargo. However, until early 2010, we did not prohibit our distributors from selling our products into Iran or any other country subject to a U.S. embargo. In the course of this review we identified that two distributors may have sold Ubiquiti products into Iran. Our review also found that

[0001511737-14-000009:mdna:87]
23

[0001511737-14-000009:mdna:88]
while we had obtained required Commodity Classification Rulings for our products in June 2010 and November 2010, we did not advise our shipping personnel to change the export authorizations used on our shipping documents until February 2011. During the course of our export control review, we also determined that we had failed to maintain adequate records for the five year period required by the EAR and the sanctions regulations due to our lack of infrastructure and because it was prior to our transition to our current system of record, NetSuite. See “Risk Factors—We are subject to numerous U.S. export control and economic sanctions laws and a substantial majority of our sales are into countries outside of the United States. Although we did not intend to do so, we have violated certain of these laws in the past, and we cannot currently assess the nature and extent of any fines or other penalties, if any, that U.S. governmental agencies may impose against us or our employees for any such violations. Any fines, if materially different from our estimates, or other penalties, could have a material adverse effect on our business and financial results.”

[0001511737-14-000009:mdna:89]
[same as prior period, unchanged from 0001511737-13-000021:mdna:85]

[0001511737-14-000009:mdna:90]
OFAC is still reviewing our disclosure. In our submission, we have provided OFAC with an explanation of the activities that led to the sales of our products in Iran and the failure to comply with the EAR and OFAC sanctions. Although our OFAC and OEE disclosures covered similar sets of facts, which led OEE to resolve the case with the issuance of a warning letter, OFAC may conclude that our actions resulted in violations of U.S. export control and economic sanctions laws and warrant the imposition of penalties that could include fines, termination of our ability to export our products and/or referral for criminal prosecution. The penalties may be imposed against us and/or our management. The maximum civil monetary penalty for the violations is up to $250,000 or twice the value of the transaction, whichever is greater, per violation. Any such fines or restrictions may be material to our financial results in the period in which they are imposed.  Also, disclosure of our conduct and any fines or other action relating to this conduct could harm our reputation and have a material adverse effect on our business. We cannot predict when OFAC will complete its review or decide upon the imposition of possible penalties.

[0001511737-14-000009:mdna:91]
While we have taken actions designed to ensure that export classification information is distributed to the appropriate personnel in a timely manner and have adopted policies and procedures to promote our compliance with applicable export laws and regulations, including obtaining written distribution agreements with substantially all of our distributors that contain covenants requiring compliance with U.S. export control and economic sanctions law; notifying all of our distributors of their obligations and obtaining updated distribution agreements from distributors that account for approximately 99% of our distributor revenue in fiscal 2013.  However we cannot be sure such actions will be effective.  Additionally, our failure to amend all our distribution agreements and to implement more robust compliance controls immediately after the discovery of Iran-related sales activity in early 2010 may be aggravating factors that could impact the imposition of penalties imposed on us or our management.  Based on the facts known to us to date, we recorded an expense of $1.6 million for this export compliance matter in fiscal 2010, which represents management’s estimated exposure for fines in accordance with applicable accounting literature.  This amount was calculated from information discovered through our internal review and we deem this loss to be probable and reasonably estimable. However, we believe that it is reasonably possible that the loss may be higher, but we cannot reasonably estimate the range of any further potential losses. Should additional facts be discovered in the future and/or should actual fines or other penalties substantially differ from our estimates, our business, financial condition, cash flows and results of operations may be materially negatively impacted.

[0001511737-14-000009:mdna:92]
[same as prior period, unchanged from 0001511737-13-000021:mdna:88]

[0001511737-14-000009:mdna:93]
Our products are generally accompanied by a 12 month warranty, which covers both parts and labor. Generally the distributor is responsible for the freight costs associated with warranty returns, and we absorb the freight costs of replacing items under warranty. In accordance with the Financial Accounting Standards Board’s (“FASB’s”), Accounting Standards Codification (“ASC”), 450-30, Loss Contingencies, we record an accrual when we believe it is estimable and probable based upon historical experience. We record a provision for estimated future warranty work in cost of goods sold upon recognition of revenues and we review the resulting accrual regularly and periodically adjust it to reflect changes in warranty estimates.

[0001511737-14-000009:mdna:94]
24

[0001511737-14-000009:mdna:95]
[same as prior period, unchanged from 0001511737-13-000021:mdna:90]

[0001511737-14-000009:mdna:96]
We have agreed to indemnify our directors, officers and certain other employees for certain events or occurrences, subject to certain limits, while such persons are or were serving at our request in such capacity. We may terminate the indemnification agreements with these persons upon the termination of their services with us but termination will not affect claims for indemnification related to events occurring prior to the effective date of termination. The maximum amount of potential future indemnification is unlimited. We have a director and officer insurance policy that limits our potential exposure. We believe the fair value of these indemnification agreements is minimal. We had not recorded any liabilities for these agreements as of December 31, 2013 or June 30, 2013.

[0001511737-14-000009:mdna:97]
Based upon our historical experience and information known as of the date of this report, we do not believe it is likely that we will have significant liability for the above indemnities at December 31, 2013.

[0001511737-14-000009:mdna:98]
[same as prior period, unchanged from 0001511737-13-000021:mdna:94]

[0001511737-14-000009:mdna:99]
We lease our headquarters in San Jose, California and other locations worldwide under non-cancelable operating leases that expire at various dates through fiscal 2019.

[0001511737-14-000009:mdna:100]
On August 7, 2012, we entered into the Loan Agreement with U.S. Bank, as syndication agent, and East West Bank, as administrative agent for the lenders party to the Loan Agreement.  The Loan Agreement provides for (i) a $50.0 million revolving credit facility, with a $5.0 million sublimit for the issuance of letters of credit and a $5.0 million sublimit for the making of swingline loan advances, and (ii) a $50.0 million Term Loan Facility. We may request borrowings under the Revolving Credit Facility until August 7, 2015. The Loan Agreement replaced a previous agreement whereby we had an existing term loan balance of $29.2 million as of the date of the new Loan Agreement.  On August 7, 2012, we borrowed $20.8 million of term loans under the Term Loan Facility bringing the total borrowed to $50.0 million, and no borrowings remain available thereunder.  On November 21, 2012, we borrowed $10.0 million under the Revolving Credit Facility.  On December 20, 2012 we borrowed an additional $20.0 million under the Revolving Credit Facility, and $20.0 million remains available for borrowing thereunder.  As of December 31, 2013 we have made aggregate payments of $6.3 million against the Term Loan Facility.

[0001511737-14-000009:mdna:101]
The following table summarizes our contractual obligations as of December 31, 2013 for the remainder of fiscal 2014 and future fiscal years:

[0001511737-14-000009:mdna:102]
|  | 2014(remainder) |  | 2015 |  | 2016 |  | 2017 |  | 2018 |  | Thereafter |  | Total |
| Operating leases | $ | 1,184 |  |  | $ | 2,494 |  |  | $ | 2,497 |  |  | $ | 1,537 |  |  | $ | 297 |  |  | $ | 53 |  |  | $ | 8,062 |  |
| Debt payment obligations | 2,500 |  |  | 6,875 |  |  | 39,375 |  |  | 10,000 |  |  | 15,000 |  |  | — |  |  | 73,750 |  |
| Interest payments on debt payment obligations | 911 |  |  | 1,723 |  |  | 1,043 |  |  | 532 |  |  | 125 |  |  | — |  |  | 4,334 |  |
| Total | $ | 4,595 |  |  | $ | 11,092 |  |  | $ | 42,915 |  |  | $ | 12,069 |  |  | $ | 15,422 |  |  | $ | 53 |  |  | $ | 86,146 |  |

[0001511737-14-000009:mdna:103]
We subcontract with other companies to manufacture our products. During the normal course of business, our contract manufacturers procure components based upon orders placed by us. If we cancel all or part of the orders, we may still be liable to the contract manufacturers for the cost of the components purchased by the subcontractors to manufacture our products. We periodically review the potential liability and to date no significant liabilities for cancellations have been recorded. Our consolidated financial position and results of operations could be negatively impacted if we were required to compensate the contract manufacturers for any unrecorded liabilities incurred.

[0001511737-14-000009:mdna:104]
As of December 31, 2013, we had $13.2 million of unrecognized tax benefits, substantially all of which would, if recognized, affect our tax expense. We have elected to include interest and penalties related to uncertain tax positions as a component of tax expense. We do not expect any significant increases or decreases to our unrecognized tax benefits in the next twelve months.

[0001511737-14-000009:mdna:105]
[same as prior period, unchanged from 0001511737-13-000021:mdna:101]

[0001511737-14-000009:mdna:106]
In July 2013, the FASB issued a new accounting standard update on the financial statement presentation of unrecognized tax benefits.  The new guidance provides that a liability related to an unrecognized tax benefit would be presented as a reduction of

[0001511737-14-000009:mdna:107]
a deferred tax asset for a new operating loss carryforward, a similar tax loss or a tax credit carryforward if such settlement is required or expected in the event the uncertain tax position is disallowed.  The new guidance will become effective for the Company on July 1, 2014 and it should be applied prospectively to unrecognized tax benefits that exist as of the effective date with retrospective application permitted.  The Company is currently assessing the impact of this new guidance.

[0001511737-14-000009:mdna:108]
[same as prior period, unchanged from 0001511737-13-000021:mdna:103]

[0001511737-14-000009:mdna:109]
Regulation G, conditions for use of Non-Generally Accepted Accounting Principles (“Non-GAAP”) financial measures, and other SEC regulations define and prescribe the conditions for use of certain Non-GAAP financial information. To supplement our condensed consolidated financial results presented in accordance with GAAP, we use Non-GAAP financial measures which are adjusted from the most directly comparable GAAP financial measures to exclude certain items, as described below. Management believes that these Non-GAAP financial measures reflect an additional and useful way of viewing aspects of our operations that, when viewed in conjunction with our GAAP results, provide a more comprehensive understanding of the various factors and trends affecting our business and operations. Non-GAAP financial measures used by us include net income and diluted net income per share.

[0001511737-14-000009:mdna:110]
[same as prior period, unchanged from 0001511737-13-000021:mdna:106]

[0001511737-14-000009:mdna:111]
[same as prior period, unchanged from 0001511737-13-000021:mdna:107]

[0001511737-14-000009:mdna:112]
[same as prior period, unchanged from 0001511737-13-000021:mdna:108]

[0001511737-14-000009:mdna:113]
|  | Three Months Ended December 31, |  | Six Months Ended December 31, |
|  | 2013 |  | 2012 |  | 2013 |  | 2012 |
|  | (In thousands, except per share amounts) |
| Non-GAAP net income and comprehensive income | $ | 42,645 |  |  | $ | 18,339 |  |  | $ | 83,873 |  |  | $ | 31,911 |  |
| Non-GAAP diluted net income per share of common stock | $ | 0.48 |  |  | $ | 0.20 |  |  | $ | 0.94 |  |  | $ | 0.35 |  |

[0001511737-14-000009:mdna:114]
[same as prior period, unchanged from 0001511737-13-000021:mdna:110]

[0001511737-14-000009:mdna:115]
26

[0001511737-14-000009:mdna:116]
[same as prior period, unchanged from 0001511737-13-000021:mdna:111]

[0001511737-14-000009:mdna:117]
|  | Three Months Ended December 31, |  | Six Months Ended December 31, |
|  | 2013 |  | 2012 |  | 2013 |  | 2012 |
|  | (In thousands, except pershare amounts) |
| Net income and comprehensive income | $ | 41,792 |  |  | $ | 17,803 |  |  | $ | 82,320 |  |  | $ | 30,982 |  |
| Stock-based compensation: |  |  |  |  |  |  |  |
| Cost of revenues | 148 |  |  | 104 |  |  | 292 |  |  | 185 |  |
| Research and development | 553 |  |  | 401 |  |  | 1,049 |  |  | 667 |  |
| Sales, general and administrative | 721 |  |  | 388 |  |  | 1,248 |  |  | 697 |  |
| Tax effect of non-GAAP adjustments | (569 | ) |  | (357 | ) |  | (1,036 | ) |  | (620 | ) |
| Non-GAAP net income and comprehensive income | $ | 42,645 |  |  | $ | 18,339 |  |  | $ | 83,873 |  |  | $ | 31,911 |  |
| Non-GAAP diluted net income per share of common stock | $ | 0.48 |  |  | $ | 0.20 |  |  | $ | 0.94 |  |  | $ | 0.35 |  |
| Weighted-average shares used in computing non-GAAP diluted net income per share of common stock | 89,653 |  |  | 90,056 |  |  | 89,593 |  |  | 91,493 |  |
