# UI note change history — 0001511737-13-000021 → 0001511737-14-000009


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- added (2014-02-07):
[0001511737-14-000009:note_history:1]
Certain facilities and equipment are leased under non-cancelable operating leases. The Company generally pays taxes, insurance and maintenance costs on leased facilities and equipment. The Company leases office space in San Jose, California and other locations under various non-cancelable operating leases that expire at various dates through fiscal 2019.

- changed (2014-02-07):
[0001511737-14-000009:note_history:2]
At December 31, 2013, future minimum annual payments under operating leases for the remainder of fiscal 2014 and future fiscal years are as follows (in thousands):
  (was, 2013-11-08, similarity 0.7686):
[0001511737-13-000021:note_history:2]
At September 30, 2013, future minimum annual payments under operating leases are as follows (in thousands):

- changed (2014-02-07):
[0001511737-14-000009:note_history:3]
OFAC is still reviewing the Company’s disclosure. In the Company’s submission, the Company provided OFAC with an explanation of the activities that led to the sales of its products in Iran and the failure to comply with the EAR and OFAC sanctions. Although the Company’s OFAC and OEE disclosures covered similar sets of facts, which led the OEE to resolve the case with the issuance of a warning letter, OFAC may conclude that the Company’s actions resulted in violations of U.S. export control and economic sanctions laws and warrant the imposition of penalties that could include fines, termination of the Company’s ability to export its products, and/or referral for criminal prosecution. The penalties may be imposed against the Company and/or its management. The maximum civil monetary penalty for the violations is up to $250,000 or twice the value of the transaction, whichever is greater, per violation. Any such fines or restrictions may be material to the Company’s financial results in the period in which they are imposed.  The Company cannot predict when OFAC will complete its review or decide upon the imposition of possible penalties.
  (was, 2013-11-08, similarity 0.9913):
[0001511737-13-000021:note_history:3]
OFAC is still reviewing the Company’s voluntary disclosure. In the Company’s submission, the Company provided OFAC with an explanation of the activities that led to the sales of its products in Iran and the failure to comply with the EAR and OFAC sanctions. Although the Company’s OFAC and OEE voluntary disclosures covered similar sets of facts, which led the OEE to resolve the case with the issuance of a warning letter, OFAC may conclude that the Company’s actions resulted in violations of U.S. export control and economic sanctions laws and warrant the imposition of penalties that could include fines, termination of the Company’s ability to export its products, and/or referral for criminal prosecution. The penalties may be imposed against the Company and/or its management. The maximum civil monetary penalty for the violations is up to $250,000 or twice the value of the transaction, whichever is greater, per violation. Any such fines or restrictions may be material to the Company’s financial results in the period in which they are imposed.  The Company cannot predict when OFAC will complete its review or decide upon the imposition of possible penalties.

- removed (2014-02-07):
[0001511737-13-000021:note_history:4]
Certain facilities and equipment are leased under noncancelable operating leases. The Company generally pays taxes, insurance and maintenance costs on leased facilities and equipment. The Company leases office space in San Jose, California and other locations under various non-cancelable operating leases that expire at various dates through 2018.


## us-gaap:BusinessDescriptionAndBasisOfPresentationTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2014-02-07):
[0001511737-14-000009:note_history:5]
Ubiquiti Networks, Inc. and its wholly owned subsidiaries (collectively, “Ubiquiti” or the “Company”) develops high performance networking technology for service providers and enterprises.

- changed (2014-02-07):
[0001511737-14-000009:note_history:6]
These condensed consolidated financial statements should be read in conjunction with the Company’s audited consolidated financial statements for the fiscal year ended June 30, 2013 included in its Annual Report on Form 10-K, as filed on September 13, 2013 with the SEC (the “Annual Report”). The results of operations for the three and six months ended December 31, 2013 are not necessarily indicative of the results to be expected for any future periods.
  (was, 2013-11-08, similarity 0.7784):
[0001511737-13-000021:note_history:6]
These condensed consolidated financial statements should be read in conjunction with the Company’s audited consolidated financial statements for the fiscal year ended June 30, 2013 included in its Annual Report on Form 10-K, as filed on September 13, 2013 with the SEC (the “Annual Report”). The results of operations for the three months ended September 30, 2013 are not necessarily indicative of the results to be expected for any future periods.

- removed (2014-02-07):
[0001511737-13-000021:note_history:7]
Ubiquiti Networks, Inc. and its wholly owned subsidiaries (collectively, “Ubiquiti” or the “Company”) is a product driven company that leverages innovative proprietary technologies to deliver networking solutions to both startup and established network operators and service providers.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2014-02-07):
[0001511737-14-000009:note_history:8]
The Loan Agreement contains customary affirmative and negative covenants, including covenants that limit or restrict the Company and its subsidiaries’ ability to, among other things, incur indebtedness, grant liens, merge or consolidate, dispose of assets, pay dividends or make distributions, make investments, make acquisitions, prepay certain indebtedness, change the nature of its business, enter into certain transactions with affiliates, enter into restrictive agreements, and make capital expenditures, in each case subject to customary exceptions for a credit facility of this size and type. The Company is also required to maintain a minimum debt service coverage ratio, a maximum leverage ratio, and a minimum liquidity ratio.  As of December 31, 2013, the Company was in compliance with all affirmative and negative covenants, debt service coverage ratio, leverage ratio and liquidity ratio requirements.
  (was, 2013-11-08, similarity 0.9961):
[0001511737-13-000021:note_history:8]
The Loan Agreement contains customary affirmative and negative covenants, including covenants that limit or restrict the Company and its subsidiaries’ ability to, among other things, incur indebtedness, grant liens, merge or consolidate, dispose of assets, pay dividends or make distributions, make investments, make acquisitions, prepay certain indebtedness, change the nature of its business, enter into certain transactions with affiliates, enter into restrictive agreements, and make capital expenditures, in each case subject to customary exceptions for a credit facility of this size and type. The Company is also required to maintain a minimum debt service coverage ratio, a maximum leverage ratio, and a minimum liquidity ratio.  As of September 30, 2013, the Company was in compliance with all affirmative and negative covenants, debt service coverage ratio, leverage ratio and liquidity ratio requirements.

- added (2014-02-07):
[0001511737-14-000009:note_history:9]
During the three and six months ended December 31, 2013, the Company made aggregate payments of $1.3 million and $2.5 million, respectively, against the loan balance.  During the three and six months ended December 31, 2012, the Company made aggregate payments of $1.3 million and $1.8 million, respectively, against the loan balance.  As of December 31, 2013, the Company has classified $5.6 million and $68.0 million in short-term and long-term debt, respectively, on its condensed consolidated balance sheet related to the Loan Agreement.

- changed (2014-02-07):
[0001511737-14-000009:note_history:10]
The following table summarizes our estimated debt and interest payment obligations as of December 31, 2013 for the remainder of fiscal 2014 and future fiscal years (in thousands):
  (was, 2013-11-08, similarity 0.7958):
[0001511737-13-000021:note_history:10]
The following table summarizes our estimated debt and interest payment obligations as of September 30, 2013 (in thousands):

- changed (2014-02-07):
[0001511737-14-000009:note_history:11]
|  | 2014 (remainder) |  | 2015 |  | 2016 |  | 2017 |  | 2018 |  | Total |
| Debt payment obligations | $ | 2,500 |  |  | $ | 6,875 |  |  | $ | 39,375 |  |  | $ | 10,000 |  |  | $ | 15,000 |  |  | $ | 73,750 |  |
| Interest payments on debt payment obligations | 911 |  |  | 1,723 |  |  | 1,043 |  |  | 532 |  |  | 125 |  |  | 4,334 |  |
| Total | $ | 3,411 |  |  | $ | 8,598 |  |  | $ | 40,418 |  |  | $ | 10,532 |  |  | $ | 15,125 |  |  | $ | 78,084 |  |
  (was, 2013-11-08, similarity 0.9985):
[0001511737-13-000021:note_history:11]
|  | 2014(remainder) |  | 2015 |  | 2016 |  | 2017 |  | 2018 |  | Total |
| Debt payment obligations | $ | 3,750 |  |  | $ | 6,875 |  |  | $ | 39,375 |  |  | $ | 10,000 |  |  | $ | 15,000 |  |  | $ | 75,000 |  |
| Interest payments on debt payment obligations | 1,383 |  |  | 1,723 |  |  | 1,043 |  |  | 532 |  |  | 125 |  |  | 4,806 |  |
| Total | $ | 5,133 |  |  | $ | 8,598 |  |  | $ | 40,418 |  |  | $ | 10,532 |  |  | $ | 15,125 |  |  | $ | 79,806 |  |

- removed (2014-02-07):
[0001511737-13-000021:note_history:12]
During the three months ended September 30, 2013 and 2012, the Company made aggregate payments of $1.3 million and $583,000, respectively, against the loan balance.  As of September 30, 2013, the Company has classified $5.0 million and $69.9 million in short-term and long-term debt, respectively, on its consolidated balance sheet related to the Loan Agreement.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2014-02-07):
[0001511737-14-000009:note_history:13]
The following table summarizes our estimated debt and interest payment obligations as of December 31, 2013 for the remainder of fiscal 2014 and future fiscal years (in thousands):
  (was, 2013-11-08, similarity 0.7958):
[0001511737-13-000021:note_history:13]
The following table summarizes our estimated debt and interest payment obligations as of September 30, 2013 (in thousands):

- changed (2014-02-07):
[0001511737-14-000009:note_history:14]
|  | 2014 (remainder) |  | 2015 |  | 2016 |  | 2017 |  | 2018 |  | Total |
| Debt payment obligations | $ | 2,500 |  |  | $ | 6,875 |  |  | $ | 39,375 |  |  | $ | 10,000 |  |  | $ | 15,000 |  |  | $ | 73,750 |  |
| Interest payments on debt payment obligations | 911 |  |  | 1,723 |  |  | 1,043 |  |  | 532 |  |  | 125 |  |  | 4,334 |  |
| Total | $ | 3,411 |  |  | $ | 8,598 |  |  | $ | 40,418 |  |  | $ | 10,532 |  |  | $ | 15,125 |  |  | $ | 78,084 |  |
  (was, 2013-11-08, similarity 0.9985):
[0001511737-13-000021:note_history:14]
|  | 2014(remainder) |  | 2015 |  | 2016 |  | 2017 |  | 2018 |  | Total |
| Debt payment obligations | $ | 3,750 |  |  | $ | 6,875 |  |  | $ | 39,375 |  |  | $ | 10,000 |  |  | $ | 15,000 |  |  | $ | 75,000 |  |
| Interest payments on debt payment obligations | 1,383 |  |  | 1,723 |  |  | 1,043 |  |  | 532 |  |  | 125 |  |  | 4,806 |  |
| Total | $ | 5,133 |  |  | $ | 8,598 |  |  | $ | 40,418 |  |  | $ | 10,532 |  |  | $ | 15,125 |  |  | $ | 79,806 |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: no_prior_note, score: 0.0

- added (2014-02-07):
[0001511737-14-000009:note_history:15]
RELATED PARTY TRANSACTIONS AND CERTAIN OTHER TRANSACTIONS

- added (2014-02-07):
[0001511737-14-000009:note_history:16]
On November 13, 2013, the Company entered into an aircraft lease agreement (the "Aircraft Lease Agreement") with RJP Manageco LLC (the "Lessor"), a limited liability company owned by the Company’s CEO, Robert J. Pera. Pursuant to the Aircraft Lease Agreement, the Company may lease an aircraft owned by the Lessor for Company business purposes. Under the Aircraft Lease Agreement, the aircraft may be leased at a rate of $5,000 per flight hour. This hourly rate does not include the cost of flight crew or on-board services, which the Company will purchase from a third-party provider. Expenses incurred will be included in the Company's sales, general and administrative expenses under its Consolidated Statements of Operations.
