# UI notes — 0001511737-14-000009


## us-gaap:BusinessDescriptionAndBasisOfPresentationTextBlock

[0001511737-14-000009:notes:1]
[same as prior period, unchanged from 0001511737-13-000021:notes:1]

[0001511737-14-000009:notes:2]
[same as prior period, unchanged from 0001511737-13-000021:notes:2]

[0001511737-14-000009:notes:3]
Ubiquiti Networks, Inc. and its wholly owned subsidiaries (collectively, “Ubiquiti” or the “Company”) develops high performance networking technology for service providers and enterprises.

[0001511737-14-000009:notes:4]
[same as prior period, unchanged from 0001511737-13-000021:notes:4]

[0001511737-14-000009:notes:5]
[same as prior period, unchanged from 0001511737-13-000021:notes:5]

[0001511737-14-000009:notes:6]
[same as prior period, unchanged from 0001511737-13-000021:notes:6]

[0001511737-14-000009:notes:7]
[same as prior period, unchanged from 0001511737-13-000021:notes:7]

[0001511737-14-000009:notes:8]
These condensed consolidated financial statements should be read in conjunction with the Company’s audited consolidated financial statements for the fiscal year ended June 30, 2013 included in its Annual Report on Form 10-K, as filed on September 13, 2013 with the SEC (the “Annual Report”). The results of operations for the three and six months ended December 31, 2013 are not necessarily indicative of the results to be expected for any future periods.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001511737-14-000009:notes:9]
COMMITMENTS AND CONTINGENCIES

[0001511737-14-000009:notes:10]
Operating Leases

[0001511737-14-000009:notes:11]
Certain facilities and equipment are leased under non-cancelable operating leases. The Company generally pays taxes, insurance and maintenance costs on leased facilities and equipment. The Company leases office space in San Jose, California and other locations under various non-cancelable operating leases that expire at various dates through fiscal 2019.

[0001511737-14-000009:notes:12]
At December 31, 2013, future minimum annual payments under operating leases for the remainder of fiscal 2014 and future fiscal years are as follows (in thousands):

[0001511737-14-000009:notes:13]
|  | 2014(remainder) |  | 2015 |  | 2016 |  | 2017 |  | 2018 |  | Thereafter |  | Total |
| Operating leases | $ | 1,184 |  |  | $ | 2,494 |  |  | $ | 2,497 |  |  | $ | 1,537 |  |  | $ | 297 |  |  | $ | 53 |  |  | $ | 8,062 |  |

[0001511737-14-000009:notes:14]
Purchase Commitments

[0001511737-14-000009:notes:15]
The Company subcontracts with other companies to manufacture its products. During the normal course of business, the Company’s contract manufacturers procure components based upon orders placed by the Company. If the Company cancels all or part of the orders, it may still be liable to the contract manufacturers for the cost of the components purchased by them to manufacture the Company’s products. The Company periodically reviews the potential liability and to date no significant accruals have been recorded.

[0001511737-14-000009:notes:16]
Indemnification Obligations

[0001511737-14-000009:notes:17]
The Company enters into standard indemnification agreements with many of its business partners in the ordinary course of business. These agreements include provisions for indemnifying the business partner against any claim brought by a third party to the extent any such claim alleges that a Ubiquiti product infringes a patent, copyright or trademark, or violates any other proprietary rights of that third party. The maximum potential amount of future payments the Company could be required to make under these indemnification agreements is not estimable and the Company has not incurred any material costs to defend lawsuits or settle claims related to these indemnification agreements to date.

[0001511737-14-000009:notes:18]
Legal Matters

[0001511737-14-000009:notes:19]
The Company may be involved, from time to time, in a variety of claims, lawsuits, investigations, and proceedings relating to contractual disputes, intellectual property rights, employment matters, regulatory compliance matters and other litigation matters relating to various claims that arise in the normal course of business. The Company determines whether an estimated loss from a contingency should be accrued by assessing whether a loss is deemed probable and can be reasonably estimated. The Company assesses its potential liability by analyzing specific litigation and regulatory matters using available information. The Company develops its views on estimated losses in consultation with inside and outside counsel, which involves a subjective analysis of potential results and outcomes, assuming various combinations of appropriate litigation and settlement strategies. Taking all of the above factors into account, the Company records an amount where it is probable that the Company will incur a loss and where that loss can be reasonably estimated. However, the Company’s estimates may be incorrect and the Company could ultimately incur more or less than the amounts initially recorded.  The Company may also incur significant legal fees, which are expensed as incurred, in defending against these claims.

[0001511737-14-000009:notes:20]
Export Compliance Matters

[0001511737-14-000009:notes:21]
In January 2011, the U.S. Commerce Department, Bureau of Industry and Security’s (“BIS”) Office of Export Enforcement (“OEE”) contacted the Company to request that the Company provide information related to its relationship with a logistics company in the United Arab Emirates (“UAE”) and with a company in Iran, as well as information on the export classification of its products. As a result of this inquiry the Company, assisted by outside counsel, conducted a review of the Company's export transactions from 2008 through March 2011 to not only gather information responsive to the OEE's request but also to review the Company's overall compliance with export control and sanctions laws.  The Company believes its products have been sold into Iran by third parties. The Company does not believe that it directly sold, exported or shipped its products into Iran or any other country subject to a U.S. embargo. However, until early 2010, the Company did not prohibit its distributors from selling its products into Iran or any other country subject to a U.S. embargo. In the course of this review the Company identified that two distributors may have sold the Company's products into Iran. The Company's review also found that while it had obtained required Commodity Classification Rulings for its products in June 2010 and November 2010, the Company did not advise its shipping personnel to change the export authorizations used on its shipping documents until February 2011. During the course of the Company's export control review, the Company also determined that it had failed to maintain adequate records for the five year period required by the Export Administration Regulations (the "EAR") and the sanctions regulations due to its lack of infrastructure and because it was prior to its transition to its current system of record, NetSuite.

[0001511737-14-000009:notes:22]
In May 2011, the Company filed a self-disclosure statement with the BIS and OEE.  In June 2011, the Company filed a self-disclosure statement with the U.S. Department of the Treasury’s Office of Foreign Asset Control (“OFAC”) regarding the compliance issues noted above. The disclosures address the above described findings and the remedial actions the Company had taken to date. However, the findings also indicate that both distributors continued to sell, directly or indirectly, the Company’s products into Iran during the period from February 2010 through March 2011 and that the Company received various communications from them indicating that they were continuing to do so. Since January 2011, the Company has cooperated with OEE and, prior to its disclosure filing, the Company informally shared with the OEE the substance of its findings with respect to both distributors. From May 2011 to August 2011, the Company provided additional information regarding its review and its findings to OEE to facilitate its investigation and OEE advised the Company in August 2011 that it had completed its investigation of the Company. In August 2011, the Company received a warning letter from OEE stating that OEE had not referred the findings of the Company’s review for criminal or administrative prosecution and closed the investigation of the Company without penalty.

[0001511737-14-000009:notes:23]
OFAC is still reviewing the Company’s disclosure. In the Company’s submission, the Company provided OFAC with an explanation of the activities that led to the sales of its products in Iran and the failure to comply with the EAR and OFAC sanctions. Although the Company’s OFAC and OEE disclosures covered similar sets of facts, which led the OEE to resolve the case with the issuance of a warning letter, OFAC may conclude that the Company’s actions resulted in violations of U.S. export control and economic sanctions laws and warrant the imposition of penalties that could include fines, termination of the Company’s ability to export its products, and/or referral for criminal prosecution. The penalties may be imposed against the Company and/or its management. The maximum civil monetary penalty for the violations is up to $250,000 or twice the value of the transaction, whichever is greater, per violation. Any such fines or restrictions may be material to the Company’s financial results in the period in which they are imposed.  The Company cannot predict when OFAC will complete its review or decide upon the imposition of possible penalties.

[0001511737-14-000009:notes:24]
The Company has taken actions designed to ensure that export classification information is distributed to the appropriate personnel in a timely manner, and has adopted policies and procedures to promote its compliance with applicable export laws and regulations, including obtaining written distribution agreements with substantially all of its distributors that contain covenants requiring compliance with U.S. export control and economic sanctions law, notifying all of its distributors of their obligations and obtaining updated distribution agreements from distributors that accounted for approximately 99% of its revenue in fiscal 2013.  However the Company cannot be sure such actions will be effective.  Additionally, the Company's failure to amend all its distribution agreements and to implement more robust compliance controls immediately after the discovery of Iran-related sales activity in early 2010 may be aggravating factors that could impact the imposition of penalties imposed on the Company or its management.  Based on the facts known to the Company to date, the Company recorded an expense of $1.6 million for this export compliance matter in fiscal 2010, which represents management’s estimated exposure for fines in accordance with applicable accounting literature. This amount was calculated from information discovered through the Company’s internal review and this loss is deemed to be probable and reasonably estimable. However, the Company also believes that it is reasonably possible that the loss may be higher, but the Company cannot reasonably estimate the range of any further potential losses. Should additional facts be discovered in the future and/or should actual fines or other penalties substantially differ from the Company’s estimates, its business, financial condition, cash flows and results of operations may be materially negatively impacted.

[0001511737-14-000009:notes:25]
Shareholder Class Action Lawsuits

[0001511737-14-000009:notes:26]
Beginning on September 7, 2012, two shareholder class action complaints were filed against the Company, certain of its officers and directors and the underwriters of the Company's initial public offering in the United States District Court for the Northern District of California. On January 30, 2013, the plaintiffs filed an Amended Consolidated Complaint, which alleges claims under the Securities Act of 1933, the Securities Exchange Act of 1934 and SEC Rule 10b-5 on behalf of a purported class of those who purchased the Company's common stock between October 14, 2011 and August 9, 2012 and/or acquired the Company's stock pursuant to or traceable to the registration statement for the initial public offering. The Amended Consolidated Complaint alleges that the defendants violated the federal securities laws by issuing false or misleading statements regarding the sale of counterfeit Company products.  The consolidated complaint seeks, among other things, damages and interest, rescission, and attorneys' fees and costs. On March 26, 2013, the Company filed a motion to dismiss the complaint.  On August 27, 2013, the court held a hearing on the motion to dismiss, and its decision is pending.

[0001511737-14-000009:notes:27]
The Company believes that the allegations in the consolidated complaint are without merit and intend to vigorously contest the litigation. However, there can be no assurance that the Company will be successful in its defense. Because the case is at a very early stage, the Company cannot say that a loss is probable and cannot currently reasonably estimate the loss or the range of possible losses that may be experienced in connection with this litigation.


## us-gaap:DebtDisclosureTextBlock

[0001511737-14-000009:notes:28]
DEBT

[0001511737-14-000009:notes:29]
On August 7, 2012, the Company entered into a Loan and Security Agreement (the “Loan Agreement”) with U.S. Bank, as syndication agent, and East West Bank, as administrative agent for the lenders party to the Loan Agreement.  The Loan Agreement provides for (i) a $50.0 million revolving credit facility, with a $5.0 million sublimit for the issuance of letters of credit and a $5.0 million sublimit for the making of swingline loan advances (the “Revolving Credit Facility”), and (ii) a $50.0 million term loan facility (the “Term Loan Facility”). The Company may request borrowings under the Revolving Credit Facility until August 7, 2015.  The Loan Agreement replaced a previous agreement whereby the Company had an existing term loan balance of $29.2 million as of the date the new Loan Agreement.  On August 7, 2012, the Company borrowed $20.8 million under the Term Loan Facility, and no borrowings remain available for borrowing thereunder.  On November 21, 2012, the Company borrowed $10.0 million under the Revolving Credit Facility. On December 20, 2012, the Company borrowed an additional $20.0 million under the Revolving Credit Facility, and $20.0 million remains available for borrowing thereunder.

[0001511737-14-000009:notes:30]
The loans bear interest, at the Company’s option, at the base rate plus a spread of 1.25% to 1.75% or an adjusted LIBOR rate (at the Company’s election, for a period of 30, 60, or 90 days) plus a spread of 2.25% to 2.75%, in each case with such spread being determined based on the debt service coverage ratio for its most recently ended fiscal quarter. The base rate is the highest of (i) East West Bank’s prime rate, (ii) the federal funds rate plus a margin equal to 0.50%, or (iii) the LIBOR rate plus a margin equal to 1.00%. The Company is also obligated to pay other customary closing fees, arrangement fees, administration fees, commitment fees and letter of credit fees for a credit facility of this size and type.

[0001511737-14-000009:notes:31]
Interest is due and payable monthly in arrears in the case of loans bearing interest at the base rate and at the end of an interest period in the case of loans bearing interest at the adjusted LIBOR rate. Principal payments under the Term Loan Facility will be made in quarterly installments on the first day of each calendar quarter, and each such quarterly installment shall be equal to $1.25 million through July 1, 2014, then equal to $1.875 million from October 1, 2014 through July 1, 2015, and then equal to $2.5 million from October 1, 2015 through July 1, 2017, with the remaining outstanding principal balance and all accrued and unpaid interest due on August 7, 2017. All outstanding loans under the Revolving Credit Facility, together with all accrued and unpaid interest, are due on August 7, 2015.

[0001511737-14-000009:notes:32]
The Company may prepay the loans, in whole or in part, at any time without premium or penalty, subject to certain conditions including minimum amounts and reimbursement of certain costs in the case of prepayments of LIBOR loans. In addition, the Company is required to prepay the loan under the Term Loan Facility with (i) the proceeds from certain financing transactions or asset sales (subject, in the case of asset sales, to reinvestment rights) and (ii) 25.0% of the Company’s excess cash flow in the U.S., as determined after each fiscal year and in accordance with the Loan Agreement, provided that the Company shall not be required to prepay the loan out of its excess cash flow if its leverage ratio is greater than 1.50:1.00 on the last day of such fiscal year.

[0001511737-14-000009:notes:33]
All of the obligations of the Company under the Loan Agreement are collateralized by substantially all of the Company’s assets, including all of the capital stock of the Company’s future domestic subsidiaries and 65% of the capital stock of the Company’s existing and future foreign subsidiaries, but excluding the Company’s intellectual property, which is subject to a negative pledge agreement. All of the Company’s future domestic subsidiaries are required to guaranty the obligations under the Loan Agreement. Such guarantees by future subsidiaries will be collateralized by substantially all of the property of such subsidiaries, excluding intellectual property.

[0001511737-14-000009:notes:34]
The Loan Agreement contains customary affirmative and negative covenants, including covenants that limit or restrict the Company and its subsidiaries’ ability to, among other things, incur indebtedness, grant liens, merge or consolidate, dispose of assets, pay dividends or make distributions, make investments, make acquisitions, prepay certain indebtedness, change the nature of its business, enter into certain transactions with affiliates, enter into restrictive agreements, and make capital expenditures, in each case subject to customary exceptions for a credit facility of this size and type. The Company is also required to maintain a minimum debt service coverage ratio, a maximum leverage ratio, and a minimum liquidity ratio.  As of December 31, 2013, the Company was in compliance with all affirmative and negative covenants, debt service coverage ratio, leverage ratio and liquidity ratio requirements.

[0001511737-14-000009:notes:35]
The Loan Agreement includes customary events of default that include, among other things, defaults for the failure to timely pay principal, interest, or other amounts due, defaults due to the inaccuracy of representations and warranties, covenant defaults, a cross default to material indebtedness, bankruptcy and insolvency defaults, material judgment defaults, defaults due to the unenforceability of a guaranty, and defaults due to circumstances that have or could reasonably be expected to have a material adverse effect on the Company's business, operations or financial condition, its ability to pay or perform under the Loan Agreement, or on the lenders' security interests. The occurrence of an event of default could result in the acceleration of the obligations under the Loan Agreement. During the existence of an event of default, interest on the obligations under the Loan Agreement could be increased by 2.00% above the otherwise applicable interest rate.

[0001511737-14-000009:notes:36]
During the three and six months ended December 31, 2013, the Company made aggregate payments of $1.3 million and $2.5 million, respectively, against the loan balance.  During the three and six months ended December 31, 2012, the Company made aggregate payments of $1.3 million and $1.8 million, respectively, against the loan balance.  As of December 31, 2013, the Company has classified $5.6 million and $68.0 million in short-term and long-term debt, respectively, on its condensed consolidated balance sheet related to the Loan Agreement.

[0001511737-14-000009:notes:37]
The following table summarizes our estimated debt and interest payment obligations as of December 31, 2013 for the remainder of fiscal 2014 and future fiscal years (in thousands):

[0001511737-14-000009:notes:38]
|  | 2014 (remainder) |  | 2015 |  | 2016 |  | 2017 |  | 2018 |  | Total |
| Debt payment obligations | $ | 2,500 |  |  | $ | 6,875 |  |  | $ | 39,375 |  |  | $ | 10,000 |  |  | $ | 15,000 |  |  | $ | 73,750 |  |
| Interest payments on debt payment obligations | 911 |  |  | 1,723 |  |  | 1,043 |  |  | 532 |  |  | 125 |  |  | 4,334 |  |
| Total | $ | 3,411 |  |  | $ | 8,598 |  |  | $ | 40,418 |  |  | $ | 10,532 |  |  | $ | 15,125 |  |  | $ | 78,084 |  |


## us-gaap:DeferredCostsCapitalizedPrepaidAndOtherAssetsDisclosureTextBlock

[0001511737-14-000009:notes:39]
[same as prior period, unchanged from 0001511737-13-000021:notes:39]

[0001511737-14-000009:notes:40]
|  | December 31, 2013 |  | June 30, 2013 |
| Non-trade receivables | $ | 1,546 |  |  | $ | 2,203 |  |
| Other current assets | 2,879 |  |  | 948 |  |
|  | $ | 4,425 |  |  | $ | 3,151 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001511737-14-000009:notes:41]
[same as prior period, unchanged from 0001511737-13-000021:notes:41]

[0001511737-14-000009:notes:42]
[same as prior period, unchanged from 0001511737-13-000021:notes:42]

[0001511737-14-000009:notes:43]
The Company’s 2010 Equity Incentive Plan and 2005 Equity Incentive Plan are described in its Annual Report. As of December 31, 2013, the Company had 5,620,284 authorized shares available for future issuance under all of its stock incentive plans.

[0001511737-14-000009:notes:44]
[same as prior period, unchanged from 0001511737-13-000021:notes:44]

[0001511737-14-000009:notes:45]
The following table shows total stock-based compensation expense included in the Condensed Consolidated Statements of Operations for the three and six months ended December 31, 2013 and 2012 (in thousands):

[0001511737-14-000009:notes:46]
|  | Three Months Ended December 31, |  | Six Months Ended December 31, |
|  | 2013 |  | 2012 |  | 2013 |  | 2012 |
| Cost of sales | $ | 148 |  |  | $ | 104 |  |  | $ | 292 |  |  | $ | 185 |  |
| Research and development | 553 |  |  | 401 |  |  | 1,049 |  |  | 667 |  |
| Sales, general and administrative | 721 |  |  | 388 |  |  | 1,248 |  |  | 697 |  |
|  | $ | 1,422 |  |  | $ | 893 |  |  | $ | 2,589 |  |  | $ | 1,549 |  |

[0001511737-14-000009:notes:47]
[same as prior period, unchanged from 0001511737-13-000021:notes:47]

[0001511737-14-000009:notes:48]
The following is a summary of option activity for the Company’s stock incentive plans for the six months ended December 31, 2013:

[0001511737-14-000009:notes:49]
|  | Common Stock Options Outstanding |
|  | Numberof Shares |  | WeightedAverageExercisePrice |  | WeightedAverageRemainingContractualLife (Years) |  | AggregateIntrinsicValue |
|  |  |  |  |  |  |  | (In thousands) |
| Balance, June 30, 2013 | 3,614,262 |  |  | $ | 3.07 |  |  |  |  |  |
| Exercised | (455,980 | ) |  | 2.20 |  |  |  |  |  |
| Forfeitures and cancellations | (107,318 | ) |  | 10.55 |  |  |  |  |  |
| Balance, December 31, 2013 | 3,050,964 |  |  | $ | 2.93 |  |  | 5.65 |  | $ | 131,270 |  |
| Vested and expected to vest as of December 31, 2013 | 3,016,040 |  |  | $ | 2.85 |  |  | 5.61 |  | $ | 130,033 |  |
| Vested and exercisable as of December 31, 2013 | 2,421,183 |  |  | $ | 1.30 |  |  | 4.97 |  | $ | 108,131 |  |

[0001511737-14-000009:notes:50]
During the three months ended December 31, 2013 and 2012, the aggregate intrinsic value of options exercised under the Company’s stock incentive plans was $3.8 million and $185,000, respectively, as determined as of the date of option exercise. During the six months ended December 31, 2013 and 2012, the aggregate intrinsic value of options exercised under the Company’s stock incentive plans was $13.7 million and $363,000, respectively, as determined as of the date of option exercise.

[0001511737-14-000009:notes:51]
As of December 31, 2013, the Company had unrecognized compensation costs of $2.6 million related to stock options which the Company expects to recognize over a weighted-average period of 2.6 years. Future option grants will increase the amount of compensation expense to be recorded in these periods.

[0001511737-14-000009:notes:52]
The Company estimates the fair value of employee stock options using the Black-Scholes option pricing model. The fair value of employee stock options is being amortized on a straight-line basis over the requisite service period of the awards.  The Company did not grant any employee stock options during the three and six months ended December 31, 2013.   For the three and six months ended December 31, 2012, the fair value of employee stock options was estimated using the following weighted average assumptions:

[0001511737-14-000009:notes:53]
|  | Three And Six Months Ended December 31, 2012 |
| Expected term | 6.1 years |  |
| Expected volatility | 52 | % |
| Risk-free interest rate | 0.8 | % |
| Expected dividend yield | — |  |
| Weighted average grant date fair value | $ | 5.37 |  |

[0001511737-14-000009:notes:54]
[same as prior period, unchanged from 0001511737-13-000021:notes:53]

[0001511737-14-000009:notes:55]
[same as prior period, unchanged from 0001511737-13-000021:notes:54]

[0001511737-14-000009:notes:56]
|  | Number of Shares |  | Weighted Average Grant Date Fair Value |
| Non-vested RSUs, June 30, 2013 | 744,906 |  |  | $ | 14.74 |  |
| RSUs granted | 77,033 |  |  | 32.48 |  |
| RSUs vested | (100,431 | ) |  | 16.09 |  |
| RSUs canceled | (188,905 | ) |  | 14.98 |  |
| Non-vested RSUs, December 31, 2013 | 532,603 |  |  | $ | 16.96 |  |

[0001511737-14-000009:notes:57]
The intrinsic value of RSUs vested in the three months ended December 31, 2013 and 2012 was $1.5 million and $142,000, respectively.  The intrinsic value of RSUs vested in the six months ended December 31, 2013 and 2012 was $2.9 million and $233,000, respectively.

[0001511737-14-000009:notes:58]
As of December 31, 2013, there was unrecognized compensation costs related to RSUs of $7.0 million which the Company expects to recognize over a weighted average period of 3.2 years.


## us-gaap:EarningsPerShareTextBlock

[0001511737-14-000009:notes:59]
[same as prior period, unchanged from 0001511737-13-000021:notes:58]

[0001511737-14-000009:notes:60]
[same as prior period, unchanged from 0001511737-13-000021:notes:59]

[0001511737-14-000009:notes:61]
|  | Three Months Ended December 31, |  | Six Months Ended December 31, |
|  | 2013 |  | 2012 |  | 2013 |  | 2012 |
| Numerator: |  |  |  |
| Net income attributable to common stockholders | $ | 41,792 |  |  | $ | 17,803 |  |  | $ | 82,320 |  |  | $ | 30,982 |  |
| Denominator: |  |  |  |
| Weighted-average shares used in computing basic net income per share | 87,661 |  |  | 88,094 |  |  | 87,536 |  |  | 89,532 |  |
| Add—dilutive potential common shares: |  |  |  |  |  |  |  |
| Stock options | 1,747 |  |  | 1,806 |  |  | 1,795 |  |  | 1,808 |  |
| Restricted stock units | 245 |  |  | 156 |  |  | 262 |  |  | 153 |  |
| Weighted-average shares used in computing diluted net income per share | 89,653 |  |  | 90,056 |  |  | 89,593 |  |  | 91,493 |  |
| Net income per share of common stock: |  |  |  |
| Basic | $ | 0.48 |  |  | $ | 0.20 |  |  | $ | 0.94 |  |  | $ | 0.35 |  |
| Diluted | $ | 0.47 |  |  | $ | 0.20 |  |  | $ | 0.92 |  |  | $ | 0.34 |  |

[0001511737-14-000009:notes:62]
The Company excludes potentially dilutive securities from its diluted net income per share calculation when their effect would be antidilutive to net income per share amounts.  The following table summarizes the total potential shares of common stock that were excluded from the diluted per share calculation, because to include them would have been anti-dilutive for the period (in thousands):

[0001511737-14-000009:notes:63]
|  | Three Months Ended December 31, |  | Six Months Ended December 31, |
|  | 2013 |  | 2012 |  | 2013 |  | 2012 |
| Stock options | — |  |  | 355 |  |  | 1 |  |  | 196 |  |
| Restricted stock units | 9 |  |  | 367 |  |  | 32 |  |  | 340 |  |
|  | 9 |  |  | 722 |  |  | 33 |  |  | 536 |  |


## us-gaap:FairValueAssetsAndLiabilitiesMeasuredOnRecurringAndNonrecurringBasisTableTextBlock

[0001511737-14-000009:notes:64]
As of December 31, 2013 and June 30, 2013, the fair value hierarchy for the Company’s financial liabilities was as follows (in thousands):

[0001511737-14-000009:notes:65]
|  | December 31, 2013 |  | June 30, 2013 |
|  | FairValue |  | Level 1 |  | Level 2 |  | Level 3 |  | FairValue |  | Level 1 |  | Level 2 |  | Level 3 |
| Debt | $ | 73,648 |  |  | $ | — |  |  | $ | 73,648 |  |  | $ | — |  |  | $ | 76,129 |  |  | $ | — |  |  | $ | 76,129 |  |  | $ | — |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001511737-14-000009:notes:66]
[same as prior period, unchanged from 0001511737-13-000021:notes:65]

[0001511737-14-000009:notes:67]
[same as prior period, unchanged from 0001511737-13-000021:notes:66]

[0001511737-14-000009:notes:68]
[same as prior period, unchanged from 0001511737-13-000021:notes:67]

[0001511737-14-000009:notes:69]
[same as prior period, unchanged from 0001511737-13-000021:notes:68]

[0001511737-14-000009:notes:70]
[same as prior period, unchanged from 0001511737-13-000021:notes:69]

[0001511737-14-000009:notes:71]
The Company did not have any financial assets recorded at fair value at December 31, 2013 or June 30, 2013.  At December 31, 2013 and June 30, 2013 the Company had debt associated with its Loan and Security Agreement with East West Bank (see Note 7). The fair value of the Company’s debt was estimated based on the current rates offered to the Company for debt with similar terms and remaining maturities and was determined to be a Level 2 measurement.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001511737-14-000009:notes:72]
[same as prior period, unchanged from 0001511737-13-000021:notes:71]

[0001511737-14-000009:notes:73]
As of December 31, 2013, the Company had approximately $13.2 million of unrecognized tax benefits, substantially all of which would, if recognized, affect its tax expense. The Company has elected to include interest and penalties related to uncertain tax positions as a component of tax expense. At December 31, 2013, an insignificant amount of interest and penalties are included in long-term income tax payable. The Company recorded an increase of its unrecognized tax benefits of $1.0 million for the three months ended December 31, 2013. The Company does not expect any significant increases or decreases to its unrecognized tax benefits in the next twelve months.

[0001511737-14-000009:notes:74]
The Company recorded income tax provisions of $5.1 million and $10.2 million for the three and six months ended December 31, 2013, respectively. The Company’s estimated 2014 effective tax rate differs from the U.S. statutory rate primarily due to profits earned in jurisdictions where the tax rate is lower than the U.S. tax rate.

[0001511737-14-000009:notes:75]
[same as prior period, unchanged from 0001511737-13-000021:notes:74]


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001511737-14-000009:notes:76]
Recent Accounting Pronouncements

[0001511737-14-000009:notes:77]
In July 2013, the FASB issued a new accounting standard update on the financial statement presentation of unrecognized tax benefits.  The new guidance provides that a liability related to an unrecognized tax benefit would be presented as a reduction of a deferred tax asset for a new operating loss carryforward, a similar tax loss or a tax credit carryforward if such settlement is required or expected in the event the uncertain tax position is disallowed.  The new guidance will become effective for the Company on July 1, 2014 and it should be applied prospectively to unrecognized tax benefits that exist as of the effective date with retrospective application permitted.  The Company is currently assessing the impact of this new guidance.


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001511737-14-000009:notes:78]
[same as prior period, unchanged from 0001511737-13-000021:notes:77]

[0001511737-14-000009:notes:79]
[same as prior period, unchanged from 0001511737-13-000021:notes:78]

[0001511737-14-000009:notes:80]
[same as prior period, unchanged from 0001511737-13-000021:notes:79]

[0001511737-14-000009:notes:81]
|  | Six Months Ended December 31, |
|  | 2013 |  | 2012 |
| Beginning balance | $ | 2,913 |  |  | $ | 1,381 |  |
| Accruals for warranties issued during the period | 2,698 |  |  | 1,684 |  |
| Warranty costs incurred during the period | (2,036 | ) |  | (1,115 | ) |
|  | $ | 3,575 |  |  | $ | 1,950 |  |


## us-gaap:PropertyPlantAndEquipmentScheduleOfSignificantAcquisitionsAndDisposalsTextBlock

[0001511737-14-000009:notes:82]
[same as prior period, unchanged from 0001511737-13-000021:notes:81]

[0001511737-14-000009:notes:83]
|  | December 31, 2013 |  | June 30, 2013 |
| Testing equipment | $ | 3,642 |  |  | $ | 3,309 |  |
| Computer and other equipment | 946 |  |  | 841 |  |
| Tooling equipment | 2,633 |  |  | 1,737 |  |
| Furniture and fixtures | 727 |  |  | 652 |  |
| Leasehold improvements | 2,421 |  |  | 1,858 |  |
| Software | 245 |  |  | 245 |  |
|  | 10,614 |  |  | 8,642 |  |
| Less: Accumulated depreciation and amortization | (3,821 | ) |  | (2,666 | ) |
|  | $ | 6,793 |  |  | $ | 5,976 |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001511737-14-000009:notes:84]
RELATED PARTY TRANSACTIONS AND CERTAIN OTHER TRANSACTIONS

[0001511737-14-000009:notes:85]
On November 13, 2013, the Company entered into an aircraft lease agreement (the "Aircraft Lease Agreement") with RJP Manageco LLC (the "Lessor"), a limited liability company owned by the Company’s CEO, Robert J. Pera. Pursuant to the Aircraft Lease Agreement, the Company may lease an aircraft owned by the Lessor for Company business purposes. Under the Aircraft Lease Agreement, the aircraft may be leased at a rate of $5,000 per flight hour. This hourly rate does not include the cost of flight crew or on-board services, which the Company will purchase from a third-party provider. Expenses incurred will be included in the Company's sales, general and administrative expenses under its Consolidated Statements of Operations.


## us-gaap:ScheduleOfAccruedLiabilitiesTableTextBlock

[0001511737-14-000009:notes:86]
[same as prior period, unchanged from 0001511737-13-000021:notes:83]

[0001511737-14-000009:notes:87]
|  | December 31, 2013 |  | June 30, 2013 |
| Accrued compensation and benefits | $ | 3,258 |  |  | $ | 2,712 |  |
| Accrued accounts payable | 479 |  |  | 323 |  |
| Accrual for an export compliance matter | 1,625 |  |  | 1,625 |  |
| Warranty accrual | 3,575 |  |  | 2,913 |  |
| Other accruals | 4,016 |  |  | 3,577 |  |
|  | $ | 12,953 |  |  | $ | 11,150 |  |


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0001511737-14-000009:notes:88]
[same as prior period, unchanged from 0001511737-13-000021:notes:85]

[0001511737-14-000009:notes:89]
|  | December 31, 2013 |  | June 30, 2013 |
| Finished goods | $ | 32,136 |  |  | $ | 15,618 |  |
| Raw materials | 187 |  |  | 262 |  |
|  | $ | 32,323 |  |  | $ | 15,880 |  |


## us-gaap:ScheduleOfOtherAssetsNoncurrentTextBlock

[0001511737-14-000009:notes:90]
[same as prior period, unchanged from 0001511737-13-000021:notes:87]

[0001511737-14-000009:notes:91]
|  | December 31, 2013 |  | June 30, 2013 |
| Intangible assets, net | $ | 958 |  |  | $ | 1,029 |  |
| Long-term deferred cost of revenues | 1,431 |  |  | 1,185 |  |
| Other long-term assets | 716 |  |  | 672 |  |
|  | $ | 3,105 |  |  | $ | 2,886 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001511737-14-000009:notes:92]
[same as prior period, unchanged from 0001511737-13-000021:notes:89]

[0001511737-14-000009:notes:93]
[same as prior period, unchanged from 0001511737-13-000021:notes:90]

[0001511737-14-000009:notes:94]
| • | Service Provider Technology includes the Company's airMAX, EdgeMAX and airFiber platforms, as well as embedded radio products and other 802.11 standard products including base stations, radios, backhaul equipment and Customer Premise Equipment (“CPE”). Additionally, Service Provider Technology includes antennas and other products in the 2.0 to 6.0GHz spectrum and miscellaneous products such as mounting brackets, cables and power over Ethernet adapters. |

[0001511737-14-000009:notes:95]
[same as prior period, unchanged from 0001511737-13-000021:notes:92]

[0001511737-14-000009:notes:96]
Revenues by product type for the three and six months ended December 31, 2013 and 2012 were as follows (in thousands, except percentages):

[0001511737-14-000009:notes:97]
|  | Three Months Ended December 31, |  | Six Months Ended December 31, |
|  | 2013 |  | 2012 |  | 2013 |  | 2012 |
| Service Provider Technology | $ | 111,454 |  |  | 81 | % |  | $ | 68,170 |  |  | 91 | % |  | $ | 205,671 |  |  | 77 | % |  | $ | 119,787 |  |  | 88 | % |
| Enterprise Technology | 26,985 |  |  | 19 | % |  | 6,731 |  |  | 9 | % |  | 62,455 |  |  | 23 | % |  | 16,649 |  |  | 12 | % |
| Total revenues | $ | 138,439 |  |  | 100 | % |  | $ | 74,901 |  |  | 100 | % |  | $ | 268,126 |  |  | 100 | % |  | $ | 136,436 |  |  | 100 | % |

[0001511737-14-000009:notes:98]
The Company generally forwards products directly from its manufacturers to its customers via logistics distribution hubs in Asia.  Beginning in the quarter ended December 31, 2012, the Company's products were predominantly routed through a third party logistics provider in China and prior to the quarter ended December 31, 2012, the Company's products were predominantly delivered to its customers through distribution hubs in Hong Kong.  The Company's logistics provider, in turn, ships to other locations throughout the world. The Company has determined the geographical distribution of product revenues based upon the customer's ship-to destinations.

[0001511737-14-000009:notes:99]
[same as prior period, unchanged from 0001511737-13-000021:notes:100]

[0001511737-14-000009:notes:100]
|  | Three Months Ended December 31, |  | Six Months Ended December 31, |
|  | 2013 |  | 2012 |  | 2013 |  | 2012 |
| North America(1) | $ | 32,567 |  |  | 24 | % |  | $ | 12,106 |  |  | 16 | % |  | $ | 70,000 |  |  | 26 | % |  | $ | 32,467 |  |  | 24 | % |
| South America | 27,992 |  |  | 20 | % |  | 17,081 |  |  | 23 | % |  | 48,768 |  |  | 18 | % |  | 27,324 |  |  | 20 | % |
| Europe, the Middle East and Africa | 58,842 |  |  | 42 | % |  | 35,929 |  |  | 48 | % |  | 111,708 |  |  | 42 | % |  | 59,073 |  |  | 43 | % |
| Asia Pacific | 19,038 |  |  | 14 | % |  | 9,785 |  |  | 13 | % |  | 37,650 |  |  | 14 | % |  | 17,572 |  |  | 13 | % |
| Total revenues | $ | 138,439 |  |  | 100 | % |  | $ | 74,901 |  |  | 100 | % |  | $ | 268,126 |  |  | 100 | % |  | $ | 136,436 |  |  | 100 | % |

[0001511737-14-000009:notes:101]
| (1) | Revenue for the United States was $31.1 million and $11.4 million for the three months ended December 31, 2013 and 2012, respectively. Revenue for the United States was $67.3 million and $30.7 million for the six months ended December 31, 2013 and 2012, respectively. |

[0001511737-14-000009:notes:102]
[same as prior period, unchanged from 0001511737-13-000021:notes:103]

[0001511737-14-000009:notes:103]
|  | Percentage of Revenues |  | Percentage of Accounts Receivable |
|  | Three Months Ended December 31, |  | Six Months Ended December 31, |  | December 31, |  | June 30, |
|  | 2013 |  | 2012 |  | 2013 |  | 2012 |  | 2013 |  | 2013 |
| Customer A | 17 | % |  | 15 | % |  | 14 | % |  | 12 | % |  | 20 | % |  | 12 | % |
| Customer B | * |  |  | 14 | % |  | * |  |  | * |  |  | 11 | % |  | 11 | % |
| Customer C | * |  |  | * |  |  | * |  |  | * |  |  | 16 | % |  | 15 | % |

[0001511737-14-000009:notes:104]
[same as prior period, unchanged from 0001511737-13-000021:notes:105]


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001511737-14-000009:notes:105]
[same as prior period, unchanged from 0001511737-13-000021:notes:106]

[0001511737-14-000009:notes:106]
[same as prior period, unchanged from 0001511737-13-000021:notes:107]


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001511737-14-000009:notes:107]
[same as prior period, unchanged from 0001511737-13-000021:notes:108]

[0001511737-14-000009:notes:108]
[same as prior period, unchanged from 0001511737-13-000021:notes:109]

[0001511737-14-000009:notes:109]
[same as prior period, unchanged from 0001511737-13-000021:notes:110]

[0001511737-14-000009:notes:110]
[same as prior period, unchanged from 0001511737-13-000021:notes:111]

[0001511737-14-000009:notes:111]
[same as prior period, unchanged from 0001511737-13-000021:notes:112]

[0001511737-14-000009:notes:112]
The Company's intangible assets consist primarily of legal costs associated with the application for and registration of the Company’s patents and trademarks.  The Company recorded $25,000 and $175,000 of amortization of intangible assets during the three and six months ended December 31, 2013, respectively.  The Company did not record any amortization of intangible assets during the three and six months ended December 31, 2012.   The balance of accumulated amortization was $375,000 and $200,000 at December 31, 2013 and June 30, 2013, respectively.  Estimated future amortization related to trademark registration fees is $56,000, $237,000, $237,000, $216,000, $54,000 and $3,000 for the remainder of fiscal 2014 and fiscal years 2015, 2016, 2017, 2018, and thereafter, respectively.  The Company commences amortization of patent registration fees upon approval of the related patent, the timing of which is determined by the regulating authority and is outside the control of the Company.  Therefore, future amortization expense related to patent registration fees by year cannot be reasonably estimated; however, upon approval of each patent, the Company expects to amortize the related capitalized fees over the estimated useful life of the patent.

[0001511737-14-000009:notes:113]
[same as prior period, unchanged from 0001511737-13-000021:notes:114]


## ubnt:CommonStockAndTreasuryStockDiscloseTextBlock

[0001511737-14-000009:notes:114]
[same as prior period, unchanged from 0001511737-13-000021:notes:115]

[0001511737-14-000009:notes:115]
As of December 31, 2013 and June 30, 2013, the authorized capital of the Company included 500,000,000 shares of common stock.  As of December 31, 2013, 131,978,895 shares of common stock were issued and 87,739,935 were outstanding. As of June 30, 2013, 131,452,763 shares of common stock were issued and 87,213,803 were outstanding.

[0001511737-14-000009:notes:116]
[same as prior period, unchanged from 0001511737-13-000021:notes:117]

[0001511737-14-000009:notes:117]
[same as prior period, unchanged from 0001511737-13-000021:notes:118]

[0001511737-14-000009:notes:118]
Common stock repurchase activity under the share repurchase program was as follows (in thousands, except share and per share amounts):

[0001511737-14-000009:notes:119]
| Period | Total Numberof SharesPurchased |  | Average PricePaid per Share |  | Estimated remaining balance available for share repurchase |
| August 13, 2012 – August 31, 2012 | 2,179,900 |  |  | $ | 8.88 |  |  | $ | 80,599 |  |
| September 1, 2012 – September 30, 2012 | 992,014 |  |  | $ | 11.93 |  |  | $ | 68,742 |  |
| October 1, 2012 - October 31, 2012 | 371,665 |  |  | $ | 11.72 |  |  | $ | 64,377 |  |
| November 1, 2012 - November 30, 2012 | 657,700 |  |  | $ | 11.16 |  |  | $ | 57,024 |  |
| December 1, 2012 - December 31, 2012 | 957,771 |  |  | $ | 11.86 |  |  | $ | 45,646 |  |
| Total | 5,159,050 |  |  | $ | 10.52 |  |  | $ | 45,646 |  |

[0001511737-14-000009:notes:120]
[same as prior period, unchanged from 0001511737-13-000021:notes:121]

[0001511737-14-000009:notes:121]
Special Dividend

[0001511737-14-000009:notes:122]
On December 14, 2012, the Company announced that its Board of Directors had authorized a special cash dividend of $0.18 per share for each share of common stock outstanding on December 24, 2012.  The aggregate dividend payment of $15.7 million was paid on December 28, 2012 to stockholders of record on December 24, 2012.  The dividend payment was funded using proceeds from the Loan Agreement as discussed in Note 7.
