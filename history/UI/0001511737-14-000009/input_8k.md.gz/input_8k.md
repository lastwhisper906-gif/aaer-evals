# UI 8-K — 0001511737-14-000005 filed 2014-02-06

## item codes, every 8-K on or before 2014-02-07

- 2014-02-06 0001511737-14-000005 — 2.02, 9.01
- 2013-12-16 0001193125-13-474388 — 5.07
- 2013-11-22 0001193125-13-451511 — 5.02
- 2013-11-07 0001511737-13-000018 — 2.02, 9.01
- 2013-10-28 0001193125-13-413414 — 5.02, 9.01
- 2013-10-18 0001193125-13-404111 — 5.02, 9.01
- 2013-08-08 0001511737-13-000009 — 2.02, 9.01
- 2013-05-09 0001511737-13-000004 — 2.02
- 2013-03-25 0001193125-13-124353 — 5.07
- 2013-03-08 0001193125-13-098334 — 5.02, 9.01
- 2013-02-07 0001193125-13-043701 — 2.02, 9.01
- 2012-12-28 0001193125-12-518487 — 1.01
- 2012-12-17 0001193125-12-503742 — 7.01, 9.01
- 2012-12-13 0001193125-12-501894 — 5.02
- 2012-11-16 0001193125-12-474083 — 5.02
- 2012-11-13 0001193125-12-467376 — 5.02
- 2012-11-08 0001193125-12-460665 — 2.02, 9.01
- 2012-10-10 0001193125-12-420015 — 5.02, 9.01
- 2012-08-13 0001193125-12-352624 — 1.01, 2.03, 9.01
- 2012-08-09 0001193125-12-347776 — 1.01, 9.01
- 2012-08-09 0001193125-12-347732 — 2.02, 9.01
- 2012-05-01 0001193125-12-201012 — 2.02, 9.01
- 2012-03-30 0001193125-12-144074 — 5.02
- 2012-03-27 0001193125-12-134395 — 5.02, 9.01
- 2012-03-22 0001193125-12-127536 — 5.02
- 2012-01-31 0001193125-12-032079 — 2.02, 9.01
- 2011-12-27 0001193125-11-353002 — 1.01, 9.01
- 2011-12-06 0001193125-11-332192 — 5.02
- 2011-11-10 0001193125-11-306969 — 2.02, 9.01

## late-filing notifications on or before 2014-02-07

- none on or before 2014-02-07

## item 2.02 — earnings release, exhibit 99.1

[0001511737-14-000005:8k_2_02:1]
EX-99.1
2
exhibit991q22014.htm
PRESS RELEASE OF UBIQUITI NETWORKS, INC.

[0001511737-14-000005:8k_2_02:2]
Exhibit 99.1 Q2 2014

[0001511737-14-000005:8k_2_02:3]
Exhibit 99.1

[0001511737-14-000005:8k_2_02:4]
| Contact: |  |  |  |  |
| Mary Zimmerman - IR@ubnt.com |  |  |  |  |

[0001511737-14-000005:8k_2_02:5]
UBIQUITI NETWORKS REPORTS RECORD SECOND QUARTER FINANCIAL RESULTS

[0001511737-14-000005:8k_2_02:6]
~ Achieves Record Revenue and Earnings ~

[0001511737-14-000005:8k_2_02:7]
~ Posts Non-GAAP EPS of $0.48 Per Diluted Share ~

[0001511737-14-000005:8k_2_02:8]
San Jose, Calif. - February 6, 2014 - Ubiquiti Networks, Inc. (NASDAQ:UBNT) (“Ubiquiti”) today announced results for the second fiscal quarter of 2014, ended December 31, 2013.

[0001511737-14-000005:8k_2_02:9]
Second Quarter Financial Highlights

[0001511737-14-000005:8k_2_02:10]
| • | Revenues of $138.4 million, up 85% year-over-year |

[0001511737-14-000005:8k_2_02:11]
| • | GAAP net income of $41.8 million, up 135% year-over-year |

[0001511737-14-000005:8k_2_02:12]
| • | Non-GAAP operating profitability of $48.5 million, up 131% year-over-year |

[0001511737-14-000005:8k_2_02:13]
| • | GAAP Diluted EPS of $0.47, up 135% year-over-year and non-GAAP diluted EPS of $0.48 |

[0001511737-14-000005:8k_2_02:14]
| • | Average days sales outstanding (DSOs) declined slightly to 24 days, the lowest in the Company's history |

[0001511737-14-000005:8k_2_02:15]
| • | $27.6 million in net cash provided by operating activities |

[0001511737-14-000005:8k_2_02:16]
Second Quarter Business and Product Highlights

[0001511737-14-000005:8k_2_02:17]
| • | Publicly launched Ubiquiti World Network, an alliance of independent Internet Service Providers, and initiated a supporting nationwide advertising and marketing campaign. |

[0001511737-14-000005:8k_2_02:18]
| • | Announced U.S. Distribution Agreement with Ingram Micro, showing that Ubiquiti's technology addresses a critical segment important to large tech distributors. |

[0001511737-14-000005:8k_2_02:19]
Service Provider Technology:

[0001511737-14-000005:8k_2_02:20]
| • | Introduced significant updates to its next-generation airMAX®, airFiber™ and EdgeMAX™ products. |

[0001511737-14-000005:8k_2_02:21]
Enterprise Technology:

[0001511737-14-000005:8k_2_02:22]
| • | UniFiTM Platform Revenues grew by more than 200% from last quarter according to Gartner Research. |

[0001511737-14-000005:8k_2_02:23]
| • | Ubiquiti’s Golden AP was found in Brazil, commemorating UniFi’s one millionth access point sold. |

[0001511737-14-000005:8k_2_02:24]
“We continue to expand our business,” said Robert J. Pera, Founder, Chief Executive Officer and Executive Chairman of Ubiquiti Networks.  “In our second quarter, we laid important groundwork to enhance our long term growth.  This included the hiring of key engineering talent which we expect will ramp our pace of innovation, took steps to reduce supply constraints experienced in recent quarters, and formally rolled out our Ubiquiti World Network, which we believe will create powerful network effects supporting our customer’s businesses, and in turn creating new and sustainable demand for our products.”

[0001511737-14-000005:8k_2_02:25]
Financial Summary ($, in millions, except per share data)

[0001511737-14-000005:8k_2_02:26]
| Financials | F2Q14 | F1Q14 | F2Q13 |
| Revenues | 138.4 | 129.7 | 74.9 |
| Service Provider | 111.4 | 94.2 | 68.2 |
| Enterprise | 27.0 | 35.5 | 6.7 |
| Cost of Revenues | 77.5 | 71.7 | 44.4 |
| Gross Profit | 61.0 | 58 | 30.5 |
| Total Operating Expenses | 13.9 | 12.1 | 10.4 |
| Income from Operations | 47.1 | 45.9 | 20.1 |
| Non-GAAP EPS (diluted) | 0.48 | 0.46 | 0.20 |

[0001511737-14-000005:8k_2_02:27]
Business Outlook

[0001511737-14-000005:8k_2_02:28]
Based on current business trends, Ubiquiti currently believes the demand environment in its end markets supports the following forecast for the Company's third fiscal quarter ending March 31, 2014:

[0001511737-14-000005:8k_2_02:29]
| • | Revenues of between $138 million and $144 million |

[0001511737-14-000005:8k_2_02:30]
| • | GAAP Diluted EPS of between $0.46 and $0.50 |

[0001511737-14-000005:8k_2_02:31]
| • | Non-GAAP Diluted EPS of between $0.47 and $0.51 |

[0001511737-14-000005:8k_2_02:32]
Conference Call

[0001511737-14-000005:8k_2_02:33]
Ubiquiti Networks will host a Q&A-only conference call to discuss the Company’s financial results at 2:00 p.m. PT today. A transcript of management’s prepared remarks can be found on the Investor Relations section of Ubiquiti Networks' website, http://www.ubnt.com/.

[0001511737-14-000005:8k_2_02:34]
To listen to the Q&A-only conference call via telephone, dial (877) 291-1296 (U.S. toll-free) or (720) 259-9209 (International) to be connected to the call by an operator. Participants should dial in at least 10 minutes prior to the start of the call. Investors may also listen to a live webcast of the Q&A-only conference call by visiting the Investor Relations section of Ubiquiti Networks' website.

[0001511737-14-000005:8k_2_02:35]
The playback of the Q&A call will be available approximately two hours after the call concludes and will be accessible on the Investor Relations section of Ubiquiti Networks' website.

[0001511737-14-000005:8k_2_02:36]
About Ubiquiti Networks

[0001511737-14-000005:8k_2_02:37]
Ubiquiti Networks (NASDAQ: UBNT) is closing the digital divide by building network communication platforms for everyone and everywhere.  With over 10 million devices deployed in over 180 countries, Ubiquiti is transforming under-networked businesses and communities.  Our leading edge platforms, airMAX™, UniFi™, airFiber™, airVision™, mFi™ and EdgeMAX™ combine innovative technology, disruptive price performance and the support of a global user community to eliminate barriers to connectivity.   For more information, join our community at http://www.ubnt.com/.

[0001511737-14-000005:8k_2_02:38]
Ubiquiti, the Ubiquiti logo, Ubiquiti Networks, airMAX, UniFi, airFiber, airVision, mFi and EdgeMAX are registered trademarks or trademarks of Ubiquiti Networks, Inc. and/or its affiliates in the United States and other countries.

[0001511737-14-000005:8k_2_02:39]
Use of Non-GAAP Financial Information

[0001511737-14-000005:8k_2_02:40]
To supplement our condensed consolidated financial results prepared under generally accepted accounting principles, or GAAP, we use non-GAAP measures of net income and earnings per diluted share that are adjusted to exclude certain recurring costs, expenses and gains such as stock based compensation expense and the tax effects of these non-GAAP adjustments.  Reconciliations of the adjustments to GAAP results for the three and six months ended December 31, 2013 and 2012 are provided below.  In addition, an explanation of the ways in which management uses non-GAAP financial information to evaluate its business, the substance behind management's decision to use this non-GAAP financial information, the material limitations associated with the use of non-GAAP financial information, the manner in which management compensates for those limitations, and the substantive

[0001511737-14-000005:8k_2_02:41]
reasons management believes that this non-GAAP financial information provides useful information to investors is included under "About our Non-GAAP Net Income and Adjustments" after the tables below.

[0001511737-14-000005:8k_2_02:42]
These non-GAAP measures are not in accordance with or an alternative to GAAP and may be materially different from other non-GAAP measures, including similarly titled non-GAAP measures, used by other companies.  The presentation of this additional information should not be considered in isolation from, as a substitute for, or superior to, net income or earnings per diluted share prepared in accordance with GAAP.

[0001511737-14-000005:8k_2_02:43]
Forward-looking statements are subject to certain risks and uncertainties that could cause our actual future results to differ materially, or cause a material adverse impact on our results.  Potential risks and uncertainties include, but are not limited to, fluctuations in our operating results; varying demand for our products due to the financial and operating condition of our distributors and their customers, distributors' inventory management practices and general economic conditions; impact of counterfeiting and our ability to contain such impact; our reliance on a limited number of distributors; inability of our contract manufacturers and suppliers to meet our demand; our dependence on Qualcomm Atheros for chipsets without a short-term alternative; as we move into new markets competition from certain of our current or potential competitors who may be more established in such markets; our ability to keep pace with technological and market developments; success and timing of new product introductions by us and the performance of our products generally; our ability to effectively manage the significant increase in our transactional sales volumes; we may become subject to warranty claims, product liability and product recalls; that a substantial majority of our sales are into countries outside the United States and we are subject to numerous U.S. export control and economic sanctions laws; costs related to responding to government inquiries related to regulatory compliance; our reliance on the Ubiquiti Community; our reliance on certain key members of our management team, including our founder and chief executive officer, Robert J.  Pera; adverse tax-related matters such as tax audits, changes in our effective tax rate or new tax legislative proposals; whether the final determination of our income tax liability may be materially different from our income tax provisions; the impact of any intellectual property litigation and claims for indemnification and litigation related to U.S. Securities laws and economic and political conditions in the United States and abroad.  We discuss these risks in greater detail under the heading “Risk Factors” and elsewhere in our Annual Report on Form 10-K for the year ended June 30, 2013 and other filings filed with the U.S. Securities and Exchange Commission (the SEC), which are available at the SEC's website at www.sec.gov.  Copies may also be obtained by contacting Ubiquiti Networks' Investor Relations Department, or by email at IR@ubnt.com or Ubiquiti Networks' Investor Relations website at www.ubnt.com.

[0001511737-14-000005:8k_2_02:44]
Given these uncertainties, you should not place undue reliance on these forward-looking statements.  Also, forward-looking statements represent our management's beliefs and assumptions only as of the date made.  Ubiquiti Networks undertakes no obligation to update information contained in this press release.  You should review our SEC filings carefully and with the understanding that our actual future results may be materially different from what we expect.

[0001511737-14-000005:8k_2_02:45]
| Ubiquiti Networks Inc.Condensed Consolidated Statement of Operations(In thousands, except per share data)(Unaudited) |
|  |  | Three Months Ended December 31, |  | Six Months Ended December 31, |
|  |  | 2013 |  | 2012 |  | 2013 |  | 2012 |
| Revenues |  | $ | 138,439 |  |  | $ | 74,901 |  |  | $ | 268,126 |  |  | $ | 136,436 |  |
| Cost of revenues |  | 77,468 |  |  | 44,416 |  |  | 149,132 |  |  | 80,931 |  |
| Gross profit |  | 60,971 |  |  | 30,485 |  |  | 118,994 |  |  | 55,505 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Research and development |  | 8,077 |  |  | 5,052 |  |  | 14,394 |  |  | 9,763 |  |
| Sales, general and administrative |  | 5,774 |  |  | 5,314 |  |  | 11,584 |  |  | 9,848 |  |
| Total operating expenses |  | 13,851 |  |  | 10,366 |  |  | 25,978 |  |  | 19,611 |  |
| Income from operations |  | 47,120 |  |  | 20,119 |  |  | 93,016 |  |  | 35,894 |  |
| Interest expense and other, net |  | (249 | ) |  | (197 | ) |  | (495 | ) |  | (283 | ) |
| Income before provision for income taxes |  | 46,871 |  |  | 19,922 |  |  | 92,521 |  |  | 35,611 |  |
| Provision for income taxes |  | 5,079 |  |  | 2,119 |  |  | 10,201 |  |  | 4,629 |  |
| Net income |  | $ | 41,792 |  |  | $ | 17,803 |  |  | $ | 82,320 |  |  | $ | 30,982 |  |
| Net income per share of common stock: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.48 |  |  | $ | 0.20 |  |  | $ | 0.94 |  |  | $ | 0.35 |  |
| Diluted |  | $ | 0.47 |  |  | $ | 0.20 |  |  | $ | 0.92 |  |  | $ | 0.34 |  |
| Weighted average shares used in computing net income per share of common stock: |  |  |  |  |  |  |  |  |
| Basic |  | 87,661 |  |  | 88,094 |  |  | 87,536 |  |  | 89,532 |  |
| Diluted |  | 89,653 |  |  | 90,056 |  |  | 89,593 |  |  | 91,493 |  |
| Cash dividends declared per common share |  | $ | — |  |  | $ | 0.18 |  |  | $ | — |  |  | $ | 0.18 |  |

[0001511737-14-000005:8k_2_02:46]
| Ubiquiti Networks Inc.Reconciliation of GAAP Net Income to Non-GAAP Net Income(In thousands, except per share data)(Unaudited) |
|  |  | Three Months Ended December 31, |  | Six Months Ended December 31, |
|  |  | 2013 |  | 2012 |  | 2013 |  | 2012 |
| Net income |  | $ | 41,792 |  |  | $ | 17,803 |  |  | $ | 82,320 |  |  | $ | 30,982 |  |
| Stock-based compensation: |  |  |  |  |  |  |  |  |
| Cost of revenues |  | 148 |  |  | 104 |  |  | 292 |  |  | 185 |  |
| Research and development |  | 553 |  |  | 401 |  |  | 1,049 |  |  | 667 |  |
| Sales, general and administrative |  | 721 |  |  | 388 |  |  | 1,248 |  |  | 697 |  |
| Tax effect of non-GAAP adjustments |  | (569 | ) |  | (357 | ) |  | (1,036 | ) |  | (620 | ) |
| Non-GAAP net income |  | $ | 42,645 |  |  | $ | 18,339 |  |  | $ | 83,873 |  |  | $ | 31,911 |  |
| Non-GAAP diluted EPS |  | $ | 0.48 |  |  | $ | 0.20 |  |  | $ | 0.94 |  |  | $ | 0.35 |  |
| Weighted-average shares used in non-GAAP diluted EPS |  | 89,653 |  |  | 90,056 |  |  | 89,593 |  |  | 91,493 |  |

[0001511737-14-000005:8k_2_02:47]
| Ubiquiti Networks Inc.Condensed Consolidated Balance Sheets(In thousands)(Unaudited) |
|  |  | December 31, 2013 |  | June 30, 2013(1) |
| Assets |  |  |  |  |
| Current assets: |  |  |  |  |
| Cash and cash equivalents |  | $ | 305,553 |  |  | $ | 227,826 |  |
| Accounts receivable, net |  | 36,809 |  |  | 35,884 |  |
| Inventories |  | 32,323 |  |  | 15,880 |  |
| Current deferred tax asset |  | 733 |  |  | 733 |  |
| Prepaid income taxes |  | 2,799 |  |  | — |  |
| Prepaid expenses and other current assets |  | 4,425 |  |  | 3,151 |  |
| Total current assets |  | 382,642 |  |  | 283,474 |  |
| Property and equipment, net |  | 6,793 |  |  | 5,976 |  |
| Long-term deferred tax asset |  | 4 |  |  | 4 |  |
| Other long–term assets |  | 3,105 |  |  | 2,886 |  |
| Total assets |  | $ | 392,544 |  |  | $ | 292,340 |  |
| Liabilities and Stockholders’ Equity |  |  |  |  |
| Current liabilities: |  |  |  |  |
| Accounts payable |  | $ | 49,688 |  |  | $ | 36,187 |  |
| Customer deposits |  | 3,930 |  |  | 5,123 |  |
| Deferred revenues |  | 898 |  |  | 691 |  |
| Income taxes payable |  | — |  |  | 1,257 |  |
| Debt - short-term |  | 5,642 |  |  | 5,013 |  |
| Other current liabilities |  | 12,953 |  |  | 11,150 |  |
| Total current liabilities |  | 73,111 |  |  | 59,421 |  |
| Long-term taxes payable |  | 13,380 |  |  | 11,857 |  |
| Debt - long-term |  | 68,006 |  |  | 71,116 |  |
| Deferred revenues - long-term |  | 3,017 |  |  | 2,510 |  |
| Total liabilities |  | 157,514 |  |  | 144,904 |  |
| Stockholders’ equity: |  |  |  |  |
| Common stock |  | 88 |  |  | 87 |  |
| Additional paid–in capital |  | 140,255 |  |  | 134,982 |  |
| Treasury stock |  | (123,864 | ) |  | (123,864 | ) |
| Retained earnings |  | 218,551 |  |  | 136,231 |  |
| Total stockholders’ equity |  | 235,030 |  |  | 147,436 |  |
| Total liabilities and stockholders’ equity |  | $ | 392,544 |  |  | $ | 292,340 |  |

[0001511737-14-000005:8k_2_02:48]
| (1) | Derived from audited consolidated statements as of and for the year ended June 30, 2013. |

[0001511737-14-000005:8k_2_02:49]
| Ubiquiti Networks Inc.Revenues by Product Type (In thousands)(Unaudited) |
|  |  | Three Months Ended December 31, |  | Six Months Ended December 31, |
|  |  | 2013 |  | 2012 |  | 2013 |  | 2012 |
| Service provider technology |  | $ | 111,454 |  |  | $ | 68,170 |  |  | $ | 205,671 |  |  | $ | 119,787 |  |
| Enterprise technology |  | 26,985 |  |  | 6,731 |  |  | 62,455 |  |  | 16,649 |  |
| Total revenues |  | $ | 138,439 |  |  | $ | 74,901 |  |  | $ | 268,126 |  |  | $ | 136,436 |  |

[0001511737-14-000005:8k_2_02:50]
| Ubiquiti Networks Inc.Revenues by Geographical Area(In thousands)(Unaudited) |
|  |  | Three Months Ended December 31, |  | Six Months Ended December 31, |
|  |  | 2013 |  | 2012 |  | 2013 |  | 2012 |
| North America |  | $ | 32,567 |  |  | $ | 12,106 |  |  | $ | 70,000 |  |  | $ | 32,467 |  |
| South America |  | 27,992 |  |  | 17,081 |  |  | 48,768 |  |  | 27,324 |  |
| Europe, the Middle East and Africa |  | 58,842 |  |  | 35,929 |  |  | 111,708 |  |  | 59,073 |  |
| Asia Pacific |  | 19,038 |  |  | 9,785 |  |  | 37,650 |  |  | 17,572 |  |
| Total revenues |  | $ | 138,439 |  |  | $ | 74,901 |  |  | $ | 268,126 |  |  | $ | 136,436 |  |

[0001511737-14-000005:8k_2_02:51]
About our Non-GAAP Net Income and Adjustments

[0001511737-14-000005:8k_2_02:52]
Use of Non-GAAP Financial Information

[0001511737-14-000005:8k_2_02:53]
To supplement our condensed consolidated financial results prepared under generally accepted accounting principles, or GAAP, we use non-GAAP measures of net income and earnings per diluted share that are GAAP net income and GAAP earnings per diluted share adjusted to exclude certain recurring costs, expenses and gains.

[0001511737-14-000005:8k_2_02:54]
We believe that the presentation of non-GAAP net income and non-GAAP earnings per diluted share provides important supplemental information regarding non-cash expenses, significant recurring items that we believe are important to understanding our financial, and business trends relating to our financial condition and results of operations.  Non-GAAP net income and non-GAAP earnings per diluted share are among the primary indicators used by management as a basis for planning and forecasting future periods and by management and our board of directors to determine whether our operating performance has met specified targets and thresholds.  Management uses non-GAAP net income and non-GAAP earnings per diluted share when evaluating operating performance because it believes that the exclusion of the items described below, for which the amounts and/or timing may vary significantly depending upon the Company's activities and other factors, facilitates comparability of the Company's operating performance from period to period.  We have chosen to provide this information to investors so they can analyze our operating results in the same way that management does and use this information in their assessment of our business and the valuation of our Company.

[0001511737-14-000005:8k_2_02:55]
Use and Economic Substance of Non-GAAP Financial Measures used by Ubiquiti Networks

[0001511737-14-000005:8k_2_02:56]
We compute non-GAAP net income and non-GAAP diluted earnings per share by adjusting GAAP net income and GAAP earnings per diluted share to remove the impact of recurring stock-based compensation expense and the tax effect of these adjustments.  Examples of items excluded from net income are:

[0001511737-14-000005:8k_2_02:57]
| • | Recurring charges and gains, including: |

[0001511737-14-000005:8k_2_02:58]
| ◦ | Stock-based compensation expense is recognized in accordance with FASB Accounting Standards Codification, Topic 718, Stock Compensation. |

[0001511737-14-000005:8k_2_02:59]
| • | Tax effect of non-GAAP adjustments. After adjusting to exclude the items described above, we apply the principles of ASC 740, Income Taxes, to estimate the non-GAAP income tax provision. |

[0001511737-14-000005:8k_2_02:60]
Usefulness of Non-GAAP Financial Information to Investors

[0001511737-14-000005:8k_2_02:61]
These non-GAAP measures are not in accordance with or an alternative to GAAP and may be materially different from other non-GAAP measures, including similarly titled non-GAAP measures, used by other companies.  The presentation of this additional information should not be considered in isolation from, as a substitute for, or superior to, net income or earnings per diluted share prepared in accordance with GAAP.  Non-GAAP financial measures have limitations in that they do not reflect certain items that may have a material impact upon our reported financial results.  We expect to continue to incur expenses of a nature similar to the non-GAAP adjustments described above, and exclusion of these items from our non-GAAP net income and non-GAAP earnings per diluted share should not be construed as an inference that these costs are unusual, infrequent or non-recurring.

[0001511737-14-000005:8k_2_02:62]
For more information on the non-GAAP adjustments, please see the table captioned “Reconciliation of GAAP Net Income to non-GAAP Net Income” included in this press release.
